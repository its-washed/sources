// Chunk 78 - 50 functions

// ============================================================
// Function: FUN_1801073c0
// Address: 0x1801073c0
// Size: 346 bytes
// ============================================================
void fcn.1801073c0(void)
{
    float *pfVar1;
    int64_t iVar2;
    undefined auVar3 [16];
    int64_t iVar4;
    int64_t iVar5;
    float fVar6;
    undefined in_XMM0 [16];
    float fVar7;
    float fVar8;
    int64_t var_18h;
    
    iVar4 = *(int64_t *)0x180781f28;
    fVar8 = 0.0;
    if (in_XMM0._0_4_ <= 0.0) {
        auVar3._12_4_ = 0;
        auVar3._0_12_ = in_XMM0._4_12_;
        in_XMM0 = auVar3 << 0x20;
    }
    pfVar1 = (float *)(*(int64_t *)0x180781f28 + 0x12fc);
    iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(float *)(*(int64_t *)0x180781f28 + 0xd90) = *pfVar1;
    fVar7 = in_XMM0._0_4_;
    if (fVar7 == 0.0) {
        fVar7 = *pfVar1 * *(float *)(iVar4 + 0xd94) * *(float *)(iVar4 + 0xd98);
        if (iVar5 != 0) {
            fVar7 = fVar7 * *(float *)(iVar5 + 0x310);
        }
        fVar7 = fVar7 * *(float *)(iVar4 + 0xc28);
        if (*(int64_t *)(iVar4 + 0x12e8) != 0) {
            fVar7 = fVar7 * *(float *)(*(int64_t *)(iVar4 + 0x12e8) + 0x48);
        }
    }
    fVar6 = (float)(int32_t)(fVar7 + 0.5);
    fVar7 = 1.0;
    if ((1.0 <= fVar6) && (fVar7 = 512.0, fVar6 <= 512.0)) {
        fVar7 = fVar6;
    }
    if ((*(int64_t *)(iVar4 + 0x12e8) != 0) && ((*(uint8_t *)(iVar4 + 0x34) & 0x10) != 0)) {
        *(undefined4 *)(*(int64_t *)(iVar4 + 0x12e8) + 0x14) = *(undefined4 *)(iVar4 + 0x1304);
    }
    *(float *)(iVar4 + 0x12f8) = fVar7;
    *(float *)(iVar4 + 0x1330) = fVar7;
    if (((iVar5 == 0) || (*(char *)(iVar5 + 0x10e) == '\0')) ||
       ((iVar2 = *(int64_t *)(iVar4 + 0x24d0), iVar2 != 0 &&
        ((*(int32_t *)(iVar2 + 0x74) == -1 ||
         (*(char *)((int64_t)*(int32_t *)(iVar2 + 0x74) * 0x74 + 0x6c + *(int64_t *)(iVar2 + 0x18)) != '\0')))))) {
        if ((*(int64_t *)(iVar4 + 0x12e8) == 0) || (iVar5 == 0)) {
            *(undefined8 *)(iVar4 + 0x12f0) = 0;
        } else {
            iVar5 = func_0x00018012ec80(*(int64_t *)(iVar4 + 0x12e8), iVar5, 0xbf800000);
            *(int64_t *)(iVar4 + 0x12f0) = iVar5;
            if (iVar5 != 0) {
                fVar8 = *(float *)(iVar4 + 0x12f8) / *(float *)(iVar5 + 0x14);
            }
        }
        *(float *)(iVar4 + 0x1300) = fVar8;
        *(float *)(iVar4 + 0x1334) = fVar8;
    }
    return;
}

// ============================================================
// Function: FUN_180107520
// Address: 0x180107520
// Size: 105 bytes
// ============================================================
void fcn.180107520(void)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    
    iVar2 = *(int64_t *)0x180781f28;
    iVar3 = (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0);
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) < 1) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018010755a. Too many branches
    // WARNING: Treating indirect jump as call
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445d0);
            return;
        }
    } else {
        iVar1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x20e8);
        func_0x0001801072d0(*(undefined8 *)(iVar1 + -0x10 + iVar3 * 0x10), *(undefined4 *)(iVar1 + -8 + iVar3 * 0x10), 
                            *(undefined4 *)(iVar1 + -4 + iVar3 * 0x10));
        *(int32_t *)(iVar2 + 0x20e0) = *(int32_t *)(iVar2 + 0x20e0) + -1;
    }
    return;
}

// ============================================================
// Function: FUN_180107590
// Address: 0x180107590
// Size: 135 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180107590(undefined8 param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined4 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t *piVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    piVar6 = (int32_t *)(iVar2 + 0x148);
    iVar1 = *piVar6;
    uVar3 = func_0x0001800f5a90(param_1, 0, *(undefined4 *)(*(int64_t *)(iVar2 + 0x150) + -4 + (int64_t)iVar1 * 4));
    iVar4 = *(int32_t *)(iVar2 + 0x14c);
    if (iVar1 == iVar4) {
        if (iVar4 == 0) {
            iVar4 = 8;
        } else {
            iVar4 = iVar4 / 2 + iVar4;
        }
        iVar5 = iVar1 + 1;
        if (iVar1 + 1 < iVar4) {
            iVar5 = iVar4;
        }
        func_0x00018011fb10(piVar6, iVar5);
    }
    *(undefined4 *)(*(int64_t *)(iVar2 + 0x150) + (int64_t)*piVar6 * 4) = uVar3;
    *piVar6 = *piVar6 + 1;
    return;
}

// ============================================================
// Function: FUN_180107620
// Address: 0x180107620
// Size: 167 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.180107620(int64_t arg1)
{
    uint8_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t *piVar6;
    uint32_t uVar7;
    int32_t *piVar8;
    int64_t var_8h;
    int64_t var_18h;
    
    piVar6 = &var_18h;
    var_18h._0_4_ = (int32_t)arg1;
    iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    piVar8 = (int32_t *)(iVar3 + 0x148);
    iVar2 = *piVar8;
    uVar7 = ~*(uint32_t *)(*(int64_t *)(iVar3 + 0x150) + -4 + (int64_t)iVar2 * 4);
    do {
        uVar1 = *(uint8_t *)piVar6;
        piVar6 = (int64_t *)((int64_t)piVar6 + 1);
        uVar7 = uVar7 >> 8 ^ *(uint32_t *)(((uint64_t)(uVar7 & 0xff) ^ (uint64_t)uVar1) * 4 + 0x180618620);
    } while (piVar6 < (int64_t *)((int64_t)&var_18h + 4U));
    iVar5 = *(int32_t *)(iVar3 + 0x14c);
    if (iVar2 == iVar5) {
        if (iVar5 == 0) {
            iVar5 = 8;
        } else {
            iVar5 = iVar5 / 2 + iVar5;
        }
        iVar4 = iVar2 + 1;
        if (iVar2 + 1 < iVar5) {
            iVar4 = iVar5;
        }
        func_0x00018011fb10(piVar8, iVar4);
    }
    *(uint32_t *)(*(int64_t *)(iVar3 + 0x150) + (int64_t)*piVar8 * 4) = ~uVar7;
    *piVar8 = *piVar8 + 1;
    return;
}

// ============================================================
// Function: FUN_1801076d0
// Address: 0x1801076d0
// Size: 112 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801076d0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t *piVar3;
    int32_t iVar4;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    piVar3 = (int32_t *)(iVar1 + 0x148);
    iVar2 = *(int32_t *)(iVar1 + 0x14c);
    if (*piVar3 == iVar2) {
        iVar4 = *piVar3 + 1;
        if (iVar2 == 0) {
            iVar2 = 8;
        } else {
            iVar2 = iVar2 / 2 + iVar2;
        }
        if (iVar4 < iVar2) {
            iVar4 = iVar2;
        }
        func_0x00018011fb10(piVar3, iVar4);
    }
    *(int32_t *)(*(int64_t *)(iVar1 + 0x150) + (int64_t)*piVar3 * 4) = (int32_t)arg1;
    *piVar3 = *piVar3 + 1;
    return;
}

// ============================================================
// Function: FUN_180107980
// Address: 0x180107980
// Size: 476 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_13ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_14ch

void fcn.180107980(int64_t arg1, int64_t arg2, int64_t arg_138h, int64_t arg_150h)
{
    int32_t *piVar1;
    int16_t *piVar2;
    undefined4 *puVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    undefined4 uVar6;
    int64_t iVar7;
    undefined8 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    int64_t iVar11;
    int32_t iVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t iVar15;
    int32_t iVar16;
    uint32_t uVar17;
    int16_t iVar18;
    int64_t var_8h;
    int64_t var_400h;
    
    iVar11 = *(int64_t *)0x180781f28;
    piVar1 = (int32_t *)(arg1 + 0x148);
    iVar13 = *(int32_t *)(arg1 + 0x14c);
    if (iVar13 < 0) {
        iVar13 = iVar13 + iVar13 / 2;
        iVar12 = 0;
        if (0 < iVar13) {
            iVar12 = iVar13;
        }
        func_0x00018011faa0(piVar1, iVar12);
    }
    *piVar1 = 0;
    uVar17 = 0x200;
    iVar13 = 0;
    do {
        piVar2 = (int16_t *)(arg1 + -0x400 + (uint64_t)uVar17 * 2);
        iVar18 = *piVar2;
        while (iVar18 != -1) {
            iVar7 = *(int64_t *)(arg1 + 0x140);
            iVar15 = (int64_t)(int32_t)iVar18;
            iVar12 = *(int32_t *)(iVar7 + 0xc + iVar15 * 0x10);
            *(undefined2 *)(iVar7 + 4 + iVar15 * 0x10) = *(undefined2 *)(iVar7 + 6 + iVar15 * 0x10);
            *(int32_t *)(iVar7 + 8 + iVar15 * 0x10) = iVar12;
            *(undefined4 *)(iVar7 + 0xc + iVar15 * 0x10) = 0xffffffff;
            *(undefined2 *)(iVar7 + 6 + iVar15 * 0x10) = 0;
            if (iVar12 != -1) {
                iVar12 = *(int32_t *)(arg1 + 0x14c);
                if (*piVar1 == iVar12) {
                    iVar14 = *piVar1 + 1;
                    if (iVar12 == 0) {
                        iVar12 = 8;
                    } else {
                        iVar12 = iVar12 / 2 + iVar12;
                    }
                    if (iVar14 < iVar12) {
                        iVar14 = iVar12;
                    }
                    func_0x00018011faa0(piVar1, iVar14);
                }
                puVar3 = (undefined4 *)(iVar7 + iVar15 * 0x10);
                uVar6 = puVar3[1];
                uVar9 = puVar3[2];
                uVar10 = puVar3[3];
                puVar4 = (undefined4 *)(*(int64_t *)(arg1 + 0x150) + (int64_t)*piVar1 * 0x10);
                *puVar4 = *puVar3;
                puVar4[1] = uVar6;
                puVar4[2] = uVar9;
                puVar4[3] = uVar10;
                *piVar1 = *piVar1 + 1;
                if (((uint32_t)*(uint16_t *)(iVar7 + 2 + iVar15 * 0x10) == *(uint32_t *)(iVar11 + 0x13c)) &&
                   (iVar5 = iVar11 + (uint64_t)uVar17 * 0xc, *(int32_t *)(iVar5 + -0x134) == -1)) {
                    *(undefined4 *)(iVar5 + -0x134) = *(undefined4 *)(iVar7 + 8 + iVar15 * 0x10);
                }
            }
            iVar18 = *(int16_t *)(iVar7 + iVar15 * 0x10);
        }
        iVar18 = -1;
        if (iVar13 < *piVar1) {
            iVar18 = (int16_t)iVar13;
        }
        *piVar2 = iVar18;
        iVar12 = *piVar1;
        if (iVar13 < iVar12) {
            do {
                iVar16 = iVar13 + 1;
                iVar14 = -1;
                if (iVar16 < iVar12) {
                    iVar14 = iVar16;
                }
                *(int16_t *)(*(int64_t *)(arg1 + 0x150) + (int64_t)iVar13 * 0x10) = (int16_t)iVar14;
                iVar12 = *piVar1;
                iVar13 = iVar16;
            } while (iVar16 < iVar12);
        }
        iVar13 = iVar12;
        uVar17 = uVar17 + 1;
    } while ((int32_t)uVar17 < 0x29b);
    *piVar1 = *(int32_t *)(arg1 + 0x138);
    uVar6 = *(undefined4 *)(arg1 + 0x14c);
    *(undefined4 *)(arg1 + 0x14c) = *(undefined4 *)(arg1 + 0x13c);
    *(undefined4 *)(arg1 + 0x13c) = uVar6;
    uVar8 = *(undefined8 *)(arg1 + 0x150);
    *(undefined8 *)(arg1 + 0x150) = *(undefined8 *)(arg1 + 0x140);
    *(undefined8 *)(arg1 + 0x140) = uVar8;
    *(int32_t *)(arg1 + 0x138) = iVar13;
    return;
}

// ============================================================
// Function: FUN_180107b60
// Address: 0x180107b60
// Size: 173 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int16_t * fcn.180107b60(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int64_t iVar2;
    int16_t iVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int16_t *piVar6;
    undefined8 *puVar7;
    uint32_t uVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar2 = *(int64_t *)0x180781f28;
    uVar8 = (uint32_t)arg1 & 0xf000;
    uVar4 = (uint32_t)arg1 & 0xffff0fff;
    if ((arg1 & 0xffff0fffU) == 0) {
        if (uVar8 == 0x1000) {
            uVar4 = 0x297;
        } else if (uVar8 == 0x2000) {
            uVar4 = 0x298;
        } else if (uVar8 == 0x4000) {
            uVar4 = 0x299;
        } else {
            uVar4 = uVar8;
            if (uVar8 == 0x8000) {
                uVar4 = 0x29a;
            }
        }
    }
    iVar9 = (int64_t)(int32_t)uVar4;
    iVar3 = *(int16_t *)(*(int64_t *)0x180781f28 + 0x1a10 + iVar9 * 2);
    if (iVar3 != -1) {
        do {
            piVar6 = (int16_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1f50) + (int64_t)iVar3 * 0x10);
            if (*(uint16_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1f50) + 2 + (int64_t)iVar3 * 0x10) == uVar8) {
                return piVar6;
            }
            iVar3 = *piVar6;
        } while (iVar3 != -1);
    }
    piVar1 = (int32_t *)(*(int64_t *)0x180781f28 + 0x1f48);
    iVar5 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1f4c);
    iVar3 = *(int16_t *)piVar1;
    if (*piVar1 == iVar5) {
        iVar10 = *piVar1 + 1;
        if (iVar5 == 0) {
            iVar5 = 8;
        } else {
            iVar5 = iVar5 / 2 + iVar5;
        }
        if (iVar10 < iVar5) {
            iVar10 = iVar5;
        }
        func_0x00018011faa0(piVar1, iVar10);
    }
    puVar7 = (undefined8 *)((int64_t)*piVar1 * 0x10 + *(int64_t *)(iVar2 + 0x1f50));
    *puVar7 = 0xffff;
    puVar7[1] = 0xffffffffffffffff;
    *piVar1 = *piVar1 + 1;
    piVar6 = (int16_t *)(*(int64_t *)(iVar2 + 0x1f50) + (int64_t)iVar3 * 0x10);
    piVar6[1] = (int16_t)uVar8;
    *piVar6 = *(int16_t *)(iVar2 + 0x1a10 + iVar9 * 2);
    *(int16_t *)(iVar2 + 0x1a10 + iVar9 * 2) = iVar3;
    return piVar6;
}

// ============================================================
// Function: FUN_180107c0d
// Address: 0x180107c0d
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int16_t * fcn.180107b60(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int64_t iVar2;
    int16_t iVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int16_t *piVar6;
    undefined8 *puVar7;
    uint32_t uVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar2 = *(int64_t *)0x180781f28;
    uVar8 = (uint32_t)arg1 & 0xf000;
    uVar4 = (uint32_t)arg1 & 0xffff0fff;
    if ((arg1 & 0xffff0fffU) == 0) {
        if (uVar8 == 0x1000) {
            uVar4 = 0x297;
        } else if (uVar8 == 0x2000) {
            uVar4 = 0x298;
        } else if (uVar8 == 0x4000) {
            uVar4 = 0x299;
        } else {
            uVar4 = uVar8;
            if (uVar8 == 0x8000) {
                uVar4 = 0x29a;
            }
        }
    }
    iVar9 = (int64_t)(int32_t)uVar4;
    iVar3 = *(int16_t *)(*(int64_t *)0x180781f28 + 0x1a10 + iVar9 * 2);
    if (iVar3 != -1) {
        do {
            piVar6 = (int16_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1f50) + (int64_t)iVar3 * 0x10);
            if (*(uint16_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1f50) + 2 + (int64_t)iVar3 * 0x10) == uVar8) {
                return piVar6;
            }
            iVar3 = *piVar6;
        } while (iVar3 != -1);
    }
    piVar1 = (int32_t *)(*(int64_t *)0x180781f28 + 0x1f48);
    iVar5 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1f4c);
    iVar3 = *(int16_t *)piVar1;
    if (*piVar1 == iVar5) {
        iVar10 = *piVar1 + 1;
        if (iVar5 == 0) {
            iVar5 = 8;
        } else {
            iVar5 = iVar5 / 2 + iVar5;
        }
        if (iVar10 < iVar5) {
            iVar10 = iVar5;
        }
        func_0x00018011faa0(piVar1, iVar10);
    }
    puVar7 = (undefined8 *)((int64_t)*piVar1 * 0x10 + *(int64_t *)(iVar2 + 0x1f50));
    *puVar7 = 0xffff;
    puVar7[1] = 0xffffffffffffffff;
    *piVar1 = *piVar1 + 1;
    piVar6 = (int16_t *)(*(int64_t *)(iVar2 + 0x1f50) + (int64_t)iVar3 * 0x10);
    piVar6[1] = (int16_t)uVar8;
    *piVar6 = *(int16_t *)(iVar2 + 0x1a10 + iVar9 * 2);
    *(int16_t *)(iVar2 + 0x1a10 + iVar9 * 2) = iVar3;
    return piVar6;
}

// ============================================================
// Function: FUN_180107c3f
// Address: 0x180107c3f
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int16_t * fcn.180107b60(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int64_t iVar2;
    int16_t iVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int16_t *piVar6;
    undefined8 *puVar7;
    uint32_t uVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar2 = *(int64_t *)0x180781f28;
    uVar8 = (uint32_t)arg1 & 0xf000;
    uVar4 = (uint32_t)arg1 & 0xffff0fff;
    if ((arg1 & 0xffff0fffU) == 0) {
        if (uVar8 == 0x1000) {
            uVar4 = 0x297;
        } else if (uVar8 == 0x2000) {
            uVar4 = 0x298;
        } else if (uVar8 == 0x4000) {
            uVar4 = 0x299;
        } else {
            uVar4 = uVar8;
            if (uVar8 == 0x8000) {
                uVar4 = 0x29a;
            }
        }
    }
    iVar9 = (int64_t)(int32_t)uVar4;
    iVar3 = *(int16_t *)(*(int64_t *)0x180781f28 + 0x1a10 + iVar9 * 2);
    if (iVar3 != -1) {
        do {
            piVar6 = (int16_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1f50) + (int64_t)iVar3 * 0x10);
            if (*(uint16_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1f50) + 2 + (int64_t)iVar3 * 0x10) == uVar8) {
                return piVar6;
            }
            iVar3 = *piVar6;
        } while (iVar3 != -1);
    }
    piVar1 = (int32_t *)(*(int64_t *)0x180781f28 + 0x1f48);
    iVar5 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1f4c);
    iVar3 = *(int16_t *)piVar1;
    if (*piVar1 == iVar5) {
        iVar10 = *piVar1 + 1;
        if (iVar5 == 0) {
            iVar5 = 8;
        } else {
            iVar5 = iVar5 / 2 + iVar5;
        }
        if (iVar10 < iVar5) {
            iVar10 = iVar5;
        }
        func_0x00018011faa0(piVar1, iVar10);
    }
    puVar7 = (undefined8 *)((int64_t)*piVar1 * 0x10 + *(int64_t *)(iVar2 + 0x1f50));
    *puVar7 = 0xffff;
    puVar7[1] = 0xffffffffffffffff;
    *piVar1 = *piVar1 + 1;
    piVar6 = (int16_t *)(*(int64_t *)(iVar2 + 0x1f50) + (int64_t)iVar3 * 0x10);
    piVar6[1] = (int16_t)uVar8;
    *piVar6 = *(int16_t *)(iVar2 + 0x1a10 + iVar9 * 2);
    *(int16_t *)(iVar2 + 0x1a10 + iVar9 * 2) = iVar3;
    return piVar6;
}

// ============================================================
// Function: FUN_180107c52
// Address: 0x180107c52
// Size: 118 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int16_t * fcn.180107b60(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int64_t iVar2;
    int16_t iVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int16_t *piVar6;
    undefined8 *puVar7;
    uint32_t uVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar2 = *(int64_t *)0x180781f28;
    uVar8 = (uint32_t)arg1 & 0xf000;
    uVar4 = (uint32_t)arg1 & 0xffff0fff;
    if ((arg1 & 0xffff0fffU) == 0) {
        if (uVar8 == 0x1000) {
            uVar4 = 0x297;
        } else if (uVar8 == 0x2000) {
            uVar4 = 0x298;
        } else if (uVar8 == 0x4000) {
            uVar4 = 0x299;
        } else {
            uVar4 = uVar8;
            if (uVar8 == 0x8000) {
                uVar4 = 0x29a;
            }
        }
    }
    iVar9 = (int64_t)(int32_t)uVar4;
    iVar3 = *(int16_t *)(*(int64_t *)0x180781f28 + 0x1a10 + iVar9 * 2);
    if (iVar3 != -1) {
        do {
            piVar6 = (int16_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1f50) + (int64_t)iVar3 * 0x10);
            if (*(uint16_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1f50) + 2 + (int64_t)iVar3 * 0x10) == uVar8) {
                return piVar6;
            }
            iVar3 = *piVar6;
        } while (iVar3 != -1);
    }
    piVar1 = (int32_t *)(*(int64_t *)0x180781f28 + 0x1f48);
    iVar5 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1f4c);
    iVar3 = *(int16_t *)piVar1;
    if (*piVar1 == iVar5) {
        iVar10 = *piVar1 + 1;
        if (iVar5 == 0) {
            iVar5 = 8;
        } else {
            iVar5 = iVar5 / 2 + iVar5;
        }
        if (iVar10 < iVar5) {
            iVar10 = iVar5;
        }
        func_0x00018011faa0(piVar1, iVar10);
    }
    puVar7 = (undefined8 *)((int64_t)*piVar1 * 0x10 + *(int64_t *)(iVar2 + 0x1f50));
    *puVar7 = 0xffff;
    puVar7[1] = 0xffffffffffffffff;
    *piVar1 = *piVar1 + 1;
    piVar6 = (int16_t *)(*(int64_t *)(iVar2 + 0x1f50) + (int64_t)iVar3 * 0x10);
    piVar6[1] = (int16_t)uVar8;
    *piVar6 = *(int16_t *)(iVar2 + 0x1a10 + iVar9 * 2);
    *(int16_t *)(iVar2 + 0x1a10 + iVar9 * 2) = iVar3;
    return piVar6;
}

// ============================================================
// Function: FUN_180107d30
// Address: 0x180107d30
// Size: 126 bytes
// ============================================================
bool fcn.180107d30(int64_t arg1)
{
    char cVar1;
    int32_t iVar2;
    
    iVar2 = (int32_t)arg1;
    if ((arg1 & 0xf000U) != 0) {
        if (iVar2 == 0x1000) {
            iVar2 = 0x297;
        } else if (iVar2 == 0x2000) {
            iVar2 = 0x298;
        } else if (iVar2 == 0x4000) {
            iVar2 = 0x299;
        } else if (iVar2 == 0x8000) {
            iVar2 = 0x29a;
        }
    }
    if (*(char *)(*(int64_t *)0x180781f28 + ((int64_t)iVar2 + -0x1ec) * 0x10) == '\0') {
        return false;
    }
    cVar1 = func_0x000180109b10();
    return cVar1 != '\0';
}

// ============================================================
// Function: FUN_180107dc0
// Address: 0x180107dc0
// Size: 447 bytes
// ============================================================
bool fcn.180107dc0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    bool bVar1;
    char cVar2;
    uint32_t uVar3;
    int32_t iVar4;
    bool bVar5;
    uint64_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    float fVar10;
    double dVar11;
    float fVar12;
    float fVar13;
    
    uVar9 = arg3 & 0xffffffff;
    iVar4 = (int32_t)arg1;
    uVar8 = arg1 & 0xffffffff;
    if ((arg1 & 0xf000U) != 0) {
        if (iVar4 == 0x1000) {
            iVar4 = 0x297;
        } else if (iVar4 == 0x2000) {
            iVar4 = 0x298;
        } else if (iVar4 == 0x4000) {
            iVar4 = 0x299;
        } else if (iVar4 == 0x8000) {
            iVar4 = 0x29a;
        }
    }
    if (*(char *)(*(int64_t *)0x180781f28 + ((int64_t)iVar4 + -0x1ec) * 0x10) == '\0') {
        return false;
    }
    fVar13 = *(float *)(*(int64_t *)0x180781f28 + 4 + ((int64_t)iVar4 + -0x1ec) * 0x10);
    if (fVar13 < 0.0) {
        return false;
    }
    uVar6 = (uint64_t)((uint32_t)arg2 | 1);
    if ((arg2 & 0xfeU) == 0) {
        uVar6 = arg2 & 0xffffffff;
    }
    if (fVar13 == 0.0) goto code_r0x000180107f63;
    if ((uVar6 & 1) == 0) {
        return false;
    }
    uVar3 = (uint32_t)uVar6 & 0xe;
    if (uVar3 == 2) {
code_r0x000180107eca:
        fVar10 = *(float *)(*(int64_t *)0x180781f28 + 0xa8);
        fVar12 = *(float *)(*(int64_t *)0x180781f28 + 0xac);
    } else if (uVar3 == 4) {
        fVar10 = *(float *)(*(int64_t *)0x180781f28 + 0xa8) * 0.72;
        fVar12 = *(float *)(*(int64_t *)0x180781f28 + 0xac) * 0.8;
    } else {
        if (uVar3 != 8) goto code_r0x000180107eca;
        fVar10 = *(float *)(*(int64_t *)0x180781f28 + 0xa8) * 0.72;
        fVar12 = *(float *)(*(int64_t *)0x180781f28 + 0xac) * 0.3;
    }
    if ((fVar13 <= fVar10) ||
       (iVar7 = *(int64_t *)0x180781f28, iVar4 = func_0x0001801078b0(uVar8, fVar10, fVar12), iVar4 < 1)) {
        return false;
    }
    if ((uVar6 & 0xf0) != 0) {
        dVar11 = (*(double *)(iVar7 + 0x18) - (double)fVar13) + 9.999999747378752e-06;
        bVar1 = true;
        if ((uVar6 & 0x20) != 0) {
            bVar1 = true;
            if (dVar11 < *(double *)(iVar7 + 0x16a0)) {
                bVar1 = false;
            }
        }
        bVar5 = bVar1;
        if (((uVar6 & 0x40) != 0) && (bVar5 = false, *(double *)(iVar7 + 0x16a8) <= dVar11)) {
            bVar5 = bVar1;
        }
        if (((char)uVar6 < '\0') && (dVar11 < *(double *)(iVar7 + 0x16b0))) {
            return false;
        }
        if (!bVar5) {
            return false;
        }
    }
code_r0x000180107f63:
    cVar2 = func_0x000180109b10(uVar8 & 0xffffffff, uVar9 & 0xffffffff);
    return cVar2 != '\0';
}

// ============================================================
// Function: FUN_180107f80
// Address: 0x180107f80
// Size: 104 bytes
// ============================================================
undefined8 fcn.180107f80(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    
    iVar2 = (int32_t)arg1;
    if (*(char *)((int64_t)iVar2 + 0x120 + *(int64_t *)0x180781f28) == '\0') {
        return 0;
    }
    if (((((iVar2 + 0x90U < 0x9b) || (iVar2 == 0xd70)) || (iVar2 == 0x1d70)) || ((iVar2 == 0x3d70 || (iVar2 == 0x7d70)))
        ) && (iVar1 = func_0x0001800f45c0(*(int64_t *)0x180781f28), *(char *)(iVar1 + 8) != '\0')) {
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_180107ff0
// Address: 0x180107ff0
// Size: 125 bytes
// ============================================================
bool fcn.180107ff0(int64_t arg1)
{
    float fVar1;
    char cVar2;
    int32_t iVar3;
    int32_t iVar4;
    uint64_t in_RDX;
    undefined4 in_R8D;
    int64_t iVar5;
    
    iVar4 = (int32_t)arg1;
    iVar5 = (int64_t)iVar4;
    if ((*(char *)(iVar5 + 0x120 + *(int64_t *)0x180781f28) != '\0') &&
       (fVar1 = *(float *)(*(int64_t *)0x180781f28 + 0xbac + iVar5 * 4), 0.0 <= fVar1)) {
        if (fVar1 == 0.0) {
code_r0x00018010804d:
            cVar2 = func_0x000180109b10(iVar4 + 0x290, in_R8D);
            return cVar2 != '\0';
        }
        if (((in_RDX & 1) != 0) && (*(float *)(*(int64_t *)0x180781f28 + 0xa8) < fVar1)) {
            iVar3 = func_0x000180107850(fVar1 - *(float *)(*(int64_t *)0x180781f28 + 0x48), fVar1, 
                                        *(float *)(*(int64_t *)0x180781f28 + 0xa8), 
                                        *(undefined4 *)(*(int64_t *)0x180781f28 + 0xac));
            iVar4 = (int32_t)iVar5;
            if (0 < iVar3) goto code_r0x00018010804d;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_180108070
// Address: 0x180108070
// Size: 104 bytes
// ============================================================
undefined8 fcn.180108070(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    
    iVar2 = (int32_t)arg1;
    if (*(char *)((int64_t)iVar2 + 0xb6e + *(int64_t *)0x180781f28) == '\0') {
        return 0;
    }
    if (((((iVar2 + 0x90U < 0x9b) || (iVar2 == 0xd70)) || (iVar2 == 0x1d70)) || ((iVar2 == 0x3d70 || (iVar2 == 0x7d70)))
        ) && (iVar1 = func_0x0001800f45c0(*(int64_t *)0x180781f28), *(char *)(iVar1 + 8) != '\0')) {
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801080e0
// Address: 0x1801080e0
// Size: 51 bytes
// ============================================================
undefined fcn.1801080e0(void)
{
    int64_t iVar1;
    
    if (*(int16_t *)(*(int64_t *)0x180781f28 + 0xb5a) == 2) {
        iVar1 = fcn.1800f45c0(*(int64_t *)0x180781f28, 0x290);
        if (*(char *)(iVar1 + 8) == '\0') {
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180108120
// Address: 0x180108120
// Size: 265 bytes
// ============================================================
uint64_t fcn.180108120(int64_t arg1, int64_t arg2)
{
    uint64_t in_RAX;
    char in_R8B;
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    fVar3 = *(float *)arg1;
    fVar4 = *(float *)(arg1 + 4);
    fVar1 = *(float *)arg2;
    fVar2 = *(float *)(arg2 + 4);
    if (in_R8B != '\0') {
        in_RAX = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        if (fVar3 <= *(float *)(in_RAX + 0x2b8)) {
            fVar3 = *(float *)(in_RAX + 0x2b8);
        }
        if (fVar4 <= *(float *)(in_RAX + 700)) {
            fVar4 = *(float *)(in_RAX + 700);
        }
        if (*(float *)(in_RAX + 0x2c0) <= fVar1) {
            fVar1 = *(float *)(in_RAX + 0x2c0);
        }
        if (*(float *)(in_RAX + 0x2c4) <= fVar2) {
            fVar2 = *(float *)(in_RAX + 0x2c4);
        }
    }
    if (fVar3 - *(float *)(*(int64_t *)0x180781f28 + 0xe04) <= *(float *)(*(int64_t *)0x180781f28 + 0x118)) {
        if (((fVar4 - *(float *)(*(int64_t *)0x180781f28 + 0xe08) <= *(float *)(*(int64_t *)0x180781f28 + 0x11c)) &&
            (*(float *)(*(int64_t *)0x180781f28 + 0x118) < *(float *)(*(int64_t *)0x180781f28 + 0xe04) + fVar1)) &&
           (*(float *)(*(int64_t *)0x180781f28 + 0x11c) < *(float *)(*(int64_t *)0x180781f28 + 0xe08) + fVar2)) {
            in_RAX = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x2168);
            if (((fVar4 < *(float *)(in_RAX + 0xc) + *(float *)(in_RAX + 0x14)) && (*(float *)(in_RAX + 0xc) < fVar2))
               && ((fVar3 < *(float *)(in_RAX + 8) + *(float *)(in_RAX + 0x10) && (*(float *)(in_RAX + 8) < fVar1)))) {
                return CONCAT71((unkint7)(in_RAX >> 8), 1);
            }
        }
    }
    return in_RAX & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_180108270
// Address: 0x180108270
// Size: 1465 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180108270(int64_t arg1)
{
    int32_t *piVar1;
    int16_t *piVar2;
    undefined4 *puVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined4 uVar7;
    int64_t iVar8;
    char cVar9;
    undefined uVar10;
    int32_t iVar11;
    uint32_t uVar12;
    int32_t iVar13;
    uint32_t uVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int32_t iVar17;
    int64_t iVar18;
    int64_t iVar19;
    int64_t iVar20;
    int16_t iVar21;
    undefined4 uVar22;
    float fVar23;
    undefined4 uVar24;
    int64_t var_8h;
    
    iVar8 = *(int64_t *)0x180781f28;
    if ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x30) & 0x40) != 0) {
        func_0x0001800f52d0();
    }
    iVar18 = *(int64_t *)0x180781f28;
    cVar9 = *(char *)(iVar8 + 0x120);
    uVar22 = 0x3f800000;
    if (cVar9 == '\0') {
        uVar24 = 0;
    } else {
        uVar24 = 0x3f800000;
    }
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0xa4c) = uVar24;
    *(char *)(iVar18 + 0xa40) = cVar9;
    if (*(char *)(iVar8 + 0x121) == '\0') {
        uVar24 = 0;
    } else {
        uVar24 = 0x3f800000;
    }
    *(char *)(iVar18 + 0xa50) = *(char *)(iVar8 + 0x121);
    *(undefined4 *)(iVar18 + 0xa5c) = uVar24;
    if (*(char *)(iVar8 + 0x122) == '\0') {
        uVar24 = 0;
    } else {
        uVar24 = 0x3f800000;
    }
    *(char *)(iVar18 + 0xa60) = *(char *)(iVar8 + 0x122);
    *(undefined4 *)(iVar18 + 0xa6c) = uVar24;
    if (*(char *)(iVar8 + 0x123) == '\0') {
        uVar24 = 0;
    } else {
        uVar24 = 0x3f800000;
    }
    *(char *)(iVar18 + 0xa70) = *(char *)(iVar8 + 0x123);
    *(undefined4 *)(iVar18 + 0xa7c) = uVar24;
    if (*(char *)(iVar8 + 0x124) == '\0') {
        uVar22 = 0;
    }
    *(char *)(iVar18 + 0xa80) = *(char *)(iVar8 + 0x124);
    *(undefined4 *)(iVar18 + 0xa8c) = uVar22;
    fVar23 = *(float *)(iVar8 + 300);
    *(float *)(iVar18 + 0xa9c) = fVar23;
    *(bool *)(iVar18 + 0xa90) = fVar23 != 0.0;
    fVar23 = *(float *)(iVar8 + 0x128);
    *(bool *)(iVar18 + 0xaa0) = fVar23 != 0.0;
    *(float *)(iVar18 + 0xaac) = fVar23;
    uVar16 = *(uint32_t *)(iVar8 + 0x13c);
    uVar14 = -(uint32_t)(*(char *)(iVar18 + 0xab0) != '\0') & 0x1000;
    if (*(char *)(iVar18 + 0xac0) != '\0') {
        uVar14 = uVar14 | 0x2000;
    }
    uVar12 = uVar14 | 0x4000;
    if (*(char *)(iVar18 + 0xad0) == '\0') {
        uVar12 = uVar14;
    }
    uVar14 = uVar12 | 0x8000;
    if (*(char *)(iVar18 + 0xae0) == '\0') {
        uVar14 = uVar12;
    }
    *(uint32_t *)(iVar8 + 0x13c) = uVar14;
    *(uint8_t *)(iVar8 + 0x138) = (uint8_t)(uVar14 >> 0xc) & 1;
    *(uint8_t *)(iVar8 + 0x139) = (uint8_t)(uVar14 >> 0xd) & 1;
    *(uint8_t *)(iVar8 + 0x13a) = (uint8_t)(uVar14 >> 0xe) & 1;
    *(char *)(iVar8 + 0x13b) = (char)(uVar14 >> 0xf);
    if (uVar16 != uVar14) {
        *(undefined8 *)(iVar8 + 0x16a0) = *(undefined8 *)(iVar8 + 0x18);
    }
    if ((uVar16 != *(uint32_t *)(iVar8 + 0x13c)) && (uVar16 == 0)) {
        *(undefined8 *)(iVar8 + 0x16a8) = *(undefined8 *)(iVar8 + 0x18);
    }
    if ((*(uint8_t *)(iVar8 + 0x34) & 1) == 0) {
        *(undefined *)(iVar8 + 0x8c0) = 0;
        *(undefined4 *)(iVar8 + 0x8cc) = 0;
        *(undefined *)(iVar8 + 0x8d0) = 0;
        *(undefined4 *)(iVar8 + 0x8dc) = 0;
        *(undefined *)(iVar8 + 0x8e0) = 0;
        *(undefined4 *)(iVar8 + 0x8ec) = 0;
        *(undefined *)(iVar8 + 0x8f0) = 0;
        *(undefined4 *)(iVar8 + 0x8fc) = 0;
        *(undefined *)(iVar8 + 0x900) = 0;
        *(undefined4 *)(iVar8 + 0x90c) = 0;
        *(undefined *)(iVar8 + 0x910) = 0;
        *(undefined4 *)(iVar8 + 0x91c) = 0;
        *(undefined *)(iVar8 + 0x920) = 0;
        *(undefined4 *)(iVar8 + 0x92c) = 0;
        *(undefined *)(iVar8 + 0x930) = 0;
        *(undefined4 *)(iVar8 + 0x93c) = 0;
        *(undefined *)(iVar8 + 0x940) = 0;
        *(undefined4 *)(iVar8 + 0x94c) = 0;
        *(undefined *)(iVar8 + 0x950) = 0;
        *(undefined4 *)(iVar8 + 0x95c) = 0;
        *(undefined *)(iVar8 + 0x960) = 0;
        *(undefined4 *)(iVar8 + 0x96c) = 0;
        *(undefined *)(iVar8 + 0x970) = 0;
        *(undefined4 *)(iVar8 + 0x97c) = 0;
        *(undefined *)(iVar8 + 0x980) = 0;
        *(undefined4 *)(iVar8 + 0x98c) = 0;
        *(undefined *)(iVar8 + 0x990) = 0;
        *(undefined4 *)(iVar8 + 0x99c) = 0;
        *(undefined *)(iVar8 + 0x9a0) = 0;
        *(undefined4 *)(iVar8 + 0x9ac) = 0;
        *(undefined *)(iVar8 + 0x9b0) = 0;
        *(undefined4 *)(iVar8 + 0x9bc) = 0;
        *(undefined *)(iVar8 + 0x9c0) = 0;
        *(undefined4 *)(iVar8 + 0x9cc) = 0;
        *(undefined *)(iVar8 + 0x9d0) = 0;
        *(undefined4 *)(iVar8 + 0x9dc) = 0;
        *(undefined *)(iVar8 + 0x9e0) = 0;
        *(undefined4 *)(iVar8 + 0x9ec) = 0;
        *(undefined *)(iVar8 + 0x9f0) = 0;
        *(undefined4 *)(iVar8 + 0x9fc) = 0;
        *(undefined *)(iVar8 + 0xa00) = 0;
        *(undefined4 *)(iVar8 + 0xa0c) = 0;
        *(undefined *)(iVar8 + 0xa10) = 0;
        *(undefined4 *)(iVar8 + 0xa1c) = 0;
        *(undefined *)(iVar8 + 0xa20) = 0;
        *(undefined4 *)(iVar8 + 0xa2c) = 0;
        *(undefined *)(iVar8 + 0xa30) = 0;
        *(undefined4 *)(iVar8 + 0xa3c) = 0;
    }
    iVar18 = 0x200;
    uVar16 = 0x200;
    iVar20 = 0x200;
    do {
        fVar23 = *(float *)(iVar8 + -0x1ebc + iVar20 * 0x10);
        *(float *)(iVar8 + -0x1eb8 + iVar20 * 0x10) = fVar23;
        if (*(char *)(iVar8 + 0x30 + (iVar20 + -0x1ef) * 0x10) == '\0') {
            fVar23 = -1.0;
        } else if (0.0 <= fVar23) {
            fVar23 = fVar23 + *(float *)(iVar8 + 0x48);
        } else {
            fVar23 = 0.0;
        }
        *(float *)(iVar8 + 0x34 + (iVar20 + -0x1ef) * 0x10) = fVar23;
        if ((fVar23 == 0.0) && ((uVar16 < 0x278 || (uVar16 - 0x297 < 4)))) {
            *(undefined8 *)(iVar8 + 0x16b0) = *(undefined8 *)(iVar8 + 0x18);
        }
        cVar9 = *(char *)(iVar8 + 0x30 + (iVar20 + -0x1ee) * 0x10);
        fVar23 = *(float *)(iVar8 + -0x1ebc + (iVar20 + 1) * 0x10);
        *(float *)(iVar8 + -0x1eb8 + (iVar20 + 1) * 0x10) = fVar23;
        if (cVar9 == '\0') {
            fVar23 = -1.0;
        } else if (0.0 <= fVar23) {
            fVar23 = fVar23 + *(float *)(iVar8 + 0x48);
        } else {
            fVar23 = 0.0;
        }
        *(float *)(iVar8 + 0x34 + (iVar20 + -0x1ee) * 0x10) = fVar23;
        if ((fVar23 == 0.0) && ((uVar16 < 0x277 || (uVar16 - 0x296 < 4)))) {
            *(undefined8 *)(iVar8 + 0x16b0) = *(undefined8 *)(iVar8 + 0x18);
        }
        cVar9 = *(char *)(iVar8 + 0x30 + (iVar20 + -0x1ed) * 0x10);
        fVar23 = *(float *)(iVar8 + -0x1ebc + (iVar20 + 2) * 0x10);
        *(float *)(iVar8 + -0x1eb8 + (iVar20 + 2) * 0x10) = fVar23;
        if (cVar9 == '\0') {
            fVar23 = -1.0;
        } else if (0.0 <= fVar23) {
            fVar23 = fVar23 + *(float *)(iVar8 + 0x48);
        } else {
            fVar23 = 0.0;
        }
        *(float *)(iVar8 + 0x34 + (iVar20 + -0x1ed) * 0x10) = fVar23;
        if ((fVar23 == 0.0) && ((uVar16 < 0x276 || (uVar16 - 0x295 < 4)))) {
            *(undefined8 *)(iVar8 + 0x16b0) = *(undefined8 *)(iVar8 + 0x18);
        }
        cVar9 = *(char *)(iVar8 + 0x30 + (iVar20 + -0x1ec) * 0x10);
        fVar23 = *(float *)(iVar8 + -0x1ebc + (iVar20 + 3) * 0x10);
        *(float *)(iVar8 + -0x1eb8 + (iVar20 + 3) * 0x10) = fVar23;
        if (cVar9 == '\0') {
            fVar23 = -1.0;
        } else if (0.0 <= fVar23) {
            fVar23 = fVar23 + *(float *)(iVar8 + 0x48);
        } else {
            fVar23 = 0.0;
        }
        *(float *)(iVar8 + 0x34 + (iVar20 + -0x1ec) * 0x10) = fVar23;
        if ((fVar23 == 0.0) && ((uVar16 < 0x275 || (uVar16 - 0x294 < 4)))) {
            *(undefined8 *)(iVar8 + 0x16b0) = *(undefined8 *)(iVar8 + 0x18);
        }
        cVar9 = *(char *)(iVar8 + 0x30 + (iVar20 + -0x1eb) * 0x10);
        fVar23 = *(float *)(iVar8 + -0x1ebc + (iVar20 + 4) * 0x10);
        *(float *)(iVar8 + -0x1eb8 + (iVar20 + 4) * 0x10) = fVar23;
        if (cVar9 == '\0') {
            fVar23 = -1.0;
        } else if (0.0 <= fVar23) {
            fVar23 = fVar23 + *(float *)(iVar8 + 0x48);
        } else {
            fVar23 = 0.0;
        }
        *(float *)(iVar8 + 0x34 + (iVar20 + -0x1eb) * 0x10) = fVar23;
        if ((fVar23 == 0.0) && ((uVar16 < 0x274 || (uVar16 - 0x293 < 4)))) {
            *(undefined8 *)(iVar8 + 0x16b0) = *(undefined8 *)(iVar8 + 0x18);
        }
        uVar16 = uVar16 + 5;
        iVar20 = iVar20 + 5;
    } while ((int32_t)uVar16 < 0x29b);
    do {
        *(undefined4 *)(iVar8 + -0x134 + iVar18 * 0xc) = *(undefined4 *)(iVar8 + -0x130 + iVar18 * 0xc);
        cVar9 = *(char *)(iVar8 + 0x30 + (iVar18 + -0x1ef) * 0x10);
        if (cVar9 == '\0') {
            *(undefined4 *)(iVar8 + -0x130 + iVar18 * 0xc) = 0xffffffff;
            cVar9 = *(char *)(iVar8 + 0x30 + (iVar18 + -0x1ef) * 0x10);
        }
        if ((*(char *)(iVar8 + -299 + iVar18 * 0xc) == '\0') || (cVar9 == '\0')) {
            uVar10 = 0;
        } else {
            uVar10 = 1;
        }
        iVar19 = iVar18 + 1;
        *(undefined *)(iVar8 + -299 + iVar18 * 0xc) = uVar10;
        *(undefined *)(iVar8 + -300 + iVar18 * 0xc) = uVar10;
        iVar20 = *(int64_t *)0x180781f28;
        iVar18 = iVar19;
    } while (iVar19 != 0x29b);
    piVar1 = (int32_t *)(iVar8 + 0x1f58);
    iVar13 = *(int32_t *)(iVar8 + 0x1f5c);
    if (iVar13 < 0) {
        iVar13 = iVar13 + iVar13 / 2;
        iVar11 = 0;
        if (0 < iVar13) {
            iVar11 = iVar13;
        }
        func_0x00018011faa0(piVar1, iVar11);
    }
    *piVar1 = 0;
    uVar16 = 0x200;
    iVar13 = 0;
    do {
        piVar2 = (int16_t *)(iVar8 + 0x1a10 + (uint64_t)uVar16 * 2);
        iVar21 = *piVar2;
        while (iVar21 != -1) {
            iVar18 = *(int64_t *)(iVar8 + 0x1f50);
            iVar19 = (int64_t)(int32_t)iVar21;
            iVar11 = *(int32_t *)(iVar18 + 0xc + iVar19 * 0x10);
            *(undefined2 *)(iVar18 + 4 + iVar19 * 0x10) = *(undefined2 *)(iVar18 + 6 + iVar19 * 0x10);
            *(int32_t *)(iVar18 + 8 + iVar19 * 0x10) = iVar11;
            *(undefined4 *)(iVar18 + 0xc + iVar19 * 0x10) = 0xffffffff;
            *(undefined2 *)(iVar18 + 6 + iVar19 * 0x10) = 0;
            if (iVar11 != -1) {
                iVar11 = *(int32_t *)(iVar8 + 0x1f5c);
                if (*piVar1 == iVar11) {
                    iVar15 = *piVar1 + 1;
                    if (iVar11 == 0) {
                        iVar11 = 8;
                    } else {
                        iVar11 = iVar11 / 2 + iVar11;
                    }
                    if (iVar15 < iVar11) {
                        iVar15 = iVar11;
                    }
                    func_0x00018011faa0(piVar1, iVar15);
                }
                puVar3 = (undefined4 *)(iVar18 + iVar19 * 0x10);
                uVar22 = puVar3[1];
                uVar24 = puVar3[2];
                uVar7 = puVar3[3];
                puVar4 = (undefined4 *)(*(int64_t *)(iVar8 + 0x1f60) + (int64_t)*piVar1 * 0x10);
                *puVar4 = *puVar3;
                puVar4[1] = uVar22;
                puVar4[2] = uVar24;
                puVar4[3] = uVar7;
                *piVar1 = *piVar1 + 1;
                if (((uint32_t)*(uint16_t *)(iVar18 + 2 + iVar19 * 0x10) == *(uint32_t *)(iVar20 + 0x13c)) &&
                   (iVar5 = iVar20 + (uint64_t)uVar16 * 0xc, *(int32_t *)(iVar5 + -0x134) == -1)) {
                    *(undefined4 *)(iVar5 + -0x134) = *(undefined4 *)(iVar18 + 8 + iVar19 * 0x10);
                }
            }
            iVar21 = *(int16_t *)(iVar18 + iVar19 * 0x10);
        }
        iVar21 = -1;
        if (iVar13 < *piVar1) {
            iVar21 = (int16_t)iVar13;
        }
        *piVar2 = iVar21;
        iVar11 = *piVar1;
        if (iVar13 < iVar11) {
            do {
                iVar17 = iVar13 + 1;
                iVar15 = -1;
                if (iVar17 < iVar11) {
                    iVar15 = iVar17;
                }
                *(int16_t *)(*(int64_t *)(iVar8 + 0x1f60) + (int64_t)iVar13 * 0x10) = (int16_t)iVar15;
                iVar11 = *piVar1;
                iVar13 = iVar17;
            } while (iVar17 < iVar11);
        }
        iVar13 = iVar11;
        uVar16 = uVar16 + 1;
    } while ((int32_t)uVar16 < 0x29b);
    *piVar1 = *(int32_t *)(iVar8 + 0x1f48);
    uVar22 = *(undefined4 *)(iVar8 + 0x1f5c);
    *(undefined4 *)(iVar8 + 0x1f5c) = *(undefined4 *)(iVar8 + 0x1f4c);
    *(undefined4 *)(iVar8 + 0x1f4c) = uVar22;
    uVar6 = *(undefined8 *)(iVar8 + 0x1f60);
    *(undefined8 *)(iVar8 + 0x1f60) = *(undefined8 *)(iVar8 + 0x1f50);
    *(undefined8 *)(iVar8 + 0x1f50) = uVar6;
    *(int32_t *)(iVar8 + 0x1f48) = iVar13;
    return;
}

// ============================================================
// Function: FUN_180108830
// Address: 0x180108830
// Size: 1092 bytes
// ============================================================
void fcn.180108830(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 *puVar1;
    float *pfVar2;
    int64_t iVar3;
    int16_t *piVar4;
    int64_t iVar5;
    undefined uVar6;
    int32_t iVar7;
    int32_t iVar8;
    float *pfVar9;
    int64_t iVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar5 = *(int64_t *)0x180781f28;
    if ((*(char *)(*(int64_t *)0x180781f28 + 0x139) == '\0') || (*(char *)(*(int64_t *)0x180781f28 + 0x8d) != '\0')) {
        uVar6 = 0;
    } else {
        uVar6 = 1;
    }
    puVar1 = (undefined8 *)(*(int64_t *)0x180781f28 + 0x118);
    *(undefined *)(*(int64_t *)0x180781f28 + 0xbaa) = uVar6;
    if ((-256000.0 <= *(float *)(iVar5 + 0x118)) && (-256000.0 <= *(float *)(iVar5 + 0x11c))) {
        fVar12 = *(float *)(iVar5 + 0x11c);
        iVar8 = (int32_t)fVar12;
        if ((fVar12 < 0.0) && ((float)iVar8 != fVar12)) {
            iVar8 = iVar8 + -1;
        }
        fVar12 = *(float *)puVar1;
        iVar7 = (int32_t)fVar12;
        if ((fVar12 < 0.0) && ((float)iVar7 != fVar12)) {
            iVar7 = iVar7 + -1;
        }
        *(float *)(iVar5 + 0x2658) = (float)iVar7;
        *(float *)(iVar5 + 0x265c) = (float)iVar8;
        *(float *)puVar1 = (float)iVar7;
        *(float *)(iVar5 + 0x11c) = (float)iVar8;
    }
    if ((-256000.0 <= *(float *)(iVar5 + 0x118)) && (-256000.0 <= *(float *)(iVar5 + 0x11c))) {
        pfVar2 = (float *)(iVar5 + 0xaf4);
        pfVar9 = pfVar2;
        if (pfVar2 == (float *)0x0) {
            pfVar9 = (float *)(iVar5 + 0x118);
        }
        if ((-256000.0 <= *pfVar9) && (-256000.0 <= pfVar9[1])) {
            fVar11 = *(float *)puVar1 - *pfVar2;
            fVar12 = *(float *)(iVar5 + 0x11c) - *(float *)(iVar5 + 0xaf8);
            goto code_r0x000180108963;
        }
    }
    fVar11 = 0.0;
    fVar12 = 0.0;
code_r0x000180108963:
    *(float *)(iVar5 + 0x104) = fVar11;
    *(float *)(iVar5 + 0x108) = fVar12;
    if (*(int32_t *)(iVar5 + 0x130) == 0) {
        fVar14 = 2.0;
    } else {
        fVar14 = 3.0;
    }
    if (fVar14 * fVar14 < fVar11 * fVar11 + fVar12 * fVar12) {
        fVar12 = 0.0;
    } else {
        fVar12 = *(float *)(iVar5 + 0x48) + *(float *)(iVar5 + 0x2654);
    }
    *(float *)(iVar5 + 0x2654) = fVar12;
    if ((*(float *)(iVar5 + 0x104) != 0.0) || (*(float *)(iVar5 + 0x108) != 0.0)) {
        *(undefined *)(iVar5 + 0x21cd) = 0;
    }
    iVar10 = 0;
    do {
        if ((*(char *)(iVar5 + 0x120 + iVar10) == '\0') ||
           (pfVar2 = (float *)(iVar5 + 0xbac + iVar10 * 4), 0.0 < *pfVar2 || *pfVar2 == 0.0)) {
            uVar6 = 0;
        } else {
            uVar6 = 1;
        }
        *(undefined *)(iVar5 + 0xb50 + iVar10) = uVar6;
        iVar3 = iVar10 * 4 + 0xb7c;
        *(undefined2 *)(iVar5 + 0xb5a + iVar10 * 2) = 0;
        if ((*(char *)(iVar5 + 0x120 + iVar10) != '\0') || (*(float *)(iVar10 * 4 + 0xbac + iVar5) < 0.0)) {
            *(undefined *)(iVar5 + 0xb6e + iVar10) = 0;
        } else {
            *(undefined *)(iVar5 + 0xb6e + iVar10) = 1;
            *(undefined8 *)(iVar5 + 0xb78 + iVar10 * 8) = *(undefined8 *)(iVar5 + 0x18);
        }
        fVar12 = *(float *)(iVar5 + 0x30 + iVar3);
        *(float *)(iVar5 + 0xbc0 + iVar10 * 4) = fVar12;
        if (*(char *)(iVar5 + 0x120 + iVar10) == '\0') {
            fVar12 = -1.0;
        } else if (0.0 <= fVar12) {
            fVar12 = fVar12 + *(float *)(iVar5 + 0x48);
        } else {
            fVar12 = 0.0;
        }
        *(float *)(iVar5 + 0x30 + iVar3) = fVar12;
        if (*(char *)(iVar5 + 0xb50 + iVar10) == '\0') {
            if (*(char *)(iVar5 + 0x120 + iVar10) != '\0') {
                if ((*(float *)(iVar5 + 0x118) < -256000.0) || (*(float *)(iVar5 + 0x11c) < -256000.0)) {
                    fVar12 = 0.0;
                    fVar11 = 0.0;
                } else {
                    fVar12 = *(float *)puVar1 - *(float *)(iVar5 + 0xafc + iVar10 * 8);
                    fVar11 = *(float *)(iVar5 + 0x11c) - *(float *)(iVar5 + 0xb00 + iVar10 * 8);
                }
                fVar13 = fVar11 * fVar11 + fVar12 * fVar12;
                fVar14 = *(float *)(iVar5 + 0xbfc + iVar10 * 4);
                if (fVar14 <= fVar13) {
                    fVar14 = fVar13;
                }
                *(float *)(iVar5 + 0xbfc + iVar10 * 4) = fVar14;
                fVar14 = *(float *)(iVar5 + 0xbd4 + iVar10 * 8);
                if (fVar14 <= (float)((uint32_t)fVar12 & 0x7fffffff)) {
                    fVar14 = (float)((uint32_t)fVar12 & 0x7fffffff);
                }
                *(float *)(iVar5 + 0xbd4 + iVar10 * 8) = fVar14;
                fVar12 = *(float *)(iVar5 + 0xbd8 + iVar10 * 8);
                if (fVar12 <= (float)((uint32_t)fVar11 & 0x7fffffff)) {
                    fVar12 = (float)((uint32_t)fVar11 & 0x7fffffff);
                }
                *(float *)(iVar5 + 0xbd8 + iVar10 * 8) = fVar12;
            }
        } else {
            if (*(float *)(iVar5 + 0x9c) <= (float)(*(double *)(iVar5 + 0x18) - *(double *)(iVar5 + 0xb28 + iVar10 * 8))
               ) {
code_r0x000180108b3b:
                *(undefined2 *)(iVar5 + 0xb64 + iVar10 * 2) = 1;
            } else {
                if ((*(float *)(iVar5 + 0x118) < -256000.0) || (*(float *)(iVar5 + 0x11c) < -256000.0)) {
                    fVar11 = 0.0;
                    fVar12 = 0.0;
                } else {
                    fVar11 = *(float *)(iVar5 + 0x118) - *(float *)(iVar5 + 0xafc + iVar10 * 8);
                    fVar12 = *(float *)(iVar5 + 0x11c) - *(float *)(iVar5 + 0xb00 + iVar10 * 8);
                }
                if (*(float *)(iVar5 + 0xa0) * *(float *)(iVar5 + 0xa0) <= fVar12 * fVar12 + fVar11 * fVar11)
                goto code_r0x000180108b3b;
                piVar4 = (int16_t *)(iVar5 + 0xb64 + iVar10 * 2);
                *piVar4 = *piVar4 + 1;
            }
            *(undefined8 *)(iVar5 + 0xb28 + iVar10 * 8) = *(undefined8 *)(iVar5 + 0x18);
            *(undefined8 *)(iVar5 + 0xafc + iVar10 * 8) = *puVar1;
            *(undefined2 *)(iVar5 + 0xb5a + iVar10 * 2) = *(undefined2 *)(iVar5 + 0xb64 + iVar10 * 2);
            *(undefined8 *)(iVar5 + 0xbd4 + iVar10 * 8) = 0;
            *(undefined4 *)(iVar5 + 0xbfc + iVar10 * 4) = 0;
        }
        *(bool *)(iVar5 + 0xb55 + iVar10) = *(int16_t *)(iVar5 + 0xb5a + iVar10 * 2) == 2;
        if (*(char *)(iVar5 + 0xb50 + iVar10) != '\0') {
            *(undefined *)(iVar5 + 0x21cd) = 0;
        }
        iVar10 = iVar10 + 1;
        if (iVar10 == 5) {
            return;
        }
    } while( true );
}

// ============================================================
// Function: FUN_180108de0
// Address: 0x180108de0
// Size: 310 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9h

void fcn.180108de0(void)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    int64_t var_8h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1608);
    if (iVar1 != 0) {
        fVar7 = *(float *)(*(int64_t *)0x180781f28 + 0x1620) - *(float *)(*(int64_t *)0x180781f28 + 0x48);
        *(float *)(*(int64_t *)0x180781f28 + 0x1620) = fVar7;
        if ((((-256000.0 <= *(float *)(iVar3 + 0x118)) && (-256000.0 <= *(float *)(iVar3 + 0x11c))) &&
            (fVar6 = *(float *)(iVar3 + 0x11c) - *(float *)(iVar3 + 0x1614),
            fVar5 = *(float *)(iVar3 + 0x118) - *(float *)(iVar3 + 0x1610),
            *(float *)(iVar3 + 0xa4) * *(float *)(iVar3 + 0xa4) < fVar6 * fVar6 + fVar5 * fVar5)) || (fVar7 <= 0.0)) {
            iVar1 = 0;
            *(undefined8 *)(iVar3 + 0x1610) = *(undefined8 *)(iVar3 + 0x118);
            *(undefined4 *)(iVar3 + 0x1620) = 0;
            *(undefined8 *)(iVar3 + 0x1608) = 0;
            *(undefined4 *)(iVar3 + 0x1618) = 0xffffffff;
            *(undefined8 *)(iVar3 + 0x162c) = 0;
        }
    }
    if (*(int32_t *)(iVar3 + 0x1dc8) == -1) {
        fVar7 = *(float *)(iVar3 + 300);
    } else {
        fVar7 = 0.0;
    }
    if (*(int32_t *)(iVar3 + 0x1dd4) == -1) {
        fVar5 = *(float *)(iVar3 + 0x128);
    } else {
        fVar5 = 0.0;
    }
    iVar2 = iVar1;
    if ((iVar1 == 0) && (iVar2 = *(int64_t *)(iVar3 + 0x15e8), *(int64_t *)(iVar3 + 0x15e8) == 0)) {
        return;
    }
    if (*(char *)(iVar2 + 0x10c) != '\0') {
        return;
    }
    if (fVar5 != 0.0) {
        if (*(char *)(iVar3 + 0x138) == '\0') goto code_r0x000180109101;
        if (*(char *)(iVar3 + 0x78) != '\0') {
            fVar7 = (float)((uint32_t)fVar5 & 0x7fffffff) * 0.7 + *(float *)(iVar3 + 0x1620);
            if (0.7 <= fVar7) {
                fVar7 = 0.7;
            }
            *(float *)(iVar3 + 0x1620) = fVar7;
            if (iVar1 != iVar2) {
                *(undefined8 *)(iVar3 + 0x1610) = *(undefined8 *)(iVar3 + 0x118);
                *(int64_t *)(iVar3 + 0x1608) = iVar2;
            }
            fVar7 = *(float *)(iVar2 + 0x310);
            fVar6 = *(float *)(iVar3 + 0x128) * 0.1 + fVar7;
            fVar5 = 0.5;
            if ((0.5 <= fVar6) && (fVar5 = 2.5, fVar6 <= 2.5)) {
                fVar5 = fVar6;
            }
            *(float *)(iVar2 + 0x310) = fVar5;
            if (iVar2 != *(int64_t *)(iVar2 + 0x418)) {
                return;
            }
            fVar5 = fVar5 / fVar7;
            var_8h._0_4_ = (*(float *)(iVar2 + 0x68) * (1.0 - fVar5) *
                           (*(float *)(iVar3 + 0x118) - *(float *)(iVar2 + 0x60))) / *(float *)(iVar2 + 0x68) +
                           *(float *)(iVar2 + 0x60);
            var_8h._4_4_ = ((*(float *)(iVar3 + 0x11c) - *(float *)(iVar2 + 100)) *
                           *(float *)(iVar2 + 0x6c) * (1.0 - fVar5)) / *(float *)(iVar2 + 0x6c) +
                           *(float *)(iVar2 + 100);
            func_0x000180106470(iVar2, &var_8h, 0);
            *(float *)(iVar2 + 0x68) = (float)(int32_t)(fVar5 * *(float *)(iVar2 + 0x68));
            *(float *)(iVar2 + 0x6c) = (float)(int32_t)(fVar5 * *(float *)(iVar2 + 0x6c));
            *(float *)(iVar2 + 0x70) = (float)(int32_t)(fVar5 * *(float *)(iVar2 + 0x70));
            *(float *)(iVar2 + 0x74) = (float)(int32_t)(fVar5 * *(float *)(iVar2 + 0x74));
            if ((*(uint32_t *)(iVar2 + 0x14) & 0x100) != 0) {
                return;
            }
            if (0.0 < *(float *)(iVar3 + 0x292c)) {
                return;
            }
            *(undefined4 *)(iVar3 + 0x292c) = *(undefined4 *)(iVar3 + 0x4c);
            return;
        }
    }
    if (*(char *)(iVar3 + 0x138) != '\0') {
        return;
    }
code_r0x000180109101:
    fVar6 = fVar5;
    if (*(char *)(iVar3 + 0xbaa) != '\0') {
        fVar6 = 0.0;
        fVar7 = fVar5;
    }
    *(float *)(iVar3 + 0x162c) =
         (float)((uint32_t)fVar7 & 0x7fffffff) / 30.0 + (*(float *)(iVar3 + 0x162c) - *(float *)(iVar3 + 0x162c) / 30.0)
    ;
    *(float *)(iVar3 + 0x1630) =
         (float)((uint32_t)fVar6 & 0x7fffffff) / 30.0 + (*(float *)(iVar3 + 0x1630) - *(float *)(iVar3 + 0x1630) / 30.0)
    ;
    fVar7 = fVar7 + *(float *)(iVar3 + 0x1624);
    fVar6 = fVar6 + *(float *)(iVar3 + 0x1628);
    *(undefined8 *)(iVar3 + 0x1624) = 0;
    if ((((fVar7 != 0.0) || (fVar6 != 0.0)) &&
        ((iVar1 != 0 || (var_8h._0_4_ = fVar7, var_8h._4_4_ = fVar6, iVar1 = func_0x000180108c80(&var_8h), iVar1 != 0)))
        ) && ((*(uint32_t *)(iVar1 + 0x14) & 0x210) == 0)) {
        if ((fVar7 == 0.0) || (*(float *)(iVar1 + 0xdc) == 0.0)) {
            var_8h._0_1_ = '\0';
        } else {
            var_8h._0_1_ = '\x01';
        }
        if ((fVar6 == 0.0) || (*(float *)(iVar1 + 0xe0) == 0.0)) {
            var_8h._1_1_ = 0;
        } else {
            var_8h._1_1_ = 1;
        }
        if ((char)var_8h != '\0') {
            if (var_8h._1_1_ != 0) {
                var_8h._0_2_ = (uint16_t)var_8h._1_1_;
                *(undefined *)
                 ((int64_t)&var_8h +
                 (uint64_t)
                 (*(float *)(iVar3 + 0x1630) <= *(float *)(iVar3 + 0x162c) &&
                 *(float *)(iVar3 + 0x162c) != *(float *)(iVar3 + 0x1630))) = 0;
            }
            if ((char)var_8h != '\0') {
                fVar5 = (float)((uint32_t)fVar7 & 0x7fffffff) * 0.7 + *(float *)(iVar3 + 0x1620);
                if (0.7 <= fVar5) {
                    fVar5 = 0.7;
                }
                *(float *)(iVar3 + 0x1620) = fVar5;
                if (*(int64_t *)(iVar3 + 0x1608) != iVar1) {
                    *(undefined8 *)(iVar3 + 0x1610) = *(undefined8 *)(iVar3 + 0x118);
                    *(int64_t *)(iVar3 + 0x1608) = iVar1;
                }
                fVar5 = *(float *)(iVar1 + 0x318) + *(float *)(iVar1 + 0x318);
                *(undefined4 *)(iVar1 + 0xec) = 0;
                *(undefined4 *)(iVar1 + 0xf4) = 0;
                fVar4 = (*(float *)(iVar1 + 0x280) - *(float *)(iVar1 + 0x278)) * 0.67;
                if (fVar4 <= fVar5) {
                    fVar5 = fVar4;
                }
                *(float *)(iVar1 + 0xe4) = *(float *)(iVar1 + 0xd4) - (float)(int32_t)fVar5 * fVar7;
                *(undefined4 *)(iVar3 + 0x161c) = *(undefined4 *)(iVar3 + 4);
            }
        }
        if (var_8h._1_1_ != 0) {
            fVar7 = (float)((uint32_t)fVar6 & 0x7fffffff) * 0.7 + *(float *)(iVar3 + 0x1620);
            if (0.7 <= fVar7) {
                fVar7 = 0.7;
            }
            *(float *)(iVar3 + 0x1620) = fVar7;
            if (*(int64_t *)(iVar3 + 0x1608) != iVar1) {
                *(undefined8 *)(iVar3 + 0x1610) = *(undefined8 *)(iVar3 + 0x118);
                *(int64_t *)(iVar3 + 0x1608) = iVar1;
            }
            fVar7 = *(float *)(iVar1 + 0x318) * 5.0;
            *(undefined4 *)(iVar1 + 0xf0) = 0;
            fVar5 = (*(float *)(iVar1 + 0x284) - *(float *)(iVar1 + 0x27c)) * 0.67;
            *(undefined4 *)(iVar1 + 0xf8) = 0;
            if (fVar5 <= fVar7) {
                fVar7 = fVar5;
            }
            *(float *)(iVar1 + 0xe8) = *(float *)(iVar1 + 0xd8) - (float)(int32_t)fVar7 * fVar6;
            *(undefined4 *)(iVar3 + 0x161c) = *(undefined4 *)(iVar3 + 4);
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180108f16
// Address: 0x180108f16
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9h

void fcn.180108de0(void)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    int64_t var_8h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1608);
    if (iVar1 != 0) {
        fVar7 = *(float *)(*(int64_t *)0x180781f28 + 0x1620) - *(float *)(*(int64_t *)0x180781f28 + 0x48);
        *(float *)(*(int64_t *)0x180781f28 + 0x1620) = fVar7;
        if ((((-256000.0 <= *(float *)(iVar3 + 0x118)) && (-256000.0 <= *(float *)(iVar3 + 0x11c))) &&
            (fVar6 = *(float *)(iVar3 + 0x11c) - *(float *)(iVar3 + 0x1614),
            fVar5 = *(float *)(iVar3 + 0x118) - *(float *)(iVar3 + 0x1610),
            *(float *)(iVar3 + 0xa4) * *(float *)(iVar3 + 0xa4) < fVar6 * fVar6 + fVar5 * fVar5)) || (fVar7 <= 0.0)) {
            iVar1 = 0;
            *(undefined8 *)(iVar3 + 0x1610) = *(undefined8 *)(iVar3 + 0x118);
            *(undefined4 *)(iVar3 + 0x1620) = 0;
            *(undefined8 *)(iVar3 + 0x1608) = 0;
            *(undefined4 *)(iVar3 + 0x1618) = 0xffffffff;
            *(undefined8 *)(iVar3 + 0x162c) = 0;
        }
    }
    if (*(int32_t *)(iVar3 + 0x1dc8) == -1) {
        fVar7 = *(float *)(iVar3 + 300);
    } else {
        fVar7 = 0.0;
    }
    if (*(int32_t *)(iVar3 + 0x1dd4) == -1) {
        fVar5 = *(float *)(iVar3 + 0x128);
    } else {
        fVar5 = 0.0;
    }
    iVar2 = iVar1;
    if ((iVar1 == 0) && (iVar2 = *(int64_t *)(iVar3 + 0x15e8), *(int64_t *)(iVar3 + 0x15e8) == 0)) {
        return;
    }
    if (*(char *)(iVar2 + 0x10c) != '\0') {
        return;
    }
    if (fVar5 != 0.0) {
        if (*(char *)(iVar3 + 0x138) == '\0') goto code_r0x000180109101;
        if (*(char *)(iVar3 + 0x78) != '\0') {
            fVar7 = (float)((uint32_t)fVar5 & 0x7fffffff) * 0.7 + *(float *)(iVar3 + 0x1620);
            if (0.7 <= fVar7) {
                fVar7 = 0.7;
            }
            *(float *)(iVar3 + 0x1620) = fVar7;
            if (iVar1 != iVar2) {
                *(undefined8 *)(iVar3 + 0x1610) = *(undefined8 *)(iVar3 + 0x118);
                *(int64_t *)(iVar3 + 0x1608) = iVar2;
            }
            fVar7 = *(float *)(iVar2 + 0x310);
            fVar6 = *(float *)(iVar3 + 0x128) * 0.1 + fVar7;
            fVar5 = 0.5;
            if ((0.5 <= fVar6) && (fVar5 = 2.5, fVar6 <= 2.5)) {
                fVar5 = fVar6;
            }
            *(float *)(iVar2 + 0x310) = fVar5;
            if (iVar2 != *(int64_t *)(iVar2 + 0x418)) {
                return;
            }
            fVar5 = fVar5 / fVar7;
            var_8h._0_4_ = (*(float *)(iVar2 + 0x68) * (1.0 - fVar5) *
                           (*(float *)(iVar3 + 0x118) - *(float *)(iVar2 + 0x60))) / *(float *)(iVar2 + 0x68) +
                           *(float *)(iVar2 + 0x60);
            var_8h._4_4_ = ((*(float *)(iVar3 + 0x11c) - *(float *)(iVar2 + 100)) *
                           *(float *)(iVar2 + 0x6c) * (1.0 - fVar5)) / *(float *)(iVar2 + 0x6c) +
                           *(float *)(iVar2 + 100);
            func_0x000180106470(iVar2, &var_8h, 0);
            *(float *)(iVar2 + 0x68) = (float)(int32_t)(fVar5 * *(float *)(iVar2 + 0x68));
            *(float *)(iVar2 + 0x6c) = (float)(int32_t)(fVar5 * *(float *)(iVar2 + 0x6c));
            *(float *)(iVar2 + 0x70) = (float)(int32_t)(fVar5 * *(float *)(iVar2 + 0x70));
            *(float *)(iVar2 + 0x74) = (float)(int32_t)(fVar5 * *(float *)(iVar2 + 0x74));
            if ((*(uint32_t *)(iVar2 + 0x14) & 0x100) != 0) {
                return;
            }
            if (0.0 < *(float *)(iVar3 + 0x292c)) {
                return;
            }
            *(undefined4 *)(iVar3 + 0x292c) = *(undefined4 *)(iVar3 + 0x4c);
            return;
        }
    }
    if (*(char *)(iVar3 + 0x138) != '\0') {
        return;
    }
code_r0x000180109101:
    fVar6 = fVar5;
    if (*(char *)(iVar3 + 0xbaa) != '\0') {
        fVar6 = 0.0;
        fVar7 = fVar5;
    }
    *(float *)(iVar3 + 0x162c) =
         (float)((uint32_t)fVar7 & 0x7fffffff) / 30.0 + (*(float *)(iVar3 + 0x162c) - *(float *)(iVar3 + 0x162c) / 30.0)
    ;
    *(float *)(iVar3 + 0x1630) =
         (float)((uint32_t)fVar6 & 0x7fffffff) / 30.0 + (*(float *)(iVar3 + 0x1630) - *(float *)(iVar3 + 0x1630) / 30.0)
    ;
    fVar7 = fVar7 + *(float *)(iVar3 + 0x1624);
    fVar6 = fVar6 + *(float *)(iVar3 + 0x1628);
    *(undefined8 *)(iVar3 + 0x1624) = 0;
    if ((((fVar7 != 0.0) || (fVar6 != 0.0)) &&
        ((iVar1 != 0 || (var_8h._0_4_ = fVar7, var_8h._4_4_ = fVar6, iVar1 = func_0x000180108c80(&var_8h), iVar1 != 0)))
        ) && ((*(uint32_t *)(iVar1 + 0x14) & 0x210) == 0)) {
        if ((fVar7 == 0.0) || (*(float *)(iVar1 + 0xdc) == 0.0)) {
            var_8h._0_1_ = '\0';
        } else {
            var_8h._0_1_ = '\x01';
        }
        if ((fVar6 == 0.0) || (*(float *)(iVar1 + 0xe0) == 0.0)) {
            var_8h._1_1_ = 0;
        } else {
            var_8h._1_1_ = 1;
        }
        if ((char)var_8h != '\0') {
            if (var_8h._1_1_ != 0) {
                var_8h._0_2_ = (uint16_t)var_8h._1_1_;
                *(undefined *)
                 ((int64_t)&var_8h +
                 (uint64_t)
                 (*(float *)(iVar3 + 0x1630) <= *(float *)(iVar3 + 0x162c) &&
                 *(float *)(iVar3 + 0x162c) != *(float *)(iVar3 + 0x1630))) = 0;
            }
            if ((char)var_8h != '\0') {
                fVar5 = (float)((uint32_t)fVar7 & 0x7fffffff) * 0.7 + *(float *)(iVar3 + 0x1620);
                if (0.7 <= fVar5) {
                    fVar5 = 0.7;
                }
                *(float *)(iVar3 + 0x1620) = fVar5;
                if (*(int64_t *)(iVar3 + 0x1608) != iVar1) {
                    *(undefined8 *)(iVar3 + 0x1610) = *(undefined8 *)(iVar3 + 0x118);
                    *(int64_t *)(iVar3 + 0x1608) = iVar1;
                }
                fVar5 = *(float *)(iVar1 + 0x318) + *(float *)(iVar1 + 0x318);
                *(undefined4 *)(iVar1 + 0xec) = 0;
                *(undefined4 *)(iVar1 + 0xf4) = 0;
                fVar4 = (*(float *)(iVar1 + 0x280) - *(float *)(iVar1 + 0x278)) * 0.67;
                if (fVar4 <= fVar5) {
                    fVar5 = fVar4;
                }
                *(float *)(iVar1 + 0xe4) = *(float *)(iVar1 + 0xd4) - (float)(int32_t)fVar5 * fVar7;
                *(undefined4 *)(iVar3 + 0x161c) = *(undefined4 *)(iVar3 + 4);
            }
        }
        if (var_8h._1_1_ != 0) {
            fVar7 = (float)((uint32_t)fVar6 & 0x7fffffff) * 0.7 + *(float *)(iVar3 + 0x1620);
            if (0.7 <= fVar7) {
                fVar7 = 0.7;
            }
            *(float *)(iVar3 + 0x1620) = fVar7;
            if (*(int64_t *)(iVar3 + 0x1608) != iVar1) {
                *(undefined8 *)(iVar3 + 0x1610) = *(undefined8 *)(iVar3 + 0x118);
                *(int64_t *)(iVar3 + 0x1608) = iVar1;
            }
            fVar7 = *(float *)(iVar1 + 0x318) * 5.0;
            *(undefined4 *)(iVar1 + 0xf0) = 0;
            fVar5 = (*(float *)(iVar1 + 0x284) - *(float *)(iVar1 + 0x27c)) * 0.67;
            *(undefined4 *)(iVar1 + 0xf8) = 0;
            if (fVar5 <= fVar7) {
                fVar7 = fVar5;
            }
            *(float *)(iVar1 + 0xe8) = *(float *)(iVar1 + 0xd8) - (float)(int32_t)fVar7 * fVar6;
            *(undefined4 *)(iVar3 + 0x161c) = *(undefined4 *)(iVar3 + 4);
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180108f49
// Address: 0x180108f49
// Size: 415 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9h

void fcn.180108de0(void)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    int64_t var_8h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1608);
    if (iVar1 != 0) {
        fVar7 = *(float *)(*(int64_t *)0x180781f28 + 0x1620) - *(float *)(*(int64_t *)0x180781f28 + 0x48);
        *(float *)(*(int64_t *)0x180781f28 + 0x1620) = fVar7;
        if ((((-256000.0 <= *(float *)(iVar3 + 0x118)) && (-256000.0 <= *(float *)(iVar3 + 0x11c))) &&
            (fVar6 = *(float *)(iVar3 + 0x11c) - *(float *)(iVar3 + 0x1614),
            fVar5 = *(float *)(iVar3 + 0x118) - *(float *)(iVar3 + 0x1610),
            *(float *)(iVar3 + 0xa4) * *(float *)(iVar3 + 0xa4) < fVar6 * fVar6 + fVar5 * fVar5)) || (fVar7 <= 0.0)) {
            iVar1 = 0;
            *(undefined8 *)(iVar3 + 0x1610) = *(undefined8 *)(iVar3 + 0x118);
            *(undefined4 *)(iVar3 + 0x1620) = 0;
            *(undefined8 *)(iVar3 + 0x1608) = 0;
            *(undefined4 *)(iVar3 + 0x1618) = 0xffffffff;
            *(undefined8 *)(iVar3 + 0x162c) = 0;
        }
    }
    if (*(int32_t *)(iVar3 + 0x1dc8) == -1) {
        fVar7 = *(float *)(iVar3 + 300);
    } else {
        fVar7 = 0.0;
    }
    if (*(int32_t *)(iVar3 + 0x1dd4) == -1) {
        fVar5 = *(float *)(iVar3 + 0x128);
    } else {
        fVar5 = 0.0;
    }
    iVar2 = iVar1;
    if ((iVar1 == 0) && (iVar2 = *(int64_t *)(iVar3 + 0x15e8), *(int64_t *)(iVar3 + 0x15e8) == 0)) {
        return;
    }
    if (*(char *)(iVar2 + 0x10c) != '\0') {
        return;
    }
    if (fVar5 != 0.0) {
        if (*(char *)(iVar3 + 0x138) == '\0') goto code_r0x000180109101;
        if (*(char *)(iVar3 + 0x78) != '\0') {
            fVar7 = (float)((uint32_t)fVar5 & 0x7fffffff) * 0.7 + *(float *)(iVar3 + 0x1620);
            if (0.7 <= fVar7) {
                fVar7 = 0.7;
            }
            *(float *)(iVar3 + 0x1620) = fVar7;
            if (iVar1 != iVar2) {
                *(undefined8 *)(iVar3 + 0x1610) = *(undefined8 *)(iVar3 + 0x118);
                *(int64_t *)(iVar3 + 0x1608) = iVar2;
            }
            fVar7 = *(float *)(iVar2 + 0x310);
            fVar6 = *(float *)(iVar3 + 0x128) * 0.1 + fVar7;
            fVar5 = 0.5;
            if ((0.5 <= fVar6) && (fVar5 = 2.5, fVar6 <= 2.5)) {
                fVar5 = fVar6;
            }
            *(float *)(iVar2 + 0x310) = fVar5;
            if (iVar2 != *(int64_t *)(iVar2 + 0x418)) {
                return;
            }
            fVar5 = fVar5 / fVar7;
            var_8h._0_4_ = (*(float *)(iVar2 + 0x68) * (1.0 - fVar5) *
                           (*(float *)(iVar3 + 0x118) - *(float *)(iVar2 + 0x60))) / *(float *)(iVar2 + 0x68) +
                           *(float *)(iVar2 + 0x60);
            var_8h._4_4_ = ((*(float *)(iVar3 + 0x11c) - *(float *)(iVar2 + 100)) *
                           *(float *)(iVar2 + 0x6c) * (1.0 - fVar5)) / *(float *)(iVar2 + 0x6c) +
                           *(float *)(iVar2 + 100);
            func_0x000180106470(iVar2, &var_8h, 0);
            *(float *)(iVar2 + 0x68) = (float)(int32_t)(fVar5 * *(float *)(iVar2 + 0x68));
            *(float *)(iVar2 + 0x6c) = (float)(int32_t)(fVar5 * *(float *)(iVar2 + 0x6c));
            *(float *)(iVar2 + 0x70) = (float)(int32_t)(fVar5 * *(float *)(iVar2 + 0x70));
            *(float *)(iVar2 + 0x74) = (float)(int32_t)(fVar5 * *(float *)(iVar2 + 0x74));
            if ((*(uint32_t *)(iVar2 + 0x14) & 0x100) != 0) {
                return;
            }
            if (0.0 < *(float *)(iVar3 + 0x292c)) {
                return;
            }
            *(undefined4 *)(iVar3 + 0x292c) = *(undefined4 *)(iVar3 + 0x4c);
            return;
        }
    }
    if (*(char *)(iVar3 + 0x138) != '\0') {
        return;
    }
code_r0x000180109101:
    fVar6 = fVar5;
    if (*(char *)(iVar3 + 0xbaa) != '\0') {
        fVar6 = 0.0;
        fVar7 = fVar5;
    }
    *(float *)(iVar3 + 0x162c) =
         (float)((uint32_t)fVar7 & 0x7fffffff) / 30.0 + (*(float *)(iVar3 + 0x162c) - *(float *)(iVar3 + 0x162c) / 30.0)
    ;
    *(float *)(iVar3 + 0x1630) =
         (float)((uint32_t)fVar6 & 0x7fffffff) / 30.0 + (*(float *)(iVar3 + 0x1630) - *(float *)(iVar3 + 0x1630) / 30.0)
    ;
    fVar7 = fVar7 + *(float *)(iVar3 + 0x1624);
    fVar6 = fVar6 + *(float *)(iVar3 + 0x1628);
    *(undefined8 *)(iVar3 + 0x1624) = 0;
    if ((((fVar7 != 0.0) || (fVar6 != 0.0)) &&
        ((iVar1 != 0 || (var_8h._0_4_ = fVar7, var_8h._4_4_ = fVar6, iVar1 = func_0x000180108c80(&var_8h), iVar1 != 0)))
        ) && ((*(uint32_t *)(iVar1 + 0x14) & 0x210) == 0)) {
        if ((fVar7 == 0.0) || (*(float *)(iVar1 + 0xdc) == 0.0)) {
            var_8h._0_1_ = '\0';
        } else {
            var_8h._0_1_ = '\x01';
        }
        if ((fVar6 == 0.0) || (*(float *)(iVar1 + 0xe0) == 0.0)) {
            var_8h._1_1_ = 0;
        } else {
            var_8h._1_1_ = 1;
        }
        if ((char)var_8h != '\0') {
            if (var_8h._1_1_ != 0) {
                var_8h._0_2_ = (uint16_t)var_8h._1_1_;
                *(undefined *)
                 ((int64_t)&var_8h +
                 (uint64_t)
                 (*(float *)(iVar3 + 0x1630) <= *(float *)(iVar3 + 0x162c) &&
                 *(float *)(iVar3 + 0x162c) != *(float *)(iVar3 + 0x1630))) = 0;
            }
            if ((char)var_8h != '\0') {
                fVar5 = (float)((uint32_t)fVar7 & 0x7fffffff) * 0.7 + *(float *)(iVar3 + 0x1620);
                if (0.7 <= fVar5) {
                    fVar5 = 0.7;
                }
                *(float *)(iVar3 + 0x1620) = fVar5;
                if (*(int64_t *)(iVar3 + 0x1608) != iVar1) {
                    *(undefined8 *)(iVar3 + 0x1610) = *(undefined8 *)(iVar3 + 0x118);
                    *(int64_t *)(iVar3 + 0x1608) = iVar1;
                }
                fVar5 = *(float *)(iVar1 + 0x318) + *(float *)(iVar1 + 0x318);
                *(undefined4 *)(iVar1 + 0xec) = 0;
                *(undefined4 *)(iVar1 + 0xf4) = 0;
                fVar4 = (*(float *)(iVar1 + 0x280) - *(float *)(iVar1 + 0x278)) * 0.67;
                if (fVar4 <= fVar5) {
                    fVar5 = fVar4;
                }
                *(float *)(iVar1 + 0xe4) = *(float *)(iVar1 + 0xd4) - (float)(int32_t)fVar5 * fVar7;
                *(undefined4 *)(iVar3 + 0x161c) = *(undefined4 *)(iVar3 + 4);
            }
        }
        if (var_8h._1_1_ != 0) {
            fVar7 = (float)((uint32_t)fVar6 & 0x7fffffff) * 0.7 + *(float *)(iVar3 + 0x1620);
            if (0.7 <= fVar7) {
                fVar7 = 0.7;
            }
            *(float *)(iVar3 + 0x1620) = fVar7;
            if (*(int64_t *)(iVar3 + 0x1608) != iVar1) {
                *(undefined8 *)(iVar3 + 0x1610) = *(undefined8 *)(iVar3 + 0x118);
                *(int64_t *)(iVar3 + 0x1608) = iVar1;
            }
            fVar7 = *(float *)(iVar1 + 0x318) * 5.0;
            *(undefined4 *)(iVar1 + 0xf0) = 0;
            fVar5 = (*(float *)(iVar1 + 0x284) - *(float *)(iVar1 + 0x27c)) * 0.67;
            *(undefined4 *)(iVar1 + 0xf8) = 0;
            if (fVar5 <= fVar7) {
                fVar7 = fVar5;
            }
            *(float *)(iVar1 + 0xe8) = *(float *)(iVar1 + 0xd8) - (float)(int32_t)fVar7 * fVar6;
            *(undefined4 *)(iVar3 + 0x161c) = *(undefined4 *)(iVar3 + 4);
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801090e8
// Address: 0x1801090e8
// Size: 5 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9h

void fcn.180108de0(void)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    int64_t var_8h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1608);
    if (iVar1 != 0) {
        fVar7 = *(float *)(*(int64_t *)0x180781f28 + 0x1620) - *(float *)(*(int64_t *)0x180781f28 + 0x48);
        *(float *)(*(int64_t *)0x180781f28 + 0x1620) = fVar7;
        if ((((-256000.0 <= *(float *)(iVar3 + 0x118)) && (-256000.0 <= *(float *)(iVar3 + 0x11c))) &&
            (fVar6 = *(float *)(iVar3 + 0x11c) - *(float *)(iVar3 + 0x1614),
            fVar5 = *(float *)(iVar3 + 0x118) - *(float *)(iVar3 + 0x1610),
            *(float *)(iVar3 + 0xa4) * *(float *)(iVar3 + 0xa4) < fVar6 * fVar6 + fVar5 * fVar5)) || (fVar7 <= 0.0)) {
            iVar1 = 0;
            *(undefined8 *)(iVar3 + 0x1610) = *(undefined8 *)(iVar3 + 0x118);
            *(undefined4 *)(iVar3 + 0x1620) = 0;
            *(undefined8 *)(iVar3 + 0x1608) = 0;
            *(undefined4 *)(iVar3 + 0x1618) = 0xffffffff;
            *(undefined8 *)(iVar3 + 0x162c) = 0;
        }
    }
    if (*(int32_t *)(iVar3 + 0x1dc8) == -1) {
        fVar7 = *(float *)(iVar3 + 300);
    } else {
        fVar7 = 0.0;
    }
    if (*(int32_t *)(iVar3 + 0x1dd4) == -1) {
        fVar5 = *(float *)(iVar3 + 0x128);
    } else {
        fVar5 = 0.0;
    }
    iVar2 = iVar1;
    if ((iVar1 == 0) && (iVar2 = *(int64_t *)(iVar3 + 0x15e8), *(int64_t *)(iVar3 + 0x15e8) == 0)) {
        return;
    }
    if (*(char *)(iVar2 + 0x10c) != '\0') {
        return;
    }
    if (fVar5 != 0.0) {
        if (*(char *)(iVar3 + 0x138) == '\0') goto code_r0x000180109101;
        if (*(char *)(iVar3 + 0x78) != '\0') {
            fVar7 = (float)((uint32_t)fVar5 & 0x7fffffff) * 0.7 + *(float *)(iVar3 + 0x1620);
            if (0.7 <= fVar7) {
                fVar7 = 0.7;
            }
            *(float *)(iVar3 + 0x1620) = fVar7;
            if (iVar1 != iVar2) {
                *(undefined8 *)(iVar3 + 0x1610) = *(undefined8 *)(iVar3 + 0x118);
                *(int64_t *)(iVar3 + 0x1608) = iVar2;
            }
            fVar7 = *(float *)(iVar2 + 0x310);
            fVar6 = *(float *)(iVar3 + 0x128) * 0.1 + fVar7;
            fVar5 = 0.5;
            if ((0.5 <= fVar6) && (fVar5 = 2.5, fVar6 <= 2.5)) {
                fVar5 = fVar6;
            }
            *(float *)(iVar2 + 0x310) = fVar5;
            if (iVar2 != *(int64_t *)(iVar2 + 0x418)) {
                return;
            }
            fVar5 = fVar5 / fVar7;
            var_8h._0_4_ = (*(float *)(iVar2 + 0x68) * (1.0 - fVar5) *
                           (*(float *)(iVar3 + 0x118) - *(float *)(iVar2 + 0x60))) / *(float *)(iVar2 + 0x68) +
                           *(float *)(iVar2 + 0x60);
            var_8h._4_4_ = ((*(float *)(iVar3 + 0x11c) - *(float *)(iVar2 + 100)) *
                           *(float *)(iVar2 + 0x6c) * (1.0 - fVar5)) / *(float *)(iVar2 + 0x6c) +
                           *(float *)(iVar2 + 100);
            func_0x000180106470(iVar2, &var_8h, 0);
            *(float *)(iVar2 + 0x68) = (float)(int32_t)(fVar5 * *(float *)(iVar2 + 0x68));
            *(float *)(iVar2 + 0x6c) = (float)(int32_t)(fVar5 * *(float *)(iVar2 + 0x6c));
            *(float *)(iVar2 + 0x70) = (float)(int32_t)(fVar5 * *(float *)(iVar2 + 0x70));
            *(float *)(iVar2 + 0x74) = (float)(int32_t)(fVar5 * *(float *)(iVar2 + 0x74));
            if ((*(uint32_t *)(iVar2 + 0x14) & 0x100) != 0) {
                return;
            }
            if (0.0 < *(float *)(iVar3 + 0x292c)) {
                return;
            }
            *(undefined4 *)(iVar3 + 0x292c) = *(undefined4 *)(iVar3 + 0x4c);
            return;
        }
    }
    if (*(char *)(iVar3 + 0x138) != '\0') {
        return;
    }
code_r0x000180109101:
    fVar6 = fVar5;
    if (*(char *)(iVar3 + 0xbaa) != '\0') {
        fVar6 = 0.0;
        fVar7 = fVar5;
    }
    *(float *)(iVar3 + 0x162c) =
         (float)((uint32_t)fVar7 & 0x7fffffff) / 30.0 + (*(float *)(iVar3 + 0x162c) - *(float *)(iVar3 + 0x162c) / 30.0)
    ;
    *(float *)(iVar3 + 0x1630) =
         (float)((uint32_t)fVar6 & 0x7fffffff) / 30.0 + (*(float *)(iVar3 + 0x1630) - *(float *)(iVar3 + 0x1630) / 30.0)
    ;
    fVar7 = fVar7 + *(float *)(iVar3 + 0x1624);
    fVar6 = fVar6 + *(float *)(iVar3 + 0x1628);
    *(undefined8 *)(iVar3 + 0x1624) = 0;
    if ((((fVar7 != 0.0) || (fVar6 != 0.0)) &&
        ((iVar1 != 0 || (var_8h._0_4_ = fVar7, var_8h._4_4_ = fVar6, iVar1 = func_0x000180108c80(&var_8h), iVar1 != 0)))
        ) && ((*(uint32_t *)(iVar1 + 0x14) & 0x210) == 0)) {
        if ((fVar7 == 0.0) || (*(float *)(iVar1 + 0xdc) == 0.0)) {
            var_8h._0_1_ = '\0';
        } else {
            var_8h._0_1_ = '\x01';
        }
        if ((fVar6 == 0.0) || (*(float *)(iVar1 + 0xe0) == 0.0)) {
            var_8h._1_1_ = 0;
        } else {
            var_8h._1_1_ = 1;
        }
        if ((char)var_8h != '\0') {
            if (var_8h._1_1_ != 0) {
                var_8h._0_2_ = (uint16_t)var_8h._1_1_;
                *(undefined *)
                 ((int64_t)&var_8h +
                 (uint64_t)
                 (*(float *)(iVar3 + 0x1630) <= *(float *)(iVar3 + 0x162c) &&
                 *(float *)(iVar3 + 0x162c) != *(float *)(iVar3 + 0x1630))) = 0;
            }
            if ((char)var_8h != '\0') {
                fVar5 = (float)((uint32_t)fVar7 & 0x7fffffff) * 0.7 + *(float *)(iVar3 + 0x1620);
                if (0.7 <= fVar5) {
                    fVar5 = 0.7;
                }
                *(float *)(iVar3 + 0x1620) = fVar5;
                if (*(int64_t *)(iVar3 + 0x1608) != iVar1) {
                    *(undefined8 *)(iVar3 + 0x1610) = *(undefined8 *)(iVar3 + 0x118);
                    *(int64_t *)(iVar3 + 0x1608) = iVar1;
                }
                fVar5 = *(float *)(iVar1 + 0x318) + *(float *)(iVar1 + 0x318);
                *(undefined4 *)(iVar1 + 0xec) = 0;
                *(undefined4 *)(iVar1 + 0xf4) = 0;
                fVar4 = (*(float *)(iVar1 + 0x280) - *(float *)(iVar1 + 0x278)) * 0.67;
                if (fVar4 <= fVar5) {
                    fVar5 = fVar4;
                }
                *(float *)(iVar1 + 0xe4) = *(float *)(iVar1 + 0xd4) - (float)(int32_t)fVar5 * fVar7;
                *(undefined4 *)(iVar3 + 0x161c) = *(undefined4 *)(iVar3 + 4);
            }
        }
        if (var_8h._1_1_ != 0) {
            fVar7 = (float)((uint32_t)fVar6 & 0x7fffffff) * 0.7 + *(float *)(iVar3 + 0x1620);
            if (0.7 <= fVar7) {
                fVar7 = 0.7;
            }
            *(float *)(iVar3 + 0x1620) = fVar7;
            if (*(int64_t *)(iVar3 + 0x1608) != iVar1) {
                *(undefined8 *)(iVar3 + 0x1610) = *(undefined8 *)(iVar3 + 0x118);
                *(int64_t *)(iVar3 + 0x1608) = iVar1;
            }
            fVar7 = *(float *)(iVar1 + 0x318) * 5.0;
            *(undefined4 *)(iVar1 + 0xf0) = 0;
            fVar5 = (*(float *)(iVar1 + 0x284) - *(float *)(iVar1 + 0x27c)) * 0.67;
            *(undefined4 *)(iVar1 + 0xf8) = 0;
            if (fVar5 <= fVar7) {
                fVar7 = fVar5;
            }
            *(float *)(iVar1 + 0xe8) = *(float *)(iVar1 + 0xd8) - (float)(int32_t)fVar7 * fVar6;
            *(undefined4 *)(iVar3 + 0x161c) = *(undefined4 *)(iVar3 + 4);
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801090ed
// Address: 0x1801090ed
// Size: 11 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9h

void fcn.180108de0(void)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    int64_t var_8h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1608);
    if (iVar1 != 0) {
        fVar7 = *(float *)(*(int64_t *)0x180781f28 + 0x1620) - *(float *)(*(int64_t *)0x180781f28 + 0x48);
        *(float *)(*(int64_t *)0x180781f28 + 0x1620) = fVar7;
        if ((((-256000.0 <= *(float *)(iVar3 + 0x118)) && (-256000.0 <= *(float *)(iVar3 + 0x11c))) &&
            (fVar6 = *(float *)(iVar3 + 0x11c) - *(float *)(iVar3 + 0x1614),
            fVar5 = *(float *)(iVar3 + 0x118) - *(float *)(iVar3 + 0x1610),
            *(float *)(iVar3 + 0xa4) * *(float *)(iVar3 + 0xa4) < fVar6 * fVar6 + fVar5 * fVar5)) || (fVar7 <= 0.0)) {
            iVar1 = 0;
            *(undefined8 *)(iVar3 + 0x1610) = *(undefined8 *)(iVar3 + 0x118);
            *(undefined4 *)(iVar3 + 0x1620) = 0;
            *(undefined8 *)(iVar3 + 0x1608) = 0;
            *(undefined4 *)(iVar3 + 0x1618) = 0xffffffff;
            *(undefined8 *)(iVar3 + 0x162c) = 0;
        }
    }
    if (*(int32_t *)(iVar3 + 0x1dc8) == -1) {
        fVar7 = *(float *)(iVar3 + 300);
    } else {
        fVar7 = 0.0;
    }
    if (*(int32_t *)(iVar3 + 0x1dd4) == -1) {
        fVar5 = *(float *)(iVar3 + 0x128);
    } else {
        fVar5 = 0.0;
    }
    iVar2 = iVar1;
    if ((iVar1 == 0) && (iVar2 = *(int64_t *)(iVar3 + 0x15e8), *(int64_t *)(iVar3 + 0x15e8) == 0)) {
        return;
    }
    if (*(char *)(iVar2 + 0x10c) != '\0') {
        return;
    }
    if (fVar5 != 0.0) {
        if (*(char *)(iVar3 + 0x138) == '\0') goto code_r0x000180109101;
        if (*(char *)(iVar3 + 0x78) != '\0') {
            fVar7 = (float)((uint32_t)fVar5 & 0x7fffffff) * 0.7 + *(float *)(iVar3 + 0x1620);
            if (0.7 <= fVar7) {
                fVar7 = 0.7;
            }
            *(float *)(iVar3 + 0x1620) = fVar7;
            if (iVar1 != iVar2) {
                *(undefined8 *)(iVar3 + 0x1610) = *(undefined8 *)(iVar3 + 0x118);
                *(int64_t *)(iVar3 + 0x1608) = iVar2;
            }
            fVar7 = *(float *)(iVar2 + 0x310);
            fVar6 = *(float *)(iVar3 + 0x128) * 0.1 + fVar7;
            fVar5 = 0.5;
            if ((0.5 <= fVar6) && (fVar5 = 2.5, fVar6 <= 2.5)) {
                fVar5 = fVar6;
            }
            *(float *)(iVar2 + 0x310) = fVar5;
            if (iVar2 != *(int64_t *)(iVar2 + 0x418)) {
                return;
            }
            fVar5 = fVar5 / fVar7;
            var_8h._0_4_ = (*(float *)(iVar2 + 0x68) * (1.0 - fVar5) *
                           (*(float *)(iVar3 + 0x118) - *(float *)(iVar2 + 0x60))) / *(float *)(iVar2 + 0x68) +
                           *(float *)(iVar2 + 0x60);
            var_8h._4_4_ = ((*(float *)(iVar3 + 0x11c) - *(float *)(iVar2 + 100)) *
                           *(float *)(iVar2 + 0x6c) * (1.0 - fVar5)) / *(float *)(iVar2 + 0x6c) +
                           *(float *)(iVar2 + 100);
            func_0x000180106470(iVar2, &var_8h, 0);
            *(float *)(iVar2 + 0x68) = (float)(int32_t)(fVar5 * *(float *)(iVar2 + 0x68));
            *(float *)(iVar2 + 0x6c) = (float)(int32_t)(fVar5 * *(float *)(iVar2 + 0x6c));
            *(float *)(iVar2 + 0x70) = (float)(int32_t)(fVar5 * *(float *)(iVar2 + 0x70));
            *(float *)(iVar2 + 0x74) = (float)(int32_t)(fVar5 * *(float *)(iVar2 + 0x74));
            if ((*(uint32_t *)(iVar2 + 0x14) & 0x100) != 0) {
                return;
            }
            if (0.0 < *(float *)(iVar3 + 0x292c)) {
                return;
            }
            *(undefined4 *)(iVar3 + 0x292c) = *(undefined4 *)(iVar3 + 0x4c);
            return;
        }
    }
    if (*(char *)(iVar3 + 0x138) != '\0') {
        return;
    }
code_r0x000180109101:
    fVar6 = fVar5;
    if (*(char *)(iVar3 + 0xbaa) != '\0') {
        fVar6 = 0.0;
        fVar7 = fVar5;
    }
    *(float *)(iVar3 + 0x162c) =
         (float)((uint32_t)fVar7 & 0x7fffffff) / 30.0 + (*(float *)(iVar3 + 0x162c) - *(float *)(iVar3 + 0x162c) / 30.0)
    ;
    *(float *)(iVar3 + 0x1630) =
         (float)((uint32_t)fVar6 & 0x7fffffff) / 30.0 + (*(float *)(iVar3 + 0x1630) - *(float *)(iVar3 + 0x1630) / 30.0)
    ;
    fVar7 = fVar7 + *(float *)(iVar3 + 0x1624);
    fVar6 = fVar6 + *(float *)(iVar3 + 0x1628);
    *(undefined8 *)(iVar3 + 0x1624) = 0;
    if ((((fVar7 != 0.0) || (fVar6 != 0.0)) &&
        ((iVar1 != 0 || (var_8h._0_4_ = fVar7, var_8h._4_4_ = fVar6, iVar1 = func_0x000180108c80(&var_8h), iVar1 != 0)))
        ) && ((*(uint32_t *)(iVar1 + 0x14) & 0x210) == 0)) {
        if ((fVar7 == 0.0) || (*(float *)(iVar1 + 0xdc) == 0.0)) {
            var_8h._0_1_ = '\0';
        } else {
            var_8h._0_1_ = '\x01';
        }
        if ((fVar6 == 0.0) || (*(float *)(iVar1 + 0xe0) == 0.0)) {
            var_8h._1_1_ = 0;
        } else {
            var_8h._1_1_ = 1;
        }
        if ((char)var_8h != '\0') {
            if (var_8h._1_1_ != 0) {
                var_8h._0_2_ = (uint16_t)var_8h._1_1_;
                *(undefined *)
                 ((int64_t)&var_8h +
                 (uint64_t)
                 (*(float *)(iVar3 + 0x1630) <= *(float *)(iVar3 + 0x162c) &&
                 *(float *)(iVar3 + 0x162c) != *(float *)(iVar3 + 0x1630))) = 0;
            }
            if ((char)var_8h != '\0') {
                fVar5 = (float)((uint32_t)fVar7 & 0x7fffffff) * 0.7 + *(float *)(iVar3 + 0x1620);
                if (0.7 <= fVar5) {
                    fVar5 = 0.7;
                }
                *(float *)(iVar3 + 0x1620) = fVar5;
                if (*(int64_t *)(iVar3 + 0x1608) != iVar1) {
                    *(undefined8 *)(iVar3 + 0x1610) = *(undefined8 *)(iVar3 + 0x118);
                    *(int64_t *)(iVar3 + 0x1608) = iVar1;
                }
                fVar5 = *(float *)(iVar1 + 0x318) + *(float *)(iVar1 + 0x318);
                *(undefined4 *)(iVar1 + 0xec) = 0;
                *(undefined4 *)(iVar1 + 0xf4) = 0;
                fVar4 = (*(float *)(iVar1 + 0x280) - *(float *)(iVar1 + 0x278)) * 0.67;
                if (fVar4 <= fVar5) {
                    fVar5 = fVar4;
                }
                *(float *)(iVar1 + 0xe4) = *(float *)(iVar1 + 0xd4) - (float)(int32_t)fVar5 * fVar7;
                *(undefined4 *)(iVar3 + 0x161c) = *(undefined4 *)(iVar3 + 4);
            }
        }
        if (var_8h._1_1_ != 0) {
            fVar7 = (float)((uint32_t)fVar6 & 0x7fffffff) * 0.7 + *(float *)(iVar3 + 0x1620);
            if (0.7 <= fVar7) {
                fVar7 = 0.7;
            }
            *(float *)(iVar3 + 0x1620) = fVar7;
            if (*(int64_t *)(iVar3 + 0x1608) != iVar1) {
                *(undefined8 *)(iVar3 + 0x1610) = *(undefined8 *)(iVar3 + 0x118);
                *(int64_t *)(iVar3 + 0x1608) = iVar1;
            }
            fVar7 = *(float *)(iVar1 + 0x318) * 5.0;
            *(undefined4 *)(iVar1 + 0xf0) = 0;
            fVar5 = (*(float *)(iVar1 + 0x284) - *(float *)(iVar1 + 0x27c)) * 0.67;
            *(undefined4 *)(iVar1 + 0xf8) = 0;
            if (fVar5 <= fVar7) {
                fVar7 = fVar5;
            }
            *(float *)(iVar1 + 0xe8) = *(float *)(iVar1 + 0xd8) - (float)(int32_t)fVar7 * fVar6;
            *(undefined4 *)(iVar3 + 0x161c) = *(undefined4 *)(iVar3 + 4);
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801090f8
// Address: 0x1801090f8
// Size: 714 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9h

void fcn.180108de0(void)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    int64_t var_8h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1608);
    if (iVar1 != 0) {
        fVar7 = *(float *)(*(int64_t *)0x180781f28 + 0x1620) - *(float *)(*(int64_t *)0x180781f28 + 0x48);
        *(float *)(*(int64_t *)0x180781f28 + 0x1620) = fVar7;
        if ((((-256000.0 <= *(float *)(iVar3 + 0x118)) && (-256000.0 <= *(float *)(iVar3 + 0x11c))) &&
            (fVar6 = *(float *)(iVar3 + 0x11c) - *(float *)(iVar3 + 0x1614),
            fVar5 = *(float *)(iVar3 + 0x118) - *(float *)(iVar3 + 0x1610),
            *(float *)(iVar3 + 0xa4) * *(float *)(iVar3 + 0xa4) < fVar6 * fVar6 + fVar5 * fVar5)) || (fVar7 <= 0.0)) {
            iVar1 = 0;
            *(undefined8 *)(iVar3 + 0x1610) = *(undefined8 *)(iVar3 + 0x118);
            *(undefined4 *)(iVar3 + 0x1620) = 0;
            *(undefined8 *)(iVar3 + 0x1608) = 0;
            *(undefined4 *)(iVar3 + 0x1618) = 0xffffffff;
            *(undefined8 *)(iVar3 + 0x162c) = 0;
        }
    }
    if (*(int32_t *)(iVar3 + 0x1dc8) == -1) {
        fVar7 = *(float *)(iVar3 + 300);
    } else {
        fVar7 = 0.0;
    }
    if (*(int32_t *)(iVar3 + 0x1dd4) == -1) {
        fVar5 = *(float *)(iVar3 + 0x128);
    } else {
        fVar5 = 0.0;
    }
    iVar2 = iVar1;
    if ((iVar1 == 0) && (iVar2 = *(int64_t *)(iVar3 + 0x15e8), *(int64_t *)(iVar3 + 0x15e8) == 0)) {
        return;
    }
    if (*(char *)(iVar2 + 0x10c) != '\0') {
        return;
    }
    if (fVar5 != 0.0) {
        if (*(char *)(iVar3 + 0x138) == '\0') goto code_r0x000180109101;
        if (*(char *)(iVar3 + 0x78) != '\0') {
            fVar7 = (float)((uint32_t)fVar5 & 0x7fffffff) * 0.7 + *(float *)(iVar3 + 0x1620);
            if (0.7 <= fVar7) {
                fVar7 = 0.7;
            }
            *(float *)(iVar3 + 0x1620) = fVar7;
            if (iVar1 != iVar2) {
                *(undefined8 *)(iVar3 + 0x1610) = *(undefined8 *)(iVar3 + 0x118);
                *(int64_t *)(iVar3 + 0x1608) = iVar2;
            }
            fVar7 = *(float *)(iVar2 + 0x310);
            fVar6 = *(float *)(iVar3 + 0x128) * 0.1 + fVar7;
            fVar5 = 0.5;
            if ((0.5 <= fVar6) && (fVar5 = 2.5, fVar6 <= 2.5)) {
                fVar5 = fVar6;
            }
            *(float *)(iVar2 + 0x310) = fVar5;
            if (iVar2 != *(int64_t *)(iVar2 + 0x418)) {
                return;
            }
            fVar5 = fVar5 / fVar7;
            var_8h._0_4_ = (*(float *)(iVar2 + 0x68) * (1.0 - fVar5) *
                           (*(float *)(iVar3 + 0x118) - *(float *)(iVar2 + 0x60))) / *(float *)(iVar2 + 0x68) +
                           *(float *)(iVar2 + 0x60);
            var_8h._4_4_ = ((*(float *)(iVar3 + 0x11c) - *(float *)(iVar2 + 100)) *
                           *(float *)(iVar2 + 0x6c) * (1.0 - fVar5)) / *(float *)(iVar2 + 0x6c) +
                           *(float *)(iVar2 + 100);
            func_0x000180106470(iVar2, &var_8h, 0);
            *(float *)(iVar2 + 0x68) = (float)(int32_t)(fVar5 * *(float *)(iVar2 + 0x68));
            *(float *)(iVar2 + 0x6c) = (float)(int32_t)(fVar5 * *(float *)(iVar2 + 0x6c));
            *(float *)(iVar2 + 0x70) = (float)(int32_t)(fVar5 * *(float *)(iVar2 + 0x70));
            *(float *)(iVar2 + 0x74) = (float)(int32_t)(fVar5 * *(float *)(iVar2 + 0x74));
            if ((*(uint32_t *)(iVar2 + 0x14) & 0x100) != 0) {
                return;
            }
            if (0.0 < *(float *)(iVar3 + 0x292c)) {
                return;
            }
            *(undefined4 *)(iVar3 + 0x292c) = *(undefined4 *)(iVar3 + 0x4c);
            return;
        }
    }
    if (*(char *)(iVar3 + 0x138) != '\0') {
        return;
    }
code_r0x000180109101:
    fVar6 = fVar5;
    if (*(char *)(iVar3 + 0xbaa) != '\0') {
        fVar6 = 0.0;
        fVar7 = fVar5;
    }
    *(float *)(iVar3 + 0x162c) =
         (float)((uint32_t)fVar7 & 0x7fffffff) / 30.0 + (*(float *)(iVar3 + 0x162c) - *(float *)(iVar3 + 0x162c) / 30.0)
    ;
    *(float *)(iVar3 + 0x1630) =
         (float)((uint32_t)fVar6 & 0x7fffffff) / 30.0 + (*(float *)(iVar3 + 0x1630) - *(float *)(iVar3 + 0x1630) / 30.0)
    ;
    fVar7 = fVar7 + *(float *)(iVar3 + 0x1624);
    fVar6 = fVar6 + *(float *)(iVar3 + 0x1628);
    *(undefined8 *)(iVar3 + 0x1624) = 0;
    if ((((fVar7 != 0.0) || (fVar6 != 0.0)) &&
        ((iVar1 != 0 || (var_8h._0_4_ = fVar7, var_8h._4_4_ = fVar6, iVar1 = func_0x000180108c80(&var_8h), iVar1 != 0)))
        ) && ((*(uint32_t *)(iVar1 + 0x14) & 0x210) == 0)) {
        if ((fVar7 == 0.0) || (*(float *)(iVar1 + 0xdc) == 0.0)) {
            var_8h._0_1_ = '\0';
        } else {
            var_8h._0_1_ = '\x01';
        }
        if ((fVar6 == 0.0) || (*(float *)(iVar1 + 0xe0) == 0.0)) {
            var_8h._1_1_ = 0;
        } else {
            var_8h._1_1_ = 1;
        }
        if ((char)var_8h != '\0') {
            if (var_8h._1_1_ != 0) {
                var_8h._0_2_ = (uint16_t)var_8h._1_1_;
                *(undefined *)
                 ((int64_t)&var_8h +
                 (uint64_t)
                 (*(float *)(iVar3 + 0x1630) <= *(float *)(iVar3 + 0x162c) &&
                 *(float *)(iVar3 + 0x162c) != *(float *)(iVar3 + 0x1630))) = 0;
            }
            if ((char)var_8h != '\0') {
                fVar5 = (float)((uint32_t)fVar7 & 0x7fffffff) * 0.7 + *(float *)(iVar3 + 0x1620);
                if (0.7 <= fVar5) {
                    fVar5 = 0.7;
                }
                *(float *)(iVar3 + 0x1620) = fVar5;
                if (*(int64_t *)(iVar3 + 0x1608) != iVar1) {
                    *(undefined8 *)(iVar3 + 0x1610) = *(undefined8 *)(iVar3 + 0x118);
                    *(int64_t *)(iVar3 + 0x1608) = iVar1;
                }
                fVar5 = *(float *)(iVar1 + 0x318) + *(float *)(iVar1 + 0x318);
                *(undefined4 *)(iVar1 + 0xec) = 0;
                *(undefined4 *)(iVar1 + 0xf4) = 0;
                fVar4 = (*(float *)(iVar1 + 0x280) - *(float *)(iVar1 + 0x278)) * 0.67;
                if (fVar4 <= fVar5) {
                    fVar5 = fVar4;
                }
                *(float *)(iVar1 + 0xe4) = *(float *)(iVar1 + 0xd4) - (float)(int32_t)fVar5 * fVar7;
                *(undefined4 *)(iVar3 + 0x161c) = *(undefined4 *)(iVar3 + 4);
            }
        }
        if (var_8h._1_1_ != 0) {
            fVar7 = (float)((uint32_t)fVar6 & 0x7fffffff) * 0.7 + *(float *)(iVar3 + 0x1620);
            if (0.7 <= fVar7) {
                fVar7 = 0.7;
            }
            *(float *)(iVar3 + 0x1620) = fVar7;
            if (*(int64_t *)(iVar3 + 0x1608) != iVar1) {
                *(undefined8 *)(iVar3 + 0x1610) = *(undefined8 *)(iVar3 + 0x118);
                *(int64_t *)(iVar3 + 0x1608) = iVar1;
            }
            fVar7 = *(float *)(iVar1 + 0x318) * 5.0;
            *(undefined4 *)(iVar1 + 0xf0) = 0;
            fVar5 = (*(float *)(iVar1 + 0x284) - *(float *)(iVar1 + 0x27c)) * 0.67;
            *(undefined4 *)(iVar1 + 0xf8) = 0;
            if (fVar5 <= fVar7) {
                fVar7 = fVar5;
            }
            *(float *)(iVar1 + 0xe8) = *(float *)(iVar1 + 0xd8) - (float)(int32_t)fVar7 * fVar6;
            *(undefined4 *)(iVar3 + 0x161c) = *(undefined4 *)(iVar3 + 4);
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801093d0
// Address: 0x1801093d0
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_55h
// WARNING: [rz-ghidra] Detected overlap for variable var_56h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_57h

void fcn.1801093d0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4)
{
    uint8_t *puVar1;
    int32_t *piVar2;
    undefined4 *puVar3;
    undefined4 uVar4;
    uint32_t uVar5;
    int64_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    undefined2 uVar10;
    uint32_t uVar11;
    int32_t iVar12;
    char cVar13;
    char cVar14;
    uint32_t uVar15;
    int64_t iVar16;
    uint32_t uVar17;
    char cVar18;
    undefined4 *puVar19;
    char cVar20;
    char *pcVar21;
    int32_t iVar22;
    uint64_t uVar23;
    char cVar24;
    char cVar25;
    uint32_t uVar26;
    int64_t iVar27;
    int32_t iVar28;
    bool bVar29;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_78 [32];
    char var_58h;
    char var_57h;
    char var_56h;
    char var_55h;
    int64_t var_54h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar9 = *(int64_t *)0x180781f28;
    var_30h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_78;
    cVar13 = (char)arg1;
    puVar1 = (uint8_t *)(*(int64_t *)0x180781f28 + 0x30);
    if ((cVar13 == '\0') || (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2c8c) != 1)) {
        var_54h._0_1_ = '\0';
    } else {
        var_54h._0_1_ = '\x01';
    }
    cVar14 = '\0';
    cVar24 = '\0';
    var_58h = '\0';
    cVar20 = '\0';
    var_55h = '\0';
    uVar23 = arg4 & 0xffffffffffffff00;
    var_56h = '\0';
    cVar25 = '\0';
    var_54h._4_4_ = (uint32_t)uVar23;
    var_57h = '\0';
    uVar17 = 0;
    var_38h._0_4_ = 0;
    iVar28 = 0;
    _var_48h = ZEXT816(0);
    iVar27 = *(int64_t *)0x180781f28;
    cVar18 = (char)var_54h;
    if (0 < *(int32_t *)(*(int64_t *)0x180781f28 + 0x1558)) {
        do {
            iVar6 = *(int64_t *)(iVar9 + 0x1560);
            iVar16 = (int64_t)iVar28 * 0x1c;
            iVar12 = *(int32_t *)(iVar16 + iVar6);
            if (iVar12 == 1) {
                if (*(char *)(iVar9 + 0xeb) == '\0') {
                    if ((cVar13 != '\0') &&
                       ((((uVar17 != 0 || (cVar24 != '\0')) || (cVar20 != '\0')) || (cVar25 != '\0')))) break;
                    uVar4 = *(undefined4 *)(iVar16 + 0xc + iVar6);
                    *(undefined4 *)(iVar9 + 0x11c) = *(undefined4 *)(iVar16 + 0x10 + iVar6);
                    *(undefined4 *)(iVar9 + 0x118) = uVar4;
                    *(undefined4 *)(iVar9 + 0x130) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                    var_58h = '\x01';
                    cVar14 = '\x01';
                }
            } else if (iVar12 == 3) {
                uVar5 = *(uint32_t *)(iVar16 + 0xc + iVar6);
                if ((cVar13 != '\0') &&
                   ((((uVar17 >> (uVar5 & 0x1f) & 1) != 0 || (cVar24 != '\0')) ||
                    ((*(int32_t *)(iVar16 + 0x14 + iVar6) == 1 && (cVar14 != '\0')))))) break;
                uVar17 = uVar17 | 1 << (uVar5 & 0x1f);
                puVar1[(int64_t)(int32_t)uVar5 + 0xf0] = *(uint8_t *)(iVar16 + 0x10 + iVar6);
                *(undefined4 *)(iVar9 + 0x130) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                cVar14 = var_58h;
            } else if (iVar12 == 2) {
                if ((cVar13 != '\0') && ((cVar14 != '\0' || (uVar17 != 0)))) break;
                var_55h = '\x01';
                *(float *)(iVar9 + 300) = *(float *)(iVar16 + 0xc + iVar6) + *(float *)(iVar9 + 300);
                *(float *)(iVar9 + 0x128) = *(float *)(iVar16 + 0x10 + iVar6) + *(float *)(iVar9 + 0x128);
                *(undefined4 *)(iVar9 + 0x130) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                cVar24 = '\x01';
            } else if (iVar12 == 4) {
                *(undefined4 *)(iVar9 + 0x134) = *(undefined4 *)(iVar16 + 0xc + iVar6);
            } else if (iVar12 == 5) {
                if ((*puVar1 & 0x40) == 0) {
                    uVar5 = *(uint32_t *)(iVar16 + 0xc + iVar6);
                    uVar11 = uVar5;
                    if ((uVar5 & 0xf000) != 0) {
                        if (uVar5 == 0x1000) {
                            uVar11 = 0x297;
                        } else if (uVar5 == 0x2000) {
                            uVar11 = 0x298;
                        } else if (uVar5 == 0x4000) {
                            uVar11 = 0x299;
                        } else if (uVar5 == 0x8000) {
                            uVar11 = 0x29a;
                        }
                    }
                    pcVar21 = (char *)(((int64_t)(int32_t)uVar11 + -0x1ec) * 0x10 + iVar27);
                    uVar11 = (uint32_t)((int64_t)(pcVar21 + (-0x140 - iVar9)) >> 4);
                    if (((cVar13 != '\0') && (*pcVar21 != *(char *)(iVar16 + 0x10 + iVar6))) &&
                       (((*(uint32_t *)((int64_t)&var_48h + ((int64_t)(int32_t)uVar11 >> 5) * 4) >> (uVar11 & 0x1f) & 1)
                         != 0 || (uVar17 != 0)))) break;
                    uVar15 = -(uint32_t)(*(char *)(iVar27 + 0xab0) != '\0') & 0x1000;
                    uVar26 = uVar15 | 0x4000;
                    if (*(char *)(iVar27 + 0xad0) == '\0') {
                        uVar26 = uVar15;
                    }
                    uVar15 = (uVar26 | uVar5) & 0x1000;
                    if (((uVar15 == 0) || (((uVar26 | uVar5) >> 0xe & 1) != 0)) &&
                       ((*(char *)(iVar27 + 0x8d) == '\0' || (uVar15 == 0)))) {
                        if ((uVar5 & 0xffff0fff) == 0) {
                            bVar29 = false;
                        } else {
                            bVar29 = (*(uint32_t *)
                                       (iVar27 + 0x16b8 + ((int64_t)(int32_t)(uVar5 & 0xffff0fff) + -0x200 >> 5) * 4) >>
                                      (uVar5 & 0x1f) & 1) != 0;
                        }
                    } else {
                        bVar29 = false;
                    }
                    if (((cVar18 != '\0') && (var_57h != '\0')) && (!bVar29)) break;
                    cVar24 = *(char *)(iVar16 + 0x10 + iVar6);
                    if (*pcVar21 != cVar24) {
                        var_56h = '\x01';
                        *(uint32_t *)((int64_t)&var_48h + ((int64_t)(int32_t)uVar11 >> 5) * 4) =
                             *(uint32_t *)((int64_t)&var_48h + ((int64_t)(int32_t)uVar11 >> 5) * 4) |
                             1 << (uVar11 & 0x1f);
                        if ((cVar18 != '\0') && (var_54h._4_4_ = var_54h._4_4_ & 0xff, !bVar29)) {
                            var_54h._4_4_ = 1;
                        }
                    }
                    *pcVar21 = cVar24;
                    *(undefined4 *)(pcVar21 + 0xc) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                    cVar24 = var_55h;
                    cVar20 = var_56h;
                    cVar25 = var_57h;
                    cVar14 = var_58h;
                }
            } else if (iVar12 == 6) {
                if ((*puVar1 & 0x40) == 0) {
                    if (((cVar13 != '\0') && (((uVar17 != 0 || (cVar14 != '\0')) || (cVar24 != '\0')))) ||
                       ((cVar18 != '\0' && ((char)uVar23 != '\0')))) break;
                    uVar5 = *(uint32_t *)(iVar16 + 0xc + iVar6);
                    piVar2 = (int32_t *)(iVar9 + 0xc18);
                    iVar12 = *(int32_t *)(iVar9 + 0xc1c);
                    uVar10 = 0xfffd;
                    if (uVar5 < 0x10000) {
                        uVar10 = (undefined2)uVar5;
                    }
                    if (*piVar2 == iVar12) {
                        iVar22 = *piVar2 + 1;
                        if (iVar12 == 0) {
                            iVar12 = 8;
                        } else {
                            iVar12 = iVar12 / 2 + iVar12;
                        }
                        if (iVar22 < iVar12) {
                            iVar22 = iVar12;
                        }
                        func_0x00018011f8d0(piVar2, iVar22);
                        iVar27 = *(int64_t *)0x180781f28;
                        cVar24 = var_55h;
                        cVar25 = var_57h;
                    }
                    *(undefined2 *)(*(int64_t *)(iVar9 + 0xc20) + (int64_t)*piVar2 * 2) = uVar10;
                    *piVar2 = *piVar2 + 1;
                    cVar20 = var_56h;
                    cVar18 = (char)var_54h;
                    cVar14 = var_58h;
                    if ((char)var_54h != '\0') {
                        cVar25 = '\x01';
                        var_57h = '\x01';
                    }
                }
            } else if (iVar12 == 7) {
                *(bool *)(iVar9 + 0xc14) = *(char *)(iVar16 + 0xc + iVar6) == '\0';
            }
            uVar23 = (uint64_t)var_54h._4_4_;
            iVar28 = iVar28 + 1;
        } while (iVar28 < *(int32_t *)(iVar9 + 0x1558));
    }
    uVar17 = 0;
    if (0 < iVar28) {
        piVar2 = (int32_t *)(iVar9 + 0x1568);
        do {
            iVar12 = *(int32_t *)(iVar9 + 0x156c);
            puVar19 = (undefined4 *)((uint64_t)uVar17 * 0x1c + *(int64_t *)(iVar9 + 0x1560));
            if (*piVar2 == iVar12) {
                iVar22 = *piVar2 + 1;
                if (iVar12 == 0) {
                    iVar12 = 8;
                } else {
                    iVar12 = iVar12 / 2 + iVar12;
                }
                if (iVar22 < iVar12) {
                    iVar22 = iVar12;
                }
                func_0x00018011f9d0(piVar2, iVar22);
            }
            iVar12 = *piVar2;
            uVar17 = uVar17 + 1;
            uVar4 = puVar19[1];
            uVar7 = puVar19[2];
            uVar8 = puVar19[3];
            iVar27 = *(int64_t *)(iVar9 + 0x1570);
            puVar3 = (undefined4 *)((int64_t)iVar12 * 0x1c + iVar27);
            *puVar3 = *puVar19;
            puVar3[1] = uVar4;
            puVar3[2] = uVar7;
            puVar3[3] = uVar8;
            uVar4 = puVar19[4];
            uVar7 = puVar19[5];
            uVar8 = puVar19[6];
            puVar3 = (undefined4 *)((int64_t)iVar12 * 0x1c + 0xc + iVar27);
            *puVar3 = puVar19[3];
            puVar3[1] = uVar4;
            puVar3[2] = uVar7;
            puVar3[3] = uVar8;
            *piVar2 = *piVar2 + 1;
        } while ((int32_t)uVar17 < iVar28);
    }
    piVar2 = (int32_t *)(iVar9 + 0x1558);
    if (iVar28 == *piVar2) {
        iVar28 = *(int32_t *)(iVar9 + 0x155c);
        if (iVar28 < 0) {
            iVar28 = iVar28 + iVar28 / 2;
            iVar12 = 0;
            if (0 < iVar28) {
                iVar12 = iVar28;
            }
            func_0x00018011f9d0(piVar2, iVar12);
        }
        *piVar2 = 0;
    } else {
        func_0x000180498030(*(int64_t *)(iVar9 + 0x1560), (int64_t)iVar28 * 0x1c + *(int64_t *)(iVar9 + 0x1560), 
                            ((int64_t)*piVar2 - (int64_t)iVar28) * 0x1c);
        *piVar2 = *piVar2 - iVar28;
    }
    if (*(char *)(iVar9 + 0xc14) != '\0') {
        func_0x0001800f52d0(puVar1);
        *(undefined *)(iVar9 + 0xa40) = 0;
        *(undefined4 *)(iVar9 + 0xa44) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa48) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa50) = 0;
        *(undefined4 *)(iVar9 + 0xa54) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa58) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa60) = 0;
        *(undefined4 *)(iVar9 + 0xa64) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa68) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa70) = 0;
        *(undefined4 *)(iVar9 + 0xa74) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa78) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa80) = 0;
        *(undefined4 *)(iVar9 + 0xa84) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa88) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa90) = 0;
        *(undefined4 *)(iVar9 + 0xa94) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa98) = 0xbf800000;
        *(undefined *)(iVar9 + 0xaa0) = 0;
        *(undefined4 *)(iVar9 + 0xaa4) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xaa8) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0x118) = 0xff7fffff;
        *(undefined4 *)(iVar9 + 0x11c) = 0xff7fffff;
        *(undefined4 *)(iVar9 + 0x120) = 0;
        *(undefined4 *)(iVar9 + 0xbc0) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbac) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbc4) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbb0) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbc8) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbb4) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbcc) = 0xbf800000;
        *(undefined4 *)(iVar9 + 3000) = 0xbf800000;
        *(undefined *)(iVar9 + 0x124) = 0;
        *(undefined4 *)(iVar9 + 0xbd0) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbbc) = 0xbf800000;
        *(undefined8 *)(iVar9 + 0x128) = 0;
    }
    func_0x000180459870(var_30h ^ (uint64_t)auStack_78);
    return;
}

// ============================================================
// Function: FUN_1801093e8
// Address: 0x1801093e8
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_55h
// WARNING: [rz-ghidra] Detected overlap for variable var_56h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_57h

void fcn.1801093d0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4)
{
    uint8_t *puVar1;
    int32_t *piVar2;
    undefined4 *puVar3;
    undefined4 uVar4;
    uint32_t uVar5;
    int64_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    undefined2 uVar10;
    uint32_t uVar11;
    int32_t iVar12;
    char cVar13;
    char cVar14;
    uint32_t uVar15;
    int64_t iVar16;
    uint32_t uVar17;
    char cVar18;
    undefined4 *puVar19;
    char cVar20;
    char *pcVar21;
    int32_t iVar22;
    uint64_t uVar23;
    char cVar24;
    char cVar25;
    uint32_t uVar26;
    int64_t iVar27;
    int32_t iVar28;
    bool bVar29;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_78 [32];
    char var_58h;
    char var_57h;
    char var_56h;
    char var_55h;
    int64_t var_54h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar9 = *(int64_t *)0x180781f28;
    var_30h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_78;
    cVar13 = (char)arg1;
    puVar1 = (uint8_t *)(*(int64_t *)0x180781f28 + 0x30);
    if ((cVar13 == '\0') || (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2c8c) != 1)) {
        var_54h._0_1_ = '\0';
    } else {
        var_54h._0_1_ = '\x01';
    }
    cVar14 = '\0';
    cVar24 = '\0';
    var_58h = '\0';
    cVar20 = '\0';
    var_55h = '\0';
    uVar23 = arg4 & 0xffffffffffffff00;
    var_56h = '\0';
    cVar25 = '\0';
    var_54h._4_4_ = (uint32_t)uVar23;
    var_57h = '\0';
    uVar17 = 0;
    var_38h._0_4_ = 0;
    iVar28 = 0;
    _var_48h = ZEXT816(0);
    iVar27 = *(int64_t *)0x180781f28;
    cVar18 = (char)var_54h;
    if (0 < *(int32_t *)(*(int64_t *)0x180781f28 + 0x1558)) {
        do {
            iVar6 = *(int64_t *)(iVar9 + 0x1560);
            iVar16 = (int64_t)iVar28 * 0x1c;
            iVar12 = *(int32_t *)(iVar16 + iVar6);
            if (iVar12 == 1) {
                if (*(char *)(iVar9 + 0xeb) == '\0') {
                    if ((cVar13 != '\0') &&
                       ((((uVar17 != 0 || (cVar24 != '\0')) || (cVar20 != '\0')) || (cVar25 != '\0')))) break;
                    uVar4 = *(undefined4 *)(iVar16 + 0xc + iVar6);
                    *(undefined4 *)(iVar9 + 0x11c) = *(undefined4 *)(iVar16 + 0x10 + iVar6);
                    *(undefined4 *)(iVar9 + 0x118) = uVar4;
                    *(undefined4 *)(iVar9 + 0x130) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                    var_58h = '\x01';
                    cVar14 = '\x01';
                }
            } else if (iVar12 == 3) {
                uVar5 = *(uint32_t *)(iVar16 + 0xc + iVar6);
                if ((cVar13 != '\0') &&
                   ((((uVar17 >> (uVar5 & 0x1f) & 1) != 0 || (cVar24 != '\0')) ||
                    ((*(int32_t *)(iVar16 + 0x14 + iVar6) == 1 && (cVar14 != '\0')))))) break;
                uVar17 = uVar17 | 1 << (uVar5 & 0x1f);
                puVar1[(int64_t)(int32_t)uVar5 + 0xf0] = *(uint8_t *)(iVar16 + 0x10 + iVar6);
                *(undefined4 *)(iVar9 + 0x130) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                cVar14 = var_58h;
            } else if (iVar12 == 2) {
                if ((cVar13 != '\0') && ((cVar14 != '\0' || (uVar17 != 0)))) break;
                var_55h = '\x01';
                *(float *)(iVar9 + 300) = *(float *)(iVar16 + 0xc + iVar6) + *(float *)(iVar9 + 300);
                *(float *)(iVar9 + 0x128) = *(float *)(iVar16 + 0x10 + iVar6) + *(float *)(iVar9 + 0x128);
                *(undefined4 *)(iVar9 + 0x130) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                cVar24 = '\x01';
            } else if (iVar12 == 4) {
                *(undefined4 *)(iVar9 + 0x134) = *(undefined4 *)(iVar16 + 0xc + iVar6);
            } else if (iVar12 == 5) {
                if ((*puVar1 & 0x40) == 0) {
                    uVar5 = *(uint32_t *)(iVar16 + 0xc + iVar6);
                    uVar11 = uVar5;
                    if ((uVar5 & 0xf000) != 0) {
                        if (uVar5 == 0x1000) {
                            uVar11 = 0x297;
                        } else if (uVar5 == 0x2000) {
                            uVar11 = 0x298;
                        } else if (uVar5 == 0x4000) {
                            uVar11 = 0x299;
                        } else if (uVar5 == 0x8000) {
                            uVar11 = 0x29a;
                        }
                    }
                    pcVar21 = (char *)(((int64_t)(int32_t)uVar11 + -0x1ec) * 0x10 + iVar27);
                    uVar11 = (uint32_t)((int64_t)(pcVar21 + (-0x140 - iVar9)) >> 4);
                    if (((cVar13 != '\0') && (*pcVar21 != *(char *)(iVar16 + 0x10 + iVar6))) &&
                       (((*(uint32_t *)((int64_t)&var_48h + ((int64_t)(int32_t)uVar11 >> 5) * 4) >> (uVar11 & 0x1f) & 1)
                         != 0 || (uVar17 != 0)))) break;
                    uVar15 = -(uint32_t)(*(char *)(iVar27 + 0xab0) != '\0') & 0x1000;
                    uVar26 = uVar15 | 0x4000;
                    if (*(char *)(iVar27 + 0xad0) == '\0') {
                        uVar26 = uVar15;
                    }
                    uVar15 = (uVar26 | uVar5) & 0x1000;
                    if (((uVar15 == 0) || (((uVar26 | uVar5) >> 0xe & 1) != 0)) &&
                       ((*(char *)(iVar27 + 0x8d) == '\0' || (uVar15 == 0)))) {
                        if ((uVar5 & 0xffff0fff) == 0) {
                            bVar29 = false;
                        } else {
                            bVar29 = (*(uint32_t *)
                                       (iVar27 + 0x16b8 + ((int64_t)(int32_t)(uVar5 & 0xffff0fff) + -0x200 >> 5) * 4) >>
                                      (uVar5 & 0x1f) & 1) != 0;
                        }
                    } else {
                        bVar29 = false;
                    }
                    if (((cVar18 != '\0') && (var_57h != '\0')) && (!bVar29)) break;
                    cVar24 = *(char *)(iVar16 + 0x10 + iVar6);
                    if (*pcVar21 != cVar24) {
                        var_56h = '\x01';
                        *(uint32_t *)((int64_t)&var_48h + ((int64_t)(int32_t)uVar11 >> 5) * 4) =
                             *(uint32_t *)((int64_t)&var_48h + ((int64_t)(int32_t)uVar11 >> 5) * 4) |
                             1 << (uVar11 & 0x1f);
                        if ((cVar18 != '\0') && (var_54h._4_4_ = var_54h._4_4_ & 0xff, !bVar29)) {
                            var_54h._4_4_ = 1;
                        }
                    }
                    *pcVar21 = cVar24;
                    *(undefined4 *)(pcVar21 + 0xc) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                    cVar24 = var_55h;
                    cVar20 = var_56h;
                    cVar25 = var_57h;
                    cVar14 = var_58h;
                }
            } else if (iVar12 == 6) {
                if ((*puVar1 & 0x40) == 0) {
                    if (((cVar13 != '\0') && (((uVar17 != 0 || (cVar14 != '\0')) || (cVar24 != '\0')))) ||
                       ((cVar18 != '\0' && ((char)uVar23 != '\0')))) break;
                    uVar5 = *(uint32_t *)(iVar16 + 0xc + iVar6);
                    piVar2 = (int32_t *)(iVar9 + 0xc18);
                    iVar12 = *(int32_t *)(iVar9 + 0xc1c);
                    uVar10 = 0xfffd;
                    if (uVar5 < 0x10000) {
                        uVar10 = (undefined2)uVar5;
                    }
                    if (*piVar2 == iVar12) {
                        iVar22 = *piVar2 + 1;
                        if (iVar12 == 0) {
                            iVar12 = 8;
                        } else {
                            iVar12 = iVar12 / 2 + iVar12;
                        }
                        if (iVar22 < iVar12) {
                            iVar22 = iVar12;
                        }
                        func_0x00018011f8d0(piVar2, iVar22);
                        iVar27 = *(int64_t *)0x180781f28;
                        cVar24 = var_55h;
                        cVar25 = var_57h;
                    }
                    *(undefined2 *)(*(int64_t *)(iVar9 + 0xc20) + (int64_t)*piVar2 * 2) = uVar10;
                    *piVar2 = *piVar2 + 1;
                    cVar20 = var_56h;
                    cVar18 = (char)var_54h;
                    cVar14 = var_58h;
                    if ((char)var_54h != '\0') {
                        cVar25 = '\x01';
                        var_57h = '\x01';
                    }
                }
            } else if (iVar12 == 7) {
                *(bool *)(iVar9 + 0xc14) = *(char *)(iVar16 + 0xc + iVar6) == '\0';
            }
            uVar23 = (uint64_t)var_54h._4_4_;
            iVar28 = iVar28 + 1;
        } while (iVar28 < *(int32_t *)(iVar9 + 0x1558));
    }
    uVar17 = 0;
    if (0 < iVar28) {
        piVar2 = (int32_t *)(iVar9 + 0x1568);
        do {
            iVar12 = *(int32_t *)(iVar9 + 0x156c);
            puVar19 = (undefined4 *)((uint64_t)uVar17 * 0x1c + *(int64_t *)(iVar9 + 0x1560));
            if (*piVar2 == iVar12) {
                iVar22 = *piVar2 + 1;
                if (iVar12 == 0) {
                    iVar12 = 8;
                } else {
                    iVar12 = iVar12 / 2 + iVar12;
                }
                if (iVar22 < iVar12) {
                    iVar22 = iVar12;
                }
                func_0x00018011f9d0(piVar2, iVar22);
            }
            iVar12 = *piVar2;
            uVar17 = uVar17 + 1;
            uVar4 = puVar19[1];
            uVar7 = puVar19[2];
            uVar8 = puVar19[3];
            iVar27 = *(int64_t *)(iVar9 + 0x1570);
            puVar3 = (undefined4 *)((int64_t)iVar12 * 0x1c + iVar27);
            *puVar3 = *puVar19;
            puVar3[1] = uVar4;
            puVar3[2] = uVar7;
            puVar3[3] = uVar8;
            uVar4 = puVar19[4];
            uVar7 = puVar19[5];
            uVar8 = puVar19[6];
            puVar3 = (undefined4 *)((int64_t)iVar12 * 0x1c + 0xc + iVar27);
            *puVar3 = puVar19[3];
            puVar3[1] = uVar4;
            puVar3[2] = uVar7;
            puVar3[3] = uVar8;
            *piVar2 = *piVar2 + 1;
        } while ((int32_t)uVar17 < iVar28);
    }
    piVar2 = (int32_t *)(iVar9 + 0x1558);
    if (iVar28 == *piVar2) {
        iVar28 = *(int32_t *)(iVar9 + 0x155c);
        if (iVar28 < 0) {
            iVar28 = iVar28 + iVar28 / 2;
            iVar12 = 0;
            if (0 < iVar28) {
                iVar12 = iVar28;
            }
            func_0x00018011f9d0(piVar2, iVar12);
        }
        *piVar2 = 0;
    } else {
        func_0x000180498030(*(int64_t *)(iVar9 + 0x1560), (int64_t)iVar28 * 0x1c + *(int64_t *)(iVar9 + 0x1560), 
                            ((int64_t)*piVar2 - (int64_t)iVar28) * 0x1c);
        *piVar2 = *piVar2 - iVar28;
    }
    if (*(char *)(iVar9 + 0xc14) != '\0') {
        func_0x0001800f52d0(puVar1);
        *(undefined *)(iVar9 + 0xa40) = 0;
        *(undefined4 *)(iVar9 + 0xa44) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa48) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa50) = 0;
        *(undefined4 *)(iVar9 + 0xa54) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa58) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa60) = 0;
        *(undefined4 *)(iVar9 + 0xa64) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa68) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa70) = 0;
        *(undefined4 *)(iVar9 + 0xa74) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa78) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa80) = 0;
        *(undefined4 *)(iVar9 + 0xa84) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa88) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa90) = 0;
        *(undefined4 *)(iVar9 + 0xa94) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa98) = 0xbf800000;
        *(undefined *)(iVar9 + 0xaa0) = 0;
        *(undefined4 *)(iVar9 + 0xaa4) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xaa8) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0x118) = 0xff7fffff;
        *(undefined4 *)(iVar9 + 0x11c) = 0xff7fffff;
        *(undefined4 *)(iVar9 + 0x120) = 0;
        *(undefined4 *)(iVar9 + 0xbc0) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbac) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbc4) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbb0) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbc8) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbb4) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbcc) = 0xbf800000;
        *(undefined4 *)(iVar9 + 3000) = 0xbf800000;
        *(undefined *)(iVar9 + 0x124) = 0;
        *(undefined4 *)(iVar9 + 0xbd0) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbbc) = 0xbf800000;
        *(undefined8 *)(iVar9 + 0x128) = 0;
    }
    func_0x000180459870(var_30h ^ (uint64_t)auStack_78);
    return;
}

// ============================================================
// Function: FUN_1801093f0
// Address: 0x1801093f0
// Size: 959 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_55h
// WARNING: [rz-ghidra] Detected overlap for variable var_56h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_57h

void fcn.1801093d0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4)
{
    uint8_t *puVar1;
    int32_t *piVar2;
    undefined4 *puVar3;
    undefined4 uVar4;
    uint32_t uVar5;
    int64_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    undefined2 uVar10;
    uint32_t uVar11;
    int32_t iVar12;
    char cVar13;
    char cVar14;
    uint32_t uVar15;
    int64_t iVar16;
    uint32_t uVar17;
    char cVar18;
    undefined4 *puVar19;
    char cVar20;
    char *pcVar21;
    int32_t iVar22;
    uint64_t uVar23;
    char cVar24;
    char cVar25;
    uint32_t uVar26;
    int64_t iVar27;
    int32_t iVar28;
    bool bVar29;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_78 [32];
    char var_58h;
    char var_57h;
    char var_56h;
    char var_55h;
    int64_t var_54h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar9 = *(int64_t *)0x180781f28;
    var_30h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_78;
    cVar13 = (char)arg1;
    puVar1 = (uint8_t *)(*(int64_t *)0x180781f28 + 0x30);
    if ((cVar13 == '\0') || (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2c8c) != 1)) {
        var_54h._0_1_ = '\0';
    } else {
        var_54h._0_1_ = '\x01';
    }
    cVar14 = '\0';
    cVar24 = '\0';
    var_58h = '\0';
    cVar20 = '\0';
    var_55h = '\0';
    uVar23 = arg4 & 0xffffffffffffff00;
    var_56h = '\0';
    cVar25 = '\0';
    var_54h._4_4_ = (uint32_t)uVar23;
    var_57h = '\0';
    uVar17 = 0;
    var_38h._0_4_ = 0;
    iVar28 = 0;
    _var_48h = ZEXT816(0);
    iVar27 = *(int64_t *)0x180781f28;
    cVar18 = (char)var_54h;
    if (0 < *(int32_t *)(*(int64_t *)0x180781f28 + 0x1558)) {
        do {
            iVar6 = *(int64_t *)(iVar9 + 0x1560);
            iVar16 = (int64_t)iVar28 * 0x1c;
            iVar12 = *(int32_t *)(iVar16 + iVar6);
            if (iVar12 == 1) {
                if (*(char *)(iVar9 + 0xeb) == '\0') {
                    if ((cVar13 != '\0') &&
                       ((((uVar17 != 0 || (cVar24 != '\0')) || (cVar20 != '\0')) || (cVar25 != '\0')))) break;
                    uVar4 = *(undefined4 *)(iVar16 + 0xc + iVar6);
                    *(undefined4 *)(iVar9 + 0x11c) = *(undefined4 *)(iVar16 + 0x10 + iVar6);
                    *(undefined4 *)(iVar9 + 0x118) = uVar4;
                    *(undefined4 *)(iVar9 + 0x130) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                    var_58h = '\x01';
                    cVar14 = '\x01';
                }
            } else if (iVar12 == 3) {
                uVar5 = *(uint32_t *)(iVar16 + 0xc + iVar6);
                if ((cVar13 != '\0') &&
                   ((((uVar17 >> (uVar5 & 0x1f) & 1) != 0 || (cVar24 != '\0')) ||
                    ((*(int32_t *)(iVar16 + 0x14 + iVar6) == 1 && (cVar14 != '\0')))))) break;
                uVar17 = uVar17 | 1 << (uVar5 & 0x1f);
                puVar1[(int64_t)(int32_t)uVar5 + 0xf0] = *(uint8_t *)(iVar16 + 0x10 + iVar6);
                *(undefined4 *)(iVar9 + 0x130) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                cVar14 = var_58h;
            } else if (iVar12 == 2) {
                if ((cVar13 != '\0') && ((cVar14 != '\0' || (uVar17 != 0)))) break;
                var_55h = '\x01';
                *(float *)(iVar9 + 300) = *(float *)(iVar16 + 0xc + iVar6) + *(float *)(iVar9 + 300);
                *(float *)(iVar9 + 0x128) = *(float *)(iVar16 + 0x10 + iVar6) + *(float *)(iVar9 + 0x128);
                *(undefined4 *)(iVar9 + 0x130) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                cVar24 = '\x01';
            } else if (iVar12 == 4) {
                *(undefined4 *)(iVar9 + 0x134) = *(undefined4 *)(iVar16 + 0xc + iVar6);
            } else if (iVar12 == 5) {
                if ((*puVar1 & 0x40) == 0) {
                    uVar5 = *(uint32_t *)(iVar16 + 0xc + iVar6);
                    uVar11 = uVar5;
                    if ((uVar5 & 0xf000) != 0) {
                        if (uVar5 == 0x1000) {
                            uVar11 = 0x297;
                        } else if (uVar5 == 0x2000) {
                            uVar11 = 0x298;
                        } else if (uVar5 == 0x4000) {
                            uVar11 = 0x299;
                        } else if (uVar5 == 0x8000) {
                            uVar11 = 0x29a;
                        }
                    }
                    pcVar21 = (char *)(((int64_t)(int32_t)uVar11 + -0x1ec) * 0x10 + iVar27);
                    uVar11 = (uint32_t)((int64_t)(pcVar21 + (-0x140 - iVar9)) >> 4);
                    if (((cVar13 != '\0') && (*pcVar21 != *(char *)(iVar16 + 0x10 + iVar6))) &&
                       (((*(uint32_t *)((int64_t)&var_48h + ((int64_t)(int32_t)uVar11 >> 5) * 4) >> (uVar11 & 0x1f) & 1)
                         != 0 || (uVar17 != 0)))) break;
                    uVar15 = -(uint32_t)(*(char *)(iVar27 + 0xab0) != '\0') & 0x1000;
                    uVar26 = uVar15 | 0x4000;
                    if (*(char *)(iVar27 + 0xad0) == '\0') {
                        uVar26 = uVar15;
                    }
                    uVar15 = (uVar26 | uVar5) & 0x1000;
                    if (((uVar15 == 0) || (((uVar26 | uVar5) >> 0xe & 1) != 0)) &&
                       ((*(char *)(iVar27 + 0x8d) == '\0' || (uVar15 == 0)))) {
                        if ((uVar5 & 0xffff0fff) == 0) {
                            bVar29 = false;
                        } else {
                            bVar29 = (*(uint32_t *)
                                       (iVar27 + 0x16b8 + ((int64_t)(int32_t)(uVar5 & 0xffff0fff) + -0x200 >> 5) * 4) >>
                                      (uVar5 & 0x1f) & 1) != 0;
                        }
                    } else {
                        bVar29 = false;
                    }
                    if (((cVar18 != '\0') && (var_57h != '\0')) && (!bVar29)) break;
                    cVar24 = *(char *)(iVar16 + 0x10 + iVar6);
                    if (*pcVar21 != cVar24) {
                        var_56h = '\x01';
                        *(uint32_t *)((int64_t)&var_48h + ((int64_t)(int32_t)uVar11 >> 5) * 4) =
                             *(uint32_t *)((int64_t)&var_48h + ((int64_t)(int32_t)uVar11 >> 5) * 4) |
                             1 << (uVar11 & 0x1f);
                        if ((cVar18 != '\0') && (var_54h._4_4_ = var_54h._4_4_ & 0xff, !bVar29)) {
                            var_54h._4_4_ = 1;
                        }
                    }
                    *pcVar21 = cVar24;
                    *(undefined4 *)(pcVar21 + 0xc) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                    cVar24 = var_55h;
                    cVar20 = var_56h;
                    cVar25 = var_57h;
                    cVar14 = var_58h;
                }
            } else if (iVar12 == 6) {
                if ((*puVar1 & 0x40) == 0) {
                    if (((cVar13 != '\0') && (((uVar17 != 0 || (cVar14 != '\0')) || (cVar24 != '\0')))) ||
                       ((cVar18 != '\0' && ((char)uVar23 != '\0')))) break;
                    uVar5 = *(uint32_t *)(iVar16 + 0xc + iVar6);
                    piVar2 = (int32_t *)(iVar9 + 0xc18);
                    iVar12 = *(int32_t *)(iVar9 + 0xc1c);
                    uVar10 = 0xfffd;
                    if (uVar5 < 0x10000) {
                        uVar10 = (undefined2)uVar5;
                    }
                    if (*piVar2 == iVar12) {
                        iVar22 = *piVar2 + 1;
                        if (iVar12 == 0) {
                            iVar12 = 8;
                        } else {
                            iVar12 = iVar12 / 2 + iVar12;
                        }
                        if (iVar22 < iVar12) {
                            iVar22 = iVar12;
                        }
                        func_0x00018011f8d0(piVar2, iVar22);
                        iVar27 = *(int64_t *)0x180781f28;
                        cVar24 = var_55h;
                        cVar25 = var_57h;
                    }
                    *(undefined2 *)(*(int64_t *)(iVar9 + 0xc20) + (int64_t)*piVar2 * 2) = uVar10;
                    *piVar2 = *piVar2 + 1;
                    cVar20 = var_56h;
                    cVar18 = (char)var_54h;
                    cVar14 = var_58h;
                    if ((char)var_54h != '\0') {
                        cVar25 = '\x01';
                        var_57h = '\x01';
                    }
                }
            } else if (iVar12 == 7) {
                *(bool *)(iVar9 + 0xc14) = *(char *)(iVar16 + 0xc + iVar6) == '\0';
            }
            uVar23 = (uint64_t)var_54h._4_4_;
            iVar28 = iVar28 + 1;
        } while (iVar28 < *(int32_t *)(iVar9 + 0x1558));
    }
    uVar17 = 0;
    if (0 < iVar28) {
        piVar2 = (int32_t *)(iVar9 + 0x1568);
        do {
            iVar12 = *(int32_t *)(iVar9 + 0x156c);
            puVar19 = (undefined4 *)((uint64_t)uVar17 * 0x1c + *(int64_t *)(iVar9 + 0x1560));
            if (*piVar2 == iVar12) {
                iVar22 = *piVar2 + 1;
                if (iVar12 == 0) {
                    iVar12 = 8;
                } else {
                    iVar12 = iVar12 / 2 + iVar12;
                }
                if (iVar22 < iVar12) {
                    iVar22 = iVar12;
                }
                func_0x00018011f9d0(piVar2, iVar22);
            }
            iVar12 = *piVar2;
            uVar17 = uVar17 + 1;
            uVar4 = puVar19[1];
            uVar7 = puVar19[2];
            uVar8 = puVar19[3];
            iVar27 = *(int64_t *)(iVar9 + 0x1570);
            puVar3 = (undefined4 *)((int64_t)iVar12 * 0x1c + iVar27);
            *puVar3 = *puVar19;
            puVar3[1] = uVar4;
            puVar3[2] = uVar7;
            puVar3[3] = uVar8;
            uVar4 = puVar19[4];
            uVar7 = puVar19[5];
            uVar8 = puVar19[6];
            puVar3 = (undefined4 *)((int64_t)iVar12 * 0x1c + 0xc + iVar27);
            *puVar3 = puVar19[3];
            puVar3[1] = uVar4;
            puVar3[2] = uVar7;
            puVar3[3] = uVar8;
            *piVar2 = *piVar2 + 1;
        } while ((int32_t)uVar17 < iVar28);
    }
    piVar2 = (int32_t *)(iVar9 + 0x1558);
    if (iVar28 == *piVar2) {
        iVar28 = *(int32_t *)(iVar9 + 0x155c);
        if (iVar28 < 0) {
            iVar28 = iVar28 + iVar28 / 2;
            iVar12 = 0;
            if (0 < iVar28) {
                iVar12 = iVar28;
            }
            func_0x00018011f9d0(piVar2, iVar12);
        }
        *piVar2 = 0;
    } else {
        func_0x000180498030(*(int64_t *)(iVar9 + 0x1560), (int64_t)iVar28 * 0x1c + *(int64_t *)(iVar9 + 0x1560), 
                            ((int64_t)*piVar2 - (int64_t)iVar28) * 0x1c);
        *piVar2 = *piVar2 - iVar28;
    }
    if (*(char *)(iVar9 + 0xc14) != '\0') {
        func_0x0001800f52d0(puVar1);
        *(undefined *)(iVar9 + 0xa40) = 0;
        *(undefined4 *)(iVar9 + 0xa44) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa48) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa50) = 0;
        *(undefined4 *)(iVar9 + 0xa54) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa58) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa60) = 0;
        *(undefined4 *)(iVar9 + 0xa64) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa68) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa70) = 0;
        *(undefined4 *)(iVar9 + 0xa74) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa78) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa80) = 0;
        *(undefined4 *)(iVar9 + 0xa84) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa88) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa90) = 0;
        *(undefined4 *)(iVar9 + 0xa94) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa98) = 0xbf800000;
        *(undefined *)(iVar9 + 0xaa0) = 0;
        *(undefined4 *)(iVar9 + 0xaa4) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xaa8) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0x118) = 0xff7fffff;
        *(undefined4 *)(iVar9 + 0x11c) = 0xff7fffff;
        *(undefined4 *)(iVar9 + 0x120) = 0;
        *(undefined4 *)(iVar9 + 0xbc0) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbac) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbc4) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbb0) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbc8) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbb4) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbcc) = 0xbf800000;
        *(undefined4 *)(iVar9 + 3000) = 0xbf800000;
        *(undefined *)(iVar9 + 0x124) = 0;
        *(undefined4 *)(iVar9 + 0xbd0) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbbc) = 0xbf800000;
        *(undefined8 *)(iVar9 + 0x128) = 0;
    }
    func_0x000180459870(var_30h ^ (uint64_t)auStack_78);
    return;
}

// ============================================================
// Function: FUN_1801097af
// Address: 0x1801097af
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_55h
// WARNING: [rz-ghidra] Detected overlap for variable var_56h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_57h

void fcn.1801093d0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4)
{
    uint8_t *puVar1;
    int32_t *piVar2;
    undefined4 *puVar3;
    undefined4 uVar4;
    uint32_t uVar5;
    int64_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    undefined2 uVar10;
    uint32_t uVar11;
    int32_t iVar12;
    char cVar13;
    char cVar14;
    uint32_t uVar15;
    int64_t iVar16;
    uint32_t uVar17;
    char cVar18;
    undefined4 *puVar19;
    char cVar20;
    char *pcVar21;
    int32_t iVar22;
    uint64_t uVar23;
    char cVar24;
    char cVar25;
    uint32_t uVar26;
    int64_t iVar27;
    int32_t iVar28;
    bool bVar29;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_78 [32];
    char var_58h;
    char var_57h;
    char var_56h;
    char var_55h;
    int64_t var_54h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar9 = *(int64_t *)0x180781f28;
    var_30h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_78;
    cVar13 = (char)arg1;
    puVar1 = (uint8_t *)(*(int64_t *)0x180781f28 + 0x30);
    if ((cVar13 == '\0') || (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2c8c) != 1)) {
        var_54h._0_1_ = '\0';
    } else {
        var_54h._0_1_ = '\x01';
    }
    cVar14 = '\0';
    cVar24 = '\0';
    var_58h = '\0';
    cVar20 = '\0';
    var_55h = '\0';
    uVar23 = arg4 & 0xffffffffffffff00;
    var_56h = '\0';
    cVar25 = '\0';
    var_54h._4_4_ = (uint32_t)uVar23;
    var_57h = '\0';
    uVar17 = 0;
    var_38h._0_4_ = 0;
    iVar28 = 0;
    _var_48h = ZEXT816(0);
    iVar27 = *(int64_t *)0x180781f28;
    cVar18 = (char)var_54h;
    if (0 < *(int32_t *)(*(int64_t *)0x180781f28 + 0x1558)) {
        do {
            iVar6 = *(int64_t *)(iVar9 + 0x1560);
            iVar16 = (int64_t)iVar28 * 0x1c;
            iVar12 = *(int32_t *)(iVar16 + iVar6);
            if (iVar12 == 1) {
                if (*(char *)(iVar9 + 0xeb) == '\0') {
                    if ((cVar13 != '\0') &&
                       ((((uVar17 != 0 || (cVar24 != '\0')) || (cVar20 != '\0')) || (cVar25 != '\0')))) break;
                    uVar4 = *(undefined4 *)(iVar16 + 0xc + iVar6);
                    *(undefined4 *)(iVar9 + 0x11c) = *(undefined4 *)(iVar16 + 0x10 + iVar6);
                    *(undefined4 *)(iVar9 + 0x118) = uVar4;
                    *(undefined4 *)(iVar9 + 0x130) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                    var_58h = '\x01';
                    cVar14 = '\x01';
                }
            } else if (iVar12 == 3) {
                uVar5 = *(uint32_t *)(iVar16 + 0xc + iVar6);
                if ((cVar13 != '\0') &&
                   ((((uVar17 >> (uVar5 & 0x1f) & 1) != 0 || (cVar24 != '\0')) ||
                    ((*(int32_t *)(iVar16 + 0x14 + iVar6) == 1 && (cVar14 != '\0')))))) break;
                uVar17 = uVar17 | 1 << (uVar5 & 0x1f);
                puVar1[(int64_t)(int32_t)uVar5 + 0xf0] = *(uint8_t *)(iVar16 + 0x10 + iVar6);
                *(undefined4 *)(iVar9 + 0x130) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                cVar14 = var_58h;
            } else if (iVar12 == 2) {
                if ((cVar13 != '\0') && ((cVar14 != '\0' || (uVar17 != 0)))) break;
                var_55h = '\x01';
                *(float *)(iVar9 + 300) = *(float *)(iVar16 + 0xc + iVar6) + *(float *)(iVar9 + 300);
                *(float *)(iVar9 + 0x128) = *(float *)(iVar16 + 0x10 + iVar6) + *(float *)(iVar9 + 0x128);
                *(undefined4 *)(iVar9 + 0x130) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                cVar24 = '\x01';
            } else if (iVar12 == 4) {
                *(undefined4 *)(iVar9 + 0x134) = *(undefined4 *)(iVar16 + 0xc + iVar6);
            } else if (iVar12 == 5) {
                if ((*puVar1 & 0x40) == 0) {
                    uVar5 = *(uint32_t *)(iVar16 + 0xc + iVar6);
                    uVar11 = uVar5;
                    if ((uVar5 & 0xf000) != 0) {
                        if (uVar5 == 0x1000) {
                            uVar11 = 0x297;
                        } else if (uVar5 == 0x2000) {
                            uVar11 = 0x298;
                        } else if (uVar5 == 0x4000) {
                            uVar11 = 0x299;
                        } else if (uVar5 == 0x8000) {
                            uVar11 = 0x29a;
                        }
                    }
                    pcVar21 = (char *)(((int64_t)(int32_t)uVar11 + -0x1ec) * 0x10 + iVar27);
                    uVar11 = (uint32_t)((int64_t)(pcVar21 + (-0x140 - iVar9)) >> 4);
                    if (((cVar13 != '\0') && (*pcVar21 != *(char *)(iVar16 + 0x10 + iVar6))) &&
                       (((*(uint32_t *)((int64_t)&var_48h + ((int64_t)(int32_t)uVar11 >> 5) * 4) >> (uVar11 & 0x1f) & 1)
                         != 0 || (uVar17 != 0)))) break;
                    uVar15 = -(uint32_t)(*(char *)(iVar27 + 0xab0) != '\0') & 0x1000;
                    uVar26 = uVar15 | 0x4000;
                    if (*(char *)(iVar27 + 0xad0) == '\0') {
                        uVar26 = uVar15;
                    }
                    uVar15 = (uVar26 | uVar5) & 0x1000;
                    if (((uVar15 == 0) || (((uVar26 | uVar5) >> 0xe & 1) != 0)) &&
                       ((*(char *)(iVar27 + 0x8d) == '\0' || (uVar15 == 0)))) {
                        if ((uVar5 & 0xffff0fff) == 0) {
                            bVar29 = false;
                        } else {
                            bVar29 = (*(uint32_t *)
                                       (iVar27 + 0x16b8 + ((int64_t)(int32_t)(uVar5 & 0xffff0fff) + -0x200 >> 5) * 4) >>
                                      (uVar5 & 0x1f) & 1) != 0;
                        }
                    } else {
                        bVar29 = false;
                    }
                    if (((cVar18 != '\0') && (var_57h != '\0')) && (!bVar29)) break;
                    cVar24 = *(char *)(iVar16 + 0x10 + iVar6);
                    if (*pcVar21 != cVar24) {
                        var_56h = '\x01';
                        *(uint32_t *)((int64_t)&var_48h + ((int64_t)(int32_t)uVar11 >> 5) * 4) =
                             *(uint32_t *)((int64_t)&var_48h + ((int64_t)(int32_t)uVar11 >> 5) * 4) |
                             1 << (uVar11 & 0x1f);
                        if ((cVar18 != '\0') && (var_54h._4_4_ = var_54h._4_4_ & 0xff, !bVar29)) {
                            var_54h._4_4_ = 1;
                        }
                    }
                    *pcVar21 = cVar24;
                    *(undefined4 *)(pcVar21 + 0xc) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                    cVar24 = var_55h;
                    cVar20 = var_56h;
                    cVar25 = var_57h;
                    cVar14 = var_58h;
                }
            } else if (iVar12 == 6) {
                if ((*puVar1 & 0x40) == 0) {
                    if (((cVar13 != '\0') && (((uVar17 != 0 || (cVar14 != '\0')) || (cVar24 != '\0')))) ||
                       ((cVar18 != '\0' && ((char)uVar23 != '\0')))) break;
                    uVar5 = *(uint32_t *)(iVar16 + 0xc + iVar6);
                    piVar2 = (int32_t *)(iVar9 + 0xc18);
                    iVar12 = *(int32_t *)(iVar9 + 0xc1c);
                    uVar10 = 0xfffd;
                    if (uVar5 < 0x10000) {
                        uVar10 = (undefined2)uVar5;
                    }
                    if (*piVar2 == iVar12) {
                        iVar22 = *piVar2 + 1;
                        if (iVar12 == 0) {
                            iVar12 = 8;
                        } else {
                            iVar12 = iVar12 / 2 + iVar12;
                        }
                        if (iVar22 < iVar12) {
                            iVar22 = iVar12;
                        }
                        func_0x00018011f8d0(piVar2, iVar22);
                        iVar27 = *(int64_t *)0x180781f28;
                        cVar24 = var_55h;
                        cVar25 = var_57h;
                    }
                    *(undefined2 *)(*(int64_t *)(iVar9 + 0xc20) + (int64_t)*piVar2 * 2) = uVar10;
                    *piVar2 = *piVar2 + 1;
                    cVar20 = var_56h;
                    cVar18 = (char)var_54h;
                    cVar14 = var_58h;
                    if ((char)var_54h != '\0') {
                        cVar25 = '\x01';
                        var_57h = '\x01';
                    }
                }
            } else if (iVar12 == 7) {
                *(bool *)(iVar9 + 0xc14) = *(char *)(iVar16 + 0xc + iVar6) == '\0';
            }
            uVar23 = (uint64_t)var_54h._4_4_;
            iVar28 = iVar28 + 1;
        } while (iVar28 < *(int32_t *)(iVar9 + 0x1558));
    }
    uVar17 = 0;
    if (0 < iVar28) {
        piVar2 = (int32_t *)(iVar9 + 0x1568);
        do {
            iVar12 = *(int32_t *)(iVar9 + 0x156c);
            puVar19 = (undefined4 *)((uint64_t)uVar17 * 0x1c + *(int64_t *)(iVar9 + 0x1560));
            if (*piVar2 == iVar12) {
                iVar22 = *piVar2 + 1;
                if (iVar12 == 0) {
                    iVar12 = 8;
                } else {
                    iVar12 = iVar12 / 2 + iVar12;
                }
                if (iVar22 < iVar12) {
                    iVar22 = iVar12;
                }
                func_0x00018011f9d0(piVar2, iVar22);
            }
            iVar12 = *piVar2;
            uVar17 = uVar17 + 1;
            uVar4 = puVar19[1];
            uVar7 = puVar19[2];
            uVar8 = puVar19[3];
            iVar27 = *(int64_t *)(iVar9 + 0x1570);
            puVar3 = (undefined4 *)((int64_t)iVar12 * 0x1c + iVar27);
            *puVar3 = *puVar19;
            puVar3[1] = uVar4;
            puVar3[2] = uVar7;
            puVar3[3] = uVar8;
            uVar4 = puVar19[4];
            uVar7 = puVar19[5];
            uVar8 = puVar19[6];
            puVar3 = (undefined4 *)((int64_t)iVar12 * 0x1c + 0xc + iVar27);
            *puVar3 = puVar19[3];
            puVar3[1] = uVar4;
            puVar3[2] = uVar7;
            puVar3[3] = uVar8;
            *piVar2 = *piVar2 + 1;
        } while ((int32_t)uVar17 < iVar28);
    }
    piVar2 = (int32_t *)(iVar9 + 0x1558);
    if (iVar28 == *piVar2) {
        iVar28 = *(int32_t *)(iVar9 + 0x155c);
        if (iVar28 < 0) {
            iVar28 = iVar28 + iVar28 / 2;
            iVar12 = 0;
            if (0 < iVar28) {
                iVar12 = iVar28;
            }
            func_0x00018011f9d0(piVar2, iVar12);
        }
        *piVar2 = 0;
    } else {
        func_0x000180498030(*(int64_t *)(iVar9 + 0x1560), (int64_t)iVar28 * 0x1c + *(int64_t *)(iVar9 + 0x1560), 
                            ((int64_t)*piVar2 - (int64_t)iVar28) * 0x1c);
        *piVar2 = *piVar2 - iVar28;
    }
    if (*(char *)(iVar9 + 0xc14) != '\0') {
        func_0x0001800f52d0(puVar1);
        *(undefined *)(iVar9 + 0xa40) = 0;
        *(undefined4 *)(iVar9 + 0xa44) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa48) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa50) = 0;
        *(undefined4 *)(iVar9 + 0xa54) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa58) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa60) = 0;
        *(undefined4 *)(iVar9 + 0xa64) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa68) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa70) = 0;
        *(undefined4 *)(iVar9 + 0xa74) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa78) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa80) = 0;
        *(undefined4 *)(iVar9 + 0xa84) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa88) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa90) = 0;
        *(undefined4 *)(iVar9 + 0xa94) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa98) = 0xbf800000;
        *(undefined *)(iVar9 + 0xaa0) = 0;
        *(undefined4 *)(iVar9 + 0xaa4) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xaa8) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0x118) = 0xff7fffff;
        *(undefined4 *)(iVar9 + 0x11c) = 0xff7fffff;
        *(undefined4 *)(iVar9 + 0x120) = 0;
        *(undefined4 *)(iVar9 + 0xbc0) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbac) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbc4) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbb0) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbc8) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbb4) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbcc) = 0xbf800000;
        *(undefined4 *)(iVar9 + 3000) = 0xbf800000;
        *(undefined *)(iVar9 + 0x124) = 0;
        *(undefined4 *)(iVar9 + 0xbd0) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbbc) = 0xbf800000;
        *(undefined8 *)(iVar9 + 0x128) = 0;
    }
    func_0x000180459870(var_30h ^ (uint64_t)auStack_78);
    return;
}

// ============================================================
// Function: FUN_1801097f9
// Address: 0x1801097f9
// Size: 224 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_55h
// WARNING: [rz-ghidra] Detected overlap for variable var_56h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_57h

void fcn.1801093d0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4)
{
    uint8_t *puVar1;
    int32_t *piVar2;
    undefined4 *puVar3;
    undefined4 uVar4;
    uint32_t uVar5;
    int64_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    undefined2 uVar10;
    uint32_t uVar11;
    int32_t iVar12;
    char cVar13;
    char cVar14;
    uint32_t uVar15;
    int64_t iVar16;
    uint32_t uVar17;
    char cVar18;
    undefined4 *puVar19;
    char cVar20;
    char *pcVar21;
    int32_t iVar22;
    uint64_t uVar23;
    char cVar24;
    char cVar25;
    uint32_t uVar26;
    int64_t iVar27;
    int32_t iVar28;
    bool bVar29;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_78 [32];
    char var_58h;
    char var_57h;
    char var_56h;
    char var_55h;
    int64_t var_54h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar9 = *(int64_t *)0x180781f28;
    var_30h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_78;
    cVar13 = (char)arg1;
    puVar1 = (uint8_t *)(*(int64_t *)0x180781f28 + 0x30);
    if ((cVar13 == '\0') || (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2c8c) != 1)) {
        var_54h._0_1_ = '\0';
    } else {
        var_54h._0_1_ = '\x01';
    }
    cVar14 = '\0';
    cVar24 = '\0';
    var_58h = '\0';
    cVar20 = '\0';
    var_55h = '\0';
    uVar23 = arg4 & 0xffffffffffffff00;
    var_56h = '\0';
    cVar25 = '\0';
    var_54h._4_4_ = (uint32_t)uVar23;
    var_57h = '\0';
    uVar17 = 0;
    var_38h._0_4_ = 0;
    iVar28 = 0;
    _var_48h = ZEXT816(0);
    iVar27 = *(int64_t *)0x180781f28;
    cVar18 = (char)var_54h;
    if (0 < *(int32_t *)(*(int64_t *)0x180781f28 + 0x1558)) {
        do {
            iVar6 = *(int64_t *)(iVar9 + 0x1560);
            iVar16 = (int64_t)iVar28 * 0x1c;
            iVar12 = *(int32_t *)(iVar16 + iVar6);
            if (iVar12 == 1) {
                if (*(char *)(iVar9 + 0xeb) == '\0') {
                    if ((cVar13 != '\0') &&
                       ((((uVar17 != 0 || (cVar24 != '\0')) || (cVar20 != '\0')) || (cVar25 != '\0')))) break;
                    uVar4 = *(undefined4 *)(iVar16 + 0xc + iVar6);
                    *(undefined4 *)(iVar9 + 0x11c) = *(undefined4 *)(iVar16 + 0x10 + iVar6);
                    *(undefined4 *)(iVar9 + 0x118) = uVar4;
                    *(undefined4 *)(iVar9 + 0x130) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                    var_58h = '\x01';
                    cVar14 = '\x01';
                }
            } else if (iVar12 == 3) {
                uVar5 = *(uint32_t *)(iVar16 + 0xc + iVar6);
                if ((cVar13 != '\0') &&
                   ((((uVar17 >> (uVar5 & 0x1f) & 1) != 0 || (cVar24 != '\0')) ||
                    ((*(int32_t *)(iVar16 + 0x14 + iVar6) == 1 && (cVar14 != '\0')))))) break;
                uVar17 = uVar17 | 1 << (uVar5 & 0x1f);
                puVar1[(int64_t)(int32_t)uVar5 + 0xf0] = *(uint8_t *)(iVar16 + 0x10 + iVar6);
                *(undefined4 *)(iVar9 + 0x130) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                cVar14 = var_58h;
            } else if (iVar12 == 2) {
                if ((cVar13 != '\0') && ((cVar14 != '\0' || (uVar17 != 0)))) break;
                var_55h = '\x01';
                *(float *)(iVar9 + 300) = *(float *)(iVar16 + 0xc + iVar6) + *(float *)(iVar9 + 300);
                *(float *)(iVar9 + 0x128) = *(float *)(iVar16 + 0x10 + iVar6) + *(float *)(iVar9 + 0x128);
                *(undefined4 *)(iVar9 + 0x130) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                cVar24 = '\x01';
            } else if (iVar12 == 4) {
                *(undefined4 *)(iVar9 + 0x134) = *(undefined4 *)(iVar16 + 0xc + iVar6);
            } else if (iVar12 == 5) {
                if ((*puVar1 & 0x40) == 0) {
                    uVar5 = *(uint32_t *)(iVar16 + 0xc + iVar6);
                    uVar11 = uVar5;
                    if ((uVar5 & 0xf000) != 0) {
                        if (uVar5 == 0x1000) {
                            uVar11 = 0x297;
                        } else if (uVar5 == 0x2000) {
                            uVar11 = 0x298;
                        } else if (uVar5 == 0x4000) {
                            uVar11 = 0x299;
                        } else if (uVar5 == 0x8000) {
                            uVar11 = 0x29a;
                        }
                    }
                    pcVar21 = (char *)(((int64_t)(int32_t)uVar11 + -0x1ec) * 0x10 + iVar27);
                    uVar11 = (uint32_t)((int64_t)(pcVar21 + (-0x140 - iVar9)) >> 4);
                    if (((cVar13 != '\0') && (*pcVar21 != *(char *)(iVar16 + 0x10 + iVar6))) &&
                       (((*(uint32_t *)((int64_t)&var_48h + ((int64_t)(int32_t)uVar11 >> 5) * 4) >> (uVar11 & 0x1f) & 1)
                         != 0 || (uVar17 != 0)))) break;
                    uVar15 = -(uint32_t)(*(char *)(iVar27 + 0xab0) != '\0') & 0x1000;
                    uVar26 = uVar15 | 0x4000;
                    if (*(char *)(iVar27 + 0xad0) == '\0') {
                        uVar26 = uVar15;
                    }
                    uVar15 = (uVar26 | uVar5) & 0x1000;
                    if (((uVar15 == 0) || (((uVar26 | uVar5) >> 0xe & 1) != 0)) &&
                       ((*(char *)(iVar27 + 0x8d) == '\0' || (uVar15 == 0)))) {
                        if ((uVar5 & 0xffff0fff) == 0) {
                            bVar29 = false;
                        } else {
                            bVar29 = (*(uint32_t *)
                                       (iVar27 + 0x16b8 + ((int64_t)(int32_t)(uVar5 & 0xffff0fff) + -0x200 >> 5) * 4) >>
                                      (uVar5 & 0x1f) & 1) != 0;
                        }
                    } else {
                        bVar29 = false;
                    }
                    if (((cVar18 != '\0') && (var_57h != '\0')) && (!bVar29)) break;
                    cVar24 = *(char *)(iVar16 + 0x10 + iVar6);
                    if (*pcVar21 != cVar24) {
                        var_56h = '\x01';
                        *(uint32_t *)((int64_t)&var_48h + ((int64_t)(int32_t)uVar11 >> 5) * 4) =
                             *(uint32_t *)((int64_t)&var_48h + ((int64_t)(int32_t)uVar11 >> 5) * 4) |
                             1 << (uVar11 & 0x1f);
                        if ((cVar18 != '\0') && (var_54h._4_4_ = var_54h._4_4_ & 0xff, !bVar29)) {
                            var_54h._4_4_ = 1;
                        }
                    }
                    *pcVar21 = cVar24;
                    *(undefined4 *)(pcVar21 + 0xc) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                    cVar24 = var_55h;
                    cVar20 = var_56h;
                    cVar25 = var_57h;
                    cVar14 = var_58h;
                }
            } else if (iVar12 == 6) {
                if ((*puVar1 & 0x40) == 0) {
                    if (((cVar13 != '\0') && (((uVar17 != 0 || (cVar14 != '\0')) || (cVar24 != '\0')))) ||
                       ((cVar18 != '\0' && ((char)uVar23 != '\0')))) break;
                    uVar5 = *(uint32_t *)(iVar16 + 0xc + iVar6);
                    piVar2 = (int32_t *)(iVar9 + 0xc18);
                    iVar12 = *(int32_t *)(iVar9 + 0xc1c);
                    uVar10 = 0xfffd;
                    if (uVar5 < 0x10000) {
                        uVar10 = (undefined2)uVar5;
                    }
                    if (*piVar2 == iVar12) {
                        iVar22 = *piVar2 + 1;
                        if (iVar12 == 0) {
                            iVar12 = 8;
                        } else {
                            iVar12 = iVar12 / 2 + iVar12;
                        }
                        if (iVar22 < iVar12) {
                            iVar22 = iVar12;
                        }
                        func_0x00018011f8d0(piVar2, iVar22);
                        iVar27 = *(int64_t *)0x180781f28;
                        cVar24 = var_55h;
                        cVar25 = var_57h;
                    }
                    *(undefined2 *)(*(int64_t *)(iVar9 + 0xc20) + (int64_t)*piVar2 * 2) = uVar10;
                    *piVar2 = *piVar2 + 1;
                    cVar20 = var_56h;
                    cVar18 = (char)var_54h;
                    cVar14 = var_58h;
                    if ((char)var_54h != '\0') {
                        cVar25 = '\x01';
                        var_57h = '\x01';
                    }
                }
            } else if (iVar12 == 7) {
                *(bool *)(iVar9 + 0xc14) = *(char *)(iVar16 + 0xc + iVar6) == '\0';
            }
            uVar23 = (uint64_t)var_54h._4_4_;
            iVar28 = iVar28 + 1;
        } while (iVar28 < *(int32_t *)(iVar9 + 0x1558));
    }
    uVar17 = 0;
    if (0 < iVar28) {
        piVar2 = (int32_t *)(iVar9 + 0x1568);
        do {
            iVar12 = *(int32_t *)(iVar9 + 0x156c);
            puVar19 = (undefined4 *)((uint64_t)uVar17 * 0x1c + *(int64_t *)(iVar9 + 0x1560));
            if (*piVar2 == iVar12) {
                iVar22 = *piVar2 + 1;
                if (iVar12 == 0) {
                    iVar12 = 8;
                } else {
                    iVar12 = iVar12 / 2 + iVar12;
                }
                if (iVar22 < iVar12) {
                    iVar22 = iVar12;
                }
                func_0x00018011f9d0(piVar2, iVar22);
            }
            iVar12 = *piVar2;
            uVar17 = uVar17 + 1;
            uVar4 = puVar19[1];
            uVar7 = puVar19[2];
            uVar8 = puVar19[3];
            iVar27 = *(int64_t *)(iVar9 + 0x1570);
            puVar3 = (undefined4 *)((int64_t)iVar12 * 0x1c + iVar27);
            *puVar3 = *puVar19;
            puVar3[1] = uVar4;
            puVar3[2] = uVar7;
            puVar3[3] = uVar8;
            uVar4 = puVar19[4];
            uVar7 = puVar19[5];
            uVar8 = puVar19[6];
            puVar3 = (undefined4 *)((int64_t)iVar12 * 0x1c + 0xc + iVar27);
            *puVar3 = puVar19[3];
            puVar3[1] = uVar4;
            puVar3[2] = uVar7;
            puVar3[3] = uVar8;
            *piVar2 = *piVar2 + 1;
        } while ((int32_t)uVar17 < iVar28);
    }
    piVar2 = (int32_t *)(iVar9 + 0x1558);
    if (iVar28 == *piVar2) {
        iVar28 = *(int32_t *)(iVar9 + 0x155c);
        if (iVar28 < 0) {
            iVar28 = iVar28 + iVar28 / 2;
            iVar12 = 0;
            if (0 < iVar28) {
                iVar12 = iVar28;
            }
            func_0x00018011f9d0(piVar2, iVar12);
        }
        *piVar2 = 0;
    } else {
        func_0x000180498030(*(int64_t *)(iVar9 + 0x1560), (int64_t)iVar28 * 0x1c + *(int64_t *)(iVar9 + 0x1560), 
                            ((int64_t)*piVar2 - (int64_t)iVar28) * 0x1c);
        *piVar2 = *piVar2 - iVar28;
    }
    if (*(char *)(iVar9 + 0xc14) != '\0') {
        func_0x0001800f52d0(puVar1);
        *(undefined *)(iVar9 + 0xa40) = 0;
        *(undefined4 *)(iVar9 + 0xa44) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa48) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa50) = 0;
        *(undefined4 *)(iVar9 + 0xa54) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa58) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa60) = 0;
        *(undefined4 *)(iVar9 + 0xa64) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa68) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa70) = 0;
        *(undefined4 *)(iVar9 + 0xa74) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa78) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa80) = 0;
        *(undefined4 *)(iVar9 + 0xa84) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa88) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa90) = 0;
        *(undefined4 *)(iVar9 + 0xa94) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa98) = 0xbf800000;
        *(undefined *)(iVar9 + 0xaa0) = 0;
        *(undefined4 *)(iVar9 + 0xaa4) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xaa8) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0x118) = 0xff7fffff;
        *(undefined4 *)(iVar9 + 0x11c) = 0xff7fffff;
        *(undefined4 *)(iVar9 + 0x120) = 0;
        *(undefined4 *)(iVar9 + 0xbc0) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbac) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbc4) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbb0) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbc8) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbb4) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbcc) = 0xbf800000;
        *(undefined4 *)(iVar9 + 3000) = 0xbf800000;
        *(undefined *)(iVar9 + 0x124) = 0;
        *(undefined4 *)(iVar9 + 0xbd0) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbbc) = 0xbf800000;
        *(undefined8 *)(iVar9 + 0x128) = 0;
    }
    func_0x000180459870(var_30h ^ (uint64_t)auStack_78);
    return;
}

// ============================================================
// Function: FUN_1801098d9
// Address: 0x1801098d9
// Size: 86 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_55h
// WARNING: [rz-ghidra] Detected overlap for variable var_56h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_57h

void fcn.1801093d0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4)
{
    uint8_t *puVar1;
    int32_t *piVar2;
    undefined4 *puVar3;
    undefined4 uVar4;
    uint32_t uVar5;
    int64_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    undefined2 uVar10;
    uint32_t uVar11;
    int32_t iVar12;
    char cVar13;
    char cVar14;
    uint32_t uVar15;
    int64_t iVar16;
    uint32_t uVar17;
    char cVar18;
    undefined4 *puVar19;
    char cVar20;
    char *pcVar21;
    int32_t iVar22;
    uint64_t uVar23;
    char cVar24;
    char cVar25;
    uint32_t uVar26;
    int64_t iVar27;
    int32_t iVar28;
    bool bVar29;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_78 [32];
    char var_58h;
    char var_57h;
    char var_56h;
    char var_55h;
    int64_t var_54h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar9 = *(int64_t *)0x180781f28;
    var_30h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_78;
    cVar13 = (char)arg1;
    puVar1 = (uint8_t *)(*(int64_t *)0x180781f28 + 0x30);
    if ((cVar13 == '\0') || (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2c8c) != 1)) {
        var_54h._0_1_ = '\0';
    } else {
        var_54h._0_1_ = '\x01';
    }
    cVar14 = '\0';
    cVar24 = '\0';
    var_58h = '\0';
    cVar20 = '\0';
    var_55h = '\0';
    uVar23 = arg4 & 0xffffffffffffff00;
    var_56h = '\0';
    cVar25 = '\0';
    var_54h._4_4_ = (uint32_t)uVar23;
    var_57h = '\0';
    uVar17 = 0;
    var_38h._0_4_ = 0;
    iVar28 = 0;
    _var_48h = ZEXT816(0);
    iVar27 = *(int64_t *)0x180781f28;
    cVar18 = (char)var_54h;
    if (0 < *(int32_t *)(*(int64_t *)0x180781f28 + 0x1558)) {
        do {
            iVar6 = *(int64_t *)(iVar9 + 0x1560);
            iVar16 = (int64_t)iVar28 * 0x1c;
            iVar12 = *(int32_t *)(iVar16 + iVar6);
            if (iVar12 == 1) {
                if (*(char *)(iVar9 + 0xeb) == '\0') {
                    if ((cVar13 != '\0') &&
                       ((((uVar17 != 0 || (cVar24 != '\0')) || (cVar20 != '\0')) || (cVar25 != '\0')))) break;
                    uVar4 = *(undefined4 *)(iVar16 + 0xc + iVar6);
                    *(undefined4 *)(iVar9 + 0x11c) = *(undefined4 *)(iVar16 + 0x10 + iVar6);
                    *(undefined4 *)(iVar9 + 0x118) = uVar4;
                    *(undefined4 *)(iVar9 + 0x130) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                    var_58h = '\x01';
                    cVar14 = '\x01';
                }
            } else if (iVar12 == 3) {
                uVar5 = *(uint32_t *)(iVar16 + 0xc + iVar6);
                if ((cVar13 != '\0') &&
                   ((((uVar17 >> (uVar5 & 0x1f) & 1) != 0 || (cVar24 != '\0')) ||
                    ((*(int32_t *)(iVar16 + 0x14 + iVar6) == 1 && (cVar14 != '\0')))))) break;
                uVar17 = uVar17 | 1 << (uVar5 & 0x1f);
                puVar1[(int64_t)(int32_t)uVar5 + 0xf0] = *(uint8_t *)(iVar16 + 0x10 + iVar6);
                *(undefined4 *)(iVar9 + 0x130) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                cVar14 = var_58h;
            } else if (iVar12 == 2) {
                if ((cVar13 != '\0') && ((cVar14 != '\0' || (uVar17 != 0)))) break;
                var_55h = '\x01';
                *(float *)(iVar9 + 300) = *(float *)(iVar16 + 0xc + iVar6) + *(float *)(iVar9 + 300);
                *(float *)(iVar9 + 0x128) = *(float *)(iVar16 + 0x10 + iVar6) + *(float *)(iVar9 + 0x128);
                *(undefined4 *)(iVar9 + 0x130) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                cVar24 = '\x01';
            } else if (iVar12 == 4) {
                *(undefined4 *)(iVar9 + 0x134) = *(undefined4 *)(iVar16 + 0xc + iVar6);
            } else if (iVar12 == 5) {
                if ((*puVar1 & 0x40) == 0) {
                    uVar5 = *(uint32_t *)(iVar16 + 0xc + iVar6);
                    uVar11 = uVar5;
                    if ((uVar5 & 0xf000) != 0) {
                        if (uVar5 == 0x1000) {
                            uVar11 = 0x297;
                        } else if (uVar5 == 0x2000) {
                            uVar11 = 0x298;
                        } else if (uVar5 == 0x4000) {
                            uVar11 = 0x299;
                        } else if (uVar5 == 0x8000) {
                            uVar11 = 0x29a;
                        }
                    }
                    pcVar21 = (char *)(((int64_t)(int32_t)uVar11 + -0x1ec) * 0x10 + iVar27);
                    uVar11 = (uint32_t)((int64_t)(pcVar21 + (-0x140 - iVar9)) >> 4);
                    if (((cVar13 != '\0') && (*pcVar21 != *(char *)(iVar16 + 0x10 + iVar6))) &&
                       (((*(uint32_t *)((int64_t)&var_48h + ((int64_t)(int32_t)uVar11 >> 5) * 4) >> (uVar11 & 0x1f) & 1)
                         != 0 || (uVar17 != 0)))) break;
                    uVar15 = -(uint32_t)(*(char *)(iVar27 + 0xab0) != '\0') & 0x1000;
                    uVar26 = uVar15 | 0x4000;
                    if (*(char *)(iVar27 + 0xad0) == '\0') {
                        uVar26 = uVar15;
                    }
                    uVar15 = (uVar26 | uVar5) & 0x1000;
                    if (((uVar15 == 0) || (((uVar26 | uVar5) >> 0xe & 1) != 0)) &&
                       ((*(char *)(iVar27 + 0x8d) == '\0' || (uVar15 == 0)))) {
                        if ((uVar5 & 0xffff0fff) == 0) {
                            bVar29 = false;
                        } else {
                            bVar29 = (*(uint32_t *)
                                       (iVar27 + 0x16b8 + ((int64_t)(int32_t)(uVar5 & 0xffff0fff) + -0x200 >> 5) * 4) >>
                                      (uVar5 & 0x1f) & 1) != 0;
                        }
                    } else {
                        bVar29 = false;
                    }
                    if (((cVar18 != '\0') && (var_57h != '\0')) && (!bVar29)) break;
                    cVar24 = *(char *)(iVar16 + 0x10 + iVar6);
                    if (*pcVar21 != cVar24) {
                        var_56h = '\x01';
                        *(uint32_t *)((int64_t)&var_48h + ((int64_t)(int32_t)uVar11 >> 5) * 4) =
                             *(uint32_t *)((int64_t)&var_48h + ((int64_t)(int32_t)uVar11 >> 5) * 4) |
                             1 << (uVar11 & 0x1f);
                        if ((cVar18 != '\0') && (var_54h._4_4_ = var_54h._4_4_ & 0xff, !bVar29)) {
                            var_54h._4_4_ = 1;
                        }
                    }
                    *pcVar21 = cVar24;
                    *(undefined4 *)(pcVar21 + 0xc) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                    cVar24 = var_55h;
                    cVar20 = var_56h;
                    cVar25 = var_57h;
                    cVar14 = var_58h;
                }
            } else if (iVar12 == 6) {
                if ((*puVar1 & 0x40) == 0) {
                    if (((cVar13 != '\0') && (((uVar17 != 0 || (cVar14 != '\0')) || (cVar24 != '\0')))) ||
                       ((cVar18 != '\0' && ((char)uVar23 != '\0')))) break;
                    uVar5 = *(uint32_t *)(iVar16 + 0xc + iVar6);
                    piVar2 = (int32_t *)(iVar9 + 0xc18);
                    iVar12 = *(int32_t *)(iVar9 + 0xc1c);
                    uVar10 = 0xfffd;
                    if (uVar5 < 0x10000) {
                        uVar10 = (undefined2)uVar5;
                    }
                    if (*piVar2 == iVar12) {
                        iVar22 = *piVar2 + 1;
                        if (iVar12 == 0) {
                            iVar12 = 8;
                        } else {
                            iVar12 = iVar12 / 2 + iVar12;
                        }
                        if (iVar22 < iVar12) {
                            iVar22 = iVar12;
                        }
                        func_0x00018011f8d0(piVar2, iVar22);
                        iVar27 = *(int64_t *)0x180781f28;
                        cVar24 = var_55h;
                        cVar25 = var_57h;
                    }
                    *(undefined2 *)(*(int64_t *)(iVar9 + 0xc20) + (int64_t)*piVar2 * 2) = uVar10;
                    *piVar2 = *piVar2 + 1;
                    cVar20 = var_56h;
                    cVar18 = (char)var_54h;
                    cVar14 = var_58h;
                    if ((char)var_54h != '\0') {
                        cVar25 = '\x01';
                        var_57h = '\x01';
                    }
                }
            } else if (iVar12 == 7) {
                *(bool *)(iVar9 + 0xc14) = *(char *)(iVar16 + 0xc + iVar6) == '\0';
            }
            uVar23 = (uint64_t)var_54h._4_4_;
            iVar28 = iVar28 + 1;
        } while (iVar28 < *(int32_t *)(iVar9 + 0x1558));
    }
    uVar17 = 0;
    if (0 < iVar28) {
        piVar2 = (int32_t *)(iVar9 + 0x1568);
        do {
            iVar12 = *(int32_t *)(iVar9 + 0x156c);
            puVar19 = (undefined4 *)((uint64_t)uVar17 * 0x1c + *(int64_t *)(iVar9 + 0x1560));
            if (*piVar2 == iVar12) {
                iVar22 = *piVar2 + 1;
                if (iVar12 == 0) {
                    iVar12 = 8;
                } else {
                    iVar12 = iVar12 / 2 + iVar12;
                }
                if (iVar22 < iVar12) {
                    iVar22 = iVar12;
                }
                func_0x00018011f9d0(piVar2, iVar22);
            }
            iVar12 = *piVar2;
            uVar17 = uVar17 + 1;
            uVar4 = puVar19[1];
            uVar7 = puVar19[2];
            uVar8 = puVar19[3];
            iVar27 = *(int64_t *)(iVar9 + 0x1570);
            puVar3 = (undefined4 *)((int64_t)iVar12 * 0x1c + iVar27);
            *puVar3 = *puVar19;
            puVar3[1] = uVar4;
            puVar3[2] = uVar7;
            puVar3[3] = uVar8;
            uVar4 = puVar19[4];
            uVar7 = puVar19[5];
            uVar8 = puVar19[6];
            puVar3 = (undefined4 *)((int64_t)iVar12 * 0x1c + 0xc + iVar27);
            *puVar3 = puVar19[3];
            puVar3[1] = uVar4;
            puVar3[2] = uVar7;
            puVar3[3] = uVar8;
            *piVar2 = *piVar2 + 1;
        } while ((int32_t)uVar17 < iVar28);
    }
    piVar2 = (int32_t *)(iVar9 + 0x1558);
    if (iVar28 == *piVar2) {
        iVar28 = *(int32_t *)(iVar9 + 0x155c);
        if (iVar28 < 0) {
            iVar28 = iVar28 + iVar28 / 2;
            iVar12 = 0;
            if (0 < iVar28) {
                iVar12 = iVar28;
            }
            func_0x00018011f9d0(piVar2, iVar12);
        }
        *piVar2 = 0;
    } else {
        func_0x000180498030(*(int64_t *)(iVar9 + 0x1560), (int64_t)iVar28 * 0x1c + *(int64_t *)(iVar9 + 0x1560), 
                            ((int64_t)*piVar2 - (int64_t)iVar28) * 0x1c);
        *piVar2 = *piVar2 - iVar28;
    }
    if (*(char *)(iVar9 + 0xc14) != '\0') {
        func_0x0001800f52d0(puVar1);
        *(undefined *)(iVar9 + 0xa40) = 0;
        *(undefined4 *)(iVar9 + 0xa44) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa48) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa50) = 0;
        *(undefined4 *)(iVar9 + 0xa54) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa58) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa60) = 0;
        *(undefined4 *)(iVar9 + 0xa64) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa68) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa70) = 0;
        *(undefined4 *)(iVar9 + 0xa74) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa78) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa80) = 0;
        *(undefined4 *)(iVar9 + 0xa84) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa88) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa90) = 0;
        *(undefined4 *)(iVar9 + 0xa94) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa98) = 0xbf800000;
        *(undefined *)(iVar9 + 0xaa0) = 0;
        *(undefined4 *)(iVar9 + 0xaa4) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xaa8) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0x118) = 0xff7fffff;
        *(undefined4 *)(iVar9 + 0x11c) = 0xff7fffff;
        *(undefined4 *)(iVar9 + 0x120) = 0;
        *(undefined4 *)(iVar9 + 0xbc0) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbac) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbc4) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbb0) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbc8) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbb4) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbcc) = 0xbf800000;
        *(undefined4 *)(iVar9 + 3000) = 0xbf800000;
        *(undefined *)(iVar9 + 0x124) = 0;
        *(undefined4 *)(iVar9 + 0xbd0) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbbc) = 0xbf800000;
        *(undefined8 *)(iVar9 + 0x128) = 0;
    }
    func_0x000180459870(var_30h ^ (uint64_t)auStack_78);
    return;
}

// ============================================================
// Function: FUN_18010992f
// Address: 0x18010992f
// Size: 101 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_55h
// WARNING: [rz-ghidra] Detected overlap for variable var_56h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_57h

void fcn.1801093d0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4)
{
    uint8_t *puVar1;
    int32_t *piVar2;
    undefined4 *puVar3;
    undefined4 uVar4;
    uint32_t uVar5;
    int64_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    undefined2 uVar10;
    uint32_t uVar11;
    int32_t iVar12;
    char cVar13;
    char cVar14;
    uint32_t uVar15;
    int64_t iVar16;
    uint32_t uVar17;
    char cVar18;
    undefined4 *puVar19;
    char cVar20;
    char *pcVar21;
    int32_t iVar22;
    uint64_t uVar23;
    char cVar24;
    char cVar25;
    uint32_t uVar26;
    int64_t iVar27;
    int32_t iVar28;
    bool bVar29;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_78 [32];
    char var_58h;
    char var_57h;
    char var_56h;
    char var_55h;
    int64_t var_54h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar9 = *(int64_t *)0x180781f28;
    var_30h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_78;
    cVar13 = (char)arg1;
    puVar1 = (uint8_t *)(*(int64_t *)0x180781f28 + 0x30);
    if ((cVar13 == '\0') || (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2c8c) != 1)) {
        var_54h._0_1_ = '\0';
    } else {
        var_54h._0_1_ = '\x01';
    }
    cVar14 = '\0';
    cVar24 = '\0';
    var_58h = '\0';
    cVar20 = '\0';
    var_55h = '\0';
    uVar23 = arg4 & 0xffffffffffffff00;
    var_56h = '\0';
    cVar25 = '\0';
    var_54h._4_4_ = (uint32_t)uVar23;
    var_57h = '\0';
    uVar17 = 0;
    var_38h._0_4_ = 0;
    iVar28 = 0;
    _var_48h = ZEXT816(0);
    iVar27 = *(int64_t *)0x180781f28;
    cVar18 = (char)var_54h;
    if (0 < *(int32_t *)(*(int64_t *)0x180781f28 + 0x1558)) {
        do {
            iVar6 = *(int64_t *)(iVar9 + 0x1560);
            iVar16 = (int64_t)iVar28 * 0x1c;
            iVar12 = *(int32_t *)(iVar16 + iVar6);
            if (iVar12 == 1) {
                if (*(char *)(iVar9 + 0xeb) == '\0') {
                    if ((cVar13 != '\0') &&
                       ((((uVar17 != 0 || (cVar24 != '\0')) || (cVar20 != '\0')) || (cVar25 != '\0')))) break;
                    uVar4 = *(undefined4 *)(iVar16 + 0xc + iVar6);
                    *(undefined4 *)(iVar9 + 0x11c) = *(undefined4 *)(iVar16 + 0x10 + iVar6);
                    *(undefined4 *)(iVar9 + 0x118) = uVar4;
                    *(undefined4 *)(iVar9 + 0x130) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                    var_58h = '\x01';
                    cVar14 = '\x01';
                }
            } else if (iVar12 == 3) {
                uVar5 = *(uint32_t *)(iVar16 + 0xc + iVar6);
                if ((cVar13 != '\0') &&
                   ((((uVar17 >> (uVar5 & 0x1f) & 1) != 0 || (cVar24 != '\0')) ||
                    ((*(int32_t *)(iVar16 + 0x14 + iVar6) == 1 && (cVar14 != '\0')))))) break;
                uVar17 = uVar17 | 1 << (uVar5 & 0x1f);
                puVar1[(int64_t)(int32_t)uVar5 + 0xf0] = *(uint8_t *)(iVar16 + 0x10 + iVar6);
                *(undefined4 *)(iVar9 + 0x130) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                cVar14 = var_58h;
            } else if (iVar12 == 2) {
                if ((cVar13 != '\0') && ((cVar14 != '\0' || (uVar17 != 0)))) break;
                var_55h = '\x01';
                *(float *)(iVar9 + 300) = *(float *)(iVar16 + 0xc + iVar6) + *(float *)(iVar9 + 300);
                *(float *)(iVar9 + 0x128) = *(float *)(iVar16 + 0x10 + iVar6) + *(float *)(iVar9 + 0x128);
                *(undefined4 *)(iVar9 + 0x130) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                cVar24 = '\x01';
            } else if (iVar12 == 4) {
                *(undefined4 *)(iVar9 + 0x134) = *(undefined4 *)(iVar16 + 0xc + iVar6);
            } else if (iVar12 == 5) {
                if ((*puVar1 & 0x40) == 0) {
                    uVar5 = *(uint32_t *)(iVar16 + 0xc + iVar6);
                    uVar11 = uVar5;
                    if ((uVar5 & 0xf000) != 0) {
                        if (uVar5 == 0x1000) {
                            uVar11 = 0x297;
                        } else if (uVar5 == 0x2000) {
                            uVar11 = 0x298;
                        } else if (uVar5 == 0x4000) {
                            uVar11 = 0x299;
                        } else if (uVar5 == 0x8000) {
                            uVar11 = 0x29a;
                        }
                    }
                    pcVar21 = (char *)(((int64_t)(int32_t)uVar11 + -0x1ec) * 0x10 + iVar27);
                    uVar11 = (uint32_t)((int64_t)(pcVar21 + (-0x140 - iVar9)) >> 4);
                    if (((cVar13 != '\0') && (*pcVar21 != *(char *)(iVar16 + 0x10 + iVar6))) &&
                       (((*(uint32_t *)((int64_t)&var_48h + ((int64_t)(int32_t)uVar11 >> 5) * 4) >> (uVar11 & 0x1f) & 1)
                         != 0 || (uVar17 != 0)))) break;
                    uVar15 = -(uint32_t)(*(char *)(iVar27 + 0xab0) != '\0') & 0x1000;
                    uVar26 = uVar15 | 0x4000;
                    if (*(char *)(iVar27 + 0xad0) == '\0') {
                        uVar26 = uVar15;
                    }
                    uVar15 = (uVar26 | uVar5) & 0x1000;
                    if (((uVar15 == 0) || (((uVar26 | uVar5) >> 0xe & 1) != 0)) &&
                       ((*(char *)(iVar27 + 0x8d) == '\0' || (uVar15 == 0)))) {
                        if ((uVar5 & 0xffff0fff) == 0) {
                            bVar29 = false;
                        } else {
                            bVar29 = (*(uint32_t *)
                                       (iVar27 + 0x16b8 + ((int64_t)(int32_t)(uVar5 & 0xffff0fff) + -0x200 >> 5) * 4) >>
                                      (uVar5 & 0x1f) & 1) != 0;
                        }
                    } else {
                        bVar29 = false;
                    }
                    if (((cVar18 != '\0') && (var_57h != '\0')) && (!bVar29)) break;
                    cVar24 = *(char *)(iVar16 + 0x10 + iVar6);
                    if (*pcVar21 != cVar24) {
                        var_56h = '\x01';
                        *(uint32_t *)((int64_t)&var_48h + ((int64_t)(int32_t)uVar11 >> 5) * 4) =
                             *(uint32_t *)((int64_t)&var_48h + ((int64_t)(int32_t)uVar11 >> 5) * 4) |
                             1 << (uVar11 & 0x1f);
                        if ((cVar18 != '\0') && (var_54h._4_4_ = var_54h._4_4_ & 0xff, !bVar29)) {
                            var_54h._4_4_ = 1;
                        }
                    }
                    *pcVar21 = cVar24;
                    *(undefined4 *)(pcVar21 + 0xc) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                    cVar24 = var_55h;
                    cVar20 = var_56h;
                    cVar25 = var_57h;
                    cVar14 = var_58h;
                }
            } else if (iVar12 == 6) {
                if ((*puVar1 & 0x40) == 0) {
                    if (((cVar13 != '\0') && (((uVar17 != 0 || (cVar14 != '\0')) || (cVar24 != '\0')))) ||
                       ((cVar18 != '\0' && ((char)uVar23 != '\0')))) break;
                    uVar5 = *(uint32_t *)(iVar16 + 0xc + iVar6);
                    piVar2 = (int32_t *)(iVar9 + 0xc18);
                    iVar12 = *(int32_t *)(iVar9 + 0xc1c);
                    uVar10 = 0xfffd;
                    if (uVar5 < 0x10000) {
                        uVar10 = (undefined2)uVar5;
                    }
                    if (*piVar2 == iVar12) {
                        iVar22 = *piVar2 + 1;
                        if (iVar12 == 0) {
                            iVar12 = 8;
                        } else {
                            iVar12 = iVar12 / 2 + iVar12;
                        }
                        if (iVar22 < iVar12) {
                            iVar22 = iVar12;
                        }
                        func_0x00018011f8d0(piVar2, iVar22);
                        iVar27 = *(int64_t *)0x180781f28;
                        cVar24 = var_55h;
                        cVar25 = var_57h;
                    }
                    *(undefined2 *)(*(int64_t *)(iVar9 + 0xc20) + (int64_t)*piVar2 * 2) = uVar10;
                    *piVar2 = *piVar2 + 1;
                    cVar20 = var_56h;
                    cVar18 = (char)var_54h;
                    cVar14 = var_58h;
                    if ((char)var_54h != '\0') {
                        cVar25 = '\x01';
                        var_57h = '\x01';
                    }
                }
            } else if (iVar12 == 7) {
                *(bool *)(iVar9 + 0xc14) = *(char *)(iVar16 + 0xc + iVar6) == '\0';
            }
            uVar23 = (uint64_t)var_54h._4_4_;
            iVar28 = iVar28 + 1;
        } while (iVar28 < *(int32_t *)(iVar9 + 0x1558));
    }
    uVar17 = 0;
    if (0 < iVar28) {
        piVar2 = (int32_t *)(iVar9 + 0x1568);
        do {
            iVar12 = *(int32_t *)(iVar9 + 0x156c);
            puVar19 = (undefined4 *)((uint64_t)uVar17 * 0x1c + *(int64_t *)(iVar9 + 0x1560));
            if (*piVar2 == iVar12) {
                iVar22 = *piVar2 + 1;
                if (iVar12 == 0) {
                    iVar12 = 8;
                } else {
                    iVar12 = iVar12 / 2 + iVar12;
                }
                if (iVar22 < iVar12) {
                    iVar22 = iVar12;
                }
                func_0x00018011f9d0(piVar2, iVar22);
            }
            iVar12 = *piVar2;
            uVar17 = uVar17 + 1;
            uVar4 = puVar19[1];
            uVar7 = puVar19[2];
            uVar8 = puVar19[3];
            iVar27 = *(int64_t *)(iVar9 + 0x1570);
            puVar3 = (undefined4 *)((int64_t)iVar12 * 0x1c + iVar27);
            *puVar3 = *puVar19;
            puVar3[1] = uVar4;
            puVar3[2] = uVar7;
            puVar3[3] = uVar8;
            uVar4 = puVar19[4];
            uVar7 = puVar19[5];
            uVar8 = puVar19[6];
            puVar3 = (undefined4 *)((int64_t)iVar12 * 0x1c + 0xc + iVar27);
            *puVar3 = puVar19[3];
            puVar3[1] = uVar4;
            puVar3[2] = uVar7;
            puVar3[3] = uVar8;
            *piVar2 = *piVar2 + 1;
        } while ((int32_t)uVar17 < iVar28);
    }
    piVar2 = (int32_t *)(iVar9 + 0x1558);
    if (iVar28 == *piVar2) {
        iVar28 = *(int32_t *)(iVar9 + 0x155c);
        if (iVar28 < 0) {
            iVar28 = iVar28 + iVar28 / 2;
            iVar12 = 0;
            if (0 < iVar28) {
                iVar12 = iVar28;
            }
            func_0x00018011f9d0(piVar2, iVar12);
        }
        *piVar2 = 0;
    } else {
        func_0x000180498030(*(int64_t *)(iVar9 + 0x1560), (int64_t)iVar28 * 0x1c + *(int64_t *)(iVar9 + 0x1560), 
                            ((int64_t)*piVar2 - (int64_t)iVar28) * 0x1c);
        *piVar2 = *piVar2 - iVar28;
    }
    if (*(char *)(iVar9 + 0xc14) != '\0') {
        func_0x0001800f52d0(puVar1);
        *(undefined *)(iVar9 + 0xa40) = 0;
        *(undefined4 *)(iVar9 + 0xa44) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa48) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa50) = 0;
        *(undefined4 *)(iVar9 + 0xa54) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa58) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa60) = 0;
        *(undefined4 *)(iVar9 + 0xa64) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa68) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa70) = 0;
        *(undefined4 *)(iVar9 + 0xa74) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa78) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa80) = 0;
        *(undefined4 *)(iVar9 + 0xa84) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa88) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa90) = 0;
        *(undefined4 *)(iVar9 + 0xa94) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa98) = 0xbf800000;
        *(undefined *)(iVar9 + 0xaa0) = 0;
        *(undefined4 *)(iVar9 + 0xaa4) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xaa8) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0x118) = 0xff7fffff;
        *(undefined4 *)(iVar9 + 0x11c) = 0xff7fffff;
        *(undefined4 *)(iVar9 + 0x120) = 0;
        *(undefined4 *)(iVar9 + 0xbc0) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbac) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbc4) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbb0) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbc8) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbb4) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbcc) = 0xbf800000;
        *(undefined4 *)(iVar9 + 3000) = 0xbf800000;
        *(undefined *)(iVar9 + 0x124) = 0;
        *(undefined4 *)(iVar9 + 0xbd0) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbbc) = 0xbf800000;
        *(undefined8 *)(iVar9 + 0x128) = 0;
    }
    func_0x000180459870(var_30h ^ (uint64_t)auStack_78);
    return;
}

// ============================================================
// Function: FUN_180109994
// Address: 0x180109994
// Size: 365 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_55h
// WARNING: [rz-ghidra] Detected overlap for variable var_56h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_57h

void fcn.1801093d0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4)
{
    uint8_t *puVar1;
    int32_t *piVar2;
    undefined4 *puVar3;
    undefined4 uVar4;
    uint32_t uVar5;
    int64_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    undefined2 uVar10;
    uint32_t uVar11;
    int32_t iVar12;
    char cVar13;
    char cVar14;
    uint32_t uVar15;
    int64_t iVar16;
    uint32_t uVar17;
    char cVar18;
    undefined4 *puVar19;
    char cVar20;
    char *pcVar21;
    int32_t iVar22;
    uint64_t uVar23;
    char cVar24;
    char cVar25;
    uint32_t uVar26;
    int64_t iVar27;
    int32_t iVar28;
    bool bVar29;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_78 [32];
    char var_58h;
    char var_57h;
    char var_56h;
    char var_55h;
    int64_t var_54h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar9 = *(int64_t *)0x180781f28;
    var_30h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_78;
    cVar13 = (char)arg1;
    puVar1 = (uint8_t *)(*(int64_t *)0x180781f28 + 0x30);
    if ((cVar13 == '\0') || (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2c8c) != 1)) {
        var_54h._0_1_ = '\0';
    } else {
        var_54h._0_1_ = '\x01';
    }
    cVar14 = '\0';
    cVar24 = '\0';
    var_58h = '\0';
    cVar20 = '\0';
    var_55h = '\0';
    uVar23 = arg4 & 0xffffffffffffff00;
    var_56h = '\0';
    cVar25 = '\0';
    var_54h._4_4_ = (uint32_t)uVar23;
    var_57h = '\0';
    uVar17 = 0;
    var_38h._0_4_ = 0;
    iVar28 = 0;
    _var_48h = ZEXT816(0);
    iVar27 = *(int64_t *)0x180781f28;
    cVar18 = (char)var_54h;
    if (0 < *(int32_t *)(*(int64_t *)0x180781f28 + 0x1558)) {
        do {
            iVar6 = *(int64_t *)(iVar9 + 0x1560);
            iVar16 = (int64_t)iVar28 * 0x1c;
            iVar12 = *(int32_t *)(iVar16 + iVar6);
            if (iVar12 == 1) {
                if (*(char *)(iVar9 + 0xeb) == '\0') {
                    if ((cVar13 != '\0') &&
                       ((((uVar17 != 0 || (cVar24 != '\0')) || (cVar20 != '\0')) || (cVar25 != '\0')))) break;
                    uVar4 = *(undefined4 *)(iVar16 + 0xc + iVar6);
                    *(undefined4 *)(iVar9 + 0x11c) = *(undefined4 *)(iVar16 + 0x10 + iVar6);
                    *(undefined4 *)(iVar9 + 0x118) = uVar4;
                    *(undefined4 *)(iVar9 + 0x130) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                    var_58h = '\x01';
                    cVar14 = '\x01';
                }
            } else if (iVar12 == 3) {
                uVar5 = *(uint32_t *)(iVar16 + 0xc + iVar6);
                if ((cVar13 != '\0') &&
                   ((((uVar17 >> (uVar5 & 0x1f) & 1) != 0 || (cVar24 != '\0')) ||
                    ((*(int32_t *)(iVar16 + 0x14 + iVar6) == 1 && (cVar14 != '\0')))))) break;
                uVar17 = uVar17 | 1 << (uVar5 & 0x1f);
                puVar1[(int64_t)(int32_t)uVar5 + 0xf0] = *(uint8_t *)(iVar16 + 0x10 + iVar6);
                *(undefined4 *)(iVar9 + 0x130) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                cVar14 = var_58h;
            } else if (iVar12 == 2) {
                if ((cVar13 != '\0') && ((cVar14 != '\0' || (uVar17 != 0)))) break;
                var_55h = '\x01';
                *(float *)(iVar9 + 300) = *(float *)(iVar16 + 0xc + iVar6) + *(float *)(iVar9 + 300);
                *(float *)(iVar9 + 0x128) = *(float *)(iVar16 + 0x10 + iVar6) + *(float *)(iVar9 + 0x128);
                *(undefined4 *)(iVar9 + 0x130) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                cVar24 = '\x01';
            } else if (iVar12 == 4) {
                *(undefined4 *)(iVar9 + 0x134) = *(undefined4 *)(iVar16 + 0xc + iVar6);
            } else if (iVar12 == 5) {
                if ((*puVar1 & 0x40) == 0) {
                    uVar5 = *(uint32_t *)(iVar16 + 0xc + iVar6);
                    uVar11 = uVar5;
                    if ((uVar5 & 0xf000) != 0) {
                        if (uVar5 == 0x1000) {
                            uVar11 = 0x297;
                        } else if (uVar5 == 0x2000) {
                            uVar11 = 0x298;
                        } else if (uVar5 == 0x4000) {
                            uVar11 = 0x299;
                        } else if (uVar5 == 0x8000) {
                            uVar11 = 0x29a;
                        }
                    }
                    pcVar21 = (char *)(((int64_t)(int32_t)uVar11 + -0x1ec) * 0x10 + iVar27);
                    uVar11 = (uint32_t)((int64_t)(pcVar21 + (-0x140 - iVar9)) >> 4);
                    if (((cVar13 != '\0') && (*pcVar21 != *(char *)(iVar16 + 0x10 + iVar6))) &&
                       (((*(uint32_t *)((int64_t)&var_48h + ((int64_t)(int32_t)uVar11 >> 5) * 4) >> (uVar11 & 0x1f) & 1)
                         != 0 || (uVar17 != 0)))) break;
                    uVar15 = -(uint32_t)(*(char *)(iVar27 + 0xab0) != '\0') & 0x1000;
                    uVar26 = uVar15 | 0x4000;
                    if (*(char *)(iVar27 + 0xad0) == '\0') {
                        uVar26 = uVar15;
                    }
                    uVar15 = (uVar26 | uVar5) & 0x1000;
                    if (((uVar15 == 0) || (((uVar26 | uVar5) >> 0xe & 1) != 0)) &&
                       ((*(char *)(iVar27 + 0x8d) == '\0' || (uVar15 == 0)))) {
                        if ((uVar5 & 0xffff0fff) == 0) {
                            bVar29 = false;
                        } else {
                            bVar29 = (*(uint32_t *)
                                       (iVar27 + 0x16b8 + ((int64_t)(int32_t)(uVar5 & 0xffff0fff) + -0x200 >> 5) * 4) >>
                                      (uVar5 & 0x1f) & 1) != 0;
                        }
                    } else {
                        bVar29 = false;
                    }
                    if (((cVar18 != '\0') && (var_57h != '\0')) && (!bVar29)) break;
                    cVar24 = *(char *)(iVar16 + 0x10 + iVar6);
                    if (*pcVar21 != cVar24) {
                        var_56h = '\x01';
                        *(uint32_t *)((int64_t)&var_48h + ((int64_t)(int32_t)uVar11 >> 5) * 4) =
                             *(uint32_t *)((int64_t)&var_48h + ((int64_t)(int32_t)uVar11 >> 5) * 4) |
                             1 << (uVar11 & 0x1f);
                        if ((cVar18 != '\0') && (var_54h._4_4_ = var_54h._4_4_ & 0xff, !bVar29)) {
                            var_54h._4_4_ = 1;
                        }
                    }
                    *pcVar21 = cVar24;
                    *(undefined4 *)(pcVar21 + 0xc) = *(undefined4 *)(iVar16 + 0x14 + iVar6);
                    cVar24 = var_55h;
                    cVar20 = var_56h;
                    cVar25 = var_57h;
                    cVar14 = var_58h;
                }
            } else if (iVar12 == 6) {
                if ((*puVar1 & 0x40) == 0) {
                    if (((cVar13 != '\0') && (((uVar17 != 0 || (cVar14 != '\0')) || (cVar24 != '\0')))) ||
                       ((cVar18 != '\0' && ((char)uVar23 != '\0')))) break;
                    uVar5 = *(uint32_t *)(iVar16 + 0xc + iVar6);
                    piVar2 = (int32_t *)(iVar9 + 0xc18);
                    iVar12 = *(int32_t *)(iVar9 + 0xc1c);
                    uVar10 = 0xfffd;
                    if (uVar5 < 0x10000) {
                        uVar10 = (undefined2)uVar5;
                    }
                    if (*piVar2 == iVar12) {
                        iVar22 = *piVar2 + 1;
                        if (iVar12 == 0) {
                            iVar12 = 8;
                        } else {
                            iVar12 = iVar12 / 2 + iVar12;
                        }
                        if (iVar22 < iVar12) {
                            iVar22 = iVar12;
                        }
                        func_0x00018011f8d0(piVar2, iVar22);
                        iVar27 = *(int64_t *)0x180781f28;
                        cVar24 = var_55h;
                        cVar25 = var_57h;
                    }
                    *(undefined2 *)(*(int64_t *)(iVar9 + 0xc20) + (int64_t)*piVar2 * 2) = uVar10;
                    *piVar2 = *piVar2 + 1;
                    cVar20 = var_56h;
                    cVar18 = (char)var_54h;
                    cVar14 = var_58h;
                    if ((char)var_54h != '\0') {
                        cVar25 = '\x01';
                        var_57h = '\x01';
                    }
                }
            } else if (iVar12 == 7) {
                *(bool *)(iVar9 + 0xc14) = *(char *)(iVar16 + 0xc + iVar6) == '\0';
            }
            uVar23 = (uint64_t)var_54h._4_4_;
            iVar28 = iVar28 + 1;
        } while (iVar28 < *(int32_t *)(iVar9 + 0x1558));
    }
    uVar17 = 0;
    if (0 < iVar28) {
        piVar2 = (int32_t *)(iVar9 + 0x1568);
        do {
            iVar12 = *(int32_t *)(iVar9 + 0x156c);
            puVar19 = (undefined4 *)((uint64_t)uVar17 * 0x1c + *(int64_t *)(iVar9 + 0x1560));
            if (*piVar2 == iVar12) {
                iVar22 = *piVar2 + 1;
                if (iVar12 == 0) {
                    iVar12 = 8;
                } else {
                    iVar12 = iVar12 / 2 + iVar12;
                }
                if (iVar22 < iVar12) {
                    iVar22 = iVar12;
                }
                func_0x00018011f9d0(piVar2, iVar22);
            }
            iVar12 = *piVar2;
            uVar17 = uVar17 + 1;
            uVar4 = puVar19[1];
            uVar7 = puVar19[2];
            uVar8 = puVar19[3];
            iVar27 = *(int64_t *)(iVar9 + 0x1570);
            puVar3 = (undefined4 *)((int64_t)iVar12 * 0x1c + iVar27);
            *puVar3 = *puVar19;
            puVar3[1] = uVar4;
            puVar3[2] = uVar7;
            puVar3[3] = uVar8;
            uVar4 = puVar19[4];
            uVar7 = puVar19[5];
            uVar8 = puVar19[6];
            puVar3 = (undefined4 *)((int64_t)iVar12 * 0x1c + 0xc + iVar27);
            *puVar3 = puVar19[3];
            puVar3[1] = uVar4;
            puVar3[2] = uVar7;
            puVar3[3] = uVar8;
            *piVar2 = *piVar2 + 1;
        } while ((int32_t)uVar17 < iVar28);
    }
    piVar2 = (int32_t *)(iVar9 + 0x1558);
    if (iVar28 == *piVar2) {
        iVar28 = *(int32_t *)(iVar9 + 0x155c);
        if (iVar28 < 0) {
            iVar28 = iVar28 + iVar28 / 2;
            iVar12 = 0;
            if (0 < iVar28) {
                iVar12 = iVar28;
            }
            func_0x00018011f9d0(piVar2, iVar12);
        }
        *piVar2 = 0;
    } else {
        func_0x000180498030(*(int64_t *)(iVar9 + 0x1560), (int64_t)iVar28 * 0x1c + *(int64_t *)(iVar9 + 0x1560), 
                            ((int64_t)*piVar2 - (int64_t)iVar28) * 0x1c);
        *piVar2 = *piVar2 - iVar28;
    }
    if (*(char *)(iVar9 + 0xc14) != '\0') {
        func_0x0001800f52d0(puVar1);
        *(undefined *)(iVar9 + 0xa40) = 0;
        *(undefined4 *)(iVar9 + 0xa44) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa48) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa50) = 0;
        *(undefined4 *)(iVar9 + 0xa54) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa58) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa60) = 0;
        *(undefined4 *)(iVar9 + 0xa64) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa68) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa70) = 0;
        *(undefined4 *)(iVar9 + 0xa74) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa78) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa80) = 0;
        *(undefined4 *)(iVar9 + 0xa84) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa88) = 0xbf800000;
        *(undefined *)(iVar9 + 0xa90) = 0;
        *(undefined4 *)(iVar9 + 0xa94) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xa98) = 0xbf800000;
        *(undefined *)(iVar9 + 0xaa0) = 0;
        *(undefined4 *)(iVar9 + 0xaa4) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xaa8) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0x118) = 0xff7fffff;
        *(undefined4 *)(iVar9 + 0x11c) = 0xff7fffff;
        *(undefined4 *)(iVar9 + 0x120) = 0;
        *(undefined4 *)(iVar9 + 0xbc0) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbac) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbc4) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbb0) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbc8) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbb4) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbcc) = 0xbf800000;
        *(undefined4 *)(iVar9 + 3000) = 0xbf800000;
        *(undefined *)(iVar9 + 0x124) = 0;
        *(undefined4 *)(iVar9 + 0xbd0) = 0xbf800000;
        *(undefined4 *)(iVar9 + 0xbbc) = 0xbf800000;
        *(undefined8 *)(iVar9 + 0x128) = 0;
    }
    func_0x000180459870(var_30h ^ (uint64_t)auStack_78);
    return;
}

// ============================================================
// Function: FUN_180109b10
// Address: 0x180109b10
// Size: 169 bytes
// ============================================================
bool fcn.180109b10(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int32_t *piVar2;
    int32_t iVar3;
    
    iVar1 = (int32_t)arg1;
    iVar3 = (int32_t)arg2;
    if ((((iVar1 - 0x200U < 0x9b) || (iVar1 == 0x1000)) || (iVar1 == 0x2000)) ||
       ((iVar1 == 0x4000 || (iVar1 == 0x8000)))) {
        if ((*(char *)(*(int64_t *)0x180781f28 + 0x1f6c) == '\0') ||
           ((iVar3 == *(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) || (iVar3 == 0)))) {
            piVar2 = (int32_t *)fcn.1800f45c0(*(int64_t *)0x180781f28, arg1 & 0xffffffff);
            if (iVar3 == 0) {
                return *(char *)(piVar2 + 2) == '\0';
            }
        } else {
            if (iVar1 - 0x200U < 0x78) {
                return false;
            }
            piVar2 = (int32_t *)fcn.1800f45c0(*(int64_t *)0x180781f28, arg1 & 0xffffffff);
        }
        if (*piVar2 != iVar3) {
            if (*(char *)(piVar2 + 2) != '\0') {
                return false;
            }
            return *piVar2 == -1;
        }
    }
    return true;
}

// ============================================================
// Function: FUN_180109ce0
// Address: 0x180109ce0
// Size: 146 bytes
// ============================================================
bool fcn.180109ce0(undefined8 placeholder_0, int64_t arg2)
{
    char cVar1;
    uint32_t uVar2;
    int64_t in_R8;
    uint32_t uVar3;
    uint64_t arg1;
    uint64_t uVar4;
    
    uVar4 = arg2 & 0xffffffff;
    uVar2 = func_0x000180107780();
    uVar3 = uVar2 & 0xf000;
    if (*(uint32_t *)(*(int64_t *)0x180781f28 + 0x13c) == uVar3) {
        if ((uVar2 & 0xffff0fff) == 0) {
            if (uVar3 == 0x1000) {
                arg1 = 0x297;
            } else if (uVar3 == 0x2000) {
                arg1 = 0x298;
            } else if (uVar3 == 0x4000) {
                arg1 = 0x299;
            } else {
                if (uVar3 == 0x8000) {
                    uVar3 = 0x29a;
                }
                arg1 = (uint64_t)uVar3;
            }
        } else {
            arg1 = (uint64_t)(uVar2 & 0xffff0fff);
        }
        cVar1 = fcn.180107dc0(arg1, uVar4 & 0xff, in_R8);
        return cVar1 != '\0';
    }
    return false;
}

// ============================================================
// Function: FUN_180109d80
// Address: 0x180109d80
// Size: 592 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180109d80(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    char cVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int32_t iVar7;
    uint64_t uVar8;
    uint32_t uVar9;
    int32_t iVar10;
    uint64_t uVar11;
    int32_t iVar12;
    uint32_t uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    uVar11 = arg3 & 0xffffffff;
    uVar9 = (uint32_t)arg2 | 0x800;
    if ((arg2 & 0x3c00U) != 0) {
        uVar9 = (uint32_t)arg2;
    }
    if (((int32_t)arg3 + 1U & 0xfffffffe) == 0) {
        uVar11 = (uint64_t)*(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f74);
    }
    if ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x1f78) & 0x40) == 0) {
        uVar13 = uVar9 | 0xd000;
        if ((uVar9 & 0x3c00) != 0) {
            uVar13 = uVar9;
        }
        iVar6 = *(int64_t *)0x180781f28;
        uVar3 = func_0x000180107780();
        if (*(uint32_t *)(iVar6 + 0x1f70) == uVar3) {
            pcVar1 = (code *)swi(3);
            uVar5 = (*pcVar1)();
            return uVar5;
        }
        if (((uVar13 >> 0x10 & 1) == 0) || (*(int64_t *)(iVar6 + 0x21d8) != 0)) {
            iVar10 = (int32_t)uVar11;
            if ((uVar13 >> 0xd & 1) == 0) {
                if ((*(int32_t *)(iVar6 + 0x1654) != 0) && (*(int32_t *)(iVar6 + 0x1654) != iVar10)) {
                    if ((uVar13 >> 10 & 1) != 0) {
                        return 0;
                    }
                    if ((*(char *)(iVar6 + 0xea) != '\0') && (cVar2 = func_0x000180107cd0(), cVar2 != '\0')) {
                        return 0;
                    }
                    if (((uVar13 >> 0xf & 1) == 0) && (*(char *)(iVar6 + 0x1f6c) != '\0')) {
                        uVar4 = uVar3 & 0xffff0fff;
                        if ((uVar3 & 0xffff0fff) == 0) {
                            uVar4 = func_0x0001800f4520();
                        }
                        if (uVar4 - 0x200 < 0x78) {
                            return 0;
                        }
                    }
                }
                if ((uVar13 >> 0x11 & 1) == 0) {
                    iVar12 = *(int32_t *)(iVar6 + 0x1f74);
                } else {
                    iVar12 = *(int32_t *)(*(int64_t *)(*(int64_t *)(iVar6 + 0x15e0) + 0x418) + 0x10);
                }
                if ((uVar13 >> 0xb & 1) == 0) {
                    if ((uVar13 >> 10 & 1) == 0) {
                        if ((uVar13 >> 0xc & 1) == 0) {
                            return 0;
                        }
                        if ((uVar13 >> 0xf & 1) == 0) {
                            if ((iVar10 == 0) || (*(int32_t *)(iVar6 + 0x1654) != iVar10)) {
                                iVar12 = 1;
                                if ((uVar13 >> 0xe & 1) != 0) {
                                    iVar12 = 200;
                                }
                            } else {
                                iVar12 = 300;
                            }
                        } else {
                            iVar12 = 400;
                        }
                    } else {
                        if (iVar10 == 0) {
                            return 0;
                        }
                        if (*(int32_t *)(iVar6 + 0x1654) != iVar10) {
                            return 0;
                        }
                        iVar12 = 300;
                    }
                } else if ((iVar10 == 0) || (*(int32_t *)(iVar6 + 0x1654) != iVar10)) {
                    if (iVar12 == 0) {
                        return 0;
                    }
                    uVar4 = *(uint32_t *)(iVar6 + 0x2200);
                    arg2 = (int64_t)uVar4;
                    if ((int32_t)uVar4 < 1) {
                        return 0;
                    }
                    uVar8 = 0;
                    while (iVar7 = (int32_t)uVar8, *(int32_t *)(*(int64_t *)(iVar6 + 0x2208) + uVar8 * 8) != iVar12) {
                        uVar8 = (uint64_t)(iVar7 + 1U);
                        if ((int32_t)uVar4 <= (int32_t)(iVar7 + 1U)) {
                            return 0;
                        }
                    }
                    iVar12 = 599 - iVar7;
                    if ((uVar13 >> 0xf & 1) == 0) {
                        iVar12 = 199 - iVar7;
                    }
                    if (iVar12 == 0) {
                        return 0;
                    }
                } else {
                    iVar12 = 300;
                }
                iVar6 = fcn.180107b60((uint64_t)uVar3, arg2);
                if ((int32_t)(uint32_t)*(uint16_t *)(iVar6 + 6) < iVar12) {
                    *(int32_t *)(iVar6 + 0xc) = iVar10;
                    *(int16_t *)(iVar6 + 6) = (int16_t)iVar12;
                }
                if (*(int32_t *)(iVar6 + 8) != iVar10) {
                    return 0;
                }
            }
            uVar13 = uVar9 | 0x20;
            if (((uint8_t)uVar9 & 0xf1) != 1) {
                uVar13 = uVar9;
            }
            cVar2 = fcn.180109ce0(arg1 & 0xffffffff, (uint64_t)uVar13);
            if (cVar2 != '\0') {
                func_0x000180109c30((uint32_t)arg1 & 0xf000, uVar11);
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18010a070
// Address: 0x18010a070
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_158h
// WARNING: Variable defined which should be unmapped: var_150h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Removing arg arg_8ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_94h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_13ch
// WARNING: [rz-ghidra] Detected overlap for variable var_144h
// WARNING: [rz-ghidra] Detected overlap for variable arg_9ch

void fcn.18010a070(int64_t arg1, int64_t arg_80h, int64_t arg_98h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int16_t iVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int64_t iVar12;
    char cVar13;
    undefined uVar14;
    undefined4 uVar15;
    int32_t iVar16;
    int64_t iVar17;
    int64_t iVar18;
    int32_t iVar19;
    int64_t *piVar20;
    int64_t *piVar21;
    int64_t iVar22;
    int64_t iVar23;
    int64_t iVar24;
    int64_t iVar25;
    int64_t iVar26;
    uint32_t uVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    float fVar31;
    float fVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    float fVar36;
    float fVar37;
    float fVar38;
    float fStackX_10;
    float fStackX_14;
    undefined8 uStackX_18;
    float fStackX_20;
    float fStackX_24;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    float var_120h;
    float var_11ch;
    int64_t var_118h;
    float var_110h;
    int64_t var_10ch;
    undefined4 var_104h;
    undefined4 var_100h;
    undefined4 var_fch;
    undefined4 uStack_f8;
    undefined4 uStack_f4;
    undefined4 uStack_f0;
    float fStack_ec;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar12 = *(int64_t *)0x180781f28;
    iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0);
    while ((iVar17 != 0 && (*(int64_t *)(iVar17 + 0x188) == *(int64_t *)(iVar12 + 0x15e0)))) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644dc0);
        }
        func_0x0001801346c0();
        iVar17 = *(int64_t *)(iVar12 + 0x24d0);
    }
    iVar17 = *(int64_t *)(iVar12 + 0x15e0);
    piVar21 = *(int64_t **)(iVar12 + 0x2538);
    var_138h = iVar17;
    while ((piVar21 != (int64_t *)0x0 && (*piVar21 == iVar17))) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644ca8);
        }
        func_0x000180148e50();
        piVar21 = *(int64_t **)(iVar12 + 0x2538);
    }
    iVar5 = *(int64_t *)(iVar12 + 0x25f0);
    while ((iVar5 != 0 && (**(int64_t **)(iVar5 + 0x28) == iVar17))) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644cc0);
        }
        iVar18 = *(int64_t *)0x180781f28;
        puVar6 = *(undefined4 **)(*(int64_t *)0x180781f28 + 0x25f0);
        iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        iVar5 = *(int64_t *)(puVar6 + 10);
        var_130h = iVar17;
        if ((puVar6[0xc] != *(int32_t *)(*(int64_t *)0x180781f28 + 0x1f74)) &&
           (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0)) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180645b48);
        }
        func_0x0001801474f0(&var_118h, puVar6, iVar17);
        fVar36 = (float)var_10ch;
        fVar37 = var_110h;
        fVar32 = var_118h._4_4_;
        fVar29 = (float)var_118h;
        if (*(char *)((int64_t)puVar6 + 0x52) != '\0') {
            if ((*(char *)((int64_t)puVar6 + 0x21) != '\0') ||
               ((*(char *)((int64_t)puVar6 + 0x55) == '\0' && (*(int64_t *)(puVar6 + 4) != -1)))) {
                *(undefined8 *)(iVar5 + 0x18) = 0xffffffffffffffff;
            }
            if ((*(char *)(puVar6 + 0x15) == '\0') && (*(int64_t *)(iVar5 + 0x20) != -1)) {
                *(undefined8 *)(iVar5 + 0x20) = 0xffffffffffffffff;
                *(undefined *)(iVar5 + 0x15) = 0xff;
            }
            iVar5 = *(int64_t *)0x180781f28;
            uVar27 = puVar6[0xd];
            if (((((uVar27 & 0xc0) != 0) && (puVar6[0x12] != 0)) &&
                (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2588) == puVar6[0x12])) &&
               (*(char *)(*(int64_t *)0x180781f28 + 0x258c) != '\0')) {
                iVar7 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
                *(undefined *)(*(int64_t *)0x180781f28 + 0x25b8) = 0;
                iVar24 = *(int64_t *)0x180781f28;
                fVar30 = *(float *)(iVar5 + 0x11c);
                fVar28 = var_118h._4_4_;
                if ((var_118h._4_4_ <= fVar30) && (fVar28 = (float)var_10ch, fVar30 <= (float)var_10ch)) {
                    fVar28 = fVar30;
                }
                fVar30 = *(float *)(iVar5 + 0x118);
                fVar34 = (float)var_118h;
                if (((float)var_118h <= fVar30) && (fVar34 = var_110h, fVar30 <= var_110h)) {
                    fVar34 = fVar30;
                }
                fVar30 = *(float *)(iVar7 + 0x168);
                fVar38 = *(float *)(iVar5 + 0x25e8);
                if ((float)var_10ch <= *(float *)(iVar5 + 0x25e8)) {
                    fVar38 = (float)var_10ch;
                }
                *(float *)(iVar5 + 0x25a4) = fVar28 - *(float *)(iVar7 + 0x16c);
                fVar28 = *(float *)(iVar5 + 0x25e4);
                if (var_110h <= *(float *)(iVar5 + 0x25e4)) {
                    fVar28 = var_110h;
                }
                *(float *)(iVar5 + 0x25a0) = fVar34 - fVar30;
                uStack_f8 = *(undefined4 *)(iVar24 + 0x1090);
                uStack_f4 = *(undefined4 *)(iVar24 + 0x1094);
                uStack_f0 = *(undefined4 *)(iVar24 + 0x1098);
                fVar30 = *(float *)(iVar5 + 0x25dc);
                if (*(float *)(iVar5 + 0x25dc) <= (float)var_118h) {
                    fVar30 = (float)var_118h;
                }
                fVar34 = *(float *)(iVar5 + 0x25e0);
                if (*(float *)(iVar5 + 0x25e0) <= var_118h._4_4_) {
                    fVar34 = var_118h._4_4_;
                }
                fStack_ec = *(float *)(iVar24 + 0x109c) * *(float *)(iVar24 + 0xd9c) * 0.3;
                var_128h._0_4_ = fVar30;
                var_128h._4_4_ = fVar34;
                var_120h = fVar28;
                var_11ch = fVar38;
                uVar15 = func_0x0001800f5fa0(&uStack_f8);
                func_0x000180126550(*(undefined8 *)(iVar7 + 800), &var_128h, &var_120h, uVar15, 0, 0);
                uStack_f8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1270);
                uStack_f4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1274);
                uStack_f0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1278);
                fStack_ec = *(float *)(*(int64_t *)0x180781f28 + 0x127c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                iVar24 = *(int64_t *)0x180781f28;
                fStackX_10 = (float)func_0x0001800f5fa0();
                if (((uint32_t)fStackX_10 & 0xff000000) != 0) {
                    iVar17 = *(int64_t *)(iVar7 + 800);
                    if ((*(uint8_t *)(iVar17 + 0x30) & 1) == 0) {
                        var_148h._0_4_ = fVar28 - 0.49;
                        var_148h._4_4_ = fVar38 - 0.49;
                        piVar21 = &var_148h;
                        piVar20 = &var_140h;
                        var_140h._0_4_ = fVar30 + 0.5;
                        var_140h._4_4_ = fVar34 + 0.5;
                    } else {
                        uStackX_18._0_4_ = fVar28 - 0.5;
                        uStackX_18._4_4_ = fVar38 - 0.5;
                        piVar21 = &uStackX_18;
                        piVar20 = (int64_t *)&fStackX_20;
                        fStackX_20 = fVar30 + 0.5;
                        fStackX_24 = fVar34 + 0.5;
                    }
                    func_0x000180125f20(iVar17, piVar20, piVar21);
                    func_0x0001801248e0(iVar17, *(undefined8 *)(iVar17 + 0x58), *(undefined4 *)(iVar17 + 0x50), 
                                        fStackX_10, 1, 0x3f800000);
                    iVar24 = *(int64_t *)0x180781f28;
                    *(undefined4 *)(iVar17 + 0x50) = 0;
                    iVar17 = var_130h;
                }
                if ((uVar27 & 0x900) == 0x800) {
                    fVar28 = (float)(*(uint32_t *)(iVar5 + 0x12f8) ^ 0x80000000);
                    fVar34 = fVar29 - fVar28;
                    fVar38 = fVar32 - fVar28;
                    fVar30 = fVar37 + fVar28;
                    fVar28 = fVar36 + fVar28;
                    if ((((*(float *)(iVar5 + 0x118) < fVar34) || (*(float *)(iVar5 + 0x11c) < fVar38)) ||
                        (fVar30 <= *(float *)(iVar5 + 0x118))) || (fVar28 <= *(float *)(iVar5 + 0x11c))) {
                        fVar33 = *(float *)(iVar24 + 0x118);
                        if ((((fVar30 < fVar33) || (fVar30 = fVar34, fVar33 < fVar34)) &&
                            ((fVar33 = fVar33 - fVar30, fVar33 != 0.0 &&
                             ((fVar30 = *(float *)(iVar7 + 0xd4), 0.0 <= fVar33 || (0.0 <= fVar30)))))) &&
                           ((fVar33 <= 0.0 || (fVar30 < *(float *)(iVar7 + 0xdc))))) {
                            fVar34 = *(float *)(iVar24 + 0x12f8);
                            fVar35 = ((float)((uint32_t)fVar33 & 0x7fffffff) - fVar34) / (fVar34 * 5.0 - fVar34);
                            if (0.0 <= fVar35) {
                                fVar31 = 1.0;
                                if (fVar35 <= 1.0) {
                                    fVar31 = fVar35;
                                }
                            } else {
                                fVar31 = 0.0;
                            }
                            if (0.0 <= fVar33) {
                                if (fVar33 <= 0.0) {
                                    fVar33 = 0.0;
                                } else {
                                    fVar33 = 1.0;
                                }
                            } else {
                                fVar33 = -1.0;
                            }
                            fVar34 = (fVar31 * 3.0 + 1.0) * fVar34 * 35.0 * fVar33 * *(float *)(iVar24 + 0x48) +
                                     *(float *)(iVar5 + 0x25a8);
                            *(float *)(iVar5 + 0x25a8) = fVar34;
                            iVar16 = (int32_t)fVar34;
                            if ((fVar34 < 0.0) && ((float)iVar16 != fVar34)) {
                                iVar16 = iVar16 + -1;
                            }
                            fVar34 = (float)iVar16;
                            if (fVar34 != 0.0) {
                                *(undefined4 *)(iVar7 + 0xec) = 0;
                                *(undefined4 *)(iVar7 + 0xf4) = 0;
                                *(float *)(iVar7 + 0xe4) = fVar34 + fVar30;
                                *(float *)(iVar5 + 0x25a8) = *(float *)(iVar5 + 0x25a8) - fVar34;
                            }
                        }
                        fVar30 = *(float *)(iVar24 + 0x11c);
                        if (((((fVar28 < fVar30) || (fVar28 = fVar38, fVar30 < fVar38)) &&
                             (fVar30 = fVar30 - fVar28, fVar30 != 0.0)) &&
                            ((fVar28 = *(float *)(iVar7 + 0xd8), 0.0 <= fVar30 || (0.0 <= fVar28)))) &&
                           ((fVar30 <= 0.0 || (fVar28 < *(float *)(iVar7 + 0xe0))))) {
                            fVar34 = *(float *)(iVar24 + 0x12f8);
                            fVar38 = ((float)((uint32_t)fVar30 & 0x7fffffff) - fVar34) / (fVar34 * 5.0 - fVar34);
                            if (0.0 <= fVar38) {
                                fVar33 = 1.0;
                                if (fVar38 <= 1.0) {
                                    fVar33 = fVar38;
                                }
                            } else {
                                fVar33 = 0.0;
                            }
                            if (0.0 <= fVar30) {
                                if (fVar30 <= 0.0) {
                                    fVar30 = 0.0;
                                } else {
                                    fVar30 = 1.0;
                                }
                            } else {
                                fVar30 = -1.0;
                            }
                            fVar30 = (fVar33 * 3.0 + 1.0) * fVar34 * 35.0 * fVar30 * *(float *)(iVar24 + 0x48) +
                                     *(float *)(iVar5 + 0x25ac);
                            *(float *)(iVar5 + 0x25ac) = fVar30;
                            iVar16 = (int32_t)fVar30;
                            if ((fVar30 < 0.0) && ((float)iVar16 != fVar30)) {
                                iVar16 = iVar16 + -1;
                            }
                            fVar30 = (float)iVar16;
                            if (fVar30 != 0.0) {
                                *(float *)(iVar7 + 0xe8) = fVar28 + fVar30;
                                *(undefined4 *)(iVar7 + 0xf0) = 0;
                                *(undefined4 *)(iVar7 + 0xf8) = 0;
                                *(float *)(iVar5 + 0x25ac) = *(float *)(iVar5 + 0x25ac) - fVar30;
                            }
                        }
                    }
                }
            }
        }
        if (*(char *)((int64_t)puVar6 + 0x51) == '\0') {
            iVar16 = puVar6[1];
            if (iVar16 < 0) {
                iVar16 = (iVar16 + 1 >> 1) + iVar16;
                iVar19 = 0;
                if (0 < iVar16) {
                    iVar19 = iVar16;
                }
                func_0x00018014fa90(puVar6, iVar19);
            }
            *puVar6 = 0;
        }
        cVar13 = func_0x0001801062b0();
        iVar5 = *(int64_t *)0x180781f28;
        if ((((cVar13 != '\0') && (fVar30 = *(float *)(iVar18 + 0x118), *(float *)(iVar17 + 0x278) <= fVar30)) &&
            (fVar28 = *(float *)(iVar18 + 0x11c), *(float *)(iVar17 + 0x27c) <= fVar28)) &&
           ((fVar30 < *(float *)(iVar17 + 0x280) && (fVar28 < *(float *)(iVar17 + 0x284))))) {
            if (((((uint32_t)puVar6[0xd] >> 0xc & 1) == 0) ||
                (((fVar29 <= fVar30 && (fVar32 <= fVar28)) && ((fVar30 < fVar37 && (fVar28 < fVar36)))))) &&
               ((*(int32_t *)(iVar18 + 0x163c) == 0 && (*(int32_t *)(iVar18 + 0x1654) == 0)))) {
                if (((puVar6[0xd] & 0xc0) != 0) &&
                   (((*(char *)(iVar18 + 0x258c) == '\0' && (*(char *)(iVar18 + 0x258d) == '\0')) &&
                    (*(int16_t *)(iVar18 + 0xb5a) == 1)))) {
                    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2588) = puVar6[0x12];
                    *(undefined2 *)(iVar5 + 0x258d) = 0x101;
                    *(undefined *)(iVar5 + 0x258f) = 1;
                    *(undefined2 *)(iVar5 + 0x2594) = *(undefined2 *)(iVar5 + 0x13c);
                    fVar32 = *(float *)(iVar5 + 0x118) - *(float *)(*(int64_t *)(iVar5 + 0x15e0) + 0x168);
                    fVar29 = *(float *)(iVar5 + 0x11c) - *(float *)(*(int64_t *)(iVar5 + 0x15e0) + 0x16c);
                    *(undefined8 *)(iVar5 + 0x25a8) = 0;
                    *(float *)(iVar5 + 0x25a0) = fVar32;
                    *(float *)(iVar5 + 0x25a4) = fVar29;
                    *(float *)(iVar5 + 0x2598) = fVar32;
                    *(float *)(iVar5 + 0x259c) = fVar29;
                    func_0x00018010e050(iVar17, 2);
                    iVar5 = *(int64_t *)0x180781f28;
                    iVar16 = puVar6[0x12];
                    *(int32_t *)(*(int64_t *)0x180781f28 + 0x163c) = iVar16;
                    *(undefined *)(iVar5 + 0x1650) = 0;
                    if ((iVar16 != 0) && (*(int32_t *)(iVar5 + 0x1640) != iVar16)) {
                        *(undefined8 *)(iVar5 + 0x1648) = 0;
                    }
                    if ((puVar6[0xd] & 0x1000) != 0) {
                        var_10ch._4_4_ = *(undefined4 *)(iVar18 + 0x118);
                        var_104h = *(undefined4 *)(iVar18 + 0x11c);
                        var_100h = var_10ch._4_4_;
                        var_fch = var_104h;
                        func_0x00018010e3f0(0, 0, puVar6[0xc], (int64_t)&var_10ch + 4);
                    }
                }
                if ((((puVar6[0xd] & 0x400) != 0) && (cVar13 = fcn.180108070(0), cVar13 != '\0')) &&
                   ((*(float *)(*(int64_t *)0x180781f28 + 0xbfc) <
                     *(float *)(*(int64_t *)0x180781f28 + 0xa4) * *(float *)(*(int64_t *)0x180781f28 + 0xa4) &&
                    (*(int32_t *)(iVar18 + 0x13c) == 0)))) {
                    func_0x000180147c50(puVar6);
                }
            }
        }
        iVar5 = *(int64_t *)0x180781f28;
        if ((puVar6[0xd] & 0x10000) != 0) {
            *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
            if (((*(int64_t *)(iVar5 + 0x21d8) == *(int64_t *)(iVar5 + 0x15e0)) && (*(char *)(iVar5 + 0x2279) != '\0'))
               && (*(int32_t *)(iVar5 + 0x21e4) == *(int32_t *)(*(int64_t *)(iVar5 + 0x15e0) + 0x1b0))) {
                *(uint32_t *)(iVar5 + 0x227c) = *(uint32_t *)(iVar5 + 0x227c) & 0xfffffff4;
                *(uint32_t *)(iVar5 + 0x227c) = *(uint32_t *)(iVar5 + 0x227c) | 4;
            }
        }
        if ((*(int64_t *)(iVar18 + 0x24d0) != 0) && (*(char *)(*(int64_t *)(iVar18 + 0x24d0) + 0x23a) != '\0')) {
            func_0x000180136780();
        }
        fVar29 = (float)puVar6[0x10];
        if ((float)puVar6[0x10] <= *(float *)(iVar17 + 0x170)) {
            fVar29 = *(float *)(iVar17 + 0x170);
        }
        fVar32 = (float)puVar6[0x11];
        if ((float)puVar6[0x11] <= *(float *)(iVar17 + 0x174)) {
            fVar32 = *(float *)(iVar17 + 0x174);
        }
        *(float *)(iVar17 + 0x170) = fVar29;
        *(float *)(iVar17 + 0x174) = fVar32;
        func_0x0001801067d0();
        puVar6[0xc] = 0;
        puVar6[0xd] = 0;
        *(int32_t *)(iVar18 + 0x25f8) = *(int32_t *)(iVar18 + 0x25f8) + -1;
        if (*(int32_t *)(iVar18 + 0x25f8) < 1) {
            iVar17 = 0;
        } else {
            iVar17 = (int64_t)(*(int32_t *)(iVar18 + 0x25f8) + -1) * 0x58 + *(int64_t *)(iVar18 + 0x2608);
        }
        *(int64_t *)(iVar18 + 0x25f0) = iVar17;
        iVar17 = var_138h;
        iVar5 = *(int64_t *)(iVar12 + 0x25f0);
    }
    if (*(char *)(iVar17 + 0x1bb) != '\0') {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644ce0);
        }
        func_0x000180147f30();
    }
    if ((int32_t)*(int16_t *)(arg1 + 4) < *(int32_t *)(iVar17 + 0x1e0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e50);
            }
            iVar7 = *(int64_t *)0x180781f28;
            iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
            *(undefined *)(iVar5 + 0x10b) = 1;
            iVar18 = *(int64_t *)(iVar7 + 0x15e0);
            fVar29 = *(float *)(iVar18 + 0x19c) - *(float *)(iVar7 + 0xe0c);
            *(float *)(iVar18 + 0x19c) = fVar29;
            *(float *)(iVar18 + 0x158) = fVar29 + *(float *)(iVar18 + 0x60) + *(float *)(iVar18 + 0x1a0);
            *(int32_t *)(iVar5 + 0x1e0) = *(int32_t *)(iVar5 + 0x1e0) + -1;
            uVar27 = 1 << ((uint8_t)*(undefined4 *)(iVar5 + 0x1e0) & 0x1f);
            if ((*(uint32_t *)(iVar5 + 0x1e4) & uVar27) != 0) {
                iVar18 = (int64_t)*(int32_t *)(iVar7 + 0x2140);
                iVar17 = *(int64_t *)(iVar7 + 0x2148);
                if ((((*(uint32_t *)(iVar17 + -0x24 + iVar18 * 0x28) & 0x20000) != 0) &&
                    (*(char *)(iVar7 + 0x21cf) != '\0')) &&
                   ((*(int32_t *)(iVar7 + 0x2288) == 0 &&
                    ((((*(int64_t *)(iVar7 + 0x21d8) == iVar5 && (*(char *)(iVar7 + 0x2279) != '\0')) &&
                      (*(int32_t *)(iVar7 + 0x22c8) == 0)) && (*(int32_t *)(iVar7 + 0x2338) == 0)))))) {
                    *(undefined *)(iVar7 + 0x2279) = 0;
                    *(undefined4 *)(iVar7 + 0x1fb8) = *(undefined4 *)(iVar17 + -0x28 + iVar18 * 0x28);
                    *(uint32_t *)(iVar7 + 0x1fbc) = *(uint32_t *)(iVar17 + -0x20 + iVar18 * 0x28) & 0xffdfffff;
                    puVar6 = (undefined4 *)(iVar17 + -0x1c + iVar18 * 0x28);
                    uVar15 = puVar6[1];
                    uVar1 = puVar6[2];
                    uVar2 = puVar6[3];
                    *(undefined4 *)(iVar7 + 0x1fd4) = *puVar6;
                    *(undefined4 *)(iVar7 + 0x1fd8) = uVar15;
                    *(undefined4 *)(iVar7 + 0x1fdc) = uVar1;
                    *(undefined4 *)(iVar7 + 0x1fe0) = uVar2;
                    func_0x00018010ea60(iVar7 + 0x22c0);
                    *(undefined4 *)
                     (*(int64_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x438) + 0x47c +
                     (int64_t)*(int32_t *)(iVar7 + 0x21e4) * 8) = 0x7f7fffff;
                    if ((*(char *)(iVar7 + 0x2279) == '\0') && (*(char *)(iVar7 + 0x223a) == '\0')) {
                        uVar14 = 0;
                    } else {
                        uVar14 = 1;
                    }
                    *(undefined *)(iVar7 + 0x2239) = uVar14;
                }
                fVar29 = *(float *)(iVar17 + -0xc + iVar18 * 0x28);
                if ((fVar29 != 3.402823e+38) && (*(float *)(iVar5 + 700) <= *(float *)(iVar5 + 0x15c))) {
                    iVar24 = *(int64_t *)(iVar7 + 0x15e0);
                    fVar32 = *(float *)(iVar17 + -0x10 + iVar18 * 0x28);
                    fVar37 = *(float *)(iVar17 + -8 + iVar18 * 0x28);
                    if (fVar32 <= *(float *)(iVar24 + 700)) {
                        fVar32 = *(float *)(iVar24 + 700);
                    }
                    if ((*(uint32_t *)(iVar17 + -0x24 + iVar18 * 0x28) & 0x80000) != 0) {
                        fVar36 = *(float *)(iVar24 + 0x15c);
                        fVar30 = fVar36;
                        if ((*(int64_t *)(iVar7 + 0x24d0) != 0) &&
                           (fVar30 = *(float *)(*(int64_t *)(iVar7 + 0x24d0) + 0x80), fVar30 <= fVar36)) {
                            fVar30 = fVar36;
                        }
                        fVar36 = (float)(int32_t)((fVar30 - *(float *)(iVar7 + 0xdf0)) -
                                                 *(float *)(iVar7 + 0x12f8) * 0.5);
                        if (*(float *)(iVar7 + 0xdf0) + *(float *)(iVar7 + 0xe68) + fVar37 < fVar36) {
                            fVar37 = fVar36;
                        }
                    }
                    if (*(float *)(iVar24 + 0x2c4) <= fVar37) {
                        fVar37 = *(float *)(iVar24 + 0x2c4);
                    }
                    if (fVar32 < fVar37) {
                        iVar4 = *(int16_t *)(iVar17 + -4 + iVar18 * 0x28);
                        if ((iVar4 != -1) &&
                           (iVar8 = *(int64_t *)(iVar7 + 0x24d0), (*(uint32_t *)(iVar8 + 4) & 0x100000) == 0)) {
                            iVar23 = *(int64_t *)(iVar8 + 0x18);
                            iVar25 = (int64_t)iVar4 * 0x74;
                            iVar26 = *(int64_t *)(iVar24 + 800);
                            puVar6 = (undefined4 *)(iVar25 + 0x24 + iVar23);
                            uVar9 = puVar6[1];
                            uVar10 = puVar6[2];
                            uVar11 = puVar6[3];
                            uVar15 = *(undefined4 *)(iVar25 + 0x24 + iVar23);
                            uVar1 = *(undefined4 *)(iVar25 + 0x28 + iVar23);
                            uVar2 = *(undefined4 *)(iVar25 + 0x2c + iVar23);
                            uVar3 = *(undefined4 *)(iVar25 + 0x30 + iVar23);
                            *(undefined4 *)(iVar24 + 0x2b8) = *puVar6;
                            *(undefined4 *)(iVar24 + 700) = uVar9;
                            *(undefined4 *)(iVar24 + 0x2c0) = uVar10;
                            *(undefined4 *)(iVar24 + 0x2c4) = uVar11;
                            *(undefined4 *)(iVar26 + 0x60) = uVar15;
                            *(undefined4 *)(iVar26 + 100) = uVar1;
                            *(undefined4 *)(iVar26 + 0x68) = uVar2;
                            *(undefined4 *)(iVar26 + 0x6c) = uVar3;
                            iVar22 = (int64_t)*(int32_t *)(*(int64_t *)(iVar24 + 800) + 0xa0);
                            iVar26 = *(int64_t *)(*(int64_t *)(iVar24 + 800) + 0xa8);
                            *(undefined4 *)(iVar26 + -0x10 + iVar22 * 0x10) = uVar15;
                            *(undefined4 *)(iVar26 + -0xc + iVar22 * 0x10) = uVar1;
                            *(undefined4 *)(iVar26 + -8 + iVar22 * 0x10) = uVar2;
                            *(undefined4 *)(iVar26 + -4 + iVar22 * 0x10) = uVar3;
                            func_0x000180127010(*(undefined8 *)(iVar8 + 0x1a0), *(undefined8 *)(iVar24 + 800), 
                                                *(undefined2 *)(iVar25 + 0x60 + iVar23));
                        }
                        uStack_f8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1230);
                        uStack_f4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1234);
                        uStack_f0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1238);
                        fStack_ec = *(float *)(*(int64_t *)0x180781f28 + 0x123c) *
                                    *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                        fStackX_10 = (float)(int32_t)fVar29;
                        fStackX_14 = fVar37;
                        uStackX_18._0_4_ = fStackX_10;
                        uStackX_18._4_4_ = fVar32;
                        uVar15 = func_0x0001800f5fa0(&uStack_f8);
                        func_0x000180126300(*(undefined8 *)(iVar24 + 800), &uStackX_18, &fStackX_10, uVar15, 
                                            *(undefined4 *)(iVar7 + 0xe64));
                        if (((*(int16_t *)(iVar17 + -4 + iVar18 * 0x28) != -1) &&
                            (iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0),
                            (*(uint32_t *)(iVar17 + 4) & 0x100000) == 0)) && (*(int32_t *)(iVar17 + 0x74) != -1)) {
                            iVar18 = *(int64_t *)(iVar17 + 0x18);
                            iVar24 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
                            iVar26 = (int64_t)*(int32_t *)(iVar17 + 0x74) * 0x74;
                            iVar8 = *(int64_t *)(iVar24 + 800);
                            puVar6 = (undefined4 *)(iVar26 + 0x24 + iVar18);
                            uVar9 = puVar6[1];
                            uVar10 = puVar6[2];
                            uVar11 = puVar6[3];
                            uVar15 = *(undefined4 *)(iVar26 + 0x24 + iVar18);
                            uVar1 = *(undefined4 *)(iVar26 + 0x28 + iVar18);
                            uVar2 = *(undefined4 *)(iVar26 + 0x2c + iVar18);
                            uVar3 = *(undefined4 *)(iVar26 + 0x30 + iVar18);
                            *(undefined4 *)(iVar24 + 0x2b8) = *puVar6;
                            *(undefined4 *)(iVar24 + 700) = uVar9;
                            *(undefined4 *)(iVar24 + 0x2c0) = uVar10;
                            *(undefined4 *)(iVar24 + 0x2c4) = uVar11;
                            *(undefined4 *)(iVar8 + 0x60) = uVar15;
                            *(undefined4 *)(iVar8 + 100) = uVar1;
                            *(undefined4 *)(iVar8 + 0x68) = uVar2;
                            *(undefined4 *)(iVar8 + 0x6c) = uVar3;
                            iVar23 = (int64_t)*(int32_t *)(*(int64_t *)(iVar24 + 800) + 0xa0);
                            iVar8 = *(int64_t *)(*(int64_t *)(iVar24 + 800) + 0xa8);
                            *(undefined4 *)(iVar8 + -0x10 + iVar23 * 0x10) = uVar15;
                            *(undefined4 *)(iVar8 + -0xc + iVar23 * 0x10) = uVar1;
                            *(undefined4 *)(iVar8 + -8 + iVar23 * 0x10) = uVar2;
                            *(undefined4 *)(iVar8 + -4 + iVar23 * 0x10) = uVar3;
                            func_0x000180127010(*(undefined8 *)(iVar17 + 0x1a0), *(undefined8 *)(iVar24 + 800), 
                                                *(undefined2 *)(iVar26 + 0x60 + iVar18));
                        }
                    }
                }
                *(int32_t *)(iVar7 + 0x2140) = *(int32_t *)(iVar7 + 0x2140) + -1;
                uVar27 = ~uVar27;
                *(uint32_t *)(iVar5 + 0x1e4) = *(uint32_t *)(iVar5 + 0x1e4) & uVar27;
                *(uint32_t *)(iVar5 + 0x1e8) = *(uint32_t *)(iVar5 + 0x1e8) & uVar27;
                iVar17 = var_138h;
            }
            iVar16 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
            if (iVar16 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
                }
            } else {
                *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar16 + -1;
            }
        } while ((int32_t)*(int16_t *)(arg1 + 4) < *(int32_t *)(iVar17 + 0x1e0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 0xe) < *(int32_t *)(iVar12 + 0x2110)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e68);
            }
            func_0x00018010c110();
        } while ((int32_t)*(int16_t *)(arg1 + 0xe) < *(int32_t *)(iVar12 + 0x2110));
    }
    if ((int32_t)*(int16_t *)(arg1 + 2) < *(int32_t *)(iVar17 + 0x148)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e80);
            }
            iVar16 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
            if (iVar16 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
                }
            } else {
                *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar16 + -1;
            }
        } while ((int32_t)*(int16_t *)(arg1 + 2) < *(int32_t *)(iVar17 + 0x148));
    }
    if (*(int16_t *)(arg1 + 0x14) < *(int16_t *)(iVar12 + 0x281c)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e90);
            }
            iVar17 = *(int64_t *)0x180781f28;
            if ((*(uint8_t *)(iVar12 + 0x1f78) & 0x40) == 0) {
                *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) = *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) + -1;
                iVar16 = *(int32_t *)(iVar17 + 0x2100);
                *(int32_t *)(iVar17 + 0x2100) = iVar16 + -1;
                *(undefined4 *)(iVar17 + 0x1f78) =
                     *(undefined4 *)(*(int64_t *)(iVar17 + 0x2108) + -8 + (int64_t)iVar16 * 4);
                *(undefined4 *)(iVar17 + 0xd9c) =
                     *(undefined4 *)((int64_t)*(int32_t *)(iVar17 + 0x15b0) * 0x78 + -8 + *(int64_t *)(iVar17 + 0x15b8))
                ;
                *(undefined *)((int64_t)*(int32_t *)(iVar12 + 0x15b0) * 0x78 + -10 + *(int64_t *)(iVar12 + 0x15b8)) = 0;
            } else {
                func_0x000180106130();
            }
        } while (*(int16_t *)(arg1 + 0x14) < *(int16_t *)(iVar12 + 0x281c));
    }
    if ((int32_t)*(int16_t *)(arg1 + 6) < *(int32_t *)(iVar12 + 0x20c0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644df0);
            }
            func_0x0001800f6770(1);
        } while ((int32_t)*(int16_t *)(arg1 + 6) < *(int32_t *)(iVar12 + 0x20c0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 0x10) < *(int32_t *)(iVar12 + 0x2100)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e08);
            }
            iVar17 = *(int64_t *)0x180781f28;
            iVar16 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100);
            if (iVar16 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644628);
                }
            } else {
                *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100) = iVar16 + -1;
                *(undefined4 *)(iVar17 + 0x1f78) =
                     *(undefined4 *)(*(int64_t *)(iVar17 + 0x2108) + -8 + (int64_t)iVar16 * 4);
            }
        } while ((int32_t)*(int16_t *)(arg1 + 0x10) < *(int32_t *)(iVar12 + 0x2100));
    }
    if ((int32_t)*(int16_t *)(arg1 + 8) < *(int32_t *)(iVar12 + 0x20d0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e20);
            }
            func_0x0001800f6a20(1);
        } while ((int32_t)*(int16_t *)(arg1 + 8) < *(int32_t *)(iVar12 + 0x20d0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 10) < *(int32_t *)(iVar12 + 0x20e0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e38);
            }
            iVar17 = *(int64_t *)0x180781f28;
            if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) < 1) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445d0);
                }
            } else {
                func_0x0001801072d0(*(undefined8 *)
                                     (*(int64_t *)(*(int64_t *)0x180781f28 + 0x20e8) + -0x10 +
                                     (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) * 0x10));
                *(int32_t *)(iVar17 + 0x20e0) = *(int32_t *)(iVar17 + 0x20e0) + -1;
            }
        } while ((int32_t)*(int16_t *)(arg1 + 10) < *(int32_t *)(iVar12 + 0x20e0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 0xc) < *(int32_t *)(iVar12 + 0x20f0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644ea8);
            }
            iVar17 = *(int64_t *)0x180781f28;
            iVar16 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x20f0);
            if (*(int16_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x2a78) + 0xc) < iVar16) {
                *(int32_t *)(*(int64_t *)0x180781f28 + 0x20f0) = iVar16 + -1;
                if (iVar16 + -1 == 0) {
                    uVar15 = 0;
                } else {
                    uVar15 = *(undefined4 *)(*(int64_t *)(iVar17 + 0x20f8) + -0x10 + (int64_t)iVar16 * 8);
                }
                *(undefined4 *)(iVar17 + 0x1f74) = uVar15;
            } else if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445a8);
            }
        } while ((int32_t)*(int16_t *)(arg1 + 0xc) < *(int32_t *)(iVar12 + 0x20f0));
    }
    return;
}

// ============================================================
// Function: FUN_18010a090
// Address: 0x18010a090
// Size: 4 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_158h
// WARNING: Variable defined which should be unmapped: var_150h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Removing arg arg_8ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_94h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_13ch
// WARNING: [rz-ghidra] Detected overlap for variable var_144h
// WARNING: [rz-ghidra] Detected overlap for variable arg_9ch

void fcn.18010a070(int64_t arg1, int64_t arg_80h, int64_t arg_98h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int16_t iVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int64_t iVar12;
    char cVar13;
    undefined uVar14;
    undefined4 uVar15;
    int32_t iVar16;
    int64_t iVar17;
    int64_t iVar18;
    int32_t iVar19;
    int64_t *piVar20;
    int64_t *piVar21;
    int64_t iVar22;
    int64_t iVar23;
    int64_t iVar24;
    int64_t iVar25;
    int64_t iVar26;
    uint32_t uVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    float fVar31;
    float fVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    float fVar36;
    float fVar37;
    float fVar38;
    float fStackX_10;
    float fStackX_14;
    undefined8 uStackX_18;
    float fStackX_20;
    float fStackX_24;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    float var_120h;
    float var_11ch;
    int64_t var_118h;
    float var_110h;
    int64_t var_10ch;
    undefined4 var_104h;
    undefined4 var_100h;
    undefined4 var_fch;
    undefined4 uStack_f8;
    undefined4 uStack_f4;
    undefined4 uStack_f0;
    float fStack_ec;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar12 = *(int64_t *)0x180781f28;
    iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0);
    while ((iVar17 != 0 && (*(int64_t *)(iVar17 + 0x188) == *(int64_t *)(iVar12 + 0x15e0)))) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644dc0);
        }
        func_0x0001801346c0();
        iVar17 = *(int64_t *)(iVar12 + 0x24d0);
    }
    iVar17 = *(int64_t *)(iVar12 + 0x15e0);
    piVar21 = *(int64_t **)(iVar12 + 0x2538);
    var_138h = iVar17;
    while ((piVar21 != (int64_t *)0x0 && (*piVar21 == iVar17))) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644ca8);
        }
        func_0x000180148e50();
        piVar21 = *(int64_t **)(iVar12 + 0x2538);
    }
    iVar5 = *(int64_t *)(iVar12 + 0x25f0);
    while ((iVar5 != 0 && (**(int64_t **)(iVar5 + 0x28) == iVar17))) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644cc0);
        }
        iVar18 = *(int64_t *)0x180781f28;
        puVar6 = *(undefined4 **)(*(int64_t *)0x180781f28 + 0x25f0);
        iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        iVar5 = *(int64_t *)(puVar6 + 10);
        var_130h = iVar17;
        if ((puVar6[0xc] != *(int32_t *)(*(int64_t *)0x180781f28 + 0x1f74)) &&
           (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0)) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180645b48);
        }
        func_0x0001801474f0(&var_118h, puVar6, iVar17);
        fVar36 = (float)var_10ch;
        fVar37 = var_110h;
        fVar32 = var_118h._4_4_;
        fVar29 = (float)var_118h;
        if (*(char *)((int64_t)puVar6 + 0x52) != '\0') {
            if ((*(char *)((int64_t)puVar6 + 0x21) != '\0') ||
               ((*(char *)((int64_t)puVar6 + 0x55) == '\0' && (*(int64_t *)(puVar6 + 4) != -1)))) {
                *(undefined8 *)(iVar5 + 0x18) = 0xffffffffffffffff;
            }
            if ((*(char *)(puVar6 + 0x15) == '\0') && (*(int64_t *)(iVar5 + 0x20) != -1)) {
                *(undefined8 *)(iVar5 + 0x20) = 0xffffffffffffffff;
                *(undefined *)(iVar5 + 0x15) = 0xff;
            }
            iVar5 = *(int64_t *)0x180781f28;
            uVar27 = puVar6[0xd];
            if (((((uVar27 & 0xc0) != 0) && (puVar6[0x12] != 0)) &&
                (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2588) == puVar6[0x12])) &&
               (*(char *)(*(int64_t *)0x180781f28 + 0x258c) != '\0')) {
                iVar7 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
                *(undefined *)(*(int64_t *)0x180781f28 + 0x25b8) = 0;
                iVar24 = *(int64_t *)0x180781f28;
                fVar30 = *(float *)(iVar5 + 0x11c);
                fVar28 = var_118h._4_4_;
                if ((var_118h._4_4_ <= fVar30) && (fVar28 = (float)var_10ch, fVar30 <= (float)var_10ch)) {
                    fVar28 = fVar30;
                }
                fVar30 = *(float *)(iVar5 + 0x118);
                fVar34 = (float)var_118h;
                if (((float)var_118h <= fVar30) && (fVar34 = var_110h, fVar30 <= var_110h)) {
                    fVar34 = fVar30;
                }
                fVar30 = *(float *)(iVar7 + 0x168);
                fVar38 = *(float *)(iVar5 + 0x25e8);
                if ((float)var_10ch <= *(float *)(iVar5 + 0x25e8)) {
                    fVar38 = (float)var_10ch;
                }
                *(float *)(iVar5 + 0x25a4) = fVar28 - *(float *)(iVar7 + 0x16c);
                fVar28 = *(float *)(iVar5 + 0x25e4);
                if (var_110h <= *(float *)(iVar5 + 0x25e4)) {
                    fVar28 = var_110h;
                }
                *(float *)(iVar5 + 0x25a0) = fVar34 - fVar30;
                uStack_f8 = *(undefined4 *)(iVar24 + 0x1090);
                uStack_f4 = *(undefined4 *)(iVar24 + 0x1094);
                uStack_f0 = *(undefined4 *)(iVar24 + 0x1098);
                fVar30 = *(float *)(iVar5 + 0x25dc);
                if (*(float *)(iVar5 + 0x25dc) <= (float)var_118h) {
                    fVar30 = (float)var_118h;
                }
                fVar34 = *(float *)(iVar5 + 0x25e0);
                if (*(float *)(iVar5 + 0x25e0) <= var_118h._4_4_) {
                    fVar34 = var_118h._4_4_;
                }
                fStack_ec = *(float *)(iVar24 + 0x109c) * *(float *)(iVar24 + 0xd9c) * 0.3;
                var_128h._0_4_ = fVar30;
                var_128h._4_4_ = fVar34;
                var_120h = fVar28;
                var_11ch = fVar38;
                uVar15 = func_0x0001800f5fa0(&uStack_f8);
                func_0x000180126550(*(undefined8 *)(iVar7 + 800), &var_128h, &var_120h, uVar15, 0, 0);
                uStack_f8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1270);
                uStack_f4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1274);
                uStack_f0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1278);
                fStack_ec = *(float *)(*(int64_t *)0x180781f28 + 0x127c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                iVar24 = *(int64_t *)0x180781f28;
                fStackX_10 = (float)func_0x0001800f5fa0();
                if (((uint32_t)fStackX_10 & 0xff000000) != 0) {
                    iVar17 = *(int64_t *)(iVar7 + 800);
                    if ((*(uint8_t *)(iVar17 + 0x30) & 1) == 0) {
                        var_148h._0_4_ = fVar28 - 0.49;
                        var_148h._4_4_ = fVar38 - 0.49;
                        piVar21 = &var_148h;
                        piVar20 = &var_140h;
                        var_140h._0_4_ = fVar30 + 0.5;
                        var_140h._4_4_ = fVar34 + 0.5;
                    } else {
                        uStackX_18._0_4_ = fVar28 - 0.5;
                        uStackX_18._4_4_ = fVar38 - 0.5;
                        piVar21 = &uStackX_18;
                        piVar20 = (int64_t *)&fStackX_20;
                        fStackX_20 = fVar30 + 0.5;
                        fStackX_24 = fVar34 + 0.5;
                    }
                    func_0x000180125f20(iVar17, piVar20, piVar21);
                    func_0x0001801248e0(iVar17, *(undefined8 *)(iVar17 + 0x58), *(undefined4 *)(iVar17 + 0x50), 
                                        fStackX_10, 1, 0x3f800000);
                    iVar24 = *(int64_t *)0x180781f28;
                    *(undefined4 *)(iVar17 + 0x50) = 0;
                    iVar17 = var_130h;
                }
                if ((uVar27 & 0x900) == 0x800) {
                    fVar28 = (float)(*(uint32_t *)(iVar5 + 0x12f8) ^ 0x80000000);
                    fVar34 = fVar29 - fVar28;
                    fVar38 = fVar32 - fVar28;
                    fVar30 = fVar37 + fVar28;
                    fVar28 = fVar36 + fVar28;
                    if ((((*(float *)(iVar5 + 0x118) < fVar34) || (*(float *)(iVar5 + 0x11c) < fVar38)) ||
                        (fVar30 <= *(float *)(iVar5 + 0x118))) || (fVar28 <= *(float *)(iVar5 + 0x11c))) {
                        fVar33 = *(float *)(iVar24 + 0x118);
                        if ((((fVar30 < fVar33) || (fVar30 = fVar34, fVar33 < fVar34)) &&
                            ((fVar33 = fVar33 - fVar30, fVar33 != 0.0 &&
                             ((fVar30 = *(float *)(iVar7 + 0xd4), 0.0 <= fVar33 || (0.0 <= fVar30)))))) &&
                           ((fVar33 <= 0.0 || (fVar30 < *(float *)(iVar7 + 0xdc))))) {
                            fVar34 = *(float *)(iVar24 + 0x12f8);
                            fVar35 = ((float)((uint32_t)fVar33 & 0x7fffffff) - fVar34) / (fVar34 * 5.0 - fVar34);
                            if (0.0 <= fVar35) {
                                fVar31 = 1.0;
                                if (fVar35 <= 1.0) {
                                    fVar31 = fVar35;
                                }
                            } else {
                                fVar31 = 0.0;
                            }
                            if (0.0 <= fVar33) {
                                if (fVar33 <= 0.0) {
                                    fVar33 = 0.0;
                                } else {
                                    fVar33 = 1.0;
                                }
                            } else {
                                fVar33 = -1.0;
                            }
                            fVar34 = (fVar31 * 3.0 + 1.0) * fVar34 * 35.0 * fVar33 * *(float *)(iVar24 + 0x48) +
                                     *(float *)(iVar5 + 0x25a8);
                            *(float *)(iVar5 + 0x25a8) = fVar34;
                            iVar16 = (int32_t)fVar34;
                            if ((fVar34 < 0.0) && ((float)iVar16 != fVar34)) {
                                iVar16 = iVar16 + -1;
                            }
                            fVar34 = (float)iVar16;
                            if (fVar34 != 0.0) {
                                *(undefined4 *)(iVar7 + 0xec) = 0;
                                *(undefined4 *)(iVar7 + 0xf4) = 0;
                                *(float *)(iVar7 + 0xe4) = fVar34 + fVar30;
                                *(float *)(iVar5 + 0x25a8) = *(float *)(iVar5 + 0x25a8) - fVar34;
                            }
                        }
                        fVar30 = *(float *)(iVar24 + 0x11c);
                        if (((((fVar28 < fVar30) || (fVar28 = fVar38, fVar30 < fVar38)) &&
                             (fVar30 = fVar30 - fVar28, fVar30 != 0.0)) &&
                            ((fVar28 = *(float *)(iVar7 + 0xd8), 0.0 <= fVar30 || (0.0 <= fVar28)))) &&
                           ((fVar30 <= 0.0 || (fVar28 < *(float *)(iVar7 + 0xe0))))) {
                            fVar34 = *(float *)(iVar24 + 0x12f8);
                            fVar38 = ((float)((uint32_t)fVar30 & 0x7fffffff) - fVar34) / (fVar34 * 5.0 - fVar34);
                            if (0.0 <= fVar38) {
                                fVar33 = 1.0;
                                if (fVar38 <= 1.0) {
                                    fVar33 = fVar38;
                                }
                            } else {
                                fVar33 = 0.0;
                            }
                            if (0.0 <= fVar30) {
                                if (fVar30 <= 0.0) {
                                    fVar30 = 0.0;
                                } else {
                                    fVar30 = 1.0;
                                }
                            } else {
                                fVar30 = -1.0;
                            }
                            fVar30 = (fVar33 * 3.0 + 1.0) * fVar34 * 35.0 * fVar30 * *(float *)(iVar24 + 0x48) +
                                     *(float *)(iVar5 + 0x25ac);
                            *(float *)(iVar5 + 0x25ac) = fVar30;
                            iVar16 = (int32_t)fVar30;
                            if ((fVar30 < 0.0) && ((float)iVar16 != fVar30)) {
                                iVar16 = iVar16 + -1;
                            }
                            fVar30 = (float)iVar16;
                            if (fVar30 != 0.0) {
                                *(float *)(iVar7 + 0xe8) = fVar28 + fVar30;
                                *(undefined4 *)(iVar7 + 0xf0) = 0;
                                *(undefined4 *)(iVar7 + 0xf8) = 0;
                                *(float *)(iVar5 + 0x25ac) = *(float *)(iVar5 + 0x25ac) - fVar30;
                            }
                        }
                    }
                }
            }
        }
        if (*(char *)((int64_t)puVar6 + 0x51) == '\0') {
            iVar16 = puVar6[1];
            if (iVar16 < 0) {
                iVar16 = (iVar16 + 1 >> 1) + iVar16;
                iVar19 = 0;
                if (0 < iVar16) {
                    iVar19 = iVar16;
                }
                func_0x00018014fa90(puVar6, iVar19);
            }
            *puVar6 = 0;
        }
        cVar13 = func_0x0001801062b0();
        iVar5 = *(int64_t *)0x180781f28;
        if ((((cVar13 != '\0') && (fVar30 = *(float *)(iVar18 + 0x118), *(float *)(iVar17 + 0x278) <= fVar30)) &&
            (fVar28 = *(float *)(iVar18 + 0x11c), *(float *)(iVar17 + 0x27c) <= fVar28)) &&
           ((fVar30 < *(float *)(iVar17 + 0x280) && (fVar28 < *(float *)(iVar17 + 0x284))))) {
            if (((((uint32_t)puVar6[0xd] >> 0xc & 1) == 0) ||
                (((fVar29 <= fVar30 && (fVar32 <= fVar28)) && ((fVar30 < fVar37 && (fVar28 < fVar36)))))) &&
               ((*(int32_t *)(iVar18 + 0x163c) == 0 && (*(int32_t *)(iVar18 + 0x1654) == 0)))) {
                if (((puVar6[0xd] & 0xc0) != 0) &&
                   (((*(char *)(iVar18 + 0x258c) == '\0' && (*(char *)(iVar18 + 0x258d) == '\0')) &&
                    (*(int16_t *)(iVar18 + 0xb5a) == 1)))) {
                    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2588) = puVar6[0x12];
                    *(undefined2 *)(iVar5 + 0x258d) = 0x101;
                    *(undefined *)(iVar5 + 0x258f) = 1;
                    *(undefined2 *)(iVar5 + 0x2594) = *(undefined2 *)(iVar5 + 0x13c);
                    fVar32 = *(float *)(iVar5 + 0x118) - *(float *)(*(int64_t *)(iVar5 + 0x15e0) + 0x168);
                    fVar29 = *(float *)(iVar5 + 0x11c) - *(float *)(*(int64_t *)(iVar5 + 0x15e0) + 0x16c);
                    *(undefined8 *)(iVar5 + 0x25a8) = 0;
                    *(float *)(iVar5 + 0x25a0) = fVar32;
                    *(float *)(iVar5 + 0x25a4) = fVar29;
                    *(float *)(iVar5 + 0x2598) = fVar32;
                    *(float *)(iVar5 + 0x259c) = fVar29;
                    func_0x00018010e050(iVar17, 2);
                    iVar5 = *(int64_t *)0x180781f28;
                    iVar16 = puVar6[0x12];
                    *(int32_t *)(*(int64_t *)0x180781f28 + 0x163c) = iVar16;
                    *(undefined *)(iVar5 + 0x1650) = 0;
                    if ((iVar16 != 0) && (*(int32_t *)(iVar5 + 0x1640) != iVar16)) {
                        *(undefined8 *)(iVar5 + 0x1648) = 0;
                    }
                    if ((puVar6[0xd] & 0x1000) != 0) {
                        var_10ch._4_4_ = *(undefined4 *)(iVar18 + 0x118);
                        var_104h = *(undefined4 *)(iVar18 + 0x11c);
                        var_100h = var_10ch._4_4_;
                        var_fch = var_104h;
                        func_0x00018010e3f0(0, 0, puVar6[0xc], (int64_t)&var_10ch + 4);
                    }
                }
                if ((((puVar6[0xd] & 0x400) != 0) && (cVar13 = fcn.180108070(0), cVar13 != '\0')) &&
                   ((*(float *)(*(int64_t *)0x180781f28 + 0xbfc) <
                     *(float *)(*(int64_t *)0x180781f28 + 0xa4) * *(float *)(*(int64_t *)0x180781f28 + 0xa4) &&
                    (*(int32_t *)(iVar18 + 0x13c) == 0)))) {
                    func_0x000180147c50(puVar6);
                }
            }
        }
        iVar5 = *(int64_t *)0x180781f28;
        if ((puVar6[0xd] & 0x10000) != 0) {
            *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
            if (((*(int64_t *)(iVar5 + 0x21d8) == *(int64_t *)(iVar5 + 0x15e0)) && (*(char *)(iVar5 + 0x2279) != '\0'))
               && (*(int32_t *)(iVar5 + 0x21e4) == *(int32_t *)(*(int64_t *)(iVar5 + 0x15e0) + 0x1b0))) {
                *(uint32_t *)(iVar5 + 0x227c) = *(uint32_t *)(iVar5 + 0x227c) & 0xfffffff4;
                *(uint32_t *)(iVar5 + 0x227c) = *(uint32_t *)(iVar5 + 0x227c) | 4;
            }
        }
        if ((*(int64_t *)(iVar18 + 0x24d0) != 0) && (*(char *)(*(int64_t *)(iVar18 + 0x24d0) + 0x23a) != '\0')) {
            func_0x000180136780();
        }
        fVar29 = (float)puVar6[0x10];
        if ((float)puVar6[0x10] <= *(float *)(iVar17 + 0x170)) {
            fVar29 = *(float *)(iVar17 + 0x170);
        }
        fVar32 = (float)puVar6[0x11];
        if ((float)puVar6[0x11] <= *(float *)(iVar17 + 0x174)) {
            fVar32 = *(float *)(iVar17 + 0x174);
        }
        *(float *)(iVar17 + 0x170) = fVar29;
        *(float *)(iVar17 + 0x174) = fVar32;
        func_0x0001801067d0();
        puVar6[0xc] = 0;
        puVar6[0xd] = 0;
        *(int32_t *)(iVar18 + 0x25f8) = *(int32_t *)(iVar18 + 0x25f8) + -1;
        if (*(int32_t *)(iVar18 + 0x25f8) < 1) {
            iVar17 = 0;
        } else {
            iVar17 = (int64_t)(*(int32_t *)(iVar18 + 0x25f8) + -1) * 0x58 + *(int64_t *)(iVar18 + 0x2608);
        }
        *(int64_t *)(iVar18 + 0x25f0) = iVar17;
        iVar17 = var_138h;
        iVar5 = *(int64_t *)(iVar12 + 0x25f0);
    }
    if (*(char *)(iVar17 + 0x1bb) != '\0') {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644ce0);
        }
        func_0x000180147f30();
    }
    if ((int32_t)*(int16_t *)(arg1 + 4) < *(int32_t *)(iVar17 + 0x1e0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e50);
            }
            iVar7 = *(int64_t *)0x180781f28;
            iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
            *(undefined *)(iVar5 + 0x10b) = 1;
            iVar18 = *(int64_t *)(iVar7 + 0x15e0);
            fVar29 = *(float *)(iVar18 + 0x19c) - *(float *)(iVar7 + 0xe0c);
            *(float *)(iVar18 + 0x19c) = fVar29;
            *(float *)(iVar18 + 0x158) = fVar29 + *(float *)(iVar18 + 0x60) + *(float *)(iVar18 + 0x1a0);
            *(int32_t *)(iVar5 + 0x1e0) = *(int32_t *)(iVar5 + 0x1e0) + -1;
            uVar27 = 1 << ((uint8_t)*(undefined4 *)(iVar5 + 0x1e0) & 0x1f);
            if ((*(uint32_t *)(iVar5 + 0x1e4) & uVar27) != 0) {
                iVar18 = (int64_t)*(int32_t *)(iVar7 + 0x2140);
                iVar17 = *(int64_t *)(iVar7 + 0x2148);
                if ((((*(uint32_t *)(iVar17 + -0x24 + iVar18 * 0x28) & 0x20000) != 0) &&
                    (*(char *)(iVar7 + 0x21cf) != '\0')) &&
                   ((*(int32_t *)(iVar7 + 0x2288) == 0 &&
                    ((((*(int64_t *)(iVar7 + 0x21d8) == iVar5 && (*(char *)(iVar7 + 0x2279) != '\0')) &&
                      (*(int32_t *)(iVar7 + 0x22c8) == 0)) && (*(int32_t *)(iVar7 + 0x2338) == 0)))))) {
                    *(undefined *)(iVar7 + 0x2279) = 0;
                    *(undefined4 *)(iVar7 + 0x1fb8) = *(undefined4 *)(iVar17 + -0x28 + iVar18 * 0x28);
                    *(uint32_t *)(iVar7 + 0x1fbc) = *(uint32_t *)(iVar17 + -0x20 + iVar18 * 0x28) & 0xffdfffff;
                    puVar6 = (undefined4 *)(iVar17 + -0x1c + iVar18 * 0x28);
                    uVar15 = puVar6[1];
                    uVar1 = puVar6[2];
                    uVar2 = puVar6[3];
                    *(undefined4 *)(iVar7 + 0x1fd4) = *puVar6;
                    *(undefined4 *)(iVar7 + 0x1fd8) = uVar15;
                    *(undefined4 *)(iVar7 + 0x1fdc) = uVar1;
                    *(undefined4 *)(iVar7 + 0x1fe0) = uVar2;
                    func_0x00018010ea60(iVar7 + 0x22c0);
                    *(undefined4 *)
                     (*(int64_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x438) + 0x47c +
                     (int64_t)*(int32_t *)(iVar7 + 0x21e4) * 8) = 0x7f7fffff;
                    if ((*(char *)(iVar7 + 0x2279) == '\0') && (*(char *)(iVar7 + 0x223a) == '\0')) {
                        uVar14 = 0;
                    } else {
                        uVar14 = 1;
                    }
                    *(undefined *)(iVar7 + 0x2239) = uVar14;
                }
                fVar29 = *(float *)(iVar17 + -0xc + iVar18 * 0x28);
                if ((fVar29 != 3.402823e+38) && (*(float *)(iVar5 + 700) <= *(float *)(iVar5 + 0x15c))) {
                    iVar24 = *(int64_t *)(iVar7 + 0x15e0);
                    fVar32 = *(float *)(iVar17 + -0x10 + iVar18 * 0x28);
                    fVar37 = *(float *)(iVar17 + -8 + iVar18 * 0x28);
                    if (fVar32 <= *(float *)(iVar24 + 700)) {
                        fVar32 = *(float *)(iVar24 + 700);
                    }
                    if ((*(uint32_t *)(iVar17 + -0x24 + iVar18 * 0x28) & 0x80000) != 0) {
                        fVar36 = *(float *)(iVar24 + 0x15c);
                        fVar30 = fVar36;
                        if ((*(int64_t *)(iVar7 + 0x24d0) != 0) &&
                           (fVar30 = *(float *)(*(int64_t *)(iVar7 + 0x24d0) + 0x80), fVar30 <= fVar36)) {
                            fVar30 = fVar36;
                        }
                        fVar36 = (float)(int32_t)((fVar30 - *(float *)(iVar7 + 0xdf0)) -
                                                 *(float *)(iVar7 + 0x12f8) * 0.5);
                        if (*(float *)(iVar7 + 0xdf0) + *(float *)(iVar7 + 0xe68) + fVar37 < fVar36) {
                            fVar37 = fVar36;
                        }
                    }
                    if (*(float *)(iVar24 + 0x2c4) <= fVar37) {
                        fVar37 = *(float *)(iVar24 + 0x2c4);
                    }
                    if (fVar32 < fVar37) {
                        iVar4 = *(int16_t *)(iVar17 + -4 + iVar18 * 0x28);
                        if ((iVar4 != -1) &&
                           (iVar8 = *(int64_t *)(iVar7 + 0x24d0), (*(uint32_t *)(iVar8 + 4) & 0x100000) == 0)) {
                            iVar23 = *(int64_t *)(iVar8 + 0x18);
                            iVar25 = (int64_t)iVar4 * 0x74;
                            iVar26 = *(int64_t *)(iVar24 + 800);
                            puVar6 = (undefined4 *)(iVar25 + 0x24 + iVar23);
                            uVar9 = puVar6[1];
                            uVar10 = puVar6[2];
                            uVar11 = puVar6[3];
                            uVar15 = *(undefined4 *)(iVar25 + 0x24 + iVar23);
                            uVar1 = *(undefined4 *)(iVar25 + 0x28 + iVar23);
                            uVar2 = *(undefined4 *)(iVar25 + 0x2c + iVar23);
                            uVar3 = *(undefined4 *)(iVar25 + 0x30 + iVar23);
                            *(undefined4 *)(iVar24 + 0x2b8) = *puVar6;
                            *(undefined4 *)(iVar24 + 700) = uVar9;
                            *(undefined4 *)(iVar24 + 0x2c0) = uVar10;
                            *(undefined4 *)(iVar24 + 0x2c4) = uVar11;
                            *(undefined4 *)(iVar26 + 0x60) = uVar15;
                            *(undefined4 *)(iVar26 + 100) = uVar1;
                            *(undefined4 *)(iVar26 + 0x68) = uVar2;
                            *(undefined4 *)(iVar26 + 0x6c) = uVar3;
                            iVar22 = (int64_t)*(int32_t *)(*(int64_t *)(iVar24 + 800) + 0xa0);
                            iVar26 = *(int64_t *)(*(int64_t *)(iVar24 + 800) + 0xa8);
                            *(undefined4 *)(iVar26 + -0x10 + iVar22 * 0x10) = uVar15;
                            *(undefined4 *)(iVar26 + -0xc + iVar22 * 0x10) = uVar1;
                            *(undefined4 *)(iVar26 + -8 + iVar22 * 0x10) = uVar2;
                            *(undefined4 *)(iVar26 + -4 + iVar22 * 0x10) = uVar3;
                            func_0x000180127010(*(undefined8 *)(iVar8 + 0x1a0), *(undefined8 *)(iVar24 + 800), 
                                                *(undefined2 *)(iVar25 + 0x60 + iVar23));
                        }
                        uStack_f8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1230);
                        uStack_f4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1234);
                        uStack_f0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1238);
                        fStack_ec = *(float *)(*(int64_t *)0x180781f28 + 0x123c) *
                                    *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                        fStackX_10 = (float)(int32_t)fVar29;
                        fStackX_14 = fVar37;
                        uStackX_18._0_4_ = fStackX_10;
                        uStackX_18._4_4_ = fVar32;
                        uVar15 = func_0x0001800f5fa0(&uStack_f8);
                        func_0x000180126300(*(undefined8 *)(iVar24 + 800), &uStackX_18, &fStackX_10, uVar15, 
                                            *(undefined4 *)(iVar7 + 0xe64));
                        if (((*(int16_t *)(iVar17 + -4 + iVar18 * 0x28) != -1) &&
                            (iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0),
                            (*(uint32_t *)(iVar17 + 4) & 0x100000) == 0)) && (*(int32_t *)(iVar17 + 0x74) != -1)) {
                            iVar18 = *(int64_t *)(iVar17 + 0x18);
                            iVar24 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
                            iVar26 = (int64_t)*(int32_t *)(iVar17 + 0x74) * 0x74;
                            iVar8 = *(int64_t *)(iVar24 + 800);
                            puVar6 = (undefined4 *)(iVar26 + 0x24 + iVar18);
                            uVar9 = puVar6[1];
                            uVar10 = puVar6[2];
                            uVar11 = puVar6[3];
                            uVar15 = *(undefined4 *)(iVar26 + 0x24 + iVar18);
                            uVar1 = *(undefined4 *)(iVar26 + 0x28 + iVar18);
                            uVar2 = *(undefined4 *)(iVar26 + 0x2c + iVar18);
                            uVar3 = *(undefined4 *)(iVar26 + 0x30 + iVar18);
                            *(undefined4 *)(iVar24 + 0x2b8) = *puVar6;
                            *(undefined4 *)(iVar24 + 700) = uVar9;
                            *(undefined4 *)(iVar24 + 0x2c0) = uVar10;
                            *(undefined4 *)(iVar24 + 0x2c4) = uVar11;
                            *(undefined4 *)(iVar8 + 0x60) = uVar15;
                            *(undefined4 *)(iVar8 + 100) = uVar1;
                            *(undefined4 *)(iVar8 + 0x68) = uVar2;
                            *(undefined4 *)(iVar8 + 0x6c) = uVar3;
                            iVar23 = (int64_t)*(int32_t *)(*(int64_t *)(iVar24 + 800) + 0xa0);
                            iVar8 = *(int64_t *)(*(int64_t *)(iVar24 + 800) + 0xa8);
                            *(undefined4 *)(iVar8 + -0x10 + iVar23 * 0x10) = uVar15;
                            *(undefined4 *)(iVar8 + -0xc + iVar23 * 0x10) = uVar1;
                            *(undefined4 *)(iVar8 + -8 + iVar23 * 0x10) = uVar2;
                            *(undefined4 *)(iVar8 + -4 + iVar23 * 0x10) = uVar3;
                            func_0x000180127010(*(undefined8 *)(iVar17 + 0x1a0), *(undefined8 *)(iVar24 + 800), 
                                                *(undefined2 *)(iVar26 + 0x60 + iVar18));
                        }
                    }
                }
                *(int32_t *)(iVar7 + 0x2140) = *(int32_t *)(iVar7 + 0x2140) + -1;
                uVar27 = ~uVar27;
                *(uint32_t *)(iVar5 + 0x1e4) = *(uint32_t *)(iVar5 + 0x1e4) & uVar27;
                *(uint32_t *)(iVar5 + 0x1e8) = *(uint32_t *)(iVar5 + 0x1e8) & uVar27;
                iVar17 = var_138h;
            }
            iVar16 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
            if (iVar16 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
                }
            } else {
                *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar16 + -1;
            }
        } while ((int32_t)*(int16_t *)(arg1 + 4) < *(int32_t *)(iVar17 + 0x1e0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 0xe) < *(int32_t *)(iVar12 + 0x2110)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e68);
            }
            func_0x00018010c110();
        } while ((int32_t)*(int16_t *)(arg1 + 0xe) < *(int32_t *)(iVar12 + 0x2110));
    }
    if ((int32_t)*(int16_t *)(arg1 + 2) < *(int32_t *)(iVar17 + 0x148)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e80);
            }
            iVar16 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
            if (iVar16 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
                }
            } else {
                *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar16 + -1;
            }
        } while ((int32_t)*(int16_t *)(arg1 + 2) < *(int32_t *)(iVar17 + 0x148));
    }
    if (*(int16_t *)(arg1 + 0x14) < *(int16_t *)(iVar12 + 0x281c)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e90);
            }
            iVar17 = *(int64_t *)0x180781f28;
            if ((*(uint8_t *)(iVar12 + 0x1f78) & 0x40) == 0) {
                *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) = *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) + -1;
                iVar16 = *(int32_t *)(iVar17 + 0x2100);
                *(int32_t *)(iVar17 + 0x2100) = iVar16 + -1;
                *(undefined4 *)(iVar17 + 0x1f78) =
                     *(undefined4 *)(*(int64_t *)(iVar17 + 0x2108) + -8 + (int64_t)iVar16 * 4);
                *(undefined4 *)(iVar17 + 0xd9c) =
                     *(undefined4 *)((int64_t)*(int32_t *)(iVar17 + 0x15b0) * 0x78 + -8 + *(int64_t *)(iVar17 + 0x15b8))
                ;
                *(undefined *)((int64_t)*(int32_t *)(iVar12 + 0x15b0) * 0x78 + -10 + *(int64_t *)(iVar12 + 0x15b8)) = 0;
            } else {
                func_0x000180106130();
            }
        } while (*(int16_t *)(arg1 + 0x14) < *(int16_t *)(iVar12 + 0x281c));
    }
    if ((int32_t)*(int16_t *)(arg1 + 6) < *(int32_t *)(iVar12 + 0x20c0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644df0);
            }
            func_0x0001800f6770(1);
        } while ((int32_t)*(int16_t *)(arg1 + 6) < *(int32_t *)(iVar12 + 0x20c0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 0x10) < *(int32_t *)(iVar12 + 0x2100)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e08);
            }
            iVar17 = *(int64_t *)0x180781f28;
            iVar16 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100);
            if (iVar16 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644628);
                }
            } else {
                *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100) = iVar16 + -1;
                *(undefined4 *)(iVar17 + 0x1f78) =
                     *(undefined4 *)(*(int64_t *)(iVar17 + 0x2108) + -8 + (int64_t)iVar16 * 4);
            }
        } while ((int32_t)*(int16_t *)(arg1 + 0x10) < *(int32_t *)(iVar12 + 0x2100));
    }
    if ((int32_t)*(int16_t *)(arg1 + 8) < *(int32_t *)(iVar12 + 0x20d0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e20);
            }
            func_0x0001800f6a20(1);
        } while ((int32_t)*(int16_t *)(arg1 + 8) < *(int32_t *)(iVar12 + 0x20d0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 10) < *(int32_t *)(iVar12 + 0x20e0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e38);
            }
            iVar17 = *(int64_t *)0x180781f28;
            if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) < 1) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445d0);
                }
            } else {
                func_0x0001801072d0(*(undefined8 *)
                                     (*(int64_t *)(*(int64_t *)0x180781f28 + 0x20e8) + -0x10 +
                                     (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) * 0x10));
                *(int32_t *)(iVar17 + 0x20e0) = *(int32_t *)(iVar17 + 0x20e0) + -1;
            }
        } while ((int32_t)*(int16_t *)(arg1 + 10) < *(int32_t *)(iVar12 + 0x20e0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 0xc) < *(int32_t *)(iVar12 + 0x20f0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644ea8);
            }
            iVar17 = *(int64_t *)0x180781f28;
            iVar16 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x20f0);
            if (*(int16_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x2a78) + 0xc) < iVar16) {
                *(int32_t *)(*(int64_t *)0x180781f28 + 0x20f0) = iVar16 + -1;
                if (iVar16 + -1 == 0) {
                    uVar15 = 0;
                } else {
                    uVar15 = *(undefined4 *)(*(int64_t *)(iVar17 + 0x20f8) + -0x10 + (int64_t)iVar16 * 8);
                }
                *(undefined4 *)(iVar17 + 0x1f74) = uVar15;
            } else if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445a8);
            }
        } while ((int32_t)*(int16_t *)(arg1 + 0xc) < *(int32_t *)(iVar12 + 0x20f0));
    }
    return;
}

// ============================================================
// Function: FUN_18010a094
// Address: 0x18010a094
// Size: 254 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_158h
// WARNING: Variable defined which should be unmapped: var_150h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Removing arg arg_8ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_94h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_13ch
// WARNING: [rz-ghidra] Detected overlap for variable var_144h
// WARNING: [rz-ghidra] Detected overlap for variable arg_9ch

void fcn.18010a070(int64_t arg1, int64_t arg_80h, int64_t arg_98h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int16_t iVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int64_t iVar12;
    char cVar13;
    undefined uVar14;
    undefined4 uVar15;
    int32_t iVar16;
    int64_t iVar17;
    int64_t iVar18;
    int32_t iVar19;
    int64_t *piVar20;
    int64_t *piVar21;
    int64_t iVar22;
    int64_t iVar23;
    int64_t iVar24;
    int64_t iVar25;
    int64_t iVar26;
    uint32_t uVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    float fVar31;
    float fVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    float fVar36;
    float fVar37;
    float fVar38;
    float fStackX_10;
    float fStackX_14;
    undefined8 uStackX_18;
    float fStackX_20;
    float fStackX_24;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    float var_120h;
    float var_11ch;
    int64_t var_118h;
    float var_110h;
    int64_t var_10ch;
    undefined4 var_104h;
    undefined4 var_100h;
    undefined4 var_fch;
    undefined4 uStack_f8;
    undefined4 uStack_f4;
    undefined4 uStack_f0;
    float fStack_ec;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar12 = *(int64_t *)0x180781f28;
    iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0);
    while ((iVar17 != 0 && (*(int64_t *)(iVar17 + 0x188) == *(int64_t *)(iVar12 + 0x15e0)))) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644dc0);
        }
        func_0x0001801346c0();
        iVar17 = *(int64_t *)(iVar12 + 0x24d0);
    }
    iVar17 = *(int64_t *)(iVar12 + 0x15e0);
    piVar21 = *(int64_t **)(iVar12 + 0x2538);
    var_138h = iVar17;
    while ((piVar21 != (int64_t *)0x0 && (*piVar21 == iVar17))) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644ca8);
        }
        func_0x000180148e50();
        piVar21 = *(int64_t **)(iVar12 + 0x2538);
    }
    iVar5 = *(int64_t *)(iVar12 + 0x25f0);
    while ((iVar5 != 0 && (**(int64_t **)(iVar5 + 0x28) == iVar17))) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644cc0);
        }
        iVar18 = *(int64_t *)0x180781f28;
        puVar6 = *(undefined4 **)(*(int64_t *)0x180781f28 + 0x25f0);
        iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        iVar5 = *(int64_t *)(puVar6 + 10);
        var_130h = iVar17;
        if ((puVar6[0xc] != *(int32_t *)(*(int64_t *)0x180781f28 + 0x1f74)) &&
           (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0)) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180645b48);
        }
        func_0x0001801474f0(&var_118h, puVar6, iVar17);
        fVar36 = (float)var_10ch;
        fVar37 = var_110h;
        fVar32 = var_118h._4_4_;
        fVar29 = (float)var_118h;
        if (*(char *)((int64_t)puVar6 + 0x52) != '\0') {
            if ((*(char *)((int64_t)puVar6 + 0x21) != '\0') ||
               ((*(char *)((int64_t)puVar6 + 0x55) == '\0' && (*(int64_t *)(puVar6 + 4) != -1)))) {
                *(undefined8 *)(iVar5 + 0x18) = 0xffffffffffffffff;
            }
            if ((*(char *)(puVar6 + 0x15) == '\0') && (*(int64_t *)(iVar5 + 0x20) != -1)) {
                *(undefined8 *)(iVar5 + 0x20) = 0xffffffffffffffff;
                *(undefined *)(iVar5 + 0x15) = 0xff;
            }
            iVar5 = *(int64_t *)0x180781f28;
            uVar27 = puVar6[0xd];
            if (((((uVar27 & 0xc0) != 0) && (puVar6[0x12] != 0)) &&
                (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2588) == puVar6[0x12])) &&
               (*(char *)(*(int64_t *)0x180781f28 + 0x258c) != '\0')) {
                iVar7 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
                *(undefined *)(*(int64_t *)0x180781f28 + 0x25b8) = 0;
                iVar24 = *(int64_t *)0x180781f28;
                fVar30 = *(float *)(iVar5 + 0x11c);
                fVar28 = var_118h._4_4_;
                if ((var_118h._4_4_ <= fVar30) && (fVar28 = (float)var_10ch, fVar30 <= (float)var_10ch)) {
                    fVar28 = fVar30;
                }
                fVar30 = *(float *)(iVar5 + 0x118);
                fVar34 = (float)var_118h;
                if (((float)var_118h <= fVar30) && (fVar34 = var_110h, fVar30 <= var_110h)) {
                    fVar34 = fVar30;
                }
                fVar30 = *(float *)(iVar7 + 0x168);
                fVar38 = *(float *)(iVar5 + 0x25e8);
                if ((float)var_10ch <= *(float *)(iVar5 + 0x25e8)) {
                    fVar38 = (float)var_10ch;
                }
                *(float *)(iVar5 + 0x25a4) = fVar28 - *(float *)(iVar7 + 0x16c);
                fVar28 = *(float *)(iVar5 + 0x25e4);
                if (var_110h <= *(float *)(iVar5 + 0x25e4)) {
                    fVar28 = var_110h;
                }
                *(float *)(iVar5 + 0x25a0) = fVar34 - fVar30;
                uStack_f8 = *(undefined4 *)(iVar24 + 0x1090);
                uStack_f4 = *(undefined4 *)(iVar24 + 0x1094);
                uStack_f0 = *(undefined4 *)(iVar24 + 0x1098);
                fVar30 = *(float *)(iVar5 + 0x25dc);
                if (*(float *)(iVar5 + 0x25dc) <= (float)var_118h) {
                    fVar30 = (float)var_118h;
                }
                fVar34 = *(float *)(iVar5 + 0x25e0);
                if (*(float *)(iVar5 + 0x25e0) <= var_118h._4_4_) {
                    fVar34 = var_118h._4_4_;
                }
                fStack_ec = *(float *)(iVar24 + 0x109c) * *(float *)(iVar24 + 0xd9c) * 0.3;
                var_128h._0_4_ = fVar30;
                var_128h._4_4_ = fVar34;
                var_120h = fVar28;
                var_11ch = fVar38;
                uVar15 = func_0x0001800f5fa0(&uStack_f8);
                func_0x000180126550(*(undefined8 *)(iVar7 + 800), &var_128h, &var_120h, uVar15, 0, 0);
                uStack_f8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1270);
                uStack_f4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1274);
                uStack_f0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1278);
                fStack_ec = *(float *)(*(int64_t *)0x180781f28 + 0x127c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                iVar24 = *(int64_t *)0x180781f28;
                fStackX_10 = (float)func_0x0001800f5fa0();
                if (((uint32_t)fStackX_10 & 0xff000000) != 0) {
                    iVar17 = *(int64_t *)(iVar7 + 800);
                    if ((*(uint8_t *)(iVar17 + 0x30) & 1) == 0) {
                        var_148h._0_4_ = fVar28 - 0.49;
                        var_148h._4_4_ = fVar38 - 0.49;
                        piVar21 = &var_148h;
                        piVar20 = &var_140h;
                        var_140h._0_4_ = fVar30 + 0.5;
                        var_140h._4_4_ = fVar34 + 0.5;
                    } else {
                        uStackX_18._0_4_ = fVar28 - 0.5;
                        uStackX_18._4_4_ = fVar38 - 0.5;
                        piVar21 = &uStackX_18;
                        piVar20 = (int64_t *)&fStackX_20;
                        fStackX_20 = fVar30 + 0.5;
                        fStackX_24 = fVar34 + 0.5;
                    }
                    func_0x000180125f20(iVar17, piVar20, piVar21);
                    func_0x0001801248e0(iVar17, *(undefined8 *)(iVar17 + 0x58), *(undefined4 *)(iVar17 + 0x50), 
                                        fStackX_10, 1, 0x3f800000);
                    iVar24 = *(int64_t *)0x180781f28;
                    *(undefined4 *)(iVar17 + 0x50) = 0;
                    iVar17 = var_130h;
                }
                if ((uVar27 & 0x900) == 0x800) {
                    fVar28 = (float)(*(uint32_t *)(iVar5 + 0x12f8) ^ 0x80000000);
                    fVar34 = fVar29 - fVar28;
                    fVar38 = fVar32 - fVar28;
                    fVar30 = fVar37 + fVar28;
                    fVar28 = fVar36 + fVar28;
                    if ((((*(float *)(iVar5 + 0x118) < fVar34) || (*(float *)(iVar5 + 0x11c) < fVar38)) ||
                        (fVar30 <= *(float *)(iVar5 + 0x118))) || (fVar28 <= *(float *)(iVar5 + 0x11c))) {
                        fVar33 = *(float *)(iVar24 + 0x118);
                        if ((((fVar30 < fVar33) || (fVar30 = fVar34, fVar33 < fVar34)) &&
                            ((fVar33 = fVar33 - fVar30, fVar33 != 0.0 &&
                             ((fVar30 = *(float *)(iVar7 + 0xd4), 0.0 <= fVar33 || (0.0 <= fVar30)))))) &&
                           ((fVar33 <= 0.0 || (fVar30 < *(float *)(iVar7 + 0xdc))))) {
                            fVar34 = *(float *)(iVar24 + 0x12f8);
                            fVar35 = ((float)((uint32_t)fVar33 & 0x7fffffff) - fVar34) / (fVar34 * 5.0 - fVar34);
                            if (0.0 <= fVar35) {
                                fVar31 = 1.0;
                                if (fVar35 <= 1.0) {
                                    fVar31 = fVar35;
                                }
                            } else {
                                fVar31 = 0.0;
                            }
                            if (0.0 <= fVar33) {
                                if (fVar33 <= 0.0) {
                                    fVar33 = 0.0;
                                } else {
                                    fVar33 = 1.0;
                                }
                            } else {
                                fVar33 = -1.0;
                            }
                            fVar34 = (fVar31 * 3.0 + 1.0) * fVar34 * 35.0 * fVar33 * *(float *)(iVar24 + 0x48) +
                                     *(float *)(iVar5 + 0x25a8);
                            *(float *)(iVar5 + 0x25a8) = fVar34;
                            iVar16 = (int32_t)fVar34;
                            if ((fVar34 < 0.0) && ((float)iVar16 != fVar34)) {
                                iVar16 = iVar16 + -1;
                            }
                            fVar34 = (float)iVar16;
                            if (fVar34 != 0.0) {
                                *(undefined4 *)(iVar7 + 0xec) = 0;
                                *(undefined4 *)(iVar7 + 0xf4) = 0;
                                *(float *)(iVar7 + 0xe4) = fVar34 + fVar30;
                                *(float *)(iVar5 + 0x25a8) = *(float *)(iVar5 + 0x25a8) - fVar34;
                            }
                        }
                        fVar30 = *(float *)(iVar24 + 0x11c);
                        if (((((fVar28 < fVar30) || (fVar28 = fVar38, fVar30 < fVar38)) &&
                             (fVar30 = fVar30 - fVar28, fVar30 != 0.0)) &&
                            ((fVar28 = *(float *)(iVar7 + 0xd8), 0.0 <= fVar30 || (0.0 <= fVar28)))) &&
                           ((fVar30 <= 0.0 || (fVar28 < *(float *)(iVar7 + 0xe0))))) {
                            fVar34 = *(float *)(iVar24 + 0x12f8);
                            fVar38 = ((float)((uint32_t)fVar30 & 0x7fffffff) - fVar34) / (fVar34 * 5.0 - fVar34);
                            if (0.0 <= fVar38) {
                                fVar33 = 1.0;
                                if (fVar38 <= 1.0) {
                                    fVar33 = fVar38;
                                }
                            } else {
                                fVar33 = 0.0;
                            }
                            if (0.0 <= fVar30) {
                                if (fVar30 <= 0.0) {
                                    fVar30 = 0.0;
                                } else {
                                    fVar30 = 1.0;
                                }
                            } else {
                                fVar30 = -1.0;
                            }
                            fVar30 = (fVar33 * 3.0 + 1.0) * fVar34 * 35.0 * fVar30 * *(float *)(iVar24 + 0x48) +
                                     *(float *)(iVar5 + 0x25ac);
                            *(float *)(iVar5 + 0x25ac) = fVar30;
                            iVar16 = (int32_t)fVar30;
                            if ((fVar30 < 0.0) && ((float)iVar16 != fVar30)) {
                                iVar16 = iVar16 + -1;
                            }
                            fVar30 = (float)iVar16;
                            if (fVar30 != 0.0) {
                                *(float *)(iVar7 + 0xe8) = fVar28 + fVar30;
                                *(undefined4 *)(iVar7 + 0xf0) = 0;
                                *(undefined4 *)(iVar7 + 0xf8) = 0;
                                *(float *)(iVar5 + 0x25ac) = *(float *)(iVar5 + 0x25ac) - fVar30;
                            }
                        }
                    }
                }
            }
        }
        if (*(char *)((int64_t)puVar6 + 0x51) == '\0') {
            iVar16 = puVar6[1];
            if (iVar16 < 0) {
                iVar16 = (iVar16 + 1 >> 1) + iVar16;
                iVar19 = 0;
                if (0 < iVar16) {
                    iVar19 = iVar16;
                }
                func_0x00018014fa90(puVar6, iVar19);
            }
            *puVar6 = 0;
        }
        cVar13 = func_0x0001801062b0();
        iVar5 = *(int64_t *)0x180781f28;
        if ((((cVar13 != '\0') && (fVar30 = *(float *)(iVar18 + 0x118), *(float *)(iVar17 + 0x278) <= fVar30)) &&
            (fVar28 = *(float *)(iVar18 + 0x11c), *(float *)(iVar17 + 0x27c) <= fVar28)) &&
           ((fVar30 < *(float *)(iVar17 + 0x280) && (fVar28 < *(float *)(iVar17 + 0x284))))) {
            if (((((uint32_t)puVar6[0xd] >> 0xc & 1) == 0) ||
                (((fVar29 <= fVar30 && (fVar32 <= fVar28)) && ((fVar30 < fVar37 && (fVar28 < fVar36)))))) &&
               ((*(int32_t *)(iVar18 + 0x163c) == 0 && (*(int32_t *)(iVar18 + 0x1654) == 0)))) {
                if (((puVar6[0xd] & 0xc0) != 0) &&
                   (((*(char *)(iVar18 + 0x258c) == '\0' && (*(char *)(iVar18 + 0x258d) == '\0')) &&
                    (*(int16_t *)(iVar18 + 0xb5a) == 1)))) {
                    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2588) = puVar6[0x12];
                    *(undefined2 *)(iVar5 + 0x258d) = 0x101;
                    *(undefined *)(iVar5 + 0x258f) = 1;
                    *(undefined2 *)(iVar5 + 0x2594) = *(undefined2 *)(iVar5 + 0x13c);
                    fVar32 = *(float *)(iVar5 + 0x118) - *(float *)(*(int64_t *)(iVar5 + 0x15e0) + 0x168);
                    fVar29 = *(float *)(iVar5 + 0x11c) - *(float *)(*(int64_t *)(iVar5 + 0x15e0) + 0x16c);
                    *(undefined8 *)(iVar5 + 0x25a8) = 0;
                    *(float *)(iVar5 + 0x25a0) = fVar32;
                    *(float *)(iVar5 + 0x25a4) = fVar29;
                    *(float *)(iVar5 + 0x2598) = fVar32;
                    *(float *)(iVar5 + 0x259c) = fVar29;
                    func_0x00018010e050(iVar17, 2);
                    iVar5 = *(int64_t *)0x180781f28;
                    iVar16 = puVar6[0x12];
                    *(int32_t *)(*(int64_t *)0x180781f28 + 0x163c) = iVar16;
                    *(undefined *)(iVar5 + 0x1650) = 0;
                    if ((iVar16 != 0) && (*(int32_t *)(iVar5 + 0x1640) != iVar16)) {
                        *(undefined8 *)(iVar5 + 0x1648) = 0;
                    }
                    if ((puVar6[0xd] & 0x1000) != 0) {
                        var_10ch._4_4_ = *(undefined4 *)(iVar18 + 0x118);
                        var_104h = *(undefined4 *)(iVar18 + 0x11c);
                        var_100h = var_10ch._4_4_;
                        var_fch = var_104h;
                        func_0x00018010e3f0(0, 0, puVar6[0xc], (int64_t)&var_10ch + 4);
                    }
                }
                if ((((puVar6[0xd] & 0x400) != 0) && (cVar13 = fcn.180108070(0), cVar13 != '\0')) &&
                   ((*(float *)(*(int64_t *)0x180781f28 + 0xbfc) <
                     *(float *)(*(int64_t *)0x180781f28 + 0xa4) * *(float *)(*(int64_t *)0x180781f28 + 0xa4) &&
                    (*(int32_t *)(iVar18 + 0x13c) == 0)))) {
                    func_0x000180147c50(puVar6);
                }
            }
        }
        iVar5 = *(int64_t *)0x180781f28;
        if ((puVar6[0xd] & 0x10000) != 0) {
            *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
            if (((*(int64_t *)(iVar5 + 0x21d8) == *(int64_t *)(iVar5 + 0x15e0)) && (*(char *)(iVar5 + 0x2279) != '\0'))
               && (*(int32_t *)(iVar5 + 0x21e4) == *(int32_t *)(*(int64_t *)(iVar5 + 0x15e0) + 0x1b0))) {
                *(uint32_t *)(iVar5 + 0x227c) = *(uint32_t *)(iVar5 + 0x227c) & 0xfffffff4;
                *(uint32_t *)(iVar5 + 0x227c) = *(uint32_t *)(iVar5 + 0x227c) | 4;
            }
        }
        if ((*(int64_t *)(iVar18 + 0x24d0) != 0) && (*(char *)(*(int64_t *)(iVar18 + 0x24d0) + 0x23a) != '\0')) {
            func_0x000180136780();
        }
        fVar29 = (float)puVar6[0x10];
        if ((float)puVar6[0x10] <= *(float *)(iVar17 + 0x170)) {
            fVar29 = *(float *)(iVar17 + 0x170);
        }
        fVar32 = (float)puVar6[0x11];
        if ((float)puVar6[0x11] <= *(float *)(iVar17 + 0x174)) {
            fVar32 = *(float *)(iVar17 + 0x174);
        }
        *(float *)(iVar17 + 0x170) = fVar29;
        *(float *)(iVar17 + 0x174) = fVar32;
        func_0x0001801067d0();
        puVar6[0xc] = 0;
        puVar6[0xd] = 0;
        *(int32_t *)(iVar18 + 0x25f8) = *(int32_t *)(iVar18 + 0x25f8) + -1;
        if (*(int32_t *)(iVar18 + 0x25f8) < 1) {
            iVar17 = 0;
        } else {
            iVar17 = (int64_t)(*(int32_t *)(iVar18 + 0x25f8) + -1) * 0x58 + *(int64_t *)(iVar18 + 0x2608);
        }
        *(int64_t *)(iVar18 + 0x25f0) = iVar17;
        iVar17 = var_138h;
        iVar5 = *(int64_t *)(iVar12 + 0x25f0);
    }
    if (*(char *)(iVar17 + 0x1bb) != '\0') {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644ce0);
        }
        func_0x000180147f30();
    }
    if ((int32_t)*(int16_t *)(arg1 + 4) < *(int32_t *)(iVar17 + 0x1e0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e50);
            }
            iVar7 = *(int64_t *)0x180781f28;
            iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
            *(undefined *)(iVar5 + 0x10b) = 1;
            iVar18 = *(int64_t *)(iVar7 + 0x15e0);
            fVar29 = *(float *)(iVar18 + 0x19c) - *(float *)(iVar7 + 0xe0c);
            *(float *)(iVar18 + 0x19c) = fVar29;
            *(float *)(iVar18 + 0x158) = fVar29 + *(float *)(iVar18 + 0x60) + *(float *)(iVar18 + 0x1a0);
            *(int32_t *)(iVar5 + 0x1e0) = *(int32_t *)(iVar5 + 0x1e0) + -1;
            uVar27 = 1 << ((uint8_t)*(undefined4 *)(iVar5 + 0x1e0) & 0x1f);
            if ((*(uint32_t *)(iVar5 + 0x1e4) & uVar27) != 0) {
                iVar18 = (int64_t)*(int32_t *)(iVar7 + 0x2140);
                iVar17 = *(int64_t *)(iVar7 + 0x2148);
                if ((((*(uint32_t *)(iVar17 + -0x24 + iVar18 * 0x28) & 0x20000) != 0) &&
                    (*(char *)(iVar7 + 0x21cf) != '\0')) &&
                   ((*(int32_t *)(iVar7 + 0x2288) == 0 &&
                    ((((*(int64_t *)(iVar7 + 0x21d8) == iVar5 && (*(char *)(iVar7 + 0x2279) != '\0')) &&
                      (*(int32_t *)(iVar7 + 0x22c8) == 0)) && (*(int32_t *)(iVar7 + 0x2338) == 0)))))) {
                    *(undefined *)(iVar7 + 0x2279) = 0;
                    *(undefined4 *)(iVar7 + 0x1fb8) = *(undefined4 *)(iVar17 + -0x28 + iVar18 * 0x28);
                    *(uint32_t *)(iVar7 + 0x1fbc) = *(uint32_t *)(iVar17 + -0x20 + iVar18 * 0x28) & 0xffdfffff;
                    puVar6 = (undefined4 *)(iVar17 + -0x1c + iVar18 * 0x28);
                    uVar15 = puVar6[1];
                    uVar1 = puVar6[2];
                    uVar2 = puVar6[3];
                    *(undefined4 *)(iVar7 + 0x1fd4) = *puVar6;
                    *(undefined4 *)(iVar7 + 0x1fd8) = uVar15;
                    *(undefined4 *)(iVar7 + 0x1fdc) = uVar1;
                    *(undefined4 *)(iVar7 + 0x1fe0) = uVar2;
                    func_0x00018010ea60(iVar7 + 0x22c0);
                    *(undefined4 *)
                     (*(int64_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x438) + 0x47c +
                     (int64_t)*(int32_t *)(iVar7 + 0x21e4) * 8) = 0x7f7fffff;
                    if ((*(char *)(iVar7 + 0x2279) == '\0') && (*(char *)(iVar7 + 0x223a) == '\0')) {
                        uVar14 = 0;
                    } else {
                        uVar14 = 1;
                    }
                    *(undefined *)(iVar7 + 0x2239) = uVar14;
                }
                fVar29 = *(float *)(iVar17 + -0xc + iVar18 * 0x28);
                if ((fVar29 != 3.402823e+38) && (*(float *)(iVar5 + 700) <= *(float *)(iVar5 + 0x15c))) {
                    iVar24 = *(int64_t *)(iVar7 + 0x15e0);
                    fVar32 = *(float *)(iVar17 + -0x10 + iVar18 * 0x28);
                    fVar37 = *(float *)(iVar17 + -8 + iVar18 * 0x28);
                    if (fVar32 <= *(float *)(iVar24 + 700)) {
                        fVar32 = *(float *)(iVar24 + 700);
                    }
                    if ((*(uint32_t *)(iVar17 + -0x24 + iVar18 * 0x28) & 0x80000) != 0) {
                        fVar36 = *(float *)(iVar24 + 0x15c);
                        fVar30 = fVar36;
                        if ((*(int64_t *)(iVar7 + 0x24d0) != 0) &&
                           (fVar30 = *(float *)(*(int64_t *)(iVar7 + 0x24d0) + 0x80), fVar30 <= fVar36)) {
                            fVar30 = fVar36;
                        }
                        fVar36 = (float)(int32_t)((fVar30 - *(float *)(iVar7 + 0xdf0)) -
                                                 *(float *)(iVar7 + 0x12f8) * 0.5);
                        if (*(float *)(iVar7 + 0xdf0) + *(float *)(iVar7 + 0xe68) + fVar37 < fVar36) {
                            fVar37 = fVar36;
                        }
                    }
                    if (*(float *)(iVar24 + 0x2c4) <= fVar37) {
                        fVar37 = *(float *)(iVar24 + 0x2c4);
                    }
                    if (fVar32 < fVar37) {
                        iVar4 = *(int16_t *)(iVar17 + -4 + iVar18 * 0x28);
                        if ((iVar4 != -1) &&
                           (iVar8 = *(int64_t *)(iVar7 + 0x24d0), (*(uint32_t *)(iVar8 + 4) & 0x100000) == 0)) {
                            iVar23 = *(int64_t *)(iVar8 + 0x18);
                            iVar25 = (int64_t)iVar4 * 0x74;
                            iVar26 = *(int64_t *)(iVar24 + 800);
                            puVar6 = (undefined4 *)(iVar25 + 0x24 + iVar23);
                            uVar9 = puVar6[1];
                            uVar10 = puVar6[2];
                            uVar11 = puVar6[3];
                            uVar15 = *(undefined4 *)(iVar25 + 0x24 + iVar23);
                            uVar1 = *(undefined4 *)(iVar25 + 0x28 + iVar23);
                            uVar2 = *(undefined4 *)(iVar25 + 0x2c + iVar23);
                            uVar3 = *(undefined4 *)(iVar25 + 0x30 + iVar23);
                            *(undefined4 *)(iVar24 + 0x2b8) = *puVar6;
                            *(undefined4 *)(iVar24 + 700) = uVar9;
                            *(undefined4 *)(iVar24 + 0x2c0) = uVar10;
                            *(undefined4 *)(iVar24 + 0x2c4) = uVar11;
                            *(undefined4 *)(iVar26 + 0x60) = uVar15;
                            *(undefined4 *)(iVar26 + 100) = uVar1;
                            *(undefined4 *)(iVar26 + 0x68) = uVar2;
                            *(undefined4 *)(iVar26 + 0x6c) = uVar3;
                            iVar22 = (int64_t)*(int32_t *)(*(int64_t *)(iVar24 + 800) + 0xa0);
                            iVar26 = *(int64_t *)(*(int64_t *)(iVar24 + 800) + 0xa8);
                            *(undefined4 *)(iVar26 + -0x10 + iVar22 * 0x10) = uVar15;
                            *(undefined4 *)(iVar26 + -0xc + iVar22 * 0x10) = uVar1;
                            *(undefined4 *)(iVar26 + -8 + iVar22 * 0x10) = uVar2;
                            *(undefined4 *)(iVar26 + -4 + iVar22 * 0x10) = uVar3;
                            func_0x000180127010(*(undefined8 *)(iVar8 + 0x1a0), *(undefined8 *)(iVar24 + 800), 
                                                *(undefined2 *)(iVar25 + 0x60 + iVar23));
                        }
                        uStack_f8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1230);
                        uStack_f4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1234);
                        uStack_f0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1238);
                        fStack_ec = *(float *)(*(int64_t *)0x180781f28 + 0x123c) *
                                    *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                        fStackX_10 = (float)(int32_t)fVar29;
                        fStackX_14 = fVar37;
                        uStackX_18._0_4_ = fStackX_10;
                        uStackX_18._4_4_ = fVar32;
                        uVar15 = func_0x0001800f5fa0(&uStack_f8);
                        func_0x000180126300(*(undefined8 *)(iVar24 + 800), &uStackX_18, &fStackX_10, uVar15, 
                                            *(undefined4 *)(iVar7 + 0xe64));
                        if (((*(int16_t *)(iVar17 + -4 + iVar18 * 0x28) != -1) &&
                            (iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0),
                            (*(uint32_t *)(iVar17 + 4) & 0x100000) == 0)) && (*(int32_t *)(iVar17 + 0x74) != -1)) {
                            iVar18 = *(int64_t *)(iVar17 + 0x18);
                            iVar24 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
                            iVar26 = (int64_t)*(int32_t *)(iVar17 + 0x74) * 0x74;
                            iVar8 = *(int64_t *)(iVar24 + 800);
                            puVar6 = (undefined4 *)(iVar26 + 0x24 + iVar18);
                            uVar9 = puVar6[1];
                            uVar10 = puVar6[2];
                            uVar11 = puVar6[3];
                            uVar15 = *(undefined4 *)(iVar26 + 0x24 + iVar18);
                            uVar1 = *(undefined4 *)(iVar26 + 0x28 + iVar18);
                            uVar2 = *(undefined4 *)(iVar26 + 0x2c + iVar18);
                            uVar3 = *(undefined4 *)(iVar26 + 0x30 + iVar18);
                            *(undefined4 *)(iVar24 + 0x2b8) = *puVar6;
                            *(undefined4 *)(iVar24 + 700) = uVar9;
                            *(undefined4 *)(iVar24 + 0x2c0) = uVar10;
                            *(undefined4 *)(iVar24 + 0x2c4) = uVar11;
                            *(undefined4 *)(iVar8 + 0x60) = uVar15;
                            *(undefined4 *)(iVar8 + 100) = uVar1;
                            *(undefined4 *)(iVar8 + 0x68) = uVar2;
                            *(undefined4 *)(iVar8 + 0x6c) = uVar3;
                            iVar23 = (int64_t)*(int32_t *)(*(int64_t *)(iVar24 + 800) + 0xa0);
                            iVar8 = *(int64_t *)(*(int64_t *)(iVar24 + 800) + 0xa8);
                            *(undefined4 *)(iVar8 + -0x10 + iVar23 * 0x10) = uVar15;
                            *(undefined4 *)(iVar8 + -0xc + iVar23 * 0x10) = uVar1;
                            *(undefined4 *)(iVar8 + -8 + iVar23 * 0x10) = uVar2;
                            *(undefined4 *)(iVar8 + -4 + iVar23 * 0x10) = uVar3;
                            func_0x000180127010(*(undefined8 *)(iVar17 + 0x1a0), *(undefined8 *)(iVar24 + 800), 
                                                *(undefined2 *)(iVar26 + 0x60 + iVar18));
                        }
                    }
                }
                *(int32_t *)(iVar7 + 0x2140) = *(int32_t *)(iVar7 + 0x2140) + -1;
                uVar27 = ~uVar27;
                *(uint32_t *)(iVar5 + 0x1e4) = *(uint32_t *)(iVar5 + 0x1e4) & uVar27;
                *(uint32_t *)(iVar5 + 0x1e8) = *(uint32_t *)(iVar5 + 0x1e8) & uVar27;
                iVar17 = var_138h;
            }
            iVar16 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
            if (iVar16 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
                }
            } else {
                *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar16 + -1;
            }
        } while ((int32_t)*(int16_t *)(arg1 + 4) < *(int32_t *)(iVar17 + 0x1e0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 0xe) < *(int32_t *)(iVar12 + 0x2110)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e68);
            }
            func_0x00018010c110();
        } while ((int32_t)*(int16_t *)(arg1 + 0xe) < *(int32_t *)(iVar12 + 0x2110));
    }
    if ((int32_t)*(int16_t *)(arg1 + 2) < *(int32_t *)(iVar17 + 0x148)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e80);
            }
            iVar16 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
            if (iVar16 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
                }
            } else {
                *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar16 + -1;
            }
        } while ((int32_t)*(int16_t *)(arg1 + 2) < *(int32_t *)(iVar17 + 0x148));
    }
    if (*(int16_t *)(arg1 + 0x14) < *(int16_t *)(iVar12 + 0x281c)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e90);
            }
            iVar17 = *(int64_t *)0x180781f28;
            if ((*(uint8_t *)(iVar12 + 0x1f78) & 0x40) == 0) {
                *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) = *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) + -1;
                iVar16 = *(int32_t *)(iVar17 + 0x2100);
                *(int32_t *)(iVar17 + 0x2100) = iVar16 + -1;
                *(undefined4 *)(iVar17 + 0x1f78) =
                     *(undefined4 *)(*(int64_t *)(iVar17 + 0x2108) + -8 + (int64_t)iVar16 * 4);
                *(undefined4 *)(iVar17 + 0xd9c) =
                     *(undefined4 *)((int64_t)*(int32_t *)(iVar17 + 0x15b0) * 0x78 + -8 + *(int64_t *)(iVar17 + 0x15b8))
                ;
                *(undefined *)((int64_t)*(int32_t *)(iVar12 + 0x15b0) * 0x78 + -10 + *(int64_t *)(iVar12 + 0x15b8)) = 0;
            } else {
                func_0x000180106130();
            }
        } while (*(int16_t *)(arg1 + 0x14) < *(int16_t *)(iVar12 + 0x281c));
    }
    if ((int32_t)*(int16_t *)(arg1 + 6) < *(int32_t *)(iVar12 + 0x20c0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644df0);
            }
            func_0x0001800f6770(1);
        } while ((int32_t)*(int16_t *)(arg1 + 6) < *(int32_t *)(iVar12 + 0x20c0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 0x10) < *(int32_t *)(iVar12 + 0x2100)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e08);
            }
            iVar17 = *(int64_t *)0x180781f28;
            iVar16 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100);
            if (iVar16 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644628);
                }
            } else {
                *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100) = iVar16 + -1;
                *(undefined4 *)(iVar17 + 0x1f78) =
                     *(undefined4 *)(*(int64_t *)(iVar17 + 0x2108) + -8 + (int64_t)iVar16 * 4);
            }
        } while ((int32_t)*(int16_t *)(arg1 + 0x10) < *(int32_t *)(iVar12 + 0x2100));
    }
    if ((int32_t)*(int16_t *)(arg1 + 8) < *(int32_t *)(iVar12 + 0x20d0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e20);
            }
            func_0x0001800f6a20(1);
        } while ((int32_t)*(int16_t *)(arg1 + 8) < *(int32_t *)(iVar12 + 0x20d0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 10) < *(int32_t *)(iVar12 + 0x20e0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e38);
            }
            iVar17 = *(int64_t *)0x180781f28;
            if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) < 1) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445d0);
                }
            } else {
                func_0x0001801072d0(*(undefined8 *)
                                     (*(int64_t *)(*(int64_t *)0x180781f28 + 0x20e8) + -0x10 +
                                     (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) * 0x10));
                *(int32_t *)(iVar17 + 0x20e0) = *(int32_t *)(iVar17 + 0x20e0) + -1;
            }
        } while ((int32_t)*(int16_t *)(arg1 + 10) < *(int32_t *)(iVar12 + 0x20e0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 0xc) < *(int32_t *)(iVar12 + 0x20f0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644ea8);
            }
            iVar17 = *(int64_t *)0x180781f28;
            iVar16 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x20f0);
            if (*(int16_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x2a78) + 0xc) < iVar16) {
                *(int32_t *)(*(int64_t *)0x180781f28 + 0x20f0) = iVar16 + -1;
                if (iVar16 + -1 == 0) {
                    uVar15 = 0;
                } else {
                    uVar15 = *(undefined4 *)(*(int64_t *)(iVar17 + 0x20f8) + -0x10 + (int64_t)iVar16 * 8);
                }
                *(undefined4 *)(iVar17 + 0x1f74) = uVar15;
            } else if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445a8);
            }
        } while ((int32_t)*(int16_t *)(arg1 + 0xc) < *(int32_t *)(iVar12 + 0x20f0));
    }
    return;
}

// ============================================================
// Function: FUN_18010a192
// Address: 0x18010a192
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_158h
// WARNING: Variable defined which should be unmapped: var_150h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Removing arg arg_8ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_94h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_13ch
// WARNING: [rz-ghidra] Detected overlap for variable var_144h
// WARNING: [rz-ghidra] Detected overlap for variable arg_9ch

void fcn.18010a070(int64_t arg1, int64_t arg_80h, int64_t arg_98h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int16_t iVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int64_t iVar12;
    char cVar13;
    undefined uVar14;
    undefined4 uVar15;
    int32_t iVar16;
    int64_t iVar17;
    int64_t iVar18;
    int32_t iVar19;
    int64_t *piVar20;
    int64_t *piVar21;
    int64_t iVar22;
    int64_t iVar23;
    int64_t iVar24;
    int64_t iVar25;
    int64_t iVar26;
    uint32_t uVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    float fVar31;
    float fVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    float fVar36;
    float fVar37;
    float fVar38;
    float fStackX_10;
    float fStackX_14;
    undefined8 uStackX_18;
    float fStackX_20;
    float fStackX_24;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    float var_120h;
    float var_11ch;
    int64_t var_118h;
    float var_110h;
    int64_t var_10ch;
    undefined4 var_104h;
    undefined4 var_100h;
    undefined4 var_fch;
    undefined4 uStack_f8;
    undefined4 uStack_f4;
    undefined4 uStack_f0;
    float fStack_ec;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar12 = *(int64_t *)0x180781f28;
    iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0);
    while ((iVar17 != 0 && (*(int64_t *)(iVar17 + 0x188) == *(int64_t *)(iVar12 + 0x15e0)))) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644dc0);
        }
        func_0x0001801346c0();
        iVar17 = *(int64_t *)(iVar12 + 0x24d0);
    }
    iVar17 = *(int64_t *)(iVar12 + 0x15e0);
    piVar21 = *(int64_t **)(iVar12 + 0x2538);
    var_138h = iVar17;
    while ((piVar21 != (int64_t *)0x0 && (*piVar21 == iVar17))) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644ca8);
        }
        func_0x000180148e50();
        piVar21 = *(int64_t **)(iVar12 + 0x2538);
    }
    iVar5 = *(int64_t *)(iVar12 + 0x25f0);
    while ((iVar5 != 0 && (**(int64_t **)(iVar5 + 0x28) == iVar17))) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644cc0);
        }
        iVar18 = *(int64_t *)0x180781f28;
        puVar6 = *(undefined4 **)(*(int64_t *)0x180781f28 + 0x25f0);
        iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        iVar5 = *(int64_t *)(puVar6 + 10);
        var_130h = iVar17;
        if ((puVar6[0xc] != *(int32_t *)(*(int64_t *)0x180781f28 + 0x1f74)) &&
           (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0)) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180645b48);
        }
        func_0x0001801474f0(&var_118h, puVar6, iVar17);
        fVar36 = (float)var_10ch;
        fVar37 = var_110h;
        fVar32 = var_118h._4_4_;
        fVar29 = (float)var_118h;
        if (*(char *)((int64_t)puVar6 + 0x52) != '\0') {
            if ((*(char *)((int64_t)puVar6 + 0x21) != '\0') ||
               ((*(char *)((int64_t)puVar6 + 0x55) == '\0' && (*(int64_t *)(puVar6 + 4) != -1)))) {
                *(undefined8 *)(iVar5 + 0x18) = 0xffffffffffffffff;
            }
            if ((*(char *)(puVar6 + 0x15) == '\0') && (*(int64_t *)(iVar5 + 0x20) != -1)) {
                *(undefined8 *)(iVar5 + 0x20) = 0xffffffffffffffff;
                *(undefined *)(iVar5 + 0x15) = 0xff;
            }
            iVar5 = *(int64_t *)0x180781f28;
            uVar27 = puVar6[0xd];
            if (((((uVar27 & 0xc0) != 0) && (puVar6[0x12] != 0)) &&
                (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2588) == puVar6[0x12])) &&
               (*(char *)(*(int64_t *)0x180781f28 + 0x258c) != '\0')) {
                iVar7 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
                *(undefined *)(*(int64_t *)0x180781f28 + 0x25b8) = 0;
                iVar24 = *(int64_t *)0x180781f28;
                fVar30 = *(float *)(iVar5 + 0x11c);
                fVar28 = var_118h._4_4_;
                if ((var_118h._4_4_ <= fVar30) && (fVar28 = (float)var_10ch, fVar30 <= (float)var_10ch)) {
                    fVar28 = fVar30;
                }
                fVar30 = *(float *)(iVar5 + 0x118);
                fVar34 = (float)var_118h;
                if (((float)var_118h <= fVar30) && (fVar34 = var_110h, fVar30 <= var_110h)) {
                    fVar34 = fVar30;
                }
                fVar30 = *(float *)(iVar7 + 0x168);
                fVar38 = *(float *)(iVar5 + 0x25e8);
                if ((float)var_10ch <= *(float *)(iVar5 + 0x25e8)) {
                    fVar38 = (float)var_10ch;
                }
                *(float *)(iVar5 + 0x25a4) = fVar28 - *(float *)(iVar7 + 0x16c);
                fVar28 = *(float *)(iVar5 + 0x25e4);
                if (var_110h <= *(float *)(iVar5 + 0x25e4)) {
                    fVar28 = var_110h;
                }
                *(float *)(iVar5 + 0x25a0) = fVar34 - fVar30;
                uStack_f8 = *(undefined4 *)(iVar24 + 0x1090);
                uStack_f4 = *(undefined4 *)(iVar24 + 0x1094);
                uStack_f0 = *(undefined4 *)(iVar24 + 0x1098);
                fVar30 = *(float *)(iVar5 + 0x25dc);
                if (*(float *)(iVar5 + 0x25dc) <= (float)var_118h) {
                    fVar30 = (float)var_118h;
                }
                fVar34 = *(float *)(iVar5 + 0x25e0);
                if (*(float *)(iVar5 + 0x25e0) <= var_118h._4_4_) {
                    fVar34 = var_118h._4_4_;
                }
                fStack_ec = *(float *)(iVar24 + 0x109c) * *(float *)(iVar24 + 0xd9c) * 0.3;
                var_128h._0_4_ = fVar30;
                var_128h._4_4_ = fVar34;
                var_120h = fVar28;
                var_11ch = fVar38;
                uVar15 = func_0x0001800f5fa0(&uStack_f8);
                func_0x000180126550(*(undefined8 *)(iVar7 + 800), &var_128h, &var_120h, uVar15, 0, 0);
                uStack_f8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1270);
                uStack_f4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1274);
                uStack_f0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1278);
                fStack_ec = *(float *)(*(int64_t *)0x180781f28 + 0x127c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                iVar24 = *(int64_t *)0x180781f28;
                fStackX_10 = (float)func_0x0001800f5fa0();
                if (((uint32_t)fStackX_10 & 0xff000000) != 0) {
                    iVar17 = *(int64_t *)(iVar7 + 800);
                    if ((*(uint8_t *)(iVar17 + 0x30) & 1) == 0) {
                        var_148h._0_4_ = fVar28 - 0.49;
                        var_148h._4_4_ = fVar38 - 0.49;
                        piVar21 = &var_148h;
                        piVar20 = &var_140h;
                        var_140h._0_4_ = fVar30 + 0.5;
                        var_140h._4_4_ = fVar34 + 0.5;
                    } else {
                        uStackX_18._0_4_ = fVar28 - 0.5;
                        uStackX_18._4_4_ = fVar38 - 0.5;
                        piVar21 = &uStackX_18;
                        piVar20 = (int64_t *)&fStackX_20;
                        fStackX_20 = fVar30 + 0.5;
                        fStackX_24 = fVar34 + 0.5;
                    }
                    func_0x000180125f20(iVar17, piVar20, piVar21);
                    func_0x0001801248e0(iVar17, *(undefined8 *)(iVar17 + 0x58), *(undefined4 *)(iVar17 + 0x50), 
                                        fStackX_10, 1, 0x3f800000);
                    iVar24 = *(int64_t *)0x180781f28;
                    *(undefined4 *)(iVar17 + 0x50) = 0;
                    iVar17 = var_130h;
                }
                if ((uVar27 & 0x900) == 0x800) {
                    fVar28 = (float)(*(uint32_t *)(iVar5 + 0x12f8) ^ 0x80000000);
                    fVar34 = fVar29 - fVar28;
                    fVar38 = fVar32 - fVar28;
                    fVar30 = fVar37 + fVar28;
                    fVar28 = fVar36 + fVar28;
                    if ((((*(float *)(iVar5 + 0x118) < fVar34) || (*(float *)(iVar5 + 0x11c) < fVar38)) ||
                        (fVar30 <= *(float *)(iVar5 + 0x118))) || (fVar28 <= *(float *)(iVar5 + 0x11c))) {
                        fVar33 = *(float *)(iVar24 + 0x118);
                        if ((((fVar30 < fVar33) || (fVar30 = fVar34, fVar33 < fVar34)) &&
                            ((fVar33 = fVar33 - fVar30, fVar33 != 0.0 &&
                             ((fVar30 = *(float *)(iVar7 + 0xd4), 0.0 <= fVar33 || (0.0 <= fVar30)))))) &&
                           ((fVar33 <= 0.0 || (fVar30 < *(float *)(iVar7 + 0xdc))))) {
                            fVar34 = *(float *)(iVar24 + 0x12f8);
                            fVar35 = ((float)((uint32_t)fVar33 & 0x7fffffff) - fVar34) / (fVar34 * 5.0 - fVar34);
                            if (0.0 <= fVar35) {
                                fVar31 = 1.0;
                                if (fVar35 <= 1.0) {
                                    fVar31 = fVar35;
                                }
                            } else {
                                fVar31 = 0.0;
                            }
                            if (0.0 <= fVar33) {
                                if (fVar33 <= 0.0) {
                                    fVar33 = 0.0;
                                } else {
                                    fVar33 = 1.0;
                                }
                            } else {
                                fVar33 = -1.0;
                            }
                            fVar34 = (fVar31 * 3.0 + 1.0) * fVar34 * 35.0 * fVar33 * *(float *)(iVar24 + 0x48) +
                                     *(float *)(iVar5 + 0x25a8);
                            *(float *)(iVar5 + 0x25a8) = fVar34;
                            iVar16 = (int32_t)fVar34;
                            if ((fVar34 < 0.0) && ((float)iVar16 != fVar34)) {
                                iVar16 = iVar16 + -1;
                            }
                            fVar34 = (float)iVar16;
                            if (fVar34 != 0.0) {
                                *(undefined4 *)(iVar7 + 0xec) = 0;
                                *(undefined4 *)(iVar7 + 0xf4) = 0;
                                *(float *)(iVar7 + 0xe4) = fVar34 + fVar30;
                                *(float *)(iVar5 + 0x25a8) = *(float *)(iVar5 + 0x25a8) - fVar34;
                            }
                        }
                        fVar30 = *(float *)(iVar24 + 0x11c);
                        if (((((fVar28 < fVar30) || (fVar28 = fVar38, fVar30 < fVar38)) &&
                             (fVar30 = fVar30 - fVar28, fVar30 != 0.0)) &&
                            ((fVar28 = *(float *)(iVar7 + 0xd8), 0.0 <= fVar30 || (0.0 <= fVar28)))) &&
                           ((fVar30 <= 0.0 || (fVar28 < *(float *)(iVar7 + 0xe0))))) {
                            fVar34 = *(float *)(iVar24 + 0x12f8);
                            fVar38 = ((float)((uint32_t)fVar30 & 0x7fffffff) - fVar34) / (fVar34 * 5.0 - fVar34);
                            if (0.0 <= fVar38) {
                                fVar33 = 1.0;
                                if (fVar38 <= 1.0) {
                                    fVar33 = fVar38;
                                }
                            } else {
                                fVar33 = 0.0;
                            }
                            if (0.0 <= fVar30) {
                                if (fVar30 <= 0.0) {
                                    fVar30 = 0.0;
                                } else {
                                    fVar30 = 1.0;
                                }
                            } else {
                                fVar30 = -1.0;
                            }
                            fVar30 = (fVar33 * 3.0 + 1.0) * fVar34 * 35.0 * fVar30 * *(float *)(iVar24 + 0x48) +
                                     *(float *)(iVar5 + 0x25ac);
                            *(float *)(iVar5 + 0x25ac) = fVar30;
                            iVar16 = (int32_t)fVar30;
                            if ((fVar30 < 0.0) && ((float)iVar16 != fVar30)) {
                                iVar16 = iVar16 + -1;
                            }
                            fVar30 = (float)iVar16;
                            if (fVar30 != 0.0) {
                                *(float *)(iVar7 + 0xe8) = fVar28 + fVar30;
                                *(undefined4 *)(iVar7 + 0xf0) = 0;
                                *(undefined4 *)(iVar7 + 0xf8) = 0;
                                *(float *)(iVar5 + 0x25ac) = *(float *)(iVar5 + 0x25ac) - fVar30;
                            }
                        }
                    }
                }
            }
        }
        if (*(char *)((int64_t)puVar6 + 0x51) == '\0') {
            iVar16 = puVar6[1];
            if (iVar16 < 0) {
                iVar16 = (iVar16 + 1 >> 1) + iVar16;
                iVar19 = 0;
                if (0 < iVar16) {
                    iVar19 = iVar16;
                }
                func_0x00018014fa90(puVar6, iVar19);
            }
            *puVar6 = 0;
        }
        cVar13 = func_0x0001801062b0();
        iVar5 = *(int64_t *)0x180781f28;
        if ((((cVar13 != '\0') && (fVar30 = *(float *)(iVar18 + 0x118), *(float *)(iVar17 + 0x278) <= fVar30)) &&
            (fVar28 = *(float *)(iVar18 + 0x11c), *(float *)(iVar17 + 0x27c) <= fVar28)) &&
           ((fVar30 < *(float *)(iVar17 + 0x280) && (fVar28 < *(float *)(iVar17 + 0x284))))) {
            if (((((uint32_t)puVar6[0xd] >> 0xc & 1) == 0) ||
                (((fVar29 <= fVar30 && (fVar32 <= fVar28)) && ((fVar30 < fVar37 && (fVar28 < fVar36)))))) &&
               ((*(int32_t *)(iVar18 + 0x163c) == 0 && (*(int32_t *)(iVar18 + 0x1654) == 0)))) {
                if (((puVar6[0xd] & 0xc0) != 0) &&
                   (((*(char *)(iVar18 + 0x258c) == '\0' && (*(char *)(iVar18 + 0x258d) == '\0')) &&
                    (*(int16_t *)(iVar18 + 0xb5a) == 1)))) {
                    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2588) = puVar6[0x12];
                    *(undefined2 *)(iVar5 + 0x258d) = 0x101;
                    *(undefined *)(iVar5 + 0x258f) = 1;
                    *(undefined2 *)(iVar5 + 0x2594) = *(undefined2 *)(iVar5 + 0x13c);
                    fVar32 = *(float *)(iVar5 + 0x118) - *(float *)(*(int64_t *)(iVar5 + 0x15e0) + 0x168);
                    fVar29 = *(float *)(iVar5 + 0x11c) - *(float *)(*(int64_t *)(iVar5 + 0x15e0) + 0x16c);
                    *(undefined8 *)(iVar5 + 0x25a8) = 0;
                    *(float *)(iVar5 + 0x25a0) = fVar32;
                    *(float *)(iVar5 + 0x25a4) = fVar29;
                    *(float *)(iVar5 + 0x2598) = fVar32;
                    *(float *)(iVar5 + 0x259c) = fVar29;
                    func_0x00018010e050(iVar17, 2);
                    iVar5 = *(int64_t *)0x180781f28;
                    iVar16 = puVar6[0x12];
                    *(int32_t *)(*(int64_t *)0x180781f28 + 0x163c) = iVar16;
                    *(undefined *)(iVar5 + 0x1650) = 0;
                    if ((iVar16 != 0) && (*(int32_t *)(iVar5 + 0x1640) != iVar16)) {
                        *(undefined8 *)(iVar5 + 0x1648) = 0;
                    }
                    if ((puVar6[0xd] & 0x1000) != 0) {
                        var_10ch._4_4_ = *(undefined4 *)(iVar18 + 0x118);
                        var_104h = *(undefined4 *)(iVar18 + 0x11c);
                        var_100h = var_10ch._4_4_;
                        var_fch = var_104h;
                        func_0x00018010e3f0(0, 0, puVar6[0xc], (int64_t)&var_10ch + 4);
                    }
                }
                if ((((puVar6[0xd] & 0x400) != 0) && (cVar13 = fcn.180108070(0), cVar13 != '\0')) &&
                   ((*(float *)(*(int64_t *)0x180781f28 + 0xbfc) <
                     *(float *)(*(int64_t *)0x180781f28 + 0xa4) * *(float *)(*(int64_t *)0x180781f28 + 0xa4) &&
                    (*(int32_t *)(iVar18 + 0x13c) == 0)))) {
                    func_0x000180147c50(puVar6);
                }
            }
        }
        iVar5 = *(int64_t *)0x180781f28;
        if ((puVar6[0xd] & 0x10000) != 0) {
            *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
            if (((*(int64_t *)(iVar5 + 0x21d8) == *(int64_t *)(iVar5 + 0x15e0)) && (*(char *)(iVar5 + 0x2279) != '\0'))
               && (*(int32_t *)(iVar5 + 0x21e4) == *(int32_t *)(*(int64_t *)(iVar5 + 0x15e0) + 0x1b0))) {
                *(uint32_t *)(iVar5 + 0x227c) = *(uint32_t *)(iVar5 + 0x227c) & 0xfffffff4;
                *(uint32_t *)(iVar5 + 0x227c) = *(uint32_t *)(iVar5 + 0x227c) | 4;
            }
        }
        if ((*(int64_t *)(iVar18 + 0x24d0) != 0) && (*(char *)(*(int64_t *)(iVar18 + 0x24d0) + 0x23a) != '\0')) {
            func_0x000180136780();
        }
        fVar29 = (float)puVar6[0x10];
        if ((float)puVar6[0x10] <= *(float *)(iVar17 + 0x170)) {
            fVar29 = *(float *)(iVar17 + 0x170);
        }
        fVar32 = (float)puVar6[0x11];
        if ((float)puVar6[0x11] <= *(float *)(iVar17 + 0x174)) {
            fVar32 = *(float *)(iVar17 + 0x174);
        }
        *(float *)(iVar17 + 0x170) = fVar29;
        *(float *)(iVar17 + 0x174) = fVar32;
        func_0x0001801067d0();
        puVar6[0xc] = 0;
        puVar6[0xd] = 0;
        *(int32_t *)(iVar18 + 0x25f8) = *(int32_t *)(iVar18 + 0x25f8) + -1;
        if (*(int32_t *)(iVar18 + 0x25f8) < 1) {
            iVar17 = 0;
        } else {
            iVar17 = (int64_t)(*(int32_t *)(iVar18 + 0x25f8) + -1) * 0x58 + *(int64_t *)(iVar18 + 0x2608);
        }
        *(int64_t *)(iVar18 + 0x25f0) = iVar17;
        iVar17 = var_138h;
        iVar5 = *(int64_t *)(iVar12 + 0x25f0);
    }
    if (*(char *)(iVar17 + 0x1bb) != '\0') {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644ce0);
        }
        func_0x000180147f30();
    }
    if ((int32_t)*(int16_t *)(arg1 + 4) < *(int32_t *)(iVar17 + 0x1e0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e50);
            }
            iVar7 = *(int64_t *)0x180781f28;
            iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
            *(undefined *)(iVar5 + 0x10b) = 1;
            iVar18 = *(int64_t *)(iVar7 + 0x15e0);
            fVar29 = *(float *)(iVar18 + 0x19c) - *(float *)(iVar7 + 0xe0c);
            *(float *)(iVar18 + 0x19c) = fVar29;
            *(float *)(iVar18 + 0x158) = fVar29 + *(float *)(iVar18 + 0x60) + *(float *)(iVar18 + 0x1a0);
            *(int32_t *)(iVar5 + 0x1e0) = *(int32_t *)(iVar5 + 0x1e0) + -1;
            uVar27 = 1 << ((uint8_t)*(undefined4 *)(iVar5 + 0x1e0) & 0x1f);
            if ((*(uint32_t *)(iVar5 + 0x1e4) & uVar27) != 0) {
                iVar18 = (int64_t)*(int32_t *)(iVar7 + 0x2140);
                iVar17 = *(int64_t *)(iVar7 + 0x2148);
                if ((((*(uint32_t *)(iVar17 + -0x24 + iVar18 * 0x28) & 0x20000) != 0) &&
                    (*(char *)(iVar7 + 0x21cf) != '\0')) &&
                   ((*(int32_t *)(iVar7 + 0x2288) == 0 &&
                    ((((*(int64_t *)(iVar7 + 0x21d8) == iVar5 && (*(char *)(iVar7 + 0x2279) != '\0')) &&
                      (*(int32_t *)(iVar7 + 0x22c8) == 0)) && (*(int32_t *)(iVar7 + 0x2338) == 0)))))) {
                    *(undefined *)(iVar7 + 0x2279) = 0;
                    *(undefined4 *)(iVar7 + 0x1fb8) = *(undefined4 *)(iVar17 + -0x28 + iVar18 * 0x28);
                    *(uint32_t *)(iVar7 + 0x1fbc) = *(uint32_t *)(iVar17 + -0x20 + iVar18 * 0x28) & 0xffdfffff;
                    puVar6 = (undefined4 *)(iVar17 + -0x1c + iVar18 * 0x28);
                    uVar15 = puVar6[1];
                    uVar1 = puVar6[2];
                    uVar2 = puVar6[3];
                    *(undefined4 *)(iVar7 + 0x1fd4) = *puVar6;
                    *(undefined4 *)(iVar7 + 0x1fd8) = uVar15;
                    *(undefined4 *)(iVar7 + 0x1fdc) = uVar1;
                    *(undefined4 *)(iVar7 + 0x1fe0) = uVar2;
                    func_0x00018010ea60(iVar7 + 0x22c0);
                    *(undefined4 *)
                     (*(int64_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x438) + 0x47c +
                     (int64_t)*(int32_t *)(iVar7 + 0x21e4) * 8) = 0x7f7fffff;
                    if ((*(char *)(iVar7 + 0x2279) == '\0') && (*(char *)(iVar7 + 0x223a) == '\0')) {
                        uVar14 = 0;
                    } else {
                        uVar14 = 1;
                    }
                    *(undefined *)(iVar7 + 0x2239) = uVar14;
                }
                fVar29 = *(float *)(iVar17 + -0xc + iVar18 * 0x28);
                if ((fVar29 != 3.402823e+38) && (*(float *)(iVar5 + 700) <= *(float *)(iVar5 + 0x15c))) {
                    iVar24 = *(int64_t *)(iVar7 + 0x15e0);
                    fVar32 = *(float *)(iVar17 + -0x10 + iVar18 * 0x28);
                    fVar37 = *(float *)(iVar17 + -8 + iVar18 * 0x28);
                    if (fVar32 <= *(float *)(iVar24 + 700)) {
                        fVar32 = *(float *)(iVar24 + 700);
                    }
                    if ((*(uint32_t *)(iVar17 + -0x24 + iVar18 * 0x28) & 0x80000) != 0) {
                        fVar36 = *(float *)(iVar24 + 0x15c);
                        fVar30 = fVar36;
                        if ((*(int64_t *)(iVar7 + 0x24d0) != 0) &&
                           (fVar30 = *(float *)(*(int64_t *)(iVar7 + 0x24d0) + 0x80), fVar30 <= fVar36)) {
                            fVar30 = fVar36;
                        }
                        fVar36 = (float)(int32_t)((fVar30 - *(float *)(iVar7 + 0xdf0)) -
                                                 *(float *)(iVar7 + 0x12f8) * 0.5);
                        if (*(float *)(iVar7 + 0xdf0) + *(float *)(iVar7 + 0xe68) + fVar37 < fVar36) {
                            fVar37 = fVar36;
                        }
                    }
                    if (*(float *)(iVar24 + 0x2c4) <= fVar37) {
                        fVar37 = *(float *)(iVar24 + 0x2c4);
                    }
                    if (fVar32 < fVar37) {
                        iVar4 = *(int16_t *)(iVar17 + -4 + iVar18 * 0x28);
                        if ((iVar4 != -1) &&
                           (iVar8 = *(int64_t *)(iVar7 + 0x24d0), (*(uint32_t *)(iVar8 + 4) & 0x100000) == 0)) {
                            iVar23 = *(int64_t *)(iVar8 + 0x18);
                            iVar25 = (int64_t)iVar4 * 0x74;
                            iVar26 = *(int64_t *)(iVar24 + 800);
                            puVar6 = (undefined4 *)(iVar25 + 0x24 + iVar23);
                            uVar9 = puVar6[1];
                            uVar10 = puVar6[2];
                            uVar11 = puVar6[3];
                            uVar15 = *(undefined4 *)(iVar25 + 0x24 + iVar23);
                            uVar1 = *(undefined4 *)(iVar25 + 0x28 + iVar23);
                            uVar2 = *(undefined4 *)(iVar25 + 0x2c + iVar23);
                            uVar3 = *(undefined4 *)(iVar25 + 0x30 + iVar23);
                            *(undefined4 *)(iVar24 + 0x2b8) = *puVar6;
                            *(undefined4 *)(iVar24 + 700) = uVar9;
                            *(undefined4 *)(iVar24 + 0x2c0) = uVar10;
                            *(undefined4 *)(iVar24 + 0x2c4) = uVar11;
                            *(undefined4 *)(iVar26 + 0x60) = uVar15;
                            *(undefined4 *)(iVar26 + 100) = uVar1;
                            *(undefined4 *)(iVar26 + 0x68) = uVar2;
                            *(undefined4 *)(iVar26 + 0x6c) = uVar3;
                            iVar22 = (int64_t)*(int32_t *)(*(int64_t *)(iVar24 + 800) + 0xa0);
                            iVar26 = *(int64_t *)(*(int64_t *)(iVar24 + 800) + 0xa8);
                            *(undefined4 *)(iVar26 + -0x10 + iVar22 * 0x10) = uVar15;
                            *(undefined4 *)(iVar26 + -0xc + iVar22 * 0x10) = uVar1;
                            *(undefined4 *)(iVar26 + -8 + iVar22 * 0x10) = uVar2;
                            *(undefined4 *)(iVar26 + -4 + iVar22 * 0x10) = uVar3;
                            func_0x000180127010(*(undefined8 *)(iVar8 + 0x1a0), *(undefined8 *)(iVar24 + 800), 
                                                *(undefined2 *)(iVar25 + 0x60 + iVar23));
                        }
                        uStack_f8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1230);
                        uStack_f4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1234);
                        uStack_f0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1238);
                        fStack_ec = *(float *)(*(int64_t *)0x180781f28 + 0x123c) *
                                    *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                        fStackX_10 = (float)(int32_t)fVar29;
                        fStackX_14 = fVar37;
                        uStackX_18._0_4_ = fStackX_10;
                        uStackX_18._4_4_ = fVar32;
                        uVar15 = func_0x0001800f5fa0(&uStack_f8);
                        func_0x000180126300(*(undefined8 *)(iVar24 + 800), &uStackX_18, &fStackX_10, uVar15, 
                                            *(undefined4 *)(iVar7 + 0xe64));
                        if (((*(int16_t *)(iVar17 + -4 + iVar18 * 0x28) != -1) &&
                            (iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0),
                            (*(uint32_t *)(iVar17 + 4) & 0x100000) == 0)) && (*(int32_t *)(iVar17 + 0x74) != -1)) {
                            iVar18 = *(int64_t *)(iVar17 + 0x18);
                            iVar24 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
                            iVar26 = (int64_t)*(int32_t *)(iVar17 + 0x74) * 0x74;
                            iVar8 = *(int64_t *)(iVar24 + 800);
                            puVar6 = (undefined4 *)(iVar26 + 0x24 + iVar18);
                            uVar9 = puVar6[1];
                            uVar10 = puVar6[2];
                            uVar11 = puVar6[3];
                            uVar15 = *(undefined4 *)(iVar26 + 0x24 + iVar18);
                            uVar1 = *(undefined4 *)(iVar26 + 0x28 + iVar18);
                            uVar2 = *(undefined4 *)(iVar26 + 0x2c + iVar18);
                            uVar3 = *(undefined4 *)(iVar26 + 0x30 + iVar18);
                            *(undefined4 *)(iVar24 + 0x2b8) = *puVar6;
                            *(undefined4 *)(iVar24 + 700) = uVar9;
                            *(undefined4 *)(iVar24 + 0x2c0) = uVar10;
                            *(undefined4 *)(iVar24 + 0x2c4) = uVar11;
                            *(undefined4 *)(iVar8 + 0x60) = uVar15;
                            *(undefined4 *)(iVar8 + 100) = uVar1;
                            *(undefined4 *)(iVar8 + 0x68) = uVar2;
                            *(undefined4 *)(iVar8 + 0x6c) = uVar3;
                            iVar23 = (int64_t)*(int32_t *)(*(int64_t *)(iVar24 + 800) + 0xa0);
                            iVar8 = *(int64_t *)(*(int64_t *)(iVar24 + 800) + 0xa8);
                            *(undefined4 *)(iVar8 + -0x10 + iVar23 * 0x10) = uVar15;
                            *(undefined4 *)(iVar8 + -0xc + iVar23 * 0x10) = uVar1;
                            *(undefined4 *)(iVar8 + -8 + iVar23 * 0x10) = uVar2;
                            *(undefined4 *)(iVar8 + -4 + iVar23 * 0x10) = uVar3;
                            func_0x000180127010(*(undefined8 *)(iVar17 + 0x1a0), *(undefined8 *)(iVar24 + 800), 
                                                *(undefined2 *)(iVar26 + 0x60 + iVar18));
                        }
                    }
                }
                *(int32_t *)(iVar7 + 0x2140) = *(int32_t *)(iVar7 + 0x2140) + -1;
                uVar27 = ~uVar27;
                *(uint32_t *)(iVar5 + 0x1e4) = *(uint32_t *)(iVar5 + 0x1e4) & uVar27;
                *(uint32_t *)(iVar5 + 0x1e8) = *(uint32_t *)(iVar5 + 0x1e8) & uVar27;
                iVar17 = var_138h;
            }
            iVar16 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
            if (iVar16 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
                }
            } else {
                *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar16 + -1;
            }
        } while ((int32_t)*(int16_t *)(arg1 + 4) < *(int32_t *)(iVar17 + 0x1e0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 0xe) < *(int32_t *)(iVar12 + 0x2110)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e68);
            }
            func_0x00018010c110();
        } while ((int32_t)*(int16_t *)(arg1 + 0xe) < *(int32_t *)(iVar12 + 0x2110));
    }
    if ((int32_t)*(int16_t *)(arg1 + 2) < *(int32_t *)(iVar17 + 0x148)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e80);
            }
            iVar16 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
            if (iVar16 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
                }
            } else {
                *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar16 + -1;
            }
        } while ((int32_t)*(int16_t *)(arg1 + 2) < *(int32_t *)(iVar17 + 0x148));
    }
    if (*(int16_t *)(arg1 + 0x14) < *(int16_t *)(iVar12 + 0x281c)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e90);
            }
            iVar17 = *(int64_t *)0x180781f28;
            if ((*(uint8_t *)(iVar12 + 0x1f78) & 0x40) == 0) {
                *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) = *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) + -1;
                iVar16 = *(int32_t *)(iVar17 + 0x2100);
                *(int32_t *)(iVar17 + 0x2100) = iVar16 + -1;
                *(undefined4 *)(iVar17 + 0x1f78) =
                     *(undefined4 *)(*(int64_t *)(iVar17 + 0x2108) + -8 + (int64_t)iVar16 * 4);
                *(undefined4 *)(iVar17 + 0xd9c) =
                     *(undefined4 *)((int64_t)*(int32_t *)(iVar17 + 0x15b0) * 0x78 + -8 + *(int64_t *)(iVar17 + 0x15b8))
                ;
                *(undefined *)((int64_t)*(int32_t *)(iVar12 + 0x15b0) * 0x78 + -10 + *(int64_t *)(iVar12 + 0x15b8)) = 0;
            } else {
                func_0x000180106130();
            }
        } while (*(int16_t *)(arg1 + 0x14) < *(int16_t *)(iVar12 + 0x281c));
    }
    if ((int32_t)*(int16_t *)(arg1 + 6) < *(int32_t *)(iVar12 + 0x20c0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644df0);
            }
            func_0x0001800f6770(1);
        } while ((int32_t)*(int16_t *)(arg1 + 6) < *(int32_t *)(iVar12 + 0x20c0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 0x10) < *(int32_t *)(iVar12 + 0x2100)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e08);
            }
            iVar17 = *(int64_t *)0x180781f28;
            iVar16 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100);
            if (iVar16 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644628);
                }
            } else {
                *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100) = iVar16 + -1;
                *(undefined4 *)(iVar17 + 0x1f78) =
                     *(undefined4 *)(*(int64_t *)(iVar17 + 0x2108) + -8 + (int64_t)iVar16 * 4);
            }
        } while ((int32_t)*(int16_t *)(arg1 + 0x10) < *(int32_t *)(iVar12 + 0x2100));
    }
    if ((int32_t)*(int16_t *)(arg1 + 8) < *(int32_t *)(iVar12 + 0x20d0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e20);
            }
            func_0x0001800f6a20(1);
        } while ((int32_t)*(int16_t *)(arg1 + 8) < *(int32_t *)(iVar12 + 0x20d0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 10) < *(int32_t *)(iVar12 + 0x20e0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e38);
            }
            iVar17 = *(int64_t *)0x180781f28;
            if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) < 1) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445d0);
                }
            } else {
                func_0x0001801072d0(*(undefined8 *)
                                     (*(int64_t *)(*(int64_t *)0x180781f28 + 0x20e8) + -0x10 +
                                     (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) * 0x10));
                *(int32_t *)(iVar17 + 0x20e0) = *(int32_t *)(iVar17 + 0x20e0) + -1;
            }
        } while ((int32_t)*(int16_t *)(arg1 + 10) < *(int32_t *)(iVar12 + 0x20e0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 0xc) < *(int32_t *)(iVar12 + 0x20f0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644ea8);
            }
            iVar17 = *(int64_t *)0x180781f28;
            iVar16 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x20f0);
            if (*(int16_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x2a78) + 0xc) < iVar16) {
                *(int32_t *)(*(int64_t *)0x180781f28 + 0x20f0) = iVar16 + -1;
                if (iVar16 + -1 == 0) {
                    uVar15 = 0;
                } else {
                    uVar15 = *(undefined4 *)(*(int64_t *)(iVar17 + 0x20f8) + -0x10 + (int64_t)iVar16 * 8);
                }
                *(undefined4 *)(iVar17 + 0x1f74) = uVar15;
            } else if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445a8);
            }
        } while ((int32_t)*(int16_t *)(arg1 + 0xc) < *(int32_t *)(iVar12 + 0x20f0));
    }
    return;
}

// ============================================================
// Function: FUN_18010a1a4
// Address: 0x18010a1a4
// Size: 2552 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_158h
// WARNING: Variable defined which should be unmapped: var_150h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Removing arg arg_8ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_94h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_13ch
// WARNING: [rz-ghidra] Detected overlap for variable var_144h
// WARNING: [rz-ghidra] Detected overlap for variable arg_9ch

void fcn.18010a070(int64_t arg1, int64_t arg_80h, int64_t arg_98h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int16_t iVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int64_t iVar12;
    char cVar13;
    undefined uVar14;
    undefined4 uVar15;
    int32_t iVar16;
    int64_t iVar17;
    int64_t iVar18;
    int32_t iVar19;
    int64_t *piVar20;
    int64_t *piVar21;
    int64_t iVar22;
    int64_t iVar23;
    int64_t iVar24;
    int64_t iVar25;
    int64_t iVar26;
    uint32_t uVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    float fVar31;
    float fVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    float fVar36;
    float fVar37;
    float fVar38;
    float fStackX_10;
    float fStackX_14;
    undefined8 uStackX_18;
    float fStackX_20;
    float fStackX_24;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    float var_120h;
    float var_11ch;
    int64_t var_118h;
    float var_110h;
    int64_t var_10ch;
    undefined4 var_104h;
    undefined4 var_100h;
    undefined4 var_fch;
    undefined4 uStack_f8;
    undefined4 uStack_f4;
    undefined4 uStack_f0;
    float fStack_ec;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar12 = *(int64_t *)0x180781f28;
    iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0);
    while ((iVar17 != 0 && (*(int64_t *)(iVar17 + 0x188) == *(int64_t *)(iVar12 + 0x15e0)))) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644dc0);
        }
        func_0x0001801346c0();
        iVar17 = *(int64_t *)(iVar12 + 0x24d0);
    }
    iVar17 = *(int64_t *)(iVar12 + 0x15e0);
    piVar21 = *(int64_t **)(iVar12 + 0x2538);
    var_138h = iVar17;
    while ((piVar21 != (int64_t *)0x0 && (*piVar21 == iVar17))) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644ca8);
        }
        func_0x000180148e50();
        piVar21 = *(int64_t **)(iVar12 + 0x2538);
    }
    iVar5 = *(int64_t *)(iVar12 + 0x25f0);
    while ((iVar5 != 0 && (**(int64_t **)(iVar5 + 0x28) == iVar17))) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644cc0);
        }
        iVar18 = *(int64_t *)0x180781f28;
        puVar6 = *(undefined4 **)(*(int64_t *)0x180781f28 + 0x25f0);
        iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        iVar5 = *(int64_t *)(puVar6 + 10);
        var_130h = iVar17;
        if ((puVar6[0xc] != *(int32_t *)(*(int64_t *)0x180781f28 + 0x1f74)) &&
           (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0)) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180645b48);
        }
        func_0x0001801474f0(&var_118h, puVar6, iVar17);
        fVar36 = (float)var_10ch;
        fVar37 = var_110h;
        fVar32 = var_118h._4_4_;
        fVar29 = (float)var_118h;
        if (*(char *)((int64_t)puVar6 + 0x52) != '\0') {
            if ((*(char *)((int64_t)puVar6 + 0x21) != '\0') ||
               ((*(char *)((int64_t)puVar6 + 0x55) == '\0' && (*(int64_t *)(puVar6 + 4) != -1)))) {
                *(undefined8 *)(iVar5 + 0x18) = 0xffffffffffffffff;
            }
            if ((*(char *)(puVar6 + 0x15) == '\0') && (*(int64_t *)(iVar5 + 0x20) != -1)) {
                *(undefined8 *)(iVar5 + 0x20) = 0xffffffffffffffff;
                *(undefined *)(iVar5 + 0x15) = 0xff;
            }
            iVar5 = *(int64_t *)0x180781f28;
            uVar27 = puVar6[0xd];
            if (((((uVar27 & 0xc0) != 0) && (puVar6[0x12] != 0)) &&
                (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2588) == puVar6[0x12])) &&
               (*(char *)(*(int64_t *)0x180781f28 + 0x258c) != '\0')) {
                iVar7 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
                *(undefined *)(*(int64_t *)0x180781f28 + 0x25b8) = 0;
                iVar24 = *(int64_t *)0x180781f28;
                fVar30 = *(float *)(iVar5 + 0x11c);
                fVar28 = var_118h._4_4_;
                if ((var_118h._4_4_ <= fVar30) && (fVar28 = (float)var_10ch, fVar30 <= (float)var_10ch)) {
                    fVar28 = fVar30;
                }
                fVar30 = *(float *)(iVar5 + 0x118);
                fVar34 = (float)var_118h;
                if (((float)var_118h <= fVar30) && (fVar34 = var_110h, fVar30 <= var_110h)) {
                    fVar34 = fVar30;
                }
                fVar30 = *(float *)(iVar7 + 0x168);
                fVar38 = *(float *)(iVar5 + 0x25e8);
                if ((float)var_10ch <= *(float *)(iVar5 + 0x25e8)) {
                    fVar38 = (float)var_10ch;
                }
                *(float *)(iVar5 + 0x25a4) = fVar28 - *(float *)(iVar7 + 0x16c);
                fVar28 = *(float *)(iVar5 + 0x25e4);
                if (var_110h <= *(float *)(iVar5 + 0x25e4)) {
                    fVar28 = var_110h;
                }
                *(float *)(iVar5 + 0x25a0) = fVar34 - fVar30;
                uStack_f8 = *(undefined4 *)(iVar24 + 0x1090);
                uStack_f4 = *(undefined4 *)(iVar24 + 0x1094);
                uStack_f0 = *(undefined4 *)(iVar24 + 0x1098);
                fVar30 = *(float *)(iVar5 + 0x25dc);
                if (*(float *)(iVar5 + 0x25dc) <= (float)var_118h) {
                    fVar30 = (float)var_118h;
                }
                fVar34 = *(float *)(iVar5 + 0x25e0);
                if (*(float *)(iVar5 + 0x25e0) <= var_118h._4_4_) {
                    fVar34 = var_118h._4_4_;
                }
                fStack_ec = *(float *)(iVar24 + 0x109c) * *(float *)(iVar24 + 0xd9c) * 0.3;
                var_128h._0_4_ = fVar30;
                var_128h._4_4_ = fVar34;
                var_120h = fVar28;
                var_11ch = fVar38;
                uVar15 = func_0x0001800f5fa0(&uStack_f8);
                func_0x000180126550(*(undefined8 *)(iVar7 + 800), &var_128h, &var_120h, uVar15, 0, 0);
                uStack_f8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1270);
                uStack_f4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1274);
                uStack_f0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1278);
                fStack_ec = *(float *)(*(int64_t *)0x180781f28 + 0x127c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                iVar24 = *(int64_t *)0x180781f28;
                fStackX_10 = (float)func_0x0001800f5fa0();
                if (((uint32_t)fStackX_10 & 0xff000000) != 0) {
                    iVar17 = *(int64_t *)(iVar7 + 800);
                    if ((*(uint8_t *)(iVar17 + 0x30) & 1) == 0) {
                        var_148h._0_4_ = fVar28 - 0.49;
                        var_148h._4_4_ = fVar38 - 0.49;
                        piVar21 = &var_148h;
                        piVar20 = &var_140h;
                        var_140h._0_4_ = fVar30 + 0.5;
                        var_140h._4_4_ = fVar34 + 0.5;
                    } else {
                        uStackX_18._0_4_ = fVar28 - 0.5;
                        uStackX_18._4_4_ = fVar38 - 0.5;
                        piVar21 = &uStackX_18;
                        piVar20 = (int64_t *)&fStackX_20;
                        fStackX_20 = fVar30 + 0.5;
                        fStackX_24 = fVar34 + 0.5;
                    }
                    func_0x000180125f20(iVar17, piVar20, piVar21);
                    func_0x0001801248e0(iVar17, *(undefined8 *)(iVar17 + 0x58), *(undefined4 *)(iVar17 + 0x50), 
                                        fStackX_10, 1, 0x3f800000);
                    iVar24 = *(int64_t *)0x180781f28;
                    *(undefined4 *)(iVar17 + 0x50) = 0;
                    iVar17 = var_130h;
                }
                if ((uVar27 & 0x900) == 0x800) {
                    fVar28 = (float)(*(uint32_t *)(iVar5 + 0x12f8) ^ 0x80000000);
                    fVar34 = fVar29 - fVar28;
                    fVar38 = fVar32 - fVar28;
                    fVar30 = fVar37 + fVar28;
                    fVar28 = fVar36 + fVar28;
                    if ((((*(float *)(iVar5 + 0x118) < fVar34) || (*(float *)(iVar5 + 0x11c) < fVar38)) ||
                        (fVar30 <= *(float *)(iVar5 + 0x118))) || (fVar28 <= *(float *)(iVar5 + 0x11c))) {
                        fVar33 = *(float *)(iVar24 + 0x118);
                        if ((((fVar30 < fVar33) || (fVar30 = fVar34, fVar33 < fVar34)) &&
                            ((fVar33 = fVar33 - fVar30, fVar33 != 0.0 &&
                             ((fVar30 = *(float *)(iVar7 + 0xd4), 0.0 <= fVar33 || (0.0 <= fVar30)))))) &&
                           ((fVar33 <= 0.0 || (fVar30 < *(float *)(iVar7 + 0xdc))))) {
                            fVar34 = *(float *)(iVar24 + 0x12f8);
                            fVar35 = ((float)((uint32_t)fVar33 & 0x7fffffff) - fVar34) / (fVar34 * 5.0 - fVar34);
                            if (0.0 <= fVar35) {
                                fVar31 = 1.0;
                                if (fVar35 <= 1.0) {
                                    fVar31 = fVar35;
                                }
                            } else {
                                fVar31 = 0.0;
                            }
                            if (0.0 <= fVar33) {
                                if (fVar33 <= 0.0) {
                                    fVar33 = 0.0;
                                } else {
                                    fVar33 = 1.0;
                                }
                            } else {
                                fVar33 = -1.0;
                            }
                            fVar34 = (fVar31 * 3.0 + 1.0) * fVar34 * 35.0 * fVar33 * *(float *)(iVar24 + 0x48) +
                                     *(float *)(iVar5 + 0x25a8);
                            *(float *)(iVar5 + 0x25a8) = fVar34;
                            iVar16 = (int32_t)fVar34;
                            if ((fVar34 < 0.0) && ((float)iVar16 != fVar34)) {
                                iVar16 = iVar16 + -1;
                            }
                            fVar34 = (float)iVar16;
                            if (fVar34 != 0.0) {
                                *(undefined4 *)(iVar7 + 0xec) = 0;
                                *(undefined4 *)(iVar7 + 0xf4) = 0;
                                *(float *)(iVar7 + 0xe4) = fVar34 + fVar30;
                                *(float *)(iVar5 + 0x25a8) = *(float *)(iVar5 + 0x25a8) - fVar34;
                            }
                        }
                        fVar30 = *(float *)(iVar24 + 0x11c);
                        if (((((fVar28 < fVar30) || (fVar28 = fVar38, fVar30 < fVar38)) &&
                             (fVar30 = fVar30 - fVar28, fVar30 != 0.0)) &&
                            ((fVar28 = *(float *)(iVar7 + 0xd8), 0.0 <= fVar30 || (0.0 <= fVar28)))) &&
                           ((fVar30 <= 0.0 || (fVar28 < *(float *)(iVar7 + 0xe0))))) {
                            fVar34 = *(float *)(iVar24 + 0x12f8);
                            fVar38 = ((float)((uint32_t)fVar30 & 0x7fffffff) - fVar34) / (fVar34 * 5.0 - fVar34);
                            if (0.0 <= fVar38) {
                                fVar33 = 1.0;
                                if (fVar38 <= 1.0) {
                                    fVar33 = fVar38;
                                }
                            } else {
                                fVar33 = 0.0;
                            }
                            if (0.0 <= fVar30) {
                                if (fVar30 <= 0.0) {
                                    fVar30 = 0.0;
                                } else {
                                    fVar30 = 1.0;
                                }
                            } else {
                                fVar30 = -1.0;
                            }
                            fVar30 = (fVar33 * 3.0 + 1.0) * fVar34 * 35.0 * fVar30 * *(float *)(iVar24 + 0x48) +
                                     *(float *)(iVar5 + 0x25ac);
                            *(float *)(iVar5 + 0x25ac) = fVar30;
                            iVar16 = (int32_t)fVar30;
                            if ((fVar30 < 0.0) && ((float)iVar16 != fVar30)) {
                                iVar16 = iVar16 + -1;
                            }
                            fVar30 = (float)iVar16;
                            if (fVar30 != 0.0) {
                                *(float *)(iVar7 + 0xe8) = fVar28 + fVar30;
                                *(undefined4 *)(iVar7 + 0xf0) = 0;
                                *(undefined4 *)(iVar7 + 0xf8) = 0;
                                *(float *)(iVar5 + 0x25ac) = *(float *)(iVar5 + 0x25ac) - fVar30;
                            }
                        }
                    }
                }
            }
        }
        if (*(char *)((int64_t)puVar6 + 0x51) == '\0') {
            iVar16 = puVar6[1];
            if (iVar16 < 0) {
                iVar16 = (iVar16 + 1 >> 1) + iVar16;
                iVar19 = 0;
                if (0 < iVar16) {
                    iVar19 = iVar16;
                }
                func_0x00018014fa90(puVar6, iVar19);
            }
            *puVar6 = 0;
        }
        cVar13 = func_0x0001801062b0();
        iVar5 = *(int64_t *)0x180781f28;
        if ((((cVar13 != '\0') && (fVar30 = *(float *)(iVar18 + 0x118), *(float *)(iVar17 + 0x278) <= fVar30)) &&
            (fVar28 = *(float *)(iVar18 + 0x11c), *(float *)(iVar17 + 0x27c) <= fVar28)) &&
           ((fVar30 < *(float *)(iVar17 + 0x280) && (fVar28 < *(float *)(iVar17 + 0x284))))) {
            if (((((uint32_t)puVar6[0xd] >> 0xc & 1) == 0) ||
                (((fVar29 <= fVar30 && (fVar32 <= fVar28)) && ((fVar30 < fVar37 && (fVar28 < fVar36)))))) &&
               ((*(int32_t *)(iVar18 + 0x163c) == 0 && (*(int32_t *)(iVar18 + 0x1654) == 0)))) {
                if (((puVar6[0xd] & 0xc0) != 0) &&
                   (((*(char *)(iVar18 + 0x258c) == '\0' && (*(char *)(iVar18 + 0x258d) == '\0')) &&
                    (*(int16_t *)(iVar18 + 0xb5a) == 1)))) {
                    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2588) = puVar6[0x12];
                    *(undefined2 *)(iVar5 + 0x258d) = 0x101;
                    *(undefined *)(iVar5 + 0x258f) = 1;
                    *(undefined2 *)(iVar5 + 0x2594) = *(undefined2 *)(iVar5 + 0x13c);
                    fVar32 = *(float *)(iVar5 + 0x118) - *(float *)(*(int64_t *)(iVar5 + 0x15e0) + 0x168);
                    fVar29 = *(float *)(iVar5 + 0x11c) - *(float *)(*(int64_t *)(iVar5 + 0x15e0) + 0x16c);
                    *(undefined8 *)(iVar5 + 0x25a8) = 0;
                    *(float *)(iVar5 + 0x25a0) = fVar32;
                    *(float *)(iVar5 + 0x25a4) = fVar29;
                    *(float *)(iVar5 + 0x2598) = fVar32;
                    *(float *)(iVar5 + 0x259c) = fVar29;
                    func_0x00018010e050(iVar17, 2);
                    iVar5 = *(int64_t *)0x180781f28;
                    iVar16 = puVar6[0x12];
                    *(int32_t *)(*(int64_t *)0x180781f28 + 0x163c) = iVar16;
                    *(undefined *)(iVar5 + 0x1650) = 0;
                    if ((iVar16 != 0) && (*(int32_t *)(iVar5 + 0x1640) != iVar16)) {
                        *(undefined8 *)(iVar5 + 0x1648) = 0;
                    }
                    if ((puVar6[0xd] & 0x1000) != 0) {
                        var_10ch._4_4_ = *(undefined4 *)(iVar18 + 0x118);
                        var_104h = *(undefined4 *)(iVar18 + 0x11c);
                        var_100h = var_10ch._4_4_;
                        var_fch = var_104h;
                        func_0x00018010e3f0(0, 0, puVar6[0xc], (int64_t)&var_10ch + 4);
                    }
                }
                if ((((puVar6[0xd] & 0x400) != 0) && (cVar13 = fcn.180108070(0), cVar13 != '\0')) &&
                   ((*(float *)(*(int64_t *)0x180781f28 + 0xbfc) <
                     *(float *)(*(int64_t *)0x180781f28 + 0xa4) * *(float *)(*(int64_t *)0x180781f28 + 0xa4) &&
                    (*(int32_t *)(iVar18 + 0x13c) == 0)))) {
                    func_0x000180147c50(puVar6);
                }
            }
        }
        iVar5 = *(int64_t *)0x180781f28;
        if ((puVar6[0xd] & 0x10000) != 0) {
            *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
            if (((*(int64_t *)(iVar5 + 0x21d8) == *(int64_t *)(iVar5 + 0x15e0)) && (*(char *)(iVar5 + 0x2279) != '\0'))
               && (*(int32_t *)(iVar5 + 0x21e4) == *(int32_t *)(*(int64_t *)(iVar5 + 0x15e0) + 0x1b0))) {
                *(uint32_t *)(iVar5 + 0x227c) = *(uint32_t *)(iVar5 + 0x227c) & 0xfffffff4;
                *(uint32_t *)(iVar5 + 0x227c) = *(uint32_t *)(iVar5 + 0x227c) | 4;
            }
        }
        if ((*(int64_t *)(iVar18 + 0x24d0) != 0) && (*(char *)(*(int64_t *)(iVar18 + 0x24d0) + 0x23a) != '\0')) {
            func_0x000180136780();
        }
        fVar29 = (float)puVar6[0x10];
        if ((float)puVar6[0x10] <= *(float *)(iVar17 + 0x170)) {
            fVar29 = *(float *)(iVar17 + 0x170);
        }
        fVar32 = (float)puVar6[0x11];
        if ((float)puVar6[0x11] <= *(float *)(iVar17 + 0x174)) {
            fVar32 = *(float *)(iVar17 + 0x174);
        }
        *(float *)(iVar17 + 0x170) = fVar29;
        *(float *)(iVar17 + 0x174) = fVar32;
        func_0x0001801067d0();
        puVar6[0xc] = 0;
        puVar6[0xd] = 0;
        *(int32_t *)(iVar18 + 0x25f8) = *(int32_t *)(iVar18 + 0x25f8) + -1;
        if (*(int32_t *)(iVar18 + 0x25f8) < 1) {
            iVar17 = 0;
        } else {
            iVar17 = (int64_t)(*(int32_t *)(iVar18 + 0x25f8) + -1) * 0x58 + *(int64_t *)(iVar18 + 0x2608);
        }
        *(int64_t *)(iVar18 + 0x25f0) = iVar17;
        iVar17 = var_138h;
        iVar5 = *(int64_t *)(iVar12 + 0x25f0);
    }
    if (*(char *)(iVar17 + 0x1bb) != '\0') {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644ce0);
        }
        func_0x000180147f30();
    }
    if ((int32_t)*(int16_t *)(arg1 + 4) < *(int32_t *)(iVar17 + 0x1e0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e50);
            }
            iVar7 = *(int64_t *)0x180781f28;
            iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
            *(undefined *)(iVar5 + 0x10b) = 1;
            iVar18 = *(int64_t *)(iVar7 + 0x15e0);
            fVar29 = *(float *)(iVar18 + 0x19c) - *(float *)(iVar7 + 0xe0c);
            *(float *)(iVar18 + 0x19c) = fVar29;
            *(float *)(iVar18 + 0x158) = fVar29 + *(float *)(iVar18 + 0x60) + *(float *)(iVar18 + 0x1a0);
            *(int32_t *)(iVar5 + 0x1e0) = *(int32_t *)(iVar5 + 0x1e0) + -1;
            uVar27 = 1 << ((uint8_t)*(undefined4 *)(iVar5 + 0x1e0) & 0x1f);
            if ((*(uint32_t *)(iVar5 + 0x1e4) & uVar27) != 0) {
                iVar18 = (int64_t)*(int32_t *)(iVar7 + 0x2140);
                iVar17 = *(int64_t *)(iVar7 + 0x2148);
                if ((((*(uint32_t *)(iVar17 + -0x24 + iVar18 * 0x28) & 0x20000) != 0) &&
                    (*(char *)(iVar7 + 0x21cf) != '\0')) &&
                   ((*(int32_t *)(iVar7 + 0x2288) == 0 &&
                    ((((*(int64_t *)(iVar7 + 0x21d8) == iVar5 && (*(char *)(iVar7 + 0x2279) != '\0')) &&
                      (*(int32_t *)(iVar7 + 0x22c8) == 0)) && (*(int32_t *)(iVar7 + 0x2338) == 0)))))) {
                    *(undefined *)(iVar7 + 0x2279) = 0;
                    *(undefined4 *)(iVar7 + 0x1fb8) = *(undefined4 *)(iVar17 + -0x28 + iVar18 * 0x28);
                    *(uint32_t *)(iVar7 + 0x1fbc) = *(uint32_t *)(iVar17 + -0x20 + iVar18 * 0x28) & 0xffdfffff;
                    puVar6 = (undefined4 *)(iVar17 + -0x1c + iVar18 * 0x28);
                    uVar15 = puVar6[1];
                    uVar1 = puVar6[2];
                    uVar2 = puVar6[3];
                    *(undefined4 *)(iVar7 + 0x1fd4) = *puVar6;
                    *(undefined4 *)(iVar7 + 0x1fd8) = uVar15;
                    *(undefined4 *)(iVar7 + 0x1fdc) = uVar1;
                    *(undefined4 *)(iVar7 + 0x1fe0) = uVar2;
                    func_0x00018010ea60(iVar7 + 0x22c0);
                    *(undefined4 *)
                     (*(int64_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x438) + 0x47c +
                     (int64_t)*(int32_t *)(iVar7 + 0x21e4) * 8) = 0x7f7fffff;
                    if ((*(char *)(iVar7 + 0x2279) == '\0') && (*(char *)(iVar7 + 0x223a) == '\0')) {
                        uVar14 = 0;
                    } else {
                        uVar14 = 1;
                    }
                    *(undefined *)(iVar7 + 0x2239) = uVar14;
                }
                fVar29 = *(float *)(iVar17 + -0xc + iVar18 * 0x28);
                if ((fVar29 != 3.402823e+38) && (*(float *)(iVar5 + 700) <= *(float *)(iVar5 + 0x15c))) {
                    iVar24 = *(int64_t *)(iVar7 + 0x15e0);
                    fVar32 = *(float *)(iVar17 + -0x10 + iVar18 * 0x28);
                    fVar37 = *(float *)(iVar17 + -8 + iVar18 * 0x28);
                    if (fVar32 <= *(float *)(iVar24 + 700)) {
                        fVar32 = *(float *)(iVar24 + 700);
                    }
                    if ((*(uint32_t *)(iVar17 + -0x24 + iVar18 * 0x28) & 0x80000) != 0) {
                        fVar36 = *(float *)(iVar24 + 0x15c);
                        fVar30 = fVar36;
                        if ((*(int64_t *)(iVar7 + 0x24d0) != 0) &&
                           (fVar30 = *(float *)(*(int64_t *)(iVar7 + 0x24d0) + 0x80), fVar30 <= fVar36)) {
                            fVar30 = fVar36;
                        }
                        fVar36 = (float)(int32_t)((fVar30 - *(float *)(iVar7 + 0xdf0)) -
                                                 *(float *)(iVar7 + 0x12f8) * 0.5);
                        if (*(float *)(iVar7 + 0xdf0) + *(float *)(iVar7 + 0xe68) + fVar37 < fVar36) {
                            fVar37 = fVar36;
                        }
                    }
                    if (*(float *)(iVar24 + 0x2c4) <= fVar37) {
                        fVar37 = *(float *)(iVar24 + 0x2c4);
                    }
                    if (fVar32 < fVar37) {
                        iVar4 = *(int16_t *)(iVar17 + -4 + iVar18 * 0x28);
                        if ((iVar4 != -1) &&
                           (iVar8 = *(int64_t *)(iVar7 + 0x24d0), (*(uint32_t *)(iVar8 + 4) & 0x100000) == 0)) {
                            iVar23 = *(int64_t *)(iVar8 + 0x18);
                            iVar25 = (int64_t)iVar4 * 0x74;
                            iVar26 = *(int64_t *)(iVar24 + 800);
                            puVar6 = (undefined4 *)(iVar25 + 0x24 + iVar23);
                            uVar9 = puVar6[1];
                            uVar10 = puVar6[2];
                            uVar11 = puVar6[3];
                            uVar15 = *(undefined4 *)(iVar25 + 0x24 + iVar23);
                            uVar1 = *(undefined4 *)(iVar25 + 0x28 + iVar23);
                            uVar2 = *(undefined4 *)(iVar25 + 0x2c + iVar23);
                            uVar3 = *(undefined4 *)(iVar25 + 0x30 + iVar23);
                            *(undefined4 *)(iVar24 + 0x2b8) = *puVar6;
                            *(undefined4 *)(iVar24 + 700) = uVar9;
                            *(undefined4 *)(iVar24 + 0x2c0) = uVar10;
                            *(undefined4 *)(iVar24 + 0x2c4) = uVar11;
                            *(undefined4 *)(iVar26 + 0x60) = uVar15;
                            *(undefined4 *)(iVar26 + 100) = uVar1;
                            *(undefined4 *)(iVar26 + 0x68) = uVar2;
                            *(undefined4 *)(iVar26 + 0x6c) = uVar3;
                            iVar22 = (int64_t)*(int32_t *)(*(int64_t *)(iVar24 + 800) + 0xa0);
                            iVar26 = *(int64_t *)(*(int64_t *)(iVar24 + 800) + 0xa8);
                            *(undefined4 *)(iVar26 + -0x10 + iVar22 * 0x10) = uVar15;
                            *(undefined4 *)(iVar26 + -0xc + iVar22 * 0x10) = uVar1;
                            *(undefined4 *)(iVar26 + -8 + iVar22 * 0x10) = uVar2;
                            *(undefined4 *)(iVar26 + -4 + iVar22 * 0x10) = uVar3;
                            func_0x000180127010(*(undefined8 *)(iVar8 + 0x1a0), *(undefined8 *)(iVar24 + 800), 
                                                *(undefined2 *)(iVar25 + 0x60 + iVar23));
                        }
                        uStack_f8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1230);
                        uStack_f4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1234);
                        uStack_f0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1238);
                        fStack_ec = *(float *)(*(int64_t *)0x180781f28 + 0x123c) *
                                    *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                        fStackX_10 = (float)(int32_t)fVar29;
                        fStackX_14 = fVar37;
                        uStackX_18._0_4_ = fStackX_10;
                        uStackX_18._4_4_ = fVar32;
                        uVar15 = func_0x0001800f5fa0(&uStack_f8);
                        func_0x000180126300(*(undefined8 *)(iVar24 + 800), &uStackX_18, &fStackX_10, uVar15, 
                                            *(undefined4 *)(iVar7 + 0xe64));
                        if (((*(int16_t *)(iVar17 + -4 + iVar18 * 0x28) != -1) &&
                            (iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0),
                            (*(uint32_t *)(iVar17 + 4) & 0x100000) == 0)) && (*(int32_t *)(iVar17 + 0x74) != -1)) {
                            iVar18 = *(int64_t *)(iVar17 + 0x18);
                            iVar24 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
                            iVar26 = (int64_t)*(int32_t *)(iVar17 + 0x74) * 0x74;
                            iVar8 = *(int64_t *)(iVar24 + 800);
                            puVar6 = (undefined4 *)(iVar26 + 0x24 + iVar18);
                            uVar9 = puVar6[1];
                            uVar10 = puVar6[2];
                            uVar11 = puVar6[3];
                            uVar15 = *(undefined4 *)(iVar26 + 0x24 + iVar18);
                            uVar1 = *(undefined4 *)(iVar26 + 0x28 + iVar18);
                            uVar2 = *(undefined4 *)(iVar26 + 0x2c + iVar18);
                            uVar3 = *(undefined4 *)(iVar26 + 0x30 + iVar18);
                            *(undefined4 *)(iVar24 + 0x2b8) = *puVar6;
                            *(undefined4 *)(iVar24 + 700) = uVar9;
                            *(undefined4 *)(iVar24 + 0x2c0) = uVar10;
                            *(undefined4 *)(iVar24 + 0x2c4) = uVar11;
                            *(undefined4 *)(iVar8 + 0x60) = uVar15;
                            *(undefined4 *)(iVar8 + 100) = uVar1;
                            *(undefined4 *)(iVar8 + 0x68) = uVar2;
                            *(undefined4 *)(iVar8 + 0x6c) = uVar3;
                            iVar23 = (int64_t)*(int32_t *)(*(int64_t *)(iVar24 + 800) + 0xa0);
                            iVar8 = *(int64_t *)(*(int64_t *)(iVar24 + 800) + 0xa8);
                            *(undefined4 *)(iVar8 + -0x10 + iVar23 * 0x10) = uVar15;
                            *(undefined4 *)(iVar8 + -0xc + iVar23 * 0x10) = uVar1;
                            *(undefined4 *)(iVar8 + -8 + iVar23 * 0x10) = uVar2;
                            *(undefined4 *)(iVar8 + -4 + iVar23 * 0x10) = uVar3;
                            func_0x000180127010(*(undefined8 *)(iVar17 + 0x1a0), *(undefined8 *)(iVar24 + 800), 
                                                *(undefined2 *)(iVar26 + 0x60 + iVar18));
                        }
                    }
                }
                *(int32_t *)(iVar7 + 0x2140) = *(int32_t *)(iVar7 + 0x2140) + -1;
                uVar27 = ~uVar27;
                *(uint32_t *)(iVar5 + 0x1e4) = *(uint32_t *)(iVar5 + 0x1e4) & uVar27;
                *(uint32_t *)(iVar5 + 0x1e8) = *(uint32_t *)(iVar5 + 0x1e8) & uVar27;
                iVar17 = var_138h;
            }
            iVar16 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
            if (iVar16 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
                }
            } else {
                *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar16 + -1;
            }
        } while ((int32_t)*(int16_t *)(arg1 + 4) < *(int32_t *)(iVar17 + 0x1e0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 0xe) < *(int32_t *)(iVar12 + 0x2110)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e68);
            }
            func_0x00018010c110();
        } while ((int32_t)*(int16_t *)(arg1 + 0xe) < *(int32_t *)(iVar12 + 0x2110));
    }
    if ((int32_t)*(int16_t *)(arg1 + 2) < *(int32_t *)(iVar17 + 0x148)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e80);
            }
            iVar16 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
            if (iVar16 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
                }
            } else {
                *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar16 + -1;
            }
        } while ((int32_t)*(int16_t *)(arg1 + 2) < *(int32_t *)(iVar17 + 0x148));
    }
    if (*(int16_t *)(arg1 + 0x14) < *(int16_t *)(iVar12 + 0x281c)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e90);
            }
            iVar17 = *(int64_t *)0x180781f28;
            if ((*(uint8_t *)(iVar12 + 0x1f78) & 0x40) == 0) {
                *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) = *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) + -1;
                iVar16 = *(int32_t *)(iVar17 + 0x2100);
                *(int32_t *)(iVar17 + 0x2100) = iVar16 + -1;
                *(undefined4 *)(iVar17 + 0x1f78) =
                     *(undefined4 *)(*(int64_t *)(iVar17 + 0x2108) + -8 + (int64_t)iVar16 * 4);
                *(undefined4 *)(iVar17 + 0xd9c) =
                     *(undefined4 *)((int64_t)*(int32_t *)(iVar17 + 0x15b0) * 0x78 + -8 + *(int64_t *)(iVar17 + 0x15b8))
                ;
                *(undefined *)((int64_t)*(int32_t *)(iVar12 + 0x15b0) * 0x78 + -10 + *(int64_t *)(iVar12 + 0x15b8)) = 0;
            } else {
                func_0x000180106130();
            }
        } while (*(int16_t *)(arg1 + 0x14) < *(int16_t *)(iVar12 + 0x281c));
    }
    if ((int32_t)*(int16_t *)(arg1 + 6) < *(int32_t *)(iVar12 + 0x20c0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644df0);
            }
            func_0x0001800f6770(1);
        } while ((int32_t)*(int16_t *)(arg1 + 6) < *(int32_t *)(iVar12 + 0x20c0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 0x10) < *(int32_t *)(iVar12 + 0x2100)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e08);
            }
            iVar17 = *(int64_t *)0x180781f28;
            iVar16 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100);
            if (iVar16 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644628);
                }
            } else {
                *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100) = iVar16 + -1;
                *(undefined4 *)(iVar17 + 0x1f78) =
                     *(undefined4 *)(*(int64_t *)(iVar17 + 0x2108) + -8 + (int64_t)iVar16 * 4);
            }
        } while ((int32_t)*(int16_t *)(arg1 + 0x10) < *(int32_t *)(iVar12 + 0x2100));
    }
    if ((int32_t)*(int16_t *)(arg1 + 8) < *(int32_t *)(iVar12 + 0x20d0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e20);
            }
            func_0x0001800f6a20(1);
        } while ((int32_t)*(int16_t *)(arg1 + 8) < *(int32_t *)(iVar12 + 0x20d0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 10) < *(int32_t *)(iVar12 + 0x20e0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e38);
            }
            iVar17 = *(int64_t *)0x180781f28;
            if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) < 1) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445d0);
                }
            } else {
                func_0x0001801072d0(*(undefined8 *)
                                     (*(int64_t *)(*(int64_t *)0x180781f28 + 0x20e8) + -0x10 +
                                     (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) * 0x10));
                *(int32_t *)(iVar17 + 0x20e0) = *(int32_t *)(iVar17 + 0x20e0) + -1;
            }
        } while ((int32_t)*(int16_t *)(arg1 + 10) < *(int32_t *)(iVar12 + 0x20e0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 0xc) < *(int32_t *)(iVar12 + 0x20f0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644ea8);
            }
            iVar17 = *(int64_t *)0x180781f28;
            iVar16 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x20f0);
            if (*(int16_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x2a78) + 0xc) < iVar16) {
                *(int32_t *)(*(int64_t *)0x180781f28 + 0x20f0) = iVar16 + -1;
                if (iVar16 + -1 == 0) {
                    uVar15 = 0;
                } else {
                    uVar15 = *(undefined4 *)(*(int64_t *)(iVar17 + 0x20f8) + -0x10 + (int64_t)iVar16 * 8);
                }
                *(undefined4 *)(iVar17 + 0x1f74) = uVar15;
            } else if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445a8);
            }
        } while ((int32_t)*(int16_t *)(arg1 + 0xc) < *(int32_t *)(iVar12 + 0x20f0));
    }
    return;
}

// ============================================================
// Function: FUN_18010ab9c
// Address: 0x18010ab9c
// Size: 1381 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_158h
// WARNING: Variable defined which should be unmapped: var_150h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Removing arg arg_8ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_94h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_13ch
// WARNING: [rz-ghidra] Detected overlap for variable var_144h
// WARNING: [rz-ghidra] Detected overlap for variable arg_9ch

void fcn.18010a070(int64_t arg1, int64_t arg_80h, int64_t arg_98h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int16_t iVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int64_t iVar12;
    char cVar13;
    undefined uVar14;
    undefined4 uVar15;
    int32_t iVar16;
    int64_t iVar17;
    int64_t iVar18;
    int32_t iVar19;
    int64_t *piVar20;
    int64_t *piVar21;
    int64_t iVar22;
    int64_t iVar23;
    int64_t iVar24;
    int64_t iVar25;
    int64_t iVar26;
    uint32_t uVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    float fVar31;
    float fVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    float fVar36;
    float fVar37;
    float fVar38;
    float fStackX_10;
    float fStackX_14;
    undefined8 uStackX_18;
    float fStackX_20;
    float fStackX_24;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    float var_120h;
    float var_11ch;
    int64_t var_118h;
    float var_110h;
    int64_t var_10ch;
    undefined4 var_104h;
    undefined4 var_100h;
    undefined4 var_fch;
    undefined4 uStack_f8;
    undefined4 uStack_f4;
    undefined4 uStack_f0;
    float fStack_ec;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar12 = *(int64_t *)0x180781f28;
    iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0);
    while ((iVar17 != 0 && (*(int64_t *)(iVar17 + 0x188) == *(int64_t *)(iVar12 + 0x15e0)))) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644dc0);
        }
        func_0x0001801346c0();
        iVar17 = *(int64_t *)(iVar12 + 0x24d0);
    }
    iVar17 = *(int64_t *)(iVar12 + 0x15e0);
    piVar21 = *(int64_t **)(iVar12 + 0x2538);
    var_138h = iVar17;
    while ((piVar21 != (int64_t *)0x0 && (*piVar21 == iVar17))) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644ca8);
        }
        func_0x000180148e50();
        piVar21 = *(int64_t **)(iVar12 + 0x2538);
    }
    iVar5 = *(int64_t *)(iVar12 + 0x25f0);
    while ((iVar5 != 0 && (**(int64_t **)(iVar5 + 0x28) == iVar17))) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644cc0);
        }
        iVar18 = *(int64_t *)0x180781f28;
        puVar6 = *(undefined4 **)(*(int64_t *)0x180781f28 + 0x25f0);
        iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        iVar5 = *(int64_t *)(puVar6 + 10);
        var_130h = iVar17;
        if ((puVar6[0xc] != *(int32_t *)(*(int64_t *)0x180781f28 + 0x1f74)) &&
           (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0)) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180645b48);
        }
        func_0x0001801474f0(&var_118h, puVar6, iVar17);
        fVar36 = (float)var_10ch;
        fVar37 = var_110h;
        fVar32 = var_118h._4_4_;
        fVar29 = (float)var_118h;
        if (*(char *)((int64_t)puVar6 + 0x52) != '\0') {
            if ((*(char *)((int64_t)puVar6 + 0x21) != '\0') ||
               ((*(char *)((int64_t)puVar6 + 0x55) == '\0' && (*(int64_t *)(puVar6 + 4) != -1)))) {
                *(undefined8 *)(iVar5 + 0x18) = 0xffffffffffffffff;
            }
            if ((*(char *)(puVar6 + 0x15) == '\0') && (*(int64_t *)(iVar5 + 0x20) != -1)) {
                *(undefined8 *)(iVar5 + 0x20) = 0xffffffffffffffff;
                *(undefined *)(iVar5 + 0x15) = 0xff;
            }
            iVar5 = *(int64_t *)0x180781f28;
            uVar27 = puVar6[0xd];
            if (((((uVar27 & 0xc0) != 0) && (puVar6[0x12] != 0)) &&
                (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2588) == puVar6[0x12])) &&
               (*(char *)(*(int64_t *)0x180781f28 + 0x258c) != '\0')) {
                iVar7 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
                *(undefined *)(*(int64_t *)0x180781f28 + 0x25b8) = 0;
                iVar24 = *(int64_t *)0x180781f28;
                fVar30 = *(float *)(iVar5 + 0x11c);
                fVar28 = var_118h._4_4_;
                if ((var_118h._4_4_ <= fVar30) && (fVar28 = (float)var_10ch, fVar30 <= (float)var_10ch)) {
                    fVar28 = fVar30;
                }
                fVar30 = *(float *)(iVar5 + 0x118);
                fVar34 = (float)var_118h;
                if (((float)var_118h <= fVar30) && (fVar34 = var_110h, fVar30 <= var_110h)) {
                    fVar34 = fVar30;
                }
                fVar30 = *(float *)(iVar7 + 0x168);
                fVar38 = *(float *)(iVar5 + 0x25e8);
                if ((float)var_10ch <= *(float *)(iVar5 + 0x25e8)) {
                    fVar38 = (float)var_10ch;
                }
                *(float *)(iVar5 + 0x25a4) = fVar28 - *(float *)(iVar7 + 0x16c);
                fVar28 = *(float *)(iVar5 + 0x25e4);
                if (var_110h <= *(float *)(iVar5 + 0x25e4)) {
                    fVar28 = var_110h;
                }
                *(float *)(iVar5 + 0x25a0) = fVar34 - fVar30;
                uStack_f8 = *(undefined4 *)(iVar24 + 0x1090);
                uStack_f4 = *(undefined4 *)(iVar24 + 0x1094);
                uStack_f0 = *(undefined4 *)(iVar24 + 0x1098);
                fVar30 = *(float *)(iVar5 + 0x25dc);
                if (*(float *)(iVar5 + 0x25dc) <= (float)var_118h) {
                    fVar30 = (float)var_118h;
                }
                fVar34 = *(float *)(iVar5 + 0x25e0);
                if (*(float *)(iVar5 + 0x25e0) <= var_118h._4_4_) {
                    fVar34 = var_118h._4_4_;
                }
                fStack_ec = *(float *)(iVar24 + 0x109c) * *(float *)(iVar24 + 0xd9c) * 0.3;
                var_128h._0_4_ = fVar30;
                var_128h._4_4_ = fVar34;
                var_120h = fVar28;
                var_11ch = fVar38;
                uVar15 = func_0x0001800f5fa0(&uStack_f8);
                func_0x000180126550(*(undefined8 *)(iVar7 + 800), &var_128h, &var_120h, uVar15, 0, 0);
                uStack_f8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1270);
                uStack_f4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1274);
                uStack_f0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1278);
                fStack_ec = *(float *)(*(int64_t *)0x180781f28 + 0x127c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                iVar24 = *(int64_t *)0x180781f28;
                fStackX_10 = (float)func_0x0001800f5fa0();
                if (((uint32_t)fStackX_10 & 0xff000000) != 0) {
                    iVar17 = *(int64_t *)(iVar7 + 800);
                    if ((*(uint8_t *)(iVar17 + 0x30) & 1) == 0) {
                        var_148h._0_4_ = fVar28 - 0.49;
                        var_148h._4_4_ = fVar38 - 0.49;
                        piVar21 = &var_148h;
                        piVar20 = &var_140h;
                        var_140h._0_4_ = fVar30 + 0.5;
                        var_140h._4_4_ = fVar34 + 0.5;
                    } else {
                        uStackX_18._0_4_ = fVar28 - 0.5;
                        uStackX_18._4_4_ = fVar38 - 0.5;
                        piVar21 = &uStackX_18;
                        piVar20 = (int64_t *)&fStackX_20;
                        fStackX_20 = fVar30 + 0.5;
                        fStackX_24 = fVar34 + 0.5;
                    }
                    func_0x000180125f20(iVar17, piVar20, piVar21);
                    func_0x0001801248e0(iVar17, *(undefined8 *)(iVar17 + 0x58), *(undefined4 *)(iVar17 + 0x50), 
                                        fStackX_10, 1, 0x3f800000);
                    iVar24 = *(int64_t *)0x180781f28;
                    *(undefined4 *)(iVar17 + 0x50) = 0;
                    iVar17 = var_130h;
                }
                if ((uVar27 & 0x900) == 0x800) {
                    fVar28 = (float)(*(uint32_t *)(iVar5 + 0x12f8) ^ 0x80000000);
                    fVar34 = fVar29 - fVar28;
                    fVar38 = fVar32 - fVar28;
                    fVar30 = fVar37 + fVar28;
                    fVar28 = fVar36 + fVar28;
                    if ((((*(float *)(iVar5 + 0x118) < fVar34) || (*(float *)(iVar5 + 0x11c) < fVar38)) ||
                        (fVar30 <= *(float *)(iVar5 + 0x118))) || (fVar28 <= *(float *)(iVar5 + 0x11c))) {
                        fVar33 = *(float *)(iVar24 + 0x118);
                        if ((((fVar30 < fVar33) || (fVar30 = fVar34, fVar33 < fVar34)) &&
                            ((fVar33 = fVar33 - fVar30, fVar33 != 0.0 &&
                             ((fVar30 = *(float *)(iVar7 + 0xd4), 0.0 <= fVar33 || (0.0 <= fVar30)))))) &&
                           ((fVar33 <= 0.0 || (fVar30 < *(float *)(iVar7 + 0xdc))))) {
                            fVar34 = *(float *)(iVar24 + 0x12f8);
                            fVar35 = ((float)((uint32_t)fVar33 & 0x7fffffff) - fVar34) / (fVar34 * 5.0 - fVar34);
                            if (0.0 <= fVar35) {
                                fVar31 = 1.0;
                                if (fVar35 <= 1.0) {
                                    fVar31 = fVar35;
                                }
                            } else {
                                fVar31 = 0.0;
                            }
                            if (0.0 <= fVar33) {
                                if (fVar33 <= 0.0) {
                                    fVar33 = 0.0;
                                } else {
                                    fVar33 = 1.0;
                                }
                            } else {
                                fVar33 = -1.0;
                            }
                            fVar34 = (fVar31 * 3.0 + 1.0) * fVar34 * 35.0 * fVar33 * *(float *)(iVar24 + 0x48) +
                                     *(float *)(iVar5 + 0x25a8);
                            *(float *)(iVar5 + 0x25a8) = fVar34;
                            iVar16 = (int32_t)fVar34;
                            if ((fVar34 < 0.0) && ((float)iVar16 != fVar34)) {
                                iVar16 = iVar16 + -1;
                            }
                            fVar34 = (float)iVar16;
                            if (fVar34 != 0.0) {
                                *(undefined4 *)(iVar7 + 0xec) = 0;
                                *(undefined4 *)(iVar7 + 0xf4) = 0;
                                *(float *)(iVar7 + 0xe4) = fVar34 + fVar30;
                                *(float *)(iVar5 + 0x25a8) = *(float *)(iVar5 + 0x25a8) - fVar34;
                            }
                        }
                        fVar30 = *(float *)(iVar24 + 0x11c);
                        if (((((fVar28 < fVar30) || (fVar28 = fVar38, fVar30 < fVar38)) &&
                             (fVar30 = fVar30 - fVar28, fVar30 != 0.0)) &&
                            ((fVar28 = *(float *)(iVar7 + 0xd8), 0.0 <= fVar30 || (0.0 <= fVar28)))) &&
                           ((fVar30 <= 0.0 || (fVar28 < *(float *)(iVar7 + 0xe0))))) {
                            fVar34 = *(float *)(iVar24 + 0x12f8);
                            fVar38 = ((float)((uint32_t)fVar30 & 0x7fffffff) - fVar34) / (fVar34 * 5.0 - fVar34);
                            if (0.0 <= fVar38) {
                                fVar33 = 1.0;
                                if (fVar38 <= 1.0) {
                                    fVar33 = fVar38;
                                }
                            } else {
                                fVar33 = 0.0;
                            }
                            if (0.0 <= fVar30) {
                                if (fVar30 <= 0.0) {
                                    fVar30 = 0.0;
                                } else {
                                    fVar30 = 1.0;
                                }
                            } else {
                                fVar30 = -1.0;
                            }
                            fVar30 = (fVar33 * 3.0 + 1.0) * fVar34 * 35.0 * fVar30 * *(float *)(iVar24 + 0x48) +
                                     *(float *)(iVar5 + 0x25ac);
                            *(float *)(iVar5 + 0x25ac) = fVar30;
                            iVar16 = (int32_t)fVar30;
                            if ((fVar30 < 0.0) && ((float)iVar16 != fVar30)) {
                                iVar16 = iVar16 + -1;
                            }
                            fVar30 = (float)iVar16;
                            if (fVar30 != 0.0) {
                                *(float *)(iVar7 + 0xe8) = fVar28 + fVar30;
                                *(undefined4 *)(iVar7 + 0xf0) = 0;
                                *(undefined4 *)(iVar7 + 0xf8) = 0;
                                *(float *)(iVar5 + 0x25ac) = *(float *)(iVar5 + 0x25ac) - fVar30;
                            }
                        }
                    }
                }
            }
        }
        if (*(char *)((int64_t)puVar6 + 0x51) == '\0') {
            iVar16 = puVar6[1];
            if (iVar16 < 0) {
                iVar16 = (iVar16 + 1 >> 1) + iVar16;
                iVar19 = 0;
                if (0 < iVar16) {
                    iVar19 = iVar16;
                }
                func_0x00018014fa90(puVar6, iVar19);
            }
            *puVar6 = 0;
        }
        cVar13 = func_0x0001801062b0();
        iVar5 = *(int64_t *)0x180781f28;
        if ((((cVar13 != '\0') && (fVar30 = *(float *)(iVar18 + 0x118), *(float *)(iVar17 + 0x278) <= fVar30)) &&
            (fVar28 = *(float *)(iVar18 + 0x11c), *(float *)(iVar17 + 0x27c) <= fVar28)) &&
           ((fVar30 < *(float *)(iVar17 + 0x280) && (fVar28 < *(float *)(iVar17 + 0x284))))) {
            if (((((uint32_t)puVar6[0xd] >> 0xc & 1) == 0) ||
                (((fVar29 <= fVar30 && (fVar32 <= fVar28)) && ((fVar30 < fVar37 && (fVar28 < fVar36)))))) &&
               ((*(int32_t *)(iVar18 + 0x163c) == 0 && (*(int32_t *)(iVar18 + 0x1654) == 0)))) {
                if (((puVar6[0xd] & 0xc0) != 0) &&
                   (((*(char *)(iVar18 + 0x258c) == '\0' && (*(char *)(iVar18 + 0x258d) == '\0')) &&
                    (*(int16_t *)(iVar18 + 0xb5a) == 1)))) {
                    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2588) = puVar6[0x12];
                    *(undefined2 *)(iVar5 + 0x258d) = 0x101;
                    *(undefined *)(iVar5 + 0x258f) = 1;
                    *(undefined2 *)(iVar5 + 0x2594) = *(undefined2 *)(iVar5 + 0x13c);
                    fVar32 = *(float *)(iVar5 + 0x118) - *(float *)(*(int64_t *)(iVar5 + 0x15e0) + 0x168);
                    fVar29 = *(float *)(iVar5 + 0x11c) - *(float *)(*(int64_t *)(iVar5 + 0x15e0) + 0x16c);
                    *(undefined8 *)(iVar5 + 0x25a8) = 0;
                    *(float *)(iVar5 + 0x25a0) = fVar32;
                    *(float *)(iVar5 + 0x25a4) = fVar29;
                    *(float *)(iVar5 + 0x2598) = fVar32;
                    *(float *)(iVar5 + 0x259c) = fVar29;
                    func_0x00018010e050(iVar17, 2);
                    iVar5 = *(int64_t *)0x180781f28;
                    iVar16 = puVar6[0x12];
                    *(int32_t *)(*(int64_t *)0x180781f28 + 0x163c) = iVar16;
                    *(undefined *)(iVar5 + 0x1650) = 0;
                    if ((iVar16 != 0) && (*(int32_t *)(iVar5 + 0x1640) != iVar16)) {
                        *(undefined8 *)(iVar5 + 0x1648) = 0;
                    }
                    if ((puVar6[0xd] & 0x1000) != 0) {
                        var_10ch._4_4_ = *(undefined4 *)(iVar18 + 0x118);
                        var_104h = *(undefined4 *)(iVar18 + 0x11c);
                        var_100h = var_10ch._4_4_;
                        var_fch = var_104h;
                        func_0x00018010e3f0(0, 0, puVar6[0xc], (int64_t)&var_10ch + 4);
                    }
                }
                if ((((puVar6[0xd] & 0x400) != 0) && (cVar13 = fcn.180108070(0), cVar13 != '\0')) &&
                   ((*(float *)(*(int64_t *)0x180781f28 + 0xbfc) <
                     *(float *)(*(int64_t *)0x180781f28 + 0xa4) * *(float *)(*(int64_t *)0x180781f28 + 0xa4) &&
                    (*(int32_t *)(iVar18 + 0x13c) == 0)))) {
                    func_0x000180147c50(puVar6);
                }
            }
        }
        iVar5 = *(int64_t *)0x180781f28;
        if ((puVar6[0xd] & 0x10000) != 0) {
            *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
            if (((*(int64_t *)(iVar5 + 0x21d8) == *(int64_t *)(iVar5 + 0x15e0)) && (*(char *)(iVar5 + 0x2279) != '\0'))
               && (*(int32_t *)(iVar5 + 0x21e4) == *(int32_t *)(*(int64_t *)(iVar5 + 0x15e0) + 0x1b0))) {
                *(uint32_t *)(iVar5 + 0x227c) = *(uint32_t *)(iVar5 + 0x227c) & 0xfffffff4;
                *(uint32_t *)(iVar5 + 0x227c) = *(uint32_t *)(iVar5 + 0x227c) | 4;
            }
        }
        if ((*(int64_t *)(iVar18 + 0x24d0) != 0) && (*(char *)(*(int64_t *)(iVar18 + 0x24d0) + 0x23a) != '\0')) {
            func_0x000180136780();
        }
        fVar29 = (float)puVar6[0x10];
        if ((float)puVar6[0x10] <= *(float *)(iVar17 + 0x170)) {
            fVar29 = *(float *)(iVar17 + 0x170);
        }
        fVar32 = (float)puVar6[0x11];
        if ((float)puVar6[0x11] <= *(float *)(iVar17 + 0x174)) {
            fVar32 = *(float *)(iVar17 + 0x174);
        }
        *(float *)(iVar17 + 0x170) = fVar29;
        *(float *)(iVar17 + 0x174) = fVar32;
        func_0x0001801067d0();
        puVar6[0xc] = 0;
        puVar6[0xd] = 0;
        *(int32_t *)(iVar18 + 0x25f8) = *(int32_t *)(iVar18 + 0x25f8) + -1;
        if (*(int32_t *)(iVar18 + 0x25f8) < 1) {
            iVar17 = 0;
        } else {
            iVar17 = (int64_t)(*(int32_t *)(iVar18 + 0x25f8) + -1) * 0x58 + *(int64_t *)(iVar18 + 0x2608);
        }
        *(int64_t *)(iVar18 + 0x25f0) = iVar17;
        iVar17 = var_138h;
        iVar5 = *(int64_t *)(iVar12 + 0x25f0);
    }
    if (*(char *)(iVar17 + 0x1bb) != '\0') {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644ce0);
        }
        func_0x000180147f30();
    }
    if ((int32_t)*(int16_t *)(arg1 + 4) < *(int32_t *)(iVar17 + 0x1e0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e50);
            }
            iVar7 = *(int64_t *)0x180781f28;
            iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
            *(undefined *)(iVar5 + 0x10b) = 1;
            iVar18 = *(int64_t *)(iVar7 + 0x15e0);
            fVar29 = *(float *)(iVar18 + 0x19c) - *(float *)(iVar7 + 0xe0c);
            *(float *)(iVar18 + 0x19c) = fVar29;
            *(float *)(iVar18 + 0x158) = fVar29 + *(float *)(iVar18 + 0x60) + *(float *)(iVar18 + 0x1a0);
            *(int32_t *)(iVar5 + 0x1e0) = *(int32_t *)(iVar5 + 0x1e0) + -1;
            uVar27 = 1 << ((uint8_t)*(undefined4 *)(iVar5 + 0x1e0) & 0x1f);
            if ((*(uint32_t *)(iVar5 + 0x1e4) & uVar27) != 0) {
                iVar18 = (int64_t)*(int32_t *)(iVar7 + 0x2140);
                iVar17 = *(int64_t *)(iVar7 + 0x2148);
                if ((((*(uint32_t *)(iVar17 + -0x24 + iVar18 * 0x28) & 0x20000) != 0) &&
                    (*(char *)(iVar7 + 0x21cf) != '\0')) &&
                   ((*(int32_t *)(iVar7 + 0x2288) == 0 &&
                    ((((*(int64_t *)(iVar7 + 0x21d8) == iVar5 && (*(char *)(iVar7 + 0x2279) != '\0')) &&
                      (*(int32_t *)(iVar7 + 0x22c8) == 0)) && (*(int32_t *)(iVar7 + 0x2338) == 0)))))) {
                    *(undefined *)(iVar7 + 0x2279) = 0;
                    *(undefined4 *)(iVar7 + 0x1fb8) = *(undefined4 *)(iVar17 + -0x28 + iVar18 * 0x28);
                    *(uint32_t *)(iVar7 + 0x1fbc) = *(uint32_t *)(iVar17 + -0x20 + iVar18 * 0x28) & 0xffdfffff;
                    puVar6 = (undefined4 *)(iVar17 + -0x1c + iVar18 * 0x28);
                    uVar15 = puVar6[1];
                    uVar1 = puVar6[2];
                    uVar2 = puVar6[3];
                    *(undefined4 *)(iVar7 + 0x1fd4) = *puVar6;
                    *(undefined4 *)(iVar7 + 0x1fd8) = uVar15;
                    *(undefined4 *)(iVar7 + 0x1fdc) = uVar1;
                    *(undefined4 *)(iVar7 + 0x1fe0) = uVar2;
                    func_0x00018010ea60(iVar7 + 0x22c0);
                    *(undefined4 *)
                     (*(int64_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x438) + 0x47c +
                     (int64_t)*(int32_t *)(iVar7 + 0x21e4) * 8) = 0x7f7fffff;
                    if ((*(char *)(iVar7 + 0x2279) == '\0') && (*(char *)(iVar7 + 0x223a) == '\0')) {
                        uVar14 = 0;
                    } else {
                        uVar14 = 1;
                    }
                    *(undefined *)(iVar7 + 0x2239) = uVar14;
                }
                fVar29 = *(float *)(iVar17 + -0xc + iVar18 * 0x28);
                if ((fVar29 != 3.402823e+38) && (*(float *)(iVar5 + 700) <= *(float *)(iVar5 + 0x15c))) {
                    iVar24 = *(int64_t *)(iVar7 + 0x15e0);
                    fVar32 = *(float *)(iVar17 + -0x10 + iVar18 * 0x28);
                    fVar37 = *(float *)(iVar17 + -8 + iVar18 * 0x28);
                    if (fVar32 <= *(float *)(iVar24 + 700)) {
                        fVar32 = *(float *)(iVar24 + 700);
                    }
                    if ((*(uint32_t *)(iVar17 + -0x24 + iVar18 * 0x28) & 0x80000) != 0) {
                        fVar36 = *(float *)(iVar24 + 0x15c);
                        fVar30 = fVar36;
                        if ((*(int64_t *)(iVar7 + 0x24d0) != 0) &&
                           (fVar30 = *(float *)(*(int64_t *)(iVar7 + 0x24d0) + 0x80), fVar30 <= fVar36)) {
                            fVar30 = fVar36;
                        }
                        fVar36 = (float)(int32_t)((fVar30 - *(float *)(iVar7 + 0xdf0)) -
                                                 *(float *)(iVar7 + 0x12f8) * 0.5);
                        if (*(float *)(iVar7 + 0xdf0) + *(float *)(iVar7 + 0xe68) + fVar37 < fVar36) {
                            fVar37 = fVar36;
                        }
                    }
                    if (*(float *)(iVar24 + 0x2c4) <= fVar37) {
                        fVar37 = *(float *)(iVar24 + 0x2c4);
                    }
                    if (fVar32 < fVar37) {
                        iVar4 = *(int16_t *)(iVar17 + -4 + iVar18 * 0x28);
                        if ((iVar4 != -1) &&
                           (iVar8 = *(int64_t *)(iVar7 + 0x24d0), (*(uint32_t *)(iVar8 + 4) & 0x100000) == 0)) {
                            iVar23 = *(int64_t *)(iVar8 + 0x18);
                            iVar25 = (int64_t)iVar4 * 0x74;
                            iVar26 = *(int64_t *)(iVar24 + 800);
                            puVar6 = (undefined4 *)(iVar25 + 0x24 + iVar23);
                            uVar9 = puVar6[1];
                            uVar10 = puVar6[2];
                            uVar11 = puVar6[3];
                            uVar15 = *(undefined4 *)(iVar25 + 0x24 + iVar23);
                            uVar1 = *(undefined4 *)(iVar25 + 0x28 + iVar23);
                            uVar2 = *(undefined4 *)(iVar25 + 0x2c + iVar23);
                            uVar3 = *(undefined4 *)(iVar25 + 0x30 + iVar23);
                            *(undefined4 *)(iVar24 + 0x2b8) = *puVar6;
                            *(undefined4 *)(iVar24 + 700) = uVar9;
                            *(undefined4 *)(iVar24 + 0x2c0) = uVar10;
                            *(undefined4 *)(iVar24 + 0x2c4) = uVar11;
                            *(undefined4 *)(iVar26 + 0x60) = uVar15;
                            *(undefined4 *)(iVar26 + 100) = uVar1;
                            *(undefined4 *)(iVar26 + 0x68) = uVar2;
                            *(undefined4 *)(iVar26 + 0x6c) = uVar3;
                            iVar22 = (int64_t)*(int32_t *)(*(int64_t *)(iVar24 + 800) + 0xa0);
                            iVar26 = *(int64_t *)(*(int64_t *)(iVar24 + 800) + 0xa8);
                            *(undefined4 *)(iVar26 + -0x10 + iVar22 * 0x10) = uVar15;
                            *(undefined4 *)(iVar26 + -0xc + iVar22 * 0x10) = uVar1;
                            *(undefined4 *)(iVar26 + -8 + iVar22 * 0x10) = uVar2;
                            *(undefined4 *)(iVar26 + -4 + iVar22 * 0x10) = uVar3;
                            func_0x000180127010(*(undefined8 *)(iVar8 + 0x1a0), *(undefined8 *)(iVar24 + 800), 
                                                *(undefined2 *)(iVar25 + 0x60 + iVar23));
                        }
                        uStack_f8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1230);
                        uStack_f4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1234);
                        uStack_f0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1238);
                        fStack_ec = *(float *)(*(int64_t *)0x180781f28 + 0x123c) *
                                    *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                        fStackX_10 = (float)(int32_t)fVar29;
                        fStackX_14 = fVar37;
                        uStackX_18._0_4_ = fStackX_10;
                        uStackX_18._4_4_ = fVar32;
                        uVar15 = func_0x0001800f5fa0(&uStack_f8);
                        func_0x000180126300(*(undefined8 *)(iVar24 + 800), &uStackX_18, &fStackX_10, uVar15, 
                                            *(undefined4 *)(iVar7 + 0xe64));
                        if (((*(int16_t *)(iVar17 + -4 + iVar18 * 0x28) != -1) &&
                            (iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0),
                            (*(uint32_t *)(iVar17 + 4) & 0x100000) == 0)) && (*(int32_t *)(iVar17 + 0x74) != -1)) {
                            iVar18 = *(int64_t *)(iVar17 + 0x18);
                            iVar24 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
                            iVar26 = (int64_t)*(int32_t *)(iVar17 + 0x74) * 0x74;
                            iVar8 = *(int64_t *)(iVar24 + 800);
                            puVar6 = (undefined4 *)(iVar26 + 0x24 + iVar18);
                            uVar9 = puVar6[1];
                            uVar10 = puVar6[2];
                            uVar11 = puVar6[3];
                            uVar15 = *(undefined4 *)(iVar26 + 0x24 + iVar18);
                            uVar1 = *(undefined4 *)(iVar26 + 0x28 + iVar18);
                            uVar2 = *(undefined4 *)(iVar26 + 0x2c + iVar18);
                            uVar3 = *(undefined4 *)(iVar26 + 0x30 + iVar18);
                            *(undefined4 *)(iVar24 + 0x2b8) = *puVar6;
                            *(undefined4 *)(iVar24 + 700) = uVar9;
                            *(undefined4 *)(iVar24 + 0x2c0) = uVar10;
                            *(undefined4 *)(iVar24 + 0x2c4) = uVar11;
                            *(undefined4 *)(iVar8 + 0x60) = uVar15;
                            *(undefined4 *)(iVar8 + 100) = uVar1;
                            *(undefined4 *)(iVar8 + 0x68) = uVar2;
                            *(undefined4 *)(iVar8 + 0x6c) = uVar3;
                            iVar23 = (int64_t)*(int32_t *)(*(int64_t *)(iVar24 + 800) + 0xa0);
                            iVar8 = *(int64_t *)(*(int64_t *)(iVar24 + 800) + 0xa8);
                            *(undefined4 *)(iVar8 + -0x10 + iVar23 * 0x10) = uVar15;
                            *(undefined4 *)(iVar8 + -0xc + iVar23 * 0x10) = uVar1;
                            *(undefined4 *)(iVar8 + -8 + iVar23 * 0x10) = uVar2;
                            *(undefined4 *)(iVar8 + -4 + iVar23 * 0x10) = uVar3;
                            func_0x000180127010(*(undefined8 *)(iVar17 + 0x1a0), *(undefined8 *)(iVar24 + 800), 
                                                *(undefined2 *)(iVar26 + 0x60 + iVar18));
                        }
                    }
                }
                *(int32_t *)(iVar7 + 0x2140) = *(int32_t *)(iVar7 + 0x2140) + -1;
                uVar27 = ~uVar27;
                *(uint32_t *)(iVar5 + 0x1e4) = *(uint32_t *)(iVar5 + 0x1e4) & uVar27;
                *(uint32_t *)(iVar5 + 0x1e8) = *(uint32_t *)(iVar5 + 0x1e8) & uVar27;
                iVar17 = var_138h;
            }
            iVar16 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
            if (iVar16 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
                }
            } else {
                *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar16 + -1;
            }
        } while ((int32_t)*(int16_t *)(arg1 + 4) < *(int32_t *)(iVar17 + 0x1e0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 0xe) < *(int32_t *)(iVar12 + 0x2110)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e68);
            }
            func_0x00018010c110();
        } while ((int32_t)*(int16_t *)(arg1 + 0xe) < *(int32_t *)(iVar12 + 0x2110));
    }
    if ((int32_t)*(int16_t *)(arg1 + 2) < *(int32_t *)(iVar17 + 0x148)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e80);
            }
            iVar16 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
            if (iVar16 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
                }
            } else {
                *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar16 + -1;
            }
        } while ((int32_t)*(int16_t *)(arg1 + 2) < *(int32_t *)(iVar17 + 0x148));
    }
    if (*(int16_t *)(arg1 + 0x14) < *(int16_t *)(iVar12 + 0x281c)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e90);
            }
            iVar17 = *(int64_t *)0x180781f28;
            if ((*(uint8_t *)(iVar12 + 0x1f78) & 0x40) == 0) {
                *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) = *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) + -1;
                iVar16 = *(int32_t *)(iVar17 + 0x2100);
                *(int32_t *)(iVar17 + 0x2100) = iVar16 + -1;
                *(undefined4 *)(iVar17 + 0x1f78) =
                     *(undefined4 *)(*(int64_t *)(iVar17 + 0x2108) + -8 + (int64_t)iVar16 * 4);
                *(undefined4 *)(iVar17 + 0xd9c) =
                     *(undefined4 *)((int64_t)*(int32_t *)(iVar17 + 0x15b0) * 0x78 + -8 + *(int64_t *)(iVar17 + 0x15b8))
                ;
                *(undefined *)((int64_t)*(int32_t *)(iVar12 + 0x15b0) * 0x78 + -10 + *(int64_t *)(iVar12 + 0x15b8)) = 0;
            } else {
                func_0x000180106130();
            }
        } while (*(int16_t *)(arg1 + 0x14) < *(int16_t *)(iVar12 + 0x281c));
    }
    if ((int32_t)*(int16_t *)(arg1 + 6) < *(int32_t *)(iVar12 + 0x20c0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644df0);
            }
            func_0x0001800f6770(1);
        } while ((int32_t)*(int16_t *)(arg1 + 6) < *(int32_t *)(iVar12 + 0x20c0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 0x10) < *(int32_t *)(iVar12 + 0x2100)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e08);
            }
            iVar17 = *(int64_t *)0x180781f28;
            iVar16 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100);
            if (iVar16 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644628);
                }
            } else {
                *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100) = iVar16 + -1;
                *(undefined4 *)(iVar17 + 0x1f78) =
                     *(undefined4 *)(*(int64_t *)(iVar17 + 0x2108) + -8 + (int64_t)iVar16 * 4);
            }
        } while ((int32_t)*(int16_t *)(arg1 + 0x10) < *(int32_t *)(iVar12 + 0x2100));
    }
    if ((int32_t)*(int16_t *)(arg1 + 8) < *(int32_t *)(iVar12 + 0x20d0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e20);
            }
            func_0x0001800f6a20(1);
        } while ((int32_t)*(int16_t *)(arg1 + 8) < *(int32_t *)(iVar12 + 0x20d0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 10) < *(int32_t *)(iVar12 + 0x20e0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e38);
            }
            iVar17 = *(int64_t *)0x180781f28;
            if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) < 1) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445d0);
                }
            } else {
                func_0x0001801072d0(*(undefined8 *)
                                     (*(int64_t *)(*(int64_t *)0x180781f28 + 0x20e8) + -0x10 +
                                     (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) * 0x10));
                *(int32_t *)(iVar17 + 0x20e0) = *(int32_t *)(iVar17 + 0x20e0) + -1;
            }
        } while ((int32_t)*(int16_t *)(arg1 + 10) < *(int32_t *)(iVar12 + 0x20e0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 0xc) < *(int32_t *)(iVar12 + 0x20f0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644ea8);
            }
            iVar17 = *(int64_t *)0x180781f28;
            iVar16 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x20f0);
            if (*(int16_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x2a78) + 0xc) < iVar16) {
                *(int32_t *)(*(int64_t *)0x180781f28 + 0x20f0) = iVar16 + -1;
                if (iVar16 + -1 == 0) {
                    uVar15 = 0;
                } else {
                    uVar15 = *(undefined4 *)(*(int64_t *)(iVar17 + 0x20f8) + -0x10 + (int64_t)iVar16 * 8);
                }
                *(undefined4 *)(iVar17 + 0x1f74) = uVar15;
            } else if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445a8);
            }
        } while ((int32_t)*(int16_t *)(arg1 + 0xc) < *(int32_t *)(iVar12 + 0x20f0));
    }
    return;
}

// ============================================================
// Function: FUN_18010b101
// Address: 0x18010b101
// Size: 223 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_158h
// WARNING: Variable defined which should be unmapped: var_150h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Removing arg arg_8ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_94h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_13ch
// WARNING: [rz-ghidra] Detected overlap for variable var_144h
// WARNING: [rz-ghidra] Detected overlap for variable arg_9ch

void fcn.18010a070(int64_t arg1, int64_t arg_80h, int64_t arg_98h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int16_t iVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int64_t iVar12;
    char cVar13;
    undefined uVar14;
    undefined4 uVar15;
    int32_t iVar16;
    int64_t iVar17;
    int64_t iVar18;
    int32_t iVar19;
    int64_t *piVar20;
    int64_t *piVar21;
    int64_t iVar22;
    int64_t iVar23;
    int64_t iVar24;
    int64_t iVar25;
    int64_t iVar26;
    uint32_t uVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    float fVar31;
    float fVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    float fVar36;
    float fVar37;
    float fVar38;
    float fStackX_10;
    float fStackX_14;
    undefined8 uStackX_18;
    float fStackX_20;
    float fStackX_24;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    float var_120h;
    float var_11ch;
    int64_t var_118h;
    float var_110h;
    int64_t var_10ch;
    undefined4 var_104h;
    undefined4 var_100h;
    undefined4 var_fch;
    undefined4 uStack_f8;
    undefined4 uStack_f4;
    undefined4 uStack_f0;
    float fStack_ec;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar12 = *(int64_t *)0x180781f28;
    iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0);
    while ((iVar17 != 0 && (*(int64_t *)(iVar17 + 0x188) == *(int64_t *)(iVar12 + 0x15e0)))) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644dc0);
        }
        func_0x0001801346c0();
        iVar17 = *(int64_t *)(iVar12 + 0x24d0);
    }
    iVar17 = *(int64_t *)(iVar12 + 0x15e0);
    piVar21 = *(int64_t **)(iVar12 + 0x2538);
    var_138h = iVar17;
    while ((piVar21 != (int64_t *)0x0 && (*piVar21 == iVar17))) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644ca8);
        }
        func_0x000180148e50();
        piVar21 = *(int64_t **)(iVar12 + 0x2538);
    }
    iVar5 = *(int64_t *)(iVar12 + 0x25f0);
    while ((iVar5 != 0 && (**(int64_t **)(iVar5 + 0x28) == iVar17))) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644cc0);
        }
        iVar18 = *(int64_t *)0x180781f28;
        puVar6 = *(undefined4 **)(*(int64_t *)0x180781f28 + 0x25f0);
        iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        iVar5 = *(int64_t *)(puVar6 + 10);
        var_130h = iVar17;
        if ((puVar6[0xc] != *(int32_t *)(*(int64_t *)0x180781f28 + 0x1f74)) &&
           (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0)) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180645b48);
        }
        func_0x0001801474f0(&var_118h, puVar6, iVar17);
        fVar36 = (float)var_10ch;
        fVar37 = var_110h;
        fVar32 = var_118h._4_4_;
        fVar29 = (float)var_118h;
        if (*(char *)((int64_t)puVar6 + 0x52) != '\0') {
            if ((*(char *)((int64_t)puVar6 + 0x21) != '\0') ||
               ((*(char *)((int64_t)puVar6 + 0x55) == '\0' && (*(int64_t *)(puVar6 + 4) != -1)))) {
                *(undefined8 *)(iVar5 + 0x18) = 0xffffffffffffffff;
            }
            if ((*(char *)(puVar6 + 0x15) == '\0') && (*(int64_t *)(iVar5 + 0x20) != -1)) {
                *(undefined8 *)(iVar5 + 0x20) = 0xffffffffffffffff;
                *(undefined *)(iVar5 + 0x15) = 0xff;
            }
            iVar5 = *(int64_t *)0x180781f28;
            uVar27 = puVar6[0xd];
            if (((((uVar27 & 0xc0) != 0) && (puVar6[0x12] != 0)) &&
                (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2588) == puVar6[0x12])) &&
               (*(char *)(*(int64_t *)0x180781f28 + 0x258c) != '\0')) {
                iVar7 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
                *(undefined *)(*(int64_t *)0x180781f28 + 0x25b8) = 0;
                iVar24 = *(int64_t *)0x180781f28;
                fVar30 = *(float *)(iVar5 + 0x11c);
                fVar28 = var_118h._4_4_;
                if ((var_118h._4_4_ <= fVar30) && (fVar28 = (float)var_10ch, fVar30 <= (float)var_10ch)) {
                    fVar28 = fVar30;
                }
                fVar30 = *(float *)(iVar5 + 0x118);
                fVar34 = (float)var_118h;
                if (((float)var_118h <= fVar30) && (fVar34 = var_110h, fVar30 <= var_110h)) {
                    fVar34 = fVar30;
                }
                fVar30 = *(float *)(iVar7 + 0x168);
                fVar38 = *(float *)(iVar5 + 0x25e8);
                if ((float)var_10ch <= *(float *)(iVar5 + 0x25e8)) {
                    fVar38 = (float)var_10ch;
                }
                *(float *)(iVar5 + 0x25a4) = fVar28 - *(float *)(iVar7 + 0x16c);
                fVar28 = *(float *)(iVar5 + 0x25e4);
                if (var_110h <= *(float *)(iVar5 + 0x25e4)) {
                    fVar28 = var_110h;
                }
                *(float *)(iVar5 + 0x25a0) = fVar34 - fVar30;
                uStack_f8 = *(undefined4 *)(iVar24 + 0x1090);
                uStack_f4 = *(undefined4 *)(iVar24 + 0x1094);
                uStack_f0 = *(undefined4 *)(iVar24 + 0x1098);
                fVar30 = *(float *)(iVar5 + 0x25dc);
                if (*(float *)(iVar5 + 0x25dc) <= (float)var_118h) {
                    fVar30 = (float)var_118h;
                }
                fVar34 = *(float *)(iVar5 + 0x25e0);
                if (*(float *)(iVar5 + 0x25e0) <= var_118h._4_4_) {
                    fVar34 = var_118h._4_4_;
                }
                fStack_ec = *(float *)(iVar24 + 0x109c) * *(float *)(iVar24 + 0xd9c) * 0.3;
                var_128h._0_4_ = fVar30;
                var_128h._4_4_ = fVar34;
                var_120h = fVar28;
                var_11ch = fVar38;
                uVar15 = func_0x0001800f5fa0(&uStack_f8);
                func_0x000180126550(*(undefined8 *)(iVar7 + 800), &var_128h, &var_120h, uVar15, 0, 0);
                uStack_f8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1270);
                uStack_f4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1274);
                uStack_f0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1278);
                fStack_ec = *(float *)(*(int64_t *)0x180781f28 + 0x127c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                iVar24 = *(int64_t *)0x180781f28;
                fStackX_10 = (float)func_0x0001800f5fa0();
                if (((uint32_t)fStackX_10 & 0xff000000) != 0) {
                    iVar17 = *(int64_t *)(iVar7 + 800);
                    if ((*(uint8_t *)(iVar17 + 0x30) & 1) == 0) {
                        var_148h._0_4_ = fVar28 - 0.49;
                        var_148h._4_4_ = fVar38 - 0.49;
                        piVar21 = &var_148h;
                        piVar20 = &var_140h;
                        var_140h._0_4_ = fVar30 + 0.5;
                        var_140h._4_4_ = fVar34 + 0.5;
                    } else {
                        uStackX_18._0_4_ = fVar28 - 0.5;
                        uStackX_18._4_4_ = fVar38 - 0.5;
                        piVar21 = &uStackX_18;
                        piVar20 = (int64_t *)&fStackX_20;
                        fStackX_20 = fVar30 + 0.5;
                        fStackX_24 = fVar34 + 0.5;
                    }
                    func_0x000180125f20(iVar17, piVar20, piVar21);
                    func_0x0001801248e0(iVar17, *(undefined8 *)(iVar17 + 0x58), *(undefined4 *)(iVar17 + 0x50), 
                                        fStackX_10, 1, 0x3f800000);
                    iVar24 = *(int64_t *)0x180781f28;
                    *(undefined4 *)(iVar17 + 0x50) = 0;
                    iVar17 = var_130h;
                }
                if ((uVar27 & 0x900) == 0x800) {
                    fVar28 = (float)(*(uint32_t *)(iVar5 + 0x12f8) ^ 0x80000000);
                    fVar34 = fVar29 - fVar28;
                    fVar38 = fVar32 - fVar28;
                    fVar30 = fVar37 + fVar28;
                    fVar28 = fVar36 + fVar28;
                    if ((((*(float *)(iVar5 + 0x118) < fVar34) || (*(float *)(iVar5 + 0x11c) < fVar38)) ||
                        (fVar30 <= *(float *)(iVar5 + 0x118))) || (fVar28 <= *(float *)(iVar5 + 0x11c))) {
                        fVar33 = *(float *)(iVar24 + 0x118);
                        if ((((fVar30 < fVar33) || (fVar30 = fVar34, fVar33 < fVar34)) &&
                            ((fVar33 = fVar33 - fVar30, fVar33 != 0.0 &&
                             ((fVar30 = *(float *)(iVar7 + 0xd4), 0.0 <= fVar33 || (0.0 <= fVar30)))))) &&
                           ((fVar33 <= 0.0 || (fVar30 < *(float *)(iVar7 + 0xdc))))) {
                            fVar34 = *(float *)(iVar24 + 0x12f8);
                            fVar35 = ((float)((uint32_t)fVar33 & 0x7fffffff) - fVar34) / (fVar34 * 5.0 - fVar34);
                            if (0.0 <= fVar35) {
                                fVar31 = 1.0;
                                if (fVar35 <= 1.0) {
                                    fVar31 = fVar35;
                                }
                            } else {
                                fVar31 = 0.0;
                            }
                            if (0.0 <= fVar33) {
                                if (fVar33 <= 0.0) {
                                    fVar33 = 0.0;
                                } else {
                                    fVar33 = 1.0;
                                }
                            } else {
                                fVar33 = -1.0;
                            }
                            fVar34 = (fVar31 * 3.0 + 1.0) * fVar34 * 35.0 * fVar33 * *(float *)(iVar24 + 0x48) +
                                     *(float *)(iVar5 + 0x25a8);
                            *(float *)(iVar5 + 0x25a8) = fVar34;
                            iVar16 = (int32_t)fVar34;
                            if ((fVar34 < 0.0) && ((float)iVar16 != fVar34)) {
                                iVar16 = iVar16 + -1;
                            }
                            fVar34 = (float)iVar16;
                            if (fVar34 != 0.0) {
                                *(undefined4 *)(iVar7 + 0xec) = 0;
                                *(undefined4 *)(iVar7 + 0xf4) = 0;
                                *(float *)(iVar7 + 0xe4) = fVar34 + fVar30;
                                *(float *)(iVar5 + 0x25a8) = *(float *)(iVar5 + 0x25a8) - fVar34;
                            }
                        }
                        fVar30 = *(float *)(iVar24 + 0x11c);
                        if (((((fVar28 < fVar30) || (fVar28 = fVar38, fVar30 < fVar38)) &&
                             (fVar30 = fVar30 - fVar28, fVar30 != 0.0)) &&
                            ((fVar28 = *(float *)(iVar7 + 0xd8), 0.0 <= fVar30 || (0.0 <= fVar28)))) &&
                           ((fVar30 <= 0.0 || (fVar28 < *(float *)(iVar7 + 0xe0))))) {
                            fVar34 = *(float *)(iVar24 + 0x12f8);
                            fVar38 = ((float)((uint32_t)fVar30 & 0x7fffffff) - fVar34) / (fVar34 * 5.0 - fVar34);
                            if (0.0 <= fVar38) {
                                fVar33 = 1.0;
                                if (fVar38 <= 1.0) {
                                    fVar33 = fVar38;
                                }
                            } else {
                                fVar33 = 0.0;
                            }
                            if (0.0 <= fVar30) {
                                if (fVar30 <= 0.0) {
                                    fVar30 = 0.0;
                                } else {
                                    fVar30 = 1.0;
                                }
                            } else {
                                fVar30 = -1.0;
                            }
                            fVar30 = (fVar33 * 3.0 + 1.0) * fVar34 * 35.0 * fVar30 * *(float *)(iVar24 + 0x48) +
                                     *(float *)(iVar5 + 0x25ac);
                            *(float *)(iVar5 + 0x25ac) = fVar30;
                            iVar16 = (int32_t)fVar30;
                            if ((fVar30 < 0.0) && ((float)iVar16 != fVar30)) {
                                iVar16 = iVar16 + -1;
                            }
                            fVar30 = (float)iVar16;
                            if (fVar30 != 0.0) {
                                *(float *)(iVar7 + 0xe8) = fVar28 + fVar30;
                                *(undefined4 *)(iVar7 + 0xf0) = 0;
                                *(undefined4 *)(iVar7 + 0xf8) = 0;
                                *(float *)(iVar5 + 0x25ac) = *(float *)(iVar5 + 0x25ac) - fVar30;
                            }
                        }
                    }
                }
            }
        }
        if (*(char *)((int64_t)puVar6 + 0x51) == '\0') {
            iVar16 = puVar6[1];
            if (iVar16 < 0) {
                iVar16 = (iVar16 + 1 >> 1) + iVar16;
                iVar19 = 0;
                if (0 < iVar16) {
                    iVar19 = iVar16;
                }
                func_0x00018014fa90(puVar6, iVar19);
            }
            *puVar6 = 0;
        }
        cVar13 = func_0x0001801062b0();
        iVar5 = *(int64_t *)0x180781f28;
        if ((((cVar13 != '\0') && (fVar30 = *(float *)(iVar18 + 0x118), *(float *)(iVar17 + 0x278) <= fVar30)) &&
            (fVar28 = *(float *)(iVar18 + 0x11c), *(float *)(iVar17 + 0x27c) <= fVar28)) &&
           ((fVar30 < *(float *)(iVar17 + 0x280) && (fVar28 < *(float *)(iVar17 + 0x284))))) {
            if (((((uint32_t)puVar6[0xd] >> 0xc & 1) == 0) ||
                (((fVar29 <= fVar30 && (fVar32 <= fVar28)) && ((fVar30 < fVar37 && (fVar28 < fVar36)))))) &&
               ((*(int32_t *)(iVar18 + 0x163c) == 0 && (*(int32_t *)(iVar18 + 0x1654) == 0)))) {
                if (((puVar6[0xd] & 0xc0) != 0) &&
                   (((*(char *)(iVar18 + 0x258c) == '\0' && (*(char *)(iVar18 + 0x258d) == '\0')) &&
                    (*(int16_t *)(iVar18 + 0xb5a) == 1)))) {
                    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2588) = puVar6[0x12];
                    *(undefined2 *)(iVar5 + 0x258d) = 0x101;
                    *(undefined *)(iVar5 + 0x258f) = 1;
                    *(undefined2 *)(iVar5 + 0x2594) = *(undefined2 *)(iVar5 + 0x13c);
                    fVar32 = *(float *)(iVar5 + 0x118) - *(float *)(*(int64_t *)(iVar5 + 0x15e0) + 0x168);
                    fVar29 = *(float *)(iVar5 + 0x11c) - *(float *)(*(int64_t *)(iVar5 + 0x15e0) + 0x16c);
                    *(undefined8 *)(iVar5 + 0x25a8) = 0;
                    *(float *)(iVar5 + 0x25a0) = fVar32;
                    *(float *)(iVar5 + 0x25a4) = fVar29;
                    *(float *)(iVar5 + 0x2598) = fVar32;
                    *(float *)(iVar5 + 0x259c) = fVar29;
                    func_0x00018010e050(iVar17, 2);
                    iVar5 = *(int64_t *)0x180781f28;
                    iVar16 = puVar6[0x12];
                    *(int32_t *)(*(int64_t *)0x180781f28 + 0x163c) = iVar16;
                    *(undefined *)(iVar5 + 0x1650) = 0;
                    if ((iVar16 != 0) && (*(int32_t *)(iVar5 + 0x1640) != iVar16)) {
                        *(undefined8 *)(iVar5 + 0x1648) = 0;
                    }
                    if ((puVar6[0xd] & 0x1000) != 0) {
                        var_10ch._4_4_ = *(undefined4 *)(iVar18 + 0x118);
                        var_104h = *(undefined4 *)(iVar18 + 0x11c);
                        var_100h = var_10ch._4_4_;
                        var_fch = var_104h;
                        func_0x00018010e3f0(0, 0, puVar6[0xc], (int64_t)&var_10ch + 4);
                    }
                }
                if ((((puVar6[0xd] & 0x400) != 0) && (cVar13 = fcn.180108070(0), cVar13 != '\0')) &&
                   ((*(float *)(*(int64_t *)0x180781f28 + 0xbfc) <
                     *(float *)(*(int64_t *)0x180781f28 + 0xa4) * *(float *)(*(int64_t *)0x180781f28 + 0xa4) &&
                    (*(int32_t *)(iVar18 + 0x13c) == 0)))) {
                    func_0x000180147c50(puVar6);
                }
            }
        }
        iVar5 = *(int64_t *)0x180781f28;
        if ((puVar6[0xd] & 0x10000) != 0) {
            *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
            if (((*(int64_t *)(iVar5 + 0x21d8) == *(int64_t *)(iVar5 + 0x15e0)) && (*(char *)(iVar5 + 0x2279) != '\0'))
               && (*(int32_t *)(iVar5 + 0x21e4) == *(int32_t *)(*(int64_t *)(iVar5 + 0x15e0) + 0x1b0))) {
                *(uint32_t *)(iVar5 + 0x227c) = *(uint32_t *)(iVar5 + 0x227c) & 0xfffffff4;
                *(uint32_t *)(iVar5 + 0x227c) = *(uint32_t *)(iVar5 + 0x227c) | 4;
            }
        }
        if ((*(int64_t *)(iVar18 + 0x24d0) != 0) && (*(char *)(*(int64_t *)(iVar18 + 0x24d0) + 0x23a) != '\0')) {
            func_0x000180136780();
        }
        fVar29 = (float)puVar6[0x10];
        if ((float)puVar6[0x10] <= *(float *)(iVar17 + 0x170)) {
            fVar29 = *(float *)(iVar17 + 0x170);
        }
        fVar32 = (float)puVar6[0x11];
        if ((float)puVar6[0x11] <= *(float *)(iVar17 + 0x174)) {
            fVar32 = *(float *)(iVar17 + 0x174);
        }
        *(float *)(iVar17 + 0x170) = fVar29;
        *(float *)(iVar17 + 0x174) = fVar32;
        func_0x0001801067d0();
        puVar6[0xc] = 0;
        puVar6[0xd] = 0;
        *(int32_t *)(iVar18 + 0x25f8) = *(int32_t *)(iVar18 + 0x25f8) + -1;
        if (*(int32_t *)(iVar18 + 0x25f8) < 1) {
            iVar17 = 0;
        } else {
            iVar17 = (int64_t)(*(int32_t *)(iVar18 + 0x25f8) + -1) * 0x58 + *(int64_t *)(iVar18 + 0x2608);
        }
        *(int64_t *)(iVar18 + 0x25f0) = iVar17;
        iVar17 = var_138h;
        iVar5 = *(int64_t *)(iVar12 + 0x25f0);
    }
    if (*(char *)(iVar17 + 0x1bb) != '\0') {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644ce0);
        }
        func_0x000180147f30();
    }
    if ((int32_t)*(int16_t *)(arg1 + 4) < *(int32_t *)(iVar17 + 0x1e0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e50);
            }
            iVar7 = *(int64_t *)0x180781f28;
            iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
            *(undefined *)(iVar5 + 0x10b) = 1;
            iVar18 = *(int64_t *)(iVar7 + 0x15e0);
            fVar29 = *(float *)(iVar18 + 0x19c) - *(float *)(iVar7 + 0xe0c);
            *(float *)(iVar18 + 0x19c) = fVar29;
            *(float *)(iVar18 + 0x158) = fVar29 + *(float *)(iVar18 + 0x60) + *(float *)(iVar18 + 0x1a0);
            *(int32_t *)(iVar5 + 0x1e0) = *(int32_t *)(iVar5 + 0x1e0) + -1;
            uVar27 = 1 << ((uint8_t)*(undefined4 *)(iVar5 + 0x1e0) & 0x1f);
            if ((*(uint32_t *)(iVar5 + 0x1e4) & uVar27) != 0) {
                iVar18 = (int64_t)*(int32_t *)(iVar7 + 0x2140);
                iVar17 = *(int64_t *)(iVar7 + 0x2148);
                if ((((*(uint32_t *)(iVar17 + -0x24 + iVar18 * 0x28) & 0x20000) != 0) &&
                    (*(char *)(iVar7 + 0x21cf) != '\0')) &&
                   ((*(int32_t *)(iVar7 + 0x2288) == 0 &&
                    ((((*(int64_t *)(iVar7 + 0x21d8) == iVar5 && (*(char *)(iVar7 + 0x2279) != '\0')) &&
                      (*(int32_t *)(iVar7 + 0x22c8) == 0)) && (*(int32_t *)(iVar7 + 0x2338) == 0)))))) {
                    *(undefined *)(iVar7 + 0x2279) = 0;
                    *(undefined4 *)(iVar7 + 0x1fb8) = *(undefined4 *)(iVar17 + -0x28 + iVar18 * 0x28);
                    *(uint32_t *)(iVar7 + 0x1fbc) = *(uint32_t *)(iVar17 + -0x20 + iVar18 * 0x28) & 0xffdfffff;
                    puVar6 = (undefined4 *)(iVar17 + -0x1c + iVar18 * 0x28);
                    uVar15 = puVar6[1];
                    uVar1 = puVar6[2];
                    uVar2 = puVar6[3];
                    *(undefined4 *)(iVar7 + 0x1fd4) = *puVar6;
                    *(undefined4 *)(iVar7 + 0x1fd8) = uVar15;
                    *(undefined4 *)(iVar7 + 0x1fdc) = uVar1;
                    *(undefined4 *)(iVar7 + 0x1fe0) = uVar2;
                    func_0x00018010ea60(iVar7 + 0x22c0);
                    *(undefined4 *)
                     (*(int64_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x438) + 0x47c +
                     (int64_t)*(int32_t *)(iVar7 + 0x21e4) * 8) = 0x7f7fffff;
                    if ((*(char *)(iVar7 + 0x2279) == '\0') && (*(char *)(iVar7 + 0x223a) == '\0')) {
                        uVar14 = 0;
                    } else {
                        uVar14 = 1;
                    }
                    *(undefined *)(iVar7 + 0x2239) = uVar14;
                }
                fVar29 = *(float *)(iVar17 + -0xc + iVar18 * 0x28);
                if ((fVar29 != 3.402823e+38) && (*(float *)(iVar5 + 700) <= *(float *)(iVar5 + 0x15c))) {
                    iVar24 = *(int64_t *)(iVar7 + 0x15e0);
                    fVar32 = *(float *)(iVar17 + -0x10 + iVar18 * 0x28);
                    fVar37 = *(float *)(iVar17 + -8 + iVar18 * 0x28);
                    if (fVar32 <= *(float *)(iVar24 + 700)) {
                        fVar32 = *(float *)(iVar24 + 700);
                    }
                    if ((*(uint32_t *)(iVar17 + -0x24 + iVar18 * 0x28) & 0x80000) != 0) {
                        fVar36 = *(float *)(iVar24 + 0x15c);
                        fVar30 = fVar36;
                        if ((*(int64_t *)(iVar7 + 0x24d0) != 0) &&
                           (fVar30 = *(float *)(*(int64_t *)(iVar7 + 0x24d0) + 0x80), fVar30 <= fVar36)) {
                            fVar30 = fVar36;
                        }
                        fVar36 = (float)(int32_t)((fVar30 - *(float *)(iVar7 + 0xdf0)) -
                                                 *(float *)(iVar7 + 0x12f8) * 0.5);
                        if (*(float *)(iVar7 + 0xdf0) + *(float *)(iVar7 + 0xe68) + fVar37 < fVar36) {
                            fVar37 = fVar36;
                        }
                    }
                    if (*(float *)(iVar24 + 0x2c4) <= fVar37) {
                        fVar37 = *(float *)(iVar24 + 0x2c4);
                    }
                    if (fVar32 < fVar37) {
                        iVar4 = *(int16_t *)(iVar17 + -4 + iVar18 * 0x28);
                        if ((iVar4 != -1) &&
                           (iVar8 = *(int64_t *)(iVar7 + 0x24d0), (*(uint32_t *)(iVar8 + 4) & 0x100000) == 0)) {
                            iVar23 = *(int64_t *)(iVar8 + 0x18);
                            iVar25 = (int64_t)iVar4 * 0x74;
                            iVar26 = *(int64_t *)(iVar24 + 800);
                            puVar6 = (undefined4 *)(iVar25 + 0x24 + iVar23);
                            uVar9 = puVar6[1];
                            uVar10 = puVar6[2];
                            uVar11 = puVar6[3];
                            uVar15 = *(undefined4 *)(iVar25 + 0x24 + iVar23);
                            uVar1 = *(undefined4 *)(iVar25 + 0x28 + iVar23);
                            uVar2 = *(undefined4 *)(iVar25 + 0x2c + iVar23);
                            uVar3 = *(undefined4 *)(iVar25 + 0x30 + iVar23);
                            *(undefined4 *)(iVar24 + 0x2b8) = *puVar6;
                            *(undefined4 *)(iVar24 + 700) = uVar9;
                            *(undefined4 *)(iVar24 + 0x2c0) = uVar10;
                            *(undefined4 *)(iVar24 + 0x2c4) = uVar11;
                            *(undefined4 *)(iVar26 + 0x60) = uVar15;
                            *(undefined4 *)(iVar26 + 100) = uVar1;
                            *(undefined4 *)(iVar26 + 0x68) = uVar2;
                            *(undefined4 *)(iVar26 + 0x6c) = uVar3;
                            iVar22 = (int64_t)*(int32_t *)(*(int64_t *)(iVar24 + 800) + 0xa0);
                            iVar26 = *(int64_t *)(*(int64_t *)(iVar24 + 800) + 0xa8);
                            *(undefined4 *)(iVar26 + -0x10 + iVar22 * 0x10) = uVar15;
                            *(undefined4 *)(iVar26 + -0xc + iVar22 * 0x10) = uVar1;
                            *(undefined4 *)(iVar26 + -8 + iVar22 * 0x10) = uVar2;
                            *(undefined4 *)(iVar26 + -4 + iVar22 * 0x10) = uVar3;
                            func_0x000180127010(*(undefined8 *)(iVar8 + 0x1a0), *(undefined8 *)(iVar24 + 800), 
                                                *(undefined2 *)(iVar25 + 0x60 + iVar23));
                        }
                        uStack_f8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1230);
                        uStack_f4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1234);
                        uStack_f0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1238);
                        fStack_ec = *(float *)(*(int64_t *)0x180781f28 + 0x123c) *
                                    *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                        fStackX_10 = (float)(int32_t)fVar29;
                        fStackX_14 = fVar37;
                        uStackX_18._0_4_ = fStackX_10;
                        uStackX_18._4_4_ = fVar32;
                        uVar15 = func_0x0001800f5fa0(&uStack_f8);
                        func_0x000180126300(*(undefined8 *)(iVar24 + 800), &uStackX_18, &fStackX_10, uVar15, 
                                            *(undefined4 *)(iVar7 + 0xe64));
                        if (((*(int16_t *)(iVar17 + -4 + iVar18 * 0x28) != -1) &&
                            (iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0),
                            (*(uint32_t *)(iVar17 + 4) & 0x100000) == 0)) && (*(int32_t *)(iVar17 + 0x74) != -1)) {
                            iVar18 = *(int64_t *)(iVar17 + 0x18);
                            iVar24 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
                            iVar26 = (int64_t)*(int32_t *)(iVar17 + 0x74) * 0x74;
                            iVar8 = *(int64_t *)(iVar24 + 800);
                            puVar6 = (undefined4 *)(iVar26 + 0x24 + iVar18);
                            uVar9 = puVar6[1];
                            uVar10 = puVar6[2];
                            uVar11 = puVar6[3];
                            uVar15 = *(undefined4 *)(iVar26 + 0x24 + iVar18);
                            uVar1 = *(undefined4 *)(iVar26 + 0x28 + iVar18);
                            uVar2 = *(undefined4 *)(iVar26 + 0x2c + iVar18);
                            uVar3 = *(undefined4 *)(iVar26 + 0x30 + iVar18);
                            *(undefined4 *)(iVar24 + 0x2b8) = *puVar6;
                            *(undefined4 *)(iVar24 + 700) = uVar9;
                            *(undefined4 *)(iVar24 + 0x2c0) = uVar10;
                            *(undefined4 *)(iVar24 + 0x2c4) = uVar11;
                            *(undefined4 *)(iVar8 + 0x60) = uVar15;
                            *(undefined4 *)(iVar8 + 100) = uVar1;
                            *(undefined4 *)(iVar8 + 0x68) = uVar2;
                            *(undefined4 *)(iVar8 + 0x6c) = uVar3;
                            iVar23 = (int64_t)*(int32_t *)(*(int64_t *)(iVar24 + 800) + 0xa0);
                            iVar8 = *(int64_t *)(*(int64_t *)(iVar24 + 800) + 0xa8);
                            *(undefined4 *)(iVar8 + -0x10 + iVar23 * 0x10) = uVar15;
                            *(undefined4 *)(iVar8 + -0xc + iVar23 * 0x10) = uVar1;
                            *(undefined4 *)(iVar8 + -8 + iVar23 * 0x10) = uVar2;
                            *(undefined4 *)(iVar8 + -4 + iVar23 * 0x10) = uVar3;
                            func_0x000180127010(*(undefined8 *)(iVar17 + 0x1a0), *(undefined8 *)(iVar24 + 800), 
                                                *(undefined2 *)(iVar26 + 0x60 + iVar18));
                        }
                    }
                }
                *(int32_t *)(iVar7 + 0x2140) = *(int32_t *)(iVar7 + 0x2140) + -1;
                uVar27 = ~uVar27;
                *(uint32_t *)(iVar5 + 0x1e4) = *(uint32_t *)(iVar5 + 0x1e4) & uVar27;
                *(uint32_t *)(iVar5 + 0x1e8) = *(uint32_t *)(iVar5 + 0x1e8) & uVar27;
                iVar17 = var_138h;
            }
            iVar16 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
            if (iVar16 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
                }
            } else {
                *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar16 + -1;
            }
        } while ((int32_t)*(int16_t *)(arg1 + 4) < *(int32_t *)(iVar17 + 0x1e0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 0xe) < *(int32_t *)(iVar12 + 0x2110)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e68);
            }
            func_0x00018010c110();
        } while ((int32_t)*(int16_t *)(arg1 + 0xe) < *(int32_t *)(iVar12 + 0x2110));
    }
    if ((int32_t)*(int16_t *)(arg1 + 2) < *(int32_t *)(iVar17 + 0x148)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e80);
            }
            iVar16 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
            if (iVar16 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
                }
            } else {
                *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar16 + -1;
            }
        } while ((int32_t)*(int16_t *)(arg1 + 2) < *(int32_t *)(iVar17 + 0x148));
    }
    if (*(int16_t *)(arg1 + 0x14) < *(int16_t *)(iVar12 + 0x281c)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e90);
            }
            iVar17 = *(int64_t *)0x180781f28;
            if ((*(uint8_t *)(iVar12 + 0x1f78) & 0x40) == 0) {
                *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) = *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) + -1;
                iVar16 = *(int32_t *)(iVar17 + 0x2100);
                *(int32_t *)(iVar17 + 0x2100) = iVar16 + -1;
                *(undefined4 *)(iVar17 + 0x1f78) =
                     *(undefined4 *)(*(int64_t *)(iVar17 + 0x2108) + -8 + (int64_t)iVar16 * 4);
                *(undefined4 *)(iVar17 + 0xd9c) =
                     *(undefined4 *)((int64_t)*(int32_t *)(iVar17 + 0x15b0) * 0x78 + -8 + *(int64_t *)(iVar17 + 0x15b8))
                ;
                *(undefined *)((int64_t)*(int32_t *)(iVar12 + 0x15b0) * 0x78 + -10 + *(int64_t *)(iVar12 + 0x15b8)) = 0;
            } else {
                func_0x000180106130();
            }
        } while (*(int16_t *)(arg1 + 0x14) < *(int16_t *)(iVar12 + 0x281c));
    }
    if ((int32_t)*(int16_t *)(arg1 + 6) < *(int32_t *)(iVar12 + 0x20c0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644df0);
            }
            func_0x0001800f6770(1);
        } while ((int32_t)*(int16_t *)(arg1 + 6) < *(int32_t *)(iVar12 + 0x20c0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 0x10) < *(int32_t *)(iVar12 + 0x2100)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e08);
            }
            iVar17 = *(int64_t *)0x180781f28;
            iVar16 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100);
            if (iVar16 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644628);
                }
            } else {
                *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100) = iVar16 + -1;
                *(undefined4 *)(iVar17 + 0x1f78) =
                     *(undefined4 *)(*(int64_t *)(iVar17 + 0x2108) + -8 + (int64_t)iVar16 * 4);
            }
        } while ((int32_t)*(int16_t *)(arg1 + 0x10) < *(int32_t *)(iVar12 + 0x2100));
    }
    if ((int32_t)*(int16_t *)(arg1 + 8) < *(int32_t *)(iVar12 + 0x20d0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e20);
            }
            func_0x0001800f6a20(1);
        } while ((int32_t)*(int16_t *)(arg1 + 8) < *(int32_t *)(iVar12 + 0x20d0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 10) < *(int32_t *)(iVar12 + 0x20e0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e38);
            }
            iVar17 = *(int64_t *)0x180781f28;
            if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) < 1) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445d0);
                }
            } else {
                func_0x0001801072d0(*(undefined8 *)
                                     (*(int64_t *)(*(int64_t *)0x180781f28 + 0x20e8) + -0x10 +
                                     (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) * 0x10));
                *(int32_t *)(iVar17 + 0x20e0) = *(int32_t *)(iVar17 + 0x20e0) + -1;
            }
        } while ((int32_t)*(int16_t *)(arg1 + 10) < *(int32_t *)(iVar12 + 0x20e0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 0xc) < *(int32_t *)(iVar12 + 0x20f0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644ea8);
            }
            iVar17 = *(int64_t *)0x180781f28;
            iVar16 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x20f0);
            if (*(int16_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x2a78) + 0xc) < iVar16) {
                *(int32_t *)(*(int64_t *)0x180781f28 + 0x20f0) = iVar16 + -1;
                if (iVar16 + -1 == 0) {
                    uVar15 = 0;
                } else {
                    uVar15 = *(undefined4 *)(*(int64_t *)(iVar17 + 0x20f8) + -0x10 + (int64_t)iVar16 * 8);
                }
                *(undefined4 *)(iVar17 + 0x1f74) = uVar15;
            } else if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445a8);
            }
        } while ((int32_t)*(int16_t *)(arg1 + 0xc) < *(int32_t *)(iVar12 + 0x20f0));
    }
    return;
}

// ============================================================
// Function: FUN_18010b1e0
// Address: 0x18010b1e0
// Size: 672 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_158h
// WARNING: Variable defined which should be unmapped: var_150h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Removing arg arg_8ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_94h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_13ch
// WARNING: [rz-ghidra] Detected overlap for variable var_144h
// WARNING: [rz-ghidra] Detected overlap for variable arg_9ch

void fcn.18010a070(int64_t arg1, int64_t arg_80h, int64_t arg_98h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int16_t iVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int64_t iVar12;
    char cVar13;
    undefined uVar14;
    undefined4 uVar15;
    int32_t iVar16;
    int64_t iVar17;
    int64_t iVar18;
    int32_t iVar19;
    int64_t *piVar20;
    int64_t *piVar21;
    int64_t iVar22;
    int64_t iVar23;
    int64_t iVar24;
    int64_t iVar25;
    int64_t iVar26;
    uint32_t uVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    float fVar31;
    float fVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    float fVar36;
    float fVar37;
    float fVar38;
    float fStackX_10;
    float fStackX_14;
    undefined8 uStackX_18;
    float fStackX_20;
    float fStackX_24;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    float var_120h;
    float var_11ch;
    int64_t var_118h;
    float var_110h;
    int64_t var_10ch;
    undefined4 var_104h;
    undefined4 var_100h;
    undefined4 var_fch;
    undefined4 uStack_f8;
    undefined4 uStack_f4;
    undefined4 uStack_f0;
    float fStack_ec;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar12 = *(int64_t *)0x180781f28;
    iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0);
    while ((iVar17 != 0 && (*(int64_t *)(iVar17 + 0x188) == *(int64_t *)(iVar12 + 0x15e0)))) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644dc0);
        }
        func_0x0001801346c0();
        iVar17 = *(int64_t *)(iVar12 + 0x24d0);
    }
    iVar17 = *(int64_t *)(iVar12 + 0x15e0);
    piVar21 = *(int64_t **)(iVar12 + 0x2538);
    var_138h = iVar17;
    while ((piVar21 != (int64_t *)0x0 && (*piVar21 == iVar17))) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644ca8);
        }
        func_0x000180148e50();
        piVar21 = *(int64_t **)(iVar12 + 0x2538);
    }
    iVar5 = *(int64_t *)(iVar12 + 0x25f0);
    while ((iVar5 != 0 && (**(int64_t **)(iVar5 + 0x28) == iVar17))) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644cc0);
        }
        iVar18 = *(int64_t *)0x180781f28;
        puVar6 = *(undefined4 **)(*(int64_t *)0x180781f28 + 0x25f0);
        iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        iVar5 = *(int64_t *)(puVar6 + 10);
        var_130h = iVar17;
        if ((puVar6[0xc] != *(int32_t *)(*(int64_t *)0x180781f28 + 0x1f74)) &&
           (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0)) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180645b48);
        }
        func_0x0001801474f0(&var_118h, puVar6, iVar17);
        fVar36 = (float)var_10ch;
        fVar37 = var_110h;
        fVar32 = var_118h._4_4_;
        fVar29 = (float)var_118h;
        if (*(char *)((int64_t)puVar6 + 0x52) != '\0') {
            if ((*(char *)((int64_t)puVar6 + 0x21) != '\0') ||
               ((*(char *)((int64_t)puVar6 + 0x55) == '\0' && (*(int64_t *)(puVar6 + 4) != -1)))) {
                *(undefined8 *)(iVar5 + 0x18) = 0xffffffffffffffff;
            }
            if ((*(char *)(puVar6 + 0x15) == '\0') && (*(int64_t *)(iVar5 + 0x20) != -1)) {
                *(undefined8 *)(iVar5 + 0x20) = 0xffffffffffffffff;
                *(undefined *)(iVar5 + 0x15) = 0xff;
            }
            iVar5 = *(int64_t *)0x180781f28;
            uVar27 = puVar6[0xd];
            if (((((uVar27 & 0xc0) != 0) && (puVar6[0x12] != 0)) &&
                (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2588) == puVar6[0x12])) &&
               (*(char *)(*(int64_t *)0x180781f28 + 0x258c) != '\0')) {
                iVar7 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
                *(undefined *)(*(int64_t *)0x180781f28 + 0x25b8) = 0;
                iVar24 = *(int64_t *)0x180781f28;
                fVar30 = *(float *)(iVar5 + 0x11c);
                fVar28 = var_118h._4_4_;
                if ((var_118h._4_4_ <= fVar30) && (fVar28 = (float)var_10ch, fVar30 <= (float)var_10ch)) {
                    fVar28 = fVar30;
                }
                fVar30 = *(float *)(iVar5 + 0x118);
                fVar34 = (float)var_118h;
                if (((float)var_118h <= fVar30) && (fVar34 = var_110h, fVar30 <= var_110h)) {
                    fVar34 = fVar30;
                }
                fVar30 = *(float *)(iVar7 + 0x168);
                fVar38 = *(float *)(iVar5 + 0x25e8);
                if ((float)var_10ch <= *(float *)(iVar5 + 0x25e8)) {
                    fVar38 = (float)var_10ch;
                }
                *(float *)(iVar5 + 0x25a4) = fVar28 - *(float *)(iVar7 + 0x16c);
                fVar28 = *(float *)(iVar5 + 0x25e4);
                if (var_110h <= *(float *)(iVar5 + 0x25e4)) {
                    fVar28 = var_110h;
                }
                *(float *)(iVar5 + 0x25a0) = fVar34 - fVar30;
                uStack_f8 = *(undefined4 *)(iVar24 + 0x1090);
                uStack_f4 = *(undefined4 *)(iVar24 + 0x1094);
                uStack_f0 = *(undefined4 *)(iVar24 + 0x1098);
                fVar30 = *(float *)(iVar5 + 0x25dc);
                if (*(float *)(iVar5 + 0x25dc) <= (float)var_118h) {
                    fVar30 = (float)var_118h;
                }
                fVar34 = *(float *)(iVar5 + 0x25e0);
                if (*(float *)(iVar5 + 0x25e0) <= var_118h._4_4_) {
                    fVar34 = var_118h._4_4_;
                }
                fStack_ec = *(float *)(iVar24 + 0x109c) * *(float *)(iVar24 + 0xd9c) * 0.3;
                var_128h._0_4_ = fVar30;
                var_128h._4_4_ = fVar34;
                var_120h = fVar28;
                var_11ch = fVar38;
                uVar15 = func_0x0001800f5fa0(&uStack_f8);
                func_0x000180126550(*(undefined8 *)(iVar7 + 800), &var_128h, &var_120h, uVar15, 0, 0);
                uStack_f8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1270);
                uStack_f4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1274);
                uStack_f0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1278);
                fStack_ec = *(float *)(*(int64_t *)0x180781f28 + 0x127c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                iVar24 = *(int64_t *)0x180781f28;
                fStackX_10 = (float)func_0x0001800f5fa0();
                if (((uint32_t)fStackX_10 & 0xff000000) != 0) {
                    iVar17 = *(int64_t *)(iVar7 + 800);
                    if ((*(uint8_t *)(iVar17 + 0x30) & 1) == 0) {
                        var_148h._0_4_ = fVar28 - 0.49;
                        var_148h._4_4_ = fVar38 - 0.49;
                        piVar21 = &var_148h;
                        piVar20 = &var_140h;
                        var_140h._0_4_ = fVar30 + 0.5;
                        var_140h._4_4_ = fVar34 + 0.5;
                    } else {
                        uStackX_18._0_4_ = fVar28 - 0.5;
                        uStackX_18._4_4_ = fVar38 - 0.5;
                        piVar21 = &uStackX_18;
                        piVar20 = (int64_t *)&fStackX_20;
                        fStackX_20 = fVar30 + 0.5;
                        fStackX_24 = fVar34 + 0.5;
                    }
                    func_0x000180125f20(iVar17, piVar20, piVar21);
                    func_0x0001801248e0(iVar17, *(undefined8 *)(iVar17 + 0x58), *(undefined4 *)(iVar17 + 0x50), 
                                        fStackX_10, 1, 0x3f800000);
                    iVar24 = *(int64_t *)0x180781f28;
                    *(undefined4 *)(iVar17 + 0x50) = 0;
                    iVar17 = var_130h;
                }
                if ((uVar27 & 0x900) == 0x800) {
                    fVar28 = (float)(*(uint32_t *)(iVar5 + 0x12f8) ^ 0x80000000);
                    fVar34 = fVar29 - fVar28;
                    fVar38 = fVar32 - fVar28;
                    fVar30 = fVar37 + fVar28;
                    fVar28 = fVar36 + fVar28;
                    if ((((*(float *)(iVar5 + 0x118) < fVar34) || (*(float *)(iVar5 + 0x11c) < fVar38)) ||
                        (fVar30 <= *(float *)(iVar5 + 0x118))) || (fVar28 <= *(float *)(iVar5 + 0x11c))) {
                        fVar33 = *(float *)(iVar24 + 0x118);
                        if ((((fVar30 < fVar33) || (fVar30 = fVar34, fVar33 < fVar34)) &&
                            ((fVar33 = fVar33 - fVar30, fVar33 != 0.0 &&
                             ((fVar30 = *(float *)(iVar7 + 0xd4), 0.0 <= fVar33 || (0.0 <= fVar30)))))) &&
                           ((fVar33 <= 0.0 || (fVar30 < *(float *)(iVar7 + 0xdc))))) {
                            fVar34 = *(float *)(iVar24 + 0x12f8);
                            fVar35 = ((float)((uint32_t)fVar33 & 0x7fffffff) - fVar34) / (fVar34 * 5.0 - fVar34);
                            if (0.0 <= fVar35) {
                                fVar31 = 1.0;
                                if (fVar35 <= 1.0) {
                                    fVar31 = fVar35;
                                }
                            } else {
                                fVar31 = 0.0;
                            }
                            if (0.0 <= fVar33) {
                                if (fVar33 <= 0.0) {
                                    fVar33 = 0.0;
                                } else {
                                    fVar33 = 1.0;
                                }
                            } else {
                                fVar33 = -1.0;
                            }
                            fVar34 = (fVar31 * 3.0 + 1.0) * fVar34 * 35.0 * fVar33 * *(float *)(iVar24 + 0x48) +
                                     *(float *)(iVar5 + 0x25a8);
                            *(float *)(iVar5 + 0x25a8) = fVar34;
                            iVar16 = (int32_t)fVar34;
                            if ((fVar34 < 0.0) && ((float)iVar16 != fVar34)) {
                                iVar16 = iVar16 + -1;
                            }
                            fVar34 = (float)iVar16;
                            if (fVar34 != 0.0) {
                                *(undefined4 *)(iVar7 + 0xec) = 0;
                                *(undefined4 *)(iVar7 + 0xf4) = 0;
                                *(float *)(iVar7 + 0xe4) = fVar34 + fVar30;
                                *(float *)(iVar5 + 0x25a8) = *(float *)(iVar5 + 0x25a8) - fVar34;
                            }
                        }
                        fVar30 = *(float *)(iVar24 + 0x11c);
                        if (((((fVar28 < fVar30) || (fVar28 = fVar38, fVar30 < fVar38)) &&
                             (fVar30 = fVar30 - fVar28, fVar30 != 0.0)) &&
                            ((fVar28 = *(float *)(iVar7 + 0xd8), 0.0 <= fVar30 || (0.0 <= fVar28)))) &&
                           ((fVar30 <= 0.0 || (fVar28 < *(float *)(iVar7 + 0xe0))))) {
                            fVar34 = *(float *)(iVar24 + 0x12f8);
                            fVar38 = ((float)((uint32_t)fVar30 & 0x7fffffff) - fVar34) / (fVar34 * 5.0 - fVar34);
                            if (0.0 <= fVar38) {
                                fVar33 = 1.0;
                                if (fVar38 <= 1.0) {
                                    fVar33 = fVar38;
                                }
                            } else {
                                fVar33 = 0.0;
                            }
                            if (0.0 <= fVar30) {
                                if (fVar30 <= 0.0) {
                                    fVar30 = 0.0;
                                } else {
                                    fVar30 = 1.0;
                                }
                            } else {
                                fVar30 = -1.0;
                            }
                            fVar30 = (fVar33 * 3.0 + 1.0) * fVar34 * 35.0 * fVar30 * *(float *)(iVar24 + 0x48) +
                                     *(float *)(iVar5 + 0x25ac);
                            *(float *)(iVar5 + 0x25ac) = fVar30;
                            iVar16 = (int32_t)fVar30;
                            if ((fVar30 < 0.0) && ((float)iVar16 != fVar30)) {
                                iVar16 = iVar16 + -1;
                            }
                            fVar30 = (float)iVar16;
                            if (fVar30 != 0.0) {
                                *(float *)(iVar7 + 0xe8) = fVar28 + fVar30;
                                *(undefined4 *)(iVar7 + 0xf0) = 0;
                                *(undefined4 *)(iVar7 + 0xf8) = 0;
                                *(float *)(iVar5 + 0x25ac) = *(float *)(iVar5 + 0x25ac) - fVar30;
                            }
                        }
                    }
                }
            }
        }
        if (*(char *)((int64_t)puVar6 + 0x51) == '\0') {
            iVar16 = puVar6[1];
            if (iVar16 < 0) {
                iVar16 = (iVar16 + 1 >> 1) + iVar16;
                iVar19 = 0;
                if (0 < iVar16) {
                    iVar19 = iVar16;
                }
                func_0x00018014fa90(puVar6, iVar19);
            }
            *puVar6 = 0;
        }
        cVar13 = func_0x0001801062b0();
        iVar5 = *(int64_t *)0x180781f28;
        if ((((cVar13 != '\0') && (fVar30 = *(float *)(iVar18 + 0x118), *(float *)(iVar17 + 0x278) <= fVar30)) &&
            (fVar28 = *(float *)(iVar18 + 0x11c), *(float *)(iVar17 + 0x27c) <= fVar28)) &&
           ((fVar30 < *(float *)(iVar17 + 0x280) && (fVar28 < *(float *)(iVar17 + 0x284))))) {
            if (((((uint32_t)puVar6[0xd] >> 0xc & 1) == 0) ||
                (((fVar29 <= fVar30 && (fVar32 <= fVar28)) && ((fVar30 < fVar37 && (fVar28 < fVar36)))))) &&
               ((*(int32_t *)(iVar18 + 0x163c) == 0 && (*(int32_t *)(iVar18 + 0x1654) == 0)))) {
                if (((puVar6[0xd] & 0xc0) != 0) &&
                   (((*(char *)(iVar18 + 0x258c) == '\0' && (*(char *)(iVar18 + 0x258d) == '\0')) &&
                    (*(int16_t *)(iVar18 + 0xb5a) == 1)))) {
                    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2588) = puVar6[0x12];
                    *(undefined2 *)(iVar5 + 0x258d) = 0x101;
                    *(undefined *)(iVar5 + 0x258f) = 1;
                    *(undefined2 *)(iVar5 + 0x2594) = *(undefined2 *)(iVar5 + 0x13c);
                    fVar32 = *(float *)(iVar5 + 0x118) - *(float *)(*(int64_t *)(iVar5 + 0x15e0) + 0x168);
                    fVar29 = *(float *)(iVar5 + 0x11c) - *(float *)(*(int64_t *)(iVar5 + 0x15e0) + 0x16c);
                    *(undefined8 *)(iVar5 + 0x25a8) = 0;
                    *(float *)(iVar5 + 0x25a0) = fVar32;
                    *(float *)(iVar5 + 0x25a4) = fVar29;
                    *(float *)(iVar5 + 0x2598) = fVar32;
                    *(float *)(iVar5 + 0x259c) = fVar29;
                    func_0x00018010e050(iVar17, 2);
                    iVar5 = *(int64_t *)0x180781f28;
                    iVar16 = puVar6[0x12];
                    *(int32_t *)(*(int64_t *)0x180781f28 + 0x163c) = iVar16;
                    *(undefined *)(iVar5 + 0x1650) = 0;
                    if ((iVar16 != 0) && (*(int32_t *)(iVar5 + 0x1640) != iVar16)) {
                        *(undefined8 *)(iVar5 + 0x1648) = 0;
                    }
                    if ((puVar6[0xd] & 0x1000) != 0) {
                        var_10ch._4_4_ = *(undefined4 *)(iVar18 + 0x118);
                        var_104h = *(undefined4 *)(iVar18 + 0x11c);
                        var_100h = var_10ch._4_4_;
                        var_fch = var_104h;
                        func_0x00018010e3f0(0, 0, puVar6[0xc], (int64_t)&var_10ch + 4);
                    }
                }
                if ((((puVar6[0xd] & 0x400) != 0) && (cVar13 = fcn.180108070(0), cVar13 != '\0')) &&
                   ((*(float *)(*(int64_t *)0x180781f28 + 0xbfc) <
                     *(float *)(*(int64_t *)0x180781f28 + 0xa4) * *(float *)(*(int64_t *)0x180781f28 + 0xa4) &&
                    (*(int32_t *)(iVar18 + 0x13c) == 0)))) {
                    func_0x000180147c50(puVar6);
                }
            }
        }
        iVar5 = *(int64_t *)0x180781f28;
        if ((puVar6[0xd] & 0x10000) != 0) {
            *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
            if (((*(int64_t *)(iVar5 + 0x21d8) == *(int64_t *)(iVar5 + 0x15e0)) && (*(char *)(iVar5 + 0x2279) != '\0'))
               && (*(int32_t *)(iVar5 + 0x21e4) == *(int32_t *)(*(int64_t *)(iVar5 + 0x15e0) + 0x1b0))) {
                *(uint32_t *)(iVar5 + 0x227c) = *(uint32_t *)(iVar5 + 0x227c) & 0xfffffff4;
                *(uint32_t *)(iVar5 + 0x227c) = *(uint32_t *)(iVar5 + 0x227c) | 4;
            }
        }
        if ((*(int64_t *)(iVar18 + 0x24d0) != 0) && (*(char *)(*(int64_t *)(iVar18 + 0x24d0) + 0x23a) != '\0')) {
            func_0x000180136780();
        }
        fVar29 = (float)puVar6[0x10];
        if ((float)puVar6[0x10] <= *(float *)(iVar17 + 0x170)) {
            fVar29 = *(float *)(iVar17 + 0x170);
        }
        fVar32 = (float)puVar6[0x11];
        if ((float)puVar6[0x11] <= *(float *)(iVar17 + 0x174)) {
            fVar32 = *(float *)(iVar17 + 0x174);
        }
        *(float *)(iVar17 + 0x170) = fVar29;
        *(float *)(iVar17 + 0x174) = fVar32;
        func_0x0001801067d0();
        puVar6[0xc] = 0;
        puVar6[0xd] = 0;
        *(int32_t *)(iVar18 + 0x25f8) = *(int32_t *)(iVar18 + 0x25f8) + -1;
        if (*(int32_t *)(iVar18 + 0x25f8) < 1) {
            iVar17 = 0;
        } else {
            iVar17 = (int64_t)(*(int32_t *)(iVar18 + 0x25f8) + -1) * 0x58 + *(int64_t *)(iVar18 + 0x2608);
        }
        *(int64_t *)(iVar18 + 0x25f0) = iVar17;
        iVar17 = var_138h;
        iVar5 = *(int64_t *)(iVar12 + 0x25f0);
    }
    if (*(char *)(iVar17 + 0x1bb) != '\0') {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644ce0);
        }
        func_0x000180147f30();
    }
    if ((int32_t)*(int16_t *)(arg1 + 4) < *(int32_t *)(iVar17 + 0x1e0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e50);
            }
            iVar7 = *(int64_t *)0x180781f28;
            iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
            *(undefined *)(iVar5 + 0x10b) = 1;
            iVar18 = *(int64_t *)(iVar7 + 0x15e0);
            fVar29 = *(float *)(iVar18 + 0x19c) - *(float *)(iVar7 + 0xe0c);
            *(float *)(iVar18 + 0x19c) = fVar29;
            *(float *)(iVar18 + 0x158) = fVar29 + *(float *)(iVar18 + 0x60) + *(float *)(iVar18 + 0x1a0);
            *(int32_t *)(iVar5 + 0x1e0) = *(int32_t *)(iVar5 + 0x1e0) + -1;
            uVar27 = 1 << ((uint8_t)*(undefined4 *)(iVar5 + 0x1e0) & 0x1f);
            if ((*(uint32_t *)(iVar5 + 0x1e4) & uVar27) != 0) {
                iVar18 = (int64_t)*(int32_t *)(iVar7 + 0x2140);
                iVar17 = *(int64_t *)(iVar7 + 0x2148);
                if ((((*(uint32_t *)(iVar17 + -0x24 + iVar18 * 0x28) & 0x20000) != 0) &&
                    (*(char *)(iVar7 + 0x21cf) != '\0')) &&
                   ((*(int32_t *)(iVar7 + 0x2288) == 0 &&
                    ((((*(int64_t *)(iVar7 + 0x21d8) == iVar5 && (*(char *)(iVar7 + 0x2279) != '\0')) &&
                      (*(int32_t *)(iVar7 + 0x22c8) == 0)) && (*(int32_t *)(iVar7 + 0x2338) == 0)))))) {
                    *(undefined *)(iVar7 + 0x2279) = 0;
                    *(undefined4 *)(iVar7 + 0x1fb8) = *(undefined4 *)(iVar17 + -0x28 + iVar18 * 0x28);
                    *(uint32_t *)(iVar7 + 0x1fbc) = *(uint32_t *)(iVar17 + -0x20 + iVar18 * 0x28) & 0xffdfffff;
                    puVar6 = (undefined4 *)(iVar17 + -0x1c + iVar18 * 0x28);
                    uVar15 = puVar6[1];
                    uVar1 = puVar6[2];
                    uVar2 = puVar6[3];
                    *(undefined4 *)(iVar7 + 0x1fd4) = *puVar6;
                    *(undefined4 *)(iVar7 + 0x1fd8) = uVar15;
                    *(undefined4 *)(iVar7 + 0x1fdc) = uVar1;
                    *(undefined4 *)(iVar7 + 0x1fe0) = uVar2;
                    func_0x00018010ea60(iVar7 + 0x22c0);
                    *(undefined4 *)
                     (*(int64_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x438) + 0x47c +
                     (int64_t)*(int32_t *)(iVar7 + 0x21e4) * 8) = 0x7f7fffff;
                    if ((*(char *)(iVar7 + 0x2279) == '\0') && (*(char *)(iVar7 + 0x223a) == '\0')) {
                        uVar14 = 0;
                    } else {
                        uVar14 = 1;
                    }
                    *(undefined *)(iVar7 + 0x2239) = uVar14;
                }
                fVar29 = *(float *)(iVar17 + -0xc + iVar18 * 0x28);
                if ((fVar29 != 3.402823e+38) && (*(float *)(iVar5 + 700) <= *(float *)(iVar5 + 0x15c))) {
                    iVar24 = *(int64_t *)(iVar7 + 0x15e0);
                    fVar32 = *(float *)(iVar17 + -0x10 + iVar18 * 0x28);
                    fVar37 = *(float *)(iVar17 + -8 + iVar18 * 0x28);
                    if (fVar32 <= *(float *)(iVar24 + 700)) {
                        fVar32 = *(float *)(iVar24 + 700);
                    }
                    if ((*(uint32_t *)(iVar17 + -0x24 + iVar18 * 0x28) & 0x80000) != 0) {
                        fVar36 = *(float *)(iVar24 + 0x15c);
                        fVar30 = fVar36;
                        if ((*(int64_t *)(iVar7 + 0x24d0) != 0) &&
                           (fVar30 = *(float *)(*(int64_t *)(iVar7 + 0x24d0) + 0x80), fVar30 <= fVar36)) {
                            fVar30 = fVar36;
                        }
                        fVar36 = (float)(int32_t)((fVar30 - *(float *)(iVar7 + 0xdf0)) -
                                                 *(float *)(iVar7 + 0x12f8) * 0.5);
                        if (*(float *)(iVar7 + 0xdf0) + *(float *)(iVar7 + 0xe68) + fVar37 < fVar36) {
                            fVar37 = fVar36;
                        }
                    }
                    if (*(float *)(iVar24 + 0x2c4) <= fVar37) {
                        fVar37 = *(float *)(iVar24 + 0x2c4);
                    }
                    if (fVar32 < fVar37) {
                        iVar4 = *(int16_t *)(iVar17 + -4 + iVar18 * 0x28);
                        if ((iVar4 != -1) &&
                           (iVar8 = *(int64_t *)(iVar7 + 0x24d0), (*(uint32_t *)(iVar8 + 4) & 0x100000) == 0)) {
                            iVar23 = *(int64_t *)(iVar8 + 0x18);
                            iVar25 = (int64_t)iVar4 * 0x74;
                            iVar26 = *(int64_t *)(iVar24 + 800);
                            puVar6 = (undefined4 *)(iVar25 + 0x24 + iVar23);
                            uVar9 = puVar6[1];
                            uVar10 = puVar6[2];
                            uVar11 = puVar6[3];
                            uVar15 = *(undefined4 *)(iVar25 + 0x24 + iVar23);
                            uVar1 = *(undefined4 *)(iVar25 + 0x28 + iVar23);
                            uVar2 = *(undefined4 *)(iVar25 + 0x2c + iVar23);
                            uVar3 = *(undefined4 *)(iVar25 + 0x30 + iVar23);
                            *(undefined4 *)(iVar24 + 0x2b8) = *puVar6;
                            *(undefined4 *)(iVar24 + 700) = uVar9;
                            *(undefined4 *)(iVar24 + 0x2c0) = uVar10;
                            *(undefined4 *)(iVar24 + 0x2c4) = uVar11;
                            *(undefined4 *)(iVar26 + 0x60) = uVar15;
                            *(undefined4 *)(iVar26 + 100) = uVar1;
                            *(undefined4 *)(iVar26 + 0x68) = uVar2;
                            *(undefined4 *)(iVar26 + 0x6c) = uVar3;
                            iVar22 = (int64_t)*(int32_t *)(*(int64_t *)(iVar24 + 800) + 0xa0);
                            iVar26 = *(int64_t *)(*(int64_t *)(iVar24 + 800) + 0xa8);
                            *(undefined4 *)(iVar26 + -0x10 + iVar22 * 0x10) = uVar15;
                            *(undefined4 *)(iVar26 + -0xc + iVar22 * 0x10) = uVar1;
                            *(undefined4 *)(iVar26 + -8 + iVar22 * 0x10) = uVar2;
                            *(undefined4 *)(iVar26 + -4 + iVar22 * 0x10) = uVar3;
                            func_0x000180127010(*(undefined8 *)(iVar8 + 0x1a0), *(undefined8 *)(iVar24 + 800), 
                                                *(undefined2 *)(iVar25 + 0x60 + iVar23));
                        }
                        uStack_f8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1230);
                        uStack_f4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1234);
                        uStack_f0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1238);
                        fStack_ec = *(float *)(*(int64_t *)0x180781f28 + 0x123c) *
                                    *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                        fStackX_10 = (float)(int32_t)fVar29;
                        fStackX_14 = fVar37;
                        uStackX_18._0_4_ = fStackX_10;
                        uStackX_18._4_4_ = fVar32;
                        uVar15 = func_0x0001800f5fa0(&uStack_f8);
                        func_0x000180126300(*(undefined8 *)(iVar24 + 800), &uStackX_18, &fStackX_10, uVar15, 
                                            *(undefined4 *)(iVar7 + 0xe64));
                        if (((*(int16_t *)(iVar17 + -4 + iVar18 * 0x28) != -1) &&
                            (iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0),
                            (*(uint32_t *)(iVar17 + 4) & 0x100000) == 0)) && (*(int32_t *)(iVar17 + 0x74) != -1)) {
                            iVar18 = *(int64_t *)(iVar17 + 0x18);
                            iVar24 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
                            iVar26 = (int64_t)*(int32_t *)(iVar17 + 0x74) * 0x74;
                            iVar8 = *(int64_t *)(iVar24 + 800);
                            puVar6 = (undefined4 *)(iVar26 + 0x24 + iVar18);
                            uVar9 = puVar6[1];
                            uVar10 = puVar6[2];
                            uVar11 = puVar6[3];
                            uVar15 = *(undefined4 *)(iVar26 + 0x24 + iVar18);
                            uVar1 = *(undefined4 *)(iVar26 + 0x28 + iVar18);
                            uVar2 = *(undefined4 *)(iVar26 + 0x2c + iVar18);
                            uVar3 = *(undefined4 *)(iVar26 + 0x30 + iVar18);
                            *(undefined4 *)(iVar24 + 0x2b8) = *puVar6;
                            *(undefined4 *)(iVar24 + 700) = uVar9;
                            *(undefined4 *)(iVar24 + 0x2c0) = uVar10;
                            *(undefined4 *)(iVar24 + 0x2c4) = uVar11;
                            *(undefined4 *)(iVar8 + 0x60) = uVar15;
                            *(undefined4 *)(iVar8 + 100) = uVar1;
                            *(undefined4 *)(iVar8 + 0x68) = uVar2;
                            *(undefined4 *)(iVar8 + 0x6c) = uVar3;
                            iVar23 = (int64_t)*(int32_t *)(*(int64_t *)(iVar24 + 800) + 0xa0);
                            iVar8 = *(int64_t *)(*(int64_t *)(iVar24 + 800) + 0xa8);
                            *(undefined4 *)(iVar8 + -0x10 + iVar23 * 0x10) = uVar15;
                            *(undefined4 *)(iVar8 + -0xc + iVar23 * 0x10) = uVar1;
                            *(undefined4 *)(iVar8 + -8 + iVar23 * 0x10) = uVar2;
                            *(undefined4 *)(iVar8 + -4 + iVar23 * 0x10) = uVar3;
                            func_0x000180127010(*(undefined8 *)(iVar17 + 0x1a0), *(undefined8 *)(iVar24 + 800), 
                                                *(undefined2 *)(iVar26 + 0x60 + iVar18));
                        }
                    }
                }
                *(int32_t *)(iVar7 + 0x2140) = *(int32_t *)(iVar7 + 0x2140) + -1;
                uVar27 = ~uVar27;
                *(uint32_t *)(iVar5 + 0x1e4) = *(uint32_t *)(iVar5 + 0x1e4) & uVar27;
                *(uint32_t *)(iVar5 + 0x1e8) = *(uint32_t *)(iVar5 + 0x1e8) & uVar27;
                iVar17 = var_138h;
            }
            iVar16 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
            if (iVar16 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
                }
            } else {
                *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar16 + -1;
            }
        } while ((int32_t)*(int16_t *)(arg1 + 4) < *(int32_t *)(iVar17 + 0x1e0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 0xe) < *(int32_t *)(iVar12 + 0x2110)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e68);
            }
            func_0x00018010c110();
        } while ((int32_t)*(int16_t *)(arg1 + 0xe) < *(int32_t *)(iVar12 + 0x2110));
    }
    if ((int32_t)*(int16_t *)(arg1 + 2) < *(int32_t *)(iVar17 + 0x148)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e80);
            }
            iVar16 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
            if (iVar16 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
                }
            } else {
                *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar16 + -1;
            }
        } while ((int32_t)*(int16_t *)(arg1 + 2) < *(int32_t *)(iVar17 + 0x148));
    }
    if (*(int16_t *)(arg1 + 0x14) < *(int16_t *)(iVar12 + 0x281c)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e90);
            }
            iVar17 = *(int64_t *)0x180781f28;
            if ((*(uint8_t *)(iVar12 + 0x1f78) & 0x40) == 0) {
                *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) = *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) + -1;
                iVar16 = *(int32_t *)(iVar17 + 0x2100);
                *(int32_t *)(iVar17 + 0x2100) = iVar16 + -1;
                *(undefined4 *)(iVar17 + 0x1f78) =
                     *(undefined4 *)(*(int64_t *)(iVar17 + 0x2108) + -8 + (int64_t)iVar16 * 4);
                *(undefined4 *)(iVar17 + 0xd9c) =
                     *(undefined4 *)((int64_t)*(int32_t *)(iVar17 + 0x15b0) * 0x78 + -8 + *(int64_t *)(iVar17 + 0x15b8))
                ;
                *(undefined *)((int64_t)*(int32_t *)(iVar12 + 0x15b0) * 0x78 + -10 + *(int64_t *)(iVar12 + 0x15b8)) = 0;
            } else {
                func_0x000180106130();
            }
        } while (*(int16_t *)(arg1 + 0x14) < *(int16_t *)(iVar12 + 0x281c));
    }
    if ((int32_t)*(int16_t *)(arg1 + 6) < *(int32_t *)(iVar12 + 0x20c0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644df0);
            }
            func_0x0001800f6770(1);
        } while ((int32_t)*(int16_t *)(arg1 + 6) < *(int32_t *)(iVar12 + 0x20c0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 0x10) < *(int32_t *)(iVar12 + 0x2100)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e08);
            }
            iVar17 = *(int64_t *)0x180781f28;
            iVar16 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100);
            if (iVar16 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644628);
                }
            } else {
                *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100) = iVar16 + -1;
                *(undefined4 *)(iVar17 + 0x1f78) =
                     *(undefined4 *)(*(int64_t *)(iVar17 + 0x2108) + -8 + (int64_t)iVar16 * 4);
            }
        } while ((int32_t)*(int16_t *)(arg1 + 0x10) < *(int32_t *)(iVar12 + 0x2100));
    }
    if ((int32_t)*(int16_t *)(arg1 + 8) < *(int32_t *)(iVar12 + 0x20d0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e20);
            }
            func_0x0001800f6a20(1);
        } while ((int32_t)*(int16_t *)(arg1 + 8) < *(int32_t *)(iVar12 + 0x20d0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 10) < *(int32_t *)(iVar12 + 0x20e0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e38);
            }
            iVar17 = *(int64_t *)0x180781f28;
            if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) < 1) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445d0);
                }
            } else {
                func_0x0001801072d0(*(undefined8 *)
                                     (*(int64_t *)(*(int64_t *)0x180781f28 + 0x20e8) + -0x10 +
                                     (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) * 0x10));
                *(int32_t *)(iVar17 + 0x20e0) = *(int32_t *)(iVar17 + 0x20e0) + -1;
            }
        } while ((int32_t)*(int16_t *)(arg1 + 10) < *(int32_t *)(iVar12 + 0x20e0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 0xc) < *(int32_t *)(iVar12 + 0x20f0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644ea8);
            }
            iVar17 = *(int64_t *)0x180781f28;
            iVar16 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x20f0);
            if (*(int16_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x2a78) + 0xc) < iVar16) {
                *(int32_t *)(*(int64_t *)0x180781f28 + 0x20f0) = iVar16 + -1;
                if (iVar16 + -1 == 0) {
                    uVar15 = 0;
                } else {
                    uVar15 = *(undefined4 *)(*(int64_t *)(iVar17 + 0x20f8) + -0x10 + (int64_t)iVar16 * 8);
                }
                *(undefined4 *)(iVar17 + 0x1f74) = uVar15;
            } else if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445a8);
            }
        } while ((int32_t)*(int16_t *)(arg1 + 0xc) < *(int32_t *)(iVar12 + 0x20f0));
    }
    return;
}

// ============================================================
// Function: FUN_18010b480
// Address: 0x18010b480
// Size: 162 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_158h
// WARNING: Variable defined which should be unmapped: var_150h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Removing arg arg_8ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_94h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_13ch
// WARNING: [rz-ghidra] Detected overlap for variable var_144h
// WARNING: [rz-ghidra] Detected overlap for variable arg_9ch

void fcn.18010a070(int64_t arg1, int64_t arg_80h, int64_t arg_98h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int16_t iVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int64_t iVar12;
    char cVar13;
    undefined uVar14;
    undefined4 uVar15;
    int32_t iVar16;
    int64_t iVar17;
    int64_t iVar18;
    int32_t iVar19;
    int64_t *piVar20;
    int64_t *piVar21;
    int64_t iVar22;
    int64_t iVar23;
    int64_t iVar24;
    int64_t iVar25;
    int64_t iVar26;
    uint32_t uVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    float fVar31;
    float fVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    float fVar36;
    float fVar37;
    float fVar38;
    float fStackX_10;
    float fStackX_14;
    undefined8 uStackX_18;
    float fStackX_20;
    float fStackX_24;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    float var_120h;
    float var_11ch;
    int64_t var_118h;
    float var_110h;
    int64_t var_10ch;
    undefined4 var_104h;
    undefined4 var_100h;
    undefined4 var_fch;
    undefined4 uStack_f8;
    undefined4 uStack_f4;
    undefined4 uStack_f0;
    float fStack_ec;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar12 = *(int64_t *)0x180781f28;
    iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0);
    while ((iVar17 != 0 && (*(int64_t *)(iVar17 + 0x188) == *(int64_t *)(iVar12 + 0x15e0)))) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644dc0);
        }
        func_0x0001801346c0();
        iVar17 = *(int64_t *)(iVar12 + 0x24d0);
    }
    iVar17 = *(int64_t *)(iVar12 + 0x15e0);
    piVar21 = *(int64_t **)(iVar12 + 0x2538);
    var_138h = iVar17;
    while ((piVar21 != (int64_t *)0x0 && (*piVar21 == iVar17))) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644ca8);
        }
        func_0x000180148e50();
        piVar21 = *(int64_t **)(iVar12 + 0x2538);
    }
    iVar5 = *(int64_t *)(iVar12 + 0x25f0);
    while ((iVar5 != 0 && (**(int64_t **)(iVar5 + 0x28) == iVar17))) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644cc0);
        }
        iVar18 = *(int64_t *)0x180781f28;
        puVar6 = *(undefined4 **)(*(int64_t *)0x180781f28 + 0x25f0);
        iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        iVar5 = *(int64_t *)(puVar6 + 10);
        var_130h = iVar17;
        if ((puVar6[0xc] != *(int32_t *)(*(int64_t *)0x180781f28 + 0x1f74)) &&
           (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0)) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180645b48);
        }
        func_0x0001801474f0(&var_118h, puVar6, iVar17);
        fVar36 = (float)var_10ch;
        fVar37 = var_110h;
        fVar32 = var_118h._4_4_;
        fVar29 = (float)var_118h;
        if (*(char *)((int64_t)puVar6 + 0x52) != '\0') {
            if ((*(char *)((int64_t)puVar6 + 0x21) != '\0') ||
               ((*(char *)((int64_t)puVar6 + 0x55) == '\0' && (*(int64_t *)(puVar6 + 4) != -1)))) {
                *(undefined8 *)(iVar5 + 0x18) = 0xffffffffffffffff;
            }
            if ((*(char *)(puVar6 + 0x15) == '\0') && (*(int64_t *)(iVar5 + 0x20) != -1)) {
                *(undefined8 *)(iVar5 + 0x20) = 0xffffffffffffffff;
                *(undefined *)(iVar5 + 0x15) = 0xff;
            }
            iVar5 = *(int64_t *)0x180781f28;
            uVar27 = puVar6[0xd];
            if (((((uVar27 & 0xc0) != 0) && (puVar6[0x12] != 0)) &&
                (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2588) == puVar6[0x12])) &&
               (*(char *)(*(int64_t *)0x180781f28 + 0x258c) != '\0')) {
                iVar7 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
                *(undefined *)(*(int64_t *)0x180781f28 + 0x25b8) = 0;
                iVar24 = *(int64_t *)0x180781f28;
                fVar30 = *(float *)(iVar5 + 0x11c);
                fVar28 = var_118h._4_4_;
                if ((var_118h._4_4_ <= fVar30) && (fVar28 = (float)var_10ch, fVar30 <= (float)var_10ch)) {
                    fVar28 = fVar30;
                }
                fVar30 = *(float *)(iVar5 + 0x118);
                fVar34 = (float)var_118h;
                if (((float)var_118h <= fVar30) && (fVar34 = var_110h, fVar30 <= var_110h)) {
                    fVar34 = fVar30;
                }
                fVar30 = *(float *)(iVar7 + 0x168);
                fVar38 = *(float *)(iVar5 + 0x25e8);
                if ((float)var_10ch <= *(float *)(iVar5 + 0x25e8)) {
                    fVar38 = (float)var_10ch;
                }
                *(float *)(iVar5 + 0x25a4) = fVar28 - *(float *)(iVar7 + 0x16c);
                fVar28 = *(float *)(iVar5 + 0x25e4);
                if (var_110h <= *(float *)(iVar5 + 0x25e4)) {
                    fVar28 = var_110h;
                }
                *(float *)(iVar5 + 0x25a0) = fVar34 - fVar30;
                uStack_f8 = *(undefined4 *)(iVar24 + 0x1090);
                uStack_f4 = *(undefined4 *)(iVar24 + 0x1094);
                uStack_f0 = *(undefined4 *)(iVar24 + 0x1098);
                fVar30 = *(float *)(iVar5 + 0x25dc);
                if (*(float *)(iVar5 + 0x25dc) <= (float)var_118h) {
                    fVar30 = (float)var_118h;
                }
                fVar34 = *(float *)(iVar5 + 0x25e0);
                if (*(float *)(iVar5 + 0x25e0) <= var_118h._4_4_) {
                    fVar34 = var_118h._4_4_;
                }
                fStack_ec = *(float *)(iVar24 + 0x109c) * *(float *)(iVar24 + 0xd9c) * 0.3;
                var_128h._0_4_ = fVar30;
                var_128h._4_4_ = fVar34;
                var_120h = fVar28;
                var_11ch = fVar38;
                uVar15 = func_0x0001800f5fa0(&uStack_f8);
                func_0x000180126550(*(undefined8 *)(iVar7 + 800), &var_128h, &var_120h, uVar15, 0, 0);
                uStack_f8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1270);
                uStack_f4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1274);
                uStack_f0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1278);
                fStack_ec = *(float *)(*(int64_t *)0x180781f28 + 0x127c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                iVar24 = *(int64_t *)0x180781f28;
                fStackX_10 = (float)func_0x0001800f5fa0();
                if (((uint32_t)fStackX_10 & 0xff000000) != 0) {
                    iVar17 = *(int64_t *)(iVar7 + 800);
                    if ((*(uint8_t *)(iVar17 + 0x30) & 1) == 0) {
                        var_148h._0_4_ = fVar28 - 0.49;
                        var_148h._4_4_ = fVar38 - 0.49;
                        piVar21 = &var_148h;
                        piVar20 = &var_140h;
                        var_140h._0_4_ = fVar30 + 0.5;
                        var_140h._4_4_ = fVar34 + 0.5;
                    } else {
                        uStackX_18._0_4_ = fVar28 - 0.5;
                        uStackX_18._4_4_ = fVar38 - 0.5;
                        piVar21 = &uStackX_18;
                        piVar20 = (int64_t *)&fStackX_20;
                        fStackX_20 = fVar30 + 0.5;
                        fStackX_24 = fVar34 + 0.5;
                    }
                    func_0x000180125f20(iVar17, piVar20, piVar21);
                    func_0x0001801248e0(iVar17, *(undefined8 *)(iVar17 + 0x58), *(undefined4 *)(iVar17 + 0x50), 
                                        fStackX_10, 1, 0x3f800000);
                    iVar24 = *(int64_t *)0x180781f28;
                    *(undefined4 *)(iVar17 + 0x50) = 0;
                    iVar17 = var_130h;
                }
                if ((uVar27 & 0x900) == 0x800) {
                    fVar28 = (float)(*(uint32_t *)(iVar5 + 0x12f8) ^ 0x80000000);
                    fVar34 = fVar29 - fVar28;
                    fVar38 = fVar32 - fVar28;
                    fVar30 = fVar37 + fVar28;
                    fVar28 = fVar36 + fVar28;
                    if ((((*(float *)(iVar5 + 0x118) < fVar34) || (*(float *)(iVar5 + 0x11c) < fVar38)) ||
                        (fVar30 <= *(float *)(iVar5 + 0x118))) || (fVar28 <= *(float *)(iVar5 + 0x11c))) {
                        fVar33 = *(float *)(iVar24 + 0x118);
                        if ((((fVar30 < fVar33) || (fVar30 = fVar34, fVar33 < fVar34)) &&
                            ((fVar33 = fVar33 - fVar30, fVar33 != 0.0 &&
                             ((fVar30 = *(float *)(iVar7 + 0xd4), 0.0 <= fVar33 || (0.0 <= fVar30)))))) &&
                           ((fVar33 <= 0.0 || (fVar30 < *(float *)(iVar7 + 0xdc))))) {
                            fVar34 = *(float *)(iVar24 + 0x12f8);
                            fVar35 = ((float)((uint32_t)fVar33 & 0x7fffffff) - fVar34) / (fVar34 * 5.0 - fVar34);
                            if (0.0 <= fVar35) {
                                fVar31 = 1.0;
                                if (fVar35 <= 1.0) {
                                    fVar31 = fVar35;
                                }
                            } else {
                                fVar31 = 0.0;
                            }
                            if (0.0 <= fVar33) {
                                if (fVar33 <= 0.0) {
                                    fVar33 = 0.0;
                                } else {
                                    fVar33 = 1.0;
                                }
                            } else {
                                fVar33 = -1.0;
                            }
                            fVar34 = (fVar31 * 3.0 + 1.0) * fVar34 * 35.0 * fVar33 * *(float *)(iVar24 + 0x48) +
                                     *(float *)(iVar5 + 0x25a8);
                            *(float *)(iVar5 + 0x25a8) = fVar34;
                            iVar16 = (int32_t)fVar34;
                            if ((fVar34 < 0.0) && ((float)iVar16 != fVar34)) {
                                iVar16 = iVar16 + -1;
                            }
                            fVar34 = (float)iVar16;
                            if (fVar34 != 0.0) {
                                *(undefined4 *)(iVar7 + 0xec) = 0;
                                *(undefined4 *)(iVar7 + 0xf4) = 0;
                                *(float *)(iVar7 + 0xe4) = fVar34 + fVar30;
                                *(float *)(iVar5 + 0x25a8) = *(float *)(iVar5 + 0x25a8) - fVar34;
                            }
                        }
                        fVar30 = *(float *)(iVar24 + 0x11c);
                        if (((((fVar28 < fVar30) || (fVar28 = fVar38, fVar30 < fVar38)) &&
                             (fVar30 = fVar30 - fVar28, fVar30 != 0.0)) &&
                            ((fVar28 = *(float *)(iVar7 + 0xd8), 0.0 <= fVar30 || (0.0 <= fVar28)))) &&
                           ((fVar30 <= 0.0 || (fVar28 < *(float *)(iVar7 + 0xe0))))) {
                            fVar34 = *(float *)(iVar24 + 0x12f8);
                            fVar38 = ((float)((uint32_t)fVar30 & 0x7fffffff) - fVar34) / (fVar34 * 5.0 - fVar34);
                            if (0.0 <= fVar38) {
                                fVar33 = 1.0;
                                if (fVar38 <= 1.0) {
                                    fVar33 = fVar38;
                                }
                            } else {
                                fVar33 = 0.0;
                            }
                            if (0.0 <= fVar30) {
                                if (fVar30 <= 0.0) {
                                    fVar30 = 0.0;
                                } else {
                                    fVar30 = 1.0;
                                }
                            } else {
                                fVar30 = -1.0;
                            }
                            fVar30 = (fVar33 * 3.0 + 1.0) * fVar34 * 35.0 * fVar30 * *(float *)(iVar24 + 0x48) +
                                     *(float *)(iVar5 + 0x25ac);
                            *(float *)(iVar5 + 0x25ac) = fVar30;
                            iVar16 = (int32_t)fVar30;
                            if ((fVar30 < 0.0) && ((float)iVar16 != fVar30)) {
                                iVar16 = iVar16 + -1;
                            }
                            fVar30 = (float)iVar16;
                            if (fVar30 != 0.0) {
                                *(float *)(iVar7 + 0xe8) = fVar28 + fVar30;
                                *(undefined4 *)(iVar7 + 0xf0) = 0;
                                *(undefined4 *)(iVar7 + 0xf8) = 0;
                                *(float *)(iVar5 + 0x25ac) = *(float *)(iVar5 + 0x25ac) - fVar30;
                            }
                        }
                    }
                }
            }
        }
        if (*(char *)((int64_t)puVar6 + 0x51) == '\0') {
            iVar16 = puVar6[1];
            if (iVar16 < 0) {
                iVar16 = (iVar16 + 1 >> 1) + iVar16;
                iVar19 = 0;
                if (0 < iVar16) {
                    iVar19 = iVar16;
                }
                func_0x00018014fa90(puVar6, iVar19);
            }
            *puVar6 = 0;
        }
        cVar13 = func_0x0001801062b0();
        iVar5 = *(int64_t *)0x180781f28;
        if ((((cVar13 != '\0') && (fVar30 = *(float *)(iVar18 + 0x118), *(float *)(iVar17 + 0x278) <= fVar30)) &&
            (fVar28 = *(float *)(iVar18 + 0x11c), *(float *)(iVar17 + 0x27c) <= fVar28)) &&
           ((fVar30 < *(float *)(iVar17 + 0x280) && (fVar28 < *(float *)(iVar17 + 0x284))))) {
            if (((((uint32_t)puVar6[0xd] >> 0xc & 1) == 0) ||
                (((fVar29 <= fVar30 && (fVar32 <= fVar28)) && ((fVar30 < fVar37 && (fVar28 < fVar36)))))) &&
               ((*(int32_t *)(iVar18 + 0x163c) == 0 && (*(int32_t *)(iVar18 + 0x1654) == 0)))) {
                if (((puVar6[0xd] & 0xc0) != 0) &&
                   (((*(char *)(iVar18 + 0x258c) == '\0' && (*(char *)(iVar18 + 0x258d) == '\0')) &&
                    (*(int16_t *)(iVar18 + 0xb5a) == 1)))) {
                    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2588) = puVar6[0x12];
                    *(undefined2 *)(iVar5 + 0x258d) = 0x101;
                    *(undefined *)(iVar5 + 0x258f) = 1;
                    *(undefined2 *)(iVar5 + 0x2594) = *(undefined2 *)(iVar5 + 0x13c);
                    fVar32 = *(float *)(iVar5 + 0x118) - *(float *)(*(int64_t *)(iVar5 + 0x15e0) + 0x168);
                    fVar29 = *(float *)(iVar5 + 0x11c) - *(float *)(*(int64_t *)(iVar5 + 0x15e0) + 0x16c);
                    *(undefined8 *)(iVar5 + 0x25a8) = 0;
                    *(float *)(iVar5 + 0x25a0) = fVar32;
                    *(float *)(iVar5 + 0x25a4) = fVar29;
                    *(float *)(iVar5 + 0x2598) = fVar32;
                    *(float *)(iVar5 + 0x259c) = fVar29;
                    func_0x00018010e050(iVar17, 2);
                    iVar5 = *(int64_t *)0x180781f28;
                    iVar16 = puVar6[0x12];
                    *(int32_t *)(*(int64_t *)0x180781f28 + 0x163c) = iVar16;
                    *(undefined *)(iVar5 + 0x1650) = 0;
                    if ((iVar16 != 0) && (*(int32_t *)(iVar5 + 0x1640) != iVar16)) {
                        *(undefined8 *)(iVar5 + 0x1648) = 0;
                    }
                    if ((puVar6[0xd] & 0x1000) != 0) {
                        var_10ch._4_4_ = *(undefined4 *)(iVar18 + 0x118);
                        var_104h = *(undefined4 *)(iVar18 + 0x11c);
                        var_100h = var_10ch._4_4_;
                        var_fch = var_104h;
                        func_0x00018010e3f0(0, 0, puVar6[0xc], (int64_t)&var_10ch + 4);
                    }
                }
                if ((((puVar6[0xd] & 0x400) != 0) && (cVar13 = fcn.180108070(0), cVar13 != '\0')) &&
                   ((*(float *)(*(int64_t *)0x180781f28 + 0xbfc) <
                     *(float *)(*(int64_t *)0x180781f28 + 0xa4) * *(float *)(*(int64_t *)0x180781f28 + 0xa4) &&
                    (*(int32_t *)(iVar18 + 0x13c) == 0)))) {
                    func_0x000180147c50(puVar6);
                }
            }
        }
        iVar5 = *(int64_t *)0x180781f28;
        if ((puVar6[0xd] & 0x10000) != 0) {
            *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
            if (((*(int64_t *)(iVar5 + 0x21d8) == *(int64_t *)(iVar5 + 0x15e0)) && (*(char *)(iVar5 + 0x2279) != '\0'))
               && (*(int32_t *)(iVar5 + 0x21e4) == *(int32_t *)(*(int64_t *)(iVar5 + 0x15e0) + 0x1b0))) {
                *(uint32_t *)(iVar5 + 0x227c) = *(uint32_t *)(iVar5 + 0x227c) & 0xfffffff4;
                *(uint32_t *)(iVar5 + 0x227c) = *(uint32_t *)(iVar5 + 0x227c) | 4;
            }
        }
        if ((*(int64_t *)(iVar18 + 0x24d0) != 0) && (*(char *)(*(int64_t *)(iVar18 + 0x24d0) + 0x23a) != '\0')) {
            func_0x000180136780();
        }
        fVar29 = (float)puVar6[0x10];
        if ((float)puVar6[0x10] <= *(float *)(iVar17 + 0x170)) {
            fVar29 = *(float *)(iVar17 + 0x170);
        }
        fVar32 = (float)puVar6[0x11];
        if ((float)puVar6[0x11] <= *(float *)(iVar17 + 0x174)) {
            fVar32 = *(float *)(iVar17 + 0x174);
        }
        *(float *)(iVar17 + 0x170) = fVar29;
        *(float *)(iVar17 + 0x174) = fVar32;
        func_0x0001801067d0();
        puVar6[0xc] = 0;
        puVar6[0xd] = 0;
        *(int32_t *)(iVar18 + 0x25f8) = *(int32_t *)(iVar18 + 0x25f8) + -1;
        if (*(int32_t *)(iVar18 + 0x25f8) < 1) {
            iVar17 = 0;
        } else {
            iVar17 = (int64_t)(*(int32_t *)(iVar18 + 0x25f8) + -1) * 0x58 + *(int64_t *)(iVar18 + 0x2608);
        }
        *(int64_t *)(iVar18 + 0x25f0) = iVar17;
        iVar17 = var_138h;
        iVar5 = *(int64_t *)(iVar12 + 0x25f0);
    }
    if (*(char *)(iVar17 + 0x1bb) != '\0') {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644ce0);
        }
        func_0x000180147f30();
    }
    if ((int32_t)*(int16_t *)(arg1 + 4) < *(int32_t *)(iVar17 + 0x1e0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e50);
            }
            iVar7 = *(int64_t *)0x180781f28;
            iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
            *(undefined *)(iVar5 + 0x10b) = 1;
            iVar18 = *(int64_t *)(iVar7 + 0x15e0);
            fVar29 = *(float *)(iVar18 + 0x19c) - *(float *)(iVar7 + 0xe0c);
            *(float *)(iVar18 + 0x19c) = fVar29;
            *(float *)(iVar18 + 0x158) = fVar29 + *(float *)(iVar18 + 0x60) + *(float *)(iVar18 + 0x1a0);
            *(int32_t *)(iVar5 + 0x1e0) = *(int32_t *)(iVar5 + 0x1e0) + -1;
            uVar27 = 1 << ((uint8_t)*(undefined4 *)(iVar5 + 0x1e0) & 0x1f);
            if ((*(uint32_t *)(iVar5 + 0x1e4) & uVar27) != 0) {
                iVar18 = (int64_t)*(int32_t *)(iVar7 + 0x2140);
                iVar17 = *(int64_t *)(iVar7 + 0x2148);
                if ((((*(uint32_t *)(iVar17 + -0x24 + iVar18 * 0x28) & 0x20000) != 0) &&
                    (*(char *)(iVar7 + 0x21cf) != '\0')) &&
                   ((*(int32_t *)(iVar7 + 0x2288) == 0 &&
                    ((((*(int64_t *)(iVar7 + 0x21d8) == iVar5 && (*(char *)(iVar7 + 0x2279) != '\0')) &&
                      (*(int32_t *)(iVar7 + 0x22c8) == 0)) && (*(int32_t *)(iVar7 + 0x2338) == 0)))))) {
                    *(undefined *)(iVar7 + 0x2279) = 0;
                    *(undefined4 *)(iVar7 + 0x1fb8) = *(undefined4 *)(iVar17 + -0x28 + iVar18 * 0x28);
                    *(uint32_t *)(iVar7 + 0x1fbc) = *(uint32_t *)(iVar17 + -0x20 + iVar18 * 0x28) & 0xffdfffff;
                    puVar6 = (undefined4 *)(iVar17 + -0x1c + iVar18 * 0x28);
                    uVar15 = puVar6[1];
                    uVar1 = puVar6[2];
                    uVar2 = puVar6[3];
                    *(undefined4 *)(iVar7 + 0x1fd4) = *puVar6;
                    *(undefined4 *)(iVar7 + 0x1fd8) = uVar15;
                    *(undefined4 *)(iVar7 + 0x1fdc) = uVar1;
                    *(undefined4 *)(iVar7 + 0x1fe0) = uVar2;
                    func_0x00018010ea60(iVar7 + 0x22c0);
                    *(undefined4 *)
                     (*(int64_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x438) + 0x47c +
                     (int64_t)*(int32_t *)(iVar7 + 0x21e4) * 8) = 0x7f7fffff;
                    if ((*(char *)(iVar7 + 0x2279) == '\0') && (*(char *)(iVar7 + 0x223a) == '\0')) {
                        uVar14 = 0;
                    } else {
                        uVar14 = 1;
                    }
                    *(undefined *)(iVar7 + 0x2239) = uVar14;
                }
                fVar29 = *(float *)(iVar17 + -0xc + iVar18 * 0x28);
                if ((fVar29 != 3.402823e+38) && (*(float *)(iVar5 + 700) <= *(float *)(iVar5 + 0x15c))) {
                    iVar24 = *(int64_t *)(iVar7 + 0x15e0);
                    fVar32 = *(float *)(iVar17 + -0x10 + iVar18 * 0x28);
                    fVar37 = *(float *)(iVar17 + -8 + iVar18 * 0x28);
                    if (fVar32 <= *(float *)(iVar24 + 700)) {
                        fVar32 = *(float *)(iVar24 + 700);
                    }
                    if ((*(uint32_t *)(iVar17 + -0x24 + iVar18 * 0x28) & 0x80000) != 0) {
                        fVar36 = *(float *)(iVar24 + 0x15c);
                        fVar30 = fVar36;
                        if ((*(int64_t *)(iVar7 + 0x24d0) != 0) &&
                           (fVar30 = *(float *)(*(int64_t *)(iVar7 + 0x24d0) + 0x80), fVar30 <= fVar36)) {
                            fVar30 = fVar36;
                        }
                        fVar36 = (float)(int32_t)((fVar30 - *(float *)(iVar7 + 0xdf0)) -
                                                 *(float *)(iVar7 + 0x12f8) * 0.5);
                        if (*(float *)(iVar7 + 0xdf0) + *(float *)(iVar7 + 0xe68) + fVar37 < fVar36) {
                            fVar37 = fVar36;
                        }
                    }
                    if (*(float *)(iVar24 + 0x2c4) <= fVar37) {
                        fVar37 = *(float *)(iVar24 + 0x2c4);
                    }
                    if (fVar32 < fVar37) {
                        iVar4 = *(int16_t *)(iVar17 + -4 + iVar18 * 0x28);
                        if ((iVar4 != -1) &&
                           (iVar8 = *(int64_t *)(iVar7 + 0x24d0), (*(uint32_t *)(iVar8 + 4) & 0x100000) == 0)) {
                            iVar23 = *(int64_t *)(iVar8 + 0x18);
                            iVar25 = (int64_t)iVar4 * 0x74;
                            iVar26 = *(int64_t *)(iVar24 + 800);
                            puVar6 = (undefined4 *)(iVar25 + 0x24 + iVar23);
                            uVar9 = puVar6[1];
                            uVar10 = puVar6[2];
                            uVar11 = puVar6[3];
                            uVar15 = *(undefined4 *)(iVar25 + 0x24 + iVar23);
                            uVar1 = *(undefined4 *)(iVar25 + 0x28 + iVar23);
                            uVar2 = *(undefined4 *)(iVar25 + 0x2c + iVar23);
                            uVar3 = *(undefined4 *)(iVar25 + 0x30 + iVar23);
                            *(undefined4 *)(iVar24 + 0x2b8) = *puVar6;
                            *(undefined4 *)(iVar24 + 700) = uVar9;
                            *(undefined4 *)(iVar24 + 0x2c0) = uVar10;
                            *(undefined4 *)(iVar24 + 0x2c4) = uVar11;
                            *(undefined4 *)(iVar26 + 0x60) = uVar15;
                            *(undefined4 *)(iVar26 + 100) = uVar1;
                            *(undefined4 *)(iVar26 + 0x68) = uVar2;
                            *(undefined4 *)(iVar26 + 0x6c) = uVar3;
                            iVar22 = (int64_t)*(int32_t *)(*(int64_t *)(iVar24 + 800) + 0xa0);
                            iVar26 = *(int64_t *)(*(int64_t *)(iVar24 + 800) + 0xa8);
                            *(undefined4 *)(iVar26 + -0x10 + iVar22 * 0x10) = uVar15;
                            *(undefined4 *)(iVar26 + -0xc + iVar22 * 0x10) = uVar1;
                            *(undefined4 *)(iVar26 + -8 + iVar22 * 0x10) = uVar2;
                            *(undefined4 *)(iVar26 + -4 + iVar22 * 0x10) = uVar3;
                            func_0x000180127010(*(undefined8 *)(iVar8 + 0x1a0), *(undefined8 *)(iVar24 + 800), 
                                                *(undefined2 *)(iVar25 + 0x60 + iVar23));
                        }
                        uStack_f8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1230);
                        uStack_f4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1234);
                        uStack_f0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1238);
                        fStack_ec = *(float *)(*(int64_t *)0x180781f28 + 0x123c) *
                                    *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                        fStackX_10 = (float)(int32_t)fVar29;
                        fStackX_14 = fVar37;
                        uStackX_18._0_4_ = fStackX_10;
                        uStackX_18._4_4_ = fVar32;
                        uVar15 = func_0x0001800f5fa0(&uStack_f8);
                        func_0x000180126300(*(undefined8 *)(iVar24 + 800), &uStackX_18, &fStackX_10, uVar15, 
                                            *(undefined4 *)(iVar7 + 0xe64));
                        if (((*(int16_t *)(iVar17 + -4 + iVar18 * 0x28) != -1) &&
                            (iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0),
                            (*(uint32_t *)(iVar17 + 4) & 0x100000) == 0)) && (*(int32_t *)(iVar17 + 0x74) != -1)) {
                            iVar18 = *(int64_t *)(iVar17 + 0x18);
                            iVar24 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
                            iVar26 = (int64_t)*(int32_t *)(iVar17 + 0x74) * 0x74;
                            iVar8 = *(int64_t *)(iVar24 + 800);
                            puVar6 = (undefined4 *)(iVar26 + 0x24 + iVar18);
                            uVar9 = puVar6[1];
                            uVar10 = puVar6[2];
                            uVar11 = puVar6[3];
                            uVar15 = *(undefined4 *)(iVar26 + 0x24 + iVar18);
                            uVar1 = *(undefined4 *)(iVar26 + 0x28 + iVar18);
                            uVar2 = *(undefined4 *)(iVar26 + 0x2c + iVar18);
                            uVar3 = *(undefined4 *)(iVar26 + 0x30 + iVar18);
                            *(undefined4 *)(iVar24 + 0x2b8) = *puVar6;
                            *(undefined4 *)(iVar24 + 700) = uVar9;
                            *(undefined4 *)(iVar24 + 0x2c0) = uVar10;
                            *(undefined4 *)(iVar24 + 0x2c4) = uVar11;
                            *(undefined4 *)(iVar8 + 0x60) = uVar15;
                            *(undefined4 *)(iVar8 + 100) = uVar1;
                            *(undefined4 *)(iVar8 + 0x68) = uVar2;
                            *(undefined4 *)(iVar8 + 0x6c) = uVar3;
                            iVar23 = (int64_t)*(int32_t *)(*(int64_t *)(iVar24 + 800) + 0xa0);
                            iVar8 = *(int64_t *)(*(int64_t *)(iVar24 + 800) + 0xa8);
                            *(undefined4 *)(iVar8 + -0x10 + iVar23 * 0x10) = uVar15;
                            *(undefined4 *)(iVar8 + -0xc + iVar23 * 0x10) = uVar1;
                            *(undefined4 *)(iVar8 + -8 + iVar23 * 0x10) = uVar2;
                            *(undefined4 *)(iVar8 + -4 + iVar23 * 0x10) = uVar3;
                            func_0x000180127010(*(undefined8 *)(iVar17 + 0x1a0), *(undefined8 *)(iVar24 + 800), 
                                                *(undefined2 *)(iVar26 + 0x60 + iVar18));
                        }
                    }
                }
                *(int32_t *)(iVar7 + 0x2140) = *(int32_t *)(iVar7 + 0x2140) + -1;
                uVar27 = ~uVar27;
                *(uint32_t *)(iVar5 + 0x1e4) = *(uint32_t *)(iVar5 + 0x1e4) & uVar27;
                *(uint32_t *)(iVar5 + 0x1e8) = *(uint32_t *)(iVar5 + 0x1e8) & uVar27;
                iVar17 = var_138h;
            }
            iVar16 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
            if (iVar16 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
                }
            } else {
                *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar16 + -1;
            }
        } while ((int32_t)*(int16_t *)(arg1 + 4) < *(int32_t *)(iVar17 + 0x1e0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 0xe) < *(int32_t *)(iVar12 + 0x2110)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e68);
            }
            func_0x00018010c110();
        } while ((int32_t)*(int16_t *)(arg1 + 0xe) < *(int32_t *)(iVar12 + 0x2110));
    }
    if ((int32_t)*(int16_t *)(arg1 + 2) < *(int32_t *)(iVar17 + 0x148)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e80);
            }
            iVar16 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
            if (iVar16 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
                }
            } else {
                *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar16 + -1;
            }
        } while ((int32_t)*(int16_t *)(arg1 + 2) < *(int32_t *)(iVar17 + 0x148));
    }
    if (*(int16_t *)(arg1 + 0x14) < *(int16_t *)(iVar12 + 0x281c)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e90);
            }
            iVar17 = *(int64_t *)0x180781f28;
            if ((*(uint8_t *)(iVar12 + 0x1f78) & 0x40) == 0) {
                *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) = *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) + -1;
                iVar16 = *(int32_t *)(iVar17 + 0x2100);
                *(int32_t *)(iVar17 + 0x2100) = iVar16 + -1;
                *(undefined4 *)(iVar17 + 0x1f78) =
                     *(undefined4 *)(*(int64_t *)(iVar17 + 0x2108) + -8 + (int64_t)iVar16 * 4);
                *(undefined4 *)(iVar17 + 0xd9c) =
                     *(undefined4 *)((int64_t)*(int32_t *)(iVar17 + 0x15b0) * 0x78 + -8 + *(int64_t *)(iVar17 + 0x15b8))
                ;
                *(undefined *)((int64_t)*(int32_t *)(iVar12 + 0x15b0) * 0x78 + -10 + *(int64_t *)(iVar12 + 0x15b8)) = 0;
            } else {
                func_0x000180106130();
            }
        } while (*(int16_t *)(arg1 + 0x14) < *(int16_t *)(iVar12 + 0x281c));
    }
    if ((int32_t)*(int16_t *)(arg1 + 6) < *(int32_t *)(iVar12 + 0x20c0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644df0);
            }
            func_0x0001800f6770(1);
        } while ((int32_t)*(int16_t *)(arg1 + 6) < *(int32_t *)(iVar12 + 0x20c0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 0x10) < *(int32_t *)(iVar12 + 0x2100)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e08);
            }
            iVar17 = *(int64_t *)0x180781f28;
            iVar16 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100);
            if (iVar16 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644628);
                }
            } else {
                *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100) = iVar16 + -1;
                *(undefined4 *)(iVar17 + 0x1f78) =
                     *(undefined4 *)(*(int64_t *)(iVar17 + 0x2108) + -8 + (int64_t)iVar16 * 4);
            }
        } while ((int32_t)*(int16_t *)(arg1 + 0x10) < *(int32_t *)(iVar12 + 0x2100));
    }
    if ((int32_t)*(int16_t *)(arg1 + 8) < *(int32_t *)(iVar12 + 0x20d0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e20);
            }
            func_0x0001800f6a20(1);
        } while ((int32_t)*(int16_t *)(arg1 + 8) < *(int32_t *)(iVar12 + 0x20d0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 10) < *(int32_t *)(iVar12 + 0x20e0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644e38);
            }
            iVar17 = *(int64_t *)0x180781f28;
            if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) < 1) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445d0);
                }
            } else {
                func_0x0001801072d0(*(undefined8 *)
                                     (*(int64_t *)(*(int64_t *)0x180781f28 + 0x20e8) + -0x10 +
                                     (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) * 0x10));
                *(int32_t *)(iVar17 + 0x20e0) = *(int32_t *)(iVar17 + 0x20e0) + -1;
            }
        } while ((int32_t)*(int16_t *)(arg1 + 10) < *(int32_t *)(iVar12 + 0x20e0));
    }
    if ((int32_t)*(int16_t *)(arg1 + 0xc) < *(int32_t *)(iVar12 + 0x20f0)) {
        do {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644ea8);
            }
            iVar17 = *(int64_t *)0x180781f28;
            iVar16 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x20f0);
            if (*(int16_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x2a78) + 0xc) < iVar16) {
                *(int32_t *)(*(int64_t *)0x180781f28 + 0x20f0) = iVar16 + -1;
                if (iVar16 + -1 == 0) {
                    uVar15 = 0;
                } else {
                    uVar15 = *(undefined4 *)(*(int64_t *)(iVar17 + 0x20f8) + -0x10 + (int64_t)iVar16 * 8);
                }
                *(undefined4 *)(iVar17 + 0x1f74) = uVar15;
            } else if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445a8);
            }
        } while ((int32_t)*(int16_t *)(arg1 + 0xc) < *(int32_t *)(iVar12 + 0x20f0));
    }
    return;
}

// ============================================================
// Function: FUN_18010b530
// Address: 0x18010b530
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable arg_d4h
// WARNING: [rz-ghidra] Removing arg arg_1ech because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_220h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_228h because it doesn't fit into ProtoModel

uint64_t fcn.18010b530(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_d0h, int64_t arg_118h,
                      int64_t arg_1b8h, int64_t arg_1e0h)
{
    float fVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    float fVar6;
    float fVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    bool bVar12;
    undefined4 *puVar13;
    char cVar14;
    undefined4 *puVar15;
    int64_t iVar16;
    int32_t iVar17;
    undefined4 *puVar18;
    uint64_t uVar19;
    uint32_t uVar20;
    uint32_t uVar21;
    undefined4 *puVar22;
    float fVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_84h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    puVar13 = *(undefined4 **)0x180781f28;
    puVar15 = (undefined4 *)arg1;
    if (arg3 != 0) {
        puVar15 = (undefined4 *)arg3;
    }
    iVar17 = (int32_t)arg2;
    uVar20 = (uint32_t)arg4 | (*(undefined4 **)0x180781f28)[0x7de] | (*(undefined4 **)0x180781f28)[0x7e1];
    iVar4 = *(int64_t *)(*(undefined4 **)0x180781f28 + 0x578);
    (*(undefined4 **)0x180781f28)[0x7ee] = iVar17;
    uVar8 = *(undefined4 *)(arg1 + 4);
    uVar9 = *(undefined4 *)(arg1 + 8);
    uVar10 = *(undefined4 *)(arg1 + 0xc);
    puVar13[0x7f1] = *(undefined4 *)arg1;
    puVar13[0x7f2] = uVar8;
    puVar13[0x7f3] = uVar9;
    puVar13[0x7f4] = uVar10;
    uVar8 = *puVar15;
    uVar9 = puVar15[1];
    uVar10 = puVar15[2];
    uVar11 = puVar15[3];
    puVar13[0x7ef] = uVar20;
    puVar13[0x7f0] = 0;
    puVar13[0x7f5] = uVar8;
    puVar13[0x7f6] = uVar9;
    puVar13[0x7f7] = uVar10;
    puVar13[0x7f8] = uVar11;
    if (iVar17 != 0) {
        if (puVar13[0x595] == iVar17) {
            puVar13[0x596] = iVar17;
        }
        if (puVar13[0x5a1] == iVar17) {
            *(undefined *)((int64_t)puVar13 + 0x168d) = 1;
        }
        puVar18 = puVar13;
        if ((uVar20 & 2) == 0) {
            puVar15 = (undefined4 *)(uint64_t)*(uint32_t *)(iVar4 + 0x1b0);
            *(uint16_t *)(iVar4 + 0x1b6) =
                 *(uint16_t *)(iVar4 + 0x1b6) | (uint16_t)(1 << (*(uint32_t *)(iVar4 + 0x1b0) & 0x1f));
            if ((puVar13[0x874] == iVar17) || (*(char *)((int64_t)puVar13 + 0x2239) != '\0')) {
                iVar5 = *(int64_t *)(puVar13 + 0x876);
                puVar15 = *(undefined4 **)(iVar4 + 0x438);
                if ((*(undefined4 **)(iVar5 + 0x438) == puVar15) &&
                   ((iVar4 == iVar5 ||
                    (uVar20 = *(uint32_t *)(iVar5 + 0x1c) | *(uint32_t *)(iVar4 + 0x1c),
                    puVar15 = (undefined4 *)(uint64_t)uVar20, (uVar20 >> 8 & 1) != 0)))) {
                    fVar6 = (float)puVar13[0x7f5];
                    var_78h._4_4_ = (float)puVar13[0x7f6];
                    fVar7 = (float)puVar13[0x7f7];
                    var_70h._4_4_ = (float)puVar13[0x7f8];
                    iVar5 = *(int64_t *)(puVar13 + 0x578);
                    uVar20 = puVar13[0x7ef];
                    iVar2 = puVar13[0x7ee];
                    fVar25 = fVar7;
                    fVar26 = fVar6;
                    if (*(char *)(iVar5 + 0x1b8) == '\0') {
                        fVar25 = *(float *)(iVar5 + 0x2b8);
                        fVar1 = *(float *)(iVar5 + 0x2c0);
                        fVar26 = fVar25;
                        if ((fVar25 <= fVar6) && (fVar26 = fVar1, fVar6 <= fVar1)) {
                            fVar26 = fVar6;
                        }
                        if ((fVar25 <= fVar7) && (fVar25 = fVar1, fVar7 <= fVar1)) {
                            fVar25 = fVar7;
                        }
                    }
                    var_78h._0_4_ = fVar26;
                    var_70h._0_4_ = fVar25;
                    if ((((*(char *)((int64_t)puVar13 + 0x223a) != '\0') &&
                         (puVar15 = (undefined4 *)(uint64_t)*(uint32_t *)(iVar5 + 0x1b0),
                         puVar13[0x879] == *(uint32_t *)(iVar5 + 0x1b0))) && ((uVar20 & 0x40) == 0)) &&
                       (((uVar21 = uVar20 & 4, uVar21 == 0 || (puVar13[0x892] == 0)) &&
                        (puVar15 = (undefined4 *)func_0x00018010ea60(), uVar21 == 0)))) {
                        *(undefined *)((int64_t)puVar13 + 0x223a) = 0;
                        puVar15 = (undefined4 *)func_0x00018010ee20();
                    }
                    fVar7 = var_70h._4_4_;
                    fVar6 = var_78h._4_4_;
                    if ((*(char *)((int64_t)puVar13 + 0x2279) != '\0') && ((uVar20 & 0x40) == 0)) {
                        uVar21 = puVar13[0x89f];
                        puVar15 = (undefined4 *)(uint64_t)uVar21;
                        if (((uVar21 & 0x200) != 0) || ((*(uint32_t *)(iVar5 + 0x14) & 0x10000) == 0)) {
                            if ((uVar21 >> 10 & 1) == 0) {
                                if ((puVar13[0x874] != iVar2) || ((uVar21 & 0x10) != 0)) {
                                    puVar15 = puVar13 + 0x8b0;
                                    if (iVar5 != *(int64_t *)(puVar13 + 0x876)) {
                                        puVar15 = puVar13 + 0x8cc;
                                    }
                                    puVar15 = (undefined4 *)func_0x00018010e620(puVar15, &var_78h);
                                    if ((char)puVar15 != '\0') {
                                        puVar15 = (undefined4 *)func_0x00018010ea60();
                                    }
                                    if (((((*(uint8_t *)(puVar13 + 0x89f) & 0x20) != 0) &&
                                         (fVar1 = *(float *)(iVar5 + 0x284), fVar6 < fVar1)) &&
                                        (fVar23 = *(float *)(iVar5 + 0x27c), fVar23 < fVar7)) &&
                                       ((fVar26 < *(float *)(iVar5 + 0x280) &&
                                        (*(float *)(iVar5 + 0x278) <= fVar25 && fVar25 != *(float *)(iVar5 + 0x278)))))
                                    {
                                        fVar24 = fVar23;
                                        if ((fVar23 <= fVar7) && (fVar24 = fVar1, fVar7 <= fVar1)) {
                                            fVar24 = fVar7;
                                        }
                                        if ((fVar23 <= fVar6) && (fVar23 = fVar1, fVar6 <= fVar1)) {
                                            fVar23 = fVar6;
                                        }
                                        if ((fVar7 - fVar6) * 0.7 <= fVar24 - fVar23) {
                                            puVar15 = (undefined4 *)func_0x00018010e620(puVar13 + 0x8be, &var_78h);
                                            cVar14 = (char)puVar15;
joined_r0x00018010b96b:
                                            if (cVar14 != '\0') {
code_r0x00018010b974:
                                                puVar15 = (undefined4 *)func_0x00018010ea60();
                                            }
                                        }
                                    }
                                }
                            } else if ((uVar21 & 0x200) == 0) {
                                puVar15 = *(undefined4 **)(puVar13 + 0x578);
                                if (puVar13[0x879] == puVar15[0x6c]) {
                                    uVar21 = puVar13[0x7dd];
                                    puVar15 = (undefined4 *)(uint64_t)uVar21;
                                    if (puVar13[0x878] == uVar21) {
                                        if (((uVar20 & 1) == 0) &&
                                           (((*(uint8_t *)(puVar13 + 0xc) & 1) != 0 || ((uVar20 >> 0x14 & 1) != 0))))
                                        goto code_r0x00018010b7b2;
                                        puVar15 = (undefined4 *)((uint64_t)(unkuint3)(uVar21 >> 8) << 8);
                                        goto code_r0x00018010b7b4;
                                    }
                                }
                            } else {
code_r0x00018010b7b2:
                                puVar15 = (undefined4 *)CONCAT71((unkint7)((uint64_t)puVar15 >> 8), 1);
code_r0x00018010b7b4:
                                iVar3 = puVar13[0x8ae];
                                cVar14 = (char)puVar15;
                                if (iVar3 == 1) {
                                    if (cVar14 != '\0') {
                                        if (puVar13[0x8dc] == 0) {
                                            func_0x00018010ea60();
                                        }
                                        uVar21 = puVar13[0x8af];
                                        puVar15 = (undefined4 *)(uint64_t)uVar21;
                                        if (0 < (int32_t)uVar21) {
                                            uVar21 = uVar21 - 1;
                                            puVar15 = (undefined4 *)(uint64_t)uVar21;
                                            puVar13[0x8af] = uVar21;
                                            if (uVar21 == 0) {
                                                puVar15 = (undefined4 *)func_0x00018010eca0();
                                                puVar18 = *(undefined4 **)0x180781f28;
                                                goto code_r0x00018010b979;
                                            }
                                        }
                                    }
                                    if (puVar13[0x874] == iVar2) {
                                        puVar13[0x8af] = 1;
                                    }
                                } else if (iVar3 == -1) {
                                    if (puVar13[0x874] != iVar2) goto joined_r0x00018010b96b;
                                    if (puVar13[0x8b2] != 0) {
                                        *(undefined *)((int64_t)puVar13 + 0x2279) = 0;
                                        puVar15 = (undefined4 *)func_0x00018010ee20();
                                    }
                                } else if ((iVar3 == 0) && (cVar14 != '\0')) {
                                    puVar22 = puVar13;
                                    if (puVar13[0x874] == iVar2) {
                                        puVar15 = (undefined4 *)func_0x00018010eca0(puVar13 + 0x8b0);
                                        puVar18 = *(undefined4 **)0x180781f28;
                                    }
                                    if (puVar22[0x8dc] == 0) goto code_r0x00018010b974;
                                }
                            }
                        }
                    }
code_r0x00018010b979:
                    if (puVar13[0x874] == iVar2) {
                        if (*(int64_t *)(puVar13 + 0x876) != iVar5) {
                            if (*(int64_t *)(puVar18 + 0x876) != iVar5) {
                                *(int64_t *)(puVar18 + 0x876) = iVar5;
                                *(undefined8 *)(puVar18 + 0x88c) = 0xffffffffffffffff;
                            }
                            *(undefined2 *)(puVar18 + 0x89e) = 0;
                            *(undefined2 *)((int64_t)puVar18 + 0x2239) = 0;
                        }
                        puVar13[0x879] = *(undefined4 *)(iVar5 + 0x1b0);
                        func_0x000180106840();
                        puVar13[0x878] = puVar13[0x7dd];
                        *(undefined *)((int64_t)puVar13 + 0x21cf) = 1;
                        puVar13[0x87a] = uVar20;
                        if ((puVar13[0x7ef] & 0x200000) != 0) {
                            *(undefined8 *)(puVar13 + 0x88c) = *(undefined8 *)(puVar13 + 0x7e4);
                        }
                        fVar1 = *(float *)(iVar5 + 0x168);
                        fVar23 = *(float *)(iVar5 + 0x16c);
                        iVar16 = (int64_t)*(int32_t *)(iVar5 + 0x1b0);
                        puVar15 = (undefined4 *)(iVar16 * 2);
                        *(float *)(iVar5 + 0x458 + iVar16 * 0x10) = fVar26 - fVar1;
                        *(float *)(iVar5 + 0x45c + iVar16 * 0x10) = fVar6 - fVar23;
                        *(float *)(iVar5 + 0x460 + iVar16 * 0x10) = fVar25 - fVar1;
                        *(float *)(iVar5 + 0x464 + iVar16 * 0x10) = fVar7 - fVar23;
                        puVar18 = *(undefined4 **)0x180781f28;
                    }
                }
            }
        }
        if (((*(uint8_t *)(puVar13 + 0x7e0) & 4) != 0) && ((*(uint8_t *)(puVar18 + 0x7ef) & 0x40) == 0)) {
            if (((uint32_t)puVar18[0x7e8] >> 0x12 & 1) != 0) {
                puVar18[0x7f0] = puVar18[0x7f0] | 0x400;
                puVar18[0x801] = puVar18[0x7e7];
            }
            puVar15 = (undefined4 *)
                      fcn.180109d80((uint64_t)(uint32_t)puVar18[0x7e7], (uint64_t)(puVar18[0x7e8] & 0x3fcff), 
                                    arg2 & 0xffffffff);
            puVar22 = *(undefined4 **)0x180781f28;
            if (((char)puVar15 != '\0') && (puVar18[0x87b] == 0)) {
                puVar18[0x87b] = iVar17;
                puVar18[0x87e] = 0x11;
                puVar18[0x87d] = iVar17;
                puVar18[0x87c] = iVar17;
                puVar22[0x884] = iVar17;
                puVar22[0x885] = 0x3dcccccd;
                puVar15 = puVar22;
            }
        }
    }
    *(undefined8 *)(puVar13 + 0x7e0) = 0;
    if ((((*(float *)(arg1 + 0xc) < *(float *)(iVar4 + 700) || *(float *)(arg1 + 0xc) == *(float *)(iVar4 + 700)) ||
         (*(float *)(iVar4 + 0x2c4) < *(float *)(arg1 + 4) || *(float *)(iVar4 + 0x2c4) == *(float *)(arg1 + 4))) ||
        (fVar25 = *(float *)(arg1 + 8), fVar25 < *(float *)(iVar4 + 0x2b8) || fVar25 == *(float *)(iVar4 + 0x2b8))) ||
       (*(float *)(iVar4 + 0x2c0) < *(float *)arg1 || *(float *)(iVar4 + 0x2c0) == *(float *)arg1)) {
        bVar12 = false;
        if ((iVar17 == 0) ||
           (((iVar17 != puVar13[0x595] && (iVar17 != puVar13[0x5a0])) &&
            ((iVar17 != puVar13[0x874] && (iVar17 != puVar13[0x87b])))))) {
            if (*(char *)((int64_t)puVar13 + 0x1652) == '\0') {
                return (uint64_t)puVar15 & 0xffffffffffffff00;
            }
            goto code_r0x00018010bb69;
        }
    } else {
        bVar12 = true;
code_r0x00018010bb69:
        if (iVar17 == 0) goto code_r0x00018010bb7e;
    }
    if (puVar13[0x5a1] == iVar17) {
        puVar13[0x5a2] = puVar13[1];
    }
code_r0x00018010bb7e:
    if (bVar12) {
        puVar13[0x7f0] = puVar13[0x7f0] | 0x100;
    }
    uVar19 = 1;
    cVar14 = fcn.180108120(arg1, (int64_t)(float *)(arg1 + 8));
    if (cVar14 != '\0') {
        puVar13[0x7f0] = puVar13[0x7f0] | 1;
    }
    return uVar19 & 0xff;
}

// ============================================================
// Function: FUN_18010b53e
// Address: 0x18010b53e
// Size: 244 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable arg_d4h
// WARNING: [rz-ghidra] Removing arg arg_1ech because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_220h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_228h because it doesn't fit into ProtoModel

uint64_t fcn.18010b530(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_d0h, int64_t arg_118h,
                      int64_t arg_1b8h, int64_t arg_1e0h)
{
    float fVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    float fVar6;
    float fVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    bool bVar12;
    undefined4 *puVar13;
    char cVar14;
    undefined4 *puVar15;
    int64_t iVar16;
    int32_t iVar17;
    undefined4 *puVar18;
    uint64_t uVar19;
    uint32_t uVar20;
    uint32_t uVar21;
    undefined4 *puVar22;
    float fVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_84h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    puVar13 = *(undefined4 **)0x180781f28;
    puVar15 = (undefined4 *)arg1;
    if (arg3 != 0) {
        puVar15 = (undefined4 *)arg3;
    }
    iVar17 = (int32_t)arg2;
    uVar20 = (uint32_t)arg4 | (*(undefined4 **)0x180781f28)[0x7de] | (*(undefined4 **)0x180781f28)[0x7e1];
    iVar4 = *(int64_t *)(*(undefined4 **)0x180781f28 + 0x578);
    (*(undefined4 **)0x180781f28)[0x7ee] = iVar17;
    uVar8 = *(undefined4 *)(arg1 + 4);
    uVar9 = *(undefined4 *)(arg1 + 8);
    uVar10 = *(undefined4 *)(arg1 + 0xc);
    puVar13[0x7f1] = *(undefined4 *)arg1;
    puVar13[0x7f2] = uVar8;
    puVar13[0x7f3] = uVar9;
    puVar13[0x7f4] = uVar10;
    uVar8 = *puVar15;
    uVar9 = puVar15[1];
    uVar10 = puVar15[2];
    uVar11 = puVar15[3];
    puVar13[0x7ef] = uVar20;
    puVar13[0x7f0] = 0;
    puVar13[0x7f5] = uVar8;
    puVar13[0x7f6] = uVar9;
    puVar13[0x7f7] = uVar10;
    puVar13[0x7f8] = uVar11;
    if (iVar17 != 0) {
        if (puVar13[0x595] == iVar17) {
            puVar13[0x596] = iVar17;
        }
        if (puVar13[0x5a1] == iVar17) {
            *(undefined *)((int64_t)puVar13 + 0x168d) = 1;
        }
        puVar18 = puVar13;
        if ((uVar20 & 2) == 0) {
            puVar15 = (undefined4 *)(uint64_t)*(uint32_t *)(iVar4 + 0x1b0);
            *(uint16_t *)(iVar4 + 0x1b6) =
                 *(uint16_t *)(iVar4 + 0x1b6) | (uint16_t)(1 << (*(uint32_t *)(iVar4 + 0x1b0) & 0x1f));
            if ((puVar13[0x874] == iVar17) || (*(char *)((int64_t)puVar13 + 0x2239) != '\0')) {
                iVar5 = *(int64_t *)(puVar13 + 0x876);
                puVar15 = *(undefined4 **)(iVar4 + 0x438);
                if ((*(undefined4 **)(iVar5 + 0x438) == puVar15) &&
                   ((iVar4 == iVar5 ||
                    (uVar20 = *(uint32_t *)(iVar5 + 0x1c) | *(uint32_t *)(iVar4 + 0x1c),
                    puVar15 = (undefined4 *)(uint64_t)uVar20, (uVar20 >> 8 & 1) != 0)))) {
                    fVar6 = (float)puVar13[0x7f5];
                    var_78h._4_4_ = (float)puVar13[0x7f6];
                    fVar7 = (float)puVar13[0x7f7];
                    var_70h._4_4_ = (float)puVar13[0x7f8];
                    iVar5 = *(int64_t *)(puVar13 + 0x578);
                    uVar20 = puVar13[0x7ef];
                    iVar2 = puVar13[0x7ee];
                    fVar25 = fVar7;
                    fVar26 = fVar6;
                    if (*(char *)(iVar5 + 0x1b8) == '\0') {
                        fVar25 = *(float *)(iVar5 + 0x2b8);
                        fVar1 = *(float *)(iVar5 + 0x2c0);
                        fVar26 = fVar25;
                        if ((fVar25 <= fVar6) && (fVar26 = fVar1, fVar6 <= fVar1)) {
                            fVar26 = fVar6;
                        }
                        if ((fVar25 <= fVar7) && (fVar25 = fVar1, fVar7 <= fVar1)) {
                            fVar25 = fVar7;
                        }
                    }
                    var_78h._0_4_ = fVar26;
                    var_70h._0_4_ = fVar25;
                    if ((((*(char *)((int64_t)puVar13 + 0x223a) != '\0') &&
                         (puVar15 = (undefined4 *)(uint64_t)*(uint32_t *)(iVar5 + 0x1b0),
                         puVar13[0x879] == *(uint32_t *)(iVar5 + 0x1b0))) && ((uVar20 & 0x40) == 0)) &&
                       (((uVar21 = uVar20 & 4, uVar21 == 0 || (puVar13[0x892] == 0)) &&
                        (puVar15 = (undefined4 *)func_0x00018010ea60(), uVar21 == 0)))) {
                        *(undefined *)((int64_t)puVar13 + 0x223a) = 0;
                        puVar15 = (undefined4 *)func_0x00018010ee20();
                    }
                    fVar7 = var_70h._4_4_;
                    fVar6 = var_78h._4_4_;
                    if ((*(char *)((int64_t)puVar13 + 0x2279) != '\0') && ((uVar20 & 0x40) == 0)) {
                        uVar21 = puVar13[0x89f];
                        puVar15 = (undefined4 *)(uint64_t)uVar21;
                        if (((uVar21 & 0x200) != 0) || ((*(uint32_t *)(iVar5 + 0x14) & 0x10000) == 0)) {
                            if ((uVar21 >> 10 & 1) == 0) {
                                if ((puVar13[0x874] != iVar2) || ((uVar21 & 0x10) != 0)) {
                                    puVar15 = puVar13 + 0x8b0;
                                    if (iVar5 != *(int64_t *)(puVar13 + 0x876)) {
                                        puVar15 = puVar13 + 0x8cc;
                                    }
                                    puVar15 = (undefined4 *)func_0x00018010e620(puVar15, &var_78h);
                                    if ((char)puVar15 != '\0') {
                                        puVar15 = (undefined4 *)func_0x00018010ea60();
                                    }
                                    if (((((*(uint8_t *)(puVar13 + 0x89f) & 0x20) != 0) &&
                                         (fVar1 = *(float *)(iVar5 + 0x284), fVar6 < fVar1)) &&
                                        (fVar23 = *(float *)(iVar5 + 0x27c), fVar23 < fVar7)) &&
                                       ((fVar26 < *(float *)(iVar5 + 0x280) &&
                                        (*(float *)(iVar5 + 0x278) <= fVar25 && fVar25 != *(float *)(iVar5 + 0x278)))))
                                    {
                                        fVar24 = fVar23;
                                        if ((fVar23 <= fVar7) && (fVar24 = fVar1, fVar7 <= fVar1)) {
                                            fVar24 = fVar7;
                                        }
                                        if ((fVar23 <= fVar6) && (fVar23 = fVar1, fVar6 <= fVar1)) {
                                            fVar23 = fVar6;
                                        }
                                        if ((fVar7 - fVar6) * 0.7 <= fVar24 - fVar23) {
                                            puVar15 = (undefined4 *)func_0x00018010e620(puVar13 + 0x8be, &var_78h);
                                            cVar14 = (char)puVar15;
joined_r0x00018010b96b:
                                            if (cVar14 != '\0') {
code_r0x00018010b974:
                                                puVar15 = (undefined4 *)func_0x00018010ea60();
                                            }
                                        }
                                    }
                                }
                            } else if ((uVar21 & 0x200) == 0) {
                                puVar15 = *(undefined4 **)(puVar13 + 0x578);
                                if (puVar13[0x879] == puVar15[0x6c]) {
                                    uVar21 = puVar13[0x7dd];
                                    puVar15 = (undefined4 *)(uint64_t)uVar21;
                                    if (puVar13[0x878] == uVar21) {
                                        if (((uVar20 & 1) == 0) &&
                                           (((*(uint8_t *)(puVar13 + 0xc) & 1) != 0 || ((uVar20 >> 0x14 & 1) != 0))))
                                        goto code_r0x00018010b7b2;
                                        puVar15 = (undefined4 *)((uint64_t)(unkuint3)(uVar21 >> 8) << 8);
                                        goto code_r0x00018010b7b4;
                                    }
                                }
                            } else {
code_r0x00018010b7b2:
                                puVar15 = (undefined4 *)CONCAT71((unkint7)((uint64_t)puVar15 >> 8), 1);
code_r0x00018010b7b4:
                                iVar3 = puVar13[0x8ae];
                                cVar14 = (char)puVar15;
                                if (iVar3 == 1) {
                                    if (cVar14 != '\0') {
                                        if (puVar13[0x8dc] == 0) {
                                            func_0x00018010ea60();
                                        }
                                        uVar21 = puVar13[0x8af];
                                        puVar15 = (undefined4 *)(uint64_t)uVar21;
                                        if (0 < (int32_t)uVar21) {
                                            uVar21 = uVar21 - 1;
                                            puVar15 = (undefined4 *)(uint64_t)uVar21;
                                            puVar13[0x8af] = uVar21;
                                            if (uVar21 == 0) {
                                                puVar15 = (undefined4 *)func_0x00018010eca0();
                                                puVar18 = *(undefined4 **)0x180781f28;
                                                goto code_r0x00018010b979;
                                            }
                                        }
                                    }
                                    if (puVar13[0x874] == iVar2) {
                                        puVar13[0x8af] = 1;
                                    }
                                } else if (iVar3 == -1) {
                                    if (puVar13[0x874] != iVar2) goto joined_r0x00018010b96b;
                                    if (puVar13[0x8b2] != 0) {
                                        *(undefined *)((int64_t)puVar13 + 0x2279) = 0;
                                        puVar15 = (undefined4 *)func_0x00018010ee20();
                                    }
                                } else if ((iVar3 == 0) && (cVar14 != '\0')) {
                                    puVar22 = puVar13;
                                    if (puVar13[0x874] == iVar2) {
                                        puVar15 = (undefined4 *)func_0x00018010eca0(puVar13 + 0x8b0);
                                        puVar18 = *(undefined4 **)0x180781f28;
                                    }
                                    if (puVar22[0x8dc] == 0) goto code_r0x00018010b974;
                                }
                            }
                        }
                    }
code_r0x00018010b979:
                    if (puVar13[0x874] == iVar2) {
                        if (*(int64_t *)(puVar13 + 0x876) != iVar5) {
                            if (*(int64_t *)(puVar18 + 0x876) != iVar5) {
                                *(int64_t *)(puVar18 + 0x876) = iVar5;
                                *(undefined8 *)(puVar18 + 0x88c) = 0xffffffffffffffff;
                            }
                            *(undefined2 *)(puVar18 + 0x89e) = 0;
                            *(undefined2 *)((int64_t)puVar18 + 0x2239) = 0;
                        }
                        puVar13[0x879] = *(undefined4 *)(iVar5 + 0x1b0);
                        func_0x000180106840();
                        puVar13[0x878] = puVar13[0x7dd];
                        *(undefined *)((int64_t)puVar13 + 0x21cf) = 1;
                        puVar13[0x87a] = uVar20;
                        if ((puVar13[0x7ef] & 0x200000) != 0) {
                            *(undefined8 *)(puVar13 + 0x88c) = *(undefined8 *)(puVar13 + 0x7e4);
                        }
                        fVar1 = *(float *)(iVar5 + 0x168);
                        fVar23 = *(float *)(iVar5 + 0x16c);
                        iVar16 = (int64_t)*(int32_t *)(iVar5 + 0x1b0);
                        puVar15 = (undefined4 *)(iVar16 * 2);
                        *(float *)(iVar5 + 0x458 + iVar16 * 0x10) = fVar26 - fVar1;
                        *(float *)(iVar5 + 0x45c + iVar16 * 0x10) = fVar6 - fVar23;
                        *(float *)(iVar5 + 0x460 + iVar16 * 0x10) = fVar25 - fVar1;
                        *(float *)(iVar5 + 0x464 + iVar16 * 0x10) = fVar7 - fVar23;
                        puVar18 = *(undefined4 **)0x180781f28;
                    }
                }
            }
        }
        if (((*(uint8_t *)(puVar13 + 0x7e0) & 4) != 0) && ((*(uint8_t *)(puVar18 + 0x7ef) & 0x40) == 0)) {
            if (((uint32_t)puVar18[0x7e8] >> 0x12 & 1) != 0) {
                puVar18[0x7f0] = puVar18[0x7f0] | 0x400;
                puVar18[0x801] = puVar18[0x7e7];
            }
            puVar15 = (undefined4 *)
                      fcn.180109d80((uint64_t)(uint32_t)puVar18[0x7e7], (uint64_t)(puVar18[0x7e8] & 0x3fcff), 
                                    arg2 & 0xffffffff);
            puVar22 = *(undefined4 **)0x180781f28;
            if (((char)puVar15 != '\0') && (puVar18[0x87b] == 0)) {
                puVar18[0x87b] = iVar17;
                puVar18[0x87e] = 0x11;
                puVar18[0x87d] = iVar17;
                puVar18[0x87c] = iVar17;
                puVar22[0x884] = iVar17;
                puVar22[0x885] = 0x3dcccccd;
                puVar15 = puVar22;
            }
        }
    }
    *(undefined8 *)(puVar13 + 0x7e0) = 0;
    if ((((*(float *)(arg1 + 0xc) < *(float *)(iVar4 + 700) || *(float *)(arg1 + 0xc) == *(float *)(iVar4 + 700)) ||
         (*(float *)(iVar4 + 0x2c4) < *(float *)(arg1 + 4) || *(float *)(iVar4 + 0x2c4) == *(float *)(arg1 + 4))) ||
        (fVar25 = *(float *)(arg1 + 8), fVar25 < *(float *)(iVar4 + 0x2b8) || fVar25 == *(float *)(iVar4 + 0x2b8))) ||
       (*(float *)(iVar4 + 0x2c0) < *(float *)arg1 || *(float *)(iVar4 + 0x2c0) == *(float *)arg1)) {
        bVar12 = false;
        if ((iVar17 == 0) ||
           (((iVar17 != puVar13[0x595] && (iVar17 != puVar13[0x5a0])) &&
            ((iVar17 != puVar13[0x874] && (iVar17 != puVar13[0x87b])))))) {
            if (*(char *)((int64_t)puVar13 + 0x1652) == '\0') {
                return (uint64_t)puVar15 & 0xffffffffffffff00;
            }
            goto code_r0x00018010bb69;
        }
    } else {
        bVar12 = true;
code_r0x00018010bb69:
        if (iVar17 == 0) goto code_r0x00018010bb7e;
    }
    if (puVar13[0x5a1] == iVar17) {
        puVar13[0x5a2] = puVar13[1];
    }
code_r0x00018010bb7e:
    if (bVar12) {
        puVar13[0x7f0] = puVar13[0x7f0] | 0x100;
    }
    uVar19 = 1;
    cVar14 = fcn.180108120(arg1, (int64_t)(float *)(arg1 + 8));
    if (cVar14 != '\0') {
        puVar13[0x7f0] = puVar13[0x7f0] | 1;
    }
    return uVar19 & 0xff;
}

// ============================================================
// Function: FUN_18010b632
// Address: 0x18010b632
// Size: 30 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable arg_d4h
// WARNING: [rz-ghidra] Removing arg arg_1ech because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_220h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_228h because it doesn't fit into ProtoModel

uint64_t fcn.18010b530(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_d0h, int64_t arg_118h,
                      int64_t arg_1b8h, int64_t arg_1e0h)
{
    float fVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    float fVar6;
    float fVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    bool bVar12;
    undefined4 *puVar13;
    char cVar14;
    undefined4 *puVar15;
    int64_t iVar16;
    int32_t iVar17;
    undefined4 *puVar18;
    uint64_t uVar19;
    uint32_t uVar20;
    uint32_t uVar21;
    undefined4 *puVar22;
    float fVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_84h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    puVar13 = *(undefined4 **)0x180781f28;
    puVar15 = (undefined4 *)arg1;
    if (arg3 != 0) {
        puVar15 = (undefined4 *)arg3;
    }
    iVar17 = (int32_t)arg2;
    uVar20 = (uint32_t)arg4 | (*(undefined4 **)0x180781f28)[0x7de] | (*(undefined4 **)0x180781f28)[0x7e1];
    iVar4 = *(int64_t *)(*(undefined4 **)0x180781f28 + 0x578);
    (*(undefined4 **)0x180781f28)[0x7ee] = iVar17;
    uVar8 = *(undefined4 *)(arg1 + 4);
    uVar9 = *(undefined4 *)(arg1 + 8);
    uVar10 = *(undefined4 *)(arg1 + 0xc);
    puVar13[0x7f1] = *(undefined4 *)arg1;
    puVar13[0x7f2] = uVar8;
    puVar13[0x7f3] = uVar9;
    puVar13[0x7f4] = uVar10;
    uVar8 = *puVar15;
    uVar9 = puVar15[1];
    uVar10 = puVar15[2];
    uVar11 = puVar15[3];
    puVar13[0x7ef] = uVar20;
    puVar13[0x7f0] = 0;
    puVar13[0x7f5] = uVar8;
    puVar13[0x7f6] = uVar9;
    puVar13[0x7f7] = uVar10;
    puVar13[0x7f8] = uVar11;
    if (iVar17 != 0) {
        if (puVar13[0x595] == iVar17) {
            puVar13[0x596] = iVar17;
        }
        if (puVar13[0x5a1] == iVar17) {
            *(undefined *)((int64_t)puVar13 + 0x168d) = 1;
        }
        puVar18 = puVar13;
        if ((uVar20 & 2) == 0) {
            puVar15 = (undefined4 *)(uint64_t)*(uint32_t *)(iVar4 + 0x1b0);
            *(uint16_t *)(iVar4 + 0x1b6) =
                 *(uint16_t *)(iVar4 + 0x1b6) | (uint16_t)(1 << (*(uint32_t *)(iVar4 + 0x1b0) & 0x1f));
            if ((puVar13[0x874] == iVar17) || (*(char *)((int64_t)puVar13 + 0x2239) != '\0')) {
                iVar5 = *(int64_t *)(puVar13 + 0x876);
                puVar15 = *(undefined4 **)(iVar4 + 0x438);
                if ((*(undefined4 **)(iVar5 + 0x438) == puVar15) &&
                   ((iVar4 == iVar5 ||
                    (uVar20 = *(uint32_t *)(iVar5 + 0x1c) | *(uint32_t *)(iVar4 + 0x1c),
                    puVar15 = (undefined4 *)(uint64_t)uVar20, (uVar20 >> 8 & 1) != 0)))) {
                    fVar6 = (float)puVar13[0x7f5];
                    var_78h._4_4_ = (float)puVar13[0x7f6];
                    fVar7 = (float)puVar13[0x7f7];
                    var_70h._4_4_ = (float)puVar13[0x7f8];
                    iVar5 = *(int64_t *)(puVar13 + 0x578);
                    uVar20 = puVar13[0x7ef];
                    iVar2 = puVar13[0x7ee];
                    fVar25 = fVar7;
                    fVar26 = fVar6;
                    if (*(char *)(iVar5 + 0x1b8) == '\0') {
                        fVar25 = *(float *)(iVar5 + 0x2b8);
                        fVar1 = *(float *)(iVar5 + 0x2c0);
                        fVar26 = fVar25;
                        if ((fVar25 <= fVar6) && (fVar26 = fVar1, fVar6 <= fVar1)) {
                            fVar26 = fVar6;
                        }
                        if ((fVar25 <= fVar7) && (fVar25 = fVar1, fVar7 <= fVar1)) {
                            fVar25 = fVar7;
                        }
                    }
                    var_78h._0_4_ = fVar26;
                    var_70h._0_4_ = fVar25;
                    if ((((*(char *)((int64_t)puVar13 + 0x223a) != '\0') &&
                         (puVar15 = (undefined4 *)(uint64_t)*(uint32_t *)(iVar5 + 0x1b0),
                         puVar13[0x879] == *(uint32_t *)(iVar5 + 0x1b0))) && ((uVar20 & 0x40) == 0)) &&
                       (((uVar21 = uVar20 & 4, uVar21 == 0 || (puVar13[0x892] == 0)) &&
                        (puVar15 = (undefined4 *)func_0x00018010ea60(), uVar21 == 0)))) {
                        *(undefined *)((int64_t)puVar13 + 0x223a) = 0;
                        puVar15 = (undefined4 *)func_0x00018010ee20();
                    }
                    fVar7 = var_70h._4_4_;
                    fVar6 = var_78h._4_4_;
                    if ((*(char *)((int64_t)puVar13 + 0x2279) != '\0') && ((uVar20 & 0x40) == 0)) {
                        uVar21 = puVar13[0x89f];
                        puVar15 = (undefined4 *)(uint64_t)uVar21;
                        if (((uVar21 & 0x200) != 0) || ((*(uint32_t *)(iVar5 + 0x14) & 0x10000) == 0)) {
                            if ((uVar21 >> 10 & 1) == 0) {
                                if ((puVar13[0x874] != iVar2) || ((uVar21 & 0x10) != 0)) {
                                    puVar15 = puVar13 + 0x8b0;
                                    if (iVar5 != *(int64_t *)(puVar13 + 0x876)) {
                                        puVar15 = puVar13 + 0x8cc;
                                    }
                                    puVar15 = (undefined4 *)func_0x00018010e620(puVar15, &var_78h);
                                    if ((char)puVar15 != '\0') {
                                        puVar15 = (undefined4 *)func_0x00018010ea60();
                                    }
                                    if (((((*(uint8_t *)(puVar13 + 0x89f) & 0x20) != 0) &&
                                         (fVar1 = *(float *)(iVar5 + 0x284), fVar6 < fVar1)) &&
                                        (fVar23 = *(float *)(iVar5 + 0x27c), fVar23 < fVar7)) &&
                                       ((fVar26 < *(float *)(iVar5 + 0x280) &&
                                        (*(float *)(iVar5 + 0x278) <= fVar25 && fVar25 != *(float *)(iVar5 + 0x278)))))
                                    {
                                        fVar24 = fVar23;
                                        if ((fVar23 <= fVar7) && (fVar24 = fVar1, fVar7 <= fVar1)) {
                                            fVar24 = fVar7;
                                        }
                                        if ((fVar23 <= fVar6) && (fVar23 = fVar1, fVar6 <= fVar1)) {
                                            fVar23 = fVar6;
                                        }
                                        if ((fVar7 - fVar6) * 0.7 <= fVar24 - fVar23) {
                                            puVar15 = (undefined4 *)func_0x00018010e620(puVar13 + 0x8be, &var_78h);
                                            cVar14 = (char)puVar15;
joined_r0x00018010b96b:
                                            if (cVar14 != '\0') {
code_r0x00018010b974:
                                                puVar15 = (undefined4 *)func_0x00018010ea60();
                                            }
                                        }
                                    }
                                }
                            } else if ((uVar21 & 0x200) == 0) {
                                puVar15 = *(undefined4 **)(puVar13 + 0x578);
                                if (puVar13[0x879] == puVar15[0x6c]) {
                                    uVar21 = puVar13[0x7dd];
                                    puVar15 = (undefined4 *)(uint64_t)uVar21;
                                    if (puVar13[0x878] == uVar21) {
                                        if (((uVar20 & 1) == 0) &&
                                           (((*(uint8_t *)(puVar13 + 0xc) & 1) != 0 || ((uVar20 >> 0x14 & 1) != 0))))
                                        goto code_r0x00018010b7b2;
                                        puVar15 = (undefined4 *)((uint64_t)(unkuint3)(uVar21 >> 8) << 8);
                                        goto code_r0x00018010b7b4;
                                    }
                                }
                            } else {
code_r0x00018010b7b2:
                                puVar15 = (undefined4 *)CONCAT71((unkint7)((uint64_t)puVar15 >> 8), 1);
code_r0x00018010b7b4:
                                iVar3 = puVar13[0x8ae];
                                cVar14 = (char)puVar15;
                                if (iVar3 == 1) {
                                    if (cVar14 != '\0') {
                                        if (puVar13[0x8dc] == 0) {
                                            func_0x00018010ea60();
                                        }
                                        uVar21 = puVar13[0x8af];
                                        puVar15 = (undefined4 *)(uint64_t)uVar21;
                                        if (0 < (int32_t)uVar21) {
                                            uVar21 = uVar21 - 1;
                                            puVar15 = (undefined4 *)(uint64_t)uVar21;
                                            puVar13[0x8af] = uVar21;
                                            if (uVar21 == 0) {
                                                puVar15 = (undefined4 *)func_0x00018010eca0();
                                                puVar18 = *(undefined4 **)0x180781f28;
                                                goto code_r0x00018010b979;
                                            }
                                        }
                                    }
                                    if (puVar13[0x874] == iVar2) {
                                        puVar13[0x8af] = 1;
                                    }
                                } else if (iVar3 == -1) {
                                    if (puVar13[0x874] != iVar2) goto joined_r0x00018010b96b;
                                    if (puVar13[0x8b2] != 0) {
                                        *(undefined *)((int64_t)puVar13 + 0x2279) = 0;
                                        puVar15 = (undefined4 *)func_0x00018010ee20();
                                    }
                                } else if ((iVar3 == 0) && (cVar14 != '\0')) {
                                    puVar22 = puVar13;
                                    if (puVar13[0x874] == iVar2) {
                                        puVar15 = (undefined4 *)func_0x00018010eca0(puVar13 + 0x8b0);
                                        puVar18 = *(undefined4 **)0x180781f28;
                                    }
                                    if (puVar22[0x8dc] == 0) goto code_r0x00018010b974;
                                }
                            }
                        }
                    }
code_r0x00018010b979:
                    if (puVar13[0x874] == iVar2) {
                        if (*(int64_t *)(puVar13 + 0x876) != iVar5) {
                            if (*(int64_t *)(puVar18 + 0x876) != iVar5) {
                                *(int64_t *)(puVar18 + 0x876) = iVar5;
                                *(undefined8 *)(puVar18 + 0x88c) = 0xffffffffffffffff;
                            }
                            *(undefined2 *)(puVar18 + 0x89e) = 0;
                            *(undefined2 *)((int64_t)puVar18 + 0x2239) = 0;
                        }
                        puVar13[0x879] = *(undefined4 *)(iVar5 + 0x1b0);
                        func_0x000180106840();
                        puVar13[0x878] = puVar13[0x7dd];
                        *(undefined *)((int64_t)puVar13 + 0x21cf) = 1;
                        puVar13[0x87a] = uVar20;
                        if ((puVar13[0x7ef] & 0x200000) != 0) {
                            *(undefined8 *)(puVar13 + 0x88c) = *(undefined8 *)(puVar13 + 0x7e4);
                        }
                        fVar1 = *(float *)(iVar5 + 0x168);
                        fVar23 = *(float *)(iVar5 + 0x16c);
                        iVar16 = (int64_t)*(int32_t *)(iVar5 + 0x1b0);
                        puVar15 = (undefined4 *)(iVar16 * 2);
                        *(float *)(iVar5 + 0x458 + iVar16 * 0x10) = fVar26 - fVar1;
                        *(float *)(iVar5 + 0x45c + iVar16 * 0x10) = fVar6 - fVar23;
                        *(float *)(iVar5 + 0x460 + iVar16 * 0x10) = fVar25 - fVar1;
                        *(float *)(iVar5 + 0x464 + iVar16 * 0x10) = fVar7 - fVar23;
                        puVar18 = *(undefined4 **)0x180781f28;
                    }
                }
            }
        }
        if (((*(uint8_t *)(puVar13 + 0x7e0) & 4) != 0) && ((*(uint8_t *)(puVar18 + 0x7ef) & 0x40) == 0)) {
            if (((uint32_t)puVar18[0x7e8] >> 0x12 & 1) != 0) {
                puVar18[0x7f0] = puVar18[0x7f0] | 0x400;
                puVar18[0x801] = puVar18[0x7e7];
            }
            puVar15 = (undefined4 *)
                      fcn.180109d80((uint64_t)(uint32_t)puVar18[0x7e7], (uint64_t)(puVar18[0x7e8] & 0x3fcff), 
                                    arg2 & 0xffffffff);
            puVar22 = *(undefined4 **)0x180781f28;
            if (((char)puVar15 != '\0') && (puVar18[0x87b] == 0)) {
                puVar18[0x87b] = iVar17;
                puVar18[0x87e] = 0x11;
                puVar18[0x87d] = iVar17;
                puVar18[0x87c] = iVar17;
                puVar22[0x884] = iVar17;
                puVar22[0x885] = 0x3dcccccd;
                puVar15 = puVar22;
            }
        }
    }
    *(undefined8 *)(puVar13 + 0x7e0) = 0;
    if ((((*(float *)(arg1 + 0xc) < *(float *)(iVar4 + 700) || *(float *)(arg1 + 0xc) == *(float *)(iVar4 + 700)) ||
         (*(float *)(iVar4 + 0x2c4) < *(float *)(arg1 + 4) || *(float *)(iVar4 + 0x2c4) == *(float *)(arg1 + 4))) ||
        (fVar25 = *(float *)(arg1 + 8), fVar25 < *(float *)(iVar4 + 0x2b8) || fVar25 == *(float *)(iVar4 + 0x2b8))) ||
       (*(float *)(iVar4 + 0x2c0) < *(float *)arg1 || *(float *)(iVar4 + 0x2c0) == *(float *)arg1)) {
        bVar12 = false;
        if ((iVar17 == 0) ||
           (((iVar17 != puVar13[0x595] && (iVar17 != puVar13[0x5a0])) &&
            ((iVar17 != puVar13[0x874] && (iVar17 != puVar13[0x87b])))))) {
            if (*(char *)((int64_t)puVar13 + 0x1652) == '\0') {
                return (uint64_t)puVar15 & 0xffffffffffffff00;
            }
            goto code_r0x00018010bb69;
        }
    } else {
        bVar12 = true;
code_r0x00018010bb69:
        if (iVar17 == 0) goto code_r0x00018010bb7e;
    }
    if (puVar13[0x5a1] == iVar17) {
        puVar13[0x5a2] = puVar13[1];
    }
code_r0x00018010bb7e:
    if (bVar12) {
        puVar13[0x7f0] = puVar13[0x7f0] | 0x100;
    }
    uVar19 = 1;
    cVar14 = fcn.180108120(arg1, (int64_t)(float *)(arg1 + 8));
    if (cVar14 != '\0') {
        puVar13[0x7f0] = puVar13[0x7f0] | 1;
    }
    return uVar19 & 0xff;
}

// ============================================================
// Function: FUN_18010b650
// Address: 0x18010b650
// Size: 827 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable arg_d4h
// WARNING: [rz-ghidra] Removing arg arg_1ech because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_220h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_228h because it doesn't fit into ProtoModel

uint64_t fcn.18010b530(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_d0h, int64_t arg_118h,
                      int64_t arg_1b8h, int64_t arg_1e0h)
{
    float fVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    float fVar6;
    float fVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    bool bVar12;
    undefined4 *puVar13;
    char cVar14;
    undefined4 *puVar15;
    int64_t iVar16;
    int32_t iVar17;
    undefined4 *puVar18;
    uint64_t uVar19;
    uint32_t uVar20;
    uint32_t uVar21;
    undefined4 *puVar22;
    float fVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_84h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    puVar13 = *(undefined4 **)0x180781f28;
    puVar15 = (undefined4 *)arg1;
    if (arg3 != 0) {
        puVar15 = (undefined4 *)arg3;
    }
    iVar17 = (int32_t)arg2;
    uVar20 = (uint32_t)arg4 | (*(undefined4 **)0x180781f28)[0x7de] | (*(undefined4 **)0x180781f28)[0x7e1];
    iVar4 = *(int64_t *)(*(undefined4 **)0x180781f28 + 0x578);
    (*(undefined4 **)0x180781f28)[0x7ee] = iVar17;
    uVar8 = *(undefined4 *)(arg1 + 4);
    uVar9 = *(undefined4 *)(arg1 + 8);
    uVar10 = *(undefined4 *)(arg1 + 0xc);
    puVar13[0x7f1] = *(undefined4 *)arg1;
    puVar13[0x7f2] = uVar8;
    puVar13[0x7f3] = uVar9;
    puVar13[0x7f4] = uVar10;
    uVar8 = *puVar15;
    uVar9 = puVar15[1];
    uVar10 = puVar15[2];
    uVar11 = puVar15[3];
    puVar13[0x7ef] = uVar20;
    puVar13[0x7f0] = 0;
    puVar13[0x7f5] = uVar8;
    puVar13[0x7f6] = uVar9;
    puVar13[0x7f7] = uVar10;
    puVar13[0x7f8] = uVar11;
    if (iVar17 != 0) {
        if (puVar13[0x595] == iVar17) {
            puVar13[0x596] = iVar17;
        }
        if (puVar13[0x5a1] == iVar17) {
            *(undefined *)((int64_t)puVar13 + 0x168d) = 1;
        }
        puVar18 = puVar13;
        if ((uVar20 & 2) == 0) {
            puVar15 = (undefined4 *)(uint64_t)*(uint32_t *)(iVar4 + 0x1b0);
            *(uint16_t *)(iVar4 + 0x1b6) =
                 *(uint16_t *)(iVar4 + 0x1b6) | (uint16_t)(1 << (*(uint32_t *)(iVar4 + 0x1b0) & 0x1f));
            if ((puVar13[0x874] == iVar17) || (*(char *)((int64_t)puVar13 + 0x2239) != '\0')) {
                iVar5 = *(int64_t *)(puVar13 + 0x876);
                puVar15 = *(undefined4 **)(iVar4 + 0x438);
                if ((*(undefined4 **)(iVar5 + 0x438) == puVar15) &&
                   ((iVar4 == iVar5 ||
                    (uVar20 = *(uint32_t *)(iVar5 + 0x1c) | *(uint32_t *)(iVar4 + 0x1c),
                    puVar15 = (undefined4 *)(uint64_t)uVar20, (uVar20 >> 8 & 1) != 0)))) {
                    fVar6 = (float)puVar13[0x7f5];
                    var_78h._4_4_ = (float)puVar13[0x7f6];
                    fVar7 = (float)puVar13[0x7f7];
                    var_70h._4_4_ = (float)puVar13[0x7f8];
                    iVar5 = *(int64_t *)(puVar13 + 0x578);
                    uVar20 = puVar13[0x7ef];
                    iVar2 = puVar13[0x7ee];
                    fVar25 = fVar7;
                    fVar26 = fVar6;
                    if (*(char *)(iVar5 + 0x1b8) == '\0') {
                        fVar25 = *(float *)(iVar5 + 0x2b8);
                        fVar1 = *(float *)(iVar5 + 0x2c0);
                        fVar26 = fVar25;
                        if ((fVar25 <= fVar6) && (fVar26 = fVar1, fVar6 <= fVar1)) {
                            fVar26 = fVar6;
                        }
                        if ((fVar25 <= fVar7) && (fVar25 = fVar1, fVar7 <= fVar1)) {
                            fVar25 = fVar7;
                        }
                    }
                    var_78h._0_4_ = fVar26;
                    var_70h._0_4_ = fVar25;
                    if ((((*(char *)((int64_t)puVar13 + 0x223a) != '\0') &&
                         (puVar15 = (undefined4 *)(uint64_t)*(uint32_t *)(iVar5 + 0x1b0),
                         puVar13[0x879] == *(uint32_t *)(iVar5 + 0x1b0))) && ((uVar20 & 0x40) == 0)) &&
                       (((uVar21 = uVar20 & 4, uVar21 == 0 || (puVar13[0x892] == 0)) &&
                        (puVar15 = (undefined4 *)func_0x00018010ea60(), uVar21 == 0)))) {
                        *(undefined *)((int64_t)puVar13 + 0x223a) = 0;
                        puVar15 = (undefined4 *)func_0x00018010ee20();
                    }
                    fVar7 = var_70h._4_4_;
                    fVar6 = var_78h._4_4_;
                    if ((*(char *)((int64_t)puVar13 + 0x2279) != '\0') && ((uVar20 & 0x40) == 0)) {
                        uVar21 = puVar13[0x89f];
                        puVar15 = (undefined4 *)(uint64_t)uVar21;
                        if (((uVar21 & 0x200) != 0) || ((*(uint32_t *)(iVar5 + 0x14) & 0x10000) == 0)) {
                            if ((uVar21 >> 10 & 1) == 0) {
                                if ((puVar13[0x874] != iVar2) || ((uVar21 & 0x10) != 0)) {
                                    puVar15 = puVar13 + 0x8b0;
                                    if (iVar5 != *(int64_t *)(puVar13 + 0x876)) {
                                        puVar15 = puVar13 + 0x8cc;
                                    }
                                    puVar15 = (undefined4 *)func_0x00018010e620(puVar15, &var_78h);
                                    if ((char)puVar15 != '\0') {
                                        puVar15 = (undefined4 *)func_0x00018010ea60();
                                    }
                                    if (((((*(uint8_t *)(puVar13 + 0x89f) & 0x20) != 0) &&
                                         (fVar1 = *(float *)(iVar5 + 0x284), fVar6 < fVar1)) &&
                                        (fVar23 = *(float *)(iVar5 + 0x27c), fVar23 < fVar7)) &&
                                       ((fVar26 < *(float *)(iVar5 + 0x280) &&
                                        (*(float *)(iVar5 + 0x278) <= fVar25 && fVar25 != *(float *)(iVar5 + 0x278)))))
                                    {
                                        fVar24 = fVar23;
                                        if ((fVar23 <= fVar7) && (fVar24 = fVar1, fVar7 <= fVar1)) {
                                            fVar24 = fVar7;
                                        }
                                        if ((fVar23 <= fVar6) && (fVar23 = fVar1, fVar6 <= fVar1)) {
                                            fVar23 = fVar6;
                                        }
                                        if ((fVar7 - fVar6) * 0.7 <= fVar24 - fVar23) {
                                            puVar15 = (undefined4 *)func_0x00018010e620(puVar13 + 0x8be, &var_78h);
                                            cVar14 = (char)puVar15;
joined_r0x00018010b96b:
                                            if (cVar14 != '\0') {
code_r0x00018010b974:
                                                puVar15 = (undefined4 *)func_0x00018010ea60();
                                            }
                                        }
                                    }
                                }
                            } else if ((uVar21 & 0x200) == 0) {
                                puVar15 = *(undefined4 **)(puVar13 + 0x578);
                                if (puVar13[0x879] == puVar15[0x6c]) {
                                    uVar21 = puVar13[0x7dd];
                                    puVar15 = (undefined4 *)(uint64_t)uVar21;
                                    if (puVar13[0x878] == uVar21) {
                                        if (((uVar20 & 1) == 0) &&
                                           (((*(uint8_t *)(puVar13 + 0xc) & 1) != 0 || ((uVar20 >> 0x14 & 1) != 0))))
                                        goto code_r0x00018010b7b2;
                                        puVar15 = (undefined4 *)((uint64_t)(unkuint3)(uVar21 >> 8) << 8);
                                        goto code_r0x00018010b7b4;
                                    }
                                }
                            } else {
code_r0x00018010b7b2:
                                puVar15 = (undefined4 *)CONCAT71((unkint7)((uint64_t)puVar15 >> 8), 1);
code_r0x00018010b7b4:
                                iVar3 = puVar13[0x8ae];
                                cVar14 = (char)puVar15;
                                if (iVar3 == 1) {
                                    if (cVar14 != '\0') {
                                        if (puVar13[0x8dc] == 0) {
                                            func_0x00018010ea60();
                                        }
                                        uVar21 = puVar13[0x8af];
                                        puVar15 = (undefined4 *)(uint64_t)uVar21;
                                        if (0 < (int32_t)uVar21) {
                                            uVar21 = uVar21 - 1;
                                            puVar15 = (undefined4 *)(uint64_t)uVar21;
                                            puVar13[0x8af] = uVar21;
                                            if (uVar21 == 0) {
                                                puVar15 = (undefined4 *)func_0x00018010eca0();
                                                puVar18 = *(undefined4 **)0x180781f28;
                                                goto code_r0x00018010b979;
                                            }
                                        }
                                    }
                                    if (puVar13[0x874] == iVar2) {
                                        puVar13[0x8af] = 1;
                                    }
                                } else if (iVar3 == -1) {
                                    if (puVar13[0x874] != iVar2) goto joined_r0x00018010b96b;
                                    if (puVar13[0x8b2] != 0) {
                                        *(undefined *)((int64_t)puVar13 + 0x2279) = 0;
                                        puVar15 = (undefined4 *)func_0x00018010ee20();
                                    }
                                } else if ((iVar3 == 0) && (cVar14 != '\0')) {
                                    puVar22 = puVar13;
                                    if (puVar13[0x874] == iVar2) {
                                        puVar15 = (undefined4 *)func_0x00018010eca0(puVar13 + 0x8b0);
                                        puVar18 = *(undefined4 **)0x180781f28;
                                    }
                                    if (puVar22[0x8dc] == 0) goto code_r0x00018010b974;
                                }
                            }
                        }
                    }
code_r0x00018010b979:
                    if (puVar13[0x874] == iVar2) {
                        if (*(int64_t *)(puVar13 + 0x876) != iVar5) {
                            if (*(int64_t *)(puVar18 + 0x876) != iVar5) {
                                *(int64_t *)(puVar18 + 0x876) = iVar5;
                                *(undefined8 *)(puVar18 + 0x88c) = 0xffffffffffffffff;
                            }
                            *(undefined2 *)(puVar18 + 0x89e) = 0;
                            *(undefined2 *)((int64_t)puVar18 + 0x2239) = 0;
                        }
                        puVar13[0x879] = *(undefined4 *)(iVar5 + 0x1b0);
                        func_0x000180106840();
                        puVar13[0x878] = puVar13[0x7dd];
                        *(undefined *)((int64_t)puVar13 + 0x21cf) = 1;
                        puVar13[0x87a] = uVar20;
                        if ((puVar13[0x7ef] & 0x200000) != 0) {
                            *(undefined8 *)(puVar13 + 0x88c) = *(undefined8 *)(puVar13 + 0x7e4);
                        }
                        fVar1 = *(float *)(iVar5 + 0x168);
                        fVar23 = *(float *)(iVar5 + 0x16c);
                        iVar16 = (int64_t)*(int32_t *)(iVar5 + 0x1b0);
                        puVar15 = (undefined4 *)(iVar16 * 2);
                        *(float *)(iVar5 + 0x458 + iVar16 * 0x10) = fVar26 - fVar1;
                        *(float *)(iVar5 + 0x45c + iVar16 * 0x10) = fVar6 - fVar23;
                        *(float *)(iVar5 + 0x460 + iVar16 * 0x10) = fVar25 - fVar1;
                        *(float *)(iVar5 + 0x464 + iVar16 * 0x10) = fVar7 - fVar23;
                        puVar18 = *(undefined4 **)0x180781f28;
                    }
                }
            }
        }
        if (((*(uint8_t *)(puVar13 + 0x7e0) & 4) != 0) && ((*(uint8_t *)(puVar18 + 0x7ef) & 0x40) == 0)) {
            if (((uint32_t)puVar18[0x7e8] >> 0x12 & 1) != 0) {
                puVar18[0x7f0] = puVar18[0x7f0] | 0x400;
                puVar18[0x801] = puVar18[0x7e7];
            }
            puVar15 = (undefined4 *)
                      fcn.180109d80((uint64_t)(uint32_t)puVar18[0x7e7], (uint64_t)(puVar18[0x7e8] & 0x3fcff), 
                                    arg2 & 0xffffffff);
            puVar22 = *(undefined4 **)0x180781f28;
            if (((char)puVar15 != '\0') && (puVar18[0x87b] == 0)) {
                puVar18[0x87b] = iVar17;
                puVar18[0x87e] = 0x11;
                puVar18[0x87d] = iVar17;
                puVar18[0x87c] = iVar17;
                puVar22[0x884] = iVar17;
                puVar22[0x885] = 0x3dcccccd;
                puVar15 = puVar22;
            }
        }
    }
    *(undefined8 *)(puVar13 + 0x7e0) = 0;
    if ((((*(float *)(arg1 + 0xc) < *(float *)(iVar4 + 700) || *(float *)(arg1 + 0xc) == *(float *)(iVar4 + 700)) ||
         (*(float *)(iVar4 + 0x2c4) < *(float *)(arg1 + 4) || *(float *)(iVar4 + 0x2c4) == *(float *)(arg1 + 4))) ||
        (fVar25 = *(float *)(arg1 + 8), fVar25 < *(float *)(iVar4 + 0x2b8) || fVar25 == *(float *)(iVar4 + 0x2b8))) ||
       (*(float *)(iVar4 + 0x2c0) < *(float *)arg1 || *(float *)(iVar4 + 0x2c0) == *(float *)arg1)) {
        bVar12 = false;
        if ((iVar17 == 0) ||
           (((iVar17 != puVar13[0x595] && (iVar17 != puVar13[0x5a0])) &&
            ((iVar17 != puVar13[0x874] && (iVar17 != puVar13[0x87b])))))) {
            if (*(char *)((int64_t)puVar13 + 0x1652) == '\0') {
                return (uint64_t)puVar15 & 0xffffffffffffff00;
            }
            goto code_r0x00018010bb69;
        }
    } else {
        bVar12 = true;
code_r0x00018010bb69:
        if (iVar17 == 0) goto code_r0x00018010bb7e;
    }
    if (puVar13[0x5a1] == iVar17) {
        puVar13[0x5a2] = puVar13[1];
    }
code_r0x00018010bb7e:
    if (bVar12) {
        puVar13[0x7f0] = puVar13[0x7f0] | 0x100;
    }
    uVar19 = 1;
    cVar14 = fcn.180108120(arg1, (int64_t)(float *)(arg1 + 8));
    if (cVar14 != '\0') {
        puVar13[0x7f0] = puVar13[0x7f0] | 1;
    }
    return uVar19 & 0xff;
}

// ============================================================
// Function: FUN_18010b98b
// Address: 0x18010b98b
// Size: 256 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable arg_d4h
// WARNING: [rz-ghidra] Removing arg arg_1ech because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_220h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_228h because it doesn't fit into ProtoModel

uint64_t fcn.18010b530(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_d0h, int64_t arg_118h,
                      int64_t arg_1b8h, int64_t arg_1e0h)
{
    float fVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    float fVar6;
    float fVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    bool bVar12;
    undefined4 *puVar13;
    char cVar14;
    undefined4 *puVar15;
    int64_t iVar16;
    int32_t iVar17;
    undefined4 *puVar18;
    uint64_t uVar19;
    uint32_t uVar20;
    uint32_t uVar21;
    undefined4 *puVar22;
    float fVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_84h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    puVar13 = *(undefined4 **)0x180781f28;
    puVar15 = (undefined4 *)arg1;
    if (arg3 != 0) {
        puVar15 = (undefined4 *)arg3;
    }
    iVar17 = (int32_t)arg2;
    uVar20 = (uint32_t)arg4 | (*(undefined4 **)0x180781f28)[0x7de] | (*(undefined4 **)0x180781f28)[0x7e1];
    iVar4 = *(int64_t *)(*(undefined4 **)0x180781f28 + 0x578);
    (*(undefined4 **)0x180781f28)[0x7ee] = iVar17;
    uVar8 = *(undefined4 *)(arg1 + 4);
    uVar9 = *(undefined4 *)(arg1 + 8);
    uVar10 = *(undefined4 *)(arg1 + 0xc);
    puVar13[0x7f1] = *(undefined4 *)arg1;
    puVar13[0x7f2] = uVar8;
    puVar13[0x7f3] = uVar9;
    puVar13[0x7f4] = uVar10;
    uVar8 = *puVar15;
    uVar9 = puVar15[1];
    uVar10 = puVar15[2];
    uVar11 = puVar15[3];
    puVar13[0x7ef] = uVar20;
    puVar13[0x7f0] = 0;
    puVar13[0x7f5] = uVar8;
    puVar13[0x7f6] = uVar9;
    puVar13[0x7f7] = uVar10;
    puVar13[0x7f8] = uVar11;
    if (iVar17 != 0) {
        if (puVar13[0x595] == iVar17) {
            puVar13[0x596] = iVar17;
        }
        if (puVar13[0x5a1] == iVar17) {
            *(undefined *)((int64_t)puVar13 + 0x168d) = 1;
        }
        puVar18 = puVar13;
        if ((uVar20 & 2) == 0) {
            puVar15 = (undefined4 *)(uint64_t)*(uint32_t *)(iVar4 + 0x1b0);
            *(uint16_t *)(iVar4 + 0x1b6) =
                 *(uint16_t *)(iVar4 + 0x1b6) | (uint16_t)(1 << (*(uint32_t *)(iVar4 + 0x1b0) & 0x1f));
            if ((puVar13[0x874] == iVar17) || (*(char *)((int64_t)puVar13 + 0x2239) != '\0')) {
                iVar5 = *(int64_t *)(puVar13 + 0x876);
                puVar15 = *(undefined4 **)(iVar4 + 0x438);
                if ((*(undefined4 **)(iVar5 + 0x438) == puVar15) &&
                   ((iVar4 == iVar5 ||
                    (uVar20 = *(uint32_t *)(iVar5 + 0x1c) | *(uint32_t *)(iVar4 + 0x1c),
                    puVar15 = (undefined4 *)(uint64_t)uVar20, (uVar20 >> 8 & 1) != 0)))) {
                    fVar6 = (float)puVar13[0x7f5];
                    var_78h._4_4_ = (float)puVar13[0x7f6];
                    fVar7 = (float)puVar13[0x7f7];
                    var_70h._4_4_ = (float)puVar13[0x7f8];
                    iVar5 = *(int64_t *)(puVar13 + 0x578);
                    uVar20 = puVar13[0x7ef];
                    iVar2 = puVar13[0x7ee];
                    fVar25 = fVar7;
                    fVar26 = fVar6;
                    if (*(char *)(iVar5 + 0x1b8) == '\0') {
                        fVar25 = *(float *)(iVar5 + 0x2b8);
                        fVar1 = *(float *)(iVar5 + 0x2c0);
                        fVar26 = fVar25;
                        if ((fVar25 <= fVar6) && (fVar26 = fVar1, fVar6 <= fVar1)) {
                            fVar26 = fVar6;
                        }
                        if ((fVar25 <= fVar7) && (fVar25 = fVar1, fVar7 <= fVar1)) {
                            fVar25 = fVar7;
                        }
                    }
                    var_78h._0_4_ = fVar26;
                    var_70h._0_4_ = fVar25;
                    if ((((*(char *)((int64_t)puVar13 + 0x223a) != '\0') &&
                         (puVar15 = (undefined4 *)(uint64_t)*(uint32_t *)(iVar5 + 0x1b0),
                         puVar13[0x879] == *(uint32_t *)(iVar5 + 0x1b0))) && ((uVar20 & 0x40) == 0)) &&
                       (((uVar21 = uVar20 & 4, uVar21 == 0 || (puVar13[0x892] == 0)) &&
                        (puVar15 = (undefined4 *)func_0x00018010ea60(), uVar21 == 0)))) {
                        *(undefined *)((int64_t)puVar13 + 0x223a) = 0;
                        puVar15 = (undefined4 *)func_0x00018010ee20();
                    }
                    fVar7 = var_70h._4_4_;
                    fVar6 = var_78h._4_4_;
                    if ((*(char *)((int64_t)puVar13 + 0x2279) != '\0') && ((uVar20 & 0x40) == 0)) {
                        uVar21 = puVar13[0x89f];
                        puVar15 = (undefined4 *)(uint64_t)uVar21;
                        if (((uVar21 & 0x200) != 0) || ((*(uint32_t *)(iVar5 + 0x14) & 0x10000) == 0)) {
                            if ((uVar21 >> 10 & 1) == 0) {
                                if ((puVar13[0x874] != iVar2) || ((uVar21 & 0x10) != 0)) {
                                    puVar15 = puVar13 + 0x8b0;
                                    if (iVar5 != *(int64_t *)(puVar13 + 0x876)) {
                                        puVar15 = puVar13 + 0x8cc;
                                    }
                                    puVar15 = (undefined4 *)func_0x00018010e620(puVar15, &var_78h);
                                    if ((char)puVar15 != '\0') {
                                        puVar15 = (undefined4 *)func_0x00018010ea60();
                                    }
                                    if (((((*(uint8_t *)(puVar13 + 0x89f) & 0x20) != 0) &&
                                         (fVar1 = *(float *)(iVar5 + 0x284), fVar6 < fVar1)) &&
                                        (fVar23 = *(float *)(iVar5 + 0x27c), fVar23 < fVar7)) &&
                                       ((fVar26 < *(float *)(iVar5 + 0x280) &&
                                        (*(float *)(iVar5 + 0x278) <= fVar25 && fVar25 != *(float *)(iVar5 + 0x278)))))
                                    {
                                        fVar24 = fVar23;
                                        if ((fVar23 <= fVar7) && (fVar24 = fVar1, fVar7 <= fVar1)) {
                                            fVar24 = fVar7;
                                        }
                                        if ((fVar23 <= fVar6) && (fVar23 = fVar1, fVar6 <= fVar1)) {
                                            fVar23 = fVar6;
                                        }
                                        if ((fVar7 - fVar6) * 0.7 <= fVar24 - fVar23) {
                                            puVar15 = (undefined4 *)func_0x00018010e620(puVar13 + 0x8be, &var_78h);
                                            cVar14 = (char)puVar15;
joined_r0x00018010b96b:
                                            if (cVar14 != '\0') {
code_r0x00018010b974:
                                                puVar15 = (undefined4 *)func_0x00018010ea60();
                                            }
                                        }
                                    }
                                }
                            } else if ((uVar21 & 0x200) == 0) {
                                puVar15 = *(undefined4 **)(puVar13 + 0x578);
                                if (puVar13[0x879] == puVar15[0x6c]) {
                                    uVar21 = puVar13[0x7dd];
                                    puVar15 = (undefined4 *)(uint64_t)uVar21;
                                    if (puVar13[0x878] == uVar21) {
                                        if (((uVar20 & 1) == 0) &&
                                           (((*(uint8_t *)(puVar13 + 0xc) & 1) != 0 || ((uVar20 >> 0x14 & 1) != 0))))
                                        goto code_r0x00018010b7b2;
                                        puVar15 = (undefined4 *)((uint64_t)(unkuint3)(uVar21 >> 8) << 8);
                                        goto code_r0x00018010b7b4;
                                    }
                                }
                            } else {
code_r0x00018010b7b2:
                                puVar15 = (undefined4 *)CONCAT71((unkint7)((uint64_t)puVar15 >> 8), 1);
code_r0x00018010b7b4:
                                iVar3 = puVar13[0x8ae];
                                cVar14 = (char)puVar15;
                                if (iVar3 == 1) {
                                    if (cVar14 != '\0') {
                                        if (puVar13[0x8dc] == 0) {
                                            func_0x00018010ea60();
                                        }
                                        uVar21 = puVar13[0x8af];
                                        puVar15 = (undefined4 *)(uint64_t)uVar21;
                                        if (0 < (int32_t)uVar21) {
                                            uVar21 = uVar21 - 1;
                                            puVar15 = (undefined4 *)(uint64_t)uVar21;
                                            puVar13[0x8af] = uVar21;
                                            if (uVar21 == 0) {
                                                puVar15 = (undefined4 *)func_0x00018010eca0();
                                                puVar18 = *(undefined4 **)0x180781f28;
                                                goto code_r0x00018010b979;
                                            }
                                        }
                                    }
                                    if (puVar13[0x874] == iVar2) {
                                        puVar13[0x8af] = 1;
                                    }
                                } else if (iVar3 == -1) {
                                    if (puVar13[0x874] != iVar2) goto joined_r0x00018010b96b;
                                    if (puVar13[0x8b2] != 0) {
                                        *(undefined *)((int64_t)puVar13 + 0x2279) = 0;
                                        puVar15 = (undefined4 *)func_0x00018010ee20();
                                    }
                                } else if ((iVar3 == 0) && (cVar14 != '\0')) {
                                    puVar22 = puVar13;
                                    if (puVar13[0x874] == iVar2) {
                                        puVar15 = (undefined4 *)func_0x00018010eca0(puVar13 + 0x8b0);
                                        puVar18 = *(undefined4 **)0x180781f28;
                                    }
                                    if (puVar22[0x8dc] == 0) goto code_r0x00018010b974;
                                }
                            }
                        }
                    }
code_r0x00018010b979:
                    if (puVar13[0x874] == iVar2) {
                        if (*(int64_t *)(puVar13 + 0x876) != iVar5) {
                            if (*(int64_t *)(puVar18 + 0x876) != iVar5) {
                                *(int64_t *)(puVar18 + 0x876) = iVar5;
                                *(undefined8 *)(puVar18 + 0x88c) = 0xffffffffffffffff;
                            }
                            *(undefined2 *)(puVar18 + 0x89e) = 0;
                            *(undefined2 *)((int64_t)puVar18 + 0x2239) = 0;
                        }
                        puVar13[0x879] = *(undefined4 *)(iVar5 + 0x1b0);
                        func_0x000180106840();
                        puVar13[0x878] = puVar13[0x7dd];
                        *(undefined *)((int64_t)puVar13 + 0x21cf) = 1;
                        puVar13[0x87a] = uVar20;
                        if ((puVar13[0x7ef] & 0x200000) != 0) {
                            *(undefined8 *)(puVar13 + 0x88c) = *(undefined8 *)(puVar13 + 0x7e4);
                        }
                        fVar1 = *(float *)(iVar5 + 0x168);
                        fVar23 = *(float *)(iVar5 + 0x16c);
                        iVar16 = (int64_t)*(int32_t *)(iVar5 + 0x1b0);
                        puVar15 = (undefined4 *)(iVar16 * 2);
                        *(float *)(iVar5 + 0x458 + iVar16 * 0x10) = fVar26 - fVar1;
                        *(float *)(iVar5 + 0x45c + iVar16 * 0x10) = fVar6 - fVar23;
                        *(float *)(iVar5 + 0x460 + iVar16 * 0x10) = fVar25 - fVar1;
                        *(float *)(iVar5 + 0x464 + iVar16 * 0x10) = fVar7 - fVar23;
                        puVar18 = *(undefined4 **)0x180781f28;
                    }
                }
            }
        }
        if (((*(uint8_t *)(puVar13 + 0x7e0) & 4) != 0) && ((*(uint8_t *)(puVar18 + 0x7ef) & 0x40) == 0)) {
            if (((uint32_t)puVar18[0x7e8] >> 0x12 & 1) != 0) {
                puVar18[0x7f0] = puVar18[0x7f0] | 0x400;
                puVar18[0x801] = puVar18[0x7e7];
            }
            puVar15 = (undefined4 *)
                      fcn.180109d80((uint64_t)(uint32_t)puVar18[0x7e7], (uint64_t)(puVar18[0x7e8] & 0x3fcff), 
                                    arg2 & 0xffffffff);
            puVar22 = *(undefined4 **)0x180781f28;
            if (((char)puVar15 != '\0') && (puVar18[0x87b] == 0)) {
                puVar18[0x87b] = iVar17;
                puVar18[0x87e] = 0x11;
                puVar18[0x87d] = iVar17;
                puVar18[0x87c] = iVar17;
                puVar22[0x884] = iVar17;
                puVar22[0x885] = 0x3dcccccd;
                puVar15 = puVar22;
            }
        }
    }
    *(undefined8 *)(puVar13 + 0x7e0) = 0;
    if ((((*(float *)(arg1 + 0xc) < *(float *)(iVar4 + 700) || *(float *)(arg1 + 0xc) == *(float *)(iVar4 + 700)) ||
         (*(float *)(iVar4 + 0x2c4) < *(float *)(arg1 + 4) || *(float *)(iVar4 + 0x2c4) == *(float *)(arg1 + 4))) ||
        (fVar25 = *(float *)(arg1 + 8), fVar25 < *(float *)(iVar4 + 0x2b8) || fVar25 == *(float *)(iVar4 + 0x2b8))) ||
       (*(float *)(iVar4 + 0x2c0) < *(float *)arg1 || *(float *)(iVar4 + 0x2c0) == *(float *)arg1)) {
        bVar12 = false;
        if ((iVar17 == 0) ||
           (((iVar17 != puVar13[0x595] && (iVar17 != puVar13[0x5a0])) &&
            ((iVar17 != puVar13[0x874] && (iVar17 != puVar13[0x87b])))))) {
            if (*(char *)((int64_t)puVar13 + 0x1652) == '\0') {
                return (uint64_t)puVar15 & 0xffffffffffffff00;
            }
            goto code_r0x00018010bb69;
        }
    } else {
        bVar12 = true;
code_r0x00018010bb69:
        if (iVar17 == 0) goto code_r0x00018010bb7e;
    }
    if (puVar13[0x5a1] == iVar17) {
        puVar13[0x5a2] = puVar13[1];
    }
code_r0x00018010bb7e:
    if (bVar12) {
        puVar13[0x7f0] = puVar13[0x7f0] | 0x100;
    }
    uVar19 = 1;
    cVar14 = fcn.180108120(arg1, (int64_t)(float *)(arg1 + 8));
    if (cVar14 != '\0') {
        puVar13[0x7f0] = puVar13[0x7f0] | 1;
    }
    return uVar19 & 0xff;
}

