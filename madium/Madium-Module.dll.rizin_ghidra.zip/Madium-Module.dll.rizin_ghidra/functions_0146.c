// Chunk 146 - 50 functions

// ============================================================
// Function: FUN_1801efbc0
// Address: 0x1801efbc0
// Size: 213 bytes
// ============================================================
undefined8 fcn.1801efbc0(int64_t arg_38h)
{
    uint8_t uVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined *puVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    uint64_t uVar10;
    undefined8 *in_RDX;
    uint64_t uVar11;
    int64_t iVar12;
    undefined8 unaff_RBX;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801efbcc;
    iVar9 = func_0x00018045a350();
    iVar9 = -iVar9;
    puVar7 = (undefined *)*in_RDX;
    uVar2 = in_RDX[1];
    uVar11 = in_RDX[1];
    *(undefined **)((int64_t)&var_18h + iVar9) = puVar7;
    *(undefined8 *)((int64_t)&var_20h + iVar9) = uVar2;
    if (1 < uVar11) {
        uVar11 = uVar11 - 2;
        uVar1 = puVar7[1];
        uVar10 = (uint64_t)CONCAT11(*puVar7, uVar1);
        if (uVar10 <= uVar11) {
            iVar12 = uVar11 - uVar10;
            *(undefined **)((int64_t)&var_18h + iVar9) = puVar7 + 2 + uVar10;
            *(int64_t *)((int64_t)&var_20h + iVar9) = iVar12;
            if (iVar12 == 0) {
                uVar3 = *(undefined4 *)((int64_t)&var_18h + iVar9);
                uVar4 = *(undefined4 *)((int64_t)&var_18h + iVar9 + 4);
                uVar5 = *(undefined4 *)((int64_t)&var_20h + iVar9);
                uVar6 = *(undefined4 *)((int64_t)&var_20h + iVar9 + 4);
                *(undefined **)((int64_t)&var_18h + iVar9) = puVar7 + 2;
                *(uint64_t *)((int64_t)&var_20h + iVar9) = uVar10;
                *(undefined4 *)in_RDX = uVar3;
                *(undefined4 *)((int64_t)in_RDX + 4) = uVar4;
                *(undefined4 *)(in_RDX + 1) = uVar5;
                *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar6;
                if ((uVar10 != 0) && ((uVar1 & 1) == 0)) {
                    if ((*(int32_t *)(in_RCX + 0x508) == 0) ||
                       ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0 &&
                         (iVar8 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar8)) && (iVar8 != 0x10000)))) {
                        uVar2 = *(undefined8 *)(in_RCX + 0xaa0);
                        *(undefined8 *)((int64_t)&arg_38h + iVar9) = unaff_RBX;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801efc9f;
                        func_0x000180224990(uVar2, 0x1804b7630, 0x4d1);
                        *(undefined8 *)(in_RCX + 0xaa0) = 0;
                        *(undefined8 *)(in_RCX + 0xa98) = 0;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801efcc3;
                        iVar8 = func_0x0001801ab930((int64_t)&var_18h + iVar9, in_RCX + 0xaa0);
                        if (iVar8 == 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801efcd1;
                            func_0x000180229480();
                            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801efce9;
                            func_0x0001802295a0(0x1804b7630, 0x4d7, 0x1804b77f8);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801efcff;
                            func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
                            return 0;
                        }
                    }
                    return 1;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801efd17;
    func_0x000180229480();
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801efd2f;
    func_0x0001802295a0(0x1804b7630, 0x4cc, 0x1804b77f8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801efd45;
    func_0x00018019b5e0(in_RCX, 0x32, 0x6e, 0);
    return 0;
}

// ============================================================
// Function: FUN_1801efc95
// Address: 0x1801efc95
// Size: 55 bytes
// ============================================================
undefined8 fcn.1801efbc0(int64_t arg_38h)
{
    uint8_t uVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined *puVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    uint64_t uVar10;
    undefined8 *in_RDX;
    uint64_t uVar11;
    int64_t iVar12;
    undefined8 unaff_RBX;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801efbcc;
    iVar9 = func_0x00018045a350();
    iVar9 = -iVar9;
    puVar7 = (undefined *)*in_RDX;
    uVar2 = in_RDX[1];
    uVar11 = in_RDX[1];
    *(undefined **)((int64_t)&var_18h + iVar9) = puVar7;
    *(undefined8 *)((int64_t)&var_20h + iVar9) = uVar2;
    if (1 < uVar11) {
        uVar11 = uVar11 - 2;
        uVar1 = puVar7[1];
        uVar10 = (uint64_t)CONCAT11(*puVar7, uVar1);
        if (uVar10 <= uVar11) {
            iVar12 = uVar11 - uVar10;
            *(undefined **)((int64_t)&var_18h + iVar9) = puVar7 + 2 + uVar10;
            *(int64_t *)((int64_t)&var_20h + iVar9) = iVar12;
            if (iVar12 == 0) {
                uVar3 = *(undefined4 *)((int64_t)&var_18h + iVar9);
                uVar4 = *(undefined4 *)((int64_t)&var_18h + iVar9 + 4);
                uVar5 = *(undefined4 *)((int64_t)&var_20h + iVar9);
                uVar6 = *(undefined4 *)((int64_t)&var_20h + iVar9 + 4);
                *(undefined **)((int64_t)&var_18h + iVar9) = puVar7 + 2;
                *(uint64_t *)((int64_t)&var_20h + iVar9) = uVar10;
                *(undefined4 *)in_RDX = uVar3;
                *(undefined4 *)((int64_t)in_RDX + 4) = uVar4;
                *(undefined4 *)(in_RDX + 1) = uVar5;
                *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar6;
                if ((uVar10 != 0) && ((uVar1 & 1) == 0)) {
                    if ((*(int32_t *)(in_RCX + 0x508) == 0) ||
                       ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0 &&
                         (iVar8 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar8)) && (iVar8 != 0x10000)))) {
                        uVar2 = *(undefined8 *)(in_RCX + 0xaa0);
                        *(undefined8 *)((int64_t)&arg_38h + iVar9) = unaff_RBX;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801efc9f;
                        func_0x000180224990(uVar2, 0x1804b7630, 0x4d1);
                        *(undefined8 *)(in_RCX + 0xaa0) = 0;
                        *(undefined8 *)(in_RCX + 0xa98) = 0;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801efcc3;
                        iVar8 = func_0x0001801ab930((int64_t)&var_18h + iVar9, in_RCX + 0xaa0);
                        if (iVar8 == 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801efcd1;
                            func_0x000180229480();
                            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801efce9;
                            func_0x0001802295a0(0x1804b7630, 0x4d7, 0x1804b77f8);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801efcff;
                            func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
                            return 0;
                        }
                    }
                    return 1;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801efd17;
    func_0x000180229480();
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801efd2f;
    func_0x0001802295a0(0x1804b7630, 0x4cc, 0x1804b77f8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801efd45;
    func_0x00018019b5e0(in_RCX, 0x32, 0x6e, 0);
    return 0;
}

// ============================================================
// Function: FUN_1801efccc
// Address: 0x1801efccc
// Size: 129 bytes
// ============================================================
undefined8 fcn.1801efbc0(int64_t arg_38h)
{
    uint8_t uVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined *puVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    uint64_t uVar10;
    undefined8 *in_RDX;
    uint64_t uVar11;
    int64_t iVar12;
    undefined8 unaff_RBX;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801efbcc;
    iVar9 = func_0x00018045a350();
    iVar9 = -iVar9;
    puVar7 = (undefined *)*in_RDX;
    uVar2 = in_RDX[1];
    uVar11 = in_RDX[1];
    *(undefined **)((int64_t)&var_18h + iVar9) = puVar7;
    *(undefined8 *)((int64_t)&var_20h + iVar9) = uVar2;
    if (1 < uVar11) {
        uVar11 = uVar11 - 2;
        uVar1 = puVar7[1];
        uVar10 = (uint64_t)CONCAT11(*puVar7, uVar1);
        if (uVar10 <= uVar11) {
            iVar12 = uVar11 - uVar10;
            *(undefined **)((int64_t)&var_18h + iVar9) = puVar7 + 2 + uVar10;
            *(int64_t *)((int64_t)&var_20h + iVar9) = iVar12;
            if (iVar12 == 0) {
                uVar3 = *(undefined4 *)((int64_t)&var_18h + iVar9);
                uVar4 = *(undefined4 *)((int64_t)&var_18h + iVar9 + 4);
                uVar5 = *(undefined4 *)((int64_t)&var_20h + iVar9);
                uVar6 = *(undefined4 *)((int64_t)&var_20h + iVar9 + 4);
                *(undefined **)((int64_t)&var_18h + iVar9) = puVar7 + 2;
                *(uint64_t *)((int64_t)&var_20h + iVar9) = uVar10;
                *(undefined4 *)in_RDX = uVar3;
                *(undefined4 *)((int64_t)in_RDX + 4) = uVar4;
                *(undefined4 *)(in_RDX + 1) = uVar5;
                *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar6;
                if ((uVar10 != 0) && ((uVar1 & 1) == 0)) {
                    if ((*(int32_t *)(in_RCX + 0x508) == 0) ||
                       ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0 &&
                         (iVar8 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar8)) && (iVar8 != 0x10000)))) {
                        uVar2 = *(undefined8 *)(in_RCX + 0xaa0);
                        *(undefined8 *)((int64_t)&arg_38h + iVar9) = unaff_RBX;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801efc9f;
                        func_0x000180224990(uVar2, 0x1804b7630, 0x4d1);
                        *(undefined8 *)(in_RCX + 0xaa0) = 0;
                        *(undefined8 *)(in_RCX + 0xa98) = 0;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801efcc3;
                        iVar8 = func_0x0001801ab930((int64_t)&var_18h + iVar9, in_RCX + 0xaa0);
                        if (iVar8 == 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801efcd1;
                            func_0x000180229480();
                            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801efce9;
                            func_0x0001802295a0(0x1804b7630, 0x4d7, 0x1804b77f8);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801efcff;
                            func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
                            return 0;
                        }
                    }
                    return 1;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801efd17;
    func_0x000180229480();
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801efd2f;
    func_0x0001802295a0(0x1804b7630, 0x4cc, 0x1804b77f8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801efd45;
    func_0x00018019b5e0(in_RCX, 0x32, 0x6e, 0);
    return 0;
}

// ============================================================
// Function: FUN_1801efd50
// Address: 0x1801efd50
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_fh

undefined8 fcn.1801efd50(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    uint8_t uVar1;
    uint8_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    uint8_t *puVar7;
    int64_t in_RCX;
    uint32_t uVar8;
    uint8_t **in_RDX;
    int32_t iVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint8_t *puVar10;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    uint8_t *puVar11;
    undefined8 unaff_R15;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    int64_t var_10h;
    
    uStack_18 = 0x1801efd5e;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efd6c;
    iVar5 = fcn.18020bb40();
    if (iVar5 == 0) {
        return 1;
    }
    puVar7 = in_RDX[1];
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar4) = unaff_R14;
    if ((uint8_t *)0x1 < puVar7) {
        puVar11 = *in_RDX;
        puVar10 = puVar11 + 2;
        uVar1 = puVar11[1];
        puVar7 = puVar7 + -2;
        uVar8 = (uint32_t)CONCAT11(*puVar11, uVar1);
        *in_RDX = puVar10;
        in_RDX[1] = puVar7;
        if (((uVar1 & 1) == 0) && (puVar11 = (uint8_t *)(uint64_t)uVar8, puVar11 <= puVar7)) {
            *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_RDI;
            in_RDX[1] = puVar7 + -(int64_t)puVar11;
            *(undefined8 *)((int64_t)&iStackX_10 + iVar4) = unaff_R15;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RSI;
            *in_RDX = puVar10 + uVar8;
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efdfa;
            uVar6 = fcn.18020bb40(in_RCX);
            *(undefined8 *)(in_RCX + 0xb98) = 0;
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efe10;
            iVar3 = fcn.180222010(uVar6);
            do {
                if (puVar11 == (uint8_t *)0x0) {
                    if (in_RDX[1] == (uint8_t *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efe79;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                                      *(int64_t *)((int64_t)&var_18h + iVar4));
code_r0x0001801efe85:
                        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efe91;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4));
                    } else {
                        puVar10 = (uint8_t *)(uint64_t)**in_RDX;
                        puVar7 = *in_RDX + 1;
                        puVar11 = in_RDX[1] + -1;
                        *in_RDX = puVar7;
                        in_RDX[1] = puVar11;
                        if (puVar10 <= puVar11) {
                            *in_RDX = puVar7 + (int64_t)puVar10;
                            in_RDX[1] = puVar11 + -(int64_t)puVar10;
                            if (puVar11 + -(int64_t)puVar10 == (uint8_t *)0x0) {
                                return 1;
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801eff1b;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                                      *(int64_t *)((int64_t)&var_18h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801eff33;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4));
                    }
                    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efea7;
                    fcn.18019b5e0(*(int64_t *)(&stack0x00000030 + iVar4));
                    return 0;
                }
                if (puVar11 < (uint8_t *)0x2) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efed5;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4));
                    goto code_r0x0001801efe85;
                }
                uVar1 = *puVar10;
                puVar11 = puVar11 + -2;
                uVar2 = puVar10[1];
                iVar9 = 0;
                puVar10 = puVar10 + 2;
                if (0 < iVar3) {
                    do {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efe4f;
                        iVar5 = fcn.180222340(uVar6, iVar9);
                        if (*(uint32_t *)(iVar5 + 8) == (uint32_t)CONCAT11(uVar1, uVar2)) {
                            *(int64_t *)(in_RCX + 0xb98) = iVar5;
                            iVar3 = iVar9;
                            break;
                        }
                        iVar9 = iVar9 + 1;
                    } while (iVar9 < iVar3);
                }
            } while( true );
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801eff43;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4));
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801eff5b;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4), 
                  *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                  *(int64_t *)((int64_t)&arg_40h + iVar4));
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801eff71;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000030 + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_1801efd84
// Address: 0x1801efd84
// Size: 332 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_fh

undefined8 fcn.1801efd50(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    uint8_t uVar1;
    uint8_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    uint8_t *puVar7;
    int64_t in_RCX;
    uint32_t uVar8;
    uint8_t **in_RDX;
    int32_t iVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint8_t *puVar10;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    uint8_t *puVar11;
    undefined8 unaff_R15;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    int64_t var_10h;
    
    uStack_18 = 0x1801efd5e;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efd6c;
    iVar5 = fcn.18020bb40();
    if (iVar5 == 0) {
        return 1;
    }
    puVar7 = in_RDX[1];
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar4) = unaff_R14;
    if ((uint8_t *)0x1 < puVar7) {
        puVar11 = *in_RDX;
        puVar10 = puVar11 + 2;
        uVar1 = puVar11[1];
        puVar7 = puVar7 + -2;
        uVar8 = (uint32_t)CONCAT11(*puVar11, uVar1);
        *in_RDX = puVar10;
        in_RDX[1] = puVar7;
        if (((uVar1 & 1) == 0) && (puVar11 = (uint8_t *)(uint64_t)uVar8, puVar11 <= puVar7)) {
            *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_RDI;
            in_RDX[1] = puVar7 + -(int64_t)puVar11;
            *(undefined8 *)((int64_t)&iStackX_10 + iVar4) = unaff_R15;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RSI;
            *in_RDX = puVar10 + uVar8;
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efdfa;
            uVar6 = fcn.18020bb40(in_RCX);
            *(undefined8 *)(in_RCX + 0xb98) = 0;
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efe10;
            iVar3 = fcn.180222010(uVar6);
            do {
                if (puVar11 == (uint8_t *)0x0) {
                    if (in_RDX[1] == (uint8_t *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efe79;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                                      *(int64_t *)((int64_t)&var_18h + iVar4));
code_r0x0001801efe85:
                        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efe91;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4));
                    } else {
                        puVar10 = (uint8_t *)(uint64_t)**in_RDX;
                        puVar7 = *in_RDX + 1;
                        puVar11 = in_RDX[1] + -1;
                        *in_RDX = puVar7;
                        in_RDX[1] = puVar11;
                        if (puVar10 <= puVar11) {
                            *in_RDX = puVar7 + (int64_t)puVar10;
                            in_RDX[1] = puVar11 + -(int64_t)puVar10;
                            if (puVar11 + -(int64_t)puVar10 == (uint8_t *)0x0) {
                                return 1;
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801eff1b;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                                      *(int64_t *)((int64_t)&var_18h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801eff33;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4));
                    }
                    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efea7;
                    fcn.18019b5e0(*(int64_t *)(&stack0x00000030 + iVar4));
                    return 0;
                }
                if (puVar11 < (uint8_t *)0x2) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efed5;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4));
                    goto code_r0x0001801efe85;
                }
                uVar1 = *puVar10;
                puVar11 = puVar11 + -2;
                uVar2 = puVar10[1];
                iVar9 = 0;
                puVar10 = puVar10 + 2;
                if (0 < iVar3) {
                    do {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efe4f;
                        iVar5 = fcn.180222340(uVar6, iVar9);
                        if (*(uint32_t *)(iVar5 + 8) == (uint32_t)CONCAT11(uVar1, uVar2)) {
                            *(int64_t *)(in_RCX + 0xb98) = iVar5;
                            iVar3 = iVar9;
                            break;
                        }
                        iVar9 = iVar9 + 1;
                    } while (iVar9 < iVar3);
                }
            } while( true );
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801eff43;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4));
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801eff5b;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4), 
                  *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                  *(int64_t *)((int64_t)&arg_40h + iVar4));
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801eff71;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000030 + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_1801efed0
// Address: 0x1801efed0
// Size: 110 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_fh

undefined8 fcn.1801efd50(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    uint8_t uVar1;
    uint8_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    uint8_t *puVar7;
    int64_t in_RCX;
    uint32_t uVar8;
    uint8_t **in_RDX;
    int32_t iVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint8_t *puVar10;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    uint8_t *puVar11;
    undefined8 unaff_R15;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    int64_t var_10h;
    
    uStack_18 = 0x1801efd5e;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efd6c;
    iVar5 = fcn.18020bb40();
    if (iVar5 == 0) {
        return 1;
    }
    puVar7 = in_RDX[1];
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar4) = unaff_R14;
    if ((uint8_t *)0x1 < puVar7) {
        puVar11 = *in_RDX;
        puVar10 = puVar11 + 2;
        uVar1 = puVar11[1];
        puVar7 = puVar7 + -2;
        uVar8 = (uint32_t)CONCAT11(*puVar11, uVar1);
        *in_RDX = puVar10;
        in_RDX[1] = puVar7;
        if (((uVar1 & 1) == 0) && (puVar11 = (uint8_t *)(uint64_t)uVar8, puVar11 <= puVar7)) {
            *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_RDI;
            in_RDX[1] = puVar7 + -(int64_t)puVar11;
            *(undefined8 *)((int64_t)&iStackX_10 + iVar4) = unaff_R15;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RSI;
            *in_RDX = puVar10 + uVar8;
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efdfa;
            uVar6 = fcn.18020bb40(in_RCX);
            *(undefined8 *)(in_RCX + 0xb98) = 0;
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efe10;
            iVar3 = fcn.180222010(uVar6);
            do {
                if (puVar11 == (uint8_t *)0x0) {
                    if (in_RDX[1] == (uint8_t *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efe79;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                                      *(int64_t *)((int64_t)&var_18h + iVar4));
code_r0x0001801efe85:
                        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efe91;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4));
                    } else {
                        puVar10 = (uint8_t *)(uint64_t)**in_RDX;
                        puVar7 = *in_RDX + 1;
                        puVar11 = in_RDX[1] + -1;
                        *in_RDX = puVar7;
                        in_RDX[1] = puVar11;
                        if (puVar10 <= puVar11) {
                            *in_RDX = puVar7 + (int64_t)puVar10;
                            in_RDX[1] = puVar11 + -(int64_t)puVar10;
                            if (puVar11 + -(int64_t)puVar10 == (uint8_t *)0x0) {
                                return 1;
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801eff1b;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                                      *(int64_t *)((int64_t)&var_18h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801eff33;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4));
                    }
                    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efea7;
                    fcn.18019b5e0(*(int64_t *)(&stack0x00000030 + iVar4));
                    return 0;
                }
                if (puVar11 < (uint8_t *)0x2) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efed5;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4));
                    goto code_r0x0001801efe85;
                }
                uVar1 = *puVar10;
                puVar11 = puVar11 + -2;
                uVar2 = puVar10[1];
                iVar9 = 0;
                puVar10 = puVar10 + 2;
                if (0 < iVar3) {
                    do {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efe4f;
                        iVar5 = fcn.180222340(uVar6, iVar9);
                        if (*(uint32_t *)(iVar5 + 8) == (uint32_t)CONCAT11(uVar1, uVar2)) {
                            *(int64_t *)(in_RCX + 0xb98) = iVar5;
                            iVar3 = iVar9;
                            break;
                        }
                        iVar9 = iVar9 + 1;
                    } while (iVar9 < iVar3);
                }
            } while( true );
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801eff43;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4));
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801eff5b;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4), 
                  *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                  *(int64_t *)((int64_t)&arg_40h + iVar4));
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801eff71;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000030 + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_1801eff3e
// Address: 0x1801eff3e
// Size: 72 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_fh

undefined8 fcn.1801efd50(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    uint8_t uVar1;
    uint8_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    uint8_t *puVar7;
    int64_t in_RCX;
    uint32_t uVar8;
    uint8_t **in_RDX;
    int32_t iVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint8_t *puVar10;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    uint8_t *puVar11;
    undefined8 unaff_R15;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    int64_t var_10h;
    
    uStack_18 = 0x1801efd5e;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efd6c;
    iVar5 = fcn.18020bb40();
    if (iVar5 == 0) {
        return 1;
    }
    puVar7 = in_RDX[1];
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar4) = unaff_R14;
    if ((uint8_t *)0x1 < puVar7) {
        puVar11 = *in_RDX;
        puVar10 = puVar11 + 2;
        uVar1 = puVar11[1];
        puVar7 = puVar7 + -2;
        uVar8 = (uint32_t)CONCAT11(*puVar11, uVar1);
        *in_RDX = puVar10;
        in_RDX[1] = puVar7;
        if (((uVar1 & 1) == 0) && (puVar11 = (uint8_t *)(uint64_t)uVar8, puVar11 <= puVar7)) {
            *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_RDI;
            in_RDX[1] = puVar7 + -(int64_t)puVar11;
            *(undefined8 *)((int64_t)&iStackX_10 + iVar4) = unaff_R15;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RSI;
            *in_RDX = puVar10 + uVar8;
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efdfa;
            uVar6 = fcn.18020bb40(in_RCX);
            *(undefined8 *)(in_RCX + 0xb98) = 0;
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efe10;
            iVar3 = fcn.180222010(uVar6);
            do {
                if (puVar11 == (uint8_t *)0x0) {
                    if (in_RDX[1] == (uint8_t *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efe79;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                                      *(int64_t *)((int64_t)&var_18h + iVar4));
code_r0x0001801efe85:
                        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efe91;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4));
                    } else {
                        puVar10 = (uint8_t *)(uint64_t)**in_RDX;
                        puVar7 = *in_RDX + 1;
                        puVar11 = in_RDX[1] + -1;
                        *in_RDX = puVar7;
                        in_RDX[1] = puVar11;
                        if (puVar10 <= puVar11) {
                            *in_RDX = puVar7 + (int64_t)puVar10;
                            in_RDX[1] = puVar11 + -(int64_t)puVar10;
                            if (puVar11 + -(int64_t)puVar10 == (uint8_t *)0x0) {
                                return 1;
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801eff1b;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                                      *(int64_t *)((int64_t)&var_18h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801eff33;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4));
                    }
                    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efea7;
                    fcn.18019b5e0(*(int64_t *)(&stack0x00000030 + iVar4));
                    return 0;
                }
                if (puVar11 < (uint8_t *)0x2) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efed5;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4));
                    goto code_r0x0001801efe85;
                }
                uVar1 = *puVar10;
                puVar11 = puVar11 + -2;
                uVar2 = puVar10[1];
                iVar9 = 0;
                puVar10 = puVar10 + 2;
                if (0 < iVar3) {
                    do {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801efe4f;
                        iVar5 = fcn.180222340(uVar6, iVar9);
                        if (*(uint32_t *)(iVar5 + 8) == (uint32_t)CONCAT11(uVar1, uVar2)) {
                            *(int64_t *)(in_RCX + 0xb98) = iVar5;
                            iVar3 = iVar9;
                            break;
                        }
                        iVar9 = iVar9 + 1;
                    } while (iVar9 < iVar3);
                }
            } while( true );
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801eff43;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4));
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801eff5b;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4), 
                  *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                  *(int64_t *)((int64_t)&arg_40h + iVar4));
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801eff71;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000030 + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_1801eff90
// Address: 0x1801eff90
// Size: 483 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801eff90(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint64_t in_R8;
    uint64_t in_R9;
    undefined8 unaff_R12;
    undefined2 uVar5;
    undefined8 unaff_R15;
    int64_t aiStackX_8 [3];
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801effa6;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = 0;
    uVar5 = (undefined2)(in_R8 & 0xffffffff);
    if (in_R9 < *(uint64_t *)(in_RCX + 0x338)) {
        if ((*(int32_t *)(in_RCX + 0x8c8) != 1) || (iVar3 = *(int64_t *)(in_RCX + 0x310 + in_R9 * 8), iVar3 == 0)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801effe8;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar2), *(int64_t *)(&stack0x00000000 + iVar2));
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801f0000;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar2), *(int64_t *)(&stack0x00000000 + iVar2), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar2), *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2));
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801f0016;
            fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_8 + iVar2 + 0x10));
            return 0;
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801f0036;
        iVar3 = func_0x0001801c6720();
        if (iVar3 == 0) {
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801f0061;
    iVar4 = func_0x00018022eef0(iVar3, (int64_t)&arg_28h + iVar2);
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801f0089;
        iVar1 = func_0x0001802446f0(in_RDX, in_R8 & 0xffffffff, 2);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801f00a3;
            iVar1 = func_0x000180244bf0(in_RDX, *(undefined8 *)((int64_t)&arg_28h + iVar2), iVar4, 2);
            if (iVar1 != 0) {
                if (in_R9 == 0) {
                    *(int64_t *)(in_RCX + 0x308) = iVar3;
                    *(undefined2 *)(in_RCX + 0x4de) = uVar5;
                }
                *(int64_t *)(in_RCX + (in_R9 + 0x62) * 8) = iVar3;
                *(undefined2 *)(in_RCX + 0x330 + in_R9 * 2) = uVar5;
                if (*(uint64_t *)(in_RCX + 0x338) <= in_R9) {
                    *(uint64_t *)(in_RCX + 0x338) = *(uint64_t *)(in_RCX + 0x338) + 1;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801f00f3;
                func_0x000180224990(*(undefined8 *)((int64_t)&arg_28h + iVar2), 0x1804b7ba0, 0x2b6);
                return 1;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801f0109;
    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar2), *(int64_t *)(&stack0x00000000 + iVar2));
    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801f011e;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar2), *(int64_t *)(&stack0x00000000 + iVar2), 
                  *(int64_t *)((int64_t)aiStackX_8 + iVar2), *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2));
    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801f0131;
    fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_8 + iVar2 + 0x10));
    if (iVar3 != *(int64_t *)(in_RCX + (in_R9 + 0x62) * 8)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801f013f;
        func_0x00018022ecc0(iVar3);
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801f0156;
    func_0x000180224990(*(undefined8 *)((int64_t)&arg_28h + iVar2), 0x1804b7ba0, 700);
    return 0;
}

// ============================================================
// Function: FUN_1801f0180
// Address: 0x1801f0180
// Size: 263 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801f0180(int64_t arg_28h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f0190;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined4 *)(in_RCX + 0x4d8) = 0;
    if ((*(int64_t *)(in_RCX + 0xaf0) != 0) &&
       ((*(int64_t *)(in_RCX + 0x260) == 0 || (*(int64_t *)(in_RCX + 0x2e8) == 0)))) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f01dc;
        iVar3 = func_0x0001802446f0(in_RDX, 0x10, 2);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f01ed;
            iVar3 = func_0x000180244a90(in_RDX, 2);
            if (iVar3 != 0) {
                uVar1 = *(undefined8 *)(in_RCX + 0xaf8);
                uVar2 = *(undefined8 *)(in_RCX + 0xaf0);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f020d;
                iVar3 = func_0x000180244bf0(in_RDX, uVar2, uVar1, 2);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f0219;
                    iVar3 = func_0x000180244000(in_RDX);
                    if (iVar3 != 0) {
                        *(undefined4 *)(in_RCX + 0x4d8) = 1;
                        return 1;
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f023c;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f0254;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f026a;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    return 2;
}

// ============================================================
// Function: FUN_1801f0290
// Address: 0x1801f0290
// Size: 229 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801f0290(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f02a0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined *)(in_RCX + 0xb51) = 0;
    if (*(int64_t *)(in_RCX + 0x1590) == 0) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f02dd;
    iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f02ee;
        iVar1 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f030e;
            iVar1 = fcn.180244bf0(*(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                                  *(int64_t *)(&stack0x00000048 + iVar2));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f031a;
                iVar1 = fcn.180244000(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                                      *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                                      *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2), 
                                      *(int64_t *)(&stack0x00000058 + iVar2));
                if (iVar1 != 0) {
                    *(undefined *)(in_RCX + 0xb51) = 1;
                    return 1;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f033a;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f0352;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f0368;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1801f0380
// Address: 0x1801f0380
// Size: 269 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801f0380(int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 uVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f0395;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar4 = 0;
    if (*(int64_t *)(in_RCX + 0xb28) == 0) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f03d1;
    iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000058 + iVar3));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f03e2;
        iVar2 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f0402;
            iVar2 = fcn.180244bf0(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                                  *(int64_t *)(&stack0x00000048 + iVar3));
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f040e;
                iVar2 = fcn.180244000(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                                      *(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                                      *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3), 
                                      *(int64_t *)(&stack0x00000058 + iVar3));
                if (iVar2 != 0) {
                    uVar4 = 1;
                    goto code_r0x0001801f044c;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f041e;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f0436;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f044c;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
code_r0x0001801f044c:
    uVar1 = *(undefined8 *)(in_RCX + 0xb20);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f0465;
    fcn.180224990(uVar1, 0x1804b7ba0, 0x32e);
    *(undefined8 *)(in_RCX + 0xb20) = 0;
    *(undefined8 *)(in_RCX + 0xb28) = 0;
    return uVar4;
}

// ============================================================
// Function: FUN_1801f0490
// Address: 0x1801f0490
// Size: 1307 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_388h because it doesn't fit into ProtoModel

void fcn.1801f0490(int64_t arg_28h)
{
    uint8_t *puVar1;
    undefined8 uVar2;
    code *pcVar3;
    int32_t iVar4;
    uint32_t uVar5;
    int64_t iVar6;
    int32_t *piVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint64_t uVar11;
    int64_t in_RCX;
    int32_t *piVar12;
    undefined8 unaff_RDI;
    uint8_t *puVar13;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_238h;
    int64_t var_38h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801f04aa;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar6);
    piVar7 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&var_20h + iVar6) = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar6) = 0;
    *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
    uVar2 = *(undefined8 *)(in_RCX + 0x40);
    piVar12 = piVar7;
    if (*(int32_t *)(in_RCX + 0x8c8) == 1) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f04f1;
        piVar7 = (int32_t *)func_0x0001801a0380(in_RCX);
        piVar12 = *(int32_t **)((int64_t)&var_10h + iVar6);
    }
    pcVar3 = *(code **)(in_RCX + 0x980);
    *(undefined8 *)(&stack0x00000388 + iVar6) = unaff_RDI;
    if (pcVar3 != (code *)0x0) {
        *(int64_t *)((int64_t)&var_8h + iVar6) = (int64_t)&var_10h + iVar6;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f0527;
        iVar4 = (*pcVar3)(uVar2, piVar7, (int64_t)&var_20h + iVar6, (int64_t)&var_18h + iVar6);
        piVar12 = *(int32_t **)((int64_t)&var_10h + iVar6);
        if (iVar4 != 0) {
            if (piVar12 == (int32_t *)0x0) goto code_r0x0001801f0585;
            if (*piVar12 == 0x304) goto code_r0x0001801f057c;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f0542;
        func_0x00018019c980();
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f0547;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f055f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f0575;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar6));
        goto code_r0x0001801f07e5;
    }
code_r0x0001801f057c:
    if (piVar12 == (int32_t *)0x0) {
code_r0x0001801f0585:
        pcVar3 = *(code **)(in_RCX + 0x968);
        if (pcVar3 == (code *)0x0) goto code_r0x0001801f06e6;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f05a7;
        func_0x0001804986e0((int64_t)&arg_28h + iVar6, 0, 0x101);
        *(undefined4 *)(&stack0x00000000 + iVar6) = 0x200;
        *(int64_t **)((int64_t)&var_8h + iVar6) = &var_238h;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f05ca;
        uVar5 = (*pcVar3)(uVar2, 0, (int64_t)&arg_28h + iVar6, 0x100);
        if (uVar5 < 0x201) {
            if (uVar5 == 0) goto code_r0x0001801f06e6;
            *(undefined2 *)((int64_t)&iStackX_8 + iVar6) = 0x113;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f0628;
            uVar8 = func_0x000180498cd0((int64_t)&arg_28h + iVar6);
            *(uint64_t *)((int64_t)&var_18h + iVar6) = uVar8;
            if (uVar8 < 0x101) {
                *(int64_t *)((int64_t)&var_20h + iVar6) = (int64_t)&arg_28h + iVar6;
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f0670;
                iVar9 = func_0x00018019e0c0(in_RCX, (int64_t)&iStackX_8 + iVar6);
                if (iVar9 != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f0689;
                    iVar10 = func_0x00018019cd20();
                    *(int64_t *)((int64_t)&var_10h + iVar6) = iVar10;
                    if (iVar10 != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f06a6;
                        iVar4 = func_0x000180192fd0(iVar10, &var_238h, uVar5);
                        if (iVar4 != 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f06bb;
                            iVar4 = func_0x00018019ce00(*(undefined8 *)((int64_t)&var_10h + iVar6), iVar9);
                            if (iVar4 != 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f06d2;
                                iVar4 = func_0x00018019ce10(*(undefined8 *)((int64_t)&var_10h + iVar6), 0x304);
                                if (iVar4 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f06e6;
                                    func_0x000180244fc0(&var_238h, uVar5);
                                    goto code_r0x0001801f06e6;
                                }
                            }
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f0763;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f077b;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f0791;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f079d;
                    func_0x000180244fc0(&var_238h, uVar5);
                    goto code_r0x0001801f07e5;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f067d;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f063a;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
            }
            goto code_r0x0001801f063f;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f05da;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f05f2;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
    } else {
code_r0x0001801f06e6:
        uVar2 = *(undefined8 *)(in_RCX + 0x900);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f06f2;
        func_0x00018019c980(uVar2);
        iVar9 = *(int64_t *)((int64_t)&var_10h + iVar6);
        *(int64_t *)(in_RCX + 0x900) = iVar9;
        if (iVar9 == 0) {
code_r0x0001801f07b2:
            if ((*(int32_t *)(in_RCX + 0xf0) != 2) ||
               ((iVar10 = *(int64_t *)(in_RCX + 0x8f8), *(int32_t *)(iVar10 + 0x338) == 0 &&
                ((iVar9 == 0 || (iVar10 = iVar9, *(int32_t *)(iVar9 + 0x338) == 0)))))) {
                *(undefined4 *)(in_RCX + 0x1538) = 0;
                goto code_r0x0001801f07e5;
            }
            *(undefined4 *)(in_RCX + 0x1538) = *(undefined4 *)(iVar10 + 0x338);
            if (*(int64_t *)(iVar10 + 0x318) != 0) {
                if (*(int64_t *)(in_RCX + 0xa18) != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f0837;
                    iVar4 = func_0x000180498f10();
                    if (iVar4 == 0) goto code_r0x0001801f0875;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f0840;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f0858;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&arg_28h + iVar6));
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f086e;
                fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar6));
                goto code_r0x0001801f07e5;
            }
code_r0x0001801f0875:
            puVar13 = *(uint8_t **)(in_RCX + 0xaf0);
            if (puVar13 == (uint8_t *)0x0) {
                if (*(int64_t *)(iVar10 + 0x340) != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f0893;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
code_r0x0001801f0898:
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f08ab;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f08c1;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar6));
                    goto code_r0x0001801f07e5;
                }
            } else if (*(int64_t *)(iVar10 + 0x340) != 0) {
                uVar8 = *(uint64_t *)(in_RCX + 0xaf8);
                if (0x7fffffffffffffff < uVar8) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f0992;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
                    goto code_r0x0001801f063f;
                }
                do {
                    do {
                        if (uVar8 == 0) {
code_r0x0001801f097e:
                            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f0983;
                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6)
                                         );
                            goto code_r0x0001801f0898;
                        }
                        uVar11 = (uint64_t)*puVar13;
                        puVar1 = puVar13 + 1;
                        if (uVar8 - 1 < uVar11) goto code_r0x0001801f097e;
                        puVar13 = puVar1 + uVar11;
                        uVar8 = (uVar8 - 1) - uVar11;
                    } while (uVar11 != *(uint64_t *)(iVar10 + 0x348));
                    uVar2 = *(undefined8 *)(iVar10 + 0x340);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f0928;
                    iVar4 = func_0x0001802262e0(puVar1, uVar2);
                } while (iVar4 != 0);
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f093f;
            iVar4 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6));
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f0950;
                iVar4 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
                if (iVar4 != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f095c;
                    iVar4 = fcn.180244000(*(int64_t *)(&stack0x00000000 + iVar6), 
                                          *(int64_t *)((int64_t)&iStackX_8 + iVar6), 
                                          *(int64_t *)((int64_t)&var_10h + iVar6), 
                                          *(int64_t *)((int64_t)&var_18h + iVar6), 
                                          *(int64_t *)((int64_t)&var_20h + iVar6), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                          *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6)
                                         );
                    if (iVar4 != 0) {
                        *(undefined4 *)(in_RCX + 0xb18) = 1;
                        *(undefined4 *)(in_RCX + 0xb1c) = 1;
                        goto code_r0x0001801f07e5;
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f09a1;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        } else {
            uVar2 = *(undefined8 *)(in_RCX + 0x908);
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f0720;
            fcn.180224990(uVar2, 0x1804b7ba0, 899);
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f073c;
            iVar9 = func_0x000180223170(*(undefined8 *)((int64_t)&var_20h + iVar6), 
                                        *(undefined8 *)((int64_t)&var_18h + iVar6), 0x1804b7ba0, 900);
            *(int64_t *)(in_RCX + 0x908) = iVar9;
            if (iVar9 != 0) {
                iVar9 = *(int64_t *)((int64_t)&var_10h + iVar6);
                *(undefined8 *)(in_RCX + 0x910) = *(undefined8 *)((int64_t)&var_18h + iVar6);
                goto code_r0x0001801f07b2;
            }
            *(undefined8 *)(in_RCX + 0x910) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f0754;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        }
code_r0x0001801f063f:
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f0652;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f0608;
    fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar6));
code_r0x0001801f07e5:
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f07fc;
    func_0x000180459870(var_38h ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1801f09b0
// Address: 0x1801f09b0
// Size: 321 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h

undefined8 fcn.1801f09b0(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f09c5;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f09e0;
    iVar3 = func_0x0001801af910();
    if (iVar3 == 0) {
        uVar1 = *(undefined4 *)((int64_t)&var_20h + iVar4 + -8);
        uVar2 = *(undefined4 *)((int64_t)&var_20h + iVar4 + -4);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f0a1c;
        iVar3 = func_0x0001801f4d20(in_RCX, uVar2, uVar1);
        if (iVar3 == 0) {
            return 2;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f0a47;
        func_0x0001801ab2d0(in_RCX, (int64_t)&arg_28h + iVar4, (int64_t)&var_20h + iVar4);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f0a5a;
        iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)&var_20h + iVar4 + -8), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f0a6b;
            iVar3 = fcn.180244a90(*(int64_t *)((int64_t)&var_20h + iVar4 + -8), *(int64_t *)((int64_t)&var_20h + iVar4))
            ;
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f0a87;
                iVar3 = fcn.180244bf0(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4));
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f0a93;
                    iVar3 = fcn.180244000(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar4), 
                                          *(int64_t *)(&stack0x00000030 + iVar4), *(int64_t *)(&stack0x00000038 + iVar4)
                                          , *(int64_t *)(&stack0x00000040 + iVar4), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar4), 
                                          *(int64_t *)(&stack0x00000058 + iVar4));
                    if (iVar3 != 0) {
                        return 1;
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f0ab1;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4 + -8), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f0ac9;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4 + -8), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f09eb;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4 + -8), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f0a03;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4 + -8), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f0adf;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_1801f0b00
// Address: 0x1801f0b00
// Size: 173 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801f0b00(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f0b10;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((*(uint8_t *)(in_RCX + 0x9a8) & 1) != 0) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f0b45;
    iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f0b59;
        iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
        if (iVar1 != 0) {
            return 1;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f0b72;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f0b8a;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f0ba0;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1801f0bb0
// Address: 0x1801f0bb0
// Size: 177 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801f0bb0(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f0bc0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((*(uint32_t *)(in_RCX + 0x9a8) >> 0x13 & 1) != 0) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f0bf9;
    iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f0c0d;
        iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
        if (iVar1 != 0) {
            return 1;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f0c26;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f0c3e;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f0c54;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1801f0c70
// Address: 0x1801f0c70
// Size: 127 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801f0c70(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    int16_t iVar1;
    undefined2 uVar2;
    bool bVar3;
    bool bVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 unaff_RDI;
    uint64_t uVar9;
    undefined8 unaff_R12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f0c89;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar8 = 0;
    bVar3 = false;
    *(undefined8 *)((int64_t)&var_20h + iVar6) = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar6) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0cb8;
    iVar5 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
    if (iVar5 == 0) {
code_r0x0001801f0ef9:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0efe;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0f16;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)(&stack0x00000038 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0f2c;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ccd;
    iVar5 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    if (iVar5 == 0) goto code_r0x0001801f0ef9;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ce2;
    iVar5 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    if (iVar5 == 0) goto code_r0x0001801f0ef9;
    *(undefined8 *)((int64_t)&arg_50h + iVar6) = unaff_R12;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d01;
    func_0x0001801ab5e0(in_RCX, (int64_t)&var_18h + iVar6, (int64_t)&var_20h + iVar6);
    iVar7 = *(int64_t *)((int64_t)&var_20h + iVar6);
    bVar4 = false;
    if (iVar7 == 1) {
        if (**(int16_t **)((int64_t)&var_18h + iVar6) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d2d;
            func_0x0001801ab620(in_RCX, (int64_t)&var_18h + iVar6, (int64_t)&var_20h + iVar6);
            iVar7 = *(int64_t *)((int64_t)&var_20h + iVar6);
            bVar4 = true;
            goto code_r0x0001801f0d35;
        }
    } else {
code_r0x0001801f0d35:
        bVar3 = bVar4;
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d3f;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d57;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                          *(int64_t *)(&stack0x00000038 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d6d;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
            return 0;
        }
    }
    iVar1 = *(int16_t *)(in_RCX + 0x4de);
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_RDI;
    if ((iVar1 == 0) || (*(int64_t *)(in_RCX + 0x308) != 0)) {
        if (*(int64_t *)(in_RCX + 0xa90) == 0) {
            bVar3 = true;
        }
        uVar9 = uVar8;
        if (iVar7 != 0) {
            do {
                uVar2 = *(undefined2 *)(*(int64_t *)((int64_t)&var_18h + iVar6) + uVar9 * 2);
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0de7;
                iVar5 = func_0x0001801ada30(in_RCX, uVar2, 0x20004);
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
                    *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
                    uVar2 = *(undefined2 *)(*(int64_t *)((int64_t)&var_18h + iVar6) + uVar9 * 2);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e0f;
                    iVar5 = func_0x0001801adc80(in_RCX, uVar2, 0x304);
                    if (iVar5 != 0) {
                        if (*(int16_t *)(*(int64_t *)((int64_t)&var_18h + iVar6) + uVar9 * 2) == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e73;
                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                          *(int64_t *)((int64_t)&var_10h + iVar6));
                            goto code_r0x0001801f0e7f;
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e32;
                        iVar5 = fcn.1801eff90(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_18h + iVar6), 
                                              *(int64_t *)((int64_t)&var_20h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar6));
                        if (iVar5 == 0) {
                            return 0;
                        }
                        uVar8 = uVar8 + 1;
                        if (bVar3) break;
                    }
                }
                uVar9 = uVar9 + 1;
            } while (uVar9 < *(uint64_t *)((int64_t)&var_20h + iVar6));
            if (uVar8 != 0) goto code_r0x0001801f0e51;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0eeb;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
code_r0x0001801f0e7f:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e8b;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)(&stack0x00000038 + iVar6));
    } else {
        *(undefined8 *)(in_RCX + 0x338) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0da6;
        iVar5 = fcn.1801eff90(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_58h + iVar6));
        if (iVar5 == 0) {
            return 0;
        }
code_r0x0001801f0e51:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e59;
        iVar5 = fcn.180244000(*(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                              *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                              *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                              *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e65;
            iVar5 = fcn.180244000(*(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                                  *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                                  *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
            if (iVar5 != 0) {
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ec6;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ede;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)(&stack0x00000038 + iVar6));
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ea1;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801f0cef
// Address: 0x1801f0cef
// Size: 140 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801f0c70(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    int16_t iVar1;
    undefined2 uVar2;
    bool bVar3;
    bool bVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 unaff_RDI;
    uint64_t uVar9;
    undefined8 unaff_R12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f0c89;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar8 = 0;
    bVar3 = false;
    *(undefined8 *)((int64_t)&var_20h + iVar6) = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar6) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0cb8;
    iVar5 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
    if (iVar5 == 0) {
code_r0x0001801f0ef9:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0efe;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0f16;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)(&stack0x00000038 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0f2c;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ccd;
    iVar5 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    if (iVar5 == 0) goto code_r0x0001801f0ef9;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ce2;
    iVar5 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    if (iVar5 == 0) goto code_r0x0001801f0ef9;
    *(undefined8 *)((int64_t)&arg_50h + iVar6) = unaff_R12;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d01;
    func_0x0001801ab5e0(in_RCX, (int64_t)&var_18h + iVar6, (int64_t)&var_20h + iVar6);
    iVar7 = *(int64_t *)((int64_t)&var_20h + iVar6);
    bVar4 = false;
    if (iVar7 == 1) {
        if (**(int16_t **)((int64_t)&var_18h + iVar6) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d2d;
            func_0x0001801ab620(in_RCX, (int64_t)&var_18h + iVar6, (int64_t)&var_20h + iVar6);
            iVar7 = *(int64_t *)((int64_t)&var_20h + iVar6);
            bVar4 = true;
            goto code_r0x0001801f0d35;
        }
    } else {
code_r0x0001801f0d35:
        bVar3 = bVar4;
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d3f;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d57;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                          *(int64_t *)(&stack0x00000038 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d6d;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
            return 0;
        }
    }
    iVar1 = *(int16_t *)(in_RCX + 0x4de);
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_RDI;
    if ((iVar1 == 0) || (*(int64_t *)(in_RCX + 0x308) != 0)) {
        if (*(int64_t *)(in_RCX + 0xa90) == 0) {
            bVar3 = true;
        }
        uVar9 = uVar8;
        if (iVar7 != 0) {
            do {
                uVar2 = *(undefined2 *)(*(int64_t *)((int64_t)&var_18h + iVar6) + uVar9 * 2);
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0de7;
                iVar5 = func_0x0001801ada30(in_RCX, uVar2, 0x20004);
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
                    *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
                    uVar2 = *(undefined2 *)(*(int64_t *)((int64_t)&var_18h + iVar6) + uVar9 * 2);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e0f;
                    iVar5 = func_0x0001801adc80(in_RCX, uVar2, 0x304);
                    if (iVar5 != 0) {
                        if (*(int16_t *)(*(int64_t *)((int64_t)&var_18h + iVar6) + uVar9 * 2) == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e73;
                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                          *(int64_t *)((int64_t)&var_10h + iVar6));
                            goto code_r0x0001801f0e7f;
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e32;
                        iVar5 = fcn.1801eff90(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_18h + iVar6), 
                                              *(int64_t *)((int64_t)&var_20h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar6));
                        if (iVar5 == 0) {
                            return 0;
                        }
                        uVar8 = uVar8 + 1;
                        if (bVar3) break;
                    }
                }
                uVar9 = uVar9 + 1;
            } while (uVar9 < *(uint64_t *)((int64_t)&var_20h + iVar6));
            if (uVar8 != 0) goto code_r0x0001801f0e51;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0eeb;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
code_r0x0001801f0e7f:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e8b;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)(&stack0x00000038 + iVar6));
    } else {
        *(undefined8 *)(in_RCX + 0x338) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0da6;
        iVar5 = fcn.1801eff90(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_58h + iVar6));
        if (iVar5 == 0) {
            return 0;
        }
code_r0x0001801f0e51:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e59;
        iVar5 = fcn.180244000(*(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                              *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                              *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                              *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e65;
            iVar5 = fcn.180244000(*(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                                  *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                                  *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
            if (iVar5 != 0) {
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ec6;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ede;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)(&stack0x00000038 + iVar6));
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ea1;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801f0d7b
// Address: 0x1801f0d7b
// Size: 301 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801f0c70(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    int16_t iVar1;
    undefined2 uVar2;
    bool bVar3;
    bool bVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 unaff_RDI;
    uint64_t uVar9;
    undefined8 unaff_R12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f0c89;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar8 = 0;
    bVar3 = false;
    *(undefined8 *)((int64_t)&var_20h + iVar6) = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar6) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0cb8;
    iVar5 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
    if (iVar5 == 0) {
code_r0x0001801f0ef9:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0efe;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0f16;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)(&stack0x00000038 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0f2c;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ccd;
    iVar5 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    if (iVar5 == 0) goto code_r0x0001801f0ef9;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ce2;
    iVar5 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    if (iVar5 == 0) goto code_r0x0001801f0ef9;
    *(undefined8 *)((int64_t)&arg_50h + iVar6) = unaff_R12;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d01;
    func_0x0001801ab5e0(in_RCX, (int64_t)&var_18h + iVar6, (int64_t)&var_20h + iVar6);
    iVar7 = *(int64_t *)((int64_t)&var_20h + iVar6);
    bVar4 = false;
    if (iVar7 == 1) {
        if (**(int16_t **)((int64_t)&var_18h + iVar6) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d2d;
            func_0x0001801ab620(in_RCX, (int64_t)&var_18h + iVar6, (int64_t)&var_20h + iVar6);
            iVar7 = *(int64_t *)((int64_t)&var_20h + iVar6);
            bVar4 = true;
            goto code_r0x0001801f0d35;
        }
    } else {
code_r0x0001801f0d35:
        bVar3 = bVar4;
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d3f;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d57;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                          *(int64_t *)(&stack0x00000038 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d6d;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
            return 0;
        }
    }
    iVar1 = *(int16_t *)(in_RCX + 0x4de);
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_RDI;
    if ((iVar1 == 0) || (*(int64_t *)(in_RCX + 0x308) != 0)) {
        if (*(int64_t *)(in_RCX + 0xa90) == 0) {
            bVar3 = true;
        }
        uVar9 = uVar8;
        if (iVar7 != 0) {
            do {
                uVar2 = *(undefined2 *)(*(int64_t *)((int64_t)&var_18h + iVar6) + uVar9 * 2);
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0de7;
                iVar5 = func_0x0001801ada30(in_RCX, uVar2, 0x20004);
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
                    *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
                    uVar2 = *(undefined2 *)(*(int64_t *)((int64_t)&var_18h + iVar6) + uVar9 * 2);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e0f;
                    iVar5 = func_0x0001801adc80(in_RCX, uVar2, 0x304);
                    if (iVar5 != 0) {
                        if (*(int16_t *)(*(int64_t *)((int64_t)&var_18h + iVar6) + uVar9 * 2) == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e73;
                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                          *(int64_t *)((int64_t)&var_10h + iVar6));
                            goto code_r0x0001801f0e7f;
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e32;
                        iVar5 = fcn.1801eff90(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_18h + iVar6), 
                                              *(int64_t *)((int64_t)&var_20h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar6));
                        if (iVar5 == 0) {
                            return 0;
                        }
                        uVar8 = uVar8 + 1;
                        if (bVar3) break;
                    }
                }
                uVar9 = uVar9 + 1;
            } while (uVar9 < *(uint64_t *)((int64_t)&var_20h + iVar6));
            if (uVar8 != 0) goto code_r0x0001801f0e51;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0eeb;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
code_r0x0001801f0e7f:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e8b;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)(&stack0x00000038 + iVar6));
    } else {
        *(undefined8 *)(in_RCX + 0x338) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0da6;
        iVar5 = fcn.1801eff90(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_58h + iVar6));
        if (iVar5 == 0) {
            return 0;
        }
code_r0x0001801f0e51:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e59;
        iVar5 = fcn.180244000(*(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                              *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                              *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                              *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e65;
            iVar5 = fcn.180244000(*(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                                  *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                                  *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
            if (iVar5 != 0) {
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ec6;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ede;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)(&stack0x00000038 + iVar6));
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ea1;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801f0ea8
// Address: 0x1801f0ea8
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801f0c70(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    int16_t iVar1;
    undefined2 uVar2;
    bool bVar3;
    bool bVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 unaff_RDI;
    uint64_t uVar9;
    undefined8 unaff_R12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f0c89;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar8 = 0;
    bVar3 = false;
    *(undefined8 *)((int64_t)&var_20h + iVar6) = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar6) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0cb8;
    iVar5 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
    if (iVar5 == 0) {
code_r0x0001801f0ef9:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0efe;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0f16;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)(&stack0x00000038 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0f2c;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ccd;
    iVar5 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    if (iVar5 == 0) goto code_r0x0001801f0ef9;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ce2;
    iVar5 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    if (iVar5 == 0) goto code_r0x0001801f0ef9;
    *(undefined8 *)((int64_t)&arg_50h + iVar6) = unaff_R12;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d01;
    func_0x0001801ab5e0(in_RCX, (int64_t)&var_18h + iVar6, (int64_t)&var_20h + iVar6);
    iVar7 = *(int64_t *)((int64_t)&var_20h + iVar6);
    bVar4 = false;
    if (iVar7 == 1) {
        if (**(int16_t **)((int64_t)&var_18h + iVar6) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d2d;
            func_0x0001801ab620(in_RCX, (int64_t)&var_18h + iVar6, (int64_t)&var_20h + iVar6);
            iVar7 = *(int64_t *)((int64_t)&var_20h + iVar6);
            bVar4 = true;
            goto code_r0x0001801f0d35;
        }
    } else {
code_r0x0001801f0d35:
        bVar3 = bVar4;
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d3f;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d57;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                          *(int64_t *)(&stack0x00000038 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d6d;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
            return 0;
        }
    }
    iVar1 = *(int16_t *)(in_RCX + 0x4de);
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_RDI;
    if ((iVar1 == 0) || (*(int64_t *)(in_RCX + 0x308) != 0)) {
        if (*(int64_t *)(in_RCX + 0xa90) == 0) {
            bVar3 = true;
        }
        uVar9 = uVar8;
        if (iVar7 != 0) {
            do {
                uVar2 = *(undefined2 *)(*(int64_t *)((int64_t)&var_18h + iVar6) + uVar9 * 2);
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0de7;
                iVar5 = func_0x0001801ada30(in_RCX, uVar2, 0x20004);
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
                    *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
                    uVar2 = *(undefined2 *)(*(int64_t *)((int64_t)&var_18h + iVar6) + uVar9 * 2);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e0f;
                    iVar5 = func_0x0001801adc80(in_RCX, uVar2, 0x304);
                    if (iVar5 != 0) {
                        if (*(int16_t *)(*(int64_t *)((int64_t)&var_18h + iVar6) + uVar9 * 2) == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e73;
                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                          *(int64_t *)((int64_t)&var_10h + iVar6));
                            goto code_r0x0001801f0e7f;
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e32;
                        iVar5 = fcn.1801eff90(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_18h + iVar6), 
                                              *(int64_t *)((int64_t)&var_20h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar6));
                        if (iVar5 == 0) {
                            return 0;
                        }
                        uVar8 = uVar8 + 1;
                        if (bVar3) break;
                    }
                }
                uVar9 = uVar9 + 1;
            } while (uVar9 < *(uint64_t *)((int64_t)&var_20h + iVar6));
            if (uVar8 != 0) goto code_r0x0001801f0e51;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0eeb;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
code_r0x0001801f0e7f:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e8b;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)(&stack0x00000038 + iVar6));
    } else {
        *(undefined8 *)(in_RCX + 0x338) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0da6;
        iVar5 = fcn.1801eff90(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_58h + iVar6));
        if (iVar5 == 0) {
            return 0;
        }
code_r0x0001801f0e51:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e59;
        iVar5 = fcn.180244000(*(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                              *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                              *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                              *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e65;
            iVar5 = fcn.180244000(*(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                                  *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                                  *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
            if (iVar5 != 0) {
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ec6;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ede;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)(&stack0x00000038 + iVar6));
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ea1;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801f0ead
// Address: 0x1801f0ead
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801f0c70(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    int16_t iVar1;
    undefined2 uVar2;
    bool bVar3;
    bool bVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 unaff_RDI;
    uint64_t uVar9;
    undefined8 unaff_R12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f0c89;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar8 = 0;
    bVar3 = false;
    *(undefined8 *)((int64_t)&var_20h + iVar6) = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar6) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0cb8;
    iVar5 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
    if (iVar5 == 0) {
code_r0x0001801f0ef9:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0efe;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0f16;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)(&stack0x00000038 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0f2c;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ccd;
    iVar5 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    if (iVar5 == 0) goto code_r0x0001801f0ef9;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ce2;
    iVar5 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    if (iVar5 == 0) goto code_r0x0001801f0ef9;
    *(undefined8 *)((int64_t)&arg_50h + iVar6) = unaff_R12;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d01;
    func_0x0001801ab5e0(in_RCX, (int64_t)&var_18h + iVar6, (int64_t)&var_20h + iVar6);
    iVar7 = *(int64_t *)((int64_t)&var_20h + iVar6);
    bVar4 = false;
    if (iVar7 == 1) {
        if (**(int16_t **)((int64_t)&var_18h + iVar6) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d2d;
            func_0x0001801ab620(in_RCX, (int64_t)&var_18h + iVar6, (int64_t)&var_20h + iVar6);
            iVar7 = *(int64_t *)((int64_t)&var_20h + iVar6);
            bVar4 = true;
            goto code_r0x0001801f0d35;
        }
    } else {
code_r0x0001801f0d35:
        bVar3 = bVar4;
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d3f;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d57;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                          *(int64_t *)(&stack0x00000038 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d6d;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
            return 0;
        }
    }
    iVar1 = *(int16_t *)(in_RCX + 0x4de);
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_RDI;
    if ((iVar1 == 0) || (*(int64_t *)(in_RCX + 0x308) != 0)) {
        if (*(int64_t *)(in_RCX + 0xa90) == 0) {
            bVar3 = true;
        }
        uVar9 = uVar8;
        if (iVar7 != 0) {
            do {
                uVar2 = *(undefined2 *)(*(int64_t *)((int64_t)&var_18h + iVar6) + uVar9 * 2);
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0de7;
                iVar5 = func_0x0001801ada30(in_RCX, uVar2, 0x20004);
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
                    *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
                    uVar2 = *(undefined2 *)(*(int64_t *)((int64_t)&var_18h + iVar6) + uVar9 * 2);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e0f;
                    iVar5 = func_0x0001801adc80(in_RCX, uVar2, 0x304);
                    if (iVar5 != 0) {
                        if (*(int16_t *)(*(int64_t *)((int64_t)&var_18h + iVar6) + uVar9 * 2) == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e73;
                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                          *(int64_t *)((int64_t)&var_10h + iVar6));
                            goto code_r0x0001801f0e7f;
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e32;
                        iVar5 = fcn.1801eff90(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_18h + iVar6), 
                                              *(int64_t *)((int64_t)&var_20h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar6));
                        if (iVar5 == 0) {
                            return 0;
                        }
                        uVar8 = uVar8 + 1;
                        if (bVar3) break;
                    }
                }
                uVar9 = uVar9 + 1;
            } while (uVar9 < *(uint64_t *)((int64_t)&var_20h + iVar6));
            if (uVar8 != 0) goto code_r0x0001801f0e51;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0eeb;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
code_r0x0001801f0e7f:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e8b;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)(&stack0x00000038 + iVar6));
    } else {
        *(undefined8 *)(in_RCX + 0x338) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0da6;
        iVar5 = fcn.1801eff90(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_58h + iVar6));
        if (iVar5 == 0) {
            return 0;
        }
code_r0x0001801f0e51:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e59;
        iVar5 = fcn.180244000(*(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                              *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                              *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                              *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e65;
            iVar5 = fcn.180244000(*(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                                  *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                                  *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
            if (iVar5 != 0) {
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ec6;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ede;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)(&stack0x00000038 + iVar6));
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ea1;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801f0ec1
// Address: 0x1801f0ec1
// Size: 56 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801f0c70(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    int16_t iVar1;
    undefined2 uVar2;
    bool bVar3;
    bool bVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 unaff_RDI;
    uint64_t uVar9;
    undefined8 unaff_R12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f0c89;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar8 = 0;
    bVar3 = false;
    *(undefined8 *)((int64_t)&var_20h + iVar6) = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar6) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0cb8;
    iVar5 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
    if (iVar5 == 0) {
code_r0x0001801f0ef9:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0efe;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0f16;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)(&stack0x00000038 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0f2c;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ccd;
    iVar5 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    if (iVar5 == 0) goto code_r0x0001801f0ef9;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ce2;
    iVar5 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    if (iVar5 == 0) goto code_r0x0001801f0ef9;
    *(undefined8 *)((int64_t)&arg_50h + iVar6) = unaff_R12;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d01;
    func_0x0001801ab5e0(in_RCX, (int64_t)&var_18h + iVar6, (int64_t)&var_20h + iVar6);
    iVar7 = *(int64_t *)((int64_t)&var_20h + iVar6);
    bVar4 = false;
    if (iVar7 == 1) {
        if (**(int16_t **)((int64_t)&var_18h + iVar6) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d2d;
            func_0x0001801ab620(in_RCX, (int64_t)&var_18h + iVar6, (int64_t)&var_20h + iVar6);
            iVar7 = *(int64_t *)((int64_t)&var_20h + iVar6);
            bVar4 = true;
            goto code_r0x0001801f0d35;
        }
    } else {
code_r0x0001801f0d35:
        bVar3 = bVar4;
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d3f;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d57;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                          *(int64_t *)(&stack0x00000038 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d6d;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
            return 0;
        }
    }
    iVar1 = *(int16_t *)(in_RCX + 0x4de);
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_RDI;
    if ((iVar1 == 0) || (*(int64_t *)(in_RCX + 0x308) != 0)) {
        if (*(int64_t *)(in_RCX + 0xa90) == 0) {
            bVar3 = true;
        }
        uVar9 = uVar8;
        if (iVar7 != 0) {
            do {
                uVar2 = *(undefined2 *)(*(int64_t *)((int64_t)&var_18h + iVar6) + uVar9 * 2);
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0de7;
                iVar5 = func_0x0001801ada30(in_RCX, uVar2, 0x20004);
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
                    *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
                    uVar2 = *(undefined2 *)(*(int64_t *)((int64_t)&var_18h + iVar6) + uVar9 * 2);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e0f;
                    iVar5 = func_0x0001801adc80(in_RCX, uVar2, 0x304);
                    if (iVar5 != 0) {
                        if (*(int16_t *)(*(int64_t *)((int64_t)&var_18h + iVar6) + uVar9 * 2) == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e73;
                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                          *(int64_t *)((int64_t)&var_10h + iVar6));
                            goto code_r0x0001801f0e7f;
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e32;
                        iVar5 = fcn.1801eff90(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_18h + iVar6), 
                                              *(int64_t *)((int64_t)&var_20h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar6));
                        if (iVar5 == 0) {
                            return 0;
                        }
                        uVar8 = uVar8 + 1;
                        if (bVar3) break;
                    }
                }
                uVar9 = uVar9 + 1;
            } while (uVar9 < *(uint64_t *)((int64_t)&var_20h + iVar6));
            if (uVar8 != 0) goto code_r0x0001801f0e51;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0eeb;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
code_r0x0001801f0e7f:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e8b;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)(&stack0x00000038 + iVar6));
    } else {
        *(undefined8 *)(in_RCX + 0x338) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0da6;
        iVar5 = fcn.1801eff90(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_58h + iVar6));
        if (iVar5 == 0) {
            return 0;
        }
code_r0x0001801f0e51:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e59;
        iVar5 = fcn.180244000(*(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                              *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                              *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                              *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e65;
            iVar5 = fcn.180244000(*(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                                  *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                                  *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
            if (iVar5 != 0) {
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ec6;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ede;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)(&stack0x00000038 + iVar6));
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ea1;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801f0ef9
// Address: 0x1801f0ef9
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801f0c70(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    int16_t iVar1;
    undefined2 uVar2;
    bool bVar3;
    bool bVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 unaff_RDI;
    uint64_t uVar9;
    undefined8 unaff_R12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f0c89;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar8 = 0;
    bVar3 = false;
    *(undefined8 *)((int64_t)&var_20h + iVar6) = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar6) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0cb8;
    iVar5 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
    if (iVar5 == 0) {
code_r0x0001801f0ef9:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0efe;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0f16;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)(&stack0x00000038 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0f2c;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ccd;
    iVar5 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    if (iVar5 == 0) goto code_r0x0001801f0ef9;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ce2;
    iVar5 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    if (iVar5 == 0) goto code_r0x0001801f0ef9;
    *(undefined8 *)((int64_t)&arg_50h + iVar6) = unaff_R12;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d01;
    func_0x0001801ab5e0(in_RCX, (int64_t)&var_18h + iVar6, (int64_t)&var_20h + iVar6);
    iVar7 = *(int64_t *)((int64_t)&var_20h + iVar6);
    bVar4 = false;
    if (iVar7 == 1) {
        if (**(int16_t **)((int64_t)&var_18h + iVar6) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d2d;
            func_0x0001801ab620(in_RCX, (int64_t)&var_18h + iVar6, (int64_t)&var_20h + iVar6);
            iVar7 = *(int64_t *)((int64_t)&var_20h + iVar6);
            bVar4 = true;
            goto code_r0x0001801f0d35;
        }
    } else {
code_r0x0001801f0d35:
        bVar3 = bVar4;
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d3f;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d57;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                          *(int64_t *)(&stack0x00000038 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0d6d;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
            return 0;
        }
    }
    iVar1 = *(int16_t *)(in_RCX + 0x4de);
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_RDI;
    if ((iVar1 == 0) || (*(int64_t *)(in_RCX + 0x308) != 0)) {
        if (*(int64_t *)(in_RCX + 0xa90) == 0) {
            bVar3 = true;
        }
        uVar9 = uVar8;
        if (iVar7 != 0) {
            do {
                uVar2 = *(undefined2 *)(*(int64_t *)((int64_t)&var_18h + iVar6) + uVar9 * 2);
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0de7;
                iVar5 = func_0x0001801ada30(in_RCX, uVar2, 0x20004);
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
                    *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
                    uVar2 = *(undefined2 *)(*(int64_t *)((int64_t)&var_18h + iVar6) + uVar9 * 2);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e0f;
                    iVar5 = func_0x0001801adc80(in_RCX, uVar2, 0x304);
                    if (iVar5 != 0) {
                        if (*(int16_t *)(*(int64_t *)((int64_t)&var_18h + iVar6) + uVar9 * 2) == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e73;
                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                          *(int64_t *)((int64_t)&var_10h + iVar6));
                            goto code_r0x0001801f0e7f;
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e32;
                        iVar5 = fcn.1801eff90(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_18h + iVar6), 
                                              *(int64_t *)((int64_t)&var_20h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar6));
                        if (iVar5 == 0) {
                            return 0;
                        }
                        uVar8 = uVar8 + 1;
                        if (bVar3) break;
                    }
                }
                uVar9 = uVar9 + 1;
            } while (uVar9 < *(uint64_t *)((int64_t)&var_20h + iVar6));
            if (uVar8 != 0) goto code_r0x0001801f0e51;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0eeb;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
code_r0x0001801f0e7f:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e8b;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)(&stack0x00000038 + iVar6));
    } else {
        *(undefined8 *)(in_RCX + 0x338) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0da6;
        iVar5 = fcn.1801eff90(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_58h + iVar6));
        if (iVar5 == 0) {
            return 0;
        }
code_r0x0001801f0e51:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e59;
        iVar5 = fcn.180244000(*(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                              *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                              *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                              *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0e65;
            iVar5 = fcn.180244000(*(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                                  *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                                  *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
            if (iVar5 != 0) {
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ec6;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ede;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)(&stack0x00000038 + iVar6));
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f0ea1;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801f0f40
// Address: 0x1801f0f40
// Size: 207 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801f0f40(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f0f50;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(char *)(in_RCX + 0xb34) == '\0') {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f0f85;
    iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f0f96;
        iVar1 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f0faf;
            iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f0fbb;
                iVar1 = fcn.180244000(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                                      *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                                      *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2), 
                                      *(int64_t *)(&stack0x00000058 + iVar2));
                if (iVar1 != 0) {
                    return 1;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f0fd4;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f0fec;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1002;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1801f1010
// Address: 0x1801f1010
// Size: 202 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801f1010(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f1020;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((*(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x2f0) != 0) &&
       ((*(int64_t *)(in_RCX + 0x260) == 0 || (*(int64_t *)(in_RCX + 0x2e8) == 0)))) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1062;
        iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1076;
            iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
            if (iVar1 != 0) {
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f108f;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f10a7;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f10bd;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    return 2;
}

// ============================================================
// Function: FUN_1801f10e0
// Address: 0x1801f10e0
// Size: 426 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801f10e0(int64_t arg_38h, int64_t arg_40h, int64_t arg_78h)
{
    undefined4 uVar1;
    int32_t *piVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f10f0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((*(uint8_t *)(in_RCX + 0x9a8) & 0x10) == 0) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f111f;
    iVar4 = fcn.1802442e0(in_RDX, (int64_t)&arg_38h + iVar5);
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f1128;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f1140;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f1156;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    piVar2 = *(int32_t **)(in_RCX + 0x8f8);
    if (((*piVar2 == 0x304) && (*(int64_t *)(piVar2 + 0xca) != 0)) && (*(int64_t *)(piVar2 + 0xbe) != 0)) {
        uVar1 = *(undefined4 *)(*(int64_t *)(piVar2 + 0xbe) + 0x40);
        uVar3 = *(undefined8 *)(in_RCX + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f1194;
        iVar6 = fcn.1801a08e0(uVar3, uVar1);
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f11a1;
            iVar4 = fcn.18020f800(iVar6);
            if (iVar4 < 1) {
                return 0;
            }
            iVar6 = (int64_t)iVar4 + *(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x328) +
                    *(int64_t *)((int64_t)&arg_38h + iVar5) + 0xf;
            goto code_r0x0001801f11c9;
        }
    }
    iVar6 = *(int64_t *)((int64_t)&arg_38h + iVar5);
code_r0x0001801f11c9:
    if (0xff < iVar6 - 0x100U) {
        return 1;
    }
    if (-iVar6 + 0x200U < 5) {
        iVar6 = 1;
    } else {
        iVar6 = -iVar6 + 0x1fc;
    }
    *(int64_t *)((int64_t)&arg_38h + iVar5) = iVar6;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f1209;
    iVar4 = fcn.1802446f0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                          *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000058 + iVar5));
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f1225;
        iVar4 = fcn.180244b60(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        if (iVar4 != 0) {
            uVar3 = *(undefined8 *)((int64_t)&iStackX_20 + iVar5 + -8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f123a;
            fcn.1804986e0(uVar3, 0, *(undefined8 *)((int64_t)&arg_38h + iVar5));
            return 1;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f124f;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f1267;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                  *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                  *(int64_t *)(&stack0x00000048 + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f127d;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_1801f1290
// Address: 0x1801f1290
// Size: 192 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801f1290(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f12a0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int32_t *)(in_RCX + 0xbac) == 0) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f12d5;
    iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f12e6;
        iVar1 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f12f2;
            iVar1 = fcn.180244000(in_RDX);
            if (iVar1 != 0) {
                *(undefined4 *)(in_RCX + 0xba8) = 1;
                return 1;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1315;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f132d;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1343;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1801f1350
// Address: 0x1801f1350
// Size: 1591 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.1801f1350(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_88h)
{
    undefined4 uVar1;
    int32_t *piVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined auVar5 [16];
    bool bVar6;
    bool bVar7;
    int32_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    uint32_t uVar14;
    int64_t in_RCX;
    undefined8 uVar15;
    undefined8 in_RDX;
    int64_t iVar16;
    uint64_t uVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801f1372;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    uVar13 = 0;
    uVar15 = *(undefined8 *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_38h + iVar9) = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar9) = 0;
    piVar2 = *(int32_t **)(in_RCX + 0x8f8);
    *(undefined4 *)(in_RCX + 0xb38) = 0;
    *(undefined4 *)((int64_t)&arg_28h + iVar9) = 0;
    *(undefined4 *)((int64_t)&arg_88h + iVar9) = 0;
    iVar8 = *piVar2;
    *(undefined8 *)((int64_t)&arg_30h + iVar9) = uVar15;
    if (iVar8 != 0x304) {
        return (bool)2;
    }
    if ((*(int64_t *)(piVar2 + 0xca) == 0) && (*(int64_t *)(in_RCX + 0x900) == 0)) {
        return (bool)2;
    }
    uVar10 = uVar13;
    if (*(int32_t *)(in_RCX + 0x8c8) == 1) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f13e9;
        uVar10 = func_0x0001801a0380(in_RCX);
        uVar15 = *(undefined8 *)((int64_t)&arg_30h + iVar9);
    }
    uVar11 = uVar13;
    if (*(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x328) == 0) {
code_r0x0001801f15f4:
        if (*(int64_t *)(in_RCX + 0x900) == 0) {
            return (bool)2;
        }
        iVar16 = *(int64_t *)(in_RCX + 0x900);
        bVar7 = false;
code_r0x0001801f1608:
        bVar6 = bVar7;
        uVar1 = *(undefined4 *)(*(int64_t *)(iVar16 + 0x2f8) + 0x40);
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f161c;
        uVar13 = fcn.1801a08e0(*(undefined8 *)((int64_t)&arg_30h + iVar9), uVar1);
        if (uVar13 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f1629;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9));
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f1641;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                          *(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9));
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f1657;
            fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar9));
            return false;
        }
        if ((*(int32_t *)(in_RCX + 0x8c8) == 1) && (uVar13 != uVar10)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f1671;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9));
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f1689;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                          *(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9));
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f169f;
            fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar9));
            return false;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f16ae;
        iVar8 = fcn.18020f800(uVar13);
        if (iVar8 < 1) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f16be;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9));
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f16d6;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                          *(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9));
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f16ec;
            fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar9));
            return false;
        }
    } else {
        iVar16 = *(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2f8);
        if (iVar16 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f1416;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9));
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f142e;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                          *(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9));
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f1444;
            fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar9));
            return false;
        }
        uVar1 = *(undefined4 *)(iVar16 + 0x40);
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f1453;
        uVar11 = fcn.1801a08e0(uVar15, uVar1);
        if ((uVar11 == 0) || ((*(int32_t *)(in_RCX + 0x8c8) == 1 && (uVar11 != uVar10)))) goto code_r0x0001801f15f4;
        uVar3 = *(uint64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2e0);
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f1484;
        uVar12 = func_0x0001802450c0();
        uVar17 = uVar13;
        if (uVar3 <= uVar12) {
            uVar17 = uVar12 - uVar3;
        }
        auVar5._8_8_ = 0;
        auVar5._0_8_ = uVar17;
        iVar16 = SUB168(ZEXT816(0x12e0be826d694b2f) * auVar5, 8);
        iVar8 = (int32_t)((uVar17 - iVar16 >> 1) + iVar16 >> 0x1d);
        uVar14 = iVar8 - 1;
        if (iVar8 == 0) {
            uVar14 = 0;
        }
        if ((*(uint32_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x330) < uVar14) ||
           ((uVar14 != 0 && ((uVar14 * 1000) / 1000 != uVar14)))) goto code_r0x0001801f15f4;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f14fa;
        iVar8 = fcn.18020f800(uVar11);
        *(int32_t *)((int64_t)&arg_28h + iVar9) = iVar8;
        if (iVar8 < 1) goto code_r0x0001801f15f4;
        *(int32_t *)(in_RCX + 0xb38) = *(int32_t *)(in_RCX + 0xb38) + 1;
        bVar6 = true;
        iVar16 = *(int64_t *)(in_RCX + 0x900);
        *(undefined4 *)((int64_t)&arg_88h + iVar9) = 1;
        bVar7 = true;
        if (iVar16 != 0) goto code_r0x0001801f1608;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f153e;
    iVar8 = fcn.1802446f0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                          *(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)((int64_t)&arg_38h + iVar9));
    if (iVar8 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f1553;
        iVar8 = fcn.180244a90(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9));
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f1568;
            iVar8 = fcn.180244a90(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9)
                                 );
            if (iVar8 != 0) {
                if (bVar6) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f159b;
                    iVar8 = fcn.180244bf0(*(int64_t *)((int64_t)&var_8h + iVar9), 
                                          *(int64_t *)((int64_t)&var_10h + iVar9), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar9));
                    if (iVar8 == 0) {
code_r0x0001801f15b8:
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f15bd;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), 
                                      *(int64_t *)(&stack0x00000000 + iVar9));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f15d5;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), 
                                      *(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                                      *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&arg_28h + iVar9));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f15eb;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar9));
                        return false;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f15b0;
                    iVar8 = fcn.1802446f0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), 
                                          *(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                          , *(int64_t *)((int64_t)&arg_38h + iVar9));
                    if (iVar8 == 0) goto code_r0x0001801f15b8;
                }
                if (*(int64_t *)(in_RCX + 0x900) != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f1718;
                    iVar8 = fcn.180244bf0(*(int64_t *)((int64_t)&var_8h + iVar9), 
                                          *(int64_t *)((int64_t)&var_10h + iVar9), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar9));
                    if (iVar8 == 0) {
code_r0x0001801f18b5:
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f18ba;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), 
                                      *(int64_t *)(&stack0x00000000 + iVar9));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f18d2;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), 
                                      *(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                                      *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&arg_28h + iVar9));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f18e8;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar9));
                        return false;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f1730;
                    iVar8 = fcn.1802446f0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), 
                                          *(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                          , *(int64_t *)((int64_t)&arg_38h + iVar9));
                    if (iVar8 == 0) goto code_r0x0001801f18b5;
                    *(int32_t *)(in_RCX + 0xb38) = *(int32_t *)(in_RCX + 0xb38) + 1;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f1746;
                iVar8 = fcn.180244000(in_RDX);
                if (iVar8 != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f175b;
                    iVar8 = fcn.1802442e0(in_RDX, (int64_t)&arg_48h + iVar9);
                    if (iVar8 != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f1770;
                        iVar8 = fcn.180244a90(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), 
                                              *(int64_t *)(&stack0x00000000 + iVar9));
                        if (iVar8 != 0) {
                            if (bVar6) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f1794;
                                iVar8 = fcn.180244b60(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), 
                                                      *(int64_t *)(&stack0x00000000 + iVar9));
                                if (iVar8 == 0) goto code_r0x0001801f18f3;
                            }
                            if (*(int64_t *)(in_RCX + 0x900) != 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f17bb;
                                iVar8 = fcn.180244b60(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), 
                                                      *(int64_t *)(&stack0x00000000 + iVar9));
                                if (iVar8 == 0) goto code_r0x0001801f18f3;
                            }
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f17cb;
                            iVar8 = fcn.180244000(in_RDX);
                            if (iVar8 != 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f17db;
                                iVar8 = fcn.180244000(in_RDX);
                                if (iVar8 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f17f0;
                                    iVar8 = fcn.1802442e0(in_RDX, (int64_t)&arg_50h + iVar9);
                                    if (iVar8 != 0) {
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f1800;
                                        iVar8 = func_0x000180244040(in_RDX);
                                        if (iVar8 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f1810;
                                            iVar16 = func_0x000180244270(in_RDX);
                                            iVar16 = iVar16 - *(int64_t *)((int64_t)&arg_50h + iVar9);
                                            if (*(int32_t *)((int64_t)&arg_88h + iVar9) != 0) {
                                                uVar15 = *(undefined8 *)(in_RCX + 0x8f8);
                                                *(undefined4 *)((int64_t)&var_18h + iVar9) = 0;
                                                *(undefined4 *)((int64_t)&var_10h + iVar9) = 1;
                                                *(undefined8 *)((int64_t)&var_8h + iVar9) = uVar15;
                                                *(undefined8 *)(&stack0x00000000 + iVar9) =
                                                     *(undefined8 *)((int64_t)&arg_38h + iVar9);
                                                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9) = 0;
                                                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f185b;
                                                iVar8 = func_0x0001801c9e00(in_RCX, uVar11, iVar16, 
                                                                            *(undefined8 *)((int64_t)&arg_48h + iVar9));
                                                if (iVar8 != 1) {
                                                    return false;
                                                }
                                            }
                                            iVar4 = *(int64_t *)(in_RCX + 0x900);
                                            if (iVar4 != 0) {
                                                *(undefined4 *)((int64_t)&var_18h + iVar9) = 1;
                                                *(undefined4 *)((int64_t)&var_10h + iVar9) = 1;
                                                *(int64_t *)((int64_t)&var_8h + iVar9) = iVar4;
                                                *(undefined8 *)(&stack0x00000000 + iVar9) =
                                                     *(undefined8 *)((int64_t)&arg_40h + iVar9);
                                                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9) = 0;
                                                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f18a7;
                                                iVar8 = func_0x0001801c9e00(in_RCX, uVar13, iVar16, 
                                                                            *(undefined8 *)((int64_t)&arg_48h + iVar9));
                                                return iVar8 == 1;
                                            }
                                            return true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
code_r0x0001801f18f3:
                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f18f8;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9));
                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f1910;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                              *(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9), 
                              *(int64_t *)((int64_t)&arg_28h + iVar9));
                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f1926;
                fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar9));
                return false;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f192f;
    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9));
    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f1947;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                  *(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9), 
                  *(int64_t *)((int64_t)&arg_28h + iVar9));
    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801f195d;
    fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar9));
    return false;
}

// ============================================================
// Function: FUN_1801f1990
// Address: 0x1801f1990
// Size: 289 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801f1990(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint32_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f19a5;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar3 = *(uint32_t *)(in_RCX + 0x9a8) & 0x400;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f19cd;
    iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f19e2;
        iVar1 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f19f7;
            iVar1 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1a0b;
                iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
                if (iVar1 != 0) {
                    if (uVar3 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1a23;
                        iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar2), 
                                              *(int64_t *)(&stack0x00000058 + iVar2));
                        if (iVar1 == 0) goto code_r0x0001801f1a6c;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1a2f;
                    iVar1 = fcn.180244000(in_RDX);
                    if (iVar1 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1a3b;
                        iVar1 = fcn.180244000(in_RDX);
                        if (iVar1 != 0) {
                            *(undefined4 *)(in_RCX + 0xb10) = 2;
                            if (uVar3 != 0) {
                                *(undefined4 *)(in_RCX + 0xb10) = 3;
                            }
                            return 1;
                        }
                    }
                }
            }
        }
    }
code_r0x0001801f1a6c:
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1a71;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1a89;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1a9f;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1801f1ac0
// Address: 0x1801f1ac0
// Size: 376 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801f1ac0(int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f1ad0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int32_t *)(in_RCX + 0xba0) == 0) {
        if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
            if (0x303 < *(int32_t *)(in_RCX + 0x9b4)) {
                return 2;
            }
            *(undefined8 *)((int64_t)&iStackX_20 + iVar2 + -8) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1b20;
            iVar1 = func_0x0001801a2690();
            if ((iVar1 != 0) && (*(int32_t *)(in_RCX + 0x9b4) < 0x302)) {
                return 2;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1b53;
        iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar2));
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1b64;
            iVar1 = fcn.180244a90(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar2));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1b78;
                iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2)
                                      , *(int64_t *)(&stack0x00000058 + iVar2));
                if (iVar1 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1b84;
                    iVar1 = fcn.180244000(in_RDX);
                    if (iVar1 != 0) {
                        return 1;
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1b9d;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2));
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1bb7;
        iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar2));
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1bc8;
            iVar1 = fcn.180244a90(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar2));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1be8;
                iVar1 = fcn.180244bf0(*(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                                      *(int64_t *)(&stack0x00000048 + iVar2));
                if (iVar1 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1bf4;
                    iVar1 = fcn.180244000(in_RDX);
                    if (iVar1 != 0) {
                        return 1;
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1bfd;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1c15;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                  *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1c2b;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1801f1c40
// Address: 0x1801f1c40
// Size: 183 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801f1c40(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t in_R9;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f1c50;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((*(int64_t *)(in_RCX + 0xb68) != 0) && (in_R9 == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1c7f;
        iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1c93;
            iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
            if (iVar1 != 0) {
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1cac;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1cc4;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1cda;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    return 2;
}

// ============================================================
// Function: FUN_1801f1d00
// Address: 0x1801f1d00
// Size: 229 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801f1d00(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f1d10;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined *)(in_RCX + 0xb53) = 0;
    if (*(int64_t *)(in_RCX + 0x15a0) == 0) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1d4d;
    iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1d5e;
        iVar1 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1d7e;
            iVar1 = fcn.180244bf0(*(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                                  *(int64_t *)(&stack0x00000048 + iVar2));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1d8a;
                iVar1 = fcn.180244000(in_RDX);
                if (iVar1 != 0) {
                    *(undefined *)(in_RCX + 0xb53) = 1;
                    return 1;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1daa;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1dc2;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f1dd8;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1801f1df0
// Address: 0x1801f1df0
// Size: 273 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801f1df0(int64_t arg_28h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f1e00;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int64_t *)(in_RCX + 0xa18) == 0) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f1e33;
    iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000058 + iVar3));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f1e48;
        iVar2 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f1e59;
            iVar2 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f1e6d;
                iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000058 + iVar3));
                if (iVar2 != 0) {
                    uVar1 = *(undefined8 *)(in_RCX + 0xa18);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f1e7d;
                    fcn.180498cd0(uVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f1e95;
                    iVar2 = fcn.180244bf0(*(int64_t *)((int64_t)&arg_28h + iVar3), 
                                          *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3)
                                         );
                    if (iVar2 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f1ea1;
                        iVar2 = fcn.180244000(in_RDX);
                        if (iVar2 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f1ead;
                            iVar2 = fcn.180244000(in_RDX);
                            if (iVar2 != 0) {
                                return 1;
                            }
                        }
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f1ec6;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f1ede;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f1ef4;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_1801f1f10
// Address: 0x1801f1f10
// Size: 156 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801f1f10(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    uint16_t *puVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    uint64_t uVar8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1801f1f2b;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f1f39;
    iVar5 = func_0x0001801adc40();
    if (iVar5 == 0) {
code_r0x0001801f20c1:
        uVar7 = 2;
    } else {
        if ((((*(int32_t *)(in_RCX + 0x7c) == 0) && (piVar2 = *(int32_t **)(in_RCX + 0x8f8), piVar2 != (int32_t *)0x0))
            && (*(int64_t *)(piVar2 + 200) != 0)) && (*piVar2 != 0x304)) {
            uVar8 = *(uint64_t *)(piVar2 + 0xca);
code_r0x0001801f2031:
            if (uVar8 == 0) goto code_r0x0001801f203a;
        } else {
            piVar1 = (int64_t *)(in_RCX + 0x8f8);
            if (((*piVar1 != 0) && (puVar3 = *(uint16_t **)(in_RCX + 0xac8), puVar3 != (uint16_t *)0x0)) &&
               (*(int64_t *)(puVar3 + 4) != 0)) {
                uVar8 = (uint64_t)*puVar3;
                *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBX;
                iVar4 = *piVar1;
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f1fbf;
                uVar7 = func_0x0001802248d0(uVar8, 0x1804b7ba0, 300);
                *(undefined8 *)(iVar4 + 800) = uVar7;
                iVar4 = *(int64_t *)(*piVar1 + 800);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f1fdf;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f1ff7;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f200d;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar6));
                    return 0;
                }
                uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0xac8) + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f2027;
                func_0x000180498030(iVar4, uVar7, uVar8);
                *(uint64_t *)(*piVar1 + 0x328) = uVar8;
                goto code_r0x0001801f2031;
            }
code_r0x0001801f203a:
            if ((*(int64_t *)(in_RCX + 0xac8) != 0) && (*(int64_t *)(*(int64_t *)(in_RCX + 0xac8) + 8) == 0))
            goto code_r0x0001801f20c1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f2060;
        iVar5 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000058 + iVar6));
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f207f;
            iVar5 = fcn.180244bf0(*(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6));
            if (iVar5 != 0) {
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f208f;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f20a7;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                      *(int64_t *)(&stack0x00000048 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f20bd;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar6));
        uVar7 = 0;
    }
    return uVar7;
}

// ============================================================
// Function: FUN_1801f1fac
// Address: 0x1801f1fac
// Size: 46 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801f1f10(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    uint16_t *puVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    uint64_t uVar8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1801f1f2b;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f1f39;
    iVar5 = func_0x0001801adc40();
    if (iVar5 == 0) {
code_r0x0001801f20c1:
        uVar7 = 2;
    } else {
        if ((((*(int32_t *)(in_RCX + 0x7c) == 0) && (piVar2 = *(int32_t **)(in_RCX + 0x8f8), piVar2 != (int32_t *)0x0))
            && (*(int64_t *)(piVar2 + 200) != 0)) && (*piVar2 != 0x304)) {
            uVar8 = *(uint64_t *)(piVar2 + 0xca);
code_r0x0001801f2031:
            if (uVar8 == 0) goto code_r0x0001801f203a;
        } else {
            piVar1 = (int64_t *)(in_RCX + 0x8f8);
            if (((*piVar1 != 0) && (puVar3 = *(uint16_t **)(in_RCX + 0xac8), puVar3 != (uint16_t *)0x0)) &&
               (*(int64_t *)(puVar3 + 4) != 0)) {
                uVar8 = (uint64_t)*puVar3;
                *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBX;
                iVar4 = *piVar1;
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f1fbf;
                uVar7 = func_0x0001802248d0(uVar8, 0x1804b7ba0, 300);
                *(undefined8 *)(iVar4 + 800) = uVar7;
                iVar4 = *(int64_t *)(*piVar1 + 800);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f1fdf;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f1ff7;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f200d;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar6));
                    return 0;
                }
                uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0xac8) + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f2027;
                func_0x000180498030(iVar4, uVar7, uVar8);
                *(uint64_t *)(*piVar1 + 0x328) = uVar8;
                goto code_r0x0001801f2031;
            }
code_r0x0001801f203a:
            if ((*(int64_t *)(in_RCX + 0xac8) != 0) && (*(int64_t *)(*(int64_t *)(in_RCX + 0xac8) + 8) == 0))
            goto code_r0x0001801f20c1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f2060;
        iVar5 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000058 + iVar6));
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f207f;
            iVar5 = fcn.180244bf0(*(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6));
            if (iVar5 != 0) {
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f208f;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f20a7;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                      *(int64_t *)(&stack0x00000048 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f20bd;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar6));
        uVar7 = 0;
    }
    return uVar7;
}

// ============================================================
// Function: FUN_1801f1fda
// Address: 0x1801f1fda
// Size: 258 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801f1f10(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    uint16_t *puVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    uint64_t uVar8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1801f1f2b;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f1f39;
    iVar5 = func_0x0001801adc40();
    if (iVar5 == 0) {
code_r0x0001801f20c1:
        uVar7 = 2;
    } else {
        if ((((*(int32_t *)(in_RCX + 0x7c) == 0) && (piVar2 = *(int32_t **)(in_RCX + 0x8f8), piVar2 != (int32_t *)0x0))
            && (*(int64_t *)(piVar2 + 200) != 0)) && (*piVar2 != 0x304)) {
            uVar8 = *(uint64_t *)(piVar2 + 0xca);
code_r0x0001801f2031:
            if (uVar8 == 0) goto code_r0x0001801f203a;
        } else {
            piVar1 = (int64_t *)(in_RCX + 0x8f8);
            if (((*piVar1 != 0) && (puVar3 = *(uint16_t **)(in_RCX + 0xac8), puVar3 != (uint16_t *)0x0)) &&
               (*(int64_t *)(puVar3 + 4) != 0)) {
                uVar8 = (uint64_t)*puVar3;
                *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBX;
                iVar4 = *piVar1;
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f1fbf;
                uVar7 = func_0x0001802248d0(uVar8, 0x1804b7ba0, 300);
                *(undefined8 *)(iVar4 + 800) = uVar7;
                iVar4 = *(int64_t *)(*piVar1 + 800);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f1fdf;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f1ff7;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f200d;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar6));
                    return 0;
                }
                uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0xac8) + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f2027;
                func_0x000180498030(iVar4, uVar7, uVar8);
                *(uint64_t *)(*piVar1 + 0x328) = uVar8;
                goto code_r0x0001801f2031;
            }
code_r0x0001801f203a:
            if ((*(int64_t *)(in_RCX + 0xac8) != 0) && (*(int64_t *)(*(int64_t *)(in_RCX + 0xac8) + 8) == 0))
            goto code_r0x0001801f20c1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f2060;
        iVar5 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000058 + iVar6));
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f207f;
            iVar5 = fcn.180244bf0(*(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6));
            if (iVar5 != 0) {
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f208f;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f20a7;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                      *(int64_t *)(&stack0x00000048 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f20bd;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar6));
        uVar7 = 0;
    }
    return uVar7;
}

// ============================================================
// Function: FUN_1801f20e0
// Address: 0x1801f20e0
// Size: 135 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801f20e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f20f0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    piVar1 = *(int32_t **)(in_RCX + 0x18);
    iVar2 = *(int32_t *)(in_RCX + 0x9cc);
    if ((*(uint8_t *)(*(int64_t *)(piVar1 + 0x36) + 0x50) & 8) == 0) {
        if ((0x302 < iVar2) && ((*piVar1 == 0x10000 || (0x302 < *(int32_t *)(in_RCX + 0x48))))) {
code_r0x0001801f2162:
            *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2179;
            uVar4 = func_0x0001801a9eb0(in_RCX, 1, (int64_t)&arg_28h + iVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f218f;
            iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)(&stack0x00000058 + iVar3));
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f21a0;
                iVar2 = fcn.180244a90(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar3));
                if (iVar2 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f21b1;
                    iVar2 = fcn.180244a90(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3));
                    if (iVar2 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f21c8;
                        iVar2 = func_0x0001801a9d60(in_RCX, in_RDX, *(undefined8 *)((int64_t)&arg_28h + iVar3), uVar4);
                        if (iVar2 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f21d4;
                            iVar2 = fcn.180244000(in_RDX);
                            if (iVar2 != 0) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f21e0;
                                iVar2 = fcn.180244000(in_RDX);
                                if (iVar2 != 0) {
                                    return 1;
                                }
                            }
                        }
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f21fe;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2216;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f222c;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            return 0;
        }
    } else if (((iVar2 != 0x100) && (iVar2 < 0xfefe)) &&
              ((*piVar1 == 0x1ffff || ((*(int32_t *)(in_RCX + 0x48) != 0x100 && (*(int32_t *)(in_RCX + 0x48) < 0xfefe)))
               ))) goto code_r0x0001801f2162;
    return 2;
}

// ============================================================
// Function: FUN_1801f2167
// Address: 0x1801f2167
// Size: 146 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801f20e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f20f0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    piVar1 = *(int32_t **)(in_RCX + 0x18);
    iVar2 = *(int32_t *)(in_RCX + 0x9cc);
    if ((*(uint8_t *)(*(int64_t *)(piVar1 + 0x36) + 0x50) & 8) == 0) {
        if ((0x302 < iVar2) && ((*piVar1 == 0x10000 || (0x302 < *(int32_t *)(in_RCX + 0x48))))) {
code_r0x0001801f2162:
            *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2179;
            uVar4 = func_0x0001801a9eb0(in_RCX, 1, (int64_t)&arg_28h + iVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f218f;
            iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)(&stack0x00000058 + iVar3));
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f21a0;
                iVar2 = fcn.180244a90(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar3));
                if (iVar2 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f21b1;
                    iVar2 = fcn.180244a90(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3));
                    if (iVar2 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f21c8;
                        iVar2 = func_0x0001801a9d60(in_RCX, in_RDX, *(undefined8 *)((int64_t)&arg_28h + iVar3), uVar4);
                        if (iVar2 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f21d4;
                            iVar2 = fcn.180244000(in_RDX);
                            if (iVar2 != 0) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f21e0;
                                iVar2 = fcn.180244000(in_RDX);
                                if (iVar2 != 0) {
                                    return 1;
                                }
                            }
                        }
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f21fe;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2216;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f222c;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            return 0;
        }
    } else if (((iVar2 != 0x100) && (iVar2 < 0xfefe)) &&
              ((*piVar1 == 0x1ffff || ((*(int32_t *)(in_RCX + 0x48) != 0x100 && (*(int32_t *)(in_RCX + 0x48) < 0xfefe)))
               ))) goto code_r0x0001801f2162;
    return 2;
}

// ============================================================
// Function: FUN_1801f21f9
// Address: 0x1801f21f9
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801f20e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f20f0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    piVar1 = *(int32_t **)(in_RCX + 0x18);
    iVar2 = *(int32_t *)(in_RCX + 0x9cc);
    if ((*(uint8_t *)(*(int64_t *)(piVar1 + 0x36) + 0x50) & 8) == 0) {
        if ((0x302 < iVar2) && ((*piVar1 == 0x10000 || (0x302 < *(int32_t *)(in_RCX + 0x48))))) {
code_r0x0001801f2162:
            *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2179;
            uVar4 = func_0x0001801a9eb0(in_RCX, 1, (int64_t)&arg_28h + iVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f218f;
            iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)(&stack0x00000058 + iVar3));
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f21a0;
                iVar2 = fcn.180244a90(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar3));
                if (iVar2 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f21b1;
                    iVar2 = fcn.180244a90(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3));
                    if (iVar2 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f21c8;
                        iVar2 = func_0x0001801a9d60(in_RCX, in_RDX, *(undefined8 *)((int64_t)&arg_28h + iVar3), uVar4);
                        if (iVar2 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f21d4;
                            iVar2 = fcn.180244000(in_RDX);
                            if (iVar2 != 0) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f21e0;
                                iVar2 = fcn.180244000(in_RDX);
                                if (iVar2 != 0) {
                                    return 1;
                                }
                            }
                        }
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f21fe;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2216;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f222c;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            return 0;
        }
    } else if (((iVar2 != 0x100) && (iVar2 < 0xfefe)) &&
              ((*piVar1 == 0x1ffff || ((*(int32_t *)(in_RCX + 0x48) != 0x100 && (*(int32_t *)(in_RCX + 0x48) < 0xfefe)))
               ))) goto code_r0x0001801f2162;
    return 2;
}

// ============================================================
// Function: FUN_1801f2240
// Address: 0x1801f2240
// Size: 263 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801f2240(int64_t arg_28h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f2250;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int64_t *)(in_RCX + 0xbf0) == 0) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2286;
    iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000058 + iVar3));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2297;
        iVar2 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f22a8;
            iVar2 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f22b9;
                iVar2 = fcn.180244980(in_RDX, 1);
                if (iVar2 != 0) {
                    uVar1 = *(undefined8 *)(in_RCX + 0xbf0);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f22c9;
                    fcn.180498cd0(uVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f22db;
                    iVar2 = fcn.1802445f0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                          *(int64_t *)(&stack0x00000058 + iVar3));
                    if (iVar2 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f22e7;
                        iVar2 = fcn.180244000(in_RDX);
                        if (iVar2 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f22f3;
                            iVar2 = fcn.180244000(in_RDX);
                            if (iVar2 != 0) {
                                return 1;
                            }
                        }
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f230c;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2324;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f233a;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_1801f2350
// Address: 0x1801f2350
// Size: 144 bytes
// ============================================================
undefined8 fcn.1801f2350(int64_t arg_30h, int64_t arg_38h, int64_t arg_48h)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    int32_t iVar6;
    undefined8 unaff_RDI;
    int64_t in_R9;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_18;
    
    uStack_18 = 0x1801f235d;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((in_R9 != 0) || (*(int32_t *)(in_RCX + 0xa20) != 1)) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f238f;
    iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000050 + iVar4));
    if (iVar2 == 0) {
code_r0x0001801f2599:
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f259e;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f25b6;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)(&stack0x00000040 + iVar4));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f25cc;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f23a4;
    iVar2 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4));
    if (iVar2 == 0) goto code_r0x0001801f2599;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f23bc;
    iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000050 + iVar4));
    if (iVar2 == 0) goto code_r0x0001801f2599;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f23d1;
    iVar2 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4));
    if (iVar2 == 0) goto code_r0x0001801f2599;
    uVar5 = *(undefined8 *)(in_RCX + 0xa38);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
    iVar6 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f23f6;
    iVar2 = fcn.180222010(uVar5);
    if (0 < iVar2) {
        do {
            uVar5 = *(undefined8 *)(in_RCX + 0xa38);
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f240e;
            uVar5 = fcn.180222340(uVar5, iVar6);
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f241b;
            iVar2 = func_0x00018023f2a0(uVar5, 0);
            if (iVar2 < 1) {
code_r0x0001801f24f9:
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f24fe;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar4));
                goto code_r0x0001801f24bf;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f243c;
            iVar3 = fcn.180244b60(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4));
            if (iVar3 == 0) goto code_r0x0001801f24f9;
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2451;
            iVar3 = func_0x00018023f2a0(uVar5, (int64_t)&arg_48h + iVar4);
            if (iVar3 != iVar2) goto code_r0x0001801f24f9;
            uVar5 = *(undefined8 *)(in_RCX + 0xa38);
            iVar6 = iVar6 + 1;
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2467;
            iVar2 = fcn.180222010(uVar5);
        } while (iVar6 < iVar2);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2473;
    iVar2 = fcn.180244000(in_RDX);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2488;
        iVar2 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar4));
        if (iVar2 != 0) {
            iVar1 = *(int64_t *)(in_RCX + 0xa40);
            if (iVar1 == 0) {
code_r0x0001801f254b:
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2553;
                iVar2 = fcn.180244000(in_RDX);
                if (iVar2 != 0) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f255f;
                    iVar2 = fcn.180244000(in_RDX);
                    if (iVar2 != 0) {
                        return 1;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2572;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar4));
            } else {
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f24a7;
                iVar2 = func_0x000180237490(iVar1, 0);
                if (iVar2 < 0) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f24b3;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4));
                    goto code_r0x0001801f24bf;
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f251c;
                iVar6 = func_0x000180243f60(in_RDX, (int64_t)iVar2, (int64_t)&arg_48h + iVar4);
                if (iVar6 != 0) {
                    uVar5 = *(undefined8 *)(in_RCX + 0xa40);
                    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2531;
                    iVar6 = func_0x000180237490(uVar5, (int64_t)&arg_48h + iVar4);
                    if (iVar6 == iVar2) goto code_r0x0001801f254b;
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f253a;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar4));
            }
            goto code_r0x0001801f24bf;
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2588;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4));
code_r0x0001801f24bf:
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f24cb;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000028 + iVar4), 
                  *(int64_t *)(&stack0x00000040 + iVar4));
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f24e1;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_1801f23e0
// Address: 0x1801f23e0
// Size: 281 bytes
// ============================================================
undefined8 fcn.1801f2350(int64_t arg_30h, int64_t arg_38h, int64_t arg_48h)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    int32_t iVar6;
    undefined8 unaff_RDI;
    int64_t in_R9;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_18;
    
    uStack_18 = 0x1801f235d;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((in_R9 != 0) || (*(int32_t *)(in_RCX + 0xa20) != 1)) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f238f;
    iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000050 + iVar4));
    if (iVar2 == 0) {
code_r0x0001801f2599:
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f259e;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f25b6;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)(&stack0x00000040 + iVar4));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f25cc;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f23a4;
    iVar2 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4));
    if (iVar2 == 0) goto code_r0x0001801f2599;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f23bc;
    iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000050 + iVar4));
    if (iVar2 == 0) goto code_r0x0001801f2599;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f23d1;
    iVar2 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4));
    if (iVar2 == 0) goto code_r0x0001801f2599;
    uVar5 = *(undefined8 *)(in_RCX + 0xa38);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
    iVar6 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f23f6;
    iVar2 = fcn.180222010(uVar5);
    if (0 < iVar2) {
        do {
            uVar5 = *(undefined8 *)(in_RCX + 0xa38);
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f240e;
            uVar5 = fcn.180222340(uVar5, iVar6);
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f241b;
            iVar2 = func_0x00018023f2a0(uVar5, 0);
            if (iVar2 < 1) {
code_r0x0001801f24f9:
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f24fe;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar4));
                goto code_r0x0001801f24bf;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f243c;
            iVar3 = fcn.180244b60(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4));
            if (iVar3 == 0) goto code_r0x0001801f24f9;
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2451;
            iVar3 = func_0x00018023f2a0(uVar5, (int64_t)&arg_48h + iVar4);
            if (iVar3 != iVar2) goto code_r0x0001801f24f9;
            uVar5 = *(undefined8 *)(in_RCX + 0xa38);
            iVar6 = iVar6 + 1;
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2467;
            iVar2 = fcn.180222010(uVar5);
        } while (iVar6 < iVar2);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2473;
    iVar2 = fcn.180244000(in_RDX);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2488;
        iVar2 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar4));
        if (iVar2 != 0) {
            iVar1 = *(int64_t *)(in_RCX + 0xa40);
            if (iVar1 == 0) {
code_r0x0001801f254b:
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2553;
                iVar2 = fcn.180244000(in_RDX);
                if (iVar2 != 0) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f255f;
                    iVar2 = fcn.180244000(in_RDX);
                    if (iVar2 != 0) {
                        return 1;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2572;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar4));
            } else {
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f24a7;
                iVar2 = func_0x000180237490(iVar1, 0);
                if (iVar2 < 0) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f24b3;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4));
                    goto code_r0x0001801f24bf;
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f251c;
                iVar6 = func_0x000180243f60(in_RDX, (int64_t)iVar2, (int64_t)&arg_48h + iVar4);
                if (iVar6 != 0) {
                    uVar5 = *(undefined8 *)(in_RCX + 0xa40);
                    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2531;
                    iVar6 = func_0x000180237490(uVar5, (int64_t)&arg_48h + iVar4);
                    if (iVar6 == iVar2) goto code_r0x0001801f254b;
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f253a;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar4));
            }
            goto code_r0x0001801f24bf;
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2588;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4));
code_r0x0001801f24bf:
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f24cb;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000028 + iVar4), 
                  *(int64_t *)(&stack0x00000040 + iVar4));
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f24e1;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_1801f24f9
// Address: 0x1801f24f9
// Size: 160 bytes
// ============================================================
undefined8 fcn.1801f2350(int64_t arg_30h, int64_t arg_38h, int64_t arg_48h)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    int32_t iVar6;
    undefined8 unaff_RDI;
    int64_t in_R9;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_18;
    
    uStack_18 = 0x1801f235d;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((in_R9 != 0) || (*(int32_t *)(in_RCX + 0xa20) != 1)) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f238f;
    iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000050 + iVar4));
    if (iVar2 == 0) {
code_r0x0001801f2599:
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f259e;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f25b6;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)(&stack0x00000040 + iVar4));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f25cc;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f23a4;
    iVar2 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4));
    if (iVar2 == 0) goto code_r0x0001801f2599;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f23bc;
    iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000050 + iVar4));
    if (iVar2 == 0) goto code_r0x0001801f2599;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f23d1;
    iVar2 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4));
    if (iVar2 == 0) goto code_r0x0001801f2599;
    uVar5 = *(undefined8 *)(in_RCX + 0xa38);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
    iVar6 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f23f6;
    iVar2 = fcn.180222010(uVar5);
    if (0 < iVar2) {
        do {
            uVar5 = *(undefined8 *)(in_RCX + 0xa38);
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f240e;
            uVar5 = fcn.180222340(uVar5, iVar6);
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f241b;
            iVar2 = func_0x00018023f2a0(uVar5, 0);
            if (iVar2 < 1) {
code_r0x0001801f24f9:
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f24fe;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar4));
                goto code_r0x0001801f24bf;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f243c;
            iVar3 = fcn.180244b60(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4));
            if (iVar3 == 0) goto code_r0x0001801f24f9;
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2451;
            iVar3 = func_0x00018023f2a0(uVar5, (int64_t)&arg_48h + iVar4);
            if (iVar3 != iVar2) goto code_r0x0001801f24f9;
            uVar5 = *(undefined8 *)(in_RCX + 0xa38);
            iVar6 = iVar6 + 1;
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2467;
            iVar2 = fcn.180222010(uVar5);
        } while (iVar6 < iVar2);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2473;
    iVar2 = fcn.180244000(in_RDX);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2488;
        iVar2 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar4));
        if (iVar2 != 0) {
            iVar1 = *(int64_t *)(in_RCX + 0xa40);
            if (iVar1 == 0) {
code_r0x0001801f254b:
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2553;
                iVar2 = fcn.180244000(in_RDX);
                if (iVar2 != 0) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f255f;
                    iVar2 = fcn.180244000(in_RDX);
                    if (iVar2 != 0) {
                        return 1;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2572;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar4));
            } else {
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f24a7;
                iVar2 = func_0x000180237490(iVar1, 0);
                if (iVar2 < 0) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f24b3;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4));
                    goto code_r0x0001801f24bf;
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f251c;
                iVar6 = func_0x000180243f60(in_RDX, (int64_t)iVar2, (int64_t)&arg_48h + iVar4);
                if (iVar6 != 0) {
                    uVar5 = *(undefined8 *)(in_RCX + 0xa40);
                    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2531;
                    iVar6 = func_0x000180237490(uVar5, (int64_t)&arg_48h + iVar4);
                    if (iVar6 == iVar2) goto code_r0x0001801f254b;
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f253a;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar4));
            }
            goto code_r0x0001801f24bf;
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2588;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4));
code_r0x0001801f24bf:
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f24cb;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000028 + iVar4), 
                  *(int64_t *)(&stack0x00000040 + iVar4));
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f24e1;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_1801f2599
// Address: 0x1801f2599
// Size: 72 bytes
// ============================================================
undefined8 fcn.1801f2350(int64_t arg_30h, int64_t arg_38h, int64_t arg_48h)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    int32_t iVar6;
    undefined8 unaff_RDI;
    int64_t in_R9;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_18;
    
    uStack_18 = 0x1801f235d;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((in_R9 != 0) || (*(int32_t *)(in_RCX + 0xa20) != 1)) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f238f;
    iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000050 + iVar4));
    if (iVar2 == 0) {
code_r0x0001801f2599:
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f259e;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f25b6;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)(&stack0x00000040 + iVar4));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f25cc;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f23a4;
    iVar2 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4));
    if (iVar2 == 0) goto code_r0x0001801f2599;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f23bc;
    iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000050 + iVar4));
    if (iVar2 == 0) goto code_r0x0001801f2599;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f23d1;
    iVar2 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4));
    if (iVar2 == 0) goto code_r0x0001801f2599;
    uVar5 = *(undefined8 *)(in_RCX + 0xa38);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
    iVar6 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f23f6;
    iVar2 = fcn.180222010(uVar5);
    if (0 < iVar2) {
        do {
            uVar5 = *(undefined8 *)(in_RCX + 0xa38);
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f240e;
            uVar5 = fcn.180222340(uVar5, iVar6);
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f241b;
            iVar2 = func_0x00018023f2a0(uVar5, 0);
            if (iVar2 < 1) {
code_r0x0001801f24f9:
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f24fe;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar4));
                goto code_r0x0001801f24bf;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f243c;
            iVar3 = fcn.180244b60(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4));
            if (iVar3 == 0) goto code_r0x0001801f24f9;
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2451;
            iVar3 = func_0x00018023f2a0(uVar5, (int64_t)&arg_48h + iVar4);
            if (iVar3 != iVar2) goto code_r0x0001801f24f9;
            uVar5 = *(undefined8 *)(in_RCX + 0xa38);
            iVar6 = iVar6 + 1;
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2467;
            iVar2 = fcn.180222010(uVar5);
        } while (iVar6 < iVar2);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2473;
    iVar2 = fcn.180244000(in_RDX);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2488;
        iVar2 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar4));
        if (iVar2 != 0) {
            iVar1 = *(int64_t *)(in_RCX + 0xa40);
            if (iVar1 == 0) {
code_r0x0001801f254b:
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2553;
                iVar2 = fcn.180244000(in_RDX);
                if (iVar2 != 0) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f255f;
                    iVar2 = fcn.180244000(in_RDX);
                    if (iVar2 != 0) {
                        return 1;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2572;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar4));
            } else {
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f24a7;
                iVar2 = func_0x000180237490(iVar1, 0);
                if (iVar2 < 0) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f24b3;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4));
                    goto code_r0x0001801f24bf;
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f251c;
                iVar6 = func_0x000180243f60(in_RDX, (int64_t)iVar2, (int64_t)&arg_48h + iVar4);
                if (iVar6 != 0) {
                    uVar5 = *(undefined8 *)(in_RCX + 0xa40);
                    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2531;
                    iVar6 = func_0x000180237490(uVar5, (int64_t)&arg_48h + iVar4);
                    if (iVar6 == iVar2) goto code_r0x0001801f254b;
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f253a;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar4));
            }
            goto code_r0x0001801f24bf;
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f2588;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4));
code_r0x0001801f24bf:
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f24cb;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000028 + iVar4), 
                  *(int64_t *)(&stack0x00000040 + iVar4));
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801f24e1;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_1801f25f0
// Address: 0x1801f25f0
// Size: 307 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

undefined8 fcn.1801f25f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_50h, int64_t arg_58h)
{
    undefined2 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f260f;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar5 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f263d;
    iVar3 = func_0x0001801af910();
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2648;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2660;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2673;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar4));
        return 0;
    }
    uVar2 = *(undefined4 *)((int64_t)&var_18h + iVar4 + 4);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f268b;
    iVar3 = func_0x0001801f4d20(in_RCX, uVar2, *(undefined4 *)((int64_t)&var_18h + iVar4));
    if ((iVar3 == 0) &&
       (((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) != 0 ||
        (*(int32_t *)((int64_t)&var_18h + iVar4) < 0x304)))) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f26c6;
    func_0x0001801ab620(in_RCX, (int64_t)&arg_30h + iVar4, (int64_t)&arg_28h + iVar4);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f26d9;
    iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                          *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4));
    if (iVar3 == 0) {
code_r0x0001801f28c8:
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f28cd;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f28e5;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f28fb;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f26ee;
    iVar3 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    if (iVar3 == 0) goto code_r0x0001801f28c8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2703;
    iVar3 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    if (iVar3 == 0) goto code_r0x0001801f28c8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2718;
    iVar3 = fcn.180244980(in_RDX, 1);
    if (iVar3 == 0) goto code_r0x0001801f28c8;
    *(undefined8 *)((int64_t)&arg_58h + iVar4) = unaff_RSI;
    uVar6 = uVar5;
    if (*(int64_t *)((int64_t)&arg_28h + iVar4) != 0) {
        do {
            uVar2 = *(undefined4 *)((int64_t)&var_18h + iVar4 + 4);
            uVar1 = *(undefined2 *)(*(int64_t *)((int64_t)&arg_30h + iVar4) + uVar5 * 2);
            *(int64_t *)((int64_t)&var_10h + iVar4) = (int64_t)&var_20h + iVar4;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2760;
            iVar3 = func_0x0001801adc80(in_RCX, uVar1, uVar2, *(undefined4 *)((int64_t)&var_18h + iVar4));
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2775;
                iVar3 = func_0x0001801ada30(in_RCX, uVar1, 0x20004);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2789;
                    iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar4), 
                                          *(int64_t *)((int64_t)&var_10h + iVar4), 
                                          *(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)(&stack0x00000048 + iVar4));
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2847;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f285f;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar4));
                        goto code_r0x0001801f2818;
                    }
                    if ((*(int32_t *)((int64_t)&var_20h + iVar4) != 0) &&
                       (*(int32_t *)((int64_t)&var_18h + iVar4) == 0x304)) {
                        uVar6 = uVar6 + 1;
                    }
                }
            }
            uVar5 = uVar5 + 1;
        } while (uVar5 < *(uint64_t *)((int64_t)&arg_28h + iVar4));
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f27ba;
    iVar3 = fcn.180244000(in_RDX);
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f27ca;
        iVar3 = fcn.180244000(in_RDX);
        if (iVar3 != 0) {
            if ((uVar6 != 0) || (*(int32_t *)((int64_t)&var_18h + iVar4) != 0x304)) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f27ee;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2806;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                          *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4));
            goto code_r0x0001801f2818;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f287b;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f289e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                  *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)((int64_t)&arg_38h + iVar4));
code_r0x0001801f2818:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2820;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_1801f2723
// Address: 0x1801f2723
// Size: 260 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

undefined8 fcn.1801f25f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_50h, int64_t arg_58h)
{
    undefined2 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f260f;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar5 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f263d;
    iVar3 = func_0x0001801af910();
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2648;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2660;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2673;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar4));
        return 0;
    }
    uVar2 = *(undefined4 *)((int64_t)&var_18h + iVar4 + 4);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f268b;
    iVar3 = func_0x0001801f4d20(in_RCX, uVar2, *(undefined4 *)((int64_t)&var_18h + iVar4));
    if ((iVar3 == 0) &&
       (((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) != 0 ||
        (*(int32_t *)((int64_t)&var_18h + iVar4) < 0x304)))) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f26c6;
    func_0x0001801ab620(in_RCX, (int64_t)&arg_30h + iVar4, (int64_t)&arg_28h + iVar4);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f26d9;
    iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                          *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4));
    if (iVar3 == 0) {
code_r0x0001801f28c8:
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f28cd;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f28e5;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f28fb;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f26ee;
    iVar3 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    if (iVar3 == 0) goto code_r0x0001801f28c8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2703;
    iVar3 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    if (iVar3 == 0) goto code_r0x0001801f28c8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2718;
    iVar3 = fcn.180244980(in_RDX, 1);
    if (iVar3 == 0) goto code_r0x0001801f28c8;
    *(undefined8 *)((int64_t)&arg_58h + iVar4) = unaff_RSI;
    uVar6 = uVar5;
    if (*(int64_t *)((int64_t)&arg_28h + iVar4) != 0) {
        do {
            uVar2 = *(undefined4 *)((int64_t)&var_18h + iVar4 + 4);
            uVar1 = *(undefined2 *)(*(int64_t *)((int64_t)&arg_30h + iVar4) + uVar5 * 2);
            *(int64_t *)((int64_t)&var_10h + iVar4) = (int64_t)&var_20h + iVar4;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2760;
            iVar3 = func_0x0001801adc80(in_RCX, uVar1, uVar2, *(undefined4 *)((int64_t)&var_18h + iVar4));
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2775;
                iVar3 = func_0x0001801ada30(in_RCX, uVar1, 0x20004);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2789;
                    iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar4), 
                                          *(int64_t *)((int64_t)&var_10h + iVar4), 
                                          *(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)(&stack0x00000048 + iVar4));
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2847;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f285f;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar4));
                        goto code_r0x0001801f2818;
                    }
                    if ((*(int32_t *)((int64_t)&var_20h + iVar4) != 0) &&
                       (*(int32_t *)((int64_t)&var_18h + iVar4) == 0x304)) {
                        uVar6 = uVar6 + 1;
                    }
                }
            }
            uVar5 = uVar5 + 1;
        } while (uVar5 < *(uint64_t *)((int64_t)&arg_28h + iVar4));
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f27ba;
    iVar3 = fcn.180244000(in_RDX);
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f27ca;
        iVar3 = fcn.180244000(in_RDX);
        if (iVar3 != 0) {
            if ((uVar6 != 0) || (*(int32_t *)((int64_t)&var_18h + iVar4) != 0x304)) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f27ee;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2806;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                          *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4));
            goto code_r0x0001801f2818;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f287b;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f289e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                  *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)((int64_t)&arg_38h + iVar4));
code_r0x0001801f2818:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2820;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_1801f2827
// Address: 0x1801f2827
// Size: 27 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

undefined8 fcn.1801f25f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_50h, int64_t arg_58h)
{
    undefined2 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f260f;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar5 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f263d;
    iVar3 = func_0x0001801af910();
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2648;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2660;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2673;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar4));
        return 0;
    }
    uVar2 = *(undefined4 *)((int64_t)&var_18h + iVar4 + 4);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f268b;
    iVar3 = func_0x0001801f4d20(in_RCX, uVar2, *(undefined4 *)((int64_t)&var_18h + iVar4));
    if ((iVar3 == 0) &&
       (((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) != 0 ||
        (*(int32_t *)((int64_t)&var_18h + iVar4) < 0x304)))) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f26c6;
    func_0x0001801ab620(in_RCX, (int64_t)&arg_30h + iVar4, (int64_t)&arg_28h + iVar4);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f26d9;
    iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                          *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4));
    if (iVar3 == 0) {
code_r0x0001801f28c8:
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f28cd;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f28e5;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f28fb;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f26ee;
    iVar3 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    if (iVar3 == 0) goto code_r0x0001801f28c8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2703;
    iVar3 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    if (iVar3 == 0) goto code_r0x0001801f28c8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2718;
    iVar3 = fcn.180244980(in_RDX, 1);
    if (iVar3 == 0) goto code_r0x0001801f28c8;
    *(undefined8 *)((int64_t)&arg_58h + iVar4) = unaff_RSI;
    uVar6 = uVar5;
    if (*(int64_t *)((int64_t)&arg_28h + iVar4) != 0) {
        do {
            uVar2 = *(undefined4 *)((int64_t)&var_18h + iVar4 + 4);
            uVar1 = *(undefined2 *)(*(int64_t *)((int64_t)&arg_30h + iVar4) + uVar5 * 2);
            *(int64_t *)((int64_t)&var_10h + iVar4) = (int64_t)&var_20h + iVar4;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2760;
            iVar3 = func_0x0001801adc80(in_RCX, uVar1, uVar2, *(undefined4 *)((int64_t)&var_18h + iVar4));
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2775;
                iVar3 = func_0x0001801ada30(in_RCX, uVar1, 0x20004);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2789;
                    iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar4), 
                                          *(int64_t *)((int64_t)&var_10h + iVar4), 
                                          *(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)(&stack0x00000048 + iVar4));
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2847;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f285f;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar4));
                        goto code_r0x0001801f2818;
                    }
                    if ((*(int32_t *)((int64_t)&var_20h + iVar4) != 0) &&
                       (*(int32_t *)((int64_t)&var_18h + iVar4) == 0x304)) {
                        uVar6 = uVar6 + 1;
                    }
                }
            }
            uVar5 = uVar5 + 1;
        } while (uVar5 < *(uint64_t *)((int64_t)&arg_28h + iVar4));
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f27ba;
    iVar3 = fcn.180244000(in_RDX);
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f27ca;
        iVar3 = fcn.180244000(in_RDX);
        if (iVar3 != 0) {
            if ((uVar6 != 0) || (*(int32_t *)((int64_t)&var_18h + iVar4) != 0x304)) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f27ee;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2806;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                          *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4));
            goto code_r0x0001801f2818;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f287b;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f289e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                  *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)((int64_t)&arg_38h + iVar4));
code_r0x0001801f2818:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2820;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_1801f2842
// Address: 0x1801f2842
// Size: 134 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

undefined8 fcn.1801f25f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_50h, int64_t arg_58h)
{
    undefined2 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f260f;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar5 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f263d;
    iVar3 = func_0x0001801af910();
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2648;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2660;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2673;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar4));
        return 0;
    }
    uVar2 = *(undefined4 *)((int64_t)&var_18h + iVar4 + 4);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f268b;
    iVar3 = func_0x0001801f4d20(in_RCX, uVar2, *(undefined4 *)((int64_t)&var_18h + iVar4));
    if ((iVar3 == 0) &&
       (((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) != 0 ||
        (*(int32_t *)((int64_t)&var_18h + iVar4) < 0x304)))) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f26c6;
    func_0x0001801ab620(in_RCX, (int64_t)&arg_30h + iVar4, (int64_t)&arg_28h + iVar4);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f26d9;
    iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                          *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4));
    if (iVar3 == 0) {
code_r0x0001801f28c8:
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f28cd;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f28e5;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f28fb;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f26ee;
    iVar3 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    if (iVar3 == 0) goto code_r0x0001801f28c8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2703;
    iVar3 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    if (iVar3 == 0) goto code_r0x0001801f28c8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2718;
    iVar3 = fcn.180244980(in_RDX, 1);
    if (iVar3 == 0) goto code_r0x0001801f28c8;
    *(undefined8 *)((int64_t)&arg_58h + iVar4) = unaff_RSI;
    uVar6 = uVar5;
    if (*(int64_t *)((int64_t)&arg_28h + iVar4) != 0) {
        do {
            uVar2 = *(undefined4 *)((int64_t)&var_18h + iVar4 + 4);
            uVar1 = *(undefined2 *)(*(int64_t *)((int64_t)&arg_30h + iVar4) + uVar5 * 2);
            *(int64_t *)((int64_t)&var_10h + iVar4) = (int64_t)&var_20h + iVar4;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2760;
            iVar3 = func_0x0001801adc80(in_RCX, uVar1, uVar2, *(undefined4 *)((int64_t)&var_18h + iVar4));
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2775;
                iVar3 = func_0x0001801ada30(in_RCX, uVar1, 0x20004);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2789;
                    iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar4), 
                                          *(int64_t *)((int64_t)&var_10h + iVar4), 
                                          *(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)(&stack0x00000048 + iVar4));
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2847;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f285f;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar4));
                        goto code_r0x0001801f2818;
                    }
                    if ((*(int32_t *)((int64_t)&var_20h + iVar4) != 0) &&
                       (*(int32_t *)((int64_t)&var_18h + iVar4) == 0x304)) {
                        uVar6 = uVar6 + 1;
                    }
                }
            }
            uVar5 = uVar5 + 1;
        } while (uVar5 < *(uint64_t *)((int64_t)&arg_28h + iVar4));
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f27ba;
    iVar3 = fcn.180244000(in_RDX);
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f27ca;
        iVar3 = fcn.180244000(in_RDX);
        if (iVar3 != 0) {
            if ((uVar6 != 0) || (*(int32_t *)((int64_t)&var_18h + iVar4) != 0x304)) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f27ee;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2806;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                          *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4));
            goto code_r0x0001801f2818;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f287b;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f289e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                  *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)((int64_t)&arg_38h + iVar4));
code_r0x0001801f2818:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2820;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_1801f28c8
// Address: 0x1801f28c8
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

undefined8 fcn.1801f25f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_50h, int64_t arg_58h)
{
    undefined2 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f260f;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar5 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f263d;
    iVar3 = func_0x0001801af910();
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2648;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2660;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2673;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar4));
        return 0;
    }
    uVar2 = *(undefined4 *)((int64_t)&var_18h + iVar4 + 4);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f268b;
    iVar3 = func_0x0001801f4d20(in_RCX, uVar2, *(undefined4 *)((int64_t)&var_18h + iVar4));
    if ((iVar3 == 0) &&
       (((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) != 0 ||
        (*(int32_t *)((int64_t)&var_18h + iVar4) < 0x304)))) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f26c6;
    func_0x0001801ab620(in_RCX, (int64_t)&arg_30h + iVar4, (int64_t)&arg_28h + iVar4);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f26d9;
    iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                          *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4));
    if (iVar3 == 0) {
code_r0x0001801f28c8:
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f28cd;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f28e5;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f28fb;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f26ee;
    iVar3 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    if (iVar3 == 0) goto code_r0x0001801f28c8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2703;
    iVar3 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    if (iVar3 == 0) goto code_r0x0001801f28c8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2718;
    iVar3 = fcn.180244980(in_RDX, 1);
    if (iVar3 == 0) goto code_r0x0001801f28c8;
    *(undefined8 *)((int64_t)&arg_58h + iVar4) = unaff_RSI;
    uVar6 = uVar5;
    if (*(int64_t *)((int64_t)&arg_28h + iVar4) != 0) {
        do {
            uVar2 = *(undefined4 *)((int64_t)&var_18h + iVar4 + 4);
            uVar1 = *(undefined2 *)(*(int64_t *)((int64_t)&arg_30h + iVar4) + uVar5 * 2);
            *(int64_t *)((int64_t)&var_10h + iVar4) = (int64_t)&var_20h + iVar4;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2760;
            iVar3 = func_0x0001801adc80(in_RCX, uVar1, uVar2, *(undefined4 *)((int64_t)&var_18h + iVar4));
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2775;
                iVar3 = func_0x0001801ada30(in_RCX, uVar1, 0x20004);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2789;
                    iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar4), 
                                          *(int64_t *)((int64_t)&var_10h + iVar4), 
                                          *(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)(&stack0x00000048 + iVar4));
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2847;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f285f;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar4));
                        goto code_r0x0001801f2818;
                    }
                    if ((*(int32_t *)((int64_t)&var_20h + iVar4) != 0) &&
                       (*(int32_t *)((int64_t)&var_18h + iVar4) == 0x304)) {
                        uVar6 = uVar6 + 1;
                    }
                }
            }
            uVar5 = uVar5 + 1;
        } while (uVar5 < *(uint64_t *)((int64_t)&arg_28h + iVar4));
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f27ba;
    iVar3 = fcn.180244000(in_RDX);
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f27ca;
        iVar3 = fcn.180244000(in_RDX);
        if (iVar3 != 0) {
            if ((uVar6 != 0) || (*(int32_t *)((int64_t)&var_18h + iVar4) != 0x304)) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f27ee;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2806;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                          *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4));
            goto code_r0x0001801f2818;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f287b;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f289e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                  *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)((int64_t)&arg_38h + iVar4));
code_r0x0001801f2818:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801f2820;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_1801f2910
// Address: 0x1801f2910
// Size: 375 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

undefined8 fcn.1801f2910(int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f2925;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2940;
    iVar1 = func_0x0001801af910();
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f294b;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2963;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        goto code_r0x0001801f2a65;
    }
    if (*(int32_t *)((int64_t)&iStackX_20 + iVar3 + -8) < 0x304) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f299d;
    iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000058 + iVar3));
    if (iVar1 == 0) {
code_r0x0001801f2a42:
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2a47;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f29b2;
        iVar1 = fcn.180244a90(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        if (iVar1 == 0) goto code_r0x0001801f2a42;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f29c7;
        iVar1 = fcn.180244a90(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        if (iVar1 == 0) goto code_r0x0001801f2a42;
        iVar1 = *(int32_t *)((int64_t)&iStackX_20 + iVar3 + -8);
        if (*(int32_t *)((int64_t)&iStackX_20 + iVar3 + -4) <= iVar1) {
            do {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f29f1;
                iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3)
                                      , *(int64_t *)(&stack0x00000058 + iVar3));
                if (iVar2 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2a2f;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3));
                    goto code_r0x0001801f2a4c;
                }
                iVar1 = iVar1 + -1;
            } while (*(int32_t *)((int64_t)&iStackX_20 + iVar3 + -4) <= iVar1);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2a05;
        iVar1 = fcn.180244000(in_RDX);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2a11;
            iVar1 = fcn.180244000(in_RDX);
            if (iVar1 != 0) {
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2a3b;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
    }
code_r0x0001801f2a4c:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2a5f;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                  *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3));
code_r0x0001801f2a65:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2a75;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_1801f2a90
// Address: 0x1801f2a90
// Size: 135 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801f2a90(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 in_RDX;
    int32_t iVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f2aa6;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2ab4;
    iVar4 = fcn.18020bb40();
    if (iVar4 == 0) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2ae5;
    iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000058 + iVar3));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2afa;
        iVar1 = fcn.180244a90(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2b0f;
            iVar1 = fcn.180244a90(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
                *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2b29;
                iVar1 = fcn.180222010(iVar4);
                iVar6 = 0;
                if (0 < iVar1) {
                    do {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2b3b;
                        iVar5 = fcn.180222340(iVar4, iVar6);
                        if (iVar5 == 0) {
code_r0x0001801f2b8e:
                            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2b93;
                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), 
                                          *(int64_t *)((int64_t)&var_20h + iVar3));
                            goto code_r0x0001801f2b9f;
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2b51;
                        iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar3), 
                                              *(int64_t *)((int64_t)&var_20h + iVar3), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                              *(int64_t *)(&stack0x00000058 + iVar3));
                        if (iVar2 == 0) goto code_r0x0001801f2b8e;
                        iVar6 = iVar6 + 1;
                    } while (iVar6 < iVar1);
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2b63;
                iVar1 = fcn.180244000(in_RDX);
                if (iVar1 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2b77;
                    iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar3), 
                                          *(int64_t *)((int64_t)&var_20h + iVar3), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                          *(int64_t *)(&stack0x00000058 + iVar3));
                    if (iVar1 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2b83;
                        iVar1 = fcn.180244000(in_RDX);
                        if (iVar1 != 0) {
                            return 1;
                        }
                    }
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2be3;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
code_r0x0001801f2b9f:
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2bab;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                              *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2bc1;
                fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
                return 0;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2bf6;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2c0e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f2c24;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    return 0;
}

