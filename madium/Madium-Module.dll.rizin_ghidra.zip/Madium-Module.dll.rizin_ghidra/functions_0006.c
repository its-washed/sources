// Chunk 6 - 50 functions

// ============================================================
// Function: FUN_18000d380
// Address: 0x18000d380
// Size: 42 bytes
// ============================================================
void fcn.18000d380(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined *puVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_40;
    undefined auStack_38 [32];
    
    puVar5 = auStack_38;
    if (0x7ffffffffffffffe < (uint64_t)arg3) {
        func_0x0001800047c0();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    if ((uint64_t)arg3 < 8) {
        *(int64_t *)(arg1 + 0x10) = arg3;
        *(undefined8 *)(arg1 + 0x18) = 7;
        func_0x000180498030(arg1, arg2, arg3 * 2);
        *(undefined2 *)(arg3 * 2 + arg1) = 0;
    } else {
        uVar2 = arg3 | 7;
        uVar6 = 0;
        if (uVar2 < 0x7fffffffffffffff) goto code_r0x00018000d41c;
        uVar4 = 0xfffffffffffffffe;
        puVar5 = auStack_38;
        uVar2 = 0x7ffffffffffffffe;
        do {
            if (uVar4 < 0x1000) {
                *(undefined8 *)(puVar5 + -8) = 0x18000d45b;
                uVar6 = func_0x000180459890();
                break;
            }
            if (uVar4 + 0x27 <= uVar4) {
code_r0x00018000d49d:
                *(undefined8 *)(puVar5 + -8) = 0x18000d4a2;
                func_0x000180004720();
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
            *(undefined8 *)(puVar5 + -8) = 0x18000d410;
            iVar3 = func_0x000180459890(uVar4 + 0x27);
            if (iVar3 != 0) {
                uVar6 = iVar3 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar6 - 8) = iVar3;
                break;
            }
            pcVar1 = (code *)swi(0x29);
            uVar2 = (*pcVar1)(5);
            puVar5 = puVar5 + 8;
code_r0x00018000d41c:
            if (uVar2 < 10) {
                uVar2 = 10;
            }
            if (0x7fffffffffffffff < uVar2 + 1) goto code_r0x00018000d49d;
            uVar4 = (uVar2 + 1) * 2;
        } while (uVar4 != 0);
        *(int64_t *)(arg1 + 0x10) = arg3;
        *(uint64_t *)arg1 = uVar6;
        *(uint64_t *)(arg1 + 0x18) = uVar2;
        *(undefined8 *)(puVar5 + -8) = 0x18000d47a;
        func_0x000180498030(uVar6, arg2, arg3 * 2);
        *(undefined2 *)(arg3 * 2 + uVar6) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18000d3aa
// Address: 0x18000d3aa
// Size: 49 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18000d380(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined *puVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_40;
    undefined auStack_38 [32];
    
    puVar5 = auStack_38;
    if (0x7ffffffffffffffe < (uint64_t)arg3) {
        func_0x0001800047c0();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    if ((uint64_t)arg3 < 8) {
        *(int64_t *)(arg1 + 0x10) = arg3;
        *(undefined8 *)(arg1 + 0x18) = 7;
        func_0x000180498030(arg1, arg2, arg3 * 2);
        *(undefined2 *)(arg3 * 2 + arg1) = 0;
    } else {
        uVar2 = arg3 | 7;
        uVar6 = 0;
        if (uVar2 < 0x7fffffffffffffff) goto code_r0x00018000d41c;
        uVar4 = 0xfffffffffffffffe;
        puVar5 = auStack_38;
        uVar2 = 0x7ffffffffffffffe;
        do {
            if (uVar4 < 0x1000) {
                *(undefined8 *)(puVar5 + -8) = 0x18000d45b;
                uVar6 = func_0x000180459890();
                break;
            }
            if (uVar4 + 0x27 <= uVar4) {
code_r0x00018000d49d:
                *(undefined8 *)(puVar5 + -8) = 0x18000d4a2;
                func_0x000180004720();
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
            *(undefined8 *)(puVar5 + -8) = 0x18000d410;
            iVar3 = func_0x000180459890(uVar4 + 0x27);
            if (iVar3 != 0) {
                uVar6 = iVar3 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar6 - 8) = iVar3;
                break;
            }
            pcVar1 = (code *)swi(0x29);
            uVar2 = (*pcVar1)(5);
            puVar5 = puVar5 + 8;
code_r0x00018000d41c:
            if (uVar2 < 10) {
                uVar2 = 10;
            }
            if (0x7fffffffffffffff < uVar2 + 1) goto code_r0x00018000d49d;
            uVar4 = (uVar2 + 1) * 2;
        } while (uVar4 != 0);
        *(int64_t *)(arg1 + 0x10) = arg3;
        *(uint64_t *)arg1 = uVar6;
        *(uint64_t *)(arg1 + 0x18) = uVar2;
        *(undefined8 *)(puVar5 + -8) = 0x18000d47a;
        func_0x000180498030(uVar6, arg2, arg3 * 2);
        *(undefined2 *)(arg3 * 2 + uVar6) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18000d3db
// Address: 0x18000d3db
// Size: 168 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18000d380(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined *puVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_40;
    undefined auStack_38 [32];
    
    puVar5 = auStack_38;
    if (0x7ffffffffffffffe < (uint64_t)arg3) {
        func_0x0001800047c0();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    if ((uint64_t)arg3 < 8) {
        *(int64_t *)(arg1 + 0x10) = arg3;
        *(undefined8 *)(arg1 + 0x18) = 7;
        func_0x000180498030(arg1, arg2, arg3 * 2);
        *(undefined2 *)(arg3 * 2 + arg1) = 0;
    } else {
        uVar2 = arg3 | 7;
        uVar6 = 0;
        if (uVar2 < 0x7fffffffffffffff) goto code_r0x00018000d41c;
        uVar4 = 0xfffffffffffffffe;
        puVar5 = auStack_38;
        uVar2 = 0x7ffffffffffffffe;
        do {
            if (uVar4 < 0x1000) {
                *(undefined8 *)(puVar5 + -8) = 0x18000d45b;
                uVar6 = func_0x000180459890();
                break;
            }
            if (uVar4 + 0x27 <= uVar4) {
code_r0x00018000d49d:
                *(undefined8 *)(puVar5 + -8) = 0x18000d4a2;
                func_0x000180004720();
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
            *(undefined8 *)(puVar5 + -8) = 0x18000d410;
            iVar3 = func_0x000180459890(uVar4 + 0x27);
            if (iVar3 != 0) {
                uVar6 = iVar3 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar6 - 8) = iVar3;
                break;
            }
            pcVar1 = (code *)swi(0x29);
            uVar2 = (*pcVar1)(5);
            puVar5 = puVar5 + 8;
code_r0x00018000d41c:
            if (uVar2 < 10) {
                uVar2 = 10;
            }
            if (0x7fffffffffffffff < uVar2 + 1) goto code_r0x00018000d49d;
            uVar4 = (uVar2 + 1) * 2;
        } while (uVar4 != 0);
        *(int64_t *)(arg1 + 0x10) = arg3;
        *(uint64_t *)arg1 = uVar6;
        *(uint64_t *)(arg1 + 0x18) = uVar2;
        *(undefined8 *)(puVar5 + -8) = 0x18000d47a;
        func_0x000180498030(uVar6, arg2, arg3 * 2);
        *(undefined2 *)(arg3 * 2 + uVar6) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18000d483
// Address: 0x18000d483
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18000d380(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined *puVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_40;
    undefined auStack_38 [32];
    
    puVar5 = auStack_38;
    if (0x7ffffffffffffffe < (uint64_t)arg3) {
        func_0x0001800047c0();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    if ((uint64_t)arg3 < 8) {
        *(int64_t *)(arg1 + 0x10) = arg3;
        *(undefined8 *)(arg1 + 0x18) = 7;
        func_0x000180498030(arg1, arg2, arg3 * 2);
        *(undefined2 *)(arg3 * 2 + arg1) = 0;
    } else {
        uVar2 = arg3 | 7;
        uVar6 = 0;
        if (uVar2 < 0x7fffffffffffffff) goto code_r0x00018000d41c;
        uVar4 = 0xfffffffffffffffe;
        puVar5 = auStack_38;
        uVar2 = 0x7ffffffffffffffe;
        do {
            if (uVar4 < 0x1000) {
                *(undefined8 *)(puVar5 + -8) = 0x18000d45b;
                uVar6 = func_0x000180459890();
                break;
            }
            if (uVar4 + 0x27 <= uVar4) {
code_r0x00018000d49d:
                *(undefined8 *)(puVar5 + -8) = 0x18000d4a2;
                func_0x000180004720();
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
            *(undefined8 *)(puVar5 + -8) = 0x18000d410;
            iVar3 = func_0x000180459890(uVar4 + 0x27);
            if (iVar3 != 0) {
                uVar6 = iVar3 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar6 - 8) = iVar3;
                break;
            }
            pcVar1 = (code *)swi(0x29);
            uVar2 = (*pcVar1)(5);
            puVar5 = puVar5 + 8;
code_r0x00018000d41c:
            if (uVar2 < 10) {
                uVar2 = 10;
            }
            if (0x7fffffffffffffff < uVar2 + 1) goto code_r0x00018000d49d;
            uVar4 = (uVar2 + 1) * 2;
        } while (uVar4 != 0);
        *(int64_t *)(arg1 + 0x10) = arg3;
        *(uint64_t *)arg1 = uVar6;
        *(uint64_t *)(arg1 + 0x18) = uVar2;
        *(undefined8 *)(puVar5 + -8) = 0x18000d47a;
        func_0x000180498030(uVar6, arg2, arg3 * 2);
        *(undefined2 *)(arg3 * 2 + uVar6) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18000d497
// Address: 0x18000d497
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18000d380(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined *puVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_40;
    undefined auStack_38 [32];
    
    puVar5 = auStack_38;
    if (0x7ffffffffffffffe < (uint64_t)arg3) {
        func_0x0001800047c0();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    if ((uint64_t)arg3 < 8) {
        *(int64_t *)(arg1 + 0x10) = arg3;
        *(undefined8 *)(arg1 + 0x18) = 7;
        func_0x000180498030(arg1, arg2, arg3 * 2);
        *(undefined2 *)(arg3 * 2 + arg1) = 0;
    } else {
        uVar2 = arg3 | 7;
        uVar6 = 0;
        if (uVar2 < 0x7fffffffffffffff) goto code_r0x00018000d41c;
        uVar4 = 0xfffffffffffffffe;
        puVar5 = auStack_38;
        uVar2 = 0x7ffffffffffffffe;
        do {
            if (uVar4 < 0x1000) {
                *(undefined8 *)(puVar5 + -8) = 0x18000d45b;
                uVar6 = func_0x000180459890();
                break;
            }
            if (uVar4 + 0x27 <= uVar4) {
code_r0x00018000d49d:
                *(undefined8 *)(puVar5 + -8) = 0x18000d4a2;
                func_0x000180004720();
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
            *(undefined8 *)(puVar5 + -8) = 0x18000d410;
            iVar3 = func_0x000180459890(uVar4 + 0x27);
            if (iVar3 != 0) {
                uVar6 = iVar3 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar6 - 8) = iVar3;
                break;
            }
            pcVar1 = (code *)swi(0x29);
            uVar2 = (*pcVar1)(5);
            puVar5 = puVar5 + 8;
code_r0x00018000d41c:
            if (uVar2 < 10) {
                uVar2 = 10;
            }
            if (0x7fffffffffffffff < uVar2 + 1) goto code_r0x00018000d49d;
            uVar4 = (uVar2 + 1) * 2;
        } while (uVar4 != 0);
        *(int64_t *)(arg1 + 0x10) = arg3;
        *(uint64_t *)arg1 = uVar6;
        *(uint64_t *)(arg1 + 0x18) = uVar2;
        *(undefined8 *)(puVar5 + -8) = 0x18000d47a;
        func_0x000180498030(uVar6, arg2, arg3 * 2);
        *(undefined2 *)(arg3 * 2 + uVar6) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18000d49d
// Address: 0x18000d49d
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18000d380(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined *puVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_40;
    undefined auStack_38 [32];
    
    puVar5 = auStack_38;
    if (0x7ffffffffffffffe < (uint64_t)arg3) {
        func_0x0001800047c0();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    if ((uint64_t)arg3 < 8) {
        *(int64_t *)(arg1 + 0x10) = arg3;
        *(undefined8 *)(arg1 + 0x18) = 7;
        func_0x000180498030(arg1, arg2, arg3 * 2);
        *(undefined2 *)(arg3 * 2 + arg1) = 0;
    } else {
        uVar2 = arg3 | 7;
        uVar6 = 0;
        if (uVar2 < 0x7fffffffffffffff) goto code_r0x00018000d41c;
        uVar4 = 0xfffffffffffffffe;
        puVar5 = auStack_38;
        uVar2 = 0x7ffffffffffffffe;
        do {
            if (uVar4 < 0x1000) {
                *(undefined8 *)(puVar5 + -8) = 0x18000d45b;
                uVar6 = func_0x000180459890();
                break;
            }
            if (uVar4 + 0x27 <= uVar4) {
code_r0x00018000d49d:
                *(undefined8 *)(puVar5 + -8) = 0x18000d4a2;
                func_0x000180004720();
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
            *(undefined8 *)(puVar5 + -8) = 0x18000d410;
            iVar3 = func_0x000180459890(uVar4 + 0x27);
            if (iVar3 != 0) {
                uVar6 = iVar3 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar6 - 8) = iVar3;
                break;
            }
            pcVar1 = (code *)swi(0x29);
            uVar2 = (*pcVar1)(5);
            puVar5 = puVar5 + 8;
code_r0x00018000d41c:
            if (uVar2 < 10) {
                uVar2 = 10;
            }
            if (0x7fffffffffffffff < uVar2 + 1) goto code_r0x00018000d49d;
            uVar4 = (uVar2 + 1) * 2;
        } while (uVar4 != 0);
        *(int64_t *)(arg1 + 0x10) = arg3;
        *(uint64_t *)arg1 = uVar6;
        *(uint64_t *)(arg1 + 0x18) = uVar2;
        *(undefined8 *)(puVar5 + -8) = 0x18000d47a;
        func_0x000180498030(uVar6, arg2, arg3 * 2);
        *(undefined2 *)(arg3 * 2 + uVar6) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18000d4b0
// Address: 0x18000d4b0
// Size: 31 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18000d4b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg1 + 0x10);
    if (*(uint64_t *)(arg1 + 0x18) - iVar1 < (uint64_t)arg3) {
        iVar1 = func_0x00018000e1f0(arg1, arg3, (undefined)var_8h, arg2, arg3);
        return iVar1;
    }
    *(int64_t *)(arg1 + 0x10) = iVar1 + arg3;
    iVar2 = arg1;
    if (7 < *(uint64_t *)(arg1 + 0x18)) {
        iVar2 = *(int64_t *)arg1;
    }
    func_0x000180498030(iVar2 + iVar1 * 2, arg2, arg3 * 2);
    *(undefined2 *)(iVar2 + (iVar1 + arg3) * 2) = 0;
    return arg1;
}

// ============================================================
// Function: FUN_18000d4cf
// Address: 0x18000d4cf
// Size: 70 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18000d4b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg1 + 0x10);
    if (*(uint64_t *)(arg1 + 0x18) - iVar1 < (uint64_t)arg3) {
        iVar1 = func_0x00018000e1f0(arg1, arg3, (undefined)var_8h, arg2, arg3);
        return iVar1;
    }
    *(int64_t *)(arg1 + 0x10) = iVar1 + arg3;
    iVar2 = arg1;
    if (7 < *(uint64_t *)(arg1 + 0x18)) {
        iVar2 = *(int64_t *)arg1;
    }
    func_0x000180498030(iVar2 + iVar1 * 2, arg2, arg3 * 2);
    *(undefined2 *)(iVar2 + (iVar1 + arg3) * 2) = 0;
    return arg1;
}

// ============================================================
// Function: FUN_18000d515
// Address: 0x18000d515
// Size: 31 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18000d4b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg1 + 0x10);
    if (*(uint64_t *)(arg1 + 0x18) - iVar1 < (uint64_t)arg3) {
        iVar1 = func_0x00018000e1f0(arg1, arg3, (undefined)var_8h, arg2, arg3);
        return iVar1;
    }
    *(int64_t *)(arg1 + 0x10) = iVar1 + arg3;
    iVar2 = arg1;
    if (7 < *(uint64_t *)(arg1 + 0x18)) {
        iVar2 = *(int64_t *)arg1;
    }
    func_0x000180498030(iVar2 + iVar1 * 2, arg2, arg3 * 2);
    *(undefined2 *)(iVar2 + (iVar1 + arg3) * 2) = 0;
    return arg1;
}

// ============================================================
// Function: FUN_18000d540
// Address: 0x18000d540
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18000d540(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    undefined8 *puVar4;
    int64_t var_8h;
    
    uVar3 = (arg2 - arg1) + 7U >> 3;
    if ((uint64_t)arg2 < (uint64_t)arg1) {
        uVar3 = 0;
    }
    if ((1 < uVar3) && (((uint64_t)arg3 < (uint64_t)arg1 || (arg1 + -8 + uVar3 * 8 < (uint64_t)arg3)))) {
        uVar1 = *(undefined8 *)arg3;
        puVar4 = (undefined8 *)arg1;
        for (uVar2 = uVar3 & 0x1ffffffffffffffe; uVar2 != 0; uVar2 = uVar2 - 1) {
            *puVar4 = uVar1;
            puVar4 = puVar4 + 1;
        }
        arg1 = arg1 + (uVar3 & 0xfffffffffffffffe) * 8;
    }
    for (; arg1 != arg2; arg1 = arg1 + 8) {
        *(undefined8 *)arg1 = *(undefined8 *)arg3;
    }
    return;
}

// ============================================================
// Function: FUN_18000d579
// Address: 0x18000d579
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18000d540(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    undefined8 *puVar4;
    int64_t var_8h;
    
    uVar3 = (arg2 - arg1) + 7U >> 3;
    if ((uint64_t)arg2 < (uint64_t)arg1) {
        uVar3 = 0;
    }
    if ((1 < uVar3) && (((uint64_t)arg3 < (uint64_t)arg1 || (arg1 + -8 + uVar3 * 8 < (uint64_t)arg3)))) {
        uVar1 = *(undefined8 *)arg3;
        puVar4 = (undefined8 *)arg1;
        for (uVar2 = uVar3 & 0x1ffffffffffffffe; uVar2 != 0; uVar2 = uVar2 - 1) {
            *puVar4 = uVar1;
            puVar4 = puVar4 + 1;
        }
        arg1 = arg1 + (uVar3 & 0xfffffffffffffffe) * 8;
    }
    for (; arg1 != arg2; arg1 = arg1 + 8) {
        *(undefined8 *)arg1 = *(undefined8 *)arg3;
    }
    return;
}

// ============================================================
// Function: FUN_18000d59d
// Address: 0x18000d59d
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18000d540(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    undefined8 *puVar4;
    int64_t var_8h;
    
    uVar3 = (arg2 - arg1) + 7U >> 3;
    if ((uint64_t)arg2 < (uint64_t)arg1) {
        uVar3 = 0;
    }
    if ((1 < uVar3) && (((uint64_t)arg3 < (uint64_t)arg1 || (arg1 + -8 + uVar3 * 8 < (uint64_t)arg3)))) {
        uVar1 = *(undefined8 *)arg3;
        puVar4 = (undefined8 *)arg1;
        for (uVar2 = uVar3 & 0x1ffffffffffffffe; uVar2 != 0; uVar2 = uVar2 - 1) {
            *puVar4 = uVar1;
            puVar4 = puVar4 + 1;
        }
        arg1 = arg1 + (uVar3 & 0xfffffffffffffffe) * 8;
    }
    for (; arg1 != arg2; arg1 = arg1 + 8) {
        *(undefined8 *)arg1 = *(undefined8 *)arg3;
    }
    return;
}

// ============================================================
// Function: FUN_18000d5d0
// Address: 0x18000d5d0
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18000d5d0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (arg1 != arg2) {
        do {
            piVar4 = *(int64_t **)(arg1 + 8);
            if (piVar4 != (int64_t *)0x0) {
                LOCK();
                piVar1 = piVar4 + 1;
                iVar3 = *(int32_t *)piVar1;
                *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)*piVar4)(piVar4);
                    LOCK();
                    piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                    iVar3 = *piVar2;
                    *piVar2 = *piVar2 + -1;
                    UNLOCK();
                    if (iVar3 == 1) {
                        (**(code **)(*piVar4 + 8))(piVar4);
                    }
                }
            }
            arg1 = arg1 + 0x10;
        } while (arg1 != arg2);
    }
    return;
}

// ============================================================
// Function: FUN_18000d5e2
// Address: 0x18000d5e2
// Size: 94 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18000d5d0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (arg1 != arg2) {
        do {
            piVar4 = *(int64_t **)(arg1 + 8);
            if (piVar4 != (int64_t *)0x0) {
                LOCK();
                piVar1 = piVar4 + 1;
                iVar3 = *(int32_t *)piVar1;
                *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)*piVar4)(piVar4);
                    LOCK();
                    piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                    iVar3 = *piVar2;
                    *piVar2 = *piVar2 + -1;
                    UNLOCK();
                    if (iVar3 == 1) {
                        (**(code **)(*piVar4 + 8))(piVar4);
                    }
                }
            }
            arg1 = arg1 + 0x10;
        } while (arg1 != arg2);
    }
    return;
}

// ============================================================
// Function: FUN_18000d640
// Address: 0x18000d640
// Size: 1 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18000d5d0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (arg1 != arg2) {
        do {
            piVar4 = *(int64_t **)(arg1 + 8);
            if (piVar4 != (int64_t *)0x0) {
                LOCK();
                piVar1 = piVar4 + 1;
                iVar3 = *(int32_t *)piVar1;
                *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)*piVar4)(piVar4);
                    LOCK();
                    piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                    iVar3 = *piVar2;
                    *piVar2 = *piVar2 + -1;
                    UNLOCK();
                    if (iVar3 == 1) {
                        (**(code **)(*piVar4 + 8))(piVar4);
                    }
                }
            }
            arg1 = arg1 + 0x10;
        } while (arg1 != arg2);
    }
    return;
}

// ============================================================
// Function: FUN_18000d650
// Address: 0x18000d650
// Size: 49 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18000d650(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined *puVar9;
    uint64_t unaff_RDI;
    undefined2 in_R9W;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7ffffffffffffffe;
    if (0x7ffffffffffffffeU - iVar3 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 7;
    if ((uVar7 < 0x7fffffffffffffff) && (uVar4 <= 0x7ffffffffffffffe - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        if (0x7fffffffffffffff < uVar8 + 1) goto code_r0x00018000d7ce;
        uVar7 = (uVar8 + 1) * 2;
        if (uVar7 != 0) goto code_r0x00018000d6ea;
        unaff_RDI = 0;
code_r0x00018000d723:
        iVar6 = iVar3 * 2;
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        if (uVar4 < 8) {
            func_0x000180498030(unaff_RDI, arg1, iVar6);
            *(undefined2 *)(iVar6 + unaff_RDI) = in_R9W;
            *(undefined2 *)(iVar6 + 2 + unaff_RDI) = 0;
            goto code_r0x00018000d7a5;
        }
        uVar8 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RDI, uVar8, iVar6);
        *(undefined2 *)(iVar6 + unaff_RDI) = in_R9W;
        *(undefined2 *)(iVar6 + 2 + unaff_RDI) = 0;
        if (0xfff < uVar4 * 2 + 2) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                func_0x000180459c3c(*piVar1, uVar4 * 2 + 0x29);
                goto code_r0x00018000d7a5;
            }
            goto code_r0x00018000d77f;
        }
    } else {
        uVar7 = 0xfffffffffffffffe;
code_r0x00018000d6ea:
        if (uVar7 < 0x1000) {
            unaff_RDI = func_0x000180459890();
            goto code_r0x00018000d723;
        }
        if (uVar7 + 0x27 <= uVar7) {
code_r0x00018000d7ce:
            func_0x000180004720();
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        iVar6 = func_0x000180459890(uVar7 + 0x27);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x00018000d723;
        }
code_r0x00018000d77f:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        puVar9 = auStack_30;
    }
    *(undefined8 *)(puVar9 + -8) = 0x18000d78e;
    func_0x000180459c3c(uVar8);
code_r0x00018000d7a5:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_18000d681
// Address: 0x18000d681
// Size: 327 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18000d650(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined *puVar9;
    uint64_t unaff_RDI;
    undefined2 in_R9W;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7ffffffffffffffe;
    if (0x7ffffffffffffffeU - iVar3 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 7;
    if ((uVar7 < 0x7fffffffffffffff) && (uVar4 <= 0x7ffffffffffffffe - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        if (0x7fffffffffffffff < uVar8 + 1) goto code_r0x00018000d7ce;
        uVar7 = (uVar8 + 1) * 2;
        if (uVar7 != 0) goto code_r0x00018000d6ea;
        unaff_RDI = 0;
code_r0x00018000d723:
        iVar6 = iVar3 * 2;
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        if (uVar4 < 8) {
            func_0x000180498030(unaff_RDI, arg1, iVar6);
            *(undefined2 *)(iVar6 + unaff_RDI) = in_R9W;
            *(undefined2 *)(iVar6 + 2 + unaff_RDI) = 0;
            goto code_r0x00018000d7a5;
        }
        uVar8 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RDI, uVar8, iVar6);
        *(undefined2 *)(iVar6 + unaff_RDI) = in_R9W;
        *(undefined2 *)(iVar6 + 2 + unaff_RDI) = 0;
        if (0xfff < uVar4 * 2 + 2) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                func_0x000180459c3c(*piVar1, uVar4 * 2 + 0x29);
                goto code_r0x00018000d7a5;
            }
            goto code_r0x00018000d77f;
        }
    } else {
        uVar7 = 0xfffffffffffffffe;
code_r0x00018000d6ea:
        if (uVar7 < 0x1000) {
            unaff_RDI = func_0x000180459890();
            goto code_r0x00018000d723;
        }
        if (uVar7 + 0x27 <= uVar7) {
code_r0x00018000d7ce:
            func_0x000180004720();
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        iVar6 = func_0x000180459890(uVar7 + 0x27);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x00018000d723;
        }
code_r0x00018000d77f:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        puVar9 = auStack_30;
    }
    *(undefined8 *)(puVar9 + -8) = 0x18000d78e;
    func_0x000180459c3c(uVar8);
code_r0x00018000d7a5:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_18000d7c8
// Address: 0x18000d7c8
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18000d650(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined *puVar9;
    uint64_t unaff_RDI;
    undefined2 in_R9W;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7ffffffffffffffe;
    if (0x7ffffffffffffffeU - iVar3 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 7;
    if ((uVar7 < 0x7fffffffffffffff) && (uVar4 <= 0x7ffffffffffffffe - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        if (0x7fffffffffffffff < uVar8 + 1) goto code_r0x00018000d7ce;
        uVar7 = (uVar8 + 1) * 2;
        if (uVar7 != 0) goto code_r0x00018000d6ea;
        unaff_RDI = 0;
code_r0x00018000d723:
        iVar6 = iVar3 * 2;
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        if (uVar4 < 8) {
            func_0x000180498030(unaff_RDI, arg1, iVar6);
            *(undefined2 *)(iVar6 + unaff_RDI) = in_R9W;
            *(undefined2 *)(iVar6 + 2 + unaff_RDI) = 0;
            goto code_r0x00018000d7a5;
        }
        uVar8 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RDI, uVar8, iVar6);
        *(undefined2 *)(iVar6 + unaff_RDI) = in_R9W;
        *(undefined2 *)(iVar6 + 2 + unaff_RDI) = 0;
        if (0xfff < uVar4 * 2 + 2) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                func_0x000180459c3c(*piVar1, uVar4 * 2 + 0x29);
                goto code_r0x00018000d7a5;
            }
            goto code_r0x00018000d77f;
        }
    } else {
        uVar7 = 0xfffffffffffffffe;
code_r0x00018000d6ea:
        if (uVar7 < 0x1000) {
            unaff_RDI = func_0x000180459890();
            goto code_r0x00018000d723;
        }
        if (uVar7 + 0x27 <= uVar7) {
code_r0x00018000d7ce:
            func_0x000180004720();
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        iVar6 = func_0x000180459890(uVar7 + 0x27);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x00018000d723;
        }
code_r0x00018000d77f:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        puVar9 = auStack_30;
    }
    *(undefined8 *)(puVar9 + -8) = 0x18000d78e;
    func_0x000180459c3c(uVar8);
code_r0x00018000d7a5:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_18000d7ce
// Address: 0x18000d7ce
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18000d650(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined *puVar9;
    uint64_t unaff_RDI;
    undefined2 in_R9W;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7ffffffffffffffe;
    if (0x7ffffffffffffffeU - iVar3 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 7;
    if ((uVar7 < 0x7fffffffffffffff) && (uVar4 <= 0x7ffffffffffffffe - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        if (0x7fffffffffffffff < uVar8 + 1) goto code_r0x00018000d7ce;
        uVar7 = (uVar8 + 1) * 2;
        if (uVar7 != 0) goto code_r0x00018000d6ea;
        unaff_RDI = 0;
code_r0x00018000d723:
        iVar6 = iVar3 * 2;
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        if (uVar4 < 8) {
            func_0x000180498030(unaff_RDI, arg1, iVar6);
            *(undefined2 *)(iVar6 + unaff_RDI) = in_R9W;
            *(undefined2 *)(iVar6 + 2 + unaff_RDI) = 0;
            goto code_r0x00018000d7a5;
        }
        uVar8 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RDI, uVar8, iVar6);
        *(undefined2 *)(iVar6 + unaff_RDI) = in_R9W;
        *(undefined2 *)(iVar6 + 2 + unaff_RDI) = 0;
        if (0xfff < uVar4 * 2 + 2) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                func_0x000180459c3c(*piVar1, uVar4 * 2 + 0x29);
                goto code_r0x00018000d7a5;
            }
            goto code_r0x00018000d77f;
        }
    } else {
        uVar7 = 0xfffffffffffffffe;
code_r0x00018000d6ea:
        if (uVar7 < 0x1000) {
            unaff_RDI = func_0x000180459890();
            goto code_r0x00018000d723;
        }
        if (uVar7 + 0x27 <= uVar7) {
code_r0x00018000d7ce:
            func_0x000180004720();
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        iVar6 = func_0x000180459890(uVar7 + 0x27);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x00018000d723;
        }
code_r0x00018000d77f:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        puVar9 = auStack_30;
    }
    *(undefined8 *)(puVar9 + -8) = 0x18000d78e;
    func_0x000180459c3c(uVar8);
code_r0x00018000d7a5:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_18000d7e0
// Address: 0x18000d7e0
// Size: 386 bytes
// ============================================================
int64_t fcn.18000d7e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    uint64_t uVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined *puVar7;
    uint64_t unaff_RSI;
    uint64_t uVar8;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    
    puVar7 = auStack_58;
    uVar2 = *(uint64_t *)(arg1 + 0x18);
    if ((uint64_t)arg3 <= uVar2) {
        iVar4 = arg1;
        if (7 < uVar2) {
            iVar4 = *(int64_t *)arg1;
        }
        *(int64_t *)(arg1 + 0x10) = arg3;
        func_0x000180498030(iVar4, arg2, arg3 * 2);
        *(undefined2 *)(arg3 * 2 + iVar4) = 0;
        return arg1;
    }
    uVar6 = 0x7ffffffffffffffe;
    if (0x7ffffffffffffffe < (uint64_t)arg3) {
        func_0x0001800047c0();
        pcVar3 = (code *)swi(3);
        iVar4 = (*pcVar3)();
        return iVar4;
    }
    uVar8 = 0;
    uVar5 = arg3 | 7;
    if ((uVar5 < 0x7fffffffffffffff) && (uVar2 <= 0x7ffffffffffffffe - (uVar2 >> 1))) {
        uVar1 = (uVar2 >> 1) + uVar2;
        uVar6 = uVar5;
        if (uVar5 < uVar1) {
            uVar6 = uVar1;
        }
        if (0x7fffffffffffffff < uVar6 + 1) goto code_r0x00018000d95c;
        uVar5 = (uVar6 + 1) * 2;
        if (uVar5 != 0) goto code_r0x00018000d8a5;
code_r0x00018000d8de:
        *(uint64_t *)(arg1 + 0x18) = uVar6;
        *(int64_t *)(arg1 + 0x10) = arg3;
        func_0x000180498030(uVar8, arg2, arg3 * 2);
        *(undefined2 *)(arg3 * 2 + uVar8) = 0;
        if (uVar2 < 8) goto code_r0x00018000d94b;
        iVar4 = *(int64_t *)arg1;
        if (0xfff < uVar2 * 2 + 2) {
            if ((iVar4 - *(int64_t *)(iVar4 + -8)) - 8U < 0x20) {
                func_0x000180459c3c(*(int64_t *)(iVar4 + -8), uVar2 * 2 + 0x29);
                *(uint64_t *)arg1 = uVar8;
                return arg1;
            }
            goto code_r0x00018000d93c;
        }
    } else {
        uVar5 = 0xfffffffffffffffe;
code_r0x00018000d8a5:
        if (uVar5 < 0x1000) {
            uVar8 = func_0x000180459890();
            goto code_r0x00018000d8de;
        }
        if (uVar5 + 0x27 <= uVar5) {
code_r0x00018000d95c:
            func_0x000180004720();
            pcVar3 = (code *)swi(3);
            iVar4 = (*pcVar3)();
            return iVar4;
        }
        iVar4 = func_0x000180459890(uVar5 + 0x27);
        uVar8 = unaff_RSI;
        if (iVar4 != 0) {
            uVar8 = iVar4 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar8 - 8) = iVar4;
            goto code_r0x00018000d8de;
        }
code_r0x00018000d93c:
        pcVar3 = (code *)swi(0x29);
        iVar4 = (*pcVar3)(5);
        puVar7 = auStack_50;
    }
    *(undefined8 *)(puVar7 + -8) = 0x18000d94b;
    func_0x000180459c3c(iVar4);
code_r0x00018000d94b:
    *(uint64_t *)arg1 = uVar8;
    return arg1;
}

// ============================================================
// Function: FUN_18000d970
// Address: 0x18000d970
// Size: 35 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18000d970(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar2 = *(int64_t *)(arg1 + 0x10);
    if (*(uint64_t *)(arg1 + 0x18) - iVar2 < (uint64_t)arg3) {
        iVar2 = func_0x00018000ee80(arg1, arg3, (undefined)var_8h, arg2, arg3);
        return iVar2;
    }
    *(int64_t *)(arg1 + 0x10) = iVar2 + arg3;
    iVar1 = arg1;
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        iVar1 = *(int64_t *)arg1;
    }
    func_0x000180498030(iVar2 + iVar1, arg2, arg3);
    *(undefined *)(iVar2 + iVar1 + arg3) = 0;
    return arg1;
}

// ============================================================
// Function: FUN_18000d993
// Address: 0x18000d993
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18000d970(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar2 = *(int64_t *)(arg1 + 0x10);
    if (*(uint64_t *)(arg1 + 0x18) - iVar2 < (uint64_t)arg3) {
        iVar2 = func_0x00018000ee80(arg1, arg3, (undefined)var_8h, arg2, arg3);
        return iVar2;
    }
    *(int64_t *)(arg1 + 0x10) = iVar2 + arg3;
    iVar1 = arg1;
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        iVar1 = *(int64_t *)arg1;
    }
    func_0x000180498030(iVar2 + iVar1, arg2, arg3);
    *(undefined *)(iVar2 + iVar1 + arg3) = 0;
    return arg1;
}

// ============================================================
// Function: FUN_18000d9d4
// Address: 0x18000d9d4
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18000d970(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar2 = *(int64_t *)(arg1 + 0x10);
    if (*(uint64_t *)(arg1 + 0x18) - iVar2 < (uint64_t)arg3) {
        iVar2 = func_0x00018000ee80(arg1, arg3, (undefined)var_8h, arg2, arg3);
        return iVar2;
    }
    *(int64_t *)(arg1 + 0x10) = iVar2 + arg3;
    iVar1 = arg1;
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        iVar1 = *(int64_t *)arg1;
    }
    func_0x000180498030(iVar2 + iVar1, arg2, arg3);
    *(undefined *)(iVar2 + iVar1 + arg3) = 0;
    return arg1;
}

// ============================================================
// Function: FUN_18000da00
// Address: 0x18000da00
// Size: 271 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18000da00(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    func_0x000180455714(&var_10h, 0);
    iVar5 = *(int64_t *)0x180782400;
    var_18h = *(int64_t *)0x180782400;
    if (*(uint64_t *)0x180782748 == 0) {
        func_0x000180455714(&var_8h, 0);
        if (*(uint64_t *)0x180782748 == 0) {
            *(int32_t *)0x180780f30 = *(int32_t *)0x180780f30 + 1;
            *(uint64_t *)0x180782748 = (uint64_t)*(int32_t *)0x180780f30;
        }
        func_0x00018045578c();
    }
    uVar3 = *(uint64_t *)0x180782748;
    iVar4 = *(int64_t *)(arg1 + 8);
    iVar1 = *(uint64_t *)0x180782748 * 8;
    if (*(uint64_t *)0x180782748 < *(uint64_t *)(iVar4 + 0x18)) {
        iVar6 = *(int64_t *)(iVar1 + *(int64_t *)(iVar4 + 0x10));
        if (iVar6 != 0) goto code_r0x00018000da93;
    } else {
        iVar6 = 0;
    }
    if (*(char *)(iVar4 + 0x24) == '\0') {
code_r0x00018000dac8:
        if (iVar6 != 0) goto code_r0x00018000da93;
    } else {
        iVar4 = func_0x0001804558e0();
        if (uVar3 < *(uint64_t *)(iVar4 + 0x18)) {
            iVar6 = *(int64_t *)(iVar1 + *(int64_t *)(iVar4 + 0x10));
            goto code_r0x00018000dac8;
        }
    }
    iVar6 = iVar5;
    if (iVar5 == 0) {
        iVar5 = func_0x00018000f5f0(&var_18h, arg1);
        iVar6 = var_18h;
        if (iVar5 == -1) {
            func_0x000180005b10();
            pcVar2 = (code *)swi(3);
            iVar5 = (*pcVar2)();
            return iVar5;
        }
        iVar5 = var_18h;
        var_8h = var_18h;
        func_0x0001804558a4(var_18h);
        (**(code **)(*(int64_t *)iVar6 + 8))(iVar6);
        *(int64_t *)0x180782400 = iVar5;
    }
code_r0x00018000da93:
    func_0x00018045578c(&var_10h);
    return iVar6;
}

// ============================================================
// Function: FUN_18000dba0
// Address: 0x18000dba0
// Size: 60 bytes
// ============================================================
void fcn.18000dba0(int64_t arg1)
{
    int64_t *piVar1;
    int32_t iVar2;
    
    iVar2 = func_0x0001804557c0();
    if (iVar2 == 0) {
        func_0x00018000fc20(*(undefined8 *)arg1);
    }
    piVar1 = *(int64_t **)((int64_t)*(int32_t *)(**(int64_t **)arg1 + 4) + 0x48 + (int64_t)*(int64_t **)arg1);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x10))();
    }
    return;
}

// ============================================================
// Function: FUN_18000dbe0
// Address: 0x18000dbe0
// Size: 122 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18000dbe0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t iVar2;
    bool bVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    *(int64_t *)arg1 = arg2;
    piVar1 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg2 + 4) + 0x48 + arg2);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 8))();
    }
    if (*(int32_t *)((int64_t)*(int32_t *)(*(int64_t *)arg2 + 4) + 0x10 + arg2) == 0) {
        iVar2 = *(int64_t *)((int64_t)*(int32_t *)(*(int64_t *)arg2 + 4) + 0x50 + arg2);
        if ((iVar2 == 0) || (iVar2 == arg2)) {
            bVar3 = true;
        } else {
            func_0x00018000fad0();
            bVar3 = *(int32_t *)((int64_t)*(int32_t *)(*(int64_t *)arg2 + 4) + 0x10 + arg2) == 0;
        }
    } else {
        bVar3 = false;
    }
    *(bool *)(arg1 + 8) = bVar3;
    return arg1;
}

// ============================================================
// Function: FUN_18000dc80
// Address: 0x18000dc80
// Size: 104 bytes
// ============================================================
void fcn.18000dc80(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined *puVar4;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    if (7 < *(uint64_t *)(arg1 + 0x18)) {
        iVar1 = *(int64_t *)arg1;
        iVar3 = iVar1;
        puVar4 = auStack_28;
        if ((0xfff < *(uint64_t *)(arg1 + 0x18) * 2 + 2) &&
           (iVar3 = *(int64_t *)(iVar1 + -8), puVar4 = auStack_28, 0x1f < (iVar1 - iVar3) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18000dccd;
        func_0x000180459c3c(iVar3);
    }
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined2 *)arg1 = 0;
    *(undefined8 *)(arg1 + 0x18) = 7;
    return;
}

// ============================================================
// Function: FUN_18000dcf0
// Address: 0x18000dcf0
// Size: 102 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18000dcf0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(arg1 + 0x10);
    if (uVar1 < (uint64_t)arg2) {
        func_0x00018000f930();
        pcVar2 = (code *)swi(3);
        iVar3 = (*pcVar2)();
        return iVar3;
    }
    if (uVar1 - arg2 < (uint64_t)arg3) {
        arg3 = uVar1 - arg2;
    }
    iVar3 = arg1;
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        iVar3 = *(int64_t *)arg1;
    }
    func_0x000180498030(iVar3 + arg2, arg3 + iVar3 + arg2, ((uVar1 - arg3) - arg2) + 1);
    *(uint64_t *)(arg1 + 0x10) = uVar1 - arg3;
    return arg1;
}

// ============================================================
// Function: FUN_18000dd90
// Address: 0x18000dd90
// Size: 128 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18000dd90(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_8h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0x18))(arg2);
    if (cVar1 != '\0') {
        *(undefined8 *)(arg1 + 0x68) = 0;
        return;
    }
    *(int64_t *)(arg1 + 0x68) = arg2;
    *(undefined8 **)(arg1 + 0x18) = (undefined8 *)(arg1 + 8);
    *(undefined8 **)(arg1 + 0x20) = (undefined8 *)(arg1 + 0x10);
    *(undefined8 **)(arg1 + 0x38) = (undefined8 *)(arg1 + 0x28);
    *(undefined8 **)(arg1 + 0x40) = (undefined8 *)(arg1 + 0x30);
    *(undefined4 **)(arg1 + 0x50) = (undefined4 *)(arg1 + 0x48);
    *(undefined4 **)(arg1 + 0x58) = (undefined4 *)(arg1 + 0x4c);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x30) = 0;
    *(undefined4 *)(arg1 + 0x4c) = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x28) = 0;
    *(undefined4 *)(arg1 + 0x48) = 0;
    return;
}

// ============================================================
// Function: FUN_18000de10
// Address: 0x18000de10
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.18000de10(int64_t arg1)
{
    int32_t iVar1;
    undefined auStack_68 [32];
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_10h;
    
    var_10h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    if ((*(int64_t *)(arg1 + 0x68) == 0) || (*(char *)(arg1 + 0x71) == '\0')) {
        fcn.180459870(var_10h ^ (uint64_t)auStack_68);
        return;
    }
    iVar1 = (**(code **)(*(int64_t *)arg1 + 0x18))(arg1, 0xffffffff);
    if (iVar1 != -1) {
        var_48h = (int64_t)&var_38h;
        iVar1 = (**(code **)(**(int64_t **)(arg1 + 0x68) + 0x40))
                          (*(int64_t **)(arg1 + 0x68), arg1 + 0x74, &var_30h, &var_10h);
        if (iVar1 == 0) {
            *(undefined *)(arg1 + 0x71) = 0;
        } else if (iVar1 != 1) {
            if (iVar1 == 3) {
                *(undefined *)(arg1 + 0x71) = 0;
            }
            goto code_r0x00018000de8c;
        }
        if (var_38h - (int64_t)&var_30h != 0) {
            fcn.180460a38(&var_30h, 1, var_38h - (int64_t)&var_30h, *(undefined8 *)(arg1 + 0x80));
        }
    }
code_r0x00018000de8c:
    fcn.180459870(var_10h ^ (uint64_t)auStack_68);
    return;
}

// ============================================================
// Function: FUN_18000de45
// Address: 0x18000de45
// Size: 95 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.18000de10(int64_t arg1)
{
    int32_t iVar1;
    undefined auStack_68 [32];
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_10h;
    
    var_10h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    if ((*(int64_t *)(arg1 + 0x68) == 0) || (*(char *)(arg1 + 0x71) == '\0')) {
        fcn.180459870(var_10h ^ (uint64_t)auStack_68);
        return;
    }
    iVar1 = (**(code **)(*(int64_t *)arg1 + 0x18))(arg1, 0xffffffff);
    if (iVar1 != -1) {
        var_48h = (int64_t)&var_38h;
        iVar1 = (**(code **)(**(int64_t **)(arg1 + 0x68) + 0x40))
                          (*(int64_t **)(arg1 + 0x68), arg1 + 0x74, &var_30h, &var_10h);
        if (iVar1 == 0) {
            *(undefined *)(arg1 + 0x71) = 0;
        } else if (iVar1 != 1) {
            if (iVar1 == 3) {
                *(undefined *)(arg1 + 0x71) = 0;
            }
            goto code_r0x00018000de8c;
        }
        if (var_38h - (int64_t)&var_30h != 0) {
            fcn.180460a38(&var_30h, 1, var_38h - (int64_t)&var_30h, *(undefined8 *)(arg1 + 0x80));
        }
    }
code_r0x00018000de8c:
    fcn.180459870(var_10h ^ (uint64_t)auStack_68);
    return;
}

// ============================================================
// Function: FUN_18000dea4
// Address: 0x18000dea4
// Size: 62 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.18000de10(int64_t arg1)
{
    int32_t iVar1;
    undefined auStack_68 [32];
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_10h;
    
    var_10h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    if ((*(int64_t *)(arg1 + 0x68) == 0) || (*(char *)(arg1 + 0x71) == '\0')) {
        fcn.180459870(var_10h ^ (uint64_t)auStack_68);
        return;
    }
    iVar1 = (**(code **)(*(int64_t *)arg1 + 0x18))(arg1, 0xffffffff);
    if (iVar1 != -1) {
        var_48h = (int64_t)&var_38h;
        iVar1 = (**(code **)(**(int64_t **)(arg1 + 0x68) + 0x40))
                          (*(int64_t **)(arg1 + 0x68), arg1 + 0x74, &var_30h, &var_10h);
        if (iVar1 == 0) {
            *(undefined *)(arg1 + 0x71) = 0;
        } else if (iVar1 != 1) {
            if (iVar1 == 3) {
                *(undefined *)(arg1 + 0x71) = 0;
            }
            goto code_r0x00018000de8c;
        }
        if (var_38h - (int64_t)&var_30h != 0) {
            fcn.180460a38(&var_30h, 1, var_38h - (int64_t)&var_30h, *(undefined8 *)(arg1 + 0x80));
        }
    }
code_r0x00018000de8c:
    fcn.180459870(var_10h ^ (uint64_t)auStack_68);
    return;
}

// ============================================================
// Function: FUN_18000dee2
// Address: 0x18000dee2
// Size: 21 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.18000de10(int64_t arg1)
{
    int32_t iVar1;
    undefined auStack_68 [32];
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_10h;
    
    var_10h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    if ((*(int64_t *)(arg1 + 0x68) == 0) || (*(char *)(arg1 + 0x71) == '\0')) {
        fcn.180459870(var_10h ^ (uint64_t)auStack_68);
        return;
    }
    iVar1 = (**(code **)(*(int64_t *)arg1 + 0x18))(arg1, 0xffffffff);
    if (iVar1 != -1) {
        var_48h = (int64_t)&var_38h;
        iVar1 = (**(code **)(**(int64_t **)(arg1 + 0x68) + 0x40))
                          (*(int64_t **)(arg1 + 0x68), arg1 + 0x74, &var_30h, &var_10h);
        if (iVar1 == 0) {
            *(undefined *)(arg1 + 0x71) = 0;
        } else if (iVar1 != 1) {
            if (iVar1 == 3) {
                *(undefined *)(arg1 + 0x71) = 0;
            }
            goto code_r0x00018000de8c;
        }
        if (var_38h - (int64_t)&var_30h != 0) {
            fcn.180460a38(&var_30h, 1, var_38h - (int64_t)&var_30h, *(undefined8 *)(arg1 + 0x80));
        }
    }
code_r0x00018000de8c:
    fcn.180459870(var_10h ^ (uint64_t)auStack_68);
    return;
}

// ============================================================
// Function: FUN_18000df00
// Address: 0x18000df00
// Size: 206 bytes
// ============================================================
void fcn.18000df00(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_60h)
{
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    
    *(undefined *)(arg1 + 0x71) = 0;
    *(undefined8 **)(arg1 + 0x18) = (undefined8 *)(arg1 + 8);
    *(undefined8 **)(arg1 + 0x38) = (undefined8 *)(arg1 + 0x28);
    *(undefined8 **)(arg1 + 0x20) = (undefined8 *)(arg1 + 0x10);
    *(undefined4 **)(arg1 + 0x50) = (undefined4 *)(arg1 + 0x48);
    *(bool *)(arg1 + 0x7c) = (int32_t)arg3 == 1;
    *(undefined8 **)(arg1 + 0x40) = (undefined8 *)(arg1 + 0x30);
    *(undefined4 **)(arg1 + 0x58) = (undefined4 *)(arg1 + 0x4c);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x30) = 0;
    *(undefined4 *)(arg1 + 0x4c) = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x28) = 0;
    *(undefined4 *)(arg1 + 0x48) = 0;
    if (arg2 != 0) {
        var_8h = 0;
        var_10h = 0;
        var_20h = 0;
        fcn.180460668(arg2, &var_8h, &var_10h, &var_20h);
        *(int64_t *)(arg1 + 0x18) = var_8h;
        *(int64_t *)(arg1 + 0x20) = var_8h;
        *(int64_t *)(arg1 + 0x38) = var_10h;
        *(int64_t *)(arg1 + 0x40) = var_10h;
        *(int64_t *)(arg1 + 0x50) = var_20h;
        *(int64_t *)(arg1 + 0x58) = var_20h;
    }
    *(int64_t *)(arg1 + 0x80) = arg2;
    *(undefined8 *)(arg1 + 0x74) = *(undefined8 *)0x1807823f8;
    *(undefined8 *)(arg1 + 0x68) = 0;
    return;
}

// ============================================================
// Function: FUN_18000dfd0
// Address: 0x18000dfd0
// Size: 104 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18000dfd0(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    uint32_t uVar2;
    int64_t var_8h;
    
    fcn.18000fd90();
    *(undefined8 *)(arg1 + 0x68) = 0;
    *(undefined8 *)arg1 = 0x1804a5580;
    uVar2 = (~(uint32_t)arg2 & 1) << 2;
    uVar1 = uVar2 | 2;
    if ((arg2 & 2U) != 0) {
        uVar1 = uVar2;
    }
    uVar2 = uVar1 | 8;
    if ((arg2 & 8U) == 0) {
        uVar2 = uVar1;
    }
    uVar1 = uVar2 | 0x10;
    if ((arg2 & 4U) == 0) {
        uVar1 = uVar2;
    }
    *(uint32_t *)(arg1 + 0x70) = uVar1;
    return arg1;
}

// ============================================================
// Function: FUN_18000e040
// Address: 0x18000e040
// Size: 158 bytes
// ============================================================
int64_t fcn.18000e040(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4)
{
    int64_t var_8h;
    int64_t var_20h;
    
    if ((int32_t)arg4 != 0) {
        *(undefined8 *)arg1 = 0x1805ab1c0;
        *(undefined8 *)(arg1 + 0x18) = 0;
        *(undefined8 *)(arg1 + 0x20) = 0;
        *(undefined4 *)(arg1 + 0x28) = 0;
        *(undefined8 *)(arg1 + 0x30) = 0;
        *(undefined8 *)(arg1 + 0x38) = 0;
        *(undefined8 *)(arg1 + 0x40) = 0;
        *(undefined8 *)(arg1 + 0x48) = 0;
        *(undefined8 *)(arg1 + 0x50) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0x1804a54e0;
        *(undefined8 *)(arg1 + 0x58) = 0;
        *(undefined8 *)(arg1 + 0x60) = 0;
        *(undefined *)(arg1 + 0x68) = 0;
    }
    *(undefined8 *)(*(int32_t *)(*(int64_t *)arg1 + 4) + arg1) = 0x1804a54f0;
    *(int32_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + -4 + arg1) = *(int32_t *)(*(int64_t *)arg1 + 4) + -0x10;
    fcn.18000fe50(*(int32_t *)(*(int64_t *)arg1 + 4) + arg1, arg2);
    return arg1;
}

// ============================================================
// Function: FUN_18000e0e0
// Address: 0x18000e0e0
// Size: 169 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.18000e0e0(int64_t arg1, int64_t arg_38h)
{
    int32_t iVar1;
    int32_t *piVar2;
    uint8_t **ppuVar3;
    uint8_t *puVar4;
    uint64_t uVar5;
    int64_t var_8h;
    
    if (**(int64_t **)(arg1 + 0x38) != 0) {
        piVar2 = *(int32_t **)(arg1 + 0x50);
        iVar1 = *piVar2;
        if (1 < iVar1) {
            *piVar2 = iVar1 + -1;
            ppuVar3 = *(uint8_t ***)(arg1 + 0x38);
            *ppuVar3 = *ppuVar3 + 1;
            return (uint64_t)**ppuVar3;
        }
        if (0 < iVar1) {
            *piVar2 = iVar1 + -1;
            puVar4 = **(uint8_t ***)(arg1 + 0x38);
            **(uint8_t ***)(arg1 + 0x38) = puVar4 + 1;
            uVar5 = (uint64_t)*puVar4;
            goto code_r0x00018000e142;
        }
    }
    uVar5 = (**(code **)(*(int64_t *)arg1 + 0x38))(arg1);
code_r0x00018000e142:
    if ((int32_t)uVar5 == -1) {
        return uVar5;
    }
    if ((**(uint8_t ***)(arg1 + 0x38) != (uint8_t *)0x0) && (0 < **(int32_t **)(arg1 + 0x50))) {
        return (uint64_t)***(uint8_t ***)(arg1 + 0x38);
    }
    // WARNING: Could not recover jumptable at 0x00018000e185. Too many branches
    // WARNING: Treating indirect jump as call
    uVar5 = (**(code **)(*(int64_t *)arg1 + 0x30))(arg1);
    return uVar5;
}

// ============================================================
// Function: FUN_18000e190
// Address: 0x18000e190
// Size: 43 bytes
// ============================================================
int64_t fcn.18000e190(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x1805ab1a0;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x50);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18000e1c0
// Address: 0x18000e1c0
// Size: 43 bytes
// ============================================================
int64_t fcn.18000e1c0(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x1804a5438;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x10);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18000e1f0
// Address: 0x18000e1f0
// Size: 46 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.18000e1f0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    undefined2 *puVar3;
    int64_t iVar4;
    uint64_t uVar5;
    code *pcVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    undefined *puVar10;
    uint64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    int64_t var_28h;
    
    puVar10 = auStack_48;
    iVar4 = *(int64_t *)(arg1 + 0x10);
    uVar9 = 0x7ffffffffffffffe;
    if (0x7ffffffffffffffeU - iVar4 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar6 = (code *)swi(3);
        (*pcVar6)();
        return;
    }
    uVar5 = *(uint64_t *)(arg1 + 0x18);
    uVar8 = iVar4 + arg2 | 7;
    if ((uVar8 < 0x7fffffffffffffff) && (uVar5 <= 0x7ffffffffffffffe - (uVar5 >> 1))) {
        uVar2 = uVar5 + (uVar5 >> 1);
        uVar9 = uVar8;
        if (uVar8 < uVar2) {
            uVar9 = uVar2;
        }
        if (0x7fffffffffffffff < uVar9 + 1) goto code_r0x00018000e396;
        uVar8 = (uVar9 + 1) * 2;
        if (uVar8 != 0) goto code_r0x00018000e28c;
        unaff_RDI = 0;
code_r0x00018000e2c9:
        *(int64_t *)(arg1 + 0x10) = iVar4 + arg2;
        *(uint64_t *)(arg1 + 0x18) = uVar9;
        iVar7 = iVar4 * 2 + unaff_RDI;
        puVar3 = (undefined2 *)(unaff_RDI + (arg_28h + iVar4) * 2);
        if (uVar5 < 8) {
            func_0x000180498030(unaff_RDI, arg1);
            func_0x000180498030(iVar7, arg4, arg_28h * 2);
            *puVar3 = 0;
            goto code_r0x00018000e36b;
        }
        uVar9 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RDI, uVar9);
        func_0x000180498030(iVar7, arg4, arg_28h * 2);
        *puVar3 = 0;
        if (0xfff < uVar5 * 2 + 2) {
            piVar1 = (int64_t *)(uVar9 - 8);
            uVar9 = (uVar9 - *piVar1) - 8;
            if (uVar9 < 0x20) {
                fcn.180459c3c(*piVar1, uVar5 * 2 + 0x29);
                goto code_r0x00018000e36b;
            }
            goto code_r0x00018000e33e;
        }
    } else {
        uVar8 = 0xfffffffffffffffe;
code_r0x00018000e28c:
        if (uVar8 < 0x1000) {
            unaff_RDI = fcn.180459890();
            goto code_r0x00018000e2c9;
        }
        if (uVar8 + 0x27 <= uVar8) {
code_r0x00018000e396:
            fcn.180004720();
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
        iVar7 = fcn.180459890(uVar8 + 0x27);
        if (iVar7 != 0) {
            unaff_RDI = iVar7 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar7;
            goto code_r0x00018000e2c9;
        }
code_r0x00018000e33e:
        pcVar6 = (code *)swi(0x29);
        (*pcVar6)(5);
        puVar10 = auStack_40;
    }
    *(undefined8 *)(puVar10 + -8) = 0x18000e34d;
    fcn.180459c3c(uVar9);
code_r0x00018000e36b:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_18000e21e
// Address: 0x18000e21e
// Size: 370 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.18000e1f0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    undefined2 *puVar3;
    int64_t iVar4;
    uint64_t uVar5;
    code *pcVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    undefined *puVar10;
    uint64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    int64_t var_28h;
    
    puVar10 = auStack_48;
    iVar4 = *(int64_t *)(arg1 + 0x10);
    uVar9 = 0x7ffffffffffffffe;
    if (0x7ffffffffffffffeU - iVar4 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar6 = (code *)swi(3);
        (*pcVar6)();
        return;
    }
    uVar5 = *(uint64_t *)(arg1 + 0x18);
    uVar8 = iVar4 + arg2 | 7;
    if ((uVar8 < 0x7fffffffffffffff) && (uVar5 <= 0x7ffffffffffffffe - (uVar5 >> 1))) {
        uVar2 = uVar5 + (uVar5 >> 1);
        uVar9 = uVar8;
        if (uVar8 < uVar2) {
            uVar9 = uVar2;
        }
        if (0x7fffffffffffffff < uVar9 + 1) goto code_r0x00018000e396;
        uVar8 = (uVar9 + 1) * 2;
        if (uVar8 != 0) goto code_r0x00018000e28c;
        unaff_RDI = 0;
code_r0x00018000e2c9:
        *(int64_t *)(arg1 + 0x10) = iVar4 + arg2;
        *(uint64_t *)(arg1 + 0x18) = uVar9;
        iVar7 = iVar4 * 2 + unaff_RDI;
        puVar3 = (undefined2 *)(unaff_RDI + (arg_28h + iVar4) * 2);
        if (uVar5 < 8) {
            func_0x000180498030(unaff_RDI, arg1);
            func_0x000180498030(iVar7, arg4, arg_28h * 2);
            *puVar3 = 0;
            goto code_r0x00018000e36b;
        }
        uVar9 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RDI, uVar9);
        func_0x000180498030(iVar7, arg4, arg_28h * 2);
        *puVar3 = 0;
        if (0xfff < uVar5 * 2 + 2) {
            piVar1 = (int64_t *)(uVar9 - 8);
            uVar9 = (uVar9 - *piVar1) - 8;
            if (uVar9 < 0x20) {
                fcn.180459c3c(*piVar1, uVar5 * 2 + 0x29);
                goto code_r0x00018000e36b;
            }
            goto code_r0x00018000e33e;
        }
    } else {
        uVar8 = 0xfffffffffffffffe;
code_r0x00018000e28c:
        if (uVar8 < 0x1000) {
            unaff_RDI = fcn.180459890();
            goto code_r0x00018000e2c9;
        }
        if (uVar8 + 0x27 <= uVar8) {
code_r0x00018000e396:
            fcn.180004720();
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
        iVar7 = fcn.180459890(uVar8 + 0x27);
        if (iVar7 != 0) {
            unaff_RDI = iVar7 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar7;
            goto code_r0x00018000e2c9;
        }
code_r0x00018000e33e:
        pcVar6 = (code *)swi(0x29);
        (*pcVar6)(5);
        puVar10 = auStack_40;
    }
    *(undefined8 *)(puVar10 + -8) = 0x18000e34d;
    fcn.180459c3c(uVar9);
code_r0x00018000e36b:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_18000e390
// Address: 0x18000e390
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.18000e1f0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    undefined2 *puVar3;
    int64_t iVar4;
    uint64_t uVar5;
    code *pcVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    undefined *puVar10;
    uint64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    int64_t var_28h;
    
    puVar10 = auStack_48;
    iVar4 = *(int64_t *)(arg1 + 0x10);
    uVar9 = 0x7ffffffffffffffe;
    if (0x7ffffffffffffffeU - iVar4 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar6 = (code *)swi(3);
        (*pcVar6)();
        return;
    }
    uVar5 = *(uint64_t *)(arg1 + 0x18);
    uVar8 = iVar4 + arg2 | 7;
    if ((uVar8 < 0x7fffffffffffffff) && (uVar5 <= 0x7ffffffffffffffe - (uVar5 >> 1))) {
        uVar2 = uVar5 + (uVar5 >> 1);
        uVar9 = uVar8;
        if (uVar8 < uVar2) {
            uVar9 = uVar2;
        }
        if (0x7fffffffffffffff < uVar9 + 1) goto code_r0x00018000e396;
        uVar8 = (uVar9 + 1) * 2;
        if (uVar8 != 0) goto code_r0x00018000e28c;
        unaff_RDI = 0;
code_r0x00018000e2c9:
        *(int64_t *)(arg1 + 0x10) = iVar4 + arg2;
        *(uint64_t *)(arg1 + 0x18) = uVar9;
        iVar7 = iVar4 * 2 + unaff_RDI;
        puVar3 = (undefined2 *)(unaff_RDI + (arg_28h + iVar4) * 2);
        if (uVar5 < 8) {
            func_0x000180498030(unaff_RDI, arg1);
            func_0x000180498030(iVar7, arg4, arg_28h * 2);
            *puVar3 = 0;
            goto code_r0x00018000e36b;
        }
        uVar9 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RDI, uVar9);
        func_0x000180498030(iVar7, arg4, arg_28h * 2);
        *puVar3 = 0;
        if (0xfff < uVar5 * 2 + 2) {
            piVar1 = (int64_t *)(uVar9 - 8);
            uVar9 = (uVar9 - *piVar1) - 8;
            if (uVar9 < 0x20) {
                fcn.180459c3c(*piVar1, uVar5 * 2 + 0x29);
                goto code_r0x00018000e36b;
            }
            goto code_r0x00018000e33e;
        }
    } else {
        uVar8 = 0xfffffffffffffffe;
code_r0x00018000e28c:
        if (uVar8 < 0x1000) {
            unaff_RDI = fcn.180459890();
            goto code_r0x00018000e2c9;
        }
        if (uVar8 + 0x27 <= uVar8) {
code_r0x00018000e396:
            fcn.180004720();
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
        iVar7 = fcn.180459890(uVar8 + 0x27);
        if (iVar7 != 0) {
            unaff_RDI = iVar7 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar7;
            goto code_r0x00018000e2c9;
        }
code_r0x00018000e33e:
        pcVar6 = (code *)swi(0x29);
        (*pcVar6)(5);
        puVar10 = auStack_40;
    }
    *(undefined8 *)(puVar10 + -8) = 0x18000e34d;
    fcn.180459c3c(uVar9);
code_r0x00018000e36b:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_18000e396
// Address: 0x18000e396
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.18000e1f0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    undefined2 *puVar3;
    int64_t iVar4;
    uint64_t uVar5;
    code *pcVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    undefined *puVar10;
    uint64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    int64_t var_28h;
    
    puVar10 = auStack_48;
    iVar4 = *(int64_t *)(arg1 + 0x10);
    uVar9 = 0x7ffffffffffffffe;
    if (0x7ffffffffffffffeU - iVar4 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar6 = (code *)swi(3);
        (*pcVar6)();
        return;
    }
    uVar5 = *(uint64_t *)(arg1 + 0x18);
    uVar8 = iVar4 + arg2 | 7;
    if ((uVar8 < 0x7fffffffffffffff) && (uVar5 <= 0x7ffffffffffffffe - (uVar5 >> 1))) {
        uVar2 = uVar5 + (uVar5 >> 1);
        uVar9 = uVar8;
        if (uVar8 < uVar2) {
            uVar9 = uVar2;
        }
        if (0x7fffffffffffffff < uVar9 + 1) goto code_r0x00018000e396;
        uVar8 = (uVar9 + 1) * 2;
        if (uVar8 != 0) goto code_r0x00018000e28c;
        unaff_RDI = 0;
code_r0x00018000e2c9:
        *(int64_t *)(arg1 + 0x10) = iVar4 + arg2;
        *(uint64_t *)(arg1 + 0x18) = uVar9;
        iVar7 = iVar4 * 2 + unaff_RDI;
        puVar3 = (undefined2 *)(unaff_RDI + (arg_28h + iVar4) * 2);
        if (uVar5 < 8) {
            func_0x000180498030(unaff_RDI, arg1);
            func_0x000180498030(iVar7, arg4, arg_28h * 2);
            *puVar3 = 0;
            goto code_r0x00018000e36b;
        }
        uVar9 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RDI, uVar9);
        func_0x000180498030(iVar7, arg4, arg_28h * 2);
        *puVar3 = 0;
        if (0xfff < uVar5 * 2 + 2) {
            piVar1 = (int64_t *)(uVar9 - 8);
            uVar9 = (uVar9 - *piVar1) - 8;
            if (uVar9 < 0x20) {
                fcn.180459c3c(*piVar1, uVar5 * 2 + 0x29);
                goto code_r0x00018000e36b;
            }
            goto code_r0x00018000e33e;
        }
    } else {
        uVar8 = 0xfffffffffffffffe;
code_r0x00018000e28c:
        if (uVar8 < 0x1000) {
            unaff_RDI = fcn.180459890();
            goto code_r0x00018000e2c9;
        }
        if (uVar8 + 0x27 <= uVar8) {
code_r0x00018000e396:
            fcn.180004720();
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
        iVar7 = fcn.180459890(uVar8 + 0x27);
        if (iVar7 != 0) {
            unaff_RDI = iVar7 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar7;
            goto code_r0x00018000e2c9;
        }
code_r0x00018000e33e:
        pcVar6 = (code *)swi(0x29);
        (*pcVar6)(5);
        puVar10 = auStack_40;
    }
    *(undefined8 *)(puVar10 + -8) = 0x18000e34d;
    fcn.180459c3c(uVar9);
code_r0x00018000e36b:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_18000e3a0
// Address: 0x18000e3a0
// Size: 1866 bytes
// ============================================================
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.18000e3a0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 *puVar13;
    int32_t iVar14;
    uint32_t uVar15;
    uint64_t uVar16;
    undefined4 *puVar17;
    uint64_t uVar18;
    undefined4 *arg1_00;
    undefined4 *puVar19;
    int64_t iVar20;
    int64_t iVar21;
    undefined4 *puVar22;
    undefined4 *puVar23;
    undefined4 *arg2_00;
    int64_t iVar24;
    int64_t iVar25;
    int64_t var_10h;
    undefined auStack_b8 [32];
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    undefined4 uStack_70;
    undefined4 uStack_6c;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_b8;
    uVar16 = arg2 - arg1;
    var_80h = arg3;
joined_r0x00018000e3e6:
    if (0x400 < (int64_t)(uVar16 & 0xffffffffffffffe0)) {
        iVar25 = arg2 - arg1 >> 6;
        if (0 < arg3) {
            puVar19 = (undefined4 *)(arg2 + -0x20);
            iVar24 = (int64_t)puVar19 - arg1 >> 5;
            puVar22 = (undefined4 *)(arg1 + iVar25 * 8 * 4);
            puVar17 = (undefined4 *)arg1;
            if (0x28 < iVar24) {
                iVar25 = iVar24 + 1 >> 3;
                puVar17 = (undefined4 *)(arg1 + iVar25 * 8 * 4);
                func_0x0001800101c0(arg1, puVar17, (undefined4 *)(arg1 + iVar25 * 0x10 * 4));
                func_0x0001800101c0(puVar22 + iVar25 * -8, puVar22, puVar22 + iVar25 * 8);
                puVar19 = puVar19 + iVar25 * -8;
                func_0x0001800101c0((undefined4 *)(arg2 + (iVar25 * -0x10 + -8) * 4), puVar19);
            }
            func_0x0001800101c0(puVar17, puVar22, puVar19);
            puVar19 = puVar22;
            while (puVar17 = puVar19, (uint64_t)arg1 < puVar17) {
                puVar19 = puVar17 + -8;
                iVar14 = func_0x000180006fa0(puVar19, puVar17);
                if ((iVar14 < 0) || (iVar14 = func_0x000180006fa0(puVar17, puVar19), iVar14 < 0)) break;
            }
            do {
                puVar22 = puVar22 + 8;
                puVar19 = puVar22;
                puVar23 = puVar17;
                if ((uint64_t)arg2 <= puVar22) goto joined_r0x00018000e4f3;
                iVar14 = func_0x000180006fa0(puVar22, puVar17);
                if ((iVar14 < 0) || (iVar14 = func_0x000180006fa0(puVar17, puVar22), iVar14 < 0))
                goto joined_r0x00018000e4f3;
            } while( true );
        }
        uVar16 = arg2 - arg1 >> 5;
        if (iVar25 < 1) goto code_r0x00018000e936;
        var_80h = (int64_t)(uVar16 - 1) >> 1;
        goto code_r0x00018000e7c0;
    }
    puVar19 = (undefined4 *)arg1;
    if (arg1 != arg2) {
        while (puVar19 = puVar19 + 8, puVar19 != (undefined4 *)arg2) {
            var_78h._0_4_ = *puVar19;
            var_78h._4_4_ = puVar19[1];
            uStack_70 = puVar19[2];
            uStack_6c = puVar19[3];
            var_68h._0_4_ = puVar19[4];
            var_68h._4_4_ = puVar19[5];
            var_60h._0_4_ = puVar19[6];
            var_60h._4_4_ = puVar19[7];
            *(undefined8 *)(puVar19 + 4) = 0;
            *(undefined8 *)(puVar19 + 6) = 7;
            *(undefined2 *)puVar19 = 0;
            uVar15 = func_0x000180006fa0(&var_78h, arg1);
            puVar22 = puVar19;
            if (uVar15 < 0x80000000) {
                while( true ) {
                    puVar17 = puVar22 + -8;
                    uVar15 = func_0x000180006fa0(&var_78h, puVar17);
                    if (uVar15 < 0x80000000) break;
                    func_0x00018000b1a0(puVar22, puVar17);
                    puVar22 = puVar17;
                }
            } else {
                puVar17 = puVar19 + 8;
                puVar23 = puVar19;
                while (puVar22 = (undefined4 *)arg1, puVar23 != (undefined4 *)arg1) {
                    puVar23 = puVar23 + -8;
                    puVar17 = puVar17 + -8;
                    func_0x00018000b1a0(puVar17, puVar23);
                }
            }
            func_0x00018000b1a0(puVar22, &var_78h);
            if (7 < CONCAT44(var_60h._4_4_, (undefined4)var_60h)) {
                iVar21 = CONCAT44(var_78h._4_4_, (undefined4)var_78h);
                iVar25 = CONCAT44(var_60h._4_4_, (undefined4)var_60h) * 2;
                uVar16 = iVar25 + 2;
                iVar24 = iVar21;
                if (0xfff < uVar16) {
                    iVar24 = *(int64_t *)(iVar21 + -8);
                    if (0x1f < (iVar21 - iVar24) - 8U) {
code_r0x00018000eae3:
                        pcVar1 = (code *)swi(0x29);
                        (*pcVar1)(5);
                        pcVar1 = (code *)swi(3);
                        (*pcVar1)();
                        return;
                    }
                    uVar16 = iVar25 + 0x29;
                }
                fcn.180459c3c(iVar24, uVar16);
            }
        }
    }
code_r0x00018000ea31:
    fcn.180459870(var_58h ^ (uint64_t)auStack_b8);
    return;
code_r0x00018000e7c0:
    do {
        iVar21 = var_80h;
        iVar25 = iVar25 + -1;
        puVar19 = (undefined4 *)(arg1 + iVar25 * 8 * 4);
        var_78h._0_4_ = *puVar19;
        var_78h._4_4_ = puVar19[1];
        uStack_70 = puVar19[2];
        uStack_6c = puVar19[3];
        puVar19 = (undefined4 *)(arg1 + (iVar25 * 8 + 4) * 4);
        var_68h._0_4_ = *puVar19;
        var_68h._4_4_ = puVar19[1];
        var_60h._0_4_ = puVar19[2];
        var_60h._4_4_ = puVar19[3];
        *(undefined8 *)(arg1 + (iVar25 * 8 + 4) * 4) = 0;
        *(undefined8 *)(arg1 + (iVar25 * 8 + 6) * 4) = 7;
        *(undefined2 *)(arg1 + iVar25 * 8 * 4) = 0;
        iVar24 = iVar25;
        while (iVar24 < iVar21) {
            iVar20 = iVar24 * 2 + 2;
            uVar15 = func_0x000180006fa0((undefined4 *)(arg1 + iVar20 * 8 * 4), 
                                         (undefined4 *)(arg1 + (iVar20 * 8 + -8) * 4));
            if (0x7fffffff < uVar15) {
                iVar20 = iVar24 * 2 + 1;
            }
            func_0x00018000b1a0((undefined4 *)(arg1 + iVar24 * 8 * 4), (undefined4 *)(arg1 + iVar20 * 8 * 4));
            iVar24 = iVar20;
        }
        if ((iVar24 == var_80h) && ((uVar16 & 1) == 0)) {
            func_0x00018000b1a0((undefined4 *)(arg1 + iVar24 * 8 * 4), (undefined4 *)(arg1 + (uVar16 * 8 + -8) * 4));
            iVar24 = uVar16 - 1;
        }
        while (iVar25 < iVar24) {
            iVar21 = iVar24 + -1 >> 1;
            uVar15 = func_0x000180006fa0((undefined4 *)(arg1 + iVar21 * 8 * 4), &var_78h);
            if (uVar15 < 0x80000000) break;
            func_0x00018000b1a0((undefined4 *)(arg1 + iVar24 * 8 * 4), (undefined4 *)(arg1 + iVar21 * 8 * 4));
            iVar24 = iVar21;
        }
        func_0x00018000b1a0((undefined4 *)(arg1 + iVar24 * 8 * 4), &var_78h);
        if (7 < CONCAT44(var_60h._4_4_, (undefined4)var_60h)) {
            iVar20 = CONCAT44(var_78h._4_4_, (undefined4)var_78h);
            iVar24 = CONCAT44(var_60h._4_4_, (undefined4)var_60h) * 2;
            uVar18 = iVar24 + 2;
            iVar21 = iVar20;
            if (0xfff < uVar18) {
                iVar21 = *(int64_t *)(iVar20 + -8);
                if (0x1f < (iVar20 - iVar21) - 8U) goto code_r0x00018000eae3;
                uVar18 = iVar24 + 0x29;
            }
            fcn.180459c3c(iVar21, uVar18);
        }
    } while (0 < iVar25);
code_r0x00018000e936:
    if (1 < (int64_t)uVar16) {
        do {
            if (0x3f < (int64_t)(arg2 - arg1 & 0xffffffffffffffe0U)) {
                var_78h._0_4_ = *(undefined4 *)(arg2 + -0x20);
                var_78h._4_4_ = *(undefined4 *)(arg2 + -0x1c);
                uStack_70 = *(undefined4 *)(arg2 + -0x18);
                uStack_6c = *(undefined4 *)(arg2 + -0x14);
                puVar19 = (undefined4 *)(arg2 + -0x20);
                var_68h._0_4_ = *(undefined4 *)(arg2 + -0x10);
                var_68h._4_4_ = *(undefined4 *)(arg2 + -0xc);
                var_60h._0_4_ = *(undefined4 *)(arg2 + -8);
                var_60h._4_4_ = *(undefined4 *)(arg2 + -4);
                *(undefined8 *)(arg2 + -0x10) = 0;
                *(undefined8 *)(arg2 + -8) = 7;
                *(undefined2 *)puVar19 = 0;
                if (puVar19 != (undefined4 *)arg1) {
                    *(undefined8 *)(arg2 + -0x10) = 0;
                    *(undefined8 *)(arg2 + -8) = 7;
                    *(undefined2 *)puVar19 = 0;
                    uVar2 = *(undefined4 *)(arg1 + 4);
                    uVar3 = *(undefined4 *)(arg1 + 8);
                    uVar4 = *(undefined4 *)(arg1 + 0xc);
                    *puVar19 = *(undefined4 *)arg1;
                    *(undefined4 *)(arg2 + -0x1c) = uVar2;
                    *(undefined4 *)(arg2 + -0x18) = uVar3;
                    *(undefined4 *)(arg2 + -0x14) = uVar4;
                    uVar2 = *(undefined4 *)(arg1 + 0x14);
                    uVar3 = *(undefined4 *)(arg1 + 0x18);
                    uVar4 = *(undefined4 *)(arg1 + 0x1c);
                    *(undefined4 *)(arg2 + -0x10) = *(undefined4 *)(arg1 + 0x10);
                    *(undefined4 *)(arg2 + -0xc) = uVar2;
                    *(undefined4 *)(arg2 + -8) = uVar3;
                    *(undefined4 *)(arg2 + -4) = uVar4;
                    *(undefined8 *)(arg1 + 0x10) = 0;
                    *(undefined8 *)(arg1 + 0x18) = 7;
                    *(undefined2 *)arg1 = 0;
                }
                func_0x0001800100a0(arg1, 0, (int64_t)puVar19 - arg1 >> 5, &var_78h);
                if (7 < CONCAT44(var_60h._4_4_, (undefined4)var_60h)) {
                    iVar24 = CONCAT44(var_78h._4_4_, (undefined4)var_78h);
                    iVar25 = iVar24;
                    if ((0xfff < CONCAT44(var_60h._4_4_, (undefined4)var_60h) * 2 + 2) &&
                       (iVar25 = *(int64_t *)(iVar24 + -8), 0x1f < (iVar24 - iVar25) - 8U)) goto code_r0x00018000eae3;
                    fcn.180459c3c(iVar25);
                }
            }
            arg2 = arg2 + -0x20;
        } while (0x3f < (int64_t)(arg2 - arg1 & 0xffffffffffffffe0U));
    }
    goto code_r0x00018000ea31;
joined_r0x00018000e4f3:
    arg1_00 = puVar19;
    if (puVar22 < (uint64_t)arg2) {
        iVar14 = func_0x000180006fa0(puVar23, puVar22);
        if (-1 < iVar14) {
            iVar14 = func_0x000180006fa0(puVar22, puVar23);
            if (iVar14 < 0) goto joined_r0x00018000e546;
            if (arg1_00 != puVar22) {
                uVar2 = puVar22[1];
                uVar3 = puVar22[2];
                uVar4 = puVar22[3];
                uVar5 = *arg1_00;
                uVar6 = arg1_00[1];
                uVar7 = arg1_00[2];
                uVar8 = arg1_00[3];
                uVar9 = arg1_00[4];
                uVar10 = arg1_00[5];
                uVar11 = arg1_00[6];
                uVar12 = arg1_00[7];
                *arg1_00 = *puVar22;
                arg1_00[1] = uVar2;
                arg1_00[2] = uVar3;
                arg1_00[3] = uVar4;
                uVar2 = puVar22[5];
                uVar3 = puVar22[6];
                uVar4 = puVar22[7];
                arg1_00[4] = puVar22[4];
                arg1_00[5] = uVar2;
                arg1_00[6] = uVar3;
                arg1_00[7] = uVar4;
                *puVar22 = uVar5;
                puVar22[1] = uVar6;
                puVar22[2] = uVar7;
                puVar22[3] = uVar8;
                puVar22[4] = uVar9;
                puVar22[5] = uVar10;
                puVar22[6] = uVar11;
                puVar22[7] = uVar12;
            }
            arg1_00 = arg1_00 + 8;
        }
        puVar22 = puVar22 + 8;
        puVar19 = arg1_00;
        goto joined_r0x00018000e4f3;
    }
joined_r0x00018000e546:
    while (arg2_00 = puVar23, puVar13 = puVar17, puVar23 = arg2_00, (uint64_t)arg1 < puVar13) {
        puVar17 = puVar13 + -8;
        iVar14 = func_0x000180006fa0(puVar17, arg2_00);
        if (-1 < iVar14) {
            iVar14 = func_0x000180006fa0(arg2_00, puVar17);
            if (iVar14 < 0) break;
            puVar23 = arg2_00 + -8;
            if (puVar23 != puVar17) {
                uVar2 = puVar13[-7];
                uVar3 = puVar13[-6];
                uVar4 = puVar13[-5];
                uVar5 = *puVar23;
                uVar6 = arg2_00[-7];
                uVar7 = arg2_00[-6];
                uVar8 = arg2_00[-5];
                uVar9 = arg2_00[-4];
                uVar10 = arg2_00[-3];
                uVar11 = arg2_00[-2];
                uVar12 = arg2_00[-1];
                *puVar23 = *puVar17;
                arg2_00[-7] = uVar2;
                arg2_00[-6] = uVar3;
                arg2_00[-5] = uVar4;
                uVar2 = puVar13[-3];
                uVar3 = puVar13[-2];
                uVar4 = puVar13[-1];
                arg2_00[-4] = puVar13[-4];
                arg2_00[-3] = uVar2;
                arg2_00[-2] = uVar3;
                arg2_00[-1] = uVar4;
                *puVar17 = uVar5;
                puVar13[-7] = uVar6;
                puVar13[-6] = uVar7;
                puVar13[-5] = uVar8;
                puVar13[-4] = uVar9;
                puVar13[-3] = uVar10;
                puVar13[-2] = uVar11;
                puVar13[-1] = uVar12;
            }
        }
    }
    if (puVar13 != (undefined4 *)arg1) {
        puVar17 = puVar13 + -8;
        if (puVar22 == (undefined4 *)arg2) {
            puVar23 = arg2_00 + -8;
            if (puVar17 != puVar23) {
                uVar2 = arg2_00[-7];
                uVar3 = arg2_00[-6];
                uVar4 = arg2_00[-5];
                uVar5 = *puVar17;
                uVar6 = puVar13[-7];
                uVar7 = puVar13[-6];
                uVar8 = puVar13[-5];
                uVar9 = puVar13[-4];
                uVar10 = puVar13[-3];
                uVar11 = puVar13[-2];
                uVar12 = puVar13[-1];
                *puVar17 = *puVar23;
                puVar13[-7] = uVar2;
                puVar13[-6] = uVar3;
                puVar13[-5] = uVar4;
                uVar2 = arg2_00[-3];
                uVar3 = arg2_00[-2];
                uVar4 = arg2_00[-1];
                puVar13[-4] = arg2_00[-4];
                puVar13[-3] = uVar2;
                puVar13[-2] = uVar3;
                puVar13[-1] = uVar4;
                *puVar23 = uVar5;
                arg2_00[-7] = uVar6;
                arg2_00[-6] = uVar7;
                arg2_00[-5] = uVar8;
                arg2_00[-4] = uVar9;
                arg2_00[-3] = uVar10;
                arg2_00[-2] = uVar11;
                arg2_00[-1] = uVar12;
            }
            puVar19 = arg1_00 + -8;
            if (puVar23 != puVar19) {
                uVar2 = arg1_00[-7];
                uVar3 = arg1_00[-6];
                uVar4 = arg1_00[-5];
                uVar5 = *puVar23;
                uVar6 = arg2_00[-7];
                uVar7 = arg2_00[-6];
                uVar8 = arg2_00[-5];
                uVar9 = arg2_00[-4];
                uVar10 = arg2_00[-3];
                uVar11 = arg2_00[-2];
                uVar12 = arg2_00[-1];
                *puVar23 = *puVar19;
                arg2_00[-7] = uVar2;
                arg2_00[-6] = uVar3;
                arg2_00[-5] = uVar4;
                uVar2 = arg1_00[-3];
                uVar3 = arg1_00[-2];
                uVar4 = arg1_00[-1];
                arg2_00[-4] = arg1_00[-4];
                arg2_00[-3] = uVar2;
                arg2_00[-2] = uVar3;
                arg2_00[-1] = uVar4;
                *puVar19 = uVar5;
                arg1_00[-7] = uVar6;
                arg1_00[-6] = uVar7;
                arg1_00[-5] = uVar8;
                arg1_00[-4] = uVar9;
                arg1_00[-3] = uVar10;
                arg1_00[-2] = uVar11;
                arg1_00[-1] = uVar12;
            }
        } else {
            if (puVar22 != puVar17) {
                uVar2 = puVar13[-7];
                uVar3 = puVar13[-6];
                uVar4 = puVar13[-5];
                uVar5 = *puVar22;
                uVar6 = puVar22[1];
                uVar7 = puVar22[2];
                uVar8 = puVar22[3];
                uVar9 = puVar22[4];
                uVar10 = puVar22[5];
                uVar11 = puVar22[6];
                uVar12 = puVar22[7];
                *puVar22 = *puVar17;
                puVar22[1] = uVar2;
                puVar22[2] = uVar3;
                puVar22[3] = uVar4;
                uVar2 = puVar13[-3];
                uVar3 = puVar13[-2];
                uVar4 = puVar13[-1];
                puVar22[4] = puVar13[-4];
                puVar22[5] = uVar2;
                puVar22[6] = uVar3;
                puVar22[7] = uVar4;
                *puVar17 = uVar5;
                puVar13[-7] = uVar6;
                puVar13[-6] = uVar7;
                puVar13[-5] = uVar8;
                puVar13[-4] = uVar9;
                puVar13[-3] = uVar10;
                puVar13[-2] = uVar11;
                puVar13[-1] = uVar12;
            }
            puVar22 = puVar22 + 8;
            puVar19 = arg1_00;
        }
        goto joined_r0x00018000e4f3;
    }
    if (puVar22 != (undefined4 *)arg2) {
        if ((arg1_00 != puVar22) && (arg2_00 != arg1_00)) {
            uVar2 = arg1_00[1];
            uVar3 = arg1_00[2];
            uVar4 = arg1_00[3];
            uVar5 = *arg2_00;
            uVar6 = arg2_00[1];
            uVar7 = arg2_00[2];
            uVar8 = arg2_00[3];
            uVar9 = arg2_00[4];
            uVar10 = arg2_00[5];
            uVar11 = arg2_00[6];
            uVar12 = arg2_00[7];
            *arg2_00 = *arg1_00;
            arg2_00[1] = uVar2;
            arg2_00[2] = uVar3;
            arg2_00[3] = uVar4;
            uVar2 = arg1_00[5];
            uVar3 = arg1_00[6];
            uVar4 = arg1_00[7];
            arg2_00[4] = arg1_00[4];
            arg2_00[5] = uVar2;
            arg2_00[6] = uVar3;
            arg2_00[7] = uVar4;
            *arg1_00 = uVar5;
            arg1_00[1] = uVar6;
            arg1_00[2] = uVar7;
            arg1_00[3] = uVar8;
            arg1_00[4] = uVar9;
            arg1_00[5] = uVar10;
            arg1_00[6] = uVar11;
            arg1_00[7] = uVar12;
        }
        if (arg2_00 != puVar22) {
            uVar2 = puVar22[1];
            uVar3 = puVar22[2];
            uVar4 = puVar22[3];
            uVar5 = *arg2_00;
            uVar6 = arg2_00[1];
            uVar7 = arg2_00[2];
            uVar8 = arg2_00[3];
            uVar9 = arg2_00[4];
            uVar10 = arg2_00[5];
            uVar11 = arg2_00[6];
            uVar12 = arg2_00[7];
            *arg2_00 = *puVar22;
            arg2_00[1] = uVar2;
            arg2_00[2] = uVar3;
            arg2_00[3] = uVar4;
            uVar2 = puVar22[5];
            uVar3 = puVar22[6];
            uVar4 = puVar22[7];
            arg2_00[4] = puVar22[4];
            arg2_00[5] = uVar2;
            arg2_00[6] = uVar3;
            arg2_00[7] = uVar4;
            *puVar22 = uVar5;
            puVar22[1] = uVar6;
            puVar22[2] = uVar7;
            puVar22[3] = uVar8;
            puVar22[4] = uVar9;
            puVar22[5] = uVar10;
            puVar22[6] = uVar11;
            puVar22[7] = uVar12;
        }
        puVar22 = puVar22 + 8;
        puVar19 = arg1_00 + 8;
        puVar17 = puVar13;
        puVar23 = arg2_00 + 8;
        goto joined_r0x00018000e4f3;
    }
    arg3 = (var_80h >> 2) + (var_80h >> 1);
    var_80h = arg3;
    if ((int64_t)((int64_t)arg2_00 - arg1 & 0xffffffffffffffe0U) <
        (int64_t)(arg2 - (int64_t)arg1_00 & 0xffffffffffffffe0U)) {
        fcn.18000e3a0(arg1, (int64_t)arg2_00, arg3);
        arg1 = (int64_t)arg1_00;
        arg2_00 = (undefined4 *)arg2;
    } else {
        fcn.18000e3a0((int64_t)arg1_00, arg2, arg3);
    }
    uVar16 = (int64_t)arg2_00 - arg1;
    arg2 = (int64_t)arg2_00;
    goto joined_r0x00018000e3e6;
}

// ============================================================
// Function: FUN_18000eaf0
// Address: 0x18000eaf0
// Size: 815 bytes
// ============================================================
undefined8 fcn.18000eaf0(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    code *pcVar5;
    int32_t iVar6;
    int32_t iVar7;
    undefined8 *puVar8;
    int64_t iVar9;
    undefined8 *arg1_00;
    uint64_t uVar10;
    int64_t *piVar11;
    undefined *puVar12;
    int64_t iVar13;
    undefined8 *puVar14;
    bool bVar15;
    undefined auStack_98 [8];
    undefined auStack_90 [24];
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    puVar12 = auStack_98;
    var_68h = 0;
    var_60h = 0;
    var_58h = 0;
    puVar8 = (undefined8 *)fcn.180459890(4000);
    arg1_00 = puVar8;
    for (puVar14 = (undefined8 *)var_68h; puVar14 != (undefined8 *)var_60h; puVar14 = puVar14 + 2) {
        *arg1_00 = 0;
        arg1_00[1] = 0;
        *arg1_00 = *puVar14;
        arg1_00[1] = puVar14[1];
        *puVar14 = 0;
        puVar14[1] = 0;
        arg1_00 = arg1_00 + 2;
    }
    fcn.18000d5d0((int64_t)arg1_00, (int64_t)arg1_00);
    iVar13 = var_60h;
    iVar9 = var_68h;
    if (var_68h == 0) goto code_r0x00018000ebf8;
    for (; iVar9 != iVar13; iVar9 = iVar9 + 0x10) {
        piVar11 = *(int64_t **)(iVar9 + 8);
        if (piVar11 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar11 + 1;
            iVar6 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar6 == 1) {
                (**(code **)*piVar11)(piVar11);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar11 + 0xc);
                iVar6 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar6 == 1) {
                    (**(code **)(*piVar11 + 8))(piVar11);
                }
            }
        }
    }
    uVar10 = var_58h - var_68h & 0xfffffffffffffff0;
    iVar9 = var_68h;
    if (0xfff < uVar10) {
        if (0x1f < (var_68h - *(int64_t *)(var_68h + -8)) - 8U) goto code_r0x00018000ede6;
        uVar10 = uVar10 + 0x27;
        iVar9 = *(int64_t *)(var_68h + -8);
    }
    fcn.180459c3c(iVar9, uVar10);
code_r0x00018000ebf8:
    var_58h = (int64_t)(puVar8 + 500);
    var_68h = (int64_t)puVar8;
    var_60h = (int64_t)puVar8;
    (*(code *)0x699d1e)(0);
    do {
        while( true ) {
            iVar9 = var_60h;
            iVar13 = var_68h;
            if (var_68h != var_60h) {
                do {
                    piVar11 = *(int64_t **)(iVar13 + 8);
                    if (piVar11 != (int64_t *)0x0) {
                        LOCK();
                        piVar1 = piVar11 + 1;
                        iVar6 = *(int32_t *)piVar1;
                        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                        UNLOCK();
                        if (iVar6 == 1) {
                            (**(code **)*piVar11)(piVar11);
                            LOCK();
                            piVar2 = (int32_t *)((int64_t)piVar11 + 0xc);
                            iVar6 = *piVar2;
                            *piVar2 = *piVar2 + -1;
                            UNLOCK();
                            if (iVar6 == 1) {
                                (**(code **)(*piVar11 + 8))(piVar11);
                            }
                        }
                    }
                    iVar13 = iVar13 + 0x10;
                } while (iVar13 != iVar9);
                var_60h = var_68h;
            }
            (**(code **)0x180782648)(&var_68h);
            iVar9 = var_60h;
            piVar11 = (int64_t *)var_68h;
            if (var_68h != var_60h) break;
code_r0x00018000ecca:
            (*(code *)0x699d32)(500);
        }
        do {
            iVar13 = *piVar11;
            if (((iVar13 != 0) && (*(char *)(iVar13 + 0x108) != '\0')) &&
               (iVar6 = func_0x000180498f10((char *)(iVar13 + 0x108), 0x1805aaea8), iVar6 == 0)) {
                if (iVar13 == *(int64_t *)0x180781ee0) goto code_r0x00018000ecca;
                LOCK();
                UNLOCK();
                iVar9 = *(int64_t *)(iVar13 + 0x1b0);
                *(int64_t *)0x180781ee0 = iVar13;
                if (iVar9 == 0) goto code_r0x00018000ed9c;
                uVar3 = *(undefined8 *)arg1;
                piVar11 = *(int64_t **)(iVar9 + 0x10);
                if (piVar11 == (int64_t *)0x0) {
                    _var_78h = ZEXT816(0);
                    piVar11 = (int64_t *)0x0;
                    goto code_r0x00018000ed42;
                }
                uVar4 = *(undefined8 *)(iVar9 + 8);
                LOCK();
                *(int32_t *)((int64_t)piVar11 + 0xc) = *(int32_t *)((int64_t)piVar11 + 0xc) + 1;
                UNLOCK();
                _var_78h = ZEXT816(0);
                iVar6 = *(int32_t *)(piVar11 + 1);
                goto joined_r0x00018000ed16;
            }
            piVar11 = piVar11 + 2;
        } while (piVar11 != (int64_t *)iVar9);
        (*(code *)0x699d32)(500);
    } while( true );
    while( true ) {
        LOCK();
        iVar7 = *(int32_t *)(piVar11 + 1);
        bVar15 = iVar6 == iVar7;
        if (bVar15) {
            *(int32_t *)(piVar11 + 1) = iVar6 + 1;
            iVar7 = iVar6;
        }
        UNLOCK();
        iVar6 = iVar7;
        if (bVar15) break;
joined_r0x00018000ed16:
        if (iVar6 == 0) goto code_r0x00018000ed42;
    }
    var_70h = (int64_t)piVar11;
    var_78h = uVar4;
code_r0x00018000ed42:
    func_0x000180008bb0(uVar3, &var_78h);
    iVar9 = var_70h;
    if (var_70h != 0) {
        LOCK();
        piVar2 = (int32_t *)(var_70h + 8);
        iVar6 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar6 == 1) {
            (***(code ***)var_70h)(var_70h);
            LOCK();
            piVar2 = (int32_t *)(iVar9 + 0xc);
            iVar6 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar6 == 1) {
                (**(code **)(*(int64_t *)iVar9 + 8))(iVar9);
            }
        }
    }
    if (piVar11 != (int64_t *)0x0) {
        LOCK();
        piVar2 = (int32_t *)((int64_t)piVar11 + 0xc);
        iVar6 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar6 == 1) {
            (**(code **)(*piVar11 + 8))(piVar11);
        }
    }
code_r0x00018000ed9c:
    LOCK();
    *(undefined *)0x180781ed8 = 0;
    UNLOCK();
    if (var_68h == 0) goto code_r0x00018000edf5;
    fcn.18000d5d0(var_68h, var_60h);
    iVar9 = var_68h;
    puVar12 = auStack_98;
    if ((0xfff < (var_58h - var_68h & 0xfffffffffffffff0U)) &&
       (iVar9 = *(int64_t *)(var_68h + -8), puVar12 = auStack_98, 0x1f < (var_68h - iVar9) - 8U)) {
code_r0x00018000ede6:
        pcVar5 = (code *)swi(0x29);
        iVar9 = (*pcVar5)(5);
        puVar12 = auStack_90;
    }
    *(undefined8 *)(puVar12 + -8) = 0x18000edf5;
    fcn.180459c3c(iVar9);
code_r0x00018000edf5:
    *(undefined8 *)(puVar12 + -8) = 0x18000edfa;
    func_0x00018045476c();
    if (arg1 != 0) {
        *(undefined8 *)(puVar12 + -8) = 0x18000ee0c;
        fcn.180459c3c(arg1, 8);
    }
    return 0;
}

// ============================================================
// Function: FUN_18000ee20
// Address: 0x18000ee20
// Size: 85 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18000ee20(int64_t arg1, int64_t arg2, int64_t arg3)
{
    char cVar1;
    int64_t *piVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar1 = *(char *)(arg3 + 0x19);
    while (cVar1 == '\0') {
        fcn.18000ee20(arg1, arg2, *(int64_t *)(arg3 + 0x10));
        piVar2 = *(int64_t **)arg3;
        fcn.180459c3c(arg3, 0x30);
        arg3 = (int64_t)piVar2;
        cVar1 = *(char *)((int64_t)piVar2 + 0x19);
    }
    return;
}

// ============================================================
// Function: FUN_18000ee80
// Address: 0x18000ee80
// Size: 46 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.18000ee80(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    uint64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    undefined auStack_40 [24];
    int64_t var_28h;
    
    piVar9 = &var_48h;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffffU - iVar3 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar4 <= 0x7fffffffffffffff - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RDI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    fcn.180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x00018000ef23;
            }
            unaff_RDI = fcn.180459890(uVar2);
        }
code_r0x00018000ef46:
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        iVar6 = iVar3 + unaff_RDI;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        if (uVar4 < 0x10) {
            func_0x000180498030(unaff_RDI, arg1, iVar3);
            func_0x000180498030(iVar6, arg4, arg_28h);
            *(undefined *)(iVar6 + arg_28h) = 0;
            goto code_r0x00018000efd6;
        }
        uVar8 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RDI, uVar8, iVar3);
        func_0x000180498030(iVar6, arg4, arg_28h);
        *(undefined *)(iVar6 + arg_28h) = 0;
        if (0xfff < uVar4 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                fcn.180459c3c(*piVar1, uVar4 + 0x28);
                goto code_r0x00018000efd6;
            }
            goto code_r0x00018000efaa;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x00018000ef23:
        iVar6 = fcn.180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x00018000ef46;
        }
code_r0x00018000efaa:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        piVar9 = (int64_t *)auStack_40;
    }
    *(undefined8 *)((int64_t)piVar9 + -8) = 0x18000efb9;
    fcn.180459c3c(uVar8);
code_r0x00018000efd6:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_18000eeae
// Address: 0x18000eeae
// Size: 333 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.18000ee80(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    uint64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    undefined auStack_40 [24];
    int64_t var_28h;
    
    piVar9 = &var_48h;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffffU - iVar3 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar4 <= 0x7fffffffffffffff - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RDI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    fcn.180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x00018000ef23;
            }
            unaff_RDI = fcn.180459890(uVar2);
        }
code_r0x00018000ef46:
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        iVar6 = iVar3 + unaff_RDI;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        if (uVar4 < 0x10) {
            func_0x000180498030(unaff_RDI, arg1, iVar3);
            func_0x000180498030(iVar6, arg4, arg_28h);
            *(undefined *)(iVar6 + arg_28h) = 0;
            goto code_r0x00018000efd6;
        }
        uVar8 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RDI, uVar8, iVar3);
        func_0x000180498030(iVar6, arg4, arg_28h);
        *(undefined *)(iVar6 + arg_28h) = 0;
        if (0xfff < uVar4 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                fcn.180459c3c(*piVar1, uVar4 + 0x28);
                goto code_r0x00018000efd6;
            }
            goto code_r0x00018000efaa;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x00018000ef23:
        iVar6 = fcn.180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x00018000ef46;
        }
code_r0x00018000efaa:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        piVar9 = (int64_t *)auStack_40;
    }
    *(undefined8 *)((int64_t)piVar9 + -8) = 0x18000efb9;
    fcn.180459c3c(uVar8);
code_r0x00018000efd6:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_18000effb
// Address: 0x18000effb
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.18000ee80(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    uint64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    undefined auStack_40 [24];
    int64_t var_28h;
    
    piVar9 = &var_48h;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffffU - iVar3 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar4 <= 0x7fffffffffffffff - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RDI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    fcn.180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x00018000ef23;
            }
            unaff_RDI = fcn.180459890(uVar2);
        }
code_r0x00018000ef46:
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        iVar6 = iVar3 + unaff_RDI;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        if (uVar4 < 0x10) {
            func_0x000180498030(unaff_RDI, arg1, iVar3);
            func_0x000180498030(iVar6, arg4, arg_28h);
            *(undefined *)(iVar6 + arg_28h) = 0;
            goto code_r0x00018000efd6;
        }
        uVar8 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RDI, uVar8, iVar3);
        func_0x000180498030(iVar6, arg4, arg_28h);
        *(undefined *)(iVar6 + arg_28h) = 0;
        if (0xfff < uVar4 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                fcn.180459c3c(*piVar1, uVar4 + 0x28);
                goto code_r0x00018000efd6;
            }
            goto code_r0x00018000efaa;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x00018000ef23:
        iVar6 = fcn.180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x00018000ef46;
        }
code_r0x00018000efaa:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        piVar9 = (int64_t *)auStack_40;
    }
    *(undefined8 *)((int64_t)piVar9 + -8) = 0x18000efb9;
    fcn.180459c3c(uVar8);
code_r0x00018000efd6:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_18000f001
// Address: 0x18000f001
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.18000ee80(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    uint64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    undefined auStack_40 [24];
    int64_t var_28h;
    
    piVar9 = &var_48h;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffffU - iVar3 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar4 <= 0x7fffffffffffffff - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RDI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    fcn.180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x00018000ef23;
            }
            unaff_RDI = fcn.180459890(uVar2);
        }
code_r0x00018000ef46:
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        iVar6 = iVar3 + unaff_RDI;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        if (uVar4 < 0x10) {
            func_0x000180498030(unaff_RDI, arg1, iVar3);
            func_0x000180498030(iVar6, arg4, arg_28h);
            *(undefined *)(iVar6 + arg_28h) = 0;
            goto code_r0x00018000efd6;
        }
        uVar8 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RDI, uVar8, iVar3);
        func_0x000180498030(iVar6, arg4, arg_28h);
        *(undefined *)(iVar6 + arg_28h) = 0;
        if (0xfff < uVar4 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                fcn.180459c3c(*piVar1, uVar4 + 0x28);
                goto code_r0x00018000efd6;
            }
            goto code_r0x00018000efaa;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x00018000ef23:
        iVar6 = fcn.180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x00018000ef46;
        }
code_r0x00018000efaa:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        piVar9 = (int64_t *)auStack_40;
    }
    *(undefined8 *)((int64_t)piVar9 + -8) = 0x18000efb9;
    fcn.180459c3c(uVar8);
code_r0x00018000efd6:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

