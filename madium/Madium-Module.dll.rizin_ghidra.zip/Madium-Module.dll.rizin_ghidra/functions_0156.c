// Chunk 156 - 50 functions

// ============================================================
// Function: FUN_18020c1c3
// Address: 0x18020c1c3
// Size: 57 bytes
// ============================================================
void fcn.18020c1c3(int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    undefined unaff_SIL;
    int64_t unaff_RDI;
    bool in_ZF;
    
    if (!in_ZF) {
        func_0x00018020be10();
    }
    if (*(int64_t *)(unaff_RDI + 0x38) == *(int64_t *)(unaff_RDI + 0x40)) {
        iVar1 = func_0x00018020cd80(unaff_RDI + 0x28, 0);
        if (iVar1 == 0) {
            *(undefined *)(unaff_RDI + 4) = 1;
            return;
        }
    }
    *(undefined *)(*(int64_t *)(unaff_RDI + 0x30) + *(int64_t *)(unaff_RDI + 0x40)) = unaff_SIL;
    *(int64_t *)(unaff_RDI + 0x40) = *(int64_t *)(unaff_RDI + 0x40) + 1;
    return;
}

// ============================================================
// Function: FUN_18020c1fc
// Address: 0x18020c1fc
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_30h

void fcn.18020c1c3(int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    undefined unaff_SIL;
    int64_t unaff_RDI;
    bool in_ZF;
    
    if (!in_ZF) {
        func_0x00018020be10();
    }
    if (*(int64_t *)(unaff_RDI + 0x38) == *(int64_t *)(unaff_RDI + 0x40)) {
        iVar1 = func_0x00018020cd80(unaff_RDI + 0x28, 0);
        if (iVar1 == 0) {
            *(undefined *)(unaff_RDI + 4) = 1;
            return;
        }
    }
    *(undefined *)(*(int64_t *)(unaff_RDI + 0x30) + *(int64_t *)(unaff_RDI + 0x40)) = unaff_SIL;
    *(int64_t *)(unaff_RDI + 0x40) = *(int64_t *)(unaff_RDI + 0x40) + 1;
    return;
}

// ============================================================
// Function: FUN_18020c211
// Address: 0x18020c211
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_30h

void fcn.18020c1c3(int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    undefined unaff_SIL;
    int64_t unaff_RDI;
    bool in_ZF;
    
    if (!in_ZF) {
        func_0x00018020be10();
    }
    if (*(int64_t *)(unaff_RDI + 0x38) == *(int64_t *)(unaff_RDI + 0x40)) {
        iVar1 = func_0x00018020cd80(unaff_RDI + 0x28, 0);
        if (iVar1 == 0) {
            *(undefined *)(unaff_RDI + 4) = 1;
            return;
        }
    }
    *(undefined *)(*(int64_t *)(unaff_RDI + 0x30) + *(int64_t *)(unaff_RDI + 0x40)) = unaff_SIL;
    *(int64_t *)(unaff_RDI + 0x40) = *(int64_t *)(unaff_RDI + 0x40) + 1;
    return;
}

// ============================================================
// Function: FUN_18020c220
// Address: 0x18020c220
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2h
// WARNING: [rz-ghidra] Detected overlap for variable var_6h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h

void fcn.18020c220(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_60h,
                  int64_t arg_70h, int64_t arg_b0h)
{
    undefined2 *puVar1;
    uint8_t uVar2;
    undefined2 uVar3;
    undefined4 uVar4;
    undefined auVar5 [16];
    char cVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    uint8_t uVar9;
    undefined4 *in_RDX;
    int64_t iVar10;
    undefined8 unaff_RSI;
    int32_t iVar11;
    uint64_t in_R8;
    int32_t in_R9D;
    char *pcVar12;
    undefined8 unaff_R15;
    undefined auVar13 [16];
    undefined auVar14 [16];
    undefined in_XMM2 [16];
    undefined auVar15 [16];
    uint32_t uVar16;
    uint32_t uVar17;
    uint32_t uVar18;
    uint32_t uVar19;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    undefined4 unaff_XMM8_Da;
    undefined4 unaff_XMM8_Db;
    undefined4 unaff_XMM8_Dc;
    undefined4 unaff_XMM8_Dd;
    undefined4 unaff_XMM9_Da;
    undefined4 unaff_XMM9_Db;
    undefined4 unaff_XMM9_Dc;
    undefined4 unaff_XMM9_Dd;
    undefined4 unaff_XMM10_Da;
    undefined4 unaff_XMM10_Db;
    undefined4 unaff_XMM10_Dc;
    undefined4 unaff_XMM10_Dd;
    undefined4 unaff_XMM11_Da;
    undefined4 unaff_XMM11_Db;
    undefined4 unaff_XMM11_Dc;
    undefined4 unaff_XMM11_Dd;
    int64_t var_8h;
    int64_t var_10h;
    undefined4 auStackX_18 [2];
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18020c230;
    iVar8 = func_0x00018045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&var_8h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar8);
    if (*(char *)(in_RCX + 4) != '\0') goto code_r0x00018020c5e9;
    cVar6 = *(char *)(in_RCX + 0x10);
    *(undefined8 *)((int64_t)&arg_b0h + iVar8) = unaff_RSI;
    if (cVar6 != '\0') {
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c26b;
        func_0x00018020be10();
    }
    if (*(int64_t *)(in_RCX + 0x38) == *(int64_t *)(in_RCX + 0x40)) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c280;
        iVar7 = func_0x00018020cd80(in_RCX + 0x28, 0);
        if (iVar7 != 0) goto code_r0x00018020c28a;
        *(undefined *)(in_RCX + 4) = 1;
    } else {
code_r0x00018020c28a:
        *(undefined *)(*(int64_t *)(in_RCX + 0x30) + *(int64_t *)(in_RCX + 0x40)) = 0x22;
        *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
    }
    if (in_R9D != 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c2a7;
        in_R8 = func_0x000180498cd0(in_RDX);
    }
    iVar7 = *(int32_t *)0x1806a3990;
    auVar5 = *(undefined (*) [16])0x1804ba4c0;
    if (in_R8 != 0) {
        *(undefined8 *)((int64_t)&arg_70h + iVar8) = unaff_R15;
        *(undefined4 *)((int64_t)&arg_60h + iVar8) = unaff_XMM6_Da;
        *(undefined4 *)((int64_t)&arg_60h + iVar8 + 4) = unaff_XMM6_Db;
        *(undefined4 *)(&stack0x00000068 + iVar8) = unaff_XMM6_Dc;
        *(undefined4 *)(&stack0x0000006c + iVar8) = unaff_XMM6_Dd;
        *(undefined4 *)((int64_t)&arg_50h + iVar8) = unaff_XMM7_Da;
        *(undefined4 *)((int64_t)&arg_50h + iVar8 + 4) = unaff_XMM7_Db;
        *(undefined4 *)(&stack0x00000058 + iVar8) = unaff_XMM7_Dc;
        *(undefined4 *)(&stack0x0000005c + iVar8) = unaff_XMM7_Dd;
        *(undefined4 *)((int64_t)&arg_40h + iVar8) = unaff_XMM8_Da;
        *(undefined4 *)((int64_t)&arg_40h + iVar8 + 4) = unaff_XMM8_Db;
        *(undefined4 *)(&stack0x00000048 + iVar8) = unaff_XMM8_Dc;
        *(undefined4 *)(&stack0x0000004c + iVar8) = unaff_XMM8_Dd;
        *(undefined4 *)((int64_t)&arg_30h + iVar8) = unaff_XMM9_Da;
        *(undefined4 *)((int64_t)&arg_30h + iVar8 + 4) = unaff_XMM9_Db;
        *(undefined4 *)((int64_t)&arg_38h + iVar8) = unaff_XMM9_Dc;
        *(undefined4 *)((int64_t)&arg_38h + iVar8 + 4) = unaff_XMM9_Dd;
        *(undefined4 *)((int64_t)&var_20h + iVar8) = unaff_XMM10_Da;
        *(undefined4 *)((int64_t)&var_20h + iVar8 + 4) = unaff_XMM10_Db;
        *(undefined4 *)((int64_t)&arg_28h + iVar8) = unaff_XMM10_Dc;
        *(undefined4 *)((int64_t)&arg_28h + iVar8 + 4) = unaff_XMM10_Dd;
        *(undefined4 *)((int64_t)auStackX_18 + iVar8 + -8) = unaff_XMM11_Da;
        *(undefined4 *)((int64_t)auStackX_18 + iVar8 + -4) = unaff_XMM11_Db;
        *(undefined4 *)((int64_t)auStackX_18 + iVar8) = unaff_XMM11_Dc;
        *(undefined4 *)((int64_t)auStackX_18 + iVar8 + 4) = unaff_XMM11_Dd;
        do {
            uVar2 = *(uint8_t *)in_RDX;
    // switch table (8 cases) at 0x18020c604
            switch(uVar2) {
            case 8:
                iVar10 = 0x1804ba49c;
                break;
            case 9:
                iVar10 = 0x180620380;
                break;
            case 10:
                iVar10 = 0x180620378;
                break;
            default:
                if ((((uint8_t)(uVar2 + 0x3e) < 0x1e) && (1 < in_R8)) &&
                   ((uint8_t)(*(uint8_t *)((int64_t)in_RDX + 1) + 0x80) < 0x40)) {
                    uVar3 = *(undefined2 *)in_RDX;
                    in_RDX = (undefined4 *)((int64_t)in_RDX + 1);
                    in_R8 = in_R8 - 1;
                    *(undefined2 *)(&stack0x00000000 + iVar8) = uVar3;
                    (&stack0x00000002)[iVar8] = 0;
code_r0x00018020c557:
                    iVar10 = (int64_t)&stack0x00000000 + iVar8;
                    break;
                }
                if (((((uint8_t)(uVar2 + 0x20) < 0x10) && (2 < in_R8)) &&
                    ((uVar9 = *(uint8_t *)((int64_t)in_RDX + 1), (uint8_t)(uVar9 + 0x80) < 0x40 &&
                     ((uint8_t)(*(uint8_t *)((int64_t)in_RDX + 2) + 0x80) < 0x40)))) &&
                   (((uVar2 != 0xe0 || (0x9f < uVar9)) && ((uVar2 != 0xed || (uVar9 < 0xa0)))))) {
                    *(undefined2 *)(&stack0x00000000 + iVar8) = *(undefined2 *)in_RDX;
                    puVar1 = (undefined2 *)((int64_t)in_RDX + 2);
                    in_RDX = (undefined4 *)((int64_t)in_RDX + 2);
                    in_R8 = in_R8 - 2;
                    (&stack0x00000002)[iVar8] = *(uint8_t *)puVar1;
                    (&stack0x00000003)[iVar8] = 0;
                    goto code_r0x00018020c557;
                }
                uVar2 = *(uint8_t *)in_RDX;
                if (((((uint8_t)(uVar2 + 0x10) < 5) && (3 < in_R8)) &&
                    (uVar9 = *(uint8_t *)((int64_t)in_RDX + 1), (uint8_t)(uVar9 + 0x80) < 0x40)) &&
                   (((uint8_t)(*(uint8_t *)((int64_t)in_RDX + 2) + 0x80) < 0x40 &&
                    ((uint8_t)(*(uint8_t *)((int64_t)in_RDX + 3) + 0x80) < 0x40)))) {
                    if (((uVar2 == 0xf0) && (uVar9 < 0x90)) || ((uVar2 == 0xf4 && (0x8f < uVar9))))
                    goto code_r0x00018020c4a3;
                    uVar4 = *in_RDX;
                    in_RDX = (undefined4 *)((int64_t)in_RDX + 3);
                    in_R8 = in_R8 - 3;
                    *(undefined4 *)(&stack0x00000000 + iVar8) = uVar4;
                    (&stack0x00000004)[iVar8] = 0;
                    goto code_r0x00018020c557;
                }
                if (0x5e < (uint8_t)(uVar2 - 0x20)) {
code_r0x00018020c4a3:
                    iVar11 = 0;
                    *(undefined2 *)(&stack0x00000000 + iVar8) = 0x755c;
                    if (iVar7 < 5) {
                        uVar2 = *(uint8_t *)in_RDX;
                        pcVar12 = &stack0x00000002 + iVar8;
                        do {
                            uVar9 = uVar2 >> ((3U - (char)iVar11 & 7) << 2) & 0xf;
                            cVar6 = 'W';
                            if (uVar9 < 10) {
                                cVar6 = '0';
                            }
                            iVar11 = iVar11 + 1;
                            *pcVar12 = cVar6 + uVar9;
                            pcVar12 = pcVar12 + 1;
                        } while (iVar11 < 4);
                    } else {
                        auVar15[3] = (char)uVar2 >> 7;
                        auVar15[7] = auVar15[3];
                        auVar15[6] = auVar15[3];
                        auVar15[5] = auVar15[3];
                        auVar15[4] = auVar15[3];
                        auVar15[2] = auVar15[3];
                        auVar15[1] = uVar2;
                        auVar15[0] = uVar2;
                        auVar15._8_8_ = 0;
                        auVar13 = pshuflw(auVar15, auVar15, 0);
                        auVar15 = pmovzxbd(in_XMM2, ZEXT416(0x4080c));
                        auVar13 = pmovzxbd(ZEXT416(0x4080c), auVar13);
                        auVar13 = vpsrlvd_avx2(auVar13, auVar15);
                        uVar16 = auVar13._0_4_ & 0xf;
                        uVar17 = auVar13._4_4_ & 0xf;
                        uVar18 = auVar13._8_4_ & 0xf;
                        uVar19 = auVar13._12_4_ & 0xf;
                        in_XMM2._0_4_ = -(uint32_t)(((uint32_t)(uVar16 < 10) * 10 | (uVar16 >= 10) * uVar16) == uVar16);
                        in_XMM2._4_4_ = -(uint32_t)(((uint32_t)(uVar17 < 10) * 10 | (uVar17 >= 10) * uVar17) == uVar17);
                        in_XMM2._8_4_ = -(uint32_t)(((uint32_t)(uVar18 < 10) * 10 | (uVar18 >= 10) * uVar18) == uVar18);
                        in_XMM2._12_4_ = -(uint32_t)(((uint32_t)(uVar19 < 10) * 10 | (uVar19 >= 10) * uVar19) == uVar19)
                        ;
                        auVar14._0_4_ = ~in_XMM2._0_4_ & uVar16 + 0x30;
                        auVar14._4_4_ = ~in_XMM2._4_4_ & uVar17 + 0x30;
                        auVar14._8_4_ = ~in_XMM2._8_4_ & uVar18 + 0x30;
                        auVar14._12_4_ = ~in_XMM2._12_4_ & uVar19 + 0x30;
                        auVar13._0_4_ = uVar16 + 0x57 & in_XMM2._0_4_;
                        auVar13._4_4_ = uVar17 + 0x57 & in_XMM2._4_4_;
                        auVar13._8_4_ = uVar18 + 0x57 & in_XMM2._8_4_;
                        auVar13._12_4_ = uVar19 + 0x57 & in_XMM2._12_4_;
                        auVar13 = pshufb(auVar14 | auVar13, auVar5);
                        *(int32_t *)(&stack0x00000002 + iVar8) = auVar13._0_4_;
                    }
                    (&stack0x00000006)[iVar8] = 0;
                    goto code_r0x00018020c557;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c49e;
                func_0x00018020c1a0(in_RCX);
                goto code_r0x00018020c564;
            case 0xc:
                iVar10 = 0x1804ba4a0;
                break;
            case 0xd:
                iVar10 = 0x18062037c;
                break;
            case 0x22:
                iVar10 = 0x180620370;
                break;
            case 0x5c:
                iVar10 = 0x180620374;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c564;
            func_0x00018020c680(in_RCX, iVar10);
code_r0x00018020c564:
            in_RDX = (undefined4 *)((int64_t)in_RDX + 1);
            in_R8 = in_R8 - 1;
        } while (in_R8 != 0);
    }
    if (*(char *)(in_RCX + 4) == '\0') {
        if (*(char *)(in_RCX + 0x10) != '\0') {
            *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c5ba;
            func_0x00018020be10(in_RCX);
        }
        if (*(int64_t *)(in_RCX + 0x38) == *(int64_t *)(in_RCX + 0x40)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c5cf;
            iVar7 = func_0x00018020cd80(in_RCX + 0x28, 0);
            if (iVar7 == 0) {
                *(undefined *)(in_RCX + 4) = 1;
                goto code_r0x00018020c5e9;
            }
        }
        *(undefined *)(*(int64_t *)(in_RCX + 0x40) + *(int64_t *)(in_RCX + 0x30)) = 0x22;
        *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
    }
code_r0x00018020c5e9:
    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c5f6;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_8h + iVar8) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar8));
    return;
}

// ============================================================
// Function: FUN_18020c25c
// Address: 0x18020c25c
// Size: 99 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2h
// WARNING: [rz-ghidra] Detected overlap for variable var_6h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h

void fcn.18020c220(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_60h,
                  int64_t arg_70h, int64_t arg_b0h)
{
    undefined2 *puVar1;
    uint8_t uVar2;
    undefined2 uVar3;
    undefined4 uVar4;
    undefined auVar5 [16];
    char cVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    uint8_t uVar9;
    undefined4 *in_RDX;
    int64_t iVar10;
    undefined8 unaff_RSI;
    int32_t iVar11;
    uint64_t in_R8;
    int32_t in_R9D;
    char *pcVar12;
    undefined8 unaff_R15;
    undefined auVar13 [16];
    undefined auVar14 [16];
    undefined in_XMM2 [16];
    undefined auVar15 [16];
    uint32_t uVar16;
    uint32_t uVar17;
    uint32_t uVar18;
    uint32_t uVar19;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    undefined4 unaff_XMM8_Da;
    undefined4 unaff_XMM8_Db;
    undefined4 unaff_XMM8_Dc;
    undefined4 unaff_XMM8_Dd;
    undefined4 unaff_XMM9_Da;
    undefined4 unaff_XMM9_Db;
    undefined4 unaff_XMM9_Dc;
    undefined4 unaff_XMM9_Dd;
    undefined4 unaff_XMM10_Da;
    undefined4 unaff_XMM10_Db;
    undefined4 unaff_XMM10_Dc;
    undefined4 unaff_XMM10_Dd;
    undefined4 unaff_XMM11_Da;
    undefined4 unaff_XMM11_Db;
    undefined4 unaff_XMM11_Dc;
    undefined4 unaff_XMM11_Dd;
    int64_t var_8h;
    int64_t var_10h;
    undefined4 auStackX_18 [2];
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18020c230;
    iVar8 = func_0x00018045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&var_8h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar8);
    if (*(char *)(in_RCX + 4) != '\0') goto code_r0x00018020c5e9;
    cVar6 = *(char *)(in_RCX + 0x10);
    *(undefined8 *)((int64_t)&arg_b0h + iVar8) = unaff_RSI;
    if (cVar6 != '\0') {
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c26b;
        func_0x00018020be10();
    }
    if (*(int64_t *)(in_RCX + 0x38) == *(int64_t *)(in_RCX + 0x40)) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c280;
        iVar7 = func_0x00018020cd80(in_RCX + 0x28, 0);
        if (iVar7 != 0) goto code_r0x00018020c28a;
        *(undefined *)(in_RCX + 4) = 1;
    } else {
code_r0x00018020c28a:
        *(undefined *)(*(int64_t *)(in_RCX + 0x30) + *(int64_t *)(in_RCX + 0x40)) = 0x22;
        *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
    }
    if (in_R9D != 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c2a7;
        in_R8 = func_0x000180498cd0(in_RDX);
    }
    iVar7 = *(int32_t *)0x1806a3990;
    auVar5 = *(undefined (*) [16])0x1804ba4c0;
    if (in_R8 != 0) {
        *(undefined8 *)((int64_t)&arg_70h + iVar8) = unaff_R15;
        *(undefined4 *)((int64_t)&arg_60h + iVar8) = unaff_XMM6_Da;
        *(undefined4 *)((int64_t)&arg_60h + iVar8 + 4) = unaff_XMM6_Db;
        *(undefined4 *)(&stack0x00000068 + iVar8) = unaff_XMM6_Dc;
        *(undefined4 *)(&stack0x0000006c + iVar8) = unaff_XMM6_Dd;
        *(undefined4 *)((int64_t)&arg_50h + iVar8) = unaff_XMM7_Da;
        *(undefined4 *)((int64_t)&arg_50h + iVar8 + 4) = unaff_XMM7_Db;
        *(undefined4 *)(&stack0x00000058 + iVar8) = unaff_XMM7_Dc;
        *(undefined4 *)(&stack0x0000005c + iVar8) = unaff_XMM7_Dd;
        *(undefined4 *)((int64_t)&arg_40h + iVar8) = unaff_XMM8_Da;
        *(undefined4 *)((int64_t)&arg_40h + iVar8 + 4) = unaff_XMM8_Db;
        *(undefined4 *)(&stack0x00000048 + iVar8) = unaff_XMM8_Dc;
        *(undefined4 *)(&stack0x0000004c + iVar8) = unaff_XMM8_Dd;
        *(undefined4 *)((int64_t)&arg_30h + iVar8) = unaff_XMM9_Da;
        *(undefined4 *)((int64_t)&arg_30h + iVar8 + 4) = unaff_XMM9_Db;
        *(undefined4 *)((int64_t)&arg_38h + iVar8) = unaff_XMM9_Dc;
        *(undefined4 *)((int64_t)&arg_38h + iVar8 + 4) = unaff_XMM9_Dd;
        *(undefined4 *)((int64_t)&var_20h + iVar8) = unaff_XMM10_Da;
        *(undefined4 *)((int64_t)&var_20h + iVar8 + 4) = unaff_XMM10_Db;
        *(undefined4 *)((int64_t)&arg_28h + iVar8) = unaff_XMM10_Dc;
        *(undefined4 *)((int64_t)&arg_28h + iVar8 + 4) = unaff_XMM10_Dd;
        *(undefined4 *)((int64_t)auStackX_18 + iVar8 + -8) = unaff_XMM11_Da;
        *(undefined4 *)((int64_t)auStackX_18 + iVar8 + -4) = unaff_XMM11_Db;
        *(undefined4 *)((int64_t)auStackX_18 + iVar8) = unaff_XMM11_Dc;
        *(undefined4 *)((int64_t)auStackX_18 + iVar8 + 4) = unaff_XMM11_Dd;
        do {
            uVar2 = *(uint8_t *)in_RDX;
    // switch table (8 cases) at 0x18020c604
            switch(uVar2) {
            case 8:
                iVar10 = 0x1804ba49c;
                break;
            case 9:
                iVar10 = 0x180620380;
                break;
            case 10:
                iVar10 = 0x180620378;
                break;
            default:
                if ((((uint8_t)(uVar2 + 0x3e) < 0x1e) && (1 < in_R8)) &&
                   ((uint8_t)(*(uint8_t *)((int64_t)in_RDX + 1) + 0x80) < 0x40)) {
                    uVar3 = *(undefined2 *)in_RDX;
                    in_RDX = (undefined4 *)((int64_t)in_RDX + 1);
                    in_R8 = in_R8 - 1;
                    *(undefined2 *)(&stack0x00000000 + iVar8) = uVar3;
                    (&stack0x00000002)[iVar8] = 0;
code_r0x00018020c557:
                    iVar10 = (int64_t)&stack0x00000000 + iVar8;
                    break;
                }
                if (((((uint8_t)(uVar2 + 0x20) < 0x10) && (2 < in_R8)) &&
                    ((uVar9 = *(uint8_t *)((int64_t)in_RDX + 1), (uint8_t)(uVar9 + 0x80) < 0x40 &&
                     ((uint8_t)(*(uint8_t *)((int64_t)in_RDX + 2) + 0x80) < 0x40)))) &&
                   (((uVar2 != 0xe0 || (0x9f < uVar9)) && ((uVar2 != 0xed || (uVar9 < 0xa0)))))) {
                    *(undefined2 *)(&stack0x00000000 + iVar8) = *(undefined2 *)in_RDX;
                    puVar1 = (undefined2 *)((int64_t)in_RDX + 2);
                    in_RDX = (undefined4 *)((int64_t)in_RDX + 2);
                    in_R8 = in_R8 - 2;
                    (&stack0x00000002)[iVar8] = *(uint8_t *)puVar1;
                    (&stack0x00000003)[iVar8] = 0;
                    goto code_r0x00018020c557;
                }
                uVar2 = *(uint8_t *)in_RDX;
                if (((((uint8_t)(uVar2 + 0x10) < 5) && (3 < in_R8)) &&
                    (uVar9 = *(uint8_t *)((int64_t)in_RDX + 1), (uint8_t)(uVar9 + 0x80) < 0x40)) &&
                   (((uint8_t)(*(uint8_t *)((int64_t)in_RDX + 2) + 0x80) < 0x40 &&
                    ((uint8_t)(*(uint8_t *)((int64_t)in_RDX + 3) + 0x80) < 0x40)))) {
                    if (((uVar2 == 0xf0) && (uVar9 < 0x90)) || ((uVar2 == 0xf4 && (0x8f < uVar9))))
                    goto code_r0x00018020c4a3;
                    uVar4 = *in_RDX;
                    in_RDX = (undefined4 *)((int64_t)in_RDX + 3);
                    in_R8 = in_R8 - 3;
                    *(undefined4 *)(&stack0x00000000 + iVar8) = uVar4;
                    (&stack0x00000004)[iVar8] = 0;
                    goto code_r0x00018020c557;
                }
                if (0x5e < (uint8_t)(uVar2 - 0x20)) {
code_r0x00018020c4a3:
                    iVar11 = 0;
                    *(undefined2 *)(&stack0x00000000 + iVar8) = 0x755c;
                    if (iVar7 < 5) {
                        uVar2 = *(uint8_t *)in_RDX;
                        pcVar12 = &stack0x00000002 + iVar8;
                        do {
                            uVar9 = uVar2 >> ((3U - (char)iVar11 & 7) << 2) & 0xf;
                            cVar6 = 'W';
                            if (uVar9 < 10) {
                                cVar6 = '0';
                            }
                            iVar11 = iVar11 + 1;
                            *pcVar12 = cVar6 + uVar9;
                            pcVar12 = pcVar12 + 1;
                        } while (iVar11 < 4);
                    } else {
                        auVar15[3] = (char)uVar2 >> 7;
                        auVar15[7] = auVar15[3];
                        auVar15[6] = auVar15[3];
                        auVar15[5] = auVar15[3];
                        auVar15[4] = auVar15[3];
                        auVar15[2] = auVar15[3];
                        auVar15[1] = uVar2;
                        auVar15[0] = uVar2;
                        auVar15._8_8_ = 0;
                        auVar13 = pshuflw(auVar15, auVar15, 0);
                        auVar15 = pmovzxbd(in_XMM2, ZEXT416(0x4080c));
                        auVar13 = pmovzxbd(ZEXT416(0x4080c), auVar13);
                        auVar13 = vpsrlvd_avx2(auVar13, auVar15);
                        uVar16 = auVar13._0_4_ & 0xf;
                        uVar17 = auVar13._4_4_ & 0xf;
                        uVar18 = auVar13._8_4_ & 0xf;
                        uVar19 = auVar13._12_4_ & 0xf;
                        in_XMM2._0_4_ = -(uint32_t)(((uint32_t)(uVar16 < 10) * 10 | (uVar16 >= 10) * uVar16) == uVar16);
                        in_XMM2._4_4_ = -(uint32_t)(((uint32_t)(uVar17 < 10) * 10 | (uVar17 >= 10) * uVar17) == uVar17);
                        in_XMM2._8_4_ = -(uint32_t)(((uint32_t)(uVar18 < 10) * 10 | (uVar18 >= 10) * uVar18) == uVar18);
                        in_XMM2._12_4_ = -(uint32_t)(((uint32_t)(uVar19 < 10) * 10 | (uVar19 >= 10) * uVar19) == uVar19)
                        ;
                        auVar14._0_4_ = ~in_XMM2._0_4_ & uVar16 + 0x30;
                        auVar14._4_4_ = ~in_XMM2._4_4_ & uVar17 + 0x30;
                        auVar14._8_4_ = ~in_XMM2._8_4_ & uVar18 + 0x30;
                        auVar14._12_4_ = ~in_XMM2._12_4_ & uVar19 + 0x30;
                        auVar13._0_4_ = uVar16 + 0x57 & in_XMM2._0_4_;
                        auVar13._4_4_ = uVar17 + 0x57 & in_XMM2._4_4_;
                        auVar13._8_4_ = uVar18 + 0x57 & in_XMM2._8_4_;
                        auVar13._12_4_ = uVar19 + 0x57 & in_XMM2._12_4_;
                        auVar13 = pshufb(auVar14 | auVar13, auVar5);
                        *(int32_t *)(&stack0x00000002 + iVar8) = auVar13._0_4_;
                    }
                    (&stack0x00000006)[iVar8] = 0;
                    goto code_r0x00018020c557;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c49e;
                func_0x00018020c1a0(in_RCX);
                goto code_r0x00018020c564;
            case 0xc:
                iVar10 = 0x1804ba4a0;
                break;
            case 0xd:
                iVar10 = 0x18062037c;
                break;
            case 0x22:
                iVar10 = 0x180620370;
                break;
            case 0x5c:
                iVar10 = 0x180620374;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c564;
            func_0x00018020c680(in_RCX, iVar10);
code_r0x00018020c564:
            in_RDX = (undefined4 *)((int64_t)in_RDX + 1);
            in_R8 = in_R8 - 1;
        } while (in_R8 != 0);
    }
    if (*(char *)(in_RCX + 4) == '\0') {
        if (*(char *)(in_RCX + 0x10) != '\0') {
            *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c5ba;
            func_0x00018020be10(in_RCX);
        }
        if (*(int64_t *)(in_RCX + 0x38) == *(int64_t *)(in_RCX + 0x40)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c5cf;
            iVar7 = func_0x00018020cd80(in_RCX + 0x28, 0);
            if (iVar7 == 0) {
                *(undefined *)(in_RCX + 4) = 1;
                goto code_r0x00018020c5e9;
            }
        }
        *(undefined *)(*(int64_t *)(in_RCX + 0x40) + *(int64_t *)(in_RCX + 0x30)) = 0x22;
        *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
    }
code_r0x00018020c5e9:
    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c5f6;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_8h + iVar8) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar8));
    return;
}

// ============================================================
// Function: FUN_18020c2bf
// Address: 0x18020c2bf
// Size: 735 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2h
// WARNING: [rz-ghidra] Detected overlap for variable var_6h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h

void fcn.18020c220(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_60h,
                  int64_t arg_70h, int64_t arg_b0h)
{
    undefined2 *puVar1;
    uint8_t uVar2;
    undefined2 uVar3;
    undefined4 uVar4;
    undefined auVar5 [16];
    char cVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    uint8_t uVar9;
    undefined4 *in_RDX;
    int64_t iVar10;
    undefined8 unaff_RSI;
    int32_t iVar11;
    uint64_t in_R8;
    int32_t in_R9D;
    char *pcVar12;
    undefined8 unaff_R15;
    undefined auVar13 [16];
    undefined auVar14 [16];
    undefined in_XMM2 [16];
    undefined auVar15 [16];
    uint32_t uVar16;
    uint32_t uVar17;
    uint32_t uVar18;
    uint32_t uVar19;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    undefined4 unaff_XMM8_Da;
    undefined4 unaff_XMM8_Db;
    undefined4 unaff_XMM8_Dc;
    undefined4 unaff_XMM8_Dd;
    undefined4 unaff_XMM9_Da;
    undefined4 unaff_XMM9_Db;
    undefined4 unaff_XMM9_Dc;
    undefined4 unaff_XMM9_Dd;
    undefined4 unaff_XMM10_Da;
    undefined4 unaff_XMM10_Db;
    undefined4 unaff_XMM10_Dc;
    undefined4 unaff_XMM10_Dd;
    undefined4 unaff_XMM11_Da;
    undefined4 unaff_XMM11_Db;
    undefined4 unaff_XMM11_Dc;
    undefined4 unaff_XMM11_Dd;
    int64_t var_8h;
    int64_t var_10h;
    undefined4 auStackX_18 [2];
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18020c230;
    iVar8 = func_0x00018045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&var_8h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar8);
    if (*(char *)(in_RCX + 4) != '\0') goto code_r0x00018020c5e9;
    cVar6 = *(char *)(in_RCX + 0x10);
    *(undefined8 *)((int64_t)&arg_b0h + iVar8) = unaff_RSI;
    if (cVar6 != '\0') {
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c26b;
        func_0x00018020be10();
    }
    if (*(int64_t *)(in_RCX + 0x38) == *(int64_t *)(in_RCX + 0x40)) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c280;
        iVar7 = func_0x00018020cd80(in_RCX + 0x28, 0);
        if (iVar7 != 0) goto code_r0x00018020c28a;
        *(undefined *)(in_RCX + 4) = 1;
    } else {
code_r0x00018020c28a:
        *(undefined *)(*(int64_t *)(in_RCX + 0x30) + *(int64_t *)(in_RCX + 0x40)) = 0x22;
        *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
    }
    if (in_R9D != 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c2a7;
        in_R8 = func_0x000180498cd0(in_RDX);
    }
    iVar7 = *(int32_t *)0x1806a3990;
    auVar5 = *(undefined (*) [16])0x1804ba4c0;
    if (in_R8 != 0) {
        *(undefined8 *)((int64_t)&arg_70h + iVar8) = unaff_R15;
        *(undefined4 *)((int64_t)&arg_60h + iVar8) = unaff_XMM6_Da;
        *(undefined4 *)((int64_t)&arg_60h + iVar8 + 4) = unaff_XMM6_Db;
        *(undefined4 *)(&stack0x00000068 + iVar8) = unaff_XMM6_Dc;
        *(undefined4 *)(&stack0x0000006c + iVar8) = unaff_XMM6_Dd;
        *(undefined4 *)((int64_t)&arg_50h + iVar8) = unaff_XMM7_Da;
        *(undefined4 *)((int64_t)&arg_50h + iVar8 + 4) = unaff_XMM7_Db;
        *(undefined4 *)(&stack0x00000058 + iVar8) = unaff_XMM7_Dc;
        *(undefined4 *)(&stack0x0000005c + iVar8) = unaff_XMM7_Dd;
        *(undefined4 *)((int64_t)&arg_40h + iVar8) = unaff_XMM8_Da;
        *(undefined4 *)((int64_t)&arg_40h + iVar8 + 4) = unaff_XMM8_Db;
        *(undefined4 *)(&stack0x00000048 + iVar8) = unaff_XMM8_Dc;
        *(undefined4 *)(&stack0x0000004c + iVar8) = unaff_XMM8_Dd;
        *(undefined4 *)((int64_t)&arg_30h + iVar8) = unaff_XMM9_Da;
        *(undefined4 *)((int64_t)&arg_30h + iVar8 + 4) = unaff_XMM9_Db;
        *(undefined4 *)((int64_t)&arg_38h + iVar8) = unaff_XMM9_Dc;
        *(undefined4 *)((int64_t)&arg_38h + iVar8 + 4) = unaff_XMM9_Dd;
        *(undefined4 *)((int64_t)&var_20h + iVar8) = unaff_XMM10_Da;
        *(undefined4 *)((int64_t)&var_20h + iVar8 + 4) = unaff_XMM10_Db;
        *(undefined4 *)((int64_t)&arg_28h + iVar8) = unaff_XMM10_Dc;
        *(undefined4 *)((int64_t)&arg_28h + iVar8 + 4) = unaff_XMM10_Dd;
        *(undefined4 *)((int64_t)auStackX_18 + iVar8 + -8) = unaff_XMM11_Da;
        *(undefined4 *)((int64_t)auStackX_18 + iVar8 + -4) = unaff_XMM11_Db;
        *(undefined4 *)((int64_t)auStackX_18 + iVar8) = unaff_XMM11_Dc;
        *(undefined4 *)((int64_t)auStackX_18 + iVar8 + 4) = unaff_XMM11_Dd;
        do {
            uVar2 = *(uint8_t *)in_RDX;
    // switch table (8 cases) at 0x18020c604
            switch(uVar2) {
            case 8:
                iVar10 = 0x1804ba49c;
                break;
            case 9:
                iVar10 = 0x180620380;
                break;
            case 10:
                iVar10 = 0x180620378;
                break;
            default:
                if ((((uint8_t)(uVar2 + 0x3e) < 0x1e) && (1 < in_R8)) &&
                   ((uint8_t)(*(uint8_t *)((int64_t)in_RDX + 1) + 0x80) < 0x40)) {
                    uVar3 = *(undefined2 *)in_RDX;
                    in_RDX = (undefined4 *)((int64_t)in_RDX + 1);
                    in_R8 = in_R8 - 1;
                    *(undefined2 *)(&stack0x00000000 + iVar8) = uVar3;
                    (&stack0x00000002)[iVar8] = 0;
code_r0x00018020c557:
                    iVar10 = (int64_t)&stack0x00000000 + iVar8;
                    break;
                }
                if (((((uint8_t)(uVar2 + 0x20) < 0x10) && (2 < in_R8)) &&
                    ((uVar9 = *(uint8_t *)((int64_t)in_RDX + 1), (uint8_t)(uVar9 + 0x80) < 0x40 &&
                     ((uint8_t)(*(uint8_t *)((int64_t)in_RDX + 2) + 0x80) < 0x40)))) &&
                   (((uVar2 != 0xe0 || (0x9f < uVar9)) && ((uVar2 != 0xed || (uVar9 < 0xa0)))))) {
                    *(undefined2 *)(&stack0x00000000 + iVar8) = *(undefined2 *)in_RDX;
                    puVar1 = (undefined2 *)((int64_t)in_RDX + 2);
                    in_RDX = (undefined4 *)((int64_t)in_RDX + 2);
                    in_R8 = in_R8 - 2;
                    (&stack0x00000002)[iVar8] = *(uint8_t *)puVar1;
                    (&stack0x00000003)[iVar8] = 0;
                    goto code_r0x00018020c557;
                }
                uVar2 = *(uint8_t *)in_RDX;
                if (((((uint8_t)(uVar2 + 0x10) < 5) && (3 < in_R8)) &&
                    (uVar9 = *(uint8_t *)((int64_t)in_RDX + 1), (uint8_t)(uVar9 + 0x80) < 0x40)) &&
                   (((uint8_t)(*(uint8_t *)((int64_t)in_RDX + 2) + 0x80) < 0x40 &&
                    ((uint8_t)(*(uint8_t *)((int64_t)in_RDX + 3) + 0x80) < 0x40)))) {
                    if (((uVar2 == 0xf0) && (uVar9 < 0x90)) || ((uVar2 == 0xf4 && (0x8f < uVar9))))
                    goto code_r0x00018020c4a3;
                    uVar4 = *in_RDX;
                    in_RDX = (undefined4 *)((int64_t)in_RDX + 3);
                    in_R8 = in_R8 - 3;
                    *(undefined4 *)(&stack0x00000000 + iVar8) = uVar4;
                    (&stack0x00000004)[iVar8] = 0;
                    goto code_r0x00018020c557;
                }
                if (0x5e < (uint8_t)(uVar2 - 0x20)) {
code_r0x00018020c4a3:
                    iVar11 = 0;
                    *(undefined2 *)(&stack0x00000000 + iVar8) = 0x755c;
                    if (iVar7 < 5) {
                        uVar2 = *(uint8_t *)in_RDX;
                        pcVar12 = &stack0x00000002 + iVar8;
                        do {
                            uVar9 = uVar2 >> ((3U - (char)iVar11 & 7) << 2) & 0xf;
                            cVar6 = 'W';
                            if (uVar9 < 10) {
                                cVar6 = '0';
                            }
                            iVar11 = iVar11 + 1;
                            *pcVar12 = cVar6 + uVar9;
                            pcVar12 = pcVar12 + 1;
                        } while (iVar11 < 4);
                    } else {
                        auVar15[3] = (char)uVar2 >> 7;
                        auVar15[7] = auVar15[3];
                        auVar15[6] = auVar15[3];
                        auVar15[5] = auVar15[3];
                        auVar15[4] = auVar15[3];
                        auVar15[2] = auVar15[3];
                        auVar15[1] = uVar2;
                        auVar15[0] = uVar2;
                        auVar15._8_8_ = 0;
                        auVar13 = pshuflw(auVar15, auVar15, 0);
                        auVar15 = pmovzxbd(in_XMM2, ZEXT416(0x4080c));
                        auVar13 = pmovzxbd(ZEXT416(0x4080c), auVar13);
                        auVar13 = vpsrlvd_avx2(auVar13, auVar15);
                        uVar16 = auVar13._0_4_ & 0xf;
                        uVar17 = auVar13._4_4_ & 0xf;
                        uVar18 = auVar13._8_4_ & 0xf;
                        uVar19 = auVar13._12_4_ & 0xf;
                        in_XMM2._0_4_ = -(uint32_t)(((uint32_t)(uVar16 < 10) * 10 | (uVar16 >= 10) * uVar16) == uVar16);
                        in_XMM2._4_4_ = -(uint32_t)(((uint32_t)(uVar17 < 10) * 10 | (uVar17 >= 10) * uVar17) == uVar17);
                        in_XMM2._8_4_ = -(uint32_t)(((uint32_t)(uVar18 < 10) * 10 | (uVar18 >= 10) * uVar18) == uVar18);
                        in_XMM2._12_4_ = -(uint32_t)(((uint32_t)(uVar19 < 10) * 10 | (uVar19 >= 10) * uVar19) == uVar19)
                        ;
                        auVar14._0_4_ = ~in_XMM2._0_4_ & uVar16 + 0x30;
                        auVar14._4_4_ = ~in_XMM2._4_4_ & uVar17 + 0x30;
                        auVar14._8_4_ = ~in_XMM2._8_4_ & uVar18 + 0x30;
                        auVar14._12_4_ = ~in_XMM2._12_4_ & uVar19 + 0x30;
                        auVar13._0_4_ = uVar16 + 0x57 & in_XMM2._0_4_;
                        auVar13._4_4_ = uVar17 + 0x57 & in_XMM2._4_4_;
                        auVar13._8_4_ = uVar18 + 0x57 & in_XMM2._8_4_;
                        auVar13._12_4_ = uVar19 + 0x57 & in_XMM2._12_4_;
                        auVar13 = pshufb(auVar14 | auVar13, auVar5);
                        *(int32_t *)(&stack0x00000002 + iVar8) = auVar13._0_4_;
                    }
                    (&stack0x00000006)[iVar8] = 0;
                    goto code_r0x00018020c557;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c49e;
                func_0x00018020c1a0(in_RCX);
                goto code_r0x00018020c564;
            case 0xc:
                iVar10 = 0x1804ba4a0;
                break;
            case 0xd:
                iVar10 = 0x18062037c;
                break;
            case 0x22:
                iVar10 = 0x180620370;
                break;
            case 0x5c:
                iVar10 = 0x180620374;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c564;
            func_0x00018020c680(in_RCX, iVar10);
code_r0x00018020c564:
            in_RDX = (undefined4 *)((int64_t)in_RDX + 1);
            in_R8 = in_R8 - 1;
        } while (in_R8 != 0);
    }
    if (*(char *)(in_RCX + 4) == '\0') {
        if (*(char *)(in_RCX + 0x10) != '\0') {
            *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c5ba;
            func_0x00018020be10(in_RCX);
        }
        if (*(int64_t *)(in_RCX + 0x38) == *(int64_t *)(in_RCX + 0x40)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c5cf;
            iVar7 = func_0x00018020cd80(in_RCX + 0x28, 0);
            if (iVar7 == 0) {
                *(undefined *)(in_RCX + 4) = 1;
                goto code_r0x00018020c5e9;
            }
        }
        *(undefined *)(*(int64_t *)(in_RCX + 0x40) + *(int64_t *)(in_RCX + 0x30)) = 0x22;
        *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
    }
code_r0x00018020c5e9:
    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c5f6;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_8h + iVar8) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar8));
    return;
}

// ============================================================
// Function: FUN_18020c59e
// Address: 0x18020c59e
// Size: 14 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2h
// WARNING: [rz-ghidra] Detected overlap for variable var_6h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h

void fcn.18020c220(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_60h,
                  int64_t arg_70h, int64_t arg_b0h)
{
    undefined2 *puVar1;
    uint8_t uVar2;
    undefined2 uVar3;
    undefined4 uVar4;
    undefined auVar5 [16];
    char cVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    uint8_t uVar9;
    undefined4 *in_RDX;
    int64_t iVar10;
    undefined8 unaff_RSI;
    int32_t iVar11;
    uint64_t in_R8;
    int32_t in_R9D;
    char *pcVar12;
    undefined8 unaff_R15;
    undefined auVar13 [16];
    undefined auVar14 [16];
    undefined in_XMM2 [16];
    undefined auVar15 [16];
    uint32_t uVar16;
    uint32_t uVar17;
    uint32_t uVar18;
    uint32_t uVar19;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    undefined4 unaff_XMM8_Da;
    undefined4 unaff_XMM8_Db;
    undefined4 unaff_XMM8_Dc;
    undefined4 unaff_XMM8_Dd;
    undefined4 unaff_XMM9_Da;
    undefined4 unaff_XMM9_Db;
    undefined4 unaff_XMM9_Dc;
    undefined4 unaff_XMM9_Dd;
    undefined4 unaff_XMM10_Da;
    undefined4 unaff_XMM10_Db;
    undefined4 unaff_XMM10_Dc;
    undefined4 unaff_XMM10_Dd;
    undefined4 unaff_XMM11_Da;
    undefined4 unaff_XMM11_Db;
    undefined4 unaff_XMM11_Dc;
    undefined4 unaff_XMM11_Dd;
    int64_t var_8h;
    int64_t var_10h;
    undefined4 auStackX_18 [2];
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18020c230;
    iVar8 = func_0x00018045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&var_8h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar8);
    if (*(char *)(in_RCX + 4) != '\0') goto code_r0x00018020c5e9;
    cVar6 = *(char *)(in_RCX + 0x10);
    *(undefined8 *)((int64_t)&arg_b0h + iVar8) = unaff_RSI;
    if (cVar6 != '\0') {
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c26b;
        func_0x00018020be10();
    }
    if (*(int64_t *)(in_RCX + 0x38) == *(int64_t *)(in_RCX + 0x40)) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c280;
        iVar7 = func_0x00018020cd80(in_RCX + 0x28, 0);
        if (iVar7 != 0) goto code_r0x00018020c28a;
        *(undefined *)(in_RCX + 4) = 1;
    } else {
code_r0x00018020c28a:
        *(undefined *)(*(int64_t *)(in_RCX + 0x30) + *(int64_t *)(in_RCX + 0x40)) = 0x22;
        *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
    }
    if (in_R9D != 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c2a7;
        in_R8 = func_0x000180498cd0(in_RDX);
    }
    iVar7 = *(int32_t *)0x1806a3990;
    auVar5 = *(undefined (*) [16])0x1804ba4c0;
    if (in_R8 != 0) {
        *(undefined8 *)((int64_t)&arg_70h + iVar8) = unaff_R15;
        *(undefined4 *)((int64_t)&arg_60h + iVar8) = unaff_XMM6_Da;
        *(undefined4 *)((int64_t)&arg_60h + iVar8 + 4) = unaff_XMM6_Db;
        *(undefined4 *)(&stack0x00000068 + iVar8) = unaff_XMM6_Dc;
        *(undefined4 *)(&stack0x0000006c + iVar8) = unaff_XMM6_Dd;
        *(undefined4 *)((int64_t)&arg_50h + iVar8) = unaff_XMM7_Da;
        *(undefined4 *)((int64_t)&arg_50h + iVar8 + 4) = unaff_XMM7_Db;
        *(undefined4 *)(&stack0x00000058 + iVar8) = unaff_XMM7_Dc;
        *(undefined4 *)(&stack0x0000005c + iVar8) = unaff_XMM7_Dd;
        *(undefined4 *)((int64_t)&arg_40h + iVar8) = unaff_XMM8_Da;
        *(undefined4 *)((int64_t)&arg_40h + iVar8 + 4) = unaff_XMM8_Db;
        *(undefined4 *)(&stack0x00000048 + iVar8) = unaff_XMM8_Dc;
        *(undefined4 *)(&stack0x0000004c + iVar8) = unaff_XMM8_Dd;
        *(undefined4 *)((int64_t)&arg_30h + iVar8) = unaff_XMM9_Da;
        *(undefined4 *)((int64_t)&arg_30h + iVar8 + 4) = unaff_XMM9_Db;
        *(undefined4 *)((int64_t)&arg_38h + iVar8) = unaff_XMM9_Dc;
        *(undefined4 *)((int64_t)&arg_38h + iVar8 + 4) = unaff_XMM9_Dd;
        *(undefined4 *)((int64_t)&var_20h + iVar8) = unaff_XMM10_Da;
        *(undefined4 *)((int64_t)&var_20h + iVar8 + 4) = unaff_XMM10_Db;
        *(undefined4 *)((int64_t)&arg_28h + iVar8) = unaff_XMM10_Dc;
        *(undefined4 *)((int64_t)&arg_28h + iVar8 + 4) = unaff_XMM10_Dd;
        *(undefined4 *)((int64_t)auStackX_18 + iVar8 + -8) = unaff_XMM11_Da;
        *(undefined4 *)((int64_t)auStackX_18 + iVar8 + -4) = unaff_XMM11_Db;
        *(undefined4 *)((int64_t)auStackX_18 + iVar8) = unaff_XMM11_Dc;
        *(undefined4 *)((int64_t)auStackX_18 + iVar8 + 4) = unaff_XMM11_Dd;
        do {
            uVar2 = *(uint8_t *)in_RDX;
    // switch table (8 cases) at 0x18020c604
            switch(uVar2) {
            case 8:
                iVar10 = 0x1804ba49c;
                break;
            case 9:
                iVar10 = 0x180620380;
                break;
            case 10:
                iVar10 = 0x180620378;
                break;
            default:
                if ((((uint8_t)(uVar2 + 0x3e) < 0x1e) && (1 < in_R8)) &&
                   ((uint8_t)(*(uint8_t *)((int64_t)in_RDX + 1) + 0x80) < 0x40)) {
                    uVar3 = *(undefined2 *)in_RDX;
                    in_RDX = (undefined4 *)((int64_t)in_RDX + 1);
                    in_R8 = in_R8 - 1;
                    *(undefined2 *)(&stack0x00000000 + iVar8) = uVar3;
                    (&stack0x00000002)[iVar8] = 0;
code_r0x00018020c557:
                    iVar10 = (int64_t)&stack0x00000000 + iVar8;
                    break;
                }
                if (((((uint8_t)(uVar2 + 0x20) < 0x10) && (2 < in_R8)) &&
                    ((uVar9 = *(uint8_t *)((int64_t)in_RDX + 1), (uint8_t)(uVar9 + 0x80) < 0x40 &&
                     ((uint8_t)(*(uint8_t *)((int64_t)in_RDX + 2) + 0x80) < 0x40)))) &&
                   (((uVar2 != 0xe0 || (0x9f < uVar9)) && ((uVar2 != 0xed || (uVar9 < 0xa0)))))) {
                    *(undefined2 *)(&stack0x00000000 + iVar8) = *(undefined2 *)in_RDX;
                    puVar1 = (undefined2 *)((int64_t)in_RDX + 2);
                    in_RDX = (undefined4 *)((int64_t)in_RDX + 2);
                    in_R8 = in_R8 - 2;
                    (&stack0x00000002)[iVar8] = *(uint8_t *)puVar1;
                    (&stack0x00000003)[iVar8] = 0;
                    goto code_r0x00018020c557;
                }
                uVar2 = *(uint8_t *)in_RDX;
                if (((((uint8_t)(uVar2 + 0x10) < 5) && (3 < in_R8)) &&
                    (uVar9 = *(uint8_t *)((int64_t)in_RDX + 1), (uint8_t)(uVar9 + 0x80) < 0x40)) &&
                   (((uint8_t)(*(uint8_t *)((int64_t)in_RDX + 2) + 0x80) < 0x40 &&
                    ((uint8_t)(*(uint8_t *)((int64_t)in_RDX + 3) + 0x80) < 0x40)))) {
                    if (((uVar2 == 0xf0) && (uVar9 < 0x90)) || ((uVar2 == 0xf4 && (0x8f < uVar9))))
                    goto code_r0x00018020c4a3;
                    uVar4 = *in_RDX;
                    in_RDX = (undefined4 *)((int64_t)in_RDX + 3);
                    in_R8 = in_R8 - 3;
                    *(undefined4 *)(&stack0x00000000 + iVar8) = uVar4;
                    (&stack0x00000004)[iVar8] = 0;
                    goto code_r0x00018020c557;
                }
                if (0x5e < (uint8_t)(uVar2 - 0x20)) {
code_r0x00018020c4a3:
                    iVar11 = 0;
                    *(undefined2 *)(&stack0x00000000 + iVar8) = 0x755c;
                    if (iVar7 < 5) {
                        uVar2 = *(uint8_t *)in_RDX;
                        pcVar12 = &stack0x00000002 + iVar8;
                        do {
                            uVar9 = uVar2 >> ((3U - (char)iVar11 & 7) << 2) & 0xf;
                            cVar6 = 'W';
                            if (uVar9 < 10) {
                                cVar6 = '0';
                            }
                            iVar11 = iVar11 + 1;
                            *pcVar12 = cVar6 + uVar9;
                            pcVar12 = pcVar12 + 1;
                        } while (iVar11 < 4);
                    } else {
                        auVar15[3] = (char)uVar2 >> 7;
                        auVar15[7] = auVar15[3];
                        auVar15[6] = auVar15[3];
                        auVar15[5] = auVar15[3];
                        auVar15[4] = auVar15[3];
                        auVar15[2] = auVar15[3];
                        auVar15[1] = uVar2;
                        auVar15[0] = uVar2;
                        auVar15._8_8_ = 0;
                        auVar13 = pshuflw(auVar15, auVar15, 0);
                        auVar15 = pmovzxbd(in_XMM2, ZEXT416(0x4080c));
                        auVar13 = pmovzxbd(ZEXT416(0x4080c), auVar13);
                        auVar13 = vpsrlvd_avx2(auVar13, auVar15);
                        uVar16 = auVar13._0_4_ & 0xf;
                        uVar17 = auVar13._4_4_ & 0xf;
                        uVar18 = auVar13._8_4_ & 0xf;
                        uVar19 = auVar13._12_4_ & 0xf;
                        in_XMM2._0_4_ = -(uint32_t)(((uint32_t)(uVar16 < 10) * 10 | (uVar16 >= 10) * uVar16) == uVar16);
                        in_XMM2._4_4_ = -(uint32_t)(((uint32_t)(uVar17 < 10) * 10 | (uVar17 >= 10) * uVar17) == uVar17);
                        in_XMM2._8_4_ = -(uint32_t)(((uint32_t)(uVar18 < 10) * 10 | (uVar18 >= 10) * uVar18) == uVar18);
                        in_XMM2._12_4_ = -(uint32_t)(((uint32_t)(uVar19 < 10) * 10 | (uVar19 >= 10) * uVar19) == uVar19)
                        ;
                        auVar14._0_4_ = ~in_XMM2._0_4_ & uVar16 + 0x30;
                        auVar14._4_4_ = ~in_XMM2._4_4_ & uVar17 + 0x30;
                        auVar14._8_4_ = ~in_XMM2._8_4_ & uVar18 + 0x30;
                        auVar14._12_4_ = ~in_XMM2._12_4_ & uVar19 + 0x30;
                        auVar13._0_4_ = uVar16 + 0x57 & in_XMM2._0_4_;
                        auVar13._4_4_ = uVar17 + 0x57 & in_XMM2._4_4_;
                        auVar13._8_4_ = uVar18 + 0x57 & in_XMM2._8_4_;
                        auVar13._12_4_ = uVar19 + 0x57 & in_XMM2._12_4_;
                        auVar13 = pshufb(auVar14 | auVar13, auVar5);
                        *(int32_t *)(&stack0x00000002 + iVar8) = auVar13._0_4_;
                    }
                    (&stack0x00000006)[iVar8] = 0;
                    goto code_r0x00018020c557;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c49e;
                func_0x00018020c1a0(in_RCX);
                goto code_r0x00018020c564;
            case 0xc:
                iVar10 = 0x1804ba4a0;
                break;
            case 0xd:
                iVar10 = 0x18062037c;
                break;
            case 0x22:
                iVar10 = 0x180620370;
                break;
            case 0x5c:
                iVar10 = 0x180620374;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c564;
            func_0x00018020c680(in_RCX, iVar10);
code_r0x00018020c564:
            in_RDX = (undefined4 *)((int64_t)in_RDX + 1);
            in_R8 = in_R8 - 1;
        } while (in_R8 != 0);
    }
    if (*(char *)(in_RCX + 4) == '\0') {
        if (*(char *)(in_RCX + 0x10) != '\0') {
            *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c5ba;
            func_0x00018020be10(in_RCX);
        }
        if (*(int64_t *)(in_RCX + 0x38) == *(int64_t *)(in_RCX + 0x40)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c5cf;
            iVar7 = func_0x00018020cd80(in_RCX + 0x28, 0);
            if (iVar7 == 0) {
                *(undefined *)(in_RCX + 4) = 1;
                goto code_r0x00018020c5e9;
            }
        }
        *(undefined *)(*(int64_t *)(in_RCX + 0x40) + *(int64_t *)(in_RCX + 0x30)) = 0x22;
        *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
    }
code_r0x00018020c5e9:
    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c5f6;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_8h + iVar8) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar8));
    return;
}

// ============================================================
// Function: FUN_18020c5ac
// Address: 0x18020c5ac
// Size: 205 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2h
// WARNING: [rz-ghidra] Detected overlap for variable var_6h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h

void fcn.18020c220(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_60h,
                  int64_t arg_70h, int64_t arg_b0h)
{
    undefined2 *puVar1;
    uint8_t uVar2;
    undefined2 uVar3;
    undefined4 uVar4;
    undefined auVar5 [16];
    char cVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    uint8_t uVar9;
    undefined4 *in_RDX;
    int64_t iVar10;
    undefined8 unaff_RSI;
    int32_t iVar11;
    uint64_t in_R8;
    int32_t in_R9D;
    char *pcVar12;
    undefined8 unaff_R15;
    undefined auVar13 [16];
    undefined auVar14 [16];
    undefined in_XMM2 [16];
    undefined auVar15 [16];
    uint32_t uVar16;
    uint32_t uVar17;
    uint32_t uVar18;
    uint32_t uVar19;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    undefined4 unaff_XMM8_Da;
    undefined4 unaff_XMM8_Db;
    undefined4 unaff_XMM8_Dc;
    undefined4 unaff_XMM8_Dd;
    undefined4 unaff_XMM9_Da;
    undefined4 unaff_XMM9_Db;
    undefined4 unaff_XMM9_Dc;
    undefined4 unaff_XMM9_Dd;
    undefined4 unaff_XMM10_Da;
    undefined4 unaff_XMM10_Db;
    undefined4 unaff_XMM10_Dc;
    undefined4 unaff_XMM10_Dd;
    undefined4 unaff_XMM11_Da;
    undefined4 unaff_XMM11_Db;
    undefined4 unaff_XMM11_Dc;
    undefined4 unaff_XMM11_Dd;
    int64_t var_8h;
    int64_t var_10h;
    undefined4 auStackX_18 [2];
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18020c230;
    iVar8 = func_0x00018045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&var_8h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar8);
    if (*(char *)(in_RCX + 4) != '\0') goto code_r0x00018020c5e9;
    cVar6 = *(char *)(in_RCX + 0x10);
    *(undefined8 *)((int64_t)&arg_b0h + iVar8) = unaff_RSI;
    if (cVar6 != '\0') {
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c26b;
        func_0x00018020be10();
    }
    if (*(int64_t *)(in_RCX + 0x38) == *(int64_t *)(in_RCX + 0x40)) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c280;
        iVar7 = func_0x00018020cd80(in_RCX + 0x28, 0);
        if (iVar7 != 0) goto code_r0x00018020c28a;
        *(undefined *)(in_RCX + 4) = 1;
    } else {
code_r0x00018020c28a:
        *(undefined *)(*(int64_t *)(in_RCX + 0x30) + *(int64_t *)(in_RCX + 0x40)) = 0x22;
        *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
    }
    if (in_R9D != 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c2a7;
        in_R8 = func_0x000180498cd0(in_RDX);
    }
    iVar7 = *(int32_t *)0x1806a3990;
    auVar5 = *(undefined (*) [16])0x1804ba4c0;
    if (in_R8 != 0) {
        *(undefined8 *)((int64_t)&arg_70h + iVar8) = unaff_R15;
        *(undefined4 *)((int64_t)&arg_60h + iVar8) = unaff_XMM6_Da;
        *(undefined4 *)((int64_t)&arg_60h + iVar8 + 4) = unaff_XMM6_Db;
        *(undefined4 *)(&stack0x00000068 + iVar8) = unaff_XMM6_Dc;
        *(undefined4 *)(&stack0x0000006c + iVar8) = unaff_XMM6_Dd;
        *(undefined4 *)((int64_t)&arg_50h + iVar8) = unaff_XMM7_Da;
        *(undefined4 *)((int64_t)&arg_50h + iVar8 + 4) = unaff_XMM7_Db;
        *(undefined4 *)(&stack0x00000058 + iVar8) = unaff_XMM7_Dc;
        *(undefined4 *)(&stack0x0000005c + iVar8) = unaff_XMM7_Dd;
        *(undefined4 *)((int64_t)&arg_40h + iVar8) = unaff_XMM8_Da;
        *(undefined4 *)((int64_t)&arg_40h + iVar8 + 4) = unaff_XMM8_Db;
        *(undefined4 *)(&stack0x00000048 + iVar8) = unaff_XMM8_Dc;
        *(undefined4 *)(&stack0x0000004c + iVar8) = unaff_XMM8_Dd;
        *(undefined4 *)((int64_t)&arg_30h + iVar8) = unaff_XMM9_Da;
        *(undefined4 *)((int64_t)&arg_30h + iVar8 + 4) = unaff_XMM9_Db;
        *(undefined4 *)((int64_t)&arg_38h + iVar8) = unaff_XMM9_Dc;
        *(undefined4 *)((int64_t)&arg_38h + iVar8 + 4) = unaff_XMM9_Dd;
        *(undefined4 *)((int64_t)&var_20h + iVar8) = unaff_XMM10_Da;
        *(undefined4 *)((int64_t)&var_20h + iVar8 + 4) = unaff_XMM10_Db;
        *(undefined4 *)((int64_t)&arg_28h + iVar8) = unaff_XMM10_Dc;
        *(undefined4 *)((int64_t)&arg_28h + iVar8 + 4) = unaff_XMM10_Dd;
        *(undefined4 *)((int64_t)auStackX_18 + iVar8 + -8) = unaff_XMM11_Da;
        *(undefined4 *)((int64_t)auStackX_18 + iVar8 + -4) = unaff_XMM11_Db;
        *(undefined4 *)((int64_t)auStackX_18 + iVar8) = unaff_XMM11_Dc;
        *(undefined4 *)((int64_t)auStackX_18 + iVar8 + 4) = unaff_XMM11_Dd;
        do {
            uVar2 = *(uint8_t *)in_RDX;
    // switch table (8 cases) at 0x18020c604
            switch(uVar2) {
            case 8:
                iVar10 = 0x1804ba49c;
                break;
            case 9:
                iVar10 = 0x180620380;
                break;
            case 10:
                iVar10 = 0x180620378;
                break;
            default:
                if ((((uint8_t)(uVar2 + 0x3e) < 0x1e) && (1 < in_R8)) &&
                   ((uint8_t)(*(uint8_t *)((int64_t)in_RDX + 1) + 0x80) < 0x40)) {
                    uVar3 = *(undefined2 *)in_RDX;
                    in_RDX = (undefined4 *)((int64_t)in_RDX + 1);
                    in_R8 = in_R8 - 1;
                    *(undefined2 *)(&stack0x00000000 + iVar8) = uVar3;
                    (&stack0x00000002)[iVar8] = 0;
code_r0x00018020c557:
                    iVar10 = (int64_t)&stack0x00000000 + iVar8;
                    break;
                }
                if (((((uint8_t)(uVar2 + 0x20) < 0x10) && (2 < in_R8)) &&
                    ((uVar9 = *(uint8_t *)((int64_t)in_RDX + 1), (uint8_t)(uVar9 + 0x80) < 0x40 &&
                     ((uint8_t)(*(uint8_t *)((int64_t)in_RDX + 2) + 0x80) < 0x40)))) &&
                   (((uVar2 != 0xe0 || (0x9f < uVar9)) && ((uVar2 != 0xed || (uVar9 < 0xa0)))))) {
                    *(undefined2 *)(&stack0x00000000 + iVar8) = *(undefined2 *)in_RDX;
                    puVar1 = (undefined2 *)((int64_t)in_RDX + 2);
                    in_RDX = (undefined4 *)((int64_t)in_RDX + 2);
                    in_R8 = in_R8 - 2;
                    (&stack0x00000002)[iVar8] = *(uint8_t *)puVar1;
                    (&stack0x00000003)[iVar8] = 0;
                    goto code_r0x00018020c557;
                }
                uVar2 = *(uint8_t *)in_RDX;
                if (((((uint8_t)(uVar2 + 0x10) < 5) && (3 < in_R8)) &&
                    (uVar9 = *(uint8_t *)((int64_t)in_RDX + 1), (uint8_t)(uVar9 + 0x80) < 0x40)) &&
                   (((uint8_t)(*(uint8_t *)((int64_t)in_RDX + 2) + 0x80) < 0x40 &&
                    ((uint8_t)(*(uint8_t *)((int64_t)in_RDX + 3) + 0x80) < 0x40)))) {
                    if (((uVar2 == 0xf0) && (uVar9 < 0x90)) || ((uVar2 == 0xf4 && (0x8f < uVar9))))
                    goto code_r0x00018020c4a3;
                    uVar4 = *in_RDX;
                    in_RDX = (undefined4 *)((int64_t)in_RDX + 3);
                    in_R8 = in_R8 - 3;
                    *(undefined4 *)(&stack0x00000000 + iVar8) = uVar4;
                    (&stack0x00000004)[iVar8] = 0;
                    goto code_r0x00018020c557;
                }
                if (0x5e < (uint8_t)(uVar2 - 0x20)) {
code_r0x00018020c4a3:
                    iVar11 = 0;
                    *(undefined2 *)(&stack0x00000000 + iVar8) = 0x755c;
                    if (iVar7 < 5) {
                        uVar2 = *(uint8_t *)in_RDX;
                        pcVar12 = &stack0x00000002 + iVar8;
                        do {
                            uVar9 = uVar2 >> ((3U - (char)iVar11 & 7) << 2) & 0xf;
                            cVar6 = 'W';
                            if (uVar9 < 10) {
                                cVar6 = '0';
                            }
                            iVar11 = iVar11 + 1;
                            *pcVar12 = cVar6 + uVar9;
                            pcVar12 = pcVar12 + 1;
                        } while (iVar11 < 4);
                    } else {
                        auVar15[3] = (char)uVar2 >> 7;
                        auVar15[7] = auVar15[3];
                        auVar15[6] = auVar15[3];
                        auVar15[5] = auVar15[3];
                        auVar15[4] = auVar15[3];
                        auVar15[2] = auVar15[3];
                        auVar15[1] = uVar2;
                        auVar15[0] = uVar2;
                        auVar15._8_8_ = 0;
                        auVar13 = pshuflw(auVar15, auVar15, 0);
                        auVar15 = pmovzxbd(in_XMM2, ZEXT416(0x4080c));
                        auVar13 = pmovzxbd(ZEXT416(0x4080c), auVar13);
                        auVar13 = vpsrlvd_avx2(auVar13, auVar15);
                        uVar16 = auVar13._0_4_ & 0xf;
                        uVar17 = auVar13._4_4_ & 0xf;
                        uVar18 = auVar13._8_4_ & 0xf;
                        uVar19 = auVar13._12_4_ & 0xf;
                        in_XMM2._0_4_ = -(uint32_t)(((uint32_t)(uVar16 < 10) * 10 | (uVar16 >= 10) * uVar16) == uVar16);
                        in_XMM2._4_4_ = -(uint32_t)(((uint32_t)(uVar17 < 10) * 10 | (uVar17 >= 10) * uVar17) == uVar17);
                        in_XMM2._8_4_ = -(uint32_t)(((uint32_t)(uVar18 < 10) * 10 | (uVar18 >= 10) * uVar18) == uVar18);
                        in_XMM2._12_4_ = -(uint32_t)(((uint32_t)(uVar19 < 10) * 10 | (uVar19 >= 10) * uVar19) == uVar19)
                        ;
                        auVar14._0_4_ = ~in_XMM2._0_4_ & uVar16 + 0x30;
                        auVar14._4_4_ = ~in_XMM2._4_4_ & uVar17 + 0x30;
                        auVar14._8_4_ = ~in_XMM2._8_4_ & uVar18 + 0x30;
                        auVar14._12_4_ = ~in_XMM2._12_4_ & uVar19 + 0x30;
                        auVar13._0_4_ = uVar16 + 0x57 & in_XMM2._0_4_;
                        auVar13._4_4_ = uVar17 + 0x57 & in_XMM2._4_4_;
                        auVar13._8_4_ = uVar18 + 0x57 & in_XMM2._8_4_;
                        auVar13._12_4_ = uVar19 + 0x57 & in_XMM2._12_4_;
                        auVar13 = pshufb(auVar14 | auVar13, auVar5);
                        *(int32_t *)(&stack0x00000002 + iVar8) = auVar13._0_4_;
                    }
                    (&stack0x00000006)[iVar8] = 0;
                    goto code_r0x00018020c557;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c49e;
                func_0x00018020c1a0(in_RCX);
                goto code_r0x00018020c564;
            case 0xc:
                iVar10 = 0x1804ba4a0;
                break;
            case 0xd:
                iVar10 = 0x18062037c;
                break;
            case 0x22:
                iVar10 = 0x180620370;
                break;
            case 0x5c:
                iVar10 = 0x180620374;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c564;
            func_0x00018020c680(in_RCX, iVar10);
code_r0x00018020c564:
            in_RDX = (undefined4 *)((int64_t)in_RDX + 1);
            in_R8 = in_R8 - 1;
        } while (in_R8 != 0);
    }
    if (*(char *)(in_RCX + 4) == '\0') {
        if (*(char *)(in_RCX + 0x10) != '\0') {
            *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c5ba;
            func_0x00018020be10(in_RCX);
        }
        if (*(int64_t *)(in_RCX + 0x38) == *(int64_t *)(in_RCX + 0x40)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c5cf;
            iVar7 = func_0x00018020cd80(in_RCX + 0x28, 0);
            if (iVar7 == 0) {
                *(undefined *)(in_RCX + 4) = 1;
                goto code_r0x00018020c5e9;
            }
        }
        *(undefined *)(*(int64_t *)(in_RCX + 0x40) + *(int64_t *)(in_RCX + 0x30)) = 0x22;
        *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
    }
code_r0x00018020c5e9:
    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18020c5f6;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_8h + iVar8) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar8));
    return;
}

// ============================================================
// Function: FUN_18020c680
// Address: 0x18020c680
// Size: 37 bytes
// ============================================================
void fcn.18020c680(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_70h, int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    char *in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar5;
    char cVar6;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar7;
    undefined8 unaff_R15;
    int64_t var_10h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18020c68e;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    if (*(char *)(in_RCX + 4) == '\0') {
        cVar6 = *(char *)(in_RCX + 0x10);
        *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBP;
        if (cVar6 != '\0') {
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18020c6b1;
            func_0x00018020be10();
        }
        cVar6 = *in_RDX;
        if (cVar6 != '\0') {
            *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RSI;
            *(undefined8 *)((int64_t)&var_10h + iVar4) = unaff_R15;
            do {
                uVar7 = *(uint64_t *)(in_RCX + 0x40);
                in_RDX = in_RDX + 1;
                if (*(uint64_t *)(in_RCX + 0x38) == uVar7) {
                    *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
                    uVar5 = 0;
                    if (uVar7 != 0) {
                        do {
                            iVar1 = *(int64_t *)(in_RCX + 0x30);
                            uVar2 = *(undefined8 *)(in_RCX + 0x28);
                            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18020c717;
                            iVar3 = func_0x00018021b300(uVar2, iVar1 + uVar5, uVar7 - uVar5, (int64_t)&arg_30h + iVar4);
                            uVar7 = *(uint64_t *)(in_RCX + 0x40);
                            if (iVar3 == 0) {
                                iVar1 = *(int64_t *)(in_RCX + 0x30);
                                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18020c75a;
                                func_0x000180498030(iVar1, iVar1 + uVar5, uVar7 - uVar5);
                                *(undefined8 *)(in_RCX + 0x40) = 0;
                                *(undefined *)(in_RCX + 4) = 1;
                                return;
                            }
                            uVar5 = uVar5 + *(int64_t *)((int64_t)&arg_30h + iVar4);
                        } while (uVar5 < uVar7);
                    }
                    *(undefined8 *)(in_RCX + 0x40) = 0;
                    uVar7 = 0;
                }
                *(char *)(uVar7 + *(int64_t *)(in_RCX + 0x30)) = cVar6;
                *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
                cVar6 = *in_RDX;
            } while (cVar6 != '\0');
        }
    }
    return;
}

// ============================================================
// Function: FUN_18020c6a5
// Address: 0x18020c6a5
// Size: 25 bytes
// ============================================================
void fcn.18020c680(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_70h, int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    char *in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar5;
    char cVar6;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar7;
    undefined8 unaff_R15;
    int64_t var_10h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18020c68e;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    if (*(char *)(in_RCX + 4) == '\0') {
        cVar6 = *(char *)(in_RCX + 0x10);
        *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBP;
        if (cVar6 != '\0') {
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18020c6b1;
            func_0x00018020be10();
        }
        cVar6 = *in_RDX;
        if (cVar6 != '\0') {
            *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RSI;
            *(undefined8 *)((int64_t)&var_10h + iVar4) = unaff_R15;
            do {
                uVar7 = *(uint64_t *)(in_RCX + 0x40);
                in_RDX = in_RDX + 1;
                if (*(uint64_t *)(in_RCX + 0x38) == uVar7) {
                    *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
                    uVar5 = 0;
                    if (uVar7 != 0) {
                        do {
                            iVar1 = *(int64_t *)(in_RCX + 0x30);
                            uVar2 = *(undefined8 *)(in_RCX + 0x28);
                            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18020c717;
                            iVar3 = func_0x00018021b300(uVar2, iVar1 + uVar5, uVar7 - uVar5, (int64_t)&arg_30h + iVar4);
                            uVar7 = *(uint64_t *)(in_RCX + 0x40);
                            if (iVar3 == 0) {
                                iVar1 = *(int64_t *)(in_RCX + 0x30);
                                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18020c75a;
                                func_0x000180498030(iVar1, iVar1 + uVar5, uVar7 - uVar5);
                                *(undefined8 *)(in_RCX + 0x40) = 0;
                                *(undefined *)(in_RCX + 4) = 1;
                                return;
                            }
                            uVar5 = uVar5 + *(int64_t *)((int64_t)&arg_30h + iVar4);
                        } while (uVar5 < uVar7);
                    }
                    *(undefined8 *)(in_RCX + 0x40) = 0;
                    uVar7 = 0;
                }
                *(char *)(uVar7 + *(int64_t *)(in_RCX + 0x30)) = cVar6;
                *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
                cVar6 = *in_RDX;
            } while (cVar6 != '\0');
        }
    }
    return;
}

// ============================================================
// Function: FUN_18020c6be
// Address: 0x18020c6be
// Size: 179 bytes
// ============================================================
void fcn.18020c680(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_70h, int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    char *in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar5;
    char cVar6;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar7;
    undefined8 unaff_R15;
    int64_t var_10h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18020c68e;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    if (*(char *)(in_RCX + 4) == '\0') {
        cVar6 = *(char *)(in_RCX + 0x10);
        *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBP;
        if (cVar6 != '\0') {
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18020c6b1;
            func_0x00018020be10();
        }
        cVar6 = *in_RDX;
        if (cVar6 != '\0') {
            *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RSI;
            *(undefined8 *)((int64_t)&var_10h + iVar4) = unaff_R15;
            do {
                uVar7 = *(uint64_t *)(in_RCX + 0x40);
                in_RDX = in_RDX + 1;
                if (*(uint64_t *)(in_RCX + 0x38) == uVar7) {
                    *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
                    uVar5 = 0;
                    if (uVar7 != 0) {
                        do {
                            iVar1 = *(int64_t *)(in_RCX + 0x30);
                            uVar2 = *(undefined8 *)(in_RCX + 0x28);
                            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18020c717;
                            iVar3 = func_0x00018021b300(uVar2, iVar1 + uVar5, uVar7 - uVar5, (int64_t)&arg_30h + iVar4);
                            uVar7 = *(uint64_t *)(in_RCX + 0x40);
                            if (iVar3 == 0) {
                                iVar1 = *(int64_t *)(in_RCX + 0x30);
                                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18020c75a;
                                func_0x000180498030(iVar1, iVar1 + uVar5, uVar7 - uVar5);
                                *(undefined8 *)(in_RCX + 0x40) = 0;
                                *(undefined *)(in_RCX + 4) = 1;
                                return;
                            }
                            uVar5 = uVar5 + *(int64_t *)((int64_t)&arg_30h + iVar4);
                        } while (uVar5 < uVar7);
                    }
                    *(undefined8 *)(in_RCX + 0x40) = 0;
                    uVar7 = 0;
                }
                *(char *)(uVar7 + *(int64_t *)(in_RCX + 0x30)) = cVar6;
                *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
                cVar6 = *in_RDX;
            } while (cVar6 != '\0');
        }
    }
    return;
}

// ============================================================
// Function: FUN_18020c771
// Address: 0x18020c771
// Size: 5 bytes
// ============================================================
void fcn.18020c680(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_70h, int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    char *in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar5;
    char cVar6;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar7;
    undefined8 unaff_R15;
    int64_t var_10h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18020c68e;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    if (*(char *)(in_RCX + 4) == '\0') {
        cVar6 = *(char *)(in_RCX + 0x10);
        *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBP;
        if (cVar6 != '\0') {
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18020c6b1;
            func_0x00018020be10();
        }
        cVar6 = *in_RDX;
        if (cVar6 != '\0') {
            *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RSI;
            *(undefined8 *)((int64_t)&var_10h + iVar4) = unaff_R15;
            do {
                uVar7 = *(uint64_t *)(in_RCX + 0x40);
                in_RDX = in_RDX + 1;
                if (*(uint64_t *)(in_RCX + 0x38) == uVar7) {
                    *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
                    uVar5 = 0;
                    if (uVar7 != 0) {
                        do {
                            iVar1 = *(int64_t *)(in_RCX + 0x30);
                            uVar2 = *(undefined8 *)(in_RCX + 0x28);
                            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18020c717;
                            iVar3 = func_0x00018021b300(uVar2, iVar1 + uVar5, uVar7 - uVar5, (int64_t)&arg_30h + iVar4);
                            uVar7 = *(uint64_t *)(in_RCX + 0x40);
                            if (iVar3 == 0) {
                                iVar1 = *(int64_t *)(in_RCX + 0x30);
                                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18020c75a;
                                func_0x000180498030(iVar1, iVar1 + uVar5, uVar7 - uVar5);
                                *(undefined8 *)(in_RCX + 0x40) = 0;
                                *(undefined *)(in_RCX + 4) = 1;
                                return;
                            }
                            uVar5 = uVar5 + *(int64_t *)((int64_t)&arg_30h + iVar4);
                        } while (uVar5 < uVar7);
                    }
                    *(undefined8 *)(in_RCX + 0x40) = 0;
                    uVar7 = 0;
                }
                *(char *)(uVar7 + *(int64_t *)(in_RCX + 0x30)) = cVar6;
                *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
                cVar6 = *in_RDX;
            } while (cVar6 != '\0');
        }
    }
    return;
}

// ============================================================
// Function: FUN_18020c776
// Address: 0x18020c776
// Size: 8 bytes
// ============================================================
void fcn.18020c680(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_70h, int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    char *in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar5;
    char cVar6;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar7;
    undefined8 unaff_R15;
    int64_t var_10h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18020c68e;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    if (*(char *)(in_RCX + 4) == '\0') {
        cVar6 = *(char *)(in_RCX + 0x10);
        *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBP;
        if (cVar6 != '\0') {
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18020c6b1;
            func_0x00018020be10();
        }
        cVar6 = *in_RDX;
        if (cVar6 != '\0') {
            *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RSI;
            *(undefined8 *)((int64_t)&var_10h + iVar4) = unaff_R15;
            do {
                uVar7 = *(uint64_t *)(in_RCX + 0x40);
                in_RDX = in_RDX + 1;
                if (*(uint64_t *)(in_RCX + 0x38) == uVar7) {
                    *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
                    uVar5 = 0;
                    if (uVar7 != 0) {
                        do {
                            iVar1 = *(int64_t *)(in_RCX + 0x30);
                            uVar2 = *(undefined8 *)(in_RCX + 0x28);
                            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18020c717;
                            iVar3 = func_0x00018021b300(uVar2, iVar1 + uVar5, uVar7 - uVar5, (int64_t)&arg_30h + iVar4);
                            uVar7 = *(uint64_t *)(in_RCX + 0x40);
                            if (iVar3 == 0) {
                                iVar1 = *(int64_t *)(in_RCX + 0x30);
                                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18020c75a;
                                func_0x000180498030(iVar1, iVar1 + uVar5, uVar7 - uVar5);
                                *(undefined8 *)(in_RCX + 0x40) = 0;
                                *(undefined *)(in_RCX + 4) = 1;
                                return;
                            }
                            uVar5 = uVar5 + *(int64_t *)((int64_t)&arg_30h + iVar4);
                        } while (uVar5 < uVar7);
                    }
                    *(undefined8 *)(in_RCX + 0x40) = 0;
                    uVar7 = 0;
                }
                *(char *)(uVar7 + *(int64_t *)(in_RCX + 0x30)) = cVar6;
                *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
                cVar6 = *in_RDX;
            } while (cVar6 != '\0');
        }
    }
    return;
}

// ============================================================
// Function: FUN_18020c780
// Address: 0x18020c780
// Size: 41 bytes
// ============================================================
void fcn.18020c780(int64_t param_1)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020c78c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020c79f;
    fcn.18020bbc0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                  *(int64_t *)(&stack0x00000028 + iVar1));
    *(undefined *)(param_1 + 6) = 1;
    return;
}

// ============================================================
// Function: FUN_18020c7b0
// Address: 0x18020c7b0
// Size: 30 bytes
// ============================================================
void fcn.18020c7b0(int64_t arg_30h, int64_t arg_50h)
{
    uint8_t uVar1;
    int64_t iVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint8_t uVar7;
    uint8_t *in_RCX;
    uint32_t uVar8;
    int64_t iVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    uint8_t uVar10;
    uint64_t uVar11;
    undefined8 auStackX_18 [2];
    
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar11 = 0x5d;
    uVar8 = 1;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar6 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar6) = 0x18020bcd0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar1 = in_RCX[0x10];
    if (in_RCX[4] != 0) {
        return;
    }
    uVar10 = in_RCX[5];
    iVar2 = *(int64_t *)(in_RCX + 0x48);
    in_RCX[0x10] = 0;
    if (uVar10 == 0) {
        if (iVar2 != 0) {
            uVar7 = 7;
            iVar9 = iVar2 + -1;
            goto code_r0x00018020bd1e;
        }
        uVar3 = 0xffffffff;
    } else {
        uVar7 = uVar10 - 1;
        iVar9 = iVar2;
code_r0x00018020bd1e:
        uVar3 = (uint32_t)(((uint8_t)(1 << (uVar7 & 0x1f)) & *(uint8_t *)(iVar9 + *(int64_t *)(in_RCX + 8))) != 0);
    }
    if (((uVar3 == uVar8) && ((uVar8 != 0 || (in_RCX[6] != 1)))) && ((iVar2 != 0 || (uVar10 != 0)))) {
        if (uVar10 == 0) {
            uVar10 = 7;
            *(int64_t *)(in_RCX + 0x48) = iVar2 + -1;
        } else {
            uVar10 = uVar10 - 1;
        }
        in_RCX[5] = uVar10;
        if (uVar1 == 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar6) = 0x18020bd83;
            func_0x00018020be10(in_RCX);
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar6) = 0x18020bd8f;
        func_0x00018020c1a0(in_RCX, uVar11 & 0xff);
        if ((in_RCX[5] != 0) || (*(int64_t *)(in_RCX + 0x48) != 0)) {
            in_RCX[6] = 2;
            return;
        }
        in_RCX[6] = 2;
        if ((*in_RCX & 1) == 0) {
            return;
        }
        if (in_RCX[4] != 0) {
            return;
        }
        if (in_RCX[0x10] != 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar6) = 0x18020bdb9;
            func_0x00018020be10(in_RCX);
        }
        if (*(int64_t *)(in_RCX + 0x38) == *(int64_t *)(in_RCX + 0x40)) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar6) = 0x18020bdce;
            iVar4 = func_0x00018020cd80(in_RCX + 0x28, 0);
            if (iVar4 == 0) goto code_r0x00018020bdfc;
        }
        *(undefined *)(*(int64_t *)(in_RCX + 0x30) + *(int64_t *)(in_RCX + 0x40)) = 10;
        *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
        return;
    }
code_r0x00018020bdfc:
    in_RCX[4] = 1;
    return;
}

// ============================================================
// Function: FUN_18020c7d0
// Address: 0x18020c7d0
// Size: 120 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18020c7d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h)
{
    uint8_t uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint8_t *in_RCX;
    undefined uVar6;
    undefined8 unaff_RSI;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020c7e0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020c7ee;
    iVar3 = func_0x00018020bfa0();
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020c80f;
        fcn.18020c680(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + 0x10), *(int64_t *)((int64_t)&arg_28h + iVar5), 
                      *(int64_t *)((int64_t)&arg_30h + iVar5), *(int64_t *)(&stack0x00000038 + iVar5), 
                      *(int64_t *)(&stack0x00000060 + iVar5), *(int64_t *)(&stack0x00000068 + iVar5));
        if ((in_RCX[5] == 0) && (*(int64_t *)(in_RCX + 0x48) == 0)) {
            in_RCX[6] = 2;
            if ((*in_RCX & 1) != 0) {
                uVar6 = 10;
                uVar2 = *(undefined8 *)((int64_t)&arg_28h + iVar5);
                uVar7 = *(undefined8 *)((int64_t)aiStackX_10 + iVar5 + 8);
                *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RSI;
                *(undefined8 *)((int64_t)aiStackX_10 + iVar5 + 8) = uVar7;
                *(undefined8 *)((int64_t)aiStackX_10 + iVar5) = 0x18020c1b0;
                iVar4 = fcn.18045a350();
                iVar4 = -iVar4;
                if (in_RCX[4] == 0) {
                    uVar1 = in_RCX[0x10];
                    *(undefined8 *)((int64_t)&arg_48h + iVar4 + iVar5) = uVar2;
                    if (uVar1 != 0) {
                        *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + iVar5) = 0x18020c1cf;
                        func_0x00018020be10();
                    }
                    if (*(int64_t *)(in_RCX + 0x38) == *(int64_t *)(in_RCX + 0x40)) {
                        *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + iVar5) = 0x18020c1e4;
                        iVar3 = func_0x00018020cd80(in_RCX + 0x28, 0);
                        if (iVar3 == 0) {
                            in_RCX[4] = 1;
                            return;
                        }
                    }
                    *(undefined *)(*(int64_t *)(in_RCX + 0x30) + *(int64_t *)(in_RCX + 0x40)) = uVar6;
                    *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
                }
                return;
            }
        } else {
            in_RCX[6] = 2;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18020c850
// Address: 0x18020c850
// Size: 30 bytes
// ============================================================
undefined8
fcn.18020c850(int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_80h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 *puVar6;
    int32_t iVar7;
    undefined8 unaff_RBX;
    uint64_t uVar8;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar9;
    undefined8 auStackX_18 [2];
    
    iVar5 = fcn.18045a350();
    iVar3 = -iVar5;
    puVar6 = (undefined8 *)(in_RCX + iVar5);
    iVar7 = 1;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x18020cd95;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar9 = puVar6[3];
    uVar8 = 0;
    *(undefined8 *)((int64_t)&arg_50h + iVar5 + iVar3) = 0;
    if (uVar9 != 0) {
        do {
            iVar1 = puVar6[1];
            uVar2 = *puVar6;
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar3) = 0x18020cdc8;
            iVar4 = func_0x00018021b300(uVar2, iVar1 + uVar8, uVar9 - uVar8, (int64_t)&arg_50h + iVar5 + iVar3);
            uVar9 = puVar6[3];
            if (iVar4 == 0) {
                iVar1 = puVar6[1];
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar3) = 0x18020ce1e;
                func_0x000180498030(iVar1, iVar1 + uVar8, uVar9 - uVar8);
                puVar6[3] = 0;
                return 0;
            }
            uVar8 = uVar8 + *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar3);
        } while (uVar8 < uVar9);
    }
    puVar6[3] = 0;
    if (iVar7 != 0) {
        uVar2 = *puVar6;
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar3) = 0x18020cdf9;
        func_0x000180219d10(uVar2, 0xb, 0, 0);
    }
    return 1;
}

// ============================================================
// Function: FUN_18020c870
// Address: 0x18020c870
// Size: 128 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined4 fcn.18020c870(int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020c885;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020c899;
    uVar3 = fcn.18020cd80(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                          *(int64_t *)(&stack0x00000050 + iVar4), *(int64_t *)(&stack0x00000070 + iVar4));
    uVar1 = *(undefined8 *)(in_RCX + 0x30);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020c8b1;
    fcn.180224990(uVar1, 0x1804ba480, 0x24);
    *(undefined8 *)(in_RCX + 0x30) = 0;
    *(undefined8 *)(in_RCX + 0x38) = 0;
    iVar2 = *(int64_t *)(in_RCX + 8);
    if (iVar2 != in_RCX + 0x11) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020c8da;
        fcn.180224990(iVar2, 0x1804ba480, 0xfe);
    }
    *(undefined8 *)(in_RCX + 8) = 0;
    return uVar3;
}

// ============================================================
// Function: FUN_18020c8f0
// Address: 0x18020c8f0
// Size: 146 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18020c8f0(int64_t arg_28h)
{
    int64_t iVar1;
    undefined4 *in_RCX;
    undefined8 in_RDX;
    undefined4 in_R8D;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020c900;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined (*) [16])((int64_t)in_RCX + 5) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)in_RCX + 0x15) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)in_RCX + 0x25) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)in_RCX + 0x35) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)in_RCX + 0x45) = ZEXT816(0);
    *(undefined2 *)((int64_t)in_RCX + 0x55) = 0;
    *(undefined *)((int64_t)in_RCX + 0x57) = 0;
    *in_RCX = in_R8D;
    *(undefined *)(in_RCX + 1) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020c946;
    iVar1 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    *(int64_t *)(in_RCX + 0xc) = iVar1;
    if (iVar1 != 0) {
        *(undefined8 *)(in_RCX + 0x10) = 0;
        *(undefined8 *)(in_RCX + 0xe) = 0x1000;
        *(undefined8 *)(in_RCX + 10) = in_RDX;
        *(undefined *)((int64_t)in_RCX + 6) = 2;
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_18020c990
// Address: 0x18020c990
// Size: 200 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2h
// WARNING: [rz-ghidra] Detected overlap for variable var_6h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h

void fcn.18020c990(int64_t arg_28h)
{
    int64_t iVar1;
    uint8_t uVar2;
    uint8_t *in_RCX;
    int64_t iVar3;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020c9a0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (in_RCX[4] != 0) {
        return;
    }
    iVar3 = *(int64_t *)(in_RCX + 0x48);
    if (in_RCX[5] == 0) {
        if (iVar3 == 0) goto code_r0x00018020c9e5;
        iVar3 = iVar3 + -1;
        uVar2 = 7;
    } else {
        uVar2 = in_RCX[5] - 1;
    }
    if (((uint8_t)(1 << (uVar2 & 0x1f)) & *(uint8_t *)(iVar3 + *(int64_t *)(in_RCX + 8))) == 0) {
        if (in_RCX[6] == 2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020ca04;
            func_0x00018020c1a0(in_RCX, 0x2c);
            in_RCX[6] = 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020ca10;
        func_0x00018020be10(in_RCX);
        if (in_RCX[6] == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020ca2a;
            fcn.18020c220(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                          *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000050 + iVar1), 
                          *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x000000a0 + iVar1));
            if (in_RCX[4] != 0) {
                return;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020ca3a;
            func_0x00018020c1a0(in_RCX, 0x3a);
            if ((*in_RCX & 2) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020ca49;
                func_0x00018020c1a0(in_RCX, 0x20);
            }
            in_RCX[6] = 1;
            return;
        }
    }
code_r0x00018020c9e5:
    in_RCX[4] = 1;
    return;
}

// ============================================================
// Function: FUN_18020ca60
// Address: 0x18020ca60
// Size: 38 bytes
// ============================================================
void fcn.18020ca60(int64_t param_1)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020ca6c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020ca7c;
    fcn.18020bbc0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                  *(int64_t *)(&stack0x00000028 + iVar1));
    *(undefined *)(param_1 + 6) = 0;
    return;
}

// ============================================================
// Function: FUN_18020ca90
// Address: 0x18020ca90
// Size: 27 bytes
// ============================================================
void fcn.18020ca90(uint8_t *param_1)
{
    uint8_t uVar1;
    int64_t iVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint8_t uVar7;
    uint32_t uVar8;
    int64_t iVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    uint8_t uVar10;
    uint64_t uVar11;
    undefined8 auStackX_18 [2];
    
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar11 = 0x7d;
    uVar8 = 0;
    *(undefined8 *)(&stack0x00000030 + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar6 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar6) = 0x18020bcd0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar1 = param_1[0x10];
    if (param_1[4] != 0) {
        return;
    }
    uVar10 = param_1[5];
    iVar2 = *(int64_t *)(param_1 + 0x48);
    param_1[0x10] = 0;
    if (uVar10 == 0) {
        if (iVar2 != 0) {
            uVar7 = 7;
            iVar9 = iVar2 + -1;
            goto code_r0x00018020bd1e;
        }
        uVar3 = 0xffffffff;
    } else {
        uVar7 = uVar10 - 1;
        iVar9 = iVar2;
code_r0x00018020bd1e:
        uVar3 = (uint32_t)(((uint8_t)(1 << (uVar7 & 0x1f)) & *(uint8_t *)(iVar9 + *(int64_t *)(param_1 + 8))) != 0);
    }
    if (((uVar3 == uVar8) && ((uVar8 != 0 || (param_1[6] != 1)))) && ((iVar2 != 0 || (uVar10 != 0)))) {
        if (uVar10 == 0) {
            uVar10 = 7;
            *(int64_t *)(param_1 + 0x48) = iVar2 + -1;
        } else {
            uVar10 = uVar10 - 1;
        }
        param_1[5] = uVar10;
        if (uVar1 == 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar6) = 0x18020bd83;
            func_0x00018020be10(param_1);
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar6) = 0x18020bd8f;
        func_0x00018020c1a0(param_1, uVar11 & 0xff);
        if ((param_1[5] != 0) || (*(int64_t *)(param_1 + 0x48) != 0)) {
            param_1[6] = 2;
            return;
        }
        param_1[6] = 2;
        if ((*param_1 & 1) == 0) {
            return;
        }
        if (param_1[4] != 0) {
            return;
        }
        if (param_1[0x10] != 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar6) = 0x18020bdb9;
            func_0x00018020be10(param_1);
        }
        if (*(int64_t *)(param_1 + 0x38) == *(int64_t *)(param_1 + 0x40)) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar6) = 0x18020bdce;
            iVar4 = fcn.18020cd80(*(int64_t *)(&stack0x00000050 + iVar5 + iVar6), 
                                  *(int64_t *)(&stack0x00000058 + iVar5 + iVar6), 
                                  *(int64_t *)(&stack0x00000068 + iVar5 + iVar6), 
                                  *(int64_t *)(&stack0x00000070 + iVar5 + iVar6), 
                                  *(int64_t *)(&stack0x00000078 + iVar5 + iVar6), 
                                  *(int64_t *)(&stack0x00000098 + iVar5 + iVar6));
            if (iVar4 == 0) goto code_r0x00018020bdfc;
        }
        *(undefined *)(*(int64_t *)(param_1 + 0x30) + *(int64_t *)(param_1 + 0x40)) = 10;
        *(int64_t *)(param_1 + 0x40) = *(int64_t *)(param_1 + 0x40) + 1;
        return;
    }
code_r0x00018020bdfc:
    param_1[4] = 1;
    return;
}

// ============================================================
// Function: FUN_18020cac0
// Address: 0x18020cac0
// Size: 111 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2h
// WARNING: [rz-ghidra] Detected overlap for variable var_6h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h

void fcn.18020cac0(int64_t arg_28h)
{
    uint8_t uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint8_t *in_RCX;
    undefined uVar6;
    undefined8 unaff_RSI;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020cad0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020cade;
    iVar3 = func_0x00018020bfa0();
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020caf6;
        fcn.18020c220(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8), *(int64_t *)((int64_t)aiStackX_10 + iVar5 + 0x10)
                      , *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                      *(int64_t *)(&stack0x00000040 + iVar5), *(int64_t *)(&stack0x00000050 + iVar5), 
                      *(int64_t *)(&stack0x00000060 + iVar5), *(int64_t *)(&stack0x000000a0 + iVar5));
        if ((in_RCX[5] == 0) && (*(int64_t *)(in_RCX + 0x48) == 0)) {
            in_RCX[6] = 2;
            if ((*in_RCX & 1) != 0) {
                uVar6 = 10;
                uVar2 = *(undefined8 *)((int64_t)&arg_28h + iVar5);
                uVar7 = *(undefined8 *)((int64_t)aiStackX_10 + iVar5 + 8);
                *(undefined8 *)(&stack0x00000030 + iVar5) = unaff_RSI;
                *(undefined8 *)((int64_t)aiStackX_10 + iVar5 + 8) = uVar7;
                *(undefined8 *)((int64_t)aiStackX_10 + iVar5) = 0x18020c1b0;
                iVar4 = fcn.18045a350();
                iVar4 = -iVar4;
                if (in_RCX[4] == 0) {
                    uVar1 = in_RCX[0x10];
                    *(undefined8 *)(&stack0x00000048 + iVar4 + iVar5) = uVar2;
                    if (uVar1 != 0) {
                        *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + iVar5) = 0x18020c1cf;
                        func_0x00018020be10();
                    }
                    if (*(int64_t *)(in_RCX + 0x38) == *(int64_t *)(in_RCX + 0x40)) {
                        *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + iVar5) = 0x18020c1e4;
                        iVar3 = fcn.18020cd80(*(int64_t *)(&stack0x00000048 + iVar4 + iVar5), 
                                              *(int64_t *)(&stack0x00000050 + iVar4 + iVar5), 
                                              *(int64_t *)(&stack0x00000060 + iVar4 + iVar5), 
                                              *(int64_t *)(&stack0x00000068 + iVar4 + iVar5), 
                                              *(int64_t *)(&stack0x00000070 + iVar4 + iVar5), 
                                              *(int64_t *)(&stack0x00000090 + iVar4 + iVar5));
                        if (iVar3 == 0) {
                            in_RCX[4] = 1;
                            return;
                        }
                    }
                    *(undefined *)(*(int64_t *)(in_RCX + 0x30) + *(int64_t *)(in_RCX + 0x40)) = uVar6;
                    *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
                }
                return;
            }
        } else {
            in_RCX[6] = 2;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18020cb30
// Address: 0x18020cb30
// Size: 43 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018020cb63: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018020cb68)
// WARNING: Removing unreachable block (ram,0x00018020cb71)
// WARNING: Removing unreachable block (ram,0x00018020cb90)
// WARNING: Removing unreachable block (ram,0x00018020cba1)
// WARNING: Removing unreachable block (ram,0x00018020cba5)
// WARNING: Removing unreachable block (ram,0x00018020cbae)
// WARNING: Removing unreachable block (ram,0x00018020cbb4)
// WARNING: Removing unreachable block (ram,0x00018020cbbc)
// WARNING: Removing unreachable block (ram,0x00018020cbc6)
// WARNING: Removing unreachable block (ram,0x00018020cbdb)
// WARNING: Removing unreachable block (ram,0x00018020cbd5)
// WARNING: Removing unreachable block (ram,0x00018020cbeb)
// WARNING: Removing unreachable block (ram,0x00018020cbf6)
// WARNING: Removing unreachable block (ram,0x00018020cbfa)
// WARNING: Removing unreachable block (ram,0x00018020cc02)
// WARNING: Removing unreachable block (ram,0x00018020cc08)
// WARNING: Removing unreachable block (ram,0x00018020cc10)
// WARNING: Removing unreachable block (ram,0x00018020cc1a)
// WARNING: Removing unreachable block (ram,0x00018020cc2f)
// WARNING: Removing unreachable block (ram,0x00018020cc29)
// WARNING: Removing unreachable block (ram,0x00018020cc3f)
// WARNING: Removing unreachable block (ram,0x00018020cc4b)
// WARNING: Removing unreachable block (ram,0x00018020cc5a)
// WARNING: Removing unreachable block (ram,0x00018020cc60)
// WARNING: Removing unreachable block (ram,0x00018020cc66)
// WARNING: Removing unreachable block (ram,0x00018020cc6e)
// WARNING: Removing unreachable block (ram,0x00018020cc78)
// WARNING: Removing unreachable block (ram,0x00018020cc8d)
// WARNING: Removing unreachable block (ram,0x00018020cc87)
// WARNING: Removing unreachable block (ram,0x00018020cc9d)
// WARNING: Removing unreachable block (ram,0x00018020cca8)
// WARNING: Removing unreachable block (ram,0x00018020ccca)
// WARNING: Removing unreachable block (ram,0x00018020ccaf)
// WARNING: Removing unreachable block (ram,0x00018020ccb8)

void fcn.18020cb30(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined uVar6;
    undefined8 in_RDX;
    undefined8 unaff_RDI;
    int64_t aiStackX_8 [4];
    undefined8 auStack_30 [3];
    
    auStack_30[2] = 0x18020cb3f;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)auStack_30 + iVar4 + 0x10) = 0x18020cb51;
    iVar2 = func_0x00018020bfa0();
    if (iVar2 == 0) {
        return;
    }
    uVar6 = 0x22;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)auStack_30 + iVar4 + 0x10) = 0x18020cb68;
    *(undefined8 *)(&stack0xfffffffffffffff0 + iVar4) = in_RDX;
    *(undefined8 *)((int64_t)auStack_30 + iVar4 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStack_30 + iVar4) = 0x18020c1b0;
    iVar5 = in_RCX;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(char *)(iVar5 + 4) == '\0') {
        cVar1 = *(char *)(iVar5 + 0x10);
        *(int64_t *)((int64_t)aiStackX_8 + iVar3 + iVar4) = in_RCX;
        if (cVar1 != '\0') {
            *(undefined8 *)((int64_t)auStack_30 + iVar3 + iVar4) = 0x18020c1cf;
            func_0x00018020be10();
        }
        if (*(int64_t *)(iVar5 + 0x38) == *(int64_t *)(iVar5 + 0x40)) {
            *(undefined8 *)((int64_t)auStack_30 + iVar3 + iVar4) = 0x18020c1e4;
            iVar2 = fcn.18020cd80(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + iVar4), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + iVar4 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + iVar4 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3 + iVar4), 
                                  *(int64_t *)(&stack0x00000050 + iVar3 + iVar4));
            if (iVar2 == 0) {
                *(undefined *)(iVar5 + 4) = 1;
                return;
            }
        }
        *(undefined *)(*(int64_t *)(iVar5 + 0x30) + *(int64_t *)(iVar5 + 0x40)) = uVar6;
        *(int64_t *)(iVar5 + 0x40) = *(int64_t *)(iVar5 + 0x40) + 1;
    }
    return;
}

// ============================================================
// Function: FUN_18020cb5b
// Address: 0x18020cb5b
// Size: 22 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018020cb63: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018020cb68)
// WARNING: Removing unreachable block (ram,0x00018020cb71)
// WARNING: Removing unreachable block (ram,0x00018020cb90)
// WARNING: Removing unreachable block (ram,0x00018020cba1)
// WARNING: Removing unreachable block (ram,0x00018020cba5)
// WARNING: Removing unreachable block (ram,0x00018020cbae)
// WARNING: Removing unreachable block (ram,0x00018020cbb4)
// WARNING: Removing unreachable block (ram,0x00018020cbbc)
// WARNING: Removing unreachable block (ram,0x00018020cbc6)
// WARNING: Removing unreachable block (ram,0x00018020cbdb)
// WARNING: Removing unreachable block (ram,0x00018020cbd5)
// WARNING: Removing unreachable block (ram,0x00018020cbeb)
// WARNING: Removing unreachable block (ram,0x00018020cbf6)
// WARNING: Removing unreachable block (ram,0x00018020cbfa)
// WARNING: Removing unreachable block (ram,0x00018020cc02)
// WARNING: Removing unreachable block (ram,0x00018020cc08)
// WARNING: Removing unreachable block (ram,0x00018020cc10)
// WARNING: Removing unreachable block (ram,0x00018020cc1a)
// WARNING: Removing unreachable block (ram,0x00018020cc2f)
// WARNING: Removing unreachable block (ram,0x00018020cc29)
// WARNING: Removing unreachable block (ram,0x00018020cc3f)
// WARNING: Removing unreachable block (ram,0x00018020cc4b)
// WARNING: Removing unreachable block (ram,0x00018020cc5a)
// WARNING: Removing unreachable block (ram,0x00018020cc60)
// WARNING: Removing unreachable block (ram,0x00018020cc66)
// WARNING: Removing unreachable block (ram,0x00018020cc6e)
// WARNING: Removing unreachable block (ram,0x00018020cc78)
// WARNING: Removing unreachable block (ram,0x00018020cc8d)
// WARNING: Removing unreachable block (ram,0x00018020cc87)
// WARNING: Removing unreachable block (ram,0x00018020cc9d)
// WARNING: Removing unreachable block (ram,0x00018020cca8)
// WARNING: Removing unreachable block (ram,0x00018020ccca)
// WARNING: Removing unreachable block (ram,0x00018020ccaf)
// WARNING: Removing unreachable block (ram,0x00018020ccb8)

void fcn.18020cb30(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined uVar6;
    undefined8 in_RDX;
    undefined8 unaff_RDI;
    int64_t aiStackX_8 [4];
    undefined8 auStack_30 [3];
    
    auStack_30[2] = 0x18020cb3f;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)auStack_30 + iVar4 + 0x10) = 0x18020cb51;
    iVar2 = func_0x00018020bfa0();
    if (iVar2 == 0) {
        return;
    }
    uVar6 = 0x22;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)auStack_30 + iVar4 + 0x10) = 0x18020cb68;
    *(undefined8 *)(&stack0xfffffffffffffff0 + iVar4) = in_RDX;
    *(undefined8 *)((int64_t)auStack_30 + iVar4 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStack_30 + iVar4) = 0x18020c1b0;
    iVar5 = in_RCX;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(char *)(iVar5 + 4) == '\0') {
        cVar1 = *(char *)(iVar5 + 0x10);
        *(int64_t *)((int64_t)aiStackX_8 + iVar3 + iVar4) = in_RCX;
        if (cVar1 != '\0') {
            *(undefined8 *)((int64_t)auStack_30 + iVar3 + iVar4) = 0x18020c1cf;
            func_0x00018020be10();
        }
        if (*(int64_t *)(iVar5 + 0x38) == *(int64_t *)(iVar5 + 0x40)) {
            *(undefined8 *)((int64_t)auStack_30 + iVar3 + iVar4) = 0x18020c1e4;
            iVar2 = fcn.18020cd80(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + iVar4), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + iVar4 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + iVar4 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3 + iVar4), 
                                  *(int64_t *)(&stack0x00000050 + iVar3 + iVar4));
            if (iVar2 == 0) {
                *(undefined *)(iVar5 + 4) = 1;
                return;
            }
        }
        *(undefined *)(*(int64_t *)(iVar5 + 0x30) + *(int64_t *)(iVar5 + 0x40)) = uVar6;
        *(int64_t *)(iVar5 + 0x40) = *(int64_t *)(iVar5 + 0x40) + 1;
    }
    return;
}

// ============================================================
// Function: FUN_18020cb71
// Address: 0x18020cb71
// Size: 233 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018020cb63: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018020cb68)
// WARNING: Removing unreachable block (ram,0x00018020cb71)
// WARNING: Removing unreachable block (ram,0x00018020cb90)
// WARNING: Removing unreachable block (ram,0x00018020cba1)
// WARNING: Removing unreachable block (ram,0x00018020cba5)
// WARNING: Removing unreachable block (ram,0x00018020cbae)
// WARNING: Removing unreachable block (ram,0x00018020cbb4)
// WARNING: Removing unreachable block (ram,0x00018020cbbc)
// WARNING: Removing unreachable block (ram,0x00018020cbc6)
// WARNING: Removing unreachable block (ram,0x00018020cbdb)
// WARNING: Removing unreachable block (ram,0x00018020cbd5)
// WARNING: Removing unreachable block (ram,0x00018020cbeb)
// WARNING: Removing unreachable block (ram,0x00018020cbf6)
// WARNING: Removing unreachable block (ram,0x00018020cbfa)
// WARNING: Removing unreachable block (ram,0x00018020cc02)
// WARNING: Removing unreachable block (ram,0x00018020cc08)
// WARNING: Removing unreachable block (ram,0x00018020cc10)
// WARNING: Removing unreachable block (ram,0x00018020cc1a)
// WARNING: Removing unreachable block (ram,0x00018020cc2f)
// WARNING: Removing unreachable block (ram,0x00018020cc29)
// WARNING: Removing unreachable block (ram,0x00018020cc3f)
// WARNING: Removing unreachable block (ram,0x00018020cc4b)
// WARNING: Removing unreachable block (ram,0x00018020cc5a)
// WARNING: Removing unreachable block (ram,0x00018020cc60)
// WARNING: Removing unreachable block (ram,0x00018020cc66)
// WARNING: Removing unreachable block (ram,0x00018020cc6e)
// WARNING: Removing unreachable block (ram,0x00018020cc78)
// WARNING: Removing unreachable block (ram,0x00018020cc8d)
// WARNING: Removing unreachable block (ram,0x00018020cc87)
// WARNING: Removing unreachable block (ram,0x00018020cc9d)
// WARNING: Removing unreachable block (ram,0x00018020cca8)
// WARNING: Removing unreachable block (ram,0x00018020ccca)
// WARNING: Removing unreachable block (ram,0x00018020ccaf)
// WARNING: Removing unreachable block (ram,0x00018020ccb8)

void fcn.18020cb30(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined uVar6;
    undefined8 in_RDX;
    undefined8 unaff_RDI;
    int64_t aiStackX_8 [4];
    undefined8 auStack_30 [3];
    
    auStack_30[2] = 0x18020cb3f;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)auStack_30 + iVar4 + 0x10) = 0x18020cb51;
    iVar2 = func_0x00018020bfa0();
    if (iVar2 == 0) {
        return;
    }
    uVar6 = 0x22;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)auStack_30 + iVar4 + 0x10) = 0x18020cb68;
    *(undefined8 *)(&stack0xfffffffffffffff0 + iVar4) = in_RDX;
    *(undefined8 *)((int64_t)auStack_30 + iVar4 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStack_30 + iVar4) = 0x18020c1b0;
    iVar5 = in_RCX;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(char *)(iVar5 + 4) == '\0') {
        cVar1 = *(char *)(iVar5 + 0x10);
        *(int64_t *)((int64_t)aiStackX_8 + iVar3 + iVar4) = in_RCX;
        if (cVar1 != '\0') {
            *(undefined8 *)((int64_t)auStack_30 + iVar3 + iVar4) = 0x18020c1cf;
            func_0x00018020be10();
        }
        if (*(int64_t *)(iVar5 + 0x38) == *(int64_t *)(iVar5 + 0x40)) {
            *(undefined8 *)((int64_t)auStack_30 + iVar3 + iVar4) = 0x18020c1e4;
            iVar2 = fcn.18020cd80(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + iVar4), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + iVar4 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + iVar4 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3 + iVar4), 
                                  *(int64_t *)(&stack0x00000050 + iVar3 + iVar4));
            if (iVar2 == 0) {
                *(undefined *)(iVar5 + 4) = 1;
                return;
            }
        }
        *(undefined *)(*(int64_t *)(iVar5 + 0x30) + *(int64_t *)(iVar5 + 0x40)) = uVar6;
        *(int64_t *)(iVar5 + 0x40) = *(int64_t *)(iVar5 + 0x40) + 1;
    }
    return;
}

// ============================================================
// Function: FUN_18020cc5a
// Address: 0x18020cc5a
// Size: 78 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018020cb63: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018020cb68)
// WARNING: Removing unreachable block (ram,0x00018020cb71)
// WARNING: Removing unreachable block (ram,0x00018020cb90)
// WARNING: Removing unreachable block (ram,0x00018020cba1)
// WARNING: Removing unreachable block (ram,0x00018020cba5)
// WARNING: Removing unreachable block (ram,0x00018020cbae)
// WARNING: Removing unreachable block (ram,0x00018020cbb4)
// WARNING: Removing unreachable block (ram,0x00018020cbbc)
// WARNING: Removing unreachable block (ram,0x00018020cbc6)
// WARNING: Removing unreachable block (ram,0x00018020cbdb)
// WARNING: Removing unreachable block (ram,0x00018020cbd5)
// WARNING: Removing unreachable block (ram,0x00018020cbeb)
// WARNING: Removing unreachable block (ram,0x00018020cbf6)
// WARNING: Removing unreachable block (ram,0x00018020cbfa)
// WARNING: Removing unreachable block (ram,0x00018020cc02)
// WARNING: Removing unreachable block (ram,0x00018020cc08)
// WARNING: Removing unreachable block (ram,0x00018020cc10)
// WARNING: Removing unreachable block (ram,0x00018020cc1a)
// WARNING: Removing unreachable block (ram,0x00018020cc2f)
// WARNING: Removing unreachable block (ram,0x00018020cc29)
// WARNING: Removing unreachable block (ram,0x00018020cc3f)
// WARNING: Removing unreachable block (ram,0x00018020cc4b)
// WARNING: Removing unreachable block (ram,0x00018020cc5a)
// WARNING: Removing unreachable block (ram,0x00018020cc60)
// WARNING: Removing unreachable block (ram,0x00018020cc66)
// WARNING: Removing unreachable block (ram,0x00018020cc6e)
// WARNING: Removing unreachable block (ram,0x00018020cc78)
// WARNING: Removing unreachable block (ram,0x00018020cc8d)
// WARNING: Removing unreachable block (ram,0x00018020cc87)
// WARNING: Removing unreachable block (ram,0x00018020cc9d)
// WARNING: Removing unreachable block (ram,0x00018020cca8)
// WARNING: Removing unreachable block (ram,0x00018020ccca)
// WARNING: Removing unreachable block (ram,0x00018020ccaf)
// WARNING: Removing unreachable block (ram,0x00018020ccb8)

void fcn.18020cb30(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined uVar6;
    undefined8 in_RDX;
    undefined8 unaff_RDI;
    int64_t aiStackX_8 [4];
    undefined8 auStack_30 [3];
    
    auStack_30[2] = 0x18020cb3f;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)auStack_30 + iVar4 + 0x10) = 0x18020cb51;
    iVar2 = func_0x00018020bfa0();
    if (iVar2 == 0) {
        return;
    }
    uVar6 = 0x22;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)auStack_30 + iVar4 + 0x10) = 0x18020cb68;
    *(undefined8 *)(&stack0xfffffffffffffff0 + iVar4) = in_RDX;
    *(undefined8 *)((int64_t)auStack_30 + iVar4 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStack_30 + iVar4) = 0x18020c1b0;
    iVar5 = in_RCX;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(char *)(iVar5 + 4) == '\0') {
        cVar1 = *(char *)(iVar5 + 0x10);
        *(int64_t *)((int64_t)aiStackX_8 + iVar3 + iVar4) = in_RCX;
        if (cVar1 != '\0') {
            *(undefined8 *)((int64_t)auStack_30 + iVar3 + iVar4) = 0x18020c1cf;
            func_0x00018020be10();
        }
        if (*(int64_t *)(iVar5 + 0x38) == *(int64_t *)(iVar5 + 0x40)) {
            *(undefined8 *)((int64_t)auStack_30 + iVar3 + iVar4) = 0x18020c1e4;
            iVar2 = fcn.18020cd80(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + iVar4), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + iVar4 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + iVar4 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3 + iVar4), 
                                  *(int64_t *)(&stack0x00000050 + iVar3 + iVar4));
            if (iVar2 == 0) {
                *(undefined *)(iVar5 + 4) = 1;
                return;
            }
        }
        *(undefined *)(*(int64_t *)(iVar5 + 0x30) + *(int64_t *)(iVar5 + 0x40)) = uVar6;
        *(int64_t *)(iVar5 + 0x40) = *(int64_t *)(iVar5 + 0x40) + 1;
    }
    return;
}

// ============================================================
// Function: FUN_18020cca8
// Address: 0x18020cca8
// Size: 47 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018020cb63: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018020cb68)
// WARNING: Removing unreachable block (ram,0x00018020cb71)
// WARNING: Removing unreachable block (ram,0x00018020cb90)
// WARNING: Removing unreachable block (ram,0x00018020cba1)
// WARNING: Removing unreachable block (ram,0x00018020cba5)
// WARNING: Removing unreachable block (ram,0x00018020cbae)
// WARNING: Removing unreachable block (ram,0x00018020cbb4)
// WARNING: Removing unreachable block (ram,0x00018020cbbc)
// WARNING: Removing unreachable block (ram,0x00018020cbc6)
// WARNING: Removing unreachable block (ram,0x00018020cbdb)
// WARNING: Removing unreachable block (ram,0x00018020cbd5)
// WARNING: Removing unreachable block (ram,0x00018020cbeb)
// WARNING: Removing unreachable block (ram,0x00018020cbf6)
// WARNING: Removing unreachable block (ram,0x00018020cbfa)
// WARNING: Removing unreachable block (ram,0x00018020cc02)
// WARNING: Removing unreachable block (ram,0x00018020cc08)
// WARNING: Removing unreachable block (ram,0x00018020cc10)
// WARNING: Removing unreachable block (ram,0x00018020cc1a)
// WARNING: Removing unreachable block (ram,0x00018020cc2f)
// WARNING: Removing unreachable block (ram,0x00018020cc29)
// WARNING: Removing unreachable block (ram,0x00018020cc3f)
// WARNING: Removing unreachable block (ram,0x00018020cc4b)
// WARNING: Removing unreachable block (ram,0x00018020cc5a)
// WARNING: Removing unreachable block (ram,0x00018020cc60)
// WARNING: Removing unreachable block (ram,0x00018020cc66)
// WARNING: Removing unreachable block (ram,0x00018020cc6e)
// WARNING: Removing unreachable block (ram,0x00018020cc78)
// WARNING: Removing unreachable block (ram,0x00018020cc8d)
// WARNING: Removing unreachable block (ram,0x00018020cc87)
// WARNING: Removing unreachable block (ram,0x00018020cc9d)
// WARNING: Removing unreachable block (ram,0x00018020cca8)
// WARNING: Removing unreachable block (ram,0x00018020ccca)
// WARNING: Removing unreachable block (ram,0x00018020ccaf)
// WARNING: Removing unreachable block (ram,0x00018020ccb8)

void fcn.18020cb30(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined uVar6;
    undefined8 in_RDX;
    undefined8 unaff_RDI;
    int64_t aiStackX_8 [4];
    undefined8 auStack_30 [3];
    
    auStack_30[2] = 0x18020cb3f;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)auStack_30 + iVar4 + 0x10) = 0x18020cb51;
    iVar2 = func_0x00018020bfa0();
    if (iVar2 == 0) {
        return;
    }
    uVar6 = 0x22;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)auStack_30 + iVar4 + 0x10) = 0x18020cb68;
    *(undefined8 *)(&stack0xfffffffffffffff0 + iVar4) = in_RDX;
    *(undefined8 *)((int64_t)auStack_30 + iVar4 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStack_30 + iVar4) = 0x18020c1b0;
    iVar5 = in_RCX;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(char *)(iVar5 + 4) == '\0') {
        cVar1 = *(char *)(iVar5 + 0x10);
        *(int64_t *)((int64_t)aiStackX_8 + iVar3 + iVar4) = in_RCX;
        if (cVar1 != '\0') {
            *(undefined8 *)((int64_t)auStack_30 + iVar3 + iVar4) = 0x18020c1cf;
            func_0x00018020be10();
        }
        if (*(int64_t *)(iVar5 + 0x38) == *(int64_t *)(iVar5 + 0x40)) {
            *(undefined8 *)((int64_t)auStack_30 + iVar3 + iVar4) = 0x18020c1e4;
            iVar2 = fcn.18020cd80(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + iVar4), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + iVar4 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + iVar4 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3 + iVar4), 
                                  *(int64_t *)(&stack0x00000050 + iVar3 + iVar4));
            if (iVar2 == 0) {
                *(undefined *)(iVar5 + 4) = 1;
                return;
            }
        }
        *(undefined *)(*(int64_t *)(iVar5 + 0x30) + *(int64_t *)(iVar5 + 0x40)) = uVar6;
        *(int64_t *)(iVar5 + 0x40) = *(int64_t *)(iVar5 + 0x40) + 1;
    }
    return;
}

// ============================================================
// Function: FUN_18020cce0
// Address: 0x18020cce0
// Size: 126 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2h
// WARNING: [rz-ghidra] Detected overlap for variable var_6h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h

void fcn.18020cce0(int64_t arg_28h, int64_t arg_30h)
{
    uint8_t uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint8_t *in_RCX;
    undefined uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020ccf5;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020cd06;
    iVar3 = func_0x00018020bfa0();
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020cd1b;
        fcn.18020c220(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000040 + iVar5), *(int64_t *)(&stack0x00000050 + iVar5), 
                      *(int64_t *)(&stack0x00000060 + iVar5), *(int64_t *)(&stack0x000000a0 + iVar5));
        if ((in_RCX[5] == 0) && (*(int64_t *)(in_RCX + 0x48) == 0)) {
            in_RCX[6] = 2;
            if ((*in_RCX & 1) != 0) {
                uVar6 = 10;
                uVar2 = *(undefined8 *)((int64_t)&arg_28h + iVar5);
                *(undefined8 *)((int64_t)&arg_30h + iVar5) = *(undefined8 *)((int64_t)&arg_30h + iVar5);
                *(undefined8 *)((int64_t)aiStackX_18 + iVar5) = *(undefined8 *)((int64_t)aiStackX_18 + iVar5);
                *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + -8) = 0x18020c1b0;
                iVar4 = fcn.18045a350();
                iVar4 = -iVar4;
                if (in_RCX[4] == 0) {
                    uVar1 = in_RCX[0x10];
                    *(undefined8 *)(&stack0x00000048 + iVar4 + iVar5) = uVar2;
                    if (uVar1 != 0) {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + iVar5 + -8) = 0x18020c1cf;
                        func_0x00018020be10();
                    }
                    if (*(int64_t *)(in_RCX + 0x38) == *(int64_t *)(in_RCX + 0x40)) {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + iVar5 + -8) = 0x18020c1e4;
                        iVar3 = fcn.18020cd80(*(int64_t *)(&stack0x00000048 + iVar4 + iVar5), 
                                              *(int64_t *)(&stack0x00000050 + iVar4 + iVar5), 
                                              *(int64_t *)(&stack0x00000060 + iVar4 + iVar5), 
                                              *(int64_t *)(&stack0x00000068 + iVar4 + iVar5), 
                                              *(int64_t *)(&stack0x00000070 + iVar4 + iVar5), 
                                              *(int64_t *)(&stack0x00000090 + iVar4 + iVar5));
                        if (iVar3 == 0) {
                            in_RCX[4] = 1;
                            return;
                        }
                    }
                    *(undefined *)(*(int64_t *)(in_RCX + 0x30) + *(int64_t *)(in_RCX + 0x40)) = uVar6;
                    *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
                }
                return;
            }
        } else {
            in_RCX[6] = 2;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18020cd60
// Address: 0x18020cd60
// Size: 25 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_45h

void fcn.18020cd60(int64_t arg_40h, int64_t arg_48h, int64_t arg_78h, int64_t arg_80h)
{
    uint8_t uVar1;
    char cVar2;
    bool bVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint8_t *in_RCX;
    uint64_t uVar7;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    char *pcVar8;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined8 uStackX_8;
    undefined8 auStackX_10 [3];
    
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar4 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_10 + iVar6 + 0x10) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar6 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar6) = unaff_R14;
    *(undefined8 *)((int64_t)&uStackX_8 + iVar6) = 0x18020c043;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_48h + iVar5 + iVar6) = *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_10 + iVar5 + iVar6;
    pcVar8 = (char *)((int64_t)&arg_40h + iVar5 + iVar6 + 5);
    if (((iVar4 == 0) && ((*in_RCX & 4) != 0)) && (0x1fffffffffffff < in_RDX)) {
        bVar3 = true;
    } else {
        bVar3 = false;
    }
    *(undefined8 *)((int64_t)&uStackX_8 + iVar5 + iVar6) = 0x18020c089;
    iVar4 = func_0x00018020bfa0();
    if (iVar4 != 0) {
        if (bVar3) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar5 + iVar6) = 0x18020c0a0;
            func_0x00018020c1a0(in_RCX, 0x22);
        }
        if (in_RDX == 0) {
            pcVar8 = "0";
        } else {
            *(undefined *)((int64_t)&arg_40h + iVar5 + iVar6 + 5) = 0;
            do {
                pcVar8 = pcVar8 + -1;
                uVar7 = in_RDX / 10;
                *pcVar8 = (char)in_RDX + (char)uVar7 * -10 + '0';
                in_RDX = uVar7;
            } while (uVar7 != 0);
        }
        if (in_RCX[4] == 0) {
            uVar1 = in_RCX[0x10];
            *(undefined8 *)((int64_t)&arg_78h + iVar5 + iVar6) = unaff_RBP;
            if (uVar1 != 0) {
                *(undefined8 *)((int64_t)&uStackX_8 + iVar5 + iVar6) = 0x18020c100;
                func_0x00018020be10(in_RCX);
            }
            cVar2 = *pcVar8;
            while (cVar2 != '\0') {
                pcVar8 = pcVar8 + 1;
                if (*(int64_t *)(in_RCX + 0x38) == *(int64_t *)(in_RCX + 0x40)) {
                    *(undefined8 *)((int64_t)&uStackX_8 + iVar5 + iVar6) = 0x18020c129;
                    iVar4 = fcn.18020cd80(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar6), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar5 + iVar6), 
                                          *(int64_t *)(&stack0x00000058 + iVar5 + iVar6), 
                                          *(int64_t *)(&stack0x00000060 + iVar5 + iVar6), 
                                          *(int64_t *)(&stack0x00000068 + iVar5 + iVar6), 
                                          *(int64_t *)(&stack0x00000088 + iVar5 + iVar6));
                    if (iVar4 == 0) {
                        in_RCX[4] = 1;
                        break;
                    }
                }
                *(char *)(*(int64_t *)(in_RCX + 0x30) + *(int64_t *)(in_RCX + 0x40)) = cVar2;
                *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
                cVar2 = *pcVar8;
            }
        }
        if (bVar3) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar5 + iVar6) = 0x18020c15f;
            func_0x00018020c1a0(in_RCX, 0x22);
        }
        if ((in_RCX[5] == 0) && (*(int64_t *)(in_RCX + 0x48) == 0)) {
            in_RCX[6] = 2;
            if ((*in_RCX & 1) != 0) {
                *(undefined8 *)((int64_t)&uStackX_8 + iVar5 + iVar6) = 0x18020c17f;
                func_0x00018020c1a0(in_RCX, 10);
            }
        } else {
            in_RCX[6] = 2;
        }
    }
    *(undefined8 *)((int64_t)&uStackX_8 + iVar5 + iVar6) = 0x18020c192;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_48h + iVar5 + iVar6) ^ (int64_t)auStackX_10 + iVar5 + iVar6);
    return;
}

// ============================================================
// Function: FUN_18020cd80
// Address: 0x18020cd80
// Size: 184 bytes
// ============================================================
undefined8
fcn.18020cd80(int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_80h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 *in_RCX;
    int32_t in_EDX;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020cd95;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar6 = in_RCX[3];
    uVar5 = 0;
    *(undefined8 *)(&stack0x00000028 + iVar4) = 0;
    if (uVar6 != 0) {
        do {
            iVar1 = in_RCX[1];
            uVar2 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020cdc8;
            iVar3 = func_0x00018021b300(uVar2, iVar1 + uVar5, uVar6 - uVar5, &stack0x00000028 + iVar4);
            uVar6 = in_RCX[3];
            if (iVar3 == 0) {
                iVar1 = in_RCX[1];
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020ce1e;
                func_0x000180498030(iVar1, iVar1 + uVar5, uVar6 - uVar5);
                in_RCX[3] = 0;
                return 0;
            }
            uVar5 = uVar5 + *(int64_t *)(&stack0x00000028 + iVar4);
        } while (uVar5 < uVar6);
    }
    in_RCX[3] = 0;
    if (in_EDX != 0) {
        uVar2 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020cdf9;
        func_0x000180219d10(uVar2, 0xb, 0, 0);
    }
    return 1;
}

// ============================================================
// Function: FUN_18020ce40
// Address: 0x18020ce40
// Size: 177 bytes
// ============================================================
void fcn.18020ce40(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h, int64_t arg_50h, int64_t arg_90h, int64_t arg_a0h,
                  int64_t arg_a8h, int64_t arg_b0h, int64_t arg_f0h, int64_t arg_100h, int64_t arg_108h,
                  int64_t arg_140h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t in_RCX;
    uint64_t in_RDX;
    uint32_t in_R8D;
    uint64_t in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18020ce4f;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(uint64_t *)((int64_t)&arg_90h + iVar9) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9);
    *(undefined8 *)((int64_t)&arg_40h + iVar9) = *(undefined8 *)((int64_t)&arg_100h + iVar9);
    if ((uint32_t)in_RDX < 4) {
        iVar11 = 0;
        iVar12 = 0;
        in_RCX = (in_RDX & 0xffffffff) * 0xd0 + in_RCX;
        if ((in_RCX != 0) && (in_R9 < 2)) {
            in_R8D = in_R8D & 0xff;
            if ((in_R8D == 1) || (in_R8D == 2)) {
                if (((uint32_t)in_RDX == 3) || (in_R9 == 0)) goto code_r0x00018020ceee;
            } else if ((in_R8D == 3) && (in_R9 == (*(uint32_t *)(in_RCX + 0x50) & 1))) {
code_r0x00018020ceee:
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&arg_f0h + iVar9) = unaff_R12;
                *(undefined8 *)((int64_t)&arg_b0h + iVar9) = unaff_R13;
                *(undefined8 *)((int64_t)&arg_a8h + iVar9) = unaff_R14;
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf0e;
                iVar10 = func_0x0001801f9a80(uVar1);
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf19;
                uVar5 = func_0x0001801f9a20(uVar1);
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf24;
                uVar6 = func_0x0001801f9a50(uVar1);
                if (iVar10 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf31;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf49;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                                  *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf5b;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
                    goto code_r0x00018020d136;
                }
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf6a;
                uVar7 = func_0x0001801f9c00(uVar1);
                if ((*(uint64_t *)((int64_t)&arg_108h + iVar9) != (uint64_t)uVar7) ||
                   (0x40 < *(uint64_t *)((int64_t)&arg_108h + iVar9))) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1b9;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1d1;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                                  *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1e3;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
                    goto code_r0x00018020d136;
                }
                uVar2 = *(undefined8 *)(in_RCX + 0x28);
                uVar3 = *(undefined8 *)(in_RCX + 0x48);
                uVar4 = *(undefined8 *)(in_RCX + 0x40);
                *(undefined4 *)((int64_t)&arg_30h + iVar9) = 1;
                *(uint64_t *)((int64_t)&arg_28h + iVar9) = (uint64_t)uVar5;
                *(undefined8 *)((int64_t)&arg_a0h + iVar9) = unaff_R15;
                iVar13 = in_R9 * 0x10 + 0x6a + in_RCX;
                *(int64_t *)((int64_t)&var_20h + iVar9) = iVar13;
                *(undefined8 *)((int64_t)&var_18h + iVar9) = 0;
                *(undefined8 *)((int64_t)&var_10h + iVar9) = 0;
                *(undefined8 *)((int64_t)&var_8h + iVar9) = 7;
                *(undefined8 *)(&stack0x00000000 + iVar9) = 0x1804ba510;
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cfe6;
                iVar8 = func_0x0001801b4180(uVar4, uVar3, uVar2, *(undefined8 *)((int64_t)&arg_40h + iVar9));
                if (iVar8 != 0) {
                    uVar2 = *(undefined8 *)(in_RCX + 0x28);
                    uVar3 = *(undefined8 *)(in_RCX + 0x48);
                    uVar4 = *(undefined8 *)(in_RCX + 0x40);
                    *(undefined4 *)((int64_t)&arg_30h + iVar9) = 1;
                    *(uint64_t *)((int64_t)&arg_28h + iVar9) = (uint64_t)uVar6;
                    *(int64_t *)((int64_t)&var_20h + iVar9) = (int64_t)&arg_50h + iVar9;
                    *(undefined8 *)((int64_t)&var_18h + iVar9) = 0;
                    *(undefined8 *)((int64_t)&var_10h + iVar9) = 0;
                    *(undefined8 *)((int64_t)&var_8h + iVar9) = 8;
                    *(undefined8 *)(&stack0x00000000 + iVar9) = 0x1804ba518;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d03c;
                    iVar8 = func_0x0001801b4180(uVar4, uVar3, uVar2, *(undefined8 *)((int64_t)&arg_40h + iVar9));
                    if (iVar8 != 0) {
                        uVar2 = *(undefined8 *)(in_RCX + 0x48);
                        uVar3 = *(undefined8 *)(in_RCX + 0x40);
                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d054;
                        iVar11 = func_0x0001802119f0(uVar3, iVar10, uVar2);
                        if (iVar11 == 0) {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d061;
                            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                         );
code_r0x00018020d066:
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d079;
                            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                          , *(int64_t *)((int64_t)&var_10h + iVar9), 
                                          *(int64_t *)((int64_t)&var_18h + iVar9), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar9));
                        } else {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d088;
                            iVar12 = func_0x000180211490();
                            if (iVar12 == 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d095;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), 
                                              *(int64_t *)((int64_t)&var_8h + iVar9));
                                goto code_r0x00018020d066;
                            }
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0a4;
                            iVar8 = func_0x00018020ef90(iVar11);
                            if ((uint64_t)uVar5 == (int64_t)iVar8) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0b8;
                                iVar8 = func_0x00018020efa0(iVar11);
                                if ((uint64_t)uVar6 == (int64_t)iVar8) {
                                    *(undefined4 *)((int64_t)&var_8h + iVar9) = 0;
                                    *(int64_t *)(&stack0x00000000 + iVar9) = iVar13;
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0e2;
                                    iVar8 = func_0x000180211b70(iVar12, iVar11, 0, (int64_t)&arg_50h + iVar9);
                                    if (iVar8 != 0) {
                                        *(int64_t *)(in_RCX + 0x30 + in_R9 * 8) = iVar12;
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d109;
                                        func_0x000180244fc0((int64_t)&arg_50h + iVar9, 0x40);
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d111;
                                        func_0x000180211a40(iVar11);
                                        goto code_r0x00018020d136;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0eb;
                                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar9));
                                    goto code_r0x00018020d066;
                                }
                            }
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d157;
                            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                         );
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d16f;
                            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                          , *(int64_t *)((int64_t)&var_10h + iVar9), 
                                          *(int64_t *)((int64_t)&var_18h + iVar9), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar9));
                        }
                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d181;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
                    }
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d189;
                func_0x000180211410(iVar12);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d191;
                func_0x000180211a40(iVar11);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d19e;
                func_0x000180244fc0(iVar13, 0x10);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1ad;
                func_0x000180244fc0((int64_t)&arg_50h + iVar9, 0x40);
                goto code_r0x00018020d136;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020ceb3;
    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9));
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cecb;
    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                  *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                  *(int64_t *)((int64_t)&arg_30h + iVar9));
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cedd;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
code_r0x00018020d136:
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d146;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_90h + iVar9) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9));
    return;
}

// ============================================================
// Function: FUN_18020cef1
// Address: 0x18020cef1
// Size: 182 bytes
// ============================================================
void fcn.18020ce40(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h, int64_t arg_50h, int64_t arg_90h, int64_t arg_a0h,
                  int64_t arg_a8h, int64_t arg_b0h, int64_t arg_f0h, int64_t arg_100h, int64_t arg_108h,
                  int64_t arg_140h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t in_RCX;
    uint64_t in_RDX;
    uint32_t in_R8D;
    uint64_t in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18020ce4f;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(uint64_t *)((int64_t)&arg_90h + iVar9) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9);
    *(undefined8 *)((int64_t)&arg_40h + iVar9) = *(undefined8 *)((int64_t)&arg_100h + iVar9);
    if ((uint32_t)in_RDX < 4) {
        iVar11 = 0;
        iVar12 = 0;
        in_RCX = (in_RDX & 0xffffffff) * 0xd0 + in_RCX;
        if ((in_RCX != 0) && (in_R9 < 2)) {
            in_R8D = in_R8D & 0xff;
            if ((in_R8D == 1) || (in_R8D == 2)) {
                if (((uint32_t)in_RDX == 3) || (in_R9 == 0)) goto code_r0x00018020ceee;
            } else if ((in_R8D == 3) && (in_R9 == (*(uint32_t *)(in_RCX + 0x50) & 1))) {
code_r0x00018020ceee:
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&arg_f0h + iVar9) = unaff_R12;
                *(undefined8 *)((int64_t)&arg_b0h + iVar9) = unaff_R13;
                *(undefined8 *)((int64_t)&arg_a8h + iVar9) = unaff_R14;
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf0e;
                iVar10 = func_0x0001801f9a80(uVar1);
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf19;
                uVar5 = func_0x0001801f9a20(uVar1);
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf24;
                uVar6 = func_0x0001801f9a50(uVar1);
                if (iVar10 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf31;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf49;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                                  *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf5b;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
                    goto code_r0x00018020d136;
                }
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf6a;
                uVar7 = func_0x0001801f9c00(uVar1);
                if ((*(uint64_t *)((int64_t)&arg_108h + iVar9) != (uint64_t)uVar7) ||
                   (0x40 < *(uint64_t *)((int64_t)&arg_108h + iVar9))) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1b9;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1d1;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                                  *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1e3;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
                    goto code_r0x00018020d136;
                }
                uVar2 = *(undefined8 *)(in_RCX + 0x28);
                uVar3 = *(undefined8 *)(in_RCX + 0x48);
                uVar4 = *(undefined8 *)(in_RCX + 0x40);
                *(undefined4 *)((int64_t)&arg_30h + iVar9) = 1;
                *(uint64_t *)((int64_t)&arg_28h + iVar9) = (uint64_t)uVar5;
                *(undefined8 *)((int64_t)&arg_a0h + iVar9) = unaff_R15;
                iVar13 = in_R9 * 0x10 + 0x6a + in_RCX;
                *(int64_t *)((int64_t)&var_20h + iVar9) = iVar13;
                *(undefined8 *)((int64_t)&var_18h + iVar9) = 0;
                *(undefined8 *)((int64_t)&var_10h + iVar9) = 0;
                *(undefined8 *)((int64_t)&var_8h + iVar9) = 7;
                *(undefined8 *)(&stack0x00000000 + iVar9) = 0x1804ba510;
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cfe6;
                iVar8 = func_0x0001801b4180(uVar4, uVar3, uVar2, *(undefined8 *)((int64_t)&arg_40h + iVar9));
                if (iVar8 != 0) {
                    uVar2 = *(undefined8 *)(in_RCX + 0x28);
                    uVar3 = *(undefined8 *)(in_RCX + 0x48);
                    uVar4 = *(undefined8 *)(in_RCX + 0x40);
                    *(undefined4 *)((int64_t)&arg_30h + iVar9) = 1;
                    *(uint64_t *)((int64_t)&arg_28h + iVar9) = (uint64_t)uVar6;
                    *(int64_t *)((int64_t)&var_20h + iVar9) = (int64_t)&arg_50h + iVar9;
                    *(undefined8 *)((int64_t)&var_18h + iVar9) = 0;
                    *(undefined8 *)((int64_t)&var_10h + iVar9) = 0;
                    *(undefined8 *)((int64_t)&var_8h + iVar9) = 8;
                    *(undefined8 *)(&stack0x00000000 + iVar9) = 0x1804ba518;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d03c;
                    iVar8 = func_0x0001801b4180(uVar4, uVar3, uVar2, *(undefined8 *)((int64_t)&arg_40h + iVar9));
                    if (iVar8 != 0) {
                        uVar2 = *(undefined8 *)(in_RCX + 0x48);
                        uVar3 = *(undefined8 *)(in_RCX + 0x40);
                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d054;
                        iVar11 = func_0x0001802119f0(uVar3, iVar10, uVar2);
                        if (iVar11 == 0) {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d061;
                            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                         );
code_r0x00018020d066:
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d079;
                            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                          , *(int64_t *)((int64_t)&var_10h + iVar9), 
                                          *(int64_t *)((int64_t)&var_18h + iVar9), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar9));
                        } else {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d088;
                            iVar12 = func_0x000180211490();
                            if (iVar12 == 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d095;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), 
                                              *(int64_t *)((int64_t)&var_8h + iVar9));
                                goto code_r0x00018020d066;
                            }
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0a4;
                            iVar8 = func_0x00018020ef90(iVar11);
                            if ((uint64_t)uVar5 == (int64_t)iVar8) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0b8;
                                iVar8 = func_0x00018020efa0(iVar11);
                                if ((uint64_t)uVar6 == (int64_t)iVar8) {
                                    *(undefined4 *)((int64_t)&var_8h + iVar9) = 0;
                                    *(int64_t *)(&stack0x00000000 + iVar9) = iVar13;
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0e2;
                                    iVar8 = func_0x000180211b70(iVar12, iVar11, 0, (int64_t)&arg_50h + iVar9);
                                    if (iVar8 != 0) {
                                        *(int64_t *)(in_RCX + 0x30 + in_R9 * 8) = iVar12;
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d109;
                                        func_0x000180244fc0((int64_t)&arg_50h + iVar9, 0x40);
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d111;
                                        func_0x000180211a40(iVar11);
                                        goto code_r0x00018020d136;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0eb;
                                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar9));
                                    goto code_r0x00018020d066;
                                }
                            }
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d157;
                            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                         );
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d16f;
                            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                          , *(int64_t *)((int64_t)&var_10h + iVar9), 
                                          *(int64_t *)((int64_t)&var_18h + iVar9), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar9));
                        }
                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d181;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
                    }
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d189;
                func_0x000180211410(iVar12);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d191;
                func_0x000180211a40(iVar11);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d19e;
                func_0x000180244fc0(iVar13, 0x10);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1ad;
                func_0x000180244fc0((int64_t)&arg_50h + iVar9, 0x40);
                goto code_r0x00018020d136;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020ceb3;
    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9));
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cecb;
    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                  *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                  *(int64_t *)((int64_t)&arg_30h + iVar9));
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cedd;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
code_r0x00018020d136:
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d146;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_90h + iVar9) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9));
    return;
}

// ============================================================
// Function: FUN_18020cfa7
// Address: 0x18020cfa7
// Size: 375 bytes
// ============================================================
void fcn.18020ce40(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h, int64_t arg_50h, int64_t arg_90h, int64_t arg_a0h,
                  int64_t arg_a8h, int64_t arg_b0h, int64_t arg_f0h, int64_t arg_100h, int64_t arg_108h,
                  int64_t arg_140h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t in_RCX;
    uint64_t in_RDX;
    uint32_t in_R8D;
    uint64_t in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18020ce4f;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(uint64_t *)((int64_t)&arg_90h + iVar9) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9);
    *(undefined8 *)((int64_t)&arg_40h + iVar9) = *(undefined8 *)((int64_t)&arg_100h + iVar9);
    if ((uint32_t)in_RDX < 4) {
        iVar11 = 0;
        iVar12 = 0;
        in_RCX = (in_RDX & 0xffffffff) * 0xd0 + in_RCX;
        if ((in_RCX != 0) && (in_R9 < 2)) {
            in_R8D = in_R8D & 0xff;
            if ((in_R8D == 1) || (in_R8D == 2)) {
                if (((uint32_t)in_RDX == 3) || (in_R9 == 0)) goto code_r0x00018020ceee;
            } else if ((in_R8D == 3) && (in_R9 == (*(uint32_t *)(in_RCX + 0x50) & 1))) {
code_r0x00018020ceee:
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&arg_f0h + iVar9) = unaff_R12;
                *(undefined8 *)((int64_t)&arg_b0h + iVar9) = unaff_R13;
                *(undefined8 *)((int64_t)&arg_a8h + iVar9) = unaff_R14;
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf0e;
                iVar10 = func_0x0001801f9a80(uVar1);
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf19;
                uVar5 = func_0x0001801f9a20(uVar1);
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf24;
                uVar6 = func_0x0001801f9a50(uVar1);
                if (iVar10 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf31;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf49;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                                  *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf5b;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
                    goto code_r0x00018020d136;
                }
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf6a;
                uVar7 = func_0x0001801f9c00(uVar1);
                if ((*(uint64_t *)((int64_t)&arg_108h + iVar9) != (uint64_t)uVar7) ||
                   (0x40 < *(uint64_t *)((int64_t)&arg_108h + iVar9))) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1b9;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1d1;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                                  *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1e3;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
                    goto code_r0x00018020d136;
                }
                uVar2 = *(undefined8 *)(in_RCX + 0x28);
                uVar3 = *(undefined8 *)(in_RCX + 0x48);
                uVar4 = *(undefined8 *)(in_RCX + 0x40);
                *(undefined4 *)((int64_t)&arg_30h + iVar9) = 1;
                *(uint64_t *)((int64_t)&arg_28h + iVar9) = (uint64_t)uVar5;
                *(undefined8 *)((int64_t)&arg_a0h + iVar9) = unaff_R15;
                iVar13 = in_R9 * 0x10 + 0x6a + in_RCX;
                *(int64_t *)((int64_t)&var_20h + iVar9) = iVar13;
                *(undefined8 *)((int64_t)&var_18h + iVar9) = 0;
                *(undefined8 *)((int64_t)&var_10h + iVar9) = 0;
                *(undefined8 *)((int64_t)&var_8h + iVar9) = 7;
                *(undefined8 *)(&stack0x00000000 + iVar9) = 0x1804ba510;
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cfe6;
                iVar8 = func_0x0001801b4180(uVar4, uVar3, uVar2, *(undefined8 *)((int64_t)&arg_40h + iVar9));
                if (iVar8 != 0) {
                    uVar2 = *(undefined8 *)(in_RCX + 0x28);
                    uVar3 = *(undefined8 *)(in_RCX + 0x48);
                    uVar4 = *(undefined8 *)(in_RCX + 0x40);
                    *(undefined4 *)((int64_t)&arg_30h + iVar9) = 1;
                    *(uint64_t *)((int64_t)&arg_28h + iVar9) = (uint64_t)uVar6;
                    *(int64_t *)((int64_t)&var_20h + iVar9) = (int64_t)&arg_50h + iVar9;
                    *(undefined8 *)((int64_t)&var_18h + iVar9) = 0;
                    *(undefined8 *)((int64_t)&var_10h + iVar9) = 0;
                    *(undefined8 *)((int64_t)&var_8h + iVar9) = 8;
                    *(undefined8 *)(&stack0x00000000 + iVar9) = 0x1804ba518;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d03c;
                    iVar8 = func_0x0001801b4180(uVar4, uVar3, uVar2, *(undefined8 *)((int64_t)&arg_40h + iVar9));
                    if (iVar8 != 0) {
                        uVar2 = *(undefined8 *)(in_RCX + 0x48);
                        uVar3 = *(undefined8 *)(in_RCX + 0x40);
                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d054;
                        iVar11 = func_0x0001802119f0(uVar3, iVar10, uVar2);
                        if (iVar11 == 0) {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d061;
                            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                         );
code_r0x00018020d066:
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d079;
                            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                          , *(int64_t *)((int64_t)&var_10h + iVar9), 
                                          *(int64_t *)((int64_t)&var_18h + iVar9), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar9));
                        } else {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d088;
                            iVar12 = func_0x000180211490();
                            if (iVar12 == 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d095;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), 
                                              *(int64_t *)((int64_t)&var_8h + iVar9));
                                goto code_r0x00018020d066;
                            }
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0a4;
                            iVar8 = func_0x00018020ef90(iVar11);
                            if ((uint64_t)uVar5 == (int64_t)iVar8) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0b8;
                                iVar8 = func_0x00018020efa0(iVar11);
                                if ((uint64_t)uVar6 == (int64_t)iVar8) {
                                    *(undefined4 *)((int64_t)&var_8h + iVar9) = 0;
                                    *(int64_t *)(&stack0x00000000 + iVar9) = iVar13;
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0e2;
                                    iVar8 = func_0x000180211b70(iVar12, iVar11, 0, (int64_t)&arg_50h + iVar9);
                                    if (iVar8 != 0) {
                                        *(int64_t *)(in_RCX + 0x30 + in_R9 * 8) = iVar12;
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d109;
                                        func_0x000180244fc0((int64_t)&arg_50h + iVar9, 0x40);
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d111;
                                        func_0x000180211a40(iVar11);
                                        goto code_r0x00018020d136;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0eb;
                                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar9));
                                    goto code_r0x00018020d066;
                                }
                            }
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d157;
                            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                         );
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d16f;
                            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                          , *(int64_t *)((int64_t)&var_10h + iVar9), 
                                          *(int64_t *)((int64_t)&var_18h + iVar9), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar9));
                        }
                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d181;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
                    }
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d189;
                func_0x000180211410(iVar12);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d191;
                func_0x000180211a40(iVar11);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d19e;
                func_0x000180244fc0(iVar13, 0x10);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1ad;
                func_0x000180244fc0((int64_t)&arg_50h + iVar9, 0x40);
                goto code_r0x00018020d136;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020ceb3;
    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9));
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cecb;
    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                  *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                  *(int64_t *)((int64_t)&arg_30h + iVar9));
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cedd;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
code_r0x00018020d136:
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d146;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_90h + iVar9) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9));
    return;
}

// ============================================================
// Function: FUN_18020d11e
// Address: 0x18020d11e
// Size: 24 bytes
// ============================================================
void fcn.18020ce40(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h, int64_t arg_50h, int64_t arg_90h, int64_t arg_a0h,
                  int64_t arg_a8h, int64_t arg_b0h, int64_t arg_f0h, int64_t arg_100h, int64_t arg_108h,
                  int64_t arg_140h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t in_RCX;
    uint64_t in_RDX;
    uint32_t in_R8D;
    uint64_t in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18020ce4f;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(uint64_t *)((int64_t)&arg_90h + iVar9) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9);
    *(undefined8 *)((int64_t)&arg_40h + iVar9) = *(undefined8 *)((int64_t)&arg_100h + iVar9);
    if ((uint32_t)in_RDX < 4) {
        iVar11 = 0;
        iVar12 = 0;
        in_RCX = (in_RDX & 0xffffffff) * 0xd0 + in_RCX;
        if ((in_RCX != 0) && (in_R9 < 2)) {
            in_R8D = in_R8D & 0xff;
            if ((in_R8D == 1) || (in_R8D == 2)) {
                if (((uint32_t)in_RDX == 3) || (in_R9 == 0)) goto code_r0x00018020ceee;
            } else if ((in_R8D == 3) && (in_R9 == (*(uint32_t *)(in_RCX + 0x50) & 1))) {
code_r0x00018020ceee:
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&arg_f0h + iVar9) = unaff_R12;
                *(undefined8 *)((int64_t)&arg_b0h + iVar9) = unaff_R13;
                *(undefined8 *)((int64_t)&arg_a8h + iVar9) = unaff_R14;
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf0e;
                iVar10 = func_0x0001801f9a80(uVar1);
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf19;
                uVar5 = func_0x0001801f9a20(uVar1);
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf24;
                uVar6 = func_0x0001801f9a50(uVar1);
                if (iVar10 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf31;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf49;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                                  *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf5b;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
                    goto code_r0x00018020d136;
                }
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf6a;
                uVar7 = func_0x0001801f9c00(uVar1);
                if ((*(uint64_t *)((int64_t)&arg_108h + iVar9) != (uint64_t)uVar7) ||
                   (0x40 < *(uint64_t *)((int64_t)&arg_108h + iVar9))) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1b9;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1d1;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                                  *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1e3;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
                    goto code_r0x00018020d136;
                }
                uVar2 = *(undefined8 *)(in_RCX + 0x28);
                uVar3 = *(undefined8 *)(in_RCX + 0x48);
                uVar4 = *(undefined8 *)(in_RCX + 0x40);
                *(undefined4 *)((int64_t)&arg_30h + iVar9) = 1;
                *(uint64_t *)((int64_t)&arg_28h + iVar9) = (uint64_t)uVar5;
                *(undefined8 *)((int64_t)&arg_a0h + iVar9) = unaff_R15;
                iVar13 = in_R9 * 0x10 + 0x6a + in_RCX;
                *(int64_t *)((int64_t)&var_20h + iVar9) = iVar13;
                *(undefined8 *)((int64_t)&var_18h + iVar9) = 0;
                *(undefined8 *)((int64_t)&var_10h + iVar9) = 0;
                *(undefined8 *)((int64_t)&var_8h + iVar9) = 7;
                *(undefined8 *)(&stack0x00000000 + iVar9) = 0x1804ba510;
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cfe6;
                iVar8 = func_0x0001801b4180(uVar4, uVar3, uVar2, *(undefined8 *)((int64_t)&arg_40h + iVar9));
                if (iVar8 != 0) {
                    uVar2 = *(undefined8 *)(in_RCX + 0x28);
                    uVar3 = *(undefined8 *)(in_RCX + 0x48);
                    uVar4 = *(undefined8 *)(in_RCX + 0x40);
                    *(undefined4 *)((int64_t)&arg_30h + iVar9) = 1;
                    *(uint64_t *)((int64_t)&arg_28h + iVar9) = (uint64_t)uVar6;
                    *(int64_t *)((int64_t)&var_20h + iVar9) = (int64_t)&arg_50h + iVar9;
                    *(undefined8 *)((int64_t)&var_18h + iVar9) = 0;
                    *(undefined8 *)((int64_t)&var_10h + iVar9) = 0;
                    *(undefined8 *)((int64_t)&var_8h + iVar9) = 8;
                    *(undefined8 *)(&stack0x00000000 + iVar9) = 0x1804ba518;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d03c;
                    iVar8 = func_0x0001801b4180(uVar4, uVar3, uVar2, *(undefined8 *)((int64_t)&arg_40h + iVar9));
                    if (iVar8 != 0) {
                        uVar2 = *(undefined8 *)(in_RCX + 0x48);
                        uVar3 = *(undefined8 *)(in_RCX + 0x40);
                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d054;
                        iVar11 = func_0x0001802119f0(uVar3, iVar10, uVar2);
                        if (iVar11 == 0) {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d061;
                            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                         );
code_r0x00018020d066:
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d079;
                            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                          , *(int64_t *)((int64_t)&var_10h + iVar9), 
                                          *(int64_t *)((int64_t)&var_18h + iVar9), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar9));
                        } else {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d088;
                            iVar12 = func_0x000180211490();
                            if (iVar12 == 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d095;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), 
                                              *(int64_t *)((int64_t)&var_8h + iVar9));
                                goto code_r0x00018020d066;
                            }
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0a4;
                            iVar8 = func_0x00018020ef90(iVar11);
                            if ((uint64_t)uVar5 == (int64_t)iVar8) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0b8;
                                iVar8 = func_0x00018020efa0(iVar11);
                                if ((uint64_t)uVar6 == (int64_t)iVar8) {
                                    *(undefined4 *)((int64_t)&var_8h + iVar9) = 0;
                                    *(int64_t *)(&stack0x00000000 + iVar9) = iVar13;
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0e2;
                                    iVar8 = func_0x000180211b70(iVar12, iVar11, 0, (int64_t)&arg_50h + iVar9);
                                    if (iVar8 != 0) {
                                        *(int64_t *)(in_RCX + 0x30 + in_R9 * 8) = iVar12;
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d109;
                                        func_0x000180244fc0((int64_t)&arg_50h + iVar9, 0x40);
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d111;
                                        func_0x000180211a40(iVar11);
                                        goto code_r0x00018020d136;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0eb;
                                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar9));
                                    goto code_r0x00018020d066;
                                }
                            }
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d157;
                            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                         );
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d16f;
                            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                          , *(int64_t *)((int64_t)&var_10h + iVar9), 
                                          *(int64_t *)((int64_t)&var_18h + iVar9), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar9));
                        }
                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d181;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
                    }
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d189;
                func_0x000180211410(iVar12);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d191;
                func_0x000180211a40(iVar11);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d19e;
                func_0x000180244fc0(iVar13, 0x10);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1ad;
                func_0x000180244fc0((int64_t)&arg_50h + iVar9, 0x40);
                goto code_r0x00018020d136;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020ceb3;
    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9));
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cecb;
    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                  *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                  *(int64_t *)((int64_t)&arg_30h + iVar9));
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cedd;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
code_r0x00018020d136:
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d146;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_90h + iVar9) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9));
    return;
}

// ============================================================
// Function: FUN_18020d136
// Address: 0x18020d136
// Size: 28 bytes
// ============================================================
void fcn.18020ce40(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h, int64_t arg_50h, int64_t arg_90h, int64_t arg_a0h,
                  int64_t arg_a8h, int64_t arg_b0h, int64_t arg_f0h, int64_t arg_100h, int64_t arg_108h,
                  int64_t arg_140h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t in_RCX;
    uint64_t in_RDX;
    uint32_t in_R8D;
    uint64_t in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18020ce4f;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(uint64_t *)((int64_t)&arg_90h + iVar9) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9);
    *(undefined8 *)((int64_t)&arg_40h + iVar9) = *(undefined8 *)((int64_t)&arg_100h + iVar9);
    if ((uint32_t)in_RDX < 4) {
        iVar11 = 0;
        iVar12 = 0;
        in_RCX = (in_RDX & 0xffffffff) * 0xd0 + in_RCX;
        if ((in_RCX != 0) && (in_R9 < 2)) {
            in_R8D = in_R8D & 0xff;
            if ((in_R8D == 1) || (in_R8D == 2)) {
                if (((uint32_t)in_RDX == 3) || (in_R9 == 0)) goto code_r0x00018020ceee;
            } else if ((in_R8D == 3) && (in_R9 == (*(uint32_t *)(in_RCX + 0x50) & 1))) {
code_r0x00018020ceee:
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&arg_f0h + iVar9) = unaff_R12;
                *(undefined8 *)((int64_t)&arg_b0h + iVar9) = unaff_R13;
                *(undefined8 *)((int64_t)&arg_a8h + iVar9) = unaff_R14;
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf0e;
                iVar10 = func_0x0001801f9a80(uVar1);
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf19;
                uVar5 = func_0x0001801f9a20(uVar1);
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf24;
                uVar6 = func_0x0001801f9a50(uVar1);
                if (iVar10 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf31;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf49;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                                  *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf5b;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
                    goto code_r0x00018020d136;
                }
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf6a;
                uVar7 = func_0x0001801f9c00(uVar1);
                if ((*(uint64_t *)((int64_t)&arg_108h + iVar9) != (uint64_t)uVar7) ||
                   (0x40 < *(uint64_t *)((int64_t)&arg_108h + iVar9))) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1b9;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1d1;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                                  *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1e3;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
                    goto code_r0x00018020d136;
                }
                uVar2 = *(undefined8 *)(in_RCX + 0x28);
                uVar3 = *(undefined8 *)(in_RCX + 0x48);
                uVar4 = *(undefined8 *)(in_RCX + 0x40);
                *(undefined4 *)((int64_t)&arg_30h + iVar9) = 1;
                *(uint64_t *)((int64_t)&arg_28h + iVar9) = (uint64_t)uVar5;
                *(undefined8 *)((int64_t)&arg_a0h + iVar9) = unaff_R15;
                iVar13 = in_R9 * 0x10 + 0x6a + in_RCX;
                *(int64_t *)((int64_t)&var_20h + iVar9) = iVar13;
                *(undefined8 *)((int64_t)&var_18h + iVar9) = 0;
                *(undefined8 *)((int64_t)&var_10h + iVar9) = 0;
                *(undefined8 *)((int64_t)&var_8h + iVar9) = 7;
                *(undefined8 *)(&stack0x00000000 + iVar9) = 0x1804ba510;
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cfe6;
                iVar8 = func_0x0001801b4180(uVar4, uVar3, uVar2, *(undefined8 *)((int64_t)&arg_40h + iVar9));
                if (iVar8 != 0) {
                    uVar2 = *(undefined8 *)(in_RCX + 0x28);
                    uVar3 = *(undefined8 *)(in_RCX + 0x48);
                    uVar4 = *(undefined8 *)(in_RCX + 0x40);
                    *(undefined4 *)((int64_t)&arg_30h + iVar9) = 1;
                    *(uint64_t *)((int64_t)&arg_28h + iVar9) = (uint64_t)uVar6;
                    *(int64_t *)((int64_t)&var_20h + iVar9) = (int64_t)&arg_50h + iVar9;
                    *(undefined8 *)((int64_t)&var_18h + iVar9) = 0;
                    *(undefined8 *)((int64_t)&var_10h + iVar9) = 0;
                    *(undefined8 *)((int64_t)&var_8h + iVar9) = 8;
                    *(undefined8 *)(&stack0x00000000 + iVar9) = 0x1804ba518;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d03c;
                    iVar8 = func_0x0001801b4180(uVar4, uVar3, uVar2, *(undefined8 *)((int64_t)&arg_40h + iVar9));
                    if (iVar8 != 0) {
                        uVar2 = *(undefined8 *)(in_RCX + 0x48);
                        uVar3 = *(undefined8 *)(in_RCX + 0x40);
                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d054;
                        iVar11 = func_0x0001802119f0(uVar3, iVar10, uVar2);
                        if (iVar11 == 0) {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d061;
                            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                         );
code_r0x00018020d066:
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d079;
                            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                          , *(int64_t *)((int64_t)&var_10h + iVar9), 
                                          *(int64_t *)((int64_t)&var_18h + iVar9), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar9));
                        } else {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d088;
                            iVar12 = func_0x000180211490();
                            if (iVar12 == 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d095;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), 
                                              *(int64_t *)((int64_t)&var_8h + iVar9));
                                goto code_r0x00018020d066;
                            }
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0a4;
                            iVar8 = func_0x00018020ef90(iVar11);
                            if ((uint64_t)uVar5 == (int64_t)iVar8) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0b8;
                                iVar8 = func_0x00018020efa0(iVar11);
                                if ((uint64_t)uVar6 == (int64_t)iVar8) {
                                    *(undefined4 *)((int64_t)&var_8h + iVar9) = 0;
                                    *(int64_t *)(&stack0x00000000 + iVar9) = iVar13;
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0e2;
                                    iVar8 = func_0x000180211b70(iVar12, iVar11, 0, (int64_t)&arg_50h + iVar9);
                                    if (iVar8 != 0) {
                                        *(int64_t *)(in_RCX + 0x30 + in_R9 * 8) = iVar12;
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d109;
                                        func_0x000180244fc0((int64_t)&arg_50h + iVar9, 0x40);
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d111;
                                        func_0x000180211a40(iVar11);
                                        goto code_r0x00018020d136;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0eb;
                                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar9));
                                    goto code_r0x00018020d066;
                                }
                            }
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d157;
                            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                         );
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d16f;
                            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                          , *(int64_t *)((int64_t)&var_10h + iVar9), 
                                          *(int64_t *)((int64_t)&var_18h + iVar9), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar9));
                        }
                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d181;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
                    }
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d189;
                func_0x000180211410(iVar12);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d191;
                func_0x000180211a40(iVar11);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d19e;
                func_0x000180244fc0(iVar13, 0x10);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1ad;
                func_0x000180244fc0((int64_t)&arg_50h + iVar9, 0x40);
                goto code_r0x00018020d136;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020ceb3;
    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9));
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cecb;
    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                  *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                  *(int64_t *)((int64_t)&arg_30h + iVar9));
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cedd;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
code_r0x00018020d136:
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d146;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_90h + iVar9) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9));
    return;
}

// ============================================================
// Function: FUN_18020d152
// Address: 0x18020d152
// Size: 98 bytes
// ============================================================
void fcn.18020ce40(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h, int64_t arg_50h, int64_t arg_90h, int64_t arg_a0h,
                  int64_t arg_a8h, int64_t arg_b0h, int64_t arg_f0h, int64_t arg_100h, int64_t arg_108h,
                  int64_t arg_140h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t in_RCX;
    uint64_t in_RDX;
    uint32_t in_R8D;
    uint64_t in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18020ce4f;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(uint64_t *)((int64_t)&arg_90h + iVar9) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9);
    *(undefined8 *)((int64_t)&arg_40h + iVar9) = *(undefined8 *)((int64_t)&arg_100h + iVar9);
    if ((uint32_t)in_RDX < 4) {
        iVar11 = 0;
        iVar12 = 0;
        in_RCX = (in_RDX & 0xffffffff) * 0xd0 + in_RCX;
        if ((in_RCX != 0) && (in_R9 < 2)) {
            in_R8D = in_R8D & 0xff;
            if ((in_R8D == 1) || (in_R8D == 2)) {
                if (((uint32_t)in_RDX == 3) || (in_R9 == 0)) goto code_r0x00018020ceee;
            } else if ((in_R8D == 3) && (in_R9 == (*(uint32_t *)(in_RCX + 0x50) & 1))) {
code_r0x00018020ceee:
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&arg_f0h + iVar9) = unaff_R12;
                *(undefined8 *)((int64_t)&arg_b0h + iVar9) = unaff_R13;
                *(undefined8 *)((int64_t)&arg_a8h + iVar9) = unaff_R14;
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf0e;
                iVar10 = func_0x0001801f9a80(uVar1);
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf19;
                uVar5 = func_0x0001801f9a20(uVar1);
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf24;
                uVar6 = func_0x0001801f9a50(uVar1);
                if (iVar10 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf31;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf49;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                                  *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf5b;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
                    goto code_r0x00018020d136;
                }
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf6a;
                uVar7 = func_0x0001801f9c00(uVar1);
                if ((*(uint64_t *)((int64_t)&arg_108h + iVar9) != (uint64_t)uVar7) ||
                   (0x40 < *(uint64_t *)((int64_t)&arg_108h + iVar9))) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1b9;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1d1;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                                  *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1e3;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
                    goto code_r0x00018020d136;
                }
                uVar2 = *(undefined8 *)(in_RCX + 0x28);
                uVar3 = *(undefined8 *)(in_RCX + 0x48);
                uVar4 = *(undefined8 *)(in_RCX + 0x40);
                *(undefined4 *)((int64_t)&arg_30h + iVar9) = 1;
                *(uint64_t *)((int64_t)&arg_28h + iVar9) = (uint64_t)uVar5;
                *(undefined8 *)((int64_t)&arg_a0h + iVar9) = unaff_R15;
                iVar13 = in_R9 * 0x10 + 0x6a + in_RCX;
                *(int64_t *)((int64_t)&var_20h + iVar9) = iVar13;
                *(undefined8 *)((int64_t)&var_18h + iVar9) = 0;
                *(undefined8 *)((int64_t)&var_10h + iVar9) = 0;
                *(undefined8 *)((int64_t)&var_8h + iVar9) = 7;
                *(undefined8 *)(&stack0x00000000 + iVar9) = 0x1804ba510;
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cfe6;
                iVar8 = func_0x0001801b4180(uVar4, uVar3, uVar2, *(undefined8 *)((int64_t)&arg_40h + iVar9));
                if (iVar8 != 0) {
                    uVar2 = *(undefined8 *)(in_RCX + 0x28);
                    uVar3 = *(undefined8 *)(in_RCX + 0x48);
                    uVar4 = *(undefined8 *)(in_RCX + 0x40);
                    *(undefined4 *)((int64_t)&arg_30h + iVar9) = 1;
                    *(uint64_t *)((int64_t)&arg_28h + iVar9) = (uint64_t)uVar6;
                    *(int64_t *)((int64_t)&var_20h + iVar9) = (int64_t)&arg_50h + iVar9;
                    *(undefined8 *)((int64_t)&var_18h + iVar9) = 0;
                    *(undefined8 *)((int64_t)&var_10h + iVar9) = 0;
                    *(undefined8 *)((int64_t)&var_8h + iVar9) = 8;
                    *(undefined8 *)(&stack0x00000000 + iVar9) = 0x1804ba518;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d03c;
                    iVar8 = func_0x0001801b4180(uVar4, uVar3, uVar2, *(undefined8 *)((int64_t)&arg_40h + iVar9));
                    if (iVar8 != 0) {
                        uVar2 = *(undefined8 *)(in_RCX + 0x48);
                        uVar3 = *(undefined8 *)(in_RCX + 0x40);
                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d054;
                        iVar11 = func_0x0001802119f0(uVar3, iVar10, uVar2);
                        if (iVar11 == 0) {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d061;
                            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                         );
code_r0x00018020d066:
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d079;
                            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                          , *(int64_t *)((int64_t)&var_10h + iVar9), 
                                          *(int64_t *)((int64_t)&var_18h + iVar9), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar9));
                        } else {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d088;
                            iVar12 = func_0x000180211490();
                            if (iVar12 == 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d095;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), 
                                              *(int64_t *)((int64_t)&var_8h + iVar9));
                                goto code_r0x00018020d066;
                            }
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0a4;
                            iVar8 = func_0x00018020ef90(iVar11);
                            if ((uint64_t)uVar5 == (int64_t)iVar8) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0b8;
                                iVar8 = func_0x00018020efa0(iVar11);
                                if ((uint64_t)uVar6 == (int64_t)iVar8) {
                                    *(undefined4 *)((int64_t)&var_8h + iVar9) = 0;
                                    *(int64_t *)(&stack0x00000000 + iVar9) = iVar13;
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0e2;
                                    iVar8 = func_0x000180211b70(iVar12, iVar11, 0, (int64_t)&arg_50h + iVar9);
                                    if (iVar8 != 0) {
                                        *(int64_t *)(in_RCX + 0x30 + in_R9 * 8) = iVar12;
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d109;
                                        func_0x000180244fc0((int64_t)&arg_50h + iVar9, 0x40);
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d111;
                                        func_0x000180211a40(iVar11);
                                        goto code_r0x00018020d136;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0eb;
                                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar9));
                                    goto code_r0x00018020d066;
                                }
                            }
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d157;
                            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                         );
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d16f;
                            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                          , *(int64_t *)((int64_t)&var_10h + iVar9), 
                                          *(int64_t *)((int64_t)&var_18h + iVar9), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar9));
                        }
                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d181;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
                    }
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d189;
                func_0x000180211410(iVar12);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d191;
                func_0x000180211a40(iVar11);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d19e;
                func_0x000180244fc0(iVar13, 0x10);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1ad;
                func_0x000180244fc0((int64_t)&arg_50h + iVar9, 0x40);
                goto code_r0x00018020d136;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020ceb3;
    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9));
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cecb;
    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                  *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                  *(int64_t *)((int64_t)&arg_30h + iVar9));
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cedd;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
code_r0x00018020d136:
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d146;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_90h + iVar9) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9));
    return;
}

// ============================================================
// Function: FUN_18020d1b4
// Address: 0x18020d1b4
// Size: 54 bytes
// ============================================================
void fcn.18020ce40(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h, int64_t arg_50h, int64_t arg_90h, int64_t arg_a0h,
                  int64_t arg_a8h, int64_t arg_b0h, int64_t arg_f0h, int64_t arg_100h, int64_t arg_108h,
                  int64_t arg_140h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t in_RCX;
    uint64_t in_RDX;
    uint32_t in_R8D;
    uint64_t in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18020ce4f;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(uint64_t *)((int64_t)&arg_90h + iVar9) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9);
    *(undefined8 *)((int64_t)&arg_40h + iVar9) = *(undefined8 *)((int64_t)&arg_100h + iVar9);
    if ((uint32_t)in_RDX < 4) {
        iVar11 = 0;
        iVar12 = 0;
        in_RCX = (in_RDX & 0xffffffff) * 0xd0 + in_RCX;
        if ((in_RCX != 0) && (in_R9 < 2)) {
            in_R8D = in_R8D & 0xff;
            if ((in_R8D == 1) || (in_R8D == 2)) {
                if (((uint32_t)in_RDX == 3) || (in_R9 == 0)) goto code_r0x00018020ceee;
            } else if ((in_R8D == 3) && (in_R9 == (*(uint32_t *)(in_RCX + 0x50) & 1))) {
code_r0x00018020ceee:
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&arg_f0h + iVar9) = unaff_R12;
                *(undefined8 *)((int64_t)&arg_b0h + iVar9) = unaff_R13;
                *(undefined8 *)((int64_t)&arg_a8h + iVar9) = unaff_R14;
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf0e;
                iVar10 = func_0x0001801f9a80(uVar1);
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf19;
                uVar5 = func_0x0001801f9a20(uVar1);
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf24;
                uVar6 = func_0x0001801f9a50(uVar1);
                if (iVar10 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf31;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf49;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                                  *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf5b;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
                    goto code_r0x00018020d136;
                }
                uVar1 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cf6a;
                uVar7 = func_0x0001801f9c00(uVar1);
                if ((*(uint64_t *)((int64_t)&arg_108h + iVar9) != (uint64_t)uVar7) ||
                   (0x40 < *(uint64_t *)((int64_t)&arg_108h + iVar9))) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1b9;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1d1;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                                  *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1e3;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
                    goto code_r0x00018020d136;
                }
                uVar2 = *(undefined8 *)(in_RCX + 0x28);
                uVar3 = *(undefined8 *)(in_RCX + 0x48);
                uVar4 = *(undefined8 *)(in_RCX + 0x40);
                *(undefined4 *)((int64_t)&arg_30h + iVar9) = 1;
                *(uint64_t *)((int64_t)&arg_28h + iVar9) = (uint64_t)uVar5;
                *(undefined8 *)((int64_t)&arg_a0h + iVar9) = unaff_R15;
                iVar13 = in_R9 * 0x10 + 0x6a + in_RCX;
                *(int64_t *)((int64_t)&var_20h + iVar9) = iVar13;
                *(undefined8 *)((int64_t)&var_18h + iVar9) = 0;
                *(undefined8 *)((int64_t)&var_10h + iVar9) = 0;
                *(undefined8 *)((int64_t)&var_8h + iVar9) = 7;
                *(undefined8 *)(&stack0x00000000 + iVar9) = 0x1804ba510;
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cfe6;
                iVar8 = func_0x0001801b4180(uVar4, uVar3, uVar2, *(undefined8 *)((int64_t)&arg_40h + iVar9));
                if (iVar8 != 0) {
                    uVar2 = *(undefined8 *)(in_RCX + 0x28);
                    uVar3 = *(undefined8 *)(in_RCX + 0x48);
                    uVar4 = *(undefined8 *)(in_RCX + 0x40);
                    *(undefined4 *)((int64_t)&arg_30h + iVar9) = 1;
                    *(uint64_t *)((int64_t)&arg_28h + iVar9) = (uint64_t)uVar6;
                    *(int64_t *)((int64_t)&var_20h + iVar9) = (int64_t)&arg_50h + iVar9;
                    *(undefined8 *)((int64_t)&var_18h + iVar9) = 0;
                    *(undefined8 *)((int64_t)&var_10h + iVar9) = 0;
                    *(undefined8 *)((int64_t)&var_8h + iVar9) = 8;
                    *(undefined8 *)(&stack0x00000000 + iVar9) = 0x1804ba518;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d03c;
                    iVar8 = func_0x0001801b4180(uVar4, uVar3, uVar2, *(undefined8 *)((int64_t)&arg_40h + iVar9));
                    if (iVar8 != 0) {
                        uVar2 = *(undefined8 *)(in_RCX + 0x48);
                        uVar3 = *(undefined8 *)(in_RCX + 0x40);
                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d054;
                        iVar11 = func_0x0001802119f0(uVar3, iVar10, uVar2);
                        if (iVar11 == 0) {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d061;
                            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                         );
code_r0x00018020d066:
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d079;
                            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                          , *(int64_t *)((int64_t)&var_10h + iVar9), 
                                          *(int64_t *)((int64_t)&var_18h + iVar9), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar9));
                        } else {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d088;
                            iVar12 = func_0x000180211490();
                            if (iVar12 == 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d095;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), 
                                              *(int64_t *)((int64_t)&var_8h + iVar9));
                                goto code_r0x00018020d066;
                            }
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0a4;
                            iVar8 = func_0x00018020ef90(iVar11);
                            if ((uint64_t)uVar5 == (int64_t)iVar8) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0b8;
                                iVar8 = func_0x00018020efa0(iVar11);
                                if ((uint64_t)uVar6 == (int64_t)iVar8) {
                                    *(undefined4 *)((int64_t)&var_8h + iVar9) = 0;
                                    *(int64_t *)(&stack0x00000000 + iVar9) = iVar13;
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0e2;
                                    iVar8 = func_0x000180211b70(iVar12, iVar11, 0, (int64_t)&arg_50h + iVar9);
                                    if (iVar8 != 0) {
                                        *(int64_t *)(in_RCX + 0x30 + in_R9 * 8) = iVar12;
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d109;
                                        func_0x000180244fc0((int64_t)&arg_50h + iVar9, 0x40);
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d111;
                                        func_0x000180211a40(iVar11);
                                        goto code_r0x00018020d136;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d0eb;
                                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar9));
                                    goto code_r0x00018020d066;
                                }
                            }
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d157;
                            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                         );
                            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d16f;
                            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9)
                                          , *(int64_t *)((int64_t)&var_10h + iVar9), 
                                          *(int64_t *)((int64_t)&var_18h + iVar9), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar9));
                        }
                        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d181;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
                    }
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d189;
                func_0x000180211410(iVar12);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d191;
                func_0x000180211a40(iVar11);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d19e;
                func_0x000180244fc0(iVar13, 0x10);
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d1ad;
                func_0x000180244fc0((int64_t)&arg_50h + iVar9, 0x40);
                goto code_r0x00018020d136;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020ceb3;
    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9));
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cecb;
    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                  *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                  *(int64_t *)((int64_t)&arg_30h + iVar9));
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020cedd;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar9));
code_r0x00018020d136:
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18020d146;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_90h + iVar9) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9));
    return;
}

// ============================================================
// Function: FUN_18020d1f0
// Address: 0x18020d1f0
// Size: 165 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18020d1f0(int64_t arg_28h)
{
    char cVar1;
    int64_t iVar2;
    int64_t in_RCX;
    uint32_t uVar3;
    uint64_t in_RDX;
    int64_t iVar4;
    uint64_t in_R8;
    int64_t iVar5;
    int64_t iVar6;
    bool bVar7;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020d200;
    iVar2 = fcn.18045a350();
    uVar3 = (uint32_t)in_RDX;
    iVar6 = (in_RDX & 0xffffffff) * 0xd0;
    iVar4 = 0;
    if (uVar3 < 4) {
        iVar4 = in_RCX + iVar6;
    }
    iVar5 = 0;
    if (uVar3 < 4) {
        iVar5 = in_RCX + iVar6;
    }
    if (iVar5 == 0) {
        return;
    }
    if (1 < in_R8) {
        return;
    }
    cVar1 = *(char *)(iVar4 + 0x68);
    if ((cVar1 == '\x01') || (cVar1 == '\x02')) {
        if (uVar3 == 3) goto code_r0x00018020d25d;
        bVar7 = in_R8 == 0;
    } else {
        if (cVar1 != '\x03') {
            return;
        }
        bVar7 = in_R8 == (*(uint32_t *)(iVar5 + 0x50) & 1);
    }
    if (!bVar7) {
        return;
    }
code_r0x00018020d25d:
    if (*(int64_t *)(iVar4 + 0x30 + in_R8 * 8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x18020d26c;
        func_0x000180211410();
        *(undefined8 *)(iVar4 + 0x30 + in_R8 * 8) = 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x18020d28a;
    func_0x000180244fc0(in_R8 * 0x10 + 0x6a + iVar4, 0x10);
    return;
}

// ============================================================
// Function: FUN_18020d2a0
// Address: 0x18020d2a0
// Size: 23 bytes
// ============================================================
void fcn.18020d2a0(int64_t placeholder_0, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3,
                  int64_t arg_28h, undefined8 placeholder_5, int64_t arg_38h)
{
    char cVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    if (3 < (uint32_t)arg2) {
        return;
    }
    uStack_10 = 0x18020d2b4;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
    placeholder_0 = (arg2 & 0xffffffffU) * 0xd0 + placeholder_0;
    if (placeholder_0 == 0) {
        return;
    }
    if (*(char *)(placeholder_0 + 0x68) == '\x04') {
        return;
    }
    cVar1 = *(char *)(placeholder_0 + 0x68);
    if ((cVar1 != '\0') && (((cVar1 == '\x01' || (cVar1 == '\x02')) || (cVar1 == '\x03')))) {
        *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d306;
        func_0x0001801f8940(placeholder_0);
        cVar1 = *(char *)(placeholder_0 + 0x68);
        if (((cVar1 == '\x01') || (cVar1 == '\x02')) ||
           ((cVar1 == '\x03' && ((~*(uint32_t *)(placeholder_0 + 0x50) & 1) != 0)))) {
            if (*(int64_t *)(placeholder_0 + 0x30) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d330;
                func_0x000180211410();
                *(undefined8 *)(placeholder_0 + 0x30) = 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d346;
            func_0x000180244fc0(placeholder_0 + 0x6a, 0x10);
        }
        cVar1 = *(char *)(placeholder_0 + 0x68);
        if ((cVar1 == '\x01') || (cVar1 == '\x02')) {
            if ((int32_t)arg2 != 3) goto code_r0x00018020d391;
        } else if ((cVar1 != '\x03') || ((*(uint32_t *)(placeholder_0 + 0x50) & 1) == 0)) goto code_r0x00018020d391;
        if (*(int64_t *)(placeholder_0 + 0x38) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d376;
            func_0x000180211410();
            *(undefined8 *)(placeholder_0 + 0x38) = 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d38c;
        func_0x000180244fc0(placeholder_0 + 0x7a, 0x10);
    }
code_r0x00018020d391:
    uVar2 = *(undefined8 *)(placeholder_0 + 0x28);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d39a;
    func_0x000180215590(uVar2);
    *(undefined8 *)(placeholder_0 + 0x28) = 0;
    *(undefined *)(placeholder_0 + 0x68) = 4;
    return;
}

// ============================================================
// Function: FUN_18020d2b7
// Address: 0x18020d2b7
// Size: 69 bytes
// ============================================================
void fcn.18020d2a0(int64_t placeholder_0, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3,
                  int64_t arg_28h, undefined8 placeholder_5, int64_t arg_38h)
{
    char cVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    if (3 < (uint32_t)arg2) {
        return;
    }
    uStack_10 = 0x18020d2b4;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
    placeholder_0 = (arg2 & 0xffffffffU) * 0xd0 + placeholder_0;
    if (placeholder_0 == 0) {
        return;
    }
    if (*(char *)(placeholder_0 + 0x68) == '\x04') {
        return;
    }
    cVar1 = *(char *)(placeholder_0 + 0x68);
    if ((cVar1 != '\0') && (((cVar1 == '\x01' || (cVar1 == '\x02')) || (cVar1 == '\x03')))) {
        *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d306;
        func_0x0001801f8940(placeholder_0);
        cVar1 = *(char *)(placeholder_0 + 0x68);
        if (((cVar1 == '\x01') || (cVar1 == '\x02')) ||
           ((cVar1 == '\x03' && ((~*(uint32_t *)(placeholder_0 + 0x50) & 1) != 0)))) {
            if (*(int64_t *)(placeholder_0 + 0x30) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d330;
                func_0x000180211410();
                *(undefined8 *)(placeholder_0 + 0x30) = 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d346;
            func_0x000180244fc0(placeholder_0 + 0x6a, 0x10);
        }
        cVar1 = *(char *)(placeholder_0 + 0x68);
        if ((cVar1 == '\x01') || (cVar1 == '\x02')) {
            if ((int32_t)arg2 != 3) goto code_r0x00018020d391;
        } else if ((cVar1 != '\x03') || ((*(uint32_t *)(placeholder_0 + 0x50) & 1) == 0)) goto code_r0x00018020d391;
        if (*(int64_t *)(placeholder_0 + 0x38) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d376;
            func_0x000180211410();
            *(undefined8 *)(placeholder_0 + 0x38) = 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d38c;
        func_0x000180244fc0(placeholder_0 + 0x7a, 0x10);
    }
code_r0x00018020d391:
    uVar2 = *(undefined8 *)(placeholder_0 + 0x28);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d39a;
    func_0x000180215590(uVar2);
    *(undefined8 *)(placeholder_0 + 0x28) = 0;
    *(undefined *)(placeholder_0 + 0x68) = 4;
    return;
}

// ============================================================
// Function: FUN_18020d2fc
// Address: 0x18020d2fc
// Size: 149 bytes
// ============================================================
void fcn.18020d2a0(int64_t placeholder_0, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3,
                  int64_t arg_28h, undefined8 placeholder_5, int64_t arg_38h)
{
    char cVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    if (3 < (uint32_t)arg2) {
        return;
    }
    uStack_10 = 0x18020d2b4;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
    placeholder_0 = (arg2 & 0xffffffffU) * 0xd0 + placeholder_0;
    if (placeholder_0 == 0) {
        return;
    }
    if (*(char *)(placeholder_0 + 0x68) == '\x04') {
        return;
    }
    cVar1 = *(char *)(placeholder_0 + 0x68);
    if ((cVar1 != '\0') && (((cVar1 == '\x01' || (cVar1 == '\x02')) || (cVar1 == '\x03')))) {
        *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d306;
        func_0x0001801f8940(placeholder_0);
        cVar1 = *(char *)(placeholder_0 + 0x68);
        if (((cVar1 == '\x01') || (cVar1 == '\x02')) ||
           ((cVar1 == '\x03' && ((~*(uint32_t *)(placeholder_0 + 0x50) & 1) != 0)))) {
            if (*(int64_t *)(placeholder_0 + 0x30) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d330;
                func_0x000180211410();
                *(undefined8 *)(placeholder_0 + 0x30) = 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d346;
            func_0x000180244fc0(placeholder_0 + 0x6a, 0x10);
        }
        cVar1 = *(char *)(placeholder_0 + 0x68);
        if ((cVar1 == '\x01') || (cVar1 == '\x02')) {
            if ((int32_t)arg2 != 3) goto code_r0x00018020d391;
        } else if ((cVar1 != '\x03') || ((*(uint32_t *)(placeholder_0 + 0x50) & 1) == 0)) goto code_r0x00018020d391;
        if (*(int64_t *)(placeholder_0 + 0x38) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d376;
            func_0x000180211410();
            *(undefined8 *)(placeholder_0 + 0x38) = 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d38c;
        func_0x000180244fc0(placeholder_0 + 0x7a, 0x10);
    }
code_r0x00018020d391:
    uVar2 = *(undefined8 *)(placeholder_0 + 0x28);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d39a;
    func_0x000180215590(uVar2);
    *(undefined8 *)(placeholder_0 + 0x28) = 0;
    *(undefined *)(placeholder_0 + 0x68) = 4;
    return;
}

// ============================================================
// Function: FUN_18020d391
// Address: 0x18020d391
// Size: 31 bytes
// ============================================================
void fcn.18020d2a0(int64_t placeholder_0, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3,
                  int64_t arg_28h, undefined8 placeholder_5, int64_t arg_38h)
{
    char cVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    if (3 < (uint32_t)arg2) {
        return;
    }
    uStack_10 = 0x18020d2b4;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
    placeholder_0 = (arg2 & 0xffffffffU) * 0xd0 + placeholder_0;
    if (placeholder_0 == 0) {
        return;
    }
    if (*(char *)(placeholder_0 + 0x68) == '\x04') {
        return;
    }
    cVar1 = *(char *)(placeholder_0 + 0x68);
    if ((cVar1 != '\0') && (((cVar1 == '\x01' || (cVar1 == '\x02')) || (cVar1 == '\x03')))) {
        *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d306;
        func_0x0001801f8940(placeholder_0);
        cVar1 = *(char *)(placeholder_0 + 0x68);
        if (((cVar1 == '\x01') || (cVar1 == '\x02')) ||
           ((cVar1 == '\x03' && ((~*(uint32_t *)(placeholder_0 + 0x50) & 1) != 0)))) {
            if (*(int64_t *)(placeholder_0 + 0x30) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d330;
                func_0x000180211410();
                *(undefined8 *)(placeholder_0 + 0x30) = 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d346;
            func_0x000180244fc0(placeholder_0 + 0x6a, 0x10);
        }
        cVar1 = *(char *)(placeholder_0 + 0x68);
        if ((cVar1 == '\x01') || (cVar1 == '\x02')) {
            if ((int32_t)arg2 != 3) goto code_r0x00018020d391;
        } else if ((cVar1 != '\x03') || ((*(uint32_t *)(placeholder_0 + 0x50) & 1) == 0)) goto code_r0x00018020d391;
        if (*(int64_t *)(placeholder_0 + 0x38) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d376;
            func_0x000180211410();
            *(undefined8 *)(placeholder_0 + 0x38) = 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d38c;
        func_0x000180244fc0(placeholder_0 + 0x7a, 0x10);
    }
code_r0x00018020d391:
    uVar2 = *(undefined8 *)(placeholder_0 + 0x28);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d39a;
    func_0x000180215590(uVar2);
    *(undefined8 *)(placeholder_0 + 0x28) = 0;
    *(undefined *)(placeholder_0 + 0x68) = 4;
    return;
}

// ============================================================
// Function: FUN_18020d3b0
// Address: 0x18020d3b0
// Size: 1 bytes
// ============================================================
void fcn.18020d2a0(int64_t placeholder_0, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3,
                  int64_t arg_28h, undefined8 placeholder_5, int64_t arg_38h)
{
    char cVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    if (3 < (uint32_t)arg2) {
        return;
    }
    uStack_10 = 0x18020d2b4;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
    placeholder_0 = (arg2 & 0xffffffffU) * 0xd0 + placeholder_0;
    if (placeholder_0 == 0) {
        return;
    }
    if (*(char *)(placeholder_0 + 0x68) == '\x04') {
        return;
    }
    cVar1 = *(char *)(placeholder_0 + 0x68);
    if ((cVar1 != '\0') && (((cVar1 == '\x01' || (cVar1 == '\x02')) || (cVar1 == '\x03')))) {
        *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d306;
        func_0x0001801f8940(placeholder_0);
        cVar1 = *(char *)(placeholder_0 + 0x68);
        if (((cVar1 == '\x01') || (cVar1 == '\x02')) ||
           ((cVar1 == '\x03' && ((~*(uint32_t *)(placeholder_0 + 0x50) & 1) != 0)))) {
            if (*(int64_t *)(placeholder_0 + 0x30) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d330;
                func_0x000180211410();
                *(undefined8 *)(placeholder_0 + 0x30) = 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d346;
            func_0x000180244fc0(placeholder_0 + 0x6a, 0x10);
        }
        cVar1 = *(char *)(placeholder_0 + 0x68);
        if ((cVar1 == '\x01') || (cVar1 == '\x02')) {
            if ((int32_t)arg2 != 3) goto code_r0x00018020d391;
        } else if ((cVar1 != '\x03') || ((*(uint32_t *)(placeholder_0 + 0x50) & 1) == 0)) goto code_r0x00018020d391;
        if (*(int64_t *)(placeholder_0 + 0x38) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d376;
            func_0x000180211410();
            *(undefined8 *)(placeholder_0 + 0x38) = 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d38c;
        func_0x000180244fc0(placeholder_0 + 0x7a, 0x10);
    }
code_r0x00018020d391:
    uVar2 = *(undefined8 *)(placeholder_0 + 0x28);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020d39a;
    func_0x000180215590(uVar2);
    *(undefined8 *)(placeholder_0 + 0x28) = 0;
    *(undefined *)(placeholder_0 + 0x68) = 4;
    return;
}

// ============================================================
// Function: FUN_18020d430
// Address: 0x18020d430
// Size: 108 bytes
// ============================================================
void fcn.18020d430(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_90h,
                  int64_t arg_a0h, int64_t arg_d0h)
{
    int64_t iVar1;
    undefined4 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18020d43d;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&arg_90h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar8);
    if ((((uint32_t)in_RDX < 4) && (in_RCX = (in_RDX & 0xffffffff) * 0xd0 + in_RCX, in_RCX != 0)) &&
       ((uint32_t)in_RDX == 3)) {
        if (*(char *)(in_RCX + 0x68) == '\x02') {
            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d495;
            fcn.18020d1f0(*(int64_t *)((int64_t)&var_10h + iVar8));
            *(undefined *)(in_RCX + 0x68) = 3;
        } else if (*(char *)(in_RCX + 0x68) != '\x03') {
            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d584;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8));
            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d59c;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                          *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)((int64_t)&arg_28h + iVar8), 
                          *(int64_t *)((int64_t)&arg_40h + iVar8));
            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d5ae;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar8));
            goto code_r0x00018020d55d;
        }
        uVar2 = *(undefined4 *)(in_RCX + 0x60);
        *(undefined8 *)((int64_t)&arg_d0h + iVar8) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_a0h + iVar8) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d4b1;
        uVar6 = func_0x0001801f9c00(uVar2);
        iVar1 = in_RCX + 0x8a;
        uVar9 = (uint64_t)uVar6;
        *(uint64_t *)((int64_t)&var_18h + iVar8) = uVar9;
        *(int64_t *)((int64_t)&var_10h + iVar8) = iVar1;
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d4df;
        iVar7 = fcn.18020ce40(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                              *(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_38h + iVar8), 
                              *(int64_t *)(&stack0x00000078 + iVar8), *(int64_t *)(&stack0x00000088 + iVar8), 
                              *(int64_t *)((int64_t)&arg_90h + iVar8), *(int64_t *)(&stack0x00000098 + iVar8), 
                              *(int64_t *)(&stack0x000000d8 + iVar8), *(int64_t *)(&stack0x000000e8 + iVar8), 
                              *(int64_t *)(&stack0x000000f0 + iVar8), *(int64_t *)(&stack0x00000128 + iVar8));
        if (iVar7 != 0) {
            uVar3 = *(undefined8 *)(in_RCX + 0x28);
            uVar4 = *(undefined8 *)(in_RCX + 0x48);
            uVar5 = *(undefined8 *)(in_RCX + 0x40);
            *(undefined4 *)((int64_t)&arg_40h + iVar8) = 1;
            *(uint64_t *)((int64_t)&arg_38h + iVar8) = uVar9;
            *(int64_t *)((int64_t)&arg_30h + iVar8) = (int64_t)&arg_50h + iVar8;
            *(undefined8 *)((int64_t)&arg_28h + iVar8) = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar8) = 0;
            *(undefined8 *)((int64_t)&var_18h + iVar8) = 7;
            *(undefined8 *)((int64_t)&var_10h + iVar8) = 0x1804ba528;
            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d52f;
            iVar7 = func_0x0001801b4180(uVar5, uVar4, uVar3, iVar1);
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d54b;
                fcn.18020d1f0(*(int64_t *)((int64_t)&var_10h + iVar8));
            } else {
                *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d5c2;
                func_0x000180498030(iVar1, (int64_t)&arg_50h + iVar8, uVar9);
                *(undefined *)(in_RCX + 0x68) = 1;
            }
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d5d2;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d5ea;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                      *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)((int64_t)&arg_28h + iVar8), 
                      *(int64_t *)((int64_t)&arg_40h + iVar8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d5fc;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar8));
    }
code_r0x00018020d55d:
    *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d56d;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_90h + iVar8) ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar8));
    return;
}

// ============================================================
// Function: FUN_18020d49c
// Address: 0x18020d49c
// Size: 193 bytes
// ============================================================
void fcn.18020d430(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_90h,
                  int64_t arg_a0h, int64_t arg_d0h)
{
    int64_t iVar1;
    undefined4 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18020d43d;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&arg_90h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar8);
    if ((((uint32_t)in_RDX < 4) && (in_RCX = (in_RDX & 0xffffffff) * 0xd0 + in_RCX, in_RCX != 0)) &&
       ((uint32_t)in_RDX == 3)) {
        if (*(char *)(in_RCX + 0x68) == '\x02') {
            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d495;
            fcn.18020d1f0(*(int64_t *)((int64_t)&var_10h + iVar8));
            *(undefined *)(in_RCX + 0x68) = 3;
        } else if (*(char *)(in_RCX + 0x68) != '\x03') {
            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d584;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8));
            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d59c;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                          *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)((int64_t)&arg_28h + iVar8), 
                          *(int64_t *)((int64_t)&arg_40h + iVar8));
            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d5ae;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar8));
            goto code_r0x00018020d55d;
        }
        uVar2 = *(undefined4 *)(in_RCX + 0x60);
        *(undefined8 *)((int64_t)&arg_d0h + iVar8) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_a0h + iVar8) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d4b1;
        uVar6 = func_0x0001801f9c00(uVar2);
        iVar1 = in_RCX + 0x8a;
        uVar9 = (uint64_t)uVar6;
        *(uint64_t *)((int64_t)&var_18h + iVar8) = uVar9;
        *(int64_t *)((int64_t)&var_10h + iVar8) = iVar1;
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d4df;
        iVar7 = fcn.18020ce40(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                              *(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_38h + iVar8), 
                              *(int64_t *)(&stack0x00000078 + iVar8), *(int64_t *)(&stack0x00000088 + iVar8), 
                              *(int64_t *)((int64_t)&arg_90h + iVar8), *(int64_t *)(&stack0x00000098 + iVar8), 
                              *(int64_t *)(&stack0x000000d8 + iVar8), *(int64_t *)(&stack0x000000e8 + iVar8), 
                              *(int64_t *)(&stack0x000000f0 + iVar8), *(int64_t *)(&stack0x00000128 + iVar8));
        if (iVar7 != 0) {
            uVar3 = *(undefined8 *)(in_RCX + 0x28);
            uVar4 = *(undefined8 *)(in_RCX + 0x48);
            uVar5 = *(undefined8 *)(in_RCX + 0x40);
            *(undefined4 *)((int64_t)&arg_40h + iVar8) = 1;
            *(uint64_t *)((int64_t)&arg_38h + iVar8) = uVar9;
            *(int64_t *)((int64_t)&arg_30h + iVar8) = (int64_t)&arg_50h + iVar8;
            *(undefined8 *)((int64_t)&arg_28h + iVar8) = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar8) = 0;
            *(undefined8 *)((int64_t)&var_18h + iVar8) = 7;
            *(undefined8 *)((int64_t)&var_10h + iVar8) = 0x1804ba528;
            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d52f;
            iVar7 = func_0x0001801b4180(uVar5, uVar4, uVar3, iVar1);
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d54b;
                fcn.18020d1f0(*(int64_t *)((int64_t)&var_10h + iVar8));
            } else {
                *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d5c2;
                func_0x000180498030(iVar1, (int64_t)&arg_50h + iVar8, uVar9);
                *(undefined *)(in_RCX + 0x68) = 1;
            }
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d5d2;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d5ea;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                      *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)((int64_t)&arg_28h + iVar8), 
                      *(int64_t *)((int64_t)&arg_40h + iVar8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d5fc;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar8));
    }
code_r0x00018020d55d:
    *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d56d;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_90h + iVar8) ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar8));
    return;
}

// ============================================================
// Function: FUN_18020d55d
// Address: 0x18020d55d
// Size: 85 bytes
// ============================================================
void fcn.18020d430(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_90h,
                  int64_t arg_a0h, int64_t arg_d0h)
{
    int64_t iVar1;
    undefined4 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18020d43d;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&arg_90h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar8);
    if ((((uint32_t)in_RDX < 4) && (in_RCX = (in_RDX & 0xffffffff) * 0xd0 + in_RCX, in_RCX != 0)) &&
       ((uint32_t)in_RDX == 3)) {
        if (*(char *)(in_RCX + 0x68) == '\x02') {
            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d495;
            fcn.18020d1f0(*(int64_t *)((int64_t)&var_10h + iVar8));
            *(undefined *)(in_RCX + 0x68) = 3;
        } else if (*(char *)(in_RCX + 0x68) != '\x03') {
            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d584;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8));
            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d59c;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                          *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)((int64_t)&arg_28h + iVar8), 
                          *(int64_t *)((int64_t)&arg_40h + iVar8));
            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d5ae;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar8));
            goto code_r0x00018020d55d;
        }
        uVar2 = *(undefined4 *)(in_RCX + 0x60);
        *(undefined8 *)((int64_t)&arg_d0h + iVar8) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_a0h + iVar8) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d4b1;
        uVar6 = func_0x0001801f9c00(uVar2);
        iVar1 = in_RCX + 0x8a;
        uVar9 = (uint64_t)uVar6;
        *(uint64_t *)((int64_t)&var_18h + iVar8) = uVar9;
        *(int64_t *)((int64_t)&var_10h + iVar8) = iVar1;
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d4df;
        iVar7 = fcn.18020ce40(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                              *(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_38h + iVar8), 
                              *(int64_t *)(&stack0x00000078 + iVar8), *(int64_t *)(&stack0x00000088 + iVar8), 
                              *(int64_t *)((int64_t)&arg_90h + iVar8), *(int64_t *)(&stack0x00000098 + iVar8), 
                              *(int64_t *)(&stack0x000000d8 + iVar8), *(int64_t *)(&stack0x000000e8 + iVar8), 
                              *(int64_t *)(&stack0x000000f0 + iVar8), *(int64_t *)(&stack0x00000128 + iVar8));
        if (iVar7 != 0) {
            uVar3 = *(undefined8 *)(in_RCX + 0x28);
            uVar4 = *(undefined8 *)(in_RCX + 0x48);
            uVar5 = *(undefined8 *)(in_RCX + 0x40);
            *(undefined4 *)((int64_t)&arg_40h + iVar8) = 1;
            *(uint64_t *)((int64_t)&arg_38h + iVar8) = uVar9;
            *(int64_t *)((int64_t)&arg_30h + iVar8) = (int64_t)&arg_50h + iVar8;
            *(undefined8 *)((int64_t)&arg_28h + iVar8) = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar8) = 0;
            *(undefined8 *)((int64_t)&var_18h + iVar8) = 7;
            *(undefined8 *)((int64_t)&var_10h + iVar8) = 0x1804ba528;
            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d52f;
            iVar7 = func_0x0001801b4180(uVar5, uVar4, uVar3, iVar1);
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d54b;
                fcn.18020d1f0(*(int64_t *)((int64_t)&var_10h + iVar8));
            } else {
                *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d5c2;
                func_0x000180498030(iVar1, (int64_t)&arg_50h + iVar8, uVar9);
                *(undefined *)(in_RCX + 0x68) = 1;
            }
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d5d2;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d5ea;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                      *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)((int64_t)&arg_28h + iVar8), 
                      *(int64_t *)((int64_t)&arg_40h + iVar8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d5fc;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar8));
    }
code_r0x00018020d55d:
    *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d56d;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_90h + iVar8) ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar8));
    return;
}

// ============================================================
// Function: FUN_18020d5b2
// Address: 0x18020d5b2
// Size: 27 bytes
// ============================================================
void fcn.18020d430(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_90h,
                  int64_t arg_a0h, int64_t arg_d0h)
{
    int64_t iVar1;
    undefined4 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18020d43d;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&arg_90h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar8);
    if ((((uint32_t)in_RDX < 4) && (in_RCX = (in_RDX & 0xffffffff) * 0xd0 + in_RCX, in_RCX != 0)) &&
       ((uint32_t)in_RDX == 3)) {
        if (*(char *)(in_RCX + 0x68) == '\x02') {
            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d495;
            fcn.18020d1f0(*(int64_t *)((int64_t)&var_10h + iVar8));
            *(undefined *)(in_RCX + 0x68) = 3;
        } else if (*(char *)(in_RCX + 0x68) != '\x03') {
            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d584;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8));
            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d59c;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                          *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)((int64_t)&arg_28h + iVar8), 
                          *(int64_t *)((int64_t)&arg_40h + iVar8));
            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d5ae;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar8));
            goto code_r0x00018020d55d;
        }
        uVar2 = *(undefined4 *)(in_RCX + 0x60);
        *(undefined8 *)((int64_t)&arg_d0h + iVar8) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_a0h + iVar8) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d4b1;
        uVar6 = func_0x0001801f9c00(uVar2);
        iVar1 = in_RCX + 0x8a;
        uVar9 = (uint64_t)uVar6;
        *(uint64_t *)((int64_t)&var_18h + iVar8) = uVar9;
        *(int64_t *)((int64_t)&var_10h + iVar8) = iVar1;
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d4df;
        iVar7 = fcn.18020ce40(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                              *(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_38h + iVar8), 
                              *(int64_t *)(&stack0x00000078 + iVar8), *(int64_t *)(&stack0x00000088 + iVar8), 
                              *(int64_t *)((int64_t)&arg_90h + iVar8), *(int64_t *)(&stack0x00000098 + iVar8), 
                              *(int64_t *)(&stack0x000000d8 + iVar8), *(int64_t *)(&stack0x000000e8 + iVar8), 
                              *(int64_t *)(&stack0x000000f0 + iVar8), *(int64_t *)(&stack0x00000128 + iVar8));
        if (iVar7 != 0) {
            uVar3 = *(undefined8 *)(in_RCX + 0x28);
            uVar4 = *(undefined8 *)(in_RCX + 0x48);
            uVar5 = *(undefined8 *)(in_RCX + 0x40);
            *(undefined4 *)((int64_t)&arg_40h + iVar8) = 1;
            *(uint64_t *)((int64_t)&arg_38h + iVar8) = uVar9;
            *(int64_t *)((int64_t)&arg_30h + iVar8) = (int64_t)&arg_50h + iVar8;
            *(undefined8 *)((int64_t)&arg_28h + iVar8) = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar8) = 0;
            *(undefined8 *)((int64_t)&var_18h + iVar8) = 7;
            *(undefined8 *)((int64_t)&var_10h + iVar8) = 0x1804ba528;
            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d52f;
            iVar7 = func_0x0001801b4180(uVar5, uVar4, uVar3, iVar1);
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d54b;
                fcn.18020d1f0(*(int64_t *)((int64_t)&var_10h + iVar8));
            } else {
                *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d5c2;
                func_0x000180498030(iVar1, (int64_t)&arg_50h + iVar8, uVar9);
                *(undefined *)(in_RCX + 0x68) = 1;
            }
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d5d2;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d5ea;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                      *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)((int64_t)&arg_28h + iVar8), 
                      *(int64_t *)((int64_t)&arg_40h + iVar8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d5fc;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar8));
    }
code_r0x00018020d55d:
    *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d56d;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_90h + iVar8) ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar8));
    return;
}

// ============================================================
// Function: FUN_18020d5cd
// Address: 0x18020d5cd
// Size: 54 bytes
// ============================================================
void fcn.18020d430(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_90h,
                  int64_t arg_a0h, int64_t arg_d0h)
{
    int64_t iVar1;
    undefined4 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18020d43d;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&arg_90h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar8);
    if ((((uint32_t)in_RDX < 4) && (in_RCX = (in_RDX & 0xffffffff) * 0xd0 + in_RCX, in_RCX != 0)) &&
       ((uint32_t)in_RDX == 3)) {
        if (*(char *)(in_RCX + 0x68) == '\x02') {
            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d495;
            fcn.18020d1f0(*(int64_t *)((int64_t)&var_10h + iVar8));
            *(undefined *)(in_RCX + 0x68) = 3;
        } else if (*(char *)(in_RCX + 0x68) != '\x03') {
            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d584;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8));
            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d59c;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                          *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)((int64_t)&arg_28h + iVar8), 
                          *(int64_t *)((int64_t)&arg_40h + iVar8));
            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d5ae;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar8));
            goto code_r0x00018020d55d;
        }
        uVar2 = *(undefined4 *)(in_RCX + 0x60);
        *(undefined8 *)((int64_t)&arg_d0h + iVar8) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_a0h + iVar8) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d4b1;
        uVar6 = func_0x0001801f9c00(uVar2);
        iVar1 = in_RCX + 0x8a;
        uVar9 = (uint64_t)uVar6;
        *(uint64_t *)((int64_t)&var_18h + iVar8) = uVar9;
        *(int64_t *)((int64_t)&var_10h + iVar8) = iVar1;
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d4df;
        iVar7 = fcn.18020ce40(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                              *(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_38h + iVar8), 
                              *(int64_t *)(&stack0x00000078 + iVar8), *(int64_t *)(&stack0x00000088 + iVar8), 
                              *(int64_t *)((int64_t)&arg_90h + iVar8), *(int64_t *)(&stack0x00000098 + iVar8), 
                              *(int64_t *)(&stack0x000000d8 + iVar8), *(int64_t *)(&stack0x000000e8 + iVar8), 
                              *(int64_t *)(&stack0x000000f0 + iVar8), *(int64_t *)(&stack0x00000128 + iVar8));
        if (iVar7 != 0) {
            uVar3 = *(undefined8 *)(in_RCX + 0x28);
            uVar4 = *(undefined8 *)(in_RCX + 0x48);
            uVar5 = *(undefined8 *)(in_RCX + 0x40);
            *(undefined4 *)((int64_t)&arg_40h + iVar8) = 1;
            *(uint64_t *)((int64_t)&arg_38h + iVar8) = uVar9;
            *(int64_t *)((int64_t)&arg_30h + iVar8) = (int64_t)&arg_50h + iVar8;
            *(undefined8 *)((int64_t)&arg_28h + iVar8) = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar8) = 0;
            *(undefined8 *)((int64_t)&var_18h + iVar8) = 7;
            *(undefined8 *)((int64_t)&var_10h + iVar8) = 0x1804ba528;
            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d52f;
            iVar7 = func_0x0001801b4180(uVar5, uVar4, uVar3, iVar1);
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d54b;
                fcn.18020d1f0(*(int64_t *)((int64_t)&var_10h + iVar8));
            } else {
                *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d5c2;
                func_0x000180498030(iVar1, (int64_t)&arg_50h + iVar8, uVar9);
                *(undefined *)(in_RCX + 0x68) = 1;
            }
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d5d2;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d5ea;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                      *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)((int64_t)&arg_28h + iVar8), 
                      *(int64_t *)((int64_t)&arg_40h + iVar8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d5fc;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar8));
    }
code_r0x00018020d55d:
    *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x18020d56d;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_90h + iVar8) ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar8));
    return;
}

// ============================================================
// Function: FUN_18020d610
// Address: 0x18020d610
// Size: 160 bytes
// ============================================================
void fcn.18020d610(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h, int64_t arg_a0h,
                  int64_t arg_b0h, int64_t arg_e0h, int64_t arg_e8h)
{
    int64_t iVar1;
    char cVar2;
    undefined4 uVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    uint32_t uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar10;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18020d61d;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(uint64_t *)((int64_t)&arg_a0h + iVar9) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar9);
    if ((((uint32_t)in_RDX < 4) && (in_RCX = (in_RDX & 0xffffffff) * 0xd0 + in_RCX, in_RCX != 0)) &&
       ((uint32_t)in_RDX == 3)) {
        if (*(char *)(in_RCX + 0x68) == '\x01') {
            if (*(char *)(in_RCX + 0x69) == '\0') {
                *(int64_t *)(in_RCX + 0x50) = *(int64_t *)(in_RCX + 0x50) + 1;
                *(undefined *)(in_RCX + 0x68) = 2;
            } else {
                uVar3 = *(undefined4 *)(in_RCX + 0x60);
                *(undefined8 *)((int64_t)&arg_e0h + iVar9) = unaff_RBP;
                *(undefined8 *)((int64_t)&arg_e8h + iVar9) = unaff_RSI;
                *(undefined8 *)((int64_t)&arg_b0h + iVar9) = unaff_R14;
                *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x18020d6cd;
                uVar7 = func_0x0001801f9c00(uVar3);
                uVar4 = *(undefined8 *)(in_RCX + 0x28);
                iVar1 = in_RCX + 0x8a;
                uVar5 = *(undefined8 *)(in_RCX + 0x48);
                uVar6 = *(undefined8 *)(in_RCX + 0x40);
                *(undefined4 *)((int64_t)&arg_40h + iVar9) = 1;
                uVar10 = (uint64_t)uVar7;
                *(uint64_t *)((int64_t)&arg_38h + iVar9) = uVar10;
                *(int64_t *)((int64_t)&arg_30h + iVar9) = (int64_t)&arg_60h + iVar9;
                *(undefined8 *)((int64_t)&arg_28h + iVar9) = 0;
                *(undefined8 *)((int64_t)&var_20h + iVar9) = 0;
                *(undefined8 *)((int64_t)&var_18h + iVar9) = 7;
                *(undefined8 *)((int64_t)&var_10h + iVar9) = 0x1804ba528;
                *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x18020d723;
                iVar8 = func_0x0001801b4180(uVar6, uVar5, uVar4, iVar1);
                if (iVar8 != 0) {
                    cVar2 = *(char *)(in_RCX + 0x68);
                    if (((cVar2 == '\x01') || (cVar2 == '\x02')) ||
                       ((cVar2 == '\x03' && ((~*(uint32_t *)(in_RCX + 0x50) & 1) != 0)))) {
                        if (*(int64_t *)(in_RCX + 0x30) != 0) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x18020d755;
                            func_0x000180211410();
                            *(undefined8 *)(in_RCX + 0x30) = 0;
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x18020d767;
                        func_0x000180244fc0(in_RCX + 0x6a, 0x10);
                    }
                    *(uint64_t *)((int64_t)&var_18h + iVar9) = uVar10;
                    *(int64_t *)((int64_t)&var_10h + iVar9) = iVar1;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x18020d784;
                    iVar8 = fcn.18020ce40(*(int64_t *)((int64_t)&var_10h + iVar9), 
                                          *(int64_t *)((int64_t)&var_18h + iVar9), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar9), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar9), 
                                          *(int64_t *)(&stack0x00000078 + iVar9), *(int64_t *)(&stack0x00000088 + iVar9)
                                          , *(int64_t *)(&stack0x00000090 + iVar9), 
                                          *(int64_t *)(&stack0x00000098 + iVar9), *(int64_t *)(&stack0x000000d8 + iVar9)
                                          , *(int64_t *)((int64_t)&arg_e8h + iVar9), 
                                          *(int64_t *)(&stack0x000000f0 + iVar9), *(int64_t *)(&stack0x00000128 + iVar9)
                                         );
                    if (iVar8 != 0) {
                        *(int64_t *)(in_RCX + 0x50) = *(int64_t *)(in_RCX + 0x50) + 1;
                        *(undefined8 *)(in_RCX + 0x58) = 0;
                        *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x18020d7a0;
                        func_0x000180498030(iVar1, (int64_t)&arg_60h + iVar9, uVar10);
                    }
                }
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x18020d664;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9));
            *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x18020d67c;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                          *(int64_t *)((int64_t)&var_20h + iVar9), *(int64_t *)((int64_t)&arg_28h + iVar9), 
                          *(int64_t *)((int64_t)&arg_40h + iVar9));
            *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x18020d68e;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar9));
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x18020d7e0;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9));
        *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x18020d7f8;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                      *(int64_t *)((int64_t)&var_20h + iVar9), *(int64_t *)((int64_t)&arg_28h + iVar9), 
                      *(int64_t *)((int64_t)&arg_40h + iVar9));
        *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x18020d80a;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar9));
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x18020d7cd;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_a0h + iVar9) ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar9));
    return;
}

