// Chunk 150 - 50 functions

// ============================================================
// Function: FUN_1801fbe95
// Address: 0x1801fbe95
// Size: 801 bytes
// ============================================================
void fcn.1801fbe95(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_d0h)
{
    uint8_t *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t iVar5;
    uint64_t uVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    int64_t *unaff_RDI;
    int64_t unaff_R13;
    int64_t var_20h;
    
    iVar2 = *(int64_t *)(unaff_RBP + 0x30);
    if (iVar2 == 0) {
        func_0x000180229480();
        func_0x0001802295a0(0x1804b8c10, 0x20a, 0x1804b8c30);
        func_0x0001802296d0(0x14, 0xc0103, 0);
    } else {
        iVar5 = func_0x00018020e980(iVar2);
        if (iVar5 < 8) {
            func_0x000180229480();
            func_0x0001802295a0(0x1804b8c10, 0x211, 0x1804b8c30);
            func_0x0001802296d0(0x14, 0xc0103, 0);
        } else {
            iVar8 = (int64_t)iVar5;
            func_0x000180498030(&arg_38h, unaff_RBP + 0x6a, iVar8);
            puVar1 = (uint8_t *)((int64_t)&arg_30h + iVar8 + 7);
            *puVar1 = *puVar1 ^ (uint8_t)arg_c0h;
            puVar1 = (uint8_t *)((int64_t)&arg_30h + iVar8 + 6);
            *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)arg_c0h >> 8);
            puVar1 = (uint8_t *)((int64_t)&arg_30h + iVar8 + 5);
            *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)arg_c0h >> 0x10);
            puVar1 = (uint8_t *)((int64_t)&arg_30h + iVar8 + 4);
            *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)arg_c0h >> 0x18);
            puVar1 = (uint8_t *)((int64_t)&arg_30h + iVar8 + 3);
            *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)arg_c0h >> 0x20);
            puVar1 = (uint8_t *)((int64_t)&arg_30h + iVar8 + 2);
            *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)arg_c0h >> 0x28);
            puVar1 = (uint8_t *)((int64_t)&arg_30h + iVar8 + 1);
            *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)arg_c0h >> 0x30);
            *(uint8_t *)((int64_t)&arg_30h + iVar8) =
                 *(uint8_t *)((int64_t)&arg_30h + iVar8) ^ (uint8_t)((uint64_t)arg_c0h >> 0x38);
            iVar5 = func_0x000180211b70(iVar2, 0, 0, 0, &arg_38h);
            if (iVar5 == 1) {
                var_20h._4_4_ = (undefined4)((uint64_t)&arg_38h >> 0x20);
                var_20h = CONCAT44(var_20h._4_4_, (undefined4)arg_d0h);
                iVar5 = func_0x000180211bb0(iVar2, 0, &arg_30h);
                if (iVar5 == 1) {
                    while( true ) {
                        uVar6 = unaff_RDI[2];
                        if ((uint64_t)unaff_RDI[1] <= uVar6) break;
                        piVar7 = (int64_t *)(*unaff_RDI + 8 + uVar6 * 0x10);
                        while( true ) {
                            iVar8 = *piVar7;
                            iVar3 = unaff_RDI[3];
                            iVar9 = iVar8 - iVar3;
                            if (iVar9 != 0) break;
                            uVar6 = uVar6 + 1;
                            unaff_RDI[3] = unaff_R13;
                            piVar7 = piVar7 + 2;
                            unaff_RDI[2] = uVar6;
                            if ((uint64_t)unaff_RDI[1] <= uVar6) goto code_r0x0001801fc083;
                        }
                        var_20h = CONCAT44(var_20h._4_4_, (int32_t)iVar9);
                        iVar4 = *(int64_t *)(uVar6 * 0x10 + *unaff_RDI);
                        unaff_RDI[4] = unaff_RDI[4] - iVar9;
                        unaff_RDI[3] = iVar8;
                        iVar5 = func_0x000180211bb0(iVar2, *(int64_t *)(unaff_RSI + 0x10) + 0x58 + unaff_RSI, &arg_30h, 
                                                    iVar3 + iVar4, var_20h);
                        if (iVar5 != 1) {
                            func_0x000180229480();
                            func_0x0001802295a0(0x1804b8c10, 0x230, 0x1804b8c30);
                            func_0x0001802296d0(0x14, 0x80006, 0);
                            goto code_r0x0001801fc1b1;
                        }
                        *(int64_t *)(unaff_RSI + 0x10) = *(int64_t *)(unaff_RSI + 0x10) + iVar9;
                    }
code_r0x0001801fc083:
                    iVar5 = func_0x000180211b40(iVar2, 0, (int64_t)&arg_30h + 4);
                    if (iVar5 == 1) {
                        iVar5 = func_0x000180210b80(iVar2, 0x10, *(undefined4 *)(unaff_RBP + 100), 
                                                    *(int64_t *)(unaff_RSI + 0x10) + 0x58 + unaff_RSI, var_20h);
                        if (iVar5 == 1) {
                            *(int64_t *)(unaff_RSI + 0x10) =
                                 *(int64_t *)(unaff_RSI + 0x10) + (uint64_t)*(uint32_t *)(unaff_RBP + 100);
                            iVar5 = func_0x0001801f8a20();
                            if (iVar5 != 0) {
                                *(int64_t *)(unaff_RBP + 0x58) = *(int64_t *)(unaff_RBP + 0x58) + 1;
                            }
                        } else {
                            func_0x000180229480();
                            func_0x0001802295a0(0x1804b8c10, 0x245, 0x1804b8c30);
                            func_0x0001802296d0(0x14, 0x80006, 0);
                        }
                    } else {
                        func_0x000180229480();
                        func_0x0001802295a0(0x1804b8c10, 0x23f, 0x1804b8c30);
                        func_0x0001802296d0(0x14, 0x80006, 0);
                    }
                } else {
                    func_0x000180229480();
                    func_0x0001802295a0(0x1804b8c10, 0x221, 0x1804b8c30);
                    func_0x0001802296d0(0x14, 0x80006, 0);
                }
            } else {
                func_0x000180229480();
                func_0x0001802295a0(0x1804b8c10, 0x21b, 0x1804b8c30);
                func_0x0001802296d0(0x14, 0x80006, 0);
            }
        }
    }
code_r0x0001801fc1b1:
    func_0x000180459870(arg_48h ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_1801fc1b6
// Address: 0x1801fc1b6
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: arg_58h
// WARNING: [rz-ghidra] Removing arg arg_6ah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h
// WARNING: [rz-ghidra] Removing arg arg_64h because it doesn't fit into ProtoModel

void fcn.1801fbe95(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_d0h)
{
    uint8_t *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t iVar5;
    uint64_t uVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    int64_t *unaff_RDI;
    int64_t unaff_R13;
    int64_t var_20h;
    
    iVar2 = *(int64_t *)(unaff_RBP + 0x30);
    if (iVar2 == 0) {
        func_0x000180229480();
        func_0x0001802295a0(0x1804b8c10, 0x20a, 0x1804b8c30);
        func_0x0001802296d0(0x14, 0xc0103, 0);
    } else {
        iVar5 = func_0x00018020e980(iVar2);
        if (iVar5 < 8) {
            func_0x000180229480();
            func_0x0001802295a0(0x1804b8c10, 0x211, 0x1804b8c30);
            func_0x0001802296d0(0x14, 0xc0103, 0);
        } else {
            iVar8 = (int64_t)iVar5;
            func_0x000180498030(&arg_38h, unaff_RBP + 0x6a, iVar8);
            puVar1 = (uint8_t *)((int64_t)&arg_30h + iVar8 + 7);
            *puVar1 = *puVar1 ^ (uint8_t)arg_c0h;
            puVar1 = (uint8_t *)((int64_t)&arg_30h + iVar8 + 6);
            *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)arg_c0h >> 8);
            puVar1 = (uint8_t *)((int64_t)&arg_30h + iVar8 + 5);
            *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)arg_c0h >> 0x10);
            puVar1 = (uint8_t *)((int64_t)&arg_30h + iVar8 + 4);
            *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)arg_c0h >> 0x18);
            puVar1 = (uint8_t *)((int64_t)&arg_30h + iVar8 + 3);
            *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)arg_c0h >> 0x20);
            puVar1 = (uint8_t *)((int64_t)&arg_30h + iVar8 + 2);
            *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)arg_c0h >> 0x28);
            puVar1 = (uint8_t *)((int64_t)&arg_30h + iVar8 + 1);
            *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)arg_c0h >> 0x30);
            *(uint8_t *)((int64_t)&arg_30h + iVar8) =
                 *(uint8_t *)((int64_t)&arg_30h + iVar8) ^ (uint8_t)((uint64_t)arg_c0h >> 0x38);
            iVar5 = func_0x000180211b70(iVar2, 0, 0, 0, &arg_38h);
            if (iVar5 == 1) {
                var_20h._4_4_ = (undefined4)((uint64_t)&arg_38h >> 0x20);
                var_20h = CONCAT44(var_20h._4_4_, (undefined4)arg_d0h);
                iVar5 = func_0x000180211bb0(iVar2, 0, &arg_30h);
                if (iVar5 == 1) {
                    while( true ) {
                        uVar6 = unaff_RDI[2];
                        if ((uint64_t)unaff_RDI[1] <= uVar6) break;
                        piVar7 = (int64_t *)(*unaff_RDI + 8 + uVar6 * 0x10);
                        while( true ) {
                            iVar8 = *piVar7;
                            iVar3 = unaff_RDI[3];
                            iVar9 = iVar8 - iVar3;
                            if (iVar9 != 0) break;
                            uVar6 = uVar6 + 1;
                            unaff_RDI[3] = unaff_R13;
                            piVar7 = piVar7 + 2;
                            unaff_RDI[2] = uVar6;
                            if ((uint64_t)unaff_RDI[1] <= uVar6) goto code_r0x0001801fc083;
                        }
                        var_20h = CONCAT44(var_20h._4_4_, (int32_t)iVar9);
                        iVar4 = *(int64_t *)(uVar6 * 0x10 + *unaff_RDI);
                        unaff_RDI[4] = unaff_RDI[4] - iVar9;
                        unaff_RDI[3] = iVar8;
                        iVar5 = func_0x000180211bb0(iVar2, *(int64_t *)(unaff_RSI + 0x10) + 0x58 + unaff_RSI, &arg_30h, 
                                                    iVar3 + iVar4, var_20h);
                        if (iVar5 != 1) {
                            func_0x000180229480();
                            func_0x0001802295a0(0x1804b8c10, 0x230, 0x1804b8c30);
                            func_0x0001802296d0(0x14, 0x80006, 0);
                            goto code_r0x0001801fc1b1;
                        }
                        *(int64_t *)(unaff_RSI + 0x10) = *(int64_t *)(unaff_RSI + 0x10) + iVar9;
                    }
code_r0x0001801fc083:
                    iVar5 = func_0x000180211b40(iVar2, 0, (int64_t)&arg_30h + 4);
                    if (iVar5 == 1) {
                        iVar5 = func_0x000180210b80(iVar2, 0x10, *(undefined4 *)(unaff_RBP + 100), 
                                                    *(int64_t *)(unaff_RSI + 0x10) + 0x58 + unaff_RSI, var_20h);
                        if (iVar5 == 1) {
                            *(int64_t *)(unaff_RSI + 0x10) =
                                 *(int64_t *)(unaff_RSI + 0x10) + (uint64_t)*(uint32_t *)(unaff_RBP + 100);
                            iVar5 = func_0x0001801f8a20();
                            if (iVar5 != 0) {
                                *(int64_t *)(unaff_RBP + 0x58) = *(int64_t *)(unaff_RBP + 0x58) + 1;
                            }
                        } else {
                            func_0x000180229480();
                            func_0x0001802295a0(0x1804b8c10, 0x245, 0x1804b8c30);
                            func_0x0001802296d0(0x14, 0x80006, 0);
                        }
                    } else {
                        func_0x000180229480();
                        func_0x0001802295a0(0x1804b8c10, 0x23f, 0x1804b8c30);
                        func_0x0001802296d0(0x14, 0x80006, 0);
                    }
                } else {
                    func_0x000180229480();
                    func_0x0001802295a0(0x1804b8c10, 0x221, 0x1804b8c30);
                    func_0x0001802296d0(0x14, 0x80006, 0);
                }
            } else {
                func_0x000180229480();
                func_0x0001802295a0(0x1804b8c10, 0x21b, 0x1804b8c30);
                func_0x0001802296d0(0x14, 0x80006, 0);
            }
        }
    }
code_r0x0001801fc1b1:
    func_0x000180459870(arg_48h ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_1801fc1bb
// Address: 0x1801fc1bb
// Size: 27 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: arg_58h
// WARNING: [rz-ghidra] Removing arg arg_6ah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h
// WARNING: [rz-ghidra] Removing arg arg_64h because it doesn't fit into ProtoModel

void fcn.1801fbe95(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_d0h)
{
    uint8_t *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t iVar5;
    uint64_t uVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    int64_t *unaff_RDI;
    int64_t unaff_R13;
    int64_t var_20h;
    
    iVar2 = *(int64_t *)(unaff_RBP + 0x30);
    if (iVar2 == 0) {
        func_0x000180229480();
        func_0x0001802295a0(0x1804b8c10, 0x20a, 0x1804b8c30);
        func_0x0001802296d0(0x14, 0xc0103, 0);
    } else {
        iVar5 = func_0x00018020e980(iVar2);
        if (iVar5 < 8) {
            func_0x000180229480();
            func_0x0001802295a0(0x1804b8c10, 0x211, 0x1804b8c30);
            func_0x0001802296d0(0x14, 0xc0103, 0);
        } else {
            iVar8 = (int64_t)iVar5;
            func_0x000180498030(&arg_38h, unaff_RBP + 0x6a, iVar8);
            puVar1 = (uint8_t *)((int64_t)&arg_30h + iVar8 + 7);
            *puVar1 = *puVar1 ^ (uint8_t)arg_c0h;
            puVar1 = (uint8_t *)((int64_t)&arg_30h + iVar8 + 6);
            *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)arg_c0h >> 8);
            puVar1 = (uint8_t *)((int64_t)&arg_30h + iVar8 + 5);
            *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)arg_c0h >> 0x10);
            puVar1 = (uint8_t *)((int64_t)&arg_30h + iVar8 + 4);
            *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)arg_c0h >> 0x18);
            puVar1 = (uint8_t *)((int64_t)&arg_30h + iVar8 + 3);
            *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)arg_c0h >> 0x20);
            puVar1 = (uint8_t *)((int64_t)&arg_30h + iVar8 + 2);
            *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)arg_c0h >> 0x28);
            puVar1 = (uint8_t *)((int64_t)&arg_30h + iVar8 + 1);
            *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)arg_c0h >> 0x30);
            *(uint8_t *)((int64_t)&arg_30h + iVar8) =
                 *(uint8_t *)((int64_t)&arg_30h + iVar8) ^ (uint8_t)((uint64_t)arg_c0h >> 0x38);
            iVar5 = func_0x000180211b70(iVar2, 0, 0, 0, &arg_38h);
            if (iVar5 == 1) {
                var_20h._4_4_ = (undefined4)((uint64_t)&arg_38h >> 0x20);
                var_20h = CONCAT44(var_20h._4_4_, (undefined4)arg_d0h);
                iVar5 = func_0x000180211bb0(iVar2, 0, &arg_30h);
                if (iVar5 == 1) {
                    while( true ) {
                        uVar6 = unaff_RDI[2];
                        if ((uint64_t)unaff_RDI[1] <= uVar6) break;
                        piVar7 = (int64_t *)(*unaff_RDI + 8 + uVar6 * 0x10);
                        while( true ) {
                            iVar8 = *piVar7;
                            iVar3 = unaff_RDI[3];
                            iVar9 = iVar8 - iVar3;
                            if (iVar9 != 0) break;
                            uVar6 = uVar6 + 1;
                            unaff_RDI[3] = unaff_R13;
                            piVar7 = piVar7 + 2;
                            unaff_RDI[2] = uVar6;
                            if ((uint64_t)unaff_RDI[1] <= uVar6) goto code_r0x0001801fc083;
                        }
                        var_20h = CONCAT44(var_20h._4_4_, (int32_t)iVar9);
                        iVar4 = *(int64_t *)(uVar6 * 0x10 + *unaff_RDI);
                        unaff_RDI[4] = unaff_RDI[4] - iVar9;
                        unaff_RDI[3] = iVar8;
                        iVar5 = func_0x000180211bb0(iVar2, *(int64_t *)(unaff_RSI + 0x10) + 0x58 + unaff_RSI, &arg_30h, 
                                                    iVar3 + iVar4, var_20h);
                        if (iVar5 != 1) {
                            func_0x000180229480();
                            func_0x0001802295a0(0x1804b8c10, 0x230, 0x1804b8c30);
                            func_0x0001802296d0(0x14, 0x80006, 0);
                            goto code_r0x0001801fc1b1;
                        }
                        *(int64_t *)(unaff_RSI + 0x10) = *(int64_t *)(unaff_RSI + 0x10) + iVar9;
                    }
code_r0x0001801fc083:
                    iVar5 = func_0x000180211b40(iVar2, 0, (int64_t)&arg_30h + 4);
                    if (iVar5 == 1) {
                        iVar5 = func_0x000180210b80(iVar2, 0x10, *(undefined4 *)(unaff_RBP + 100), 
                                                    *(int64_t *)(unaff_RSI + 0x10) + 0x58 + unaff_RSI, var_20h);
                        if (iVar5 == 1) {
                            *(int64_t *)(unaff_RSI + 0x10) =
                                 *(int64_t *)(unaff_RSI + 0x10) + (uint64_t)*(uint32_t *)(unaff_RBP + 100);
                            iVar5 = func_0x0001801f8a20();
                            if (iVar5 != 0) {
                                *(int64_t *)(unaff_RBP + 0x58) = *(int64_t *)(unaff_RBP + 0x58) + 1;
                            }
                        } else {
                            func_0x000180229480();
                            func_0x0001802295a0(0x1804b8c10, 0x245, 0x1804b8c30);
                            func_0x0001802296d0(0x14, 0x80006, 0);
                        }
                    } else {
                        func_0x000180229480();
                        func_0x0001802295a0(0x1804b8c10, 0x23f, 0x1804b8c30);
                        func_0x0001802296d0(0x14, 0x80006, 0);
                    }
                } else {
                    func_0x000180229480();
                    func_0x0001802295a0(0x1804b8c10, 0x221, 0x1804b8c30);
                    func_0x0001802296d0(0x14, 0x80006, 0);
                }
            } else {
                func_0x000180229480();
                func_0x0001802295a0(0x1804b8c10, 0x21b, 0x1804b8c30);
                func_0x0001802296d0(0x14, 0x80006, 0);
            }
        }
    }
code_r0x0001801fc1b1:
    func_0x000180459870(arg_48h ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_1801fc290
// Address: 0x1801fc290
// Size: 387 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined (*) [16] fcn.1801fc290(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined (*pauVar1) [16];
    int64_t iVar2;
    undefined (*pauVar3) [16];
    int64_t in_RCX;
    undefined (**in_RDX) [16];
    undefined (*in_R8) [16];
    uint64_t in_R9;
    bool bVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fc2b0;
    iVar2 = func_0x00018045a350();
    if ((in_R8 != (undefined (*) [16])0x0) && (in_R9 < 0xffffffffffffffa7)) {
        pauVar1 = *(undefined (**) [16])(*in_R8 + 8);
        if (*in_RDX == in_R8) {
            *in_RDX = *(undefined (**) [16])*in_R8;
        }
        if (in_RDX[1] == in_R8) {
            in_RDX[1] = *(undefined (**) [16])(*in_R8 + 8);
        }
        if (*(undefined8 **)(*in_R8 + 8) != (undefined8 *)0x0) {
            **(undefined8 **)(*in_R8 + 8) = *(undefined8 *)*in_R8;
        }
        if (*(int64_t *)*in_R8 != 0) {
            *(undefined8 *)(*(int64_t *)*in_R8 + 8) = *(undefined8 *)(*in_R8 + 8);
        }
        in_RDX[2] = (undefined (*) [16])(in_RDX[2][-1] + 0xf);
        *in_R8 = ZEXT816(0);
        *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1801fc332;
        pauVar3 = (undefined (*) [16])func_0x0001802249c0(in_R8, in_R9 + 0x58, 0x1804b8c10, 0x119);
        if (pauVar3 != (undefined (*) [16])0x0) {
            if (pauVar1 == (undefined (*) [16])0x0) {
                if (*in_RDX != (undefined (*) [16])0x0) {
                    *(undefined (**) [16])(**in_RDX + 8) = pauVar3;
                }
                *(undefined (**) [16])*pauVar3 = *in_RDX;
                *(undefined8 *)(*pauVar3 + 8) = 0;
                bVar4 = in_RDX[1] == (undefined (*) [16])0x0;
                *in_RDX = pauVar3;
            } else {
                *(undefined (**) [16])(*pauVar3 + 8) = pauVar1;
                *(undefined8 *)*pauVar3 = *(undefined8 *)*pauVar1;
                if (*(int64_t *)*pauVar1 != 0) {
                    *(undefined (**) [16])(*(int64_t *)*pauVar1 + 8) = pauVar3;
                }
                *(undefined (**) [16])*pauVar1 = pauVar3;
                bVar4 = in_RDX[1] == pauVar1;
            }
            if (bVar4) {
                in_RDX[1] = pauVar3;
            }
            in_RDX[2] = (undefined (*) [16])(*in_RDX[2] + 1);
            if (*(undefined (**) [16])(in_RCX + 0x3b0) == in_R8) {
                *(undefined (**) [16])(in_RCX + 0x3b0) = pauVar3;
            }
            *(uint64_t *)(pauVar3[1] + 8) = in_R9;
            return pauVar3;
        }
        if (pauVar1 == (undefined (*) [16])0x0) {
            if (*in_RDX != (undefined (*) [16])0x0) {
                *(undefined (**) [16])(**in_RDX + 8) = in_R8;
            }
            *(undefined (**) [16])*in_R8 = *in_RDX;
            *(undefined8 *)(*in_R8 + 8) = 0;
            pauVar1 = in_RDX[1];
            *in_RDX = in_R8;
        } else {
            *(undefined (**) [16])(*in_R8 + 8) = pauVar1;
            *(undefined8 *)*in_R8 = *(undefined8 *)*pauVar1;
            if (*(int64_t *)*pauVar1 != 0) {
                *(undefined (**) [16])(*(int64_t *)*pauVar1 + 8) = in_R8;
            }
            *(undefined (**) [16])*pauVar1 = in_R8;
            pauVar1 = (undefined (*) [16])((int64_t)in_RDX[1] - (int64_t)pauVar1);
        }
        if (pauVar1 == (undefined (*) [16])0x0) {
            in_RDX[1] = in_R8;
        }
        in_RDX[2] = (undefined (*) [16])(*in_RDX[2] + 1);
    }
    return (undefined (*) [16])0x0;
}

// ============================================================
// Function: FUN_1801fc420
// Address: 0x1801fc420
// Size: 1137 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h

undefined8
fcn.1801fc420(int64_t arg1, int64_t arg2, int64_t placeholder_2, int64_t arg4, undefined8 placeholder_4, int64_t arg_30h
             , int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_90h,
             int64_t arg_b8h, int64_t arg_c0h, int64_t arg_f8h, int64_t arg_100h, int64_t arg_108h, int64_t arg_110h,
             int64_t arg_118h, int64_t arg_120h, int64_t arg_128h, int64_t arg_138h)
{
    undefined uVar1;
    undefined4 uVar2;
    uint32_t *puVar3;
    uint64_t uVar4;
    code *pcVar5;
    undefined auVar6 [16];
    bool bVar7;
    uint32_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint64_t uVar12;
    undefined8 uVar13;
    uint32_t uVar14;
    int64_t *piVar15;
    uint64_t uVar16;
    int64_t iVar17;
    undefined8 unaff_RSI;
    int64_t iVar18;
    undefined8 unaff_RDI;
    int64_t iVar19;
    uint64_t uVar20;
    undefined8 unaff_R15;
    int64_t iVar21;
    int64_t iVar22;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_28h;
    
    var_20h._0_4_ = (undefined4)arg4;
    uStack_30 = 0x1801fc441;
    var_8h = arg1;
    var_10h = arg2;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    puVar3 = *(uint32_t **)((int64_t)&arg_118h + iVar10);
    uVar4 = *(uint64_t *)((int64_t)&arg_128h + iVar10);
    iVar11 = 0;
    uVar20 = arg4 & 0xffffffff;
    if (((*puVar3 & 0xff) == 4) || ((*puVar3 & 0xff) == 6)) {
        bVar7 = false;
        uVar16 = 7;
        *(undefined4 *)((int64_t)&arg_118h + iVar10) = 0;
    } else {
        bVar7 = true;
        *(undefined4 *)((int64_t)&arg_118h + iVar10) = 1;
        uVar16 = 0x15;
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801fc493;
        iVar11 = fcn.18020d3c0(arg1 + 0x10, arg4 & 0xffffffff, 1);
        if (iVar11 == 0) {
            return 0;
        }
        arg1 = *(int64_t *)((int64_t)&arg_f8h + iVar10);
        uVar20 = (uint64_t)*(uint32_t *)((int64_t)&arg_110h + iVar10);
    }
    *(undefined8 *)((int64_t)&var_20h + iVar10) = *(undefined8 *)(placeholder_2 + 0x10);
    uVar12 = *(int64_t *)(placeholder_2 + 0x18) - *(int64_t *)((int64_t)&var_20h + iVar10);
    *(undefined8 *)((int64_t)&arg_108h + iVar10) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_c0h + iVar10) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_b8h + iVar10) = unaff_R15;
    *(uint64_t *)((int64_t)&var_18h + iVar10) = uVar12;
    if (uVar12 < uVar16) {
code_r0x0001801fc501:
        uVar13 = 0xfffffffe;
        goto code_r0x0001801fc860;
    }
    uVar8 = *puVar3;
    if ((char)uVar8 == '\x05') {
        *puVar3 = ((uint32_t)*(uint8_t *)(iVar11 + 0x50) << 9 ^ uVar8) & 0x200 ^ uVar8;
    }
    iVar11 = *(int64_t *)((int64_t)&arg_120h + iVar10);
    uVar12 = 0;
    iVar18 = 0;
    *(int64_t *)((int64_t)&arg_30h + iVar10) = iVar11;
    iVar17 = 0;
    *(uint64_t *)((int64_t)&arg_38h + iVar10) = uVar4;
    uVar16 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar10) = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar10) = 0;
    if (3 < uVar4) {
        iVar21 = 0;
        iVar22 = 0;
        iVar17 = 0;
        iVar19 = 0;
        piVar15 = (int64_t *)(iVar11 + 0x18);
        do {
            uVar16 = uVar16 + 4;
            iVar21 = iVar21 + piVar15[-2];
            iVar22 = iVar22 + *piVar15;
            iVar17 = iVar17 + piVar15[2];
            iVar19 = iVar19 + piVar15[4];
            piVar15 = piVar15 + 8;
        } while (uVar16 < (uVar4 & 0xfffffffffffffffc));
        auVar6._8_4_ = (int32_t)(iVar19 + iVar22);
        auVar6._0_8_ = iVar17 + iVar21;
        auVar6._12_4_ = (int32_t)((uint64_t)(iVar19 + iVar22) >> 0x20);
        iVar17 = iVar17 + iVar21 + auVar6._8_8_;
    }
    iVar19 = 0;
    iVar21 = 0;
    if (uVar16 < uVar4) {
        if (uVar4 - uVar16 < 2) {
code_r0x0001801fc606:
            iVar17 = iVar17 + *(int64_t *)(uVar16 * 0x10 + 8 + iVar11);
        } else {
            piVar15 = (int64_t *)(uVar16 * 0x10 + 0x18 + iVar11);
            iVar22 = ((uVar4 - uVar16) - 2 >> 1) + 1;
            uVar16 = uVar16 + iVar22 * 2;
            do {
                iVar19 = iVar19 + piVar15[-2];
                iVar21 = iVar21 + *piVar15;
                piVar15 = piVar15 + 4;
                iVar22 = iVar22 + -1;
            } while (iVar22 != 0);
            if (uVar16 < uVar4) goto code_r0x0001801fc606;
        }
        iVar17 = iVar17 + iVar21 + iVar19;
    }
    *(int64_t *)((int64_t)&arg_50h + iVar10) = iVar17;
    if (iVar17 != 0) {
        if (bVar7) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801fc63b;
            iVar19 = fcn.18020d3c0(arg1 + 0x10, uVar20, 1);
            if (iVar19 == 0) {
                iVar17 = 0;
            } else {
                uVar2 = *(undefined4 *)(iVar19 + 0x60);
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801fc64d;
                uVar8 = fcn.1801f9ab0(uVar2);
                iVar17 = (uint64_t)uVar8 + iVar17;
            }
        }
        uVar1 = *(undefined *)(puVar3 + 2);
        *(undefined8 *)(puVar3 + 0x14) = 0;
        *(int64_t *)(puVar3 + 0x12) = iVar17;
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801fc66d;
        iVar19 = fcn.1801f97e0(uVar1, puVar3);
        if (iVar19 != 0) {
            if (*(uint64_t *)((int64_t)&var_18h + iVar10) < (uint64_t)(iVar19 + iVar17)) goto code_r0x0001801fc501;
            uVar8 = *puVar3;
            uVar14 = uVar8 & 0xff;
            if ((uVar14 == 4) || (uVar14 == 6)) {
                iVar17 = *(int64_t *)((int64_t)&arg_100h + iVar10);
            } else {
                iVar17 = *(int64_t *)((int64_t)&arg_100h + iVar10);
                uVar13 = *(undefined8 *)(iVar17 + 0x28);
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801fc6b6;
                iVar9 = fcn.1801f9770(uVar13, (int64_t)puVar3 + 0x32, uVar8 >> 10 & 0xf);
                if (iVar9 == 0) goto code_r0x0001801fc85b;
            }
            iVar19 = placeholder_2 + 0x58 + *(int64_t *)(placeholder_2 + 0x10);
            *(undefined8 *)((int64_t)&var_18h + iVar10) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801fc6ef;
            iVar9 = fcn.180244550(*(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)((int64_t)&var_10h + iVar10), 
                                  *(int64_t *)((int64_t)&var_20h + iVar10), *(int64_t *)(&stack0x00000028 + iVar10), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar10));
            if (iVar9 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801fc714;
                iVar9 = fcn.1801f93b0(*(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)((int64_t)&var_10h + iVar10)
                                      , *(int64_t *)((int64_t)&var_18h + iVar10), 
                                      *(int64_t *)((int64_t)&var_20h + iVar10));
                if (iVar9 != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801fc72e;
                    iVar9 = fcn.1802442e0((int64_t)&arg_58h + iVar10, (int64_t)&var_18h + iVar10);
                    if (iVar9 != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801fc743;
                        fcn.180244200(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10));
                        iVar21 = *(int64_t *)((int64_t)&arg_f8h + iVar10);
                        pcVar5 = *(code **)(iVar21 + 1000);
                        if (pcVar5 != (code *)0x0) {
                            *(undefined8 *)((int64_t)&var_8h + iVar10) = *(undefined8 *)(iVar21 + 0x3f0);
                            *(undefined8 *)(&stack0x00000000 + iVar10) = *(undefined8 *)(iVar21 + 0x3f8);
                            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar10) =
                                 *(undefined8 *)((int64_t)&var_18h + iVar10);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801fc78c;
                            (*pcVar5)(1, 1, 0x201, iVar19);
                        }
                        iVar21 = *(int64_t *)(placeholder_2 + 0x10) + *(int64_t *)((int64_t)&var_18h + iVar10);
                        *(int64_t *)(placeholder_2 + 0x10) = iVar21;
                        if (*(int32_t *)((int64_t)&arg_118h + iVar10) == 0) {
                            do {
                                iVar17 = iVar18;
                                if (uVar4 <= uVar12) {
                                    return 1;
                                }
                                while( true ) {
                                    iVar18 = *(int64_t *)(iVar11 + 8 + uVar12 * 0x10);
                                    iVar19 = iVar18 - iVar17;
                                    if (iVar19 != 0) break;
                                    uVar12 = uVar12 + 1;
                                    iVar17 = 0;
                                    if (uVar4 <= uVar12) {
                                        return 1;
                                    }
                                }
                                iVar21 = *(int64_t *)(iVar11 + uVar12 * 0x10);
                                iVar22 = *(int64_t *)(placeholder_2 + 0x10);
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801fc804;
                                fcn.180498030(iVar22 + 0x58 + placeholder_2, iVar21 + iVar17, iVar19);
                                *(int64_t *)(placeholder_2 + 0x10) = *(int64_t *)(placeholder_2 + 0x10) + iVar19;
                            } while( true );
                        }
                        *(int64_t *)((int64_t)&var_10h + iVar10) = (int64_t)&arg_90h + iVar10;
                        *(int64_t *)((int64_t)&var_8h + iVar10) = placeholder_2 + 0x58 + (iVar21 - iVar19);
                        uVar13 = *(undefined8 *)(iVar17 + 0x28);
                        *(int64_t *)(&stack0x00000000 + iVar10) = iVar19;
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar10) = uVar13;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801fc843;
                        iVar9 = fcn.1801fbdb0(*(int64_t *)(&stack0x00000000 + iVar10), 
                                              *(int64_t *)(&stack0x00000068 + iVar10), 
                                              *(int64_t *)(&stack0x00000078 + iVar10));
                        if (iVar9 != 0) {
                            return 1;
                        }
                        goto code_r0x0001801fc85b;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801fc85b;
                fcn.180244200(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10));
            }
        }
    }
code_r0x0001801fc85b:
    uVar13 = 0xffffffff;
code_r0x0001801fc860:
    *(undefined8 *)(placeholder_2 + 0x10) = *(undefined8 *)((int64_t)&var_20h + iVar10);
    return uVar13;
}

// ============================================================
// Function: FUN_1801fc950
// Address: 0x1801fc950
// Size: 119 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801fc950(int64_t arg_28h, int64_t arg_30h)
{
    uint8_t *puVar1;
    int64_t iVar2;
    undefined8 uVar3;
    uint8_t **in_RCX;
    undefined8 *in_RDX;
    uint8_t *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fc965;
    iVar2 = fcn.18045a350();
    if (in_RCX[1] != (uint8_t *)0x0) {
        puVar1 = *in_RCX;
        puVar4 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar1 >> 6));
        if (puVar4 <= in_RCX[1]) {
            *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1801fc996;
            uVar3 = fcn.180274e70(puVar1);
            *in_RDX = uVar3;
            *in_RCX = *in_RCX + (int64_t)puVar4;
            in_RCX[1] = in_RCX[1] + -(int64_t)puVar4;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801fc9d0
// Address: 0x1801fc9d0
// Size: 122 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.1801fc9d0(int64_t arg_28h, int64_t arg_30h)
{
    uint8_t *puVar1;
    int64_t iVar2;
    uint8_t **in_RCX;
    int64_t in_RDX;
    uint8_t *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fc9e5;
    iVar2 = fcn.18045a350();
    if (in_RCX[1] != (uint8_t *)0x0) {
        puVar1 = *in_RCX;
        puVar3 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar1 >> 6));
        if (puVar3 <= in_RCX[1]) {
            *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1801fca16;
            iVar2 = fcn.180274e70(puVar1);
            *in_RCX = *in_RCX + (int64_t)puVar3;
            in_RCX[1] = in_RCX[1] + -(int64_t)puVar3;
            return iVar2 == in_RDX;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1801fcd10
// Address: 0x1801fcd10
// Size: 870 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801fcd10(int64_t arg4, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h)
{
    uint8_t *puVar1;
    undefined auVar2 [16];
    undefined auVar3 [16];
    int32_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t *puVar9;
    int64_t iVar10;
    uint8_t **in_RCX;
    uint64_t uVar11;
    uint8_t in_DL;
    uint8_t *puVar12;
    uint64_t uVar13;
    uint8_t *puVar14;
    uint64_t **in_R8;
    uint64_t uVar15;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_40;
    int64_t var_18h;
    
    uStack_40 = 0x1801fcd2f;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX[1] != (uint8_t *)0x0) {
        puVar1 = *in_RCX;
        puVar12 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar1 >> 6));
        if (puVar12 <= in_RCX[1]) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801fcd6b;
            uVar6 = fcn.180274e70(puVar1);
            *in_RCX = *in_RCX + (int64_t)puVar12;
            puVar12 = in_RCX[1] + -(int64_t)puVar12;
            puVar1 = *in_RCX;
            *(uint64_t *)((int64_t)&var_18h + iVar5) = uVar6;
            in_RCX[1] = puVar12;
            if ((((uVar6 & 0xfffffffffffffffe) == 2) && (puVar12 != (uint8_t *)0x0)) &&
               (puVar14 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar1 >> 6)), puVar14 <= puVar12)) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801fcdb8;
                uVar6 = fcn.180274e70(puVar1);
                *in_RCX = *in_RCX + (int64_t)puVar14;
                puVar12 = in_RCX[1] + -(int64_t)puVar14;
                puVar1 = *in_RCX;
                in_RCX[1] = puVar12;
                if ((puVar12 != (uint8_t *)0x0) &&
                   (puVar14 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar1 >> 6)), puVar14 <= puVar12)) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801fcdf5;
                    uVar7 = fcn.180274e70(puVar1);
                    *in_RCX = *in_RCX + (int64_t)puVar14;
                    puVar12 = in_RCX[1] + -(int64_t)puVar14;
                    puVar1 = *in_RCX;
                    in_RCX[1] = puVar12;
                    if ((puVar12 != (uint8_t *)0x0) &&
                       (puVar14 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar1 >> 6)), puVar14 <= puVar12)) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801fce32;
                        uVar8 = fcn.180274e70(puVar1);
                        *in_RCX = *in_RCX + (int64_t)puVar14;
                        in_RCX[1] = in_RCX[1] + -(int64_t)puVar14;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801fce49;
                        iVar4 = fcn.1801fc950(*(int64_t *)((int64_t)&var_18h + iVar5), 
                                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar5));
                        if ((iVar4 != 0) && (*(uint64_t *)((int64_t)&arg_38h + iVar5) <= uVar6)) {
                            uVar13 = uVar6 - *(uint64_t *)((int64_t)&arg_38h + iVar5);
                            if (in_R8 != (uint64_t **)0x0) {
                                uVar15 = 1LL << (in_DL & 0x3f);
                                auVar2._8_8_ = 0;
                                auVar2._0_8_ = uVar15;
                                uVar15 = uVar15 * uVar7;
                                if ((uVar15 == 0) ||
                                   (auVar3._8_8_ = 0, auVar3._0_8_ = uVar15, puVar9 = (uint64_t *)0xffffffffffffffff,
                                   999 < SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar3, 0))) {
                                    puVar9 = (uint64_t *)(uVar15 * 1000);
                                }
                                in_R8[2] = puVar9;
                                if (SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar2, 0) < uVar7) {
                                    in_R8[2] = (uint64_t *)0xffffffffffffffff;
                                }
                                if (in_R8[1] != (uint64_t *)0x0) {
                                    (*in_R8)[1] = uVar6;
                                    **in_R8 = uVar13;
                                }
                            }
                            uVar7 = 0;
                            uVar6 = uVar7;
                            if (uVar8 != 0) {
                                do {
                                    if (in_RCX[1] == (uint8_t *)0x0) {
                                        return 0;
                                    }
                                    puVar1 = *in_RCX;
                                    puVar12 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar1 >> 6));
                                    if (in_RCX[1] < puVar12) {
                                        return 0;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801fcf22;
                                    iVar10 = fcn.180274e70(puVar1);
                                    *in_RCX = *in_RCX + (int64_t)puVar12;
                                    puVar12 = in_RCX[1] + -(int64_t)puVar12;
                                    puVar1 = *in_RCX;
                                    in_RCX[1] = puVar12;
                                    if (puVar12 == (uint8_t *)0x0) {
                                        return 0;
                                    }
                                    puVar14 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar1 >> 6));
                                    if (puVar12 < puVar14) {
                                        return 0;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801fcf61;
                                    uVar15 = fcn.180274e70(puVar1);
                                    *in_RCX = *in_RCX + (int64_t)puVar14;
                                    in_RCX[1] = in_RCX[1] + -(int64_t)puVar14;
                                    uVar11 = (uVar13 - iVar10) - 2;
                                    if (uVar13 < iVar10 + 2U) {
                                        return 0;
                                    }
                                    if (uVar11 < uVar15) {
                                        return 0;
                                    }
                                    if ((in_R8 != (uint64_t **)0x0) && ((uint64_t *)(uVar7 + 1) < in_R8[1])) {
                                        uVar13 = uVar11 - uVar15;
                                        *(uint64_t *)(uVar6 + 0x10 + (int64_t)*in_R8) = uVar13;
                                        *(uint64_t *)(uVar6 + 0x18 + (int64_t)*in_R8) = uVar11;
                                    }
                                    uVar7 = uVar7 + 1;
                                    uVar6 = uVar6 + 0x10;
                                } while (uVar7 < uVar8);
                            }
                            if ((in_R8 != (uint64_t **)0x0) && ((uint64_t *)(uVar8 + 1) < in_R8[1])) {
                                in_R8[1] = (uint64_t *)(uVar8 + 1);
                            }
                            if (*(int64_t **)((int64_t)&arg_50h + iVar5) != (int64_t *)0x0) {
                                **(int64_t **)((int64_t)&arg_50h + iVar5) = uVar8 + 1;
                            }
                            if (*(int64_t *)((int64_t)&var_18h + iVar5) != 3) {
                                if (in_R8 != (uint64_t **)0x0) {
                                    *(uint32_t *)(in_R8 + 6) = *(uint32_t *)(in_R8 + 6) & 0xfffffffe;
                                }
                                return 1;
                            }
                            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801fcffe;
                            iVar4 = fcn.1801fc950(*(int64_t *)((int64_t)&var_18h + iVar5), 
                                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar5));
                            if (iVar4 != 0) {
                                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801fd00f;
                                iVar4 = fcn.1801fc950(*(int64_t *)((int64_t)&var_18h + iVar5), 
                                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar5));
                                if (iVar4 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801fd020;
                                    iVar4 = fcn.1801fc950(*(int64_t *)((int64_t)&var_18h + iVar5), 
                                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar5));
                                    if (iVar4 != 0) {
                                        if (in_R8 == (uint64_t **)0x0) {
                                            return 1;
                                        }
                                        puVar9 = *(uint64_t **)((int64_t)&arg_38h + iVar5);
                                        *(uint32_t *)(in_R8 + 6) = *(uint32_t *)(in_R8 + 6) | 1;
                                        in_R8[3] = puVar9;
                                        in_R8[4] = *(uint64_t **)((int64_t)&var_18h + iVar5);
                                        in_R8[5] = *(uint64_t **)(&stack0xfffffffffffffff0 + iVar5);
                                        return 1;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801fd080
// Address: 0x1801fd080
// Size: 251 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801fd080(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    uint8_t *puVar4;
    uint8_t **in_RCX;
    uint32_t *in_RDX;
    uint8_t *puVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fd09a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX[1] != (uint8_t *)0x0) {
        puVar4 = *in_RCX;
        puVar5 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar4 >> 6));
        if (puVar5 <= in_RCX[1]) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd0cb;
            uVar3 = fcn.180274e70(puVar4);
            *in_RCX = *in_RCX + (int64_t)puVar5;
            in_RCX[1] = in_RCX[1] + -(int64_t)puVar5;
            if ((uVar3 & 0xfffffffffffffffe) == 0x1c) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd0eb;
                iVar1 = fcn.1801fc950(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar2));
                if (iVar1 != 0) {
                    *in_RDX = *in_RDX ^ ((uint32_t)uVar3 ^ *in_RDX) & 1;
                    if ((uVar3 & 1) == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd10a;
                        iVar1 = fcn.1801fc950(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar2));
                        if (iVar1 == 0) {
                            return 0;
                        }
                    } else {
                        *(undefined8 *)(in_RDX + 4) = 0;
                    }
                    if (in_RCX[1] != (uint8_t *)0x0) {
                        puVar4 = *in_RCX;
                        puVar5 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar4 >> 6));
                        if (puVar5 <= in_RCX[1]) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd155;
                            puVar4 = (uint8_t *)fcn.180274e70(puVar4);
                            *in_RCX = *in_RCX + (int64_t)puVar5;
                            in_RCX[1] = in_RCX[1] + -(int64_t)puVar5;
                            if (puVar4 <= in_RCX[1]) {
                                *(uint8_t **)(in_RDX + 6) = *in_RCX;
                                *in_RCX = *in_RCX + (int64_t)puVar4;
                                in_RCX[1] = in_RCX[1] + -(int64_t)puVar4;
                                *(uint8_t **)(in_RDX + 8) = puVar4;
                                return 1;
                            }
                        }
                    }
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801fd180
// Address: 0x1801fd180
// Size: 188 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801fd180(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint64_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t *in_RCX;
    int32_t in_EDX;
    int64_t *in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fd19a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fd1af;
    iVar2 = fcn.1801fc9d0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fd1be;
        iVar2 = fcn.1801fc950(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fd1ce;
            iVar2 = fcn.1801fc950(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            if ((iVar2 != 0) && (uVar1 = in_R8[1], *in_R8 + uVar1 < 0x4000000000000000)) {
                if (in_EDX != 0) {
                    in_R8[2] = 0;
                    return 1;
                }
                if (uVar1 <= (uint64_t)in_RCX[1]) {
                    in_R8[2] = *in_RCX;
                    if (uVar1 <= (uint64_t)in_RCX[1]) {
                        *in_RCX = *in_RCX + uVar1;
                        in_RCX[1] = in_RCX[1] - uVar1;
                        return 1;
                    }
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801fd240
// Address: 0x1801fd240
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1801fd240(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fd250;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd263;
    iVar1 = fcn.1801fc9d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd272;
        iVar1 = fcn.1801fc950(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
        return iVar1 != 0;
    }
    return false;
}

// ============================================================
// Function: FUN_1801fd2a0
// Address: 0x1801fd2a0
// Size: 27 bytes
// ============================================================
bool fcn.1801fd2a0(uint8_t **param_1)
{
    uint8_t *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    uint8_t *puVar5;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar4 = 0x1e;
    *(undefined8 *)(&stack0x00000030 + iVar3) = unaff_RBX;
    *(undefined8 *)(&stack0x00000038 + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1801fc9e5;
    iVar2 = fcn.18045a350();
    if (param_1[1] != (uint8_t *)0x0) {
        puVar1 = *param_1;
        puVar5 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar1 >> 6));
        if (puVar5 <= param_1[1]) {
            *(undefined8 *)((int64_t)auStackX_18 + (iVar3 - iVar2)) = 0x1801fca16;
            iVar3 = fcn.180274e70(puVar1);
            *param_1 = *param_1 + (int64_t)puVar5;
            param_1[1] = param_1[1] + -(int64_t)puVar5;
            return iVar3 == iVar4;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1801fd2c0
// Address: 0x1801fd2c0
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1801fd2c0(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fd2d0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd2e3;
    iVar1 = fcn.1801fc9d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd2f2;
        iVar1 = fcn.1801fc950(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
        return iVar1 != 0;
    }
    return false;
}

// ============================================================
// Function: FUN_1801fd320
// Address: 0x1801fd320
// Size: 116 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.1801fd320(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fd335;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd34b;
    iVar1 = fcn.1801fc9d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd35a;
        iVar1 = fcn.1801fc950(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd369;
            iVar1 = fcn.1801fc950(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            return iVar1 != 0;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1801fd3a0
// Address: 0x1801fd3a0
// Size: 141 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.1801fd3a0(int64_t arg_28h, int64_t arg_30h)
{
    uint8_t *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint8_t **in_RCX;
    uint8_t *puVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fd3b5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX[1] != (uint8_t *)0x0) {
        puVar1 = *in_RCX;
        puVar5 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar1 >> 6));
        if (puVar5 <= in_RCX[1]) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fd3e6;
            uVar4 = fcn.180274e70(puVar1);
            *in_RCX = *in_RCX + (int64_t)puVar5;
            in_RCX[1] = in_RCX[1] + -(int64_t)puVar5;
            if ((uVar4 & 0xfffffffffffffffe) == 0x12) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fd402;
                iVar2 = fcn.1801fc950(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
                return iVar2 != 0;
            }
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1801fd430
// Address: 0x1801fd430
// Size: 237 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801fd430(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint8_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint8_t **in_RCX;
    uint64_t *in_RDX;
    uint32_t uVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fd44a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fd45d;
    iVar2 = fcn.1801fc9d0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fd470;
        iVar2 = fcn.1801fc950(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fd484;
            iVar2 = fcn.1801fc950(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            if (((iVar2 != 0) && (in_RDX[1] <= *in_RDX)) && (in_RCX[1] != (uint8_t *)0x0)) {
                uVar1 = **in_RCX;
                *in_RCX = *in_RCX + 1;
                in_RCX[1] = in_RCX[1] + -1;
                if (uVar1 - 1 < 0x14) {
                    *(uint8_t *)(in_RDX + 2) = uVar1;
                    uVar4 = (uint32_t)uVar1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fd4c9;
                    iVar2 = func_0x0001801b4900(in_RCX, (int64_t)in_RDX + 0x11, uVar4);
                    if (iVar2 != 0) {
                        if (uVar4 < 0x14) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fd4e9;
                            func_0x0001804986e0((int64_t)in_RDX + (uint64_t)uVar1 + 0x11, 0, 0x14 - uVar4);
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fd4fb;
                        iVar2 = func_0x0001801b4900(in_RCX, (int64_t)in_RDX + 0x25, 0x10);
                        if (iVar2 != 0) {
                            return 1;
                        }
                    }
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801fd520
// Address: 0x1801fd520
// Size: 158 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801fd520(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint8_t *puVar3;
    uint8_t **in_RCX;
    uint8_t **in_RDX;
    uint8_t *puVar4;
    uint8_t **in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fd53b;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd551;
    iVar1 = fcn.1801fc9d0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2));
    if ((iVar1 != 0) && (in_RCX[1] != (uint8_t *)0x0)) {
        puVar3 = *in_RCX;
        puVar4 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar3 >> 6));
        if (puVar4 <= in_RCX[1]) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd57c;
            puVar3 = (uint8_t *)fcn.180274e70(puVar3);
            *in_RCX = *in_RCX + (int64_t)puVar4;
            in_RCX[1] = in_RCX[1] + -(int64_t)puVar4;
            *in_RDX = *in_RCX;
            *in_R8 = puVar3;
            if (puVar3 <= in_RCX[1]) {
                *in_RCX = *in_RCX + (int64_t)puVar3;
                in_RCX[1] = in_RCX[1] + -(int64_t)puVar3;
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801fd5c0
// Address: 0x1801fd5c0
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1801fd5c0(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fd5d0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd5e3;
    iVar1 = fcn.1801fc9d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd5f2;
        iVar1 = fcn.1801fc8a0(in_RCX, in_RDX);
        return iVar1 != 0;
    }
    return false;
}

// ============================================================
// Function: FUN_1801fd620
// Address: 0x1801fd620
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1801fd620(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fd630;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd643;
    iVar1 = fcn.1801fc9d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd652;
        iVar1 = fcn.1801fc8a0(in_RCX, in_RDX);
        return iVar1 != 0;
    }
    return false;
}

// ============================================================
// Function: FUN_1801fd680
// Address: 0x1801fd680
// Size: 27 bytes
// ============================================================
bool fcn.1801fd680(uint8_t **param_1)
{
    uint8_t *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    uint8_t *puVar5;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar4 = 1;
    *(undefined8 *)(&stack0x00000030 + iVar3) = unaff_RBX;
    *(undefined8 *)(&stack0x00000038 + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1801fc9e5;
    iVar2 = fcn.18045a350();
    if (param_1[1] != (uint8_t *)0x0) {
        puVar1 = *param_1;
        puVar5 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar1 >> 6));
        if (puVar5 <= param_1[1]) {
            *(undefined8 *)((int64_t)auStackX_18 + (iVar3 - iVar2)) = 0x1801fca16;
            iVar3 = fcn.180274e70(puVar1);
            *param_1 = *param_1 + (int64_t)puVar5;
            param_1[1] = param_1[1] + -(int64_t)puVar5;
            return iVar3 == iVar4;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1801fd6a0
// Address: 0x1801fd6a0
// Size: 115 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1801fd6a0(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fd6b0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd6c3;
    iVar1 = fcn.1801fc9d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd6d2;
        iVar1 = fcn.1801fc950(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd6e2;
            iVar1 = fcn.1801fc950(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd6f2;
                iVar1 = fcn.1801fc950(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
                return iVar1 != 0;
            }
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1801fd720
// Address: 0x1801fd720
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1801fd720(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fd730;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd743;
    iVar1 = fcn.1801fc9d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd752;
        iVar1 = fcn.1801fc950(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
        return iVar1 != 0;
    }
    return false;
}

// ============================================================
// Function: FUN_1801fd780
// Address: 0x1801fd780
// Size: 99 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1801fd780(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fd790;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd7a3;
    iVar1 = fcn.1801fc9d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd7b2;
        iVar1 = fcn.1801fc950(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd7c2;
            iVar1 = fcn.1801fc950(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            return iVar1 != 0;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1801fd7f0
// Address: 0x1801fd7f0
// Size: 352 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801fd7f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint8_t *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    uint8_t **in_RCX;
    int32_t in_EDX;
    uint8_t *puVar6;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801fd80e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX[1] != (uint8_t *)0x0) {
        puVar1 = *in_RCX;
        puVar6 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar1 >> 6));
        if (puVar6 <= in_RCX[1]) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801fd842;
            uVar4 = fcn.180274e70(puVar1);
            *in_RCX = *in_RCX + (int64_t)puVar6;
            in_RCX[1] = in_RCX[1] + -(int64_t)puVar6;
            if ((uVar4 & 0xfffffffffffffff8) == 8) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801fd861;
                iVar2 = fcn.1801fc950(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
                if (iVar2 != 0) {
                    if ((uVar4 & 4) == 0) {
                        *(undefined8 *)(in_R8 + 8) = 0;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801fd877;
                        iVar2 = fcn.1801fc950(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                              *(int64_t *)((int64_t)&var_10h + iVar3));
                        if (iVar2 == 0) {
                            return 0;
                        }
                    }
                    uVar5 = (uint32_t)((uVar4 & 2) != 0) | *(uint32_t *)(in_R8 + 0x20) & 0xfffffffe;
                    *(uint32_t *)(in_R8 + 0x20) = ((int32_t)uVar4 * 2 ^ uVar5) & 2 ^ uVar5;
                    if ((uVar4 & 2) == 0) {
                        if (in_EDX == 0) {
                            *(uint8_t **)(in_R8 + 0x10) = in_RCX[1];
                        } else {
                            *(undefined8 *)(in_R8 + 0x10) = 0;
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801fd8d6;
                        iVar2 = fcn.1801fc950(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                              *(int64_t *)((int64_t)&var_10h + iVar3));
                        if (iVar2 == 0) {
                            return 0;
                        }
                    }
                    puVar1 = *(uint8_t **)(in_R8 + 0x10);
                    if (puVar1 + *(int64_t *)(in_R8 + 8) < (uint8_t *)0x4000000000000000) {
                        if (in_EDX != 0) {
                            *(undefined8 *)(in_R8 + 0x18) = 0;
                            return 1;
                        }
                        *(uint8_t **)(in_R8 + 0x18) = *in_RCX;
                        if (puVar1 <= in_RCX[1]) {
                            *in_RCX = *in_RCX + (int64_t)puVar1;
                            in_RCX[1] = in_RCX[1] + -(int64_t)puVar1;
                            return 1;
                        }
                    }
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801fd950
// Address: 0x1801fd950
// Size: 116 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.1801fd950(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fd965;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd97b;
    iVar1 = fcn.1801fc9d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd98a;
        iVar1 = fcn.1801fc950(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fd999;
            iVar1 = fcn.1801fc950(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            return iVar1 != 0;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1801fd9d0
// Address: 0x1801fd9d0
// Size: 141 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.1801fd9d0(int64_t arg_28h, int64_t arg_30h)
{
    uint8_t *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint8_t **in_RCX;
    uint8_t *puVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fd9e5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX[1] != (uint8_t *)0x0) {
        puVar1 = *in_RCX;
        puVar5 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar1 >> 6));
        if (puVar5 <= in_RCX[1]) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fda16;
            uVar4 = fcn.180274e70(puVar1);
            *in_RCX = *in_RCX + (int64_t)puVar5;
            in_RCX[1] = in_RCX[1] + -(int64_t)puVar5;
            if ((uVar4 & 0xfffffffffffffffe) == 0x16) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fda32;
                iVar2 = fcn.1801fc950(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
                return iVar2 != 0;
            }
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1801fdaa0
// Address: 0x1801fdaa0
// Size: 213 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint8_t * fcn.1801fdaa0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint8_t *puVar1;
    int64_t iVar2;
    undefined8 uVar3;
    uint8_t **in_RCX;
    undefined8 *in_RDX;
    uint8_t *puVar4;
    uint8_t *puVar5;
    uint8_t **in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801fdabe;
    iVar2 = fcn.18045a350();
    if (in_RCX[1] != (uint8_t *)0x0) {
        puVar1 = *in_RCX;
        puVar4 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar1 >> 6));
        if (puVar4 <= in_RCX[1]) {
            *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x1801fdaf8;
            uVar3 = fcn.180274e70(puVar1);
            *in_RCX = *in_RCX + (int64_t)puVar4;
            puVar4 = in_RCX[1] + -(int64_t)puVar4;
            puVar1 = *in_RCX;
            in_RCX[1] = puVar4;
            if ((puVar4 != (uint8_t *)0x0) &&
               (puVar5 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar1 >> 6)), puVar5 <= puVar4)) {
                *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x1801fdb26;
                puVar4 = (uint8_t *)fcn.180274e70(puVar1);
                *in_RCX = *in_RCX + (int64_t)puVar5;
                puVar5 = in_RCX[1] + -(int64_t)puVar5;
                puVar1 = *in_RCX;
                in_RCX[1] = puVar5;
                if (puVar4 <= puVar5) {
                    *in_RCX = puVar1 + (int64_t)puVar4;
                    in_RCX[1] = puVar5 + -(int64_t)puVar4;
                    *in_R8 = puVar4;
                    if (in_RDX == (undefined8 *)0x0) {
                        return puVar1;
                    }
                    *in_RDX = uVar3;
                    return puVar1;
                }
            }
        }
    }
    return (uint8_t *)0x0;
}

// ============================================================
// Function: FUN_1801fdb80
// Address: 0x1801fdb80
// Size: 256 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801fdb80(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t *puVar1;
    int64_t iVar2;
    undefined8 uVar3;
    uint8_t **in_RCX;
    undefined8 *in_RDX;
    uint8_t *puVar4;
    uint8_t *puVar5;
    undefined *in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fdba0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX[1] != (uint8_t *)0x0) {
        puVar1 = *in_RCX;
        puVar4 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar1 >> 6));
        if (puVar4 <= in_RCX[1]) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fdbdb;
            uVar3 = fcn.180274e70(puVar1);
            *in_RCX = *in_RCX + (int64_t)puVar4;
            puVar4 = in_RCX[1] + -(int64_t)puVar4;
            puVar1 = *in_RCX;
            in_RCX[1] = puVar4;
            if ((puVar4 != (uint8_t *)0x0) &&
               (puVar5 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar1 >> 6)), puVar5 <= puVar4)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fdc10;
                puVar4 = (uint8_t *)fcn.180274e70(puVar1);
                *in_RCX = *in_RCX + (int64_t)puVar5;
                puVar5 = in_RCX[1] + -(int64_t)puVar5;
                puVar1 = *in_RCX;
                in_RCX[1] = puVar5;
                if (puVar4 <= puVar5) {
                    *in_RCX = puVar4 + (int64_t)puVar1;
                    in_RCX[1] = puVar5 + -(int64_t)puVar4;
                    if (in_RDX != (undefined8 *)0x0) {
                        *in_RDX = uVar3;
                    }
                    if ((puVar1 != (uint8_t *)0x0) && (puVar4 < (uint8_t *)0x15)) {
                        *in_R8 = (char)puVar4;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fdc5c;
                        fcn.180498030(in_R8 + 1, puVar1);
                        return 1;
                    }
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801fdc80
// Address: 0x1801fdc80
// Size: 273 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.1801fdc80(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t *puVar1;
    int64_t iVar2;
    undefined8 uVar3;
    uint8_t **in_RCX;
    undefined8 *in_RDX;
    uint8_t *puVar4;
    undefined8 *in_R8;
    uint8_t *puVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801fdca4;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX[1] != (uint8_t *)0x0) {
        puVar1 = *in_RCX;
        puVar5 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar1 >> 6));
        if (puVar5 <= in_RCX[1]) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801fdce1;
            uVar3 = fcn.180274e70(puVar1);
            *in_RCX = *in_RCX + (int64_t)puVar5;
            puVar5 = in_RCX[1] + -(int64_t)puVar5;
            puVar1 = *in_RCX;
            in_RCX[1] = puVar5;
            if ((puVar5 != (uint8_t *)0x0) &&
               (puVar4 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar1 >> 6)), puVar4 <= puVar5)) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801fdd12;
                puVar5 = (uint8_t *)fcn.180274e70(puVar1);
                *in_RCX = *in_RCX + (int64_t)puVar4;
                puVar4 = in_RCX[1] + -(int64_t)puVar4;
                puVar1 = *in_RCX;
                in_RCX[1] = puVar4;
                if (puVar5 <= puVar4) {
                    *in_RCX = puVar1 + (int64_t)puVar5;
                    in_RCX[1] = puVar4 + -(int64_t)puVar5;
                    if (in_RDX != (undefined8 *)0x0) {
                        *in_RDX = uVar3;
                    }
                    if (((puVar1 != (uint8_t *)0x0) && (puVar5 != (uint8_t *)0x0)) &&
                       (puVar4 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar1 >> 6)), puVar4 <= puVar5)) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801fdd62;
                        uVar3 = fcn.180274e70(puVar1);
                        *in_R8 = uVar3;
                        return puVar5 == puVar4;
                    }
                }
            }
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1801fdda0
// Address: 0x1801fdda0
// Size: 452 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801fdda0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t uVar1;
    uint8_t uVar2;
    uint8_t uVar3;
    uint8_t uVar4;
    undefined uVar5;
    undefined4 *puVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint8_t *puVar12;
    uint8_t **in_RCX;
    undefined2 *in_RDX;
    uint8_t *puVar13;
    uint8_t *puVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801fddc2;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    if (in_RCX[1] != (uint8_t *)0x0) {
        puVar12 = *in_RCX;
        puVar13 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar12 >> 6));
        if (puVar13 <= in_RCX[1]) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801fddfb;
            iVar11 = fcn.180274e70(puVar12);
            *in_RCX = *in_RCX + (int64_t)puVar13;
            puVar13 = in_RCX[1] + -(int64_t)puVar13;
            puVar12 = *in_RCX;
            in_RCX[1] = puVar13;
            if ((puVar13 != (uint8_t *)0x0) &&
               (puVar14 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar12 >> 6)), puVar14 <= puVar13)) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801fde38;
                puVar12 = (uint8_t *)fcn.180274e70(puVar12);
                *in_RCX = *in_RCX + (int64_t)puVar14;
                puVar13 = in_RCX[1] + -(int64_t)puVar14;
                puVar6 = (undefined4 *)*in_RCX;
                in_RCX[1] = puVar13;
                if (puVar12 <= puVar13) {
                    *in_RCX = puVar12 + (int64_t)puVar6;
                    in_RCX[1] = puVar13 + -(int64_t)puVar12;
                    if ((((puVar6 != (undefined4 *)0x0) && (puVar12 + -0x29 < (uint8_t *)0x15)) && (iVar11 == 0xd)) &&
                       ((uint8_t *)0x3 < puVar12)) {
                        *(undefined4 *)(in_RDX + 2) = *puVar6;
                        if ((uint8_t *)0x1 < puVar12 + -4) {
                            uVar1 = *(uint8_t *)(puVar6 + 1);
                            *(uint8_t *)((int64_t)&arg_28h + iVar10) = *(uint8_t *)((int64_t)puVar6 + 5);
                            if ((uint8_t *)0xf < puVar12 + -6) {
                                uVar7 = *(undefined4 *)((int64_t)puVar6 + 10);
                                uVar8 = *(undefined4 *)((int64_t)puVar6 + 0xe);
                                uVar9 = *(undefined4 *)((int64_t)puVar6 + 0x12);
                                *(undefined4 *)(in_RDX + 4) = *(undefined4 *)((int64_t)puVar6 + 6);
                                *(undefined4 *)(in_RDX + 6) = uVar7;
                                *(undefined4 *)(in_RDX + 8) = uVar8;
                                *(undefined4 *)(in_RDX + 10) = uVar9;
                                if ((uint8_t *)0x1 < puVar12 + -0x16) {
                                    uVar2 = *(uint8_t *)((int64_t)puVar6 + 0x16);
                                    uVar3 = *(uint8_t *)((int64_t)puVar6 + 0x17);
                                    if (puVar12 != (uint8_t *)0x18) {
                                        uVar4 = *(uint8_t *)(puVar6 + 6);
                                        puVar13 = (uint8_t *)(uint64_t)uVar4;
                                        if ((uVar4 < 0x15) && (puVar13 <= puVar12 + -0x19)) {
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801fdf04;
                                            fcn.180498030((int64_t)in_RDX + 0x29, (uint8_t *)((int64_t)puVar6 + 0x19), 
                                                          puVar13);
                                            if (0xf < (uint64_t)((int64_t)(puVar12 + -0x19) - (int64_t)puVar13)) {
                                                puVar6 = (undefined4 *)
                                                         ((uint8_t *)((int64_t)puVar6 + 0x19) + (int64_t)puVar13);
                                                uVar7 = puVar6[1];
                                                uVar8 = puVar6[2];
                                                uVar9 = puVar6[3];
                                                uVar5 = *(undefined *)((int64_t)&arg_28h + iVar10);
                                                *(undefined4 *)(in_RDX + 0xc) = *puVar6;
                                                *(undefined4 *)(in_RDX + 0xe) = uVar7;
                                                *(undefined4 *)(in_RDX + 0x10) = uVar8;
                                                *(undefined4 *)(in_RDX + 0x12) = uVar9;
                                                *in_RDX = CONCAT11(uVar1, uVar5);
                                                *(uint8_t *)(in_RDX + 0x14) = uVar4;
                                                in_RDX[1] = CONCAT11(uVar2, uVar3);
                                                return 1;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801fdf70
// Address: 0x1801fdf70
// Size: 394 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801fdf70(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint32_t uVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined auVar7 [16];
    int32_t iVar8;
    int64_t iVar9;
    undefined8 in_RCX;
    uint8_t in_DL;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t iVar12;
    int64_t **in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801fdf8e;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    uVar1 = *(uint32_t *)(in_R8 + 6);
    piVar2 = in_R8[1];
    if (piVar2 != (int64_t *)0x0) {
        piVar11 = in_R8[2];
        auVar7._8_8_ = 0;
        auVar7._0_8_ = piVar11;
        iVar10 = SUB168(ZEXT816(0x624dd2f1a9fbe77) * auVar7, 8);
        iVar12 = (*in_R8)[1];
        iVar3 = **in_R8;
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801fdffb;
        iVar8 = func_0x0001802447a0(in_RCX, (uVar1 & 1) + 2);
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801fe00e;
            iVar8 = func_0x0001802447a0(in_RCX, iVar12);
            if (iVar8 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801fe021;
                iVar8 = func_0x0001802447a0(in_RCX, (iVar10 + ((uint64_t)((int64_t)piVar11 - iVar10) >> 1) >> 9) /
                                                    (uint64_t)(1LL << (in_DL & 0x3f)));
                if (iVar8 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801fe035;
                    iVar8 = func_0x0001802447a0(in_RCX, (int64_t)piVar2 - 1);
                    if (iVar8 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801fe048;
                        iVar8 = func_0x0001802447a0(in_RCX, iVar12 - iVar3);
                        if (iVar8 != 0) {
                            piVar11 = (int64_t *)0x1;
                            if ((int64_t *)0x1 < piVar2) {
                                iVar12 = 0x10;
                                do {
                                    piVar4 = *in_R8;
                                    iVar3 = *(int64_t *)(iVar12 + -0x10 + (int64_t)piVar4);
                                    iVar10 = *(int64_t *)(iVar12 + 8 + (int64_t)piVar4);
                                    iVar5 = *(int64_t *)(iVar12 + 8 + (int64_t)piVar4);
                                    iVar6 = *(int64_t *)(iVar12 + (int64_t)piVar4);
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801fe082;
                                    iVar8 = func_0x0001802447a0(in_RCX, (iVar3 - iVar10) + -2);
                                    if (iVar8 == 0) {
                                        return 0;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801fe091;
                                    iVar8 = func_0x0001802447a0(in_RCX, iVar5 - iVar6);
                                    if (iVar8 == 0) {
                                        return 0;
                                    }
                                    piVar11 = (int64_t *)((int64_t)piVar11 + 1);
                                    iVar12 = iVar12 + 0x10;
                                } while (piVar11 < piVar2);
                            }
                            if ((*(uint8_t *)(in_R8 + 6) & 1) == 0) {
                                return 1;
                            }
                            piVar2 = in_R8[3];
                            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801fe0b4;
                            iVar8 = func_0x0001802447a0(in_RCX, piVar2);
                            if (iVar8 != 0) {
                                piVar2 = in_R8[4];
                                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801fe0c4;
                                iVar8 = func_0x0001802447a0(in_RCX, piVar2);
                                if (iVar8 != 0) {
                                    piVar2 = in_R8[5];
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801fe0d4;
                                    iVar8 = func_0x0001802447a0(in_RCX, piVar2);
                                    if (iVar8 != 0) {
                                        return 1;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801fe100
// Address: 0x1801fe100
// Size: 145 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801fe100(int64_t arg_28h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint8_t *in_RDX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fe110;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801fe127;
    iVar3 = func_0x0001802447a0();
    if (iVar3 != 0) {
        uVar1 = *(undefined8 *)(in_RDX + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801fe137;
        iVar3 = func_0x0001802447a0(in_RCX, uVar1);
        if (iVar3 != 0) {
            if ((*in_RDX & 1) == 0) {
                uVar1 = *(undefined8 *)(in_RDX + 0x10);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801fe14c;
                iVar3 = func_0x0001802447a0(in_RCX, uVar1);
                if (iVar3 == 0) {
                    return 0;
                }
            }
            uVar1 = *(undefined8 *)(in_RDX + 0x20);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801fe15c;
            iVar3 = func_0x0001802447a0(in_RCX, uVar1);
            if (iVar3 != 0) {
                uVar1 = *(undefined8 *)(in_RDX + 0x20);
                uVar2 = *(undefined8 *)(in_RDX + 0x18);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801fe170;
                iVar3 = func_0x0001802445f0(in_RCX, uVar2, uVar1);
                if (iVar3 != 0) {
                    return 1;
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801fe1a0
// Address: 0x1801fe1a0
// Size: 99 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1801fe1a0(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fe1b0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe1c3;
    iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe1d2;
        iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2));
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe1e2;
            iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2));
            return iVar1 != 0;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1801fe210
// Address: 0x1801fe210
// Size: 27 bytes
// ============================================================
undefined8 fcn.1801fe210(int64_t param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined8 unaff_RBX;
    int64_t iVar5;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar4 = 0x1e;
    *(undefined8 *)(&stack0x00000030 + iVar2) = unaff_RBX;
    *(undefined8 *)(&stack0x00000040 + iVar2) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x1802447b5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)(&stack0x00000058 + iVar3 + iVar2) = 0;
    if (uVar4 < 0x40) {
        iVar5 = 1;
    } else if (uVar4 < 0x4000) {
        iVar5 = 2;
    } else if (uVar4 < 0x40000000) {
        iVar5 = 4;
    } else {
        if (0x3fffffffffffffff < uVar4) {
            return 0;
        }
        iVar5 = 8;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180244815;
    iVar1 = func_0x000180244860();
    if (iVar1 == 0) {
        return 0;
    }
    *(int64_t *)(param_1 + 0x18) = *(int64_t *)(param_1 + 0x18) + iVar5;
    *(int64_t *)(param_1 + 0x10) = *(int64_t *)(param_1 + 0x10) + iVar5;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18024482e;
    func_0x000180274f10(*(undefined8 *)(&stack0x00000058 + iVar3 + iVar2), uVar4);
    return 1;
}

// ============================================================
// Function: FUN_1801fe230
// Address: 0x1801fe230
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1801fe230(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fe240;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe253;
    iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe262;
        iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2));
        return iVar1 != 0;
    }
    return false;
}

// ============================================================
// Function: FUN_1801fe290
// Address: 0x1801fe290
// Size: 116 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.1801fe290(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fe2a5;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe2bb;
    iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe2ca;
        iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2));
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe2d9;
            iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2));
            return iVar1 != 0;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1801fe310
// Address: 0x1801fe310
// Size: 107 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.1801fe310(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fe325;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe343;
    iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe352;
        iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2));
        return iVar1 != 0;
    }
    return false;
}

// ============================================================
// Function: FUN_1801fe380
// Address: 0x1801fe380
// Size: 119 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.1801fe380(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fe395;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe3ab;
    iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe3ba;
        iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2));
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe3cc;
            iVar1 = fcn.1802445f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
            return iVar1 != 0;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1801fe400
// Address: 0x1801fe400
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1801fe400(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fe410;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe423;
    iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe438;
        iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
        return iVar1 != 0;
    }
    return false;
}

// ============================================================
// Function: FUN_1801fe460
// Address: 0x1801fe460
// Size: 27 bytes
// ============================================================
undefined8 fcn.1801fe460(int64_t param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined8 unaff_RBX;
    int64_t iVar5;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar4 = 1;
    *(undefined8 *)(&stack0x00000030 + iVar2) = unaff_RBX;
    *(undefined8 *)(&stack0x00000040 + iVar2) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x1802447b5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)(&stack0x00000058 + iVar3 + iVar2) = 0;
    if (uVar4 < 0x40) {
        iVar5 = 1;
    } else if (uVar4 < 0x4000) {
        iVar5 = 2;
    } else if (uVar4 < 0x40000000) {
        iVar5 = 4;
    } else {
        if (0x3fffffffffffffff < uVar4) {
            return 0;
        }
        iVar5 = 8;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180244815;
    iVar1 = fcn.180244860(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2)
                         );
    if (iVar1 == 0) {
        return 0;
    }
    *(int64_t *)(param_1 + 0x18) = *(int64_t *)(param_1 + 0x18) + iVar5;
    *(int64_t *)(param_1 + 0x10) = *(int64_t *)(param_1 + 0x10) + iVar5;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18024482e;
    func_0x000180274f10(*(undefined8 *)(&stack0x00000058 + iVar3 + iVar2), uVar4);
    return 1;
}

// ============================================================
// Function: FUN_1801fe480
// Address: 0x1801fe480
// Size: 115 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1801fe480(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fe490;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe4a3;
    iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe4b2;
        iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2));
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe4c2;
            iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe4d2;
                iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar2));
                return iVar1 != 0;
            }
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1801fe500
// Address: 0x1801fe500
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1801fe500(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fe510;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe523;
    iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe532;
        iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2));
        return iVar1 != 0;
    }
    return false;
}

// ============================================================
// Function: FUN_1801fe560
// Address: 0x1801fe560
// Size: 99 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1801fe560(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fe570;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe583;
    iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe592;
        iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2));
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe5a2;
            iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2));
            return iVar1 != 0;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1801fe5d0
// Address: 0x1801fe5d0
// Size: 175 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801fe5d0(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fe5e0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe624;
    iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe633;
        iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2));
        if (iVar1 != 0) {
            if (*(int64_t *)(in_RDX + 8) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe648;
                iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar2));
                if (iVar1 == 0) {
                    return 0;
                }
            }
            if ((*(uint8_t *)(in_RDX + 0x20) & 1) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe65e;
                iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar2));
                if (iVar1 == 0) {
                    return 0;
                }
            }
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801fe680
// Address: 0x1801fe680
// Size: 27 bytes
// ============================================================
undefined8
fcn.1801fe680(int64_t arg_30h, int64_t arg_38h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_90h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined4 uVar5;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar5 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x180244685;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802446a2;
        iVar2 = fcn.180244860(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar4 + iVar3));
        if (iVar2 == 0) {
            return 0;
        }
        *(int64_t *)(in_RCX + 0x18) = *(int64_t *)(in_RCX + 0x18) + in_RDX;
        *(int64_t *)(in_RCX + 0x10) = *(int64_t *)(in_RCX + 0x10) + in_RDX;
        iVar1 = *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802446c2;
            fcn.1804986e0(iVar1, uVar5, in_RDX);
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801fe6a0
// Address: 0x1801fe6a0
// Size: 166 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801fe6a0(int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 in_RCX;
    int64_t in_R8;
    int64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fe6b5;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar2 + -8) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe6cf;
    iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                          *(int64_t *)(&stack0x00000028 + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe6de;
        iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
        if (iVar1 != 0) {
            if (in_R9 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe6ef;
                uVar3 = func_0x000180244270();
                *(undefined8 *)((int64_t)&iStackX_20 + iVar2 + -8) = uVar3;
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe703;
                iVar1 = func_0x000180243f60(in_RCX, in_R9, (int64_t)&iStackX_20 + iVar2 + -8);
                if (iVar1 == 0) {
                    return 0;
                }
                uVar3 = *(undefined8 *)((int64_t)&iStackX_20 + iVar2 + -8);
            }
            if (in_R8 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe71f;
                fcn.180498030(uVar3, in_R8, in_R9);
                return *(undefined8 *)((int64_t)&iStackX_20 + iVar2 + -8);
            }
            return uVar3;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801fe750
// Address: 0x1801fe750
// Size: 172 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.1801fe750(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint8_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint8_t *in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_20;
    
    uStack_20 = 0x1801fe768;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *in_R8;
    if (uVar1 < 0x15) {
        *(undefined8 *)((int64_t)&arg_38h + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801fe788;
        iVar2 = fcn.1802447a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar3));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801fe796;
            iVar2 = fcn.1802447a0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3));
            if (iVar2 != 0) {
                if (uVar1 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801fe7a7;
                    iVar4 = func_0x000180244270();
                    *(int64_t *)((int64_t)&arg_38h + iVar3) = iVar4;
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801fe7bb;
                    iVar2 = func_0x000180243f60(in_RCX, uVar1, (int64_t)&arg_38h + iVar3);
                    if (iVar2 == 0) {
                        return false;
                    }
                    iVar4 = *(int64_t *)((int64_t)&arg_38h + iVar3);
                }
                if (in_R8 + 1 != (uint8_t *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801fe7d7;
                    fcn.180498030(iVar4, in_R8 + 1, uVar1);
                    iVar4 = *(int64_t *)((int64_t)&arg_38h + iVar3);
                }
                return iVar4 != 0;
            }
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1801fe800
// Address: 0x1801fe800
// Size: 176 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.1801fe800(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fe815;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe823;
    iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe877;
        iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2));
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fe886;
            iVar1 = fcn.1802447a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2));
            return iVar1 != 0;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1801fe950
// Address: 0x1801fe950
// Size: 164 bytes
// ============================================================
int64_t fcn.1801fe950(uint64_t *param_1)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fe95c;
    iVar2 = fcn.18045a350();
    uVar1 = *param_1;
    if (uVar1 < 0x40) {
        iVar5 = 1;
    } else if (uVar1 < 0x4000) {
        iVar5 = 2;
    } else if (uVar1 < 0x40000000) {
        iVar5 = 4;
    } else {
        if (0x3fffffffffffffff < uVar1) {
            return 0;
        }
        iVar5 = 8;
    }
    iVar3 = 0;
    iVar4 = iVar3;
    if (param_1[1] != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801fe9b9;
        iVar3 = fcn.1801f8d10();
        if (iVar3 == 0) {
            return 0;
        }
    }
    if ((*(uint8_t *)(param_1 + 4) & 1) != 0) {
        uVar1 = param_1[2];
        *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801fe9dc;
        iVar4 = fcn.1801f8d10(uVar1);
        if (iVar4 == 0) {
            return 0;
        }
    }
    return iVar4 + 1 + iVar5 + iVar3;
}

// ============================================================
// Function: FUN_1801fea00
// Address: 0x1801fea00
// Size: 353 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801fea00(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint8_t *puVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint8_t **in_RCX;
    int64_t *in_RDX;
    uint8_t *puVar7;
    uint64_t uVar8;
    uint8_t *puVar9;
    uint64_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fea1b;
    iVar4 = fcn.18045a350();
    puVar1 = in_RCX[1];
    puVar7 = *in_RCX;
    if ((puVar1 != (uint8_t *)0x0) && (puVar9 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar7 >> 6)), puVar9 <= puVar1))
    {
        *(undefined8 *)((int64_t)&uStack_10 + -iVar4) = 0x1801fea50;
        uVar5 = fcn.180274e70(puVar7);
        puVar7 = puVar7 + (int64_t)puVar9;
        uVar8 = (int64_t)puVar1 - (int64_t)puVar9;
        if (((uVar5 & 0xfffffffffffffffe) == 2) &&
           ((uVar8 != 0 && (uVar5 = (uint64_t)(uint32_t)(1 << (*puVar7 >> 6)), uVar5 <= uVar8)))) {
            uVar8 = uVar8 - uVar5;
            if (uVar8 != 0) {
                uVar2 = 1 << (puVar7[uVar5] >> 6);
                if (uVar2 <= uVar8) {
                    uVar8 = uVar8 - uVar2;
                    puVar7 = puVar7 + uVar5 + uVar2;
                    if ((uVar8 != 0) && (uVar5 = (uint64_t)(uint32_t)(1 << (*puVar7 >> 6)), uVar5 <= uVar8)) {
                        *(undefined8 *)((int64_t)&uStack_10 + -iVar4) = 0x1801feada;
                        uVar6 = fcn.180274e70(puVar7);
                        uVar10 = 0;
                        puVar7 = puVar7 + uVar5;
                        uVar8 = uVar8 - uVar5;
                        if (uVar6 != 0) {
                            do {
                                if (uVar8 == 0) {
                                    return 0;
                                }
                                uVar2 = 1 << (*puVar7 >> 6);
                                if (uVar8 < uVar2) {
                                    return 0;
                                }
                                uVar8 = uVar8 - uVar2;
                                if (uVar8 == 0) {
                                    return 0;
                                }
                                uVar3 = 1 << (puVar7[uVar2] >> 6);
                                if (uVar8 < uVar3) {
                                    return 0;
                                }
                                uVar8 = uVar8 - uVar3;
                                puVar7 = puVar7 + uVar2 + uVar3;
                                uVar10 = uVar10 + 1;
                            } while (uVar10 < uVar6);
                        }
                        *in_RDX = uVar6 + 1;
                        return 1;
                    }
                }
            }
        }
    }
    return 0;
}

