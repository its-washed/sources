// Chunk 124 - 50 functions

// ============================================================
// Function: FUN_1801a9160
// Address: 0x1801a9160
// Size: 36 bytes
// ============================================================
undefined8 fcn.1801a9160(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint32_t uVar5;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    int64_t iVar6;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int16_t *piVar7;
    undefined8 unaff_R14;
    int64_t iVar8;
    uint32_t uVar9;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a916c;
    iVar2 = func_0x00018045a350();
    iVar2 = -iVar2;
    iVar8 = *(int64_t *)(in_RCX + 0x878);
    *(undefined8 *)(in_RCX + 0x410) = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar2) = unaff_RSI;
    *(undefined8 *)((int64_t)&var_20h + iVar2) = unaff_R14;
    uVar5 = *(uint32_t *)(iVar8 + 0x1c) & 0x30000;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = unaff_R15;
    uVar9 = 0xb;
    if (uVar5 == 0x10000) {
        iVar8 = 1;
code_r0x0001801a9218:
        piVar7 = (int16_t *)0x1804adff4;
    } else if (uVar5 == 0x20000) {
        piVar7 = (int16_t *)0x1804adff6;
        iVar8 = 1;
    } else {
        if (uVar5 == 0x30000) {
            iVar8 = 2;
            goto code_r0x0001801a9218;
        }
        if ((*(int32_t *)(in_RCX + 0x78) == 1) && (piVar7 = *(int16_t **)(iVar8 + 0x50), piVar7 != (int16_t *)0x0)) {
            iVar8 = *(int64_t *)(iVar8 + 0x58);
        } else {
            piVar7 = *(int16_t **)(iVar8 + 0x40);
            if (piVar7 == (int16_t *)0x0) {
                piVar7 = *(int16_t **)(*(int64_t *)(in_RCX + 8) + 0x658);
                iVar8 = *(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x648);
            } else {
                iVar8 = *(int64_t *)(iVar8 + 0x48);
            }
        }
        if (iVar8 == 0) goto code_r0x0001801a92b4;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_RBP;
    do {
        iVar4 = *(int64_t *)(in_RCX + 8);
        uVar3 = 0;
        iVar6 = *(int64_t *)(iVar4 + 0x650);
        if (*(uint64_t *)(iVar4 + 0x640) != 0) {
            do {
                if (*(int16_t *)(iVar6 + 0x10) == *piVar7) {
                    if (*(int32_t *)(iVar6 + 0x2c) != 0) {
                        iVar1 = *(int32_t *)(iVar6 + 0x20);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a9276;
                        iVar4 = func_0x0001801a1fe0((int64_t)iVar1, iVar4);
                        if ((iVar4 != 0) && ((*(uint32_t *)(iVar4 + 4) & uVar9) != 0)) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a9294;
                            iVar1 = func_0x0001801aa060(in_RCX, 0x5000e, iVar6);
                            if (iVar1 != 0) {
                                uVar9 = uVar9 & ~*(uint32_t *)(iVar4 + 4);
                            }
                        }
                    }
                    break;
                }
                iVar6 = iVar6 + 0x48;
                uVar3 = uVar3 + 1;
            } while (uVar3 < *(uint64_t *)(iVar4 + 0x640));
        }
        piVar7 = piVar7 + 1;
        iVar8 = iVar8 + -1;
    } while (iVar8 != 0);
code_r0x0001801a92b4:
    *(uint32_t *)(in_RCX + 0x414) = *(uint32_t *)(in_RCX + 0x414) | uVar9;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a92d4;
    iVar1 = func_0x0001801af910(in_RCX, in_RCX + 0x418, in_RCX + 0x41c, 0);
    if (iVar1 == 0) {
        if (*(int64_t *)(in_RCX + 0x968) == 0) {
            *(uint32_t *)(in_RCX + 0x414) = *(uint32_t *)(in_RCX + 0x414) | 0x10;
            *(uint32_t *)(in_RCX + 0x410) = *(uint32_t *)(in_RCX + 0x410) | 0x1c8;
        }
        if ((*(uint8_t *)(in_RCX + 0xc44) & 0x20) == 0) {
            *(uint32_t *)(in_RCX + 0x414) = *(uint32_t *)(in_RCX + 0x414) | 0x40;
            *(uint32_t *)(in_RCX + 0x410) = *(uint32_t *)(in_RCX + 0x410) | 0x20;
        }
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a9184
// Address: 0x1801a9184
// Size: 155 bytes
// ============================================================
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.1801a9160(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint32_t uVar5;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    int64_t iVar6;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int16_t *piVar7;
    undefined8 unaff_R14;
    int64_t iVar8;
    uint32_t uVar9;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a916c;
    iVar2 = func_0x00018045a350();
    iVar2 = -iVar2;
    iVar8 = *(int64_t *)(in_RCX + 0x878);
    *(undefined8 *)(in_RCX + 0x410) = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar2) = unaff_RSI;
    *(undefined8 *)((int64_t)&var_20h + iVar2) = unaff_R14;
    uVar5 = *(uint32_t *)(iVar8 + 0x1c) & 0x30000;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = unaff_R15;
    uVar9 = 0xb;
    if (uVar5 == 0x10000) {
        iVar8 = 1;
code_r0x0001801a9218:
        piVar7 = (int16_t *)0x1804adff4;
    } else if (uVar5 == 0x20000) {
        piVar7 = (int16_t *)0x1804adff6;
        iVar8 = 1;
    } else {
        if (uVar5 == 0x30000) {
            iVar8 = 2;
            goto code_r0x0001801a9218;
        }
        if ((*(int32_t *)(in_RCX + 0x78) == 1) && (piVar7 = *(int16_t **)(iVar8 + 0x50), piVar7 != (int16_t *)0x0)) {
            iVar8 = *(int64_t *)(iVar8 + 0x58);
        } else {
            piVar7 = *(int16_t **)(iVar8 + 0x40);
            if (piVar7 == (int16_t *)0x0) {
                piVar7 = *(int16_t **)(*(int64_t *)(in_RCX + 8) + 0x658);
                iVar8 = *(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x648);
            } else {
                iVar8 = *(int64_t *)(iVar8 + 0x48);
            }
        }
        if (iVar8 == 0) goto code_r0x0001801a92b4;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_RBP;
    do {
        iVar4 = *(int64_t *)(in_RCX + 8);
        uVar3 = 0;
        iVar6 = *(int64_t *)(iVar4 + 0x650);
        if (*(uint64_t *)(iVar4 + 0x640) != 0) {
            do {
                if (*(int16_t *)(iVar6 + 0x10) == *piVar7) {
                    if (*(int32_t *)(iVar6 + 0x2c) != 0) {
                        iVar1 = *(int32_t *)(iVar6 + 0x20);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a9276;
                        iVar4 = func_0x0001801a1fe0((int64_t)iVar1, iVar4);
                        if ((iVar4 != 0) && ((*(uint32_t *)(iVar4 + 4) & uVar9) != 0)) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a9294;
                            iVar1 = func_0x0001801aa060(in_RCX, 0x5000e, iVar6);
                            if (iVar1 != 0) {
                                uVar9 = uVar9 & ~*(uint32_t *)(iVar4 + 4);
                            }
                        }
                    }
                    break;
                }
                iVar6 = iVar6 + 0x48;
                uVar3 = uVar3 + 1;
            } while (uVar3 < *(uint64_t *)(iVar4 + 0x640));
        }
        piVar7 = piVar7 + 1;
        iVar8 = iVar8 + -1;
    } while (iVar8 != 0);
code_r0x0001801a92b4:
    *(uint32_t *)(in_RCX + 0x414) = *(uint32_t *)(in_RCX + 0x414) | uVar9;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a92d4;
    iVar1 = func_0x0001801af910(in_RCX, in_RCX + 0x418, in_RCX + 0x41c, 0);
    if (iVar1 == 0) {
        if (*(int64_t *)(in_RCX + 0x968) == 0) {
            *(uint32_t *)(in_RCX + 0x414) = *(uint32_t *)(in_RCX + 0x414) | 0x10;
            *(uint32_t *)(in_RCX + 0x410) = *(uint32_t *)(in_RCX + 0x410) | 0x1c8;
        }
        if ((*(uint8_t *)(in_RCX + 0xc44) & 0x20) == 0) {
            *(uint32_t *)(in_RCX + 0x414) = *(uint32_t *)(in_RCX + 0x414) | 0x40;
            *(uint32_t *)(in_RCX + 0x410) = *(uint32_t *)(in_RCX + 0x410) | 0x20;
        }
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a921f
// Address: 0x1801a921f
// Size: 149 bytes
// ============================================================
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.1801a9160(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint32_t uVar5;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    int64_t iVar6;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int16_t *piVar7;
    undefined8 unaff_R14;
    int64_t iVar8;
    uint32_t uVar9;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a916c;
    iVar2 = func_0x00018045a350();
    iVar2 = -iVar2;
    iVar8 = *(int64_t *)(in_RCX + 0x878);
    *(undefined8 *)(in_RCX + 0x410) = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar2) = unaff_RSI;
    *(undefined8 *)((int64_t)&var_20h + iVar2) = unaff_R14;
    uVar5 = *(uint32_t *)(iVar8 + 0x1c) & 0x30000;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = unaff_R15;
    uVar9 = 0xb;
    if (uVar5 == 0x10000) {
        iVar8 = 1;
code_r0x0001801a9218:
        piVar7 = (int16_t *)0x1804adff4;
    } else if (uVar5 == 0x20000) {
        piVar7 = (int16_t *)0x1804adff6;
        iVar8 = 1;
    } else {
        if (uVar5 == 0x30000) {
            iVar8 = 2;
            goto code_r0x0001801a9218;
        }
        if ((*(int32_t *)(in_RCX + 0x78) == 1) && (piVar7 = *(int16_t **)(iVar8 + 0x50), piVar7 != (int16_t *)0x0)) {
            iVar8 = *(int64_t *)(iVar8 + 0x58);
        } else {
            piVar7 = *(int16_t **)(iVar8 + 0x40);
            if (piVar7 == (int16_t *)0x0) {
                piVar7 = *(int16_t **)(*(int64_t *)(in_RCX + 8) + 0x658);
                iVar8 = *(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x648);
            } else {
                iVar8 = *(int64_t *)(iVar8 + 0x48);
            }
        }
        if (iVar8 == 0) goto code_r0x0001801a92b4;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_RBP;
    do {
        iVar4 = *(int64_t *)(in_RCX + 8);
        uVar3 = 0;
        iVar6 = *(int64_t *)(iVar4 + 0x650);
        if (*(uint64_t *)(iVar4 + 0x640) != 0) {
            do {
                if (*(int16_t *)(iVar6 + 0x10) == *piVar7) {
                    if (*(int32_t *)(iVar6 + 0x2c) != 0) {
                        iVar1 = *(int32_t *)(iVar6 + 0x20);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a9276;
                        iVar4 = func_0x0001801a1fe0((int64_t)iVar1, iVar4);
                        if ((iVar4 != 0) && ((*(uint32_t *)(iVar4 + 4) & uVar9) != 0)) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a9294;
                            iVar1 = func_0x0001801aa060(in_RCX, 0x5000e, iVar6);
                            if (iVar1 != 0) {
                                uVar9 = uVar9 & ~*(uint32_t *)(iVar4 + 4);
                            }
                        }
                    }
                    break;
                }
                iVar6 = iVar6 + 0x48;
                uVar3 = uVar3 + 1;
            } while (uVar3 < *(uint64_t *)(iVar4 + 0x640));
        }
        piVar7 = piVar7 + 1;
        iVar8 = iVar8 + -1;
    } while (iVar8 != 0);
code_r0x0001801a92b4:
    *(uint32_t *)(in_RCX + 0x414) = *(uint32_t *)(in_RCX + 0x414) | uVar9;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a92d4;
    iVar1 = func_0x0001801af910(in_RCX, in_RCX + 0x418, in_RCX + 0x41c, 0);
    if (iVar1 == 0) {
        if (*(int64_t *)(in_RCX + 0x968) == 0) {
            *(uint32_t *)(in_RCX + 0x414) = *(uint32_t *)(in_RCX + 0x414) | 0x10;
            *(uint32_t *)(in_RCX + 0x410) = *(uint32_t *)(in_RCX + 0x410) | 0x1c8;
        }
        if ((*(uint8_t *)(in_RCX + 0xc44) & 0x20) == 0) {
            *(uint32_t *)(in_RCX + 0x414) = *(uint32_t *)(in_RCX + 0x414) | 0x40;
            *(uint32_t *)(in_RCX + 0x410) = *(uint32_t *)(in_RCX + 0x410) | 0x20;
        }
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a92b4
// Address: 0x1801a92b4
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.1801a9160(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint32_t uVar5;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    int64_t iVar6;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int16_t *piVar7;
    undefined8 unaff_R14;
    int64_t iVar8;
    uint32_t uVar9;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a916c;
    iVar2 = func_0x00018045a350();
    iVar2 = -iVar2;
    iVar8 = *(int64_t *)(in_RCX + 0x878);
    *(undefined8 *)(in_RCX + 0x410) = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar2) = unaff_RSI;
    *(undefined8 *)((int64_t)&var_20h + iVar2) = unaff_R14;
    uVar5 = *(uint32_t *)(iVar8 + 0x1c) & 0x30000;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = unaff_R15;
    uVar9 = 0xb;
    if (uVar5 == 0x10000) {
        iVar8 = 1;
code_r0x0001801a9218:
        piVar7 = (int16_t *)0x1804adff4;
    } else if (uVar5 == 0x20000) {
        piVar7 = (int16_t *)0x1804adff6;
        iVar8 = 1;
    } else {
        if (uVar5 == 0x30000) {
            iVar8 = 2;
            goto code_r0x0001801a9218;
        }
        if ((*(int32_t *)(in_RCX + 0x78) == 1) && (piVar7 = *(int16_t **)(iVar8 + 0x50), piVar7 != (int16_t *)0x0)) {
            iVar8 = *(int64_t *)(iVar8 + 0x58);
        } else {
            piVar7 = *(int16_t **)(iVar8 + 0x40);
            if (piVar7 == (int16_t *)0x0) {
                piVar7 = *(int16_t **)(*(int64_t *)(in_RCX + 8) + 0x658);
                iVar8 = *(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x648);
            } else {
                iVar8 = *(int64_t *)(iVar8 + 0x48);
            }
        }
        if (iVar8 == 0) goto code_r0x0001801a92b4;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_RBP;
    do {
        iVar4 = *(int64_t *)(in_RCX + 8);
        uVar3 = 0;
        iVar6 = *(int64_t *)(iVar4 + 0x650);
        if (*(uint64_t *)(iVar4 + 0x640) != 0) {
            do {
                if (*(int16_t *)(iVar6 + 0x10) == *piVar7) {
                    if (*(int32_t *)(iVar6 + 0x2c) != 0) {
                        iVar1 = *(int32_t *)(iVar6 + 0x20);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a9276;
                        iVar4 = func_0x0001801a1fe0((int64_t)iVar1, iVar4);
                        if ((iVar4 != 0) && ((*(uint32_t *)(iVar4 + 4) & uVar9) != 0)) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a9294;
                            iVar1 = func_0x0001801aa060(in_RCX, 0x5000e, iVar6);
                            if (iVar1 != 0) {
                                uVar9 = uVar9 & ~*(uint32_t *)(iVar4 + 4);
                            }
                        }
                    }
                    break;
                }
                iVar6 = iVar6 + 0x48;
                uVar3 = uVar3 + 1;
            } while (uVar3 < *(uint64_t *)(iVar4 + 0x640));
        }
        piVar7 = piVar7 + 1;
        iVar8 = iVar8 + -1;
    } while (iVar8 != 0);
code_r0x0001801a92b4:
    *(uint32_t *)(in_RCX + 0x414) = *(uint32_t *)(in_RCX + 0x414) | uVar9;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a92d4;
    iVar1 = func_0x0001801af910(in_RCX, in_RCX + 0x418, in_RCX + 0x41c, 0);
    if (iVar1 == 0) {
        if (*(int64_t *)(in_RCX + 0x968) == 0) {
            *(uint32_t *)(in_RCX + 0x414) = *(uint32_t *)(in_RCX + 0x414) | 0x10;
            *(uint32_t *)(in_RCX + 0x410) = *(uint32_t *)(in_RCX + 0x410) | 0x1c8;
        }
        if ((*(uint8_t *)(in_RCX + 0xc44) & 0x20) == 0) {
            *(uint32_t *)(in_RCX + 0x414) = *(uint32_t *)(in_RCX + 0x414) | 0x40;
            *(uint32_t *)(in_RCX + 0x410) = *(uint32_t *)(in_RCX + 0x410) | 0x20;
        }
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a92e7
// Address: 0x1801a92e7
// Size: 69 bytes
// ============================================================
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.1801a9160(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint32_t uVar5;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    int64_t iVar6;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int16_t *piVar7;
    undefined8 unaff_R14;
    int64_t iVar8;
    uint32_t uVar9;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a916c;
    iVar2 = func_0x00018045a350();
    iVar2 = -iVar2;
    iVar8 = *(int64_t *)(in_RCX + 0x878);
    *(undefined8 *)(in_RCX + 0x410) = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar2) = unaff_RSI;
    *(undefined8 *)((int64_t)&var_20h + iVar2) = unaff_R14;
    uVar5 = *(uint32_t *)(iVar8 + 0x1c) & 0x30000;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = unaff_R15;
    uVar9 = 0xb;
    if (uVar5 == 0x10000) {
        iVar8 = 1;
code_r0x0001801a9218:
        piVar7 = (int16_t *)0x1804adff4;
    } else if (uVar5 == 0x20000) {
        piVar7 = (int16_t *)0x1804adff6;
        iVar8 = 1;
    } else {
        if (uVar5 == 0x30000) {
            iVar8 = 2;
            goto code_r0x0001801a9218;
        }
        if ((*(int32_t *)(in_RCX + 0x78) == 1) && (piVar7 = *(int16_t **)(iVar8 + 0x50), piVar7 != (int16_t *)0x0)) {
            iVar8 = *(int64_t *)(iVar8 + 0x58);
        } else {
            piVar7 = *(int16_t **)(iVar8 + 0x40);
            if (piVar7 == (int16_t *)0x0) {
                piVar7 = *(int16_t **)(*(int64_t *)(in_RCX + 8) + 0x658);
                iVar8 = *(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x648);
            } else {
                iVar8 = *(int64_t *)(iVar8 + 0x48);
            }
        }
        if (iVar8 == 0) goto code_r0x0001801a92b4;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_RBP;
    do {
        iVar4 = *(int64_t *)(in_RCX + 8);
        uVar3 = 0;
        iVar6 = *(int64_t *)(iVar4 + 0x650);
        if (*(uint64_t *)(iVar4 + 0x640) != 0) {
            do {
                if (*(int16_t *)(iVar6 + 0x10) == *piVar7) {
                    if (*(int32_t *)(iVar6 + 0x2c) != 0) {
                        iVar1 = *(int32_t *)(iVar6 + 0x20);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a9276;
                        iVar4 = func_0x0001801a1fe0((int64_t)iVar1, iVar4);
                        if ((iVar4 != 0) && ((*(uint32_t *)(iVar4 + 4) & uVar9) != 0)) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a9294;
                            iVar1 = func_0x0001801aa060(in_RCX, 0x5000e, iVar6);
                            if (iVar1 != 0) {
                                uVar9 = uVar9 & ~*(uint32_t *)(iVar4 + 4);
                            }
                        }
                    }
                    break;
                }
                iVar6 = iVar6 + 0x48;
                uVar3 = uVar3 + 1;
            } while (uVar3 < *(uint64_t *)(iVar4 + 0x640));
        }
        piVar7 = piVar7 + 1;
        iVar8 = iVar8 + -1;
    } while (iVar8 != 0);
code_r0x0001801a92b4:
    *(uint32_t *)(in_RCX + 0x414) = *(uint32_t *)(in_RCX + 0x414) | uVar9;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a92d4;
    iVar1 = func_0x0001801af910(in_RCX, in_RCX + 0x418, in_RCX + 0x41c, 0);
    if (iVar1 == 0) {
        if (*(int64_t *)(in_RCX + 0x968) == 0) {
            *(uint32_t *)(in_RCX + 0x414) = *(uint32_t *)(in_RCX + 0x414) | 0x10;
            *(uint32_t *)(in_RCX + 0x410) = *(uint32_t *)(in_RCX + 0x410) | 0x1c8;
        }
        if ((*(uint8_t *)(in_RCX + 0xc44) & 0x20) == 0) {
            *(uint32_t *)(in_RCX + 0x414) = *(uint32_t *)(in_RCX + 0x414) | 0x40;
            *(uint32_t *)(in_RCX + 0x410) = *(uint32_t *)(in_RCX + 0x410) | 0x20;
        }
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a9330
// Address: 0x1801a9330
// Size: 361 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h

void fcn.1801a9330(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    uint32_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 unaff_RSI;
    int16_t *piVar8;
    uint64_t in_R8;
    uint32_t uVar9;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801a9348;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    iVar7 = *(int64_t *)(in_RDX + 0x878);
    uVar9 = 0xb;
    uVar1 = *(uint32_t *)(iVar7 + 0x1c) & 0x30000;
    if (uVar1 == 0x10000) {
        iVar7 = 1;
    } else {
        if (uVar1 == 0x20000) {
            piVar8 = (int16_t *)0x1804adff6;
            iVar7 = 1;
            goto code_r0x0001801a93f0;
        }
        if (uVar1 != 0x30000) {
            if ((*(int32_t *)(in_RDX + 0x78) == 1) && (piVar8 = *(int16_t **)(iVar7 + 0x50), piVar8 != (int16_t *)0x0))
            {
                iVar7 = *(int64_t *)(iVar7 + 0x58);
            } else {
                piVar8 = *(int16_t **)(iVar7 + 0x40);
                if (piVar8 == (int16_t *)0x0) {
                    piVar8 = *(int16_t **)(*(int64_t *)(in_RDX + 8) + 0x658);
                    iVar7 = *(int64_t *)(*(int64_t *)(in_RDX + 8) + 0x648);
                } else {
                    iVar7 = *(int64_t *)(iVar7 + 0x48);
                }
            }
            if (iVar7 == 0) {
                *in_RCX = *in_RCX | 0xb;
                return;
            }
            goto code_r0x0001801a93f0;
        }
        iVar7 = 2;
    }
    piVar8 = (int16_t *)0x1804adff4;
code_r0x0001801a93f0:
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
    do {
        iVar5 = *(int64_t *)(in_RDX + 8);
        uVar4 = 0;
        iVar6 = *(int64_t *)(iVar5 + 0x650);
        if (*(uint64_t *)(iVar5 + 0x640) != 0) {
            do {
                if (*(int16_t *)(iVar6 + 0x10) == *piVar8) {
                    if (*(int32_t *)(iVar6 + 0x2c) != 0) {
                        iVar2 = *(int32_t *)(iVar6 + 0x20);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801a9446;
                        iVar5 = func_0x0001801a1fe0((int64_t)iVar2, iVar5);
                        if ((iVar5 != 0) && ((*(uint32_t *)(iVar5 + 4) & uVar9) != 0)) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801a9462;
                            iVar2 = func_0x0001801aa060(in_RDX, in_R8 & 0xffffffff, iVar6);
                            if (iVar2 != 0) {
                                uVar9 = uVar9 & ~*(uint32_t *)(iVar5 + 4);
                            }
                        }
                    }
                    break;
                }
                iVar6 = iVar6 + 0x48;
                uVar4 = uVar4 + 1;
            } while (uVar4 < *(uint64_t *)(iVar5 + 0x640));
        }
        piVar8 = piVar8 + 1;
        iVar7 = iVar7 + -1;
        if (iVar7 == 0) {
            *in_RCX = *in_RCX | uVar9;
            return;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1801a94a0
// Address: 0x1801a94a0
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1801a94a0(int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_c8h, int64_t arg_d0h,
                      int64_t arg_d8h, int64_t arg_e0h, int64_t arg_1c0h)
{
    undefined2 *puVar1;
    undefined4 *puVar2;
    int16_t iVar3;
    undefined4 uVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int32_t iVar8;
    int32_t iVar9;
    undefined4 uVar10;
    undefined2 uVar11;
    undefined2 uVar12;
    undefined2 uVar13;
    undefined2 uVar14;
    int32_t iVar15;
    undefined4 uVar16;
    int64_t iVar17;
    int64_t iVar18;
    uint64_t uVar19;
    uint64_t uVar20;
    int64_t iVar21;
    uint64_t uVar22;
    undefined8 *in_RCX;
    uint64_t uVar23;
    uint64_t uVar24;
    int32_t *piVar25;
    int32_t *piVar26;
    undefined2 *puVar27;
    uint64_t uVar28;
    undefined8 unaff_RSI;
    int64_t iVar29;
    undefined8 unaff_RDI;
    uint64_t uVar30;
    uint64_t uVar31;
    undefined8 unaff_R12;
    undefined2 *puVar32;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801a94b3;
    iVar17 = func_0x00018045a350();
    iVar17 = -iVar17;
    uVar28 = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a94c6;
    iVar18 = func_0x00018022fd80();
    *(int64_t *)((int64_t)&var_8h + iVar17) = iVar18;
    uVar20 = uVar28;
    uVar19 = uVar28;
    if (in_RCX != (undefined8 *)0x0) {
        iVar21 = in_RCX[1];
        *(undefined8 *)((int64_t)&arg_90h + iVar17) = unaff_RSI;
        iVar29 = in_RCX[0xd0];
        *(int64_t *)((int64_t)&arg_d0h + iVar17) = iVar29;
        iVar29 = iVar29 + 0x1f;
        iVar21 = *(int64_t *)(iVar21 + 0xd8);
        *(int64_t *)((int64_t)&arg_e0h + iVar17) = iVar29;
        *(uint32_t *)((int64_t)&arg_c8h + iVar17) = ~(*(uint32_t *)(iVar21 + 0x50) >> 3) & 1;
        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9531;
        uVar19 = func_0x000180224e40(iVar29, 0x48, 0x1804aeee0, 0x898);
        if ((uVar19 != 0) && (uVar20 = 0, iVar18 != 0)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9560;
            uVar20 = func_0x000180224e40(iVar29, 2, 0x1804aeee0, 0x89c);
            if (uVar20 != 0) {
                *(undefined8 *)((int64_t)&arg_88h + iVar17) = unaff_RDI;
                *(undefined8 *)((int64_t)&arg_80h + iVar17) = unaff_R12;
                *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9581;
                func_0x000180229b10();
                uVar5 = *(undefined8 *)((int64_t)&var_8h + iVar17);
                piVar26 = (int32_t *)0x1804ae0f8;
                piVar25 = (int32_t *)(uVar19 + 0x2c);
                iVar18 = 0x1f;
                do {
                    iVar15 = piVar26[-5];
                    iVar8 = piVar26[-4];
                    iVar9 = piVar26[-3];
                    piVar25[-0xb] = piVar26[-6];
                    piVar25[-10] = iVar15;
                    piVar25[-9] = iVar8;
                    piVar25[-8] = iVar9;
                    iVar15 = piVar26[-1];
                    iVar8 = *piVar26;
                    iVar9 = piVar26[1];
                    piVar25[-7] = piVar26[-2];
                    piVar25[-6] = iVar15;
                    piVar25[-5] = iVar8;
                    piVar25[-4] = iVar9;
                    iVar15 = piVar26[3];
                    iVar8 = piVar26[4];
                    iVar9 = piVar26[5];
                    piVar25[-3] = piVar26[2];
                    piVar25[-2] = iVar15;
                    piVar25[-1] = iVar8;
                    *piVar25 = iVar9;
                    iVar15 = piVar26[7];
                    iVar8 = piVar26[8];
                    iVar9 = piVar26[9];
                    piVar25[1] = piVar26[6];
                    piVar25[2] = iVar15;
                    piVar25[3] = iVar8;
                    piVar25[4] = iVar9;
                    *(undefined8 *)(piVar25 + 5) = *(undefined8 *)(piVar26 + 10);
                    if ((piVar26[-1] == 0) || (in_RCX[(int64_t)*piVar26 + 0xac] != 0)) {
                        iVar15 = piVar26[1];
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a95e7;
                        iVar15 = func_0x0001802304b0(uVar5, iVar15);
                        if (iVar15 == 0) goto code_r0x0001801a95eb;
                        uVar6 = in_RCX[0x8c];
                        uVar7 = *in_RCX;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9601;
                        iVar21 = func_0x000180259210(uVar7, uVar5, uVar6);
                        if (iVar21 == 0) {
                            *piVar25 = 0;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9610;
                        func_0x000180258be0(iVar21);
                    } else {
code_r0x0001801a95eb:
                        *piVar25 = 0;
                    }
                    piVar26 = piVar26 + 0x12;
                    piVar25 = piVar25 + 0x12;
                    iVar18 = iVar18 + -1;
                } while (iVar18 != 0);
                uVar23 = *(uint64_t *)((int64_t)&arg_e0h + iVar17);
                if (in_RCX[0xd0] != 0) {
                    uVar4 = *(undefined4 *)((int64_t)&arg_c8h + iVar17);
                    puVar32 = (undefined2 *)(uVar20 + 0x3e);
                    puVar27 = (undefined2 *)(uVar19 + 0x8c8);
                    *(undefined8 *)((int64_t)&arg_d8h + iVar17) = 0;
                    uVar23 = uVar28;
                    uVar30 = uVar28;
                    do {
                        iVar18 = in_RCX[0xcf];
                        puVar2 = (undefined4 *)(uVar23 + 0x10 + iVar18);
                        uVar16 = *puVar2;
                        uVar10 = puVar2[1];
                        puVar1 = (undefined2 *)(uVar23 + iVar18);
                        uVar11 = puVar1[1];
                        uVar12 = puVar1[2];
                        uVar13 = puVar1[3];
                        uVar14 = puVar1[4];
                        iVar18 = *(int64_t *)(uVar23 + 0x30 + iVar18);
                        puVar27[-8] = *puVar1;
                        puVar27[-7] = uVar11;
                        puVar27[-6] = uVar12;
                        puVar27[-5] = uVar13;
                        *(undefined4 *)(puVar27 + -4) = uVar16;
                        *(undefined4 *)(puVar27 + -2) = uVar10;
                        *(undefined4 *)((int64_t)&arg_c8h + iVar17) = uVar16;
                        *(undefined4 *)((int64_t)&arg_c8h + iVar17 + 4) = uVar10;
                        *puVar27 = uVar14;
                        *puVar32 = uVar14;
                        uVar16 = 0;
                        if (iVar18 != 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a96a5;
                            uVar16 = func_0x00018022d1b0();
                        }
                        *(undefined4 *)(puVar27 + 2) = uVar16;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a96b3;
                        uVar16 = func_0x0001801a0350(uVar16);
                        uVar5 = *(undefined8 *)((int64_t)&arg_c8h + iVar17);
                        *(undefined4 *)(puVar27 + 4) = uVar16;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a96c3;
                        uVar16 = func_0x00018022d1b0(uVar5);
                        uVar5 = *(undefined8 *)((int64_t)&arg_c8h + iVar17);
                        *(undefined4 *)(puVar27 + 6) = uVar16;
                        *(int32_t *)(puVar27 + 8) = (int32_t)uVar30 + 9;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a96d9;
                        uVar16 = func_0x00018022d1b0(uVar5);
                        iVar18 = *(int64_t *)((int64_t)&arg_d8h + iVar17);
                        puVar32 = puVar32 + 1;
                        *(undefined4 *)(puVar27 + 10) = uVar16;
                        uVar23 = iVar18 + 0x68;
                        *(undefined4 *)(puVar27 + 0xc) = 0;
                        uVar30 = uVar30 + 1;
                        *(undefined4 *)(puVar27 + 0x12) = 0x304;
                        *(undefined4 *)(puVar27 + 0x14) = 0x304;
                        *(undefined8 *)(puVar27 + 0x16) = 0xffffffffffffffff;
                        *(undefined4 *)(puVar27 + 0xe) = uVar4;
                        *(undefined4 *)(puVar27 + 0x10) = 0;
                        puVar27 = puVar27 + 0x24;
                        *(uint64_t *)((int64_t)&arg_d8h + iVar17) = uVar23;
                    } while (uVar30 < (uint64_t)in_RCX[0xd0]);
                    uVar23 = *(uint64_t *)((int64_t)&arg_e0h + iVar17);
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9734;
                func_0x0001802299d0();
                uVar30 = uVar28;
                uVar31 = uVar28;
                do {
                    if (uVar23 == 0) {
code_r0x0001801a979e:
                        if (uVar23 != 0) goto code_r0x0001801a97a9;
                    } else {
                        iVar3 = *(int16_t *)(uVar31 + 0x1804ae090);
                        uVar22 = uVar19;
                        uVar24 = uVar28;
                        do {
                            if (*(int16_t *)(uVar22 + 0x10) == iVar3) {
                                if ((*(int32_t *)(uVar22 + 0x2c) == 0) || (*(int32_t *)(uVar22 + 0x30) != 0))
                                goto code_r0x0001801a979e;
                                *(undefined4 *)(uVar22 + 0x30) = 1;
                                *(int16_t *)(uVar20 + uVar30 * 2) = iVar3;
                                uVar30 = uVar30 + 1;
                                break;
                            }
                            uVar22 = uVar22 + 0x48;
                            uVar24 = uVar24 + 1;
                        } while (uVar24 < uVar23);
code_r0x0001801a97a9:
                        iVar3 = *(int16_t *)(uVar31 + 0x1804ae092);
                        uVar22 = uVar19;
                        uVar24 = uVar28;
                        do {
                            if (*(int16_t *)(uVar22 + 0x10) == iVar3) {
                                if ((*(int32_t *)(uVar22 + 0x2c) != 0) && (*(int32_t *)(uVar22 + 0x30) == 0)) {
                                    *(undefined4 *)(uVar22 + 0x30) = 1;
                                    *(int16_t *)(uVar20 + uVar30 * 2) = iVar3;
                                    uVar30 = uVar30 + 1;
                                }
                                break;
                            }
                            uVar22 = uVar22 + 0x48;
                            uVar24 = uVar24 + 1;
                        } while (uVar24 < uVar23);
                    }
                    uVar31 = uVar31 + 4;
                } while (uVar31 < 0x44);
                if (0x1f < uVar23) {
                    iVar18 = *(int64_t *)((int64_t)&arg_d0h + iVar17);
                    piVar25 = (int32_t *)(uVar19 + 0x8e8);
                    do {
                        if ((piVar25[-1] != 0) && (*piVar25 == 0)) {
                            *(undefined2 *)(uVar20 + uVar30 * 2) = *(undefined2 *)(piVar25 + -8);
                            uVar30 = uVar30 + 1;
                            iVar18 = *(int64_t *)((int64_t)&arg_d0h + iVar17);
                        }
                        piVar25 = piVar25 + 0x12;
                        iVar18 = iVar18 + -1;
                        *(int64_t *)((int64_t)&arg_d0h + iVar17) = iVar18;
                    } while (iVar18 != 0);
                }
                iVar18 = *(int64_t *)((int64_t)&var_8h + iVar17);
                in_RCX[0xca] = uVar19;
                uVar19 = 0;
                in_RCX[0xcb] = uVar20;
                uVar20 = 0;
                uVar28 = 1;
                in_RCX[200] = uVar23;
                in_RCX[0xc9] = uVar30;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a987b;
    func_0x000180224990(uVar19, 0x1804aeee0, 0x8fc);
    *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9890;
    func_0x000180224990(uVar20, 0x1804aeee0, 0x8fd);
    *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9898;
    func_0x00018022ecc0(iVar18);
    return uVar28;
}

// ============================================================
// Function: FUN_1801a94e2
// Address: 0x1801a94e2
// Size: 138 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1801a94a0(int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_c8h, int64_t arg_d0h,
                      int64_t arg_d8h, int64_t arg_e0h, int64_t arg_1c0h)
{
    undefined2 *puVar1;
    undefined4 *puVar2;
    int16_t iVar3;
    undefined4 uVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int32_t iVar8;
    int32_t iVar9;
    undefined4 uVar10;
    undefined2 uVar11;
    undefined2 uVar12;
    undefined2 uVar13;
    undefined2 uVar14;
    int32_t iVar15;
    undefined4 uVar16;
    int64_t iVar17;
    int64_t iVar18;
    uint64_t uVar19;
    uint64_t uVar20;
    int64_t iVar21;
    uint64_t uVar22;
    undefined8 *in_RCX;
    uint64_t uVar23;
    uint64_t uVar24;
    int32_t *piVar25;
    int32_t *piVar26;
    undefined2 *puVar27;
    uint64_t uVar28;
    undefined8 unaff_RSI;
    int64_t iVar29;
    undefined8 unaff_RDI;
    uint64_t uVar30;
    uint64_t uVar31;
    undefined8 unaff_R12;
    undefined2 *puVar32;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801a94b3;
    iVar17 = func_0x00018045a350();
    iVar17 = -iVar17;
    uVar28 = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a94c6;
    iVar18 = func_0x00018022fd80();
    *(int64_t *)((int64_t)&var_8h + iVar17) = iVar18;
    uVar20 = uVar28;
    uVar19 = uVar28;
    if (in_RCX != (undefined8 *)0x0) {
        iVar21 = in_RCX[1];
        *(undefined8 *)((int64_t)&arg_90h + iVar17) = unaff_RSI;
        iVar29 = in_RCX[0xd0];
        *(int64_t *)((int64_t)&arg_d0h + iVar17) = iVar29;
        iVar29 = iVar29 + 0x1f;
        iVar21 = *(int64_t *)(iVar21 + 0xd8);
        *(int64_t *)((int64_t)&arg_e0h + iVar17) = iVar29;
        *(uint32_t *)((int64_t)&arg_c8h + iVar17) = ~(*(uint32_t *)(iVar21 + 0x50) >> 3) & 1;
        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9531;
        uVar19 = func_0x000180224e40(iVar29, 0x48, 0x1804aeee0, 0x898);
        if ((uVar19 != 0) && (uVar20 = 0, iVar18 != 0)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9560;
            uVar20 = func_0x000180224e40(iVar29, 2, 0x1804aeee0, 0x89c);
            if (uVar20 != 0) {
                *(undefined8 *)((int64_t)&arg_88h + iVar17) = unaff_RDI;
                *(undefined8 *)((int64_t)&arg_80h + iVar17) = unaff_R12;
                *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9581;
                func_0x000180229b10();
                uVar5 = *(undefined8 *)((int64_t)&var_8h + iVar17);
                piVar26 = (int32_t *)0x1804ae0f8;
                piVar25 = (int32_t *)(uVar19 + 0x2c);
                iVar18 = 0x1f;
                do {
                    iVar15 = piVar26[-5];
                    iVar8 = piVar26[-4];
                    iVar9 = piVar26[-3];
                    piVar25[-0xb] = piVar26[-6];
                    piVar25[-10] = iVar15;
                    piVar25[-9] = iVar8;
                    piVar25[-8] = iVar9;
                    iVar15 = piVar26[-1];
                    iVar8 = *piVar26;
                    iVar9 = piVar26[1];
                    piVar25[-7] = piVar26[-2];
                    piVar25[-6] = iVar15;
                    piVar25[-5] = iVar8;
                    piVar25[-4] = iVar9;
                    iVar15 = piVar26[3];
                    iVar8 = piVar26[4];
                    iVar9 = piVar26[5];
                    piVar25[-3] = piVar26[2];
                    piVar25[-2] = iVar15;
                    piVar25[-1] = iVar8;
                    *piVar25 = iVar9;
                    iVar15 = piVar26[7];
                    iVar8 = piVar26[8];
                    iVar9 = piVar26[9];
                    piVar25[1] = piVar26[6];
                    piVar25[2] = iVar15;
                    piVar25[3] = iVar8;
                    piVar25[4] = iVar9;
                    *(undefined8 *)(piVar25 + 5) = *(undefined8 *)(piVar26 + 10);
                    if ((piVar26[-1] == 0) || (in_RCX[(int64_t)*piVar26 + 0xac] != 0)) {
                        iVar15 = piVar26[1];
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a95e7;
                        iVar15 = func_0x0001802304b0(uVar5, iVar15);
                        if (iVar15 == 0) goto code_r0x0001801a95eb;
                        uVar6 = in_RCX[0x8c];
                        uVar7 = *in_RCX;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9601;
                        iVar21 = func_0x000180259210(uVar7, uVar5, uVar6);
                        if (iVar21 == 0) {
                            *piVar25 = 0;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9610;
                        func_0x000180258be0(iVar21);
                    } else {
code_r0x0001801a95eb:
                        *piVar25 = 0;
                    }
                    piVar26 = piVar26 + 0x12;
                    piVar25 = piVar25 + 0x12;
                    iVar18 = iVar18 + -1;
                } while (iVar18 != 0);
                uVar23 = *(uint64_t *)((int64_t)&arg_e0h + iVar17);
                if (in_RCX[0xd0] != 0) {
                    uVar4 = *(undefined4 *)((int64_t)&arg_c8h + iVar17);
                    puVar32 = (undefined2 *)(uVar20 + 0x3e);
                    puVar27 = (undefined2 *)(uVar19 + 0x8c8);
                    *(undefined8 *)((int64_t)&arg_d8h + iVar17) = 0;
                    uVar23 = uVar28;
                    uVar30 = uVar28;
                    do {
                        iVar18 = in_RCX[0xcf];
                        puVar2 = (undefined4 *)(uVar23 + 0x10 + iVar18);
                        uVar16 = *puVar2;
                        uVar10 = puVar2[1];
                        puVar1 = (undefined2 *)(uVar23 + iVar18);
                        uVar11 = puVar1[1];
                        uVar12 = puVar1[2];
                        uVar13 = puVar1[3];
                        uVar14 = puVar1[4];
                        iVar18 = *(int64_t *)(uVar23 + 0x30 + iVar18);
                        puVar27[-8] = *puVar1;
                        puVar27[-7] = uVar11;
                        puVar27[-6] = uVar12;
                        puVar27[-5] = uVar13;
                        *(undefined4 *)(puVar27 + -4) = uVar16;
                        *(undefined4 *)(puVar27 + -2) = uVar10;
                        *(undefined4 *)((int64_t)&arg_c8h + iVar17) = uVar16;
                        *(undefined4 *)((int64_t)&arg_c8h + iVar17 + 4) = uVar10;
                        *puVar27 = uVar14;
                        *puVar32 = uVar14;
                        uVar16 = 0;
                        if (iVar18 != 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a96a5;
                            uVar16 = func_0x00018022d1b0();
                        }
                        *(undefined4 *)(puVar27 + 2) = uVar16;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a96b3;
                        uVar16 = func_0x0001801a0350(uVar16);
                        uVar5 = *(undefined8 *)((int64_t)&arg_c8h + iVar17);
                        *(undefined4 *)(puVar27 + 4) = uVar16;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a96c3;
                        uVar16 = func_0x00018022d1b0(uVar5);
                        uVar5 = *(undefined8 *)((int64_t)&arg_c8h + iVar17);
                        *(undefined4 *)(puVar27 + 6) = uVar16;
                        *(int32_t *)(puVar27 + 8) = (int32_t)uVar30 + 9;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a96d9;
                        uVar16 = func_0x00018022d1b0(uVar5);
                        iVar18 = *(int64_t *)((int64_t)&arg_d8h + iVar17);
                        puVar32 = puVar32 + 1;
                        *(undefined4 *)(puVar27 + 10) = uVar16;
                        uVar23 = iVar18 + 0x68;
                        *(undefined4 *)(puVar27 + 0xc) = 0;
                        uVar30 = uVar30 + 1;
                        *(undefined4 *)(puVar27 + 0x12) = 0x304;
                        *(undefined4 *)(puVar27 + 0x14) = 0x304;
                        *(undefined8 *)(puVar27 + 0x16) = 0xffffffffffffffff;
                        *(undefined4 *)(puVar27 + 0xe) = uVar4;
                        *(undefined4 *)(puVar27 + 0x10) = 0;
                        puVar27 = puVar27 + 0x24;
                        *(uint64_t *)((int64_t)&arg_d8h + iVar17) = uVar23;
                    } while (uVar30 < (uint64_t)in_RCX[0xd0]);
                    uVar23 = *(uint64_t *)((int64_t)&arg_e0h + iVar17);
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9734;
                func_0x0001802299d0();
                uVar30 = uVar28;
                uVar31 = uVar28;
                do {
                    if (uVar23 == 0) {
code_r0x0001801a979e:
                        if (uVar23 != 0) goto code_r0x0001801a97a9;
                    } else {
                        iVar3 = *(int16_t *)(uVar31 + 0x1804ae090);
                        uVar22 = uVar19;
                        uVar24 = uVar28;
                        do {
                            if (*(int16_t *)(uVar22 + 0x10) == iVar3) {
                                if ((*(int32_t *)(uVar22 + 0x2c) == 0) || (*(int32_t *)(uVar22 + 0x30) != 0))
                                goto code_r0x0001801a979e;
                                *(undefined4 *)(uVar22 + 0x30) = 1;
                                *(int16_t *)(uVar20 + uVar30 * 2) = iVar3;
                                uVar30 = uVar30 + 1;
                                break;
                            }
                            uVar22 = uVar22 + 0x48;
                            uVar24 = uVar24 + 1;
                        } while (uVar24 < uVar23);
code_r0x0001801a97a9:
                        iVar3 = *(int16_t *)(uVar31 + 0x1804ae092);
                        uVar22 = uVar19;
                        uVar24 = uVar28;
                        do {
                            if (*(int16_t *)(uVar22 + 0x10) == iVar3) {
                                if ((*(int32_t *)(uVar22 + 0x2c) != 0) && (*(int32_t *)(uVar22 + 0x30) == 0)) {
                                    *(undefined4 *)(uVar22 + 0x30) = 1;
                                    *(int16_t *)(uVar20 + uVar30 * 2) = iVar3;
                                    uVar30 = uVar30 + 1;
                                }
                                break;
                            }
                            uVar22 = uVar22 + 0x48;
                            uVar24 = uVar24 + 1;
                        } while (uVar24 < uVar23);
                    }
                    uVar31 = uVar31 + 4;
                } while (uVar31 < 0x44);
                if (0x1f < uVar23) {
                    iVar18 = *(int64_t *)((int64_t)&arg_d0h + iVar17);
                    piVar25 = (int32_t *)(uVar19 + 0x8e8);
                    do {
                        if ((piVar25[-1] != 0) && (*piVar25 == 0)) {
                            *(undefined2 *)(uVar20 + uVar30 * 2) = *(undefined2 *)(piVar25 + -8);
                            uVar30 = uVar30 + 1;
                            iVar18 = *(int64_t *)((int64_t)&arg_d0h + iVar17);
                        }
                        piVar25 = piVar25 + 0x12;
                        iVar18 = iVar18 + -1;
                        *(int64_t *)((int64_t)&arg_d0h + iVar17) = iVar18;
                    } while (iVar18 != 0);
                }
                iVar18 = *(int64_t *)((int64_t)&var_8h + iVar17);
                in_RCX[0xca] = uVar19;
                uVar19 = 0;
                in_RCX[0xcb] = uVar20;
                uVar20 = 0;
                uVar28 = 1;
                in_RCX[200] = uVar23;
                in_RCX[0xc9] = uVar30;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a987b;
    func_0x000180224990(uVar19, 0x1804aeee0, 0x8fc);
    *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9890;
    func_0x000180224990(uVar20, 0x1804aeee0, 0x8fd);
    *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9898;
    func_0x00018022ecc0(iVar18);
    return uVar28;
}

// ============================================================
// Function: FUN_1801a956c
// Address: 0x1801a956c
// Size: 485 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1801a94a0(int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_c8h, int64_t arg_d0h,
                      int64_t arg_d8h, int64_t arg_e0h, int64_t arg_1c0h)
{
    undefined2 *puVar1;
    undefined4 *puVar2;
    int16_t iVar3;
    undefined4 uVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int32_t iVar8;
    int32_t iVar9;
    undefined4 uVar10;
    undefined2 uVar11;
    undefined2 uVar12;
    undefined2 uVar13;
    undefined2 uVar14;
    int32_t iVar15;
    undefined4 uVar16;
    int64_t iVar17;
    int64_t iVar18;
    uint64_t uVar19;
    uint64_t uVar20;
    int64_t iVar21;
    uint64_t uVar22;
    undefined8 *in_RCX;
    uint64_t uVar23;
    uint64_t uVar24;
    int32_t *piVar25;
    int32_t *piVar26;
    undefined2 *puVar27;
    uint64_t uVar28;
    undefined8 unaff_RSI;
    int64_t iVar29;
    undefined8 unaff_RDI;
    uint64_t uVar30;
    uint64_t uVar31;
    undefined8 unaff_R12;
    undefined2 *puVar32;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801a94b3;
    iVar17 = func_0x00018045a350();
    iVar17 = -iVar17;
    uVar28 = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a94c6;
    iVar18 = func_0x00018022fd80();
    *(int64_t *)((int64_t)&var_8h + iVar17) = iVar18;
    uVar20 = uVar28;
    uVar19 = uVar28;
    if (in_RCX != (undefined8 *)0x0) {
        iVar21 = in_RCX[1];
        *(undefined8 *)((int64_t)&arg_90h + iVar17) = unaff_RSI;
        iVar29 = in_RCX[0xd0];
        *(int64_t *)((int64_t)&arg_d0h + iVar17) = iVar29;
        iVar29 = iVar29 + 0x1f;
        iVar21 = *(int64_t *)(iVar21 + 0xd8);
        *(int64_t *)((int64_t)&arg_e0h + iVar17) = iVar29;
        *(uint32_t *)((int64_t)&arg_c8h + iVar17) = ~(*(uint32_t *)(iVar21 + 0x50) >> 3) & 1;
        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9531;
        uVar19 = func_0x000180224e40(iVar29, 0x48, 0x1804aeee0, 0x898);
        if ((uVar19 != 0) && (uVar20 = 0, iVar18 != 0)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9560;
            uVar20 = func_0x000180224e40(iVar29, 2, 0x1804aeee0, 0x89c);
            if (uVar20 != 0) {
                *(undefined8 *)((int64_t)&arg_88h + iVar17) = unaff_RDI;
                *(undefined8 *)((int64_t)&arg_80h + iVar17) = unaff_R12;
                *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9581;
                func_0x000180229b10();
                uVar5 = *(undefined8 *)((int64_t)&var_8h + iVar17);
                piVar26 = (int32_t *)0x1804ae0f8;
                piVar25 = (int32_t *)(uVar19 + 0x2c);
                iVar18 = 0x1f;
                do {
                    iVar15 = piVar26[-5];
                    iVar8 = piVar26[-4];
                    iVar9 = piVar26[-3];
                    piVar25[-0xb] = piVar26[-6];
                    piVar25[-10] = iVar15;
                    piVar25[-9] = iVar8;
                    piVar25[-8] = iVar9;
                    iVar15 = piVar26[-1];
                    iVar8 = *piVar26;
                    iVar9 = piVar26[1];
                    piVar25[-7] = piVar26[-2];
                    piVar25[-6] = iVar15;
                    piVar25[-5] = iVar8;
                    piVar25[-4] = iVar9;
                    iVar15 = piVar26[3];
                    iVar8 = piVar26[4];
                    iVar9 = piVar26[5];
                    piVar25[-3] = piVar26[2];
                    piVar25[-2] = iVar15;
                    piVar25[-1] = iVar8;
                    *piVar25 = iVar9;
                    iVar15 = piVar26[7];
                    iVar8 = piVar26[8];
                    iVar9 = piVar26[9];
                    piVar25[1] = piVar26[6];
                    piVar25[2] = iVar15;
                    piVar25[3] = iVar8;
                    piVar25[4] = iVar9;
                    *(undefined8 *)(piVar25 + 5) = *(undefined8 *)(piVar26 + 10);
                    if ((piVar26[-1] == 0) || (in_RCX[(int64_t)*piVar26 + 0xac] != 0)) {
                        iVar15 = piVar26[1];
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a95e7;
                        iVar15 = func_0x0001802304b0(uVar5, iVar15);
                        if (iVar15 == 0) goto code_r0x0001801a95eb;
                        uVar6 = in_RCX[0x8c];
                        uVar7 = *in_RCX;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9601;
                        iVar21 = func_0x000180259210(uVar7, uVar5, uVar6);
                        if (iVar21 == 0) {
                            *piVar25 = 0;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9610;
                        func_0x000180258be0(iVar21);
                    } else {
code_r0x0001801a95eb:
                        *piVar25 = 0;
                    }
                    piVar26 = piVar26 + 0x12;
                    piVar25 = piVar25 + 0x12;
                    iVar18 = iVar18 + -1;
                } while (iVar18 != 0);
                uVar23 = *(uint64_t *)((int64_t)&arg_e0h + iVar17);
                if (in_RCX[0xd0] != 0) {
                    uVar4 = *(undefined4 *)((int64_t)&arg_c8h + iVar17);
                    puVar32 = (undefined2 *)(uVar20 + 0x3e);
                    puVar27 = (undefined2 *)(uVar19 + 0x8c8);
                    *(undefined8 *)((int64_t)&arg_d8h + iVar17) = 0;
                    uVar23 = uVar28;
                    uVar30 = uVar28;
                    do {
                        iVar18 = in_RCX[0xcf];
                        puVar2 = (undefined4 *)(uVar23 + 0x10 + iVar18);
                        uVar16 = *puVar2;
                        uVar10 = puVar2[1];
                        puVar1 = (undefined2 *)(uVar23 + iVar18);
                        uVar11 = puVar1[1];
                        uVar12 = puVar1[2];
                        uVar13 = puVar1[3];
                        uVar14 = puVar1[4];
                        iVar18 = *(int64_t *)(uVar23 + 0x30 + iVar18);
                        puVar27[-8] = *puVar1;
                        puVar27[-7] = uVar11;
                        puVar27[-6] = uVar12;
                        puVar27[-5] = uVar13;
                        *(undefined4 *)(puVar27 + -4) = uVar16;
                        *(undefined4 *)(puVar27 + -2) = uVar10;
                        *(undefined4 *)((int64_t)&arg_c8h + iVar17) = uVar16;
                        *(undefined4 *)((int64_t)&arg_c8h + iVar17 + 4) = uVar10;
                        *puVar27 = uVar14;
                        *puVar32 = uVar14;
                        uVar16 = 0;
                        if (iVar18 != 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a96a5;
                            uVar16 = func_0x00018022d1b0();
                        }
                        *(undefined4 *)(puVar27 + 2) = uVar16;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a96b3;
                        uVar16 = func_0x0001801a0350(uVar16);
                        uVar5 = *(undefined8 *)((int64_t)&arg_c8h + iVar17);
                        *(undefined4 *)(puVar27 + 4) = uVar16;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a96c3;
                        uVar16 = func_0x00018022d1b0(uVar5);
                        uVar5 = *(undefined8 *)((int64_t)&arg_c8h + iVar17);
                        *(undefined4 *)(puVar27 + 6) = uVar16;
                        *(int32_t *)(puVar27 + 8) = (int32_t)uVar30 + 9;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a96d9;
                        uVar16 = func_0x00018022d1b0(uVar5);
                        iVar18 = *(int64_t *)((int64_t)&arg_d8h + iVar17);
                        puVar32 = puVar32 + 1;
                        *(undefined4 *)(puVar27 + 10) = uVar16;
                        uVar23 = iVar18 + 0x68;
                        *(undefined4 *)(puVar27 + 0xc) = 0;
                        uVar30 = uVar30 + 1;
                        *(undefined4 *)(puVar27 + 0x12) = 0x304;
                        *(undefined4 *)(puVar27 + 0x14) = 0x304;
                        *(undefined8 *)(puVar27 + 0x16) = 0xffffffffffffffff;
                        *(undefined4 *)(puVar27 + 0xe) = uVar4;
                        *(undefined4 *)(puVar27 + 0x10) = 0;
                        puVar27 = puVar27 + 0x24;
                        *(uint64_t *)((int64_t)&arg_d8h + iVar17) = uVar23;
                    } while (uVar30 < (uint64_t)in_RCX[0xd0]);
                    uVar23 = *(uint64_t *)((int64_t)&arg_e0h + iVar17);
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9734;
                func_0x0001802299d0();
                uVar30 = uVar28;
                uVar31 = uVar28;
                do {
                    if (uVar23 == 0) {
code_r0x0001801a979e:
                        if (uVar23 != 0) goto code_r0x0001801a97a9;
                    } else {
                        iVar3 = *(int16_t *)(uVar31 + 0x1804ae090);
                        uVar22 = uVar19;
                        uVar24 = uVar28;
                        do {
                            if (*(int16_t *)(uVar22 + 0x10) == iVar3) {
                                if ((*(int32_t *)(uVar22 + 0x2c) == 0) || (*(int32_t *)(uVar22 + 0x30) != 0))
                                goto code_r0x0001801a979e;
                                *(undefined4 *)(uVar22 + 0x30) = 1;
                                *(int16_t *)(uVar20 + uVar30 * 2) = iVar3;
                                uVar30 = uVar30 + 1;
                                break;
                            }
                            uVar22 = uVar22 + 0x48;
                            uVar24 = uVar24 + 1;
                        } while (uVar24 < uVar23);
code_r0x0001801a97a9:
                        iVar3 = *(int16_t *)(uVar31 + 0x1804ae092);
                        uVar22 = uVar19;
                        uVar24 = uVar28;
                        do {
                            if (*(int16_t *)(uVar22 + 0x10) == iVar3) {
                                if ((*(int32_t *)(uVar22 + 0x2c) != 0) && (*(int32_t *)(uVar22 + 0x30) == 0)) {
                                    *(undefined4 *)(uVar22 + 0x30) = 1;
                                    *(int16_t *)(uVar20 + uVar30 * 2) = iVar3;
                                    uVar30 = uVar30 + 1;
                                }
                                break;
                            }
                            uVar22 = uVar22 + 0x48;
                            uVar24 = uVar24 + 1;
                        } while (uVar24 < uVar23);
                    }
                    uVar31 = uVar31 + 4;
                } while (uVar31 < 0x44);
                if (0x1f < uVar23) {
                    iVar18 = *(int64_t *)((int64_t)&arg_d0h + iVar17);
                    piVar25 = (int32_t *)(uVar19 + 0x8e8);
                    do {
                        if ((piVar25[-1] != 0) && (*piVar25 == 0)) {
                            *(undefined2 *)(uVar20 + uVar30 * 2) = *(undefined2 *)(piVar25 + -8);
                            uVar30 = uVar30 + 1;
                            iVar18 = *(int64_t *)((int64_t)&arg_d0h + iVar17);
                        }
                        piVar25 = piVar25 + 0x12;
                        iVar18 = iVar18 + -1;
                        *(int64_t *)((int64_t)&arg_d0h + iVar17) = iVar18;
                    } while (iVar18 != 0);
                }
                iVar18 = *(int64_t *)((int64_t)&var_8h + iVar17);
                in_RCX[0xca] = uVar19;
                uVar19 = 0;
                in_RCX[0xcb] = uVar20;
                uVar20 = 0;
                uVar28 = 1;
                in_RCX[200] = uVar23;
                in_RCX[0xc9] = uVar30;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a987b;
    func_0x000180224990(uVar19, 0x1804aeee0, 0x8fc);
    *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9890;
    func_0x000180224990(uVar20, 0x1804aeee0, 0x8fd);
    *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9898;
    func_0x00018022ecc0(iVar18);
    return uVar28;
}

// ============================================================
// Function: FUN_1801a9751
// Address: 0x1801a9751
// Size: 277 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1801a94a0(int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_c8h, int64_t arg_d0h,
                      int64_t arg_d8h, int64_t arg_e0h, int64_t arg_1c0h)
{
    undefined2 *puVar1;
    undefined4 *puVar2;
    int16_t iVar3;
    undefined4 uVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int32_t iVar8;
    int32_t iVar9;
    undefined4 uVar10;
    undefined2 uVar11;
    undefined2 uVar12;
    undefined2 uVar13;
    undefined2 uVar14;
    int32_t iVar15;
    undefined4 uVar16;
    int64_t iVar17;
    int64_t iVar18;
    uint64_t uVar19;
    uint64_t uVar20;
    int64_t iVar21;
    uint64_t uVar22;
    undefined8 *in_RCX;
    uint64_t uVar23;
    uint64_t uVar24;
    int32_t *piVar25;
    int32_t *piVar26;
    undefined2 *puVar27;
    uint64_t uVar28;
    undefined8 unaff_RSI;
    int64_t iVar29;
    undefined8 unaff_RDI;
    uint64_t uVar30;
    uint64_t uVar31;
    undefined8 unaff_R12;
    undefined2 *puVar32;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801a94b3;
    iVar17 = func_0x00018045a350();
    iVar17 = -iVar17;
    uVar28 = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a94c6;
    iVar18 = func_0x00018022fd80();
    *(int64_t *)((int64_t)&var_8h + iVar17) = iVar18;
    uVar20 = uVar28;
    uVar19 = uVar28;
    if (in_RCX != (undefined8 *)0x0) {
        iVar21 = in_RCX[1];
        *(undefined8 *)((int64_t)&arg_90h + iVar17) = unaff_RSI;
        iVar29 = in_RCX[0xd0];
        *(int64_t *)((int64_t)&arg_d0h + iVar17) = iVar29;
        iVar29 = iVar29 + 0x1f;
        iVar21 = *(int64_t *)(iVar21 + 0xd8);
        *(int64_t *)((int64_t)&arg_e0h + iVar17) = iVar29;
        *(uint32_t *)((int64_t)&arg_c8h + iVar17) = ~(*(uint32_t *)(iVar21 + 0x50) >> 3) & 1;
        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9531;
        uVar19 = func_0x000180224e40(iVar29, 0x48, 0x1804aeee0, 0x898);
        if ((uVar19 != 0) && (uVar20 = 0, iVar18 != 0)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9560;
            uVar20 = func_0x000180224e40(iVar29, 2, 0x1804aeee0, 0x89c);
            if (uVar20 != 0) {
                *(undefined8 *)((int64_t)&arg_88h + iVar17) = unaff_RDI;
                *(undefined8 *)((int64_t)&arg_80h + iVar17) = unaff_R12;
                *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9581;
                func_0x000180229b10();
                uVar5 = *(undefined8 *)((int64_t)&var_8h + iVar17);
                piVar26 = (int32_t *)0x1804ae0f8;
                piVar25 = (int32_t *)(uVar19 + 0x2c);
                iVar18 = 0x1f;
                do {
                    iVar15 = piVar26[-5];
                    iVar8 = piVar26[-4];
                    iVar9 = piVar26[-3];
                    piVar25[-0xb] = piVar26[-6];
                    piVar25[-10] = iVar15;
                    piVar25[-9] = iVar8;
                    piVar25[-8] = iVar9;
                    iVar15 = piVar26[-1];
                    iVar8 = *piVar26;
                    iVar9 = piVar26[1];
                    piVar25[-7] = piVar26[-2];
                    piVar25[-6] = iVar15;
                    piVar25[-5] = iVar8;
                    piVar25[-4] = iVar9;
                    iVar15 = piVar26[3];
                    iVar8 = piVar26[4];
                    iVar9 = piVar26[5];
                    piVar25[-3] = piVar26[2];
                    piVar25[-2] = iVar15;
                    piVar25[-1] = iVar8;
                    *piVar25 = iVar9;
                    iVar15 = piVar26[7];
                    iVar8 = piVar26[8];
                    iVar9 = piVar26[9];
                    piVar25[1] = piVar26[6];
                    piVar25[2] = iVar15;
                    piVar25[3] = iVar8;
                    piVar25[4] = iVar9;
                    *(undefined8 *)(piVar25 + 5) = *(undefined8 *)(piVar26 + 10);
                    if ((piVar26[-1] == 0) || (in_RCX[(int64_t)*piVar26 + 0xac] != 0)) {
                        iVar15 = piVar26[1];
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a95e7;
                        iVar15 = func_0x0001802304b0(uVar5, iVar15);
                        if (iVar15 == 0) goto code_r0x0001801a95eb;
                        uVar6 = in_RCX[0x8c];
                        uVar7 = *in_RCX;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9601;
                        iVar21 = func_0x000180259210(uVar7, uVar5, uVar6);
                        if (iVar21 == 0) {
                            *piVar25 = 0;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9610;
                        func_0x000180258be0(iVar21);
                    } else {
code_r0x0001801a95eb:
                        *piVar25 = 0;
                    }
                    piVar26 = piVar26 + 0x12;
                    piVar25 = piVar25 + 0x12;
                    iVar18 = iVar18 + -1;
                } while (iVar18 != 0);
                uVar23 = *(uint64_t *)((int64_t)&arg_e0h + iVar17);
                if (in_RCX[0xd0] != 0) {
                    uVar4 = *(undefined4 *)((int64_t)&arg_c8h + iVar17);
                    puVar32 = (undefined2 *)(uVar20 + 0x3e);
                    puVar27 = (undefined2 *)(uVar19 + 0x8c8);
                    *(undefined8 *)((int64_t)&arg_d8h + iVar17) = 0;
                    uVar23 = uVar28;
                    uVar30 = uVar28;
                    do {
                        iVar18 = in_RCX[0xcf];
                        puVar2 = (undefined4 *)(uVar23 + 0x10 + iVar18);
                        uVar16 = *puVar2;
                        uVar10 = puVar2[1];
                        puVar1 = (undefined2 *)(uVar23 + iVar18);
                        uVar11 = puVar1[1];
                        uVar12 = puVar1[2];
                        uVar13 = puVar1[3];
                        uVar14 = puVar1[4];
                        iVar18 = *(int64_t *)(uVar23 + 0x30 + iVar18);
                        puVar27[-8] = *puVar1;
                        puVar27[-7] = uVar11;
                        puVar27[-6] = uVar12;
                        puVar27[-5] = uVar13;
                        *(undefined4 *)(puVar27 + -4) = uVar16;
                        *(undefined4 *)(puVar27 + -2) = uVar10;
                        *(undefined4 *)((int64_t)&arg_c8h + iVar17) = uVar16;
                        *(undefined4 *)((int64_t)&arg_c8h + iVar17 + 4) = uVar10;
                        *puVar27 = uVar14;
                        *puVar32 = uVar14;
                        uVar16 = 0;
                        if (iVar18 != 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a96a5;
                            uVar16 = func_0x00018022d1b0();
                        }
                        *(undefined4 *)(puVar27 + 2) = uVar16;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a96b3;
                        uVar16 = func_0x0001801a0350(uVar16);
                        uVar5 = *(undefined8 *)((int64_t)&arg_c8h + iVar17);
                        *(undefined4 *)(puVar27 + 4) = uVar16;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a96c3;
                        uVar16 = func_0x00018022d1b0(uVar5);
                        uVar5 = *(undefined8 *)((int64_t)&arg_c8h + iVar17);
                        *(undefined4 *)(puVar27 + 6) = uVar16;
                        *(int32_t *)(puVar27 + 8) = (int32_t)uVar30 + 9;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a96d9;
                        uVar16 = func_0x00018022d1b0(uVar5);
                        iVar18 = *(int64_t *)((int64_t)&arg_d8h + iVar17);
                        puVar32 = puVar32 + 1;
                        *(undefined4 *)(puVar27 + 10) = uVar16;
                        uVar23 = iVar18 + 0x68;
                        *(undefined4 *)(puVar27 + 0xc) = 0;
                        uVar30 = uVar30 + 1;
                        *(undefined4 *)(puVar27 + 0x12) = 0x304;
                        *(undefined4 *)(puVar27 + 0x14) = 0x304;
                        *(undefined8 *)(puVar27 + 0x16) = 0xffffffffffffffff;
                        *(undefined4 *)(puVar27 + 0xe) = uVar4;
                        *(undefined4 *)(puVar27 + 0x10) = 0;
                        puVar27 = puVar27 + 0x24;
                        *(uint64_t *)((int64_t)&arg_d8h + iVar17) = uVar23;
                    } while (uVar30 < (uint64_t)in_RCX[0xd0]);
                    uVar23 = *(uint64_t *)((int64_t)&arg_e0h + iVar17);
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9734;
                func_0x0001802299d0();
                uVar30 = uVar28;
                uVar31 = uVar28;
                do {
                    if (uVar23 == 0) {
code_r0x0001801a979e:
                        if (uVar23 != 0) goto code_r0x0001801a97a9;
                    } else {
                        iVar3 = *(int16_t *)(uVar31 + 0x1804ae090);
                        uVar22 = uVar19;
                        uVar24 = uVar28;
                        do {
                            if (*(int16_t *)(uVar22 + 0x10) == iVar3) {
                                if ((*(int32_t *)(uVar22 + 0x2c) == 0) || (*(int32_t *)(uVar22 + 0x30) != 0))
                                goto code_r0x0001801a979e;
                                *(undefined4 *)(uVar22 + 0x30) = 1;
                                *(int16_t *)(uVar20 + uVar30 * 2) = iVar3;
                                uVar30 = uVar30 + 1;
                                break;
                            }
                            uVar22 = uVar22 + 0x48;
                            uVar24 = uVar24 + 1;
                        } while (uVar24 < uVar23);
code_r0x0001801a97a9:
                        iVar3 = *(int16_t *)(uVar31 + 0x1804ae092);
                        uVar22 = uVar19;
                        uVar24 = uVar28;
                        do {
                            if (*(int16_t *)(uVar22 + 0x10) == iVar3) {
                                if ((*(int32_t *)(uVar22 + 0x2c) != 0) && (*(int32_t *)(uVar22 + 0x30) == 0)) {
                                    *(undefined4 *)(uVar22 + 0x30) = 1;
                                    *(int16_t *)(uVar20 + uVar30 * 2) = iVar3;
                                    uVar30 = uVar30 + 1;
                                }
                                break;
                            }
                            uVar22 = uVar22 + 0x48;
                            uVar24 = uVar24 + 1;
                        } while (uVar24 < uVar23);
                    }
                    uVar31 = uVar31 + 4;
                } while (uVar31 < 0x44);
                if (0x1f < uVar23) {
                    iVar18 = *(int64_t *)((int64_t)&arg_d0h + iVar17);
                    piVar25 = (int32_t *)(uVar19 + 0x8e8);
                    do {
                        if ((piVar25[-1] != 0) && (*piVar25 == 0)) {
                            *(undefined2 *)(uVar20 + uVar30 * 2) = *(undefined2 *)(piVar25 + -8);
                            uVar30 = uVar30 + 1;
                            iVar18 = *(int64_t *)((int64_t)&arg_d0h + iVar17);
                        }
                        piVar25 = piVar25 + 0x12;
                        iVar18 = iVar18 + -1;
                        *(int64_t *)((int64_t)&arg_d0h + iVar17) = iVar18;
                    } while (iVar18 != 0);
                }
                iVar18 = *(int64_t *)((int64_t)&var_8h + iVar17);
                in_RCX[0xca] = uVar19;
                uVar19 = 0;
                in_RCX[0xcb] = uVar20;
                uVar20 = 0;
                uVar28 = 1;
                in_RCX[200] = uVar23;
                in_RCX[0xc9] = uVar30;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a987b;
    func_0x000180224990(uVar19, 0x1804aeee0, 0x8fc);
    *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9890;
    func_0x000180224990(uVar20, 0x1804aeee0, 0x8fd);
    *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9898;
    func_0x00018022ecc0(iVar18);
    return uVar28;
}

// ============================================================
// Function: FUN_1801a9866
// Address: 0x1801a9866
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1801a94a0(int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_c8h, int64_t arg_d0h,
                      int64_t arg_d8h, int64_t arg_e0h, int64_t arg_1c0h)
{
    undefined2 *puVar1;
    undefined4 *puVar2;
    int16_t iVar3;
    undefined4 uVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int32_t iVar8;
    int32_t iVar9;
    undefined4 uVar10;
    undefined2 uVar11;
    undefined2 uVar12;
    undefined2 uVar13;
    undefined2 uVar14;
    int32_t iVar15;
    undefined4 uVar16;
    int64_t iVar17;
    int64_t iVar18;
    uint64_t uVar19;
    uint64_t uVar20;
    int64_t iVar21;
    uint64_t uVar22;
    undefined8 *in_RCX;
    uint64_t uVar23;
    uint64_t uVar24;
    int32_t *piVar25;
    int32_t *piVar26;
    undefined2 *puVar27;
    uint64_t uVar28;
    undefined8 unaff_RSI;
    int64_t iVar29;
    undefined8 unaff_RDI;
    uint64_t uVar30;
    uint64_t uVar31;
    undefined8 unaff_R12;
    undefined2 *puVar32;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801a94b3;
    iVar17 = func_0x00018045a350();
    iVar17 = -iVar17;
    uVar28 = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a94c6;
    iVar18 = func_0x00018022fd80();
    *(int64_t *)((int64_t)&var_8h + iVar17) = iVar18;
    uVar20 = uVar28;
    uVar19 = uVar28;
    if (in_RCX != (undefined8 *)0x0) {
        iVar21 = in_RCX[1];
        *(undefined8 *)((int64_t)&arg_90h + iVar17) = unaff_RSI;
        iVar29 = in_RCX[0xd0];
        *(int64_t *)((int64_t)&arg_d0h + iVar17) = iVar29;
        iVar29 = iVar29 + 0x1f;
        iVar21 = *(int64_t *)(iVar21 + 0xd8);
        *(int64_t *)((int64_t)&arg_e0h + iVar17) = iVar29;
        *(uint32_t *)((int64_t)&arg_c8h + iVar17) = ~(*(uint32_t *)(iVar21 + 0x50) >> 3) & 1;
        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9531;
        uVar19 = func_0x000180224e40(iVar29, 0x48, 0x1804aeee0, 0x898);
        if ((uVar19 != 0) && (uVar20 = 0, iVar18 != 0)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9560;
            uVar20 = func_0x000180224e40(iVar29, 2, 0x1804aeee0, 0x89c);
            if (uVar20 != 0) {
                *(undefined8 *)((int64_t)&arg_88h + iVar17) = unaff_RDI;
                *(undefined8 *)((int64_t)&arg_80h + iVar17) = unaff_R12;
                *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9581;
                func_0x000180229b10();
                uVar5 = *(undefined8 *)((int64_t)&var_8h + iVar17);
                piVar26 = (int32_t *)0x1804ae0f8;
                piVar25 = (int32_t *)(uVar19 + 0x2c);
                iVar18 = 0x1f;
                do {
                    iVar15 = piVar26[-5];
                    iVar8 = piVar26[-4];
                    iVar9 = piVar26[-3];
                    piVar25[-0xb] = piVar26[-6];
                    piVar25[-10] = iVar15;
                    piVar25[-9] = iVar8;
                    piVar25[-8] = iVar9;
                    iVar15 = piVar26[-1];
                    iVar8 = *piVar26;
                    iVar9 = piVar26[1];
                    piVar25[-7] = piVar26[-2];
                    piVar25[-6] = iVar15;
                    piVar25[-5] = iVar8;
                    piVar25[-4] = iVar9;
                    iVar15 = piVar26[3];
                    iVar8 = piVar26[4];
                    iVar9 = piVar26[5];
                    piVar25[-3] = piVar26[2];
                    piVar25[-2] = iVar15;
                    piVar25[-1] = iVar8;
                    *piVar25 = iVar9;
                    iVar15 = piVar26[7];
                    iVar8 = piVar26[8];
                    iVar9 = piVar26[9];
                    piVar25[1] = piVar26[6];
                    piVar25[2] = iVar15;
                    piVar25[3] = iVar8;
                    piVar25[4] = iVar9;
                    *(undefined8 *)(piVar25 + 5) = *(undefined8 *)(piVar26 + 10);
                    if ((piVar26[-1] == 0) || (in_RCX[(int64_t)*piVar26 + 0xac] != 0)) {
                        iVar15 = piVar26[1];
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a95e7;
                        iVar15 = func_0x0001802304b0(uVar5, iVar15);
                        if (iVar15 == 0) goto code_r0x0001801a95eb;
                        uVar6 = in_RCX[0x8c];
                        uVar7 = *in_RCX;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9601;
                        iVar21 = func_0x000180259210(uVar7, uVar5, uVar6);
                        if (iVar21 == 0) {
                            *piVar25 = 0;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9610;
                        func_0x000180258be0(iVar21);
                    } else {
code_r0x0001801a95eb:
                        *piVar25 = 0;
                    }
                    piVar26 = piVar26 + 0x12;
                    piVar25 = piVar25 + 0x12;
                    iVar18 = iVar18 + -1;
                } while (iVar18 != 0);
                uVar23 = *(uint64_t *)((int64_t)&arg_e0h + iVar17);
                if (in_RCX[0xd0] != 0) {
                    uVar4 = *(undefined4 *)((int64_t)&arg_c8h + iVar17);
                    puVar32 = (undefined2 *)(uVar20 + 0x3e);
                    puVar27 = (undefined2 *)(uVar19 + 0x8c8);
                    *(undefined8 *)((int64_t)&arg_d8h + iVar17) = 0;
                    uVar23 = uVar28;
                    uVar30 = uVar28;
                    do {
                        iVar18 = in_RCX[0xcf];
                        puVar2 = (undefined4 *)(uVar23 + 0x10 + iVar18);
                        uVar16 = *puVar2;
                        uVar10 = puVar2[1];
                        puVar1 = (undefined2 *)(uVar23 + iVar18);
                        uVar11 = puVar1[1];
                        uVar12 = puVar1[2];
                        uVar13 = puVar1[3];
                        uVar14 = puVar1[4];
                        iVar18 = *(int64_t *)(uVar23 + 0x30 + iVar18);
                        puVar27[-8] = *puVar1;
                        puVar27[-7] = uVar11;
                        puVar27[-6] = uVar12;
                        puVar27[-5] = uVar13;
                        *(undefined4 *)(puVar27 + -4) = uVar16;
                        *(undefined4 *)(puVar27 + -2) = uVar10;
                        *(undefined4 *)((int64_t)&arg_c8h + iVar17) = uVar16;
                        *(undefined4 *)((int64_t)&arg_c8h + iVar17 + 4) = uVar10;
                        *puVar27 = uVar14;
                        *puVar32 = uVar14;
                        uVar16 = 0;
                        if (iVar18 != 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a96a5;
                            uVar16 = func_0x00018022d1b0();
                        }
                        *(undefined4 *)(puVar27 + 2) = uVar16;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a96b3;
                        uVar16 = func_0x0001801a0350(uVar16);
                        uVar5 = *(undefined8 *)((int64_t)&arg_c8h + iVar17);
                        *(undefined4 *)(puVar27 + 4) = uVar16;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a96c3;
                        uVar16 = func_0x00018022d1b0(uVar5);
                        uVar5 = *(undefined8 *)((int64_t)&arg_c8h + iVar17);
                        *(undefined4 *)(puVar27 + 6) = uVar16;
                        *(int32_t *)(puVar27 + 8) = (int32_t)uVar30 + 9;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a96d9;
                        uVar16 = func_0x00018022d1b0(uVar5);
                        iVar18 = *(int64_t *)((int64_t)&arg_d8h + iVar17);
                        puVar32 = puVar32 + 1;
                        *(undefined4 *)(puVar27 + 10) = uVar16;
                        uVar23 = iVar18 + 0x68;
                        *(undefined4 *)(puVar27 + 0xc) = 0;
                        uVar30 = uVar30 + 1;
                        *(undefined4 *)(puVar27 + 0x12) = 0x304;
                        *(undefined4 *)(puVar27 + 0x14) = 0x304;
                        *(undefined8 *)(puVar27 + 0x16) = 0xffffffffffffffff;
                        *(undefined4 *)(puVar27 + 0xe) = uVar4;
                        *(undefined4 *)(puVar27 + 0x10) = 0;
                        puVar27 = puVar27 + 0x24;
                        *(uint64_t *)((int64_t)&arg_d8h + iVar17) = uVar23;
                    } while (uVar30 < (uint64_t)in_RCX[0xd0]);
                    uVar23 = *(uint64_t *)((int64_t)&arg_e0h + iVar17);
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9734;
                func_0x0001802299d0();
                uVar30 = uVar28;
                uVar31 = uVar28;
                do {
                    if (uVar23 == 0) {
code_r0x0001801a979e:
                        if (uVar23 != 0) goto code_r0x0001801a97a9;
                    } else {
                        iVar3 = *(int16_t *)(uVar31 + 0x1804ae090);
                        uVar22 = uVar19;
                        uVar24 = uVar28;
                        do {
                            if (*(int16_t *)(uVar22 + 0x10) == iVar3) {
                                if ((*(int32_t *)(uVar22 + 0x2c) == 0) || (*(int32_t *)(uVar22 + 0x30) != 0))
                                goto code_r0x0001801a979e;
                                *(undefined4 *)(uVar22 + 0x30) = 1;
                                *(int16_t *)(uVar20 + uVar30 * 2) = iVar3;
                                uVar30 = uVar30 + 1;
                                break;
                            }
                            uVar22 = uVar22 + 0x48;
                            uVar24 = uVar24 + 1;
                        } while (uVar24 < uVar23);
code_r0x0001801a97a9:
                        iVar3 = *(int16_t *)(uVar31 + 0x1804ae092);
                        uVar22 = uVar19;
                        uVar24 = uVar28;
                        do {
                            if (*(int16_t *)(uVar22 + 0x10) == iVar3) {
                                if ((*(int32_t *)(uVar22 + 0x2c) != 0) && (*(int32_t *)(uVar22 + 0x30) == 0)) {
                                    *(undefined4 *)(uVar22 + 0x30) = 1;
                                    *(int16_t *)(uVar20 + uVar30 * 2) = iVar3;
                                    uVar30 = uVar30 + 1;
                                }
                                break;
                            }
                            uVar22 = uVar22 + 0x48;
                            uVar24 = uVar24 + 1;
                        } while (uVar24 < uVar23);
                    }
                    uVar31 = uVar31 + 4;
                } while (uVar31 < 0x44);
                if (0x1f < uVar23) {
                    iVar18 = *(int64_t *)((int64_t)&arg_d0h + iVar17);
                    piVar25 = (int32_t *)(uVar19 + 0x8e8);
                    do {
                        if ((piVar25[-1] != 0) && (*piVar25 == 0)) {
                            *(undefined2 *)(uVar20 + uVar30 * 2) = *(undefined2 *)(piVar25 + -8);
                            uVar30 = uVar30 + 1;
                            iVar18 = *(int64_t *)((int64_t)&arg_d0h + iVar17);
                        }
                        piVar25 = piVar25 + 0x12;
                        iVar18 = iVar18 + -1;
                        *(int64_t *)((int64_t)&arg_d0h + iVar17) = iVar18;
                    } while (iVar18 != 0);
                }
                iVar18 = *(int64_t *)((int64_t)&var_8h + iVar17);
                in_RCX[0xca] = uVar19;
                uVar19 = 0;
                in_RCX[0xcb] = uVar20;
                uVar20 = 0;
                uVar28 = 1;
                in_RCX[200] = uVar23;
                in_RCX[0xc9] = uVar30;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a987b;
    func_0x000180224990(uVar19, 0x1804aeee0, 0x8fc);
    *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9890;
    func_0x000180224990(uVar20, 0x1804aeee0, 0x8fd);
    *(undefined8 *)((int64_t)&uStack_30 + iVar17) = 0x1801a9898;
    func_0x00018022ecc0(iVar18);
    return uVar28;
}

// ============================================================
// Function: FUN_1801a98b0
// Address: 0x1801a98b0
// Size: 161 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_49h
// WARNING: [rz-ghidra] Removing arg arg_678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_670h because it doesn't fit into ProtoModel

undefined8 fcn.1801a98b0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t in_RCX;
    uint64_t uVar7;
    uint64_t uVar8;
    int16_t in_DX;
    int16_t *piVar9;
    undefined8 unaff_RDI;
    int64_t iVar10;
    undefined8 in_R8;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_30;
    
    uStack_30 = 0x1801a98c2;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a98d6;
    iVar3 = fcn.180203a00(in_R8);
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar4 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar4)) && (iVar4 != 0x10000)) {
        if (iVar3 == 0x74) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a990a;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9922;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar5), 
                          *(int64_t *)(&stack0x00000028 + iVar5));
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9938;
            fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8));
            return 0;
        }
        if (iVar3 == 6) {
            iVar3 = 0x390;
        }
    }
    iVar10 = *(int64_t *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_58h + iVar5) = unaff_R15;
    uVar6 = 0;
    uVar8 = *(uint64_t *)(iVar10 + 0x640);
    iVar10 = *(int64_t *)(iVar10 + 0x650);
    uVar7 = uVar6;
    if (uVar8 != 0) {
        do {
            if (*(int16_t *)(iVar10 + 0x10) == in_DX) {
                if ((*(int32_t *)(iVar10 + 0x2c) != 0) && (iVar10 != 0)) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a99ed;
                    iVar4 = fcn.1801adb40(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8));
                    if (iVar4 != 0) {
                        if ((iVar3 == -1) && (iVar3 = *(int32_t *)(iVar10 + 0x1c), iVar3 == -1)) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9a03;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9a1b;
                            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5), 
                                          *(int64_t *)(&stack0x00000028 + iVar5));
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9a31;
                            fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8));
                            return 0xffffffff;
                        }
                        if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                             (iVar4 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar4)) && (iVar4 != 0x10000)) &&
                           ((*(int32_t *)(iVar10 + 0x14) == 0x40 || (*(int32_t *)(iVar10 + 0x14) == 0x2a3)))) {
code_r0x0001801a9a76:
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9a7b;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
                            goto code_r0x0001801a9993;
                        }
                        iVar4 = iVar3;
                        if (iVar3 == *(int32_t *)(iVar10 + 0x1c)) {
                            if (iVar3 == 0x390) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9a92;
                                iVar4 = fcn.180203a00(in_R8);
                            }
                        } else if ((*(int32_t *)(iVar10 + 0x1c) != 0x390) || (iVar3 != 6)) goto code_r0x0001801a9a76;
                        uVar2 = *(undefined8 *)(in_RCX + 8);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9aa9;
                        iVar4 = fcn.1801a2020(iVar4, (int64_t)&arg_60h + iVar5, uVar2);
                        if ((iVar4 == 0) || (*(int32_t *)(iVar10 + 0x20) != *(int32_t *)((int64_t)&arg_60h + iVar5))) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9d54;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
                            goto code_r0x0001801a9993;
                        }
                        if (iVar3 != 0x198) {
                            if ((*(uint32_t *)(*(int64_t *)(in_RCX + 0x878) + 0x1c) & 0x30000) == 0)
                            goto code_r0x0001801a9c34;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9c2d;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
                            goto code_r0x0001801a9bf5;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9ad8;
                        iVar3 = fcn.1801aadc0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5));
                        if (iVar3 == 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9ae1;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9af9;
                            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5), 
                                          *(int64_t *)(&stack0x00000028 + iVar5));
                            goto code_r0x0001801a99b1;
                        }
                        if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                             (iVar3 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar3)) && (iVar3 != 0x10000)) ||
                           ((*(uint32_t *)(*(int64_t *)(in_RCX + 0x878) + 0x1c) & 0x30000) != 0)) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9b49;
                            iVar3 = fcn.1801a86f0(*(int64_t *)(&stack0x00000028 + iVar5), 
                                                  *(int64_t *)((int64_t)&arg_60h + iVar5));
                            if ((*(int32_t *)(iVar10 + 0x28) == 0) || (iVar3 == *(int32_t *)(iVar10 + 0x28)))
                            goto code_r0x0001801a9b7c;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9b59;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
code_r0x0001801a9b5e:
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9b71;
                            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5), 
                                          *(int64_t *)(&stack0x00000028 + iVar5));
                            goto code_r0x0001801a99b1;
                        }
code_r0x0001801a9b7c:
                        if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
                            (iVar3 = **(int32_t **)(in_RCX + 0x18), iVar3 < 0x304)) || (iVar3 == 0x10000)) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9ba9;
                            fcn.1801ab340(in_R8);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9bba;
                            iVar3 = fcn.1801aac50(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                                  *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
                            if (iVar3 == 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9bc3;
                                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                              *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
                                goto code_r0x0001801a9b5e;
                            }
                            if (((*(uint32_t *)(*(int64_t *)(in_RCX + 0x878) + 0x1c) & 0x30000) != 0) &&
                               ((in_DX - 0x403U & 0xfeff) != 0)) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9bf0;
                                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                              *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
                                goto code_r0x0001801a9bf5;
                            }
                        }
code_r0x0001801a9c34:
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9c46;
                        uVar7 = fcn.1801a9eb0(in_RCX, 1, (int64_t)aiStackX_10 + iVar5 + -8);
                        uVar8 = uVar6;
                        if (uVar7 == 0) goto code_r0x0001801a9c64;
                        piVar9 = *(int16_t **)((int64_t)aiStackX_10 + iVar5 + -8);
                        goto code_r0x0001801a9c53;
                    }
                }
                break;
            }
            iVar10 = iVar10 + 0x48;
            uVar7 = uVar7 + 1;
        } while (uVar7 < uVar8);
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a998e;
    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
code_r0x0001801a9993:
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a99a6;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                  *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar5), 
                  *(int64_t *)(&stack0x00000028 + iVar5));
    goto code_r0x0001801a99b1;
    while( true ) {
        uVar8 = uVar8 + 1;
        piVar9 = piVar9 + 1;
        if (uVar7 <= uVar8) break;
code_r0x0001801a9c53:
        if (in_DX == *piVar9) goto code_r0x0001801a9c8e;
    }
code_r0x0001801a9c64:
    if ((uVar8 == uVar7) &&
       ((*(int32_t *)(iVar10 + 0x14) != 0x40 || ((*(uint32_t *)(*(int64_t *)(in_RCX + 0x878) + 0x1c) & 0x30001) != 0))))
    {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9c84;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10)
                     );
    } else {
code_r0x0001801a9c8e:
        if (*(int32_t *)(iVar10 + 0x14) != 0) {
            uVar1 = *(undefined4 *)(iVar10 + 0x18);
            uVar2 = *(undefined8 *)(in_RCX + 8);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9d0b;
            uVar6 = fcn.1801a08e0(uVar2, uVar1);
            if (uVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9d18;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9d30;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar5), *(int64_t *)(&stack0x00000028 + iVar5));
                goto code_r0x0001801a99b1;
            }
        }
        *(char *)((int64_t)&arg_48h + iVar5) = (char)((uint16_t)in_DX >> 8);
        *(char *)((int64_t)&arg_48h + iVar5 + 1) = (char)in_DX;
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9cb3;
        iVar3 = fcn.1801a8420(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8));
        if (iVar3 != 0) {
            if (uVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9cca;
                fcn.180203a00(uVar6);
            }
            *(int64_t *)(&stack0xfffffffffffffff8 + iVar5) = (int64_t)&arg_48h + iVar5;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9cea;
            iVar3 = fcn.1801a2690(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                                  *(int64_t *)(&stack0x00000040 + iVar5));
            if (iVar3 != 0) {
                *(int64_t *)(in_RCX + 0x400) = iVar10;
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9d45;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10)
                     );
    }
code_r0x0001801a9bf5:
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9c08;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                  *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar5), 
                  *(int64_t *)(&stack0x00000028 + iVar5));
code_r0x0001801a99b1:
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a99bc;
    fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8));
    return 0;
}

// ============================================================
// Function: FUN_1801a9951
// Address: 0x1801a9951
// Size: 134 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_49h
// WARNING: [rz-ghidra] Removing arg arg_678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_670h because it doesn't fit into ProtoModel

undefined8 fcn.1801a98b0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t in_RCX;
    uint64_t uVar7;
    uint64_t uVar8;
    int16_t in_DX;
    int16_t *piVar9;
    undefined8 unaff_RDI;
    int64_t iVar10;
    undefined8 in_R8;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_30;
    
    uStack_30 = 0x1801a98c2;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a98d6;
    iVar3 = fcn.180203a00(in_R8);
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar4 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar4)) && (iVar4 != 0x10000)) {
        if (iVar3 == 0x74) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a990a;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9922;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar5), 
                          *(int64_t *)(&stack0x00000028 + iVar5));
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9938;
            fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8));
            return 0;
        }
        if (iVar3 == 6) {
            iVar3 = 0x390;
        }
    }
    iVar10 = *(int64_t *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_58h + iVar5) = unaff_R15;
    uVar6 = 0;
    uVar8 = *(uint64_t *)(iVar10 + 0x640);
    iVar10 = *(int64_t *)(iVar10 + 0x650);
    uVar7 = uVar6;
    if (uVar8 != 0) {
        do {
            if (*(int16_t *)(iVar10 + 0x10) == in_DX) {
                if ((*(int32_t *)(iVar10 + 0x2c) != 0) && (iVar10 != 0)) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a99ed;
                    iVar4 = fcn.1801adb40(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8));
                    if (iVar4 != 0) {
                        if ((iVar3 == -1) && (iVar3 = *(int32_t *)(iVar10 + 0x1c), iVar3 == -1)) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9a03;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9a1b;
                            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5), 
                                          *(int64_t *)(&stack0x00000028 + iVar5));
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9a31;
                            fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8));
                            return 0xffffffff;
                        }
                        if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                             (iVar4 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar4)) && (iVar4 != 0x10000)) &&
                           ((*(int32_t *)(iVar10 + 0x14) == 0x40 || (*(int32_t *)(iVar10 + 0x14) == 0x2a3)))) {
code_r0x0001801a9a76:
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9a7b;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
                            goto code_r0x0001801a9993;
                        }
                        iVar4 = iVar3;
                        if (iVar3 == *(int32_t *)(iVar10 + 0x1c)) {
                            if (iVar3 == 0x390) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9a92;
                                iVar4 = fcn.180203a00(in_R8);
                            }
                        } else if ((*(int32_t *)(iVar10 + 0x1c) != 0x390) || (iVar3 != 6)) goto code_r0x0001801a9a76;
                        uVar2 = *(undefined8 *)(in_RCX + 8);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9aa9;
                        iVar4 = fcn.1801a2020(iVar4, (int64_t)&arg_60h + iVar5, uVar2);
                        if ((iVar4 == 0) || (*(int32_t *)(iVar10 + 0x20) != *(int32_t *)((int64_t)&arg_60h + iVar5))) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9d54;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
                            goto code_r0x0001801a9993;
                        }
                        if (iVar3 != 0x198) {
                            if ((*(uint32_t *)(*(int64_t *)(in_RCX + 0x878) + 0x1c) & 0x30000) == 0)
                            goto code_r0x0001801a9c34;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9c2d;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
                            goto code_r0x0001801a9bf5;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9ad8;
                        iVar3 = fcn.1801aadc0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5));
                        if (iVar3 == 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9ae1;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9af9;
                            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5), 
                                          *(int64_t *)(&stack0x00000028 + iVar5));
                            goto code_r0x0001801a99b1;
                        }
                        if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                             (iVar3 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar3)) && (iVar3 != 0x10000)) ||
                           ((*(uint32_t *)(*(int64_t *)(in_RCX + 0x878) + 0x1c) & 0x30000) != 0)) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9b49;
                            iVar3 = fcn.1801a86f0(*(int64_t *)(&stack0x00000028 + iVar5), 
                                                  *(int64_t *)((int64_t)&arg_60h + iVar5));
                            if ((*(int32_t *)(iVar10 + 0x28) == 0) || (iVar3 == *(int32_t *)(iVar10 + 0x28)))
                            goto code_r0x0001801a9b7c;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9b59;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
code_r0x0001801a9b5e:
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9b71;
                            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5), 
                                          *(int64_t *)(&stack0x00000028 + iVar5));
                            goto code_r0x0001801a99b1;
                        }
code_r0x0001801a9b7c:
                        if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
                            (iVar3 = **(int32_t **)(in_RCX + 0x18), iVar3 < 0x304)) || (iVar3 == 0x10000)) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9ba9;
                            fcn.1801ab340(in_R8);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9bba;
                            iVar3 = fcn.1801aac50(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                                  *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
                            if (iVar3 == 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9bc3;
                                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                              *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
                                goto code_r0x0001801a9b5e;
                            }
                            if (((*(uint32_t *)(*(int64_t *)(in_RCX + 0x878) + 0x1c) & 0x30000) != 0) &&
                               ((in_DX - 0x403U & 0xfeff) != 0)) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9bf0;
                                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                              *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
                                goto code_r0x0001801a9bf5;
                            }
                        }
code_r0x0001801a9c34:
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9c46;
                        uVar7 = fcn.1801a9eb0(in_RCX, 1, (int64_t)aiStackX_10 + iVar5 + -8);
                        uVar8 = uVar6;
                        if (uVar7 == 0) goto code_r0x0001801a9c64;
                        piVar9 = *(int16_t **)((int64_t)aiStackX_10 + iVar5 + -8);
                        goto code_r0x0001801a9c53;
                    }
                }
                break;
            }
            iVar10 = iVar10 + 0x48;
            uVar7 = uVar7 + 1;
        } while (uVar7 < uVar8);
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a998e;
    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
code_r0x0001801a9993:
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a99a6;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                  *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar5), 
                  *(int64_t *)(&stack0x00000028 + iVar5));
    goto code_r0x0001801a99b1;
    while( true ) {
        uVar8 = uVar8 + 1;
        piVar9 = piVar9 + 1;
        if (uVar7 <= uVar8) break;
code_r0x0001801a9c53:
        if (in_DX == *piVar9) goto code_r0x0001801a9c8e;
    }
code_r0x0001801a9c64:
    if ((uVar8 == uVar7) &&
       ((*(int32_t *)(iVar10 + 0x14) != 0x40 || ((*(uint32_t *)(*(int64_t *)(in_RCX + 0x878) + 0x1c) & 0x30001) != 0))))
    {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9c84;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10)
                     );
    } else {
code_r0x0001801a9c8e:
        if (*(int32_t *)(iVar10 + 0x14) != 0) {
            uVar1 = *(undefined4 *)(iVar10 + 0x18);
            uVar2 = *(undefined8 *)(in_RCX + 8);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9d0b;
            uVar6 = fcn.1801a08e0(uVar2, uVar1);
            if (uVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9d18;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9d30;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar5), *(int64_t *)(&stack0x00000028 + iVar5));
                goto code_r0x0001801a99b1;
            }
        }
        *(char *)((int64_t)&arg_48h + iVar5) = (char)((uint16_t)in_DX >> 8);
        *(char *)((int64_t)&arg_48h + iVar5 + 1) = (char)in_DX;
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9cb3;
        iVar3 = fcn.1801a8420(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8));
        if (iVar3 != 0) {
            if (uVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9cca;
                fcn.180203a00(uVar6);
            }
            *(int64_t *)(&stack0xfffffffffffffff8 + iVar5) = (int64_t)&arg_48h + iVar5;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9cea;
            iVar3 = fcn.1801a2690(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                                  *(int64_t *)(&stack0x00000040 + iVar5));
            if (iVar3 != 0) {
                *(int64_t *)(in_RCX + 0x400) = iVar10;
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9d45;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10)
                     );
    }
code_r0x0001801a9bf5:
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9c08;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                  *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar5), 
                  *(int64_t *)(&stack0x00000028 + iVar5));
code_r0x0001801a99b1:
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a99bc;
    fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8));
    return 0;
}

// ============================================================
// Function: FUN_1801a99d7
// Address: 0x1801a99d7
// Size: 903 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_49h
// WARNING: [rz-ghidra] Removing arg arg_678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_670h because it doesn't fit into ProtoModel

undefined8 fcn.1801a98b0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t in_RCX;
    uint64_t uVar7;
    uint64_t uVar8;
    int16_t in_DX;
    int16_t *piVar9;
    undefined8 unaff_RDI;
    int64_t iVar10;
    undefined8 in_R8;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_30;
    
    uStack_30 = 0x1801a98c2;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a98d6;
    iVar3 = fcn.180203a00(in_R8);
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar4 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar4)) && (iVar4 != 0x10000)) {
        if (iVar3 == 0x74) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a990a;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9922;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar5), 
                          *(int64_t *)(&stack0x00000028 + iVar5));
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9938;
            fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8));
            return 0;
        }
        if (iVar3 == 6) {
            iVar3 = 0x390;
        }
    }
    iVar10 = *(int64_t *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_58h + iVar5) = unaff_R15;
    uVar6 = 0;
    uVar8 = *(uint64_t *)(iVar10 + 0x640);
    iVar10 = *(int64_t *)(iVar10 + 0x650);
    uVar7 = uVar6;
    if (uVar8 != 0) {
        do {
            if (*(int16_t *)(iVar10 + 0x10) == in_DX) {
                if ((*(int32_t *)(iVar10 + 0x2c) != 0) && (iVar10 != 0)) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a99ed;
                    iVar4 = fcn.1801adb40(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8));
                    if (iVar4 != 0) {
                        if ((iVar3 == -1) && (iVar3 = *(int32_t *)(iVar10 + 0x1c), iVar3 == -1)) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9a03;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9a1b;
                            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5), 
                                          *(int64_t *)(&stack0x00000028 + iVar5));
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9a31;
                            fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8));
                            return 0xffffffff;
                        }
                        if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                             (iVar4 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar4)) && (iVar4 != 0x10000)) &&
                           ((*(int32_t *)(iVar10 + 0x14) == 0x40 || (*(int32_t *)(iVar10 + 0x14) == 0x2a3)))) {
code_r0x0001801a9a76:
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9a7b;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
                            goto code_r0x0001801a9993;
                        }
                        iVar4 = iVar3;
                        if (iVar3 == *(int32_t *)(iVar10 + 0x1c)) {
                            if (iVar3 == 0x390) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9a92;
                                iVar4 = fcn.180203a00(in_R8);
                            }
                        } else if ((*(int32_t *)(iVar10 + 0x1c) != 0x390) || (iVar3 != 6)) goto code_r0x0001801a9a76;
                        uVar2 = *(undefined8 *)(in_RCX + 8);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9aa9;
                        iVar4 = fcn.1801a2020(iVar4, (int64_t)&arg_60h + iVar5, uVar2);
                        if ((iVar4 == 0) || (*(int32_t *)(iVar10 + 0x20) != *(int32_t *)((int64_t)&arg_60h + iVar5))) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9d54;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
                            goto code_r0x0001801a9993;
                        }
                        if (iVar3 != 0x198) {
                            if ((*(uint32_t *)(*(int64_t *)(in_RCX + 0x878) + 0x1c) & 0x30000) == 0)
                            goto code_r0x0001801a9c34;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9c2d;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
                            goto code_r0x0001801a9bf5;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9ad8;
                        iVar3 = fcn.1801aadc0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5));
                        if (iVar3 == 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9ae1;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9af9;
                            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5), 
                                          *(int64_t *)(&stack0x00000028 + iVar5));
                            goto code_r0x0001801a99b1;
                        }
                        if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                             (iVar3 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar3)) && (iVar3 != 0x10000)) ||
                           ((*(uint32_t *)(*(int64_t *)(in_RCX + 0x878) + 0x1c) & 0x30000) != 0)) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9b49;
                            iVar3 = fcn.1801a86f0(*(int64_t *)(&stack0x00000028 + iVar5), 
                                                  *(int64_t *)((int64_t)&arg_60h + iVar5));
                            if ((*(int32_t *)(iVar10 + 0x28) == 0) || (iVar3 == *(int32_t *)(iVar10 + 0x28)))
                            goto code_r0x0001801a9b7c;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9b59;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
code_r0x0001801a9b5e:
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9b71;
                            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5), 
                                          *(int64_t *)(&stack0x00000028 + iVar5));
                            goto code_r0x0001801a99b1;
                        }
code_r0x0001801a9b7c:
                        if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
                            (iVar3 = **(int32_t **)(in_RCX + 0x18), iVar3 < 0x304)) || (iVar3 == 0x10000)) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9ba9;
                            fcn.1801ab340(in_R8);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9bba;
                            iVar3 = fcn.1801aac50(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                                  *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
                            if (iVar3 == 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9bc3;
                                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                              *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
                                goto code_r0x0001801a9b5e;
                            }
                            if (((*(uint32_t *)(*(int64_t *)(in_RCX + 0x878) + 0x1c) & 0x30000) != 0) &&
                               ((in_DX - 0x403U & 0xfeff) != 0)) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9bf0;
                                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                              *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
                                goto code_r0x0001801a9bf5;
                            }
                        }
code_r0x0001801a9c34:
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9c46;
                        uVar7 = fcn.1801a9eb0(in_RCX, 1, (int64_t)aiStackX_10 + iVar5 + -8);
                        uVar8 = uVar6;
                        if (uVar7 == 0) goto code_r0x0001801a9c64;
                        piVar9 = *(int16_t **)((int64_t)aiStackX_10 + iVar5 + -8);
                        goto code_r0x0001801a9c53;
                    }
                }
                break;
            }
            iVar10 = iVar10 + 0x48;
            uVar7 = uVar7 + 1;
        } while (uVar7 < uVar8);
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a998e;
    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
code_r0x0001801a9993:
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a99a6;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                  *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar5), 
                  *(int64_t *)(&stack0x00000028 + iVar5));
    goto code_r0x0001801a99b1;
    while( true ) {
        uVar8 = uVar8 + 1;
        piVar9 = piVar9 + 1;
        if (uVar7 <= uVar8) break;
code_r0x0001801a9c53:
        if (in_DX == *piVar9) goto code_r0x0001801a9c8e;
    }
code_r0x0001801a9c64:
    if ((uVar8 == uVar7) &&
       ((*(int32_t *)(iVar10 + 0x14) != 0x40 || ((*(uint32_t *)(*(int64_t *)(in_RCX + 0x878) + 0x1c) & 0x30001) != 0))))
    {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9c84;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10)
                     );
    } else {
code_r0x0001801a9c8e:
        if (*(int32_t *)(iVar10 + 0x14) != 0) {
            uVar1 = *(undefined4 *)(iVar10 + 0x18);
            uVar2 = *(undefined8 *)(in_RCX + 8);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9d0b;
            uVar6 = fcn.1801a08e0(uVar2, uVar1);
            if (uVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9d18;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10));
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9d30;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar5), *(int64_t *)(&stack0x00000028 + iVar5));
                goto code_r0x0001801a99b1;
            }
        }
        *(char *)((int64_t)&arg_48h + iVar5) = (char)((uint16_t)in_DX >> 8);
        *(char *)((int64_t)&arg_48h + iVar5 + 1) = (char)in_DX;
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9cb3;
        iVar3 = fcn.1801a8420(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8));
        if (iVar3 != 0) {
            if (uVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9cca;
                fcn.180203a00(uVar6);
            }
            *(int64_t *)(&stack0xfffffffffffffff8 + iVar5) = (int64_t)&arg_48h + iVar5;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9cea;
            iVar3 = fcn.1801a2690(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                                  *(int64_t *)(&stack0x00000040 + iVar5));
            if (iVar3 != 0) {
                *(int64_t *)(in_RCX + 0x400) = iVar10;
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9d45;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10)
                     );
    }
code_r0x0001801a9bf5:
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a9c08;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -0x10), 
                  *(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar5), 
                  *(int64_t *)(&stack0x00000028 + iVar5));
code_r0x0001801a99b1:
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a99bc;
    fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8));
    return 0;
}

// ============================================================
// Function: FUN_1801a9d60
// Address: 0x1801a9d60
// Size: 329 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int32_t fcn.1801a9d60(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int16_t iVar1;
    uint64_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    uint64_t uVar5;
    undefined8 in_RDX;
    int64_t iVar6;
    uint64_t uVar7;
    int32_t iVar8;
    int16_t *in_R8;
    uint64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801a9d84;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar8 = 0;
    uVar7 = 0;
    if (in_R9 != 0) {
        do {
            uVar5 = 0;
            uVar2 = *(uint64_t *)(*(int64_t *)(in_RCX + 8) + 0x640);
            iVar6 = *(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x650);
            if (uVar2 != 0) {
                do {
                    if (*(int16_t *)(iVar6 + 0x10) == *in_R8) {
                        if (*(int32_t *)(iVar6 + 0x2c) != 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a9de5;
                            iVar3 = fcn.1801adb40(*(int64_t *)((int64_t)&var_8h + iVar4), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar4), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar4));
                            if (iVar3 != 0) {
                                iVar1 = *in_R8;
                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a9dfa;
                                iVar3 = func_0x0001802446f0(in_RDX, iVar1, 2);
                                if (iVar3 == 0) {
                                    return 0;
                                }
                                if ((iVar8 == 0) &&
                                   (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0
                                      || (iVar3 = **(int32_t **)(in_RCX + 0x18), iVar3 < 0x304)) || (iVar3 == 0x10000))
                                    || (((*(int32_t *)(iVar6 + 0x1c) != 6 && (*(int32_t *)(iVar6 + 0x14) != 0x40)) &&
                                        (*(int32_t *)(iVar6 + 0x14) != 0x2a3)))))) {
                                    iVar8 = 1;
                                }
                            }
                        }
                        break;
                    }
                    iVar6 = iVar6 + 0x48;
                    uVar5 = uVar5 + 1;
                } while (uVar5 < uVar2);
            }
            uVar7 = uVar7 + 1;
            in_R8 = in_R8 + 1;
        } while (uVar7 < in_R9);
        if (iVar8 != 0) {
            return iVar8;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a9e5a;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a9e72;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                  *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)((int64_t)&arg_38h + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a9e84;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
    return iVar8;
}

// ============================================================
// Function: FUN_1801a9f60
// Address: 0x1801a9f60
// Size: 45 bytes
// ============================================================
int64_t fcn.1801a9f60(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h,
                     int64_t arg_78h)
{
    uint64_t uVar1;
    int16_t *piVar2;
    int32_t iVar3;
    int64_t iVar4;
    int16_t *piVar5;
    int64_t in_RCX;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 unaff_RDI;
    int16_t *in_R8;
    int64_t in_R9;
    undefined8 unaff_R12;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801a9f73;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar9 = 0;
    if (in_R9 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
    uVar1 = *(uint64_t *)((int64_t)&arg_50h + iVar4);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_R12;
    piVar2 = *(int16_t **)((int64_t)&arg_48h + iVar4);
code_r0x0001801a9fb0:
    uVar6 = 0;
    uVar7 = *(uint64_t *)(*(int64_t *)(in_RCX + 8) + 0x640);
    iVar8 = *(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x650);
    if (uVar7 != 0) {
        do {
            if (*(int16_t *)(iVar8 + 0x10) == *in_R8) {
                if ((*(int32_t *)(iVar8 + 0x2c) != 0) && (iVar8 != 0)) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a9fff;
                    iVar3 = func_0x0001801aa060(in_RCX, 0x5000c, iVar8);
                    if ((iVar3 != 0) && (uVar7 = 0, uVar1 != 0)) {
                        piVar5 = piVar2;
                        goto code_r0x0001801aa011;
                    }
                }
                break;
            }
            iVar8 = iVar8 + 0x48;
            uVar6 = uVar6 + 1;
        } while (uVar6 < uVar7);
    }
    goto code_r0x0001801aa033;
    while( true ) {
        uVar7 = uVar7 + 1;
        piVar5 = piVar5 + 1;
        if (uVar1 <= uVar7) break;
code_r0x0001801aa011:
        if (*in_R8 == *piVar5) {
            iVar9 = iVar9 + 1;
            if (in_RDX != (int64_t *)0x0) {
                *in_RDX = iVar8;
                in_RDX = in_RDX + 1;
            }
            break;
        }
    }
code_r0x0001801aa033:
    in_R8 = in_R8 + 1;
    in_R9 = in_R9 + -1;
    if (in_R9 == 0) {
        return iVar9;
    }
    goto code_r0x0001801a9fb0;
}

// ============================================================
// Function: FUN_1801a9f8d
// Address: 0x1801a9f8d
// Size: 195 bytes
// ============================================================
int64_t fcn.1801a9f60(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h,
                     int64_t arg_78h)
{
    uint64_t uVar1;
    int16_t *piVar2;
    int32_t iVar3;
    int64_t iVar4;
    int16_t *piVar5;
    int64_t in_RCX;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 unaff_RDI;
    int16_t *in_R8;
    int64_t in_R9;
    undefined8 unaff_R12;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801a9f73;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar9 = 0;
    if (in_R9 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
    uVar1 = *(uint64_t *)((int64_t)&arg_50h + iVar4);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_R12;
    piVar2 = *(int16_t **)((int64_t)&arg_48h + iVar4);
code_r0x0001801a9fb0:
    uVar6 = 0;
    uVar7 = *(uint64_t *)(*(int64_t *)(in_RCX + 8) + 0x640);
    iVar8 = *(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x650);
    if (uVar7 != 0) {
        do {
            if (*(int16_t *)(iVar8 + 0x10) == *in_R8) {
                if ((*(int32_t *)(iVar8 + 0x2c) != 0) && (iVar8 != 0)) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a9fff;
                    iVar3 = func_0x0001801aa060(in_RCX, 0x5000c, iVar8);
                    if ((iVar3 != 0) && (uVar7 = 0, uVar1 != 0)) {
                        piVar5 = piVar2;
                        goto code_r0x0001801aa011;
                    }
                }
                break;
            }
            iVar8 = iVar8 + 0x48;
            uVar6 = uVar6 + 1;
        } while (uVar6 < uVar7);
    }
    goto code_r0x0001801aa033;
    while( true ) {
        uVar7 = uVar7 + 1;
        piVar5 = piVar5 + 1;
        if (uVar1 <= uVar7) break;
code_r0x0001801aa011:
        if (*in_R8 == *piVar5) {
            iVar9 = iVar9 + 1;
            if (in_RDX != (int64_t *)0x0) {
                *in_RDX = iVar8;
                in_RDX = in_RDX + 1;
            }
            break;
        }
    }
code_r0x0001801aa033:
    in_R8 = in_R8 + 1;
    in_R9 = in_R9 + -1;
    if (in_R9 == 0) {
        return iVar9;
    }
    goto code_r0x0001801a9fb0;
}

// ============================================================
// Function: FUN_1801aa050
// Address: 0x1801aa050
// Size: 16 bytes
// ============================================================
int64_t fcn.1801a9f60(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h,
                     int64_t arg_78h)
{
    uint64_t uVar1;
    int16_t *piVar2;
    int32_t iVar3;
    int64_t iVar4;
    int16_t *piVar5;
    int64_t in_RCX;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 unaff_RDI;
    int16_t *in_R8;
    int64_t in_R9;
    undefined8 unaff_R12;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801a9f73;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar9 = 0;
    if (in_R9 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
    uVar1 = *(uint64_t *)((int64_t)&arg_50h + iVar4);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_R12;
    piVar2 = *(int16_t **)((int64_t)&arg_48h + iVar4);
code_r0x0001801a9fb0:
    uVar6 = 0;
    uVar7 = *(uint64_t *)(*(int64_t *)(in_RCX + 8) + 0x640);
    iVar8 = *(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x650);
    if (uVar7 != 0) {
        do {
            if (*(int16_t *)(iVar8 + 0x10) == *in_R8) {
                if ((*(int32_t *)(iVar8 + 0x2c) != 0) && (iVar8 != 0)) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a9fff;
                    iVar3 = func_0x0001801aa060(in_RCX, 0x5000c, iVar8);
                    if ((iVar3 != 0) && (uVar7 = 0, uVar1 != 0)) {
                        piVar5 = piVar2;
                        goto code_r0x0001801aa011;
                    }
                }
                break;
            }
            iVar8 = iVar8 + 0x48;
            uVar6 = uVar6 + 1;
        } while (uVar6 < uVar7);
    }
    goto code_r0x0001801aa033;
    while( true ) {
        uVar7 = uVar7 + 1;
        piVar5 = piVar5 + 1;
        if (uVar1 <= uVar7) break;
code_r0x0001801aa011:
        if (*in_R8 == *piVar5) {
            iVar9 = iVar9 + 1;
            if (in_RDX != (int64_t *)0x0) {
                *in_RDX = iVar8;
                in_RDX = in_RDX + 1;
            }
            break;
        }
    }
code_r0x0001801aa033:
    in_R8 = in_R8 + 1;
    in_R9 = in_R9 + -1;
    if (in_R9 == 0) {
        return iVar9;
    }
    goto code_r0x0001801a9fb0;
}

// ============================================================
// Function: FUN_1801aa060
// Address: 0x1801aa060
// Size: 679 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable arg_49h
// WARNING: [rz-ghidra] Removing arg arg_678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_670h because it doesn't fit into ProtoModel

undefined8 fcn.1801aa060(int64_t placeholder_0, int64_t arg2, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined2 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t *piVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    undefined8 uVar12;
    uint32_t uVar13;
    int64_t iVar14;
    int64_t in_R8;
    bool bVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_40;
    int64_t var_18h;
    
    uStack_40 = 0x1801aa07e;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    if ((in_R8 != 0) && (*(int32_t *)(in_R8 + 0x2c) != 0)) {
        uVar13 = *(uint32_t *)(*(int64_t *)(*(int32_t **)(placeholder_0 + 0x18) + 0x36) + 0x50) & 8;
        if (((uVar13 != 0) ||
            (((iVar6 = **(int32_t **)(placeholder_0 + 0x18), iVar6 < 0x304 || (iVar6 == 0x10000)) ||
             (*(int32_t *)(in_R8 + 0x1c) != 0x74)))) &&
           ((((*(int32_t *)(placeholder_0 + 0x78) != 0 || (uVar13 != 0)) ||
             (*(int32_t *)(placeholder_0 + 0x418) < 0x304)) ||
            (((*(int32_t *)(in_R8 + 0x1c) != 0x74 && (iVar6 = *(int32_t *)(in_R8 + 0x18), iVar6 != 1)) &&
             ((iVar6 != 0 && (iVar6 != 10)))))))) {
            iVar6 = *(int32_t *)(in_R8 + 0x20);
            uVar12 = *(undefined8 *)(placeholder_0 + 8);
            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801aa103;
            iVar6 = func_0x00018019e480(uVar12, (int64_t)iVar6);
            if (iVar6 == 0) {
                iVar6 = *(int32_t *)(in_R8 + 0x1c);
                if (((iVar6 != 0x3d3) && (iVar6 != 0x3d4)) && (iVar6 != 0x32b)) {
code_r0x0001801aa2bd:
                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801aa2c9;
                    fcn.1801a8420(*(int64_t *)((int64_t)&var_18h + iVar9), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar9), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar9));
                    uVar1 = *(undefined2 *)(in_R8 + 0x10);
                    *(char *)((int64_t)&arg_48h + iVar9) = (char)((uint16_t)uVar1 >> 8);
                    *(int64_t *)((int64_t)&var_18h + iVar9) = (int64_t)&arg_48h + iVar9;
                    *(char *)((int64_t)&arg_48h + iVar9 + 1) = (char)uVar1;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801aa302;
                    uVar12 = fcn.1801a2690(*(int64_t *)((int64_t)&var_18h + iVar9), 
                                           *(int64_t *)(&stack0xfffffffffffffff0 + iVar9), 
                                           *(int64_t *)(&stack0x00000030 + iVar9));
                    return uVar12;
                }
                piVar5 = *(int32_t **)(placeholder_0 + 0x18);
                if (*(int32_t *)(placeholder_0 + 0x78) == 0) {
                    if ((*piVar5 != 0x10000) || (*(int32_t *)(placeholder_0 + 0x41c) < 0x304))
                    goto code_r0x0001801aa2bd;
                    if (*(int32_t *)(placeholder_0 + 0x418) < 0x304) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801aa19d;
                        iVar10 = func_0x000180193a50(placeholder_0);
                        if (iVar10 != 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801aa1ad;
                            iVar7 = func_0x000180222010(iVar10);
                            iVar6 = 0;
                            iVar8 = 0;
                            if (0 < iVar7) {
                                do {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801aa1d0;
                                    iVar11 = func_0x000180222340(iVar10, iVar6);
                                    iVar14 = 0x34;
                                    bVar15 = (*(uint32_t *)
                                               (*(int64_t *)(*(int64_t *)(placeholder_0 + 0x18) + 0xd8) + 0x50) & 8) ==
                                             0;
                                    if (bVar15) {
                                        iVar14 = 0x2c;
                                    }
                                    uVar2 = *(undefined4 *)(iVar14 + iVar11);
                                    iVar14 = 0x38;
                                    if (bVar15) {
                                        iVar14 = 0x30;
                                    }
                                    uVar3 = *(undefined4 *)(iVar14 + iVar11);
                                    if ((((*(uint32_t *)(placeholder_0 + 0x410) & *(uint32_t *)(iVar11 + 0x1c)) == 0) &&
                                        ((*(uint32_t *)(iVar11 + 0x20) & *(uint32_t *)(placeholder_0 + 0x414)) == 0)) &&
                                       (*(int32_t *)(placeholder_0 + 0x41c) != 0)) {
                                        if ((*(uint32_t *)(placeholder_0 + 0x160) & 0x4000) != 0) {
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801aa23a;
                                            iVar8 = func_0x00018019e0f0(iVar11);
                                            if (((iVar8 != 0x3001301) && (iVar8 != 0x3001302)) && (iVar8 != 0x3001303))
                                            goto code_r0x0001801aa29d;
                                        }
                                        uVar4 = *(undefined4 *)(placeholder_0 + 0x41c);
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801aa25d;
                                        iVar8 = func_0x0001801afd90(placeholder_0, uVar2, uVar4);
                                        if (iVar8 < 1) {
                                            uVar2 = *(undefined4 *)(placeholder_0 + 0x418);
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801aa273;
                                            iVar8 = func_0x0001801afd90(placeholder_0, uVar3, uVar2);
                                            if (-1 < iVar8) {
                                                *(int64_t *)((int64_t)&var_18h + iVar9) = iVar11;
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801aa290;
                                                iVar8 = fcn.1801a2690(*(int64_t *)((int64_t)&var_18h + iVar9), 
                                                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar9), 
                                                                      *(int64_t *)(&stack0x00000030 + iVar9));
                                                if ((iVar8 != 0) && ((*(uint32_t *)(iVar11 + 0x1c) & 0x210) != 0))
                                                goto code_r0x0001801aa2bd;
                                            }
                                        }
                                    }
code_r0x0001801aa29d:
                                    iVar8 = iVar6 + 1;
                                    iVar6 = iVar8;
                                } while (iVar8 < iVar7);
                            }
                            if (iVar8 != iVar7) goto code_r0x0001801aa2bd;
                        }
                    }
                } else if ((((*(uint8_t *)(*(int64_t *)(piVar5 + 0x36) + 0x50) & 8) != 0) || (*piVar5 < 0x304)) ||
                          (*piVar5 == 0x10000)) goto code_r0x0001801aa2bd;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801aa310
// Address: 0x1801aa310
// Size: 146 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.1801aa310(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h, int64_t arg_78h,
                      int64_t arg_88h, int64_t arg_90h, int64_t arg_a0h, int64_t arg_b0h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    uint64_t uVar10;
    int64_t in_RCX;
    char *in_RDX;
    uint64_t in_R8;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801aa325;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801aa33d;
    iVar6 = func_0x00018022fc40(extraout_XMM0_Da, 0x1804ad19c);
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801aa381;
        iVar6 = func_0x00018022fc40(in_RCX, 0x1804af0ec);
        if (iVar6 != 0) {
            if (in_R8 < 3) {
                return 0;
            }
            if (*in_RDX != '\x04') {
                return 0;
            }
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801aa349;
        iVar6 = func_0x00018022f0e0();
        if ((iVar6 < 1) || (in_R8 != (uint64_t)(int64_t)iVar6 >> 3)) {
            return 0;
        }
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar7) = *(undefined8 *)((int64_t)&arg_28h + iVar7);
    *(undefined8 *)((int64_t)auStackX_18 + iVar7 + -8) = 0x18023039c;
    iVar8 = fcn.18045a350(in_RCX, in_RDX);
    iVar8 = -iVar8;
    if (in_RCX != 0) {
        if (*(int64_t *)(in_RCX + 0x60) != 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7 + -8) = 0x1802303cd;
            puVar9 = (undefined4 *)func_0x000180229c70((int64_t)&arg_38h + iVar8 + iVar7, 0x1804e1de8, in_RDX, in_R8);
            uVar3 = puVar9[1];
            uVar4 = puVar9[2];
            uVar5 = puVar9[3];
            *(undefined4 *)((int64_t)&arg_68h + iVar8 + iVar7) = *puVar9;
            *(undefined4 *)((int64_t)&arg_68h + iVar8 + iVar7 + 4) = uVar3;
            *(undefined4 *)(&stack0x00000070 + iVar8 + iVar7) = uVar4;
            *(undefined4 *)(&stack0x00000074 + iVar8 + iVar7) = uVar5;
            uVar3 = puVar9[5];
            uVar4 = puVar9[6];
            uVar5 = puVar9[7];
            *(undefined4 *)((int64_t)&arg_78h + iVar8 + iVar7) = puVar9[4];
            *(undefined4 *)((int64_t)&arg_78h + iVar8 + iVar7 + 4) = uVar3;
            *(undefined4 *)(&stack0x00000080 + iVar8 + iVar7) = uVar4;
            *(undefined4 *)(&stack0x00000084 + iVar8 + iVar7) = uVar5;
            *(undefined8 *)((int64_t)&arg_88h + iVar8 + iVar7) = *(undefined8 *)(puVar9 + 8);
            *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7 + -8) = 0x1802303f3;
            puVar9 = (undefined4 *)func_0x000180229ba0((int64_t)&arg_38h + iVar8 + iVar7);
            iVar1 = *(int64_t *)(in_RCX + 0x60);
            uVar3 = puVar9[1];
            uVar4 = puVar9[2];
            uVar5 = puVar9[3];
            *(undefined4 *)((int64_t)&arg_90h + iVar8 + iVar7) = *puVar9;
            *(undefined4 *)((int64_t)&arg_90h + iVar8 + iVar7 + 4) = uVar3;
            *(undefined4 *)(&stack0x00000098 + iVar8 + iVar7) = uVar4;
            *(undefined4 *)(&stack0x0000009c + iVar8 + iVar7) = uVar5;
            uVar3 = puVar9[5];
            uVar4 = puVar9[6];
            uVar5 = puVar9[7];
            *(undefined4 *)((int64_t)&arg_a0h + iVar8 + iVar7) = puVar9[4];
            *(undefined4 *)((int64_t)&arg_a0h + iVar8 + iVar7 + 4) = uVar3;
            *(undefined4 *)(&stack0x000000a8 + iVar8 + iVar7) = uVar4;
            *(undefined4 *)(&stack0x000000ac + iVar8 + iVar7) = uVar5;
            *(undefined8 *)((int64_t)&arg_b0h + iVar8 + iVar7) = *(undefined8 *)(puVar9 + 8);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7 + -8) = 0x18023043e;
                fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000040 + iVar8 + iVar7));
                *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7 + -8) = 0x180230456;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000050 + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_68h + iVar8 + iVar7));
                *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7 + -8) = 0x180230468;
                fcn.1802296d0(*(int64_t *)(&stack0x00000058 + iVar8 + iVar7));
                return 0;
            }
            *(int64_t *)(in_RCX + 0x70) = *(int64_t *)(in_RCX + 0x70) + 1;
            uVar2 = *(undefined8 *)(in_RCX + 0x68);
            *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7 + -8) = 0x180230430;
            uVar10 = func_0x000180257ff0(iVar1, uVar2, (int64_t)&arg_68h + iVar8 + iVar7);
            return uVar10;
        }
        if (in_R8 < 0x80000000) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7 + -8) = 0x18023048b;
            iVar6 = func_0x0001802308f0(extraout_XMM0_Da_00, 9);
            return (uint64_t)(0 < iVar6);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801aa3b0
// Address: 0x1801aa3b0
// Size: 259 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801aa3b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int16_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t *piVar5;
    undefined8 in_RDX;
    uint64_t uVar6;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801aa3ca;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801aa3db;
    iVar4 = func_0x000180238400(in_RDX);
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801aa3f6;
        iVar2 = func_0x00018022fc40(iVar4, 0x1804af0ec);
        if (iVar2 == 0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801aa409;
        iVar2 = fcn.1801aadc0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801aa419;
            iVar1 = fcn.1801ab340(iVar4);
            uVar6 = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801aa433;
            iVar2 = fcn.1801aac50(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            if (iVar2 != 0) {
                if (in_R8D == 0) {
                    return 1;
                }
                if ((*(uint32_t *)(*(int64_t *)(in_RCX + 0x878) + 0x1c) & 0x30000) == 0) {
                    return 1;
                }
                if (iVar1 == 0x17) {
                    iVar2 = 0x31a;
                } else {
                    if (iVar1 != 0x18) {
                        return 0;
                    }
                    iVar2 = 0x31b;
                }
                if (*(uint64_t *)(in_RCX + 0x1588) != 0) {
                    piVar5 = *(int64_t **)(in_RCX + 0x1580);
                    do {
                        if (iVar2 == *(int32_t *)(*piVar5 + 0x24)) {
                            return 1;
                        }
                        uVar6 = uVar6 + 1;
                        piVar5 = piVar5 + 1;
                    } while (uVar6 < *(uint64_t *)(in_RCX + 0x1588));
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801aa4c0
// Address: 0x1801aa4c0
// Size: 1808 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_408h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_358h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_350h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_348h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b52h because it doesn't fit into ProtoModel

uint32_t fcn.1801aa4c0(int64_t placeholder_0, int64_t arg2, int64_t arg3, int64_t arg_38h, int64_t arg_40h,
                      int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_78h)
{
    int64_t **ppiVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t *piVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    undefined8 uVar12;
    undefined8 uVar13;
    int64_t iVar14;
    int64_t *piVar15;
    char *pcVar16;
    uint32_t *puVar17;
    int64_t *piVar18;
    int64_t *piVar19;
    int64_t *piVar20;
    char cVar21;
    int64_t in_R9;
    int64_t *piVar22;
    int64_t *piVar23;
    uint32_t uVar24;
    uint32_t uVar25;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_40;
    int64_t *piVar26;
    
    uStack_40 = 0x1801aa4e4;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    ppiVar1 = *(int64_t ***)(placeholder_0 + 0x878);
    piVar26 = (int64_t *)0x0;
    uVar25 = 0;
    iVar8 = *(int32_t *)((int64_t)&arg_58h + iVar10);
    uVar9 = 0;
    *(undefined4 *)((int64_t)&arg_38h + iVar10) = 0;
    piVar19 = (int64_t *)0x0;
    uVar7 = *(uint32_t *)((int64_t)ppiVar1 + 0x1c);
    uVar24 = uVar7 & 0x30000;
    if (iVar8 == -1) {
        if (arg2 == 0) {
            return 0;
        }
        if (arg3 == 0) {
            return 0;
        }
        uVar13 = *(undefined8 *)(placeholder_0 + 8);
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aa63a;
        iVar11 = func_0x0001801a2080(arg3, &stack0xfffffffffffffff0 + iVar10, uVar13);
        if (iVar11 == 0) {
            return 0;
        }
        iVar8 = *(int32_t *)(&stack0xfffffffffffffff0 + iVar10);
        iVar2 = *(int64_t *)(placeholder_0 + 0x408);
        uVar7 = *(uint32_t *)((int64_t)ppiVar1 + 0x1c);
        iVar11 = *(int64_t *)((int64_t)&arg_40h + iVar10);
        *(undefined4 *)((int64_t)&arg_58h + iVar10) = 1;
        *(int64_t *)(&stack0xffffffffffffffe8 + iVar10) = iVar2 + (int64_t)iVar8 * 4;
        uVar25 = 0x6f0;
        if ((uVar7 & 0x30001) == 0) {
            uVar25 = 0x50;
        }
        *(uint32_t *)((int64_t)&arg_38h + iVar10) = uVar25;
code_r0x0001801aa683:
        if (uVar24 == 0) {
            uVar7 = *(uint32_t *)((int64_t)&arg_38h + iVar10);
            piVar20 = piVar19;
        } else {
            uVar7 = uVar25 | 0x800;
            if (uVar25 == 0) {
                uVar7 = 0;
            }
            *(uint32_t *)((int64_t)&arg_38h + iVar10) = uVar7;
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aa6aa;
            iVar6 = func_0x000180237df0(0, iVar11, in_R9, uVar24);
            if (iVar6 == 0) {
                piVar20 = (int64_t *)0x800;
            } else {
                *(uint32_t *)((int64_t)&arg_38h + iVar10) = uVar7;
                piVar20 = piVar26;
                if (uVar7 == 0) {
                    uVar9 = 0;
                    piVar18 = piVar19;
                    goto code_r0x0001801aa6c5;
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aa70e;
        uVar9 = func_0x000180194ed0(placeholder_0);
        uVar24 = (uint32_t)piVar20;
        if ((uVar9 & 0xffffff00) == 0x300) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aa726;
            iVar6 = func_0x000180194ed0(placeholder_0);
            if ((iVar6 < 0x303) || (*(int32_t *)((int64_t)&arg_58h + iVar10) == 0)) goto code_r0x0001801aa95a;
            piVar19 = piVar26;
            piVar18 = piVar20;
            if ((*(int64_t *)(placeholder_0 + 1000) == 0) && (*(int64_t *)(placeholder_0 + 0x3e0) == 0)) {
    // switch table (7 cases) at 0x1801aabb4
                switch(iVar8) {
                case 0:
                    iVar8 = 6;
                    piVar19 = (int64_t *)0x41;
                    break;
                default:
                    piVar19 = (int64_t *)0xffffffff;
                    goto code_r0x0001801aa882;
                case 2:
                    iVar8 = 0x74;
                    piVar19 = (int64_t *)0x71;
                    break;
                case 3:
                    iVar8 = 0x198;
                    piVar19 = (int64_t *)0x1a0;
                    break;
                case 4:
                    iVar8 = 0x32b;
                    piVar19 = (int64_t *)0x327;
                    break;
                case 5:
                    iVar8 = 0x3d3;
                    piVar19 = (int64_t *)0x3d9;
                    break;
                case 6:
                    iVar8 = 0x3d4;
                    piVar19 = (int64_t *)0x3da;
                }
                piVar23 = ppiVar1[8];
                if (piVar23 == (int64_t *)0x0) goto code_r0x0001801aa882;
                piVar4 = ppiVar1[9];
                piVar22 = piVar26;
                if (piVar4 != (int64_t *)0x0) {
                    piVar5 = *(int64_t **)(*(int64_t *)(placeholder_0 + 8) + 0x640);
                    do {
                        if (piVar5 != (int64_t *)0x0) {
                            iVar11 = *(int64_t *)(*(int64_t *)(placeholder_0 + 8) + 0x650);
                            piVar15 = piVar26;
                            do {
                                if (*(int16_t *)(iVar11 + 0x10) == *(int16_t *)piVar23) {
                                    if (((*(int32_t *)(iVar11 + 0x2c) != 0) && (*(int32_t *)(iVar11 + 0x14) == 0x40)) &&
                                       (*(int32_t *)(iVar11 + 0x1c) == iVar8)) goto code_r0x0001801aa882;
                                    break;
                                }
                                iVar11 = iVar11 + 0x48;
                                piVar15 = (int64_t *)((int64_t)piVar15 + 1);
                            } while (piVar15 < piVar5);
                        }
                        piVar22 = (int64_t *)((int64_t)piVar22 + 1);
                        piVar23 = (int64_t *)((int64_t)piVar23 + 2);
                    } while (piVar22 < piVar4);
                }
                if (piVar22 != piVar4) goto code_r0x0001801aa882;
                uVar9 = *(uint32_t *)((int64_t)&arg_38h + iVar10);
                if (uVar9 == 0) goto code_r0x0001801aa6c5;
                uVar13 = *(undefined8 *)((int64_t)&arg_48h + iVar10);
            } else {
code_r0x0001801aa882:
                if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(placeholder_0 + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                    (iVar8 = **(int32_t **)(placeholder_0 + 0x18), 0x303 < iVar8)) && (iVar8 != 0x10000)) {
                    uVar13 = *(undefined8 *)((int64_t)&arg_48h + iVar10);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aa8bb;
                    iVar11 = func_0x0001801a7690(placeholder_0, *(undefined8 *)((int64_t)&arg_40h + iVar10), uVar13);
                    uVar7 = uVar24 | 0x10;
                    if (iVar11 == 0) {
                        uVar7 = uVar24;
                    }
                } else {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aa8da;
                    iVar8 = func_0x0001801aae90(placeholder_0, *(undefined8 *)((int64_t)&arg_40h + iVar10), piVar19);
                    if (iVar8 == 0) {
                        if (uVar7 == 0) {
                            uVar9 = *(uint32_t *)((int64_t)&arg_38h + iVar10);
                            goto code_r0x0001801aa6c5;
                        }
                    } else {
                        uVar24 = uVar24 | 0x10;
                    }
                    uVar13 = *(undefined8 *)((int64_t)&arg_48h + iVar10);
                    uVar7 = uVar24;
                }
                piVar20 = (int64_t *)(uint64_t)(uVar7 | 0x20);
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aa906;
                iVar8 = func_0x000180222010(in_R9);
                piVar18 = piVar26;
                if (0 < iVar8) {
                    do {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aa91a;
                        uVar12 = func_0x000180222340(in_R9, piVar18);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aa928;
                        iVar8 = func_0x0001801aae90(placeholder_0, uVar12, piVar19);
                        if (iVar8 == 0) {
                            uVar9 = *(uint32_t *)((int64_t)&arg_38h + iVar10);
                            piVar18 = piVar20;
                            if (uVar9 == 0) goto code_r0x0001801aa6c5;
                            piVar20 = (int64_t *)(uint64_t)uVar7;
                            goto code_r0x0001801aa851;
                        }
                        uVar9 = (int32_t)piVar18 + 1;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aa936;
                        iVar8 = func_0x000180222010(in_R9);
                        piVar18 = (int64_t *)(uint64_t)uVar9;
                    } while ((int32_t)uVar9 < iVar8);
                }
                uVar9 = *(uint32_t *)((int64_t)&arg_38h + iVar10);
            }
        } else {
code_r0x0001801aa95a:
            uVar9 = *(uint32_t *)((int64_t)&arg_38h + iVar10);
            uVar13 = *(undefined8 *)((int64_t)&arg_48h + iVar10);
            if (uVar9 != 0) {
                piVar20 = (int64_t *)(uint64_t)(uVar24 | 0x30);
            }
        }
code_r0x0001801aa851:
        uVar12 = *(undefined8 *)((int64_t)&arg_40h + iVar10);
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aa867;
        iVar8 = fcn.1801aa3b0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar10));
        if (iVar8 == 0) {
            piVar18 = piVar20;
            if (uVar9 == 0) goto code_r0x0001801aa6c5;
        } else {
            piVar20 = (int64_t *)(uint64_t)((uint32_t)piVar20 | 0x40);
        }
        iVar8 = *(int32_t *)((int64_t)&arg_58h + iVar10);
        if (*(int32_t *)(placeholder_0 + 0x78) == 0) {
            piVar19 = (int64_t *)(uint64_t)((uint32_t)piVar20 | 0x80);
        } else {
            piVar19 = piVar20;
            if (iVar8 != 0) {
                piVar19 = (int64_t *)(uint64_t)((uint32_t)piVar20 | 0x80);
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aa9ae;
                iVar8 = func_0x000180222010(in_R9);
                piVar18 = piVar26;
                if (0 < iVar8) {
                    do {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aa9bc;
                        uVar12 = func_0x000180222340(in_R9, piVar18);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aa9c4;
                        iVar11 = func_0x000180238400(uVar12);
                        if (iVar11 == 0) {
code_r0x0001801aaa20:
                            piVar18 = piVar19;
                            piVar19 = piVar20;
                            if (uVar9 == 0) goto code_r0x0001801aa6c5;
                            break;
                        }
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aa9db;
                        iVar8 = func_0x00018022fc40(iVar11, 0x1804af0ec);
                        if (iVar8 != 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aa9ea;
                            iVar8 = fcn.1801aadc0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10));
                            if (iVar8 != 0) {
                                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aa9f6;
                                fcn.1801ab340(iVar11);
                                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aaa0c;
                                iVar8 = fcn.1801aac50(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar10));
                                if (iVar8 != 0) goto code_r0x0001801aaa10;
                            }
                            goto code_r0x0001801aaa20;
                        }
code_r0x0001801aaa10:
                        uVar7 = (int32_t)piVar18 + 1;
                        piVar18 = (int64_t *)(uint64_t)uVar7;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aaa1a;
                        iVar8 = func_0x000180222010(in_R9);
                    } while ((int32_t)uVar7 < iVar8);
                }
                iVar8 = *(int32_t *)((int64_t)&arg_58h + iVar10);
                uVar12 = *(undefined8 *)((int64_t)&arg_40h + iVar10);
            }
        }
        uVar7 = (uint32_t)piVar19;
        if ((*(int32_t *)(placeholder_0 + 0x78) == 0) && (iVar8 != 0)) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aaa5a;
            iVar8 = func_0x00018022fc40(uVar13, 0x1804a9778);
            if (iVar8 == 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aaa75;
                iVar8 = func_0x00018022fc40(uVar13, 0x1804ad420);
                if (iVar8 != 0) {
                    cVar21 = '\x02';
                    goto code_r0x0001801aaa9a;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aaa90;
                iVar8 = func_0x00018022fc40(uVar13, 0x1804af0ec);
                if (iVar8 != 0) {
                    cVar21 = '@';
                    goto code_r0x0001801aaa9a;
                }
                piVar19 = (int64_t *)(uint64_t)(uVar7 | 0x400);
            } else {
                cVar21 = '\x01';
code_r0x0001801aaa9a:
                pcVar16 = *(char **)(placeholder_0 + 0x348);
                piVar18 = piVar26;
                if (*(int64_t **)(placeholder_0 + 0x350) != (int64_t *)0x0) {
                    do {
                        if (*pcVar16 == cVar21) {
                            piVar19 = (int64_t *)(uint64_t)(uVar7 | 0x400);
                            break;
                        }
                        pcVar16 = pcVar16 + 1;
                        piVar18 = (int64_t *)((int64_t)piVar18 + 1);
                    } while (piVar18 < *(int64_t **)(placeholder_0 + 0x350));
                }
                if ((((uint32_t)piVar19 >> 10 & 1) == 0) && (piVar18 = piVar19, uVar9 == 0)) goto code_r0x0001801aa6c5;
            }
            iVar11 = *(int64_t *)(placeholder_0 + 0x358);
            if (iVar11 == 0) {
code_r0x0001801aab3d:
                piVar19 = (int64_t *)(uint64_t)((uint32_t)piVar19 | 0x200);
            } else {
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aaaf2;
                iVar8 = func_0x000180222010(iVar11);
                if (iVar8 == 0) goto code_r0x0001801aab3d;
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aab01;
                iVar8 = func_0x0001801a8520(iVar11, uVar12);
                if (iVar8 != 0) goto code_r0x0001801aab3d;
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aab0d;
                iVar8 = func_0x000180222010(in_R9);
                if (0 < iVar8) {
                    do {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aab1c;
                        uVar13 = func_0x000180222340(in_R9, piVar26);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aab27;
                        iVar8 = func_0x0001801a8520(iVar11, uVar13);
                        if (iVar8 != 0) goto code_r0x0001801aab3d;
                        uVar7 = (int32_t)piVar26 + 1;
                        piVar26 = (int64_t *)(uint64_t)uVar7;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aab36;
                        iVar8 = func_0x000180222010(in_R9);
                    } while ((int32_t)uVar7 < iVar8);
                }
            }
            if (uVar9 == 0) {
                piVar18 = piVar19;
                if (((uint32_t)piVar19 >> 9 & 1) != 0) {
                    piVar18 = (int64_t *)(uint64_t)((uint32_t)piVar19 | 1);
                }
            } else {
code_r0x0001801aab63:
                uVar7 = (uint32_t)piVar19;
                piVar18 = piVar19;
                if ((uVar9 & uVar7) == uVar9) goto code_r0x0001801aab71;
            }
        } else {
            uVar7 = uVar7 | 0x600;
            piVar19 = (int64_t *)(uint64_t)uVar7;
            if (uVar9 != 0) goto code_r0x0001801aab63;
code_r0x0001801aab71:
            piVar18 = (int64_t *)(uint64_t)(uVar7 | 1);
        }
    } else {
        piVar18 = ppiVar1[4];
        if (iVar8 == -2) {
            piVar20 = *ppiVar1;
            iVar8 = (int32_t)(((int64_t)piVar20 - (int64_t)piVar18) / 0x28);
        } else {
            piVar20 = piVar18 + (int64_t)iVar8 * 5;
        }
        iVar2 = *(int64_t *)(placeholder_0 + 0x408);
        iVar11 = *piVar20;
        iVar3 = piVar20[1];
        in_R9 = piVar20[2];
        iVar14 = (int64_t)iVar8;
        *(int64_t *)((int64_t)&arg_40h + iVar10) = iVar11;
        *(int64_t *)((int64_t)&arg_48h + iVar10) = iVar3;
        *(uint32_t *)((int64_t)&arg_58h + iVar10) = uVar7 & 0x30001;
        *(int64_t *)(&stack0xffffffffffffffe8 + iVar10) = iVar2 + iVar14 * 4;
        if (*(int32_t *)(placeholder_0 + 0x78) == 0) {
            cVar21 = *(char *)(placeholder_0 + 0xb50);
        } else {
            cVar21 = *(char *)(placeholder_0 + 0xb52);
        }
        if (((cVar21 == '\x02') && (piVar18[iVar14 * 5 + 1] != 0)) && (piVar18[iVar14 * 5] == 0)) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aa5e6;
            iVar8 = func_0x00018022fc40(iVar3, 0x1804af0ec);
            if (iVar8 != 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aa5fa;
                iVar8 = fcn.1801aadc0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10));
                if (iVar8 == 0) {
                    return 0;
                }
            }
            **(undefined4 **)(&stack0xffffffffffffffe8 + iVar10) = 0x1000;
            return 0x1000;
        }
        piVar18 = piVar26;
        if ((iVar11 != 0) && (piVar18 = piVar19, iVar3 != 0)) goto code_r0x0001801aa683;
    }
code_r0x0001801aa6c5:
    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aa6cd;
    uVar7 = func_0x000180194ed0(placeholder_0);
    if ((uVar7 & 0xffffff00) == 0x300) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801aa6e5;
        iVar8 = func_0x000180194ed0(placeholder_0);
        if (0x302 < iVar8) {
            puVar17 = *(uint32_t **)(&stack0xffffffffffffffe8 + iVar10);
            uVar7 = *puVar17 & 0x102;
            goto code_r0x0001801aab83;
        }
    }
    puVar17 = *(uint32_t **)(&stack0xffffffffffffffe8 + iVar10);
    uVar7 = 0x102;
code_r0x0001801aab83:
    uVar7 = uVar7 | (uint32_t)piVar18;
    if (uVar9 != 0) {
        return uVar7;
    }
    if (((uint64_t)piVar18 & 1) == 0) {
        *puVar17 = *puVar17 & 0x102;
        return 0;
    }
    *puVar17 = uVar7;
    return uVar7;
}

// ============================================================
// Function: FUN_1801aabd0
// Address: 0x1801aabd0
// Size: 114 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_668h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_258h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_250h because it doesn't fit into ProtoModel

bool fcn.1801aabd0(int64_t param_1, int32_t param_2)
{
    int32_t iVar1;
    int16_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint32_t uVar8;
    int64_t iVar9;
    uint64_t uVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    bool bVar11;
    undefined8 auStackX_18 [2];
    undefined8 uStack_8;
    
    uStack_8 = 0x1801aabda;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((*(uint32_t *)(*(int64_t *)(param_1 + 0x878) + 0x1c) & 0x30000) == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x1801aabf4;
        iVar2 = fcn.1801ac8f0(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4));
        return iVar2 != 0;
    }
    if (param_2 == 0x300c02b) {
        uVar10 = 0x17;
    } else {
        if (param_2 != 0x300c02c) {
            return false;
        }
        uVar10 = 0x18;
    }
    iVar3 = 1;
    *(undefined8 *)(&stack0x00000030 + iVar4) = unaff_RBX;
    *(undefined8 *)(&stack0x00000038 + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x1801aac65;
    iVar5 = fcn.18045a350();
    iVar2 = (int16_t)uVar10;
    if (iVar2 == 0) {
        return false;
    }
    uVar8 = *(uint32_t *)(*(int64_t *)(param_1 + 0x878) + 0x1c) & 0x30000;
    if ((uVar8 != 0) && (*(int64_t *)(param_1 + 0x300) != 0)) {
        iVar1 = *(int32_t *)(*(int64_t *)(param_1 + 0x300) + 0x18);
        if (iVar1 == 0x300c02b) {
            bVar11 = iVar2 == 0x17;
        } else {
            if (iVar1 != 0x300c02c) {
                return false;
            }
            bVar11 = iVar2 == 0x18;
        }
        if (!bVar11) {
            return false;
        }
    }
    bVar11 = true;
    if (iVar3 == 0) goto code_r0x0001801aad60;
    if (uVar8 == 0x10000) {
        uVar7 = 1;
code_r0x0001801aad30:
        iVar9 = 0x1804adff0;
code_r0x0001801aad37:
        uVar6 = 0;
    } else {
        if (uVar8 == 0x20000) {
            uVar7 = 1;
            iVar9 = 0x1804adff2;
            goto code_r0x0001801aad37;
        }
        if (uVar8 == 0x30000) {
            uVar7 = 2;
            goto code_r0x0001801aad30;
        }
        iVar9 = *(int64_t *)(param_1 + 0xa90);
        if (iVar9 == 0) {
            iVar9 = *(int64_t *)(*(int64_t *)(param_1 + 8) + 0x298);
            uVar7 = *(uint64_t *)(*(int64_t *)(param_1 + 8) + 0x290);
        } else {
            uVar7 = *(uint64_t *)(param_1 + 0xa88);
        }
        uVar6 = 0;
        if (uVar7 == 0) {
            return false;
        }
    }
    while (*(int16_t *)(iVar9 + uVar6 * 2) != iVar2) {
        uVar6 = uVar6 + 1;
        if (uVar7 <= uVar6) {
            return false;
        }
    }
code_r0x0001801aad60:
    *(undefined8 *)((int64_t)auStackX_18 + (iVar4 - iVar5)) = 0x1801aad71;
    iVar3 = func_0x0001801ada30(param_1, uVar10 & 0xffff, 0x20006);
    if (iVar3 == 0) {
        return false;
    }
    if (*(int32_t *)(param_1 + 0x78) != 0) {
        uVar10 = *(uint64_t *)(param_1 + 0xa98);
        if (uVar10 != 0) {
            uVar7 = 0;
            if (uVar10 != 0) {
                do {
                    if (*(int16_t *)(*(int64_t *)(param_1 + 0xaa0) + uVar7 * 2) == iVar2) {
                        return true;
                    }
                    uVar7 = uVar7 + 1;
                } while (uVar7 < uVar10);
            }
            bVar11 = false;
        }
    }
    return bVar11;
}

// ============================================================
// Function: FUN_1801aac50
// Address: 0x1801aac50
// Size: 359 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801aac50(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    uint32_t uVar4;
    int64_t in_RCX;
    int64_t iVar5;
    int16_t iVar6;
    uint64_t in_RDX;
    uint64_t uVar7;
    undefined8 uVar8;
    int32_t in_R8D;
    bool bVar9;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801aac65;
    iVar2 = fcn.18045a350();
    iVar6 = (int16_t)in_RDX;
    if (iVar6 == 0) {
        return 0;
    }
    uVar4 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x878) + 0x1c) & 0x30000;
    if ((uVar4 != 0) && (*(int64_t *)(in_RCX + 0x300) != 0)) {
        iVar1 = *(int32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x18);
        if (iVar1 == 0x300c02b) {
            bVar9 = iVar6 == 0x17;
        } else {
            if (iVar1 != 0x300c02c) {
                return 0;
            }
            bVar9 = iVar6 == 0x18;
        }
        if (!bVar9) {
            return 0;
        }
    }
    uVar8 = 1;
    if (in_R8D == 0) goto code_r0x0001801aad60;
    if (uVar4 == 0x10000) {
        uVar7 = 1;
code_r0x0001801aad30:
        iVar5 = 0x1804adff0;
code_r0x0001801aad37:
        uVar3 = 0;
    } else {
        if (uVar4 == 0x20000) {
            uVar7 = 1;
            iVar5 = 0x1804adff2;
            goto code_r0x0001801aad37;
        }
        if (uVar4 == 0x30000) {
            uVar7 = 2;
            goto code_r0x0001801aad30;
        }
        iVar5 = *(int64_t *)(in_RCX + 0xa90);
        if (iVar5 == 0) {
            iVar5 = *(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x298);
            uVar7 = *(uint64_t *)(*(int64_t *)(in_RCX + 8) + 0x290);
        } else {
            uVar7 = *(uint64_t *)(in_RCX + 0xa88);
        }
        uVar3 = 0;
        if (uVar7 == 0) {
            return 0;
        }
    }
    while (*(int16_t *)(iVar5 + uVar3 * 2) != iVar6) {
        uVar3 = uVar3 + 1;
        if (uVar7 <= uVar3) {
            return 0;
        }
    }
code_r0x0001801aad60:
    *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1801aad71;
    iVar1 = func_0x0001801ada30(in_RCX, in_RDX & 0xffff, 0x20006);
    if (iVar1 == 0) {
        return 0;
    }
    if (*(int32_t *)(in_RCX + 0x78) != 0) {
        uVar7 = *(uint64_t *)(in_RCX + 0xa98);
        if (uVar7 != 0) {
            uVar3 = 0;
            if (uVar7 != 0) {
                do {
                    if (*(int16_t *)(*(int64_t *)(in_RCX + 0xaa0) + uVar3 * 2) == iVar6) {
                        return 1;
                    }
                    uVar3 = uVar3 + 1;
                } while (uVar3 < uVar7);
            }
            uVar8 = 0;
        }
    }
    return uVar8;
}

// ============================================================
// Function: FUN_1801aadc0
// Address: 0x1801aadc0
// Size: 202 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801aadc0(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    char cVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801aadd0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801aade8;
    iVar1 = func_0x00018022fc40(in_RDX, 0x1804af0ec);
    if (iVar1 == 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801aadf8;
    iVar1 = func_0x00018022f440();
    if (iVar1 != 0) {
        if (iVar1 == 4) {
            cVar4 = '\0';
        } else {
            if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                (iVar1 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar1)) && (iVar1 != 0x10000)) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801aae2e;
            iVar1 = func_0x00018022f610(in_RDX);
            if (iVar1 == 0x196) {
                cVar4 = '\x01';
            } else {
                if (iVar1 != 0x197) {
                    return 0;
                }
                cVar4 = '\x02';
            }
        }
        if (*(int64_t *)(in_RCX + 0xa80) == 0) {
            return 1;
        }
        uVar3 = 0;
        if (*(uint64_t *)(in_RCX + 0xa78) != 0) {
            do {
                if (*(char *)(*(int64_t *)(in_RCX + 0xa80) + uVar3) == cVar4) {
                    return 1;
                }
                uVar3 = uVar3 + 1;
            } while (uVar3 < *(uint64_t *)(in_RCX + 0xa78));
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801aae90
// Address: 0x1801aae90
// Size: 370 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_1560h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1558h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3d0h because it doesn't fit into ProtoModel

bool fcn.1801aae90(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint64_t uVar1;
    bool bVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    uint64_t uVar6;
    undefined8 in_RDX;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int32_t in_R8D;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_30;
    int64_t var_20h;
    
    uStack_30 = 0x1801aaeac;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar9 = 0;
    bVar2 = false;
    if (in_R8D != -1) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801aaed1;
        iVar3 = func_0x00018024c670(in_RDX, 0);
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801aaee1;
            iVar3 = func_0x00018021fee0(in_RDX);
            if (in_R8D != 0) {
                return iVar3 == in_R8D;
            }
            if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                 (iVar4 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar4)) && (iVar4 != 0x10000)) &&
               (*(int64_t *)(in_RCX + 1000) != 0)) {
                uVar11 = *(uint64_t *)(in_RCX + 0x3f8);
                bVar2 = true;
            } else {
                uVar11 = *(uint64_t *)(in_RCX + 0x1588);
            }
            uVar10 = uVar9;
            if (uVar11 != 0) {
                do {
                    if (bVar2) {
                        uVar1 = *(uint64_t *)(*(int64_t *)(in_RCX + 8) + 0x640);
                        uVar7 = *(uint64_t *)(*(int64_t *)(in_RCX + 8) + 0x650);
                        uVar8 = uVar9;
                        if (uVar1 != 0) {
                            uVar6 = uVar9;
                            do {
                                if (*(int16_t *)(uVar7 + 0x10) == *(int16_t *)(*(int64_t *)(in_RCX + 1000) + uVar10 * 2)
                                   ) {
                                    uVar8 = uVar7;
                                    if (*(int32_t *)(uVar7 + 0x2c) == 0) {
                                        uVar8 = uVar9;
                                    }
                                    break;
                                }
                                uVar7 = uVar7 + 0x48;
                                uVar6 = uVar6 + 1;
                            } while (uVar6 < uVar1);
                        }
                    } else {
                        uVar8 = *(uint64_t *)(*(int64_t *)(in_RCX + 0x1580) + uVar10 * 8);
                    }
                    if (uVar8 != 0) {
                        if (iVar3 == *(int32_t *)(uVar8 + 0x24)) {
                            return true;
                        }
                        if (*(int32_t *)(uVar8 + 0x1c) == 0x390) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801aafc2;
                            iVar4 = func_0x0001802567e0(iVar3, (int64_t)&arg_40h + iVar5, (int64_t)&arg_38h + iVar5);
                            if (((iVar4 != 0) && (*(int32_t *)((int64_t)&arg_38h + iVar5) == 6)) &&
                               (*(int32_t *)((int64_t)&arg_40h + iVar5) == *(int32_t *)(uVar8 + 0x14))) {
                                return true;
                            }
                        }
                    }
                    uVar10 = uVar10 + 1;
                } while (uVar10 < uVar11);
            }
            return false;
        }
    }
    return true;
}

// ============================================================
// Function: FUN_1801ab010
// Address: 0x1801ab010
// Size: 119 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801ab010(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t *piVar3;
    int32_t *in_RCX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ab020;
    iVar2 = fcn.18045a350();
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    piVar3 = in_RCX;
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801ab03f;
        piVar3 = (int32_t *)func_0x0001801bda50();
        if (piVar3 == (int32_t *)0x0) {
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801ab04f;
    iVar1 = func_0x0001801c37d0(in_RCX);
    if (iVar1 == 0) {
        return 0;
    }
    iVar1 = **(int32_t **)(in_RCX + 6);
    if (iVar1 == 0x10000) {
        iVar1 = 0x304;
    }
    piVar3[0x12] = iVar1;
    return 1;
}

// ============================================================
// Function: FUN_1801ab0a0
// Address: 0x1801ab0a0
// Size: 86 bytes
// ============================================================
void fcn.1801ab0a0(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    int32_t *piVar3;
    undefined8 uStack_10;
    
    if (arg1 == 0) {
        return;
    }
    uStack_10 = 0x1801ab0b0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    piVar3 = (int32_t *)arg1;
    if (*(int32_t *)arg1 != 0) {
        if (-1 < (char)*(int32_t *)arg1) {
            return;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ab0ca;
        piVar3 = (int32_t *)func_0x0001801bda50();
        if (piVar3 == (int32_t *)0x0) {
            return;
        }
    }
    uVar1 = *(undefined8 *)(piVar3 + 0x2b2);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ab0e8;
    fcn.180224990(uVar1, 0x1804aeee0, 0x7a);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ab0f0;
    func_0x0001801c4f10(arg1);
    return;
}

// ============================================================
// Function: FUN_1801ab100
// Address: 0x1801ab100
// Size: 117 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined4
fcn.1801ab100(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_98h,
             int64_t arg_a0h)
{
    int32_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int32_t **ppiVar8;
    int64_t *piVar9;
    int32_t in_ECX;
    int32_t in_EDX;
    int32_t *piVar10;
    int32_t *piVar11;
    int32_t *piVar12;
    undefined8 unaff_RSI;
    uint32_t uVar13;
    undefined8 unaff_RDI;
    int64_t in_R8;
    uint64_t in_R9;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801ab118;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    piVar11 = (int32_t *)0x0;
    *(undefined4 *)((int64_t)&arg_38h + iVar5) = 0;
    if (((in_R8 != 0) && (*(int64_t *)((int64_t)&arg_50h + iVar5) != 0)) && (in_R9 < 0x80000000)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab15a;
        uVar6 = func_0x000180221ee0(0x1801adaf0);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab169;
        iVar7 = func_0x000180222290(uVar6, 0x180196ec0);
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RDI;
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RSI;
            if (0 < (int32_t)in_R9) {
                piVar10 = (int32_t *)(in_R8 + 0x24);
                piVar12 = piVar11;
                do {
                    if ((((piVar10[-1] < 1) || (in_EDX < 1)) || (piVar10[-1] <= in_EDX)) &&
                       (((*piVar10 < 1 || (in_ECX < 1)) || (in_ECX <= *piVar10)))) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab1c8;
                        ppiVar8 = (int32_t **)
                                  fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                                *(int64_t *)(&stack0x00000000 + iVar5));
                        if (ppiVar8 == (int32_t **)0x0) goto code_r0x0001801ab25e;
                        *ppiVar8 = piVar10 + -9;
                        ppiVar8[1] = piVar12;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab1ec;
                        iVar3 = func_0x000180222110(iVar7, ppiVar8);
                        if (iVar3 < 1) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab2b2;
                            fcn.180224990(ppiVar8, 0x1804aeee0, 0x3d4);
                            goto code_r0x0001801ab25e;
                        }
                    }
                    uVar13 = (int32_t)piVar12 + 1;
                    piVar12 = (int32_t *)(uint64_t)uVar13;
                    piVar10 = piVar10 + 0xe;
                } while ((int32_t)uVar13 < (int32_t)in_R9);
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab207;
            func_0x0001802222d0(iVar7);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab211;
            iVar3 = func_0x000180222010(iVar7);
            if (0 < iVar3) {
                iVar1 = *(int32_t *)(&stack0x00000048 + iVar5);
                uVar6 = *(undefined8 *)((int64_t)&arg_50h + iVar5);
                piVar12 = piVar11;
                do {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab22a;
                    piVar9 = (int64_t *)func_0x000180222340(iVar7, piVar11);
                    if ((iVar1 != 0) || (*(int16_t *)(*piVar9 + 0x1c) != (int16_t)piVar12)) {
                        piVar12 = (int32_t *)(uint64_t)*(uint16_t *)((int64_t)(undefined8 *)*piVar9 + 0x1c);
                        uVar2 = *(undefined8 *)*piVar9;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab24c;
                        iVar4 = func_0x000180222110(uVar6, uVar2);
                        if (iVar4 < 1) goto code_r0x0001801ab25e;
                    }
                    uVar13 = (int32_t)piVar11 + 1;
                    piVar11 = (int32_t *)(uint64_t)uVar13;
                } while ((int32_t)uVar13 < iVar3);
            }
            *(undefined4 *)((int64_t)&arg_38h + iVar5) = 1;
code_r0x0001801ab25e:
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab26d;
            uVar6 = func_0x000180222290(iVar7, 0x180196ec0);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab27c;
            func_0x000180222050(uVar6, 0x1801a7960);
            return *(undefined4 *)((int64_t)&arg_38h + iVar5);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801ab175
// Address: 0x1801ab175
// Size: 296 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined4
fcn.1801ab100(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_98h,
             int64_t arg_a0h)
{
    int32_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int32_t **ppiVar8;
    int64_t *piVar9;
    int32_t in_ECX;
    int32_t in_EDX;
    int32_t *piVar10;
    int32_t *piVar11;
    int32_t *piVar12;
    undefined8 unaff_RSI;
    uint32_t uVar13;
    undefined8 unaff_RDI;
    int64_t in_R8;
    uint64_t in_R9;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801ab118;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    piVar11 = (int32_t *)0x0;
    *(undefined4 *)((int64_t)&arg_38h + iVar5) = 0;
    if (((in_R8 != 0) && (*(int64_t *)((int64_t)&arg_50h + iVar5) != 0)) && (in_R9 < 0x80000000)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab15a;
        uVar6 = func_0x000180221ee0(0x1801adaf0);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab169;
        iVar7 = func_0x000180222290(uVar6, 0x180196ec0);
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RDI;
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RSI;
            if (0 < (int32_t)in_R9) {
                piVar10 = (int32_t *)(in_R8 + 0x24);
                piVar12 = piVar11;
                do {
                    if ((((piVar10[-1] < 1) || (in_EDX < 1)) || (piVar10[-1] <= in_EDX)) &&
                       (((*piVar10 < 1 || (in_ECX < 1)) || (in_ECX <= *piVar10)))) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab1c8;
                        ppiVar8 = (int32_t **)
                                  fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                                *(int64_t *)(&stack0x00000000 + iVar5));
                        if (ppiVar8 == (int32_t **)0x0) goto code_r0x0001801ab25e;
                        *ppiVar8 = piVar10 + -9;
                        ppiVar8[1] = piVar12;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab1ec;
                        iVar3 = func_0x000180222110(iVar7, ppiVar8);
                        if (iVar3 < 1) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab2b2;
                            fcn.180224990(ppiVar8, 0x1804aeee0, 0x3d4);
                            goto code_r0x0001801ab25e;
                        }
                    }
                    uVar13 = (int32_t)piVar12 + 1;
                    piVar12 = (int32_t *)(uint64_t)uVar13;
                    piVar10 = piVar10 + 0xe;
                } while ((int32_t)uVar13 < (int32_t)in_R9);
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab207;
            func_0x0001802222d0(iVar7);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab211;
            iVar3 = func_0x000180222010(iVar7);
            if (0 < iVar3) {
                iVar1 = *(int32_t *)(&stack0x00000048 + iVar5);
                uVar6 = *(undefined8 *)((int64_t)&arg_50h + iVar5);
                piVar12 = piVar11;
                do {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab22a;
                    piVar9 = (int64_t *)func_0x000180222340(iVar7, piVar11);
                    if ((iVar1 != 0) || (*(int16_t *)(*piVar9 + 0x1c) != (int16_t)piVar12)) {
                        piVar12 = (int32_t *)(uint64_t)*(uint16_t *)((int64_t)(undefined8 *)*piVar9 + 0x1c);
                        uVar2 = *(undefined8 *)*piVar9;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab24c;
                        iVar4 = func_0x000180222110(uVar6, uVar2);
                        if (iVar4 < 1) goto code_r0x0001801ab25e;
                    }
                    uVar13 = (int32_t)piVar11 + 1;
                    piVar11 = (int32_t *)(uint64_t)uVar13;
                } while ((int32_t)uVar13 < iVar3);
            }
            *(undefined4 *)((int64_t)&arg_38h + iVar5) = 1;
code_r0x0001801ab25e:
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab26d;
            uVar6 = func_0x000180222290(iVar7, 0x180196ec0);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab27c;
            func_0x000180222050(uVar6, 0x1801a7960);
            return *(undefined4 *)((int64_t)&arg_38h + iVar5);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801ab29d
// Address: 0x1801ab29d
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined4
fcn.1801ab100(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_98h,
             int64_t arg_a0h)
{
    int32_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int32_t **ppiVar8;
    int64_t *piVar9;
    int32_t in_ECX;
    int32_t in_EDX;
    int32_t *piVar10;
    int32_t *piVar11;
    int32_t *piVar12;
    undefined8 unaff_RSI;
    uint32_t uVar13;
    undefined8 unaff_RDI;
    int64_t in_R8;
    uint64_t in_R9;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801ab118;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    piVar11 = (int32_t *)0x0;
    *(undefined4 *)((int64_t)&arg_38h + iVar5) = 0;
    if (((in_R8 != 0) && (*(int64_t *)((int64_t)&arg_50h + iVar5) != 0)) && (in_R9 < 0x80000000)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab15a;
        uVar6 = func_0x000180221ee0(0x1801adaf0);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab169;
        iVar7 = func_0x000180222290(uVar6, 0x180196ec0);
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RDI;
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RSI;
            if (0 < (int32_t)in_R9) {
                piVar10 = (int32_t *)(in_R8 + 0x24);
                piVar12 = piVar11;
                do {
                    if ((((piVar10[-1] < 1) || (in_EDX < 1)) || (piVar10[-1] <= in_EDX)) &&
                       (((*piVar10 < 1 || (in_ECX < 1)) || (in_ECX <= *piVar10)))) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab1c8;
                        ppiVar8 = (int32_t **)
                                  fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                                *(int64_t *)(&stack0x00000000 + iVar5));
                        if (ppiVar8 == (int32_t **)0x0) goto code_r0x0001801ab25e;
                        *ppiVar8 = piVar10 + -9;
                        ppiVar8[1] = piVar12;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab1ec;
                        iVar3 = func_0x000180222110(iVar7, ppiVar8);
                        if (iVar3 < 1) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab2b2;
                            fcn.180224990(ppiVar8, 0x1804aeee0, 0x3d4);
                            goto code_r0x0001801ab25e;
                        }
                    }
                    uVar13 = (int32_t)piVar12 + 1;
                    piVar12 = (int32_t *)(uint64_t)uVar13;
                    piVar10 = piVar10 + 0xe;
                } while ((int32_t)uVar13 < (int32_t)in_R9);
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab207;
            func_0x0001802222d0(iVar7);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab211;
            iVar3 = func_0x000180222010(iVar7);
            if (0 < iVar3) {
                iVar1 = *(int32_t *)(&stack0x00000048 + iVar5);
                uVar6 = *(undefined8 *)((int64_t)&arg_50h + iVar5);
                piVar12 = piVar11;
                do {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab22a;
                    piVar9 = (int64_t *)func_0x000180222340(iVar7, piVar11);
                    if ((iVar1 != 0) || (*(int16_t *)(*piVar9 + 0x1c) != (int16_t)piVar12)) {
                        piVar12 = (int32_t *)(uint64_t)*(uint16_t *)((int64_t)(undefined8 *)*piVar9 + 0x1c);
                        uVar2 = *(undefined8 *)*piVar9;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab24c;
                        iVar4 = func_0x000180222110(uVar6, uVar2);
                        if (iVar4 < 1) goto code_r0x0001801ab25e;
                    }
                    uVar13 = (int32_t)piVar11 + 1;
                    piVar11 = (int32_t *)(uint64_t)uVar13;
                } while ((int32_t)uVar13 < iVar3);
            }
            *(undefined4 *)((int64_t)&arg_38h + iVar5) = 1;
code_r0x0001801ab25e:
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab26d;
            uVar6 = func_0x000180222290(iVar7, 0x180196ec0);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab27c;
            func_0x000180222050(uVar6, 0x1801a7960);
            return *(undefined4 *)((int64_t)&arg_38h + iVar5);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801ab2b4
// Address: 0x1801ab2b4
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined4
fcn.1801ab100(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_98h,
             int64_t arg_a0h)
{
    int32_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int32_t **ppiVar8;
    int64_t *piVar9;
    int32_t in_ECX;
    int32_t in_EDX;
    int32_t *piVar10;
    int32_t *piVar11;
    int32_t *piVar12;
    undefined8 unaff_RSI;
    uint32_t uVar13;
    undefined8 unaff_RDI;
    int64_t in_R8;
    uint64_t in_R9;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801ab118;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    piVar11 = (int32_t *)0x0;
    *(undefined4 *)((int64_t)&arg_38h + iVar5) = 0;
    if (((in_R8 != 0) && (*(int64_t *)((int64_t)&arg_50h + iVar5) != 0)) && (in_R9 < 0x80000000)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab15a;
        uVar6 = func_0x000180221ee0(0x1801adaf0);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab169;
        iVar7 = func_0x000180222290(uVar6, 0x180196ec0);
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RDI;
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RSI;
            if (0 < (int32_t)in_R9) {
                piVar10 = (int32_t *)(in_R8 + 0x24);
                piVar12 = piVar11;
                do {
                    if ((((piVar10[-1] < 1) || (in_EDX < 1)) || (piVar10[-1] <= in_EDX)) &&
                       (((*piVar10 < 1 || (in_ECX < 1)) || (in_ECX <= *piVar10)))) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab1c8;
                        ppiVar8 = (int32_t **)
                                  fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                                *(int64_t *)(&stack0x00000000 + iVar5));
                        if (ppiVar8 == (int32_t **)0x0) goto code_r0x0001801ab25e;
                        *ppiVar8 = piVar10 + -9;
                        ppiVar8[1] = piVar12;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab1ec;
                        iVar3 = func_0x000180222110(iVar7, ppiVar8);
                        if (iVar3 < 1) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab2b2;
                            fcn.180224990(ppiVar8, 0x1804aeee0, 0x3d4);
                            goto code_r0x0001801ab25e;
                        }
                    }
                    uVar13 = (int32_t)piVar12 + 1;
                    piVar12 = (int32_t *)(uint64_t)uVar13;
                    piVar10 = piVar10 + 0xe;
                } while ((int32_t)uVar13 < (int32_t)in_R9);
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab207;
            func_0x0001802222d0(iVar7);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab211;
            iVar3 = func_0x000180222010(iVar7);
            if (0 < iVar3) {
                iVar1 = *(int32_t *)(&stack0x00000048 + iVar5);
                uVar6 = *(undefined8 *)((int64_t)&arg_50h + iVar5);
                piVar12 = piVar11;
                do {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab22a;
                    piVar9 = (int64_t *)func_0x000180222340(iVar7, piVar11);
                    if ((iVar1 != 0) || (*(int16_t *)(*piVar9 + 0x1c) != (int16_t)piVar12)) {
                        piVar12 = (int32_t *)(uint64_t)*(uint16_t *)((int64_t)(undefined8 *)*piVar9 + 0x1c);
                        uVar2 = *(undefined8 *)*piVar9;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab24c;
                        iVar4 = func_0x000180222110(uVar6, uVar2);
                        if (iVar4 < 1) goto code_r0x0001801ab25e;
                    }
                    uVar13 = (int32_t)piVar11 + 1;
                    piVar11 = (int32_t *)(uint64_t)uVar13;
                } while ((int32_t)uVar13 < iVar3);
            }
            *(undefined4 *)((int64_t)&arg_38h + iVar5) = 1;
code_r0x0001801ab25e:
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab26d;
            uVar6 = func_0x000180222290(iVar7, 0x180196ec0);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ab27c;
            func_0x000180222050(uVar6, 0x1801a7960);
            return *(undefined4 *)((int64_t)&arg_38h + iVar5);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801ab340
// Address: 0x1801ab340
// Size: 93 bytes
// ============================================================
uint64_t fcn.1801ab340(void)
{
    int32_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801ab34a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801ab352;
    iVar1 = fcn.1801a86f0(*(int64_t *)(&stack0x00000050 + iVar2), *(int64_t *)(&stack0x00000088 + iVar2));
    uVar3 = 0;
    if (iVar1 != 0) {
        while (*(int32_t *)(uVar3 * 8 + 0x1804ade80) != iVar1) {
            uVar3 = uVar3 + 1;
            if (0x2c < uVar3) {
                return 0;
            }
        }
        uVar3 = (uint64_t)*(uint16_t *)(uVar3 * 8 + 0x1804ade84);
    }
    return uVar3;
}

// ============================================================
// Function: FUN_1801ab3e0
// Address: 0x1801ab3e0
// Size: 498 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable arg_49h

int64_t fcn.1801ab3e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int64_t in_RCX;
    uint64_t in_RDX;
    int64_t *piVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ab3fa;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar9 = 0;
    uVar8 = in_RDX & 0xffffffff;
    if ((int32_t)in_RDX == -1) {
        if (*(int32_t *)(in_RCX + 0x78) == 0) {
            uVar8 = (**(int64_t **)(in_RCX + 0x878) - (*(int64_t **)(in_RCX + 0x878))[4]) / 0x28;
        } else {
            uVar8 = uVar9;
            if (*(int64_t *)(in_RCX + 0x118) == 0) {
                return 0;
            }
            while( true ) {
                uVar2 = *(undefined8 *)(in_RCX + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ab42d;
                iVar5 = func_0x0001801a1fe0(uVar8, uVar2);
                if ((iVar5 != 0) &&
                   (uVar6 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20), (*(uint32_t *)(iVar5 + 4) & uVar6) != 0)
                   ) break;
                uVar8 = uVar8 + 1;
                if (*(uint64_t *)(in_RCX + 0x118) <= uVar8) {
                    return 0;
                }
            }
            if ((int32_t)uVar8 == 4) {
                if (uVar6 != 0x20) {
                    uVar6 = 6;
                    iVar5 = 6;
                    piVar7 = (int64_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x878) + 0x20) + 0xf8);
                    do {
                        if (*piVar7 != 0) goto code_r0x0001801ab4db;
                        uVar6 = uVar6 - 1;
                        iVar5 = iVar5 + -1;
                        piVar7 = piVar7 + -5;
                    } while (3 < iVar5);
                }
                goto code_r0x0001801ab511;
            }
            if ((int32_t)uVar8 == 5) {
                uVar6 = 6;
                iVar5 = 6;
                piVar7 = (int64_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x878) + 0x20) + 0xf8);
                do {
                    if (*piVar7 != 0) goto code_r0x0001801ab4db;
                    uVar6 = uVar6 - 1;
                    iVar5 = iVar5 + -1;
                    piVar7 = piVar7 + -5;
                } while (4 < iVar5);
                goto code_r0x0001801ab511;
            }
        }
    }
    goto code_r0x0001801ab508;
code_r0x0001801ab4db:
    uVar8 = (uint64_t)uVar6;
code_r0x0001801ab508:
    if (8 < (uint32_t)uVar8) {
        return 0;
    }
code_r0x0001801ab511:
    if (((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 2) == 0) && ((int32_t)uVar8 == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ab53a;
        iVar3 = fcn.1801aa060(in_RCX, 0x5000b, *(int64_t *)((int64_t)&arg_28h + iVar4), 
                              *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar4));
        if (iVar3 != 0) {
            return 0x1804ae9a0;
        }
    } else {
        iVar5 = *(int64_t *)(in_RCX + 8);
        iVar10 = *(int64_t *)(iVar5 + 0x650);
        if (*(uint64_t *)(iVar5 + 0x640) != 0) {
            do {
                if (*(int16_t *)(iVar10 + 0x10) == *(int16_t *)((int64_t)(int32_t)uVar8 * 2 + 0x1804ae9e8)) {
                    if (*(int32_t *)(iVar10 + 0x2c) == 0) {
                        return 0;
                    }
                    if (*(int32_t *)(iVar10 + 0x14) != 0) {
                        uVar1 = *(undefined4 *)(iVar10 + 0x18);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ab5a9;
                        iVar5 = fcn.1801a08e0(iVar5, uVar1);
                        if (iVar5 == 0) {
                            return 0;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ab5c2;
                    iVar3 = fcn.1801aa060(in_RCX, 0x5000b, *(int64_t *)((int64_t)&arg_28h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar4));
                    if (iVar3 == 0) {
                        return 0;
                    }
                    return iVar10;
                }
                iVar10 = iVar10 + 0x48;
                uVar9 = uVar9 + 1;
            } while (uVar9 < *(uint64_t *)(iVar5 + 0x640));
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801ab730
// Address: 0x1801ab730
// Size: 73 bytes
// ============================================================
undefined8 fcn.1801ab730(undefined8 param_1, int64_t param_2, int64_t *param_3)
{
    undefined4 uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ab73c;
    iVar2 = fcn.18045a350();
    if (param_2 == 0) {
        return 0;
    }
    if (*(int32_t *)(param_2 + 0x14) == 0) {
        iVar2 = 0;
    } else {
        uVar1 = *(undefined4 *)(param_2 + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1801ab759;
        iVar2 = fcn.1801a08e0(param_1, uVar1);
        if (iVar2 == 0) {
            return 0;
        }
    }
    if (param_3 != (int64_t *)0x0) {
        *param_3 = iVar2;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801ab780
// Address: 0x1801ab780
// Size: 63 bytes
// ============================================================
bool fcn.1801ab780(int64_t param_1)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ab78c;
    iVar3 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x1801ab797;
    iVar2 = fcn.1801c5550();
    if (iVar2 != 0) {
        pcVar1 = *(code **)(*(int64_t *)(param_1 + 0x18) + 0x30);
        *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x1801ab7a8;
        iVar2 = (*pcVar1)(param_1);
        return iVar2 != 0;
    }
    return false;
}

// ============================================================
// Function: FUN_1801ab7c0
// Address: 0x1801ab7c0
// Size: 105 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801ab7c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_60h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    uint64_t uVar5;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    uint64_t uVar6;
    undefined8 unaff_RSI;
    int64_t iVar7;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ab7d1;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar1 = *(int64_t *)(in_RCX + 0x408);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ab7e3;
    uVar4 = fcn.1801ac470(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar3));
    if ((int32_t)uVar4 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        uVar6 = 0;
        uVar5 = uVar6;
        if (*(int64_t *)(in_RCX + 0x118) != 0) {
            do {
                *(undefined4 *)(iVar1 + uVar5 * 4) = 0;
                uVar5 = uVar5 + 1;
            } while (uVar5 < *(uint64_t *)(in_RCX + 0x118));
        }
        if (*(int64_t *)(in_RCX + 0x1588) != 0) {
            *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
            do {
                iVar7 = *(int64_t *)(*(int64_t *)(in_RCX + 0x1580) + uVar6 * 8);
                if ((((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
                      (iVar2 = **(int32_t **)(in_RCX + 0x18), iVar2 < 0x304)) || (iVar2 == 0x10000)) ||
                    (*(int32_t *)(iVar7 + 0x1c) != 6)) &&
                   (iVar7 = (int64_t)*(int32_t *)(iVar7 + 0x20), *(int32_t *)(iVar1 + iVar7 * 4) == 0)) {
                    uVar4 = *(undefined8 *)(in_RCX + 8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ab879;
                    iVar2 = fcn.18019e480(uVar4, iVar7);
                    if (iVar2 == 0) {
                        *(undefined4 *)(iVar1 + iVar7 * 4) = 0x102;
                    }
                }
                uVar6 = uVar6 + 1;
            } while (uVar6 < *(uint64_t *)(in_RCX + 0x1588));
        }
        return 1;
    }
    return uVar4;
}

// ============================================================
// Function: FUN_1801ab829
// Address: 0x1801ab829
// Size: 109 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801ab7c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_60h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    uint64_t uVar5;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    uint64_t uVar6;
    undefined8 unaff_RSI;
    int64_t iVar7;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ab7d1;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar1 = *(int64_t *)(in_RCX + 0x408);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ab7e3;
    uVar4 = fcn.1801ac470(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar3));
    if ((int32_t)uVar4 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        uVar6 = 0;
        uVar5 = uVar6;
        if (*(int64_t *)(in_RCX + 0x118) != 0) {
            do {
                *(undefined4 *)(iVar1 + uVar5 * 4) = 0;
                uVar5 = uVar5 + 1;
            } while (uVar5 < *(uint64_t *)(in_RCX + 0x118));
        }
        if (*(int64_t *)(in_RCX + 0x1588) != 0) {
            *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
            do {
                iVar7 = *(int64_t *)(*(int64_t *)(in_RCX + 0x1580) + uVar6 * 8);
                if ((((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
                      (iVar2 = **(int32_t **)(in_RCX + 0x18), iVar2 < 0x304)) || (iVar2 == 0x10000)) ||
                    (*(int32_t *)(iVar7 + 0x1c) != 6)) &&
                   (iVar7 = (int64_t)*(int32_t *)(iVar7 + 0x20), *(int32_t *)(iVar1 + iVar7 * 4) == 0)) {
                    uVar4 = *(undefined8 *)(in_RCX + 8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ab879;
                    iVar2 = fcn.18019e480(uVar4, iVar7);
                    if (iVar2 == 0) {
                        *(undefined4 *)(iVar1 + iVar7 * 4) = 0x102;
                    }
                }
                uVar6 = uVar6 + 1;
            } while (uVar6 < *(uint64_t *)(in_RCX + 0x1588));
        }
        return 1;
    }
    return uVar4;
}

// ============================================================
// Function: FUN_1801ab896
// Address: 0x1801ab896
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801ab7c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_60h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    uint64_t uVar5;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    uint64_t uVar6;
    undefined8 unaff_RSI;
    int64_t iVar7;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ab7d1;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar1 = *(int64_t *)(in_RCX + 0x408);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ab7e3;
    uVar4 = fcn.1801ac470(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar3));
    if ((int32_t)uVar4 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        uVar6 = 0;
        uVar5 = uVar6;
        if (*(int64_t *)(in_RCX + 0x118) != 0) {
            do {
                *(undefined4 *)(iVar1 + uVar5 * 4) = 0;
                uVar5 = uVar5 + 1;
            } while (uVar5 < *(uint64_t *)(in_RCX + 0x118));
        }
        if (*(int64_t *)(in_RCX + 0x1588) != 0) {
            *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
            do {
                iVar7 = *(int64_t *)(*(int64_t *)(in_RCX + 0x1580) + uVar6 * 8);
                if ((((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
                      (iVar2 = **(int32_t **)(in_RCX + 0x18), iVar2 < 0x304)) || (iVar2 == 0x10000)) ||
                    (*(int32_t *)(iVar7 + 0x1c) != 6)) &&
                   (iVar7 = (int64_t)*(int32_t *)(iVar7 + 0x20), *(int32_t *)(iVar1 + iVar7 * 4) == 0)) {
                    uVar4 = *(undefined8 *)(in_RCX + 8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ab879;
                    iVar2 = fcn.18019e480(uVar4, iVar7);
                    if (iVar2 == 0) {
                        *(undefined4 *)(iVar1 + iVar7 * 4) = 0x102;
                    }
                }
                uVar6 = uVar6 + 1;
            } while (uVar6 < *(uint64_t *)(in_RCX + 0x1588));
        }
        return 1;
    }
    return uVar4;
}

// ============================================================
// Function: FUN_1801ab8b0
// Address: 0x1801ab8b0
// Size: 118 bytes
// ============================================================
undefined8
fcn.1801ab8b0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
             int64_t arg_60h, int64_t arg_68h)
{
    undefined uVar1;
    undefined uVar2;
    undefined *puVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    undefined8 *in_RDX;
    int64_t *piVar8;
    undefined8 unaff_RBX;
    uint64_t uVar9;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    uint64_t *puVar10;
    uint64_t uVar11;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 auStackX_18 [2];
    
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 2) == 0) {
        return 1;
    }
    if (*(int64_t *)(in_RCX + 0x878) == 0) {
        return 0;
    }
    if (in_R8D == 0) {
        puVar10 = (uint64_t *)(in_RCX + 0x3f0);
        piVar8 = (int64_t *)(in_RCX + 0x3e0);
    } else {
        puVar10 = (uint64_t *)(in_RCX + 0x3f8);
        piVar8 = (int64_t *)(in_RCX + 1000);
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5) = 0x1801ab950;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar9 = in_RDX[1];
    if ((uVar9 != 0) && ((uVar9 & 1) == 0)) {
        uVar9 = uVar9 >> 1;
        *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x1801ab98f;
        iVar7 = fcn.180224ed0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5));
        if (iVar7 != 0) {
            uVar11 = 0;
            if (uVar9 != 0) {
                do {
                    if ((uint64_t)in_RDX[1] < 2) goto code_r0x0001801ab9de;
                    puVar3 = (undefined *)*in_RDX;
                    uVar1 = *puVar3;
                    uVar2 = puVar3[1];
                    *in_RDX = puVar3 + 2;
                    in_RDX[1] = in_RDX[1] - 2;
                    *(uint16_t *)(iVar7 + uVar11 * 2) = CONCAT11(uVar1, uVar2);
                    uVar11 = uVar11 + 1;
                } while (uVar11 < uVar9);
            }
            if (uVar11 == uVar9) {
                iVar4 = *piVar8;
                *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x1801aba25;
                fcn.180224990(iVar4, 0x1804aeee0, 0xdf4);
                *piVar8 = iVar7;
                *puVar10 = uVar9;
                return 1;
            }
code_r0x0001801ab9de:
            *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x1801ab9f3;
            fcn.180224990(iVar7, 0x1804aeee0, 0xdf0);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801ab930
// Address: 0x1801ab930
// Size: 258 bytes
// ============================================================
undefined8
fcn.1801ab8b0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
             int64_t arg_60h, int64_t arg_68h)
{
    undefined uVar1;
    undefined uVar2;
    undefined *puVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    undefined8 *in_RDX;
    int64_t *piVar8;
    undefined8 unaff_RBX;
    uint64_t uVar9;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    uint64_t *puVar10;
    uint64_t uVar11;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 auStackX_18 [2];
    
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 2) == 0) {
        return 1;
    }
    if (*(int64_t *)(in_RCX + 0x878) == 0) {
        return 0;
    }
    if (in_R8D == 0) {
        puVar10 = (uint64_t *)(in_RCX + 0x3f0);
        piVar8 = (int64_t *)(in_RCX + 0x3e0);
    } else {
        puVar10 = (uint64_t *)(in_RCX + 0x3f8);
        piVar8 = (int64_t *)(in_RCX + 1000);
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5) = 0x1801ab950;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar9 = in_RDX[1];
    if ((uVar9 != 0) && ((uVar9 & 1) == 0)) {
        uVar9 = uVar9 >> 1;
        *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x1801ab98f;
        iVar7 = fcn.180224ed0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5));
        if (iVar7 != 0) {
            uVar11 = 0;
            if (uVar9 != 0) {
                do {
                    if ((uint64_t)in_RDX[1] < 2) goto code_r0x0001801ab9de;
                    puVar3 = (undefined *)*in_RDX;
                    uVar1 = *puVar3;
                    uVar2 = puVar3[1];
                    *in_RDX = puVar3 + 2;
                    in_RDX[1] = in_RDX[1] - 2;
                    *(uint16_t *)(iVar7 + uVar11 * 2) = CONCAT11(uVar1, uVar2);
                    uVar11 = uVar11 + 1;
                } while (uVar11 < uVar9);
            }
            if (uVar11 == uVar9) {
                iVar4 = *piVar8;
                *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x1801aba25;
                fcn.180224990(iVar4, 0x1804aeee0, 0xdf4);
                *piVar8 = iVar7;
                *puVar10 = uVar9;
                return 1;
            }
code_r0x0001801ab9de:
            *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x1801ab9f3;
            fcn.180224990(iVar7, 0x1804aeee0, 0xdf0);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801aba40
// Address: 0x1801aba40
// Size: 237 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_408h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_358h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_350h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_348h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b52h because it doesn't fit into ProtoModel

void fcn.1801aba40(undefined8 param_1)
{
    int64_t iVar1;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801aba4c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801aba67;
    fcn.1801aa4c0(param_1, 0, 0, *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1));
    *(undefined4 *)((int64_t)&var_18h + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801aba7f;
    fcn.1801aa4c0(param_1, 0, 0, *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1));
    *(undefined4 *)((int64_t)&var_18h + iVar1) = 2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801aba97;
    fcn.1801aa4c0(param_1, 0, 0, *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1));
    *(undefined4 *)((int64_t)&var_18h + iVar1) = 3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801abaaf;
    fcn.1801aa4c0(param_1, 0, 0, *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1));
    *(undefined4 *)((int64_t)&var_18h + iVar1) = 4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801abac7;
    fcn.1801aa4c0(param_1, 0, 0, *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1));
    *(undefined4 *)((int64_t)&var_18h + iVar1) = 5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801abadf;
    fcn.1801aa4c0(param_1, 0, 0, *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1));
    *(undefined4 *)((int64_t)&var_18h + iVar1) = 6;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801abaf7;
    fcn.1801aa4c0(param_1, 0, 0, *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1));
    *(undefined4 *)((int64_t)&var_18h + iVar1) = 7;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801abb0f;
    fcn.1801aa4c0(param_1, 0, 0, *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1));
    *(undefined4 *)((int64_t)&var_18h + iVar1) = 8;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801abb27;
    fcn.1801aa4c0(param_1, 0, 0, *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1801abb30
// Address: 0x1801abb30
// Size: 135 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

undefined8
fcn.1801abb30(undefined8 *placeholder_0, int64_t arg2, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
             int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    uint16_t uVar1;
    uint32_t uVar2;
    undefined8 *puVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int64_t iVar7;
    undefined2 *puVar8;
    undefined8 *puVar9;
    undefined8 *puVar10;
    undefined8 *puVar11;
    uint32_t uVar12;
    undefined8 *puVar13;
    undefined8 unaff_RSI;
    undefined8 *in_R8;
    undefined8 *in_R9;
    undefined8 *puVar14;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_28h;
    int64_t var_8h;
    
    uStack_30 = 0x1801abb52;
    var_10h = arg2;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    puVar3 = *(undefined8 **)((int64_t)&arg_70h + iVar7);
    puVar13 = (undefined8 *)0x0;
    *(undefined4 *)((int64_t)&var_8h + iVar7) = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar7 + 4) = 0;
    if (puVar3 == (undefined8 *)0x0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abb80;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)(&stack0x00000000 + iVar7));
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abb98;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar7));
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abbaa;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar7));
    } else {
        *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abbd0;
        puVar8 = (undefined2 *)fcn.180224ed0(*(int64_t *)((int64_t)&var_8h + iVar7));
        puVar10 = puVar13;
        puVar9 = puVar13;
        if (puVar8 != (undefined2 *)0x0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abbf8;
            puVar9 = (undefined8 *)fcn.180224ed0(*(int64_t *)((int64_t)&var_8h + iVar7));
            puVar10 = (undefined8 *)0x0;
            if (puVar9 != (undefined8 *)0x0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abc1c;
                puVar10 = (undefined8 *)fcn.180224ed0(*(int64_t *)((int64_t)&var_8h + iVar7));
                if (puVar10 != (undefined8 *)0x0) {
                    if (puVar3 != (undefined8 *)0x0) {
                        iVar4 = *(int64_t *)((int64_t)&arg_68h + iVar7);
                        *(undefined4 *)((int64_t)&arg_70h + iVar7) = 0x100;
                        puVar14 = puVar13;
                        do {
                            puVar11 = puVar13;
                            while (*(int32_t *)((int64_t)puVar11 * 8 + 0x1804ade80) !=
                                   *(int32_t *)(iVar4 + (int64_t)puVar14 * 4)) {
                                puVar11 = (undefined8 *)((int64_t)puVar11 + 1);
                                if ((undefined8 *)0x2c < puVar11) goto code_r0x0001801abc77;
                            }
                            uVar1 = *(uint16_t *)((int64_t)puVar11 * 8 + 0x1804ade84);
                            if (0x1f < (uVar1 & 0xff)) goto code_r0x0001801abc77;
                            uVar12 = 1 << ((uint8_t)uVar1 & 0x1f);
                            piVar6 = &var_8h;
                            if (*(uint16_t *)((int64_t)&arg_70h + iVar7) <= uVar1) {
                                piVar6 = (int64_t *)((int64_t)&var_8h + 4);
                            }
                            if ((uVar1 == 0) || (uVar2 = *(uint32_t *)((int64_t)piVar6 + iVar7), (uVar12 & uVar2) != 0))
                            goto code_r0x0001801abc77;
                            puVar8[(int64_t)puVar14] = uVar1;
                            puVar14 = (undefined8 *)((int64_t)puVar14 + 1);
                            *(uint32_t *)((int64_t)piVar6 + iVar7) = uVar2 | uVar12;
                        } while (puVar14 < puVar3);
                    }
                    uVar5 = *placeholder_0;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abd4d;
                    fcn.180224990(uVar5, 0x1804aeee0, 0x461);
                    uVar5 = *in_R8;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abd63;
                    fcn.180224990(uVar5, 0x1804aeee0, 0x462);
                    puVar13 = *(undefined8 **)((int64_t)&arg_58h + iVar7);
                    uVar5 = *puVar13;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abd80;
                    fcn.180224990(uVar5, 0x1804aeee0, 0x463);
                    puVar14 = *(undefined8 **)((int64_t)&arg_40h + iVar7);
                    *placeholder_0 = puVar8;
                    *puVar14 = puVar3;
                    *(undefined2 *)puVar9 = *puVar8;
                    puVar14 = *(undefined8 **)((int64_t)&arg_60h + iVar7);
                    *in_R8 = puVar9;
                    *in_R9 = 1;
                    *puVar10 = puVar3;
                    *puVar13 = puVar10;
                    *puVar14 = 1;
                    return 1;
                }
            }
        }
code_r0x0001801abc77:
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abc8c;
        fcn.180224990(puVar8, 0x1804aeee0, 0x46e);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abca1;
        fcn.180224990(puVar9, 0x1804aeee0, 0x46f);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abcb6;
        fcn.180224990(puVar10, 0x1804aeee0, 0x470);
    }
    return 0;
}

// ============================================================
// Function: FUN_1801abbb7
// Address: 0x1801abbb7
// Size: 262 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

undefined8
fcn.1801abb30(undefined8 *placeholder_0, int64_t arg2, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
             int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    uint16_t uVar1;
    uint32_t uVar2;
    undefined8 *puVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int64_t iVar7;
    undefined2 *puVar8;
    undefined8 *puVar9;
    undefined8 *puVar10;
    undefined8 *puVar11;
    uint32_t uVar12;
    undefined8 *puVar13;
    undefined8 unaff_RSI;
    undefined8 *in_R8;
    undefined8 *in_R9;
    undefined8 *puVar14;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_28h;
    int64_t var_8h;
    
    uStack_30 = 0x1801abb52;
    var_10h = arg2;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    puVar3 = *(undefined8 **)((int64_t)&arg_70h + iVar7);
    puVar13 = (undefined8 *)0x0;
    *(undefined4 *)((int64_t)&var_8h + iVar7) = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar7 + 4) = 0;
    if (puVar3 == (undefined8 *)0x0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abb80;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)(&stack0x00000000 + iVar7));
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abb98;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar7));
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abbaa;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar7));
    } else {
        *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abbd0;
        puVar8 = (undefined2 *)fcn.180224ed0(*(int64_t *)((int64_t)&var_8h + iVar7));
        puVar10 = puVar13;
        puVar9 = puVar13;
        if (puVar8 != (undefined2 *)0x0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abbf8;
            puVar9 = (undefined8 *)fcn.180224ed0(*(int64_t *)((int64_t)&var_8h + iVar7));
            puVar10 = (undefined8 *)0x0;
            if (puVar9 != (undefined8 *)0x0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abc1c;
                puVar10 = (undefined8 *)fcn.180224ed0(*(int64_t *)((int64_t)&var_8h + iVar7));
                if (puVar10 != (undefined8 *)0x0) {
                    if (puVar3 != (undefined8 *)0x0) {
                        iVar4 = *(int64_t *)((int64_t)&arg_68h + iVar7);
                        *(undefined4 *)((int64_t)&arg_70h + iVar7) = 0x100;
                        puVar14 = puVar13;
                        do {
                            puVar11 = puVar13;
                            while (*(int32_t *)((int64_t)puVar11 * 8 + 0x1804ade80) !=
                                   *(int32_t *)(iVar4 + (int64_t)puVar14 * 4)) {
                                puVar11 = (undefined8 *)((int64_t)puVar11 + 1);
                                if ((undefined8 *)0x2c < puVar11) goto code_r0x0001801abc77;
                            }
                            uVar1 = *(uint16_t *)((int64_t)puVar11 * 8 + 0x1804ade84);
                            if (0x1f < (uVar1 & 0xff)) goto code_r0x0001801abc77;
                            uVar12 = 1 << ((uint8_t)uVar1 & 0x1f);
                            piVar6 = &var_8h;
                            if (*(uint16_t *)((int64_t)&arg_70h + iVar7) <= uVar1) {
                                piVar6 = (int64_t *)((int64_t)&var_8h + 4);
                            }
                            if ((uVar1 == 0) || (uVar2 = *(uint32_t *)((int64_t)piVar6 + iVar7), (uVar12 & uVar2) != 0))
                            goto code_r0x0001801abc77;
                            puVar8[(int64_t)puVar14] = uVar1;
                            puVar14 = (undefined8 *)((int64_t)puVar14 + 1);
                            *(uint32_t *)((int64_t)piVar6 + iVar7) = uVar2 | uVar12;
                        } while (puVar14 < puVar3);
                    }
                    uVar5 = *placeholder_0;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abd4d;
                    fcn.180224990(uVar5, 0x1804aeee0, 0x461);
                    uVar5 = *in_R8;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abd63;
                    fcn.180224990(uVar5, 0x1804aeee0, 0x462);
                    puVar13 = *(undefined8 **)((int64_t)&arg_58h + iVar7);
                    uVar5 = *puVar13;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abd80;
                    fcn.180224990(uVar5, 0x1804aeee0, 0x463);
                    puVar14 = *(undefined8 **)((int64_t)&arg_40h + iVar7);
                    *placeholder_0 = puVar8;
                    *puVar14 = puVar3;
                    *(undefined2 *)puVar9 = *puVar8;
                    puVar14 = *(undefined8 **)((int64_t)&arg_60h + iVar7);
                    *in_R8 = puVar9;
                    *in_R9 = 1;
                    *puVar10 = puVar3;
                    *puVar13 = puVar10;
                    *puVar14 = 1;
                    return 1;
                }
            }
        }
code_r0x0001801abc77:
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abc8c;
        fcn.180224990(puVar8, 0x1804aeee0, 0x46e);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abca1;
        fcn.180224990(puVar9, 0x1804aeee0, 0x46f);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abcb6;
        fcn.180224990(puVar10, 0x1804aeee0, 0x470);
    }
    return 0;
}

// ============================================================
// Function: FUN_1801abcbd
// Address: 0x1801abcbd
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

undefined8
fcn.1801abb30(undefined8 *placeholder_0, int64_t arg2, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
             int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    uint16_t uVar1;
    uint32_t uVar2;
    undefined8 *puVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int64_t iVar7;
    undefined2 *puVar8;
    undefined8 *puVar9;
    undefined8 *puVar10;
    undefined8 *puVar11;
    uint32_t uVar12;
    undefined8 *puVar13;
    undefined8 unaff_RSI;
    undefined8 *in_R8;
    undefined8 *in_R9;
    undefined8 *puVar14;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_28h;
    int64_t var_8h;
    
    uStack_30 = 0x1801abb52;
    var_10h = arg2;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    puVar3 = *(undefined8 **)((int64_t)&arg_70h + iVar7);
    puVar13 = (undefined8 *)0x0;
    *(undefined4 *)((int64_t)&var_8h + iVar7) = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar7 + 4) = 0;
    if (puVar3 == (undefined8 *)0x0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abb80;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)(&stack0x00000000 + iVar7));
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abb98;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar7));
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abbaa;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar7));
    } else {
        *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abbd0;
        puVar8 = (undefined2 *)fcn.180224ed0(*(int64_t *)((int64_t)&var_8h + iVar7));
        puVar10 = puVar13;
        puVar9 = puVar13;
        if (puVar8 != (undefined2 *)0x0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abbf8;
            puVar9 = (undefined8 *)fcn.180224ed0(*(int64_t *)((int64_t)&var_8h + iVar7));
            puVar10 = (undefined8 *)0x0;
            if (puVar9 != (undefined8 *)0x0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abc1c;
                puVar10 = (undefined8 *)fcn.180224ed0(*(int64_t *)((int64_t)&var_8h + iVar7));
                if (puVar10 != (undefined8 *)0x0) {
                    if (puVar3 != (undefined8 *)0x0) {
                        iVar4 = *(int64_t *)((int64_t)&arg_68h + iVar7);
                        *(undefined4 *)((int64_t)&arg_70h + iVar7) = 0x100;
                        puVar14 = puVar13;
                        do {
                            puVar11 = puVar13;
                            while (*(int32_t *)((int64_t)puVar11 * 8 + 0x1804ade80) !=
                                   *(int32_t *)(iVar4 + (int64_t)puVar14 * 4)) {
                                puVar11 = (undefined8 *)((int64_t)puVar11 + 1);
                                if ((undefined8 *)0x2c < puVar11) goto code_r0x0001801abc77;
                            }
                            uVar1 = *(uint16_t *)((int64_t)puVar11 * 8 + 0x1804ade84);
                            if (0x1f < (uVar1 & 0xff)) goto code_r0x0001801abc77;
                            uVar12 = 1 << ((uint8_t)uVar1 & 0x1f);
                            piVar6 = &var_8h;
                            if (*(uint16_t *)((int64_t)&arg_70h + iVar7) <= uVar1) {
                                piVar6 = (int64_t *)((int64_t)&var_8h + 4);
                            }
                            if ((uVar1 == 0) || (uVar2 = *(uint32_t *)((int64_t)piVar6 + iVar7), (uVar12 & uVar2) != 0))
                            goto code_r0x0001801abc77;
                            puVar8[(int64_t)puVar14] = uVar1;
                            puVar14 = (undefined8 *)((int64_t)puVar14 + 1);
                            *(uint32_t *)((int64_t)piVar6 + iVar7) = uVar2 | uVar12;
                        } while (puVar14 < puVar3);
                    }
                    uVar5 = *placeholder_0;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abd4d;
                    fcn.180224990(uVar5, 0x1804aeee0, 0x461);
                    uVar5 = *in_R8;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abd63;
                    fcn.180224990(uVar5, 0x1804aeee0, 0x462);
                    puVar13 = *(undefined8 **)((int64_t)&arg_58h + iVar7);
                    uVar5 = *puVar13;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abd80;
                    fcn.180224990(uVar5, 0x1804aeee0, 0x463);
                    puVar14 = *(undefined8 **)((int64_t)&arg_40h + iVar7);
                    *placeholder_0 = puVar8;
                    *puVar14 = puVar3;
                    *(undefined2 *)puVar9 = *puVar8;
                    puVar14 = *(undefined8 **)((int64_t)&arg_60h + iVar7);
                    *in_R8 = puVar9;
                    *in_R9 = 1;
                    *puVar10 = puVar3;
                    *puVar13 = puVar10;
                    *puVar14 = 1;
                    return 1;
                }
            }
        }
code_r0x0001801abc77:
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abc8c;
        fcn.180224990(puVar8, 0x1804aeee0, 0x46e);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abca1;
        fcn.180224990(puVar9, 0x1804aeee0, 0x46f);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abcb6;
        fcn.180224990(puVar10, 0x1804aeee0, 0x470);
    }
    return 0;
}

// ============================================================
// Function: FUN_1801abcd5
// Address: 0x1801abcd5
// Size: 233 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

undefined8
fcn.1801abb30(undefined8 *placeholder_0, int64_t arg2, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
             int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    uint16_t uVar1;
    uint32_t uVar2;
    undefined8 *puVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int64_t iVar7;
    undefined2 *puVar8;
    undefined8 *puVar9;
    undefined8 *puVar10;
    undefined8 *puVar11;
    uint32_t uVar12;
    undefined8 *puVar13;
    undefined8 unaff_RSI;
    undefined8 *in_R8;
    undefined8 *in_R9;
    undefined8 *puVar14;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_28h;
    int64_t var_8h;
    
    uStack_30 = 0x1801abb52;
    var_10h = arg2;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    puVar3 = *(undefined8 **)((int64_t)&arg_70h + iVar7);
    puVar13 = (undefined8 *)0x0;
    *(undefined4 *)((int64_t)&var_8h + iVar7) = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar7 + 4) = 0;
    if (puVar3 == (undefined8 *)0x0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abb80;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)(&stack0x00000000 + iVar7));
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abb98;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar7));
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abbaa;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar7));
    } else {
        *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abbd0;
        puVar8 = (undefined2 *)fcn.180224ed0(*(int64_t *)((int64_t)&var_8h + iVar7));
        puVar10 = puVar13;
        puVar9 = puVar13;
        if (puVar8 != (undefined2 *)0x0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abbf8;
            puVar9 = (undefined8 *)fcn.180224ed0(*(int64_t *)((int64_t)&var_8h + iVar7));
            puVar10 = (undefined8 *)0x0;
            if (puVar9 != (undefined8 *)0x0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abc1c;
                puVar10 = (undefined8 *)fcn.180224ed0(*(int64_t *)((int64_t)&var_8h + iVar7));
                if (puVar10 != (undefined8 *)0x0) {
                    if (puVar3 != (undefined8 *)0x0) {
                        iVar4 = *(int64_t *)((int64_t)&arg_68h + iVar7);
                        *(undefined4 *)((int64_t)&arg_70h + iVar7) = 0x100;
                        puVar14 = puVar13;
                        do {
                            puVar11 = puVar13;
                            while (*(int32_t *)((int64_t)puVar11 * 8 + 0x1804ade80) !=
                                   *(int32_t *)(iVar4 + (int64_t)puVar14 * 4)) {
                                puVar11 = (undefined8 *)((int64_t)puVar11 + 1);
                                if ((undefined8 *)0x2c < puVar11) goto code_r0x0001801abc77;
                            }
                            uVar1 = *(uint16_t *)((int64_t)puVar11 * 8 + 0x1804ade84);
                            if (0x1f < (uVar1 & 0xff)) goto code_r0x0001801abc77;
                            uVar12 = 1 << ((uint8_t)uVar1 & 0x1f);
                            piVar6 = &var_8h;
                            if (*(uint16_t *)((int64_t)&arg_70h + iVar7) <= uVar1) {
                                piVar6 = (int64_t *)((int64_t)&var_8h + 4);
                            }
                            if ((uVar1 == 0) || (uVar2 = *(uint32_t *)((int64_t)piVar6 + iVar7), (uVar12 & uVar2) != 0))
                            goto code_r0x0001801abc77;
                            puVar8[(int64_t)puVar14] = uVar1;
                            puVar14 = (undefined8 *)((int64_t)puVar14 + 1);
                            *(uint32_t *)((int64_t)piVar6 + iVar7) = uVar2 | uVar12;
                        } while (puVar14 < puVar3);
                    }
                    uVar5 = *placeholder_0;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abd4d;
                    fcn.180224990(uVar5, 0x1804aeee0, 0x461);
                    uVar5 = *in_R8;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abd63;
                    fcn.180224990(uVar5, 0x1804aeee0, 0x462);
                    puVar13 = *(undefined8 **)((int64_t)&arg_58h + iVar7);
                    uVar5 = *puVar13;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abd80;
                    fcn.180224990(uVar5, 0x1804aeee0, 0x463);
                    puVar14 = *(undefined8 **)((int64_t)&arg_40h + iVar7);
                    *placeholder_0 = puVar8;
                    *puVar14 = puVar3;
                    *(undefined2 *)puVar9 = *puVar8;
                    puVar14 = *(undefined8 **)((int64_t)&arg_60h + iVar7);
                    *in_R8 = puVar9;
                    *in_R9 = 1;
                    *puVar10 = puVar3;
                    *puVar13 = puVar10;
                    *puVar14 = 1;
                    return 1;
                }
            }
        }
code_r0x0001801abc77:
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abc8c;
        fcn.180224990(puVar8, 0x1804aeee0, 0x46e);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abca1;
        fcn.180224990(puVar9, 0x1804aeee0, 0x46f);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801abcb6;
        fcn.180224990(puVar10, 0x1804aeee0, 0x470);
    }
    return 0;
}

// ============================================================
// Function: FUN_1801abdc0
// Address: 0x1801abdc0
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1801abdc0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h,
                      int64_t arg_98h, int64_t arg_a0h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    char cVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int64_t in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    char *pcVar11;
    undefined8 unaff_RSI;
    uint64_t uVar12;
    int64_t *in_R8;
    int64_t *in_R9;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801abdde;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar10 = 0;
    uVar12 = 0;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abdf6;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abe0e;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                      *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abe20;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar7));
        uVar8 = 0;
    } else {
        *(undefined8 *)((int64_t)&arg_98h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_a0h + iVar7) = unaff_RSI;
        _var_68h = ZEXT816(0);
        _var_28h = ZEXT812(1);
        uStack_20._4_4_ = 0;
        var_38h = 0;
        var_30h = 0;
        var_70h = 0x20;
        var_78h = in_RCX;
        var_58h = 0x20;
        var_50h = 0;
        var_48h = 0;
        var_40h = 0x20;
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abe95;
        iVar9 = fcn.180224ed0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
        uVar8 = uVar10;
        var_60h = iVar9;
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abebd;
            var_48h = fcn.180224ed0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
            if ((undefined8 *)var_48h != (undefined8 *)0x0) {
                *(undefined8 *)var_48h = 0;
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abee8;
                var_30h = fcn.180224ed0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                if (var_30h != 0) {
                    cVar5 = *(char *)arg_40h;
                    pcVar11 = (char *)arg_40h;
                    if (cVar5 != '\0') {
code_r0x0001801abf04:
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abf0c;
                        iVar6 = func_0x00018046ce40(cVar5);
                        if (iVar6 != 0) goto code_r0x0001801abf10;
                        if (*pcVar11 != '\0') {
                            *(int64_t **)((int64_t)&iStackX_10 + iVar7 + -8) = &var_78h;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abf4c;
                            iVar6 = func_0x00018024a850(pcVar11, 0x2f, 1, 0x1801ade20);
                            uVar8 = uVar12;
                            if (iVar6 != 0) {
                                if (iVar6 == -1) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abf5e;
                                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_10 + iVar7));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abf76;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar7), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar7), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar7));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abf8f;
                                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar7));
                                } else {
                                    uVar12 = uVar10;
                                    if (var_50h != 0) {
                                        do {
                                            iVar9 = *(int64_t *)(var_48h + uVar10 * 8);
                                            if (iVar9 != 0) {
                                                if (uVar10 != uVar12) {
                                                    *(int64_t *)(var_48h + uVar12 * 8) = iVar9;
                                                }
                                                uVar12 = uVar12 + 1;
                                            }
                                            uVar10 = uVar10 + 1;
                                        } while (uVar10 < (uint64_t)var_50h);
                                    }
                                    var_50h = uVar12;
                                    if ((uint64_t)var_38h < 5) {
                                        if ((var_68h != 0) && (var_38h == 0)) {
                                            var_38h = 1;
                                            *(undefined2 *)var_30h = 0;
                                        }
                                        goto code_r0x0001801ac037;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abfdf;
                                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_10 + iVar7));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abff7;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar7), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar7), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar7));
                                    *(undefined4 *)((int64_t)&iStackX_10 + iVar7 + -8) = 4;
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801ac018;
                                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar7));
                                }
                            }
                            goto code_r0x0001801ac0e7;
                        }
                    }
code_r0x0001801ac037:
                    iVar4 = arg_38h;
                    iVar3 = arg_30h;
                    iVar9 = arg_28h;
                    if ((((in_RDX != (int64_t *)0x0) && (in_R9 != (int64_t *)0x0)) && (arg_30h != 0)) &&
                       (((in_R8 != (int64_t *)0x0 && (arg_28h != 0)) && (arg_38h != 0)))) {
                        iVar1 = *in_RDX;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801ac086;
                        fcn.180224990(iVar1, 0x1804aeee0, 0x6a2);
                        *in_RDX = var_60h;
                        *in_R8 = var_68h;
                        iVar1 = *in_R9;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801ac0aa;
                        fcn.180224990(iVar1, 0x1804aeee0, 0x6a5);
                        *in_R9 = var_30h;
                        *(int64_t *)iVar9 = var_38h;
                        uVar2 = *(undefined8 *)iVar3;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801ac0cd;
                        fcn.180224990(uVar2, 0x1804aeee0, 0x6a8);
                        *(int64_t *)iVar3 = var_48h;
                        *(int64_t *)iVar4 = var_50h;
                        return 1;
                    }
                    uVar8 = 1;
                }
            }
        }
code_r0x0001801ac0e7:
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801ac0fd;
        fcn.180224990(var_60h, 0x1804aeee0, 0x6af);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801ac113;
        fcn.180224990(var_48h, 0x1804aeee0, 0x6b0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801ac129;
        fcn.180224990(var_30h, 0x1804aeee0, 0x6b1);
    }
    return uVar8;
code_r0x0001801abf10:
    cVar5 = pcVar11[1];
    pcVar11 = pcVar11 + 1;
    if (cVar5 == '\0') goto code_r0x0001801ac037;
    goto code_r0x0001801abf04;
}

// ============================================================
// Function: FUN_1801abe2a
// Address: 0x1801abe2a
// Size: 785 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1801abdc0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h,
                      int64_t arg_98h, int64_t arg_a0h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    char cVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int64_t in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    char *pcVar11;
    undefined8 unaff_RSI;
    uint64_t uVar12;
    int64_t *in_R8;
    int64_t *in_R9;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801abdde;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar10 = 0;
    uVar12 = 0;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abdf6;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abe0e;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                      *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abe20;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar7));
        uVar8 = 0;
    } else {
        *(undefined8 *)((int64_t)&arg_98h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_a0h + iVar7) = unaff_RSI;
        _var_68h = ZEXT816(0);
        _var_28h = ZEXT812(1);
        uStack_20._4_4_ = 0;
        var_38h = 0;
        var_30h = 0;
        var_70h = 0x20;
        var_78h = in_RCX;
        var_58h = 0x20;
        var_50h = 0;
        var_48h = 0;
        var_40h = 0x20;
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abe95;
        iVar9 = fcn.180224ed0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
        uVar8 = uVar10;
        var_60h = iVar9;
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abebd;
            var_48h = fcn.180224ed0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
            if ((undefined8 *)var_48h != (undefined8 *)0x0) {
                *(undefined8 *)var_48h = 0;
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abee8;
                var_30h = fcn.180224ed0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                if (var_30h != 0) {
                    cVar5 = *(char *)arg_40h;
                    pcVar11 = (char *)arg_40h;
                    if (cVar5 != '\0') {
code_r0x0001801abf04:
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abf0c;
                        iVar6 = func_0x00018046ce40(cVar5);
                        if (iVar6 != 0) goto code_r0x0001801abf10;
                        if (*pcVar11 != '\0') {
                            *(int64_t **)((int64_t)&iStackX_10 + iVar7 + -8) = &var_78h;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abf4c;
                            iVar6 = func_0x00018024a850(pcVar11, 0x2f, 1, 0x1801ade20);
                            uVar8 = uVar12;
                            if (iVar6 != 0) {
                                if (iVar6 == -1) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abf5e;
                                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_10 + iVar7));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abf76;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar7), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar7), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar7));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abf8f;
                                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar7));
                                } else {
                                    uVar12 = uVar10;
                                    if (var_50h != 0) {
                                        do {
                                            iVar9 = *(int64_t *)(var_48h + uVar10 * 8);
                                            if (iVar9 != 0) {
                                                if (uVar10 != uVar12) {
                                                    *(int64_t *)(var_48h + uVar12 * 8) = iVar9;
                                                }
                                                uVar12 = uVar12 + 1;
                                            }
                                            uVar10 = uVar10 + 1;
                                        } while (uVar10 < (uint64_t)var_50h);
                                    }
                                    var_50h = uVar12;
                                    if ((uint64_t)var_38h < 5) {
                                        if ((var_68h != 0) && (var_38h == 0)) {
                                            var_38h = 1;
                                            *(undefined2 *)var_30h = 0;
                                        }
                                        goto code_r0x0001801ac037;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abfdf;
                                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_10 + iVar7));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abff7;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar7), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar7), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar7));
                                    *(undefined4 *)((int64_t)&iStackX_10 + iVar7 + -8) = 4;
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801ac018;
                                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar7));
                                }
                            }
                            goto code_r0x0001801ac0e7;
                        }
                    }
code_r0x0001801ac037:
                    iVar4 = arg_38h;
                    iVar3 = arg_30h;
                    iVar9 = arg_28h;
                    if ((((in_RDX != (int64_t *)0x0) && (in_R9 != (int64_t *)0x0)) && (arg_30h != 0)) &&
                       (((in_R8 != (int64_t *)0x0 && (arg_28h != 0)) && (arg_38h != 0)))) {
                        iVar1 = *in_RDX;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801ac086;
                        fcn.180224990(iVar1, 0x1804aeee0, 0x6a2);
                        *in_RDX = var_60h;
                        *in_R8 = var_68h;
                        iVar1 = *in_R9;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801ac0aa;
                        fcn.180224990(iVar1, 0x1804aeee0, 0x6a5);
                        *in_R9 = var_30h;
                        *(int64_t *)iVar9 = var_38h;
                        uVar2 = *(undefined8 *)iVar3;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801ac0cd;
                        fcn.180224990(uVar2, 0x1804aeee0, 0x6a8);
                        *(int64_t *)iVar3 = var_48h;
                        *(int64_t *)iVar4 = var_50h;
                        return 1;
                    }
                    uVar8 = 1;
                }
            }
        }
code_r0x0001801ac0e7:
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801ac0fd;
        fcn.180224990(var_60h, 0x1804aeee0, 0x6af);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801ac113;
        fcn.180224990(var_48h, 0x1804aeee0, 0x6b0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801ac129;
        fcn.180224990(var_30h, 0x1804aeee0, 0x6b1);
    }
    return uVar8;
code_r0x0001801abf10:
    cVar5 = pcVar11[1];
    pcVar11 = pcVar11 + 1;
    if (cVar5 == '\0') goto code_r0x0001801ac037;
    goto code_r0x0001801abf04;
}

// ============================================================
// Function: FUN_1801ac13b
// Address: 0x1801ac13b
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1801abdc0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h,
                      int64_t arg_98h, int64_t arg_a0h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    char cVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int64_t in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    char *pcVar11;
    undefined8 unaff_RSI;
    uint64_t uVar12;
    int64_t *in_R8;
    int64_t *in_R9;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801abdde;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar10 = 0;
    uVar12 = 0;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abdf6;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abe0e;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                      *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abe20;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar7));
        uVar8 = 0;
    } else {
        *(undefined8 *)((int64_t)&arg_98h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_a0h + iVar7) = unaff_RSI;
        _var_68h = ZEXT816(0);
        _var_28h = ZEXT812(1);
        uStack_20._4_4_ = 0;
        var_38h = 0;
        var_30h = 0;
        var_70h = 0x20;
        var_78h = in_RCX;
        var_58h = 0x20;
        var_50h = 0;
        var_48h = 0;
        var_40h = 0x20;
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abe95;
        iVar9 = fcn.180224ed0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
        uVar8 = uVar10;
        var_60h = iVar9;
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abebd;
            var_48h = fcn.180224ed0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
            if ((undefined8 *)var_48h != (undefined8 *)0x0) {
                *(undefined8 *)var_48h = 0;
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abee8;
                var_30h = fcn.180224ed0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                if (var_30h != 0) {
                    cVar5 = *(char *)arg_40h;
                    pcVar11 = (char *)arg_40h;
                    if (cVar5 != '\0') {
code_r0x0001801abf04:
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abf0c;
                        iVar6 = func_0x00018046ce40(cVar5);
                        if (iVar6 != 0) goto code_r0x0001801abf10;
                        if (*pcVar11 != '\0') {
                            *(int64_t **)((int64_t)&iStackX_10 + iVar7 + -8) = &var_78h;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abf4c;
                            iVar6 = func_0x00018024a850(pcVar11, 0x2f, 1, 0x1801ade20);
                            uVar8 = uVar12;
                            if (iVar6 != 0) {
                                if (iVar6 == -1) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abf5e;
                                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_10 + iVar7));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abf76;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar7), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar7), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar7));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abf8f;
                                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar7));
                                } else {
                                    uVar12 = uVar10;
                                    if (var_50h != 0) {
                                        do {
                                            iVar9 = *(int64_t *)(var_48h + uVar10 * 8);
                                            if (iVar9 != 0) {
                                                if (uVar10 != uVar12) {
                                                    *(int64_t *)(var_48h + uVar12 * 8) = iVar9;
                                                }
                                                uVar12 = uVar12 + 1;
                                            }
                                            uVar10 = uVar10 + 1;
                                        } while (uVar10 < (uint64_t)var_50h);
                                    }
                                    var_50h = uVar12;
                                    if ((uint64_t)var_38h < 5) {
                                        if ((var_68h != 0) && (var_38h == 0)) {
                                            var_38h = 1;
                                            *(undefined2 *)var_30h = 0;
                                        }
                                        goto code_r0x0001801ac037;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abfdf;
                                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_10 + iVar7));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801abff7;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar7), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar7), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar7));
                                    *(undefined4 *)((int64_t)&iStackX_10 + iVar7 + -8) = 4;
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801ac018;
                                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar7));
                                }
                            }
                            goto code_r0x0001801ac0e7;
                        }
                    }
code_r0x0001801ac037:
                    iVar4 = arg_38h;
                    iVar3 = arg_30h;
                    iVar9 = arg_28h;
                    if ((((in_RDX != (int64_t *)0x0) && (in_R9 != (int64_t *)0x0)) && (arg_30h != 0)) &&
                       (((in_R8 != (int64_t *)0x0 && (arg_28h != 0)) && (arg_38h != 0)))) {
                        iVar1 = *in_RDX;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801ac086;
                        fcn.180224990(iVar1, 0x1804aeee0, 0x6a2);
                        *in_RDX = var_60h;
                        *in_R8 = var_68h;
                        iVar1 = *in_R9;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801ac0aa;
                        fcn.180224990(iVar1, 0x1804aeee0, 0x6a5);
                        *in_R9 = var_30h;
                        *(int64_t *)iVar9 = var_38h;
                        uVar2 = *(undefined8 *)iVar3;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801ac0cd;
                        fcn.180224990(uVar2, 0x1804aeee0, 0x6a8);
                        *(int64_t *)iVar3 = var_48h;
                        *(int64_t *)iVar4 = var_50h;
                        return 1;
                    }
                    uVar8 = 1;
                }
            }
        }
code_r0x0001801ac0e7:
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801ac0fd;
        fcn.180224990(var_60h, 0x1804aeee0, 0x6af);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801ac113;
        fcn.180224990(var_48h, 0x1804aeee0, 0x6b0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801ac129;
        fcn.180224990(var_30h, 0x1804aeee0, 0x6b1);
    }
    return uVar8;
code_r0x0001801abf10:
    cVar5 = pcVar11[1];
    pcVar11 = pcVar11 + 1;
    if (cVar5 == '\0') goto code_r0x0001801ac037;
    goto code_r0x0001801abf04;
}

// ============================================================
// Function: FUN_1801ac160
// Address: 0x1801ac160
// Size: 86 bytes
// ============================================================
undefined8 fcn.1801ac160(int64_t arg_28h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ac16c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801ac186;
    iVar2 = fcn.1801a2080(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar1));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801ac197;
        iVar1 = fcn.1801ab3e0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar1));
        if (iVar1 != 0) {
            *(int64_t *)(in_RCX + 0x400) = iVar1;
            return 1;
        }
    }
    return 0;
}

