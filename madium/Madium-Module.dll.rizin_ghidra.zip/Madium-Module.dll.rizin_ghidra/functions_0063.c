// Chunk 63 - 50 functions

// ============================================================
// Function: FUN_1800cb240
// Address: 0x1800cb240
// Size: 28 bytes
// ============================================================
undefined fcn.1800cb240(int64_t arg1, int64_t arg2)
{
    int64_t in_stack_00000070;
    
    fcn.1800cb060(in_stack_00000070);
    return 1;
}

// ============================================================
// Function: FUN_1800cb260
// Address: 0x1800cb260
// Size: 689 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_90h
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_80h

uint64_t fcn.1800cb260(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                      int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    bool bVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t **ppiVar6;
    int32_t *piVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    undefined8 *puVar11;
    int64_t *piVar12;
    int64_t unaff_RDI;
    int64_t *piVar13;
    int64_t var_10h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    
    puVar11 = *(undefined8 **)(arg2 + 0x38);
    puVar1 = puVar11 + *(int64_t *)(arg2 + 0x40);
    for (; puVar11 != puVar1; puVar11 = puVar11 + 1) {
        (***(code ***)(undefined8 *)*puVar11)((undefined8 *)*puVar11, arg1);
    }
    piVar13 = (int64_t *)0x0;
    if ((*(int64_t *)(arg2 + 0x30) != 2) || (*(int64_t *)(arg2 + 0x40) != 1)) goto code_r0x0001800cb3e2;
    piVar12 = **(int64_t ***)(arg2 + 0x38);
    piVar10 = piVar13;
    if (*(int32_t *)(piVar12 + 1) == *(int32_t *)0x180782740) {
        piVar10 = piVar12;
    }
    if ((piVar10 == (int64_t *)0x0) || (piVar10[8] != 1)) {
code_r0x0001800cb3ac:
        iVar5 = func_0x0001800cae90(arg1, piVar12);
    } else {
        piVar9 = piVar13;
        if (*(int32_t *)((int64_t *)piVar10[4] + 1) == *(int32_t *)0x180782738) {
            piVar9 = (int64_t *)piVar10[4];
        }
        if (piVar9 == (int64_t *)0x0) goto code_r0x0001800cb3e2;
        piVar12 = *(int64_t **)piVar10[7];
        uVar2 = *(undefined8 *)(arg1 + 0x40);
        iVar5 = piVar9[4];
        iVar4 = func_0x0001800aa2c0(uVar2);
        if ((iVar4 == 0) && (piVar10 = piVar13, iVar5 != 0)) {
            do {
                piVar9 = (int64_t *)((int64_t)piVar10 + 1);
                if (*(char *)(iVar5 + (int64_t)piVar10) != *(char *)((int64_t)piVar10 + 0x180625d3c))
                goto code_r0x0001800cb348;
                piVar10 = piVar9;
            } while (piVar9 != (int64_t *)0x7);
            bVar3 = true;
        } else {
code_r0x0001800cb348:
            bVar3 = false;
        }
        if (!bVar3) {
            iVar4 = func_0x0001800aa2c0(uVar2);
            if ((iVar4 != 0) || (piVar10 = piVar13, iVar5 == 0)) goto code_r0x0001800cb3e2;
            do {
                piVar9 = (int64_t *)((int64_t)piVar10 + 1);
                if (*(char *)(iVar5 + (int64_t)piVar10) != *(char *)((int64_t)piVar10 + 0x180625f3c))
                goto code_r0x0001800cb3e2;
                piVar10 = piVar9;
            } while (piVar9 != (int64_t *)0x6);
            goto code_r0x0001800cb3ac;
        }
        iVar5 = func_0x0001800cae90(arg1, piVar12);
    }
    if (iVar5 != 0) {
        fcn.1800cb060(unaff_RDI);
        fcn.1800cb060(unaff_RDI);
    }
code_r0x0001800cb3e2:
    piVar12 = piVar13;
    if (*(int64_t *)(arg2 + 0x30) != 0) {
        do {
            iVar5 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + (int64_t)piVar12 * 8);
            piVar10 = *(int64_t **)(iVar5 + 0x38);
            if (piVar10 != (int64_t *)0x0) {
                piVar9 = piVar13;
                if (*(int32_t *)(piVar10 + 1) == *(int32_t *)0x1807826bc) {
                    piVar9 = piVar10;
                }
                var_10h = iVar5;
                if ((piVar9 != (int64_t *)0x0) && (*(char *)(piVar9 + 6) == '\0')) {
                    iVar5 = func_0x0001800ac7f0(arg1 + 0x58, piVar9 + 10);
                    piVar9 = (int64_t *)(iVar5 + 8);
                    if (iVar5 == 0) {
                        piVar9 = piVar13;
                    }
                    if ((piVar9 != (int64_t *)0x0) && (*piVar9 != 0)) {
                        piVar10 = *(int64_t **)(*piVar9 + 0x60);
                    }
                }
                ppiVar6 = (int64_t **)func_0x0001800cc970(arg1 + 0x98, &var_10h);
                *ppiVar6 = piVar10;
                _var_68h = ZEXT816(0);
                _var_58h = ZEXT816(0);
                var_78h = 0;
                var_70h = 0;
                iVar4 = func_0x0001800ca210(piVar10, &var_78h, arg1 + 0x58, 1, *(undefined8 *)(arg1 + 0x20), 
                                            *(undefined8 *)(arg1 + 0x28), *(undefined8 *)(arg1 + 0x50), &var_68h);
                if (iVar4 != 0xf) {
                    piVar7 = (int32_t *)func_0x0001800ac540(*(undefined8 *)(arg1 + 0x10), &var_10h);
                    *piVar7 = iVar4;
                }
                if (var_68h != 0) {
                    func_0x0001800f4640();
                }
            }
            piVar12 = (int64_t *)((int64_t)piVar12 + 1);
        } while (piVar12 < *(int64_t **)(arg2 + 0x30));
    }
    uVar8 = (**(code **)**(undefined8 **)(arg2 + 0x48))(*(undefined8 **)(arg2 + 0x48), arg1);
    return uVar8 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800cb520
// Address: 0x1800cb520
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800cb520(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 *puVar3;
    int64_t iVar4;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 0x68);
    if (iVar1 != 0) {
        iVar4 = 0;
        if (*(int32_t *)(iVar1 + 8) == *(int32_t *)0x18078268c) {
            iVar4 = iVar1;
        }
        if ((iVar4 != 0) && (*(int64_t *)(iVar4 + 0x28) != 0)) {
            uVar2 = **(undefined8 **)(iVar4 + 0x20);
            puVar3 = (undefined8 *)fcn.1800cc970(arg1 + 0xe8, arg2 + 0x28);
            *puVar3 = uVar2;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1800cb556
// Address: 0x1800cb556
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800cb520(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 *puVar3;
    int64_t iVar4;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 0x68);
    if (iVar1 != 0) {
        iVar4 = 0;
        if (*(int32_t *)(iVar1 + 8) == *(int32_t *)0x18078268c) {
            iVar4 = iVar1;
        }
        if ((iVar4 != 0) && (*(int64_t *)(iVar4 + 0x28) != 0)) {
            uVar2 = **(undefined8 **)(iVar4 + 0x20);
            puVar3 = (undefined8 *)fcn.1800cc970(arg1 + 0xe8, arg2 + 0x28);
            *puVar3 = uVar2;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1800cb572
// Address: 0x1800cb572
// Size: 7 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800cb520(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 *puVar3;
    int64_t iVar4;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 0x68);
    if (iVar1 != 0) {
        iVar4 = 0;
        if (*(int32_t *)(iVar1 + 8) == *(int32_t *)0x18078268c) {
            iVar4 = iVar1;
        }
        if ((iVar4 != 0) && (*(int64_t *)(iVar4 + 0x28) != 0)) {
            uVar2 = **(undefined8 **)(iVar4 + 0x20);
            puVar3 = (undefined8 *)fcn.1800cc970(arg1 + 0xe8, arg2 + 0x28);
            *puVar3 = uVar2;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1800cb580
// Address: 0x1800cb580
// Size: 1509 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800cb580(int64_t arg1, int64_t arg2)
{
    undefined2 *puVar1;
    char *pcVar2;
    undefined *puVar3;
    uint64_t *puVar4;
    int64_t iVar5;
    code *pcVar6;
    undefined auVar7 [16];
    undefined auVar8 [16];
    bool bVar9;
    undefined auVar10 [16];
    undefined auVar11 [16];
    int64_t iVar12;
    int32_t iVar13;
    int64_t *piVar14;
    int64_t *piVar15;
    int64_t iVar16;
    int64_t iVar17;
    uint64_t uVar18;
    uint64_t uVar19;
    uint64_t uVar20;
    uint64_t uVar21;
    uint64_t uVar22;
    char cVar23;
    undefined *puVar24;
    undefined *puVar25;
    int64_t *piVar26;
    uint64_t *puVar27;
    uint64_t uVar28;
    undefined4 uVar29;
    undefined4 uVar30;
    undefined4 uVar31;
    undefined4 uVar32;
    int64_t var_18h;
    undefined8 uStack_120;
    undefined auStack_118 [8];
    undefined auStack_110 [24];
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    undefined4 uStack_70;
    undefined4 uStack_6c;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    
    puVar25 = auStack_118;
    puVar24 = auStack_118;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_118;
    iVar17 = *(int64_t *)(arg1 + 0x50);
    iVar16 = *(int64_t *)(arg1 + 0x28);
    var_d0h = *(int64_t *)(arg1 + 0x20);
    iVar5 = *(int64_t *)(arg2 + 0x50);
    var_88h = 0;
    var_80h = 0xf;
    stack0xffffffffffffff69 = SUB1615(ZEXT816(0), 1);
    auVar8[15] = 0;
    auVar8._0_15_ = stack0xffffffffffffff69;
    _var_98h = auVar8 << 8;
    var_c8h = arg2;
    func_0x00018000b240(&var_98h, *(int64_t *)(arg2 + 0x60) + 2 + (uint64_t)(iVar5 != 0));
    if ((uint64_t)var_88h < (uint64_t)var_80h) {
        piVar14 = &var_98h;
        if (0xf < (uint64_t)var_80h) {
            piVar14 = (int64_t *)var_98h;
        }
        puVar1 = (undefined2 *)((int64_t)piVar14 + var_88h);
        var_88h = var_88h + 1;
        *puVar1 = 5;
    } else {
        func_0x00018000f010(&var_98h, 1, (undefined)var_d8h, 5);
    }
    iVar12 = var_88h;
    cVar23 = (iVar5 != 0) + *(char *)(arg2 + 0x60);
    if ((uint64_t)var_88h < (uint64_t)var_80h) {
        piVar14 = &var_98h;
        if (0xf < (uint64_t)var_80h) {
            piVar14 = (int64_t *)var_98h;
        }
        pcVar2 = (char *)((int64_t)piVar14 + var_88h);
        var_88h = var_88h + 1;
        *pcVar2 = cVar23;
        *(undefined *)((int64_t)piVar14 + iVar12 + 1) = 0;
    } else {
        func_0x00018000f010(&var_98h, 1, (undefined)var_d8h, cVar23);
    }
    if (iVar5 != 0) {
        if ((uint64_t)var_88h < (uint64_t)var_80h) {
            piVar14 = &var_98h;
            if (0xf < (uint64_t)var_80h) {
                piVar14 = (int64_t *)var_98h;
            }
            puVar1 = (undefined2 *)((int64_t)piVar14 + var_88h);
            var_88h = var_88h + 1;
            *puVar1 = 4;
        } else {
            func_0x00018000f010(&var_98h, 1, (undefined)var_d8h, 4);
        }
    }
    bVar9 = false;
    piVar26 = *(int64_t **)(arg2 + 0x58);
    piVar14 = piVar26 + *(int64_t *)(arg2 + 0x60);
    if (piVar26 == piVar14) {
code_r0x0001800cb7d6:
        iVar17 = 0;
        var_d0h = 0xf;
        _var_68h = ZEXT816(0xf) << 0x40;
        stack0xffffffffffffff89 = SUB1615(ZEXT816(0), 1);
        auVar10[15] = 0;
        auVar10._0_15_ = stack0xffffffffffffff89;
        _var_78h = auVar10 << 8;
        if ((uint64_t)var_80h < 0x10) {
code_r0x0001800cb82f:
            uVar29 = (undefined4)var_68h;
            uVar30 = var_68h._4_4_;
            uVar31 = (undefined4)var_60h;
            uVar32 = var_60h._4_4_;
            goto code_r0x0001800cb833;
        }
        iVar16 = var_98h;
        if ((var_80h + 1U < 0x1000) || (iVar16 = *(int64_t *)(var_98h + -8), (var_98h - iVar16) - 8U < 0x20)) {
            func_0x000180459c3c(iVar16);
            goto code_r0x0001800cb82f;
        }
code_r0x0001800cbb25:
        pcVar6 = (code *)swi(0x29);
        iVar17 = (*pcVar6)(5);
        puVar25 = puVar25 + 8;
    } else {
        do {
            var_c0h = 0;
            var_b8h = 0;
            var_b0h = 0;
            var_a8h = 0;
            if (*(int64_t *)(*piVar26 + 0x38) == 0) {
                iVar13 = 0xf;
            } else {
                var_e0h = (int64_t)&var_c0h;
                var_f8h = var_d0h;
                var_f0h = iVar16;
                var_e8h = iVar17;
                iVar13 = func_0x0001800ca210(*(int64_t *)(*piVar26 + 0x38), var_c8h + 0x30, arg1 + 0x58, 1);
                if (iVar13 != 0xf) {
                    bVar9 = true;
                }
            }
            iVar5 = var_88h;
            if ((uint64_t)var_88h < (uint64_t)var_80h) {
                piVar15 = &var_98h;
                if (0xf < (uint64_t)var_80h) {
                    piVar15 = (int64_t *)var_98h;
                }
                puVar3 = (undefined *)((int64_t)piVar15 + var_88h);
                var_88h = var_88h + 1;
                *puVar3 = (char)iVar13;
                *(undefined *)((int64_t)piVar15 + iVar5 + 1) = 0;
            } else {
                func_0x00018000f010(&var_98h, 1, (undefined)var_d8h);
            }
            if (var_c0h != 0) {
                func_0x0001800f4640();
            }
            piVar26 = piVar26 + 1;
        } while (piVar26 != piVar14);
        if (!bVar9) goto code_r0x0001800cb7d6;
        _var_78h = _var_98h;
        unique0x100004ce = var_80h;
        var_68h = var_88h;
        var_d0h = var_80h;
        iVar17 = var_88h;
        uVar29 = (int32_t)var_88h;
        uVar30 = (int32_t)((uint64_t)var_88h >> 0x20);
        uVar31 = (int32_t)var_80h;
        uVar32 = (int32_t)((uint64_t)var_80h >> 0x20);
code_r0x0001800cb833:
        uVar18 = var_d0h;
        puVar25 = auStack_118;
        if (iVar17 != 0) {
            piVar14 = *(int64_t **)(arg1 + 8);
            iVar17 = piVar14[1];
            if ((uint64_t)(iVar17 * 3) >> 2 <= (uint64_t)piVar14[2]) {
                if ((piVar14[2] != 0) && (var_c8h != piVar14[3])) {
                    uVar18 = ((uint64_t)var_c8h >> 5 ^ var_c8h) >> 4;
                    uVar20 = 0;
                    do {
                        uVar18 = uVar18 & iVar17 - 1U;
                        iVar16 = *(int64_t *)(*piVar14 + uVar18 * 0x28);
                        if (iVar16 == var_c8h) goto code_r0x0001800cba38;
                        if (iVar16 == piVar14[3]) break;
                        uVar18 = uVar18 + 1 + uVar20;
                        uVar20 = uVar20 + 1;
                    } while (uVar20 <= iVar17 - 1U);
                }
                puVar4 = (uint64_t *)(piVar14 + 3);
                uVar18 = *puVar4;
                if (iVar17 == 0) {
                    uVar20 = 0x10;
                    iVar16 = func_0x000180459890(0x280);
                    uVar21 = 0;
                    uVar28 = 0x10;
                    iVar17 = iVar16;
code_r0x0001800cb920:
                    do {
                        iVar5 = uVar21 * 0x28;
                        *(uint64_t *)(iVar5 + iVar16) = *puVar4;
                        *(undefined (*) [16])(iVar5 + 8 + iVar16) = ZEXT816(0);
                        *(undefined8 *)(iVar5 + 0x18 + iVar16) = 0;
                        *(undefined8 *)(iVar5 + 0x20 + iVar16) = 0xf;
                        *(undefined *)(iVar5 + 8 + iVar16) = 0;
                        uVar21 = uVar21 + 1;
                    } while (uVar21 < uVar20);
                } else {
                    uVar20 = iVar17 * 2;
                    if (uVar20 == 0) {
                        uVar28 = 0;
                        iVar17 = 0;
                    } else {
                        iVar16 = func_0x000180459890(iVar17 * 0x50);
                        uVar21 = 0;
                        uVar28 = uVar20;
                        iVar17 = iVar16;
                        if (uVar20 != 0) goto code_r0x0001800cb920;
                    }
                }
                uVar21 = 0;
                uVar20 = piVar14[1];
                if (uVar20 != 0) {
                    do {
                        uVar20 = *(uint64_t *)(uVar21 * 0x28 + *piVar14);
                        if (uVar20 != *puVar4) {
                            uVar19 = (uVar20 >> 5 ^ uVar20) >> 4;
                            uVar22 = 0;
                            do {
                                uVar19 = uVar19 & uVar28 - 1;
                                puVar27 = (uint64_t *)(iVar17 + uVar19 * 0x28);
                                if (*puVar27 == uVar18) {
                                    *puVar27 = uVar20;
                                    goto code_r0x0001800cb9ce;
                                }
                                if (*puVar27 == uVar20) goto code_r0x0001800cb9ce;
                                uVar19 = uVar19 + 1 + uVar22;
                                uVar22 = uVar22 + 1;
                            } while (uVar22 <= uVar28 - 1);
                            puVar27 = (uint64_t *)0x0;
code_r0x0001800cb9ce:
                            *puVar27 = *(uint64_t *)(*piVar14 + uVar21 * 0x28);
                            func_0x000180012c10(puVar27 + 1);
                        }
                        uVar21 = uVar21 + 1;
                        uVar20 = piVar14[1];
                    } while (uVar21 < uVar20);
                }
                iVar16 = *piVar14;
                *piVar14 = iVar17;
                piVar14[1] = uVar28;
                if (iVar16 != 0) {
                    uVar18 = 0;
                    if (uVar20 != 0) {
                        do {
                            func_0x000180004e40(iVar16 + (uVar18 * 5 + 1) * 8);
                            uVar18 = uVar18 + 1;
                        } while (uVar18 < uVar20);
                    }
                    func_0x0001800f4640(iVar16);
                }
            }
code_r0x0001800cba38:
            uVar18 = ((uint64_t)var_c8h >> 5 ^ var_c8h) >> 4;
            uVar20 = 0;
            do {
                uVar18 = uVar18 & piVar14[1] - 1U;
                piVar26 = (int64_t *)(*piVar14 + uVar18 * 0x28);
                if (*piVar26 == piVar14[3]) {
                    *piVar26 = var_c8h;
                    piVar14[2] = piVar14[2] + 1;
                    goto code_r0x0001800cba92;
                }
                if (*piVar26 == var_c8h) goto code_r0x0001800cba92;
                uVar18 = uVar18 + 1 + uVar20;
                uVar20 = uVar20 + 1;
            } while (uVar20 <= piVar14[1] - 1U);
            piVar26 = (int64_t *)0x0;
code_r0x0001800cba92:
            piVar14 = piVar26 + 1;
            uVar18 = var_d0h;
            puVar25 = auStack_118;
            if (piVar14 != &var_78h) {
                if (0xf < (uint64_t)piVar26[4]) {
                    iVar17 = *piVar14;
                    iVar16 = iVar17;
                    puVar24 = auStack_118;
                    if ((0xfff < piVar26[4] + 1U) &&
                       (iVar16 = *(int64_t *)(iVar17 + -8), puVar24 = auStack_118, 0x1f < (iVar17 - iVar16) - 8U)) {
                        pcVar6 = (code *)swi(0x29);
                        iVar16 = (*pcVar6)(5);
                        puVar24 = auStack_110;
                    }
                    *(undefined8 *)(puVar24 + -8) = 0x1800cbade;
                    func_0x000180459c3c(iVar16);
                }
                *(undefined4 *)piVar14 = (undefined4)var_78h;
                *(undefined4 *)((int64_t)piVar26 + 0xc) = var_78h._4_4_;
                *(undefined4 *)(piVar26 + 2) = uStack_70;
                *(undefined4 *)((int64_t)piVar26 + 0x14) = uStack_6c;
                auVar7._4_4_ = uVar30;
                auVar7._0_4_ = uVar29;
                auVar7._8_4_ = uVar31;
                auVar7._12_4_ = uVar32;
                *(undefined (*) [16])(piVar26 + 3) = auVar7;
                auVar11[15] = 0;
                auVar11._0_15_ = stack0xffffffffffffff89;
                _var_78h = auVar11 << 8;
                uVar18 = 0xf;
                puVar25 = puVar24;
            }
        }
        if (uVar18 < 0x10) goto code_r0x0001800cbb34;
        iVar17 = var_78h;
        if ((0xfff < uVar18 + 1) && (iVar17 = *(int64_t *)(var_78h + -8), 0x1f < (var_78h - iVar17) - 8U))
        goto code_r0x0001800cbb25;
    }
    *(undefined8 *)(puVar25 + -8) = 0x1800cbb34;
    func_0x000180459c3c(iVar17);
code_r0x0001800cbb34:
    *(undefined8 *)(puVar25 + -8) = 0x1800cbb42;
    func_0x000180459870(var_58h ^ (uint64_t)puVar25);
    return;
}

// ============================================================
// Function: FUN_1800cbb70
// Address: 0x1800cbb70
// Size: 254 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1800cbb70(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int32_t *in_RAX;
    uint64_t uVar2;
    int32_t **ppiVar3;
    uint64_t uVar4;
    int32_t **ppiVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    var_10h = *(int64_t *)(arg2 + 0x20);
    if (*(int64_t *)(var_10h + 0x38) == 0) {
        if ((*(int64_t *)(arg1 + 0xa8) == 0) || ((int32_t *)var_10h == *(int32_t **)(arg1 + 0xb0)))
        goto code_r0x0001800cbc5c;
        uVar6 = *(int64_t *)(arg1 + 0xa0) - 1;
        uVar2 = ((uint64_t)var_10h >> 5 ^ var_10h) >> 4;
        uVar4 = 0;
        while( true ) {
            uVar2 = uVar2 & uVar6;
            ppiVar5 = (int32_t **)(uVar2 * 0x10 + *(int64_t *)(arg1 + 0x98));
            in_RAX = *ppiVar5;
            if (in_RAX == (int32_t *)var_10h) break;
            if (in_RAX == *(int32_t **)(arg1 + 0xb0)) goto code_r0x0001800cbc5c;
            uVar2 = uVar2 + 1 + uVar4;
            uVar4 = uVar4 + 1;
            if (uVar6 < uVar4) {
                return (uint64_t)in_RAX & 0xffffffffffffff00;
            }
        }
        ppiVar3 = ppiVar5 + 1;
        if (ppiVar5 == (int32_t **)0x0) {
            ppiVar3 = (int32_t **)0x0;
        }
        if (ppiVar3 == (int32_t **)0x0) {
            return 0;
        }
        iVar1 = func_0x0001800caf50(arg1, arg2, *ppiVar3);
    } else {
        in_RAX = (int32_t *)func_0x0001800caf50();
        iVar1 = (int32_t)in_RAX;
        if (iVar1 == 0xf) goto code_r0x0001800cbc5c;
    }
    in_RAX = (int32_t *)func_0x0001800ac540(*(undefined8 *)(arg1 + 0x10), &var_10h);
    *in_RAX = iVar1;
code_r0x0001800cbc5c:
    return (uint64_t)in_RAX & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800cbc70
// Address: 0x1800cbc70
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

uint64_t fcn.1800cbc70(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                      int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_68h)
{
    undefined8 *puVar1;
    int64_t *piVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t *puVar9;
    uint64_t uVar10;
    undefined8 *puVar11;
    int64_t iVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar11 = *(undefined8 **)(arg2 + 0x38);
    uVar5 = *(uint64_t *)(arg2 + 0x40);
    puVar1 = puVar11 + uVar5;
    for (; puVar11 != puVar1; puVar11 = puVar11 + 1) {
        uVar5 = (***(code ***)(undefined8 *)*puVar11)((undefined8 *)*puVar11, arg1);
    }
    var_18h = 0;
    if (*(int64_t *)(arg2 + 0x30) != 0) {
        do {
            uVar5 = *(uint64_t *)(arg2 + 0x28);
            uVar3 = *(uint64_t *)(uVar5 + var_18h * 8);
            if ((*(int64_t *)(uVar3 + 0x38) == 0) && ((uint64_t)var_18h < *(uint64_t *)(arg2 + 0x40))) {
                uVar5 = func_0x0001800ac7f0(arg1 + 0xc0, *(int64_t *)(arg2 + 0x38) + var_18h * 8);
                puVar9 = (uint64_t *)(uVar5 + 8);
                if (uVar5 == 0) {
                    puVar9 = (uint64_t *)0x0;
                }
                if (puVar9 != (uint64_t *)0x0) {
                    uVar4 = *puVar9;
                    piVar2 = (int64_t *)(arg1 + 0x98);
                    iVar6 = *(int64_t *)(arg1 + 0xa0);
                    if ((uint64_t)(iVar6 * 3) >> 2 <= *(uint64_t *)(arg1 + 0xa8)) {
                        if ((*(uint64_t *)(arg1 + 0xa8) != 0) && (uVar3 != *(uint64_t *)(arg1 + 0xb0))) {
                            uVar5 = (uVar3 >> 5 ^ uVar3) >> 4;
                            uVar7 = 0;
                            do {
                                uVar5 = uVar5 & iVar6 - 1U;
                                uVar10 = *(uint64_t *)(*piVar2 + uVar5 * 0x10);
                                if (uVar10 == uVar3) goto code_r0x0001800cbebe;
                                if (uVar10 == *(uint64_t *)(arg1 + 0xb0)) break;
                                uVar5 = uVar5 + 1 + uVar7;
                                uVar7 = uVar7 + 1;
                            } while (uVar7 <= iVar6 - 1U);
                        }
                        uVar5 = *(uint64_t *)(arg1 + 0xb0);
                        if (iVar6 == 0) {
                            uVar7 = 0x10;
                            iVar6 = func_0x000180459890(0x100);
                            uVar14 = 0;
                            iVar12 = iVar6;
                            uVar10 = 0x10;
code_r0x0001800cbdf0:
                            do {
                                uVar8 = uVar14 + 1;
                                *(uint64_t *)(iVar12 + uVar14 * 0x10) = *(uint64_t *)(arg1 + 0xb0);
                                *(undefined8 *)(iVar12 + 8 + uVar14 * 0x10) = 0;
                                uVar14 = uVar8;
                            } while (uVar8 < uVar7);
                        } else {
                            uVar7 = iVar6 * 2;
                            if (uVar7 == 0) {
                                iVar6 = 0;
                                uVar10 = 0;
                            } else {
                                iVar6 = func_0x000180459890(iVar6 << 5);
                                uVar14 = 0;
                                iVar12 = iVar6;
                                uVar10 = uVar7;
                                if (uVar7 != 0) goto code_r0x0001800cbdf0;
                            }
                        }
                        uVar7 = 0;
                        if (*(int64_t *)(arg1 + 0xa0) != 0) {
                            do {
                                uVar14 = *(uint64_t *)(*piVar2 + uVar7 * 0x10);
                                if (uVar14 != *(uint64_t *)(arg1 + 0xb0)) {
                                    uVar8 = (uVar14 >> 5 ^ uVar14) >> 4;
                                    uVar13 = 0;
                                    do {
                                        uVar8 = uVar8 & uVar10 - 1;
                                        puVar9 = (uint64_t *)(uVar8 * 0x10 + iVar6);
                                        if (*puVar9 == uVar5) {
                                            *puVar9 = uVar14;
                                            goto code_r0x0001800cbe7f;
                                        }
                                        if (*puVar9 == uVar14) goto code_r0x0001800cbe7f;
                                        uVar8 = uVar8 + 1 + uVar13;
                                        uVar13 = uVar13 + 1;
                                    } while (uVar13 <= uVar10 - 1);
                                    puVar9 = (uint64_t *)0x0;
code_r0x0001800cbe7f:
                                    iVar12 = *piVar2;
                                    *puVar9 = *(uint64_t *)(iVar12 + uVar7 * 0x10);
                                    puVar9[1] = *(uint64_t *)(iVar12 + 8 + uVar7 * 0x10);
                                }
                                uVar7 = uVar7 + 1;
                            } while (uVar7 < *(uint64_t *)(arg1 + 0xa0));
                        }
                        iVar12 = *piVar2;
                        *piVar2 = iVar6;
                        *(uint64_t *)(arg1 + 0xa0) = uVar10;
                        if (iVar12 != 0) {
                            func_0x0001800f4640();
                        }
                    }
code_r0x0001800cbebe:
                    uVar14 = *(int64_t *)(arg1 + 0xa0) - 1;
                    uVar7 = (uVar3 >> 5 ^ uVar3) >> 4;
                    uVar10 = 0;
                    do {
                        uVar7 = uVar7 & uVar14;
                        puVar9 = (uint64_t *)(uVar7 * 0x10 + *piVar2);
                        uVar5 = *puVar9;
                        if (uVar5 == *(uint64_t *)(arg1 + 0xb0)) {
                            *puVar9 = uVar3;
                            *(int64_t *)(arg1 + 0xa8) = *(int64_t *)(arg1 + 0xa8) + 1;
                            goto code_r0x0001800cbf28;
                        }
                        if (uVar5 == uVar3) goto code_r0x0001800cbf28;
                        uVar7 = uVar7 + 1 + uVar10;
                        uVar10 = uVar10 + 1;
                    } while (uVar10 <= uVar14);
                    puVar9 = (uint64_t *)0x0;
code_r0x0001800cbf28:
                    puVar9[1] = uVar4;
                }
            }
            var_18h = var_18h + 1;
        } while ((uint64_t)var_18h < *(uint64_t *)(arg2 + 0x30));
    }
    return uVar5 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800cbcba
// Address: 0x1800cbcba
// Size: 664 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

uint64_t fcn.1800cbc70(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                      int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_68h)
{
    undefined8 *puVar1;
    int64_t *piVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t *puVar9;
    uint64_t uVar10;
    undefined8 *puVar11;
    int64_t iVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar11 = *(undefined8 **)(arg2 + 0x38);
    uVar5 = *(uint64_t *)(arg2 + 0x40);
    puVar1 = puVar11 + uVar5;
    for (; puVar11 != puVar1; puVar11 = puVar11 + 1) {
        uVar5 = (***(code ***)(undefined8 *)*puVar11)((undefined8 *)*puVar11, arg1);
    }
    var_18h = 0;
    if (*(int64_t *)(arg2 + 0x30) != 0) {
        do {
            uVar5 = *(uint64_t *)(arg2 + 0x28);
            uVar3 = *(uint64_t *)(uVar5 + var_18h * 8);
            if ((*(int64_t *)(uVar3 + 0x38) == 0) && ((uint64_t)var_18h < *(uint64_t *)(arg2 + 0x40))) {
                uVar5 = func_0x0001800ac7f0(arg1 + 0xc0, *(int64_t *)(arg2 + 0x38) + var_18h * 8);
                puVar9 = (uint64_t *)(uVar5 + 8);
                if (uVar5 == 0) {
                    puVar9 = (uint64_t *)0x0;
                }
                if (puVar9 != (uint64_t *)0x0) {
                    uVar4 = *puVar9;
                    piVar2 = (int64_t *)(arg1 + 0x98);
                    iVar6 = *(int64_t *)(arg1 + 0xa0);
                    if ((uint64_t)(iVar6 * 3) >> 2 <= *(uint64_t *)(arg1 + 0xa8)) {
                        if ((*(uint64_t *)(arg1 + 0xa8) != 0) && (uVar3 != *(uint64_t *)(arg1 + 0xb0))) {
                            uVar5 = (uVar3 >> 5 ^ uVar3) >> 4;
                            uVar7 = 0;
                            do {
                                uVar5 = uVar5 & iVar6 - 1U;
                                uVar10 = *(uint64_t *)(*piVar2 + uVar5 * 0x10);
                                if (uVar10 == uVar3) goto code_r0x0001800cbebe;
                                if (uVar10 == *(uint64_t *)(arg1 + 0xb0)) break;
                                uVar5 = uVar5 + 1 + uVar7;
                                uVar7 = uVar7 + 1;
                            } while (uVar7 <= iVar6 - 1U);
                        }
                        uVar5 = *(uint64_t *)(arg1 + 0xb0);
                        if (iVar6 == 0) {
                            uVar7 = 0x10;
                            iVar6 = func_0x000180459890(0x100);
                            uVar14 = 0;
                            iVar12 = iVar6;
                            uVar10 = 0x10;
code_r0x0001800cbdf0:
                            do {
                                uVar8 = uVar14 + 1;
                                *(uint64_t *)(iVar12 + uVar14 * 0x10) = *(uint64_t *)(arg1 + 0xb0);
                                *(undefined8 *)(iVar12 + 8 + uVar14 * 0x10) = 0;
                                uVar14 = uVar8;
                            } while (uVar8 < uVar7);
                        } else {
                            uVar7 = iVar6 * 2;
                            if (uVar7 == 0) {
                                iVar6 = 0;
                                uVar10 = 0;
                            } else {
                                iVar6 = func_0x000180459890(iVar6 << 5);
                                uVar14 = 0;
                                iVar12 = iVar6;
                                uVar10 = uVar7;
                                if (uVar7 != 0) goto code_r0x0001800cbdf0;
                            }
                        }
                        uVar7 = 0;
                        if (*(int64_t *)(arg1 + 0xa0) != 0) {
                            do {
                                uVar14 = *(uint64_t *)(*piVar2 + uVar7 * 0x10);
                                if (uVar14 != *(uint64_t *)(arg1 + 0xb0)) {
                                    uVar8 = (uVar14 >> 5 ^ uVar14) >> 4;
                                    uVar13 = 0;
                                    do {
                                        uVar8 = uVar8 & uVar10 - 1;
                                        puVar9 = (uint64_t *)(uVar8 * 0x10 + iVar6);
                                        if (*puVar9 == uVar5) {
                                            *puVar9 = uVar14;
                                            goto code_r0x0001800cbe7f;
                                        }
                                        if (*puVar9 == uVar14) goto code_r0x0001800cbe7f;
                                        uVar8 = uVar8 + 1 + uVar13;
                                        uVar13 = uVar13 + 1;
                                    } while (uVar13 <= uVar10 - 1);
                                    puVar9 = (uint64_t *)0x0;
code_r0x0001800cbe7f:
                                    iVar12 = *piVar2;
                                    *puVar9 = *(uint64_t *)(iVar12 + uVar7 * 0x10);
                                    puVar9[1] = *(uint64_t *)(iVar12 + 8 + uVar7 * 0x10);
                                }
                                uVar7 = uVar7 + 1;
                            } while (uVar7 < *(uint64_t *)(arg1 + 0xa0));
                        }
                        iVar12 = *piVar2;
                        *piVar2 = iVar6;
                        *(uint64_t *)(arg1 + 0xa0) = uVar10;
                        if (iVar12 != 0) {
                            func_0x0001800f4640();
                        }
                    }
code_r0x0001800cbebe:
                    uVar14 = *(int64_t *)(arg1 + 0xa0) - 1;
                    uVar7 = (uVar3 >> 5 ^ uVar3) >> 4;
                    uVar10 = 0;
                    do {
                        uVar7 = uVar7 & uVar14;
                        puVar9 = (uint64_t *)(uVar7 * 0x10 + *piVar2);
                        uVar5 = *puVar9;
                        if (uVar5 == *(uint64_t *)(arg1 + 0xb0)) {
                            *puVar9 = uVar3;
                            *(int64_t *)(arg1 + 0xa8) = *(int64_t *)(arg1 + 0xa8) + 1;
                            goto code_r0x0001800cbf28;
                        }
                        if (uVar5 == uVar3) goto code_r0x0001800cbf28;
                        uVar7 = uVar7 + 1 + uVar10;
                        uVar10 = uVar10 + 1;
                    } while (uVar10 <= uVar14);
                    puVar9 = (uint64_t *)0x0;
code_r0x0001800cbf28:
                    puVar9[1] = uVar4;
                }
            }
            var_18h = var_18h + 1;
        } while ((uint64_t)var_18h < *(uint64_t *)(arg2 + 0x30));
    }
    return uVar5 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800cbf52
// Address: 0x1800cbf52
// Size: 12 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

uint64_t fcn.1800cbc70(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                      int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_68h)
{
    undefined8 *puVar1;
    int64_t *piVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t *puVar9;
    uint64_t uVar10;
    undefined8 *puVar11;
    int64_t iVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar11 = *(undefined8 **)(arg2 + 0x38);
    uVar5 = *(uint64_t *)(arg2 + 0x40);
    puVar1 = puVar11 + uVar5;
    for (; puVar11 != puVar1; puVar11 = puVar11 + 1) {
        uVar5 = (***(code ***)(undefined8 *)*puVar11)((undefined8 *)*puVar11, arg1);
    }
    var_18h = 0;
    if (*(int64_t *)(arg2 + 0x30) != 0) {
        do {
            uVar5 = *(uint64_t *)(arg2 + 0x28);
            uVar3 = *(uint64_t *)(uVar5 + var_18h * 8);
            if ((*(int64_t *)(uVar3 + 0x38) == 0) && ((uint64_t)var_18h < *(uint64_t *)(arg2 + 0x40))) {
                uVar5 = func_0x0001800ac7f0(arg1 + 0xc0, *(int64_t *)(arg2 + 0x38) + var_18h * 8);
                puVar9 = (uint64_t *)(uVar5 + 8);
                if (uVar5 == 0) {
                    puVar9 = (uint64_t *)0x0;
                }
                if (puVar9 != (uint64_t *)0x0) {
                    uVar4 = *puVar9;
                    piVar2 = (int64_t *)(arg1 + 0x98);
                    iVar6 = *(int64_t *)(arg1 + 0xa0);
                    if ((uint64_t)(iVar6 * 3) >> 2 <= *(uint64_t *)(arg1 + 0xa8)) {
                        if ((*(uint64_t *)(arg1 + 0xa8) != 0) && (uVar3 != *(uint64_t *)(arg1 + 0xb0))) {
                            uVar5 = (uVar3 >> 5 ^ uVar3) >> 4;
                            uVar7 = 0;
                            do {
                                uVar5 = uVar5 & iVar6 - 1U;
                                uVar10 = *(uint64_t *)(*piVar2 + uVar5 * 0x10);
                                if (uVar10 == uVar3) goto code_r0x0001800cbebe;
                                if (uVar10 == *(uint64_t *)(arg1 + 0xb0)) break;
                                uVar5 = uVar5 + 1 + uVar7;
                                uVar7 = uVar7 + 1;
                            } while (uVar7 <= iVar6 - 1U);
                        }
                        uVar5 = *(uint64_t *)(arg1 + 0xb0);
                        if (iVar6 == 0) {
                            uVar7 = 0x10;
                            iVar6 = func_0x000180459890(0x100);
                            uVar14 = 0;
                            iVar12 = iVar6;
                            uVar10 = 0x10;
code_r0x0001800cbdf0:
                            do {
                                uVar8 = uVar14 + 1;
                                *(uint64_t *)(iVar12 + uVar14 * 0x10) = *(uint64_t *)(arg1 + 0xb0);
                                *(undefined8 *)(iVar12 + 8 + uVar14 * 0x10) = 0;
                                uVar14 = uVar8;
                            } while (uVar8 < uVar7);
                        } else {
                            uVar7 = iVar6 * 2;
                            if (uVar7 == 0) {
                                iVar6 = 0;
                                uVar10 = 0;
                            } else {
                                iVar6 = func_0x000180459890(iVar6 << 5);
                                uVar14 = 0;
                                iVar12 = iVar6;
                                uVar10 = uVar7;
                                if (uVar7 != 0) goto code_r0x0001800cbdf0;
                            }
                        }
                        uVar7 = 0;
                        if (*(int64_t *)(arg1 + 0xa0) != 0) {
                            do {
                                uVar14 = *(uint64_t *)(*piVar2 + uVar7 * 0x10);
                                if (uVar14 != *(uint64_t *)(arg1 + 0xb0)) {
                                    uVar8 = (uVar14 >> 5 ^ uVar14) >> 4;
                                    uVar13 = 0;
                                    do {
                                        uVar8 = uVar8 & uVar10 - 1;
                                        puVar9 = (uint64_t *)(uVar8 * 0x10 + iVar6);
                                        if (*puVar9 == uVar5) {
                                            *puVar9 = uVar14;
                                            goto code_r0x0001800cbe7f;
                                        }
                                        if (*puVar9 == uVar14) goto code_r0x0001800cbe7f;
                                        uVar8 = uVar8 + 1 + uVar13;
                                        uVar13 = uVar13 + 1;
                                    } while (uVar13 <= uVar10 - 1);
                                    puVar9 = (uint64_t *)0x0;
code_r0x0001800cbe7f:
                                    iVar12 = *piVar2;
                                    *puVar9 = *(uint64_t *)(iVar12 + uVar7 * 0x10);
                                    puVar9[1] = *(uint64_t *)(iVar12 + 8 + uVar7 * 0x10);
                                }
                                uVar7 = uVar7 + 1;
                            } while (uVar7 < *(uint64_t *)(arg1 + 0xa0));
                        }
                        iVar12 = *piVar2;
                        *piVar2 = iVar6;
                        *(uint64_t *)(arg1 + 0xa0) = uVar10;
                        if (iVar12 != 0) {
                            func_0x0001800f4640();
                        }
                    }
code_r0x0001800cbebe:
                    uVar14 = *(int64_t *)(arg1 + 0xa0) - 1;
                    uVar7 = (uVar3 >> 5 ^ uVar3) >> 4;
                    uVar10 = 0;
                    do {
                        uVar7 = uVar7 & uVar14;
                        puVar9 = (uint64_t *)(uVar7 * 0x10 + *piVar2);
                        uVar5 = *puVar9;
                        if (uVar5 == *(uint64_t *)(arg1 + 0xb0)) {
                            *puVar9 = uVar3;
                            *(int64_t *)(arg1 + 0xa8) = *(int64_t *)(arg1 + 0xa8) + 1;
                            goto code_r0x0001800cbf28;
                        }
                        if (uVar5 == uVar3) goto code_r0x0001800cbf28;
                        uVar7 = uVar7 + 1 + uVar10;
                        uVar10 = uVar10 + 1;
                    } while (uVar10 <= uVar14);
                    puVar9 = (uint64_t *)0x0;
code_r0x0001800cbf28:
                    puVar9[1] = uVar4;
                }
            }
            var_18h = var_18h + 1;
        } while ((uint64_t)var_18h < *(uint64_t *)(arg2 + 0x30));
    }
    return uVar5 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800cbf60
// Address: 0x1800cbf60
// Size: 85 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1800cbf60(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_8h;
    
    (**(code **)**(undefined8 **)(arg2 + 0x20))(*(undefined8 **)(arg2 + 0x20), arg1);
    (**(code **)**(undefined8 **)(arg2 + 0x28))(*(undefined8 **)(arg2 + 0x28), arg1);
    uVar1 = fcn.1800cae90(arg1, *(undefined8 *)(arg2 + 0x20));
    if (uVar1 != 0) {
        uVar1 = fcn.1800caf50(arg1, arg2, *(undefined8 *)(uVar1 + 8));
    }
    return uVar1 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800cbfc0
// Address: 0x1800cbfc0
// Size: 316 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1800cbfc0(int64_t arg1, int64_t arg2)
{
    char *pcVar1;
    undefined8 uVar2;
    char cVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    int32_t *piVar8;
    int64_t *piVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    (**(code **)**(undefined8 **)(arg2 + 0x20))(*(undefined8 **)(arg2 + 0x20), arg1);
    iVar5 = func_0x0001800ac7f0(arg1 + 0xc0, arg2 + 0x20);
    piVar9 = (int64_t *)(iVar5 + 8);
    if (iVar5 == 0) {
        piVar9 = (int64_t *)0x0;
    }
    if (piVar9 != (int64_t *)0x0) {
        iVar5 = 0;
        if (*(int32_t *)(*piVar9 + 8) == *(int32_t *)0x180782704) {
            iVar5 = *piVar9;
        }
        if (iVar5 != 0) {
            piVar9 = *(int64_t **)(iVar5 + 0x20);
            piVar6 = piVar9 + *(int64_t *)(iVar5 + 0x28) * 7;
            if (piVar9 != piVar6) {
                do {
                    if (*piVar9 == *(int64_t *)(arg2 + 0x28)) {
                        uVar7 = fcn.1800caf50(arg1, arg2, piVar9[3]);
                        return uVar7 & 0xffffffffffffff00;
                    }
                    piVar9 = piVar9 + 7;
                } while (piVar9 != piVar6);
            }
        }
    }
    iVar5 = func_0x0001800ac7f0(*(undefined8 *)(arg1 + 0x18), arg2 + 0x20);
    piVar8 = (int32_t *)(iVar5 + 8);
    if (iVar5 == 0) {
        piVar8 = (int32_t *)0x0;
    }
    if ((((piVar8 != (int32_t *)0x0) && (*piVar8 == 8)) && (pcVar1 = *(char **)(arg2 + 0x28), pcVar1 != (char *)0x0)) &&
       ((((((*pcVar1 == 'X' && (pcVar1[1] == '\0')) || ((*pcVar1 == 'Y' && (pcVar1[1] == '\0')))) ||
          ((*pcVar1 == 'Z' && (pcVar1[1] == '\0')))) || ((*pcVar1 == 'x' && (pcVar1[1] == '\0')))) ||
        (((*pcVar1 == 'y' && (pcVar1[1] == '\0')) || ((*pcVar1 == 'z' && (pcVar1[1] == '\0')))))))) {
        uVar7 = fcn.1800caf50(arg1, arg2, *(int64_t *)(arg1 + 0x30) + 0x78);
        return uVar7 & 0xffffffffffffff00;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x40);
    cVar3 = func_0x0001800ca7c0(uVar2, arg2);
    if ((cVar3 != '\0') || (piVar8 = (int32_t *)func_0x0001800ca7c0(uVar2, arg2), (char)piVar8 != '\0')) {
        piVar8 = (int32_t *)fcn.1800caf50(arg1, arg2, *(int64_t *)(arg1 + 0x30) + 0x1e0);
        goto code_r0x0001800cc1fa;
    }
    if (*(code **)(arg1 + 0x48) == (code *)0x0) goto code_r0x0001800cc1fa;
    piVar8 = (int32_t *)(uint64_t)*(uint32_t *)0x180782738;
    iVar5 = 0;
    if (*(uint32_t *)(*(int64_t *)(arg2 + 0x20) + 8) == *(uint32_t *)0x180782738) {
        iVar5 = *(int64_t *)(arg2 + 0x20);
    }
    if (iVar5 == 0) goto code_r0x0001800cc1fa;
    piVar8 = (int32_t *)(**(code **)(arg1 + 0x48))(*(undefined8 *)(iVar5 + 0x20), *(undefined8 *)(arg2 + 0x28));
    iVar4 = (int32_t)piVar8;
    if (iVar4 == 0xf) goto code_r0x0001800cc1fa;
    if (iVar4 == 1) {
        iVar5 = *(int64_t *)(arg1 + 0x30);
code_r0x0001800cc1c9:
        var_8h = arg2;
        piVar9 = (int64_t *)fcn.1800cc970(arg1 + 0xc0, &var_8h);
        *piVar9 = iVar5;
    } else {
        if (iVar4 == 2) {
            iVar5 = *(int64_t *)(arg1 + 0x30) + 0x78;
            goto code_r0x0001800cc1c9;
        }
        if (iVar4 == 3) {
            iVar5 = *(int64_t *)(arg1 + 0x30) + 0x168;
            goto code_r0x0001800cc1c9;
        }
        if (iVar4 == 8) {
            iVar5 = *(int64_t *)(arg1 + 0x30) + 0x1e0;
            goto code_r0x0001800cc1c9;
        }
        if (iVar4 == 10) {
            iVar5 = *(int64_t *)(arg1 + 0x30) + 0xf0;
            goto code_r0x0001800cc1c9;
        }
    }
    var_8h = arg2;
    piVar8 = (int32_t *)func_0x0001800ac540(*(undefined8 *)(arg1 + 0x18), &var_8h);
    *piVar8 = iVar4;
code_r0x0001800cc1fa:
    return (uint64_t)piVar8 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800cc0fc
// Address: 0x1800cc0fc
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1800cbfc0(int64_t arg1, int64_t arg2)
{
    char *pcVar1;
    undefined8 uVar2;
    char cVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    int32_t *piVar8;
    int64_t *piVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    (**(code **)**(undefined8 **)(arg2 + 0x20))(*(undefined8 **)(arg2 + 0x20), arg1);
    iVar5 = func_0x0001800ac7f0(arg1 + 0xc0, arg2 + 0x20);
    piVar9 = (int64_t *)(iVar5 + 8);
    if (iVar5 == 0) {
        piVar9 = (int64_t *)0x0;
    }
    if (piVar9 != (int64_t *)0x0) {
        iVar5 = 0;
        if (*(int32_t *)(*piVar9 + 8) == *(int32_t *)0x180782704) {
            iVar5 = *piVar9;
        }
        if (iVar5 != 0) {
            piVar9 = *(int64_t **)(iVar5 + 0x20);
            piVar6 = piVar9 + *(int64_t *)(iVar5 + 0x28) * 7;
            if (piVar9 != piVar6) {
                do {
                    if (*piVar9 == *(int64_t *)(arg2 + 0x28)) {
                        uVar7 = fcn.1800caf50(arg1, arg2, piVar9[3]);
                        return uVar7 & 0xffffffffffffff00;
                    }
                    piVar9 = piVar9 + 7;
                } while (piVar9 != piVar6);
            }
        }
    }
    iVar5 = func_0x0001800ac7f0(*(undefined8 *)(arg1 + 0x18), arg2 + 0x20);
    piVar8 = (int32_t *)(iVar5 + 8);
    if (iVar5 == 0) {
        piVar8 = (int32_t *)0x0;
    }
    if ((((piVar8 != (int32_t *)0x0) && (*piVar8 == 8)) && (pcVar1 = *(char **)(arg2 + 0x28), pcVar1 != (char *)0x0)) &&
       ((((((*pcVar1 == 'X' && (pcVar1[1] == '\0')) || ((*pcVar1 == 'Y' && (pcVar1[1] == '\0')))) ||
          ((*pcVar1 == 'Z' && (pcVar1[1] == '\0')))) || ((*pcVar1 == 'x' && (pcVar1[1] == '\0')))) ||
        (((*pcVar1 == 'y' && (pcVar1[1] == '\0')) || ((*pcVar1 == 'z' && (pcVar1[1] == '\0')))))))) {
        uVar7 = fcn.1800caf50(arg1, arg2, *(int64_t *)(arg1 + 0x30) + 0x78);
        return uVar7 & 0xffffffffffffff00;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x40);
    cVar3 = func_0x0001800ca7c0(uVar2, arg2);
    if ((cVar3 != '\0') || (piVar8 = (int32_t *)func_0x0001800ca7c0(uVar2, arg2), (char)piVar8 != '\0')) {
        piVar8 = (int32_t *)fcn.1800caf50(arg1, arg2, *(int64_t *)(arg1 + 0x30) + 0x1e0);
        goto code_r0x0001800cc1fa;
    }
    if (*(code **)(arg1 + 0x48) == (code *)0x0) goto code_r0x0001800cc1fa;
    piVar8 = (int32_t *)(uint64_t)*(uint32_t *)0x180782738;
    iVar5 = 0;
    if (*(uint32_t *)(*(int64_t *)(arg2 + 0x20) + 8) == *(uint32_t *)0x180782738) {
        iVar5 = *(int64_t *)(arg2 + 0x20);
    }
    if (iVar5 == 0) goto code_r0x0001800cc1fa;
    piVar8 = (int32_t *)(**(code **)(arg1 + 0x48))(*(undefined8 *)(iVar5 + 0x20), *(undefined8 *)(arg2 + 0x28));
    iVar4 = (int32_t)piVar8;
    if (iVar4 == 0xf) goto code_r0x0001800cc1fa;
    if (iVar4 == 1) {
        iVar5 = *(int64_t *)(arg1 + 0x30);
code_r0x0001800cc1c9:
        var_8h = arg2;
        piVar9 = (int64_t *)fcn.1800cc970(arg1 + 0xc0, &var_8h);
        *piVar9 = iVar5;
    } else {
        if (iVar4 == 2) {
            iVar5 = *(int64_t *)(arg1 + 0x30) + 0x78;
            goto code_r0x0001800cc1c9;
        }
        if (iVar4 == 3) {
            iVar5 = *(int64_t *)(arg1 + 0x30) + 0x168;
            goto code_r0x0001800cc1c9;
        }
        if (iVar4 == 8) {
            iVar5 = *(int64_t *)(arg1 + 0x30) + 0x1e0;
            goto code_r0x0001800cc1c9;
        }
        if (iVar4 == 10) {
            iVar5 = *(int64_t *)(arg1 + 0x30) + 0xf0;
            goto code_r0x0001800cc1c9;
        }
    }
    var_8h = arg2;
    piVar8 = (int32_t *)func_0x0001800ac540(*(undefined8 *)(arg1 + 0x18), &var_8h);
    *piVar8 = iVar4;
code_r0x0001800cc1fa:
    return (uint64_t)piVar8 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800cc13d
// Address: 0x1800cc13d
// Size: 189 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1800cbfc0(int64_t arg1, int64_t arg2)
{
    char *pcVar1;
    undefined8 uVar2;
    char cVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    int32_t *piVar8;
    int64_t *piVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    (**(code **)**(undefined8 **)(arg2 + 0x20))(*(undefined8 **)(arg2 + 0x20), arg1);
    iVar5 = func_0x0001800ac7f0(arg1 + 0xc0, arg2 + 0x20);
    piVar9 = (int64_t *)(iVar5 + 8);
    if (iVar5 == 0) {
        piVar9 = (int64_t *)0x0;
    }
    if (piVar9 != (int64_t *)0x0) {
        iVar5 = 0;
        if (*(int32_t *)(*piVar9 + 8) == *(int32_t *)0x180782704) {
            iVar5 = *piVar9;
        }
        if (iVar5 != 0) {
            piVar9 = *(int64_t **)(iVar5 + 0x20);
            piVar6 = piVar9 + *(int64_t *)(iVar5 + 0x28) * 7;
            if (piVar9 != piVar6) {
                do {
                    if (*piVar9 == *(int64_t *)(arg2 + 0x28)) {
                        uVar7 = fcn.1800caf50(arg1, arg2, piVar9[3]);
                        return uVar7 & 0xffffffffffffff00;
                    }
                    piVar9 = piVar9 + 7;
                } while (piVar9 != piVar6);
            }
        }
    }
    iVar5 = func_0x0001800ac7f0(*(undefined8 *)(arg1 + 0x18), arg2 + 0x20);
    piVar8 = (int32_t *)(iVar5 + 8);
    if (iVar5 == 0) {
        piVar8 = (int32_t *)0x0;
    }
    if ((((piVar8 != (int32_t *)0x0) && (*piVar8 == 8)) && (pcVar1 = *(char **)(arg2 + 0x28), pcVar1 != (char *)0x0)) &&
       ((((((*pcVar1 == 'X' && (pcVar1[1] == '\0')) || ((*pcVar1 == 'Y' && (pcVar1[1] == '\0')))) ||
          ((*pcVar1 == 'Z' && (pcVar1[1] == '\0')))) || ((*pcVar1 == 'x' && (pcVar1[1] == '\0')))) ||
        (((*pcVar1 == 'y' && (pcVar1[1] == '\0')) || ((*pcVar1 == 'z' && (pcVar1[1] == '\0')))))))) {
        uVar7 = fcn.1800caf50(arg1, arg2, *(int64_t *)(arg1 + 0x30) + 0x78);
        return uVar7 & 0xffffffffffffff00;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x40);
    cVar3 = func_0x0001800ca7c0(uVar2, arg2);
    if ((cVar3 != '\0') || (piVar8 = (int32_t *)func_0x0001800ca7c0(uVar2, arg2), (char)piVar8 != '\0')) {
        piVar8 = (int32_t *)fcn.1800caf50(arg1, arg2, *(int64_t *)(arg1 + 0x30) + 0x1e0);
        goto code_r0x0001800cc1fa;
    }
    if (*(code **)(arg1 + 0x48) == (code *)0x0) goto code_r0x0001800cc1fa;
    piVar8 = (int32_t *)(uint64_t)*(uint32_t *)0x180782738;
    iVar5 = 0;
    if (*(uint32_t *)(*(int64_t *)(arg2 + 0x20) + 8) == *(uint32_t *)0x180782738) {
        iVar5 = *(int64_t *)(arg2 + 0x20);
    }
    if (iVar5 == 0) goto code_r0x0001800cc1fa;
    piVar8 = (int32_t *)(**(code **)(arg1 + 0x48))(*(undefined8 *)(iVar5 + 0x20), *(undefined8 *)(arg2 + 0x28));
    iVar4 = (int32_t)piVar8;
    if (iVar4 == 0xf) goto code_r0x0001800cc1fa;
    if (iVar4 == 1) {
        iVar5 = *(int64_t *)(arg1 + 0x30);
code_r0x0001800cc1c9:
        var_8h = arg2;
        piVar9 = (int64_t *)fcn.1800cc970(arg1 + 0xc0, &var_8h);
        *piVar9 = iVar5;
    } else {
        if (iVar4 == 2) {
            iVar5 = *(int64_t *)(arg1 + 0x30) + 0x78;
            goto code_r0x0001800cc1c9;
        }
        if (iVar4 == 3) {
            iVar5 = *(int64_t *)(arg1 + 0x30) + 0x168;
            goto code_r0x0001800cc1c9;
        }
        if (iVar4 == 8) {
            iVar5 = *(int64_t *)(arg1 + 0x30) + 0x1e0;
            goto code_r0x0001800cc1c9;
        }
        if (iVar4 == 10) {
            iVar5 = *(int64_t *)(arg1 + 0x30) + 0xf0;
            goto code_r0x0001800cc1c9;
        }
    }
    var_8h = arg2;
    piVar8 = (int32_t *)func_0x0001800ac540(*(undefined8 *)(arg1 + 0x18), &var_8h);
    *piVar8 = iVar4;
code_r0x0001800cc1fa:
    return (uint64_t)piVar8 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800cc1fa
// Address: 0x1800cc1fa
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1800cbfc0(int64_t arg1, int64_t arg2)
{
    char *pcVar1;
    undefined8 uVar2;
    char cVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    int32_t *piVar8;
    int64_t *piVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    (**(code **)**(undefined8 **)(arg2 + 0x20))(*(undefined8 **)(arg2 + 0x20), arg1);
    iVar5 = func_0x0001800ac7f0(arg1 + 0xc0, arg2 + 0x20);
    piVar9 = (int64_t *)(iVar5 + 8);
    if (iVar5 == 0) {
        piVar9 = (int64_t *)0x0;
    }
    if (piVar9 != (int64_t *)0x0) {
        iVar5 = 0;
        if (*(int32_t *)(*piVar9 + 8) == *(int32_t *)0x180782704) {
            iVar5 = *piVar9;
        }
        if (iVar5 != 0) {
            piVar9 = *(int64_t **)(iVar5 + 0x20);
            piVar6 = piVar9 + *(int64_t *)(iVar5 + 0x28) * 7;
            if (piVar9 != piVar6) {
                do {
                    if (*piVar9 == *(int64_t *)(arg2 + 0x28)) {
                        uVar7 = fcn.1800caf50(arg1, arg2, piVar9[3]);
                        return uVar7 & 0xffffffffffffff00;
                    }
                    piVar9 = piVar9 + 7;
                } while (piVar9 != piVar6);
            }
        }
    }
    iVar5 = func_0x0001800ac7f0(*(undefined8 *)(arg1 + 0x18), arg2 + 0x20);
    piVar8 = (int32_t *)(iVar5 + 8);
    if (iVar5 == 0) {
        piVar8 = (int32_t *)0x0;
    }
    if ((((piVar8 != (int32_t *)0x0) && (*piVar8 == 8)) && (pcVar1 = *(char **)(arg2 + 0x28), pcVar1 != (char *)0x0)) &&
       ((((((*pcVar1 == 'X' && (pcVar1[1] == '\0')) || ((*pcVar1 == 'Y' && (pcVar1[1] == '\0')))) ||
          ((*pcVar1 == 'Z' && (pcVar1[1] == '\0')))) || ((*pcVar1 == 'x' && (pcVar1[1] == '\0')))) ||
        (((*pcVar1 == 'y' && (pcVar1[1] == '\0')) || ((*pcVar1 == 'z' && (pcVar1[1] == '\0')))))))) {
        uVar7 = fcn.1800caf50(arg1, arg2, *(int64_t *)(arg1 + 0x30) + 0x78);
        return uVar7 & 0xffffffffffffff00;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x40);
    cVar3 = func_0x0001800ca7c0(uVar2, arg2);
    if ((cVar3 != '\0') || (piVar8 = (int32_t *)func_0x0001800ca7c0(uVar2, arg2), (char)piVar8 != '\0')) {
        piVar8 = (int32_t *)fcn.1800caf50(arg1, arg2, *(int64_t *)(arg1 + 0x30) + 0x1e0);
        goto code_r0x0001800cc1fa;
    }
    if (*(code **)(arg1 + 0x48) == (code *)0x0) goto code_r0x0001800cc1fa;
    piVar8 = (int32_t *)(uint64_t)*(uint32_t *)0x180782738;
    iVar5 = 0;
    if (*(uint32_t *)(*(int64_t *)(arg2 + 0x20) + 8) == *(uint32_t *)0x180782738) {
        iVar5 = *(int64_t *)(arg2 + 0x20);
    }
    if (iVar5 == 0) goto code_r0x0001800cc1fa;
    piVar8 = (int32_t *)(**(code **)(arg1 + 0x48))(*(undefined8 *)(iVar5 + 0x20), *(undefined8 *)(arg2 + 0x28));
    iVar4 = (int32_t)piVar8;
    if (iVar4 == 0xf) goto code_r0x0001800cc1fa;
    if (iVar4 == 1) {
        iVar5 = *(int64_t *)(arg1 + 0x30);
code_r0x0001800cc1c9:
        var_8h = arg2;
        piVar9 = (int64_t *)fcn.1800cc970(arg1 + 0xc0, &var_8h);
        *piVar9 = iVar5;
    } else {
        if (iVar4 == 2) {
            iVar5 = *(int64_t *)(arg1 + 0x30) + 0x78;
            goto code_r0x0001800cc1c9;
        }
        if (iVar4 == 3) {
            iVar5 = *(int64_t *)(arg1 + 0x30) + 0x168;
            goto code_r0x0001800cc1c9;
        }
        if (iVar4 == 8) {
            iVar5 = *(int64_t *)(arg1 + 0x30) + 0x1e0;
            goto code_r0x0001800cc1c9;
        }
        if (iVar4 == 10) {
            iVar5 = *(int64_t *)(arg1 + 0x30) + 0xf0;
            goto code_r0x0001800cc1c9;
        }
    }
    var_8h = arg2;
    piVar8 = (int32_t *)func_0x0001800ac540(*(undefined8 *)(arg1 + 0x18), &var_8h);
    *piVar8 = iVar4;
code_r0x0001800cc1fa:
    return (uint64_t)piVar8 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800cc20e
// Address: 0x1800cc20e
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1800cbfc0(int64_t arg1, int64_t arg2)
{
    char *pcVar1;
    undefined8 uVar2;
    char cVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    int32_t *piVar8;
    int64_t *piVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    (**(code **)**(undefined8 **)(arg2 + 0x20))(*(undefined8 **)(arg2 + 0x20), arg1);
    iVar5 = func_0x0001800ac7f0(arg1 + 0xc0, arg2 + 0x20);
    piVar9 = (int64_t *)(iVar5 + 8);
    if (iVar5 == 0) {
        piVar9 = (int64_t *)0x0;
    }
    if (piVar9 != (int64_t *)0x0) {
        iVar5 = 0;
        if (*(int32_t *)(*piVar9 + 8) == *(int32_t *)0x180782704) {
            iVar5 = *piVar9;
        }
        if (iVar5 != 0) {
            piVar9 = *(int64_t **)(iVar5 + 0x20);
            piVar6 = piVar9 + *(int64_t *)(iVar5 + 0x28) * 7;
            if (piVar9 != piVar6) {
                do {
                    if (*piVar9 == *(int64_t *)(arg2 + 0x28)) {
                        uVar7 = fcn.1800caf50(arg1, arg2, piVar9[3]);
                        return uVar7 & 0xffffffffffffff00;
                    }
                    piVar9 = piVar9 + 7;
                } while (piVar9 != piVar6);
            }
        }
    }
    iVar5 = func_0x0001800ac7f0(*(undefined8 *)(arg1 + 0x18), arg2 + 0x20);
    piVar8 = (int32_t *)(iVar5 + 8);
    if (iVar5 == 0) {
        piVar8 = (int32_t *)0x0;
    }
    if ((((piVar8 != (int32_t *)0x0) && (*piVar8 == 8)) && (pcVar1 = *(char **)(arg2 + 0x28), pcVar1 != (char *)0x0)) &&
       ((((((*pcVar1 == 'X' && (pcVar1[1] == '\0')) || ((*pcVar1 == 'Y' && (pcVar1[1] == '\0')))) ||
          ((*pcVar1 == 'Z' && (pcVar1[1] == '\0')))) || ((*pcVar1 == 'x' && (pcVar1[1] == '\0')))) ||
        (((*pcVar1 == 'y' && (pcVar1[1] == '\0')) || ((*pcVar1 == 'z' && (pcVar1[1] == '\0')))))))) {
        uVar7 = fcn.1800caf50(arg1, arg2, *(int64_t *)(arg1 + 0x30) + 0x78);
        return uVar7 & 0xffffffffffffff00;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x40);
    cVar3 = func_0x0001800ca7c0(uVar2, arg2);
    if ((cVar3 != '\0') || (piVar8 = (int32_t *)func_0x0001800ca7c0(uVar2, arg2), (char)piVar8 != '\0')) {
        piVar8 = (int32_t *)fcn.1800caf50(arg1, arg2, *(int64_t *)(arg1 + 0x30) + 0x1e0);
        goto code_r0x0001800cc1fa;
    }
    if (*(code **)(arg1 + 0x48) == (code *)0x0) goto code_r0x0001800cc1fa;
    piVar8 = (int32_t *)(uint64_t)*(uint32_t *)0x180782738;
    iVar5 = 0;
    if (*(uint32_t *)(*(int64_t *)(arg2 + 0x20) + 8) == *(uint32_t *)0x180782738) {
        iVar5 = *(int64_t *)(arg2 + 0x20);
    }
    if (iVar5 == 0) goto code_r0x0001800cc1fa;
    piVar8 = (int32_t *)(**(code **)(arg1 + 0x48))(*(undefined8 *)(iVar5 + 0x20), *(undefined8 *)(arg2 + 0x28));
    iVar4 = (int32_t)piVar8;
    if (iVar4 == 0xf) goto code_r0x0001800cc1fa;
    if (iVar4 == 1) {
        iVar5 = *(int64_t *)(arg1 + 0x30);
code_r0x0001800cc1c9:
        var_8h = arg2;
        piVar9 = (int64_t *)fcn.1800cc970(arg1 + 0xc0, &var_8h);
        *piVar9 = iVar5;
    } else {
        if (iVar4 == 2) {
            iVar5 = *(int64_t *)(arg1 + 0x30) + 0x78;
            goto code_r0x0001800cc1c9;
        }
        if (iVar4 == 3) {
            iVar5 = *(int64_t *)(arg1 + 0x30) + 0x168;
            goto code_r0x0001800cc1c9;
        }
        if (iVar4 == 8) {
            iVar5 = *(int64_t *)(arg1 + 0x30) + 0x1e0;
            goto code_r0x0001800cc1c9;
        }
        if (iVar4 == 10) {
            iVar5 = *(int64_t *)(arg1 + 0x30) + 0xf0;
            goto code_r0x0001800cc1c9;
        }
    }
    var_8h = arg2;
    piVar8 = (int32_t *)func_0x0001800ac540(*(undefined8 *)(arg1 + 0x18), &var_8h);
    *piVar8 = iVar4;
code_r0x0001800cc1fa:
    return (uint64_t)piVar8 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800cc230
// Address: 0x1800cc230
// Size: 100 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1800cc230(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    uint32_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint32_t *puVar5;
    undefined8 *puVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar3 = (**(code **)**(undefined8 **)(arg2 + 0x28))(*(undefined8 **)(arg2 + 0x28), arg1);
    iVar1 = *(int32_t *)(arg2 + 0x20);
    if (iVar1 == 0) {
        uVar3 = fcn.1800caf50(arg1, arg2, *(undefined8 *)(arg1 + 0x30));
        return uVar3 & 0xffffffffffffff00;
    }
    if (iVar1 != 1) {
        if (iVar1 == 2) {
            uVar3 = fcn.1800caf50(arg1, arg2, *(int64_t *)(arg1 + 0x30) + 0x78);
        }
        return uVar3 & 0xffffffffffffff00;
    }
    iVar4 = fcn.1800ac7f0(arg1 + 0xc0, arg2 + 0x28);
    puVar6 = (undefined8 *)(iVar4 + 8);
    if (iVar4 == 0) {
        puVar6 = (undefined8 *)0x0;
    }
    uVar3 = fcn.1800ac7f0(*(undefined8 *)(arg1 + 0x18), arg2 + 0x28);
    puVar5 = (uint32_t *)(uVar3 + 8);
    if (uVar3 == 0) {
        puVar5 = (uint32_t *)0x0;
    }
    if ((puVar6 != (undefined8 *)0x0) && (puVar5 != (uint32_t *)0x0)) {
        uVar2 = *puVar5;
        uVar3 = (uint64_t)uVar2;
        if ((uVar2 == 8) || (uVar2 == 2)) {
            uVar3 = fcn.1800caf50(arg1, arg2, *puVar6);
        }
    }
    return uVar3 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800cc294
// Address: 0x1800cc294
// Size: 113 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1800cc230(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    uint32_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint32_t *puVar5;
    undefined8 *puVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar3 = (**(code **)**(undefined8 **)(arg2 + 0x28))(*(undefined8 **)(arg2 + 0x28), arg1);
    iVar1 = *(int32_t *)(arg2 + 0x20);
    if (iVar1 == 0) {
        uVar3 = fcn.1800caf50(arg1, arg2, *(undefined8 *)(arg1 + 0x30));
        return uVar3 & 0xffffffffffffff00;
    }
    if (iVar1 != 1) {
        if (iVar1 == 2) {
            uVar3 = fcn.1800caf50(arg1, arg2, *(int64_t *)(arg1 + 0x30) + 0x78);
        }
        return uVar3 & 0xffffffffffffff00;
    }
    iVar4 = fcn.1800ac7f0(arg1 + 0xc0, arg2 + 0x28);
    puVar6 = (undefined8 *)(iVar4 + 8);
    if (iVar4 == 0) {
        puVar6 = (undefined8 *)0x0;
    }
    uVar3 = fcn.1800ac7f0(*(undefined8 *)(arg1 + 0x18), arg2 + 0x28);
    puVar5 = (uint32_t *)(uVar3 + 8);
    if (uVar3 == 0) {
        puVar5 = (uint32_t *)0x0;
    }
    if ((puVar6 != (undefined8 *)0x0) && (puVar5 != (uint32_t *)0x0)) {
        uVar2 = *puVar5;
        uVar3 = (uint64_t)uVar2;
        if ((uVar2 == 8) || (uVar2 == 2)) {
            uVar3 = fcn.1800caf50(arg1, arg2, *puVar6);
        }
    }
    return uVar3 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800cc305
// Address: 0x1800cc305
// Size: 34 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1800cc230(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    uint32_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint32_t *puVar5;
    undefined8 *puVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar3 = (**(code **)**(undefined8 **)(arg2 + 0x28))(*(undefined8 **)(arg2 + 0x28), arg1);
    iVar1 = *(int32_t *)(arg2 + 0x20);
    if (iVar1 == 0) {
        uVar3 = fcn.1800caf50(arg1, arg2, *(undefined8 *)(arg1 + 0x30));
        return uVar3 & 0xffffffffffffff00;
    }
    if (iVar1 != 1) {
        if (iVar1 == 2) {
            uVar3 = fcn.1800caf50(arg1, arg2, *(int64_t *)(arg1 + 0x30) + 0x78);
        }
        return uVar3 & 0xffffffffffffff00;
    }
    iVar4 = fcn.1800ac7f0(arg1 + 0xc0, arg2 + 0x28);
    puVar6 = (undefined8 *)(iVar4 + 8);
    if (iVar4 == 0) {
        puVar6 = (undefined8 *)0x0;
    }
    uVar3 = fcn.1800ac7f0(*(undefined8 *)(arg1 + 0x18), arg2 + 0x28);
    puVar5 = (uint32_t *)(uVar3 + 8);
    if (uVar3 == 0) {
        puVar5 = (uint32_t *)0x0;
    }
    if ((puVar6 != (undefined8 *)0x0) && (puVar5 != (uint32_t *)0x0)) {
        uVar2 = *puVar5;
        uVar3 = (uint64_t)uVar2;
        if ((uVar2 == 8) || (uVar2 == 2)) {
            uVar3 = fcn.1800caf50(arg1, arg2, *puVar6);
        }
    }
    return uVar3 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800cc330
// Address: 0x1800cc330
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.1800cc330(int64_t arg1, int64_t arg2, int64_t arg_48h)
{
    int32_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint32_t *puVar5;
    undefined8 *puVar6;
    undefined8 uVar7;
    int32_t *piVar8;
    undefined8 *puVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    (**(code **)**(undefined8 **)(arg2 + 0x28))(*(undefined8 **)(arg2 + 0x28), arg1);
    (**(code **)**(undefined8 **)(arg2 + 0x30))(*(undefined8 **)(arg2 + 0x30), arg1);
    iVar1 = *(int32_t *)(arg2 + 0x20);
    uVar4 = (uint64_t)(iVar1 - 8U);
    if (iVar1 - 8U < 6) {
        uVar4 = fcn.1800caf50(arg1, arg2, *(undefined8 *)(arg1 + 0x30));
        return uVar4 & 0xffffffffffffff00;
    }
    if ((iVar1 == 7) || (uVar4 = (uint64_t)(iVar1 - 0xeU), iVar1 - 0xeU < 2)) goto code_r0x0001800cc437;
    iVar3 = fcn.1800ac7f0(arg1 + 0xc0, arg2 + 0x28);
    puVar6 = (undefined8 *)(iVar3 + 8);
    if (iVar3 == 0) {
        puVar6 = (undefined8 *)0x0;
    }
    uVar4 = fcn.1800ac7f0(*(undefined8 *)(arg1 + 0x18));
    piVar8 = (int32_t *)(uVar4 + 8);
    if (uVar4 == 0) {
        piVar8 = (int32_t *)0x0;
    }
    if ((puVar6 == (undefined8 *)0x0) || (piVar8 == (int32_t *)0x0)) goto code_r0x0001800cc437;
    iVar3 = fcn.1800ac7f0(arg1 + 0xc0, arg2 + 0x30);
    puVar9 = (undefined8 *)(iVar3 + 8);
    if (iVar3 == 0) {
        puVar9 = (undefined8 *)0x0;
    }
    uVar4 = fcn.1800ac7f0(*(undefined8 *)(arg1 + 0x18), arg2 + 0x30);
    puVar5 = (uint32_t *)(uVar4 + 8);
    if (uVar4 == 0) {
        puVar5 = (uint32_t *)0x0;
    }
    if ((puVar9 == (undefined8 *)0x0) || (puVar5 == (uint32_t *)0x0)) goto code_r0x0001800cc437;
    if (*piVar8 == 8) {
code_r0x0001800cc429:
        uVar7 = *puVar6;
    } else {
        uVar2 = *puVar5;
        uVar4 = (uint64_t)uVar2;
        if (uVar2 != 8) {
            if ((*piVar8 != 2) || (uVar2 != 2)) goto code_r0x0001800cc437;
            goto code_r0x0001800cc429;
        }
        uVar7 = *puVar9;
    }
    uVar4 = fcn.1800caf50(arg1, arg2, uVar7);
code_r0x0001800cc437:
    return uVar4 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800cc36a
// Address: 0x1800cc36a
// Size: 231 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.1800cc330(int64_t arg1, int64_t arg2, int64_t arg_48h)
{
    int32_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint32_t *puVar5;
    undefined8 *puVar6;
    undefined8 uVar7;
    int32_t *piVar8;
    undefined8 *puVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    (**(code **)**(undefined8 **)(arg2 + 0x28))(*(undefined8 **)(arg2 + 0x28), arg1);
    (**(code **)**(undefined8 **)(arg2 + 0x30))(*(undefined8 **)(arg2 + 0x30), arg1);
    iVar1 = *(int32_t *)(arg2 + 0x20);
    uVar4 = (uint64_t)(iVar1 - 8U);
    if (iVar1 - 8U < 6) {
        uVar4 = fcn.1800caf50(arg1, arg2, *(undefined8 *)(arg1 + 0x30));
        return uVar4 & 0xffffffffffffff00;
    }
    if ((iVar1 == 7) || (uVar4 = (uint64_t)(iVar1 - 0xeU), iVar1 - 0xeU < 2)) goto code_r0x0001800cc437;
    iVar3 = fcn.1800ac7f0(arg1 + 0xc0, arg2 + 0x28);
    puVar6 = (undefined8 *)(iVar3 + 8);
    if (iVar3 == 0) {
        puVar6 = (undefined8 *)0x0;
    }
    uVar4 = fcn.1800ac7f0(*(undefined8 *)(arg1 + 0x18));
    piVar8 = (int32_t *)(uVar4 + 8);
    if (uVar4 == 0) {
        piVar8 = (int32_t *)0x0;
    }
    if ((puVar6 == (undefined8 *)0x0) || (piVar8 == (int32_t *)0x0)) goto code_r0x0001800cc437;
    iVar3 = fcn.1800ac7f0(arg1 + 0xc0, arg2 + 0x30);
    puVar9 = (undefined8 *)(iVar3 + 8);
    if (iVar3 == 0) {
        puVar9 = (undefined8 *)0x0;
    }
    uVar4 = fcn.1800ac7f0(*(undefined8 *)(arg1 + 0x18), arg2 + 0x30);
    puVar5 = (uint32_t *)(uVar4 + 8);
    if (uVar4 == 0) {
        puVar5 = (uint32_t *)0x0;
    }
    if ((puVar9 == (undefined8 *)0x0) || (puVar5 == (uint32_t *)0x0)) goto code_r0x0001800cc437;
    if (*piVar8 == 8) {
code_r0x0001800cc429:
        uVar7 = *puVar6;
    } else {
        uVar2 = *puVar5;
        uVar4 = (uint64_t)uVar2;
        if (uVar2 != 8) {
            if ((*piVar8 != 2) || (uVar2 != 2)) goto code_r0x0001800cc437;
            goto code_r0x0001800cc429;
        }
        uVar7 = *puVar9;
    }
    uVar4 = fcn.1800caf50(arg1, arg2, uVar7);
code_r0x0001800cc437:
    return uVar4 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800cc451
// Address: 0x1800cc451
// Size: 31 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.1800cc330(int64_t arg1, int64_t arg2, int64_t arg_48h)
{
    int32_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint32_t *puVar5;
    undefined8 *puVar6;
    undefined8 uVar7;
    int32_t *piVar8;
    undefined8 *puVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    (**(code **)**(undefined8 **)(arg2 + 0x28))(*(undefined8 **)(arg2 + 0x28), arg1);
    (**(code **)**(undefined8 **)(arg2 + 0x30))(*(undefined8 **)(arg2 + 0x30), arg1);
    iVar1 = *(int32_t *)(arg2 + 0x20);
    uVar4 = (uint64_t)(iVar1 - 8U);
    if (iVar1 - 8U < 6) {
        uVar4 = fcn.1800caf50(arg1, arg2, *(undefined8 *)(arg1 + 0x30));
        return uVar4 & 0xffffffffffffff00;
    }
    if ((iVar1 == 7) || (uVar4 = (uint64_t)(iVar1 - 0xeU), iVar1 - 0xeU < 2)) goto code_r0x0001800cc437;
    iVar3 = fcn.1800ac7f0(arg1 + 0xc0, arg2 + 0x28);
    puVar6 = (undefined8 *)(iVar3 + 8);
    if (iVar3 == 0) {
        puVar6 = (undefined8 *)0x0;
    }
    uVar4 = fcn.1800ac7f0(*(undefined8 *)(arg1 + 0x18));
    piVar8 = (int32_t *)(uVar4 + 8);
    if (uVar4 == 0) {
        piVar8 = (int32_t *)0x0;
    }
    if ((puVar6 == (undefined8 *)0x0) || (piVar8 == (int32_t *)0x0)) goto code_r0x0001800cc437;
    iVar3 = fcn.1800ac7f0(arg1 + 0xc0, arg2 + 0x30);
    puVar9 = (undefined8 *)(iVar3 + 8);
    if (iVar3 == 0) {
        puVar9 = (undefined8 *)0x0;
    }
    uVar4 = fcn.1800ac7f0(*(undefined8 *)(arg1 + 0x18), arg2 + 0x30);
    puVar5 = (uint32_t *)(uVar4 + 8);
    if (uVar4 == 0) {
        puVar5 = (uint32_t *)0x0;
    }
    if ((puVar9 == (undefined8 *)0x0) || (puVar5 == (uint32_t *)0x0)) goto code_r0x0001800cc437;
    if (*piVar8 == 8) {
code_r0x0001800cc429:
        uVar7 = *puVar6;
    } else {
        uVar2 = *puVar5;
        uVar4 = (uint64_t)uVar2;
        if (uVar2 != 8) {
            if ((*piVar8 != 2) || (uVar2 != 2)) goto code_r0x0001800cc437;
            goto code_r0x0001800cc429;
        }
        uVar7 = *puVar9;
    }
    uVar4 = fcn.1800caf50(arg1, arg2, uVar7);
code_r0x0001800cc437:
    return uVar4 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800cc470
// Address: 0x1800cc470
// Size: 99 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.1800cc470(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined8 *puVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    (**(code **)**(undefined8 **)(arg2 + 0x20))(*(undefined8 **)(arg2 + 0x20), arg1);
    uVar1 = fcn.1800ac7f0(arg1 + 0xc0, arg2 + 0x20);
    puVar2 = (undefined8 *)(uVar1 + 8);
    if (uVar1 == 0) {
        puVar2 = (undefined8 *)0x0;
    }
    if (puVar2 != (undefined8 *)0x0) {
        uVar1 = fcn.1800caf50(arg1, arg2, *puVar2);
    }
    return uVar1 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800cc4e0
// Address: 0x1800cc4e0
// Size: 56 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1800cc4e0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_8h;
    
    (**(code **)**(undefined8 **)(arg2 + 0x20))(*(undefined8 **)(arg2 + 0x20), arg1);
    uVar1 = fcn.1800caf50(arg1, arg2, *(undefined8 *)(arg2 + 0x28));
    return uVar1 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800cc520
// Address: 0x1800cc520
// Size: 20 bytes
// ============================================================
undefined fcn.1800cc520(int64_t arg1)
{
    undefined8 in_RDX;
    
    fcn.1800caf50(arg1, in_RDX, *(undefined8 *)(arg1 + 0x30));
    return 0;
}

// ============================================================
// Function: FUN_1800cc540
// Address: 0x1800cc540
// Size: 24 bytes
// ============================================================
undefined fcn.1800cc540(int64_t arg1)
{
    undefined8 in_RDX;
    
    fcn.1800caf50(arg1, in_RDX, *(int64_t *)(arg1 + 0x30) + 0x78);
    return 0;
}

// ============================================================
// Function: FUN_1800cc560
// Address: 0x1800cc560
// Size: 27 bytes
// ============================================================
undefined fcn.1800cc560(int64_t arg1)
{
    undefined8 in_RDX;
    
    fcn.1800caf50(arg1, in_RDX, *(int64_t *)(arg1 + 0x30) + 0xf0);
    return 0;
}

// ============================================================
// Function: FUN_1800cc580
// Address: 0x1800cc580
// Size: 27 bytes
// ============================================================
undefined fcn.1800cc580(int64_t arg1)
{
    undefined8 in_RDX;
    
    fcn.1800caf50(arg1, in_RDX, *(int64_t *)(arg1 + 0x30) + 0x168);
    return 0;
}

// ============================================================
// Function: FUN_1800cc5a0
// Address: 0x1800cc5a0
// Size: 185 bytes
// ============================================================
uint64_t fcn.1800cc5a0(int64_t arg1, int64_t arg2, int64_t arg_c0h)
{
    int64_t iVar1;
    uint64_t uVar2;
    uint32_t *puVar3;
    uint32_t *puVar4;
    undefined8 *puVar5;
    int64_t var_18h;
    
    (**(code **)**(undefined8 **)(arg2 + 0x20))(*(undefined8 **)(arg2 + 0x20), arg1);
    (**(code **)**(undefined8 **)(arg2 + 0x30))(*(undefined8 **)(arg2 + 0x30), arg1);
    (**(code **)**(undefined8 **)(arg2 + 0x40))(*(undefined8 **)(arg2 + 0x40), arg1);
    iVar1 = fcn.1800ac7f0(arg1 + 0xc0, arg2 + 0x30);
    puVar5 = (undefined8 *)(iVar1 + 8);
    if (iVar1 == 0) {
        puVar5 = (undefined8 *)0x0;
    }
    iVar1 = fcn.1800ac7f0(*(undefined8 *)(arg1 + 0x18), arg2 + 0x30);
    puVar4 = (uint32_t *)(iVar1 + 8);
    if (iVar1 == 0) {
        puVar4 = (uint32_t *)0x0;
    }
    uVar2 = fcn.1800ac7f0(*(undefined8 *)(arg1 + 0x18), arg2 + 0x40);
    puVar3 = (uint32_t *)(uVar2 + 8);
    if (uVar2 == 0) {
        puVar3 = (uint32_t *)0x0;
    }
    if ((((puVar5 != (undefined8 *)0x0) && (puVar4 != (uint32_t *)0x0)) && (puVar3 != (uint32_t *)0x0)) &&
       (uVar2 = (uint64_t)*puVar3, *puVar4 == *puVar3)) {
        uVar2 = fcn.1800caf50(arg1, arg2, *puVar5);
    }
    return uVar2 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800cc660
// Address: 0x1800cc660
// Size: 538 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800cc660(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    uint64_t uVar2;
    int64_t *piVar3;
    uint64_t uVar4;
    int64_t *piVar5;
    int64_t var_8h;
    
    piVar3 = *(int64_t **)(arg1 + 0x38);
    if ((piVar3[2] != 0) && (arg2 != piVar3[3])) {
        uVar2 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar4 = 0;
        do {
            uVar2 = uVar2 & piVar3[1] - 1U;
            piVar5 = (int64_t *)(uVar2 * 0x10 + *piVar3);
            if (*piVar5 == arg2) {
                piVar3 = piVar5 + 1;
                if (piVar5 == (int64_t *)0x0) {
                    piVar3 = (int64_t *)0x0;
                }
                if (piVar3 != (int64_t *)0x0) {
    // switch table (130 cases) at 0x1800cc7d8
                    switch(*(int32_t *)piVar3 + -2) {
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                    case 7:
                    case 8:
                    case 9:
                    case 10:
                    case 0xb:
                    case 0xc:
                    case 0xd:
                    case 0xe:
                    case 0xf:
                    case 0x10:
                    case 0x11:
                    case 0x12:
                    case 0x13:
                    case 0x14:
                    case 0x15:
                    case 0x16:
                    case 0x17:
                    case 0x18:
                    case 0x19:
                    case 0x1a:
                    case 0x1b:
                    case 0x1c:
                    case 0x1d:
                    case 0x1e:
                    case 0x1f:
                    case 0x20:
                    case 0x21:
                    case 0x22:
                    case 0x23:
                    case 0x24:
                    case 0x25:
                    case 0x27:
                    case 0x29:
                    case 0x2c:
                    case 0x2d:
                    case 0x2e:
                    case 0x35:
                    case 0x36:
                    case 0x38:
                    case 0x39:
                    case 0x3c:
                    case 0x3e:
                    case 0x3f:
                    case 0x40:
                    case 0x42:
                    case 0x43:
                    case 0x45:
                    case 0x46:
                    case 0x48:
                    case 0x4a:
                    case 0x4c:
                    case 0x4f:
                    case 0x57:
                        iVar1 = *(int64_t *)(arg1 + 0x30) + 0x78;
                        break;
                    case 0x26:
                    case 0x28:
                    case 0x2a:
                    case 0x2b:
                    case 0x3d:
                        iVar1 = *(int64_t *)(arg1 + 0x30) + 0x168;
                        break;
                    default:
                        goto code_r0x0001800cc720;
                    case 0x34:
                    case 0x4d:
                    case 0x4e:
                    case 0x50:
                    case 0x51:
                    case 0x52:
                    case 0x53:
                    case 0x54:
                    case 0x55:
                    case 0x56:
                    case 0x58:
                        iVar1 = *(int64_t *)(arg1 + 0x30) + 0x1e0;
                        break;
                    case 0x5c:
                    case 0x5e:
                    case 0x5f:
                    case 0x60:
                    case 0x61:
                    case 0x62:
                    case 99:
                    case 100:
                    case 0x65:
                    case 0x66:
                    case 0x67:
                    case 0x68:
                    case 0x69:
                    case 0x6a:
                    case 0x6b:
                    case 0x6c:
                    case 0x6d:
                    case 0x6e:
                    case 0x77:
                    case 0x78:
                    case 0x79:
                    case 0x7a:
                    case 0x7b:
                    case 0x7c:
                    case 0x7e:
                    case 0x7f:
                    case 0x80:
                    case 0x81:
                        if (*(char *)0x180777e78 == '\0') {
                            return 1;
                        }
                        iVar1 = *(int64_t *)(arg1 + 0x30) + 0xf0;
                        break;
                    case 0x5d:
                        if (*(char *)0x180777e78 == '\0') {
                            return 1;
                        }
                        iVar1 = *(int64_t *)(arg1 + 0x30) + 0x78;
                        break;
                    case 0x6f:
                    case 0x70:
                    case 0x71:
                    case 0x72:
                    case 0x73:
                    case 0x74:
                    case 0x75:
                    case 0x76:
                    case 0x7d:
                        if (*(char *)0x180777e78 == '\0') {
                            return 1;
                        }
                    case 0x31:
                    case 0x59:
                    case 0x5a:
                    case 0x5b:
                        iVar1 = *(int64_t *)(arg1 + 0x30);
                    }
                    goto code_r0x0001800cc715;
                }
                break;
            }
            if (*piVar5 == piVar3[3]) break;
            uVar2 = uVar2 + 1 + uVar4;
            uVar4 = uVar4 + 1;
        } while (uVar4 <= piVar3[1] - 1U);
    }
    iVar1 = 0;
    if (*(int32_t *)(*(int64_t *)(arg2 + 0x20) + 8) == *(int32_t *)0x180782728) {
        iVar1 = *(int64_t *)(arg2 + 0x20);
    }
    if (iVar1 != 0) {
        iVar1 = fcn.1800ac7f0(arg1 + 0xe8, iVar1 + 0x20);
        piVar3 = (int64_t *)(iVar1 + 8);
        if (iVar1 == 0) {
            piVar3 = (int64_t *)0x0;
        }
        if (piVar3 != (int64_t *)0x0) {
            iVar1 = *piVar3;
code_r0x0001800cc715:
            fcn.1800caf50(arg1, arg2, iVar1);
        }
    }
code_r0x0001800cc720:
    return 1;
}

// ============================================================
// Function: FUN_1800cc880
// Address: 0x1800cc880
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800cc880(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    fcn.1800cc8c0();
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x110);
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800cc8c0
// Address: 0x1800cc8c0
// Size: 163 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800cc8c0(int64_t arg1)
{
    int64_t var_8h;
    
    if (*(int64_t *)(arg1 + 0xe8) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0xe8) = 0;
        *(undefined8 *)(arg1 + 0xf0) = 0;
    }
    if (*(int64_t *)(arg1 + 0xc0) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0xc0) = 0;
        *(undefined8 *)(arg1 + 200) = 0;
    }
    if (*(int64_t *)(arg1 + 0x98) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x98) = 0;
        *(undefined8 *)(arg1 + 0xa0) = 0;
    }
    func_0x00018002a260(arg1 + 0x80);
    if (*(int64_t *)(arg1 + 0x58) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x58) = 0;
        *(undefined8 *)(arg1 + 0x60) = 0;
    }
    *(undefined8 *)arg1 = 0x18063f2c0;
    return;
}

// ============================================================
// Function: FUN_1800cc970
// Address: 0x1800cc970
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800cc970(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t *puVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar3 * 3) >> 2) || (iVar2 = fcn.1800ac7f0(), iVar2 != 0))
    goto code_r0x0001800ccaf4;
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar3 == 0) {
        uVar7 = 0x10;
        iVar3 = func_0x000180459890(0x100);
        uVar4 = 0;
        iVar2 = iVar3;
        uVar9 = 0x10;
code_r0x0001800cca10:
        do {
            uVar5 = uVar4 + 1;
            *(uint64_t *)(iVar2 + uVar4 * 0x10) = *(uint64_t *)(arg1 + 0x18);
            *(undefined8 *)(iVar2 + 8 + uVar4 * 0x10) = 0;
            uVar4 = uVar5;
        } while (uVar5 < uVar7);
    } else {
        uVar7 = iVar3 * 2;
        if (uVar7 == 0) {
            iVar3 = 0;
            uVar9 = 0;
        } else {
            iVar3 = func_0x000180459890(iVar3 << 5);
            uVar4 = 0;
            iVar2 = iVar3;
            uVar9 = uVar7;
            if (uVar7 != 0) goto code_r0x0001800cca10;
        }
    }
    uVar7 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar4 = *(uint64_t *)(*(int64_t *)arg1 + uVar7 * 0x10);
            if (uVar4 != *(uint64_t *)(arg1 + 0x18)) {
                uVar5 = (uVar4 >> 5 ^ uVar4) >> 4;
                uVar6 = 0;
                do {
                    uVar5 = uVar5 & uVar9 - 1;
                    puVar8 = (uint64_t *)(uVar5 * 0x10 + iVar3);
                    if (*puVar8 == uVar1) {
                        *puVar8 = uVar4;
                        goto code_r0x0001800ccab0;
                    }
                    if (*puVar8 == uVar4) goto code_r0x0001800ccab0;
                    uVar5 = uVar5 + 1 + uVar6;
                    uVar6 = uVar6 + 1;
                } while (uVar6 <= uVar9 - 1);
                puVar8 = (uint64_t *)0x0;
code_r0x0001800ccab0:
                iVar2 = *(int64_t *)arg1;
                *puVar8 = *(uint64_t *)(iVar2 + uVar7 * 0x10);
                puVar8[1] = *(uint64_t *)(iVar2 + 8 + uVar7 * 0x10);
            }
            uVar7 = uVar7 + 1;
        } while (uVar7 < *(uint64_t *)(arg1 + 8));
    }
    iVar2 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar3;
    *(uint64_t *)(arg1 + 8) = uVar9;
    if (iVar2 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800ccaf4:
    iVar3 = func_0x0001800ac6e0(arg1, arg2);
    return iVar3 + 8;
}

// ============================================================
// Function: FUN_1800cc9a3
// Address: 0x1800cc9a3
// Size: 10 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800cc970(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t *puVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar3 * 3) >> 2) || (iVar2 = fcn.1800ac7f0(), iVar2 != 0))
    goto code_r0x0001800ccaf4;
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar3 == 0) {
        uVar7 = 0x10;
        iVar3 = func_0x000180459890(0x100);
        uVar4 = 0;
        iVar2 = iVar3;
        uVar9 = 0x10;
code_r0x0001800cca10:
        do {
            uVar5 = uVar4 + 1;
            *(uint64_t *)(iVar2 + uVar4 * 0x10) = *(uint64_t *)(arg1 + 0x18);
            *(undefined8 *)(iVar2 + 8 + uVar4 * 0x10) = 0;
            uVar4 = uVar5;
        } while (uVar5 < uVar7);
    } else {
        uVar7 = iVar3 * 2;
        if (uVar7 == 0) {
            iVar3 = 0;
            uVar9 = 0;
        } else {
            iVar3 = func_0x000180459890(iVar3 << 5);
            uVar4 = 0;
            iVar2 = iVar3;
            uVar9 = uVar7;
            if (uVar7 != 0) goto code_r0x0001800cca10;
        }
    }
    uVar7 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar4 = *(uint64_t *)(*(int64_t *)arg1 + uVar7 * 0x10);
            if (uVar4 != *(uint64_t *)(arg1 + 0x18)) {
                uVar5 = (uVar4 >> 5 ^ uVar4) >> 4;
                uVar6 = 0;
                do {
                    uVar5 = uVar5 & uVar9 - 1;
                    puVar8 = (uint64_t *)(uVar5 * 0x10 + iVar3);
                    if (*puVar8 == uVar1) {
                        *puVar8 = uVar4;
                        goto code_r0x0001800ccab0;
                    }
                    if (*puVar8 == uVar4) goto code_r0x0001800ccab0;
                    uVar5 = uVar5 + 1 + uVar6;
                    uVar6 = uVar6 + 1;
                } while (uVar6 <= uVar9 - 1);
                puVar8 = (uint64_t *)0x0;
code_r0x0001800ccab0:
                iVar2 = *(int64_t *)arg1;
                *puVar8 = *(uint64_t *)(iVar2 + uVar7 * 0x10);
                puVar8[1] = *(uint64_t *)(iVar2 + 8 + uVar7 * 0x10);
            }
            uVar7 = uVar7 + 1;
        } while (uVar7 < *(uint64_t *)(arg1 + 8));
    }
    iVar2 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar3;
    *(uint64_t *)(arg1 + 8) = uVar9;
    if (iVar2 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800ccaf4:
    iVar3 = func_0x0001800ac6e0(arg1, arg2);
    return iVar3 + 8;
}

// ============================================================
// Function: FUN_1800cc9ad
// Address: 0x1800cc9ad
// Size: 163 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800cc970(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t *puVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar3 * 3) >> 2) || (iVar2 = fcn.1800ac7f0(), iVar2 != 0))
    goto code_r0x0001800ccaf4;
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar3 == 0) {
        uVar7 = 0x10;
        iVar3 = func_0x000180459890(0x100);
        uVar4 = 0;
        iVar2 = iVar3;
        uVar9 = 0x10;
code_r0x0001800cca10:
        do {
            uVar5 = uVar4 + 1;
            *(uint64_t *)(iVar2 + uVar4 * 0x10) = *(uint64_t *)(arg1 + 0x18);
            *(undefined8 *)(iVar2 + 8 + uVar4 * 0x10) = 0;
            uVar4 = uVar5;
        } while (uVar5 < uVar7);
    } else {
        uVar7 = iVar3 * 2;
        if (uVar7 == 0) {
            iVar3 = 0;
            uVar9 = 0;
        } else {
            iVar3 = func_0x000180459890(iVar3 << 5);
            uVar4 = 0;
            iVar2 = iVar3;
            uVar9 = uVar7;
            if (uVar7 != 0) goto code_r0x0001800cca10;
        }
    }
    uVar7 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar4 = *(uint64_t *)(*(int64_t *)arg1 + uVar7 * 0x10);
            if (uVar4 != *(uint64_t *)(arg1 + 0x18)) {
                uVar5 = (uVar4 >> 5 ^ uVar4) >> 4;
                uVar6 = 0;
                do {
                    uVar5 = uVar5 & uVar9 - 1;
                    puVar8 = (uint64_t *)(uVar5 * 0x10 + iVar3);
                    if (*puVar8 == uVar1) {
                        *puVar8 = uVar4;
                        goto code_r0x0001800ccab0;
                    }
                    if (*puVar8 == uVar4) goto code_r0x0001800ccab0;
                    uVar5 = uVar5 + 1 + uVar6;
                    uVar6 = uVar6 + 1;
                } while (uVar6 <= uVar9 - 1);
                puVar8 = (uint64_t *)0x0;
code_r0x0001800ccab0:
                iVar2 = *(int64_t *)arg1;
                *puVar8 = *(uint64_t *)(iVar2 + uVar7 * 0x10);
                puVar8[1] = *(uint64_t *)(iVar2 + 8 + uVar7 * 0x10);
            }
            uVar7 = uVar7 + 1;
        } while (uVar7 < *(uint64_t *)(arg1 + 8));
    }
    iVar2 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar3;
    *(uint64_t *)(arg1 + 8) = uVar9;
    if (iVar2 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800ccaf4:
    iVar3 = func_0x0001800ac6e0(arg1, arg2);
    return iVar3 + 8;
}

// ============================================================
// Function: FUN_1800cca50
// Address: 0x1800cca50
// Size: 159 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800cc970(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t *puVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar3 * 3) >> 2) || (iVar2 = fcn.1800ac7f0(), iVar2 != 0))
    goto code_r0x0001800ccaf4;
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar3 == 0) {
        uVar7 = 0x10;
        iVar3 = func_0x000180459890(0x100);
        uVar4 = 0;
        iVar2 = iVar3;
        uVar9 = 0x10;
code_r0x0001800cca10:
        do {
            uVar5 = uVar4 + 1;
            *(uint64_t *)(iVar2 + uVar4 * 0x10) = *(uint64_t *)(arg1 + 0x18);
            *(undefined8 *)(iVar2 + 8 + uVar4 * 0x10) = 0;
            uVar4 = uVar5;
        } while (uVar5 < uVar7);
    } else {
        uVar7 = iVar3 * 2;
        if (uVar7 == 0) {
            iVar3 = 0;
            uVar9 = 0;
        } else {
            iVar3 = func_0x000180459890(iVar3 << 5);
            uVar4 = 0;
            iVar2 = iVar3;
            uVar9 = uVar7;
            if (uVar7 != 0) goto code_r0x0001800cca10;
        }
    }
    uVar7 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar4 = *(uint64_t *)(*(int64_t *)arg1 + uVar7 * 0x10);
            if (uVar4 != *(uint64_t *)(arg1 + 0x18)) {
                uVar5 = (uVar4 >> 5 ^ uVar4) >> 4;
                uVar6 = 0;
                do {
                    uVar5 = uVar5 & uVar9 - 1;
                    puVar8 = (uint64_t *)(uVar5 * 0x10 + iVar3);
                    if (*puVar8 == uVar1) {
                        *puVar8 = uVar4;
                        goto code_r0x0001800ccab0;
                    }
                    if (*puVar8 == uVar4) goto code_r0x0001800ccab0;
                    uVar5 = uVar5 + 1 + uVar6;
                    uVar6 = uVar6 + 1;
                } while (uVar6 <= uVar9 - 1);
                puVar8 = (uint64_t *)0x0;
code_r0x0001800ccab0:
                iVar2 = *(int64_t *)arg1;
                *puVar8 = *(uint64_t *)(iVar2 + uVar7 * 0x10);
                puVar8[1] = *(uint64_t *)(iVar2 + 8 + uVar7 * 0x10);
            }
            uVar7 = uVar7 + 1;
        } while (uVar7 < *(uint64_t *)(arg1 + 8));
    }
    iVar2 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar3;
    *(uint64_t *)(arg1 + 8) = uVar9;
    if (iVar2 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800ccaf4:
    iVar3 = func_0x0001800ac6e0(arg1, arg2);
    return iVar3 + 8;
}

// ============================================================
// Function: FUN_1800ccaef
// Address: 0x1800ccaef
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800cc970(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t *puVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar3 * 3) >> 2) || (iVar2 = fcn.1800ac7f0(), iVar2 != 0))
    goto code_r0x0001800ccaf4;
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar3 == 0) {
        uVar7 = 0x10;
        iVar3 = func_0x000180459890(0x100);
        uVar4 = 0;
        iVar2 = iVar3;
        uVar9 = 0x10;
code_r0x0001800cca10:
        do {
            uVar5 = uVar4 + 1;
            *(uint64_t *)(iVar2 + uVar4 * 0x10) = *(uint64_t *)(arg1 + 0x18);
            *(undefined8 *)(iVar2 + 8 + uVar4 * 0x10) = 0;
            uVar4 = uVar5;
        } while (uVar5 < uVar7);
    } else {
        uVar7 = iVar3 * 2;
        if (uVar7 == 0) {
            iVar3 = 0;
            uVar9 = 0;
        } else {
            iVar3 = func_0x000180459890(iVar3 << 5);
            uVar4 = 0;
            iVar2 = iVar3;
            uVar9 = uVar7;
            if (uVar7 != 0) goto code_r0x0001800cca10;
        }
    }
    uVar7 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar4 = *(uint64_t *)(*(int64_t *)arg1 + uVar7 * 0x10);
            if (uVar4 != *(uint64_t *)(arg1 + 0x18)) {
                uVar5 = (uVar4 >> 5 ^ uVar4) >> 4;
                uVar6 = 0;
                do {
                    uVar5 = uVar5 & uVar9 - 1;
                    puVar8 = (uint64_t *)(uVar5 * 0x10 + iVar3);
                    if (*puVar8 == uVar1) {
                        *puVar8 = uVar4;
                        goto code_r0x0001800ccab0;
                    }
                    if (*puVar8 == uVar4) goto code_r0x0001800ccab0;
                    uVar5 = uVar5 + 1 + uVar6;
                    uVar6 = uVar6 + 1;
                } while (uVar6 <= uVar9 - 1);
                puVar8 = (uint64_t *)0x0;
code_r0x0001800ccab0:
                iVar2 = *(int64_t *)arg1;
                *puVar8 = *(uint64_t *)(iVar2 + uVar7 * 0x10);
                puVar8[1] = *(uint64_t *)(iVar2 + 8 + uVar7 * 0x10);
            }
            uVar7 = uVar7 + 1;
        } while (uVar7 < *(uint64_t *)(arg1 + 8));
    }
    iVar2 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar3;
    *(uint64_t *)(arg1 + 8) = uVar9;
    if (iVar2 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800ccaf4:
    iVar3 = func_0x0001800ac6e0(arg1, arg2);
    return iVar3 + 8;
}

// ============================================================
// Function: FUN_1800ccb10
// Address: 0x1800ccb10
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t * fcn.1800ccb10(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t *puVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar10 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar10 * 3) >> 2) || (iVar3 = func_0x0001800c1560(), iVar3 != 0))
    goto code_r0x0001800c15e0;
    if (iVar10 == 0) {
        uVar8 = *(uint64_t *)(arg1 + 0x18);
        iVar10 = 0x10;
code_r0x0001800ccb83:
        iVar3 = func_0x000180459890(iVar10 * 8);
        func_0x0001800ccc60(iVar3, iVar10, arg1 + 0x18);
    } else {
        uVar8 = *(uint64_t *)(arg1 + 0x18);
        iVar10 = iVar10 * 2;
        if (iVar10 != 0) goto code_r0x0001800ccb83;
        iVar3 = 0;
        iVar10 = 0;
    }
    uVar9 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar5 = *(uint64_t *)(*(int64_t *)arg1 + uVar9 * 8);
            if (uVar5 != *(uint64_t *)(arg1 + 0x18)) {
                uVar4 = (uVar5 >> 5 ^ uVar5) >> 4;
                uVar6 = 0;
                do {
                    uVar4 = uVar4 & iVar10 - 1U;
                    uVar1 = *(uint64_t *)(iVar3 + uVar4 * 8);
                    puVar7 = (uint64_t *)(iVar3 + uVar4 * 8);
                    if (uVar1 == uVar8) {
                        *puVar7 = uVar5;
                        goto code_r0x0001800ccc0a;
                    }
                    if (uVar1 == uVar5) goto code_r0x0001800ccc0a;
                    uVar4 = uVar4 + 1 + uVar6;
                    uVar6 = uVar6 + 1;
                } while (uVar6 <= iVar10 - 1U);
                puVar7 = (uint64_t *)0x0;
code_r0x0001800ccc0a:
                *puVar7 = *(uint64_t *)(*(int64_t *)arg1 + uVar9 * 8);
            }
            uVar9 = uVar9 + 1;
        } while (uVar9 < *(uint64_t *)(arg1 + 8));
    }
    iVar2 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar3;
    *(int64_t *)(arg1 + 8) = iVar10;
    if (iVar2 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800c15e0:
    uVar8 = *(uint64_t *)arg2;
    uVar4 = *(int64_t *)(arg1 + 8) - 1;
    uVar9 = (uVar8 >> 5 ^ uVar8) >> 4;
    uVar5 = 0;
    while( true ) {
        uVar9 = uVar9 & uVar4;
        uVar6 = *(uint64_t *)(*(int64_t *)arg1 + uVar9 * 8);
        puVar7 = (uint64_t *)(*(int64_t *)arg1 + uVar9 * 8);
        if (uVar6 == *(uint64_t *)(arg1 + 0x18)) {
            *puVar7 = uVar8;
            *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
            return puVar7;
        }
        if (uVar6 == uVar8) break;
        uVar9 = uVar9 + 1 + uVar5;
        uVar5 = uVar5 + 1;
        if (uVar4 < uVar5) {
            return (uint64_t *)0x0;
        }
    }
    return puVar7;
}

// ============================================================
// Function: FUN_1800ccb43
// Address: 0x1800ccb43
// Size: 253 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t * fcn.1800ccb10(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t *puVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar10 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar10 * 3) >> 2) || (iVar3 = func_0x0001800c1560(), iVar3 != 0))
    goto code_r0x0001800c15e0;
    if (iVar10 == 0) {
        uVar8 = *(uint64_t *)(arg1 + 0x18);
        iVar10 = 0x10;
code_r0x0001800ccb83:
        iVar3 = func_0x000180459890(iVar10 * 8);
        func_0x0001800ccc60(iVar3, iVar10, arg1 + 0x18);
    } else {
        uVar8 = *(uint64_t *)(arg1 + 0x18);
        iVar10 = iVar10 * 2;
        if (iVar10 != 0) goto code_r0x0001800ccb83;
        iVar3 = 0;
        iVar10 = 0;
    }
    uVar9 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar5 = *(uint64_t *)(*(int64_t *)arg1 + uVar9 * 8);
            if (uVar5 != *(uint64_t *)(arg1 + 0x18)) {
                uVar4 = (uVar5 >> 5 ^ uVar5) >> 4;
                uVar6 = 0;
                do {
                    uVar4 = uVar4 & iVar10 - 1U;
                    uVar1 = *(uint64_t *)(iVar3 + uVar4 * 8);
                    puVar7 = (uint64_t *)(iVar3 + uVar4 * 8);
                    if (uVar1 == uVar8) {
                        *puVar7 = uVar5;
                        goto code_r0x0001800ccc0a;
                    }
                    if (uVar1 == uVar5) goto code_r0x0001800ccc0a;
                    uVar4 = uVar4 + 1 + uVar6;
                    uVar6 = uVar6 + 1;
                } while (uVar6 <= iVar10 - 1U);
                puVar7 = (uint64_t *)0x0;
code_r0x0001800ccc0a:
                *puVar7 = *(uint64_t *)(*(int64_t *)arg1 + uVar9 * 8);
            }
            uVar9 = uVar9 + 1;
        } while (uVar9 < *(uint64_t *)(arg1 + 8));
    }
    iVar2 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar3;
    *(int64_t *)(arg1 + 8) = iVar10;
    if (iVar2 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800c15e0:
    uVar8 = *(uint64_t *)arg2;
    uVar4 = *(int64_t *)(arg1 + 8) - 1;
    uVar9 = (uVar8 >> 5 ^ uVar8) >> 4;
    uVar5 = 0;
    while( true ) {
        uVar9 = uVar9 & uVar4;
        uVar6 = *(uint64_t *)(*(int64_t *)arg1 + uVar9 * 8);
        puVar7 = (uint64_t *)(*(int64_t *)arg1 + uVar9 * 8);
        if (uVar6 == *(uint64_t *)(arg1 + 0x18)) {
            *puVar7 = uVar8;
            *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
            return puVar7;
        }
        if (uVar6 == uVar8) break;
        uVar9 = uVar9 + 1 + uVar5;
        uVar5 = uVar5 + 1;
        if (uVar4 < uVar5) {
            return (uint64_t *)0x0;
        }
    }
    return puVar7;
}

// ============================================================
// Function: FUN_1800ccc40
// Address: 0x1800ccc40
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t * fcn.1800ccb10(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t *puVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar10 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar10 * 3) >> 2) || (iVar3 = func_0x0001800c1560(), iVar3 != 0))
    goto code_r0x0001800c15e0;
    if (iVar10 == 0) {
        uVar8 = *(uint64_t *)(arg1 + 0x18);
        iVar10 = 0x10;
code_r0x0001800ccb83:
        iVar3 = func_0x000180459890(iVar10 * 8);
        func_0x0001800ccc60(iVar3, iVar10, arg1 + 0x18);
    } else {
        uVar8 = *(uint64_t *)(arg1 + 0x18);
        iVar10 = iVar10 * 2;
        if (iVar10 != 0) goto code_r0x0001800ccb83;
        iVar3 = 0;
        iVar10 = 0;
    }
    uVar9 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar5 = *(uint64_t *)(*(int64_t *)arg1 + uVar9 * 8);
            if (uVar5 != *(uint64_t *)(arg1 + 0x18)) {
                uVar4 = (uVar5 >> 5 ^ uVar5) >> 4;
                uVar6 = 0;
                do {
                    uVar4 = uVar4 & iVar10 - 1U;
                    uVar1 = *(uint64_t *)(iVar3 + uVar4 * 8);
                    puVar7 = (uint64_t *)(iVar3 + uVar4 * 8);
                    if (uVar1 == uVar8) {
                        *puVar7 = uVar5;
                        goto code_r0x0001800ccc0a;
                    }
                    if (uVar1 == uVar5) goto code_r0x0001800ccc0a;
                    uVar4 = uVar4 + 1 + uVar6;
                    uVar6 = uVar6 + 1;
                } while (uVar6 <= iVar10 - 1U);
                puVar7 = (uint64_t *)0x0;
code_r0x0001800ccc0a:
                *puVar7 = *(uint64_t *)(*(int64_t *)arg1 + uVar9 * 8);
            }
            uVar9 = uVar9 + 1;
        } while (uVar9 < *(uint64_t *)(arg1 + 8));
    }
    iVar2 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar3;
    *(int64_t *)(arg1 + 8) = iVar10;
    if (iVar2 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800c15e0:
    uVar8 = *(uint64_t *)arg2;
    uVar4 = *(int64_t *)(arg1 + 8) - 1;
    uVar9 = (uVar8 >> 5 ^ uVar8) >> 4;
    uVar5 = 0;
    while( true ) {
        uVar9 = uVar9 & uVar4;
        uVar6 = *(uint64_t *)(*(int64_t *)arg1 + uVar9 * 8);
        puVar7 = (uint64_t *)(*(int64_t *)arg1 + uVar9 * 8);
        if (uVar6 == *(uint64_t *)(arg1 + 0x18)) {
            *puVar7 = uVar8;
            *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
            return puVar7;
        }
        if (uVar6 == uVar8) break;
        uVar9 = uVar9 + 1 + uVar5;
        uVar5 = uVar5 + 1;
        if (uVar4 < uVar5) {
            return (uint64_t *)0x0;
        }
    }
    return puVar7;
}

// ============================================================
// Function: FUN_1800ccc60
// Address: 0x1800ccc60
// Size: 12 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800ccc60(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    undefined8 *puVar4;
    int64_t var_8h;
    
    if (arg2 != 0) {
        uVar3 = 0;
        if ((uint64_t)arg2 < 2) goto code_r0x0001800cccc0;
        if (((uint64_t)arg1 <= (uint64_t)arg3) && ((uint64_t)arg3 <= (uint64_t)(arg1 + (arg2 + -1) * 8)))
        goto code_r0x0001800cccc0;
        uVar1 = *(undefined8 *)arg3;
        do {
            uVar3 = uVar3 + 2;
        } while (uVar3 < (arg2 & 0xfffffffffffffffeU));
        puVar4 = (undefined8 *)arg1;
        for (uVar2 = (((uint64_t)arg2 >> 1) << 4) >> 3; uVar2 != 0; uVar2 = uVar2 - 1) {
            *puVar4 = uVar1;
            puVar4 = puVar4 + 1;
        }
        for (; uVar3 < (uint64_t)arg2; uVar3 = uVar3 + 1) {
code_r0x0001800cccc0:
            *(undefined8 *)(arg1 + uVar3 * 8) = *(undefined8 *)arg3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800ccc6c
// Address: 0x1800ccc6c
// Size: 103 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800ccc60(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    undefined8 *puVar4;
    int64_t var_8h;
    
    if (arg2 != 0) {
        uVar3 = 0;
        if ((uint64_t)arg2 < 2) goto code_r0x0001800cccc0;
        if (((uint64_t)arg1 <= (uint64_t)arg3) && ((uint64_t)arg3 <= (uint64_t)(arg1 + (arg2 + -1) * 8)))
        goto code_r0x0001800cccc0;
        uVar1 = *(undefined8 *)arg3;
        do {
            uVar3 = uVar3 + 2;
        } while (uVar3 < (arg2 & 0xfffffffffffffffeU));
        puVar4 = (undefined8 *)arg1;
        for (uVar2 = (((uint64_t)arg2 >> 1) << 4) >> 3; uVar2 != 0; uVar2 = uVar2 - 1) {
            *puVar4 = uVar1;
            puVar4 = puVar4 + 1;
        }
        for (; uVar3 < (uint64_t)arg2; uVar3 = uVar3 + 1) {
code_r0x0001800cccc0:
            *(undefined8 *)(arg1 + uVar3 * 8) = *(undefined8 *)arg3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800cccd3
// Address: 0x1800cccd3
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800ccc60(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    undefined8 *puVar4;
    int64_t var_8h;
    
    if (arg2 != 0) {
        uVar3 = 0;
        if ((uint64_t)arg2 < 2) goto code_r0x0001800cccc0;
        if (((uint64_t)arg1 <= (uint64_t)arg3) && ((uint64_t)arg3 <= (uint64_t)(arg1 + (arg2 + -1) * 8)))
        goto code_r0x0001800cccc0;
        uVar1 = *(undefined8 *)arg3;
        do {
            uVar3 = uVar3 + 2;
        } while (uVar3 < (arg2 & 0xfffffffffffffffeU));
        puVar4 = (undefined8 *)arg1;
        for (uVar2 = (((uint64_t)arg2 >> 1) << 4) >> 3; uVar2 != 0; uVar2 = uVar2 - 1) {
            *puVar4 = uVar1;
            puVar4 = puVar4 + 1;
        }
        for (; uVar3 < (uint64_t)arg2; uVar3 = uVar3 + 1) {
code_r0x0001800cccc0:
            *(undefined8 *)(arg1 + uVar3 * 8) = *(undefined8 *)arg3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800ccce0
// Address: 0x1800ccce0
// Size: 104 bytes
// ============================================================
void fcn.1800ccce0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    undefined4 *puVar2;
    
    iVar1 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782728) {
        iVar1 = arg2;
    }
    if (iVar1 != 0) {
        iVar1 = fcn.1800cd7a0(*(undefined8 *)(arg1 + 0x10), iVar1 + 0x20);
        *(undefined *)(iVar1 + 8) = 1;
        return;
    }
    iVar1 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782738) {
        iVar1 = arg2;
    }
    if (iVar1 != 0) {
        puVar2 = (undefined4 *)fcn.1800cd960(*(undefined8 *)(arg1 + 8), iVar1 + 0x20);
        *puVar2 = 2;
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001800ccd45. Too many branches
    // WARNING: Treating indirect jump as call
    (***(code ***)arg2)(arg2, arg1);
    return;
}

// ============================================================
// Function: FUN_1800ccd50
// Address: 0x1800ccd50
// Size: 1111 bytes
// ============================================================
undefined8 fcn.1800ccd50(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    undefined4 *puVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    uint64_t uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    uint64_t *puVar16;
    uint64_t uVar17;
    uint64_t uVar18;
    int64_t iVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    uVar9 = *(uint64_t *)(arg2 + 0x30);
    if (uVar9 != 0) {
        uVar17 = 0;
        do {
            if (*(uint64_t *)(arg2 + 0x40) <= uVar17) break;
            piVar3 = *(int64_t **)(arg1 + 0x10);
            iVar11 = piVar3[1];
            uVar4 = *(undefined8 *)(*(int64_t *)(arg2 + 0x38) + uVar17 * 8);
            iVar19 = *(int64_t *)(arg2 + 0x28);
            if (((uint64_t)(iVar11 * 3) >> 2 <= (uint64_t)piVar3[2]) &&
               (iVar10 = func_0x0001800ac770(piVar3), iVar10 == 0)) {
                uVar9 = piVar3[3];
                if (iVar11 == 0) {
                    uVar15 = 0x10;
                    iVar10 = func_0x000180459890(0x180);
                    uVar13 = 0;
                    uVar18 = 0x10;
                    iVar11 = iVar10;
code_r0x0001800cce70:
                    do {
                        iVar1 = uVar13 * 0x18;
                        uVar13 = uVar13 + 1;
                        *(int64_t *)(iVar1 + iVar10) = piVar3[3];
                        *(undefined (*) [16])(iVar1 + 8 + iVar10) = ZEXT816(0);
                        *(undefined8 *)(iVar1 + 8 + iVar10) = 0;
                        *(undefined2 *)(iVar1 + 0x10 + iVar10) = 0;
                    } while (uVar13 < uVar15);
                } else {
                    uVar15 = iVar11 * 2;
                    if (uVar15 == 0) {
                        uVar18 = 0;
                        iVar11 = 0;
                    } else {
                        iVar10 = func_0x000180459890(iVar11 * 0x30);
                        uVar13 = 0;
                        uVar18 = uVar15;
                        iVar11 = iVar10;
                        if (uVar15 != 0) goto code_r0x0001800cce70;
                    }
                }
                uVar15 = 0;
                if (piVar3[1] != 0) {
                    do {
                        iVar10 = uVar15 * 0x18;
                        uVar13 = *(uint64_t *)(iVar10 + *piVar3);
                        if (uVar13 != piVar3[3]) {
                            uVar12 = (uVar13 >> 5 ^ uVar13) >> 4;
                            uVar14 = 0;
                            do {
                                uVar12 = uVar12 & uVar18 - 1;
                                puVar16 = (uint64_t *)(iVar11 + uVar12 * 0x18);
                                uVar5 = *(uint64_t *)(iVar11 + uVar12 * 0x18);
                                if (uVar5 == uVar9) {
                                    *puVar16 = uVar13;
                                    goto code_r0x0001800ccf27;
                                }
                                if (uVar5 == uVar13) goto code_r0x0001800ccf27;
                                uVar12 = uVar12 + 1 + uVar14;
                                uVar14 = uVar14 + 1;
                            } while (uVar14 <= uVar18 - 1);
                            puVar16 = (uint64_t *)0x0;
code_r0x0001800ccf27:
                            iVar1 = *piVar3;
                            *puVar16 = *(uint64_t *)(iVar1 + iVar10);
                            puVar2 = (undefined4 *)(iVar1 + 8 + iVar10);
                            uVar6 = puVar2[1];
                            uVar7 = puVar2[2];
                            uVar8 = puVar2[3];
                            *(undefined4 *)(puVar16 + 1) = *puVar2;
                            *(undefined4 *)((int64_t)puVar16 + 0xc) = uVar6;
                            *(undefined4 *)(puVar16 + 2) = uVar7;
                            *(undefined4 *)((int64_t)puVar16 + 0x14) = uVar8;
                        }
                        uVar15 = uVar15 + 1;
                    } while (uVar15 < (uint64_t)piVar3[1]);
                }
                iVar10 = *piVar3;
                *piVar3 = iVar11;
                piVar3[1] = uVar18;
                if (iVar10 != 0) {
                    func_0x0001800f4640();
                }
            }
            iVar11 = func_0x0001800c14e0(piVar3, iVar19 + uVar17 * 8);
            uVar17 = uVar17 + 1;
            *(undefined8 *)(iVar11 + 8) = uVar4;
            uVar9 = *(uint64_t *)(arg2 + 0x30);
        } while (uVar17 < uVar9);
    }
    uVar17 = *(uint64_t *)(arg2 + 0x40);
    if (uVar17 < uVar9) {
        do {
            piVar3 = *(int64_t **)(arg1 + 0x10);
            iVar11 = *(int64_t *)(arg2 + 0x28);
            iVar19 = piVar3[1];
            if (((uint64_t)(iVar19 * 3) >> 2 <= (uint64_t)piVar3[2]) &&
               (iVar10 = func_0x0001800ac770(piVar3), iVar10 == 0)) {
                uVar9 = piVar3[3];
                if (iVar19 == 0) {
                    uVar15 = 0x10;
                    iVar10 = func_0x000180459890(0x180);
                    uVar13 = 0;
                    uVar18 = 0x10;
                    iVar19 = iVar10;
code_r0x0001800cd070:
                    do {
                        iVar1 = uVar13 * 0x18;
                        uVar13 = uVar13 + 1;
                        *(int64_t *)(iVar1 + iVar10) = piVar3[3];
                        *(undefined (*) [16])(iVar1 + 8 + iVar10) = ZEXT816(0);
                        *(undefined8 *)(iVar1 + 8 + iVar10) = 0;
                        *(undefined2 *)(iVar1 + 0x10 + iVar10) = 0;
                    } while (uVar13 < uVar15);
                } else {
                    uVar15 = iVar19 * 2;
                    if (uVar15 == 0) {
                        uVar18 = 0;
                        iVar19 = 0;
                    } else {
                        iVar10 = func_0x000180459890(iVar19 * 0x30);
                        uVar13 = 0;
                        uVar18 = uVar15;
                        iVar19 = iVar10;
                        if (uVar15 != 0) goto code_r0x0001800cd070;
                    }
                }
                uVar15 = 0;
                if (piVar3[1] != 0) {
                    do {
                        iVar10 = uVar15 * 0x18;
                        uVar13 = *(uint64_t *)(iVar10 + *piVar3);
                        if (uVar13 != piVar3[3]) {
                            uVar12 = (uVar13 >> 5 ^ uVar13) >> 4;
                            uVar14 = 0;
                            do {
                                uVar12 = uVar12 & uVar18 - 1;
                                puVar16 = (uint64_t *)(iVar19 + uVar12 * 0x18);
                                uVar5 = *(uint64_t *)(iVar19 + uVar12 * 0x18);
                                if (uVar5 == uVar9) {
                                    *puVar16 = uVar13;
                                    goto code_r0x0001800cd127;
                                }
                                if (uVar5 == uVar13) goto code_r0x0001800cd127;
                                uVar12 = uVar12 + 1 + uVar14;
                                uVar14 = uVar14 + 1;
                            } while (uVar14 <= uVar18 - 1);
                            puVar16 = (uint64_t *)0x0;
code_r0x0001800cd127:
                            iVar1 = *piVar3;
                            *puVar16 = *(uint64_t *)(iVar1 + iVar10);
                            puVar2 = (undefined4 *)(iVar1 + 8 + iVar10);
                            uVar6 = puVar2[1];
                            uVar7 = puVar2[2];
                            uVar8 = puVar2[3];
                            *(undefined4 *)(puVar16 + 1) = *puVar2;
                            *(undefined4 *)((int64_t)puVar16 + 0xc) = uVar6;
                            *(undefined4 *)(puVar16 + 2) = uVar7;
                            *(undefined4 *)((int64_t)puVar16 + 0x14) = uVar8;
                        }
                        uVar15 = uVar15 + 1;
                    } while (uVar15 < (uint64_t)piVar3[1]);
                }
                iVar10 = *piVar3;
                *piVar3 = iVar19;
                piVar3[1] = uVar18;
                if (iVar10 != 0) {
                    func_0x0001800f4640();
                }
            }
            iVar11 = func_0x0001800c14e0(piVar3, iVar11 + uVar17 * 8);
            uVar17 = uVar17 + 1;
            *(undefined8 *)(iVar11 + 8) = 0;
        } while (uVar17 < *(uint64_t *)(arg2 + 0x30));
    }
    return 1;
}

// ============================================================
// Function: FUN_1800cd1b0
// Address: 0x1800cd1b0
// Size: 187 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.1800cd1b0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    undefined4 *in_RAX;
    undefined8 *puVar2;
    uint64_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar3 = 0;
    if (*(int64_t *)(arg2 + 0x30) != 0) {
        do {
            puVar1 = *(undefined8 **)(*(int64_t *)(arg2 + 0x28) + uVar3 * 8);
            puVar2 = (undefined8 *)0x0;
            if (*(int32_t *)(puVar1 + 1) == *(int32_t *)0x180782728) {
                puVar2 = puVar1;
            }
            if (puVar2 == (undefined8 *)0x0) {
                puVar2 = (undefined8 *)0x0;
                if (*(int32_t *)(puVar1 + 1) == *(int32_t *)0x180782738) {
                    puVar2 = puVar1;
                }
                if (puVar2 == (undefined8 *)0x0) {
                    in_RAX = (undefined4 *)(**(code **)*puVar1)();
                } else {
                    in_RAX = (undefined4 *)fcn.1800cd960(*(undefined8 *)(arg1 + 8));
                    *in_RAX = 2;
                }
            } else {
                in_RAX = (undefined4 *)fcn.1800cd7a0(*(undefined8 *)(arg1 + 0x10));
                *(undefined *)(in_RAX + 2) = 1;
            }
            uVar3 = uVar3 + 1;
        } while (uVar3 < *(uint64_t *)(arg2 + 0x30));
    }
    uVar3 = 0;
    if (*(int64_t *)(arg2 + 0x40) != 0) {
        do {
            puVar1 = *(undefined8 **)(*(int64_t *)(arg2 + 0x38) + uVar3 * 8);
            in_RAX = (undefined4 *)(**(code **)*puVar1)(puVar1, arg1);
            uVar3 = uVar3 + 1;
        } while (uVar3 < *(uint64_t *)(arg2 + 0x40));
    }
    return (uint64_t)in_RAX & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800cd270
// Address: 0x1800cd270
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1800cd270(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_8h;
    
    fcn.1800ccce0(arg1, *(int64_t *)(arg2 + 0x30));
    uVar1 = (**(code **)**(undefined8 **)(arg2 + 0x38))(*(undefined8 **)(arg2 + 0x38), arg1);
    return uVar1 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800cd2b0
// Address: 0x1800cd2b0
// Size: 34 bytes
// ============================================================
undefined fcn.1800cd2b0(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    undefined8 *puVar2;
    
    uVar1 = *(undefined8 *)(arg2 + 0x30);
    puVar2 = (undefined8 *)fcn.1800cd7a0(*(undefined8 *)(arg1 + 0x10), arg2 + 0x28);
    *puVar2 = uVar1;
    return 1;
}

// ============================================================
// Function: FUN_1800cd2e0
// Address: 0x1800cd2e0
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1800cd2e0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_8h;
    
    fcn.1800ccce0(arg1, *(int64_t *)(arg2 + 0x28));
    uVar1 = (**(code **)**(undefined8 **)(arg2 + 0x30))(*(undefined8 **)(arg2 + 0x30), arg1);
    return uVar1 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800cd320
// Address: 0x1800cd320
// Size: 40 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

undefined8 fcn.1800cd320(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    int64_t iVar2;
    undefined4 *puVar3;
    int64_t *piVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    int64_t iVar17;
    uint64_t *puVar18;
    uint64_t *puVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    puVar19 = *(uint64_t **)(arg2 + 0x58);
    uVar12 = *(uint64_t *)(arg2 + 0x60);
    puVar1 = puVar19 + uVar12;
    do {
        if (puVar19 == puVar1) {
            return CONCAT71((unkint7)(uVar12 >> 8), 1);
        }
        piVar4 = *(int64_t **)(arg1 + 0x10);
        uVar5 = *puVar19;
        iVar10 = piVar4[1];
        if ((uint64_t)(iVar10 * 3) >> 2 <= (uint64_t)piVar4[2]) {
            if ((piVar4[2] != 0) && (uVar5 != piVar4[3])) {
                uVar12 = (uVar5 >> 5 ^ uVar5) >> 4;
                uVar13 = 0;
                do {
                    uVar12 = uVar12 & iVar10 - 1U;
                    uVar16 = *(uint64_t *)(*piVar4 + uVar12 * 0x18);
                    if (uVar16 == uVar5) goto code_r0x0001800cd515;
                    if (uVar16 == piVar4[3]) break;
                    uVar12 = uVar12 + 1 + uVar13;
                    uVar13 = uVar13 + 1;
                } while (uVar13 <= iVar10 - 1U);
            }
            uVar12 = piVar4[3];
            if (iVar10 == 0) {
                uVar13 = 0x10;
                iVar10 = func_0x000180459890(0x180);
                uVar14 = 0;
                iVar17 = iVar10;
                uVar16 = 0x10;
code_r0x0001800cd440:
                do {
                    iVar2 = uVar14 * 0x18;
                    uVar14 = uVar14 + 1;
                    *(int64_t *)(iVar2 + iVar17) = piVar4[3];
                    *(undefined (*) [16])(iVar2 + 8 + iVar17) = ZEXT816(0);
                    *(undefined8 *)(iVar2 + 8 + iVar17) = 0;
                    *(undefined2 *)(iVar2 + 0x10 + iVar17) = 0;
                } while (uVar14 < uVar13);
            } else {
                uVar13 = iVar10 * 2;
                if (uVar13 == 0) {
                    iVar10 = 0;
                    uVar16 = 0;
                } else {
                    iVar10 = func_0x000180459890(iVar10 * 0x30);
                    uVar14 = 0;
                    iVar17 = iVar10;
                    uVar16 = uVar13;
                    if (uVar13 != 0) goto code_r0x0001800cd440;
                }
            }
            uVar13 = 0;
            if (piVar4[1] != 0) {
                do {
                    iVar17 = uVar13 * 0x18;
                    uVar14 = *(uint64_t *)(iVar17 + *piVar4);
                    if (uVar14 != piVar4[3]) {
                        uVar11 = (uVar14 >> 5 ^ uVar14) >> 4;
                        uVar15 = 0;
                        do {
                            uVar11 = uVar11 & uVar16 - 1;
                            puVar18 = (uint64_t *)(iVar10 + uVar11 * 0x18);
                            uVar6 = *(uint64_t *)(iVar10 + uVar11 * 0x18);
                            if (uVar6 == uVar12) {
                                *puVar18 = uVar14;
                                goto code_r0x0001800cd4df;
                            }
                            if (uVar6 == uVar14) goto code_r0x0001800cd4df;
                            uVar11 = uVar11 + 1 + uVar15;
                            uVar15 = uVar15 + 1;
                        } while (uVar15 <= uVar16 - 1);
                        puVar18 = (uint64_t *)0x0;
code_r0x0001800cd4df:
                        iVar2 = *piVar4;
                        *puVar18 = *(uint64_t *)(iVar2 + iVar17);
                        puVar3 = (undefined4 *)(iVar2 + 8 + iVar17);
                        uVar7 = puVar3[1];
                        uVar8 = puVar3[2];
                        uVar9 = puVar3[3];
                        *(undefined4 *)(puVar18 + 1) = *puVar3;
                        *(undefined4 *)((int64_t)puVar18 + 0xc) = uVar7;
                        *(undefined4 *)(puVar18 + 2) = uVar8;
                        *(undefined4 *)((int64_t)puVar18 + 0x14) = uVar9;
                    }
                    uVar13 = uVar13 + 1;
                } while (uVar13 < (uint64_t)piVar4[1]);
            }
            iVar17 = *piVar4;
            *piVar4 = iVar10;
            piVar4[1] = uVar16;
            if (iVar17 != 0) {
                func_0x0001800f4640();
            }
        }
code_r0x0001800cd515:
        uVar13 = (uVar5 >> 5 ^ uVar5) >> 4;
        uVar16 = 0;
        do {
            uVar13 = uVar13 & piVar4[1] - 1U;
            puVar18 = (uint64_t *)(*piVar4 + uVar13 * 0x18);
            uVar12 = *(uint64_t *)(*piVar4 + uVar13 * 0x18);
            if (uVar12 == piVar4[3]) {
                *puVar18 = uVar5;
                piVar4[2] = piVar4[2] + 1;
                goto code_r0x0001800cd573;
            }
            if (uVar12 == uVar5) goto code_r0x0001800cd573;
            uVar13 = uVar13 + 1 + uVar16;
            uVar16 = uVar16 + 1;
        } while (uVar16 <= piVar4[1] - 1U);
        puVar18 = (uint64_t *)0x0;
code_r0x0001800cd573:
        puVar19 = puVar19 + 1;
        puVar18[1] = 0;
    } while( true );
}

