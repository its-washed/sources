// Chunk 71 - 50 functions

// ============================================================
// Function: FUN_1800ecbd0
// Address: 0x1800ecbd0
// Size: 3334 bytes
// ============================================================
int64_t fcn.1800ecbd0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4)
{
    int64_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    bool bVar11;
    bool bVar12;
    char cVar13;
    int64_t iVar14;
    int64_t *piVar15;
    int64_t **ppiVar16;
    int32_t *piVar17;
    uint64_t uVar18;
    uint64_t uVar19;
    uint64_t uVar20;
    uint64_t uVar21;
    uint64_t uVar22;
    uint64_t uVar23;
    uint64_t *puVar24;
    int64_t *piVar25;
    int64_t iVar26;
    uint64_t *puVar27;
    int64_t **ppiVar28;
    int64_t *piVar29;
    int64_t var_20h;
    uint64_t *in_stack_00000028;
    undefined8 *in_stack_00000030;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    undefined4 uStack_e0;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t *piStack_c8;
    int64_t iStack_c0;
    uint64_t uStack_b8;
    int64_t *piStack_b0;
    int64_t iStack_a8;
    uint64_t uStack_a0;
    int64_t *piStack_98;
    int64_t iStack_90;
    uint64_t uStack_88;
    undefined auStack_80 [7];
    int64_t var_79h;
    int64_t var_71h;
    int64_t var_69h;
    int64_t var_61h;
    int64_t var_59h;
    int64_t var_51h;
    int64_t var_49h;
    int64_t var_41h;
    int64_t var_39h;
    int64_t var_31h;
    int64_t var_29h;
    int64_t var_1dh;
    int64_t var_11h;
    
    piStack_b0 = (int64_t *)(arg1 + 0x3f8);
    iStack_a8 = *(int64_t *)(arg1 + 0x400) - *piStack_b0 >> 3;
    uStack_a0 = 0;
    piStack_c8 = (int64_t *)(arg1 + 0x410);
    iStack_c0 = *(int64_t *)(arg1 + 0x418) - *piStack_c8 >> 3;
    uStack_b8 = 0;
    piStack_98 = (int64_t *)(arg1 + 0x440);
    var_d8h = *(int64_t *)(arg1 + 0x448) - *piStack_98 >> 3;
    uStack_88 = 0;
    var_d0h._0_4_ = *(int32_t *)(arg1 + 0x80);
    iStack_90 = var_d8h;
    if ((int32_t)var_d0h == 0x3c) {
        uVar5 = *(undefined4 *)(undefined8 *)(arg1 + 0x84);
        uVar6 = *(undefined4 *)(arg1 + 0x88);
        unique0x100006d6 = *(undefined4 *)(arg1 + 0x8c);
        var_61h._1_4_ = *(undefined4 *)(arg1 + 0x90);
        unique0x1000070a = *(undefined4 *)(arg1 + 0x94);
        var_59h._1_4_ = *(undefined4 *)(arg1 + 0x98);
        unique0x10000722 = *(undefined4 *)(arg1 + 0x9c);
        if (arg4 != 0) {
            *(undefined8 *)arg4 = *(undefined8 *)(arg1 + 0x84);
        }
        unique0x10000c8d = uVar5;
        var_69h._1_4_ = uVar6;
        func_0x0001800f0350();
        bVar11 = false;
        bVar12 = false;
        do {
            uVar7 = *(undefined4 *)(arg1 + 0x84);
            uVar8 = *(undefined4 *)(arg1 + 0x88);
            uVar9 = *(undefined4 *)(arg1 + 0x8c);
            uVar10 = *(undefined4 *)(arg1 + 0x90);
            if (*(int32_t *)(arg1 + 0x80) == 0x119) {
                piVar25 = *(int64_t **)(arg1 + 0x98);
                func_0x0001800f0350(arg1);
            } else {
                func_0x0001800efe90(arg1, 0);
                piVar25 = *(int64_t **)(arg1 + 0x128);
            }
            iVar2 = *(int32_t *)(arg1 + 0x80);
            if ((iVar2 == 0x106) || (bVar11)) {
                bVar11 = true;
                var_d8h = -1;
                if (iVar2 == 0x106) {
                    iVar26 = *(int64_t *)(arg1 + 0x84);
                    var_d8h = iVar26;
                    func_0x0001800f0350(arg1);
                } else {
                    func_0x0001800efe70(arg1, arg1 + 0x84);
                    iVar26 = var_d8h;
                }
                if (((char)placeholder_2 == '\0') || (*(int32_t *)(arg1 + 0x80) != 0x3d)) {
                    if (bVar12) {
                        func_0x0001800efe70(arg1, arg1 + 0x84);
                    }
                    ppiVar16 = *(int64_t ***)(arg1 + 0xd8);
                    iVar14 = (int64_t)*ppiVar16;
                    if (iVar14 == 0) {
code_r0x0001800ed279:
                        piVar29 = (int64_t *)func_0x000180459890(0x2008);
                        *piVar29 = (int64_t)*ppiVar16;
                        *ppiVar16 = piVar29;
                        piVar29 = piVar29 + 1;
                        piVar15 = (int64_t *)0x30;
                    } else {
                        piVar29 = (int64_t *)((int64_t)ppiVar16[1] + iVar14 + 0xf & 0xfffffffffffffff8);
                        if ((int64_t *)(iVar14 + 0x2008) < piVar29 + 6) goto code_r0x0001800ed279;
                        piVar15 = (int64_t *)((int64_t)piVar29 + (0x30 - (iVar14 + 8)));
                    }
                    ppiVar16[1] = piVar15;
                    *(undefined4 *)(piVar29 + 1) = *(undefined4 *)0x1807826f4;
                    *(undefined4 *)((int64_t)piVar29 + 0xc) = uVar7;
                    *(undefined4 *)(piVar29 + 2) = uVar8;
                    *(undefined4 *)((int64_t)piVar29 + 0x14) = uVar9;
                    *(undefined4 *)(piVar29 + 3) = uVar10;
                    *piVar29 = 0x1806421f8;
                    piVar29[4] = (int64_t)piVar25;
                    piVar29[5] = 0;
                    var_e8h._0_4_ = (int32_t)piVar29;
                    var_e8h._4_4_ = (undefined4)((uint64_t)piVar29 >> 0x20);
                    if (*(char *)(arg1 + 0x58) != '\0') {
                        ppiVar16 = *(int64_t ***)(arg1 + 0xd8);
                        iVar14 = (int64_t)*ppiVar16;
                        if (iVar14 == 0) {
code_r0x0001800ed312:
                            piVar25 = (int64_t *)func_0x000180459890(0x2008);
                            *piVar25 = (int64_t)*ppiVar16;
                            *ppiVar16 = piVar25;
                            piVar25 = piVar25 + 1;
                            piVar15 = (int64_t *)0x14;
                        } else {
                            piVar25 = (int64_t *)((int64_t)ppiVar16[1] + iVar14 + 0xf & 0xfffffffffffffff8);
                            if (iVar14 + 0x2008U < (int64_t)piVar25 + 0x14U) goto code_r0x0001800ed312;
                            piVar15 = (int64_t *)((int64_t)piVar25 + (0x14 - (iVar14 + 8)));
                        }
                        ppiVar16[1] = piVar15;
                        *(undefined4 *)piVar25 = *(undefined4 *)0x180782aa4;
                        *(int64_t *)((int64_t)piVar25 + 4) = iVar26;
                        *(undefined8 *)((int64_t)piVar25 + 0xc) = 0xffffffffffffffff;
                        if ((uint64_t)(*(int64_t *)(arg1 + 0x498) * 3) >> 2 <= *(uint64_t *)(arg1 + 0x4a0)) {
                            if ((*(uint64_t *)(arg1 + 0x4a0) != 0) && (piVar29 != *(int64_t **)(arg1 + 0x4a8))) {
                                uVar19 = *(int64_t *)(arg1 + 0x498) - 1;
                                uVar20 = ((uint64_t)piVar29 >> 5 ^ (uint64_t)piVar29) >> 4;
                                uVar18 = 0;
                                do {
                                    uVar20 = uVar20 & uVar19;
                                    piVar15 = *(int64_t **)(*(int64_t *)(arg1 + 0x490) + uVar20 * 0x10);
                                    if (piVar15 == piVar29) goto code_r0x0001800ed520;
                                    if (piVar15 == *(int64_t **)(arg1 + 0x4a8)) break;
                                    uVar20 = uVar20 + 1 + uVar18;
                                    uVar18 = uVar18 + 1;
                                } while (uVar18 <= uVar19);
                            }
                            iVar26 = *(int64_t *)(arg1 + 0x498);
                            uVar20 = *(uint64_t *)(arg1 + 0x4a8);
                            if (iVar26 == 0) {
                                uVar18 = 0x10;
                                iVar14 = func_0x000180459890(0x100);
                                uVar21 = 0;
                                uVar19 = 0x10;
                                iVar26 = iVar14;
code_r0x0001800ed420:
                                do {
                                    *(undefined8 *)(iVar14 + uVar21 * 0x10) = *(undefined8 *)(arg1 + 0x4a8);
                                    *(undefined8 *)(iVar14 + 8 + uVar21 * 0x10) = 0;
                                    uVar21 = uVar21 + 1;
                                } while (uVar21 < uVar18);
                            } else {
                                uVar18 = iVar26 * 2;
                                if (uVar18 == 0) {
                                    uVar19 = 0;
                                    iVar26 = 0;
                                } else {
                                    iVar14 = func_0x000180459890(iVar26 << 5);
                                    uVar21 = 0;
                                    uVar19 = uVar18;
                                    iVar26 = iVar14;
                                    if (uVar18 != 0) goto code_r0x0001800ed420;
                                }
                            }
                            uVar18 = 0;
                            if (*(int64_t *)(arg1 + 0x498) != 0) {
                                do {
                                    uVar21 = *(uint64_t *)(*(int64_t *)(arg1 + 0x490) + uVar18 * 0x10);
                                    if (uVar21 != *(uint64_t *)(arg1 + 0x4a8)) {
                                        uVar22 = (uVar21 >> 5 ^ uVar21) >> 4;
                                        uVar23 = 0;
                                        do {
                                            uVar22 = uVar22 & uVar19 - 1;
                                            puVar27 = (uint64_t *)(uVar22 * 0x10 + iVar26);
                                            if (*puVar27 == uVar20) {
                                                *puVar27 = uVar21;
                                                goto code_r0x0001800ed4d0;
                                            }
                                            if (*puVar27 == uVar21) goto code_r0x0001800ed4d0;
                                            uVar22 = uVar22 + 1 + uVar23;
                                            uVar23 = uVar23 + 1;
                                        } while (uVar23 <= uVar19 - 1);
                                        puVar27 = (uint64_t *)0x0;
code_r0x0001800ed4d0:
                                        puVar24 = (uint64_t *)(uVar18 * 0x10 + *(int64_t *)(arg1 + 0x490));
                                        *puVar27 = *puVar24;
                                        puVar27[1] = puVar24[1];
                                    }
                                    uVar18 = uVar18 + 1;
                                } while (uVar18 < *(uint64_t *)(arg1 + 0x498));
                            }
                            iVar14 = *(int64_t *)(arg1 + 0x490);
                            *(int64_t *)(arg1 + 0x490) = iVar26;
                            *(uint64_t *)(arg1 + 0x498) = uVar19;
                            if (iVar14 != 0) {
                                func_0x0001800f4640();
                            }
                        }
code_r0x0001800ed520:
                        uVar19 = *(int64_t *)(arg1 + 0x498) - 1;
                        uVar20 = ((uint64_t)piVar29 >> 5 ^ (uint64_t)piVar29) >> 4;
                        uVar18 = 0;
                        do {
                            uVar20 = uVar20 & uVar19;
                            ppiVar16 = (int64_t **)(uVar20 * 0x10 + *(int64_t *)(arg1 + 0x490));
                            if (*ppiVar16 == *(int64_t **)(arg1 + 0x4a8)) {
                                *ppiVar16 = piVar29;
                                *(int64_t *)(arg1 + 0x4a0) = *(int64_t *)(arg1 + 0x4a0) + 1;
                                goto code_r0x0001800ed587;
                            }
                            if (*ppiVar16 == piVar29) goto code_r0x0001800ed587;
                            uVar20 = uVar20 + 1 + uVar18;
                            uVar18 = uVar18 + 1;
                        } while (uVar18 <= uVar19);
                        ppiVar16 = (int64_t **)0x0;
code_r0x0001800ed587:
                        ppiVar16[1] = piVar25;
                    }
                } else {
                    bVar12 = true;
                    var_e8h._0_4_ = (int32_t)*(undefined8 *)(arg1 + 0x84);
                    var_e8h._4_4_ = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x84) >> 0x20);
                    func_0x0001800f0350(arg1);
                    if ((*(int32_t *)(arg1 + 0x80) == 0x106) ||
                       ((*(int32_t *)(arg1 + 0x80) == 0x119 &&
                        (piVar17 = (int32_t *)func_0x0001800d70e0(arg1 + 0x60, (int64_t)&var_71h + 1), *piVar17 == 0x106
                        )))) {
                        piVar15 = (int64_t *)func_0x0001800e8e20(arg1);
                        ppiVar16 = *(int64_t ***)(arg1 + 0xd8);
                        piVar29 = *ppiVar16;
                        if (piVar29 != (int64_t *)0x0) goto code_r0x0001800ed0d9;
code_r0x0001800ed105:
                        ppiVar28 = (int64_t **)func_0x000180459890(0x2008);
                        *ppiVar28 = *ppiVar16;
                        *ppiVar16 = (int64_t *)ppiVar28;
                        ppiVar28 = ppiVar28 + 1;
                        piVar29 = (int64_t *)0x30;
                    } else {
                        uVar3 = *(undefined4 *)(arg1 + 0x114);
                        var_71h._1_4_ = *(undefined4 *)(arg1 + 0x84);
                        unique0x1000074a = *(undefined4 *)(arg1 + 0x88);
                        var_69h._1_4_ = *(undefined4 *)(arg1 + 0x8c);
                        unique0x10000762 = *(undefined4 *)(arg1 + 0x90);
                        func_0x0001800e81c0(arg1, auStack_80, 1, 0);
                        piVar15 = stack0xffffffffffffff88;
                        if (stack0xffffffffffffff88 == (int64_t *)0x0) {
                            *(undefined4 *)(arg1 + 0x114) = uVar3;
                            iVar14 = func_0x0001800e7930(arg1, _auStack_80);
                            if (iVar14 != 0) {
                                func_0x0001800efe70(arg1, iVar14 + 0xc);
                            }
                        }
                        ppiVar16 = *(int64_t ***)(arg1 + 0xd8);
                        piVar29 = *ppiVar16;
                        if (piVar29 == (int64_t *)0x0) goto code_r0x0001800ed105;
code_r0x0001800ed0d9:
                        ppiVar28 = (int64_t **)((int64_t)ppiVar16[1] + 7 + (int64_t)(piVar29 + 1) & 0xfffffffffffffff8);
                        if (piVar29 + 0x401 < ppiVar28 + 6) goto code_r0x0001800ed105;
                        piVar29 = (int64_t *)((int64_t)ppiVar28 + (0x30 - (int64_t)(piVar29 + 1)));
                    }
                    ppiVar16[1] = piVar29;
                    *(undefined4 *)(ppiVar28 + 1) = *(undefined4 *)0x1807826f4;
                    *(undefined4 *)((int64_t)ppiVar28 + 0xc) = uVar7;
                    *(undefined4 *)(ppiVar28 + 2) = uVar8;
                    *(undefined4 *)((int64_t)ppiVar28 + 0x14) = uVar9;
                    *(undefined4 *)(ppiVar28 + 3) = uVar10;
                    *ppiVar28 = (int64_t *)0x1806421f8;
                    ppiVar28[4] = piVar25;
                    ppiVar28[5] = piVar15;
                    if (*(char *)(arg1 + 0x58) != '\0') {
                        ppiVar16 = *(int64_t ***)(arg1 + 0xd8);
                        iVar14 = (int64_t)*ppiVar16;
                        if (iVar14 == 0) {
code_r0x0001800ed19e:
                            piVar25 = (int64_t *)func_0x000180459890(0x2008);
                            *piVar25 = (int64_t)*ppiVar16;
                            *ppiVar16 = piVar25;
                            piVar25 = piVar25 + 1;
                            piVar29 = (int64_t *)0x14;
                        } else {
                            piVar25 = (int64_t *)((int64_t)ppiVar16[1] + iVar14 + 0xf & 0xfffffffffffffff8);
                            if (iVar14 + 0x2008U < (int64_t)piVar25 + 0x14U) goto code_r0x0001800ed19e;
                            piVar29 = (int64_t *)((int64_t)piVar25 + (0x14 - (iVar14 + 8)));
                        }
                        ppiVar16[1] = piVar29;
                        *(undefined4 *)piVar25 = *(undefined4 *)0x180782aa4;
                        *(int64_t *)((int64_t)piVar25 + 4) = iVar26;
                        *(uint64_t *)((int64_t)piVar25 + 0xc) = CONCAT44(var_e8h._4_4_, (int32_t)var_e8h);
                        var_e8h._0_4_ = (int32_t)ppiVar28;
                        var_e8h._4_4_ = (undefined4)((uint64_t)ppiVar28 >> 0x20);
                        ppiVar16 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_e8h);
                        *ppiVar16 = piVar25;
                    }
                }
                func_0x0001800f1a70(&piStack_c8);
            } else if (((char)placeholder_2 == '\0') || (iVar2 != 0x3d)) {
                if (bVar12) {
                    func_0x0001800efe70(arg1, arg1 + 0x84);
                }
                ppiVar16 = *(int64_t ***)(arg1 + 0xd8);
                iVar26 = (int64_t)*ppiVar16;
                if (iVar26 == 0) {
code_r0x0001800ecede:
                    piVar29 = (int64_t *)func_0x000180459890(0x2008);
                    *piVar29 = (int64_t)*ppiVar16;
                    *ppiVar16 = piVar29;
                    piVar29 = piVar29 + 1;
                    piVar15 = (int64_t *)0x30;
                } else {
                    piVar29 = (int64_t *)((int64_t)ppiVar16[1] + iVar26 + 0xf & 0xfffffffffffffff8);
                    if ((int64_t *)(iVar26 + 0x2008) < piVar29 + 6) goto code_r0x0001800ecede;
                    piVar15 = (int64_t *)((int64_t)piVar29 + (0x30 - (iVar26 + 8)));
                }
                ppiVar16[1] = piVar15;
                *(undefined4 *)(piVar29 + 1) = *(undefined4 *)0x180782710;
                *(undefined4 *)((int64_t)piVar29 + 0xc) = uVar7;
                *(undefined4 *)(piVar29 + 2) = uVar8;
                *(undefined4 *)((int64_t)piVar29 + 0x14) = uVar9;
                *(undefined4 *)(piVar29 + 3) = uVar10;
                *piVar29 = 0x180642220;
                piVar29[4] = (int64_t)piVar25;
                piVar29[5] = 0;
                if (*(char *)(arg1 + 0x58) != '\0') {
                    ppiVar16 = *(int64_t ***)(arg1 + 0xd8);
                    iVar26 = (int64_t)*ppiVar16;
                    if (iVar26 == 0) {
code_r0x0001800ecf6b:
                        piVar25 = (int64_t *)func_0x000180459890(0x2008);
                        *piVar25 = (int64_t)*ppiVar16;
                        *ppiVar16 = piVar25;
                        piVar25 = piVar25 + 1;
                        piVar15 = (int64_t *)0xc;
                    } else {
                        piVar25 = (int64_t *)((int64_t)ppiVar16[1] + iVar26 + 0xf & 0xfffffffffffffff8);
                        if (iVar26 + 0x2008U < (int64_t)piVar25 + 0xcU) goto code_r0x0001800ecf6b;
                        piVar15 = (int64_t *)((int64_t)piVar25 + (0xc - (iVar26 + 8)));
                    }
                    ppiVar16[1] = piVar15;
                    *(undefined4 *)piVar25 = *(undefined4 *)0x180782a5c;
                    *(undefined8 *)((int64_t)piVar25 + 4) = 0xffffffffffffffff;
                    var_e8h._0_4_ = (int32_t)piVar29;
                    var_e8h._4_4_ = (undefined4)((uint64_t)piVar29 >> 0x20);
                    ppiVar16 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_e8h);
                    *ppiVar16 = piVar25;
                }
                func_0x0001800f1a70(&piStack_b0);
            } else {
                bVar12 = true;
                uVar4 = *(undefined8 *)(arg1 + 0x84);
                func_0x0001800f0350(arg1);
                iVar14 = func_0x0001800e8150(arg1, 0);
                ppiVar16 = *(int64_t ***)(arg1 + 0xd8);
                iVar26 = (int64_t)*ppiVar16;
                if (iVar26 == 0) {
code_r0x0001800ecd95:
                    piVar29 = (int64_t *)func_0x000180459890(0x2008);
                    *piVar29 = (int64_t)*ppiVar16;
                    *ppiVar16 = piVar29;
                    piVar29 = piVar29 + 1;
                    piVar15 = (int64_t *)0x30;
                } else {
                    piVar29 = (int64_t *)((int64_t)ppiVar16[1] + iVar26 + 0xf & 0xfffffffffffffff8);
                    if ((int64_t *)(iVar26 + 0x2008) < piVar29 + 6) goto code_r0x0001800ecd95;
                    piVar15 = (int64_t *)((int64_t)piVar29 + (0x30 - (iVar26 + 8)));
                }
                ppiVar16[1] = piVar15;
                *(undefined4 *)(piVar29 + 1) = *(undefined4 *)0x180782710;
                *(undefined4 *)((int64_t)piVar29 + 0xc) = uVar7;
                *(undefined4 *)(piVar29 + 2) = uVar8;
                *(undefined4 *)((int64_t)piVar29 + 0x14) = uVar9;
                *(undefined4 *)(piVar29 + 3) = uVar10;
                *piVar29 = 0x180642220;
                piVar29[4] = (int64_t)piVar25;
                piVar29[5] = iVar14;
                if (*(char *)(arg1 + 0x58) != '\0') {
                    ppiVar16 = *(int64_t ***)(arg1 + 0xd8);
                    iVar26 = (int64_t)*ppiVar16;
                    if (iVar26 == 0) {
code_r0x0001800ece2a:
                        piVar25 = (int64_t *)func_0x000180459890(0x2008);
                        *piVar25 = (int64_t)*ppiVar16;
                        *ppiVar16 = piVar25;
                        piVar25 = piVar25 + 1;
                        piVar15 = (int64_t *)0xc;
                    } else {
                        piVar25 = (int64_t *)((int64_t)ppiVar16[1] + iVar26 + 0xf & 0xfffffffffffffff8);
                        if (iVar26 + 0x2008U < (int64_t)piVar25 + 0xcU) goto code_r0x0001800ece2a;
                        piVar15 = (int64_t *)((int64_t)piVar25 + (0xc - (iVar26 + 8)));
                    }
                    ppiVar16[1] = piVar15;
                    *(undefined4 *)piVar25 = *(undefined4 *)0x180782a5c;
                    *(undefined8 *)((int64_t)piVar25 + 4) = uVar4;
                    var_e8h._0_4_ = (int32_t)piVar29;
                    var_e8h._4_4_ = (undefined4)((uint64_t)piVar29 >> 0x20);
                    ppiVar16 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_e8h);
                    *ppiVar16 = piVar25;
                }
                func_0x0001800f1a70(&piStack_b0);
            }
            if (*(int32_t *)(arg1 + 0x80) != 0x2c) goto code_r0x0001800ed5fa;
            if (in_stack_00000028 != (uint64_t *)0x0) {
                func_0x0001800f1a70(&piStack_98);
            }
            func_0x0001800f0350(arg1);
        } while (*(int32_t *)(arg1 + 0x80) != 0x3e);
        func_0x0001800efe70(arg1, arg1 + 0x84);
code_r0x0001800ed5fa:
        var_e8h._0_4_ = (int32_t)var_d0h;
        var_e8h._4_4_ = uVar5;
        uStack_e0 = uVar6;
        if (*(int32_t *)(arg1 + 0x80) == 0x3e) {
            func_0x0001800f0350(arg1);
            cVar13 = '\x01';
        } else {
            func_0x0001800ef5a0(arg1, 0x3e, &var_e8h, 0);
            cVar13 = func_0x0001800ef4e0(arg1, 0x3e);
        }
        if ((in_stack_00000030 != (undefined8 *)0x0) && (cVar13 != '\0')) {
            *in_stack_00000030 = *(undefined8 *)(arg1 + 0xa0);
        }
    }
    uVar20 = uStack_88;
    iVar1 = iStack_90;
    piVar15 = piStack_98;
    iVar14 = iStack_a8;
    piVar29 = piStack_b0;
    iVar26 = iStack_c0;
    piVar25 = piStack_c8;
    var_d8h = iStack_90;
    if (in_stack_00000028 != (uint64_t *)0x0) {
        if (uStack_88 == 0) {
            uVar18 = 0;
        } else {
            var_e8h._0_4_ = (int32_t)*piStack_98;
            var_e8h._4_4_ = (undefined4)((uint64_t)*piStack_98 >> 0x20);
            uVar18 = func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), uStack_88 * 8);
            if (uVar20 != 0) {
                uVar19 = CONCAT44(var_e8h._4_4_, (int32_t)var_e8h) + iVar1 * 8;
                uVar21 = 0;
                if ((uVar20 < 2) || ((uVar18 <= uVar19 + (uVar20 - 1) * 8 && (uVar19 <= uVar18 + (uVar20 - 1) * 8)))) {
                    do {
                        *(undefined8 *)(uVar18 + uVar21 * 8) = *(undefined8 *)(uVar19 + uVar21 * 8);
                        uVar21 = uVar21 + 1;
                    } while (uVar21 < uVar20);
                } else {
                    func_0x000180498030(uVar18, uVar19, uVar20 * 8);
                }
            }
        }
        *in_stack_00000028 = uVar18;
        in_stack_00000028[1] = uVar20;
    }
    uVar20 = uStack_a0;
    if (uStack_a0 == 0) {
        in_stack_00000028 = (uint64_t *)uStack_a0;
    } else {
        iVar1 = *piVar29;
        in_stack_00000028 = (uint64_t *)func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), uStack_a0 * 8);
        if (uVar20 != 0) {
            uVar18 = iVar1 + iVar14 * 8;
            uVar19 = 0;
            if ((uVar20 < 2) ||
               ((in_stack_00000028 <= uVar18 + (uVar20 - 1) * 8 &&
                (uVar18 <= (int64_t)in_stack_00000028 + (uVar20 - 1) * 8)))) {
                do {
                    *(undefined8 *)((int64_t)in_stack_00000028 + uVar19 * 8) = *(undefined8 *)(uVar18 + uVar19 * 8);
                    uVar19 = uVar19 + 1;
                } while (uVar19 < uVar20);
            } else {
                func_0x000180498030(in_stack_00000028);
            }
        }
    }
    uVar18 = uStack_b8;
    if (uStack_b8 == 0) {
        uVar19 = 0;
    } else {
        var_e8h._0_4_ = (int32_t)*piVar25;
        var_e8h._4_4_ = (undefined4)((uint64_t)*piVar25 >> 0x20);
        uVar19 = func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), uStack_b8 * 8);
        if (uVar18 != 0) {
            uVar21 = CONCAT44(var_e8h._4_4_, (int32_t)var_e8h) + iVar26 * 8;
            uVar22 = 0;
            if ((uVar18 < 2) || ((uVar19 <= uVar21 + (uVar18 - 1) * 8 && (uVar21 <= uVar19 + (uVar18 - 1) * 8)))) {
                do {
                    *(undefined8 *)(uVar19 + uVar22 * 8) = *(undefined8 *)(uVar21 + uVar22 * 8);
                    uVar22 = uVar22 + 1;
                } while (uVar22 < uVar18);
            } else {
                func_0x000180498030(uVar19, uVar21, uVar18 * 8);
            }
        }
    }
    *(uint64_t **)arg2 = in_stack_00000028;
    *(uint64_t *)(arg2 + 8) = uVar20;
    *(uint64_t *)(arg2 + 0x10) = uVar19;
    *(uint64_t *)(arg2 + 0x18) = uVar18;
    iVar1 = *piVar15 + var_d8h * 8;
    if (iVar1 != piVar15[1]) {
        piVar15[1] = iVar1;
    }
    iVar26 = *piVar25 + iVar26 * 8;
    if (iVar26 != piVar25[1]) {
        piVar25[1] = iVar26;
    }
    iVar26 = *piVar29 + iVar14 * 8;
    if (iVar26 != piVar29[1]) {
        piVar29[1] = iVar26;
    }
    return arg2;
}

// ============================================================
// Function: FUN_1800ed8e0
// Address: 0x1800ed8e0
// Size: 1161 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h

int64_t fcn.1800ed8e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int32_t **ppiVar1;
    undefined4 *puVar2;
    undefined4 *puVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t *piVar6;
    undefined8 uVar7;
    int64_t iVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    char cVar12;
    int32_t iVar13;
    int32_t *piVar14;
    undefined8 uVar15;
    int64_t *piVar16;
    int64_t **ppiVar17;
    int64_t iVar18;
    uint64_t uVar19;
    int64_t iVar20;
    int32_t *piVar21;
    uint64_t uVar22;
    int32_t *piVar23;
    int32_t *piVar24;
    int64_t *piVar25;
    int64_t iVar26;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_108h;
    undefined4 uStack_100;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    undefined4 var_80h;
    int64_t var_7ch;
    undefined4 uStack_74;
    int64_t var_70h;
    undefined4 uStack_68;
    undefined4 uStack_64;
    int64_t var_60h;
    undefined4 uStack_58;
    undefined4 uStack_54;
    
    var_f8h = arg1 + 0x368;
    var_f0h = *(int64_t *)(arg1 + 0x370) - *(int64_t *)var_f8h >> 4;
    uVar19 = 0;
    var_e8h = 0;
    iVar4 = *(int32_t *)(arg1 + 0x80);
    if (iVar4 == 0x3c) {
        uVar9 = *(undefined4 *)(undefined8 *)(arg1 + 0x84);
        uVar10 = *(undefined4 *)(arg1 + 0x88);
        uStack_74 = *(undefined4 *)(arg1 + 0x8c);
        var_70h._0_4_ = *(undefined4 *)(arg1 + 0x90);
        var_70h._4_4_ = *(undefined4 *)(arg1 + 0x94);
        uStack_68 = *(undefined4 *)(arg1 + 0x98);
        uStack_64 = *(undefined4 *)(arg1 + 0x9c);
        if (arg3 != 0) {
            *(undefined8 *)arg3 = *(undefined8 *)(arg1 + 0x84);
        }
        var_7ch._0_4_ = uVar9;
        var_7ch._4_4_ = uVar10;
        func_0x0001800f0350();
        do {
            piVar24 = (int32_t *)0x0;
            if ((*(int32_t *)(arg1 + 0x80) == 0x106) ||
               ((*(int32_t *)(arg1 + 0x80) == 0x119 &&
                (piVar14 = (int32_t *)func_0x0001800d70e0(arg1 + 0x60, &var_60h), *piVar14 == 0x106)))) {
                uVar15 = func_0x0001800e8e20(arg1);
                var_80h = 0;
                var_7ch._0_4_ = 0;
                var_7ch._4_4_ = (undefined4)uVar15;
                uStack_74 = (undefined4)((uint64_t)uVar15 >> 0x20);
            } else if (*(int32_t *)(arg1 + 0x80) == 0x28) {
                var_60h._0_4_ = *(undefined4 *)(arg1 + 0x84);
                var_60h._4_4_ = *(undefined4 *)(arg1 + 0x88);
                uStack_58 = *(undefined4 *)(arg1 + 0x8c);
                uStack_54 = *(undefined4 *)(arg1 + 0x90);
                func_0x0001800e81c0(arg1, &var_b0h, 1, 0);
                if (var_a8h == 0) {
                    var_a0h = func_0x0001800e7930(arg1, var_b0h, &var_60h);
                    var_98h = 0;
                } else {
                    piVar14 = piVar24;
                    if (*(int32_t *)(var_a8h + 8) == *(int32_t *)0x18078268c) {
                        piVar14 = (int32_t *)var_a8h;
                    }
                    if ((((piVar14 == (int32_t *)0x0) || (*(int64_t *)(piVar14 + 0xc) != 0)) ||
                        (*(int64_t *)(piVar14 + 10) != 1)) ||
                       (((iVar13 = *(int32_t *)(arg1 + 0x80), iVar13 != 0x7c && (iVar13 != 0x3f)) && (iVar13 != 0x26))))
                    {
                        var_c0h = 0;
                        var_b8h = var_a8h;
                    } else {
                        iVar5 = **(int64_t **)(piVar14 + 8);
                        var_108h._0_4_ = (int32_t)iVar5;
                        var_108h._4_4_ = (undefined4)((uint64_t)iVar5 >> 0x20);
                        if (*(char *)0x180778140 == '\0') {
                            uVar15 = func_0x0001800f1350(*(undefined8 *)(arg1 + 0xd8), iVar5 + 0xc, &var_108h);
                            var_d0h = func_0x0001800e7930(arg1, uVar15, &var_60h);
                            var_c8h = 0;
                        } else {
                            uVar15 = func_0x0001800f1350(*(undefined8 *)(arg1 + 0xd8), iVar5 + 0xc, &var_108h);
                            if (((*(char *)(arg1 + 0x58) != '\0') && (*(int64_t *)(arg1 + 0x4a0) != 0)) &&
                               (piVar14 != *(int32_t **)(arg1 + 0x4a8))) {
                                piVar23 = (int32_t *)(*(int64_t *)(arg1 + 0x498) + -1);
                                uVar19 = ((uint64_t)piVar14 >> 5 ^ (uint64_t)piVar14) >> 4;
                                piVar21 = piVar24;
                                do {
                                    uVar19 = uVar19 & (uint64_t)piVar23;
                                    piVar6 = *(int32_t **)(*(int64_t *)(arg1 + 0x490) + uVar19 * 0x10);
                                    if (piVar6 == piVar14) {
                                        ppiVar1 = (int32_t **)(*(int64_t *)(arg1 + 0x490) + 8 + uVar19 * 0x10);
                                        if ((ppiVar1 != (int32_t **)0x0) &&
                                           (piVar14 = *ppiVar1, piVar14 != (int32_t *)0x0)) {
                                            if (*piVar14 == *(int32_t *)0x180782ac0) {
                                                piVar24 = piVar14;
                                            }
                                            if (piVar24 != (int32_t *)0x0) {
                                                ppiVar17 = *(int64_t ***)(arg1 + 0xd8);
                                                iVar5 = (int64_t)*ppiVar17;
                                                if (iVar5 == 0) {
code_r0x0001800edb3e:
                                                    piVar25 = (int64_t *)func_0x000180459890(0x2008);
                                                    *piVar25 = (int64_t)*ppiVar17;
                                                    *ppiVar17 = piVar25;
                                                    piVar25 = piVar25 + 1;
                                                    piVar16 = (int64_t *)0xc;
                                                } else {
                                                    piVar25 = (int64_t *)
                                                              ((int64_t)ppiVar17[1] + iVar5 + 0xf & 0xfffffffffffffff8);
                                                    if (iVar5 + 0x2008U < (int64_t)piVar25 + 0xcU)
                                                    goto code_r0x0001800edb3e;
                                                    piVar16 = (int64_t *)((int64_t)piVar25 + (0xc - (iVar5 + 8)));
                                                }
                                                ppiVar17[1] = piVar16;
                                                uVar7 = *(undefined8 *)(piVar24 + 3);
                                                *(undefined4 *)piVar25 = *(undefined4 *)0x180782a50;
                                                *(undefined8 *)((int64_t)piVar25 + 4) = uVar7;
                                                var_108h._0_4_ = (int32_t)uVar15;
                                                var_108h._4_4_ = (undefined4)((uint64_t)uVar15 >> 0x20);
                                                ppiVar17 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_108h);
                                                *ppiVar17 = piVar25;
                                            }
                                        }
                                        break;
                                    }
                                    if (piVar6 == *(int32_t **)(arg1 + 0x4a8)) break;
                                    uVar19 = uVar19 + 1 + (int64_t)piVar21;
                                    piVar21 = (int32_t *)((int64_t)piVar21 + 1);
                                } while (piVar21 <= piVar23);
                            }
                            var_e0h = func_0x0001800e7930(arg1, uVar15, &var_60h);
                            var_d8h = 0;
                        }
                    }
                }
            } else {
                if ((*(int32_t *)(arg1 + 0x80) == 0x3e) && (iVar13 = 0x3e, uVar19 == 0)) goto code_r0x0001800edc76;
                var_90h = func_0x0001800e8150(arg1, 0);
                var_88h = 0;
            }
            func_0x0001800f2a00(&var_f8h);
            iVar13 = *(int32_t *)(arg1 + 0x80);
            uVar19 = var_e8h;
            if (iVar13 != 0x2c) goto code_r0x0001800edc76;
            if (arg4 != 0) {
                func_0x0001800f1a70(arg4);
            }
            func_0x0001800f0350(arg1);
            uVar19 = var_e8h;
        } while( true );
    }
code_r0x0001800edcd7:
    iVar20 = var_f0h;
    iVar5 = var_f8h;
    uVar22 = 0;
    *(undefined8 *)arg2 = 0;
    if (uVar19 == 0) {
        *(undefined8 *)(arg2 + 8) = 0;
    } else {
        *(undefined8 *)(arg2 + 8) = 0;
        iVar26 = var_f0h * 0x10;
        iVar8 = *(int64_t *)var_f8h;
        iVar18 = func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), uVar19 << 4);
        *(int64_t *)arg2 = iVar18;
        *(uint64_t *)(arg2 + 8) = uVar19;
        if (uVar19 != 0) {
            do {
                puVar2 = (undefined4 *)(iVar26 + iVar8 + uVar22 * 0x10);
                uVar9 = puVar2[1];
                uVar10 = puVar2[2];
                uVar11 = puVar2[3];
                puVar3 = (undefined4 *)(iVar18 + uVar22 * 0x10);
                *puVar3 = *puVar2;
                puVar3[1] = uVar9;
                puVar3[2] = uVar10;
                puVar3[3] = uVar11;
                uVar22 = uVar22 + 1;
            } while (uVar22 < uVar19);
        }
    }
    iVar20 = *(int64_t *)iVar5 + iVar20 * 0x10;
    if (iVar20 != *(int64_t *)(iVar5 + 8)) {
        *(int64_t *)(iVar5 + 8) = iVar20;
    }
    return arg2;
code_r0x0001800edc76:
    var_108h._0_4_ = iVar4;
    var_108h._4_4_ = uVar9;
    uStack_100 = uVar10;
    if (iVar13 == 0x3e) {
        func_0x0001800f0350(arg1);
        cVar12 = '\x01';
    } else {
        func_0x0001800ef5a0(arg1, 0x3e, &var_108h, 0);
        cVar12 = func_0x0001800ef4e0(arg1, 0x3e);
    }
    if ((arg_28h != 0) && (cVar12 != '\0')) {
        *(undefined8 *)arg_28h = *(undefined8 *)(arg1 + 0xa0);
    }
    goto code_r0x0001800edcd7;
}

// ============================================================
// Function: FUN_1800edd70
// Address: 0x1800edd70
// Size: 335 bytes
// ============================================================
int64_t fcn.1800edd70(int64_t arg1, int64_t arg2, int64_t arg3)
{
    char **ppcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    char cVar5;
    undefined4 *puVar6;
    char **ppcVar7;
    char **ppcVar8;
    int64_t var_10h;
    int64_t var_38h;
    undefined4 uStack_30;
    undefined4 uStack_2c;
    
    ppcVar1 = (char **)(arg1 + 0x470);
    func_0x00018000f180(ppcVar1, *(undefined8 *)(arg1 + 0x98), *(undefined4 *)(arg1 + 0x94));
    if (arg3 != 0) {
        puVar6 = (undefined4 *)func_0x0001800efa10(arg1, &var_38h, ppcVar1);
        uVar2 = puVar6[1];
        uVar3 = puVar6[2];
        uVar4 = puVar6[3];
        *(undefined4 *)arg3 = *puVar6;
        *(undefined4 *)(arg3 + 4) = uVar2;
        *(undefined4 *)(arg3 + 8) = uVar3;
        *(undefined4 *)(arg3 + 0xc) = uVar4;
    }
    if ((*(int32_t *)(arg1 + 0x80) == 0x117) || (*(int32_t *)(arg1 + 0x80) == 0x10d)) {
        cVar5 = func_0x0001800d8610(ppcVar1);
        if (cVar5 == '\0') {
            func_0x0001800f0350(arg1);
            *(undefined *)(arg2 + 0x10) = 0;
            return arg2;
        }
        goto code_r0x0001800ede6a;
    }
    if (*(int64_t *)(arg1 + 0x480) == 0) goto code_r0x0001800ede6a;
    ppcVar8 = ppcVar1;
    if (0xf < *(uint64_t *)(arg1 + 0x488)) {
        ppcVar8 = (char **)*ppcVar1;
    }
    cVar5 = *(char *)ppcVar8;
    if ((cVar5 == '\r') && (*(char *)((int64_t)ppcVar8 + 1) == '\n')) {
        ppcVar7 = (char **)((int64_t)ppcVar8 + 2);
code_r0x0001800ede12:
        cVar5 = *(char *)ppcVar7;
    } else {
        ppcVar7 = ppcVar8;
        if (cVar5 == '\n') {
            ppcVar7 = (char **)((int64_t)ppcVar8 + 1);
            goto code_r0x0001800ede12;
        }
    }
    if (cVar5 != '\0') {
        cVar5 = *(char *)ppcVar7;
        do {
            if ((cVar5 == '\r') && (*(char *)((int64_t)ppcVar7 + 1) == '\n')) {
                ppcVar7 = (char **)((int64_t)ppcVar7 + 2);
                cVar5 = '\n';
            } else {
                cVar5 = *(char *)ppcVar7;
                ppcVar7 = (char **)((int64_t)ppcVar7 + 1);
            }
            *(char *)ppcVar8 = cVar5;
            ppcVar8 = (char **)((int64_t)ppcVar8 + 1);
            cVar5 = *(char *)ppcVar7;
        } while (cVar5 != '\0');
    }
    ppcVar7 = ppcVar1;
    if (0xf < *(uint64_t *)(arg1 + 0x488)) {
        ppcVar7 = (char **)*ppcVar1;
    }
    func_0x00018000b3b0(ppcVar1, (int64_t)ppcVar8 - (int64_t)ppcVar7, 0);
code_r0x0001800ede6a:
    func_0x0001800efa10(arg1, &var_38h, ppcVar1);
    func_0x0001800f0350(arg1);
    *(undefined *)(arg2 + 0x10) = 1;
    *(undefined4 *)arg2 = (undefined4)var_38h;
    *(undefined4 *)(arg2 + 4) = var_38h._4_4_;
    *(undefined4 *)(arg2 + 8) = uStack_30;
    *(undefined4 *)(arg2 + 0xc) = uStack_2c;
    return arg2;
}

// ============================================================
// Function: FUN_1800edec0
// Address: 0x1800edec0
// Size: 257 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

int64_t * fcn.1800edec0(int64_t arg1, int64_t arg_88h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    int64_t **ppiVar9;
    uint32_t uVar10;
    int64_t *piVar11;
    uint32_t uVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    undefined4 uStack_58;
    undefined4 uStack_54;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar1 = *(int32_t *)(arg1 + 0x80);
    uVar3 = *(undefined4 *)(arg1 + 0x84);
    uVar4 = *(undefined4 *)(arg1 + 0x88);
    uVar5 = *(undefined4 *)(arg1 + 0x8c);
    uVar6 = *(undefined4 *)(arg1 + 0x90);
    uVar10 = 0;
    uVar12 = uVar10;
    if (iVar1 != 0x10d) {
        if (iVar1 == 0x116) {
            uVar12 = 2;
        } else if (iVar1 != 0x117) {
            uVar12 = (uint32_t)var_8h;
        }
    }
    if (*(char *)(arg1 + 0x58) != '\0') {
        if (iVar1 == 0x10d) {
            var_10h._0_4_ = 3;
            var_8h._0_4_ = uVar10;
        } else if (iVar1 == 0x116) {
            piVar11 = (int64_t *)0x0;
            do {
                var_8h._0_4_ = (uint32_t)piVar11;
                piVar11 = (int64_t *)(uint64_t)((uint32_t)var_8h + 1);
                var_10h._0_4_ = 2;
            } while (*(char *)((int64_t)piVar11 + (uint64_t)*(uint32_t *)(arg1 + 0x94) + *(int64_t *)(arg1 + 0x98)) !=
                     ']');
        } else {
            var_10h._0_4_ = (uint32_t)var_8h;
            var_8h._0_4_ = uVar10;
            if (iVar1 == 0x117) {
                var_10h._0_4_ =
                     (uint32_t)(*(char *)((uint64_t)*(uint32_t *)(arg1 + 0x94) + *(int64_t *)(arg1 + 0x98)) != '\'');
            }
        }
    }
    var_88h = 0;
    var_80h = 0;
    piVar11 = &var_88h;
    if (*(char *)(arg1 + 0x58) == '\0') {
        piVar11 = (int64_t *)0x0;
    }
    var_60h._0_4_ = uVar3;
    var_60h._4_4_ = uVar4;
    uStack_58 = uVar5;
    uStack_54 = uVar6;
    fcn.1800edd70(arg1, (int64_t)&var_78h, (int64_t)piVar11);
    if ((char)var_68h == '\0') {
        var_78h = 0;
        var_70h = 0;
        piVar11 = (int64_t *)func_0x0001800f0080(arg1, &var_60h, &var_78h, 0x180643760);
        return piVar11;
    }
    ppiVar9 = *(int64_t ***)(arg1 + 0xd8);
    iVar2 = (int64_t)*ppiVar9;
    if (iVar2 == 0) {
code_r0x0001800ee00c:
        piVar7 = (int64_t *)func_0x000180459890(0x2008);
        *piVar7 = (int64_t)*ppiVar9;
        piVar11 = piVar7 + 1;
        *ppiVar9 = piVar7;
        piVar7 = (int64_t *)0x38;
    } else {
        piVar11 = (int64_t *)((int64_t)ppiVar9[1] + iVar2 + 0xf & 0xfffffffffffffff8);
        if ((int64_t *)(iVar2 + 0x2008) < piVar11 + 7) goto code_r0x0001800ee00c;
        piVar7 = (int64_t *)((int64_t)piVar11 + (0x38 - (iVar2 + 8)));
    }
    ppiVar9[1] = piVar7;
    *(undefined4 *)(piVar11 + 1) = *(undefined4 *)0x18078273c;
    *piVar11 = 0x180642158;
    *(undefined4 *)(piVar11 + 4) = (undefined4)var_78h;
    *(undefined4 *)((int64_t)piVar11 + 0x24) = var_78h._4_4_;
    *(undefined4 *)(piVar11 + 5) = (undefined4)var_70h;
    *(undefined4 *)((int64_t)piVar11 + 0x2c) = var_70h._4_4_;
    *(uint32_t *)(piVar11 + 6) = uVar12;
    *(undefined4 *)((int64_t)piVar11 + 0xc) = uVar3;
    *(undefined4 *)(piVar11 + 2) = uVar4;
    *(undefined4 *)((int64_t)piVar11 + 0x14) = uVar5;
    *(undefined4 *)(piVar11 + 3) = uVar6;
    if (*(char *)(arg1 + 0x58) == '\0') {
        return piVar11;
    }
    ppiVar9 = *(int64_t ***)(arg1 + 0xd8);
    iVar2 = (int64_t)*ppiVar9;
    if (iVar2 != 0) {
        piVar7 = (int64_t *)((int64_t)ppiVar9[1] + iVar2 + 0xf & 0xfffffffffffffff8);
        if (piVar7 + 4 <= (int64_t *)(iVar2 + 0x2008U)) {
            piVar8 = (int64_t *)((int64_t)piVar7 + (0x20 - (iVar2 + 8)));
            goto code_r0x0001800ee0bd;
        }
    }
    piVar8 = (int64_t *)func_0x000180459890(0x2008);
    *piVar8 = (int64_t)*ppiVar9;
    piVar7 = piVar8 + 1;
    *ppiVar9 = piVar8;
    piVar8 = (int64_t *)0x20;
code_r0x0001800ee0bd:
    ppiVar9[1] = piVar8;
    *(undefined4 *)piVar7 = *(undefined4 *)0x180782a64;
    *(undefined4 *)(piVar7 + 1) = (undefined4)var_88h;
    *(undefined4 *)((int64_t)piVar7 + 0xc) = var_88h._4_4_;
    *(undefined4 *)(piVar7 + 2) = (undefined4)var_80h;
    *(undefined4 *)((int64_t)piVar7 + 0x14) = var_80h._4_4_;
    *(uint32_t *)(piVar7 + 3) = (uint32_t)var_10h;
    *(uint32_t *)((int64_t)piVar7 + 0x1c) = (uint32_t)var_8h;
    var_18h = (int64_t)piVar11;
    ppiVar9 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_18h);
    *ppiVar9 = piVar7;
    return piVar11;
}

// ============================================================
// Function: FUN_1800edfc1
// Address: 0x1800edfc1
// Size: 329 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

int64_t * fcn.1800edec0(int64_t arg1, int64_t arg_88h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    int64_t **ppiVar9;
    uint32_t uVar10;
    int64_t *piVar11;
    uint32_t uVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    undefined4 uStack_58;
    undefined4 uStack_54;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar1 = *(int32_t *)(arg1 + 0x80);
    uVar3 = *(undefined4 *)(arg1 + 0x84);
    uVar4 = *(undefined4 *)(arg1 + 0x88);
    uVar5 = *(undefined4 *)(arg1 + 0x8c);
    uVar6 = *(undefined4 *)(arg1 + 0x90);
    uVar10 = 0;
    uVar12 = uVar10;
    if (iVar1 != 0x10d) {
        if (iVar1 == 0x116) {
            uVar12 = 2;
        } else if (iVar1 != 0x117) {
            uVar12 = (uint32_t)var_8h;
        }
    }
    if (*(char *)(arg1 + 0x58) != '\0') {
        if (iVar1 == 0x10d) {
            var_10h._0_4_ = 3;
            var_8h._0_4_ = uVar10;
        } else if (iVar1 == 0x116) {
            piVar11 = (int64_t *)0x0;
            do {
                var_8h._0_4_ = (uint32_t)piVar11;
                piVar11 = (int64_t *)(uint64_t)((uint32_t)var_8h + 1);
                var_10h._0_4_ = 2;
            } while (*(char *)((int64_t)piVar11 + (uint64_t)*(uint32_t *)(arg1 + 0x94) + *(int64_t *)(arg1 + 0x98)) !=
                     ']');
        } else {
            var_10h._0_4_ = (uint32_t)var_8h;
            var_8h._0_4_ = uVar10;
            if (iVar1 == 0x117) {
                var_10h._0_4_ =
                     (uint32_t)(*(char *)((uint64_t)*(uint32_t *)(arg1 + 0x94) + *(int64_t *)(arg1 + 0x98)) != '\'');
            }
        }
    }
    var_88h = 0;
    var_80h = 0;
    piVar11 = &var_88h;
    if (*(char *)(arg1 + 0x58) == '\0') {
        piVar11 = (int64_t *)0x0;
    }
    var_60h._0_4_ = uVar3;
    var_60h._4_4_ = uVar4;
    uStack_58 = uVar5;
    uStack_54 = uVar6;
    fcn.1800edd70(arg1, (int64_t)&var_78h, (int64_t)piVar11);
    if ((char)var_68h == '\0') {
        var_78h = 0;
        var_70h = 0;
        piVar11 = (int64_t *)func_0x0001800f0080(arg1, &var_60h, &var_78h, 0x180643760);
        return piVar11;
    }
    ppiVar9 = *(int64_t ***)(arg1 + 0xd8);
    iVar2 = (int64_t)*ppiVar9;
    if (iVar2 == 0) {
code_r0x0001800ee00c:
        piVar7 = (int64_t *)func_0x000180459890(0x2008);
        *piVar7 = (int64_t)*ppiVar9;
        piVar11 = piVar7 + 1;
        *ppiVar9 = piVar7;
        piVar7 = (int64_t *)0x38;
    } else {
        piVar11 = (int64_t *)((int64_t)ppiVar9[1] + iVar2 + 0xf & 0xfffffffffffffff8);
        if ((int64_t *)(iVar2 + 0x2008) < piVar11 + 7) goto code_r0x0001800ee00c;
        piVar7 = (int64_t *)((int64_t)piVar11 + (0x38 - (iVar2 + 8)));
    }
    ppiVar9[1] = piVar7;
    *(undefined4 *)(piVar11 + 1) = *(undefined4 *)0x18078273c;
    *piVar11 = 0x180642158;
    *(undefined4 *)(piVar11 + 4) = (undefined4)var_78h;
    *(undefined4 *)((int64_t)piVar11 + 0x24) = var_78h._4_4_;
    *(undefined4 *)(piVar11 + 5) = (undefined4)var_70h;
    *(undefined4 *)((int64_t)piVar11 + 0x2c) = var_70h._4_4_;
    *(uint32_t *)(piVar11 + 6) = uVar12;
    *(undefined4 *)((int64_t)piVar11 + 0xc) = uVar3;
    *(undefined4 *)(piVar11 + 2) = uVar4;
    *(undefined4 *)((int64_t)piVar11 + 0x14) = uVar5;
    *(undefined4 *)(piVar11 + 3) = uVar6;
    if (*(char *)(arg1 + 0x58) == '\0') {
        return piVar11;
    }
    ppiVar9 = *(int64_t ***)(arg1 + 0xd8);
    iVar2 = (int64_t)*ppiVar9;
    if (iVar2 != 0) {
        piVar7 = (int64_t *)((int64_t)ppiVar9[1] + iVar2 + 0xf & 0xfffffffffffffff8);
        if (piVar7 + 4 <= (int64_t *)(iVar2 + 0x2008U)) {
            piVar8 = (int64_t *)((int64_t)piVar7 + (0x20 - (iVar2 + 8)));
            goto code_r0x0001800ee0bd;
        }
    }
    piVar8 = (int64_t *)func_0x000180459890(0x2008);
    *piVar8 = (int64_t)*ppiVar9;
    piVar7 = piVar8 + 1;
    *ppiVar9 = piVar8;
    piVar8 = (int64_t *)0x20;
code_r0x0001800ee0bd:
    ppiVar9[1] = piVar8;
    *(undefined4 *)piVar7 = *(undefined4 *)0x180782a64;
    *(undefined4 *)(piVar7 + 1) = (undefined4)var_88h;
    *(undefined4 *)((int64_t)piVar7 + 0xc) = var_88h._4_4_;
    *(undefined4 *)(piVar7 + 2) = (undefined4)var_80h;
    *(undefined4 *)((int64_t)piVar7 + 0x14) = var_80h._4_4_;
    *(uint32_t *)(piVar7 + 3) = (uint32_t)var_10h;
    *(uint32_t *)((int64_t)piVar7 + 0x1c) = (uint32_t)var_8h;
    var_18h = (int64_t)piVar11;
    ppiVar9 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_18h);
    *ppiVar9 = piVar7;
    return piVar11;
}

// ============================================================
// Function: FUN_1800ee10a
// Address: 0x1800ee10a
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

int64_t * fcn.1800edec0(int64_t arg1, int64_t arg_88h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    int64_t **ppiVar9;
    uint32_t uVar10;
    int64_t *piVar11;
    uint32_t uVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    undefined4 uStack_58;
    undefined4 uStack_54;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar1 = *(int32_t *)(arg1 + 0x80);
    uVar3 = *(undefined4 *)(arg1 + 0x84);
    uVar4 = *(undefined4 *)(arg1 + 0x88);
    uVar5 = *(undefined4 *)(arg1 + 0x8c);
    uVar6 = *(undefined4 *)(arg1 + 0x90);
    uVar10 = 0;
    uVar12 = uVar10;
    if (iVar1 != 0x10d) {
        if (iVar1 == 0x116) {
            uVar12 = 2;
        } else if (iVar1 != 0x117) {
            uVar12 = (uint32_t)var_8h;
        }
    }
    if (*(char *)(arg1 + 0x58) != '\0') {
        if (iVar1 == 0x10d) {
            var_10h._0_4_ = 3;
            var_8h._0_4_ = uVar10;
        } else if (iVar1 == 0x116) {
            piVar11 = (int64_t *)0x0;
            do {
                var_8h._0_4_ = (uint32_t)piVar11;
                piVar11 = (int64_t *)(uint64_t)((uint32_t)var_8h + 1);
                var_10h._0_4_ = 2;
            } while (*(char *)((int64_t)piVar11 + (uint64_t)*(uint32_t *)(arg1 + 0x94) + *(int64_t *)(arg1 + 0x98)) !=
                     ']');
        } else {
            var_10h._0_4_ = (uint32_t)var_8h;
            var_8h._0_4_ = uVar10;
            if (iVar1 == 0x117) {
                var_10h._0_4_ =
                     (uint32_t)(*(char *)((uint64_t)*(uint32_t *)(arg1 + 0x94) + *(int64_t *)(arg1 + 0x98)) != '\'');
            }
        }
    }
    var_88h = 0;
    var_80h = 0;
    piVar11 = &var_88h;
    if (*(char *)(arg1 + 0x58) == '\0') {
        piVar11 = (int64_t *)0x0;
    }
    var_60h._0_4_ = uVar3;
    var_60h._4_4_ = uVar4;
    uStack_58 = uVar5;
    uStack_54 = uVar6;
    fcn.1800edd70(arg1, (int64_t)&var_78h, (int64_t)piVar11);
    if ((char)var_68h == '\0') {
        var_78h = 0;
        var_70h = 0;
        piVar11 = (int64_t *)func_0x0001800f0080(arg1, &var_60h, &var_78h, 0x180643760);
        return piVar11;
    }
    ppiVar9 = *(int64_t ***)(arg1 + 0xd8);
    iVar2 = (int64_t)*ppiVar9;
    if (iVar2 == 0) {
code_r0x0001800ee00c:
        piVar7 = (int64_t *)func_0x000180459890(0x2008);
        *piVar7 = (int64_t)*ppiVar9;
        piVar11 = piVar7 + 1;
        *ppiVar9 = piVar7;
        piVar7 = (int64_t *)0x38;
    } else {
        piVar11 = (int64_t *)((int64_t)ppiVar9[1] + iVar2 + 0xf & 0xfffffffffffffff8);
        if ((int64_t *)(iVar2 + 0x2008) < piVar11 + 7) goto code_r0x0001800ee00c;
        piVar7 = (int64_t *)((int64_t)piVar11 + (0x38 - (iVar2 + 8)));
    }
    ppiVar9[1] = piVar7;
    *(undefined4 *)(piVar11 + 1) = *(undefined4 *)0x18078273c;
    *piVar11 = 0x180642158;
    *(undefined4 *)(piVar11 + 4) = (undefined4)var_78h;
    *(undefined4 *)((int64_t)piVar11 + 0x24) = var_78h._4_4_;
    *(undefined4 *)(piVar11 + 5) = (undefined4)var_70h;
    *(undefined4 *)((int64_t)piVar11 + 0x2c) = var_70h._4_4_;
    *(uint32_t *)(piVar11 + 6) = uVar12;
    *(undefined4 *)((int64_t)piVar11 + 0xc) = uVar3;
    *(undefined4 *)(piVar11 + 2) = uVar4;
    *(undefined4 *)((int64_t)piVar11 + 0x14) = uVar5;
    *(undefined4 *)(piVar11 + 3) = uVar6;
    if (*(char *)(arg1 + 0x58) == '\0') {
        return piVar11;
    }
    ppiVar9 = *(int64_t ***)(arg1 + 0xd8);
    iVar2 = (int64_t)*ppiVar9;
    if (iVar2 != 0) {
        piVar7 = (int64_t *)((int64_t)ppiVar9[1] + iVar2 + 0xf & 0xfffffffffffffff8);
        if (piVar7 + 4 <= (int64_t *)(iVar2 + 0x2008U)) {
            piVar8 = (int64_t *)((int64_t)piVar7 + (0x20 - (iVar2 + 8)));
            goto code_r0x0001800ee0bd;
        }
    }
    piVar8 = (int64_t *)func_0x000180459890(0x2008);
    *piVar8 = (int64_t)*ppiVar9;
    piVar7 = piVar8 + 1;
    *ppiVar9 = piVar8;
    piVar8 = (int64_t *)0x20;
code_r0x0001800ee0bd:
    ppiVar9[1] = piVar8;
    *(undefined4 *)piVar7 = *(undefined4 *)0x180782a64;
    *(undefined4 *)(piVar7 + 1) = (undefined4)var_88h;
    *(undefined4 *)((int64_t)piVar7 + 0xc) = var_88h._4_4_;
    *(undefined4 *)(piVar7 + 2) = (undefined4)var_80h;
    *(undefined4 *)((int64_t)piVar7 + 0x14) = var_80h._4_4_;
    *(uint32_t *)(piVar7 + 3) = (uint32_t)var_10h;
    *(uint32_t *)((int64_t)piVar7 + 0x1c) = (uint32_t)var_8h;
    var_18h = (int64_t)piVar11;
    ppiVar9 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_18h);
    *ppiVar9 = piVar7;
    return piVar11;
}

// ============================================================
// Function: FUN_1800ee150
// Address: 0x1800ee150
// Size: 2762 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h

void fcn.1800ee150(int64_t arg1)
{
    int32_t *piVar1;
    undefined4 *puVar2;
    undefined4 *puVar3;
    int32_t iVar4;
    int64_t **ppiVar5;
    code *pcVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    char cVar10;
    int64_t iVar11;
    int64_t *piVar12;
    undefined8 *puVar13;
    uint64_t uVar14;
    int64_t iVar15;
    uint64_t uVar16;
    undefined *puVar17;
    undefined *puVar18;
    uint64_t *puVar19;
    undefined8 *puVar20;
    int64_t *piVar21;
    int64_t iVar22;
    int64_t iVar23;
    int64_t *piVar24;
    undefined8 uVar25;
    int64_t iVar26;
    undefined auStack_188 [8];
    undefined auStack_180 [24];
    int64_t var_168h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    uint64_t uStack_88;
    int64_t var_80h;
    int64_t var_78h;
    undefined4 uStack_70;
    undefined4 uStack_6c;
    undefined4 uStack_68;
    int64_t var_64h;
    int64_t var_58h;
    
    puVar17 = auStack_188;
    puVar18 = auStack_188;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_188;
    var_d0h = arg1 + 0x260;
    var_c8h = *(int64_t *)(arg1 + 0x268) - *(int64_t *)var_d0h >> 4;
    var_c0h = 0;
    var_a0h = arg1 + 0x278;
    var_98h = *(int64_t *)(arg1 + 0x280) - *(int64_t *)var_a0h >> 4;
    var_90h = 0;
    var_b8h = arg1 + 0x440;
    var_b0h = *(int64_t *)(arg1 + 0x448) - *(int64_t *)var_b8h >> 3;
    var_a8h = 0;
    var_e8h = arg1 + 0x290;
    var_f0h = *(int64_t *)(arg1 + 0x298) - *(int64_t *)var_e8h >> 3;
    var_d8h = 0;
    var_140h = *(int64_t *)(arg1 + 0x84);
    var_138h = *(int64_t *)(arg1 + 0x8c);
    piVar1 = (int32_t *)(arg1 + 0x80);
    puVar13 = (undefined8 *)(arg1 + 0x470);
    puVar19 = (uint64_t *)(arg1 + 0x488);
    var_e0h = var_f0h;
    do {
        do {
            var_78h._0_4_ = *piVar1;
            var_f8h = CONCAT44(var_f8h._4_4_, (int32_t)var_78h);
            var_78h._4_4_ = *(undefined4 *)(int64_t *)(arg1 + 0x84);
            uStack_70 = *(undefined4 *)(arg1 + 0x88);
            var_130h = *(int64_t *)(arg1 + 0x84);
            uStack_6c = *(undefined4 *)(int64_t *)(arg1 + 0x8c);
            uStack_68 = *(undefined4 *)(arg1 + 0x90);
            var_128h = *(int64_t *)(arg1 + 0x8c);
            var_64h._0_4_ = *(undefined4 *)(arg1 + 0x94);
            unique0x0000c280 = *(uint64_t *)(arg1 + 0x98);
            var_150h = (int64_t)puVar19;
            func_0x00018000f180(puVar13);
            if (*(char *)(arg1 + 0x58) != '\0') {
                iVar15 = *(int64_t *)(arg1 + 0x480);
                uVar16 = iVar15 + 1;
                puVar20 = puVar13;
                if (0xf < *(uint64_t *)var_150h) {
                    puVar20 = (undefined8 *)*puVar13;
                }
                if (uVar16 == 0) {
                    uStack_88 = 0;
                } else {
                    uStack_88 = func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), uVar16);
                    if (uVar16 != 0) {
                        uVar14 = 0;
                        if ((uVar16 < 0x10) ||
                           ((uStack_88 <= (uint64_t)((int64_t)puVar20 + iVar15) &&
                            (uVar14 = 0, puVar20 <= (undefined8 *)(uStack_88 + iVar15))))) {
                            do {
                                *(undefined *)(uStack_88 + uVar14) = *(undefined *)((int64_t)puVar20 + uVar14);
                                uVar14 = uVar14 + 1;
                            } while (uVar14 < uVar16);
                        } else {
                            func_0x000180498030(uStack_88, puVar20);
                        }
                    }
                }
                var_80h = *(int64_t *)(arg1 + 0x480);
                func_0x0001800f2a00(&var_a0h, &uStack_88);
                func_0x0001800f1a70(&var_b8h, (int64_t)&var_78h + 4);
                puVar19 = (uint64_t *)var_150h;
            }
            cVar10 = func_0x0001800d8610(puVar13);
            var_108h = var_98h;
            var_158h = var_a0h;
            var_100h = var_b0h;
            var_110h = var_b8h;
            if (cVar10 == '\0') {
                func_0x0001800f0350(arg1);
                var_120h = 0;
                var_118h = 0;
                var_138h = var_128h;
                uVar25 = 0x180643de8;
                piVar24 = &var_120h;
                piVar21 = &var_140h;
                goto code_r0x0001800eeb86;
            }
            iVar15 = *(int64_t *)(arg1 + 0x480);
            uVar16 = iVar15 + 1;
            puVar20 = puVar13;
            if (0xf < *puVar19) {
                puVar20 = (undefined8 *)*puVar13;
            }
            if (uVar16 == 0) {
                var_120h = 0;
            } else {
                var_120h = func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), uVar16);
                if (uVar16 != 0) {
                    uVar14 = 0;
                    if ((uVar16 < 0x10) ||
                       (((uint64_t)var_120h <= (uint64_t)((int64_t)puVar20 + iVar15) &&
                        (uVar14 = 0, puVar20 <= (undefined8 *)(var_120h + iVar15))))) {
                        do {
                            *(undefined *)(var_120h + uVar14) = *(undefined *)((int64_t)puVar20 + uVar14);
                            uVar14 = uVar14 + 1;
                        } while (uVar14 < uVar16);
                    } else {
                        func_0x000180498030(var_120h, puVar20);
                    }
                }
            }
            var_118h = *(int64_t *)(arg1 + 0x480);
            func_0x0001800f0350(arg1);
            func_0x0001800f2a00(&var_d0h, &var_120h);
            if ((int32_t)var_f8h - 0x10cU < 2) {
code_r0x0001800ee8c9:
                iVar23 = var_c0h;
                iVar15 = var_d8h;
                if (var_c0h == 0) {
                    iVar26 = 0;
                } else {
                    iVar22 = var_c8h * 0x10;
                    iVar11 = *(int64_t *)var_d0h;
                    iVar26 = func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8));
                    uVar16 = 0;
                    if (iVar23 != 0) {
                        do {
                            puVar2 = (undefined4 *)(iVar22 + iVar11 + uVar16 * 0x10);
                            uVar7 = puVar2[1];
                            uVar8 = puVar2[2];
                            uVar9 = puVar2[3];
                            puVar3 = (undefined4 *)(iVar26 + uVar16 * 0x10);
                            *puVar3 = *puVar2;
                            puVar3[1] = uVar7;
                            puVar3[2] = uVar8;
                            puVar3[3] = uVar9;
                            uVar16 = uVar16 + 1;
                        } while (uVar16 < (uint64_t)iVar23);
                    }
                }
                if (iVar15 == 0) {
                    iVar11 = 0;
                } else {
                    iVar11 = *(int64_t *)(arg1 + 0x290) + var_f0h * 8;
                }
                piVar24 = (int64_t *)(arg1 + 0xd8);
                func_0x0001800f1110(arg1, &var_120h, iVar11, iVar15);
                ppiVar5 = (int64_t **)*piVar24;
                var_138h = var_128h;
                iVar15 = (int64_t)*ppiVar5;
                if (iVar15 == 0) {
code_r0x0001800ee9a1:
                    piVar21 = (int64_t *)func_0x000180459890(0x2008);
                    *piVar21 = (int64_t)*ppiVar5;
                    *ppiVar5 = piVar21;
                    piVar21 = piVar21 + 1;
                    piVar12 = (int64_t *)0x40;
                } else {
                    piVar21 = (int64_t *)((int64_t)ppiVar5[1] + iVar15 + 0xf & 0xfffffffffffffff8);
                    if ((int64_t *)(iVar15 + 0x2008) < piVar21 + 8) goto code_r0x0001800ee9a1;
                    piVar12 = (int64_t *)((int64_t)piVar21 + (0x40 - (iVar15 + 8)));
                }
                iVar15 = var_a8h;
                ppiVar5[1] = piVar12;
                *(undefined4 *)(piVar21 + 1) = *(undefined4 *)0x18078275c;
                *(undefined4 *)((int64_t)piVar21 + 0xc) = (undefined4)var_140h;
                *(undefined4 *)(piVar21 + 2) = var_140h._4_4_;
                *(undefined4 *)((int64_t)piVar21 + 0x14) = (undefined4)var_138h;
                *(undefined4 *)(piVar21 + 3) = var_138h._4_4_;
                *piVar21 = 0x180641d20;
                piVar21[4] = iVar26;
                piVar21[5] = iVar23;
                *(undefined4 *)(piVar21 + 6) = (undefined4)var_120h;
                *(undefined4 *)((int64_t)piVar21 + 0x34) = var_120h._4_4_;
                *(undefined4 *)(piVar21 + 7) = (undefined4)var_118h;
                *(undefined4 *)((int64_t)piVar21 + 0x3c) = var_118h._4_4_;
                var_108h = var_98h;
                var_158h = var_a0h;
                var_100h = var_b0h;
                var_110h = var_b8h;
                puVar18 = auStack_188;
                if (*(char *)(arg1 + 0x58) != '\0') {
                    iVar23 = *piVar24;
                    if (var_a8h == 0) {
                        var_130h = var_a8h;
                        var_128h = var_a8h;
                    } else {
                        iVar11 = *(int64_t *)var_b8h;
                        var_130h = func_0x0001800d4d20(iVar23, var_a8h * 8);
                        var_128h = iVar15;
                        if (iVar15 != 0) {
                            uVar16 = iVar11 + var_100h * 8;
                            uVar14 = 0;
                            if (((uint64_t)iVar15 < 2) ||
                               (((uint64_t)var_130h <= uVar16 + (iVar15 + -1) * 8 &&
                                (uVar14 = 0, uVar16 <= (uint64_t)(var_130h + (iVar15 + -1) * 8))))) {
                                do {
                                    *(undefined8 *)(var_130h + uVar14 * 8) = *(undefined8 *)(uVar16 + uVar14 * 8);
                                    uVar14 = uVar14 + 1;
                                } while (uVar14 < (uint64_t)iVar15);
                            } else {
                                func_0x000180498030(var_130h);
                            }
                        }
                    }
                    iVar15 = var_90h;
                    if (var_90h == 0) {
                        var_150h = var_90h;
                    } else {
                        iVar26 = var_108h * 0x10;
                        iVar11 = *(int64_t *)var_158h;
                        var_150h = func_0x0001800d4d20(*piVar24, var_90h << 4);
                        uVar16 = 0;
                        if (iVar15 != 0) {
                            do {
                                puVar2 = (undefined4 *)(iVar26 + iVar11 + uVar16 * 0x10);
                                uVar7 = puVar2[1];
                                uVar8 = puVar2[2];
                                uVar9 = puVar2[3];
                                puVar3 = (undefined4 *)(var_150h + uVar16 * 0x10);
                                *puVar3 = *puVar2;
                                puVar3[1] = uVar7;
                                puVar3[2] = uVar8;
                                puVar3[3] = uVar9;
                                uVar16 = uVar16 + 1;
                            } while (uVar16 < (uint64_t)iVar15);
                        }
                    }
                    var_148h = iVar15;
                    uVar25 = func_0x0001800f19b0(iVar23, &var_150h, &var_130h);
                    var_150h = (int64_t)piVar21;
                    puVar13 = (undefined8 *)func_0x0001800cc970(arg1 + 0x490, &var_150h);
                    *puVar13 = uVar25;
                    puVar18 = auStack_188;
                }
                goto code_r0x0001800eeb91;
            }
            iVar4 = *piVar1;
            if ((iVar4 == 0x10b) || (iVar4 == 0x10c)) {
                func_0x0001800f0350(arg1);
                var_120h = 0;
                var_118h = 0;
                var_110h = func_0x0001800f0080(arg1, &var_130h, &var_120h, 0x180643e28);
                func_0x0001800bf890(arg1 + 0x290, &var_110h);
                var_d8h = var_d8h + 1;
                goto code_r0x0001800ee8c9;
            }
            if (iVar4 == 0x11e) {
                func_0x0001800f0350(arg1);
                var_120h = 0;
                var_118h = 0;
                var_110h = func_0x0001800f0080(arg1, &var_130h, &var_120h, 0x180643f40);
                func_0x0001800bf890(arg1 + 0x290, &var_110h);
                var_d8h = var_d8h + 1;
                goto code_r0x0001800ee8c9;
            }
            var_f8h = func_0x0001800e9350(arg1, 0);
            func_0x0001800bf890(arg1 + 0x290, &var_f8h);
            var_d8h = var_d8h + 1;
            iVar4 = *piVar1;
            if (0x10c < iVar4) {
                if (iVar4 == 0x11e) {
                    func_0x0001800f0350(arg1);
code_r0x0001800ee54b:
                    iVar15 = var_c0h;
                    if (var_c0h == 0) {
                        iVar11 = 0;
                    } else {
                        iVar26 = var_c8h * 0x10;
                        iVar23 = *(int64_t *)var_d0h;
                        iVar11 = func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8));
                        uVar16 = 0;
                        if (iVar15 != 0) {
                            do {
                                puVar2 = (undefined4 *)(iVar26 + iVar23 + uVar16 * 0x10);
                                uVar7 = puVar2[1];
                                uVar8 = puVar2[2];
                                uVar9 = puVar2[3];
                                puVar3 = (undefined4 *)(iVar11 + uVar16 * 0x10);
                                *puVar3 = *puVar2;
                                puVar3[1] = uVar7;
                                puVar3[2] = uVar8;
                                puVar3[3] = uVar9;
                                uVar16 = uVar16 + 1;
                            } while (uVar16 < (uint64_t)iVar15);
                        }
                    }
                    if (var_d8h == 0) {
                        iVar23 = 0;
                    } else {
                        iVar23 = *(int64_t *)(arg1 + 0x290) + var_f0h * 8;
                    }
                    piVar24 = (int64_t *)(arg1 + 0xd8);
                    func_0x0001800f1110(arg1, &var_120h, iVar23, var_d8h);
                    ppiVar5 = (int64_t **)*piVar24;
                    var_138h = *(int64_t *)(arg1 + 0xa8);
                    iVar23 = (int64_t)*ppiVar5;
                    if (iVar23 == 0) {
code_r0x0001800ee63e:
                        piVar21 = (int64_t *)func_0x000180459890(0x2008);
                        *piVar21 = (int64_t)*ppiVar5;
                        *ppiVar5 = piVar21;
                        piVar21 = piVar21 + 1;
                        piVar12 = (int64_t *)0x40;
                    } else {
                        piVar21 = (int64_t *)((int64_t)ppiVar5[1] + iVar23 + 0xf & 0xfffffffffffffff8);
                        if ((int64_t *)(iVar23 + 0x2008) < piVar21 + 8) goto code_r0x0001800ee63e;
                        piVar12 = (int64_t *)((int64_t)piVar21 + (0x40 - (iVar23 + 8)));
                    }
                    iVar23 = var_a8h;
                    ppiVar5[1] = piVar12;
                    *(undefined4 *)(piVar21 + 1) = *(undefined4 *)0x18078275c;
                    *(undefined4 *)((int64_t)piVar21 + 0xc) = (undefined4)var_140h;
                    *(undefined4 *)(piVar21 + 2) = var_140h._4_4_;
                    *(undefined4 *)((int64_t)piVar21 + 0x14) = (undefined4)var_138h;
                    *(undefined4 *)(piVar21 + 3) = var_138h._4_4_;
                    *piVar21 = 0x180641d20;
                    piVar21[4] = iVar11;
                    piVar21[5] = iVar15;
                    *(undefined4 *)(piVar21 + 6) = (undefined4)var_120h;
                    *(undefined4 *)((int64_t)piVar21 + 0x34) = var_120h._4_4_;
                    *(undefined4 *)(piVar21 + 7) = (undefined4)var_118h;
                    *(undefined4 *)((int64_t)piVar21 + 0x3c) = var_118h._4_4_;
                    piVar12 = (int64_t *)var_158h;
                    if (*(char *)(arg1 + 0x58) != '\0') {
                        iVar15 = *piVar24;
                        if (var_a8h == 0) {
                            var_130h = var_a8h;
                            var_128h = var_a8h;
                        } else {
                            iVar11 = *(int64_t *)var_110h;
                            var_130h = func_0x0001800d4d20(iVar15, var_a8h * 8);
                            var_128h = iVar23;
                            if (iVar23 != 0) {
                                uVar16 = iVar11 + var_100h * 8;
                                uVar14 = 0;
                                if (((uint64_t)iVar23 < 2) ||
                                   (((uint64_t)var_130h <= uVar16 + (iVar23 + -1) * 8 &&
                                    (uVar14 = 0, uVar16 <= (uint64_t)(var_130h + (iVar23 + -1) * 8))))) {
                                    do {
                                        *(undefined8 *)(var_130h + uVar14 * 8) = *(undefined8 *)(uVar16 + uVar14 * 8);
                                        uVar14 = uVar14 + 1;
                                    } while (uVar14 < (uint64_t)iVar23);
                                } else {
                                    func_0x000180498030(var_130h);
                                }
                            }
                        }
                        iVar23 = var_90h;
                        piVar12 = (int64_t *)var_158h;
                        if (var_90h == 0) {
                            var_150h = var_90h;
                        } else {
                            iVar26 = var_108h * 0x10;
                            iVar11 = *(int64_t *)var_158h;
                            var_150h = func_0x0001800d4d20(*piVar24, var_90h << 4);
                            uVar16 = 0;
                            if (iVar23 != 0) {
                                do {
                                    puVar2 = (undefined4 *)(iVar26 + iVar11 + uVar16 * 0x10);
                                    uVar7 = puVar2[1];
                                    uVar8 = puVar2[2];
                                    uVar9 = puVar2[3];
                                    puVar3 = (undefined4 *)(var_150h + uVar16 * 0x10);
                                    *puVar3 = *puVar2;
                                    puVar3[1] = uVar7;
                                    puVar3[2] = uVar8;
                                    puVar3[3] = uVar9;
                                    uVar16 = uVar16 + 1;
                                } while (uVar16 < (uint64_t)iVar23);
                            }
                        }
                        var_148h = iVar23;
                        uVar25 = func_0x0001800f19b0(iVar15, &var_150h, &var_130h);
                        var_150h = (int64_t)piVar21;
                        puVar13 = (undefined8 *)func_0x0001800cc970(arg1 + 0x490, &var_150h);
                        *puVar13 = uVar25;
                    }
                    if (*(int64_t *)(arg1 + 0xc0) == *(int64_t *)(arg1 + 200)) {
                        func_0x0001800efe70(arg1, arg1 + 0xa0, 0x180643f40);
                        puVar18 = auStack_188;
                    } else {
                        puVar18 = auStack_188;
                        if (*(int32_t *)(*(int64_t *)(arg1 + 200) + -4) == 0) {
                            func_0x0001800efe70(arg1, arg1 + 0xa0, 0x180643f80);
                            puVar18 = auStack_188;
                        }
                    }
                    goto code_r0x0001800eeb96;
                }
                if (iVar4 == 0x121) goto code_r0x0001800ee513;
                goto code_r0x0001800ee482;
            }
            puVar19 = (uint64_t *)var_150h;
        } while (iVar4 == 0x10c);
        if (iVar4 == 0) goto code_r0x0001800ee54b;
    } while ((iVar4 == 0x10a) || (iVar4 == 0x10b));
code_r0x0001800ee482:
    var_168h = func_0x0001800d62b0(piVar1, &var_78h);
    if (0xf < *(uint64_t *)(var_168h + 0x18)) {
        var_168h = *(int64_t *)var_168h;
    }
    var_140h = 0;
    var_138h = 0;
    func_0x0001800f0080(arg1, &var_130h, &var_140h, 0x180643fc0);
    puVar18 = auStack_188;
    if (0xf < stack0xffffffffffffffa0) {
        uVar16 = stack0xffffffffffffffa0 + 1;
        iVar23 = CONCAT44(var_78h._4_4_, (int32_t)var_78h);
        iVar15 = iVar23;
        if (0xfff < uVar16) {
            iVar15 = *(int64_t *)(iVar23 + -8);
            if (0x1f < (iVar23 - iVar15) - 8U) {
                pcVar6 = (code *)swi(0x29);
                (*pcVar6)(5);
                puVar17 = auStack_180;
code_r0x0001800ee513:
                *(undefined8 *)(puVar17 + -8) = 0x1800ee51b;
                func_0x0001800f0350(arg1);
                *(undefined8 *)(puVar17 + 0x48) = 0;
                *(undefined8 *)(puVar17 + 0x50) = 0;
                uVar25 = 0x180643ce0;
                piVar24 = (int64_t *)(puVar17 + 0x48);
                piVar21 = (int64_t *)(puVar17 + 0x58);
                puVar18 = puVar17;
code_r0x0001800eeb86:
                *(undefined8 *)(puVar18 + -8) = 0x1800eeb8e;
                func_0x0001800f0080(arg1, piVar21, piVar24, uVar25);
                goto code_r0x0001800eeb91;
            }
            uVar16 = stack0xffffffffffffffa0 + 0x28;
        }
        func_0x000180459c3c(iVar15, uVar16);
        puVar18 = auStack_188;
    }
code_r0x0001800eeb91:
    piVar12 = *(int64_t **)(puVar18 + 0x30);
code_r0x0001800eeb96:
    iVar15 = *(int64_t *)var_e8h + var_f0h * 8;
    if (iVar15 != *(int64_t *)(var_e8h + 8)) {
        *(int64_t *)(var_e8h + 8) = iVar15;
    }
    piVar24 = *(int64_t **)(puVar18 + 0x78);
    iVar15 = *piVar24 + var_100h * 8;
    if (iVar15 != piVar24[1]) {
        piVar24[1] = iVar15;
    }
    iVar15 = var_108h * 0x10 + *piVar12;
    if (iVar15 != piVar12[1]) {
        piVar12[1] = iVar15;
    }
    iVar15 = var_c8h * 0x10 + *(int64_t *)var_d0h;
    if (iVar15 != *(int64_t *)(var_d0h + 8)) {
        *(int64_t *)(var_d0h + 8) = iVar15;
    }
    *(undefined8 *)(puVar18 + -8) = 0x1800eec06;
    func_0x000180459870(var_58h ^ (uint64_t)puVar18);
    return;
}

// ============================================================
// Function: FUN_1800eec20
// Address: 0x1800eec20
// Size: 837 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_b0h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h

int64_t * fcn.1800eec20(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t *piVar4;
    uint64_t uVar5;
    int64_t **ppiVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_c8h;
    int64_t var_b8h;
    undefined4 var_b0h;
    undefined4 uStack_ac;
    int64_t var_a8h;
    undefined4 uStack_a0;
    undefined4 uStack_9c;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_6ch;
    undefined4 uStack_64;
    undefined4 uStack_60;
    
    var_18h = arg3;
    if (*(char *)(arg1 + 0x58) == '\0') {
        piVar8 = (int64_t *)0x0;
        piVar4 = piVar8;
    } else {
        ppiVar6 = *(int64_t ***)(arg1 + 0xd8);
        iVar3 = (int64_t)*ppiVar6;
        if (iVar3 == 0) {
code_r0x0001800eec93:
            piVar8 = (int64_t *)func_0x000180459890(0x2008);
            *piVar8 = (int64_t)*ppiVar6;
            *ppiVar6 = piVar8;
            piVar8 = piVar8 + 1;
            piVar4 = (int64_t *)0x38;
        } else {
            piVar8 = (int64_t *)((int64_t)ppiVar6[1] + iVar3 + 0xf & 0xfffffffffffffff8);
            if ((int64_t *)(iVar3 + 0x2008U) < piVar8 + 7) goto code_r0x0001800eec93;
            piVar4 = (int64_t *)((int64_t)piVar8 + (0x38 - (iVar3 + 8)));
        }
        ppiVar6[1] = piVar4;
        *(undefined4 *)piVar8 = *(undefined4 *)0x180782a54;
        piVar8[1] = -1;
        piVar8[2] = -1;
        piVar8[3] = 0;
        piVar8[4] = 0;
        piVar8[5] = -1;
        piVar8[6] = -1;
        piVar4 = piVar8 + 1;
    }
    uVar9 = 0;
    if (piVar4 != (int64_t *)0x0) {
        *piVar4 = *(int64_t *)(arg1 + 0x84);
    }
    uVar2 = *(undefined4 *)(arg1 + 0x80);
    var_6ch._0_4_ = *(undefined4 *)(arg1 + 0x84);
    var_6ch._4_4_ = *(undefined4 *)(arg1 + 0x88);
    uStack_64 = *(undefined4 *)(arg1 + 0x8c);
    uStack_60 = *(undefined4 *)(arg1 + 0x90);
    func_0x0001800d7020(arg1 + 0x60);
    var_88h = arg1 + 0x440;
    var_80h = *(int64_t *)(arg1 + 0x448) - *(int64_t *)var_88h >> 3;
    var_78h = 0;
    if (piVar4 == (int64_t *)0x0) {
        fcn.1800ed8e0(arg1, (int64_t)&var_a8h, 0, 0, 0);
    } else {
        fcn.1800ed8e0(arg1, (int64_t)&var_a8h, (int64_t)(piVar4 + 1), (int64_t)&var_88h, (int64_t)(piVar4 + 4));
        iVar3 = var_78h;
        if (var_78h == 0) {
            uVar5 = 0;
        } else {
            var_20h = *(int64_t *)var_88h;
            uVar5 = func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), var_78h * 8);
            if (iVar3 != 0) {
                uVar1 = var_20h + var_80h * 8;
                if (((uint64_t)iVar3 < 2) ||
                   ((uVar5 <= uVar1 + (iVar3 + -1) * 8 && (uVar1 <= uVar5 + (iVar3 + -1) * 8)))) {
                    do {
                        *(undefined8 *)(uVar5 + uVar9 * 8) = *(undefined8 *)(uVar1 + uVar9 * 8);
                        uVar9 = uVar9 + 1;
                    } while (uVar9 < (uint64_t)iVar3);
                } else {
                    func_0x000180498030(uVar5, uVar1, iVar3 * 8);
                }
            }
        }
        piVar4[2] = uVar5;
        piVar4[3] = iVar3;
        arg3 = var_18h;
        if (*(int32_t *)(arg1 + 0x80) == 0x3e) {
            piVar4[5] = *(int64_t *)(arg1 + 0x84);
        }
    }
    piVar4 = (int64_t *)0x38;
    var_98h._0_4_ = *(undefined4 *)(arg1 + 0x84);
    var_98h._4_4_ = *(undefined4 *)(arg1 + 0x88);
    var_90h._0_4_ = *(undefined4 *)(arg1 + 0x8c);
    var_90h._4_4_ = *(undefined4 *)(arg1 + 0x90);
    var_b8h._4_4_ = (undefined4)var_6ch;
    var_b0h = var_6ch._4_4_;
    var_b8h._0_4_ = uVar2;
    if (*(int32_t *)(arg1 + 0x80) == 0x3e) {
        func_0x0001800f0350(arg1);
    } else {
        func_0x0001800ef5a0(arg1, 0x3e, &var_b8h, 0);
        func_0x0001800ef4e0(arg1, 0x3e);
    }
    iVar3 = *(int64_t *)var_88h + var_80h * 8;
    if (iVar3 != *(int64_t *)(var_88h + 8)) {
        *(int64_t *)(var_88h + 8) = iVar3;
    }
    ppiVar6 = *(int64_t ***)(arg1 + 0xd8);
    var_b0h = (undefined4)var_90h;
    uStack_ac = var_90h._4_4_;
    iVar3 = (int64_t)*ppiVar6;
    if (iVar3 != 0) {
        piVar7 = (int64_t *)((int64_t)ppiVar6[1] + iVar3 + 0xf & 0xfffffffffffffff8);
        if (piVar7 + 7 <= (int64_t *)(iVar3 + 0x2008)) {
            piVar4 = (int64_t *)((int64_t)piVar7 + (0x38 - (iVar3 + 8)));
            goto code_r0x0001800eef05;
        }
    }
    var_b8h = arg2;
    piVar7 = (int64_t *)func_0x000180459890(0x2008);
    *piVar7 = (int64_t)*ppiVar6;
    *ppiVar6 = piVar7;
    piVar7 = piVar7 + 1;
    arg2 = var_b8h;
code_r0x0001800eef05:
    ppiVar6[1] = piVar4;
    *(undefined4 *)(piVar7 + 1) = *(undefined4 *)0x180782674;
    *(int64_t *)((int64_t)piVar7 + 0xc) = arg2;
    *(undefined4 *)((int64_t)piVar7 + 0x14) = var_b0h;
    *(undefined4 *)(piVar7 + 3) = uStack_ac;
    *piVar7 = 0x180641ab8;
    piVar7[4] = arg3;
    *(undefined4 *)(piVar7 + 5) = (undefined4)var_a8h;
    *(undefined4 *)((int64_t)piVar7 + 0x2c) = var_a8h._4_4_;
    *(undefined4 *)(piVar7 + 6) = uStack_a0;
    *(undefined4 *)((int64_t)piVar7 + 0x34) = uStack_9c;
    if (*(char *)(arg1 + 0x58) != '\0') {
        var_18h = (int64_t)piVar7;
        var_b8h = arg2;
        ppiVar6 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_18h);
        *ppiVar6 = piVar8;
    }
    return piVar7;
}

// ============================================================
// Function: FUN_1800eef70
// Address: 0x1800eef70
// Size: 247 bytes
// ============================================================
int64_t * fcn.1800eef70(int64_t arg1, int64_t arg2, int64_t arg_d8h, int64_t arg_148h, int64_t arg_150h,
                       int64_t arg_190h)
{
    undefined uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t **ppiVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    int64_t **ppiVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    
    ppiVar11 = (int64_t **)func_0x0001800f30a0(arg1 + 0x168);
    iVar3 = *(int64_t *)(arg1 + 0x150);
    ppiVar4 = *(int64_t ***)(arg1 + 0xd8);
    iVar5 = *(int64_t *)(arg1 + 0x148);
    iVar6 = (int64_t)*ppiVar4;
    if (iVar6 != 0) {
        piVar13 = (int64_t *)((int64_t)ppiVar4[1] + iVar6 + 0xf & 0xfffffffffffffff8);
        if (piVar13 + 8 <= (int64_t *)(iVar6 + 0x2008U)) {
            piVar12 = (int64_t *)((int64_t)piVar13 + (0x40 - (iVar6 + 8)));
            goto code_r0x0001800ef008;
        }
    }
    piVar12 = (int64_t *)func_0x000180459890(0x2008);
    *piVar12 = (int64_t)*ppiVar4;
    piVar13 = piVar12 + 1;
    *ppiVar4 = piVar12;
    piVar12 = (int64_t *)0x40;
code_r0x0001800ef008:
    ppiVar4[1] = piVar12;
    uVar2 = *(uint32_t *)(iVar3 + -4);
    piVar12 = *ppiVar11;
    uVar1 = *(undefined *)(arg2 + 0x28);
    iVar6 = *(int64_t *)(arg2 + 0x18);
    *piVar13 = *(int64_t *)arg2;
    uVar7 = *(undefined4 *)(arg2 + 8);
    uVar8 = *(undefined4 *)(arg2 + 0xc);
    uVar9 = *(undefined4 *)(arg2 + 0x10);
    uVar10 = *(undefined4 *)(arg2 + 0x14);
    piVar13[3] = (int64_t)piVar12;
    piVar13[5] = (uint64_t)uVar2;
    *(undefined4 *)(piVar13 + 1) = uVar7;
    *(undefined4 *)((int64_t)piVar13 + 0xc) = uVar8;
    *(undefined4 *)(piVar13 + 2) = uVar9;
    *(undefined4 *)((int64_t)piVar13 + 0x14) = uVar10;
    piVar13[4] = (iVar3 - iVar5 >> 3) + -1;
    *(undefined *)(piVar13 + 6) = uVar1;
    *(undefined *)((int64_t)piVar13 + 0x31) = 0;
    piVar13[7] = iVar6;
    *ppiVar11 = piVar13;
    func_0x0001800bf890(arg1 + 400, ppiVar11);
    return *ppiVar11;
}

// ============================================================
// Function: FUN_1800ef070
// Address: 0x1800ef070
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.1800ef070(int64_t arg1, int64_t arg2, int64_t arg_80h)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    code *pcVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    uint64_t *puVar10;
    uint64_t uVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_68h;
    int64_t var_48h;
    undefined auStack_40 [8];
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    piVar1 = (int64_t *)(arg1 + 400);
    var_48h = arg2 & 0xffffffff;
    uVar15 = *(int64_t *)(arg1 + 0x198) - *piVar1 >> 3;
    if ((uint64_t)var_48h < uVar15) {
        piVar13 = (int64_t *)(arg1 + 0x168);
        do {
            iVar6 = *(int64_t *)(arg1 + 0x170);
            iVar2 = *(int64_t *)(*piVar1 + -8 + uVar15 * 8);
            uVar3 = *(undefined8 *)(iVar2 + 0x18);
            if (((uint64_t)(iVar6 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x178)) &&
               (iVar5 = func_0x0001800ac7f0(piVar13), iVar5 == 0)) {
                uVar7 = *(uint64_t *)(arg1 + 0x180);
                if (iVar6 == 0) {
                    uVar11 = 0x10;
                    iVar5 = func_0x000180459890(0x100);
                    uVar8 = 0;
                    iVar6 = iVar5;
                    uVar16 = 0x10;
code_r0x0001800ef170:
                    do {
                        uVar9 = uVar8 + 1;
                        *(uint64_t *)(iVar6 + uVar8 * 0x10) = *(uint64_t *)(arg1 + 0x180);
                        *(undefined8 *)(iVar6 + 8 + uVar8 * 0x10) = 0;
                        uVar8 = uVar9;
                    } while (uVar9 < uVar11);
                } else {
                    uVar11 = iVar6 * 2;
                    if (uVar11 == 0) {
                        iVar5 = 0;
                        uVar16 = 0;
                    } else {
                        iVar5 = func_0x000180459890(iVar6 << 5);
                        uVar8 = 0;
                        iVar6 = iVar5;
                        uVar16 = uVar11;
                        if (uVar11 != 0) goto code_r0x0001800ef170;
                    }
                }
                uVar11 = 0;
                if (*(int64_t *)(arg1 + 0x170) != 0) {
                    do {
                        uVar8 = *(uint64_t *)(*piVar13 + uVar11 * 0x10);
                        if (uVar8 != *(uint64_t *)(arg1 + 0x180)) {
                            uVar9 = (uVar8 >> 5 ^ uVar8) >> 4;
                            uVar14 = 0;
                            do {
                                uVar9 = uVar9 & uVar16 - 1;
                                puVar10 = (uint64_t *)(uVar9 * 0x10 + iVar5);
                                if (*puVar10 == uVar7) {
                                    *puVar10 = uVar8;
                                    goto code_r0x0001800ef206;
                                }
                                if (*puVar10 == uVar8) goto code_r0x0001800ef206;
                                uVar9 = uVar9 + 1 + uVar14;
                                uVar14 = uVar14 + 1;
                            } while (uVar14 <= uVar16 - 1);
                            puVar10 = (uint64_t *)0x0;
code_r0x0001800ef206:
                            iVar6 = *piVar13;
                            *puVar10 = *(uint64_t *)(iVar6 + uVar11 * 0x10);
                            puVar10[1] = *(uint64_t *)(iVar6 + 8 + uVar11 * 0x10);
                        }
                        uVar11 = uVar11 + 1;
                    } while (uVar11 < *(uint64_t *)(arg1 + 0x170));
                }
                iVar6 = *piVar13;
                *piVar13 = iVar5;
                *(uint64_t *)(arg1 + 0x170) = uVar16;
                if (iVar6 != 0) {
                    func_0x0001800f4640();
                }
            }
            iVar6 = func_0x0001800c1340(piVar13, iVar2);
            uVar15 = uVar15 - 1;
            *(undefined8 *)(iVar6 + 8) = uVar3;
        } while ((uint64_t)var_48h < uVar15);
    }
    iVar5 = var_48h;
    piVar12 = &var_48h;
    piVar13 = &var_48h;
    iVar6 = *(int64_t *)(arg1 + 0x198);
    iVar2 = *piVar1;
    uVar15 = iVar6 - iVar2 >> 3;
    if ((uint64_t)var_48h < uVar15) {
        *(int64_t *)(arg1 + 0x198) = iVar2 + var_48h * 8;
        return;
    }
    if (uVar15 < (uint64_t)var_48h) {
        uVar7 = *(int64_t *)(arg1 + 0x1a0) - iVar2 >> 3;
        if ((uint64_t)var_48h <= uVar7) {
            iVar2 = (var_48h - uVar15) * 8;
            func_0x0001804986e0(iVar6, 0, iVar2);
            *(int64_t *)(arg1 + 0x198) = iVar2 + iVar6;
            return;
        }
        if (0x1fffffffffffffff < (uint64_t)var_48h) {
            func_0x000180010010();
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        if ((0x1fffffffffffffff - (uVar7 >> 1) < uVar7) ||
           ((uVar7 = uVar7 + (uVar7 >> 1), uVar11 = var_48h, (uint64_t)var_48h <= uVar7 &&
            (uVar11 = uVar7, 0x1fffffffffffffff < uVar7)))) {
code_r0x0001800c0fb8:
            func_0x000180004720();
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        uVar7 = uVar11 * 8;
        if (uVar7 == 0) {
            uVar7 = 0;
            piVar13 = &var_48h;
        } else if (uVar7 < 0x1000) {
            uVar7 = func_0x000180459890();
        } else {
            if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800c0fb8;
            iVar6 = func_0x000180459890(uVar7 + 0x27);
            if (iVar6 == 0) {
                pcVar4 = (code *)swi(0x29);
                iVar6 = (*pcVar4)(5);
                piVar12 = (int64_t *)auStack_40;
            }
            uVar7 = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar7 - 8) = iVar6;
            piVar13 = piVar12;
        }
        *(undefined8 *)((int64_t)piVar13 + -8) = 0x1800c0f5c;
        func_0x0001804986e0(uVar7 + uVar15 * 8, 0, (iVar5 - uVar15) * 8);
        iVar6 = *piVar1;
        iVar2 = *(int64_t *)(arg1 + 0x198);
        *(undefined8 *)((int64_t)piVar13 + -8) = 0x1800c0f6e;
        func_0x000180498030(uVar7, iVar6, iVar2 - iVar6);
        *(undefined8 *)((int64_t)piVar13 + -8) = 0x1800c0f7f;
        func_0x0001800c2120(piVar1, uVar7, iVar5, uVar11);
    }
    return;
}

// ============================================================
// Function: FUN_1800ef0a2
// Address: 0x1800ef0a2
// Size: 486 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.1800ef070(int64_t arg1, int64_t arg2, int64_t arg_80h)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    code *pcVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    uint64_t *puVar10;
    uint64_t uVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_68h;
    int64_t var_48h;
    undefined auStack_40 [8];
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    piVar1 = (int64_t *)(arg1 + 400);
    var_48h = arg2 & 0xffffffff;
    uVar15 = *(int64_t *)(arg1 + 0x198) - *piVar1 >> 3;
    if ((uint64_t)var_48h < uVar15) {
        piVar13 = (int64_t *)(arg1 + 0x168);
        do {
            iVar6 = *(int64_t *)(arg1 + 0x170);
            iVar2 = *(int64_t *)(*piVar1 + -8 + uVar15 * 8);
            uVar3 = *(undefined8 *)(iVar2 + 0x18);
            if (((uint64_t)(iVar6 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x178)) &&
               (iVar5 = func_0x0001800ac7f0(piVar13), iVar5 == 0)) {
                uVar7 = *(uint64_t *)(arg1 + 0x180);
                if (iVar6 == 0) {
                    uVar11 = 0x10;
                    iVar5 = func_0x000180459890(0x100);
                    uVar8 = 0;
                    iVar6 = iVar5;
                    uVar16 = 0x10;
code_r0x0001800ef170:
                    do {
                        uVar9 = uVar8 + 1;
                        *(uint64_t *)(iVar6 + uVar8 * 0x10) = *(uint64_t *)(arg1 + 0x180);
                        *(undefined8 *)(iVar6 + 8 + uVar8 * 0x10) = 0;
                        uVar8 = uVar9;
                    } while (uVar9 < uVar11);
                } else {
                    uVar11 = iVar6 * 2;
                    if (uVar11 == 0) {
                        iVar5 = 0;
                        uVar16 = 0;
                    } else {
                        iVar5 = func_0x000180459890(iVar6 << 5);
                        uVar8 = 0;
                        iVar6 = iVar5;
                        uVar16 = uVar11;
                        if (uVar11 != 0) goto code_r0x0001800ef170;
                    }
                }
                uVar11 = 0;
                if (*(int64_t *)(arg1 + 0x170) != 0) {
                    do {
                        uVar8 = *(uint64_t *)(*piVar13 + uVar11 * 0x10);
                        if (uVar8 != *(uint64_t *)(arg1 + 0x180)) {
                            uVar9 = (uVar8 >> 5 ^ uVar8) >> 4;
                            uVar14 = 0;
                            do {
                                uVar9 = uVar9 & uVar16 - 1;
                                puVar10 = (uint64_t *)(uVar9 * 0x10 + iVar5);
                                if (*puVar10 == uVar7) {
                                    *puVar10 = uVar8;
                                    goto code_r0x0001800ef206;
                                }
                                if (*puVar10 == uVar8) goto code_r0x0001800ef206;
                                uVar9 = uVar9 + 1 + uVar14;
                                uVar14 = uVar14 + 1;
                            } while (uVar14 <= uVar16 - 1);
                            puVar10 = (uint64_t *)0x0;
code_r0x0001800ef206:
                            iVar6 = *piVar13;
                            *puVar10 = *(uint64_t *)(iVar6 + uVar11 * 0x10);
                            puVar10[1] = *(uint64_t *)(iVar6 + 8 + uVar11 * 0x10);
                        }
                        uVar11 = uVar11 + 1;
                    } while (uVar11 < *(uint64_t *)(arg1 + 0x170));
                }
                iVar6 = *piVar13;
                *piVar13 = iVar5;
                *(uint64_t *)(arg1 + 0x170) = uVar16;
                if (iVar6 != 0) {
                    func_0x0001800f4640();
                }
            }
            iVar6 = func_0x0001800c1340(piVar13, iVar2);
            uVar15 = uVar15 - 1;
            *(undefined8 *)(iVar6 + 8) = uVar3;
        } while ((uint64_t)var_48h < uVar15);
    }
    iVar5 = var_48h;
    piVar12 = &var_48h;
    piVar13 = &var_48h;
    iVar6 = *(int64_t *)(arg1 + 0x198);
    iVar2 = *piVar1;
    uVar15 = iVar6 - iVar2 >> 3;
    if ((uint64_t)var_48h < uVar15) {
        *(int64_t *)(arg1 + 0x198) = iVar2 + var_48h * 8;
        return;
    }
    if (uVar15 < (uint64_t)var_48h) {
        uVar7 = *(int64_t *)(arg1 + 0x1a0) - iVar2 >> 3;
        if ((uint64_t)var_48h <= uVar7) {
            iVar2 = (var_48h - uVar15) * 8;
            func_0x0001804986e0(iVar6, 0, iVar2);
            *(int64_t *)(arg1 + 0x198) = iVar2 + iVar6;
            return;
        }
        if (0x1fffffffffffffff < (uint64_t)var_48h) {
            func_0x000180010010();
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        if ((0x1fffffffffffffff - (uVar7 >> 1) < uVar7) ||
           ((uVar7 = uVar7 + (uVar7 >> 1), uVar11 = var_48h, (uint64_t)var_48h <= uVar7 &&
            (uVar11 = uVar7, 0x1fffffffffffffff < uVar7)))) {
code_r0x0001800c0fb8:
            func_0x000180004720();
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        uVar7 = uVar11 * 8;
        if (uVar7 == 0) {
            uVar7 = 0;
            piVar13 = &var_48h;
        } else if (uVar7 < 0x1000) {
            uVar7 = func_0x000180459890();
        } else {
            if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800c0fb8;
            iVar6 = func_0x000180459890(uVar7 + 0x27);
            if (iVar6 == 0) {
                pcVar4 = (code *)swi(0x29);
                iVar6 = (*pcVar4)(5);
                piVar12 = (int64_t *)auStack_40;
            }
            uVar7 = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar7 - 8) = iVar6;
            piVar13 = piVar12;
        }
        *(undefined8 *)((int64_t)piVar13 + -8) = 0x1800c0f5c;
        func_0x0001804986e0(uVar7 + uVar15 * 8, 0, (iVar5 - uVar15) * 8);
        iVar6 = *piVar1;
        iVar2 = *(int64_t *)(arg1 + 0x198);
        *(undefined8 *)((int64_t)piVar13 + -8) = 0x1800c0f6e;
        func_0x000180498030(uVar7, iVar6, iVar2 - iVar6);
        *(undefined8 *)((int64_t)piVar13 + -8) = 0x1800c0f7f;
        func_0x0001800c2120(piVar1, uVar7, iVar5, uVar11);
    }
    return;
}

// ============================================================
// Function: FUN_1800ef288
// Address: 0x1800ef288
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.1800ef070(int64_t arg1, int64_t arg2, int64_t arg_80h)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    code *pcVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    uint64_t *puVar10;
    uint64_t uVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_68h;
    int64_t var_48h;
    undefined auStack_40 [8];
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    piVar1 = (int64_t *)(arg1 + 400);
    var_48h = arg2 & 0xffffffff;
    uVar15 = *(int64_t *)(arg1 + 0x198) - *piVar1 >> 3;
    if ((uint64_t)var_48h < uVar15) {
        piVar13 = (int64_t *)(arg1 + 0x168);
        do {
            iVar6 = *(int64_t *)(arg1 + 0x170);
            iVar2 = *(int64_t *)(*piVar1 + -8 + uVar15 * 8);
            uVar3 = *(undefined8 *)(iVar2 + 0x18);
            if (((uint64_t)(iVar6 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x178)) &&
               (iVar5 = func_0x0001800ac7f0(piVar13), iVar5 == 0)) {
                uVar7 = *(uint64_t *)(arg1 + 0x180);
                if (iVar6 == 0) {
                    uVar11 = 0x10;
                    iVar5 = func_0x000180459890(0x100);
                    uVar8 = 0;
                    iVar6 = iVar5;
                    uVar16 = 0x10;
code_r0x0001800ef170:
                    do {
                        uVar9 = uVar8 + 1;
                        *(uint64_t *)(iVar6 + uVar8 * 0x10) = *(uint64_t *)(arg1 + 0x180);
                        *(undefined8 *)(iVar6 + 8 + uVar8 * 0x10) = 0;
                        uVar8 = uVar9;
                    } while (uVar9 < uVar11);
                } else {
                    uVar11 = iVar6 * 2;
                    if (uVar11 == 0) {
                        iVar5 = 0;
                        uVar16 = 0;
                    } else {
                        iVar5 = func_0x000180459890(iVar6 << 5);
                        uVar8 = 0;
                        iVar6 = iVar5;
                        uVar16 = uVar11;
                        if (uVar11 != 0) goto code_r0x0001800ef170;
                    }
                }
                uVar11 = 0;
                if (*(int64_t *)(arg1 + 0x170) != 0) {
                    do {
                        uVar8 = *(uint64_t *)(*piVar13 + uVar11 * 0x10);
                        if (uVar8 != *(uint64_t *)(arg1 + 0x180)) {
                            uVar9 = (uVar8 >> 5 ^ uVar8) >> 4;
                            uVar14 = 0;
                            do {
                                uVar9 = uVar9 & uVar16 - 1;
                                puVar10 = (uint64_t *)(uVar9 * 0x10 + iVar5);
                                if (*puVar10 == uVar7) {
                                    *puVar10 = uVar8;
                                    goto code_r0x0001800ef206;
                                }
                                if (*puVar10 == uVar8) goto code_r0x0001800ef206;
                                uVar9 = uVar9 + 1 + uVar14;
                                uVar14 = uVar14 + 1;
                            } while (uVar14 <= uVar16 - 1);
                            puVar10 = (uint64_t *)0x0;
code_r0x0001800ef206:
                            iVar6 = *piVar13;
                            *puVar10 = *(uint64_t *)(iVar6 + uVar11 * 0x10);
                            puVar10[1] = *(uint64_t *)(iVar6 + 8 + uVar11 * 0x10);
                        }
                        uVar11 = uVar11 + 1;
                    } while (uVar11 < *(uint64_t *)(arg1 + 0x170));
                }
                iVar6 = *piVar13;
                *piVar13 = iVar5;
                *(uint64_t *)(arg1 + 0x170) = uVar16;
                if (iVar6 != 0) {
                    func_0x0001800f4640();
                }
            }
            iVar6 = func_0x0001800c1340(piVar13, iVar2);
            uVar15 = uVar15 - 1;
            *(undefined8 *)(iVar6 + 8) = uVar3;
        } while ((uint64_t)var_48h < uVar15);
    }
    iVar5 = var_48h;
    piVar12 = &var_48h;
    piVar13 = &var_48h;
    iVar6 = *(int64_t *)(arg1 + 0x198);
    iVar2 = *piVar1;
    uVar15 = iVar6 - iVar2 >> 3;
    if ((uint64_t)var_48h < uVar15) {
        *(int64_t *)(arg1 + 0x198) = iVar2 + var_48h * 8;
        return;
    }
    if (uVar15 < (uint64_t)var_48h) {
        uVar7 = *(int64_t *)(arg1 + 0x1a0) - iVar2 >> 3;
        if ((uint64_t)var_48h <= uVar7) {
            iVar2 = (var_48h - uVar15) * 8;
            func_0x0001804986e0(iVar6, 0, iVar2);
            *(int64_t *)(arg1 + 0x198) = iVar2 + iVar6;
            return;
        }
        if (0x1fffffffffffffff < (uint64_t)var_48h) {
            func_0x000180010010();
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        if ((0x1fffffffffffffff - (uVar7 >> 1) < uVar7) ||
           ((uVar7 = uVar7 + (uVar7 >> 1), uVar11 = var_48h, (uint64_t)var_48h <= uVar7 &&
            (uVar11 = uVar7, 0x1fffffffffffffff < uVar7)))) {
code_r0x0001800c0fb8:
            func_0x000180004720();
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        uVar7 = uVar11 * 8;
        if (uVar7 == 0) {
            uVar7 = 0;
            piVar13 = &var_48h;
        } else if (uVar7 < 0x1000) {
            uVar7 = func_0x000180459890();
        } else {
            if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800c0fb8;
            iVar6 = func_0x000180459890(uVar7 + 0x27);
            if (iVar6 == 0) {
                pcVar4 = (code *)swi(0x29);
                iVar6 = (*pcVar4)(5);
                piVar12 = (int64_t *)auStack_40;
            }
            uVar7 = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar7 - 8) = iVar6;
            piVar13 = piVar12;
        }
        *(undefined8 *)((int64_t)piVar13 + -8) = 0x1800c0f5c;
        func_0x0001804986e0(uVar7 + uVar15 * 8, 0, (iVar5 - uVar15) * 8);
        iVar6 = *piVar1;
        iVar2 = *(int64_t *)(arg1 + 0x198);
        *(undefined8 *)((int64_t)piVar13 + -8) = 0x1800c0f6e;
        func_0x000180498030(uVar7, iVar6, iVar2 - iVar6);
        *(undefined8 *)((int64_t)piVar13 + -8) = 0x1800c0f7f;
        func_0x0001800c2120(piVar1, uVar7, iVar5, uVar11);
    }
    return;
}

// ============================================================
// Function: FUN_1800ef2a0
// Address: 0x1800ef2a0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

undefined fcn.1800ef2a0(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int64_t var_8h;
    int64_t var_28h;
    
    fcn.1800ef2f0();
    piVar1 = (int32_t *)fcn.1800d70e0(arg1 + 0x60, &var_28h);
    if (*piVar1 == (int32_t)arg2) {
        fcn.1800f0350(arg1);
        fcn.1800f0350(arg1);
    }
    return 0;
}

// ============================================================
// Function: FUN_1800ef2f0
// Address: 0x1800ef2f0
// Size: 377 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h

void fcn.1800ef2f0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t *piVar5;
    int64_t var_10h;
    undefined8 uStack_c0;
    undefined auStack_b8 [8];
    undefined auStack_b0 [24];
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_74h;
    int64_t var_6ch;
    int64_t var_60h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_28h;
    int64_t var_20h;
    
    puVar4 = auStack_b8;
    var_20h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_b8;
    var_88h = 0;
    var_80h._0_4_ = (undefined4)arg2;
    stack0xffffffffffffff84 = 0;
    var_74h = 0;
    var_6ch._0_4_ = 0;
    stack0xffffffffffffff98 = 0;
    func_0x0001800d62b0(&var_80h, &var_40h);
    func_0x0001800d62b0(arg1 + 0x80, &var_60h);
    var_98h = (int64_t)&var_60h;
    if (arg3 == 0) {
        if (0xf < (uint64_t)var_48h) {
            var_98h = CONCAT71(var_60h._1_7_, (undefined)var_60h);
        }
        piVar5 = &var_40h;
        if (0xf < (uint64_t)var_28h) {
            piVar5 = (int64_t *)var_40h;
        }
        func_0x0001800efe70(arg1, arg1 + 0x84, 0x180644100, piVar5);
    } else {
        if (0xf < (uint64_t)var_48h) {
            var_98h = CONCAT71(var_60h._1_7_, (undefined)var_60h);
        }
        piVar5 = &var_40h;
        if (0xf < (uint64_t)var_28h) {
            piVar5 = (int64_t *)var_40h;
        }
        var_90h = var_98h;
        var_98h = arg3;
        func_0x0001800efe70(arg1, arg1 + 0x84, 0x1806440d8, piVar5);
    }
    if (0xf < (uint64_t)var_48h) {
        iVar2 = CONCAT71(var_60h._1_7_, (undefined)var_60h);
        iVar3 = iVar2;
        puVar4 = auStack_b8;
        if ((0xfff < var_48h + 1U) &&
           (iVar3 = *(int64_t *)(iVar2 + -8), puVar4 = auStack_b8, 0x1f < (iVar2 - iVar3) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar3 = (*pcVar1)(5);
            puVar4 = auStack_b0;
        }
        *(undefined8 *)(puVar4 + -8) = 0x1800ef3fa;
        func_0x000180459c3c(iVar3);
    }
    var_50h = 0;
    var_48h = 0xf;
    var_60h._0_1_ = 0;
    if (0xf < (uint64_t)var_28h) {
        iVar3 = var_40h;
        if ((0xfff < var_28h + 1U) && (iVar3 = *(int64_t *)(var_40h + -8), 0x1f < (var_40h - iVar3) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar3 = (*pcVar1)(5);
            puVar4 = puVar4 + 8;
        }
        *(undefined8 *)(puVar4 + -8) = 0x1800ef44a;
        func_0x000180459c3c(iVar3);
    }
    *(undefined8 *)(puVar4 + -8) = 0x1800ef456;
    func_0x000180459870(var_20h ^ (uint64_t)puVar4);
    return;
}

// ============================================================
// Function: FUN_1800ef470
// Address: 0x1800ef470
// Size: 97 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

undefined8 fcn.1800ef470(int64_t arg1)
{
    int32_t iVar1;
    int32_t iVar2;
    uint32_t uVar3;
    uint32_t *puVar4;
    uint8_t in_DL;
    uint32_t uVar5;
    char in_R9B;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_28h;
    
    if (*(uint32_t *)(arg1 + 0x80) == (uint32_t)in_DL) {
        fcn.1800f0350(arg1, in_DL);
        return 1;
    }
    func_0x0001800ef5a0();
    uVar5 = (uint32_t)in_DL;
    if (in_R9B == '\0') {
        puVar4 = (uint32_t *)fcn.1800d70e0(arg1 + 0x60, &var_28h);
        if (*puVar4 == uVar5) {
            fcn.1800f0350(arg1);
            fcn.1800f0350(arg1);
            return 1;
        }
    } else {
        iVar2 = *(int32_t *)(arg1 + 0xa8);
        uVar3 = *(uint32_t *)(arg1 + 0x80);
        iVar1 = *(int32_t *)(arg1 + 0x84);
        while (iVar2 == iVar1) {
            if (uVar3 == uVar5) goto code_r0x0001800ef53e;
            if (*(int32_t *)(*(int64_t *)(arg1 + 0x1e8) + (int64_t)(int32_t)uVar3 * 4) != 0) {
                return 0;
            }
            fcn.1800f0350(arg1);
            uVar3 = *(uint32_t *)(arg1 + 0x80);
            iVar1 = *(int32_t *)(arg1 + 0x84);
        }
        if (uVar3 == uVar5) {
code_r0x0001800ef53e:
            fcn.1800f0350(arg1);
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1800ef4e0
// Address: 0x1800ef4e0
// Size: 186 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

undefined8 fcn.1800ef470(int64_t arg1)
{
    int32_t iVar1;
    int32_t iVar2;
    uint32_t uVar3;
    uint32_t *puVar4;
    uint8_t in_DL;
    uint32_t uVar5;
    char in_R9B;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_28h;
    
    if (*(uint32_t *)(arg1 + 0x80) == (uint32_t)in_DL) {
        fcn.1800f0350(arg1, in_DL);
        return 1;
    }
    func_0x0001800ef5a0();
    uVar5 = (uint32_t)in_DL;
    if (in_R9B == '\0') {
        puVar4 = (uint32_t *)fcn.1800d70e0(arg1 + 0x60, &var_28h);
        if (*puVar4 == uVar5) {
            fcn.1800f0350(arg1);
            fcn.1800f0350(arg1);
            return 1;
        }
    } else {
        iVar2 = *(int32_t *)(arg1 + 0xa8);
        uVar3 = *(uint32_t *)(arg1 + 0x80);
        iVar1 = *(int32_t *)(arg1 + 0x84);
        while (iVar2 == iVar1) {
            if (uVar3 == uVar5) goto code_r0x0001800ef53e;
            if (*(int32_t *)(*(int64_t *)(arg1 + 0x1e8) + (int64_t)(int32_t)uVar3 * 4) != 0) {
                return 0;
            }
            fcn.1800f0350(arg1);
            uVar3 = *(uint32_t *)(arg1 + 0x80);
            iVar1 = *(int32_t *)(arg1 + 0x84);
        }
        if (uVar3 == uVar5) {
code_r0x0001800ef53e:
            fcn.1800f0350(arg1);
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1800ef5a0
// Address: 0x1800ef5a0
// Size: 617 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_ach
// WARNING: [rz-ghidra] Detected overlap for variable var_98h

void fcn.1800ef5a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t *piVar5;
    int64_t var_10h;
    undefined8 uStack_100;
    undefined auStack_f8 [8];
    undefined auStack_f0 [24];
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a4h;
    int64_t var_9ch;
    int64_t var_90h;
    undefined4 uStack_88;
    int64_t var_84h;
    int64_t var_7ch;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_38h;
    int64_t var_30h;
    
    puVar4 = auStack_f8;
    var_30h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_f8;
    var_b8h = 0;
    var_90h._0_4_ = (undefined4)arg2;
    var_90h._4_4_ = 0;
    uStack_88 = 0;
    var_84h = 0;
    var_7ch._0_4_ = 0;
    stack0xffffffffffffff88 = 0;
    func_0x0001800d62b0(&var_90h, &var_50h);
    var_b8h = 0;
    var_b0h._0_4_ = *(undefined4 *)arg3;
    stack0xffffffffffffff54 = 0;
    var_a4h = 0;
    var_9ch._0_4_ = 0;
    stack0xffffffffffffff68 = 0;
    func_0x0001800d62b0(&var_b0h, &var_70h);
    if (*(int32_t *)(arg1 + 0x84) == *(int32_t *)(arg3 + 4)) {
        var_c8h = func_0x0001800d62b0(arg1 + 0x80, &var_90h);
        if (0xf < *(uint64_t *)(var_c8h + 0x18)) {
            var_c8h = *(int64_t *)var_c8h;
        }
        var_d0h._0_4_ = *(int32_t *)(arg3 + 8) + 1;
        var_d8h = (int64_t)&var_70h;
        if (0xf < (uint64_t)var_58h) {
            var_d8h = CONCAT71(var_70h._1_7_, (undefined)var_70h);
        }
        piVar5 = &var_50h;
        if (0xf < (uint64_t)var_38h) {
            piVar5 = (int64_t *)var_50h;
        }
        var_c0h = 0x1805aadb1;
        if (arg4 != 0) {
            var_c0h = arg4;
        }
        func_0x0001800efe70(arg1, arg1 + 0x84, 0x180644118, piVar5);
    } else {
        var_c8h = func_0x0001800d62b0(arg1 + 0x80, &var_90h);
        if (0xf < *(uint64_t *)(var_c8h + 0x18)) {
            var_c8h = *(int64_t *)var_c8h;
        }
        var_d0h._0_4_ = *(int32_t *)(arg3 + 4) + 1;
        var_d8h = (int64_t)&var_70h;
        if (0xf < (uint64_t)var_58h) {
            var_d8h = CONCAT71(var_70h._1_7_, (undefined)var_70h);
        }
        piVar5 = &var_50h;
        if (0xf < (uint64_t)var_38h) {
            piVar5 = (int64_t *)var_50h;
        }
        var_c0h = 0x1805aadb1;
        if (arg4 != 0) {
            var_c0h = arg4;
        }
        func_0x0001800efe70(arg1, arg1 + 0x84, 0x180643ff0, piVar5);
    }
    if (0xf < stack0xffffffffffffff88) {
        iVar2 = CONCAT44(var_90h._4_4_, (undefined4)var_90h);
        iVar3 = iVar2;
        puVar4 = auStack_f8;
        if ((0xfff < stack0xffffffffffffff88 + 1) &&
           (iVar3 = *(int64_t *)(iVar2 + -8), puVar4 = auStack_f8, 0x1f < (iVar2 - iVar3) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar3 = (*pcVar1)(5);
            puVar4 = auStack_f0;
        }
        *(undefined8 *)(puVar4 + -8) = 0x1800ef755;
        func_0x000180459c3c(iVar3);
    }
    if (0xf < (uint64_t)var_58h) {
        iVar2 = CONCAT71(var_70h._1_7_, (undefined)var_70h);
        iVar3 = iVar2;
        if ((0xfff < var_58h + 1U) && (iVar3 = *(int64_t *)(iVar2 + -8), 0x1f < (iVar2 - iVar3) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar3 = (*pcVar1)(5);
            puVar4 = puVar4 + 8;
        }
        *(undefined8 *)(puVar4 + -8) = 0x1800ef796;
        func_0x000180459c3c(iVar3);
    }
    var_60h = 0;
    var_58h = 0xf;
    var_70h._0_1_ = 0;
    if (0xf < (uint64_t)var_38h) {
        iVar3 = var_50h;
        if ((0xfff < var_38h + 1U) && (iVar3 = *(int64_t *)(var_50h + -8), 0x1f < (var_50h - iVar3) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar3 = (*pcVar1)(5);
            puVar4 = puVar4 + 8;
        }
        *(undefined8 *)(puVar4 + -8) = 0x1800ef7e6;
        func_0x000180459c3c(iVar3);
    }
    *(undefined8 *)(puVar4 + -8) = 0x1800ef7f2;
    func_0x000180459870(var_30h ^ (uint64_t)puVar4);
    return;
}

// ============================================================
// Function: FUN_1800ef810
// Address: 0x1800ef810
// Size: 88 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_ach
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

undefined8 fcn.1800ef810(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t *piVar4;
    undefined8 uVar5;
    undefined *puVar6;
    int64_t *piVar7;
    undefined8 uStack_c0;
    undefined auStack_b8 [8];
    undefined auStack_b0 [24];
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_84h;
    int64_t var_7ch;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_38h;
    int64_t var_30h;
    
    if (*(int32_t *)(arg1 + 0x80) == (int32_t)arg2) {
        if (((*(uint32_t *)(arg1 + 0x84) != *(uint32_t *)(arg3 + 4)) &&
            (*(int32_t *)(arg1 + 0x88) != *(int32_t *)(arg3 + 8))) &&
           (*(uint32_t *)(arg1 + 0x13c) < *(uint32_t *)(arg3 + 4))) {
            *(undefined8 *)(arg1 + 0x138) = *(undefined8 *)arg3;
            *(undefined4 *)(arg1 + 0x140) = *(undefined4 *)(arg3 + 8);
        }
        var_30h = 0x1800ef861;
        fcn.1800f0350();
        return 1;
    }
    puVar6 = auStack_b8;
    var_30h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_b8;
    if ((*(int32_t *)(arg1 + 0x138) == 0) || (*(uint32_t *)(arg1 + 0x13c) <= *(uint32_t *)(arg3 + 4))) {
        fcn.1800ef5a0(arg1, arg2, arg3, 0);
    } else {
        var_98h = 0;
        stack0xffffffffffffff74 = 0;
        var_84h = 0;
        var_7ch._0_4_ = 0;
        stack0xffffffffffffff88 = 0;
        var_90h._0_4_ = *(int32_t *)(arg1 + 0x138);
        func_0x0001800d62b0(&var_90h, &var_50h);
        piVar7 = &var_50h;
        if (0xf < (uint64_t)var_38h) {
            piVar7 = (int64_t *)var_50h;
        }
        func_0x0001800d4c50(&var_70h, 0x180644020, piVar7, *(int32_t *)(arg1 + 0x13c) + 1);
        piVar7 = &var_70h;
        if (0xf < (uint64_t)var_58h) {
            piVar7 = (int64_t *)CONCAT71(var_70h._1_7_, (undefined)var_70h);
        }
        fcn.1800ef5a0(arg1, arg2 & 0xffffffff, arg3, (int64_t)piVar7);
        puVar6 = auStack_b8;
        if (0xf < (uint64_t)var_58h) {
            iVar2 = CONCAT71(var_70h._1_7_, (undefined)var_70h);
            iVar3 = iVar2;
            puVar6 = auStack_b8;
            if ((0xfff < var_58h + 1U) &&
               (iVar3 = *(int64_t *)(iVar2 + -8), puVar6 = auStack_b8, 0x1f < (iVar2 - iVar3) - 8U)) {
                pcVar1 = (code *)swi(0x29);
                iVar3 = (*pcVar1)(5);
                puVar6 = auStack_b0;
            }
            *(undefined8 *)(puVar6 + -8) = 0x1800ef967;
            func_0x000180459c3c(iVar3);
        }
        var_60h = 0;
        var_58h = 0xf;
        var_70h._0_1_ = 0;
        if (0xf < (uint64_t)var_38h) {
            if (0xfff < var_38h + 1U) {
                iVar3 = *(int64_t *)(var_50h + -8);
                if ((var_50h - iVar3) - 8U < 0x20) {
                    *(undefined8 *)(puVar6 + -8) = 0x1800ef9ab;
                    func_0x000180459c3c(iVar3, var_38h + 0x28);
                    goto code_r0x0001800ef9c9;
                }
                pcVar1 = (code *)swi(0x29);
                var_50h = (*pcVar1)(5);
                puVar6 = puVar6 + 8;
            }
            *(undefined8 *)(puVar6 + -8) = 0x1800ef9bc;
            func_0x000180459c3c(var_50h);
        }
    }
code_r0x0001800ef9c9:
    *(undefined8 *)(puVar6 + -8) = 0x1800ef9d6;
    piVar4 = (int32_t *)fcn.1800d70e0(arg1 + 0x60, &var_50h);
    if (*piVar4 == (int32_t)arg2) {
        *(undefined8 *)(puVar6 + -8) = 0x1800ef9e2;
        fcn.1800f0350(arg1);
        *(undefined8 *)(puVar6 + -8) = 0x1800ef9ea;
        fcn.1800f0350(arg1);
    }
    *(undefined8 *)(puVar6 + -8) = 0x1800ef9fc;
    uVar5 = func_0x000180459870(var_30h ^ (uint64_t)puVar6);
    return uVar5;
}

// ============================================================
// Function: FUN_1800ef870
// Address: 0x1800ef870
// Size: 410 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_ach
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

undefined8 fcn.1800ef810(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t *piVar4;
    undefined8 uVar5;
    undefined *puVar6;
    int64_t *piVar7;
    undefined8 uStack_c0;
    undefined auStack_b8 [8];
    undefined auStack_b0 [24];
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_84h;
    int64_t var_7ch;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_38h;
    int64_t var_30h;
    
    if (*(int32_t *)(arg1 + 0x80) == (int32_t)arg2) {
        if (((*(uint32_t *)(arg1 + 0x84) != *(uint32_t *)(arg3 + 4)) &&
            (*(int32_t *)(arg1 + 0x88) != *(int32_t *)(arg3 + 8))) &&
           (*(uint32_t *)(arg1 + 0x13c) < *(uint32_t *)(arg3 + 4))) {
            *(undefined8 *)(arg1 + 0x138) = *(undefined8 *)arg3;
            *(undefined4 *)(arg1 + 0x140) = *(undefined4 *)(arg3 + 8);
        }
        var_30h = 0x1800ef861;
        fcn.1800f0350();
        return 1;
    }
    puVar6 = auStack_b8;
    var_30h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_b8;
    if ((*(int32_t *)(arg1 + 0x138) == 0) || (*(uint32_t *)(arg1 + 0x13c) <= *(uint32_t *)(arg3 + 4))) {
        fcn.1800ef5a0(arg1, arg2, arg3, 0);
    } else {
        var_98h = 0;
        stack0xffffffffffffff74 = 0;
        var_84h = 0;
        var_7ch._0_4_ = 0;
        stack0xffffffffffffff88 = 0;
        var_90h._0_4_ = *(int32_t *)(arg1 + 0x138);
        func_0x0001800d62b0(&var_90h, &var_50h);
        piVar7 = &var_50h;
        if (0xf < (uint64_t)var_38h) {
            piVar7 = (int64_t *)var_50h;
        }
        func_0x0001800d4c50(&var_70h, 0x180644020, piVar7, *(int32_t *)(arg1 + 0x13c) + 1);
        piVar7 = &var_70h;
        if (0xf < (uint64_t)var_58h) {
            piVar7 = (int64_t *)CONCAT71(var_70h._1_7_, (undefined)var_70h);
        }
        fcn.1800ef5a0(arg1, arg2 & 0xffffffff, arg3, (int64_t)piVar7);
        puVar6 = auStack_b8;
        if (0xf < (uint64_t)var_58h) {
            iVar2 = CONCAT71(var_70h._1_7_, (undefined)var_70h);
            iVar3 = iVar2;
            puVar6 = auStack_b8;
            if ((0xfff < var_58h + 1U) &&
               (iVar3 = *(int64_t *)(iVar2 + -8), puVar6 = auStack_b8, 0x1f < (iVar2 - iVar3) - 8U)) {
                pcVar1 = (code *)swi(0x29);
                iVar3 = (*pcVar1)(5);
                puVar6 = auStack_b0;
            }
            *(undefined8 *)(puVar6 + -8) = 0x1800ef967;
            func_0x000180459c3c(iVar3);
        }
        var_60h = 0;
        var_58h = 0xf;
        var_70h._0_1_ = 0;
        if (0xf < (uint64_t)var_38h) {
            if (0xfff < var_38h + 1U) {
                iVar3 = *(int64_t *)(var_50h + -8);
                if ((var_50h - iVar3) - 8U < 0x20) {
                    *(undefined8 *)(puVar6 + -8) = 0x1800ef9ab;
                    func_0x000180459c3c(iVar3, var_38h + 0x28);
                    goto code_r0x0001800ef9c9;
                }
                pcVar1 = (code *)swi(0x29);
                var_50h = (*pcVar1)(5);
                puVar6 = puVar6 + 8;
            }
            *(undefined8 *)(puVar6 + -8) = 0x1800ef9bc;
            func_0x000180459c3c(var_50h);
        }
    }
code_r0x0001800ef9c9:
    *(undefined8 *)(puVar6 + -8) = 0x1800ef9d6;
    piVar4 = (int32_t *)fcn.1800d70e0(arg1 + 0x60, &var_50h);
    if (*piVar4 == (int32_t)arg2) {
        *(undefined8 *)(puVar6 + -8) = 0x1800ef9e2;
        fcn.1800f0350(arg1);
        *(undefined8 *)(puVar6 + -8) = 0x1800ef9ea;
        fcn.1800f0350(arg1);
    }
    *(undefined8 *)(puVar6 + -8) = 0x1800ef9fc;
    uVar5 = func_0x000180459870(var_30h ^ (uint64_t)puVar6);
    return uVar5;
}

// ============================================================
// Function: FUN_1800efa10
// Address: 0x1800efa10
// Size: 166 bytes
// ============================================================
int64_t fcn.1800efa10(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    
    piVar1 = (int64_t *)(arg3 + 0x10);
    iVar3 = *piVar1;
    uVar2 = iVar3 + 1;
    if (0xf < *(uint64_t *)(arg3 + 0x18)) {
        arg3 = *(int64_t *)arg3;
    }
    *(undefined8 *)arg2 = 0;
    *(undefined8 *)(arg2 + 8) = 0;
    if (uVar2 != 0) {
        uVar4 = func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), uVar2);
        *(uint64_t *)arg2 = uVar4;
        if (uVar2 != 0) {
            if ((uVar2 < 0x10) || ((uVar4 <= (uint64_t)(iVar3 + arg3) && ((uint64_t)arg3 <= iVar3 + uVar4)))) {
                uVar5 = 0;
                do {
                    *(undefined *)(uVar4 + uVar5) = *(undefined *)(arg3 + uVar5);
                    uVar5 = uVar5 + 1;
                } while (uVar5 < uVar2);
            } else {
                func_0x000180498030(uVar4, arg3, uVar2);
            }
        }
    }
    *(int64_t *)(arg2 + 8) = *piVar1;
    return arg2;
}

// ============================================================
// Function: FUN_1800efac0
// Address: 0x1800efac0
// Size: 938 bytes
// ============================================================
void fcn.1800efac0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined auVar8 [16];
    undefined4 *puVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined8 uVar13;
    undefined8 *puVar14;
    undefined8 *puVar15;
    undefined *puVar16;
    undefined *puVar17;
    undefined *puVar18;
    undefined8 *puVar19;
    uint64_t uVar20;
    undefined8 *puVar21;
    uint64_t uVar22;
    undefined8 uStack_130;
    undefined auStack_128 [8];
    undefined auStack_120 [24];
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_d0h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_58h;
    
    puVar16 = auStack_128;
    puVar17 = auStack_128;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_128;
    puVar19 = (undefined8 *)0x0;
    var_108h._0_4_ = 0;
    piVar1 = (int64_t *)(arg1 + 0x1d0);
    iVar12 = *(int64_t *)(arg1 + 0x1d8);
    var_100h = arg1;
    if ((((*piVar1 == iVar12) || (*(int32_t *)(arg2 + 4) != *(int32_t *)(iVar12 + -0x2c))) ||
        (*(int32_t *)arg2 != *(int32_t *)(iVar12 + -0x30))) ||
       ((*(int32_t *)(arg2 + 0xc) != *(int32_t *)(iVar12 + -0x24) ||
        (puVar18 = auStack_128, *(int32_t *)(arg2 + 8) != *(int32_t *)(iVar12 + -0x28))))) {
        var_c0h = 0;
        var_b8h = 0xf;
        stack0xffffffffffffff31 = SUB1615(ZEXT816(0), 1);
        auVar8[15] = 0;
        auVar8._0_15_ = stack0xffffffffffffff31;
        _var_d0h = auVar8 << 8;
        var_108h._0_4_ = 1;
        func_0x0001800d4b20(&var_d0h, arg3, arg4);
        if (*(uint32_t *)0x180778480 == 1) {
            uVar13 = func_0x00018000b4d0(&var_f8h, &var_d0h);
            func_0x0001800d98e0(&var_a8h, arg2, uVar13);
            func_0x00018045bae0(&var_a8h, 0x180698fa8);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        puVar3 = *(undefined8 **)(arg1 + 0x1d8);
        if (puVar3 == *(undefined8 **)(arg1 + 0x1e0)) {
            iVar12 = (int64_t)puVar3 - *piVar1;
            iVar12 = iVar12 / 0x12 + (iVar12 >> 0x3f);
            iVar12 = (iVar12 >> 2) - (iVar12 >> 0x3f);
            if (iVar12 == 0x38e38e38e38e38e) {
                func_0x000180010010();
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            uVar20 = ((int64_t)*(undefined8 **)(arg1 + 0x1e0) - *piVar1 >> 3) * -0x71c71c71c71c71c7;
            uVar10 = 0x38e38e38e38e38e - (uVar20 >> 1);
            if (uVar10 <= uVar20 && uVar20 - uVar10 != 0) {
code_r0x0001800efe30:
                func_0x000180004720();
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            uVar10 = iVar12 + 1;
            uVar20 = (uVar20 >> 1) + uVar20;
            uVar22 = uVar10;
            if (uVar10 <= uVar20) {
                uVar22 = uVar20;
            }
            if (0x38e38e38e38e38e < uVar22) goto code_r0x0001800efe30;
            uVar20 = uVar22 * 0x48;
            puVar17 = auStack_128;
            if (uVar20 != 0) {
                if (uVar20 < 0x1000) {
                    puVar19 = (undefined8 *)func_0x000180459890();
                    puVar17 = auStack_128;
                } else {
                    if (uVar20 + 0x27 <= uVar20) goto code_r0x0001800efe30;
                    iVar11 = func_0x000180459890(uVar20 + 0x27);
                    if (iVar11 == 0) {
                        pcVar4 = (code *)swi(0x29);
                        iVar11 = (*pcVar4)(5);
                        puVar16 = auStack_120;
                    }
                    puVar19 = (undefined8 *)(iVar11 + 0x27U & 0xffffffffffffffe0);
                    puVar19[-1] = iVar11;
                    puVar17 = puVar16;
                }
            }
            puVar2 = puVar19 + iVar12 * 9;
            var_90h = (int64_t)(puVar2 + 9);
            *(undefined8 *)(puVar17 + -8) = 0x1800efcee;
            var_a8h = (int64_t)piVar1;
            var_a0h = (int64_t)puVar19;
            var_98h = uVar22;
            var_88h = var_90h;
            puVar9 = (undefined4 *)func_0x00018000b4d0(puVar17 + 0x30, &var_d0h);
            *(undefined (*) [16])(puVar2 + 1) = ZEXT816(0);
            *puVar2 = 0x180640168;
            uVar5 = *(undefined4 *)(arg2 + 4);
            uVar6 = *(undefined4 *)(arg2 + 8);
            uVar7 = *(undefined4 *)(arg2 + 0xc);
            *(undefined4 *)(puVar2 + 3) = *(undefined4 *)arg2;
            *(undefined4 *)((int64_t)puVar2 + 0x1c) = uVar5;
            *(undefined4 *)(puVar2 + 4) = uVar6;
            *(undefined4 *)((int64_t)puVar2 + 0x24) = uVar7;
            *(undefined (*) [16])(puVar2 + 5) = ZEXT816(0);
            puVar2[7] = 0;
            puVar2[8] = 0;
            uVar5 = puVar9[1];
            uVar6 = puVar9[2];
            uVar7 = puVar9[3];
            *(undefined4 *)(puVar2 + 5) = *puVar9;
            *(undefined4 *)((int64_t)puVar2 + 0x2c) = uVar5;
            *(undefined4 *)(puVar2 + 6) = uVar6;
            *(undefined4 *)((int64_t)puVar2 + 0x34) = uVar7;
            uVar5 = puVar9[5];
            uVar6 = puVar9[6];
            uVar7 = puVar9[7];
            *(undefined4 *)(puVar2 + 7) = puVar9[4];
            *(undefined4 *)((int64_t)puVar2 + 0x3c) = uVar5;
            *(undefined4 *)(puVar2 + 8) = uVar6;
            *(undefined4 *)((int64_t)puVar2 + 0x44) = uVar7;
            *(undefined8 *)(puVar9 + 6) = 0xf;
            *(undefined8 *)(puVar9 + 4) = 0;
            *(undefined8 *)(puVar9 + 6) = 0xf;
            *(undefined *)puVar9 = 0;
            puVar15 = *(undefined8 **)(arg1 + 0x1d8);
            puVar14 = (undefined8 *)*piVar1;
            puVar21 = puVar19;
            var_90h = (int64_t)puVar2;
            if (puVar3 != puVar15) {
                *(undefined8 *)(puVar17 + -8) = 0x1800efd59;
                func_0x0001800f3480(puVar14, puVar3, puVar19);
                puVar21 = puVar2 + 9;
                puVar15 = *(undefined8 **)(arg1 + 0x1d8);
                puVar14 = puVar3;
                var_90h = (int64_t)puVar19;
            }
            *(undefined8 *)(puVar17 + -8) = 0x1800efd6d;
            func_0x0001800f3480(puVar14, puVar15, puVar21);
            var_a0h = 0;
            *(undefined8 *)(puVar17 + -8) = 0x1800efd86;
            func_0x0001800f38a0(piVar1, puVar19, uVar10, uVar22);
            *(undefined8 *)(puVar17 + -8) = 0x1800efd90;
            func_0x0001800f37f0(&var_a8h);
            iVar12 = *(int64_t *)(puVar17 + 0x28);
        } else {
            puVar9 = (undefined4 *)func_0x00018000b4d0(&var_f8h, &var_d0h);
            *(undefined (*) [16])(puVar3 + 1) = ZEXT816(0);
            *puVar3 = 0x180640168;
            uVar5 = *(undefined4 *)(arg2 + 4);
            uVar6 = *(undefined4 *)(arg2 + 8);
            uVar7 = *(undefined4 *)(arg2 + 0xc);
            *(undefined4 *)(puVar3 + 3) = *(undefined4 *)arg2;
            *(undefined4 *)((int64_t)puVar3 + 0x1c) = uVar5;
            *(undefined4 *)(puVar3 + 4) = uVar6;
            *(undefined4 *)((int64_t)puVar3 + 0x24) = uVar7;
            *(undefined (*) [16])(puVar3 + 5) = ZEXT816(0);
            puVar3[7] = 0;
            puVar3[8] = 0;
            uVar5 = puVar9[1];
            uVar6 = puVar9[2];
            uVar7 = puVar9[3];
            *(undefined4 *)(puVar3 + 5) = *puVar9;
            *(undefined4 *)((int64_t)puVar3 + 0x2c) = uVar5;
            *(undefined4 *)(puVar3 + 6) = uVar6;
            *(undefined4 *)((int64_t)puVar3 + 0x34) = uVar7;
            uVar5 = puVar9[5];
            uVar6 = puVar9[6];
            uVar7 = puVar9[7];
            *(undefined4 *)(puVar3 + 7) = puVar9[4];
            *(undefined4 *)((int64_t)puVar3 + 0x3c) = uVar5;
            *(undefined4 *)(puVar3 + 8) = uVar6;
            *(undefined4 *)((int64_t)puVar3 + 0x44) = uVar7;
            *(undefined8 *)(puVar9 + 6) = 0xf;
            *(undefined *)puVar9 = 0;
            *(undefined8 *)(puVar9 + 4) = 0;
            *(undefined8 *)(puVar9 + 6) = 0xf;
            *(undefined *)puVar9 = 0;
            *(int64_t *)(arg1 + 0x1d8) = *(int64_t *)(arg1 + 0x1d8) + 0x48;
            iVar12 = arg1;
        }
        if (((uint64_t)*(uint32_t *)0x180778480 <=
             (uint64_t)((*(int64_t *)(arg1 + 0x1d8) - *piVar1 >> 3) * -0x71c71c71c71c71c7)) &&
           (*(char *)(iVar12 + 0x59) == '\0')) {
            *(undefined8 *)(puVar17 + -8) = 0x1800efe2f;
            func_0x0001800d9940(arg2, 0x1806440a0);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        puVar18 = puVar17;
        if (0xf < (uint64_t)var_b8h) {
            iVar12 = var_d0h;
            if ((0xfff < var_b8h + 1U) && (iVar12 = *(int64_t *)(var_d0h + -8), 0x1f < (var_d0h - iVar12) - 8U)) {
                pcVar4 = (code *)swi(0x29);
                iVar12 = (*pcVar4)(5);
                puVar17 = puVar17 + 8;
            }
            *(undefined8 *)(puVar17 + -8) = 0x1800efe00;
            func_0x000180459c3c(iVar12);
            puVar18 = puVar17;
        }
    }
    *(undefined8 *)(puVar18 + -8) = 0x1800efe0c;
    func_0x000180459870(var_58h ^ (uint64_t)puVar18);
    return;
}

// ============================================================
// Function: FUN_1800efe70
// Address: 0x1800efe70
// Size: 29 bytes
// ============================================================
void fcn.1800efe70(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t var_18h;
    int64_t var_20h;
    
    var_20h = arg4;
    fcn.1800efac0(arg1, arg2, arg3, (int64_t)&var_20h);
    return;
}

// ============================================================
// Function: FUN_1800efe90
// Address: 0x1800efe90
// Size: 229 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800efe90(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    code *pcVar1;
    undefined8 *arg4;
    int64_t iVar2;
    undefined *puVar3;
    int64_t var_18h;
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_20h;
    uint64_t uStack_18;
    
    puVar3 = auStack_68;
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    if (arg2 == 0) {
        arg4 = (undefined8 *)func_0x0001800d62b0(arg1 + 0x80, &var_38h);
        if (0xf < (uint64_t)arg4[3]) {
            arg4 = (undefined8 *)*arg4;
        }
        fcn.1800efe70(arg1, arg1 + 0x84, 0x180644180, (int64_t)arg4);
    } else {
        var_48h = func_0x0001800d62b0(arg1 + 0x80, &var_38h);
        if (0xf < *(uint64_t *)(var_48h + 0x18)) {
            var_48h = *(int64_t *)var_48h;
        }
        fcn.1800efe70(arg1, arg1 + 0x84, 0x180644150, arg2);
    }
    if (0xf < (uint64_t)var_20h) {
        iVar2 = var_38h;
        puVar3 = auStack_68;
        if ((0xfff < var_20h + 1U) &&
           (iVar2 = *(int64_t *)(var_38h + -8), puVar3 = auStack_68, 0x1f < (var_38h - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            puVar3 = auStack_60;
        }
        *(undefined8 *)(puVar3 + -8) = 0x1800eff5a;
        func_0x000180459c3c(iVar2);
    }
    *(undefined8 *)(puVar3 + -8) = 0x1800eff67;
    func_0x000180459870(*(uint64_t *)(puVar3 + 0x50) ^ (uint64_t)puVar3);
    return;
}

// ============================================================
// Function: FUN_1800eff80
// Address: 0x1800eff80
// Size: 248 bytes
// ============================================================
int64_t * fcn.1800eff80(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t **ppiVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t in_stack_00000028;
    
    fcn.1800efac0(arg1, arg2, in_stack_00000028, (int64_t)&stack0x00000030);
    iVar1 = *(int64_t *)(arg1 + 0x1d8);
    iVar2 = *(int64_t *)(arg1 + 0x1d0);
    ppiVar3 = *(int64_t ***)(arg1 + 0xd8);
    iVar4 = (int64_t)*ppiVar3;
    if (iVar4 != 0) {
        piVar10 = (int64_t *)((int64_t)ppiVar3[1] + iVar4 + 0xf & 0xfffffffffffffff8);
        if (piVar10 + 10 <= (int64_t *)(iVar4 + 0x2008)) {
            piVar9 = (int64_t *)((int64_t)piVar10 + (0x50 - (iVar4 + 8)));
            goto code_r0x0001800f0028;
        }
    }
    piVar9 = (int64_t *)func_0x000180459890(0x2008);
    *piVar9 = (int64_t)*ppiVar3;
    piVar10 = piVar9 + 1;
    *ppiVar3 = piVar9;
    piVar9 = (int64_t *)0x50;
code_r0x0001800f0028:
    ppiVar3[1] = piVar9;
    *(undefined4 *)(piVar10 + 1) = *(undefined4 *)0x180782720;
    *piVar10 = 0x180642298;
    uVar5 = *(undefined4 *)arg2;
    uVar6 = *(undefined4 *)(arg2 + 4);
    uVar7 = *(undefined4 *)(arg2 + 8);
    uVar8 = *(undefined4 *)(arg2 + 0xc);
    *piVar10 = 0x180641b08;
    *(undefined *)(piVar10 + 4) = 0;
    *(undefined4 *)((int64_t)piVar10 + 0xc) = uVar5;
    *(undefined4 *)(piVar10 + 2) = uVar6;
    *(undefined4 *)((int64_t)piVar10 + 0x14) = uVar7;
    *(undefined4 *)(piVar10 + 3) = uVar8;
    uVar5 = *(undefined4 *)(arg3 + 4);
    uVar6 = *(undefined4 *)(arg3 + 8);
    uVar7 = *(undefined4 *)(arg3 + 0xc);
    *(undefined4 *)(piVar10 + 5) = *(undefined4 *)arg3;
    *(undefined4 *)((int64_t)piVar10 + 0x2c) = uVar5;
    *(undefined4 *)(piVar10 + 6) = uVar6;
    *(undefined4 *)((int64_t)piVar10 + 0x34) = uVar7;
    uVar5 = *(undefined4 *)arg4;
    uVar6 = *(undefined4 *)(arg4 + 4);
    uVar7 = *(undefined4 *)(arg4 + 8);
    uVar8 = *(undefined4 *)(arg4 + 0xc);
    *(int32_t *)(piVar10 + 9) = (int32_t)(iVar1 - iVar2 >> 3) * 0x38e38e39 + -1;
    *(undefined4 *)(piVar10 + 7) = uVar5;
    *(undefined4 *)((int64_t)piVar10 + 0x3c) = uVar6;
    *(undefined4 *)(piVar10 + 8) = uVar7;
    *(undefined4 *)((int64_t)piVar10 + 0x44) = uVar8;
    return piVar10;
}

// ============================================================
// Function: FUN_1800f0080
// Address: 0x1800f0080
// Size: 234 bytes
// ============================================================
int64_t * fcn.1800f0080(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t **ppiVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t var_20h;
    
    fcn.1800efac0(arg1, arg2, arg4, (int64_t)&arg_28h);
    iVar1 = *(int64_t *)(arg1 + 0x1d8);
    iVar2 = *(int64_t *)(arg1 + 0x1d0);
    ppiVar3 = *(int64_t ***)(arg1 + 0xd8);
    iVar4 = (int64_t)*ppiVar3;
    if (iVar4 != 0) {
        piVar10 = (int64_t *)((int64_t)ppiVar3[1] + iVar4 + 0xf & 0xfffffffffffffff8);
        if (piVar10 + 7 <= (int64_t *)(iVar4 + 0x2008)) {
            piVar9 = (int64_t *)((int64_t)piVar10 + (0x38 - (iVar4 + 8)));
            goto code_r0x0001800f0128;
        }
    }
    piVar9 = (int64_t *)func_0x000180459890(0x2008);
    *piVar9 = (int64_t)*ppiVar3;
    piVar10 = piVar9 + 1;
    *ppiVar3 = piVar9;
    piVar9 = (int64_t *)0x38;
code_r0x0001800f0128:
    ppiVar3[1] = piVar9;
    uVar5 = *(undefined4 *)0x1807826f0;
    *piVar10 = 0x180642298;
    *(undefined4 *)(piVar10 + 1) = uVar5;
    uVar5 = *(undefined4 *)arg2;
    uVar6 = *(undefined4 *)(arg2 + 4);
    uVar7 = *(undefined4 *)(arg2 + 8);
    uVar8 = *(undefined4 *)(arg2 + 0xc);
    *piVar10 = 0x180641ae0;
    *(undefined4 *)((int64_t)piVar10 + 0xc) = uVar5;
    *(undefined4 *)(piVar10 + 2) = uVar6;
    *(undefined4 *)((int64_t)piVar10 + 0x14) = uVar7;
    *(undefined4 *)(piVar10 + 3) = uVar8;
    uVar5 = *(undefined4 *)arg3;
    uVar6 = *(undefined4 *)(arg3 + 4);
    uVar7 = *(undefined4 *)(arg3 + 8);
    uVar8 = *(undefined4 *)(arg3 + 0xc);
    *(int32_t *)(piVar10 + 6) = (int32_t)(iVar1 - iVar2 >> 3) * 0x38e38e39 + -1;
    *(undefined4 *)(piVar10 + 4) = uVar5;
    *(undefined4 *)((int64_t)piVar10 + 0x24) = uVar6;
    *(undefined4 *)(piVar10 + 5) = uVar7;
    *(undefined4 *)((int64_t)piVar10 + 0x2c) = uVar8;
    return piVar10;
}

// ============================================================
// Function: FUN_1800f0170
// Address: 0x1800f0170
// Size: 238 bytes
// ============================================================
int64_t * fcn.1800f0170(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t **ppiVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t var_20h;
    
    fcn.1800efac0(arg1, arg2, arg4, (int64_t)&arg_28h);
    iVar1 = *(int64_t *)(arg1 + 0x1d8);
    iVar2 = *(int64_t *)(arg1 + 0x1d0);
    ppiVar3 = *(int64_t ***)(arg1 + 0xd8);
    iVar4 = (int64_t)*ppiVar3;
    if (iVar4 != 0) {
        piVar10 = (int64_t *)((int64_t)ppiVar3[1] + iVar4 + 0xf & 0xfffffffffffffff8);
        if (piVar10 + 7 <= (int64_t *)(iVar4 + 0x2008)) {
            piVar9 = (int64_t *)((int64_t)piVar10 + (0x38 - (iVar4 + 8)));
            goto code_r0x0001800f0218;
        }
    }
    piVar9 = (int64_t *)func_0x000180459890(0x2008);
    *piVar9 = (int64_t)*ppiVar3;
    piVar10 = piVar9 + 1;
    *ppiVar3 = piVar9;
    piVar9 = (int64_t *)0x38;
code_r0x0001800f0218:
    ppiVar3[1] = piVar9;
    uVar5 = *(undefined4 *)0x180782678;
    *piVar10 = 0x180642298;
    *(undefined4 *)(piVar10 + 1) = uVar5;
    uVar5 = *(undefined4 *)arg2;
    uVar6 = *(undefined4 *)(arg2 + 4);
    uVar7 = *(undefined4 *)(arg2 + 8);
    uVar8 = *(undefined4 *)(arg2 + 0xc);
    *piVar10 = 0x180641de8;
    *(undefined4 *)((int64_t)piVar10 + 0xc) = uVar5;
    *(undefined4 *)(piVar10 + 2) = uVar6;
    *(undefined4 *)((int64_t)piVar10 + 0x14) = uVar7;
    *(undefined4 *)(piVar10 + 3) = uVar8;
    uVar5 = *(undefined4 *)arg3;
    uVar6 = *(undefined4 *)(arg3 + 4);
    uVar7 = *(undefined4 *)(arg3 + 8);
    uVar8 = *(undefined4 *)(arg3 + 0xc);
    *(undefined *)(piVar10 + 6) = 0;
    *(int32_t *)((int64_t)piVar10 + 0x34) = (int32_t)(iVar1 - iVar2 >> 3) * 0x38e38e39 + -1;
    *(undefined4 *)(piVar10 + 4) = uVar5;
    *(undefined4 *)((int64_t)piVar10 + 0x24) = uVar6;
    *(undefined4 *)(piVar10 + 5) = uVar7;
    *(undefined4 *)((int64_t)piVar10 + 0x2c) = uVar8;
    return piVar10;
}

// ============================================================
// Function: FUN_1800f0260
// Address: 0x1800f0260
// Size: 231 bytes
// ============================================================
int64_t * fcn.1800f0260(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t **ppiVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t var_20h;
    
    fcn.1800efac0(arg1, arg2, arg4, (int64_t)&arg_28h);
    iVar1 = *(int64_t *)(arg1 + 0x1d8);
    iVar2 = *(int64_t *)(arg1 + 0x1d0);
    ppiVar3 = *(int64_t ***)(arg1 + 0xd8);
    iVar4 = (int64_t)*ppiVar3;
    if (iVar4 != 0) {
        piVar10 = (int64_t *)((int64_t)ppiVar3[1] + iVar4 + 0xf & 0xfffffffffffffff8);
        if (piVar10 + 7 <= (int64_t *)(iVar4 + 0x2008)) {
            piVar9 = (int64_t *)((int64_t)piVar10 + (0x38 - (iVar4 + 8)));
            goto code_r0x0001800f0302;
        }
    }
    piVar9 = (int64_t *)func_0x000180459890(0x2008);
    *piVar9 = (int64_t)*ppiVar3;
    piVar10 = piVar9 + 1;
    *ppiVar3 = piVar9;
    piVar9 = (int64_t *)0x38;
code_r0x0001800f0302:
    ppiVar3[1] = piVar9;
    uVar5 = *(undefined4 *)0x180782678;
    *piVar10 = 0x180642298;
    *(undefined4 *)(piVar10 + 1) = uVar5;
    uVar5 = *(undefined4 *)arg3;
    uVar6 = *(undefined4 *)(arg3 + 4);
    uVar7 = *(undefined4 *)(arg3 + 8);
    uVar8 = *(undefined4 *)(arg3 + 0xc);
    *piVar10 = 0x180641de8;
    piVar10[4] = 0;
    piVar10[5] = 0;
    *(undefined4 *)((int64_t)piVar10 + 0xc) = uVar5;
    *(undefined4 *)(piVar10 + 2) = uVar6;
    *(undefined4 *)((int64_t)piVar10 + 0x14) = uVar7;
    *(undefined4 *)(piVar10 + 3) = uVar8;
    *(undefined *)(piVar10 + 6) = 1;
    *(int32_t *)((int64_t)piVar10 + 0x34) = (int32_t)(iVar1 - iVar2 >> 3) * 0x38e38e39 + -1;
    return piVar10;
}

// ============================================================
// Function: FUN_1800f0350
// Address: 0x1800f0350
// Size: 1679 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

void fcn.1800f0350(int64_t arg1)
{
    uint32_t uVar1;
    int64_t *piVar2;
    char *pcVar3;
    uint8_t uVar4;
    undefined4 uVar5;
    undefined4 *puVar6;
    char *pcVar7;
    undefined *puVar8;
    code *pcVar9;
    undefined auVar10 [16];
    undefined auVar11 [16];
    int64_t iVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined auVar17 [16];
    undefined4 *puVar18;
    int64_t iVar19;
    uint64_t uVar20;
    int64_t iVar21;
    undefined4 *puVar22;
    undefined *puVar23;
    uint32_t uVar24;
    undefined *puVar25;
    undefined *puVar26;
    undefined *puVar27;
    int64_t iVar28;
    undefined4 *puVar29;
    int64_t iVar30;
    uint64_t uVar31;
    undefined *puVar32;
    uint64_t uVar33;
    int64_t var_1h;
    int64_t var_14h;
    undefined8 uStack_d0;
    undefined auStack_c8 [8];
    undefined auStack_c0 [24];
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    undefined4 uStack_90;
    undefined4 uStack_8c;
    undefined4 uStack_88;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_8h;
    
    var_60h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_c8;
    piVar2 = (int64_t *)(arg1 + 0x60);
    while( true ) {
        uVar31 = (uint64_t)*(uint32_t *)(arg1 + 0x70);
        if (*(uint64_t *)(arg1 + 0x68) <= uVar31) break;
        uVar4 = *(uint8_t *)(uVar31 + *piVar2);
        if ((uVar4 < 0x21) && ((0x100002600U >> ((int64_t)(char)uVar4 & 0x3fU) & 1) != 0)) {
code_r0x0001800f03b8:
            if (*(char *)(uVar31 + *piVar2) == '\n') {
                *(int32_t *)(arg1 + 0x74) = *(int32_t *)(arg1 + 0x74) + 1;
                *(uint32_t *)(arg1 + 0x78) = *(uint32_t *)(arg1 + 0x70) + 1;
            }
        } else if (uVar4 != 0xb) {
            if (uVar4 == 0xc) goto code_r0x0001800f03b8;
            break;
        }
        *(int32_t *)(arg1 + 0x70) = *(int32_t *)(arg1 + 0x70) + 1;
    }
    *(undefined4 *)(arg1 + 0xa0) = *(undefined4 *)(arg1 + 0x84);
    *(undefined4 *)(arg1 + 0xa4) = *(undefined4 *)(arg1 + 0x88);
    *(undefined4 *)(arg1 + 0xa8) = *(undefined4 *)(arg1 + 0x8c);
    *(undefined4 *)(arg1 + 0xac) = *(undefined4 *)(arg1 + 0x90);
    var_a0h = arg1;
    puVar18 = (undefined4 *)func_0x0001800d7a00(piVar2, &var_98h);
    iVar28 = arg1;
    while( true ) {
        uVar5 = puVar18[1];
        uVar13 = puVar18[2];
        uVar14 = puVar18[3];
        *(undefined4 *)(arg1 + 0x80) = *puVar18;
        *(undefined4 *)(arg1 + 0x84) = uVar5;
        *(undefined4 *)(arg1 + 0x88) = uVar13;
        *(undefined4 *)(arg1 + 0x8c) = uVar14;
        uVar5 = puVar18[5];
        uVar13 = puVar18[6];
        uVar14 = puVar18[7];
        *(undefined4 *)(arg1 + 0x90) = puVar18[4];
        *(undefined4 *)(arg1 + 0x94) = uVar5;
        *(undefined4 *)(arg1 + 0x98) = uVar13;
        *(undefined4 *)(arg1 + 0x9c) = uVar14;
        puVar26 = auStack_c8;
        if (((*(int32_t *)(arg1 + 0x80) - 0x11aU & 0xfffffffa) != 0) ||
           (puVar26 = auStack_c8, *(int32_t *)(arg1 + 0x80) == 0x11e)) goto code_r0x0001800f09a1;
        if (*(char *)(iVar28 + 1) != '\0') break;
code_r0x0001800f0648:
        puVar26 = auStack_c8;
        if (*(int32_t *)(iVar28 + 0x80) == 0x11f) goto code_r0x0001800f09a1;
        if (((*(int32_t *)(iVar28 + 0x80) == 0x11a) && (uVar24 = *(uint32_t *)(iVar28 + 0x94), uVar24 != 0)) &&
           (pcVar7 = *(char **)(iVar28 + 0x98), *pcVar7 == '!')) {
            do {
                uVar1 = uVar24 - 1;
                if ((pcVar7[uVar1] != ' ') && (4 < (uint8_t)(pcVar7[uVar1] - 9U))) break;
                uVar24 = uVar1;
            } while (uVar1 != 0);
            var_a8h._0_1_ = *(undefined *)(iVar28 + 0x110);
            var_98h._4_4_ = *(undefined4 *)(iVar28 + 0x84);
            uStack_90 = *(undefined4 *)(iVar28 + 0x88);
            uStack_8c = *(undefined4 *)(iVar28 + 0x8c);
            uStack_88 = *(undefined4 *)(iVar28 + 0x90);
            pcVar3 = pcVar7 + 1;
            _var_80h = ZEXT816(0);
            var_70h = 0;
            var_68h = 0;
            var_98h._0_1_ = (undefined)var_a8h;
            if (pcVar3 == pcVar7 + uVar24) {
                var_70h = 0;
                var_68h = 0xf;
                auVar17[15] = 0;
                auVar17._0_15_ = stack0xffffffffffffff81;
                _var_80h = auVar17 << 8;
            } else {
                func_0x000180004830(&var_80h, pcVar3, (int64_t)(pcVar7 + uVar24) - (int64_t)pcVar3);
            }
            iVar19 = var_68h;
            iVar30 = var_70h;
            uVar15 = uStack_88;
            uVar14 = uStack_8c;
            uVar13 = uStack_90;
            uVar5 = var_98h._4_4_;
            puVar8 = *(undefined **)(iVar28 + 0x100);
            var_a8h._0_1_ = (undefined)var_98h;
            if (puVar8 == *(undefined **)(iVar28 + 0x108)) {
                iVar12 = ((int64_t)puVar8 - *(int64_t *)(iVar28 + 0xf8)) / 0x38;
                if (iVar12 == 0x492492492492492) {
                    func_0x000180010010();
code_r0x0001800f09cd:
                    func_0x000180004720();
                    pcVar9 = (code *)swi(3);
                    (*pcVar9)();
                    return;
                }
                uVar31 = ((int64_t)*(undefined **)(iVar28 + 0x108) - *(int64_t *)(iVar28 + 0xf8) >> 3) *
                         0x6db6db6db6db6db7;
                uVar20 = 0x492492492492492 - (uVar31 >> 1);
                if (uVar20 <= uVar31 && uVar31 - uVar20 != 0) {
code_r0x0001800f09d9:
                    func_0x000180004720();
                    pcVar9 = (code *)swi(3);
                    (*pcVar9)();
                    return;
                }
                uVar31 = (uVar31 >> 1) + uVar31;
                uVar20 = iVar12 + 1U;
                if (iVar12 + 1U <= uVar31) {
                    uVar20 = uVar31;
                }
                if (0x492492492492492 < uVar20) goto code_r0x0001800f09d9;
                uVar20 = uVar20 * 0x38;
                if (uVar20 == 0) {
                    puVar27 = (undefined *)0x0;
                } else if (uVar20 < 0x1000) {
                    puVar27 = (undefined *)func_0x000180459890(uVar20);
                } else {
                    if (uVar20 + 0x27 <= uVar20) goto code_r0x0001800f09d9;
                    iVar21 = func_0x000180459890();
                    puVar26 = auStack_c8;
                    if (iVar21 == 0) goto code_r0x0001800f099a;
                    puVar27 = (undefined *)(iVar21 + 0x27U & 0xffffffffffffffe0);
                    *(int64_t *)(puVar27 + -8) = iVar21;
                }
                puVar32 = puVar27 + iVar12 * 0x38;
                *puVar32 = (undefined)var_a8h;
                auVar11._4_4_ = uVar13;
                auVar11._0_4_ = uVar5;
                auVar11._8_4_ = uVar14;
                auVar11._12_4_ = uVar15;
                *(undefined (*) [16])(puVar32 + 4) = auVar11;
                *(int64_t *)(puVar32 + 0x18) = var_80h;
                *(int64_t *)(puVar32 + 0x20) = var_78h;
                *(int64_t *)(puVar32 + 0x28) = iVar30;
                *(int64_t *)(puVar32 + 0x30) = iVar19;
                puVar25 = *(undefined **)(iVar28 + 0x100);
                puVar23 = *(undefined **)(iVar28 + 0xf8);
                puVar26 = puVar27;
                if (puVar8 != puVar25) {
                    func_0x0001800f3540(*(undefined **)(iVar28 + 0xf8), puVar8, puVar27);
                    puVar26 = puVar32 + 0x38;
                    puVar25 = *(undefined **)(iVar28 + 0x100);
                    puVar23 = puVar8;
                }
                func_0x0001800f3540(puVar23, puVar25, puVar26);
                iVar30 = *(int64_t *)(iVar28 + 0xf8);
                if (iVar30 != 0) {
                    iVar19 = *(int64_t *)(iVar28 + 0x100);
                    for (; iVar30 != iVar19; iVar30 = iVar30 + 0x38) {
                        func_0x000180004e40(iVar30 + 0x18);
                    }
                    iVar30 = *(int64_t *)(iVar28 + 0xf8);
                    uVar31 = (*(int64_t *)(iVar28 + 0x108) - iVar30 >> 3) * 8;
                    if (0xfff < uVar31) {
                        puVar26 = auStack_c8;
                        if (0x1f < (iVar30 - *(int64_t *)(iVar30 + -8)) - 8U) goto code_r0x0001800f099a;
                        uVar31 = uVar31 + 0x27;
                        iVar30 = *(int64_t *)(iVar30 + -8);
                    }
                    func_0x000180459c3c(iVar30, uVar31);
                }
                *(undefined **)(iVar28 + 0xf8) = puVar27;
                *(undefined **)(iVar28 + 0x100) = puVar27 + (iVar12 + 1) * 0x38;
                *(undefined **)(iVar28 + 0x108) = puVar27 + uVar20;
            } else {
                *puVar8 = (undefined)var_98h;
                auVar10._4_4_ = uStack_90;
                auVar10._0_4_ = var_98h._4_4_;
                auVar10._8_4_ = uStack_8c;
                auVar10._12_4_ = uStack_88;
                *(undefined (*) [16])(puVar8 + 4) = auVar10;
                *(int64_t *)(puVar8 + 0x18) = var_80h;
                *(int64_t *)(puVar8 + 0x20) = var_78h;
                *(int64_t *)(puVar8 + 0x28) = var_70h;
                *(int64_t *)(puVar8 + 0x30) = var_68h;
                *(int64_t *)(iVar28 + 0x100) = *(int64_t *)(iVar28 + 0x100) + 0x38;
            }
        }
        while( true ) {
            uVar31 = (uint64_t)*(uint32_t *)(arg1 + 0x70);
            if (*(uint64_t *)(arg1 + 0x68) <= uVar31) break;
            uVar4 = *(uint8_t *)(uVar31 + *piVar2);
            if ((uVar4 < 0x21) && ((0x100002600U >> ((int64_t)(char)uVar4 & 0x3fU) & 1) != 0)) {
code_r0x0001800f0966:
                if (*(char *)(uVar31 + *piVar2) == '\n') {
                    *(int32_t *)(arg1 + 0x74) = *(int32_t *)(arg1 + 0x74) + 1;
                    *(uint32_t *)(arg1 + 0x78) = *(uint32_t *)(arg1 + 0x70) + 1;
                }
            } else if (uVar4 != 0xb) {
                if (uVar4 == 0xc) goto code_r0x0001800f0966;
                break;
            }
            *(int32_t *)(arg1 + 0x70) = *(int32_t *)(arg1 + 0x70) + 1;
        }
        puVar18 = (undefined4 *)func_0x0001800d7a00(piVar2, &var_98h);
        iVar28 = var_a0h;
    }
    uVar5 = *(undefined4 *)(iVar28 + 0x80);
    uVar13 = *(undefined4 *)(iVar28 + 0x84);
    uVar14 = *(undefined4 *)(iVar28 + 0x88);
    uVar15 = *(undefined4 *)(iVar28 + 0x8c);
    uVar16 = *(undefined4 *)(iVar28 + 0x90);
    puVar18 = *(undefined4 **)(iVar28 + 0xe8);
    if (puVar18 != *(undefined4 **)(iVar28 + 0xf0)) {
        *puVar18 = uVar5;
        puVar18[1] = uVar13;
        puVar18[2] = uVar14;
        puVar18[3] = uVar15;
        puVar18[4] = uVar16;
        *(int64_t *)(iVar28 + 0xe8) = *(int64_t *)(iVar28 + 0xe8) + 0x14;
        goto code_r0x0001800f0648;
    }
    iVar30 = ((int64_t)puVar18 - *(int64_t *)(iVar28 + 0xe0)) / 0x14;
    if (iVar30 == 0xccccccccccccccc) {
        func_0x000180010010();
        goto code_r0x0001800f09d9;
    }
    uVar31 = ((int64_t)*(undefined4 **)(iVar28 + 0xf0) - *(int64_t *)(iVar28 + 0xe0) >> 2) * -0x3333333333333333;
    uVar20 = 0xccccccccccccccc - (uVar31 >> 1);
    if (uVar20 <= uVar31 && uVar31 - uVar20 != 0) goto code_r0x0001800f09cd;
    uVar20 = iVar30 + 1;
    uVar31 = (uVar31 >> 1) + uVar31;
    uVar33 = uVar20;
    if (uVar20 <= uVar31) {
        uVar33 = uVar31;
    }
    if (0xccccccccccccccc < uVar33) goto code_r0x0001800f09cd;
    uVar31 = uVar33 * 0x14;
    if (uVar31 == 0) {
        puVar29 = (undefined4 *)0x0;
code_r0x0001800f0548:
        puVar22 = puVar29 + iVar30 * 5;
        *puVar22 = uVar5;
        puVar22[1] = uVar13;
        puVar22[2] = uVar14;
        puVar22[3] = uVar15;
        puVar22[4] = uVar16;
        puVar6 = *(undefined4 **)(iVar28 + 0xe0);
        if (puVar18 == *(undefined4 **)(iVar28 + 0xe8)) {
            iVar30 = (int64_t)*(undefined4 **)(iVar28 + 0xe8) - (int64_t)puVar6;
            puVar22 = puVar29;
            puVar18 = puVar6;
        } else {
            func_0x000180498030(puVar29, puVar6, (int64_t)puVar18 - (int64_t)puVar6);
            iVar30 = *(int64_t *)(iVar28 + 0xe8) - (int64_t)puVar18;
            puVar22 = puVar22 + 5;
        }
        func_0x000180498030(puVar22, puVar18, iVar30);
        iVar30 = *(int64_t *)(iVar28 + 0xe0);
        if (iVar30 != 0) {
            uVar31 = (*(int64_t *)(iVar28 + 0xf0) - iVar30 >> 2) * 4;
            if (0xfff < uVar31) {
                if (0x1f < (iVar30 - *(int64_t *)(iVar30 + -8)) - 8U) goto code_r0x0001800f0993;
                uVar31 = uVar31 + 0x27;
                iVar30 = *(int64_t *)(iVar30 + -8);
            }
            func_0x000180459c3c(iVar30, uVar31);
        }
        *(undefined4 **)(iVar28 + 0xe0) = puVar29;
        *(undefined4 **)(iVar28 + 0xe8) = puVar29 + uVar20 * 5;
        *(undefined4 **)(iVar28 + 0xf0) = puVar29 + uVar33 * 5;
        goto code_r0x0001800f0648;
    }
    if (uVar31 < 0x1000) {
        puVar29 = (undefined4 *)func_0x000180459890();
        goto code_r0x0001800f0548;
    }
    if (uVar31 + 0x27 <= uVar31) goto code_r0x0001800f09cd;
    iVar19 = func_0x000180459890(uVar31 + 0x27);
    if (iVar19 != 0) {
        puVar29 = (undefined4 *)(iVar19 + 0x27U & 0xffffffffffffffe0);
        *(int64_t *)(puVar29 + -2) = iVar19;
        goto code_r0x0001800f0548;
    }
code_r0x0001800f0993:
    pcVar9 = (code *)swi(0x29);
    (*pcVar9)(5);
    puVar26 = auStack_c0;
code_r0x0001800f099a:
    pcVar9 = (code *)swi(0x29);
    (*pcVar9)(5);
    puVar26 = puVar26 + 8;
code_r0x0001800f09a1:
    *(undefined8 *)(puVar26 + -8) = 0x1800f09ae;
    func_0x000180459870(*(uint64_t *)(puVar26 + 0x68) ^ (uint64_t)puVar26);
    return;
}

// ============================================================
// Function: FUN_1800f09e0
// Address: 0x1800f09e0
// Size: 523 bytes
// ============================================================
undefined4 * fcn.1800f09e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    undefined4 *puVar11;
    uint64_t uVar12;
    undefined *puVar13;
    undefined *puVar14;
    uint64_t uVar15;
    undefined4 *puVar16;
    undefined4 *puVar17;
    undefined4 *puVar18;
    undefined auStack_98 [8];
    undefined auStack_90 [24];
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    puVar14 = auStack_98;
    puVar13 = auStack_98;
    puVar8 = *(undefined4 **)(arg1 + 8);
    if (puVar8 != *(undefined4 **)(arg1 + 0x10)) {
        uVar2 = *(undefined4 *)(arg2 + 4);
        uVar3 = *(undefined4 *)(arg2 + 8);
        uVar4 = *(undefined4 *)(arg2 + 0xc);
        *puVar8 = *(undefined4 *)arg2;
        puVar8[1] = uVar2;
        puVar8[2] = uVar3;
        puVar8[3] = uVar4;
        *(undefined (*) [16])(puVar8 + 4) = ZEXT816(0);
        *(undefined8 *)(puVar8 + 8) = 0;
        *(undefined8 *)(puVar8 + 10) = 0;
        uVar2 = *(undefined4 *)(arg3 + 4);
        uVar3 = *(undefined4 *)(arg3 + 8);
        uVar4 = *(undefined4 *)(arg3 + 0xc);
        puVar8[4] = *(undefined4 *)arg3;
        puVar8[5] = uVar2;
        puVar8[6] = uVar3;
        puVar8[7] = uVar4;
        uVar2 = *(undefined4 *)(arg3 + 0x14);
        uVar3 = *(undefined4 *)(arg3 + 0x18);
        uVar4 = *(undefined4 *)(arg3 + 0x1c);
        puVar8[8] = *(undefined4 *)(arg3 + 0x10);
        puVar8[9] = uVar2;
        puVar8[10] = uVar3;
        puVar8[0xb] = uVar4;
        *(undefined8 *)(arg3 + 0x10) = 0;
        *(undefined8 *)(arg3 + 0x18) = 0xf;
        *(undefined *)arg3 = 0;
        puVar8 = *(undefined4 **)(arg1 + 8);
        *(undefined4 **)(arg1 + 8) = puVar8 + 0xc;
        return puVar8;
    }
    iVar9 = (int64_t)puVar8 - *(int64_t *)arg1;
    iVar9 = iVar9 / 6 + (iVar9 >> 0x3f);
    iVar9 = (iVar9 >> 3) - (iVar9 >> 0x3f);
    if (iVar9 == 0x555555555555555) {
        func_0x000180010010();
        pcVar1 = (code *)swi(3);
        puVar8 = (undefined4 *)(*pcVar1)();
        return puVar8;
    }
    uVar15 = ((int64_t)*(undefined4 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 4) * -0x5555555555555555;
    uVar6 = 0x555555555555555 - (uVar15 >> 1);
    if (uVar15 < uVar6 || uVar15 - uVar6 == 0) {
        uVar6 = iVar9 + 1;
        uVar15 = (uVar15 >> 1) + uVar15;
        uVar12 = uVar6;
        if (uVar6 <= uVar15) {
            uVar12 = uVar15;
        }
        if (uVar12 < 0x555555555555556) {
            puVar16 = (undefined4 *)0x0;
            uVar15 = uVar12 * 0x30;
            if (uVar15 != 0) {
                if (uVar15 < 0x1000) {
                    puVar16 = (undefined4 *)func_0x000180459890();
                    puVar14 = auStack_98;
                } else {
                    if (uVar15 + 0x27 <= uVar15) goto code_r0x0001800f0be5;
                    iVar7 = func_0x000180459890(uVar15 + 0x27);
                    if (iVar7 == 0) {
                        pcVar1 = (code *)swi(0x29);
                        iVar7 = (*pcVar1)(5);
                        puVar13 = auStack_90;
                    }
                    puVar16 = (undefined4 *)(iVar7 + 0x27U & 0xffffffffffffffe0);
                    *(int64_t *)(puVar16 + -2) = iVar7;
                    puVar14 = puVar13;
                }
            }
            uVar2 = *(undefined4 *)arg2;
            uVar3 = *(undefined4 *)(arg2 + 4);
            uVar4 = *(undefined4 *)(arg2 + 8);
            uVar5 = *(undefined4 *)(arg2 + 0xc);
            *(int64_t *)(puVar14 + 0x20) = arg1;
            puVar18 = puVar16 + iVar9 * 0xc;
            *(uint64_t *)(puVar14 + 0x30) = uVar12;
            *(undefined4 **)(puVar14 + 0x38) = puVar18;
            *puVar18 = uVar2;
            puVar18[1] = uVar3;
            puVar18[2] = uVar4;
            puVar18[3] = uVar5;
            *(undefined (*) [16])(puVar18 + 4) = ZEXT816(0);
            *(undefined8 *)(puVar18 + 8) = 0;
            *(undefined8 *)(puVar18 + 10) = 0;
            uVar2 = *(undefined4 *)arg3;
            uVar3 = *(undefined4 *)(arg3 + 4);
            uVar4 = *(undefined4 *)(arg3 + 8);
            uVar5 = *(undefined4 *)(arg3 + 0xc);
            *(undefined4 **)(puVar14 + 0x40) = puVar18 + 0xc;
            puVar18[4] = uVar2;
            puVar18[5] = uVar3;
            puVar18[6] = uVar4;
            puVar18[7] = uVar5;
            uVar2 = *(undefined4 *)(arg3 + 0x14);
            uVar3 = *(undefined4 *)(arg3 + 0x18);
            uVar4 = *(undefined4 *)(arg3 + 0x1c);
            puVar18[8] = *(undefined4 *)(arg3 + 0x10);
            puVar18[9] = uVar2;
            puVar18[10] = uVar3;
            puVar18[0xb] = uVar4;
            *(undefined8 *)(arg3 + 0x10) = 0;
            *(undefined8 *)(arg3 + 0x18) = 0xf;
            *(undefined *)arg3 = 0;
            puVar11 = *(undefined4 **)(arg1 + 8);
            puVar10 = *(undefined4 **)arg1;
            puVar17 = puVar16;
            if (puVar8 != puVar11) {
                *(undefined8 *)(puVar14 + -8) = 0x1800f0b97;
                puVar11 = puVar18 + 0xc;
                func_0x0001800f3420(puVar10, puVar8, puVar16);
                puVar16 = puVar11;
                puVar11 = *(undefined4 **)(arg1 + 8);
                *(undefined4 **)(puVar14 + 0x38) = puVar17;
                puVar10 = puVar8;
            }
            *(undefined8 *)(puVar14 + -8) = 0x1800f0bab;
            func_0x0001800f3420(puVar10, puVar11, puVar16);
            *(undefined8 *)(puVar14 + 0x28) = 0;
            *(undefined8 *)(puVar14 + -8) = 0x1800f0bc1;
            func_0x0001800f3710(arg1, puVar17, uVar6, uVar12);
            *(undefined8 *)(puVar14 + -8) = 0x1800f0bcb;
            func_0x0001800f3660(puVar14 + 0x20);
            return puVar18;
        }
    }
code_r0x0001800f0be5:
    func_0x000180004720();
    pcVar1 = (code *)swi(3);
    puVar8 = (undefined4 *)(*pcVar1)();
    return puVar8;
}

// ============================================================
// Function: FUN_1800f0bf0
// Address: 0x1800f0bf0
// Size: 60 bytes
// ============================================================
int64_t fcn.1800f0bf0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    
    if (*(int64_t *)(arg3 + 0x10) == 0) {
        iVar1 = 0;
    } else {
        iVar1 = **(int64_t **)arg3 + *(int64_t *)(arg3 + 8) * 8;
    }
    func_0x0001800f1110(arg1, arg2, iVar1);
    return arg2;
}

// ============================================================
// Function: FUN_1800f0c30
// Address: 0x1800f0c30
// Size: 177 bytes
// ============================================================
undefined8 * fcn.1800f0c30(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    undefined8 *puVar7;
    
    iVar5 = *(int64_t *)arg1;
    if (iVar5 != 0) {
        puVar7 = (undefined8 *)(*(int64_t *)(arg1 + 8) + 7 + iVar5 + 8 & 0xfffffffffffffff8);
        if (puVar7 + 8 <= (undefined8 *)(iVar5 + 0x2008)) {
            iVar5 = (int64_t)puVar7 + (0x40 - (iVar5 + 8));
            goto code_r0x0001800f0c98;
        }
    }
    puVar6 = (undefined8 *)func_0x000180459890(0x2008);
    *puVar6 = *(undefined8 *)arg1;
    puVar7 = puVar6 + 1;
    *(undefined8 **)arg1 = puVar6;
    iVar5 = 0x40;
code_r0x0001800f0c98:
    *(int64_t *)(arg1 + 8) = iVar5;
    uVar1 = *(undefined4 *)0x180782718;
    *puVar7 = 0x180642298;
    *(undefined4 *)(puVar7 + 1) = uVar1;
    uVar1 = *(undefined4 *)arg2;
    uVar2 = *(undefined4 *)(arg2 + 4);
    uVar3 = *(undefined4 *)(arg2 + 8);
    uVar4 = *(undefined4 *)(arg2 + 0xc);
    *puVar7 = 0x180641b30;
    *(undefined *)(puVar7 + 4) = 0;
    *(undefined4 *)((int64_t)puVar7 + 0xc) = uVar1;
    *(undefined4 *)(puVar7 + 2) = uVar2;
    *(undefined4 *)((int64_t)puVar7 + 0x14) = uVar3;
    *(undefined4 *)(puVar7 + 3) = uVar4;
    uVar1 = *(undefined4 *)arg3;
    uVar2 = *(undefined4 *)(arg3 + 4);
    uVar3 = *(undefined4 *)(arg3 + 8);
    uVar4 = *(undefined4 *)(arg3 + 0xc);
    *(undefined *)(puVar7 + 7) = 1;
    *(undefined4 *)(puVar7 + 5) = uVar1;
    *(undefined4 *)((int64_t)puVar7 + 0x2c) = uVar2;
    *(undefined4 *)(puVar7 + 6) = uVar3;
    *(undefined4 *)((int64_t)puVar7 + 0x34) = uVar4;
    return puVar7;
}

// ============================================================
// Function: FUN_1800f0cf0
// Address: 0x1800f0cf0
// Size: 173 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 * fcn.1800f0cf0(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    undefined8 *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar5 = *(int64_t *)arg1;
    if (iVar5 != 0) {
        puVar7 = (undefined8 *)(*(int64_t *)(arg1 + 8) + 7 + iVar5 + 8 & 0xfffffffffffffff8);
        if (puVar7 + 5 <= (undefined8 *)(iVar5 + 0x2008)) {
            iVar5 = (int64_t)puVar7 + (0x28 - (iVar5 + 8));
            goto code_r0x0001800f0d5b;
        }
    }
    puVar6 = (undefined8 *)func_0x000180459890(0x2008);
    *puVar6 = *(undefined8 *)arg1;
    puVar7 = puVar6 + 1;
    *(undefined8 **)arg1 = puVar6;
    iVar5 = 0x28;
code_r0x0001800f0d5b:
    *(int64_t *)(arg1 + 8) = iVar5;
    uVar1 = *(undefined4 *)0x180782700;
    *puVar7 = 0x180642298;
    *(undefined4 *)(puVar7 + 1) = uVar1;
    uVar1 = *(undefined4 *)arg2;
    uVar2 = *(undefined4 *)(arg2 + 4);
    uVar3 = *(undefined4 *)(arg2 + 8);
    uVar4 = *(undefined4 *)(arg2 + 0xc);
    *puVar7 = 0x1806421a8;
    *(undefined4 *)((int64_t)puVar7 + 0xc) = uVar1;
    *(undefined4 *)(puVar7 + 2) = uVar2;
    *(undefined4 *)((int64_t)puVar7 + 0x14) = uVar3;
    *(undefined4 *)(puVar7 + 3) = uVar4;
    *(undefined *)(puVar7 + 4) = 0;
    return puVar7;
}

// ============================================================
// Function: FUN_1800f0da0
// Address: 0x1800f0da0
// Size: 173 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 * fcn.1800f0da0(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    undefined8 *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar5 = *(int64_t *)arg1;
    if (iVar5 != 0) {
        puVar7 = (undefined8 *)(*(int64_t *)(arg1 + 8) + 7 + iVar5 + 8 & 0xfffffffffffffff8);
        if (puVar7 + 5 <= (undefined8 *)(iVar5 + 0x2008)) {
            iVar5 = (int64_t)puVar7 + (0x28 - (iVar5 + 8));
            goto code_r0x0001800f0e0b;
        }
    }
    puVar6 = (undefined8 *)func_0x000180459890(0x2008);
    *puVar6 = *(undefined8 *)arg1;
    puVar7 = puVar6 + 1;
    *(undefined8 **)arg1 = puVar6;
    iVar5 = 0x28;
code_r0x0001800f0e0b:
    *(int64_t *)(arg1 + 8) = iVar5;
    uVar1 = *(undefined4 *)0x180782750;
    *puVar7 = 0x180642298;
    *(undefined4 *)(puVar7 + 1) = uVar1;
    uVar1 = *(undefined4 *)arg2;
    uVar2 = *(undefined4 *)(arg2 + 4);
    uVar3 = *(undefined4 *)(arg2 + 8);
    uVar4 = *(undefined4 *)(arg2 + 0xc);
    *puVar7 = 0x180641e60;
    *(undefined4 *)((int64_t)puVar7 + 0xc) = uVar1;
    *(undefined4 *)(puVar7 + 2) = uVar2;
    *(undefined4 *)((int64_t)puVar7 + 0x14) = uVar3;
    *(undefined4 *)(puVar7 + 3) = uVar4;
    *(undefined *)(puVar7 + 4) = 0;
    return puVar7;
}

// ============================================================
// Function: FUN_1800f0e50
// Address: 0x1800f0e50
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1800f0e50(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    uVar3 = *(uint64_t *)(arg3 + 0x10);
    *(undefined8 *)(arg2 + 8) = 0;
    *(undefined8 *)arg2 = 0;
    if (uVar3 == 0) {
        *(undefined8 *)(arg2 + 8) = 0;
        return arg2;
    }
    iVar4 = *(int64_t *)(arg3 + 8);
    iVar2 = uVar3 * 8;
    iVar5 = **(int64_t **)arg3;
    uVar6 = func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), iVar2);
    *(uint64_t *)arg2 = uVar6;
    *(uint64_t *)(arg2 + 8) = uVar3;
    if (uVar3 != 0) {
        uVar1 = iVar5 + iVar4 * 8;
        if ((uVar3 < 2) || ((uVar6 <= iVar2 + -8 + uVar1 && (uVar1 <= iVar2 + -8 + uVar6)))) {
            uVar7 = 0;
            do {
                *(undefined8 *)(uVar6 + uVar7 * 8) = *(undefined8 *)(uVar1 + uVar7 * 8);
                uVar7 = uVar7 + 1;
            } while (uVar7 < uVar3);
        } else {
            func_0x000180498030(uVar6, uVar1, iVar2);
        }
    }
    return arg2;
}

// ============================================================
// Function: FUN_1800f0e83
// Address: 0x1800f0e83
// Size: 127 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1800f0e50(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    uVar3 = *(uint64_t *)(arg3 + 0x10);
    *(undefined8 *)(arg2 + 8) = 0;
    *(undefined8 *)arg2 = 0;
    if (uVar3 == 0) {
        *(undefined8 *)(arg2 + 8) = 0;
        return arg2;
    }
    iVar4 = *(int64_t *)(arg3 + 8);
    iVar2 = uVar3 * 8;
    iVar5 = **(int64_t **)arg3;
    uVar6 = func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), iVar2);
    *(uint64_t *)arg2 = uVar6;
    *(uint64_t *)(arg2 + 8) = uVar3;
    if (uVar3 != 0) {
        uVar1 = iVar5 + iVar4 * 8;
        if ((uVar3 < 2) || ((uVar6 <= iVar2 + -8 + uVar1 && (uVar1 <= iVar2 + -8 + uVar6)))) {
            uVar7 = 0;
            do {
                *(undefined8 *)(uVar6 + uVar7 * 8) = *(undefined8 *)(uVar1 + uVar7 * 8);
                uVar7 = uVar7 + 1;
            } while (uVar7 < uVar3);
        } else {
            func_0x000180498030(uVar6, uVar1, iVar2);
        }
    }
    return arg2;
}

// ============================================================
// Function: FUN_1800f0f02
// Address: 0x1800f0f02
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1800f0e50(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    uVar3 = *(uint64_t *)(arg3 + 0x10);
    *(undefined8 *)(arg2 + 8) = 0;
    *(undefined8 *)arg2 = 0;
    if (uVar3 == 0) {
        *(undefined8 *)(arg2 + 8) = 0;
        return arg2;
    }
    iVar4 = *(int64_t *)(arg3 + 8);
    iVar2 = uVar3 * 8;
    iVar5 = **(int64_t **)arg3;
    uVar6 = func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), iVar2);
    *(uint64_t *)arg2 = uVar6;
    *(uint64_t *)(arg2 + 8) = uVar3;
    if (uVar3 != 0) {
        uVar1 = iVar5 + iVar4 * 8;
        if ((uVar3 < 2) || ((uVar6 <= iVar2 + -8 + uVar1 && (uVar1 <= iVar2 + -8 + uVar6)))) {
            uVar7 = 0;
            do {
                *(undefined8 *)(uVar6 + uVar7 * 8) = *(undefined8 *)(uVar1 + uVar7 * 8);
                uVar7 = uVar7 + 1;
            } while (uVar7 < uVar3);
        } else {
            func_0x000180498030(uVar6, uVar1, iVar2);
        }
    }
    return arg2;
}

// ============================================================
// Function: FUN_1800f0f22
// Address: 0x1800f0f22
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1800f0e50(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    uVar3 = *(uint64_t *)(arg3 + 0x10);
    *(undefined8 *)(arg2 + 8) = 0;
    *(undefined8 *)arg2 = 0;
    if (uVar3 == 0) {
        *(undefined8 *)(arg2 + 8) = 0;
        return arg2;
    }
    iVar4 = *(int64_t *)(arg3 + 8);
    iVar2 = uVar3 * 8;
    iVar5 = **(int64_t **)arg3;
    uVar6 = func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), iVar2);
    *(uint64_t *)arg2 = uVar6;
    *(uint64_t *)(arg2 + 8) = uVar3;
    if (uVar3 != 0) {
        uVar1 = iVar5 + iVar4 * 8;
        if ((uVar3 < 2) || ((uVar6 <= iVar2 + -8 + uVar1 && (uVar1 <= iVar2 + -8 + uVar6)))) {
            uVar7 = 0;
            do {
                *(undefined8 *)(uVar6 + uVar7 * 8) = *(undefined8 *)(uVar1 + uVar7 * 8);
                uVar7 = uVar7 + 1;
            } while (uVar7 < uVar3);
        } else {
            func_0x000180498030(uVar6, uVar1, iVar2);
        }
    }
    return arg2;
}

// ============================================================
// Function: FUN_1800f0f40
// Address: 0x1800f0f40
// Size: 162 bytes
// ============================================================
undefined8 * fcn.1800f0f40(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    int64_t iVar13;
    undefined8 *puVar14;
    undefined8 *puVar15;
    
    iVar13 = *(int64_t *)arg1;
    if (iVar13 != 0) {
        puVar15 = (undefined8 *)(*(int64_t *)(arg1 + 8) + 7 + iVar13 + 8 & 0xfffffffffffffff8);
        if (puVar15 + 7 <= (undefined8 *)(iVar13 + 0x2008U)) {
            iVar13 = (int64_t)puVar15 + (0x38 - (iVar13 + 8));
            goto code_r0x0001800f0fad;
        }
    }
    puVar14 = (undefined8 *)func_0x000180459890(0x2008);
    *puVar14 = *(undefined8 *)arg1;
    puVar15 = puVar14 + 1;
    *(undefined8 **)arg1 = puVar14;
    iVar13 = 0x38;
code_r0x0001800f0fad:
    *(int64_t *)(arg1 + 8) = iVar13;
    uVar1 = *(undefined4 *)arg4;
    uVar2 = *(undefined4 *)(arg4 + 4);
    uVar3 = *(undefined4 *)(arg4 + 8);
    uVar4 = *(undefined4 *)(arg4 + 0xc);
    uVar5 = *(undefined4 *)arg3;
    uVar6 = *(undefined4 *)(arg3 + 4);
    uVar7 = *(undefined4 *)(arg3 + 8);
    uVar8 = *(undefined4 *)(arg3 + 0xc);
    uVar9 = *(undefined4 *)arg2;
    uVar10 = *(undefined4 *)(arg2 + 4);
    uVar11 = *(undefined4 *)(arg2 + 8);
    uVar12 = *(undefined4 *)(arg2 + 0xc);
    *(undefined4 *)puVar15 = *(undefined4 *)0x180782a78;
    *(undefined4 *)(puVar15 + 3) = uVar5;
    *(undefined4 *)((int64_t)puVar15 + 0x1c) = uVar6;
    *(undefined4 *)(puVar15 + 4) = uVar7;
    *(undefined4 *)((int64_t)puVar15 + 0x24) = uVar8;
    *(undefined4 *)(puVar15 + 1) = uVar9;
    *(undefined4 *)((int64_t)puVar15 + 0xc) = uVar10;
    *(undefined4 *)(puVar15 + 2) = uVar11;
    *(undefined4 *)((int64_t)puVar15 + 0x14) = uVar12;
    *(undefined4 *)(puVar15 + 5) = uVar1;
    *(undefined4 *)((int64_t)puVar15 + 0x2c) = uVar2;
    *(undefined4 *)(puVar15 + 6) = uVar3;
    *(undefined4 *)((int64_t)puVar15 + 0x34) = uVar4;
    return puVar15;
}

// ============================================================
// Function: FUN_1800f0ff0
// Address: 0x1800f0ff0
// Size: 230 bytes
// ============================================================
undefined8 * fcn.1800f0ff0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    undefined uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    undefined8 *puVar8;
    
    iVar6 = *(int64_t *)arg1;
    if (iVar6 != 0) {
        puVar8 = (undefined8 *)(*(int64_t *)(arg1 + 8) + 7 + iVar6 + 8 & 0xfffffffffffffff8);
        if (puVar8 + 0xf <= (undefined8 *)(iVar6 + 0x2008)) {
            iVar6 = (int64_t)puVar8 + (0x78 - (iVar6 + 8));
            goto code_r0x0001800f105d;
        }
    }
    puVar7 = (undefined8 *)func_0x000180459890(0x2008);
    *puVar7 = *(undefined8 *)arg1;
    puVar8 = puVar7 + 1;
    *(undefined8 **)arg1 = puVar7;
    iVar6 = 0x78;
code_r0x0001800f105d:
    *(int64_t *)(arg1 + 8) = iVar6;
    uVar1 = *(undefined *)arg_30h;
    *(undefined4 *)(puVar8 + 1) = *(undefined4 *)0x1807826f8;
    *puVar8 = 0x180642298;
    uVar2 = *(undefined4 *)arg2;
    uVar3 = *(undefined4 *)(arg2 + 4);
    uVar4 = *(undefined4 *)(arg2 + 8);
    uVar5 = *(undefined4 *)(arg2 + 0xc);
    *puVar8 = 0x180641a68;
    *(undefined *)(puVar8 + 4) = 0;
    *(undefined4 *)((int64_t)puVar8 + 0xc) = uVar2;
    *(undefined4 *)(puVar8 + 2) = uVar3;
    *(undefined4 *)((int64_t)puVar8 + 0x14) = uVar4;
    *(undefined4 *)(puVar8 + 3) = uVar5;
    uVar2 = *(undefined4 *)(arg3 + 4);
    uVar3 = *(undefined4 *)(arg3 + 8);
    uVar4 = *(undefined4 *)(arg3 + 0xc);
    *(undefined4 *)(puVar8 + 5) = *(undefined4 *)arg3;
    *(undefined4 *)((int64_t)puVar8 + 0x2c) = uVar2;
    *(undefined4 *)(puVar8 + 6) = uVar3;
    *(undefined4 *)((int64_t)puVar8 + 0x34) = uVar4;
    uVar2 = *(undefined4 *)arg4;
    uVar3 = *(undefined4 *)(arg4 + 4);
    uVar4 = *(undefined4 *)(arg4 + 8);
    uVar5 = *(undefined4 *)(arg4 + 0xc);
    *(undefined *)(puVar8 + 9) = uVar1;
    *(undefined4 *)(puVar8 + 7) = uVar2;
    *(undefined4 *)((int64_t)puVar8 + 0x3c) = uVar3;
    *(undefined4 *)(puVar8 + 8) = uVar4;
    *(undefined4 *)((int64_t)puVar8 + 0x44) = uVar5;
    *(undefined *)((int64_t)puVar8 + 0x5c) = 0;
    *(undefined *)((int64_t)puVar8 + 0x49) = 0;
    uVar2 = *(undefined4 *)(arg_28h + 4);
    uVar3 = *(undefined4 *)(arg_28h + 8);
    uVar4 = *(undefined4 *)(arg_28h + 0xc);
    *(undefined4 *)(puVar8 + 0xc) = *(undefined4 *)arg_28h;
    *(undefined4 *)((int64_t)puVar8 + 100) = uVar2;
    *(undefined4 *)(puVar8 + 0xd) = uVar3;
    *(undefined4 *)((int64_t)puVar8 + 0x6c) = uVar4;
    *(undefined4 *)(puVar8 + 0xe) = *(undefined4 *)(arg_28h + 0x10);
    return puVar8;
}

// ============================================================
// Function: FUN_1800f1110
// Address: 0x1800f1110
// Size: 55 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1800f1110(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_30h;
    
    *(undefined8 *)arg2 = 0;
    *(undefined8 *)(arg2 + 8) = 0;
    if (arg4 == 0) {
        *(undefined8 *)(arg2 + 8) = 0;
        return arg2;
    }
    iVar1 = arg4 * 8;
    uVar2 = func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), iVar1);
    *(uint64_t *)arg2 = uVar2;
    *(int64_t *)(arg2 + 8) = arg4;
    if (arg4 != 0) {
        if (((uint64_t)arg4 < 2) || ((uVar2 <= (uint64_t)(arg3 + -8 + iVar1) && ((uint64_t)arg3 <= iVar1 + -8 + uVar2)))
           ) {
            uVar3 = 0;
            do {
                *(undefined8 *)(uVar2 + uVar3 * 8) = *(undefined8 *)(arg3 + uVar3 * 8);
                uVar3 = uVar3 + 1;
            } while (uVar3 < (uint64_t)arg4);
        } else {
            func_0x000180498030(uVar2, arg3, iVar1);
        }
    }
    return arg2;
}

// ============================================================
// Function: FUN_1800f1147
// Address: 0x1800f1147
// Size: 104 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1800f1110(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_30h;
    
    *(undefined8 *)arg2 = 0;
    *(undefined8 *)(arg2 + 8) = 0;
    if (arg4 == 0) {
        *(undefined8 *)(arg2 + 8) = 0;
        return arg2;
    }
    iVar1 = arg4 * 8;
    uVar2 = func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), iVar1);
    *(uint64_t *)arg2 = uVar2;
    *(int64_t *)(arg2 + 8) = arg4;
    if (arg4 != 0) {
        if (((uint64_t)arg4 < 2) || ((uVar2 <= (uint64_t)(arg3 + -8 + iVar1) && ((uint64_t)arg3 <= iVar1 + -8 + uVar2)))
           ) {
            uVar3 = 0;
            do {
                *(undefined8 *)(uVar2 + uVar3 * 8) = *(undefined8 *)(arg3 + uVar3 * 8);
                uVar3 = uVar3 + 1;
            } while (uVar3 < (uint64_t)arg4);
        } else {
            func_0x000180498030(uVar2, arg3, iVar1);
        }
    }
    return arg2;
}

// ============================================================
// Function: FUN_1800f11af
// Address: 0x1800f11af
// Size: 35 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1800f1110(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_30h;
    
    *(undefined8 *)arg2 = 0;
    *(undefined8 *)(arg2 + 8) = 0;
    if (arg4 == 0) {
        *(undefined8 *)(arg2 + 8) = 0;
        return arg2;
    }
    iVar1 = arg4 * 8;
    uVar2 = func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), iVar1);
    *(uint64_t *)arg2 = uVar2;
    *(int64_t *)(arg2 + 8) = arg4;
    if (arg4 != 0) {
        if (((uint64_t)arg4 < 2) || ((uVar2 <= (uint64_t)(arg3 + -8 + iVar1) && ((uint64_t)arg3 <= iVar1 + -8 + uVar2)))
           ) {
            uVar3 = 0;
            do {
                *(undefined8 *)(uVar2 + uVar3 * 8) = *(undefined8 *)(arg3 + uVar3 * 8);
                uVar3 = uVar3 + 1;
            } while (uVar3 < (uint64_t)arg4);
        } else {
            func_0x000180498030(uVar2, arg3, iVar1);
        }
    }
    return arg2;
}

// ============================================================
// Function: FUN_1800f11d2
// Address: 0x1800f11d2
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1800f1110(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_30h;
    
    *(undefined8 *)arg2 = 0;
    *(undefined8 *)(arg2 + 8) = 0;
    if (arg4 == 0) {
        *(undefined8 *)(arg2 + 8) = 0;
        return arg2;
    }
    iVar1 = arg4 * 8;
    uVar2 = func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), iVar1);
    *(uint64_t *)arg2 = uVar2;
    *(int64_t *)(arg2 + 8) = arg4;
    if (arg4 != 0) {
        if (((uint64_t)arg4 < 2) || ((uVar2 <= (uint64_t)(arg3 + -8 + iVar1) && ((uint64_t)arg3 <= iVar1 + -8 + uVar2)))
           ) {
            uVar3 = 0;
            do {
                *(undefined8 *)(uVar2 + uVar3 * 8) = *(undefined8 *)(arg3 + uVar3 * 8);
                uVar3 = uVar3 + 1;
            } while (uVar3 < (uint64_t)arg4);
        } else {
            func_0x000180498030(uVar2, arg3, iVar1);
        }
    }
    return arg2;
}

// ============================================================
// Function: FUN_1800f11f0
// Address: 0x1800f11f0
// Size: 178 bytes
// ============================================================
undefined8 * fcn.1800f11f0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t iVar10;
    undefined8 *puVar11;
    undefined8 *puVar12;
    
    iVar10 = *(int64_t *)arg1;
    if (iVar10 != 0) {
        puVar12 = (undefined8 *)(*(int64_t *)(arg1 + 8) + 7 + iVar10 + 8 & 0xfffffffffffffff8);
        if (puVar12 + 7 <= (undefined8 *)(iVar10 + 0x2008)) {
            iVar10 = (int64_t)puVar12 + (0x38 - (iVar10 + 8));
            goto code_r0x0001800f1258;
        }
    }
    puVar11 = (undefined8 *)func_0x000180459890(0x2008);
    *puVar11 = *(undefined8 *)arg1;
    puVar12 = puVar11 + 1;
    *(undefined8 **)arg1 = puVar11;
    iVar10 = 0x38;
code_r0x0001800f1258:
    *(int64_t *)(arg1 + 8) = iVar10;
    uVar6 = *(undefined4 *)0x18078268c;
    uVar2 = *(undefined4 *)arg3;
    uVar3 = *(undefined4 *)(arg3 + 4);
    uVar4 = *(undefined4 *)(arg3 + 8);
    uVar5 = *(undefined4 *)(arg3 + 0xc);
    uVar1 = *(undefined8 *)(arg3 + 0x10);
    *puVar12 = 0x180642298;
    *(undefined4 *)(puVar12 + 1) = uVar6;
    uVar6 = *(undefined4 *)arg2;
    uVar7 = *(undefined4 *)(arg2 + 4);
    uVar8 = *(undefined4 *)(arg2 + 8);
    uVar9 = *(undefined4 *)(arg2 + 0xc);
    *puVar12 = 0x180641fc8;
    *(undefined4 *)(puVar12 + 4) = uVar2;
    *(undefined4 *)((int64_t)puVar12 + 0x24) = uVar3;
    *(undefined4 *)(puVar12 + 5) = uVar4;
    *(undefined4 *)((int64_t)puVar12 + 0x2c) = uVar5;
    *(undefined4 *)((int64_t)puVar12 + 0xc) = uVar6;
    *(undefined4 *)(puVar12 + 2) = uVar7;
    *(undefined4 *)((int64_t)puVar12 + 0x14) = uVar8;
    *(undefined4 *)(puVar12 + 3) = uVar9;
    puVar12[6] = uVar1;
    return puVar12;
}

// ============================================================
// Function: FUN_1800f12b0
// Address: 0x1800f12b0
// Size: 152 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 * fcn.1800f12b0(int64_t arg1)
{
    undefined4 uVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    undefined8 *puVar4;
    int64_t var_8h;
    
    iVar2 = *(int64_t *)arg1;
    if (iVar2 != 0) {
        puVar4 = (undefined8 *)(*(int64_t *)(arg1 + 8) + 7 + iVar2 + 8 & 0xfffffffffffffff8);
        if (puVar4 + 5 <= (undefined8 *)(iVar2 + 0x2008U)) {
            iVar2 = (int64_t)puVar4 + (0x28 - (iVar2 + 8));
            goto code_r0x0001800f1313;
        }
    }
    puVar3 = (undefined8 *)func_0x000180459890(0x2008);
    *puVar3 = *(undefined8 *)arg1;
    puVar4 = puVar3 + 1;
    *(undefined8 **)arg1 = puVar3;
    iVar2 = 0x28;
code_r0x0001800f1313:
    *(int64_t *)(arg1 + 8) = iVar2;
    uVar1 = *(undefined4 *)0x180782ac0;
    *(undefined8 *)((int64_t)puVar4 + 4) = 0xffffffffffffffff;
    *(undefined8 *)((int64_t)puVar4 + 0xc) = 0xffffffffffffffff;
    puVar4[3] = 0;
    puVar4[4] = 0;
    *(undefined4 *)puVar4 = uVar1;
    return puVar4;
}

// ============================================================
// Function: FUN_1800f1350
// Address: 0x1800f1350
// Size: 166 bytes
// ============================================================
undefined8 * fcn.1800f1350(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    undefined8 *puVar8;
    
    iVar6 = *(int64_t *)arg1;
    if (iVar6 != 0) {
        puVar8 = (undefined8 *)(*(int64_t *)(arg1 + 8) + 7 + iVar6 + 8 & 0xfffffffffffffff8);
        if (puVar8 + 5 <= (undefined8 *)(iVar6 + 0x2008)) {
            iVar6 = (int64_t)puVar8 + (0x28 - (iVar6 + 8));
            goto code_r0x0001800f13b8;
        }
    }
    puVar7 = (undefined8 *)func_0x000180459890(0x2008);
    *puVar7 = *(undefined8 *)arg1;
    puVar8 = puVar7 + 1;
    *(undefined8 **)arg1 = puVar7;
    iVar6 = 0x28;
code_r0x0001800f13b8:
    *(int64_t *)(arg1 + 8) = iVar6;
    uVar2 = *(undefined4 *)0x180782784;
    uVar1 = *(undefined8 *)arg3;
    *puVar8 = 0x180642298;
    *(undefined4 *)(puVar8 + 1) = uVar2;
    uVar2 = *(undefined4 *)arg2;
    uVar3 = *(undefined4 *)(arg2 + 4);
    uVar4 = *(undefined4 *)(arg2 + 8);
    uVar5 = *(undefined4 *)(arg2 + 0xc);
    *puVar8 = 0x180641d70;
    puVar8[4] = uVar1;
    *(undefined4 *)((int64_t)puVar8 + 0xc) = uVar2;
    *(undefined4 *)(puVar8 + 2) = uVar3;
    *(undefined4 *)((int64_t)puVar8 + 0x14) = uVar4;
    *(undefined4 *)(puVar8 + 3) = uVar5;
    return puVar8;
}

// ============================================================
// Function: FUN_1800f1400
// Address: 0x1800f1400
// Size: 146 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 * fcn.1800f1400(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    undefined8 *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = *(int64_t *)arg1;
    if (iVar2 != 0) {
        puVar4 = (undefined8 *)(*(int64_t *)(arg1 + 8) + 7 + iVar2 + 8 & 0xfffffffffffffff8);
        if ((int64_t)puVar4 + 0xcU <= iVar2 + 0x2008U) {
            iVar2 = (int64_t)puVar4 + (0xc - (iVar2 + 8));
            goto code_r0x0001800f146b;
        }
    }
    puVar3 = (undefined8 *)func_0x000180459890(0x2008);
    *puVar3 = *(undefined8 *)arg1;
    puVar4 = puVar3 + 1;
    *(undefined8 **)arg1 = puVar3;
    iVar2 = 0xc;
code_r0x0001800f146b:
    *(int64_t *)(arg1 + 8) = iVar2;
    uVar1 = *(undefined4 *)0x180782a50;
    *(undefined8 *)((int64_t)puVar4 + 4) = *(undefined8 *)arg2;
    *(undefined4 *)puVar4 = uVar1;
    return puVar4;
}

// ============================================================
// Function: FUN_1800f14a0
// Address: 0x1800f14a0
// Size: 162 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 * fcn.1800f14a0(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar4 = *(int64_t *)arg1;
    if (iVar4 != 0) {
        puVar5 = (undefined8 *)(*(int64_t *)(arg1 + 8) + 7 + iVar4 + 8 & 0xfffffffffffffff8);
        if (puVar5 + 7 <= (undefined8 *)(iVar4 + 0x2008U)) {
            iVar4 = (int64_t)puVar5 + (0x38 - (iVar4 + 8));
            goto code_r0x0001800f150b;
        }
    }
    puVar5 = (undefined8 *)func_0x000180459890(0x2008);
    *puVar5 = *(undefined8 *)arg1;
    iVar4 = 0x38;
    *(undefined8 **)arg1 = puVar5;
    puVar5 = puVar5 + 1;
code_r0x0001800f150b:
    *(int64_t *)(arg1 + 8) = iVar4;
    uVar1 = *(undefined4 *)(arg2 + 4);
    uVar2 = *(undefined4 *)(arg2 + 8);
    uVar3 = *(undefined4 *)(arg2 + 0xc);
    *(undefined4 *)puVar5 = *(undefined4 *)arg2;
    *(undefined4 *)((int64_t)puVar5 + 4) = uVar1;
    *(undefined4 *)(puVar5 + 1) = uVar2;
    *(undefined4 *)((int64_t)puVar5 + 0xc) = uVar3;
    uVar1 = *(undefined4 *)(arg2 + 0x14);
    uVar2 = *(undefined4 *)(arg2 + 0x18);
    uVar3 = *(undefined4 *)(arg2 + 0x1c);
    *(undefined4 *)(puVar5 + 2) = *(undefined4 *)(arg2 + 0x10);
    *(undefined4 *)((int64_t)puVar5 + 0x14) = uVar1;
    *(undefined4 *)(puVar5 + 3) = uVar2;
    *(undefined4 *)((int64_t)puVar5 + 0x1c) = uVar3;
    uVar1 = *(undefined4 *)(arg2 + 0x24);
    uVar2 = *(undefined4 *)(arg2 + 0x28);
    uVar3 = *(undefined4 *)(arg2 + 0x2c);
    *(undefined4 *)(puVar5 + 4) = *(undefined4 *)(arg2 + 0x20);
    *(undefined4 *)((int64_t)puVar5 + 0x24) = uVar1;
    *(undefined4 *)(puVar5 + 5) = uVar2;
    *(undefined4 *)((int64_t)puVar5 + 0x2c) = uVar3;
    puVar5[6] = *(undefined8 *)(arg2 + 0x30);
    return puVar5;
}

// ============================================================
// Function: FUN_1800f1550
// Address: 0x1800f1550
// Size: 280 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_3bh
// WARNING: [rz-ghidra] Detected overlap for variable var_39h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h

undefined8 *
fcn.1800f1550(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, undefined8 placeholder_4,
             int64_t arg_30h)
{
    undefined8 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    uint32_t uVar6;
    int64_t iVar7;
    undefined8 *puVar8;
    undefined8 *puVar9;
    int64_t var_48h;
    undefined uStack_40;
    int64_t var_3fh;
    int64_t var_37h;
    
    uVar2 = stack0xffffffffffffffc8;
    iVar7 = *(int64_t *)arg1;
    if (iVar7 != 0) {
        puVar9 = (undefined8 *)(*(int64_t *)(arg1 + 8) + 7 + iVar7 + 8 & 0xfffffffffffffff8);
        if (puVar9 + 0xf <= (undefined8 *)(iVar7 + 0x2008)) {
            iVar7 = (int64_t)puVar9 + (0x78 - (iVar7 + 8));
            goto code_r0x0001800f15b8;
        }
    }
    puVar8 = (undefined8 *)func_0x000180459890(0x2008);
    *puVar8 = *(undefined8 *)arg1;
    puVar9 = puVar8 + 1;
    *(undefined8 **)arg1 = puVar8;
    iVar7 = 0x78;
code_r0x0001800f15b8:
    *(int64_t *)(arg1 + 8) = iVar7;
    uVar1 = *(undefined8 *)arg4;
    uVar6 = (uint32_t)stack0xffffffffffffffc8 >> 8;
    *(undefined4 *)(puVar9 + 1) = *(undefined4 *)0x1807826bc;
    *puVar9 = 0x180642298;
    uVar2 = *(undefined4 *)arg2;
    uVar3 = *(undefined4 *)(arg2 + 4);
    uVar4 = *(undefined4 *)(arg2 + 8);
    uVar5 = *(undefined4 *)(arg2 + 0xc);
    *puVar9 = 0x1806419a0;
    puVar9[5] = CONCAT44(var_48h._4_4_, (undefined4)var_48h);
    *(uint32_t *)((int64_t)puVar9 + 0x31) = CONCAT13(var_3fh._3_1_, (unkbyte3)var_3fh);
    *(undefined2 *)((int64_t)puVar9 + 0x35) = var_3fh._4_2_;
    *(undefined *)((int64_t)puVar9 + 0x37) = var_3fh._6_1_;
    *(undefined4 *)(puVar9 + 7) = (undefined4)var_48h;
    *(undefined4 *)((int64_t)puVar9 + 0x3c) = var_48h._4_4_;
    *(undefined4 *)(puVar9 + 8) = _uStack_40;
    *(uint32_t *)((int64_t)puVar9 + 0x44) = CONCAT13(var_3fh._6_1_, CONCAT21(var_3fh._4_2_, var_3fh._3_1_));
    *(undefined4 *)(puVar9 + 9) = stack0xffffffffffffffc8;
    *(undefined4 *)((int64_t)puVar9 + 0xc) = uVar2;
    *(undefined4 *)(puVar9 + 2) = uVar3;
    *(undefined4 *)((int64_t)puVar9 + 0x14) = uVar4;
    *(undefined4 *)(puVar9 + 3) = uVar5;
    *(undefined *)(puVar9 + 4) = 0;
    *(undefined *)(puVar9 + 6) = 0;
    puVar9[10] = uVar1;
    uVar2 = *(undefined4 *)arg_30h;
    uVar3 = *(undefined4 *)(arg_30h + 4);
    uVar4 = *(undefined4 *)(arg_30h + 8);
    uVar5 = *(undefined4 *)(arg_30h + 0xc);
    puVar9[0xd] = 0;
    puVar9[0xe] = 0;
    *(undefined4 *)(puVar9 + 0xb) = uVar2;
    *(undefined4 *)((int64_t)puVar9 + 0x5c) = uVar3;
    *(undefined4 *)(puVar9 + 0xc) = uVar4;
    *(undefined4 *)((int64_t)puVar9 + 100) = uVar5;
    return puVar9;
}

// ============================================================
// Function: FUN_1800f1670
// Address: 0x1800f1670
// Size: 160 bytes
// ============================================================
undefined8 * fcn.1800f1670(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    undefined8 *puVar8;
    undefined8 *puVar9;
    
    iVar7 = *(int64_t *)arg1;
    if (iVar7 != 0) {
        puVar9 = (undefined8 *)(*(int64_t *)(arg1 + 8) + 7 + iVar7 + 8 & 0xfffffffffffffff8);
        if (puVar9 + 5 <= (undefined8 *)(iVar7 + 0x2008U)) {
            iVar7 = (int64_t)puVar9 + (0x28 - (iVar7 + 8));
            goto code_r0x0001800f16de;
        }
    }
    puVar8 = (undefined8 *)func_0x000180459890(0x2008);
    *puVar8 = *(undefined8 *)arg1;
    puVar9 = puVar8 + 1;
    *(undefined8 **)arg1 = puVar8;
    iVar7 = 0x28;
code_r0x0001800f16de:
    *(int64_t *)(arg1 + 8) = iVar7;
    uVar6 = *(undefined4 *)0x180782ac0;
    uVar3 = *(undefined4 *)(arg4 + 4);
    uVar4 = *(undefined4 *)(arg4 + 8);
    uVar5 = *(undefined4 *)(arg4 + 0xc);
    uVar1 = *(undefined8 *)arg3;
    uVar2 = *(undefined8 *)arg2;
    *(undefined4 *)(puVar9 + 3) = *(undefined4 *)arg4;
    *(undefined4 *)((int64_t)puVar9 + 0x1c) = uVar3;
    *(undefined4 *)(puVar9 + 4) = uVar4;
    *(undefined4 *)((int64_t)puVar9 + 0x24) = uVar5;
    *(undefined4 *)puVar9 = uVar6;
    *(undefined8 *)((int64_t)puVar9 + 4) = uVar2;
    *(undefined8 *)((int64_t)puVar9 + 0xc) = uVar1;
    return puVar9;
}

