// Chunk 198 - 50 functions

// ============================================================
// Function: FUN_180266728
// Address: 0x180266728
// Size: 75 bytes
// ============================================================
undefined8 fcn.180266728(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t *unaff_RBX;
    uint8_t *unaff_RSI;
    uint8_t **unaff_RDI;
    
    piVar1 = (int64_t *)unaff_RBX[1];
    if (piVar1 != (int64_t *)0x0) {
        pcVar2 = *(code **)(*piVar1 + 0x60);
        if ((pcVar2 != (code *)0x0) || (pcVar2 = *(code **)(*piVar1 + 0x58), pcVar2 != (code *)0x0)) {
            (*pcVar2)(piVar1);
        }
        func_0x000180224b90(piVar1, 0x30, 0x1804e6f68, 0x300);
    }
    unaff_RBX[1] = (int64_t)unaff_RSI;
    if ((**unaff_RDI & 2) == 0) {
        iVar3 = func_0x000180255110(unaff_RBX[2], unaff_RDI[2]);
        if (iVar3 == 0) {
            return 0;
        }
        iVar3 = func_0x000180255110(unaff_RBX[3], unaff_RDI[3]);
        if (iVar3 == 0) {
            return 0;
        }
    }
    *(undefined4 *)((int64_t)unaff_RBX + 0x24) = *(undefined4 *)((int64_t)unaff_RDI + 0x24);
    *(undefined4 *)((int64_t)unaff_RBX + 0x2c) = *(undefined4 *)((int64_t)unaff_RDI + 0x2c);
    *(undefined4 *)(unaff_RBX + 5) = *(undefined4 *)(unaff_RDI + 5);
    if (unaff_RDI[6] == unaff_RSI) {
        func_0x000180224990(unaff_RBX[6], 0x1804e6f68, 0x105);
        unaff_RBX[6] = (int64_t)unaff_RSI;
    } else {
        func_0x000180224990(unaff_RBX[6], 0x1804e6f68, 0xfe);
        iVar3 = func_0x0001802248d0(unaff_RDI[7], 0x1804e6f68, 0xff);
        unaff_RBX[6] = iVar3;
        if ((iVar3 == 0) || (iVar3 = func_0x000180498030(iVar3, unaff_RDI[6], unaff_RDI[7]), iVar3 == 0)) {
            return 0;
        }
        unaff_RSI = unaff_RDI[7];
    }
    unaff_RBX[7] = (int64_t)unaff_RSI;
    // WARNING: Could not recover jumptable at 0x000180266846. Too many branches
    // WARNING: Treating indirect jump as call
    uVar4 = (**(code **)(*unaff_RBX + 0x20))();
    return uVar4;
}

// ============================================================
// Function: FUN_180266773
// Address: 0x180266773
// Size: 214 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_38h

undefined8 fcn.180266728(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t *unaff_RBX;
    uint8_t *unaff_RSI;
    uint8_t **unaff_RDI;
    
    piVar1 = (int64_t *)unaff_RBX[1];
    if (piVar1 != (int64_t *)0x0) {
        pcVar2 = *(code **)(*piVar1 + 0x60);
        if ((pcVar2 != (code *)0x0) || (pcVar2 = *(code **)(*piVar1 + 0x58), pcVar2 != (code *)0x0)) {
            (*pcVar2)(piVar1);
        }
        func_0x000180224b90(piVar1, 0x30, 0x1804e6f68, 0x300);
    }
    unaff_RBX[1] = (int64_t)unaff_RSI;
    if ((**unaff_RDI & 2) == 0) {
        iVar3 = func_0x000180255110(unaff_RBX[2], unaff_RDI[2]);
        if (iVar3 == 0) {
            return 0;
        }
        iVar3 = func_0x000180255110(unaff_RBX[3], unaff_RDI[3]);
        if (iVar3 == 0) {
            return 0;
        }
    }
    *(undefined4 *)((int64_t)unaff_RBX + 0x24) = *(undefined4 *)((int64_t)unaff_RDI + 0x24);
    *(undefined4 *)((int64_t)unaff_RBX + 0x2c) = *(undefined4 *)((int64_t)unaff_RDI + 0x2c);
    *(undefined4 *)(unaff_RBX + 5) = *(undefined4 *)(unaff_RDI + 5);
    if (unaff_RDI[6] == unaff_RSI) {
        func_0x000180224990(unaff_RBX[6], 0x1804e6f68, 0x105);
        unaff_RBX[6] = (int64_t)unaff_RSI;
    } else {
        func_0x000180224990(unaff_RBX[6], 0x1804e6f68, 0xfe);
        iVar3 = func_0x0001802248d0(unaff_RDI[7], 0x1804e6f68, 0xff);
        unaff_RBX[6] = iVar3;
        if ((iVar3 == 0) || (iVar3 = func_0x000180498030(iVar3, unaff_RDI[6], unaff_RDI[7]), iVar3 == 0)) {
            return 0;
        }
        unaff_RSI = unaff_RDI[7];
    }
    unaff_RBX[7] = (int64_t)unaff_RSI;
    // WARNING: Could not recover jumptable at 0x000180266846. Too many branches
    // WARNING: Treating indirect jump as call
    uVar4 = (**(code **)(*unaff_RBX + 0x20))();
    return uVar4;
}

// ============================================================
// Function: FUN_180266850
// Address: 0x180266850
// Size: 107 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180266850(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180266860;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180266881;
        iVar3 = fcn.180268ae0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180266894;
            iVar1 = fcn.180266590(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2));
            if (iVar1 != 0) {
                return iVar3;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802668a0;
            fcn.1802668c0(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1802668c0
// Address: 0x1802668c0
// Size: 29 bytes
// ============================================================
void fcn.1802668c0(int64_t arg1, int64_t arg_28h)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t *piVar3;
    int64_t iVar4;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1802668d4;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        iVar1 = *(int64_t *)arg1;
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
        pcVar2 = *(code **)(iVar1 + 0x10);
        if (pcVar2 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802668ed;
            (*pcVar2)();
        }
        if (*(int32_t *)(arg1 + 0x98) == 6) {
            iVar1 = *(int64_t *)(arg1 + 0xa0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180266902;
            func_0x0001802d7d60(iVar1);
        }
        iVar1 = *(int64_t *)(arg1 + 0x90);
        *(int64_t *)(arg1 + 0xa0) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180266919;
        fcn.1802cd2a0(iVar1);
        piVar3 = *(int64_t **)(arg1 + 8);
        if (piVar3 != (int64_t *)0x0) {
            pcVar2 = *(code **)(*piVar3 + 0x58);
            if (pcVar2 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180266933;
                (*pcVar2)(piVar3);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180266948;
            fcn.180224990(piVar3, 0x1804e6f68, 0x2f3);
        }
        iVar1 = *(int64_t *)(arg1 + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180266951;
        fcn.180255290(iVar1);
        iVar1 = *(int64_t *)(arg1 + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026695a;
        fcn.180255290(iVar1);
        iVar1 = *(int64_t *)(arg1 + 0x30);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180266970;
        fcn.180224990(iVar1, 0x1804e6f68, 0x88);
        iVar1 = *(int64_t *)(arg1 + 0xb0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180266989;
        fcn.180224990(iVar1, 0x1804e6f68, 0x89);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026699e;
        fcn.180224990(arg1, 0x1804e6f68, 0x8a);
    }
    return;
}

// ============================================================
// Function: FUN_1802668dd
// Address: 0x1802668dd
// Size: 203 bytes
// ============================================================
void fcn.1802668c0(int64_t arg1, int64_t arg_28h)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t *piVar3;
    int64_t iVar4;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1802668d4;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        iVar1 = *(int64_t *)arg1;
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
        pcVar2 = *(code **)(iVar1 + 0x10);
        if (pcVar2 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802668ed;
            (*pcVar2)();
        }
        if (*(int32_t *)(arg1 + 0x98) == 6) {
            iVar1 = *(int64_t *)(arg1 + 0xa0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180266902;
            func_0x0001802d7d60(iVar1);
        }
        iVar1 = *(int64_t *)(arg1 + 0x90);
        *(int64_t *)(arg1 + 0xa0) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180266919;
        fcn.1802cd2a0(iVar1);
        piVar3 = *(int64_t **)(arg1 + 8);
        if (piVar3 != (int64_t *)0x0) {
            pcVar2 = *(code **)(*piVar3 + 0x58);
            if (pcVar2 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180266933;
                (*pcVar2)(piVar3);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180266948;
            fcn.180224990(piVar3, 0x1804e6f68, 0x2f3);
        }
        iVar1 = *(int64_t *)(arg1 + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180266951;
        fcn.180255290(iVar1);
        iVar1 = *(int64_t *)(arg1 + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026695a;
        fcn.180255290(iVar1);
        iVar1 = *(int64_t *)(arg1 + 0x30);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180266970;
        fcn.180224990(iVar1, 0x1804e6f68, 0x88);
        iVar1 = *(int64_t *)(arg1 + 0xb0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180266989;
        fcn.180224990(iVar1, 0x1804e6f68, 0x89);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026699e;
        fcn.180224990(arg1, 0x1804e6f68, 0x8a);
    }
    return;
}

// ============================================================
// Function: FUN_1802669a8
// Address: 0x1802669a8
// Size: 1 bytes
// ============================================================
void fcn.1802668c0(int64_t arg1, int64_t arg_28h)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t *piVar3;
    int64_t iVar4;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1802668d4;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        iVar1 = *(int64_t *)arg1;
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
        pcVar2 = *(code **)(iVar1 + 0x10);
        if (pcVar2 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802668ed;
            (*pcVar2)();
        }
        if (*(int32_t *)(arg1 + 0x98) == 6) {
            iVar1 = *(int64_t *)(arg1 + 0xa0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180266902;
            func_0x0001802d7d60(iVar1);
        }
        iVar1 = *(int64_t *)(arg1 + 0x90);
        *(int64_t *)(arg1 + 0xa0) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180266919;
        fcn.1802cd2a0(iVar1);
        piVar3 = *(int64_t **)(arg1 + 8);
        if (piVar3 != (int64_t *)0x0) {
            pcVar2 = *(code **)(*piVar3 + 0x58);
            if (pcVar2 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180266933;
                (*pcVar2)(piVar3);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180266948;
            fcn.180224990(piVar3, 0x1804e6f68, 0x2f3);
        }
        iVar1 = *(int64_t *)(arg1 + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180266951;
        fcn.180255290(iVar1);
        iVar1 = *(int64_t *)(arg1 + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026695a;
        fcn.180255290(iVar1);
        iVar1 = *(int64_t *)(arg1 + 0x30);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180266970;
        fcn.180224990(iVar1, 0x1804e6f68, 0x88);
        iVar1 = *(int64_t *)(arg1 + 0xb0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180266989;
        fcn.180224990(iVar1, 0x1804e6f68, 0x89);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026699e;
        fcn.180224990(arg1, 0x1804e6f68, 0x8a);
    }
    return;
}

// ============================================================
// Function: FUN_180266a20
// Address: 0x180266a20
// Size: 75 bytes
// ============================================================
bool fcn.180266a20(int64_t param_1)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180266a2c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int64_t *)(param_1 + 0x18) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180266a46;
        iVar4 = fcn.180255110(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3));
        if (iVar4 != 0) {
            uVar1 = *(undefined8 *)(param_1 + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180266a54;
            iVar2 = fcn.1802553f0(uVar1);
            return iVar2 == 0;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_180266a70
// Address: 0x180266a70
// Size: 86 bytes
// ============================================================
undefined8 fcn.180266a70(int64_t *param_1)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x180266a7a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*(code **)(*param_1 + 0x30) == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180266a8e;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180266aa6;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180266ab8;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    // WARNING: Could not recover jumptable at 0x000180266ac3. Too many branches
    // WARNING: Treating indirect jump as call
    uVar2 = (**(code **)(*param_1 + 0x30))();
    return uVar2;
}

// ============================================================
// Function: FUN_180266ae0
// Address: 0x180266ae0
// Size: 86 bytes
// ============================================================
undefined8 fcn.180266ae0(int64_t *param_1)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x180266aea;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*(code **)(*param_1 + 0x38) == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180266afe;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180266b16;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180266b28;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    // WARNING: Could not recover jumptable at 0x000180266b33. Too many branches
    // WARNING: Treating indirect jump as call
    uVar2 = (**(code **)(*param_1 + 0x38))();
    return uVar2;
}

// ============================================================
// Function: FUN_180266b50
// Address: 0x180266b50
// Size: 71 bytes
// ============================================================
bool fcn.180266b50(int64_t param_1, undefined8 param_2)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180266b5c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int64_t *)(param_1 + 0x10) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180266b73;
        iVar3 = fcn.180255110(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar2));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180266b80;
            iVar1 = fcn.1802553f0(param_2);
            return iVar1 == 0;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_180266ba0
// Address: 0x180266ba0
// Size: 158 bytes
// ============================================================
undefined8 fcn.180266ba0(int64_t *param_1, int32_t *param_2, undefined4 *param_3, undefined4 *param_4)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x180266baa;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_1 != (int64_t *)0x0) {
        if ((((*(int32_t *)(*param_1 + 4) == 0x197) && (*(int32_t *)(param_1 + 9) != 0)) &&
            (*(int32_t *)((int64_t)param_1 + 0x4c) != 0)) &&
           (((*(int32_t *)(param_1 + 10) != 0 && (*(int32_t *)((int64_t)param_1 + 0x54) != 0)) &&
            (*(int32_t *)(param_1 + 0xb) == 0)))) {
            if (param_2 != (int32_t *)0x0) {
                *param_2 = *(int32_t *)((int64_t)param_1 + 0x54);
            }
            if (param_3 != (undefined4 *)0x0) {
                *param_3 = *(undefined4 *)(param_1 + 10);
            }
            if (param_4 != (undefined4 *)0x0) {
                *param_4 = *(undefined4 *)((int64_t)param_1 + 0x4c);
            }
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180266c0d;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180266c25;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180266c37;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
    }
    return 0;
}

// ============================================================
// Function: FUN_180266c40
// Address: 0x180266c40
// Size: 120 bytes
// ============================================================
undefined8 fcn.180266c40(int64_t *param_1, int32_t *param_2)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x180266c4a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_1 != (int64_t *)0x0) {
        if ((((*(int32_t *)(*param_1 + 4) == 0x197) && (*(int32_t *)(param_1 + 9) != 0)) &&
            (*(int32_t *)((int64_t)param_1 + 0x4c) != 0)) && (*(int32_t *)(param_1 + 10) == 0)) {
            if (param_2 != (int32_t *)0x0) {
                *param_2 = *(int32_t *)((int64_t)param_1 + 0x4c);
            }
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180266c87;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180266c9f;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180266cb1;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
    }
    return 0;
}

// ============================================================
// Function: FUN_180266cc0
// Address: 0x180266cc0
// Size: 2633 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t * fcn.180266cc0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg_88h)
{
    undefined8 uVar1;
    code *pcVar2;
    bool bVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t *piVar11;
    int64_t *arg1;
    int64_t *piVar12;
    int64_t *piVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    var_40h = 0x180266ce7;
    var_10h = arg2;
    var_18h = arg3;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    piVar8 = (int64_t *)0x0;
    var_68h._0_4_ = -1;
    var_48h = 0;
    var_88h = 0;
    bVar3 = false;
    var_20h = (uint64_t)var_20h._4_4_ << 0x20;
    *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266d18;
    iVar7 = func_0x00018022ae60();
    if (iVar7 != 0) {
        var_70h = (uint64_t)var_70h._4_4_ << 0x20;
        var_88h = 0;
        if (*(int32_t *)(iVar7 + 8) == 4) {
            var_88h = *(int64_t *)(iVar7 + 0x10);
            uVar4 = (uint32_t)(var_88h != 0);
        } else {
            if (*(int32_t *)(iVar7 + 8) != 6) {
                return (int64_t *)0x0;
            }
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266d46;
            uVar4 = func_0x00018022ab70(iVar7, &var_88h);
        }
        if (uVar4 == 0) {
            return (int64_t *)0x0;
        }
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266d6a;
        iVar5 = func_0x0001802d5350(var_88h);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266d73;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                         );
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266d8b;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6));
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266d9d;
            fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
            return (int64_t *)0x0;
        }
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266db2;
        piVar8 = (int64_t *)func_0x0001802d56c0(arg2, arg3, iVar5);
        if (piVar8 == (int64_t *)0x0) {
            return (int64_t *)0x0;
        }
        var_80h = CONCAT44(var_80h._4_4_, 0xffffffff);
        var_20h = CONCAT44(var_20h._4_4_, 0xffffffff);
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266ddb;
        iVar7 = func_0x00018022ae60(placeholder_0, 0x1804e1ef8);
        if (iVar7 == 0) {
code_r0x000180266e04:
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266e13;
            iVar7 = func_0x00018022ae60(placeholder_0, 0x1804e71b8);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266e24;
                iVar5 = func_0x0001802a47e0(iVar7, &var_80h);
                if (iVar5 == 0) goto code_r0x000180266e77;
                *(undefined4 *)((int64_t)piVar8 + 0x24) = (undefined4)var_80h;
            }
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266e4b;
            iVar7 = func_0x00018022ae60(placeholder_0, 0x1804b4b7c);
            if (iVar7 == 0) {
code_r0x000180266eb9:
                *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266ec8;
                iVar7 = func_0x00018022ae60(placeholder_0, 0x1804e49d0);
                if (iVar7 == 0) {
code_r0x000180266f09:
                    *(uint32_t *)(piVar8 + 5) = (uint32_t)(0 < (int32_t)var_70h);
                    return piVar8;
                }
                *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266ed9;
                iVar5 = func_0x000180229fc0(iVar7, &var_70h);
                if (iVar5 != 0) goto code_r0x000180266f09;
                *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266ee2;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266efa;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6));
                goto code_r0x000180266ea5;
            }
            if (*(int32_t *)(iVar7 + 8) == 5) {
                uVar10 = *(undefined8 *)(iVar7 + 0x18);
                uVar1 = *(undefined8 *)(iVar7 + 0x10);
                *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266e66;
                iVar7 = func_0x000180267b90(piVar8, uVar1, uVar10);
                if (iVar7 != 0) goto code_r0x000180266eb9;
            }
        } else {
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266dec;
            iVar5 = func_0x0001802a56c0(iVar7, &var_20h);
            if (iVar5 != 0) {
                *(int32_t *)((int64_t)piVar8 + 0x2c) = (int32_t)var_20h;
                goto code_r0x000180266e04;
            }
        }
code_r0x000180266e77:
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266e8f;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266e9d;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6));
code_r0x000180266ea5:
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266eaa;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266eb2;
        fcn.1802668c0((int64_t)piVar8, *(int64_t *)(&stack0xffffffffffffffe8 + iVar6));
        return (int64_t *)0x0;
    }
    *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266f22;
    iVar7 = func_0x0001802d4790(arg2);
    var_70h = iVar7;
    if (iVar7 == 0) {
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266f33;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266f4b;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6));
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266f5d;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
        return (int64_t *)0x0;
    }
    *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266f6c;
    func_0x0001802d48b0(iVar7);
    *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266f74;
    var_78h = func_0x0001802d4590(iVar7);
    *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266f80;
    var_50h = func_0x0001802d4590(iVar7);
    *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266f8c;
    var_58h = func_0x0001802d4590(iVar7);
    *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266f98;
    var_60h = func_0x0001802d4590(iVar7);
    piVar12 = piVar8;
    piVar11 = piVar8;
    if (var_60h == 0) {
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266fa6;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266fc1;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6));
code_r0x00018026769b:
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802676a3;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
code_r0x0001802676a3:
        piVar13 = (int64_t *)var_88h;
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802676af;
        fcn.1802668c0((int64_t)piVar11, *(int64_t *)(&stack0xffffffffffffffe8 + iVar6));
        piVar12 = piVar8;
        if (piVar13 == (int64_t *)0x0) goto code_r0x0001802676d9;
    } else {
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180266fda;
        iVar9 = func_0x00018022ae60(placeholder_0, 0x1804e1f30);
        if ((iVar9 == 0) || (*(int32_t *)(iVar9 + 8) != 4)) {
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267676;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                         );
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267691;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6));
            goto code_r0x00018026769b;
        }
        uVar10 = *(undefined8 *)(iVar9 + 0x10);
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267000;
        iVar5 = func_0x000180223670(uVar10, 0x1804d87d8);
        if (iVar5 == 0) {
            bVar3 = true;
        } else {
            uVar10 = *(undefined8 *)(iVar9 + 0x10);
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x18026701c;
            iVar5 = func_0x000180223670(uVar10, 0x1804d87e8);
            if (iVar5 != 0) {
                *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x18026764f;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x18026766a;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6));
                goto code_r0x00018026769b;
            }
        }
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267036;
        uVar10 = func_0x00018022ae60(placeholder_0, 0x1804a59f0);
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267042;
        iVar5 = func_0x000180229ec0(uVar10, &var_50h);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x18026704b;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                         );
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267066;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6));
            goto code_r0x00018026769b;
        }
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x18026707f;
        uVar10 = func_0x00018022ae60(placeholder_0, 0x1804e3dc4);
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x18026708b;
        iVar5 = func_0x000180229ec0(uVar10, &var_58h);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267094;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                         );
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802670af;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6));
            goto code_r0x00018026769b;
        }
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802670c8;
        uVar10 = func_0x00018022ae60(placeholder_0, 0x1804af230);
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802670d4;
        iVar5 = func_0x000180229ec0(uVar10, &var_78h);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802670dd;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                         );
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802670f8;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6));
            goto code_r0x00018026769b;
        }
        if (bVar3) {
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267120;
            iVar5 = func_0x000180255370();
            piVar11 = (int64_t *)0x0;
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267131;
                iVar5 = fcn.1802553f0(var_78h);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x18026713e;
                    iVar5 = func_0x000180255500(var_78h);
                    var_20h = CONCAT44(var_20h._4_4_, iVar5);
                    if (iVar5 < 0x296) {
                        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267181;
                        piVar11 = (int64_t *)func_0x0001802d5560(var_78h, var_50h, var_58h, iVar7);
                        goto code_r0x000180267184;
                    }
                    *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x18026714d;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                    *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267161;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6)
                                  , *(int64_t *)((int64_t)&var_18h + iVar6));
                    goto code_r0x00018026769b;
                }
            }
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802671b7;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                         );
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802671cb;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6));
            goto code_r0x00018026769b;
        }
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802671e7;
        piVar11 = (int64_t *)func_0x0001802d54c0(var_78h, var_50h, var_58h, 0);
        if (piVar11 == (int64_t *)0x0) {
code_r0x000180267184:
            if (piVar11 == (int64_t *)0x0) {
                *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267192;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802671a6;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6));
                goto code_r0x00018026769b;
            }
        } else {
            pcVar2 = *(code **)(*piVar11 + 0x38);
            if (pcVar2 == (code *)0x0) {
                *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267200;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267214;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6));
                *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267223;
                fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
                var_20h = var_20h & 0xffffffff00000000;
            } else {
                *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x18026726b;
                iVar5 = (*pcVar2)(piVar11);
                var_20h = CONCAT44(var_20h._4_4_, iVar5);
                if (0x295 < iVar5) {
                    *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x18026727a;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                    *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x18026728e;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6)
                                  , *(int64_t *)((int64_t)&var_18h + iVar6));
                    goto code_r0x00018026769b;
                }
            }
        }
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267236;
        iVar9 = func_0x00018022ae60(placeholder_0, 0x1804b4b7c);
        if (iVar9 != 0) {
            if (*(int32_t *)(iVar9 + 8) != 5) {
                *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267246;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x18026725a;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6));
                goto code_r0x00018026769b;
            }
            uVar10 = *(undefined8 *)(iVar9 + 0x18);
            uVar1 = *(undefined8 *)(iVar9 + 0x10);
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802672aa;
            iVar9 = func_0x000180267b90(piVar11, uVar1, uVar10);
            if (iVar9 != 0) goto code_r0x0001802672b3;
            goto code_r0x0001802676a3;
        }
code_r0x0001802672b3:
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802672c2;
        var_40h = func_0x00018022ae60(placeholder_0, 0x1804e71e8);
        if ((var_40h == 0) || (*(int32_t *)(var_40h + 8) != 5)) {
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x18026762d;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                         );
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267641;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6));
            goto code_r0x00018026769b;
        }
        var_80h = *(int64_t *)(var_40h + 0x10);
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802672e9;
        iVar9 = fcn.1802685b0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6));
        var_88h = iVar9;
        if (iVar9 == 0) goto code_r0x0001802676a3;
        *(int64_t *)(&stack0xffffffffffffffe8 + iVar6) = iVar7;
        *(uint32_t *)((int64_t)piVar11 + 0x2c) = *(uint8_t *)var_80h & 0xfffffffe;
        uVar10 = *(undefined8 *)(var_40h + 0x18);
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267321;
        iVar5 = func_0x0001802d5ee0(piVar11, iVar9, var_80h, uVar10);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x18026732a;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                         );
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x18026733e;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6));
            goto code_r0x00018026769b;
        }
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267359;
        uVar10 = func_0x00018022ae60(placeholder_0, 0x1804e71f4);
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267365;
        iVar5 = func_0x000180229ec0(uVar10, &var_60h);
        if (iVar5 == 0) {
code_r0x000180267606:
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x18026760b;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                         );
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x18026761f;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6));
            goto code_r0x00018026769b;
        }
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267376;
        iVar5 = func_0x000180255370(var_60h);
        if (iVar5 != 0) goto code_r0x000180267606;
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267387;
        iVar5 = fcn.1802553f0(var_60h);
        if (iVar5 != 0) goto code_r0x000180267606;
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267398;
        iVar5 = func_0x000180255500(var_60h);
        if ((int32_t)var_20h + 1 < iVar5) goto code_r0x000180267606;
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802673b4;
        var_20h = func_0x00018022ae60(placeholder_0, 0x1804e7200);
        if (var_20h != 0) {
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802673c5;
            var_48h = func_0x0001802d4590(iVar7);
            if (var_48h != 0) {
                *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802673db;
                iVar5 = func_0x000180229ec0(var_20h, &var_48h);
                if (iVar5 != 0) goto code_r0x000180267404;
            }
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802673e4;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                         );
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802673f8;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6));
            goto code_r0x00018026769b;
        }
code_r0x000180267404:
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267417;
        iVar5 = func_0x0001802677a0(piVar11, iVar9, var_60h, var_48h);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267420;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                         );
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267434;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6));
            goto code_r0x00018026769b;
        }
        var_40h = piVar11[1];
        var_20h = piVar11[2];
        var_80h = piVar11[6];
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267471;
        arg1 = (int64_t *)
               fcn.180268ae0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                             *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                             *(int64_t *)(&stack0xfffffffffffffff8 + iVar6));
        piVar13 = piVar8;
        if (arg1 == (int64_t *)0x0) {
code_r0x000180267493:
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x18026749b;
            fcn.1802668c0((int64_t)piVar13, *(int64_t *)(&stack0xffffffffffffffe8 + iVar6));
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802674a3;
            fcn.1802668c0((int64_t)piVar12, *(int64_t *)(&stack0xffffffffffffffe8 + iVar6));
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802674a8;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                         );
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802674bc;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6));
            goto code_r0x00018026769b;
        }
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267484;
        iVar5 = fcn.180266590(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar6));
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267490;
            fcn.1802668c0((int64_t)arg1, *(int64_t *)(&stack0xffffffffffffffe8 + iVar6));
            goto code_r0x000180267493;
        }
        iVar7 = arg1[6];
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802674db;
        fcn.180224990(iVar7, 0x1804e6f68, 0x214);
        iVar7 = var_40h;
        arg1[6] = 0;
        arg1[7] = 0;
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802674f8;
        iVar5 = func_0x0001802677a0(arg1, iVar7, var_20h, 0);
        piVar13 = arg1;
        if (iVar5 == 0) goto code_r0x000180267493;
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267508;
        iVar5 = func_0x0001802d5c30(arg1, var_70h);
        piVar12 = piVar11;
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x18026751c;
            piVar12 = (int64_t *)func_0x0001802d56c0(var_10h, var_18h, iVar5);
            if (piVar12 == (int64_t *)0x0) goto code_r0x000180267493;
            *(undefined4 *)((int64_t)piVar12 + 0x24) = 0;
            if (var_80h == 0) {
                iVar7 = piVar12[6];
                *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267544;
                fcn.180224990(iVar7, 0x1804e6f68, 0x214);
                piVar12[6] = 0;
                piVar12[7] = 0;
            }
        }
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267559;
        fcn.1802668c0((int64_t)arg1, *(int64_t *)(&stack0xffffffffffffffe8 + iVar6));
        if (piVar12 == piVar11) {
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267571;
            iVar7 = func_0x00018022ae60(placeholder_0, 0x1804e71b8);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x180267582;
                iVar5 = func_0x0001802a47e0(iVar7, &var_68h);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x18026758b;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                    *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x18026759f;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6)
                                  , *(int64_t *)((int64_t)&var_18h + iVar6));
                    goto code_r0x00018026769b;
                }
            }
            if ((int32_t)var_68h == 1) {
                *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802675b6;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802675ca;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6));
                goto code_r0x00018026769b;
            }
            *(undefined4 *)((int64_t)piVar11 + 0x24) = 0;
            *(undefined4 *)(piVar11 + 5) = 1;
            piVar12 = piVar11;
            piVar13 = (int64_t *)var_88h;
        } else {
            *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802675f2;
            fcn.1802668c0((int64_t)piVar11, *(int64_t *)(&stack0xffffffffffffffe8 + iVar6));
            *(undefined4 *)(piVar12 + 5) = 1;
            piVar13 = (int64_t *)var_88h;
        }
    }
    pcVar2 = *(code **)(*piVar13 + 0x58);
    if (pcVar2 != (code *)0x0) {
        *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802676c8;
        (*pcVar2)(piVar13);
    }
    *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802676d9;
    fcn.180224990(piVar13, 0x1804e6f68, 0x2f3);
code_r0x0001802676d9:
    *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802676e2;
    func_0x0001802d4450(var_70h);
    *(undefined8 *)((int64_t)&var_40h + iVar6) = 0x1802676eb;
    func_0x0001802d44d0(var_70h);
    return piVar12;
}

// ============================================================
// Function: FUN_180267710
// Address: 0x180267710
// Size: 27 bytes
// ============================================================
void fcn.180267710(int64_t *param_1)
{
    fcn.18045a350();
    // WARNING: Could not recover jumptable at 0x000180267728. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)(*param_1 + 0x40))();
    return;
}

// ============================================================
// Function: FUN_180267730
// Address: 0x180267730
// Size: 86 bytes
// ============================================================
undefined8 fcn.180267730(int64_t *param_1)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026773a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*(code **)(*param_1 + 0x28) == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18026774e;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180267766;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180267778;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    // WARNING: Could not recover jumptable at 0x000180267783. Too many branches
    // WARNING: Treating indirect jump as call
    uVar2 = (**(code **)(*param_1 + 0x28))();
    return uVar2;
}

// ============================================================
// Function: FUN_1802677a0
// Address: 0x1802677a0
// Size: 144 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1802677a0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 uVar8;
    int64_t in_R8;
    int64_t in_R9;
    bool bVar9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802677bb;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802677d4;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802677ec;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802677fe;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    if (in_RCX[8] == 0) {
code_r0x000180267b4e:
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b53;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b6b;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b7d;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267817;
    iVar2 = fcn.1802553f0();
    if (iVar2 != 0) goto code_r0x000180267b4e;
    iVar5 = in_RCX[8];
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267828;
    iVar2 = func_0x000180255370(iVar5);
    if (iVar2 != 0) goto code_r0x000180267b4e;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
    if (in_R8 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267846;
        iVar2 = fcn.1802553f0(in_R8);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267856;
            iVar2 = func_0x000180255370(in_R8);
            if (iVar2 == 0) {
                iVar5 = in_RCX[8];
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267867;
                iVar2 = func_0x000180255500(iVar5);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267872;
                iVar3 = func_0x000180255500(in_R8);
                if (iVar3 <= iVar2 + 1) {
                    if (in_R9 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267887;
                        iVar2 = func_0x000180255370(in_R9);
                        if (iVar2 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267890;
                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4));
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802678a8;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_48h + iVar4));
                            goto code_r0x0001802678b0;
                        }
                    }
                    iVar5 = in_RCX[1];
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802678e8;
                        iVar5 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar4));
                        in_RCX[1] = iVar5;
                        if (iVar5 == 0) {
                            return 0;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802678fc;
                    iVar2 = fcn.180267e30(iVar5, in_RDX);
                    if (iVar2 == 0) {
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026790c;
                    iVar5 = fcn.180255110(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)(&stack0x00000028 + iVar4), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar4));
                    if (iVar5 == 0) {
                        return 0;
                    }
                    if (in_R9 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026791e;
                        iVar2 = fcn.1802553f0(in_R9);
                        if (iVar2 == 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026792e;
                            iVar5 = fcn.180255110(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                                  *(int64_t *)(&stack0x00000028 + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_50h + iVar4));
                            if (iVar5 == 0) {
                                return 0;
                            }
                            goto code_r0x000180267a53;
                        }
                    }
                    iVar5 = in_RCX[8];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267942;
                    iVar2 = func_0x000180255500(iVar5);
                    iVar5 = in_RCX[2];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267955;
                    iVar3 = func_0x000180255500(iVar5);
                    if ((iVar2 + 1) / 2 + 3 < iVar3) {
                        iVar5 = in_RCX[0x15];
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267973;
                        iVar5 = func_0x0001802d4790(iVar5);
                        if (iVar5 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267987;
                            func_0x0001802d48b0(iVar5);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026798f;
                            iVar7 = func_0x0001802d4590(iVar5);
                            if (iVar7 != 0) {
                                if (*(int32_t *)(*in_RCX + 4) == 0x197) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679af;
                                    func_0x000180255b00(iVar7);
                                    iVar6 = in_RCX[8];
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679b8;
                                    iVar2 = func_0x000180255500(iVar6);
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679c3;
                                    iVar2 = func_0x000180255780(iVar7, iVar2 + -1);
                                    bVar9 = iVar2 == 0;
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679d0;
                                    iVar6 = fcn.180255110(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                                          *(int64_t *)(&stack0x00000028 + iVar4), 
                                                          *(int64_t *)((int64_t)&arg_50h + iVar4));
                                    bVar9 = iVar6 == 0;
                                }
                                if (!bVar9) {
                                    iVar6 = in_RCX[2];
                                    iVar1 = in_RCX[3];
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679e6;
                                    iVar2 = func_0x000180297880(iVar1, iVar6);
                                    if (iVar2 != 0) {
                                        iVar6 = in_RCX[3];
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679fd;
                                        iVar2 = func_0x0001802d49d0(iVar6, iVar6, iVar7);
                                        if (iVar2 != 0) {
                                            iVar7 = in_RCX[3];
                                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a0e;
                                            uVar8 = func_0x000180255ab0();
                                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a1c;
                                            iVar2 = func_0x0001802d49d0(iVar7, iVar7, uVar8);
                                            if (iVar2 != 0) {
                                                iVar7 = in_RCX[3];
                                                iVar6 = in_RCX[2];
                                                *(int64_t *)((int64_t)&var_18h + iVar4) = iVar5;
                                                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a3b;
                                                iVar2 = func_0x0001802d4d00(iVar7, 0, iVar7, iVar6);
                                                if (iVar2 != 0) {
                                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a4b;
                                                    func_0x0001802d4450(iVar5);
                                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a53;
                                                    func_0x0001802d44d0(iVar5);
                                                    goto code_r0x000180267a53;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b0e;
                            func_0x0001802d4450(iVar5);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b16;
                            func_0x0001802d44d0(iVar5);
                        }
                        iVar5 = in_RCX[3];
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b1f;
                        func_0x000180255b00(iVar5);
                        return 0;
                    }
                    iVar5 = in_RCX[3];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267962;
                    func_0x000180255b00(iVar5);
code_r0x000180267a53:
                    iVar5 = in_RCX[2];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a5c;
                    iVar2 = func_0x000180255380(iVar5);
                    if (iVar2 == 0) {
                        iVar5 = in_RCX[0x12];
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267af3;
                        fcn.1802cd2a0(iVar5);
                        in_RCX[0x12] = 0;
                        return 1;
                    }
                    iVar5 = in_RCX[0x15];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a70;
                    iVar7 = func_0x0001802d4790(iVar5);
                    iVar5 = in_RCX[0x12];
                    uVar8 = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a81;
                    fcn.1802cd2a0(iVar5);
                    in_RCX[0x12] = 0;
                    if (iVar7 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a92;
                        iVar5 = fcn.1802cd2f0();
                        in_RCX[0x12] = iVar5;
                        if (iVar5 != 0) {
                            iVar6 = in_RCX[2];
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267aad;
                            iVar2 = func_0x0001802cd370(iVar5, iVar6, iVar7);
                            if (iVar2 == 0) {
                                iVar5 = in_RCX[0x12];
                                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267abd;
                                fcn.1802cd2a0(iVar5);
                                in_RCX[0x12] = 0;
                                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267acc;
                                func_0x0001802d44d0(iVar7);
                                return 0;
                            }
                            uVar8 = 1;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267ae0;
                    func_0x0001802d44d0(iVar7);
                    return uVar8;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b29;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b41;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                  *(int64_t *)((int64_t)&arg_48h + iVar4));
code_r0x0001802678b0:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802678ba;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_180267830
// Address: 0x180267830
// Size: 145 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1802677a0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 uVar8;
    int64_t in_R8;
    int64_t in_R9;
    bool bVar9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802677bb;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802677d4;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802677ec;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802677fe;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    if (in_RCX[8] == 0) {
code_r0x000180267b4e:
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b53;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b6b;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b7d;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267817;
    iVar2 = fcn.1802553f0();
    if (iVar2 != 0) goto code_r0x000180267b4e;
    iVar5 = in_RCX[8];
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267828;
    iVar2 = func_0x000180255370(iVar5);
    if (iVar2 != 0) goto code_r0x000180267b4e;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
    if (in_R8 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267846;
        iVar2 = fcn.1802553f0(in_R8);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267856;
            iVar2 = func_0x000180255370(in_R8);
            if (iVar2 == 0) {
                iVar5 = in_RCX[8];
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267867;
                iVar2 = func_0x000180255500(iVar5);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267872;
                iVar3 = func_0x000180255500(in_R8);
                if (iVar3 <= iVar2 + 1) {
                    if (in_R9 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267887;
                        iVar2 = func_0x000180255370(in_R9);
                        if (iVar2 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267890;
                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4));
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802678a8;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_48h + iVar4));
                            goto code_r0x0001802678b0;
                        }
                    }
                    iVar5 = in_RCX[1];
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802678e8;
                        iVar5 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar4));
                        in_RCX[1] = iVar5;
                        if (iVar5 == 0) {
                            return 0;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802678fc;
                    iVar2 = fcn.180267e30(iVar5, in_RDX);
                    if (iVar2 == 0) {
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026790c;
                    iVar5 = fcn.180255110(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)(&stack0x00000028 + iVar4), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar4));
                    if (iVar5 == 0) {
                        return 0;
                    }
                    if (in_R9 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026791e;
                        iVar2 = fcn.1802553f0(in_R9);
                        if (iVar2 == 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026792e;
                            iVar5 = fcn.180255110(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                                  *(int64_t *)(&stack0x00000028 + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_50h + iVar4));
                            if (iVar5 == 0) {
                                return 0;
                            }
                            goto code_r0x000180267a53;
                        }
                    }
                    iVar5 = in_RCX[8];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267942;
                    iVar2 = func_0x000180255500(iVar5);
                    iVar5 = in_RCX[2];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267955;
                    iVar3 = func_0x000180255500(iVar5);
                    if ((iVar2 + 1) / 2 + 3 < iVar3) {
                        iVar5 = in_RCX[0x15];
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267973;
                        iVar5 = func_0x0001802d4790(iVar5);
                        if (iVar5 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267987;
                            func_0x0001802d48b0(iVar5);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026798f;
                            iVar7 = func_0x0001802d4590(iVar5);
                            if (iVar7 != 0) {
                                if (*(int32_t *)(*in_RCX + 4) == 0x197) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679af;
                                    func_0x000180255b00(iVar7);
                                    iVar6 = in_RCX[8];
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679b8;
                                    iVar2 = func_0x000180255500(iVar6);
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679c3;
                                    iVar2 = func_0x000180255780(iVar7, iVar2 + -1);
                                    bVar9 = iVar2 == 0;
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679d0;
                                    iVar6 = fcn.180255110(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                                          *(int64_t *)(&stack0x00000028 + iVar4), 
                                                          *(int64_t *)((int64_t)&arg_50h + iVar4));
                                    bVar9 = iVar6 == 0;
                                }
                                if (!bVar9) {
                                    iVar6 = in_RCX[2];
                                    iVar1 = in_RCX[3];
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679e6;
                                    iVar2 = func_0x000180297880(iVar1, iVar6);
                                    if (iVar2 != 0) {
                                        iVar6 = in_RCX[3];
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679fd;
                                        iVar2 = func_0x0001802d49d0(iVar6, iVar6, iVar7);
                                        if (iVar2 != 0) {
                                            iVar7 = in_RCX[3];
                                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a0e;
                                            uVar8 = func_0x000180255ab0();
                                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a1c;
                                            iVar2 = func_0x0001802d49d0(iVar7, iVar7, uVar8);
                                            if (iVar2 != 0) {
                                                iVar7 = in_RCX[3];
                                                iVar6 = in_RCX[2];
                                                *(int64_t *)((int64_t)&var_18h + iVar4) = iVar5;
                                                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a3b;
                                                iVar2 = func_0x0001802d4d00(iVar7, 0, iVar7, iVar6);
                                                if (iVar2 != 0) {
                                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a4b;
                                                    func_0x0001802d4450(iVar5);
                                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a53;
                                                    func_0x0001802d44d0(iVar5);
                                                    goto code_r0x000180267a53;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b0e;
                            func_0x0001802d4450(iVar5);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b16;
                            func_0x0001802d44d0(iVar5);
                        }
                        iVar5 = in_RCX[3];
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b1f;
                        func_0x000180255b00(iVar5);
                        return 0;
                    }
                    iVar5 = in_RCX[3];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267962;
                    func_0x000180255b00(iVar5);
code_r0x000180267a53:
                    iVar5 = in_RCX[2];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a5c;
                    iVar2 = func_0x000180255380(iVar5);
                    if (iVar2 == 0) {
                        iVar5 = in_RCX[0x12];
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267af3;
                        fcn.1802cd2a0(iVar5);
                        in_RCX[0x12] = 0;
                        return 1;
                    }
                    iVar5 = in_RCX[0x15];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a70;
                    iVar7 = func_0x0001802d4790(iVar5);
                    iVar5 = in_RCX[0x12];
                    uVar8 = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a81;
                    fcn.1802cd2a0(iVar5);
                    in_RCX[0x12] = 0;
                    if (iVar7 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a92;
                        iVar5 = fcn.1802cd2f0();
                        in_RCX[0x12] = iVar5;
                        if (iVar5 != 0) {
                            iVar6 = in_RCX[2];
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267aad;
                            iVar2 = func_0x0001802cd370(iVar5, iVar6, iVar7);
                            if (iVar2 == 0) {
                                iVar5 = in_RCX[0x12];
                                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267abd;
                                fcn.1802cd2a0(iVar5);
                                in_RCX[0x12] = 0;
                                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267acc;
                                func_0x0001802d44d0(iVar7);
                                return 0;
                            }
                            uVar8 = 1;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267ae0;
                    func_0x0001802d44d0(iVar7);
                    return uVar8;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b29;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b41;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                  *(int64_t *)((int64_t)&arg_48h + iVar4));
code_r0x0001802678b0:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802678ba;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_1802678c1
// Address: 0x1802678c1
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1802677a0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 uVar8;
    int64_t in_R8;
    int64_t in_R9;
    bool bVar9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802677bb;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802677d4;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802677ec;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802677fe;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    if (in_RCX[8] == 0) {
code_r0x000180267b4e:
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b53;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b6b;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b7d;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267817;
    iVar2 = fcn.1802553f0();
    if (iVar2 != 0) goto code_r0x000180267b4e;
    iVar5 = in_RCX[8];
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267828;
    iVar2 = func_0x000180255370(iVar5);
    if (iVar2 != 0) goto code_r0x000180267b4e;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
    if (in_R8 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267846;
        iVar2 = fcn.1802553f0(in_R8);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267856;
            iVar2 = func_0x000180255370(in_R8);
            if (iVar2 == 0) {
                iVar5 = in_RCX[8];
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267867;
                iVar2 = func_0x000180255500(iVar5);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267872;
                iVar3 = func_0x000180255500(in_R8);
                if (iVar3 <= iVar2 + 1) {
                    if (in_R9 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267887;
                        iVar2 = func_0x000180255370(in_R9);
                        if (iVar2 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267890;
                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4));
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802678a8;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_48h + iVar4));
                            goto code_r0x0001802678b0;
                        }
                    }
                    iVar5 = in_RCX[1];
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802678e8;
                        iVar5 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar4));
                        in_RCX[1] = iVar5;
                        if (iVar5 == 0) {
                            return 0;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802678fc;
                    iVar2 = fcn.180267e30(iVar5, in_RDX);
                    if (iVar2 == 0) {
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026790c;
                    iVar5 = fcn.180255110(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)(&stack0x00000028 + iVar4), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar4));
                    if (iVar5 == 0) {
                        return 0;
                    }
                    if (in_R9 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026791e;
                        iVar2 = fcn.1802553f0(in_R9);
                        if (iVar2 == 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026792e;
                            iVar5 = fcn.180255110(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                                  *(int64_t *)(&stack0x00000028 + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_50h + iVar4));
                            if (iVar5 == 0) {
                                return 0;
                            }
                            goto code_r0x000180267a53;
                        }
                    }
                    iVar5 = in_RCX[8];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267942;
                    iVar2 = func_0x000180255500(iVar5);
                    iVar5 = in_RCX[2];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267955;
                    iVar3 = func_0x000180255500(iVar5);
                    if ((iVar2 + 1) / 2 + 3 < iVar3) {
                        iVar5 = in_RCX[0x15];
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267973;
                        iVar5 = func_0x0001802d4790(iVar5);
                        if (iVar5 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267987;
                            func_0x0001802d48b0(iVar5);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026798f;
                            iVar7 = func_0x0001802d4590(iVar5);
                            if (iVar7 != 0) {
                                if (*(int32_t *)(*in_RCX + 4) == 0x197) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679af;
                                    func_0x000180255b00(iVar7);
                                    iVar6 = in_RCX[8];
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679b8;
                                    iVar2 = func_0x000180255500(iVar6);
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679c3;
                                    iVar2 = func_0x000180255780(iVar7, iVar2 + -1);
                                    bVar9 = iVar2 == 0;
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679d0;
                                    iVar6 = fcn.180255110(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                                          *(int64_t *)(&stack0x00000028 + iVar4), 
                                                          *(int64_t *)((int64_t)&arg_50h + iVar4));
                                    bVar9 = iVar6 == 0;
                                }
                                if (!bVar9) {
                                    iVar6 = in_RCX[2];
                                    iVar1 = in_RCX[3];
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679e6;
                                    iVar2 = func_0x000180297880(iVar1, iVar6);
                                    if (iVar2 != 0) {
                                        iVar6 = in_RCX[3];
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679fd;
                                        iVar2 = func_0x0001802d49d0(iVar6, iVar6, iVar7);
                                        if (iVar2 != 0) {
                                            iVar7 = in_RCX[3];
                                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a0e;
                                            uVar8 = func_0x000180255ab0();
                                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a1c;
                                            iVar2 = func_0x0001802d49d0(iVar7, iVar7, uVar8);
                                            if (iVar2 != 0) {
                                                iVar7 = in_RCX[3];
                                                iVar6 = in_RCX[2];
                                                *(int64_t *)((int64_t)&var_18h + iVar4) = iVar5;
                                                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a3b;
                                                iVar2 = func_0x0001802d4d00(iVar7, 0, iVar7, iVar6);
                                                if (iVar2 != 0) {
                                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a4b;
                                                    func_0x0001802d4450(iVar5);
                                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a53;
                                                    func_0x0001802d44d0(iVar5);
                                                    goto code_r0x000180267a53;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b0e;
                            func_0x0001802d4450(iVar5);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b16;
                            func_0x0001802d44d0(iVar5);
                        }
                        iVar5 = in_RCX[3];
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b1f;
                        func_0x000180255b00(iVar5);
                        return 0;
                    }
                    iVar5 = in_RCX[3];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267962;
                    func_0x000180255b00(iVar5);
code_r0x000180267a53:
                    iVar5 = in_RCX[2];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a5c;
                    iVar2 = func_0x000180255380(iVar5);
                    if (iVar2 == 0) {
                        iVar5 = in_RCX[0x12];
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267af3;
                        fcn.1802cd2a0(iVar5);
                        in_RCX[0x12] = 0;
                        return 1;
                    }
                    iVar5 = in_RCX[0x15];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a70;
                    iVar7 = func_0x0001802d4790(iVar5);
                    iVar5 = in_RCX[0x12];
                    uVar8 = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a81;
                    fcn.1802cd2a0(iVar5);
                    in_RCX[0x12] = 0;
                    if (iVar7 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a92;
                        iVar5 = fcn.1802cd2f0();
                        in_RCX[0x12] = iVar5;
                        if (iVar5 != 0) {
                            iVar6 = in_RCX[2];
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267aad;
                            iVar2 = func_0x0001802cd370(iVar5, iVar6, iVar7);
                            if (iVar2 == 0) {
                                iVar5 = in_RCX[0x12];
                                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267abd;
                                fcn.1802cd2a0(iVar5);
                                in_RCX[0x12] = 0;
                                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267acc;
                                func_0x0001802d44d0(iVar7);
                                return 0;
                            }
                            uVar8 = 1;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267ae0;
                    func_0x0001802d44d0(iVar7);
                    return uVar8;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b29;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b41;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                  *(int64_t *)((int64_t)&arg_48h + iVar4));
code_r0x0001802678b0:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802678ba;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_1802678d7
// Address: 0x1802678d7
// Size: 631 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1802677a0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 uVar8;
    int64_t in_R8;
    int64_t in_R9;
    bool bVar9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802677bb;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802677d4;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802677ec;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802677fe;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    if (in_RCX[8] == 0) {
code_r0x000180267b4e:
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b53;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b6b;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b7d;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267817;
    iVar2 = fcn.1802553f0();
    if (iVar2 != 0) goto code_r0x000180267b4e;
    iVar5 = in_RCX[8];
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267828;
    iVar2 = func_0x000180255370(iVar5);
    if (iVar2 != 0) goto code_r0x000180267b4e;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
    if (in_R8 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267846;
        iVar2 = fcn.1802553f0(in_R8);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267856;
            iVar2 = func_0x000180255370(in_R8);
            if (iVar2 == 0) {
                iVar5 = in_RCX[8];
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267867;
                iVar2 = func_0x000180255500(iVar5);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267872;
                iVar3 = func_0x000180255500(in_R8);
                if (iVar3 <= iVar2 + 1) {
                    if (in_R9 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267887;
                        iVar2 = func_0x000180255370(in_R9);
                        if (iVar2 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267890;
                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4));
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802678a8;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_48h + iVar4));
                            goto code_r0x0001802678b0;
                        }
                    }
                    iVar5 = in_RCX[1];
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802678e8;
                        iVar5 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar4));
                        in_RCX[1] = iVar5;
                        if (iVar5 == 0) {
                            return 0;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802678fc;
                    iVar2 = fcn.180267e30(iVar5, in_RDX);
                    if (iVar2 == 0) {
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026790c;
                    iVar5 = fcn.180255110(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)(&stack0x00000028 + iVar4), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar4));
                    if (iVar5 == 0) {
                        return 0;
                    }
                    if (in_R9 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026791e;
                        iVar2 = fcn.1802553f0(in_R9);
                        if (iVar2 == 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026792e;
                            iVar5 = fcn.180255110(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                                  *(int64_t *)(&stack0x00000028 + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_50h + iVar4));
                            if (iVar5 == 0) {
                                return 0;
                            }
                            goto code_r0x000180267a53;
                        }
                    }
                    iVar5 = in_RCX[8];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267942;
                    iVar2 = func_0x000180255500(iVar5);
                    iVar5 = in_RCX[2];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267955;
                    iVar3 = func_0x000180255500(iVar5);
                    if ((iVar2 + 1) / 2 + 3 < iVar3) {
                        iVar5 = in_RCX[0x15];
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267973;
                        iVar5 = func_0x0001802d4790(iVar5);
                        if (iVar5 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267987;
                            func_0x0001802d48b0(iVar5);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026798f;
                            iVar7 = func_0x0001802d4590(iVar5);
                            if (iVar7 != 0) {
                                if (*(int32_t *)(*in_RCX + 4) == 0x197) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679af;
                                    func_0x000180255b00(iVar7);
                                    iVar6 = in_RCX[8];
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679b8;
                                    iVar2 = func_0x000180255500(iVar6);
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679c3;
                                    iVar2 = func_0x000180255780(iVar7, iVar2 + -1);
                                    bVar9 = iVar2 == 0;
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679d0;
                                    iVar6 = fcn.180255110(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                                          *(int64_t *)(&stack0x00000028 + iVar4), 
                                                          *(int64_t *)((int64_t)&arg_50h + iVar4));
                                    bVar9 = iVar6 == 0;
                                }
                                if (!bVar9) {
                                    iVar6 = in_RCX[2];
                                    iVar1 = in_RCX[3];
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679e6;
                                    iVar2 = func_0x000180297880(iVar1, iVar6);
                                    if (iVar2 != 0) {
                                        iVar6 = in_RCX[3];
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679fd;
                                        iVar2 = func_0x0001802d49d0(iVar6, iVar6, iVar7);
                                        if (iVar2 != 0) {
                                            iVar7 = in_RCX[3];
                                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a0e;
                                            uVar8 = func_0x000180255ab0();
                                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a1c;
                                            iVar2 = func_0x0001802d49d0(iVar7, iVar7, uVar8);
                                            if (iVar2 != 0) {
                                                iVar7 = in_RCX[3];
                                                iVar6 = in_RCX[2];
                                                *(int64_t *)((int64_t)&var_18h + iVar4) = iVar5;
                                                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a3b;
                                                iVar2 = func_0x0001802d4d00(iVar7, 0, iVar7, iVar6);
                                                if (iVar2 != 0) {
                                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a4b;
                                                    func_0x0001802d4450(iVar5);
                                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a53;
                                                    func_0x0001802d44d0(iVar5);
                                                    goto code_r0x000180267a53;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b0e;
                            func_0x0001802d4450(iVar5);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b16;
                            func_0x0001802d44d0(iVar5);
                        }
                        iVar5 = in_RCX[3];
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b1f;
                        func_0x000180255b00(iVar5);
                        return 0;
                    }
                    iVar5 = in_RCX[3];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267962;
                    func_0x000180255b00(iVar5);
code_r0x000180267a53:
                    iVar5 = in_RCX[2];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a5c;
                    iVar2 = func_0x000180255380(iVar5);
                    if (iVar2 == 0) {
                        iVar5 = in_RCX[0x12];
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267af3;
                        fcn.1802cd2a0(iVar5);
                        in_RCX[0x12] = 0;
                        return 1;
                    }
                    iVar5 = in_RCX[0x15];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a70;
                    iVar7 = func_0x0001802d4790(iVar5);
                    iVar5 = in_RCX[0x12];
                    uVar8 = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a81;
                    fcn.1802cd2a0(iVar5);
                    in_RCX[0x12] = 0;
                    if (iVar7 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a92;
                        iVar5 = fcn.1802cd2f0();
                        in_RCX[0x12] = iVar5;
                        if (iVar5 != 0) {
                            iVar6 = in_RCX[2];
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267aad;
                            iVar2 = func_0x0001802cd370(iVar5, iVar6, iVar7);
                            if (iVar2 == 0) {
                                iVar5 = in_RCX[0x12];
                                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267abd;
                                fcn.1802cd2a0(iVar5);
                                in_RCX[0x12] = 0;
                                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267acc;
                                func_0x0001802d44d0(iVar7);
                                return 0;
                            }
                            uVar8 = 1;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267ae0;
                    func_0x0001802d44d0(iVar7);
                    return uVar8;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b29;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b41;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                  *(int64_t *)((int64_t)&arg_48h + iVar4));
code_r0x0001802678b0:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802678ba;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_180267b4e
// Address: 0x180267b4e
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1802677a0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 uVar8;
    int64_t in_R8;
    int64_t in_R9;
    bool bVar9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802677bb;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802677d4;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802677ec;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802677fe;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    if (in_RCX[8] == 0) {
code_r0x000180267b4e:
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b53;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b6b;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b7d;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267817;
    iVar2 = fcn.1802553f0();
    if (iVar2 != 0) goto code_r0x000180267b4e;
    iVar5 = in_RCX[8];
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267828;
    iVar2 = func_0x000180255370(iVar5);
    if (iVar2 != 0) goto code_r0x000180267b4e;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
    if (in_R8 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267846;
        iVar2 = fcn.1802553f0(in_R8);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267856;
            iVar2 = func_0x000180255370(in_R8);
            if (iVar2 == 0) {
                iVar5 = in_RCX[8];
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267867;
                iVar2 = func_0x000180255500(iVar5);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267872;
                iVar3 = func_0x000180255500(in_R8);
                if (iVar3 <= iVar2 + 1) {
                    if (in_R9 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267887;
                        iVar2 = func_0x000180255370(in_R9);
                        if (iVar2 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267890;
                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4));
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802678a8;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_48h + iVar4));
                            goto code_r0x0001802678b0;
                        }
                    }
                    iVar5 = in_RCX[1];
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802678e8;
                        iVar5 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar4));
                        in_RCX[1] = iVar5;
                        if (iVar5 == 0) {
                            return 0;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802678fc;
                    iVar2 = fcn.180267e30(iVar5, in_RDX);
                    if (iVar2 == 0) {
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026790c;
                    iVar5 = fcn.180255110(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)(&stack0x00000028 + iVar4), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar4));
                    if (iVar5 == 0) {
                        return 0;
                    }
                    if (in_R9 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026791e;
                        iVar2 = fcn.1802553f0(in_R9);
                        if (iVar2 == 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026792e;
                            iVar5 = fcn.180255110(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                                  *(int64_t *)(&stack0x00000028 + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_50h + iVar4));
                            if (iVar5 == 0) {
                                return 0;
                            }
                            goto code_r0x000180267a53;
                        }
                    }
                    iVar5 = in_RCX[8];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267942;
                    iVar2 = func_0x000180255500(iVar5);
                    iVar5 = in_RCX[2];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267955;
                    iVar3 = func_0x000180255500(iVar5);
                    if ((iVar2 + 1) / 2 + 3 < iVar3) {
                        iVar5 = in_RCX[0x15];
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267973;
                        iVar5 = func_0x0001802d4790(iVar5);
                        if (iVar5 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267987;
                            func_0x0001802d48b0(iVar5);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026798f;
                            iVar7 = func_0x0001802d4590(iVar5);
                            if (iVar7 != 0) {
                                if (*(int32_t *)(*in_RCX + 4) == 0x197) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679af;
                                    func_0x000180255b00(iVar7);
                                    iVar6 = in_RCX[8];
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679b8;
                                    iVar2 = func_0x000180255500(iVar6);
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679c3;
                                    iVar2 = func_0x000180255780(iVar7, iVar2 + -1);
                                    bVar9 = iVar2 == 0;
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679d0;
                                    iVar6 = fcn.180255110(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                                          *(int64_t *)(&stack0x00000028 + iVar4), 
                                                          *(int64_t *)((int64_t)&arg_50h + iVar4));
                                    bVar9 = iVar6 == 0;
                                }
                                if (!bVar9) {
                                    iVar6 = in_RCX[2];
                                    iVar1 = in_RCX[3];
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679e6;
                                    iVar2 = func_0x000180297880(iVar1, iVar6);
                                    if (iVar2 != 0) {
                                        iVar6 = in_RCX[3];
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802679fd;
                                        iVar2 = func_0x0001802d49d0(iVar6, iVar6, iVar7);
                                        if (iVar2 != 0) {
                                            iVar7 = in_RCX[3];
                                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a0e;
                                            uVar8 = func_0x000180255ab0();
                                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a1c;
                                            iVar2 = func_0x0001802d49d0(iVar7, iVar7, uVar8);
                                            if (iVar2 != 0) {
                                                iVar7 = in_RCX[3];
                                                iVar6 = in_RCX[2];
                                                *(int64_t *)((int64_t)&var_18h + iVar4) = iVar5;
                                                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a3b;
                                                iVar2 = func_0x0001802d4d00(iVar7, 0, iVar7, iVar6);
                                                if (iVar2 != 0) {
                                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a4b;
                                                    func_0x0001802d4450(iVar5);
                                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a53;
                                                    func_0x0001802d44d0(iVar5);
                                                    goto code_r0x000180267a53;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b0e;
                            func_0x0001802d4450(iVar5);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b16;
                            func_0x0001802d44d0(iVar5);
                        }
                        iVar5 = in_RCX[3];
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b1f;
                        func_0x000180255b00(iVar5);
                        return 0;
                    }
                    iVar5 = in_RCX[3];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267962;
                    func_0x000180255b00(iVar5);
code_r0x000180267a53:
                    iVar5 = in_RCX[2];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a5c;
                    iVar2 = func_0x000180255380(iVar5);
                    if (iVar2 == 0) {
                        iVar5 = in_RCX[0x12];
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267af3;
                        fcn.1802cd2a0(iVar5);
                        in_RCX[0x12] = 0;
                        return 1;
                    }
                    iVar5 = in_RCX[0x15];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a70;
                    iVar7 = func_0x0001802d4790(iVar5);
                    iVar5 = in_RCX[0x12];
                    uVar8 = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a81;
                    fcn.1802cd2a0(iVar5);
                    in_RCX[0x12] = 0;
                    if (iVar7 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267a92;
                        iVar5 = fcn.1802cd2f0();
                        in_RCX[0x12] = iVar5;
                        if (iVar5 != 0) {
                            iVar6 = in_RCX[2];
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267aad;
                            iVar2 = func_0x0001802cd370(iVar5, iVar6, iVar7);
                            if (iVar2 == 0) {
                                iVar5 = in_RCX[0x12];
                                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267abd;
                                fcn.1802cd2a0(iVar5);
                                in_RCX[0x12] = 0;
                                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267acc;
                                func_0x0001802d44d0(iVar7);
                                return 0;
                            }
                            uVar8 = 1;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267ae0;
                    func_0x0001802d44d0(iVar7);
                    return uVar8;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b29;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180267b41;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                  *(int64_t *)((int64_t)&arg_48h + iVar4));
code_r0x0001802678b0:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802678ba;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_180267b90
// Address: 0x180267b90
// Size: 179 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180267b90(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180267ba5;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar1 = *(undefined8 *)(in_RCX + 0x30);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180267bc7;
    fcn.180224990(uVar1, 0x1804e6f68, 0x214);
    *(undefined8 *)(in_RCX + 0x30) = 0;
    *(undefined8 *)(in_RCX + 0x38) = 0;
    if ((in_R8 != 0) && (in_RDX != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180267bf0;
        iVar3 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
        *(int64_t *)(in_RCX + 0x30) = iVar3;
        if (iVar3 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180267c17;
        fcn.180498030(iVar3, in_RDX, in_R8);
        *(int64_t *)(in_RCX + 0x38) = in_R8;
        return in_R8;
    }
    return 1;
}

// ============================================================
// Function: FUN_180267c50
// Address: 0x180267c50
// Size: 203 bytes
// ============================================================
undefined8 fcn.180267c50(int64_t *param_1, int64_t *param_2, int64_t *param_3, int64_t *param_4)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180267c5c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar2 = *param_1;
    if (*(code **)(iVar2 + 0xa0) == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180267c76;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180267c8e;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
    } else {
        if ((((iVar2 == *param_2) &&
             ((((iVar1 = *(int32_t *)(param_1 + 4), iVar1 == 0 || (*(int32_t *)(param_2 + 1) == 0)) ||
               (iVar1 == *(int32_t *)(param_2 + 1))) && (iVar2 == *param_3)))) &&
            ((((iVar1 == 0 || (*(int32_t *)(param_3 + 1) == 0)) || (iVar1 == *(int32_t *)(param_3 + 1))) &&
             (iVar2 == *param_4)))) &&
           (((iVar1 == 0 || (*(int32_t *)(param_4 + 1) == 0)) || (iVar1 == *(int32_t *)(param_4 + 1))))) {
    // WARNING: Could not recover jumptable at 0x000180267ce1. Too many branches
    // WARNING: Treating indirect jump as call
            uVar4 = (**(code **)(iVar2 + 0xa0))(param_1);
            return uVar4;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180267ce9;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180267d01;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180267d13;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_180267d20
// Address: 0x180267d20
// Size: 80 bytes
// ============================================================
void fcn.180267d20(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180267d30;
        iVar1 = fcn.18045a350();
        pcVar2 = *(code **)(*(int64_t *)arg1 + 0x60);
        if ((pcVar2 != (code *)0x0) || (pcVar2 = *(code **)(*(int64_t *)arg1 + 0x58), pcVar2 != (code *)0x0)) {
            *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x180267d50;
            (*pcVar2)(arg1);
        }
        *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x180267d6a;
        func_0x000180224b90(arg1, 0x30, 0x1804e6f68, 0x300);
    }
    return;
}

// ============================================================
// Function: FUN_180267d70
// Address: 0x180267d70
// Size: 185 bytes
// ============================================================
undefined8 fcn.180267d70(int64_t *param_1, int64_t *param_2, int64_t *param_3)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180267d7c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar2 = *param_1;
    if (*(code **)(iVar2 + 200) == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180267d96;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180267dae;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
    } else {
        if (((iVar2 == *param_2) &&
            (((iVar1 = *(int32_t *)(param_1 + 4), iVar1 == 0 || (*(int32_t *)(param_2 + 1) == 0)) ||
             (iVar1 == *(int32_t *)(param_2 + 1))))) &&
           ((iVar2 == *param_3 &&
            (((iVar1 == 0 || (*(int32_t *)(param_3 + 1) == 0)) || (iVar1 == *(int32_t *)(param_3 + 1))))))) {
    // WARNING: Could not recover jumptable at 0x000180267dec. Too many branches
    // WARNING: Treating indirect jump as call
            uVar4 = (**(code **)(iVar2 + 200))(param_1);
            return uVar4;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180267df4;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180267e0c;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180267e1e;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
    return 0xffffffff;
}

// ============================================================
// Function: FUN_180267e30
// Address: 0x180267e30
// Size: 181 bytes
// ============================================================
undefined8 fcn.180267e30(int64_t *param_1, int64_t *param_2)
{
    code *UNRECOVERED_JUMPTABLE;
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x180267e3a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    UNRECOVERED_JUMPTABLE = *(code **)(*param_1 + 0x68);
    if (UNRECOVERED_JUMPTABLE == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180267e4e;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180267e66;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180267e78;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    if (*param_1 == *param_2) {
        if (((*(int32_t *)(param_1 + 1) == *(int32_t *)(param_2 + 1)) || (*(int32_t *)(param_1 + 1) == 0)) ||
           (*(int32_t *)(param_2 + 1) == 0)) {
            if (param_1 == param_2) {
                return 1;
            }
    // WARNING: Could not recover jumptable at 0x000180267eac. Too many branches
    // WARNING: Treating indirect jump as call
            uVar2 = (*UNRECOVERED_JUMPTABLE)();
            return uVar2;
        }
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180267eb4;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180267ecc;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                  *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180267ede;
    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
    return 0;
}

// ============================================================
// Function: FUN_180267ef0
// Address: 0x180267ef0
// Size: 182 bytes
// ============================================================
undefined8 fcn.180267ef0(int64_t *param_1, int64_t *param_2, int64_t *param_3)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180267efc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar2 = *param_1;
    if (*(code **)(iVar2 + 0xa8) == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180267f16;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180267f2e;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
    } else {
        if (((iVar2 == *param_2) &&
            (((iVar1 = *(int32_t *)(param_1 + 4), iVar1 == 0 || (*(int32_t *)(param_2 + 1) == 0)) ||
             (iVar1 == *(int32_t *)(param_2 + 1))))) &&
           ((iVar2 == *param_3 &&
            (((iVar1 == 0 || (*(int32_t *)(param_3 + 1) == 0)) || (iVar1 == *(int32_t *)(param_3 + 1))))))) {
    // WARNING: Could not recover jumptable at 0x000180267f6c. Too many branches
    // WARNING: Treating indirect jump as call
            uVar4 = (**(code **)(iVar2 + 0xa8))(param_1);
            return uVar4;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180267f74;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180267f8c;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180267f9e;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_180267fb0
// Address: 0x180267fb0
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t * fcn.180267fb0(int64_t arg_28h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180267fc0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180267fd3;
        piVar4 = (int64_t *)fcn.1802685b0(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
        if (piVar4 != (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180267fe6;
            iVar2 = fcn.180267e30(piVar4, in_RCX);
            if (iVar2 != 0) {
                return piVar4;
            }
            pcVar1 = *(code **)(*piVar4 + 0x58);
            if (pcVar1 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180267ffb;
                (*pcVar1)(piVar4);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180268010;
            fcn.180224990(piVar4, 0x1804e6f68, 0x2f3);
        }
    }
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_180268030
// Address: 0x180268030
// Size: 63 bytes
// ============================================================
void fcn.180268030(int64_t arg1)
{
    code *pcVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180268040;
        iVar2 = fcn.18045a350();
        pcVar1 = *(code **)(*(int64_t *)arg1 + 0x58);
        if (pcVar1 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x180268054;
            (*pcVar1)();
        }
        *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x180268069;
        fcn.180224990(arg1, 0x1804e6f68, 0x2f3);
    }
    return;
}

// ============================================================
// Function: FUN_180268070
// Address: 0x180268070
// Size: 396 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180268070(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t *in_RCX;
    int64_t *in_RDX;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026808a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar1 = *in_RCX;
    if (*(int64_t *)(iVar1 + 0x80) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802680ab;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802680c3;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
code_r0x0001802681d8:
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802681e5;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    if ((iVar1 != *in_RDX) ||
       (((iVar3 = *(int32_t *)(in_RCX + 4), iVar3 != 0 && (*(int32_t *)(in_RDX + 1) != 0)) &&
        (iVar3 != *(int32_t *)(in_RDX + 1))))) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802681bb;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802681d3;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        goto code_r0x0001802681d8;
    }
    pcVar2 = *(code **)(iVar1 + 0xb8);
    if (pcVar2 == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802680fd;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268115;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
    } else {
        if (((iVar3 == 0) || (*(int32_t *)(in_RDX + 1) == 0)) || (iVar3 == *(int32_t *)(in_RDX + 1))) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026818e;
            iVar3 = (*pcVar2)(in_RCX, in_RDX);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268197;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802681af;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                              *(int64_t *)(&stack0x00000030 + iVar4), *(int64_t *)((int64_t)&arg_48h + iVar4));
                goto code_r0x0001802681d8;
            }
            goto code_r0x000180268127;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268163;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026817b;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268127;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
code_r0x000180268127:
    pcVar2 = *(code **)(*in_RCX + 0x80);
    *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + -8) = *(undefined8 *)((int64_t)&arg_58h + iVar4);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026814a;
    uVar5 = (*pcVar2)(in_RCX, in_RDX, in_R8, in_R9);
    return uVar5;
}

// ============================================================
// Function: FUN_180268200
// Address: 0x180268200
// Size: 172 bytes
// ============================================================
undefined8 fcn.180268200(int64_t *param_1, int64_t *param_2)
{
    code *UNRECOVERED_JUMPTABLE;
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026820a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    UNRECOVERED_JUMPTABLE = *(code **)(*param_1 + 0xb0);
    if (UNRECOVERED_JUMPTABLE == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180268224;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18026823c;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18026824e;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    if ((*param_1 == *param_2) &&
       (((*(int32_t *)(param_1 + 4) == 0 || (*(int32_t *)(param_2 + 1) == 0)) ||
        (*(int32_t *)(param_1 + 4) == *(int32_t *)(param_2 + 1))))) {
    // WARNING: Could not recover jumptable at 0x000180268273. Too many branches
    // WARNING: Treating indirect jump as call
        uVar2 = (*UNRECOVERED_JUMPTABLE)(param_1);
        return uVar2;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18026827b;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180268293;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                  *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802682a5;
    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
    return 0;
}

// ============================================================
// Function: FUN_1802682b0
// Address: 0x1802682b0
// Size: 169 bytes
// ============================================================
undefined8 fcn.1802682b0(int64_t *param_1, int64_t *param_2)
{
    code *UNRECOVERED_JUMPTABLE;
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802682ba;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    UNRECOVERED_JUMPTABLE = *(code **)(*param_1 + 0xb8);
    if (UNRECOVERED_JUMPTABLE == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802682d1;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802682e9;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802682fb;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    if ((*param_1 == *param_2) &&
       (((*(int32_t *)(param_1 + 4) == 0 || (*(int32_t *)(param_2 + 1) == 0)) ||
        (*(int32_t *)(param_1 + 4) == *(int32_t *)(param_2 + 1))))) {
    // WARNING: Could not recover jumptable at 0x000180268320. Too many branches
    // WARNING: Treating indirect jump as call
        uVar2 = (*UNRECOVERED_JUMPTABLE)();
        return uVar2;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180268328;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180268340;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                  *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180268352;
    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
    return 0;
}

// ============================================================
// Function: FUN_180268360
// Address: 0x180268360
// Size: 172 bytes
// ============================================================
undefined8 fcn.180268360(int64_t *param_1, int64_t *param_2)
{
    code *UNRECOVERED_JUMPTABLE;
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026836a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    UNRECOVERED_JUMPTABLE = *(code **)(*param_1 + 0xc0);
    if (UNRECOVERED_JUMPTABLE == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180268384;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18026839c;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802683ae;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    if ((*param_1 == *param_2) &&
       (((*(int32_t *)(param_1 + 4) == 0 || (*(int32_t *)(param_2 + 1) == 0)) ||
        (*(int32_t *)(param_1 + 4) == *(int32_t *)(param_2 + 1))))) {
    // WARNING: Could not recover jumptable at 0x0001802683d3. Too many branches
    // WARNING: Treating indirect jump as call
        uVar2 = (*UNRECOVERED_JUMPTABLE)(param_1);
        return uVar2;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802683db;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802683f3;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                  *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180268405;
    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
    return 0;
}

// ============================================================
// Function: FUN_180268410
// Address: 0x180268410
// Size: 402 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.180268410(int64_t arg4, int64_t arg_48h, int64_t arg_50h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h
                      )
{
    int32_t iVar1;
    code *pcVar2;
    uint32_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    int64_t *in_RDX;
    int64_t iVar8;
    int64_t iVar9;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18026842d;
    var_20h = arg4;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar8 = 0;
    if (((*in_RCX == *in_RDX) &&
        (((iVar1 = *(int32_t *)(in_RCX + 4), iVar1 == 0 || (*(int32_t *)(in_RDX + 1) == 0)) ||
         (iVar1 == *(int32_t *)(in_RDX + 1))))) &&
       (((int64_t *)arg4 == (int64_t *)0x0 ||
        ((*in_RCX == *(int64_t *)arg4 &&
         (((iVar1 == 0 || (*(int32_t *)(arg4 + 8) == 0)) || (iVar1 == *(int32_t *)(arg4 + 8))))))))) {
        iVar7 = *(int64_t *)((int64_t)&arg_68h + iVar4);
        if ((in_R8 == 0) && (iVar7 == 0)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026849e;
            uVar5 = func_0x000180268920(in_RCX, in_RDX);
            return uVar5;
        }
        iVar6 = *(int64_t *)((int64_t)&arg_70h + iVar4);
        iVar9 = iVar8;
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802684b5;
            iVar6 = func_0x0001802d47f0();
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802684c5;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802684dd;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                              *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000038 + iVar4));
                goto code_r0x000180268580;
            }
            iVar7 = *(int64_t *)((int64_t)&arg_68h + iVar4);
            arg4 = *(int64_t *)((int64_t)&arg_60h + iVar4);
            iVar9 = iVar6;
        }
        if (((int64_t *)arg4 != (int64_t *)0x0) && (iVar7 != 0)) {
            iVar8 = 1;
        }
        iVar7 = *in_RCX;
        *(int64_t *)((int64_t)&var_18h + iVar4) = iVar6;
        pcVar2 = *(code **)(iVar7 + 0xe0);
        *(int64_t *)((int64_t)&var_10h + iVar4) = (int64_t)&arg_68h + iVar4;
        *(int64_t *)((int64_t)&var_8h + iVar4) = (int64_t)&arg_60h + iVar4;
        if (pcVar2 == (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180268550;
            uVar3 = func_0x0001802d8530(in_RCX, in_RDX, in_R8, iVar8);
            uVar5 = (uint64_t)uVar3;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026855a;
            func_0x0001802d44d0(iVar9);
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026853d;
            uVar3 = (*pcVar2)();
            uVar5 = (uint64_t)uVar3;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180268547;
            func_0x0001802d44d0(iVar9);
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180268563;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026857b;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000038 + iVar4));
code_r0x000180268580:
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026858d;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar4));
        uVar5 = 0;
    }
    return uVar5;
}

// ============================================================
// Function: FUN_1802685b0
// Address: 0x1802685b0
// Size: 149 bytes
// ============================================================
int64_t * fcn.1802685b0(int64_t arg_28h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t *in_RCX;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802685bc;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX == (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802685cc;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802685e4;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802685f6;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar4));
        return (int64_t *)0x0;
    }
    if (*(int64_t *)(*in_RCX + 0x50) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026860d;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268625;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268637;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar4));
        return (int64_t *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026865b;
    piVar5 = (int64_t *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
    if (piVar5 != (int64_t *)0x0) {
        iVar1 = *in_RCX;
        *piVar5 = iVar1;
        *(undefined4 *)(piVar5 + 1) = *(undefined4 *)(in_RCX + 4);
        pcVar2 = *(code **)(iVar1 + 0x50);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268678;
        iVar3 = (*pcVar2)(piVar5);
        if (iVar3 != 0) {
            return piVar5;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268691;
        fcn.180224990(piVar5, 0x1804e6f68, 0x2e2);
    }
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_180268645
// Address: 0x180268645
// Size: 89 bytes
// ============================================================
int64_t * fcn.1802685b0(int64_t arg_28h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t *in_RCX;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802685bc;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX == (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802685cc;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802685e4;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802685f6;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar4));
        return (int64_t *)0x0;
    }
    if (*(int64_t *)(*in_RCX + 0x50) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026860d;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268625;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268637;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar4));
        return (int64_t *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026865b;
    piVar5 = (int64_t *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
    if (piVar5 != (int64_t *)0x0) {
        iVar1 = *in_RCX;
        *piVar5 = iVar1;
        *(undefined4 *)(piVar5 + 1) = *(undefined4 *)(in_RCX + 4);
        pcVar2 = *(code **)(iVar1 + 0x50);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268678;
        iVar3 = (*pcVar2)(piVar5);
        if (iVar3 != 0) {
            return piVar5;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268691;
        fcn.180224990(piVar5, 0x1804e6f68, 0x2e2);
    }
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_18026869e
// Address: 0x18026869e
// Size: 14 bytes
// ============================================================
int64_t * fcn.1802685b0(int64_t arg_28h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t *in_RCX;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802685bc;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX == (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802685cc;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802685e4;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802685f6;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar4));
        return (int64_t *)0x0;
    }
    if (*(int64_t *)(*in_RCX + 0x50) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026860d;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268625;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268637;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar4));
        return (int64_t *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026865b;
    piVar5 = (int64_t *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
    if (piVar5 != (int64_t *)0x0) {
        iVar1 = *in_RCX;
        *piVar5 = iVar1;
        *(undefined4 *)(piVar5 + 1) = *(undefined4 *)(in_RCX + 4);
        pcVar2 = *(code **)(iVar1 + 0x50);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268678;
        iVar3 = (*pcVar2)(piVar5);
        if (iVar3 != 0) {
            return piVar5;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268691;
        fcn.180224990(piVar5, 0x1804e6f68, 0x2e2);
    }
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_1802686b0
// Address: 0x1802686b0
// Size: 171 bytes
// ============================================================
undefined4
fcn.1802686b0(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
             int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h)
{
    code *pcVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t *in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t in_R8;
    int64_t in_R9;
    undefined4 uVar9;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t aiStackX_18 [2];
    undefined8 uStack_8;
    
    uStack_8 = 0x1802686ba;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (*(int32_t *)(*in_RCX + 4) != 0x196) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x1802686d1;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6));
        *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x1802686e9;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                      *(int64_t *)((int64_t)&arg_50h + iVar6));
        *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x1802686fb;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar6));
        return 0;
    }
    if ((*in_RCX != *in_RDX) ||
       (((*(int32_t *)(in_RCX + 4) != 0 && (*(int32_t *)(in_RDX + 1) != 0)) &&
        (*(int32_t *)(in_RCX + 4) != *(int32_t *)(in_RDX + 1))))) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x18026872a;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6));
        *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x180268742;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                      *(int64_t *)((int64_t)&arg_50h + iVar6));
        *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x180268754;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_50h + iVar6) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_58h + iVar6) = unaff_RDI;
    *(undefined8 *)(&stack0x00000030 + iVar6) = unaff_R12;
    *(undefined8 *)(&stack0x00000028 + iVar6) = unaff_R14;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar6) = 0x1802dc6c4;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar8 = *(int64_t *)((int64_t)&arg_88h + iVar7 + iVar6);
    uVar9 = 0;
    if (iVar8 == 0) {
        iVar8 = in_RCX[0x15];
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar6) = 0x1802dc6ee;
        iVar8 = fcn.1802d4790(iVar8);
        if (iVar8 == 0) {
            return 0;
        }
    }
    if (in_R8 != 0) {
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar6) = 0x1802dc715;
        iVar4 = fcn.1802e1570(*(int64_t *)((int64_t)&arg_50h + iVar7 + iVar6));
        if (iVar4 == 0) goto code_r0x0001802dc7fd;
        pcVar1 = *(code **)(*in_RCX + 0x118);
        if (pcVar1 != (code *)0x0) {
            iVar2 = in_RDX[2];
            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar6) = 0x1802dc73c;
            iVar4 = (*pcVar1)(in_RCX, iVar2, iVar2, iVar8);
            if (iVar4 == 0) goto code_r0x0001802dc7fd;
        }
    }
    if (in_R9 != 0) {
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar6) = 0x1802dc75c;
        iVar4 = fcn.1802e1570(*(int64_t *)((int64_t)&arg_50h + iVar7 + iVar6));
        if (iVar4 == 0) goto code_r0x0001802dc7fd;
        pcVar1 = *(code **)(*in_RCX + 0x118);
        if (pcVar1 != (code *)0x0) {
            iVar2 = in_RDX[3];
            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar6) = 0x1802dc783;
            iVar4 = (*pcVar1)(in_RCX, iVar2, iVar2, iVar8);
            if (iVar4 == 0) goto code_r0x0001802dc7fd;
        }
    }
    if (*(int64_t *)((int64_t)&arg_80h + iVar7 + iVar6) != 0) {
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar6) = 0x1802dc7a1;
        iVar4 = fcn.1802e1570(*(int64_t *)((int64_t)&arg_50h + iVar7 + iVar6));
        if (iVar4 == 0) goto code_r0x0001802dc7fd;
        iVar2 = in_RDX[4];
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar6) = 0x1802dc7ae;
        iVar4 = fcn.1802553a0(iVar2);
        pcVar1 = *(code **)(*in_RCX + 0x118);
        if (pcVar1 != (code *)0x0) {
            if ((iVar4 == 0) || (pcVar3 = *(code **)(*in_RCX + 0x128), pcVar3 == (code *)0x0)) {
                iVar2 = in_RDX[4];
                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar6) = 0x1802dc7ef;
                iVar5 = (*pcVar1)(in_RCX, iVar2, iVar2, iVar8);
            } else {
                iVar2 = in_RDX[4];
                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar6) = 0x1802dc7dd;
                iVar5 = (*pcVar3)(in_RCX, iVar2, iVar8);
            }
            if (iVar5 == 0) goto code_r0x0001802dc7fd;
        }
        *(int32_t *)(in_RDX + 5) = iVar4;
    }
    uVar9 = 1;
code_r0x0001802dc7fd:
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar6) = 0x1802dc805;
    fcn.1802d44d0(*(int64_t *)((int64_t)&arg_40h + iVar7 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar6), 
                  *(int64_t *)((int64_t)&arg_78h + iVar7 + iVar6));
    return uVar9;
}

// ============================================================
// Function: FUN_180268760
// Address: 0x180268760
// Size: 128 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180268760(int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    code *pcVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180268770;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    pcVar1 = *(code **)(*in_RCX + 0x78);
    if (pcVar1 == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026878a;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802687a2;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802687b4;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    if ((*in_RCX != *in_RDX) ||
       (((*(int32_t *)(in_RCX + 4) != 0 && (*(int32_t *)(in_RDX + 1) != 0)) &&
        (*(int32_t *)(in_RCX + 4) != *(int32_t *)(in_RDX + 1))))) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802688e1;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802688f9;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026890b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
    uVar2 = *(undefined8 *)((int64_t)&arg_58h + iVar4);
    *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + -8) = uVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802687f5;
    iVar3 = (*pcVar1)(in_RCX);
    if (iVar3 == 0) {
        return 0;
    }
    pcVar1 = *(code **)(*in_RCX + 0xc0);
    if (pcVar1 == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268811;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268829;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
    } else {
        if ((*in_RCX == *in_RDX) &&
           (((*(int32_t *)(in_RCX + 4) == 0 || (*(int32_t *)(in_RDX + 1) == 0)) ||
            (*(int32_t *)(in_RCX + 4) == *(int32_t *)(in_RDX + 1))))) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268853;
            iVar3 = (*pcVar1)(in_RCX, in_RDX, uVar2);
            if (0 < iVar3) {
                return 1;
            }
            goto code_r0x00018026889b;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268871;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268889;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026889b;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
code_r0x00018026889b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802688a0;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802688b8;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                  *(int64_t *)(&stack0x00000048 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802688ca;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_1802687e0
// Address: 0x1802687e0
// Size: 140 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180268760(int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    code *pcVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180268770;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    pcVar1 = *(code **)(*in_RCX + 0x78);
    if (pcVar1 == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026878a;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802687a2;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802687b4;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    if ((*in_RCX != *in_RDX) ||
       (((*(int32_t *)(in_RCX + 4) != 0 && (*(int32_t *)(in_RDX + 1) != 0)) &&
        (*(int32_t *)(in_RCX + 4) != *(int32_t *)(in_RDX + 1))))) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802688e1;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802688f9;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026890b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
    uVar2 = *(undefined8 *)((int64_t)&arg_58h + iVar4);
    *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + -8) = uVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802687f5;
    iVar3 = (*pcVar1)(in_RCX);
    if (iVar3 == 0) {
        return 0;
    }
    pcVar1 = *(code **)(*in_RCX + 0xc0);
    if (pcVar1 == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268811;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268829;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
    } else {
        if ((*in_RCX == *in_RDX) &&
           (((*(int32_t *)(in_RCX + 4) == 0 || (*(int32_t *)(in_RDX + 1) == 0)) ||
            (*(int32_t *)(in_RCX + 4) == *(int32_t *)(in_RDX + 1))))) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268853;
            iVar3 = (*pcVar1)(in_RCX, in_RDX, uVar2);
            if (0 < iVar3) {
                return 1;
            }
            goto code_r0x00018026889b;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268871;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268889;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026889b;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
code_r0x00018026889b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802688a0;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802688b8;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                  *(int64_t *)(&stack0x00000048 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802688ca;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_18026886c
// Address: 0x18026886c
// Size: 112 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180268760(int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    code *pcVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180268770;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    pcVar1 = *(code **)(*in_RCX + 0x78);
    if (pcVar1 == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026878a;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802687a2;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802687b4;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    if ((*in_RCX != *in_RDX) ||
       (((*(int32_t *)(in_RCX + 4) != 0 && (*(int32_t *)(in_RDX + 1) != 0)) &&
        (*(int32_t *)(in_RCX + 4) != *(int32_t *)(in_RDX + 1))))) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802688e1;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802688f9;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026890b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
    uVar2 = *(undefined8 *)((int64_t)&arg_58h + iVar4);
    *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + -8) = uVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802687f5;
    iVar3 = (*pcVar1)(in_RCX);
    if (iVar3 == 0) {
        return 0;
    }
    pcVar1 = *(code **)(*in_RCX + 0xc0);
    if (pcVar1 == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268811;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268829;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
    } else {
        if ((*in_RCX == *in_RDX) &&
           (((*(int32_t *)(in_RCX + 4) == 0 || (*(int32_t *)(in_RDX + 1) == 0)) ||
            (*(int32_t *)(in_RCX + 4) == *(int32_t *)(in_RDX + 1))))) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268853;
            iVar3 = (*pcVar1)(in_RCX, in_RDX, uVar2);
            if (0 < iVar3) {
                return 1;
            }
            goto code_r0x00018026889b;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268871;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268889;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026889b;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
code_r0x00018026889b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802688a0;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802688b8;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                  *(int64_t *)(&stack0x00000048 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802688ca;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_1802688dc
// Address: 0x1802688dc
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180268760(int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    code *pcVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180268770;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    pcVar1 = *(code **)(*in_RCX + 0x78);
    if (pcVar1 == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026878a;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802687a2;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802687b4;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    if ((*in_RCX != *in_RDX) ||
       (((*(int32_t *)(in_RCX + 4) != 0 && (*(int32_t *)(in_RDX + 1) != 0)) &&
        (*(int32_t *)(in_RCX + 4) != *(int32_t *)(in_RDX + 1))))) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802688e1;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802688f9;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026890b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
    uVar2 = *(undefined8 *)((int64_t)&arg_58h + iVar4);
    *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + -8) = uVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802687f5;
    iVar3 = (*pcVar1)(in_RCX);
    if (iVar3 == 0) {
        return 0;
    }
    pcVar1 = *(code **)(*in_RCX + 0xc0);
    if (pcVar1 == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268811;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268829;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
    } else {
        if ((*in_RCX == *in_RDX) &&
           (((*(int32_t *)(in_RCX + 4) == 0 || (*(int32_t *)(in_RDX + 1) == 0)) ||
            (*(int32_t *)(in_RCX + 4) == *(int32_t *)(in_RDX + 1))))) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268853;
            iVar3 = (*pcVar1)(in_RCX, in_RDX, uVar2);
            if (0 < iVar3) {
                return 1;
            }
            goto code_r0x00018026889b;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268871;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180268889;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026889b;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
code_r0x00018026889b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802688a0;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802688b8;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                  *(int64_t *)(&stack0x00000048 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802688ca;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_180268920
// Address: 0x180268920
// Size: 145 bytes
// ============================================================
undefined8 fcn.180268920(int64_t *param_1, int64_t *param_2)
{
    code *UNRECOVERED_JUMPTABLE;
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026892a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    UNRECOVERED_JUMPTABLE = *(code **)(*param_1 + 0x70);
    if (UNRECOVERED_JUMPTABLE == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18026893e;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180268956;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180268968;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    if (*param_1 != *param_2) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180268979;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180268991;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802689a3;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    // WARNING: Could not recover jumptable at 0x0001802689ae. Too many branches
    // WARNING: Treating indirect jump as call
    uVar2 = (*UNRECOVERED_JUMPTABLE)();
    return uVar2;
}

// ============================================================
// Function: FUN_1802689c0
// Address: 0x1802689c0
// Size: 124 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1802689c0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    int64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802689d5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(code **)(*in_RCX + 400) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180268a02. Too many branches
    // WARNING: Treating indirect jump as call
        uVar4 = (**(code **)(*in_RCX + 400))();
        return uVar4;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBX;
    uVar4 = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RSI;
    if (in_RCX[0x12] != 0) {
        if (in_R9 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180268a2a;
            in_R9 = func_0x0001802d47f0();
            if (in_R9 == 0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RBP;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180268a46;
        func_0x0001802d48b0(in_R9);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180268a4e;
        iVar5 = func_0x0001802d4590(in_R9);
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180268a63;
            iVar2 = func_0x000180255860(iVar5, 2);
            if (iVar2 != 0) {
                iVar1 = in_RCX[2];
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180268a76;
                iVar2 = func_0x0001802d4a70(iVar5, iVar1, iVar5);
                if (iVar2 != 0) {
                    iVar1 = in_RCX[2];
                    *(int64_t *)((int64_t)&var_10h + iVar3) = in_RCX[0x12];
                    *(int64_t *)((int64_t)&var_8h + iVar3) = in_R9;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180268a9d;
                    iVar2 = func_0x0001802d7580(in_RDX, in_R8, iVar5, iVar1);
                    uVar4 = 0;
                    if (iVar2 != 0) {
                        uVar4 = 1;
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180268aaf;
        func_0x0001802d4450(in_R9);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180268ab7;
        fcn.1802d44d0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                      *(int64_t *)((int64_t)&arg_40h + iVar3));
    }
    return uVar4;
}

// ============================================================
// Function: FUN_180268a3c
// Address: 0x180268a3c
// Size: 128 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1802689c0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    int64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802689d5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(code **)(*in_RCX + 400) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180268a02. Too many branches
    // WARNING: Treating indirect jump as call
        uVar4 = (**(code **)(*in_RCX + 400))();
        return uVar4;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBX;
    uVar4 = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RSI;
    if (in_RCX[0x12] != 0) {
        if (in_R9 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180268a2a;
            in_R9 = func_0x0001802d47f0();
            if (in_R9 == 0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RBP;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180268a46;
        func_0x0001802d48b0(in_R9);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180268a4e;
        iVar5 = func_0x0001802d4590(in_R9);
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180268a63;
            iVar2 = func_0x000180255860(iVar5, 2);
            if (iVar2 != 0) {
                iVar1 = in_RCX[2];
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180268a76;
                iVar2 = func_0x0001802d4a70(iVar5, iVar1, iVar5);
                if (iVar2 != 0) {
                    iVar1 = in_RCX[2];
                    *(int64_t *)((int64_t)&var_10h + iVar3) = in_RCX[0x12];
                    *(int64_t *)((int64_t)&var_8h + iVar3) = in_R9;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180268a9d;
                    iVar2 = func_0x0001802d7580(in_RDX, in_R8, iVar5, iVar1);
                    uVar4 = 0;
                    if (iVar2 != 0) {
                        uVar4 = 1;
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180268aaf;
        func_0x0001802d4450(in_R9);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180268ab7;
        fcn.1802d44d0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                      *(int64_t *)((int64_t)&arg_40h + iVar3));
    }
    return uVar4;
}

// ============================================================
// Function: FUN_180268abc
// Address: 0x180268abc
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1802689c0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    int64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802689d5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(code **)(*in_RCX + 400) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180268a02. Too many branches
    // WARNING: Treating indirect jump as call
        uVar4 = (**(code **)(*in_RCX + 400))();
        return uVar4;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBX;
    uVar4 = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RSI;
    if (in_RCX[0x12] != 0) {
        if (in_R9 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180268a2a;
            in_R9 = func_0x0001802d47f0();
            if (in_R9 == 0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RBP;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180268a46;
        func_0x0001802d48b0(in_R9);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180268a4e;
        iVar5 = func_0x0001802d4590(in_R9);
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180268a63;
            iVar2 = func_0x000180255860(iVar5, 2);
            if (iVar2 != 0) {
                iVar1 = in_RCX[2];
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180268a76;
                iVar2 = func_0x0001802d4a70(iVar5, iVar1, iVar5);
                if (iVar2 != 0) {
                    iVar1 = in_RCX[2];
                    *(int64_t *)((int64_t)&var_10h + iVar3) = in_RCX[0x12];
                    *(int64_t *)((int64_t)&var_8h + iVar3) = in_R9;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180268a9d;
                    iVar2 = func_0x0001802d7580(in_RDX, in_R8, iVar5, iVar1);
                    uVar4 = 0;
                    if (iVar2 != 0) {
                        uVar4 = 1;
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180268aaf;
        func_0x0001802d4450(in_R9);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180268ab7;
        fcn.1802d44d0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                      *(int64_t *)((int64_t)&arg_40h + iVar3));
    }
    return uVar4;
}

// ============================================================
// Function: FUN_180268ae0
// Address: 0x180268ae0
// Size: 414 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint8_t ** fcn.180268ae0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint8_t **ppuVar4;
    uint8_t *puVar5;
    uint8_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    uint8_t *in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180268af5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_R8 == (uint8_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180268b0b;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180268b23;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180268b35;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return (uint8_t **)0x0;
    }
    if (*(int64_t *)(in_R8 + 8) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180268b53;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180268b6b;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180268b7d;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return (uint8_t **)0x0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180268bab;
    ppuVar4 = (uint8_t **)fcn.180224d60(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
    if (ppuVar4 == (uint8_t **)0x0) {
        return (uint8_t **)0x0;
    }
    ppuVar4[0x15] = in_RCX;
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180268bdf;
        puVar5 = (uint8_t *)
                 fcn.1802231e0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                               *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3));
        ppuVar4[0x16] = puVar5;
        if (puVar5 == (uint8_t *)0x0) goto code_r0x000180268c26;
    }
    *ppuVar4 = in_R8;
    if ((*in_R8 & 2) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180268bf4;
        puVar5 = (uint8_t *)fcn.1802554c0();
        ppuVar4[2] = puVar5;
        if (puVar5 == (uint8_t *)0x0) goto code_r0x000180268c26;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180268c02;
        puVar5 = (uint8_t *)fcn.1802554c0();
        ppuVar4[3] = puVar5;
        if (puVar5 == (uint8_t *)0x0) goto code_r0x000180268c26;
    }
    *(undefined4 *)((int64_t)ppuVar4 + 0x24) = 0;
    *(undefined4 *)((int64_t)ppuVar4 + 0x2c) = 4;
    pcVar1 = *(code **)(in_R8 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180268c22;
    iVar2 = (*pcVar1)(ppuVar4);
    if (iVar2 != 0) {
        return ppuVar4;
    }
code_r0x000180268c26:
    puVar5 = ppuVar4[2];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180268c2f;
    fcn.180255290(puVar5);
    puVar5 = ppuVar4[3];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180268c38;
    fcn.180255290(puVar5);
    puVar5 = ppuVar4[0x16];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180268c4d;
    fcn.180224990(puVar5, 0x1804e6f68, 0x48);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180268c62;
    fcn.180224990(ppuVar4, 0x1804e6f68, 0x49);
    return (uint8_t **)0x0;
}

// ============================================================
// Function: FUN_180268c80
// Address: 0x180268c80
// Size: 372 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180268c80(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_68h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180268c90;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined4 *)((int64_t)&arg_40h + iVar2) = 0xffffffff;
    *(undefined4 *)((int64_t)&arg_38h + iVar2) = 0xffffffff;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180268cb8;
    iVar3 = fcn.18022ae60(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180268cca;
        iVar1 = fcn.1802a56c0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2));
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180268cd3;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180268ceb;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180268cfd;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
            return 0;
        }
        *(undefined4 *)(in_RCX + 0x2c) = *(undefined4 *)((int64_t)&arg_38h + iVar2);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180268d20;
    iVar3 = fcn.18022ae60(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180268d32;
        iVar1 = fcn.1802a47e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2));
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180268d3b;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180268d53;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180268d65;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
            return 0;
        }
        *(undefined4 *)(in_RCX + 0x24) = *(undefined4 *)((int64_t)&arg_40h + iVar2);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180268d88;
    iVar3 = fcn.18022ae60(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
    if (iVar3 == 0) {
        return 1;
    }
    if (*(int32_t *)(iVar3 + 8) == 5) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180268da3;
        iVar3 = fcn.180267b90(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)(&stack0x00000048 + iVar2));
        if (iVar3 != 0) {
            return 1;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180268dad;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180268dc5;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180268dd7;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_180268e00
// Address: 0x180268e00
// Size: 38 bytes
// ============================================================
uint64_t fcn.180268e00(int64_t arg_40h, int64_t arg_48h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                      int64_t arg_78h, int64_t arg_a0h, int64_t arg_a8h)
{
    undefined8 uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    uint32_t uVar8;
    undefined8 unaff_RBP;
    uint32_t uVar9;
    undefined8 unaff_RSI;
    uint32_t uVar10;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 *puVar11;
    undefined8 unaff_R14;
    uint32_t uVar12;
    undefined8 unaff_R15;
    undefined8 auStackX_18 [2];
    
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    piVar7 = *(int64_t **)(in_RCX + 0x10);
    if (piVar7 == (int64_t *)0x0) {
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar6 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar6) = 0x18025550c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar4 = *(int32_t *)(piVar7 + 1);
    uVar10 = iVar4 - 1;
    if ((*(uint8_t *)((int64_t)piVar7 + 0x14) & 4) == 0) {
        if (iVar4 != 0) {
            uVar1 = *(undefined8 *)(*piVar7 + -8 + (int64_t)iVar4 * 8);
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar6) = 0x1802555d6;
            iVar4 = fcn.1802555f0(uVar1);
            return (uint64_t)(iVar4 + uVar10 * 0x40);
        }
        return (int64_t)iVar4;
    }
    *(undefined8 *)((int64_t)&arg_68h + iVar5 + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_70h + iVar5 + iVar6) = unaff_RSI;
    uVar9 = 0;
    *(undefined8 *)((int64_t)&arg_78h + iVar5 + iVar6) = unaff_R12;
    uVar8 = 0;
    iVar4 = *(int32_t *)((int64_t)piVar7 + 0xc);
    *(undefined8 *)((int64_t)&arg_40h + iVar5 + iVar6) = unaff_R15;
    uVar12 = 0;
    if (0 < iVar4) {
        *(undefined8 *)((int64_t)&arg_60h + iVar5 + iVar6) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_48h + iVar5 + iVar6) = unaff_R14;
        puVar11 = (undefined8 *)*piVar7;
        do {
            uVar1 = *puVar11;
            uVar2 = (int32_t)((uVar8 ^ uVar10) - 1 & ~(uVar8 ^ uVar10)) >> 0x1f;
            uVar9 = uVar9 | uVar2;
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar6) = 0x18025556e;
            uVar3 = fcn.1802555f0(uVar1);
            puVar11 = puVar11 + 1;
            uVar8 = uVar8 + 1;
            uVar12 = uVar12 + (~uVar9 & 0x40) + (uVar3 & uVar2);
        } while ((int32_t)uVar8 < iVar4);
    }
    return (uint64_t)(0xffffffffU - ((int32_t)(~uVar10 - 1 & uVar10) >> 0x1f) & uVar12);
}

// ============================================================
// Function: FUN_180268e30
// Address: 0x180268e30
// Size: 45 bytes
// ============================================================
undefined8 fcn.180268e30(int64_t *param_1)
{
    undefined8 uVar1;
    
    fcn.18045a350();
    if (*(code **)(*param_1 + 0x198) == (code *)0x0) {
        return 1;
    }
    // WARNING: Could not recover jumptable at 0x000180268e5a. Too many branches
    // WARNING: Treating indirect jump as call
    uVar1 = (**(code **)(*param_1 + 0x198))();
    return uVar1;
}

// ============================================================
// Function: FUN_180268e80
// Address: 0x180268e80
// Size: 164 bytes
// ============================================================
undefined8 fcn.180268e80(int64_t param_1)
{
    code *UNRECOVERED_JUMPTABLE;
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x180268e8a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (((param_1 != 0) && (*(int64_t **)(param_1 + 0x18) != (int64_t *)0x0)) && (*(int64_t *)(param_1 + 0x20) != 0)) {
        UNRECOVERED_JUMPTABLE = *(code **)(**(int64_t **)(param_1 + 0x18) + 0x150);
        if (UNRECOVERED_JUMPTABLE == (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180268eb6;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
            *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180268ece;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                          *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                          *(int64_t *)(&stack0x00000050 + iVar1));
            *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180268ee0;
            fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
            return 0;
        }
    // WARNING: Could not recover jumptable at 0x000180268eeb. Too many branches
    // WARNING: Treating indirect jump as call
        uVar2 = (*UNRECOVERED_JUMPTABLE)();
        return uVar2;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180268ef3;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180268f0b;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                  *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180268f1d;
    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
    return 0;
}

