// Chunk 197 - 50 functions

// ============================================================
// Function: FUN_1802637cf
// Address: 0x1802637cf
// Size: 23 bytes
// ============================================================
void fcn.1802637cf(int64_t arg_70h, int64_t arg_78h)
{
    return;
}

// ============================================================
// Function: FUN_1802637e6
// Address: 0x1802637e6
// Size: 212 bytes
// ============================================================
undefined8 fcn.1802637e6(int64_t arg_70h, int64_t arg_78h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h)
{
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1802638ba
// Address: 0x1802638ba
// Size: 72 bytes
// ============================================================
void fcn.1802638ba(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_c0h, int64_t arg_c8h,
                  int64_t arg_d0h, int64_t arg_d8h, int64_t arg_e0h)
{
    int64_t var_20h;
    
    func_0x000180263910();
    return;
}

// ============================================================
// Function: FUN_180263910
// Address: 0x180263910
// Size: 66 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h

undefined8
fcn.180263910(int64_t *placeholder_0, int64_t arg2, int64_t arg3, uint32_t *placeholder_3, int64_t arg_28h,
             int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_78h, int64_t arg_80h,
             int64_t arg_88h, int64_t arg_90h, int64_t arg_d0h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    uint32_t uVar9;
    undefined8 unaff_RDI;
    int32_t iVar10;
    int32_t iVar11;
    undefined8 unaff_R12;
    uint32_t uVar12;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int32_t var_68h;
    int64_t var_64h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    undefined8 uStack_20;
    
    var_18h._0_4_ = (int32_t)arg3;
    uStack_20 = 0x18026392e;
    var_10h = arg2;
    iVar5 = (int32_t)var_18h;
    iVar6 = fcn.18045a350();
    iVar2 = arg_30h;
    iVar6 = -iVar6;
    if (placeholder_0 == (int64_t *)0x0) {
        return 0;
    }
    uVar9 = *placeholder_3;
    *(undefined8 *)((int64_t)&arg_80h + iVar6) = unaff_R12;
    var_58h = *(int64_t *)arg2;
    *(undefined8 *)((int64_t)&arg_78h + iVar6) = unaff_R15;
    uVar12 = uVar9 & 0xc0;
    if ((uVar9 >> 0xc & 1) != 0) {
        var_48h = (int64_t)placeholder_0;
        placeholder_0 = &var_48h;
    }
    *(undefined8 *)((int64_t)&arg_d0h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_90h + iVar6) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_88h + iVar6) = unaff_RDI;
    if ((uVar9 & 6) == 0) {
        if ((uVar9 & 8) == 0) {
            pcVar1 = *(code **)(placeholder_3 + 6);
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263dff;
            (*pcVar1)();
            *(int64_t *)((int64_t)&arg_38h + iVar6) = arg_48h;
            *(int64_t *)((int64_t)&arg_30h + iVar6) = arg_40h;
            *(undefined4 *)((int64_t)&arg_28h + iVar6) = (undefined4)arg_38h;
            *(int64_t *)((int64_t)&var_20h + iVar6) = arg_30h;
            *(char *)((int64_t)&var_18h + iVar6) = (char)arg_28h;
            *(undefined4 *)((int64_t)&var_10h + iVar6) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0xffffffff;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263e4c;
            iVar5 = fcn.1802629a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)(&stack0x00000050 + iVar6), 
                                  *(int64_t *)(&stack0x00000058 + iVar6), *(int64_t *)(&stack0x00000060 + iVar6), 
                                  *(int64_t *)(&stack0x000000a0 + iVar6));
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263e55;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                goto code_r0x000180263e5a;
            }
        } else {
            uVar9 = placeholder_3[1];
            pcVar1 = *(code **)(placeholder_3 + 6);
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263d54;
            (*pcVar1)();
            *(int64_t *)((int64_t)&arg_38h + iVar6) = arg_48h;
            *(int64_t *)((int64_t)&arg_30h + iVar6) = arg_40h;
            *(undefined4 *)((int64_t)&arg_28h + iVar6) = (undefined4)arg_38h;
            *(int64_t *)((int64_t)&var_20h + iVar6) = arg_30h;
            *(char *)((int64_t)&var_18h + iVar6) = (char)arg_28h;
            *(uint32_t *)((int64_t)&var_10h + iVar6) = uVar12;
            *(uint32_t *)((int64_t)&var_8h + iVar6) = uVar9;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263d9a;
            iVar5 = fcn.1802629a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)(&stack0x00000050 + iVar6), 
                                  *(int64_t *)(&stack0x00000058 + iVar6), *(int64_t *)(&stack0x00000060 + iVar6), 
                                  *(int64_t *)(&stack0x000000a0 + iVar6));
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263da3;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
code_r0x000180263e5a:
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263e6d;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_38h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263e7f;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
                return 0;
            }
        }
        if (iVar5 == -1) {
            return 0xffffffff;
        }
code_r0x000180263db6:
        *(int64_t *)var_10h = var_58h;
        return 1;
    }
    if ((uVar9 & 8) == 0) {
        uVar12 = 0;
        uVar9 = (uVar9 & 2 | 0x20) >> 1;
    } else {
        uVar9 = placeholder_3[1];
    }
    var_50h = var_58h;
    if (0 < iVar5) {
        iVar11 = (int32_t)var_58h;
        if ((arg_30h == 0) || (*(char *)arg_30h == '\0')) {
            *(int32_t *)((int64_t)&var_8h + iVar6) = iVar5;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263a22;
            uVar4 = fcn.180296a80(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6));
            var_8h._0_4_ = uVar4;
            iVar5 = (int32_t)var_18h;
            if (iVar2 != 0) {
                *(uint32_t *)(iVar2 + 4) = uVar4;
                iVar10 = (int32_t)var_50h - iVar11;
                *(int32_t *)(iVar2 + 8) = var_68h;
                *(uint32_t *)(iVar2 + 0x10) = (uint32_t)var_64h;
                *(uint32_t *)(iVar2 + 0xc) = var_64h._4_4_;
                *(int32_t *)(iVar2 + 0x14) = iVar10;
                *(undefined *)iVar2 = 1;
                if (((uVar4 & 0x81) == 0) && ((int32_t)var_18h < iVar10 + var_68h)) goto code_r0x000180263ae0;
            }
        } else {
            var_68h = *(int32_t *)(arg_30h + 8);
            var_50h = *(int32_t *)(arg_30h + 0x14) + var_58h;
            var_64h._0_4_ = *(uint32_t *)(arg_30h + 0x10);
            var_64h._4_4_ = *(uint32_t *)(arg_30h + 0xc);
            uVar4 = *(uint32_t *)(arg_30h + 4);
        }
        var_58h = var_50h;
        if (-1 < (char)uVar4) {
            if (-1 < (int32_t)uVar9) {
                if ((uVar9 != var_64h._4_4_) || (uVar12 != (uint32_t)var_64h)) {
                    if ((char)arg_28h != '\0') {
                        return 0xffffffff;
                    }
                    goto code_r0x000180263ae0;
                }
                if (iVar2 != 0) {
                    *(undefined *)iVar2 = 0;
                }
            }
            if ((uVar4 & 1) != 0) {
                var_68h = (iVar11 - (int32_t)var_50h) + iVar5;
            }
            iVar7 = *placeholder_0;
            var_8h._0_4_ = uVar4 & 0xffffff01;
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263ac4;
                iVar7 = fcn.180221f20();
                *placeholder_0 = iVar7;
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b4f;
                iVar5 = fcn.180222010(iVar7);
                while (0 < iVar5) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b5b;
                    var_50h = fcn.180222020(*(int64_t *)((int64_t)&var_10h + iVar6), 
                                            *(int64_t *)((int64_t)&arg_30h + iVar6));
                    pcVar1 = *(code **)(placeholder_3 + 6);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b63;
                    uVar8 = (*pcVar1)();
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b6f;
                    fcn.180261290(&var_50h, uVar8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b77;
                    iVar5 = fcn.180222010(iVar7);
                }
            }
            iVar3 = arg_48h;
            iVar7 = arg_40h;
            if (*placeholder_0 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b86;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b9e;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_38h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263bb0;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
                return 0;
            }
            while( true ) {
                if (var_68h < 1) {
                    if ((char)var_8h != '\0') {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263c61;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263c79;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar6));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263c8b;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
                        return 0;
                    }
                    goto code_r0x000180263db6;
                }
                if (((1 < var_68h) && (*(char *)var_58h == '\0')) && (*(char *)(var_58h + 1) == '\0')) break;
                var_50h = 0;
                pcVar1 = *(code **)(placeholder_3 + 6);
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263beb;
                (*pcVar1)();
                *(int64_t *)((int64_t)&arg_38h + iVar6) = iVar3;
                *(int64_t *)((int64_t)&arg_30h + iVar6) = iVar7;
                *(undefined4 *)((int64_t)&arg_28h + iVar6) = (undefined4)arg_38h;
                *(int64_t *)((int64_t)&var_20h + iVar6) = iVar2;
                *(undefined *)((int64_t)&var_18h + iVar6) = 0;
                *(undefined4 *)((int64_t)&var_10h + iVar6) = 0;
                *(undefined4 *)((int64_t)&var_8h + iVar6) = 0xffffffff;
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263c29;
                iVar5 = fcn.1802629a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)(&stack0x00000050 + iVar6), 
                                      *(int64_t *)(&stack0x00000058 + iVar6), *(int64_t *)(&stack0x00000060 + iVar6), 
                                      *(int64_t *)(&stack0x000000a0 + iVar6));
                if (iVar5 < 1) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263d03;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263d1b;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6));
                    goto code_r0x000180263d20;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263c42;
                iVar5 = fcn.180222110(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar6));
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263cdf;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263cf7;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6));
code_r0x000180263d20:
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263d2d;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
                    pcVar1 = *(code **)(placeholder_3 + 6);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263d31;
                    (*pcVar1)();
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263d3d;
                    fcn.1802612b0(*(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6));
                    return 0;
                }
            }
            var_58h = var_58h + 2;
            if ((char)var_8h == '\0') {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263ca9;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263cc1;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_38h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263cd3;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
                return 0;
            }
            goto code_r0x000180263db6;
        }
    }
code_r0x000180263ae0:
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263ae5;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263afa;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                  *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                  *(int64_t *)((int64_t)&arg_38h + iVar6));
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b09;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
    if (iVar2 != 0) {
        *(undefined *)iVar2 = 0;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b16;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b2e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                  *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                  *(int64_t *)((int64_t)&arg_38h + iVar6));
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b40;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_180263952
// Address: 0x180263952
// Size: 1193 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h

undefined8
fcn.180263910(int64_t *placeholder_0, int64_t arg2, int64_t arg3, uint32_t *placeholder_3, int64_t arg_28h,
             int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_78h, int64_t arg_80h,
             int64_t arg_88h, int64_t arg_90h, int64_t arg_d0h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    uint32_t uVar9;
    undefined8 unaff_RDI;
    int32_t iVar10;
    int32_t iVar11;
    undefined8 unaff_R12;
    uint32_t uVar12;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int32_t var_68h;
    int64_t var_64h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    undefined8 uStack_20;
    
    var_18h._0_4_ = (int32_t)arg3;
    uStack_20 = 0x18026392e;
    var_10h = arg2;
    iVar5 = (int32_t)var_18h;
    iVar6 = fcn.18045a350();
    iVar2 = arg_30h;
    iVar6 = -iVar6;
    if (placeholder_0 == (int64_t *)0x0) {
        return 0;
    }
    uVar9 = *placeholder_3;
    *(undefined8 *)((int64_t)&arg_80h + iVar6) = unaff_R12;
    var_58h = *(int64_t *)arg2;
    *(undefined8 *)((int64_t)&arg_78h + iVar6) = unaff_R15;
    uVar12 = uVar9 & 0xc0;
    if ((uVar9 >> 0xc & 1) != 0) {
        var_48h = (int64_t)placeholder_0;
        placeholder_0 = &var_48h;
    }
    *(undefined8 *)((int64_t)&arg_d0h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_90h + iVar6) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_88h + iVar6) = unaff_RDI;
    if ((uVar9 & 6) == 0) {
        if ((uVar9 & 8) == 0) {
            pcVar1 = *(code **)(placeholder_3 + 6);
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263dff;
            (*pcVar1)();
            *(int64_t *)((int64_t)&arg_38h + iVar6) = arg_48h;
            *(int64_t *)((int64_t)&arg_30h + iVar6) = arg_40h;
            *(undefined4 *)((int64_t)&arg_28h + iVar6) = (undefined4)arg_38h;
            *(int64_t *)((int64_t)&var_20h + iVar6) = arg_30h;
            *(char *)((int64_t)&var_18h + iVar6) = (char)arg_28h;
            *(undefined4 *)((int64_t)&var_10h + iVar6) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0xffffffff;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263e4c;
            iVar5 = fcn.1802629a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)(&stack0x00000050 + iVar6), 
                                  *(int64_t *)(&stack0x00000058 + iVar6), *(int64_t *)(&stack0x00000060 + iVar6), 
                                  *(int64_t *)(&stack0x000000a0 + iVar6));
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263e55;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                goto code_r0x000180263e5a;
            }
        } else {
            uVar9 = placeholder_3[1];
            pcVar1 = *(code **)(placeholder_3 + 6);
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263d54;
            (*pcVar1)();
            *(int64_t *)((int64_t)&arg_38h + iVar6) = arg_48h;
            *(int64_t *)((int64_t)&arg_30h + iVar6) = arg_40h;
            *(undefined4 *)((int64_t)&arg_28h + iVar6) = (undefined4)arg_38h;
            *(int64_t *)((int64_t)&var_20h + iVar6) = arg_30h;
            *(char *)((int64_t)&var_18h + iVar6) = (char)arg_28h;
            *(uint32_t *)((int64_t)&var_10h + iVar6) = uVar12;
            *(uint32_t *)((int64_t)&var_8h + iVar6) = uVar9;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263d9a;
            iVar5 = fcn.1802629a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)(&stack0x00000050 + iVar6), 
                                  *(int64_t *)(&stack0x00000058 + iVar6), *(int64_t *)(&stack0x00000060 + iVar6), 
                                  *(int64_t *)(&stack0x000000a0 + iVar6));
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263da3;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
code_r0x000180263e5a:
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263e6d;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_38h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263e7f;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
                return 0;
            }
        }
        if (iVar5 == -1) {
            return 0xffffffff;
        }
code_r0x000180263db6:
        *(int64_t *)var_10h = var_58h;
        return 1;
    }
    if ((uVar9 & 8) == 0) {
        uVar12 = 0;
        uVar9 = (uVar9 & 2 | 0x20) >> 1;
    } else {
        uVar9 = placeholder_3[1];
    }
    var_50h = var_58h;
    if (0 < iVar5) {
        iVar11 = (int32_t)var_58h;
        if ((arg_30h == 0) || (*(char *)arg_30h == '\0')) {
            *(int32_t *)((int64_t)&var_8h + iVar6) = iVar5;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263a22;
            uVar4 = fcn.180296a80(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6));
            var_8h._0_4_ = uVar4;
            iVar5 = (int32_t)var_18h;
            if (iVar2 != 0) {
                *(uint32_t *)(iVar2 + 4) = uVar4;
                iVar10 = (int32_t)var_50h - iVar11;
                *(int32_t *)(iVar2 + 8) = var_68h;
                *(uint32_t *)(iVar2 + 0x10) = (uint32_t)var_64h;
                *(uint32_t *)(iVar2 + 0xc) = var_64h._4_4_;
                *(int32_t *)(iVar2 + 0x14) = iVar10;
                *(undefined *)iVar2 = 1;
                if (((uVar4 & 0x81) == 0) && ((int32_t)var_18h < iVar10 + var_68h)) goto code_r0x000180263ae0;
            }
        } else {
            var_68h = *(int32_t *)(arg_30h + 8);
            var_50h = *(int32_t *)(arg_30h + 0x14) + var_58h;
            var_64h._0_4_ = *(uint32_t *)(arg_30h + 0x10);
            var_64h._4_4_ = *(uint32_t *)(arg_30h + 0xc);
            uVar4 = *(uint32_t *)(arg_30h + 4);
        }
        var_58h = var_50h;
        if (-1 < (char)uVar4) {
            if (-1 < (int32_t)uVar9) {
                if ((uVar9 != var_64h._4_4_) || (uVar12 != (uint32_t)var_64h)) {
                    if ((char)arg_28h != '\0') {
                        return 0xffffffff;
                    }
                    goto code_r0x000180263ae0;
                }
                if (iVar2 != 0) {
                    *(undefined *)iVar2 = 0;
                }
            }
            if ((uVar4 & 1) != 0) {
                var_68h = (iVar11 - (int32_t)var_50h) + iVar5;
            }
            iVar7 = *placeholder_0;
            var_8h._0_4_ = uVar4 & 0xffffff01;
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263ac4;
                iVar7 = fcn.180221f20();
                *placeholder_0 = iVar7;
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b4f;
                iVar5 = fcn.180222010(iVar7);
                while (0 < iVar5) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b5b;
                    var_50h = fcn.180222020(*(int64_t *)((int64_t)&var_10h + iVar6), 
                                            *(int64_t *)((int64_t)&arg_30h + iVar6));
                    pcVar1 = *(code **)(placeholder_3 + 6);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b63;
                    uVar8 = (*pcVar1)();
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b6f;
                    fcn.180261290(&var_50h, uVar8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b77;
                    iVar5 = fcn.180222010(iVar7);
                }
            }
            iVar3 = arg_48h;
            iVar7 = arg_40h;
            if (*placeholder_0 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b86;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b9e;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_38h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263bb0;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
                return 0;
            }
            while( true ) {
                if (var_68h < 1) {
                    if ((char)var_8h != '\0') {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263c61;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263c79;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar6));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263c8b;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
                        return 0;
                    }
                    goto code_r0x000180263db6;
                }
                if (((1 < var_68h) && (*(char *)var_58h == '\0')) && (*(char *)(var_58h + 1) == '\0')) break;
                var_50h = 0;
                pcVar1 = *(code **)(placeholder_3 + 6);
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263beb;
                (*pcVar1)();
                *(int64_t *)((int64_t)&arg_38h + iVar6) = iVar3;
                *(int64_t *)((int64_t)&arg_30h + iVar6) = iVar7;
                *(undefined4 *)((int64_t)&arg_28h + iVar6) = (undefined4)arg_38h;
                *(int64_t *)((int64_t)&var_20h + iVar6) = iVar2;
                *(undefined *)((int64_t)&var_18h + iVar6) = 0;
                *(undefined4 *)((int64_t)&var_10h + iVar6) = 0;
                *(undefined4 *)((int64_t)&var_8h + iVar6) = 0xffffffff;
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263c29;
                iVar5 = fcn.1802629a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)(&stack0x00000050 + iVar6), 
                                      *(int64_t *)(&stack0x00000058 + iVar6), *(int64_t *)(&stack0x00000060 + iVar6), 
                                      *(int64_t *)(&stack0x000000a0 + iVar6));
                if (iVar5 < 1) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263d03;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263d1b;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6));
                    goto code_r0x000180263d20;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263c42;
                iVar5 = fcn.180222110(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar6));
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263cdf;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263cf7;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6));
code_r0x000180263d20:
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263d2d;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
                    pcVar1 = *(code **)(placeholder_3 + 6);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263d31;
                    (*pcVar1)();
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263d3d;
                    fcn.1802612b0(*(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6));
                    return 0;
                }
            }
            var_58h = var_58h + 2;
            if ((char)var_8h == '\0') {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263ca9;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263cc1;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_38h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263cd3;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
                return 0;
            }
            goto code_r0x000180263db6;
        }
    }
code_r0x000180263ae0:
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263ae5;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263afa;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                  *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                  *(int64_t *)((int64_t)&arg_38h + iVar6));
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b09;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
    if (iVar2 != 0) {
        *(undefined *)iVar2 = 0;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b16;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b2e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                  *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                  *(int64_t *)((int64_t)&arg_38h + iVar6));
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b40;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_180263dfb
// Address: 0x180263dfb
// Size: 158 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h

undefined8
fcn.180263910(int64_t *placeholder_0, int64_t arg2, int64_t arg3, uint32_t *placeholder_3, int64_t arg_28h,
             int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_78h, int64_t arg_80h,
             int64_t arg_88h, int64_t arg_90h, int64_t arg_d0h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    uint32_t uVar9;
    undefined8 unaff_RDI;
    int32_t iVar10;
    int32_t iVar11;
    undefined8 unaff_R12;
    uint32_t uVar12;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int32_t var_68h;
    int64_t var_64h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    undefined8 uStack_20;
    
    var_18h._0_4_ = (int32_t)arg3;
    uStack_20 = 0x18026392e;
    var_10h = arg2;
    iVar5 = (int32_t)var_18h;
    iVar6 = fcn.18045a350();
    iVar2 = arg_30h;
    iVar6 = -iVar6;
    if (placeholder_0 == (int64_t *)0x0) {
        return 0;
    }
    uVar9 = *placeholder_3;
    *(undefined8 *)((int64_t)&arg_80h + iVar6) = unaff_R12;
    var_58h = *(int64_t *)arg2;
    *(undefined8 *)((int64_t)&arg_78h + iVar6) = unaff_R15;
    uVar12 = uVar9 & 0xc0;
    if ((uVar9 >> 0xc & 1) != 0) {
        var_48h = (int64_t)placeholder_0;
        placeholder_0 = &var_48h;
    }
    *(undefined8 *)((int64_t)&arg_d0h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_90h + iVar6) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_88h + iVar6) = unaff_RDI;
    if ((uVar9 & 6) == 0) {
        if ((uVar9 & 8) == 0) {
            pcVar1 = *(code **)(placeholder_3 + 6);
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263dff;
            (*pcVar1)();
            *(int64_t *)((int64_t)&arg_38h + iVar6) = arg_48h;
            *(int64_t *)((int64_t)&arg_30h + iVar6) = arg_40h;
            *(undefined4 *)((int64_t)&arg_28h + iVar6) = (undefined4)arg_38h;
            *(int64_t *)((int64_t)&var_20h + iVar6) = arg_30h;
            *(char *)((int64_t)&var_18h + iVar6) = (char)arg_28h;
            *(undefined4 *)((int64_t)&var_10h + iVar6) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0xffffffff;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263e4c;
            iVar5 = fcn.1802629a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)(&stack0x00000050 + iVar6), 
                                  *(int64_t *)(&stack0x00000058 + iVar6), *(int64_t *)(&stack0x00000060 + iVar6), 
                                  *(int64_t *)(&stack0x000000a0 + iVar6));
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263e55;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                goto code_r0x000180263e5a;
            }
        } else {
            uVar9 = placeholder_3[1];
            pcVar1 = *(code **)(placeholder_3 + 6);
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263d54;
            (*pcVar1)();
            *(int64_t *)((int64_t)&arg_38h + iVar6) = arg_48h;
            *(int64_t *)((int64_t)&arg_30h + iVar6) = arg_40h;
            *(undefined4 *)((int64_t)&arg_28h + iVar6) = (undefined4)arg_38h;
            *(int64_t *)((int64_t)&var_20h + iVar6) = arg_30h;
            *(char *)((int64_t)&var_18h + iVar6) = (char)arg_28h;
            *(uint32_t *)((int64_t)&var_10h + iVar6) = uVar12;
            *(uint32_t *)((int64_t)&var_8h + iVar6) = uVar9;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263d9a;
            iVar5 = fcn.1802629a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)(&stack0x00000050 + iVar6), 
                                  *(int64_t *)(&stack0x00000058 + iVar6), *(int64_t *)(&stack0x00000060 + iVar6), 
                                  *(int64_t *)(&stack0x000000a0 + iVar6));
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263da3;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
code_r0x000180263e5a:
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263e6d;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_38h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263e7f;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
                return 0;
            }
        }
        if (iVar5 == -1) {
            return 0xffffffff;
        }
code_r0x000180263db6:
        *(int64_t *)var_10h = var_58h;
        return 1;
    }
    if ((uVar9 & 8) == 0) {
        uVar12 = 0;
        uVar9 = (uVar9 & 2 | 0x20) >> 1;
    } else {
        uVar9 = placeholder_3[1];
    }
    var_50h = var_58h;
    if (0 < iVar5) {
        iVar11 = (int32_t)var_58h;
        if ((arg_30h == 0) || (*(char *)arg_30h == '\0')) {
            *(int32_t *)((int64_t)&var_8h + iVar6) = iVar5;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263a22;
            uVar4 = fcn.180296a80(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6));
            var_8h._0_4_ = uVar4;
            iVar5 = (int32_t)var_18h;
            if (iVar2 != 0) {
                *(uint32_t *)(iVar2 + 4) = uVar4;
                iVar10 = (int32_t)var_50h - iVar11;
                *(int32_t *)(iVar2 + 8) = var_68h;
                *(uint32_t *)(iVar2 + 0x10) = (uint32_t)var_64h;
                *(uint32_t *)(iVar2 + 0xc) = var_64h._4_4_;
                *(int32_t *)(iVar2 + 0x14) = iVar10;
                *(undefined *)iVar2 = 1;
                if (((uVar4 & 0x81) == 0) && ((int32_t)var_18h < iVar10 + var_68h)) goto code_r0x000180263ae0;
            }
        } else {
            var_68h = *(int32_t *)(arg_30h + 8);
            var_50h = *(int32_t *)(arg_30h + 0x14) + var_58h;
            var_64h._0_4_ = *(uint32_t *)(arg_30h + 0x10);
            var_64h._4_4_ = *(uint32_t *)(arg_30h + 0xc);
            uVar4 = *(uint32_t *)(arg_30h + 4);
        }
        var_58h = var_50h;
        if (-1 < (char)uVar4) {
            if (-1 < (int32_t)uVar9) {
                if ((uVar9 != var_64h._4_4_) || (uVar12 != (uint32_t)var_64h)) {
                    if ((char)arg_28h != '\0') {
                        return 0xffffffff;
                    }
                    goto code_r0x000180263ae0;
                }
                if (iVar2 != 0) {
                    *(undefined *)iVar2 = 0;
                }
            }
            if ((uVar4 & 1) != 0) {
                var_68h = (iVar11 - (int32_t)var_50h) + iVar5;
            }
            iVar7 = *placeholder_0;
            var_8h._0_4_ = uVar4 & 0xffffff01;
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263ac4;
                iVar7 = fcn.180221f20();
                *placeholder_0 = iVar7;
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b4f;
                iVar5 = fcn.180222010(iVar7);
                while (0 < iVar5) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b5b;
                    var_50h = fcn.180222020(*(int64_t *)((int64_t)&var_10h + iVar6), 
                                            *(int64_t *)((int64_t)&arg_30h + iVar6));
                    pcVar1 = *(code **)(placeholder_3 + 6);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b63;
                    uVar8 = (*pcVar1)();
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b6f;
                    fcn.180261290(&var_50h, uVar8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b77;
                    iVar5 = fcn.180222010(iVar7);
                }
            }
            iVar3 = arg_48h;
            iVar7 = arg_40h;
            if (*placeholder_0 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b86;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b9e;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_38h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263bb0;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
                return 0;
            }
            while( true ) {
                if (var_68h < 1) {
                    if ((char)var_8h != '\0') {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263c61;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263c79;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar6));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263c8b;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
                        return 0;
                    }
                    goto code_r0x000180263db6;
                }
                if (((1 < var_68h) && (*(char *)var_58h == '\0')) && (*(char *)(var_58h + 1) == '\0')) break;
                var_50h = 0;
                pcVar1 = *(code **)(placeholder_3 + 6);
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263beb;
                (*pcVar1)();
                *(int64_t *)((int64_t)&arg_38h + iVar6) = iVar3;
                *(int64_t *)((int64_t)&arg_30h + iVar6) = iVar7;
                *(undefined4 *)((int64_t)&arg_28h + iVar6) = (undefined4)arg_38h;
                *(int64_t *)((int64_t)&var_20h + iVar6) = iVar2;
                *(undefined *)((int64_t)&var_18h + iVar6) = 0;
                *(undefined4 *)((int64_t)&var_10h + iVar6) = 0;
                *(undefined4 *)((int64_t)&var_8h + iVar6) = 0xffffffff;
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263c29;
                iVar5 = fcn.1802629a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)(&stack0x00000050 + iVar6), 
                                      *(int64_t *)(&stack0x00000058 + iVar6), *(int64_t *)(&stack0x00000060 + iVar6), 
                                      *(int64_t *)(&stack0x000000a0 + iVar6));
                if (iVar5 < 1) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263d03;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263d1b;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6));
                    goto code_r0x000180263d20;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263c42;
                iVar5 = fcn.180222110(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar6));
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263cdf;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263cf7;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6));
code_r0x000180263d20:
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263d2d;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
                    pcVar1 = *(code **)(placeholder_3 + 6);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263d31;
                    (*pcVar1)();
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263d3d;
                    fcn.1802612b0(*(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6));
                    return 0;
                }
            }
            var_58h = var_58h + 2;
            if ((char)var_8h == '\0') {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263ca9;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263cc1;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_38h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263cd3;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
                return 0;
            }
            goto code_r0x000180263db6;
        }
    }
code_r0x000180263ae0:
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263ae5;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263afa;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                  *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                  *(int64_t *)((int64_t)&arg_38h + iVar6));
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b09;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
    if (iVar2 != 0) {
        *(undefined *)iVar2 = 0;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b16;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b2e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                  *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                  *(int64_t *)((int64_t)&arg_38h + iVar6));
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263b40;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_180263ea0
// Address: 0x180263ea0
// Size: 1044 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.180263ea0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_d8h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    int64_t *in_RCX;
    uint32_t uVar8;
    int64_t in_RDX;
    code *pcVar9;
    uint32_t uVar10;
    undefined4 uVar12;
    char *in_R8;
    uint64_t in_R9;
    code *pcVar13;
    code *pcVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    code *pcStack_30;
    code *pcVar11;
    
    pcStack_30 = (code *)0x180263ec2;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    pcVar14 = (code *)0x0;
    uVar12 = 1;
    *(undefined4 *)((int64_t)&var_8h + iVar3) = 1;
    iVar2 = (int32_t)in_R9;
    iVar5 = *(int64_t *)(in_R8 + 0x18);
    if ((*in_R8 != '\0') && (*in_RCX == 0)) {
        return 0;
    }
    pcVar13 = pcVar14;
    if (iVar5 != 0) {
        iVar4 = 0x28;
        if ((*(uint8_t *)(iVar5 + 8) & 8) == 0) {
            iVar4 = 0x18;
        }
        pcVar13 = *(code **)(iVar4 + iVar5);
    }
    uVar8 = *(uint32_t *)(&stack0x00000068 + iVar3);
    // switch table (7 cases) at 0x180264298
    switch(*in_R8) {
    case '\0':
        iVar5 = *(int64_t *)(in_R8 + 8);
        in_R9 = in_R9 & 0xffffffff;
        *(uint32_t *)(&stack0xfffffffffffffff8 + iVar3) = uVar8;
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&pcStack_30 + iVar3) = 0x180263f59;
            uVar7 = func_0x0001802644b0(in_RCX, in_RDX, in_R8);
            return uVar7;
        }
        break;
    case '\x02':
        if (iVar2 != -1) {
            *(undefined8 *)((int64_t)&pcStack_30 + iVar3) = 0x180263fc3;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000000 + iVar3));
            *(undefined8 *)((int64_t)&pcStack_30 + iVar3) = 0x180263fdb;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000000 + iVar3), 
                          *(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&iStackX_18 + iVar3 + -8), 
                          *(int64_t *)(&stack0x00000028 + iVar3));
            *(undefined8 *)((int64_t)&pcStack_30 + iVar3) = 0x180263fed;
            fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar3));
            return 0xffffffff;
        }
        if (pcVar13 != (code *)0x0) {
            *(undefined8 *)((int64_t)&pcStack_30 + iVar3) = 0x18026400a;
            iVar2 = (*pcVar13)(6, in_RCX, in_R8, 0);
            if (iVar2 == 0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&pcStack_30 + iVar3) = 0x180264019;
        iVar2 = fcn.1802d4410(in_RCX, in_R8);
        if ((iVar2 < 0) || (*(int32_t *)(in_R8 + 0x10) <= iVar2)) {
            if (pcVar13 != (code *)0x0) {
                *(code **)((int64_t)&pcStack_30 + iVar3) = case.0x180263f35.3;
                (*pcVar13)(7, in_RCX, in_R8, 0);
                return 0;
            }
            return 0;
        }
        iVar5 = *(int64_t *)(in_R8 + 8) + (int64_t)iVar2 * 0x20;
        *(undefined8 *)((int64_t)&pcStack_30 + iVar3) = 0x18026403b;
        in_RCX = (int64_t *)fcn.1802d4420(in_RCX, iVar5);
        in_R9 = 0xffffffff;
        *(uint32_t *)(&stack0xfffffffffffffff8 + iVar3) = uVar8;
        break;
    default:
        return 0;
    case '\x04':
        pcVar14 = *(code **)(iVar5 + 0x28);
        *(uint32_t *)(&stack0xfffffffffffffff8 + iVar3) = uVar8;
        *(undefined8 *)((int64_t)&pcStack_30 + iVar3) = 0x1802640a3;
        uVar7 = (*pcVar14)(in_RCX, in_RDX, in_R8, in_R9 & 0xffffffff);
        return uVar7;
    case '\x05':
        if (iVar2 == -1) {
            *(uint32_t *)(&stack0xfffffffffffffff8 + iVar3) = uVar8;
            *(undefined8 *)((int64_t)&pcStack_30 + iVar3) = 0x180263fb4;
            uVar7 = func_0x0001802644b0(in_RCX, in_RDX, in_R8, 0xffffffff);
            return uVar7;
        }
        *(undefined8 *)((int64_t)&pcStack_30 + iVar3) = 0x180263f68;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000000 + iVar3));
        *(undefined8 *)((int64_t)&pcStack_30 + iVar3) = 0x180263f80;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000000 + iVar3), 
                      *(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&iStackX_18 + iVar3 + -8), 
                      *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&pcStack_30 + iVar3) = 0x180263f92;
        fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar3));
        return 0xffffffff;
    case '\x06':
        if ((uVar8 >> 0xb & 1) != 0) {
            uVar12 = 2;
        }
        *(undefined4 *)((int64_t)&var_8h + iVar3) = uVar12;
    case '\x01':
        *(undefined8 *)((int64_t)&pcStack_30 + iVar3) = 0x1802640cd;
        iVar1 = func_0x0001802d4270((int64_t)&arg_58h + iVar3, in_RDX, in_RCX, in_R8);
        if (iVar1 < 0) {
            return 0;
        }
        if (0 < iVar1) {
            return (uint64_t)*(uint32_t *)((int64_t)&arg_58h + iVar3);
        }
        iVar1 = 0x10;
        if (iVar2 != -1) {
            iVar1 = iVar2;
        }
        *(undefined4 *)((int64_t)&arg_58h + iVar3) = 0;
        *(int32_t *)((int64_t)&iStackX_18 + iVar3 + -8) = iVar1;
        uVar10 = uVar8 & 0xffffff3f;
        if (iVar2 != -1) {
            uVar10 = uVar8;
        }
        *(uint32_t *)((int64_t)&var_8h + iVar3 + 4) = uVar10;
        pcVar9 = pcVar14;
        if (pcVar13 != (code *)0x0) {
            *(undefined8 *)((int64_t)&pcStack_30 + iVar3) = 0x180264121;
            iVar2 = (*pcVar13)(6, in_RCX, in_R8, 0);
            if (iVar2 == 0) {
                return 0;
            }
            pcVar9 = (code *)(uint64_t)*(uint32_t *)((int64_t)&arg_58h + iVar3);
        }
        pcVar11 = pcVar14;
        if (0 < *(int32_t *)(in_R8 + 0x10)) {
            do {
                *(undefined8 *)((int64_t)&pcStack_30 + iVar3) = 0x180264151;
                iVar5 = fcn.1802d3f90(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), 
                                      *(int64_t *)(&stack0x00000000 + iVar3), *(int64_t *)((int64_t)&var_8h + iVar3), 
                                      *(int64_t *)((int64_t)&iStackX_18 + iVar3 + -8));
                if (iVar5 == 0) {
                    return 0;
                }
                *(undefined8 *)((int64_t)&pcStack_30 + iVar3) = 0x180264168;
                uVar6 = fcn.1802d4420(in_RCX, iVar5);
                *(undefined4 *)(&stack0xfffffffffffffff8 + iVar3) = *(undefined4 *)((int64_t)&var_8h + iVar3 + 4);
                *(undefined8 *)((int64_t)&pcStack_30 + iVar3) = 0x180264183;
                iVar2 = func_0x000180264940(uVar6, 0, iVar5, 0xffffffff);
                if (iVar2 == -1) {
                    return 0xffffffff;
                }
                if (0x7fffffff - *(int32_t *)((int64_t)&arg_58h + iVar3) < iVar2) {
                    return 0xffffffff;
                }
                uVar8 = *(int32_t *)((int64_t)&arg_58h + iVar3) + iVar2;
                pcVar9 = (code *)(uint64_t)uVar8;
                uVar10 = (int32_t)pcVar11 + 1;
                pcVar11 = (code *)(uint64_t)uVar10;
                *(uint32_t *)((int64_t)&arg_58h + iVar3) = uVar8;
            } while ((int32_t)uVar10 < *(int32_t *)(in_R8 + 0x10));
            uVar10 = *(uint32_t *)((int64_t)&var_8h + iVar3 + 4);
        }
        uVar12 = *(undefined4 *)((int64_t)&iStackX_18 + iVar3 + -8);
        iVar2 = *(int32_t *)((int64_t)&var_8h + iVar3);
        *(undefined8 *)((int64_t)&pcStack_30 + iVar3) = 0x1802641cd;
        uVar7 = func_0x000180296c90(iVar2, pcVar9, uVar12);
        *(int32_t *)((int64_t)&var_8h + iVar3 + 4) = (int32_t)uVar7;
        if (in_RDX == 0) {
            return uVar7;
        }
        if ((int32_t)uVar7 == -1) {
            return uVar7;
        }
        *(uint32_t *)(&stack0xfffffffffffffff8 + iVar3) = uVar10;
        *(undefined8 *)((int64_t)&pcStack_30 + iVar3) = 0x1802641fd;
        func_0x000180296d10(in_RDX, iVar2, *(undefined4 *)((int64_t)&arg_58h + iVar3), uVar12);
        if (0 < *(int32_t *)(in_R8 + 0x10)) {
            do {
                *(undefined8 *)((int64_t)&pcStack_30 + iVar3) = 0x180264221;
                iVar5 = fcn.1802d3f90(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), 
                                      *(int64_t *)(&stack0x00000000 + iVar3), *(int64_t *)((int64_t)&var_8h + iVar3), 
                                      *(int64_t *)((int64_t)&iStackX_18 + iVar3 + -8));
                if (iVar5 == 0) {
                    return 0;
                }
                *(undefined8 *)((int64_t)&pcStack_30 + iVar3) = 0x180264238;
                uVar6 = fcn.1802d4420(in_RCX, iVar5);
                *(uint32_t *)(&stack0xfffffffffffffff8 + iVar3) = uVar10;
                *(undefined8 *)((int64_t)&pcStack_30 + iVar3) = 0x180264251;
                func_0x000180264940(uVar6, in_RDX, iVar5, 0xffffffff);
                uVar8 = (int32_t)pcVar14 + 1;
                pcVar14 = (code *)(uint64_t)uVar8;
            } while ((int32_t)uVar8 < *(int32_t *)(in_R8 + 0x10));
            iVar2 = *(int32_t *)((int64_t)&var_8h + iVar3);
        }
        if (iVar2 == 2) {
            *(undefined8 *)((int64_t)&pcStack_30 + iVar3) = 0x18026426f;
            func_0x000180296cf0(in_RDX);
        }
        if (pcVar13 != (code *)0x0) {
            *(undefined8 *)((int64_t)&pcStack_30 + iVar3) = 0x180264285;
            iVar2 = (*pcVar13)(7, in_RCX, in_R8, 0);
            if (iVar2 == 0) {
                return 0;
            }
        }
        return (uint64_t)*(uint32_t *)((int64_t)&var_8h + iVar3 + 4);
    }
    *(undefined8 *)((int64_t)&pcStack_30 + iVar3) = 0x180264053;
    uVar7 = func_0x000180264940(in_RCX, in_RDX, iVar5, in_R9);
    return uVar7;
}

// ============================================================
// Function: FUN_1802642c0
// Address: 0x1802642c0
// Size: 25 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.1802642c0(int64_t arg_30h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined4 uVar6;
    undefined8 unaff_R14;
    undefined8 auStackX_8 [4];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar6 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = in_RCX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar2 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar2 + 0x10) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_8 + iVar2 + 8) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar2) = 0x1802645e2;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_RDX != (int64_t *)0x0) && (*in_RDX == 0)) {
        *(undefined4 *)((int64_t)&arg_30h + iVar3 + iVar2) = uVar6;
        *(undefined8 *)((int64_t)&arg_70h + iVar3 + iVar2) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar2) = 0x18026461d;
        uVar1 = fcn.180263ea0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x000000e0 + iVar3 + iVar2));
        if ((int32_t)uVar1 < 1) {
            return (uint64_t)uVar1;
        }
        *(undefined8 *)((int64_t)&arg_78h + iVar3 + iVar2) = unaff_R14;
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar2) = 0x18026464d;
        iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_30h + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000038 + iVar3 + iVar2));
        if (iVar4 == 0) {
            uVar5 = 0xffffffff;
        } else {
            *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2) = iVar4;
            *(undefined4 *)((int64_t)&arg_30h + iVar3 + iVar2) = uVar6;
            *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar2) = 0x18026468d;
            fcn.180263ea0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar2), *(int64_t *)(&stack0x00000058 + iVar3 + iVar2)
                          , *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                          *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2), 
                          *(int64_t *)(&stack0x000000e0 + iVar3 + iVar2));
            uVar5 = (uint64_t)uVar1;
            *in_RDX = iVar4;
        }
        return uVar5;
    }
    *(undefined4 *)((int64_t)&arg_30h + iVar3 + iVar2) = uVar6;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar2) = 0x1802646a8;
    uVar5 = fcn.180263ea0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar2), *(int64_t *)(&stack0x00000058 + iVar3 + iVar2)
                          , *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                          *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2), 
                          *(int64_t *)(&stack0x000000e0 + iVar3 + iVar2));
    return uVar5;
}

// ============================================================
// Function: FUN_1802642e0
// Address: 0x1802642e0
// Size: 456 bytes
// ============================================================
uint64_t fcn.1802642e0(uint32_t **placeholder_0, int64_t arg2, int64_t arg_30h, int64_t arg_40h)
{
    int32_t *piVar1;
    int32_t iVar2;
    code *pcVar3;
    uint32_t *puVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint32_t uVar7;
    int64_t iVar8;
    uint32_t *in_R8;
    char *in_R9;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802642f0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((*(int64_t *)(in_R9 + 0x18) != 0) &&
       (pcVar3 = *(code **)(*(int64_t *)(in_R9 + 0x18) + 0x30), pcVar3 != (code *)0x0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026430d;
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar1 = (int32_t *)(in_R9 + 4);
    if ((*in_R9 == '\0') && (*piVar1 == 1)) {
code_r0x000180264338:
        if (*piVar1 == -4) {
            uVar7 = **placeholder_0;
            placeholder_0 = (uint32_t **)(*placeholder_0 + 2);
            *in_R8 = uVar7;
        } else {
            uVar7 = *in_R8;
        }
    } else {
        if (*placeholder_0 == (uint32_t *)0x0) {
            return 0xffffffff;
        }
        if (*in_R9 != '\x05') goto code_r0x000180264338;
        uVar7 = (*placeholder_0)[1];
        *in_R8 = uVar7;
    }
    // switch table (32 cases) at 0x180264468
    switch(uVar7) {
    default:
        puVar4 = *placeholder_0;
        if ((*(int32_t *)(in_R9 + 0x20) == 0x800) && ((*(uint8_t *)(puVar4 + 4) & 0x10) != 0)) {
            if (arg2 == 0) {
                return 0xfffffffe;
            }
            *(int64_t *)(puVar4 + 2) = arg2;
            *puVar4 = 0;
            return 0xfffffffe;
        }
        iVar8 = *(int64_t *)(puVar4 + 2);
        uVar7 = *puVar4;
        break;
    case 1:
        iVar2 = *(int32_t *)placeholder_0;
        if (iVar2 == -1) {
            return 0xffffffff;
        }
        if (*piVar1 != -4) {
            if (iVar2 != 0) {
                if (0 < *(int32_t *)(in_R9 + 0x20)) {
                    return 0xffffffff;
                }
                *(char *)((int64_t)&arg_40h + iVar5) = (char)iVar2;
                iVar8 = (int64_t)&arg_40h + iVar5;
                uVar7 = 1;
                break;
            }
            if (*(int32_t *)(in_R9 + 0x20) == 0) {
                return 0xffffffff;
            }
        }
        *(char *)((int64_t)&arg_40h + iVar5) = (char)iVar2;
        iVar8 = (int64_t)&arg_40h + iVar5;
        uVar7 = 1;
        break;
    case 2:
    case 10:
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180264412;
        uVar6 = fcn.1802609f0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)(&stack0x00000048 + iVar5));
        return uVar6;
    case 3:
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802643f6;
        uVar6 = fcn.1802a9370(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                              , *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                              *(int64_t *)(&stack0x00000048 + iVar5));
        return uVar6;
    case 5:
        iVar8 = 0;
        uVar7 = 0;
        break;
    case 6:
        iVar8 = *(int64_t *)(*placeholder_0 + 6);
        uVar7 = (*placeholder_0)[5];
        if (iVar8 == 0) {
            return 0xffffffff;
        }
        if (uVar7 == 0) {
            return 0xffffffff;
        }
        break;
    case 0xffffffff:
        return 0xfffffffe;
    }
    if ((arg2 != 0) && (uVar7 != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180264460;
        fcn.180498030(arg2, iVar8, (int64_t)(int32_t)uVar7);
    }
    return (uint64_t)uVar7;
}

// ============================================================
// Function: FUN_1802644b0
// Address: 0x1802644b0
// Size: 278 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1802644b0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    uint32_t uVar1;
    int64_t arg2;
    bool bVar2;
    uint32_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    int64_t in_R8;
    uint64_t in_R9;
    undefined8 unaff_R14;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t aiStackX_10 [2];
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1802644c7;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined4 *)((int64_t)&arg_48h + iVar4) = *(undefined4 *)(in_R8 + 4);
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802644ed;
    uVar3 = fcn.1802642e0(in_RCX, 0, *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4))
    ;
    uVar1 = *(uint32_t *)((int64_t)&arg_48h + iVar4);
    if ((uVar1 - 0x10 < 2) || (bVar2 = true, uVar1 == 0xfffffffd)) {
        bVar2 = false;
    }
    if (uVar3 != 0xffffffff) {
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
        uVar5 = 0;
        if (uVar3 != 0xfffffffe) {
            uVar5 = (uint64_t)uVar3;
        }
        uVar6 = 2;
        if (uVar3 != 0xfffffffe) {
            uVar6 = 0;
        }
        uVar7 = in_R9 & 0xffffffff;
        if ((int32_t)in_R9 == -1) {
            uVar7 = (uint64_t)uVar1;
        }
        if (in_RDX != (int64_t *)0x0) {
            if (bVar2) {
                *(undefined4 *)((int64_t)&var_8h + iVar4) = *(undefined4 *)((int64_t)&arg_58h + iVar4);
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026456d;
                func_0x000180296d10(in_RDX, uVar6, uVar5, uVar7);
            }
            arg2 = *in_RDX;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264580;
            fcn.1802642e0(in_RCX, arg2, *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar4));
            if (uVar3 == 0xfffffffe) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026458d;
                func_0x000180296cf0(in_RDX);
            } else {
                *in_RDX = *in_RDX + (int64_t)(int32_t)uVar5;
            }
        }
        if (bVar2) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802645a6;
            uVar5 = func_0x000180296c90(uVar6, uVar5, uVar7);
        }
        return uVar5;
    }
    return 0;
}

// ============================================================
// Function: FUN_1802645d0
// Address: 0x1802645d0
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.1802642c0(int64_t arg_30h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined4 uVar6;
    undefined8 unaff_R14;
    undefined8 auStackX_8 [4];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar6 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = in_RCX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar2 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar2 + 0x10) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_8 + iVar2 + 8) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar2) = 0x1802645e2;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_RDX != (int64_t *)0x0) && (*in_RDX == 0)) {
        *(undefined4 *)((int64_t)&arg_30h + iVar3 + iVar2) = uVar6;
        *(undefined8 *)((int64_t)&arg_70h + iVar3 + iVar2) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar2) = 0x18026461d;
        uVar1 = fcn.180263ea0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x000000e0 + iVar3 + iVar2));
        if ((int32_t)uVar1 < 1) {
            return (uint64_t)uVar1;
        }
        *(undefined8 *)((int64_t)&arg_78h + iVar3 + iVar2) = unaff_R14;
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar2) = 0x18026464d;
        iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_30h + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000038 + iVar3 + iVar2));
        if (iVar4 == 0) {
            uVar5 = 0xffffffff;
        } else {
            *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2) = iVar4;
            *(undefined4 *)((int64_t)&arg_30h + iVar3 + iVar2) = uVar6;
            *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar2) = 0x18026468d;
            fcn.180263ea0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar2), *(int64_t *)(&stack0x00000058 + iVar3 + iVar2)
                          , *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                          *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2), 
                          *(int64_t *)(&stack0x000000e0 + iVar3 + iVar2));
            uVar5 = (uint64_t)uVar1;
            *in_RDX = iVar4;
        }
        return uVar5;
    }
    *(undefined4 *)((int64_t)&arg_30h + iVar3 + iVar2) = uVar6;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar2) = 0x1802646a8;
    uVar5 = fcn.180263ea0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar2), *(int64_t *)(&stack0x00000058 + iVar3 + iVar2)
                          , *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                          *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2), 
                          *(int64_t *)(&stack0x000000e0 + iVar3 + iVar2));
    return uVar5;
}

// ============================================================
// Function: FUN_180264611
// Address: 0x180264611
// Size: 34 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.1802642c0(int64_t arg_30h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined4 uVar6;
    undefined8 unaff_R14;
    undefined8 auStackX_8 [4];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar6 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = in_RCX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar2 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar2 + 0x10) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_8 + iVar2 + 8) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar2) = 0x1802645e2;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_RDX != (int64_t *)0x0) && (*in_RDX == 0)) {
        *(undefined4 *)((int64_t)&arg_30h + iVar3 + iVar2) = uVar6;
        *(undefined8 *)((int64_t)&arg_70h + iVar3 + iVar2) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar2) = 0x18026461d;
        uVar1 = fcn.180263ea0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x000000e0 + iVar3 + iVar2));
        if ((int32_t)uVar1 < 1) {
            return (uint64_t)uVar1;
        }
        *(undefined8 *)((int64_t)&arg_78h + iVar3 + iVar2) = unaff_R14;
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar2) = 0x18026464d;
        iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_30h + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000038 + iVar3 + iVar2));
        if (iVar4 == 0) {
            uVar5 = 0xffffffff;
        } else {
            *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2) = iVar4;
            *(undefined4 *)((int64_t)&arg_30h + iVar3 + iVar2) = uVar6;
            *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar2) = 0x18026468d;
            fcn.180263ea0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar2), *(int64_t *)(&stack0x00000058 + iVar3 + iVar2)
                          , *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                          *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2), 
                          *(int64_t *)(&stack0x000000e0 + iVar3 + iVar2));
            uVar5 = (uint64_t)uVar1;
            *in_RDX = iVar4;
        }
        return uVar5;
    }
    *(undefined4 *)((int64_t)&arg_30h + iVar3 + iVar2) = uVar6;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar2) = 0x1802646a8;
    uVar5 = fcn.180263ea0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar2), *(int64_t *)(&stack0x00000058 + iVar3 + iVar2)
                          , *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                          *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2), 
                          *(int64_t *)(&stack0x000000e0 + iVar3 + iVar2));
    return uVar5;
}

// ============================================================
// Function: FUN_180264633
// Address: 0x180264633
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.1802642c0(int64_t arg_30h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined4 uVar6;
    undefined8 unaff_R14;
    undefined8 auStackX_8 [4];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar6 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = in_RCX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar2 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar2 + 0x10) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_8 + iVar2 + 8) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar2) = 0x1802645e2;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_RDX != (int64_t *)0x0) && (*in_RDX == 0)) {
        *(undefined4 *)((int64_t)&arg_30h + iVar3 + iVar2) = uVar6;
        *(undefined8 *)((int64_t)&arg_70h + iVar3 + iVar2) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar2) = 0x18026461d;
        uVar1 = fcn.180263ea0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x000000e0 + iVar3 + iVar2));
        if ((int32_t)uVar1 < 1) {
            return (uint64_t)uVar1;
        }
        *(undefined8 *)((int64_t)&arg_78h + iVar3 + iVar2) = unaff_R14;
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar2) = 0x18026464d;
        iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_30h + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000038 + iVar3 + iVar2));
        if (iVar4 == 0) {
            uVar5 = 0xffffffff;
        } else {
            *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2) = iVar4;
            *(undefined4 *)((int64_t)&arg_30h + iVar3 + iVar2) = uVar6;
            *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar2) = 0x18026468d;
            fcn.180263ea0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar2), *(int64_t *)(&stack0x00000058 + iVar3 + iVar2)
                          , *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                          *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2), 
                          *(int64_t *)(&stack0x000000e0 + iVar3 + iVar2));
            uVar5 = (uint64_t)uVar1;
            *in_RDX = iVar4;
        }
        return uVar5;
    }
    *(undefined4 *)((int64_t)&arg_30h + iVar3 + iVar2) = uVar6;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar2) = 0x1802646a8;
    uVar5 = fcn.180263ea0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar2), *(int64_t *)(&stack0x00000058 + iVar3 + iVar2)
                          , *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                          *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2), 
                          *(int64_t *)(&stack0x000000e0 + iVar3 + iVar2));
    return uVar5;
}

// ============================================================
// Function: FUN_18026466c
// Address: 0x18026466c
// Size: 40 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.1802642c0(int64_t arg_30h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined4 uVar6;
    undefined8 unaff_R14;
    undefined8 auStackX_8 [4];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar6 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = in_RCX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar2 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar2 + 0x10) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_8 + iVar2 + 8) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar2) = 0x1802645e2;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_RDX != (int64_t *)0x0) && (*in_RDX == 0)) {
        *(undefined4 *)((int64_t)&arg_30h + iVar3 + iVar2) = uVar6;
        *(undefined8 *)((int64_t)&arg_70h + iVar3 + iVar2) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar2) = 0x18026461d;
        uVar1 = fcn.180263ea0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x000000e0 + iVar3 + iVar2));
        if ((int32_t)uVar1 < 1) {
            return (uint64_t)uVar1;
        }
        *(undefined8 *)((int64_t)&arg_78h + iVar3 + iVar2) = unaff_R14;
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar2) = 0x18026464d;
        iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_30h + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000038 + iVar3 + iVar2));
        if (iVar4 == 0) {
            uVar5 = 0xffffffff;
        } else {
            *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2) = iVar4;
            *(undefined4 *)((int64_t)&arg_30h + iVar3 + iVar2) = uVar6;
            *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar2) = 0x18026468d;
            fcn.180263ea0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar2), *(int64_t *)(&stack0x00000058 + iVar3 + iVar2)
                          , *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                          *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2), 
                          *(int64_t *)(&stack0x000000e0 + iVar3 + iVar2));
            uVar5 = (uint64_t)uVar1;
            *in_RDX = iVar4;
        }
        return uVar5;
    }
    *(undefined4 *)((int64_t)&arg_30h + iVar3 + iVar2) = uVar6;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar2) = 0x1802646a8;
    uVar5 = fcn.180263ea0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar2), *(int64_t *)(&stack0x00000058 + iVar3 + iVar2)
                          , *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                          *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2), 
                          *(int64_t *)(&stack0x000000e0 + iVar3 + iVar2));
    return uVar5;
}

// ============================================================
// Function: FUN_180264694
// Address: 0x180264694
// Size: 28 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.1802642c0(int64_t arg_30h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined4 uVar6;
    undefined8 unaff_R14;
    undefined8 auStackX_8 [4];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar6 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = in_RCX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar2 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar2 + 0x10) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_8 + iVar2 + 8) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar2) = 0x1802645e2;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_RDX != (int64_t *)0x0) && (*in_RDX == 0)) {
        *(undefined4 *)((int64_t)&arg_30h + iVar3 + iVar2) = uVar6;
        *(undefined8 *)((int64_t)&arg_70h + iVar3 + iVar2) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar2) = 0x18026461d;
        uVar1 = fcn.180263ea0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x000000e0 + iVar3 + iVar2));
        if ((int32_t)uVar1 < 1) {
            return (uint64_t)uVar1;
        }
        *(undefined8 *)((int64_t)&arg_78h + iVar3 + iVar2) = unaff_R14;
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar2) = 0x18026464d;
        iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_30h + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000038 + iVar3 + iVar2));
        if (iVar4 == 0) {
            uVar5 = 0xffffffff;
        } else {
            *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2) = iVar4;
            *(undefined4 *)((int64_t)&arg_30h + iVar3 + iVar2) = uVar6;
            *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar2) = 0x18026468d;
            fcn.180263ea0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar2), *(int64_t *)(&stack0x00000058 + iVar3 + iVar2)
                          , *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                          *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2), 
                          *(int64_t *)(&stack0x000000e0 + iVar3 + iVar2));
            uVar5 = (uint64_t)uVar1;
            *in_RDX = iVar4;
        }
        return uVar5;
    }
    *(undefined4 *)((int64_t)&arg_30h + iVar3 + iVar2) = uVar6;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar2) = 0x1802646a8;
    uVar5 = fcn.180263ea0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar2), *(int64_t *)(&stack0x00000058 + iVar3 + iVar2)
                          , *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                          *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2), 
                          *(int64_t *)(&stack0x000000e0 + iVar3 + iVar2));
    return uVar5;
}

// ============================================================
// Function: FUN_1802646b0
// Address: 0x1802646b0
// Size: 70 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.1802646b0(int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_78h, int64_t arg_80h,
                      int64_t arg_100h)
{
    undefined4 uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 in_RCX;
    undefined8 *in_RDX;
    uint64_t uVar8;
    uint64_t uVar9;
    uint32_t uVar10;
    undefined8 unaff_RBP;
    int32_t *piVar11;
    undefined8 *puVar12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    
    uStack_30 = 0x1802646c2;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar8 = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar4) = 0;
    if (*(int32_t *)((int64_t)&arg_78h + iVar4) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802646ea;
        iVar2 = fcn.180222010();
        if (1 < iVar2) {
            *(undefined8 *)((int64_t)&arg_68h + iVar4) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264703;
            fcn.180222010(in_RCX);
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264720;
            uVar5 = fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -0x20));
            uVar9 = uVar5;
            if (uVar5 != 0) {
                *(undefined8 *)((int64_t)&arg_60h + iVar4) = unaff_R13;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264759;
                iVar6 = fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -0x20));
                *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8) = iVar6;
                uVar9 = uVar8;
                if (iVar6 != 0) {
                    *(undefined8 *)((int64_t)&arg_58h + iVar4) = unaff_RBP;
                    *(int64_t *)((int64_t)&var_8h + iVar4) = iVar6;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264781;
                    iVar2 = fcn.180222010(in_RCX);
                    if (0 < iVar2) {
                        uVar1 = *(undefined4 *)((int64_t)&arg_80h + iVar4);
                        puVar12 = (undefined8 *)(uVar5 + 0x10);
                        do {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026479b;
                            uVar7 = fcn.180222340(in_RCX, uVar9);
                            *(undefined8 *)((int64_t)&var_10h + iVar4) = uVar7;
                            puVar12[-2] = *(undefined8 *)((int64_t)&var_8h + iVar4);
                            *(undefined4 *)(&stack0xfffffffffffffff8 + iVar4) = uVar1;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802647c6;
                            uVar3 = fcn.180263ea0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                                                  *(int64_t *)(&stack0x00000028 + iVar4), 
                                                  *(int64_t *)(&stack0x00000030 + iVar4), 
                                                  *(int64_t *)(&stack0x000000a8 + iVar4));
                            *(undefined4 *)(puVar12 + -1) = uVar3;
                            *puVar12 = *(undefined8 *)((int64_t)&var_10h + iVar4);
                            uVar10 = (int32_t)uVar9 + 1;
                            uVar9 = (uint64_t)uVar10;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802647e0;
                            iVar2 = fcn.180222010(in_RCX);
                            puVar12 = puVar12 + 3;
                        } while ((int32_t)uVar10 < iVar2);
                        iVar6 = *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8);
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802647f1;
                    fcn.180222010(in_RCX);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264809;
                    fcn.18046f0d0(*(int64_t *)((int64_t)&var_8h + iVar4));
                    *(undefined8 *)((int64_t)&var_8h + iVar4) = *in_RDX;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026481c;
                    iVar2 = fcn.180222010(in_RCX);
                    if (0 < iVar2) {
                        piVar11 = (int32_t *)(uVar5 + 8);
                        uVar9 = uVar8;
                        do {
                            iVar2 = *piVar11;
                            uVar7 = *(undefined8 *)(piVar11 + -2);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264835;
                            fcn.180498030(*(undefined8 *)((int64_t)&var_8h + iVar4), uVar7, (int64_t)iVar2);
                            iVar2 = *piVar11;
                            piVar11 = piVar11 + 6;
                            *(int64_t *)((int64_t)&var_8h + iVar4) =
                                 *(int64_t *)((int64_t)&var_8h + iVar4) + (int64_t)iVar2;
                            uVar10 = (int32_t)uVar9 + 1;
                            uVar9 = (uint64_t)uVar10;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026484b;
                            iVar2 = fcn.180222010(in_RCX);
                        } while ((int32_t)uVar10 < iVar2);
                    }
                    iVar2 = *(int32_t *)((int64_t)&arg_78h + iVar4);
                    *in_RDX = *(undefined8 *)((int64_t)&var_8h + iVar4);
                    if (iVar2 == 2) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264872;
                        iVar2 = fcn.180222010(in_RCX);
                        if (0 < iVar2) {
                            puVar12 = (undefined8 *)(uVar5 + 0x10);
                            do {
                                uVar7 = *puVar12;
                                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026488d;
                                fcn.1802221b0(in_RCX, uVar8, uVar7);
                                puVar12 = puVar12 + 3;
                                uVar10 = (int32_t)uVar8 + 1;
                                uVar8 = (uint64_t)uVar10;
                                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026489b;
                                iVar2 = fcn.180222010(in_RCX);
                            } while ((int32_t)uVar10 < iVar2);
                        }
                    }
                    uVar9 = 1;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648b9;
                fcn.180224990(uVar5, 0x1804e6de8, 0x1c9);
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648ce;
                fcn.180224990(iVar6, 0x1804e6de8, 0x1ca);
            }
            return uVar9;
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648e5;
    iVar2 = fcn.180222010(in_RCX);
    if (0 < iVar2) {
        uVar1 = *(undefined4 *)((int64_t)&arg_80h + iVar4);
        do {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648fa;
            uVar7 = fcn.180222340(in_RCX, uVar8);
            *(undefined8 *)((int64_t)&var_10h + iVar4) = uVar7;
            *(undefined4 *)(&stack0xfffffffffffffff8 + iVar4) = uVar1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264919;
            fcn.180263ea0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)(&stack0x000000a8 + iVar4));
            uVar10 = (int32_t)uVar8 + 1;
            uVar8 = (uint64_t)uVar10;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264923;
            iVar2 = fcn.180222010(in_RCX);
        } while ((int32_t)uVar10 < iVar2);
    }
    return 1;
}

// ============================================================
// Function: FUN_1802646f6
// Address: 0x1802646f6
// Size: 70 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.1802646b0(int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_78h, int64_t arg_80h,
                      int64_t arg_100h)
{
    undefined4 uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 in_RCX;
    undefined8 *in_RDX;
    uint64_t uVar8;
    uint64_t uVar9;
    uint32_t uVar10;
    undefined8 unaff_RBP;
    int32_t *piVar11;
    undefined8 *puVar12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    
    uStack_30 = 0x1802646c2;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar8 = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar4) = 0;
    if (*(int32_t *)((int64_t)&arg_78h + iVar4) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802646ea;
        iVar2 = fcn.180222010();
        if (1 < iVar2) {
            *(undefined8 *)((int64_t)&arg_68h + iVar4) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264703;
            fcn.180222010(in_RCX);
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264720;
            uVar5 = fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -0x20));
            uVar9 = uVar5;
            if (uVar5 != 0) {
                *(undefined8 *)((int64_t)&arg_60h + iVar4) = unaff_R13;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264759;
                iVar6 = fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -0x20));
                *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8) = iVar6;
                uVar9 = uVar8;
                if (iVar6 != 0) {
                    *(undefined8 *)((int64_t)&arg_58h + iVar4) = unaff_RBP;
                    *(int64_t *)((int64_t)&var_8h + iVar4) = iVar6;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264781;
                    iVar2 = fcn.180222010(in_RCX);
                    if (0 < iVar2) {
                        uVar1 = *(undefined4 *)((int64_t)&arg_80h + iVar4);
                        puVar12 = (undefined8 *)(uVar5 + 0x10);
                        do {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026479b;
                            uVar7 = fcn.180222340(in_RCX, uVar9);
                            *(undefined8 *)((int64_t)&var_10h + iVar4) = uVar7;
                            puVar12[-2] = *(undefined8 *)((int64_t)&var_8h + iVar4);
                            *(undefined4 *)(&stack0xfffffffffffffff8 + iVar4) = uVar1;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802647c6;
                            uVar3 = fcn.180263ea0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                                                  *(int64_t *)(&stack0x00000028 + iVar4), 
                                                  *(int64_t *)(&stack0x00000030 + iVar4), 
                                                  *(int64_t *)(&stack0x000000a8 + iVar4));
                            *(undefined4 *)(puVar12 + -1) = uVar3;
                            *puVar12 = *(undefined8 *)((int64_t)&var_10h + iVar4);
                            uVar10 = (int32_t)uVar9 + 1;
                            uVar9 = (uint64_t)uVar10;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802647e0;
                            iVar2 = fcn.180222010(in_RCX);
                            puVar12 = puVar12 + 3;
                        } while ((int32_t)uVar10 < iVar2);
                        iVar6 = *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8);
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802647f1;
                    fcn.180222010(in_RCX);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264809;
                    fcn.18046f0d0(*(int64_t *)((int64_t)&var_8h + iVar4));
                    *(undefined8 *)((int64_t)&var_8h + iVar4) = *in_RDX;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026481c;
                    iVar2 = fcn.180222010(in_RCX);
                    if (0 < iVar2) {
                        piVar11 = (int32_t *)(uVar5 + 8);
                        uVar9 = uVar8;
                        do {
                            iVar2 = *piVar11;
                            uVar7 = *(undefined8 *)(piVar11 + -2);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264835;
                            fcn.180498030(*(undefined8 *)((int64_t)&var_8h + iVar4), uVar7, (int64_t)iVar2);
                            iVar2 = *piVar11;
                            piVar11 = piVar11 + 6;
                            *(int64_t *)((int64_t)&var_8h + iVar4) =
                                 *(int64_t *)((int64_t)&var_8h + iVar4) + (int64_t)iVar2;
                            uVar10 = (int32_t)uVar9 + 1;
                            uVar9 = (uint64_t)uVar10;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026484b;
                            iVar2 = fcn.180222010(in_RCX);
                        } while ((int32_t)uVar10 < iVar2);
                    }
                    iVar2 = *(int32_t *)((int64_t)&arg_78h + iVar4);
                    *in_RDX = *(undefined8 *)((int64_t)&var_8h + iVar4);
                    if (iVar2 == 2) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264872;
                        iVar2 = fcn.180222010(in_RCX);
                        if (0 < iVar2) {
                            puVar12 = (undefined8 *)(uVar5 + 0x10);
                            do {
                                uVar7 = *puVar12;
                                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026488d;
                                fcn.1802221b0(in_RCX, uVar8, uVar7);
                                puVar12 = puVar12 + 3;
                                uVar10 = (int32_t)uVar8 + 1;
                                uVar8 = (uint64_t)uVar10;
                                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026489b;
                                iVar2 = fcn.180222010(in_RCX);
                            } while ((int32_t)uVar10 < iVar2);
                        }
                    }
                    uVar9 = 1;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648b9;
                fcn.180224990(uVar5, 0x1804e6de8, 0x1c9);
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648ce;
                fcn.180224990(iVar6, 0x1804e6de8, 0x1ca);
            }
            return uVar9;
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648e5;
    iVar2 = fcn.180222010(in_RCX);
    if (0 < iVar2) {
        uVar1 = *(undefined4 *)((int64_t)&arg_80h + iVar4);
        do {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648fa;
            uVar7 = fcn.180222340(in_RCX, uVar8);
            *(undefined8 *)((int64_t)&var_10h + iVar4) = uVar7;
            *(undefined4 *)(&stack0xfffffffffffffff8 + iVar4) = uVar1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264919;
            fcn.180263ea0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)(&stack0x000000a8 + iVar4));
            uVar10 = (int32_t)uVar8 + 1;
            uVar8 = (uint64_t)uVar10;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264923;
            iVar2 = fcn.180222010(in_RCX);
        } while ((int32_t)uVar10 < iVar2);
    }
    return 1;
}

// ============================================================
// Function: FUN_18026473c
// Address: 0x18026473c
// Size: 3 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.1802646b0(int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_78h, int64_t arg_80h,
                      int64_t arg_100h)
{
    undefined4 uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 in_RCX;
    undefined8 *in_RDX;
    uint64_t uVar8;
    uint64_t uVar9;
    uint32_t uVar10;
    undefined8 unaff_RBP;
    int32_t *piVar11;
    undefined8 *puVar12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    
    uStack_30 = 0x1802646c2;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar8 = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar4) = 0;
    if (*(int32_t *)((int64_t)&arg_78h + iVar4) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802646ea;
        iVar2 = fcn.180222010();
        if (1 < iVar2) {
            *(undefined8 *)((int64_t)&arg_68h + iVar4) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264703;
            fcn.180222010(in_RCX);
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264720;
            uVar5 = fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -0x20));
            uVar9 = uVar5;
            if (uVar5 != 0) {
                *(undefined8 *)((int64_t)&arg_60h + iVar4) = unaff_R13;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264759;
                iVar6 = fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -0x20));
                *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8) = iVar6;
                uVar9 = uVar8;
                if (iVar6 != 0) {
                    *(undefined8 *)((int64_t)&arg_58h + iVar4) = unaff_RBP;
                    *(int64_t *)((int64_t)&var_8h + iVar4) = iVar6;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264781;
                    iVar2 = fcn.180222010(in_RCX);
                    if (0 < iVar2) {
                        uVar1 = *(undefined4 *)((int64_t)&arg_80h + iVar4);
                        puVar12 = (undefined8 *)(uVar5 + 0x10);
                        do {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026479b;
                            uVar7 = fcn.180222340(in_RCX, uVar9);
                            *(undefined8 *)((int64_t)&var_10h + iVar4) = uVar7;
                            puVar12[-2] = *(undefined8 *)((int64_t)&var_8h + iVar4);
                            *(undefined4 *)(&stack0xfffffffffffffff8 + iVar4) = uVar1;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802647c6;
                            uVar3 = fcn.180263ea0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                                                  *(int64_t *)(&stack0x00000028 + iVar4), 
                                                  *(int64_t *)(&stack0x00000030 + iVar4), 
                                                  *(int64_t *)(&stack0x000000a8 + iVar4));
                            *(undefined4 *)(puVar12 + -1) = uVar3;
                            *puVar12 = *(undefined8 *)((int64_t)&var_10h + iVar4);
                            uVar10 = (int32_t)uVar9 + 1;
                            uVar9 = (uint64_t)uVar10;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802647e0;
                            iVar2 = fcn.180222010(in_RCX);
                            puVar12 = puVar12 + 3;
                        } while ((int32_t)uVar10 < iVar2);
                        iVar6 = *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8);
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802647f1;
                    fcn.180222010(in_RCX);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264809;
                    fcn.18046f0d0(*(int64_t *)((int64_t)&var_8h + iVar4));
                    *(undefined8 *)((int64_t)&var_8h + iVar4) = *in_RDX;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026481c;
                    iVar2 = fcn.180222010(in_RCX);
                    if (0 < iVar2) {
                        piVar11 = (int32_t *)(uVar5 + 8);
                        uVar9 = uVar8;
                        do {
                            iVar2 = *piVar11;
                            uVar7 = *(undefined8 *)(piVar11 + -2);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264835;
                            fcn.180498030(*(undefined8 *)((int64_t)&var_8h + iVar4), uVar7, (int64_t)iVar2);
                            iVar2 = *piVar11;
                            piVar11 = piVar11 + 6;
                            *(int64_t *)((int64_t)&var_8h + iVar4) =
                                 *(int64_t *)((int64_t)&var_8h + iVar4) + (int64_t)iVar2;
                            uVar10 = (int32_t)uVar9 + 1;
                            uVar9 = (uint64_t)uVar10;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026484b;
                            iVar2 = fcn.180222010(in_RCX);
                        } while ((int32_t)uVar10 < iVar2);
                    }
                    iVar2 = *(int32_t *)((int64_t)&arg_78h + iVar4);
                    *in_RDX = *(undefined8 *)((int64_t)&var_8h + iVar4);
                    if (iVar2 == 2) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264872;
                        iVar2 = fcn.180222010(in_RCX);
                        if (0 < iVar2) {
                            puVar12 = (undefined8 *)(uVar5 + 0x10);
                            do {
                                uVar7 = *puVar12;
                                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026488d;
                                fcn.1802221b0(in_RCX, uVar8, uVar7);
                                puVar12 = puVar12 + 3;
                                uVar10 = (int32_t)uVar8 + 1;
                                uVar8 = (uint64_t)uVar10;
                                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026489b;
                                iVar2 = fcn.180222010(in_RCX);
                            } while ((int32_t)uVar10 < iVar2);
                        }
                    }
                    uVar9 = 1;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648b9;
                fcn.180224990(uVar5, 0x1804e6de8, 0x1c9);
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648ce;
                fcn.180224990(iVar6, 0x1804e6de8, 0x1ca);
            }
            return uVar9;
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648e5;
    iVar2 = fcn.180222010(in_RCX);
    if (0 < iVar2) {
        uVar1 = *(undefined4 *)((int64_t)&arg_80h + iVar4);
        do {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648fa;
            uVar7 = fcn.180222340(in_RCX, uVar8);
            *(undefined8 *)((int64_t)&var_10h + iVar4) = uVar7;
            *(undefined4 *)(&stack0xfffffffffffffff8 + iVar4) = uVar1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264919;
            fcn.180263ea0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)(&stack0x000000a8 + iVar4));
            uVar10 = (int32_t)uVar8 + 1;
            uVar8 = (uint64_t)uVar10;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264923;
            iVar2 = fcn.180222010(in_RCX);
        } while ((int32_t)uVar10 < iVar2);
    }
    return 1;
}

// ============================================================
// Function: FUN_18026473f
// Address: 0x18026473f
// Size: 43 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.1802646b0(int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_78h, int64_t arg_80h,
                      int64_t arg_100h)
{
    undefined4 uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 in_RCX;
    undefined8 *in_RDX;
    uint64_t uVar8;
    uint64_t uVar9;
    uint32_t uVar10;
    undefined8 unaff_RBP;
    int32_t *piVar11;
    undefined8 *puVar12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    
    uStack_30 = 0x1802646c2;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar8 = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar4) = 0;
    if (*(int32_t *)((int64_t)&arg_78h + iVar4) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802646ea;
        iVar2 = fcn.180222010();
        if (1 < iVar2) {
            *(undefined8 *)((int64_t)&arg_68h + iVar4) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264703;
            fcn.180222010(in_RCX);
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264720;
            uVar5 = fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -0x20));
            uVar9 = uVar5;
            if (uVar5 != 0) {
                *(undefined8 *)((int64_t)&arg_60h + iVar4) = unaff_R13;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264759;
                iVar6 = fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -0x20));
                *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8) = iVar6;
                uVar9 = uVar8;
                if (iVar6 != 0) {
                    *(undefined8 *)((int64_t)&arg_58h + iVar4) = unaff_RBP;
                    *(int64_t *)((int64_t)&var_8h + iVar4) = iVar6;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264781;
                    iVar2 = fcn.180222010(in_RCX);
                    if (0 < iVar2) {
                        uVar1 = *(undefined4 *)((int64_t)&arg_80h + iVar4);
                        puVar12 = (undefined8 *)(uVar5 + 0x10);
                        do {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026479b;
                            uVar7 = fcn.180222340(in_RCX, uVar9);
                            *(undefined8 *)((int64_t)&var_10h + iVar4) = uVar7;
                            puVar12[-2] = *(undefined8 *)((int64_t)&var_8h + iVar4);
                            *(undefined4 *)(&stack0xfffffffffffffff8 + iVar4) = uVar1;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802647c6;
                            uVar3 = fcn.180263ea0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                                                  *(int64_t *)(&stack0x00000028 + iVar4), 
                                                  *(int64_t *)(&stack0x00000030 + iVar4), 
                                                  *(int64_t *)(&stack0x000000a8 + iVar4));
                            *(undefined4 *)(puVar12 + -1) = uVar3;
                            *puVar12 = *(undefined8 *)((int64_t)&var_10h + iVar4);
                            uVar10 = (int32_t)uVar9 + 1;
                            uVar9 = (uint64_t)uVar10;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802647e0;
                            iVar2 = fcn.180222010(in_RCX);
                            puVar12 = puVar12 + 3;
                        } while ((int32_t)uVar10 < iVar2);
                        iVar6 = *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8);
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802647f1;
                    fcn.180222010(in_RCX);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264809;
                    fcn.18046f0d0(*(int64_t *)((int64_t)&var_8h + iVar4));
                    *(undefined8 *)((int64_t)&var_8h + iVar4) = *in_RDX;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026481c;
                    iVar2 = fcn.180222010(in_RCX);
                    if (0 < iVar2) {
                        piVar11 = (int32_t *)(uVar5 + 8);
                        uVar9 = uVar8;
                        do {
                            iVar2 = *piVar11;
                            uVar7 = *(undefined8 *)(piVar11 + -2);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264835;
                            fcn.180498030(*(undefined8 *)((int64_t)&var_8h + iVar4), uVar7, (int64_t)iVar2);
                            iVar2 = *piVar11;
                            piVar11 = piVar11 + 6;
                            *(int64_t *)((int64_t)&var_8h + iVar4) =
                                 *(int64_t *)((int64_t)&var_8h + iVar4) + (int64_t)iVar2;
                            uVar10 = (int32_t)uVar9 + 1;
                            uVar9 = (uint64_t)uVar10;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026484b;
                            iVar2 = fcn.180222010(in_RCX);
                        } while ((int32_t)uVar10 < iVar2);
                    }
                    iVar2 = *(int32_t *)((int64_t)&arg_78h + iVar4);
                    *in_RDX = *(undefined8 *)((int64_t)&var_8h + iVar4);
                    if (iVar2 == 2) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264872;
                        iVar2 = fcn.180222010(in_RCX);
                        if (0 < iVar2) {
                            puVar12 = (undefined8 *)(uVar5 + 0x10);
                            do {
                                uVar7 = *puVar12;
                                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026488d;
                                fcn.1802221b0(in_RCX, uVar8, uVar7);
                                puVar12 = puVar12 + 3;
                                uVar10 = (int32_t)uVar8 + 1;
                                uVar8 = (uint64_t)uVar10;
                                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026489b;
                                iVar2 = fcn.180222010(in_RCX);
                            } while ((int32_t)uVar10 < iVar2);
                        }
                    }
                    uVar9 = 1;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648b9;
                fcn.180224990(uVar5, 0x1804e6de8, 0x1c9);
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648ce;
                fcn.180224990(iVar6, 0x1804e6de8, 0x1ca);
            }
            return uVar9;
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648e5;
    iVar2 = fcn.180222010(in_RCX);
    if (0 < iVar2) {
        uVar1 = *(undefined4 *)((int64_t)&arg_80h + iVar4);
        do {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648fa;
            uVar7 = fcn.180222340(in_RCX, uVar8);
            *(undefined8 *)((int64_t)&var_10h + iVar4) = uVar7;
            *(undefined4 *)(&stack0xfffffffffffffff8 + iVar4) = uVar1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264919;
            fcn.180263ea0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)(&stack0x000000a8 + iVar4));
            uVar10 = (int32_t)uVar8 + 1;
            uVar8 = (uint64_t)uVar10;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264923;
            iVar2 = fcn.180222010(in_RCX);
        } while ((int32_t)uVar10 < iVar2);
    }
    return 1;
}

// ============================================================
// Function: FUN_18026476a
// Address: 0x18026476a
// Size: 256 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.1802646b0(int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_78h, int64_t arg_80h,
                      int64_t arg_100h)
{
    undefined4 uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 in_RCX;
    undefined8 *in_RDX;
    uint64_t uVar8;
    uint64_t uVar9;
    uint32_t uVar10;
    undefined8 unaff_RBP;
    int32_t *piVar11;
    undefined8 *puVar12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    
    uStack_30 = 0x1802646c2;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar8 = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar4) = 0;
    if (*(int32_t *)((int64_t)&arg_78h + iVar4) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802646ea;
        iVar2 = fcn.180222010();
        if (1 < iVar2) {
            *(undefined8 *)((int64_t)&arg_68h + iVar4) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264703;
            fcn.180222010(in_RCX);
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264720;
            uVar5 = fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -0x20));
            uVar9 = uVar5;
            if (uVar5 != 0) {
                *(undefined8 *)((int64_t)&arg_60h + iVar4) = unaff_R13;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264759;
                iVar6 = fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -0x20));
                *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8) = iVar6;
                uVar9 = uVar8;
                if (iVar6 != 0) {
                    *(undefined8 *)((int64_t)&arg_58h + iVar4) = unaff_RBP;
                    *(int64_t *)((int64_t)&var_8h + iVar4) = iVar6;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264781;
                    iVar2 = fcn.180222010(in_RCX);
                    if (0 < iVar2) {
                        uVar1 = *(undefined4 *)((int64_t)&arg_80h + iVar4);
                        puVar12 = (undefined8 *)(uVar5 + 0x10);
                        do {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026479b;
                            uVar7 = fcn.180222340(in_RCX, uVar9);
                            *(undefined8 *)((int64_t)&var_10h + iVar4) = uVar7;
                            puVar12[-2] = *(undefined8 *)((int64_t)&var_8h + iVar4);
                            *(undefined4 *)(&stack0xfffffffffffffff8 + iVar4) = uVar1;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802647c6;
                            uVar3 = fcn.180263ea0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                                                  *(int64_t *)(&stack0x00000028 + iVar4), 
                                                  *(int64_t *)(&stack0x00000030 + iVar4), 
                                                  *(int64_t *)(&stack0x000000a8 + iVar4));
                            *(undefined4 *)(puVar12 + -1) = uVar3;
                            *puVar12 = *(undefined8 *)((int64_t)&var_10h + iVar4);
                            uVar10 = (int32_t)uVar9 + 1;
                            uVar9 = (uint64_t)uVar10;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802647e0;
                            iVar2 = fcn.180222010(in_RCX);
                            puVar12 = puVar12 + 3;
                        } while ((int32_t)uVar10 < iVar2);
                        iVar6 = *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8);
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802647f1;
                    fcn.180222010(in_RCX);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264809;
                    fcn.18046f0d0(*(int64_t *)((int64_t)&var_8h + iVar4));
                    *(undefined8 *)((int64_t)&var_8h + iVar4) = *in_RDX;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026481c;
                    iVar2 = fcn.180222010(in_RCX);
                    if (0 < iVar2) {
                        piVar11 = (int32_t *)(uVar5 + 8);
                        uVar9 = uVar8;
                        do {
                            iVar2 = *piVar11;
                            uVar7 = *(undefined8 *)(piVar11 + -2);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264835;
                            fcn.180498030(*(undefined8 *)((int64_t)&var_8h + iVar4), uVar7, (int64_t)iVar2);
                            iVar2 = *piVar11;
                            piVar11 = piVar11 + 6;
                            *(int64_t *)((int64_t)&var_8h + iVar4) =
                                 *(int64_t *)((int64_t)&var_8h + iVar4) + (int64_t)iVar2;
                            uVar10 = (int32_t)uVar9 + 1;
                            uVar9 = (uint64_t)uVar10;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026484b;
                            iVar2 = fcn.180222010(in_RCX);
                        } while ((int32_t)uVar10 < iVar2);
                    }
                    iVar2 = *(int32_t *)((int64_t)&arg_78h + iVar4);
                    *in_RDX = *(undefined8 *)((int64_t)&var_8h + iVar4);
                    if (iVar2 == 2) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264872;
                        iVar2 = fcn.180222010(in_RCX);
                        if (0 < iVar2) {
                            puVar12 = (undefined8 *)(uVar5 + 0x10);
                            do {
                                uVar7 = *puVar12;
                                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026488d;
                                fcn.1802221b0(in_RCX, uVar8, uVar7);
                                puVar12 = puVar12 + 3;
                                uVar10 = (int32_t)uVar8 + 1;
                                uVar8 = (uint64_t)uVar10;
                                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026489b;
                                iVar2 = fcn.180222010(in_RCX);
                            } while ((int32_t)uVar10 < iVar2);
                        }
                    }
                    uVar9 = 1;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648b9;
                fcn.180224990(uVar5, 0x1804e6de8, 0x1c9);
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648ce;
                fcn.180224990(iVar6, 0x1804e6de8, 0x1ca);
            }
            return uVar9;
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648e5;
    iVar2 = fcn.180222010(in_RCX);
    if (0 < iVar2) {
        uVar1 = *(undefined4 *)((int64_t)&arg_80h + iVar4);
        do {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648fa;
            uVar7 = fcn.180222340(in_RCX, uVar8);
            *(undefined8 *)((int64_t)&var_10h + iVar4) = uVar7;
            *(undefined4 *)(&stack0xfffffffffffffff8 + iVar4) = uVar1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264919;
            fcn.180263ea0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)(&stack0x000000a8 + iVar4));
            uVar10 = (int32_t)uVar8 + 1;
            uVar8 = (uint64_t)uVar10;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264923;
            iVar2 = fcn.180222010(in_RCX);
        } while ((int32_t)uVar10 < iVar2);
    }
    return 1;
}

// ============================================================
// Function: FUN_18026486a
// Address: 0x18026486a
// Size: 115 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.1802646b0(int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_78h, int64_t arg_80h,
                      int64_t arg_100h)
{
    undefined4 uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 in_RCX;
    undefined8 *in_RDX;
    uint64_t uVar8;
    uint64_t uVar9;
    uint32_t uVar10;
    undefined8 unaff_RBP;
    int32_t *piVar11;
    undefined8 *puVar12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    
    uStack_30 = 0x1802646c2;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar8 = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar4) = 0;
    if (*(int32_t *)((int64_t)&arg_78h + iVar4) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802646ea;
        iVar2 = fcn.180222010();
        if (1 < iVar2) {
            *(undefined8 *)((int64_t)&arg_68h + iVar4) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264703;
            fcn.180222010(in_RCX);
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264720;
            uVar5 = fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -0x20));
            uVar9 = uVar5;
            if (uVar5 != 0) {
                *(undefined8 *)((int64_t)&arg_60h + iVar4) = unaff_R13;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264759;
                iVar6 = fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -0x20));
                *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8) = iVar6;
                uVar9 = uVar8;
                if (iVar6 != 0) {
                    *(undefined8 *)((int64_t)&arg_58h + iVar4) = unaff_RBP;
                    *(int64_t *)((int64_t)&var_8h + iVar4) = iVar6;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264781;
                    iVar2 = fcn.180222010(in_RCX);
                    if (0 < iVar2) {
                        uVar1 = *(undefined4 *)((int64_t)&arg_80h + iVar4);
                        puVar12 = (undefined8 *)(uVar5 + 0x10);
                        do {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026479b;
                            uVar7 = fcn.180222340(in_RCX, uVar9);
                            *(undefined8 *)((int64_t)&var_10h + iVar4) = uVar7;
                            puVar12[-2] = *(undefined8 *)((int64_t)&var_8h + iVar4);
                            *(undefined4 *)(&stack0xfffffffffffffff8 + iVar4) = uVar1;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802647c6;
                            uVar3 = fcn.180263ea0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                                                  *(int64_t *)(&stack0x00000028 + iVar4), 
                                                  *(int64_t *)(&stack0x00000030 + iVar4), 
                                                  *(int64_t *)(&stack0x000000a8 + iVar4));
                            *(undefined4 *)(puVar12 + -1) = uVar3;
                            *puVar12 = *(undefined8 *)((int64_t)&var_10h + iVar4);
                            uVar10 = (int32_t)uVar9 + 1;
                            uVar9 = (uint64_t)uVar10;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802647e0;
                            iVar2 = fcn.180222010(in_RCX);
                            puVar12 = puVar12 + 3;
                        } while ((int32_t)uVar10 < iVar2);
                        iVar6 = *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8);
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802647f1;
                    fcn.180222010(in_RCX);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264809;
                    fcn.18046f0d0(*(int64_t *)((int64_t)&var_8h + iVar4));
                    *(undefined8 *)((int64_t)&var_8h + iVar4) = *in_RDX;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026481c;
                    iVar2 = fcn.180222010(in_RCX);
                    if (0 < iVar2) {
                        piVar11 = (int32_t *)(uVar5 + 8);
                        uVar9 = uVar8;
                        do {
                            iVar2 = *piVar11;
                            uVar7 = *(undefined8 *)(piVar11 + -2);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264835;
                            fcn.180498030(*(undefined8 *)((int64_t)&var_8h + iVar4), uVar7, (int64_t)iVar2);
                            iVar2 = *piVar11;
                            piVar11 = piVar11 + 6;
                            *(int64_t *)((int64_t)&var_8h + iVar4) =
                                 *(int64_t *)((int64_t)&var_8h + iVar4) + (int64_t)iVar2;
                            uVar10 = (int32_t)uVar9 + 1;
                            uVar9 = (uint64_t)uVar10;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026484b;
                            iVar2 = fcn.180222010(in_RCX);
                        } while ((int32_t)uVar10 < iVar2);
                    }
                    iVar2 = *(int32_t *)((int64_t)&arg_78h + iVar4);
                    *in_RDX = *(undefined8 *)((int64_t)&var_8h + iVar4);
                    if (iVar2 == 2) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264872;
                        iVar2 = fcn.180222010(in_RCX);
                        if (0 < iVar2) {
                            puVar12 = (undefined8 *)(uVar5 + 0x10);
                            do {
                                uVar7 = *puVar12;
                                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026488d;
                                fcn.1802221b0(in_RCX, uVar8, uVar7);
                                puVar12 = puVar12 + 3;
                                uVar10 = (int32_t)uVar8 + 1;
                                uVar8 = (uint64_t)uVar10;
                                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026489b;
                                iVar2 = fcn.180222010(in_RCX);
                            } while ((int32_t)uVar10 < iVar2);
                        }
                    }
                    uVar9 = 1;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648b9;
                fcn.180224990(uVar5, 0x1804e6de8, 0x1c9);
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648ce;
                fcn.180224990(iVar6, 0x1804e6de8, 0x1ca);
            }
            return uVar9;
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648e5;
    iVar2 = fcn.180222010(in_RCX);
    if (0 < iVar2) {
        uVar1 = *(undefined4 *)((int64_t)&arg_80h + iVar4);
        do {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648fa;
            uVar7 = fcn.180222340(in_RCX, uVar8);
            *(undefined8 *)((int64_t)&var_10h + iVar4) = uVar7;
            *(undefined4 *)(&stack0xfffffffffffffff8 + iVar4) = uVar1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264919;
            fcn.180263ea0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)(&stack0x000000a8 + iVar4));
            uVar10 = (int32_t)uVar8 + 1;
            uVar8 = (uint64_t)uVar10;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264923;
            iVar2 = fcn.180222010(in_RCX);
        } while ((int32_t)uVar10 < iVar2);
    }
    return 1;
}

// ============================================================
// Function: FUN_1802648dd
// Address: 0x1802648dd
// Size: 91 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.1802646b0(int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_78h, int64_t arg_80h,
                      int64_t arg_100h)
{
    undefined4 uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 in_RCX;
    undefined8 *in_RDX;
    uint64_t uVar8;
    uint64_t uVar9;
    uint32_t uVar10;
    undefined8 unaff_RBP;
    int32_t *piVar11;
    undefined8 *puVar12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    
    uStack_30 = 0x1802646c2;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar8 = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar4) = 0;
    if (*(int32_t *)((int64_t)&arg_78h + iVar4) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802646ea;
        iVar2 = fcn.180222010();
        if (1 < iVar2) {
            *(undefined8 *)((int64_t)&arg_68h + iVar4) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264703;
            fcn.180222010(in_RCX);
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264720;
            uVar5 = fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -0x20));
            uVar9 = uVar5;
            if (uVar5 != 0) {
                *(undefined8 *)((int64_t)&arg_60h + iVar4) = unaff_R13;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264759;
                iVar6 = fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -0x20));
                *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8) = iVar6;
                uVar9 = uVar8;
                if (iVar6 != 0) {
                    *(undefined8 *)((int64_t)&arg_58h + iVar4) = unaff_RBP;
                    *(int64_t *)((int64_t)&var_8h + iVar4) = iVar6;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264781;
                    iVar2 = fcn.180222010(in_RCX);
                    if (0 < iVar2) {
                        uVar1 = *(undefined4 *)((int64_t)&arg_80h + iVar4);
                        puVar12 = (undefined8 *)(uVar5 + 0x10);
                        do {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026479b;
                            uVar7 = fcn.180222340(in_RCX, uVar9);
                            *(undefined8 *)((int64_t)&var_10h + iVar4) = uVar7;
                            puVar12[-2] = *(undefined8 *)((int64_t)&var_8h + iVar4);
                            *(undefined4 *)(&stack0xfffffffffffffff8 + iVar4) = uVar1;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802647c6;
                            uVar3 = fcn.180263ea0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                                                  *(int64_t *)(&stack0x00000028 + iVar4), 
                                                  *(int64_t *)(&stack0x00000030 + iVar4), 
                                                  *(int64_t *)(&stack0x000000a8 + iVar4));
                            *(undefined4 *)(puVar12 + -1) = uVar3;
                            *puVar12 = *(undefined8 *)((int64_t)&var_10h + iVar4);
                            uVar10 = (int32_t)uVar9 + 1;
                            uVar9 = (uint64_t)uVar10;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802647e0;
                            iVar2 = fcn.180222010(in_RCX);
                            puVar12 = puVar12 + 3;
                        } while ((int32_t)uVar10 < iVar2);
                        iVar6 = *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8);
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802647f1;
                    fcn.180222010(in_RCX);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264809;
                    fcn.18046f0d0(*(int64_t *)((int64_t)&var_8h + iVar4));
                    *(undefined8 *)((int64_t)&var_8h + iVar4) = *in_RDX;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026481c;
                    iVar2 = fcn.180222010(in_RCX);
                    if (0 < iVar2) {
                        piVar11 = (int32_t *)(uVar5 + 8);
                        uVar9 = uVar8;
                        do {
                            iVar2 = *piVar11;
                            uVar7 = *(undefined8 *)(piVar11 + -2);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264835;
                            fcn.180498030(*(undefined8 *)((int64_t)&var_8h + iVar4), uVar7, (int64_t)iVar2);
                            iVar2 = *piVar11;
                            piVar11 = piVar11 + 6;
                            *(int64_t *)((int64_t)&var_8h + iVar4) =
                                 *(int64_t *)((int64_t)&var_8h + iVar4) + (int64_t)iVar2;
                            uVar10 = (int32_t)uVar9 + 1;
                            uVar9 = (uint64_t)uVar10;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026484b;
                            iVar2 = fcn.180222010(in_RCX);
                        } while ((int32_t)uVar10 < iVar2);
                    }
                    iVar2 = *(int32_t *)((int64_t)&arg_78h + iVar4);
                    *in_RDX = *(undefined8 *)((int64_t)&var_8h + iVar4);
                    if (iVar2 == 2) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264872;
                        iVar2 = fcn.180222010(in_RCX);
                        if (0 < iVar2) {
                            puVar12 = (undefined8 *)(uVar5 + 0x10);
                            do {
                                uVar7 = *puVar12;
                                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026488d;
                                fcn.1802221b0(in_RCX, uVar8, uVar7);
                                puVar12 = puVar12 + 3;
                                uVar10 = (int32_t)uVar8 + 1;
                                uVar8 = (uint64_t)uVar10;
                                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026489b;
                                iVar2 = fcn.180222010(in_RCX);
                            } while ((int32_t)uVar10 < iVar2);
                        }
                    }
                    uVar9 = 1;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648b9;
                fcn.180224990(uVar5, 0x1804e6de8, 0x1c9);
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648ce;
                fcn.180224990(iVar6, 0x1804e6de8, 0x1ca);
            }
            return uVar9;
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648e5;
    iVar2 = fcn.180222010(in_RCX);
    if (0 < iVar2) {
        uVar1 = *(undefined4 *)((int64_t)&arg_80h + iVar4);
        do {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802648fa;
            uVar7 = fcn.180222340(in_RCX, uVar8);
            *(undefined8 *)((int64_t)&var_10h + iVar4) = uVar7;
            *(undefined4 *)(&stack0xfffffffffffffff8 + iVar4) = uVar1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264919;
            fcn.180263ea0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)(&stack0x000000a8 + iVar4));
            uVar10 = (int32_t)uVar8 + 1;
            uVar8 = (uint64_t)uVar10;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180264923;
            iVar2 = fcn.180222010(in_RCX);
        } while ((int32_t)uVar10 < iVar2);
    }
    return 1;
}

// ============================================================
// Function: FUN_180264940
// Address: 0x180264940
// Size: 922 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

uint64_t fcn.180264940(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h, int64_t arg_78h,
                      int64_t arg_88h)
{
    undefined4 uVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    int64_t iVar7;
    undefined8 uVar8;
    uint64_t uVar9;
    uint32_t uVar10;
    int64_t *in_RCX;
    int64_t in_RDX;
    int32_t iVar11;
    uint32_t uVar12;
    undefined4 uVar13;
    undefined8 unaff_RBP;
    uint32_t *in_R8;
    uint32_t in_R9D;
    uint32_t uVar14;
    int32_t iVar15;
    bool bVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x18026495d;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar6 = *in_R8;
    if ((uVar6 >> 0xc & 1) != 0) {
        *(int64_t **)((int64_t)&arg_28h + iVar7) = in_RCX;
        in_RCX = (int64_t *)((int64_t)&arg_28h + iVar7);
    }
    iVar15 = 0;
    *(undefined8 *)((int64_t)&arg_68h + iVar7) = unaff_RBP;
    uVar10 = 0;
    if ((uVar6 & 0x18) == 0) {
        if (in_R9D == 0xffffffff) {
            in_R9D = 0xffffffff;
            uVar12 = uVar10;
        } else {
            uVar12 = *(uint32_t *)((int64_t)&arg_88h + iVar7) & 0xc0;
        }
    } else {
        if (in_R9D != 0xffffffff) {
            return 0xffffffff;
        }
        in_R9D = in_R8[1];
        uVar12 = uVar6 & 0xc0;
    }
    uVar14 = *(uint32_t *)((int64_t)&arg_88h + iVar7) & 0xffffff3f;
    bVar16 = ((uVar6 & uVar14) >> 0xb & 1) != 0;
    *(bool *)((int64_t)&arg_78h + iVar7) = bVar16;
    *(uint32_t *)((int64_t)&var_8h + iVar7) = bVar16 + 1;
    if ((uVar6 & 6) == 0) {
        pcVar3 = *(code **)(in_R8 + 6);
        if ((uVar6 & 0x10) == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180264c66;
            (*pcVar3)();
            *(uint32_t *)(&stack0xfffffffffffffff8 + iVar7) = uVar12 | uVar14;
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180264c7b;
            uVar9 = fcn.180263ea0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                  *(int64_t *)(&stack0x000000a8 + iVar7));
            if ((int32_t)uVar9 != 0) {
                return uVar9;
            }
            if ((*(uint8_t *)in_R8 & 1) != 0) {
                return uVar9;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180264c89;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7));
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180264bc2;
            (*pcVar3)();
            *(uint32_t *)(&stack0xfffffffffffffff8 + iVar7) = uVar14;
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180264bda;
            iVar15 = fcn.180263ea0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                   *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                   *(int64_t *)(&stack0x000000a8 + iVar7));
            *(int32_t *)((int64_t)&var_10h + iVar7) = iVar15;
            if (iVar15 != 0) {
                uVar13 = *(undefined4 *)((int64_t)&var_8h + iVar7);
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180264c0d;
                uVar6 = func_0x000180296c90(uVar13, iVar15, in_R9D);
                uVar9 = (uint64_t)uVar6;
                if (in_RDX == 0) {
                    return uVar9;
                }
                if (uVar6 != 0xffffffff) {
                    *(uint32_t *)(&stack0xfffffffffffffff8 + iVar7) = uVar12;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180264c2f;
                    func_0x000180296d10(in_RDX, uVar13, *(undefined4 *)((int64_t)&var_10h + iVar7), in_R9D);
                    pcVar3 = *(code **)(in_R8 + 6);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180264c32;
                    (*pcVar3)();
                    *(uint32_t *)(&stack0xfffffffffffffff8 + iVar7) = uVar14;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180264c4b;
                    fcn.180263ea0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                  *(int64_t *)(&stack0x000000a8 + iVar7));
                    if (*(char *)((int64_t)&arg_78h + iVar7) != '\0') {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180264c5d;
                        func_0x000180296cf0(in_RDX);
                        return uVar9;
                    }
                    return uVar9;
                }
                return uVar9;
            }
            if ((*(uint8_t *)in_R8 & 1) != 0) {
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180264bec;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7));
        }
code_r0x000180264c8e:
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180264ca1;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                      *(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7));
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180264cb3;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar7));
    } else {
        iVar2 = *in_RCX;
        *(int64_t *)((int64_t)&var_20h + iVar7) = iVar2;
        if (iVar2 == 0) {
            return 0;
        }
        if ((uVar6 & 2) == 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar7) = 0;
        } else {
            uVar10 = ((uVar6 & 4) != 0) + 1;
            *(uint32_t *)((int64_t)&var_18h + iVar7) = uVar10;
        }
        if ((in_R9D == 0xffffffff) || ((uVar6 & 0x10) != 0)) {
            *(undefined4 *)((int64_t)&var_10h + iVar7 + 4) = 0;
            *(uint32_t *)((int64_t)&var_8h + iVar7 + 4) = (uVar10 != 0) + 0x10;
        } else {
            *(uint32_t *)((int64_t)&var_8h + iVar7 + 4) = in_R9D;
            *(uint32_t *)((int64_t)&var_10h + iVar7 + 4) = uVar12;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180264a59;
        iVar4 = fcn.180222010(iVar2);
        iVar11 = iVar15;
        if (0 < iVar4) {
            do {
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180264a6d;
                uVar8 = fcn.180222340(*(undefined8 *)((int64_t)&var_20h + iVar7), iVar15);
                *(undefined8 *)((int64_t)&arg_30h + iVar7) = uVar8;
                pcVar3 = *(code **)(in_R8 + 6);
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180264a75;
                (*pcVar3)();
                *(uint32_t *)(&stack0xfffffffffffffff8 + iVar7) = uVar14;
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180264a8f;
                iVar4 = fcn.180263ea0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                      *(int64_t *)(&stack0x000000a8 + iVar7));
                if (iVar4 == -1) {
                    return 0xffffffff;
                }
                if (0x7fffffff - iVar4 < iVar11) {
                    return 0xffffffff;
                }
                if ((iVar4 == 0) && ((*(uint8_t *)in_R8 & 1) == 0)) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180264b0f;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7)
                                 );
                    goto code_r0x000180264c8e;
                }
                iVar11 = iVar11 + iVar4;
                iVar15 = iVar15 + 1;
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180264abf;
                iVar4 = fcn.180222010(*(undefined8 *)((int64_t)&var_20h + iVar7));
            } while (iVar15 < iVar4);
        }
        uVar13 = *(undefined4 *)((int64_t)&var_8h + iVar7);
        uVar1 = *(undefined4 *)((int64_t)&var_8h + iVar7 + 4);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180264ad8;
        uVar10 = func_0x000180296c90(uVar13, iVar11, uVar1);
        *(uint32_t *)((int64_t)&var_18h + iVar7 + 4) = uVar10;
        if (uVar10 != 0xffffffff) {
            *(uint32_t *)((int64_t)&var_10h + iVar7) = uVar6 & 0x10;
            if ((uVar6 & 0x10) == 0) {
                iVar15 = 0;
                uVar5 = uVar10;
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180264afd;
                uVar5 = func_0x000180296c90(uVar13, uVar10, in_R9D);
                iVar15 = *(int32_t *)((int64_t)&var_10h + iVar7);
                uVar10 = *(uint32_t *)((int64_t)&var_18h + iVar7 + 4);
            }
            uVar9 = (uint64_t)uVar5;
            if (in_RDX == 0) {
                return uVar9;
            }
            if (uVar5 == 0xffffffff) {
                return uVar9;
            }
            if (iVar15 == 0) {
                uVar13 = *(undefined4 *)((int64_t)&var_8h + iVar7);
            } else {
                *(uint32_t *)(&stack0xfffffffffffffff8 + iVar7) = uVar12;
                uVar13 = *(undefined4 *)((int64_t)&var_8h + iVar7);
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180264b47;
                func_0x000180296d10(in_RDX, uVar13, uVar10, in_R9D);
            }
            uVar1 = *(undefined4 *)((int64_t)&var_8h + iVar7 + 4);
            *(undefined4 *)(&stack0xfffffffffffffff8 + iVar7) = *(undefined4 *)((int64_t)&var_10h + iVar7 + 4);
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180264b67;
            func_0x000180296d10(in_RDX, uVar13, iVar11, uVar1);
            pcVar3 = *(code **)(in_R8 + 6);
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180264b6a;
            (*pcVar3)();
            *(uint32_t *)(&stack0x00000000 + iVar7) = uVar14;
            *(undefined4 *)(&stack0xfffffffffffffff8 + iVar7) = *(undefined4 *)((int64_t)&var_18h + iVar7);
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180264b8a;
            fcn.1802646b0(*(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7), *(int64_t *)(&stack0x00000048 + iVar7), 
                          *(int64_t *)(&stack0x00000050 + iVar7), *(int64_t *)(&stack0x000000d0 + iVar7));
            if (*(char *)((int64_t)&arg_78h + iVar7) != '\0') {
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180264b9c;
                func_0x000180296cf0(in_RDX);
                if ((uVar6 & 0x10) != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180264baa;
                    func_0x000180296cf0(in_RDX);
                    return uVar9;
                }
                return uVar9;
            }
            return uVar9;
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_180264ce0
// Address: 0x180264ce0
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int32_t fcn.180264ce0(int64_t arg_28h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 *in_RCX;
    undefined8 *in_RDX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180264cf0;
    iVar6 = fcn.18045a350();
    iVar1 = *(int32_t *)(in_RDX + 1);
    iVar2 = *(int32_t *)(in_RCX + 1);
    uVar3 = *in_RDX;
    uVar4 = *in_RCX;
    iVar5 = iVar2;
    if (iVar1 <= iVar2) {
        iVar5 = iVar1;
    }
    *(undefined8 *)((int64_t)&uStack_10 - iVar6) = 0x180264d0e;
    iVar5 = fcn.180497f30(uVar4, uVar3, (int64_t)iVar5);
    iVar1 = iVar2 - iVar1;
    if (iVar5 != 0) {
        iVar1 = iVar5;
    }
    return iVar1;
}

// ============================================================
// Function: FUN_180264d30
// Address: 0x180264d30
// Size: 95 bytes
// ============================================================
void fcn.180264d30(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180264d40;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0x20);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            uVar3 = *(undefined8 *)(arg1 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180264d6b;
            fcn.180224990(uVar3, 0x1804e6e50, 0x1ef);
            uVar3 = *(undefined8 *)(arg1 + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180264d74;
            fcn.18027edb0(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180264d89;
            fcn.180224990(arg1, 0x1804e6e50, 0x1f2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180264d90
// Address: 0x180264d90
// Size: 509 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.180264d90(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    code *pcVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int32_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    int64_t iVar9;
    uint64_t *in_R8;
    undefined8 in_R9;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180264da3;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RCX == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264dbc;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264dd4;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264de6;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
        return 0xfffffffe;
    }
    if (*in_RCX != 0x400) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264e06;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264e1e;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264e30;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
        return 0xffffffff;
    }
    if (*(int64_t *)(in_RCX + 0xc) != 0) {
        *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_R14;
        iVar1 = *(int64_t *)(in_RCX + 10);
        iVar3 = *(int64_t *)(iVar1 + 0x10);
        iVar9 = 0x1805aadb1;
        if (iVar3 != 0) {
            iVar9 = iVar3;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264fb2;
        fcn.180229b10();
        if (in_RDX == 0) {
            uVar8 = 0;
        } else {
            uVar8 = *in_R8;
        }
        pcVar4 = *(code **)(iVar1 + 0x48);
        uVar2 = *(undefined8 *)(in_RCX + 0xc);
        *(undefined8 *)((int64_t)&var_10h + iVar7) = *(undefined8 *)((int64_t)&arg_58h + iVar7);
        *(undefined8 *)((int64_t)&var_8h + iVar7) = in_R9;
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264fdf;
        uVar6 = (*pcVar4)(uVar2, in_RDX, in_R8, uVar8);
        if ((int32_t)uVar6 < 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264fea;
            iVar5 = fcn.180229970();
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264ff3;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18026500b;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7));
                *(int64_t *)((int64_t)&var_8h + iVar7) = iVar9;
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18026502a;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18026502f;
        fcn.180229900();
        return (uint64_t)uVar6;
    }
    iVar1 = *(int64_t *)(in_RCX + 0x1e);
    if ((iVar1 != 0) && (*(int64_t *)(iVar1 + 0xa8) != 0)) {
        if ((*(uint8_t *)(iVar1 + 4) & 2) != 0) {
            uVar2 = *(undefined8 *)(in_RCX + 0x22);
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264e7f;
            iVar5 = fcn.18022fbd0(uVar2);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264e8b;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264ea3;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264eb5;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
                return 0;
            }
            if (in_RDX == 0) {
                *in_R8 = (int64_t)iVar5;
                return 1;
            }
            if (*in_R8 < (uint64_t)(int64_t)iVar5) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264eea;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264f02;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264f14;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
                return 0;
            }
        }
    // WARNING: Could not recover jumptable at 0x000180264f48. Too many branches
    // WARNING: Treating indirect jump as call
        uVar8 = (**(code **)(*(int64_t *)(in_RCX + 0x1e) + 0xa8))(in_RCX, in_RDX, in_R8, in_R9);
        return uVar8;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264f50;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264f68;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                  *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                  *(int64_t *)((int64_t)&arg_38h + iVar7));
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264f7a;
    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_180264f8d
// Address: 0x180264f8d
// Size: 188 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.180264d90(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    code *pcVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int32_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    int64_t iVar9;
    uint64_t *in_R8;
    undefined8 in_R9;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180264da3;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RCX == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264dbc;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264dd4;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264de6;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
        return 0xfffffffe;
    }
    if (*in_RCX != 0x400) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264e06;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264e1e;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264e30;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
        return 0xffffffff;
    }
    if (*(int64_t *)(in_RCX + 0xc) != 0) {
        *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_R14;
        iVar1 = *(int64_t *)(in_RCX + 10);
        iVar3 = *(int64_t *)(iVar1 + 0x10);
        iVar9 = 0x1805aadb1;
        if (iVar3 != 0) {
            iVar9 = iVar3;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264fb2;
        fcn.180229b10();
        if (in_RDX == 0) {
            uVar8 = 0;
        } else {
            uVar8 = *in_R8;
        }
        pcVar4 = *(code **)(iVar1 + 0x48);
        uVar2 = *(undefined8 *)(in_RCX + 0xc);
        *(undefined8 *)((int64_t)&var_10h + iVar7) = *(undefined8 *)((int64_t)&arg_58h + iVar7);
        *(undefined8 *)((int64_t)&var_8h + iVar7) = in_R9;
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264fdf;
        uVar6 = (*pcVar4)(uVar2, in_RDX, in_R8, uVar8);
        if ((int32_t)uVar6 < 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264fea;
            iVar5 = fcn.180229970();
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264ff3;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18026500b;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7));
                *(int64_t *)((int64_t)&var_8h + iVar7) = iVar9;
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18026502a;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18026502f;
        fcn.180229900();
        return (uint64_t)uVar6;
    }
    iVar1 = *(int64_t *)(in_RCX + 0x1e);
    if ((iVar1 != 0) && (*(int64_t *)(iVar1 + 0xa8) != 0)) {
        if ((*(uint8_t *)(iVar1 + 4) & 2) != 0) {
            uVar2 = *(undefined8 *)(in_RCX + 0x22);
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264e7f;
            iVar5 = fcn.18022fbd0(uVar2);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264e8b;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264ea3;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264eb5;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
                return 0;
            }
            if (in_RDX == 0) {
                *in_R8 = (int64_t)iVar5;
                return 1;
            }
            if (*in_R8 < (uint64_t)(int64_t)iVar5) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264eea;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264f02;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264f14;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
                return 0;
            }
        }
    // WARNING: Could not recover jumptable at 0x000180264f48. Too many branches
    // WARNING: Treating indirect jump as call
        uVar8 = (**(code **)(*(int64_t *)(in_RCX + 0x1e) + 0xa8))(in_RCX, in_RDX, in_R8, in_R9);
        return uVar8;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264f50;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264f68;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                  *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                  *(int64_t *)((int64_t)&arg_38h + iVar7));
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180264f7a;
    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_180265050
// Address: 0x180265050
// Size: 30 bytes
// ============================================================
int32_t fcn.180265050(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_50h, int64_t arg_58h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    code *pcVar9;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    int64_t iVar10;
    int32_t iVar11;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int32_t iVar12;
    undefined8 unaff_R15;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026505a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar12 = 0x400;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = 0;
    *(undefined4 *)((int64_t)&arg_38h + iVar3) = 0x400;
    *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_RBX;
    *(undefined8 *)(&stack0x00000018 + iVar3) = unaff_RBP;
    *(undefined8 *)(&stack0x00000010 + iVar3) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar3) = unaff_RDI;
    *(undefined8 *)(&stack0x00000000 + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180265719;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar6 = 0;
    iVar11 = 0;
    iVar2 = 0;
    *(undefined8 *)((int64_t)&arg_90h + iVar4 + iVar3) = 0;
    if (in_RCX == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x18026573a;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265752;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265764;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3));
        return -2;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar4 + iVar3) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_50h + iVar4 + iVar3) = unaff_R13;
    *(undefined8 *)((int64_t)&arg_48h + iVar4 + iVar3) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265788;
    fcn.180259930();
    *in_RCX = iVar12;
    *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x18026578f;
    fcn.180229b10();
    iVar5 = *(int64_t *)(in_RCX + 8);
    if (iVar5 == 0) {
code_r0x000180265950:
        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265955;
        fcn.1802299d0(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265962;
        fcn.180257a00(*(undefined8 *)((int64_t)&arg_90h + iVar4 + iVar3));
        iVar6 = *(int64_t *)(in_RCX + 0x1e);
        *(undefined8 *)((int64_t)&arg_90h + iVar4 + iVar3) = 0;
        if ((iVar6 == 0) || (*(int64_t *)(iVar6 + 0x98) == 0)) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265c7b;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3));
            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265c93;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3));
            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265ca5;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3));
            return -2;
        }
        if (*in_RCX == 0x200) {
            pcVar9 = *(code **)(iVar6 + 0x90);
        } else {
            if (*in_RCX != 0x400) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x1802659a3;
                fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3));
                *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x1802659bb;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3));
                *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x1802659cd;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3));
                iVar2 = -1;
                goto code_r0x000180265c57;
            }
            pcVar9 = *(code **)(iVar6 + 0xa0);
        }
        if (pcVar9 == (code *)0x0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265c51;
        iVar2 = (*pcVar9)(in_RCX);
        if (0 < iVar2) goto code_r0x000180265c65;
    } else if (*(int64_t *)(in_RCX + 0x22) == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x1802657ad;
        fcn.180229900();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x1802657b2;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x1802657ca;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x1802657dc;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3));
        iVar2 = iVar11;
    } else {
        iVar7 = *(int64_t *)(*(int64_t *)(in_RCX + 0x22) + 0x60);
        if ((iVar7 == 0) || (iVar7 == iVar5)) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265832;
            iVar5 = fcn.18029f2b0(iVar5, 0xd);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x18026583f;
                fcn.180229900();
                *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265844;
                fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3));
                *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x18026585c;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3));
                *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x18026586e;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3));
                iVar2 = iVar11;
            } else {
                iVar12 = 1;
                iVar5 = 0;
                do {
                    if (iVar5 != 0) goto code_r0x000180265adf;
                    if (iVar6 != 0) {
                        LOCK();
                        piVar1 = (int32_t *)(iVar6 + 0x20);
                        iVar11 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar11 < 2) {
                            uVar8 = *(undefined8 *)(iVar6 + 8);
                            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x1802658b6;
                            fcn.180224990(uVar8, 0x1804e6e50, 0x1ef);
                            uVar8 = *(undefined8 *)(iVar6 + 0x18);
                            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x1802658bf;
                            fcn.18027edb0(uVar8);
                            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x1802658d4;
                            fcn.180224990(iVar6, 0x1804e6e50, 0x1f2);
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x1802658e1;
                    fcn.180257a00(*(undefined8 *)((int64_t)&arg_90h + iVar4 + iVar3));
                    if (iVar12 == 1) {
                        *(undefined8 *)((int64_t)&arg_30h + iVar4 + iVar3) = 0x180265350;
                        *(undefined8 *)((int64_t)&arg_28h + iVar4 + iVar3) = 0x180248230;
                        *(undefined8 *)((int64_t)&var_20h + iVar4 + iVar3) = 0x1802653b0;
                        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265a10;
                        iVar6 = fcn.180280c20(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                              *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3), 
                                              *(int64_t *)(&stack0x000000b0 + iVar4 + iVar3), 
                                              *(int64_t *)(&stack0x000000b8 + iVar4 + iVar3), 
                                              *(int64_t *)(&stack0x000000c0 + iVar4 + iVar3));
                        if (iVar6 != 0) goto code_r0x000180265a1c;
                    } else {
                        if (iVar12 == 2) {
                            uVar8 = *(undefined8 *)(in_RCX + 8);
                            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265909;
                            fcn.1801dd170(uVar8);
                            *(undefined8 *)((int64_t)&arg_30h + iVar4 + iVar3) = 0x180265350;
                            *(undefined8 *)((int64_t)&arg_28h + iVar4 + iVar3) = 0x180248230;
                            *(undefined8 *)((int64_t)&var_20h + iVar4 + iVar3) = 0x1802653b0;
                            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265944;
                            iVar6 = fcn.180280ca0(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                  *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3), 
                                                  *(int64_t *)(&stack0x00000080 + iVar4 + iVar3), 
                                                  *(int64_t *)(&stack0x000000b0 + iVar4 + iVar3), 
                                                  *(int64_t *)(&stack0x000000b8 + iVar4 + iVar3), 
                                                  *(int64_t *)(&stack0x000000c0 + iVar4 + iVar3));
                            if (iVar6 == 0) goto code_r0x000180265950;
                        } else if (iVar6 == 0) goto code_r0x000180265a78;
code_r0x000180265a1c:
                        uVar8 = *(undefined8 *)(in_RCX + 8);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265a29;
                        fcn.1801dd6c0(uVar8);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265a37;
                        iVar7 = fcn.180257b60(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3));
                        *(int64_t *)((int64_t)&arg_90h + iVar4 + iVar3) = iVar7;
                        if (iVar7 != 0) {
                            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265a63;
                            iVar5 = fcn.180230ea0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                                                  *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                                                  *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                                                  *(int64_t *)(&stack0x000000a8 + iVar4 + iVar3));
                        }
                        if (*(int64_t *)((int64_t)&arg_90h + iVar4 + iVar3) == 0) {
                            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265a78;
                            fcn.180257a00(iVar7);
                        }
                    }
code_r0x000180265a78:
                    iVar12 = iVar12 + 1;
                } while (iVar12 < 3);
                if (iVar5 == 0) {
                    if (iVar6 != 0) {
                        LOCK();
                        piVar1 = (int32_t *)(iVar6 + 0x20);
                        iVar2 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar2 < 2) {
                            uVar8 = *(undefined8 *)(iVar6 + 8);
                            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265abc;
                            fcn.180224990(uVar8, 0x1804e6e50, 0x1ef);
                            uVar8 = *(undefined8 *)(iVar6 + 0x18);
                            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265ac5;
                            fcn.18027edb0(uVar8);
                            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265ada;
                            fcn.180224990(iVar6, 0x1804e6e50, 0x1f2);
                        }
                    }
                    goto code_r0x000180265950;
                }
code_r0x000180265adf:
                *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265ae4;
                fcn.1802299d0(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3));
                *(int64_t *)(in_RCX + 10) = iVar6;
                uVar8 = *(undefined8 *)(iVar6 + 0x18);
                pcVar9 = *(code **)(iVar6 + 0x28);
                *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265af5;
                uVar8 = fcn.18027e810(uVar8);
                *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265afa;
                iVar7 = (*pcVar9)(uVar8);
                *(int64_t *)(in_RCX + 0xc) = iVar7;
                if (iVar7 == 0) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265b0b;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265b23;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265b35;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3));
                } else {
                    iVar10 = 0x1805aadb1;
                    if (*(int64_t *)(iVar6 + 0x10) != 0) {
                        iVar10 = *(int64_t *)(iVar6 + 0x10);
                    }
                    iVar12 = *(int32_t *)((int64_t)&arg_98h + iVar4 + iVar3);
                    if (iVar12 == 0x200) {
                        pcVar9 = *(code **)(iVar6 + 0x30);
                        if (pcVar9 == (code *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265bd2;
                            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3));
                            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265bea;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3));
                            goto code_r0x000180265bf1;
                        }
code_r0x000180265c10:
                        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265c1d;
                        iVar2 = (*pcVar9)(iVar7, iVar5, *(undefined8 *)((int64_t)&arg_a0h + iVar4 + iVar3));
                        if (0 < iVar2) {
                            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265c30;
                            fcn.180257a00(*(undefined8 *)((int64_t)&arg_90h + iVar4 + iVar3));
                            return 1;
                        }
                    } else if (iVar12 == 0x400) {
                        pcVar9 = *(code **)(iVar6 + 0x40);
                        if (pcVar9 != (code *)0x0) goto code_r0x000180265c10;
                        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265ba3;
                        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265bbb;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3));
code_r0x000180265bf1:
                        *(int64_t *)((int64_t)&var_20h + iVar4 + iVar3) = iVar10;
                        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265c09;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3));
                        iVar2 = -2;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265b66;
                        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265b7e;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265b90;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3));
                    }
                }
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x1802657f4;
            fcn.180229900();
            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x1802657f9;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3));
            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265811;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3));
            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265823;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3));
            iVar2 = iVar11;
        }
    }
code_r0x000180265c57:
    *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265c5f;
    fcn.180259930(in_RCX);
    *in_RCX = 0;
code_r0x000180265c65:
    *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265c72;
    fcn.180257a00(*(undefined8 *)((int64_t)&arg_90h + iVar4 + iVar3));
    return iVar2;
}

// ============================================================
// Function: FUN_180265070
// Address: 0x180265070
// Size: 509 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.180265070(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    code *pcVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int32_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    int64_t iVar9;
    uint64_t *in_R8;
    undefined8 in_R9;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180265083;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RCX == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18026509c;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802650b4;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802650c6;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
        return 0xfffffffe;
    }
    if (*in_RCX != 0x200) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802650e6;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802650fe;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180265110;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
        return 0xffffffff;
    }
    if (*(int64_t *)(in_RCX + 0xc) != 0) {
        *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_R14;
        iVar1 = *(int64_t *)(in_RCX + 10);
        iVar3 = *(int64_t *)(iVar1 + 0x10);
        iVar9 = 0x1805aadb1;
        if (iVar3 != 0) {
            iVar9 = iVar3;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180265292;
        fcn.180229b10();
        if (in_RDX == 0) {
            uVar8 = 0;
        } else {
            uVar8 = *in_R8;
        }
        pcVar4 = *(code **)(iVar1 + 0x38);
        uVar2 = *(undefined8 *)(in_RCX + 0xc);
        *(undefined8 *)((int64_t)&var_10h + iVar7) = *(undefined8 *)((int64_t)&arg_58h + iVar7);
        *(undefined8 *)((int64_t)&var_8h + iVar7) = in_R9;
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802652bf;
        uVar6 = (*pcVar4)(uVar2, in_RDX, in_R8, uVar8);
        if ((int32_t)uVar6 < 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802652ca;
            iVar5 = fcn.180229970();
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802652d3;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802652eb;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7));
                *(int64_t *)((int64_t)&var_8h + iVar7) = iVar9;
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18026530a;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18026530f;
        fcn.180229900();
        return (uint64_t)uVar6;
    }
    iVar1 = *(int64_t *)(in_RCX + 0x1e);
    if ((iVar1 != 0) && (*(int64_t *)(iVar1 + 0x98) != 0)) {
        if ((*(uint8_t *)(iVar1 + 4) & 2) != 0) {
            uVar2 = *(undefined8 *)(in_RCX + 0x22);
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18026515f;
            iVar5 = fcn.18022fbd0(uVar2);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18026516b;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180265183;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180265195;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
                return 0;
            }
            if (in_RDX == 0) {
                *in_R8 = (int64_t)iVar5;
                return 1;
            }
            if (*in_R8 < (uint64_t)(int64_t)iVar5) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802651ca;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802651e2;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802651f4;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
                return 0;
            }
        }
    // WARNING: Could not recover jumptable at 0x000180265228. Too many branches
    // WARNING: Treating indirect jump as call
        uVar8 = (**(code **)(*(int64_t *)(in_RCX + 0x1e) + 0x98))(in_RCX, in_RDX, in_R8, in_R9);
        return uVar8;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180265230;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180265248;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                  *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                  *(int64_t *)((int64_t)&arg_38h + iVar7));
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18026525a;
    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_18026526d
// Address: 0x18026526d
// Size: 188 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.180265070(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    code *pcVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int32_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    int64_t iVar9;
    uint64_t *in_R8;
    undefined8 in_R9;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180265083;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RCX == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18026509c;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802650b4;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802650c6;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
        return 0xfffffffe;
    }
    if (*in_RCX != 0x200) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802650e6;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802650fe;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180265110;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
        return 0xffffffff;
    }
    if (*(int64_t *)(in_RCX + 0xc) != 0) {
        *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_R14;
        iVar1 = *(int64_t *)(in_RCX + 10);
        iVar3 = *(int64_t *)(iVar1 + 0x10);
        iVar9 = 0x1805aadb1;
        if (iVar3 != 0) {
            iVar9 = iVar3;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180265292;
        fcn.180229b10();
        if (in_RDX == 0) {
            uVar8 = 0;
        } else {
            uVar8 = *in_R8;
        }
        pcVar4 = *(code **)(iVar1 + 0x38);
        uVar2 = *(undefined8 *)(in_RCX + 0xc);
        *(undefined8 *)((int64_t)&var_10h + iVar7) = *(undefined8 *)((int64_t)&arg_58h + iVar7);
        *(undefined8 *)((int64_t)&var_8h + iVar7) = in_R9;
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802652bf;
        uVar6 = (*pcVar4)(uVar2, in_RDX, in_R8, uVar8);
        if ((int32_t)uVar6 < 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802652ca;
            iVar5 = fcn.180229970();
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802652d3;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802652eb;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7));
                *(int64_t *)((int64_t)&var_8h + iVar7) = iVar9;
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18026530a;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18026530f;
        fcn.180229900();
        return (uint64_t)uVar6;
    }
    iVar1 = *(int64_t *)(in_RCX + 0x1e);
    if ((iVar1 != 0) && (*(int64_t *)(iVar1 + 0x98) != 0)) {
        if ((*(uint8_t *)(iVar1 + 4) & 2) != 0) {
            uVar2 = *(undefined8 *)(in_RCX + 0x22);
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18026515f;
            iVar5 = fcn.18022fbd0(uVar2);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18026516b;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180265183;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180265195;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
                return 0;
            }
            if (in_RDX == 0) {
                *in_R8 = (int64_t)iVar5;
                return 1;
            }
            if (*in_R8 < (uint64_t)(int64_t)iVar5) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802651ca;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802651e2;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802651f4;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
                return 0;
            }
        }
    // WARNING: Could not recover jumptable at 0x000180265228. Too many branches
    // WARNING: Treating indirect jump as call
        uVar8 = (**(code **)(*(int64_t *)(in_RCX + 0x1e) + 0x98))(in_RCX, in_RDX, in_R8, in_R9);
        return uVar8;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180265230;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180265248;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                  *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                  *(int64_t *)((int64_t)&arg_38h + iVar7));
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18026525a;
    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_180265330
// Address: 0x180265330
// Size: 30 bytes
// ============================================================
int32_t fcn.180265330(int32_t *param_1)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    code *pcVar9;
    undefined8 unaff_RBX;
    int64_t iVar10;
    int32_t iVar11;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int32_t iVar12;
    undefined8 unaff_R15;
    int64_t iStack_8;
    
    iStack_8 = 0x18026533a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar12 = 0x200;
    *(undefined8 *)(&stack0x00000040 + iVar3) = 0;
    *(undefined4 *)(&stack0x00000038 + iVar3) = 0x200;
    *(undefined8 *)(&stack0x00000020 + iVar3) = unaff_RBX;
    *(undefined8 *)(&stack0x00000018 + iVar3) = unaff_RBP;
    *(undefined8 *)(&stack0x00000010 + iVar3) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar3) = unaff_RDI;
    *(undefined8 *)(&stack0x00000020 + iVar3 + -0x20) = unaff_R14;
    *(undefined8 *)((int64_t)&iStack_8 + iVar3) = 0x180265719;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar6 = 0;
    iVar11 = 0;
    iVar2 = 0;
    *(undefined8 *)(&stack0x00000090 + iVar4 + iVar3) = 0;
    if (param_1 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x18026573a;
        fcn.180229480(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), *(int64_t *)(&stack0x00000028 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265752;
        fcn.1802295a0(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), *(int64_t *)(&stack0x00000028 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000030 + iVar4 + iVar3), *(int64_t *)(&stack0x00000038 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265764;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3));
        return -2;
    }
    *(undefined8 *)(&stack0x00000058 + iVar4 + iVar3) = unaff_R12;
    *(undefined8 *)(&stack0x00000050 + iVar4 + iVar3) = unaff_R13;
    *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = unaff_R15;
    *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265788;
    fcn.180259930();
    *param_1 = iVar12;
    *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x18026578f;
    fcn.180229b10();
    iVar5 = *(int64_t *)(param_1 + 8);
    if (iVar5 == 0) {
code_r0x000180265950:
        *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265955;
        fcn.1802299d0(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), *(int64_t *)(&stack0x00000028 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265962;
        fcn.180257a00(*(undefined8 *)(&stack0x00000090 + iVar4 + iVar3));
        iVar6 = *(int64_t *)(param_1 + 0x1e);
        *(undefined8 *)(&stack0x00000090 + iVar4 + iVar3) = 0;
        if ((iVar6 == 0) || (*(int64_t *)(iVar6 + 0x98) == 0)) {
            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265c7b;
            fcn.180229480(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), *(int64_t *)(&stack0x00000028 + iVar4 + iVar3)
                         );
            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265c93;
            fcn.1802295a0(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), *(int64_t *)(&stack0x00000028 + iVar4 + iVar3)
                          , *(int64_t *)(&stack0x00000030 + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000038 + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3)
                         );
            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265ca5;
            fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3));
            return -2;
        }
        if (*param_1 == 0x200) {
            pcVar9 = *(code **)(iVar6 + 0x90);
        } else {
            if (*param_1 != 0x400) {
                *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802659a3;
                fcn.180229480(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000028 + iVar4 + iVar3));
                *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802659bb;
                fcn.1802295a0(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000028 + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000030 + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000038 + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
                *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802659cd;
                fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3));
                iVar2 = -1;
                goto code_r0x000180265c57;
            }
            pcVar9 = *(code **)(iVar6 + 0xa0);
        }
        if (pcVar9 == (code *)0x0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265c51;
        iVar2 = (*pcVar9)(param_1);
        if (0 < iVar2) goto code_r0x000180265c65;
    } else if (*(int64_t *)(param_1 + 0x22) == 0) {
        *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802657ad;
        fcn.180229900();
        *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802657b2;
        fcn.180229480(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), *(int64_t *)(&stack0x00000028 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802657ca;
        fcn.1802295a0(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), *(int64_t *)(&stack0x00000028 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000030 + iVar4 + iVar3), *(int64_t *)(&stack0x00000038 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802657dc;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3));
        iVar2 = iVar11;
    } else {
        iVar7 = *(int64_t *)(*(int64_t *)(param_1 + 0x22) + 0x60);
        if ((iVar7 == 0) || (iVar7 == iVar5)) {
            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265832;
            iVar5 = fcn.18029f2b0(iVar5, 0xd);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x18026583f;
                fcn.180229900();
                *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265844;
                fcn.180229480(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000028 + iVar4 + iVar3));
                *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x18026585c;
                fcn.1802295a0(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000028 + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000030 + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000038 + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
                *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x18026586e;
                fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3));
                iVar2 = iVar11;
            } else {
                iVar12 = 1;
                iVar5 = 0;
                do {
                    if (iVar5 != 0) goto code_r0x000180265adf;
                    if (iVar6 != 0) {
                        LOCK();
                        piVar1 = (int32_t *)(iVar6 + 0x20);
                        iVar11 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar11 < 2) {
                            uVar8 = *(undefined8 *)(iVar6 + 8);
                            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802658b6;
                            fcn.180224990(uVar8, 0x1804e6e50, 0x1ef);
                            uVar8 = *(undefined8 *)(iVar6 + 0x18);
                            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802658bf;
                            fcn.18027edb0(uVar8);
                            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802658d4;
                            fcn.180224990(iVar6, 0x1804e6e50, 0x1f2);
                        }
                    }
                    *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802658e1;
                    fcn.180257a00(*(undefined8 *)(&stack0x00000090 + iVar4 + iVar3));
                    if (iVar12 == 1) {
                        *(undefined8 *)(&stack0x00000030 + iVar4 + iVar3) = 0x180265350;
                        *(undefined8 *)(&stack0x00000028 + iVar4 + iVar3) = 0x180248230;
                        *(undefined8 *)(&stack0x00000020 + iVar4 + iVar3) = 0x1802653b0;
                        *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265a10;
                        iVar6 = fcn.180280c20(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), 
                                              *(int64_t *)(&stack0x00000028 + iVar4 + iVar3), 
                                              *(int64_t *)(&stack0x00000030 + iVar4 + iVar3), 
                                              *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                                              *(int64_t *)(&stack0x000000b0 + iVar4 + iVar3), 
                                              *(int64_t *)(&stack0x000000b8 + iVar4 + iVar3), 
                                              *(int64_t *)(&stack0x000000c0 + iVar4 + iVar3));
                        if (iVar6 != 0) goto code_r0x000180265a1c;
                    } else {
                        if (iVar12 == 2) {
                            uVar8 = *(undefined8 *)(param_1 + 8);
                            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265909;
                            fcn.1801dd170(uVar8);
                            *(undefined8 *)(&stack0x00000030 + iVar4 + iVar3) = 0x180265350;
                            *(undefined8 *)(&stack0x00000028 + iVar4 + iVar3) = 0x180248230;
                            *(undefined8 *)(&stack0x00000020 + iVar4 + iVar3) = 0x1802653b0;
                            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265944;
                            iVar6 = fcn.180280ca0(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), 
                                                  *(int64_t *)(&stack0x00000028 + iVar4 + iVar3), 
                                                  *(int64_t *)(&stack0x00000030 + iVar4 + iVar3), 
                                                  *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                                                  *(int64_t *)(&stack0x00000080 + iVar4 + iVar3), 
                                                  *(int64_t *)(&stack0x000000b0 + iVar4 + iVar3), 
                                                  *(int64_t *)(&stack0x000000b8 + iVar4 + iVar3), 
                                                  *(int64_t *)(&stack0x000000c0 + iVar4 + iVar3));
                            if (iVar6 == 0) goto code_r0x000180265950;
                        } else if (iVar6 == 0) goto code_r0x000180265a78;
code_r0x000180265a1c:
                        uVar8 = *(undefined8 *)(param_1 + 8);
                        *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265a29;
                        fcn.1801dd6c0(uVar8);
                        *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265a37;
                        iVar7 = fcn.180257b60(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), 
                                              *(int64_t *)(&stack0x00000028 + iVar4 + iVar3));
                        *(int64_t *)(&stack0x00000090 + iVar4 + iVar3) = iVar7;
                        if (iVar7 != 0) {
                            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265a63;
                            iVar5 = fcn.180230ea0(*(int64_t *)(&stack0x00000030 + iVar4 + iVar3), 
                                                  *(int64_t *)(&stack0x00000038 + iVar4 + iVar3), 
                                                  *(int64_t *)(&stack0x00000040 + iVar4 + iVar3), 
                                                  *(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                                                  *(int64_t *)(&stack0x000000a8 + iVar4 + iVar3));
                        }
                        if (*(int64_t *)(&stack0x00000090 + iVar4 + iVar3) == 0) {
                            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265a78;
                            fcn.180257a00(iVar7);
                        }
                    }
code_r0x000180265a78:
                    iVar12 = iVar12 + 1;
                } while (iVar12 < 3);
                if (iVar5 == 0) {
                    if (iVar6 != 0) {
                        LOCK();
                        piVar1 = (int32_t *)(iVar6 + 0x20);
                        iVar2 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar2 < 2) {
                            uVar8 = *(undefined8 *)(iVar6 + 8);
                            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265abc;
                            fcn.180224990(uVar8, 0x1804e6e50, 0x1ef);
                            uVar8 = *(undefined8 *)(iVar6 + 0x18);
                            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265ac5;
                            fcn.18027edb0(uVar8);
                            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265ada;
                            fcn.180224990(iVar6, 0x1804e6e50, 0x1f2);
                        }
                    }
                    goto code_r0x000180265950;
                }
code_r0x000180265adf:
                *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265ae4;
                fcn.1802299d0(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000028 + iVar4 + iVar3));
                *(int64_t *)(param_1 + 10) = iVar6;
                uVar8 = *(undefined8 *)(iVar6 + 0x18);
                pcVar9 = *(code **)(iVar6 + 0x28);
                *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265af5;
                uVar8 = fcn.18027e810(uVar8);
                *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265afa;
                iVar7 = (*pcVar9)(uVar8);
                *(int64_t *)(param_1 + 0xc) = iVar7;
                if (iVar7 == 0) {
                    *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265b0b;
                    fcn.180229480(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), 
                                  *(int64_t *)(&stack0x00000028 + iVar4 + iVar3));
                    *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265b23;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), 
                                  *(int64_t *)(&stack0x00000028 + iVar4 + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar4 + iVar3), 
                                  *(int64_t *)(&stack0x00000038 + iVar4 + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
                    *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265b35;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3));
                } else {
                    iVar10 = 0x1805aadb1;
                    if (*(int64_t *)(iVar6 + 0x10) != 0) {
                        iVar10 = *(int64_t *)(iVar6 + 0x10);
                    }
                    if (*(int32_t *)(&stack0x00000098 + iVar4 + iVar3) == 0x200) {
                        pcVar9 = *(code **)(iVar6 + 0x30);
                        if (pcVar9 == (code *)0x0) {
                            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265bd2;
                            fcn.180229480(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), 
                                          *(int64_t *)(&stack0x00000028 + iVar4 + iVar3));
                            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265bea;
                            fcn.1802295a0(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), 
                                          *(int64_t *)(&stack0x00000028 + iVar4 + iVar3), 
                                          *(int64_t *)(&stack0x00000030 + iVar4 + iVar3), 
                                          *(int64_t *)(&stack0x00000038 + iVar4 + iVar3), 
                                          *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
                            goto code_r0x000180265bf1;
                        }
code_r0x000180265c10:
                        *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265c1d;
                        iVar2 = (*pcVar9)(iVar7, iVar5, *(undefined8 *)(&stack0x000000a0 + iVar4 + iVar3));
                        if (0 < iVar2) {
                            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265c30;
                            fcn.180257a00(*(undefined8 *)(&stack0x00000090 + iVar4 + iVar3));
                            return 1;
                        }
                    } else if (*(int32_t *)(&stack0x00000098 + iVar4 + iVar3) == 0x400) {
                        pcVar9 = *(code **)(iVar6 + 0x40);
                        if (pcVar9 != (code *)0x0) goto code_r0x000180265c10;
                        *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265ba3;
                        fcn.180229480(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x00000028 + iVar4 + iVar3));
                        *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265bbb;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x00000028 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x00000030 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x00000038 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
code_r0x000180265bf1:
                        *(int64_t *)(&stack0x00000020 + iVar4 + iVar3) = iVar10;
                        *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265c09;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3));
                        iVar2 = -2;
                    } else {
                        *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265b66;
                        fcn.180229480(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x00000028 + iVar4 + iVar3));
                        *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265b7e;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x00000028 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x00000030 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x00000038 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
                        *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265b90;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3));
                    }
                }
            }
        } else {
            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802657f4;
            fcn.180229900();
            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802657f9;
            fcn.180229480(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), *(int64_t *)(&stack0x00000028 + iVar4 + iVar3)
                         );
            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265811;
            fcn.1802295a0(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), *(int64_t *)(&stack0x00000028 + iVar4 + iVar3)
                          , *(int64_t *)(&stack0x00000030 + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000038 + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3)
                         );
            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265823;
            fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3));
            iVar2 = iVar11;
        }
    }
code_r0x000180265c57:
    *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265c5f;
    fcn.180259930(param_1);
    *param_1 = 0;
code_r0x000180265c65:
    *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x180265c72;
    fcn.180257a00(*(undefined8 *)(&stack0x00000090 + iVar4 + iVar3));
    return iVar2;
}

// ============================================================
// Function: FUN_180265350
// Address: 0x180265350
// Size: 95 bytes
// ============================================================
void fcn.180265350(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180265360;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0x20);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            uVar3 = *(undefined8 *)(arg1 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026538b;
            fcn.180224990(uVar3, 0x1804e6e50, 0x1ef);
            uVar3 = *(undefined8 *)(arg1 + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180265394;
            fcn.18027edb0(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802653a9;
            fcn.180224990(arg1, 0x1804e6e50, 0x1f2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1802653b0
// Address: 0x1802653b0
// Size: 840 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined4 * fcn.1802653b0(int64_t arg_38h, int64_t arg_40h, int64_t arg_50h)
{
    int32_t *piVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    undefined4 in_ECX;
    uint32_t uVar7;
    int64_t in_RDX;
    undefined8 *puVar8;
    int32_t iVar9;
    int32_t iVar10;
    undefined8 in_R8;
    uint32_t uVar11;
    uint32_t uVar12;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_40;
    
    uStack_40 = 0x1802653ca;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    piVar1 = *(int32_t **)(in_RDX + 0x10);
    iVar9 = 0;
    *(undefined4 *)((int64_t)&arg_40h + iVar4) = 0;
    uVar12 = 0;
    uVar11 = 0;
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1802653fd;
    puVar5 = (undefined4 *)fcn.180224d60(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4));
    if (puVar5 != (undefined4 *)0x0) {
        puVar5[8] = 1;
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180265418;
        iVar3 = func_0x00018027fb30(in_R8);
        if (iVar3 != 0) {
            *(undefined8 *)(puVar5 + 6) = in_R8;
            *puVar5 = in_ECX;
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18026542f;
            iVar6 = func_0x000180282210(in_RDX);
            *(int64_t *)(puVar5 + 2) = iVar6;
            if (iVar6 != 0) {
                *(undefined8 *)(puVar5 + 4) = *(undefined8 *)(in_RDX + 0x18);
                iVar3 = *piVar1;
                if (iVar3 != 0) {
                    puVar8 = (undefined8 *)(piVar1 + 2);
                    iVar10 = 0;
                    do {
    // switch table (11 cases) at 0x1802656cc
                        switch(iVar3) {
                        case 1:
                            uVar7 = *(uint32_t *)((int64_t)&arg_40h + iVar4);
                            if (*(int64_t *)(puVar5 + 10) == 0) {
                                iVar9 = iVar9 + 1;
                                *(undefined8 *)(puVar5 + 10) = *puVar8;
                            }
                            break;
                        case 2:
                            uVar7 = *(uint32_t *)((int64_t)&arg_40h + iVar4);
                            if (*(int64_t *)(puVar5 + 0xc) == 0) {
                                uVar12 = uVar12 + 1;
                                *(undefined8 *)(puVar5 + 0xc) = *puVar8;
                            }
                            break;
                        case 3:
                            uVar7 = *(uint32_t *)((int64_t)&arg_40h + iVar4);
                            if (*(int64_t *)(puVar5 + 0xe) == 0) {
                                uVar12 = uVar12 + 1;
                                *(undefined8 *)(puVar5 + 0xe) = *puVar8;
                            }
                            break;
                        case 4:
                            uVar7 = *(uint32_t *)((int64_t)&arg_40h + iVar4);
                            if (*(int64_t *)(puVar5 + 0x10) == 0) {
                                uVar11 = uVar11 + 1;
                                *(undefined8 *)(puVar5 + 0x10) = *puVar8;
                            }
                            break;
                        case 5:
                            uVar7 = *(uint32_t *)((int64_t)&arg_40h + iVar4);
                            if (*(int64_t *)(puVar5 + 0x12) == 0) {
                                uVar11 = uVar11 + 1;
                                *(undefined8 *)(puVar5 + 0x12) = *puVar8;
                            }
                            break;
                        case 6:
                            uVar7 = *(uint32_t *)((int64_t)&arg_40h + iVar4);
                            if (*(int64_t *)(puVar5 + 0x14) == 0) {
                                iVar9 = iVar9 + 1;
                                *(undefined8 *)(puVar5 + 0x14) = *puVar8;
                            }
                            break;
                        case 7:
                            uVar7 = *(uint32_t *)((int64_t)&arg_40h + iVar4);
                            if (*(int64_t *)(puVar5 + 0x16) == 0) {
                                *(undefined8 *)(puVar5 + 0x16) = *puVar8;
                            }
                            break;
                        case 8:
                            uVar7 = *(uint32_t *)((int64_t)&arg_40h + iVar4);
                            if (*(int64_t *)(puVar5 + 0x18) == 0) {
                                uVar7 = uVar7 + 1;
                                *(undefined8 *)(puVar5 + 0x18) = *puVar8;
                                *(uint32_t *)((int64_t)&arg_40h + iVar4) = uVar7;
                            }
                            break;
                        case 9:
                            uVar7 = *(uint32_t *)((int64_t)&arg_40h + iVar4);
                            if (*(int64_t *)(puVar5 + 0x1a) == 0) {
                                uVar7 = uVar7 + 1;
                                *(undefined8 *)(puVar5 + 0x1a) = *puVar8;
                                *(uint32_t *)((int64_t)&arg_40h + iVar4) = uVar7;
                            }
                            break;
                        case 10:
                            uVar7 = *(uint32_t *)((int64_t)&arg_40h + iVar4);
                            if (*(int64_t *)(puVar5 + 0x1c) == 0) {
                                iVar10 = iVar10 + 1;
                                *(undefined8 *)(puVar5 + 0x1c) = *puVar8;
                            }
                            break;
                        case 0xb:
                            uVar7 = *(uint32_t *)((int64_t)&arg_40h + iVar4);
                            if (*(int64_t *)(puVar5 + 0x1e) == 0) {
                                iVar10 = iVar10 + 1;
                                *(undefined8 *)(puVar5 + 0x1e) = *puVar8;
                            }
                            break;
                        default:
                            uVar7 = *(uint32_t *)((int64_t)&arg_40h + iVar4);
                        }
                        iVar3 = *(int32_t *)(puVar8 + 1);
                        puVar8 = puVar8 + 2;
                    } while (iVar3 != 0);
                    *(int32_t *)((int64_t)&arg_50h + iVar4) = iVar10;
                    if ((((iVar9 == 2) && ((uVar12 & 0xfffffffd) == 0)) && ((uVar11 & 0xfffffffd) == 0)) &&
                       (((uVar12 == 2 || (uVar11 == 2)) &&
                        (((uVar7 & 0xfffffffd) == 0 && ((*(uint32_t *)((int64_t)&arg_50h + iVar4) & 0xfffffffd) == 0))))
                       )) {
                        return puVar5;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1802655ff;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180265617;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar4));
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180265629;
                fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar4));
            }
            LOCK();
            piVar1 = puVar5 + 8;
            iVar9 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (1 < iVar9) {
                return (undefined4 *)0x0;
            }
            uVar2 = *(undefined8 *)(puVar5 + 2);
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18026564e;
            fcn.180224990(uVar2, 0x1804e6e50, 0x1ef);
            uVar2 = *(undefined8 *)(puVar5 + 6);
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180265657;
            fcn.18027edb0(uVar2);
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18026566c;
            fcn.180224990(puVar5, 0x1804e6e50, 0x1f2);
            return (undefined4 *)0x0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180265683;
        fcn.180224990(puVar5, 0x1804e6e50, 0x169);
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180265688;
    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1802656a0;
    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), 
                  *(int64_t *)((int64_t)aiStackX_18 + iVar4));
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1802656b2;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar4));
    return (undefined4 *)0x0;
}

// ============================================================
// Function: FUN_180265700
// Address: 0x180265700
// Size: 1476 bytes
// ============================================================
int32_t fcn.180265050(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_50h, int64_t arg_58h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    code *pcVar9;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    int64_t iVar10;
    int32_t iVar11;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int32_t iVar12;
    undefined8 unaff_R15;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026505a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar12 = 0x400;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = 0;
    *(undefined4 *)((int64_t)&arg_38h + iVar3) = 0x400;
    *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_RBX;
    *(undefined8 *)(&stack0x00000018 + iVar3) = unaff_RBP;
    *(undefined8 *)(&stack0x00000010 + iVar3) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar3) = unaff_RDI;
    *(undefined8 *)(&stack0x00000000 + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180265719;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar6 = 0;
    iVar11 = 0;
    iVar2 = 0;
    *(undefined8 *)((int64_t)&arg_90h + iVar4 + iVar3) = 0;
    if (in_RCX == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x18026573a;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265752;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265764;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3));
        return -2;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar4 + iVar3) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_50h + iVar4 + iVar3) = unaff_R13;
    *(undefined8 *)((int64_t)&arg_48h + iVar4 + iVar3) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265788;
    fcn.180259930();
    *in_RCX = iVar12;
    *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x18026578f;
    fcn.180229b10();
    iVar5 = *(int64_t *)(in_RCX + 8);
    if (iVar5 == 0) {
code_r0x000180265950:
        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265955;
        fcn.1802299d0(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265962;
        fcn.180257a00(*(undefined8 *)((int64_t)&arg_90h + iVar4 + iVar3));
        iVar6 = *(int64_t *)(in_RCX + 0x1e);
        *(undefined8 *)((int64_t)&arg_90h + iVar4 + iVar3) = 0;
        if ((iVar6 == 0) || (*(int64_t *)(iVar6 + 0x98) == 0)) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265c7b;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3));
            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265c93;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3));
            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265ca5;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3));
            return -2;
        }
        if (*in_RCX == 0x200) {
            pcVar9 = *(code **)(iVar6 + 0x90);
        } else {
            if (*in_RCX != 0x400) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x1802659a3;
                fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3));
                *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x1802659bb;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3));
                *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x1802659cd;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3));
                iVar2 = -1;
                goto code_r0x000180265c57;
            }
            pcVar9 = *(code **)(iVar6 + 0xa0);
        }
        if (pcVar9 == (code *)0x0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265c51;
        iVar2 = (*pcVar9)(in_RCX);
        if (0 < iVar2) goto code_r0x000180265c65;
    } else if (*(int64_t *)(in_RCX + 0x22) == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x1802657ad;
        fcn.180229900();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x1802657b2;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x1802657ca;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x1802657dc;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3));
        iVar2 = iVar11;
    } else {
        iVar7 = *(int64_t *)(*(int64_t *)(in_RCX + 0x22) + 0x60);
        if ((iVar7 == 0) || (iVar7 == iVar5)) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265832;
            iVar5 = fcn.18029f2b0(iVar5, 0xd);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x18026583f;
                fcn.180229900();
                *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265844;
                fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3));
                *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x18026585c;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3));
                *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x18026586e;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3));
                iVar2 = iVar11;
            } else {
                iVar12 = 1;
                iVar5 = 0;
                do {
                    if (iVar5 != 0) goto code_r0x000180265adf;
                    if (iVar6 != 0) {
                        LOCK();
                        piVar1 = (int32_t *)(iVar6 + 0x20);
                        iVar11 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar11 < 2) {
                            uVar8 = *(undefined8 *)(iVar6 + 8);
                            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x1802658b6;
                            fcn.180224990(uVar8, 0x1804e6e50, 0x1ef);
                            uVar8 = *(undefined8 *)(iVar6 + 0x18);
                            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x1802658bf;
                            fcn.18027edb0(uVar8);
                            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x1802658d4;
                            fcn.180224990(iVar6, 0x1804e6e50, 0x1f2);
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x1802658e1;
                    fcn.180257a00(*(undefined8 *)((int64_t)&arg_90h + iVar4 + iVar3));
                    if (iVar12 == 1) {
                        *(code **)((int64_t)&arg_30h + iVar4 + iVar3) = fcn.180265350;
                        *(undefined8 *)((int64_t)&arg_28h + iVar4 + iVar3) = 0x180248230;
                        *(code **)((int64_t)&var_20h + iVar4 + iVar3) = fcn.1802653b0;
                        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265a10;
                        iVar6 = fcn.180280c20(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                              *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3), 
                                              *(int64_t *)(&stack0x000000b0 + iVar4 + iVar3), 
                                              *(int64_t *)(&stack0x000000b8 + iVar4 + iVar3), 
                                              *(int64_t *)(&stack0x000000c0 + iVar4 + iVar3));
                        if (iVar6 != 0) goto code_r0x000180265a1c;
                    } else {
                        if (iVar12 == 2) {
                            uVar8 = *(undefined8 *)(in_RCX + 8);
                            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265909;
                            fcn.1801dd170(uVar8);
                            *(code **)((int64_t)&arg_30h + iVar4 + iVar3) = fcn.180265350;
                            *(undefined8 *)((int64_t)&arg_28h + iVar4 + iVar3) = 0x180248230;
                            *(code **)((int64_t)&var_20h + iVar4 + iVar3) = fcn.1802653b0;
                            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265944;
                            iVar6 = fcn.180280ca0(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                  *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3), 
                                                  *(int64_t *)(&stack0x00000080 + iVar4 + iVar3), 
                                                  *(int64_t *)(&stack0x000000b0 + iVar4 + iVar3), 
                                                  *(int64_t *)(&stack0x000000b8 + iVar4 + iVar3), 
                                                  *(int64_t *)(&stack0x000000c0 + iVar4 + iVar3));
                            if (iVar6 == 0) goto code_r0x000180265950;
                        } else if (iVar6 == 0) goto code_r0x000180265a78;
code_r0x000180265a1c:
                        uVar8 = *(undefined8 *)(in_RCX + 8);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265a29;
                        fcn.1801dd6c0(uVar8);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265a37;
                        iVar7 = fcn.180257b60(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3));
                        *(int64_t *)((int64_t)&arg_90h + iVar4 + iVar3) = iVar7;
                        if (iVar7 != 0) {
                            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265a63;
                            iVar5 = fcn.180230ea0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                                                  *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                                                  *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                                                  *(int64_t *)(&stack0x000000a8 + iVar4 + iVar3));
                        }
                        if (*(int64_t *)((int64_t)&arg_90h + iVar4 + iVar3) == 0) {
                            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265a78;
                            fcn.180257a00(iVar7);
                        }
                    }
code_r0x000180265a78:
                    iVar12 = iVar12 + 1;
                } while (iVar12 < 3);
                if (iVar5 == 0) {
                    if (iVar6 != 0) {
                        LOCK();
                        piVar1 = (int32_t *)(iVar6 + 0x20);
                        iVar2 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar2 < 2) {
                            uVar8 = *(undefined8 *)(iVar6 + 8);
                            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265abc;
                            fcn.180224990(uVar8, 0x1804e6e50, 0x1ef);
                            uVar8 = *(undefined8 *)(iVar6 + 0x18);
                            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265ac5;
                            fcn.18027edb0(uVar8);
                            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265ada;
                            fcn.180224990(iVar6, 0x1804e6e50, 0x1f2);
                        }
                    }
                    goto code_r0x000180265950;
                }
code_r0x000180265adf:
                *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265ae4;
                fcn.1802299d0(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3));
                *(int64_t *)(in_RCX + 10) = iVar6;
                uVar8 = *(undefined8 *)(iVar6 + 0x18);
                pcVar9 = *(code **)(iVar6 + 0x28);
                *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265af5;
                uVar8 = fcn.18027e810(uVar8);
                *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265afa;
                iVar7 = (*pcVar9)(uVar8);
                *(int64_t *)(in_RCX + 0xc) = iVar7;
                if (iVar7 == 0) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265b0b;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265b23;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265b35;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3));
                } else {
                    iVar10 = 0x1805aadb1;
                    if (*(int64_t *)(iVar6 + 0x10) != 0) {
                        iVar10 = *(int64_t *)(iVar6 + 0x10);
                    }
                    iVar12 = *(int32_t *)((int64_t)&arg_98h + iVar4 + iVar3);
                    if (iVar12 == 0x200) {
                        pcVar9 = *(code **)(iVar6 + 0x30);
                        if (pcVar9 == (code *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265bd2;
                            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3));
                            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265bea;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3));
                            goto code_r0x000180265bf1;
                        }
code_r0x000180265c10:
                        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265c1d;
                        iVar2 = (*pcVar9)(iVar7, iVar5, *(undefined8 *)((int64_t)&arg_a0h + iVar4 + iVar3));
                        if (0 < iVar2) {
                            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265c30;
                            fcn.180257a00(*(undefined8 *)((int64_t)&arg_90h + iVar4 + iVar3));
                            return 1;
                        }
                    } else if (iVar12 == 0x400) {
                        pcVar9 = *(code **)(iVar6 + 0x40);
                        if (pcVar9 != (code *)0x0) goto code_r0x000180265c10;
                        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265ba3;
                        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265bbb;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3));
code_r0x000180265bf1:
                        *(int64_t *)((int64_t)&var_20h + iVar4 + iVar3) = iVar10;
                        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265c09;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3));
                        iVar2 = -2;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265b66;
                        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265b7e;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265b90;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3));
                    }
                }
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x1802657f4;
            fcn.180229900();
            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x1802657f9;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3));
            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265811;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3));
            *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265823;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3));
            iVar2 = iVar11;
        }
    }
code_r0x000180265c57:
    *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265c5f;
    fcn.180259930(in_RCX);
    *in_RCX = 0;
code_r0x000180265c65:
    *(undefined8 *)((int64_t)&uStack_8 + iVar4 + iVar3) = 0x180265c72;
    fcn.180257a00(*(undefined8 *)((int64_t)&arg_90h + iVar4 + iVar3));
    return iVar2;
}

// ============================================================
// Function: FUN_180265d70
// Address: 0x180265d70
// Size: 133 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180265d70(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    uint64_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    uint64_t *in_RDX;
    uint64_t uVar5;
    undefined8 *puVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180265d90;
    iVar4 = fcn.18045a350();
    uVar2 = *(uint64_t *)0x18077e758;
    if ((in_RCX != 0) && (uVar5 = 0, puVar6 = *(undefined8 **)0x18077e750, *(uint64_t *)0x18077e758 != 0)) {
        do {
            uVar1 = *puVar6;
            *(undefined8 *)((int64_t)&uStack_10 - iVar4) = 0x180265dbe;
            iVar3 = func_0x000180498f10(uVar1, in_RCX);
            if (iVar3 == 0) {
                *in_RDX = uVar5;
                return 1;
            }
            uVar5 = uVar5 + 1;
            puVar6 = puVar6 + 3;
        } while (uVar5 < uVar2);
    }
    return 0;
}

// ============================================================
// Function: FUN_180265e00
// Address: 0x180265e00
// Size: 43 bytes
// ============================================================
bool fcn.180265e00(void)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uStackX_20;
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2) = 0x18024a43a;
    iVar1 = fcn.18045a350(0x1804e6f40, 0x180265f70, 0x180265e30);
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar1 + iVar2) = 0x18024a44d;
    iVar1 = fcn.18024ab80(*(int64_t *)(&stack0x00000058 + iVar1 + iVar2), *(int64_t *)(&stack0x00000060 + iVar1 + iVar2)
                          , *(int64_t *)(&stack0x00000068 + iVar1 + iVar2));
    return iVar1 != 0;
}

// ============================================================
// Function: FUN_180265e30
// Address: 0x180265e30
// Size: 29 bytes
// ============================================================
void fcn.180265e30(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_80h,
                  int64_t arg_88h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar4;
    undefined8 unaff_RSI;
    uint64_t uVar5;
    undefined8 unaff_RDI;
    int64_t iVar6;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iVar7;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180265e3a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int64_t *)0x18077e750 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RBP;
        uVar4 = 0;
        if (*(uint64_t *)0x18077e758 != 0) {
            *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_R14;
            *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_R15;
            iVar7 = 0;
            do {
                puVar1 = (undefined8 *)(iVar7 + *(int64_t *)0x18077e750);
                uVar2 = *puVar1;
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180265e99;
                fcn.180224990(uVar2, 0x1804e6f08, 0x31);
                uVar5 = 0;
                if (puVar1[2] != 0) {
                    iVar6 = 0;
                    do {
                        uVar2 = *(undefined8 *)(iVar6 + puVar1[1]);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180265ebd;
                        fcn.180224990(uVar2, 0x1804e6f08, 0x33);
                        uVar2 = *(undefined8 *)(iVar6 + 8 + puVar1[1]);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180265ed8;
                        fcn.180224990(uVar2, 0x1804e6f08, 0x34);
                        uVar5 = uVar5 + 1;
                        iVar6 = iVar6 + 0x10;
                    } while (uVar5 < (uint64_t)puVar1[2]);
                }
                uVar2 = puVar1[1];
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180265efb;
                fcn.180224990(uVar2, 0x1804e6f08, 0x36);
                uVar4 = uVar4 + 1;
                iVar7 = iVar7 + 0x18;
            } while (uVar4 < *(uint64_t *)0x18077e758);
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180265f41;
        fcn.180224990(*(int64_t *)0x18077e750, 0x1804e6f08, 0x38);
        *(int64_t *)0x18077e750 = 0;
        *(uint64_t *)0x18077e758 = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180265e4d
// Address: 0x180265e4d
// Size: 20 bytes
// ============================================================
void fcn.180265e30(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_80h,
                  int64_t arg_88h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar4;
    undefined8 unaff_RSI;
    uint64_t uVar5;
    undefined8 unaff_RDI;
    int64_t iVar6;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iVar7;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180265e3a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int64_t *)0x18077e750 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RBP;
        uVar4 = 0;
        if (*(uint64_t *)0x18077e758 != 0) {
            *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_R14;
            *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_R15;
            iVar7 = 0;
            do {
                puVar1 = (undefined8 *)(iVar7 + *(int64_t *)0x18077e750);
                uVar2 = *puVar1;
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180265e99;
                fcn.180224990(uVar2, 0x1804e6f08, 0x31);
                uVar5 = 0;
                if (puVar1[2] != 0) {
                    iVar6 = 0;
                    do {
                        uVar2 = *(undefined8 *)(iVar6 + puVar1[1]);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180265ebd;
                        fcn.180224990(uVar2, 0x1804e6f08, 0x33);
                        uVar2 = *(undefined8 *)(iVar6 + 8 + puVar1[1]);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180265ed8;
                        fcn.180224990(uVar2, 0x1804e6f08, 0x34);
                        uVar5 = uVar5 + 1;
                        iVar6 = iVar6 + 0x10;
                    } while (uVar5 < (uint64_t)puVar1[2]);
                }
                uVar2 = puVar1[1];
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180265efb;
                fcn.180224990(uVar2, 0x1804e6f08, 0x36);
                uVar4 = uVar4 + 1;
                iVar7 = iVar7 + 0x18;
            } while (uVar4 < *(uint64_t *)0x18077e758);
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180265f41;
        fcn.180224990(*(int64_t *)0x18077e750, 0x1804e6f08, 0x38);
        *(int64_t *)0x18077e750 = 0;
        *(uint64_t *)0x18077e758 = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180265e61
// Address: 0x180265e61
// Size: 206 bytes
// ============================================================
void fcn.180265e30(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_80h,
                  int64_t arg_88h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar4;
    undefined8 unaff_RSI;
    uint64_t uVar5;
    undefined8 unaff_RDI;
    int64_t iVar6;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iVar7;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180265e3a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int64_t *)0x18077e750 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RBP;
        uVar4 = 0;
        if (*(uint64_t *)0x18077e758 != 0) {
            *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_R14;
            *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_R15;
            iVar7 = 0;
            do {
                puVar1 = (undefined8 *)(iVar7 + *(int64_t *)0x18077e750);
                uVar2 = *puVar1;
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180265e99;
                fcn.180224990(uVar2, 0x1804e6f08, 0x31);
                uVar5 = 0;
                if (puVar1[2] != 0) {
                    iVar6 = 0;
                    do {
                        uVar2 = *(undefined8 *)(iVar6 + puVar1[1]);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180265ebd;
                        fcn.180224990(uVar2, 0x1804e6f08, 0x33);
                        uVar2 = *(undefined8 *)(iVar6 + 8 + puVar1[1]);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180265ed8;
                        fcn.180224990(uVar2, 0x1804e6f08, 0x34);
                        uVar5 = uVar5 + 1;
                        iVar6 = iVar6 + 0x10;
                    } while (uVar5 < (uint64_t)puVar1[2]);
                }
                uVar2 = puVar1[1];
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180265efb;
                fcn.180224990(uVar2, 0x1804e6f08, 0x36);
                uVar4 = uVar4 + 1;
                iVar7 = iVar7 + 0x18;
            } while (uVar4 < *(uint64_t *)0x18077e758);
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180265f41;
        fcn.180224990(*(int64_t *)0x18077e750, 0x1804e6f08, 0x38);
        *(int64_t *)0x18077e750 = 0;
        *(uint64_t *)0x18077e758 = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180265f2f
// Address: 0x180265f2f
// Size: 45 bytes
// ============================================================
void fcn.180265e30(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_80h,
                  int64_t arg_88h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar4;
    undefined8 unaff_RSI;
    uint64_t uVar5;
    undefined8 unaff_RDI;
    int64_t iVar6;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iVar7;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180265e3a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int64_t *)0x18077e750 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RBP;
        uVar4 = 0;
        if (*(uint64_t *)0x18077e758 != 0) {
            *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_R14;
            *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_R15;
            iVar7 = 0;
            do {
                puVar1 = (undefined8 *)(iVar7 + *(int64_t *)0x18077e750);
                uVar2 = *puVar1;
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180265e99;
                fcn.180224990(uVar2, 0x1804e6f08, 0x31);
                uVar5 = 0;
                if (puVar1[2] != 0) {
                    iVar6 = 0;
                    do {
                        uVar2 = *(undefined8 *)(iVar6 + puVar1[1]);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180265ebd;
                        fcn.180224990(uVar2, 0x1804e6f08, 0x33);
                        uVar2 = *(undefined8 *)(iVar6 + 8 + puVar1[1]);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180265ed8;
                        fcn.180224990(uVar2, 0x1804e6f08, 0x34);
                        uVar5 = uVar5 + 1;
                        iVar6 = iVar6 + 0x10;
                    } while (uVar5 < (uint64_t)puVar1[2]);
                }
                uVar2 = puVar1[1];
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180265efb;
                fcn.180224990(uVar2, 0x1804e6f08, 0x36);
                uVar4 = uVar4 + 1;
                iVar7 = iVar7 + 0x18;
            } while (uVar4 < *(uint64_t *)0x18077e758);
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180265f41;
        fcn.180224990(*(int64_t *)0x18077e750, 0x1804e6f08, 0x38);
        *(int64_t *)0x18077e750 = 0;
        *(uint64_t *)0x18077e758 = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180265f5c
// Address: 0x180265f5c
// Size: 5 bytes
// ============================================================
void fcn.180265e30(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_80h,
                  int64_t arg_88h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar4;
    undefined8 unaff_RSI;
    uint64_t uVar5;
    undefined8 unaff_RDI;
    int64_t iVar6;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iVar7;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180265e3a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int64_t *)0x18077e750 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RBP;
        uVar4 = 0;
        if (*(uint64_t *)0x18077e758 != 0) {
            *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_R14;
            *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_R15;
            iVar7 = 0;
            do {
                puVar1 = (undefined8 *)(iVar7 + *(int64_t *)0x18077e750);
                uVar2 = *puVar1;
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180265e99;
                fcn.180224990(uVar2, 0x1804e6f08, 0x31);
                uVar5 = 0;
                if (puVar1[2] != 0) {
                    iVar6 = 0;
                    do {
                        uVar2 = *(undefined8 *)(iVar6 + puVar1[1]);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180265ebd;
                        fcn.180224990(uVar2, 0x1804e6f08, 0x33);
                        uVar2 = *(undefined8 *)(iVar6 + 8 + puVar1[1]);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180265ed8;
                        fcn.180224990(uVar2, 0x1804e6f08, 0x34);
                        uVar5 = uVar5 + 1;
                        iVar6 = iVar6 + 0x10;
                    } while (uVar5 < (uint64_t)puVar1[2]);
                }
                uVar2 = puVar1[1];
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180265efb;
                fcn.180224990(uVar2, 0x1804e6f08, 0x36);
                uVar4 = uVar4 + 1;
                iVar7 = iVar7 + 0x18;
            } while (uVar4 < *(uint64_t *)0x18077e758);
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180265f41;
        fcn.180224990(*(int64_t *)0x18077e750, 0x1804e6f08, 0x38);
        *(int64_t *)0x18077e750 = 0;
        *(uint64_t *)0x18077e758 = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180265f70
// Address: 0x180265f70
// Size: 697 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180265f70(int64_t arg1, int64_t arg2, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_48;
    int64_t var_20h;
    
    uStack_48 = 0x180265f90;
    var_8h = arg1;
    var_10h = arg2;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x180265f9b;
    fcn.1801dd6c0();
    *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x180265fa9;
    uVar5 = fcn.18028cae0(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4));
    *(undefined8 *)((int64_t)&arg_58h + iVar4) = uVar5;
    *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x180265fbc;
    iVar3 = fcn.180222010(uVar5);
    if (iVar3 < 1) {
        *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x180265fc5;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0xffffffffffffffe8 + iVar4));
        *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x180265fdd;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0xffffffffffffffe8 + iVar4), 
                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                      *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x180265ff9;
        fcn.1802296d0(*(int64_t *)(&stack0x00000000 + iVar4));
    } else {
        *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x180266021;
        iVar3 = fcn.180222010(uVar5);
        uVar9 = (uint64_t)iVar3;
        *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x180266031;
        fcn.180265e30(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0xffffffffffffffe8 + iVar4), 
                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                      *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4));
        *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x18026604b;
        *(int64_t *)0x18077e750 = fcn.180224e40(*(int64_t *)((int64_t)&var_20h + iVar4));
        if (*(int64_t *)0x18077e750 != 0) {
            uVar11 = 0;
            *(uint64_t *)0x18077e758 = uVar9;
            if (uVar9 != 0) {
                iVar6 = 0;
                *(undefined8 *)((int64_t)&arg_50h + iVar4) = 0;
                do {
                    piVar1 = (int64_t *)(iVar6 + *(int64_t *)0x18077e750);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x18026608f;
                    iVar6 = fcn.180222340(uVar5, uVar11 & 0xffffffff);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x18026609e;
                    uVar7 = fcn.18028cae0(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4)
                                         );
                    *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x1802660a9;
                    iVar3 = fcn.180222010(uVar7);
                    if (iVar3 < 1) {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x1802661dc;
                        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0xffffffffffffffe8 + iVar4));
                        *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x1802661f4;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0xffffffffffffffe8 + iVar4), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                      *(int64_t *)((int64_t)&var_10h + iVar4));
                        *(undefined8 *)((int64_t)&var_20h + iVar4) = *(undefined8 *)(iVar6 + 0x10);
                        *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x18026621a;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000000 + iVar4));
                        goto code_r0x000180265ff9;
                    }
                    *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x1802660c7;
                    iVar6 = fcn.1802231e0(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)(&stack0xffffffffffffffe8 + iVar4), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
                    *piVar1 = iVar6;
                    if (iVar6 == 0) goto code_r0x000180265ff9;
                    *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x1802660db;
                    iVar3 = fcn.180222010(uVar7);
                    uVar9 = (uint64_t)iVar3;
                    *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x1802660f8;
                    iVar6 = fcn.180224e40(*(int64_t *)((int64_t)&var_20h + iVar4));
                    piVar1[1] = iVar6;
                    if (iVar6 == 0) goto code_r0x000180265ff9;
                    uVar10 = 0;
                    piVar1[2] = uVar9;
                    if (uVar9 != 0) {
                        iVar6 = 0;
                        do {
                            *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x180266120;
                            iVar8 = fcn.180222340(uVar7, uVar10 & 0xffffffff);
                            iVar2 = piVar1[1];
                            uVar5 = *(undefined8 *)(iVar8 + 8);
                            *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x180266135;
                            fcn.18045b928(uVar5, 0x2e);
                            *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x180266158;
                            uVar5 = fcn.1802231e0(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar4), 
                                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
                            *(undefined8 *)(iVar2 + iVar6) = uVar5;
                            *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x180266172;
                            iVar8 = fcn.1802231e0(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar4), 
                                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
                            *(int64_t *)(iVar2 + 8 + iVar6) = iVar8;
                            if ((*(int64_t *)(iVar2 + iVar6) == 0) || (iVar8 == 0)) goto code_r0x000180265ff9;
                            uVar10 = uVar10 + 1;
                            iVar6 = iVar6 + 0x10;
                        } while (uVar10 < uVar9);
                        uVar5 = *(undefined8 *)((int64_t)&arg_58h + iVar4);
                    }
                    uVar11 = uVar11 + 1;
                    iVar6 = *(int64_t *)((int64_t)&arg_50h + iVar4) + 0x18;
                    *(int64_t *)((int64_t)&arg_50h + iVar4) = iVar6;
                } while (uVar11 < *(uint64_t *)0x18077e758);
            }
            return 1;
        }
    }
code_r0x000180265ff9:
    *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x180266006;
    fcn.180265e30(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0xffffffffffffffe8 + iVar4), 
                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                  *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                  *(int64_t *)((int64_t)&arg_40h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_180266230
// Address: 0x180266230
// Size: 86 bytes
// ============================================================
undefined8 fcn.180266230(int64_t *param_1)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026623a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*(code **)(*param_1 + 0x48) == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18026624e;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180266266;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180266278;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    // WARNING: Could not recover jumptable at 0x000180266283. Too many branches
    // WARNING: Treating indirect jump as call
    uVar2 = (**(code **)(*param_1 + 0x48))();
    return uVar2;
}

// ============================================================
// Function: FUN_180266290
// Address: 0x180266290
// Size: 135 bytes
// ============================================================
int64_t fcn.180266290(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    uint8_t *puVar1;
    code *pcVar2;
    int64_t iVar3;
    uint8_t **ppuVar4;
    uint8_t **ppuVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    undefined8 uVar9;
    undefined8 uVar10;
    int64_t iVar11;
    uint8_t **in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBP;
    int64_t iVar12;
    int64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_30;
    
    uStack_30 = 0x1802662a2;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar12 = 0;
    if ((*(int32_t *)(*in_RCX + 4) != *(int32_t *)(*in_RDX + 4)) ||
       (((*(int32_t *)(in_RCX + 4) != 0 && (*(int32_t *)(in_RDX + 4) != 0)) &&
        (*(int32_t *)(in_RCX + 4) != *(int32_t *)(in_RDX + 4))))) {
        return 1;
    }
    if ((**in_RCX & 2) != 0) {
        return 0;
    }
    iVar13 = iVar12;
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802662fb;
        in_R8 = func_0x0001802d4730();
        iVar13 = in_R8;
        if (in_R8 == 0) {
            return 0xffffffff;
        }
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + -8) = unaff_R12;
    *(undefined8 *)((int64_t)&var_8h + iVar7) = unaff_R13;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266331;
    func_0x0001802d48b0(in_R8);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266339;
    uVar8 = func_0x0001802d4590(in_R8);
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = uVar8;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266346;
    uVar8 = func_0x0001802d4590(in_R8);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266351;
    uVar9 = func_0x0001802d4590(in_R8);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18026635c;
    uVar10 = func_0x0001802d4590(in_R8);
    *(undefined8 *)((int64_t)&arg_48h + iVar7) = uVar10;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266369;
    uVar10 = func_0x0001802d4590(in_R8);
    *(undefined8 *)((int64_t)&arg_60h + iVar7) = uVar10;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266379;
    iVar11 = func_0x0001802d4590(in_R8);
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266389;
        func_0x0001802d4450(in_R8);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266391;
        func_0x0001802d44d0(iVar13);
        return 0xffffffff;
    }
    puVar1 = *in_RCX;
    *(int64_t *)(&stack0xfffffffffffffff8 + iVar7) = in_R8;
    pcVar2 = *(code **)(puVar1 + 0x30);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802663d1;
    iVar6 = (*pcVar2)(in_RCX, *(undefined8 *)((int64_t)&arg_50h + iVar7), uVar8, uVar9);
    if (iVar6 != 0) {
        iVar3 = *in_RDX;
        *(int64_t *)(&stack0xfffffffffffffff8 + iVar7) = in_R8;
        pcVar2 = *(code **)(iVar3 + 0x30);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802663fb;
        iVar6 = (*pcVar2)(in_RDX, *(undefined8 *)((int64_t)&arg_48h + iVar7), *(undefined8 *)((int64_t)&arg_60h + iVar7)
                          , iVar11);
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266412;
            iVar6 = func_0x000180254f10(*(undefined8 *)((int64_t)&arg_50h + iVar7), 
                                        *(undefined8 *)((int64_t)&arg_48h + iVar7));
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18026642a;
                iVar6 = func_0x000180254f10(uVar8, *(undefined8 *)((int64_t)&arg_60h + iVar7));
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18026643d;
                    iVar6 = func_0x000180254f10(uVar9, iVar11);
                    if (iVar6 == 0) {
                        puVar1 = *in_RCX;
                        ppuVar4 = (uint8_t **)in_RDX[1];
                        ppuVar5 = (uint8_t **)in_RCX[1];
                        if (*(int64_t *)(puVar1 + 200) == 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18026645e;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -0x18));
                            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266476;
                            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -0x18), 
                                          *(int64_t *)((int64_t)&var_8h + iVar7), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -8), 
                                          *(int64_t *)(&stack0x00000028 + iVar7));
                        } else {
                            if (((puVar1 == *ppuVar5) &&
                                ((((iVar6 = *(int32_t *)(in_RCX + 4), iVar6 == 0 || (*(int32_t *)(ppuVar5 + 1) == 0)) ||
                                  (iVar6 == *(int32_t *)(ppuVar5 + 1))) && (puVar1 == *ppuVar4)))) &&
                               (((iVar6 == 0 || (*(int32_t *)(ppuVar4 + 1) == 0)) ||
                                (iVar6 == *(int32_t *)(ppuVar4 + 1))))) {
                                pcVar2 = *(code **)(*in_RCX + 200);
                                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802664ca;
                                iVar6 = (*pcVar2)(in_RCX, ppuVar5, ppuVar4, in_R8);
                                if (iVar6 == 0) {
                                    if ((in_RCX[2] == (uint8_t *)0x0) || (in_RDX[2] == 0)) {
                                        iVar12 = 0xffffffff;
                                        goto code_r0x000180266559;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802664e9;
                                    iVar6 = func_0x000180254f10();
                                    if (iVar6 == 0) {
                                        puVar1 = in_RCX[3];
                                        iVar11 = in_RDX[3];
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802664fd;
                                        iVar6 = func_0x0001802553f0(puVar1);
                                        if (iVar6 != 0) goto code_r0x000180266559;
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266509;
                                        iVar6 = func_0x0001802553f0(iVar11);
                                        if (iVar6 != 0) goto code_r0x000180266559;
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266518;
                                        iVar6 = func_0x000180254f10(puVar1, iVar11);
                                        if (iVar6 == 0) goto code_r0x000180266559;
                                    }
                                }
                                goto code_r0x000180266554;
                            }
                            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18026652a;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -0x18));
                            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266542;
                            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -0x18), 
                                          *(int64_t *)((int64_t)&var_8h + iVar7), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -8), 
                                          *(int64_t *)(&stack0x00000028 + iVar7));
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266554;
                        fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_18 + iVar7));
                    }
                }
            }
        }
    }
code_r0x000180266554:
    iVar12 = 1;
code_r0x000180266559:
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266561;
    func_0x0001802d4450(in_R8);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266569;
    func_0x0001802d44d0(iVar13);
    return iVar12;
}

// ============================================================
// Function: FUN_180266317
// Address: 0x180266317
// Size: 157 bytes
// ============================================================
int64_t fcn.180266290(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    uint8_t *puVar1;
    code *pcVar2;
    int64_t iVar3;
    uint8_t **ppuVar4;
    uint8_t **ppuVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    undefined8 uVar9;
    undefined8 uVar10;
    int64_t iVar11;
    uint8_t **in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBP;
    int64_t iVar12;
    int64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_30;
    
    uStack_30 = 0x1802662a2;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar12 = 0;
    if ((*(int32_t *)(*in_RCX + 4) != *(int32_t *)(*in_RDX + 4)) ||
       (((*(int32_t *)(in_RCX + 4) != 0 && (*(int32_t *)(in_RDX + 4) != 0)) &&
        (*(int32_t *)(in_RCX + 4) != *(int32_t *)(in_RDX + 4))))) {
        return 1;
    }
    if ((**in_RCX & 2) != 0) {
        return 0;
    }
    iVar13 = iVar12;
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802662fb;
        in_R8 = func_0x0001802d4730();
        iVar13 = in_R8;
        if (in_R8 == 0) {
            return 0xffffffff;
        }
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + -8) = unaff_R12;
    *(undefined8 *)((int64_t)&var_8h + iVar7) = unaff_R13;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266331;
    func_0x0001802d48b0(in_R8);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266339;
    uVar8 = func_0x0001802d4590(in_R8);
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = uVar8;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266346;
    uVar8 = func_0x0001802d4590(in_R8);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266351;
    uVar9 = func_0x0001802d4590(in_R8);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18026635c;
    uVar10 = func_0x0001802d4590(in_R8);
    *(undefined8 *)((int64_t)&arg_48h + iVar7) = uVar10;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266369;
    uVar10 = func_0x0001802d4590(in_R8);
    *(undefined8 *)((int64_t)&arg_60h + iVar7) = uVar10;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266379;
    iVar11 = func_0x0001802d4590(in_R8);
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266389;
        func_0x0001802d4450(in_R8);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266391;
        func_0x0001802d44d0(iVar13);
        return 0xffffffff;
    }
    puVar1 = *in_RCX;
    *(int64_t *)(&stack0xfffffffffffffff8 + iVar7) = in_R8;
    pcVar2 = *(code **)(puVar1 + 0x30);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802663d1;
    iVar6 = (*pcVar2)(in_RCX, *(undefined8 *)((int64_t)&arg_50h + iVar7), uVar8, uVar9);
    if (iVar6 != 0) {
        iVar3 = *in_RDX;
        *(int64_t *)(&stack0xfffffffffffffff8 + iVar7) = in_R8;
        pcVar2 = *(code **)(iVar3 + 0x30);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802663fb;
        iVar6 = (*pcVar2)(in_RDX, *(undefined8 *)((int64_t)&arg_48h + iVar7), *(undefined8 *)((int64_t)&arg_60h + iVar7)
                          , iVar11);
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266412;
            iVar6 = func_0x000180254f10(*(undefined8 *)((int64_t)&arg_50h + iVar7), 
                                        *(undefined8 *)((int64_t)&arg_48h + iVar7));
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18026642a;
                iVar6 = func_0x000180254f10(uVar8, *(undefined8 *)((int64_t)&arg_60h + iVar7));
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18026643d;
                    iVar6 = func_0x000180254f10(uVar9, iVar11);
                    if (iVar6 == 0) {
                        puVar1 = *in_RCX;
                        ppuVar4 = (uint8_t **)in_RDX[1];
                        ppuVar5 = (uint8_t **)in_RCX[1];
                        if (*(int64_t *)(puVar1 + 200) == 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18026645e;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -0x18));
                            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266476;
                            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -0x18), 
                                          *(int64_t *)((int64_t)&var_8h + iVar7), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -8), 
                                          *(int64_t *)(&stack0x00000028 + iVar7));
                        } else {
                            if (((puVar1 == *ppuVar5) &&
                                ((((iVar6 = *(int32_t *)(in_RCX + 4), iVar6 == 0 || (*(int32_t *)(ppuVar5 + 1) == 0)) ||
                                  (iVar6 == *(int32_t *)(ppuVar5 + 1))) && (puVar1 == *ppuVar4)))) &&
                               (((iVar6 == 0 || (*(int32_t *)(ppuVar4 + 1) == 0)) ||
                                (iVar6 == *(int32_t *)(ppuVar4 + 1))))) {
                                pcVar2 = *(code **)(*in_RCX + 200);
                                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802664ca;
                                iVar6 = (*pcVar2)(in_RCX, ppuVar5, ppuVar4, in_R8);
                                if (iVar6 == 0) {
                                    if ((in_RCX[2] == (uint8_t *)0x0) || (in_RDX[2] == 0)) {
                                        iVar12 = 0xffffffff;
                                        goto code_r0x000180266559;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802664e9;
                                    iVar6 = func_0x000180254f10();
                                    if (iVar6 == 0) {
                                        puVar1 = in_RCX[3];
                                        iVar11 = in_RDX[3];
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802664fd;
                                        iVar6 = func_0x0001802553f0(puVar1);
                                        if (iVar6 != 0) goto code_r0x000180266559;
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266509;
                                        iVar6 = func_0x0001802553f0(iVar11);
                                        if (iVar6 != 0) goto code_r0x000180266559;
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266518;
                                        iVar6 = func_0x000180254f10(puVar1, iVar11);
                                        if (iVar6 == 0) goto code_r0x000180266559;
                                    }
                                }
                                goto code_r0x000180266554;
                            }
                            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18026652a;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -0x18));
                            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266542;
                            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -0x18), 
                                          *(int64_t *)((int64_t)&var_8h + iVar7), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -8), 
                                          *(int64_t *)(&stack0x00000028 + iVar7));
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266554;
                        fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_18 + iVar7));
                    }
                }
            }
        }
    }
code_r0x000180266554:
    iVar12 = 1;
code_r0x000180266559:
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266561;
    func_0x0001802d4450(in_R8);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266569;
    func_0x0001802d44d0(iVar13);
    return iVar12;
}

// ============================================================
// Function: FUN_1802663b4
// Address: 0x1802663b4
// Size: 444 bytes
// ============================================================
int64_t fcn.180266290(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    uint8_t *puVar1;
    code *pcVar2;
    int64_t iVar3;
    uint8_t **ppuVar4;
    uint8_t **ppuVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    undefined8 uVar9;
    undefined8 uVar10;
    int64_t iVar11;
    uint8_t **in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBP;
    int64_t iVar12;
    int64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_30;
    
    uStack_30 = 0x1802662a2;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar12 = 0;
    if ((*(int32_t *)(*in_RCX + 4) != *(int32_t *)(*in_RDX + 4)) ||
       (((*(int32_t *)(in_RCX + 4) != 0 && (*(int32_t *)(in_RDX + 4) != 0)) &&
        (*(int32_t *)(in_RCX + 4) != *(int32_t *)(in_RDX + 4))))) {
        return 1;
    }
    if ((**in_RCX & 2) != 0) {
        return 0;
    }
    iVar13 = iVar12;
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802662fb;
        in_R8 = func_0x0001802d4730();
        iVar13 = in_R8;
        if (in_R8 == 0) {
            return 0xffffffff;
        }
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + -8) = unaff_R12;
    *(undefined8 *)((int64_t)&var_8h + iVar7) = unaff_R13;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266331;
    func_0x0001802d48b0(in_R8);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266339;
    uVar8 = func_0x0001802d4590(in_R8);
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = uVar8;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266346;
    uVar8 = func_0x0001802d4590(in_R8);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266351;
    uVar9 = func_0x0001802d4590(in_R8);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18026635c;
    uVar10 = func_0x0001802d4590(in_R8);
    *(undefined8 *)((int64_t)&arg_48h + iVar7) = uVar10;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266369;
    uVar10 = func_0x0001802d4590(in_R8);
    *(undefined8 *)((int64_t)&arg_60h + iVar7) = uVar10;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266379;
    iVar11 = func_0x0001802d4590(in_R8);
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266389;
        func_0x0001802d4450(in_R8);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266391;
        func_0x0001802d44d0(iVar13);
        return 0xffffffff;
    }
    puVar1 = *in_RCX;
    *(int64_t *)(&stack0xfffffffffffffff8 + iVar7) = in_R8;
    pcVar2 = *(code **)(puVar1 + 0x30);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802663d1;
    iVar6 = (*pcVar2)(in_RCX, *(undefined8 *)((int64_t)&arg_50h + iVar7), uVar8, uVar9);
    if (iVar6 != 0) {
        iVar3 = *in_RDX;
        *(int64_t *)(&stack0xfffffffffffffff8 + iVar7) = in_R8;
        pcVar2 = *(code **)(iVar3 + 0x30);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802663fb;
        iVar6 = (*pcVar2)(in_RDX, *(undefined8 *)((int64_t)&arg_48h + iVar7), *(undefined8 *)((int64_t)&arg_60h + iVar7)
                          , iVar11);
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266412;
            iVar6 = func_0x000180254f10(*(undefined8 *)((int64_t)&arg_50h + iVar7), 
                                        *(undefined8 *)((int64_t)&arg_48h + iVar7));
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18026642a;
                iVar6 = func_0x000180254f10(uVar8, *(undefined8 *)((int64_t)&arg_60h + iVar7));
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18026643d;
                    iVar6 = func_0x000180254f10(uVar9, iVar11);
                    if (iVar6 == 0) {
                        puVar1 = *in_RCX;
                        ppuVar4 = (uint8_t **)in_RDX[1];
                        ppuVar5 = (uint8_t **)in_RCX[1];
                        if (*(int64_t *)(puVar1 + 200) == 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18026645e;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -0x18));
                            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266476;
                            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -0x18), 
                                          *(int64_t *)((int64_t)&var_8h + iVar7), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -8), 
                                          *(int64_t *)(&stack0x00000028 + iVar7));
                        } else {
                            if (((puVar1 == *ppuVar5) &&
                                ((((iVar6 = *(int32_t *)(in_RCX + 4), iVar6 == 0 || (*(int32_t *)(ppuVar5 + 1) == 0)) ||
                                  (iVar6 == *(int32_t *)(ppuVar5 + 1))) && (puVar1 == *ppuVar4)))) &&
                               (((iVar6 == 0 || (*(int32_t *)(ppuVar4 + 1) == 0)) ||
                                (iVar6 == *(int32_t *)(ppuVar4 + 1))))) {
                                pcVar2 = *(code **)(*in_RCX + 200);
                                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802664ca;
                                iVar6 = (*pcVar2)(in_RCX, ppuVar5, ppuVar4, in_R8);
                                if (iVar6 == 0) {
                                    if ((in_RCX[2] == (uint8_t *)0x0) || (in_RDX[2] == 0)) {
                                        iVar12 = 0xffffffff;
                                        goto code_r0x000180266559;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802664e9;
                                    iVar6 = func_0x000180254f10();
                                    if (iVar6 == 0) {
                                        puVar1 = in_RCX[3];
                                        iVar11 = in_RDX[3];
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802664fd;
                                        iVar6 = func_0x0001802553f0(puVar1);
                                        if (iVar6 != 0) goto code_r0x000180266559;
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266509;
                                        iVar6 = func_0x0001802553f0(iVar11);
                                        if (iVar6 != 0) goto code_r0x000180266559;
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266518;
                                        iVar6 = func_0x000180254f10(puVar1, iVar11);
                                        if (iVar6 == 0) goto code_r0x000180266559;
                                    }
                                }
                                goto code_r0x000180266554;
                            }
                            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18026652a;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -0x18));
                            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266542;
                            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -0x18), 
                                          *(int64_t *)((int64_t)&var_8h + iVar7), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -8), 
                                          *(int64_t *)(&stack0x00000028 + iVar7));
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266554;
                        fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_18 + iVar7));
                    }
                }
            }
        }
    }
code_r0x000180266554:
    iVar12 = 1;
code_r0x000180266559:
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266561;
    func_0x0001802d4450(in_R8);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266569;
    func_0x0001802d44d0(iVar13);
    return iVar12;
}

// ============================================================
// Function: FUN_180266570
// Address: 0x180266570
// Size: 17 bytes
// ============================================================
int64_t fcn.180266290(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    uint8_t *puVar1;
    code *pcVar2;
    int64_t iVar3;
    uint8_t **ppuVar4;
    uint8_t **ppuVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    undefined8 uVar9;
    undefined8 uVar10;
    int64_t iVar11;
    uint8_t **in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBP;
    int64_t iVar12;
    int64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_30;
    
    uStack_30 = 0x1802662a2;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar12 = 0;
    if ((*(int32_t *)(*in_RCX + 4) != *(int32_t *)(*in_RDX + 4)) ||
       (((*(int32_t *)(in_RCX + 4) != 0 && (*(int32_t *)(in_RDX + 4) != 0)) &&
        (*(int32_t *)(in_RCX + 4) != *(int32_t *)(in_RDX + 4))))) {
        return 1;
    }
    if ((**in_RCX & 2) != 0) {
        return 0;
    }
    iVar13 = iVar12;
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802662fb;
        in_R8 = func_0x0001802d4730();
        iVar13 = in_R8;
        if (in_R8 == 0) {
            return 0xffffffff;
        }
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + -8) = unaff_R12;
    *(undefined8 *)((int64_t)&var_8h + iVar7) = unaff_R13;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266331;
    func_0x0001802d48b0(in_R8);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266339;
    uVar8 = func_0x0001802d4590(in_R8);
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = uVar8;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266346;
    uVar8 = func_0x0001802d4590(in_R8);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266351;
    uVar9 = func_0x0001802d4590(in_R8);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18026635c;
    uVar10 = func_0x0001802d4590(in_R8);
    *(undefined8 *)((int64_t)&arg_48h + iVar7) = uVar10;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266369;
    uVar10 = func_0x0001802d4590(in_R8);
    *(undefined8 *)((int64_t)&arg_60h + iVar7) = uVar10;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266379;
    iVar11 = func_0x0001802d4590(in_R8);
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266389;
        func_0x0001802d4450(in_R8);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266391;
        func_0x0001802d44d0(iVar13);
        return 0xffffffff;
    }
    puVar1 = *in_RCX;
    *(int64_t *)(&stack0xfffffffffffffff8 + iVar7) = in_R8;
    pcVar2 = *(code **)(puVar1 + 0x30);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802663d1;
    iVar6 = (*pcVar2)(in_RCX, *(undefined8 *)((int64_t)&arg_50h + iVar7), uVar8, uVar9);
    if (iVar6 != 0) {
        iVar3 = *in_RDX;
        *(int64_t *)(&stack0xfffffffffffffff8 + iVar7) = in_R8;
        pcVar2 = *(code **)(iVar3 + 0x30);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802663fb;
        iVar6 = (*pcVar2)(in_RDX, *(undefined8 *)((int64_t)&arg_48h + iVar7), *(undefined8 *)((int64_t)&arg_60h + iVar7)
                          , iVar11);
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266412;
            iVar6 = func_0x000180254f10(*(undefined8 *)((int64_t)&arg_50h + iVar7), 
                                        *(undefined8 *)((int64_t)&arg_48h + iVar7));
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18026642a;
                iVar6 = func_0x000180254f10(uVar8, *(undefined8 *)((int64_t)&arg_60h + iVar7));
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18026643d;
                    iVar6 = func_0x000180254f10(uVar9, iVar11);
                    if (iVar6 == 0) {
                        puVar1 = *in_RCX;
                        ppuVar4 = (uint8_t **)in_RDX[1];
                        ppuVar5 = (uint8_t **)in_RCX[1];
                        if (*(int64_t *)(puVar1 + 200) == 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18026645e;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -0x18));
                            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266476;
                            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -0x18), 
                                          *(int64_t *)((int64_t)&var_8h + iVar7), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -8), 
                                          *(int64_t *)(&stack0x00000028 + iVar7));
                        } else {
                            if (((puVar1 == *ppuVar5) &&
                                ((((iVar6 = *(int32_t *)(in_RCX + 4), iVar6 == 0 || (*(int32_t *)(ppuVar5 + 1) == 0)) ||
                                  (iVar6 == *(int32_t *)(ppuVar5 + 1))) && (puVar1 == *ppuVar4)))) &&
                               (((iVar6 == 0 || (*(int32_t *)(ppuVar4 + 1) == 0)) ||
                                (iVar6 == *(int32_t *)(ppuVar4 + 1))))) {
                                pcVar2 = *(code **)(*in_RCX + 200);
                                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802664ca;
                                iVar6 = (*pcVar2)(in_RCX, ppuVar5, ppuVar4, in_R8);
                                if (iVar6 == 0) {
                                    if ((in_RCX[2] == (uint8_t *)0x0) || (in_RDX[2] == 0)) {
                                        iVar12 = 0xffffffff;
                                        goto code_r0x000180266559;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802664e9;
                                    iVar6 = func_0x000180254f10();
                                    if (iVar6 == 0) {
                                        puVar1 = in_RCX[3];
                                        iVar11 = in_RDX[3];
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802664fd;
                                        iVar6 = func_0x0001802553f0(puVar1);
                                        if (iVar6 != 0) goto code_r0x000180266559;
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266509;
                                        iVar6 = func_0x0001802553f0(iVar11);
                                        if (iVar6 != 0) goto code_r0x000180266559;
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266518;
                                        iVar6 = func_0x000180254f10(puVar1, iVar11);
                                        if (iVar6 == 0) goto code_r0x000180266559;
                                    }
                                }
                                goto code_r0x000180266554;
                            }
                            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18026652a;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -0x18));
                            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266542;
                            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -0x18), 
                                          *(int64_t *)((int64_t)&var_8h + iVar7), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -8), 
                                          *(int64_t *)(&stack0x00000028 + iVar7));
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266554;
                        fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_18 + iVar7));
                    }
                }
            }
        }
    }
code_r0x000180266554:
    iVar12 = 1;
code_r0x000180266559:
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266561;
    func_0x0001802d4450(in_R8);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180266569;
    func_0x0001802d44d0(iVar13);
    return iVar12;
}

// ============================================================
// Function: FUN_180266590
// Address: 0x180266590
// Size: 207 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180266590(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 uVar1;
    uint8_t *puVar2;
    int64_t *piVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint8_t *puVar6;
    int64_t iVar7;
    code *pcVar8;
    uint8_t *puVar9;
    undefined8 uVar10;
    uint8_t **in_RCX;
    uint8_t **in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802665a0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (*(int64_t *)(*in_RCX + 0x20) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802665b8;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802665d0;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802665e2;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    if (*in_RCX != *in_RDX) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802665f9;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180266611;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180266623;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    if (in_RCX == in_RDX) {
        return 1;
    }
    in_RCX[0x15] = in_RDX[0x15];
    *(undefined4 *)(in_RCX + 4) = *(undefined4 *)(in_RDX + 4);
    uVar1 = *(undefined4 *)(in_RDX + 0x13);
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RSI;
    puVar9 = (uint8_t *)0x0;
    *(undefined4 *)(in_RCX + 0x13) = uVar1;
    if (*(int32_t *)(in_RDX + 0x13) == 0) {
        in_RCX[0x14] = (uint8_t *)0x0;
    } else if (*(int32_t *)(in_RDX + 0x13) == 6) {
        puVar6 = in_RDX[0x14];
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180266687;
        puVar6 = (uint8_t *)fcn.1802d7d50(puVar6);
        in_RCX[0x14] = puVar6;
    }
    if (in_RDX[0x12] == (uint8_t *)0x0) {
        puVar6 = in_RCX[0x12];
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802666ef;
        fcn.1802cd2a0(puVar6);
        in_RCX[0x12] = (uint8_t *)0x0;
    } else {
        if (in_RCX[0x12] == (uint8_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802666b1;
            puVar6 = (uint8_t *)fcn.1802cd2f0();
            in_RCX[0x12] = puVar6;
            if (puVar6 == (uint8_t *)0x0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802666cc;
        iVar7 = fcn.1802cd220(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
        if (iVar7 == 0) {
            return 0;
        }
    }
    if (in_RDX[1] == (uint8_t *)0x0) {
        *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_R14;
        piVar3 = (int64_t *)in_RCX[1];
        if (piVar3 != (int64_t *)0x0) {
            pcVar8 = *(code **)(*piVar3 + 0x60);
            if ((pcVar8 != (code *)0x0) || (pcVar8 = *(code **)(*piVar3 + 0x58), pcVar8 != (code *)0x0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180266750;
                (*pcVar8)(piVar3);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026676a;
            fcn.180224b90(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        }
        in_RCX[1] = (uint8_t *)0x0;
    } else {
        puVar6 = in_RCX[1];
        if (puVar6 == (uint8_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026670d;
            puVar6 = (uint8_t *)fcn.1802685b0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
            in_RCX[1] = puVar6;
            if (puVar6 == (uint8_t *)0x0) {
                return 0;
            }
        }
        puVar2 = in_RDX[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180266722;
        iVar4 = fcn.180267e30(puVar6, puVar2);
        if (iVar4 == 0) {
            return 0;
        }
    }
    if ((**in_RDX & 2) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180266788;
        iVar7 = fcn.180255110(*(int64_t *)((int64_t)&iStackX_20 + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5), 
                              *(int64_t *)(&stack0x00000050 + iVar5));
        if (iVar7 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026679e;
        iVar7 = fcn.180255110(*(int64_t *)((int64_t)&iStackX_20 + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5), 
                              *(int64_t *)(&stack0x00000050 + iVar5));
        if (iVar7 == 0) {
            return 0;
        }
    }
    puVar6 = in_RCX[6];
    *(undefined4 *)((int64_t)in_RCX + 0x24) = *(undefined4 *)((int64_t)in_RDX + 0x24);
    *(undefined4 *)((int64_t)in_RCX + 0x2c) = *(undefined4 *)((int64_t)in_RDX + 0x2c);
    *(undefined4 *)(in_RCX + 5) = *(undefined4 *)(in_RDX + 5);
    if (in_RDX[6] != (uint8_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802667d5;
        fcn.180224990(puVar6, 0x1804e6f68, 0xfe);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802667eb;
        puVar9 = (uint8_t *)
                 fcn.1802248d0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                               *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        in_RCX[6] = puVar9;
        if (puVar9 != (uint8_t *)0x0) {
            puVar6 = in_RDX[7];
            puVar2 = in_RDX[6];
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180266808;
            iVar5 = fcn.180498030(puVar9, puVar2, puVar6);
            if (iVar5 != 0) {
                puVar9 = in_RDX[7];
                goto code_r0x000180266826;
            }
        }
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180266822;
    fcn.180224990(puVar6, 0x1804e6f68, 0x105);
    in_RCX[6] = (uint8_t *)0x0;
code_r0x000180266826:
    in_RCX[7] = puVar9;
    // WARNING: Could not recover jumptable at 0x000180266846. Too many branches
    // WARNING: Treating indirect jump as call
    uVar10 = (**(code **)(*in_RCX + 0x20))(in_RCX, in_RDX, *(code **)(*in_RCX + 0x20));
    return uVar10;
}

// ============================================================
// Function: FUN_18026665f
// Address: 0x18026665f
// Size: 132 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180266590(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 uVar1;
    uint8_t *puVar2;
    int64_t *piVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint8_t *puVar6;
    int64_t iVar7;
    code *pcVar8;
    uint8_t *puVar9;
    undefined8 uVar10;
    uint8_t **in_RCX;
    uint8_t **in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802665a0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (*(int64_t *)(*in_RCX + 0x20) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802665b8;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802665d0;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802665e2;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    if (*in_RCX != *in_RDX) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802665f9;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180266611;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180266623;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    if (in_RCX == in_RDX) {
        return 1;
    }
    in_RCX[0x15] = in_RDX[0x15];
    *(undefined4 *)(in_RCX + 4) = *(undefined4 *)(in_RDX + 4);
    uVar1 = *(undefined4 *)(in_RDX + 0x13);
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RSI;
    puVar9 = (uint8_t *)0x0;
    *(undefined4 *)(in_RCX + 0x13) = uVar1;
    if (*(int32_t *)(in_RDX + 0x13) == 0) {
        in_RCX[0x14] = (uint8_t *)0x0;
    } else if (*(int32_t *)(in_RDX + 0x13) == 6) {
        puVar6 = in_RDX[0x14];
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180266687;
        puVar6 = (uint8_t *)fcn.1802d7d50(puVar6);
        in_RCX[0x14] = puVar6;
    }
    if (in_RDX[0x12] == (uint8_t *)0x0) {
        puVar6 = in_RCX[0x12];
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802666ef;
        fcn.1802cd2a0(puVar6);
        in_RCX[0x12] = (uint8_t *)0x0;
    } else {
        if (in_RCX[0x12] == (uint8_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802666b1;
            puVar6 = (uint8_t *)fcn.1802cd2f0();
            in_RCX[0x12] = puVar6;
            if (puVar6 == (uint8_t *)0x0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802666cc;
        iVar7 = fcn.1802cd220(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
        if (iVar7 == 0) {
            return 0;
        }
    }
    if (in_RDX[1] == (uint8_t *)0x0) {
        *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_R14;
        piVar3 = (int64_t *)in_RCX[1];
        if (piVar3 != (int64_t *)0x0) {
            pcVar8 = *(code **)(*piVar3 + 0x60);
            if ((pcVar8 != (code *)0x0) || (pcVar8 = *(code **)(*piVar3 + 0x58), pcVar8 != (code *)0x0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180266750;
                (*pcVar8)(piVar3);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026676a;
            fcn.180224b90(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        }
        in_RCX[1] = (uint8_t *)0x0;
    } else {
        puVar6 = in_RCX[1];
        if (puVar6 == (uint8_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026670d;
            puVar6 = (uint8_t *)fcn.1802685b0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
            in_RCX[1] = puVar6;
            if (puVar6 == (uint8_t *)0x0) {
                return 0;
            }
        }
        puVar2 = in_RDX[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180266722;
        iVar4 = fcn.180267e30(puVar6, puVar2);
        if (iVar4 == 0) {
            return 0;
        }
    }
    if ((**in_RDX & 2) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180266788;
        iVar7 = fcn.180255110(*(int64_t *)((int64_t)&iStackX_20 + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5), 
                              *(int64_t *)(&stack0x00000050 + iVar5));
        if (iVar7 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026679e;
        iVar7 = fcn.180255110(*(int64_t *)((int64_t)&iStackX_20 + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5), 
                              *(int64_t *)(&stack0x00000050 + iVar5));
        if (iVar7 == 0) {
            return 0;
        }
    }
    puVar6 = in_RCX[6];
    *(undefined4 *)((int64_t)in_RCX + 0x24) = *(undefined4 *)((int64_t)in_RDX + 0x24);
    *(undefined4 *)((int64_t)in_RCX + 0x2c) = *(undefined4 *)((int64_t)in_RDX + 0x2c);
    *(undefined4 *)(in_RCX + 5) = *(undefined4 *)(in_RDX + 5);
    if (in_RDX[6] != (uint8_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802667d5;
        fcn.180224990(puVar6, 0x1804e6f68, 0xfe);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802667eb;
        puVar9 = (uint8_t *)
                 fcn.1802248d0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                               *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        in_RCX[6] = puVar9;
        if (puVar9 != (uint8_t *)0x0) {
            puVar6 = in_RDX[7];
            puVar2 = in_RDX[6];
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180266808;
            iVar5 = fcn.180498030(puVar9, puVar2, puVar6);
            if (iVar5 != 0) {
                puVar9 = in_RDX[7];
                goto code_r0x000180266826;
            }
        }
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180266822;
    fcn.180224990(puVar6, 0x1804e6f68, 0x105);
    in_RCX[6] = (uint8_t *)0x0;
code_r0x000180266826:
    in_RCX[7] = puVar9;
    // WARNING: Could not recover jumptable at 0x000180266846. Too many branches
    // WARNING: Treating indirect jump as call
    uVar10 = (**(code **)(*in_RCX + 0x20))(in_RCX, in_RDX, *(code **)(*in_RCX + 0x20));
    return uVar10;
}

// ============================================================
// Function: FUN_1802666e3
// Address: 0x1802666e3
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180266590(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 uVar1;
    uint8_t *puVar2;
    int64_t *piVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint8_t *puVar6;
    int64_t iVar7;
    code *pcVar8;
    uint8_t *puVar9;
    undefined8 uVar10;
    uint8_t **in_RCX;
    uint8_t **in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802665a0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (*(int64_t *)(*in_RCX + 0x20) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802665b8;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802665d0;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802665e2;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    if (*in_RCX != *in_RDX) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802665f9;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180266611;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180266623;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    if (in_RCX == in_RDX) {
        return 1;
    }
    in_RCX[0x15] = in_RDX[0x15];
    *(undefined4 *)(in_RCX + 4) = *(undefined4 *)(in_RDX + 4);
    uVar1 = *(undefined4 *)(in_RDX + 0x13);
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RSI;
    puVar9 = (uint8_t *)0x0;
    *(undefined4 *)(in_RCX + 0x13) = uVar1;
    if (*(int32_t *)(in_RDX + 0x13) == 0) {
        in_RCX[0x14] = (uint8_t *)0x0;
    } else if (*(int32_t *)(in_RDX + 0x13) == 6) {
        puVar6 = in_RDX[0x14];
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180266687;
        puVar6 = (uint8_t *)fcn.1802d7d50(puVar6);
        in_RCX[0x14] = puVar6;
    }
    if (in_RDX[0x12] == (uint8_t *)0x0) {
        puVar6 = in_RCX[0x12];
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802666ef;
        fcn.1802cd2a0(puVar6);
        in_RCX[0x12] = (uint8_t *)0x0;
    } else {
        if (in_RCX[0x12] == (uint8_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802666b1;
            puVar6 = (uint8_t *)fcn.1802cd2f0();
            in_RCX[0x12] = puVar6;
            if (puVar6 == (uint8_t *)0x0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802666cc;
        iVar7 = fcn.1802cd220(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
        if (iVar7 == 0) {
            return 0;
        }
    }
    if (in_RDX[1] == (uint8_t *)0x0) {
        *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_R14;
        piVar3 = (int64_t *)in_RCX[1];
        if (piVar3 != (int64_t *)0x0) {
            pcVar8 = *(code **)(*piVar3 + 0x60);
            if ((pcVar8 != (code *)0x0) || (pcVar8 = *(code **)(*piVar3 + 0x58), pcVar8 != (code *)0x0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180266750;
                (*pcVar8)(piVar3);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026676a;
            fcn.180224b90(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        }
        in_RCX[1] = (uint8_t *)0x0;
    } else {
        puVar6 = in_RCX[1];
        if (puVar6 == (uint8_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026670d;
            puVar6 = (uint8_t *)fcn.1802685b0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
            in_RCX[1] = puVar6;
            if (puVar6 == (uint8_t *)0x0) {
                return 0;
            }
        }
        puVar2 = in_RDX[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180266722;
        iVar4 = fcn.180267e30(puVar6, puVar2);
        if (iVar4 == 0) {
            return 0;
        }
    }
    if ((**in_RDX & 2) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180266788;
        iVar7 = fcn.180255110(*(int64_t *)((int64_t)&iStackX_20 + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5), 
                              *(int64_t *)(&stack0x00000050 + iVar5));
        if (iVar7 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026679e;
        iVar7 = fcn.180255110(*(int64_t *)((int64_t)&iStackX_20 + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5), 
                              *(int64_t *)(&stack0x00000050 + iVar5));
        if (iVar7 == 0) {
            return 0;
        }
    }
    puVar6 = in_RCX[6];
    *(undefined4 *)((int64_t)in_RCX + 0x24) = *(undefined4 *)((int64_t)in_RDX + 0x24);
    *(undefined4 *)((int64_t)in_RCX + 0x2c) = *(undefined4 *)((int64_t)in_RDX + 0x2c);
    *(undefined4 *)(in_RCX + 5) = *(undefined4 *)(in_RDX + 5);
    if (in_RDX[6] != (uint8_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802667d5;
        fcn.180224990(puVar6, 0x1804e6f68, 0xfe);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802667eb;
        puVar9 = (uint8_t *)
                 fcn.1802248d0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                               *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        in_RCX[6] = puVar9;
        if (puVar9 != (uint8_t *)0x0) {
            puVar6 = in_RDX[7];
            puVar2 = in_RDX[6];
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180266808;
            iVar5 = fcn.180498030(puVar9, puVar2, puVar6);
            if (iVar5 != 0) {
                puVar9 = in_RDX[7];
                goto code_r0x000180266826;
            }
        }
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180266822;
    fcn.180224990(puVar6, 0x1804e6f68, 0x105);
    in_RCX[6] = (uint8_t *)0x0;
code_r0x000180266826:
    in_RCX[7] = puVar9;
    // WARNING: Could not recover jumptable at 0x000180266846. Too many branches
    // WARNING: Treating indirect jump as call
    uVar10 = (**(code **)(*in_RCX + 0x20))(in_RCX, in_RDX, *(code **)(*in_RCX + 0x20));
    return uVar10;
}

