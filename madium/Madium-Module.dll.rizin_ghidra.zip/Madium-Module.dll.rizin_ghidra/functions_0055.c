// Chunk 55 - 50 functions

// ============================================================
// Function: FUN_1800ad27e
// Address: 0x1800ad27e
// Size: 194 bytes
// ============================================================
void fcn.1800ad27e(int64_t arg1, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 in_EAX;
    uint8_t *puVar3;
    uint8_t in_DL;
    undefined4 uVar4;
    int64_t *unaff_RSI;
    undefined8 *unaff_RDI;
    bool in_CF;
    
    if (in_CF) {
        in_EAX = (undefined4)arg1;
    }
    *(undefined4 *)(unaff_RSI + 0xc2) = in_EAX;
    iVar1 = *unaff_RSI;
    arg_40h = CONCAT44(arg_40h._4_4_, (uint32_t)in_DL << 8) | 0x35;
    fcn.1800d31a0(iVar1 + 0x28, &arg_40h);
    fcn.1800d31a0(iVar1 + 0x40, iVar1 + 0x270);
    iVar1 = *unaff_RSI;
    arg_40h = arg_40h & 0xffffffff00000000;
    fcn.1800d31a0(iVar1 + 0x28, &arg_40h);
    fcn.1800d31a0(iVar1 + 0x40, iVar1 + 0x270);
    if ((uint64_t)(unaff_RSI[0xc9] - unaff_RSI[200] >> 3) < 200) {
        fcn.1800bf890(unaff_RSI + 200, &arg_40h);
        puVar3 = (uint8_t *)fcn.1800c0050(unaff_RSI + 0x11, &arg_40h);
        *puVar3 = in_DL;
        puVar3[1] = 1;
        uVar4 = (undefined4)(*(int64_t *)(*unaff_RSI + 0x30) - *(int64_t *)(*unaff_RSI + 0x28) >> 2);
        *(undefined4 *)(puVar3 + 4) = uVar4;
        *(undefined4 *)(puVar3 + 8) = uVar4;
        return;
    }
    fcn.1800acea0(unaff_RDI + 1, 0x18063fb70, *unaff_RDI, 200);
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_1800ad340
// Address: 0x1800ad340
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_48h
// WARNING: Variable defined which should be unmapped: arg_40h

void fcn.1800ad27e(int64_t arg1, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 in_EAX;
    uint8_t *puVar3;
    uint8_t in_DL;
    undefined4 uVar4;
    int64_t *unaff_RSI;
    undefined8 *unaff_RDI;
    bool in_CF;
    
    if (in_CF) {
        in_EAX = (undefined4)arg1;
    }
    *(undefined4 *)(unaff_RSI + 0xc2) = in_EAX;
    iVar1 = *unaff_RSI;
    arg_40h = CONCAT44(arg_40h._4_4_, (uint32_t)in_DL << 8) | 0x35;
    fcn.1800d31a0(iVar1 + 0x28, &arg_40h);
    fcn.1800d31a0(iVar1 + 0x40, iVar1 + 0x270);
    iVar1 = *unaff_RSI;
    arg_40h = arg_40h & 0xffffffff00000000;
    fcn.1800d31a0(iVar1 + 0x28, &arg_40h);
    fcn.1800d31a0(iVar1 + 0x40, iVar1 + 0x270);
    if ((uint64_t)(unaff_RSI[0xc9] - unaff_RSI[200] >> 3) < 200) {
        fcn.1800bf890(unaff_RSI + 200, &arg_40h);
        puVar3 = (uint8_t *)fcn.1800c0050(unaff_RSI + 0x11, &arg_40h);
        *puVar3 = in_DL;
        puVar3[1] = 1;
        uVar4 = (undefined4)(*(int64_t *)(*unaff_RSI + 0x30) - *(int64_t *)(*unaff_RSI + 0x28) >> 2);
        *(undefined4 *)(puVar3 + 4) = uVar4;
        *(undefined4 *)(puVar3 + 8) = uVar4;
        return;
    }
    fcn.1800acea0(unaff_RDI + 1, 0x18063fb70, *unaff_RDI, 200);
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_1800ad34e
// Address: 0x1800ad34e
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_48h
// WARNING: Variable defined which should be unmapped: arg_40h

void fcn.1800ad27e(int64_t arg1, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 in_EAX;
    uint8_t *puVar3;
    uint8_t in_DL;
    undefined4 uVar4;
    int64_t *unaff_RSI;
    undefined8 *unaff_RDI;
    bool in_CF;
    
    if (in_CF) {
        in_EAX = (undefined4)arg1;
    }
    *(undefined4 *)(unaff_RSI + 0xc2) = in_EAX;
    iVar1 = *unaff_RSI;
    arg_40h = CONCAT44(arg_40h._4_4_, (uint32_t)in_DL << 8) | 0x35;
    fcn.1800d31a0(iVar1 + 0x28, &arg_40h);
    fcn.1800d31a0(iVar1 + 0x40, iVar1 + 0x270);
    iVar1 = *unaff_RSI;
    arg_40h = arg_40h & 0xffffffff00000000;
    fcn.1800d31a0(iVar1 + 0x28, &arg_40h);
    fcn.1800d31a0(iVar1 + 0x40, iVar1 + 0x270);
    if ((uint64_t)(unaff_RSI[0xc9] - unaff_RSI[200] >> 3) < 200) {
        fcn.1800bf890(unaff_RSI + 200, &arg_40h);
        puVar3 = (uint8_t *)fcn.1800c0050(unaff_RSI + 0x11, &arg_40h);
        *puVar3 = in_DL;
        puVar3[1] = 1;
        uVar4 = (undefined4)(*(int64_t *)(*unaff_RSI + 0x30) - *(int64_t *)(*unaff_RSI + 0x28) >> 2);
        *(undefined4 *)(puVar3 + 4) = uVar4;
        *(undefined4 *)(puVar3 + 8) = uVar4;
        return;
    }
    fcn.1800acea0(unaff_RDI + 1, 0x18063fb70, *unaff_RDI, 200);
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_1800ad368
// Address: 0x1800ad368
// Size: 29 bytes
// ============================================================
void fcn.1800ad368(void)
{
    code *pcVar1;
    int64_t unaff_RBX;
    
    fcn.1800acea0(unaff_RBX + 0xc, 0x18063fbc0, 1, 0xff);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1800ad390
// Address: 0x1800ad390
// Size: 199 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1800ad390(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    code *pcVar2;
    uint32_t uVar3;
    uint8_t uVar4;
    uint64_t uVar5;
    uint32_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar5 = fcn.1800acf70(arg1, arg1 + 0x5c0);
    if ((int32_t)uVar5 < 0) {
        uVar4 = fcn.1800ad020(arg1, arg1 + 0x5c0);
        uVar6 = *(uint32_t *)(arg1 + 0x60c);
        uVar1 = uVar6 + 1;
        if (0xff < uVar1) {
            fcn.1800acea0(arg2 + 0xc, 0x18063fbc0, 1, 0xff);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
        *(uint32_t *)(arg1 + 0x60c) = uVar1;
        uVar6 = uVar6 & 0xff;
        uVar3 = *(uint32_t *)(arg1 + 0x610);
        if (*(uint32_t *)(arg1 + 0x610) < uVar1) {
            uVar3 = uVar1;
        }
        *(uint32_t *)(arg1 + 0x610) = uVar3;
        arg1 = *(int64_t *)arg1;
        var_8h._0_4_ = ((uint32_t)uVar4 << 8 | uVar6) << 8 | 9;
        fcn.1800d31a0(arg1 + 0x28, &var_8h);
        fcn.1800d31a0(arg1 + 0x40, arg1 + 0x270);
        uVar5 = (uint64_t)uVar6;
    }
    return uVar5;
}

// ============================================================
// Function: FUN_1800ad460
// Address: 0x1800ad460
// Size: 153 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800ad460(int64_t arg1, undefined8 placeholder_1, int64_t arg3)
{
    uint64_t *puVar1;
    uint64_t uVar2;
    undefined4 *puVar3;
    code *pcVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined4 *puVar7;
    int64_t iVar8;
    undefined *puVar9;
    undefined8 *puVar10;
    undefined *puVar11;
    uint64_t uVar12;
    undefined8 uVar13;
    uint32_t uVar14;
    int64_t iVar15;
    uint64_t uVar16;
    int64_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 auStack_50 [3];
    undefined auStack_38 [8];
    undefined8 auStack_30 [3];
    
    iVar8 = *(int64_t *)arg1;
    uVar14 = (uint32_t)arg3;
    iVar17 = iVar8 + 0x28;
    if ((int32_t)uVar14 < 0x8000) {
        var_18h = CONCAT44(var_18h._4_4_, ((uVar14 & 0xffff) << 8 | (uint32_t)(uint8_t)placeholder_1) << 8) | 5;
    } else {
        var_18h = CONCAT44(var_18h._4_4_, (uint32_t)(uint8_t)placeholder_1 << 8) | 0x42;
        auStack_30[0] = 0x1800ad4b5;
        fcn.1800d31a0(iVar17, &var_18h);
        auStack_30[0] = 0x1800ad4c5;
        fcn.1800d31a0(iVar8 + 0x40, iVar8 + 0x270);
        iVar8 = *(int64_t *)arg1;
        var_18h = CONCAT44(var_18h._4_4_, uVar14);
        iVar17 = iVar8 + 0x28;
    }
    auStack_30[0] = 0x1800ad4da;
    fcn.1800d31a0(iVar17, &var_18h);
    puVar1 = (uint64_t *)(iVar8 + 0x40);
    puVar10 = (undefined8 *)auStack_38;
    puVar11 = auStack_38;
    puVar7 = *(undefined4 **)(iVar8 + 0x48);
    if (puVar7 != *(undefined4 **)(iVar8 + 0x50)) {
        *puVar7 = *(undefined4 *)(iVar8 + 0x270);
        *(int64_t *)(iVar8 + 0x48) = *(int64_t *)(iVar8 + 0x48) + 4;
        return;
    }
    iVar17 = (int64_t)((int64_t)puVar7 - *puVar1) >> 2;
    if (iVar17 == 0x3fffffffffffffff) {
        fcn.180010010();
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    uVar6 = (int64_t)((int64_t)*(undefined4 **)(iVar8 + 0x50) - *puVar1) >> 2;
    if (uVar6 <= 0x3fffffffffffffff - (uVar6 >> 1)) {
        uVar2 = iVar17 + 1;
        uVar6 = uVar6 + (uVar6 >> 1);
        uVar12 = uVar2;
        if (uVar2 <= uVar6) {
            uVar12 = uVar6;
        }
        if (uVar12 < 0x4000000000000000) {
            uVar6 = uVar12 * 4;
            if (uVar6 == 0) {
                uVar6 = 0;
                puVar11 = auStack_38;
            } else if (uVar6 < 0x1000) {
                uVar6 = fcn.180459890();
            } else {
                if (uVar6 + 0x27 <= uVar6) goto code_r0x0001800d32fa;
                iVar15 = fcn.180459890(uVar6 + 0x27);
                if (iVar15 == 0) {
                    pcVar4 = (code *)swi(0x29);
                    iVar15 = (*pcVar4)(5);
                    puVar10 = auStack_30;
                }
                uVar6 = iVar15 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar6 - 8) = iVar15;
                puVar11 = (undefined *)puVar10;
            }
            *(undefined4 *)(uVar6 + iVar17 * 4) = *(undefined4 *)(iVar8 + 0x270);
            puVar3 = (undefined4 *)*puVar1;
            if (puVar7 == *(undefined4 **)(iVar8 + 0x48)) {
                iVar15 = (int64_t)*(undefined4 **)(iVar8 + 0x48) - (int64_t)puVar3;
                uVar16 = uVar6;
                puVar7 = puVar3;
            } else {
                *(undefined8 *)(puVar11 + -8) = 0x1800d32b0;
                fcn.180498030(uVar6, puVar3, (int64_t)puVar7 - (int64_t)puVar3);
                iVar15 = *(int64_t *)(iVar8 + 0x48) - (int64_t)puVar7;
                uVar16 = uVar6 + (iVar17 + 1) * 4;
            }
            *(undefined8 *)(puVar11 + -8) = 0x1800d32c7;
            fcn.180498030(uVar16, puVar7, iVar15);
            uVar13 = *(undefined8 *)(puVar11 + 0x28);
            *(undefined8 *)(puVar11 + 0x30) = *(undefined8 *)(puVar11 + 0x30);
            *(undefined8 *)(puVar11 + 0x28) = *(undefined8 *)(puVar11 + 0x40);
            *(undefined8 *)(puVar11 + 0x20) = uVar13;
            *(undefined8 *)(puVar11 + 0x18) = *(undefined8 *)(puVar11 + 0x48);
            uVar16 = *puVar1;
            if (uVar16 != 0) {
                uVar5 = uVar16;
                puVar9 = puVar11 + -0x10;
                if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(iVar8 + 0x50) - uVar16) >> 2) * 4)) {
                    uVar5 = *(uint64_t *)(uVar16 - 8);
                    uVar16 = (uVar16 - uVar5) - 8;
                    puVar9 = puVar11 + -0x10;
                    if (0x1f < uVar16) {
                        pcVar4 = (code *)swi(0x29);
                        uVar5 = uVar16;
                        (*pcVar4)(5);
                        puVar9 = puVar11 + -8;
                    }
                }
                *(undefined8 *)(puVar9 + -8) = 0x180030d9f;
                fcn.180459c3c(uVar5);
            }
            *puVar1 = uVar6;
            *(uint64_t *)(iVar8 + 0x48) = uVar6 + uVar2 * 4;
            *(uint64_t *)(iVar8 + 0x50) = uVar6 + uVar12 * 4;
            return;
        }
    }
code_r0x0001800d32fa:
    fcn.180004720();
    pcVar4 = (code *)swi(3);
    (*pcVar4)();
    return;
}

// ============================================================
// Function: FUN_1800ad500
// Address: 0x1800ad500
// Size: 665 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_40h

int64_t fcn.1800ad500(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    uint32_t uVar2;
    char *pcVar3;
    char cVar4;
    undefined4 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t *piVar9;
    int32_t *piVar10;
    uint64_t uVar11;
    int32_t *piVar12;
    int32_t *piVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    uint32_t var_40h;
    int64_t var_3ch;
    
    cVar4 = *(char *)0x180777f78;
code_r0x0001800ad530:
    do {
        iVar1 = *(int32_t *)(arg2 + 8);
        iVar6 = 0;
        if (iVar1 == *(int32_t *)0x180782728) {
            iVar6 = arg2;
        }
        if (iVar6 == 0) {
            iVar6 = 0;
            if (iVar1 == *(int32_t *)0x18078269c) {
                iVar6 = arg2;
            }
            if ((iVar6 == 0) || (cVar4 == '\0')) {
                iVar6 = 0;
                if (iVar1 == *(int32_t *)0x1807826c0) {
                    iVar6 = arg2;
                }
                if (iVar6 == 0) {
                    iVar6 = 0;
                    if (iVar1 == *(int32_t *)0x180782708) {
                        iVar6 = arg2;
                    }
                    if (iVar6 == 0) {
                        iVar6 = 0;
                        if (iVar1 == *(int32_t *)0x180782674) {
                            iVar6 = arg2;
                        }
                        if ((iVar6 == 0) || (cVar4 == '\0')) {
                            if (iVar1 == *(int32_t *)0x1807826a0) {
                                return arg2;
                            }
                            return 0;
                        }
                        arg2 = *(int64_t *)(iVar6 + 0x20);
                    } else {
                        arg2 = *(int64_t *)(iVar6 + 0x20);
                    }
                } else {
                    arg2 = *(int64_t *)(iVar6 + 0x20);
                }
                goto code_r0x0001800ad530;
            }
            iVar7 = func_0x0001800beb60(*(undefined8 *)(iVar6 + 0x20));
            if (iVar7 == 0) {
                return 0;
            }
            iVar7 = func_0x0001800ac770(arg1 + 0xd8, iVar7 + 0x20);
            piVar9 = (int64_t *)(iVar7 + 8);
            if (iVar7 == 0) {
                piVar9 = (int64_t *)0x0;
            }
            if (piVar9 == (int64_t *)0x0) {
                return 0;
            }
            if (*(char *)(piVar9 + 1) != '\0') {
                return 0;
            }
            iVar7 = *piVar9;
            if (iVar7 == 0) {
                return 0;
            }
            iVar8 = func_0x0001800ac7f0(arg1 + 0x150);
            piVar13 = (int32_t *)(iVar8 + 8);
            if (iVar8 == 0) {
                piVar13 = (int32_t *)0x0;
            }
            if (piVar13 == (int32_t *)0x0) {
                return 0;
            }
            if (*piVar13 != 0) {
                return 0;
            }
            iVar7 = func_0x0001800bebd0(iVar7);
            if (iVar7 == 0) {
                return 0;
            }
            piVar12 = *(int32_t **)(iVar7 + 0x20);
            arg2 = 0;
            piVar13 = piVar12 + *(int64_t *)(iVar7 + 0x28) * 6;
            if (piVar12 == piVar13) {
                return 0;
            }
            do {
                if (*piVar12 - 1U < 2) {
                    iVar7 = func_0x0001800c13d0(arg1 + 0x100, piVar12 + 2);
                    piVar10 = (int32_t *)(iVar7 + 8);
                    if (iVar7 == 0) {
                        piVar10 = (int32_t *)0x0;
                    }
                    if (piVar10 == (int32_t *)0x0) {
                        arg2 = 0;
                    } else if (*piVar10 == 6) {
                        uVar2 = piVar10[1];
                        uVar11 = (uint64_t)uVar2;
                        if (uVar2 != 0) {
                            pcVar3 = *(char **)(piVar10 + 2);
                            iVar7 = *(int64_t *)(arg1 + 0x5b8);
                            var_3ch._0_4_ = 0;
                            var_48h = (int64_t)pcVar3;
                            var_40h = uVar2;
                            piVar9 = (int64_t *)func_0x0001800d8c20(iVar7, &var_48h);
                            if (*(int32_t *)((int64_t)piVar9 + 0xc) == 0) {
                                iVar7 = func_0x0001800d4d20(*(undefined8 *)(iVar7 + 0x30), uVar11 + 1);
                                fcn.180498030(iVar7, pcVar3, uVar11);
                                *(undefined *)(uVar11 + iVar7) = 0;
                                *piVar9 = iVar7;
                                uVar5 = 0x119;
                                if (*pcVar3 == '@') {
                                    uVar5 = 0x11c;
                                }
                                *(undefined4 *)((int64_t)piVar9 + 0xc) = uVar5;
                            } else {
                                iVar7 = *piVar9;
                            }
                            if (iVar7 == *(int64_t *)(iVar6 + 0x28)) {
                                arg2 = *(int64_t *)(piVar12 + 4);
                            }
                        }
                    }
                }
                piVar12 = piVar12 + 6;
                cVar4 = *(char *)0x180777f78;
            } while (piVar12 != piVar13);
        } else {
            iVar6 = func_0x0001800ac770(arg1 + 0xd8, iVar6 + 0x20);
            piVar9 = (int64_t *)(iVar6 + 8);
            if (iVar6 == 0) {
                piVar9 = (int64_t *)0x0;
            }
            if (piVar9 == (int64_t *)0x0) {
                return 0;
            }
            if (*(char *)(piVar9 + 1) != '\0') {
                return 0;
            }
            arg2 = *piVar9;
        }
        if (arg2 == 0) {
            return 0;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1800ad7a0
// Address: 0x1800ad7a0
// Size: 5092 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x0001800ade9f)
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h

uint64_t fcn.1800ad7a0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t **ppiVar1;
    int64_t *piVar2;
    undefined8 *puVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    code *pcVar8;
    char cVar9;
    undefined uVar10;
    uint32_t uVar11;
    undefined4 uVar12;
    int32_t iVar13;
    uint32_t uVar14;
    char *pcVar15;
    undefined *puVar16;
    int64_t iVar17;
    uint8_t uVar18;
    uint8_t uVar19;
    int64_t *piVar20;
    uint32_t uVar21;
    uint64_t uVar22;
    undefined *puVar23;
    uint64_t *puVar24;
    uint64_t uVar25;
    int64_t **ppiVar26;
    uint64_t *puVar27;
    int32_t iVar28;
    int64_t *piVar29;
    int64_t *piVar30;
    uint64_t uVar31;
    uint64_t *puVar32;
    int64_t *in_R10;
    int64_t *in_R11;
    int64_t **ppiVar33;
    int64_t *piVar34;
    uint64_t *puVar35;
    bool bVar36;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_118 [8];
    undefined auStack_110 [24];
    int64_t var_f8h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    uint32_t var_78h;
    int64_t var_74h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    if (*(char *)0x180778520 != '\0') {
        *(int64_t *)(arg1 + 0x628) = arg2;
    }
    var_74h._0_4_ = *(undefined4 *)(arg1 + 0x60c);
    bVar36 = *(int64_t *)(arg2 + 0x50) != 0;
    var_18h = arg3;
    var_60h = arg1;
    var_58h._0_4_ = (undefined4)var_74h;
    var_78h = func_0x0001800ce650(*(undefined8 *)arg1, bVar36 + *(char *)(arg2 + 0x60), *(undefined *)(arg2 + 0x70));
    if (0 < *(int32_t *)(arg1 + 0xc)) {
        *(int32_t *)(*(int64_t *)arg1 + 0x270) = *(int32_t *)(arg2 + 0xc) + 1;
    }
    if (*(char *)(arg2 + 0x70) != '\0') {
        iVar17 = *(int64_t *)arg1;
        var_8h = CONCAT44(var_8h._4_4_, (uint32_t)(uint8_t)(bVar36 + *(char *)(arg2 + 0x60)) << 8) | 0x41;
        fcn.1800d31a0(iVar17 + 0x28, &var_8h);
        fcn.1800d31a0(iVar17 + 0x40, iVar17 + 0x270);
    }
    iVar28 = (uint32_t)bVar36 + *(int32_t *)(arg2 + 0x60);
    iVar13 = *(int32_t *)(arg1 + 0x60c);
    uVar21 = iVar28 + iVar13;
    if (0xff < uVar21) {
        fcn.1800acea0((int32_t *)(arg2 + 0xc), 0x18063fbc0, iVar28, 0xff);
        pcVar8 = (code *)swi(3);
        uVar25 = (*pcVar8)();
        return uVar25;
    }
    *(uint32_t *)(arg1 + 0x60c) = uVar21;
    uVar14 = *(uint32_t *)(arg1 + 0x610);
    if (*(uint32_t *)(arg1 + 0x610) < uVar21) {
        uVar14 = uVar21;
    }
    *(uint32_t *)(arg1 + 0x610) = uVar14;
    puVar3 = *(undefined8 **)(arg2 + 0x50);
    cVar9 = (char)iVar13;
    if (puVar3 != (undefined8 *)0x0) {
        var_8h = (int64_t)puVar3;
        if (199 < (uint64_t)(*(int64_t *)(arg1 + 0x648) - *(int64_t *)(arg1 + 0x640) >> 3)) {
            fcn.1800acea0(puVar3 + 1, 0x18063fb70, *puVar3, 200);
            pcVar8 = (code *)swi(3);
            uVar25 = (*pcVar8)();
            return uVar25;
        }
        fcn.1800bf890((int64_t *)(arg1 + 0x640), &var_8h);
        pcVar15 = (char *)fcn.1800c0050(arg1 + 0x88, &var_8h);
        *pcVar15 = cVar9;
        pcVar15[1] = '\x01';
        uVar12 = (undefined4)(*(int64_t *)(*(int64_t *)arg1 + 0x30) - *(int64_t *)(*(int64_t *)arg1 + 0x28) >> 2);
        *(undefined4 *)(pcVar15 + 4) = uVar12;
        *(undefined4 *)(pcVar15 + 8) = uVar12;
    }
    uVar25 = 0;
    if (*(int64_t *)(arg2 + 0x60) != 0) {
        do {
            var_8h = *(int64_t *)(*(int64_t *)(arg2 + 0x58) + uVar25 * 8);
            if (199 < (uint64_t)(*(int64_t *)(arg1 + 0x648) - *(int64_t *)(arg1 + 0x640) >> 3)) {
                fcn.1800acea0((undefined8 *)(var_8h + 8), 0x18063fb70, *(undefined8 *)var_8h, 200);
                pcVar8 = (code *)swi(3);
                uVar25 = (*pcVar8)();
                return uVar25;
            }
            fcn.1800bf890(arg1 + 0x640, &var_8h);
            pcVar15 = (char *)fcn.1800c0050(arg1 + 0x88, &var_8h);
            *pcVar15 = cVar9 + (char)uVar25 + bVar36;
            pcVar15[1] = '\x01';
            uVar12 = (undefined4)(*(int64_t *)(*(int64_t *)arg1 + 0x30) - *(int64_t *)(*(int64_t *)arg1 + 0x28) >> 2);
            *(undefined4 *)(pcVar15 + 4) = uVar12;
            *(undefined4 *)(pcVar15 + 8) = uVar12;
            uVar25 = uVar25 + 1;
        } while (uVar25 < *(uint64_t *)(arg2 + 0x60));
    }
    piVar34 = (int64_t *)(arg1 + 0x640);
    *(int64_t *)(arg1 + 0x618) = *(int64_t *)(arg1 + 0x648) - *piVar34 >> 3;
    unique0x0000c280 = *(undefined8 **)(arg2 + 0x90);
    bVar36 = false;
    *(int64_t *)(arg1 + 0x628) = arg2;
    uVar25 = 0;
    if (unique0x0000c280[6] != 0) {
        do {
            func_0x0001800b7cc0(arg1, *(undefined8 *)(stack0xffffffffffffff90[5] + uVar25 * 8));
            cVar9 = func_0x0001800acb30(arg1 + 0x100);
            if (cVar9 != '\0') {
                bVar36 = true;
                break;
            }
            uVar25 = uVar25 + 1;
        } while (uVar25 < (uint64_t)stack0xffffffffffffff90[6]);
    }
    if (*(char *)0x180778520 == '\0') {
        if (!bVar36) {
            if (0 < *(int32_t *)(arg1 + 0xc)) {
                *(int32_t *)(*(int64_t *)arg1 + 0x270) = *(int32_t *)((int64_t)stack0xffffffffffffff90 + 0x14) + 1;
            }
code_r0x0001800ae17b:
            func_0x0001800bbb60(arg1, 0);
            iVar17 = *(int64_t *)arg1;
            var_8h = CONCAT44(var_8h._4_4_, 0x10016);
            fcn.1800d31a0(iVar17 + 0x28, &var_8h);
            fcn.1800d31a0(iVar17 + 0x40, iVar17 + 0x270);
        }
    } else {
        if (0 < *(int32_t *)(arg1 + 0xc)) {
            *(int32_t *)(*(int64_t *)arg1 + 0x270) = *(int32_t *)((int64_t)stack0xffffffffffffff90 + 0x14) + 1;
        }
        var_8h = *(int64_t *)(arg1 + 0x6d0);
        if ((((var_8h == *(int64_t *)(arg1 + 0x6d8)) && (*(int64_t *)(arg1 + 0x6f8) == 0)) ||
            (iVar17 = *(int64_t *)(arg1 + 0x628), iVar17 == 0)) ||
           (((*(int64_t *)(iVar17 + 0x98) != 0 || (*(int64_t *)(arg1 + 0x630) != 0)) ||
            (*(int64_t *)(arg1 + 0x688) != *(int64_t *)(arg1 + 0x690))))) {
            if (!bVar36) goto code_r0x0001800ae17b;
        } else {
            piVar20 = (int64_t *)(arg1 + 0x5c0);
            if ((*(int64_t *)(arg1 + 0x98) != 0) && (in_R10 = *(int64_t **)(arg1 + 0xa0), piVar20 != in_R10)) {
                uVar31 = *(int64_t *)(arg1 + 0x90) - 1;
                uVar25 = ((uint64_t)piVar20 >> 5 ^ (uint64_t)piVar20) >> 4;
                uVar22 = 0;
                in_R11 = *(int64_t **)(arg1 + 0x88);
                do {
                    uVar25 = uVar25 & uVar31;
                    if ((int64_t *)in_R11[uVar25 * 3] == piVar20) goto code_r0x0001800adbf2;
                    if ((int64_t *)in_R11[uVar25 * 3] == in_R10) break;
                    uVar25 = uVar25 + 1 + uVar22;
                    uVar22 = uVar22 + 1;
                } while (uVar22 <= uVar31);
            }
            uVar14 = *(uint32_t *)(arg1 + 0x60c);
            uVar21 = uVar14 + 1;
            if (0xff < uVar21) {
                fcn.1800acea0(iVar17 + 0xc, 0x18063fbc0, 1, 0xff);
                pcVar8 = (code *)swi(3);
                uVar25 = (*pcVar8)();
                return uVar25;
            }
            *(uint32_t *)(arg1 + 0x60c) = uVar21;
            uVar11 = *(uint32_t *)(arg1 + 0x610);
            if (*(uint32_t *)(arg1 + 0x610) < uVar21) {
                uVar11 = uVar21;
            }
            *(uint32_t *)(arg1 + 0x610) = uVar11;
            iVar17 = *(int64_t *)arg1;
            uVar21 = (int32_t)(*(int64_t *)(arg1 + 0x6d8) - var_8h >> 3) + *(int32_t *)(arg1 + 0x6f8);
            uVar18 = 0;
            uVar19 = 0;
            if (uVar21 < 2) {
                if (uVar21 != 0) goto code_r0x0001800adb44;
            } else {
                do {
                    uVar18 = uVar18 + 1;
                } while ((uint32_t)(1 << (uVar18 & 0x1f)) < uVar21);
code_r0x0001800adb44:
                uVar19 = uVar18 + 1;
            }
            var_8h._4_4_ = (undefined4)((uint64_t)var_8h >> 0x20);
            var_8h = CONCAT44(var_8h._4_4_, ((uint32_t)uVar19 << 8 | uVar14 & 0xff) << 8) | 0x35;
            fcn.1800d31a0(iVar17 + 0x28, &var_8h);
            fcn.1800d31a0(iVar17 + 0x40, iVar17 + 0x270);
            iVar17 = *(int64_t *)arg1;
            var_8h = var_8h & 0xffffffff00000000;
            fcn.1800d31a0(iVar17 + 0x28, &var_8h);
            fcn.1800d31a0(iVar17 + 0x40, iVar17 + 0x270);
            var_8h = (int64_t)piVar20;
            if (199 < (uint64_t)(*(int64_t *)(arg1 + 0x648) - *piVar34 >> 3)) {
                fcn.1800acea0(arg1 + 0x5c8, 0x18063fb70, *piVar20, 200);
                pcVar8 = (code *)swi(3);
                uVar25 = (*pcVar8)();
                return uVar25;
            }
            fcn.1800bf890(piVar34, &var_8h);
            puVar16 = (undefined *)fcn.1800c0050(arg1 + 0x88, &var_8h);
            *puVar16 = (char)uVar14;
            puVar16[1] = 1;
            uVar12 = (undefined4)(*(int64_t *)(*(int64_t *)arg1 + 0x30) - *(int64_t *)(*(int64_t *)arg1 + 0x28) >> 2);
            *(undefined4 *)(puVar16 + 4) = uVar12;
            *(undefined4 *)(puVar16 + 8) = uVar12;
code_r0x0001800adbf2:
            iVar17 = *(int64_t *)(arg1 + 0x628);
            var_68h = iVar17;
            uVar12 = fcn.1800acf70(arg1, piVar20);
            var_8h = CONCAT44(var_8h._4_4_, uVar12);
            if (*(char *)0x180778560 != '\0') {
                uVar25 = 0;
                var_a0h = *(uint64_t *)(arg1 + 0x6f0);
                if (var_a0h != 0) {
                    do {
                        if (*(int64_t *)(*(int64_t *)(arg1 + 0x6e8) + uVar25 * 0x10) != *(int64_t *)(arg1 + 0x700))
                        break;
                        uVar25 = uVar25 + 1;
                    } while (uVar25 < (uint64_t)var_a0h);
                }
code_r0x0001800adc54:
                iVar17 = var_68h;
                if (uVar25 != var_a0h) {
                    ppiVar33 = (int64_t **)(uVar25 * 0x10 + *(int64_t *)(arg1 + 0x6e8));
                    iVar17 = **ppiVar33;
                    uVar22 = func_0x000180498cd0(iVar17);
                    uVar4 = *(undefined8 *)arg1;
                    var_e8h = iVar17;
                    var_e0h = uVar22;
                    var_c0h._0_4_ = func_0x0001800cf010(uVar4, &var_e8h);
                    var_90h._0_4_ = 5;
                    stack0xffffffffffffff7c = SUB1612(ZEXT816(0), 4);
                    var_88h._0_4_ = (uint32_t)var_c0h;
                    var_c8h = CONCAT44(var_c8h._4_4_, 5);
                    var_c0h._4_4_ = 0;
                    var_b8h._0_4_ = 0;
                    var_b8h._4_4_ = 0;
                    iVar13 = func_0x0001800ced20(uVar4, &var_c8h, &var_90h);
                    var_20h = CONCAT44(var_20h._4_4_, iVar13);
                    if (iVar13 < 0) goto code_r0x0001800aeb55;
                    iVar5 = *(int64_t *)arg1;
                    uVar31 = uVar22;
                    for (; uVar21 = (uint32_t)uVar31, uVar22 != 0; uVar22 = uVar22 - 1) {
                        uVar31 = (uint64_t)
                                 (uVar21 ^ (uint32_t)*(uint8_t *)(iVar17 + -1 + uVar22) + uVar21 * 0x20 +
                                           ((uint32_t)(uVar31 >> 2) & 0x3fffffff));
                    }
                    var_10h = CONCAT44(var_10h._4_4_, 
                                       (((uVar21 & 0xff) << 8 | (uint32_t)(uint8_t)var_8h) << 8 |
                                       (uint32_t)*(uint8_t *)(ppiVar33 + 1)) << 8) | 0x10;
                    fcn.1800d31a0(iVar5 + 0x28, &var_10h);
                    fcn.1800d31a0(iVar5 + 0x40, iVar5 + 0x270);
                    iVar17 = *(int64_t *)arg1;
                    var_10h = CONCAT44(var_10h._4_4_, (undefined4)var_20h);
                    fcn.1800d31a0(iVar17 + 0x28, &var_10h);
                    fcn.1800d31a0(iVar17 + 0x40, iVar17 + 0x270);
                    do {
                        uVar25 = uVar25 + 1;
                        if (*(uint64_t *)(arg1 + 0x6f0) <= uVar25) break;
                    } while (*(int64_t *)(*(int64_t *)(arg1 + 0x6e8) + uVar25 * 0x10) == *(int64_t *)(arg1 + 0x700));
                    goto code_r0x0001800adc54;
                }
            }
            var_10h = CONCAT44(var_10h._4_4_, *(int32_t *)(arg1 + 0x60c));
            uVar21 = *(int32_t *)(arg1 + 0x60c) + 2;
            if (0xff < uVar21) {
                fcn.1800acea0(iVar17 + 0xc, 0x18063fbc0, 2, 0xff);
                pcVar8 = (code *)swi(3);
                uVar25 = (*pcVar8)();
                return uVar25;
            }
            *(uint32_t *)(arg1 + 0x60c) = uVar21;
            uVar14 = *(uint32_t *)(arg1 + 0x610);
            if (*(uint32_t *)(arg1 + 0x610) < uVar21) {
                uVar14 = uVar21;
            }
            *(uint32_t *)(arg1 + 0x610) = uVar14;
            iVar17 = *(int64_t *)(arg1 + 0x5b8);
            var_a0h = 0x18063c3b0;
            var_98h = 6;
            ppiVar33 = (int64_t **)func_0x0001800d8c20(iVar17, &var_a0h);
            if (*(int32_t *)((int64_t)ppiVar33 + 0xc) == 0) {
                ppiVar26 = *(int64_t ***)(iVar17 + 0x30);
                iVar17 = (int64_t)*ppiVar26;
                if (iVar17 == 0) {
code_r0x0001800ade54:
                    piVar34 = (int64_t *)fcn.180459890(0x2008);
                    *piVar34 = (int64_t)*ppiVar26;
                    *ppiVar26 = piVar34;
                    piVar34 = piVar34 + 1;
                    piVar20 = (int64_t *)0x7;
                } else {
                    piVar34 = (int64_t *)((int64_t)ppiVar26[1] + iVar17 + 0xf & 0xfffffffffffffff8);
                    if (iVar17 + 0x2008U < (int64_t)piVar34 + 7U) goto code_r0x0001800ade54;
                    piVar20 = (int64_t *)((int64_t)piVar34 + (7 - (iVar17 + 8)));
                }
                ppiVar26[1] = piVar20;
                *(undefined4 *)piVar34 = 0x65657266;
                *(undefined2 *)((int64_t)piVar34 + 4) = 0x657a;
                *(undefined *)((int64_t)piVar34 + 6) = 0;
                *ppiVar33 = piVar34;
                *(undefined4 *)((int64_t)ppiVar33 + 0xc) = 0x119;
            } else {
                piVar34 = *ppiVar33;
            }
            uVar4 = *(undefined8 *)arg1;
            var_e0h = func_0x000180498cd0(piVar34);
            var_e8h = (int64_t)piVar34;
            var_c0h._0_4_ = func_0x0001800cf010(uVar4, &var_e8h);
            var_c8h = CONCAT44(var_c8h._4_4_, 5);
            var_b8h._4_4_ = 0;
            var_c0h._4_4_ = 0;
            var_b8h._0_4_ = 0;
            var_90h._0_4_ = 5;
            _var_88h = ZEXT416((uint32_t)var_c0h);
            uVar21 = func_0x0001800ced20(uVar4, &var_90h, &var_c8h);
            if ((int32_t)uVar21 < 0) goto code_r0x0001800aeb55;
            iVar17 = *(int64_t *)(arg1 + 0x5b8);
            var_a0h = 0x180622fb4;
            var_98h = 5;
            ppiVar33 = (int64_t **)func_0x0001800d8c20(iVar17, &var_a0h);
            if (*(int32_t *)((int64_t)ppiVar33 + 0xc) == 0) {
                ppiVar26 = *(int64_t ***)(iVar17 + 0x30);
                iVar17 = (int64_t)*ppiVar26;
                if (iVar17 == 0) {
code_r0x0001800adf78:
                    piVar34 = (int64_t *)fcn.180459890(0x2008);
                    *piVar34 = (int64_t)*ppiVar26;
                    *ppiVar26 = piVar34;
                    piVar34 = piVar34 + 1;
                    piVar20 = (int64_t *)0x6;
                } else {
                    piVar34 = (int64_t *)((int64_t)ppiVar26[1] + iVar17 + 0xf & 0xfffffffffffffff8);
                    if (iVar17 + 0x2008U < (int64_t)piVar34 + 6U) goto code_r0x0001800adf78;
                    piVar20 = (int64_t *)((int64_t)piVar34 + (6 - (iVar17 + 8)));
                }
                ppiVar26[1] = piVar20;
                *(undefined4 *)piVar34 = 0x6c626174;
                *(undefined *)((int64_t)piVar34 + 4) = 0x65;
                *(undefined *)((int64_t)piVar34 + 5) = 0;
                *ppiVar33 = piVar34;
                *(undefined4 *)((int64_t)ppiVar33 + 0xc) = 0x119;
            } else {
                piVar34 = *ppiVar33;
            }
            uVar4 = *(undefined8 *)arg1;
            var_e0h = func_0x000180498cd0(piVar34);
            var_e8h = (int64_t)piVar34;
            var_c0h._0_4_ = func_0x0001800cf010(uVar4, &var_e8h);
            var_c8h = CONCAT44(var_c8h._4_4_, 5);
            var_b8h._4_4_ = 0;
            var_c0h._4_4_ = 0;
            var_b8h._0_4_ = 0;
            var_90h._0_4_ = 5;
            _var_88h = ZEXT416((uint32_t)var_c0h);
            iVar13 = func_0x0001800ced20(uVar4, &var_90h, &var_c8h);
            if (iVar13 < 0) {
code_r0x0001800aeb55:
                fcn.1800acea0(var_68h + 0xc, 0x18063f5a0);
code_r0x0001800aeb6a:
                fcn.1800acea0(in_R10 + 1, 0x18063f720, *in_R10, 200);
                pcVar8 = (code *)swi(3);
                uVar25 = (*pcVar8)();
                return uVar25;
            }
            uVar21 = (iVar13 << 10 | uVar21) << 10;
            var_c0h._0_4_ = uVar21 | 0x80000000;
            var_c8h = CONCAT44(var_c8h._4_4_, 6);
            var_b8h._4_4_ = 0;
            var_c0h._4_4_ = 0;
            var_b8h._0_4_ = 0;
            var_90h._0_4_ = 6;
            _var_88h = ZEXT416((uint32_t)var_c0h);
            uVar14 = func_0x0001800ced20(*(undefined8 *)arg1, &var_90h, &var_c8h);
            if (0x7fff < uVar14) goto code_r0x0001800aeb55;
            uVar18 = (uint8_t)var_10h;
            iVar17 = *(int64_t *)arg1;
            var_10h = CONCAT44(var_10h._4_4_, ((uVar14 & 0xffff) << 8 | (uint32_t)(uint8_t)var_10h) << 8) | 0xc;
            fcn.1800d31a0(iVar17 + 0x28, &var_10h);
            fcn.1800d31a0(iVar17 + 0x40, iVar17 + 0x270);
            iVar17 = *(int64_t *)arg1;
            var_10h = CONCAT44(var_10h._4_4_, uVar21) | 0x80000000;
            fcn.1800d31a0(iVar17 + 0x28, &var_10h);
            fcn.1800d31a0(iVar17 + 0x40, iVar17 + 0x270);
            iVar17 = *(int64_t *)arg1;
            var_8h = CONCAT44(var_8h._4_4_, ((uint32_t)(uint8_t)var_8h << 8 | uVar18 + 1 & 0xff) << 8) | 6;
            fcn.1800d31a0(iVar17 + 0x28, &var_8h);
            fcn.1800d31a0(iVar17 + 0x40, iVar17 + 0x270);
            iVar17 = *(int64_t *)arg1;
            iVar13 = (uint32_t)uVar18 << 8;
            var_8h = CONCAT44(var_8h._4_4_, iVar13) | 0x2020015;
            fcn.1800d31a0(iVar17 + 0x28, &var_8h);
            fcn.1800d31a0(iVar17 + 0x40, iVar17 + 0x270);
            func_0x0001800bbb60(arg1, 0);
            iVar17 = *(int64_t *)arg1;
            var_8h = CONCAT44(var_8h._4_4_, iVar13) | 0x20016;
            fcn.1800d31a0(iVar17 + 0x28, &var_8h);
            fcn.1800d31a0(iVar17 + 0x40, iVar17 + 0x270);
        }
    }
    piVar34 = (int64_t *)0x0;
    var_c0h = CONCAT44(var_c0h._4_4_, (uint32_t)var_c0h);
    if ((*(int32_t *)(arg1 + 8) < 1) ||
       (var_c0h = CONCAT44(var_c0h._4_4_, (uint32_t)var_c0h), *(int32_t *)(arg1 + 0xc) < 2)) {
code_r0x0001800ae34f:
        *(int32_t *)((uint64_t)*(uint32_t *)(*(int64_t **)arg1 + 3) * 0xa8 + 0x28 + **(int64_t **)arg1) =
             *(int32_t *)(arg2 + 0xc) + 1;
        if ((0 < *(int32_t *)(arg1 + 0xc)) && (iVar17 = *(int64_t *)(arg2 + 0xa0), iVar17 != 0)) {
            var_e0h = func_0x000180498cd0(iVar17);
            var_e8h = iVar17;
            func_0x0001800d04f0(*(undefined8 *)arg1, &var_e8h);
        }
        if (1 < *(int32_t *)(arg1 + 0xc)) {
            ppiVar26 = *(int64_t ***)(arg1 + 0x660);
            for (ppiVar33 = *(int64_t ***)(arg1 + 0x658); ppiVar33 != ppiVar26; ppiVar33 = ppiVar33 + 1) {
                iVar17 = **ppiVar33;
                var_e0h = func_0x000180498cd0(iVar17);
                var_e8h = iVar17;
                func_0x0001800d0820(*(undefined8 *)arg1, &var_e8h);
            }
        }
        if (0 < *(int32_t *)(arg1 + 0x10)) {
            puVar24 = *(uint64_t **)(arg1 + 0x660);
            for (puVar27 = *(uint64_t **)(arg1 + 0x658); puVar27 != puVar24; puVar27 = puVar27 + 1) {
                uVar12 = 0xf;
                if (*(int64_t *)(arg1 + 0x228) != 0) {
                    uVar25 = *puVar27;
                    if (uVar25 != *(uint64_t *)(arg1 + 0x230)) {
                        piVar29 = (int64_t *)(*(int64_t *)(arg1 + 0x220) + -1);
                        puVar16 = (undefined *)((uVar25 >> 5 ^ uVar25) >> 4);
                        piVar20 = piVar34;
                        do {
                            uVar31 = (uint64_t)puVar16 & (uint64_t)piVar29;
                            puVar32 = (uint64_t *)(uVar31 * 0x10 + *(int64_t *)(arg1 + 0x218));
                            uVar22 = *puVar32;
                            if (uVar22 == uVar25) {
                                puVar32 = puVar32 + 1;
                                if (puVar32 != (uint64_t *)0x0) {
                                    uVar12 = *(undefined4 *)puVar32;
                                }
                                break;
                            }
                            if (uVar22 == *(uint64_t *)(arg1 + 0x230)) break;
                            puVar16 = (undefined *)(uVar31 + 1 + (int64_t)piVar20);
                            piVar20 = (int64_t *)((int64_t)piVar20 + 1);
                        } while (piVar20 <= piVar29);
                    }
                }
                func_0x0001800d0310(*(undefined8 *)arg1, uVar12);
            }
        }
        if (0 < *(int32_t *)(arg1 + 8)) {
            func_0x0001800d22e0(*(undefined8 *)arg1);
        }
        func_0x0001800d23c0(*(undefined8 *)arg1);
        func_0x0001800bbc30(arg1, 0);
        if (1000000000 < (uint64_t)(*(int64_t *)(*(int64_t *)arg1 + 0x30) - *(int64_t *)(*(int64_t *)arg1 + 0x28) >> 2))
        {
            fcn.1800acea0(arg2 + 0xc, 0x18063f7a0);
            pcVar8 = (code *)swi(3);
            uVar25 = (*pcVar8)();
            return uVar25;
        }
        piVar20 = piVar34;
        if ((*(int64_t *)(arg1 + 0x200) != 0) && (arg2 != *(int64_t *)(arg1 + 0x208))) {
            piVar30 = (int64_t *)(*(int64_t *)(arg1 + 0x1f8) + -1);
            puVar16 = (undefined *)(((uint64_t)arg2 >> 5 ^ arg2) >> 4);
            piVar29 = piVar34;
            do {
                uVar25 = (uint64_t)puVar16 & (uint64_t)piVar30;
                piVar2 = (int64_t *)(*(int64_t *)(arg1 + 0x1f0) + uVar25 * 0x28);
                iVar17 = *piVar2;
                if (iVar17 == arg2) {
                    piVar20 = piVar2 + 1;
                    break;
                }
                if (iVar17 == *(int64_t *)(arg1 + 0x208)) break;
                puVar16 = (undefined *)(uVar25 + 1 + (int64_t)piVar29);
                piVar29 = (int64_t *)((int64_t)piVar29 + 1);
            } while (piVar29 <= piVar30);
        }
        if (piVar20 != (int64_t *)0x0) {
            piVar29 = *(int64_t **)arg1;
            var_c8h = *piVar20;
            var_c0h._0_4_ = *(uint32_t *)(piVar20 + 1);
            var_c0h._4_4_ = *(undefined4 *)((int64_t)piVar20 + 0xc);
            var_b8h._0_4_ = *(undefined4 *)(piVar20 + 2);
            var_b8h._4_4_ = *(undefined4 *)((int64_t)piVar20 + 0x14);
            var_b0h._0_4_ = *(undefined4 *)(piVar20 + 3);
            var_b0h._4_4_ = *(undefined4 *)((int64_t)piVar20 + 0x1c);
            piVar20[2] = 0;
            piVar20[3] = 0xf;
            *(undefined *)piVar20 = 0;
            func_0x000180012c10((uint64_t)*(uint32_t *)(piVar29 + 3) * 0xa8 + *piVar29 + 0x88, &var_c8h);
            func_0x000180004e40(&var_c8h);
        }
        if ((*(int64_t *)(arg2 + 0x98) == 0) && (*(char *)(arg1 + 0x620) == '\0')) {
            *(uint8_t *)var_18h = *(uint8_t *)var_18h | 2;
        }
        piVar29 = *(int64_t **)(arg2 + 0x20);
        piVar20 = piVar29 + *(int64_t *)(arg2 + 0x28);
        for (; piVar29 != piVar20; piVar29 = piVar29 + 1) {
            if (*(int32_t *)(*piVar29 + 0x20) == 1) {
                *(uint8_t *)var_18h = *(uint8_t *)var_18h | 4;
                break;
            }
        }
        uVar18 = *(uint8_t *)var_18h;
        if (((*(char *)(arg2 + 0x70) == '\0') && (*(char *)(arg1 + 0x638) == '\0')) && (*(char *)(arg1 + 0x639) == '\0')
           ) {
            bVar36 = true;
        } else {
            bVar36 = false;
            uVar18 = *(uint8_t *)var_18h;
        }
        if (((*(char *)0x180777e98 != '\0') && (bVar36)) && (*(int64_t *)(arg1 + 0x658) == *(int64_t *)(arg1 + 0x660)))
        {
            *(uint8_t *)var_18h = uVar18 | 8;
        }
        func_0x0001800ce9d0(*(undefined8 *)arg1, *(undefined *)(arg1 + 0x610), 
                            (int64_t)(uint64_t)(uint32_t)(*(int32_t *)(arg1 + 0x660) - *(int32_t *)(arg1 + 0x658)) >> 3)
        ;
        puVar16 = auStack_118;
        if (*(uint64_t *)(arg1 + 0x70) < (uint64_t)(*(int64_t *)(arg1 + 0x68) * 3) >> 2) goto code_r0x0001800ae8fe;
        if ((*(uint64_t *)(arg1 + 0x70) != 0) && (arg2 != *(int64_t *)(arg1 + 0x78))) {
            piVar29 = (int64_t *)(*(int64_t *)(arg1 + 0x68) + -1);
            puVar16 = (undefined *)(((uint64_t)arg2 >> 5 ^ arg2) >> 4);
            piVar20 = piVar34;
            do {
                uVar25 = (uint64_t)puVar16 & (uint64_t)piVar29;
                iVar17 = *(int64_t *)(uVar25 * 0x38 + *(int64_t *)(arg1 + 0x60));
                puVar16 = auStack_118;
                if (iVar17 == arg2) goto code_r0x0001800ae8fe;
                if (iVar17 == *(int64_t *)(arg1 + 0x78)) break;
                puVar16 = (undefined *)(uVar25 + 1 + (int64_t)piVar20);
                piVar20 = (int64_t *)((int64_t)piVar20 + 1);
            } while (piVar20 <= piVar29);
        }
        iVar17 = *(int64_t *)(arg1 + 0x68);
        uVar25 = *(uint64_t *)(arg1 + 0x78);
        piVar20 = piVar34;
        var_20h = uVar25;
        if (iVar17 == 0) {
            piVar29 = (int64_t *)0x10;
            piVar30 = (int64_t *)fcn.180459890(0x380);
            var_10h = 0x10;
            in_R10 = piVar30;
            in_R11 = (int64_t *)0x10;
            var_8h = (int64_t)piVar30;
code_r0x0001800ae724:
            do {
                piVar30[(int64_t)piVar20 * 7] = *(int64_t *)(arg1 + 0x78);
                piVar30[(int64_t)piVar20 * 7 + 1] = 0;
                piVar30[(int64_t)piVar20 * 7 + 6] = 0;
                piVar30[(int64_t)piVar20 * 7 + 2] = 0;
                piVar30[(int64_t)piVar20 * 7 + 3] = 0;
                piVar30[(int64_t)piVar20 * 7 + 4] = 0;
                piVar30[(int64_t)piVar20 * 7 + 5] = 0;
                piVar20 = (int64_t *)((int64_t)piVar20 + 1);
            } while (piVar20 < piVar29);
        } else {
            piVar29 = (int64_t *)(iVar17 * 2);
            if (piVar29 == (int64_t *)0x0) {
                var_10h = 0;
                var_8h = 0;
                in_R10 = piVar34;
                in_R11 = piVar34;
            } else {
                piVar30 = (int64_t *)fcn.180459890(iVar17 * 0x70);
                in_R10 = piVar30;
                in_R11 = piVar29;
                var_8h = (int64_t)piVar30;
                var_10h = (int64_t)piVar29;
                if (piVar29 != (int64_t *)0x0) goto code_r0x0001800ae724;
            }
        }
        puVar16 = auStack_118;
        if (*(int64_t *)(arg1 + 0x68) != 0) {
            do {
                uVar22 = *(uint64_t *)((int64_t)piVar34 * 0x38 + *(int64_t *)(arg1 + 0x60));
                if (uVar22 != *(uint64_t *)(arg1 + 0x78)) {
                    puVar16 = (undefined *)((uVar22 >> 5 ^ uVar22) >> 4);
                    puVar23 = (undefined *)0x0;
                    do {
                        uVar31 = (uint64_t)puVar16 & (uint64_t)(undefined *)((int64_t)in_R11 + -1);
                        puVar24 = (uint64_t *)(in_R10 + uVar31 * 7);
                        if (*puVar24 == uVar25) {
                            *puVar24 = uVar22;
                            goto code_r0x0001800ae7e0;
                        }
                        if (*puVar24 == uVar22) goto code_r0x0001800ae7e0;
                        puVar16 = puVar23 + uVar31 + 1;
                        puVar23 = puVar23 + 1;
                    } while (puVar23 <= (undefined *)((int64_t)in_R11 + -1));
                    puVar24 = (uint64_t *)0x0;
code_r0x0001800ae7e0:
                    puVar35 = (uint64_t *)((int64_t)piVar34 * 0x38 + *(int64_t *)(arg1 + 0x60));
                    *puVar24 = *puVar35;
                    *(undefined4 *)(puVar24 + 1) = *(undefined4 *)(puVar35 + 1);
                    puVar27 = puVar35 + 2;
                    puVar32 = puVar24 + 2;
                    if (puVar32 != puVar27) {
                        uVar25 = *puVar32;
                        if (uVar25 != 0) {
                            uVar22 = uVar25;
                            if ((0xfff < (uint64_t)(((int64_t)(puVar24[4] - uVar25) >> 3) * 8)) &&
                               (uVar22 = *(uint64_t *)(uVar25 - 8), 0x1f < (uVar25 - uVar22) - 8))
                            goto code_r0x0001800ae8b7;
                            fcn.180459c3c(uVar22);
                            *puVar32 = 0;
                            puVar24[3] = 0;
                            puVar24[4] = 0;
                            in_R10 = (int64_t *)var_8h;
                            in_R11 = (int64_t *)var_10h;
                        }
                        *puVar32 = *puVar27;
                        puVar24[3] = puVar35[3];
                        puVar24[4] = puVar35[4];
                        *puVar27 = 0;
                        puVar35[3] = 0;
                        puVar35[4] = 0;
                    }
                    puVar24[5] = puVar35[5];
                    *(undefined4 *)(puVar24 + 6) = *(undefined4 *)(puVar35 + 6);
                    *(undefined *)((int64_t)puVar24 + 0x34) = *(undefined *)((int64_t)puVar35 + 0x34);
                    *(undefined *)((int64_t)puVar24 + 0x35) = *(undefined *)((int64_t)puVar35 + 0x35);
                }
                piVar34 = (int64_t *)((int64_t)piVar34 + 1);
                puVar16 = auStack_118;
                uVar25 = var_20h;
            } while (piVar34 < *(int64_t **)(arg1 + 0x68));
        }
    } else {
        var_c8h = 0x18063fd48;
        var_b8h._0_4_ = 0;
        var_b8h._4_4_ = 0;
        var_b0h._0_4_ = 0;
        var_b0h._4_4_ = 0;
        var_a8h = 0;
        var_c0h = arg1;
        (**(code **)**(undefined8 **)(arg2 + 0x90))(*(undefined8 **)(arg2 + 0x90), &var_c8h);
        ppiVar33 = (int64_t **)CONCAT44(var_b8h._4_4_, (undefined4)var_b8h);
        ppiVar26 = (int64_t **)CONCAT44(var_b0h._4_4_, (undefined4)var_b0h);
        if (ppiVar33 != ppiVar26) {
            do {
                in_R10 = *ppiVar33;
                iVar17 = *(int64_t *)(arg1 + 0x660);
                iVar5 = *(int64_t *)(arg1 + 0x658);
                piVar20 = piVar34;
                var_8h = (int64_t)in_R10;
                if (iVar17 - iVar5 >> 3 != 0) {
                    do {
                        if (*(int64_t **)(iVar5 + (int64_t)piVar20 * 8) == in_R10) goto code_r0x0001800ae2f9;
                        piVar20 = (int64_t *)((int64_t)piVar20 + 1);
                    } while (piVar20 < (int64_t *)(iVar17 - iVar5 >> 3));
                }
                if (199 < (uint64_t)(iVar17 - iVar5 >> 3)) goto code_r0x0001800aeb6a;
                if ((*(int64_t *)(arg1 + 0xe8) != 0) && (in_R11 = *(int64_t **)(arg1 + 0xf0), in_R10 != in_R11)) {
                    piVar29 = (int64_t *)(*(int64_t *)(arg1 + 0xe0) + -1);
                    puVar16 = (undefined *)(((uint64_t)in_R10 >> 5 ^ (uint64_t)in_R10) >> 4);
                    piVar20 = piVar34;
                    do {
                        uVar25 = (uint64_t)puVar16 & (uint64_t)piVar29;
                        ppiVar1 = (int64_t **)(*(int64_t *)(arg1 + 0xd8) + uVar25 * 0x18);
                        if (*ppiVar1 == in_R10) {
                            if ((ppiVar1 != (int64_t **)0xfffffffffffffff8) && (*(char *)(ppiVar1 + 2) != '\0')) {
                                iVar17 = fcn.1800c0050(arg1 + 0x88, &var_8h);
                                *(undefined *)(iVar17 + 2) = 1;
                            }
                            break;
                        }
                        if (*ppiVar1 == in_R11) break;
                        puVar16 = (undefined *)(uVar25 + 1 + (int64_t)piVar20);
                        piVar20 = (int64_t *)((int64_t)piVar20 + 1);
                    } while (piVar20 <= piVar29);
                }
                fcn.1800bf890(arg1 + 0x658, &var_8h);
code_r0x0001800ae2f9:
                ppiVar33 = ppiVar33 + 1;
            } while (ppiVar33 != ppiVar26);
            ppiVar33 = (int64_t **)CONCAT44(var_b8h._4_4_, (undefined4)var_b8h);
        }
        if (ppiVar33 == (int64_t **)0x0) goto code_r0x0001800ae34f;
        uVar25 = (var_a8h - (int64_t)ppiVar33 >> 3) * 8;
        ppiVar26 = ppiVar33;
        if (uVar25 < 0x1000) {
code_r0x0001800ae347:
            fcn.180459c3c(ppiVar26, uVar25);
            goto code_r0x0001800ae34f;
        }
        ppiVar26 = (int64_t **)ppiVar33[-1];
        if ((uint64_t)((int64_t)ppiVar33 + (-8 - (int64_t)ppiVar26)) < 0x20) {
            uVar25 = uVar25 + 0x27;
            goto code_r0x0001800ae347;
        }
code_r0x0001800ae8b7:
        pcVar8 = (code *)swi(0x29);
        (*pcVar8)(5);
        puVar16 = auStack_110;
    }
    iVar17 = *(int64_t *)(arg1 + 0x60);
    *(int64_t **)(arg1 + 0x60) = in_R10;
    uVar25 = *(uint64_t *)(arg1 + 0x68);
    *(int64_t **)(arg1 + 0x68) = in_R11;
    uVar22 = 0;
    if (iVar17 != 0) {
        if (uVar25 != 0) {
            do {
                *(undefined8 *)(puVar16 + -8) = 0x1800ae8ee;
                func_0x00018000ace0(uVar22 * 0x38 + iVar17 + 0x10);
                uVar22 = uVar22 + 1;
            } while (uVar22 < uVar25);
        }
        *(undefined8 *)(puVar16 + -8) = 0x1800ae8fe;
        func_0x0001800f4640(iVar17);
    }
code_r0x0001800ae8fe:
    uVar21 = var_78h;
    piVar20 = (int64_t *)(*(int64_t *)(arg1 + 0x68) + -1);
    uVar25 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
    piVar34 = (int64_t *)0x0;
    do {
        uVar25 = uVar25 & (uint64_t)piVar20;
        piVar29 = (int64_t *)(uVar25 * 0x38 + *(int64_t *)(arg1 + 0x60));
        if (*piVar29 == *(int64_t *)(arg1 + 0x78)) {
            *piVar29 = arg2;
            *(int64_t *)(arg1 + 0x70) = *(int64_t *)(arg1 + 0x70) + 1;
            break;
        }
        if (*piVar29 == arg2) break;
        uVar25 = uVar25 + 1 + (int64_t)piVar34;
        piVar34 = (int64_t *)((int64_t)piVar34 + 1);
        piVar29 = (int64_t *)0x0;
    } while (piVar34 <= piVar20);
    *(uint32_t *)(piVar29 + 1) = var_78h;
    *(undefined8 *)(puVar16 + -8) = 0x1800ae96a;
    func_0x0001800c0fd0(piVar29 + 2, arg1 + 0x658);
    if ((((1 < *(int32_t *)(arg1 + 8)) && (*(char *)(arg2 + 0x70) == '\0')) && (*(int64_t *)(arg2 + 0x50) == 0)) &&
       ((*(char *)(arg1 + 0x638) == '\0' && (*(char *)(arg1 + 0x639) == '\0')))) {
        if (*(char *)0x180778540 != '\0') {
            piVar20 = *(int64_t **)(arg2 + 0x20);
            piVar34 = piVar20 + *(int64_t *)(arg2 + 0x28);
            for (; piVar20 != piVar34; piVar20 = piVar20 + 1) {
                if (*(int32_t *)(*piVar20 + 0x20) == 3) {
                    uVar10 = 0;
                    goto code_r0x0001800ae9d8;
                }
            }
        }
        uVar10 = 1;
code_r0x0001800ae9d8:
        *(undefined *)((int64_t)piVar29 + 0x34) = uVar10;
        *(undefined4 *)(piVar29 + 6) = *(undefined4 *)(arg1 + 0x610);
        *(int64_t *)(puVar16 + 0x20) = arg1 + 0x100;
        uVar4 = *(undefined8 *)(arg2 + 0x60);
        uVar6 = *(undefined8 *)(arg2 + 0x58);
        uVar7 = *(undefined8 *)(arg2 + 0x90);
        *(undefined8 *)(puVar16 + -8) = 0x1800aea0b;
        iVar17 = func_0x0001800c92c0(uVar7, uVar6, uVar4, arg1 + 0x1a0);
        piVar29[5] = iVar17;
        uVar4 = *(undefined8 *)(arg2 + 0x90);
        *(undefined8 *)(puVar16 + -8) = 0x1800aea1e;
        cVar9 = func_0x0001800acb30(arg1 + 0x100, uVar4);
        if (cVar9 != '\0') {
            *(undefined8 *)(puVar16 + 0x30) = 0x1806403a8;
            *(int64_t *)(puVar16 + 0x38) = arg1;
            var_d8h._0_1_ = 1;
            pcVar8 = *(code **)*stack0xffffffffffffff90;
            *(undefined8 *)(puVar16 + -8) = 0x1800aea45;
            (*pcVar8)(stack0xffffffffffffff90, puVar16 + 0x30);
            *(undefined *)((int64_t)piVar29 + 0x35) = (undefined)var_d8h;
        }
    }
    if (*(int64_t *)(arg1 + 0x658) != *(int64_t *)(arg1 + 0x660)) {
        *(int64_t *)(arg1 + 0x660) = *(int64_t *)(arg1 + 0x658);
    }
    *(undefined4 *)(arg1 + 0x610) = 0;
    *(undefined8 *)(arg1 + 0x618) = 0;
    *(undefined *)(arg1 + 0x620) = 0;
    *(undefined8 *)(arg1 + 0x628) = 0;
    *(undefined4 *)(arg1 + 0x60c) = (undefined4)var_74h;
    return (uint64_t)uVar21;
}

// ============================================================
// Function: FUN_1800aeb90
// Address: 0x1800aeb90
// Size: 432 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h

bool fcn.1800aeb90(int64_t arg1, int64_t arg2)
{
    char cVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t *puVar5;
    uint64_t uVar6;
    uint64_t *puVar7;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_18h;
    
    uVar2 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782740) {
        uVar2 = arg2;
    }
    if (uVar2 == 0) {
        return *(int32_t *)(arg2 + 8) == *(int32_t *)0x1807826b8;
    }
    if (1 < *(int32_t *)(arg1 + 8)) {
        cVar1 = fcn.1800b2930();
        if (cVar1 != '\0') {
            return false;
        }
        if ((*(int64_t *)(arg1 + 0x1b0) != 0) && (uVar2 != *(uint64_t *)(arg1 + 0x1b8))) {
            uVar8 = *(int64_t *)(arg1 + 0x1a8) - 1;
            uVar4 = (uVar2 >> 5 ^ uVar2) >> 4;
            uVar6 = 0;
            do {
                uVar4 = uVar4 & uVar8;
                puVar7 = (uint64_t *)(uVar4 * 0x10 + *(int64_t *)(arg1 + 0x1a0));
                if (*puVar7 == uVar2) {
                    puVar5 = puVar7 + 1;
                    if (puVar7 == (uint64_t *)0x0) {
                        puVar5 = (uint64_t *)0x0;
                    }
                    if ((puVar5 != (uint64_t *)0x0) && (*(int32_t *)puVar5 != 0)) {
                        iVar3 = fcn.1800ac390(&var_18h);
                        return *(int32_t *)(iVar3 + 4) != 1;
                    }
                    break;
                }
                if (*puVar7 == *(uint64_t *)(arg1 + 0x1b8)) break;
                uVar4 = uVar4 + 1 + uVar6;
                uVar6 = uVar6 + 1;
            } while (uVar6 <= uVar8);
        }
        uVar2 = fcn.1800ad500(arg1, *(int64_t *)(uVar2 + 0x20));
        if (uVar2 != 0) {
            if ((*(int64_t *)(arg1 + 0x70) != 0) && (uVar2 != *(uint64_t *)(arg1 + 0x78))) {
                uVar8 = *(int64_t *)(arg1 + 0x68) - 1;
                uVar4 = (uVar2 >> 5 ^ uVar2) >> 4;
                uVar6 = 0;
                do {
                    uVar4 = uVar4 & uVar8;
                    puVar7 = (uint64_t *)(uVar4 * 0x38 + *(int64_t *)(arg1 + 0x60));
                    if (*puVar7 == uVar2) goto code_r0x0001800aecc7;
                    if (*puVar7 == *(uint64_t *)(arg1 + 0x78)) break;
                    uVar4 = uVar4 + 1 + uVar6;
                    uVar6 = uVar6 + 1;
                } while (uVar6 <= uVar8);
            }
            puVar7 = (uint64_t *)0x0;
code_r0x0001800aecc7:
            puVar5 = puVar7 + 1;
            if (puVar7 == (uint64_t *)0x0) {
                puVar5 = (uint64_t *)0x0;
            }
            if (puVar5 != (uint64_t *)0x0) {
                return *(char *)((int64_t)puVar5 + 0x2d) == '\0';
            }
        }
    }
    return true;
}

// ============================================================
// Function: FUN_1800aed40
// Address: 0x1800aed40
// Size: 275 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h

undefined8 fcn.1800aed40(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    undefined4 uVar1;
    char cVar2;
    int64_t iVar3;
    uint32_t uVar4;
    uint32_t in_R8D;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    uVar4 = in_R8D & 0xff;
    iVar3 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782740) {
        iVar3 = arg2;
    }
    if (iVar3 != 0) {
        if (1 < *(int32_t *)(arg1 + 8)) {
            cVar2 = fcn.1800aeb90(arg1, arg2);
            if (cVar2 == '\0') goto code_r0x0001800aee36;
        }
        uVar1 = *(undefined4 *)(arg1 + 0x60c);
        *(uint32_t *)(arg1 + 0x60c) = uVar4;
        func_0x0001800b0700(arg1, iVar3, uVar4, 0, 1, 1, arg1, uVar1);
        *(undefined4 *)(arg1 + 0x60c) = uVar1;
        return 1;
    }
    iVar3 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x1807826b8) {
        iVar3 = arg2;
    }
    if (iVar3 != 0) {
        uVar1 = *(undefined4 *)(arg1 + 0x60c);
        *(uint32_t *)(arg1 + 0x60c) = uVar4;
        if (0 < *(int32_t *)(arg1 + 0xc)) {
            *(int32_t *)(*(int64_t *)arg1 + 0x270) = *(int32_t *)(iVar3 + 0xc) + 1;
        }
        iVar3 = *(int64_t *)arg1;
        var_10h._0_4_ = uVar4 << 8 | 0x3f;
        fcn.1800d31a0(iVar3 + 0x28, &var_10h);
        fcn.1800d31a0(iVar3 + 0x40, iVar3 + 0x270);
        *(undefined4 *)(arg1 + 0x60c) = uVar1;
        return 1;
    }
code_r0x0001800aee36:
    func_0x0001800b4ce0(arg1, arg2, uVar4, 1);
    return 0;
}

// ============================================================
// Function: FUN_1800aee60
// Address: 0x1800aee60
// Size: 1584 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_bfh
// WARNING: [rz-ghidra] Detected overlap for variable var_b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

void fcn.1800aee60(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    uint32_t *puVar1;
    undefined4 uVar2;
    undefined8 uVar3;
    code *pcVar4;
    uint8_t uVar5;
    char cVar6;
    int32_t iVar7;
    int64_t iVar8;
    uint32_t uVar9;
    uint64_t uVar10;
    int64_t iVar11;
    uint32_t uVar12;
    uint64_t uVar13;
    uint64_t *puVar14;
    uint8_t *puVar15;
    int64_t iVar16;
    uint64_t uVar17;
    uint64_t *puVar18;
    uint64_t uVar19;
    uint64_t uVar20;
    int64_t var_18h;
    undefined auStack_f8 [32];
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_f8;
    iVar11 = *(int64_t *)(arg2 + 0x40);
    var_c0h._0_1_ = (uint8_t)placeholder_3;
    var_c0h._1_1_ = (uint8_t)placeholder_2;
    var_b8h = arg2;
    if (iVar11 == 1) {
        var_c0h._4_4_ = 0x49;
    } else if ((int32_t)(uint32_t)arg_48h < 0) {
        if (iVar11 == 2) {
            cVar6 = fcn.1800b2930();
            if (cVar6 != '\0') goto code_r0x0001800aeedd;
            var_c0h._4_4_ = 0x4a;
        } else {
            var_c0h._4_4_ = 0x3c;
        }
    } else {
code_r0x0001800aeedd:
        var_c0h._4_4_ = 0x4b;
    }
    var_58h = 0;
    var_50h._0_4_ = 0;
    uVar20 = 0;
    if (iVar11 != 0) {
        do {
            if ((uVar20 == 0) || (var_c0h._4_4_ != 0x4b)) {
                iVar11 = *(int64_t *)(*(int64_t *)(arg2 + 0x38) + uVar20 * 8);
                if (*(char *)0x180777f78 == '\0') {
                    iVar7 = *(int32_t *)(iVar11 + 8);
                    iVar8 = 0;
                    if (iVar7 == *(int32_t *)0x180782728) {
                        iVar8 = iVar11;
                    }
                    if (iVar8 != 0) goto code_r0x0001800af104;
                    iVar8 = 0;
                    if (iVar7 == *(int32_t *)0x1807826c0) {
                        iVar8 = iVar11;
                    }
                    if (iVar8 != 0) {
code_r0x0001800af0f6:
                        iVar8 = func_0x0001800b7b80(iVar7, *(undefined8 *)(iVar8 + 0x20));
                        goto code_r0x0001800af0ff;
                    }
                    if (iVar7 == *(int32_t *)0x180782708) {
                        iVar8 = iVar11;
                    }
                    if (iVar8 != 0) goto code_r0x0001800af0f6;
                } else {
                    iVar8 = func_0x0001800beb60(iVar11);
code_r0x0001800af0ff:
                    if (iVar8 != 0) {
code_r0x0001800af104:
                        iVar8 = func_0x0001800ac770(arg1 + 0x88, iVar8 + 0x20);
                        puVar15 = (uint8_t *)(iVar8 + 8);
                        if (iVar8 == 0) {
                            puVar15 = (uint8_t *)0x0;
                        }
                        if ((puVar15 != (uint8_t *)0x0) && (puVar15[1] != 0)) {
                            *(uint32_t *)((int64_t)&var_58h + uVar20 * 4) = (uint32_t)*puVar15;
                            goto code_r0x0001800af174;
                        }
                    }
                }
                uVar9 = (uint8_t)arg_38h + 1 + (int32_t)uVar20 & 0xff;
                *(uint32_t *)((int64_t)&var_58h + uVar20 * 4) = uVar9;
                uVar2 = *(undefined4 *)(arg1 + 0x60c);
                *(uint32_t *)(arg1 + 0x60c) = uVar9 + 1;
                var_68h = arg1;
                var_60h._0_4_ = uVar2;
                func_0x0001800b4ce0(arg1, iVar11, uVar9, 1);
                *(undefined4 *)(arg1 + 0x60c) = uVar2;
            } else {
                if (*(int64_t *)(arg1 + 0x110) == 0) {
code_r0x0001800af454:
                    fcn.1800acea0(arg2 + 0xc, 0x18063f5a0);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                uVar17 = *(uint64_t *)(*(int64_t *)(arg2 + 0x38) + uVar20 * 8);
                if (uVar17 == *(uint64_t *)(arg1 + 0x118)) goto code_r0x0001800af454;
                uVar19 = *(int64_t *)(arg1 + 0x108) - 1;
                uVar10 = (uVar17 >> 5 ^ uVar17) >> 4;
                uVar13 = 0;
                while( true ) {
                    uVar10 = uVar10 & uVar19;
                    puVar18 = (uint64_t *)(uVar10 * 0x20 + *(int64_t *)(arg1 + 0x100));
                    if (*puVar18 == uVar17) break;
                    if (*puVar18 == *(uint64_t *)(arg1 + 0x118)) goto code_r0x0001800af454;
                    uVar10 = uVar10 + 1 + uVar13;
                    uVar13 = uVar13 + 1;
                    if (uVar19 < uVar13) goto code_r0x0001800af454;
                }
                puVar14 = puVar18 + 1;
                if (puVar18 == (uint64_t *)0x0) {
                    puVar14 = (uint64_t *)0x0;
                }
                if ((puVar14 == (uint64_t *)0x0) || (*(int32_t *)puVar14 == 0)) goto code_r0x0001800af454;
    // switch table (6 cases) at 0x1800af478
                switch(*(int32_t *)puVar14) {
                case 1:
                    iVar7 = func_0x0001800cf5d0(*(undefined8 *)arg1);
                    break;
                case 2:
                    iVar7 = func_0x0001800cf610(*(undefined8 *)arg1);
                    break;
                case 3:
                    iVar7 = func_0x0001800cf660(*(undefined8 *)arg1, puVar14[1]);
                    break;
                case 4:
                    iVar7 = func_0x0001800cf6b0(*(undefined8 *)arg1);
                    break;
                case 5:
                    var_d8h._0_4_ = *(int32_t *)((int64_t)puVar14 + 0x14);
                    iVar7 = func_0x0001800cf700(*(undefined8 *)arg1, *(int32_t *)(puVar14 + 1), 
                                                *(int32_t *)((int64_t)puVar14 + 0xc), *(int32_t *)(puVar14 + 2));
                    break;
                case 6:
                    uVar3 = *(undefined8 *)arg1;
                    var_a8h = puVar14[1];
                    var_a0h = (int64_t)*(uint32_t *)((int64_t)puVar14 + 4);
                    var_90h._0_4_ = func_0x0001800cf010(uVar3, &var_a8h);
                    var_98h._0_4_ = 5;
                    stack0xffffffffffffff74 = SUB1612(ZEXT816(0), 4);
                    var_80h._0_4_ = 5;
                    var_78h = (int64_t)(uint32_t)var_90h;
                    var_70h = 0;
                    iVar7 = func_0x0001800ced20(uVar3, &var_80h, &var_98h);
                    break;
                default:
                    goto code_r0x0001800af454;
                }
                if (iVar7 < 0) {
                    fcn.1800acea0(uVar17 + 0xc, 0x18063f5a0);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                *(int32_t *)((int64_t)&var_58h + uVar20 * 4) = iVar7;
            }
code_r0x0001800af174:
            uVar20 = uVar20 + 1;
        } while (uVar20 < *(uint64_t *)(arg2 + 0x40));
    }
    iVar7 = (int32_t)var_50h;
    uVar9 = var_c0h._4_4_;
    iVar11 = *(int64_t *)arg1;
    iVar8 = *(int64_t *)(iVar11 + 0x30) - *(int64_t *)(iVar11 + 0x28) >> 2;
    var_c8h._0_4_ = (uint32_t)CONCAT11((undefined)var_58h, (undefined)arg_40h) << 8 | var_c0h._4_4_;
    fcn.1800d31a0((int64_t *)(iVar11 + 0x28), &var_c8h);
    fcn.1800d31a0(iVar11 + 0x40, iVar11 + 0x270);
    if (uVar9 == 0x3c) {
        var_c8h._0_4_ = iVar7 << 8 | var_58h._4_4_;
    } else {
        if (uVar9 == 0x49) goto code_r0x0001800af21b;
        var_c8h._0_4_ = var_58h._4_4_;
        if (-1 < (int32_t)(uint32_t)arg_48h) {
            var_c8h._0_4_ = (uint32_t)arg_48h;
        }
    }
    iVar11 = *(int64_t *)arg1;
    fcn.1800d31a0(iVar11 + 0x28, &var_c8h);
    fcn.1800d31a0(iVar11 + 0x40, iVar11 + 0x270);
code_r0x0001800af21b:
    if (*(int64_t *)(arg2 + 0x40) != 0) {
        uVar20 = 0;
        do {
            if ((uVar20 == 0) || (uVar9 != 0x4b)) {
                uVar12 = *(uint32_t *)((int64_t)&var_58h + uVar20 * 4);
                if ((uint64_t)uVar12 != (int64_t)(int32_t)((uint8_t)arg_38h + 1) + uVar20) {
                    iVar11 = *(int64_t *)arg1;
                    var_c8h._0_4_ =
                         ((uint32_t)(uint8_t)((char)uVar20 + '\x01' + (uint8_t)arg_38h) | (uVar12 & 0xff) << 8) << 8 | 6
                    ;
                    fcn.1800d31a0(iVar11 + 0x28, &var_c8h);
                    fcn.1800d31a0(iVar11 + 0x40, iVar11 + 0x270);
                }
            } else {
                uVar9 = *(uint32_t *)((int64_t)&var_58h + uVar20 * 4);
                uVar12 = (uint8_t)arg_38h + 1 + (int32_t)uVar20 & 0xff;
                iVar16 = *(int64_t *)arg1;
                iVar11 = iVar16 + 0x28;
                if ((int32_t)uVar9 < 0x8000) {
                    var_c8h._0_4_ = ((uVar9 & 0xffff) << 8 | uVar12) << 8 | 5;
                } else {
                    var_c8h._0_4_ = uVar12 << 8 | 0x42;
                    fcn.1800d31a0(iVar11, &var_c8h);
                    fcn.1800d31a0(iVar16 + 0x40, iVar16 + 0x270);
                    iVar16 = *(int64_t *)arg1;
                    iVar11 = iVar16 + 0x28;
                    var_c8h._0_4_ = uVar9;
                }
                fcn.1800d31a0(iVar11, &var_c8h);
                fcn.1800d31a0(iVar16 + 0x40, iVar16 + 0x270);
                uVar9 = var_c0h._4_4_;
            }
            uVar20 = uVar20 + 1;
        } while (uVar20 < *(uint64_t *)(var_b8h + 0x40));
    }
    iVar16 = var_b8h;
    func_0x0001800b4ce0(arg1, *(undefined8 *)(var_b8h + 0x20), arg_38h & 0xff, 1);
    iVar11 = *(int64_t *)(*(int64_t *)arg1 + 0x28);
    uVar9 = ((int32_t)(*(int64_t *)(*(int64_t *)arg1 + 0x30) - iVar11 >> 2) - (int32_t)iVar8) - 1;
    if ((uVar9 & 0xff) == uVar9) {
        puVar1 = (uint32_t *)(iVar11 + iVar8 * 4);
        *puVar1 = *puVar1 | uVar9 * 0x1000000;
        iVar11 = *(int64_t *)arg1;
        uVar20 = (uint64_t)(uint8_t)var_c0h;
        cVar6 = '\0';
        if ((char)arg_30h == '\0') {
            cVar6 = (uint8_t)var_c0h + 1;
        }
        var_c8h._0_4_ =
             (uint32_t)CONCAT21(CONCAT11(cVar6, *(char *)(iVar16 + 0x40) + '\x01'), (uint8_t)arg_38h) << 8 | 0x15;
        fcn.1800d31a0(iVar11 + 0x28, &var_c8h);
        fcn.1800d31a0(iVar11 + 0x40, iVar11 + 0x270);
        uVar5 = var_c0h._1_1_;
        if (((char)arg_28h == '\0') && (uVar17 = 0, uVar20 != 0)) {
            do {
                iVar11 = *(int64_t *)arg1;
                var_c8h._0_4_ =
                     (((int32_t)uVar17 + (uint32_t)(uint8_t)arg_38h & 0xff) << 8 |
                     (uint32_t)uVar5 + (int32_t)uVar17 & 0xff) << 8 | 6;
                fcn.1800d31a0(iVar11 + 0x28, &var_c8h);
                fcn.1800d31a0(iVar11 + 0x40, iVar11 + 0x270);
                uVar17 = uVar17 + 1;
            } while (uVar17 < uVar20);
        }
        func_0x000180459870(var_48h ^ (uint64_t)auStack_f8);
        return;
    }
    fcn.1800acea0(*(int64_t *)(iVar16 + 0x20) + 0xc, 0x18063f7f0);
    pcVar4 = (code *)swi(3);
    (*pcVar4)();
    return;
}

// ============================================================
// Function: FUN_1800af490
// Address: 0x1800af490
// Size: 4705 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_77h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h

void fcn.1800af490(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                  int64_t arg_78h, int64_t arg_80h)
{
    undefined uVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    uint64_t uVar9;
    code *pcVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined auVar13 [16];
    int64_t iVar14;
    int64_t iVar15;
    undefined auVar16 [16];
    char cVar17;
    uint32_t uVar18;
    int32_t iVar19;
    undefined8 *puVar20;
    undefined *puVar21;
    int64_t iVar22;
    int64_t iVar23;
    undefined4 *puVar24;
    uint32_t uVar25;
    uint32_t uVar26;
    uint64_t uVar27;
    uint64_t uVar28;
    undefined8 *puVar29;
    uint64_t uVar30;
    undefined8 *puVar31;
    undefined *puVar32;
    uint8_t uVar33;
    undefined4 uVar34;
    int64_t *piVar35;
    uint64_t uVar36;
    uint8_t in_R9B;
    undefined8 *puVar37;
    uint64_t uVar38;
    uint64_t *puVar39;
    int64_t *piVar40;
    bool bVar41;
    undefined4 uVar42;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    undefined4 extraout_XMM0_Da_01;
    undefined8 uStackX_8;
    int64_t iStackX_10;
    int64_t iStackX_18;
    uint8_t uStackX_20;
    uint8_t in_stack_00000028;
    undefined8 uStack_160;
    undefined auStack_158 [8];
    undefined auStack_150 [24];
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    undefined8 uStack_d8;
    undefined8 uStack_d0;
    undefined auStack_c8 [16];
    undefined auStack_b8 [4];
    undefined auStack_b4 [12];
    int64_t iStack_a8;
    int64_t iStack_a0;
    int32_t iStack_98;
    undefined4 uStack_94;
    undefined4 uStack_90;
    int64_t *piStack_88;
    int64_t var_80h;
    int64_t var_78h;
    undefined4 var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    puVar32 = auStack_158;
    uStack_90 = *(undefined4 *)(arg1 + 0x60c);
    iStack_a8 = *(int64_t *)(arg1 + 0x648);
    var_80h = *(int64_t *)(arg1 + 0x640);
    uVar42 = 0;
    _var_f8h = ZEXT816(0);
    var_e8h = 0;
    uVar30 = *(uint64_t *)(arg3 + 0x60);
    iStackX_10 = arg2;
    iStackX_18 = arg3;
    uStackX_20 = in_R9B;
    var_78h = arg1;
    var_70h = uStack_90;
    if (uVar30 == 0) {
code_r0x0001800af5eb:
        piVar40 = (int64_t *)0x0;
        piVar35 = *(int64_t **)(iStackX_18 + 0x60);
        if (piVar35 != (int64_t *)0x0) {
            do {
                uVar30 = *(uint64_t *)(*(int64_t *)(iStackX_18 + 0x58) + (int64_t)piVar40 * 8);
                piVar4 = *(int64_t **)(arg2 + 0x40);
                if (piVar40 < piVar4) {
                    puVar31 = *(undefined8 **)(*(int64_t *)(arg2 + 0x38) + (int64_t)piVar40 * 8);
                } else {
                    puVar31 = (undefined8 *)0x0;
                }
                piStack_88 = (int64_t *)((int64_t)piVar40 + 1);
                if ((piStack_88 == piVar4) && (piVar4 < piVar35)) {
                    puVar20 = (undefined8 *)0x0;
                    if (*(int32_t *)(puVar31 + 1) == *(int32_t *)0x180782740) {
                        puVar20 = puVar31;
                    }
                    if (puVar20 == (undefined8 *)0x0) {
                        bVar41 = *(int32_t *)(puVar31 + 1) == *(int32_t *)0x1807826b8;
code_r0x0001800af806:
                        if (!bVar41) goto code_r0x0001800af825;
                    } else if (1 < *(int32_t *)(arg1 + 8)) {
                        cVar17 = fcn.1800b2930(arg1);
                        uVar42 = extraout_XMM0_Da;
                        if (cVar17 != '\0') goto code_r0x0001800af825;
                        if ((*(int64_t *)(arg1 + 0x1b0) != 0) && (puVar20 != *(undefined8 **)(arg1 + 0x1b8))) {
                            uVar36 = *(int64_t *)(arg1 + 0x1a8) - 1;
                            uVar27 = ((uint64_t)puVar20 >> 5 ^ (uint64_t)puVar20) >> 4;
                            uVar28 = 0;
                            do {
                                uVar27 = uVar27 & uVar36;
                                piVar35 = (int64_t *)(uVar27 * 0x10 + *(int64_t *)(arg1 + 0x1a0));
                                puVar29 = (undefined8 *)*piVar35;
                                if (puVar29 == puVar20) {
                                    piVar35 = piVar35 + 1;
                                    if ((piVar35 != (int64_t *)0x0) && (*(int32_t *)piVar35 != 0)) {
                                        iVar22 = fcn.1800ac390(&iStack_a0);
                                        bVar41 = *(int32_t *)(iVar22 + 4) != 1;
                                        uVar42 = extraout_XMM0_Da_01;
                                        goto code_r0x0001800af806;
                                    }
                                    break;
                                }
                                if (puVar29 == *(undefined8 **)(arg1 + 0x1b8)) break;
                                uVar27 = uVar27 + 1 + uVar28;
                                uVar28 = uVar28 + 1;
                            } while (uVar28 <= uVar36);
                        }
                        uVar27 = fcn.1800ad500(arg1, puVar20[4]);
                        if (((uVar27 != 0) && (*(int64_t *)(arg1 + 0x70) != 0)) &&
                           (uVar27 != *(uint64_t *)(arg1 + 0x78))) {
                            uVar38 = *(int64_t *)(arg1 + 0x68) - 1;
                            uVar28 = (uVar27 >> 5 ^ uVar27) >> 4;
                            uVar36 = 0;
                            while( true ) {
                                uVar28 = uVar28 & uVar38;
                                puVar39 = (uint64_t *)(uVar28 * 0x38 + *(int64_t *)(arg1 + 0x60));
                                if (*puVar39 == uVar27) break;
                                if (*puVar39 == *(uint64_t *)(arg1 + 0x78)) goto code_r0x0001800af759;
                                uVar28 = uVar28 + 1 + uVar36;
                                uVar36 = uVar36 + 1;
                                if (uVar38 < uVar36) goto code_r0x0001800af759;
                            }
                            if ((puVar39 != (uint64_t *)0xfffffffffffffff8) &&
                               (uVar42 = extraout_XMM0_Da_00, *(char *)((int64_t)puVar39 + 0x35) != '\0'))
                            goto code_r0x0001800af825;
                        }
                    }
code_r0x0001800af759:
                    uVar26 = (*(int32_t *)(iStackX_18 + 0x60) - *(int32_t *)(arg2 + 0x40)) + 1;
                    uVar25 = *(uint32_t *)(arg1 + 0x60c);
                    uVar2 = uVar26 + uVar25;
                    if (0xff < uVar2) {
                        fcn.1800acea0((int64_t)puVar31 + 0xc, 0x18063fbc0, uVar26, 0xff);
                        pcVar10 = (code *)swi(3);
                        (*pcVar10)();
                        return;
                    }
                    *(uint32_t *)(arg1 + 0x60c) = uVar2;
                    uVar18 = *(uint32_t *)(arg1 + 0x610);
                    if (*(uint32_t *)(arg1 + 0x610) < uVar2) {
                        uVar18 = uVar2;
                    }
                    *(uint32_t *)(arg1 + 0x610) = uVar18;
                    iVar22 = *(int64_t *)arg1;
                    iVar23 = *(int64_t *)(iVar22 + 0x30);
                    iVar5 = *(int64_t *)(iVar22 + 0x28);
                    puVar20 = (undefined8 *)0x0;
                    if (*(int32_t *)(puVar31 + 1) == *(int32_t *)0x180782740) {
                        puVar20 = puVar31;
                    }
                    if (puVar20 == (undefined8 *)0x0) {
                        puVar20 = (undefined8 *)0x0;
                        if (*(int32_t *)(puVar31 + 1) == *(int32_t *)0x1807826b8) {
                            puVar20 = puVar31;
                        }
                        if (puVar20 != (undefined8 *)0x0) {
                            if (0 < *(int32_t *)(arg1 + 0xc)) {
                                *(int32_t *)(iVar22 + 0x270) = *(int32_t *)((int64_t)puVar20 + 0xc) + 1;
                            }
                            iVar22 = *(int64_t *)arg1;
                            uStackX_8 = (undefined8 *)
                                        (CONCAT44(uStackX_8._4_4_, 
                                                  ((uint32_t)(uint8_t)((char)uVar26 + 1) << 8 | uVar25 & 0xff) << 8) |
                                        0x3f);
                            fcn.1800d31a0(iVar22 + 0x28, &uStackX_8);
                            fcn.1800d31a0(iVar22 + 0x40, iVar22 + 0x270);
                        }
                    } else {
                        var_130h = var_130h & 0xffffffffffffff00;
                        var_138h = CONCAT71(var_138h._1_7_, 1);
                        func_0x0001800b0700(arg1, puVar20, uVar25 & 0xff, uVar26 & 0xff);
                    }
                    piVar35 = *(int64_t **)(iStackX_18 + 0x60);
                    if (piVar40 < piVar35) {
                        cVar17 = (char)piVar40;
                        iVar22 = iStackX_18;
                        do {
                            auVar13 = _auStack_b8;
                            iVar14 = uStack_d8;
                            iVar6 = *(int64_t *)(*(int64_t *)(iVar22 + 0x58) + (int64_t)piVar40 * 8);
                            uStack_d8 = CONCAT71(uStack_d8._1_7_, ((char)piVar40 - cVar17) + (char)uVar25);
                            iVar15 = uStack_d8;
                            uStack_d0 = 0;
                            auStack_c8 = ZEXT816(0);
                            uVar42 = (undefined4)(iVar23 - iVar5 >> 2);
                            auStack_b8 = (undefined  [4])uVar42;
                            auStack_b4._4_8_ = 0;
                            auVar16 = _auStack_b8;
                            var_e0h = iVar6;
                            if (var_f0h == var_e8h) {
                                func_0x0001800c19d0(&var_f8h, var_f0h, &var_e0h);
                                iVar22 = iStackX_18;
                            } else {
                                var_e0h._0_4_ = (undefined4)iVar6;
                                var_e0h._4_4_ = (undefined4)((uint64_t)iVar6 >> 0x20);
                                uStack_d8._4_4_ = SUB84(iVar14, 4);
                                *(undefined4 *)var_f0h = (undefined4)var_e0h;
                                *(undefined4 *)(var_f0h + 4) = var_e0h._4_4_;
                                *(undefined4 *)(var_f0h + 8) = (undefined4)uStack_d8;
                                *(undefined4 *)(var_f0h + 0xc) = uStack_d8._4_4_;
                                *(undefined4 *)(var_f0h + 0x10) = 0;
                                *(undefined4 *)(var_f0h + 0x14) = 0;
                                *(undefined4 *)(var_f0h + 0x18) = 0;
                                *(undefined4 *)(var_f0h + 0x1c) = 0;
                                auStack_b4._0_4_ = auVar13._4_4_;
                                *(undefined4 *)(var_f0h + 0x20) = 0;
                                *(undefined4 *)(var_f0h + 0x24) = 0;
                                *(undefined4 *)(var_f0h + 0x28) = uVar42;
                                *(undefined4 *)(var_f0h + 0x2c) = auStack_b4._0_4_;
                                *(undefined8 *)(var_f0h + 0x30) = 0;
                                var_f0h = var_f0h + 0x38;
                                uStack_d8 = iVar15;
                                _auStack_b8 = auVar16;
                            }
                            piVar40 = (int64_t *)((int64_t)piVar40 + 1);
                            piVar35 = *(int64_t **)(iVar22 + 0x60);
                        } while (piVar40 < piVar35);
                    }
                    break;
                }
code_r0x0001800af825:
                iVar23 = uStack_d8;
                iVar22 = var_e0h;
                var_e0h._0_4_ = (undefined4)uVar30;
                uVar11 = (undefined4)var_e0h;
                var_e0h._4_4_ = (undefined4)(uVar30 >> 0x20);
                uVar12 = var_e0h._4_4_;
                var_e0h = uVar30;
                if ((*(int64_t *)(arg1 + 0xe8) != 0) && (uVar30 != *(uint64_t *)(arg1 + 0xf0))) {
                    uVar36 = *(int64_t *)(arg1 + 0xe0) - 1;
                    uVar27 = (uVar30 >> 5 ^ uVar30) >> 4;
                    uVar28 = 0;
                    do {
                        uVar27 = uVar27 & uVar36;
                        puVar39 = (uint64_t *)(*(int64_t *)(arg1 + 0xd8) + uVar27 * 0x18);
                        if (*puVar39 == uVar30) {
                            if ((puVar39 + 1 != (uint64_t *)0x0) && (*(char *)(puVar39 + 2) != '\0')) {
                                uVar2 = *(uint32_t *)(arg1 + 0x60c);
                                uVar25 = uVar2 + 1;
                                var_e0h = iVar22;
                                if (0xff < uVar25) goto code_r0x0001800b06b9;
                                *(uint32_t *)(arg1 + 0x60c) = uVar25;
                                uVar26 = *(uint32_t *)(arg1 + 0x610);
                                if (*(uint32_t *)(arg1 + 0x610) < uVar25) {
                                    uVar26 = uVar25;
                                }
                                *(uint32_t *)(arg1 + 0x610) = uVar26;
                                iVar23 = *(int64_t *)arg1;
                                iVar5 = *(int64_t *)(iVar23 + 0x30);
                                iVar6 = *(int64_t *)(iVar23 + 0x28);
                                if (puVar31 == (undefined8 *)0x0) {
                                    uStackX_8 = (undefined8 *)(CONCAT44(uStackX_8._4_4_, (uVar2 & 0xff) << 8) | 2);
                                    fcn.1800d31a0((int64_t *)(iVar23 + 0x28), &uStackX_8);
                                    fcn.1800d31a0(iVar23 + 0x40, iVar23 + 0x270);
                                } else {
                                    func_0x0001800b4ce0(arg1, puVar31, uVar2 & 0xff, 
                                                        CONCAT71((unkint7)((uint64_t)(puVar39 + 1) >> 8), 1));
                                }
                                auVar13 = _auStack_b8;
                                iVar22 = uStack_d8;
                                uStack_d8 = CONCAT71(uStack_d8._1_7_, (char)uVar2);
                                iVar23 = uStack_d8;
                                uStack_d0 = 0;
                                auStack_c8 = ZEXT816(0);
                                uVar34 = (undefined4)(iVar5 - iVar6 >> 2);
                                auStack_b8 = (undefined  [4])uVar34;
                                auStack_b4._4_8_ = 0;
                                auVar16 = _auStack_b8;
                                if (var_f0h == var_e8h) {
                                    var_e0h = uVar30;
                                    uVar42 = func_0x0001800c19d0(&var_f8h, var_f0h, &var_e0h);
                                    arg2 = iStackX_10;
                                } else {
                                    uStack_d8._4_4_ = SUB84(iVar22, 4);
                                    *(undefined4 *)var_f0h = uVar11;
                                    *(undefined4 *)(var_f0h + 4) = uVar12;
                                    *(undefined4 *)(var_f0h + 8) = (undefined4)uStack_d8;
                                    *(undefined4 *)(var_f0h + 0xc) = uStack_d8._4_4_;
                                    *(undefined4 *)(var_f0h + 0x10) = 0;
                                    *(undefined4 *)(var_f0h + 0x14) = 0;
                                    *(undefined4 *)(var_f0h + 0x18) = 0;
                                    *(undefined4 *)(var_f0h + 0x1c) = 0;
                                    uVar42 = 0;
                                    auStack_b4._0_4_ = auVar13._4_4_;
                                    *(undefined4 *)(var_f0h + 0x20) = 0;
                                    *(undefined4 *)(var_f0h + 0x24) = 0;
                                    *(undefined4 *)(var_f0h + 0x28) = uVar34;
                                    *(undefined4 *)(var_f0h + 0x2c) = auStack_b4._0_4_;
                                    *(undefined8 *)(var_f0h + 0x30) = 0;
                                    var_f0h = var_f0h + 0x38;
                                    arg2 = iStackX_10;
                                    var_e0h = uVar30;
                                    uStack_d8 = iVar23;
                                    _auStack_b8 = auVar16;
                                }
                                goto code_r0x0001800afbfe;
                            }
                            break;
                        }
                        if (*puVar39 == *(uint64_t *)(arg1 + 0xf0)) break;
                        uVar27 = uVar27 + 1 + uVar28;
                        uVar28 = uVar28 + 1;
                    } while (uVar28 <= uVar36);
                }
                puVar20 = (undefined8 *)0x0;
                if (puVar31 == (undefined8 *)0x0) {
                    uStack_d8 = CONCAT71(uStack_d8._1_7_, 0xff);
                    iVar22 = uStack_d8;
                    uStack_d0 = 1;
                    _auStack_b8 = ZEXT816(0);
                    auStack_c8 = ZEXT816(0);
                    if (var_f0h == var_e8h) {
                        uVar42 = func_0x0001800c19d0(&var_f8h, var_f0h, &var_e0h);
                    } else {
                        uStack_d8._4_4_ = SUB84(iVar23, 4);
                        *(undefined4 *)var_f0h = (undefined4)var_e0h;
                        *(undefined4 *)(var_f0h + 4) = var_e0h._4_4_;
                        *(undefined4 *)(var_f0h + 8) = (undefined4)uStack_d8;
                        *(undefined4 *)(var_f0h + 0xc) = uStack_d8._4_4_;
                        *(undefined4 *)(var_f0h + 0x10) = 1;
                        *(undefined4 *)(var_f0h + 0x14) = 0;
                        *(undefined4 *)(var_f0h + 0x18) = 0;
                        *(undefined4 *)(var_f0h + 0x1c) = 0;
                        auStack_c8._8_4_ = 0;
                        *(undefined4 *)(var_f0h + 0x20) = 0;
                        *(undefined4 *)(var_f0h + 0x24) = 0;
                        *(undefined4 *)(var_f0h + 0x28) = 0;
                        *(undefined4 *)(var_f0h + 0x2c) = 0;
                        *(undefined8 *)(var_f0h + 0x30) = 0;
                        var_f0h = var_f0h + 0x38;
                        uVar42 = auStack_c8._8_4_;
                        uStack_d8 = iVar22;
                    }
                } else {
                    if ((*(int64_t *)(arg1 + 0x110) != 0) && (puVar31 != *(undefined8 **)(arg1 + 0x118))) {
                        puVar37 = (undefined8 *)(*(int64_t *)(arg1 + 0x108) + -1);
                        uVar27 = ((uint64_t)puVar31 >> 5 ^ (uint64_t)puVar31) >> 4;
                        puVar29 = puVar20;
                        do {
                            uVar27 = uVar27 & (uint64_t)puVar37;
                            piVar35 = (int64_t *)(uVar27 * 0x20 + *(int64_t *)(arg1 + 0x100));
                            if ((undefined8 *)*piVar35 == puVar31) {
                                piVar40 = piVar35 + 1;
                                if ((piVar40 != (int64_t *)0x0) && (*(int32_t *)piVar40 != 0)) {
                                    uStack_d8 = CONCAT71(uStack_d8._1_7_, 0xff);
                                    uStack_d0 = *piVar40;
                                    auStack_c8 = *(undefined (*) [16])(piVar35 + 2);
                                    _auStack_b8 = ZEXT816(0);
                                    goto code_r0x0001800afbef;
                                }
                                break;
                            }
                            if ((undefined8 *)*piVar35 == *(undefined8 **)(arg1 + 0x118)) break;
                            uVar27 = uVar27 + 1 + (int64_t)puVar29;
                            puVar29 = (undefined8 *)((int64_t)puVar29 + 1);
                        } while (puVar29 <= puVar37);
                    }
                    if (*(char *)0x180777f78 == '\0') {
                        iVar19 = *(int32_t *)(puVar31 + 1);
                        puVar29 = puVar20;
                        if (iVar19 == *(int32_t *)0x180782728) {
                            puVar29 = puVar31;
                        }
                        var_e0h = iVar22;
                        if (puVar29 != (undefined8 *)0x0) goto code_r0x0001800afb16;
                        puVar29 = puVar20;
                        if (iVar19 == *(int32_t *)0x1807826c0) {
                            puVar29 = puVar31;
                        }
                        if (puVar29 != (undefined8 *)0x0) {
code_r0x0001800afb05:
                            puVar29 = (undefined8 *)func_0x0001800b7b80(uVar42, puVar29[4]);
                            goto code_r0x0001800afb0e;
                        }
                        puVar29 = puVar20;
                        if (iVar19 == *(int32_t *)0x180782708) {
                            puVar29 = puVar31;
                        }
                        if (puVar29 != (undefined8 *)0x0) goto code_r0x0001800afb05;
code_r0x0001800afb7e:
                        uVar25 = *(uint32_t *)(arg1 + 0x60c);
                        uVar2 = uVar25 + 1;
                        if (0xff < uVar2) {
code_r0x0001800b06b9:
                            fcn.1800acea0((int64_t)puVar31 + 0xc, 0x18063fbc0, 1, 0xff);
                            pcVar10 = (code *)swi(3);
                            (*pcVar10)();
                            return;
                        }
                        *(uint32_t *)(arg1 + 0x60c) = uVar2;
                        uVar26 = *(uint32_t *)(arg1 + 0x610);
                        if (*(uint32_t *)(arg1 + 0x610) < uVar2) {
                            uVar26 = uVar2;
                        }
                        *(uint32_t *)(arg1 + 0x610) = uVar26;
                        iVar22 = *(int64_t *)(*(int64_t *)arg1 + 0x30);
                        iVar23 = *(int64_t *)(*(int64_t *)arg1 + 0x28);
                        func_0x0001800b4ce0(arg1, puVar31, uVar25 & 0xff, 1);
                        uStack_d8 = CONCAT71(uStack_d8._1_7_, (char)uVar25);
                        uStack_d0 = 0;
                        auStack_c8 = ZEXT816(0);
                        auStack_b8 = (undefined  [4])(int32_t)(iVar22 - iVar23 >> 2);
                        auStack_b4._4_8_ = puVar31;
                    } else {
                        var_e0h = iVar22;
                        puVar29 = (undefined8 *)func_0x0001800beb60(puVar31);
code_r0x0001800afb0e:
                        if (puVar29 == (undefined8 *)0x0) goto code_r0x0001800afb7e;
code_r0x0001800afb16:
                        iVar22 = func_0x0001800ac770(arg1 + 0xd8, puVar29 + 4);
                        puVar37 = (undefined8 *)(iVar22 + 8);
                        if (iVar22 == 0) {
                            puVar37 = puVar20;
                        }
                        iVar19 = func_0x0001800b7be0(arg1, puVar29);
                        if ((iVar19 < 0) || ((puVar37 != (undefined8 *)0x0 && (*(char *)(puVar37 + 1) != '\0'))))
                        goto code_r0x0001800afb7e;
                        uStack_d8 = CONCAT71(uStack_d8._1_7_, (char)iVar19);
                        uStack_d0 = 0;
                        auStack_c8 = ZEXT816(0);
                        auStack_b8 = (undefined  [4])0xffffffff;
                        if (puVar37 == (undefined8 *)0x0) {
                            auStack_b4._4_8_ = 0;
                        } else {
                            auStack_b4._4_8_ = *puVar37;
                        }
                    }
code_r0x0001800afbef:
                    var_e0h = uVar30;
                    uVar42 = func_0x0001800bf640(&var_f8h, &var_e0h);
                }
code_r0x0001800afbfe:
                piVar35 = *(int64_t **)(iStackX_18 + 0x60);
                piVar40 = piStack_88;
            } while (piStack_88 < piVar35);
        }
        iVar22 = iStackX_10;
        if (piVar35 < *(int64_t **)(iStackX_10 + 0x40)) {
            do {
                iVar23 = *(int64_t *)(*(int64_t *)(iVar22 + 0x38) + (int64_t)piVar35 * 8);
                iVar19 = *(int32_t *)(iVar23 + 8);
                if ((((iVar19 != *(int32_t *)0x180782728) && (iVar19 != *(int32_t *)0x180782738)) &&
                    (iVar19 != *(int32_t *)0x1807826b8)) &&
                   ((iVar19 != *(int32_t *)0x1807826a0 && (cVar17 = fcn.1800b2930(arg1, iVar23), cVar17 == '\0')))) {
                    if (iVar19 != *(int32_t *)0x180782740) {
                        func_0x0001800d0a10(*(undefined8 *)arg1, 0x18063f9a8);
                    }
                    iVar19 = *(int32_t *)(arg1 + 0x60c);
                    iStack_a0 = arg1;
                    iStack_98 = iVar19;
                    func_0x0001800b7030(arg1, iVar23);
                    *(int32_t *)(arg1 + 0x60c) = iVar19;
                }
                piVar35 = (int64_t *)((int64_t)piVar35 + 1);
            } while (piVar35 < *(int64_t **)(iVar22 + 0x40));
        }
        iVar23 = var_f0h;
        iVar22 = iStackX_18;
        uVar33 = in_stack_00000028;
        for (puVar39 = (uint64_t *)var_f8h; iStackX_18 = iVar22, in_stack_00000028 = uVar33,
            puVar39 != (uint64_t *)iVar23; puVar39 = puVar39 + 7) {
            if (*(int32_t *)(puVar39 + 2) == 0) {
                uStackX_8 = (undefined8 *)*puVar39;
                if (199 < (uint64_t)(*(int64_t *)(arg1 + 0x648) - *(int64_t *)(arg1 + 0x640) >> 3)) {
                    fcn.1800acea0(uStackX_8 + 1, 0x18063fb70, *uStackX_8, 200);
                    pcVar10 = (code *)swi(3);
                    (*pcVar10)();
                    return;
                }
                uVar2 = *(uint32_t *)(puVar39 + 5);
                piVar35 = (int64_t *)(uint64_t)uVar2;
                uVar1 = *(undefined *)(puVar39 + 1);
                fcn.1800bf890((int64_t *)(arg1 + 0x640), &uStackX_8);
                puVar21 = (undefined *)fcn.1800c0050(arg1 + 0x88, &uStackX_8);
                *puVar21 = uVar1;
                puVar21[1] = 1;
                uVar25 = (uint32_t)(*(int64_t *)(*(int64_t *)arg1 + 0x30) - *(int64_t *)(*(int64_t *)arg1 + 0x28) >> 2);
                *(uint32_t *)(puVar21 + 4) = uVar25;
                if (uVar2 != 0xffffffff) {
                    uVar25 = uVar2;
                }
                *(uint32_t *)(puVar21 + 8) = uVar25;
                uVar30 = puVar39[6];
                if (((uVar30 != 0) && (iVar22 = func_0x0001800ac770(arg1 + 0xd8, puVar39), iVar22 != 0)) &&
                   ((uint64_t *)(iVar22 + 8) != (uint64_t *)0x0)) {
                    *(uint64_t *)(iVar22 + 8) = uVar30;
                }
            } else {
                uVar42 = *(undefined4 *)(puVar39 + 2);
                uVar11 = *(undefined4 *)((int64_t)puVar39 + 0x14);
                uVar12 = *(undefined4 *)(puVar39 + 3);
                uVar34 = *(undefined4 *)((int64_t)puVar39 + 0x1c);
                uVar30 = puVar39[4];
                puVar24 = (undefined4 *)func_0x0001800c05e0(arg1 + 0x128, puVar39);
                *puVar24 = uVar42;
                puVar24[1] = uVar11;
                puVar24[2] = uVar12;
                puVar24[3] = uVar34;
                *(uint64_t *)(puVar24 + 4) = uVar30;
            }
            iVar22 = iStackX_18;
            uVar33 = in_stack_00000028;
        }
        uStack_d8 = iStack_a8 - var_80h >> 3;
        uVar30 = (uint64_t)uStack_d0 >> 0x10;
        auStack_c8 = ZEXT816(0);
        puVar31 = (undefined8 *)0x0;
        auVar13._8_8_ = 0;
        auVar13._0_8_ = auStack_b4._4_8_;
        _auStack_b8 = auVar13 << 0x40;
        piVar40 = *(int64_t **)(arg1 + 0x6a8);
        var_e0h = iVar22;
        iStack_a8 = uStack_d8;
        if (piVar40 == *(int64_t **)(arg1 + 0x6b0)) {
            func_0x0001800c1b80(arg1 + 0x6a0, piVar40, &var_e0h);
            puVar20 = _auStack_b8;
            puVar29 = (undefined8 *)auStack_c8._0_8_;
        } else {
            *piVar40 = iVar22;
            piVar40[1] = uStack_d8;
            *(uint8_t *)(piVar40 + 2) = uStackX_20;
            *(uint8_t *)((int64_t)piVar40 + 0x11) = uVar33;
            piVar40[3] = 0;
            piVar40[4] = 0;
            piVar40[5] = 0;
            *(int64_t *)(arg1 + 0x6a8) = *(int64_t *)(arg1 + 0x6a8) + 0x30;
            puVar20 = puVar31;
            puVar29 = puVar31;
        }
        if (puVar29 != (undefined8 *)0x0) {
            uVar30 = ((int64_t)puVar20 - (int64_t)puVar29 >> 3) * 8;
            puVar20 = puVar29;
            if (0xfff < uVar30) {
                puVar20 = (undefined8 *)puVar29[-1];
                if (0x1f < (uint64_t)((int64_t)puVar29 + (-8 - (int64_t)puVar20))) goto code_r0x0001800b00c8;
                uVar30 = uVar30 + 0x27;
            }
            fcn.180459c3c(puVar20, uVar30);
        }
        piVar35 = (int64_t *)(arg1 + 0x268);
        var_130h = *(int64_t *)(arg1 + 0x5b8);
        var_138h = *(int64_t *)(iVar22 + 0x90);
        func_0x0001800ac190(piVar35, arg1 + 0xb0, arg1 + 0xd8, arg1 + 8);
        puVar21 = auStack_158;
        if (*(int64_t *)(arg1 + 0x278) == 0) goto code_r0x0001800b00ec;
        uStackX_8 = *(undefined8 **)(arg1 + 0x270);
        if (uStackX_8 != (undefined8 *)0x0) {
            do {
                if (*(int64_t *)(*piVar35 + (int64_t)puVar31 * 0x10) != *(int64_t *)(arg1 + 0x280)) break;
                puVar31 = (undefined8 *)((int64_t)puVar31 + 1);
            } while (puVar31 < uStackX_8);
        }
code_r0x0001800affc4:
        if (puVar31 != uStackX_8) {
            piVar40 = (int64_t *)(*piVar35 + (int64_t)puVar31 * 0x10);
            iStack_a0 = *piVar40;
            iVar19 = *(int32_t *)(piVar40 + 1);
            uStack_94 = *(undefined4 *)((int64_t)piVar40 + 0xc);
            iStack_98 = iVar19;
            if (((uint64_t)(*(int64_t *)(arg1 + 0x1a8) * 3) >> 2 <= *(uint64_t *)(arg1 + 0x1b0)) &&
               (iVar22 = func_0x0001800ac7f0(arg1 + 0x1a0, &iStack_a0), iVar22 == 0)) {
                func_0x0001800ac870(arg1 + 0x1a0);
            }
            iVar22 = func_0x0001800ac6e0(arg1 + 0x1a0, &iStack_a0);
            iVar3 = *(int32_t *)(iVar22 + 8);
            if (iVar19 != iVar3) {
                if (((uint64_t)(*(int64_t *)(arg1 + 0x298) * 3) >> 2 <= *(uint64_t *)(arg1 + 0x2a0)) &&
                   (iVar23 = func_0x0001800ac7f0(arg1 + 0x290, &iStack_a0), iVar23 == 0)) {
                    func_0x0001800ac870(arg1 + 0x290);
                }
                iVar23 = func_0x0001800ac6e0(arg1 + 0x290, &iStack_a0);
                *(int32_t *)(iVar23 + 8) = iVar3;
                *(int32_t *)(iVar22 + 8) = iVar19;
            }
            do {
                puVar31 = (undefined8 *)((int64_t)puVar31 + 1);
                if (*(undefined8 **)(arg1 + 0x270) <= puVar31) break;
            } while (*(int64_t *)(*piVar35 + (int64_t)puVar31 * 0x10) == *(int64_t *)(arg1 + 0x280));
            goto code_r0x0001800affc4;
        }
    } else {
        if (0x492492492492492 < uVar30) {
            fcn.180010010();
            pcVar10 = (code *)swi(3);
            (*pcVar10)();
            return;
        }
        piVar35 = (int64_t *)(uVar30 * 0x38);
        if (piVar35 == (int64_t *)0x0) {
            uVar30 = 0;
code_r0x0001800af572:
            uVar42 = fcn.180498030(uVar30, var_f8h, var_f0h - var_f8h);
            if (var_f8h != 0) {
                uVar27 = (var_e8h - var_f8h >> 3) * 8;
                iVar22 = var_f8h;
                if (0xfff < uVar27) {
                    if (0x1f < (var_f8h - *(int64_t *)(var_f8h + -8)) - 8U) goto code_r0x0001800b00c8;
                    uVar27 = uVar27 + 0x27;
                    iVar22 = *(int64_t *)(var_f8h + -8);
                }
                uVar42 = fcn.180459c3c(iVar22, uVar27);
            }
            var_f0h = uVar30;
            var_f8h = uVar30;
            var_e8h = uVar30 + (int64_t)piVar35;
            goto code_r0x0001800af5eb;
        }
        if (piVar35 < (int64_t *)0x1000) {
            uVar30 = fcn.180459890(piVar35);
            goto code_r0x0001800af572;
        }
        if ((int64_t *)((int64_t)piVar35 + 0x27U) <= piVar35) {
            fcn.180004720();
            pcVar10 = (code *)swi(3);
            (*pcVar10)();
            return;
        }
        iVar22 = fcn.180459890();
        if (iVar22 != 0) {
            uVar30 = iVar22 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar30 - 8) = iVar22;
            goto code_r0x0001800af572;
        }
code_r0x0001800b00c8:
        pcVar10 = (code *)swi(0x29);
        (*pcVar10)(5);
        puVar32 = auStack_150;
    }
    *(undefined8 *)(puVar32 + -8) = 0x1800b00d7;
    func_0x0001800c0840(piVar35);
    puVar21 = puVar32;
    uVar33 = in_stack_00000028;
code_r0x0001800b00ec:
    if ((*(char *)0x180778018 != '\0') && (*(char *)0x180777ff8 != '\0')) {
        if (*(int64_t *)(arg1 + 0x2b8) != *(int64_t *)(arg1 + 0x2c0)) {
            *(int64_t *)(arg1 + 0x2c0) = *(int64_t *)(arg1 + 0x2b8);
        }
        if (*(int64_t *)(arg1 + 0x2d0) != *(int64_t *)(arg1 + 0x2d8)) {
            *(int64_t *)(arg1 + 0x2d8) = *(int64_t *)(arg1 + 0x2d0);
        }
    }
    piVar35 = (int64_t *)(arg1 + 0x128);
    *(int64_t *)(puVar21 + 0x50) = arg1 + 0x2d0;
    *(int64_t *)(puVar21 + 0x48) = arg1 + 0x2b8;
    *(int64_t *)(puVar21 + 0x40) = arg1 + 0x150;
    *(undefined8 *)(puVar21 + 0x38) = *(undefined8 *)(arg1 + 0x5b8);
    *(undefined8 *)(puVar21 + 0x30) = *(undefined8 *)(iStackX_18 + 0x90);
    *(undefined8 *)(puVar21 + 0x28) = *(undefined8 *)(arg1 + 0x50);
    puVar21[0x20] = *(undefined *)(arg1 + 0x608);
    uVar7 = *(undefined8 *)(arg1 + 0x600);
    *(undefined8 *)(puVar21 + -8) = 0x1800b01a1;
    func_0x0001800c7640(arg1 + 0x100, arg1 + 0xd8, piVar35, uVar7);
    uVar30 = 0;
    iVar22 = *(int64_t *)(iStackX_18 + 0x90);
    if (*(int64_t *)(iVar22 + 0x30) != 0) {
        do {
            uVar7 = *(undefined8 *)(*(int64_t *)(iVar22 + 0x28) + uVar30 * 8);
            *(undefined8 *)(puVar21 + -8) = 0x1800b01d3;
            func_0x0001800b7cc0(arg1, uVar7);
            *(undefined8 *)(puVar21 + -8) = 0x1800b01e2;
            cVar17 = func_0x0001800acb30(arg1 + 0x100, uVar7);
            if (cVar17 != '\0') {
                iVar22 = *(int64_t *)(arg1 + 0x6a8);
                if (*(int64_t *)(iVar22 + -0x18) != *(int64_t *)(iVar22 + -0x10)) {
                    iVar23 = *(int64_t *)arg1;
                    if (*(int64_t *)(*(int64_t *)(iVar22 + -0x10) + -8) ==
                        (*(int64_t *)(iVar23 + 0x30) - *(int64_t *)(iVar23 + 0x28) >> 2) + -1) {
                        *(int64_t *)(iVar23 + 0x30) = *(int64_t *)(iVar23 + 0x30) + -4;
                        *(int64_t *)(iVar23 + 0x48) = *(int64_t *)(iVar23 + 0x48) + -4;
                        *(int64_t *)(iVar22 + -0x10) = *(int64_t *)(iVar22 + -0x10) + -8;
                    }
                }
                goto code_r0x0001800b025e;
            }
            uVar30 = uVar30 + 1;
            iVar22 = *(int64_t *)(iStackX_18 + 0x90);
        } while (uVar30 < *(uint64_t *)(iVar22 + 0x30));
    }
    uVar30 = 0;
    if ((uint64_t)uVar33 != 0) {
        do {
            iVar22 = *(int64_t *)arg1;
            uStackX_8 = (undefined8 *)
                        (CONCAT44(uStackX_8._4_4_, ((uint32_t)uStackX_20 + (int32_t)uVar30 & 0xff) << 8) | 2);
            *(undefined8 *)(puVar21 + -8) = 0x1800b0230;
            fcn.1800d31a0(iVar22 + 0x28, &uStackX_8);
            *(undefined8 *)(puVar21 + -8) = 0x1800b0240;
            fcn.1800d31a0(iVar22 + 0x40, iVar22 + 0x270);
            uVar30 = uVar30 + 1;
        } while (uVar30 < uVar33);
    }
    *(undefined8 *)(puVar21 + -8) = 0x1800b025e;
    func_0x0001800bbb60(arg1, iStack_a8);
code_r0x0001800b025e:
    *(undefined8 *)(puVar21 + -8) = 0x1800b0269;
    func_0x0001800bbc30(arg1);
    iVar22 = *(int64_t *)(*(int64_t *)arg1 + 0x30);
    iVar23 = *(int64_t *)(*(int64_t *)arg1 + 0x28);
    puVar20 = *(undefined8 **)(*(int64_t *)(arg1 + 0x6a8) + -0x10);
    for (puVar31 = *(undefined8 **)(*(int64_t *)(arg1 + 0x6a8) + -0x18); puVar31 != puVar20; puVar31 = puVar31 + 1) {
        uVar7 = *puVar31;
        uVar8 = *(undefined8 *)arg1;
        *(undefined8 *)(puVar21 + -8) = 0x1800b029e;
        cVar17 = func_0x0001800cfeb0(uVar8, uVar7, iVar22 - iVar23 >> 2);
        if (cVar17 == '\0') {
            *(undefined8 *)(puVar21 + -8) = 0x1800b0691;
            fcn.1800acea0(iStackX_10 + 0xc, 0x18063f7f0);
            pcVar10 = (code *)swi(3);
            (*pcVar10)();
            return;
        }
    }
    iVar22 = *(int64_t *)(arg1 + 0x6a8);
    *(undefined8 *)(puVar21 + -8) = 0x1800b02bc;
    func_0x00018000ace0(iVar22 + -0x18);
    *(int64_t *)(arg1 + 0x6a8) = *(int64_t *)(arg1 + 0x6a8) + -0x30;
    uVar30 = 0;
    if (*(int64_t *)(iStackX_18 + 0x60) != 0) {
        do {
            uVar27 = *(uint64_t *)(*(int64_t *)(iStackX_18 + 0x58) + uVar30 * 8);
            if ((*(int64_t *)(arg1 + 0x138) != 0) && (uVar27 != *(uint64_t *)(arg1 + 0x140))) {
                uVar38 = *(int64_t *)(arg1 + 0x130) - 1;
                uVar28 = (uVar27 >> 5 ^ uVar27) >> 4;
                uVar36 = 0;
                do {
                    uVar28 = uVar28 & uVar38;
                    puVar39 = (uint64_t *)(uVar28 * 0x20 + *piVar35);
                    uVar9 = *puVar39;
                    if (uVar9 == uVar27) {
                        puVar39 = puVar39 + 1;
                        if (puVar39 != (uint64_t *)0x0) {
                            *(undefined4 *)puVar39 = 0;
                        }
                        break;
                    }
                    if (uVar9 == *(uint64_t *)(arg1 + 0x140)) break;
                    uVar28 = uVar28 + 1 + uVar36;
                    uVar36 = uVar36 + 1;
                } while (uVar36 <= uVar38);
            }
            if ((*(int64_t *)(arg1 + 0xe8) != 0) && (uVar27 != *(uint64_t *)(arg1 + 0xf0))) {
                uVar38 = *(int64_t *)(arg1 + 0xe0) - 1;
                uVar28 = (uVar27 >> 5 ^ uVar27) >> 4;
                uVar36 = 0;
                do {
                    uVar28 = uVar28 & uVar38;
                    puVar39 = (uint64_t *)(*(int64_t *)(arg1 + 0xd8) + uVar28 * 0x18);
                    uVar9 = *puVar39;
                    if (uVar9 == uVar27) {
                        puVar39 = puVar39 + 1;
                        if (puVar39 != (uint64_t *)0x0) {
                            *puVar39 = 0;
                        }
                        break;
                    }
                    if (uVar9 == *(uint64_t *)(arg1 + 0xf0)) break;
                    uVar28 = uVar28 + 1 + uVar36;
                    uVar36 = uVar36 + 1;
                } while (uVar36 <= uVar38);
            }
            uVar30 = uVar30 + 1;
        } while (uVar30 < *(uint64_t *)(iStackX_18 + 0x60));
    }
    if (*(int64_t *)(arg1 + 0x2a0) != 0) {
        piVar40 = (int64_t *)(arg1 + 0x290);
        uVar27 = 0;
        uVar30 = *(uint64_t *)(arg1 + 0x298);
        if (uVar30 != 0) {
            do {
                if (*(int64_t *)(*piVar40 + uVar27 * 0x10) != *(int64_t *)(arg1 + 0x2a8)) break;
                uVar27 = uVar27 + 1;
            } while (uVar27 < uVar30);
        }
code_r0x0001800b0464:
        if (uVar27 != uVar30) {
            piVar4 = (int64_t *)(*piVar40 + uVar27 * 0x10);
            iStack_a0 = *piVar4;
            iStack_98 = *(int32_t *)(piVar4 + 1);
            uStack_94 = *(undefined4 *)((int64_t)piVar4 + 0xc);
            uVar42 = *(undefined4 *)(*piVar40 + 8 + uVar27 * 0x10);
            if ((uint64_t)(*(int64_t *)(arg1 + 0x1a8) * 3) >> 2 <= *(uint64_t *)(arg1 + 0x1b0)) {
                *(undefined8 *)(puVar21 + -8) = 0x1800b04ab;
                iVar22 = func_0x0001800ac7f0(arg1 + 0x1a0, &iStack_a0);
                if (iVar22 == 0) {
                    *(undefined8 *)(puVar21 + -8) = 0x1800b04bc;
                    func_0x0001800ac870(arg1 + 0x1a0);
                }
            }
            *(undefined8 *)(puVar21 + -8) = 0x1800b04cc;
            iVar22 = func_0x0001800ac6e0(arg1 + 0x1a0, &iStack_a0);
            *(undefined4 *)(iVar22 + 8) = uVar42;
            do {
                uVar27 = uVar27 + 1;
                if (*(uint64_t *)(arg1 + 0x298) <= uVar27) break;
            } while (*(int64_t *)(*piVar40 + uVar27 * 0x10) == *(int64_t *)(arg1 + 0x2a8));
            goto code_r0x0001800b0464;
        }
        *(undefined8 *)(puVar21 + -8) = 0x1800b04fc;
        func_0x0001800c0840(piVar40);
    }
    if ((*(char *)0x180778018 == '\0') || (*(char *)0x180777ff8 == '\0')) {
        *(undefined8 *)(puVar21 + 0x50) = 0;
        *(undefined8 *)(puVar21 + 0x48) = 0;
        *(int64_t *)(puVar21 + 0x40) = arg1 + 0x150;
        *(undefined8 *)(puVar21 + 0x38) = *(undefined8 *)(arg1 + 0x5b8);
        *(undefined8 *)(puVar21 + 0x30) = *(undefined8 *)(iStackX_18 + 0x90);
        *(undefined8 *)(puVar21 + 0x28) = *(undefined8 *)(arg1 + 0x50);
        puVar21[0x20] = *(undefined *)(arg1 + 0x608);
        uVar7 = *(undefined8 *)(arg1 + 0x600);
        *(undefined8 *)(puVar21 + -8) = 0x1800b05f3;
        func_0x0001800c7640(arg1 + 0x100, arg1 + 0xd8, piVar35, uVar7);
    } else {
        *(undefined8 *)(puVar21 + -8) = 0x1800b0533;
        func_0x0001800c75a0(arg1 + 0x100, arg1 + 0x2b8);
        iVar22 = *(int64_t *)(arg1 + 0x2d8);
        if (iVar22 != *(int64_t *)(arg1 + 0x2d0)) {
            do {
                iVar23 = iVar22 + -0x28;
                if (*(char *)(iVar22 + -8) == '\0') {
                    uVar42 = *(undefined4 *)(iVar22 + -0x20);
                    uVar11 = *(undefined4 *)(iVar22 + -0x1c);
                    uVar12 = *(undefined4 *)(iVar22 + -0x18);
                    uVar34 = *(undefined4 *)(iVar22 + -0x14);
                    uVar7 = *(undefined8 *)(iVar22 + -0x10);
                    *(undefined8 *)(puVar21 + -8) = 0x1800b0582;
                    puVar24 = (undefined4 *)func_0x0001800c05e0(piVar35, iVar23);
                    *puVar24 = uVar42;
                    puVar24[1] = uVar11;
                    puVar24[2] = uVar12;
                    puVar24[3] = uVar34;
                    *(undefined8 *)(puVar24 + 4) = uVar7;
                } else {
                    *(undefined8 *)(puVar21 + -8) = 0x1800b0565;
                    iVar22 = func_0x0001800c13d0();
                    if ((iVar22 != 0) && ((undefined4 *)(iVar22 + 8) != (undefined4 *)0x0)) {
                        *(undefined4 *)(iVar22 + 8) = 0;
                    }
                }
                iVar22 = iVar23;
            } while (iVar23 != *(int64_t *)(arg1 + 0x2d0));
        }
    }
    iVar22 = *(int64_t *)(puVar21 + 0x60);
    if (iVar22 != 0) {
        iVar23 = iVar22;
        if ((0xfff < (uint64_t)((*(int64_t *)(puVar21 + 0x70) - iVar22 >> 3) * 8)) &&
           (iVar23 = *(int64_t *)(iVar22 + -8), 0x1f < (iVar22 - iVar23) - 8U)) {
            iVar23 = 5;
            pcVar10 = (code *)swi(0x29);
            (*pcVar10)(5);
            puVar21 = puVar21 + 8;
        }
        *(undefined8 *)(puVar21 + -8) = 0x1800b064e;
        fcn.180459c3c(iVar23);
    }
    *(undefined4 *)(arg1 + 0x60c) = uStack_90;
    return;
}

// ============================================================
// Function: FUN_1800b0700
// Address: 0x1800b0700
// Size: 6594 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_128h
// WARNING: Variable defined which should be unmapped: var_118h
// WARNING: Variable defined which should be unmapped: var_10ch
// WARNING: Variable defined which should be unmapped: var_168h
// WARNING: Variable defined which should be unmapped: var_160h
// WARNING: Variable defined which should be unmapped: var_158h
// WARNING: Variable defined which should be unmapped: var_150h
// WARNING: Variable defined which should be unmapped: var_148h
// WARNING: [rz-ghidra] Detected overlap for variable var_127h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_126h
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_bfh
// WARNING: [rz-ghidra] Detected overlap for variable var_b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_77h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h

void fcn.1800b0700(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h, int64_t arg_68h)
{
    uint32_t *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int32_t iVar8;
    undefined4 uVar9;
    char cVar10;
    uint32_t uVar11;
    int32_t iVar12;
    uint64_t uVar13;
    uint64_t *puVar14;
    int64_t iVar15;
    undefined4 *puVar16;
    int64_t iVar17;
    int64_t iVar18;
    int32_t *piVar19;
    uint32_t uVar20;
    int32_t iVar21;
    uint32_t uVar22;
    uint64_t uVar23;
    int64_t iVar24;
    uint64_t uVar25;
    uint64_t *puVar26;
    uint8_t *puVar27;
    undefined4 uVar28;
    uint64_t uVar29;
    int64_t *piVar30;
    uint8_t uVar31;
    uint32_t uVar32;
    uint64_t *puVar33;
    uint64_t uVar34;
    uint64_t uVar35;
    uint64_t uVar36;
    uint64_t uVar37;
    int64_t *piVar38;
    uint8_t uVar39;
    bool bVar40;
    undefined auStackY_188 [32];
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t in_stack_fffffffffffffed0;
    int64_t var_128h;
    int64_t var_118h;
    int32_t var_110h;
    int64_t var_10ch;
    undefined4 uStack_104;
    int64_t var_100h;
    undefined8 uStack_f8;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    undefined auStack_88 [8];
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    
    var_70h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_188;
    if (0 < *(int32_t *)(arg1 + 0xc)) {
        *(int32_t *)(*(int64_t *)arg1 + 0x270) = *(int32_t *)(arg2 + 0xc) + 1;
    }
    var_128h._0_1_ = (uint8_t)placeholder_3;
    var_128h._1_1_ = (uint8_t)placeholder_2;
    if (((1 < *(int32_t *)(arg1 + 8)) && (*(char *)(arg2 + 0x48) == '\0')) &&
       (uVar13 = fcn.1800ad500(arg1, *(int64_t *)(arg2 + 0x20)), uVar13 != 0)) {
        if ((*(int64_t *)(arg1 + 0x70) != 0) && (uVar13 != *(uint64_t *)(arg1 + 0x78))) {
            uVar35 = *(int64_t *)(arg1 + 0x68) - 1;
            uVar23 = (uVar13 >> 5 ^ uVar13) >> 4;
            uVar25 = 0;
            do {
                uVar23 = uVar23 & uVar35;
                puVar33 = (uint64_t *)(uVar23 * 0x38 + *(int64_t *)(arg1 + 0x60));
                if (*puVar33 == uVar13) goto code_r0x0001800b07e8;
                if (*puVar33 == *(uint64_t *)(arg1 + 0x78)) break;
                uVar23 = uVar23 + 1 + uVar25;
                uVar25 = uVar25 + 1;
            } while (uVar25 <= uVar35);
        }
        puVar33 = (uint64_t *)0x0;
code_r0x0001800b07e8:
        var_e0h = arg1 + 0x60;
        var_e8h = 0x18;
        puVar26 = puVar33 + 1;
        if (puVar33 == (uint64_t *)0x0) {
            puVar26 = (uint64_t *)0x0;
        }
        var_d0h = (int64_t)puVar26;
        if (puVar26 != (uint64_t *)0x0) {
            if (*(char *)((int64_t)puVar26 + 0x2c) != '\0') {
                if ((*(int64_t *)(arg1 + 0x70) != 0) && (uVar13 != *(uint64_t *)(arg1 + 0x78))) {
                    uVar35 = *(int64_t *)(arg1 + 0x68) - 1;
                    uVar23 = (uVar13 >> 5 ^ uVar13) >> 4;
                    uVar25 = 0;
                    do {
                        uVar23 = uVar23 & uVar35;
                        puVar33 = (uint64_t *)(uVar23 * 0x38 + *(int64_t *)(arg1 + 0x60));
                        if (*puVar33 == uVar13) goto code_r0x0001800b0877;
                        if (*puVar33 == *(uint64_t *)(arg1 + 0x78)) break;
                        uVar23 = uVar23 + 1 + uVar25;
                        uVar25 = uVar25 + 1;
                    } while (uVar25 <= uVar35);
                }
                puVar33 = (uint64_t *)0x0;
code_r0x0001800b0877:
                if (*(uint32_t *)(arg1 + 0x60c) < 0x81) {
                    puVar14 = puVar33 + 6;
                    if (puVar33 == (uint64_t *)0x0) {
                        puVar14 = (uint64_t *)0x28;
                    }
                    if (*(uint32_t *)puVar14 < 0x21) {
                        puVar14 = *(uint64_t **)(arg1 + 0x6a0);
                        if ((int32_t)((int64_t)*(uint64_t **)(arg1 + 0x6a8) - (int64_t)puVar14 >> 4) * -0x55555555 <
                            *(int32_t *)0x180777ef8) {
                            for (; puVar14 != *(uint64_t **)(arg1 + 0x6a8); puVar14 = puVar14 + 6) {
                                if (*puVar14 == uVar13) goto code_r0x0001800b12d9;
                            }
                            if ((char)arg_30h == '\0') {
                                var_10ch._0_4_ = *(uint32_t *)0x180777f18;
                                var_128h._4_4_ = *(uint32_t *)0x180777ed8;
                                var_78h = 0;
                                bVar40 = false;
                                uVar23 = *(uint64_t *)(uVar13 + 0x60);
                                uVar25 = uVar13;
                                if (uVar23 != 0) {
                                    uVar29 = 0;
                                    uVar35 = *(uint64_t *)(arg2 + 0x40);
                                    do {
                                        uVar25 = uVar13;
                                        if ((uVar35 <= uVar29) || (7 < uVar29)) break;
                                        cVar10 = fcn.1800b2930(arg1, *(undefined8 *)
                                                                      (*(int64_t *)(arg2 + 0x38) + uVar29 * 8));
                                        if (cVar10 != '\0') {
                                            *(undefined *)((int64_t)&var_78h + uVar29) = 1;
                                            bVar40 = true;
                                        }
                                        uVar29 = uVar29 + 1;
                                        uVar25 = uVar13;
                                    } while (uVar29 < uVar23);
                                }
                                uVar13 = uVar25;
                                if ((*(int64_t *)(arg2 + 0x40) != 0) &&
                                   (cVar10 = fcn.1800aeb90(arg1, *(int64_t *)
                                                                  (*(int64_t *)(arg2 + 0x38) + -8 +
                                                                  *(int64_t *)(arg2 + 0x40) * 8)), cVar10 == '\0')) {
                                    uVar35 = *(uint64_t *)(uVar25 + 0x60);
                                    for (uVar23 = *(uint64_t *)(arg2 + 0x40); (uVar23 < uVar35 && (uVar23 < 8));
                                        uVar23 = uVar23 + 1) {
                                        *(undefined *)((int64_t)&var_78h + uVar23) = 1;
                                        bVar40 = true;
                                    }
                                }
                                var_a0h = (int64_t)(puVar33 + 5);
                                if (puVar33 == (uint64_t *)0x0) {
                                    var_a0h = 0x20;
                                }
                                if (bVar40) {
                                    uVar23 = *(uint64_t *)(uVar25 + 0x60);
                                    if (uVar23 != 0) {
                                        var_b0h = 0;
                                        do {
                                            uVar35 = *(uint64_t *)(*(int64_t *)(uVar25 + 0x58) + var_b0h * 8);
                                            uVar29 = *(uint64_t *)(arg2 + 0x40);
                                            if ((uint64_t)var_b0h < uVar29) {
                                                uVar34 = *(uint64_t *)(*(int64_t *)(arg2 + 0x38) + var_b0h * 8);
                                            } else {
                                                uVar34 = 0;
                                            }
                                            var_b0h = var_b0h + 1;
                                            var_d8h = uVar35;
                                            var_b8h = uVar35;
                                            if ((var_b0h == uVar29) && (uVar29 < uVar23)) {
                                                uVar23 = 0;
                                                if (*(int32_t *)(uVar34 + 8) == *(int32_t *)0x180782740) {
                                                    uVar23 = uVar34;
                                                }
                                                if (uVar23 == 0) {
                                                    bVar40 = *(int32_t *)(uVar34 + 8) == *(int32_t *)0x1807826b8;
code_r0x0001800b0b9e:
                                                    if (bVar40) break;
                                                } else {
                                                    if (*(int32_t *)(arg1 + 8) < 2) break;
                                                    cVar10 = fcn.1800b2930(arg1);
                                                    if (cVar10 == '\0') {
                                                        if ((*(int64_t *)(arg1 + 0x1b0) != 0) &&
                                                           (uVar23 != *(uint64_t *)(arg1 + 0x1b8))) {
                                                            uVar36 = *(int64_t *)(arg1 + 0x1a8) - 1;
                                                            uVar29 = (uVar23 >> 5 ^ uVar23) >> 4;
                                                            uVar37 = 0;
                                                            do {
                                                                uVar29 = uVar29 & uVar36;
                                                                puVar33 = (uint64_t *)
                                                                          (uVar29 * 0x10 + *(int64_t *)(arg1 + 0x1a0));
                                                                if (*puVar33 == uVar23) {
                                                                    puVar26 = puVar33 + 1;
                                                                    if (puVar33 == (uint64_t *)0x0) {
                                                                        puVar26 = (uint64_t *)0x0;
                                                                    }
                                                                    if ((puVar26 != (uint64_t *)0x0) &&
                                                                       (*(int32_t *)puVar26 != 0)) {
                                                                        iVar15 = fcn.1800ac390((int64_t)&var_10ch + 4);
                                                                        bVar40 = *(int32_t *)(iVar15 + 4) != 1;
                                                                        goto code_r0x0001800b0b9e;
                                                                    }
                                                                    break;
                                                                }
                                                                if (*puVar33 == *(uint64_t *)(arg1 + 0x1b8)) break;
                                                                uVar29 = uVar29 + 1 + uVar37;
                                                                uVar37 = uVar37 + 1;
                                                            } while (uVar37 <= uVar36);
                                                        }
                                                        uVar23 = fcn.1800ad500(arg1, *(int64_t *)(uVar23 + 0x20));
                                                        if (((uVar23 == 0) || (*(int64_t *)(arg1 + 0x70) == 0)) ||
                                                           (uVar23 == *(uint64_t *)(var_e0h + var_e8h))) break;
                                                        uVar36 = *(int64_t *)(arg1 + 0x68) - 1;
                                                        uVar29 = (uVar23 >> 5 ^ uVar23) >> 4;
                                                        uVar37 = 0;
                                                        while( true ) {
                                                            uVar29 = uVar29 & uVar36;
                                                            puVar33 = (uint64_t *)
                                                                      (uVar29 * 0x38 + *(int64_t *)(arg1 + 0x60));
                                                            if (*puVar33 == uVar23) break;
                                                            if (*puVar33 == *(uint64_t *)(var_e0h + var_e8h))
                                                            goto code_r0x0001800b0f92;
                                                            uVar29 = uVar29 + 1 + uVar37;
                                                            uVar37 = uVar37 + 1;
                                                            if (uVar36 < uVar37) goto code_r0x0001800b0f92;
                                                        }
                                                        puVar26 = puVar33 + 1;
                                                        if (puVar33 == (uint64_t *)0x0) {
                                                            puVar26 = (uint64_t *)0x0;
                                                        }
                                                        if ((puVar26 == (uint64_t *)0x0) ||
                                                           (*(char *)((int64_t)puVar26 + 0x2d) == '\0')) break;
                                                    }
                                                }
                                            }
                                            if ((*(int64_t *)(arg1 + 0xe8) != 0) &&
                                               (uVar35 != *(uint64_t *)(arg1 + 0xf0))) {
                                                uVar37 = *(int64_t *)(arg1 + 0xe0) - 1;
                                                uVar23 = (uVar35 >> 5 ^ uVar35) >> 4;
                                                uVar29 = 0;
                                                do {
                                                    uVar23 = uVar23 & uVar37;
                                                    puVar33 = (uint64_t *)(*(int64_t *)(arg1 + 0xd8) + uVar23 * 0x18);
                                                    if (*puVar33 == uVar35) {
                                                        puVar26 = puVar33 + 1;
                                                        if (puVar33 == (uint64_t *)0x0) {
                                                            puVar26 = (uint64_t *)0x0;
                                                        }
                                                        if ((puVar26 != (uint64_t *)0x0) &&
                                                           (*(char *)(puVar26 + 1) != '\0')) goto code_r0x0001800b0f80;
                                                        break;
                                                    }
                                                    if (*puVar33 == *(uint64_t *)(arg1 + 0xf0)) break;
                                                    uVar23 = uVar23 + 1 + uVar29;
                                                    uVar29 = uVar29 + 1;
                                                } while (uVar29 <= uVar37);
                                            }
                                            if (uVar34 == 0) {
                                                _auStack_88 = ZEXT816(0);
                                                var_d8h = 0;
                                                iVar15 = *(int64_t *)(arg1 + 0x130);
                                                if ((uint64_t)(iVar15 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x138)) {
                                                    if ((*(uint64_t *)(arg1 + 0x138) != 0) &&
                                                       (uVar35 != *(uint64_t *)(arg1 + 0x140))) {
                                                        uVar23 = (uVar35 >> 5 ^ uVar35) >> 4;
                                                        uVar29 = 0;
                                                        do {
                                                            uVar23 = uVar23 & iVar15 - 1U;
                                                            uVar34 = *(uint64_t *)
                                                                      (uVar23 * 0x20 + *(int64_t *)(arg1 + 0x128));
                                                            if (uVar34 == uVar35) goto code_r0x0001800b0e54;
                                                            if (uVar34 == *(uint64_t *)(arg1 + 0x140)) break;
                                                            uVar23 = uVar23 + 1 + uVar29;
                                                            uVar29 = uVar29 + 1;
                                                        } while (uVar29 <= iVar15 - 1U);
                                                    }
                                                    puVar33 = (uint64_t *)(arg1 + 0x140);
                                                    uVar23 = *puVar33;
                                                    if (iVar15 == 0) {
                                                        uVar35 = 0x10;
                                                        iVar18 = fcn.180459890(0x200);
                                                        uVar34 = 0;
                                                        uVar29 = 0x10;
                                                        iVar15 = iVar18;
code_r0x0001800b0d40:
                                                        do {
                                                            iVar24 = uVar34 * 0x20;
                                                            *(uint64_t *)(iVar24 + iVar18) = *puVar33;
                                                            *(undefined (*) [16])(iVar24 + 8 + iVar18) = ZEXT816(0);
                                                            *(undefined8 *)(iVar24 + 0x18 + iVar18) = 0;
                                                            *(undefined8 *)(iVar24 + 8 + iVar18) = 0;
                                                            *(undefined8 *)(iVar24 + 0x10 + iVar18) = 0;
                                                            uVar34 = uVar34 + 1;
                                                            uVar25 = uVar13;
                                                        } while (uVar34 < uVar35);
                                                    } else {
                                                        uVar35 = iVar15 * 2;
                                                        if (uVar35 == 0) {
                                                            uVar29 = 0;
                                                            iVar15 = 0;
                                                            uVar25 = uVar13;
                                                        } else {
                                                            iVar18 = fcn.180459890(iVar15 << 6);
                                                            uVar34 = 0;
                                                            uVar29 = uVar35;
                                                            iVar15 = iVar18;
                                                            uVar25 = uVar13;
                                                            if (uVar35 != 0) goto code_r0x0001800b0d40;
                                                        }
                                                    }
                                                    uVar13 = 0;
                                                    if (*(int64_t *)(arg1 + 0x130) != 0) {
                                                        do {
                                                            iVar18 = uVar13 * 0x20;
                                                            uVar35 = *(uint64_t *)(iVar18 + *(int64_t *)(arg1 + 0x128));
                                                            if (uVar35 != *puVar33) {
                                                                uVar34 = (uVar35 >> 5 ^ uVar35) >> 4;
                                                                uVar37 = 0;
                                                                do {
                                                                    uVar34 = uVar34 & uVar29 - 1;
                                                                    puVar26 = (uint64_t *)(uVar34 * 0x20 + iVar15);
                                                                    if (*puVar26 == uVar23) {
                                                                        *puVar26 = uVar35;
                                                                        goto code_r0x0001800b0def;
                                                                    }
                                                                    if (*puVar26 == uVar35) goto code_r0x0001800b0def;
                                                                    uVar34 = uVar34 + 1 + uVar37;
                                                                    uVar37 = uVar37 + 1;
                                                                } while (uVar37 <= uVar29 - 1);
                                                                puVar26 = (uint64_t *)0x0;
code_r0x0001800b0def:
                                                                iVar24 = *(int64_t *)(arg1 + 0x128);
                                                                *puVar26 = *(uint64_t *)(iVar18 + iVar24);
                                                                puVar16 = (undefined4 *)(iVar18 + 8 + iVar24);
                                                                uVar28 = puVar16[1];
                                                                uVar5 = puVar16[2];
                                                                uVar6 = puVar16[3];
                                                                *(undefined4 *)(puVar26 + 1) = *puVar16;
                                                                *(undefined4 *)((int64_t)puVar26 + 0xc) = uVar28;
                                                                *(undefined4 *)(puVar26 + 2) = uVar5;
                                                                *(undefined4 *)((int64_t)puVar26 + 0x14) = uVar6;
                                                                puVar26[3] = *(uint64_t *)(iVar18 + 0x18 + iVar24);
                                                            }
                                                            uVar13 = uVar13 + 1;
                                                        } while (uVar13 < *(uint64_t *)(arg1 + 0x130));
                                                    }
                                                    iVar18 = *(int64_t *)(arg1 + 0x128);
                                                    *(int64_t *)(arg1 + 0x128) = iVar15;
                                                    *(uint64_t *)(arg1 + 0x130) = uVar29;
                                                    uVar35 = var_b8h;
                                                    uVar13 = uVar25;
                                                    if (iVar18 != 0) {
                                                        func_0x0001800f4640();
                                                        uVar35 = var_b8h;
                                                        uVar13 = uVar25;
                                                    }
                                                }
code_r0x0001800b0e54:
                                                uVar34 = *(int64_t *)(arg1 + 0x130) - 1;
                                                uVar23 = (uVar35 >> 5 ^ uVar35) >> 4;
                                                uVar29 = 0;
                                                do {
                                                    uVar23 = uVar23 & uVar34;
                                                    puVar33 = (uint64_t *)(uVar23 * 0x20 + *(int64_t *)(arg1 + 0x128));
                                                    if (*puVar33 == *(uint64_t *)(arg1 + 0x140)) {
                                                        *puVar33 = uVar35;
                                                        *(int64_t *)(arg1 + 0x138) = *(int64_t *)(arg1 + 0x138) + 1;
                                                        goto code_r0x0001800b0eb6;
                                                    }
                                                    if (*puVar33 == uVar35) goto code_r0x0001800b0eb6;
                                                    uVar23 = uVar23 + 1 + uVar29;
                                                    uVar29 = uVar29 + 1;
                                                } while (uVar29 <= uVar34);
                                                puVar33 = (uint64_t *)0x0;
code_r0x0001800b0eb6:
                                                *(undefined4 *)(puVar33 + 1) = 1;
                                                *(undefined4 *)((int64_t)puVar33 + 0xc) = 0;
                                                puVar33[2] = var_d8h;
                                                puVar33[3] = var_80h;
                                            } else if ((*(int64_t *)(arg1 + 0x110) != 0) &&
                                                      (uVar34 != *(uint64_t *)(arg1 + 0x118))) {
                                                uVar29 = *(int64_t *)(arg1 + 0x108) - 1;
                                                uVar23 = (uVar34 >> 5 ^ uVar34) >> 4;
                                                uVar35 = 0;
                                                do {
                                                    uVar23 = uVar23 & uVar29;
                                                    puVar33 = (uint64_t *)(uVar23 * 0x20 + *(int64_t *)(arg1 + 0x100));
                                                    if (*puVar33 == uVar34) {
                                                        puVar26 = puVar33 + 1;
                                                        if (puVar33 == (uint64_t *)0x0) {
                                                            puVar26 = (uint64_t *)0x0;
                                                        }
                                                        if ((puVar26 != (uint64_t *)0x0) && (*(int32_t *)puVar26 != 0))
                                                        {
                                                            iVar12 = *(int32_t *)puVar26;
                                                            iVar21 = *(int32_t *)((int64_t)puVar26 + 4);
                                                            iVar7 = *(int32_t *)(puVar26 + 1);
                                                            iVar8 = *(int32_t *)((int64_t)puVar26 + 0xc);
                                                            uVar23 = puVar26[2];
                                                            piVar19 = (int32_t *)
                                                                      func_0x0001800c05e0(arg1 + 0x128, &var_d8h);
                                                            *piVar19 = iVar12;
                                                            piVar19[1] = iVar21;
                                                            piVar19[2] = iVar7;
                                                            piVar19[3] = iVar8;
                                                            *(uint64_t *)(piVar19 + 4) = uVar23;
                                                        }
                                                        break;
                                                    }
                                                    if (*puVar33 == *(uint64_t *)(arg1 + 0x118)) break;
                                                    uVar23 = uVar23 + 1 + uVar35;
                                                    uVar35 = uVar35 + 1;
                                                } while (uVar35 <= uVar29);
                                            }
code_r0x0001800b0f80:
                                            uVar23 = *(uint64_t *)(uVar25 + 0x60);
                                        } while ((uint64_t)var_b0h < uVar23);
                                    }
code_r0x0001800b0f92:
                                    if ((*(char *)0x180778018 != '\0') && (*(char *)0x180777ff8 != '\0')) {
                                        if (*(int64_t *)(arg1 + 0x2b8) != *(int64_t *)(arg1 + 0x2c0)) {
                                            *(int64_t *)(arg1 + 0x2c0) = *(int64_t *)(arg1 + 0x2b8);
                                        }
                                        if (*(int64_t *)(arg1 + 0x2d0) != *(int64_t *)(arg1 + 0x2d8)) {
                                            *(int64_t *)(arg1 + 0x2d8) = *(int64_t *)(arg1 + 0x2d0);
                                        }
                                    }
                                    var_148h = arg1 + 0x150;
                                    iVar15 = arg1 + 0x100;
                                    var_138h = arg1 + 0x2d0;
                                    var_150h = *(int64_t *)(arg1 + 0x5b8);
                                    var_158h = *(int64_t *)(uVar25 + 0x90);
                                    var_160h = *(int64_t *)(arg1 + 0x50);
                                    var_168h = CONCAT71(var_168h._1_7_, *(undefined *)(arg1 + 0x608));
                                    var_140h = arg1 + 0x2b8;
                                    func_0x0001800c7640(iVar15, arg1 + 0xd8, arg1 + 0x128, *(undefined8 *)(arg1 + 0x600)
                                                       );
                                    var_168h = iVar15;
                                    uVar23 = func_0x0001800c92c0(*(undefined8 *)(uVar25 + 0x90), 
                                                                 *(undefined8 *)(uVar25 + 0x58), 
                                                                 *(undefined8 *)(uVar25 + 0x60), arg1 + 0x1a0);
                                    uVar35 = 0;
                                    uVar25 = uVar13;
                                    if (*(int64_t *)(uVar13 + 0x60) != 0) {
                                        do {
                                            iVar18 = func_0x0001800c13d0(arg1 + 0x128, 
                                                                         *(int64_t *)(uVar13 + 0x58) + uVar35 * 8);
                                            puVar16 = (undefined4 *)(iVar18 + 8);
                                            if (iVar18 == 0) {
                                                puVar16 = (undefined4 *)0x0;
                                            }
                                            if (puVar16 != (undefined4 *)0x0) {
                                                *puVar16 = 0;
                                            }
                                            uVar35 = uVar35 + 1;
                                        } while (uVar35 < *(uint64_t *)(uVar13 + 0x60));
                                    }
                                    uVar13 = uVar25;
                                    if ((*(char *)0x180778018 == '\0') || (*(char *)0x180777ff8 == '\0')) {
                                        var_138h = 0;
                                        var_140h = 0;
                                        var_148h = arg1 + 0x150;
                                        var_150h = *(int64_t *)(arg1 + 0x5b8);
                                        var_158h = *(int64_t *)(uVar13 + 0x90);
                                        var_160h = *(int64_t *)(arg1 + 0x50);
                                        var_168h = CONCAT71(var_168h._1_7_, *(undefined *)(arg1 + 0x608));
                                        func_0x0001800c7640(iVar15, arg1 + 0xd8, arg1 + 0x128, 
                                                            *(undefined8 *)(arg1 + 0x600));
                                    } else {
                                        func_0x0001800c75a0(iVar15, arg1 + 0x2b8);
                                        iVar15 = *(int64_t *)(arg1 + 0x2d8);
                                        if (iVar15 != *(int64_t *)(arg1 + 0x2d0)) {
                                            do {
                                                iVar18 = iVar15 + -0x28;
                                                if (*(char *)(iVar15 + -8) == '\0') {
                                                    uVar28 = *(undefined4 *)(iVar15 + -0x20);
                                                    uVar5 = *(undefined4 *)(iVar15 + -0x1c);
                                                    uVar6 = *(undefined4 *)(iVar15 + -0x18);
                                                    uVar9 = *(undefined4 *)(iVar15 + -0x14);
                                                    uVar3 = *(undefined8 *)(iVar15 + -0x10);
                                                    puVar16 = (undefined4 *)func_0x0001800c05e0(arg1 + 0x128, iVar18);
                                                    *puVar16 = uVar28;
                                                    puVar16[1] = uVar5;
                                                    puVar16[2] = uVar6;
                                                    puVar16[3] = uVar9;
                                                    *(undefined8 *)(puVar16 + 4) = uVar3;
                                                } else {
                                                    iVar15 = func_0x0001800c13d0();
                                                    puVar16 = (undefined4 *)(iVar15 + 8);
                                                    if (iVar15 == 0) {
                                                        puVar16 = (undefined4 *)0x0;
                                                    }
                                                    if (puVar16 != (undefined4 *)0x0) {
                                                        *puVar16 = 0;
                                                    }
                                                }
                                                iVar15 = iVar18;
                                            } while (iVar18 != *(int64_t *)(arg1 + 0x2d0));
                                        }
                                    }
                                } else {
                                    uVar23 = *(uint64_t *)var_a0h;
                                }
                                uVar22 = (uint32_t)uVar23 & 0x7f;
                                if (uVar22 != 0x7f) {
                                    iVar12 = *(int32_t *)(uVar13 + 0x60);
                                    uVar25 = 0;
                                    if (8 < iVar12) {
                                        iVar12 = 8;
                                    }
                                    if (iVar12 != 0) {
                                        do {
                                            if (6 < uVar25) break;
                                            uVar22 = uVar22 - ((uint32_t)(uVar23 >> ((char)uVar25 * '\b' + 8U & 0x3f)) &
                                                              0x7f) * (uint32_t)*(uint8_t *)((int64_t)&var_78h + uVar25)
                                            ;
                                            uVar25 = uVar25 + 1;
                                        } while (uVar25 < (uint64_t)(int64_t)iVar12);
                                    }
                                }
                                uVar32 = (uint32_t)var_10ch;
                                if ((uVar22 != 0) &&
                                   (uVar20 = (uint32_t)
                                             ((int64_t)(uint64_t)(((*(uint32_t *)var_a0h & 0x7f) + 3) * 100) /
                                             (int64_t)(int32_t)uVar22), (int32_t)uVar20 < (int32_t)(uint32_t)var_10ch))
                                {
                                    uVar32 = uVar20;
                                }
                                if ((int32_t)uVar22 <= (int32_t)(uVar32 * var_128h._4_4_) / 100) {
                                    var_168h = CONCAT44(var_168h._4_4_, 
                                                        (int32_t)(*(int64_t *)(arg1 + 0x6a8) -
                                                                  *(int64_t *)(arg1 + 0x6a0) >> 4) * -0x55555555);
                                    uVar23 = uVar13;
                                    func_0x0001800d0a10(*(undefined8 *)arg1, 0x18063f8f0, uVar22, (double)uVar32 / 100.0
                                                       );
                                    var_168h = CONCAT71(var_168h._1_7_, (uint8_t)var_128h);
                                    fcn.1800af490(arg1, arg2, uVar13, in_stack_fffffffffffffed0, 
                                                  CONCAT44(var_128h._4_4_, 
                                                           CONCAT13(var_128h._3_1_, 
                                                                    CONCAT12(var_128h._2_1_, 
                                                                             CONCAT11(var_128h._1_1_, (uint8_t)var_128h)
                                                                            ))), uVar23, arg2, 
                                                  CONCAT44((uint32_t)var_10ch, var_110h));
                                    goto code_r0x0001800b2004;
                                }
                                func_0x0001800d0a10(*(undefined8 *)arg1, 0x18063f8b8, uVar22, (double)uVar32 / 100.0);
                                puVar26 = (uint64_t *)var_d0h;
                                goto code_r0x0001800b12e1;
                            }
                        }
                    }
                }
code_r0x0001800b12d9:
                func_0x0001800d0a10(*(undefined8 *)arg1);
            }
code_r0x0001800b12e1:
            if (*(char *)((int64_t)puVar26 + 0x2c) != '\0') goto code_r0x0001800b1328;
        }
        if ((((*(char *)(uVar13 + 0x70) != '\0') || (puVar26 == (uint64_t *)0x0)) || (*(char *)(arg1 + 0x638) != '\0'))
           || (*(char *)(arg1 + 0x639) != '\0')) {
            func_0x0001800d0a10(*(undefined8 *)arg1);
        }
    }
code_r0x0001800b1328:
    uVar22 = *(uint32_t *)(arg1 + 0x60c);
    uVar32 = *(int32_t *)(arg2 + 0x40) + 1 + (uint32_t)*(uint8_t *)(arg2 + 0x48);
    if (uVar32 < (uint8_t)var_128h) {
        uVar32 = (uint32_t)(uint8_t)var_128h;
    }
    var_10ch._0_4_ = uVar22;
    var_a0h = arg1;
    var_98h._0_4_ = uVar22;
    if ((char)arg_28h == '\0') {
        uVar20 = uVar32 + uVar22;
        if (0xff < uVar20) {
            fcn.1800acea0(arg2 + 0xc, 0x18063fbc0, uVar32, 0xff);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        uVar32 = uVar22 & 0xff;
    } else {
        uVar20 = uVar22 + (uVar32 - (uint8_t)var_128h);
        if (0xff < uVar20) {
            fcn.1800acea0(arg2 + 0xc, 0x18063fbc0, uVar32 - (uint8_t)var_128h, 0xff);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        uVar32 = (uint32_t)(uint8_t)((char)uVar22 - (uint8_t)var_128h);
    }
    *(uint32_t *)(arg1 + 0x60c) = uVar20;
    uVar11 = *(uint32_t *)(arg1 + 0x610);
    if (*(uint32_t *)(arg1 + 0x610) < uVar20) {
        uVar11 = uVar20;
    }
    *(uint32_t *)(arg1 + 0x610) = uVar11;
    var_110h = -1;
    uVar39 = (uint8_t)uVar32;
    if (((0 < *(int32_t *)(arg1 + 8)) && (*(char *)(arg2 + 0x48) == '\0')) &&
       ((*(int64_t *)(arg1 + 0x1b0) != 0 && (arg2 != *(int64_t *)(arg1 + 0x1b8))))) {
        uVar25 = *(int64_t *)(arg1 + 0x1a8) - 1;
        uVar13 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar23 = 0;
        do {
            uVar13 = uVar13 & uVar25;
            piVar38 = (int64_t *)(uVar13 * 0x10 + *(int64_t *)(arg1 + 0x1a0));
            if (*piVar38 == arg2) {
                piVar30 = piVar38 + 1;
                if (piVar38 == (int64_t *)0x0) {
                    piVar30 = (int64_t *)0x0;
                }
                if (piVar30 == (int64_t *)0x0) break;
                iVar12 = *(int32_t *)piVar30;
                if (iVar12 == 0) break;
                if ((-1 < iVar12) && ((*(uint8_t *)(*(int64_t *)arg1 + 0x398) & 0x10) != 0)) {
                    piVar38 = (int64_t *)
                              func_0x0001800aa350((int64_t)&var_10ch + 4, *(undefined8 *)(arg2 + 0x20), arg1 + 0xb0);
                    iVar15 = *piVar38;
                    iVar18 = piVar38[1];
                    if ((*(int64_t *)(arg2 + 0x40) == 0) ||
                       (cVar10 = fcn.1800aeb90(arg1, *(int64_t *)
                                                      (*(int64_t *)(arg2 + 0x38) + -8 + *(int64_t *)(arg2 + 0x40) * 8)),
                       cVar10 == '\0')) {
                        bVar40 = false;
                    } else {
                        bVar40 = true;
                    }
                    if (iVar15 == 0) {
                        if (iVar18 != 0) {
                            var_168h = 0x1805aadb1;
                            if (bVar40) {
                                var_168h = 0x18063cd78;
                            }
                            func_0x0001800d0a10(*(undefined8 *)arg1, 0x18063f848, iVar18);
                        }
                    } else {
                        var_160h = 0x1805aadb1;
                        if (bVar40) {
                            var_160h = 0x18063cd78;
                        }
                        var_168h = CONCAT44(var_168h._4_4_, *(undefined4 *)(arg2 + 0x40));
                        func_0x0001800d0a10(*(undefined8 *)arg1, 0x18063f830, iVar15);
                    }
                }
                if (iVar12 == 0x39) {
                    if (((char)arg_30h == '\0') && ((uint8_t)var_128h == 1)) {
                        uVar3 = **(undefined8 **)(arg2 + 0x38);
                        uVar22 = func_0x0001800b7be0(arg1, uVar3);
                        uVar20 = uVar32 + 1 & 0xff;
                        if ((int32_t)uVar22 < 0) {
                            uVar28 = *(undefined4 *)(arg1 + 0x60c);
                            var_100h._0_4_ = uVar28;
                            *(uint32_t *)(arg1 + 0x60c) = uVar20 + 1;
                            unique0x100016a5 = arg1;
                            func_0x0001800b4ce0(arg1, uVar3, uVar20, 1);
                            *(undefined4 *)(arg1 + 0x60c) = uVar28;
                            uVar22 = uVar20;
                        }
                        iVar15 = *(int64_t *)arg1;
                        iVar18 = *(int64_t *)(iVar15 + 0x30) - *(int64_t *)(iVar15 + 0x28) >> 2;
                        uVar22 = uVar22 & 0xff;
                        var_128h._4_4_ = uVar22 << 0x10 | 0x3949;
                        fcn.1800d31a0((int64_t *)(iVar15 + 0x28), (int64_t)&var_128h + 4);
                        fcn.1800d31a0(iVar15 + 0x40, iVar15 + 0x270);
                        func_0x0001800b4ce0(arg1, *(undefined8 *)(arg2 + 0x20), uVar32, 1);
                        if (uVar22 != uVar32 + 1) {
                            iVar15 = *(int64_t *)arg1;
                            var_128h._4_4_ = (uVar22 << 8 | uVar20) << 8 | 6;
                            fcn.1800d31a0(iVar15 + 0x28, (int64_t)&var_128h + 4);
                            fcn.1800d31a0(iVar15 + 0x40, iVar15 + 0x270);
                        }
                        iVar15 = *(int64_t *)arg1;
                        var_128h._4_4_ = (uVar32 + 2 & 0xff) << 8 | 0x3f;
                        fcn.1800d31a0(iVar15 + 0x28, (int64_t)&var_128h + 4);
                        fcn.1800d31a0(iVar15 + 0x40, iVar15 + 0x270);
                        iVar15 = *(int64_t *)(*(int64_t *)arg1 + 0x28);
                        uVar22 = ((int32_t)(*(int64_t *)(*(int64_t *)arg1 + 0x30) - iVar15 >> 2) - (int32_t)iVar18) - 1;
                        if ((uVar22 & 0xff) != uVar22) {
                            fcn.1800acea0(*(int64_t *)(arg2 + 0x20) + 0xc, 0x18063f7f0);
                            pcVar4 = (code *)swi(3);
                            (*pcVar4)();
                            return;
                        }
                        puVar1 = (uint32_t *)(iVar15 + iVar18 * 4);
                        *puVar1 = *puVar1 | uVar22 * 0x1000000;
                        iVar15 = *(int64_t *)arg1;
                        var_128h._4_4_ = uVar32 << 8 | 0x2000015;
                        fcn.1800d31a0(iVar15 + 0x28, (int64_t)&var_128h + 4);
                        fcn.1800d31a0(iVar15 + 0x40, iVar15 + 0x270);
                        if ((char)arg_28h == '\0') {
                            iVar15 = *(int64_t *)arg1;
                            var_128h._4_4_ = (uVar32 << 8 | (uint32_t)var_128h._1_1_) << 8 | 6;
                            fcn.1800d31a0(iVar15 + 0x28, (int64_t)&var_128h + 4);
                            fcn.1800d31a0(iVar15 + 0x40, iVar15 + 0x270);
                        }
                        goto code_r0x0001800b1ffa;
                    }
                    var_110h = -1;
                } else {
                    var_110h = iVar12;
                    if (iVar12 == 0x22) {
                        if (*(int64_t *)(arg2 + 0x40) == 3) {
                            iVar15 = *(int64_t *)(arg2 + 0x38);
                            uVar3 = *(undefined8 *)(iVar15 + 8);
                            cVar10 = fcn.1800b2930();
                            if (cVar10 != '\0') {
                                uVar2 = *(undefined8 *)(iVar15 + 0x10);
                                cVar10 = fcn.1800b2930();
                                if (cVar10 != '\0') {
                                    func_0x0001800b29d0(arg1, (int64_t)&var_10ch + 4, uVar3);
                                    func_0x0001800b29d0(arg1, &var_d0h, uVar2);
                                    uVar20 = (uint32_t)(double)var_100h;
                                    if (var_10ch._4_4_ != 3) {
                                        uVar20 = 0xffffffff;
                                    }
                                    iVar21 = (int32_t)(double)var_c8h;
                                    if ((int32_t)var_d0h != 3) {
                                        iVar21 = -1;
                                    }
                                    if (((-1 < (int32_t)uVar20) && (0 < iVar21)) && ((int32_t)(iVar21 + uVar20) < 0x21))
                                    {
                                        iVar12 = func_0x0001800cf660(*(undefined8 *)arg1, 
                                                                     (double)(iVar21 * 0x20 - 0x20U | uVar20));
                                        if (iVar12 < 0) {
                                            fcn.1800acea0(arg2 + 0xc, 0x18063f5a0);
                                            pcVar4 = (code *)swi(3);
                                            (*pcVar4)();
                                            return;
                                        }
                                        var_148h = CONCAT44(var_148h._4_4_, iVar12);
                                        var_150h = CONCAT44(var_150h._4_4_, 0x3b);
                                        var_158h = CONCAT71(var_158h._1_7_, uVar39);
                                        var_160h = CONCAT71(var_160h._1_7_, (char)arg_30h);
                                        var_168h = CONCAT71(var_168h._1_7_, (char)arg_28h);
                                        fcn.1800aee60(arg1, arg2, (uint64_t)var_128h._1_1_, (uint64_t)(uint8_t)var_128h
                                                      , var_168h, var_160h, var_158h, var_150h, var_148h);
                                        *(uint32_t *)(arg1 + 0x60c) = uVar22;
                                        goto code_r0x0001800b2004;
                                    }
                                }
                            }
                        }
                    } else if (iVar12 < 0) break;
                    iVar15 = *(int64_t *)(arg2 + 0x40);
                    if (iVar15 == 3) {
                        uVar13 = 0;
                        iVar18 = *(int64_t *)(arg2 + 0x38);
                        goto code_r0x0001800b1870;
                    }
                    if (iVar15 - 1U < 2) goto code_r0x0001800b1959;
                }
                break;
            }
            if (*piVar38 == *(int64_t *)(arg1 + 0x1b8)) break;
            uVar13 = uVar13 + 1 + uVar23;
            uVar23 = uVar23 + 1;
        } while (uVar23 <= uVar25);
    }
    goto code_r0x0001800b1902;
code_r0x0001800b1959:
    cVar10 = fcn.1800aeb90(arg1, *(int64_t *)(*(int64_t *)(arg2 + 0x38) + -8 + iVar15 * 8));
    if ((cVar10 == '\0') ||
       (((1 < *(int32_t *)(arg1 + 8) &&
         (piVar19 = (int32_t *)fcn.1800ac390((int64_t)&var_10ch + 4, iVar12), *(int32_t *)(arg2 + 0x40) == *piVar19)) &&
        ((*(uint8_t *)(piVar19 + 2) & 1) != 0)))) {
        var_148h = CONCAT44(var_148h._4_4_, 0xffffffff);
        var_150h = CONCAT44(var_150h._4_4_, iVar12);
        var_158h = CONCAT71(var_158h._1_7_, uVar39);
        var_160h = CONCAT71(var_160h._1_7_, (char)arg_30h);
        var_168h = CONCAT71(var_168h._1_7_, (char)arg_28h);
        fcn.1800aee60(arg1, arg2, (uint64_t)var_128h._1_1_, (uint64_t)(uint8_t)var_128h, var_168h, var_160h, var_158h, 
                      var_150h, var_148h);
        *(uint32_t *)(arg1 + 0x60c) = uVar22;
        goto code_r0x0001800b2004;
    }
    goto code_r0x0001800b1902;
code_r0x0001800b1870:
    do {
        iVar24 = *(int64_t *)(iVar18 + uVar13 * 8);
        if (*(char *)0x180777f78 == '\0') {
            iVar21 = *(int32_t *)(iVar24 + 8);
            iVar17 = 0;
            if (iVar21 == *(int32_t *)0x180782728) {
                iVar17 = iVar24;
            }
            if (iVar17 != 0) goto code_r0x0001800b18ca;
            iVar17 = 0;
            if (iVar21 == *(int32_t *)0x1807826c0) {
                iVar17 = iVar24;
            }
            if (iVar17 != 0) {
code_r0x0001800b18bc:
                iVar17 = func_0x0001800b7b80();
                goto code_r0x0001800b18c5;
            }
            iVar17 = 0;
            if (iVar21 == *(int32_t *)0x180782708) {
                iVar17 = iVar24;
            }
            if (iVar17 != 0) goto code_r0x0001800b18bc;
        } else {
            iVar17 = func_0x0001800beb60();
code_r0x0001800b18c5:
            if (iVar17 != 0) {
code_r0x0001800b18ca:
                iVar17 = func_0x0001800ac770(arg1 + 0x88, iVar17 + 0x20);
                iVar24 = iVar17 + 8;
                if (iVar17 == 0) {
                    iVar24 = 0;
                }
                if ((iVar24 != 0) && (*(char *)(iVar24 + 1) != '\0')) goto code_r0x0001800b1959;
            }
        }
        uVar13 = uVar13 + 1;
    } while (uVar13 < 3);
code_r0x0001800b1902:
    if (*(char *)(arg2 + 0x48) == '\0') {
        var_128h._2_1_ = 0;
        if (var_110h < 0) {
            uVar3 = *(undefined8 *)(arg2 + 0x20);
            uVar28 = *(undefined4 *)(arg1 + 0x60c);
            var_100h._0_4_ = uVar28;
            *(uint32_t *)(arg1 + 0x60c) = uVar32 + 1;
            unique0x100016ad = arg1;
            func_0x0001800b4ce0(arg1, uVar3, uVar32);
            goto code_r0x0001800b1ab9;
        }
    } else {
        iVar15 = 0;
        if (*(int32_t *)(*(int64_t *)(arg2 + 0x20) + 8) == *(int32_t *)0x18078269c) {
            iVar15 = *(int64_t *)(arg2 + 0x20);
        }
        iVar15 = *(int64_t *)(iVar15 + 0x20);
        if (*(char *)0x180777f78 == '\0') {
            iVar12 = *(int32_t *)(iVar15 + 8);
            iVar18 = 0;
            if (iVar12 == *(int32_t *)0x180782728) {
                iVar18 = iVar15;
            }
            if (iVar18 != 0) goto code_r0x0001800b1a1d;
            iVar18 = 0;
            if (iVar12 == *(int32_t *)0x1807826c0) {
                iVar18 = iVar15;
            }
            if (iVar18 != 0) {
code_r0x0001800b1a0f:
                iVar18 = func_0x0001800b7b80(iVar12, *(undefined8 *)(iVar18 + 0x20));
                goto code_r0x0001800b1a18;
            }
            if (iVar12 == *(int32_t *)0x180782708) {
                iVar18 = iVar15;
            }
            if (iVar18 != 0) goto code_r0x0001800b1a0f;
        } else {
            iVar18 = func_0x0001800beb60(iVar15);
code_r0x0001800b1a18:
            if (iVar18 != 0) {
code_r0x0001800b1a1d:
                iVar18 = func_0x0001800ac770(arg1 + 0x88, iVar18 + 0x20);
                puVar27 = (uint8_t *)(iVar18 + 8);
                if (iVar18 == 0) {
                    puVar27 = (uint8_t *)0x0;
                }
                if ((puVar27 != (uint8_t *)0x0) && (puVar27[1] != 0)) {
                    var_128h._2_1_ = *puVar27;
                    goto code_r0x0001800b1abf;
                }
            }
        }
        uVar28 = *(undefined4 *)(arg1 + 0x60c);
        var_100h._0_4_ = uVar28;
        *(uint32_t *)(arg1 + 0x60c) = uVar32 + 1;
        var_128h._2_1_ = uVar39;
        unique0x100016b5 = arg1;
        func_0x0001800b4ce0(arg1, iVar15, uVar32);
code_r0x0001800b1ab9:
        *(undefined4 *)(arg1 + 0x60c) = uVar28;
    }
code_r0x0001800b1abf:
    bVar40 = false;
    uVar13 = *(uint64_t *)(arg2 + 0x40);
    if (uVar13 != 0) {
        uVar23 = 0;
        bVar40 = false;
        do {
            uVar25 = uVar23 + 1;
            uVar31 = (char)uVar23 + '\x01' + uVar39 + *(char *)(arg2 + 0x48);
            iVar15 = *(int64_t *)(*(int64_t *)(arg2 + 0x38) + uVar23 * 8);
            if (uVar25 == uVar13) {
                iVar18 = 0;
                if (*(int32_t *)(iVar15 + 8) == *(int32_t *)0x180782740) {
                    iVar18 = iVar15;
                }
                if (iVar18 == 0) {
                    iVar18 = 0;
                    if (*(int32_t *)(iVar15 + 8) == *(int32_t *)0x1807826b8) {
                        iVar18 = iVar15;
                    }
                    if (iVar18 != 0) {
                        uVar28 = *(undefined4 *)(arg1 + 0x60c);
                        var_c8h = CONCAT44(var_c8h._4_4_, uVar28);
                        *(uint32_t *)(arg1 + 0x60c) = (uint32_t)uVar31;
                        if (0 < *(int32_t *)(arg1 + 0xc)) {
                            *(int32_t *)(*(int64_t *)arg1 + 0x270) = *(int32_t *)(iVar18 + 0xc) + 1;
                        }
                        iVar15 = *(int64_t *)arg1;
                        var_128h._4_4_ = (uint32_t)uVar31 << 8 | 0x3f;
                        var_d0h = arg1;
                        fcn.1800d31a0(iVar15 + 0x28, (int64_t)&var_128h + 4);
                        fcn.1800d31a0(iVar15 + 0x40, iVar15 + 0x270);
                        *(undefined4 *)(arg1 + 0x60c) = uVar28;
                        bVar40 = true;
                        goto code_r0x0001800b1c1e;
                    }
                } else if ((*(int32_t *)(arg1 + 8) < 2) || (cVar10 = fcn.1800aeb90(arg1, iVar15), cVar10 != '\0')) {
                    uVar28 = *(undefined4 *)(arg1 + 0x60c);
                    var_100h._0_4_ = uVar28;
                    *(uint32_t *)(arg1 + 0x60c) = (uint32_t)uVar31;
                    var_160h = CONCAT71(var_160h._1_7_, 1);
                    var_168h = CONCAT71(var_168h._1_7_, 1);
                    unique0x100016bd = arg1;
                    fcn.1800b0700(arg1, iVar18, (uint64_t)uVar31, 0, var_168h, var_160h, 
                                  CONCAT44(var_128h._4_4_, 
                                           CONCAT13(var_128h._3_1_, 
                                                    CONCAT12(var_128h._2_1_, CONCAT11(var_128h._1_1_, (uint8_t)var_128h)
                                                            ))));
                    bVar40 = true;
                    goto code_r0x0001800b1c18;
                }
                func_0x0001800b4ce0(arg1, iVar15, uVar31);
                bVar40 = false;
            } else {
                uVar28 = *(undefined4 *)(arg1 + 0x60c);
                *(uint32_t *)(arg1 + 0x60c) = uVar31 + 1;
                var_b0h = arg1;
                var_a8h._0_4_ = uVar28;
                func_0x0001800b4ce0(arg1, iVar15, uVar31);
code_r0x0001800b1c18:
                *(undefined4 *)(arg1 + 0x60c) = uVar28;
            }
code_r0x0001800b1c1e:
            uVar13 = *(uint64_t *)(arg2 + 0x40);
            uVar23 = uVar25;
        } while (uVar25 < uVar13);
    }
    if (0 < *(int32_t *)(arg1 + 0xc)) {
        *(int32_t *)(*(int64_t *)arg1 + 0x270) = *(int32_t *)(*(int64_t *)(arg2 + 0x20) + 0x14) + 1;
    }
    if (*(char *)(arg2 + 0x48) == '\0') {
        if (-1 < var_110h) {
            iVar15 = *(int64_t *)arg1;
            iVar18 = *(int64_t *)(iVar15 + 0x30) - *(int64_t *)(iVar15 + 0x28) >> 2;
            fcn.1800d31a0((int64_t *)(iVar15 + 0x28), &stack0xfffffffffffffee0);
            fcn.1800d31a0(iVar15 + 0x40, iVar15 + 0x270);
            func_0x0001800b4ce0(arg1, *(undefined8 *)(arg2 + 0x20), uVar32, 1);
            iVar15 = *(int64_t *)(*(int64_t *)arg1 + 0x28);
            uVar22 = ((int32_t)(*(int64_t *)(*(int64_t *)arg1 + 0x30) - iVar15 >> 2) - (int32_t)iVar18) - 1;
            if ((uVar22 & 0xff) != uVar22) {
                fcn.1800acea0(*(int64_t *)(arg2 + 0x20) + 0xc, 0x18063f7f0);
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            puVar1 = (uint32_t *)(iVar15 + iVar18 * 4);
            *puVar1 = *puVar1 | uVar22 * 0x1000000;
        }
    } else {
        iVar15 = 0;
        if (*(int32_t *)(*(int64_t *)(arg2 + 0x20) + 8) == *(int32_t *)0x18078269c) {
            iVar15 = *(int64_t *)(arg2 + 0x20);
        }
        if (0 < *(int32_t *)(arg1 + 0xc)) {
            *(int32_t *)(*(int64_t *)arg1 + 0x270) = *(int32_t *)(iVar15 + 0x30) + 1;
        }
        iVar18 = *(int64_t *)(iVar15 + 0x28);
        uVar13 = func_0x000180498cd0(iVar18);
        uVar3 = *(undefined8 *)arg1;
        var_100h = uVar13;
        unique0x100016c5 = iVar18;
        var_100h._0_4_ = func_0x0001800cf010(uVar3, (int64_t)&var_10ch + 4);
        stack0xfffffffffffffef8 = CONCAT44(uStack_104, 5);
        stack0xffffffffffffff04 = SUB1612(ZEXT816(0), 4);
        var_d0h = CONCAT44(var_d0h._4_4_, 5);
        var_c8h = (int64_t)(uint32_t)var_100h;
        var_c0h = 0;
        iVar12 = func_0x0001800ced20(uVar3, &var_d0h, (int64_t)&var_10ch + 4);
        if (iVar12 < 0) {
            fcn.1800acea0(iVar15 + 0xc, 0x18063f5a0);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        var_d0h = *(int64_t *)arg1;
        uVar23 = uVar13;
        for (; uVar22 = (uint32_t)uVar23, uVar13 != 0; uVar13 = uVar13 - 1) {
            uVar23 = (uint64_t)
                     (uVar22 ^ (uint32_t)*(uint8_t *)((uVar13 - 1) + iVar18) + uVar22 * 0x20 +
                               ((uint32_t)(uVar23 >> 2) & 0x3fffffff));
        }
        uVar20 = (uint32_t)var_128h._2_1_;
        var_128h._4_4_ = (((uVar22 & 0xff) << 8 | uVar20) << 8 | uVar32) << 8 | 0x14;
        fcn.1800d31a0(var_d0h + 0x28, (int64_t)&var_128h + 4);
        fcn.1800d31a0(var_d0h + 0x40, var_d0h + 0x270);
        iVar18 = *(int64_t *)arg1;
        fcn.1800d31a0(iVar18 + 0x28, &stack0xfffffffffffffee0);
        fcn.1800d31a0(iVar18 + 0x40, iVar18 + 0x270);
        var_168h = CONCAT44(var_168h._4_4_, 2);
        func_0x0001800bbfb0(arg1, *(undefined8 *)(iVar15 + 0x20), uVar20, 4);
    }
    if (((*(int64_t *)(*(int64_t *)(arg1 + 0x628) + 0x98) == 0) || (bVar40)) || ((char)arg_30h != '\0')) {
        bVar40 = false;
    } else {
        bVar40 = true;
    }
    if (((*(char *)0x180777e98 == '\0') || (-1 < var_110h)) || (!bVar40)) {
        iVar15 = *(int64_t *)arg1;
    } else {
        fcn.1800d31a0(*(int64_t *)arg1 + 0xd0, &stack0xfffffffffffffee0);
        iVar15 = *(int64_t *)arg1;
        fcn.1800d31a0(iVar15 + 0x28, &stack0xfffffffffffffee0);
        fcn.1800d31a0(iVar15 + 0x40, iVar15 + 0x270);
        iVar15 = *(int64_t *)arg1;
    }
    fcn.1800d31a0(iVar15 + 0x28, &stack0xfffffffffffffee0);
    fcn.1800d31a0(iVar15 + 0x40, iVar15 + 0x270);
    if ((char)arg_28h == '\0') {
        uVar23 = (uint64_t)(uint8_t)var_128h;
        uVar13 = 0;
        if (uVar23 != 0) {
            do {
                iVar15 = *(int64_t *)arg1;
                fcn.1800d31a0(iVar15 + 0x28, &stack0xfffffffffffffee0);
                fcn.1800d31a0(iVar15 + 0x40, iVar15 + 0x270);
                uVar13 = uVar13 + 1;
            } while (uVar13 < uVar23);
        }
    }
code_r0x0001800b1ffa:
    *(uint32_t *)(arg1 + 0x60c) = (uint32_t)var_10ch;
code_r0x0001800b2004:
    func_0x000180459870(var_70h ^ (uint64_t)auStackY_188);
    return;
}

// ============================================================
// Function: FUN_1800b20d0
// Address: 0x1800b20d0
// Size: 405 bytes
// ============================================================
undefined8 fcn.1800b20d0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    uint64_t *puVar2;
    uint64_t uVar3;
    int32_t iVar4;
    char cVar5;
    uint64_t uVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    int64_t arg2_00;
    uint64_t *puVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    
    iVar4 = *(int32_t *)0x1807826a0;
    if ((*(int64_t *)(arg1 + 0x70) != 0) && (arg2 != *(int64_t *)(arg1 + 0x78))) {
        uVar11 = *(int64_t *)(arg1 + 0x68) - 1;
        uVar10 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar6 = 0;
        do {
            uVar10 = uVar10 & uVar11;
            piVar8 = (int64_t *)(uVar10 * 0x38 + *(int64_t *)(arg1 + 0x60));
            if (*piVar8 == arg2) {
                piVar7 = piVar8 + 1;
                if (piVar8 == (int64_t *)0x0) {
                    piVar7 = (int64_t *)0x0;
                }
                if (piVar7 == (int64_t *)0x0) {
                    return 0;
                }
                puVar9 = (uint64_t *)piVar7[1];
                puVar2 = (uint64_t *)piVar7[2];
                if (puVar9 == puVar2) {
                    return 1;
                }
                do {
                    if (*(int64_t *)(arg1 + 0xe8) == 0) {
                        return 0;
                    }
                    uVar6 = *puVar9;
                    if (uVar6 == *(uint64_t *)(arg1 + 0xf0)) {
                        return 0;
                    }
                    uVar12 = *(int64_t *)(arg1 + 0xe0) - 1;
                    uVar10 = (uVar6 >> 5 ^ uVar6) >> 4;
                    uVar11 = 0;
                    while( true ) {
                        uVar10 = uVar10 & uVar12;
                        iVar1 = *(int64_t *)(arg1 + 0xd8) + uVar10 * 0x18;
                        uVar3 = *(uint64_t *)(*(int64_t *)(arg1 + 0xd8) + uVar10 * 0x18);
                        if (uVar3 == uVar6) break;
                        if (uVar3 == *(uint64_t *)(arg1 + 0xf0)) {
                            return 0;
                        }
                        uVar10 = uVar10 + uVar11 + 1;
                        uVar11 = uVar11 + 1;
                        if (uVar12 < uVar11) {
                            return 0;
                        }
                    }
                    piVar8 = (int64_t *)(iVar1 + 8);
                    if (iVar1 == 0) {
                        piVar8 = (int64_t *)0x0;
                    }
                    if (piVar8 == (int64_t *)0x0) {
                        return 0;
                    }
                    if (*(char *)(piVar8 + 1) != '\0') {
                        return 0;
                    }
                    if ((*(int64_t *)(uVar6 + 0x20) != 0) || (*(int64_t *)(uVar6 + 0x28) != 0)) {
                        iVar1 = *piVar8;
                        if (iVar1 == 0) {
                            return 0;
                        }
                        arg2_00 = 0;
                        if (*(int32_t *)(iVar1 + 8) == iVar4) {
                            arg2_00 = iVar1;
                        }
                        if (arg2_00 == 0) {
                            return 0;
                        }
                        if ((arg2_00 != arg2) && (cVar5 = fcn.1800b20d0(arg1, arg2_00), cVar5 == '\0')) {
                            return 0;
                        }
                    }
                    puVar9 = puVar9 + 1;
                    if (puVar9 == puVar2) {
                        return 1;
                    }
                } while( true );
            }
            if (*piVar8 == *(int64_t *)(arg1 + 0x78)) {
                return 0;
            }
            uVar10 = uVar10 + 1 + uVar6;
            uVar6 = uVar6 + 1;
        } while (uVar6 <= uVar11);
    }
    return 0;
}

// ============================================================
// Function: FUN_1800b2270
// Address: 0x1800b2270
// Size: 1720 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_fh
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_dh

void fcn.1800b2270(int64_t arg1, int64_t arg2, uint64_t placeholder_2, int64_t arg4)
{
    uint64_t *puVar1;
    uint8_t uVar2;
    uint32_t uVar3;
    uint64_t uVar4;
    uint32_t *puVar5;
    undefined8 uVar6;
    undefined *puVar7;
    code *pcVar8;
    char cVar9;
    uint8_t uVar10;
    int16_t iVar11;
    uint32_t uVar12;
    uint32_t uVar13;
    int64_t iVar14;
    uint64_t uVar15;
    int32_t *piVar16;
    uint64_t uVar17;
    uint64_t uVar18;
    undefined *puVar19;
    undefined *puVar20;
    int64_t iVar21;
    int64_t iVar22;
    uint64_t uVar23;
    int64_t *piVar24;
    uint32_t *puVar25;
    undefined uVar26;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_d8 [8];
    undefined auStack_d0 [24];
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    
    var_18h._0_1_ = (uint8_t)placeholder_2;
    var_b8h._0_4_ = *(undefined4 *)(arg1 + 0x60c);
    if ((*(int64_t *)(arg1 + 0x70) != 0) && (arg2 != *(int64_t *)(arg1 + 0x78))) {
        placeholder_2 = *(int64_t *)(arg1 + 0x68) - 1;
        uVar15 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar17 = 0;
        do {
            arg4 = (uVar15 & placeholder_2) * 0x38;
            iVar22 = *(int64_t *)(arg4 + *(int64_t *)(arg1 + 0x60));
            if (iVar22 == arg2) {
                puVar25 = (uint32_t *)(*(int64_t *)(arg1 + 0x60) + 8 + arg4);
                goto code_r0x0001800b2306;
            }
            if (iVar22 == *(int64_t *)(arg1 + 0x78)) break;
            uVar15 = (uVar15 & placeholder_2) + 1 + uVar17;
            uVar17 = uVar17 + 1;
        } while (uVar17 <= placeholder_2);
    }
    puVar25 = (uint32_t *)0x0;
code_r0x0001800b2306:
    var_10h = arg2;
    var_b0h = (int64_t)puVar25;
    var_58h = arg1;
    var_50h._0_4_ = (undefined4)var_b8h;
    iVar11 = func_0x0001800cfb90(*(undefined8 *)arg1, *puVar25, placeholder_2, arg4);
    var_8h._0_4_ = CONCAT22(var_8h._2_2_, iVar11);
    if (iVar11 < 0) {
        fcn.1800acea0(arg2 + 0xc, 0x18063f858);
        pcVar8 = (code *)swi(3);
        (*pcVar8)();
        return;
    }
    piVar24 = (int64_t *)(arg1 + 0x6b8);
    iVar22 = *piVar24;
    iVar21 = *(int64_t *)(arg1 + 0x6c0);
    if (iVar22 != iVar21) {
        *(int64_t *)(arg1 + 0x6c0) = iVar22;
        iVar21 = iVar22;
    }
    uVar15 = *(int64_t *)(puVar25 + 4) - *(int64_t *)(puVar25 + 2) >> 3;
    iVar22 = *piVar24;
    if ((uint64_t)(*(int64_t *)(arg1 + 0x6c8) - iVar22 >> 3) < uVar15) {
        if (0x1fffffffffffffff < uVar15) {
code_r0x0001800b2922:
            fcn.180010010();
            pcVar8 = (code *)swi(3);
            (*pcVar8)();
            return;
        }
        uVar17 = uVar15 * 8;
        if (uVar17 == 0) {
            uVar17 = 0;
code_r0x0001800b23d1:
            fcn.180498030(uVar17, *piVar24, *(int64_t *)(arg1 + 0x6c0) - *piVar24);
            func_0x0001800c2120(piVar24, uVar17, iVar21 - iVar22 >> 3, uVar15);
            puVar25 = (uint32_t *)var_b0h;
            goto code_r0x0001800b2401;
        }
        if (uVar17 < 0x1000) {
            uVar17 = fcn.180459890();
            goto code_r0x0001800b23d1;
        }
        if (uVar17 + 0x27 <= uVar17) {
code_r0x0001800b291c:
            fcn.180004720();
            pcVar8 = (code *)swi(3);
            (*pcVar8)();
            return;
        }
        iVar14 = fcn.180459890(uVar17 + 0x27);
        if (iVar14 != 0) {
            uVar17 = iVar14 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar17 - 8) = iVar14;
            goto code_r0x0001800b23d1;
        }
code_r0x0001800b2823:
        pcVar8 = (code *)swi(0x29);
        (*pcVar8)(5);
        puVar19 = auStack_d0;
    } else {
code_r0x0001800b2401:
        var_98h = *(int64_t *)(puVar25 + 2);
        var_90h = *(int64_t *)(puVar25 + 4);
        uVar26 = var_8h._7_1_;
        if (var_98h != var_90h) {
code_r0x0001800b2420:
            uVar15 = *(uint64_t *)var_98h;
            if ((*(int64_t *)(arg1 + 0x98) != 0) && (uVar15 != *(uint64_t *)(arg1 + 0xa0))) {
                uVar23 = *(int64_t *)(arg1 + 0x90) - 1;
                uVar17 = (uVar15 >> 5 ^ uVar15) >> 4;
                uVar18 = 0;
                do {
                    uVar17 = uVar17 & uVar23;
                    puVar1 = (uint64_t *)(*(int64_t *)(arg1 + 0x88) + uVar17 * 0x18);
                    if (*puVar1 == uVar15) {
                        if ((puVar1 + 1 != (uint64_t *)0x0) && (*(char *)((int64_t)puVar1 + 9) != '\0')) {
                            uVar2 = *(uint8_t *)(puVar1 + 1);
                            var_20h._0_4_ = (uint32_t)uVar2;
                            if ((*(int64_t *)(arg1 + 0xe8) == 0) || (uVar15 == *(uint64_t *)(arg1 + 0xf0)))
                            goto code_r0x0001800b2646;
                            uVar23 = *(int64_t *)(arg1 + 0xe0) - 1;
                            uVar17 = (uVar15 >> 5 ^ uVar15) >> 4;
                            uVar18 = 0;
                            goto code_r0x0001800b2620;
                        }
                        break;
                    }
                    if (*puVar1 == *(uint64_t *)(arg1 + 0xa0)) break;
                    uVar17 = uVar17 + 1 + uVar18;
                    uVar18 = uVar18 + 1;
                } while (uVar18 <= uVar23);
            }
            if ((*(int64_t *)(arg1 + 0x138) != 0) && (uVar15 != *(uint64_t *)(arg1 + 0x140))) {
                uVar23 = *(int64_t *)(arg1 + 0x130) - 1;
                uVar17 = (uVar15 >> 5 ^ uVar15) >> 4;
                uVar18 = 0;
                do {
                    uVar17 = uVar17 & uVar23;
                    iVar22 = uVar17 * 0x20;
                    uVar4 = *(uint64_t *)(iVar22 + *(int64_t *)(arg1 + 0x128));
                    if (uVar4 == uVar15) {
                        piVar16 = (int32_t *)(*(int64_t *)(arg1 + 0x128) + 8 + iVar22);
                        if ((piVar16 != (int32_t *)0x0) && (*piVar16 != 0)) {
                            uVar3 = *(uint32_t *)(arg1 + 0x60c);
                            uVar12 = uVar3 + 1;
                            if (0xff < uVar12) {
                                fcn.1800acea0(arg2 + 0xc, 0x18063fbc0, 1, 0xff);
                                pcVar8 = (code *)swi(3);
                                (*pcVar8)();
                                return;
                            }
                            *(uint32_t *)(arg1 + 0x60c) = uVar12;
                            uVar13 = *(uint32_t *)(arg1 + 0x610);
                            if (*(uint32_t *)(arg1 + 0x610) < uVar12) {
                                uVar13 = uVar12;
                            }
                            *(uint32_t *)(arg1 + 0x610) = uVar13;
                            func_0x0001800b4ae0(arg1, arg2, piVar16, uVar3 & 0xff);
                            var_a8h._0_4_ = 0;
                            var_a8h._4_1_ = (undefined)uVar3;
                            goto code_r0x0001800b2513;
                        }
                        break;
                    }
                    if (uVar4 == *(uint64_t *)(arg1 + 0x140)) break;
                    uVar17 = uVar17 + 1 + uVar18;
                    uVar18 = uVar18 + 1;
                } while (uVar18 <= uVar23);
            }
            var_a0h._4_1_ = fcn.1800ad020(arg1, uVar15);
            var_a0h._0_4_ = 2;
code_r0x0001800b2513:
            fcn.1800bf890(arg1 + 0x6b8);
            goto code_r0x0001800b251b;
        }
code_r0x0001800b2535:
        piVar24 = (int64_t *)(arg1 + 0x6b8);
        puVar19 = auStack_d8;
        if (((0 < *(int32_t *)(arg1 + 8)) && (cVar9 = fcn.1800b20d0(arg1, arg2), puVar19 = auStack_d8, cVar9 != '\0'))
           && (puVar19 = auStack_d8, *(char *)(arg1 + 0x639) == '\0')) {
            var_68h = (int64_t)*puVar25;
            var_88h._0_4_ = 8;
            stack0xffffffffffffff84 = SUB1612(ZEXT816(0), 4);
            var_80h._0_4_ = *puVar25;
            var_70h._0_4_ = 8;
            var_60h = 0;
            uVar12 = func_0x0001800ced20(*(undefined8 *)arg1, &var_70h, &var_88h);
            puVar19 = auStack_d8;
            if ((uVar12 < 0x8000) && (puVar19 = auStack_d8, -1 < (int16_t)uVar12)) {
                var_8h._0_4_ = ((uVar12 & 0xffff) << 8 | (uint32_t)(uint8_t)var_18h) << 8 | 0x40;
                puVar19 = auStack_d8;
                goto code_r0x0001800b2859;
            }
        }
    }
    iVar22 = piVar24[1];
    iVar21 = *piVar24;
    uVar6 = *(undefined8 *)arg1;
    *(undefined8 *)(puVar19 + -8) = 0x1800b2846;
    func_0x0001800d0a10(uVar6, 0x18063f890, iVar22 - iVar21 >> 3);
    var_8h._0_4_ = (uint32_t)CONCAT21((undefined2)var_8h, (uint8_t)var_18h) << 8 | 0x13;
code_r0x0001800b2859:
    iVar22 = *(int64_t *)arg1;
    *(undefined8 *)(puVar19 + -8) = 0x1800b286c;
    fcn.1800d31a0(iVar22 + 0x28, &var_8h);
    *(undefined8 *)(puVar19 + -8) = 0x1800b287f;
    fcn.1800d31a0(iVar22 + 0x40, iVar22 + 0x270);
    puVar7 = (undefined *)piVar24[1];
    for (puVar20 = (undefined *)*piVar24; puVar20 != puVar7; puVar20 = puVar20 + 8) {
        iVar22 = *(int64_t *)arg1;
        var_8h._0_4_ = (uint32_t)CONCAT11(puVar20[4], *puVar20) << 8 | 0x1000046;
        *(undefined8 *)(puVar19 + -8) = 0x1800b28b8;
        fcn.1800d31a0(iVar22 + 0x28, &var_8h);
        *(undefined8 *)(puVar19 + -8) = 0x1800b28c8;
        fcn.1800d31a0(iVar22 + 0x40, iVar22 + 0x270);
    }
    *(undefined4 *)(arg1 + 0x60c) = (undefined4)var_b8h;
    return;
    while( true ) {
        if (*puVar1 == *(uint64_t *)(arg1 + 0xf0)) break;
        uVar17 = uVar17 + 1 + uVar18;
        uVar18 = uVar18 + 1;
        if (uVar23 < uVar18) break;
code_r0x0001800b2620:
        uVar17 = uVar17 & uVar23;
        puVar1 = (uint64_t *)(*(int64_t *)(arg1 + 0xd8) + uVar17 * 0x18);
        if (*puVar1 == uVar15) {
            if ((puVar1 != (uint64_t *)0xfffffffffffffff8) && (*(char *)(puVar1 + 2) != '\0')) {
                uVar10 = 1;
                goto code_r0x0001800b2648;
            }
            break;
        }
    }
code_r0x0001800b2646:
    uVar10 = 0;
code_r0x0001800b2648:
    piVar24 = (int64_t *)(uint64_t)uVar10;
    puVar25 = *(uint32_t **)(arg1 + 0x6c0);
    if (puVar25 == *(uint32_t **)(arg1 + 0x6c8)) {
        iVar22 = (int64_t)puVar25 - *(int64_t *)(arg1 + 0x6b8) >> 3;
        if (iVar22 == 0x1fffffffffffffff) goto code_r0x0001800b2922;
        uVar15 = (int64_t)*(uint32_t **)(arg1 + 0x6c8) - *(int64_t *)(arg1 + 0x6b8) >> 3;
        if (0x1fffffffffffffff - (uVar15 >> 1) < uVar15) goto code_r0x0001800b291c;
        uVar17 = iVar22 + 1;
        uVar15 = (uVar15 >> 1) + uVar15;
        uVar18 = uVar17;
        if (uVar17 <= uVar15) {
            uVar18 = uVar15;
        }
        if (0x1fffffffffffffff < uVar18) goto code_r0x0001800b291c;
        uVar15 = uVar18 * 8;
        if (uVar15 == 0) {
            uVar15 = 0;
        } else if (uVar15 < 0x1000) {
            uVar15 = fcn.180459890();
        } else {
            if (uVar15 + 0x27 <= uVar15) goto code_r0x0001800b291c;
            iVar21 = fcn.180459890(uVar15 + 0x27);
            if (iVar21 == 0) goto code_r0x0001800b2823;
            uVar15 = iVar21 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar15 - 8) = iVar21;
        }
        *(uint32_t *)(uVar15 + iVar22 * 8) = (uint32_t)uVar10;
        *(char *)(uVar15 + 4 + iVar22 * 8) = (char)(uint32_t)var_20h;
        *(undefined2 *)(uVar15 + 5 + iVar22 * 8) = var_8h._5_2_;
        *(undefined *)(uVar15 + 7 + iVar22 * 8) = var_8h._7_1_;
        puVar5 = *(uint32_t **)(arg1 + 0x6b8);
        if (puVar25 == *(uint32_t **)(arg1 + 0x6c0)) {
            iVar21 = (int64_t)*(uint32_t **)(arg1 + 0x6c0) - (int64_t)puVar5;
            uVar23 = uVar15;
            puVar25 = puVar5;
        } else {
            fcn.180498030(uVar15, puVar5, (int64_t)puVar25 - (int64_t)puVar5);
            iVar21 = *(int64_t *)(arg1 + 0x6c0) - (int64_t)puVar25;
            uVar23 = uVar15 + (iVar22 + 1) * 8;
        }
        fcn.180498030(uVar23, puVar25, iVar21);
        func_0x0001800c2120((uint32_t **)(arg1 + 0x6b8), uVar15, uVar17, uVar18);
        arg2 = var_10h;
        uVar26 = var_8h._7_1_;
    } else {
        *puVar25 = (uint32_t)uVar10;
        *(uint8_t *)(puVar25 + 1) = uVar2;
        *(undefined2 *)((int64_t)puVar25 + 5) = var_8h._5_2_;
        *(undefined *)((int64_t)puVar25 + 7) = uVar26;
        *(int64_t *)(arg1 + 0x6c0) = *(int64_t *)(arg1 + 0x6c0) + 8;
    }
code_r0x0001800b251b:
    var_98h = var_98h + 8;
    puVar25 = (uint32_t *)var_b0h;
    if (var_98h == var_90h) goto code_r0x0001800b2535;
    goto code_r0x0001800b2420;
}

// ============================================================
// Function: FUN_1800b2930
// Address: 0x1800b2930
// Size: 158 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1800b2930(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t *in_RAX;
    int64_t *piVar2;
    uint64_t uVar3;
    int64_t *piVar4;
    uint64_t uVar5;
    int64_t var_8h;
    
    if ((*(int64_t *)(arg1 + 0x110) != 0) && (arg2 != *(int64_t *)(arg1 + 0x118))) {
        uVar5 = *(int64_t *)(arg1 + 0x108) - 1;
        in_RAX = (int64_t *)(((uint64_t)arg2 >> 5 ^ arg2) >> 4 & uVar5);
        uVar3 = 0;
        do {
            piVar4 = (int64_t *)((int64_t)in_RAX * 0x20 + *(int64_t *)(arg1 + 0x100));
            if (*piVar4 == arg2) {
                in_RAX = (int64_t *)0x0;
                piVar2 = piVar4 + 1;
                if (piVar4 == (int64_t *)0x0) {
                    piVar2 = in_RAX;
                }
                if ((piVar2 != (int64_t *)0x0) && (*(int32_t *)piVar2 != 0)) {
                    return 1;
                }
                break;
            }
            if (*piVar4 == *(int64_t *)(arg1 + 0x118)) break;
            iVar1 = uVar3 + 1;
            uVar3 = uVar3 + 1;
            in_RAX = (int64_t *)((int64_t)in_RAX + iVar1 & uVar5);
        } while (uVar3 <= uVar5);
    }
    return (uint64_t)in_RAX & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800b29d0
// Address: 0x1800b29d0
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.1800b29d0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t *piVar2;
    uint64_t uVar3;
    int64_t *piVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t var_8h;
    int64_t var_10h;
    undefined4 uStack_28;
    undefined4 uStack_24;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(int64_t *)(arg1 + 0x110) == 0) {
        piVar2 = (int64_t *)0x0;
    } else if (arg3 == *(int64_t *)(arg1 + 0x118)) {
        piVar2 = (int64_t *)0x0;
    } else {
        piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x108) + -1);
        uVar3 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
        piVar5 = (int64_t *)0x0;
        piVar4 = piVar5;
        do {
            uVar3 = uVar3 & (uint64_t)piVar6;
            piVar2 = (int64_t *)(uVar3 * 0x20 + *(int64_t *)(arg1 + 0x100));
            iVar1 = *piVar2;
            if ((iVar1 == arg3) || (piVar2 = piVar5, iVar1 == *(int64_t *)(arg1 + 0x118))) break;
            uVar3 = uVar3 + 1 + (int64_t)piVar4;
            piVar4 = (int64_t *)((int64_t)piVar4 + 1);
        } while (piVar4 <= piVar6);
    }
    piVar4 = piVar2 + 1;
    if (piVar2 == (int64_t *)0x0) {
        piVar4 = (int64_t *)0x0;
    }
    if (piVar4 == (int64_t *)0x0) {
        uStack_28 = 0;
        uStack_24 = 0;
        _var_20h = ZEXT816(0);
    } else {
        uStack_28 = *(undefined4 *)piVar4;
        uStack_24 = *(undefined4 *)((int64_t)piVar4 + 4);
        _var_20h = *(undefined (*) [16])(piVar4 + 1);
    }
    *(undefined4 *)arg2 = uStack_28;
    *(undefined4 *)(arg2 + 4) = uStack_24;
    *(undefined4 *)(arg2 + 8) = (undefined4)var_20h;
    *(undefined4 *)(arg2 + 0xc) = var_20h._4_4_;
    *(int64_t *)(arg2 + 0x10) = var_18h;
    return arg2;
}

// ============================================================
// Function: FUN_1800b29e1
// Address: 0x1800b29e1
// Size: 61 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.1800b29d0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t *piVar2;
    uint64_t uVar3;
    int64_t *piVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t var_8h;
    int64_t var_10h;
    undefined4 uStack_28;
    undefined4 uStack_24;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(int64_t *)(arg1 + 0x110) == 0) {
        piVar2 = (int64_t *)0x0;
    } else if (arg3 == *(int64_t *)(arg1 + 0x118)) {
        piVar2 = (int64_t *)0x0;
    } else {
        piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x108) + -1);
        uVar3 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
        piVar5 = (int64_t *)0x0;
        piVar4 = piVar5;
        do {
            uVar3 = uVar3 & (uint64_t)piVar6;
            piVar2 = (int64_t *)(uVar3 * 0x20 + *(int64_t *)(arg1 + 0x100));
            iVar1 = *piVar2;
            if ((iVar1 == arg3) || (piVar2 = piVar5, iVar1 == *(int64_t *)(arg1 + 0x118))) break;
            uVar3 = uVar3 + 1 + (int64_t)piVar4;
            piVar4 = (int64_t *)((int64_t)piVar4 + 1);
        } while (piVar4 <= piVar6);
    }
    piVar4 = piVar2 + 1;
    if (piVar2 == (int64_t *)0x0) {
        piVar4 = (int64_t *)0x0;
    }
    if (piVar4 == (int64_t *)0x0) {
        uStack_28 = 0;
        uStack_24 = 0;
        _var_20h = ZEXT816(0);
    } else {
        uStack_28 = *(undefined4 *)piVar4;
        uStack_24 = *(undefined4 *)((int64_t)piVar4 + 4);
        _var_20h = *(undefined (*) [16])(piVar4 + 1);
    }
    *(undefined4 *)arg2 = uStack_28;
    *(undefined4 *)(arg2 + 4) = uStack_24;
    *(undefined4 *)(arg2 + 8) = (undefined4)var_20h;
    *(undefined4 *)(arg2 + 0xc) = var_20h._4_4_;
    *(int64_t *)(arg2 + 0x10) = var_18h;
    return arg2;
}

// ============================================================
// Function: FUN_1800b2a1e
// Address: 0x1800b2a1e
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.1800b29d0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t *piVar2;
    uint64_t uVar3;
    int64_t *piVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t var_8h;
    int64_t var_10h;
    undefined4 uStack_28;
    undefined4 uStack_24;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(int64_t *)(arg1 + 0x110) == 0) {
        piVar2 = (int64_t *)0x0;
    } else if (arg3 == *(int64_t *)(arg1 + 0x118)) {
        piVar2 = (int64_t *)0x0;
    } else {
        piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x108) + -1);
        uVar3 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
        piVar5 = (int64_t *)0x0;
        piVar4 = piVar5;
        do {
            uVar3 = uVar3 & (uint64_t)piVar6;
            piVar2 = (int64_t *)(uVar3 * 0x20 + *(int64_t *)(arg1 + 0x100));
            iVar1 = *piVar2;
            if ((iVar1 == arg3) || (piVar2 = piVar5, iVar1 == *(int64_t *)(arg1 + 0x118))) break;
            uVar3 = uVar3 + 1 + (int64_t)piVar4;
            piVar4 = (int64_t *)((int64_t)piVar4 + 1);
        } while (piVar4 <= piVar6);
    }
    piVar4 = piVar2 + 1;
    if (piVar2 == (int64_t *)0x0) {
        piVar4 = (int64_t *)0x0;
    }
    if (piVar4 == (int64_t *)0x0) {
        uStack_28 = 0;
        uStack_24 = 0;
        _var_20h = ZEXT816(0);
    } else {
        uStack_28 = *(undefined4 *)piVar4;
        uStack_24 = *(undefined4 *)((int64_t)piVar4 + 4);
        _var_20h = *(undefined (*) [16])(piVar4 + 1);
    }
    *(undefined4 *)arg2 = uStack_28;
    *(undefined4 *)(arg2 + 4) = uStack_24;
    *(undefined4 *)(arg2 + 8) = (undefined4)var_20h;
    *(undefined4 *)(arg2 + 0xc) = var_20h._4_4_;
    *(int64_t *)(arg2 + 0x10) = var_18h;
    return arg2;
}

// ============================================================
// Function: FUN_1800b2a70
// Address: 0x1800b2a70
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.1800b29d0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t *piVar2;
    uint64_t uVar3;
    int64_t *piVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t var_8h;
    int64_t var_10h;
    undefined4 uStack_28;
    undefined4 uStack_24;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(int64_t *)(arg1 + 0x110) == 0) {
        piVar2 = (int64_t *)0x0;
    } else if (arg3 == *(int64_t *)(arg1 + 0x118)) {
        piVar2 = (int64_t *)0x0;
    } else {
        piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x108) + -1);
        uVar3 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
        piVar5 = (int64_t *)0x0;
        piVar4 = piVar5;
        do {
            uVar3 = uVar3 & (uint64_t)piVar6;
            piVar2 = (int64_t *)(uVar3 * 0x20 + *(int64_t *)(arg1 + 0x100));
            iVar1 = *piVar2;
            if ((iVar1 == arg3) || (piVar2 = piVar5, iVar1 == *(int64_t *)(arg1 + 0x118))) break;
            uVar3 = uVar3 + 1 + (int64_t)piVar4;
            piVar4 = (int64_t *)((int64_t)piVar4 + 1);
        } while (piVar4 <= piVar6);
    }
    piVar4 = piVar2 + 1;
    if (piVar2 == (int64_t *)0x0) {
        piVar4 = (int64_t *)0x0;
    }
    if (piVar4 == (int64_t *)0x0) {
        uStack_28 = 0;
        uStack_24 = 0;
        _var_20h = ZEXT816(0);
    } else {
        uStack_28 = *(undefined4 *)piVar4;
        uStack_24 = *(undefined4 *)((int64_t)piVar4 + 4);
        _var_20h = *(undefined (*) [16])(piVar4 + 1);
    }
    *(undefined4 *)arg2 = uStack_28;
    *(undefined4 *)(arg2 + 4) = uStack_24;
    *(undefined4 *)(arg2 + 8) = (undefined4)var_20h;
    *(undefined4 *)(arg2 + 0xc) = var_20h._4_4_;
    *(int64_t *)(arg2 + 0x10) = var_18h;
    return arg2;
}

// ============================================================
// Function: FUN_1800b2a89
// Address: 0x1800b2a89
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.1800b29d0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t *piVar2;
    uint64_t uVar3;
    int64_t *piVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t var_8h;
    int64_t var_10h;
    undefined4 uStack_28;
    undefined4 uStack_24;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(int64_t *)(arg1 + 0x110) == 0) {
        piVar2 = (int64_t *)0x0;
    } else if (arg3 == *(int64_t *)(arg1 + 0x118)) {
        piVar2 = (int64_t *)0x0;
    } else {
        piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x108) + -1);
        uVar3 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
        piVar5 = (int64_t *)0x0;
        piVar4 = piVar5;
        do {
            uVar3 = uVar3 & (uint64_t)piVar6;
            piVar2 = (int64_t *)(uVar3 * 0x20 + *(int64_t *)(arg1 + 0x100));
            iVar1 = *piVar2;
            if ((iVar1 == arg3) || (piVar2 = piVar5, iVar1 == *(int64_t *)(arg1 + 0x118))) break;
            uVar3 = uVar3 + 1 + (int64_t)piVar4;
            piVar4 = (int64_t *)((int64_t)piVar4 + 1);
        } while (piVar4 <= piVar6);
    }
    piVar4 = piVar2 + 1;
    if (piVar2 == (int64_t *)0x0) {
        piVar4 = (int64_t *)0x0;
    }
    if (piVar4 == (int64_t *)0x0) {
        uStack_28 = 0;
        uStack_24 = 0;
        _var_20h = ZEXT816(0);
    } else {
        uStack_28 = *(undefined4 *)piVar4;
        uStack_24 = *(undefined4 *)((int64_t)piVar4 + 4);
        _var_20h = *(undefined (*) [16])(piVar4 + 1);
    }
    *(undefined4 *)arg2 = uStack_28;
    *(undefined4 *)(arg2 + 4) = uStack_24;
    *(undefined4 *)(arg2 + 8) = (undefined4)var_20h;
    *(undefined4 *)(arg2 + 0xc) = var_20h._4_4_;
    *(int64_t *)(arg2 + 0x10) = var_18h;
    return arg2;
}

// ============================================================
// Function: FUN_1800b2ad0
// Address: 0x1800b2ad0
// Size: 1400 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

int64_t fcn.1800b2ad0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int32_t iVar2;
    int32_t iVar3;
    code *pcVar4;
    char cVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    int64_t iVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    uint64_t *puVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    uint64_t arg2_00;
    int64_t iVar16;
    uint8_t in_R8B;
    uint64_t *puVar17;
    uint64_t uVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_48h;
    int64_t var_40h;
    
    uVar7 = *(uint32_t *)(arg1 + 0x60c);
    var_10h._0_4_ = uVar7;
    var_18h._0_1_ = in_R8B;
    if (*(int32_t *)(arg2 + 0x20) - 8U < 2) {
        arg2_00 = *(uint64_t *)(arg2 + 0x28);
        uVar15 = *(uint64_t *)(arg2 + 0x30);
        cVar5 = fcn.1800b2930(arg1, uVar15);
        uVar12 = arg2_00;
        if (cVar5 != '\0') {
            var_8h._0_4_ = CONCAT31(var_8h._1_3_, 1);
            goto code_r0x0001800b2b6c;
        }
        cVar5 = fcn.1800b2930(arg1, arg2_00);
        var_8h._0_4_ = CONCAT31(var_8h._1_3_, 1);
        if (cVar5 == '\0') goto code_r0x0001800b2b6c;
code_r0x0001800b2b75:
        in_R8B = (uint8_t)var_18h;
        if ((*(int64_t *)(arg1 + 0x110) != 0) && (arg2_00 != *(uint64_t *)(arg1 + 0x118))) {
            uVar18 = *(int64_t *)(arg1 + 0x108) - 1;
            uVar12 = (arg2_00 >> 5 ^ arg2_00) >> 4;
            uVar14 = 0;
            do {
                uVar12 = uVar12 & uVar18;
                puVar17 = (uint64_t *)(uVar12 * 0x20 + *(int64_t *)(arg1 + 0x100));
                if (*puVar17 == arg2_00) {
                    puVar13 = puVar17 + 1;
                    if (puVar17 == (uint64_t *)0x0) {
                        puVar13 = (uint64_t *)0x0;
                    }
                    if ((puVar13 != (uint64_t *)0x0) && (*(int32_t *)puVar13 == 5)) goto code_r0x0001800b2c91;
                    break;
                }
                if (*puVar17 == *(uint64_t *)(arg1 + 0x118)) break;
                uVar12 = uVar12 + 1 + uVar14;
                uVar14 = uVar14 + 1;
            } while (uVar14 <= uVar18);
        }
        if (((*(char *)0x180778580 != '\0') && (*(int64_t *)(arg1 + 0x110) != 0)) &&
           (arg2_00 != *(uint64_t *)(arg1 + 0x118))) {
            uVar18 = *(int64_t *)(arg1 + 0x108) - 1;
            uVar12 = (arg2_00 >> 5 ^ arg2_00) >> 4;
            uVar14 = 0;
            do {
                uVar12 = uVar12 & uVar18;
                puVar17 = (uint64_t *)(uVar12 * 0x20 + *(int64_t *)(arg1 + 0x100));
                if (*puVar17 == arg2_00) {
                    puVar13 = puVar17 + 1;
                    if (puVar17 == (uint64_t *)0x0) {
                        puVar13 = (uint64_t *)0x0;
                    }
                    if ((puVar13 != (uint64_t *)0x0) && (*(int32_t *)puVar13 == 4)) {
code_r0x0001800b2c91:
                        cVar5 = '\0';
                    }
                    break;
                }
                if (*puVar17 == *(uint64_t *)(arg1 + 0x118)) break;
                uVar12 = uVar12 + 1 + uVar14;
                uVar14 = uVar14 + 1;
            } while (uVar14 <= uVar18);
        }
    } else {
        var_8h._0_4_ = (uint32_t)var_8h & 0xffffff00;
        uVar15 = *(uint64_t *)(arg2 + 0x30);
        uVar12 = *(uint64_t *)(arg2 + 0x28);
        cVar5 = fcn.1800b2930(arg1, uVar15);
code_r0x0001800b2b6c:
        arg2_00 = uVar15;
        uVar15 = uVar12;
        if (cVar5 != '\0') goto code_r0x0001800b2b75;
    }
    uVar6 = func_0x0001800b7be0(arg1);
    uVar8 = (uint32_t)var_10h;
    if ((int32_t)uVar6 < 0) {
        uVar6 = (uint32_t)var_10h + 1;
        if (0xff < uVar6) {
            fcn.1800acea0(uVar15 + 0xc, 0x18063fbc0, 1, 0xff, arg1, uVar7);
            pcVar4 = (code *)swi(3);
            iVar10 = (*pcVar4)();
            return iVar10;
        }
        *(uint32_t *)(arg1 + 0x60c) = uVar6;
        uVar7 = *(uint32_t *)(arg1 + 0x610);
        if (*(uint32_t *)(arg1 + 0x610) < uVar6) {
            uVar7 = uVar6;
        }
        *(uint32_t *)(arg1 + 0x610) = uVar7;
        func_0x0001800b4ce0(arg1, uVar15, (char)(uint32_t)var_10h, 1);
        uVar6 = uVar8 & 0xff;
    }
    if (((char)var_8h == '\0') || (cVar5 == '\0')) {
    // switch table (6 cases) at 0x1800b3030
        switch(*(undefined4 *)(arg2 + 0x20)) {
        case 8:
            uVar7 = 0x1e;
            if (in_R8B != 0) {
                uVar7 = 0x1b;
            }
            break;
        case 9:
            uVar7 = 0x1b;
            if (in_R8B != 0) {
                uVar7 = 0x1e;
            }
            break;
        case 10:
        case 0xc:
            uVar7 = 0x1d;
            if (in_R8B != 0) {
                uVar7 = 0x20;
            }
            break;
        case 0xb:
        case 0xd:
            uVar7 = 0x1c;
            if (in_R8B != 0) {
                uVar7 = 0x1f;
            }
            break;
        default:
            uVar7 = 0;
        }
        uVar8 = func_0x0001800b7be0(arg1, arg2_00);
        if ((int32_t)uVar8 < 0) {
            uVar8 = *(uint32_t *)(arg1 + 0x60c);
            uVar11 = uVar8 + 1;
            if (0xff < uVar11) {
                fcn.1800acea0(arg2_00 + 0xc, 0x18063fbc0, 1, 0xff);
                pcVar4 = (code *)swi(3);
                iVar10 = (*pcVar4)();
                return iVar10;
            }
            *(uint32_t *)(arg1 + 0x60c) = uVar11;
            uVar9 = *(uint32_t *)(arg1 + 0x610);
            if (*(uint32_t *)(arg1 + 0x610) < uVar11) {
                uVar9 = uVar11;
            }
            *(uint32_t *)(arg1 + 0x610) = uVar9;
            func_0x0001800b4ce0(arg1, arg2_00, uVar8 & 0xff, 1);
        }
        iVar10 = *(int64_t *)arg1;
        piVar1 = (int64_t *)(iVar10 + 0x28);
        iVar16 = *(int64_t *)(iVar10 + 0x30) - *piVar1;
        if (*(int32_t *)(arg2 + 0x20) - 0xcU < 2) {
            var_8h._0_4_ = (uVar8 & 0xff) << 8 | uVar7;
            fcn.1800d31a0(piVar1, &var_8h);
            fcn.1800d31a0(iVar10 + 0x40, iVar10 + 0x270);
        } else {
            var_8h._0_4_ = (uVar6 & 0xff) << 8 | uVar7;
            fcn.1800d31a0(piVar1, &var_8h);
            fcn.1800d31a0(iVar10 + 0x40, iVar10 + 0x270);
            uVar6 = uVar8;
        }
        var_8h._0_4_ = uVar6 & 0xff;
        iVar10 = *(int64_t *)arg1;
        fcn.1800d31a0(iVar10 + 0x28, &var_8h);
        fcn.1800d31a0(iVar10 + 0x40, iVar10 + 0x270);
        *(uint32_t *)(arg1 + 0x60c) = (uint32_t)var_10h;
    } else {
        if ((*(int64_t *)(arg1 + 0x110) != 0) && (arg2_00 != *(uint64_t *)(arg1 + 0x118))) {
            uVar14 = *(int64_t *)(arg1 + 0x108) - 1;
            uVar12 = (arg2_00 >> 5 ^ arg2_00) >> 4;
            uVar15 = 0;
            do {
                uVar12 = uVar12 & uVar14;
                puVar17 = (uint64_t *)(uVar12 * 0x20 + *(int64_t *)(arg1 + 0x100));
                if (*puVar17 == arg2_00) goto code_r0x0001800b2d6b;
                if (*puVar17 == *(uint64_t *)(arg1 + 0x118)) break;
                uVar12 = uVar12 + 1 + uVar15;
                uVar15 = uVar15 + 1;
            } while (uVar15 <= uVar14);
        }
        puVar17 = (uint64_t *)0x0;
code_r0x0001800b2d6b:
        puVar13 = puVar17 + 1;
        if (puVar17 == (uint64_t *)0x0) {
            puVar13 = (uint64_t *)0x0;
        }
        iVar3 = *(int32_t *)(arg2 + 0x20);
        iVar2 = *(int32_t *)puVar13;
        if (iVar2 == 1) {
            uVar7 = 0;
            uVar8 = 0x4d;
        } else {
            if (iVar2 == 2) {
                uVar8 = 0x4e;
                uVar7 = (uint32_t)*(uint8_t *)(puVar13 + 1);
            } else if (iVar2 == 3) {
                uVar8 = 0x4f;
                uVar7 = func_0x0001800b3150(arg1, arg2_00);
            } else {
                if (iVar2 != 6) goto code_r0x0001800b3002;
                uVar8 = 0x50;
                uVar7 = func_0x0001800b3150(arg1, arg2_00);
            }
            if ((int32_t)uVar7 < 0) {
code_r0x0001800b3002:
                fcn.1800acea0(arg2 + 0xc, 0x18063f5a0);
                pcVar4 = (code *)swi(3);
                iVar10 = (*pcVar4)();
                return iVar10;
            }
        }
        iVar10 = *(int64_t *)arg1;
        iVar16 = *(int64_t *)(iVar10 + 0x30) - *(int64_t *)(iVar10 + 0x28);
        var_8h._0_4_ = (uVar6 & 0xff) << 8 | uVar8;
        fcn.1800d31a0((int64_t *)(iVar10 + 0x28), &var_8h);
        fcn.1800d31a0(iVar10 + 0x40, iVar10 + 0x270);
        iVar10 = *(int64_t *)arg1;
        var_8h._0_4_ = (uint32_t)((uint8_t)var_18h ^ iVar3 != 9) << 0x1f | uVar7;
        fcn.1800d31a0(iVar10 + 0x28, &var_8h);
        fcn.1800d31a0(iVar10 + 0x40, iVar10 + 0x270);
        *(uint32_t *)(arg1 + 0x60c) = (uint32_t)var_10h;
    }
    return iVar16 >> 2;
}

// ============================================================
// Function: FUN_1800b3050
// Address: 0x1800b3050
// Size: 254 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800b3050(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    undefined8 uVar2;
    uint64_t uVar3;
    int64_t *piVar4;
    int64_t *piVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    if ((*(int64_t *)(arg1 + 0x110) != 0) && (arg2 != *(int64_t *)(arg1 + 0x118))) {
        uVar7 = *(int64_t *)(arg1 + 0x108) - 1;
        uVar6 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar3 = 0;
        do {
            uVar6 = uVar6 & uVar7;
            piVar5 = (int64_t *)(uVar6 * 0x20 + *(int64_t *)(arg1 + 0x100));
            if (*piVar5 == arg2) {
                piVar4 = piVar5 + 1;
                if (piVar5 == (int64_t *)0x0) {
                    piVar4 = (int64_t *)0x0;
                }
                if (piVar4 == (int64_t *)0x0) {
                    return 0xffffffff;
                }
                if (*(int32_t *)piVar4 != 3) {
                    return 0xffffffff;
                }
                var_30h = piVar4[1];
                var_28h = 0;
                uStack_10 = 0;
                var_18h = var_30h;
                var_20h._0_4_ = 2;
                var_38h._0_4_ = 2;
                uVar2 = func_0x0001800ced20(*(undefined8 *)arg1, &var_38h, &var_20h);
                if ((int32_t)uVar2 < 0) {
                    fcn.1800acea0(arg2 + 0xc, 0x18063f5a0);
                    pcVar1 = (code *)swi(3);
                    uVar2 = (*pcVar1)();
                    return uVar2;
                }
                return uVar2;
            }
            if (*piVar5 == *(int64_t *)(arg1 + 0x118)) {
                return 0xffffffff;
            }
            uVar6 = uVar6 + 1 + uVar3;
            uVar3 = uVar3 + 1;
        } while (uVar3 <= uVar7);
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1800b3150
// Address: 0x1800b3150
// Size: 440 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800b3150(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    undefined auVar2 [16];
    undefined8 uVar3;
    uint64_t uVar4;
    int64_t *piVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t *piVar8;
    int64_t var_8h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    undefined8 uStack_38;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    auVar2 = _var_40h;
    if ((*(int64_t *)(arg1 + 0x110) != 0) && (arg2 != *(int64_t *)(arg1 + 0x118))) {
        uVar7 = *(int64_t *)(arg1 + 0x108) - 1;
        uVar6 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar4 = 0;
        do {
            uVar6 = uVar6 & uVar7;
            piVar8 = (int64_t *)(uVar6 * 0x20 + *(int64_t *)(arg1 + 0x100));
            if (*piVar8 == arg2) {
                piVar5 = piVar8 + 1;
                if (piVar8 == (int64_t *)0x0) {
                    piVar5 = (int64_t *)0x0;
                }
                if (piVar5 == (int64_t *)0x0) {
                    return 0xffffffff;
                }
                if (*(int32_t *)piVar5 == 0) {
                    return 0xffffffff;
                }
    // switch table (6 cases) at 0x1800b32f0
                switch(*(int32_t *)piVar5) {
                case 1:
                    uVar3 = func_0x0001800cf5d0(*(undefined8 *)arg1);
                    break;
                case 2:
                    uVar3 = func_0x0001800cf610(*(undefined8 *)arg1, *(undefined *)(piVar5 + 1));
                    break;
                case 3:
                    uVar3 = func_0x0001800cf660(*(undefined8 *)arg1, piVar5[1]);
                    break;
                case 4:
                    uVar3 = func_0x0001800cf6b0(*(undefined8 *)arg1, piVar5[1]);
                    break;
                case 5:
                    uVar3 = func_0x0001800cf700(*(undefined8 *)arg1, *(int32_t *)(piVar5 + 1), 
                                                *(int32_t *)((int64_t)piVar5 + 0xc), *(int32_t *)(piVar5 + 2), 
                                                *(int32_t *)((int64_t)piVar5 + 0x14));
                    break;
                case 6:
                    var_48h = piVar5[1];
                    uVar3 = *(undefined8 *)arg1;
                    var_40h._4_4_ = 0;
                    var_40h._0_4_ = *(uint32_t *)((int64_t)piVar5 + 4);
                    uStack_38 = auVar2._8_8_;
                    var_40h._0_4_ = func_0x0001800cf010(uVar3, &var_48h);
                    var_48h = CONCAT44(var_48h._4_4_, 5);
                    stack0xffffffffffffffc4 = SUB1612(ZEXT816(0), 4);
                    var_20h = (int64_t)(uint32_t)var_40h;
                    var_28h._0_4_ = 5;
                    var_18h = 0;
                    uVar3 = func_0x0001800ced20(uVar3, &var_28h, &var_48h);
                    break;
                default:
                    goto code_r0x0001800b31cd;
                }
                if (-1 < (int32_t)uVar3) {
                    return uVar3;
                }
                fcn.1800acea0(arg2 + 0xc, 0x18063f5a0);
                pcVar1 = (code *)swi(3);
                uVar3 = (*pcVar1)();
                return uVar3;
            }
            if (*piVar8 == *(int64_t *)(arg1 + 0x118)) {
                return 0xffffffff;
            }
            uVar6 = uVar6 + 1 + uVar4;
            uVar4 = uVar4 + 1;
        } while (uVar4 <= uVar7);
    }
code_r0x0001800b31cd:
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1800b3310
// Address: 0x1800b3310
// Size: 1036 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.1800b3310(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t iVar6;
    char cVar7;
    uint8_t uVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    undefined8 *puVar11;
    undefined *puVar12;
    uint64_t uVar13;
    uint64_t *puVar14;
    uint64_t *puVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStackY_78 [8];
    undefined auStackY_70 [24];
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    
    puVar12 = auStackY_78;
code_r0x0001800b3341:
    do {
        if ((*(int64_t *)(arg1 + 0x110) != 0) && (arg2 != *(uint64_t *)(arg1 + 0x118))) {
            uVar13 = *(int64_t *)(arg1 + 0x108) - 1;
            uVar9 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
            uVar10 = 0;
            do {
                uVar9 = uVar9 & uVar13;
                puVar14 = (uint64_t *)(uVar9 * 0x20 + *(int64_t *)(arg1 + 0x100));
                if (*puVar14 == arg2) {
                    puVar15 = puVar14 + 1;
                    if ((puVar15 != (uint64_t *)0x0) && (iVar1 = *(int32_t *)puVar15, iVar1 != 0)) {
                        if ((iVar1 == 1) || ((iVar1 == 2 && (*(char *)(puVar14 + 2) == '\0')))) {
                            uVar8 = 0;
                        } else {
                            uVar8 = 1;
                        }
                        if (uVar8 != (uint8_t)arg_28h) {
                            return;
                        }
                        if (arg3 != 0) {
                            func_0x0001800b4ce0(arg1, arg2, *(undefined *)arg3, 
                                                CONCAT71((unkint7)((uint64_t)puVar15 >> 8), 1));
                        }
                        var_8h = *(int64_t *)(*(int64_t *)arg1 + 0x30) - *(int64_t *)(*(int64_t *)arg1 + 0x28) >> 2;
                        func_0x0001800c1140(arg4, &var_8h);
                        arg1 = *(int64_t *)arg1;
                        var_8h = CONCAT44(var_8h._4_4_, 0x17);
                        fcn.1800d31a0(arg1 + 0x28, &var_8h);
                        fcn.1800d31a0(arg1 + 0x40, arg1 + 0x270);
                        return;
                    }
                    break;
                }
                if (*puVar14 == *(uint64_t *)(arg1 + 0x118)) break;
                uVar9 = uVar9 + 1 + uVar10;
                uVar10 = uVar10 + 1;
            } while (uVar10 <= uVar13);
        }
        iVar1 = *(int32_t *)(arg2 + 8);
        uVar9 = 0;
        if (iVar1 == *(int32_t *)0x180782668) {
            uVar9 = arg2;
        }
        if (uVar9 == 0) {
code_r0x0001800b3421:
            uVar9 = 0;
            if (iVar1 == *(int32_t *)0x180782768) {
                uVar9 = arg2;
            }
            if (((uVar9 == 0) || (arg3 != 0)) || (*(int32_t *)(uVar9 + 0x20) != 0)) {
                uVar9 = 0;
                if (iVar1 == *(int32_t *)0x1807826c0) {
                    uVar9 = arg2;
                }
                if (uVar9 == 0) {
                    uVar2 = *(undefined4 *)(arg1 + 0x60c);
                    var_40h._0_4_ = uVar2;
                    var_48h = arg1;
                    if (arg3 == 0) {
                        uVar8 = func_0x0001800b7030(arg1, arg2);
                    } else {
                        uVar8 = *(uint8_t *)arg3;
                        func_0x0001800b4ce0(arg1, arg2, uVar8, 1);
                    }
                    var_8h = *(int64_t *)(*(int64_t *)arg1 + 0x30) - *(int64_t *)(*(int64_t *)arg1 + 0x28) >> 2;
                    func_0x0001800c1140(arg4, &var_8h);
                    iVar4 = *(int64_t *)arg1;
                    var_8h = CONCAT44(var_8h._4_4_, (uint32_t)uVar8 << 8 | 0x1a - ((uint8_t)arg_28h != 0));
                    fcn.1800d31a0(iVar4 + 0x28, &var_8h);
                    fcn.1800d31a0(iVar4 + 0x40, iVar4 + 0x270);
                    *(undefined4 *)(arg1 + 0x60c) = uVar2;
                    return;
                }
                arg2 = *(uint64_t *)(uVar9 + 0x20);
            } else {
                arg_28h._0_1_ = (uint8_t)arg_28h ^ 1;
                arg2 = *(uint64_t *)(uVar9 + 0x28);
            }
            goto code_r0x0001800b3341;
        }
    // switch table (8 cases) at 0x1800b36fc
        switch(*(int32_t *)(uVar9 + 0x20)) {
        case 8:
        case 9:
        case 10:
        case 0xb:
        case 0xc:
        case 0xd:
            if (arg3 != 0) {
                var_58h._0_1_ = 0;
                func_0x0001800cfdd0(*(undefined8 *)arg1, 3, *(undefined *)arg3, (uint8_t)arg_28h != 0);
            }
            var_8h = fcn.1800b2ad0(arg1, uVar9);
            fcn.1800bf890(arg4, &var_8h);
            return;
        case 0xe:
        case 0xf:
            if ((bool)(uint8_t)arg_28h == (*(int32_t *)(uVar9 + 0x20) == 0xe)) {
                _var_48h = ZEXT816(0);
                var_38h = 0;
                var_58h._0_1_ = (uint8_t)arg_28h == 0;
                fcn.1800b3310(arg1, *(int64_t *)(uVar9 + 0x28), 0, (int64_t)&var_48h, 
                              CONCAT71(var_58h._1_7_, (uint8_t)var_58h));
                var_58h._0_1_ = (uint8_t)arg_28h;
                fcn.1800b3310(arg1, *(int64_t *)(uVar9 + 0x30), arg3, arg4, CONCAT71(var_58h._1_7_, (uint8_t)arg_28h));
                iVar4 = *(int64_t *)(*(int64_t *)arg1 + 0x30);
                iVar3 = *(int64_t *)(*(int64_t *)arg1 + 0x28);
                iVar6 = var_40h;
                puVar11 = (undefined8 *)var_48h;
                if (var_48h != var_40h) {
                    do {
                        cVar7 = func_0x0001800cfeb0(*(undefined8 *)arg1, *puVar11, iVar4 - iVar3 >> 2);
                        if (cVar7 == '\0') {
                            fcn.1800acea0(uVar9 + 0xc, 0x18063f7f0);
                            pcVar5 = (code *)swi(3);
                            (*pcVar5)();
                            return;
                        }
                        puVar11 = puVar11 + 1;
                    } while (puVar11 != (undefined8 *)iVar6);
                }
                if (var_48h != 0) {
                    uVar9 = (var_38h - var_48h >> 3) * 8;
                    uVar10 = var_48h;
                    if (0xfff < uVar9) {
                        uVar10 = (var_48h - *(int64_t *)(var_48h - 8)) - 8;
                        if (uVar10 < 0x20) {
                            fcn.180459c3c(*(int64_t *)(var_48h - 8), uVar9 + 0x27);
                            return;
                        }
                        pcVar5 = (code *)swi(0x29);
                        (*pcVar5)(5);
                        puVar12 = auStackY_70;
                    }
                    *(undefined8 *)(puVar12 + -8) = 0x1800b35d8;
                    fcn.180459c3c(uVar10);
                }
                return;
            }
            var_58h._0_1_ = (uint8_t)arg_28h;
            fcn.1800b3310(arg1, *(int64_t *)(uVar9 + 0x28), arg3, arg4, CONCAT71(var_58h._1_7_, (uint8_t)arg_28h));
            arg2 = *(uint64_t *)(uVar9 + 0x30);
            break;
        default:
            goto code_r0x0001800b3421;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1800b3720
// Address: 0x1800b3720
// Size: 280 bytes
// ============================================================
// WARNING: Switch with 1 destination removed at 0x0001800b3804 : 8 cases all go to same destination

uint64_t fcn.1800b3720(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    uint64_t uVar2;
    uint64_t *puVar3;
    uint64_t *puVar4;
    uint64_t uVar5;
    uint64_t *puVar6;
    uint64_t uVar7;
    
    do {
        if ((*(int64_t *)(arg1 + 0x110) != 0) && (arg2 != *(uint64_t *)(arg1 + 0x118))) {
            uVar7 = *(int64_t *)(arg1 + 0x108) - 1;
            uVar2 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
            uVar5 = 0;
            do {
                uVar2 = uVar2 & uVar7;
                puVar6 = (uint64_t *)(uVar2 * 0x20 + *(int64_t *)(arg1 + 0x100));
                if (*puVar6 == arg2) {
                    puVar3 = (uint64_t *)0x0;
                    puVar4 = puVar6 + 1;
                    if (puVar6 == (uint64_t *)0x0) {
                        puVar4 = puVar3;
                    }
                    if ((puVar4 != (uint64_t *)0x0) && (*(int32_t *)puVar4 != 0)) goto code_r0x0001800b3806;
                    break;
                }
                if (*puVar6 == *(uint64_t *)(arg1 + 0x118)) break;
                uVar2 = uVar2 + 1 + uVar5;
                uVar5 = uVar5 + 1;
            } while (uVar5 <= uVar7);
        }
        uVar2 = 0;
        if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782668) {
            uVar2 = arg2;
        }
        if (uVar2 != 0) {
            uVar1 = *(int32_t *)(uVar2 + 0x20) - 8;
            uVar2 = (uint64_t)uVar1;
            if (uVar1 < 8) {
                puVar3 = (uint64_t *)(int64_t)(int32_t)uVar1;
    // switch table (8 cases) at 0x1800b3818
code_r0x0001800b3806:
                return CONCAT71((unkint7)((uint64_t)puVar3 >> 8), 1);
            }
code_r0x0001800b380f:
            return uVar2 & 0xffffffffffffff00;
        }
        uVar2 = 0;
        if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x1807826c0) {
            uVar2 = arg2;
        }
        if (uVar2 == 0) goto code_r0x0001800b380f;
        arg2 = *(uint64_t *)(uVar2 + 0x20);
    } while( true );
}

// ============================================================
// Function: FUN_1800b3840
// Address: 0x1800b3840
// Size: 42 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1800b3840(int64_t arg1, int64_t arg_38h)
{
    uint64_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 *puVar7;
    undefined *puVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined uStack_48;
    int64_t var_47h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar9 = *(int64_t *)(arg1 + 8);
    iVar10 = 0;
    if (*(int32_t *)(*(int64_t *)(iVar9 + -8) + 8) == *(int32_t *)0x180782668) {
        iVar10 = *(int64_t *)(iVar9 + -8);
    }
    do {
        if ((iVar10 == 0) || (*(int32_t *)(iVar10 + 0x20) != 7)) {
            return;
        }
        *(undefined8 *)(iVar9 + -8) = *(undefined8 *)(iVar10 + 0x28);
        puVar7 = *(undefined8 **)(arg1 + 8);
        if (puVar7 == *(undefined8 **)(arg1 + 0x10)) {
            iVar9 = (int64_t)puVar7 - *(int64_t *)arg1 >> 3;
            if (iVar9 == 0x1fffffffffffffff) {
                fcn.180010010();
                pcVar3 = (code *)swi(3);
                (*pcVar3)();
                return;
            }
            uVar5 = (int64_t)*(undefined8 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3;
            puVar8 = &uStack_48;
            if (0x1fffffffffffffff - (uVar5 >> 1) < uVar5) {
code_r0x0001800b39f8:
                *(undefined8 *)(puVar8 + -8) = 0x1800b39fd;
                fcn.180004720();
                pcVar3 = (code *)swi(3);
                (*pcVar3)();
                return;
            }
            uVar1 = iVar9 + 1;
            uVar5 = uVar5 + (uVar5 >> 1);
            uVar11 = uVar1;
            if (uVar1 <= uVar5) {
                uVar11 = uVar5;
            }
            puVar8 = &uStack_48;
            if (0x1fffffffffffffff < uVar11) goto code_r0x0001800b39f8;
            uVar5 = uVar11 * 8;
            if (uVar5 == 0) {
                uVar5 = 0;
            } else if (uVar5 < 0x1000) {
                uVar5 = fcn.180459890();
            } else {
                puVar8 = &uStack_48;
                if (uVar5 + 0x27 <= uVar5) goto code_r0x0001800b39f8;
                iVar4 = fcn.180459890(uVar5 + 0x27);
                if (iVar4 == 0) {
                    pcVar3 = (code *)swi(0x29);
                    (*pcVar3)(5);
                    puVar8 = (undefined *)((int64_t)&var_47h + 7);
                    goto code_r0x0001800b39f8;
                }
                uVar5 = iVar4 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar5 - 8) = iVar4;
            }
            *(undefined8 *)(uVar5 + iVar9 * 8) = *(undefined8 *)(iVar10 + 0x30);
            puVar2 = *(undefined8 **)arg1;
            if (puVar7 == *(undefined8 **)(arg1 + 8)) {
                iVar10 = (int64_t)*(undefined8 **)(arg1 + 8) - (int64_t)puVar2;
                uVar6 = uVar5;
                puVar7 = puVar2;
            } else {
                fcn.180498030(uVar5, puVar2, (int64_t)puVar7 - (int64_t)puVar2);
                iVar10 = *(int64_t *)(arg1 + 8) - (int64_t)puVar7;
                uVar6 = uVar5 + (iVar9 + 1) * 8;
            }
            fcn.180498030(uVar6, puVar7, iVar10);
            func_0x0001800c2120(arg1, uVar5, uVar1, uVar11);
        } else {
            *puVar7 = *(undefined8 *)(iVar10 + 0x30);
            *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 8;
        }
        iVar9 = *(int64_t *)(arg1 + 8);
        iVar10 = 0;
        if (*(int32_t *)(*(int64_t *)(iVar9 + -8) + 8) == *(int32_t *)0x180782668) {
            iVar10 = *(int64_t *)(iVar9 + -8);
        }
    } while( true );
}

// ============================================================
// Function: FUN_1800b386a
// Address: 0x1800b386a
// Size: 384 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1800b3840(int64_t arg1, int64_t arg_38h)
{
    uint64_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 *puVar7;
    undefined *puVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined uStack_48;
    int64_t var_47h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar9 = *(int64_t *)(arg1 + 8);
    iVar10 = 0;
    if (*(int32_t *)(*(int64_t *)(iVar9 + -8) + 8) == *(int32_t *)0x180782668) {
        iVar10 = *(int64_t *)(iVar9 + -8);
    }
    do {
        if ((iVar10 == 0) || (*(int32_t *)(iVar10 + 0x20) != 7)) {
            return;
        }
        *(undefined8 *)(iVar9 + -8) = *(undefined8 *)(iVar10 + 0x28);
        puVar7 = *(undefined8 **)(arg1 + 8);
        if (puVar7 == *(undefined8 **)(arg1 + 0x10)) {
            iVar9 = (int64_t)puVar7 - *(int64_t *)arg1 >> 3;
            if (iVar9 == 0x1fffffffffffffff) {
                fcn.180010010();
                pcVar3 = (code *)swi(3);
                (*pcVar3)();
                return;
            }
            uVar5 = (int64_t)*(undefined8 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3;
            puVar8 = &uStack_48;
            if (0x1fffffffffffffff - (uVar5 >> 1) < uVar5) {
code_r0x0001800b39f8:
                *(undefined8 *)(puVar8 + -8) = 0x1800b39fd;
                fcn.180004720();
                pcVar3 = (code *)swi(3);
                (*pcVar3)();
                return;
            }
            uVar1 = iVar9 + 1;
            uVar5 = uVar5 + (uVar5 >> 1);
            uVar11 = uVar1;
            if (uVar1 <= uVar5) {
                uVar11 = uVar5;
            }
            puVar8 = &uStack_48;
            if (0x1fffffffffffffff < uVar11) goto code_r0x0001800b39f8;
            uVar5 = uVar11 * 8;
            if (uVar5 == 0) {
                uVar5 = 0;
            } else if (uVar5 < 0x1000) {
                uVar5 = fcn.180459890();
            } else {
                puVar8 = &uStack_48;
                if (uVar5 + 0x27 <= uVar5) goto code_r0x0001800b39f8;
                iVar4 = fcn.180459890(uVar5 + 0x27);
                if (iVar4 == 0) {
                    pcVar3 = (code *)swi(0x29);
                    (*pcVar3)(5);
                    puVar8 = (undefined *)((int64_t)&var_47h + 7);
                    goto code_r0x0001800b39f8;
                }
                uVar5 = iVar4 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar5 - 8) = iVar4;
            }
            *(undefined8 *)(uVar5 + iVar9 * 8) = *(undefined8 *)(iVar10 + 0x30);
            puVar2 = *(undefined8 **)arg1;
            if (puVar7 == *(undefined8 **)(arg1 + 8)) {
                iVar10 = (int64_t)*(undefined8 **)(arg1 + 8) - (int64_t)puVar2;
                uVar6 = uVar5;
                puVar7 = puVar2;
            } else {
                fcn.180498030(uVar5, puVar2, (int64_t)puVar7 - (int64_t)puVar2);
                iVar10 = *(int64_t *)(arg1 + 8) - (int64_t)puVar7;
                uVar6 = uVar5 + (iVar9 + 1) * 8;
            }
            fcn.180498030(uVar6, puVar7, iVar10);
            func_0x0001800c2120(arg1, uVar5, uVar1, uVar11);
        } else {
            *puVar7 = *(undefined8 *)(iVar10 + 0x30);
            *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 8;
        }
        iVar9 = *(int64_t *)(arg1 + 8);
        iVar10 = 0;
        if (*(int32_t *)(*(int64_t *)(iVar9 + -8) + 8) == *(int32_t *)0x180782668) {
            iVar10 = *(int64_t *)(iVar9 + -8);
        }
    } while( true );
}

// ============================================================
// Function: FUN_1800b39ea
// Address: 0x1800b39ea
// Size: 7 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1800b3840(int64_t arg1, int64_t arg_38h)
{
    uint64_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 *puVar7;
    undefined *puVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined uStack_48;
    int64_t var_47h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar9 = *(int64_t *)(arg1 + 8);
    iVar10 = 0;
    if (*(int32_t *)(*(int64_t *)(iVar9 + -8) + 8) == *(int32_t *)0x180782668) {
        iVar10 = *(int64_t *)(iVar9 + -8);
    }
    do {
        if ((iVar10 == 0) || (*(int32_t *)(iVar10 + 0x20) != 7)) {
            return;
        }
        *(undefined8 *)(iVar9 + -8) = *(undefined8 *)(iVar10 + 0x28);
        puVar7 = *(undefined8 **)(arg1 + 8);
        if (puVar7 == *(undefined8 **)(arg1 + 0x10)) {
            iVar9 = (int64_t)puVar7 - *(int64_t *)arg1 >> 3;
            if (iVar9 == 0x1fffffffffffffff) {
                fcn.180010010();
                pcVar3 = (code *)swi(3);
                (*pcVar3)();
                return;
            }
            uVar5 = (int64_t)*(undefined8 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3;
            puVar8 = &uStack_48;
            if (0x1fffffffffffffff - (uVar5 >> 1) < uVar5) {
code_r0x0001800b39f8:
                *(undefined8 *)(puVar8 + -8) = 0x1800b39fd;
                fcn.180004720();
                pcVar3 = (code *)swi(3);
                (*pcVar3)();
                return;
            }
            uVar1 = iVar9 + 1;
            uVar5 = uVar5 + (uVar5 >> 1);
            uVar11 = uVar1;
            if (uVar1 <= uVar5) {
                uVar11 = uVar5;
            }
            puVar8 = &uStack_48;
            if (0x1fffffffffffffff < uVar11) goto code_r0x0001800b39f8;
            uVar5 = uVar11 * 8;
            if (uVar5 == 0) {
                uVar5 = 0;
            } else if (uVar5 < 0x1000) {
                uVar5 = fcn.180459890();
            } else {
                puVar8 = &uStack_48;
                if (uVar5 + 0x27 <= uVar5) goto code_r0x0001800b39f8;
                iVar4 = fcn.180459890(uVar5 + 0x27);
                if (iVar4 == 0) {
                    pcVar3 = (code *)swi(0x29);
                    (*pcVar3)(5);
                    puVar8 = (undefined *)((int64_t)&var_47h + 7);
                    goto code_r0x0001800b39f8;
                }
                uVar5 = iVar4 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar5 - 8) = iVar4;
            }
            *(undefined8 *)(uVar5 + iVar9 * 8) = *(undefined8 *)(iVar10 + 0x30);
            puVar2 = *(undefined8 **)arg1;
            if (puVar7 == *(undefined8 **)(arg1 + 8)) {
                iVar10 = (int64_t)*(undefined8 **)(arg1 + 8) - (int64_t)puVar2;
                uVar6 = uVar5;
                puVar7 = puVar2;
            } else {
                fcn.180498030(uVar5, puVar2, (int64_t)puVar7 - (int64_t)puVar2);
                iVar10 = *(int64_t *)(arg1 + 8) - (int64_t)puVar7;
                uVar6 = uVar5 + (iVar9 + 1) * 8;
            }
            fcn.180498030(uVar6, puVar7, iVar10);
            func_0x0001800c2120(arg1, uVar5, uVar1, uVar11);
        } else {
            *puVar7 = *(undefined8 *)(iVar10 + 0x30);
            *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 8;
        }
        iVar9 = *(int64_t *)(arg1 + 8);
        iVar10 = 0;
        if (*(int32_t *)(*(int64_t *)(iVar9 + -8) + 8) == *(int32_t *)0x180782668) {
            iVar10 = *(int64_t *)(iVar9 + -8);
        }
    } while( true );
}

// ============================================================
// Function: FUN_1800b39f1
// Address: 0x1800b39f1
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1800b3840(int64_t arg1, int64_t arg_38h)
{
    uint64_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 *puVar7;
    undefined *puVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined uStack_48;
    int64_t var_47h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar9 = *(int64_t *)(arg1 + 8);
    iVar10 = 0;
    if (*(int32_t *)(*(int64_t *)(iVar9 + -8) + 8) == *(int32_t *)0x180782668) {
        iVar10 = *(int64_t *)(iVar9 + -8);
    }
    do {
        if ((iVar10 == 0) || (*(int32_t *)(iVar10 + 0x20) != 7)) {
            return;
        }
        *(undefined8 *)(iVar9 + -8) = *(undefined8 *)(iVar10 + 0x28);
        puVar7 = *(undefined8 **)(arg1 + 8);
        if (puVar7 == *(undefined8 **)(arg1 + 0x10)) {
            iVar9 = (int64_t)puVar7 - *(int64_t *)arg1 >> 3;
            if (iVar9 == 0x1fffffffffffffff) {
                fcn.180010010();
                pcVar3 = (code *)swi(3);
                (*pcVar3)();
                return;
            }
            uVar5 = (int64_t)*(undefined8 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3;
            puVar8 = &uStack_48;
            if (0x1fffffffffffffff - (uVar5 >> 1) < uVar5) {
code_r0x0001800b39f8:
                *(undefined8 *)(puVar8 + -8) = 0x1800b39fd;
                fcn.180004720();
                pcVar3 = (code *)swi(3);
                (*pcVar3)();
                return;
            }
            uVar1 = iVar9 + 1;
            uVar5 = uVar5 + (uVar5 >> 1);
            uVar11 = uVar1;
            if (uVar1 <= uVar5) {
                uVar11 = uVar5;
            }
            puVar8 = &uStack_48;
            if (0x1fffffffffffffff < uVar11) goto code_r0x0001800b39f8;
            uVar5 = uVar11 * 8;
            if (uVar5 == 0) {
                uVar5 = 0;
            } else if (uVar5 < 0x1000) {
                uVar5 = fcn.180459890();
            } else {
                puVar8 = &uStack_48;
                if (uVar5 + 0x27 <= uVar5) goto code_r0x0001800b39f8;
                iVar4 = fcn.180459890(uVar5 + 0x27);
                if (iVar4 == 0) {
                    pcVar3 = (code *)swi(0x29);
                    (*pcVar3)(5);
                    puVar8 = (undefined *)((int64_t)&var_47h + 7);
                    goto code_r0x0001800b39f8;
                }
                uVar5 = iVar4 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar5 - 8) = iVar4;
            }
            *(undefined8 *)(uVar5 + iVar9 * 8) = *(undefined8 *)(iVar10 + 0x30);
            puVar2 = *(undefined8 **)arg1;
            if (puVar7 == *(undefined8 **)(arg1 + 8)) {
                iVar10 = (int64_t)*(undefined8 **)(arg1 + 8) - (int64_t)puVar2;
                uVar6 = uVar5;
                puVar7 = puVar2;
            } else {
                fcn.180498030(uVar5, puVar2, (int64_t)puVar7 - (int64_t)puVar2);
                iVar10 = *(int64_t *)(arg1 + 8) - (int64_t)puVar7;
                uVar6 = uVar5 + (iVar9 + 1) * 8;
            }
            fcn.180498030(uVar6, puVar7, iVar10);
            func_0x0001800c2120(arg1, uVar5, uVar1, uVar11);
        } else {
            *puVar7 = *(undefined8 *)(iVar10 + 0x30);
            *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 8;
        }
        iVar9 = *(int64_t *)(arg1 + 8);
        iVar10 = 0;
        if (*(int32_t *)(*(int64_t *)(iVar9 + -8) + 8) == *(int32_t *)0x180782668) {
            iVar10 = *(int64_t *)(iVar9 + -8);
        }
    } while( true );
}

// ============================================================
// Function: FUN_1800b3a10
// Address: 0x1800b3a10
// Size: 331 bytes
// ============================================================
void fcn.1800b3a10(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    uint64_t *puVar1;
    uint64_t uVar2;
    undefined4 *puVar3;
    code *pcVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    undefined4 *puVar10;
    undefined *puVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    uint64_t uVar14;
    undefined8 uVar15;
    int64_t iVar16;
    uint64_t uVar17;
    int64_t iVar18;
    undefined8 uStack_50;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    undefined auStack_30 [8];
    
    uVar5 = fcn.1800b3150(arg1, arg4);
    if (0xff < uVar5) {
        uVar5 = *(uint32_t *)(arg1 + 0x60c);
        var_40h = arg1;
        var_38h._0_4_ = uVar5;
        uVar6 = func_0x0001800b7be0(arg1, arg4);
        if ((int32_t)uVar6 < 0) {
            uVar6 = uVar5 + 1;
            if (0xff < uVar6) {
                fcn.1800acea0(arg4 + 0xc, 0x18063fbc0, 1, 0xff);
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            *(uint32_t *)(arg1 + 0x60c) = uVar6;
            uVar7 = *(uint32_t *)(arg1 + 0x610);
            if (*(uint32_t *)(arg1 + 0x610) < uVar6) {
                uVar7 = uVar6;
            }
            *(uint32_t *)(arg1 + 0x610) = uVar7;
            func_0x0001800b4ce0(arg1, arg4, uVar5 & 0xff, 1);
            uVar6 = uVar5 & 0xff;
        }
        iVar18 = *(int64_t *)arg1;
        var_48h._0_4_ =
             (((uVar6 & 0xff) << 8 | (uint32_t)(uint8_t)placeholder_2) << 8 | (uint32_t)(uint8_t)arg_28h) << 8 |
             ((uint8_t)placeholder_1 ^ 1) + 0x2d;
        fcn.1800d31a0(iVar18 + 0x28, &var_48h);
        fcn.1800d31a0(iVar18 + 0x40, iVar18 + 0x270);
        *(uint32_t *)(arg1 + 0x60c) = uVar5;
        return;
    }
    arg1 = *(int64_t *)arg1;
    var_48h._0_4_ =
         (((uVar5 & 0xff) << 8 | (uint32_t)(uint8_t)placeholder_2) << 8 | (uint32_t)(uint8_t)arg_28h) << 8 |
         ((uint8_t)placeholder_1 ^ 1) + 0x2f;
    fcn.1800d31a0(arg1 + 0x28, &var_48h);
    puVar1 = (uint64_t *)(arg1 + 0x40);
    piVar12 = &var_38h;
    piVar13 = &var_38h;
    puVar10 = *(undefined4 **)(arg1 + 0x48);
    if (puVar10 != *(undefined4 **)(arg1 + 0x50)) {
        *puVar10 = *(undefined4 *)(arg1 + 0x270);
        *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 4;
        return;
    }
    iVar18 = (int64_t)((int64_t)puVar10 - *puVar1) >> 2;
    if (iVar18 == 0x3fffffffffffffff) {
        var_40h = 0x1800d32f9;
        fcn.180010010();
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    uVar9 = (int64_t)((int64_t)*(undefined4 **)(arg1 + 0x50) - *puVar1) >> 2;
    if (uVar9 <= 0x3fffffffffffffff - (uVar9 >> 1)) {
        uVar2 = iVar18 + 1;
        uVar9 = uVar9 + (uVar9 >> 1);
        uVar14 = uVar2;
        if (uVar2 <= uVar9) {
            uVar14 = uVar9;
        }
        if (uVar14 < 0x4000000000000000) {
            uVar9 = uVar14 * 4;
            if (uVar9 == 0) {
                uVar9 = 0;
                piVar13 = &var_38h;
            } else if (uVar9 < 0x1000) {
                var_40h = 0x1800d3287;
                uVar9 = fcn.180459890();
            } else {
                if (uVar9 + 0x27 <= uVar9) goto code_r0x0001800d32fa;
                var_40h = 0x1800d3268;
                iVar16 = fcn.180459890(uVar9 + 0x27);
                if (iVar16 == 0) {
                    pcVar4 = (code *)swi(0x29);
                    iVar16 = (*pcVar4)(5);
                    piVar12 = (int64_t *)auStack_30;
                }
                uVar9 = iVar16 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar9 - 8) = iVar16;
                piVar13 = piVar12;
            }
            *(undefined4 *)(uVar9 + iVar18 * 4) = *(undefined4 *)(arg1 + 0x270);
            puVar3 = (undefined4 *)*puVar1;
            if (puVar10 == *(undefined4 **)(arg1 + 0x48)) {
                iVar16 = (int64_t)*(undefined4 **)(arg1 + 0x48) - (int64_t)puVar3;
                uVar17 = uVar9;
                puVar10 = puVar3;
            } else {
                *(undefined8 *)((int64_t)piVar13 + -8) = 0x1800d32b0;
                fcn.180498030(uVar9, puVar3, (int64_t)puVar10 - (int64_t)puVar3);
                iVar16 = *(int64_t *)(arg1 + 0x48) - (int64_t)puVar10;
                uVar17 = uVar9 + (iVar18 + 1) * 4;
            }
            *(undefined8 *)((int64_t)piVar13 + -8) = 0x1800d32c7;
            fcn.180498030(uVar17, puVar10, iVar16);
            uVar15 = *(undefined8 *)((int64_t)piVar13 + 0x28);
            *(undefined8 *)((int64_t)piVar13 + 0x30) = *(undefined8 *)((int64_t)piVar13 + 0x30);
            *(undefined8 *)((int64_t)piVar13 + 0x28) = *(undefined8 *)((int64_t)piVar13 + 0x40);
            *(undefined8 *)((int64_t)piVar13 + 0x20) = uVar15;
            *(undefined8 *)((int64_t)piVar13 + 0x18) = *(undefined8 *)((int64_t)piVar13 + 0x48);
            uVar17 = *puVar1;
            if (uVar17 != 0) {
                uVar8 = uVar17;
                puVar11 = (undefined *)((int64_t)piVar13 + -0x10);
                if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x50) - uVar17) >> 2) * 4)) {
                    uVar8 = *(uint64_t *)(uVar17 - 8);
                    uVar17 = (uVar17 - uVar8) - 8;
                    puVar11 = (undefined *)((int64_t)piVar13 + -0x10);
                    if (0x1f < uVar17) {
                        pcVar4 = (code *)swi(0x29);
                        uVar8 = uVar17;
                        (*pcVar4)(5);
                        puVar11 = (undefined *)((int64_t)piVar13 + -8);
                    }
                }
                *(undefined8 *)(puVar11 + -8) = 0x180030d9f;
                fcn.180459c3c(uVar8);
            }
            *puVar1 = uVar9;
            *(uint64_t *)(arg1 + 0x48) = uVar9 + uVar2 * 4;
            *(uint64_t *)(arg1 + 0x50) = uVar9 + uVar14 * 4;
            return;
        }
    }
code_r0x0001800d32fa:
    var_40h = 0x1800d32ff;
    fcn.180004720();
    pcVar4 = (code *)swi(3);
    (*pcVar4)();
    return;
}

// ============================================================
// Function: FUN_1800b3b60
// Address: 0x1800b3b60
// Size: 3964 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_2b7h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_2b6h
// WARNING: [rz-ghidra] Detected overlap for variable var_2b0h
// WARNING: [rz-ghidra] Detected overlap for variable var_2a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_2b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_274h
// WARNING: [rz-ghidra] Detected overlap for variable var_272h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_271h
// WARNING: [rz-ghidra] Detected overlap for variable arg_174h
// WARNING: [rz-ghidra] Detected overlap for variable var_2a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_2a7h
// WARNING: [rz-ghidra] Detected overlap for variable var_2a6h
// WARNING: [rz-ghidra] Detected overlap for variable var_2a5h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ach

void fcn.1800b3b60(int64_t arg1, int64_t arg2, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                  int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_70h, int64_t arg_170h, int64_t arg_180h
                  )
{
    undefined8 *puVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t *arg1_00;
    undefined auVar4 [16];
    uint32_t uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    uint64_t *puVar10;
    int64_t iVar11;
    int32_t *piVar12;
    undefined4 *puVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    undefined8 *puVar16;
    uint64_t uVar17;
    uint64_t uVar18;
    uint64_t uVar19;
    uint64_t uVar20;
    uint8_t in_R8B;
    int64_t iVar21;
    char in_R9B;
    int32_t iVar22;
    uint32_t uVar23;
    uint32_t uVar25;
    uint64_t uVar27;
    char cVar28;
    uint64_t uVar29;
    uint8_t uVar30;
    uint64_t uVar31;
    bool bVar32;
    uint8_t var_2b8h;
    int64_t var_2b7h;
    undefined auStackY_2e8 [32];
    int64_t var_2c8h;
    uint32_t var_2ach;
    undefined4 var_2a8h;
    int64_t var_2a4h;
    int64_t var_298h;
    int64_t var_290h;
    int64_t var_288h;
    int64_t var_280h;
    int64_t var_278h;
    int64_t var_270h;
    uint64_t uStack_268;
    undefined4 uStack_260;
    undefined4 uStack_25c;
    undefined4 uStack_258;
    undefined4 uStack_254;
    int32_t iStack_250;
    uint32_t uStack_24c;
    undefined auStack_248 [16];
    int64_t *piStack_238;
    undefined8 uStack_230;
    uint64_t uStack_228;
    undefined8 uStack_220;
    undefined auStack_218 [16];
    undefined8 uStack_208;
    undefined4 auStack_200 [2];
    undefined8 *puStack_1f8;
    uint64_t uStack_1f0;
    undefined auStack_1e8 [16];
    undefined8 uStack_1d8;
    uint64_t uStack_1d0;
    uint64_t uStack_1c8;
    undefined8 uStack_1b8;
    undefined8 uStack_1b0;
    undefined8 uStack_1a8;
    int64_t *piStack_1a0;
    int32_t iStack_198;
    int64_t *piStack_190;
    uint32_t uStack_188;
    int32_t aiStack_178 [32];
    int32_t aiStack_f8 [30];
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    uint64_t uVar24;
    uint64_t uVar26;
    
    var_68h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_2e8;
    uVar31 = *(uint64_t *)(arg2 + 0x28);
    var_288h = arg2;
    var_2b7h._0_1_ = in_R9B;
    var_2b7h._1_1_ = in_R8B;
    unique0x10000fcd = arg2;
    piStack_238 = (int64_t *)arg1;
    if (uVar31 == 0) {
        puVar10 = (uint64_t *)func_0x0001800c03e0(arg1 + 0x178, (int64_t)&var_2b7h + 7);
        uVar31 = *puVar10;
        unique0x10000e5b = uVar31;
        func_0x0001800d0a10(*(undefined8 *)arg1, 0x18063fa58, uVar31 >> 0x20);
        iVar21 = *(int64_t *)arg1;
        uVar30 = 0;
        if (1 < (uint32_t)(uVar31 >> 0x20)) {
            do {
                uVar30 = uVar30 + 1;
                arg1 = (int64_t)piStack_238;
            } while ((uint32_t)(1 << (uVar30 & 0x1f)) < var_2ach);
        }
        if (var_2ach == 0) {
            cVar28 = '\0';
        } else {
            cVar28 = uVar30 + 1;
        }
        var_298h._0_4_ = (uint32_t)CONCAT11(cVar28, var_2b7h._1_1_) << 8 | 0x35;
        fcn.1800d31a0(iVar21 + 0x28, &var_298h);
        fcn.1800d31a0(iVar21 + 0x40, iVar21 + 0x270);
        arg1 = *(int64_t *)arg1;
        var_298h._0_4_ = (uint32_t)uVar31;
        fcn.1800d31a0(arg1 + 0x28, &var_298h);
        fcn.1800d31a0(arg1 + 0x40, arg1 + 0x270);
        goto code_r0x0001800b49f7;
    }
    uVar29 = 0;
    uVar23 = 0;
    uVar15 = 0;
    uVar9 = 0;
    var_280h._0_4_ = 0;
    var_290h._0_4_ = 0;
    var_298h._0_4_ = 0;
    uVar19 = uVar29;
    uVar20 = uVar29;
    if (uVar31 < 2) {
        uVar25 = uVar15;
        uVar8 = uVar23;
        if (uVar31 != 0) {
            iVar21 = *(int64_t *)(arg2 + 0x20);
            uVar25 = uVar9;
            uVar23 = uVar15;
            uVar8 = uVar15;
            goto code_r0x0001800b3e50;
        }
code_r0x0001800b3d62:
        iVar22 = (int32_t)uVar20;
        var_2a4h._0_4_ = 0;
        var_2a4h._4_4_ = 0;
    } else {
        iVar21 = *(int64_t *)(arg2 + 0x20);
        uVar17 = uVar29;
        uVar18 = uVar29;
        uVar24 = uVar29;
        uVar26 = uVar29;
        uVar27 = uVar29;
        do {
            iVar7 = *(int32_t *)(iVar21 + uVar19 * 0x18);
            uVar20 = (uint64_t)((int32_t)uVar20 + (uint32_t)(iVar7 == 0));
            uVar25 = (int32_t)uVar26 + (uint32_t)(iVar7 != 0);
            uVar26 = (uint64_t)uVar25;
            var_280h._0_4_ = (int32_t)uVar17 + (uint32_t)(iVar7 == 1);
            uVar17 = (uint64_t)(uint32_t)var_280h;
            iVar7 = *(int32_t *)(iVar21 + 0x18 + uVar19 * 0x18);
            uVar23 = (int32_t)uVar24 + (uint32_t)(iVar7 == 0);
            uVar24 = (uint64_t)uVar23;
            var_2a8h = (int32_t)uVar27 + (uint32_t)(iVar7 != 0);
            uVar27 = (uint64_t)var_2a8h;
            var_290h._0_4_ = (int32_t)uVar18 + (uint32_t)(iVar7 == 1);
            uVar18 = (uint64_t)(uint32_t)var_290h;
            uVar19 = uVar19 + 2;
        } while (uVar19 < uVar31 - 1);
        uVar31 = *(uint64_t *)(arg2 + 0x28);
        uVar8 = var_2a8h;
        if (uVar31 <= uVar19) goto code_r0x0001800b3d62;
code_r0x0001800b3e50:
        iVar22 = (int32_t)uVar20;
        iVar7 = *(int32_t *)(iVar21 + uVar19 * 0x18);
        var_298h._0_4_ = (uint32_t)(iVar7 == 0);
        var_2a4h._0_4_ = (uint32_t)(iVar7 != 0);
        var_2a4h._4_4_ = (uint32_t)(iVar7 == 1);
    }
    var_298h._0_4_ = iVar22 + uVar23 + (uint32_t)var_298h;
    var_2a4h._0_4_ = (uint32_t)var_2a4h + uVar25 + uVar8;
    var_2a4h._4_4_ = var_2a4h._4_4_ + (uint32_t)var_280h + (uint32_t)var_290h;
    uVar23 = uVar9;
    if (((uint32_t)var_298h == 0) && ((uint32_t)var_2a4h != 0)) {
        uVar25 = uVar15;
        if (uVar31 != 0) {
            iVar21 = *(int64_t *)(arg2 + 0x20);
            uVar19 = uVar29;
            uVar20 = uVar29;
            do {
                iVar11 = func_0x0001800c13d0(arg1 + 0x100, iVar21 + 8 + uVar20 * 0x18);
                if ((((iVar11 == 0) || ((int32_t *)(iVar11 + 8) == (int32_t *)0x0)) || (*(int32_t *)(iVar11 + 8) != 3))
                   || (uVar25 = 1, *(double *)(iVar11 + 0x10) != (double)(uint64_t)((int32_t)uVar19 + 1))) {
                    uVar25 = uVar9;
                }
                uVar25 = (int32_t)uVar19 + uVar25;
                uVar19 = (uint64_t)uVar25;
                uVar20 = uVar20 + 1;
            } while (uVar20 < uVar31);
        }
        if ((uint32_t)var_2a4h == uVar25 + var_2a4h._4_4_) {
            uVar23 = uVar25;
            var_2a4h._0_4_ = var_2a4h._4_4_;
        }
    }
    arg1_00 = piStack_238;
    iVar21 = var_288h;
    uVar8 = var_2a4h._4_4_;
    uVar25 = (uint32_t)var_2a4h;
    uVar19 = 1;
    uVar30 = 0;
    uVar31 = uVar29;
    if ((uint32_t)var_2a4h < 2) {
        if ((uint32_t)var_2a4h != 0) goto code_r0x0001800b3ea6;
    } else {
        do {
            uVar30 = (uint8_t)(uVar31 + 1);
            uVar31 = uVar31 + 1;
        } while ((uint32_t)(1 << (uVar30 & 0x1f)) < (uint32_t)var_2a4h);
code_r0x0001800b3ea6:
        uVar9 = (uint32_t)(uint8_t)(uVar30 + 1);
    }
    var_290h._0_4_ = *(int32_t *)((int64_t)piStack_238 + 0x60c);
    piStack_1a0 = piStack_238;
    iStack_198 = (uint32_t)var_290h;
    if ((char)var_2b7h == '\0') {
        uVar14 = (uint32_t)var_290h + 1;
        if (0xff < uVar14) {
code_r0x0001800b4a48:
            fcn.1800acea0(iVar21 + 0xc, 0x18063fbc0, uVar19 & 0xffffffff, 0xff);
            goto code_r0x0001800b4a62;
        }
        *(uint32_t *)((int64_t)piStack_238 + 0x60c) = uVar14;
        uVar5 = *(uint32_t *)(piStack_238 + 0xc2);
        if (*(uint32_t *)(piStack_238 + 0xc2) < uVar14) {
            uVar5 = uVar14;
        }
        *(uint32_t *)(piStack_238 + 0xc2) = uVar5;
        var_2b8h = (uint8_t)(uint32_t)var_290h;
    } else {
        var_2b8h = var_2b7h._1_1_;
    }
    auStack_218 = ZEXT816(0);
    uStack_208 = 0;
    var_288h = (int64_t)auStack_200;
    auStack_200[0] = 0;
    puStack_1f8 = (undefined8 *)0x0;
    uStack_1f0 = 0;
    puStack_1f8 = (undefined8 *)fcn.180459890(0x20);
    *puStack_1f8 = puStack_1f8;
    puStack_1f8[1] = puStack_1f8;
    auStack_1e8 = ZEXT816(0);
    uStack_1d8 = 0;
    uStack_1d0 = 7;
    uStack_1c8 = 8;
    auStack_200[0] = 0x3f800000;
    func_0x00018000f7e0(auStack_1e8, 0x10, puStack_1f8);
    if ((((uint32_t)var_298h == 0) && (uVar23 == 0)) && ((uVar25 == uVar8 && ((uVar8 != 0 && (uVar8 < 0x21)))))) {
        var_78h._0_4_ = 0;
        var_78h._4_1_ = 0;
        if (*(char *)0x180777fb8 == '\0') {
            uVar31 = uVar29;
            uVar19 = uVar29;
            if (*(int64_t *)(iVar21 + 0x28) != 0) {
                do {
                    uVar20 = *(uint64_t *)(*(int64_t *)(iVar21 + 0x20) + 8 + uVar19 * 0x18);
                    var_288h = uVar29;
                    if (*(int32_t *)(uVar20 + 8) == *(int32_t *)0x18078273c) {
                        var_288h = uVar20;
                    }
                    iVar11 = *arg1_00;
                    uStack_228 = *(uint64_t *)(var_288h + 0x20);
                    uStack_220 = *(undefined8 *)(var_288h + 0x28);
                    auStack_248._0_4_ = func_0x0001800cf010(iVar11, &uStack_228);
                    iStack_250 = 5;
                    auStack_248._4_12_ = SUB1612(ZEXT816(0), 4);
                    uStack_1b8 = (int64_t *)CONCAT44(uStack_1b8._4_4_, 5);
                    uStack_1b0 = (uint64_t)(uint32_t)auStack_248._0_4_;
                    uStack_1a8 = 0;
                    iVar7 = func_0x0001800ced20(iVar11, &uStack_1b8, &iStack_250);
                    if (iVar7 < 0) {
                        fcn.1800acea0(var_288h + 0xc, 0x18063f5a0);
                        pcVar3 = (code *)swi(3);
                        (*pcVar3)();
                        return;
                    }
                    aiStack_178[uVar31] = iVar7;
                    var_78h._0_4_ = (uint32_t)var_78h + 1;
                    uVar19 = uVar19 + 1;
                    uVar31 = (uint64_t)(uint32_t)var_78h;
                } while (uVar19 < *(uint64_t *)(iVar21 + 0x28));
            }
        } else {
            uVar31 = uVar29;
            if (*(int64_t *)(iVar21 + 0x28) != 0) {
                do {
                    var_288h = *(int64_t *)(iVar21 + 0x20);
                    uVar19 = *(uint64_t *)(var_288h + 8 + uVar31 * 0x18);
                    uStack_228 = uVar29;
                    if (*(int32_t *)(uVar19 + 8) == *(int32_t *)0x18078273c) {
                        uStack_228 = uVar19;
                    }
                    iVar11 = *arg1_00;
                    piStack_238 = *(int64_t **)(uStack_228 + 0x20);
                    uStack_230 = *(undefined8 *)(uStack_228 + 0x28);
                    auStack_248._0_4_ = func_0x0001800cf010(iVar11, &piStack_238);
                    iStack_250 = 5;
                    auStack_248._4_12_ = SUB1612(ZEXT816(0), 4);
                    uStack_1b8 = (int64_t *)CONCAT44(uStack_1b8._4_4_, 5);
                    uStack_1b0 = (uint64_t)(uint32_t)auStack_248._0_4_;
                    uStack_1a8 = 0;
                    var_2a8h = func_0x0001800ced20(iVar11, &uStack_1b8, &iStack_250);
                    if ((int32_t)var_2a8h < 0) {
                        fcn.1800acea0(uStack_228 + 0xc, 0x18063f5a0);
                        pcVar3 = (code *)swi(3);
                        (*pcVar3)();
                        return;
                    }
                    uVar6 = fcn.1800b3150((int64_t)arg1_00, *(int64_t *)(var_288h + 0x10 + uVar31 * 0x18));
                    stack0xfffffffffffffd50 = CONCAT44(var_2ach, uVar6);
                    uVar19 = (((((uint64_t)(var_2a8h & 0xff) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)var_2a8h._1_1_) * 0x100000001b3 ^ (uint64_t)var_2a8h._2_1_) * 0x100000001b3 ^
                             (uint64_t)var_2a8h._3_1_) * 0x100000001b3 & uStack_1d0;
                    puVar16 = *(undefined8 **)(auStack_1e8._0_8_ + 8 + uVar19 * 0x10);
                    if (puVar16 == puStack_1f8) {
code_r0x0001800b40e0:
                        puVar16 = (undefined8 *)0x0;
                    } else {
                        uVar23 = *(uint32_t *)(puVar16 + 2);
                        while (var_2a8h != uVar23) {
                            if (puVar16 == *(undefined8 **)(auStack_1e8._0_8_ + uVar19 * 0x10))
                            goto code_r0x0001800b40e0;
                            puVar16 = (undefined8 *)puVar16[1];
                            uVar23 = *(uint32_t *)(puVar16 + 2);
                        }
                    }
                    if ((puVar16 == (undefined8 *)0x0) ||
                       (piVar12 = (int32_t *)func_0x0001800befb0(auStack_218, &var_2a8h), *piVar12 != -1)) {
                        puVar13 = (undefined4 *)func_0x0001800befb0(auStack_218, &var_2a8h);
                        *puVar13 = stack0xfffffffffffffd50;
                    }
                    uVar31 = uVar31 + 1;
                } while (uVar31 < *(uint64_t *)(iVar21 + 0x28));
            }
            uVar31 = uVar29;
            for (piVar12 = (int32_t *)auStack_218._0_8_; piVar12 != (int32_t *)auStack_218._8_8_; piVar12 = piVar12 + 2)
            {
                aiStack_178[uVar31] = *piVar12;
                iVar7 = piVar12[1];
                aiStack_f8[uVar31] = iVar7;
                if (-1 < iVar7) {
                    var_78h._4_1_ = 1;
                }
                var_78h._0_4_ = (uint32_t)var_78h + 1;
                uVar31 = (uint64_t)(uint32_t)var_78h;
            }
        }
        uVar23 = func_0x0001800cf840(*arg1_00, aiStack_178);
        if ((int32_t)uVar23 < 0) {
code_r0x0001800b4a62:
            fcn.1800acea0(iVar21 + 0xc, 0x18063f5a0);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        func_0x0001800d0a10(*arg1_00, 0x18063fa78, (uint32_t)var_2a4h);
        if ((int32_t)uVar23 < 0x8000) {
            stack0xfffffffffffffd50 = CONCAT44(var_2ach, ((uVar23 & 0xffff) << 8 | (uint32_t)var_2b8h) << 8) | 0x36;
        } else {
            auVar4 = auStack_1e8;
            if (*(char *)0x180777fb8 != '\0') {
                if (auStack_218._0_8_ != auStack_218._8_8_) {
                    auStack_218._8_8_ = auStack_218._0_8_;
                }
                if (uStack_1f0 != 0) {
                    if (uStack_1f0 < uStack_1c8 >> 3) {
                        func_0x0001800c1e90(auStack_200, *puStack_1f8, puStack_1f8);
                        auVar4 = auStack_1e8;
                    } else {
                        *(undefined8 *)puStack_1f8[1] = 0;
                        puVar16 = (undefined8 *)*puStack_1f8;
                        while (puVar16 != (undefined8 *)0x0) {
                            puVar1 = (undefined8 *)*puVar16;
                            auStack_1e8 = auVar4;
                            fcn.180459c3c(puVar16, 0x20);
                            puVar16 = puVar1;
                            auVar4 = auStack_1e8;
                        }
                        *puStack_1f8 = puStack_1f8;
                        puStack_1f8[1] = puStack_1f8;
                        uStack_1f0 = 0;
                        auStack_1e8._0_8_ = auVar4._0_8_;
                        auStack_1e8._8_8_ = auVar4._8_8_;
                        uVar31 = (uint64_t)(auStack_1e8._8_8_ + (7 - auStack_1e8._0_8_)) >> 3;
                        if ((uint64_t)auStack_1e8._8_8_ < (uint64_t)auStack_1e8._0_8_) {
                            uVar31 = uVar29;
                        }
                        if (uVar31 != 0) {
                            for (; uVar31 != 0; uVar31 = uVar31 - 1) {
                                *(undefined8 **)auStack_1e8._0_8_ = puStack_1f8;
                                auStack_1e8._0_8_ = (undefined8 *)(auStack_1e8._0_8_ + 8);
                            }
                        }
                    }
                }
            }
            auStack_1e8 = auVar4;
            iVar11 = *arg1_00;
            stack0xfffffffffffffd50 = CONCAT44(var_2ach, (uVar9 << 8 | (uint32_t)var_2b8h) << 8) | 0x35;
            fcn.1800d31a0(iVar11 + 0x28, (int64_t)&var_2b7h + 7);
            fcn.1800d31a0(iVar11 + 0x40, iVar11 + 0x270);
            stack0xfffffffffffffd50 = stack0xfffffffffffffd50 & 0xffffffff00000000;
        }
    } else {
        if ((*(int64_t *)(iVar21 + 0x28) == 0) ||
           (((piVar12 = (int32_t *)(*(int64_t *)(iVar21 + 0x20) + (*(int64_t *)(iVar21 + 0x28) * 3 + -3) * 8),
             piVar12 == (int32_t *)0x0 || (*piVar12 != 0)) ||
            (uVar8 = 1, *(int32_t *)(*(int64_t *)(piVar12 + 4) + 8) != *(int32_t *)0x1807826b8)))) {
            uVar8 = uVar15;
        }
        iVar7 = (uVar23 - uVar8) + (uint32_t)var_298h;
        iVar11 = *arg1_00;
        if (uVar25 == 0) {
            func_0x0001800d0a10(iVar11, 0x18063fa98, iVar7);
        } else if (iVar7 == 0) {
            func_0x0001800d0a10(iVar11, 0x18063fa58, uVar25);
        } else {
            func_0x0001800d0a10(iVar11, 0x18063f980, uVar25, iVar7);
        }
        iVar11 = *arg1_00;
        stack0xfffffffffffffd50 = CONCAT44(var_2ach, (uVar9 << 8 | (uint32_t)var_2b8h) << 8) | 0x35;
        fcn.1800d31a0(iVar11 + 0x28, (int64_t)&var_2b7h + 7);
        fcn.1800d31a0(iVar11 + 0x40, iVar11 + 0x270);
        stack0xfffffffffffffd50 = CONCAT44(var_2ach, iVar7);
    }
    iVar11 = *arg1_00;
    fcn.1800d31a0(iVar11 + 0x28, (int64_t)&var_2b7h + 7);
    fcn.1800d31a0(iVar11 + 0x40, iVar11 + 0x270);
    var_288h = 0x10;
    if ((uint32_t)var_298h < 0x10) {
        var_288h = (int64_t)(uint32_t)var_298h;
    }
    var_2a4h._4_4_ = *(uint32_t *)((int64_t)arg1_00 + 0x60c);
    uVar23 = var_2a4h._4_4_ + (int32_t)var_288h;
    if (0xff < uVar23) {
        fcn.1800acea0(iVar21 + 0xc, 0x18063fbc0, var_288h, 0xff);
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    *(uint32_t *)((int64_t)arg1_00 + 0x60c) = uVar23;
    uVar9 = *(uint32_t *)(arg1_00 + 0xc2);
    if (*(uint32_t *)(arg1_00 + 0xc2) < uVar23) {
        uVar9 = uVar23;
    }
    *(uint32_t *)(arg1_00 + 0xc2) = uVar9;
    var_2a4h._0_4_ = 1;
    var_2b7h._0_1_ = '\0';
    piStack_238 = (int64_t *)0x0;
    uVar31 = uVar29;
    if (*(int64_t *)(iVar21 + 0x28) != 0) {
        do {
            iVar7 = (int32_t)uVar31;
            uVar20 = *(uint64_t *)(*(int64_t *)(iVar21 + 0x20) + 8 + (int64_t)piStack_238 * 0x18);
            iVar11 = *(int64_t *)(*(int64_t *)(iVar21 + 0x20) + 0x10 + (int64_t)piStack_238 * 0x18);
            if (*(char *)0x180777fb8 == '\0') {
code_r0x0001800b462f:
                if (0 < *(int32_t *)((int64_t)arg1_00 + 0xc)) {
                    *(int32_t *)(*arg1_00 + 0x270) = *(int32_t *)(iVar11 + 0xc) + 1;
                }
                if (1 < *(int32_t *)((int64_t)arg1_00 + 0x14)) {
                    iVar2 = *arg1_00;
                    stack0xfffffffffffffd50 = CONCAT44(var_2ach, 0x45);
                    fcn.1800d31a0(iVar2 + 0x28, (int64_t)&var_2b7h + 7);
                    fcn.1800d31a0(iVar2 + 0x40, iVar2 + 0x270);
                }
                if (iVar7 == 0) {
code_r0x0001800b4704:
                    iVar7 = (int32_t)uVar31;
                    if (uVar20 != 0) {
                        uVar23 = *(uint32_t *)((int64_t)arg1_00 + 0x60c);
                        piStack_190 = arg1_00;
                        uStack_188 = uVar23;
                        fcn.1800b29d0((int64_t)arg1_00, (int64_t)&iStack_250, uVar20);
                        if (iStack_250 == 3) {
                            if ((((double)auStack_248._0_8_ < 1.0) || (256.0 < (double)auStack_248._0_8_)) ||
                               ((double)(int32_t)(double)auStack_248._0_8_ != (double)auStack_248._0_8_)) {
code_r0x0001800b47a5:
                                var_270h = 0;
                                uStack_268 = 0;
                                var_278h._0_5_ = CONCAT14(var_2b8h, 5);
                                var_278h = (int64_t)(unkuint5)var_278h;
                                uVar9 = func_0x0001800b7be0(arg1_00, uVar20);
                                if ((int32_t)uVar9 < 0) {
                                    uVar9 = uVar23 + 1;
                                    if (0xff < uVar9) {
                                        uVar19 = 0x18063fbc0;
                                        fcn.1800acea0(uVar20 + 0xc, 0x18063fbc0, 1, 0xff);
                                        goto code_r0x0001800b4a48;
                                    }
                                    *(uint32_t *)((int64_t)arg1_00 + 0x60c) = uVar9;
                                    uVar15 = *(uint32_t *)(arg1_00 + 0xc2);
                                    if (*(uint32_t *)(arg1_00 + 0xc2) < uVar9) {
                                        uVar15 = uVar9;
                                    }
                                    *(uint32_t *)(arg1_00 + 0xc2) = uVar15;
                                    func_0x0001800b4ce0(arg1_00, uVar20, uVar23 & 0xff, 1);
                                    uVar9 = uVar23 & 0xff;
                                }
                                var_278h._0_7_ = CONCAT16((char)uVar9, (unkbyte6)var_278h);
                            } else {
                                var_270h = 0;
                                uStack_268 = 0;
                                var_278h._0_5_ = CONCAT14(var_2b8h, 4);
                                var_278h._0_7_ = (unkuint7)(unkuint5)var_278h;
                                var_278h = CONCAT17((char)(int32_t)(double)auStack_248._0_8_ + -1, (unkuint7)var_278h);
                            }
                        } else {
                            if (iStack_250 != 6) goto code_r0x0001800b47a5;
                            var_278h._0_5_ = CONCAT14(var_2b8h, 3);
                            var_278h = (int64_t)(unkuint5)var_278h;
                            var_270h = auStack_248._0_8_;
                            uStack_268 = (uint64_t)uStack_24c;
                        }
                        uStack_260 = *(undefined4 *)(uVar20 + 0xc);
                        uStack_25c = *(undefined4 *)(uVar20 + 0x10);
                        uStack_258 = *(undefined4 *)(uVar20 + 0x14);
                        uStack_254 = *(undefined4 *)(uVar20 + 0x18);
                        uVar9 = func_0x0001800b7be0(arg1_00, iVar11);
                        if ((int32_t)uVar9 < 0) {
                            uVar9 = *(uint32_t *)((int64_t)arg1_00 + 0x60c);
                            uVar15 = uVar9 + 1;
                            if (0xff < uVar15) {
code_r0x0001800b4abe:
                                fcn.1800acea0(iVar11 + 0xc, 0x18063fbc0, 1, 0xff);
                                pcVar3 = (code *)swi(3);
                                (*pcVar3)();
                                return;
                            }
                            *(uint32_t *)((int64_t)arg1_00 + 0x60c) = uVar15;
                            uVar25 = *(uint32_t *)(arg1_00 + 0xc2);
                            if (*(uint32_t *)(arg1_00 + 0xc2) < uVar15) {
                                uVar25 = uVar15;
                            }
                            *(uint32_t *)(arg1_00 + 0xc2) = uVar25;
                            func_0x0001800b4ce0(arg1_00, iVar11, (char)uVar9, 1);
                        }
                        func_0x0001800b77e0(arg1_00, &var_278h, uVar9 & 0xff, 1);
                        *(uint32_t *)((int64_t)arg1_00 + 0x60c) = uVar23;
                        uVar23 = var_2a4h._4_4_;
                        goto code_r0x0001800b489a;
                    }
                } else if ((uVar20 != 0) || (iVar7 == (int32_t)var_288h)) {
                    iVar2 = *arg1_00;
                    stack0xfffffffffffffd50 =
                         CONCAT44(var_2ach, 
                                  (((iVar7 + 1U & 0xff) << 8 | var_2a4h._4_4_ & 0xff) << 8 | (uint32_t)var_2b8h) << 8) |
                         0x37;
                    fcn.1800d31a0(iVar2 + 0x28, (int64_t)&var_2b7h + 7);
                    fcn.1800d31a0(iVar2 + 0x40, iVar2 + 0x270);
                    iVar2 = *arg1_00;
                    stack0xfffffffffffffd50 = CONCAT44(var_2ach, (uint32_t)var_2a4h);
                    fcn.1800d31a0(iVar2 + 0x28, (int64_t)&var_2b7h + 7);
                    fcn.1800d31a0(iVar2 + 0x40, iVar2 + 0x270);
                    var_2a4h._0_4_ = (uint32_t)var_2a4h + iVar7;
                    uVar31 = uVar29;
                    goto code_r0x0001800b4704;
                }
                uVar23 = var_2a4h._4_4_;
                if ((int64_t)piStack_238 + 1 == *(int64_t *)(iVar21 + 0x28)) {
                    var_2b7h._0_1_ =
                         fcn.1800aed40((int64_t)arg1_00, iVar11, 
                                       CONCAT53(var_2b7h._2_5_, 
                                                CONCAT12(var_2b7h._1_1_, CONCAT11((char)var_2b7h, var_2b8h))));
                    uVar31 = (uint64_t)(iVar7 + 1);
                } else {
                    uVar6 = *(undefined4 *)((int64_t)arg1_00 + 0x60c);
                    uStack_1b0 = CONCAT44(uStack_1b0._4_4_, uVar6);
                    *(uint32_t *)((int64_t)arg1_00 + 0x60c) = (var_2a4h._4_4_ + iVar7 & 0xff) + 1;
                    uStack_1b8 = arg1_00;
                    func_0x0001800b4ce0(arg1_00, iVar11, var_2a4h._4_4_ + iVar7, 1);
                    *(undefined4 *)((int64_t)arg1_00 + 0x60c) = uVar6;
                    uVar31 = (uint64_t)(iVar7 + 1);
                }
            } else {
                if ((((int64_t)(auStack_218._8_8_ - auStack_218._0_8_) >> 3 == 0) || (uVar20 == 0)) ||
                   (bVar32 = *(int32_t *)(uVar20 + 8) != *(int32_t *)0x18078273c, bVar32)) goto code_r0x0001800b462f;
                iVar2 = *arg1_00;
                uVar19 = uVar29;
                if (!bVar32) {
                    uVar19 = uVar20;
                }
                uStack_228 = *(uint64_t *)(uVar19 + 0x20);
                uStack_220 = *(undefined8 *)(uVar19 + 0x28);
                auStack_248._0_4_ = func_0x0001800cf010(iVar2, &uStack_228);
                iStack_250 = 5;
                auStack_248._4_12_ = SUB1612(ZEXT816(0), 4);
                var_278h = CONCAT44(var_278h._4_4_, 5);
                var_270h = (int64_t)(uint32_t)auStack_248._0_4_;
                uStack_268 = 0;
                uVar23 = func_0x0001800ced20(iVar2, &var_278h, &iStack_250);
                uVar19 = (((((uint64_t)(uVar23 & 0xff) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                           (uint64_t)((int32_t)uVar23 >> 8 & 0xff)) * 0x100000001b3 ^
                          (uint64_t)((int32_t)uVar23 >> 0x10 & 0xff)) * 0x100000001b3 ^
                         (uint64_t)((int32_t)uVar23 >> 0x18 & 0xff)) * 0x100000001b3 & uStack_1d0;
                puVar16 = *(undefined8 **)(auStack_1e8._0_8_ + 8 + uVar19 * 0x10);
                if (puVar16 == puStack_1f8) {
code_r0x0001800b45f0:
                    puVar16 = (undefined8 *)0x0;
                } else {
                    uVar9 = *(uint32_t *)(puVar16 + 2);
                    while (uVar23 != uVar9) {
                        if (puVar16 == *(undefined8 **)(auStack_1e8._0_8_ + uVar19 * 0x10)) goto code_r0x0001800b45f0;
                        puVar16 = (undefined8 *)puVar16[1];
                        uVar9 = *(uint32_t *)(puVar16 + 2);
                    }
                }
                if ((puVar16 == (undefined8 *)0x0) || (puVar16 == puStack_1f8)) goto code_r0x0001800b462f;
                if ((uint64_t)((int64_t)(auStack_218._8_8_ - auStack_218._0_8_) >> 3) <= (uint64_t)puVar16[3]) {
                    func_0x000180060370();
                    goto code_r0x0001800b4abe;
                }
                piVar12 = (int32_t *)(auStack_218._0_8_ + 4 + puVar16[3] * 8);
                if ((piVar12 == (int32_t *)0x0) || (uVar23 = var_2a4h._4_4_, *piVar12 < 0)) goto code_r0x0001800b462f;
            }
code_r0x0001800b489a:
            piStack_238 = (int64_t *)((int64_t)piStack_238 + 1);
        } while (piStack_238 < *(int64_t **)(iVar21 + 0x28));
        if ((int32_t)uVar31 != 0) {
            iVar21 = *arg1_00;
            if ((char)var_2b7h == '\0') {
                uVar30 = (char)uVar31 + 1;
            } else {
                uVar30 = 0;
            }
            stack0xfffffffffffffd50 =
                 CONCAT44(var_2ach, (((uint32_t)uVar30 << 8 | uVar23 & 0xff) << 8 | (uint32_t)var_2b8h) << 8) | 0x37;
            fcn.1800d31a0(iVar21 + 0x28, (int64_t)&var_2b7h + 7);
            fcn.1800d31a0(iVar21 + 0x40, iVar21 + 0x270);
            iVar21 = *arg1_00;
            stack0xfffffffffffffd50 = CONCAT44(var_2ach, (uint32_t)var_2a4h);
            fcn.1800d31a0(iVar21 + 0x28, (int64_t)&var_2b7h + 7);
            fcn.1800d31a0(iVar21 + 0x40, iVar21 + 0x270);
        }
    }
    if (var_2b7h._1_1_ != var_2b8h) {
        iVar21 = *arg1_00;
        stack0xfffffffffffffd50 = CONCAT44(var_2ach, (uint32_t)CONCAT11(var_2b8h, var_2b7h._1_1_) << 8) | 6;
        fcn.1800d31a0(iVar21 + 0x28, (int64_t)&var_2b7h + 7);
        fcn.1800d31a0(iVar21 + 0x40, iVar21 + 0x270);
    }
    func_0x00018000ace0(auStack_1e8);
    func_0x00018001c440(&puStack_1f8);
    func_0x00018000ace0(auStack_218);
    *(uint32_t *)((int64_t)arg1_00 + 0x60c) = (uint32_t)var_290h;
code_r0x0001800b49f7:
    func_0x000180459870(var_68h ^ (uint64_t)auStackY_2e8);
    return;
}

// ============================================================
// Function: FUN_1800b4ae0
// Address: 0x1800b4ae0
// Size: 42 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.1800b4ae0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    double dVar1;
    undefined8 uVar2;
    code *pcVar3;
    undefined auVar4 [16];
    int32_t iVar5;
    uint32_t uVar6;
    uint8_t in_R9B;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    undefined8 uStack_48;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_8h;
    
    auVar4 = _var_50h;
    if (5 < *(int32_t *)arg3 - 1U) {
        return;
    }
    // switch table (6 cases) at 0x1800b4cc4
    switch(*(int32_t *)arg3) {
    case 1:
        var_68h._0_4_ = (uint32_t)var_68h._1_3_ << 8;
        func_0x0001800cfdd0(*(undefined8 *)arg1, 2, in_R9B, 0, (int32_t)var_68h);
        return;
    case 2:
        var_68h._0_4_ = (uint32_t)var_68h._1_3_ << 8;
        func_0x0001800cfdd0(*(undefined8 *)arg1, 3, in_R9B, *(undefined *)(arg3 + 8), (int32_t)var_68h);
        return;
    case 3:
        dVar1 = *(double *)(arg3 + 8);
        if ((((-32768.0 <= dVar1) && (dVar1 <= 32767.0)) && ((double)(int32_t)(int16_t)(int32_t)dVar1 == dVar1)) &&
           ((dVar1 != 0.0 || (iVar5 = func_0x00018046ea20(), iVar5 == 0)))) {
            func_0x0001800cfe30(*(undefined8 *)arg1, 4, in_R9B, (int32_t)dVar1 & 0xffff);
            return;
        }
        uVar6 = func_0x0001800cf660(*(undefined8 *)arg1, SUB84(dVar1, 0));
        break;
    case 4:
        uVar6 = func_0x0001800cf6b0(*(undefined8 *)arg1, *(undefined8 *)(arg3 + 8));
        break;
    case 5:
        uVar6 = func_0x0001800cf700(*(undefined8 *)arg1, *(undefined4 *)(arg3 + 8), *(undefined4 *)(arg3 + 0xc), 
                                    *(undefined4 *)(arg3 + 0x10), *(undefined4 *)(arg3 + 0x14));
        break;
    case 6:
        var_58h = *(int64_t *)(arg3 + 8);
        uVar2 = *(undefined8 *)arg1;
        var_50h._4_4_ = 0;
        var_50h._0_4_ = *(uint32_t *)(arg3 + 4);
        uStack_48 = auVar4._8_8_;
        var_50h._0_4_ = func_0x0001800cf010(uVar2, &var_58h);
        var_58h = CONCAT44(var_58h._4_4_, 5);
        stack0xffffffffffffffb4 = SUB1612(ZEXT816(0), 4);
        var_30h = (int64_t)(uint32_t)var_50h;
        var_38h._0_4_ = 5;
        var_28h = 0;
        uVar6 = func_0x0001800ced20(uVar2, &var_38h, &var_58h);
    }
    if (-1 < (int32_t)uVar6) {
        fcn.1800ad460(arg1, (uint64_t)in_R9B, (uint64_t)uVar6);
        return;
    }
    fcn.1800acea0(arg2 + 0xc, 0x18063f5a0);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_1800b4b0a
// Address: 0x1800b4b0a
// Size: 244 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.1800b4ae0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    double dVar1;
    undefined8 uVar2;
    code *pcVar3;
    undefined auVar4 [16];
    int32_t iVar5;
    uint32_t uVar6;
    uint8_t in_R9B;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    undefined8 uStack_48;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_8h;
    
    auVar4 = _var_50h;
    if (5 < *(int32_t *)arg3 - 1U) {
        return;
    }
    // switch table (6 cases) at 0x1800b4cc4
    switch(*(int32_t *)arg3) {
    case 1:
        var_68h._0_4_ = (uint32_t)var_68h._1_3_ << 8;
        func_0x0001800cfdd0(*(undefined8 *)arg1, 2, in_R9B, 0, (int32_t)var_68h);
        return;
    case 2:
        var_68h._0_4_ = (uint32_t)var_68h._1_3_ << 8;
        func_0x0001800cfdd0(*(undefined8 *)arg1, 3, in_R9B, *(undefined *)(arg3 + 8), (int32_t)var_68h);
        return;
    case 3:
        dVar1 = *(double *)(arg3 + 8);
        if ((((-32768.0 <= dVar1) && (dVar1 <= 32767.0)) && ((double)(int32_t)(int16_t)(int32_t)dVar1 == dVar1)) &&
           ((dVar1 != 0.0 || (iVar5 = func_0x00018046ea20(), iVar5 == 0)))) {
            func_0x0001800cfe30(*(undefined8 *)arg1, 4, in_R9B, (int32_t)dVar1 & 0xffff);
            return;
        }
        uVar6 = func_0x0001800cf660(*(undefined8 *)arg1, SUB84(dVar1, 0));
        break;
    case 4:
        uVar6 = func_0x0001800cf6b0(*(undefined8 *)arg1, *(undefined8 *)(arg3 + 8));
        break;
    case 5:
        uVar6 = func_0x0001800cf700(*(undefined8 *)arg1, *(undefined4 *)(arg3 + 8), *(undefined4 *)(arg3 + 0xc), 
                                    *(undefined4 *)(arg3 + 0x10), *(undefined4 *)(arg3 + 0x14));
        break;
    case 6:
        var_58h = *(int64_t *)(arg3 + 8);
        uVar2 = *(undefined8 *)arg1;
        var_50h._4_4_ = 0;
        var_50h._0_4_ = *(uint32_t *)(arg3 + 4);
        uStack_48 = auVar4._8_8_;
        var_50h._0_4_ = func_0x0001800cf010(uVar2, &var_58h);
        var_58h = CONCAT44(var_58h._4_4_, 5);
        stack0xffffffffffffffb4 = SUB1612(ZEXT816(0), 4);
        var_30h = (int64_t)(uint32_t)var_50h;
        var_38h._0_4_ = 5;
        var_28h = 0;
        uVar6 = func_0x0001800ced20(uVar2, &var_38h, &var_58h);
    }
    if (-1 < (int32_t)uVar6) {
        fcn.1800ad460(arg1, (uint64_t)in_R9B, (uint64_t)uVar6);
        return;
    }
    fcn.1800acea0(arg2 + 0xc, 0x18063f5a0);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_1800b4bfe
// Address: 0x1800b4bfe
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.1800b4ae0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    double dVar1;
    undefined8 uVar2;
    code *pcVar3;
    undefined auVar4 [16];
    int32_t iVar5;
    uint32_t uVar6;
    uint8_t in_R9B;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    undefined8 uStack_48;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_8h;
    
    auVar4 = _var_50h;
    if (5 < *(int32_t *)arg3 - 1U) {
        return;
    }
    // switch table (6 cases) at 0x1800b4cc4
    switch(*(int32_t *)arg3) {
    case 1:
        var_68h._0_4_ = (uint32_t)var_68h._1_3_ << 8;
        func_0x0001800cfdd0(*(undefined8 *)arg1, 2, in_R9B, 0, (int32_t)var_68h);
        return;
    case 2:
        var_68h._0_4_ = (uint32_t)var_68h._1_3_ << 8;
        func_0x0001800cfdd0(*(undefined8 *)arg1, 3, in_R9B, *(undefined *)(arg3 + 8), (int32_t)var_68h);
        return;
    case 3:
        dVar1 = *(double *)(arg3 + 8);
        if ((((-32768.0 <= dVar1) && (dVar1 <= 32767.0)) && ((double)(int32_t)(int16_t)(int32_t)dVar1 == dVar1)) &&
           ((dVar1 != 0.0 || (iVar5 = func_0x00018046ea20(), iVar5 == 0)))) {
            func_0x0001800cfe30(*(undefined8 *)arg1, 4, in_R9B, (int32_t)dVar1 & 0xffff);
            return;
        }
        uVar6 = func_0x0001800cf660(*(undefined8 *)arg1, SUB84(dVar1, 0));
        break;
    case 4:
        uVar6 = func_0x0001800cf6b0(*(undefined8 *)arg1, *(undefined8 *)(arg3 + 8));
        break;
    case 5:
        uVar6 = func_0x0001800cf700(*(undefined8 *)arg1, *(undefined4 *)(arg3 + 8), *(undefined4 *)(arg3 + 0xc), 
                                    *(undefined4 *)(arg3 + 0x10), *(undefined4 *)(arg3 + 0x14));
        break;
    case 6:
        var_58h = *(int64_t *)(arg3 + 8);
        uVar2 = *(undefined8 *)arg1;
        var_50h._4_4_ = 0;
        var_50h._0_4_ = *(uint32_t *)(arg3 + 4);
        uStack_48 = auVar4._8_8_;
        var_50h._0_4_ = func_0x0001800cf010(uVar2, &var_58h);
        var_58h = CONCAT44(var_58h._4_4_, 5);
        stack0xffffffffffffffb4 = SUB1612(ZEXT816(0), 4);
        var_30h = (int64_t)(uint32_t)var_50h;
        var_38h._0_4_ = 5;
        var_28h = 0;
        uVar6 = func_0x0001800ced20(uVar2, &var_38h, &var_58h);
    }
    if (-1 < (int32_t)uVar6) {
        fcn.1800ad460(arg1, (uint64_t)in_R9B, (uint64_t)uVar6);
        return;
    }
    fcn.1800acea0(arg2 + 0xc, 0x18063f5a0);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_1800b4c13
// Address: 0x1800b4c13
// Size: 201 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.1800b4ae0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    double dVar1;
    undefined8 uVar2;
    code *pcVar3;
    undefined auVar4 [16];
    int32_t iVar5;
    uint32_t uVar6;
    uint8_t in_R9B;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    undefined8 uStack_48;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_8h;
    
    auVar4 = _var_50h;
    if (5 < *(int32_t *)arg3 - 1U) {
        return;
    }
    // switch table (6 cases) at 0x1800b4cc4
    switch(*(int32_t *)arg3) {
    case 1:
        var_68h._0_4_ = (uint32_t)var_68h._1_3_ << 8;
        func_0x0001800cfdd0(*(undefined8 *)arg1, 2, in_R9B, 0, (int32_t)var_68h);
        return;
    case 2:
        var_68h._0_4_ = (uint32_t)var_68h._1_3_ << 8;
        func_0x0001800cfdd0(*(undefined8 *)arg1, 3, in_R9B, *(undefined *)(arg3 + 8), (int32_t)var_68h);
        return;
    case 3:
        dVar1 = *(double *)(arg3 + 8);
        if ((((-32768.0 <= dVar1) && (dVar1 <= 32767.0)) && ((double)(int32_t)(int16_t)(int32_t)dVar1 == dVar1)) &&
           ((dVar1 != 0.0 || (iVar5 = func_0x00018046ea20(), iVar5 == 0)))) {
            func_0x0001800cfe30(*(undefined8 *)arg1, 4, in_R9B, (int32_t)dVar1 & 0xffff);
            return;
        }
        uVar6 = func_0x0001800cf660(*(undefined8 *)arg1, SUB84(dVar1, 0));
        break;
    case 4:
        uVar6 = func_0x0001800cf6b0(*(undefined8 *)arg1, *(undefined8 *)(arg3 + 8));
        break;
    case 5:
        uVar6 = func_0x0001800cf700(*(undefined8 *)arg1, *(undefined4 *)(arg3 + 8), *(undefined4 *)(arg3 + 0xc), 
                                    *(undefined4 *)(arg3 + 0x10), *(undefined4 *)(arg3 + 0x14));
        break;
    case 6:
        var_58h = *(int64_t *)(arg3 + 8);
        uVar2 = *(undefined8 *)arg1;
        var_50h._4_4_ = 0;
        var_50h._0_4_ = *(uint32_t *)(arg3 + 4);
        uStack_48 = auVar4._8_8_;
        var_50h._0_4_ = func_0x0001800cf010(uVar2, &var_58h);
        var_58h = CONCAT44(var_58h._4_4_, 5);
        stack0xffffffffffffffb4 = SUB1612(ZEXT816(0), 4);
        var_30h = (int64_t)(uint32_t)var_50h;
        var_38h._0_4_ = 5;
        var_28h = 0;
        uVar6 = func_0x0001800ced20(uVar2, &var_38h, &var_58h);
    }
    if (-1 < (int32_t)uVar6) {
        fcn.1800ad460(arg1, (uint64_t)in_R9B, (uint64_t)uVar6);
        return;
    }
    fcn.1800acea0(arg2 + 0xc, 0x18063f5a0);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_1800b4ce0
// Address: 0x1800b4ce0
// Size: 9036 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_128h
// WARNING: Variable defined which should be unmapped: var_120h
// WARNING: Variable defined which should be unmapped: var_e8h
// WARNING: Variable defined which should be unmapped: var_117h
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: Variable defined which should be unmapped: var_100h
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Detected overlap for variable var_2b6h
// WARNING: [rz-ghidra] Detected overlap for variable var_2b0h
// WARNING: [rz-ghidra] Detected overlap for variable var_2a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_2b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_274h
// WARNING: [rz-ghidra] Detected overlap for variable var_272h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_271h
// WARNING: [rz-ghidra] Detected overlap for variable arg_174h
// WARNING: [rz-ghidra] Detected overlap for variable var_2a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_2a7h
// WARNING: [rz-ghidra] Detected overlap for variable var_2a6h
// WARNING: [rz-ghidra] Detected overlap for variable var_2a5h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ach
// WARNING: [rz-ghidra] Detected overlap for variable var_fh
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_dh
// WARNING: [rz-ghidra] Detected overlap for variable var_127h
// WARNING: [rz-ghidra] Detected overlap for variable var_126h
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.1800b4ce0(int64_t arg1, int64_t arg2)
{
    undefined2 *puVar1;
    uint64_t uVar2;
    code *pcVar3;
    undefined8 *puVar4;
    undefined auVar5 [16];
    undefined auVar6 [16];
    char cVar7;
    undefined uVar8;
    bool bVar9;
    uint8_t uVar10;
    undefined uVar11;
    uint32_t uVar12;
    uint32_t uVar13;
    int32_t iVar14;
    undefined4 uVar15;
    uint32_t uVar16;
    uint64_t uVar17;
    int64_t iVar18;
    int64_t iVar19;
    int64_t iVar20;
    int64_t *piVar21;
    int32_t *piVar22;
    undefined8 uVar23;
    uint32_t uVar24;
    int64_t iVar25;
    int64_t *piVar26;
    uint64_t uVar27;
    uint64_t uVar28;
    undefined8 *puVar29;
    undefined *puVar30;
    undefined *puVar31;
    undefined *puVar32;
    undefined *puVar33;
    int64_t *unaff_RSI;
    uint8_t in_R8B;
    int32_t iVar34;
    uint8_t in_R9B;
    uint64_t uVar35;
    uint64_t uVar36;
    undefined8 uVar37;
    int64_t *piVar38;
    int64_t *piVar39;
    uint32_t uVar40;
    int64_t *piVar41;
    int64_t iVar42;
    int64_t in_stack_00000020;
    int64_t in_stack_00000030;
    undefined8 uStack_150;
    undefined auStack_148 [8];
    undefined auStack_140 [24];
    int64_t var_128h;
    int64_t var_120h;
    uint8_t var_118h;
    int64_t var_117h;
    undefined4 uStack_10c;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t in_stack_ffffffffffffff10;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    puVar31 = auStack_148;
    puVar33 = auStack_148;
    puVar30 = auStack_148;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_148;
    var_118h = in_R8B;
    var_117h._0_1_ = in_R9B;
code_r0x0001800b4d17:
    if (0 < *(int32_t *)(arg1 + 0xc)) {
        *(int32_t *)(*(int64_t *)arg1 + 0x270) = *(int32_t *)(arg2 + 0xc) + 1;
    }
    if (((1 < *(int32_t *)(arg1 + 0x14)) && (*(int32_t *)(arg2 + 8) != *(int32_t *)0x180782718)) &&
       (*(int32_t *)(arg2 + 8) != *(int32_t *)0x18078266c)) {
        stack0xfffffffffffffef0 = 0x45;
        fcn.1800d31a0(*(int64_t *)arg1 + 0x28, (int64_t)&var_117h + 7);
        fcn.1800d31a0();
    }
    piVar38 = (int64_t *)(arg1 + 0x100);
    if ((*(int64_t *)(arg1 + 0x110) != 0) && ((int64_t *)arg2 != *(int64_t **)(arg1 + 0x118))) {
        uVar35 = *(int64_t *)(arg1 + 0x108) - 1;
        uVar17 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar27 = 0;
        do {
            uVar17 = uVar17 & uVar35;
            iVar25 = uVar17 * 0x20;
            piVar21 = *(int64_t **)(iVar25 + *piVar38);
            if (piVar21 == (int64_t *)arg2) {
                piVar22 = (int32_t *)(*piVar38 + 8 + iVar25);
                if ((piVar22 != (int32_t *)0x0) && (*piVar22 != 0)) {
                    fcn.1800b4ae0(arg1, arg2, (int64_t)piVar22);
                    puVar32 = auStack_148;
                    goto code_r0x0001800b6d8e;
                }
                break;
            }
            if (piVar21 == *(int64_t **)(arg1 + 0x118)) break;
            uVar17 = uVar17 + 1 + uVar27;
            uVar27 = uVar27 + 1;
        } while (uVar27 <= uVar35);
    }
    iVar14 = *(int32_t *)(arg2 + 8);
    piVar21 = (int64_t *)0x0;
    if (iVar14 == *(int32_t *)0x1807826c0) {
        piVar21 = (int64_t *)arg2;
    }
    if (piVar21 != (int64_t *)0x0) goto code_r0x0001800b4dff;
    if (iVar14 == *(int32_t *)0x180782670) {
        uVar12 = (uint32_t)var_118h << 8 | 2;
code_r0x0001800b6d6b:
        var_90h._0_4_ = uVar12;
        goto code_r0x0001800b6d6e;
    }
    piVar21 = (int64_t *)0x0;
    if (iVar14 == *(int32_t *)0x1807826cc) {
        piVar21 = (int64_t *)arg2;
    }
    if (piVar21 != (int64_t *)0x0) {
        var_128h = (uint64_t)var_128h._1_7_ << 8;
        func_0x0001800cfdd0(*(undefined8 *)arg1, 3, var_118h, *(undefined *)(piVar21 + 4));
        puVar32 = auStack_148;
        goto code_r0x0001800b6d8e;
    }
    piVar21 = (int64_t *)0x0;
    if (iVar14 == *(int32_t *)0x1807826b4) {
        piVar21 = (int64_t *)arg2;
    }
    if (piVar21 != (int64_t *)0x0) {
        uVar12 = func_0x0001800cf660(*(undefined8 *)arg1, piVar21[4]);
        if ((int32_t)uVar12 < 0) {
            fcn.1800acea0((int64_t)piVar21 + 0xc, 0x18063f5a0);
            goto code_r0x0001800b6de1;
        }
code_r0x0001800b6d02:
        fcn.1800ad460(arg1, (uint64_t)var_118h, (uint64_t)uVar12);
        puVar32 = auStack_148;
        goto code_r0x0001800b6d8e;
    }
    piVar21 = (int64_t *)0x0;
    if (iVar14 == *(int32_t *)0x18078271c) {
        piVar21 = (int64_t *)arg2;
    }
    if (piVar21 != (int64_t *)0x0) {
        uVar12 = func_0x0001800cf6b0(*(undefined8 *)arg1, piVar21[4]);
        if ((int32_t)uVar12 < 0) {
            fcn.1800acea0((int64_t)piVar21 + 0xc, 0x18063f5a0);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        goto code_r0x0001800b6d02;
    }
    piVar21 = (int64_t *)0x0;
    if (iVar14 == *(int32_t *)0x18078273c) {
        piVar21 = (int64_t *)arg2;
    }
    if (piVar21 != (int64_t *)0x0) {
        uVar37 = *(undefined8 *)arg1;
        var_108h = piVar21[4];
        var_100h = piVar21[5];
        var_e0h._0_4_ = func_0x0001800cf010(uVar37, &var_108h);
        var_a8h._0_4_ = 5;
        stack0xffffffffffffff64 = SUB1612(ZEXT816(0), 4);
        var_a0h._0_4_ = (uint32_t)var_e0h;
        var_e8h._0_4_ = 5;
        var_e0h._4_4_ = 0;
        var_d8h = 0;
        uVar12 = func_0x0001800ced20(uVar37, &var_e8h, &var_a8h);
        if ((int32_t)uVar12 < 0) {
            fcn.1800acea0((int64_t)piVar21 + 0xc, 0x18063f5a0);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        goto code_r0x0001800b6d02;
    }
    piVar21 = (int64_t *)0x0;
    if (iVar14 == *(int32_t *)0x180782728) {
        piVar21 = (int64_t *)arg2;
    }
    if (piVar21 != (int64_t *)0x0) {
        if ((*(char *)0x180778520 != '\0') &&
           (piVar38 = (int64_t *)piVar21[4], *(char *)((int64_t)piVar38 + 0x31) != '\0')) {
            iVar25 = func_0x0001800ac7f0(arg1 + 0x6e8);
            if (iVar25 == 0) {
                iVar25 = *piVar38;
                uVar17 = func_0x000180498cd0(iVar25);
                uVar37 = *(undefined8 *)arg1;
                var_100h = uVar17;
                var_108h = iVar25;
                var_e0h._0_4_ = func_0x0001800cf010(uVar37, &var_108h);
                var_a8h._0_4_ = 5;
                stack0xffffffffffffff64 = SUB1612(ZEXT816(0), 4);
                var_a0h._0_4_ = (uint32_t)var_e0h;
                var_e8h._0_4_ = 5;
                var_e0h._4_4_ = 0;
                var_d8h = 0;
                iVar14 = func_0x0001800ced20(uVar37, &var_e8h, &var_a8h);
                if (iVar14 < 0) {
                    fcn.1800acea0((int64_t)piVar21 + 0xc, 0x18063f5a0);
                    pcVar3 = (code *)swi(3);
                    (*pcVar3)();
                    return;
                }
                uVar12 = fcn.1800acf70(arg1, arg1 + 0x5c0);
                if ((int32_t)uVar12 < 0) {
                    uVar11 = fcn.1800ad020(arg1, arg1 + 0x5c0);
                    var_128h = var_128h & 0xffffffffffffff00;
                    func_0x0001800cfdd0(*(undefined8 *)arg1, 9, var_118h, uVar11);
                    uVar37 = *(undefined8 *)arg1;
                    uVar27 = uVar17;
                    for (; uVar17 != 0; uVar17 = uVar17 - 1) {
                        uVar27 = (uint64_t)
                                 ((uint32_t)uVar27 ^
                                 (uint32_t)*(uint8_t *)((uVar17 - 1) + iVar25) + (uint32_t)uVar27 * 0x20 +
                                 ((uint32_t)(uVar27 >> 2) & 0x3fffffff));
                    }
                    uVar11 = (undefined)uVar27;
                    uVar12 = (uint32_t)var_118h;
                } else {
                    uVar37 = *(undefined8 *)arg1;
                    uVar27 = uVar17;
                    for (; uVar17 != 0; uVar17 = uVar17 - 1) {
                        uVar27 = (uint64_t)
                                 ((uint32_t)uVar27 ^
                                 (uint32_t)*(uint8_t *)(iVar25 + -1 + uVar17) + (uint32_t)uVar27 * 0x20 +
                                 ((uint32_t)(uVar27 >> 2) & 0x3fffffff));
                    }
                    uVar11 = (undefined)uVar27;
                }
                var_128h = CONCAT71(var_128h._1_7_, uVar11);
                func_0x0001800cfdd0(uVar37, 0xf, var_118h, uVar12);
                func_0x0001800cfe80(*(undefined8 *)arg1, iVar14);
                puVar32 = auStack_148;
                goto code_r0x0001800b6d8e;
            }
        }
        uVar12 = func_0x0001800b7be0(arg1, piVar21);
        if ((int32_t)uVar12 < 0) {
            uVar11 = fcn.1800ad020(arg1, piVar21[4]);
            var_128h = var_128h & 0xffffffffffffff00;
            func_0x0001800cfdd0(*(undefined8 *)arg1, 9, var_118h, uVar11);
            puVar32 = auStack_148;
        } else if ((*(int32_t *)(arg1 + 8) == 0) || (puVar32 = auStack_148, var_118h != uVar12)) {
            var_128h = var_128h & 0xffffffffffffff00;
            func_0x0001800cfdd0(*(undefined8 *)arg1, 6, var_118h, uVar12 & 0xff);
            puVar32 = auStack_148;
        }
        goto code_r0x0001800b6d8e;
    }
    piVar21 = (int64_t *)0x0;
    if (iVar14 == *(int32_t *)0x180782738) {
        piVar21 = (int64_t *)arg2;
    }
    if (piVar21 != (int64_t *)0x0) {
        if (0 < *(int32_t *)(arg1 + 8)) {
            iVar25 = piVar21[4];
            iVar14 = func_0x0001800aa2c0(arg1 + 0xb0);
            if (iVar14 != 2) {
                uVar37 = *(undefined8 *)arg1;
                var_100h = func_0x000180498cd0(iVar25);
                var_108h = iVar25;
                var_e0h._0_4_ = func_0x0001800cf010(uVar37, &var_108h);
                var_a8h._0_4_ = 5;
                stack0xffffffffffffff64 = SUB1612(ZEXT816(0), 4);
                var_a0h._0_4_ = (uint32_t)var_e0h;
                var_e8h._0_4_ = 5;
                var_e0h._4_4_ = 0;
                var_d8h = 0;
                uVar12 = func_0x0001800ced20(uVar37, &var_e8h, &var_a8h);
                if ((int32_t)uVar12 < 0) goto code_r0x0001800b6f73;
                if ((int32_t)uVar12 < 0x400) {
                    iVar14 = (uVar12 | 0x400) << 0x14;
                    uVar12 = func_0x0001800cf7f0(*(undefined8 *)arg1, iVar14);
                    if (uVar12 < 0x8000) {
                        func_0x0001800cfe30(*(undefined8 *)arg1, 0xc, var_118h, uVar12 & 0xffff);
                        func_0x0001800cfe80(*(undefined8 *)arg1, iVar14);
                        puVar32 = auStack_148;
                        goto code_r0x0001800b6d8e;
                    }
                }
            }
        }
        iVar25 = piVar21[4];
        uVar17 = func_0x000180498cd0(iVar25);
        uVar37 = *(undefined8 *)arg1;
        var_100h = uVar17;
        var_108h = iVar25;
        var_e0h._0_4_ = func_0x0001800cf010(uVar37, &var_108h);
        var_a8h._0_4_ = 5;
        stack0xffffffffffffff64 = SUB1612(ZEXT816(0), 4);
        var_a0h._0_4_ = (uint32_t)var_e0h;
        var_e8h._0_4_ = 5;
        var_e0h._4_4_ = 0;
        var_d8h = 0;
        iVar14 = func_0x0001800ced20(uVar37, &var_e8h, &var_a8h);
        if (iVar14 < 0) goto code_r0x0001800b6f73;
        iVar42 = *(int64_t *)arg1;
        uVar27 = uVar17;
        for (; uVar12 = (uint32_t)uVar27, uVar17 != 0; uVar17 = uVar17 - 1) {
            uVar27 = (uint64_t)
                     (uVar12 ^ (uint32_t)*(uint8_t *)(iVar25 + -1 + uVar17) + uVar12 * 0x20 +
                               ((uint32_t)(uVar27 >> 2) & 0x3fffffff));
        }
        var_90h._0_4_ = ((uVar12 & 0xff) << 0x10 | (uint32_t)var_118h) << 8 | 7;
        fcn.1800d31a0(iVar42 + 0x28, &var_90h);
        fcn.1800d31a0(iVar42 + 0x40, iVar42 + 0x270);
        var_90h._0_4_ = iVar14;
code_r0x0001800b6d6e:
        arg1 = *(int64_t *)arg1;
        fcn.1800d31a0(arg1 + 0x28, &var_90h);
        fcn.1800d31a0(arg1 + 0x40, arg1 + 0x270);
        puVar32 = auStack_148;
        goto code_r0x0001800b6d8e;
    }
    piVar26 = (int64_t *)0x0;
    if (iVar14 == *(int32_t *)0x1807826b8) {
        piVar26 = (int64_t *)arg2;
    }
    if (piVar26 != (int64_t *)0x0) {
        if (0 < *(int32_t *)(arg1 + 0xc)) {
            *(int32_t *)(*(int64_t *)arg1 + 0x270) = *(int32_t *)((int64_t)piVar26 + 0xc) + 1;
        }
        uVar12 = (uint32_t)var_118h << 8 | 0x2003f;
        goto code_r0x0001800b6d6b;
    }
    piVar26 = (int64_t *)0x0;
    if (iVar14 == *(int32_t *)0x180782740) {
        piVar26 = (int64_t *)arg2;
    }
    if (piVar26 != (int64_t *)0x0) {
        if (((uint8_t)var_117h == 0) || ((uint32_t)var_118h != *(int32_t *)(arg1 + 0x60c) - 1U)) {
            uVar11 = 0;
        } else {
            uVar11 = 1;
        }
        var_120h._0_1_ = 0;
        var_128h = CONCAT71(var_128h._1_7_, uVar11);
        fcn.1800b0700(arg1, (int64_t)piVar26, (uint64_t)var_118h, 1, var_128h, (uint64_t)var_120h._1_7_ << 8, 
                      CONCAT44(var_e8h._4_4_, (undefined4)var_e8h));
        puVar32 = auStack_148;
        goto code_r0x0001800b6d8e;
    }
    if (iVar14 == *(int32_t *)0x18078269c) {
        piVar21 = (int64_t *)arg2;
    }
    if (piVar21 == (int64_t *)0x0) {
        piVar26 = (int64_t *)0x0;
        if (iVar14 == *(int32_t *)0x180782730) {
            piVar26 = (int64_t *)arg2;
        }
        if (piVar26 != (int64_t *)0x0) {
            uVar12 = *(uint32_t *)(arg1 + 0x60c);
            var_e0h._0_4_ = uVar12;
            var_e8h = arg1;
            fcn.1800b29d0(arg1, (int64_t)&var_108h, piVar26[5]);
            iVar25 = var_100h;
            if ((int32_t)var_108h == 3) {
                if (((1.0 <= (double)var_100h) && ((double)var_100h <= 256.0)) &&
                   (iVar14 = (int32_t)(double)var_100h, (double)iVar14 == (double)var_100h)) {
                    uVar10 = func_0x0001800b7030(arg1, piVar26[4]);
                    if (0 < *(int32_t *)(arg1 + 0xc)) {
                        *(int32_t *)(*(int64_t *)arg1 + 0x270) = *(int32_t *)(piVar26[5] + 0xc) + 1;
                    }
                    var_128h = CONCAT71(var_128h._1_7_, (char)iVar14 + -1);
                    func_0x0001800cfdd0(*(undefined8 *)arg1, 0x11, var_118h, uVar10);
                    uVar40 = (uint32_t)uVar10;
                    var_128h = CONCAT44(var_128h._4_4_, 1);
                    uVar37 = 4;
                    iVar25 = piVar26[4];
                    goto code_r0x0001800b645b;
                }
            } else if ((int32_t)var_108h == 6) {
                uVar13 = var_108h._4_4_;
                uVar17 = (uint64_t)var_108h._4_4_;
                uVar37 = *(undefined8 *)arg1;
                var_108h = var_100h;
                var_100h = uVar17;
                var_a0h._0_4_ = func_0x0001800cf010(uVar37, &var_108h);
                var_a8h._0_4_ = 5;
                stack0xffffffffffffff64 = SUB1612(ZEXT816(0), 4);
                var_108h = CONCAT44(var_108h._4_4_, 5);
                _var_100h = ZEXT416((uint32_t)var_a0h);
                *(uint32_t *)0x0 = func_0x0001800ced20(uVar37, &var_108h, &var_a8h);
                if ((int32_t)*(uint32_t *)0x0 < 0) goto code_r0x0001800b6ecc;
                iVar42 = piVar26[4];
                uVar40 = func_0x0001800b7be0(arg1, iVar42);
                if ((int32_t)uVar40 < 0) {
                    uVar40 = *(uint32_t *)(arg1 + 0x60c);
                    uVar24 = uVar40 + 1;
                    if (0xff < uVar24) {
                        fcn.1800acea0(iVar42 + 0xc, 0x18063fbc0, 1, 0xff);
                        pcVar3 = (code *)swi(3);
                        (*pcVar3)();
                        return;
                    }
                    *(uint32_t *)(arg1 + 0x60c) = uVar24;
                    uVar16 = *(uint32_t *)(arg1 + 0x610);
                    if (*(uint32_t *)(arg1 + 0x610) < uVar24) {
                        uVar16 = uVar24;
                    }
                    *(uint32_t *)(arg1 + 0x610) = uVar16;
                    fcn.1800b4ce0(arg1, iVar42);
                }
                if (0 < *(int32_t *)(arg1 + 0xc)) {
                    *(int32_t *)(*(int64_t *)arg1 + 0x270) = *(int32_t *)(piVar26[5] + 0xc) + 1;
                }
                iVar42 = *(int64_t *)arg1;
                uVar27 = uVar17;
                for (; uVar17 != 0; uVar17 = uVar17 - 1) {
                    uVar13 = (uint32_t)uVar27 ^
                             (uint32_t)*(uint8_t *)((uVar17 - 1) + iVar25) + (uint32_t)uVar27 * 0x20 +
                             (int32_t)(uVar27 >> 2);
                    uVar27 = (uint64_t)uVar13;
                }
                uVar40 = uVar40 & 0xff;
                var_c8h = CONCAT44(var_c8h._4_4_, (((uVar13 & 0xff) << 8 | uVar40) << 8 | (uint32_t)var_118h) << 8) |
                          0xf;
                fcn.1800d31a0(iVar42 + 0x28, &var_c8h);
                fcn.1800d31a0(iVar42 + 0x40, iVar42 + 0x270);
                iVar25 = *(int64_t *)arg1;
                var_c8h = CONCAT44(var_c8h._4_4_, stack0xfffffffffffffef0);
                fcn.1800d31a0(iVar25 + 0x28, &var_c8h);
                fcn.1800d31a0(iVar25 + 0x40, iVar25 + 0x270);
                var_128h = CONCAT44(var_128h._4_4_, 2);
                uVar37 = 4;
                iVar25 = piVar26[4];
code_r0x0001800b645b:
                func_0x0001800bbfb0(arg1, iVar25, uVar40, uVar37);
                *(uint32_t *)(arg1 + 0x60c) = uVar12;
                puVar32 = auStack_148;
                goto code_r0x0001800b6d8e;
            }
            iVar25 = piVar26[4];
            uVar13 = func_0x0001800b7be0(arg1, iVar25);
            if ((int32_t)uVar13 < 0) {
                uVar13 = uVar12 + 1;
                if (0xff < uVar13) {
                    fcn.1800acea0(iVar25 + 0xc, 0x18063fbc0, 1, 0xff);
                    pcVar3 = (code *)swi(3);
                    (*pcVar3)();
                    return;
                }
                *(uint32_t *)(arg1 + 0x60c) = uVar13;
                uVar40 = *(uint32_t *)(arg1 + 0x610);
                if (*(uint32_t *)(arg1 + 0x610) < uVar13) {
                    uVar40 = uVar13;
                }
                *(uint32_t *)(arg1 + 0x610) = uVar40;
                fcn.1800b4ce0(arg1, iVar25);
                uVar13 = uVar12 & 0xff;
            }
            iVar25 = piVar26[5];
            uVar40 = func_0x0001800b7be0(arg1, iVar25);
            if ((int32_t)uVar40 < 0) {
                uVar40 = *(uint32_t *)(arg1 + 0x60c);
                uVar24 = uVar40 + 1;
                if (0xff < uVar24) {
                    fcn.1800acea0(iVar25 + 0xc, 0x18063fbc0, 1, 0xff);
                    goto code_r0x0001800b6f34;
                }
                *(uint32_t *)(arg1 + 0x60c) = uVar24;
                uVar16 = *(uint32_t *)(arg1 + 0x610);
                if (*(uint32_t *)(arg1 + 0x610) < uVar24) {
                    uVar16 = uVar24;
                }
                *(uint32_t *)(arg1 + 0x610) = uVar16;
                fcn.1800b4ce0(arg1, iVar25);
            }
            iVar25 = *(int64_t *)arg1;
            uVar40 = uVar40 & 0xff;
            var_c8h = CONCAT44(var_c8h._4_4_, ((uVar40 << 8 | uVar13 & 0xff) << 8 | (uint32_t)var_118h) << 8) | 0xd;
            fcn.1800d31a0(iVar25 + 0x28, &var_c8h);
            fcn.1800d31a0(iVar25 + 0x40, iVar25 + 0x270);
            var_128h = CONCAT44(var_128h._4_4_, 1);
            func_0x0001800bbfb0(arg1, piVar26[4], uVar13 & 0xff, 4);
            var_128h = CONCAT44(var_128h._4_4_, 1);
            uVar37 = 2;
            iVar25 = piVar26[5];
            goto code_r0x0001800b645b;
        }
        piVar21 = (int64_t *)0x0;
        if (iVar14 == *(int32_t *)0x1807826a0) {
            piVar21 = (int64_t *)arg2;
        }
        if (piVar21 != (int64_t *)0x0) {
            fcn.1800b2270(arg1, (int64_t)piVar21, (uint64_t)var_118h, 0);
            puVar32 = auStack_148;
            goto code_r0x0001800b6d8e;
        }
        piVar21 = (int64_t *)0x0;
        if (iVar14 == *(int32_t *)0x180782758) {
            piVar21 = (int64_t *)arg2;
        }
        if (piVar21 != (int64_t *)0x0) {
            fcn.1800b3b60(arg1, (int64_t)piVar21, CONCAT71(var_120h._1_7_, (undefined)var_120h), 
                          CONCAT53(var_117h._2_5_, CONCAT12(var_117h._1_1_, CONCAT11((uint8_t)var_117h, var_118h))), 
                          CONCAT44(uStack_10c, stack0xfffffffffffffef0), var_108h, var_100h, var_f8h, 
                          in_stack_ffffffffffffff10, CONCAT44(var_e0h._4_4_, (uint32_t)var_e0h), in_stack_00000020, 
                          in_stack_00000030);
            puVar32 = auStack_148;
            goto code_r0x0001800b6d8e;
        }
        piVar21 = (int64_t *)0x0;
        if (iVar14 == *(int32_t *)0x180782768) {
            piVar21 = (int64_t *)arg2;
        }
        if (piVar21 != (int64_t *)0x0) goto code_r0x0001800b5f86;
        piVar41 = (int64_t *)0x0;
        if (iVar14 == *(int32_t *)0x180782668) {
            piVar41 = (int64_t *)arg2;
        }
        puVar32 = auStack_148;
        if (piVar41 != (int64_t *)0x0) goto code_r0x0001800b57da;
        piVar21 = (int64_t *)0x0;
        if (iVar14 == *(int32_t *)0x180782708) {
            piVar21 = (int64_t *)arg2;
        }
        if (piVar21 == (int64_t *)0x0) {
            unaff_RSI = (int64_t *)0x0;
            if (iVar14 == *(int32_t *)0x18078270c) {
                unaff_RSI = (int64_t *)arg2;
            }
            if (unaff_RSI == (int64_t *)0x0) {
                if (iVar14 == *(int32_t *)0x18078275c) {
                    unaff_RSI = (int64_t *)arg2;
                }
                if (unaff_RSI != (int64_t *)0x0) {
                    iVar25 = 0;
                    piVar21 = (int64_t *)unaff_RSI[4];
                    piVar26 = piVar21 + unaff_RSI[5] * 2;
                    for (; piVar21 != piVar26; piVar21 = piVar21 + 2) {
                        iVar42 = piVar21[1];
                        iVar19 = func_0x000180457f30(*piVar21, iVar42 + *piVar21, 0x25);
                        iVar25 = iVar25 + iVar42 + iVar19;
                    }
                    iVar42 = 0;
                    auVar6._8_8_ = 0;
                    auVar6._0_8_ = var_88h;
                    _var_90h = auVar6 << 0x40;
                    uVar17 = 0;
                    if (unaff_RSI[7] != 0) {
                        do {
                            iVar19 = func_0x0001800c13d0(piVar38, unaff_RSI[6] + uVar17 * 8);
                            if (((iVar19 == 0) || ((int32_t *)(iVar19 + 8) == (int32_t *)0x0)) ||
                               (*(int32_t *)(iVar19 + 8) != 6)) {
                                iVar25 = iVar25 + 2;
                            } else {
                                iVar20 = func_0x000180457f30(*(int64_t *)(iVar19 + 0x10), 
                                                             (uint64_t)*(uint32_t *)(iVar19 + 0xc) +
                                                             *(int64_t *)(iVar19 + 0x10), 0x25);
                                iVar25 = iVar25 + (uint64_t)*(uint32_t *)(iVar19 + 0xc) + iVar20;
                                iVar42 = iVar42 + 1;
                            }
                            uVar17 = uVar17 + 1;
                        } while (uVar17 < (uint64_t)unaff_RSI[7]);
                        var_90h = iVar42;
                    }
                    uVar17 = 0;
                    var_68h = 0;
                    var_60h = 0xf;
                    stack0xffffffffffffff89 = SUB1615(ZEXT816(0), 1);
                    auVar5[15] = 0;
                    auVar5._0_15_ = stack0xffffffffffffff89;
                    _var_78h = auVar5 << 8;
                    func_0x00018000b240(&var_78h, iVar25);
                    if (unaff_RSI[5] != 0) {
                        do {
                            func_0x0001800acc60(&var_78h, *(undefined8 *)(unaff_RSI[4] + uVar17 * 0x10), 
                                                *(undefined8 *)(unaff_RSI[4] + 8 + uVar17 * 0x10));
                            if (uVar17 < (uint64_t)unaff_RSI[7]) {
                                iVar19 = func_0x0001800c13d0(arg1 + 0x100, unaff_RSI[6] + uVar17 * 8);
                                iVar25 = var_68h;
                                if (((iVar19 == 0) || ((int32_t *)(iVar19 + 8) == (int32_t *)0x0)) ||
                                   (*(int32_t *)(iVar19 + 8) != 6)) {
                                    if ((uint64_t)(var_60h - var_68h) < 2) {
                                        var_128h = 2;
                                        func_0x00018000ee80(&var_78h, 2, var_117h._1_1_, 0x18063fa54);
                                    } else {
                                        piVar38 = &var_78h;
                                        if (0xf < (uint64_t)var_60h) {
                                            piVar38 = (int64_t *)var_78h;
                                        }
                                        puVar1 = (undefined2 *)((int64_t)piVar38 + var_68h);
                                        var_68h = var_68h + 2;
                                        *puVar1 = 0x2a25;
                                        *(undefined *)((int64_t)piVar38 + iVar25 + 2) = 0;
                                    }
                                } else {
                                    func_0x0001800acc60(&var_78h, *(undefined8 *)(iVar19 + 0x10), 
                                                        *(undefined4 *)(iVar19 + 0xc));
                                }
                            }
                            uVar17 = uVar17 + 1;
                        } while (uVar17 < (uint64_t)unaff_RSI[5]);
                    }
                    iVar25 = var_68h;
                    if (var_68h == 0) {
                        uVar37 = *(undefined8 *)arg1;
                        var_c8h = 0x1805aadb1;
                        var_c0h = 0;
                        var_e0h._0_4_ = func_0x0001800cf010(uVar37);
                    } else {
                        iVar19 = *(int64_t *)(arg1 + 0x5b8);
                        piVar38 = &var_78h;
                        if (0xf < (uint64_t)var_60h) {
                            piVar38 = (int64_t *)var_78h;
                        }
                        var_c0h = var_68h & 0xffffffff;
                        var_c8h = (int64_t)piVar38;
                        piVar21 = (int64_t *)func_0x0001800d8c20(iVar19, &var_c8h);
                        if (*(int32_t *)((int64_t)piVar21 + 0xc) == 0) {
                            iVar19 = func_0x0001800d4d20(*(undefined8 *)(iVar19 + 0x30), iVar25 + 1);
                            fcn.180498030(iVar19, piVar38, iVar25);
                            *(undefined *)(iVar25 + iVar19) = 0;
                            *piVar21 = iVar19;
                            uVar15 = 0x119;
                            if (*(char *)piVar38 == '@') {
                                uVar15 = 0x11c;
                            }
                            *(undefined4 *)((int64_t)piVar21 + 0xc) = uVar15;
                        } else {
                            iVar19 = *piVar21;
                        }
                        uVar37 = *(undefined8 *)arg1;
                        var_c0h = var_68h;
                        var_c8h = iVar19;
                        var_e0h._0_4_ = func_0x0001800cf010(uVar37, &var_c8h);
                    }
                    var_e0h._4_4_ = 0;
                    var_d8h = 0;
                    var_e8h._0_4_ = 5;
                    var_108h = CONCAT44(var_108h._4_4_, 5);
                    _var_100h = ZEXT416((uint32_t)var_e0h);
                    uVar12 = func_0x0001800ced20(uVar37, &var_108h, &var_e8h);
                    if ((int32_t)uVar12 < 0) goto code_r0x0001800b6df2;
                    var_e0h._0_4_ = *(uint32_t *)(arg1 + 0x60c);
                    var_c8h = CONCAT44(var_c8h._4_4_, (uint32_t)var_e0h);
                    iVar14 = *(int32_t *)(unaff_RSI + 7) - (int32_t)iVar42;
                    iVar34 = iVar14 + 2;
                    if (((*(char *)0x180777f38 == '\0') || ((uint8_t)var_117h == 0)) ||
                       ((uint32_t)var_118h != (uint32_t)var_e0h - 1)) {
                        uVar13 = (uint32_t)var_e0h + iVar34;
                        if (0xff < uVar13) {
                            var_e8h = arg1;
                            fcn.1800acea0((int64_t)unaff_RSI + 0xc, 0x18063fbc0, iVar34, 0xff);
                            pcVar3 = (code *)swi(3);
                            (*pcVar3)();
                            return;
                        }
                        uVar40 = (uint32_t)var_e0h & 0xff;
                    } else {
                        uVar13 = (uint32_t)var_e0h + iVar14 + 1;
                        if (0xff < uVar13) goto code_r0x0001800b6e03;
                        uVar40 = (uint32_t)var_e0h - 1;
                    }
                    piVar38 = (int64_t *)(uint64_t)var_118h;
                    *(uint32_t *)(arg1 + 0x60c) = uVar13;
                    uVar24 = *(uint32_t *)(arg1 + 0x610);
                    if (*(uint32_t *)(arg1 + 0x610) < uVar13) {
                        uVar24 = uVar13;
                    }
                    *(uint32_t *)(arg1 + 0x610) = uVar24;
                    var_117h._0_1_ = (uint8_t)uVar40;
                    var_e8h = arg1;
                    fcn.1800ad460(arg1, (uint64_t)(uVar40 & 0xff), (uint64_t)uVar12);
                    cVar7 = '\0';
                    uVar17 = 0;
                    if (unaff_RSI[7] != 0) {
                        do {
                            uVar27 = *(uint64_t *)(unaff_RSI[6] + uVar17 * 8);
                            if ((*(int64_t *)(arg1 + 0x110) != 0) && (uVar27 != *(uint64_t *)(arg1 + 0x118))) {
                                uVar36 = *(int64_t *)(arg1 + 0x108) - 1;
                                uVar35 = (uVar27 >> 5 ^ uVar27) >> 4;
                                uVar28 = 0;
                                do {
                                    uVar35 = uVar35 & uVar36;
                                    iVar25 = uVar35 * 0x20;
                                    uVar2 = *(uint64_t *)(iVar25 + *(int64_t *)(arg1 + 0x100));
                                    if (uVar2 == uVar27) {
                                        piVar22 = (int32_t *)(*(int64_t *)(arg1 + 0x100) + 8 + iVar25);
                                        if ((piVar22 != (int32_t *)0x0) && (*piVar22 == 6)) {
                                            cVar7 = cVar7 + '\x01';
                                            goto code_r0x0001800b560d;
                                        }
                                        break;
                                    }
                                    if (uVar2 == *(uint64_t *)(arg1 + 0x118)) break;
                                    uVar35 = uVar35 + 1 + uVar28;
                                    uVar28 = uVar28 + 1;
                                } while (uVar28 <= uVar36);
                            }
                            uVar15 = *(undefined4 *)(arg1 + 0x60c);
                            var_100h._0_4_ = uVar15;
                            *(uint32_t *)(arg1 + 0x60c) =
                                 (uint8_t)(((char)uVar17 - cVar7) + '\x02' + (uint8_t)uVar40) + 1;
                            var_108h = arg1;
                            fcn.1800b4ce0(arg1, uVar27);
                            *(undefined4 *)(arg1 + 0x60c) = uVar15;
code_r0x0001800b560d:
                            uVar17 = uVar17 + 1;
                        } while (uVar17 < (uint64_t)unaff_RSI[7]);
                    }
                    uVar37 = *(undefined8 *)arg1;
                    iVar25 = 0x18063c3cc;
                    var_108h = 0x18063c3cc;
                    uVar17 = 6;
                    var_100h = 6;
                    var_100h._0_4_ = func_0x0001800cf010(uVar37, &var_108h);
                    var_108h = CONCAT44(var_108h._4_4_, 5);
                    stack0xffffffffffffff04 = SUB1612(ZEXT816(0), 4);
                    var_a8h._0_4_ = 5;
                    _var_a0h = ZEXT416((uint32_t)var_100h);
                    uVar12 = func_0x0001800ced20(uVar37, &var_a8h, &var_108h);
                    uVar10 = (uint8_t)var_117h;
                    piVar41 = (int64_t *)(uint64_t)uVar12;
                    if (-1 < (int32_t)uVar12) {
                        iVar25 = *(int64_t *)arg1;
                        iVar42 = 6;
                        do {
                            uVar13 = (uint32_t)uVar17 ^
                                     (uint32_t)*(uint8_t *)(iVar42 + 0x18063c3cb) + (uint32_t)uVar17 * 0x20 +
                                     (int32_t)(uVar17 >> 2);
                            uVar17 = (uint64_t)uVar13;
                            iVar42 = iVar42 + -1;
                        } while (iVar42 != 0);
                        *(uint32_t *)0x0 =
                             (((uVar13 & 0xff) << 8 | (uint32_t)(uint8_t)var_117h) << 8 | (uint32_t)(uint8_t)var_117h)
                             << 8 | 0x14;
                        fcn.1800d31a0(iVar25 + 0x28, (int64_t)&var_117h + 7);
                        fcn.1800d31a0(iVar25 + 0x40, iVar25 + 0x270);
                        iVar25 = *(int64_t *)arg1;
                        unique0x10002605 = uVar12;
                        fcn.1800d31a0(iVar25 + 0x28, (int64_t)&var_117h + 7);
                        fcn.1800d31a0(iVar25 + 0x40, iVar25 + 0x270);
                        iVar25 = *(int64_t *)arg1;
                        *(uint32_t *)0x8 =
                             (uint32_t)CONCAT11((*(char *)(unaff_RSI + 7) - (char)var_90h) + '\x02', uVar10) << 8 |
                             0x2000015;
                        fcn.1800d31a0(iVar25 + 0x28, (int64_t)&var_117h + 7);
                        fcn.1800d31a0(iVar25 + 0x40, iVar25 + 0x270);
                        if (var_118h != (uint8_t)var_117h) {
                            iVar25 = *(int64_t *)arg1;
                            *(uint32_t *)0xb0 = (uint32_t)CONCAT11(uVar10, var_118h) << 8 | 6;
                            fcn.1800d31a0(iVar25 + 0x28, (int64_t)&var_117h + 7);
                            fcn.1800d31a0(iVar25 + 0x40, iVar25 + 0x270);
                        }
                        *(undefined4 *)(arg1 + 0x60c) = (undefined4)var_c8h;
                        puVar32 = auStack_148;
                        if ((uint64_t)var_60h < 0x10) goto code_r0x0001800b6d8e;
                        uVar17 = var_60h + 1;
                        iVar25 = var_78h;
                        goto code_r0x0001800b51ba;
                    }
                    fcn.1800acea0((int64_t)unaff_RSI + 0xc, 0x18063f5a0);
                    goto code_r0x0001800b6e42;
                }
                piVar38 = (int64_t *)0x0;
                if (iVar14 == *(int32_t *)0x180782674) {
                    piVar38 = (int64_t *)arg2;
                }
                puVar32 = auStack_148;
                if (piVar38 == (int64_t *)0x0) goto code_r0x0001800b6d8e;
                arg2 = piVar38[4];
            } else {
                iVar25 = unaff_RSI[4];
                cVar7 = fcn.1800b2930(arg1, iVar25);
                if (cVar7 == '\0') {
                    uVar12 = func_0x0001800b7be0(arg1);
                    if (-1 < (int32_t)uVar12) {
                        iVar42 = unaff_RSI[6];
                        uVar13 = func_0x0001800b7be0(arg1, iVar42);
                        if (uVar12 == uVar13) {
                            iVar19 = unaff_RSI[8];
                            iVar14 = func_0x0001800b7be0(arg1);
                            if ((-1 < iVar14) || (cVar7 = fcn.1800b2930(arg1, iVar19), cVar7 != '\0')) {
                                var_128h = CONCAT71(var_128h._1_7_, var_118h);
                                fcn.1800b3a10(arg1, 0, (uint64_t)(uVar12 & 0xff), iVar19, var_128h);
                                puVar32 = auStack_148;
                                goto code_r0x0001800b6d8e;
                            }
                        }
                        uVar13 = func_0x0001800b7be0(arg1, unaff_RSI[8]);
                        if (uVar12 == uVar13) {
                            iVar19 = iVar42;
                            iVar14 = func_0x0001800b7be0(arg1, iVar42);
                            if (iVar14 < 0) {
                                iVar19 = iVar42;
                                cVar7 = fcn.1800b2930(arg1, iVar42);
                                if (cVar7 == '\0') goto code_r0x0001800b508a;
                            }
                            var_128h = CONCAT71(var_128h._1_7_, var_118h);
                            fcn.1800b3a10(arg1, CONCAT71((unkint7)((uint64_t)iVar19 >> 8), 1), (uint64_t)(uVar12 & 0xff)
                                          , iVar42, var_128h);
                            puVar32 = auStack_148;
                            goto code_r0x0001800b6d8e;
                        }
                    }
code_r0x0001800b508a:
                    var_e8h._0_4_ = 0;
                    var_e8h._4_4_ = 0;
                    var_e0h._0_4_ = 0;
                    var_e0h._4_4_ = 0;
                    var_d8h = 0;
                    var_128h = var_128h & 0xffffffffffffff00;
                    fcn.1800b3310(arg1, iVar25, 0, (int64_t)&var_e8h, var_128h);
                    fcn.1800b4ce0(arg1, unaff_RSI[6]);
                    iVar25 = *(int64_t *)arg1;
                    iVar42 = *(int64_t *)(iVar25 + 0x30);
                    var_c8h = *(int64_t *)(iVar25 + 0x28);
                    stack0xfffffffffffffef0 = 0x17;
                    fcn.1800d31a0((int64_t *)(iVar25 + 0x28), (int64_t)&var_117h + 7);
                    fcn.1800d31a0(iVar25 + 0x40, iVar25 + 0x270);
                    iVar25 = *(int64_t *)(*(int64_t *)arg1 + 0x30);
                    iVar19 = *(int64_t *)(*(int64_t *)arg1 + 0x28);
                    fcn.1800b4ce0(arg1, unaff_RSI[8]);
                    iVar20 = *(int64_t *)(*(int64_t *)arg1 + 0x30);
                    var_90h = *(int64_t *)(*(int64_t *)arg1 + 0x28);
                    puVar29 = (undefined8 *)CONCAT44(var_e8h._4_4_, (undefined4)var_e8h);
                    puVar4 = (undefined8 *)CONCAT44(var_e0h._4_4_, (uint32_t)var_e0h);
                    iVar18 = var_90h;
                    if (puVar29 != puVar4) goto code_r0x0001800b5150;
                    goto code_r0x0001800b5173;
                }
                cVar7 = func_0x0001800ac9f0();
                if (cVar7 == '\0') {
                    arg2 = unaff_RSI[8];
                } else {
                    arg2 = unaff_RSI[6];
                }
            }
        } else {
            arg2 = piVar21[4];
            unaff_RSI = (int64_t *)0x0;
        }
        goto code_r0x0001800b4d17;
    }
    if (0 < *(int32_t *)(arg1 + 0xc)) {
        *(int32_t *)(*(int64_t *)arg1 + 0x270) = *(int32_t *)((int64_t)piVar21 + 0xc) + 1;
    }
    piVar38 = (int64_t *)piVar21[4];
    piVar26 = (int64_t *)0x0;
    if (*(int32_t *)(piVar38 + 1) == *(int32_t *)0x18078269c) {
        piVar26 = piVar38;
    }
    piVar41 = (int64_t *)0x0;
    if (piVar26 == (int64_t *)0x0) {
        piVar39 = (int64_t *)0x0;
        piVar26 = piVar21;
        if (*(int32_t *)(piVar38 + 1) == *(int32_t *)0x180782738) {
            piVar41 = piVar38;
        }
    } else {
        piVar39 = piVar21;
        if (*(int32_t *)((int64_t *)piVar26[4] + 1) == *(int32_t *)0x180782738) {
            piVar41 = (int64_t *)piVar26[4];
        }
    }
    if ((piVar41 != (int64_t *)0x0) && (0 < *(int32_t *)(arg1 + 8))) {
        iVar25 = piVar41[4];
        iVar14 = func_0x0001800aa2c0(arg1 + 0xb0);
        if (iVar14 == 0) {
            uVar37 = *(undefined8 *)arg1;
            var_100h = func_0x000180498cd0(iVar25);
            var_108h = iVar25;
            var_e0h._0_4_ = func_0x0001800cf010(uVar37, &var_108h);
            var_a8h._0_4_ = 5;
            stack0xffffffffffffff64 = SUB1612(ZEXT816(0), 4);
            var_a0h._0_4_ = (uint32_t)var_e0h;
            var_e8h._0_4_ = 5;
            var_e0h._4_4_ = 0;
            var_d8h = 0;
            iVar14 = func_0x0001800ced20(uVar37, &var_e8h, &var_a8h);
            uVar37 = *(undefined8 *)arg1;
            iVar25 = piVar26[5];
            var_100h = func_0x000180498cd0(iVar25);
            var_108h = iVar25;
            var_e0h._0_4_ = func_0x0001800cf010(uVar37, &var_108h);
            var_a8h._0_4_ = 5;
            stack0xffffffffffffff64 = SUB1612(ZEXT816(0), 4);
            var_a0h._0_4_ = (uint32_t)var_e0h;
            var_e8h._0_4_ = 5;
            var_e0h._4_4_ = 0;
            var_d8h = 0;
            uVar12 = func_0x0001800ced20(uVar37, &var_e8h, &var_a8h);
            if (piVar39 == (int64_t *)0x0) {
                uVar13 = 0xffffffff;
            } else {
                uVar37 = *(undefined8 *)arg1;
                iVar25 = piVar39[5];
                uVar23 = func_0x000180498cd0(iVar25);
                var_100h = uVar23;
                var_108h = iVar25;
                var_e0h._0_4_ = func_0x0001800cf010(uVar37, &var_108h);
                var_a8h._0_4_ = 5;
                stack0xffffffffffffff64 = SUB1612(ZEXT816(0), 4);
                var_a0h._0_4_ = (uint32_t)var_e0h;
                var_e8h._0_4_ = 5;
                var_e0h._4_4_ = 0;
                var_d8h = 0;
                uVar13 = func_0x0001800ced20(uVar37, &var_e8h, &var_a8h);
            }
            var_e8h = CONCAT44(var_e8h._4_4_, (undefined4)var_e8h);
            if (((iVar14 < 0) || (var_e8h = CONCAT44(var_e8h._4_4_, (undefined4)var_e8h), (int32_t)uVar12 < 0)) ||
               ((piVar39 != (int64_t *)0x0 &&
                (var_e8h = CONCAT44(var_e8h._4_4_, (undefined4)var_e8h), (int32_t)uVar13 < 0)))) {
code_r0x0001800b6f34:
                fcn.1800acea0((int64_t)piVar21 + 0xc, 0x18063f5a0);
                goto code_r0x0001800b6f45;
            }
            if (((iVar14 < 0x400) && ((int32_t)uVar12 < 0x400)) && ((int32_t)uVar13 < 0x400)) {
                uVar12 = (iVar14 << 10 | uVar12) << 10;
                if (piVar39 == (int64_t *)0x0) {
                    uVar12 = uVar12 | 0x80000000;
                } else {
                    uVar12 = uVar12 | uVar13 | 0xc0000000;
                }
                uVar13 = func_0x0001800cf7f0(*(undefined8 *)arg1, uVar12);
                if (uVar13 < 0x8000) {
                    func_0x0001800cfe30(*(undefined8 *)arg1, 0xc, var_118h, uVar13 & 0xffff);
                    func_0x0001800cfe80(*(undefined8 *)arg1, uVar12);
                    puVar32 = auStack_148;
                    goto code_r0x0001800b6d8e;
                }
            }
        }
    }
    uVar12 = *(uint32_t *)(arg1 + 0x60c);
    var_90h._0_4_ = uVar12;
    iVar25 = piVar21[4];
    var_e0h._0_4_ = uVar12;
    var_e8h = arg1;
    uVar13 = func_0x0001800b7be0(arg1, iVar25);
    if ((int32_t)uVar13 < 0) {
        if ((uint8_t)var_117h == 0) {
            uVar13 = func_0x0001800b7be0();
            if ((int32_t)uVar13 < 0) {
                uVar13 = uVar12 + 1;
                if (0xff < uVar13) {
code_r0x0001800b6f45:
                    fcn.1800acea0(iVar25 + 0xc, 0x18063fbc0, 1, 0xff);
                    pcVar3 = (code *)swi(3);
                    (*pcVar3)();
                    return;
                }
                *(uint32_t *)(arg1 + 0x60c) = uVar13;
                uVar40 = *(uint32_t *)(arg1 + 0x610);
                if (*(uint32_t *)(arg1 + 0x610) < uVar13) {
                    uVar40 = uVar13;
                }
                *(uint32_t *)(arg1 + 0x610) = uVar40;
                fcn.1800b4ce0(arg1, iVar25);
                uVar13 = uVar12 & 0xff;
            }
            uVar13 = uVar13 & 0xff;
        } else {
            uVar13 = (uint32_t)var_118h;
            fcn.1800b4ce0(arg1, iVar25);
        }
    }
    if (0 < *(int32_t *)(arg1 + 0xc)) {
        *(int32_t *)(*(int64_t *)arg1 + 0x270) = *(int32_t *)(piVar21 + 6) + 1;
    }
    iVar25 = piVar21[5];
    uVar17 = func_0x000180498cd0(iVar25);
    uVar37 = *(undefined8 *)arg1;
    var_108h = iVar25;
    var_100h = uVar17;
    var_a0h._0_4_ = func_0x0001800cf010(uVar37, &var_108h);
    var_a8h._0_4_ = 5;
    stack0xffffffffffffff64 = SUB1612(ZEXT816(0), 4);
    var_108h = CONCAT44(var_108h._4_4_, 5);
    _var_100h = ZEXT416((uint32_t)var_a0h);
    *(uint32_t *)0x0 = func_0x0001800ced20(uVar37, &var_108h, &var_a8h);
    if ((int32_t)*(uint32_t *)0x0 < 0) {
        fcn.1800acea0((int64_t)piVar21 + 0xc, 0x18063f5a0);
code_r0x0001800b6f73:
        fcn.1800acea0((int64_t)piVar21 + 0xc, 0x18063f5a0);
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    iVar42 = *(int64_t *)arg1;
    uVar27 = uVar17;
    for (; uVar12 = (uint32_t)uVar27, uVar17 != 0; uVar17 = uVar17 - 1) {
        uVar27 = (uint64_t)
                 (uVar12 ^ (uint32_t)*(uint8_t *)(iVar25 + -1 + uVar17) + uVar12 * 0x20 +
                           ((uint32_t)(uVar27 >> 2) & 0x3fffffff));
    }
    var_c8h = CONCAT44(var_c8h._4_4_, (((uVar12 & 0xff) << 8 | uVar13 & 0xff) << 8 | (uint32_t)var_118h) << 8) | 0xf;
    fcn.1800d31a0(iVar42 + 0x28, &var_c8h);
    fcn.1800d31a0(iVar42 + 0x40, iVar42 + 0x270);
    iVar25 = *(int64_t *)arg1;
    var_c8h = CONCAT44(var_c8h._4_4_, stack0xfffffffffffffef0);
    fcn.1800d31a0(iVar25 + 0x28, &var_c8h);
    fcn.1800d31a0(iVar25 + 0x40, iVar25 + 0x270);
    var_128h = CONCAT44(var_128h._4_4_, 2);
    func_0x0001800bbfb0(arg1, piVar21[4], uVar13 & 0xff, 4);
    *(uint32_t *)(arg1 + 0x60c) = (uint32_t)var_90h;
    puVar32 = auStack_148;
    goto code_r0x0001800b6d8e;
code_r0x0001800b4dff:
    arg2 = piVar21[4];
    goto code_r0x0001800b4d17;
    while (puVar29 = puVar29 + 1, puVar29 != puVar4) {
code_r0x0001800b5150:
        cVar7 = func_0x0001800cfeb0(*(undefined8 *)arg1, *puVar29, iVar25 - iVar19 >> 2);
        if (cVar7 == '\0') goto code_r0x0001800b6de1;
    }
    iVar18 = var_90h;
code_r0x0001800b5173:
    piVar38 = (int64_t *)(iVar20 - iVar18 >> 2);
    piVar41 = (int64_t *)(iVar42 - var_c8h >> 2);
    cVar7 = func_0x0001800cfeb0(*(undefined8 *)arg1, piVar41, piVar38);
    if (cVar7 == '\0') {
code_r0x0001800b6de1:
        fcn.1800acea0((int64_t)unaff_RSI + 0xc, 0x18063f7f0);
code_r0x0001800b6df2:
        fcn.1800acea0((int64_t)unaff_RSI + 0xc, 0x18063f5a0);
        arg1 = CONCAT44(var_e8h._4_4_, (undefined4)var_e8h);
code_r0x0001800b6e03:
        var_e8h = arg1;
        fcn.1800acea0((int64_t)unaff_RSI + 0xc, 0x18063fbc0);
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    iVar25 = CONCAT44(var_e8h._4_4_, (undefined4)var_e8h);
    puVar32 = auStack_148;
    if (iVar25 == 0) goto code_r0x0001800b6d8e;
    uVar17 = (var_d8h - iVar25 >> 3) * 8;
code_r0x0001800b51ba:
    iVar42 = iVar25;
    if (0xfff < uVar17) {
        iVar42 = *(int64_t *)(iVar25 + -8);
        if (0x1f < (iVar25 - iVar42) - 8U) {
            pcVar3 = (code *)swi(0x29);
            (*pcVar3)(5);
            puVar32 = auStack_140;
code_r0x0001800b57da:
            *(int64_t *)(puVar32 + 0x60) = arg1;
            uVar12 = *(uint32_t *)(arg1 + 0x60c);
            *(uint32_t *)(puVar32 + 0x38) = uVar12;
            *(uint32_t *)(puVar32 + 0x68) = uVar12;
            iVar14 = *(int32_t *)(piVar41 + 4);
            puVar30 = puVar32;
    // switch table (16 cases) at 0x1800b6f98
            switch(iVar14) {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
                iVar25 = piVar41[6];
                *(undefined8 *)(puVar32 + -8) = 0x1800b581b;
                uVar13 = fcn.1800b3050(arg1, iVar25);
                if (uVar13 < 0x100) {
                    iVar25 = piVar41[5];
                    *(undefined8 *)(puVar32 + -8) = 0x1800b5834;
                    uVar11 = func_0x0001800b7030(arg1, iVar25);
    // switch table (7 cases) at 0x1800b6fd8
                    switch(*(undefined4 *)(piVar41 + 4)) {
                    case 0:
                        uVar37 = 0x27;
                        break;
                    case 1:
                        uVar37 = 0x28;
                        break;
                    case 2:
                        uVar37 = 0x29;
                        break;
                    case 3:
                        uVar37 = 0x2a;
                        break;
                    case 4:
                        uVar37 = 0x52;
                        break;
                    case 5:
                        uVar37 = 0x2b;
                        break;
                    case 6:
                        uVar37 = 0x2c;
                        break;
                    default:
                        uVar37 = 0;
                    }
                    puVar32[0x20] = (char)uVar13;
                    uVar23 = *(undefined8 *)arg1;
                    *(undefined8 *)(puVar32 + -8) = 0x1800b5896;
                    func_0x0001800cfdd0(uVar23, uVar37, puVar32[0x30], uVar11);
                    iVar25 = piVar41[5];
                } else {
                    uVar13 = *(uint32_t *)(piVar41 + 4);
                    if ((uVar13 - 1 & 0xfffffffd) == 0) {
                        iVar25 = piVar41[5];
                        *(undefined8 *)(puVar32 + -8) = 0x1800b5a1c;
                        uVar13 = fcn.1800b3050(arg1, iVar25);
                        if (uVar13 < 0x100) {
                            iVar25 = piVar41[6];
                            *(undefined8 *)(puVar32 + -8) = 0x1800b5a35;
                            uVar11 = func_0x0001800b7030(arg1, iVar25);
                            iVar14 = *(int32_t *)(piVar41 + 4);
                            puVar32[0x20] = uVar11;
                            uVar37 = *(undefined8 *)arg1;
                            *(undefined8 *)(puVar32 + -8) = 0x1800b5a5b;
                            func_0x0001800cfdd0(uVar37, (iVar14 != 1) + 'G', puVar32[0x30], (char)uVar13);
code_r0x0001800b5a5e:
                            *(undefined4 *)(puVar32 + 0x20) = 1;
                            iVar25 = piVar41[6];
                            *(undefined8 *)(puVar32 + -8) = 0x1800b5a78;
                            func_0x0001800bbfb0(arg1, iVar25, uVar11, 2);
                            *(uint32_t *)(arg1 + 0x60c) = uVar12;
                            goto code_r0x0001800b6d8e;
                        }
                    } else if ((((1 < *(int32_t *)(arg1 + 8)) && ((uVar13 & 0xfffffffd) == 0)) &&
                               (*(int64_t *)(arg1 + 0x250) != 0)) && (piVar41 != *(int64_t **)(arg1 + 600))) {
                        uVar35 = *(int64_t *)(arg1 + 0x248) - 1;
                        uVar17 = ((uint64_t)piVar41 >> 5 ^ (uint64_t)piVar41) >> 4;
                        uVar27 = 0;
                        do {
                            uVar17 = uVar17 & uVar35;
                            iVar25 = uVar17 * 0x10;
                            piVar38 = *(int64_t **)(iVar25 + *(int64_t *)(arg1 + 0x240));
                            if (piVar38 == piVar41) {
                                piVar22 = (int32_t *)(*(int64_t *)(arg1 + 0x240) + 8 + iVar25);
                                if ((piVar22 != (int32_t *)0x0) &&
                                   ((iVar14 = *piVar22, iVar14 == 2 || ((iVar14 == 8 && (uVar13 == 2)))))) {
                                    iVar25 = piVar41[5];
                                    *(undefined8 *)(puVar32 + -8) = 0x1800b5994;
                                    uVar13 = fcn.1800b3050(arg1, iVar25);
                                    if (uVar13 < 0x100) {
                                        iVar25 = piVar41[6];
                                        *(undefined8 *)(puVar32 + -8) = 0x1800b59a9;
                                        uVar11 = func_0x0001800b7030(arg1, iVar25);
    // switch table (7 cases) at 0x1800b7010
                                        switch(*(undefined4 *)(piVar41 + 4)) {
                                        case 0:
                                            uVar37 = 0x27;
                                            break;
                                        case 1:
                                            uVar37 = 0x28;
                                            break;
                                        case 2:
                                            uVar37 = 0x29;
                                            break;
                                        case 3:
                                            uVar37 = 0x2a;
                                            break;
                                        case 4:
                                            uVar37 = 0x52;
                                            break;
                                        case 5:
                                            uVar37 = 0x2b;
                                            break;
                                        case 6:
                                            uVar37 = 0x2c;
                                            break;
                                        default:
                                            uVar37 = 0;
                                        }
                                        puVar32[0x20] = (char)uVar13;
                                        uVar23 = *(undefined8 *)arg1;
                                        *(undefined8 *)(puVar32 + -8) = 0x1800b5a0b;
                                        func_0x0001800cfdd0(uVar23, uVar37, puVar32[0x30], uVar11);
                                        goto code_r0x0001800b5a5e;
                                    }
                                }
                                break;
                            }
                            if (piVar38 == *(int64_t **)(arg1 + 600)) break;
                            uVar17 = uVar17 + 1 + uVar27;
                            uVar27 = uVar27 + 1;
                        } while (uVar27 <= uVar35);
                    }
                    iVar25 = piVar41[5];
                    *(undefined8 *)(puVar32 + -8) = 0x1800b5942;
                    uVar8 = func_0x0001800b7030(arg1, iVar25);
                    iVar25 = piVar41[6];
                    *(undefined8 *)(puVar32 + -8) = 0x1800b5951;
                    uVar11 = func_0x0001800b7030(arg1, iVar25);
    // switch table (7 cases) at 0x1800b6ff4
                    switch(*(undefined4 *)(piVar41 + 4)) {
                    case 0:
                        uVar37 = 0x21;
                        break;
                    case 1:
                        uVar37 = 0x22;
                        break;
                    case 2:
                        uVar37 = 0x23;
                        break;
                    case 3:
                        uVar37 = 0x24;
                        break;
                    case 4:
                        uVar37 = 0x51;
                        break;
                    case 5:
                        uVar37 = 0x25;
                        break;
                    case 6:
                        uVar37 = 0x26;
                        break;
                    default:
                        uVar37 = 0;
                    }
                    puVar32[0x20] = uVar11;
                    uVar23 = *(undefined8 *)arg1;
                    *(undefined8 *)(puVar32 + -8) = 0x1800b5ace;
                    func_0x0001800cfdd0(uVar23, uVar37, puVar32[0x30], uVar8);
                    *(undefined4 *)(puVar32 + 0x20) = 1;
                    iVar25 = piVar41[5];
                    *(undefined8 *)(puVar32 + -8) = 0x1800b5aef;
                    func_0x0001800bbfb0(arg1, iVar25, uVar8, 2);
                    iVar25 = piVar41[6];
                }
                *(undefined4 *)(puVar32 + 0x20) = 1;
                *(undefined8 *)(puVar32 + -8) = 0x1800b5b06;
                func_0x0001800bbfb0(arg1, iVar25, uVar11, 2);
                break;
            case 7:
                _var_90h = *(undefined (*) [16])(piVar41 + 5);
                *(int64_t **)(puVar32 + 0x40) = &var_90h;
                *(int64_t **)(puVar32 + 0x48) = &var_80h;
                *(undefined8 *)(puVar32 + -8) = 0x1800b5b3b;
                func_0x0001800c08c0(&var_c8h, puVar32 + 0x40);
                *(undefined8 *)(puVar32 + -8) = 0x1800b5b45;
                fcn.1800b3840((int64_t)&var_c8h, *(int64_t *)(puVar32 + 0x30));
                *(undefined8 *)(puVar32 + -8) = 0x1800b5b5c;
                cVar7 = func_0x0001800bbe60(arg1, piVar41, var_c0h - var_c8h >> 3);
                uVar17 = 0;
                if (var_c0h - var_c8h >> 3 != 0) {
                    do {
                        iVar25 = *(int64_t *)(var_c8h + uVar17 * 8);
                        *(undefined8 *)(puVar32 + -8) = 0x1800b5b93;
                        fcn.1800b4ce0(arg1, iVar25);
                        uVar17 = uVar17 + 1;
                    } while (uVar17 < (uint64_t)(var_c0h - var_c8h >> 3));
                }
                puVar32[0x20] = (char)(var_c0h - var_c8h >> 3) + -1 + cVar7;
                uVar37 = *(undefined8 *)arg1;
                *(undefined8 *)(puVar32 + -8) = 0x1800b5bd6;
                func_0x0001800cfdd0(uVar37, 0x31, puVar32[0x30], cVar7);
                if (var_c8h != 0) {
                    uVar17 = (var_b8h - var_c8h >> 3) * 8;
                    iVar25 = var_c8h;
                    if (0xfff < uVar17) {
                        iVar25 = *(int64_t *)(var_c8h + -8);
                        if (0x1f < (var_c8h - iVar25) - 8U) {
                            pcVar3 = (code *)swi(0x29);
                            (*pcVar3)(5);
                            puVar30 = puVar32 + 8;
                            goto code_r0x0001800b5c29;
                        }
                        uVar17 = uVar17 + 0x27;
                    }
                    *(undefined8 *)(puVar32 + -8) = 0x1800b5c1d;
                    fcn.180459c3c(iVar25, uVar17);
                }
                break;
            case 8:
            case 9:
            case 10:
            case 0xb:
            case 0xc:
            case 0xd:
code_r0x0001800b5c29:
                *(undefined8 *)(puVar30 + -8) = 0x1800b5c37;
                iVar25 = fcn.1800b2ad0(arg1, (int64_t)piVar41);
                iVar42 = *(int64_t *)arg1;
                uVar10 = puVar30[0x30];
                var_c8h = CONCAT44(var_c8h._4_4_, (uint32_t)uVar10 << 8) | 0x1000003;
                *(undefined8 *)(puVar30 + -8) = 0x1800b5c5d;
                fcn.1800d31a0(iVar42 + 0x28, &var_c8h);
                *(undefined8 *)(puVar30 + -8) = 0x1800b5c6d;
                fcn.1800d31a0(iVar42 + 0x40, iVar42 + 0x270);
                iVar42 = *(int64_t *)arg1;
                iVar19 = *(int64_t *)(iVar42 + 0x30);
                iVar20 = *(int64_t *)(iVar42 + 0x28);
                var_c8h = CONCAT44(var_c8h._4_4_, (uint32_t)uVar10 << 8) | 0x10003;
                *(undefined8 *)(puVar30 + -8) = 0x1800b5c91;
                fcn.1800d31a0((int64_t *)(iVar42 + 0x28), &var_c8h);
                *(undefined8 *)(puVar30 + -8) = 0x1800b5ca1;
                fcn.1800d31a0(iVar42 + 0x40, iVar42 + 0x270);
                uVar37 = *(undefined8 *)arg1;
                *(undefined8 *)(puVar30 + -8) = 0x1800b5caf;
                cVar7 = func_0x0001800cfeb0(uVar37, iVar25, iVar19 - iVar20 >> 2);
                if (cVar7 == '\0') {
code_r0x0001800b6e42:
                    *(undefined8 *)(puVar30 + -8) = 0x1800b6e52;
                    fcn.1800acea0((int64_t)piVar41 + 0xc, 0x18063f7f0);
                    puVar32 = puVar30;
code_r0x0001800b6e53:
                    *(undefined8 *)(puVar32 + -8) = 0x1800b6e6f;
                    fcn.1800acea0(iVar25 + 0xc, 0x18063fbc0, 1, 0xff);
                    pcVar3 = (code *)swi(3);
                    (*pcVar3)();
                    return;
                }
                uVar12 = *(uint32_t *)(puVar30 + 0x38);
                puVar32 = puVar30;
                break;
            case 0xe:
            case 0xf:
                *(int64_t *)(puVar32 + 0x40) = arg1;
                *(uint32_t *)(puVar32 + 0x48) = uVar12;
                piVar21 = piVar41 + 5;
                *(undefined8 *)(puVar32 + -8) = 0x1800b5ce6;
                iVar25 = func_0x0001800c13d0(piVar38, piVar21);
                if (((iVar25 == 0) || ((int32_t *)(iVar25 + 8) == (int32_t *)0x0)) ||
                   (iVar34 = *(int32_t *)(iVar25 + 8), iVar34 == 0)) {
                    iVar25 = *piVar21;
                    *(undefined8 *)(puVar32 + -8) = 0x1800b5d48;
                    cVar7 = fcn.1800b3720(arg1, iVar25);
                    if (cVar7 == '\0') {
                        iVar42 = piVar41[6];
                        *(undefined8 *)(puVar32 + -8) = 0x1800b5d5f;
                        iVar34 = func_0x0001800b7be0(arg1, iVar42);
                        var_c8h = CONCAT44(var_c8h._4_4_, iVar34);
                        if (iVar34 < 0) {
                            *(undefined8 *)(puVar32 + -8) = 0x1800b5df1;
                            uVar13 = fcn.1800b3150(arg1, iVar42);
                            if (0xff < uVar13) goto code_r0x0001800b5e18;
                            iVar25 = *piVar21;
                            *(undefined8 *)(puVar32 + -8) = 0x1800b5e06;
                            uVar11 = func_0x0001800b7030(arg1, iVar25);
                            cVar7 = (iVar14 != 0xe) + '/';
                            puVar32[0x20] = (char)uVar13;
                        } else {
                            *(undefined8 *)(puVar32 + -8) = 0x1800b5d75;
                            uVar13 = func_0x0001800b7be0(arg1, iVar25);
                            if ((int32_t)uVar13 < 0) {
                                uVar13 = uVar12 + 1;
                                if (0xff < uVar13) goto code_r0x0001800b6e53;
                                *(uint32_t *)(arg1 + 0x60c) = uVar13;
                                uVar40 = *(uint32_t *)(arg1 + 0x610);
                                if (*(uint32_t *)(arg1 + 0x610) < uVar13) {
                                    uVar40 = uVar13;
                                }
                                *(uint32_t *)(arg1 + 0x610) = uVar40;
                                *(undefined8 *)(puVar32 + -8) = 0x1800b5db4;
                                fcn.1800b4ce0(arg1, iVar25);
                                uVar13 = uVar12 & 0xff;
                            }
                            uVar11 = (undefined)uVar13;
                            cVar7 = (iVar14 != 0xe) + '-';
                            puVar32[0x20] = (char)var_c8h;
                        }
                        uVar37 = *(undefined8 *)arg1;
                        *(undefined8 *)(puVar32 + -8) = 0x1800b5ddc;
                        func_0x0001800cfdd0(uVar37, cVar7, puVar32[0x30], uVar11);
                    } else {
code_r0x0001800b5e18:
                        if (puVar32[0x31] == '\0') {
                            uVar40 = *(uint32_t *)(arg1 + 0x60c);
                            uVar13 = uVar40 + 1;
                            if (0xff < uVar13) {
                                *(undefined8 *)(puVar32 + -8) = 0x1800b6e8c;
                                fcn.1800acea0((int64_t)piVar41 + 0xc, 0x18063fbc0, 1, 0xff);
code_r0x0001800b6e8d:
                                *(undefined8 *)(puVar32 + -8) = 0x1800b6e9d;
                                fcn.1800acea0((int64_t)piVar41 + 0xc, 0x18063f7f0);
                                goto code_r0x0001800b6e9e;
                            }
                            *(uint32_t *)(arg1 + 0x60c) = uVar13;
                            uVar24 = *(uint32_t *)(arg1 + 0x610);
                            if (*(uint32_t *)(arg1 + 0x610) < uVar13) {
                                uVar24 = uVar13;
                            }
                            *(uint32_t *)(arg1 + 0x610) = uVar24;
                            uVar10 = puVar32[0x30];
                        } else {
                            uVar10 = puVar32[0x30];
                            uVar40 = (uint32_t)uVar10;
                        }
                        puVar32[0x32] = (char)uVar40;
                        _var_90h = ZEXT816(0);
                        var_80h = 0;
                        puVar32[0x20] = iVar14 != 0xe;
                        iVar25 = *piVar21;
                        *(undefined8 *)(puVar32 + -8) = 0x1800b5e93;
                        fcn.1800b3310(arg1, iVar25, (int64_t)(puVar32 + 0x32), (int64_t)&var_90h, 
                                      *(int64_t *)(puVar32 + 0x20));
                        iVar25 = piVar41[6];
                        *(undefined8 *)(puVar32 + -8) = 0x1800b5ea8;
                        fcn.1800b4ce0(arg1, iVar25);
                        iVar25 = *(int64_t *)(*(int64_t *)arg1 + 0x30);
                        iVar42 = *(int64_t *)(*(int64_t *)arg1 + 0x28);
                        piVar26 = (int64_t *)var_88h;
                        piVar21 = (int64_t *)var_90h;
                        if (var_90h != var_88h) {
                            do {
                                iVar19 = *piVar21;
                                uVar37 = *(undefined8 *)arg1;
                                *(undefined8 *)(puVar32 + -8) = 0x1800b5ede;
                                cVar7 = func_0x0001800cfeb0(uVar37, iVar19, iVar25 - iVar42 >> 2);
                                if (cVar7 == '\0') goto code_r0x0001800b6e8d;
                                piVar21 = piVar21 + 1;
                            } while (piVar21 != piVar26);
                        }
                        iVar25 = var_90h;
                        if (uVar10 != puVar32[0x32]) {
                            iVar25 = *(int64_t *)arg1;
                            var_c8h = CONCAT44(var_c8h._4_4_, (uint32_t)CONCAT11(puVar32[0x32], uVar10) << 8) | 6;
                            *(undefined8 *)(puVar32 + -8) = 0x1800b5f21;
                            fcn.1800d31a0(iVar25 + 0x28, &var_c8h);
                            *(undefined8 *)(puVar32 + -8) = 0x1800b5f31;
                            fcn.1800d31a0(iVar25 + 0x40, iVar25 + 0x270);
                            iVar25 = var_90h;
                        }
                        if (iVar25 != 0) {
                            uVar17 = (var_80h - iVar25 >> 3) * 8;
                            iVar42 = iVar25;
                            if (0xfff < uVar17) {
                                iVar42 = *(int64_t *)(iVar25 + -8);
                                piVar21 = (int64_t *)((iVar25 - iVar42) + -8);
                                if ((int64_t *)0x1f < piVar21) {
                                    pcVar3 = (code *)swi(0x29);
                                    (*pcVar3)(5);
                                    puVar31 = puVar32 + 8;
code_r0x0001800b5f86:
                                    *(int64_t *)(puVar31 + 0x60) = arg1;
                                    uVar12 = *(uint32_t *)(arg1 + 0x60c);
                                    *(uint32_t *)(puVar31 + 0x68) = uVar12;
                                    iVar25 = piVar21[5];
                                    iVar42 = 0;
                                    if (*(int32_t *)(iVar25 + 8) == *(int32_t *)0x18078271c) {
                                        iVar42 = iVar25;
                                    }
                                    puVar32 = puVar31;
                                    if (((*(char *)0x180778580 == '\0') || (*(int32_t *)(piVar21 + 4) != 1)) ||
                                       (iVar42 == 0)) {
                                        *(undefined8 *)(puVar31 + -8) = 0x1800b5ffc;
                                        uVar13 = func_0x0001800b7be0(arg1);
                                        if ((int32_t)uVar13 < 0) {
                                            uVar13 = uVar12 + 1;
                                            if (0xff < uVar13) {
                                                *(undefined8 *)(puVar31 + -8) = 0x1800b6ecb;
                                                fcn.1800acea0(iVar25 + 0xc, 0x18063fbc0, 1, 0xff);
                                                puVar33 = puVar31;
code_r0x0001800b6ecc:
                                                *(undefined8 *)(puVar33 + -8) = 0x1800b6edc;
                                                fcn.1800acea0((int64_t)piVar26 + 0xc, 0x18063f5a0);
                                                pcVar3 = (code *)swi(3);
                                                (*pcVar3)();
                                                return;
                                            }
                                            *(uint32_t *)(arg1 + 0x60c) = uVar13;
                                            uVar40 = *(uint32_t *)(arg1 + 0x610);
                                            if (*(uint32_t *)(arg1 + 0x610) < uVar13) {
                                                uVar40 = uVar13;
                                            }
                                            *(uint32_t *)(arg1 + 0x610) = uVar40;
                                            *(undefined8 *)(puVar31 + -8) = 0x1800b603e;
                                            fcn.1800b4ce0(arg1, iVar25);
                                            uVar13 = uVar12 & 0xff;
                                        }
                                        iVar25 = *(int64_t *)arg1;
                                        iVar14 = *(int32_t *)(piVar21 + 4);
                                        if (iVar14 == 0) {
                                            uVar40 = 0x32;
                                        } else if (iVar14 == 1) {
                                            uVar40 = 0x33;
                                        } else if (iVar14 == 2) {
                                            uVar40 = 0x34;
                                        } else {
                                            uVar40 = 0;
                                        }
                                        var_c8h = CONCAT44(var_c8h._4_4_, 
                                                           ((uVar13 & 0xff) << 8 | (uint32_t)(uint8_t)puVar31[0x30]) <<
                                                           8 | uVar40);
                                        *(undefined8 *)(puVar31 + -8) = 0x1800b6092;
                                        fcn.1800d31a0(iVar25 + 0x28, &var_c8h);
                                        *(undefined8 *)(puVar31 + -8) = 0x1800b60a2;
                                        fcn.1800d31a0(iVar25 + 0x40, iVar25 + 0x270);
                                        *(uint32_t *)(arg1 + 0x60c) = uVar12;
                                    } else {
                                        iVar25 = *(int64_t *)(iVar42 + 0x20);
                                        uVar37 = *(undefined8 *)arg1;
                                        *(undefined8 *)(puVar31 + -8) = 0x1800b5fcc;
                                        uVar13 = func_0x0001800cf6b0(uVar37, -iVar25);
                                        if ((int32_t)uVar13 < 0) {
code_r0x0001800b6e9e:
                                            *(undefined8 *)(puVar32 + -8) = 0x1800b6eae;
                                            fcn.1800acea0((int64_t)piVar21 + 0xc, 0x18063f5a0);
                                            pcVar3 = (code *)swi(3);
                                            (*pcVar3)();
                                            return;
                                        }
                                        *(undefined8 *)(puVar31 + -8) = 0x1800b5fe4;
                                        fcn.1800ad460(arg1, (uint64_t)(uint8_t)puVar31[0x30], (uint64_t)uVar13);
                                        *(uint32_t *)(arg1 + 0x60c) = uVar12;
                                    }
                                    goto code_r0x0001800b6d8e;
                                }
                                uVar17 = uVar17 + 0x27;
                            }
                            *(undefined8 *)(puVar32 + -8) = 0x1800b5f7a;
                            fcn.180459c3c(iVar42, uVar17);
                        }
                    }
                    *(uint32_t *)(arg1 + 0x60c) = uVar12;
                } else {
                    if ((iVar34 == 1) || ((iVar34 == 2 && (*(char *)(iVar25 + 0x10) == '\0')))) {
                        bVar9 = false;
                    } else {
                        bVar9 = true;
                    }
                    if ((iVar14 == 0xe) == bVar9) {
                        piVar21 = piVar41 + 6;
                    }
                    iVar25 = *piVar21;
                    *(undefined8 *)(puVar32 + -8) = 0x1800b5d30;
                    fcn.1800b4ce0(arg1, iVar25);
                    *(uint32_t *)(arg1 + 0x60c) = uVar12;
                }
            }
            *(uint32_t *)(arg1 + 0x60c) = uVar12;
            goto code_r0x0001800b6d8e;
        }
        uVar17 = uVar17 + 0x27;
    }
    fcn.180459c3c(iVar42, uVar17);
    puVar32 = auStack_148;
code_r0x0001800b6d8e:
    *(undefined8 *)(puVar32 + -8) = 0x1800b6d9a;
    func_0x000180459870(var_58h ^ (uint64_t)puVar32);
    return;
}

// ============================================================
// Function: FUN_1800b7030
// Address: 0x1800b7030
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch

uint64_t fcn.1800b7030(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar4 = fcn.1800b7be0();
    if ((int32_t)uVar4 < 0) {
        uVar2 = *(uint32_t *)(arg1 + 0x60c);
        uVar1 = uVar2 + 1;
        if (0xff < uVar1) {
            fcn.1800acea0(arg2 + 0xc, 0x18063fbc0, 1, 0xff);
            pcVar3 = (code *)swi(3);
            uVar4 = (*pcVar3)();
            return uVar4;
        }
        *(uint32_t *)(arg1 + 0x60c) = uVar1;
        uVar5 = *(uint32_t *)(arg1 + 0x610);
        if (*(uint32_t *)(arg1 + 0x610) < uVar1) {
            uVar5 = uVar1;
        }
        *(uint32_t *)(arg1 + 0x610) = uVar5;
        fcn.1800b4ce0(arg1, arg2);
        uVar4 = (uint64_t)(uVar2 & 0xff);
    }
    return uVar4;
}

// ============================================================
// Function: FUN_1800b7049
// Address: 0x1800b7049
// Size: 71 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch

uint64_t fcn.1800b7030(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar4 = fcn.1800b7be0();
    if ((int32_t)uVar4 < 0) {
        uVar2 = *(uint32_t *)(arg1 + 0x60c);
        uVar1 = uVar2 + 1;
        if (0xff < uVar1) {
            fcn.1800acea0(arg2 + 0xc, 0x18063fbc0, 1, 0xff);
            pcVar3 = (code *)swi(3);
            uVar4 = (*pcVar3)();
            return uVar4;
        }
        *(uint32_t *)(arg1 + 0x60c) = uVar1;
        uVar5 = *(uint32_t *)(arg1 + 0x610);
        if (*(uint32_t *)(arg1 + 0x610) < uVar1) {
            uVar5 = uVar1;
        }
        *(uint32_t *)(arg1 + 0x610) = uVar5;
        fcn.1800b4ce0(arg1, arg2);
        uVar4 = (uint64_t)(uVar2 & 0xff);
    }
    return uVar4;
}

// ============================================================
// Function: FUN_1800b7090
// Address: 0x1800b7090
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch

uint64_t fcn.1800b7030(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar4 = fcn.1800b7be0();
    if ((int32_t)uVar4 < 0) {
        uVar2 = *(uint32_t *)(arg1 + 0x60c);
        uVar1 = uVar2 + 1;
        if (0xff < uVar1) {
            fcn.1800acea0(arg2 + 0xc, 0x18063fbc0, 1, 0xff);
            pcVar3 = (code *)swi(3);
            uVar4 = (*pcVar3)();
            return uVar4;
        }
        *(uint32_t *)(arg1 + 0x60c) = uVar1;
        uVar5 = *(uint32_t *)(arg1 + 0x610);
        if (*(uint32_t *)(arg1 + 0x610) < uVar1) {
            uVar5 = uVar1;
        }
        *(uint32_t *)(arg1 + 0x610) = uVar5;
        fcn.1800b4ce0(arg1, arg2);
        uVar4 = (uint64_t)(uVar2 & 0xff);
    }
    return uVar4;
}

// ============================================================
// Function: FUN_1800b709b
// Address: 0x1800b709b
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch

uint64_t fcn.1800b7030(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar4 = fcn.1800b7be0();
    if ((int32_t)uVar4 < 0) {
        uVar2 = *(uint32_t *)(arg1 + 0x60c);
        uVar1 = uVar2 + 1;
        if (0xff < uVar1) {
            fcn.1800acea0(arg2 + 0xc, 0x18063fbc0, 1, 0xff);
            pcVar3 = (code *)swi(3);
            uVar4 = (*pcVar3)();
            return uVar4;
        }
        *(uint32_t *)(arg1 + 0x60c) = uVar1;
        uVar5 = *(uint32_t *)(arg1 + 0x610);
        if (*(uint32_t *)(arg1 + 0x610) < uVar1) {
            uVar5 = uVar1;
        }
        *(uint32_t *)(arg1 + 0x610) = uVar5;
        fcn.1800b4ce0(arg1, arg2);
        uVar4 = (uint64_t)(uVar2 & 0xff);
    }
    return uVar4;
}

// ============================================================
// Function: FUN_1800b70c0
// Address: 0x1800b70c0
// Size: 137 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800b70c0(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    undefined4 uVar2;
    char cVar3;
    int64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int32_t *)(arg2 + 8);
    if ((((iVar1 != *(int32_t *)0x180782728) && (iVar1 != *(int32_t *)0x180782738)) &&
        (iVar1 != *(int32_t *)0x1807826b8)) && (iVar1 != *(int32_t *)0x1807826a0)) {
        cVar3 = fcn.1800b2930(arg1, arg2);
        if (cVar3 == '\0') {
            if (iVar1 != *(int32_t *)0x180782740) {
                fcn.1800d0a10(*(undefined8 *)arg1, 0x18063f9a8);
            }
            uVar2 = *(undefined4 *)(arg1 + 0x60c);
            fcn.1800b7030(arg1, arg2, unaff_RDI);
            *(undefined4 *)(arg1 + 0x60c) = uVar2;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800b7150
// Address: 0x1800b7150
// Size: 92 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_127h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_126h
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch

void fcn.1800b7150(int64_t arg1, int64_t arg2, int64_t arg_70h)
{
    uint64_t *puVar1;
    uint64_t uVar2;
    undefined4 *puVar3;
    code *pcVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined4 *puVar7;
    undefined *puVar8;
    undefined *puVar9;
    undefined *puVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    undefined8 uVar13;
    uint64_t in_R8;
    int64_t iVar14;
    uint8_t in_R9B;
    uint64_t uVar15;
    int64_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t in_stack_00000018;
    int64_t var_20h;
    undefined in_stack_00000028;
    undefined8 auStack_50 [3];
    undefined auStack_38 [8];
    undefined auStack_30 [8];
    int64_t var_28h;
    unkuint7 in_stack_ffffffffffffffe1;
    
    uVar11 = (uint32_t)in_R8 & 0xff;
    if (in_R9B == 0xff) {
        fcn.1800acea0(arg2 + 0xc, 0x18063f9d8);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    iVar16 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782740) {
        iVar16 = arg2;
    }
    if (iVar16 != 0) {
        fcn.1800b0700(arg1, iVar16, in_R8 & 0xff, (uint64_t)in_R9B, CONCAT71(var_28h._1_7_, in_stack_00000028), 
                      (uint64_t)in_stack_ffffffffffffffe1 << 8, in_stack_00000018);
        return;
    }
    iVar16 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x1807826b8) {
        iVar16 = arg2;
    }
    if (iVar16 == 0) {
        fcn.1800b4ce0(arg1, arg2);
        uVar6 = 1;
        if (1 < (uint64_t)in_R9B) {
            do {
                iVar16 = *(int64_t *)arg1;
                var_20h = CONCAT44(var_20h._4_4_, ((int32_t)uVar6 + uVar11 & 0xff) << 8) | 2;
                fcn.1800d31a0(iVar16 + 0x28, &var_20h);
                fcn.1800d31a0(iVar16 + 0x40, iVar16 + 0x270);
                uVar6 = uVar6 + 1;
            } while (uVar6 < in_R9B);
        }
        return;
    }
    if (0 < *(int32_t *)(arg1 + 0xc)) {
        *(int32_t *)(*(int64_t *)arg1 + 0x270) = *(int32_t *)(iVar16 + 0xc) + 1;
    }
    arg1 = *(int64_t *)arg1;
    var_20h = CONCAT44(var_20h._4_4_, ((uint32_t)(uint8_t)(in_R9B + 1) << 8 | uVar11) << 8) | 0x3f;
    fcn.1800d31a0(arg1 + 0x28, &var_20h);
    puVar1 = (uint64_t *)(arg1 + 0x40);
    puVar9 = auStack_38;
    puVar10 = auStack_38;
    puVar7 = *(undefined4 **)(arg1 + 0x48);
    if (puVar7 != *(undefined4 **)(arg1 + 0x50)) {
        *puVar7 = *(undefined4 *)(arg1 + 0x270);
        *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 4;
        return;
    }
    iVar16 = (int64_t)((int64_t)puVar7 - *puVar1) >> 2;
    if (iVar16 == 0x3fffffffffffffff) {
        fcn.180010010();
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    uVar6 = (int64_t)((int64_t)*(undefined4 **)(arg1 + 0x50) - *puVar1) >> 2;
    if (uVar6 <= 0x3fffffffffffffff - (uVar6 >> 1)) {
        uVar2 = iVar16 + 1;
        uVar6 = uVar6 + (uVar6 >> 1);
        uVar12 = uVar2;
        if (uVar2 <= uVar6) {
            uVar12 = uVar6;
        }
        if (uVar12 < 0x4000000000000000) {
            uVar6 = uVar12 * 4;
            if (uVar6 == 0) {
                uVar6 = 0;
                puVar10 = auStack_38;
            } else if (uVar6 < 0x1000) {
                uVar6 = fcn.180459890();
            } else {
                if (uVar6 + 0x27 <= uVar6) goto code_r0x0001800d32fa;
                iVar14 = fcn.180459890(uVar6 + 0x27);
                if (iVar14 == 0) {
                    pcVar4 = (code *)swi(0x29);
                    iVar14 = (*pcVar4)(5);
                    puVar9 = auStack_30;
                }
                uVar6 = iVar14 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar6 - 8) = iVar14;
                puVar10 = puVar9;
            }
            *(undefined4 *)(uVar6 + iVar16 * 4) = *(undefined4 *)(arg1 + 0x270);
            puVar3 = (undefined4 *)*puVar1;
            if (puVar7 == *(undefined4 **)(arg1 + 0x48)) {
                iVar14 = (int64_t)*(undefined4 **)(arg1 + 0x48) - (int64_t)puVar3;
                uVar15 = uVar6;
                puVar7 = puVar3;
            } else {
                *(undefined8 *)(puVar10 + -8) = 0x1800d32b0;
                fcn.180498030(uVar6, puVar3, (int64_t)puVar7 - (int64_t)puVar3);
                iVar14 = *(int64_t *)(arg1 + 0x48) - (int64_t)puVar7;
                uVar15 = uVar6 + (iVar16 + 1) * 4;
            }
            *(undefined8 *)(puVar10 + -8) = 0x1800d32c7;
            fcn.180498030(uVar15, puVar7, iVar14);
            uVar13 = *(undefined8 *)(puVar10 + 0x28);
            *(undefined8 *)(puVar10 + 0x30) = *(undefined8 *)(puVar10 + 0x30);
            *(undefined8 *)(puVar10 + 0x28) = *(undefined8 *)(puVar10 + 0x40);
            *(undefined8 *)(puVar10 + 0x20) = uVar13;
            *(undefined8 *)(puVar10 + 0x18) = *(undefined8 *)(puVar10 + 0x48);
            uVar15 = *puVar1;
            if (uVar15 != 0) {
                uVar5 = uVar15;
                puVar8 = puVar10 + -0x10;
                if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x50) - uVar15) >> 2) * 4)) {
                    uVar5 = *(uint64_t *)(uVar15 - 8);
                    uVar15 = (uVar15 - uVar5) - 8;
                    puVar8 = puVar10 + -0x10;
                    if (0x1f < uVar15) {
                        pcVar4 = (code *)swi(0x29);
                        uVar5 = uVar15;
                        (*pcVar4)(5);
                        puVar8 = puVar10 + -8;
                    }
                }
                *(undefined8 *)(puVar8 + -8) = 0x180030d9f;
                fcn.180459c3c(uVar5);
            }
            *puVar1 = uVar6;
            *(uint64_t *)(arg1 + 0x48) = uVar6 + uVar2 * 4;
            *(uint64_t *)(arg1 + 0x50) = uVar6 + uVar12 * 4;
            return;
        }
    }
code_r0x0001800d32fa:
    fcn.180004720();
    pcVar4 = (code *)swi(3);
    (*pcVar4)();
    return;
}

// ============================================================
// Function: FUN_1800b71ac
// Address: 0x1800b71ac
// Size: 107 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_127h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_126h
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch

void fcn.1800b7150(int64_t arg1, int64_t arg2, int64_t arg_70h)
{
    uint64_t *puVar1;
    uint64_t uVar2;
    undefined4 *puVar3;
    code *pcVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined4 *puVar7;
    undefined *puVar8;
    undefined *puVar9;
    undefined *puVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    undefined8 uVar13;
    uint64_t in_R8;
    int64_t iVar14;
    uint8_t in_R9B;
    uint64_t uVar15;
    int64_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t in_stack_00000018;
    int64_t var_20h;
    undefined in_stack_00000028;
    undefined8 auStack_50 [3];
    undefined auStack_38 [8];
    undefined auStack_30 [8];
    int64_t var_28h;
    unkuint7 in_stack_ffffffffffffffe1;
    
    uVar11 = (uint32_t)in_R8 & 0xff;
    if (in_R9B == 0xff) {
        fcn.1800acea0(arg2 + 0xc, 0x18063f9d8);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    iVar16 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782740) {
        iVar16 = arg2;
    }
    if (iVar16 != 0) {
        fcn.1800b0700(arg1, iVar16, in_R8 & 0xff, (uint64_t)in_R9B, CONCAT71(var_28h._1_7_, in_stack_00000028), 
                      (uint64_t)in_stack_ffffffffffffffe1 << 8, in_stack_00000018);
        return;
    }
    iVar16 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x1807826b8) {
        iVar16 = arg2;
    }
    if (iVar16 == 0) {
        fcn.1800b4ce0(arg1, arg2);
        uVar6 = 1;
        if (1 < (uint64_t)in_R9B) {
            do {
                iVar16 = *(int64_t *)arg1;
                var_20h = CONCAT44(var_20h._4_4_, ((int32_t)uVar6 + uVar11 & 0xff) << 8) | 2;
                fcn.1800d31a0(iVar16 + 0x28, &var_20h);
                fcn.1800d31a0(iVar16 + 0x40, iVar16 + 0x270);
                uVar6 = uVar6 + 1;
            } while (uVar6 < in_R9B);
        }
        return;
    }
    if (0 < *(int32_t *)(arg1 + 0xc)) {
        *(int32_t *)(*(int64_t *)arg1 + 0x270) = *(int32_t *)(iVar16 + 0xc) + 1;
    }
    arg1 = *(int64_t *)arg1;
    var_20h = CONCAT44(var_20h._4_4_, ((uint32_t)(uint8_t)(in_R9B + 1) << 8 | uVar11) << 8) | 0x3f;
    fcn.1800d31a0(arg1 + 0x28, &var_20h);
    puVar1 = (uint64_t *)(arg1 + 0x40);
    puVar9 = auStack_38;
    puVar10 = auStack_38;
    puVar7 = *(undefined4 **)(arg1 + 0x48);
    if (puVar7 != *(undefined4 **)(arg1 + 0x50)) {
        *puVar7 = *(undefined4 *)(arg1 + 0x270);
        *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 4;
        return;
    }
    iVar16 = (int64_t)((int64_t)puVar7 - *puVar1) >> 2;
    if (iVar16 == 0x3fffffffffffffff) {
        fcn.180010010();
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    uVar6 = (int64_t)((int64_t)*(undefined4 **)(arg1 + 0x50) - *puVar1) >> 2;
    if (uVar6 <= 0x3fffffffffffffff - (uVar6 >> 1)) {
        uVar2 = iVar16 + 1;
        uVar6 = uVar6 + (uVar6 >> 1);
        uVar12 = uVar2;
        if (uVar2 <= uVar6) {
            uVar12 = uVar6;
        }
        if (uVar12 < 0x4000000000000000) {
            uVar6 = uVar12 * 4;
            if (uVar6 == 0) {
                uVar6 = 0;
                puVar10 = auStack_38;
            } else if (uVar6 < 0x1000) {
                uVar6 = fcn.180459890();
            } else {
                if (uVar6 + 0x27 <= uVar6) goto code_r0x0001800d32fa;
                iVar14 = fcn.180459890(uVar6 + 0x27);
                if (iVar14 == 0) {
                    pcVar4 = (code *)swi(0x29);
                    iVar14 = (*pcVar4)(5);
                    puVar9 = auStack_30;
                }
                uVar6 = iVar14 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar6 - 8) = iVar14;
                puVar10 = puVar9;
            }
            *(undefined4 *)(uVar6 + iVar16 * 4) = *(undefined4 *)(arg1 + 0x270);
            puVar3 = (undefined4 *)*puVar1;
            if (puVar7 == *(undefined4 **)(arg1 + 0x48)) {
                iVar14 = (int64_t)*(undefined4 **)(arg1 + 0x48) - (int64_t)puVar3;
                uVar15 = uVar6;
                puVar7 = puVar3;
            } else {
                *(undefined8 *)(puVar10 + -8) = 0x1800d32b0;
                fcn.180498030(uVar6, puVar3, (int64_t)puVar7 - (int64_t)puVar3);
                iVar14 = *(int64_t *)(arg1 + 0x48) - (int64_t)puVar7;
                uVar15 = uVar6 + (iVar16 + 1) * 4;
            }
            *(undefined8 *)(puVar10 + -8) = 0x1800d32c7;
            fcn.180498030(uVar15, puVar7, iVar14);
            uVar13 = *(undefined8 *)(puVar10 + 0x28);
            *(undefined8 *)(puVar10 + 0x30) = *(undefined8 *)(puVar10 + 0x30);
            *(undefined8 *)(puVar10 + 0x28) = *(undefined8 *)(puVar10 + 0x40);
            *(undefined8 *)(puVar10 + 0x20) = uVar13;
            *(undefined8 *)(puVar10 + 0x18) = *(undefined8 *)(puVar10 + 0x48);
            uVar15 = *puVar1;
            if (uVar15 != 0) {
                uVar5 = uVar15;
                puVar8 = puVar10 + -0x10;
                if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x50) - uVar15) >> 2) * 4)) {
                    uVar5 = *(uint64_t *)(uVar15 - 8);
                    uVar15 = (uVar15 - uVar5) - 8;
                    puVar8 = puVar10 + -0x10;
                    if (0x1f < uVar15) {
                        pcVar4 = (code *)swi(0x29);
                        uVar5 = uVar15;
                        (*pcVar4)(5);
                        puVar8 = puVar10 + -8;
                    }
                }
                *(undefined8 *)(puVar8 + -8) = 0x180030d9f;
                fcn.180459c3c(uVar5);
            }
            *puVar1 = uVar6;
            *(uint64_t *)(arg1 + 0x48) = uVar6 + uVar2 * 4;
            *(uint64_t *)(arg1 + 0x50) = uVar6 + uVar12 * 4;
            return;
        }
    }
code_r0x0001800d32fa:
    fcn.180004720();
    pcVar4 = (code *)swi(3);
    (*pcVar4)();
    return;
}

// ============================================================
// Function: FUN_1800b7217
// Address: 0x1800b7217
// Size: 116 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_127h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_126h
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch

void fcn.1800b7150(int64_t arg1, int64_t arg2, int64_t arg_70h)
{
    uint64_t *puVar1;
    uint64_t uVar2;
    undefined4 *puVar3;
    code *pcVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined4 *puVar7;
    undefined *puVar8;
    undefined *puVar9;
    undefined *puVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    undefined8 uVar13;
    uint64_t in_R8;
    int64_t iVar14;
    uint8_t in_R9B;
    uint64_t uVar15;
    int64_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t in_stack_00000018;
    int64_t var_20h;
    undefined in_stack_00000028;
    undefined8 auStack_50 [3];
    undefined auStack_38 [8];
    undefined auStack_30 [8];
    int64_t var_28h;
    unkuint7 in_stack_ffffffffffffffe1;
    
    uVar11 = (uint32_t)in_R8 & 0xff;
    if (in_R9B == 0xff) {
        fcn.1800acea0(arg2 + 0xc, 0x18063f9d8);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    iVar16 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782740) {
        iVar16 = arg2;
    }
    if (iVar16 != 0) {
        fcn.1800b0700(arg1, iVar16, in_R8 & 0xff, (uint64_t)in_R9B, CONCAT71(var_28h._1_7_, in_stack_00000028), 
                      (uint64_t)in_stack_ffffffffffffffe1 << 8, in_stack_00000018);
        return;
    }
    iVar16 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x1807826b8) {
        iVar16 = arg2;
    }
    if (iVar16 == 0) {
        fcn.1800b4ce0(arg1, arg2);
        uVar6 = 1;
        if (1 < (uint64_t)in_R9B) {
            do {
                iVar16 = *(int64_t *)arg1;
                var_20h = CONCAT44(var_20h._4_4_, ((int32_t)uVar6 + uVar11 & 0xff) << 8) | 2;
                fcn.1800d31a0(iVar16 + 0x28, &var_20h);
                fcn.1800d31a0(iVar16 + 0x40, iVar16 + 0x270);
                uVar6 = uVar6 + 1;
            } while (uVar6 < in_R9B);
        }
        return;
    }
    if (0 < *(int32_t *)(arg1 + 0xc)) {
        *(int32_t *)(*(int64_t *)arg1 + 0x270) = *(int32_t *)(iVar16 + 0xc) + 1;
    }
    arg1 = *(int64_t *)arg1;
    var_20h = CONCAT44(var_20h._4_4_, ((uint32_t)(uint8_t)(in_R9B + 1) << 8 | uVar11) << 8) | 0x3f;
    fcn.1800d31a0(arg1 + 0x28, &var_20h);
    puVar1 = (uint64_t *)(arg1 + 0x40);
    puVar9 = auStack_38;
    puVar10 = auStack_38;
    puVar7 = *(undefined4 **)(arg1 + 0x48);
    if (puVar7 != *(undefined4 **)(arg1 + 0x50)) {
        *puVar7 = *(undefined4 *)(arg1 + 0x270);
        *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 4;
        return;
    }
    iVar16 = (int64_t)((int64_t)puVar7 - *puVar1) >> 2;
    if (iVar16 == 0x3fffffffffffffff) {
        fcn.180010010();
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    uVar6 = (int64_t)((int64_t)*(undefined4 **)(arg1 + 0x50) - *puVar1) >> 2;
    if (uVar6 <= 0x3fffffffffffffff - (uVar6 >> 1)) {
        uVar2 = iVar16 + 1;
        uVar6 = uVar6 + (uVar6 >> 1);
        uVar12 = uVar2;
        if (uVar2 <= uVar6) {
            uVar12 = uVar6;
        }
        if (uVar12 < 0x4000000000000000) {
            uVar6 = uVar12 * 4;
            if (uVar6 == 0) {
                uVar6 = 0;
                puVar10 = auStack_38;
            } else if (uVar6 < 0x1000) {
                uVar6 = fcn.180459890();
            } else {
                if (uVar6 + 0x27 <= uVar6) goto code_r0x0001800d32fa;
                iVar14 = fcn.180459890(uVar6 + 0x27);
                if (iVar14 == 0) {
                    pcVar4 = (code *)swi(0x29);
                    iVar14 = (*pcVar4)(5);
                    puVar9 = auStack_30;
                }
                uVar6 = iVar14 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar6 - 8) = iVar14;
                puVar10 = puVar9;
            }
            *(undefined4 *)(uVar6 + iVar16 * 4) = *(undefined4 *)(arg1 + 0x270);
            puVar3 = (undefined4 *)*puVar1;
            if (puVar7 == *(undefined4 **)(arg1 + 0x48)) {
                iVar14 = (int64_t)*(undefined4 **)(arg1 + 0x48) - (int64_t)puVar3;
                uVar15 = uVar6;
                puVar7 = puVar3;
            } else {
                *(undefined8 *)(puVar10 + -8) = 0x1800d32b0;
                fcn.180498030(uVar6, puVar3, (int64_t)puVar7 - (int64_t)puVar3);
                iVar14 = *(int64_t *)(arg1 + 0x48) - (int64_t)puVar7;
                uVar15 = uVar6 + (iVar16 + 1) * 4;
            }
            *(undefined8 *)(puVar10 + -8) = 0x1800d32c7;
            fcn.180498030(uVar15, puVar7, iVar14);
            uVar13 = *(undefined8 *)(puVar10 + 0x28);
            *(undefined8 *)(puVar10 + 0x30) = *(undefined8 *)(puVar10 + 0x30);
            *(undefined8 *)(puVar10 + 0x28) = *(undefined8 *)(puVar10 + 0x40);
            *(undefined8 *)(puVar10 + 0x20) = uVar13;
            *(undefined8 *)(puVar10 + 0x18) = *(undefined8 *)(puVar10 + 0x48);
            uVar15 = *puVar1;
            if (uVar15 != 0) {
                uVar5 = uVar15;
                puVar8 = puVar10 + -0x10;
                if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x50) - uVar15) >> 2) * 4)) {
                    uVar5 = *(uint64_t *)(uVar15 - 8);
                    uVar15 = (uVar15 - uVar5) - 8;
                    puVar8 = puVar10 + -0x10;
                    if (0x1f < uVar15) {
                        pcVar4 = (code *)swi(0x29);
                        uVar5 = uVar15;
                        (*pcVar4)(5);
                        puVar8 = puVar10 + -8;
                    }
                }
                *(undefined8 *)(puVar8 + -8) = 0x180030d9f;
                fcn.180459c3c(uVar5);
            }
            *puVar1 = uVar6;
            *(uint64_t *)(arg1 + 0x48) = uVar6 + uVar2 * 4;
            *(uint64_t *)(arg1 + 0x50) = uVar6 + uVar12 * 4;
            return;
        }
    }
code_r0x0001800d32fa:
    fcn.180004720();
    pcVar4 = (code *)swi(3);
    (*pcVar4)();
    return;
}

// ============================================================
// Function: FUN_1800b728b
// Address: 0x1800b728b
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_127h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_126h
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch

void fcn.1800b7150(int64_t arg1, int64_t arg2, int64_t arg_70h)
{
    uint64_t *puVar1;
    uint64_t uVar2;
    undefined4 *puVar3;
    code *pcVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined4 *puVar7;
    undefined *puVar8;
    undefined *puVar9;
    undefined *puVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    undefined8 uVar13;
    uint64_t in_R8;
    int64_t iVar14;
    uint8_t in_R9B;
    uint64_t uVar15;
    int64_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t in_stack_00000018;
    int64_t var_20h;
    undefined in_stack_00000028;
    undefined8 auStack_50 [3];
    undefined auStack_38 [8];
    undefined auStack_30 [8];
    int64_t var_28h;
    unkuint7 in_stack_ffffffffffffffe1;
    
    uVar11 = (uint32_t)in_R8 & 0xff;
    if (in_R9B == 0xff) {
        fcn.1800acea0(arg2 + 0xc, 0x18063f9d8);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    iVar16 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782740) {
        iVar16 = arg2;
    }
    if (iVar16 != 0) {
        fcn.1800b0700(arg1, iVar16, in_R8 & 0xff, (uint64_t)in_R9B, CONCAT71(var_28h._1_7_, in_stack_00000028), 
                      (uint64_t)in_stack_ffffffffffffffe1 << 8, in_stack_00000018);
        return;
    }
    iVar16 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x1807826b8) {
        iVar16 = arg2;
    }
    if (iVar16 == 0) {
        fcn.1800b4ce0(arg1, arg2);
        uVar6 = 1;
        if (1 < (uint64_t)in_R9B) {
            do {
                iVar16 = *(int64_t *)arg1;
                var_20h = CONCAT44(var_20h._4_4_, ((int32_t)uVar6 + uVar11 & 0xff) << 8) | 2;
                fcn.1800d31a0(iVar16 + 0x28, &var_20h);
                fcn.1800d31a0(iVar16 + 0x40, iVar16 + 0x270);
                uVar6 = uVar6 + 1;
            } while (uVar6 < in_R9B);
        }
        return;
    }
    if (0 < *(int32_t *)(arg1 + 0xc)) {
        *(int32_t *)(*(int64_t *)arg1 + 0x270) = *(int32_t *)(iVar16 + 0xc) + 1;
    }
    arg1 = *(int64_t *)arg1;
    var_20h = CONCAT44(var_20h._4_4_, ((uint32_t)(uint8_t)(in_R9B + 1) << 8 | uVar11) << 8) | 0x3f;
    fcn.1800d31a0(arg1 + 0x28, &var_20h);
    puVar1 = (uint64_t *)(arg1 + 0x40);
    puVar9 = auStack_38;
    puVar10 = auStack_38;
    puVar7 = *(undefined4 **)(arg1 + 0x48);
    if (puVar7 != *(undefined4 **)(arg1 + 0x50)) {
        *puVar7 = *(undefined4 *)(arg1 + 0x270);
        *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 4;
        return;
    }
    iVar16 = (int64_t)((int64_t)puVar7 - *puVar1) >> 2;
    if (iVar16 == 0x3fffffffffffffff) {
        fcn.180010010();
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    uVar6 = (int64_t)((int64_t)*(undefined4 **)(arg1 + 0x50) - *puVar1) >> 2;
    if (uVar6 <= 0x3fffffffffffffff - (uVar6 >> 1)) {
        uVar2 = iVar16 + 1;
        uVar6 = uVar6 + (uVar6 >> 1);
        uVar12 = uVar2;
        if (uVar2 <= uVar6) {
            uVar12 = uVar6;
        }
        if (uVar12 < 0x4000000000000000) {
            uVar6 = uVar12 * 4;
            if (uVar6 == 0) {
                uVar6 = 0;
                puVar10 = auStack_38;
            } else if (uVar6 < 0x1000) {
                uVar6 = fcn.180459890();
            } else {
                if (uVar6 + 0x27 <= uVar6) goto code_r0x0001800d32fa;
                iVar14 = fcn.180459890(uVar6 + 0x27);
                if (iVar14 == 0) {
                    pcVar4 = (code *)swi(0x29);
                    iVar14 = (*pcVar4)(5);
                    puVar9 = auStack_30;
                }
                uVar6 = iVar14 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar6 - 8) = iVar14;
                puVar10 = puVar9;
            }
            *(undefined4 *)(uVar6 + iVar16 * 4) = *(undefined4 *)(arg1 + 0x270);
            puVar3 = (undefined4 *)*puVar1;
            if (puVar7 == *(undefined4 **)(arg1 + 0x48)) {
                iVar14 = (int64_t)*(undefined4 **)(arg1 + 0x48) - (int64_t)puVar3;
                uVar15 = uVar6;
                puVar7 = puVar3;
            } else {
                *(undefined8 *)(puVar10 + -8) = 0x1800d32b0;
                fcn.180498030(uVar6, puVar3, (int64_t)puVar7 - (int64_t)puVar3);
                iVar14 = *(int64_t *)(arg1 + 0x48) - (int64_t)puVar7;
                uVar15 = uVar6 + (iVar16 + 1) * 4;
            }
            *(undefined8 *)(puVar10 + -8) = 0x1800d32c7;
            fcn.180498030(uVar15, puVar7, iVar14);
            uVar13 = *(undefined8 *)(puVar10 + 0x28);
            *(undefined8 *)(puVar10 + 0x30) = *(undefined8 *)(puVar10 + 0x30);
            *(undefined8 *)(puVar10 + 0x28) = *(undefined8 *)(puVar10 + 0x40);
            *(undefined8 *)(puVar10 + 0x20) = uVar13;
            *(undefined8 *)(puVar10 + 0x18) = *(undefined8 *)(puVar10 + 0x48);
            uVar15 = *puVar1;
            if (uVar15 != 0) {
                uVar5 = uVar15;
                puVar8 = puVar10 + -0x10;
                if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x50) - uVar15) >> 2) * 4)) {
                    uVar5 = *(uint64_t *)(uVar15 - 8);
                    uVar15 = (uVar15 - uVar5) - 8;
                    puVar8 = puVar10 + -0x10;
                    if (0x1f < uVar15) {
                        pcVar4 = (code *)swi(0x29);
                        uVar5 = uVar15;
                        (*pcVar4)(5);
                        puVar8 = puVar10 + -8;
                    }
                }
                *(undefined8 *)(puVar8 + -8) = 0x180030d9f;
                fcn.180459c3c(uVar5);
            }
            *puVar1 = uVar6;
            *(uint64_t *)(arg1 + 0x48) = uVar6 + uVar2 * 4;
            *(uint64_t *)(arg1 + 0x50) = uVar6 + uVar12 * 4;
            return;
        }
    }
code_r0x0001800d32fa:
    fcn.180004720();
    pcVar4 = (code *)swi(3);
    (*pcVar4)();
    return;
}

// ============================================================
// Function: FUN_1800b72a0
// Address: 0x1800b72a0
// Size: 509 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Detected overlap for variable var_127h
// WARNING: [rz-ghidra] Detected overlap for variable var_126h
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_124h

void fcn.1800b72a0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h)
{
    uint64_t *puVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    code *pcVar5;
    char cVar6;
    uint64_t uVar7;
    undefined4 *puVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    undefined *puVar12;
    undefined *puVar13;
    undefined *puVar14;
    undefined8 uVar15;
    uint64_t unaff_RDI;
    int64_t iVar16;
    uint8_t uVar17;
    uint64_t uVar18;
    undefined8 unaff_R14;
    int64_t iVar19;
    int64_t in_stack_00000018;
    int64_t var_20h;
    undefined8 uStack_50;
    int64_t var_48h;
    int64_t var_40h;
    undefined auStack_38 [8];
    
    uVar9 = (uint64_t)(uint8_t)placeholder_3;
    uVar10 = *(uint64_t *)(arg2 + 8);
    if (uVar10 == uVar9) {
        uVar9 = 0;
        if (uVar10 != 0) {
            do {
                fcn.1800b4ce0(arg1, *(int64_t *)(*(int64_t *)arg2 + uVar9 * 8));
                uVar9 = uVar9 + 1;
            } while (uVar9 < *(uint64_t *)(arg2 + 8));
            return;
        }
    } else if (uVar9 < uVar10) {
        uVar10 = 0;
        if ((uint8_t)placeholder_3 != 0) {
            do {
                fcn.1800b4ce0(arg1, *(int64_t *)(*(int64_t *)arg2 + uVar10 * 8));
                uVar10 = uVar10 + 1;
            } while (uVar10 < uVar9);
        }
        if (uVar9 < *(uint64_t *)(arg2 + 8)) {
            do {
                iVar19 = *(int64_t *)(*(int64_t *)arg2 + uVar9 * 8);
                iVar2 = *(int32_t *)(iVar19 + 8);
                if ((((iVar2 != *(int32_t *)0x180782728) && (iVar2 != *(int32_t *)0x180782738)) &&
                    (iVar2 != *(int32_t *)0x1807826b8)) &&
                   ((iVar2 != *(int32_t *)0x1807826a0 && (cVar6 = fcn.1800b2930(arg1, iVar19), cVar6 == '\0')))) {
                    if (iVar2 != *(int32_t *)0x180782740) {
                        fcn.1800d0a10(*(undefined8 *)arg1, 0x18063f9a8);
                    }
                    uVar3 = *(undefined4 *)(arg1 + 0x60c);
                    fcn.1800b7030(arg1, iVar19, arg1);
                    *(undefined4 *)(arg1 + 0x60c) = uVar3;
                }
                uVar9 = uVar9 + 1;
            } while (uVar9 < *(uint64_t *)(arg2 + 8));
            return;
        }
    } else {
        uVar11 = 0;
        if (uVar10 != 0) {
            if (uVar10 != 1) {
                do {
                    fcn.1800b4ce0(arg1, *(int64_t *)(*(int64_t *)arg2 + uVar11 * 8));
                    uVar11 = uVar11 + 1;
                    uVar10 = *(uint64_t *)(arg2 + 8);
                } while (uVar11 < uVar10 - 1);
            }
            cVar6 = (uint8_t)placeholder_3 - (char)uVar10;
            uVar17 = cVar6 + 1;
            placeholder_2._0_1_ = (char)uVar10 + -1 + (uint8_t)placeholder_2;
            iVar19 = *(int64_t *)(*(int64_t *)arg2 + -8 + uVar10 * 8);
            if (uVar17 == 0xff) {
                fcn.1800acea0(iVar19 + 0xc, 0x18063f9d8);
                pcVar5 = (code *)swi(3);
                (*pcVar5)();
                return;
            }
            iVar16 = 0;
            if (*(int32_t *)(iVar19 + 8) == *(int32_t *)0x180782740) {
                iVar16 = iVar19;
            }
            if (iVar16 != 0) {
                fcn.1800b0700(arg1, iVar16, (uint64_t)(uint8_t)placeholder_2, (uint64_t)uVar17, 
                              CONCAT71((unkint7)((uint64_t)unaff_R14 >> 8), (undefined)arg_28h), 
                              unaff_RDI & 0xffffffffffffff00, in_stack_00000018);
                return;
            }
            iVar16 = 0;
            if (*(int32_t *)(iVar19 + 8) == *(int32_t *)0x1807826b8) {
                iVar16 = iVar19;
            }
            if (iVar16 == 0) {
                fcn.1800b4ce0(arg1, iVar19);
                uVar10 = 1;
                if (uVar17 != 0 && (uint64_t)uVar17 != 1) {
                    do {
                        iVar19 = *(int64_t *)arg1;
                        var_20h = CONCAT44(var_20h._4_4_, 
                                           ((int32_t)uVar10 + (uint32_t)(uint8_t)placeholder_2 & 0xff) << 8) | 2;
                        fcn.1800d31a0(iVar19 + 0x28, &var_20h);
                        fcn.1800d31a0(iVar19 + 0x40, iVar19 + 0x270);
                        uVar10 = uVar10 + 1;
                    } while (uVar10 < uVar17);
                }
                return;
            }
            if (0 < *(int32_t *)(arg1 + 0xc)) {
                *(int32_t *)(*(int64_t *)arg1 + 0x270) = *(int32_t *)(iVar16 + 0xc) + 1;
            }
            arg1 = *(int64_t *)arg1;
            var_20h = CONCAT44(var_20h._4_4_, (uint32_t)CONCAT11(cVar6 + '\x02', (uint8_t)placeholder_2) << 8) | 0x3f;
            fcn.1800d31a0(arg1 + 0x28, &var_20h);
            puVar1 = (uint64_t *)(arg1 + 0x40);
            puVar13 = auStack_38;
            puVar14 = auStack_38;
            puVar8 = *(undefined4 **)(arg1 + 0x48);
            if (puVar8 != *(undefined4 **)(arg1 + 0x50)) {
                *puVar8 = *(undefined4 *)(arg1 + 0x270);
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 4;
                return;
            }
            iVar19 = (int64_t)((int64_t)puVar8 - *puVar1) >> 2;
            if (iVar19 == 0x3fffffffffffffff) {
                fcn.180010010();
                pcVar5 = (code *)swi(3);
                (*pcVar5)();
                return;
            }
            uVar10 = (int64_t)((int64_t)*(undefined4 **)(arg1 + 0x50) - *puVar1) >> 2;
            if (uVar10 <= 0x3fffffffffffffff - (uVar10 >> 1)) {
                uVar9 = iVar19 + 1;
                uVar10 = uVar10 + (uVar10 >> 1);
                uVar11 = uVar9;
                if (uVar9 <= uVar10) {
                    uVar11 = uVar10;
                }
                if (uVar11 < 0x4000000000000000) {
                    uVar10 = uVar11 * 4;
                    if (uVar10 == 0) {
                        uVar10 = 0;
                        puVar14 = auStack_38;
                    } else if (uVar10 < 0x1000) {
                        uVar10 = fcn.180459890();
                    } else {
                        if (uVar10 + 0x27 <= uVar10) goto code_r0x0001800d32fa;
                        iVar16 = fcn.180459890(uVar10 + 0x27);
                        if (iVar16 == 0) {
                            pcVar5 = (code *)swi(0x29);
                            iVar16 = (*pcVar5)(5);
                            puVar13 = &stack0xffffffffffffffd0;
                        }
                        uVar10 = iVar16 + 0x27U & 0xffffffffffffffe0;
                        *(int64_t *)(uVar10 - 8) = iVar16;
                        puVar14 = puVar13;
                    }
                    *(undefined4 *)(uVar10 + iVar19 * 4) = *(undefined4 *)(arg1 + 0x270);
                    puVar4 = (undefined4 *)*puVar1;
                    if (puVar8 == *(undefined4 **)(arg1 + 0x48)) {
                        iVar16 = (int64_t)*(undefined4 **)(arg1 + 0x48) - (int64_t)puVar4;
                        uVar18 = uVar10;
                        puVar8 = puVar4;
                    } else {
                        *(undefined8 *)(puVar14 + -8) = 0x1800d32b0;
                        fcn.180498030(uVar10, puVar4, (int64_t)puVar8 - (int64_t)puVar4);
                        iVar16 = *(int64_t *)(arg1 + 0x48) - (int64_t)puVar8;
                        uVar18 = uVar10 + (iVar19 + 1) * 4;
                    }
                    *(undefined8 *)(puVar14 + -8) = 0x1800d32c7;
                    fcn.180498030(uVar18, puVar8, iVar16);
                    uVar15 = *(undefined8 *)(puVar14 + 0x28);
                    *(undefined8 *)(puVar14 + 0x30) = *(undefined8 *)(puVar14 + 0x30);
                    *(undefined8 *)(puVar14 + 0x28) = *(undefined8 *)(puVar14 + 0x40);
                    *(undefined8 *)(puVar14 + 0x20) = uVar15;
                    *(undefined8 *)(puVar14 + 0x18) = *(undefined8 *)(puVar14 + 0x48);
                    uVar18 = *puVar1;
                    if (uVar18 != 0) {
                        uVar7 = uVar18;
                        puVar12 = puVar14 + -0x10;
                        if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x50) - uVar18) >> 2) * 4)) {
                            uVar7 = *(uint64_t *)(uVar18 - 8);
                            uVar18 = (uVar18 - uVar7) - 8;
                            puVar12 = puVar14 + -0x10;
                            if (0x1f < uVar18) {
                                pcVar5 = (code *)swi(0x29);
                                uVar7 = uVar18;
                                (*pcVar5)(5);
                                puVar12 = puVar14 + -8;
                            }
                        }
                        *(undefined8 *)(puVar12 + -8) = 0x180030d9f;
                        fcn.180459c3c(uVar7);
                    }
                    *puVar1 = uVar10;
                    *(uint64_t *)(arg1 + 0x48) = uVar10 + uVar9 * 4;
                    *(uint64_t *)(arg1 + 0x50) = uVar10 + uVar11 * 4;
                    return;
                }
            }
code_r0x0001800d32fa:
            fcn.180004720();
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        if ((uint8_t)placeholder_3 != 0) {
            do {
                iVar19 = *(int64_t *)arg1;
                var_20h = CONCAT44(var_20h._4_4_, ((uint32_t)(uint8_t)placeholder_2 + (int32_t)uVar11 & 0xff) << 8) | 2;
                fcn.1800d31a0(iVar19 + 0x28, &var_20h);
                fcn.1800d31a0(iVar19 + 0x40, iVar19 + 0x270);
                uVar11 = uVar11 + 1;
            } while (uVar11 < uVar9);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800b74a0
// Address: 0x1800b74a0
// Size: 238 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_44h

int64_t fcn.1800b74a0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined uVar4;
    int64_t var_48h;
    int64_t var_40h;
    int64_t in_stack_ffffffffffffffc8;
    
    fcn.1800b29d0(arg1, (int64_t)&var_48h, arg4);
    if (((((int32_t)var_48h != 3) || ((double)var_40h < 1.0)) || (256.0 < (double)var_40h)) ||
       ((double)(int32_t)(double)var_40h != (double)var_40h)) {
        if ((int32_t)var_48h == 6) {
            *(undefined8 *)arg2 = 3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            *(undefined8 *)(arg2 + 0x20) = 0;
            *(int64_t *)(arg2 + 8) = var_40h;
            *(uint64_t *)(arg2 + 0x10) = (uint64_t)var_48h._4_4_;
            *(undefined *)(arg2 + 4) = (undefined)placeholder_2;
        } else {
            *(undefined8 *)arg2 = 5;
            *(undefined8 *)(arg2 + 8) = 0;
            *(undefined8 *)(arg2 + 0x10) = 0;
            *(undefined8 *)(arg2 + 0x18) = 0;
            *(undefined8 *)(arg2 + 0x20) = 0;
            *(undefined *)(arg2 + 4) = (undefined)placeholder_2;
            uVar4 = fcn.1800b7030(arg1, arg4, in_stack_ffffffffffffffc8);
            *(undefined *)(arg2 + 6) = uVar4;
        }
    } else {
        *(undefined8 *)arg2 = 4;
        *(undefined8 *)(arg2 + 8) = 0;
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0;
        *(undefined8 *)(arg2 + 0x20) = 0;
        *(undefined *)(arg2 + 4) = (undefined)placeholder_2;
        *(char *)(arg2 + 7) = (char)(int32_t)(double)var_40h + -1;
    }
    uVar1 = *(undefined4 *)(arg4 + 0x10);
    uVar2 = *(undefined4 *)(arg4 + 0x14);
    uVar3 = *(undefined4 *)(arg4 + 0x18);
    *(undefined4 *)(arg2 + 0x18) = *(undefined4 *)(arg4 + 0xc);
    *(undefined4 *)(arg2 + 0x1c) = uVar1;
    *(undefined4 *)(arg2 + 0x20) = uVar2;
    *(undefined4 *)(arg2 + 0x24) = uVar3;
    return arg2;
}

// ============================================================
// Function: FUN_1800b7590
// Address: 0x1800b7590
// Size: 90 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_44h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_43h
// WARNING: [rz-ghidra] Detected overlap for variable var_41h
// WARNING: [rz-ghidra] Detected overlap for variable var_42h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h

int64_t fcn.1800b7590(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    int64_t *piVar2;
    undefined8 uVar3;
    undefined auVar4 [16];
    undefined uVar5;
    uint8_t uVar6;
    int32_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int64_t iVar10;
    int32_t iVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    uint32_t uStack_48;
    int64_t var_44h;
    
    piVar1 = (int32_t *)(arg3 + 0xc);
    if (0 < *(int32_t *)(arg1 + 0xc)) {
        *(int32_t *)(*(int64_t *)arg1 + 0x270) = *piVar1 + 1;
    }
    iVar11 = *(int32_t *)(arg3 + 8);
    iVar10 = 0;
    iVar9 = iVar10;
    if (iVar11 == *(int32_t *)0x180782728) {
        iVar9 = arg3;
    }
    if (iVar9 == 0) {
        iVar9 = iVar10;
        if (iVar11 == *(int32_t *)0x180782738) {
            iVar9 = arg3;
        }
        if (iVar9 == 0) {
            iVar9 = iVar10;
            if (iVar11 == *(int32_t *)0x18078269c) {
                iVar9 = arg3;
            }
            if (iVar9 != 0) {
                uVar5 = fcn.1800b7030(arg1, *(int64_t *)(iVar9 + 0x20), (uint64_t)uStack_48);
                uVar3 = *(undefined8 *)(iVar9 + 0x28);
                uVar8 = func_0x000180498cd0(uVar3);
                iVar11 = *piVar1;
                uVar12 = *(undefined4 *)(arg3 + 0x10);
                uVar13 = *(undefined4 *)(arg3 + 0x14);
                uVar14 = *(undefined4 *)(arg3 + 0x18);
                *(undefined2 *)(arg2 + 5) = 0;
                *(undefined *)(arg2 + 7) = 0;
                *(undefined4 *)arg2 = 3;
                *(undefined *)(arg2 + 4) = uVar5;
                *(undefined8 *)(arg2 + 8) = uVar3;
                *(undefined8 *)(arg2 + 0x10) = uVar8;
                *(int32_t *)(arg2 + 0x18) = iVar11;
                *(undefined4 *)(arg2 + 0x1c) = uVar12;
                *(undefined4 *)(arg2 + 0x20) = uVar13;
                *(undefined4 *)(arg2 + 0x24) = uVar14;
                return arg2;
            }
            if (iVar11 == *(int32_t *)0x180782730) {
                iVar10 = arg3;
            }
            if (iVar10 != 0) {
                uVar6 = fcn.1800b7030(arg1, *(int64_t *)(iVar10 + 0x20), 
                                      CONCAT17(var_44h._3_1_, 
                                               CONCAT16(var_44h._2_1_, 
                                                        CONCAT15(var_44h._1_1_, CONCAT14((undefined)var_44h, uStack_48))
                                                       )));
                fcn.1800b74a0(arg1, arg2, (uint64_t)uVar6, *(int64_t *)(iVar10 + 0x28));
                return arg2;
            }
            *(undefined8 *)arg2 = 0;
            *(undefined8 *)(arg2 + 8) = 0;
            *(undefined8 *)(arg2 + 0x10) = 0;
            *(undefined8 *)(arg2 + 0x18) = 0;
            *(undefined8 *)(arg2 + 0x20) = 0;
            return arg2;
        }
        uVar3 = *(undefined8 *)(iVar9 + 0x20);
        uVar8 = func_0x000180498cd0(uVar3);
        iVar11 = *piVar1;
        uVar12 = *(undefined4 *)(arg3 + 0x10);
        uVar13 = *(undefined4 *)(arg3 + 0x14);
        uVar14 = *(undefined4 *)(arg3 + 0x18);
        *(undefined8 *)arg2 = 2;
        *(undefined8 *)(arg2 + 8) = uVar3;
        *(undefined8 *)(arg2 + 0x10) = uVar8;
    } else {
        piVar2 = (int64_t *)(iVar9 + 0x20);
        if ((*(char *)0x180778520 == '\0') || (*(char *)(*piVar2 + 0x31) == '\0')) {
            iVar7 = fcn.1800b7be0();
            if (iVar7 < 0) {
                uVar5 = fcn.1800ad020(arg1, *piVar2);
                iVar11 = *piVar1;
                uVar12 = *(undefined4 *)(arg3 + 0x10);
                uVar13 = *(undefined4 *)(arg3 + 0x14);
                uVar14 = *(undefined4 *)(arg3 + 0x18);
                *(undefined *)(arg2 + 5) = uVar5;
                *(undefined2 *)(arg2 + 6) = 0;
                *(undefined4 *)arg2 = 1;
                *(undefined *)(arg2 + 4) = 0;
            } else {
                iVar11 = *piVar1;
                uVar12 = *(undefined4 *)(arg3 + 0x10);
                uVar13 = *(undefined4 *)(arg3 + 0x14);
                uVar14 = *(undefined4 *)(arg3 + 0x18);
                *(char *)(arg2 + 4) = (char)iVar7;
                *(undefined2 *)(arg2 + 5) = 0;
                *(undefined *)(arg2 + 7) = 0;
                *(undefined4 *)arg2 = 0;
            }
            *(undefined8 *)(arg2 + 8) = 0;
            *(undefined8 *)(arg2 + 0x10) = 0;
        } else {
            uVar5 = fcn.1800ad390(arg1, arg3);
            uVar3 = *(undefined8 *)*piVar2;
            uVar8 = func_0x000180498cd0(uVar3);
            iVar11 = *piVar1;
            uVar12 = *(undefined4 *)(arg3 + 0x10);
            uVar13 = *(undefined4 *)(arg3 + 0x14);
            uVar14 = *(undefined4 *)(arg3 + 0x18);
            *(undefined2 *)(arg2 + 5) = 0;
            *(undefined *)(arg2 + 7) = 0;
            *(undefined4 *)arg2 = 3;
            *(undefined *)(arg2 + 4) = uVar5;
            *(undefined8 *)(arg2 + 8) = uVar3;
            *(undefined8 *)(arg2 + 0x10) = uVar8;
        }
    }
    auVar4._4_4_ = uVar12;
    auVar4._0_4_ = iVar11;
    auVar4._8_4_ = uVar13;
    auVar4._12_4_ = uVar14;
    *(undefined (*) [16])(arg2 + 0x18) = auVar4;
    return arg2;
}

// ============================================================
// Function: FUN_1800b75ea
// Address: 0x1800b75ea
// Size: 152 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_44h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_43h
// WARNING: [rz-ghidra] Detected overlap for variable var_41h
// WARNING: [rz-ghidra] Detected overlap for variable var_42h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h

int64_t fcn.1800b7590(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    int64_t *piVar2;
    undefined8 uVar3;
    undefined auVar4 [16];
    undefined uVar5;
    uint8_t uVar6;
    int32_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int64_t iVar10;
    int32_t iVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    uint32_t uStack_48;
    int64_t var_44h;
    
    piVar1 = (int32_t *)(arg3 + 0xc);
    if (0 < *(int32_t *)(arg1 + 0xc)) {
        *(int32_t *)(*(int64_t *)arg1 + 0x270) = *piVar1 + 1;
    }
    iVar11 = *(int32_t *)(arg3 + 8);
    iVar10 = 0;
    iVar9 = iVar10;
    if (iVar11 == *(int32_t *)0x180782728) {
        iVar9 = arg3;
    }
    if (iVar9 == 0) {
        iVar9 = iVar10;
        if (iVar11 == *(int32_t *)0x180782738) {
            iVar9 = arg3;
        }
        if (iVar9 == 0) {
            iVar9 = iVar10;
            if (iVar11 == *(int32_t *)0x18078269c) {
                iVar9 = arg3;
            }
            if (iVar9 != 0) {
                uVar5 = fcn.1800b7030(arg1, *(int64_t *)(iVar9 + 0x20), (uint64_t)uStack_48);
                uVar3 = *(undefined8 *)(iVar9 + 0x28);
                uVar8 = func_0x000180498cd0(uVar3);
                iVar11 = *piVar1;
                uVar12 = *(undefined4 *)(arg3 + 0x10);
                uVar13 = *(undefined4 *)(arg3 + 0x14);
                uVar14 = *(undefined4 *)(arg3 + 0x18);
                *(undefined2 *)(arg2 + 5) = 0;
                *(undefined *)(arg2 + 7) = 0;
                *(undefined4 *)arg2 = 3;
                *(undefined *)(arg2 + 4) = uVar5;
                *(undefined8 *)(arg2 + 8) = uVar3;
                *(undefined8 *)(arg2 + 0x10) = uVar8;
                *(int32_t *)(arg2 + 0x18) = iVar11;
                *(undefined4 *)(arg2 + 0x1c) = uVar12;
                *(undefined4 *)(arg2 + 0x20) = uVar13;
                *(undefined4 *)(arg2 + 0x24) = uVar14;
                return arg2;
            }
            if (iVar11 == *(int32_t *)0x180782730) {
                iVar10 = arg3;
            }
            if (iVar10 != 0) {
                uVar6 = fcn.1800b7030(arg1, *(int64_t *)(iVar10 + 0x20), 
                                      CONCAT17(var_44h._3_1_, 
                                               CONCAT16(var_44h._2_1_, 
                                                        CONCAT15(var_44h._1_1_, CONCAT14((undefined)var_44h, uStack_48))
                                                       )));
                fcn.1800b74a0(arg1, arg2, (uint64_t)uVar6, *(int64_t *)(iVar10 + 0x28));
                return arg2;
            }
            *(undefined8 *)arg2 = 0;
            *(undefined8 *)(arg2 + 8) = 0;
            *(undefined8 *)(arg2 + 0x10) = 0;
            *(undefined8 *)(arg2 + 0x18) = 0;
            *(undefined8 *)(arg2 + 0x20) = 0;
            return arg2;
        }
        uVar3 = *(undefined8 *)(iVar9 + 0x20);
        uVar8 = func_0x000180498cd0(uVar3);
        iVar11 = *piVar1;
        uVar12 = *(undefined4 *)(arg3 + 0x10);
        uVar13 = *(undefined4 *)(arg3 + 0x14);
        uVar14 = *(undefined4 *)(arg3 + 0x18);
        *(undefined8 *)arg2 = 2;
        *(undefined8 *)(arg2 + 8) = uVar3;
        *(undefined8 *)(arg2 + 0x10) = uVar8;
    } else {
        piVar2 = (int64_t *)(iVar9 + 0x20);
        if ((*(char *)0x180778520 == '\0') || (*(char *)(*piVar2 + 0x31) == '\0')) {
            iVar7 = fcn.1800b7be0();
            if (iVar7 < 0) {
                uVar5 = fcn.1800ad020(arg1, *piVar2);
                iVar11 = *piVar1;
                uVar12 = *(undefined4 *)(arg3 + 0x10);
                uVar13 = *(undefined4 *)(arg3 + 0x14);
                uVar14 = *(undefined4 *)(arg3 + 0x18);
                *(undefined *)(arg2 + 5) = uVar5;
                *(undefined2 *)(arg2 + 6) = 0;
                *(undefined4 *)arg2 = 1;
                *(undefined *)(arg2 + 4) = 0;
            } else {
                iVar11 = *piVar1;
                uVar12 = *(undefined4 *)(arg3 + 0x10);
                uVar13 = *(undefined4 *)(arg3 + 0x14);
                uVar14 = *(undefined4 *)(arg3 + 0x18);
                *(char *)(arg2 + 4) = (char)iVar7;
                *(undefined2 *)(arg2 + 5) = 0;
                *(undefined *)(arg2 + 7) = 0;
                *(undefined4 *)arg2 = 0;
            }
            *(undefined8 *)(arg2 + 8) = 0;
            *(undefined8 *)(arg2 + 0x10) = 0;
        } else {
            uVar5 = fcn.1800ad390(arg1, arg3);
            uVar3 = *(undefined8 *)*piVar2;
            uVar8 = func_0x000180498cd0(uVar3);
            iVar11 = *piVar1;
            uVar12 = *(undefined4 *)(arg3 + 0x10);
            uVar13 = *(undefined4 *)(arg3 + 0x14);
            uVar14 = *(undefined4 *)(arg3 + 0x18);
            *(undefined2 *)(arg2 + 5) = 0;
            *(undefined *)(arg2 + 7) = 0;
            *(undefined4 *)arg2 = 3;
            *(undefined *)(arg2 + 4) = uVar5;
            *(undefined8 *)(arg2 + 8) = uVar3;
            *(undefined8 *)(arg2 + 0x10) = uVar8;
        }
    }
    auVar4._4_4_ = uVar12;
    auVar4._0_4_ = iVar11;
    auVar4._8_4_ = uVar13;
    auVar4._12_4_ = uVar14;
    *(undefined (*) [16])(arg2 + 0x18) = auVar4;
    return arg2;
}

