// Chunk 68 - 50 functions

// ============================================================
// Function: FUN_1800d5b70
// Address: 0x1800d5b70
// Size: 65 bytes
// ============================================================
void fcn.1800d5b70(int64_t arg_28h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t *unaff_RBX;
    int32_t *unaff_RDI;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_20h;
    
    do {
        var_20h = (int64_t)&arg_48h;
        (**(code **)((int64_t)*unaff_RBX * 8 + 0x180641b58))(&var_20h, unaff_RBX + 2, in_R8, in_R9, var_20h);
        unaff_RBX = unaff_RBX + 0x14;
    } while (unaff_RBX != unaff_RDI);
    return;
}

// ============================================================
// Function: FUN_1800d5bb1
// Address: 0x1800d5bb1
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: arg_50h

void fcn.1800d5b70(int64_t arg_28h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t *unaff_RBX;
    int32_t *unaff_RDI;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_20h;
    
    do {
        var_20h = (int64_t)&arg_48h;
        (**(code **)((int64_t)*unaff_RBX * 8 + 0x180641b58))(&var_20h, unaff_RBX + 2, in_R8, in_R9, var_20h);
        unaff_RBX = unaff_RBX + 0x14;
    } while (unaff_RBX != unaff_RDI);
    return;
}

// ============================================================
// Function: FUN_1800d5bb6
// Address: 0x1800d5bb6
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: arg_50h

void fcn.1800d5b70(int64_t arg_28h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t *unaff_RBX;
    int32_t *unaff_RDI;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_20h;
    
    do {
        var_20h = (int64_t)&arg_48h;
        (**(code **)((int64_t)*unaff_RBX * 8 + 0x180641b58))(&var_20h, unaff_RBX + 2, in_R8, in_R9, var_20h);
        unaff_RBX = unaff_RBX + 0x14;
    } while (unaff_RBX != unaff_RDI);
    return;
}

// ============================================================
// Function: FUN_1800d5bc0
// Address: 0x1800d5bc0
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800d5bc0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0xa8))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x70);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x78);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
        puVar1 = *(undefined8 **)(arg1 + 0x80);
        if (puVar1 != (undefined8 *)0x0) {
            (**(code **)*puVar1)(puVar1, arg2);
        }
        (**(code **)**(undefined8 **)(arg1 + 0xb0))(*(undefined8 **)(arg1 + 0xb0), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d5be7
// Address: 0x1800d5be7
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800d5bc0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0xa8))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x70);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x78);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
        puVar1 = *(undefined8 **)(arg1 + 0x80);
        if (puVar1 != (undefined8 *)0x0) {
            (**(code **)*puVar1)(puVar1, arg2);
        }
        (**(code **)**(undefined8 **)(arg1 + 0xb0))(*(undefined8 **)(arg1 + 0xb0), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d5c2a
// Address: 0x1800d5c2a
// Size: 34 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800d5bc0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0xa8))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x70);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x78);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
        puVar1 = *(undefined8 **)(arg1 + 0x80);
        if (puVar1 != (undefined8 *)0x0) {
            (**(code **)*puVar1)(puVar1, arg2);
        }
        (**(code **)**(undefined8 **)(arg1 + 0xb0))(*(undefined8 **)(arg1 + 0xb0), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d5c50
// Address: 0x1800d5c50
// Size: 35 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5c50(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    char cVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0x90))(arg2, arg1);
    if (cVar1 != '\0') {
        iVar2 = *(int64_t *)(arg1 + 0x40);
        iVar3 = *(int64_t *)(arg1 + 0x48) * 0x38 + iVar2;
        for (; iVar2 != iVar3; iVar2 = iVar2 + 0x38) {
            (**(code **)**(undefined8 **)(iVar2 + 0x18))(*(undefined8 **)(iVar2 + 0x18), arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5c73
// Address: 0x1800d5c73
// Size: 55 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5c50(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    char cVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0x90))(arg2, arg1);
    if (cVar1 != '\0') {
        iVar2 = *(int64_t *)(arg1 + 0x40);
        iVar3 = *(int64_t *)(arg1 + 0x48) * 0x38 + iVar2;
        for (; iVar2 != iVar3; iVar2 = iVar2 + 0x38) {
            (**(code **)**(undefined8 **)(iVar2 + 0x18))(*(undefined8 **)(iVar2 + 0x18), arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5caa
// Address: 0x1800d5caa
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5c50(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    char cVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0x90))(arg2, arg1);
    if (cVar1 != '\0') {
        iVar2 = *(int64_t *)(arg1 + 0x40);
        iVar3 = *(int64_t *)(arg1 + 0x48) * 0x38 + iVar2;
        for (; iVar2 != iVar3; iVar2 = iVar2 + 0x38) {
            (**(code **)**(undefined8 **)(iVar2 + 0x18))(*(undefined8 **)(iVar2 + 0x18), arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5cc0
// Address: 0x1800d5cc0
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5cc0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x88))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x28);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x30);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
        puVar3 = *(undefined8 **)(arg1 + 0x38);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x40);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5ce7
// Address: 0x1800d5ce7
// Size: 92 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5cc0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x88))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x28);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x30);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
        puVar3 = *(undefined8 **)(arg1 + 0x38);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x40);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5d43
// Address: 0x1800d5d43
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5cc0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x88))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x28);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x30);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
        puVar3 = *(undefined8 **)(arg1 + 0x38);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x40);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5d50
// Address: 0x1800d5d50
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5d50(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    char cVar1;
    undefined8 *puVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0x78))(arg2, arg1);
    if (cVar1 != '\0') {
        piVar3 = *(int64_t **)(arg1 + 0x68);
        piVar4 = piVar3 + *(int64_t *)(arg1 + 0x70) * 2;
        for (; piVar3 != piVar4; piVar3 = piVar3 + 2) {
            puVar2 = (undefined8 *)*piVar3;
            if (puVar2 == (undefined8 *)0x0) {
                puVar2 = (undefined8 *)piVar3[1];
            }
            (**(code **)*puVar2)(puVar2, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5d70
// Address: 0x1800d5d70
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5d50(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    char cVar1;
    undefined8 *puVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0x78))(arg2, arg1);
    if (cVar1 != '\0') {
        piVar3 = *(int64_t **)(arg1 + 0x68);
        piVar4 = piVar3 + *(int64_t *)(arg1 + 0x70) * 2;
        for (; piVar3 != piVar4; piVar3 = piVar3 + 2) {
            puVar2 = (undefined8 *)*piVar3;
            if (puVar2 == (undefined8 *)0x0) {
                puVar2 = (undefined8 *)piVar3[1];
            }
            (**(code **)*puVar2)(puVar2, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5db2
// Address: 0x1800d5db2
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5d50(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    char cVar1;
    undefined8 *puVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0x78))(arg2, arg1);
    if (cVar1 != '\0') {
        piVar3 = *(int64_t **)(arg1 + 0x68);
        piVar4 = piVar3 + *(int64_t *)(arg1 + 0x70) * 2;
        for (; piVar3 != piVar4; piVar3 = piVar3 + 2) {
            puVar2 = (undefined8 *)*piVar3;
            if (puVar2 == (undefined8 *)0x0) {
                puVar2 = (undefined8 *)piVar3[1];
            }
            (**(code **)*puVar2)(puVar2, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5dc0
// Address: 0x1800d5dc0
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5dc0(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    undefined8 *puVar1;
    char cVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_8h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x70))(arg2, arg1);
    if (cVar2 != '\0') {
        iVar3 = *(int64_t *)(arg1 + 0x20);
        iVar4 = *(int64_t *)(arg1 + 0x28) * 0x38 + iVar3;
        for (; iVar3 != iVar4; iVar3 = iVar3 + 0x38) {
            (**(code **)**(undefined8 **)(iVar3 + 0x18))(*(undefined8 **)(iVar3 + 0x18), arg2);
        }
        if (*(undefined8 **)(arg1 + 0x30) != (undefined8 *)0x0) {
            puVar1 = (undefined8 *)**(undefined8 **)(arg1 + 0x30);
            (**(code **)*puVar1)(puVar1, arg2);
            puVar1 = *(undefined8 **)(*(int64_t *)(arg1 + 0x30) + 8);
            (**(code **)*puVar1)(puVar1, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5de0
// Address: 0x1800d5de0
// Size: 72 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5dc0(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    undefined8 *puVar1;
    char cVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_8h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x70))(arg2, arg1);
    if (cVar2 != '\0') {
        iVar3 = *(int64_t *)(arg1 + 0x20);
        iVar4 = *(int64_t *)(arg1 + 0x28) * 0x38 + iVar3;
        for (; iVar3 != iVar4; iVar3 = iVar3 + 0x38) {
            (**(code **)**(undefined8 **)(iVar3 + 0x18))(*(undefined8 **)(iVar3 + 0x18), arg2);
        }
        if (*(undefined8 **)(arg1 + 0x30) != (undefined8 *)0x0) {
            puVar1 = (undefined8 *)**(undefined8 **)(arg1 + 0x30);
            (**(code **)*puVar1)(puVar1, arg2);
            puVar1 = *(undefined8 **)(*(int64_t *)(arg1 + 0x30) + 8);
            (**(code **)*puVar1)(puVar1, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5e28
// Address: 0x1800d5e28
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5dc0(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    undefined8 *puVar1;
    char cVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_8h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x70))(arg2, arg1);
    if (cVar2 != '\0') {
        iVar3 = *(int64_t *)(arg1 + 0x20);
        iVar4 = *(int64_t *)(arg1 + 0x28) * 0x38 + iVar3;
        for (; iVar3 != iVar4; iVar3 = iVar3 + 0x38) {
            (**(code **)**(undefined8 **)(iVar3 + 0x18))(*(undefined8 **)(iVar3 + 0x18), arg2);
        }
        if (*(undefined8 **)(arg1 + 0x30) != (undefined8 *)0x0) {
            puVar1 = (undefined8 *)**(undefined8 **)(arg1 + 0x30);
            (**(code **)*puVar1)(puVar1, arg2);
            puVar1 = *(undefined8 **)(*(int64_t *)(arg1 + 0x30) + 8);
            (**(code **)*puVar1)(puVar1, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5e50
// Address: 0x1800d5e50
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800d5e50(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x68))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x50);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x58);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
        puVar1 = *(undefined8 **)(arg1 + 0x60);
        if (puVar1 != (undefined8 *)0x0) {
            (**(code **)*puVar1)(puVar1, arg2);
        }
        (**(code **)**(undefined8 **)(arg1 + 0x78))(*(undefined8 **)(arg1 + 0x78), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d5e74
// Address: 0x1800d5e74
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800d5e50(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x68))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x50);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x58);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
        puVar1 = *(undefined8 **)(arg1 + 0x60);
        if (puVar1 != (undefined8 *)0x0) {
            (**(code **)*puVar1)(puVar1, arg2);
        }
        (**(code **)**(undefined8 **)(arg1 + 0x78))(*(undefined8 **)(arg1 + 0x78), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d5eb7
// Address: 0x1800d5eb7
// Size: 31 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800d5e50(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x68))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x50);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x58);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
        puVar1 = *(undefined8 **)(arg1 + 0x60);
        if (puVar1 != (undefined8 *)0x0) {
            (**(code **)*puVar1)(puVar1, arg2);
        }
        (**(code **)**(undefined8 **)(arg1 + 0x78))(*(undefined8 **)(arg1 + 0x78), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d5ee0
// Address: 0x1800d5ee0
// Size: 55 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d5ee0(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_8h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0x60))(arg2, arg1);
    if (cVar1 != '\0') {
        (**(code **)**(undefined8 **)(arg1 + 0x20))(*(undefined8 **)(arg1 + 0x20), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d5f30
// Address: 0x1800d5f30
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5f30(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x50))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x20);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x28);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5f54
// Address: 0x1800d5f54
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5f30(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x50))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x20);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x28);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5f89
// Address: 0x1800d5f89
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5f30(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x50))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x20);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x28);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5fa0
// Address: 0x1800d5fa0
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5fa0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x48))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x20);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x28);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5fc4
// Address: 0x1800d5fc4
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5fa0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x48))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x20);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x28);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5ff9
// Address: 0x1800d5ff9
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5fa0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x48))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x20);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x28);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d6030
// Address: 0x1800d6030
// Size: 55 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d6030(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_8h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0x30))(arg2, arg1);
    if (cVar1 != '\0') {
        (**(code **)**(undefined8 **)(arg1 + 0x20))(*(undefined8 **)(arg1 + 0x20), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d6070
// Address: 0x1800d6070
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d6070(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x28))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x20);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x28);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d6094
// Address: 0x1800d6094
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d6070(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x28))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x20);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x28);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d60c9
// Address: 0x1800d60c9
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d6070(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x28))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x20);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x28);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d60e0
// Address: 0x1800d60e0
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d60e0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x18))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x20);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x28);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
        puVar1 = *(undefined8 **)(arg1 + 0x30);
        if (puVar1 != (undefined8 *)0x0) {
            (**(code **)*puVar1)(puVar1, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d6104
// Address: 0x1800d6104
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d60e0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x18))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x20);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x28);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
        puVar1 = *(undefined8 **)(arg1 + 0x30);
        if (puVar1 != (undefined8 *)0x0) {
            (**(code **)*puVar1)(puVar1, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d6147
// Address: 0x1800d6147
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d60e0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x18))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x20);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x28);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
        puVar1 = *(undefined8 **)(arg1 + 0x30);
        if (puVar1 != (undefined8 *)0x0) {
            (**(code **)*puVar1)(puVar1, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d6160
// Address: 0x1800d6160
// Size: 55 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d6160(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_8h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0x10))(arg2, arg1);
    if (cVar1 != '\0') {
        (**(code **)**(undefined8 **)(arg1 + 0x20))(*(undefined8 **)(arg1 + 0x20), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d61b0
// Address: 0x1800d61b0
// Size: 177 bytes
// ============================================================
undefined8 fcn.1800d61b0(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    char cVar7;
    int64_t iVar8;
    int32_t *piVar9;
    bool bVar10;
    
    iVar6 = *(int32_t *)0x18078273c;
    iVar5 = *(int32_t *)0x1807826cc;
    iVar4 = *(int32_t *)0x1807826b4;
    iVar3 = *(int32_t *)0x180782670;
    if (*(int32_t *)(arg1 + 8) != *(int32_t *)0x180782758) {
        return 0;
    }
    iVar8 = 0;
    if (*(int32_t *)(arg1 + 8) == *(int32_t *)0x180782758) {
        iVar8 = arg1;
    }
    piVar9 = *(int32_t **)(iVar8 + 0x20);
    piVar1 = piVar9 + *(int64_t *)(iVar8 + 0x28) * 6;
    do {
        if (piVar9 == piVar1) {
            return 1;
        }
        iVar2 = *piVar9;
        if ((iVar2 == 0) || (iVar2 == 1)) {
            iVar2 = *(int32_t *)(*(int64_t *)(piVar9 + 4) + 8);
            if ((iVar2 != iVar3) && (((iVar2 != iVar5 && (iVar2 != iVar4)) && (iVar2 != iVar6)))) {
                cVar7 = fcn.1800d61b0(*(int64_t *)(piVar9 + 4));
                bVar10 = cVar7 == '\0';
                goto code_r0x0001800d6238;
            }
        } else {
            bVar10 = iVar2 == 2;
code_r0x0001800d6238:
            if (bVar10) {
                return 0;
            }
        }
        piVar9 = piVar9 + 6;
    } while( true );
}

// ============================================================
// Function: FUN_1800d62b0
// Address: 0x1800d62b0
// Size: 3016 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_5fh
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h

void fcn.1800d62b0(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    undefined *puVar11;
    uint32_t *puVar12;
    bool bVar13;
    int64_t var_18h;
    undefined auStack_98 [8];
    undefined auStack_90 [24];
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_28h;
    
    puVar11 = auStack_98;
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_98;
    var_78h._0_4_ = 0;
    iVar1 = *(int32_t *)arg1;
    var_70h = arg2;
    if (iVar1 < 0x102) {
        if (iVar1 == 0x101) {
            *(undefined (*) [16])arg2 = ZEXT816(0);
            *(undefined8 *)(arg2 + 0x10) = 4;
            *(undefined8 *)(arg2 + 0x18) = 0xf;
            *(undefined4 *)arg2 = 0x273d3d27;
            *(undefined *)(arg2 + 4) = 0;
            puVar11 = auStack_98;
            goto code_r0x0001800d6dd6;
        }
        if (iVar1 == 0) {
            *(undefined (*) [16])arg2 = ZEXT816(0);
            *(undefined8 *)(arg2 + 0x10) = 5;
            *(undefined8 *)(arg2 + 0x18) = 0xf;
            *(undefined4 *)arg2 = 0x666f653c;
            *(undefined *)(arg2 + 4) = 0x3e;
            *(undefined *)(arg2 + 5) = 0;
            puVar11 = auStack_98;
            goto code_r0x0001800d6dd6;
        }
        if (iVar1 < 0x100) {
            func_0x0001800d4c50(arg2, 0x180642540);
            puVar11 = auStack_98;
            goto code_r0x0001800d6dd6;
        }
code_r0x0001800d6da6:
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 9;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined8 *)arg2 = 0x6e776f6e6b6e753c;
        *(undefined *)(arg2 + 8) = 0x3e;
        *(undefined *)(arg2 + 9) = 0;
        puVar11 = auStack_98;
        goto code_r0x0001800d6dd6;
    }
    // switch table (32 cases) at 0x1800d6df8
    switch(iVar1) {
    case 0x102:
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 4;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined4 *)arg2 = 0x273d3c27;
        *(undefined *)(arg2 + 4) = 0;
        break;
    case 0x103:
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 4;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined4 *)arg2 = 0x273d3e27;
        *(undefined *)(arg2 + 4) = 0;
        puVar11 = auStack_98;
        break;
    case 0x104:
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 4;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined4 *)arg2 = 0x273d7e27;
        *(undefined *)(arg2 + 4) = 0;
        puVar11 = auStack_98;
        break;
    case 0x105:
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 4;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined4 *)arg2 = 0x272e2e27;
        *(undefined *)(arg2 + 4) = 0;
        puVar11 = auStack_98;
        break;
    case 0x106:
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 5;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined4 *)arg2 = 0x2e2e2e27;
        *(undefined *)(arg2 + 4) = 0x27;
        *(undefined *)(arg2 + 5) = 0;
        puVar11 = auStack_98;
        break;
    case 0x107:
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 4;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined4 *)arg2 = 0x273e2d27;
        *(undefined *)(arg2 + 4) = 0;
        puVar11 = auStack_98;
        break;
    case 0x108:
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 4;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined4 *)arg2 = 0x273a3a27;
        *(undefined *)(arg2 + 4) = 0;
        puVar11 = auStack_98;
        break;
    case 0x109:
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 4;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined4 *)arg2 = 0x272f2f27;
        *(undefined *)(arg2 + 4) = 0;
        puVar11 = auStack_98;
        break;
    case 0x10a:
        bVar13 = *(int64_t *)(arg1 + 0x18) == 0;
        if (bVar13) {
            _var_68h = ZEXT816(0);
            var_58h = 0;
            var_50h = 0;
            func_0x000180004830(&var_68h, 0x1806423f0, 0x27);
            piVar8 = &var_68h;
        } else {
            piVar8 = (int64_t *)func_0x0001800d4c50(&var_48h, 0x1806423e4, *(undefined4 *)(arg1 + 0x14));
        }
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0;
        uVar4 = *(undefined4 *)((int64_t)piVar8 + 4);
        uVar5 = *(undefined4 *)(piVar8 + 1);
        uVar6 = *(undefined4 *)((int64_t)piVar8 + 0xc);
        *(undefined4 *)arg2 = *(undefined4 *)piVar8;
        *(undefined4 *)(arg2 + 4) = uVar4;
        *(undefined4 *)(arg2 + 8) = uVar5;
        *(undefined4 *)(arg2 + 0xc) = uVar6;
        uVar4 = *(undefined4 *)((int64_t)piVar8 + 0x14);
        uVar5 = *(undefined4 *)(piVar8 + 3);
        uVar6 = *(undefined4 *)((int64_t)piVar8 + 0x1c);
        *(undefined4 *)(arg2 + 0x10) = *(undefined4 *)(piVar8 + 2);
        *(undefined4 *)(arg2 + 0x14) = uVar4;
        *(undefined4 *)(arg2 + 0x18) = uVar5;
        *(undefined4 *)(arg2 + 0x1c) = uVar6;
        piVar8[2] = 0;
        piVar8[3] = 0xf;
        *(undefined *)piVar8 = 0;
        puVar11 = auStack_98;
        if ((bVar13) && (puVar11 = auStack_98, 0xf < (uint64_t)var_50h)) {
            func_0x000180005a60(&var_68h, var_68h);
            puVar11 = auStack_98;
        }
        goto code_r0x0001800d6bfb;
    case 0x10b:
        bVar13 = *(int64_t *)(arg1 + 0x18) == 0;
        if (bVar13) {
            _var_68h = ZEXT816(0);
            var_58h = 0;
            var_50h = 0;
            func_0x000180004830(&var_68h, 0x180642480, 0x24);
            piVar8 = &var_68h;
        } else {
            piVar8 = (int64_t *)func_0x0001800d4c50(&var_48h, 0x180642418, *(undefined4 *)(arg1 + 0x14));
        }
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0;
        uVar4 = *(undefined4 *)((int64_t)piVar8 + 4);
        uVar5 = *(undefined4 *)(piVar8 + 1);
        uVar6 = *(undefined4 *)((int64_t)piVar8 + 0xc);
        *(undefined4 *)arg2 = *(undefined4 *)piVar8;
        *(undefined4 *)(arg2 + 4) = uVar4;
        *(undefined4 *)(arg2 + 8) = uVar5;
        *(undefined4 *)(arg2 + 0xc) = uVar6;
        uVar4 = *(undefined4 *)((int64_t)piVar8 + 0x14);
        uVar5 = *(undefined4 *)(piVar8 + 3);
        uVar6 = *(undefined4 *)((int64_t)piVar8 + 0x1c);
        *(undefined4 *)(arg2 + 0x10) = *(undefined4 *)(piVar8 + 2);
        *(undefined4 *)(arg2 + 0x14) = uVar4;
        *(undefined4 *)(arg2 + 0x18) = uVar5;
        *(undefined4 *)(arg2 + 0x1c) = uVar6;
        piVar8[2] = 0;
        piVar8[3] = 0xf;
        *(undefined *)piVar8 = 0;
        puVar11 = auStack_98;
        if ((bVar13) && (puVar11 = auStack_98, 0xf < (uint64_t)var_50h)) {
            func_0x000180005a60(&var_68h, var_68h);
            puVar11 = auStack_98;
        }
        goto code_r0x0001800d6bfb;
    case 0x10c:
        bVar13 = *(int64_t *)(arg1 + 0x18) == 0;
        if (bVar13) {
            _var_68h = ZEXT816(0);
            var_58h = 0;
            var_50h = 0;
            func_0x000180004830(&var_68h, 0x1806424b0, 0x21);
            piVar8 = &var_68h;
        } else {
            piVar8 = (int64_t *)func_0x0001800d4c50(&var_48h, 0x1806424a8, *(undefined4 *)(arg1 + 0x14));
        }
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0;
        uVar4 = *(undefined4 *)((int64_t)piVar8 + 4);
        uVar5 = *(undefined4 *)(piVar8 + 1);
        uVar6 = *(undefined4 *)((int64_t)piVar8 + 0xc);
        *(undefined4 *)arg2 = *(undefined4 *)piVar8;
        *(undefined4 *)(arg2 + 4) = uVar4;
        *(undefined4 *)(arg2 + 8) = uVar5;
        *(undefined4 *)(arg2 + 0xc) = uVar6;
        uVar4 = *(undefined4 *)((int64_t)piVar8 + 0x14);
        uVar5 = *(undefined4 *)(piVar8 + 3);
        uVar6 = *(undefined4 *)((int64_t)piVar8 + 0x1c);
        *(undefined4 *)(arg2 + 0x10) = *(undefined4 *)(piVar8 + 2);
        *(undefined4 *)(arg2 + 0x14) = uVar4;
        *(undefined4 *)(arg2 + 0x18) = uVar5;
        *(undefined4 *)(arg2 + 0x1c) = uVar6;
        piVar8[2] = 0;
        piVar8[3] = 0xf;
        *(undefined *)piVar8 = 0;
        if (bVar13) {
            func_0x000180004e40(&var_68h);
            puVar11 = auStack_98;
        } else {
            func_0x000180004e40(&var_48h);
            puVar11 = auStack_98;
        }
        break;
    case 0x10d:
        bVar13 = *(int64_t *)(arg1 + 0x18) == 0;
        if (bVar13) {
            _var_68h = ZEXT816(0);
            var_58h = 0;
            var_50h = 0;
            func_0x000180004830(&var_68h, 0x180642440, 0x13);
            piVar8 = &var_68h;
        } else {
            piVar8 = (int64_t *)func_0x0001800d4c50(&var_48h, 0x1806424d4, *(undefined4 *)(arg1 + 0x14));
        }
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0;
        uVar4 = *(undefined4 *)((int64_t)piVar8 + 4);
        uVar5 = *(undefined4 *)(piVar8 + 1);
        uVar6 = *(undefined4 *)((int64_t)piVar8 + 0xc);
        *(undefined4 *)arg2 = *(undefined4 *)piVar8;
        *(undefined4 *)(arg2 + 4) = uVar4;
        *(undefined4 *)(arg2 + 8) = uVar5;
        *(undefined4 *)(arg2 + 0xc) = uVar6;
        uVar4 = *(undefined4 *)((int64_t)piVar8 + 0x14);
        uVar5 = *(undefined4 *)(piVar8 + 3);
        uVar6 = *(undefined4 *)((int64_t)piVar8 + 0x1c);
        *(undefined4 *)(arg2 + 0x10) = *(undefined4 *)(piVar8 + 2);
        *(undefined4 *)(arg2 + 0x14) = uVar4;
        *(undefined4 *)(arg2 + 0x18) = uVar5;
        *(undefined4 *)(arg2 + 0x1c) = uVar6;
        piVar8[2] = 0;
        piVar8[3] = 0xf;
        *(undefined *)piVar8 = 0;
        puVar11 = auStack_98;
        if ((bVar13) && (puVar11 = auStack_98, 0xf < (uint64_t)var_50h)) {
            func_0x000180005a60(&var_68h, var_68h);
            puVar11 = auStack_98;
        }
        goto code_r0x0001800d6bfb;
    case 0x10e:
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 4;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined4 *)arg2 = 0x273d2b27;
        *(undefined *)(arg2 + 4) = 0;
        puVar11 = auStack_98;
        break;
    case 0x10f:
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 4;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined4 *)arg2 = 0x273d2d27;
        *(undefined *)(arg2 + 4) = 0;
        puVar11 = auStack_98;
        break;
    case 0x110:
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 4;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined4 *)arg2 = 0x273d2a27;
        *(undefined *)(arg2 + 4) = 0;
        puVar11 = auStack_98;
        break;
    case 0x111:
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 4;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined4 *)arg2 = 0x273d2f27;
        *(undefined *)(arg2 + 4) = 0;
        puVar11 = auStack_98;
        break;
    case 0x112:
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 5;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined4 *)arg2 = 0x3d2f2f27;
        *(undefined *)(arg2 + 4) = 0x27;
        *(undefined *)(arg2 + 5) = 0;
        puVar11 = auStack_98;
        break;
    case 0x113:
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 4;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined4 *)arg2 = 0x273d2527;
        *(undefined *)(arg2 + 4) = 0;
        puVar11 = auStack_98;
        break;
    case 0x114:
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 4;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined4 *)arg2 = 0x273d5e27;
        *(undefined *)(arg2 + 4) = 0;
        puVar11 = auStack_98;
        break;
    case 0x115:
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 5;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined4 *)arg2 = 0x3d2e2e27;
        *(undefined *)(arg2 + 4) = 0x27;
        *(undefined *)(arg2 + 5) = 0;
        puVar11 = auStack_98;
        break;
    case 0x116:
    case 0x117:
        bVar13 = *(int64_t *)(arg1 + 0x18) == 0;
        if (bVar13) {
            var_58h = 6;
            var_50h = 0xf;
            stack0xffffffffffffff9f = SUB169(ZEXT816(0), 7);
            var_68h._0_7_ = 0x676e69727473;
            piVar8 = &var_68h;
        } else {
            piVar8 = (int64_t *)func_0x0001800d4c50(&var_48h, 0x1806423dc, *(undefined4 *)(arg1 + 0x14));
        }
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0;
        uVar4 = *(undefined4 *)((int64_t)piVar8 + 4);
        uVar5 = *(undefined4 *)(piVar8 + 1);
        uVar6 = *(undefined4 *)((int64_t)piVar8 + 0xc);
        *(undefined4 *)arg2 = *(undefined4 *)piVar8;
        *(undefined4 *)(arg2 + 4) = uVar4;
        *(undefined4 *)(arg2 + 8) = uVar5;
        *(undefined4 *)(arg2 + 0xc) = uVar6;
        uVar4 = *(undefined4 *)((int64_t)piVar8 + 0x14);
        uVar5 = *(undefined4 *)(piVar8 + 3);
        uVar6 = *(undefined4 *)((int64_t)piVar8 + 0x1c);
        *(undefined4 *)(arg2 + 0x10) = *(undefined4 *)(piVar8 + 2);
        *(undefined4 *)(arg2 + 0x14) = uVar4;
        *(undefined4 *)(arg2 + 0x18) = uVar5;
        *(undefined4 *)(arg2 + 0x1c) = uVar6;
        piVar8[2] = 0;
        piVar8[3] = 0xf;
        *(undefined *)piVar8 = 0;
        puVar11 = auStack_98;
        if ((bVar13) && (puVar11 = auStack_98, 0xf < (uint64_t)var_50h)) {
            iVar7 = var_68h;
            puVar11 = auStack_98;
            if ((0xfff < var_50h + 1U) &&
               (iVar7 = *(int64_t *)(var_68h + -8), puVar11 = auStack_98, 0x1f < (var_68h - iVar7) - 8U)) {
                pcVar3 = (code *)swi(0x29);
                iVar7 = (*pcVar3)(5);
                puVar11 = auStack_90;
            }
            *(undefined8 *)(puVar11 + -8) = 0x1800d6705;
            func_0x000180459c3c(iVar7);
        }
        goto code_r0x0001800d6bfb;
    case 0x118:
        bVar13 = *(int64_t *)(arg1 + 0x18) == 0;
        if (bVar13) {
            var_58h = 6;
            var_50h = 0xf;
            stack0xffffffffffffff9f = SUB169(ZEXT816(0), 7);
            var_68h._0_7_ = 0x7265626d756e;
            piVar8 = &var_68h;
        } else {
            piVar8 = (int64_t *)func_0x0001800d4c50(&var_48h, 0x180641918, *(undefined4 *)(arg1 + 0x14));
        }
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0;
        uVar4 = *(undefined4 *)((int64_t)piVar8 + 4);
        uVar5 = *(undefined4 *)(piVar8 + 1);
        uVar6 = *(undefined4 *)((int64_t)piVar8 + 0xc);
        *(undefined4 *)arg2 = *(undefined4 *)piVar8;
        *(undefined4 *)(arg2 + 4) = uVar4;
        *(undefined4 *)(arg2 + 8) = uVar5;
        *(undefined4 *)(arg2 + 0xc) = uVar6;
        uVar4 = *(undefined4 *)((int64_t)piVar8 + 0x14);
        uVar5 = *(undefined4 *)(piVar8 + 3);
        uVar6 = *(undefined4 *)((int64_t)piVar8 + 0x1c);
        *(undefined4 *)(arg2 + 0x10) = *(undefined4 *)(piVar8 + 2);
        *(undefined4 *)(arg2 + 0x14) = uVar4;
        *(undefined4 *)(arg2 + 0x18) = uVar5;
        *(undefined4 *)(arg2 + 0x1c) = uVar6;
        piVar8[2] = 0;
        piVar8[3] = 0xf;
        *(undefined *)piVar8 = 0;
        puVar11 = auStack_98;
        if (bVar13) {
            func_0x000180004e40(&var_68h);
            puVar11 = auStack_98;
        }
        goto code_r0x0001800d6bfb;
    case 0x119:
        bVar13 = *(int64_t *)(arg1 + 0x18) == 0;
        if (bVar13) {
            var_58h = 10;
            var_50h = 0xf;
            var_60h._0_2_ = 0x7265;
            var_68h = 0x696669746e656469;
            var_60h._2_6_ = 0;
            piVar8 = &var_68h;
        } else {
            piVar8 = (int64_t *)func_0x0001800d4c50(&var_48h, 0x180641930);
        }
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0;
        uVar4 = *(undefined4 *)((int64_t)piVar8 + 4);
        uVar5 = *(undefined4 *)(piVar8 + 1);
        uVar6 = *(undefined4 *)((int64_t)piVar8 + 0xc);
        *(undefined4 *)arg2 = *(undefined4 *)piVar8;
        *(undefined4 *)(arg2 + 4) = uVar4;
        *(undefined4 *)(arg2 + 8) = uVar5;
        *(undefined4 *)(arg2 + 0xc) = uVar6;
        uVar4 = *(undefined4 *)((int64_t)piVar8 + 0x14);
        uVar5 = *(undefined4 *)(piVar8 + 3);
        uVar6 = *(undefined4 *)((int64_t)piVar8 + 0x1c);
        *(undefined4 *)(arg2 + 0x10) = *(undefined4 *)(piVar8 + 2);
        *(undefined4 *)(arg2 + 0x14) = uVar4;
        *(undefined4 *)(arg2 + 0x18) = uVar5;
        *(undefined4 *)(arg2 + 0x1c) = uVar6;
        piVar8[2] = 0;
        piVar8[3] = 0xf;
        *(undefined *)piVar8 = 0;
        puVar11 = auStack_98;
        if ((bVar13) && (puVar11 = auStack_98, 0xf < (uint64_t)var_50h)) {
            func_0x000180005a60(&var_68h, var_68h);
            puVar11 = auStack_98;
        }
        goto code_r0x0001800d6bfb;
    case 0x11a:
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0;
        func_0x000180004830(arg2, 0x180642468, 7);
        puVar11 = auStack_98;
        break;
    default:
        if ((0x122 < iVar1) && (iVar1 < 0x138)) {
            func_0x0001800d4c50(arg2, 0x180641930, *(undefined8 *)((int64_t)iVar1 * 8 + 0x1806179e8));
            puVar11 = auStack_98;
            break;
        }
        goto code_r0x0001800d6da6;
    case 0x11c:
        bVar13 = *(int64_t *)(arg1 + 0x18) == 0;
        if (bVar13) {
            var_58h = 9;
            var_50h = 0xf;
            var_60h._0_1_ = 0x65;
            var_68h = 0x7475626972747461;
            var_60h._1_7_ = 0;
            piVar8 = &var_68h;
        } else {
            piVar8 = (int64_t *)func_0x0001800d4c50(&var_48h, 0x180641930);
        }
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0;
        uVar4 = *(undefined4 *)((int64_t)piVar8 + 4);
        uVar5 = *(undefined4 *)(piVar8 + 1);
        uVar6 = *(undefined4 *)((int64_t)piVar8 + 0xc);
        *(undefined4 *)arg2 = *(undefined4 *)piVar8;
        *(undefined4 *)(arg2 + 4) = uVar4;
        *(undefined4 *)(arg2 + 8) = uVar5;
        *(undefined4 *)(arg2 + 0xc) = uVar6;
        uVar4 = *(undefined4 *)((int64_t)piVar8 + 0x14);
        uVar5 = *(undefined4 *)(piVar8 + 3);
        uVar6 = *(undefined4 *)((int64_t)piVar8 + 0x1c);
        *(undefined4 *)(arg2 + 0x10) = *(undefined4 *)(piVar8 + 2);
        *(undefined4 *)(arg2 + 0x14) = uVar4;
        *(undefined4 *)(arg2 + 0x18) = uVar5;
        *(undefined4 *)(arg2 + 0x1c) = uVar6;
        piVar8[2] = 0;
        piVar8[3] = 0xf;
        *(undefined *)piVar8 = 0;
        puVar11 = auStack_98;
        if ((bVar13) && (puVar11 = auStack_98, 0xf < (uint64_t)var_50h)) {
            func_0x000180005a60(&var_68h, var_68h);
            puVar11 = auStack_98;
        }
code_r0x0001800d6bfb:
        if (!bVar13) {
            *(undefined8 *)(puVar11 + -8) = 0x1800d6c0a;
            func_0x000180004e40(&var_48h);
        }
        break;
    case 0x11d:
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 4;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined4 *)arg2 = 0x275b4027;
        *(undefined *)(arg2 + 4) = 0;
        puVar11 = auStack_98;
        break;
    case 0x11e:
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0;
        func_0x000180004830(arg2, 0x180642550, 0x10);
        puVar11 = auStack_98;
        break;
    case 0x11f:
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0;
        func_0x000180004830(arg2, 0x180642568, 0x12);
        puVar11 = auStack_98;
        break;
    case 0x120:
        uVar2 = *(uint32_t *)(arg1 + 0x18);
        if (uVar2 == 0) {
            *(undefined (*) [16])arg2 = ZEXT816(0);
            *(undefined8 *)(arg2 + 0x10) = 0;
            *(undefined8 *)(arg2 + 0x18) = 0;
            func_0x000180004830(arg2, 0x180642528, 0x16);
            puVar11 = auStack_98;
        } else {
            puVar12 = (uint32_t *)0x180612f40;
            uVar10 = 0x6fa;
            do {
                uVar9 = uVar10 >> 1;
                if ((puVar12[uVar9 + (uVar10 & 0xfffffffffffffffe)] & 0xffffff) < uVar2) {
                    puVar12 = puVar12 + uVar9 + (uVar10 & 0xfffffffffffffffe) + 3;
                    uVar9 = uVar10 + (-1 - uVar9);
                }
                uVar10 = uVar9;
            } while (0 < (int64_t)uVar9);
            if (((puVar12 == (uint32_t *)0x1806182f8) || ((*puVar12 & 0xffffff) != uVar2)) ||
               (puVar12 == (uint32_t *)0xfffffffffffffffc)) {
                func_0x0001800d4c50(arg2, 0x180642510, uVar2);
                puVar11 = auStack_98;
            } else {
                func_0x0001800d4c50(arg2, 0x1806424e0, uVar2);
                puVar11 = auStack_98;
            }
        }
        break;
    case 0x121:
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0;
        func_0x000180004830(arg2, 0x180642580, 0x2b);
        puVar11 = auStack_98;
    }
code_r0x0001800d6dd6:
    *(undefined8 *)(puVar11 + -8) = 0x1800d6de5;
    func_0x000180459870(var_28h ^ (uint64_t)puVar11);
    return;
}

// ============================================================
// Function: FUN_1800d6e80
// Address: 0x1800d6e80
// Size: 160 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

int64_t fcn.1800d6e80(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    char cVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t *piVar4;
    int64_t iVar5;
    int64_t unaff_RBP;
    int64_t var_1h;
    int64_t var_38h;
    int64_t var_30h;
    
    piVar4 = (int64_t *)fcn.1800d8c20(unaff_RBP);
    iVar2 = *(int32_t *)((int64_t)piVar4 + 0xc);
    if (iVar2 != 0) {
        *(int64_t *)arg2 = *piVar4;
        *(int32_t *)(arg2 + 8) = iVar2;
        return arg2;
    }
    iVar5 = fcn.1800d4d20(*(undefined8 *)(arg1 + 0x30), arg4 + 1);
    fcn.180498030(iVar5, arg3, arg4);
    *(undefined *)(iVar5 + arg4) = 0;
    *piVar4 = iVar5;
    cVar1 = *(char *)arg3;
    *(int64_t *)arg2 = iVar5;
    uVar3 = 0x119;
    if (cVar1 == '@') {
        uVar3 = 0x11c;
    }
    *(undefined4 *)((int64_t)piVar4 + 0xc) = uVar3;
    *(undefined4 *)(arg2 + 8) = uVar3;
    return arg2;
}

// ============================================================
// Function: FUN_1800d6f20
// Address: 0x1800d6f20
// Size: 153 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

int64_t fcn.1800d6f20(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    char cVar1;
    undefined4 uVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t unaff_RBP;
    int64_t var_1h;
    int64_t var_38h;
    int64_t var_30h;
    
    piVar3 = (int64_t *)fcn.1800d8c20(unaff_RBP);
    if (*(int32_t *)((int64_t)piVar3 + 0xc) != 0) {
        *(int64_t *)arg2 = *piVar3;
        return arg2;
    }
    iVar4 = fcn.1800d4d20(*(undefined8 *)(arg1 + 0x30), arg4 + 1);
    fcn.180498030(iVar4, arg3, arg4);
    *(undefined *)(iVar4 + arg4) = 0;
    *piVar3 = iVar4;
    cVar1 = *(char *)arg3;
    *(int64_t *)arg2 = iVar4;
    uVar2 = 0x119;
    if (cVar1 == '@') {
        uVar2 = 0x11c;
    }
    *(undefined4 *)((int64_t)piVar3 + 0xc) = uVar2;
    return arg2;
}

// ============================================================
// Function: FUN_1800d6fc0
// Address: 0x1800d6fc0
// Size: 96 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

int64_t fcn.1800d6fc0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 *puVar1;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_10h;
    
    var_18h = arg3;
    var_10h._0_4_ = fcn.180498cd0(arg3);
    var_10h._4_4_ = 0;
    puVar1 = (undefined8 *)fcn.1800d8ef0(arg1, &var_18h);
    if (puVar1 != (undefined8 *)0x0) {
        *(undefined8 *)arg2 = *puVar1;
        return arg2;
    }
    *(undefined8 *)arg2 = 0;
    return arg2;
}

// ============================================================
// Function: FUN_1800d7020
// Address: 0x1800d7020
// Size: 177 bytes
// ============================================================
int64_t fcn.1800d7020(int64_t arg1)
{
    char cVar1;
    uint8_t uVar2;
    uint32_t uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    bool bVar7;
    undefined4 *puVar8;
    int64_t var_48h;
    
    cVar1 = *(char *)(arg1 + 0x58);
    bVar7 = true;
    do {
        while( true ) {
            uVar3 = *(uint32_t *)(arg1 + 0x10);
            if (*(uint64_t *)(arg1 + 8) <= (uint64_t)uVar3) break;
            uVar2 = *(uint8_t *)((uint64_t)uVar3 + *(int64_t *)arg1);
            if ((0x20 < uVar2) || ((0x100002200U >> ((int64_t)(char)uVar2 & 0x3fU) & 1) == 0)) {
                if (uVar2 == 10) {
                    *(int32_t *)(arg1 + 0x14) = *(int32_t *)(arg1 + 0x14) + 1;
                    *(uint32_t *)(arg1 + 0x18) = uVar3 + 1;
                } else if (1 < (uint8_t)(uVar2 - 0xb)) break;
            }
            *(uint32_t *)(arg1 + 0x10) = uVar3 + 1;
        }
        if (bVar7) {
            *(undefined4 *)(arg1 + 0x40) = *(undefined4 *)(arg1 + 0x24);
            *(undefined4 *)(arg1 + 0x44) = *(undefined4 *)(arg1 + 0x28);
            *(undefined4 *)(arg1 + 0x48) = *(undefined4 *)(arg1 + 0x2c);
            *(undefined4 *)(arg1 + 0x4c) = *(undefined4 *)(arg1 + 0x30);
        }
        puVar8 = (undefined4 *)func_0x0001800d7a00(arg1, &var_48h);
        uVar4 = puVar8[1];
        uVar5 = puVar8[2];
        uVar6 = puVar8[3];
        *(undefined4 *)(arg1 + 0x20) = *puVar8;
        *(undefined4 *)(arg1 + 0x24) = uVar4;
        *(undefined4 *)(arg1 + 0x28) = uVar5;
        *(undefined4 *)(arg1 + 0x2c) = uVar6;
        uVar4 = puVar8[5];
        uVar5 = puVar8[6];
        uVar6 = puVar8[7];
        *(undefined4 *)(arg1 + 0x30) = puVar8[4];
        *(undefined4 *)(arg1 + 0x34) = uVar4;
        *(undefined4 *)(arg1 + 0x38) = uVar5;
        *(undefined4 *)(arg1 + 0x3c) = uVar6;
        if (cVar1 == '\0') break;
        bVar7 = false;
    } while ((*(int32_t *)(arg1 + 0x20) == 0x11a) || (*(int32_t *)(arg1 + 0x20) == 0x11b));
    return arg1 + 0x20;
}

// ============================================================
// Function: FUN_1800d70e0
// Address: 0x1800d70e0
// Size: 480 bytes
// ============================================================
int64_t fcn.1800d70e0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint64_t uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 *puVar6;
    code *pcVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    undefined4 uVar18;
    undefined4 uVar19;
    undefined4 uVar20;
    undefined4 uVar21;
    undefined4 uVar22;
    undefined4 uVar23;
    undefined4 uVar24;
    undefined4 uVar25;
    undefined4 uVar26;
    undefined4 uVar27;
    undefined4 *puVar28;
    undefined *puVar29;
    undefined *puVar30;
    uint64_t uVar31;
    uint64_t uVar32;
    uint64_t uVar33;
    int64_t iVar34;
    undefined4 uVar35;
    int64_t var_1h;
    undefined auStack_98 [8];
    undefined auStack_90 [24];
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    
    puVar29 = auStack_98;
    puVar30 = auStack_98;
    iVar34 = *(int64_t *)(arg1 + 0x68);
    piVar1 = (int64_t *)(arg1 + 0x60);
    uVar3 = *(undefined4 *)(arg1 + 0x10);
    uVar4 = *(undefined4 *)(arg1 + 0x14);
    uVar5 = *(undefined4 *)(arg1 + 0x18);
    uVar16 = *(undefined4 *)(arg1 + 0x20);
    uVar17 = *(undefined4 *)(arg1 + 0x24);
    uVar18 = *(undefined4 *)(arg1 + 0x28);
    uVar19 = *(undefined4 *)(arg1 + 0x2c);
    uVar32 = iVar34 - *piVar1 >> 2;
    uVar20 = *(undefined4 *)(arg1 + 0x30);
    uVar21 = *(undefined4 *)(arg1 + 0x34);
    uVar22 = *(undefined4 *)(arg1 + 0x38);
    uVar23 = *(undefined4 *)(arg1 + 0x3c);
    uVar24 = *(undefined4 *)(arg1 + 0x40);
    uVar25 = *(undefined4 *)(arg1 + 0x44);
    uVar26 = *(undefined4 *)(arg1 + 0x48);
    uVar27 = *(undefined4 *)(arg1 + 0x4c);
    if (*piVar1 == iVar34) {
        uVar35 = 1;
    } else {
        uVar35 = *(undefined4 *)(iVar34 + -4);
    }
    puVar28 = (undefined4 *)fcn.1800d7020(arg1);
    uVar8 = *puVar28;
    uVar9 = puVar28[1];
    uVar10 = puVar28[2];
    uVar11 = puVar28[3];
    uVar12 = puVar28[4];
    uVar13 = puVar28[5];
    uVar14 = puVar28[6];
    uVar15 = puVar28[7];
    *(undefined4 *)(arg1 + 0x10) = uVar3;
    *(undefined4 *)(arg1 + 0x20) = uVar16;
    *(undefined4 *)(arg1 + 0x24) = uVar17;
    *(undefined4 *)(arg1 + 0x28) = uVar18;
    *(undefined4 *)(arg1 + 0x2c) = uVar19;
    *(undefined4 *)(arg1 + 0x14) = uVar4;
    *(undefined4 *)(arg1 + 0x30) = uVar20;
    *(undefined4 *)(arg1 + 0x34) = uVar21;
    *(undefined4 *)(arg1 + 0x38) = uVar22;
    *(undefined4 *)(arg1 + 0x3c) = uVar23;
    *(undefined4 *)(arg1 + 0x18) = uVar5;
    *(undefined4 *)(arg1 + 0x40) = uVar24;
    *(undefined4 *)(arg1 + 0x44) = uVar25;
    *(undefined4 *)(arg1 + 0x48) = uVar26;
    *(undefined4 *)(arg1 + 0x4c) = uVar27;
    puVar28 = *(undefined4 **)(arg1 + 0x68);
    iVar34 = *piVar1;
    uVar31 = (int64_t)puVar28 - iVar34 >> 2;
    *(undefined4 *)arg2 = uVar8;
    *(undefined4 *)(arg2 + 4) = uVar9;
    *(undefined4 *)(arg2 + 8) = uVar10;
    *(undefined4 *)(arg2 + 0xc) = uVar11;
    *(undefined4 *)(arg2 + 0x10) = uVar12;
    *(undefined4 *)(arg2 + 0x14) = uVar13;
    *(undefined4 *)(arg2 + 0x18) = uVar14;
    *(undefined4 *)(arg2 + 0x1c) = uVar15;
    if (uVar31 < uVar32) {
        if (puVar28 == *(undefined4 **)(arg1 + 0x70)) {
            if (uVar31 == 0x3fffffffffffffff) {
                func_0x000180010010();
                pcVar7 = (code *)swi(3);
                iVar34 = (*pcVar7)();
                return iVar34;
            }
            uVar32 = (int64_t)*(undefined4 **)(arg1 + 0x70) - iVar34 >> 2;
            if (uVar32 <= 0x3fffffffffffffff - (uVar32 >> 1)) {
                uVar2 = uVar31 + 1;
                uVar32 = (uVar32 >> 1) + uVar32;
                uVar33 = uVar2;
                if (uVar2 <= uVar32) {
                    uVar33 = uVar32;
                }
                if (uVar33 < 0x4000000000000000) {
                    uVar32 = uVar33 * 4;
                    if (uVar32 == 0) {
                        uVar32 = 0;
                        puVar30 = auStack_98;
                    } else if (uVar32 < 0x1000) {
                        uVar32 = fcn.180459890();
                    } else {
                        if (uVar32 + 0x27 <= uVar32) goto code_r0x0001800d72b4;
                        iVar34 = fcn.180459890(uVar32 + 0x27);
                        if (iVar34 == 0) {
                            pcVar7 = (code *)swi(0x29);
                            iVar34 = (*pcVar7)(5);
                            puVar29 = auStack_90;
                        }
                        uVar32 = iVar34 + 0x27U & 0xffffffffffffffe0;
                        *(int64_t *)(uVar32 - 8) = iVar34;
                        puVar30 = puVar29;
                    }
                    *(undefined4 *)(uVar32 + uVar31 * 4) = uVar35;
                    puVar6 = (undefined4 *)*piVar1;
                    if (puVar28 == *(undefined4 **)(arg1 + 0x68)) {
                        iVar34 = (int64_t)*(undefined4 **)(arg1 + 0x68) - (int64_t)puVar6;
                        uVar31 = uVar32;
                        puVar28 = puVar6;
                    } else {
                        *(undefined8 *)(puVar30 + -8) = 0x1800d725f;
                        fcn.180498030(uVar32, puVar6, (int64_t)puVar28 - (int64_t)puVar6);
                        iVar34 = *(int64_t *)(arg1 + 0x68) - (int64_t)puVar28;
                        uVar31 = uVar32 + (uVar31 + 1) * 4;
                    }
                    *(undefined8 *)(puVar30 + -8) = 0x1800d7276;
                    fcn.180498030(uVar31, puVar28, iVar34);
                    *(undefined8 *)(puVar30 + -8) = 0x1800d7287;
                    func_0x000180030d40(piVar1, uVar32, uVar2, uVar33);
                    return arg2;
                }
            }
code_r0x0001800d72b4:
            fcn.180004720();
            pcVar7 = (code *)swi(3);
            iVar34 = (*pcVar7)();
            return iVar34;
        }
        *puVar28 = uVar35;
        *(int64_t *)(arg1 + 0x68) = *(int64_t *)(arg1 + 0x68) + 4;
    } else if (uVar32 < uVar31) {
        *(int64_t *)(arg1 + 0x68) = *(int64_t *)(arg1 + 0x68) + -4;
    }
    return arg2;
}

// ============================================================
// Function: FUN_1800d72c0
// Address: 0x1800d72c0
// Size: 275 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

int64_t fcn.1800d72c0(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    char cVar2;
    int32_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int32_t iVar7;
    uint32_t uVar9;
    int64_t var_8h;
    int64_t var_48h;
    int64_t var_40h;
    uint64_t uVar8;
    
    var_8h._0_4_ = *(undefined4 *)(arg1 + 0x14);
    iVar3 = *(int32_t *)(arg1 + 0x18);
    iVar7 = *(int32_t *)(arg1 + 0x10);
    var_8h._4_4_ = iVar7 - iVar3;
    uVar4 = *(uint64_t *)(arg1 + 8);
    iVar5 = *(int64_t *)arg1;
    uVar1 = iVar7 + 2;
    *(uint32_t *)(arg1 + 0x10) = uVar1;
    if ((uVar1 < uVar4) && (*(char *)((uint64_t)uVar1 + iVar5) == '[')) {
        uVar6 = iVar7 + 3;
        uVar9 = 0;
        while( true ) {
            uVar8 = (uint64_t)uVar6;
            *(uint32_t *)(arg1 + 0x10) = uVar6;
            if (uVar4 <= uVar8) break;
            if (*(char *)(uVar8 + iVar5) != '=') {
                if (*(char *)(uVar8 + iVar5) == '[') goto code_r0x0001800d7332;
                break;
            }
            uVar6 = uVar6 + 1;
            uVar9 = uVar9 + 1;
        }
        uVar9 = ~uVar9;
code_r0x0001800d7332:
        if (-1 < (int32_t)uVar9) {
            func_0x0001800d73e0(arg1, arg2, &var_8h, uVar9, 0x11b, 0x11f);
            return arg2;
        }
    } else {
        uVar8 = (uint64_t)uVar1;
    }
    while (iVar7 = (int32_t)uVar8, uVar8 < uVar4) {
        iVar5 = *(int64_t *)arg1;
        cVar2 = *(char *)(uVar8 + iVar5);
        if (((cVar2 == '\0') || (cVar2 == '\r')) || (cVar2 == '\n')) break;
        *(uint32_t *)(arg1 + 0x10) = iVar7 + 1U;
        uVar8 = (uint64_t)(iVar7 + 1U);
    }
    *(undefined4 *)arg2 = 0x11a;
    *(undefined4 *)(arg2 + 4) = (undefined4)var_8h;
    *(int32_t *)(arg2 + 0x10) = iVar7 - iVar3;
    *(int32_t *)(arg2 + 8) = var_8h._4_4_;
    *(uint64_t *)(arg2 + 0x18) = iVar5 + (uint64_t)uVar1;
    *(undefined4 *)(arg2 + 0xc) = (undefined4)var_8h;
    *(uint32_t *)(arg2 + 0x14) = iVar7 - uVar1;
    return arg2;
}

// ============================================================
// Function: FUN_1800d73e0
// Address: 0x1800d73e0
// Size: 305 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800d73e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    char cVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    uint64_t uVar8;
    uint32_t uVar9;
    int64_t var_8h;
    
    uVar2 = *(uint64_t *)(arg1 + 8);
    uVar9 = *(int32_t *)(arg1 + 0x10) + 1;
    *(uint32_t *)(arg1 + 0x10) = uVar9;
    uVar8 = (uint64_t)uVar9;
code_r0x0001800d7410:
    do {
        uVar5 = (uint32_t)uVar8;
        if (uVar2 <= uVar8) {
code_r0x0001800d74d6:
            iVar7 = *(int32_t *)(arg1 + 0x18);
            *(undefined8 *)(arg2 + 4) = *(undefined8 *)arg3;
            *(undefined4 *)(arg2 + 0xc) = *(undefined4 *)(arg1 + 0x14);
            *(uint32_t *)(arg2 + 0x10) = uVar5 - iVar7;
            *(undefined4 *)(arg2 + 0x14) = 0;
            *(undefined8 *)(arg2 + 0x18) = 0;
            arg_28h._0_4_ = (undefined4)arg_30h;
            goto code_r0x0001800d74ff;
        }
        iVar3 = *(int64_t *)arg1;
        if (*(char *)(iVar3 + uVar8) == '\0') goto code_r0x0001800d74d6;
        if (*(char *)(iVar3 + uVar8) != ']') {
            if (*(char *)(uVar8 + iVar3) == '\n') {
                *(int32_t *)(arg1 + 0x14) = *(int32_t *)(arg1 + 0x14) + 1;
                *(uint32_t *)(arg1 + 0x18) = uVar5 + 1;
            }
            uVar8 = (uint64_t)(uVar5 + 1);
            *(uint32_t *)(arg1 + 0x10) = uVar5 + 1;
            goto code_r0x0001800d7410;
        }
        cVar1 = *(char *)(uVar8 + iVar3);
        uVar4 = 0;
        while( true ) {
            uVar6 = uVar5 + 1;
            uVar8 = (uint64_t)uVar6;
            *(uint32_t *)(arg1 + 0x10) = uVar6;
            if ((uVar2 <= uVar8) || (*(char *)(iVar3 + uVar8) != '=')) break;
            uVar4 = uVar4 + 1;
            uVar5 = uVar6;
        }
        if ((uVar2 <= uVar8) || (cVar1 != *(char *)(iVar3 + uVar8))) {
            uVar4 = ~uVar4;
        }
        if (uVar4 == (uint32_t)arg4) {
            iVar7 = uVar5 + 2;
            *(int32_t *)(arg1 + 0x10) = iVar7;
            *(undefined8 *)(arg2 + 4) = *(undefined8 *)arg3;
            *(undefined4 *)(arg2 + 0xc) = *(undefined4 *)(arg1 + 0x14);
            *(int32_t *)(arg2 + 0x10) = iVar7 - *(int32_t *)(arg1 + 0x18);
            *(uint32_t *)(arg2 + 0x14) = ((iVar7 - uVar9) - (uint32_t)arg4) + -2;
            *(uint64_t *)(arg2 + 0x18) = (uint64_t)uVar9 + iVar3;
code_r0x0001800d74ff:
            *(undefined4 *)arg2 = (undefined4)arg_28h;
            return arg2;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1800d75e0
// Address: 0x1800d75e0
// Size: 406 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_28h

int64_t fcn.1800d75e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int32_t iVar8;
    uint64_t uVar9;
    char cVar10;
    undefined8 uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_34h;
    int64_t var_2ch;
    
    uVar2 = *(uint32_t *)(arg1 + 0x10);
    uVar11 = 0x2401;
    while( true ) {
        uVar6 = *(uint64_t *)(arg1 + 8);
        uVar3 = *(uint32_t *)(arg1 + 0x10);
        uVar9 = (uint64_t)uVar3;
        if (uVar6 <= uVar9) break;
        iVar7 = *(int64_t *)arg1;
        if (*(char *)(uVar9 + iVar7) == '`') {
            iVar8 = uVar3 + 1;
            *(undefined4 *)arg2 = (undefined4)arg_28h;
            *(undefined4 *)(arg2 + 0xc) = *(undefined4 *)(arg1 + 0x14);
            *(int32_t *)(arg1 + 0x10) = iVar8;
            *(int32_t *)(arg2 + 0x10) = iVar8 - *(int32_t *)(arg1 + 0x18);
            *(uint32_t *)(arg2 + 0x14) = (iVar8 - uVar2) + -1;
            iVar7 = iVar7 + (uint64_t)uVar2;
            goto code_r0x0001800d7758;
        }
        uVar1 = *(uint8_t *)(uVar9 + iVar7);
        if ((uVar1 < 0xe) && (((uint32_t)uVar11 >> ((int32_t)(char)uVar1 & 0x1fU) & 1) != 0)) break;
        if (uVar1 == 0x5c) {
            if ((((uVar3 + 1 < uVar6) && (*(char *)((uint64_t)(uVar3 + 1) + *(int64_t *)arg1) == 'u')) &&
                (uVar3 + 2 < uVar6)) && (*(char *)((uint64_t)(uVar3 + 2) + *(int64_t *)arg1) == '{')) {
                *(uint32_t *)(arg1 + 0x10) = uVar3 + 3;
            } else {
                func_0x0001800d7520(arg1);
            }
        } else {
            if (uVar1 == 0x7b) {
                var_8h._0_4_ = 0;
                func_0x0001800d31a0(arg1 + 0x60, &var_8h);
                iVar8 = *(int32_t *)(arg1 + 0x10);
                uVar3 = iVar8 + 1;
                if ((uint64_t)uVar3 < *(uint64_t *)(arg1 + 8)) {
                    cVar10 = *(char *)((uint64_t)uVar3 + *(int64_t *)arg1);
                } else {
                    cVar10 = '\0';
                }
                uVar4 = *(undefined4 *)(arg1 + 0x14);
                iVar5 = *(int32_t *)(arg1 + 0x18);
                *(uint64_t *)(arg2 + 0x18) = (uint64_t)uVar2 + *(int64_t *)arg1;
                if (cVar10 == '{') {
                    *(int32_t *)(arg1 + 0x10) = iVar8 + 2;
                    *(undefined4 *)arg2 = 0x121;
                    *(int64_t *)(arg2 + 4) = arg3;
                    *(undefined4 *)(arg2 + 0xc) = uVar4;
                    *(int32_t *)(arg2 + 0x10) = iVar8 - iVar5;
                    *(uint32_t *)(arg2 + 0x14) = iVar8 - uVar2;
                    return arg2;
                }
                *(uint32_t *)(arg1 + 0x10) = uVar3;
                *(int32_t *)arg2 = (int32_t)arg4;
                *(undefined4 *)(arg2 + 0xc) = uVar4;
                *(uint32_t *)(arg2 + 0x10) = uVar3 - iVar5;
                *(uint32_t *)(arg2 + 0x14) = (uVar3 - uVar2) + -1;
                goto code_r0x0001800d775c;
            }
            *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + 1;
        }
    }
    iVar8 = *(int32_t *)(arg1 + 0x18);
    *(undefined4 *)(arg2 + 0xc) = *(undefined4 *)(arg1 + 0x14);
    iVar7 = 0;
    *(undefined4 *)(arg2 + 0x14) = 0;
    *(undefined4 *)arg2 = 0x11e;
    *(uint32_t *)(arg2 + 0x10) = uVar3 - iVar8;
code_r0x0001800d7758:
    *(int64_t *)(arg2 + 0x18) = iVar7;
code_r0x0001800d775c:
    *(int64_t *)(arg2 + 4) = arg3;
    return arg2;
}

// ============================================================
// Function: FUN_1800d7780
// Address: 0x1800d7780
// Size: 287 bytes
// ============================================================
int64_t fcn.1800d7780(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    uint64_t uVar1;
    int64_t iVar2;
    char cVar3;
    int32_t iVar4;
    uint64_t uVar5;
    
    uVar1 = *(uint64_t *)(arg1 + 8);
    do {
        do {
            iVar4 = *(int32_t *)(arg1 + 0x10);
            iVar2 = *(int64_t *)arg1;
            uVar5 = (uint64_t)(iVar4 + 1U);
            *(uint32_t *)(arg1 + 0x10) = iVar4 + 1U;
            if (uVar5 < uVar1) {
                cVar3 = *(char *)(uVar5 + iVar2);
            } else {
                cVar3 = '\0';
            }
        } while ((int32_t)cVar3 - 0x30U < 10);
        if (uVar1 <= uVar5) goto code_r0x0001800d7815;
    } while ((*(char *)(uVar5 + iVar2) == '.') || (*(char *)(uVar5 + iVar2) == '_'));
    if ((*(char *)(uVar5 + iVar2) == 'e') || (*(char *)(uVar5 + iVar2) == 'E')) {
        uVar5 = (uint64_t)(iVar4 + 2U);
        *(uint32_t *)(arg1 + 0x10) = iVar4 + 2U;
        if ((uVar5 < uVar1) && ((*(char *)(uVar5 + iVar2) == '+' || (*(char *)(uVar5 + iVar2) == '-')))) {
            uVar5 = (uint64_t)(iVar4 + 3U);
            *(uint32_t *)(arg1 + 0x10) = iVar4 + 3U;
        }
    }
code_r0x0001800d7815:
    do {
        iVar4 = (int32_t)uVar5;
        if (uVar5 < uVar1) {
            cVar3 = *(char *)(uVar5 + *(int64_t *)arg1);
        } else {
            cVar3 = '\0';
        }
        if (0x19 < ((int32_t)cVar3 | 0x20U) - 0x61) {
            if (uVar5 < uVar1) {
                cVar3 = *(char *)(uVar5 + *(int64_t *)arg1);
            } else {
                cVar3 = '\0';
            }
            if ((9 < (int32_t)cVar3 - 0x30U) && ((uVar1 <= uVar5 || (*(char *)(uVar5 + *(int64_t *)arg1) != '_')))) {
                *(undefined8 *)(arg2 + 4) = *(undefined8 *)arg3;
                *(undefined4 *)(arg2 + 0xc) = *(undefined4 *)(arg1 + 0x14);
                *(int32_t *)(arg2 + 0x10) = iVar4 - *(int32_t *)(arg1 + 0x18);
                *(uint64_t *)(arg2 + 0x18) = (arg4 & 0xffffffffU) + *(int64_t *)arg1;
                *(undefined4 *)arg2 = 0x118;
                *(int32_t *)(arg2 + 0x14) = iVar4 - (int32_t)arg4;
                return arg2;
            }
        }
        uVar5 = (uint64_t)(iVar4 + 1U);
        *(uint32_t *)(arg1 + 0x10) = iVar4 + 1U;
    } while( true );
}

// ============================================================
// Function: FUN_1800d78a0
// Address: 0x1800d78a0
// Size: 163 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.1800d78a0(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t *piVar2;
    int64_t iVar3;
    char cVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    char *pcVar7;
    uint64_t uVar8;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar1 = *(uint32_t *)(arg1 + 0x10);
    uVar6 = *(uint64_t *)(arg1 + 8);
    uVar8 = (uint64_t)uVar1;
    do {
        do {
            var_20h._0_4_ = (int32_t)uVar8 + 1;
            uVar5 = (uint64_t)(uint32_t)var_20h;
            *(uint32_t *)(arg1 + 0x10) = (uint32_t)var_20h;
            if (uVar5 < uVar6) {
                cVar4 = *(char *)(uVar5 + *(int64_t *)arg1);
            } else {
                cVar4 = '\0';
            }
            uVar8 = (uint64_t)(uint32_t)var_20h;
        } while (((int32_t)cVar4 | 0x20U) - 0x61 < 0x1a);
        if (uVar5 < uVar6) {
            cVar4 = *(char *)(uVar5 + *(int64_t *)arg1);
        } else {
            cVar4 = '\0';
        }
    } while (((int32_t)cVar4 - 0x30U < 10) || ((uVar5 < uVar6 && (*(char *)(uVar5 + *(int64_t *)arg1) == '_'))));
    iVar3 = *(int64_t *)(arg1 + 0x50);
    var_20h._0_4_ = (uint32_t)var_20h - uVar1;
    uVar6 = (uint64_t)(uint32_t)var_20h;
    var_20h._4_4_ = 0;
    pcVar7 = (char *)((uint64_t)uVar1 + *(int64_t *)arg1);
    var_28h = (int64_t)pcVar7;
    if (*(char *)(arg1 + 0x59) == '\0') {
        piVar2 = (int64_t *)fcn.1800d8ef0(iVar3, &var_28h);
        if (piVar2 == (int64_t *)0x0) {
            var_28h = 0;
            var_20h._0_4_ = 0x119;
        } else {
            var_28h = *piVar2;
            var_20h._0_4_ = *(int32_t *)((int64_t)piVar2 + 0xc);
        }
    } else {
        piVar2 = (int64_t *)fcn.1800d8c20(unaff_retaddr);
        if (*(int32_t *)((int64_t)piVar2 + 0xc) == 0) {
            iVar3 = fcn.1800d4d20(*(undefined8 *)(iVar3 + 0x30), uVar6 + 1);
            fcn.180498030(iVar3, pcVar7, uVar6);
            *(undefined *)(uVar6 + iVar3) = 0;
            *piVar2 = iVar3;
            var_20h._0_4_ = 0x119;
            if (*pcVar7 == '@') {
                var_20h._0_4_ = 0x11c;
            }
            *(uint32_t *)((int64_t)piVar2 + 0xc) = (uint32_t)var_20h;
            var_28h = iVar3;
        } else {
            var_28h = *piVar2;
            var_20h._0_4_ = *(int32_t *)((int64_t)piVar2 + 0xc);
        }
    }
    *(undefined4 *)arg2 = (undefined4)var_28h;
    *(undefined4 *)(arg2 + 4) = var_28h._4_4_;
    *(uint32_t *)(arg2 + 8) = (uint32_t)var_20h;
    *(undefined4 *)(arg2 + 0xc) = var_20h._4_4_;
    return arg2;
}

// ============================================================
// Function: FUN_1800d7943
// Address: 0x1800d7943
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.1800d78a0(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t *piVar2;
    int64_t iVar3;
    char cVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    char *pcVar7;
    uint64_t uVar8;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar1 = *(uint32_t *)(arg1 + 0x10);
    uVar6 = *(uint64_t *)(arg1 + 8);
    uVar8 = (uint64_t)uVar1;
    do {
        do {
            var_20h._0_4_ = (int32_t)uVar8 + 1;
            uVar5 = (uint64_t)(uint32_t)var_20h;
            *(uint32_t *)(arg1 + 0x10) = (uint32_t)var_20h;
            if (uVar5 < uVar6) {
                cVar4 = *(char *)(uVar5 + *(int64_t *)arg1);
            } else {
                cVar4 = '\0';
            }
            uVar8 = (uint64_t)(uint32_t)var_20h;
        } while (((int32_t)cVar4 | 0x20U) - 0x61 < 0x1a);
        if (uVar5 < uVar6) {
            cVar4 = *(char *)(uVar5 + *(int64_t *)arg1);
        } else {
            cVar4 = '\0';
        }
    } while (((int32_t)cVar4 - 0x30U < 10) || ((uVar5 < uVar6 && (*(char *)(uVar5 + *(int64_t *)arg1) == '_'))));
    iVar3 = *(int64_t *)(arg1 + 0x50);
    var_20h._0_4_ = (uint32_t)var_20h - uVar1;
    uVar6 = (uint64_t)(uint32_t)var_20h;
    var_20h._4_4_ = 0;
    pcVar7 = (char *)((uint64_t)uVar1 + *(int64_t *)arg1);
    var_28h = (int64_t)pcVar7;
    if (*(char *)(arg1 + 0x59) == '\0') {
        piVar2 = (int64_t *)fcn.1800d8ef0(iVar3, &var_28h);
        if (piVar2 == (int64_t *)0x0) {
            var_28h = 0;
            var_20h._0_4_ = 0x119;
        } else {
            var_28h = *piVar2;
            var_20h._0_4_ = *(int32_t *)((int64_t)piVar2 + 0xc);
        }
    } else {
        piVar2 = (int64_t *)fcn.1800d8c20(unaff_retaddr);
        if (*(int32_t *)((int64_t)piVar2 + 0xc) == 0) {
            iVar3 = fcn.1800d4d20(*(undefined8 *)(iVar3 + 0x30), uVar6 + 1);
            fcn.180498030(iVar3, pcVar7, uVar6);
            *(undefined *)(uVar6 + iVar3) = 0;
            *piVar2 = iVar3;
            var_20h._0_4_ = 0x119;
            if (*pcVar7 == '@') {
                var_20h._0_4_ = 0x11c;
            }
            *(uint32_t *)((int64_t)piVar2 + 0xc) = (uint32_t)var_20h;
            var_28h = iVar3;
        } else {
            var_28h = *piVar2;
            var_20h._0_4_ = *(int32_t *)((int64_t)piVar2 + 0xc);
        }
    }
    *(undefined4 *)arg2 = (undefined4)var_28h;
    *(undefined4 *)(arg2 + 4) = var_28h._4_4_;
    *(uint32_t *)(arg2 + 8) = (uint32_t)var_20h;
    *(undefined4 *)(arg2 + 0xc) = var_20h._4_4_;
    return arg2;
}

// ============================================================
// Function: FUN_1800d796a
// Address: 0x1800d796a
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.1800d78a0(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t *piVar2;
    int64_t iVar3;
    char cVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    char *pcVar7;
    uint64_t uVar8;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar1 = *(uint32_t *)(arg1 + 0x10);
    uVar6 = *(uint64_t *)(arg1 + 8);
    uVar8 = (uint64_t)uVar1;
    do {
        do {
            var_20h._0_4_ = (int32_t)uVar8 + 1;
            uVar5 = (uint64_t)(uint32_t)var_20h;
            *(uint32_t *)(arg1 + 0x10) = (uint32_t)var_20h;
            if (uVar5 < uVar6) {
                cVar4 = *(char *)(uVar5 + *(int64_t *)arg1);
            } else {
                cVar4 = '\0';
            }
            uVar8 = (uint64_t)(uint32_t)var_20h;
        } while (((int32_t)cVar4 | 0x20U) - 0x61 < 0x1a);
        if (uVar5 < uVar6) {
            cVar4 = *(char *)(uVar5 + *(int64_t *)arg1);
        } else {
            cVar4 = '\0';
        }
    } while (((int32_t)cVar4 - 0x30U < 10) || ((uVar5 < uVar6 && (*(char *)(uVar5 + *(int64_t *)arg1) == '_'))));
    iVar3 = *(int64_t *)(arg1 + 0x50);
    var_20h._0_4_ = (uint32_t)var_20h - uVar1;
    uVar6 = (uint64_t)(uint32_t)var_20h;
    var_20h._4_4_ = 0;
    pcVar7 = (char *)((uint64_t)uVar1 + *(int64_t *)arg1);
    var_28h = (int64_t)pcVar7;
    if (*(char *)(arg1 + 0x59) == '\0') {
        piVar2 = (int64_t *)fcn.1800d8ef0(iVar3, &var_28h);
        if (piVar2 == (int64_t *)0x0) {
            var_28h = 0;
            var_20h._0_4_ = 0x119;
        } else {
            var_28h = *piVar2;
            var_20h._0_4_ = *(int32_t *)((int64_t)piVar2 + 0xc);
        }
    } else {
        piVar2 = (int64_t *)fcn.1800d8c20(unaff_retaddr);
        if (*(int32_t *)((int64_t)piVar2 + 0xc) == 0) {
            iVar3 = fcn.1800d4d20(*(undefined8 *)(iVar3 + 0x30), uVar6 + 1);
            fcn.180498030(iVar3, pcVar7, uVar6);
            *(undefined *)(uVar6 + iVar3) = 0;
            *piVar2 = iVar3;
            var_20h._0_4_ = 0x119;
            if (*pcVar7 == '@') {
                var_20h._0_4_ = 0x11c;
            }
            *(uint32_t *)((int64_t)piVar2 + 0xc) = (uint32_t)var_20h;
            var_28h = iVar3;
        } else {
            var_28h = *piVar2;
            var_20h._0_4_ = *(int32_t *)((int64_t)piVar2 + 0xc);
        }
    }
    *(undefined4 *)arg2 = (undefined4)var_28h;
    *(undefined4 *)(arg2 + 4) = var_28h._4_4_;
    *(uint32_t *)(arg2 + 8) = (uint32_t)var_20h;
    *(undefined4 *)(arg2 + 0xc) = var_20h._4_4_;
    return arg2;
}

