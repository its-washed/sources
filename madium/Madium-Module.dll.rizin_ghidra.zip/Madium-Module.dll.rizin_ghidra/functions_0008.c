// Chunk 8 - 50 functions

// ============================================================
// Function: FUN_1800115d0
// Address: 0x1800115d0
// Size: 808 bytes
// ============================================================
void fcn.1800115d0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    uint8_t uVar1;
    int32_t iVar2;
    uint8_t *puVar3;
    code *pcVar4;
    undefined auVar5 [16];
    int64_t iVar6;
    uint32_t uVar7;
    int64_t *piVar8;
    undefined8 *puVar9;
    uint64_t uVar10;
    undefined *puVar11;
    uint32_t uVar12;
    undefined uVar13;
    int64_t *piVar14;
    int64_t iVar15;
    uint64_t uVar16;
    int64_t iVar17;
    undefined auStack_108 [8];
    undefined auStack_100 [24];
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    undefined4 uStack_c0;
    undefined4 uStack_bc;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    uint64_t uStack_a0;
    int64_t var_98h;
    undefined8 uStack_90;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    
    puVar11 = auStack_108;
    var_78h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_108;
    iVar17 = 0;
    var_d8h = arg3;
    if ((*(uint32_t *)(arg4 + 0x18) & 0x4000) == 0) {
        var_c8h = *(int64_t *)arg3;
        uStack_c0 = *(undefined4 *)(arg3 + 8);
        uStack_bc = *(undefined4 *)(arg3 + 0xc);
        var_e0h._0_4_ = (uint32_t)(uint8_t)arg_30h;
        var_e8h._0_1_ = (uint8_t)arg_28h;
        (**(code **)(*(int64_t *)arg1 + 0x48))(*(undefined4 *)arg3, arg2, &var_c8h);
        puVar11 = auStack_108;
    } else {
        piVar14 = *(int64_t **)(*(int64_t *)(arg4 + 0x40) + 8);
        var_c8h = arg4;
        var_b0h = (int64_t)piVar14;
        (**(code **)(*piVar14 + 8))(piVar14);
        piVar8 = (int64_t *)func_0x000180011fb0(&var_b8h);
        puVar9 = (undefined8 *)(**(code **)(*piVar14 + 0x10))(piVar14);
        if (puVar9 != (undefined8 *)0x0) {
            (**(code **)*puVar9)(puVar9, 1);
        }
        var_88h = 0;
        var_80h = 0xf;
        stack0xffffffffffffff69 = SUB1615(ZEXT816(0), 1);
        auVar5[15] = 0;
        auVar5._0_15_ = stack0xffffffffffffff69;
        _var_98h = auVar5 << 8;
        if ((uint8_t)arg_30h == 0) {
            (**(code **)(*piVar8 + 0x30))(piVar8, &var_b8h);
        } else {
            (**(code **)(*piVar8 + 0x38))();
        }
        iVar6 = var_b8h;
        var_88h = var_a8h;
        var_80h = uStack_a0;
        uStack_90 = var_b0h;
        var_98h = var_b8h;
        uVar10 = *(uint64_t *)(arg4 + 0x28);
        iVar15 = iVar17;
        if ((0 < (int64_t)uVar10) && ((uint64_t)var_a8h < uVar10)) {
            iVar15 = uVar10 - var_a8h;
        }
        uVar12 = (uint32_t)(uint8_t)arg_28h;
        if ((*(uint32_t *)(arg4 + 0x18) & 0x1c0) != 0x40) {
            uVar13 = *(undefined *)arg3;
            piVar14 = *(int64_t **)(arg3 + 8);
            for (; iVar15 != 0; iVar15 = iVar15 + -1) {
                if (piVar14 == (int64_t *)0x0) {
code_r0x000180011762:
                    uVar13 = 1;
                } else {
                    if (*(int64_t *)piVar14[8] == 0) {
code_r0x000180011752:
                        uVar7 = (**(code **)(*piVar14 + 0x18))(piVar14, uVar12);
                    } else {
                        iVar2 = *(int32_t *)piVar14[0xb];
                        if (iVar2 < 1) goto code_r0x000180011752;
                        *(int32_t *)piVar14[0xb] = iVar2 + -1;
                        puVar3 = *(uint8_t **)piVar14[8];
                        *(uint8_t **)piVar14[8] = puVar3 + 1;
                        *puVar3 = (uint8_t)arg_28h;
                        uVar7 = uVar12;
                    }
                    if (uVar7 == 0xffffffff) goto code_r0x000180011762;
                }
            }
            *(undefined *)arg3 = uVar13;
            iVar15 = iVar17;
        }
        piVar14 = &var_98h;
        if (0xf < uStack_a0) {
            piVar14 = (int64_t *)var_b8h;
        }
        uVar13 = *(undefined *)arg3;
        piVar8 = *(int64_t **)(var_d8h + 8);
        var_b8h = uStack_a0;
        for (iVar17 = var_a8h; iVar17 != 0; iVar17 = iVar17 + -1) {
            if (piVar8 == (int64_t *)0x0) {
code_r0x0001800117ec:
                uVar13 = 1;
            } else {
                uVar1 = *(uint8_t *)piVar14;
                if (*(int64_t *)piVar8[8] == 0) {
code_r0x0001800117db:
                    uVar7 = (**(code **)(*piVar8 + 0x18))(piVar8, uVar1);
                } else {
                    iVar2 = *(int32_t *)piVar8[0xb];
                    if (iVar2 < 1) goto code_r0x0001800117db;
                    *(int32_t *)piVar8[0xb] = iVar2 + -1;
                    puVar3 = *(uint8_t **)piVar8[8];
                    *(uint8_t **)piVar8[8] = puVar3 + 1;
                    *puVar3 = uVar1;
                    uVar7 = (uint32_t)uVar1;
                }
                if (uVar7 == 0xffffffff) goto code_r0x0001800117ec;
            }
            piVar14 = (int64_t *)((int64_t)piVar14 + 1);
        }
        *(undefined8 *)(var_c8h + 0x28) = 0;
        for (; iVar15 != 0; iVar15 = iVar15 + -1) {
            if (piVar8 == (int64_t *)0x0) {
code_r0x000180011852:
                uVar13 = 1;
            } else {
                if (*(int64_t *)piVar8[8] == 0) {
code_r0x000180011842:
                    uVar7 = (**(code **)(*piVar8 + 0x18))(piVar8, uVar12);
                } else {
                    iVar2 = *(int32_t *)piVar8[0xb];
                    if (iVar2 < 1) goto code_r0x000180011842;
                    *(int32_t *)piVar8[0xb] = iVar2 + -1;
                    puVar3 = *(uint8_t **)piVar8[8];
                    *(uint8_t **)piVar8[8] = puVar3 + 1;
                    *puVar3 = (uint8_t)arg_28h;
                    uVar7 = uVar12;
                }
                if (uVar7 == 0xffffffff) goto code_r0x000180011852;
            }
        }
        *(undefined *)arg2 = uVar13;
        *(undefined4 *)(arg2 + 1) = *(undefined4 *)(var_d8h + 1);
        *(undefined2 *)(arg2 + 5) = *(undefined2 *)(var_d8h + 5);
        *(undefined *)(arg2 + 7) = *(undefined *)(var_d8h + 7);
        *(int64_t **)(arg2 + 8) = piVar8;
        if (0xf < (uint64_t)var_b8h) {
            uVar10 = iVar6;
            puVar11 = auStack_108;
            if (0xfff < var_b8h + 1U) {
                uVar10 = *(uint64_t *)(iVar6 + -8);
                uVar16 = (iVar6 - uVar10) - 8;
                puVar11 = auStack_108;
                if (0x1f < uVar16) {
                    pcVar4 = (code *)swi(0x29);
                    (*pcVar4)(5);
                    uVar10 = uVar16;
                    puVar11 = auStack_100;
                }
            }
            *(undefined8 *)(puVar11 + -8) = 0x1800118c1;
            func_0x000180459c3c(uVar10);
        }
    }
    *(undefined8 *)(puVar11 + -8) = 0x1800118d4;
    func_0x000180459870(*(uint64_t *)(puVar11 + 0x90) ^ (uint64_t)puVar11);
    return;
}

// ============================================================
// Function: FUN_180011900
// Address: 0x180011900
// Size: 1698 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180011900(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_40h)
{
    uint8_t uVar1;
    int32_t iVar2;
    uint8_t *puVar3;
    code *pcVar4;
    undefined uVar5;
    undefined uVar6;
    char cVar7;
    uint32_t uVar8;
    undefined8 *puVar9;
    uint64_t uVar10;
    int64_t *piVar11;
    undefined8 uVar12;
    uint64_t uVar13;
    undefined *puVar14;
    undefined *puVar15;
    undefined *puVar16;
    int64_t iVar17;
    int64_t iVar18;
    int64_t iVar19;
    int64_t *piVar20;
    uint8_t *puVar21;
    int64_t var_8h;
    undefined8 uStack_100;
    undefined auStack_f8 [8];
    undefined auStack_f0 [24];
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    puVar15 = auStack_f8;
    puVar14 = auStack_f8;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_f8;
    uVar13 = arg_28h & 0xff;
    if ((arg_38h == 0) || ((*(char *)arg_30h - 0x2bU & 0xfd) != 0)) {
        var_c0h = 0;
    } else {
        var_c0h = 1;
    }
    if ((*(uint32_t *)(arg4 + 0x18) & 0x3000) == 0x3000) {
        uVar12 = 0x1805ab2e0;
        if (((var_c0h + 2U <= (uint64_t)arg_38h) && (*(char *)(arg_30h + var_c0h) == '0')) &&
           ((*(char *)(arg_30h + 1 + var_c0h) + 0xa8U & 0xdf) == 0)) {
            var_c0h = var_c0h + 2U;
        }
    } else {
        uVar12 = 0x1805ab2dc;
    }
    iVar19 = var_c0h;
    var_b8h = arg3;
    var_b0h = arg4;
    var_a0h = arg2;
    var_a8h = func_0x000180461e90(arg_30h, uVar12);
    var_c8h._0_2_ = 0x2e;
    puVar9 = (undefined8 *)func_0x000180467ba0();
    var_c8h._0_2_ = CONCAT11(var_c8h._1_1_, *(undefined *)*puVar9);
    uVar10 = func_0x000180461e90(arg_30h, &var_c8h);
    piVar20 = *(int64_t **)(*(int64_t *)(arg4 + 0x40) + 8);
    var_90h = (int64_t)piVar20;
    (**(code **)(*piVar20 + 8))(piVar20);
    piVar11 = (int64_t *)func_0x00018000a390(&var_98h);
    puVar9 = (undefined8 *)(**(code **)(*piVar20 + 0x10))(piVar20);
    if (puVar9 != (undefined8 *)0x0) {
        (**(code **)*puVar9)(puVar9, 1);
    }
    func_0x0001800106c0(&var_88h, arg_38h, 0);
    piVar20 = &var_88h;
    if (0xf < (uint64_t)var_70h) {
        piVar20 = (int64_t *)var_88h;
    }
    (**(code **)(*piVar11 + 0x38))(piVar11, arg_30h, arg_38h + arg_30h, piVar20);
    piVar20 = *(int64_t **)(*(int64_t *)(var_b0h + 0x40) + 8);
    var_90h = (int64_t)piVar20;
    (**(code **)(*piVar20 + 8))(piVar20);
    piVar11 = (int64_t *)func_0x000180011fb0(&var_98h);
    puVar9 = (undefined8 *)(**(code **)(*piVar20 + 0x10))(piVar20);
    if (puVar9 != (undefined8 *)0x0) {
        (**(code **)*puVar9)(puVar9, 1);
    }
    (**(code **)(*piVar11 + 0x28))(piVar11, &var_68h);
    uVar5 = (**(code **)(*piVar11 + 0x20))(piVar11);
    if (uVar10 != arg_38h) {
        uVar6 = (**(code **)(*piVar11 + 0x18))(piVar11);
        piVar20 = &var_88h;
        if (0xf < (uint64_t)var_70h) {
            piVar20 = (int64_t *)var_88h;
        }
        *(undefined *)((int64_t)piVar20 + uVar10) = uVar6;
    }
    if ((char)arg_40h != '\0') {
        if (uVar10 == arg_38h) {
            uVar10 = var_a8h;
        }
        piVar20 = &var_68h;
        if (0xf < (uint64_t)var_50h) {
            piVar20 = (int64_t *)CONCAT71(var_68h._1_7_, (undefined)var_68h);
        }
        cVar7 = *(char *)piVar20;
        if (cVar7 != '\x7f') {
            uVar6 = (undefined)var_c8h;
            do {
                if ((cVar7 < '\x01') || (uVar10 - iVar19 <= (uint64_t)(int64_t)*(char *)piVar20)) break;
                uVar10 = uVar10 - (int64_t)*(char *)piVar20;
                if ((uint64_t)var_78h < uVar10) goto code_r0x000180011f9c;
                if (var_70h == var_78h) {
                    var_d8h = 1;
                    var_d0h._0_1_ = uVar5;
                    func_0x000180012ca0(&var_88h, 1, uVar6, uVar10);
                } else {
                    piVar11 = &var_88h;
                    if (0xf < (uint64_t)var_70h) {
                        piVar11 = (int64_t *)var_88h;
                    }
                    puVar16 = (undefined *)((int64_t)piVar11 + uVar10);
                    iVar17 = var_78h - uVar10;
                    var_78h = var_78h + 1;
                    func_0x000180498030(puVar16 + 1, puVar16, iVar17 + 1);
                    *puVar16 = uVar5;
                }
                if ('\0' < *(char *)(int64_t *)((int64_t)piVar20 + 1)) {
                    piVar20 = (int64_t *)((int64_t)piVar20 + 1);
                }
                cVar7 = *(char *)piVar20;
            } while (cVar7 != '\x7f');
        }
    }
    iVar19 = var_78h;
    uVar10 = *(uint64_t *)(var_b0h + 0x28);
    if (((int64_t)uVar10 < 1) || (uVar10 <= (uint64_t)var_78h)) {
        iVar17 = 0;
    } else {
        iVar17 = uVar10 - var_78h;
    }
    uVar8 = *(uint32_t *)(var_b0h + 0x18) & 0x1c0;
    if (uVar8 == 0x40) {
        piVar20 = &var_88h;
        if (0xf < (uint64_t)var_70h) {
            piVar20 = (int64_t *)var_88h;
        }
        uVar5 = *(undefined *)var_b8h;
        piVar11 = *(int64_t **)(var_b8h + 8);
        for (iVar18 = var_c0h; iVar18 != 0; iVar18 = iVar18 + -1) {
            if (piVar11 == (int64_t *)0x0) {
code_r0x000180011ddf:
                uVar5 = 1;
            } else {
                uVar1 = *(uint8_t *)piVar20;
                if (*(int64_t *)piVar11[8] == 0) {
code_r0x000180011dce:
                    uVar8 = (**(code **)(*piVar11 + 0x18))(piVar11, uVar1);
                } else {
                    iVar2 = *(int32_t *)piVar11[0xb];
                    if (iVar2 < 1) goto code_r0x000180011dce;
                    *(int32_t *)piVar11[0xb] = iVar2 + -1;
                    puVar21 = *(uint8_t **)piVar11[8];
                    *(uint8_t **)piVar11[8] = puVar21 + 1;
                    *puVar21 = uVar1;
                    uVar8 = (uint32_t)uVar1;
                }
                if (uVar8 == 0xffffffff) goto code_r0x000180011ddf;
            }
            piVar20 = (int64_t *)((int64_t)piVar20 + 1);
        }
    } else {
        uVar5 = *(undefined *)var_b8h;
        piVar20 = *(int64_t **)(var_b8h + 8);
        if (uVar8 == 0x100) {
            piVar11 = &var_88h;
            iVar18 = var_c0h;
            if (0xf < (uint64_t)var_70h) {
                piVar11 = (int64_t *)var_88h;
            }
            for (; iVar18 != 0; iVar18 = iVar18 + -1) {
                if (piVar20 == (int64_t *)0x0) {
code_r0x000180011d0c:
                    uVar5 = 1;
                } else {
                    uVar1 = *(uint8_t *)piVar11;
                    if (*(int64_t *)piVar20[8] == 0) {
code_r0x000180011cfb:
                        uVar8 = (**(code **)(*piVar20 + 0x18))(piVar20, uVar1);
                    } else {
                        iVar2 = *(int32_t *)piVar20[0xb];
                        if (iVar2 < 1) goto code_r0x000180011cfb;
                        *(int32_t *)piVar20[0xb] = iVar2 + -1;
                        puVar21 = *(uint8_t **)piVar20[8];
                        *(uint8_t **)piVar20[8] = puVar21 + 1;
                        *puVar21 = uVar1;
                        uVar8 = (uint32_t)uVar1;
                    }
                    if (uVar8 == 0xffffffff) goto code_r0x000180011d0c;
                }
                piVar11 = (int64_t *)((int64_t)piVar11 + 1);
            }
            for (; iVar17 != 0; iVar17 = iVar17 + -1) {
                if (piVar20 == (int64_t *)0x0) {
code_r0x000180011d64:
                    uVar5 = 1;
                } else {
                    if (*(int64_t *)piVar20[8] == 0) {
code_r0x000180011d53:
                        uVar8 = (**(code **)(*piVar20 + 0x18))(piVar20, uVar13);
                    } else {
                        iVar2 = *(int32_t *)piVar20[0xb];
                        if (iVar2 < 1) goto code_r0x000180011d53;
                        *(int32_t *)piVar20[0xb] = iVar2 + -1;
                        puVar21 = *(uint8_t **)piVar20[8];
                        *(uint8_t **)piVar20[8] = puVar21 + 1;
                        *puVar21 = (uint8_t)arg_28h;
                        uVar8 = (uint32_t)(uint8_t)arg_28h;
                    }
                    if (uVar8 == 0xffffffff) goto code_r0x000180011d64;
                }
            }
            iVar17 = 0;
        } else {
            for (; iVar17 != 0; iVar17 = iVar17 + -1) {
                if (piVar20 == (int64_t *)0x0) {
code_r0x000180011c27:
                    uVar5 = 1;
                } else {
                    if (*(int64_t *)piVar20[8] == 0) {
code_r0x000180011c16:
                        uVar8 = (**(code **)(*piVar20 + 0x18))(piVar20, uVar13);
                    } else {
                        iVar2 = *(int32_t *)piVar20[0xb];
                        if (iVar2 < 1) goto code_r0x000180011c16;
                        *(int32_t *)piVar20[0xb] = iVar2 + -1;
                        puVar21 = *(uint8_t **)piVar20[8];
                        *(uint8_t **)piVar20[8] = puVar21 + 1;
                        *puVar21 = (uint8_t)arg_28h;
                        uVar8 = (uint32_t)(uint8_t)arg_28h;
                    }
                    if (uVar8 == 0xffffffff) goto code_r0x000180011c27;
                }
            }
            iVar17 = 0;
            piVar11 = &var_88h;
            iVar18 = var_c0h;
            if (0xf < (uint64_t)var_70h) {
                piVar11 = (int64_t *)var_88h;
            }
            for (; iVar18 != 0; iVar18 = iVar18 + -1) {
                if (piVar20 == (int64_t *)0x0) {
code_r0x000180011c98:
                    uVar5 = 1;
                } else {
                    uVar1 = *(uint8_t *)piVar11;
                    if (*(int64_t *)piVar20[8] == 0) {
code_r0x000180011c87:
                        uVar8 = (**(code **)(*piVar20 + 0x18))(piVar20, uVar1);
                    } else {
                        iVar2 = *(int32_t *)piVar20[0xb];
                        if (iVar2 < 1) goto code_r0x000180011c87;
                        *(int32_t *)piVar20[0xb] = iVar2 + -1;
                        puVar21 = *(uint8_t **)piVar20[8];
                        *(uint8_t **)piVar20[8] = puVar21 + 1;
                        *puVar21 = uVar1;
                        uVar8 = (uint32_t)uVar1;
                    }
                    if (uVar8 == 0xffffffff) goto code_r0x000180011c98;
                }
                piVar11 = (int64_t *)((int64_t)piVar11 + 1);
            }
        }
    }
    iVar18 = var_b8h;
    piVar20 = &var_88h;
    if (0xf < (uint64_t)var_70h) {
        piVar20 = (int64_t *)var_88h;
    }
    puVar21 = (uint8_t *)((int64_t)piVar20 + var_c0h);
    piVar20 = *(int64_t **)(var_b8h + 8);
    for (iVar19 = iVar19 - var_c0h; iVar19 != 0; iVar19 = iVar19 + -1) {
        if (piVar20 == (int64_t *)0x0) {
code_r0x000180011e58:
            uVar5 = 1;
        } else {
            uVar1 = *puVar21;
            if (*(int64_t *)piVar20[8] == 0) {
code_r0x000180011e47:
                uVar8 = (**(code **)(*piVar20 + 0x18))(piVar20, uVar1);
            } else {
                iVar2 = *(int32_t *)piVar20[0xb];
                if (iVar2 < 1) goto code_r0x000180011e47;
                *(int32_t *)piVar20[0xb] = iVar2 + -1;
                puVar3 = *(uint8_t **)piVar20[8];
                *(uint8_t **)piVar20[8] = puVar3 + 1;
                *puVar3 = uVar1;
                uVar8 = (uint32_t)uVar1;
            }
            if (uVar8 == 0xffffffff) goto code_r0x000180011e58;
        }
        puVar21 = puVar21 + 1;
    }
    *(undefined8 *)(var_b0h + 0x28) = 0;
    for (; iVar17 != 0; iVar17 = iVar17 + -1) {
        if (piVar20 == (int64_t *)0x0) {
code_r0x000180011eb7:
            uVar5 = 1;
        } else {
            if (*(int64_t *)piVar20[8] == 0) {
code_r0x000180011ea6:
                uVar8 = (**(code **)(*piVar20 + 0x18))(piVar20, uVar13);
            } else {
                iVar2 = *(int32_t *)piVar20[0xb];
                if (iVar2 < 1) goto code_r0x000180011ea6;
                *(int32_t *)piVar20[0xb] = iVar2 + -1;
                puVar21 = *(uint8_t **)piVar20[8];
                *(uint8_t **)piVar20[8] = puVar21 + 1;
                *puVar21 = (uint8_t)arg_28h;
                uVar8 = (uint32_t)(uint8_t)arg_28h;
            }
            if (uVar8 == 0xffffffff) goto code_r0x000180011eb7;
        }
    }
    *(undefined *)var_a0h = uVar5;
    *(undefined4 *)(var_a0h + 1) = *(undefined4 *)(iVar18 + 1);
    *(undefined2 *)(var_a0h + 5) = *(undefined2 *)(iVar18 + 5);
    *(undefined *)(var_a0h + 7) = *(undefined *)(iVar18 + 7);
    *(int64_t **)(var_a0h + 8) = piVar20;
    if (0xf < (uint64_t)var_50h) {
        uVar13 = var_50h + 1;
        iVar17 = CONCAT71(var_68h._1_7_, (undefined)var_68h);
        iVar19 = iVar17;
        if (0xfff < uVar13) {
            iVar19 = *(int64_t *)(iVar17 + -8);
            if (0x1f < (iVar17 - iVar19) - 8U) {
                pcVar4 = (code *)swi(0x29);
                (*pcVar4)(5);
                puVar14 = auStack_f0;
                goto code_r0x000180011f95;
            }
            uVar13 = var_50h + 0x28;
        }
        func_0x000180459c3c(iVar19, uVar13);
    }
    var_58h = 0;
    var_50h = 0xf;
    var_68h._0_1_ = 0;
    if (0xf < (uint64_t)var_70h) {
        uVar13 = var_70h + 1;
        iVar19 = var_88h;
        if (0xfff < uVar13) {
            iVar19 = *(int64_t *)(var_88h + -8);
            if (0x1f < (var_88h - iVar19) - 8U) {
code_r0x000180011f95:
                pcVar4 = (code *)swi(0x29);
                (*pcVar4)(5);
                puVar15 = puVar14 + 8;
code_r0x000180011f9c:
                *(undefined8 *)(puVar15 + -8) = 0x180011fa1;
                func_0x00018000f930();
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            uVar13 = var_70h + 0x28;
        }
        func_0x000180459c3c(iVar19, uVar13);
    }
    func_0x000180459870(var_48h ^ (uint64_t)auStack_f8);
    return;
}

// ============================================================
// Function: FUN_180011fb0
// Address: 0x180011fb0
// Size: 271 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.180011fb0(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    func_0x000180455714(&var_10h, 0);
    iVar5 = *(int64_t *)0x180782448;
    var_18h = *(int64_t *)0x180782448;
    if (*(uint64_t *)0x1807827a0 == 0) {
        func_0x000180455714(&var_8h, 0);
        if (*(uint64_t *)0x1807827a0 == 0) {
            *(int32_t *)0x180780f30 = *(int32_t *)0x180780f30 + 1;
            *(uint64_t *)0x1807827a0 = (uint64_t)*(int32_t *)0x180780f30;
        }
        func_0x00018045578c();
    }
    uVar3 = *(uint64_t *)0x1807827a0;
    iVar4 = *(int64_t *)(arg1 + 8);
    iVar1 = *(uint64_t *)0x1807827a0 * 8;
    if (*(uint64_t *)0x1807827a0 < *(uint64_t *)(iVar4 + 0x18)) {
        iVar6 = *(int64_t *)(iVar1 + *(int64_t *)(iVar4 + 0x10));
        if (iVar6 != 0) goto code_r0x000180012043;
    } else {
        iVar6 = 0;
    }
    if (*(char *)(iVar4 + 0x24) == '\0') {
code_r0x000180012078:
        if (iVar6 != 0) goto code_r0x000180012043;
    } else {
        iVar4 = func_0x0001804558e0();
        if (uVar3 < *(uint64_t *)(iVar4 + 0x18)) {
            iVar6 = *(int64_t *)(iVar1 + *(int64_t *)(iVar4 + 0x10));
            goto code_r0x000180012078;
        }
    }
    iVar6 = iVar5;
    if (iVar5 == 0) {
        iVar5 = func_0x0001800129e0(&var_18h, arg1);
        iVar6 = var_18h;
        if (iVar5 == -1) {
            func_0x000180005b10();
            pcVar2 = (code *)swi(3);
            iVar5 = (*pcVar2)();
            return iVar5;
        }
        iVar5 = var_18h;
        var_8h = var_18h;
        func_0x0001804558a4(var_18h);
        (**(code **)(*(int64_t *)iVar6 + 8))(iVar6);
        *(int64_t *)0x180782448 = iVar5;
    }
code_r0x000180012043:
    func_0x00018045578c(&var_10h);
    return iVar6;
}

// ============================================================
// Function: FUN_1800120c0
// Address: 0x1800120c0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800120c0(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int64_t var_8h;
    
    uVar1 = *(undefined8 *)(arg1 + 0x28);
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0;
    uVar2 = fcn.180498cd0(uVar1);
    fcn.180004830(arg2, uVar1, uVar2);
    return arg2;
}

// ============================================================
// Function: FUN_180012110
// Address: 0x180012110
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180012110(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int64_t var_8h;
    
    uVar1 = *(undefined8 *)(arg1 + 0x20);
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0;
    uVar2 = fcn.180498cd0(uVar1);
    fcn.180004830(arg2, uVar1, uVar2);
    return arg2;
}

// ============================================================
// Function: FUN_180012160
// Address: 0x180012160
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180012160(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int64_t var_8h;
    
    uVar1 = *(undefined8 *)(arg1 + 0x10);
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0;
    uVar2 = fcn.180498cd0(uVar1);
    fcn.180004830(arg2, uVar1, uVar2);
    return arg2;
}

// ============================================================
// Function: FUN_1800121d0
// Address: 0x1800121d0
// Size: 1571 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800121d0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h)
{
    char cVar1;
    uint8_t uVar2;
    int32_t iVar3;
    uint64_t uVar4;
    uint8_t *puVar5;
    code *pcVar6;
    int64_t iVar7;
    undefined uVar8;
    uint32_t uVar9;
    int64_t *piVar10;
    undefined8 *puVar11;
    uint64_t uVar12;
    undefined *puVar13;
    undefined *puVar14;
    int64_t *piVar15;
    undefined *puVar16;
    int64_t iVar17;
    int64_t iVar18;
    uint8_t *puVar19;
    int64_t var_8h;
    undefined8 uStack_f0;
    undefined auStack_e8 [8];
    undefined auStack_e0 [24];
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    puVar14 = auStack_e8;
    puVar13 = auStack_e8;
    var_40h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_e8;
    uVar12 = arg_28h & 0xff;
    if ((arg_38h == 0) || ((*(char *)arg_30h - 0x2bU & 0xfd) != 0)) {
        var_b0h = 0;
    } else {
        var_b0h = 1;
    }
    if (((((*(uint32_t *)(arg4 + 0x18) & 0xe00) == 0x800) && (var_b0h + 2U <= (uint64_t)arg_38h)) &&
        (*(char *)(arg_30h + var_b0h) == '0')) && ((*(char *)(arg_30h + 1 + var_b0h) + 0xa8U & 0xdf) == 0)) {
        var_b0h = var_b0h + 2U;
    }
    iVar18 = var_b0h;
    piVar15 = *(int64_t **)(*(int64_t *)(arg4 + 0x40) + 8);
    var_a8h = arg3;
    var_a0h = arg4;
    var_98h = arg2;
    var_88h = (int64_t)piVar15;
    (**(code **)(*piVar15 + 8))(piVar15);
    piVar10 = (int64_t *)func_0x00018000a390(&var_90h);
    puVar11 = (undefined8 *)(**(code **)(*piVar15 + 0x10))(piVar15);
    if (puVar11 != (undefined8 *)0x0) {
        (**(code **)*puVar11)(puVar11, 1);
    }
    func_0x0001800106c0(&var_80h, arg_38h, 0);
    piVar15 = &var_80h;
    if (0xf < (uint64_t)var_68h) {
        piVar15 = (int64_t *)var_80h;
    }
    (**(code **)(*piVar10 + 0x38))(piVar10, arg_30h, arg_38h + arg_30h, piVar15);
    piVar15 = *(int64_t **)(*(int64_t *)(var_a0h + 0x40) + 8);
    var_88h = (int64_t)piVar15;
    (**(code **)(*piVar15 + 8))(piVar15);
    piVar10 = (int64_t *)fcn.180011fb0((int64_t)&var_90h);
    puVar11 = (undefined8 *)(**(code **)(*piVar15 + 0x10))(piVar15);
    if (puVar11 != (undefined8 *)0x0) {
        (**(code **)*puVar11)(puVar11, 1);
    }
    (**(code **)(*piVar10 + 0x28))(piVar10, &var_60h);
    piVar15 = &var_60h;
    if (0xf < (uint64_t)var_48h) {
        piVar15 = (int64_t *)CONCAT71(var_60h._1_7_, (undefined)var_60h);
    }
    if ((uint8_t)(*(char *)piVar15 - 1U) < 0x7e) {
        uVar8 = (**(code **)(*piVar10 + 0x20))(piVar10);
        cVar1 = *(char *)piVar15;
        arg3 = var_a8h;
        while (((var_a8h = arg3, cVar1 != '\x7f' && ('\0' < cVar1)) &&
               ((uint64_t)(int64_t)*(char *)piVar15 < (uint64_t)(arg_38h - iVar18)))) {
            arg_38h = arg_38h - *(char *)piVar15;
            if ((uint64_t)var_70h < (uint64_t)arg_38h) goto code_r0x0001800127ed;
            if (var_68h == var_70h) {
                var_c8h = 1;
                var_c0h._0_1_ = uVar8;
                func_0x000180012ca0(&var_80h, 1, (undefined)var_b8h, arg_38h);
            } else {
                piVar10 = &var_80h;
                if (0xf < (uint64_t)var_68h) {
                    piVar10 = (int64_t *)var_80h;
                }
                puVar16 = (undefined *)((int64_t)piVar10 + arg_38h);
                iVar17 = var_70h - arg_38h;
                var_70h = var_70h + 1;
                fcn.180498030(puVar16 + 1, puVar16, iVar17 + 1);
                *puVar16 = uVar8;
            }
            if ('\0' < *(char *)(int64_t *)((int64_t)piVar15 + 1)) {
                piVar15 = (int64_t *)((int64_t)piVar15 + 1);
            }
            cVar1 = *(char *)piVar15;
            arg3 = var_a8h;
        }
    }
    iVar18 = var_70h;
    uVar4 = *(uint64_t *)(var_a0h + 0x28);
    if (((int64_t)uVar4 < 1) || (uVar4 <= (uint64_t)var_70h)) {
        iVar17 = 0;
    } else {
        iVar17 = uVar4 - var_70h;
    }
    uVar9 = *(uint32_t *)(var_a0h + 0x18) & 0x1c0;
    uVar8 = *(undefined *)arg3;
    piVar15 = *(int64_t **)(arg3 + 8);
    if (uVar9 == 0x40) {
        piVar10 = &var_80h;
        iVar7 = var_b0h;
        if (0xf < (uint64_t)var_68h) {
            piVar10 = (int64_t *)var_80h;
        }
        for (; iVar7 != 0; iVar7 = iVar7 + -1) {
            if (piVar15 == (int64_t *)0x0) {
code_r0x000180012638:
                uVar8 = 1;
            } else {
                uVar2 = *(uint8_t *)piVar10;
                if (*(int64_t *)piVar15[8] == 0) {
code_r0x000180012627:
                    uVar9 = (**(code **)(*piVar15 + 0x18))(piVar15, uVar2);
                } else {
                    iVar3 = *(int32_t *)piVar15[0xb];
                    if (iVar3 < 1) goto code_r0x000180012627;
                    *(int32_t *)piVar15[0xb] = iVar3 + -1;
                    puVar19 = *(uint8_t **)piVar15[8];
                    *(uint8_t **)piVar15[8] = puVar19 + 1;
                    *puVar19 = uVar2;
                    uVar9 = (uint32_t)uVar2;
                }
                if (uVar9 == 0xffffffff) goto code_r0x000180012638;
            }
            piVar10 = (int64_t *)((int64_t)piVar10 + 1);
        }
    } else if (uVar9 == 0x100) {
        piVar10 = &var_80h;
        iVar7 = var_b0h;
        if (0xf < (uint64_t)var_68h) {
            piVar10 = (int64_t *)var_80h;
        }
        for (; iVar7 != 0; iVar7 = iVar7 + -1) {
            if (piVar15 == (int64_t *)0x0) {
code_r0x00018001256d:
                uVar8 = 1;
            } else {
                uVar2 = *(uint8_t *)piVar10;
                if (*(int64_t *)piVar15[8] == 0) {
code_r0x00018001255c:
                    uVar9 = (**(code **)(*piVar15 + 0x18))(piVar15, uVar2);
                } else {
                    iVar3 = *(int32_t *)piVar15[0xb];
                    if (iVar3 < 1) goto code_r0x00018001255c;
                    *(int32_t *)piVar15[0xb] = iVar3 + -1;
                    puVar19 = *(uint8_t **)piVar15[8];
                    *(uint8_t **)piVar15[8] = puVar19 + 1;
                    *puVar19 = uVar2;
                    uVar9 = (uint32_t)uVar2;
                }
                if (uVar9 == 0xffffffff) goto code_r0x00018001256d;
            }
            piVar10 = (int64_t *)((int64_t)piVar10 + 1);
        }
        for (; iVar17 != 0; iVar17 = iVar17 + -1) {
            if (piVar15 == (int64_t *)0x0) {
code_r0x0001800125c4:
                uVar8 = 1;
            } else {
                if (*(int64_t *)piVar15[8] == 0) {
code_r0x0001800125b3:
                    uVar9 = (**(code **)(*piVar15 + 0x18))(piVar15, uVar12);
                } else {
                    iVar3 = *(int32_t *)piVar15[0xb];
                    if (iVar3 < 1) goto code_r0x0001800125b3;
                    *(int32_t *)piVar15[0xb] = iVar3 + -1;
                    puVar19 = *(uint8_t **)piVar15[8];
                    *(uint8_t **)piVar15[8] = puVar19 + 1;
                    *puVar19 = (uint8_t)arg_28h;
                    uVar9 = (uint32_t)(uint8_t)arg_28h;
                }
                if (uVar9 == 0xffffffff) goto code_r0x0001800125c4;
            }
        }
        iVar17 = 0;
    } else {
        for (; iVar17 != 0; iVar17 = iVar17 + -1) {
            if (piVar15 == (int64_t *)0x0) {
code_r0x00018001248a:
                uVar8 = 1;
            } else {
                if (*(int64_t *)piVar15[8] == 0) {
code_r0x000180012479:
                    uVar9 = (**(code **)(*piVar15 + 0x18))(piVar15, uVar12);
                } else {
                    iVar3 = *(int32_t *)piVar15[0xb];
                    if (iVar3 < 1) goto code_r0x000180012479;
                    *(int32_t *)piVar15[0xb] = iVar3 + -1;
                    puVar19 = *(uint8_t **)piVar15[8];
                    *(uint8_t **)piVar15[8] = puVar19 + 1;
                    *puVar19 = (uint8_t)arg_28h;
                    uVar9 = (uint32_t)(uint8_t)arg_28h;
                }
                if (uVar9 == 0xffffffff) goto code_r0x00018001248a;
            }
        }
        iVar17 = 0;
        piVar10 = &var_80h;
        iVar7 = var_b0h;
        if (0xf < (uint64_t)var_68h) {
            piVar10 = (int64_t *)var_80h;
        }
        for (; iVar7 != 0; iVar7 = iVar7 + -1) {
            if (piVar15 == (int64_t *)0x0) {
code_r0x0001800124fa:
                uVar8 = 1;
            } else {
                uVar2 = *(uint8_t *)piVar10;
                if (*(int64_t *)piVar15[8] == 0) {
code_r0x0001800124e9:
                    uVar9 = (**(code **)(*piVar15 + 0x18))(piVar15, uVar2);
                } else {
                    iVar3 = *(int32_t *)piVar15[0xb];
                    if (iVar3 < 1) goto code_r0x0001800124e9;
                    *(int32_t *)piVar15[0xb] = iVar3 + -1;
                    puVar19 = *(uint8_t **)piVar15[8];
                    *(uint8_t **)piVar15[8] = puVar19 + 1;
                    *puVar19 = uVar2;
                    uVar9 = (uint32_t)uVar2;
                }
                if (uVar9 == 0xffffffff) goto code_r0x0001800124fa;
            }
            piVar10 = (int64_t *)((int64_t)piVar10 + 1);
        }
    }
    iVar7 = var_a8h;
    piVar15 = &var_80h;
    if (0xf < (uint64_t)var_68h) {
        piVar15 = (int64_t *)var_80h;
    }
    puVar19 = (uint8_t *)((int64_t)piVar15 + var_b0h);
    piVar15 = *(int64_t **)(var_a8h + 8);
    for (iVar18 = iVar18 - var_b0h; iVar18 != 0; iVar18 = iVar18 + -1) {
        if (piVar15 == (int64_t *)0x0) {
code_r0x0001800126ac:
            uVar8 = 1;
        } else {
            uVar2 = *puVar19;
            if (*(int64_t *)piVar15[8] == 0) {
code_r0x00018001269b:
                uVar9 = (**(code **)(*piVar15 + 0x18))(piVar15, uVar2);
            } else {
                iVar3 = *(int32_t *)piVar15[0xb];
                if (iVar3 < 1) goto code_r0x00018001269b;
                *(int32_t *)piVar15[0xb] = iVar3 + -1;
                puVar5 = *(uint8_t **)piVar15[8];
                *(uint8_t **)piVar15[8] = puVar5 + 1;
                *puVar5 = uVar2;
                uVar9 = (uint32_t)uVar2;
            }
            if (uVar9 == 0xffffffff) goto code_r0x0001800126ac;
        }
        puVar19 = puVar19 + 1;
    }
    *(undefined8 *)(var_a0h + 0x28) = 0;
    for (; iVar17 != 0; iVar17 = iVar17 + -1) {
        if (piVar15 == (int64_t *)0x0) {
code_r0x00018001270b:
            uVar8 = 1;
        } else {
            if (*(int64_t *)piVar15[8] == 0) {
code_r0x0001800126fa:
                uVar9 = (**(code **)(*piVar15 + 0x18))(piVar15, uVar12);
            } else {
                iVar3 = *(int32_t *)piVar15[0xb];
                if (iVar3 < 1) goto code_r0x0001800126fa;
                *(int32_t *)piVar15[0xb] = iVar3 + -1;
                puVar19 = *(uint8_t **)piVar15[8];
                *(uint8_t **)piVar15[8] = puVar19 + 1;
                *puVar19 = (uint8_t)arg_28h;
                uVar9 = (uint32_t)(uint8_t)arg_28h;
            }
            if (uVar9 == 0xffffffff) goto code_r0x00018001270b;
        }
    }
    *(undefined *)var_98h = uVar8;
    *(undefined4 *)(var_98h + 1) = *(undefined4 *)(iVar7 + 1);
    *(undefined2 *)(var_98h + 5) = *(undefined2 *)(iVar7 + 5);
    *(undefined *)(var_98h + 7) = *(undefined *)(iVar7 + 7);
    *(int64_t **)(var_98h + 8) = piVar15;
    if (0xf < (uint64_t)var_48h) {
        uVar12 = var_48h + 1;
        iVar17 = CONCAT71(var_60h._1_7_, (undefined)var_60h);
        iVar18 = iVar17;
        if (0xfff < uVar12) {
            iVar18 = *(int64_t *)(iVar17 + -8);
            if (0x1f < (iVar17 - iVar18) - 8U) {
                pcVar6 = (code *)swi(0x29);
                (*pcVar6)(5);
                puVar13 = auStack_e0;
                goto code_r0x0001800127e6;
            }
            uVar12 = var_48h + 0x28;
        }
        func_0x000180459c3c(iVar18, uVar12);
    }
    var_50h = 0;
    var_48h = 0xf;
    var_60h._0_1_ = 0;
    if (0xf < (uint64_t)var_68h) {
        uVar12 = var_68h + 1;
        iVar18 = var_80h;
        if (0xfff < uVar12) {
            iVar18 = *(int64_t *)(var_80h + -8);
            if (0x1f < (var_80h - iVar18) - 8U) {
code_r0x0001800127e6:
                pcVar6 = (code *)swi(0x29);
                (*pcVar6)(5);
                puVar14 = puVar13 + 8;
code_r0x0001800127ed:
                *(undefined8 *)(puVar14 + -8) = 0x1800127f2;
                func_0x00018000f930();
                pcVar6 = (code *)swi(3);
                (*pcVar6)();
                return;
            }
            uVar12 = var_68h + 0x28;
        }
        func_0x000180459c3c(iVar18, uVar12);
    }
    func_0x000180459870(var_40h ^ (uint64_t)auStack_e8);
    return;
}

// ============================================================
// Function: FUN_180012800
// Address: 0x180012800
// Size: 371 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180012800(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    code *pcVar2;
    undefined8 *puVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if ((arg1 != 0) && (*(int64_t *)arg1 == 0)) {
        puVar3 = (undefined8 *)fcn.180459890(0x10);
        iVar1 = *(int64_t *)(arg2 + 8);
        if (iVar1 == 0) {
            iVar5 = 0x1805aadb1;
        } else {
            iVar5 = *(int64_t *)(iVar1 + 0x28);
            if (iVar5 == 0) {
                iVar5 = iVar1 + 0x30;
            }
        }
        func_0x000180455714(&var_88h, 0);
        var_80h = 0;
        var_78h._0_1_ = 0;
        var_70h = 0;
        var_68h._0_1_ = 0;
        var_60h = 0;
        var_58h._0_2_ = 0;
        var_50h = 0;
        var_48h._0_2_ = 0;
        var_40h = 0;
        var_38h._0_1_ = 0;
        var_30h = 0;
        var_28h._0_1_ = 0;
        if (iVar5 == 0) {
            func_0x000180454740(0x1805aadd8);
            pcVar2 = (code *)swi(3);
            uVar4 = (*pcVar2)();
            return uVar4;
        }
        func_0x000180455a00(&var_88h, iVar5);
        *(undefined4 *)(puVar3 + 1) = 0;
        *puVar3 = 0x1804a6458;
        *(undefined8 **)arg1 = puVar3;
        func_0x000180455a6c(&var_88h);
        if (var_30h != 0) {
            func_0x000180460d90();
        }
        var_30h = 0;
        if (var_40h != 0) {
            func_0x000180460d90();
        }
        var_40h = 0;
        if (var_50h != 0) {
            func_0x000180460d90();
        }
        var_50h = 0;
        if (var_60h != 0) {
            func_0x000180460d90();
        }
        var_60h = 0;
        if (var_70h != 0) {
            func_0x000180460d90();
        }
        var_70h = 0;
        if (var_80h != 0) {
            func_0x000180460d90();
        }
        var_80h = 0;
        func_0x00018045578c(&var_88h);
    }
    return 4;
}

// ============================================================
// Function: FUN_180012980
// Address: 0x180012980
// Size: 94 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180012980(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    *(undefined8 *)arg1 = 0x1804a64c8;
    fcn.180460d90(*(undefined8 *)(arg1 + 0x10));
    fcn.180460d90(*(undefined8 *)(arg1 + 0x20));
    fcn.180460d90(*(undefined8 *)(arg1 + 0x28));
    *(undefined8 *)arg1 = 0x1804a5438;
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x30);
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800129e0
// Address: 0x1800129e0
// Size: 555 bytes
// ============================================================
undefined8 fcn.1800129e0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    code *pcVar2;
    undefined8 *puVar3;
    undefined *puVar4;
    undefined4 *puVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    
    if ((arg1 == 0) || (*(int64_t *)arg1 != 0)) {
        return 4;
    }
    puVar3 = (undefined8 *)fcn.180459890(0x30);
    iVar1 = *(int64_t *)(arg2 + 8);
    if (iVar1 == 0) {
        iVar7 = 0x1805aadb1;
    } else {
        iVar7 = *(int64_t *)(iVar1 + 0x28);
        if (iVar7 == 0) {
            iVar7 = iVar1 + 0x30;
        }
    }
    func_0x000180455714(&var_c8h, 0);
    var_c0h = 0;
    var_b8h._0_1_ = 0;
    var_b0h = 0;
    var_a8h._0_1_ = 0;
    var_a0h = 0;
    var_98h._0_2_ = 0;
    var_90h = 0;
    var_88h._0_2_ = 0;
    var_80h = 0;
    var_78h._0_1_ = 0;
    var_70h = 0;
    var_68h._0_1_ = 0;
    if (iVar7 != 0) {
        func_0x000180455a00(&var_c8h, iVar7);
        *(undefined4 *)(puVar3 + 1) = 0;
        *puVar3 = 0x1804a64c8;
        func_0x000180467ba0();
        func_0x0001804583bc(&var_60h);
        puVar3[2] = 0;
        puVar3[4] = 0;
        puVar3[5] = 0;
        puVar4 = (undefined *)func_0x000180461640(1);
        if (puVar4 == (undefined *)0x0) goto code_r0x000180012bff;
        *puVar4 = 0;
        puVar3[2] = puVar4;
        puVar5 = (undefined4 *)func_0x000180461640(6, 1);
        if (puVar5 == (undefined4 *)0x0) {
            fcn.180454670();
            pcVar2 = (code *)swi(3);
            uVar6 = (*pcVar2)();
            return uVar6;
        }
        *puVar5 = 0x736c6166;
        *(undefined2 *)(puVar5 + 1) = 0x65;
        puVar3[4] = puVar5;
        puVar5 = (undefined4 *)func_0x000180461640(5, 1);
        if (puVar5 != (undefined4 *)0x0) {
            *puVar5 = 0x65757274;
            *(undefined *)(puVar5 + 1) = 0;
            puVar3[5] = puVar5;
            *(undefined2 *)(puVar3 + 3) = 0x2c2e;
            *(undefined8 **)arg1 = puVar3;
            func_0x000180455a6c(&var_c8h);
            if (var_70h != 0) {
                fcn.180460d90();
            }
            var_70h = 0;
            if (var_80h != 0) {
                fcn.180460d90();
            }
            var_80h = 0;
            if (var_90h != 0) {
                fcn.180460d90();
            }
            var_90h = 0;
            if (var_a0h != 0) {
                fcn.180460d90();
            }
            var_a0h = 0;
            if (var_b0h != 0) {
                fcn.180460d90();
            }
            var_b0h = 0;
            if (var_c0h != 0) {
                fcn.180460d90();
            }
            var_c0h = 0;
            func_0x00018045578c(&var_c8h);
            return 4;
        }
        fcn.180454670();
    }
    func_0x000180454740(0x1805aadd8);
code_r0x000180012bff:
    fcn.180454670();
    pcVar2 = (code *)swi(3);
    uVar6 = (*pcVar2)();
    return uVar6;
}

// ============================================================
// Function: FUN_180012c10
// Address: 0x180012c10
// Size: 142 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180012c10(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t iVar6;
    undefined *puVar7;
    int64_t var_8h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    if (arg1 != arg2) {
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            iVar1 = *(int64_t *)arg1;
            iVar6 = iVar1;
            puVar7 = auStack_28;
            if ((0xfff < *(uint64_t *)(arg1 + 0x18) + 1) &&
               (iVar6 = *(int64_t *)(iVar1 + -8), puVar7 = auStack_28, 0x1f < (iVar1 - iVar6) - 8U)) {
                pcVar2 = (code *)swi(0x29);
                iVar6 = (*pcVar2)(5);
                puVar7 = auStack_20;
            }
            *(undefined8 *)(puVar7 + -8) = 0x180012c64;
            fcn.180459c3c(iVar6);
        }
        *(undefined8 *)(arg1 + 0x18) = 0xf;
        *(undefined8 *)(arg1 + 0x10) = 0;
        *(undefined *)arg1 = 0;
        uVar3 = *(undefined4 *)(arg2 + 4);
        uVar4 = *(undefined4 *)(arg2 + 8);
        uVar5 = *(undefined4 *)(arg2 + 0xc);
        *(undefined4 *)arg1 = *(undefined4 *)arg2;
        *(undefined4 *)(arg1 + 4) = uVar3;
        *(undefined4 *)(arg1 + 8) = uVar4;
        *(undefined4 *)(arg1 + 0xc) = uVar5;
        uVar3 = *(undefined4 *)(arg2 + 0x14);
        uVar4 = *(undefined4 *)(arg2 + 0x18);
        uVar5 = *(undefined4 *)(arg2 + 0x1c);
        *(undefined4 *)(arg1 + 0x10) = *(undefined4 *)(arg2 + 0x10);
        *(undefined4 *)(arg1 + 0x14) = uVar3;
        *(undefined4 *)(arg1 + 0x18) = uVar4;
        *(undefined4 *)(arg1 + 0x1c) = uVar5;
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined *)arg2 = 0;
    }
    return arg1;
}

// ============================================================
// Function: FUN_180012ca0
// Address: 0x180012ca0
// Size: 46 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180012ca0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    uint64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_48h;
    undefined auStack_40 [24];
    int64_t var_28h;
    
    piVar9 = &var_48h;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffffU - iVar3 < (uint64_t)arg2) {
        fcn.1800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar4 <= 0x7fffffffffffffff - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RDI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    fcn.180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x000180012d43;
            }
            unaff_RDI = fcn.180459890(uVar2);
        }
code_r0x000180012d6a:
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        iVar6 = unaff_RDI + arg4;
        iVar3 = (iVar3 - arg4) + 1;
        if (uVar4 < 0x10) {
            fcn.180498030(unaff_RDI, arg1, arg4);
            func_0x0001804986e0(iVar6, (int32_t)(char)arg_30h, arg_28h);
            fcn.180498030(arg_28h + iVar6, arg4 + arg1, iVar3);
            goto code_r0x000180012e24;
        }
        uVar8 = *(uint64_t *)arg1;
        fcn.180498030(unaff_RDI, uVar8, arg4);
        func_0x0001804986e0(iVar6, (int32_t)(char)arg_30h, arg_28h);
        fcn.180498030(arg_28h + iVar6, uVar8 + arg4, iVar3);
        if (0xfff < uVar4 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                fcn.180459c3c(*piVar1, uVar4 + 0x28);
                goto code_r0x000180012e24;
            }
            goto code_r0x000180012ded;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x000180012d43:
        iVar6 = fcn.180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x000180012d6a;
        }
code_r0x000180012ded:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        piVar9 = (int64_t *)auStack_40;
    }
    *(undefined8 *)((int64_t)piVar9 + -8) = 0x180012dfc;
    fcn.180459c3c(uVar8);
code_r0x000180012e24:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_180012cce
// Address: 0x180012cce
// Size: 379 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180012ca0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    uint64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_48h;
    undefined auStack_40 [24];
    int64_t var_28h;
    
    piVar9 = &var_48h;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffffU - iVar3 < (uint64_t)arg2) {
        fcn.1800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar4 <= 0x7fffffffffffffff - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RDI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    fcn.180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x000180012d43;
            }
            unaff_RDI = fcn.180459890(uVar2);
        }
code_r0x000180012d6a:
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        iVar6 = unaff_RDI + arg4;
        iVar3 = (iVar3 - arg4) + 1;
        if (uVar4 < 0x10) {
            fcn.180498030(unaff_RDI, arg1, arg4);
            func_0x0001804986e0(iVar6, (int32_t)(char)arg_30h, arg_28h);
            fcn.180498030(arg_28h + iVar6, arg4 + arg1, iVar3);
            goto code_r0x000180012e24;
        }
        uVar8 = *(uint64_t *)arg1;
        fcn.180498030(unaff_RDI, uVar8, arg4);
        func_0x0001804986e0(iVar6, (int32_t)(char)arg_30h, arg_28h);
        fcn.180498030(arg_28h + iVar6, uVar8 + arg4, iVar3);
        if (0xfff < uVar4 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                fcn.180459c3c(*piVar1, uVar4 + 0x28);
                goto code_r0x000180012e24;
            }
            goto code_r0x000180012ded;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x000180012d43:
        iVar6 = fcn.180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x000180012d6a;
        }
code_r0x000180012ded:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        piVar9 = (int64_t *)auStack_40;
    }
    *(undefined8 *)((int64_t)piVar9 + -8) = 0x180012dfc;
    fcn.180459c3c(uVar8);
code_r0x000180012e24:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_180012e49
// Address: 0x180012e49
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180012ca0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    uint64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_48h;
    undefined auStack_40 [24];
    int64_t var_28h;
    
    piVar9 = &var_48h;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffffU - iVar3 < (uint64_t)arg2) {
        fcn.1800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar4 <= 0x7fffffffffffffff - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RDI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    fcn.180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x000180012d43;
            }
            unaff_RDI = fcn.180459890(uVar2);
        }
code_r0x000180012d6a:
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        iVar6 = unaff_RDI + arg4;
        iVar3 = (iVar3 - arg4) + 1;
        if (uVar4 < 0x10) {
            fcn.180498030(unaff_RDI, arg1, arg4);
            func_0x0001804986e0(iVar6, (int32_t)(char)arg_30h, arg_28h);
            fcn.180498030(arg_28h + iVar6, arg4 + arg1, iVar3);
            goto code_r0x000180012e24;
        }
        uVar8 = *(uint64_t *)arg1;
        fcn.180498030(unaff_RDI, uVar8, arg4);
        func_0x0001804986e0(iVar6, (int32_t)(char)arg_30h, arg_28h);
        fcn.180498030(arg_28h + iVar6, uVar8 + arg4, iVar3);
        if (0xfff < uVar4 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                fcn.180459c3c(*piVar1, uVar4 + 0x28);
                goto code_r0x000180012e24;
            }
            goto code_r0x000180012ded;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x000180012d43:
        iVar6 = fcn.180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x000180012d6a;
        }
code_r0x000180012ded:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        piVar9 = (int64_t *)auStack_40;
    }
    *(undefined8 *)((int64_t)piVar9 + -8) = 0x180012dfc;
    fcn.180459c3c(uVar8);
code_r0x000180012e24:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_180012e4f
// Address: 0x180012e4f
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180012ca0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    uint64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_48h;
    undefined auStack_40 [24];
    int64_t var_28h;
    
    piVar9 = &var_48h;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffffU - iVar3 < (uint64_t)arg2) {
        fcn.1800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar4 <= 0x7fffffffffffffff - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RDI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    fcn.180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x000180012d43;
            }
            unaff_RDI = fcn.180459890(uVar2);
        }
code_r0x000180012d6a:
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        iVar6 = unaff_RDI + arg4;
        iVar3 = (iVar3 - arg4) + 1;
        if (uVar4 < 0x10) {
            fcn.180498030(unaff_RDI, arg1, arg4);
            func_0x0001804986e0(iVar6, (int32_t)(char)arg_30h, arg_28h);
            fcn.180498030(arg_28h + iVar6, arg4 + arg1, iVar3);
            goto code_r0x000180012e24;
        }
        uVar8 = *(uint64_t *)arg1;
        fcn.180498030(unaff_RDI, uVar8, arg4);
        func_0x0001804986e0(iVar6, (int32_t)(char)arg_30h, arg_28h);
        fcn.180498030(arg_28h + iVar6, uVar8 + arg4, iVar3);
        if (0xfff < uVar4 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                fcn.180459c3c(*piVar1, uVar4 + 0x28);
                goto code_r0x000180012e24;
            }
            goto code_r0x000180012ded;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x000180012d43:
        iVar6 = fcn.180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x000180012d6a;
        }
code_r0x000180012ded:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        piVar9 = (int64_t *)auStack_40;
    }
    *(undefined8 *)((int64_t)piVar9 + -8) = 0x180012dfc;
    fcn.180459c3c(uVar8);
code_r0x000180012e24:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_180012e60
// Address: 0x180012e60
// Size: 52 bytes
// ============================================================
void fcn.180012e60(int64_t arg1)
{
    undefined4 *puVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 == 0) {
        return;
    }
    fcn.180460d90(*(undefined8 *)(arg1 + 0x10));
    fcn.180460d90(*(undefined8 *)(arg1 + 0x20));
    if ((*(int64_t *)(arg1 + 0x28) != 0) &&
       (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, *(int64_t *)(arg1 + 0x28), in_R9, unaff_RBX),
       iVar2 == 0)) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18046b63c(uVar3);
        puVar1 = (undefined4 *)fcn.18046b77c();
        *puVar1 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_180012ea0
// Address: 0x180012ea0
// Size: 52 bytes
// ============================================================
void fcn.180012ea0(int64_t arg1)
{
    if (*(char *)(arg1 + 0x48) != '\0') {
        fcn.18000ace0(arg1 + 0x28);
        if (*(int64_t *)arg1 != 0) {
            fcn.1800f4640();
            *(undefined8 *)arg1 = 0;
            *(undefined8 *)(arg1 + 8) = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180012ee0
// Address: 0x180012ee0
// Size: 54 bytes
// ============================================================
void fcn.180012ee0(int64_t arg1)
{
    if (*(char *)(arg1 + 0x50) != '\0') {
        fcn.18000ace0(arg1 + 0x30);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.1800f4640();
            *(undefined8 *)(arg1 + 8) = 0;
            *(undefined8 *)(arg1 + 0x10) = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180012f20
// Address: 0x180012f20
// Size: 43 bytes
// ============================================================
int64_t fcn.180012f20(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x18061fdd0;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 8);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180012f50
// Address: 0x180012f50
// Size: 125 bytes
// ============================================================
undefined8 fcn.180012f50(void)
{
    int64_t unaff_GS_OFFSET;
    
    if (*(int32_t *)(*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
        *(int32_t *)0x1807827ac) {
        fcn.180459d18(0x1807827ac);
        if (*(int32_t *)0x1807827ac == -1) {
            *(undefined8 *)0x1807827b0 = fcn.180459890(1);
            fcn.180459c24(0x1804a2010);
            fcn.180459cac(0x1807827ac);
            return 0x1807827b0;
        }
    }
    return 0x1807827b0;
}

// ============================================================
// Function: FUN_180012fd0
// Address: 0x180012fd0
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180012fd0(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    uint32_t *puVar1;
    uint8_t uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t var_8h;
    int64_t var_18h;
    
    iVar3 = 0;
    if (arg3 != 0) {
        do {
            uVar2 = *(uint8_t *)(arg2 + (int64_t)iVar3 * 4);
            puVar1 = (uint32_t *)(arg2 + (int64_t)iVar3 * 4);
    // switch table (2 cases) at 0x18001305c
            switch(uVar2) {
            case 7:
            case 8:
            case 0xc:
            case 0xf:
            case 0x10:
            case 0x14:
            case 0x1b:
            case 0x1c:
            case 0x1d:
            case 0x1e:
            case 0x1f:
            case 0x20:
            case 0x35:
            case 0x37:
            case 0x3a:
            case 0x3c:
            case 0x42:
            case 0x4a:
            case 0x4b:
            case 0x4d:
            case 0x4e:
            case 0x4f:
            case 0x50:
            case 0x53:
            case 0x54:
            case 0x55:
            case 0x56:
            case 0x57:
            case 0x58:
                iVar4 = 2;
                break;
            default:
                iVar4 = 1;
            }
            iVar3 = iVar3 + iVar4;
            *puVar1 = (uint32_t)*(uint8_t *)((uint64_t)((uint32_t)uVar2 * 0xe3 & 0xff) + *(int64_t *)0x180782600) |
                      *puVar1 & 0xffffff00;
        } while ((uint64_t)(int64_t)iVar3 < (uint64_t)arg3);
    }
    return;
}

// ============================================================
// Function: FUN_180012fe0
// Address: 0x180012fe0
// Size: 121 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180012fd0(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    uint32_t *puVar1;
    uint8_t uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t var_8h;
    int64_t var_18h;
    
    iVar3 = 0;
    if (arg3 != 0) {
        do {
            uVar2 = *(uint8_t *)(arg2 + (int64_t)iVar3 * 4);
            puVar1 = (uint32_t *)(arg2 + (int64_t)iVar3 * 4);
    // switch table (2 cases) at 0x18001305c
            switch(uVar2) {
            case 7:
            case 8:
            case 0xc:
            case 0xf:
            case 0x10:
            case 0x14:
            case 0x1b:
            case 0x1c:
            case 0x1d:
            case 0x1e:
            case 0x1f:
            case 0x20:
            case 0x35:
            case 0x37:
            case 0x3a:
            case 0x3c:
            case 0x42:
            case 0x4a:
            case 0x4b:
            case 0x4d:
            case 0x4e:
            case 0x4f:
            case 0x50:
            case 0x53:
            case 0x54:
            case 0x55:
            case 0x56:
            case 0x57:
            case 0x58:
                iVar4 = 2;
                break;
            default:
                iVar4 = 1;
            }
            iVar3 = iVar3 + iVar4;
            *puVar1 = (uint32_t)*(uint8_t *)((uint64_t)((uint32_t)uVar2 * 0xe3 & 0xff) + *(int64_t *)0x180782600) |
                      *puVar1 & 0xffffff00;
        } while ((uint64_t)(int64_t)iVar3 < (uint64_t)arg3);
    }
    return;
}

// ============================================================
// Function: FUN_180013059
// Address: 0x180013059
// Size: 93 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180012fd0(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    uint32_t *puVar1;
    uint8_t uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t var_8h;
    int64_t var_18h;
    
    iVar3 = 0;
    if (arg3 != 0) {
        do {
            uVar2 = *(uint8_t *)(arg2 + (int64_t)iVar3 * 4);
            puVar1 = (uint32_t *)(arg2 + (int64_t)iVar3 * 4);
    // switch table (2 cases) at 0x18001305c
            switch(uVar2) {
            case 7:
            case 8:
            case 0xc:
            case 0xf:
            case 0x10:
            case 0x14:
            case 0x1b:
            case 0x1c:
            case 0x1d:
            case 0x1e:
            case 0x1f:
            case 0x20:
            case 0x35:
            case 0x37:
            case 0x3a:
            case 0x3c:
            case 0x42:
            case 0x4a:
            case 0x4b:
            case 0x4d:
            case 0x4e:
            case 0x4f:
            case 0x50:
            case 0x53:
            case 0x54:
            case 0x55:
            case 0x56:
            case 0x57:
            case 0x58:
                iVar4 = 2;
                break;
            default:
                iVar4 = 1;
            }
            iVar3 = iVar3 + iVar4;
            *puVar1 = (uint32_t)*(uint8_t *)((uint64_t)((uint32_t)uVar2 * 0xe3 & 0xff) + *(int64_t *)0x180782600) |
                      *puVar1 & 0xffffff00;
        } while ((uint64_t)(int64_t)iVar3 < (uint64_t)arg3);
    }
    return;
}

// ============================================================
// Function: FUN_1800130c0
// Address: 0x1800130c0
// Size: 215 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_464h
// WARNING: [rz-ghidra] Detected overlap for variable var_460h

void fcn.1800130c0(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    int64_t var_8h;
    undefined auStack_138 [56];
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_68h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    undefined4 uStack_30;
    undefined4 uStack_2c;
    int64_t var_28h;
    undefined4 uStack_20;
    undefined4 uStack_1c;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_138;
    var_f0h = 0;
    _var_e8h = ZEXT816(0);
    _var_d8h = ZEXT816(0);
    _var_c8h = ZEXT816(0);
    var_b8h = 0;
    var_b0h = 0;
    var_a8h = 0;
    var_f8h._0_4_ = 1;
    var_f8h._4_4_ = 2;
    var_98h._0_2_ = 0;
    var_48h._0_1_ = '\0';
    var_40h._0_2_ = 0;
    var_100h = arg2;
    fcn.1800be580(&var_38h, arg3, &var_f8h, &var_98h);
    if ((char)var_48h != '\0') {
        fcn.18000ace0(&var_68h);
        if (var_90h != 0) {
            fcn.1800f4640();
        }
    }
    *(undefined *)arg2 = 1;
    *(undefined4 *)(arg2 + 8) = (undefined4)var_38h;
    *(undefined4 *)(arg2 + 0xc) = var_38h._4_4_;
    *(undefined4 *)(arg2 + 0x10) = uStack_30;
    *(undefined4 *)(arg2 + 0x14) = uStack_2c;
    *(undefined4 *)(arg2 + 0x18) = (undefined4)var_28h;
    *(undefined4 *)(arg2 + 0x1c) = var_28h._4_4_;
    *(undefined4 *)(arg2 + 0x20) = uStack_20;
    *(undefined4 *)(arg2 + 0x24) = uStack_1c;
    fcn.180459870(var_18h ^ (uint64_t)auStack_138);
    return;
}

// ============================================================
// Function: FUN_1800131b0
// Address: 0x1800131b0
// Size: 822 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h

void fcn.1800131b0(int64_t arg1, int64_t arg2, int64_t placeholder_2, int64_t arg4, int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    undefined8 uVar7;
    undefined8 *puVar8;
    int64_t *piVar9;
    int64_t var_8h;
    undefined auStack_f8 [32];
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    undefined8 var_88h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    var_40h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_f8;
    fcn.1800130c0(arg1, (int64_t)&var_68h, placeholder_2);
    if ((char)var_68h == '\0') {
        if ((uint64_t)var_48h < 0x10) {
            piVar9 = &var_60h;
        } else {
            piVar9 = (int64_t *)var_60h;
            if (var_60h == 0) {
                fcn.180086510(arg2);
                goto code_r0x00018001320a;
            }
        }
        uVar7 = fcn.180498cd0(piVar9);
        fcn.1800867f0(arg2, piVar9, uVar7);
    } else {
        piVar9 = &var_60h;
        if (0xf < (uint64_t)var_48h) {
            piVar9 = (int64_t *)var_60h;
        }
        if (*(uint64_t *)(*(int64_t *)(arg2 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg2 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg2, 1);
        }
        iVar2 = *(int64_t *)(arg2 + 0x20);
        iVar3 = *(int64_t *)(iVar2 + 0x28);
        *(undefined8 *)(iVar2 + 0x28) = 0xffffffffffffffff;
        _var_d8h = ZEXT816(0);
        var_c8h = 0;
        var_c0h = 0;
        var_b8h = 0;
        var_b0h = 0;
        var_98h = var_50h;
        var_90h._0_4_ = (undefined4)arg_28h;
        var_90h._4_1_ = 0;
        var_88h = 0;
        var_a8h = arg4;
        var_a0h = (int64_t)piVar9;
        var_78h = iVar2;
        var_70h = iVar3;
        iVar6 = fcn.180093190(arg2, 0x1800a8050, &var_d8h);
        iVar5 = var_b0h;
        if (iVar6 == 4) {
            fcn.1800867f0(arg2, 0x18063ddf8, 0x11);
            iVar5 = var_b0h;
            if (var_b8h != 0) {
                iVar1 = var_b0h * 8;
                iVar4 = *(int64_t *)(var_c0h + 0x20);
                if ((iVar1 - 1U < 0x400) && (-1 < *(char *)(iVar1 + 0x180777990))) {
                    fcn.1800985c0(var_c0h, (int32_t)*(char *)(iVar1 + 0x180777990), var_b8h);
                } else {
                    (**(code **)(iVar4 + 0x48))(*(undefined8 *)(iVar4 + 0x50), var_b8h, iVar1, 0);
                }
                *(int64_t *)(iVar4 + 0x30) = *(int64_t *)(iVar4 + 0x30) + iVar5 * -8;
                *(int64_t *)(iVar4 + 0x2c30) = *(int64_t *)(iVar4 + 0x2c30) + iVar5 * -8;
            }
            iVar5 = var_c8h;
            if (var_d0h != 0) {
                iVar1 = var_c8h * 8;
                iVar4 = *(int64_t *)(var_d8h + 0x20);
                if ((iVar1 - 1U < 0x400) && (-1 < *(char *)(iVar1 + 0x180777990))) {
                    fcn.1800985c0(var_d8h, (int32_t)*(char *)(iVar1 + 0x180777990), var_d0h);
                } else {
                    (**(code **)(iVar4 + 0x48))(*(undefined8 *)(iVar4 + 0x50), var_d0h, iVar1, 0);
                }
                *(int64_t *)(iVar4 + 0x30) = *(int64_t *)(iVar4 + 0x30) + iVar5 * -8;
                *(int64_t *)(iVar4 + 0x2c30) = *(int64_t *)(iVar4 + 0x2c30) + iVar5 * -8;
            }
            *(int64_t *)(iVar2 + 0x28) = iVar3;
        } else {
            iVar6 = (int32_t)var_88h;
            if (var_b8h != 0) {
                iVar1 = var_b0h * 8;
                iVar4 = *(int64_t *)(var_c0h + 0x20);
                if ((iVar1 - 1U < 0x400) && (-1 < *(char *)(iVar1 + 0x180777990))) {
                    fcn.1800985c0(var_c0h, (int32_t)*(char *)(iVar1 + 0x180777990), var_b8h);
                } else {
                    (**(code **)(iVar4 + 0x48))(*(undefined8 *)(iVar4 + 0x50), var_b8h, iVar1, 0);
                }
                *(int64_t *)(iVar4 + 0x30) = *(int64_t *)(iVar4 + 0x30) + iVar5 * -8;
                *(int64_t *)(iVar4 + 0x2c30) = *(int64_t *)(iVar4 + 0x2c30) + iVar5 * -8;
            }
            iVar5 = var_c8h;
            if (var_d0h != 0) {
                iVar1 = var_c8h * 8;
                iVar4 = *(int64_t *)(var_d8h + 0x20);
                if ((iVar1 - 1U < 0x400) && (-1 < *(char *)(iVar1 + 0x180777990))) {
                    fcn.1800985c0(var_d8h, (int32_t)*(char *)(iVar1 + 0x180777990), var_d0h);
                } else {
                    (**(code **)(iVar4 + 0x48))(*(undefined8 *)(iVar4 + 0x50), var_d0h, iVar1, 0);
                }
                *(int64_t *)(iVar4 + 0x30) = *(int64_t *)(iVar4 + 0x30) + iVar5 * -8;
                *(int64_t *)(iVar4 + 0x2c30) = *(int64_t *)(iVar4 + 0x2c30) + iVar5 * -8;
            }
            *(int64_t *)(iVar2 + 0x28) = iVar3;
            if (iVar6 == 0) {
                piVar9 = (int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10);
                if ((piVar9 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 6)) {
                    if (piVar9 == *(int64_t **)0x180782430) {
                        piVar9 = (int64_t *)0x0;
                    }
                    iVar2 = *piVar9;
                    if ((iVar2 != 0) && (*(int64_t *)(iVar2 + 0x20) != 0)) {
                        puVar8 = (undefined8 *)fcn.180013530();
                        fcn.1800136b0(*puVar8, *(undefined8 *)(iVar2 + 0x20));
                    }
                }
            }
        }
    }
code_r0x00018001320a:
    fcn.180004e40(&var_60h);
    fcn.180459870(var_40h ^ (uint64_t)auStack_f8);
    return;
}

// ============================================================
// Function: FUN_1800134f0
// Address: 0x1800134f0
// Size: 37 bytes
// ============================================================
void fcn.1800134f0(int64_t arg1)
{
    if (*(int64_t *)arg1 != 0) {
        fcn.1800f4640();
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180013530
// Address: 0x180013530
// Size: 125 bytes
// ============================================================
undefined8 fcn.180013530(void)
{
    int64_t unaff_GS_OFFSET;
    
    if (*(int32_t *)(*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
        *(int32_t *)0x1807827b8) {
        fcn.180459d18(0x1807827b8);
        if (*(int32_t *)0x1807827b8 == -1) {
            *(undefined8 *)0x1807827c0 = fcn.180459890(1);
            fcn.180459c24(0x1804a2040);
            fcn.180459cac(0x1807827b8);
            return 0x1807827c0;
        }
    }
    return 0x1807827c0;
}

// ============================================================
// Function: FUN_1800135b0
// Address: 0x1800135b0
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800135b0(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    if (*(code **)0x180781ee8 != (code *)0x0) {
        (**(code **)0x180781ee8)();
    }
    if ((arg1 != 0) && (arg2 != 0)) {
        fcn.180013530();
        if ((*(uint8_t *)(arg1 + 1) & 0x40) != 0) {
            *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) | 0x40;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800136b0
// Address: 0x1800136b0
// Size: 141 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800136b0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    puVar1 = *(undefined8 **)0x180782458;
    if (*(undefined8 **)0x180782458 == (undefined8 *)0x0) {
        puVar1 = (undefined8 *)fcn.180459890(8);
        *(undefined8 **)0x180782458 = puVar1;
        *puVar1 = 0x203fffffffffff3f;
    }
    iVar2 = 0;
    *(uint64_t *)(arg2 + 0x18) = arg2 + 0x18U ^ (uint64_t)puVar1;
    if (0 < *(int32_t *)(arg2 + 0xa0)) {
        do {
            fcn.1800136b0(arg1, *(int64_t *)(*(int64_t *)(arg2 + 0x58) + (int64_t)iVar2 * 8));
            iVar2 = iVar2 + 1;
        } while (iVar2 < *(int32_t *)(arg2 + 0xa0));
    }
    return;
}

// ============================================================
// Function: FUN_180013740
// Address: 0x180013740
// Size: 135 bytes
// ============================================================
void fcn.180013740(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    uint64_t uVar2;
    int32_t *piVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    
    iVar5 = (int32_t)arg3;
    iVar1 = *(int64_t *)(arg2 + 0x50);
    *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) | 0x40;
    *(int32_t *)(iVar1 + 0x88) = iVar5;
    iVar6 = iVar5;
    uVar2 = func_0x000180013610(placeholder_0, arg3 & 0xffffffff);
    if (((iVar6 - 2U & 0xfffffffc) != 0) || (uVar4 = 0x103fffffffffff00, iVar5 == 3)) {
        uVar4 = 0x3fffffffffff00;
    }
    *(uint64_t *)(iVar1 + 0x78) = uVar2 | uVar4;
    piVar3 = (int32_t *)(**(code **)0x180782558)(**(undefined8 **)0x180782610);
    if (piVar3 != (int32_t *)0x0) {
        uVar4 = *(uint64_t *)(iVar1 + 0x78);
        *piVar3 = iVar5;
        *(int64_t *)(piVar3 + 6) = arg2;
        *(uint64_t *)(piVar3 + 10) = uVar4 & 0xffffffffffffffc0 | uVar2;
    }
    return;
}

// ============================================================
// Function: FUN_1800137d0
// Address: 0x1800137d0
// Size: 328 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800137d0(void)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    int64_t unaff_GS_OFFSET;
    int64_t var_8h;
    int64_t var_10h;
    
    if (*(int32_t *)(*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
        *(int32_t *)0x1807827c8) {
        fcn.180459d18(0x1807827c8);
        if (*(int32_t *)0x1807827c8 == -1) {
            puVar1 = (undefined8 *)fcn.180459890(0xe8);
            fcn.1804986e0(puVar1 + 5, 0, 0xc0);
            *puVar1 = 0;
            puVar1[1] = 0;
            puVar1[2] = 0;
            puVar1[3] = 0;
            puVar1[4] = 0;
            puVar2 = (undefined8 *)fcn.180459890(0x10);
            puVar2[1] = 0;
            *puVar1 = puVar2;
            *puVar2 = puVar1;
            *(undefined (*) [16])(puVar1 + 8) = ZEXT816(0);
            *(undefined (*) [16])(puVar1 + 10) = ZEXT816(0);
            *(undefined (*) [16])(puVar1 + 0xc) = ZEXT816(0);
            puVar1[6] = 0;
            puVar1[7] = 0;
            *(undefined4 *)(puVar1 + 0xe) = 0xffffffff;
            *(undefined4 *)(puVar1 + 5) = 2;
            *(undefined4 *)((int64_t)puVar1 + 0x74) = 0;
            puVar1[0xf] = 0;
            puVar1[0x10] = 0;
            *(undefined (*) [16])(puVar1 + 0x11) = ZEXT816(0);
            *(undefined (*) [16])(puVar1 + 0x13) = ZEXT816(0);
            *(undefined (*) [16])(puVar1 + 0x15) = ZEXT816(0);
            puVar1[0x17] = 0;
            puVar2 = puVar1 + 0x18;
            *puVar2 = 0;
            puVar1[0x19] = 0;
            puVar1[0x1a] = 0;
            puVar1[0x1b] = 0;
            puVar1[0x1c] = 0;
            puVar3 = (undefined8 *)fcn.180459890(0x10);
            puVar3[1] = 0;
            *puVar2 = puVar3;
            *puVar3 = puVar2;
            *(undefined8 **)0x1807827d0 = puVar1;
            fcn.180459c24(0x1804a2060);
            fcn.180459cac(0x1807827c8);
        }
    }
    return 0x1807827d0;
}

// ============================================================
// Function: FUN_180013920
// Address: 0x180013920
// Size: 93 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180013920(int64_t arg1, int64_t arg_30h)
{
    code *pcVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 unaff_RBX;
    int64_t *piVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    undefined auStack_20 [24];
    
    piVar7 = &var_28h;
    iVar5 = *(int64_t *)(arg1 + 0x20);
    if (iVar5 != 0) {
        do {
            fcn.180004e40(*(undefined8 *)
                           (*(int64_t *)(arg1 + 8) +
                           (*(int64_t *)(arg1 + 0x18) + -1 + iVar5 & *(int64_t *)(arg1 + 0x10) - 1U) * 8));
            iVar5 = *(int64_t *)(arg1 + 0x20) + -1;
            *(int64_t *)(arg1 + 0x20) = iVar5;
        } while (iVar5 != 0);
        *(undefined8 *)(arg1 + 0x18) = 0;
    }
    if (*(int64_t *)(arg1 + 8) != 0) {
        iVar5 = *(int64_t *)(arg1 + 0x10);
        while (0 < iVar5) {
            iVar5 = iVar5 + -1;
            iVar6 = *(int64_t *)(*(int64_t *)(arg1 + 8) + iVar5 * 8);
            if (iVar6 != 0) {
                fcn.180459c3c(iVar6, 0x20);
            }
        }
        iVar5 = *(int64_t *)(arg1 + 8);
        iVar6 = iVar5;
        piVar7 = &var_28h;
        if ((0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 8)) &&
           (iVar6 = *(int64_t *)(iVar5 + -8), piVar7 = &var_28h, 0x1f < (iVar5 - iVar6) - 8U)) {
            iVar6 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            piVar7 = (int64_t *)auStack_20;
        }
        *(undefined8 *)((int64_t)piVar7 + -8) = 0x1800139f6;
        fcn.180459c3c(iVar6);
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    iVar5 = *(int64_t *)arg1;
    *(undefined8 *)arg1 = 0;
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)piVar7 + 0x20) = unaff_RBX;
        *(undefined8 *)((int64_t)piVar7 + -8) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar5);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)piVar7 + -8) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)piVar7 + -8) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)piVar7 + -8) = 0x18047ca54;
            puVar4 = (undefined4 *)fcn.18046b77c();
            *puVar4 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18001397d
// Address: 0x18001397d
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180013920(int64_t arg1, int64_t arg_30h)
{
    code *pcVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 unaff_RBX;
    int64_t *piVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    undefined auStack_20 [24];
    
    piVar7 = &var_28h;
    iVar5 = *(int64_t *)(arg1 + 0x20);
    if (iVar5 != 0) {
        do {
            fcn.180004e40(*(undefined8 *)
                           (*(int64_t *)(arg1 + 8) +
                           (*(int64_t *)(arg1 + 0x18) + -1 + iVar5 & *(int64_t *)(arg1 + 0x10) - 1U) * 8));
            iVar5 = *(int64_t *)(arg1 + 0x20) + -1;
            *(int64_t *)(arg1 + 0x20) = iVar5;
        } while (iVar5 != 0);
        *(undefined8 *)(arg1 + 0x18) = 0;
    }
    if (*(int64_t *)(arg1 + 8) != 0) {
        iVar5 = *(int64_t *)(arg1 + 0x10);
        while (0 < iVar5) {
            iVar5 = iVar5 + -1;
            iVar6 = *(int64_t *)(*(int64_t *)(arg1 + 8) + iVar5 * 8);
            if (iVar6 != 0) {
                fcn.180459c3c(iVar6, 0x20);
            }
        }
        iVar5 = *(int64_t *)(arg1 + 8);
        iVar6 = iVar5;
        piVar7 = &var_28h;
        if ((0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 8)) &&
           (iVar6 = *(int64_t *)(iVar5 + -8), piVar7 = &var_28h, 0x1f < (iVar5 - iVar6) - 8U)) {
            iVar6 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            piVar7 = (int64_t *)auStack_20;
        }
        *(undefined8 *)((int64_t)piVar7 + -8) = 0x1800139f6;
        fcn.180459c3c(iVar6);
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    iVar5 = *(int64_t *)arg1;
    *(undefined8 *)arg1 = 0;
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)piVar7 + 0x20) = unaff_RBX;
        *(undefined8 *)((int64_t)piVar7 + -8) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar5);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)piVar7 + -8) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)piVar7 + -8) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)piVar7 + -8) = 0x18047ca54;
            puVar4 = (undefined4 *)fcn.18046b77c();
            *puVar4 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800139cd
// Address: 0x1800139cd
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180013920(int64_t arg1, int64_t arg_30h)
{
    code *pcVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 unaff_RBX;
    int64_t *piVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    undefined auStack_20 [24];
    
    piVar7 = &var_28h;
    iVar5 = *(int64_t *)(arg1 + 0x20);
    if (iVar5 != 0) {
        do {
            fcn.180004e40(*(undefined8 *)
                           (*(int64_t *)(arg1 + 8) +
                           (*(int64_t *)(arg1 + 0x18) + -1 + iVar5 & *(int64_t *)(arg1 + 0x10) - 1U) * 8));
            iVar5 = *(int64_t *)(arg1 + 0x20) + -1;
            *(int64_t *)(arg1 + 0x20) = iVar5;
        } while (iVar5 != 0);
        *(undefined8 *)(arg1 + 0x18) = 0;
    }
    if (*(int64_t *)(arg1 + 8) != 0) {
        iVar5 = *(int64_t *)(arg1 + 0x10);
        while (0 < iVar5) {
            iVar5 = iVar5 + -1;
            iVar6 = *(int64_t *)(*(int64_t *)(arg1 + 8) + iVar5 * 8);
            if (iVar6 != 0) {
                fcn.180459c3c(iVar6, 0x20);
            }
        }
        iVar5 = *(int64_t *)(arg1 + 8);
        iVar6 = iVar5;
        piVar7 = &var_28h;
        if ((0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 8)) &&
           (iVar6 = *(int64_t *)(iVar5 + -8), piVar7 = &var_28h, 0x1f < (iVar5 - iVar6) - 8U)) {
            iVar6 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            piVar7 = (int64_t *)auStack_20;
        }
        *(undefined8 *)((int64_t)piVar7 + -8) = 0x1800139f6;
        fcn.180459c3c(iVar6);
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    iVar5 = *(int64_t *)arg1;
    *(undefined8 *)arg1 = 0;
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)piVar7 + 0x20) = unaff_RBX;
        *(undefined8 *)((int64_t)piVar7 + -8) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar5);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)piVar7 + -8) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)piVar7 + -8) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)piVar7 + -8) = 0x18047ca54;
            puVar4 = (undefined4 *)fcn.18046b77c();
            *puVar4 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180013a20
// Address: 0x180013a20
// Size: 93 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180013a20(int64_t arg1, int64_t arg_30h)
{
    code *pcVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 unaff_RBX;
    int64_t *piVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    undefined auStack_20 [24];
    
    piVar7 = &var_28h;
    iVar5 = *(int64_t *)(arg1 + 0x20);
    if (iVar5 != 0) {
        do {
            func_0x00018000d070(*(undefined8 *)
                                 (*(int64_t *)(arg1 + 8) +
                                 (*(int64_t *)(arg1 + 0x18) + -1 + iVar5 & *(int64_t *)(arg1 + 0x10) - 1U) * 8));
            iVar5 = *(int64_t *)(arg1 + 0x20) + -1;
            *(int64_t *)(arg1 + 0x20) = iVar5;
        } while (iVar5 != 0);
        *(undefined8 *)(arg1 + 0x18) = 0;
    }
    if (*(int64_t *)(arg1 + 8) != 0) {
        iVar5 = *(int64_t *)(arg1 + 0x10);
        while (0 < iVar5) {
            iVar5 = iVar5 + -1;
            iVar6 = *(int64_t *)(*(int64_t *)(arg1 + 8) + iVar5 * 8);
            if (iVar6 != 0) {
                fcn.180459c3c(iVar6, 0x10);
            }
        }
        iVar5 = *(int64_t *)(arg1 + 8);
        iVar6 = iVar5;
        piVar7 = &var_28h;
        if ((0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 8)) &&
           (iVar6 = *(int64_t *)(iVar5 + -8), piVar7 = &var_28h, 0x1f < (iVar5 - iVar6) - 8U)) {
            iVar6 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            piVar7 = (int64_t *)auStack_20;
        }
        *(undefined8 *)((int64_t)piVar7 + -8) = 0x180013af6;
        fcn.180459c3c(iVar6);
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    iVar5 = *(int64_t *)arg1;
    *(undefined8 *)arg1 = 0;
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)piVar7 + 0x20) = unaff_RBX;
        *(undefined8 *)((int64_t)piVar7 + -8) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar5);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)piVar7 + -8) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)piVar7 + -8) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)piVar7 + -8) = 0x18047ca54;
            puVar4 = (undefined4 *)fcn.18046b77c();
            *puVar4 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180013a7d
// Address: 0x180013a7d
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180013a20(int64_t arg1, int64_t arg_30h)
{
    code *pcVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 unaff_RBX;
    int64_t *piVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    undefined auStack_20 [24];
    
    piVar7 = &var_28h;
    iVar5 = *(int64_t *)(arg1 + 0x20);
    if (iVar5 != 0) {
        do {
            func_0x00018000d070(*(undefined8 *)
                                 (*(int64_t *)(arg1 + 8) +
                                 (*(int64_t *)(arg1 + 0x18) + -1 + iVar5 & *(int64_t *)(arg1 + 0x10) - 1U) * 8));
            iVar5 = *(int64_t *)(arg1 + 0x20) + -1;
            *(int64_t *)(arg1 + 0x20) = iVar5;
        } while (iVar5 != 0);
        *(undefined8 *)(arg1 + 0x18) = 0;
    }
    if (*(int64_t *)(arg1 + 8) != 0) {
        iVar5 = *(int64_t *)(arg1 + 0x10);
        while (0 < iVar5) {
            iVar5 = iVar5 + -1;
            iVar6 = *(int64_t *)(*(int64_t *)(arg1 + 8) + iVar5 * 8);
            if (iVar6 != 0) {
                fcn.180459c3c(iVar6, 0x10);
            }
        }
        iVar5 = *(int64_t *)(arg1 + 8);
        iVar6 = iVar5;
        piVar7 = &var_28h;
        if ((0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 8)) &&
           (iVar6 = *(int64_t *)(iVar5 + -8), piVar7 = &var_28h, 0x1f < (iVar5 - iVar6) - 8U)) {
            iVar6 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            piVar7 = (int64_t *)auStack_20;
        }
        *(undefined8 *)((int64_t)piVar7 + -8) = 0x180013af6;
        fcn.180459c3c(iVar6);
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    iVar5 = *(int64_t *)arg1;
    *(undefined8 *)arg1 = 0;
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)piVar7 + 0x20) = unaff_RBX;
        *(undefined8 *)((int64_t)piVar7 + -8) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar5);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)piVar7 + -8) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)piVar7 + -8) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)piVar7 + -8) = 0x18047ca54;
            puVar4 = (undefined4 *)fcn.18046b77c();
            *puVar4 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180013acd
// Address: 0x180013acd
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180013a20(int64_t arg1, int64_t arg_30h)
{
    code *pcVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 unaff_RBX;
    int64_t *piVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    undefined auStack_20 [24];
    
    piVar7 = &var_28h;
    iVar5 = *(int64_t *)(arg1 + 0x20);
    if (iVar5 != 0) {
        do {
            func_0x00018000d070(*(undefined8 *)
                                 (*(int64_t *)(arg1 + 8) +
                                 (*(int64_t *)(arg1 + 0x18) + -1 + iVar5 & *(int64_t *)(arg1 + 0x10) - 1U) * 8));
            iVar5 = *(int64_t *)(arg1 + 0x20) + -1;
            *(int64_t *)(arg1 + 0x20) = iVar5;
        } while (iVar5 != 0);
        *(undefined8 *)(arg1 + 0x18) = 0;
    }
    if (*(int64_t *)(arg1 + 8) != 0) {
        iVar5 = *(int64_t *)(arg1 + 0x10);
        while (0 < iVar5) {
            iVar5 = iVar5 + -1;
            iVar6 = *(int64_t *)(*(int64_t *)(arg1 + 8) + iVar5 * 8);
            if (iVar6 != 0) {
                fcn.180459c3c(iVar6, 0x10);
            }
        }
        iVar5 = *(int64_t *)(arg1 + 8);
        iVar6 = iVar5;
        piVar7 = &var_28h;
        if ((0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 8)) &&
           (iVar6 = *(int64_t *)(iVar5 + -8), piVar7 = &var_28h, 0x1f < (iVar5 - iVar6) - 8U)) {
            iVar6 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            piVar7 = (int64_t *)auStack_20;
        }
        *(undefined8 *)((int64_t)piVar7 + -8) = 0x180013af6;
        fcn.180459c3c(iVar6);
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    iVar5 = *(int64_t *)arg1;
    *(undefined8 *)arg1 = 0;
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)piVar7 + 0x20) = unaff_RBX;
        *(undefined8 *)((int64_t)piVar7 + -8) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar5);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)piVar7 + -8) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)piVar7 + -8) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)piVar7 + -8) = 0x18047ca54;
            puVar4 = (undefined4 *)fcn.18046b77c();
            *puVar4 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180013b20
// Address: 0x180013b20
// Size: 216 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180013b20(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t unaff_RBX;
    int64_t iVar3;
    int64_t var_8h;
    
    iVar1 = fcn.180458324(unaff_RBX);
    iVar2 = fcn.180458308();
    if (iVar1 == 10000000) {
        *(int64_t *)arg1 = iVar2 * 100;
        return arg1;
    }
    if (iVar1 == 24000000) {
        iVar1 = iVar2 + SUB168(SEXT816(-0x4d0b03f86b6f730d) * SEXT816(iVar2), 8);
        iVar3 = (iVar1 >> 0x18) - (iVar1 >> 0x3f);
        iVar1 = (iVar2 + iVar3 * -24000000) * 1000000000;
        iVar1 = SUB168(SEXT816(-0x4d0b03f86b6f730d) * SEXT816(iVar1), 8) + iVar1;
        *(int64_t *)arg1 = ((iVar1 >> 0x18) - (iVar1 >> 0x3f)) + iVar3 * 1000000000;
        return arg1;
    }
    *(int64_t *)arg1 = ((iVar2 % iVar1) * 1000000000) / iVar1 + (iVar2 / iVar1) * 1000000000;
    return arg1;
}

// ============================================================
// Function: FUN_180013c00
// Address: 0x180013c00
// Size: 17 bytes
// ============================================================
void fcn.180013c00(void)
{
    code *pcVar1;
    
    fcn.1804546d4(0x18061fde0);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180013c20
// Address: 0x180013c20
// Size: 110 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180013c20(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int32_t *piVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    var_10h = arg2;
    piVar2 = (int32_t *)fcn.18046b77c();
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        arg1 = *(int64_t *)arg1;
    }
    *piVar2 = 0;
    func_0x00018046c52c(arg1, &var_10h, 10);
    if (arg1 != var_10h) {
        if (*piVar2 != 0x22) {
            return;
        }
        func_0x0001804546f8(0x18061fe10);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    func_0x0001804546b0(0x18061fdf8);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180013c90
// Address: 0x180013c90
// Size: 104 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180013c90(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int32_t *piVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    var_10h = arg2;
    piVar2 = (int32_t *)fcn.18046b77c();
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        arg1 = *(int64_t *)arg1;
    }
    *piVar2 = 0;
    func_0x00018046b634(arg1, &var_10h);
    if (arg1 != var_10h) {
        if (*piVar2 != 0x22) {
            return;
        }
        func_0x0001804546f8(0x18061fe48);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    func_0x0001804546b0(0x18061fe30);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180013d00
// Address: 0x180013d00
// Size: 44 bytes
// ============================================================
void fcn.180013d00(int64_t arg1)
{
    int64_t *piVar1;
    
    piVar1 = *(int64_t **)(arg1 + 0x38);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)arg1);
        *(undefined8 *)(arg1 + 0x38) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180013d30
// Address: 0x180013d30
// Size: 437 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_e8h

void fcn.180013d30(void)
{
    int64_t iVar1;
    int64_t unaff_GS_OFFSET;
    undefined auStackY_108 [32];
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_20h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_108;
    if (*(int32_t *)(*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
        *(int32_t *)0x1807827e0) {
        fcn.180459d18(0x1807827e0);
        if (*(int32_t *)0x1807827e0 == -1) {
            iVar1 = fcn.180459890(0x2e8);
            _var_e8h = ZEXT816(0);
            fcn.18017caf0(iVar1, &var_e8h);
            *(undefined8 *)(iVar1 + 0x2e0) = 0;
            var_d8h = 0x18061ff20;
            var_a0h = (int64_t)&var_d8h;
            var_d0h = iVar1;
            fcn.180014e50(var_e8h);
            if (var_a0h != 0) {
                (**(code **)(*(int64_t *)var_a0h + 0x20))
                          (var_a0h, CONCAT71((unkint7)((uint64_t)&var_d8h >> 8), (int64_t *)var_a0h != &var_d8h));
            }
            var_98h = 0x18061ffb0;
            var_60h = (int64_t)&var_98h;
            var_90h = iVar1;
            fcn.180014e50(var_e8h);
            if (var_60h != 0) {
                (**(code **)(*(int64_t *)var_60h + 0x20))
                          (var_60h, CONCAT71((unkint7)((uint64_t)&var_98h >> 8), (int64_t *)var_60h != &var_98h));
            }
            var_58h = 0x18061ff80;
            var_20h = (int64_t)&var_58h;
            fcn.180014e50(var_e8h);
            if (var_20h != 0) {
                (**(code **)(*(int64_t *)var_20h + 0x20))
                          (var_20h, CONCAT71((unkint7)((uint64_t)&var_58h >> 8), (int64_t *)var_20h != &var_58h));
            }
            *(int64_t *)0x1807827d8 = iVar1;
            fcn.180459c24(0x1804a20a0);
            fcn.180459cac(0x1807827e0);
        }
    }
    fcn.180459870(var_18h ^ (uint64_t)auStackY_108);
    return;
}

// ============================================================
// Function: FUN_180013ef0
// Address: 0x180013ef0
// Size: 86 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180013ef0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar2 = fcn.180498cd0(arg2);
    uVar1 = *(uint64_t *)(arg1 + 0x10);
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        arg1 = *(int64_t *)arg1;
    }
    if ((uVar2 <= uVar1) && ((uint64_t)arg3 <= uVar1 - uVar2)) {
        if (uVar2 == 0) {
            return arg3;
        }
        iVar3 = func_0x0001804581c0(arg1 + arg3, uVar1 + arg1, arg2, uVar2);
        if (iVar3 != uVar1 + arg1) {
            return iVar3 - arg1;
        }
    }
    return -1;
}

// ============================================================
// Function: FUN_180013f46
// Address: 0x180013f46
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180013ef0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar2 = fcn.180498cd0(arg2);
    uVar1 = *(uint64_t *)(arg1 + 0x10);
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        arg1 = *(int64_t *)arg1;
    }
    if ((uVar2 <= uVar1) && ((uint64_t)arg3 <= uVar1 - uVar2)) {
        if (uVar2 == 0) {
            return arg3;
        }
        iVar3 = func_0x0001804581c0(arg1 + arg3, uVar1 + arg1, arg2, uVar2);
        if (iVar3 != uVar1 + arg1) {
            return iVar3 - arg1;
        }
    }
    return -1;
}

// ============================================================
// Function: FUN_180013f6b
// Address: 0x180013f6b
// Size: 42 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180013ef0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar2 = fcn.180498cd0(arg2);
    uVar1 = *(uint64_t *)(arg1 + 0x10);
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        arg1 = *(int64_t *)arg1;
    }
    if ((uVar2 <= uVar1) && ((uint64_t)arg3 <= uVar1 - uVar2)) {
        if (uVar2 == 0) {
            return arg3;
        }
        iVar3 = func_0x0001804581c0(arg1 + arg3, uVar1 + arg1, arg2, uVar2);
        if (iVar3 != uVar1 + arg1) {
            return iVar3 - arg1;
        }
    }
    return -1;
}

// ============================================================
// Function: FUN_180013fa0
// Address: 0x180013fa0
// Size: 42 bytes
// ============================================================
void fcn.180013fa0(int64_t arg1)
{
    undefined4 *puVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    
    func_0x000180015170(arg1, arg1, *(undefined8 *)(*(int64_t *)arg1 + 8));
    if ((*(int64_t *)arg1 != 0) &&
       (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, *(int64_t *)arg1, in_R9, unaff_RBX), iVar2 == 0)) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18046b63c(uVar3);
        puVar1 = (undefined4 *)fcn.18046b77c();
        *puVar1 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_180013fd0
// Address: 0x180013fd0
// Size: 334 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch

void fcn.180013fd0(int64_t arg1, int64_t arg2)
{
    uint32_t *puVar1;
    uint32_t uVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined auVar8 [16];
    undefined auVar9 [16];
    int32_t iVar10;
    int64_t *piVar11;
    int64_t iVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    
    uVar4 = *(undefined4 *)arg2;
    uVar5 = *(undefined4 *)(arg2 + 4);
    uVar6 = *(undefined4 *)(arg2 + 8);
    uVar7 = *(undefined4 *)(arg2 + 0xc);
    _var_38h = ZEXT816(0);
    var_28h = fcn.180459890();
    *(undefined4 *)var_28h = 1;
    *(undefined4 *)(var_28h + 4) = 2;
    *(undefined8 *)(var_28h + 8) = 0;
    *(undefined8 *)(var_28h + 0x10) = 0;
    *(undefined4 *)(var_28h + 0x18) = 0;
    piVar11 = (int64_t *)fcn.180459890(0x18);
    *piVar11 = arg1;
    *(undefined4 *)(piVar11 + 1) = uVar4;
    *(undefined4 *)((int64_t)piVar11 + 0xc) = uVar5;
    *(undefined4 *)(piVar11 + 2) = uVar6;
    *(undefined4 *)((int64_t)piVar11 + 0x14) = uVar7;
    iVar12 = func_0x00018045f6e8(0, 0, 0x180014f70, piVar11, 0, &var_30h);
    auVar8 = _var_38h;
    var_38h = iVar12;
    auVar9 = _var_38h;
    var_30h._4_4_ = auVar8._12_4_;
    if (iVar12 == 0) {
        _var_38h = ZEXT812(0);
        func_0x0001804542e8(6);
    } else {
        var_30h._0_4_ = auVar8._8_4_;
        if ((int32_t)var_30h == 0) goto code_r0x000180014113;
        var_40h._0_4_ = (int32_t)var_30h;
        var_48h = iVar12;
        var_40h._4_4_ = var_30h._4_4_;
        _var_38h = auVar9;
        iVar10 = func_0x000180454a0c(&var_48h);
        auVar9 = _var_38h;
        if (iVar10 != 0) goto code_r0x000180014113;
        _var_48h = ZEXT816(0);
        _var_38h = ZEXT812(0);
        var_30h._4_4_ = 0;
        if (var_28h != 0) {
            LOCK();
            puVar1 = (uint32_t *)(var_28h + 4);
            uVar2 = *puVar1;
            *puVar1 = *puVar1 - 2;
            UNLOCK();
            if ((uVar2 & 0xfffffffe) == 2) {
                LOCK();
                iVar10 = *(int32_t *)var_28h;
                *(int32_t *)var_28h = *(int32_t *)var_28h + -1;
                UNLOCK();
                if (iVar10 == 1) {
                    fcn.180459c3c(var_28h, 0x20);
                }
            }
        }
        if ((int32_t)var_30h == 0) {
            return;
        }
    }
    func_0x00018045f7d4();
    auVar9 = _var_38h;
code_r0x000180014113:
    _var_38h = auVar9;
    func_0x0001804542e8(1);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_180014120
// Address: 0x180014120
// Size: 71 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180014120(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(arg2 + 0x10);
    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
        arg2 = *(int64_t *)arg2;
    }
    uVar2 = *(uint64_t *)(arg1 + 0x10);
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        arg1 = *(int64_t *)arg1;
    }
    if ((uVar1 <= uVar2) && ((uint64_t)arg3 <= uVar2 - uVar1)) {
        if (uVar1 == 0) {
            return arg3;
        }
        iVar3 = func_0x0001804581c0(arg1 + arg3, uVar2 + arg1, arg2);
        if (iVar3 != uVar2 + arg1) {
            return iVar3 - arg1;
        }
    }
    return -1;
}

// ============================================================
// Function: FUN_180014167
// Address: 0x180014167
// Size: 30 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180014120(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(arg2 + 0x10);
    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
        arg2 = *(int64_t *)arg2;
    }
    uVar2 = *(uint64_t *)(arg1 + 0x10);
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        arg1 = *(int64_t *)arg1;
    }
    if ((uVar1 <= uVar2) && ((uint64_t)arg3 <= uVar2 - uVar1)) {
        if (uVar1 == 0) {
            return arg3;
        }
        iVar3 = func_0x0001804581c0(arg1 + arg3, uVar2 + arg1, arg2);
        if (iVar3 != uVar2 + arg1) {
            return iVar3 - arg1;
        }
    }
    return -1;
}

