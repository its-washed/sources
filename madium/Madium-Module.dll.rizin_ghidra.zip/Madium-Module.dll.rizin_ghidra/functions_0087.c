// Chunk 87 - 50 functions

// ============================================================
// Function: FUN_180124200
// Address: 0x180124200
// Size: 192 bytes
// ============================================================
void fcn.180124200(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    int32_t iVar13;
    int64_t iVar14;
    int32_t iVar15;
    int64_t var_68h;
    int64_t var_8h;
    
    iVar13 = *(int32_t *)(arg1 + 4);
    uVar5 = *(undefined4 *)(arg1 + 0x60);
    uVar6 = *(undefined4 *)(arg1 + 100);
    uVar7 = *(undefined4 *)(arg1 + 0x68);
    uVar8 = *(undefined4 *)(arg1 + 0x6c);
    uVar2 = *(undefined4 *)(arg1 + 0x80);
    uVar9 = *(undefined4 *)(arg1 + 0x70);
    uVar10 = *(undefined4 *)(arg1 + 0x74);
    uVar11 = *(undefined4 *)(arg1 + 0x78);
    uVar12 = *(undefined4 *)(arg1 + 0x7c);
    uVar3 = *(undefined4 *)(arg1 + 0x10);
    if (*(int32_t *)arg1 == iVar13) {
        iVar15 = *(int32_t *)arg1 + 1;
        if (iVar13 == 0) {
            iVar13 = 8;
        } else {
            iVar13 = iVar13 / 2 + iVar13;
        }
        if (iVar15 < iVar13) {
            iVar15 = iVar13;
        }
        func_0x00018011fc10(arg1, iVar15);
    }
    iVar14 = (int64_t)*(int32_t *)arg1;
    iVar4 = *(int64_t *)(arg1 + 8);
    puVar1 = (undefined4 *)(iVar4 + iVar14 * 0x48);
    *puVar1 = uVar5;
    puVar1[1] = uVar6;
    puVar1[2] = uVar7;
    puVar1[3] = uVar8;
    puVar1 = (undefined4 *)(iVar4 + 0x10 + iVar14 * 0x48);
    *puVar1 = uVar9;
    puVar1[1] = uVar10;
    puVar1[2] = uVar11;
    puVar1[3] = uVar12;
    puVar1 = (undefined4 *)(iVar4 + 0x20 + iVar14 * 0x48);
    *puVar1 = uVar2;
    puVar1[1] = uVar3;
    puVar1[2] = 0;
    puVar1[3] = 0;
    *(undefined (*) [16])(iVar4 + 0x30 + iVar14 * 0x48) = ZEXT816(0);
    *(undefined8 *)(iVar4 + 0x40 + iVar14 * 0x48) = 0;
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    return;
}

// ============================================================
// Function: FUN_1801242c0
// Address: 0x1801242c0
// Size: 157 bytes
// ============================================================
void fcn.1801242c0(int64_t arg1)
{
    undefined4 *puVar1;
    int64_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    int32_t iVar13;
    int64_t iVar14;
    int32_t iVar15;
    
    iVar13 = *(int32_t *)arg1;
    iVar2 = *(int64_t *)(arg1 + 8) + (int64_t)iVar13 * 0x48;
    if (*(int32_t *)(*(int64_t *)(arg1 + 8) + -0x20 + (int64_t)iVar13 * 0x48) == 0) {
        if (1 < iVar13) {
            iVar15 = func_0x000180497f30(arg1 + 0x60, iVar2 + -0x90, 0x24);
            if (((iVar15 == 0) &&
                (*(int32_t *)(iVar2 + -0x68) + *(int32_t *)(iVar2 + -0x6c) == *(int32_t *)(iVar2 + -0x24))) &&
               (*(int64_t *)(iVar2 + -0x60) == 0)) {
                *(int32_t *)arg1 = iVar13 + -1;
                return;
            }
        }
    } else if ((*(int64_t *)(iVar2 + -0x48) != *(int64_t *)(arg1 + 0x60)) ||
              (*(int64_t *)(iVar2 + -0x40) != *(int64_t *)(arg1 + 0x68))) {
        iVar13 = *(int32_t *)(arg1 + 4);
        uVar5 = *(undefined4 *)(arg1 + 0x60);
        uVar6 = *(undefined4 *)(arg1 + 100);
        uVar7 = *(undefined4 *)(arg1 + 0x68);
        uVar8 = *(undefined4 *)(arg1 + 0x6c);
        uVar3 = *(undefined4 *)(arg1 + 0x80);
        uVar9 = *(undefined4 *)(arg1 + 0x70);
        uVar10 = *(undefined4 *)(arg1 + 0x74);
        uVar11 = *(undefined4 *)(arg1 + 0x78);
        uVar12 = *(undefined4 *)(arg1 + 0x7c);
        uVar4 = *(undefined4 *)(arg1 + 0x10);
        if (*(int32_t *)arg1 == iVar13) {
            iVar15 = *(int32_t *)arg1 + 1;
            if (iVar13 == 0) {
                iVar13 = 8;
            } else {
                iVar13 = iVar13 / 2 + iVar13;
            }
            if (iVar15 < iVar13) {
                iVar15 = iVar13;
            }
            func_0x00018011fc10(arg1, iVar15);
        }
        iVar14 = (int64_t)*(int32_t *)arg1;
        iVar2 = *(int64_t *)(arg1 + 8);
        puVar1 = (undefined4 *)(iVar2 + iVar14 * 0x48);
        *puVar1 = uVar5;
        puVar1[1] = uVar6;
        puVar1[2] = uVar7;
        puVar1[3] = uVar8;
        puVar1 = (undefined4 *)(iVar2 + 0x10 + iVar14 * 0x48);
        *puVar1 = uVar9;
        puVar1[1] = uVar10;
        puVar1[2] = uVar11;
        puVar1[3] = uVar12;
        puVar1 = (undefined4 *)(iVar2 + 0x20 + iVar14 * 0x48);
        *puVar1 = uVar3;
        puVar1[1] = uVar4;
        puVar1[2] = 0;
        puVar1[3] = 0;
        *(undefined (*) [16])(iVar2 + 0x30 + iVar14 * 0x48) = ZEXT816(0);
        *(undefined8 *)(iVar2 + 0x40 + iVar14 * 0x48) = 0;
        *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
        return;
    }
    uVar3 = *(undefined4 *)(arg1 + 100);
    uVar4 = *(undefined4 *)(arg1 + 0x68);
    uVar5 = *(undefined4 *)(arg1 + 0x6c);
    *(undefined4 *)(iVar2 + -0x48) = *(undefined4 *)(arg1 + 0x60);
    *(undefined4 *)(iVar2 + -0x44) = uVar3;
    *(undefined4 *)(iVar2 + -0x40) = uVar4;
    *(undefined4 *)(iVar2 + -0x3c) = uVar5;
    return;
}

// ============================================================
// Function: FUN_180124360
// Address: 0x180124360
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.180124360(int64_t arg1, int64_t arg_48h)
{
    int64_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar2 = *(int32_t *)arg1;
    iVar7 = (int64_t)iVar2;
    iVar6 = *(int32_t *)(*(int64_t *)(arg1 + 8) + -0x20 + iVar7 * 0x48);
    iVar1 = *(int64_t *)(arg1 + 8) + iVar7 * 0x48;
    if ((iVar6 == 0) ||
       ((*(int64_t *)(iVar1 + -0x30) == *(int64_t *)(arg1 + 0x78) &&
        (*(int64_t *)(iVar1 + -0x38) == *(int64_t *)(arg1 + 0x70))))) {
        if (*(int64_t *)(iVar1 + -0x18) == 0) {
            if ((((iVar6 == 0) && (1 < iVar2)) &&
                (iVar6 = func_0x000180497f30(arg1 + 0x60, iVar1 + -0x90, 0x24), iVar6 == 0)) &&
               ((*(int32_t *)(iVar1 + -0x68) + *(int32_t *)(iVar1 + -0x6c) == *(int32_t *)(iVar1 + -0x24) &&
                (*(int64_t *)(iVar1 + -0x60) == 0)))) {
                *(int32_t *)arg1 = iVar2 + -1;
            } else {
                uVar3 = *(undefined4 *)(arg1 + 0x74);
                uVar4 = *(undefined4 *)(arg1 + 0x78);
                uVar5 = *(undefined4 *)(arg1 + 0x7c);
                *(undefined4 *)(iVar1 + -0x38) = *(undefined4 *)(arg1 + 0x70);
                *(undefined4 *)(iVar1 + -0x34) = uVar3;
                *(undefined4 *)(iVar1 + -0x30) = uVar4;
                *(undefined4 *)(iVar1 + -0x2c) = uVar5;
            }
        }
    } else {
        fcn.180124200(arg1, iVar7 * 9);
    }
    return;
}

// ============================================================
// Function: FUN_1801243b2
// Address: 0x1801243b2
// Size: 84 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.180124360(int64_t arg1, int64_t arg_48h)
{
    int64_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar2 = *(int32_t *)arg1;
    iVar7 = (int64_t)iVar2;
    iVar6 = *(int32_t *)(*(int64_t *)(arg1 + 8) + -0x20 + iVar7 * 0x48);
    iVar1 = *(int64_t *)(arg1 + 8) + iVar7 * 0x48;
    if ((iVar6 == 0) ||
       ((*(int64_t *)(iVar1 + -0x30) == *(int64_t *)(arg1 + 0x78) &&
        (*(int64_t *)(iVar1 + -0x38) == *(int64_t *)(arg1 + 0x70))))) {
        if (*(int64_t *)(iVar1 + -0x18) == 0) {
            if ((((iVar6 == 0) && (1 < iVar2)) &&
                (iVar6 = func_0x000180497f30(arg1 + 0x60, iVar1 + -0x90, 0x24), iVar6 == 0)) &&
               ((*(int32_t *)(iVar1 + -0x68) + *(int32_t *)(iVar1 + -0x6c) == *(int32_t *)(iVar1 + -0x24) &&
                (*(int64_t *)(iVar1 + -0x60) == 0)))) {
                *(int32_t *)arg1 = iVar2 + -1;
            } else {
                uVar3 = *(undefined4 *)(arg1 + 0x74);
                uVar4 = *(undefined4 *)(arg1 + 0x78);
                uVar5 = *(undefined4 *)(arg1 + 0x7c);
                *(undefined4 *)(iVar1 + -0x38) = *(undefined4 *)(arg1 + 0x70);
                *(undefined4 *)(iVar1 + -0x34) = uVar3;
                *(undefined4 *)(iVar1 + -0x30) = uVar4;
                *(undefined4 *)(iVar1 + -0x2c) = uVar5;
            }
        }
    } else {
        fcn.180124200(arg1, iVar7 * 9);
    }
    return;
}

// ============================================================
// Function: FUN_180124406
// Address: 0x180124406
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.180124360(int64_t arg1, int64_t arg_48h)
{
    int64_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar2 = *(int32_t *)arg1;
    iVar7 = (int64_t)iVar2;
    iVar6 = *(int32_t *)(*(int64_t *)(arg1 + 8) + -0x20 + iVar7 * 0x48);
    iVar1 = *(int64_t *)(arg1 + 8) + iVar7 * 0x48;
    if ((iVar6 == 0) ||
       ((*(int64_t *)(iVar1 + -0x30) == *(int64_t *)(arg1 + 0x78) &&
        (*(int64_t *)(iVar1 + -0x38) == *(int64_t *)(arg1 + 0x70))))) {
        if (*(int64_t *)(iVar1 + -0x18) == 0) {
            if ((((iVar6 == 0) && (1 < iVar2)) &&
                (iVar6 = func_0x000180497f30(arg1 + 0x60, iVar1 + -0x90, 0x24), iVar6 == 0)) &&
               ((*(int32_t *)(iVar1 + -0x68) + *(int32_t *)(iVar1 + -0x6c) == *(int32_t *)(iVar1 + -0x24) &&
                (*(int64_t *)(iVar1 + -0x60) == 0)))) {
                *(int32_t *)arg1 = iVar2 + -1;
            } else {
                uVar3 = *(undefined4 *)(arg1 + 0x74);
                uVar4 = *(undefined4 *)(arg1 + 0x78);
                uVar5 = *(undefined4 *)(arg1 + 0x7c);
                *(undefined4 *)(iVar1 + -0x38) = *(undefined4 *)(arg1 + 0x70);
                *(undefined4 *)(iVar1 + -0x34) = uVar3;
                *(undefined4 *)(iVar1 + -0x30) = uVar4;
                *(undefined4 *)(iVar1 + -0x2c) = uVar5;
            }
        }
    } else {
        fcn.180124200(arg1, iVar7 * 9);
    }
    return;
}

// ============================================================
// Function: FUN_180124420
// Address: 0x180124420
// Size: 139 bytes
// ============================================================
uint32_t fcn.180124420(int64_t arg1)
{
    uint32_t uVar1;
    float fVar2;
    float in_XMM1_Da;
    
    if ((uint32_t)(int32_t)(in_XMM1_Da + 0.999999) < 0x40) {
        return (uint32_t)*(uint8_t *)((int64_t)(int32_t)(in_XMM1_Da + 0.999999) + 500 + *(int64_t *)(arg1 + 0x38));
    }
    fVar2 = *(float *)(*(int64_t *)(arg1 + 0x38) + 0x2c);
    if (in_XMM1_Da <= fVar2) {
        fVar2 = in_XMM1_Da;
    }
    fVar2 = (float)fcn.18048e9f0(1.0 - fVar2 / in_XMM1_Da);
    fVar2 = (float)fcn.180471c90(3.141593 / fVar2);
    uVar1 = (((int32_t)fVar2 + 1) / 2) * 2;
    if ((int32_t)uVar1 < 4) {
        return 4;
    }
    if (0x200 < (int32_t)uVar1) {
        uVar1 = 0x200;
    }
    return uVar1;
}

// ============================================================
// Function: FUN_1801244b0
// Address: 0x1801244b0
// Size: 290 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801244b0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    undefined4 *puVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    int32_t iVar14;
    int64_t iVar15;
    int32_t iVar16;
    char in_R9B;
    float fVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    int64_t var_8h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    fVar18 = *(float *)arg3;
    fVar17 = *(float *)(arg3 + 4);
    fVar19 = *(float *)(arg2 + 4);
    fVar21 = *(float *)arg2;
    if (in_R9B != '\0') {
        if (fVar21 < *(float *)(arg1 + 0x60)) {
            fVar21 = *(float *)(arg1 + 0x60);
        }
        if (fVar19 < *(float *)(arg1 + 100)) {
            fVar19 = *(float *)(arg1 + 100);
        }
        if (*(float *)(arg1 + 0x68) < fVar18) {
            fVar18 = *(float *)(arg1 + 0x68);
        }
        if (*(float *)(arg1 + 0x6c) < fVar17) {
            fVar17 = *(float *)(arg1 + 0x6c);
        }
    }
    piVar1 = (int32_t *)(arg1 + 0xa0);
    iVar14 = *(int32_t *)(arg1 + 0xa4);
    fVar20 = fVar21;
    if (fVar21 <= fVar18) {
        fVar20 = fVar18;
    }
    fVar18 = fVar19;
    if (fVar19 <= fVar17) {
        fVar18 = fVar17;
    }
    if (*piVar1 == iVar14) {
        iVar16 = *piVar1 + 1;
        if (iVar14 == 0) {
            iVar14 = 8;
        } else {
            iVar14 = iVar14 / 2 + iVar14;
        }
        if (iVar16 < iVar14) {
            iVar16 = iVar14;
        }
        func_0x00018011faa0(piVar1, iVar16);
    }
    iVar15 = (int64_t)*piVar1;
    iVar5 = *(int64_t *)(arg1 + 0xa8);
    *(float *)(iVar5 + iVar15 * 0x10) = fVar21;
    *(float *)(iVar5 + 4 + iVar15 * 0x10) = fVar19;
    *(float *)(iVar5 + 8 + iVar15 * 0x10) = fVar20;
    *(float *)(iVar5 + 0xc + iVar15 * 0x10) = fVar18;
    *piVar1 = *piVar1 + 1;
    *(float *)(arg1 + 0x60) = fVar21;
    *(float *)(arg1 + 100) = fVar19;
    *(float *)(arg1 + 0x68) = fVar20;
    *(float *)(arg1 + 0x6c) = fVar18;
    iVar14 = *(int32_t *)arg1;
    iVar5 = *(int64_t *)(arg1 + 8) + (int64_t)iVar14 * 0x48;
    if (*(int32_t *)(*(int64_t *)(arg1 + 8) + -0x20 + (int64_t)iVar14 * 0x48) == 0) {
        if (1 < iVar14) {
            iVar16 = func_0x000180497f30(arg1 + 0x60, iVar5 + -0x90, 0x24);
            if (((iVar16 == 0) &&
                (*(int32_t *)(iVar5 + -0x68) + *(int32_t *)(iVar5 + -0x6c) == *(int32_t *)(iVar5 + -0x24))) &&
               (*(int64_t *)(iVar5 + -0x60) == 0)) {
                *(int32_t *)arg1 = iVar14 + -1;
                return;
            }
        }
    } else if ((*(int64_t *)(iVar5 + -0x48) != *(int64_t *)(arg1 + 0x60)) ||
              (*(int64_t *)(iVar5 + -0x40) != *(int64_t *)(arg1 + 0x68))) {
        iVar14 = *(int32_t *)(arg1 + 4);
        uVar6 = *(undefined4 *)(arg1 + 0x60);
        uVar7 = *(undefined4 *)(arg1 + 100);
        uVar8 = *(undefined4 *)(arg1 + 0x68);
        uVar9 = *(undefined4 *)(arg1 + 0x6c);
        uVar3 = *(undefined4 *)(arg1 + 0x80);
        uVar10 = *(undefined4 *)(arg1 + 0x70);
        uVar11 = *(undefined4 *)(arg1 + 0x74);
        uVar12 = *(undefined4 *)(arg1 + 0x78);
        uVar13 = *(undefined4 *)(arg1 + 0x7c);
        uVar4 = *(undefined4 *)(arg1 + 0x10);
        if (*(int32_t *)arg1 == iVar14) {
            iVar16 = *(int32_t *)arg1 + 1;
            if (iVar14 == 0) {
                iVar14 = 8;
            } else {
                iVar14 = iVar14 / 2 + iVar14;
            }
            if (iVar16 < iVar14) {
                iVar16 = iVar14;
            }
            func_0x00018011fc10(arg1, iVar16);
        }
        iVar15 = (int64_t)*(int32_t *)arg1;
        iVar5 = *(int64_t *)(arg1 + 8);
        puVar2 = (undefined4 *)(iVar5 + iVar15 * 0x48);
        *puVar2 = uVar6;
        puVar2[1] = uVar7;
        puVar2[2] = uVar8;
        puVar2[3] = uVar9;
        puVar2 = (undefined4 *)(iVar5 + 0x10 + iVar15 * 0x48);
        *puVar2 = uVar10;
        puVar2[1] = uVar11;
        puVar2[2] = uVar12;
        puVar2[3] = uVar13;
        puVar2 = (undefined4 *)(iVar5 + 0x20 + iVar15 * 0x48);
        *puVar2 = uVar3;
        puVar2[1] = uVar4;
        puVar2[2] = 0;
        puVar2[3] = 0;
        *(undefined (*) [16])(iVar5 + 0x30 + iVar15 * 0x48) = ZEXT816(0);
        *(undefined8 *)(iVar5 + 0x40 + iVar15 * 0x48) = 0;
        *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
        return;
    }
    uVar3 = *(undefined4 *)(arg1 + 100);
    uVar4 = *(undefined4 *)(arg1 + 0x68);
    uVar6 = *(undefined4 *)(arg1 + 0x6c);
    *(undefined4 *)(iVar5 + -0x48) = *(undefined4 *)(arg1 + 0x60);
    *(undefined4 *)(iVar5 + -0x44) = uVar3;
    *(undefined4 *)(iVar5 + -0x40) = uVar4;
    *(undefined4 *)(iVar5 + -0x3c) = uVar6;
    return;
}

// ============================================================
// Function: FUN_180124620
// Address: 0x180124620
// Size: 88 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.180124620(int64_t arg1)
{
    int64_t iVar1;
    int64_t *piVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t var_18h;
    int64_t var_10h;
    
    iVar3 = *(int32_t *)(arg1 + 0xb0);
    iVar7 = iVar3 + -1;
    *(int32_t *)(arg1 + 0xb0) = iVar7;
    if (iVar7 == 0) {
        var_18h = 0;
        var_10h = 0;
    } else {
        piVar2 = (int64_t *)(*(int64_t *)(arg1 + 0xb8) + ((int64_t)iVar3 + -2) * 0x10);
        var_18h = *piVar2;
        var_10h = piVar2[1];
    }
    *(undefined4 *)(arg1 + 0x70) = (undefined4)var_18h;
    *(undefined4 *)(arg1 + 0x74) = var_18h._4_4_;
    *(undefined4 *)(arg1 + 0x78) = (undefined4)var_10h;
    *(undefined4 *)(arg1 + 0x7c) = var_10h._4_4_;
    iVar3 = *(int32_t *)arg1;
    iVar8 = (int64_t)iVar3;
    iVar7 = *(int32_t *)(*(int64_t *)(arg1 + 8) + -0x20 + iVar8 * 0x48);
    iVar1 = *(int64_t *)(arg1 + 8) + iVar8 * 0x48;
    if ((iVar7 == 0) ||
       ((*(int64_t *)(iVar1 + -0x30) == *(int64_t *)(arg1 + 0x78) &&
        (*(int64_t *)(iVar1 + -0x38) == *(int64_t *)(arg1 + 0x70))))) {
        if (*(int64_t *)(iVar1 + -0x18) == 0) {
            if ((((iVar7 == 0) && (1 < iVar3)) &&
                (iVar7 = func_0x000180497f30(arg1 + 0x60, iVar1 + -0x90, 0x24), iVar7 == 0)) &&
               ((*(int32_t *)(iVar1 + -0x68) + *(int32_t *)(iVar1 + -0x6c) == *(int32_t *)(iVar1 + -0x24) &&
                (*(int64_t *)(iVar1 + -0x60) == 0)))) {
                *(int32_t *)arg1 = iVar3 + -1;
            } else {
                uVar4 = *(undefined4 *)(arg1 + 0x74);
                uVar5 = *(undefined4 *)(arg1 + 0x78);
                uVar6 = *(undefined4 *)(arg1 + 0x7c);
                *(undefined4 *)(iVar1 + -0x38) = *(undefined4 *)(arg1 + 0x70);
                *(undefined4 *)(iVar1 + -0x34) = uVar4;
                *(undefined4 *)(iVar1 + -0x30) = uVar5;
                *(undefined4 *)(iVar1 + -0x2c) = uVar6;
            }
        }
    } else {
        fcn.180124200(arg1, iVar8 * 9);
    }
    return;
}

// ============================================================
// Function: FUN_180124680
// Address: 0x180124680
// Size: 257 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.180124680(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t arg2_00;
    int32_t *piVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    
    if ((0xffff < (uint32_t)(*(int32_t *)(arg1 + 0x34) + (int32_t)arg3)) && ((*(uint8_t *)(arg1 + 0x30) & 8) != 0)) {
        *(undefined4 *)(arg1 + 0x80) = *(undefined4 *)(arg1 + 0x20);
        *(undefined4 *)(arg1 + 0x34) = 0;
        arg2_00 = *(int64_t *)(arg1 + 8) + (int64_t)*(int32_t *)arg1 * 0x48;
        if (*(int32_t *)(*(int64_t *)(arg1 + 8) + -0x20 + (int64_t)*(int32_t *)arg1 * 0x48) == 0) {
            *(undefined4 *)(arg2_00 + -0x28) = *(undefined4 *)(arg1 + 0x20);
        } else {
            fcn.180124200(arg1, arg2_00);
        }
    }
    piVar1 = (int32_t *)(*(int64_t *)(arg1 + 8) + -0x20 + (int64_t)*(int32_t *)arg1 * 0x48);
    *piVar1 = *piVar1 + (int32_t)arg2;
    iVar2 = *(int32_t *)(arg1 + 0x20);
    iVar4 = *(int32_t *)(arg1 + 0x24);
    iVar5 = iVar2 + (int32_t)arg3;
    iVar6 = 8;
    if (iVar4 < iVar5) {
        if (iVar4 == 0) {
            iVar4 = 8;
        } else {
            iVar4 = iVar4 / 2 + iVar4;
        }
        iVar3 = iVar5;
        if (iVar5 < iVar4) {
            iVar3 = iVar4;
        }
        func_0x00018011f6f0(arg1 + 0x20, iVar3);
    }
    *(int32_t *)(arg1 + 0x20) = iVar5;
    iVar4 = *(int32_t *)(arg1 + 0x10);
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x28) + (int64_t)iVar2 * 0x14;
    iVar5 = iVar4 + (int32_t)arg2;
    iVar2 = *(int32_t *)(arg1 + 0x14);
    if (iVar2 < iVar5) {
        if (iVar2 != 0) {
            iVar6 = iVar2 + iVar2 / 2;
        }
        iVar2 = iVar5;
        if (iVar5 < iVar6) {
            iVar2 = iVar6;
        }
        func_0x00018011f8d0(arg1 + 0x10, iVar2);
    }
    *(int32_t *)(arg1 + 0x10) = iVar5;
    *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x18) + (int64_t)iVar4 * 2;
    return;
}

// ============================================================
// Function: FUN_180124790
// Address: 0x180124790
// Size: 334 bytes
// ============================================================
void fcn.180124790(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int16_t iVar9;
    int64_t iVar10;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    uVar1 = *(undefined4 *)(arg4 + 4);
    uVar2 = *(undefined4 *)arg3;
    uVar3 = *(undefined4 *)(arg2 + 4);
    uVar4 = *(undefined4 *)arg4;
    iVar9 = *(int16_t *)(arg1 + 0x34);
    uVar5 = *(undefined4 *)arg_28h;
    uVar6 = *(undefined4 *)(arg_28h + 4);
    uVar7 = *(undefined4 *)arg2;
    uVar8 = *(undefined4 *)(arg3 + 4);
    **(int16_t **)(arg1 + 0x48) = iVar9;
    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar9 + 1;
    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar9 + 2;
    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar9;
    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar9 + 2;
    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar9 + 3;
    **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)arg2;
    *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 8) = *(undefined8 *)arg4;
    *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0x10) = (undefined4)arg_30h;
    iVar10 = *(int64_t *)(arg1 + 0x40);
    *(undefined4 *)(iVar10 + 0x14) = uVar2;
    *(undefined4 *)(iVar10 + 0x18) = uVar3;
    iVar10 = *(int64_t *)(arg1 + 0x40);
    *(undefined4 *)(iVar10 + 0x1c) = uVar5;
    *(undefined4 *)(iVar10 + 0x20) = uVar1;
    *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0x24) = (undefined4)arg_30h;
    *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x28) = *(undefined8 *)arg3;
    *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x30) = *(undefined8 *)arg_28h;
    *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0x38) = (undefined4)arg_30h;
    iVar10 = *(int64_t *)(arg1 + 0x40);
    *(undefined4 *)(iVar10 + 0x3c) = uVar7;
    *(undefined4 *)(iVar10 + 0x40) = uVar8;
    iVar10 = *(int64_t *)(arg1 + 0x40);
    *(undefined4 *)(iVar10 + 0x44) = uVar4;
    *(undefined4 *)(iVar10 + 0x48) = uVar6;
    *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0x4c) = (undefined4)arg_30h;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x50;
    *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + 4;
    *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0xc;
    return;
}

// ============================================================
// Function: FUN_1801248e0
// Address: 0x1801248e0
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch

void fcn.1801248e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    float *pfVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    float *pfVar6;
    int16_t iVar7;
    int16_t iVar8;
    uint8_t uVar9;
    uint64_t uVar10;
    int16_t iVar11;
    int32_t iVar12;
    int32_t iVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    int32_t iVar16;
    int64_t iVar17;
    uint64_t uVar19;
    int64_t iVar20;
    int16_t iVar21;
    uint32_t uVar22;
    uint32_t uVar23;
    int16_t iVar24;
    uint32_t uVar25;
    uint32_t uVar26;
    uint32_t uVar27;
    uint32_t uVar28;
    float fVar29;
    undefined auVar30 [16];
    float fVar31;
    float fVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int32_t *var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uVar18;
    
    uVar25 = (uint32_t)arg4;
    uVar22 = (uint32_t)arg3;
    iVar20 = (int64_t)(int32_t)uVar22;
    if ((int32_t)uVar22 < 2) {
        return;
    }
    if ((arg4 & 0xff000000U) == 0) {
        return;
    }
    uVar2 = **(undefined4 **)(arg1 + 0x38);
    uVar3 = (*(undefined4 **)(arg1 + 0x38))[1];
    uVar15 = uVar22;
    if ((arg_28h & 1U) == 0) {
        uVar15 = uVar22 - 1;
    }
    fVar34 = *(float *)(arg1 + 0xd0);
    if ((*(uint32_t *)(arg1 + 0x30) & 1) == 0) {
        fcn.180124680(arg1, (uint64_t)(uVar15 * 6), (uint64_t)(uVar15 * 4));
        uVar19 = 0;
        if ((int32_t)uVar15 < 1) {
            return;
        }
        do {
            fVar34 = *(float *)(arg2 + uVar19 * 8);
            uVar28 = (int32_t)uVar19 + 1;
            uVar26 = 0;
            if (uVar28 != uVar22) {
                uVar26 = uVar28;
            }
            iVar20 = (int64_t)(int32_t)uVar26;
            fVar31 = *(float *)(arg2 + iVar20 * 8) - fVar34;
            fVar29 = *(float *)(arg2 + 4 + iVar20 * 8) - *(float *)(arg2 + 4 + uVar19 * 8);
            fVar35 = fVar29 * fVar29 + fVar31 * fVar31;
            if (0.0 < fVar35) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar35), ZEXT416((uint32_t)fVar35));
                fVar31 = fVar31 * auVar30._0_4_;
                fVar29 = fVar29 * auVar30._0_4_;
            }
            fVar29 = fVar29 * (float)arg_30h * 0.5;
            fVar31 = fVar31 * (float)arg_30h * 0.5;
            **(float **)(arg1 + 0x40) = fVar29 + fVar34;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 4) = *(float *)(arg2 + 4 + uVar19 * 8) - fVar31;
            iVar17 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar17 + 8) = uVar2;
            *(undefined4 *)(iVar17 + 0xc) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar25;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x14) = fVar29 + *(float *)(arg2 + iVar20 * 8);
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x18) = *(float *)(arg2 + 4 + iVar20 * 8) - fVar31;
            iVar17 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar17 + 0x1c) = uVar2;
            *(undefined4 *)(iVar17 + 0x20) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar25;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x28) = *(float *)(arg2 + iVar20 * 8) - fVar29;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x2c) = fVar31 + *(float *)(arg2 + 4 + iVar20 * 8);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x30) = uVar2;
            *(undefined4 *)(iVar20 + 0x34) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x38) = uVar25;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x3c) = *(float *)(arg2 + uVar19 * 8) - fVar29;
            iVar20 = uVar19 * 8;
            uVar19 = (uint64_t)uVar28;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x40) = fVar31 + *(float *)(arg2 + 4 + iVar20);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x44) = uVar2;
            *(undefined4 *)(iVar20 + 0x48) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x4c) = uVar25;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x50;
            **(undefined2 **)(arg1 + 0x48) = *(undefined2 *)(arg1 + 0x34);
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = *(int16_t *)(arg1 + 0x34) + 1;
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = *(int16_t *)(arg1 + 0x34) + 2;
            *(undefined2 *)(*(int64_t *)(arg1 + 0x48) + 6) = *(undefined2 *)(arg1 + 0x34);
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = *(int16_t *)(arg1 + 0x34) + 2;
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = *(int16_t *)(arg1 + 0x34) + 3;
            *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0xc;
            *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + 4;
        } while ((int32_t)uVar28 < (int32_t)uVar15);
        return;
    }
    uVar26 = uVar25 & 0xffffff;
    fVar35 = (float)arg_30h;
    if ((float)arg_30h <= 1.0) {
        fVar35 = 1.0;
    }
    iVar12 = (int32_t)fVar35;
    if (((((*(uint32_t *)(arg1 + 0x30) & 2) == 0) || (0x1f < iVar12)) || (1e-05 < fVar35 - (float)iVar12)) ||
       (fVar34 != 1.0)) {
        if ((float)arg_30h <= fVar34) {
            var_d8h._4_4_ = uVar22 * 3;
            uVar9 = 0;
            uVar28 = uVar15 * 0xc;
            goto code_r0x000180124a47;
        }
        var_d8h._4_4_ = uVar22 * 4;
        fcn.180124680(arg1, (uint64_t)(uVar15 * 0x12), (uint64_t)var_d8h._4_4_);
        iVar13 = 5;
        uVar9 = 0;
    } else {
        var_d8h._4_4_ = uVar22 * 2;
        uVar9 = 1;
        uVar28 = uVar15 * 6;
code_r0x000180124a47:
        fcn.180124680(arg1, (uint64_t)uVar28, (uint64_t)var_d8h._4_4_);
        iVar13 = 3;
    }
    func_0x0001801312e0(*(int64_t *)(arg1 + 0x38) + 0x48, iVar13 * uVar22);
    uVar18 = 0;
    uVar27 = 0;
    pfVar6 = *(float **)(*(int64_t *)(arg1 + 0x38) + 0x50);
    pfVar1 = pfVar6 + iVar20 * 2;
    uVar28 = 0;
    uVar19 = uVar18;
    if (3 < (int32_t)uVar15) {
        do {
            iVar13 = (int32_t)uVar19;
            iVar17 = (int64_t)iVar13;
            uVar14 = uVar27;
            if (iVar13 + 1U != uVar22) {
                uVar14 = iVar13 + 1U;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 4 + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2] = fVar32;
            pfVar6[iVar17 * 2 + 1] = (float)((uint32_t)fVar31 ^ 0x80000000);
            uVar14 = uVar27;
            if (iVar13 + 2U != uVar22) {
                uVar14 = iVar13 + 2U;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 8 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0xc + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2 + 2] = fVar32;
            pfVar6[iVar17 * 2 + 3] = (float)((uint32_t)fVar31 ^ 0x80000000);
            uVar14 = uVar27;
            if (iVar13 + 3U != uVar22) {
                uVar14 = iVar13 + 3U;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x10 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x14 + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2 + 4] = fVar32;
            uVar23 = iVar13 + 4;
            uVar19 = (uint64_t)uVar23;
            pfVar6[iVar17 * 2 + 5] = (float)((uint32_t)fVar31 ^ 0x80000000);
            uVar14 = uVar28;
            if (uVar23 != uVar22) {
                uVar14 = uVar23;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x18 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x1c + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2 + 6] = fVar32;
            pfVar6[iVar17 * 2 + 7] = (float)((uint32_t)fVar31 ^ 0x80000000);
        } while ((int32_t)uVar23 < (int32_t)(uVar15 - 3));
    }
    uVar14 = (uint32_t)uVar19;
    while ((int32_t)uVar14 < (int32_t)uVar15) {
        uVar14 = (int32_t)uVar19 + 1;
        uVar23 = uVar28;
        if (uVar14 != uVar22) {
            uVar23 = uVar14;
        }
        iVar17 = (int64_t)(int32_t)uVar19;
        fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar23 * 8) - *(float *)(arg2 + iVar17 * 8);
        fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar23 * 8) - *(float *)(arg2 + 4 + iVar17 * 8);
        fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
        if (0.0 < fVar29) {
            auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
            fVar32 = auVar30._0_4_ * fVar32;
            fVar31 = auVar30._0_4_ * fVar31;
        }
        pfVar6[iVar17 * 2] = fVar32;
        pfVar6[iVar17 * 2 + 1] = (float)((uint32_t)fVar31 ^ 0x80000000);
        uVar19 = (uint64_t)uVar14;
    }
    if ((arg_28h & 1U) == 0) {
        *(undefined8 *)(pfVar6 + iVar20 * 2 + -2) = *(undefined8 *)(pfVar6 + iVar20 * 2 + -4);
    }
    if (uVar9 == 0) {
        if (fVar34 < (float)arg_30h) {
            fVar35 = (fVar35 - fVar34) * 0.5;
            if ((arg_28h & 1U) == 0) {
                fVar32 = fVar35 + fVar34;
                iVar17 = (int64_t)(int32_t)(uVar22 * 4 + -4);
                fVar31 = pfVar6[1];
                fVar29 = *(float *)(arg2 + 4);
                *pfVar1 = fVar32 * *pfVar6 + *(float *)arg2;
                pfVar1[1] = fVar32 * fVar31 + fVar29;
                fVar31 = pfVar6[1];
                fVar29 = *(float *)(arg2 + 4);
                pfVar1[2] = fVar35 * *pfVar6 + *(float *)arg2;
                pfVar1[3] = fVar35 * fVar31 + fVar29;
                fVar31 = *pfVar6;
                fVar29 = *(float *)arg2;
                pfVar1[5] = *(float *)(arg2 + 4) - fVar35 * pfVar6[1];
                pfVar1[4] = fVar29 - fVar35 * fVar31;
                fVar31 = *(float *)arg2;
                fVar29 = *pfVar6;
                pfVar1[7] = *(float *)(arg2 + 4) - fVar32 * pfVar6[1];
                pfVar1[6] = fVar31 - fVar32 * fVar29;
                fVar31 = pfVar6[iVar20 * 2 + -1];
                fVar29 = *(float *)(arg2 + -4 + iVar20 * 8);
                pfVar1[iVar17 * 2] = fVar32 * pfVar6[iVar20 * 2 + -2] + *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 1] = fVar32 * fVar31 + fVar29;
                fVar31 = pfVar6[iVar20 * 2 + -1];
                fVar29 = *(float *)(arg2 + -4 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 2] = fVar35 * pfVar6[iVar20 * 2 + -2] + *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 3] = fVar35 * fVar31 + fVar29;
                fVar31 = pfVar6[iVar20 * 2 + -2];
                fVar29 = *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 5] = *(float *)(arg2 + -4 + iVar20 * 8) - fVar35 * pfVar6[iVar20 * 2 + -1];
                pfVar1[iVar17 * 2 + 4] = fVar29 - fVar35 * fVar31;
                fVar31 = pfVar6[iVar20 * 2 + -2];
                fVar29 = *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 7] = *(float *)(arg2 + -4 + iVar20 * 8) - fVar32 * pfVar6[iVar20 * 2 + -1];
                pfVar1[iVar17 * 2 + 6] = fVar29 - fVar32 * fVar31;
            }
            var_18h._0_4_ = 0;
            uVar19 = uVar18;
            if (0 < (int32_t)uVar15) {
                uVar27 = 1;
                uVar10 = uVar18;
                iVar12 = *(int32_t *)(arg1 + 0x34);
                do {
                    if (uVar27 == uVar22) {
                        iVar13 = *(int32_t *)(arg1 + 0x34);
                        uVar14 = uVar28;
                    } else {
                        iVar13 = iVar12 + 4;
                        uVar14 = uVar27;
                    }
                    iVar20 = (int64_t)(int32_t)uVar14;
                    fVar29 = (pfVar6[iVar20 * 2] + pfVar6[uVar10 * 2]) * 0.5;
                    fVar32 = (pfVar6[iVar20 * 2 + 1] + pfVar6[uVar10 * 2 + 1]) * 0.5;
                    fVar31 = fVar32 * fVar32 + fVar29 * fVar29;
                    if (1e-06 < fVar31) {
                        fVar31 = 1.0 / fVar31;
                        fVar33 = 100.0;
                        if (fVar31 <= 100.0) {
                            fVar33 = fVar31;
                        }
                        fVar29 = fVar29 * fVar33;
                        fVar32 = fVar32 * fVar33;
                    }
                    iVar17 = (int64_t)(int32_t)(uVar14 * 4);
                    iVar7 = (int16_t)iVar13;
                    iVar24 = iVar7 + 1;
                    fVar31 = (fVar34 + fVar35) * fVar29;
                    iVar21 = iVar7 + 2;
                    uVar27 = uVar27 + 1;
                    fVar33 = (fVar34 + fVar35) * fVar32;
                    pfVar1[iVar17 * 2] = fVar31 + *(float *)(arg2 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 1] = fVar33 + *(float *)(arg2 + 4 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 2] = fVar29 * fVar35 + *(float *)(arg2 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 3] = fVar32 * fVar35 + *(float *)(arg2 + 4 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 4] = *(float *)(arg2 + iVar20 * 8) - fVar29 * fVar35;
                    pfVar1[iVar17 * 2 + 5] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar32 * fVar35;
                    pfVar1[iVar17 * 2 + 6] = *(float *)(arg2 + iVar20 * 8) - fVar31;
                    iVar8 = (int16_t)iVar12;
                    iVar11 = iVar8 + 2;
                    pfVar1[iVar17 * 2 + 7] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar33;
                    **(int16_t **)(arg1 + 0x48) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar8 + 1;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar11;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar21;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xc) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xe) = iVar8 + 1;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x10) = iVar8;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x12) = iVar8;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x14) = iVar7;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x16) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x18) = iVar21;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x1a) = iVar11;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x1c) = iVar8 + 3;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x1e) = iVar8 + 3;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x20) = iVar7 + 3;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x22) = iVar21;
                    *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0x24;
                    var_18h._0_4_ = (uint32_t)var_18h + 1;
                    uVar10 = (uint64_t)(uint32_t)var_18h;
                    iVar12 = iVar13;
                } while ((int32_t)(uint32_t)var_18h < (int32_t)uVar15);
            }
            do {
                uVar15 = (int32_t)uVar18 + 1;
                uVar18 = (uint64_t)uVar15;
                iVar17 = (int64_t)(int32_t)uVar19;
                **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(pfVar1 + iVar17 * 2);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 8) = uVar2;
                *(undefined4 *)(iVar20 + 0xc) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar26;
                *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x14) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 2);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 0x1c) = uVar2;
                *(undefined4 *)(iVar20 + 0x20) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar25;
                *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x28) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 4);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 0x30) = uVar2;
                *(undefined4 *)(iVar20 + 0x34) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x38) = uVar25;
                *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x3c) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 6);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 0x44) = uVar2;
                *(undefined4 *)(iVar20 + 0x48) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x4c) = uVar26;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x50;
                uVar19 = (uint64_t)((int32_t)uVar19 + 4);
            } while ((int32_t)uVar15 < (int32_t)uVar22);
            goto code_r0x00018012554d;
        }
    } else {
        fVar34 = fVar35 * 0.5 + 1.0;
    }
    if ((arg_28h & 1U) == 0) {
        iVar20 = iVar20 + -1;
        iVar17 = (int64_t)(int32_t)(uVar22 * 2);
        fVar35 = pfVar6[1];
        fVar31 = *(float *)(arg2 + 4);
        *pfVar1 = fVar34 * *pfVar6 + *(float *)arg2;
        pfVar1[1] = fVar34 * fVar35 + fVar31;
        fVar35 = *pfVar6;
        fVar31 = *(float *)arg2;
        pfVar1[3] = *(float *)(arg2 + 4) - fVar34 * pfVar6[1];
        pfVar1[2] = fVar31 - fVar34 * fVar35;
        fVar35 = pfVar6[iVar20 * 2 + 1];
        fVar31 = *(float *)(arg2 + 4 + iVar20 * 8);
        pfVar1[iVar17 * 2 + -4] = fVar34 * pfVar6[iVar20 * 2] + *(float *)(arg2 + iVar20 * 8);
        pfVar1[iVar17 * 2 + -3] = fVar34 * fVar35 + fVar31;
        fVar35 = pfVar6[iVar20 * 2];
        fVar31 = *(float *)(arg2 + iVar20 * 8);
        pfVar1[iVar17 * 2 + -1] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar34 * pfVar6[iVar20 * 2 + 1];
        pfVar1[iVar17 * 2 + -2] = fVar31 - fVar34 * fVar35;
    }
    if (0 < (int32_t)uVar15) {
        uVar28 = 1;
        uVar19 = uVar18;
        iVar13 = *(int32_t *)(arg1 + 0x34);
        do {
            if (uVar28 == uVar22) {
                iVar16 = *(int32_t *)(arg1 + 0x34);
                uVar14 = uVar27;
            } else {
                iVar16 = (uVar9 ^ 1) + 2 + iVar13;
                uVar14 = uVar28;
            }
            iVar20 = (int64_t)(int32_t)uVar14;
            fVar31 = (pfVar6[iVar20 * 2] + pfVar6[uVar19 * 2]) * 0.5;
            fVar29 = (pfVar6[iVar20 * 2 + 1] + pfVar6[uVar19 * 2 + 1]) * 0.5;
            fVar35 = fVar29 * fVar29 + fVar31 * fVar31;
            if (1e-06 < fVar35) {
                fVar35 = 1.0 / fVar35;
                fVar32 = 100.0;
                if (fVar35 <= 100.0) {
                    fVar32 = fVar35;
                }
                fVar31 = fVar31 * fVar32;
                fVar29 = fVar29 * fVar32;
            }
            iVar8 = (int16_t)iVar16;
            iVar21 = iVar8 + 1;
            iVar17 = (int64_t)(int32_t)(uVar14 * 2);
            pfVar1[iVar17 * 2] = fVar31 * fVar34 + *(float *)(arg2 + iVar20 * 8);
            pfVar1[iVar17 * 2 + 1] = fVar29 * fVar34 + *(float *)(arg2 + 4 + iVar20 * 8);
            pfVar1[iVar17 * 2 + 2] = *(float *)(arg2 + iVar20 * 8) - fVar31 * fVar34;
            iVar7 = (int16_t)iVar13;
            iVar11 = iVar7 + 1;
            pfVar1[iVar17 * 2 + 3] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar29 * fVar34;
            **(int16_t **)(arg1 + 0x48) = iVar8;
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar7;
            if (uVar9 == 0) {
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar7 + 2;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar7 + 2;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar8 + 2;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar8;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xc) = iVar21;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xe) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x10) = iVar7;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x12) = iVar7;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x14) = iVar8;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x16) = iVar21;
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0x18;
            } else {
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar21;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar8;
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0xc;
            }
            uVar14 = (int32_t)uVar19 + 1;
            uVar19 = (uint64_t)uVar14;
            uVar28 = uVar28 + 1;
            iVar13 = iVar16;
        } while ((int32_t)uVar14 < (int32_t)uVar15);
    }
    if (uVar9 == 0) {
        do {
            **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(arg2 + uVar18 * 8);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 8) = uVar2;
            *(undefined4 *)(iVar20 + 0xc) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar25;
            iVar17 = (int64_t)((int32_t)uVar18 * 2);
            uVar15 = (int32_t)uVar18 + 1;
            uVar18 = (uint64_t)uVar15;
            *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x14) = *(undefined8 *)(pfVar1 + iVar17 * 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x1c) = uVar2;
            *(undefined4 *)(iVar20 + 0x20) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar26;
            *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x28) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x30) = uVar2;
            *(undefined4 *)(iVar20 + 0x34) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x38) = uVar26;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x3c;
        } while ((int32_t)uVar15 < (int32_t)uVar22);
    } else {
        iVar17 = (int64_t)iVar12;
        iVar20 = *(int64_t *)(*(int64_t *)(arg1 + 0x38) + 8);
        uVar2 = *(undefined4 *)(iVar20 + iVar17 * 0x10);
        uVar3 = *(undefined4 *)(iVar20 + 4 + iVar17 * 0x10);
        uVar4 = *(undefined4 *)(iVar20 + 8 + iVar17 * 0x10);
        uVar5 = *(undefined4 *)(iVar20 + 0xc + iVar17 * 0x10);
        do {
            iVar12 = (int32_t)uVar18;
            uVar15 = iVar12 + 1;
            uVar18 = (uint64_t)uVar15;
            iVar17 = (int64_t)(iVar12 * 2);
            **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(pfVar1 + iVar17 * 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 8) = uVar2;
            *(undefined4 *)(iVar20 + 0xc) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar25;
            *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x14) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x1c) = uVar4;
            *(undefined4 *)(iVar20 + 0x20) = uVar5;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar25;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x28;
        } while ((int32_t)uVar15 < (int32_t)uVar22);
    }
code_r0x00018012554d:
    var_c8h = (int32_t *)(arg1 + 0x34);
    *var_c8h = *var_c8h + (var_d8h._4_4_ & 0xffff);
    return;
}

// ============================================================
// Function: FUN_180124919
// Address: 0x180124919
// Size: 101 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch

void fcn.1801248e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    float *pfVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    float *pfVar6;
    int16_t iVar7;
    int16_t iVar8;
    uint8_t uVar9;
    uint64_t uVar10;
    int16_t iVar11;
    int32_t iVar12;
    int32_t iVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    int32_t iVar16;
    int64_t iVar17;
    uint64_t uVar19;
    int64_t iVar20;
    int16_t iVar21;
    uint32_t uVar22;
    uint32_t uVar23;
    int16_t iVar24;
    uint32_t uVar25;
    uint32_t uVar26;
    uint32_t uVar27;
    uint32_t uVar28;
    float fVar29;
    undefined auVar30 [16];
    float fVar31;
    float fVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int32_t *var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uVar18;
    
    uVar25 = (uint32_t)arg4;
    uVar22 = (uint32_t)arg3;
    iVar20 = (int64_t)(int32_t)uVar22;
    if ((int32_t)uVar22 < 2) {
        return;
    }
    if ((arg4 & 0xff000000U) == 0) {
        return;
    }
    uVar2 = **(undefined4 **)(arg1 + 0x38);
    uVar3 = (*(undefined4 **)(arg1 + 0x38))[1];
    uVar15 = uVar22;
    if ((arg_28h & 1U) == 0) {
        uVar15 = uVar22 - 1;
    }
    fVar34 = *(float *)(arg1 + 0xd0);
    if ((*(uint32_t *)(arg1 + 0x30) & 1) == 0) {
        fcn.180124680(arg1, (uint64_t)(uVar15 * 6), (uint64_t)(uVar15 * 4));
        uVar19 = 0;
        if ((int32_t)uVar15 < 1) {
            return;
        }
        do {
            fVar34 = *(float *)(arg2 + uVar19 * 8);
            uVar28 = (int32_t)uVar19 + 1;
            uVar26 = 0;
            if (uVar28 != uVar22) {
                uVar26 = uVar28;
            }
            iVar20 = (int64_t)(int32_t)uVar26;
            fVar31 = *(float *)(arg2 + iVar20 * 8) - fVar34;
            fVar29 = *(float *)(arg2 + 4 + iVar20 * 8) - *(float *)(arg2 + 4 + uVar19 * 8);
            fVar35 = fVar29 * fVar29 + fVar31 * fVar31;
            if (0.0 < fVar35) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar35), ZEXT416((uint32_t)fVar35));
                fVar31 = fVar31 * auVar30._0_4_;
                fVar29 = fVar29 * auVar30._0_4_;
            }
            fVar29 = fVar29 * (float)arg_30h * 0.5;
            fVar31 = fVar31 * (float)arg_30h * 0.5;
            **(float **)(arg1 + 0x40) = fVar29 + fVar34;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 4) = *(float *)(arg2 + 4 + uVar19 * 8) - fVar31;
            iVar17 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar17 + 8) = uVar2;
            *(undefined4 *)(iVar17 + 0xc) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar25;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x14) = fVar29 + *(float *)(arg2 + iVar20 * 8);
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x18) = *(float *)(arg2 + 4 + iVar20 * 8) - fVar31;
            iVar17 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar17 + 0x1c) = uVar2;
            *(undefined4 *)(iVar17 + 0x20) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar25;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x28) = *(float *)(arg2 + iVar20 * 8) - fVar29;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x2c) = fVar31 + *(float *)(arg2 + 4 + iVar20 * 8);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x30) = uVar2;
            *(undefined4 *)(iVar20 + 0x34) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x38) = uVar25;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x3c) = *(float *)(arg2 + uVar19 * 8) - fVar29;
            iVar20 = uVar19 * 8;
            uVar19 = (uint64_t)uVar28;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x40) = fVar31 + *(float *)(arg2 + 4 + iVar20);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x44) = uVar2;
            *(undefined4 *)(iVar20 + 0x48) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x4c) = uVar25;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x50;
            **(undefined2 **)(arg1 + 0x48) = *(undefined2 *)(arg1 + 0x34);
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = *(int16_t *)(arg1 + 0x34) + 1;
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = *(int16_t *)(arg1 + 0x34) + 2;
            *(undefined2 *)(*(int64_t *)(arg1 + 0x48) + 6) = *(undefined2 *)(arg1 + 0x34);
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = *(int16_t *)(arg1 + 0x34) + 2;
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = *(int16_t *)(arg1 + 0x34) + 3;
            *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0xc;
            *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + 4;
        } while ((int32_t)uVar28 < (int32_t)uVar15);
        return;
    }
    uVar26 = uVar25 & 0xffffff;
    fVar35 = (float)arg_30h;
    if ((float)arg_30h <= 1.0) {
        fVar35 = 1.0;
    }
    iVar12 = (int32_t)fVar35;
    if (((((*(uint32_t *)(arg1 + 0x30) & 2) == 0) || (0x1f < iVar12)) || (1e-05 < fVar35 - (float)iVar12)) ||
       (fVar34 != 1.0)) {
        if ((float)arg_30h <= fVar34) {
            var_d8h._4_4_ = uVar22 * 3;
            uVar9 = 0;
            uVar28 = uVar15 * 0xc;
            goto code_r0x000180124a47;
        }
        var_d8h._4_4_ = uVar22 * 4;
        fcn.180124680(arg1, (uint64_t)(uVar15 * 0x12), (uint64_t)var_d8h._4_4_);
        iVar13 = 5;
        uVar9 = 0;
    } else {
        var_d8h._4_4_ = uVar22 * 2;
        uVar9 = 1;
        uVar28 = uVar15 * 6;
code_r0x000180124a47:
        fcn.180124680(arg1, (uint64_t)uVar28, (uint64_t)var_d8h._4_4_);
        iVar13 = 3;
    }
    func_0x0001801312e0(*(int64_t *)(arg1 + 0x38) + 0x48, iVar13 * uVar22);
    uVar18 = 0;
    uVar27 = 0;
    pfVar6 = *(float **)(*(int64_t *)(arg1 + 0x38) + 0x50);
    pfVar1 = pfVar6 + iVar20 * 2;
    uVar28 = 0;
    uVar19 = uVar18;
    if (3 < (int32_t)uVar15) {
        do {
            iVar13 = (int32_t)uVar19;
            iVar17 = (int64_t)iVar13;
            uVar14 = uVar27;
            if (iVar13 + 1U != uVar22) {
                uVar14 = iVar13 + 1U;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 4 + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2] = fVar32;
            pfVar6[iVar17 * 2 + 1] = (float)((uint32_t)fVar31 ^ 0x80000000);
            uVar14 = uVar27;
            if (iVar13 + 2U != uVar22) {
                uVar14 = iVar13 + 2U;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 8 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0xc + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2 + 2] = fVar32;
            pfVar6[iVar17 * 2 + 3] = (float)((uint32_t)fVar31 ^ 0x80000000);
            uVar14 = uVar27;
            if (iVar13 + 3U != uVar22) {
                uVar14 = iVar13 + 3U;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x10 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x14 + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2 + 4] = fVar32;
            uVar23 = iVar13 + 4;
            uVar19 = (uint64_t)uVar23;
            pfVar6[iVar17 * 2 + 5] = (float)((uint32_t)fVar31 ^ 0x80000000);
            uVar14 = uVar28;
            if (uVar23 != uVar22) {
                uVar14 = uVar23;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x18 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x1c + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2 + 6] = fVar32;
            pfVar6[iVar17 * 2 + 7] = (float)((uint32_t)fVar31 ^ 0x80000000);
        } while ((int32_t)uVar23 < (int32_t)(uVar15 - 3));
    }
    uVar14 = (uint32_t)uVar19;
    while ((int32_t)uVar14 < (int32_t)uVar15) {
        uVar14 = (int32_t)uVar19 + 1;
        uVar23 = uVar28;
        if (uVar14 != uVar22) {
            uVar23 = uVar14;
        }
        iVar17 = (int64_t)(int32_t)uVar19;
        fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar23 * 8) - *(float *)(arg2 + iVar17 * 8);
        fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar23 * 8) - *(float *)(arg2 + 4 + iVar17 * 8);
        fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
        if (0.0 < fVar29) {
            auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
            fVar32 = auVar30._0_4_ * fVar32;
            fVar31 = auVar30._0_4_ * fVar31;
        }
        pfVar6[iVar17 * 2] = fVar32;
        pfVar6[iVar17 * 2 + 1] = (float)((uint32_t)fVar31 ^ 0x80000000);
        uVar19 = (uint64_t)uVar14;
    }
    if ((arg_28h & 1U) == 0) {
        *(undefined8 *)(pfVar6 + iVar20 * 2 + -2) = *(undefined8 *)(pfVar6 + iVar20 * 2 + -4);
    }
    if (uVar9 == 0) {
        if (fVar34 < (float)arg_30h) {
            fVar35 = (fVar35 - fVar34) * 0.5;
            if ((arg_28h & 1U) == 0) {
                fVar32 = fVar35 + fVar34;
                iVar17 = (int64_t)(int32_t)(uVar22 * 4 + -4);
                fVar31 = pfVar6[1];
                fVar29 = *(float *)(arg2 + 4);
                *pfVar1 = fVar32 * *pfVar6 + *(float *)arg2;
                pfVar1[1] = fVar32 * fVar31 + fVar29;
                fVar31 = pfVar6[1];
                fVar29 = *(float *)(arg2 + 4);
                pfVar1[2] = fVar35 * *pfVar6 + *(float *)arg2;
                pfVar1[3] = fVar35 * fVar31 + fVar29;
                fVar31 = *pfVar6;
                fVar29 = *(float *)arg2;
                pfVar1[5] = *(float *)(arg2 + 4) - fVar35 * pfVar6[1];
                pfVar1[4] = fVar29 - fVar35 * fVar31;
                fVar31 = *(float *)arg2;
                fVar29 = *pfVar6;
                pfVar1[7] = *(float *)(arg2 + 4) - fVar32 * pfVar6[1];
                pfVar1[6] = fVar31 - fVar32 * fVar29;
                fVar31 = pfVar6[iVar20 * 2 + -1];
                fVar29 = *(float *)(arg2 + -4 + iVar20 * 8);
                pfVar1[iVar17 * 2] = fVar32 * pfVar6[iVar20 * 2 + -2] + *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 1] = fVar32 * fVar31 + fVar29;
                fVar31 = pfVar6[iVar20 * 2 + -1];
                fVar29 = *(float *)(arg2 + -4 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 2] = fVar35 * pfVar6[iVar20 * 2 + -2] + *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 3] = fVar35 * fVar31 + fVar29;
                fVar31 = pfVar6[iVar20 * 2 + -2];
                fVar29 = *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 5] = *(float *)(arg2 + -4 + iVar20 * 8) - fVar35 * pfVar6[iVar20 * 2 + -1];
                pfVar1[iVar17 * 2 + 4] = fVar29 - fVar35 * fVar31;
                fVar31 = pfVar6[iVar20 * 2 + -2];
                fVar29 = *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 7] = *(float *)(arg2 + -4 + iVar20 * 8) - fVar32 * pfVar6[iVar20 * 2 + -1];
                pfVar1[iVar17 * 2 + 6] = fVar29 - fVar32 * fVar31;
            }
            var_18h._0_4_ = 0;
            uVar19 = uVar18;
            if (0 < (int32_t)uVar15) {
                uVar27 = 1;
                uVar10 = uVar18;
                iVar12 = *(int32_t *)(arg1 + 0x34);
                do {
                    if (uVar27 == uVar22) {
                        iVar13 = *(int32_t *)(arg1 + 0x34);
                        uVar14 = uVar28;
                    } else {
                        iVar13 = iVar12 + 4;
                        uVar14 = uVar27;
                    }
                    iVar20 = (int64_t)(int32_t)uVar14;
                    fVar29 = (pfVar6[iVar20 * 2] + pfVar6[uVar10 * 2]) * 0.5;
                    fVar32 = (pfVar6[iVar20 * 2 + 1] + pfVar6[uVar10 * 2 + 1]) * 0.5;
                    fVar31 = fVar32 * fVar32 + fVar29 * fVar29;
                    if (1e-06 < fVar31) {
                        fVar31 = 1.0 / fVar31;
                        fVar33 = 100.0;
                        if (fVar31 <= 100.0) {
                            fVar33 = fVar31;
                        }
                        fVar29 = fVar29 * fVar33;
                        fVar32 = fVar32 * fVar33;
                    }
                    iVar17 = (int64_t)(int32_t)(uVar14 * 4);
                    iVar7 = (int16_t)iVar13;
                    iVar24 = iVar7 + 1;
                    fVar31 = (fVar34 + fVar35) * fVar29;
                    iVar21 = iVar7 + 2;
                    uVar27 = uVar27 + 1;
                    fVar33 = (fVar34 + fVar35) * fVar32;
                    pfVar1[iVar17 * 2] = fVar31 + *(float *)(arg2 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 1] = fVar33 + *(float *)(arg2 + 4 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 2] = fVar29 * fVar35 + *(float *)(arg2 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 3] = fVar32 * fVar35 + *(float *)(arg2 + 4 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 4] = *(float *)(arg2 + iVar20 * 8) - fVar29 * fVar35;
                    pfVar1[iVar17 * 2 + 5] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar32 * fVar35;
                    pfVar1[iVar17 * 2 + 6] = *(float *)(arg2 + iVar20 * 8) - fVar31;
                    iVar8 = (int16_t)iVar12;
                    iVar11 = iVar8 + 2;
                    pfVar1[iVar17 * 2 + 7] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar33;
                    **(int16_t **)(arg1 + 0x48) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar8 + 1;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar11;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar21;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xc) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xe) = iVar8 + 1;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x10) = iVar8;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x12) = iVar8;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x14) = iVar7;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x16) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x18) = iVar21;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x1a) = iVar11;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x1c) = iVar8 + 3;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x1e) = iVar8 + 3;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x20) = iVar7 + 3;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x22) = iVar21;
                    *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0x24;
                    var_18h._0_4_ = (uint32_t)var_18h + 1;
                    uVar10 = (uint64_t)(uint32_t)var_18h;
                    iVar12 = iVar13;
                } while ((int32_t)(uint32_t)var_18h < (int32_t)uVar15);
            }
            do {
                uVar15 = (int32_t)uVar18 + 1;
                uVar18 = (uint64_t)uVar15;
                iVar17 = (int64_t)(int32_t)uVar19;
                **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(pfVar1 + iVar17 * 2);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 8) = uVar2;
                *(undefined4 *)(iVar20 + 0xc) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar26;
                *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x14) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 2);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 0x1c) = uVar2;
                *(undefined4 *)(iVar20 + 0x20) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar25;
                *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x28) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 4);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 0x30) = uVar2;
                *(undefined4 *)(iVar20 + 0x34) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x38) = uVar25;
                *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x3c) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 6);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 0x44) = uVar2;
                *(undefined4 *)(iVar20 + 0x48) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x4c) = uVar26;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x50;
                uVar19 = (uint64_t)((int32_t)uVar19 + 4);
            } while ((int32_t)uVar15 < (int32_t)uVar22);
            goto code_r0x00018012554d;
        }
    } else {
        fVar34 = fVar35 * 0.5 + 1.0;
    }
    if ((arg_28h & 1U) == 0) {
        iVar20 = iVar20 + -1;
        iVar17 = (int64_t)(int32_t)(uVar22 * 2);
        fVar35 = pfVar6[1];
        fVar31 = *(float *)(arg2 + 4);
        *pfVar1 = fVar34 * *pfVar6 + *(float *)arg2;
        pfVar1[1] = fVar34 * fVar35 + fVar31;
        fVar35 = *pfVar6;
        fVar31 = *(float *)arg2;
        pfVar1[3] = *(float *)(arg2 + 4) - fVar34 * pfVar6[1];
        pfVar1[2] = fVar31 - fVar34 * fVar35;
        fVar35 = pfVar6[iVar20 * 2 + 1];
        fVar31 = *(float *)(arg2 + 4 + iVar20 * 8);
        pfVar1[iVar17 * 2 + -4] = fVar34 * pfVar6[iVar20 * 2] + *(float *)(arg2 + iVar20 * 8);
        pfVar1[iVar17 * 2 + -3] = fVar34 * fVar35 + fVar31;
        fVar35 = pfVar6[iVar20 * 2];
        fVar31 = *(float *)(arg2 + iVar20 * 8);
        pfVar1[iVar17 * 2 + -1] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar34 * pfVar6[iVar20 * 2 + 1];
        pfVar1[iVar17 * 2 + -2] = fVar31 - fVar34 * fVar35;
    }
    if (0 < (int32_t)uVar15) {
        uVar28 = 1;
        uVar19 = uVar18;
        iVar13 = *(int32_t *)(arg1 + 0x34);
        do {
            if (uVar28 == uVar22) {
                iVar16 = *(int32_t *)(arg1 + 0x34);
                uVar14 = uVar27;
            } else {
                iVar16 = (uVar9 ^ 1) + 2 + iVar13;
                uVar14 = uVar28;
            }
            iVar20 = (int64_t)(int32_t)uVar14;
            fVar31 = (pfVar6[iVar20 * 2] + pfVar6[uVar19 * 2]) * 0.5;
            fVar29 = (pfVar6[iVar20 * 2 + 1] + pfVar6[uVar19 * 2 + 1]) * 0.5;
            fVar35 = fVar29 * fVar29 + fVar31 * fVar31;
            if (1e-06 < fVar35) {
                fVar35 = 1.0 / fVar35;
                fVar32 = 100.0;
                if (fVar35 <= 100.0) {
                    fVar32 = fVar35;
                }
                fVar31 = fVar31 * fVar32;
                fVar29 = fVar29 * fVar32;
            }
            iVar8 = (int16_t)iVar16;
            iVar21 = iVar8 + 1;
            iVar17 = (int64_t)(int32_t)(uVar14 * 2);
            pfVar1[iVar17 * 2] = fVar31 * fVar34 + *(float *)(arg2 + iVar20 * 8);
            pfVar1[iVar17 * 2 + 1] = fVar29 * fVar34 + *(float *)(arg2 + 4 + iVar20 * 8);
            pfVar1[iVar17 * 2 + 2] = *(float *)(arg2 + iVar20 * 8) - fVar31 * fVar34;
            iVar7 = (int16_t)iVar13;
            iVar11 = iVar7 + 1;
            pfVar1[iVar17 * 2 + 3] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar29 * fVar34;
            **(int16_t **)(arg1 + 0x48) = iVar8;
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar7;
            if (uVar9 == 0) {
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar7 + 2;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar7 + 2;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar8 + 2;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar8;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xc) = iVar21;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xe) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x10) = iVar7;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x12) = iVar7;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x14) = iVar8;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x16) = iVar21;
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0x18;
            } else {
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar21;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar8;
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0xc;
            }
            uVar14 = (int32_t)uVar19 + 1;
            uVar19 = (uint64_t)uVar14;
            uVar28 = uVar28 + 1;
            iVar13 = iVar16;
        } while ((int32_t)uVar14 < (int32_t)uVar15);
    }
    if (uVar9 == 0) {
        do {
            **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(arg2 + uVar18 * 8);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 8) = uVar2;
            *(undefined4 *)(iVar20 + 0xc) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar25;
            iVar17 = (int64_t)((int32_t)uVar18 * 2);
            uVar15 = (int32_t)uVar18 + 1;
            uVar18 = (uint64_t)uVar15;
            *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x14) = *(undefined8 *)(pfVar1 + iVar17 * 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x1c) = uVar2;
            *(undefined4 *)(iVar20 + 0x20) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar26;
            *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x28) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x30) = uVar2;
            *(undefined4 *)(iVar20 + 0x34) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x38) = uVar26;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x3c;
        } while ((int32_t)uVar15 < (int32_t)uVar22);
    } else {
        iVar17 = (int64_t)iVar12;
        iVar20 = *(int64_t *)(*(int64_t *)(arg1 + 0x38) + 8);
        uVar2 = *(undefined4 *)(iVar20 + iVar17 * 0x10);
        uVar3 = *(undefined4 *)(iVar20 + 4 + iVar17 * 0x10);
        uVar4 = *(undefined4 *)(iVar20 + 8 + iVar17 * 0x10);
        uVar5 = *(undefined4 *)(iVar20 + 0xc + iVar17 * 0x10);
        do {
            iVar12 = (int32_t)uVar18;
            uVar15 = iVar12 + 1;
            uVar18 = (uint64_t)uVar15;
            iVar17 = (int64_t)(iVar12 * 2);
            **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(pfVar1 + iVar17 * 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 8) = uVar2;
            *(undefined4 *)(iVar20 + 0xc) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar25;
            *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x14) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x1c) = uVar4;
            *(undefined4 *)(iVar20 + 0x20) = uVar5;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar25;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x28;
        } while ((int32_t)uVar15 < (int32_t)uVar22);
    }
code_r0x00018012554d:
    var_c8h = (int32_t *)(arg1 + 0x34);
    *var_c8h = *var_c8h + (var_d8h._4_4_ & 0xffff);
    return;
}

// ============================================================
// Function: FUN_18012497e
// Address: 0x18012497e
// Size: 1313 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch

void fcn.1801248e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    float *pfVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    float *pfVar6;
    int16_t iVar7;
    int16_t iVar8;
    uint8_t uVar9;
    uint64_t uVar10;
    int16_t iVar11;
    int32_t iVar12;
    int32_t iVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    int32_t iVar16;
    int64_t iVar17;
    uint64_t uVar19;
    int64_t iVar20;
    int16_t iVar21;
    uint32_t uVar22;
    uint32_t uVar23;
    int16_t iVar24;
    uint32_t uVar25;
    uint32_t uVar26;
    uint32_t uVar27;
    uint32_t uVar28;
    float fVar29;
    undefined auVar30 [16];
    float fVar31;
    float fVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int32_t *var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uVar18;
    
    uVar25 = (uint32_t)arg4;
    uVar22 = (uint32_t)arg3;
    iVar20 = (int64_t)(int32_t)uVar22;
    if ((int32_t)uVar22 < 2) {
        return;
    }
    if ((arg4 & 0xff000000U) == 0) {
        return;
    }
    uVar2 = **(undefined4 **)(arg1 + 0x38);
    uVar3 = (*(undefined4 **)(arg1 + 0x38))[1];
    uVar15 = uVar22;
    if ((arg_28h & 1U) == 0) {
        uVar15 = uVar22 - 1;
    }
    fVar34 = *(float *)(arg1 + 0xd0);
    if ((*(uint32_t *)(arg1 + 0x30) & 1) == 0) {
        fcn.180124680(arg1, (uint64_t)(uVar15 * 6), (uint64_t)(uVar15 * 4));
        uVar19 = 0;
        if ((int32_t)uVar15 < 1) {
            return;
        }
        do {
            fVar34 = *(float *)(arg2 + uVar19 * 8);
            uVar28 = (int32_t)uVar19 + 1;
            uVar26 = 0;
            if (uVar28 != uVar22) {
                uVar26 = uVar28;
            }
            iVar20 = (int64_t)(int32_t)uVar26;
            fVar31 = *(float *)(arg2 + iVar20 * 8) - fVar34;
            fVar29 = *(float *)(arg2 + 4 + iVar20 * 8) - *(float *)(arg2 + 4 + uVar19 * 8);
            fVar35 = fVar29 * fVar29 + fVar31 * fVar31;
            if (0.0 < fVar35) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar35), ZEXT416((uint32_t)fVar35));
                fVar31 = fVar31 * auVar30._0_4_;
                fVar29 = fVar29 * auVar30._0_4_;
            }
            fVar29 = fVar29 * (float)arg_30h * 0.5;
            fVar31 = fVar31 * (float)arg_30h * 0.5;
            **(float **)(arg1 + 0x40) = fVar29 + fVar34;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 4) = *(float *)(arg2 + 4 + uVar19 * 8) - fVar31;
            iVar17 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar17 + 8) = uVar2;
            *(undefined4 *)(iVar17 + 0xc) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar25;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x14) = fVar29 + *(float *)(arg2 + iVar20 * 8);
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x18) = *(float *)(arg2 + 4 + iVar20 * 8) - fVar31;
            iVar17 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar17 + 0x1c) = uVar2;
            *(undefined4 *)(iVar17 + 0x20) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar25;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x28) = *(float *)(arg2 + iVar20 * 8) - fVar29;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x2c) = fVar31 + *(float *)(arg2 + 4 + iVar20 * 8);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x30) = uVar2;
            *(undefined4 *)(iVar20 + 0x34) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x38) = uVar25;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x3c) = *(float *)(arg2 + uVar19 * 8) - fVar29;
            iVar20 = uVar19 * 8;
            uVar19 = (uint64_t)uVar28;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x40) = fVar31 + *(float *)(arg2 + 4 + iVar20);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x44) = uVar2;
            *(undefined4 *)(iVar20 + 0x48) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x4c) = uVar25;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x50;
            **(undefined2 **)(arg1 + 0x48) = *(undefined2 *)(arg1 + 0x34);
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = *(int16_t *)(arg1 + 0x34) + 1;
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = *(int16_t *)(arg1 + 0x34) + 2;
            *(undefined2 *)(*(int64_t *)(arg1 + 0x48) + 6) = *(undefined2 *)(arg1 + 0x34);
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = *(int16_t *)(arg1 + 0x34) + 2;
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = *(int16_t *)(arg1 + 0x34) + 3;
            *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0xc;
            *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + 4;
        } while ((int32_t)uVar28 < (int32_t)uVar15);
        return;
    }
    uVar26 = uVar25 & 0xffffff;
    fVar35 = (float)arg_30h;
    if ((float)arg_30h <= 1.0) {
        fVar35 = 1.0;
    }
    iVar12 = (int32_t)fVar35;
    if (((((*(uint32_t *)(arg1 + 0x30) & 2) == 0) || (0x1f < iVar12)) || (1e-05 < fVar35 - (float)iVar12)) ||
       (fVar34 != 1.0)) {
        if ((float)arg_30h <= fVar34) {
            var_d8h._4_4_ = uVar22 * 3;
            uVar9 = 0;
            uVar28 = uVar15 * 0xc;
            goto code_r0x000180124a47;
        }
        var_d8h._4_4_ = uVar22 * 4;
        fcn.180124680(arg1, (uint64_t)(uVar15 * 0x12), (uint64_t)var_d8h._4_4_);
        iVar13 = 5;
        uVar9 = 0;
    } else {
        var_d8h._4_4_ = uVar22 * 2;
        uVar9 = 1;
        uVar28 = uVar15 * 6;
code_r0x000180124a47:
        fcn.180124680(arg1, (uint64_t)uVar28, (uint64_t)var_d8h._4_4_);
        iVar13 = 3;
    }
    func_0x0001801312e0(*(int64_t *)(arg1 + 0x38) + 0x48, iVar13 * uVar22);
    uVar18 = 0;
    uVar27 = 0;
    pfVar6 = *(float **)(*(int64_t *)(arg1 + 0x38) + 0x50);
    pfVar1 = pfVar6 + iVar20 * 2;
    uVar28 = 0;
    uVar19 = uVar18;
    if (3 < (int32_t)uVar15) {
        do {
            iVar13 = (int32_t)uVar19;
            iVar17 = (int64_t)iVar13;
            uVar14 = uVar27;
            if (iVar13 + 1U != uVar22) {
                uVar14 = iVar13 + 1U;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 4 + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2] = fVar32;
            pfVar6[iVar17 * 2 + 1] = (float)((uint32_t)fVar31 ^ 0x80000000);
            uVar14 = uVar27;
            if (iVar13 + 2U != uVar22) {
                uVar14 = iVar13 + 2U;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 8 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0xc + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2 + 2] = fVar32;
            pfVar6[iVar17 * 2 + 3] = (float)((uint32_t)fVar31 ^ 0x80000000);
            uVar14 = uVar27;
            if (iVar13 + 3U != uVar22) {
                uVar14 = iVar13 + 3U;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x10 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x14 + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2 + 4] = fVar32;
            uVar23 = iVar13 + 4;
            uVar19 = (uint64_t)uVar23;
            pfVar6[iVar17 * 2 + 5] = (float)((uint32_t)fVar31 ^ 0x80000000);
            uVar14 = uVar28;
            if (uVar23 != uVar22) {
                uVar14 = uVar23;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x18 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x1c + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2 + 6] = fVar32;
            pfVar6[iVar17 * 2 + 7] = (float)((uint32_t)fVar31 ^ 0x80000000);
        } while ((int32_t)uVar23 < (int32_t)(uVar15 - 3));
    }
    uVar14 = (uint32_t)uVar19;
    while ((int32_t)uVar14 < (int32_t)uVar15) {
        uVar14 = (int32_t)uVar19 + 1;
        uVar23 = uVar28;
        if (uVar14 != uVar22) {
            uVar23 = uVar14;
        }
        iVar17 = (int64_t)(int32_t)uVar19;
        fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar23 * 8) - *(float *)(arg2 + iVar17 * 8);
        fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar23 * 8) - *(float *)(arg2 + 4 + iVar17 * 8);
        fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
        if (0.0 < fVar29) {
            auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
            fVar32 = auVar30._0_4_ * fVar32;
            fVar31 = auVar30._0_4_ * fVar31;
        }
        pfVar6[iVar17 * 2] = fVar32;
        pfVar6[iVar17 * 2 + 1] = (float)((uint32_t)fVar31 ^ 0x80000000);
        uVar19 = (uint64_t)uVar14;
    }
    if ((arg_28h & 1U) == 0) {
        *(undefined8 *)(pfVar6 + iVar20 * 2 + -2) = *(undefined8 *)(pfVar6 + iVar20 * 2 + -4);
    }
    if (uVar9 == 0) {
        if (fVar34 < (float)arg_30h) {
            fVar35 = (fVar35 - fVar34) * 0.5;
            if ((arg_28h & 1U) == 0) {
                fVar32 = fVar35 + fVar34;
                iVar17 = (int64_t)(int32_t)(uVar22 * 4 + -4);
                fVar31 = pfVar6[1];
                fVar29 = *(float *)(arg2 + 4);
                *pfVar1 = fVar32 * *pfVar6 + *(float *)arg2;
                pfVar1[1] = fVar32 * fVar31 + fVar29;
                fVar31 = pfVar6[1];
                fVar29 = *(float *)(arg2 + 4);
                pfVar1[2] = fVar35 * *pfVar6 + *(float *)arg2;
                pfVar1[3] = fVar35 * fVar31 + fVar29;
                fVar31 = *pfVar6;
                fVar29 = *(float *)arg2;
                pfVar1[5] = *(float *)(arg2 + 4) - fVar35 * pfVar6[1];
                pfVar1[4] = fVar29 - fVar35 * fVar31;
                fVar31 = *(float *)arg2;
                fVar29 = *pfVar6;
                pfVar1[7] = *(float *)(arg2 + 4) - fVar32 * pfVar6[1];
                pfVar1[6] = fVar31 - fVar32 * fVar29;
                fVar31 = pfVar6[iVar20 * 2 + -1];
                fVar29 = *(float *)(arg2 + -4 + iVar20 * 8);
                pfVar1[iVar17 * 2] = fVar32 * pfVar6[iVar20 * 2 + -2] + *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 1] = fVar32 * fVar31 + fVar29;
                fVar31 = pfVar6[iVar20 * 2 + -1];
                fVar29 = *(float *)(arg2 + -4 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 2] = fVar35 * pfVar6[iVar20 * 2 + -2] + *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 3] = fVar35 * fVar31 + fVar29;
                fVar31 = pfVar6[iVar20 * 2 + -2];
                fVar29 = *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 5] = *(float *)(arg2 + -4 + iVar20 * 8) - fVar35 * pfVar6[iVar20 * 2 + -1];
                pfVar1[iVar17 * 2 + 4] = fVar29 - fVar35 * fVar31;
                fVar31 = pfVar6[iVar20 * 2 + -2];
                fVar29 = *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 7] = *(float *)(arg2 + -4 + iVar20 * 8) - fVar32 * pfVar6[iVar20 * 2 + -1];
                pfVar1[iVar17 * 2 + 6] = fVar29 - fVar32 * fVar31;
            }
            var_18h._0_4_ = 0;
            uVar19 = uVar18;
            if (0 < (int32_t)uVar15) {
                uVar27 = 1;
                uVar10 = uVar18;
                iVar12 = *(int32_t *)(arg1 + 0x34);
                do {
                    if (uVar27 == uVar22) {
                        iVar13 = *(int32_t *)(arg1 + 0x34);
                        uVar14 = uVar28;
                    } else {
                        iVar13 = iVar12 + 4;
                        uVar14 = uVar27;
                    }
                    iVar20 = (int64_t)(int32_t)uVar14;
                    fVar29 = (pfVar6[iVar20 * 2] + pfVar6[uVar10 * 2]) * 0.5;
                    fVar32 = (pfVar6[iVar20 * 2 + 1] + pfVar6[uVar10 * 2 + 1]) * 0.5;
                    fVar31 = fVar32 * fVar32 + fVar29 * fVar29;
                    if (1e-06 < fVar31) {
                        fVar31 = 1.0 / fVar31;
                        fVar33 = 100.0;
                        if (fVar31 <= 100.0) {
                            fVar33 = fVar31;
                        }
                        fVar29 = fVar29 * fVar33;
                        fVar32 = fVar32 * fVar33;
                    }
                    iVar17 = (int64_t)(int32_t)(uVar14 * 4);
                    iVar7 = (int16_t)iVar13;
                    iVar24 = iVar7 + 1;
                    fVar31 = (fVar34 + fVar35) * fVar29;
                    iVar21 = iVar7 + 2;
                    uVar27 = uVar27 + 1;
                    fVar33 = (fVar34 + fVar35) * fVar32;
                    pfVar1[iVar17 * 2] = fVar31 + *(float *)(arg2 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 1] = fVar33 + *(float *)(arg2 + 4 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 2] = fVar29 * fVar35 + *(float *)(arg2 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 3] = fVar32 * fVar35 + *(float *)(arg2 + 4 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 4] = *(float *)(arg2 + iVar20 * 8) - fVar29 * fVar35;
                    pfVar1[iVar17 * 2 + 5] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar32 * fVar35;
                    pfVar1[iVar17 * 2 + 6] = *(float *)(arg2 + iVar20 * 8) - fVar31;
                    iVar8 = (int16_t)iVar12;
                    iVar11 = iVar8 + 2;
                    pfVar1[iVar17 * 2 + 7] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar33;
                    **(int16_t **)(arg1 + 0x48) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar8 + 1;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar11;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar21;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xc) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xe) = iVar8 + 1;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x10) = iVar8;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x12) = iVar8;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x14) = iVar7;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x16) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x18) = iVar21;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x1a) = iVar11;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x1c) = iVar8 + 3;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x1e) = iVar8 + 3;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x20) = iVar7 + 3;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x22) = iVar21;
                    *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0x24;
                    var_18h._0_4_ = (uint32_t)var_18h + 1;
                    uVar10 = (uint64_t)(uint32_t)var_18h;
                    iVar12 = iVar13;
                } while ((int32_t)(uint32_t)var_18h < (int32_t)uVar15);
            }
            do {
                uVar15 = (int32_t)uVar18 + 1;
                uVar18 = (uint64_t)uVar15;
                iVar17 = (int64_t)(int32_t)uVar19;
                **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(pfVar1 + iVar17 * 2);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 8) = uVar2;
                *(undefined4 *)(iVar20 + 0xc) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar26;
                *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x14) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 2);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 0x1c) = uVar2;
                *(undefined4 *)(iVar20 + 0x20) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar25;
                *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x28) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 4);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 0x30) = uVar2;
                *(undefined4 *)(iVar20 + 0x34) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x38) = uVar25;
                *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x3c) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 6);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 0x44) = uVar2;
                *(undefined4 *)(iVar20 + 0x48) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x4c) = uVar26;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x50;
                uVar19 = (uint64_t)((int32_t)uVar19 + 4);
            } while ((int32_t)uVar15 < (int32_t)uVar22);
            goto code_r0x00018012554d;
        }
    } else {
        fVar34 = fVar35 * 0.5 + 1.0;
    }
    if ((arg_28h & 1U) == 0) {
        iVar20 = iVar20 + -1;
        iVar17 = (int64_t)(int32_t)(uVar22 * 2);
        fVar35 = pfVar6[1];
        fVar31 = *(float *)(arg2 + 4);
        *pfVar1 = fVar34 * *pfVar6 + *(float *)arg2;
        pfVar1[1] = fVar34 * fVar35 + fVar31;
        fVar35 = *pfVar6;
        fVar31 = *(float *)arg2;
        pfVar1[3] = *(float *)(arg2 + 4) - fVar34 * pfVar6[1];
        pfVar1[2] = fVar31 - fVar34 * fVar35;
        fVar35 = pfVar6[iVar20 * 2 + 1];
        fVar31 = *(float *)(arg2 + 4 + iVar20 * 8);
        pfVar1[iVar17 * 2 + -4] = fVar34 * pfVar6[iVar20 * 2] + *(float *)(arg2 + iVar20 * 8);
        pfVar1[iVar17 * 2 + -3] = fVar34 * fVar35 + fVar31;
        fVar35 = pfVar6[iVar20 * 2];
        fVar31 = *(float *)(arg2 + iVar20 * 8);
        pfVar1[iVar17 * 2 + -1] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar34 * pfVar6[iVar20 * 2 + 1];
        pfVar1[iVar17 * 2 + -2] = fVar31 - fVar34 * fVar35;
    }
    if (0 < (int32_t)uVar15) {
        uVar28 = 1;
        uVar19 = uVar18;
        iVar13 = *(int32_t *)(arg1 + 0x34);
        do {
            if (uVar28 == uVar22) {
                iVar16 = *(int32_t *)(arg1 + 0x34);
                uVar14 = uVar27;
            } else {
                iVar16 = (uVar9 ^ 1) + 2 + iVar13;
                uVar14 = uVar28;
            }
            iVar20 = (int64_t)(int32_t)uVar14;
            fVar31 = (pfVar6[iVar20 * 2] + pfVar6[uVar19 * 2]) * 0.5;
            fVar29 = (pfVar6[iVar20 * 2 + 1] + pfVar6[uVar19 * 2 + 1]) * 0.5;
            fVar35 = fVar29 * fVar29 + fVar31 * fVar31;
            if (1e-06 < fVar35) {
                fVar35 = 1.0 / fVar35;
                fVar32 = 100.0;
                if (fVar35 <= 100.0) {
                    fVar32 = fVar35;
                }
                fVar31 = fVar31 * fVar32;
                fVar29 = fVar29 * fVar32;
            }
            iVar8 = (int16_t)iVar16;
            iVar21 = iVar8 + 1;
            iVar17 = (int64_t)(int32_t)(uVar14 * 2);
            pfVar1[iVar17 * 2] = fVar31 * fVar34 + *(float *)(arg2 + iVar20 * 8);
            pfVar1[iVar17 * 2 + 1] = fVar29 * fVar34 + *(float *)(arg2 + 4 + iVar20 * 8);
            pfVar1[iVar17 * 2 + 2] = *(float *)(arg2 + iVar20 * 8) - fVar31 * fVar34;
            iVar7 = (int16_t)iVar13;
            iVar11 = iVar7 + 1;
            pfVar1[iVar17 * 2 + 3] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar29 * fVar34;
            **(int16_t **)(arg1 + 0x48) = iVar8;
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar7;
            if (uVar9 == 0) {
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar7 + 2;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar7 + 2;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar8 + 2;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar8;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xc) = iVar21;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xe) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x10) = iVar7;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x12) = iVar7;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x14) = iVar8;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x16) = iVar21;
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0x18;
            } else {
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar21;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar8;
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0xc;
            }
            uVar14 = (int32_t)uVar19 + 1;
            uVar19 = (uint64_t)uVar14;
            uVar28 = uVar28 + 1;
            iVar13 = iVar16;
        } while ((int32_t)uVar14 < (int32_t)uVar15);
    }
    if (uVar9 == 0) {
        do {
            **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(arg2 + uVar18 * 8);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 8) = uVar2;
            *(undefined4 *)(iVar20 + 0xc) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar25;
            iVar17 = (int64_t)((int32_t)uVar18 * 2);
            uVar15 = (int32_t)uVar18 + 1;
            uVar18 = (uint64_t)uVar15;
            *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x14) = *(undefined8 *)(pfVar1 + iVar17 * 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x1c) = uVar2;
            *(undefined4 *)(iVar20 + 0x20) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar26;
            *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x28) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x30) = uVar2;
            *(undefined4 *)(iVar20 + 0x34) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x38) = uVar26;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x3c;
        } while ((int32_t)uVar15 < (int32_t)uVar22);
    } else {
        iVar17 = (int64_t)iVar12;
        iVar20 = *(int64_t *)(*(int64_t *)(arg1 + 0x38) + 8);
        uVar2 = *(undefined4 *)(iVar20 + iVar17 * 0x10);
        uVar3 = *(undefined4 *)(iVar20 + 4 + iVar17 * 0x10);
        uVar4 = *(undefined4 *)(iVar20 + 8 + iVar17 * 0x10);
        uVar5 = *(undefined4 *)(iVar20 + 0xc + iVar17 * 0x10);
        do {
            iVar12 = (int32_t)uVar18;
            uVar15 = iVar12 + 1;
            uVar18 = (uint64_t)uVar15;
            iVar17 = (int64_t)(iVar12 * 2);
            **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(pfVar1 + iVar17 * 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 8) = uVar2;
            *(undefined4 *)(iVar20 + 0xc) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar25;
            *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x14) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x1c) = uVar4;
            *(undefined4 *)(iVar20 + 0x20) = uVar5;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar25;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x28;
        } while ((int32_t)uVar15 < (int32_t)uVar22);
    }
code_r0x00018012554d:
    var_c8h = (int32_t *)(arg1 + 0x34);
    *var_c8h = *var_c8h + (var_d8h._4_4_ & 0xffff);
    return;
}

// ============================================================
// Function: FUN_180124e9f
// Address: 0x180124e9f
// Size: 558 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch

void fcn.1801248e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    float *pfVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    float *pfVar6;
    int16_t iVar7;
    int16_t iVar8;
    uint8_t uVar9;
    uint64_t uVar10;
    int16_t iVar11;
    int32_t iVar12;
    int32_t iVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    int32_t iVar16;
    int64_t iVar17;
    uint64_t uVar19;
    int64_t iVar20;
    int16_t iVar21;
    uint32_t uVar22;
    uint32_t uVar23;
    int16_t iVar24;
    uint32_t uVar25;
    uint32_t uVar26;
    uint32_t uVar27;
    uint32_t uVar28;
    float fVar29;
    undefined auVar30 [16];
    float fVar31;
    float fVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int32_t *var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uVar18;
    
    uVar25 = (uint32_t)arg4;
    uVar22 = (uint32_t)arg3;
    iVar20 = (int64_t)(int32_t)uVar22;
    if ((int32_t)uVar22 < 2) {
        return;
    }
    if ((arg4 & 0xff000000U) == 0) {
        return;
    }
    uVar2 = **(undefined4 **)(arg1 + 0x38);
    uVar3 = (*(undefined4 **)(arg1 + 0x38))[1];
    uVar15 = uVar22;
    if ((arg_28h & 1U) == 0) {
        uVar15 = uVar22 - 1;
    }
    fVar34 = *(float *)(arg1 + 0xd0);
    if ((*(uint32_t *)(arg1 + 0x30) & 1) == 0) {
        fcn.180124680(arg1, (uint64_t)(uVar15 * 6), (uint64_t)(uVar15 * 4));
        uVar19 = 0;
        if ((int32_t)uVar15 < 1) {
            return;
        }
        do {
            fVar34 = *(float *)(arg2 + uVar19 * 8);
            uVar28 = (int32_t)uVar19 + 1;
            uVar26 = 0;
            if (uVar28 != uVar22) {
                uVar26 = uVar28;
            }
            iVar20 = (int64_t)(int32_t)uVar26;
            fVar31 = *(float *)(arg2 + iVar20 * 8) - fVar34;
            fVar29 = *(float *)(arg2 + 4 + iVar20 * 8) - *(float *)(arg2 + 4 + uVar19 * 8);
            fVar35 = fVar29 * fVar29 + fVar31 * fVar31;
            if (0.0 < fVar35) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar35), ZEXT416((uint32_t)fVar35));
                fVar31 = fVar31 * auVar30._0_4_;
                fVar29 = fVar29 * auVar30._0_4_;
            }
            fVar29 = fVar29 * (float)arg_30h * 0.5;
            fVar31 = fVar31 * (float)arg_30h * 0.5;
            **(float **)(arg1 + 0x40) = fVar29 + fVar34;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 4) = *(float *)(arg2 + 4 + uVar19 * 8) - fVar31;
            iVar17 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar17 + 8) = uVar2;
            *(undefined4 *)(iVar17 + 0xc) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar25;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x14) = fVar29 + *(float *)(arg2 + iVar20 * 8);
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x18) = *(float *)(arg2 + 4 + iVar20 * 8) - fVar31;
            iVar17 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar17 + 0x1c) = uVar2;
            *(undefined4 *)(iVar17 + 0x20) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar25;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x28) = *(float *)(arg2 + iVar20 * 8) - fVar29;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x2c) = fVar31 + *(float *)(arg2 + 4 + iVar20 * 8);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x30) = uVar2;
            *(undefined4 *)(iVar20 + 0x34) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x38) = uVar25;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x3c) = *(float *)(arg2 + uVar19 * 8) - fVar29;
            iVar20 = uVar19 * 8;
            uVar19 = (uint64_t)uVar28;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x40) = fVar31 + *(float *)(arg2 + 4 + iVar20);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x44) = uVar2;
            *(undefined4 *)(iVar20 + 0x48) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x4c) = uVar25;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x50;
            **(undefined2 **)(arg1 + 0x48) = *(undefined2 *)(arg1 + 0x34);
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = *(int16_t *)(arg1 + 0x34) + 1;
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = *(int16_t *)(arg1 + 0x34) + 2;
            *(undefined2 *)(*(int64_t *)(arg1 + 0x48) + 6) = *(undefined2 *)(arg1 + 0x34);
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = *(int16_t *)(arg1 + 0x34) + 2;
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = *(int16_t *)(arg1 + 0x34) + 3;
            *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0xc;
            *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + 4;
        } while ((int32_t)uVar28 < (int32_t)uVar15);
        return;
    }
    uVar26 = uVar25 & 0xffffff;
    fVar35 = (float)arg_30h;
    if ((float)arg_30h <= 1.0) {
        fVar35 = 1.0;
    }
    iVar12 = (int32_t)fVar35;
    if (((((*(uint32_t *)(arg1 + 0x30) & 2) == 0) || (0x1f < iVar12)) || (1e-05 < fVar35 - (float)iVar12)) ||
       (fVar34 != 1.0)) {
        if ((float)arg_30h <= fVar34) {
            var_d8h._4_4_ = uVar22 * 3;
            uVar9 = 0;
            uVar28 = uVar15 * 0xc;
            goto code_r0x000180124a47;
        }
        var_d8h._4_4_ = uVar22 * 4;
        fcn.180124680(arg1, (uint64_t)(uVar15 * 0x12), (uint64_t)var_d8h._4_4_);
        iVar13 = 5;
        uVar9 = 0;
    } else {
        var_d8h._4_4_ = uVar22 * 2;
        uVar9 = 1;
        uVar28 = uVar15 * 6;
code_r0x000180124a47:
        fcn.180124680(arg1, (uint64_t)uVar28, (uint64_t)var_d8h._4_4_);
        iVar13 = 3;
    }
    func_0x0001801312e0(*(int64_t *)(arg1 + 0x38) + 0x48, iVar13 * uVar22);
    uVar18 = 0;
    uVar27 = 0;
    pfVar6 = *(float **)(*(int64_t *)(arg1 + 0x38) + 0x50);
    pfVar1 = pfVar6 + iVar20 * 2;
    uVar28 = 0;
    uVar19 = uVar18;
    if (3 < (int32_t)uVar15) {
        do {
            iVar13 = (int32_t)uVar19;
            iVar17 = (int64_t)iVar13;
            uVar14 = uVar27;
            if (iVar13 + 1U != uVar22) {
                uVar14 = iVar13 + 1U;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 4 + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2] = fVar32;
            pfVar6[iVar17 * 2 + 1] = (float)((uint32_t)fVar31 ^ 0x80000000);
            uVar14 = uVar27;
            if (iVar13 + 2U != uVar22) {
                uVar14 = iVar13 + 2U;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 8 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0xc + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2 + 2] = fVar32;
            pfVar6[iVar17 * 2 + 3] = (float)((uint32_t)fVar31 ^ 0x80000000);
            uVar14 = uVar27;
            if (iVar13 + 3U != uVar22) {
                uVar14 = iVar13 + 3U;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x10 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x14 + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2 + 4] = fVar32;
            uVar23 = iVar13 + 4;
            uVar19 = (uint64_t)uVar23;
            pfVar6[iVar17 * 2 + 5] = (float)((uint32_t)fVar31 ^ 0x80000000);
            uVar14 = uVar28;
            if (uVar23 != uVar22) {
                uVar14 = uVar23;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x18 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x1c + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2 + 6] = fVar32;
            pfVar6[iVar17 * 2 + 7] = (float)((uint32_t)fVar31 ^ 0x80000000);
        } while ((int32_t)uVar23 < (int32_t)(uVar15 - 3));
    }
    uVar14 = (uint32_t)uVar19;
    while ((int32_t)uVar14 < (int32_t)uVar15) {
        uVar14 = (int32_t)uVar19 + 1;
        uVar23 = uVar28;
        if (uVar14 != uVar22) {
            uVar23 = uVar14;
        }
        iVar17 = (int64_t)(int32_t)uVar19;
        fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar23 * 8) - *(float *)(arg2 + iVar17 * 8);
        fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar23 * 8) - *(float *)(arg2 + 4 + iVar17 * 8);
        fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
        if (0.0 < fVar29) {
            auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
            fVar32 = auVar30._0_4_ * fVar32;
            fVar31 = auVar30._0_4_ * fVar31;
        }
        pfVar6[iVar17 * 2] = fVar32;
        pfVar6[iVar17 * 2 + 1] = (float)((uint32_t)fVar31 ^ 0x80000000);
        uVar19 = (uint64_t)uVar14;
    }
    if ((arg_28h & 1U) == 0) {
        *(undefined8 *)(pfVar6 + iVar20 * 2 + -2) = *(undefined8 *)(pfVar6 + iVar20 * 2 + -4);
    }
    if (uVar9 == 0) {
        if (fVar34 < (float)arg_30h) {
            fVar35 = (fVar35 - fVar34) * 0.5;
            if ((arg_28h & 1U) == 0) {
                fVar32 = fVar35 + fVar34;
                iVar17 = (int64_t)(int32_t)(uVar22 * 4 + -4);
                fVar31 = pfVar6[1];
                fVar29 = *(float *)(arg2 + 4);
                *pfVar1 = fVar32 * *pfVar6 + *(float *)arg2;
                pfVar1[1] = fVar32 * fVar31 + fVar29;
                fVar31 = pfVar6[1];
                fVar29 = *(float *)(arg2 + 4);
                pfVar1[2] = fVar35 * *pfVar6 + *(float *)arg2;
                pfVar1[3] = fVar35 * fVar31 + fVar29;
                fVar31 = *pfVar6;
                fVar29 = *(float *)arg2;
                pfVar1[5] = *(float *)(arg2 + 4) - fVar35 * pfVar6[1];
                pfVar1[4] = fVar29 - fVar35 * fVar31;
                fVar31 = *(float *)arg2;
                fVar29 = *pfVar6;
                pfVar1[7] = *(float *)(arg2 + 4) - fVar32 * pfVar6[1];
                pfVar1[6] = fVar31 - fVar32 * fVar29;
                fVar31 = pfVar6[iVar20 * 2 + -1];
                fVar29 = *(float *)(arg2 + -4 + iVar20 * 8);
                pfVar1[iVar17 * 2] = fVar32 * pfVar6[iVar20 * 2 + -2] + *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 1] = fVar32 * fVar31 + fVar29;
                fVar31 = pfVar6[iVar20 * 2 + -1];
                fVar29 = *(float *)(arg2 + -4 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 2] = fVar35 * pfVar6[iVar20 * 2 + -2] + *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 3] = fVar35 * fVar31 + fVar29;
                fVar31 = pfVar6[iVar20 * 2 + -2];
                fVar29 = *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 5] = *(float *)(arg2 + -4 + iVar20 * 8) - fVar35 * pfVar6[iVar20 * 2 + -1];
                pfVar1[iVar17 * 2 + 4] = fVar29 - fVar35 * fVar31;
                fVar31 = pfVar6[iVar20 * 2 + -2];
                fVar29 = *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 7] = *(float *)(arg2 + -4 + iVar20 * 8) - fVar32 * pfVar6[iVar20 * 2 + -1];
                pfVar1[iVar17 * 2 + 6] = fVar29 - fVar32 * fVar31;
            }
            var_18h._0_4_ = 0;
            uVar19 = uVar18;
            if (0 < (int32_t)uVar15) {
                uVar27 = 1;
                uVar10 = uVar18;
                iVar12 = *(int32_t *)(arg1 + 0x34);
                do {
                    if (uVar27 == uVar22) {
                        iVar13 = *(int32_t *)(arg1 + 0x34);
                        uVar14 = uVar28;
                    } else {
                        iVar13 = iVar12 + 4;
                        uVar14 = uVar27;
                    }
                    iVar20 = (int64_t)(int32_t)uVar14;
                    fVar29 = (pfVar6[iVar20 * 2] + pfVar6[uVar10 * 2]) * 0.5;
                    fVar32 = (pfVar6[iVar20 * 2 + 1] + pfVar6[uVar10 * 2 + 1]) * 0.5;
                    fVar31 = fVar32 * fVar32 + fVar29 * fVar29;
                    if (1e-06 < fVar31) {
                        fVar31 = 1.0 / fVar31;
                        fVar33 = 100.0;
                        if (fVar31 <= 100.0) {
                            fVar33 = fVar31;
                        }
                        fVar29 = fVar29 * fVar33;
                        fVar32 = fVar32 * fVar33;
                    }
                    iVar17 = (int64_t)(int32_t)(uVar14 * 4);
                    iVar7 = (int16_t)iVar13;
                    iVar24 = iVar7 + 1;
                    fVar31 = (fVar34 + fVar35) * fVar29;
                    iVar21 = iVar7 + 2;
                    uVar27 = uVar27 + 1;
                    fVar33 = (fVar34 + fVar35) * fVar32;
                    pfVar1[iVar17 * 2] = fVar31 + *(float *)(arg2 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 1] = fVar33 + *(float *)(arg2 + 4 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 2] = fVar29 * fVar35 + *(float *)(arg2 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 3] = fVar32 * fVar35 + *(float *)(arg2 + 4 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 4] = *(float *)(arg2 + iVar20 * 8) - fVar29 * fVar35;
                    pfVar1[iVar17 * 2 + 5] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar32 * fVar35;
                    pfVar1[iVar17 * 2 + 6] = *(float *)(arg2 + iVar20 * 8) - fVar31;
                    iVar8 = (int16_t)iVar12;
                    iVar11 = iVar8 + 2;
                    pfVar1[iVar17 * 2 + 7] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar33;
                    **(int16_t **)(arg1 + 0x48) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar8 + 1;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar11;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar21;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xc) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xe) = iVar8 + 1;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x10) = iVar8;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x12) = iVar8;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x14) = iVar7;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x16) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x18) = iVar21;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x1a) = iVar11;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x1c) = iVar8 + 3;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x1e) = iVar8 + 3;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x20) = iVar7 + 3;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x22) = iVar21;
                    *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0x24;
                    var_18h._0_4_ = (uint32_t)var_18h + 1;
                    uVar10 = (uint64_t)(uint32_t)var_18h;
                    iVar12 = iVar13;
                } while ((int32_t)(uint32_t)var_18h < (int32_t)uVar15);
            }
            do {
                uVar15 = (int32_t)uVar18 + 1;
                uVar18 = (uint64_t)uVar15;
                iVar17 = (int64_t)(int32_t)uVar19;
                **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(pfVar1 + iVar17 * 2);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 8) = uVar2;
                *(undefined4 *)(iVar20 + 0xc) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar26;
                *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x14) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 2);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 0x1c) = uVar2;
                *(undefined4 *)(iVar20 + 0x20) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar25;
                *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x28) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 4);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 0x30) = uVar2;
                *(undefined4 *)(iVar20 + 0x34) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x38) = uVar25;
                *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x3c) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 6);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 0x44) = uVar2;
                *(undefined4 *)(iVar20 + 0x48) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x4c) = uVar26;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x50;
                uVar19 = (uint64_t)((int32_t)uVar19 + 4);
            } while ((int32_t)uVar15 < (int32_t)uVar22);
            goto code_r0x00018012554d;
        }
    } else {
        fVar34 = fVar35 * 0.5 + 1.0;
    }
    if ((arg_28h & 1U) == 0) {
        iVar20 = iVar20 + -1;
        iVar17 = (int64_t)(int32_t)(uVar22 * 2);
        fVar35 = pfVar6[1];
        fVar31 = *(float *)(arg2 + 4);
        *pfVar1 = fVar34 * *pfVar6 + *(float *)arg2;
        pfVar1[1] = fVar34 * fVar35 + fVar31;
        fVar35 = *pfVar6;
        fVar31 = *(float *)arg2;
        pfVar1[3] = *(float *)(arg2 + 4) - fVar34 * pfVar6[1];
        pfVar1[2] = fVar31 - fVar34 * fVar35;
        fVar35 = pfVar6[iVar20 * 2 + 1];
        fVar31 = *(float *)(arg2 + 4 + iVar20 * 8);
        pfVar1[iVar17 * 2 + -4] = fVar34 * pfVar6[iVar20 * 2] + *(float *)(arg2 + iVar20 * 8);
        pfVar1[iVar17 * 2 + -3] = fVar34 * fVar35 + fVar31;
        fVar35 = pfVar6[iVar20 * 2];
        fVar31 = *(float *)(arg2 + iVar20 * 8);
        pfVar1[iVar17 * 2 + -1] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar34 * pfVar6[iVar20 * 2 + 1];
        pfVar1[iVar17 * 2 + -2] = fVar31 - fVar34 * fVar35;
    }
    if (0 < (int32_t)uVar15) {
        uVar28 = 1;
        uVar19 = uVar18;
        iVar13 = *(int32_t *)(arg1 + 0x34);
        do {
            if (uVar28 == uVar22) {
                iVar16 = *(int32_t *)(arg1 + 0x34);
                uVar14 = uVar27;
            } else {
                iVar16 = (uVar9 ^ 1) + 2 + iVar13;
                uVar14 = uVar28;
            }
            iVar20 = (int64_t)(int32_t)uVar14;
            fVar31 = (pfVar6[iVar20 * 2] + pfVar6[uVar19 * 2]) * 0.5;
            fVar29 = (pfVar6[iVar20 * 2 + 1] + pfVar6[uVar19 * 2 + 1]) * 0.5;
            fVar35 = fVar29 * fVar29 + fVar31 * fVar31;
            if (1e-06 < fVar35) {
                fVar35 = 1.0 / fVar35;
                fVar32 = 100.0;
                if (fVar35 <= 100.0) {
                    fVar32 = fVar35;
                }
                fVar31 = fVar31 * fVar32;
                fVar29 = fVar29 * fVar32;
            }
            iVar8 = (int16_t)iVar16;
            iVar21 = iVar8 + 1;
            iVar17 = (int64_t)(int32_t)(uVar14 * 2);
            pfVar1[iVar17 * 2] = fVar31 * fVar34 + *(float *)(arg2 + iVar20 * 8);
            pfVar1[iVar17 * 2 + 1] = fVar29 * fVar34 + *(float *)(arg2 + 4 + iVar20 * 8);
            pfVar1[iVar17 * 2 + 2] = *(float *)(arg2 + iVar20 * 8) - fVar31 * fVar34;
            iVar7 = (int16_t)iVar13;
            iVar11 = iVar7 + 1;
            pfVar1[iVar17 * 2 + 3] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar29 * fVar34;
            **(int16_t **)(arg1 + 0x48) = iVar8;
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar7;
            if (uVar9 == 0) {
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar7 + 2;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar7 + 2;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar8 + 2;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar8;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xc) = iVar21;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xe) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x10) = iVar7;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x12) = iVar7;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x14) = iVar8;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x16) = iVar21;
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0x18;
            } else {
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar21;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar8;
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0xc;
            }
            uVar14 = (int32_t)uVar19 + 1;
            uVar19 = (uint64_t)uVar14;
            uVar28 = uVar28 + 1;
            iVar13 = iVar16;
        } while ((int32_t)uVar14 < (int32_t)uVar15);
    }
    if (uVar9 == 0) {
        do {
            **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(arg2 + uVar18 * 8);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 8) = uVar2;
            *(undefined4 *)(iVar20 + 0xc) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar25;
            iVar17 = (int64_t)((int32_t)uVar18 * 2);
            uVar15 = (int32_t)uVar18 + 1;
            uVar18 = (uint64_t)uVar15;
            *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x14) = *(undefined8 *)(pfVar1 + iVar17 * 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x1c) = uVar2;
            *(undefined4 *)(iVar20 + 0x20) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar26;
            *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x28) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x30) = uVar2;
            *(undefined4 *)(iVar20 + 0x34) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x38) = uVar26;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x3c;
        } while ((int32_t)uVar15 < (int32_t)uVar22);
    } else {
        iVar17 = (int64_t)iVar12;
        iVar20 = *(int64_t *)(*(int64_t *)(arg1 + 0x38) + 8);
        uVar2 = *(undefined4 *)(iVar20 + iVar17 * 0x10);
        uVar3 = *(undefined4 *)(iVar20 + 4 + iVar17 * 0x10);
        uVar4 = *(undefined4 *)(iVar20 + 8 + iVar17 * 0x10);
        uVar5 = *(undefined4 *)(iVar20 + 0xc + iVar17 * 0x10);
        do {
            iVar12 = (int32_t)uVar18;
            uVar15 = iVar12 + 1;
            uVar18 = (uint64_t)uVar15;
            iVar17 = (int64_t)(iVar12 * 2);
            **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(pfVar1 + iVar17 * 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 8) = uVar2;
            *(undefined4 *)(iVar20 + 0xc) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar25;
            *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x14) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x1c) = uVar4;
            *(undefined4 *)(iVar20 + 0x20) = uVar5;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar25;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x28;
        } while ((int32_t)uVar15 < (int32_t)uVar22);
    }
code_r0x00018012554d:
    var_c8h = (int32_t *)(arg1 + 0x34);
    *var_c8h = *var_c8h + (var_d8h._4_4_ & 0xffff);
    return;
}

// ============================================================
// Function: FUN_1801250cd
// Address: 0x1801250cd
// Size: 1199 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch

void fcn.1801248e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    float *pfVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    float *pfVar6;
    int16_t iVar7;
    int16_t iVar8;
    uint8_t uVar9;
    uint64_t uVar10;
    int16_t iVar11;
    int32_t iVar12;
    int32_t iVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    int32_t iVar16;
    int64_t iVar17;
    uint64_t uVar19;
    int64_t iVar20;
    int16_t iVar21;
    uint32_t uVar22;
    uint32_t uVar23;
    int16_t iVar24;
    uint32_t uVar25;
    uint32_t uVar26;
    uint32_t uVar27;
    uint32_t uVar28;
    float fVar29;
    undefined auVar30 [16];
    float fVar31;
    float fVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int32_t *var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uVar18;
    
    uVar25 = (uint32_t)arg4;
    uVar22 = (uint32_t)arg3;
    iVar20 = (int64_t)(int32_t)uVar22;
    if ((int32_t)uVar22 < 2) {
        return;
    }
    if ((arg4 & 0xff000000U) == 0) {
        return;
    }
    uVar2 = **(undefined4 **)(arg1 + 0x38);
    uVar3 = (*(undefined4 **)(arg1 + 0x38))[1];
    uVar15 = uVar22;
    if ((arg_28h & 1U) == 0) {
        uVar15 = uVar22 - 1;
    }
    fVar34 = *(float *)(arg1 + 0xd0);
    if ((*(uint32_t *)(arg1 + 0x30) & 1) == 0) {
        fcn.180124680(arg1, (uint64_t)(uVar15 * 6), (uint64_t)(uVar15 * 4));
        uVar19 = 0;
        if ((int32_t)uVar15 < 1) {
            return;
        }
        do {
            fVar34 = *(float *)(arg2 + uVar19 * 8);
            uVar28 = (int32_t)uVar19 + 1;
            uVar26 = 0;
            if (uVar28 != uVar22) {
                uVar26 = uVar28;
            }
            iVar20 = (int64_t)(int32_t)uVar26;
            fVar31 = *(float *)(arg2 + iVar20 * 8) - fVar34;
            fVar29 = *(float *)(arg2 + 4 + iVar20 * 8) - *(float *)(arg2 + 4 + uVar19 * 8);
            fVar35 = fVar29 * fVar29 + fVar31 * fVar31;
            if (0.0 < fVar35) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar35), ZEXT416((uint32_t)fVar35));
                fVar31 = fVar31 * auVar30._0_4_;
                fVar29 = fVar29 * auVar30._0_4_;
            }
            fVar29 = fVar29 * (float)arg_30h * 0.5;
            fVar31 = fVar31 * (float)arg_30h * 0.5;
            **(float **)(arg1 + 0x40) = fVar29 + fVar34;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 4) = *(float *)(arg2 + 4 + uVar19 * 8) - fVar31;
            iVar17 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar17 + 8) = uVar2;
            *(undefined4 *)(iVar17 + 0xc) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar25;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x14) = fVar29 + *(float *)(arg2 + iVar20 * 8);
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x18) = *(float *)(arg2 + 4 + iVar20 * 8) - fVar31;
            iVar17 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar17 + 0x1c) = uVar2;
            *(undefined4 *)(iVar17 + 0x20) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar25;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x28) = *(float *)(arg2 + iVar20 * 8) - fVar29;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x2c) = fVar31 + *(float *)(arg2 + 4 + iVar20 * 8);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x30) = uVar2;
            *(undefined4 *)(iVar20 + 0x34) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x38) = uVar25;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x3c) = *(float *)(arg2 + uVar19 * 8) - fVar29;
            iVar20 = uVar19 * 8;
            uVar19 = (uint64_t)uVar28;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x40) = fVar31 + *(float *)(arg2 + 4 + iVar20);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x44) = uVar2;
            *(undefined4 *)(iVar20 + 0x48) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x4c) = uVar25;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x50;
            **(undefined2 **)(arg1 + 0x48) = *(undefined2 *)(arg1 + 0x34);
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = *(int16_t *)(arg1 + 0x34) + 1;
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = *(int16_t *)(arg1 + 0x34) + 2;
            *(undefined2 *)(*(int64_t *)(arg1 + 0x48) + 6) = *(undefined2 *)(arg1 + 0x34);
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = *(int16_t *)(arg1 + 0x34) + 2;
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = *(int16_t *)(arg1 + 0x34) + 3;
            *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0xc;
            *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + 4;
        } while ((int32_t)uVar28 < (int32_t)uVar15);
        return;
    }
    uVar26 = uVar25 & 0xffffff;
    fVar35 = (float)arg_30h;
    if ((float)arg_30h <= 1.0) {
        fVar35 = 1.0;
    }
    iVar12 = (int32_t)fVar35;
    if (((((*(uint32_t *)(arg1 + 0x30) & 2) == 0) || (0x1f < iVar12)) || (1e-05 < fVar35 - (float)iVar12)) ||
       (fVar34 != 1.0)) {
        if ((float)arg_30h <= fVar34) {
            var_d8h._4_4_ = uVar22 * 3;
            uVar9 = 0;
            uVar28 = uVar15 * 0xc;
            goto code_r0x000180124a47;
        }
        var_d8h._4_4_ = uVar22 * 4;
        fcn.180124680(arg1, (uint64_t)(uVar15 * 0x12), (uint64_t)var_d8h._4_4_);
        iVar13 = 5;
        uVar9 = 0;
    } else {
        var_d8h._4_4_ = uVar22 * 2;
        uVar9 = 1;
        uVar28 = uVar15 * 6;
code_r0x000180124a47:
        fcn.180124680(arg1, (uint64_t)uVar28, (uint64_t)var_d8h._4_4_);
        iVar13 = 3;
    }
    func_0x0001801312e0(*(int64_t *)(arg1 + 0x38) + 0x48, iVar13 * uVar22);
    uVar18 = 0;
    uVar27 = 0;
    pfVar6 = *(float **)(*(int64_t *)(arg1 + 0x38) + 0x50);
    pfVar1 = pfVar6 + iVar20 * 2;
    uVar28 = 0;
    uVar19 = uVar18;
    if (3 < (int32_t)uVar15) {
        do {
            iVar13 = (int32_t)uVar19;
            iVar17 = (int64_t)iVar13;
            uVar14 = uVar27;
            if (iVar13 + 1U != uVar22) {
                uVar14 = iVar13 + 1U;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 4 + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2] = fVar32;
            pfVar6[iVar17 * 2 + 1] = (float)((uint32_t)fVar31 ^ 0x80000000);
            uVar14 = uVar27;
            if (iVar13 + 2U != uVar22) {
                uVar14 = iVar13 + 2U;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 8 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0xc + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2 + 2] = fVar32;
            pfVar6[iVar17 * 2 + 3] = (float)((uint32_t)fVar31 ^ 0x80000000);
            uVar14 = uVar27;
            if (iVar13 + 3U != uVar22) {
                uVar14 = iVar13 + 3U;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x10 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x14 + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2 + 4] = fVar32;
            uVar23 = iVar13 + 4;
            uVar19 = (uint64_t)uVar23;
            pfVar6[iVar17 * 2 + 5] = (float)((uint32_t)fVar31 ^ 0x80000000);
            uVar14 = uVar28;
            if (uVar23 != uVar22) {
                uVar14 = uVar23;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x18 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x1c + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2 + 6] = fVar32;
            pfVar6[iVar17 * 2 + 7] = (float)((uint32_t)fVar31 ^ 0x80000000);
        } while ((int32_t)uVar23 < (int32_t)(uVar15 - 3));
    }
    uVar14 = (uint32_t)uVar19;
    while ((int32_t)uVar14 < (int32_t)uVar15) {
        uVar14 = (int32_t)uVar19 + 1;
        uVar23 = uVar28;
        if (uVar14 != uVar22) {
            uVar23 = uVar14;
        }
        iVar17 = (int64_t)(int32_t)uVar19;
        fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar23 * 8) - *(float *)(arg2 + iVar17 * 8);
        fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar23 * 8) - *(float *)(arg2 + 4 + iVar17 * 8);
        fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
        if (0.0 < fVar29) {
            auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
            fVar32 = auVar30._0_4_ * fVar32;
            fVar31 = auVar30._0_4_ * fVar31;
        }
        pfVar6[iVar17 * 2] = fVar32;
        pfVar6[iVar17 * 2 + 1] = (float)((uint32_t)fVar31 ^ 0x80000000);
        uVar19 = (uint64_t)uVar14;
    }
    if ((arg_28h & 1U) == 0) {
        *(undefined8 *)(pfVar6 + iVar20 * 2 + -2) = *(undefined8 *)(pfVar6 + iVar20 * 2 + -4);
    }
    if (uVar9 == 0) {
        if (fVar34 < (float)arg_30h) {
            fVar35 = (fVar35 - fVar34) * 0.5;
            if ((arg_28h & 1U) == 0) {
                fVar32 = fVar35 + fVar34;
                iVar17 = (int64_t)(int32_t)(uVar22 * 4 + -4);
                fVar31 = pfVar6[1];
                fVar29 = *(float *)(arg2 + 4);
                *pfVar1 = fVar32 * *pfVar6 + *(float *)arg2;
                pfVar1[1] = fVar32 * fVar31 + fVar29;
                fVar31 = pfVar6[1];
                fVar29 = *(float *)(arg2 + 4);
                pfVar1[2] = fVar35 * *pfVar6 + *(float *)arg2;
                pfVar1[3] = fVar35 * fVar31 + fVar29;
                fVar31 = *pfVar6;
                fVar29 = *(float *)arg2;
                pfVar1[5] = *(float *)(arg2 + 4) - fVar35 * pfVar6[1];
                pfVar1[4] = fVar29 - fVar35 * fVar31;
                fVar31 = *(float *)arg2;
                fVar29 = *pfVar6;
                pfVar1[7] = *(float *)(arg2 + 4) - fVar32 * pfVar6[1];
                pfVar1[6] = fVar31 - fVar32 * fVar29;
                fVar31 = pfVar6[iVar20 * 2 + -1];
                fVar29 = *(float *)(arg2 + -4 + iVar20 * 8);
                pfVar1[iVar17 * 2] = fVar32 * pfVar6[iVar20 * 2 + -2] + *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 1] = fVar32 * fVar31 + fVar29;
                fVar31 = pfVar6[iVar20 * 2 + -1];
                fVar29 = *(float *)(arg2 + -4 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 2] = fVar35 * pfVar6[iVar20 * 2 + -2] + *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 3] = fVar35 * fVar31 + fVar29;
                fVar31 = pfVar6[iVar20 * 2 + -2];
                fVar29 = *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 5] = *(float *)(arg2 + -4 + iVar20 * 8) - fVar35 * pfVar6[iVar20 * 2 + -1];
                pfVar1[iVar17 * 2 + 4] = fVar29 - fVar35 * fVar31;
                fVar31 = pfVar6[iVar20 * 2 + -2];
                fVar29 = *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 7] = *(float *)(arg2 + -4 + iVar20 * 8) - fVar32 * pfVar6[iVar20 * 2 + -1];
                pfVar1[iVar17 * 2 + 6] = fVar29 - fVar32 * fVar31;
            }
            var_18h._0_4_ = 0;
            uVar19 = uVar18;
            if (0 < (int32_t)uVar15) {
                uVar27 = 1;
                uVar10 = uVar18;
                iVar12 = *(int32_t *)(arg1 + 0x34);
                do {
                    if (uVar27 == uVar22) {
                        iVar13 = *(int32_t *)(arg1 + 0x34);
                        uVar14 = uVar28;
                    } else {
                        iVar13 = iVar12 + 4;
                        uVar14 = uVar27;
                    }
                    iVar20 = (int64_t)(int32_t)uVar14;
                    fVar29 = (pfVar6[iVar20 * 2] + pfVar6[uVar10 * 2]) * 0.5;
                    fVar32 = (pfVar6[iVar20 * 2 + 1] + pfVar6[uVar10 * 2 + 1]) * 0.5;
                    fVar31 = fVar32 * fVar32 + fVar29 * fVar29;
                    if (1e-06 < fVar31) {
                        fVar31 = 1.0 / fVar31;
                        fVar33 = 100.0;
                        if (fVar31 <= 100.0) {
                            fVar33 = fVar31;
                        }
                        fVar29 = fVar29 * fVar33;
                        fVar32 = fVar32 * fVar33;
                    }
                    iVar17 = (int64_t)(int32_t)(uVar14 * 4);
                    iVar7 = (int16_t)iVar13;
                    iVar24 = iVar7 + 1;
                    fVar31 = (fVar34 + fVar35) * fVar29;
                    iVar21 = iVar7 + 2;
                    uVar27 = uVar27 + 1;
                    fVar33 = (fVar34 + fVar35) * fVar32;
                    pfVar1[iVar17 * 2] = fVar31 + *(float *)(arg2 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 1] = fVar33 + *(float *)(arg2 + 4 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 2] = fVar29 * fVar35 + *(float *)(arg2 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 3] = fVar32 * fVar35 + *(float *)(arg2 + 4 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 4] = *(float *)(arg2 + iVar20 * 8) - fVar29 * fVar35;
                    pfVar1[iVar17 * 2 + 5] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar32 * fVar35;
                    pfVar1[iVar17 * 2 + 6] = *(float *)(arg2 + iVar20 * 8) - fVar31;
                    iVar8 = (int16_t)iVar12;
                    iVar11 = iVar8 + 2;
                    pfVar1[iVar17 * 2 + 7] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar33;
                    **(int16_t **)(arg1 + 0x48) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar8 + 1;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar11;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar21;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xc) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xe) = iVar8 + 1;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x10) = iVar8;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x12) = iVar8;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x14) = iVar7;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x16) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x18) = iVar21;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x1a) = iVar11;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x1c) = iVar8 + 3;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x1e) = iVar8 + 3;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x20) = iVar7 + 3;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x22) = iVar21;
                    *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0x24;
                    var_18h._0_4_ = (uint32_t)var_18h + 1;
                    uVar10 = (uint64_t)(uint32_t)var_18h;
                    iVar12 = iVar13;
                } while ((int32_t)(uint32_t)var_18h < (int32_t)uVar15);
            }
            do {
                uVar15 = (int32_t)uVar18 + 1;
                uVar18 = (uint64_t)uVar15;
                iVar17 = (int64_t)(int32_t)uVar19;
                **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(pfVar1 + iVar17 * 2);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 8) = uVar2;
                *(undefined4 *)(iVar20 + 0xc) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar26;
                *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x14) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 2);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 0x1c) = uVar2;
                *(undefined4 *)(iVar20 + 0x20) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar25;
                *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x28) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 4);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 0x30) = uVar2;
                *(undefined4 *)(iVar20 + 0x34) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x38) = uVar25;
                *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x3c) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 6);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 0x44) = uVar2;
                *(undefined4 *)(iVar20 + 0x48) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x4c) = uVar26;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x50;
                uVar19 = (uint64_t)((int32_t)uVar19 + 4);
            } while ((int32_t)uVar15 < (int32_t)uVar22);
            goto code_r0x00018012554d;
        }
    } else {
        fVar34 = fVar35 * 0.5 + 1.0;
    }
    if ((arg_28h & 1U) == 0) {
        iVar20 = iVar20 + -1;
        iVar17 = (int64_t)(int32_t)(uVar22 * 2);
        fVar35 = pfVar6[1];
        fVar31 = *(float *)(arg2 + 4);
        *pfVar1 = fVar34 * *pfVar6 + *(float *)arg2;
        pfVar1[1] = fVar34 * fVar35 + fVar31;
        fVar35 = *pfVar6;
        fVar31 = *(float *)arg2;
        pfVar1[3] = *(float *)(arg2 + 4) - fVar34 * pfVar6[1];
        pfVar1[2] = fVar31 - fVar34 * fVar35;
        fVar35 = pfVar6[iVar20 * 2 + 1];
        fVar31 = *(float *)(arg2 + 4 + iVar20 * 8);
        pfVar1[iVar17 * 2 + -4] = fVar34 * pfVar6[iVar20 * 2] + *(float *)(arg2 + iVar20 * 8);
        pfVar1[iVar17 * 2 + -3] = fVar34 * fVar35 + fVar31;
        fVar35 = pfVar6[iVar20 * 2];
        fVar31 = *(float *)(arg2 + iVar20 * 8);
        pfVar1[iVar17 * 2 + -1] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar34 * pfVar6[iVar20 * 2 + 1];
        pfVar1[iVar17 * 2 + -2] = fVar31 - fVar34 * fVar35;
    }
    if (0 < (int32_t)uVar15) {
        uVar28 = 1;
        uVar19 = uVar18;
        iVar13 = *(int32_t *)(arg1 + 0x34);
        do {
            if (uVar28 == uVar22) {
                iVar16 = *(int32_t *)(arg1 + 0x34);
                uVar14 = uVar27;
            } else {
                iVar16 = (uVar9 ^ 1) + 2 + iVar13;
                uVar14 = uVar28;
            }
            iVar20 = (int64_t)(int32_t)uVar14;
            fVar31 = (pfVar6[iVar20 * 2] + pfVar6[uVar19 * 2]) * 0.5;
            fVar29 = (pfVar6[iVar20 * 2 + 1] + pfVar6[uVar19 * 2 + 1]) * 0.5;
            fVar35 = fVar29 * fVar29 + fVar31 * fVar31;
            if (1e-06 < fVar35) {
                fVar35 = 1.0 / fVar35;
                fVar32 = 100.0;
                if (fVar35 <= 100.0) {
                    fVar32 = fVar35;
                }
                fVar31 = fVar31 * fVar32;
                fVar29 = fVar29 * fVar32;
            }
            iVar8 = (int16_t)iVar16;
            iVar21 = iVar8 + 1;
            iVar17 = (int64_t)(int32_t)(uVar14 * 2);
            pfVar1[iVar17 * 2] = fVar31 * fVar34 + *(float *)(arg2 + iVar20 * 8);
            pfVar1[iVar17 * 2 + 1] = fVar29 * fVar34 + *(float *)(arg2 + 4 + iVar20 * 8);
            pfVar1[iVar17 * 2 + 2] = *(float *)(arg2 + iVar20 * 8) - fVar31 * fVar34;
            iVar7 = (int16_t)iVar13;
            iVar11 = iVar7 + 1;
            pfVar1[iVar17 * 2 + 3] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar29 * fVar34;
            **(int16_t **)(arg1 + 0x48) = iVar8;
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar7;
            if (uVar9 == 0) {
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar7 + 2;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar7 + 2;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar8 + 2;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar8;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xc) = iVar21;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xe) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x10) = iVar7;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x12) = iVar7;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x14) = iVar8;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x16) = iVar21;
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0x18;
            } else {
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar21;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar8;
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0xc;
            }
            uVar14 = (int32_t)uVar19 + 1;
            uVar19 = (uint64_t)uVar14;
            uVar28 = uVar28 + 1;
            iVar13 = iVar16;
        } while ((int32_t)uVar14 < (int32_t)uVar15);
    }
    if (uVar9 == 0) {
        do {
            **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(arg2 + uVar18 * 8);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 8) = uVar2;
            *(undefined4 *)(iVar20 + 0xc) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar25;
            iVar17 = (int64_t)((int32_t)uVar18 * 2);
            uVar15 = (int32_t)uVar18 + 1;
            uVar18 = (uint64_t)uVar15;
            *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x14) = *(undefined8 *)(pfVar1 + iVar17 * 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x1c) = uVar2;
            *(undefined4 *)(iVar20 + 0x20) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar26;
            *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x28) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x30) = uVar2;
            *(undefined4 *)(iVar20 + 0x34) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x38) = uVar26;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x3c;
        } while ((int32_t)uVar15 < (int32_t)uVar22);
    } else {
        iVar17 = (int64_t)iVar12;
        iVar20 = *(int64_t *)(*(int64_t *)(arg1 + 0x38) + 8);
        uVar2 = *(undefined4 *)(iVar20 + iVar17 * 0x10);
        uVar3 = *(undefined4 *)(iVar20 + 4 + iVar17 * 0x10);
        uVar4 = *(undefined4 *)(iVar20 + 8 + iVar17 * 0x10);
        uVar5 = *(undefined4 *)(iVar20 + 0xc + iVar17 * 0x10);
        do {
            iVar12 = (int32_t)uVar18;
            uVar15 = iVar12 + 1;
            uVar18 = (uint64_t)uVar15;
            iVar17 = (int64_t)(iVar12 * 2);
            **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(pfVar1 + iVar17 * 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 8) = uVar2;
            *(undefined4 *)(iVar20 + 0xc) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar25;
            *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x14) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x1c) = uVar4;
            *(undefined4 *)(iVar20 + 0x20) = uVar5;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar25;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x28;
        } while ((int32_t)uVar15 < (int32_t)uVar22);
    }
code_r0x00018012554d:
    var_c8h = (int32_t *)(arg1 + 0x34);
    *var_c8h = *var_c8h + (var_d8h._4_4_ & 0xffff);
    return;
}

// ============================================================
// Function: FUN_18012557c
// Address: 0x18012557c
// Size: 529 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch

void fcn.1801248e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    float *pfVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    float *pfVar6;
    int16_t iVar7;
    int16_t iVar8;
    uint8_t uVar9;
    uint64_t uVar10;
    int16_t iVar11;
    int32_t iVar12;
    int32_t iVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    int32_t iVar16;
    int64_t iVar17;
    uint64_t uVar19;
    int64_t iVar20;
    int16_t iVar21;
    uint32_t uVar22;
    uint32_t uVar23;
    int16_t iVar24;
    uint32_t uVar25;
    uint32_t uVar26;
    uint32_t uVar27;
    uint32_t uVar28;
    float fVar29;
    undefined auVar30 [16];
    float fVar31;
    float fVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int32_t *var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uVar18;
    
    uVar25 = (uint32_t)arg4;
    uVar22 = (uint32_t)arg3;
    iVar20 = (int64_t)(int32_t)uVar22;
    if ((int32_t)uVar22 < 2) {
        return;
    }
    if ((arg4 & 0xff000000U) == 0) {
        return;
    }
    uVar2 = **(undefined4 **)(arg1 + 0x38);
    uVar3 = (*(undefined4 **)(arg1 + 0x38))[1];
    uVar15 = uVar22;
    if ((arg_28h & 1U) == 0) {
        uVar15 = uVar22 - 1;
    }
    fVar34 = *(float *)(arg1 + 0xd0);
    if ((*(uint32_t *)(arg1 + 0x30) & 1) == 0) {
        fcn.180124680(arg1, (uint64_t)(uVar15 * 6), (uint64_t)(uVar15 * 4));
        uVar19 = 0;
        if ((int32_t)uVar15 < 1) {
            return;
        }
        do {
            fVar34 = *(float *)(arg2 + uVar19 * 8);
            uVar28 = (int32_t)uVar19 + 1;
            uVar26 = 0;
            if (uVar28 != uVar22) {
                uVar26 = uVar28;
            }
            iVar20 = (int64_t)(int32_t)uVar26;
            fVar31 = *(float *)(arg2 + iVar20 * 8) - fVar34;
            fVar29 = *(float *)(arg2 + 4 + iVar20 * 8) - *(float *)(arg2 + 4 + uVar19 * 8);
            fVar35 = fVar29 * fVar29 + fVar31 * fVar31;
            if (0.0 < fVar35) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar35), ZEXT416((uint32_t)fVar35));
                fVar31 = fVar31 * auVar30._0_4_;
                fVar29 = fVar29 * auVar30._0_4_;
            }
            fVar29 = fVar29 * (float)arg_30h * 0.5;
            fVar31 = fVar31 * (float)arg_30h * 0.5;
            **(float **)(arg1 + 0x40) = fVar29 + fVar34;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 4) = *(float *)(arg2 + 4 + uVar19 * 8) - fVar31;
            iVar17 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar17 + 8) = uVar2;
            *(undefined4 *)(iVar17 + 0xc) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar25;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x14) = fVar29 + *(float *)(arg2 + iVar20 * 8);
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x18) = *(float *)(arg2 + 4 + iVar20 * 8) - fVar31;
            iVar17 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar17 + 0x1c) = uVar2;
            *(undefined4 *)(iVar17 + 0x20) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar25;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x28) = *(float *)(arg2 + iVar20 * 8) - fVar29;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x2c) = fVar31 + *(float *)(arg2 + 4 + iVar20 * 8);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x30) = uVar2;
            *(undefined4 *)(iVar20 + 0x34) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x38) = uVar25;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x3c) = *(float *)(arg2 + uVar19 * 8) - fVar29;
            iVar20 = uVar19 * 8;
            uVar19 = (uint64_t)uVar28;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x40) = fVar31 + *(float *)(arg2 + 4 + iVar20);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x44) = uVar2;
            *(undefined4 *)(iVar20 + 0x48) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x4c) = uVar25;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x50;
            **(undefined2 **)(arg1 + 0x48) = *(undefined2 *)(arg1 + 0x34);
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = *(int16_t *)(arg1 + 0x34) + 1;
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = *(int16_t *)(arg1 + 0x34) + 2;
            *(undefined2 *)(*(int64_t *)(arg1 + 0x48) + 6) = *(undefined2 *)(arg1 + 0x34);
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = *(int16_t *)(arg1 + 0x34) + 2;
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = *(int16_t *)(arg1 + 0x34) + 3;
            *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0xc;
            *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + 4;
        } while ((int32_t)uVar28 < (int32_t)uVar15);
        return;
    }
    uVar26 = uVar25 & 0xffffff;
    fVar35 = (float)arg_30h;
    if ((float)arg_30h <= 1.0) {
        fVar35 = 1.0;
    }
    iVar12 = (int32_t)fVar35;
    if (((((*(uint32_t *)(arg1 + 0x30) & 2) == 0) || (0x1f < iVar12)) || (1e-05 < fVar35 - (float)iVar12)) ||
       (fVar34 != 1.0)) {
        if ((float)arg_30h <= fVar34) {
            var_d8h._4_4_ = uVar22 * 3;
            uVar9 = 0;
            uVar28 = uVar15 * 0xc;
            goto code_r0x000180124a47;
        }
        var_d8h._4_4_ = uVar22 * 4;
        fcn.180124680(arg1, (uint64_t)(uVar15 * 0x12), (uint64_t)var_d8h._4_4_);
        iVar13 = 5;
        uVar9 = 0;
    } else {
        var_d8h._4_4_ = uVar22 * 2;
        uVar9 = 1;
        uVar28 = uVar15 * 6;
code_r0x000180124a47:
        fcn.180124680(arg1, (uint64_t)uVar28, (uint64_t)var_d8h._4_4_);
        iVar13 = 3;
    }
    func_0x0001801312e0(*(int64_t *)(arg1 + 0x38) + 0x48, iVar13 * uVar22);
    uVar18 = 0;
    uVar27 = 0;
    pfVar6 = *(float **)(*(int64_t *)(arg1 + 0x38) + 0x50);
    pfVar1 = pfVar6 + iVar20 * 2;
    uVar28 = 0;
    uVar19 = uVar18;
    if (3 < (int32_t)uVar15) {
        do {
            iVar13 = (int32_t)uVar19;
            iVar17 = (int64_t)iVar13;
            uVar14 = uVar27;
            if (iVar13 + 1U != uVar22) {
                uVar14 = iVar13 + 1U;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 4 + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2] = fVar32;
            pfVar6[iVar17 * 2 + 1] = (float)((uint32_t)fVar31 ^ 0x80000000);
            uVar14 = uVar27;
            if (iVar13 + 2U != uVar22) {
                uVar14 = iVar13 + 2U;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 8 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0xc + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2 + 2] = fVar32;
            pfVar6[iVar17 * 2 + 3] = (float)((uint32_t)fVar31 ^ 0x80000000);
            uVar14 = uVar27;
            if (iVar13 + 3U != uVar22) {
                uVar14 = iVar13 + 3U;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x10 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x14 + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2 + 4] = fVar32;
            uVar23 = iVar13 + 4;
            uVar19 = (uint64_t)uVar23;
            pfVar6[iVar17 * 2 + 5] = (float)((uint32_t)fVar31 ^ 0x80000000);
            uVar14 = uVar28;
            if (uVar23 != uVar22) {
                uVar14 = uVar23;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x18 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x1c + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2 + 6] = fVar32;
            pfVar6[iVar17 * 2 + 7] = (float)((uint32_t)fVar31 ^ 0x80000000);
        } while ((int32_t)uVar23 < (int32_t)(uVar15 - 3));
    }
    uVar14 = (uint32_t)uVar19;
    while ((int32_t)uVar14 < (int32_t)uVar15) {
        uVar14 = (int32_t)uVar19 + 1;
        uVar23 = uVar28;
        if (uVar14 != uVar22) {
            uVar23 = uVar14;
        }
        iVar17 = (int64_t)(int32_t)uVar19;
        fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar23 * 8) - *(float *)(arg2 + iVar17 * 8);
        fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar23 * 8) - *(float *)(arg2 + 4 + iVar17 * 8);
        fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
        if (0.0 < fVar29) {
            auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
            fVar32 = auVar30._0_4_ * fVar32;
            fVar31 = auVar30._0_4_ * fVar31;
        }
        pfVar6[iVar17 * 2] = fVar32;
        pfVar6[iVar17 * 2 + 1] = (float)((uint32_t)fVar31 ^ 0x80000000);
        uVar19 = (uint64_t)uVar14;
    }
    if ((arg_28h & 1U) == 0) {
        *(undefined8 *)(pfVar6 + iVar20 * 2 + -2) = *(undefined8 *)(pfVar6 + iVar20 * 2 + -4);
    }
    if (uVar9 == 0) {
        if (fVar34 < (float)arg_30h) {
            fVar35 = (fVar35 - fVar34) * 0.5;
            if ((arg_28h & 1U) == 0) {
                fVar32 = fVar35 + fVar34;
                iVar17 = (int64_t)(int32_t)(uVar22 * 4 + -4);
                fVar31 = pfVar6[1];
                fVar29 = *(float *)(arg2 + 4);
                *pfVar1 = fVar32 * *pfVar6 + *(float *)arg2;
                pfVar1[1] = fVar32 * fVar31 + fVar29;
                fVar31 = pfVar6[1];
                fVar29 = *(float *)(arg2 + 4);
                pfVar1[2] = fVar35 * *pfVar6 + *(float *)arg2;
                pfVar1[3] = fVar35 * fVar31 + fVar29;
                fVar31 = *pfVar6;
                fVar29 = *(float *)arg2;
                pfVar1[5] = *(float *)(arg2 + 4) - fVar35 * pfVar6[1];
                pfVar1[4] = fVar29 - fVar35 * fVar31;
                fVar31 = *(float *)arg2;
                fVar29 = *pfVar6;
                pfVar1[7] = *(float *)(arg2 + 4) - fVar32 * pfVar6[1];
                pfVar1[6] = fVar31 - fVar32 * fVar29;
                fVar31 = pfVar6[iVar20 * 2 + -1];
                fVar29 = *(float *)(arg2 + -4 + iVar20 * 8);
                pfVar1[iVar17 * 2] = fVar32 * pfVar6[iVar20 * 2 + -2] + *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 1] = fVar32 * fVar31 + fVar29;
                fVar31 = pfVar6[iVar20 * 2 + -1];
                fVar29 = *(float *)(arg2 + -4 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 2] = fVar35 * pfVar6[iVar20 * 2 + -2] + *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 3] = fVar35 * fVar31 + fVar29;
                fVar31 = pfVar6[iVar20 * 2 + -2];
                fVar29 = *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 5] = *(float *)(arg2 + -4 + iVar20 * 8) - fVar35 * pfVar6[iVar20 * 2 + -1];
                pfVar1[iVar17 * 2 + 4] = fVar29 - fVar35 * fVar31;
                fVar31 = pfVar6[iVar20 * 2 + -2];
                fVar29 = *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 7] = *(float *)(arg2 + -4 + iVar20 * 8) - fVar32 * pfVar6[iVar20 * 2 + -1];
                pfVar1[iVar17 * 2 + 6] = fVar29 - fVar32 * fVar31;
            }
            var_18h._0_4_ = 0;
            uVar19 = uVar18;
            if (0 < (int32_t)uVar15) {
                uVar27 = 1;
                uVar10 = uVar18;
                iVar12 = *(int32_t *)(arg1 + 0x34);
                do {
                    if (uVar27 == uVar22) {
                        iVar13 = *(int32_t *)(arg1 + 0x34);
                        uVar14 = uVar28;
                    } else {
                        iVar13 = iVar12 + 4;
                        uVar14 = uVar27;
                    }
                    iVar20 = (int64_t)(int32_t)uVar14;
                    fVar29 = (pfVar6[iVar20 * 2] + pfVar6[uVar10 * 2]) * 0.5;
                    fVar32 = (pfVar6[iVar20 * 2 + 1] + pfVar6[uVar10 * 2 + 1]) * 0.5;
                    fVar31 = fVar32 * fVar32 + fVar29 * fVar29;
                    if (1e-06 < fVar31) {
                        fVar31 = 1.0 / fVar31;
                        fVar33 = 100.0;
                        if (fVar31 <= 100.0) {
                            fVar33 = fVar31;
                        }
                        fVar29 = fVar29 * fVar33;
                        fVar32 = fVar32 * fVar33;
                    }
                    iVar17 = (int64_t)(int32_t)(uVar14 * 4);
                    iVar7 = (int16_t)iVar13;
                    iVar24 = iVar7 + 1;
                    fVar31 = (fVar34 + fVar35) * fVar29;
                    iVar21 = iVar7 + 2;
                    uVar27 = uVar27 + 1;
                    fVar33 = (fVar34 + fVar35) * fVar32;
                    pfVar1[iVar17 * 2] = fVar31 + *(float *)(arg2 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 1] = fVar33 + *(float *)(arg2 + 4 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 2] = fVar29 * fVar35 + *(float *)(arg2 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 3] = fVar32 * fVar35 + *(float *)(arg2 + 4 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 4] = *(float *)(arg2 + iVar20 * 8) - fVar29 * fVar35;
                    pfVar1[iVar17 * 2 + 5] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar32 * fVar35;
                    pfVar1[iVar17 * 2 + 6] = *(float *)(arg2 + iVar20 * 8) - fVar31;
                    iVar8 = (int16_t)iVar12;
                    iVar11 = iVar8 + 2;
                    pfVar1[iVar17 * 2 + 7] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar33;
                    **(int16_t **)(arg1 + 0x48) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar8 + 1;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar11;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar21;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xc) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xe) = iVar8 + 1;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x10) = iVar8;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x12) = iVar8;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x14) = iVar7;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x16) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x18) = iVar21;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x1a) = iVar11;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x1c) = iVar8 + 3;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x1e) = iVar8 + 3;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x20) = iVar7 + 3;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x22) = iVar21;
                    *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0x24;
                    var_18h._0_4_ = (uint32_t)var_18h + 1;
                    uVar10 = (uint64_t)(uint32_t)var_18h;
                    iVar12 = iVar13;
                } while ((int32_t)(uint32_t)var_18h < (int32_t)uVar15);
            }
            do {
                uVar15 = (int32_t)uVar18 + 1;
                uVar18 = (uint64_t)uVar15;
                iVar17 = (int64_t)(int32_t)uVar19;
                **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(pfVar1 + iVar17 * 2);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 8) = uVar2;
                *(undefined4 *)(iVar20 + 0xc) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar26;
                *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x14) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 2);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 0x1c) = uVar2;
                *(undefined4 *)(iVar20 + 0x20) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar25;
                *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x28) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 4);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 0x30) = uVar2;
                *(undefined4 *)(iVar20 + 0x34) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x38) = uVar25;
                *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x3c) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 6);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 0x44) = uVar2;
                *(undefined4 *)(iVar20 + 0x48) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x4c) = uVar26;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x50;
                uVar19 = (uint64_t)((int32_t)uVar19 + 4);
            } while ((int32_t)uVar15 < (int32_t)uVar22);
            goto code_r0x00018012554d;
        }
    } else {
        fVar34 = fVar35 * 0.5 + 1.0;
    }
    if ((arg_28h & 1U) == 0) {
        iVar20 = iVar20 + -1;
        iVar17 = (int64_t)(int32_t)(uVar22 * 2);
        fVar35 = pfVar6[1];
        fVar31 = *(float *)(arg2 + 4);
        *pfVar1 = fVar34 * *pfVar6 + *(float *)arg2;
        pfVar1[1] = fVar34 * fVar35 + fVar31;
        fVar35 = *pfVar6;
        fVar31 = *(float *)arg2;
        pfVar1[3] = *(float *)(arg2 + 4) - fVar34 * pfVar6[1];
        pfVar1[2] = fVar31 - fVar34 * fVar35;
        fVar35 = pfVar6[iVar20 * 2 + 1];
        fVar31 = *(float *)(arg2 + 4 + iVar20 * 8);
        pfVar1[iVar17 * 2 + -4] = fVar34 * pfVar6[iVar20 * 2] + *(float *)(arg2 + iVar20 * 8);
        pfVar1[iVar17 * 2 + -3] = fVar34 * fVar35 + fVar31;
        fVar35 = pfVar6[iVar20 * 2];
        fVar31 = *(float *)(arg2 + iVar20 * 8);
        pfVar1[iVar17 * 2 + -1] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar34 * pfVar6[iVar20 * 2 + 1];
        pfVar1[iVar17 * 2 + -2] = fVar31 - fVar34 * fVar35;
    }
    if (0 < (int32_t)uVar15) {
        uVar28 = 1;
        uVar19 = uVar18;
        iVar13 = *(int32_t *)(arg1 + 0x34);
        do {
            if (uVar28 == uVar22) {
                iVar16 = *(int32_t *)(arg1 + 0x34);
                uVar14 = uVar27;
            } else {
                iVar16 = (uVar9 ^ 1) + 2 + iVar13;
                uVar14 = uVar28;
            }
            iVar20 = (int64_t)(int32_t)uVar14;
            fVar31 = (pfVar6[iVar20 * 2] + pfVar6[uVar19 * 2]) * 0.5;
            fVar29 = (pfVar6[iVar20 * 2 + 1] + pfVar6[uVar19 * 2 + 1]) * 0.5;
            fVar35 = fVar29 * fVar29 + fVar31 * fVar31;
            if (1e-06 < fVar35) {
                fVar35 = 1.0 / fVar35;
                fVar32 = 100.0;
                if (fVar35 <= 100.0) {
                    fVar32 = fVar35;
                }
                fVar31 = fVar31 * fVar32;
                fVar29 = fVar29 * fVar32;
            }
            iVar8 = (int16_t)iVar16;
            iVar21 = iVar8 + 1;
            iVar17 = (int64_t)(int32_t)(uVar14 * 2);
            pfVar1[iVar17 * 2] = fVar31 * fVar34 + *(float *)(arg2 + iVar20 * 8);
            pfVar1[iVar17 * 2 + 1] = fVar29 * fVar34 + *(float *)(arg2 + 4 + iVar20 * 8);
            pfVar1[iVar17 * 2 + 2] = *(float *)(arg2 + iVar20 * 8) - fVar31 * fVar34;
            iVar7 = (int16_t)iVar13;
            iVar11 = iVar7 + 1;
            pfVar1[iVar17 * 2 + 3] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar29 * fVar34;
            **(int16_t **)(arg1 + 0x48) = iVar8;
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar7;
            if (uVar9 == 0) {
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar7 + 2;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar7 + 2;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar8 + 2;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar8;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xc) = iVar21;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xe) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x10) = iVar7;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x12) = iVar7;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x14) = iVar8;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x16) = iVar21;
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0x18;
            } else {
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar21;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar8;
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0xc;
            }
            uVar14 = (int32_t)uVar19 + 1;
            uVar19 = (uint64_t)uVar14;
            uVar28 = uVar28 + 1;
            iVar13 = iVar16;
        } while ((int32_t)uVar14 < (int32_t)uVar15);
    }
    if (uVar9 == 0) {
        do {
            **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(arg2 + uVar18 * 8);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 8) = uVar2;
            *(undefined4 *)(iVar20 + 0xc) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar25;
            iVar17 = (int64_t)((int32_t)uVar18 * 2);
            uVar15 = (int32_t)uVar18 + 1;
            uVar18 = (uint64_t)uVar15;
            *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x14) = *(undefined8 *)(pfVar1 + iVar17 * 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x1c) = uVar2;
            *(undefined4 *)(iVar20 + 0x20) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar26;
            *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x28) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x30) = uVar2;
            *(undefined4 *)(iVar20 + 0x34) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x38) = uVar26;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x3c;
        } while ((int32_t)uVar15 < (int32_t)uVar22);
    } else {
        iVar17 = (int64_t)iVar12;
        iVar20 = *(int64_t *)(*(int64_t *)(arg1 + 0x38) + 8);
        uVar2 = *(undefined4 *)(iVar20 + iVar17 * 0x10);
        uVar3 = *(undefined4 *)(iVar20 + 4 + iVar17 * 0x10);
        uVar4 = *(undefined4 *)(iVar20 + 8 + iVar17 * 0x10);
        uVar5 = *(undefined4 *)(iVar20 + 0xc + iVar17 * 0x10);
        do {
            iVar12 = (int32_t)uVar18;
            uVar15 = iVar12 + 1;
            uVar18 = (uint64_t)uVar15;
            iVar17 = (int64_t)(iVar12 * 2);
            **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(pfVar1 + iVar17 * 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 8) = uVar2;
            *(undefined4 *)(iVar20 + 0xc) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar25;
            *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x14) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x1c) = uVar4;
            *(undefined4 *)(iVar20 + 0x20) = uVar5;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar25;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x28;
        } while ((int32_t)uVar15 < (int32_t)uVar22);
    }
code_r0x00018012554d:
    var_c8h = (int32_t *)(arg1 + 0x34);
    *var_c8h = *var_c8h + (var_d8h._4_4_ & 0xffff);
    return;
}

// ============================================================
// Function: FUN_18012578d
// Address: 0x18012578d
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch

void fcn.1801248e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    float *pfVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    float *pfVar6;
    int16_t iVar7;
    int16_t iVar8;
    uint8_t uVar9;
    uint64_t uVar10;
    int16_t iVar11;
    int32_t iVar12;
    int32_t iVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    int32_t iVar16;
    int64_t iVar17;
    uint64_t uVar19;
    int64_t iVar20;
    int16_t iVar21;
    uint32_t uVar22;
    uint32_t uVar23;
    int16_t iVar24;
    uint32_t uVar25;
    uint32_t uVar26;
    uint32_t uVar27;
    uint32_t uVar28;
    float fVar29;
    undefined auVar30 [16];
    float fVar31;
    float fVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int32_t *var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uVar18;
    
    uVar25 = (uint32_t)arg4;
    uVar22 = (uint32_t)arg3;
    iVar20 = (int64_t)(int32_t)uVar22;
    if ((int32_t)uVar22 < 2) {
        return;
    }
    if ((arg4 & 0xff000000U) == 0) {
        return;
    }
    uVar2 = **(undefined4 **)(arg1 + 0x38);
    uVar3 = (*(undefined4 **)(arg1 + 0x38))[1];
    uVar15 = uVar22;
    if ((arg_28h & 1U) == 0) {
        uVar15 = uVar22 - 1;
    }
    fVar34 = *(float *)(arg1 + 0xd0);
    if ((*(uint32_t *)(arg1 + 0x30) & 1) == 0) {
        fcn.180124680(arg1, (uint64_t)(uVar15 * 6), (uint64_t)(uVar15 * 4));
        uVar19 = 0;
        if ((int32_t)uVar15 < 1) {
            return;
        }
        do {
            fVar34 = *(float *)(arg2 + uVar19 * 8);
            uVar28 = (int32_t)uVar19 + 1;
            uVar26 = 0;
            if (uVar28 != uVar22) {
                uVar26 = uVar28;
            }
            iVar20 = (int64_t)(int32_t)uVar26;
            fVar31 = *(float *)(arg2 + iVar20 * 8) - fVar34;
            fVar29 = *(float *)(arg2 + 4 + iVar20 * 8) - *(float *)(arg2 + 4 + uVar19 * 8);
            fVar35 = fVar29 * fVar29 + fVar31 * fVar31;
            if (0.0 < fVar35) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar35), ZEXT416((uint32_t)fVar35));
                fVar31 = fVar31 * auVar30._0_4_;
                fVar29 = fVar29 * auVar30._0_4_;
            }
            fVar29 = fVar29 * (float)arg_30h * 0.5;
            fVar31 = fVar31 * (float)arg_30h * 0.5;
            **(float **)(arg1 + 0x40) = fVar29 + fVar34;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 4) = *(float *)(arg2 + 4 + uVar19 * 8) - fVar31;
            iVar17 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar17 + 8) = uVar2;
            *(undefined4 *)(iVar17 + 0xc) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar25;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x14) = fVar29 + *(float *)(arg2 + iVar20 * 8);
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x18) = *(float *)(arg2 + 4 + iVar20 * 8) - fVar31;
            iVar17 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar17 + 0x1c) = uVar2;
            *(undefined4 *)(iVar17 + 0x20) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar25;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x28) = *(float *)(arg2 + iVar20 * 8) - fVar29;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x2c) = fVar31 + *(float *)(arg2 + 4 + iVar20 * 8);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x30) = uVar2;
            *(undefined4 *)(iVar20 + 0x34) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x38) = uVar25;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x3c) = *(float *)(arg2 + uVar19 * 8) - fVar29;
            iVar20 = uVar19 * 8;
            uVar19 = (uint64_t)uVar28;
            *(float *)(*(int64_t *)(arg1 + 0x40) + 0x40) = fVar31 + *(float *)(arg2 + 4 + iVar20);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x44) = uVar2;
            *(undefined4 *)(iVar20 + 0x48) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x4c) = uVar25;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x50;
            **(undefined2 **)(arg1 + 0x48) = *(undefined2 *)(arg1 + 0x34);
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = *(int16_t *)(arg1 + 0x34) + 1;
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = *(int16_t *)(arg1 + 0x34) + 2;
            *(undefined2 *)(*(int64_t *)(arg1 + 0x48) + 6) = *(undefined2 *)(arg1 + 0x34);
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = *(int16_t *)(arg1 + 0x34) + 2;
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = *(int16_t *)(arg1 + 0x34) + 3;
            *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0xc;
            *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + 4;
        } while ((int32_t)uVar28 < (int32_t)uVar15);
        return;
    }
    uVar26 = uVar25 & 0xffffff;
    fVar35 = (float)arg_30h;
    if ((float)arg_30h <= 1.0) {
        fVar35 = 1.0;
    }
    iVar12 = (int32_t)fVar35;
    if (((((*(uint32_t *)(arg1 + 0x30) & 2) == 0) || (0x1f < iVar12)) || (1e-05 < fVar35 - (float)iVar12)) ||
       (fVar34 != 1.0)) {
        if ((float)arg_30h <= fVar34) {
            var_d8h._4_4_ = uVar22 * 3;
            uVar9 = 0;
            uVar28 = uVar15 * 0xc;
            goto code_r0x000180124a47;
        }
        var_d8h._4_4_ = uVar22 * 4;
        fcn.180124680(arg1, (uint64_t)(uVar15 * 0x12), (uint64_t)var_d8h._4_4_);
        iVar13 = 5;
        uVar9 = 0;
    } else {
        var_d8h._4_4_ = uVar22 * 2;
        uVar9 = 1;
        uVar28 = uVar15 * 6;
code_r0x000180124a47:
        fcn.180124680(arg1, (uint64_t)uVar28, (uint64_t)var_d8h._4_4_);
        iVar13 = 3;
    }
    func_0x0001801312e0(*(int64_t *)(arg1 + 0x38) + 0x48, iVar13 * uVar22);
    uVar18 = 0;
    uVar27 = 0;
    pfVar6 = *(float **)(*(int64_t *)(arg1 + 0x38) + 0x50);
    pfVar1 = pfVar6 + iVar20 * 2;
    uVar28 = 0;
    uVar19 = uVar18;
    if (3 < (int32_t)uVar15) {
        do {
            iVar13 = (int32_t)uVar19;
            iVar17 = (int64_t)iVar13;
            uVar14 = uVar27;
            if (iVar13 + 1U != uVar22) {
                uVar14 = iVar13 + 1U;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 4 + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2] = fVar32;
            pfVar6[iVar17 * 2 + 1] = (float)((uint32_t)fVar31 ^ 0x80000000);
            uVar14 = uVar27;
            if (iVar13 + 2U != uVar22) {
                uVar14 = iVar13 + 2U;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 8 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0xc + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2 + 2] = fVar32;
            pfVar6[iVar17 * 2 + 3] = (float)((uint32_t)fVar31 ^ 0x80000000);
            uVar14 = uVar27;
            if (iVar13 + 3U != uVar22) {
                uVar14 = iVar13 + 3U;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x10 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x14 + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2 + 4] = fVar32;
            uVar23 = iVar13 + 4;
            uVar19 = (uint64_t)uVar23;
            pfVar6[iVar17 * 2 + 5] = (float)((uint32_t)fVar31 ^ 0x80000000);
            uVar14 = uVar28;
            if (uVar23 != uVar22) {
                uVar14 = uVar23;
            }
            fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x18 + iVar17 * 8);
            fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar14 * 8) - *(float *)(arg2 + 0x1c + iVar17 * 8);
            fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
            if (0.0 < fVar29) {
                auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
                fVar32 = auVar30._0_4_ * fVar32;
                fVar31 = auVar30._0_4_ * fVar31;
            }
            pfVar6[iVar17 * 2 + 6] = fVar32;
            pfVar6[iVar17 * 2 + 7] = (float)((uint32_t)fVar31 ^ 0x80000000);
        } while ((int32_t)uVar23 < (int32_t)(uVar15 - 3));
    }
    uVar14 = (uint32_t)uVar19;
    while ((int32_t)uVar14 < (int32_t)uVar15) {
        uVar14 = (int32_t)uVar19 + 1;
        uVar23 = uVar28;
        if (uVar14 != uVar22) {
            uVar23 = uVar14;
        }
        iVar17 = (int64_t)(int32_t)uVar19;
        fVar31 = *(float *)(arg2 + (int64_t)(int32_t)uVar23 * 8) - *(float *)(arg2 + iVar17 * 8);
        fVar32 = *(float *)(arg2 + 4 + (int64_t)(int32_t)uVar23 * 8) - *(float *)(arg2 + 4 + iVar17 * 8);
        fVar29 = fVar32 * fVar32 + fVar31 * fVar31;
        if (0.0 < fVar29) {
            auVar30 = rsqrtss(ZEXT416((uint32_t)fVar29), ZEXT416((uint32_t)fVar29));
            fVar32 = auVar30._0_4_ * fVar32;
            fVar31 = auVar30._0_4_ * fVar31;
        }
        pfVar6[iVar17 * 2] = fVar32;
        pfVar6[iVar17 * 2 + 1] = (float)((uint32_t)fVar31 ^ 0x80000000);
        uVar19 = (uint64_t)uVar14;
    }
    if ((arg_28h & 1U) == 0) {
        *(undefined8 *)(pfVar6 + iVar20 * 2 + -2) = *(undefined8 *)(pfVar6 + iVar20 * 2 + -4);
    }
    if (uVar9 == 0) {
        if (fVar34 < (float)arg_30h) {
            fVar35 = (fVar35 - fVar34) * 0.5;
            if ((arg_28h & 1U) == 0) {
                fVar32 = fVar35 + fVar34;
                iVar17 = (int64_t)(int32_t)(uVar22 * 4 + -4);
                fVar31 = pfVar6[1];
                fVar29 = *(float *)(arg2 + 4);
                *pfVar1 = fVar32 * *pfVar6 + *(float *)arg2;
                pfVar1[1] = fVar32 * fVar31 + fVar29;
                fVar31 = pfVar6[1];
                fVar29 = *(float *)(arg2 + 4);
                pfVar1[2] = fVar35 * *pfVar6 + *(float *)arg2;
                pfVar1[3] = fVar35 * fVar31 + fVar29;
                fVar31 = *pfVar6;
                fVar29 = *(float *)arg2;
                pfVar1[5] = *(float *)(arg2 + 4) - fVar35 * pfVar6[1];
                pfVar1[4] = fVar29 - fVar35 * fVar31;
                fVar31 = *(float *)arg2;
                fVar29 = *pfVar6;
                pfVar1[7] = *(float *)(arg2 + 4) - fVar32 * pfVar6[1];
                pfVar1[6] = fVar31 - fVar32 * fVar29;
                fVar31 = pfVar6[iVar20 * 2 + -1];
                fVar29 = *(float *)(arg2 + -4 + iVar20 * 8);
                pfVar1[iVar17 * 2] = fVar32 * pfVar6[iVar20 * 2 + -2] + *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 1] = fVar32 * fVar31 + fVar29;
                fVar31 = pfVar6[iVar20 * 2 + -1];
                fVar29 = *(float *)(arg2 + -4 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 2] = fVar35 * pfVar6[iVar20 * 2 + -2] + *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 3] = fVar35 * fVar31 + fVar29;
                fVar31 = pfVar6[iVar20 * 2 + -2];
                fVar29 = *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 5] = *(float *)(arg2 + -4 + iVar20 * 8) - fVar35 * pfVar6[iVar20 * 2 + -1];
                pfVar1[iVar17 * 2 + 4] = fVar29 - fVar35 * fVar31;
                fVar31 = pfVar6[iVar20 * 2 + -2];
                fVar29 = *(float *)(arg2 + -8 + iVar20 * 8);
                pfVar1[iVar17 * 2 + 7] = *(float *)(arg2 + -4 + iVar20 * 8) - fVar32 * pfVar6[iVar20 * 2 + -1];
                pfVar1[iVar17 * 2 + 6] = fVar29 - fVar32 * fVar31;
            }
            var_18h._0_4_ = 0;
            uVar19 = uVar18;
            if (0 < (int32_t)uVar15) {
                uVar27 = 1;
                uVar10 = uVar18;
                iVar12 = *(int32_t *)(arg1 + 0x34);
                do {
                    if (uVar27 == uVar22) {
                        iVar13 = *(int32_t *)(arg1 + 0x34);
                        uVar14 = uVar28;
                    } else {
                        iVar13 = iVar12 + 4;
                        uVar14 = uVar27;
                    }
                    iVar20 = (int64_t)(int32_t)uVar14;
                    fVar29 = (pfVar6[iVar20 * 2] + pfVar6[uVar10 * 2]) * 0.5;
                    fVar32 = (pfVar6[iVar20 * 2 + 1] + pfVar6[uVar10 * 2 + 1]) * 0.5;
                    fVar31 = fVar32 * fVar32 + fVar29 * fVar29;
                    if (1e-06 < fVar31) {
                        fVar31 = 1.0 / fVar31;
                        fVar33 = 100.0;
                        if (fVar31 <= 100.0) {
                            fVar33 = fVar31;
                        }
                        fVar29 = fVar29 * fVar33;
                        fVar32 = fVar32 * fVar33;
                    }
                    iVar17 = (int64_t)(int32_t)(uVar14 * 4);
                    iVar7 = (int16_t)iVar13;
                    iVar24 = iVar7 + 1;
                    fVar31 = (fVar34 + fVar35) * fVar29;
                    iVar21 = iVar7 + 2;
                    uVar27 = uVar27 + 1;
                    fVar33 = (fVar34 + fVar35) * fVar32;
                    pfVar1[iVar17 * 2] = fVar31 + *(float *)(arg2 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 1] = fVar33 + *(float *)(arg2 + 4 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 2] = fVar29 * fVar35 + *(float *)(arg2 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 3] = fVar32 * fVar35 + *(float *)(arg2 + 4 + iVar20 * 8);
                    pfVar1[iVar17 * 2 + 4] = *(float *)(arg2 + iVar20 * 8) - fVar29 * fVar35;
                    pfVar1[iVar17 * 2 + 5] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar32 * fVar35;
                    pfVar1[iVar17 * 2 + 6] = *(float *)(arg2 + iVar20 * 8) - fVar31;
                    iVar8 = (int16_t)iVar12;
                    iVar11 = iVar8 + 2;
                    pfVar1[iVar17 * 2 + 7] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar33;
                    **(int16_t **)(arg1 + 0x48) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar8 + 1;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar11;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar21;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xc) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xe) = iVar8 + 1;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x10) = iVar8;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x12) = iVar8;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x14) = iVar7;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x16) = iVar24;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x18) = iVar21;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x1a) = iVar11;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x1c) = iVar8 + 3;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x1e) = iVar8 + 3;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x20) = iVar7 + 3;
                    *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x22) = iVar21;
                    *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0x24;
                    var_18h._0_4_ = (uint32_t)var_18h + 1;
                    uVar10 = (uint64_t)(uint32_t)var_18h;
                    iVar12 = iVar13;
                } while ((int32_t)(uint32_t)var_18h < (int32_t)uVar15);
            }
            do {
                uVar15 = (int32_t)uVar18 + 1;
                uVar18 = (uint64_t)uVar15;
                iVar17 = (int64_t)(int32_t)uVar19;
                **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(pfVar1 + iVar17 * 2);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 8) = uVar2;
                *(undefined4 *)(iVar20 + 0xc) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar26;
                *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x14) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 2);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 0x1c) = uVar2;
                *(undefined4 *)(iVar20 + 0x20) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar25;
                *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x28) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 4);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 0x30) = uVar2;
                *(undefined4 *)(iVar20 + 0x34) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x38) = uVar25;
                *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x3c) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 6);
                iVar20 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar20 + 0x44) = uVar2;
                *(undefined4 *)(iVar20 + 0x48) = uVar3;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x4c) = uVar26;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x50;
                uVar19 = (uint64_t)((int32_t)uVar19 + 4);
            } while ((int32_t)uVar15 < (int32_t)uVar22);
            goto code_r0x00018012554d;
        }
    } else {
        fVar34 = fVar35 * 0.5 + 1.0;
    }
    if ((arg_28h & 1U) == 0) {
        iVar20 = iVar20 + -1;
        iVar17 = (int64_t)(int32_t)(uVar22 * 2);
        fVar35 = pfVar6[1];
        fVar31 = *(float *)(arg2 + 4);
        *pfVar1 = fVar34 * *pfVar6 + *(float *)arg2;
        pfVar1[1] = fVar34 * fVar35 + fVar31;
        fVar35 = *pfVar6;
        fVar31 = *(float *)arg2;
        pfVar1[3] = *(float *)(arg2 + 4) - fVar34 * pfVar6[1];
        pfVar1[2] = fVar31 - fVar34 * fVar35;
        fVar35 = pfVar6[iVar20 * 2 + 1];
        fVar31 = *(float *)(arg2 + 4 + iVar20 * 8);
        pfVar1[iVar17 * 2 + -4] = fVar34 * pfVar6[iVar20 * 2] + *(float *)(arg2 + iVar20 * 8);
        pfVar1[iVar17 * 2 + -3] = fVar34 * fVar35 + fVar31;
        fVar35 = pfVar6[iVar20 * 2];
        fVar31 = *(float *)(arg2 + iVar20 * 8);
        pfVar1[iVar17 * 2 + -1] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar34 * pfVar6[iVar20 * 2 + 1];
        pfVar1[iVar17 * 2 + -2] = fVar31 - fVar34 * fVar35;
    }
    if (0 < (int32_t)uVar15) {
        uVar28 = 1;
        uVar19 = uVar18;
        iVar13 = *(int32_t *)(arg1 + 0x34);
        do {
            if (uVar28 == uVar22) {
                iVar16 = *(int32_t *)(arg1 + 0x34);
                uVar14 = uVar27;
            } else {
                iVar16 = (uVar9 ^ 1) + 2 + iVar13;
                uVar14 = uVar28;
            }
            iVar20 = (int64_t)(int32_t)uVar14;
            fVar31 = (pfVar6[iVar20 * 2] + pfVar6[uVar19 * 2]) * 0.5;
            fVar29 = (pfVar6[iVar20 * 2 + 1] + pfVar6[uVar19 * 2 + 1]) * 0.5;
            fVar35 = fVar29 * fVar29 + fVar31 * fVar31;
            if (1e-06 < fVar35) {
                fVar35 = 1.0 / fVar35;
                fVar32 = 100.0;
                if (fVar35 <= 100.0) {
                    fVar32 = fVar35;
                }
                fVar31 = fVar31 * fVar32;
                fVar29 = fVar29 * fVar32;
            }
            iVar8 = (int16_t)iVar16;
            iVar21 = iVar8 + 1;
            iVar17 = (int64_t)(int32_t)(uVar14 * 2);
            pfVar1[iVar17 * 2] = fVar31 * fVar34 + *(float *)(arg2 + iVar20 * 8);
            pfVar1[iVar17 * 2 + 1] = fVar29 * fVar34 + *(float *)(arg2 + 4 + iVar20 * 8);
            pfVar1[iVar17 * 2 + 2] = *(float *)(arg2 + iVar20 * 8) - fVar31 * fVar34;
            iVar7 = (int16_t)iVar13;
            iVar11 = iVar7 + 1;
            pfVar1[iVar17 * 2 + 3] = *(float *)(arg2 + 4 + iVar20 * 8) - fVar29 * fVar34;
            **(int16_t **)(arg1 + 0x48) = iVar8;
            *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar7;
            if (uVar9 == 0) {
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar7 + 2;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar7 + 2;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar8 + 2;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar8;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xc) = iVar21;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0xe) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x10) = iVar7;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x12) = iVar7;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x14) = iVar8;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 0x16) = iVar21;
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0x18;
            } else {
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar21;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar8;
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0xc;
            }
            uVar14 = (int32_t)uVar19 + 1;
            uVar19 = (uint64_t)uVar14;
            uVar28 = uVar28 + 1;
            iVar13 = iVar16;
        } while ((int32_t)uVar14 < (int32_t)uVar15);
    }
    if (uVar9 == 0) {
        do {
            **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(arg2 + uVar18 * 8);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 8) = uVar2;
            *(undefined4 *)(iVar20 + 0xc) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar25;
            iVar17 = (int64_t)((int32_t)uVar18 * 2);
            uVar15 = (int32_t)uVar18 + 1;
            uVar18 = (uint64_t)uVar15;
            *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x14) = *(undefined8 *)(pfVar1 + iVar17 * 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x1c) = uVar2;
            *(undefined4 *)(iVar20 + 0x20) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar26;
            *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x28) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x30) = uVar2;
            *(undefined4 *)(iVar20 + 0x34) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x38) = uVar26;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x3c;
        } while ((int32_t)uVar15 < (int32_t)uVar22);
    } else {
        iVar17 = (int64_t)iVar12;
        iVar20 = *(int64_t *)(*(int64_t *)(arg1 + 0x38) + 8);
        uVar2 = *(undefined4 *)(iVar20 + iVar17 * 0x10);
        uVar3 = *(undefined4 *)(iVar20 + 4 + iVar17 * 0x10);
        uVar4 = *(undefined4 *)(iVar20 + 8 + iVar17 * 0x10);
        uVar5 = *(undefined4 *)(iVar20 + 0xc + iVar17 * 0x10);
        do {
            iVar12 = (int32_t)uVar18;
            uVar15 = iVar12 + 1;
            uVar18 = (uint64_t)uVar15;
            iVar17 = (int64_t)(iVar12 * 2);
            **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(pfVar1 + iVar17 * 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 8) = uVar2;
            *(undefined4 *)(iVar20 + 0xc) = uVar3;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar25;
            *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x14) = *(undefined8 *)(pfVar1 + iVar17 * 2 + 2);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            *(undefined4 *)(iVar20 + 0x1c) = uVar4;
            *(undefined4 *)(iVar20 + 0x20) = uVar5;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar25;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x28;
        } while ((int32_t)uVar15 < (int32_t)uVar22);
    }
code_r0x00018012554d:
    var_c8h = (int32_t *)(arg1 + 0x34);
    *var_c8h = *var_c8h + (var_d8h._4_4_ & 0xffff);
    return;
}

// ============================================================
// Function: FUN_1801257a0
// Address: 0x1801257a0
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801257a0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    float fVar1;
    int32_t iVar2;
    uint32_t uVar3;
    bool bVar4;
    bool bVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int32_t *piVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    int32_t iVar13;
    int32_t iVar14;
    uint64_t uVar15;
    float *pfVar16;
    float in_XMM2_Da;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    
    uVar12 = arg4 & 0xffffffff;
    if (in_XMM2_Da < 0.5) {
        piVar10 = (int32_t *)(arg1 + 0x50);
        iVar6 = *(int32_t *)(arg1 + 0x54);
        if (*piVar10 == iVar6) {
            iVar13 = *piVar10 + 1;
            if (iVar6 == 0) {
                iVar6 = 8;
            } else {
                iVar6 = iVar6 / 2 + iVar6;
            }
            if (iVar13 < iVar6) {
                iVar13 = iVar6;
            }
            func_0x00018011f4f0(piVar10, iVar13);
        }
        *(undefined8 *)(*(int64_t *)(arg1 + 0x58) + (int64_t)*piVar10 * 8) = *(undefined8 *)arg2;
        *piVar10 = *piVar10 + 1;
        return;
    }
    iVar6 = fcn.180124420(arg1);
    iVar6 = (int32_t)(0x30 / (int64_t)iVar6);
    uVar11 = (uint32_t)arg4;
    if (iVar6 < 1) {
        iVar6 = 1;
        iVar7 = (int32_t)arg_28h - uVar11;
        iVar13 = -iVar7;
        if (0 < iVar7) {
            iVar13 = iVar7;
        }
    } else {
        if (0xc < iVar6) {
            iVar6 = 0xc;
        }
        iVar7 = (int32_t)arg_28h - uVar11;
        iVar13 = -iVar7;
        if (0 < iVar7) {
            iVar13 = iVar7;
        }
        bVar4 = false;
        bVar5 = false;
        if (1 < iVar6) {
            iVar14 = iVar13 / iVar6 + 1;
            iVar7 = iVar6;
            if (0 < iVar13 % iVar6) {
                iVar14 = iVar13 / iVar6 + 2;
                bVar4 = true;
                bVar5 = true;
                if (0 < iVar13) {
                    iVar7 = iVar6 - (iVar6 - iVar13 % iVar6) / 2;
                }
            }
            goto code_r0x000180125836;
        }
    }
    bVar5 = false;
    bVar4 = false;
    iVar14 = iVar13 + 1;
    iVar7 = iVar6;
code_r0x000180125836:
    iVar13 = *(int32_t *)(arg1 + 0x50);
    iVar8 = *(int32_t *)(arg1 + 0x54);
    iVar14 = iVar13 + iVar14;
    if (iVar8 < iVar14) {
        if (iVar8 == 0) {
            iVar8 = 8;
        } else {
            iVar8 = iVar8 / 2 + iVar8;
        }
        iVar2 = iVar14;
        if (iVar14 < iVar8) {
            iVar2 = iVar8;
        }
        func_0x00018011f4f0(arg1 + 0x50, iVar2);
        bVar4 = bVar5;
    }
    *(int32_t *)(arg1 + 0x50) = iVar14;
    pfVar16 = (float *)(*(int64_t *)(arg1 + 0x58) + (int64_t)iVar13 * 8);
    if (uVar11 < 0x30) {
        uVar15 = arg4 & 0xffffffff;
    } else {
        uVar9 = (int32_t)uVar11 % 0x30;
        uVar3 = uVar9 + 0x30;
        if (-1 < (int32_t)uVar9) {
            uVar3 = uVar9;
        }
        uVar15 = (uint64_t)uVar3;
    }
    if ((int32_t)arg_28h < (int32_t)uVar11) {
        do {
            iVar14 = (int32_t)uVar15;
            iVar13 = iVar14 + 0x30;
            if (-1 < iVar14) {
                iVar13 = iVar14;
            }
            uVar11 = (int32_t)uVar12 - iVar7;
            uVar12 = (uint64_t)uVar11;
            fVar1 = *(float *)(*(int64_t *)(arg1 + 0x38) + 0x74 + (int64_t)iVar13 * 8);
            uVar15 = (uint64_t)(uint32_t)(iVar13 - iVar7);
            *pfVar16 = in_XMM2_Da * *(float *)(*(int64_t *)(arg1 + 0x38) + 0x70 + (int64_t)iVar13 * 8) + *(float *)arg2;
            pfVar16[1] = fVar1 * in_XMM2_Da + *(float *)(arg2 + 4);
            pfVar16 = pfVar16 + 2;
            iVar7 = iVar6;
        } while ((int32_t)arg_28h <= (int32_t)uVar11);
    } else {
        do {
            iVar13 = (int32_t)uVar15;
            iVar14 = iVar13 + -0x30;
            if (iVar13 < 0x30) {
                iVar14 = iVar13;
            }
            uVar11 = (int32_t)uVar12 + iVar7;
            uVar12 = (uint64_t)uVar11;
            uVar15 = (uint64_t)(uint32_t)(iVar14 + iVar7);
            fVar1 = *(float *)(*(int64_t *)(arg1 + 0x38) + 0x74 + (int64_t)iVar14 * 8);
            *pfVar16 = in_XMM2_Da * *(float *)(*(int64_t *)(arg1 + 0x38) + 0x70 + (int64_t)iVar14 * 8) + *(float *)arg2;
            pfVar16[1] = fVar1 * in_XMM2_Da + *(float *)(arg2 + 4);
            pfVar16 = pfVar16 + 2;
            iVar7 = iVar6;
        } while ((int32_t)uVar11 <= (int32_t)arg_28h);
    }
    if (bVar4) {
        arg_28h._0_4_ = (int32_t)arg_28h % 0x30;
        iVar6 = (int32_t)arg_28h + 0x30;
        if (-1 < (int32_t)arg_28h) {
            iVar6 = (int32_t)arg_28h;
        }
        fVar1 = *(float *)(*(int64_t *)(arg1 + 0x38) + 0x74 + (int64_t)iVar6 * 8);
        *pfVar16 = in_XMM2_Da * *(float *)(*(int64_t *)(arg1 + 0x38) + 0x70 + (int64_t)iVar6 * 8) + *(float *)arg2;
        pfVar16[1] = fVar1 * in_XMM2_Da + *(float *)(arg2 + 4);
    }
    return;
}

// ============================================================
// Function: FUN_1801257df
// Address: 0x1801257df
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801257a0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    float fVar1;
    int32_t iVar2;
    uint32_t uVar3;
    bool bVar4;
    bool bVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int32_t *piVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    int32_t iVar13;
    int32_t iVar14;
    uint64_t uVar15;
    float *pfVar16;
    float in_XMM2_Da;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    
    uVar12 = arg4 & 0xffffffff;
    if (in_XMM2_Da < 0.5) {
        piVar10 = (int32_t *)(arg1 + 0x50);
        iVar6 = *(int32_t *)(arg1 + 0x54);
        if (*piVar10 == iVar6) {
            iVar13 = *piVar10 + 1;
            if (iVar6 == 0) {
                iVar6 = 8;
            } else {
                iVar6 = iVar6 / 2 + iVar6;
            }
            if (iVar13 < iVar6) {
                iVar13 = iVar6;
            }
            func_0x00018011f4f0(piVar10, iVar13);
        }
        *(undefined8 *)(*(int64_t *)(arg1 + 0x58) + (int64_t)*piVar10 * 8) = *(undefined8 *)arg2;
        *piVar10 = *piVar10 + 1;
        return;
    }
    iVar6 = fcn.180124420(arg1);
    iVar6 = (int32_t)(0x30 / (int64_t)iVar6);
    uVar11 = (uint32_t)arg4;
    if (iVar6 < 1) {
        iVar6 = 1;
        iVar7 = (int32_t)arg_28h - uVar11;
        iVar13 = -iVar7;
        if (0 < iVar7) {
            iVar13 = iVar7;
        }
    } else {
        if (0xc < iVar6) {
            iVar6 = 0xc;
        }
        iVar7 = (int32_t)arg_28h - uVar11;
        iVar13 = -iVar7;
        if (0 < iVar7) {
            iVar13 = iVar7;
        }
        bVar4 = false;
        bVar5 = false;
        if (1 < iVar6) {
            iVar14 = iVar13 / iVar6 + 1;
            iVar7 = iVar6;
            if (0 < iVar13 % iVar6) {
                iVar14 = iVar13 / iVar6 + 2;
                bVar4 = true;
                bVar5 = true;
                if (0 < iVar13) {
                    iVar7 = iVar6 - (iVar6 - iVar13 % iVar6) / 2;
                }
            }
            goto code_r0x000180125836;
        }
    }
    bVar5 = false;
    bVar4 = false;
    iVar14 = iVar13 + 1;
    iVar7 = iVar6;
code_r0x000180125836:
    iVar13 = *(int32_t *)(arg1 + 0x50);
    iVar8 = *(int32_t *)(arg1 + 0x54);
    iVar14 = iVar13 + iVar14;
    if (iVar8 < iVar14) {
        if (iVar8 == 0) {
            iVar8 = 8;
        } else {
            iVar8 = iVar8 / 2 + iVar8;
        }
        iVar2 = iVar14;
        if (iVar14 < iVar8) {
            iVar2 = iVar8;
        }
        func_0x00018011f4f0(arg1 + 0x50, iVar2);
        bVar4 = bVar5;
    }
    *(int32_t *)(arg1 + 0x50) = iVar14;
    pfVar16 = (float *)(*(int64_t *)(arg1 + 0x58) + (int64_t)iVar13 * 8);
    if (uVar11 < 0x30) {
        uVar15 = arg4 & 0xffffffff;
    } else {
        uVar9 = (int32_t)uVar11 % 0x30;
        uVar3 = uVar9 + 0x30;
        if (-1 < (int32_t)uVar9) {
            uVar3 = uVar9;
        }
        uVar15 = (uint64_t)uVar3;
    }
    if ((int32_t)arg_28h < (int32_t)uVar11) {
        do {
            iVar14 = (int32_t)uVar15;
            iVar13 = iVar14 + 0x30;
            if (-1 < iVar14) {
                iVar13 = iVar14;
            }
            uVar11 = (int32_t)uVar12 - iVar7;
            uVar12 = (uint64_t)uVar11;
            fVar1 = *(float *)(*(int64_t *)(arg1 + 0x38) + 0x74 + (int64_t)iVar13 * 8);
            uVar15 = (uint64_t)(uint32_t)(iVar13 - iVar7);
            *pfVar16 = in_XMM2_Da * *(float *)(*(int64_t *)(arg1 + 0x38) + 0x70 + (int64_t)iVar13 * 8) + *(float *)arg2;
            pfVar16[1] = fVar1 * in_XMM2_Da + *(float *)(arg2 + 4);
            pfVar16 = pfVar16 + 2;
            iVar7 = iVar6;
        } while ((int32_t)arg_28h <= (int32_t)uVar11);
    } else {
        do {
            iVar13 = (int32_t)uVar15;
            iVar14 = iVar13 + -0x30;
            if (iVar13 < 0x30) {
                iVar14 = iVar13;
            }
            uVar11 = (int32_t)uVar12 + iVar7;
            uVar12 = (uint64_t)uVar11;
            uVar15 = (uint64_t)(uint32_t)(iVar14 + iVar7);
            fVar1 = *(float *)(*(int64_t *)(arg1 + 0x38) + 0x74 + (int64_t)iVar14 * 8);
            *pfVar16 = in_XMM2_Da * *(float *)(*(int64_t *)(arg1 + 0x38) + 0x70 + (int64_t)iVar14 * 8) + *(float *)arg2;
            pfVar16[1] = fVar1 * in_XMM2_Da + *(float *)(arg2 + 4);
            pfVar16 = pfVar16 + 2;
            iVar7 = iVar6;
        } while ((int32_t)uVar11 <= (int32_t)arg_28h);
    }
    if (bVar4) {
        arg_28h._0_4_ = (int32_t)arg_28h % 0x30;
        iVar6 = (int32_t)arg_28h + 0x30;
        if (-1 < (int32_t)arg_28h) {
            iVar6 = (int32_t)arg_28h;
        }
        fVar1 = *(float *)(*(int64_t *)(arg1 + 0x38) + 0x74 + (int64_t)iVar6 * 8);
        *pfVar16 = in_XMM2_Da * *(float *)(*(int64_t *)(arg1 + 0x38) + 0x70 + (int64_t)iVar6 * 8) + *(float *)arg2;
        pfVar16[1] = fVar1 * in_XMM2_Da + *(float *)(arg2 + 4);
    }
    return;
}

// ============================================================
// Function: FUN_1801257f1
// Address: 0x1801257f1
// Size: 255 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801257a0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    float fVar1;
    int32_t iVar2;
    uint32_t uVar3;
    bool bVar4;
    bool bVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int32_t *piVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    int32_t iVar13;
    int32_t iVar14;
    uint64_t uVar15;
    float *pfVar16;
    float in_XMM2_Da;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    
    uVar12 = arg4 & 0xffffffff;
    if (in_XMM2_Da < 0.5) {
        piVar10 = (int32_t *)(arg1 + 0x50);
        iVar6 = *(int32_t *)(arg1 + 0x54);
        if (*piVar10 == iVar6) {
            iVar13 = *piVar10 + 1;
            if (iVar6 == 0) {
                iVar6 = 8;
            } else {
                iVar6 = iVar6 / 2 + iVar6;
            }
            if (iVar13 < iVar6) {
                iVar13 = iVar6;
            }
            func_0x00018011f4f0(piVar10, iVar13);
        }
        *(undefined8 *)(*(int64_t *)(arg1 + 0x58) + (int64_t)*piVar10 * 8) = *(undefined8 *)arg2;
        *piVar10 = *piVar10 + 1;
        return;
    }
    iVar6 = fcn.180124420(arg1);
    iVar6 = (int32_t)(0x30 / (int64_t)iVar6);
    uVar11 = (uint32_t)arg4;
    if (iVar6 < 1) {
        iVar6 = 1;
        iVar7 = (int32_t)arg_28h - uVar11;
        iVar13 = -iVar7;
        if (0 < iVar7) {
            iVar13 = iVar7;
        }
    } else {
        if (0xc < iVar6) {
            iVar6 = 0xc;
        }
        iVar7 = (int32_t)arg_28h - uVar11;
        iVar13 = -iVar7;
        if (0 < iVar7) {
            iVar13 = iVar7;
        }
        bVar4 = false;
        bVar5 = false;
        if (1 < iVar6) {
            iVar14 = iVar13 / iVar6 + 1;
            iVar7 = iVar6;
            if (0 < iVar13 % iVar6) {
                iVar14 = iVar13 / iVar6 + 2;
                bVar4 = true;
                bVar5 = true;
                if (0 < iVar13) {
                    iVar7 = iVar6 - (iVar6 - iVar13 % iVar6) / 2;
                }
            }
            goto code_r0x000180125836;
        }
    }
    bVar5 = false;
    bVar4 = false;
    iVar14 = iVar13 + 1;
    iVar7 = iVar6;
code_r0x000180125836:
    iVar13 = *(int32_t *)(arg1 + 0x50);
    iVar8 = *(int32_t *)(arg1 + 0x54);
    iVar14 = iVar13 + iVar14;
    if (iVar8 < iVar14) {
        if (iVar8 == 0) {
            iVar8 = 8;
        } else {
            iVar8 = iVar8 / 2 + iVar8;
        }
        iVar2 = iVar14;
        if (iVar14 < iVar8) {
            iVar2 = iVar8;
        }
        func_0x00018011f4f0(arg1 + 0x50, iVar2);
        bVar4 = bVar5;
    }
    *(int32_t *)(arg1 + 0x50) = iVar14;
    pfVar16 = (float *)(*(int64_t *)(arg1 + 0x58) + (int64_t)iVar13 * 8);
    if (uVar11 < 0x30) {
        uVar15 = arg4 & 0xffffffff;
    } else {
        uVar9 = (int32_t)uVar11 % 0x30;
        uVar3 = uVar9 + 0x30;
        if (-1 < (int32_t)uVar9) {
            uVar3 = uVar9;
        }
        uVar15 = (uint64_t)uVar3;
    }
    if ((int32_t)arg_28h < (int32_t)uVar11) {
        do {
            iVar14 = (int32_t)uVar15;
            iVar13 = iVar14 + 0x30;
            if (-1 < iVar14) {
                iVar13 = iVar14;
            }
            uVar11 = (int32_t)uVar12 - iVar7;
            uVar12 = (uint64_t)uVar11;
            fVar1 = *(float *)(*(int64_t *)(arg1 + 0x38) + 0x74 + (int64_t)iVar13 * 8);
            uVar15 = (uint64_t)(uint32_t)(iVar13 - iVar7);
            *pfVar16 = in_XMM2_Da * *(float *)(*(int64_t *)(arg1 + 0x38) + 0x70 + (int64_t)iVar13 * 8) + *(float *)arg2;
            pfVar16[1] = fVar1 * in_XMM2_Da + *(float *)(arg2 + 4);
            pfVar16 = pfVar16 + 2;
            iVar7 = iVar6;
        } while ((int32_t)arg_28h <= (int32_t)uVar11);
    } else {
        do {
            iVar13 = (int32_t)uVar15;
            iVar14 = iVar13 + -0x30;
            if (iVar13 < 0x30) {
                iVar14 = iVar13;
            }
            uVar11 = (int32_t)uVar12 + iVar7;
            uVar12 = (uint64_t)uVar11;
            uVar15 = (uint64_t)(uint32_t)(iVar14 + iVar7);
            fVar1 = *(float *)(*(int64_t *)(arg1 + 0x38) + 0x74 + (int64_t)iVar14 * 8);
            *pfVar16 = in_XMM2_Da * *(float *)(*(int64_t *)(arg1 + 0x38) + 0x70 + (int64_t)iVar14 * 8) + *(float *)arg2;
            pfVar16[1] = fVar1 * in_XMM2_Da + *(float *)(arg2 + 4);
            pfVar16 = pfVar16 + 2;
            iVar7 = iVar6;
        } while ((int32_t)uVar11 <= (int32_t)arg_28h);
    }
    if (bVar4) {
        arg_28h._0_4_ = (int32_t)arg_28h % 0x30;
        iVar6 = (int32_t)arg_28h + 0x30;
        if (-1 < (int32_t)arg_28h) {
            iVar6 = (int32_t)arg_28h;
        }
        fVar1 = *(float *)(*(int64_t *)(arg1 + 0x38) + 0x74 + (int64_t)iVar6 * 8);
        *pfVar16 = in_XMM2_Da * *(float *)(*(int64_t *)(arg1 + 0x38) + 0x70 + (int64_t)iVar6 * 8) + *(float *)arg2;
        pfVar16[1] = fVar1 * in_XMM2_Da + *(float *)(arg2 + 4);
    }
    return;
}

// ============================================================
// Function: FUN_1801258f0
// Address: 0x1801258f0
// Size: 219 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801257a0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    float fVar1;
    int32_t iVar2;
    uint32_t uVar3;
    bool bVar4;
    bool bVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int32_t *piVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    int32_t iVar13;
    int32_t iVar14;
    uint64_t uVar15;
    float *pfVar16;
    float in_XMM2_Da;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    
    uVar12 = arg4 & 0xffffffff;
    if (in_XMM2_Da < 0.5) {
        piVar10 = (int32_t *)(arg1 + 0x50);
        iVar6 = *(int32_t *)(arg1 + 0x54);
        if (*piVar10 == iVar6) {
            iVar13 = *piVar10 + 1;
            if (iVar6 == 0) {
                iVar6 = 8;
            } else {
                iVar6 = iVar6 / 2 + iVar6;
            }
            if (iVar13 < iVar6) {
                iVar13 = iVar6;
            }
            func_0x00018011f4f0(piVar10, iVar13);
        }
        *(undefined8 *)(*(int64_t *)(arg1 + 0x58) + (int64_t)*piVar10 * 8) = *(undefined8 *)arg2;
        *piVar10 = *piVar10 + 1;
        return;
    }
    iVar6 = fcn.180124420(arg1);
    iVar6 = (int32_t)(0x30 / (int64_t)iVar6);
    uVar11 = (uint32_t)arg4;
    if (iVar6 < 1) {
        iVar6 = 1;
        iVar7 = (int32_t)arg_28h - uVar11;
        iVar13 = -iVar7;
        if (0 < iVar7) {
            iVar13 = iVar7;
        }
    } else {
        if (0xc < iVar6) {
            iVar6 = 0xc;
        }
        iVar7 = (int32_t)arg_28h - uVar11;
        iVar13 = -iVar7;
        if (0 < iVar7) {
            iVar13 = iVar7;
        }
        bVar4 = false;
        bVar5 = false;
        if (1 < iVar6) {
            iVar14 = iVar13 / iVar6 + 1;
            iVar7 = iVar6;
            if (0 < iVar13 % iVar6) {
                iVar14 = iVar13 / iVar6 + 2;
                bVar4 = true;
                bVar5 = true;
                if (0 < iVar13) {
                    iVar7 = iVar6 - (iVar6 - iVar13 % iVar6) / 2;
                }
            }
            goto code_r0x000180125836;
        }
    }
    bVar5 = false;
    bVar4 = false;
    iVar14 = iVar13 + 1;
    iVar7 = iVar6;
code_r0x000180125836:
    iVar13 = *(int32_t *)(arg1 + 0x50);
    iVar8 = *(int32_t *)(arg1 + 0x54);
    iVar14 = iVar13 + iVar14;
    if (iVar8 < iVar14) {
        if (iVar8 == 0) {
            iVar8 = 8;
        } else {
            iVar8 = iVar8 / 2 + iVar8;
        }
        iVar2 = iVar14;
        if (iVar14 < iVar8) {
            iVar2 = iVar8;
        }
        func_0x00018011f4f0(arg1 + 0x50, iVar2);
        bVar4 = bVar5;
    }
    *(int32_t *)(arg1 + 0x50) = iVar14;
    pfVar16 = (float *)(*(int64_t *)(arg1 + 0x58) + (int64_t)iVar13 * 8);
    if (uVar11 < 0x30) {
        uVar15 = arg4 & 0xffffffff;
    } else {
        uVar9 = (int32_t)uVar11 % 0x30;
        uVar3 = uVar9 + 0x30;
        if (-1 < (int32_t)uVar9) {
            uVar3 = uVar9;
        }
        uVar15 = (uint64_t)uVar3;
    }
    if ((int32_t)arg_28h < (int32_t)uVar11) {
        do {
            iVar14 = (int32_t)uVar15;
            iVar13 = iVar14 + 0x30;
            if (-1 < iVar14) {
                iVar13 = iVar14;
            }
            uVar11 = (int32_t)uVar12 - iVar7;
            uVar12 = (uint64_t)uVar11;
            fVar1 = *(float *)(*(int64_t *)(arg1 + 0x38) + 0x74 + (int64_t)iVar13 * 8);
            uVar15 = (uint64_t)(uint32_t)(iVar13 - iVar7);
            *pfVar16 = in_XMM2_Da * *(float *)(*(int64_t *)(arg1 + 0x38) + 0x70 + (int64_t)iVar13 * 8) + *(float *)arg2;
            pfVar16[1] = fVar1 * in_XMM2_Da + *(float *)(arg2 + 4);
            pfVar16 = pfVar16 + 2;
            iVar7 = iVar6;
        } while ((int32_t)arg_28h <= (int32_t)uVar11);
    } else {
        do {
            iVar13 = (int32_t)uVar15;
            iVar14 = iVar13 + -0x30;
            if (iVar13 < 0x30) {
                iVar14 = iVar13;
            }
            uVar11 = (int32_t)uVar12 + iVar7;
            uVar12 = (uint64_t)uVar11;
            uVar15 = (uint64_t)(uint32_t)(iVar14 + iVar7);
            fVar1 = *(float *)(*(int64_t *)(arg1 + 0x38) + 0x74 + (int64_t)iVar14 * 8);
            *pfVar16 = in_XMM2_Da * *(float *)(*(int64_t *)(arg1 + 0x38) + 0x70 + (int64_t)iVar14 * 8) + *(float *)arg2;
            pfVar16[1] = fVar1 * in_XMM2_Da + *(float *)(arg2 + 4);
            pfVar16 = pfVar16 + 2;
            iVar7 = iVar6;
        } while ((int32_t)uVar11 <= (int32_t)arg_28h);
    }
    if (bVar4) {
        arg_28h._0_4_ = (int32_t)arg_28h % 0x30;
        iVar6 = (int32_t)arg_28h + 0x30;
        if (-1 < (int32_t)arg_28h) {
            iVar6 = (int32_t)arg_28h;
        }
        fVar1 = *(float *)(*(int64_t *)(arg1 + 0x38) + 0x74 + (int64_t)iVar6 * 8);
        *pfVar16 = in_XMM2_Da * *(float *)(*(int64_t *)(arg1 + 0x38) + 0x70 + (int64_t)iVar6 * 8) + *(float *)arg2;
        pfVar16[1] = fVar1 * in_XMM2_Da + *(float *)(arg2 + 4);
    }
    return;
}

// ============================================================
// Function: FUN_1801259cb
// Address: 0x1801259cb
// Size: 99 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801257a0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    float fVar1;
    int32_t iVar2;
    uint32_t uVar3;
    bool bVar4;
    bool bVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int32_t *piVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    int32_t iVar13;
    int32_t iVar14;
    uint64_t uVar15;
    float *pfVar16;
    float in_XMM2_Da;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    
    uVar12 = arg4 & 0xffffffff;
    if (in_XMM2_Da < 0.5) {
        piVar10 = (int32_t *)(arg1 + 0x50);
        iVar6 = *(int32_t *)(arg1 + 0x54);
        if (*piVar10 == iVar6) {
            iVar13 = *piVar10 + 1;
            if (iVar6 == 0) {
                iVar6 = 8;
            } else {
                iVar6 = iVar6 / 2 + iVar6;
            }
            if (iVar13 < iVar6) {
                iVar13 = iVar6;
            }
            func_0x00018011f4f0(piVar10, iVar13);
        }
        *(undefined8 *)(*(int64_t *)(arg1 + 0x58) + (int64_t)*piVar10 * 8) = *(undefined8 *)arg2;
        *piVar10 = *piVar10 + 1;
        return;
    }
    iVar6 = fcn.180124420(arg1);
    iVar6 = (int32_t)(0x30 / (int64_t)iVar6);
    uVar11 = (uint32_t)arg4;
    if (iVar6 < 1) {
        iVar6 = 1;
        iVar7 = (int32_t)arg_28h - uVar11;
        iVar13 = -iVar7;
        if (0 < iVar7) {
            iVar13 = iVar7;
        }
    } else {
        if (0xc < iVar6) {
            iVar6 = 0xc;
        }
        iVar7 = (int32_t)arg_28h - uVar11;
        iVar13 = -iVar7;
        if (0 < iVar7) {
            iVar13 = iVar7;
        }
        bVar4 = false;
        bVar5 = false;
        if (1 < iVar6) {
            iVar14 = iVar13 / iVar6 + 1;
            iVar7 = iVar6;
            if (0 < iVar13 % iVar6) {
                iVar14 = iVar13 / iVar6 + 2;
                bVar4 = true;
                bVar5 = true;
                if (0 < iVar13) {
                    iVar7 = iVar6 - (iVar6 - iVar13 % iVar6) / 2;
                }
            }
            goto code_r0x000180125836;
        }
    }
    bVar5 = false;
    bVar4 = false;
    iVar14 = iVar13 + 1;
    iVar7 = iVar6;
code_r0x000180125836:
    iVar13 = *(int32_t *)(arg1 + 0x50);
    iVar8 = *(int32_t *)(arg1 + 0x54);
    iVar14 = iVar13 + iVar14;
    if (iVar8 < iVar14) {
        if (iVar8 == 0) {
            iVar8 = 8;
        } else {
            iVar8 = iVar8 / 2 + iVar8;
        }
        iVar2 = iVar14;
        if (iVar14 < iVar8) {
            iVar2 = iVar8;
        }
        func_0x00018011f4f0(arg1 + 0x50, iVar2);
        bVar4 = bVar5;
    }
    *(int32_t *)(arg1 + 0x50) = iVar14;
    pfVar16 = (float *)(*(int64_t *)(arg1 + 0x58) + (int64_t)iVar13 * 8);
    if (uVar11 < 0x30) {
        uVar15 = arg4 & 0xffffffff;
    } else {
        uVar9 = (int32_t)uVar11 % 0x30;
        uVar3 = uVar9 + 0x30;
        if (-1 < (int32_t)uVar9) {
            uVar3 = uVar9;
        }
        uVar15 = (uint64_t)uVar3;
    }
    if ((int32_t)arg_28h < (int32_t)uVar11) {
        do {
            iVar14 = (int32_t)uVar15;
            iVar13 = iVar14 + 0x30;
            if (-1 < iVar14) {
                iVar13 = iVar14;
            }
            uVar11 = (int32_t)uVar12 - iVar7;
            uVar12 = (uint64_t)uVar11;
            fVar1 = *(float *)(*(int64_t *)(arg1 + 0x38) + 0x74 + (int64_t)iVar13 * 8);
            uVar15 = (uint64_t)(uint32_t)(iVar13 - iVar7);
            *pfVar16 = in_XMM2_Da * *(float *)(*(int64_t *)(arg1 + 0x38) + 0x70 + (int64_t)iVar13 * 8) + *(float *)arg2;
            pfVar16[1] = fVar1 * in_XMM2_Da + *(float *)(arg2 + 4);
            pfVar16 = pfVar16 + 2;
            iVar7 = iVar6;
        } while ((int32_t)arg_28h <= (int32_t)uVar11);
    } else {
        do {
            iVar13 = (int32_t)uVar15;
            iVar14 = iVar13 + -0x30;
            if (iVar13 < 0x30) {
                iVar14 = iVar13;
            }
            uVar11 = (int32_t)uVar12 + iVar7;
            uVar12 = (uint64_t)uVar11;
            uVar15 = (uint64_t)(uint32_t)(iVar14 + iVar7);
            fVar1 = *(float *)(*(int64_t *)(arg1 + 0x38) + 0x74 + (int64_t)iVar14 * 8);
            *pfVar16 = in_XMM2_Da * *(float *)(*(int64_t *)(arg1 + 0x38) + 0x70 + (int64_t)iVar14 * 8) + *(float *)arg2;
            pfVar16[1] = fVar1 * in_XMM2_Da + *(float *)(arg2 + 4);
            pfVar16 = pfVar16 + 2;
            iVar7 = iVar6;
        } while ((int32_t)uVar11 <= (int32_t)arg_28h);
    }
    if (bVar4) {
        arg_28h._0_4_ = (int32_t)arg_28h % 0x30;
        iVar6 = (int32_t)arg_28h + 0x30;
        if (-1 < (int32_t)arg_28h) {
            iVar6 = (int32_t)arg_28h;
        }
        fVar1 = *(float *)(*(int64_t *)(arg1 + 0x38) + 0x74 + (int64_t)iVar6 * 8);
        *pfVar16 = in_XMM2_Da * *(float *)(*(int64_t *)(arg1 + 0x38) + 0x70 + (int64_t)iVar6 * 8) + *(float *)arg2;
        pfVar16[1] = fVar1 * in_XMM2_Da + *(float *)(arg2 + 4);
    }
    return;
}

// ============================================================
// Function: FUN_180125a30
// Address: 0x180125a30
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

void fcn.180125a30(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h)
{
    float fVar1;
    int64_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    float fVar6;
    float fVar7;
    float in_XMM2_Da;
    float in_XMM3_Da;
    float fVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    if (0.5 <= in_XMM2_Da) {
        func_0x00018011f4f0(arg1 + 0x50, *(int32_t *)(arg1 + 0x50) + 1 + (int32_t)arg_30h);
        iVar5 = 0;
        if (-1 < (int32_t)arg_30h) {
            do {
                fVar8 = ((float)iVar5 / (float)(int32_t)arg_30h) * ((float)arg_28h - in_XMM3_Da) + in_XMM3_Da;
                fVar6 = (float)func_0x00018048ffb0(fVar8);
                fVar1 = *(float *)arg2;
                fVar7 = (float)func_0x000180493d20(fVar8);
                iVar3 = *(int32_t *)(arg1 + 0x54);
                fVar8 = *(float *)(arg2 + 4);
                if (*(int32_t *)(arg1 + 0x50) == iVar3) {
                    iVar4 = *(int32_t *)(arg1 + 0x50) + 1;
                    if (iVar3 == 0) {
                        iVar3 = 8;
                    } else {
                        iVar3 = iVar3 / 2 + iVar3;
                    }
                    if (iVar4 < iVar3) {
                        iVar4 = iVar3;
                    }
                    func_0x00018011f4f0(arg1 + 0x50, iVar4);
                }
                iVar3 = *(int32_t *)(arg1 + 0x50);
                iVar5 = iVar5 + 1;
                iVar2 = *(int64_t *)(arg1 + 0x58);
                *(float *)(iVar2 + (int64_t)iVar3 * 8) = fVar6 * in_XMM2_Da + fVar1;
                *(float *)(iVar2 + 4 + (int64_t)iVar3 * 8) = fVar7 * in_XMM2_Da + fVar8;
                *(int32_t *)(arg1 + 0x50) = *(int32_t *)(arg1 + 0x50) + 1;
            } while (iVar5 <= (int32_t)arg_30h);
        }
    } else {
        func_0x00018011f490(arg1 + 0x50);
    }
    return;
}

// ============================================================
// Function: FUN_180125a80
// Address: 0x180125a80
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

void fcn.180125a30(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h)
{
    float fVar1;
    int64_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    float fVar6;
    float fVar7;
    float in_XMM2_Da;
    float in_XMM3_Da;
    float fVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    if (0.5 <= in_XMM2_Da) {
        func_0x00018011f4f0(arg1 + 0x50, *(int32_t *)(arg1 + 0x50) + 1 + (int32_t)arg_30h);
        iVar5 = 0;
        if (-1 < (int32_t)arg_30h) {
            do {
                fVar8 = ((float)iVar5 / (float)(int32_t)arg_30h) * ((float)arg_28h - in_XMM3_Da) + in_XMM3_Da;
                fVar6 = (float)func_0x00018048ffb0(fVar8);
                fVar1 = *(float *)arg2;
                fVar7 = (float)func_0x000180493d20(fVar8);
                iVar3 = *(int32_t *)(arg1 + 0x54);
                fVar8 = *(float *)(arg2 + 4);
                if (*(int32_t *)(arg1 + 0x50) == iVar3) {
                    iVar4 = *(int32_t *)(arg1 + 0x50) + 1;
                    if (iVar3 == 0) {
                        iVar3 = 8;
                    } else {
                        iVar3 = iVar3 / 2 + iVar3;
                    }
                    if (iVar4 < iVar3) {
                        iVar4 = iVar3;
                    }
                    func_0x00018011f4f0(arg1 + 0x50, iVar4);
                }
                iVar3 = *(int32_t *)(arg1 + 0x50);
                iVar5 = iVar5 + 1;
                iVar2 = *(int64_t *)(arg1 + 0x58);
                *(float *)(iVar2 + (int64_t)iVar3 * 8) = fVar6 * in_XMM2_Da + fVar1;
                *(float *)(iVar2 + 4 + (int64_t)iVar3 * 8) = fVar7 * in_XMM2_Da + fVar8;
                *(int32_t *)(arg1 + 0x50) = *(int32_t *)(arg1 + 0x50) + 1;
            } while (iVar5 <= (int32_t)arg_30h);
        }
    } else {
        func_0x00018011f490(arg1 + 0x50);
    }
    return;
}

// ============================================================
// Function: FUN_180125aba
// Address: 0x180125aba
// Size: 205 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

void fcn.180125a30(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h)
{
    float fVar1;
    int64_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    float fVar6;
    float fVar7;
    float in_XMM2_Da;
    float in_XMM3_Da;
    float fVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    if (0.5 <= in_XMM2_Da) {
        func_0x00018011f4f0(arg1 + 0x50, *(int32_t *)(arg1 + 0x50) + 1 + (int32_t)arg_30h);
        iVar5 = 0;
        if (-1 < (int32_t)arg_30h) {
            do {
                fVar8 = ((float)iVar5 / (float)(int32_t)arg_30h) * ((float)arg_28h - in_XMM3_Da) + in_XMM3_Da;
                fVar6 = (float)func_0x00018048ffb0(fVar8);
                fVar1 = *(float *)arg2;
                fVar7 = (float)func_0x000180493d20(fVar8);
                iVar3 = *(int32_t *)(arg1 + 0x54);
                fVar8 = *(float *)(arg2 + 4);
                if (*(int32_t *)(arg1 + 0x50) == iVar3) {
                    iVar4 = *(int32_t *)(arg1 + 0x50) + 1;
                    if (iVar3 == 0) {
                        iVar3 = 8;
                    } else {
                        iVar3 = iVar3 / 2 + iVar3;
                    }
                    if (iVar4 < iVar3) {
                        iVar4 = iVar3;
                    }
                    func_0x00018011f4f0(arg1 + 0x50, iVar4);
                }
                iVar3 = *(int32_t *)(arg1 + 0x50);
                iVar5 = iVar5 + 1;
                iVar2 = *(int64_t *)(arg1 + 0x58);
                *(float *)(iVar2 + (int64_t)iVar3 * 8) = fVar6 * in_XMM2_Da + fVar1;
                *(float *)(iVar2 + 4 + (int64_t)iVar3 * 8) = fVar7 * in_XMM2_Da + fVar8;
                *(int32_t *)(arg1 + 0x50) = *(int32_t *)(arg1 + 0x50) + 1;
            } while (iVar5 <= (int32_t)arg_30h);
        }
    } else {
        func_0x00018011f490(arg1 + 0x50);
    }
    return;
}

// ============================================================
// Function: FUN_180125b87
// Address: 0x180125b87
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

void fcn.180125a30(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h)
{
    float fVar1;
    int64_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    float fVar6;
    float fVar7;
    float in_XMM2_Da;
    float in_XMM3_Da;
    float fVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    if (0.5 <= in_XMM2_Da) {
        func_0x00018011f4f0(arg1 + 0x50, *(int32_t *)(arg1 + 0x50) + 1 + (int32_t)arg_30h);
        iVar5 = 0;
        if (-1 < (int32_t)arg_30h) {
            do {
                fVar8 = ((float)iVar5 / (float)(int32_t)arg_30h) * ((float)arg_28h - in_XMM3_Da) + in_XMM3_Da;
                fVar6 = (float)func_0x00018048ffb0(fVar8);
                fVar1 = *(float *)arg2;
                fVar7 = (float)func_0x000180493d20(fVar8);
                iVar3 = *(int32_t *)(arg1 + 0x54);
                fVar8 = *(float *)(arg2 + 4);
                if (*(int32_t *)(arg1 + 0x50) == iVar3) {
                    iVar4 = *(int32_t *)(arg1 + 0x50) + 1;
                    if (iVar3 == 0) {
                        iVar3 = 8;
                    } else {
                        iVar3 = iVar3 / 2 + iVar3;
                    }
                    if (iVar4 < iVar3) {
                        iVar4 = iVar3;
                    }
                    func_0x00018011f4f0(arg1 + 0x50, iVar4);
                }
                iVar3 = *(int32_t *)(arg1 + 0x50);
                iVar5 = iVar5 + 1;
                iVar2 = *(int64_t *)(arg1 + 0x58);
                *(float *)(iVar2 + (int64_t)iVar3 * 8) = fVar6 * in_XMM2_Da + fVar1;
                *(float *)(iVar2 + 4 + (int64_t)iVar3 * 8) = fVar7 * in_XMM2_Da + fVar8;
                *(int32_t *)(arg1 + 0x50) = *(int32_t *)(arg1 + 0x50) + 1;
            } while (iVar5 <= (int32_t)arg_30h);
        }
    } else {
        func_0x00018011f490(arg1 + 0x50);
    }
    return;
}

// ============================================================
// Function: FUN_180125b9d
// Address: 0x180125b9d
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

void fcn.180125a30(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h)
{
    float fVar1;
    int64_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    float fVar6;
    float fVar7;
    float in_XMM2_Da;
    float in_XMM3_Da;
    float fVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    if (0.5 <= in_XMM2_Da) {
        func_0x00018011f4f0(arg1 + 0x50, *(int32_t *)(arg1 + 0x50) + 1 + (int32_t)arg_30h);
        iVar5 = 0;
        if (-1 < (int32_t)arg_30h) {
            do {
                fVar8 = ((float)iVar5 / (float)(int32_t)arg_30h) * ((float)arg_28h - in_XMM3_Da) + in_XMM3_Da;
                fVar6 = (float)func_0x00018048ffb0(fVar8);
                fVar1 = *(float *)arg2;
                fVar7 = (float)func_0x000180493d20(fVar8);
                iVar3 = *(int32_t *)(arg1 + 0x54);
                fVar8 = *(float *)(arg2 + 4);
                if (*(int32_t *)(arg1 + 0x50) == iVar3) {
                    iVar4 = *(int32_t *)(arg1 + 0x50) + 1;
                    if (iVar3 == 0) {
                        iVar3 = 8;
                    } else {
                        iVar3 = iVar3 / 2 + iVar3;
                    }
                    if (iVar4 < iVar3) {
                        iVar4 = iVar3;
                    }
                    func_0x00018011f4f0(arg1 + 0x50, iVar4);
                }
                iVar3 = *(int32_t *)(arg1 + 0x50);
                iVar5 = iVar5 + 1;
                iVar2 = *(int64_t *)(arg1 + 0x58);
                *(float *)(iVar2 + (int64_t)iVar3 * 8) = fVar6 * in_XMM2_Da + fVar1;
                *(float *)(iVar2 + 4 + (int64_t)iVar3 * 8) = fVar7 * in_XMM2_Da + fVar8;
                *(int32_t *)(arg1 + 0x50) = *(int32_t *)(arg1 + 0x50) + 1;
            } while (iVar5 <= (int32_t)arg_30h);
        }
    } else {
        func_0x00018011f490(arg1 + 0x50);
    }
    return;
}

// ============================================================
// Function: FUN_180125bc0
// Address: 0x180125bc0
// Size: 105 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_90h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

void fcn.180125bc0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h, int64_t arg_50h, int64_t arg_c8h)
{
    bool bVar1;
    bool bVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    float fVar7;
    float in_XMM2_Da;
    float in_XMM3_Da;
    float fVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (in_XMM2_Da < 0.5) {
        func_0x00018011f490(arg1 + 0x50);
    } else if ((int32_t)arg_30h < 1) {
        if (*(float *)(*(int64_t *)(arg1 + 0x38) + 0x1f0) < in_XMM2_Da) {
            iVar3 = fcn.180124420(arg1);
            fVar7 = (float)fcn.180471c90(((float)iVar3 * (float)((uint32_t)((float)arg_28h - in_XMM3_Da) & 0x7fffffff))
                                         / 6.283185);
            iVar3 = 1;
            if (0 < (int32_t)fVar7) {
                iVar3 = (int32_t)fVar7;
            }
            fcn.180125a30(arg1, arg2, placeholder_2, placeholder_3, CONCAT44(var_98h._4_4_, (float)arg_28h), 
                          CONCAT44(var_90h._4_4_, iVar3));
        } else {
            fVar8 = ((float)arg_28h * 48.0) / 6.283185;
            fVar7 = (in_XMM3_Da * 48.0) / 6.283185;
            if (in_XMM3_Da <= (float)arg_28h) {
                fVar7 = (float)fcn.180471c90();
                uVar6 = (uint32_t)fVar7;
                if ((0.0 <= fVar8) || ((float)(int32_t)fVar8 == fVar8)) {
                    iVar3 = (int32_t)fVar8;
                } else {
                    iVar3 = (int32_t)fVar8 + -1;
                }
                iVar5 = (int32_t)(float)iVar3;
                iVar3 = iVar5 - uVar6;
            } else {
                iVar3 = (int32_t)fVar7;
                if ((fVar7 < 0.0) && ((float)iVar3 != fVar7)) {
                    iVar3 = iVar3 + -1;
                }
                uVar6 = (uint32_t)(float)iVar3;
                fVar7 = (float)fcn.180471c90();
                iVar5 = (int32_t)fVar7;
                iVar3 = uVar6 - iVar5;
            }
            iVar4 = 0;
            if (-1 < iVar3) {
                iVar4 = iVar3;
            }
            bVar1 = 1e-05 <= (float)((uint32_t)(((float)uVar6 * 3.141593 + (float)uVar6 * 3.141593) / 48.0 - in_XMM3_Da)
                                    & 0x7fffffff);
            bVar2 = 1e-05 <= (float)((uint32_t)
                                     ((float)arg_28h - ((float)iVar5 * 3.141593 + (float)iVar5 * 3.141593) / 48.0) &
                                    0x7fffffff);
            func_0x00018011f4f0(arg1 + 0x50, (uint32_t)bVar2 + bVar1 + 1 + *(int32_t *)(arg1 + 0x50) + iVar4);
            if (bVar1) {
                fVar7 = (float)func_0x00018048ffb0();
                var_88h._0_4_ = fVar7 * in_XMM2_Da + *(float *)arg2;
                fVar7 = (float)func_0x000180493d20();
                var_88h._4_4_ = fVar7 * in_XMM2_Da + *(float *)(arg2 + 4);
                func_0x00018011f490(arg1 + 0x50, &var_88h);
            }
            if (0 < iVar4) {
                fcn.1801257a0(arg1, arg2, placeholder_2, (uint64_t)uVar6, CONCAT44(var_98h._4_4_, iVar5), 
                              CONCAT44(var_90h._4_4_, (undefined4)var_90h));
            }
            if (bVar2) {
                fVar7 = (float)func_0x00018048ffb0();
                var_88h._0_4_ = fVar7 * in_XMM2_Da + *(float *)arg2;
                fVar7 = (float)func_0x000180493d20();
                var_88h._4_4_ = fVar7 * in_XMM2_Da + *(float *)(arg2 + 4);
                func_0x00018011f490(arg1 + 0x50, &var_88h);
            }
        }
    } else {
        fcn.180125a30(arg1, arg2, placeholder_2, placeholder_3, CONCAT44(var_98h._4_4_, (float)arg_28h), 
                      CONCAT44(var_90h._4_4_, (int32_t)arg_30h));
    }
    return;
}

// ============================================================
// Function: FUN_180125c29
// Address: 0x180125c29
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_90h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

void fcn.180125bc0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h, int64_t arg_50h, int64_t arg_c8h)
{
    bool bVar1;
    bool bVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    float fVar7;
    float in_XMM2_Da;
    float in_XMM3_Da;
    float fVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (in_XMM2_Da < 0.5) {
        func_0x00018011f490(arg1 + 0x50);
    } else if ((int32_t)arg_30h < 1) {
        if (*(float *)(*(int64_t *)(arg1 + 0x38) + 0x1f0) < in_XMM2_Da) {
            iVar3 = fcn.180124420(arg1);
            fVar7 = (float)fcn.180471c90(((float)iVar3 * (float)((uint32_t)((float)arg_28h - in_XMM3_Da) & 0x7fffffff))
                                         / 6.283185);
            iVar3 = 1;
            if (0 < (int32_t)fVar7) {
                iVar3 = (int32_t)fVar7;
            }
            fcn.180125a30(arg1, arg2, placeholder_2, placeholder_3, CONCAT44(var_98h._4_4_, (float)arg_28h), 
                          CONCAT44(var_90h._4_4_, iVar3));
        } else {
            fVar8 = ((float)arg_28h * 48.0) / 6.283185;
            fVar7 = (in_XMM3_Da * 48.0) / 6.283185;
            if (in_XMM3_Da <= (float)arg_28h) {
                fVar7 = (float)fcn.180471c90();
                uVar6 = (uint32_t)fVar7;
                if ((0.0 <= fVar8) || ((float)(int32_t)fVar8 == fVar8)) {
                    iVar3 = (int32_t)fVar8;
                } else {
                    iVar3 = (int32_t)fVar8 + -1;
                }
                iVar5 = (int32_t)(float)iVar3;
                iVar3 = iVar5 - uVar6;
            } else {
                iVar3 = (int32_t)fVar7;
                if ((fVar7 < 0.0) && ((float)iVar3 != fVar7)) {
                    iVar3 = iVar3 + -1;
                }
                uVar6 = (uint32_t)(float)iVar3;
                fVar7 = (float)fcn.180471c90();
                iVar5 = (int32_t)fVar7;
                iVar3 = uVar6 - iVar5;
            }
            iVar4 = 0;
            if (-1 < iVar3) {
                iVar4 = iVar3;
            }
            bVar1 = 1e-05 <= (float)((uint32_t)(((float)uVar6 * 3.141593 + (float)uVar6 * 3.141593) / 48.0 - in_XMM3_Da)
                                    & 0x7fffffff);
            bVar2 = 1e-05 <= (float)((uint32_t)
                                     ((float)arg_28h - ((float)iVar5 * 3.141593 + (float)iVar5 * 3.141593) / 48.0) &
                                    0x7fffffff);
            func_0x00018011f4f0(arg1 + 0x50, (uint32_t)bVar2 + bVar1 + 1 + *(int32_t *)(arg1 + 0x50) + iVar4);
            if (bVar1) {
                fVar7 = (float)func_0x00018048ffb0();
                var_88h._0_4_ = fVar7 * in_XMM2_Da + *(float *)arg2;
                fVar7 = (float)func_0x000180493d20();
                var_88h._4_4_ = fVar7 * in_XMM2_Da + *(float *)(arg2 + 4);
                func_0x00018011f490(arg1 + 0x50, &var_88h);
            }
            if (0 < iVar4) {
                fcn.1801257a0(arg1, arg2, placeholder_2, (uint64_t)uVar6, CONCAT44(var_98h._4_4_, iVar5), 
                              CONCAT44(var_90h._4_4_, (undefined4)var_90h));
            }
            if (bVar2) {
                fVar7 = (float)func_0x00018048ffb0();
                var_88h._0_4_ = fVar7 * in_XMM2_Da + *(float *)arg2;
                fVar7 = (float)func_0x000180493d20();
                var_88h._4_4_ = fVar7 * in_XMM2_Da + *(float *)(arg2 + 4);
                func_0x00018011f490(arg1 + 0x50, &var_88h);
            }
        }
    } else {
        fcn.180125a30(arg1, arg2, placeholder_2, placeholder_3, CONCAT44(var_98h._4_4_, (float)arg_28h), 
                      CONCAT44(var_90h._4_4_, (int32_t)arg_30h));
    }
    return;
}

// ============================================================
// Function: FUN_180125c42
// Address: 0x180125c42
// Size: 394 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_90h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

void fcn.180125bc0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h, int64_t arg_50h, int64_t arg_c8h)
{
    bool bVar1;
    bool bVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    float fVar7;
    float in_XMM2_Da;
    float in_XMM3_Da;
    float fVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (in_XMM2_Da < 0.5) {
        func_0x00018011f490(arg1 + 0x50);
    } else if ((int32_t)arg_30h < 1) {
        if (*(float *)(*(int64_t *)(arg1 + 0x38) + 0x1f0) < in_XMM2_Da) {
            iVar3 = fcn.180124420(arg1);
            fVar7 = (float)fcn.180471c90(((float)iVar3 * (float)((uint32_t)((float)arg_28h - in_XMM3_Da) & 0x7fffffff))
                                         / 6.283185);
            iVar3 = 1;
            if (0 < (int32_t)fVar7) {
                iVar3 = (int32_t)fVar7;
            }
            fcn.180125a30(arg1, arg2, placeholder_2, placeholder_3, CONCAT44(var_98h._4_4_, (float)arg_28h), 
                          CONCAT44(var_90h._4_4_, iVar3));
        } else {
            fVar8 = ((float)arg_28h * 48.0) / 6.283185;
            fVar7 = (in_XMM3_Da * 48.0) / 6.283185;
            if (in_XMM3_Da <= (float)arg_28h) {
                fVar7 = (float)fcn.180471c90();
                uVar6 = (uint32_t)fVar7;
                if ((0.0 <= fVar8) || ((float)(int32_t)fVar8 == fVar8)) {
                    iVar3 = (int32_t)fVar8;
                } else {
                    iVar3 = (int32_t)fVar8 + -1;
                }
                iVar5 = (int32_t)(float)iVar3;
                iVar3 = iVar5 - uVar6;
            } else {
                iVar3 = (int32_t)fVar7;
                if ((fVar7 < 0.0) && ((float)iVar3 != fVar7)) {
                    iVar3 = iVar3 + -1;
                }
                uVar6 = (uint32_t)(float)iVar3;
                fVar7 = (float)fcn.180471c90();
                iVar5 = (int32_t)fVar7;
                iVar3 = uVar6 - iVar5;
            }
            iVar4 = 0;
            if (-1 < iVar3) {
                iVar4 = iVar3;
            }
            bVar1 = 1e-05 <= (float)((uint32_t)(((float)uVar6 * 3.141593 + (float)uVar6 * 3.141593) / 48.0 - in_XMM3_Da)
                                    & 0x7fffffff);
            bVar2 = 1e-05 <= (float)((uint32_t)
                                     ((float)arg_28h - ((float)iVar5 * 3.141593 + (float)iVar5 * 3.141593) / 48.0) &
                                    0x7fffffff);
            func_0x00018011f4f0(arg1 + 0x50, (uint32_t)bVar2 + bVar1 + 1 + *(int32_t *)(arg1 + 0x50) + iVar4);
            if (bVar1) {
                fVar7 = (float)func_0x00018048ffb0();
                var_88h._0_4_ = fVar7 * in_XMM2_Da + *(float *)arg2;
                fVar7 = (float)func_0x000180493d20();
                var_88h._4_4_ = fVar7 * in_XMM2_Da + *(float *)(arg2 + 4);
                func_0x00018011f490(arg1 + 0x50, &var_88h);
            }
            if (0 < iVar4) {
                fcn.1801257a0(arg1, arg2, placeholder_2, (uint64_t)uVar6, CONCAT44(var_98h._4_4_, iVar5), 
                              CONCAT44(var_90h._4_4_, (undefined4)var_90h));
            }
            if (bVar2) {
                fVar7 = (float)func_0x00018048ffb0();
                var_88h._0_4_ = fVar7 * in_XMM2_Da + *(float *)arg2;
                fVar7 = (float)func_0x000180493d20();
                var_88h._4_4_ = fVar7 * in_XMM2_Da + *(float *)(arg2 + 4);
                func_0x00018011f490(arg1 + 0x50, &var_88h);
            }
        }
    } else {
        fcn.180125a30(arg1, arg2, placeholder_2, placeholder_3, CONCAT44(var_98h._4_4_, (float)arg_28h), 
                      CONCAT44(var_90h._4_4_, (int32_t)arg_30h));
    }
    return;
}

// ============================================================
// Function: FUN_180125dcc
// Address: 0x180125dcc
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_90h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

void fcn.180125bc0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h, int64_t arg_50h, int64_t arg_c8h)
{
    bool bVar1;
    bool bVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    float fVar7;
    float in_XMM2_Da;
    float in_XMM3_Da;
    float fVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (in_XMM2_Da < 0.5) {
        func_0x00018011f490(arg1 + 0x50);
    } else if ((int32_t)arg_30h < 1) {
        if (*(float *)(*(int64_t *)(arg1 + 0x38) + 0x1f0) < in_XMM2_Da) {
            iVar3 = fcn.180124420(arg1);
            fVar7 = (float)fcn.180471c90(((float)iVar3 * (float)((uint32_t)((float)arg_28h - in_XMM3_Da) & 0x7fffffff))
                                         / 6.283185);
            iVar3 = 1;
            if (0 < (int32_t)fVar7) {
                iVar3 = (int32_t)fVar7;
            }
            fcn.180125a30(arg1, arg2, placeholder_2, placeholder_3, CONCAT44(var_98h._4_4_, (float)arg_28h), 
                          CONCAT44(var_90h._4_4_, iVar3));
        } else {
            fVar8 = ((float)arg_28h * 48.0) / 6.283185;
            fVar7 = (in_XMM3_Da * 48.0) / 6.283185;
            if (in_XMM3_Da <= (float)arg_28h) {
                fVar7 = (float)fcn.180471c90();
                uVar6 = (uint32_t)fVar7;
                if ((0.0 <= fVar8) || ((float)(int32_t)fVar8 == fVar8)) {
                    iVar3 = (int32_t)fVar8;
                } else {
                    iVar3 = (int32_t)fVar8 + -1;
                }
                iVar5 = (int32_t)(float)iVar3;
                iVar3 = iVar5 - uVar6;
            } else {
                iVar3 = (int32_t)fVar7;
                if ((fVar7 < 0.0) && ((float)iVar3 != fVar7)) {
                    iVar3 = iVar3 + -1;
                }
                uVar6 = (uint32_t)(float)iVar3;
                fVar7 = (float)fcn.180471c90();
                iVar5 = (int32_t)fVar7;
                iVar3 = uVar6 - iVar5;
            }
            iVar4 = 0;
            if (-1 < iVar3) {
                iVar4 = iVar3;
            }
            bVar1 = 1e-05 <= (float)((uint32_t)(((float)uVar6 * 3.141593 + (float)uVar6 * 3.141593) / 48.0 - in_XMM3_Da)
                                    & 0x7fffffff);
            bVar2 = 1e-05 <= (float)((uint32_t)
                                     ((float)arg_28h - ((float)iVar5 * 3.141593 + (float)iVar5 * 3.141593) / 48.0) &
                                    0x7fffffff);
            func_0x00018011f4f0(arg1 + 0x50, (uint32_t)bVar2 + bVar1 + 1 + *(int32_t *)(arg1 + 0x50) + iVar4);
            if (bVar1) {
                fVar7 = (float)func_0x00018048ffb0();
                var_88h._0_4_ = fVar7 * in_XMM2_Da + *(float *)arg2;
                fVar7 = (float)func_0x000180493d20();
                var_88h._4_4_ = fVar7 * in_XMM2_Da + *(float *)(arg2 + 4);
                func_0x00018011f490(arg1 + 0x50, &var_88h);
            }
            if (0 < iVar4) {
                fcn.1801257a0(arg1, arg2, placeholder_2, (uint64_t)uVar6, CONCAT44(var_98h._4_4_, iVar5), 
                              CONCAT44(var_90h._4_4_, (undefined4)var_90h));
            }
            if (bVar2) {
                fVar7 = (float)func_0x00018048ffb0();
                var_88h._0_4_ = fVar7 * in_XMM2_Da + *(float *)arg2;
                fVar7 = (float)func_0x000180493d20();
                var_88h._4_4_ = fVar7 * in_XMM2_Da + *(float *)(arg2 + 4);
                func_0x00018011f490(arg1 + 0x50, &var_88h);
            }
        }
    } else {
        fcn.180125a30(arg1, arg2, placeholder_2, placeholder_3, CONCAT44(var_98h._4_4_, (float)arg_28h), 
                      CONCAT44(var_90h._4_4_, (int32_t)arg_30h));
    }
    return;
}

// ============================================================
// Function: FUN_180125e15
// Address: 0x180125e15
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_90h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

void fcn.180125bc0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h, int64_t arg_50h, int64_t arg_c8h)
{
    bool bVar1;
    bool bVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    float fVar7;
    float in_XMM2_Da;
    float in_XMM3_Da;
    float fVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (in_XMM2_Da < 0.5) {
        func_0x00018011f490(arg1 + 0x50);
    } else if ((int32_t)arg_30h < 1) {
        if (*(float *)(*(int64_t *)(arg1 + 0x38) + 0x1f0) < in_XMM2_Da) {
            iVar3 = fcn.180124420(arg1);
            fVar7 = (float)fcn.180471c90(((float)iVar3 * (float)((uint32_t)((float)arg_28h - in_XMM3_Da) & 0x7fffffff))
                                         / 6.283185);
            iVar3 = 1;
            if (0 < (int32_t)fVar7) {
                iVar3 = (int32_t)fVar7;
            }
            fcn.180125a30(arg1, arg2, placeholder_2, placeholder_3, CONCAT44(var_98h._4_4_, (float)arg_28h), 
                          CONCAT44(var_90h._4_4_, iVar3));
        } else {
            fVar8 = ((float)arg_28h * 48.0) / 6.283185;
            fVar7 = (in_XMM3_Da * 48.0) / 6.283185;
            if (in_XMM3_Da <= (float)arg_28h) {
                fVar7 = (float)fcn.180471c90();
                uVar6 = (uint32_t)fVar7;
                if ((0.0 <= fVar8) || ((float)(int32_t)fVar8 == fVar8)) {
                    iVar3 = (int32_t)fVar8;
                } else {
                    iVar3 = (int32_t)fVar8 + -1;
                }
                iVar5 = (int32_t)(float)iVar3;
                iVar3 = iVar5 - uVar6;
            } else {
                iVar3 = (int32_t)fVar7;
                if ((fVar7 < 0.0) && ((float)iVar3 != fVar7)) {
                    iVar3 = iVar3 + -1;
                }
                uVar6 = (uint32_t)(float)iVar3;
                fVar7 = (float)fcn.180471c90();
                iVar5 = (int32_t)fVar7;
                iVar3 = uVar6 - iVar5;
            }
            iVar4 = 0;
            if (-1 < iVar3) {
                iVar4 = iVar3;
            }
            bVar1 = 1e-05 <= (float)((uint32_t)(((float)uVar6 * 3.141593 + (float)uVar6 * 3.141593) / 48.0 - in_XMM3_Da)
                                    & 0x7fffffff);
            bVar2 = 1e-05 <= (float)((uint32_t)
                                     ((float)arg_28h - ((float)iVar5 * 3.141593 + (float)iVar5 * 3.141593) / 48.0) &
                                    0x7fffffff);
            func_0x00018011f4f0(arg1 + 0x50, (uint32_t)bVar2 + bVar1 + 1 + *(int32_t *)(arg1 + 0x50) + iVar4);
            if (bVar1) {
                fVar7 = (float)func_0x00018048ffb0();
                var_88h._0_4_ = fVar7 * in_XMM2_Da + *(float *)arg2;
                fVar7 = (float)func_0x000180493d20();
                var_88h._4_4_ = fVar7 * in_XMM2_Da + *(float *)(arg2 + 4);
                func_0x00018011f490(arg1 + 0x50, &var_88h);
            }
            if (0 < iVar4) {
                fcn.1801257a0(arg1, arg2, placeholder_2, (uint64_t)uVar6, CONCAT44(var_98h._4_4_, iVar5), 
                              CONCAT44(var_90h._4_4_, (undefined4)var_90h));
            }
            if (bVar2) {
                fVar7 = (float)func_0x00018048ffb0();
                var_88h._0_4_ = fVar7 * in_XMM2_Da + *(float *)arg2;
                fVar7 = (float)func_0x000180493d20();
                var_88h._4_4_ = fVar7 * in_XMM2_Da + *(float *)(arg2 + 4);
                func_0x00018011f490(arg1 + 0x50, &var_88h);
            }
        }
    } else {
        fcn.180125a30(arg1, arg2, placeholder_2, placeholder_3, CONCAT44(var_98h._4_4_, (float)arg_28h), 
                      CONCAT44(var_90h._4_4_, (int32_t)arg_30h));
    }
    return;
}

// ============================================================
// Function: FUN_180125e48
// Address: 0x180125e48
// Size: 75 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_90h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

void fcn.180125bc0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h, int64_t arg_50h, int64_t arg_c8h)
{
    bool bVar1;
    bool bVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    float fVar7;
    float in_XMM2_Da;
    float in_XMM3_Da;
    float fVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (in_XMM2_Da < 0.5) {
        func_0x00018011f490(arg1 + 0x50);
    } else if ((int32_t)arg_30h < 1) {
        if (*(float *)(*(int64_t *)(arg1 + 0x38) + 0x1f0) < in_XMM2_Da) {
            iVar3 = fcn.180124420(arg1);
            fVar7 = (float)fcn.180471c90(((float)iVar3 * (float)((uint32_t)((float)arg_28h - in_XMM3_Da) & 0x7fffffff))
                                         / 6.283185);
            iVar3 = 1;
            if (0 < (int32_t)fVar7) {
                iVar3 = (int32_t)fVar7;
            }
            fcn.180125a30(arg1, arg2, placeholder_2, placeholder_3, CONCAT44(var_98h._4_4_, (float)arg_28h), 
                          CONCAT44(var_90h._4_4_, iVar3));
        } else {
            fVar8 = ((float)arg_28h * 48.0) / 6.283185;
            fVar7 = (in_XMM3_Da * 48.0) / 6.283185;
            if (in_XMM3_Da <= (float)arg_28h) {
                fVar7 = (float)fcn.180471c90();
                uVar6 = (uint32_t)fVar7;
                if ((0.0 <= fVar8) || ((float)(int32_t)fVar8 == fVar8)) {
                    iVar3 = (int32_t)fVar8;
                } else {
                    iVar3 = (int32_t)fVar8 + -1;
                }
                iVar5 = (int32_t)(float)iVar3;
                iVar3 = iVar5 - uVar6;
            } else {
                iVar3 = (int32_t)fVar7;
                if ((fVar7 < 0.0) && ((float)iVar3 != fVar7)) {
                    iVar3 = iVar3 + -1;
                }
                uVar6 = (uint32_t)(float)iVar3;
                fVar7 = (float)fcn.180471c90();
                iVar5 = (int32_t)fVar7;
                iVar3 = uVar6 - iVar5;
            }
            iVar4 = 0;
            if (-1 < iVar3) {
                iVar4 = iVar3;
            }
            bVar1 = 1e-05 <= (float)((uint32_t)(((float)uVar6 * 3.141593 + (float)uVar6 * 3.141593) / 48.0 - in_XMM3_Da)
                                    & 0x7fffffff);
            bVar2 = 1e-05 <= (float)((uint32_t)
                                     ((float)arg_28h - ((float)iVar5 * 3.141593 + (float)iVar5 * 3.141593) / 48.0) &
                                    0x7fffffff);
            func_0x00018011f4f0(arg1 + 0x50, (uint32_t)bVar2 + bVar1 + 1 + *(int32_t *)(arg1 + 0x50) + iVar4);
            if (bVar1) {
                fVar7 = (float)func_0x00018048ffb0();
                var_88h._0_4_ = fVar7 * in_XMM2_Da + *(float *)arg2;
                fVar7 = (float)func_0x000180493d20();
                var_88h._4_4_ = fVar7 * in_XMM2_Da + *(float *)(arg2 + 4);
                func_0x00018011f490(arg1 + 0x50, &var_88h);
            }
            if (0 < iVar4) {
                fcn.1801257a0(arg1, arg2, placeholder_2, (uint64_t)uVar6, CONCAT44(var_98h._4_4_, iVar5), 
                              CONCAT44(var_90h._4_4_, (undefined4)var_90h));
            }
            if (bVar2) {
                fVar7 = (float)func_0x00018048ffb0();
                var_88h._0_4_ = fVar7 * in_XMM2_Da + *(float *)arg2;
                fVar7 = (float)func_0x000180493d20();
                var_88h._4_4_ = fVar7 * in_XMM2_Da + *(float *)(arg2 + 4);
                func_0x00018011f490(arg1 + 0x50, &var_88h);
            }
        }
    } else {
        fcn.180125a30(arg1, arg2, placeholder_2, placeholder_3, CONCAT44(var_98h._4_4_, (float)arg_28h), 
                      CONCAT44(var_90h._4_4_, (int32_t)arg_30h));
    }
    return;
}

// ============================================================
// Function: FUN_180125e93
// Address: 0x180125e93
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_90h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

void fcn.180125bc0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h, int64_t arg_50h, int64_t arg_c8h)
{
    bool bVar1;
    bool bVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    float fVar7;
    float in_XMM2_Da;
    float in_XMM3_Da;
    float fVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (in_XMM2_Da < 0.5) {
        func_0x00018011f490(arg1 + 0x50);
    } else if ((int32_t)arg_30h < 1) {
        if (*(float *)(*(int64_t *)(arg1 + 0x38) + 0x1f0) < in_XMM2_Da) {
            iVar3 = fcn.180124420(arg1);
            fVar7 = (float)fcn.180471c90(((float)iVar3 * (float)((uint32_t)((float)arg_28h - in_XMM3_Da) & 0x7fffffff))
                                         / 6.283185);
            iVar3 = 1;
            if (0 < (int32_t)fVar7) {
                iVar3 = (int32_t)fVar7;
            }
            fcn.180125a30(arg1, arg2, placeholder_2, placeholder_3, CONCAT44(var_98h._4_4_, (float)arg_28h), 
                          CONCAT44(var_90h._4_4_, iVar3));
        } else {
            fVar8 = ((float)arg_28h * 48.0) / 6.283185;
            fVar7 = (in_XMM3_Da * 48.0) / 6.283185;
            if (in_XMM3_Da <= (float)arg_28h) {
                fVar7 = (float)fcn.180471c90();
                uVar6 = (uint32_t)fVar7;
                if ((0.0 <= fVar8) || ((float)(int32_t)fVar8 == fVar8)) {
                    iVar3 = (int32_t)fVar8;
                } else {
                    iVar3 = (int32_t)fVar8 + -1;
                }
                iVar5 = (int32_t)(float)iVar3;
                iVar3 = iVar5 - uVar6;
            } else {
                iVar3 = (int32_t)fVar7;
                if ((fVar7 < 0.0) && ((float)iVar3 != fVar7)) {
                    iVar3 = iVar3 + -1;
                }
                uVar6 = (uint32_t)(float)iVar3;
                fVar7 = (float)fcn.180471c90();
                iVar5 = (int32_t)fVar7;
                iVar3 = uVar6 - iVar5;
            }
            iVar4 = 0;
            if (-1 < iVar3) {
                iVar4 = iVar3;
            }
            bVar1 = 1e-05 <= (float)((uint32_t)(((float)uVar6 * 3.141593 + (float)uVar6 * 3.141593) / 48.0 - in_XMM3_Da)
                                    & 0x7fffffff);
            bVar2 = 1e-05 <= (float)((uint32_t)
                                     ((float)arg_28h - ((float)iVar5 * 3.141593 + (float)iVar5 * 3.141593) / 48.0) &
                                    0x7fffffff);
            func_0x00018011f4f0(arg1 + 0x50, (uint32_t)bVar2 + bVar1 + 1 + *(int32_t *)(arg1 + 0x50) + iVar4);
            if (bVar1) {
                fVar7 = (float)func_0x00018048ffb0();
                var_88h._0_4_ = fVar7 * in_XMM2_Da + *(float *)arg2;
                fVar7 = (float)func_0x000180493d20();
                var_88h._4_4_ = fVar7 * in_XMM2_Da + *(float *)(arg2 + 4);
                func_0x00018011f490(arg1 + 0x50, &var_88h);
            }
            if (0 < iVar4) {
                fcn.1801257a0(arg1, arg2, placeholder_2, (uint64_t)uVar6, CONCAT44(var_98h._4_4_, iVar5), 
                              CONCAT44(var_90h._4_4_, (undefined4)var_90h));
            }
            if (bVar2) {
                fVar7 = (float)func_0x00018048ffb0();
                var_88h._0_4_ = fVar7 * in_XMM2_Da + *(float *)arg2;
                fVar7 = (float)func_0x000180493d20();
                var_88h._4_4_ = fVar7 * in_XMM2_Da + *(float *)(arg2 + 4);
                func_0x00018011f490(arg1 + 0x50, &var_88h);
            }
        }
    } else {
        fcn.180125a30(arg1, arg2, placeholder_2, placeholder_3, CONCAT44(var_98h._4_4_, (float)arg_28h), 
                      CONCAT44(var_90h._4_4_, (int32_t)arg_30h));
    }
    return;
}

// ============================================================
// Function: FUN_180125e9b
// Address: 0x180125e9b
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_90h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

void fcn.180125bc0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h, int64_t arg_50h, int64_t arg_c8h)
{
    bool bVar1;
    bool bVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    float fVar7;
    float in_XMM2_Da;
    float in_XMM3_Da;
    float fVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (in_XMM2_Da < 0.5) {
        func_0x00018011f490(arg1 + 0x50);
    } else if ((int32_t)arg_30h < 1) {
        if (*(float *)(*(int64_t *)(arg1 + 0x38) + 0x1f0) < in_XMM2_Da) {
            iVar3 = fcn.180124420(arg1);
            fVar7 = (float)fcn.180471c90(((float)iVar3 * (float)((uint32_t)((float)arg_28h - in_XMM3_Da) & 0x7fffffff))
                                         / 6.283185);
            iVar3 = 1;
            if (0 < (int32_t)fVar7) {
                iVar3 = (int32_t)fVar7;
            }
            fcn.180125a30(arg1, arg2, placeholder_2, placeholder_3, CONCAT44(var_98h._4_4_, (float)arg_28h), 
                          CONCAT44(var_90h._4_4_, iVar3));
        } else {
            fVar8 = ((float)arg_28h * 48.0) / 6.283185;
            fVar7 = (in_XMM3_Da * 48.0) / 6.283185;
            if (in_XMM3_Da <= (float)arg_28h) {
                fVar7 = (float)fcn.180471c90();
                uVar6 = (uint32_t)fVar7;
                if ((0.0 <= fVar8) || ((float)(int32_t)fVar8 == fVar8)) {
                    iVar3 = (int32_t)fVar8;
                } else {
                    iVar3 = (int32_t)fVar8 + -1;
                }
                iVar5 = (int32_t)(float)iVar3;
                iVar3 = iVar5 - uVar6;
            } else {
                iVar3 = (int32_t)fVar7;
                if ((fVar7 < 0.0) && ((float)iVar3 != fVar7)) {
                    iVar3 = iVar3 + -1;
                }
                uVar6 = (uint32_t)(float)iVar3;
                fVar7 = (float)fcn.180471c90();
                iVar5 = (int32_t)fVar7;
                iVar3 = uVar6 - iVar5;
            }
            iVar4 = 0;
            if (-1 < iVar3) {
                iVar4 = iVar3;
            }
            bVar1 = 1e-05 <= (float)((uint32_t)(((float)uVar6 * 3.141593 + (float)uVar6 * 3.141593) / 48.0 - in_XMM3_Da)
                                    & 0x7fffffff);
            bVar2 = 1e-05 <= (float)((uint32_t)
                                     ((float)arg_28h - ((float)iVar5 * 3.141593 + (float)iVar5 * 3.141593) / 48.0) &
                                    0x7fffffff);
            func_0x00018011f4f0(arg1 + 0x50, (uint32_t)bVar2 + bVar1 + 1 + *(int32_t *)(arg1 + 0x50) + iVar4);
            if (bVar1) {
                fVar7 = (float)func_0x00018048ffb0();
                var_88h._0_4_ = fVar7 * in_XMM2_Da + *(float *)arg2;
                fVar7 = (float)func_0x000180493d20();
                var_88h._4_4_ = fVar7 * in_XMM2_Da + *(float *)(arg2 + 4);
                func_0x00018011f490(arg1 + 0x50, &var_88h);
            }
            if (0 < iVar4) {
                fcn.1801257a0(arg1, arg2, placeholder_2, (uint64_t)uVar6, CONCAT44(var_98h._4_4_, iVar5), 
                              CONCAT44(var_90h._4_4_, (undefined4)var_90h));
            }
            if (bVar2) {
                fVar7 = (float)func_0x00018048ffb0();
                var_88h._0_4_ = fVar7 * in_XMM2_Da + *(float *)arg2;
                fVar7 = (float)func_0x000180493d20();
                var_88h._4_4_ = fVar7 * in_XMM2_Da + *(float *)(arg2 + 4);
                func_0x00018011f490(arg1 + 0x50, &var_88h);
            }
        }
    } else {
        fcn.180125a30(arg1, arg2, placeholder_2, placeholder_3, CONCAT44(var_98h._4_4_, (float)arg_28h), 
                      CONCAT44(var_90h._4_4_, (int32_t)arg_30h));
    }
    return;
}

// ============================================================
// Function: FUN_180125eb0
// Address: 0x180125eb0
// Size: 103 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_90h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

void fcn.180125bc0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h, int64_t arg_50h, int64_t arg_c8h)
{
    bool bVar1;
    bool bVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    float fVar7;
    float in_XMM2_Da;
    float in_XMM3_Da;
    float fVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (in_XMM2_Da < 0.5) {
        func_0x00018011f490(arg1 + 0x50);
    } else if ((int32_t)arg_30h < 1) {
        if (*(float *)(*(int64_t *)(arg1 + 0x38) + 0x1f0) < in_XMM2_Da) {
            iVar3 = fcn.180124420(arg1);
            fVar7 = (float)fcn.180471c90(((float)iVar3 * (float)((uint32_t)((float)arg_28h - in_XMM3_Da) & 0x7fffffff))
                                         / 6.283185);
            iVar3 = 1;
            if (0 < (int32_t)fVar7) {
                iVar3 = (int32_t)fVar7;
            }
            fcn.180125a30(arg1, arg2, placeholder_2, placeholder_3, CONCAT44(var_98h._4_4_, (float)arg_28h), 
                          CONCAT44(var_90h._4_4_, iVar3));
        } else {
            fVar8 = ((float)arg_28h * 48.0) / 6.283185;
            fVar7 = (in_XMM3_Da * 48.0) / 6.283185;
            if (in_XMM3_Da <= (float)arg_28h) {
                fVar7 = (float)fcn.180471c90();
                uVar6 = (uint32_t)fVar7;
                if ((0.0 <= fVar8) || ((float)(int32_t)fVar8 == fVar8)) {
                    iVar3 = (int32_t)fVar8;
                } else {
                    iVar3 = (int32_t)fVar8 + -1;
                }
                iVar5 = (int32_t)(float)iVar3;
                iVar3 = iVar5 - uVar6;
            } else {
                iVar3 = (int32_t)fVar7;
                if ((fVar7 < 0.0) && ((float)iVar3 != fVar7)) {
                    iVar3 = iVar3 + -1;
                }
                uVar6 = (uint32_t)(float)iVar3;
                fVar7 = (float)fcn.180471c90();
                iVar5 = (int32_t)fVar7;
                iVar3 = uVar6 - iVar5;
            }
            iVar4 = 0;
            if (-1 < iVar3) {
                iVar4 = iVar3;
            }
            bVar1 = 1e-05 <= (float)((uint32_t)(((float)uVar6 * 3.141593 + (float)uVar6 * 3.141593) / 48.0 - in_XMM3_Da)
                                    & 0x7fffffff);
            bVar2 = 1e-05 <= (float)((uint32_t)
                                     ((float)arg_28h - ((float)iVar5 * 3.141593 + (float)iVar5 * 3.141593) / 48.0) &
                                    0x7fffffff);
            func_0x00018011f4f0(arg1 + 0x50, (uint32_t)bVar2 + bVar1 + 1 + *(int32_t *)(arg1 + 0x50) + iVar4);
            if (bVar1) {
                fVar7 = (float)func_0x00018048ffb0();
                var_88h._0_4_ = fVar7 * in_XMM2_Da + *(float *)arg2;
                fVar7 = (float)func_0x000180493d20();
                var_88h._4_4_ = fVar7 * in_XMM2_Da + *(float *)(arg2 + 4);
                func_0x00018011f490(arg1 + 0x50, &var_88h);
            }
            if (0 < iVar4) {
                fcn.1801257a0(arg1, arg2, placeholder_2, (uint64_t)uVar6, CONCAT44(var_98h._4_4_, iVar5), 
                              CONCAT44(var_90h._4_4_, (undefined4)var_90h));
            }
            if (bVar2) {
                fVar7 = (float)func_0x00018048ffb0();
                var_88h._0_4_ = fVar7 * in_XMM2_Da + *(float *)arg2;
                fVar7 = (float)func_0x000180493d20();
                var_88h._4_4_ = fVar7 * in_XMM2_Da + *(float *)(arg2 + 4);
                func_0x00018011f490(arg1 + 0x50, &var_88h);
            }
        }
    } else {
        fcn.180125a30(arg1, arg2, placeholder_2, placeholder_3, CONCAT44(var_98h._4_4_, (float)arg_28h), 
                      CONCAT44(var_90h._4_4_, (int32_t)arg_30h));
    }
    return;
}

// ============================================================
// Function: FUN_180125f20
// Address: 0x180125f20
// Size: 271 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

void fcn.180125f20(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    int32_t *piVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    uint32_t uVar4;
    uint8_t uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    float fVar10;
    float in_XMM3_Da;
    float fVar11;
    float fVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_68h;
    int64_t in_stack_ffffffffffffffa0;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    uVar4 = (uint32_t)arg_28h;
    if (0.5 <= in_XMM3_Da) {
        uVar4 = (uint32_t)arg_28h | 0xf0;
        if ((arg_28h & 0x1f0U) != 0) {
            uVar4 = (uint32_t)arg_28h;
        }
        uVar5 = (uint8_t)uVar4;
        if ((uVar5 & 0x30) == 0x30 || (uVar5 & 0xc0) == 0xc0) {
            fVar10 = 0.5;
        } else {
            fVar10 = 1.0;
        }
        fVar10 = (float)((uint32_t)(*(float *)arg3 - *(float *)arg2) & 0x7fffffff) * fVar10 - 1.0;
        if (fVar10 <= in_XMM3_Da) {
            in_XMM3_Da = fVar10;
        }
        if ((uVar5 & 0x50) == 0x50 || (uVar5 & 0xa0) == 0xa0) {
            fVar10 = 0.5;
        } else {
            fVar10 = 1.0;
        }
        fVar10 = (float)((uint32_t)(*(float *)(arg3 + 4) - *(float *)(arg2 + 4)) & 0x7fffffff) * fVar10 - 1.0;
        if (fVar10 <= in_XMM3_Da) {
            in_XMM3_Da = fVar10;
        }
    }
    if ((in_XMM3_Da < 0.5) || ((uVar4 & 0x1f0) == 0x100)) {
        iVar6 = *(int32_t *)(arg1 + 0x54);
        piVar1 = (int32_t *)(arg1 + 0x50);
        iVar7 = 8;
        if (*piVar1 == iVar6) {
            iVar8 = *piVar1 + 1;
            if (iVar6 == 0) {
                iVar6 = 8;
            } else {
                iVar6 = iVar6 / 2 + iVar6;
            }
            if (iVar8 < iVar6) {
                iVar8 = iVar6;
            }
            func_0x00018011f4f0(piVar1, iVar8);
        }
        *(undefined8 *)(*(int64_t *)(arg1 + 0x58) + (int64_t)*piVar1 * 8) = *(undefined8 *)arg2;
        *piVar1 = *piVar1 + 1;
        iVar6 = *(int32_t *)(arg1 + 0x54);
        uVar2 = *(undefined4 *)arg3;
        uVar3 = *(undefined4 *)(arg2 + 4);
        if (*piVar1 == iVar6) {
            iVar8 = *piVar1 + 1;
            if (iVar6 == 0) {
                iVar6 = 8;
            } else {
                iVar6 = iVar6 / 2 + iVar6;
            }
            if (iVar8 < iVar6) {
                iVar8 = iVar6;
            }
            func_0x00018011f4f0(piVar1, iVar8);
        }
        iVar6 = *piVar1;
        iVar9 = *(int64_t *)(arg1 + 0x58);
        *(undefined4 *)(iVar9 + (int64_t)iVar6 * 8) = uVar2;
        *(undefined4 *)(iVar9 + 4 + (int64_t)iVar6 * 8) = uVar3;
        *piVar1 = *piVar1 + 1;
        iVar6 = *(int32_t *)(arg1 + 0x54);
        if (*piVar1 == iVar6) {
            iVar8 = *piVar1 + 1;
            if (iVar6 == 0) {
                iVar6 = 8;
            } else {
                iVar6 = iVar6 / 2 + iVar6;
            }
            if (iVar8 < iVar6) {
                iVar8 = iVar6;
            }
            func_0x00018011f4f0(piVar1, iVar8);
        }
        *(undefined8 *)(*(int64_t *)(arg1 + 0x58) + (int64_t)*piVar1 * 8) = *(undefined8 *)arg3;
        *piVar1 = *piVar1 + 1;
        iVar6 = *(int32_t *)(arg1 + 0x54);
        uVar2 = *(undefined4 *)arg2;
        uVar3 = *(undefined4 *)(arg3 + 4);
        if (*piVar1 == iVar6) {
            iVar8 = *piVar1 + 1;
            if (iVar6 != 0) {
                iVar7 = iVar6 + iVar6 / 2;
            }
            if (iVar8 < iVar7) {
                iVar8 = iVar7;
            }
            func_0x00018011f4f0(piVar1, iVar8);
        }
        iVar6 = *piVar1;
        iVar9 = *(int64_t *)(arg1 + 0x58);
        *(undefined4 *)(iVar9 + (int64_t)iVar6 * 8) = uVar2;
        *(undefined4 *)(iVar9 + 4 + (int64_t)iVar6 * 8) = uVar3;
        *piVar1 = *piVar1 + 1;
    } else {
        fVar10 = in_XMM3_Da;
        if ((uVar4 & 0x10) == 0) {
            fVar10 = 0.0;
        }
        fVar12 = in_XMM3_Da;
        if ((uVar4 & 0x20) == 0) {
            fVar12 = 0.0;
        }
        fVar11 = in_XMM3_Da;
        if (-1 < (char)uVar4) {
            fVar11 = 0.0;
        }
        if ((uVar4 & 0x40) == 0) {
            in_XMM3_Da = 0.0;
        }
        var_58h._0_4_ = fVar10 + *(float *)arg2;
        var_58h._4_4_ = fVar10 + *(float *)(arg2 + 4);
        iVar9 = arg3;
        if (0.5 <= fVar10) {
            fcn.1801257a0(arg1, (int64_t)&var_58h, arg3, 0x18, CONCAT44(var_68h._4_4_, 0x24), in_stack_ffffffffffffffa0)
            ;
        } else {
            func_0x00018011f490(arg1 + 0x50);
        }
        var_58h._4_4_ = fVar12 + *(float *)(arg2 + 4);
        var_58h._0_4_ = *(float *)arg3 - fVar12;
        if (0.5 <= fVar12) {
            fcn.1801257a0(arg1, (int64_t)&var_58h, iVar9, 0x24, CONCAT44(var_68h._4_4_, 0x30), in_stack_ffffffffffffffa0
                         );
        } else {
            func_0x00018011f490(arg1 + 0x50);
        }
        var_58h._0_4_ = *(float *)arg3 - fVar11;
        var_58h._4_4_ = *(float *)(arg3 + 4) - fVar11;
        if (0.5 <= fVar11) {
            fcn.1801257a0(arg1, (int64_t)&var_58h, iVar9, 0, CONCAT44(var_68h._4_4_, 0xc), in_stack_ffffffffffffffa0);
        } else {
            func_0x00018011f490(arg1 + 0x50);
        }
        var_58h._0_4_ = in_XMM3_Da + *(float *)arg2;
        var_58h._4_4_ = *(float *)(arg3 + 4) - in_XMM3_Da;
        if (0.5 <= in_XMM3_Da) {
            fcn.1801257a0(arg1, (int64_t)&var_58h, iVar9, 0xc, CONCAT44(var_68h._4_4_, 0x18), in_stack_ffffffffffffffa0)
            ;
        } else {
            func_0x00018011f490(arg1 + 0x50);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18012602f
// Address: 0x18012602f
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

void fcn.180125f20(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    int32_t *piVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    uint32_t uVar4;
    uint8_t uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    float fVar10;
    float in_XMM3_Da;
    float fVar11;
    float fVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_68h;
    int64_t in_stack_ffffffffffffffa0;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    uVar4 = (uint32_t)arg_28h;
    if (0.5 <= in_XMM3_Da) {
        uVar4 = (uint32_t)arg_28h | 0xf0;
        if ((arg_28h & 0x1f0U) != 0) {
            uVar4 = (uint32_t)arg_28h;
        }
        uVar5 = (uint8_t)uVar4;
        if ((uVar5 & 0x30) == 0x30 || (uVar5 & 0xc0) == 0xc0) {
            fVar10 = 0.5;
        } else {
            fVar10 = 1.0;
        }
        fVar10 = (float)((uint32_t)(*(float *)arg3 - *(float *)arg2) & 0x7fffffff) * fVar10 - 1.0;
        if (fVar10 <= in_XMM3_Da) {
            in_XMM3_Da = fVar10;
        }
        if ((uVar5 & 0x50) == 0x50 || (uVar5 & 0xa0) == 0xa0) {
            fVar10 = 0.5;
        } else {
            fVar10 = 1.0;
        }
        fVar10 = (float)((uint32_t)(*(float *)(arg3 + 4) - *(float *)(arg2 + 4)) & 0x7fffffff) * fVar10 - 1.0;
        if (fVar10 <= in_XMM3_Da) {
            in_XMM3_Da = fVar10;
        }
    }
    if ((in_XMM3_Da < 0.5) || ((uVar4 & 0x1f0) == 0x100)) {
        iVar6 = *(int32_t *)(arg1 + 0x54);
        piVar1 = (int32_t *)(arg1 + 0x50);
        iVar7 = 8;
        if (*piVar1 == iVar6) {
            iVar8 = *piVar1 + 1;
            if (iVar6 == 0) {
                iVar6 = 8;
            } else {
                iVar6 = iVar6 / 2 + iVar6;
            }
            if (iVar8 < iVar6) {
                iVar8 = iVar6;
            }
            func_0x00018011f4f0(piVar1, iVar8);
        }
        *(undefined8 *)(*(int64_t *)(arg1 + 0x58) + (int64_t)*piVar1 * 8) = *(undefined8 *)arg2;
        *piVar1 = *piVar1 + 1;
        iVar6 = *(int32_t *)(arg1 + 0x54);
        uVar2 = *(undefined4 *)arg3;
        uVar3 = *(undefined4 *)(arg2 + 4);
        if (*piVar1 == iVar6) {
            iVar8 = *piVar1 + 1;
            if (iVar6 == 0) {
                iVar6 = 8;
            } else {
                iVar6 = iVar6 / 2 + iVar6;
            }
            if (iVar8 < iVar6) {
                iVar8 = iVar6;
            }
            func_0x00018011f4f0(piVar1, iVar8);
        }
        iVar6 = *piVar1;
        iVar9 = *(int64_t *)(arg1 + 0x58);
        *(undefined4 *)(iVar9 + (int64_t)iVar6 * 8) = uVar2;
        *(undefined4 *)(iVar9 + 4 + (int64_t)iVar6 * 8) = uVar3;
        *piVar1 = *piVar1 + 1;
        iVar6 = *(int32_t *)(arg1 + 0x54);
        if (*piVar1 == iVar6) {
            iVar8 = *piVar1 + 1;
            if (iVar6 == 0) {
                iVar6 = 8;
            } else {
                iVar6 = iVar6 / 2 + iVar6;
            }
            if (iVar8 < iVar6) {
                iVar8 = iVar6;
            }
            func_0x00018011f4f0(piVar1, iVar8);
        }
        *(undefined8 *)(*(int64_t *)(arg1 + 0x58) + (int64_t)*piVar1 * 8) = *(undefined8 *)arg3;
        *piVar1 = *piVar1 + 1;
        iVar6 = *(int32_t *)(arg1 + 0x54);
        uVar2 = *(undefined4 *)arg2;
        uVar3 = *(undefined4 *)(arg3 + 4);
        if (*piVar1 == iVar6) {
            iVar8 = *piVar1 + 1;
            if (iVar6 != 0) {
                iVar7 = iVar6 + iVar6 / 2;
            }
            if (iVar8 < iVar7) {
                iVar8 = iVar7;
            }
            func_0x00018011f4f0(piVar1, iVar8);
        }
        iVar6 = *piVar1;
        iVar9 = *(int64_t *)(arg1 + 0x58);
        *(undefined4 *)(iVar9 + (int64_t)iVar6 * 8) = uVar2;
        *(undefined4 *)(iVar9 + 4 + (int64_t)iVar6 * 8) = uVar3;
        *piVar1 = *piVar1 + 1;
    } else {
        fVar10 = in_XMM3_Da;
        if ((uVar4 & 0x10) == 0) {
            fVar10 = 0.0;
        }
        fVar12 = in_XMM3_Da;
        if ((uVar4 & 0x20) == 0) {
            fVar12 = 0.0;
        }
        fVar11 = in_XMM3_Da;
        if (-1 < (char)uVar4) {
            fVar11 = 0.0;
        }
        if ((uVar4 & 0x40) == 0) {
            in_XMM3_Da = 0.0;
        }
        var_58h._0_4_ = fVar10 + *(float *)arg2;
        var_58h._4_4_ = fVar10 + *(float *)(arg2 + 4);
        iVar9 = arg3;
        if (0.5 <= fVar10) {
            fcn.1801257a0(arg1, (int64_t)&var_58h, arg3, 0x18, CONCAT44(var_68h._4_4_, 0x24), in_stack_ffffffffffffffa0)
            ;
        } else {
            func_0x00018011f490(arg1 + 0x50);
        }
        var_58h._4_4_ = fVar12 + *(float *)(arg2 + 4);
        var_58h._0_4_ = *(float *)arg3 - fVar12;
        if (0.5 <= fVar12) {
            fcn.1801257a0(arg1, (int64_t)&var_58h, iVar9, 0x24, CONCAT44(var_68h._4_4_, 0x30), in_stack_ffffffffffffffa0
                         );
        } else {
            func_0x00018011f490(arg1 + 0x50);
        }
        var_58h._0_4_ = *(float *)arg3 - fVar11;
        var_58h._4_4_ = *(float *)(arg3 + 4) - fVar11;
        if (0.5 <= fVar11) {
            fcn.1801257a0(arg1, (int64_t)&var_58h, iVar9, 0, CONCAT44(var_68h._4_4_, 0xc), in_stack_ffffffffffffffa0);
        } else {
            func_0x00018011f490(arg1 + 0x50);
        }
        var_58h._0_4_ = in_XMM3_Da + *(float *)arg2;
        var_58h._4_4_ = *(float *)(arg3 + 4) - in_XMM3_Da;
        if (0.5 <= in_XMM3_Da) {
            fcn.1801257a0(arg1, (int64_t)&var_58h, iVar9, 0xc, CONCAT44(var_68h._4_4_, 0x18), in_stack_ffffffffffffffa0)
            ;
        } else {
            func_0x00018011f490(arg1 + 0x50);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180126035
// Address: 0x180126035
// Size: 257 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

void fcn.180125f20(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    int32_t *piVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    uint32_t uVar4;
    uint8_t uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    float fVar10;
    float in_XMM3_Da;
    float fVar11;
    float fVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_68h;
    int64_t in_stack_ffffffffffffffa0;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    uVar4 = (uint32_t)arg_28h;
    if (0.5 <= in_XMM3_Da) {
        uVar4 = (uint32_t)arg_28h | 0xf0;
        if ((arg_28h & 0x1f0U) != 0) {
            uVar4 = (uint32_t)arg_28h;
        }
        uVar5 = (uint8_t)uVar4;
        if ((uVar5 & 0x30) == 0x30 || (uVar5 & 0xc0) == 0xc0) {
            fVar10 = 0.5;
        } else {
            fVar10 = 1.0;
        }
        fVar10 = (float)((uint32_t)(*(float *)arg3 - *(float *)arg2) & 0x7fffffff) * fVar10 - 1.0;
        if (fVar10 <= in_XMM3_Da) {
            in_XMM3_Da = fVar10;
        }
        if ((uVar5 & 0x50) == 0x50 || (uVar5 & 0xa0) == 0xa0) {
            fVar10 = 0.5;
        } else {
            fVar10 = 1.0;
        }
        fVar10 = (float)((uint32_t)(*(float *)(arg3 + 4) - *(float *)(arg2 + 4)) & 0x7fffffff) * fVar10 - 1.0;
        if (fVar10 <= in_XMM3_Da) {
            in_XMM3_Da = fVar10;
        }
    }
    if ((in_XMM3_Da < 0.5) || ((uVar4 & 0x1f0) == 0x100)) {
        iVar6 = *(int32_t *)(arg1 + 0x54);
        piVar1 = (int32_t *)(arg1 + 0x50);
        iVar7 = 8;
        if (*piVar1 == iVar6) {
            iVar8 = *piVar1 + 1;
            if (iVar6 == 0) {
                iVar6 = 8;
            } else {
                iVar6 = iVar6 / 2 + iVar6;
            }
            if (iVar8 < iVar6) {
                iVar8 = iVar6;
            }
            func_0x00018011f4f0(piVar1, iVar8);
        }
        *(undefined8 *)(*(int64_t *)(arg1 + 0x58) + (int64_t)*piVar1 * 8) = *(undefined8 *)arg2;
        *piVar1 = *piVar1 + 1;
        iVar6 = *(int32_t *)(arg1 + 0x54);
        uVar2 = *(undefined4 *)arg3;
        uVar3 = *(undefined4 *)(arg2 + 4);
        if (*piVar1 == iVar6) {
            iVar8 = *piVar1 + 1;
            if (iVar6 == 0) {
                iVar6 = 8;
            } else {
                iVar6 = iVar6 / 2 + iVar6;
            }
            if (iVar8 < iVar6) {
                iVar8 = iVar6;
            }
            func_0x00018011f4f0(piVar1, iVar8);
        }
        iVar6 = *piVar1;
        iVar9 = *(int64_t *)(arg1 + 0x58);
        *(undefined4 *)(iVar9 + (int64_t)iVar6 * 8) = uVar2;
        *(undefined4 *)(iVar9 + 4 + (int64_t)iVar6 * 8) = uVar3;
        *piVar1 = *piVar1 + 1;
        iVar6 = *(int32_t *)(arg1 + 0x54);
        if (*piVar1 == iVar6) {
            iVar8 = *piVar1 + 1;
            if (iVar6 == 0) {
                iVar6 = 8;
            } else {
                iVar6 = iVar6 / 2 + iVar6;
            }
            if (iVar8 < iVar6) {
                iVar8 = iVar6;
            }
            func_0x00018011f4f0(piVar1, iVar8);
        }
        *(undefined8 *)(*(int64_t *)(arg1 + 0x58) + (int64_t)*piVar1 * 8) = *(undefined8 *)arg3;
        *piVar1 = *piVar1 + 1;
        iVar6 = *(int32_t *)(arg1 + 0x54);
        uVar2 = *(undefined4 *)arg2;
        uVar3 = *(undefined4 *)(arg3 + 4);
        if (*piVar1 == iVar6) {
            iVar8 = *piVar1 + 1;
            if (iVar6 != 0) {
                iVar7 = iVar6 + iVar6 / 2;
            }
            if (iVar8 < iVar7) {
                iVar8 = iVar7;
            }
            func_0x00018011f4f0(piVar1, iVar8);
        }
        iVar6 = *piVar1;
        iVar9 = *(int64_t *)(arg1 + 0x58);
        *(undefined4 *)(iVar9 + (int64_t)iVar6 * 8) = uVar2;
        *(undefined4 *)(iVar9 + 4 + (int64_t)iVar6 * 8) = uVar3;
        *piVar1 = *piVar1 + 1;
    } else {
        fVar10 = in_XMM3_Da;
        if ((uVar4 & 0x10) == 0) {
            fVar10 = 0.0;
        }
        fVar12 = in_XMM3_Da;
        if ((uVar4 & 0x20) == 0) {
            fVar12 = 0.0;
        }
        fVar11 = in_XMM3_Da;
        if (-1 < (char)uVar4) {
            fVar11 = 0.0;
        }
        if ((uVar4 & 0x40) == 0) {
            in_XMM3_Da = 0.0;
        }
        var_58h._0_4_ = fVar10 + *(float *)arg2;
        var_58h._4_4_ = fVar10 + *(float *)(arg2 + 4);
        iVar9 = arg3;
        if (0.5 <= fVar10) {
            fcn.1801257a0(arg1, (int64_t)&var_58h, arg3, 0x18, CONCAT44(var_68h._4_4_, 0x24), in_stack_ffffffffffffffa0)
            ;
        } else {
            func_0x00018011f490(arg1 + 0x50);
        }
        var_58h._4_4_ = fVar12 + *(float *)(arg2 + 4);
        var_58h._0_4_ = *(float *)arg3 - fVar12;
        if (0.5 <= fVar12) {
            fcn.1801257a0(arg1, (int64_t)&var_58h, iVar9, 0x24, CONCAT44(var_68h._4_4_, 0x30), in_stack_ffffffffffffffa0
                         );
        } else {
            func_0x00018011f490(arg1 + 0x50);
        }
        var_58h._0_4_ = *(float *)arg3 - fVar11;
        var_58h._4_4_ = *(float *)(arg3 + 4) - fVar11;
        if (0.5 <= fVar11) {
            fcn.1801257a0(arg1, (int64_t)&var_58h, iVar9, 0, CONCAT44(var_68h._4_4_, 0xc), in_stack_ffffffffffffffa0);
        } else {
            func_0x00018011f490(arg1 + 0x50);
        }
        var_58h._0_4_ = in_XMM3_Da + *(float *)arg2;
        var_58h._4_4_ = *(float *)(arg3 + 4) - in_XMM3_Da;
        if (0.5 <= in_XMM3_Da) {
            fcn.1801257a0(arg1, (int64_t)&var_58h, iVar9, 0xc, CONCAT44(var_68h._4_4_, 0x18), in_stack_ffffffffffffffa0)
            ;
        } else {
            func_0x00018011f490(arg1 + 0x50);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180126136
// Address: 0x180126136
// Size: 79 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

void fcn.180125f20(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    int32_t *piVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    uint32_t uVar4;
    uint8_t uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    float fVar10;
    float in_XMM3_Da;
    float fVar11;
    float fVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_68h;
    int64_t in_stack_ffffffffffffffa0;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    uVar4 = (uint32_t)arg_28h;
    if (0.5 <= in_XMM3_Da) {
        uVar4 = (uint32_t)arg_28h | 0xf0;
        if ((arg_28h & 0x1f0U) != 0) {
            uVar4 = (uint32_t)arg_28h;
        }
        uVar5 = (uint8_t)uVar4;
        if ((uVar5 & 0x30) == 0x30 || (uVar5 & 0xc0) == 0xc0) {
            fVar10 = 0.5;
        } else {
            fVar10 = 1.0;
        }
        fVar10 = (float)((uint32_t)(*(float *)arg3 - *(float *)arg2) & 0x7fffffff) * fVar10 - 1.0;
        if (fVar10 <= in_XMM3_Da) {
            in_XMM3_Da = fVar10;
        }
        if ((uVar5 & 0x50) == 0x50 || (uVar5 & 0xa0) == 0xa0) {
            fVar10 = 0.5;
        } else {
            fVar10 = 1.0;
        }
        fVar10 = (float)((uint32_t)(*(float *)(arg3 + 4) - *(float *)(arg2 + 4)) & 0x7fffffff) * fVar10 - 1.0;
        if (fVar10 <= in_XMM3_Da) {
            in_XMM3_Da = fVar10;
        }
    }
    if ((in_XMM3_Da < 0.5) || ((uVar4 & 0x1f0) == 0x100)) {
        iVar6 = *(int32_t *)(arg1 + 0x54);
        piVar1 = (int32_t *)(arg1 + 0x50);
        iVar7 = 8;
        if (*piVar1 == iVar6) {
            iVar8 = *piVar1 + 1;
            if (iVar6 == 0) {
                iVar6 = 8;
            } else {
                iVar6 = iVar6 / 2 + iVar6;
            }
            if (iVar8 < iVar6) {
                iVar8 = iVar6;
            }
            func_0x00018011f4f0(piVar1, iVar8);
        }
        *(undefined8 *)(*(int64_t *)(arg1 + 0x58) + (int64_t)*piVar1 * 8) = *(undefined8 *)arg2;
        *piVar1 = *piVar1 + 1;
        iVar6 = *(int32_t *)(arg1 + 0x54);
        uVar2 = *(undefined4 *)arg3;
        uVar3 = *(undefined4 *)(arg2 + 4);
        if (*piVar1 == iVar6) {
            iVar8 = *piVar1 + 1;
            if (iVar6 == 0) {
                iVar6 = 8;
            } else {
                iVar6 = iVar6 / 2 + iVar6;
            }
            if (iVar8 < iVar6) {
                iVar8 = iVar6;
            }
            func_0x00018011f4f0(piVar1, iVar8);
        }
        iVar6 = *piVar1;
        iVar9 = *(int64_t *)(arg1 + 0x58);
        *(undefined4 *)(iVar9 + (int64_t)iVar6 * 8) = uVar2;
        *(undefined4 *)(iVar9 + 4 + (int64_t)iVar6 * 8) = uVar3;
        *piVar1 = *piVar1 + 1;
        iVar6 = *(int32_t *)(arg1 + 0x54);
        if (*piVar1 == iVar6) {
            iVar8 = *piVar1 + 1;
            if (iVar6 == 0) {
                iVar6 = 8;
            } else {
                iVar6 = iVar6 / 2 + iVar6;
            }
            if (iVar8 < iVar6) {
                iVar8 = iVar6;
            }
            func_0x00018011f4f0(piVar1, iVar8);
        }
        *(undefined8 *)(*(int64_t *)(arg1 + 0x58) + (int64_t)*piVar1 * 8) = *(undefined8 *)arg3;
        *piVar1 = *piVar1 + 1;
        iVar6 = *(int32_t *)(arg1 + 0x54);
        uVar2 = *(undefined4 *)arg2;
        uVar3 = *(undefined4 *)(arg3 + 4);
        if (*piVar1 == iVar6) {
            iVar8 = *piVar1 + 1;
            if (iVar6 != 0) {
                iVar7 = iVar6 + iVar6 / 2;
            }
            if (iVar8 < iVar7) {
                iVar8 = iVar7;
            }
            func_0x00018011f4f0(piVar1, iVar8);
        }
        iVar6 = *piVar1;
        iVar9 = *(int64_t *)(arg1 + 0x58);
        *(undefined4 *)(iVar9 + (int64_t)iVar6 * 8) = uVar2;
        *(undefined4 *)(iVar9 + 4 + (int64_t)iVar6 * 8) = uVar3;
        *piVar1 = *piVar1 + 1;
    } else {
        fVar10 = in_XMM3_Da;
        if ((uVar4 & 0x10) == 0) {
            fVar10 = 0.0;
        }
        fVar12 = in_XMM3_Da;
        if ((uVar4 & 0x20) == 0) {
            fVar12 = 0.0;
        }
        fVar11 = in_XMM3_Da;
        if (-1 < (char)uVar4) {
            fVar11 = 0.0;
        }
        if ((uVar4 & 0x40) == 0) {
            in_XMM3_Da = 0.0;
        }
        var_58h._0_4_ = fVar10 + *(float *)arg2;
        var_58h._4_4_ = fVar10 + *(float *)(arg2 + 4);
        iVar9 = arg3;
        if (0.5 <= fVar10) {
            fcn.1801257a0(arg1, (int64_t)&var_58h, arg3, 0x18, CONCAT44(var_68h._4_4_, 0x24), in_stack_ffffffffffffffa0)
            ;
        } else {
            func_0x00018011f490(arg1 + 0x50);
        }
        var_58h._4_4_ = fVar12 + *(float *)(arg2 + 4);
        var_58h._0_4_ = *(float *)arg3 - fVar12;
        if (0.5 <= fVar12) {
            fcn.1801257a0(arg1, (int64_t)&var_58h, iVar9, 0x24, CONCAT44(var_68h._4_4_, 0x30), in_stack_ffffffffffffffa0
                         );
        } else {
            func_0x00018011f490(arg1 + 0x50);
        }
        var_58h._0_4_ = *(float *)arg3 - fVar11;
        var_58h._4_4_ = *(float *)(arg3 + 4) - fVar11;
        if (0.5 <= fVar11) {
            fcn.1801257a0(arg1, (int64_t)&var_58h, iVar9, 0, CONCAT44(var_68h._4_4_, 0xc), in_stack_ffffffffffffffa0);
        } else {
            func_0x00018011f490(arg1 + 0x50);
        }
        var_58h._0_4_ = in_XMM3_Da + *(float *)arg2;
        var_58h._4_4_ = *(float *)(arg3 + 4) - in_XMM3_Da;
        if (0.5 <= in_XMM3_Da) {
            fcn.1801257a0(arg1, (int64_t)&var_58h, iVar9, 0xc, CONCAT44(var_68h._4_4_, 0x18), in_stack_ffffffffffffffa0)
            ;
        } else {
            func_0x00018011f490(arg1 + 0x50);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180126185
// Address: 0x180126185
// Size: 376 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

void fcn.180125f20(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    int32_t *piVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    uint32_t uVar4;
    uint8_t uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    float fVar10;
    float in_XMM3_Da;
    float fVar11;
    float fVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_68h;
    int64_t in_stack_ffffffffffffffa0;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    uVar4 = (uint32_t)arg_28h;
    if (0.5 <= in_XMM3_Da) {
        uVar4 = (uint32_t)arg_28h | 0xf0;
        if ((arg_28h & 0x1f0U) != 0) {
            uVar4 = (uint32_t)arg_28h;
        }
        uVar5 = (uint8_t)uVar4;
        if ((uVar5 & 0x30) == 0x30 || (uVar5 & 0xc0) == 0xc0) {
            fVar10 = 0.5;
        } else {
            fVar10 = 1.0;
        }
        fVar10 = (float)((uint32_t)(*(float *)arg3 - *(float *)arg2) & 0x7fffffff) * fVar10 - 1.0;
        if (fVar10 <= in_XMM3_Da) {
            in_XMM3_Da = fVar10;
        }
        if ((uVar5 & 0x50) == 0x50 || (uVar5 & 0xa0) == 0xa0) {
            fVar10 = 0.5;
        } else {
            fVar10 = 1.0;
        }
        fVar10 = (float)((uint32_t)(*(float *)(arg3 + 4) - *(float *)(arg2 + 4)) & 0x7fffffff) * fVar10 - 1.0;
        if (fVar10 <= in_XMM3_Da) {
            in_XMM3_Da = fVar10;
        }
    }
    if ((in_XMM3_Da < 0.5) || ((uVar4 & 0x1f0) == 0x100)) {
        iVar6 = *(int32_t *)(arg1 + 0x54);
        piVar1 = (int32_t *)(arg1 + 0x50);
        iVar7 = 8;
        if (*piVar1 == iVar6) {
            iVar8 = *piVar1 + 1;
            if (iVar6 == 0) {
                iVar6 = 8;
            } else {
                iVar6 = iVar6 / 2 + iVar6;
            }
            if (iVar8 < iVar6) {
                iVar8 = iVar6;
            }
            func_0x00018011f4f0(piVar1, iVar8);
        }
        *(undefined8 *)(*(int64_t *)(arg1 + 0x58) + (int64_t)*piVar1 * 8) = *(undefined8 *)arg2;
        *piVar1 = *piVar1 + 1;
        iVar6 = *(int32_t *)(arg1 + 0x54);
        uVar2 = *(undefined4 *)arg3;
        uVar3 = *(undefined4 *)(arg2 + 4);
        if (*piVar1 == iVar6) {
            iVar8 = *piVar1 + 1;
            if (iVar6 == 0) {
                iVar6 = 8;
            } else {
                iVar6 = iVar6 / 2 + iVar6;
            }
            if (iVar8 < iVar6) {
                iVar8 = iVar6;
            }
            func_0x00018011f4f0(piVar1, iVar8);
        }
        iVar6 = *piVar1;
        iVar9 = *(int64_t *)(arg1 + 0x58);
        *(undefined4 *)(iVar9 + (int64_t)iVar6 * 8) = uVar2;
        *(undefined4 *)(iVar9 + 4 + (int64_t)iVar6 * 8) = uVar3;
        *piVar1 = *piVar1 + 1;
        iVar6 = *(int32_t *)(arg1 + 0x54);
        if (*piVar1 == iVar6) {
            iVar8 = *piVar1 + 1;
            if (iVar6 == 0) {
                iVar6 = 8;
            } else {
                iVar6 = iVar6 / 2 + iVar6;
            }
            if (iVar8 < iVar6) {
                iVar8 = iVar6;
            }
            func_0x00018011f4f0(piVar1, iVar8);
        }
        *(undefined8 *)(*(int64_t *)(arg1 + 0x58) + (int64_t)*piVar1 * 8) = *(undefined8 *)arg3;
        *piVar1 = *piVar1 + 1;
        iVar6 = *(int32_t *)(arg1 + 0x54);
        uVar2 = *(undefined4 *)arg2;
        uVar3 = *(undefined4 *)(arg3 + 4);
        if (*piVar1 == iVar6) {
            iVar8 = *piVar1 + 1;
            if (iVar6 != 0) {
                iVar7 = iVar6 + iVar6 / 2;
            }
            if (iVar8 < iVar7) {
                iVar8 = iVar7;
            }
            func_0x00018011f4f0(piVar1, iVar8);
        }
        iVar6 = *piVar1;
        iVar9 = *(int64_t *)(arg1 + 0x58);
        *(undefined4 *)(iVar9 + (int64_t)iVar6 * 8) = uVar2;
        *(undefined4 *)(iVar9 + 4 + (int64_t)iVar6 * 8) = uVar3;
        *piVar1 = *piVar1 + 1;
    } else {
        fVar10 = in_XMM3_Da;
        if ((uVar4 & 0x10) == 0) {
            fVar10 = 0.0;
        }
        fVar12 = in_XMM3_Da;
        if ((uVar4 & 0x20) == 0) {
            fVar12 = 0.0;
        }
        fVar11 = in_XMM3_Da;
        if (-1 < (char)uVar4) {
            fVar11 = 0.0;
        }
        if ((uVar4 & 0x40) == 0) {
            in_XMM3_Da = 0.0;
        }
        var_58h._0_4_ = fVar10 + *(float *)arg2;
        var_58h._4_4_ = fVar10 + *(float *)(arg2 + 4);
        iVar9 = arg3;
        if (0.5 <= fVar10) {
            fcn.1801257a0(arg1, (int64_t)&var_58h, arg3, 0x18, CONCAT44(var_68h._4_4_, 0x24), in_stack_ffffffffffffffa0)
            ;
        } else {
            func_0x00018011f490(arg1 + 0x50);
        }
        var_58h._4_4_ = fVar12 + *(float *)(arg2 + 4);
        var_58h._0_4_ = *(float *)arg3 - fVar12;
        if (0.5 <= fVar12) {
            fcn.1801257a0(arg1, (int64_t)&var_58h, iVar9, 0x24, CONCAT44(var_68h._4_4_, 0x30), in_stack_ffffffffffffffa0
                         );
        } else {
            func_0x00018011f490(arg1 + 0x50);
        }
        var_58h._0_4_ = *(float *)arg3 - fVar11;
        var_58h._4_4_ = *(float *)(arg3 + 4) - fVar11;
        if (0.5 <= fVar11) {
            fcn.1801257a0(arg1, (int64_t)&var_58h, iVar9, 0, CONCAT44(var_68h._4_4_, 0xc), in_stack_ffffffffffffffa0);
        } else {
            func_0x00018011f490(arg1 + 0x50);
        }
        var_58h._0_4_ = in_XMM3_Da + *(float *)arg2;
        var_58h._4_4_ = *(float *)(arg3 + 4) - in_XMM3_Da;
        if (0.5 <= in_XMM3_Da) {
            fcn.1801257a0(arg1, (int64_t)&var_58h, iVar9, 0xc, CONCAT44(var_68h._4_4_, 0x18), in_stack_ffffffffffffffa0)
            ;
        } else {
            func_0x00018011f490(arg1 + 0x50);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180126300
// Address: 0x180126300
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch

void fcn.180126300(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    float fVar1;
    float fVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    if ((arg4 & 0xff000000U) != 0) {
        iVar4 = *(int32_t *)(arg1 + 0x54);
        iVar5 = 8;
        fVar1 = *(float *)arg2;
        fVar2 = *(float *)(arg2 + 4);
        if (*(int32_t *)(arg1 + 0x50) == iVar4) {
            iVar6 = *(int32_t *)(arg1 + 0x50) + 1;
            if (iVar4 == 0) {
                iVar4 = 8;
            } else {
                iVar4 = iVar4 / 2 + iVar4;
            }
            if (iVar6 < iVar4) {
                iVar6 = iVar4;
            }
            func_0x00018011f4f0(arg1 + 0x50, iVar6);
        }
        iVar4 = *(int32_t *)(arg1 + 0x50);
        iVar3 = *(int64_t *)(arg1 + 0x58);
        *(float *)(iVar3 + (int64_t)iVar4 * 8) = fVar1 + 0.5;
        *(float *)(iVar3 + 4 + (int64_t)iVar4 * 8) = fVar2 + 0.5;
        *(int32_t *)(arg1 + 0x50) = *(int32_t *)(arg1 + 0x50) + 1;
        fVar1 = *(float *)arg3;
        fVar2 = *(float *)(arg3 + 4);
        iVar4 = *(int32_t *)(arg1 + 0x54);
        if (*(int32_t *)(arg1 + 0x50) == iVar4) {
            iVar6 = *(int32_t *)(arg1 + 0x50) + 1;
            if (iVar4 != 0) {
                iVar5 = iVar4 + iVar4 / 2;
            }
            if (iVar6 < iVar5) {
                iVar6 = iVar5;
            }
            func_0x00018011f4f0(arg1 + 0x50, iVar6);
        }
        iVar4 = *(int32_t *)(arg1 + 0x50);
        iVar3 = *(int64_t *)(arg1 + 0x58);
        *(float *)(iVar3 + (int64_t)iVar4 * 8) = fVar1 + 0.5;
        *(float *)(iVar3 + 4 + (int64_t)iVar4 * 8) = fVar2 + 0.5;
        *(int32_t *)(arg1 + 0x50) = *(int32_t *)(arg1 + 0x50) + 1;
        fcn.1801248e0(arg1, *(int64_t *)(arg1 + 0x58), (uint64_t)*(uint32_t *)(arg1 + 0x50), arg4 & 0xffffffff, 
                      (uint64_t)var_48h._4_4_ << 0x20, CONCAT44(var_40h._4_4_, (undefined4)arg_28h));
        *(undefined4 *)(arg1 + 0x50) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180126332
// Address: 0x180126332
// Size: 153 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch

void fcn.180126300(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    float fVar1;
    float fVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    if ((arg4 & 0xff000000U) != 0) {
        iVar4 = *(int32_t *)(arg1 + 0x54);
        iVar5 = 8;
        fVar1 = *(float *)arg2;
        fVar2 = *(float *)(arg2 + 4);
        if (*(int32_t *)(arg1 + 0x50) == iVar4) {
            iVar6 = *(int32_t *)(arg1 + 0x50) + 1;
            if (iVar4 == 0) {
                iVar4 = 8;
            } else {
                iVar4 = iVar4 / 2 + iVar4;
            }
            if (iVar6 < iVar4) {
                iVar6 = iVar4;
            }
            func_0x00018011f4f0(arg1 + 0x50, iVar6);
        }
        iVar4 = *(int32_t *)(arg1 + 0x50);
        iVar3 = *(int64_t *)(arg1 + 0x58);
        *(float *)(iVar3 + (int64_t)iVar4 * 8) = fVar1 + 0.5;
        *(float *)(iVar3 + 4 + (int64_t)iVar4 * 8) = fVar2 + 0.5;
        *(int32_t *)(arg1 + 0x50) = *(int32_t *)(arg1 + 0x50) + 1;
        fVar1 = *(float *)arg3;
        fVar2 = *(float *)(arg3 + 4);
        iVar4 = *(int32_t *)(arg1 + 0x54);
        if (*(int32_t *)(arg1 + 0x50) == iVar4) {
            iVar6 = *(int32_t *)(arg1 + 0x50) + 1;
            if (iVar4 != 0) {
                iVar5 = iVar4 + iVar4 / 2;
            }
            if (iVar6 < iVar5) {
                iVar6 = iVar5;
            }
            func_0x00018011f4f0(arg1 + 0x50, iVar6);
        }
        iVar4 = *(int32_t *)(arg1 + 0x50);
        iVar3 = *(int64_t *)(arg1 + 0x58);
        *(float *)(iVar3 + (int64_t)iVar4 * 8) = fVar1 + 0.5;
        *(float *)(iVar3 + 4 + (int64_t)iVar4 * 8) = fVar2 + 0.5;
        *(int32_t *)(arg1 + 0x50) = *(int32_t *)(arg1 + 0x50) + 1;
        fcn.1801248e0(arg1, *(int64_t *)(arg1 + 0x58), (uint64_t)*(uint32_t *)(arg1 + 0x50), arg4 & 0xffffffff, 
                      (uint64_t)var_48h._4_4_ << 0x20, CONCAT44(var_40h._4_4_, (undefined4)arg_28h));
        *(undefined4 *)(arg1 + 0x50) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1801263cb
// Address: 0x1801263cb
// Size: 140 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch

void fcn.180126300(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    float fVar1;
    float fVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    if ((arg4 & 0xff000000U) != 0) {
        iVar4 = *(int32_t *)(arg1 + 0x54);
        iVar5 = 8;
        fVar1 = *(float *)arg2;
        fVar2 = *(float *)(arg2 + 4);
        if (*(int32_t *)(arg1 + 0x50) == iVar4) {
            iVar6 = *(int32_t *)(arg1 + 0x50) + 1;
            if (iVar4 == 0) {
                iVar4 = 8;
            } else {
                iVar4 = iVar4 / 2 + iVar4;
            }
            if (iVar6 < iVar4) {
                iVar6 = iVar4;
            }
            func_0x00018011f4f0(arg1 + 0x50, iVar6);
        }
        iVar4 = *(int32_t *)(arg1 + 0x50);
        iVar3 = *(int64_t *)(arg1 + 0x58);
        *(float *)(iVar3 + (int64_t)iVar4 * 8) = fVar1 + 0.5;
        *(float *)(iVar3 + 4 + (int64_t)iVar4 * 8) = fVar2 + 0.5;
        *(int32_t *)(arg1 + 0x50) = *(int32_t *)(arg1 + 0x50) + 1;
        fVar1 = *(float *)arg3;
        fVar2 = *(float *)(arg3 + 4);
        iVar4 = *(int32_t *)(arg1 + 0x54);
        if (*(int32_t *)(arg1 + 0x50) == iVar4) {
            iVar6 = *(int32_t *)(arg1 + 0x50) + 1;
            if (iVar4 != 0) {
                iVar5 = iVar4 + iVar4 / 2;
            }
            if (iVar6 < iVar5) {
                iVar6 = iVar5;
            }
            func_0x00018011f4f0(arg1 + 0x50, iVar6);
        }
        iVar4 = *(int32_t *)(arg1 + 0x50);
        iVar3 = *(int64_t *)(arg1 + 0x58);
        *(float *)(iVar3 + (int64_t)iVar4 * 8) = fVar1 + 0.5;
        *(float *)(iVar3 + 4 + (int64_t)iVar4 * 8) = fVar2 + 0.5;
        *(int32_t *)(arg1 + 0x50) = *(int32_t *)(arg1 + 0x50) + 1;
        fcn.1801248e0(arg1, *(int64_t *)(arg1 + 0x58), (uint64_t)*(uint32_t *)(arg1 + 0x50), arg4 & 0xffffffff, 
                      (uint64_t)var_48h._4_4_ << 0x20, CONCAT44(var_40h._4_4_, (undefined4)arg_28h));
        *(undefined4 *)(arg1 + 0x50) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180126457
// Address: 0x180126457
// Size: 1 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch

void fcn.180126300(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    float fVar1;
    float fVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    if ((arg4 & 0xff000000U) != 0) {
        iVar4 = *(int32_t *)(arg1 + 0x54);
        iVar5 = 8;
        fVar1 = *(float *)arg2;
        fVar2 = *(float *)(arg2 + 4);
        if (*(int32_t *)(arg1 + 0x50) == iVar4) {
            iVar6 = *(int32_t *)(arg1 + 0x50) + 1;
            if (iVar4 == 0) {
                iVar4 = 8;
            } else {
                iVar4 = iVar4 / 2 + iVar4;
            }
            if (iVar6 < iVar4) {
                iVar6 = iVar4;
            }
            func_0x00018011f4f0(arg1 + 0x50, iVar6);
        }
        iVar4 = *(int32_t *)(arg1 + 0x50);
        iVar3 = *(int64_t *)(arg1 + 0x58);
        *(float *)(iVar3 + (int64_t)iVar4 * 8) = fVar1 + 0.5;
        *(float *)(iVar3 + 4 + (int64_t)iVar4 * 8) = fVar2 + 0.5;
        *(int32_t *)(arg1 + 0x50) = *(int32_t *)(arg1 + 0x50) + 1;
        fVar1 = *(float *)arg3;
        fVar2 = *(float *)(arg3 + 4);
        iVar4 = *(int32_t *)(arg1 + 0x54);
        if (*(int32_t *)(arg1 + 0x50) == iVar4) {
            iVar6 = *(int32_t *)(arg1 + 0x50) + 1;
            if (iVar4 != 0) {
                iVar5 = iVar4 + iVar4 / 2;
            }
            if (iVar6 < iVar5) {
                iVar6 = iVar5;
            }
            func_0x00018011f4f0(arg1 + 0x50, iVar6);
        }
        iVar4 = *(int32_t *)(arg1 + 0x50);
        iVar3 = *(int64_t *)(arg1 + 0x58);
        *(float *)(iVar3 + (int64_t)iVar4 * 8) = fVar1 + 0.5;
        *(float *)(iVar3 + 4 + (int64_t)iVar4 * 8) = fVar2 + 0.5;
        *(int32_t *)(arg1 + 0x50) = *(int32_t *)(arg1 + 0x50) + 1;
        fcn.1801248e0(arg1, *(int64_t *)(arg1 + 0x58), (uint64_t)*(uint32_t *)(arg1 + 0x50), arg4 & 0xffffffff, 
                      (uint64_t)var_48h._4_4_ << 0x20, CONCAT44(var_40h._4_4_, (undefined4)arg_28h));
        *(undefined4 *)(arg1 + 0x50) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180126460
// Address: 0x180126460
// Size: 239 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch

void fcn.180126460(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, undefined8 placeholder_5,
                  int64_t arg_38h)
{
    int64_t *arg2_00;
    int64_t *arg3_00;
    float fVar1;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    
    if ((arg4 & 0xff000000U) != 0) {
        fVar1 = *(float *)(arg2 + 4) + 0.5;
        if ((*(uint8_t *)(arg1 + 0x30) & 1) == 0) {
            var_10h._0_4_ = *(float *)arg3 - 0.49;
            var_10h._4_4_ = *(float *)(arg3 + 4) - 0.49;
            arg3_00 = &var_10h;
            arg2_00 = &var_18h;
            var_18h._0_4_ = *(float *)arg2 + 0.5;
            var_18h._4_4_ = fVar1;
        } else {
            arg3_00 = &var_18h;
            arg2_00 = &var_10h;
            var_18h._0_4_ = *(float *)arg3 - 0.5;
            var_18h._4_4_ = *(float *)(arg3 + 4) - 0.5;
            var_10h._0_4_ = *(float *)arg2 + 0.5;
            var_10h._4_4_ = fVar1;
        }
        fcn.180125f20(arg1, (int64_t)arg2_00, (int64_t)arg3_00, arg4, (uint64_t)var_28h._4_4_ << 0x20);
        fcn.1801248e0(arg1, *(int64_t *)(arg1 + 0x58), (uint64_t)*(uint32_t *)(arg1 + 0x50), arg4 & 0xffffffff, 
                      CONCAT44(var_28h._4_4_, 1), CONCAT44(var_20h._4_4_, (undefined4)arg_38h));
        *(undefined4 *)(arg1 + 0x50) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180126550
// Address: 0x180126550
// Size: 111 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

void fcn.180126550(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_a0h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    uint32_t uVar6;
    undefined4 uVar7;
    int64_t iVar8;
    int64_t iVar9;
    int16_t iVar10;
    undefined8 uVar11;
    int64_t iVar12;
    int32_t iVar13;
    int16_t iVar14;
    uint32_t uVar15;
    uint64_t uVar16;
    int16_t iVar17;
    int32_t iVar18;
    int64_t iVar19;
    uint32_t uVar20;
    int32_t iVar21;
    int32_t iVar22;
    int16_t iVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    undefined auVar28 [16];
    float fVar29;
    int64_t var_4h;
    int64_t var_10h;
    int64_t var_18h;
    uint32_t in_stack_00000030;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar20 = (uint32_t)arg4;
    if ((arg4 & 0xff000000U) != 0) {
        if ((0.5 <= (float)arg_28h) && ((in_stack_00000030 & 0x1f0) != 0x100)) {
            var_48h._0_4_ = in_stack_00000030;
            fcn.180125f20(arg1, arg2, arg3, arg4, var_48h);
            uVar6 = *(uint32_t *)(arg1 + 0x50);
            if ((2 < (int32_t)uVar6) && ((arg4 & 0xff000000U) != 0)) {
                iVar8 = *(int64_t *)(arg1 + 0x58);
                uVar1 = **(undefined4 **)(arg1 + 0x38);
                uVar2 = (*(undefined4 **)(arg1 + 0x38))[1];
                if ((*(uint8_t *)(arg1 + 0x30) & 4) == 0) {
                    fcn.180124680(arg1, (uint64_t)((uVar6 - 2) * 3), (uint64_t)uVar6);
                    uVar16 = 0;
                    do {
                        iVar9 = uVar16 * 8;
                        uVar15 = (int32_t)uVar16 + 1;
                        uVar16 = (uint64_t)uVar15;
                        **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar8 + iVar9);
                        iVar9 = *(int64_t *)(arg1 + 0x40);
                        *(undefined4 *)(iVar9 + 8) = uVar1;
                        *(undefined4 *)(iVar9 + 0xc) = uVar2;
                        *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar20;
                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x14;
                    } while ((int32_t)uVar15 < (int32_t)uVar6);
                    iVar18 = 2;
                    do {
                        **(undefined2 **)(arg1 + 0x48) = *(undefined2 *)(arg1 + 0x34);
                        iVar14 = (int16_t)iVar18;
                        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar14 + -1 + *(int16_t *)(arg1 + 0x34);
                        iVar18 = iVar18 + 1;
                        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar14 + *(int16_t *)(arg1 + 0x34);
                        *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 6;
                    } while (iVar18 < (int32_t)uVar6);
                    *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + (uVar6 & 0xffff);
                    *(undefined4 *)(arg1 + 0x50) = 0;
                } else {
                    fVar29 = *(float *)(arg1 + 0xd0);
                    fcn.180124680(arg1, (uint64_t)(uVar6 * 9 - 6), (uint64_t)(uVar6 * 2));
                    uVar7 = *(undefined4 *)(arg1 + 0x34);
                    iVar18 = 2;
                    do {
                        iVar14 = (int16_t)iVar18;
                        iVar18 = iVar18 + 1;
                        iVar23 = (int16_t)uVar7;
                        iVar14 = iVar14 * 2 + iVar23;
                        **(int16_t **)(arg1 + 0x48) = iVar23;
                        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar14 + -2;
                        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar14;
                        *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 6;
                    } while (iVar18 < (int32_t)uVar6);
                    iVar9 = *(int64_t *)(arg1 + 0x38);
                    if (*(int32_t *)(iVar9 + 0x4c) < (int32_t)uVar6) {
                        if (*(int64_t *)(iVar9 + 0x50) != 0) {
                            func_0x000180460d90();
                        }
                        uVar11 = func_0x00018046d050();
                        *(undefined8 *)(iVar9 + 0x50) = uVar11;
                        *(uint32_t *)(iVar9 + 0x4c) = uVar6;
                    }
                    iVar22 = uVar6 - 1;
                    iVar13 = 0;
                    iVar9 = *(int64_t *)(*(int64_t *)(arg1 + 0x38) + 0x50);
                    iVar18 = iVar22;
                    iVar21 = iVar13;
                    if ((int32_t)uVar6 < 4) goto code_r0x0001800f3e44;
                    do {
                        iVar12 = (int64_t)iVar13;
                        iVar19 = (int64_t)iVar18;
                        fVar24 = *(float *)(iVar8 + iVar12 * 8) - *(float *)(iVar8 + iVar19 * 8);
                        fVar26 = *(float *)(iVar8 + 4 + iVar12 * 8) - *(float *)(iVar8 + 4 + iVar19 * 8);
                        fVar27 = fVar26 * fVar26 + fVar24 * fVar24;
                        if (0.0 < fVar27) {
                            auVar28 = rsqrtss(ZEXT416((uint32_t)fVar27), ZEXT416((uint32_t)fVar27));
                            fVar24 = fVar24 * auVar28._0_4_;
                            fVar26 = fVar26 * auVar28._0_4_;
                        }
                        *(float *)(iVar9 + iVar19 * 8) = fVar26;
                        *(uint32_t *)(iVar9 + 4 + iVar19 * 8) = (uint32_t)fVar24 ^ 0x80000000;
                        fVar24 = *(float *)(iVar8 + 8 + iVar12 * 8) - *(float *)(iVar8 + iVar12 * 8);
                        fVar26 = *(float *)(iVar8 + 0xc + iVar12 * 8) - *(float *)(iVar8 + 4 + iVar12 * 8);
                        fVar27 = fVar26 * fVar26 + fVar24 * fVar24;
                        if (0.0 < fVar27) {
                            auVar28 = rsqrtss(ZEXT416((uint32_t)fVar27), ZEXT416((uint32_t)fVar27));
                            fVar24 = fVar24 * auVar28._0_4_;
                            fVar26 = fVar26 * auVar28._0_4_;
                        }
                        *(float *)(iVar9 + iVar12 * 8) = fVar26;
                        *(uint32_t *)(iVar9 + 4 + iVar12 * 8) = (uint32_t)fVar24 ^ 0x80000000;
                        fVar24 = *(float *)(iVar8 + 0x10 + iVar12 * 8) - *(float *)(iVar8 + 8 + iVar12 * 8);
                        fVar26 = *(float *)(iVar8 + 0x14 + iVar12 * 8) - *(float *)(iVar8 + 0xc + iVar12 * 8);
                        fVar27 = fVar26 * fVar26 + fVar24 * fVar24;
                        if (0.0 < fVar27) {
                            auVar28 = rsqrtss(ZEXT416((uint32_t)fVar27), ZEXT416((uint32_t)fVar27));
                            fVar24 = fVar24 * auVar28._0_4_;
                            fVar26 = fVar26 * auVar28._0_4_;
                        }
                        *(float *)(iVar9 + 8 + iVar12 * 8) = fVar26;
                        *(uint32_t *)(iVar9 + 0xc + iVar12 * 8) = (uint32_t)fVar24 ^ 0x80000000;
                        fVar24 = *(float *)(iVar8 + 0x18 + iVar12 * 8) - *(float *)(iVar8 + 0x10 + iVar12 * 8);
                        fVar26 = *(float *)(iVar8 + 0x1c + iVar12 * 8) - *(float *)(iVar8 + 0x14 + iVar12 * 8);
                        fVar27 = fVar26 * fVar26 + fVar24 * fVar24;
                        if (0.0 < fVar27) {
                            auVar28 = rsqrtss(ZEXT416((uint32_t)fVar27), ZEXT416((uint32_t)fVar27));
                            fVar24 = fVar24 * auVar28._0_4_;
                            fVar26 = fVar26 * auVar28._0_4_;
                        }
                        iVar18 = iVar13 + 3;
                        *(float *)(iVar9 + 0x10 + iVar12 * 8) = fVar26;
                        iVar13 = iVar13 + 4;
                        *(uint32_t *)(iVar9 + 0x14 + iVar12 * 8) = (uint32_t)fVar24 ^ 0x80000000;
                    } while (iVar13 < (int32_t)(uVar6 - 3));
                    while (iVar21 = iVar13, iVar13 < (int32_t)uVar6) {
code_r0x0001800f3e44:
                        iVar12 = (int64_t)iVar18;
                        fVar24 = *(float *)(iVar8 + (int64_t)iVar21 * 8) - *(float *)(iVar8 + iVar12 * 8);
                        fVar26 = *(float *)(iVar8 + 4 + (int64_t)iVar21 * 8) - *(float *)(iVar8 + 4 + iVar12 * 8);
                        fVar27 = fVar26 * fVar26 + fVar24 * fVar24;
                        if (0.0 < fVar27) {
                            auVar28 = rsqrtss(ZEXT416((uint32_t)fVar27), ZEXT416((uint32_t)fVar27));
                            fVar24 = fVar24 * auVar28._0_4_;
                            fVar26 = fVar26 * auVar28._0_4_;
                        }
                        *(float *)(iVar9 + iVar12 * 8) = fVar26;
                        *(uint32_t *)(iVar9 + 4 + iVar12 * 8) = (uint32_t)fVar24 ^ 0x80000000;
                        iVar18 = iVar21;
                        iVar13 = iVar21 + 1;
                    }
                    fVar29 = fVar29 * 0.5;
                    iVar18 = 0;
                    do {
                        iVar12 = (int64_t)iVar18;
                        fVar26 = (*(float *)(iVar9 + (int64_t)iVar22 * 8) + *(float *)(iVar9 + iVar12 * 8)) * 0.5;
                        fVar27 = (*(float *)(iVar9 + 4 + (int64_t)iVar22 * 8) + *(float *)(iVar9 + 4 + iVar12 * 8)) *
                                 0.5;
                        fVar24 = fVar27 * fVar27 + fVar26 * fVar26;
                        if (1e-06 < fVar24) {
                            fVar24 = 1.0 / fVar24;
                            fVar25 = 100.0;
                            if (fVar24 <= 100.0) {
                                fVar25 = fVar24;
                            }
                            fVar26 = fVar26 * fVar25;
                            fVar27 = fVar27 * fVar25;
                        }
                        iVar14 = (int16_t)iVar22 * 2;
                        iVar10 = (int16_t)iVar18 * 2;
                        fVar26 = fVar29 * fVar26;
                        fVar27 = fVar29 * fVar27;
                        iVar17 = iVar10 + iVar23;
                        **(float **)(arg1 + 0x40) = *(float *)(iVar8 + iVar12 * 8) - fVar26;
                        *(float *)(*(int64_t *)(arg1 + 0x40) + 4) = *(float *)(iVar8 + 4 + iVar12 * 8) - fVar27;
                        iVar19 = *(int64_t *)(arg1 + 0x40);
                        *(undefined4 *)(iVar19 + 8) = uVar1;
                        *(undefined4 *)(iVar19 + 0xc) = uVar2;
                        *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar20;
                        *(float *)(*(int64_t *)(arg1 + 0x40) + 0x14) = fVar26 + *(float *)(iVar8 + iVar12 * 8);
                        *(float *)(*(int64_t *)(arg1 + 0x40) + 0x18) = fVar27 + *(float *)(iVar8 + 4 + iVar12 * 8);
                        iVar12 = *(int64_t *)(arg1 + 0x40);
                        *(undefined4 *)(iVar12 + 0x1c) = uVar1;
                        *(undefined4 *)(iVar12 + 0x20) = uVar2;
                        *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar20 & 0xffffff;
                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x28;
                        **(int16_t **)(arg1 + 0x48) = iVar17;
                        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar14 + iVar23;
                        iVar14 = iVar14 + iVar23 + 1;
                        iVar21 = iVar18 + 1;
                        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar14;
                        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar14;
                        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar10 + iVar23 + 1;
                        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar17;
                        *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0xc;
                        iVar22 = iVar18;
                        iVar18 = iVar21;
                    } while (iVar21 < (int32_t)uVar6);
                    *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + (uVar6 * 2 & 0xffff);
                    *(undefined4 *)(arg1 + 0x50) = 0;
                }
                return;
            }
            *(undefined4 *)(arg1 + 0x50) = 0;
            return;
        }
        fcn.180124680(arg1, 6, 4);
        iVar14 = *(int16_t *)(arg1 + 0x34);
        uVar1 = *(undefined4 *)arg3;
        uVar2 = *(undefined4 *)(arg2 + 4);
        uVar7 = *(undefined4 *)arg2;
        uVar3 = (*(undefined4 **)(arg1 + 0x38))[1];
        uVar4 = **(undefined4 **)(arg1 + 0x38);
        uVar5 = *(undefined4 *)(arg3 + 4);
        **(int16_t **)(arg1 + 0x48) = iVar14;
        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar14 + 1;
        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar14 + 2;
        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar14;
        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar14 + 2;
        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar14 + 3;
        **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)arg2;
        iVar8 = *(int64_t *)(arg1 + 0x40);
        *(undefined4 *)(iVar8 + 8) = uVar4;
        *(undefined4 *)(iVar8 + 0xc) = uVar3;
        *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar20;
        iVar8 = *(int64_t *)(arg1 + 0x40);
        *(undefined4 *)(iVar8 + 0x14) = uVar1;
        *(undefined4 *)(iVar8 + 0x18) = uVar2;
        iVar8 = *(int64_t *)(arg1 + 0x40);
        *(undefined4 *)(iVar8 + 0x1c) = uVar4;
        *(undefined4 *)(iVar8 + 0x20) = uVar3;
        *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar20;
        *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x28) = *(undefined8 *)arg3;
        iVar8 = *(int64_t *)(arg1 + 0x40);
        *(undefined4 *)(iVar8 + 0x30) = uVar4;
        *(undefined4 *)(iVar8 + 0x34) = uVar3;
        *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x38) = uVar20;
        iVar8 = *(int64_t *)(arg1 + 0x40);
        *(undefined4 *)(iVar8 + 0x3c) = uVar7;
        *(undefined4 *)(iVar8 + 0x40) = uVar5;
        iVar8 = *(int64_t *)(arg1 + 0x40);
        *(undefined4 *)(iVar8 + 0x44) = uVar4;
        *(undefined4 *)(iVar8 + 0x48) = uVar3;
        *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x4c) = uVar20;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x50;
        *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + 4;
        *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0xc;
    }
    return;
}

// ============================================================
// Function: FUN_1801265bf
// Address: 0x1801265bf
// Size: 277 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

void fcn.180126550(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_a0h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    uint32_t uVar6;
    undefined4 uVar7;
    int64_t iVar8;
    int64_t iVar9;
    int16_t iVar10;
    undefined8 uVar11;
    int64_t iVar12;
    int32_t iVar13;
    int16_t iVar14;
    uint32_t uVar15;
    uint64_t uVar16;
    int16_t iVar17;
    int32_t iVar18;
    int64_t iVar19;
    uint32_t uVar20;
    int32_t iVar21;
    int32_t iVar22;
    int16_t iVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    undefined auVar28 [16];
    float fVar29;
    int64_t var_4h;
    int64_t var_10h;
    int64_t var_18h;
    uint32_t in_stack_00000030;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar20 = (uint32_t)arg4;
    if ((arg4 & 0xff000000U) != 0) {
        if ((0.5 <= (float)arg_28h) && ((in_stack_00000030 & 0x1f0) != 0x100)) {
            var_48h._0_4_ = in_stack_00000030;
            fcn.180125f20(arg1, arg2, arg3, arg4, var_48h);
            uVar6 = *(uint32_t *)(arg1 + 0x50);
            if ((2 < (int32_t)uVar6) && ((arg4 & 0xff000000U) != 0)) {
                iVar8 = *(int64_t *)(arg1 + 0x58);
                uVar1 = **(undefined4 **)(arg1 + 0x38);
                uVar2 = (*(undefined4 **)(arg1 + 0x38))[1];
                if ((*(uint8_t *)(arg1 + 0x30) & 4) == 0) {
                    fcn.180124680(arg1, (uint64_t)((uVar6 - 2) * 3), (uint64_t)uVar6);
                    uVar16 = 0;
                    do {
                        iVar9 = uVar16 * 8;
                        uVar15 = (int32_t)uVar16 + 1;
                        uVar16 = (uint64_t)uVar15;
                        **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar8 + iVar9);
                        iVar9 = *(int64_t *)(arg1 + 0x40);
                        *(undefined4 *)(iVar9 + 8) = uVar1;
                        *(undefined4 *)(iVar9 + 0xc) = uVar2;
                        *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar20;
                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x14;
                    } while ((int32_t)uVar15 < (int32_t)uVar6);
                    iVar18 = 2;
                    do {
                        **(undefined2 **)(arg1 + 0x48) = *(undefined2 *)(arg1 + 0x34);
                        iVar14 = (int16_t)iVar18;
                        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar14 + -1 + *(int16_t *)(arg1 + 0x34);
                        iVar18 = iVar18 + 1;
                        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar14 + *(int16_t *)(arg1 + 0x34);
                        *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 6;
                    } while (iVar18 < (int32_t)uVar6);
                    *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + (uVar6 & 0xffff);
                    *(undefined4 *)(arg1 + 0x50) = 0;
                } else {
                    fVar29 = *(float *)(arg1 + 0xd0);
                    fcn.180124680(arg1, (uint64_t)(uVar6 * 9 - 6), (uint64_t)(uVar6 * 2));
                    uVar7 = *(undefined4 *)(arg1 + 0x34);
                    iVar18 = 2;
                    do {
                        iVar14 = (int16_t)iVar18;
                        iVar18 = iVar18 + 1;
                        iVar23 = (int16_t)uVar7;
                        iVar14 = iVar14 * 2 + iVar23;
                        **(int16_t **)(arg1 + 0x48) = iVar23;
                        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar14 + -2;
                        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar14;
                        *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 6;
                    } while (iVar18 < (int32_t)uVar6);
                    iVar9 = *(int64_t *)(arg1 + 0x38);
                    if (*(int32_t *)(iVar9 + 0x4c) < (int32_t)uVar6) {
                        if (*(int64_t *)(iVar9 + 0x50) != 0) {
                            func_0x000180460d90();
                        }
                        uVar11 = func_0x00018046d050();
                        *(undefined8 *)(iVar9 + 0x50) = uVar11;
                        *(uint32_t *)(iVar9 + 0x4c) = uVar6;
                    }
                    iVar22 = uVar6 - 1;
                    iVar13 = 0;
                    iVar9 = *(int64_t *)(*(int64_t *)(arg1 + 0x38) + 0x50);
                    iVar18 = iVar22;
                    iVar21 = iVar13;
                    if ((int32_t)uVar6 < 4) goto code_r0x0001800f3e44;
                    do {
                        iVar12 = (int64_t)iVar13;
                        iVar19 = (int64_t)iVar18;
                        fVar24 = *(float *)(iVar8 + iVar12 * 8) - *(float *)(iVar8 + iVar19 * 8);
                        fVar26 = *(float *)(iVar8 + 4 + iVar12 * 8) - *(float *)(iVar8 + 4 + iVar19 * 8);
                        fVar27 = fVar26 * fVar26 + fVar24 * fVar24;
                        if (0.0 < fVar27) {
                            auVar28 = rsqrtss(ZEXT416((uint32_t)fVar27), ZEXT416((uint32_t)fVar27));
                            fVar24 = fVar24 * auVar28._0_4_;
                            fVar26 = fVar26 * auVar28._0_4_;
                        }
                        *(float *)(iVar9 + iVar19 * 8) = fVar26;
                        *(uint32_t *)(iVar9 + 4 + iVar19 * 8) = (uint32_t)fVar24 ^ 0x80000000;
                        fVar24 = *(float *)(iVar8 + 8 + iVar12 * 8) - *(float *)(iVar8 + iVar12 * 8);
                        fVar26 = *(float *)(iVar8 + 0xc + iVar12 * 8) - *(float *)(iVar8 + 4 + iVar12 * 8);
                        fVar27 = fVar26 * fVar26 + fVar24 * fVar24;
                        if (0.0 < fVar27) {
                            auVar28 = rsqrtss(ZEXT416((uint32_t)fVar27), ZEXT416((uint32_t)fVar27));
                            fVar24 = fVar24 * auVar28._0_4_;
                            fVar26 = fVar26 * auVar28._0_4_;
                        }
                        *(float *)(iVar9 + iVar12 * 8) = fVar26;
                        *(uint32_t *)(iVar9 + 4 + iVar12 * 8) = (uint32_t)fVar24 ^ 0x80000000;
                        fVar24 = *(float *)(iVar8 + 0x10 + iVar12 * 8) - *(float *)(iVar8 + 8 + iVar12 * 8);
                        fVar26 = *(float *)(iVar8 + 0x14 + iVar12 * 8) - *(float *)(iVar8 + 0xc + iVar12 * 8);
                        fVar27 = fVar26 * fVar26 + fVar24 * fVar24;
                        if (0.0 < fVar27) {
                            auVar28 = rsqrtss(ZEXT416((uint32_t)fVar27), ZEXT416((uint32_t)fVar27));
                            fVar24 = fVar24 * auVar28._0_4_;
                            fVar26 = fVar26 * auVar28._0_4_;
                        }
                        *(float *)(iVar9 + 8 + iVar12 * 8) = fVar26;
                        *(uint32_t *)(iVar9 + 0xc + iVar12 * 8) = (uint32_t)fVar24 ^ 0x80000000;
                        fVar24 = *(float *)(iVar8 + 0x18 + iVar12 * 8) - *(float *)(iVar8 + 0x10 + iVar12 * 8);
                        fVar26 = *(float *)(iVar8 + 0x1c + iVar12 * 8) - *(float *)(iVar8 + 0x14 + iVar12 * 8);
                        fVar27 = fVar26 * fVar26 + fVar24 * fVar24;
                        if (0.0 < fVar27) {
                            auVar28 = rsqrtss(ZEXT416((uint32_t)fVar27), ZEXT416((uint32_t)fVar27));
                            fVar24 = fVar24 * auVar28._0_4_;
                            fVar26 = fVar26 * auVar28._0_4_;
                        }
                        iVar18 = iVar13 + 3;
                        *(float *)(iVar9 + 0x10 + iVar12 * 8) = fVar26;
                        iVar13 = iVar13 + 4;
                        *(uint32_t *)(iVar9 + 0x14 + iVar12 * 8) = (uint32_t)fVar24 ^ 0x80000000;
                    } while (iVar13 < (int32_t)(uVar6 - 3));
                    while (iVar21 = iVar13, iVar13 < (int32_t)uVar6) {
code_r0x0001800f3e44:
                        iVar12 = (int64_t)iVar18;
                        fVar24 = *(float *)(iVar8 + (int64_t)iVar21 * 8) - *(float *)(iVar8 + iVar12 * 8);
                        fVar26 = *(float *)(iVar8 + 4 + (int64_t)iVar21 * 8) - *(float *)(iVar8 + 4 + iVar12 * 8);
                        fVar27 = fVar26 * fVar26 + fVar24 * fVar24;
                        if (0.0 < fVar27) {
                            auVar28 = rsqrtss(ZEXT416((uint32_t)fVar27), ZEXT416((uint32_t)fVar27));
                            fVar24 = fVar24 * auVar28._0_4_;
                            fVar26 = fVar26 * auVar28._0_4_;
                        }
                        *(float *)(iVar9 + iVar12 * 8) = fVar26;
                        *(uint32_t *)(iVar9 + 4 + iVar12 * 8) = (uint32_t)fVar24 ^ 0x80000000;
                        iVar18 = iVar21;
                        iVar13 = iVar21 + 1;
                    }
                    fVar29 = fVar29 * 0.5;
                    iVar18 = 0;
                    do {
                        iVar12 = (int64_t)iVar18;
                        fVar26 = (*(float *)(iVar9 + (int64_t)iVar22 * 8) + *(float *)(iVar9 + iVar12 * 8)) * 0.5;
                        fVar27 = (*(float *)(iVar9 + 4 + (int64_t)iVar22 * 8) + *(float *)(iVar9 + 4 + iVar12 * 8)) *
                                 0.5;
                        fVar24 = fVar27 * fVar27 + fVar26 * fVar26;
                        if (1e-06 < fVar24) {
                            fVar24 = 1.0 / fVar24;
                            fVar25 = 100.0;
                            if (fVar24 <= 100.0) {
                                fVar25 = fVar24;
                            }
                            fVar26 = fVar26 * fVar25;
                            fVar27 = fVar27 * fVar25;
                        }
                        iVar14 = (int16_t)iVar22 * 2;
                        iVar10 = (int16_t)iVar18 * 2;
                        fVar26 = fVar29 * fVar26;
                        fVar27 = fVar29 * fVar27;
                        iVar17 = iVar10 + iVar23;
                        **(float **)(arg1 + 0x40) = *(float *)(iVar8 + iVar12 * 8) - fVar26;
                        *(float *)(*(int64_t *)(arg1 + 0x40) + 4) = *(float *)(iVar8 + 4 + iVar12 * 8) - fVar27;
                        iVar19 = *(int64_t *)(arg1 + 0x40);
                        *(undefined4 *)(iVar19 + 8) = uVar1;
                        *(undefined4 *)(iVar19 + 0xc) = uVar2;
                        *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar20;
                        *(float *)(*(int64_t *)(arg1 + 0x40) + 0x14) = fVar26 + *(float *)(iVar8 + iVar12 * 8);
                        *(float *)(*(int64_t *)(arg1 + 0x40) + 0x18) = fVar27 + *(float *)(iVar8 + 4 + iVar12 * 8);
                        iVar12 = *(int64_t *)(arg1 + 0x40);
                        *(undefined4 *)(iVar12 + 0x1c) = uVar1;
                        *(undefined4 *)(iVar12 + 0x20) = uVar2;
                        *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar20 & 0xffffff;
                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x28;
                        **(int16_t **)(arg1 + 0x48) = iVar17;
                        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar14 + iVar23;
                        iVar14 = iVar14 + iVar23 + 1;
                        iVar21 = iVar18 + 1;
                        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar14;
                        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar14;
                        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar10 + iVar23 + 1;
                        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar17;
                        *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0xc;
                        iVar22 = iVar18;
                        iVar18 = iVar21;
                    } while (iVar21 < (int32_t)uVar6);
                    *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + (uVar6 * 2 & 0xffff);
                    *(undefined4 *)(arg1 + 0x50) = 0;
                }
                return;
            }
            *(undefined4 *)(arg1 + 0x50) = 0;
            return;
        }
        fcn.180124680(arg1, 6, 4);
        iVar14 = *(int16_t *)(arg1 + 0x34);
        uVar1 = *(undefined4 *)arg3;
        uVar2 = *(undefined4 *)(arg2 + 4);
        uVar7 = *(undefined4 *)arg2;
        uVar3 = (*(undefined4 **)(arg1 + 0x38))[1];
        uVar4 = **(undefined4 **)(arg1 + 0x38);
        uVar5 = *(undefined4 *)(arg3 + 4);
        **(int16_t **)(arg1 + 0x48) = iVar14;
        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar14 + 1;
        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar14 + 2;
        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar14;
        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar14 + 2;
        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar14 + 3;
        **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)arg2;
        iVar8 = *(int64_t *)(arg1 + 0x40);
        *(undefined4 *)(iVar8 + 8) = uVar4;
        *(undefined4 *)(iVar8 + 0xc) = uVar3;
        *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar20;
        iVar8 = *(int64_t *)(arg1 + 0x40);
        *(undefined4 *)(iVar8 + 0x14) = uVar1;
        *(undefined4 *)(iVar8 + 0x18) = uVar2;
        iVar8 = *(int64_t *)(arg1 + 0x40);
        *(undefined4 *)(iVar8 + 0x1c) = uVar4;
        *(undefined4 *)(iVar8 + 0x20) = uVar3;
        *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar20;
        *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x28) = *(undefined8 *)arg3;
        iVar8 = *(int64_t *)(arg1 + 0x40);
        *(undefined4 *)(iVar8 + 0x30) = uVar4;
        *(undefined4 *)(iVar8 + 0x34) = uVar3;
        *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x38) = uVar20;
        iVar8 = *(int64_t *)(arg1 + 0x40);
        *(undefined4 *)(iVar8 + 0x3c) = uVar7;
        *(undefined4 *)(iVar8 + 0x40) = uVar5;
        iVar8 = *(int64_t *)(arg1 + 0x40);
        *(undefined4 *)(iVar8 + 0x44) = uVar4;
        *(undefined4 *)(iVar8 + 0x48) = uVar3;
        *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x4c) = uVar20;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x50;
        *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + 4;
        *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0xc;
    }
    return;
}

// ============================================================
// Function: FUN_1801266d4
// Address: 0x1801266d4
// Size: 1 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

void fcn.180126550(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_a0h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    uint32_t uVar6;
    undefined4 uVar7;
    int64_t iVar8;
    int64_t iVar9;
    int16_t iVar10;
    undefined8 uVar11;
    int64_t iVar12;
    int32_t iVar13;
    int16_t iVar14;
    uint32_t uVar15;
    uint64_t uVar16;
    int16_t iVar17;
    int32_t iVar18;
    int64_t iVar19;
    uint32_t uVar20;
    int32_t iVar21;
    int32_t iVar22;
    int16_t iVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    undefined auVar28 [16];
    float fVar29;
    int64_t var_4h;
    int64_t var_10h;
    int64_t var_18h;
    uint32_t in_stack_00000030;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar20 = (uint32_t)arg4;
    if ((arg4 & 0xff000000U) != 0) {
        if ((0.5 <= (float)arg_28h) && ((in_stack_00000030 & 0x1f0) != 0x100)) {
            var_48h._0_4_ = in_stack_00000030;
            fcn.180125f20(arg1, arg2, arg3, arg4, var_48h);
            uVar6 = *(uint32_t *)(arg1 + 0x50);
            if ((2 < (int32_t)uVar6) && ((arg4 & 0xff000000U) != 0)) {
                iVar8 = *(int64_t *)(arg1 + 0x58);
                uVar1 = **(undefined4 **)(arg1 + 0x38);
                uVar2 = (*(undefined4 **)(arg1 + 0x38))[1];
                if ((*(uint8_t *)(arg1 + 0x30) & 4) == 0) {
                    fcn.180124680(arg1, (uint64_t)((uVar6 - 2) * 3), (uint64_t)uVar6);
                    uVar16 = 0;
                    do {
                        iVar9 = uVar16 * 8;
                        uVar15 = (int32_t)uVar16 + 1;
                        uVar16 = (uint64_t)uVar15;
                        **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar8 + iVar9);
                        iVar9 = *(int64_t *)(arg1 + 0x40);
                        *(undefined4 *)(iVar9 + 8) = uVar1;
                        *(undefined4 *)(iVar9 + 0xc) = uVar2;
                        *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar20;
                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x14;
                    } while ((int32_t)uVar15 < (int32_t)uVar6);
                    iVar18 = 2;
                    do {
                        **(undefined2 **)(arg1 + 0x48) = *(undefined2 *)(arg1 + 0x34);
                        iVar14 = (int16_t)iVar18;
                        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar14 + -1 + *(int16_t *)(arg1 + 0x34);
                        iVar18 = iVar18 + 1;
                        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar14 + *(int16_t *)(arg1 + 0x34);
                        *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 6;
                    } while (iVar18 < (int32_t)uVar6);
                    *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + (uVar6 & 0xffff);
                    *(undefined4 *)(arg1 + 0x50) = 0;
                } else {
                    fVar29 = *(float *)(arg1 + 0xd0);
                    fcn.180124680(arg1, (uint64_t)(uVar6 * 9 - 6), (uint64_t)(uVar6 * 2));
                    uVar7 = *(undefined4 *)(arg1 + 0x34);
                    iVar18 = 2;
                    do {
                        iVar14 = (int16_t)iVar18;
                        iVar18 = iVar18 + 1;
                        iVar23 = (int16_t)uVar7;
                        iVar14 = iVar14 * 2 + iVar23;
                        **(int16_t **)(arg1 + 0x48) = iVar23;
                        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar14 + -2;
                        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar14;
                        *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 6;
                    } while (iVar18 < (int32_t)uVar6);
                    iVar9 = *(int64_t *)(arg1 + 0x38);
                    if (*(int32_t *)(iVar9 + 0x4c) < (int32_t)uVar6) {
                        if (*(int64_t *)(iVar9 + 0x50) != 0) {
                            func_0x000180460d90();
                        }
                        uVar11 = func_0x00018046d050();
                        *(undefined8 *)(iVar9 + 0x50) = uVar11;
                        *(uint32_t *)(iVar9 + 0x4c) = uVar6;
                    }
                    iVar22 = uVar6 - 1;
                    iVar13 = 0;
                    iVar9 = *(int64_t *)(*(int64_t *)(arg1 + 0x38) + 0x50);
                    iVar18 = iVar22;
                    iVar21 = iVar13;
                    if ((int32_t)uVar6 < 4) goto code_r0x0001800f3e44;
                    do {
                        iVar12 = (int64_t)iVar13;
                        iVar19 = (int64_t)iVar18;
                        fVar24 = *(float *)(iVar8 + iVar12 * 8) - *(float *)(iVar8 + iVar19 * 8);
                        fVar26 = *(float *)(iVar8 + 4 + iVar12 * 8) - *(float *)(iVar8 + 4 + iVar19 * 8);
                        fVar27 = fVar26 * fVar26 + fVar24 * fVar24;
                        if (0.0 < fVar27) {
                            auVar28 = rsqrtss(ZEXT416((uint32_t)fVar27), ZEXT416((uint32_t)fVar27));
                            fVar24 = fVar24 * auVar28._0_4_;
                            fVar26 = fVar26 * auVar28._0_4_;
                        }
                        *(float *)(iVar9 + iVar19 * 8) = fVar26;
                        *(uint32_t *)(iVar9 + 4 + iVar19 * 8) = (uint32_t)fVar24 ^ 0x80000000;
                        fVar24 = *(float *)(iVar8 + 8 + iVar12 * 8) - *(float *)(iVar8 + iVar12 * 8);
                        fVar26 = *(float *)(iVar8 + 0xc + iVar12 * 8) - *(float *)(iVar8 + 4 + iVar12 * 8);
                        fVar27 = fVar26 * fVar26 + fVar24 * fVar24;
                        if (0.0 < fVar27) {
                            auVar28 = rsqrtss(ZEXT416((uint32_t)fVar27), ZEXT416((uint32_t)fVar27));
                            fVar24 = fVar24 * auVar28._0_4_;
                            fVar26 = fVar26 * auVar28._0_4_;
                        }
                        *(float *)(iVar9 + iVar12 * 8) = fVar26;
                        *(uint32_t *)(iVar9 + 4 + iVar12 * 8) = (uint32_t)fVar24 ^ 0x80000000;
                        fVar24 = *(float *)(iVar8 + 0x10 + iVar12 * 8) - *(float *)(iVar8 + 8 + iVar12 * 8);
                        fVar26 = *(float *)(iVar8 + 0x14 + iVar12 * 8) - *(float *)(iVar8 + 0xc + iVar12 * 8);
                        fVar27 = fVar26 * fVar26 + fVar24 * fVar24;
                        if (0.0 < fVar27) {
                            auVar28 = rsqrtss(ZEXT416((uint32_t)fVar27), ZEXT416((uint32_t)fVar27));
                            fVar24 = fVar24 * auVar28._0_4_;
                            fVar26 = fVar26 * auVar28._0_4_;
                        }
                        *(float *)(iVar9 + 8 + iVar12 * 8) = fVar26;
                        *(uint32_t *)(iVar9 + 0xc + iVar12 * 8) = (uint32_t)fVar24 ^ 0x80000000;
                        fVar24 = *(float *)(iVar8 + 0x18 + iVar12 * 8) - *(float *)(iVar8 + 0x10 + iVar12 * 8);
                        fVar26 = *(float *)(iVar8 + 0x1c + iVar12 * 8) - *(float *)(iVar8 + 0x14 + iVar12 * 8);
                        fVar27 = fVar26 * fVar26 + fVar24 * fVar24;
                        if (0.0 < fVar27) {
                            auVar28 = rsqrtss(ZEXT416((uint32_t)fVar27), ZEXT416((uint32_t)fVar27));
                            fVar24 = fVar24 * auVar28._0_4_;
                            fVar26 = fVar26 * auVar28._0_4_;
                        }
                        iVar18 = iVar13 + 3;
                        *(float *)(iVar9 + 0x10 + iVar12 * 8) = fVar26;
                        iVar13 = iVar13 + 4;
                        *(uint32_t *)(iVar9 + 0x14 + iVar12 * 8) = (uint32_t)fVar24 ^ 0x80000000;
                    } while (iVar13 < (int32_t)(uVar6 - 3));
                    while (iVar21 = iVar13, iVar13 < (int32_t)uVar6) {
code_r0x0001800f3e44:
                        iVar12 = (int64_t)iVar18;
                        fVar24 = *(float *)(iVar8 + (int64_t)iVar21 * 8) - *(float *)(iVar8 + iVar12 * 8);
                        fVar26 = *(float *)(iVar8 + 4 + (int64_t)iVar21 * 8) - *(float *)(iVar8 + 4 + iVar12 * 8);
                        fVar27 = fVar26 * fVar26 + fVar24 * fVar24;
                        if (0.0 < fVar27) {
                            auVar28 = rsqrtss(ZEXT416((uint32_t)fVar27), ZEXT416((uint32_t)fVar27));
                            fVar24 = fVar24 * auVar28._0_4_;
                            fVar26 = fVar26 * auVar28._0_4_;
                        }
                        *(float *)(iVar9 + iVar12 * 8) = fVar26;
                        *(uint32_t *)(iVar9 + 4 + iVar12 * 8) = (uint32_t)fVar24 ^ 0x80000000;
                        iVar18 = iVar21;
                        iVar13 = iVar21 + 1;
                    }
                    fVar29 = fVar29 * 0.5;
                    iVar18 = 0;
                    do {
                        iVar12 = (int64_t)iVar18;
                        fVar26 = (*(float *)(iVar9 + (int64_t)iVar22 * 8) + *(float *)(iVar9 + iVar12 * 8)) * 0.5;
                        fVar27 = (*(float *)(iVar9 + 4 + (int64_t)iVar22 * 8) + *(float *)(iVar9 + 4 + iVar12 * 8)) *
                                 0.5;
                        fVar24 = fVar27 * fVar27 + fVar26 * fVar26;
                        if (1e-06 < fVar24) {
                            fVar24 = 1.0 / fVar24;
                            fVar25 = 100.0;
                            if (fVar24 <= 100.0) {
                                fVar25 = fVar24;
                            }
                            fVar26 = fVar26 * fVar25;
                            fVar27 = fVar27 * fVar25;
                        }
                        iVar14 = (int16_t)iVar22 * 2;
                        iVar10 = (int16_t)iVar18 * 2;
                        fVar26 = fVar29 * fVar26;
                        fVar27 = fVar29 * fVar27;
                        iVar17 = iVar10 + iVar23;
                        **(float **)(arg1 + 0x40) = *(float *)(iVar8 + iVar12 * 8) - fVar26;
                        *(float *)(*(int64_t *)(arg1 + 0x40) + 4) = *(float *)(iVar8 + 4 + iVar12 * 8) - fVar27;
                        iVar19 = *(int64_t *)(arg1 + 0x40);
                        *(undefined4 *)(iVar19 + 8) = uVar1;
                        *(undefined4 *)(iVar19 + 0xc) = uVar2;
                        *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar20;
                        *(float *)(*(int64_t *)(arg1 + 0x40) + 0x14) = fVar26 + *(float *)(iVar8 + iVar12 * 8);
                        *(float *)(*(int64_t *)(arg1 + 0x40) + 0x18) = fVar27 + *(float *)(iVar8 + 4 + iVar12 * 8);
                        iVar12 = *(int64_t *)(arg1 + 0x40);
                        *(undefined4 *)(iVar12 + 0x1c) = uVar1;
                        *(undefined4 *)(iVar12 + 0x20) = uVar2;
                        *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar20 & 0xffffff;
                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x28;
                        **(int16_t **)(arg1 + 0x48) = iVar17;
                        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar14 + iVar23;
                        iVar14 = iVar14 + iVar23 + 1;
                        iVar21 = iVar18 + 1;
                        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar14;
                        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar14;
                        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar10 + iVar23 + 1;
                        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar17;
                        *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0xc;
                        iVar22 = iVar18;
                        iVar18 = iVar21;
                    } while (iVar21 < (int32_t)uVar6);
                    *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + (uVar6 * 2 & 0xffff);
                    *(undefined4 *)(arg1 + 0x50) = 0;
                }
                return;
            }
            *(undefined4 *)(arg1 + 0x50) = 0;
            return;
        }
        fcn.180124680(arg1, 6, 4);
        iVar14 = *(int16_t *)(arg1 + 0x34);
        uVar1 = *(undefined4 *)arg3;
        uVar2 = *(undefined4 *)(arg2 + 4);
        uVar7 = *(undefined4 *)arg2;
        uVar3 = (*(undefined4 **)(arg1 + 0x38))[1];
        uVar4 = **(undefined4 **)(arg1 + 0x38);
        uVar5 = *(undefined4 *)(arg3 + 4);
        **(int16_t **)(arg1 + 0x48) = iVar14;
        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar14 + 1;
        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar14 + 2;
        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar14;
        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar14 + 2;
        *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar14 + 3;
        **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)arg2;
        iVar8 = *(int64_t *)(arg1 + 0x40);
        *(undefined4 *)(iVar8 + 8) = uVar4;
        *(undefined4 *)(iVar8 + 0xc) = uVar3;
        *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar20;
        iVar8 = *(int64_t *)(arg1 + 0x40);
        *(undefined4 *)(iVar8 + 0x14) = uVar1;
        *(undefined4 *)(iVar8 + 0x18) = uVar2;
        iVar8 = *(int64_t *)(arg1 + 0x40);
        *(undefined4 *)(iVar8 + 0x1c) = uVar4;
        *(undefined4 *)(iVar8 + 0x20) = uVar3;
        *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar20;
        *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x28) = *(undefined8 *)arg3;
        iVar8 = *(int64_t *)(arg1 + 0x40);
        *(undefined4 *)(iVar8 + 0x30) = uVar4;
        *(undefined4 *)(iVar8 + 0x34) = uVar3;
        *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x38) = uVar20;
        iVar8 = *(int64_t *)(arg1 + 0x40);
        *(undefined4 *)(iVar8 + 0x3c) = uVar7;
        *(undefined4 *)(iVar8 + 0x40) = uVar5;
        iVar8 = *(int64_t *)(arg1 + 0x40);
        *(undefined4 *)(iVar8 + 0x44) = uVar4;
        *(undefined4 *)(iVar8 + 0x48) = uVar3;
        *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x4c) = uVar20;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x50;
        *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + 4;
        *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0xc;
    }
    return;
}

// ============================================================
// Function: FUN_1801266e0
// Address: 0x1801266e0
// Size: 125 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch

void fcn.1801266e0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined4 in_stack_fffffffffffffff4;
    
    if ((arg_28h & 0xff000000U) != 0) {
        fcn.1800f3b50();
        fcn.1800f3b50(arg1, arg3);
        fcn.1800f3b50(arg1, arg4);
        fcn.1801248e0(arg1, *(int64_t *)(arg1 + 0x58), (uint64_t)*(uint32_t *)(arg1 + 0x50), arg_28h & 0xffffffff, 
                      CONCAT44(var_18h._4_4_, 1), CONCAT44(in_stack_fffffffffffffff4, (undefined4)arg_30h));
        *(undefined4 *)(arg1 + 0x50) = 0;
    }
    return;
}

