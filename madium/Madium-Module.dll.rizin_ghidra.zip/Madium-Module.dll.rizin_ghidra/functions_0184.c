// Chunk 184 - 50 functions

// ============================================================
// Function: FUN_180244040
// Address: 0x180244040
// Size: 444 bytes
// ============================================================
undefined8 fcn.180244040(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined *puVar3;
    uint64_t uVar4;
    undefined8 uVar5;
    int64_t *in_RCX;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180244060;
    iVar2 = func_0x00018045a350();
    iVar2 = -iVar2;
    piVar8 = (int64_t *)in_RCX[5];
    if (piVar8 == (int64_t *)0x0) {
code_r0x0001802440f9:
        uVar5 = 0;
    } else {
        do {
            uVar7 = in_RCX[3] - piVar8[3];
            if ((uVar7 == 0) && (((*(uint32_t *)(piVar8 + 4) & 1) != 0 || ((*(uint32_t *)(piVar8 + 4) & 2) != 0))))
            goto code_r0x0001802440f9;
            uVar9 = piVar8[2];
            if (uVar9 == 0) {
                if (((*(uint8_t *)(in_RCX + 6) & 1) != 0) && (*piVar8 != 0)) {
                    if (uVar7 == 0) {
                        if ((*(uint8_t *)(piVar8 + 4) & 2) != 0) goto code_r0x0001802441e6;
                        uVar9 = 1;
                    } else {
                        uVar9 = 1;
                        uVar4 = uVar7;
                        while (uVar4 = uVar4 >> 8, uVar4 != 0) {
                            uVar9 = uVar9 + 1;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802441ba;
                    iVar1 = func_0x0001802446f0(in_RCX, uVar7, uVar9);
                    if (iVar1 == 0) goto code_r0x0001802440f9;
                    if (0x7f < uVar7) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802441de;
                        iVar1 = func_0x0001802446f0(in_RCX, uVar9 | 0x80, 1);
                        if (iVar1 == 0) goto code_r0x0001802440f9;
                    }
                }
            } else {
                iVar6 = in_RCX[1];
                if ((iVar6 != 0) || ((*in_RCX != 0 && (iVar6 = *(int64_t *)(*in_RCX + 8), iVar6 != 0)))) {
                    iVar6 = iVar6 + piVar8[1];
                    if ((*(uint8_t *)(piVar8 + 4) & 4) == 0) {
                        if (iVar6 != 0) {
                            puVar3 = (undefined *)((uVar9 - 1) + iVar6);
                            do {
                                *puVar3 = (char)uVar7;
                                puVar3 = puVar3 + -1;
                                uVar7 = uVar7 >> 8;
                                uVar9 = uVar9 - 1;
                            } while (uVar9 != 0);
                            if (uVar7 != 0) goto code_r0x0001802440f9;
                        }
                    } else if (iVar6 != 0) {
                        if (uVar7 < 0x40) {
                            uVar4 = 1;
code_r0x000180244156:
                            if (uVar9 < uVar4) goto code_r0x0001802440f9;
                        } else {
                            if (uVar7 < 0x4000) {
                                uVar4 = 2;
                                goto code_r0x000180244156;
                            }
                            if (uVar7 < 0x40000000) {
                                uVar4 = 4;
                                goto code_r0x000180244156;
                            }
                            if (uVar7 < 0x4000000000000000) {
                                uVar4 = 8;
                                goto code_r0x000180244156;
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180244163;
                        func_0x000180274fd0(iVar6, uVar7);
                    }
                }
            }
code_r0x0001802441e6:
            piVar8 = (int64_t *)*piVar8;
        } while (piVar8 != (int64_t *)0x0);
        uVar5 = 1;
    }
    return uVar5;
}

// ============================================================
// Function: FUN_180244200
// Address: 0x180244200
// Size: 39 bytes
// ============================================================
int32_t fcn.180244200(int64_t arg_28h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18024420c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((*(int64_t **)(in_RCX + 0x28) != (int64_t *)0x0) && (**(int64_t **)(in_RCX + 0x28) == 0)) {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180244231;
        iVar2 = fcn.180244d00(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3));
        if (iVar2 != 0) {
            uVar1 = *(undefined8 *)(in_RCX + 0x28);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024424d;
            fcn.180224990(uVar1, 0x1804e4190, 0x167);
            *(undefined8 *)(in_RCX + 0x28) = 0;
        }
        return iVar2;
    }
    return 0;
}

// ============================================================
// Function: FUN_180244227
// Address: 0x180244227
// Size: 59 bytes
// ============================================================
int32_t fcn.180244200(int64_t arg_28h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18024420c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((*(int64_t **)(in_RCX + 0x28) != (int64_t *)0x0) && (**(int64_t **)(in_RCX + 0x28) == 0)) {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180244231;
        iVar2 = fcn.180244d00(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3));
        if (iVar2 != 0) {
            uVar1 = *(undefined8 *)(in_RCX + 0x28);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024424d;
            fcn.180224990(uVar1, 0x1804e4190, 0x167);
            *(undefined8 *)(in_RCX + 0x28) = 0;
        }
        return iVar2;
    }
    return 0;
}

// ============================================================
// Function: FUN_180244262
// Address: 0x180244262
// Size: 8 bytes
// ============================================================
int32_t fcn.180244200(int64_t arg_28h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18024420c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((*(int64_t **)(in_RCX + 0x28) != (int64_t *)0x0) && (**(int64_t **)(in_RCX + 0x28) == 0)) {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180244231;
        iVar2 = fcn.180244d00(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3));
        if (iVar2 != 0) {
            uVar1 = *(undefined8 *)(in_RCX + 0x28);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024424d;
            fcn.180224990(uVar1, 0x1804e4190, 0x167);
            *(undefined8 *)(in_RCX + 0x28) = 0;
        }
        return iVar2;
    }
    return 0;
}

// ============================================================
// Function: FUN_180244300
// Address: 0x180244300
// Size: 102 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.180244300(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t *in_RCX;
    int64_t in_RDX;
    bool bVar2;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180244310;
    iVar1 = fcn.18045a350();
    bVar2 = false;
    if (in_RDX != 0) {
        *(uint32_t *)(in_RCX + 6) = *(uint32_t *)(in_RCX + 6) & 0xfffffffe;
        *in_RCX = in_RDX;
        in_RCX[1] = 0;
        in_RCX[4] = -1;
        in_RCX[2] = 0;
        in_RCX[3] = 0;
        *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x18024434f;
        iVar1 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + -iVar1));
        bVar2 = iVar1 != 0;
        in_RCX[5] = iVar1;
    }
    return bVar2;
}

// ============================================================
// Function: FUN_180244370
// Address: 0x180244370
// Size: 53 bytes
// ============================================================
bool fcn.180244370(int64_t arg_28h)
{
    int64_t iVar1;
    undefined8 *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t in_R8;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18024437c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if ((in_RDX != 0) && (in_R8 != 0)) {
        *(uint32_t *)(in_RCX + 6) = *(uint32_t *)(in_RCX + 6) | 1;
        in_RCX[1] = in_RDX;
        in_RCX[4] = in_R8;
        *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RBX;
        *in_RCX = 0;
        in_RCX[2] = 0;
        in_RCX[3] = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802443c1;
        iVar1 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
        in_RCX[5] = iVar1;
        return iVar1 != 0;
    }
    return false;
}

// ============================================================
// Function: FUN_1802443a5
// Address: 0x1802443a5
// Size: 51 bytes
// ============================================================
bool fcn.180244370(int64_t arg_28h)
{
    int64_t iVar1;
    undefined8 *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t in_R8;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18024437c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if ((in_RDX != 0) && (in_R8 != 0)) {
        *(uint32_t *)(in_RCX + 6) = *(uint32_t *)(in_RCX + 6) | 1;
        in_RCX[1] = in_RDX;
        in_RCX[4] = in_R8;
        *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RBX;
        *in_RCX = 0;
        in_RCX[2] = 0;
        in_RCX[3] = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802443c1;
        iVar1 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
        in_RCX[5] = iVar1;
        return iVar1 != 0;
    }
    return false;
}

// ============================================================
// Function: FUN_1802443d8
// Address: 0x1802443d8
// Size: 8 bytes
// ============================================================
bool fcn.180244370(int64_t arg_28h)
{
    int64_t iVar1;
    undefined8 *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t in_R8;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18024437c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if ((in_RDX != 0) && (in_R8 != 0)) {
        *(uint32_t *)(in_RCX + 6) = *(uint32_t *)(in_RCX + 6) | 1;
        in_RCX[1] = in_RDX;
        in_RCX[4] = in_R8;
        *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RBX;
        *in_RCX = 0;
        in_RCX[2] = 0;
        in_RCX[3] = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802443c1;
        iVar1 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
        in_RCX[5] = iVar1;
        return iVar1 != 0;
    }
    return false;
}

// ============================================================
// Function: FUN_1802443e0
// Address: 0x1802443e0
// Size: 104 bytes
// ============================================================
undefined8 fcn.1802443e0(int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *in_RCX;
    int64_t iVar4;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t in_R8;
    undefined8 auStackX_18 [2];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RDX == 0) {
        return 0;
    }
    in_RCX[1] = 0;
    *in_RCX = in_RDX;
    if (in_R8 - 1U < 7) {
        iVar4 = in_R8 + -1 + (1LL << (((uint8_t)in_R8 & 7) << 3));
    } else {
        iVar4 = -1;
    }
    *(uint32_t *)(in_RCX + 6) = *(uint32_t *)(in_RCX + 6) & 0xfffffffe;
    in_RCX[4] = iVar4;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x180244f15;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    in_RCX[2] = 0;
    in_RCX[3] = 0;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar2) = 0x180244f3f;
    iVar3 = fcn.180224d60(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar2));
    in_RCX[5] = iVar3;
    if (iVar3 == 0) {
        return 0;
    }
    if (in_R8 != 0) {
        *(int64_t *)(iVar3 + 0x18) = in_R8;
        *(int64_t *)(in_RCX[5] + 0x10) = in_R8;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar2) = 0x180244f69;
        iVar1 = fcn.180244860(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar4 + iVar2));
        if (iVar1 == 0) {
            iVar3 = in_RCX[5];
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar2) = 0x180244f83;
            fcn.180224990(iVar3, 0x1804e4190, 0x78);
            in_RCX[5] = 0;
            return 0;
        }
        in_RCX[3] = in_RCX[3] + in_R8;
        in_RCX[2] = in_RCX[2] + in_R8;
        *(undefined8 *)(in_RCX[5] + 8) = 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_180244450
// Address: 0x180244450
// Size: 134 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.180244450(int64_t arg_28h)
{
    int64_t iVar1;
    undefined8 *in_RCX;
    int64_t iVar2;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180244460;
    iVar1 = fcn.18045a350();
    in_RCX[1] = 0;
    *in_RCX = 0;
    if (in_RDX - 1U < 7) {
        iVar2 = in_RDX + -1 + (1LL << (((uint8_t)in_RDX & 7) << 3));
    } else {
        iVar2 = -1;
    }
    *(uint32_t *)(in_RCX + 6) = *(uint32_t *)(in_RCX + 6) & 0xfffffffe;
    in_RCX[4] = iVar2;
    in_RCX[2] = 0;
    in_RCX[3] = 0;
    *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x1802444be;
    iVar1 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + -iVar1));
    in_RCX[5] = iVar1;
    return iVar1 != 0;
}

// ============================================================
// Function: FUN_1802444e0
// Address: 0x1802444e0
// Size: 98 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1802444e0(int64_t arg_28h)
{
    int64_t iVar1;
    undefined8 *in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802444f0;
    iVar1 = fcn.18045a350();
    *(uint32_t *)(in_RCX + 6) = *(uint32_t *)(in_RCX + 6) | 1;
    in_RCX[4] = 0xffffffffffffffff;
    in_RCX[1] = 0;
    *in_RCX = 0;
    in_RCX[2] = 0;
    in_RCX[3] = 0;
    *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x18024452a;
    iVar1 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + -iVar1));
    in_RCX[5] = iVar1;
    return iVar1 != 0;
}

// ============================================================
// Function: FUN_180244550
// Address: 0x180244550
// Size: 116 bytes
// ============================================================
undefined8 fcn.180244550(undefined8 *param_1, int64_t param_2, uint64_t param_3, undefined8 param_4)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t iVar7;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint8_t uVar8;
    unkbyte7 Var9;
    undefined8 auStackX_18 [2];
    
    Var9 = (unkbyte7)((uint64_t)param_4 >> 8);
    uVar8 = (uint8_t)param_4;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (CONCAT71(Var9, uVar8) - 1U < 7) {
        uVar6 = CONCAT71(Var9, uVar8) + -1 + (1LL << ((uVar8 & 7) << 3));
    } else {
        uVar6 = 0xffffffffffffffff;
    }
    if ((param_2 == 0) || (param_3 == 0)) {
        return 0;
    }
    param_1[1] = param_2;
    iVar7 = CONCAT71(Var9, uVar8);
    *param_1 = 0;
    if (uVar6 < param_3) {
        param_3 = uVar6;
    }
    *(uint32_t *)(param_1 + 6) = *(uint32_t *)(param_1 + 6) & 0xfffffffe;
    param_1[4] = param_3;
    *(undefined8 *)(&stack0x00000038 + iVar3) = unaff_RBX;
    *(undefined8 *)(&stack0x00000040 + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x180244f15;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    param_1[2] = 0;
    param_1[3] = 0;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180244f3f;
    iVar5 = fcn.180224d60(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3));
    param_1[5] = iVar5;
    if (iVar5 == 0) {
        return 0;
    }
    if (iVar7 != 0) {
        *(int64_t *)(iVar5 + 0x18) = iVar7;
        *(int64_t *)(param_1[5] + 0x10) = iVar7;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180244f69;
        iVar2 = fcn.180244860(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar4 + iVar3));
        if (iVar2 == 0) {
            uVar1 = param_1[5];
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180244f83;
            fcn.180224990(uVar1, 0x1804e4190, 0x78);
            param_1[5] = 0;
            return 0;
        }
        param_1[3] = param_1[3] + iVar7;
        param_1[2] = param_1[2] + iVar7;
        *(undefined8 *)(param_1[5] + 8) = 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_1802445f0
// Address: 0x1802445f0
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1802445f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180244605;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_R8 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180244623;
        iVar1 = fcn.180244860(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
        if (iVar1 == 0) {
            return 0;
        }
        *(int64_t *)(in_RCX + 0x18) = *(int64_t *)(in_RCX + 0x18) + in_R8;
        *(int64_t *)(in_RCX + 0x10) = *(int64_t *)(in_RCX + 0x10) + in_R8;
        if (*(int64_t *)((int64_t)&arg_38h + iVar2) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180244644;
            fcn.180498030(*(int64_t *)((int64_t)&arg_38h + iVar2), in_RDX, in_R8);
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_180244670
// Address: 0x180244670
// Size: 121 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180244670(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    uint64_t in_RDX;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180244685;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_R8 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802446a2;
        iVar1 = fcn.180244860(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
        if (iVar1 == 0) {
            return 0;
        }
        *(int64_t *)(in_RCX + 0x18) = *(int64_t *)(in_RCX + 0x18) + in_R8;
        *(int64_t *)(in_RCX + 0x10) = *(int64_t *)(in_RCX + 0x10) + in_R8;
        if (*(int64_t *)((int64_t)&arg_38h + iVar2) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802446c2;
            fcn.1804986e0(*(int64_t *)((int64_t)&arg_38h + iVar2), in_RDX & 0xffffffff, in_R8);
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1802446f0
// Address: 0x1802446f0
// Size: 175 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.1802446f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined *puVar3;
    int64_t in_RCX;
    uint64_t in_RDX;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180244705;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_R8 < 9) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180244724;
        iVar1 = fcn.180244860(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
        if (iVar1 != 0) {
            *(int64_t *)(in_RCX + 0x18) = *(int64_t *)(in_RCX + 0x18) + in_R8;
            *(int64_t *)(in_RCX + 0x10) = *(int64_t *)(in_RCX + 0x10) + in_R8;
            if (*(int64_t *)((int64_t)&arg_38h + iVar2) != 0) {
                puVar3 = (undefined *)(*(int64_t *)((int64_t)&arg_38h + iVar2) + -1 + in_R8);
                for (; in_R8 != 0; in_R8 = in_R8 - 1) {
                    *puVar3 = (char)in_RDX;
                    puVar3 = puVar3 + -1;
                    in_RDX = in_RDX >> 8;
                }
                return in_RDX == 0;
            }
            return true;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1802447a0
// Address: 0x1802447a0
// Size: 181 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1802447a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    uint64_t in_RDX;
    int64_t iVar3;
    int64_t var_8h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802447b5;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = 0;
    if (in_RDX < 0x40) {
        iVar3 = 1;
    } else if (in_RDX < 0x4000) {
        iVar3 = 2;
    } else if (in_RDX < 0x40000000) {
        iVar3 = 4;
    } else {
        if (0x3fffffffffffffff < in_RDX) {
            return 0;
        }
        iVar3 = 8;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180244815;
    iVar1 = fcn.180244860(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2));
    if (iVar1 == 0) {
        return 0;
    }
    *(int64_t *)(in_RCX + 0x18) = *(int64_t *)(in_RCX + 0x18) + iVar3;
    *(int64_t *)(in_RCX + 0x10) = *(int64_t *)(in_RCX + 0x10) + iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024482e;
    func_0x000180274f10(*(undefined8 *)((int64_t)&arg_30h + iVar2), in_RDX);
    return 1;
}

// ============================================================
// Function: FUN_180244860
// Address: 0x180244860
// Size: 279 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180244860(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    uint64_t **in_RCX;
    uint64_t *puVar2;
    uint64_t in_RDX;
    uint64_t uVar3;
    int64_t *in_R8;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180244875;
    iVar1 = fcn.18045a350();
    if (((in_RCX[5] == (uint64_t *)0x0) || (in_RDX == 0)) ||
       ((uint64_t)((int64_t)in_RCX[4] - (int64_t)in_RCX[3]) < in_RDX)) {
        return 0;
    }
    puVar2 = *in_RCX;
    if ((puVar2 != (uint64_t *)0x0) && (uVar3 = *puVar2, uVar3 - (int64_t)in_RCX[3] < in_RDX)) {
        if (uVar3 < in_RDX) {
            uVar3 = in_RDX;
        }
        if (uVar3 < 0x8000000000000000) {
            uVar3 = uVar3 * 2;
            if (uVar3 < 0x100) {
                uVar3 = 0x100;
            }
        } else {
            uVar3 = 0xffffffffffffffff;
        }
        *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x1802448f6;
        iVar1 = func_0x000180226380(puVar2, uVar3);
        if (iVar1 == 0) {
            return 0;
        }
    }
    if (in_R8 != (int64_t *)0x0) {
        puVar2 = in_RCX[1];
        if ((puVar2 == (uint64_t *)0x0) &&
           ((*in_RCX == (uint64_t *)0x0 || (puVar2 = (uint64_t *)(*in_RCX)[1], puVar2 == (uint64_t *)0x0)))) {
            iVar1 = 0;
        } else if ((*(uint8_t *)(in_RCX + 6) & 1) == 0) {
            iVar1 = (int64_t)puVar2 + (int64_t)in_RCX[2];
        } else {
            iVar1 = ((int64_t)puVar2 - (int64_t)in_RCX[2]) + (int64_t)in_RCX[4];
        }
        *in_R8 = iVar1;
        if (((*(uint8_t *)(in_RCX + 6) & 1) != 0) && (iVar1 != 0)) {
            *in_R8 = iVar1 - in_RDX;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_180244a20
// Address: 0x180244a20
// Size: 110 bytes
// ============================================================
undefined8 fcn.180244a20(int64_t param_1)
{
    int64_t iVar1;
    undefined8 *puVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180244a2c;
    iVar1 = fcn.18045a350();
    if (*(int64_t *)(param_1 + 0x28) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x180244a58;
        puVar2 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + -iVar1));
        if (puVar2 != (undefined8 *)0x0) {
            *puVar2 = *(undefined8 *)(param_1 + 0x28);
            *(undefined8 **)(param_1 + 0x28) = puVar2;
            puVar2[3] = *(undefined8 *)(param_1 + 0x18);
            puVar2[2] = 0;
            puVar2[1] = 0;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180244a90
// Address: 0x180244a90
// Size: 198 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180244a90(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180244aa0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((*(int64_t *)(in_RCX + 0x28) != 0) && ((in_RDX == 0 || ((*(uint8_t *)(in_RCX + 0x30) & 1) == 0)))) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180244ada;
        puVar3 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
        if (puVar3 != (undefined8 *)0x0) {
            *puVar3 = *(undefined8 *)(in_RCX + 0x28);
            *(undefined8 **)(in_RCX + 0x28) = puVar3;
            puVar3[3] = *(int64_t *)(in_RCX + 0x18) + in_RDX;
            puVar3[2] = in_RDX;
            if (in_RDX == 0) {
                puVar3[1] = 0;
                return 1;
            }
            puVar3[1] = *(undefined8 *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180244b2d;
            iVar1 = fcn.180244860(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            if (iVar1 != 0) {
                *(int64_t *)(in_RCX + 0x18) = *(int64_t *)(in_RCX + 0x18) + in_RDX;
                *(int64_t *)(in_RCX + 0x10) = *(int64_t *)(in_RCX + 0x10) + in_RDX;
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180244b60
// Address: 0x180244b60
// Size: 143 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.180244b60(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180244b75;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180244b89;
    iVar1 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180244b9b;
        iVar1 = fcn.180244860(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
        if (iVar1 != 0) {
            *(int64_t *)(in_RCX + 0x18) = *(int64_t *)(in_RCX + 0x18) + in_RDX;
            *(int64_t *)(in_RCX + 0x10) = *(int64_t *)(in_RCX + 0x10) + in_RDX;
            if ((*(int64_t **)(in_RCX + 0x28) != (int64_t *)0x0) && (**(int64_t **)(in_RCX + 0x28) != 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180244bc4;
                iVar1 = fcn.180244d00(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
                return iVar1 != 0;
            }
        }
    }
    return false;
}

// ============================================================
// Function: FUN_180244bf0
// Address: 0x180244bf0
// Size: 171 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.180244bf0(int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180244c05;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180244c19;
    iVar2 = fcn.180244a90(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
    if (iVar2 != 0) {
        if (in_R8 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180244c32;
            iVar2 = fcn.180244860(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            if (iVar2 == 0) {
                return false;
            }
            *(int64_t *)(in_RCX + 0x18) = *(int64_t *)(in_RCX + 0x18) + in_R8;
            *(int64_t *)(in_RCX + 0x10) = *(int64_t *)(in_RCX + 0x10) + in_R8;
            iVar1 = *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8);
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180244c53;
                fcn.180498030(iVar1, in_RDX, in_R8);
            }
        }
        if ((*(int64_t **)(in_RCX + 0x28) != (int64_t *)0x0) && (**(int64_t **)(in_RCX + 0x28) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180244c70;
            iVar2 = fcn.180244d00(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3));
            return iVar2 != 0;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_180244ca0
// Address: 0x180244ca0
// Size: 91 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180244ca0(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t *in_R8;
    int64_t in_R9;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180244cb0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (((*(uint8_t *)(in_RCX + 0x30) & 1) == 0) || (in_R9 == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180244ccc;
        iVar1 = fcn.180244860(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
        if (iVar1 != 0) {
            if (*in_R8 != 0) {
                *in_R8 = *in_R8 + in_R9;
            }
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180244d00
// Address: 0x180244d00
// Size: 509 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180244d00(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined *puVar3;
    uint64_t uVar4;
    int64_t *in_RCX;
    int64_t iVar5;
    int64_t *in_RDX;
    uint64_t uVar6;
    int32_t in_R8D;
    uint64_t uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180244d20;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar6 = in_RCX[3] - in_RDX[3];
    if (uVar6 == 0) {
        if ((*(uint32_t *)(in_RDX + 4) & 1) != 0) {
            return 0;
        }
        if ((*(uint32_t *)(in_RDX + 4) & 2) != 0) {
            if (in_R8D == 0) {
                return 0;
            }
            if (in_RCX[2] - in_RDX[2] == in_RDX[1]) {
                in_RCX[3] = in_RCX[3] - in_RDX[2];
                in_RCX[2] = in_RCX[2] - in_RDX[2];
            }
            in_RDX[1] = 0;
            in_RDX[2] = 0;
        }
    }
    uVar7 = in_RDX[2];
    if (uVar7 == 0) {
        if ((((*(uint8_t *)(in_RCX + 6) & 1) != 0) && (*in_RDX != 0)) &&
           ((uVar7 = uVar6, uVar6 != 0 || ((*(uint8_t *)(in_RDX + 4) & 2) == 0)))) {
            do {
                uVar7 = uVar7 >> 8;
            } while (uVar7 != 0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180244eca;
            iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
            if (iVar1 == 0) {
                return 0;
            }
            if (0x7f < uVar6) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180244eee;
                iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
                if (iVar1 == 0) {
                    return 0;
                }
            }
        }
        goto code_r0x000180244dd9;
    }
    iVar5 = in_RCX[1];
    if ((iVar5 == 0) && ((*in_RCX == 0 || (iVar5 = *(int64_t *)(*in_RCX + 8), iVar5 == 0)))) goto code_r0x000180244dd9;
    iVar5 = iVar5 + in_RDX[1];
    if ((*(uint8_t *)(in_RDX + 4) & 4) == 0) {
        if (iVar5 != 0) {
            puVar3 = (undefined *)((uVar7 - 1) + iVar5);
            do {
                *puVar3 = (char)uVar6;
                puVar3 = puVar3 + -1;
                uVar6 = uVar6 >> 8;
                uVar7 = uVar7 - 1;
            } while (uVar7 != 0);
            if (uVar6 != 0) {
                return 0;
            }
        }
        goto code_r0x000180244dd9;
    }
    if (iVar5 == 0) goto code_r0x000180244dd9;
    if (uVar6 < 0x40) {
        uVar4 = 1;
code_r0x000180244e5f:
        if (uVar7 < uVar4) {
            return 0;
        }
    } else {
        if (uVar6 < 0x4000) {
            uVar4 = 2;
            goto code_r0x000180244e5f;
        }
        if (uVar6 < 0x40000000) {
            uVar4 = 4;
            goto code_r0x000180244e5f;
        }
        if (uVar6 < 0x4000000000000000) {
            uVar4 = 8;
            goto code_r0x000180244e5f;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180244e70;
    func_0x000180274fd0(iVar5, uVar6);
code_r0x000180244dd9:
    if (in_R8D != 0) {
        in_RCX[5] = *in_RDX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180244df9;
        fcn.180224990(in_RDX, 0x1804e4190, 0x139);
    }
    return 1;
}

// ============================================================
// Function: FUN_180244f00
// Address: 0x180244f00
// Size: 190 bytes
// ============================================================
undefined8 fcn.1802443e0(int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *in_RCX;
    int64_t iVar4;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t in_R8;
    undefined8 auStackX_18 [2];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RDX == 0) {
        return 0;
    }
    in_RCX[1] = 0;
    *in_RCX = in_RDX;
    if (in_R8 - 1U < 7) {
        iVar4 = in_R8 + -1 + (1LL << (((uint8_t)in_R8 & 7) << 3));
    } else {
        iVar4 = -1;
    }
    *(uint32_t *)(in_RCX + 6) = *(uint32_t *)(in_RCX + 6) & 0xfffffffe;
    in_RCX[4] = iVar4;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x180244f15;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    in_RCX[2] = 0;
    in_RCX[3] = 0;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar2) = 0x180244f3f;
    iVar3 = fcn.180224d60(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar2));
    in_RCX[5] = iVar3;
    if (iVar3 == 0) {
        return 0;
    }
    if (in_R8 != 0) {
        *(int64_t *)(iVar3 + 0x18) = in_R8;
        *(int64_t *)(in_RCX[5] + 0x10) = in_R8;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar2) = 0x180244f69;
        iVar1 = fcn.180244860(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar4 + iVar2));
        if (iVar1 == 0) {
            iVar3 = in_RCX[5];
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar2) = 0x180244f83;
            fcn.180224990(iVar3, 0x1804e4190, 0x78);
            in_RCX[5] = 0;
            return 0;
        }
        in_RCX[3] = in_RCX[3] + in_R8;
        in_RCX[2] = in_RCX[2] + in_R8;
        *(undefined8 *)(in_RCX[5] + 8) = 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_180244fc0
// Address: 0x180244fc0
// Size: 32 bytes
// ============================================================
void fcn.180244fc0(undefined8 param_1, undefined8 param_2)
{
    fcn.18045a350();
    // WARNING: Could not recover jumptable at 0x000180244fdd. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0340)(param_1, 0, param_2);
    return;
}

// ============================================================
// Function: FUN_180244fe0
// Address: 0x180244fe0
// Size: 220 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180244fe0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_68h,
                     int64_t arg_88h, int64_t arg_90h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *in_RCX;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180244ff0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = *(undefined8 *)((int64_t)&arg_90h + iVar2);
    *(undefined8 *)((int64_t)&var_20h + iVar2) = *(undefined8 *)((int64_t)&arg_88h + iVar2);
    *(undefined8 *)((int64_t)&var_18h + iVar2) = in_R8;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180245036;
    iVar1 = fcn.180240ec0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000060 + iVar2), 
                          *(int64_t *)((int64_t)&arg_68h + iVar2), *(int64_t *)(&stack0x00000070 + iVar2));
    if (iVar1 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar2) = *(undefined8 *)((int64_t)&arg_40h + iVar2);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180245060;
    iVar3 = (*in_RCX)(in_R9, (int64_t)&arg_48h + iVar2, *(undefined4 *)((int64_t)&arg_38h + iVar2));
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024506d;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180245085;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)((int64_t)&arg_48h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180245097;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802450ae;
    fcn.180224990(*(undefined8 *)((int64_t)&arg_40h + iVar2), 0x1804e41b8, 0x22);
    return iVar3;
}

// ============================================================
// Function: FUN_1802450c0
// Address: 0x1802450c0
// Size: 92 bytes
// ============================================================
void fcn.1802450c0(int64_t arg_28h, int64_t arg_38h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802450ca;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(uint64_t *)((int64_t)&arg_38h + iVar1) = *(uint64_t *)0x1806a3940 ^ (int64_t)&stack0x00000000 + iVar1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802450e7;
    (*(code *)0x69a176)((int64_t)&arg_28h + iVar1);
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802450f7;
    (*(code *)0x69a186)((int64_t)&arg_28h + iVar1, (int64_t)&var_20h + iVar1);
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180245117;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_38h + iVar1) ^ (int64_t)&stack0x00000000 + iVar1);
    return;
}

// ============================================================
// Function: FUN_180245120
// Address: 0x180245120
// Size: 115 bytes
// ============================================================
void fcn.180245120(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180245130;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024513b;
        puVar3 = (undefined8 *)fcn.180245a40();
        if ((undefined8 *)arg1 != puVar3) {
            if (*(int32_t *)(arg1 + 0x138) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180245151;
                fcn.1802be230(arg1);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180245159;
            fcn.18028c410(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000058 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180245161;
            fcn.1802455a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180245169;
            fcn.180224600(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2));
            uVar1 = *(undefined8 *)arg1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180245171;
            fcn.1802227d0(uVar1);
            *(undefined8 *)arg1 = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024518d;
            fcn.180224990(arg1, 0x1804e41d0, 0x1f1);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1802451a0
// Address: 0x1802451a0
// Size: 63 bytes
// ============================================================
undefined8 fcn.1802451a0(void)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802451aa;
    iVar2 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 + -iVar2) = 0x1802451c0;
    iVar1 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_20 + -iVar2));
    iVar4 = 0;
    if (iVar1 != 0) {
        iVar4 = *(int32_t *)0x18077e6cc;
    }
    uVar3 = 0x18077e580;
    if (iVar4 == 0) {
        uVar3 = 0;
    }
    return uVar3;
}

// ============================================================
// Function: FUN_1802451e0
// Address: 0x1802451e0
// Size: 47 bytes
// ============================================================
undefined4 fcn.1802451e0(int64_t param_1)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802451ea;
    iVar1 = fcn.18045a350();
    if (param_1 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x1802451f7;
        param_1 = fcn.180245a40();
        if (param_1 == 0) {
            return 0;
        }
    }
    return *(undefined4 *)(param_1 + 0x13c);
}

// ============================================================
// Function: FUN_180245210
// Address: 0x180245210
// Size: 420 bytes
// ============================================================
int64_t fcn.180245210(int64_t param_1, undefined4 param_2)
{
    int64_t iVar1;
    undefined8 uStack_10;
    
    uStack_10 = 0x18024521c;
    iVar1 = fcn.18045a350();
    if (param_1 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x18024522f;
        param_1 = fcn.180245a40();
        if (param_1 == 0) {
            return 0;
        }
    }
    // switch table (23 cases) at 0x180245358
    switch(param_2) {
    case 0:
        return *(int64_t *)(param_1 + 0xa8);
    case 1:
        return *(int64_t *)(param_1 + 0xb0);
    case 2:
        return *(int64_t *)(param_1 + 0xc0);
    case 3:
        return *(int64_t *)(param_1 + 0xa0);
    case 4:
        return *(int64_t *)(param_1 + 0xb8);
    case 5:
        return *(int64_t *)(param_1 + 0xd0);
    case 6:
        return *(int64_t *)(param_1 + 0xd8);
    default:
        return 0;
    case 10:
        return *(int64_t *)(param_1 + 0x108);
    case 0xb:
        return *(int64_t *)(param_1 + 0xf8);
    case 0xc:
        return *(int64_t *)(param_1 + 0x118);
    case 0xe:
        return *(int64_t *)(param_1 + 200);
    case 0xf:
        return *(int64_t *)(param_1 + 0x110);
    case 0x10:
        return *(int64_t *)(param_1 + 0xe0);
    case 0x11:
        return *(int64_t *)(param_1 + 0xe8);
    case 0x12:
        return *(int64_t *)(param_1 + 0xf0);
    case 0x13:
        return *(int64_t *)(param_1 + 0x128);
    case 0x14:
        return *(int64_t *)(param_1 + 0x100);
    case 0x15:
        return param_1 + 0x130;
    case 0x16:
        return *(int64_t *)(param_1 + 0x120);
    }
}

// ============================================================
// Function: FUN_1802453c0
// Address: 0x1802453c0
// Size: 255 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 * fcn.1802453c0(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    undefined8 *puVar4;
    undefined8 in_RDX;
    undefined8 uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802453d5;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802453f5;
    puVar3 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
    if (puVar3 != (undefined8 *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180245405;
        iVar1 = fcn.180245790(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
        if (iVar1 == 0) {
            uVar5 = 0x1b9;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180245438;
            iVar1 = fcn.1802be010(puVar3, in_RDX);
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024549e;
                iVar1 = fcn.1802be2f0(*(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                                      *(int64_t *)(&stack0x00000038 + iVar2));
                if (iVar1 != 0) {
                    *(undefined4 *)(puVar3 + 0x27) = 1;
                    return puVar3;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180245441;
            puVar4 = (undefined8 *)fcn.180245a40();
            if (puVar3 == puVar4) {
                return (undefined8 *)0x0;
            }
            if (*(int32_t *)(puVar3 + 0x27) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180245457;
                fcn.1802be230(puVar3);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024545f;
            fcn.18028c410(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                          *(int64_t *)(&stack0x00000058 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180245467;
            fcn.1802455a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024546f;
            fcn.180224600(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000048 + iVar2));
            uVar5 = *puVar3;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180245477;
            fcn.1802227d0(uVar5);
            uVar5 = 0x1f1;
            *puVar3 = 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024541e;
        fcn.180224990(puVar3, 0x1804e41d0, uVar5);
    }
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_1802454c0
// Address: 0x1802454c0
// Size: 161 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1802454c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int32_t iVar4;
    int64_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802454da;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802454f3;
    iVar1 = fcn.180222870(*(int64_t *)((int64_t)&var_18h + iVar2));
    iVar4 = 0;
    if (iVar1 != 0) {
        iVar4 = *(int32_t *)0x18077e6cc;
    }
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180245517;
        iVar3 = fcn.180222760(*(int64_t *)((int64_t)&var_18h + iVar2));
        if (iVar3 != 0) goto code_r0x00018024552a;
    }
    if (*(int32_t *)0x18077e6c8 == 0) {
        return 0;
    }
    iVar3 = 0x18077e580;
code_r0x00018024552a:
    if (in_RCX != 0) {
        iVar5 = 0;
        if (in_RCX != 0x18077e580) {
            iVar5 = in_RCX;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180245545;
        fcn.1802228e0(0x18077e6c4, iVar5);
    }
    return iVar3;
}

// ============================================================
// Function: FUN_180245570
// Address: 0x180245570
// Size: 47 bytes
// ============================================================
void fcn.180245570(int64_t param_1, undefined4 param_2)
{
    int64_t iVar1;
    undefined8 uStack_10;
    
    uStack_10 = 0x18024557c;
    iVar1 = fcn.18045a350();
    if (param_1 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x18024558e;
        param_1 = fcn.180245a40();
        if (param_1 == 0) {
            return;
        }
    }
    *(undefined4 *)(param_1 + 0x13c) = param_2;
    return;
}

// ============================================================
// Function: FUN_1802455a0
// Address: 0x1802455a0
// Size: 491 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1802455a0(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t in_RCX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802455b0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*(int64_t *)(in_RCX + 0xa8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802455c9;
        func_0x0001802bda10();
        *(undefined8 *)(in_RCX + 0xa8) = 0;
    }
    if (*(int64_t *)(in_RCX + 0xd0) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802455e1;
        func_0x00018021c230();
        *(undefined8 *)(in_RCX + 0xd0) = 0;
    }
    if (*(int64_t *)(in_RCX + 0xe0) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802455f9;
        func_0x0001802bf0e0();
        *(undefined8 *)(in_RCX + 0xe0) = 0;
    }
    if (*(int64_t *)(in_RCX + 0xf8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180245611;
        func_0x0001802bda10();
        *(undefined8 *)(in_RCX + 0xf8) = 0;
    }
    if (*(int64_t *)(in_RCX + 0x100) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180245629;
        func_0x0001802725e0();
        *(undefined8 *)(in_RCX + 0x100) = 0;
    }
    if (*(int64_t *)(in_RCX + 0x108) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180245641;
        func_0x0001802bda10();
        *(undefined8 *)(in_RCX + 0x108) = 0;
    }
    if (*(int64_t *)(in_RCX + 0x110) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180245659;
        func_0x0001802bda10();
        *(undefined8 *)(in_RCX + 0x110) = 0;
    }
    if (*(int64_t *)(in_RCX + 0xb0) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180245671;
        func_0x00018027f700();
        *(undefined8 *)(in_RCX + 0xb0) = 0;
    }
    if (*(int64_t *)(in_RCX + 0xa0) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180245689;
        func_0x0001802beb20();
        *(undefined8 *)(in_RCX + 0xa0) = 0;
    }
    if (*(int64_t *)(in_RCX + 0xb8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802456a1;
        func_0x000180299850();
        *(undefined8 *)(in_RCX + 0xb8) = 0;
    }
    if (*(int64_t *)(in_RCX + 0xc0) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802456b9;
        func_0x0001802bf020();
        *(undefined8 *)(in_RCX + 0xc0) = 0;
    }
    if (*(int64_t *)(in_RCX + 200) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802456d1;
        func_0x0001802bce60();
        *(undefined8 *)(in_RCX + 200) = 0;
    }
    if (*(int64_t *)(in_RCX + 0xe8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802456e9;
        func_0x0001802bdfb0();
        *(undefined8 *)(in_RCX + 0xe8) = 0;
    }
    if (*(int64_t *)(in_RCX + 0xd8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180245701;
        func_0x0001802c0f70();
        *(undefined8 *)(in_RCX + 0xd8) = 0;
    }
    if (*(int64_t *)(in_RCX + 0x120) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180245719;
        func_0x0001802c1b70();
        *(undefined8 *)(in_RCX + 0x120) = 0;
    }
    if (*(int64_t *)(in_RCX + 0x118) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180245731;
        func_0x0001802c19d0();
        *(undefined8 *)(in_RCX + 0x118) = 0;
    }
    if (*(int64_t *)(in_RCX + 0x128) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180245749;
        func_0x0001802c1dd0();
        *(undefined8 *)(in_RCX + 0x128) = 0;
    }
    if (*(int64_t *)(in_RCX + 0xf0) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180245761;
        func_0x0001802be120();
        *(undefined8 *)(in_RCX + 0xf0) = 0;
    }
    if (*(int64_t *)(in_RCX + 0x130) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180245779;
        func_0x0001802baec0();
        *(undefined8 *)(in_RCX + 0x130) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180245790
// Address: 0x180245790
// Size: 568 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch

undefined8 fcn.180245790(int64_t arg_28h)
{
    bool bVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802457a0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802457ad;
    iVar4 = fcn.180222800();
    *in_RCX = iVar4;
    bVar1 = false;
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802457c1;
        iVar2 = fcn.180224890(in_RCX);
        bVar1 = false;
        if (iVar2 != 0) {
            bVar1 = true;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802457d6;
            iVar4 = fcn.1802bda80(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
            in_RCX[0x15] = iVar4;
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802457ee;
                iVar4 = fcn.1802bf140(in_RCX);
                in_RCX[0x1c] = iVar4;
                if (iVar4 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180245806;
                    iVar4 = fcn.18021c320(in_RCX);
                    in_RCX[0x1a] = iVar4;
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024581e;
                        iVar4 = fcn.1802bda80(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
                        in_RCX[0x1f] = iVar4;
                        if (iVar4 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180245836;
                            iVar4 = fcn.180272630(in_RCX);
                            in_RCX[0x20] = iVar4;
                            if (iVar4 != 0) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024584e;
                                iVar4 = fcn.1802bda80(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
                                in_RCX[0x21] = iVar4;
                                if (iVar4 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180245866;
                                    iVar4 = fcn.1802bda80(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
                                    in_RCX[0x22] = iVar4;
                                    if (iVar4 != 0) {
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024587e;
                                        iVar4 = fcn.18027f850(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                                              *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                                              *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                                              *(int64_t *)(&stack0x00000030 + iVar3), 
                                                              *(int64_t *)(&stack0x00000058 + iVar3));
                                        in_RCX[0x16] = iVar4;
                                        if (iVar4 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180245896;
                                            iVar4 = fcn.1802bebe0(*(int64_t *)((int64_t)&arg_28h + iVar3), 
                                                                  *(int64_t *)(&stack0x00000030 + iVar3));
                                            in_RCX[0x14] = iVar4;
                                            if (iVar4 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802458ae;
                                                iVar4 = fcn.1802998c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                                                      *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                                                      *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                                                      *(int64_t *)(&stack0x00000068 + iVar3));
                                                in_RCX[0x17] = iVar4;
                                                if (iVar4 != 0) {
                                                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802458c6;
                                                    iVar4 = fcn.1802bf050(in_RCX);
                                                    in_RCX[0x18] = iVar4;
                                                    if (iVar4 != 0) {
                                                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802458de;
                                                        iVar4 = fcn.1802bcea0(in_RCX);
                                                        in_RCX[0x19] = iVar4;
                                                        if (iVar4 != 0) {
                                                            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802458f6;
                                                            iVar4 = fcn.1802bdfe0(in_RCX);
                                                            in_RCX[0x1d] = iVar4;
                                                            if (iVar4 != 0) {
                                                                *(undefined8 *)((int64_t)&uStack_10 + iVar3) =
                                                                     0x18024590e;
                                                                iVar4 = fcn.1802c0fb0(in_RCX);
                                                                in_RCX[0x1b] = iVar4;
                                                                if (iVar4 != 0) {
                                                                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) =
                                                                         0x180245922;
                                                                    iVar4 = fcn.1802c1a00(in_RCX);
                                                                    in_RCX[0x23] = iVar4;
                                                                    if (iVar4 != 0) {
                                                                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) =
                                                                             0x180245936;
                                                                        iVar4 = fcn.1802c1ba0(in_RCX);
                                                                        in_RCX[0x24] = iVar4;
                                                                        if (iVar4 != 0) {
                                                                            *(undefined8 *)((int64_t)&uStack_10 + iVar3)
                                                                                 = 0x18024594a;
                                                                            iVar4 = fcn.1802c1e20(*(int64_t *)
                                                                                                   ((int64_t)aiStackX_18
                                                                                                   + iVar3), 
                                                                                                  *(int64_t *)
                                                                                                   ((int64_t)aiStackX_18
                                                                                                   + iVar3 + 8));
                                                                            in_RCX[0x25] = iVar4;
                                                                            if (iVar4 != 0) {
                                                                                *(undefined8 *)
                                                                                 ((int64_t)&uStack_10 + iVar3) =
                                                                                     0x18024595e;
                                                                                iVar4 = fcn.1802be160(in_RCX);
                                                                                in_RCX[0x1e] = iVar4;
                                                                                if (iVar4 != 0) {
                                                                                    *(undefined8 *)
                                                                                     ((int64_t)&uStack_10 + iVar3) =
                                                                                         0x180245972;
                                                                                    iVar2 = fcn.1802bbbc0(*(int64_t *)
                                                                                                           ((int64_t)
                                                            aiStackX_18 + iVar3), 
                                                            *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                                            *(int64_t *)((int64_t)&arg_28h + iVar3));
                                                            if (iVar2 != 0) {
                                                                *(undefined8 *)((int64_t)&uStack_10 + iVar3) =
                                                                     0x18024597b;
                                                                iVar3 = fcn.1802baee0(*(int64_t *)
                                                                                       ((int64_t)aiStackX_18 + iVar3), 
                                                                                      *(int64_t *)
                                                                                       ((int64_t)aiStackX_18 + iVar3 + 8
                                                                                       ));
                                                                in_RCX[0x26] = iVar3;
                                                                return 1;
                                                            }
                                                            }
                                                            }
                                                            }
                                                            }
                                                            }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180245997;
    fcn.1802455a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    if (bVar1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802459a3;
        fcn.180224600(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
    }
    iVar4 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802459ab;
    fcn.1802227d0(iVar4);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802459bb;
    fcn.1804986e0(in_RCX, 0, 0x140);
    return 0;
}

// ============================================================
// Function: FUN_1802459d0
// Address: 0x1802459d0
// Size: 99 bytes
// ============================================================
void fcn.1802459d0(void)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802459da;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1802459eb;
    iVar1 = fcn.1802227a0(0x18077e6c4, 0);
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1802459fb;
        iVar1 = fcn.180245790(*(int64_t *)((int64_t)&iStackX_20 + iVar2));
        if (iVar1 != 0) {
            *(undefined4 *)0x18077e6c8 = 1;
            *(undefined4 *)0x18077e6cc = 1;
            return;
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180245a0b;
        fcn.180222710(0x18077e6c4);
    }
    *(undefined4 *)0x18077e6cc = 0;
    return;
}

// ============================================================
// Function: FUN_180245a40
// Address: 0x180245a40
// Size: 92 bytes
// ============================================================
int64_t fcn.180245a40(void)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x180245a4a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180245a60;
    iVar1 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_20 + iVar2));
    iVar3 = 0;
    iVar4 = 0;
    if (iVar1 != 0) {
        iVar4 = *(int32_t *)0x18077e6cc;
    }
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180245a7d;
        iVar3 = fcn.180222760(*(int64_t *)((int64_t)&iStackX_20 + iVar2));
        if (iVar3 != 0) {
            return iVar3;
        }
    }
    iVar2 = 0x18077e580;
    if (*(int32_t *)0x18077e6c8 == 0) {
        iVar2 = iVar3;
    }
    return iVar2;
}

// ============================================================
// Function: FUN_180245aa0
// Address: 0x180245aa0
// Size: 108 bytes
// ============================================================
void fcn.180245aa0(void)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x180245aaa;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*(int32_t *)0x18077e6c8 != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180245ac2;
        fcn.18028c410(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000060 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180245ace;
        fcn.1802455a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180245ada;
        fcn.180224600(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180245ae6;
        fcn.1802227d0(*(undefined8 *)0x18077e580);
        *(undefined8 *)0x18077e580 = 0;
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180245afd;
        fcn.180222710(0x18077e6c4);
        *(int32_t *)0x18077e6c8 = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180245b10
// Address: 0x180245b10
// Size: 35 bytes
// ============================================================
int64_t fcn.180245b10(int64_t param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t iVar5;
    undefined8 uStackX_20;
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (param_1 != 0) {
        return param_1;
    }
    *(undefined8 *)((int64_t)&uStackX_20 + iVar4) = 0x180245a4a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar4) = 0x180245a60;
    iVar1 = fcn.180222870(*(int64_t *)(&stack0x00000048 + iVar2 + iVar4));
    iVar3 = 0;
    iVar5 = 0;
    if (iVar1 != 0) {
        iVar5 = *(int32_t *)0x18077e6cc;
    }
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar4) = 0x180245a7d;
        iVar3 = fcn.180222760(*(int64_t *)(&stack0x00000048 + iVar2 + iVar4));
        if (iVar3 != 0) {
            return iVar3;
        }
    }
    iVar4 = 0x18077e580;
    if (*(int32_t *)0x18077e6c8 == 0) {
        iVar4 = iVar3;
    }
    return iVar4;
}

// ============================================================
// Function: FUN_180245b40
// Address: 0x180245b40
// Size: 416 bytes
// ============================================================
int64_t fcn.180245b40(int64_t param_1, undefined4 param_2)
{
    int64_t iVar1;
    undefined8 uStack_10;
    
    uStack_10 = 0x180245b4c;
    iVar1 = fcn.18045a350();
    if (param_1 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x180245b5f;
        param_1 = fcn.180245a40();
        if (param_1 == 0) {
            return 0;
        }
    }
    // switch table (23 cases) at 0x180245c84
    switch(param_2) {
    case 0:
        return *(int64_t *)(param_1 + 0xa8);
    case 1:
        return *(int64_t *)(param_1 + 0xb0);
    case 2:
        return *(int64_t *)(param_1 + 0xc0);
    case 3:
        return *(int64_t *)(param_1 + 0xa0);
    case 4:
        return *(int64_t *)(param_1 + 0xb8);
    case 5:
        return *(int64_t *)(param_1 + 0xd0);
    case 6:
        return *(int64_t *)(param_1 + 0xd8);
    default:
        return 0;
    case 10:
        return *(int64_t *)(param_1 + 0x108);
    case 0xb:
        return *(int64_t *)(param_1 + 0xf8);
    case 0xc:
        return *(int64_t *)(param_1 + 0x118);
    case 0xe:
        return *(int64_t *)(param_1 + 200);
    case 0xf:
        return *(int64_t *)(param_1 + 0x110);
    case 0x10:
        return *(int64_t *)(param_1 + 0xe0);
    case 0x11:
        return *(int64_t *)(param_1 + 0xe8);
    case 0x12:
        return *(int64_t *)(param_1 + 0xf0);
    case 0x13:
        return *(int64_t *)(param_1 + 0x128);
    case 0x14:
        return *(int64_t *)(param_1 + 0x100);
    case 0x15:
        return param_1 + 0x130;
    case 0x16:
        return *(int64_t *)(param_1 + 0x120);
    }
}

// ============================================================
// Function: FUN_180245ce0
// Address: 0x180245ce0
// Size: 93 bytes
// ============================================================
undefined8 fcn.180245ce0(int64_t param_1)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x180245cec;
    iVar1 = fcn.18045a350();
    iVar2 = param_1;
    if (param_1 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x180245cfc;
        iVar2 = fcn.180245a40();
    }
    if (iVar2 != 0x18077e580) {
        if (param_1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x180245d24;
            iVar2 = fcn.180245a40();
            if (param_1 != iVar2) {
                return 0x1804e4230;
            }
        }
        return 0x1804e4208;
    }
    return 0x1804e41e8;
}

// ============================================================
// Function: FUN_180245d40
// Address: 0x180245d40
// Size: 45 bytes
// ============================================================
int64_t fcn.180245d40(int64_t param_1)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x180245d4a;
    iVar1 = fcn.18045a350();
    if (param_1 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x180245d57;
        param_1 = fcn.180245a40();
        if (param_1 == 0) {
            return 0;
        }
    }
    return param_1 + 8;
}

// ============================================================
// Function: FUN_180245d70
// Address: 0x180245d70
// Size: 55 bytes
// ============================================================
bool fcn.180245d70(int64_t param_1)
{
    int64_t iVar1;
    undefined8 uStack_10;
    
    uStack_10 = 0x180245d7c;
    iVar1 = fcn.18045a350();
    if (param_1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x180245d8c;
        iVar1 = fcn.180245a40();
        return param_1 == iVar1;
    }
    return true;
}

// ============================================================
// Function: FUN_180245db0
// Address: 0x180245db0
// Size: 48 bytes
// ============================================================
undefined8 fcn.180245db0(undefined8 *param_1)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x180245dba;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_1 == (undefined8 *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180245dca;
        param_1 = (undefined8 *)fcn.180245a40();
        if (param_1 == (undefined8 *)0x0) {
            return 0;
        }
    }
    uVar1 = *param_1;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x18022285a;
    iVar2 = fcn.18045a350(uVar1);
    *(undefined8 *)((int64_t)&uStackX_20 + (iVar3 - iVar2)) = 0x180222863;
    (*(code *)0x69a0ae)();
    return 1;
}

// ============================================================
// Function: FUN_180245de0
// Address: 0x180245de0
// Size: 48 bytes
// ============================================================
undefined8 fcn.180245de0(int64_t *param_1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x180245dea;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (param_1 == (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180245dfa;
        param_1 = (int64_t *)fcn.180245a40();
        if (param_1 == (int64_t *)0x0) {
            return 0;
        }
    }
    iVar3 = *param_1;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2) = 0x18022291a;
    iVar1 = fcn.18045a350();
    if (*(int32_t *)(iVar3 + 8) != 0) {
        *(undefined4 *)(iVar3 + 8) = 0;
        *(undefined8 *)((int64_t)&uStackX_20 + -iVar1 + iVar2) = 0x180222930;
        (*(code *)0x69a062)();
        return 1;
    }
    *(undefined8 *)((int64_t)&uStackX_20 + -iVar1 + iVar2) = 0x180222940;
    (*(code *)0x69a07c)();
    return 1;
}

// ============================================================
// Function: FUN_180245e10
// Address: 0x180245e10
// Size: 48 bytes
// ============================================================
undefined8 fcn.180245e10(int64_t *param_1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined8 auStackX_18 [2];
    undefined8 uStack_8;
    
    uStack_8 = 0x180245e1a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (param_1 == (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180245e2a;
        param_1 = (int64_t *)fcn.180245a40();
        if (param_1 == (int64_t *)0x0) {
            return 0;
        }
    }
    iVar3 = *param_1;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x18022295c;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)auStackX_18 + (iVar2 - iVar1)) = 0x180222968;
    (*(code *)0x69a094)();
    *(undefined4 *)(iVar3 + 8) = 1;
    return 1;
}

// ============================================================
// Function: FUN_180245e40
// Address: 0x180245e40
// Size: 46 bytes
// ============================================================
void fcn.180245e40(void)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x180245e4a;
    iVar1 = fcn.18045a350();
    if (*(int64_t *)0x18077e650 != 0) {
        *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x180245e5e;
        fcn.18021c230();
        *(int64_t *)0x18077e650 = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180245e70
// Address: 0x180245e70
// Size: 254 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_868h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_898h because it doesn't fit into ProtoModel

void fcn.180245e70(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h,
                  undefined8 placeholder_5, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, undefined8 placeholder_11, int64_t arg_68h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180245e8a;
    var_18h = arg3;
    var_20h = arg4;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(uint64_t *)(&stack0x00000868 + iVar2) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2);
    *(undefined8 *)((int64_t)&arg_50h + iVar2) = 0x800;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = 0;
    *(undefined **)((int64_t)&arg_28h + iVar2) = &stack0x00000898 + iVar2;
    *(int64_t *)((int64_t)&var_20h + iVar2) = arg2;
    *(int64_t *)((int64_t)&arg_58h + iVar2) = (int64_t)&arg_68h + iVar2;
    *(int64_t *)((int64_t)&var_18h + iVar2) = (int64_t)&arg_48h + iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180245ef3;
    iVar1 = func_0x000180246150((int64_t)&arg_58h + iVar2, (int64_t)&arg_38h + iVar2, (int64_t)&arg_50h + iVar2, 
                                (int64_t)&arg_40h + iVar2);
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180245f0e;
        fcn.180224990(*(undefined8 *)((int64_t)&arg_38h + iVar2), 0x1804e4250, 0x435);
    } else if (*(int64_t *)((int64_t)&arg_38h + iVar2) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180245f51;
        func_0x00018021b2c0(placeholder_0, (int64_t)&arg_68h + iVar2, *(undefined4 *)((int64_t)&arg_40h + iVar2));
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180245f2c;
        func_0x00018021b2c0(placeholder_0, *(int64_t *)((int64_t)&arg_38h + iVar2), 
                            *(undefined4 *)((int64_t)&arg_40h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180245f45;
        fcn.180224990(*(undefined8 *)((int64_t)&arg_38h + iVar2), 0x1804e4250, 0x43a);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180245f65;
    fcn.180459870(*(uint64_t *)(&stack0x00000868 + iVar2) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2));
    return;
}

// ============================================================
// Function: FUN_180245f70
// Address: 0x180245f70
// Size: 119 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch

uint64_t fcn.180245f70(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_28h,
                      int64_t arg_30h, undefined8 placeholder_6, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                      int64_t arg_58h, int64_t arg_88h, int64_t arg_b0h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180245f84;
    var_20h = arg4;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&arg_48h + iVar2) = placeholder_1;
    *(int64_t *)((int64_t)&arg_30h + iVar2) = (int64_t)&arg_88h + iVar2;
    *(int64_t *)((int64_t)&arg_28h + iVar2) = arg3;
    *(undefined8 *)((int64_t)&arg_50h + iVar2) = placeholder_0;
    *(int64_t *)((int64_t)&var_20h + iVar2) = (int64_t)&arg_40h + iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180245fc3;
    iVar1 = fcn.180246150(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                          *(int64_t *)((int64_t)&arg_30h + iVar2));
    uVar3 = 0xffffffff;
    if ((iVar1 != 0) && (*(int32_t *)((int64_t)&arg_40h + iVar2) == 0)) {
        uVar3 = 0xffffffff;
        if (*(uint64_t *)((int64_t)&arg_58h + iVar2) < 0x80000000) {
            uVar3 = *(uint64_t *)((int64_t)&arg_58h + iVar2) & 0xffffffff;
        }
    }
    return uVar3;
}

