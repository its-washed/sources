// Chunk 172 - 50 functions

// ============================================================
// Function: FUN_18022a1f0
// Address: 0x18022a1f0
// Size: 536 bytes
// ============================================================
undefined8 fcn.18022a1f0(int64_t arg_48h, int64_t arg_50h)
{
    double dVar1;
    int32_t iVar2;
    double *pdVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    double dVar8;
    int64_t iVar9;
    int64_t in_RCX;
    double *in_RDX;
    undefined8 uVar10;
    undefined8 uStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022a1fa;
    iVar7 = func_0x00018045a350();
    iVar7 = -iVar7;
    if ((in_RDX == (double *)0x0) || (in_RCX == 0)) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar7) = 0x18022a3d7;
        func_0x000180229480();
        uVar10 = 0x2c4;
    } else {
        pdVar3 = *(double **)(in_RCX + 0x10);
        if (pdVar3 != (double *)0x0) {
            iVar2 = *(int32_t *)(in_RCX + 8);
            if (iVar2 == 1) {
                if (*(int64_t *)(in_RCX + 0x18) == 4) {
                    dVar8 = (double)(int64_t)*(int32_t *)pdVar3;
code_r0x00018022a263:
                    *in_RDX = dVar8;
                    return 1;
                }
                if (*(int64_t *)(in_RCX + 0x18) == 8) {
                    *in_RDX = *pdVar3;
                    return 1;
                }
            } else {
                if (iVar2 != 2) {
                    if (iVar2 != 3) {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7) = 0x18022a3a1;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7) = 0x18022a3b9;
                        func_0x0001802295a0(0x1804c0808, 0x305, 0x1804c08e0);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7) = 0x18022a3cb;
                        func_0x0001802296d0(0xf, 0x81, 0);
                        return 0;
                    }
                    if (*(int64_t *)(in_RCX + 0x18) != 8) {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7) = 0x18022a300;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7) = 0x18022a318;
                        func_0x0001802295a0(0x1804c0808, 0x301, 0x1804c08e0);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7) = 0x18022a32a;
                        func_0x0001802296d0(0xf, 0x82, 0);
                        return 0;
                    }
                    dVar1 = *pdVar3;
                    if (((dVar1 < -9.223372036854776e+18) || (9.223372036854776e+18 <= dVar1)) ||
                       (dVar8 = (double)(int64_t)dVar1, dVar1 != (double)(int64_t)dVar8)) {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7) = 0x18022a36b;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7) = 0x18022a383;
                        func_0x0001802295a0(0x1804c0808, 0x2fe, 0x1804c08e0);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7) = 0x18022a395;
                        func_0x0001802296d0(0xf, 0x7b, 0);
                        return 0;
                    }
                    goto code_r0x00018022a263;
                }
                if (*(int64_t *)(in_RCX + 0x18) == 4) {
                    *in_RDX = (double)(uint64_t)*(uint32_t *)pdVar3;
                    return 1;
                }
                if (*(int64_t *)(in_RCX + 0x18) == 8) {
                    if (0x7fffffffffffffff < (uint64_t)*pdVar3) {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7) = 0x18022a2aa;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7) = 0x18022a2c2;
                        func_0x0001802295a0(0x1804c0808, 0x2e7, 0x1804c08e0);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7) = 0x18022a2d4;
                        func_0x0001802296d0(0xf, 0x7e, 0);
                        return 0;
                    }
                    *in_RDX = *pdVar3;
                    return 1;
                }
            }
            uVar10 = 8;
            *(undefined8 *)((int64_t)&uStackX_20 + iVar7) = 0x18022be2a;
            iVar9 = func_0x00018045a350();
            iVar9 = -iVar9;
            iVar4 = *(int64_t *)(in_RCX + 0x10);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar9 + iVar7) = 0x18022be41;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStackX_20 + iVar9 + iVar7) = 0x18022be59;
                func_0x0001802295a0(0x1804c0808, 0xca, 0x1804c0830);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar9 + iVar7) = 0x18022be6b;
                func_0x0001802296d0(0xf, 0xc0102, 0);
                return 0;
            }
            if (*(int32_t *)(in_RCX + 8) != 1) {
                if (*(int32_t *)(in_RCX + 8) != 2) {
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar9 + iVar7) = 0x18022bece;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar9 + iVar7) = 0x18022bee6;
                    func_0x0001802295a0(0x1804c0808, 0xd1, 0x1804c0830);
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar9 + iVar7) = 0x18022bef8;
                    func_0x0001802296d0(0xf, 0x7c, 0);
                    return 0;
                }
                uVar6 = *(undefined8 *)(in_RCX + 0x18);
                *(undefined4 *)((int64_t)&arg_50h + iVar9 + iVar7) = 1;
                *(undefined *)((int64_t)&arg_48h + iVar9 + iVar7) = 0;
                *(undefined8 *)((int64_t)&uStackX_20 + iVar9 + iVar7) = 0x18022bec4;
                uVar10 = func_0x00018022bd50(in_RDX, uVar10, iVar4, uVar6);
                return uVar10;
            }
            iVar5 = *(int64_t *)(in_RCX + 0x18);
            *(undefined4 *)((int64_t)&arg_50h + iVar9 + iVar7) = 1;
            *(char *)((int64_t)&arg_48h + iVar9 + iVar7) = *(char *)(iVar5 + -1 + iVar4) >> 7;
            *(undefined8 *)((int64_t)&uStackX_20 + iVar9 + iVar7) = 0x18022be9e;
            uVar10 = func_0x00018022bd50(in_RDX, uVar10);
            return uVar10;
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar7) = 0x18022a21d;
        func_0x000180229480();
        uVar10 = 0x2c9;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar7) = 0x18022a3ef;
    func_0x0001802295a0(0x1804c0808, uVar10, 0x1804c08e0);
    *(undefined8 *)((int64_t)&uStack_8 + iVar7) = 0x18022a401;
    func_0x0001802296d0(0xf, 0xc0102, 0);
    return 0;
}

// ============================================================
// Function: FUN_18022a410
// Address: 0x18022a410
// Size: 169 bytes
// ============================================================
undefined8 fcn.18022a410(int64_t param_1, undefined8 *param_2, undefined8 *param_3)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022a41a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if ((param_2 != (undefined8 *)0x0) && (param_1 != 0)) {
        if (*(int32_t *)(param_1 + 8) != 7) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022a432;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
            *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022a44a;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                          *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                          *(int64_t *)(&stack0x00000050 + iVar1));
            *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022a45c;
            fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
            return 0;
        }
        if (param_3 != (undefined8 *)0x0) {
            *param_3 = *(undefined8 *)(param_1 + 0x18);
        }
        *param_2 = **(undefined8 **)(param_1 + 0x10);
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022a488;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022a4a0;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                  *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022a4b2;
    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
    return 0;
}

// ============================================================
// Function: FUN_18022a4c0
// Address: 0x18022a4c0
// Size: 41 bytes
// ============================================================
void fcn.18022a4c0(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022a4cf;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 5;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022a4e4;
    fcn.18022c1a0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                  *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                  *(int64_t *)(&stack0x00000040 + iVar1));
    return;
}

// ============================================================
// Function: FUN_18022a4f0
// Address: 0x18022a4f0
// Size: 213 bytes
// ============================================================
undefined8 fcn.18022a4f0(int64_t param_1, undefined8 *param_2, undefined8 *param_3)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022a4fa;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if ((param_2 == (undefined8 *)0x0) || (param_1 == 0)) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022a594;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022a5ac;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022a5be;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    if (*(int32_t *)(param_1 + 8) == 7) {
        if (param_3 != (undefined8 *)0x0) {
            *param_3 = *(undefined8 *)(param_1 + 0x18);
        }
        *param_2 = **(undefined8 **)(param_1 + 0x10);
        return 1;
    }
    if (*(int32_t *)(param_1 + 8) != 5) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022a541;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022a559;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022a56b;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    if (param_3 != (undefined8 *)0x0) {
        *param_3 = *(undefined8 *)(param_1 + 0x18);
    }
    *param_2 = *(undefined8 *)(param_1 + 0x10);
    return 1;
}

// ============================================================
// Function: FUN_18022a5d0
// Address: 0x18022a5d0
// Size: 22 bytes
// ============================================================
undefined8 fcn.18022a5d0(int64_t arg_70h, int64_t arg_78h, int64_t arg_a8h, int64_t arg_b0h)
{
    int32_t iVar1;
    double *pdVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    double dVar9;
    double *in_RDX;
    undefined8 uVar10;
    int64_t iVar11;
    double dVar12;
    double dVar13;
    undefined8 uStackX_20;
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar4) = 0x18022a90a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((in_RDX == (double *)0x0) || (in_RCX == 0)) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022ab31;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), *(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
    } else {
        pdVar2 = *(double **)(in_RCX + 0x10);
        if (pdVar2 != (double *)0x0) {
            iVar1 = *(int32_t *)(in_RCX + 8);
            if (iVar1 != 2) {
                if (iVar1 != 1) {
                    if (iVar1 != 3) {
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022aafb;
                        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                                      *(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022ab13;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                                      *(int64_t *)(&stack0x00000050 + iVar5 + iVar4), 
                                      *(int64_t *)(&stack0x00000058 + iVar5 + iVar4), 
                                      *(int64_t *)(&stack0x00000060 + iVar5 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_78h + iVar5 + iVar4));
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022ab25;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar5 + iVar4));
                        return 0;
                    }
                    if (*(int64_t *)(in_RCX + 0x18) == 8) {
                        dVar9 = *pdVar2;
                        if ((0.0 <= dVar9) && (dVar9 < 1.844674407370955e+19)) {
                            iVar6 = 0;
                            dVar12 = dVar9;
                            if ((9.223372036854776e+18 <= dVar9) &&
                               (dVar12 = dVar9 - 9.223372036854776e+18, dVar12 < 9.223372036854776e+18)) {
                                iVar6 = -0x8000000000000000;
                            }
                            dVar12 = (double)((int64_t)dVar12 + iVar6);
                            if ((int64_t)dVar12 < 0) {
                                dVar13 = (double)((uint64_t)dVar12 >> 1 | (uint64_t)(SUB84(dVar12, 0) & 1));
                                dVar13 = dVar13 + dVar13;
                            } else {
                                dVar13 = (double)(int64_t)dVar12;
                            }
                            if (dVar9 == dVar13) {
                                *in_RDX = dVar12;
                                return 1;
                            }
                        }
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022aac5;
                        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                                      *(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022aadd;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                                      *(int64_t *)(&stack0x00000050 + iVar5 + iVar4), 
                                      *(int64_t *)(&stack0x00000058 + iVar5 + iVar4), 
                                      *(int64_t *)(&stack0x00000060 + iVar5 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_78h + iVar5 + iVar4));
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022aaef;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar5 + iVar4));
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022aa09;
                    fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022aa21;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000050 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000058 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000060 + iVar5 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_78h + iVar5 + iVar4));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022aa33;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar5 + iVar4));
                    return 0;
                }
                if (*(int64_t *)(in_RCX + 0x18) == 4) {
                    dVar9 = (double)(int64_t)*(int32_t *)pdVar2;
                    if (-1 < *(int32_t *)pdVar2) {
code_r0x00018022a9da:
                        *in_RDX = dVar9;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022a9ec;
                    fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
                } else {
                    if (*(int64_t *)(in_RCX + 0x18) != 8) goto code_r0x00018022a951;
                    dVar9 = *pdVar2;
                    if (-1 < (int64_t)dVar9) goto code_r0x00018022a9da;
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022a9a2;
                    fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
                }
                *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022a9ba;
                fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000050 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000058 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000060 + iVar5 + iVar4), 
                              *(int64_t *)((int64_t)&arg_78h + iVar5 + iVar4));
                *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022a9cc;
                fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar5 + iVar4));
                return 0;
            }
            if (*(int64_t *)(in_RCX + 0x18) == 4) {
                *in_RDX = (double)(uint64_t)*(uint32_t *)pdVar2;
                return 1;
            }
            if (*(int64_t *)(in_RCX + 0x18) == 8) {
                *in_RDX = *pdVar2;
                return 1;
            }
code_r0x00018022a951:
            uVar10 = 8;
            *(undefined8 *)(&stack0x00000048 + iVar5 + iVar4) = 0x18022bf0a;
            iVar7 = fcn.18045a350();
            iVar7 = -iVar7;
            iVar6 = *(int64_t *)(in_RCX + 0x10);
            if (iVar6 == 0) {
                *(undefined8 *)(&stack0x00000048 + iVar7 + iVar5 + iVar4) = 0x18022bf21;
                fcn.180229480(*(int64_t *)((int64_t)&arg_70h + iVar7 + iVar5 + iVar4), 
                              *(int64_t *)((int64_t)&arg_78h + iVar7 + iVar5 + iVar4));
                *(undefined8 *)(&stack0x00000048 + iVar7 + iVar5 + iVar4) = 0x18022bf39;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_70h + iVar7 + iVar5 + iVar4), 
                              *(int64_t *)((int64_t)&arg_78h + iVar7 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000080 + iVar7 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000088 + iVar7 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x000000a0 + iVar7 + iVar5 + iVar4));
                *(undefined8 *)(&stack0x00000048 + iVar7 + iVar5 + iVar4) = 0x18022bf4b;
                fcn.1802296d0(*(int64_t *)(&stack0x00000090 + iVar7 + iVar5 + iVar4));
                return 0;
            }
            if (*(int32_t *)(in_RCX + 8) != 1) {
                if (*(int32_t *)(in_RCX + 8) != 2) {
                    *(undefined8 *)(&stack0x00000048 + iVar7 + iVar5 + iVar4) = 0x18022bf98;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_70h + iVar7 + iVar5 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_78h + iVar7 + iVar5 + iVar4));
                    *(undefined8 *)(&stack0x00000048 + iVar7 + iVar5 + iVar4) = 0x18022bfb0;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_70h + iVar7 + iVar5 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_78h + iVar7 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000080 + iVar7 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000088 + iVar7 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x000000a0 + iVar7 + iVar5 + iVar4));
                    *(undefined8 *)(&stack0x00000048 + iVar7 + iVar5 + iVar4) = 0x18022bfc2;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000090 + iVar7 + iVar5 + iVar4));
                    return 0;
                }
                uVar3 = *(undefined8 *)(in_RCX + 0x18);
                *(undefined4 *)((int64_t)&arg_78h + iVar7 + iVar5 + iVar4) = 0;
                *(undefined *)((int64_t)&arg_70h + iVar7 + iVar5 + iVar4) = 0;
                *(undefined8 *)(&stack0x00000048 + iVar7 + iVar5 + iVar4) = 0x18022bf8e;
                uVar10 = func_0x00018022bd50(in_RDX, uVar10, iVar6, uVar3);
                return uVar10;
            }
            iVar11 = *(int64_t *)(in_RCX + 0x18);
            *(undefined8 *)(&stack0x00000080 + iVar7 + iVar5 + iVar4) = 0x18022c7da;
            iVar8 = fcn.18045a350(in_RDX, uVar10);
            iVar8 = -iVar8;
            if (-1 < *(char *)(iVar6 + -1 + iVar11)) {
                *(undefined4 *)((int64_t)&arg_b0h + iVar8 + iVar7 + iVar5 + iVar4) = 0;
                *(undefined *)((int64_t)&arg_a8h + iVar8 + iVar7 + iVar5 + iVar4) = 0;
                *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar5 + iVar4) = 0x18022c82d;
                uVar10 = func_0x00018022bd50();
                return uVar10;
            }
            *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar5 + iVar4) = 0x18022c7ea;
            fcn.180229480(*(int64_t *)((int64_t)&arg_a8h + iVar8 + iVar7 + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_b0h + iVar8 + iVar7 + iVar5 + iVar4));
            *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar5 + iVar4) = 0x18022c802;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_a8h + iVar8 + iVar7 + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_b0h + iVar8 + iVar7 + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x000000b8 + iVar8 + iVar7 + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x000000c0 + iVar8 + iVar7 + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x000000d8 + iVar8 + iVar7 + iVar5 + iVar4));
            *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar5 + iVar4) = 0x18022c814;
            fcn.1802296d0(*(int64_t *)(&stack0x000000c8 + iVar8 + iVar7 + iVar5 + iVar4));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022a92d;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), *(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
    }
    *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022ab49;
    fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), *(int64_t *)(&stack0x00000050 + iVar5 + iVar4), 
                  *(int64_t *)(&stack0x00000058 + iVar5 + iVar4), *(int64_t *)(&stack0x00000060 + iVar5 + iVar4), 
                  *(int64_t *)((int64_t)&arg_78h + iVar5 + iVar4));
    *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022ab5b;
    fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar5 + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_18022a5f0
// Address: 0x18022a5f0
// Size: 22 bytes
// ============================================================
undefined8 fcn.18022a5f0(int64_t param_1, double *param_2)
{
    double dVar1;
    int32_t iVar2;
    double *pdVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    double dVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 uVar11;
    undefined8 uStackX_20;
    
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar9) = 0x18022a1fa;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if ((param_2 == (double *)0x0) || (param_1 == 0)) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar9) = 0x18022a3d7;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar7 + iVar9), *(int64_t *)(&stack0x00000050 + iVar7 + iVar9));
    } else {
        pdVar3 = *(double **)(param_1 + 0x10);
        if (pdVar3 != (double *)0x0) {
            iVar2 = *(int32_t *)(param_1 + 8);
            if (iVar2 == 1) {
                if (*(int64_t *)(param_1 + 0x18) == 4) {
                    dVar8 = (double)(int64_t)*(int32_t *)pdVar3;
code_r0x00018022a263:
                    *param_2 = dVar8;
                    return 1;
                }
                if (*(int64_t *)(param_1 + 0x18) == 8) {
                    *param_2 = *pdVar3;
                    return 1;
                }
            } else {
                if (iVar2 != 2) {
                    if (iVar2 != 3) {
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar9) = 0x18022a3a1;
                        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar7 + iVar9), 
                                      *(int64_t *)(&stack0x00000050 + iVar7 + iVar9));
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar9) = 0x18022a3b9;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar7 + iVar9), 
                                      *(int64_t *)(&stack0x00000050 + iVar7 + iVar9), 
                                      *(int64_t *)(&stack0x00000058 + iVar7 + iVar9), 
                                      *(int64_t *)(&stack0x00000060 + iVar7 + iVar9), 
                                      *(int64_t *)(&stack0x00000078 + iVar7 + iVar9));
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar9) = 0x18022a3cb;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar7 + iVar9));
                        return 0;
                    }
                    if (*(int64_t *)(param_1 + 0x18) != 8) {
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar9) = 0x18022a300;
                        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar7 + iVar9), 
                                      *(int64_t *)(&stack0x00000050 + iVar7 + iVar9));
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar9) = 0x18022a318;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar7 + iVar9), 
                                      *(int64_t *)(&stack0x00000050 + iVar7 + iVar9), 
                                      *(int64_t *)(&stack0x00000058 + iVar7 + iVar9), 
                                      *(int64_t *)(&stack0x00000060 + iVar7 + iVar9), 
                                      *(int64_t *)(&stack0x00000078 + iVar7 + iVar9));
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar9) = 0x18022a32a;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar7 + iVar9));
                        return 0;
                    }
                    dVar1 = *pdVar3;
                    if (((dVar1 < -9.223372036854776e+18) || (9.223372036854776e+18 <= dVar1)) ||
                       (dVar8 = (double)(int64_t)dVar1, dVar1 != (double)(int64_t)dVar8)) {
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar9) = 0x18022a36b;
                        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar7 + iVar9), 
                                      *(int64_t *)(&stack0x00000050 + iVar7 + iVar9));
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar9) = 0x18022a383;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar7 + iVar9), 
                                      *(int64_t *)(&stack0x00000050 + iVar7 + iVar9), 
                                      *(int64_t *)(&stack0x00000058 + iVar7 + iVar9), 
                                      *(int64_t *)(&stack0x00000060 + iVar7 + iVar9), 
                                      *(int64_t *)(&stack0x00000078 + iVar7 + iVar9));
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar9) = 0x18022a395;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar7 + iVar9));
                        return 0;
                    }
                    goto code_r0x00018022a263;
                }
                if (*(int64_t *)(param_1 + 0x18) == 4) {
                    *param_2 = (double)(uint64_t)*(uint32_t *)pdVar3;
                    return 1;
                }
                if (*(int64_t *)(param_1 + 0x18) == 8) {
                    if (0x7fffffffffffffff < (uint64_t)*pdVar3) {
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar9) = 0x18022a2aa;
                        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar7 + iVar9), 
                                      *(int64_t *)(&stack0x00000050 + iVar7 + iVar9));
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar9) = 0x18022a2c2;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar7 + iVar9), 
                                      *(int64_t *)(&stack0x00000050 + iVar7 + iVar9), 
                                      *(int64_t *)(&stack0x00000058 + iVar7 + iVar9), 
                                      *(int64_t *)(&stack0x00000060 + iVar7 + iVar9), 
                                      *(int64_t *)(&stack0x00000078 + iVar7 + iVar9));
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar9) = 0x18022a2d4;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar7 + iVar9));
                        return 0;
                    }
                    *param_2 = *pdVar3;
                    return 1;
                }
            }
            uVar11 = 8;
            *(undefined8 *)(&stack0x00000048 + iVar7 + iVar9) = 0x18022be2a;
            iVar10 = fcn.18045a350();
            iVar10 = -iVar10;
            iVar4 = *(int64_t *)(param_1 + 0x10);
            if (iVar4 == 0) {
                *(undefined8 *)(&stack0x00000048 + iVar10 + iVar7 + iVar9) = 0x18022be41;
                fcn.180229480(*(int64_t *)(&stack0x00000070 + iVar10 + iVar7 + iVar9), 
                              *(int64_t *)(&stack0x00000078 + iVar10 + iVar7 + iVar9));
                *(undefined8 *)(&stack0x00000048 + iVar10 + iVar7 + iVar9) = 0x18022be59;
                fcn.1802295a0(*(int64_t *)(&stack0x00000070 + iVar10 + iVar7 + iVar9), 
                              *(int64_t *)(&stack0x00000078 + iVar10 + iVar7 + iVar9), 
                              *(int64_t *)(&stack0x00000080 + iVar10 + iVar7 + iVar9), 
                              *(int64_t *)(&stack0x00000088 + iVar10 + iVar7 + iVar9), 
                              *(int64_t *)(&stack0x000000a0 + iVar10 + iVar7 + iVar9));
                *(undefined8 *)(&stack0x00000048 + iVar10 + iVar7 + iVar9) = 0x18022be6b;
                fcn.1802296d0(*(int64_t *)(&stack0x00000090 + iVar10 + iVar7 + iVar9));
                return 0;
            }
            if (*(int32_t *)(param_1 + 8) != 1) {
                if (*(int32_t *)(param_1 + 8) != 2) {
                    *(undefined8 *)(&stack0x00000048 + iVar10 + iVar7 + iVar9) = 0x18022bece;
                    fcn.180229480(*(int64_t *)(&stack0x00000070 + iVar10 + iVar7 + iVar9), 
                                  *(int64_t *)(&stack0x00000078 + iVar10 + iVar7 + iVar9));
                    *(undefined8 *)(&stack0x00000048 + iVar10 + iVar7 + iVar9) = 0x18022bee6;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000070 + iVar10 + iVar7 + iVar9), 
                                  *(int64_t *)(&stack0x00000078 + iVar10 + iVar7 + iVar9), 
                                  *(int64_t *)(&stack0x00000080 + iVar10 + iVar7 + iVar9), 
                                  *(int64_t *)(&stack0x00000088 + iVar10 + iVar7 + iVar9), 
                                  *(int64_t *)(&stack0x000000a0 + iVar10 + iVar7 + iVar9));
                    *(undefined8 *)(&stack0x00000048 + iVar10 + iVar7 + iVar9) = 0x18022bef8;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000090 + iVar10 + iVar7 + iVar9));
                    return 0;
                }
                uVar6 = *(undefined8 *)(param_1 + 0x18);
                *(undefined4 *)(&stack0x00000078 + iVar10 + iVar7 + iVar9) = 1;
                (&stack0x00000070)[iVar10 + iVar7 + iVar9] = 0;
                *(undefined8 *)(&stack0x00000048 + iVar10 + iVar7 + iVar9) = 0x18022bec4;
                uVar11 = func_0x00018022bd50(param_2, uVar11, iVar4, uVar6);
                return uVar11;
            }
            iVar5 = *(int64_t *)(param_1 + 0x18);
            *(undefined4 *)(&stack0x00000078 + iVar10 + iVar7 + iVar9) = 1;
            (&stack0x00000070)[iVar10 + iVar7 + iVar9] = *(char *)(iVar5 + -1 + iVar4) >> 7;
            *(undefined8 *)(&stack0x00000048 + iVar10 + iVar7 + iVar9) = 0x18022be9e;
            uVar11 = func_0x00018022bd50(param_2, uVar11);
            return uVar11;
        }
        *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar9) = 0x18022a21d;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar7 + iVar9), *(int64_t *)(&stack0x00000050 + iVar7 + iVar9));
    }
    *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar9) = 0x18022a3ef;
    fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar7 + iVar9), *(int64_t *)(&stack0x00000050 + iVar7 + iVar9), 
                  *(int64_t *)(&stack0x00000058 + iVar7 + iVar9), *(int64_t *)(&stack0x00000060 + iVar7 + iVar9), 
                  *(int64_t *)(&stack0x00000078 + iVar7 + iVar9));
    *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar9) = 0x18022a401;
    fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar7 + iVar9));
    return 0;
}

// ============================================================
// Function: FUN_18022a610
// Address: 0x18022a610
// Size: 22 bytes
// ============================================================
undefined8 fcn.18022a610(int64_t arg_48h, int64_t arg_70h)
{
    double dVar1;
    int32_t iVar2;
    double *pdVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    double dVar9;
    undefined4 *in_RDX;
    undefined8 unaff_RBX;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined8 uStackX_20;
    
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar5) = 0x18022a63a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if ((in_RDX == (undefined4 *)0x0) || (in_RCX == 0)) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a8cf;
        fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a8e7;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000058 + iVar6 + iVar5), *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a8f9;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
        return 0;
    }
    pdVar3 = *(double **)(in_RCX + 0x10);
    if (pdVar3 == (double *)0x0) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a65d;
        fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a675;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000058 + iVar6 + iVar5), *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a687;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
        return 0;
    }
    iVar2 = *(int32_t *)(in_RCX + 8);
    if (iVar2 == 2) {
        if (*(int64_t *)(in_RCX + 0x18) == 4) {
            *in_RDX = *(undefined4 *)pdVar3;
            return 1;
        }
        if (*(int64_t *)(in_RCX + 0x18) != 8) {
code_r0x00018022a6a8:
            uVar10 = 4;
            *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar5) = 0x18022bf0a;
            iVar7 = fcn.18045a350();
            iVar7 = -iVar7;
            iVar11 = *(int64_t *)(in_RCX + 0x10);
            if (iVar11 == 0) {
                *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bf21;
                fcn.180229480(*(int64_t *)((int64_t)&arg_70h + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)(&stack0x00000078 + iVar7 + iVar6 + iVar5));
                *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bf39;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_70h + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)(&stack0x00000078 + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)(&stack0x00000080 + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)(&stack0x00000088 + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)(&stack0x000000a0 + iVar7 + iVar6 + iVar5));
                *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bf4b;
                fcn.1802296d0(*(int64_t *)(&stack0x00000090 + iVar7 + iVar6 + iVar5));
                return 0;
            }
            if (*(int32_t *)(in_RCX + 8) != 1) {
                if (*(int32_t *)(in_RCX + 8) != 2) {
                    *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bf98;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_70h + iVar7 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000078 + iVar7 + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bfb0;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_70h + iVar7 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000078 + iVar7 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000080 + iVar7 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000088 + iVar7 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x000000a0 + iVar7 + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bfc2;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000090 + iVar7 + iVar6 + iVar5));
                    return 0;
                }
                uVar4 = *(undefined8 *)(in_RCX + 0x18);
                *(undefined4 *)(&stack0x00000078 + iVar7 + iVar6 + iVar5) = 0;
                *(undefined *)((int64_t)&arg_70h + iVar7 + iVar6 + iVar5) = 0;
                *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bf8e;
                uVar10 = func_0x00018022bd50(in_RDX, uVar10, iVar11, uVar4);
                return uVar10;
            }
            iVar12 = *(int64_t *)(in_RCX + 0x18);
            *(undefined8 *)(&stack0x00000080 + iVar7 + iVar6 + iVar5) = 0x18022c7da;
            iVar8 = fcn.18045a350(in_RDX, uVar10);
            iVar8 = -iVar8;
            if (-1 < *(char *)(iVar11 + -1 + iVar12)) {
                *(undefined4 *)(&stack0x000000b0 + iVar8 + iVar7 + iVar6 + iVar5) = 0;
                (&stack0x000000a8)[iVar8 + iVar7 + iVar6 + iVar5] = 0;
                *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar6 + iVar5) = 0x18022c82d;
                uVar10 = func_0x00018022bd50();
                return uVar10;
            }
            *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar6 + iVar5) = 0x18022c7ea;
            fcn.180229480(*(int64_t *)(&stack0x000000a8 + iVar8 + iVar7 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000b0 + iVar8 + iVar7 + iVar6 + iVar5));
            *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar6 + iVar5) = 0x18022c802;
            fcn.1802295a0(*(int64_t *)(&stack0x000000a8 + iVar8 + iVar7 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000b0 + iVar8 + iVar7 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000b8 + iVar8 + iVar7 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000c0 + iVar8 + iVar7 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000d8 + iVar8 + iVar7 + iVar6 + iVar5));
            *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar6 + iVar5) = 0x18022c814;
            fcn.1802296d0(*(int64_t *)(&stack0x000000c8 + iVar8 + iVar7 + iVar6 + iVar5));
            return 0;
        }
        dVar9 = *pdVar3;
        if (0xffffffff < (uint64_t)dVar9) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a6d5;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a6ed;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a6ff;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
            return 0;
        }
    } else if (iVar2 == 1) {
        if (*(int64_t *)(in_RCX + 0x18) != 4) {
            if (*(int64_t *)(in_RCX + 0x18) == 8) {
                *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar5) = unaff_RBX;
                if (0xffffffff < (uint64_t)*pdVar3) {
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a75a;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a77d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000058 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a795;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
                    return 0;
                }
                *in_RDX = SUB84(*pdVar3, 0);
                return 1;
            }
            goto code_r0x00018022a6a8;
        }
        dVar9 = (double)(uint64_t)*(uint32_t *)pdVar3;
        if ((int32_t)*(uint32_t *)pdVar3 < 0) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a7b0;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a7c8;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a7da;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
            return 0;
        }
    } else {
        if (iVar2 != 3) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a899;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a8b1;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a8c3;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
            return 0;
        }
        if (*(int64_t *)(in_RCX + 0x18) != 8) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a7f7;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a80f;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a821;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
            return 0;
        }
        dVar1 = *pdVar3;
        if (((dVar1 < 0.0) || (4294967295.0 < dVar1)) ||
           (dVar9 = (double)(int64_t)dVar1, dVar1 != (double)((uint64_t)dVar9 & 0xffffffff))) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a863;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a87b;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a88d;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
            return 0;
        }
    }
    *in_RDX = SUB84(dVar9, 0);
    return 1;
}

// ============================================================
// Function: FUN_18022a630
// Address: 0x18022a630
// Size: 258 bytes
// ============================================================
undefined8 fcn.18022a610(int64_t arg_48h, int64_t arg_70h)
{
    double dVar1;
    int32_t iVar2;
    double *pdVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    double dVar9;
    undefined4 *in_RDX;
    undefined8 unaff_RBX;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined8 uStackX_20;
    
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar5) = 0x18022a63a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if ((in_RDX == (undefined4 *)0x0) || (in_RCX == 0)) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a8cf;
        fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a8e7;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000058 + iVar6 + iVar5), *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a8f9;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
        return 0;
    }
    pdVar3 = *(double **)(in_RCX + 0x10);
    if (pdVar3 == (double *)0x0) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a65d;
        fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a675;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000058 + iVar6 + iVar5), *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a687;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
        return 0;
    }
    iVar2 = *(int32_t *)(in_RCX + 8);
    if (iVar2 == 2) {
        if (*(int64_t *)(in_RCX + 0x18) == 4) {
            *in_RDX = *(undefined4 *)pdVar3;
            return 1;
        }
        if (*(int64_t *)(in_RCX + 0x18) != 8) {
code_r0x00018022a6a8:
            uVar10 = 4;
            *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar5) = 0x18022bf0a;
            iVar7 = fcn.18045a350();
            iVar7 = -iVar7;
            iVar11 = *(int64_t *)(in_RCX + 0x10);
            if (iVar11 == 0) {
                *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bf21;
                fcn.180229480(*(int64_t *)((int64_t)&arg_70h + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)(&stack0x00000078 + iVar7 + iVar6 + iVar5));
                *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bf39;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_70h + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)(&stack0x00000078 + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)(&stack0x00000080 + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)(&stack0x00000088 + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)(&stack0x000000a0 + iVar7 + iVar6 + iVar5));
                *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bf4b;
                fcn.1802296d0(*(int64_t *)(&stack0x00000090 + iVar7 + iVar6 + iVar5));
                return 0;
            }
            if (*(int32_t *)(in_RCX + 8) != 1) {
                if (*(int32_t *)(in_RCX + 8) != 2) {
                    *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bf98;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_70h + iVar7 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000078 + iVar7 + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bfb0;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_70h + iVar7 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000078 + iVar7 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000080 + iVar7 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000088 + iVar7 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x000000a0 + iVar7 + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bfc2;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000090 + iVar7 + iVar6 + iVar5));
                    return 0;
                }
                uVar4 = *(undefined8 *)(in_RCX + 0x18);
                *(undefined4 *)(&stack0x00000078 + iVar7 + iVar6 + iVar5) = 0;
                *(undefined *)((int64_t)&arg_70h + iVar7 + iVar6 + iVar5) = 0;
                *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bf8e;
                uVar10 = func_0x00018022bd50(in_RDX, uVar10, iVar11, uVar4);
                return uVar10;
            }
            iVar12 = *(int64_t *)(in_RCX + 0x18);
            *(undefined8 *)(&stack0x00000080 + iVar7 + iVar6 + iVar5) = 0x18022c7da;
            iVar8 = fcn.18045a350(in_RDX, uVar10);
            iVar8 = -iVar8;
            if (-1 < *(char *)(iVar11 + -1 + iVar12)) {
                *(undefined4 *)(&stack0x000000b0 + iVar8 + iVar7 + iVar6 + iVar5) = 0;
                (&stack0x000000a8)[iVar8 + iVar7 + iVar6 + iVar5] = 0;
                *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar6 + iVar5) = 0x18022c82d;
                uVar10 = func_0x00018022bd50();
                return uVar10;
            }
            *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar6 + iVar5) = 0x18022c7ea;
            fcn.180229480(*(int64_t *)(&stack0x000000a8 + iVar8 + iVar7 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000b0 + iVar8 + iVar7 + iVar6 + iVar5));
            *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar6 + iVar5) = 0x18022c802;
            fcn.1802295a0(*(int64_t *)(&stack0x000000a8 + iVar8 + iVar7 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000b0 + iVar8 + iVar7 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000b8 + iVar8 + iVar7 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000c0 + iVar8 + iVar7 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000d8 + iVar8 + iVar7 + iVar6 + iVar5));
            *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar6 + iVar5) = 0x18022c814;
            fcn.1802296d0(*(int64_t *)(&stack0x000000c8 + iVar8 + iVar7 + iVar6 + iVar5));
            return 0;
        }
        dVar9 = *pdVar3;
        if (0xffffffff < (uint64_t)dVar9) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a6d5;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a6ed;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a6ff;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
            return 0;
        }
    } else if (iVar2 == 1) {
        if (*(int64_t *)(in_RCX + 0x18) != 4) {
            if (*(int64_t *)(in_RCX + 0x18) == 8) {
                *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar5) = unaff_RBX;
                if (0xffffffff < (uint64_t)*pdVar3) {
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a75a;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a77d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000058 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a795;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
                    return 0;
                }
                *in_RDX = SUB84(*pdVar3, 0);
                return 1;
            }
            goto code_r0x00018022a6a8;
        }
        dVar9 = (double)(uint64_t)*(uint32_t *)pdVar3;
        if ((int32_t)*(uint32_t *)pdVar3 < 0) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a7b0;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a7c8;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a7da;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
            return 0;
        }
    } else {
        if (iVar2 != 3) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a899;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a8b1;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a8c3;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
            return 0;
        }
        if (*(int64_t *)(in_RCX + 0x18) != 8) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a7f7;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a80f;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a821;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
            return 0;
        }
        dVar1 = *pdVar3;
        if (((dVar1 < 0.0) || (4294967295.0 < dVar1)) ||
           (dVar9 = (double)(int64_t)dVar1, dVar1 != (double)((uint64_t)dVar9 & 0xffffffff))) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a863;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a87b;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a88d;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
            return 0;
        }
    }
    *in_RDX = SUB84(dVar9, 0);
    return 1;
}

// ============================================================
// Function: FUN_18022a732
// Address: 0x18022a732
// Size: 35 bytes
// ============================================================
undefined8 fcn.18022a610(int64_t arg_48h, int64_t arg_70h)
{
    double dVar1;
    int32_t iVar2;
    double *pdVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    double dVar9;
    undefined4 *in_RDX;
    undefined8 unaff_RBX;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined8 uStackX_20;
    
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar5) = 0x18022a63a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if ((in_RDX == (undefined4 *)0x0) || (in_RCX == 0)) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a8cf;
        fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a8e7;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000058 + iVar6 + iVar5), *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a8f9;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
        return 0;
    }
    pdVar3 = *(double **)(in_RCX + 0x10);
    if (pdVar3 == (double *)0x0) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a65d;
        fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a675;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000058 + iVar6 + iVar5), *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a687;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
        return 0;
    }
    iVar2 = *(int32_t *)(in_RCX + 8);
    if (iVar2 == 2) {
        if (*(int64_t *)(in_RCX + 0x18) == 4) {
            *in_RDX = *(undefined4 *)pdVar3;
            return 1;
        }
        if (*(int64_t *)(in_RCX + 0x18) != 8) {
code_r0x00018022a6a8:
            uVar10 = 4;
            *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar5) = 0x18022bf0a;
            iVar7 = fcn.18045a350();
            iVar7 = -iVar7;
            iVar11 = *(int64_t *)(in_RCX + 0x10);
            if (iVar11 == 0) {
                *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bf21;
                fcn.180229480(*(int64_t *)((int64_t)&arg_70h + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)(&stack0x00000078 + iVar7 + iVar6 + iVar5));
                *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bf39;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_70h + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)(&stack0x00000078 + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)(&stack0x00000080 + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)(&stack0x00000088 + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)(&stack0x000000a0 + iVar7 + iVar6 + iVar5));
                *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bf4b;
                fcn.1802296d0(*(int64_t *)(&stack0x00000090 + iVar7 + iVar6 + iVar5));
                return 0;
            }
            if (*(int32_t *)(in_RCX + 8) != 1) {
                if (*(int32_t *)(in_RCX + 8) != 2) {
                    *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bf98;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_70h + iVar7 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000078 + iVar7 + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bfb0;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_70h + iVar7 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000078 + iVar7 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000080 + iVar7 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000088 + iVar7 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x000000a0 + iVar7 + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bfc2;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000090 + iVar7 + iVar6 + iVar5));
                    return 0;
                }
                uVar4 = *(undefined8 *)(in_RCX + 0x18);
                *(undefined4 *)(&stack0x00000078 + iVar7 + iVar6 + iVar5) = 0;
                *(undefined *)((int64_t)&arg_70h + iVar7 + iVar6 + iVar5) = 0;
                *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bf8e;
                uVar10 = func_0x00018022bd50(in_RDX, uVar10, iVar11, uVar4);
                return uVar10;
            }
            iVar12 = *(int64_t *)(in_RCX + 0x18);
            *(undefined8 *)(&stack0x00000080 + iVar7 + iVar6 + iVar5) = 0x18022c7da;
            iVar8 = fcn.18045a350(in_RDX, uVar10);
            iVar8 = -iVar8;
            if (-1 < *(char *)(iVar11 + -1 + iVar12)) {
                *(undefined4 *)(&stack0x000000b0 + iVar8 + iVar7 + iVar6 + iVar5) = 0;
                (&stack0x000000a8)[iVar8 + iVar7 + iVar6 + iVar5] = 0;
                *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar6 + iVar5) = 0x18022c82d;
                uVar10 = func_0x00018022bd50();
                return uVar10;
            }
            *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar6 + iVar5) = 0x18022c7ea;
            fcn.180229480(*(int64_t *)(&stack0x000000a8 + iVar8 + iVar7 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000b0 + iVar8 + iVar7 + iVar6 + iVar5));
            *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar6 + iVar5) = 0x18022c802;
            fcn.1802295a0(*(int64_t *)(&stack0x000000a8 + iVar8 + iVar7 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000b0 + iVar8 + iVar7 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000b8 + iVar8 + iVar7 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000c0 + iVar8 + iVar7 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000d8 + iVar8 + iVar7 + iVar6 + iVar5));
            *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar6 + iVar5) = 0x18022c814;
            fcn.1802296d0(*(int64_t *)(&stack0x000000c8 + iVar8 + iVar7 + iVar6 + iVar5));
            return 0;
        }
        dVar9 = *pdVar3;
        if (0xffffffff < (uint64_t)dVar9) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a6d5;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a6ed;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a6ff;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
            return 0;
        }
    } else if (iVar2 == 1) {
        if (*(int64_t *)(in_RCX + 0x18) != 4) {
            if (*(int64_t *)(in_RCX + 0x18) == 8) {
                *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar5) = unaff_RBX;
                if (0xffffffff < (uint64_t)*pdVar3) {
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a75a;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a77d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000058 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a795;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
                    return 0;
                }
                *in_RDX = SUB84(*pdVar3, 0);
                return 1;
            }
            goto code_r0x00018022a6a8;
        }
        dVar9 = (double)(uint64_t)*(uint32_t *)pdVar3;
        if ((int32_t)*(uint32_t *)pdVar3 < 0) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a7b0;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a7c8;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a7da;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
            return 0;
        }
    } else {
        if (iVar2 != 3) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a899;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a8b1;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a8c3;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
            return 0;
        }
        if (*(int64_t *)(in_RCX + 0x18) != 8) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a7f7;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a80f;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a821;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
            return 0;
        }
        dVar1 = *pdVar3;
        if (((dVar1 < 0.0) || (4294967295.0 < dVar1)) ||
           (dVar9 = (double)(int64_t)dVar1, dVar1 != (double)((uint64_t)dVar9 & 0xffffffff))) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a863;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a87b;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a88d;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
            return 0;
        }
    }
    *in_RDX = SUB84(dVar9, 0);
    return 1;
}

// ============================================================
// Function: FUN_18022a755
// Address: 0x18022a755
// Size: 76 bytes
// ============================================================
undefined8 fcn.18022a610(int64_t arg_48h, int64_t arg_70h)
{
    double dVar1;
    int32_t iVar2;
    double *pdVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    double dVar9;
    undefined4 *in_RDX;
    undefined8 unaff_RBX;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined8 uStackX_20;
    
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar5) = 0x18022a63a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if ((in_RDX == (undefined4 *)0x0) || (in_RCX == 0)) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a8cf;
        fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a8e7;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000058 + iVar6 + iVar5), *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a8f9;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
        return 0;
    }
    pdVar3 = *(double **)(in_RCX + 0x10);
    if (pdVar3 == (double *)0x0) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a65d;
        fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a675;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000058 + iVar6 + iVar5), *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a687;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
        return 0;
    }
    iVar2 = *(int32_t *)(in_RCX + 8);
    if (iVar2 == 2) {
        if (*(int64_t *)(in_RCX + 0x18) == 4) {
            *in_RDX = *(undefined4 *)pdVar3;
            return 1;
        }
        if (*(int64_t *)(in_RCX + 0x18) != 8) {
code_r0x00018022a6a8:
            uVar10 = 4;
            *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar5) = 0x18022bf0a;
            iVar7 = fcn.18045a350();
            iVar7 = -iVar7;
            iVar11 = *(int64_t *)(in_RCX + 0x10);
            if (iVar11 == 0) {
                *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bf21;
                fcn.180229480(*(int64_t *)((int64_t)&arg_70h + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)(&stack0x00000078 + iVar7 + iVar6 + iVar5));
                *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bf39;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_70h + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)(&stack0x00000078 + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)(&stack0x00000080 + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)(&stack0x00000088 + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)(&stack0x000000a0 + iVar7 + iVar6 + iVar5));
                *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bf4b;
                fcn.1802296d0(*(int64_t *)(&stack0x00000090 + iVar7 + iVar6 + iVar5));
                return 0;
            }
            if (*(int32_t *)(in_RCX + 8) != 1) {
                if (*(int32_t *)(in_RCX + 8) != 2) {
                    *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bf98;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_70h + iVar7 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000078 + iVar7 + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bfb0;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_70h + iVar7 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000078 + iVar7 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000080 + iVar7 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000088 + iVar7 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x000000a0 + iVar7 + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bfc2;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000090 + iVar7 + iVar6 + iVar5));
                    return 0;
                }
                uVar4 = *(undefined8 *)(in_RCX + 0x18);
                *(undefined4 *)(&stack0x00000078 + iVar7 + iVar6 + iVar5) = 0;
                *(undefined *)((int64_t)&arg_70h + iVar7 + iVar6 + iVar5) = 0;
                *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bf8e;
                uVar10 = func_0x00018022bd50(in_RDX, uVar10, iVar11, uVar4);
                return uVar10;
            }
            iVar12 = *(int64_t *)(in_RCX + 0x18);
            *(undefined8 *)(&stack0x00000080 + iVar7 + iVar6 + iVar5) = 0x18022c7da;
            iVar8 = fcn.18045a350(in_RDX, uVar10);
            iVar8 = -iVar8;
            if (-1 < *(char *)(iVar11 + -1 + iVar12)) {
                *(undefined4 *)(&stack0x000000b0 + iVar8 + iVar7 + iVar6 + iVar5) = 0;
                (&stack0x000000a8)[iVar8 + iVar7 + iVar6 + iVar5] = 0;
                *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar6 + iVar5) = 0x18022c82d;
                uVar10 = func_0x00018022bd50();
                return uVar10;
            }
            *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar6 + iVar5) = 0x18022c7ea;
            fcn.180229480(*(int64_t *)(&stack0x000000a8 + iVar8 + iVar7 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000b0 + iVar8 + iVar7 + iVar6 + iVar5));
            *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar6 + iVar5) = 0x18022c802;
            fcn.1802295a0(*(int64_t *)(&stack0x000000a8 + iVar8 + iVar7 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000b0 + iVar8 + iVar7 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000b8 + iVar8 + iVar7 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000c0 + iVar8 + iVar7 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000d8 + iVar8 + iVar7 + iVar6 + iVar5));
            *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar6 + iVar5) = 0x18022c814;
            fcn.1802296d0(*(int64_t *)(&stack0x000000c8 + iVar8 + iVar7 + iVar6 + iVar5));
            return 0;
        }
        dVar9 = *pdVar3;
        if (0xffffffff < (uint64_t)dVar9) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a6d5;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a6ed;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a6ff;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
            return 0;
        }
    } else if (iVar2 == 1) {
        if (*(int64_t *)(in_RCX + 0x18) != 4) {
            if (*(int64_t *)(in_RCX + 0x18) == 8) {
                *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar5) = unaff_RBX;
                if (0xffffffff < (uint64_t)*pdVar3) {
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a75a;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a77d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000058 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a795;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
                    return 0;
                }
                *in_RDX = SUB84(*pdVar3, 0);
                return 1;
            }
            goto code_r0x00018022a6a8;
        }
        dVar9 = (double)(uint64_t)*(uint32_t *)pdVar3;
        if ((int32_t)*(uint32_t *)pdVar3 < 0) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a7b0;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a7c8;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a7da;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
            return 0;
        }
    } else {
        if (iVar2 != 3) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a899;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a8b1;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a8c3;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
            return 0;
        }
        if (*(int64_t *)(in_RCX + 0x18) != 8) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a7f7;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a80f;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a821;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
            return 0;
        }
        dVar1 = *pdVar3;
        if (((dVar1 < 0.0) || (4294967295.0 < dVar1)) ||
           (dVar9 = (double)(int64_t)dVar1, dVar1 != (double)((uint64_t)dVar9 & 0xffffffff))) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a863;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a87b;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a88d;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
            return 0;
        }
    }
    *in_RDX = SUB84(dVar9, 0);
    return 1;
}

// ============================================================
// Function: FUN_18022a7a1
// Address: 0x18022a7a1
// Size: 351 bytes
// ============================================================
undefined8 fcn.18022a610(int64_t arg_48h, int64_t arg_70h)
{
    double dVar1;
    int32_t iVar2;
    double *pdVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    double dVar9;
    undefined4 *in_RDX;
    undefined8 unaff_RBX;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined8 uStackX_20;
    
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar5) = 0x18022a63a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if ((in_RDX == (undefined4 *)0x0) || (in_RCX == 0)) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a8cf;
        fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a8e7;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000058 + iVar6 + iVar5), *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a8f9;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
        return 0;
    }
    pdVar3 = *(double **)(in_RCX + 0x10);
    if (pdVar3 == (double *)0x0) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a65d;
        fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a675;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000058 + iVar6 + iVar5), *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a687;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
        return 0;
    }
    iVar2 = *(int32_t *)(in_RCX + 8);
    if (iVar2 == 2) {
        if (*(int64_t *)(in_RCX + 0x18) == 4) {
            *in_RDX = *(undefined4 *)pdVar3;
            return 1;
        }
        if (*(int64_t *)(in_RCX + 0x18) != 8) {
code_r0x00018022a6a8:
            uVar10 = 4;
            *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar5) = 0x18022bf0a;
            iVar7 = fcn.18045a350();
            iVar7 = -iVar7;
            iVar11 = *(int64_t *)(in_RCX + 0x10);
            if (iVar11 == 0) {
                *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bf21;
                fcn.180229480(*(int64_t *)((int64_t)&arg_70h + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)(&stack0x00000078 + iVar7 + iVar6 + iVar5));
                *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bf39;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_70h + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)(&stack0x00000078 + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)(&stack0x00000080 + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)(&stack0x00000088 + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)(&stack0x000000a0 + iVar7 + iVar6 + iVar5));
                *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bf4b;
                fcn.1802296d0(*(int64_t *)(&stack0x00000090 + iVar7 + iVar6 + iVar5));
                return 0;
            }
            if (*(int32_t *)(in_RCX + 8) != 1) {
                if (*(int32_t *)(in_RCX + 8) != 2) {
                    *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bf98;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_70h + iVar7 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000078 + iVar7 + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bfb0;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_70h + iVar7 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000078 + iVar7 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000080 + iVar7 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000088 + iVar7 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x000000a0 + iVar7 + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bfc2;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000090 + iVar7 + iVar6 + iVar5));
                    return 0;
                }
                uVar4 = *(undefined8 *)(in_RCX + 0x18);
                *(undefined4 *)(&stack0x00000078 + iVar7 + iVar6 + iVar5) = 0;
                *(undefined *)((int64_t)&arg_70h + iVar7 + iVar6 + iVar5) = 0;
                *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6 + iVar5) = 0x18022bf8e;
                uVar10 = func_0x00018022bd50(in_RDX, uVar10, iVar11, uVar4);
                return uVar10;
            }
            iVar12 = *(int64_t *)(in_RCX + 0x18);
            *(undefined8 *)(&stack0x00000080 + iVar7 + iVar6 + iVar5) = 0x18022c7da;
            iVar8 = fcn.18045a350(in_RDX, uVar10);
            iVar8 = -iVar8;
            if (-1 < *(char *)(iVar11 + -1 + iVar12)) {
                *(undefined4 *)(&stack0x000000b0 + iVar8 + iVar7 + iVar6 + iVar5) = 0;
                (&stack0x000000a8)[iVar8 + iVar7 + iVar6 + iVar5] = 0;
                *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar6 + iVar5) = 0x18022c82d;
                uVar10 = func_0x00018022bd50();
                return uVar10;
            }
            *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar6 + iVar5) = 0x18022c7ea;
            fcn.180229480(*(int64_t *)(&stack0x000000a8 + iVar8 + iVar7 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000b0 + iVar8 + iVar7 + iVar6 + iVar5));
            *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar6 + iVar5) = 0x18022c802;
            fcn.1802295a0(*(int64_t *)(&stack0x000000a8 + iVar8 + iVar7 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000b0 + iVar8 + iVar7 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000b8 + iVar8 + iVar7 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000c0 + iVar8 + iVar7 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000d8 + iVar8 + iVar7 + iVar6 + iVar5));
            *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar6 + iVar5) = 0x18022c814;
            fcn.1802296d0(*(int64_t *)(&stack0x000000c8 + iVar8 + iVar7 + iVar6 + iVar5));
            return 0;
        }
        dVar9 = *pdVar3;
        if (0xffffffff < (uint64_t)dVar9) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a6d5;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a6ed;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a6ff;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
            return 0;
        }
    } else if (iVar2 == 1) {
        if (*(int64_t *)(in_RCX + 0x18) != 4) {
            if (*(int64_t *)(in_RCX + 0x18) == 8) {
                *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar5) = unaff_RBX;
                if (0xffffffff < (uint64_t)*pdVar3) {
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a75a;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a77d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000058 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a795;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
                    return 0;
                }
                *in_RDX = SUB84(*pdVar3, 0);
                return 1;
            }
            goto code_r0x00018022a6a8;
        }
        dVar9 = (double)(uint64_t)*(uint32_t *)pdVar3;
        if ((int32_t)*(uint32_t *)pdVar3 < 0) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a7b0;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a7c8;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a7da;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
            return 0;
        }
    } else {
        if (iVar2 != 3) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a899;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a8b1;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a8c3;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
            return 0;
        }
        if (*(int64_t *)(in_RCX + 0x18) != 8) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a7f7;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a80f;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a821;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
            return 0;
        }
        dVar1 = *pdVar3;
        if (((dVar1 < 0.0) || (4294967295.0 < dVar1)) ||
           (dVar9 = (double)(int64_t)dVar1, dVar1 != (double)((uint64_t)dVar9 & 0xffffffff))) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a863;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a87b;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000078 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x18022a88d;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
            return 0;
        }
    }
    *in_RDX = SUB84(dVar9, 0);
    return 1;
}

// ============================================================
// Function: FUN_18022a900
// Address: 0x18022a900
// Size: 610 bytes
// ============================================================
undefined8 fcn.18022a5d0(int64_t param_1, double *param_2)
{
    int32_t iVar1;
    double *pdVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    double dVar9;
    undefined8 uVar10;
    int64_t iVar11;
    double dVar12;
    double dVar13;
    undefined8 uStackX_20;
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar4) = 0x18022a90a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((param_2 == (double *)0x0) || (param_1 == 0)) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022ab31;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), *(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
    } else {
        pdVar2 = *(double **)(param_1 + 0x10);
        if (pdVar2 != (double *)0x0) {
            iVar1 = *(int32_t *)(param_1 + 8);
            if (iVar1 != 2) {
                if (iVar1 != 1) {
                    if (iVar1 != 3) {
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022aafb;
                        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                                      *(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022ab13;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                                      *(int64_t *)(&stack0x00000050 + iVar5 + iVar4), 
                                      *(int64_t *)(&stack0x00000058 + iVar5 + iVar4), 
                                      *(int64_t *)(&stack0x00000060 + iVar5 + iVar4), 
                                      *(int64_t *)(&stack0x00000078 + iVar5 + iVar4));
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022ab25;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar5 + iVar4));
                        return 0;
                    }
                    if (*(int64_t *)(param_1 + 0x18) == 8) {
                        dVar9 = *pdVar2;
                        if ((0.0 <= dVar9) && (dVar9 < 1.844674407370955e+19)) {
                            iVar6 = 0;
                            dVar12 = dVar9;
                            if ((9.223372036854776e+18 <= dVar9) &&
                               (dVar12 = dVar9 - 9.223372036854776e+18, dVar12 < 9.223372036854776e+18)) {
                                iVar6 = -0x8000000000000000;
                            }
                            dVar12 = (double)((int64_t)dVar12 + iVar6);
                            if ((int64_t)dVar12 < 0) {
                                dVar13 = (double)((uint64_t)dVar12 >> 1 | (uint64_t)(SUB84(dVar12, 0) & 1));
                                dVar13 = dVar13 + dVar13;
                            } else {
                                dVar13 = (double)(int64_t)dVar12;
                            }
                            if (dVar9 == dVar13) {
                                *param_2 = dVar12;
                                return 1;
                            }
                        }
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022aac5;
                        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                                      *(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022aadd;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                                      *(int64_t *)(&stack0x00000050 + iVar5 + iVar4), 
                                      *(int64_t *)(&stack0x00000058 + iVar5 + iVar4), 
                                      *(int64_t *)(&stack0x00000060 + iVar5 + iVar4), 
                                      *(int64_t *)(&stack0x00000078 + iVar5 + iVar4));
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022aaef;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar5 + iVar4));
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022aa09;
                    fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022aa21;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000050 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000058 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000060 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000078 + iVar5 + iVar4));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022aa33;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar5 + iVar4));
                    return 0;
                }
                if (*(int64_t *)(param_1 + 0x18) == 4) {
                    dVar9 = (double)(int64_t)*(int32_t *)pdVar2;
                    if (-1 < *(int32_t *)pdVar2) {
code_r0x00018022a9da:
                        *param_2 = dVar9;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022a9ec;
                    fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
                } else {
                    if (*(int64_t *)(param_1 + 0x18) != 8) goto code_r0x00018022a951;
                    dVar9 = *pdVar2;
                    if (-1 < (int64_t)dVar9) goto code_r0x00018022a9da;
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022a9a2;
                    fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
                }
                *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022a9ba;
                fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000050 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000058 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000060 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000078 + iVar5 + iVar4));
                *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022a9cc;
                fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar5 + iVar4));
                return 0;
            }
            if (*(int64_t *)(param_1 + 0x18) == 4) {
                *param_2 = (double)(uint64_t)*(uint32_t *)pdVar2;
                return 1;
            }
            if (*(int64_t *)(param_1 + 0x18) == 8) {
                *param_2 = *pdVar2;
                return 1;
            }
code_r0x00018022a951:
            uVar10 = 8;
            *(undefined8 *)(&stack0x00000048 + iVar5 + iVar4) = 0x18022bf0a;
            iVar7 = fcn.18045a350();
            iVar7 = -iVar7;
            iVar6 = *(int64_t *)(param_1 + 0x10);
            if (iVar6 == 0) {
                *(undefined8 *)(&stack0x00000048 + iVar7 + iVar5 + iVar4) = 0x18022bf21;
                fcn.180229480(*(int64_t *)(&stack0x00000070 + iVar7 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000078 + iVar7 + iVar5 + iVar4));
                *(undefined8 *)(&stack0x00000048 + iVar7 + iVar5 + iVar4) = 0x18022bf39;
                fcn.1802295a0(*(int64_t *)(&stack0x00000070 + iVar7 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000078 + iVar7 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000080 + iVar7 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000088 + iVar7 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x000000a0 + iVar7 + iVar5 + iVar4));
                *(undefined8 *)(&stack0x00000048 + iVar7 + iVar5 + iVar4) = 0x18022bf4b;
                fcn.1802296d0(*(int64_t *)(&stack0x00000090 + iVar7 + iVar5 + iVar4));
                return 0;
            }
            if (*(int32_t *)(param_1 + 8) != 1) {
                if (*(int32_t *)(param_1 + 8) != 2) {
                    *(undefined8 *)(&stack0x00000048 + iVar7 + iVar5 + iVar4) = 0x18022bf98;
                    fcn.180229480(*(int64_t *)(&stack0x00000070 + iVar7 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000078 + iVar7 + iVar5 + iVar4));
                    *(undefined8 *)(&stack0x00000048 + iVar7 + iVar5 + iVar4) = 0x18022bfb0;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000070 + iVar7 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000078 + iVar7 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000080 + iVar7 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000088 + iVar7 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x000000a0 + iVar7 + iVar5 + iVar4));
                    *(undefined8 *)(&stack0x00000048 + iVar7 + iVar5 + iVar4) = 0x18022bfc2;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000090 + iVar7 + iVar5 + iVar4));
                    return 0;
                }
                uVar3 = *(undefined8 *)(param_1 + 0x18);
                *(undefined4 *)(&stack0x00000078 + iVar7 + iVar5 + iVar4) = 0;
                (&stack0x00000070)[iVar7 + iVar5 + iVar4] = 0;
                *(undefined8 *)(&stack0x00000048 + iVar7 + iVar5 + iVar4) = 0x18022bf8e;
                uVar10 = func_0x00018022bd50(param_2, uVar10, iVar6, uVar3);
                return uVar10;
            }
            iVar11 = *(int64_t *)(param_1 + 0x18);
            *(undefined8 *)(&stack0x00000080 + iVar7 + iVar5 + iVar4) = 0x18022c7da;
            iVar8 = fcn.18045a350(param_2, uVar10);
            iVar8 = -iVar8;
            if (-1 < *(char *)(iVar6 + -1 + iVar11)) {
                *(undefined4 *)(&stack0x000000b0 + iVar8 + iVar7 + iVar5 + iVar4) = 0;
                (&stack0x000000a8)[iVar8 + iVar7 + iVar5 + iVar4] = 0;
                *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar5 + iVar4) = 0x18022c82d;
                uVar10 = func_0x00018022bd50();
                return uVar10;
            }
            *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar5 + iVar4) = 0x18022c7ea;
            fcn.180229480(*(int64_t *)(&stack0x000000a8 + iVar8 + iVar7 + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x000000b0 + iVar8 + iVar7 + iVar5 + iVar4));
            *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar5 + iVar4) = 0x18022c802;
            fcn.1802295a0(*(int64_t *)(&stack0x000000a8 + iVar8 + iVar7 + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x000000b0 + iVar8 + iVar7 + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x000000b8 + iVar8 + iVar7 + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x000000c0 + iVar8 + iVar7 + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x000000d8 + iVar8 + iVar7 + iVar5 + iVar4));
            *(undefined8 *)(&stack0x00000080 + iVar8 + iVar7 + iVar5 + iVar4) = 0x18022c814;
            fcn.1802296d0(*(int64_t *)(&stack0x000000c8 + iVar8 + iVar7 + iVar5 + iVar4));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022a92d;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), *(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
    }
    *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022ab49;
    fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), *(int64_t *)(&stack0x00000050 + iVar5 + iVar4), 
                  *(int64_t *)(&stack0x00000058 + iVar5 + iVar4), *(int64_t *)(&stack0x00000060 + iVar5 + iVar4), 
                  *(int64_t *)(&stack0x00000078 + iVar5 + iVar4));
    *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + iVar4) = 0x18022ab5b;
    fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar5 + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_18022ab70
// Address: 0x18022ab70
// Size: 157 bytes
// ============================================================
undefined8 fcn.18022ab70(int64_t param_1, undefined8 *param_2)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022ab7a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if ((param_2 != (undefined8 *)0x0) && (param_1 != 0)) {
        if (*(int32_t *)(param_1 + 8) != 6) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022ab92;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
            *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022abaa;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                          *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                          *(int64_t *)(&stack0x00000050 + iVar1));
            *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022abbc;
            fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
            return 0;
        }
        *param_2 = **(undefined8 **)(param_1 + 0x10);
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022abdc;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022abf4;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                  *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022ac06;
    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
    return 0;
}

// ============================================================
// Function: FUN_18022ac10
// Address: 0x18022ac10
// Size: 387 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Variable var_7h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.18022ac10(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t in_RCX;
    int64_t *in_RDX;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022ac30;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((in_RDX == (int64_t *)0x0) || (in_RCX == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022ad4c;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
    } else {
        if (*(int32_t *)(in_RCX + 8) != 4) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022ac59;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022ac71;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            goto code_r0x00018022ad69;
        }
        uVar4 = *(uint64_t *)(in_RCX + 0x18);
        if (*(int64_t *)(in_RCX + 0x10) != 0) {
            iVar3 = *in_RDX;
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022acb3;
                iVar3 = func_0x0001802248d0(uVar4 + 1, 0x1804c0808, 0x554);
                if (iVar3 == 0) {
                    return 0;
                }
                *in_RDX = iVar3;
                in_R8 = uVar4 + 1;
            }
            if (uVar4 <= in_R8) {
                uVar1 = *(undefined8 *)(in_RCX + 0x10);
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022acfb;
                func_0x000180498030(iVar3, uVar1, uVar4);
                uVar4 = *(uint64_t *)(in_RCX + 0x18);
                if (in_R8 <= uVar4) {
                    uVar1 = *(undefined8 *)(in_RCX + 0x10);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022ad10;
                    uVar4 = func_0x000180223860(uVar1, uVar4);
                    if (in_R8 <= uVar4) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022ad1a;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022ad32;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                                      *(int64_t *)(&stack0x00000048 + iVar2));
                        goto code_r0x00018022ad69;
                    }
                }
                *(undefined *)(uVar4 + *in_RDX) = 0;
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022accd;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022ace5;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            goto code_r0x00018022ad69;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022ac8b;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022ad64;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
code_r0x00018022ad69:
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022ad76;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_18022ada0
// Address: 0x18022ada0
// Size: 181 bytes
// ============================================================
undefined8 fcn.18022ada0(int64_t param_1, undefined8 *param_2)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022adaa;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if ((param_2 == (undefined8 *)0x0) || (param_1 == 0)) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022ae24;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022ae3c;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022ae4e;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    if (*(int32_t *)(param_1 + 8) == 6) {
        *param_2 = **(undefined8 **)(param_1 + 0x10);
        return 1;
    }
    if (*(int32_t *)(param_1 + 8) != 4) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022addd;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022adf5;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022ae07;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    *param_2 = *(undefined8 *)(param_1 + 0x10);
    return 1;
}

// ============================================================
// Function: FUN_18022ae60
// Address: 0x18022ae60
// Size: 103 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t * fcn.18022ae60(int64_t arg_28h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022ae70;
    iVar4 = fcn.18045a350();
    if ((in_RCX != (int64_t *)0x0) && (in_RDX != 0)) {
        iVar2 = *in_RCX;
        while (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 - iVar4) = 0x18022ae9b;
            iVar3 = func_0x000180498f10(in_RDX, iVar2);
            if (iVar3 == 0) {
                return in_RCX;
            }
            piVar1 = in_RCX + 5;
            in_RCX = in_RCX + 5;
            iVar2 = *piVar1;
        }
    }
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_18022aef0
// Address: 0x18022aef0
// Size: 90 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18022aef0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    uint64_t uVar5;
    int64_t in_RDX;
    uint64_t uVar6;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022af00;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022af13;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022af2b;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022af3d;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RSI;
    *(undefined8 *)(in_RCX + 0x20) = 0;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022af61;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022af79;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022af8b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    iVar2 = *(int32_t *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_R14;
    if (iVar2 == 2) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022afb4;
        iVar2 = fcn.180255370(in_RDX);
        if (iVar2 == 0) goto code_r0x00018022afe3;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022afbd;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
code_r0x00018022afc2:
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022afd5;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
    } else {
code_r0x00018022afe3:
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022afeb;
        iVar3 = fcn.180255500(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                              *(int64_t *)(&stack0x00000068 + iVar4), *(int64_t *)(&stack0x00000070 + iVar4));
        iVar2 = *(int32_t *)(in_RCX + 8);
        uVar5 = (uint64_t)((int32_t)(iVar3 + 7 + (iVar3 + 7 >> 0x1f & 7U)) >> 3);
        uVar6 = uVar5 + 1;
        if (iVar2 != 1) {
            uVar6 = uVar5;
        }
        uVar5 = 1;
        if (uVar6 != 0) {
            uVar5 = uVar6;
        }
        iVar1 = *(int64_t *)(in_RCX + 0x10);
        if (iVar1 == 0) {
            *(uint64_t *)(in_RCX + 0x20) = uVar5;
            return 1;
        }
        uVar6 = *(uint64_t *)(in_RCX + 0x18);
        if (uVar6 < uVar5) {
            *(uint64_t *)(in_RCX + 0x20) = uVar5;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022b0b5;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022b0cd;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            goto code_r0x00018022b0d2;
        }
        if (iVar2 == 1) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022b08f;
            iVar2 = fcn.1802558d0(in_RDX, iVar1, uVar6 & 0xffffffff);
            if (-1 < iVar2) {
code_r0x00018022b09f:
                *(uint64_t *)(in_RCX + 0x20) = *(uint64_t *)(in_RCX + 0x18);
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022b098;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        } else {
            if (iVar2 != 2) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022b047;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4));
                goto code_r0x00018022afc2;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022b05c;
            iVar2 = fcn.180254da0(in_RDX, iVar1, uVar6 & 0xffffffff);
            if (-1 < iVar2) goto code_r0x00018022b09f;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022b065;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022b07d;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
    }
code_r0x00018022b0d2:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022b0df;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_18022af4a
// Address: 0x18022af4a
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18022aef0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    uint64_t uVar5;
    int64_t in_RDX;
    uint64_t uVar6;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022af00;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022af13;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022af2b;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022af3d;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RSI;
    *(undefined8 *)(in_RCX + 0x20) = 0;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022af61;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022af79;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022af8b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    iVar2 = *(int32_t *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_R14;
    if (iVar2 == 2) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022afb4;
        iVar2 = fcn.180255370(in_RDX);
        if (iVar2 == 0) goto code_r0x00018022afe3;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022afbd;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
code_r0x00018022afc2:
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022afd5;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
    } else {
code_r0x00018022afe3:
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022afeb;
        iVar3 = fcn.180255500(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                              *(int64_t *)(&stack0x00000068 + iVar4), *(int64_t *)(&stack0x00000070 + iVar4));
        iVar2 = *(int32_t *)(in_RCX + 8);
        uVar5 = (uint64_t)((int32_t)(iVar3 + 7 + (iVar3 + 7 >> 0x1f & 7U)) >> 3);
        uVar6 = uVar5 + 1;
        if (iVar2 != 1) {
            uVar6 = uVar5;
        }
        uVar5 = 1;
        if (uVar6 != 0) {
            uVar5 = uVar6;
        }
        iVar1 = *(int64_t *)(in_RCX + 0x10);
        if (iVar1 == 0) {
            *(uint64_t *)(in_RCX + 0x20) = uVar5;
            return 1;
        }
        uVar6 = *(uint64_t *)(in_RCX + 0x18);
        if (uVar6 < uVar5) {
            *(uint64_t *)(in_RCX + 0x20) = uVar5;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022b0b5;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022b0cd;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            goto code_r0x00018022b0d2;
        }
        if (iVar2 == 1) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022b08f;
            iVar2 = fcn.1802558d0(in_RDX, iVar1, uVar6 & 0xffffffff);
            if (-1 < iVar2) {
code_r0x00018022b09f:
                *(uint64_t *)(in_RCX + 0x20) = *(uint64_t *)(in_RCX + 0x18);
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022b098;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        } else {
            if (iVar2 != 2) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022b047;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4));
                goto code_r0x00018022afc2;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022b05c;
            iVar2 = fcn.180254da0(in_RDX, iVar1, uVar6 & 0xffffffff);
            if (-1 < iVar2) goto code_r0x00018022b09f;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022b065;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022b07d;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
    }
code_r0x00018022b0d2:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022b0df;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_18022af9d
// Address: 0x18022af9d
// Size: 345 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18022aef0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    uint64_t uVar5;
    int64_t in_RDX;
    uint64_t uVar6;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022af00;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022af13;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022af2b;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022af3d;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RSI;
    *(undefined8 *)(in_RCX + 0x20) = 0;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022af61;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022af79;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022af8b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    iVar2 = *(int32_t *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_R14;
    if (iVar2 == 2) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022afb4;
        iVar2 = fcn.180255370(in_RDX);
        if (iVar2 == 0) goto code_r0x00018022afe3;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022afbd;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
code_r0x00018022afc2:
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022afd5;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
    } else {
code_r0x00018022afe3:
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022afeb;
        iVar3 = fcn.180255500(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                              *(int64_t *)(&stack0x00000068 + iVar4), *(int64_t *)(&stack0x00000070 + iVar4));
        iVar2 = *(int32_t *)(in_RCX + 8);
        uVar5 = (uint64_t)((int32_t)(iVar3 + 7 + (iVar3 + 7 >> 0x1f & 7U)) >> 3);
        uVar6 = uVar5 + 1;
        if (iVar2 != 1) {
            uVar6 = uVar5;
        }
        uVar5 = 1;
        if (uVar6 != 0) {
            uVar5 = uVar6;
        }
        iVar1 = *(int64_t *)(in_RCX + 0x10);
        if (iVar1 == 0) {
            *(uint64_t *)(in_RCX + 0x20) = uVar5;
            return 1;
        }
        uVar6 = *(uint64_t *)(in_RCX + 0x18);
        if (uVar6 < uVar5) {
            *(uint64_t *)(in_RCX + 0x20) = uVar5;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022b0b5;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022b0cd;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            goto code_r0x00018022b0d2;
        }
        if (iVar2 == 1) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022b08f;
            iVar2 = fcn.1802558d0(in_RDX, iVar1, uVar6 & 0xffffffff);
            if (-1 < iVar2) {
code_r0x00018022b09f:
                *(uint64_t *)(in_RCX + 0x20) = *(uint64_t *)(in_RCX + 0x18);
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022b098;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        } else {
            if (iVar2 != 2) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022b047;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4));
                goto code_r0x00018022afc2;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022b05c;
            iVar2 = fcn.180254da0(in_RDX, iVar1, uVar6 & 0xffffffff);
            if (-1 < iVar2) goto code_r0x00018022b09f;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022b065;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022b07d;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
    }
code_r0x00018022b0d2:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022b0df;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_18022b100
// Address: 0x18022b100
// Size: 22 bytes
// ============================================================
undefined8 fcn.18022b100(int64_t arg_38h, int64_t arg_60h)
{
    int32_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(int32_t *)((int64_t)&arg_38h + iVar3) = in_EDX;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x18022b12e;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18022b13b;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18022b153;
        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18022b165;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar4 + iVar3));
        return 0;
    }
    iVar1 = *(int32_t *)(in_RCX + 8);
    *(undefined8 *)(in_RCX + 0x20) = 0;
    if (iVar1 == 1) {
code_r0x00018022b17c:
        piVar2 = *(int64_t **)(in_RCX + 0x10);
        *(undefined8 *)(in_RCX + 0x20) = 4;
        if (piVar2 != (int64_t *)0x0) {
            if (*(int64_t *)(in_RCX + 0x18) != 4) {
                if (*(int64_t *)(in_RCX + 0x18) == 8) {
                    *(undefined8 *)(in_RCX + 0x20) = 8;
                    *piVar2 = (int64_t)in_EDX;
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18022b1ad;
                uVar5 = fcn.18022bfd0(*(int64_t *)(&stack0x00000058 + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
                return uVar5;
            }
            *(int32_t *)piVar2 = in_EDX;
        }
        return 1;
    }
    if (iVar1 == 2) {
        if (-1 < in_EDX) goto code_r0x00018022b17c;
    } else if (iVar1 == 3) {
        *(undefined8 *)(in_RCX + 0x20) = 8;
        if (*(double **)(in_RCX + 0x10) == (double *)0x0) {
            return 1;
        }
        if (*(int64_t *)(in_RCX + 0x18) == 8) {
            **(double **)(in_RCX + 0x10) = (double)in_EDX;
            return 1;
        }
        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18022b238;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18022b250;
        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18022b262;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar4 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18022b1e5;
    fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18022b1fd;
    fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                  *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), 
                  *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18022b20f;
    fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar4 + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_18022b120
// Address: 0x18022b120
// Size: 351 bytes
// ============================================================
undefined8 fcn.18022b100(int64_t arg_38h, int64_t arg_60h)
{
    int32_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(int32_t *)((int64_t)&arg_38h + iVar3) = in_EDX;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x18022b12e;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18022b13b;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18022b153;
        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18022b165;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar4 + iVar3));
        return 0;
    }
    iVar1 = *(int32_t *)(in_RCX + 8);
    *(undefined8 *)(in_RCX + 0x20) = 0;
    if (iVar1 == 1) {
code_r0x00018022b17c:
        piVar2 = *(int64_t **)(in_RCX + 0x10);
        *(undefined8 *)(in_RCX + 0x20) = 4;
        if (piVar2 != (int64_t *)0x0) {
            if (*(int64_t *)(in_RCX + 0x18) != 4) {
                if (*(int64_t *)(in_RCX + 0x18) == 8) {
                    *(undefined8 *)(in_RCX + 0x20) = 8;
                    *piVar2 = (int64_t)in_EDX;
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18022b1ad;
                uVar5 = fcn.18022bfd0(*(int64_t *)(&stack0x00000058 + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
                return uVar5;
            }
            *(int32_t *)piVar2 = in_EDX;
        }
        return 1;
    }
    if (iVar1 == 2) {
        if (-1 < in_EDX) goto code_r0x00018022b17c;
    } else if (iVar1 == 3) {
        *(undefined8 *)(in_RCX + 0x20) = 8;
        if (*(double **)(in_RCX + 0x10) == (double *)0x0) {
            return 1;
        }
        if (*(int64_t *)(in_RCX + 0x18) == 8) {
            **(double **)(in_RCX + 0x10) = (double)in_EDX;
            return 1;
        }
        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18022b238;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18022b250;
        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18022b262;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar4 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18022b1e5;
    fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18022b1fd;
    fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                  *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), 
                  *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18022b20f;
    fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar4 + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_18022b280
// Address: 0x18022b280
// Size: 633 bytes
// ============================================================
undefined8 fcn.18022b280(int64_t placeholder_0, int64_t arg2, int64_t arg_38h)
{
    int32_t iVar1;
    uint64_t *puVar2;
    int64_t iVar3;
    undefined8 uVar4;
    uint64_t uVar5;
    int64_t var_10h;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022b28f;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (placeholder_0 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022b29c;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022b2b4;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022b2c6;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
        return 0;
    }
    iVar1 = *(int32_t *)(placeholder_0 + 8);
    *(undefined8 *)(placeholder_0 + 0x20) = 0;
    if (iVar1 == 1) {
        puVar2 = *(uint64_t **)(placeholder_0 + 0x10);
        if (puVar2 != (uint64_t *)0x0) {
            if (*(int64_t *)(placeholder_0 + 0x18) == 4) {
                if (arg2 + 0x80000000U < 0x100000000) {
                    *(undefined8 *)(placeholder_0 + 0x20) = 4;
                    *(int32_t *)puVar2 = (int32_t)arg2;
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022b363;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
code_r0x00018022b368:
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022b37b;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                              *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3));
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022b38d;
                fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
                return 0;
            }
            if (*(int64_t *)(placeholder_0 + 0x18) == 8) {
                *(undefined8 *)(placeholder_0 + 0x20) = 8;
                *puVar2 = arg2;
                return 1;
            }
code_r0x00018022b30c:
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022b31c;
            uVar4 = fcn.18022bfd0(*(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3));
            return uVar4;
        }
    } else if (iVar1 == 2) {
        if (arg2 < 0) {
code_r0x00018022b4c3:
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022b4c8;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022b4e0;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                          *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022b4f2;
            fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
            return 0;
        }
        puVar2 = *(uint64_t **)(placeholder_0 + 0x10);
        if (puVar2 != (uint64_t *)0x0) {
            if (*(int64_t *)(placeholder_0 + 0x18) == 4) {
                if (arg2 < 0x100000000) {
                    *(undefined8 *)(placeholder_0 + 0x20) = 4;
                    *(int32_t *)puVar2 = (int32_t)arg2;
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022b3f8;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
                goto code_r0x00018022b368;
            }
            if (*(int64_t *)(placeholder_0 + 0x18) == 8) {
                *(undefined8 *)(placeholder_0 + 0x20) = 8;
                *puVar2 = arg2;
                return 1;
            }
            goto code_r0x00018022b30c;
        }
    } else {
        if (iVar1 != 3) goto code_r0x00018022b4c3;
        if (*(double **)(placeholder_0 + 0x10) != (double *)0x0) {
            if (*(int64_t *)(placeholder_0 + 0x18) != 8) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022b424;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022b43c;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                              *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3));
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022b44e;
                fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
                return 0;
            }
            uVar5 = -arg2;
            if (0 < arg2) {
                uVar5 = arg2;
            }
            if (uVar5 < 0x20000000000000) {
                *(undefined8 *)(placeholder_0 + 0x20) = 8;
                **(double **)(placeholder_0 + 0x10) = (double)arg2;
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022b492;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022b4aa;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                          *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022b4bc;
            fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
            return 0;
        }
    }
    *(undefined8 *)(placeholder_0 + 0x20) = 8;
    return 1;
}

// ============================================================
// Function: FUN_18022b500
// Address: 0x18022b500
// Size: 72 bytes
// ============================================================
undefined8 fcn.18022b500(int64_t param_1, undefined8 param_2, undefined8 param_3)
{
    int64_t iVar1;
    undefined8 unaff_RBX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022b50a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_1 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b517;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b52f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b541;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar1) = unaff_RBX;
    *(undefined8 *)(param_1 + 0x20) = 0;
    if (*(int32_t *)(param_1 + 8) != 7) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b55e;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b576;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b588;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    *(undefined8 *)(param_1 + 0x20) = param_3;
    if (*(undefined8 **)(param_1 + 0x10) != (undefined8 *)0x0) {
        **(undefined8 **)(param_1 + 0x10) = param_2;
    }
    return 1;
}

// ============================================================
// Function: FUN_18022b548
// Address: 0x18022b548
// Size: 76 bytes
// ============================================================
undefined8 fcn.18022b500(int64_t param_1, undefined8 param_2, undefined8 param_3)
{
    int64_t iVar1;
    undefined8 unaff_RBX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022b50a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_1 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b517;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b52f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b541;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar1) = unaff_RBX;
    *(undefined8 *)(param_1 + 0x20) = 0;
    if (*(int32_t *)(param_1 + 8) != 7) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b55e;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b576;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b588;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    *(undefined8 *)(param_1 + 0x20) = param_3;
    if (*(undefined8 **)(param_1 + 0x10) != (undefined8 *)0x0) {
        **(undefined8 **)(param_1 + 0x10) = param_2;
    }
    return 1;
}

// ============================================================
// Function: FUN_18022b594
// Address: 0x18022b594
// Size: 33 bytes
// ============================================================
undefined8 fcn.18022b500(int64_t param_1, undefined8 param_2, undefined8 param_3)
{
    int64_t iVar1;
    undefined8 unaff_RBX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022b50a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_1 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b517;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b52f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b541;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar1) = unaff_RBX;
    *(undefined8 *)(param_1 + 0x20) = 0;
    if (*(int32_t *)(param_1 + 8) != 7) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b55e;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b576;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b588;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    *(undefined8 *)(param_1 + 0x20) = param_3;
    if (*(undefined8 **)(param_1 + 0x10) != (undefined8 *)0x0) {
        **(undefined8 **)(param_1 + 0x10) = param_2;
    }
    return 1;
}

// ============================================================
// Function: FUN_18022b5c0
// Address: 0x18022b5c0
// Size: 100 bytes
// ============================================================
undefined8 fcn.18022b5c0(int64_t arg_30h, int64_t arg_38h, int64_t arg_50h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    int32_t iVar3;
    int64_t aiStackX_18 [2];
    undefined8 uStack_8;
    
    uStack_8 = 0x18022b5ca;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if ((in_RCX != 0) && (in_RDX != 0)) {
        iVar3 = 5;
        *(undefined8 *)(in_RCX + 0x20) = 0;
        *(undefined8 *)((int64_t)&arg_30h + iVar1) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_38h + iVar1) = unaff_RSI;
        *(undefined8 *)((int64_t)aiStackX_18 + iVar1 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)aiStackX_18 + iVar1) = 0x18022c605;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        if (*(int32_t *)(in_RCX + 8) != iVar3) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + iVar1) = 0x18022c61c;
            fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar2 + iVar1), *(int64_t *)(&stack0x00000048 + iVar2 + iVar1)
                         );
            *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + iVar1) = 0x18022c634;
            fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar2 + iVar1), *(int64_t *)(&stack0x00000048 + iVar2 + iVar1)
                          , *(int64_t *)((int64_t)&arg_50h + iVar2 + iVar1), 
                          *(int64_t *)((int64_t)&arg_58h + iVar2 + iVar1), 
                          *(int64_t *)(&stack0x00000070 + iVar2 + iVar1));
            *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + iVar1) = 0x18022c646;
            fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar2 + iVar1));
            return 0;
        }
        *(uint64_t *)(in_RCX + 0x20) = in_R8;
        if (*(int64_t *)(in_RCX + 0x10) != 0) {
            if (*(uint64_t *)(in_RCX + 0x18) < in_R8) {
                *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + iVar1) = 0x18022c670;
                fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar2 + iVar1), 
                              *(int64_t *)(&stack0x00000048 + iVar2 + iVar1));
                *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + iVar1) = 0x18022c688;
                fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar2 + iVar1), 
                              *(int64_t *)(&stack0x00000048 + iVar2 + iVar1), 
                              *(int64_t *)((int64_t)&arg_50h + iVar2 + iVar1), 
                              *(int64_t *)((int64_t)&arg_58h + iVar2 + iVar1), 
                              *(int64_t *)(&stack0x00000070 + iVar2 + iVar1));
                *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + iVar1) = 0x18022c69a;
                fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar2 + iVar1));
                return 0;
            }
            *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + iVar1) = 0x18022c6b1;
            fcn.180498030();
            if ((iVar3 == 4) && (in_R8 < *(uint64_t *)(in_RCX + 0x18))) {
                *(undefined *)(in_R8 + *(int64_t *)(in_RCX + 0x10)) = 0;
            }
        }
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b5f3;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), *(int64_t *)(&stack0x00000028 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b60b;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), *(int64_t *)(&stack0x00000028 + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)((int64_t)&arg_38h + iVar1), 
                  *(int64_t *)((int64_t)&arg_50h + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b61d;
    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
    return 0;
}

// ============================================================
// Function: FUN_18022b630
// Address: 0x18022b630
// Size: 245 bytes
// ============================================================
undefined8 fcn.18022b630(int64_t param_1, int64_t param_2, uint64_t param_3)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t iVar3;
    int64_t aiStackX_18 [2];
    undefined8 uStack_8;
    
    uStack_8 = 0x18022b63a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_1 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b647;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b65f;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b671;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    if (*(int32_t *)(param_1 + 8) != 5) {
        if (*(int32_t *)(param_1 + 8) == 7) {
            *(uint64_t *)(param_1 + 0x20) = param_3;
            if (*(int64_t **)(param_1 + 0x10) != (int64_t *)0x0) {
                **(int64_t **)(param_1 + 0x10) = param_2;
            }
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b6f4;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b70c;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b71e;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    if (param_2 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b69f;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b6b7;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022b6c9;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    iVar3 = 5;
    *(undefined8 *)(param_1 + 0x20) = 0;
    *(undefined8 *)(&stack0x00000030 + iVar1) = unaff_RBX;
    *(undefined8 *)(&stack0x00000038 + iVar1) = unaff_RSI;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar1 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar1) = 0x18022c605;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int32_t *)(param_1 + 8) != iVar3) {
        *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + iVar1) = 0x18022c61c;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar2 + iVar1), *(int64_t *)(&stack0x00000048 + iVar2 + iVar1));
        *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + iVar1) = 0x18022c634;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar2 + iVar1), *(int64_t *)(&stack0x00000048 + iVar2 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar2 + iVar1), *(int64_t *)(&stack0x00000058 + iVar2 + iVar1), 
                      *(int64_t *)(&stack0x00000070 + iVar2 + iVar1));
        *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + iVar1) = 0x18022c646;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar2 + iVar1));
        return 0;
    }
    *(uint64_t *)(param_1 + 0x20) = param_3;
    if (*(int64_t *)(param_1 + 0x10) != 0) {
        if (*(uint64_t *)(param_1 + 0x18) < param_3) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + iVar1) = 0x18022c670;
            fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar2 + iVar1), *(int64_t *)(&stack0x00000048 + iVar2 + iVar1)
                         );
            *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + iVar1) = 0x18022c688;
            fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar2 + iVar1), *(int64_t *)(&stack0x00000048 + iVar2 + iVar1)
                          , *(int64_t *)(&stack0x00000050 + iVar2 + iVar1), 
                          *(int64_t *)(&stack0x00000058 + iVar2 + iVar1), *(int64_t *)(&stack0x00000070 + iVar2 + iVar1)
                         );
            *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + iVar1) = 0x18022c69a;
            fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar2 + iVar1));
            return 0;
        }
        *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + iVar1) = 0x18022c6b1;
        fcn.180498030();
        if ((iVar3 == 4) && (param_3 < *(uint64_t *)(param_1 + 0x18))) {
            *(undefined *)(param_3 + *(int64_t *)(param_1 + 0x10)) = 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18022b730
// Address: 0x18022b730
// Size: 22 bytes
// ============================================================
undefined8 fcn.18022b730(int64_t arg_38h, int64_t arg_60h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    uint64_t *puVar5;
    int64_t in_RCX;
    uint64_t in_RDX;
    double dVar6;
    undefined8 uStackX_20;
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(uint64_t *)((int64_t)&arg_38h + iVar2) = in_RDX;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2) = 0x18022b95f;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b96c;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), *(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b984;
        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000078 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b996;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar3 + iVar2));
        return 0;
    }
    iVar1 = *(int32_t *)(in_RCX + 8);
    *(undefined8 *)(in_RCX + 0x20) = 0;
    if (iVar1 == 2) {
        puVar5 = *(uint64_t **)(in_RCX + 0x10);
        if (puVar5 != (uint64_t *)0x0) {
            if (*(int64_t *)(in_RCX + 0x18) == 4) {
                if (0xffffffff < in_RDX) {
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022ba2a;
                    fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
                    goto code_r0x00018022ba2f;
                }
code_r0x00018022ba11:
                *(undefined8 *)(in_RCX + 0x20) = 4;
                *(uint32_t *)puVar5 = (uint32_t)in_RDX;
                return 1;
            }
            if (*(int64_t *)(in_RCX + 0x18) == 8) {
code_r0x00018022b9f1:
                *(undefined8 *)(in_RCX + 0x20) = 8;
                *puVar5 = in_RDX;
                return 1;
            }
code_r0x00018022b9dc:
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b9ec;
            uVar4 = fcn.18022c0e0(*(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000068 + iVar3 + iVar2));
            return uVar4;
        }
    } else {
        if (iVar1 != 1) {
            if (iVar1 != 3) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022bb9a;
                fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022bbb2;
                fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000078 + iVar3 + iVar2));
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022bbc4;
                fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar3 + iVar2));
                return 0;
            }
            if (*(int64_t *)(in_RCX + 0x18) != 8) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022bad1;
                fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022bae9;
                fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000078 + iVar3 + iVar2));
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022bafb;
                fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar3 + iVar2));
                return 0;
            }
            if (0x1fffffffffffff < in_RDX) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022bb64;
                fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022bb7c;
                fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000078 + iVar3 + iVar2));
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022bb8e;
                fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar3 + iVar2));
                return 0;
            }
            *(undefined8 *)(in_RCX + 0x20) = 8;
            if (-1 < (int64_t)in_RDX) {
                **(double **)(in_RCX + 0x10) = (double)in_RDX;
                return 1;
            }
            dVar6 = (double)(in_RDX >> 1 | (uint64_t)((uint32_t)in_RDX & 1));
            **(double **)(in_RCX + 0x10) = dVar6 + dVar6;
            return 1;
        }
        puVar5 = *(uint64_t **)(in_RCX + 0x10);
        if (puVar5 != (uint64_t *)0x0) {
            if (*(int64_t *)(in_RCX + 0x18) == 4) {
                if (in_RDX < 0x80000000) goto code_r0x00018022ba11;
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022bab2;
                fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
            } else {
                if (*(int64_t *)(in_RCX + 0x18) != 8) goto code_r0x00018022b9dc;
                if (in_RDX < 0x8000000000000000) goto code_r0x00018022b9f1;
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022ba99;
                fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
            }
code_r0x00018022ba2f:
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022ba42;
            fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), *(int64_t *)(&stack0x00000050 + iVar3 + iVar2)
                          , *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                          *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                          *(int64_t *)(&stack0x00000078 + iVar3 + iVar2));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022ba54;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar3 + iVar2));
            return 0;
        }
    }
    *(undefined8 *)(in_RCX + 0x20) = 8;
    return 1;
}

// ============================================================
// Function: FUN_18022b750
// Address: 0x18022b750
// Size: 22 bytes
// ============================================================
undefined8 fcn.18022b750(int64_t param_1, uint64_t param_2)
{
    int32_t iVar1;
    uint64_t *puVar2;
    int64_t iVar3;
    undefined8 uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    undefined8 uStackX_20;
    
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)(&stack0x00000038 + iVar6) = param_2;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar6) = 0x18022b28f;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_1 == 0) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar6) = 0x18022b29c;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar6), *(int64_t *)(&stack0x00000050 + iVar3 + iVar6));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar6) = 0x18022b2b4;
        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar6), *(int64_t *)(&stack0x00000050 + iVar3 + iVar6), 
                      *(int64_t *)(&stack0x00000058 + iVar3 + iVar6), *(int64_t *)(&stack0x00000060 + iVar3 + iVar6), 
                      *(int64_t *)(&stack0x00000078 + iVar3 + iVar6));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar6) = 0x18022b2c6;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar3 + iVar6));
        return 0;
    }
    iVar1 = *(int32_t *)(param_1 + 8);
    *(undefined8 *)(param_1 + 0x20) = 0;
    if (iVar1 == 1) {
        puVar2 = *(uint64_t **)(param_1 + 0x10);
        if (puVar2 != (uint64_t *)0x0) {
            if (*(int64_t *)(param_1 + 0x18) == 4) {
                if (param_2 + 0x80000000 < 0x100000000) {
                    *(undefined8 *)(param_1 + 0x20) = 4;
                    *(int32_t *)puVar2 = (int32_t)param_2;
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar6) = 0x18022b363;
                fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar6), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar6));
code_r0x00018022b368:
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar6) = 0x18022b37b;
                fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar6), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar6), 
                              *(int64_t *)(&stack0x00000058 + iVar3 + iVar6), 
                              *(int64_t *)(&stack0x00000060 + iVar3 + iVar6), 
                              *(int64_t *)(&stack0x00000078 + iVar3 + iVar6));
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar6) = 0x18022b38d;
                fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar3 + iVar6));
                return 0;
            }
            if (*(int64_t *)(param_1 + 0x18) == 8) {
                *(undefined8 *)(param_1 + 0x20) = 8;
                *puVar2 = param_2;
                return 1;
            }
code_r0x00018022b30c:
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar6) = 0x18022b31c;
            uVar4 = fcn.18022bfd0(*(int64_t *)(&stack0x00000058 + iVar3 + iVar6), 
                                  *(int64_t *)(&stack0x00000060 + iVar3 + iVar6));
            return uVar4;
        }
    } else if (iVar1 == 2) {
        if ((int64_t)param_2 < 0) {
code_r0x00018022b4c3:
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar6) = 0x18022b4c8;
            fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar6), *(int64_t *)(&stack0x00000050 + iVar3 + iVar6)
                         );
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar6) = 0x18022b4e0;
            fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar6), *(int64_t *)(&stack0x00000050 + iVar3 + iVar6)
                          , *(int64_t *)(&stack0x00000058 + iVar3 + iVar6), 
                          *(int64_t *)(&stack0x00000060 + iVar3 + iVar6), *(int64_t *)(&stack0x00000078 + iVar3 + iVar6)
                         );
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar6) = 0x18022b4f2;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar3 + iVar6));
            return 0;
        }
        puVar2 = *(uint64_t **)(param_1 + 0x10);
        if (puVar2 != (uint64_t *)0x0) {
            if (*(int64_t *)(param_1 + 0x18) == 4) {
                if ((int64_t)param_2 < 0x100000000) {
                    *(undefined8 *)(param_1 + 0x20) = 4;
                    *(int32_t *)puVar2 = (int32_t)param_2;
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar6) = 0x18022b3f8;
                fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar6), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar6));
                goto code_r0x00018022b368;
            }
            if (*(int64_t *)(param_1 + 0x18) == 8) {
                *(undefined8 *)(param_1 + 0x20) = 8;
                *puVar2 = param_2;
                return 1;
            }
            goto code_r0x00018022b30c;
        }
    } else {
        if (iVar1 != 3) goto code_r0x00018022b4c3;
        if (*(double **)(param_1 + 0x10) != (double *)0x0) {
            if (*(int64_t *)(param_1 + 0x18) != 8) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar6) = 0x18022b424;
                fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar6), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar6));
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar6) = 0x18022b43c;
                fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar6), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar6), 
                              *(int64_t *)(&stack0x00000058 + iVar3 + iVar6), 
                              *(int64_t *)(&stack0x00000060 + iVar3 + iVar6), 
                              *(int64_t *)(&stack0x00000078 + iVar3 + iVar6));
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar6) = 0x18022b44e;
                fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar3 + iVar6));
                return 0;
            }
            uVar5 = -param_2;
            if (0 < (int64_t)param_2) {
                uVar5 = param_2;
            }
            if (uVar5 < 0x20000000000000) {
                *(undefined8 *)(param_1 + 0x20) = 8;
                **(double **)(param_1 + 0x10) = (double)param_2;
                return 1;
            }
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar6) = 0x18022b492;
            fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar6), *(int64_t *)(&stack0x00000050 + iVar3 + iVar6)
                         );
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar6) = 0x18022b4aa;
            fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar6), *(int64_t *)(&stack0x00000050 + iVar3 + iVar6)
                          , *(int64_t *)(&stack0x00000058 + iVar3 + iVar6), 
                          *(int64_t *)(&stack0x00000060 + iVar3 + iVar6), *(int64_t *)(&stack0x00000078 + iVar3 + iVar6)
                         );
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar6) = 0x18022b4bc;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar3 + iVar6));
            return 0;
        }
    }
    *(undefined8 *)(param_1 + 0x20) = 8;
    return 1;
}

// ============================================================
// Function: FUN_18022b770
// Address: 0x18022b770
// Size: 22 bytes
// ============================================================
undefined8 fcn.18022b770(int64_t arg_38h, int64_t arg_60h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    uint64_t in_RDX;
    uint64_t *puVar6;
    undefined8 uStackX_20;
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(int32_t *)((int64_t)&arg_38h + iVar2) = (int32_t)in_RDX;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2) = 0x18022b79e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b7ab;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), *(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b7c3;
        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000078 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b7d5;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar3 + iVar2));
        return 0;
    }
    iVar1 = *(int32_t *)(in_RCX + 8);
    *(undefined8 *)(in_RCX + 0x20) = 0;
    if (iVar1 == 2) {
        puVar6 = *(uint64_t **)(in_RCX + 0x10);
        *(undefined8 *)(in_RCX + 0x20) = 4;
        if (puVar6 == (uint64_t *)0x0) {
            return 1;
        }
        iVar4 = *(int64_t *)(in_RCX + 0x18);
        if (iVar4 != 4) {
code_r0x00018022b807:
            if (iVar4 == 8) {
                *(undefined8 *)(in_RCX + 0x20) = 8;
                *puVar6 = in_RDX & 0xffffffff;
                return 1;
            }
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b81d;
            uVar5 = fcn.18022c0e0(*(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000068 + iVar3 + iVar2));
            return uVar5;
        }
    } else {
        if (iVar1 != 1) {
            if (iVar1 != 3) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b915;
                fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b92d;
                fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000078 + iVar3 + iVar2));
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b93f;
                fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar3 + iVar2));
                return 0;
            }
            if (*(double **)(in_RCX + 0x10) != (double *)0x0) {
                if (*(int64_t *)(in_RCX + 0x18) != 8) {
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b8be;
                    fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b8d6;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000078 + iVar3 + iVar2));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b8e8;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar3 + iVar2));
                    return 0;
                }
                **(double **)(in_RCX + 0x10) = (double)(in_RDX & 0xffffffff);
            }
            *(undefined8 *)(in_RCX + 0x20) = 8;
            return 1;
        }
        puVar6 = *(uint64_t **)(in_RCX + 0x10);
        *(undefined8 *)(in_RCX + 0x20) = 4;
        if (puVar6 == (uint64_t *)0x0) {
            return 1;
        }
        iVar4 = *(int64_t *)(in_RCX + 0x18);
        if (iVar4 != 4) goto code_r0x00018022b807;
        if (0x7fffffff < (uint32_t)in_RDX) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b873;
            fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), *(int64_t *)(&stack0x00000050 + iVar3 + iVar2)
                         );
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b88b;
            fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), *(int64_t *)(&stack0x00000050 + iVar3 + iVar2)
                          , *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                          *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                          *(int64_t *)(&stack0x00000078 + iVar3 + iVar2));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b89d;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar3 + iVar2));
            return 0;
        }
    }
    *(uint32_t *)puVar6 = (uint32_t)in_RDX;
    return 1;
}

// ============================================================
// Function: FUN_18022b790
// Address: 0x18022b790
// Size: 438 bytes
// ============================================================
undefined8 fcn.18022b770(int64_t arg_38h, int64_t arg_60h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    uint64_t in_RDX;
    uint64_t *puVar6;
    undefined8 uStackX_20;
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(int32_t *)((int64_t)&arg_38h + iVar2) = (int32_t)in_RDX;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2) = 0x18022b79e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b7ab;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), *(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b7c3;
        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000078 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b7d5;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar3 + iVar2));
        return 0;
    }
    iVar1 = *(int32_t *)(in_RCX + 8);
    *(undefined8 *)(in_RCX + 0x20) = 0;
    if (iVar1 == 2) {
        puVar6 = *(uint64_t **)(in_RCX + 0x10);
        *(undefined8 *)(in_RCX + 0x20) = 4;
        if (puVar6 == (uint64_t *)0x0) {
            return 1;
        }
        iVar4 = *(int64_t *)(in_RCX + 0x18);
        if (iVar4 != 4) {
code_r0x00018022b807:
            if (iVar4 == 8) {
                *(undefined8 *)(in_RCX + 0x20) = 8;
                *puVar6 = in_RDX & 0xffffffff;
                return 1;
            }
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b81d;
            uVar5 = fcn.18022c0e0(*(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000068 + iVar3 + iVar2));
            return uVar5;
        }
    } else {
        if (iVar1 != 1) {
            if (iVar1 != 3) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b915;
                fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b92d;
                fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000078 + iVar3 + iVar2));
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b93f;
                fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar3 + iVar2));
                return 0;
            }
            if (*(double **)(in_RCX + 0x10) != (double *)0x0) {
                if (*(int64_t *)(in_RCX + 0x18) != 8) {
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b8be;
                    fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b8d6;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000078 + iVar3 + iVar2));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b8e8;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar3 + iVar2));
                    return 0;
                }
                **(double **)(in_RCX + 0x10) = (double)(in_RDX & 0xffffffff);
            }
            *(undefined8 *)(in_RCX + 0x20) = 8;
            return 1;
        }
        puVar6 = *(uint64_t **)(in_RCX + 0x10);
        *(undefined8 *)(in_RCX + 0x20) = 4;
        if (puVar6 == (uint64_t *)0x0) {
            return 1;
        }
        iVar4 = *(int64_t *)(in_RCX + 0x18);
        if (iVar4 != 4) goto code_r0x00018022b807;
        if (0x7fffffff < (uint32_t)in_RDX) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b873;
            fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), *(int64_t *)(&stack0x00000050 + iVar3 + iVar2)
                         );
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b88b;
            fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), *(int64_t *)(&stack0x00000050 + iVar3 + iVar2)
                          , *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                          *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                          *(int64_t *)(&stack0x00000078 + iVar3 + iVar2));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b89d;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar3 + iVar2));
            return 0;
        }
    }
    *(uint32_t *)puVar6 = (uint32_t)in_RDX;
    return 1;
}

// ============================================================
// Function: FUN_18022b950
// Address: 0x18022b950
// Size: 635 bytes
// ============================================================
undefined8 fcn.18022b730(int64_t arg_38h, int64_t arg_60h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    uint64_t *puVar5;
    int64_t in_RCX;
    uint64_t in_RDX;
    double dVar6;
    undefined8 uStackX_20;
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(uint64_t *)((int64_t)&arg_38h + iVar2) = in_RDX;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2) = 0x18022b95f;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b96c;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), *(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b984;
        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000078 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b996;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar3 + iVar2));
        return 0;
    }
    iVar1 = *(int32_t *)(in_RCX + 8);
    *(undefined8 *)(in_RCX + 0x20) = 0;
    if (iVar1 == 2) {
        puVar5 = *(uint64_t **)(in_RCX + 0x10);
        if (puVar5 != (uint64_t *)0x0) {
            if (*(int64_t *)(in_RCX + 0x18) == 4) {
                if (0xffffffff < in_RDX) {
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022ba2a;
                    fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
                    goto code_r0x00018022ba2f;
                }
code_r0x00018022ba11:
                *(undefined8 *)(in_RCX + 0x20) = 4;
                *(uint32_t *)puVar5 = (uint32_t)in_RDX;
                return 1;
            }
            if (*(int64_t *)(in_RCX + 0x18) == 8) {
code_r0x00018022b9f1:
                *(undefined8 *)(in_RCX + 0x20) = 8;
                *puVar5 = in_RDX;
                return 1;
            }
code_r0x00018022b9dc:
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022b9ec;
            uVar4 = fcn.18022c0e0(*(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000068 + iVar3 + iVar2));
            return uVar4;
        }
    } else {
        if (iVar1 != 1) {
            if (iVar1 != 3) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022bb9a;
                fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022bbb2;
                fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000078 + iVar3 + iVar2));
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022bbc4;
                fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar3 + iVar2));
                return 0;
            }
            if (*(int64_t *)(in_RCX + 0x18) != 8) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022bad1;
                fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022bae9;
                fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000078 + iVar3 + iVar2));
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022bafb;
                fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar3 + iVar2));
                return 0;
            }
            if (0x1fffffffffffff < in_RDX) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022bb64;
                fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022bb7c;
                fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000078 + iVar3 + iVar2));
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022bb8e;
                fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar3 + iVar2));
                return 0;
            }
            *(undefined8 *)(in_RCX + 0x20) = 8;
            if (-1 < (int64_t)in_RDX) {
                **(double **)(in_RCX + 0x10) = (double)in_RDX;
                return 1;
            }
            dVar6 = (double)(in_RDX >> 1 | (uint64_t)((uint32_t)in_RDX & 1));
            **(double **)(in_RCX + 0x10) = dVar6 + dVar6;
            return 1;
        }
        puVar5 = *(uint64_t **)(in_RCX + 0x10);
        if (puVar5 != (uint64_t *)0x0) {
            if (*(int64_t *)(in_RCX + 0x18) == 4) {
                if (in_RDX < 0x80000000) goto code_r0x00018022ba11;
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022bab2;
                fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
            } else {
                if (*(int64_t *)(in_RCX + 0x18) != 8) goto code_r0x00018022b9dc;
                if (in_RDX < 0x8000000000000000) goto code_r0x00018022b9f1;
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022ba99;
                fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
            }
code_r0x00018022ba2f:
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022ba42;
            fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), *(int64_t *)(&stack0x00000050 + iVar3 + iVar2)
                          , *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                          *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2), 
                          *(int64_t *)(&stack0x00000078 + iVar3 + iVar2));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022ba54;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar3 + iVar2));
            return 0;
        }
    }
    *(undefined8 *)(in_RCX + 0x20) = 8;
    return 1;
}

// ============================================================
// Function: FUN_18022bbd0
// Address: 0x18022bbd0
// Size: 90 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18022bbd0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022bbe0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bbf3;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bc0b;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bc1d;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RDI;
    uVar2 = 0;
    *(undefined8 *)(in_RCX + 0x20) = 0;
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bc46;
        uVar2 = fcn.180498cd0(in_RDX);
    }
    if (*(int32_t *)(in_RCX + 8) == 6) {
        *(undefined8 *)(in_RCX + 0x20) = uVar2;
        if (*(int64_t **)(in_RCX + 0x10) != (int64_t *)0x0) {
            **(int64_t **)(in_RCX + 0x10) = in_RDX;
        }
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bc51;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bc69;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bc7b;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
    return 0;
}

// ============================================================
// Function: FUN_18022bc2a
// Address: 0x18022bc2a
// Size: 99 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18022bbd0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022bbe0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bbf3;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bc0b;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bc1d;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RDI;
    uVar2 = 0;
    *(undefined8 *)(in_RCX + 0x20) = 0;
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bc46;
        uVar2 = fcn.180498cd0(in_RDX);
    }
    if (*(int32_t *)(in_RCX + 8) == 6) {
        *(undefined8 *)(in_RCX + 0x20) = uVar2;
        if (*(int64_t **)(in_RCX + 0x10) != (int64_t *)0x0) {
            **(int64_t **)(in_RCX + 0x10) = in_RDX;
        }
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bc51;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bc69;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bc7b;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
    return 0;
}

// ============================================================
// Function: FUN_18022bc8d
// Address: 0x18022bc8d
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18022bbd0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022bbe0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bbf3;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bc0b;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bc1d;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RDI;
    uVar2 = 0;
    *(undefined8 *)(in_RCX + 0x20) = 0;
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bc46;
        uVar2 = fcn.180498cd0(in_RDX);
    }
    if (*(int32_t *)(in_RCX + 8) == 6) {
        *(undefined8 *)(in_RCX + 0x20) = uVar2;
        if (*(int64_t **)(in_RCX + 0x10) != (int64_t *)0x0) {
            **(int64_t **)(in_RCX + 0x10) = in_RDX;
        }
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bc51;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bc69;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bc7b;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
    return 0;
}

// ============================================================
// Function: FUN_18022bcc0
// Address: 0x18022bcc0
// Size: 141 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18022bcc0(int64_t arg_28h)
{
    int64_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022bcd0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if ((in_RCX != 0) && (in_RDX != 0)) {
        *(undefined8 *)(in_RCX + 0x20) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bcf3;
        uVar2 = fcn.180498cd0(in_RDX);
        iVar5 = 4;
        uVar4 = *(undefined8 *)((int64_t)aiStackX_10 + iVar1 + 8);
        *(undefined8 *)((int64_t)&arg_28h + iVar1) = *(undefined8 *)((int64_t)&arg_28h + iVar1);
        *(undefined8 *)(&stack0x00000030 + iVar1) = unaff_RSI;
        *(undefined8 *)((int64_t)aiStackX_10 + iVar1 + 8) = uVar4;
        *(undefined8 *)((int64_t)aiStackX_10 + iVar1) = 0x18022c605;
        iVar3 = fcn.18045a350(in_RCX, in_RDX);
        iVar3 = -iVar3;
        if (*(int32_t *)(in_RCX + 8) != iVar5) {
            *(undefined8 *)((int64_t)aiStackX_10 + iVar3 + iVar1) = 0x18022c61c;
            fcn.180229480(*(int64_t *)(&stack0x00000038 + iVar3 + iVar1), *(int64_t *)(&stack0x00000040 + iVar3 + iVar1)
                         );
            *(undefined8 *)((int64_t)aiStackX_10 + iVar3 + iVar1) = 0x18022c634;
            fcn.1802295a0(*(int64_t *)(&stack0x00000038 + iVar3 + iVar1), *(int64_t *)(&stack0x00000040 + iVar3 + iVar1)
                          , *(int64_t *)(&stack0x00000048 + iVar3 + iVar1), 
                          *(int64_t *)(&stack0x00000050 + iVar3 + iVar1), *(int64_t *)(&stack0x00000068 + iVar3 + iVar1)
                         );
            *(undefined8 *)((int64_t)aiStackX_10 + iVar3 + iVar1) = 0x18022c646;
            fcn.1802296d0(*(int64_t *)(&stack0x00000058 + iVar3 + iVar1));
            return 0;
        }
        *(uint64_t *)(in_RCX + 0x20) = uVar2;
        if (*(int64_t *)(in_RCX + 0x10) != 0) {
            if (*(uint64_t *)(in_RCX + 0x18) < uVar2) {
                *(undefined8 *)((int64_t)aiStackX_10 + iVar3 + iVar1) = 0x18022c670;
                fcn.180229480(*(int64_t *)(&stack0x00000038 + iVar3 + iVar1), 
                              *(int64_t *)(&stack0x00000040 + iVar3 + iVar1));
                *(undefined8 *)((int64_t)aiStackX_10 + iVar3 + iVar1) = 0x18022c688;
                fcn.1802295a0(*(int64_t *)(&stack0x00000038 + iVar3 + iVar1), 
                              *(int64_t *)(&stack0x00000040 + iVar3 + iVar1), 
                              *(int64_t *)(&stack0x00000048 + iVar3 + iVar1), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar1), 
                              *(int64_t *)(&stack0x00000068 + iVar3 + iVar1));
                *(undefined8 *)((int64_t)aiStackX_10 + iVar3 + iVar1) = 0x18022c69a;
                fcn.1802296d0(*(int64_t *)(&stack0x00000058 + iVar3 + iVar1));
                return 0;
            }
            *(undefined8 *)((int64_t)aiStackX_10 + iVar3 + iVar1) = 0x18022c6b1;
            fcn.180498030();
            if ((iVar5 == 4) && (uVar2 < *(uint64_t *)(in_RCX + 0x18))) {
                *(undefined *)(uVar2 + *(int64_t *)(in_RCX + 0x10)) = 0;
            }
        }
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bd16;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar1 + 8), *(int64_t *)((int64_t)aiStackX_10 + iVar1 + 0x10));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bd2e;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar1 + 8), *(int64_t *)((int64_t)aiStackX_10 + iVar1 + 0x10), 
                  *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bd40;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
    return 0;
}

// ============================================================
// Function: FUN_18022bd50
// Address: 0x18022bd50
// Size: 202 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18022bd50(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    uint64_t uVar2;
    int64_t in_RCX;
    uint64_t in_RDX;
    int64_t in_R8;
    uint64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022bd65;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (in_R9 < in_RDX) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bd89;
        fcn.1804986e0(in_RCX + in_R9, *(undefined *)((int64_t)&arg_48h + iVar1), in_RDX - in_R9);
        in_RDX = in_R9;
    } else {
        uVar2 = 0;
        if (in_R9 != in_RDX) {
            do {
                if (*(uint8_t *)(in_R8 + in_RDX + uVar2) != *(uint8_t *)((int64_t)&arg_48h + iVar1))
                goto code_r0x00018022bdd9;
                uVar2 = uVar2 + 1;
            } while (uVar2 < in_R9 - in_RDX);
        }
        if ((*(int32_t *)((int64_t)&arg_50h + iVar1) != 0) &&
           ((char)(*(uint8_t *)((int64_t)&arg_48h + iVar1) ^ *(uint8_t *)(in_R8 + in_RDX + -1)) < '\0')) {
code_r0x00018022bdd9:
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bdde;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bdf6;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                          *(int64_t *)((int64_t)&arg_48h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022be08;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022bd97;
    fcn.180498030(in_RCX, in_R8, in_RDX);
    return 1;
}

// ============================================================
// Function: FUN_18022be20
// Address: 0x18022be20
// Size: 223 bytes
// ============================================================
undefined8 fcn.18022a1f0(int64_t arg_48h, int64_t arg_50h)
{
    double dVar1;
    int32_t iVar2;
    double *pdVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    double dVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t in_RCX;
    double *in_RDX;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022a1fa;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if ((in_RDX == (double *)0x0) || (in_RCX == 0)) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x18022a3d7;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6));
    } else {
        pdVar3 = *(double **)(in_RCX + 0x10);
        if (pdVar3 != (double *)0x0) {
            iVar2 = *(int32_t *)(in_RCX + 8);
            if (iVar2 == 1) {
                if (*(int64_t *)(in_RCX + 0x18) == 4) {
                    dVar7 = (double)(int64_t)*(int32_t *)pdVar3;
code_r0x00018022a263:
                    *in_RDX = dVar7;
                    return 1;
                }
                if (*(int64_t *)(in_RCX + 0x18) == 8) {
                    *in_RDX = *pdVar3;
                    return 1;
                }
            } else {
                if (iVar2 != 2) {
                    if (iVar2 != 3) {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x18022a3a1;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6)
                                     );
                        *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x18022a3b9;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6)
                                      , *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar6));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x18022a3cb;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar6));
                        return 0;
                    }
                    if (*(int64_t *)(in_RCX + 0x18) != 8) {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x18022a300;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6)
                                     );
                        *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x18022a318;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6)
                                      , *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar6));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x18022a32a;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar6));
                        return 0;
                    }
                    dVar1 = *pdVar3;
                    if (((dVar1 < -9.223372036854776e+18) || (9.223372036854776e+18 <= dVar1)) ||
                       (dVar7 = (double)(int64_t)dVar1, dVar1 != (double)(int64_t)dVar7)) {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x18022a36b;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6)
                                     );
                        *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x18022a383;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6)
                                      , *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar6));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x18022a395;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar6));
                        return 0;
                    }
                    goto code_r0x00018022a263;
                }
                if (*(int64_t *)(in_RCX + 0x18) == 4) {
                    *in_RDX = (double)(uint64_t)*(uint32_t *)pdVar3;
                    return 1;
                }
                if (*(int64_t *)(in_RCX + 0x18) == 8) {
                    if (0x7fffffffffffffff < (uint64_t)*pdVar3) {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x18022a2aa;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6)
                                     );
                        *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x18022a2c2;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6)
                                      , *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar6));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x18022a2d4;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar6));
                        return 0;
                    }
                    *in_RDX = *pdVar3;
                    return 1;
                }
            }
            *(undefined8 *)((int64_t)&iStackX_20 + iVar6) = 0x18022be2a;
            iVar8 = fcn.18045a350();
            iVar8 = -iVar8;
            iVar4 = *(int64_t *)(in_RCX + 0x10);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&iStackX_20 + iVar8 + iVar6) = 0x18022be41;
                fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar8 + iVar6), 
                              *(int64_t *)((int64_t)&arg_50h + iVar8 + iVar6));
                *(undefined8 *)((int64_t)&iStackX_20 + iVar8 + iVar6) = 0x18022be59;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar8 + iVar6), 
                              *(int64_t *)((int64_t)&arg_50h + iVar8 + iVar6), 
                              *(int64_t *)(&stack0x00000058 + iVar8 + iVar6), 
                              *(int64_t *)(&stack0x00000060 + iVar8 + iVar6), 
                              *(int64_t *)(&stack0x00000078 + iVar8 + iVar6));
                *(undefined8 *)((int64_t)&iStackX_20 + iVar8 + iVar6) = 0x18022be6b;
                fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar8 + iVar6));
                return 0;
            }
            if (*(int32_t *)(in_RCX + 8) != 1) {
                if (*(int32_t *)(in_RCX + 8) != 2) {
                    *(undefined8 *)((int64_t)&iStackX_20 + iVar8 + iVar6) = 0x18022bece;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar8 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar8 + iVar6));
                    *(undefined8 *)((int64_t)&iStackX_20 + iVar8 + iVar6) = 0x18022bee6;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar8 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar8 + iVar6), 
                                  *(int64_t *)(&stack0x00000058 + iVar8 + iVar6), 
                                  *(int64_t *)(&stack0x00000060 + iVar8 + iVar6), 
                                  *(int64_t *)(&stack0x00000078 + iVar8 + iVar6));
                    *(undefined8 *)((int64_t)&iStackX_20 + iVar8 + iVar6) = 0x18022bef8;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar8 + iVar6));
                    return 0;
                }
                *(undefined4 *)((int64_t)&arg_50h + iVar8 + iVar6) = 1;
                *(undefined *)((int64_t)&arg_48h + iVar8 + iVar6) = 0;
                *(undefined8 *)((int64_t)&iStackX_20 + iVar8 + iVar6) = 0x18022bec4;
                uVar9 = fcn.18022bd50(*(int64_t *)((int64_t)&arg_48h + iVar8 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar8 + iVar6), 
                                      *(int64_t *)(&stack0x00000068 + iVar8 + iVar6), 
                                      *(int64_t *)(&stack0x00000070 + iVar8 + iVar6));
                return uVar9;
            }
            iVar5 = *(int64_t *)(in_RCX + 0x18);
            *(undefined4 *)((int64_t)&arg_50h + iVar8 + iVar6) = 1;
            *(char *)((int64_t)&arg_48h + iVar8 + iVar6) = *(char *)(iVar5 + -1 + iVar4) >> 7;
            *(undefined8 *)((int64_t)&iStackX_20 + iVar8 + iVar6) = 0x18022be9e;
            uVar9 = fcn.18022bd50(*(int64_t *)((int64_t)&arg_48h + iVar8 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar8 + iVar6), 
                                  *(int64_t *)(&stack0x00000068 + iVar8 + iVar6), 
                                  *(int64_t *)(&stack0x00000070 + iVar8 + iVar6));
            return uVar9;
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x18022a21d;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6));
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x18022a3ef;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                  *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                  *(int64_t *)((int64_t)&arg_50h + iVar6));
    *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x18022a401;
    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_18022bf00
// Address: 0x18022bf00
// Size: 201 bytes
// ============================================================
undefined8 fcn.18022bf00(int64_t arg_70h, int64_t arg_78h, int64_t arg_a8h, int64_t arg_b0h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 in_R8;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022bf0a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    iVar4 = *(int64_t *)(in_RCX + 0x10);
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022bf21;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022bf39;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022bf4b;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    if (*(int32_t *)(in_RCX + 8) == 1) {
        iVar5 = *(int64_t *)(in_RCX + 0x18);
        *(undefined8 *)(&stack0x00000030 + iVar1) = 0x18022c7da;
        iVar2 = fcn.18045a350(in_RDX, in_R8);
        iVar2 = -iVar2;
        if (*(char *)(iVar4 + -1 + iVar5) < '\0') {
            *(undefined8 *)(&stack0x00000030 + iVar2 + iVar1) = 0x18022c7ea;
            fcn.180229480(*(int64_t *)(&stack0x00000058 + iVar2 + iVar1), *(int64_t *)(&stack0x00000060 + iVar2 + iVar1)
                         );
            *(undefined8 *)(&stack0x00000030 + iVar2 + iVar1) = 0x18022c802;
            fcn.1802295a0(*(int64_t *)(&stack0x00000058 + iVar2 + iVar1), *(int64_t *)(&stack0x00000060 + iVar2 + iVar1)
                          , *(int64_t *)(&stack0x00000068 + iVar2 + iVar1), 
                          *(int64_t *)((int64_t)&arg_70h + iVar2 + iVar1), 
                          *(int64_t *)(&stack0x00000088 + iVar2 + iVar1));
            *(undefined8 *)(&stack0x00000030 + iVar2 + iVar1) = 0x18022c814;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_78h + iVar2 + iVar1));
            return 0;
        }
        *(undefined4 *)(&stack0x00000060 + iVar2 + iVar1) = 0;
        (&stack0x00000058)[iVar2 + iVar1] = 0;
        *(undefined8 *)(&stack0x00000030 + iVar2 + iVar1) = 0x18022c82d;
        uVar3 = fcn.18022bd50(*(int64_t *)(&stack0x00000058 + iVar2 + iVar1), 
                              *(int64_t *)(&stack0x00000060 + iVar2 + iVar1), 
                              *(int64_t *)((int64_t)&arg_78h + iVar2 + iVar1), 
                              *(int64_t *)(&stack0x00000080 + iVar2 + iVar1));
        return uVar3;
    }
    if (*(int32_t *)(in_RCX + 8) == 2) {
        *(undefined4 *)(&stack0x00000028 + iVar1) = 0;
        *(undefined *)((int64_t)&iStackX_20 + iVar1) = 0;
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022bf8e;
        uVar3 = fcn.18022bd50(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                              *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1));
        return uVar3;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022bf98;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022bfb0;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                  *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022bfc2;
    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
    return 0;
}

// ============================================================
// Function: FUN_18022bfd0
// Address: 0x18022bfd0
// Size: 263 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int32_t fcn.18022bfd0(int64_t arg_38h, int64_t arg_40h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022bfe5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar2 = 0;
    if (*(int64_t *)(in_RCX + 0x10) == 0) {
        *(int64_t *)(in_RCX + 0x20) = in_R8;
        return 1;
    }
    if (*(int32_t *)(in_RCX + 8) == 1) {
        cVar1 = *(char *)(in_RDX + -1 + in_R8);
        *(undefined4 *)((int64_t)&var_20h + iVar3) = 1;
        *(char *)((int64_t)&var_18h + iVar3) = cVar1 >> 7;
code_r0x00018022c077:
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c086;
        iVar2 = fcn.18022bd50(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3));
    } else {
        if (*(int32_t *)(in_RCX + 8) != 2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c097;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c0af;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c0c1;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            goto code_r0x00018022c0c1;
        }
        if (-1 < *(char *)(in_RDX + -1 + in_R8)) {
            *(undefined4 *)((int64_t)&var_20h + iVar3) = 0;
            *(undefined *)((int64_t)&var_18h + iVar3) = 0;
            goto code_r0x00018022c077;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c042;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c05a;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c06c;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        iVar2 = 0;
    }
    if (iVar2 != 0) {
        in_R8 = *(int64_t *)(in_RCX + 0x18);
    }
code_r0x00018022c0c1:
    *(int64_t *)(in_RCX + 0x20) = in_R8;
    return iVar2;
}

// ============================================================
// Function: FUN_18022c0e0
// Address: 0x18022c0e0
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.18022c0e0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 in_R8;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022c0f5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar2 = 0;
    if (*(int64_t *)(in_RCX + 0x10) == 0) {
        iVar2 = 1;
    } else {
        iVar1 = *(int32_t *)(in_RCX + 8);
        *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_R14;
        if (iVar1 == 1) {
            iVar2 = 1;
        } else if (iVar1 != 2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c154;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c16c;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c17e;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            goto code_r0x00018022c185;
        }
        *(int32_t *)((int64_t)&var_20h + iVar3) = iVar2;
        *(undefined *)((int64_t)&var_18h + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c144;
        iVar2 = fcn.18022bd50(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3));
        if (iVar2 != 0) {
            in_R8 = *(undefined8 *)(in_RCX + 0x18);
        }
    }
code_r0x00018022c185:
    *(undefined8 *)(in_RCX + 0x20) = in_R8;
    return iVar2;
}

// ============================================================
// Function: FUN_18022c113
// Address: 0x18022c113
// Size: 114 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.18022c0e0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 in_R8;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022c0f5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar2 = 0;
    if (*(int64_t *)(in_RCX + 0x10) == 0) {
        iVar2 = 1;
    } else {
        iVar1 = *(int32_t *)(in_RCX + 8);
        *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_R14;
        if (iVar1 == 1) {
            iVar2 = 1;
        } else if (iVar1 != 2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c154;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c16c;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c17e;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            goto code_r0x00018022c185;
        }
        *(int32_t *)((int64_t)&var_20h + iVar3) = iVar2;
        *(undefined *)((int64_t)&var_18h + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c144;
        iVar2 = fcn.18022bd50(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3));
        if (iVar2 != 0) {
            in_R8 = *(undefined8 *)(in_RCX + 0x18);
        }
    }
code_r0x00018022c185:
    *(undefined8 *)(in_RCX + 0x20) = in_R8;
    return iVar2;
}

// ============================================================
// Function: FUN_18022c185
// Address: 0x18022c185
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.18022c0e0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 in_R8;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022c0f5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar2 = 0;
    if (*(int64_t *)(in_RCX + 0x10) == 0) {
        iVar2 = 1;
    } else {
        iVar1 = *(int32_t *)(in_RCX + 8);
        *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_R14;
        if (iVar1 == 1) {
            iVar2 = 1;
        } else if (iVar1 != 2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c154;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c16c;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c17e;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            goto code_r0x00018022c185;
        }
        *(int32_t *)((int64_t)&var_20h + iVar3) = iVar2;
        *(undefined *)((int64_t)&var_18h + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c144;
        iVar2 = fcn.18022bd50(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3));
        if (iVar2 != 0) {
            in_R8 = *(undefined8 *)(in_RCX + 0x18);
        }
    }
code_r0x00018022c185:
    *(undefined8 *)(in_RCX + 0x20) = in_R8;
    return iVar2;
}

// ============================================================
// Function: FUN_18022c1a0
// Address: 0x18022c1a0
// Size: 439 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18022c1a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t *in_R8;
    uint64_t *in_R9;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x18022c1b6;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (((in_RDX == (int64_t *)0x0) && (in_R9 == (uint64_t *)0x0)) || (in_RCX == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022c1d6;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022c1ee;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                      *(int64_t *)((int64_t)&arg_48h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022c200;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
        return 0;
    }
    if (*(int32_t *)(in_RCX + 8) != *(int32_t *)((int64_t)&arg_48h + iVar2)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022c221;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022c239;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                      *(int64_t *)((int64_t)&arg_48h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022c24b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
    uVar1 = *(uint64_t *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBP;
    if ((*(int32_t *)((int64_t)&arg_48h + iVar2) == 4) || (uVar1 == 0)) {
        iVar3 = 1;
    } else {
        iVar3 = 0;
    }
    if (in_R9 != (uint64_t *)0x0) {
        *in_R9 = uVar1;
    }
    if (*(int64_t *)(in_RCX + 0x10) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022c297;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022c2af;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                      *(int64_t *)((int64_t)&arg_48h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022c2c1;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
        return 0;
    }
    if (in_RDX == (int64_t *)0x0) {
code_r0x00018022c337:
        uVar5 = 1;
    } else {
        if (*in_RDX == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022c2e5;
            iVar4 = func_0x0001802248d0(iVar3 + uVar1, 0x1804c0808, 0x554);
            if (iVar4 != 0) {
                *in_RDX = iVar4;
                *in_R8 = iVar3 + uVar1;
                goto code_r0x00018022c2f0;
            }
        } else {
code_r0x00018022c2f0:
            if (uVar1 <= *in_R8) {
                uVar5 = *(undefined8 *)(in_RCX + 0x10);
                iVar3 = *in_RDX;
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022c337;
                fcn.180498030(iVar3, uVar5, uVar1);
                goto code_r0x00018022c337;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022c2fa;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022c312;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                          *(int64_t *)((int64_t)&arg_48h + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022c324;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
        }
        uVar5 = 0;
    }
    return uVar5;
}

// ============================================================
// Function: FUN_18022c360
// Address: 0x18022c360
// Size: 411 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18022c360(int64_t arg_28h, int64_t arg_48h, int64_t arg_68h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t in_RCX;
    int64_t in_RDX;
    uint64_t uVar6;
    int64_t *in_R8;
    undefined8 *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18022c379;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar6 = 0;
    *(undefined8 *)((int64_t)&arg_68h + iVar4) = 0;
    if (in_RCX == 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022c3a7;
    iVar3 = func_0x000180244450((int64_t)&var_8h + iVar4, 0);
    if (iVar3 == 0) {
        return 0;
    }
    if (in_RCX != 0) {
        do {
            iVar5 = *(int64_t *)(in_RDX + uVar6 * 8);
            if (*(int32_t *)(iVar5 + 8) != 5) goto code_r0x00018022c4d9;
            if ((*(int64_t *)(iVar5 + 0x10) != 0) && (*(int64_t *)(iVar5 + 0x18) != 0)) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022c3ea;
                iVar3 = func_0x0001802445f0((int64_t)&var_8h + iVar4);
                if (iVar3 == 0) goto code_r0x00018022c4d9;
            }
            uVar6 = uVar6 + 1;
        } while (uVar6 < in_RCX);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022c40c;
    iVar3 = func_0x0001802442e0((int64_t)&var_8h + iVar4, (int64_t)&arg_68h + iVar4);
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022c41e;
        iVar3 = func_0x000180244200((int64_t)&var_8h + iVar4);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022c430;
            func_0x000180243fb0((int64_t)&var_8h + iVar4);
            if (*(int64_t *)((int64_t)&arg_68h + iVar4) == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022c454;
                iVar5 = func_0x000180224d60(1, 0x1804c0808, 0x669);
                if (iVar5 == 0) {
                    return 0;
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022c498;
                iVar5 = func_0x0001802248d0(*(int64_t *)((int64_t)&arg_68h + iVar4), 0x1804c0808, 0x66f);
                if (iVar5 == 0) {
                    return 0;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022c4b6;
                iVar3 = func_0x00018022c6e0(in_RCX, in_RDX, iVar5, (int64_t)&arg_68h + iVar4);
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022c4d7;
                    func_0x000180224b90(iVar5, *(undefined8 *)((int64_t)&arg_68h + iVar4), 0x1804c0808, 0x675);
                    return 0;
                }
            }
            uVar1 = *in_R9;
            iVar2 = *in_R8;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022c478;
            func_0x000180224b90(iVar2, uVar1, 0x1804c0808, 0x67a);
            uVar1 = *(undefined8 *)((int64_t)&arg_68h + iVar4);
            *in_R8 = iVar5;
            *in_R9 = uVar1;
            return 1;
        }
    }
code_r0x00018022c4d9:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022c4e3;
    func_0x000180243fb0((int64_t)&var_8h + iVar4);
    return 0;
}

// ============================================================
// Function: FUN_18022c500
// Address: 0x18022c500
// Size: 56 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18022c500(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    int64_t *in_RDX;
    int64_t iVar6;
    undefined8 unaff_RSI;
    int64_t *in_R8;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x18022c519;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar4 = 0;
    if (in_RCX == 0) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
    iVar6 = iVar4;
    if ((*(int64_t *)(in_RCX + 0x10) == 0) || (iVar1 = *(int64_t *)(in_RCX + 0x18), iVar6 = 0, iVar1 == 0)) {
code_r0x00018022c5b4:
        iVar1 = *in_R8;
        iVar2 = *in_RDX;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18022c5cc;
        func_0x000180224b90(iVar2, iVar1, 0x1804c0808, 0x62c);
        *in_RDX = iVar4;
        uVar5 = 1;
        *in_R8 = iVar6;
    } else {
        if (*(int32_t *)(in_RCX + 8) == 5) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18022c59d;
            iVar4 = func_0x0001802248d0(iVar1, 0x1804c0808, 0x554);
            if (iVar4 != 0) {
                uVar5 = *(undefined8 *)(in_RCX + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18022c5b4;
                fcn.180498030(iVar4, uVar5, iVar1);
                iVar6 = iVar1;
                goto code_r0x00018022c5b4;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18022c557;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18022c56f;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar3));
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18022c581;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar3));
        }
        uVar5 = 0;
    }
    return uVar5;
}

// ============================================================
// Function: FUN_18022c538
// Address: 0x18022c538
// Size: 164 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18022c500(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    int64_t *in_RDX;
    int64_t iVar6;
    undefined8 unaff_RSI;
    int64_t *in_R8;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x18022c519;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar4 = 0;
    if (in_RCX == 0) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
    iVar6 = iVar4;
    if ((*(int64_t *)(in_RCX + 0x10) == 0) || (iVar1 = *(int64_t *)(in_RCX + 0x18), iVar6 = 0, iVar1 == 0)) {
code_r0x00018022c5b4:
        iVar1 = *in_R8;
        iVar2 = *in_RDX;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18022c5cc;
        func_0x000180224b90(iVar2, iVar1, 0x1804c0808, 0x62c);
        *in_RDX = iVar4;
        uVar5 = 1;
        *in_R8 = iVar6;
    } else {
        if (*(int32_t *)(in_RCX + 8) == 5) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18022c59d;
            iVar4 = func_0x0001802248d0(iVar1, 0x1804c0808, 0x554);
            if (iVar4 != 0) {
                uVar5 = *(undefined8 *)(in_RCX + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18022c5b4;
                fcn.180498030(iVar4, uVar5, iVar1);
                iVar6 = iVar1;
                goto code_r0x00018022c5b4;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18022c557;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18022c56f;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar3));
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18022c581;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar3));
        }
        uVar5 = 0;
    }
    return uVar5;
}

// ============================================================
// Function: FUN_18022c5dc
// Address: 0x18022c5dc
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18022c500(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    int64_t *in_RDX;
    int64_t iVar6;
    undefined8 unaff_RSI;
    int64_t *in_R8;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x18022c519;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar4 = 0;
    if (in_RCX == 0) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
    iVar6 = iVar4;
    if ((*(int64_t *)(in_RCX + 0x10) == 0) || (iVar1 = *(int64_t *)(in_RCX + 0x18), iVar6 = 0, iVar1 == 0)) {
code_r0x00018022c5b4:
        iVar1 = *in_R8;
        iVar2 = *in_RDX;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18022c5cc;
        func_0x000180224b90(iVar2, iVar1, 0x1804c0808, 0x62c);
        *in_RDX = iVar4;
        uVar5 = 1;
        *in_R8 = iVar6;
    } else {
        if (*(int32_t *)(in_RCX + 8) == 5) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18022c59d;
            iVar4 = func_0x0001802248d0(iVar1, 0x1804c0808, 0x554);
            if (iVar4 != 0) {
                uVar5 = *(undefined8 *)(in_RCX + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18022c5b4;
                fcn.180498030(iVar4, uVar5, iVar1);
                iVar6 = iVar1;
                goto code_r0x00018022c5b4;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18022c557;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18022c56f;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar3));
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18022c581;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar3));
        }
        uVar5 = 0;
    }
    return uVar5;
}

// ============================================================
// Function: FUN_18022c5f0
// Address: 0x18022c5f0
// Size: 233 bytes
// ============================================================
undefined8 fcn.18022c5f0(int64_t arg_30h, int64_t arg_38h, int64_t arg_50h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t in_RCX;
    uint64_t in_R8;
    int32_t in_R9D;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022c605;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*(int32_t *)(in_RCX + 8) != in_R9D) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022c61c;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022c634;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022c646;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar1));
        return 0;
    }
    *(uint64_t *)(in_RCX + 0x20) = in_R8;
    if (*(int64_t *)(in_RCX + 0x10) != 0) {
        if (*(uint64_t *)(in_RCX + 0x18) < in_R8) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022c670;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022c688;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                          *(int64_t *)(&stack0x00000048 + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022c69a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar1));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022c6b1;
        fcn.180498030();
        if ((in_R9D == 4) && (in_R8 < *(uint64_t *)(in_RCX + 0x18))) {
            *(undefined *)(in_R8 + *(int64_t *)(in_RCX + 0x10)) = 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18022c6e0
// Address: 0x18022c6e0
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.18022c6e0(int64_t arg_28h, int64_t arg_58h, int64_t arg_68h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar5;
    uint64_t uVar6;
    int64_t in_R8;
    undefined8 *in_R9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022c6fb;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar6 = 0;
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022c721;
        iVar3 = func_0x000180244450((int64_t)&var_18h + iVar4, 0);
    } else {
        uVar2 = *in_R9;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022c7c3;
        iVar3 = func_0x000180244550((int64_t)&var_18h + iVar4, in_R8, uVar2, 0);
    }
    if (iVar3 == 0) {
        uVar6 = 0;
    } else {
        *(undefined8 *)((int64_t)&arg_68h + iVar4) = unaff_RBX;
        uVar5 = uVar6;
        if (in_RCX != 0) {
            do {
                iVar1 = *(int64_t *)(in_RDX + uVar5 * 8);
                if (*(int32_t *)(iVar1 + 8) != 5) goto code_r0x00018022c78d;
                if ((*(int64_t *)(iVar1 + 0x10) != 0) && (*(int64_t *)(iVar1 + 0x18) != 0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022c75c;
                    iVar3 = func_0x0001802445f0((int64_t)&var_18h + iVar4);
                    if (iVar3 == 0) goto code_r0x00018022c78d;
                }
                uVar5 = uVar5 + 1;
            } while (uVar5 < in_RCX);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022c775;
        iVar3 = func_0x0001802442e0((int64_t)&var_18h + iVar4, in_R9);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022c783;
            iVar3 = func_0x000180244200((int64_t)&var_18h + iVar4);
            uVar6 = 0;
            if (iVar3 != 0) {
                uVar6 = 1;
            }
        }
code_r0x00018022c78d:
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022c797;
        func_0x000180243fb0((int64_t)&var_18h + iVar4);
    }
    return uVar6;
}

