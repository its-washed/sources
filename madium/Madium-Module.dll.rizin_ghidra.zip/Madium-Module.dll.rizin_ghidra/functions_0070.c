// Chunk 70 - 50 functions

// ============================================================
// Function: FUN_1800e3690
// Address: 0x1800e3690
// Size: 2365 bytes
// ============================================================
int64_t fcn.1800e3690(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t *placeholder_4,
                     int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t **ppiVar3;
    undefined *puVar4;
    code *pcVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    int64_t iVar18;
    undefined uVar19;
    int64_t *piVar20;
    undefined4 *puVar21;
    undefined8 uVar22;
    uint64_t uVar23;
    int64_t iVar24;
    int64_t *piVar25;
    uint64_t uVar26;
    int64_t iVar27;
    int64_t iVar28;
    undefined *puVar29;
    int64_t iVar30;
    uint64_t uVar31;
    undefined *puVar32;
    undefined *puVar33;
    int64_t iVar34;
    undefined uVar35;
    int64_t iVar36;
    uint64_t uVar37;
    undefined4 uVar38;
    undefined4 uVar39;
    undefined4 uVar40;
    undefined4 uVar41;
    undefined4 uVar42;
    undefined4 uVar43;
    undefined4 uVar44;
    undefined4 uVar45;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined var_20h;
    int64_t var_21h;
    undefined auStack_198 [8];
    undefined auStack_190 [24];
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    undefined8 var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    undefined4 uStack_110;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    undefined4 uStack_c0;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_40h;
    
    uVar38 = *(undefined4 *)(int64_t *)(arg4 + 4);
    uVar39 = *(undefined4 *)(arg4 + 8);
    var_98h = *(int64_t *)(arg4 + 4);
    uVar40 = *(undefined4 *)(int64_t *)(arg4 + 0xc);
    uVar41 = *(undefined4 *)(arg4 + 0x10);
    var_90h = *(int64_t *)(arg4 + 0xc);
    if (*(int64_t *)(arg_38h + 8) != 0) {
        iVar30 = **(int64_t **)arg_38h;
        uVar38 = *(undefined4 *)(int64_t *)(iVar30 + 0xc);
        uVar39 = *(undefined4 *)(iVar30 + 0x10);
        var_98h = *(int64_t *)(iVar30 + 0xc);
        uVar40 = *(undefined4 *)(int64_t *)(iVar30 + 0x14);
        uVar41 = *(undefined4 *)(iVar30 + 0x18);
        var_90h = *(int64_t *)(iVar30 + 0x14);
    }
    if (*(char *)(arg1 + 0x58) == '\0') {
        var_178h = 0;
        var_150h = 0;
        piVar20 = &var_148h;
        var_170h = var_178h;
        piVar25 = (int64_t *)var_178h;
    } else {
        ppiVar3 = *(int64_t ***)(arg1 + 0xd8);
        iVar30 = (int64_t)*ppiVar3;
        if (iVar30 == 0) {
code_r0x0001800e3742:
            piVar20 = (int64_t *)func_0x000180459890(0x2008);
            *piVar20 = (int64_t)*ppiVar3;
            *ppiVar3 = piVar20;
            var_150h = (int64_t)(piVar20 + 1);
            piVar20 = (int64_t *)0x60;
        } else {
            var_150h = (int64_t)ppiVar3[1] + iVar30 + 0xf & 0xfffffffffffffff8;
            if ((int64_t *)(iVar30 + 0x2008U) < (int64_t *)(var_150h + 0x60)) goto code_r0x0001800e3742;
            piVar20 = (int64_t *)(var_150h + (0x60 - (iVar30 + 8)));
        }
        ppiVar3[1] = piVar20;
        *(undefined4 *)var_150h = *(undefined4 *)0x180782a40;
        *(undefined8 *)(var_150h + 4) = 0xffffffffffffffff;
        *(int64_t *)(var_150h + 0xc) = -1;
        var_178h = var_150h + 0x18;
        *(int64_t *)var_178h = 0;
        *(int64_t *)(var_150h + 0x20) = 0;
        *(int64_t *)(var_150h + 0x28) = -1;
        *(int64_t *)(var_150h + 0x30) = 0;
        *(int64_t *)(var_150h + 0x38) = 0;
        *(int64_t *)(var_150h + 0x40) = 0;
        *(int64_t *)(var_150h + 0x48) = 0;
        *(int64_t *)(var_150h + 0x50) = -1;
        *(int64_t *)(var_150h + 0x58) = -1;
        piVar20 = &var_b8h;
        var_170h = (int64_t)(int64_t *)(var_150h + 0x28);
        piVar25 = (int64_t *)(var_150h + 0xc);
    }
    iVar36 = var_150h;
    uVar31 = 0;
    puVar21 = (undefined4 *)func_0x0001800ecbd0(arg1, piVar20, 0, piVar25);
    uVar8 = *puVar21;
    uVar9 = puVar21[1];
    uVar10 = puVar21[2];
    uVar11 = puVar21[3];
    uVar12 = puVar21[4];
    uVar13 = puVar21[5];
    uVar14 = puVar21[6];
    uVar15 = puVar21[7];
    iVar2 = *(int32_t *)(arg1 + 0x80);
    iVar30 = *(int64_t *)(arg1 + 0x84);
    var_c8h._4_4_ = (undefined4)iVar30;
    uVar16 = var_c8h._4_4_;
    uStack_c0 = (undefined4)((uint64_t)iVar30 >> 0x20);
    uVar17 = uStack_c0;
    var_c8h._0_4_ = iVar2;
    if (iVar2 == 0x28) {
        func_0x0001800f0350(arg1);
    } else {
        func_0x0001800ef2a0(arg1, 0x28, 0x180622fe0);
    }
    piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x1e8) + 0xa4);
    *piVar1 = *piVar1 + 1;
    var_108h = arg1 + 0x2f0;
    var_b0h = (*(int64_t *)(arg1 + 0x2f8) - *(int64_t *)var_108h >> 4) * -0x5555555555555555;
    var_a8h = 0;
    var_d8h = 0;
    var_d0h = 0;
    var_b8h = var_108h;
    if (*(int32_t *)(arg1 + 0x80) == 0x29) {
        uVar35 = 0;
        var_f8h = 0;
    } else {
        var_160h._0_1_ = 0;
        if (iVar36 == 0) {
            var_168h = 0;
            var_170h = 0;
            var_178h = 0;
            piVar20 = (int64_t *)func_0x0001800e4340(arg1, &var_148h, &var_b8h, 1);
            uVar35 = *(undefined *)(piVar20 + 3);
            var_d8h = piVar20[1];
            var_d0h = piVar20[2];
            var_f8h = *piVar20;
        } else {
            var_168h = iVar36 + 0x50;
            var_178h = iVar36 + 0x40;
            var_170h = 0;
            piVar20 = (int64_t *)func_0x0001800e4340(arg1, &var_148h, &var_b8h, 1);
            uVar35 = *(undefined *)(piVar20 + 3);
            var_d8h = piVar20[1];
            var_d0h = piVar20[2];
            var_f8h = *piVar20;
        }
    }
    iVar18 = var_b0h;
    puVar32 = auStack_198;
    puVar33 = auStack_198;
    var_158h._0_1_ = 0;
    uVar42 = (undefined4)var_148h;
    uVar43 = var_148h._4_4_;
    uVar44 = (undefined4)var_140h;
    uVar45 = var_140h._4_4_;
    if ((iVar2 == 0x28) && (*(int32_t *)(arg1 + 0x80) == 0x29)) {
        iVar28 = *(int64_t *)(arg1 + 0x8c);
        var_e0h._0_4_ = (undefined4)iVar28;
        var_e0h._4_4_ = (undefined4)((uint64_t)iVar28 >> 0x20);
        var_158h._0_1_ = 1;
        uVar42 = uVar16;
        uVar43 = uVar17;
        uVar44 = (undefined4)var_e0h;
        uVar45 = var_e0h._4_4_;
        var_e8h = iVar30;
        var_e0h = iVar28;
    }
    var_108h = var_b8h;
    if (*(int32_t *)(arg1 + 0x80) == 0x29) {
        func_0x0001800f0350(arg1);
    } else {
        func_0x0001800ef5a0(arg1, 0x29, &var_c8h, 0);
        func_0x0001800ef4e0(arg1, 0x29);
    }
    piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x1e8) + 0xa4);
    *piVar1 = *piVar1 + -1;
    uVar37 = iVar36 + 0x58;
    if (iVar36 == 0) {
        uVar37 = uVar31;
    }
    uVar22 = func_0x0001800e4820(arg1, uVar37);
    var_c8h._0_4_ = (int32_t)uVar22;
    var_c8h._4_4_ = (undefined4)((uint64_t)uVar22 >> 0x20);
    var_f0h = 0;
    if (arg_30h != 0) {
        var_148h._0_4_ = *(undefined4 *)arg_30h;
        var_148h._4_4_ = *(undefined4 *)(arg_30h + 4);
        var_140h._0_4_ = *(undefined4 *)(arg_30h + 8);
        var_140h._4_4_ = *(undefined4 *)(arg_30h + 0xc);
        var_138h = *(int64_t *)(arg_30h + 0x10);
        var_130h = 0;
        var_128h = 0;
        if (*(char *)0x180778460 == '\0') {
            var_120h._0_1_ = 0;
        } else {
            var_120h._0_1_ = (undefined)arg_40h;
        }
        var_f0h = func_0x0001800eef70(arg1, &var_148h);
    }
    iVar30 = *(int64_t *)(arg1 + 0x198);
    var_100h = *(int64_t *)(arg1 + 400);
    puVar29 = *(undefined **)(arg1 + 0x150);
    var_21h._2_1_ = (undefined)((uint64_t)arg4 >> 0x18);
    var_21h._0_2_ = (undefined2)((uint64_t)arg4 >> 8);
    if (puVar29 == *(undefined **)(arg1 + 0x158)) {
        iVar28 = (int64_t)puVar29 - *(int64_t *)(arg1 + 0x148) >> 3;
        if (iVar28 == 0x1fffffffffffffff) {
            func_0x000180010010();
code_r0x0001800e3fc7:
            func_0x000180004720();
            pcVar5 = (code *)swi(3);
            iVar30 = (*pcVar5)();
            return iVar30;
        }
        uVar37 = (int64_t)*(undefined **)(arg1 + 0x158) - *(int64_t *)(arg1 + 0x148) >> 3;
        if (0x1fffffffffffffff - (uVar37 >> 1) < uVar37) goto code_r0x0001800e3fc7;
        uVar37 = (uVar37 >> 1) + uVar37;
        uVar26 = iVar28 + 1U;
        if (iVar28 + 1U <= uVar37) {
            uVar26 = uVar37;
        }
        var_118h._0_4_ = (undefined4)uVar26;
        var_118h._4_4_ = (int32_t)(uVar26 >> 0x20);
        if (0x1fffffffffffffff < uVar26) goto code_r0x0001800e3fc7;
        uVar26 = uVar26 * 8;
        uVar37 = uVar31;
        if (uVar26 != 0) {
            if (uVar26 < 0x1000) {
                uVar37 = func_0x000180459890();
                puVar33 = auStack_198;
            } else {
                if (uVar26 + 0x27 <= uVar26) goto code_r0x0001800e3fc7;
                iVar34 = func_0x000180459890(uVar26 + 0x27);
                if (iVar34 == 0) {
                    pcVar5 = (code *)swi(0x29);
                    iVar34 = (*pcVar5)(5);
                    puVar32 = auStack_190;
                }
                uVar37 = iVar34 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar37 - 8) = iVar34;
                puVar33 = puVar32;
            }
        }
        *(undefined *)(uVar37 + iVar28 * 8) = uVar35;
        *(undefined2 *)(uVar37 + 1 + iVar28 * 8) = (undefined2)var_21h;
        *(undefined *)(uVar37 + 3 + iVar28 * 8) = var_21h._2_1_;
        *(undefined4 *)(uVar37 + 4 + iVar28 * 8) = 0;
        puVar4 = *(undefined **)(arg1 + 0x148);
        if (puVar29 == *(undefined **)(arg1 + 0x150)) {
            iVar34 = (int64_t)*(undefined **)(arg1 + 0x150) - (int64_t)puVar4;
            uVar26 = uVar37;
            puVar29 = puVar4;
        } else {
            *(undefined8 *)(puVar33 + -8) = 0x1800e3b5f;
            func_0x000180498030(uVar37, puVar4, (int64_t)puVar29 - (int64_t)puVar4);
            iVar34 = *(int64_t *)(arg1 + 0x150) - (int64_t)puVar29;
            uVar26 = uVar37 + (iVar28 + 1) * 8;
        }
        *(undefined8 *)(puVar33 + -8) = 0x1800e3b79;
        func_0x000180498030(uVar26, puVar29, iVar34);
        *(undefined8 *)(puVar33 + -8) = 0x1800e3b90;
        func_0x0001800c2120(arg1 + 0x148, uVar37, iVar28 + 1, CONCAT44(var_118h._4_4_, (undefined4)var_118h));
    } else {
        *puVar29 = uVar35;
        *(undefined2 *)(puVar29 + 1) = (undefined2)var_21h;
        puVar29[3] = var_21h._2_1_;
        *(undefined4 *)(puVar29 + 4) = 0;
        *(int64_t *)(arg1 + 0x150) = *(int64_t *)(arg1 + 0x150) + 8;
        puVar33 = auStack_198;
    }
    iVar30 = iVar30 - var_100h;
    var_100h = 0;
    if ((char)placeholder_2 != '\0') {
        *(undefined8 *)(puVar33 + 0x50) = *(undefined8 *)(arg1 + 0x118);
        auVar6._4_4_ = uVar39;
        auVar6._0_4_ = uVar38;
        auVar6._8_4_ = uVar40;
        auVar6._12_4_ = uVar41;
        *(undefined (*) [16])(puVar33 + 0x58) = auVar6;
        *(undefined4 *)(puVar33 + 0x50) = *(undefined4 *)(puVar33 + 0x50);
        *(undefined4 *)(puVar33 + 0x54) = *(undefined4 *)(puVar33 + 0x54);
        *(undefined4 *)(puVar33 + 0x58) = *(undefined4 *)(puVar33 + 0x58);
        *(undefined4 *)(puVar33 + 0x5c) = *(undefined4 *)(puVar33 + 0x5c);
        *(uint64_t *)(puVar33 + 0x60) = CONCAT44(uVar41, uVar40);
        *(undefined8 *)(puVar33 + 0x68) = 0;
        *(undefined8 *)(puVar33 + 0x70) = 0;
        puVar33[0x78] = 0;
        *(undefined8 *)(puVar33 + -8) = 0x1800e3bf8;
        var_100h = func_0x0001800eef70(arg1, puVar33 + 0x50);
    }
    iVar24 = var_a8h;
    iVar34 = var_108h;
    piVar20 = (int64_t *)(arg1 + 0x308);
    *(int64_t **)(puVar33 + 0x50) = piVar20;
    iVar27 = *(int64_t *)(arg1 + 0x310) - *piVar20;
    iVar28 = iVar27 >> 3;
    var_118h._0_4_ = (undefined4)iVar28;
    var_118h._4_4_ = (int32_t)(iVar27 >> 0x23);
    *(int64_t *)(puVar33 + 0x58) = iVar28;
    *(undefined8 *)(puVar33 + 0x60) = 0;
    uVar37 = uVar31;
    if (var_a8h != 0) {
        do {
            iVar36 = *(int64_t *)iVar34;
            *(undefined8 *)(puVar33 + -8) = 0x1800e3c57;
            var_e8h = func_0x0001800eef70(arg1, (iVar18 + uVar31) * 0x30 + iVar36);
            *(undefined8 *)(puVar33 + -8) = 0x1800e3c67;
            func_0x0001800bf890(piVar20, &var_e8h);
            uVar37 = uVar37 + 1;
            *(uint64_t *)(puVar33 + 0x60) = uVar37;
            uVar31 = uVar31 + 1;
        } while (uVar31 < (uint64_t)iVar24);
        iVar36 = *(int64_t *)(puVar33 + 0x48);
        iVar28 = CONCAT44(var_118h._4_4_, (undefined4)var_118h);
    }
    uVar31 = 0;
    if (uVar37 == 0) {
        uVar23 = 0;
        uVar26 = uVar31;
    } else {
        iVar34 = *piVar20;
        uVar22 = *(undefined8 *)(arg1 + 0xd8);
        *(undefined8 *)(puVar33 + -8) = 0x1800e3cad;
        uVar23 = func_0x0001800d4d20(uVar22, uVar37 * 8);
        uVar26 = iVar34 + iVar28 * 8;
    }
    *(uint64_t *)(puVar33 + 0x48) = uVar23;
    if (uVar37 != 0) {
        if ((1 < uVar37) && ((uVar26 + (uVar37 - 1) * 8 < uVar23 || (uVar23 + (uVar37 - 1) * 8 < uVar26)))) {
            *(undefined8 *)(puVar33 + -8) = 0x1800e3cf6;
            func_0x000180498030(uVar23, uVar26, uVar37 * 8);
            do {
                uVar31 = uVar31 + 1;
            } while (uVar31 < uVar37);
        }
        if (uVar31 < uVar37) {
            iVar28 = *(int64_t *)(puVar33 + 0x48);
            do {
                *(undefined8 *)(iVar28 + uVar31 * 8) = *(undefined8 *)(uVar26 + uVar31 * 8);
                uVar31 = uVar31 + 1;
            } while (uVar31 < uVar37);
        }
    }
    iVar28 = *piVar20 + CONCAT44(var_118h._4_4_, (undefined4)var_118h) * 8;
    if (iVar28 != *(int64_t *)(arg1 + 0x310)) {
        *(int64_t *)(arg1 + 0x310) = iVar28;
    }
    iVar28 = *(int64_t *)(arg1 + 0x198);
    iVar34 = *(int64_t *)(arg1 + 400);
    *(undefined8 *)(puVar33 + -8) = 0x1800e3d74;
    iVar24 = func_0x0001800dae50(arg1);
    *(undefined8 *)(puVar33 + -8) = 0x1800e3d85;
    var_e8h = iVar24;
    func_0x0001800ef070(arg1, iVar28 - iVar34 >> 3 & 0xffffffff);
    *(int64_t *)(arg1 + 0x150) = *(int64_t *)(arg1 + 0x150) + -8;
    *(undefined8 *)(puVar33 + -8) = 0x1800e3d9b;
    func_0x0001800ef070(arg1, iVar30 >> 3 & 0xffffffff);
    uVar38 = *(undefined4 *)(arg1 + 0x88);
    uVar39 = *(undefined4 *)(arg1 + 0x8c);
    uVar40 = *(undefined4 *)(arg1 + 0x90);
    *(undefined4 *)(puVar33 + 0x50) = *(undefined4 *)(arg1 + 0x84);
    *(undefined4 *)(puVar33 + 0x54) = uVar38;
    *(undefined4 *)(puVar33 + 0x58) = uVar39;
    *(undefined4 *)(puVar33 + 0x5c) = uVar40;
    var_118h._0_4_ = *(undefined4 *)arg4;
    var_118h._4_4_ = (int32_t)*(undefined8 *)(arg4 + 4);
    uStack_110 = (undefined4)((uint64_t)*(undefined8 *)(arg4 + 4) >> 0x20);
    *(undefined8 *)(puVar33 + -8) = 0x1800e3dcc;
    uVar19 = func_0x0001800ef810(arg1, 0x128, &var_118h);
    *(undefined *)(iVar24 + 0x38) = uVar19;
    ppiVar3 = *(int64_t ***)(arg1 + 0xd8);
    iVar30 = *(int64_t *)(arg1 + 0x150);
    iVar28 = *(int64_t *)(arg1 + 0x148);
    var_90h = *(int64_t *)(puVar33 + 0x58);
    iVar34 = (int64_t)*ppiVar3;
    if (iVar34 != 0) {
        piVar20 = (int64_t *)((int64_t)ppiVar3[1] + iVar34 + 0xf & 0xfffffffffffffff8);
        if (piVar20 + 0x18 <= (int64_t *)(iVar34 + 0x2008)) {
            piVar25 = (int64_t *)((int64_t)piVar20 + (0xc0 - (iVar34 + 8)));
            goto code_r0x0001800e3e58;
        }
    }
    *(undefined8 *)(puVar33 + -8) = 0x1800e3e44;
    piVar20 = (int64_t *)func_0x000180459890(0x2008);
    *piVar20 = (int64_t)*ppiVar3;
    *ppiVar3 = piVar20;
    piVar20 = piVar20 + 1;
    piVar25 = (int64_t *)0xc0;
code_r0x0001800e3e58:
    ppiVar3[1] = piVar25;
    *(undefined4 *)(piVar20 + 1) = *(undefined4 *)0x1807826a0;
    *(undefined4 *)((int64_t)piVar20 + 0xc) = (undefined4)var_98h;
    *(undefined4 *)(piVar20 + 2) = var_98h._4_4_;
    *(undefined4 *)((int64_t)piVar20 + 0x14) = (undefined4)var_90h;
    *(undefined4 *)(piVar20 + 3) = var_90h._4_4_;
    *piVar20 = 0x180641ed8;
    uVar38 = *(undefined4 *)(arg_38h + 4);
    uVar39 = *(undefined4 *)(arg_38h + 8);
    uVar40 = *(undefined4 *)(arg_38h + 0xc);
    *(undefined4 *)(piVar20 + 4) = *(undefined4 *)arg_38h;
    *(undefined4 *)((int64_t)piVar20 + 0x24) = uVar38;
    *(undefined4 *)(piVar20 + 5) = uVar39;
    *(undefined4 *)((int64_t)piVar20 + 0x2c) = uVar40;
    *(undefined4 *)(piVar20 + 6) = uVar8;
    *(undefined4 *)((int64_t)piVar20 + 0x34) = uVar9;
    *(undefined4 *)(piVar20 + 7) = uVar10;
    *(undefined4 *)((int64_t)piVar20 + 0x3c) = uVar11;
    *(undefined4 *)(piVar20 + 8) = uVar12;
    *(undefined4 *)((int64_t)piVar20 + 0x44) = uVar13;
    *(undefined4 *)(piVar20 + 9) = uVar14;
    *(undefined4 *)((int64_t)piVar20 + 0x4c) = uVar15;
    piVar20[10] = var_100h;
    piVar20[0xb] = *(int64_t *)(puVar33 + 0x48);
    piVar20[0xc] = uVar37;
    piVar20[0xd] = CONCAT44(var_c8h._4_4_, (int32_t)var_c8h);
    *(undefined *)(piVar20 + 0xe) = uVar35;
    *(undefined4 *)((int64_t)piVar20 + 0x74) = (undefined4)var_d8h;
    *(undefined4 *)(piVar20 + 0xf) = var_d8h._4_4_;
    *(undefined4 *)((int64_t)piVar20 + 0x7c) = (undefined4)var_d0h;
    *(undefined4 *)(piVar20 + 0x10) = var_d0h._4_4_;
    piVar20[0x11] = var_f8h;
    piVar20[0x12] = var_e8h;
    piVar20[0x13] = iVar30 - iVar28 >> 3;
    piVar20[0x14] = *placeholder_4;
    auVar7._4_4_ = uVar43;
    auVar7._0_4_ = uVar42;
    auVar7._8_4_ = uVar44;
    auVar7._12_4_ = uVar45;
    *(undefined (*) [16])(piVar20 + 0x15) = auVar7;
    *(undefined *)(piVar20 + 0x17) = puVar33[0x40];
    *(undefined2 *)((int64_t)piVar20 + 0xb9) = *(undefined2 *)(puVar33 + 0x61);
    *(undefined *)((int64_t)piVar20 + 0xbb) = puVar33[99];
    if (*(char *)(arg1 + 0x58) != '\0') {
        *(undefined8 *)(iVar36 + 4) = *(undefined8 *)(arg4 + 4);
        *(undefined8 *)(puVar33 + -8) = 0x1800e3f42;
        puVar21 = (undefined4 *)func_0x0001800e4200(arg1, puVar33 + 0x50, &var_b8h);
        uVar38 = puVar21[1];
        uVar39 = puVar21[2];
        uVar40 = puVar21[3];
        *(undefined4 *)(iVar36 + 0x30) = *puVar21;
        *(undefined4 *)(iVar36 + 0x34) = uVar38;
        *(undefined4 *)(iVar36 + 0x38) = uVar39;
        *(undefined4 *)(iVar36 + 0x3c) = uVar40;
        *(undefined8 *)(puVar33 + -8) = 0x1800e3f64;
        piVar25 = (int64_t *)func_0x0001800cc970(arg1 + 0x490, &var_20h);
        *piVar25 = iVar36;
    }
    *(int64_t **)arg2 = piVar20;
    *(int64_t *)(arg2 + 8) = var_f0h;
    iVar30 = iVar18 * 0x30 + *(int64_t *)var_108h;
    if (iVar30 != *(int64_t *)(var_108h + 8)) {
        *(int64_t *)(var_108h + 8) = iVar30;
    }
    return arg2;
}

// ============================================================
// Function: FUN_1800e3fd0
// Address: 0x1800e3fd0
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800e3fd0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    var_8h = func_0x0001800e9350(arg1, 0);
    func_0x0001800bf890(*(undefined8 *)arg2, &var_8h);
    *(int64_t *)(arg2 + 0x10) = *(int64_t *)(arg2 + 0x10) + 1;
    iVar1 = *(int32_t *)(arg1 + 0x80);
    while( true ) {
        if (iVar1 != 0x2c) {
            return;
        }
        if (arg3 != 0) {
            func_0x0001800f1a70(arg3, arg1 + 0x84);
        }
        func_0x0001800f0350(arg1);
        if (*(int32_t *)(arg1 + 0x80) == 0x29) break;
        var_8h = func_0x0001800e9350(arg1, 0);
        func_0x0001800bf890(*(undefined8 *)arg2);
        *(int64_t *)(arg2 + 0x10) = *(int64_t *)(arg2 + 0x10) + 1;
        iVar1 = *(int32_t *)(arg1 + 0x80);
    }
    func_0x0001800efe70(arg1, arg1 + 0x84, 0x1806433c8);
    return;
}

// ============================================================
// Function: FUN_1800e400e
// Address: 0x1800e400e
// Size: 108 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800e3fd0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    var_8h = func_0x0001800e9350(arg1, 0);
    func_0x0001800bf890(*(undefined8 *)arg2, &var_8h);
    *(int64_t *)(arg2 + 0x10) = *(int64_t *)(arg2 + 0x10) + 1;
    iVar1 = *(int32_t *)(arg1 + 0x80);
    while( true ) {
        if (iVar1 != 0x2c) {
            return;
        }
        if (arg3 != 0) {
            func_0x0001800f1a70(arg3, arg1 + 0x84);
        }
        func_0x0001800f0350(arg1);
        if (*(int32_t *)(arg1 + 0x80) == 0x29) break;
        var_8h = func_0x0001800e9350(arg1, 0);
        func_0x0001800bf890(*(undefined8 *)arg2);
        *(int64_t *)(arg2 + 0x10) = *(int64_t *)(arg2 + 0x10) + 1;
        iVar1 = *(int32_t *)(arg1 + 0x80);
    }
    func_0x0001800efe70(arg1, arg1 + 0x84, 0x1806433c8);
    return;
}

// ============================================================
// Function: FUN_1800e407a
// Address: 0x1800e407a
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800e3fd0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    var_8h = func_0x0001800e9350(arg1, 0);
    func_0x0001800bf890(*(undefined8 *)arg2, &var_8h);
    *(int64_t *)(arg2 + 0x10) = *(int64_t *)(arg2 + 0x10) + 1;
    iVar1 = *(int32_t *)(arg1 + 0x80);
    while( true ) {
        if (iVar1 != 0x2c) {
            return;
        }
        if (arg3 != 0) {
            func_0x0001800f1a70(arg3, arg1 + 0x84);
        }
        func_0x0001800f0350(arg1);
        if (*(int32_t *)(arg1 + 0x80) == 0x29) break;
        var_8h = func_0x0001800e9350(arg1, 0);
        func_0x0001800bf890(*(undefined8 *)arg2);
        *(int64_t *)(arg2 + 0x10) = *(int64_t *)(arg2 + 0x10) + 1;
        iVar1 = *(int32_t *)(arg1 + 0x80);
    }
    func_0x0001800efe70(arg1, arg1 + 0x84, 0x1806433c8);
    return;
}

// ============================================================
// Function: FUN_1800e4090
// Address: 0x1800e4090
// Size: 35 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1800e4090(int64_t arg1, int64_t arg2)
{
    char cVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined8 *puVar7;
    undefined8 uVar8;
    undefined8 uVar9;
    undefined in_R8B;
    undefined4 uVar10;
    undefined4 uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    undefined4 uStack_60;
    undefined4 uStack_5c;
    int64_t var_58h;
    int64_t var_50h;
    undefined4 uStack_48;
    undefined4 uStack_44;
    int64_t var_38h;
    int64_t var_28h;
    
    if (*(int32_t *)(arg1 + 0x80) == 0x119) {
        var_50h._0_4_ = *(undefined4 *)(arg1 + 0x84);
        var_50h._4_4_ = *(undefined4 *)(arg1 + 0x88);
        uVar10 = *(undefined4 *)(arg1 + 0x8c);
        uVar11 = *(undefined4 *)(arg1 + 0x90);
        var_58h = *(int64_t *)(arg1 + 0x98);
        uStack_48 = uVar10;
        uStack_44 = uVar11;
        func_0x0001800f0350();
    } else {
        func_0x0001800efe90(arg1, 0x180642ae8);
        var_50h._0_4_ = *(undefined4 *)(arg1 + 0x84);
        var_50h._4_4_ = *(undefined4 *)(arg1 + 0x88);
        uVar10 = *(undefined4 *)(arg1 + 0x8c);
        uVar11 = *(undefined4 *)(arg1 + 0x90);
        var_58h = *(int64_t *)(arg1 + 0x128);
        uStack_48 = uVar10;
        uStack_44 = uVar11;
    }
    uVar6 = var_50h._4_4_;
    uVar5 = (undefined4)var_50h;
    uVar3 = (undefined4)var_58h;
    uVar4 = var_58h._4_4_;
    if (*(int32_t *)(arg1 + 0x80) == 0x3a) {
        uVar9 = *(undefined8 *)(arg1 + 0x84);
        func_0x0001800f0350(arg1);
        var_68h._0_4_ = *(undefined4 *)(arg1 + 0x84);
        var_68h._4_4_ = *(undefined4 *)(arg1 + 0x88);
        uStack_60 = *(undefined4 *)(arg1 + 0x8c);
        uStack_5c = *(undefined4 *)(arg1 + 0x90);
        uVar8 = 0;
        uVar2 = *(undefined4 *)(arg1 + 0x114);
        if ((*(int32_t *)(arg1 + 0x80) != 0x7c) && (*(int32_t *)(arg1 + 0x80) != 0x26)) {
            puVar7 = (undefined8 *)func_0x0001800e81c0(arg1, &var_58h, 0, 0);
            uVar8 = *puVar7;
            *(undefined4 *)(arg1 + 0x114) = uVar2;
        }
        uVar8 = func_0x0001800e7930(arg1, uVar8, &var_68h);
        *(undefined4 *)(arg1 + 0x114) = uVar2;
    } else {
        uVar9 = 0xffffffffffffffff;
        uVar8 = 0;
    }
    cVar1 = *(char *)(arg1 + 0x58);
    *(undefined4 *)arg2 = uVar3;
    *(undefined4 *)(arg2 + 4) = uVar4;
    *(undefined4 *)(arg2 + 8) = uVar5;
    *(undefined4 *)(arg2 + 0xc) = uVar6;
    *(uint64_t *)(arg2 + 0x10) = CONCAT44(uVar11, uVar10);
    if (cVar1 == '\0') {
        *(undefined8 *)(arg2 + 0x20) = 0xffffffffffffffff;
    } else {
        *(undefined8 *)(arg2 + 0x20) = uVar9;
    }
    *(undefined8 *)(arg2 + 0x18) = uVar8;
    *(undefined *)(arg2 + 0x28) = in_R8B;
    return arg2;
}

// ============================================================
// Function: FUN_1800e40b3
// Address: 0x1800e40b3
// Size: 125 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1800e4090(int64_t arg1, int64_t arg2)
{
    char cVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined8 *puVar7;
    undefined8 uVar8;
    undefined8 uVar9;
    undefined in_R8B;
    undefined4 uVar10;
    undefined4 uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    undefined4 uStack_60;
    undefined4 uStack_5c;
    int64_t var_58h;
    int64_t var_50h;
    undefined4 uStack_48;
    undefined4 uStack_44;
    int64_t var_38h;
    int64_t var_28h;
    
    if (*(int32_t *)(arg1 + 0x80) == 0x119) {
        var_50h._0_4_ = *(undefined4 *)(arg1 + 0x84);
        var_50h._4_4_ = *(undefined4 *)(arg1 + 0x88);
        uVar10 = *(undefined4 *)(arg1 + 0x8c);
        uVar11 = *(undefined4 *)(arg1 + 0x90);
        var_58h = *(int64_t *)(arg1 + 0x98);
        uStack_48 = uVar10;
        uStack_44 = uVar11;
        func_0x0001800f0350();
    } else {
        func_0x0001800efe90(arg1, 0x180642ae8);
        var_50h._0_4_ = *(undefined4 *)(arg1 + 0x84);
        var_50h._4_4_ = *(undefined4 *)(arg1 + 0x88);
        uVar10 = *(undefined4 *)(arg1 + 0x8c);
        uVar11 = *(undefined4 *)(arg1 + 0x90);
        var_58h = *(int64_t *)(arg1 + 0x128);
        uStack_48 = uVar10;
        uStack_44 = uVar11;
    }
    uVar6 = var_50h._4_4_;
    uVar5 = (undefined4)var_50h;
    uVar3 = (undefined4)var_58h;
    uVar4 = var_58h._4_4_;
    if (*(int32_t *)(arg1 + 0x80) == 0x3a) {
        uVar9 = *(undefined8 *)(arg1 + 0x84);
        func_0x0001800f0350(arg1);
        var_68h._0_4_ = *(undefined4 *)(arg1 + 0x84);
        var_68h._4_4_ = *(undefined4 *)(arg1 + 0x88);
        uStack_60 = *(undefined4 *)(arg1 + 0x8c);
        uStack_5c = *(undefined4 *)(arg1 + 0x90);
        uVar8 = 0;
        uVar2 = *(undefined4 *)(arg1 + 0x114);
        if ((*(int32_t *)(arg1 + 0x80) != 0x7c) && (*(int32_t *)(arg1 + 0x80) != 0x26)) {
            puVar7 = (undefined8 *)func_0x0001800e81c0(arg1, &var_58h, 0, 0);
            uVar8 = *puVar7;
            *(undefined4 *)(arg1 + 0x114) = uVar2;
        }
        uVar8 = func_0x0001800e7930(arg1, uVar8, &var_68h);
        *(undefined4 *)(arg1 + 0x114) = uVar2;
    } else {
        uVar9 = 0xffffffffffffffff;
        uVar8 = 0;
    }
    cVar1 = *(char *)(arg1 + 0x58);
    *(undefined4 *)arg2 = uVar3;
    *(undefined4 *)(arg2 + 4) = uVar4;
    *(undefined4 *)(arg2 + 8) = uVar5;
    *(undefined4 *)(arg2 + 0xc) = uVar6;
    *(uint64_t *)(arg2 + 0x10) = CONCAT44(uVar11, uVar10);
    if (cVar1 == '\0') {
        *(undefined8 *)(arg2 + 0x20) = 0xffffffffffffffff;
    } else {
        *(undefined8 *)(arg2 + 0x20) = uVar9;
    }
    *(undefined8 *)(arg2 + 0x18) = uVar8;
    *(undefined *)(arg2 + 0x28) = in_R8B;
    return arg2;
}

// ============================================================
// Function: FUN_1800e4130
// Address: 0x1800e4130
// Size: 103 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1800e4090(int64_t arg1, int64_t arg2)
{
    char cVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined8 *puVar7;
    undefined8 uVar8;
    undefined8 uVar9;
    undefined in_R8B;
    undefined4 uVar10;
    undefined4 uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    undefined4 uStack_60;
    undefined4 uStack_5c;
    int64_t var_58h;
    int64_t var_50h;
    undefined4 uStack_48;
    undefined4 uStack_44;
    int64_t var_38h;
    int64_t var_28h;
    
    if (*(int32_t *)(arg1 + 0x80) == 0x119) {
        var_50h._0_4_ = *(undefined4 *)(arg1 + 0x84);
        var_50h._4_4_ = *(undefined4 *)(arg1 + 0x88);
        uVar10 = *(undefined4 *)(arg1 + 0x8c);
        uVar11 = *(undefined4 *)(arg1 + 0x90);
        var_58h = *(int64_t *)(arg1 + 0x98);
        uStack_48 = uVar10;
        uStack_44 = uVar11;
        func_0x0001800f0350();
    } else {
        func_0x0001800efe90(arg1, 0x180642ae8);
        var_50h._0_4_ = *(undefined4 *)(arg1 + 0x84);
        var_50h._4_4_ = *(undefined4 *)(arg1 + 0x88);
        uVar10 = *(undefined4 *)(arg1 + 0x8c);
        uVar11 = *(undefined4 *)(arg1 + 0x90);
        var_58h = *(int64_t *)(arg1 + 0x128);
        uStack_48 = uVar10;
        uStack_44 = uVar11;
    }
    uVar6 = var_50h._4_4_;
    uVar5 = (undefined4)var_50h;
    uVar3 = (undefined4)var_58h;
    uVar4 = var_58h._4_4_;
    if (*(int32_t *)(arg1 + 0x80) == 0x3a) {
        uVar9 = *(undefined8 *)(arg1 + 0x84);
        func_0x0001800f0350(arg1);
        var_68h._0_4_ = *(undefined4 *)(arg1 + 0x84);
        var_68h._4_4_ = *(undefined4 *)(arg1 + 0x88);
        uStack_60 = *(undefined4 *)(arg1 + 0x8c);
        uStack_5c = *(undefined4 *)(arg1 + 0x90);
        uVar8 = 0;
        uVar2 = *(undefined4 *)(arg1 + 0x114);
        if ((*(int32_t *)(arg1 + 0x80) != 0x7c) && (*(int32_t *)(arg1 + 0x80) != 0x26)) {
            puVar7 = (undefined8 *)func_0x0001800e81c0(arg1, &var_58h, 0, 0);
            uVar8 = *puVar7;
            *(undefined4 *)(arg1 + 0x114) = uVar2;
        }
        uVar8 = func_0x0001800e7930(arg1, uVar8, &var_68h);
        *(undefined4 *)(arg1 + 0x114) = uVar2;
    } else {
        uVar9 = 0xffffffffffffffff;
        uVar8 = 0;
    }
    cVar1 = *(char *)(arg1 + 0x58);
    *(undefined4 *)arg2 = uVar3;
    *(undefined4 *)(arg2 + 4) = uVar4;
    *(undefined4 *)(arg2 + 8) = uVar5;
    *(undefined4 *)(arg2 + 0xc) = uVar6;
    *(uint64_t *)(arg2 + 0x10) = CONCAT44(uVar11, uVar10);
    if (cVar1 == '\0') {
        *(undefined8 *)(arg2 + 0x20) = 0xffffffffffffffff;
    } else {
        *(undefined8 *)(arg2 + 0x20) = uVar9;
    }
    *(undefined8 *)(arg2 + 0x18) = uVar8;
    *(undefined *)(arg2 + 0x28) = in_R8B;
    return arg2;
}

// ============================================================
// Function: FUN_1800e4197
// Address: 0x1800e4197
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1800e4090(int64_t arg1, int64_t arg2)
{
    char cVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined8 *puVar7;
    undefined8 uVar8;
    undefined8 uVar9;
    undefined in_R8B;
    undefined4 uVar10;
    undefined4 uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    undefined4 uStack_60;
    undefined4 uStack_5c;
    int64_t var_58h;
    int64_t var_50h;
    undefined4 uStack_48;
    undefined4 uStack_44;
    int64_t var_38h;
    int64_t var_28h;
    
    if (*(int32_t *)(arg1 + 0x80) == 0x119) {
        var_50h._0_4_ = *(undefined4 *)(arg1 + 0x84);
        var_50h._4_4_ = *(undefined4 *)(arg1 + 0x88);
        uVar10 = *(undefined4 *)(arg1 + 0x8c);
        uVar11 = *(undefined4 *)(arg1 + 0x90);
        var_58h = *(int64_t *)(arg1 + 0x98);
        uStack_48 = uVar10;
        uStack_44 = uVar11;
        func_0x0001800f0350();
    } else {
        func_0x0001800efe90(arg1, 0x180642ae8);
        var_50h._0_4_ = *(undefined4 *)(arg1 + 0x84);
        var_50h._4_4_ = *(undefined4 *)(arg1 + 0x88);
        uVar10 = *(undefined4 *)(arg1 + 0x8c);
        uVar11 = *(undefined4 *)(arg1 + 0x90);
        var_58h = *(int64_t *)(arg1 + 0x128);
        uStack_48 = uVar10;
        uStack_44 = uVar11;
    }
    uVar6 = var_50h._4_4_;
    uVar5 = (undefined4)var_50h;
    uVar3 = (undefined4)var_58h;
    uVar4 = var_58h._4_4_;
    if (*(int32_t *)(arg1 + 0x80) == 0x3a) {
        uVar9 = *(undefined8 *)(arg1 + 0x84);
        func_0x0001800f0350(arg1);
        var_68h._0_4_ = *(undefined4 *)(arg1 + 0x84);
        var_68h._4_4_ = *(undefined4 *)(arg1 + 0x88);
        uStack_60 = *(undefined4 *)(arg1 + 0x8c);
        uStack_5c = *(undefined4 *)(arg1 + 0x90);
        uVar8 = 0;
        uVar2 = *(undefined4 *)(arg1 + 0x114);
        if ((*(int32_t *)(arg1 + 0x80) != 0x7c) && (*(int32_t *)(arg1 + 0x80) != 0x26)) {
            puVar7 = (undefined8 *)func_0x0001800e81c0(arg1, &var_58h, 0, 0);
            uVar8 = *puVar7;
            *(undefined4 *)(arg1 + 0x114) = uVar2;
        }
        uVar8 = func_0x0001800e7930(arg1, uVar8, &var_68h);
        *(undefined4 *)(arg1 + 0x114) = uVar2;
    } else {
        uVar9 = 0xffffffffffffffff;
        uVar8 = 0;
    }
    cVar1 = *(char *)(arg1 + 0x58);
    *(undefined4 *)arg2 = uVar3;
    *(undefined4 *)(arg2 + 4) = uVar4;
    *(undefined4 *)(arg2 + 8) = uVar5;
    *(undefined4 *)(arg2 + 0xc) = uVar6;
    *(uint64_t *)(arg2 + 0x10) = CONCAT44(uVar11, uVar10);
    if (cVar1 == '\0') {
        *(undefined8 *)(arg2 + 0x20) = 0xffffffffffffffff;
    } else {
        *(undefined8 *)(arg2 + 0x20) = uVar9;
    }
    *(undefined8 *)(arg2 + 0x18) = uVar8;
    *(undefined *)(arg2 + 0x28) = in_R8B;
    return arg2;
}

// ============================================================
// Function: FUN_1800e41c6
// Address: 0x1800e41c6
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1800e4090(int64_t arg1, int64_t arg2)
{
    char cVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined8 *puVar7;
    undefined8 uVar8;
    undefined8 uVar9;
    undefined in_R8B;
    undefined4 uVar10;
    undefined4 uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    undefined4 uStack_60;
    undefined4 uStack_5c;
    int64_t var_58h;
    int64_t var_50h;
    undefined4 uStack_48;
    undefined4 uStack_44;
    int64_t var_38h;
    int64_t var_28h;
    
    if (*(int32_t *)(arg1 + 0x80) == 0x119) {
        var_50h._0_4_ = *(undefined4 *)(arg1 + 0x84);
        var_50h._4_4_ = *(undefined4 *)(arg1 + 0x88);
        uVar10 = *(undefined4 *)(arg1 + 0x8c);
        uVar11 = *(undefined4 *)(arg1 + 0x90);
        var_58h = *(int64_t *)(arg1 + 0x98);
        uStack_48 = uVar10;
        uStack_44 = uVar11;
        func_0x0001800f0350();
    } else {
        func_0x0001800efe90(arg1, 0x180642ae8);
        var_50h._0_4_ = *(undefined4 *)(arg1 + 0x84);
        var_50h._4_4_ = *(undefined4 *)(arg1 + 0x88);
        uVar10 = *(undefined4 *)(arg1 + 0x8c);
        uVar11 = *(undefined4 *)(arg1 + 0x90);
        var_58h = *(int64_t *)(arg1 + 0x128);
        uStack_48 = uVar10;
        uStack_44 = uVar11;
    }
    uVar6 = var_50h._4_4_;
    uVar5 = (undefined4)var_50h;
    uVar3 = (undefined4)var_58h;
    uVar4 = var_58h._4_4_;
    if (*(int32_t *)(arg1 + 0x80) == 0x3a) {
        uVar9 = *(undefined8 *)(arg1 + 0x84);
        func_0x0001800f0350(arg1);
        var_68h._0_4_ = *(undefined4 *)(arg1 + 0x84);
        var_68h._4_4_ = *(undefined4 *)(arg1 + 0x88);
        uStack_60 = *(undefined4 *)(arg1 + 0x8c);
        uStack_5c = *(undefined4 *)(arg1 + 0x90);
        uVar8 = 0;
        uVar2 = *(undefined4 *)(arg1 + 0x114);
        if ((*(int32_t *)(arg1 + 0x80) != 0x7c) && (*(int32_t *)(arg1 + 0x80) != 0x26)) {
            puVar7 = (undefined8 *)func_0x0001800e81c0(arg1, &var_58h, 0, 0);
            uVar8 = *puVar7;
            *(undefined4 *)(arg1 + 0x114) = uVar2;
        }
        uVar8 = func_0x0001800e7930(arg1, uVar8, &var_68h);
        *(undefined4 *)(arg1 + 0x114) = uVar2;
    } else {
        uVar9 = 0xffffffffffffffff;
        uVar8 = 0;
    }
    cVar1 = *(char *)(arg1 + 0x58);
    *(undefined4 *)arg2 = uVar3;
    *(undefined4 *)(arg2 + 4) = uVar4;
    *(undefined4 *)(arg2 + 8) = uVar5;
    *(undefined4 *)(arg2 + 0xc) = uVar6;
    *(uint64_t *)(arg2 + 0x10) = CONCAT44(uVar11, uVar10);
    if (cVar1 == '\0') {
        *(undefined8 *)(arg2 + 0x20) = 0xffffffffffffffff;
    } else {
        *(undefined8 *)(arg2 + 0x20) = uVar9;
    }
    *(undefined8 *)(arg2 + 0x18) = uVar8;
    *(undefined *)(arg2 + 0x28) = in_R8B;
    return arg2;
}

// ============================================================
// Function: FUN_1800e4200
// Address: 0x1800e4200
// Size: 309 bytes
// ============================================================
int64_t fcn.1800e4200(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    var_68h = arg1 + 0x440;
    var_60h = *(int64_t *)(arg1 + 0x448) - *(int64_t *)var_68h >> 3;
    uVar7 = 0;
    var_58h = 0;
    uVar8 = uVar7;
    if (*(int64_t *)(arg3 + 0x10) != 0) {
        do {
            func_0x0001800f1a70(&var_68h, (*(int64_t *)(arg3 + 8) + uVar8) * 0x30 + **(int64_t **)arg3 + 0x20);
            uVar8 = uVar8 + 1;
        } while (uVar8 < *(uint64_t *)(arg3 + 0x10));
    }
    iVar6 = var_58h;
    iVar2 = var_60h;
    iVar5 = var_68h;
    *(undefined8 *)arg2 = 0;
    if (var_58h == 0) {
        *(undefined8 *)(arg2 + 8) = 0;
    } else {
        iVar4 = *(int64_t *)var_68h;
        *(undefined8 *)(arg2 + 8) = 0;
        iVar3 = var_58h * 8;
        uVar8 = func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), iVar3);
        *(uint64_t *)arg2 = uVar8;
        *(int64_t *)(arg2 + 8) = iVar6;
        if (iVar6 != 0) {
            uVar1 = iVar4 + iVar2 * 8;
            if (((uint64_t)iVar6 < 2) || ((uVar8 <= (uVar1 - 8) + iVar3 && (uVar1 <= (uVar8 - 8) + iVar3)))) {
                do {
                    *(undefined8 *)(uVar8 + uVar7 * 8) = *(undefined8 *)(uVar1 + uVar7 * 8);
                    uVar7 = uVar7 + 1;
                } while (uVar7 < (uint64_t)iVar6);
            } else {
                func_0x000180498030(uVar8, uVar1, iVar3);
            }
        }
    }
    iVar2 = *(int64_t *)iVar5 + iVar2 * 8;
    if (iVar2 != *(int64_t *)(iVar5 + 8)) {
        *(int64_t *)(iVar5 + 8) = iVar2;
    }
    return arg2;
}

// ============================================================
// Function: FUN_1800e4340
// Address: 0x1800e4340
// Size: 1236 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_6fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_87h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Removing arg arg_4fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_51h
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel

int64_t fcn.1800e4340(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    int64_t iVar2;
    undefined4 uVar3;
    int64_t **ppiVar4;
    int64_t iVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    uint64_t *puVar12;
    uint64_t uVar13;
    int32_t *piVar14;
    int64_t *piVar15;
    undefined8 uVar16;
    undefined8 *puVar17;
    int64_t iVar18;
    int64_t *piVar19;
    uint64_t uVar20;
    uint64_t uVar21;
    char in_R9B;
    uint64_t *in_stack_00000028;
    int64_t in_stack_00000030;
    int64_t *in_stack_00000038;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    undefined4 uStack_c0;
    undefined4 uStack_bc;
    int64_t *piStack_b8;
    int64_t iStack_b0;
    uint64_t uStack_a8;
    undefined8 uStack_a0;
    int64_t iStack_98;
    int64_t iStack_90;
    int64_t var_79h;
    int64_t var_71h;
    int64_t var_69h;
    int64_t var_61h;
    int64_t var_59h;
    int64_t var_49h;
    
    puVar12 = in_stack_00000028;
    piStack_b8 = (int64_t *)(arg1 + 0x440);
    iStack_b0 = *(int64_t *)(arg1 + 0x448) - *piStack_b8 >> 3;
    uStack_a8 = 0;
    if ((in_stack_00000028 != (uint64_t *)0x0) && (in_stack_00000030 != 0)) {
        func_0x0001800f1a70(&piStack_b8);
    }
    while ((piVar19 = (int64_t *)(arg1 + 0x84), *(int32_t *)(arg1 + 0x80) != 0x106 || (in_R9B == '\0'))) {
        fcn.1800e4090(arg1, (int64_t)&uStack_a0);
        func_0x0001800f1c30(arg3);
        uVar13 = uStack_a8;
        iVar2 = iStack_b0;
        piVar19 = piStack_b8;
        if (*(int32_t *)(arg1 + 0x80) != 0x2c) {
            if (in_stack_00000028 != (uint64_t *)0x0) {
                if (uStack_a8 == 0) {
                    uVar20 = 0;
                } else {
                    iVar5 = *piStack_b8;
                    iVar18 = uStack_a8 * 8;
                    uVar20 = func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), iVar18);
                    if (uVar13 != 0) {
                        uVar1 = iVar5 + iVar2 * 8;
                        uVar21 = 0;
                        if ((uVar13 < 2) ||
                           ((uVar20 <= uVar1 + (uVar13 - 1) * 8 && (uVar1 <= uVar20 + (uVar13 - 1) * 8)))) {
                            do {
                                *(undefined8 *)(uVar20 + uVar21 * 8) = *(undefined8 *)(uVar1 + uVar21 * 8);
                                uVar21 = uVar21 + 1;
                            } while (uVar21 < uVar13);
                        } else {
                            func_0x000180498030(uVar20, uVar1, iVar18);
                        }
                    }
                }
                *in_stack_00000028 = uVar20;
                in_stack_00000028[1] = uVar13;
            }
            *(undefined8 *)arg2 = 0;
            *(undefined8 *)(arg2 + 8) = 0;
            *(undefined8 *)(arg2 + 0x10) = 0;
            *(undefined *)(arg2 + 0x18) = 0;
            iVar2 = *piVar19 + iVar2 * 8;
            if (iVar2 != piVar19[1]) {
                piVar19[1] = iVar2;
            }
            return arg2;
        }
        if (puVar12 != (uint64_t *)0x0) {
            func_0x0001800f1a70(&piStack_b8);
        }
        func_0x0001800f0350(arg1);
    }
    uVar8 = *(undefined4 *)piVar19;
    uVar9 = *(undefined4 *)(arg1 + 0x88);
    uVar10 = *(undefined4 *)(arg1 + 0x8c);
    uVar11 = *(undefined4 *)(arg1 + 0x90);
    func_0x0001800f0350(arg1);
    piVar15 = (int64_t *)0x0;
    if (*(int32_t *)(arg1 + 0x80) != 0x3a) goto code_r0x0001800e4651;
    if (in_stack_00000038 != (int64_t *)0x0) {
        *in_stack_00000038 = *piVar19;
    }
    func_0x0001800f0350(arg1);
    if ((*(int32_t *)(arg1 + 0x80) == 0x119) &&
       (piVar14 = (int32_t *)func_0x0001800d70e0(arg1 + 0x60, &uStack_a0), *piVar14 == 0x106)) {
        if (*(int32_t *)(arg1 + 0x80) == 0x119) {
            uStack_a0 = *(undefined8 *)(arg1 + 0x98);
            iStack_98 = *piVar19;
            iVar2 = *(int64_t *)(arg1 + 0x8c);
            iStack_90 = iVar2;
            func_0x0001800f0350(arg1);
            iStack_90 = iVar2;
        } else {
            func_0x0001800efe90(arg1, 0x1806438e0);
            iStack_98 = *piVar19;
            var_d8h = *piVar19;
            uStack_a0 = *(undefined8 *)(arg1 + 0x128);
            var_d0h = var_d8h;
            iStack_90 = *piVar19;
        }
        var_c8h._0_4_ = *(undefined4 *)piVar19;
        var_c8h._4_4_ = *(undefined4 *)(arg1 + 0x88);
        uStack_c0 = *(undefined4 *)(arg1 + 0x8c);
        uStack_bc = *(undefined4 *)(arg1 + 0x90);
        if (*(int32_t *)(arg1 + 0x80) == 0x106) {
            func_0x0001800f0350(arg1);
        } else {
            func_0x0001800ef2a0(arg1, 0x106, 0x1806438f0);
        }
        var_d8h = iStack_98;
        var_d0h = CONCAT44(uStack_bc, uStack_c0);
        piVar15 = (int64_t *)func_0x0001800f1710(*(undefined8 *)(arg1 + 0xd8), &var_d8h);
        if (*(char *)(arg1 + 0x58) != '\0') {
            uVar16 = func_0x0001800f17c0(*(undefined8 *)(arg1 + 0xd8), &var_c8h);
            in_stack_00000028 = (uint64_t *)piVar15;
            puVar17 = (undefined8 *)func_0x0001800cc970(arg1 + 0x490, &stack0x00000028);
            *puVar17 = uVar16;
        }
        goto code_r0x0001800e4651;
    }
    uVar3 = *(undefined4 *)(arg1 + 0x114);
    var_c8h._0_4_ = *(undefined4 *)piVar19;
    var_c8h._4_4_ = *(undefined4 *)(arg1 + 0x88);
    uStack_c0 = *(undefined4 *)(arg1 + 0x8c);
    uStack_bc = *(undefined4 *)(arg1 + 0x90);
    uVar16 = 0;
    if ((*(int32_t *)(arg1 + 0x80) != 0x7c) && (*(int32_t *)(arg1 + 0x80) != 0x26)) {
        puVar17 = (undefined8 *)func_0x0001800e81c0(arg1, &var_d8h, 0, 0);
        uVar16 = *puVar17;
        *(undefined4 *)(arg1 + 0x114) = uVar3;
    }
    iVar18 = func_0x0001800e7930(arg1, uVar16);
    *(undefined4 *)(arg1 + 0x114) = uVar3;
    ppiVar4 = *(int64_t ***)(arg1 + 0xd8);
    iVar2 = (int64_t)*ppiVar4;
    if (iVar2 == 0) {
code_r0x0001800e4604:
        piVar15 = (int64_t *)func_0x000180459890(0x2008);
        *piVar15 = (int64_t)*ppiVar4;
        *ppiVar4 = piVar15;
        piVar15 = piVar15 + 1;
        piVar19 = (int64_t *)0x28;
    } else {
        piVar15 = (int64_t *)((int64_t)ppiVar4[1] + iVar2 + 0xf & 0xfffffffffffffff8);
        if ((int64_t *)(iVar2 + 0x2008) < piVar15 + 5) goto code_r0x0001800e4604;
        piVar19 = (int64_t *)((int64_t)piVar15 + (0x28 - (iVar2 + 8)));
    }
    ppiVar4[1] = piVar19;
    uVar3 = *(undefined4 *)0x180782688;
    *piVar15 = 0x180642298;
    *(undefined4 *)(piVar15 + 1) = uVar3;
    uVar3 = *(undefined4 *)(iVar18 + 0x10);
    uVar6 = *(undefined4 *)(iVar18 + 0x14);
    uVar7 = *(undefined4 *)(iVar18 + 0x18);
    *(undefined4 *)((int64_t)piVar15 + 0xc) = *(undefined4 *)(iVar18 + 0xc);
    *(undefined4 *)(piVar15 + 2) = uVar3;
    *(undefined4 *)((int64_t)piVar15 + 0x14) = uVar6;
    *(undefined4 *)(piVar15 + 3) = uVar7;
    *piVar15 = 0x180642068;
    piVar15[4] = iVar18;
code_r0x0001800e4651:
    uVar13 = uStack_a8;
    piVar19 = piStack_b8;
    if (puVar12 != (uint64_t *)0x0) {
        if (uStack_a8 == 0) {
            uVar20 = 0;
        } else {
            in_stack_00000028 = (uint64_t *)*piStack_b8;
            uVar20 = func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), uStack_a8 * 8);
            if (uVar13 != 0) {
                uVar1 = (int64_t)in_stack_00000028 + iStack_b0 * 8;
                uVar21 = 0;
                if ((uVar13 < 2) || ((uVar20 <= uVar1 + (uVar13 - 1) * 8 && (uVar1 <= uVar20 + (uVar13 - 1) * 8)))) {
                    do {
                        *(undefined8 *)(uVar20 + uVar21 * 8) = *(undefined8 *)(uVar1 + uVar21 * 8);
                        uVar21 = uVar21 + 1;
                    } while (uVar21 < uVar13);
                } else {
                    func_0x000180498030(uVar20, uVar1, uVar13 * 8);
                }
            }
        }
        *puVar12 = uVar20;
        puVar12[1] = uVar13;
    }
    *(int64_t **)arg2 = piVar15;
    *(undefined4 *)(arg2 + 8) = uVar8;
    *(undefined4 *)(arg2 + 0xc) = uVar9;
    *(undefined4 *)(arg2 + 0x10) = uVar10;
    *(undefined4 *)(arg2 + 0x14) = uVar11;
    *(undefined *)(arg2 + 0x18) = 1;
    iVar2 = *piVar19 + iStack_b0 * 8;
    if (iVar2 == piVar19[1]) {
        return arg2;
    }
    piVar19[1] = iVar2;
    return arg2;
}

// ============================================================
// Function: FUN_1800e4820
// Address: 0x1800e4820
// Size: 198 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h

undefined8 fcn.1800e4820(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (*(int32_t *)(arg1 + 0x80) != 0x3a) {
        if (*(int32_t *)(arg1 + 0x80) != 0x107) {
            return 0;
        }
        fcn.1800efe70(arg1, arg1 + 0x84, 0x180643430);
    }
    if (arg2 != 0) {
        *(undefined8 *)arg2 = *(undefined8 *)(arg1 + 0x84);
    }
    fcn.1800f0350(arg1);
    uVar1 = *(undefined4 *)(arg1 + 0x114);
    uVar2 = fcn.1800e48f0(arg1);
    if (*(int32_t *)(arg1 + 0x80) == 0x2c) {
        fcn.1800efe70(arg1, arg1 + 0x84, 0x180643660);
        fcn.1800f0350(arg1);
    }
    *(undefined4 *)(arg1 + 0x114) = uVar1;
    return uVar2;
}

// ============================================================
// Function: FUN_1800e48f0
// Address: 0x1800e48f0
// Size: 4015 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_198h
// WARNING: Variable defined which should be unmapped: var_190h
// WARNING: Variable defined which should be unmapped: var_188h
// WARNING: Variable defined which should be unmapped: var_180h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

int64_t ** fcn.1800e48f0(int64_t arg1)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    char cVar7;
    int32_t *piVar8;
    int64_t iVar9;
    int64_t *piVar10;
    undefined8 uVar11;
    undefined8 *puVar12;
    int64_t **ppiVar13;
    int64_t iVar14;
    uint64_t uVar15;
    undefined8 *puVar16;
    uint64_t uVar17;
    uint64_t uVar18;
    int64_t iVar19;
    int64_t **ppiVar20;
    uint64_t uVar21;
    int64_t *piVar22;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    undefined4 var_130h;
    undefined4 uStack_12c;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    undefined4 uStack_60;
    undefined4 uStack_5c;
    int64_t var_58h;
    undefined4 uStack_50;
    undefined4 uStack_4c;
    
    *(int32_t *)(arg1 + 0x114) = *(int32_t *)(arg1 + 0x114) + 1;
    if (*(uint32_t *)0x180778500 < *(uint32_t *)(arg1 + 0x114)) {
        iVar19 = func_0x0001800d90d0(arg1 + 0x60);
        func_0x0001800d9940(iVar19 + 4, 0x180644050, 0x1806436c0);
        pcVar3 = (code *)swi(3);
        ppiVar13 = (int64_t **)(*pcVar3)();
        return ppiVar13;
    }
    var_68h._0_4_ = *(undefined4 *)(arg1 + 0x80);
    var_68h._4_4_ = *(undefined4 *)(arg1 + 0x84);
    uStack_60 = *(undefined4 *)(arg1 + 0x88);
    uStack_5c = *(undefined4 *)(arg1 + 0x8c);
    var_58h._0_4_ = *(undefined4 *)(arg1 + 0x90);
    var_58h._4_4_ = *(undefined4 *)(arg1 + 0x94);
    uStack_50 = *(undefined4 *)(arg1 + 0x98);
    uStack_4c = *(undefined4 *)(arg1 + 0x9c);
    if (*(int32_t *)(arg1 + 0x80) == 0x28) {
        fcn.1800f0350();
        piVar8 = (int32_t *)(*(int64_t *)(arg1 + 0x1e8) + 0x41c);
        *piVar8 = *piVar8 + 1;
        var_8h = arg1 + 0x350;
        var_10h = *(int64_t *)(arg1 + 0x358) - *(int64_t *)var_8h >> 3;
        uVar21 = 0;
        var_e8h = 0;
        var_170h = arg1 + 0x428;
        var_168h = *(int64_t *)(arg1 + 0x430) - *(int64_t *)var_170h >> 5;
        var_160h = 0;
        var_118h = arg1 + 0x440;
        var_110h = *(int64_t *)(arg1 + 0x448) - *(int64_t *)var_118h >> 3;
        var_20h = 0;
        var_78h = 0;
        var_e0h = arg1 + 0x458;
        var_d8h = *(int64_t *)(arg1 + 0x460) - *(int64_t *)var_e0h >> 3;
        var_c0h = 0;
        var_18h = 0;
        uVar15 = uVar21;
        var_108h = var_168h;
        var_100h = var_170h;
        var_f8h = var_8h;
        var_f0h = var_10h;
        var_d0h = var_e0h;
        var_c8h = var_d8h;
        var_88h = var_118h;
        var_80h = var_110h;
        if (*(int32_t *)(arg1 + 0x80) != 0x29) {
            if (*(char *)(arg1 + 0x58) == '\0') {
                do {
                    uVar15 = var_e8h;
                    if ((*(int32_t *)(arg1 + 0x80) == 0x106) ||
                       ((*(int32_t *)(arg1 + 0x80) == 0x119 &&
                        (piVar8 = (int32_t *)func_0x0001800d70e0(arg1 + 0x60, &var_158h), *piVar8 == 0x106)))) {
                        var_18h = func_0x0001800e8e20(arg1);
                        goto code_r0x0001800e4f7c;
                    }
                    if ((*(int32_t *)(arg1 + 0x80) == 0x119) &&
                       (piVar8 = (int32_t *)func_0x0001800d70e0(arg1 + 0x60, &var_158h), *piVar8 == 0x3a)) {
                        while ((uint64_t)var_160h < uVar15) {
                            var_140h._0_1_ = 0;
                            func_0x0001800f1e20(&var_170h, &var_158h);
                        }
                        var_158h = *(int64_t *)(arg1 + 0x98);
                        var_b0h = *(int64_t *)(arg1 + 0x84);
                        var_150h = *(int64_t *)(arg1 + 0x84);
                        var_a0h._4_4_ = *(undefined4 *)(arg1 + 0x90);
                        var_148h = *(int64_t *)(arg1 + 0x8c);
                        var_a0h._1_3_ = (unkbyte3)((uint32_t)*(undefined4 *)(int64_t *)(arg1 + 0x8c) >> 8);
                        var_a0h._0_4_ = CONCAT31(var_a0h._1_3_, 1);
                        var_b8h = var_158h;
                        func_0x0001800f1e20(&var_170h, &var_b8h);
                        fcn.1800f0350(arg1);
                        if (*(int32_t *)(arg1 + 0x80) == 0x3a) {
                            fcn.1800f0350(arg1);
                        } else {
                            func_0x0001800ef2a0(arg1, 0x3a, 0);
                        }
                    } else if (var_160h != 0) {
                        var_140h._0_1_ = 0;
                        func_0x0001800f1e20(&var_170h, &var_158h);
                    }
                    var_8h = func_0x0001800e8150(arg1, 0);
                    func_0x0001800f1a70(&var_f8h);
                    if (*(int32_t *)(arg1 + 0x80) != 0x2c) goto code_r0x0001800e4f5a;
                    fcn.1800f0350(arg1);
                } while (*(int32_t *)(arg1 + 0x80) != 0x29);
                fcn.1800efe70(arg1, arg1 + 0x84, 0x180643400);
code_r0x0001800e4f5a:
                var_18h = 0;
                uVar15 = var_e8h;
code_r0x0001800e4f7c:
                var_108h = var_168h;
                var_100h = var_170h;
            } else {
                do {
                    uVar15 = var_e8h;
                    if ((*(int32_t *)(arg1 + 0x80) == 0x106) ||
                       ((*(int32_t *)(arg1 + 0x80) == 0x119 &&
                        (piVar8 = (int32_t *)func_0x0001800d70e0(arg1 + 0x60, &var_158h), *piVar8 == 0x106)))) {
                        var_18h = func_0x0001800e8e20(arg1);
                        goto code_r0x0001800e4d8e;
                    }
                    if ((*(int32_t *)(arg1 + 0x80) == 0x119) &&
                       (piVar8 = (int32_t *)func_0x0001800d70e0(arg1 + 0x60, &var_158h), *piVar8 == 0x3a)) {
                        while ((uint64_t)var_160h < uVar15) {
                            var_140h._0_1_ = 0;
                            func_0x0001800f1e20(&var_170h, &var_158h);
                        }
                        while ((uint64_t)var_c0h < uVar15) {
                            var_8h = -1;
                            func_0x0001800f1a70(&var_d0h, &var_8h);
                        }
                        var_158h = *(int64_t *)(arg1 + 0x98);
                        var_b0h = *(int64_t *)(arg1 + 0x84);
                        var_150h = *(int64_t *)(arg1 + 0x84);
                        var_a0h._4_4_ = *(undefined4 *)(arg1 + 0x90);
                        var_148h = *(int64_t *)(arg1 + 0x8c);
                        var_a0h._1_3_ = (unkbyte3)((uint32_t)*(undefined4 *)(int64_t *)(arg1 + 0x8c) >> 8);
                        var_a0h._0_4_ = CONCAT31(var_a0h._1_3_, 1);
                        var_b8h = var_158h;
                        func_0x0001800f1e20(&var_170h, &var_b8h);
                        fcn.1800f0350(arg1);
                        func_0x0001800f1a70(&var_d0h, arg1 + 0x84);
                        if (*(int32_t *)(arg1 + 0x80) == 0x3a) {
                            fcn.1800f0350(arg1);
                        } else {
                            func_0x0001800ef2a0(arg1, 0x3a, 0);
                        }
                    } else if (var_160h != 0) {
                        var_140h._0_1_ = 0;
                        func_0x0001800f1e20(&var_170h, &var_158h);
                        var_10h = -1;
                        func_0x0001800f1a70(&var_d0h, &var_10h);
                    }
                    var_18h = func_0x0001800e8150(arg1, 0);
                    func_0x0001800f1a70(&var_f8h, &var_18h);
                    if (*(int32_t *)(arg1 + 0x80) != 0x2c) goto code_r0x0001800e4d6c;
                    func_0x0001800f1a70(&var_88h);
                    fcn.1800f0350(arg1);
                } while (*(int32_t *)(arg1 + 0x80) != 0x29);
                fcn.1800efe70(arg1, arg1 + 0x84, 0x180643400);
code_r0x0001800e4d6c:
                var_18h = 0;
                uVar15 = var_e8h;
code_r0x0001800e4d8e:
                var_108h = var_168h;
                var_100h = var_170h;
                var_20h = var_78h;
                var_110h = var_80h;
                var_118h = var_88h;
                var_d8h = var_c8h;
                var_e0h = var_d0h;
            }
        }
        uVar5 = uStack_60;
        uVar4 = var_68h._4_4_;
        iVar14 = var_18h;
        iVar9 = CONCAT44(uStack_60, var_68h._4_4_);
        iVar19 = *(int64_t *)(arg1 + 0x8c);
        var_138h._0_4_ = (undefined4)var_68h;
        var_138h._4_4_ = var_68h._4_4_;
        var_130h = uStack_60;
        var_8h = var_f8h;
        var_10h = var_f0h;
        var_170h = var_100h;
        var_168h = var_108h;
        var_128h = iVar9;
        var_120h = iVar19;
        if (*(int32_t *)(arg1 + 0x80) == 0x29) {
            fcn.1800f0350(arg1);
            cVar7 = '\x01';
code_r0x0001800e5011:
            var_178h = *(int64_t *)(arg1 + 0xa0);
        } else {
            func_0x0001800ef5a0(arg1, 0x29, &var_138h, 0);
            cVar7 = func_0x0001800ef4e0(arg1, 0x29);
            if (cVar7 != '\0') goto code_r0x0001800e5011;
            var_178h = -1;
        }
        piVar8 = (int32_t *)(*(int64_t *)(arg1 + 0x1e8) + 0x41c);
        *piVar8 = *piVar8 + -1;
        if ((*(int32_t *)(arg1 + 0x80) == 0x107) || (var_160h != 0)) {
            uVar11 = *(undefined8 *)(arg1 + 0x84);
            uVar17 = uVar21;
            if (var_160h != 0) {
                iVar19 = var_108h * 0x20 + *(int64_t *)var_100h;
                uVar17 = func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), var_160h << 5);
                uVar18 = uVar21;
                if (var_160h != 0) {
                    do {
                        iVar14 = uVar18 * 0x20;
                        puVar1 = (undefined4 *)(iVar14 + iVar19);
                        uVar4 = puVar1[1];
                        uVar5 = puVar1[2];
                        uVar6 = puVar1[3];
                        puVar2 = (undefined4 *)(uVar17 + iVar14);
                        *puVar2 = *puVar1;
                        puVar2[1] = uVar4;
                        puVar2[2] = uVar5;
                        puVar2[3] = uVar6;
                        puVar1 = (undefined4 *)(iVar14 + 0x10 + iVar19);
                        uVar4 = puVar1[1];
                        uVar5 = puVar1[2];
                        uVar6 = puVar1[3];
                        puVar2 = (undefined4 *)(uVar17 + 0x10 + iVar14);
                        *puVar2 = *puVar1;
                        puVar2[1] = uVar4;
                        puVar2[2] = uVar5;
                        puVar2[3] = uVar6;
                        uVar18 = uVar18 + 1;
                    } while (uVar18 < (uint64_t)var_160h);
                }
            }
            uVar18 = uVar21;
            if (uVar15 != 0) {
                uVar18 = *(int64_t *)var_8h + var_10h * 8;
            }
            func_0x0001800f1110(arg1, &var_98h, uVar18, uVar15);
            var_b8h = 0;
            var_b0h = 0;
            var_138h._0_4_ = (undefined4)uVar17;
            var_138h._4_4_ = (undefined4)(uVar17 >> 0x20);
            var_130h = (undefined4)var_160h;
            uStack_12c = (undefined4)((uint64_t)var_160h >> 0x20);
            var_158h = var_98h;
            var_150h = var_90h;
            var_128h = 0;
            var_120h = 0;
            var_98h = 0;
            var_90h = 0;
            iVar19 = func_0x0001800e7620(arg1, &var_68h, &var_b8h, &var_98h, &var_128h, &var_158h, &var_138h, var_18h);
            iVar14 = var_20h;
            var_138h._0_4_ = (undefined4)iVar19;
            var_138h._4_4_ = (undefined4)((uint64_t)iVar19 >> 0x20);
            if ((*(char *)(arg1 + 0x58) != '\0') && (*(int32_t *)(iVar19 + 8) == *(int32_t *)0x1807826ac)) {
                var_128h = *(int64_t *)(arg1 + 0xd8);
                if (var_20h == 0) {
                    var_18h = 0;
                } else {
                    iVar19 = *(int64_t *)var_118h;
                    uVar15 = func_0x0001800d4d20(var_128h, var_20h * 8);
                    var_18h = uVar15;
                    if (iVar14 != 0) {
                        uVar17 = iVar19 + var_110h * 8;
                        uVar18 = uVar21;
                        if (((uint64_t)iVar14 < 2) ||
                           ((uVar15 <= uVar17 + (iVar14 + -1) * 8 && (uVar17 <= uVar15 + (iVar14 + -1) * 8)))) {
                            do {
                                *(undefined8 *)(uVar15 + uVar18 * 8) = *(undefined8 *)(uVar17 + uVar18 * 8);
                                uVar18 = uVar18 + 1;
                            } while (uVar18 < (uint64_t)iVar14);
                        } else {
                            func_0x000180498030(uVar15, uVar17, iVar14 * 8);
                            var_18h = uVar15;
                        }
                    }
                }
                iVar19 = var_c0h;
                uVar15 = uVar21;
                if (var_c0h != 0) {
                    iVar14 = *(int64_t *)var_e0h;
                    uVar15 = func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), var_c0h * 8);
                    if (iVar19 != 0) {
                        uVar17 = var_d8h * 8 + iVar14;
                        if (((uint64_t)iVar19 < 2) ||
                           ((uVar15 <= uVar17 + (iVar19 + -1) * 8 && (uVar17 <= uVar15 + (iVar19 + -1) * 8)))) {
                            do {
                                *(undefined8 *)(uVar15 + uVar21 * 8) = *(undefined8 *)(uVar17 + uVar21 * 8);
                                uVar21 = uVar21 + 1;
                            } while (uVar21 < (uint64_t)iVar19);
                        } else {
                            func_0x000180498030(uVar15, uVar17, iVar19 * 8);
                        }
                    }
                }
                iVar14 = *(int64_t *)var_128h;
                if (iVar14 == 0) {
code_r0x0001800e5642:
                    puVar12 = (undefined8 *)func_0x000180459890(0x2008);
                    *puVar12 = *(undefined8 *)var_128h;
                    *(undefined8 **)var_128h = puVar12;
                    puVar12 = puVar12 + 1;
                    iVar14 = 0x60;
                } else {
                    puVar12 = (undefined8 *)(*(int64_t *)(var_128h + 8) + 7 + iVar14 + 8 & 0xfffffffffffffff8);
                    if ((undefined8 *)(iVar14 + 0x2008U) < puVar12 + 0xc) goto code_r0x0001800e5642;
                    iVar14 = (int64_t)puVar12 + (0x60 - (iVar14 + 8));
                }
                *(int64_t *)(var_128h + 8) = iVar14;
                *(undefined4 *)puVar12 = *(undefined4 *)0x180782a74;
                *(undefined8 *)((int64_t)puVar12 + 4) = 0xffffffffffffffff;
                puVar12[2] = 0;
                puVar12[3] = 0;
                puVar12[4] = 0xffffffffffffffff;
                puVar12[5] = iVar9;
                puVar12[6] = uVar15;
                puVar12[7] = iVar19;
                puVar12[8] = var_18h;
                puVar12[9] = var_20h;
                puVar12[10] = var_178h;
                puVar12[0xb] = uVar11;
                var_18h = CONCAT44(var_138h._4_4_, (undefined4)var_138h);
                puVar16 = (undefined8 *)func_0x0001800cc970(arg1 + 0x490, &var_18h);
                *puVar16 = puVar12;
                iVar19 = CONCAT44(var_138h._4_4_, (undefined4)var_138h);
            }
            ppiVar13 = *(int64_t ***)(arg1 + 0xd8);
            iVar14 = (int64_t)*ppiVar13;
            if (iVar14 == 0) {
code_r0x0001800e5718:
                piVar22 = (int64_t *)func_0x000180459890(0x2008);
                *piVar22 = (int64_t)*ppiVar13;
                *ppiVar13 = piVar22;
                piVar22 = piVar22 + 1;
                piVar10 = (int64_t *)0x8;
            } else {
                piVar22 = (int64_t *)((int64_t)ppiVar13[1] + iVar14 + 0xf & 0xfffffffffffffff8);
                if ((int64_t *)(iVar14 + 0x2008U) < piVar22 + 1) goto code_r0x0001800e5718;
                piVar10 = (int64_t *)((int64_t)piVar22 + (8 - (iVar14 + 8)));
            }
            ppiVar13[1] = piVar10;
            *piVar22 = iVar19;
            var_b0h = *(int64_t *)(iVar19 + 0x14);
            piVar10 = *ppiVar13;
            var_b8h = iVar9;
            if (piVar10 == (int64_t *)0x0) {
code_r0x0001800e577f:
                ppiVar20 = (int64_t **)func_0x000180459890(0x2008);
                *ppiVar20 = *ppiVar13;
                *ppiVar13 = (int64_t *)ppiVar20;
                ppiVar20 = ppiVar20 + 1;
                piVar10 = (int64_t *)0x38;
            } else {
                ppiVar20 = (int64_t **)((int64_t)ppiVar13[1] + 7 + (int64_t)(piVar10 + 1) & 0xfffffffffffffff8);
                if (piVar10 + 0x401 < ppiVar20 + 7) goto code_r0x0001800e577f;
                piVar10 = (int64_t *)((int64_t)ppiVar20 + (0x38 - (int64_t)(piVar10 + 1)));
            }
            ppiVar13[1] = piVar10;
            *(undefined4 *)(ppiVar20 + 1) = *(undefined4 *)0x18078268c;
            *(undefined4 *)((int64_t)ppiVar20 + 0xc) = (undefined4)var_b8h;
            *(undefined4 *)(ppiVar20 + 2) = var_b8h._4_4_;
            *(undefined4 *)((int64_t)ppiVar20 + 0x14) = (undefined4)var_b0h;
            *(undefined4 *)(ppiVar20 + 3) = var_b0h._4_4_;
            *ppiVar20 = (int64_t *)0x180641fc8;
            ppiVar20[4] = piVar22;
            ppiVar20[5] = (int64_t *)0x1;
            ppiVar20[6] = (int64_t *)0x0;
code_r0x0001800e57ca:
            if (*(char *)(arg1 + 0x58) == '\0') goto code_r0x0001800e57fd;
            piVar22 = (int64_t *)func_0x0001800f12b0(*(undefined8 *)(arg1 + 0xd8));
        } else {
            if (uVar15 == 1) {
                iVar9 = *(int64_t *)var_8h;
                if (*(char *)0x180778140 == '\0') {
                    if (iVar14 != 0) goto code_r0x0001800e5103;
                    iVar9 = func_0x0001800f1350(*(undefined8 *)(arg1 + 0xd8), &var_128h, iVar9 + var_10h * 8);
                } else if (iVar14 == 0) {
                    iVar9 = func_0x0001800f1350(*(undefined8 *)(arg1 + 0xd8), &var_128h, iVar9 + var_10h * 8);
                    if (*(char *)(arg1 + 0x58) != '\0') {
                        if (cVar7 == '\0') {
                            var_20h = -1;
                        } else {
                            var_20h = var_178h;
                        }
                        uVar11 = func_0x0001800f1400(*(undefined8 *)(arg1 + 0xd8), &var_20h);
                        var_20h = iVar9;
                        puVar12 = (undefined8 *)func_0x0001800cc970(arg1 + 0x490, &var_20h);
                        *puVar12 = uVar11;
                    }
                } else {
code_r0x0001800e5103:
                    iVar9 = *(int64_t *)(iVar9 + var_10h * 8);
                }
                iVar14 = func_0x0001800e7930(arg1, iVar9, (int64_t)&var_68h + 4);
                ppiVar13 = *(int64_t ***)(arg1 + 0xd8);
                iVar9 = (int64_t)*ppiVar13;
                if (iVar9 == 0) {
code_r0x0001800e5157:
                    piVar22 = (int64_t *)func_0x000180459890(0x2008);
                    *piVar22 = (int64_t)*ppiVar13;
                    *ppiVar13 = piVar22;
                    piVar22 = piVar22 + 1;
                    piVar10 = (int64_t *)0x8;
                } else {
                    piVar22 = (int64_t *)((int64_t)ppiVar13[1] + iVar9 + 0xf & 0xfffffffffffffff8);
                    if ((int64_t *)(iVar9 + 0x2008U) < piVar22 + 1) goto code_r0x0001800e5157;
                    piVar10 = (int64_t *)((int64_t)piVar22 + (8 - (iVar9 + 8)));
                }
                ppiVar13[1] = piVar10;
                var_150h = 1;
                *piVar22 = iVar14;
                var_148h = var_18h;
                var_138h._0_4_ = uVar4;
                var_138h._4_4_ = uVar5;
                var_130h = (undefined4)iVar19;
                uStack_12c = (undefined4)((uint64_t)iVar19 >> 0x20);
                var_158h = (int64_t)piVar22;
                ppiVar20 = (int64_t **)func_0x0001800f11f0(ppiVar13, &var_138h, &var_158h);
                goto code_r0x0001800e57ca;
            }
            ppiVar13 = *(int64_t ***)(arg1 + 0xd8);
            uVar17 = uVar21;
            if (uVar15 != 0) {
                uVar17 = *(int64_t *)var_8h + var_10h * 8;
            }
            func_0x0001800f1110(arg1, &var_158h, uVar17, uVar15);
            iVar19 = (int64_t)*ppiVar13;
            if (iVar19 == 0) {
code_r0x0001800e5222:
                piVar22 = (int64_t *)func_0x000180459890(0x2008);
                *piVar22 = (int64_t)*ppiVar13;
                *ppiVar13 = piVar22;
                ppiVar20 = (int64_t **)(piVar22 + 1);
                piVar22 = (int64_t *)0x38;
            } else {
                ppiVar20 = (int64_t **)((int64_t)ppiVar13[1] + iVar19 + 0xf & 0xfffffffffffffff8);
                if ((int64_t **)(iVar19 + 0x2008) < ppiVar20 + 7) goto code_r0x0001800e5222;
                piVar22 = (int64_t *)((int64_t)ppiVar20 + (0x38 - (iVar19 + 8)));
            }
            ppiVar13[1] = piVar22;
            *(undefined4 *)(ppiVar20 + 1) = *(undefined4 *)0x18078268c;
            *(undefined4 *)((int64_t)ppiVar20 + 0xc) = (undefined4)var_128h;
            *(undefined4 *)(ppiVar20 + 2) = var_128h._4_4_;
            *(undefined4 *)((int64_t)ppiVar20 + 0x14) = (undefined4)var_120h;
            *(undefined4 *)(ppiVar20 + 3) = var_120h._4_4_;
            *ppiVar20 = (int64_t *)0x180641fc8;
            *(undefined4 *)(ppiVar20 + 4) = (undefined4)var_158h;
            *(undefined4 *)((int64_t)ppiVar20 + 0x24) = var_158h._4_4_;
            *(undefined4 *)(ppiVar20 + 5) = (undefined4)var_150h;
            *(undefined4 *)((int64_t)ppiVar20 + 0x2c) = var_150h._4_4_;
            ppiVar20[6] = (int64_t *)iVar14;
            if (*(char *)(arg1 + 0x58) == '\0') goto code_r0x0001800e57fd;
            ppiVar13 = *(int64_t ***)(arg1 + 0xd8);
            uVar15 = uVar21;
            if (var_20h != 0) {
                iVar19 = *(int64_t *)var_118h;
                uVar15 = func_0x0001800d4d20(ppiVar13, var_20h * 8);
                if (var_20h != 0) {
                    uVar17 = var_110h * 8 + iVar19;
                    if (((uint64_t)var_20h < 2) ||
                       ((uVar15 <= uVar17 + (var_20h + -1) * 8 && (uVar17 <= uVar15 + (var_20h + -1) * 8)))) {
                        do {
                            *(undefined8 *)(uVar15 + uVar21 * 8) = *(undefined8 *)(uVar17 + uVar21 * 8);
                            uVar21 = uVar21 + 1;
                        } while (uVar21 < (uint64_t)var_20h);
                    } else {
                        func_0x000180498030(uVar15, uVar17, var_20h * 8);
                    }
                }
            }
            iVar19 = (int64_t)*ppiVar13;
            if (iVar19 == 0) {
code_r0x0001800e5352:
                piVar22 = (int64_t *)func_0x000180459890(0x2008);
                *piVar22 = (int64_t)*ppiVar13;
                *ppiVar13 = piVar22;
                piVar22 = piVar22 + 1;
                piVar10 = (int64_t *)0x28;
            } else {
                piVar22 = (int64_t *)((int64_t)ppiVar13[1] + iVar19 + 0xf & 0xfffffffffffffff8);
                if ((int64_t *)(iVar19 + 0x2008U) < piVar22 + 5) goto code_r0x0001800e5352;
                piVar10 = (int64_t *)((int64_t)piVar22 + (0x28 - (iVar19 + 8)));
            }
            ppiVar13[1] = piVar10;
            *(undefined4 *)piVar22 = *(undefined4 *)0x180782ac0;
            *(int64_t *)((int64_t)piVar22 + 4) = iVar9;
            *(int64_t *)((int64_t)piVar22 + 0xc) = var_178h;
            piVar22[3] = uVar15;
            piVar22[4] = var_20h;
        }
        var_18h = (int64_t)ppiVar20;
        ppiVar13 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_18h);
        *ppiVar13 = piVar22;
code_r0x0001800e57fd:
        iVar19 = *(int64_t *)var_e0h + var_d8h * 8;
        if (iVar19 != *(int64_t *)(var_e0h + 8)) {
            *(int64_t *)(var_e0h + 8) = iVar19;
        }
        iVar19 = *(int64_t *)var_118h + var_110h * 8;
        if (iVar19 != *(int64_t *)(var_118h + 8)) {
            *(int64_t *)(var_118h + 8) = iVar19;
        }
        iVar19 = var_108h * 0x20 + *(int64_t *)var_100h;
        if (iVar19 != *(int64_t *)(var_100h + 8)) {
            *(int64_t *)(var_100h + 8) = iVar19;
        }
        iVar19 = *(int64_t *)var_8h + var_10h * 8;
        if (iVar19 == *(int64_t *)(var_8h + 8)) {
            return ppiVar20;
        }
        *(int64_t *)(var_8h + 8) = iVar19;
        return ppiVar20;
    }
    if ((*(int32_t *)(arg1 + 0x80) == 0x106) ||
       ((*(int32_t *)(arg1 + 0x80) == 0x119 &&
        (piVar8 = (int32_t *)func_0x0001800d70e0(arg1 + 0x60, &var_88h), *piVar8 == 0x106)))) {
        ppiVar13 = (int64_t **)func_0x0001800e8e20(arg1);
        return ppiVar13;
    }
    iVar9 = func_0x0001800e8150(arg1, 0);
    ppiVar13 = *(int64_t ***)(arg1 + 0xd8);
    iVar19 = (int64_t)*ppiVar13;
    if (iVar19 == 0) {
code_r0x0001800e49c0:
        piVar22 = (int64_t *)func_0x000180459890(0x2008);
        *piVar22 = (int64_t)*ppiVar13;
        *ppiVar13 = piVar22;
        piVar22 = piVar22 + 1;
        piVar10 = (int64_t *)0x8;
    } else {
        piVar22 = (int64_t *)((int64_t)ppiVar13[1] + iVar19 + 0xf & 0xfffffffffffffff8);
        if ((int64_t *)(iVar19 + 0x2008U) < piVar22 + 1) goto code_r0x0001800e49c0;
        piVar10 = (int64_t *)((int64_t)piVar22 + (8 - (iVar19 + 8)));
    }
    ppiVar13[1] = piVar10;
    *piVar22 = iVar9;
    piVar10 = *ppiVar13;
    if (piVar10 != (int64_t *)0x0) {
        ppiVar20 = (int64_t **)((int64_t)ppiVar13[1] + 7 + (int64_t)(piVar10 + 1) & 0xfffffffffffffff8);
        if (ppiVar20 + 7 <= piVar10 + 0x401) {
            piVar10 = (int64_t *)((int64_t)ppiVar20 + (0x38 - (int64_t)(piVar10 + 1)));
            goto code_r0x0001800e4a36;
        }
    }
    ppiVar20 = (int64_t **)func_0x000180459890(0x2008);
    *ppiVar20 = *ppiVar13;
    *ppiVar13 = (int64_t *)ppiVar20;
    ppiVar20 = ppiVar20 + 1;
    piVar10 = (int64_t *)0x38;
code_r0x0001800e4a36:
    ppiVar13[1] = piVar10;
    uVar4 = *(undefined4 *)0x18078268c;
    *ppiVar20 = (int64_t *)0x180642298;
    *(undefined4 *)(ppiVar20 + 1) = uVar4;
    uVar4 = *(undefined4 *)(iVar9 + 0x10);
    uVar5 = *(undefined4 *)(iVar9 + 0x14);
    uVar6 = *(undefined4 *)(iVar9 + 0x18);
    *(undefined4 *)((int64_t)ppiVar20 + 0xc) = *(undefined4 *)(iVar9 + 0xc);
    *(undefined4 *)(ppiVar20 + 2) = uVar4;
    *(undefined4 *)((int64_t)ppiVar20 + 0x14) = uVar5;
    *(undefined4 *)(ppiVar20 + 3) = uVar6;
    *ppiVar20 = (int64_t *)0x180641fc8;
    ppiVar20[4] = piVar22;
    ppiVar20[5] = (int64_t *)0x1;
    ppiVar20[6] = (int64_t *)0x0;
    if (*(char *)(arg1 + 0x58) != '\0') {
        uVar11 = func_0x0001800f12b0(*(undefined8 *)(arg1 + 0xd8));
        var_8h = (int64_t)ppiVar20;
        puVar12 = (undefined8 *)func_0x0001800cc970(arg1 + 0x490, &var_8h);
        *puVar12 = uVar11;
    }
    return ppiVar20;
}

// ============================================================
// Function: FUN_1800e58a0
// Address: 0x1800e58a0
// Size: 451 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

int64_t fcn.1800e58a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    undefined4 uVar1;
    int64_t iVar2;
    int64_t **ppiVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    char cVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    undefined8 uVar14;
    undefined8 uVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined4 var_88h;
    int64_t var_84h;
    int64_t var_68h;
    int64_t var_60h;
    
    iVar10 = func_0x0001800e8150(arg1, 0);
    iVar2 = *(int64_t *)(arg_28h + 4);
    var_88h = *(undefined4 *)arg_28h;
    var_84h = iVar2;
    if (*(int32_t *)(arg1 + 0x80) == 0x5d) {
        fcn.1800f0350(arg1);
code_r0x0001800e5937:
        uVar14 = *(undefined8 *)(arg1 + 0xa0);
    } else {
        func_0x0001800ef5a0(arg1, 0x5d, &var_88h, 0);
        cVar9 = func_0x0001800ef4e0(arg1, 0x5d);
        if (cVar9 != '\0') goto code_r0x0001800e5937;
        uVar14 = 0xffffffffffffffff;
    }
    if (*(int32_t *)(arg1 + 0x80) == 0x3a) {
        fcn.1800f0350(arg1);
code_r0x0001800e597a:
        uVar15 = *(undefined8 *)(arg1 + 0xa0);
    } else {
        cVar9 = func_0x0001800ef2a0(arg1, 0x3a, 0x1806436d0);
        if (cVar9 != '\0') goto code_r0x0001800e597a;
        uVar15 = 0xffffffffffffffff;
    }
    iVar11 = func_0x0001800e8150(arg1, 0);
    ppiVar3 = *(int64_t ***)(arg1 + 0xd8);
    var_60h = *(int64_t *)(iVar11 + 0x14);
    iVar4 = (int64_t)*ppiVar3;
    var_68h = iVar2;
    if (iVar4 != 0) {
        piVar13 = (int64_t *)((int64_t)ppiVar3[1] + iVar4 + 0xf & 0xfffffffffffffff8);
        if (piVar13 + 7 <= (int64_t *)(iVar4 + 0x2008U)) {
            piVar12 = (int64_t *)((int64_t)piVar13 + (0x38 - (iVar4 + 8)));
            goto code_r0x0001800e59f6;
        }
    }
    piVar12 = (int64_t *)func_0x000180459890(0x2008);
    *piVar12 = (int64_t)*ppiVar3;
    piVar13 = piVar12 + 1;
    *ppiVar3 = piVar12;
    piVar12 = (int64_t *)0x38;
code_r0x0001800e59f6:
    ppiVar3[1] = piVar12;
    *piVar13 = iVar10;
    *(int32_t *)(piVar13 + 4) = (int32_t)arg3;
    *(undefined4 *)(piVar13 + 2) = (undefined4)var_68h;
    *(undefined4 *)((int64_t)piVar13 + 0x14) = var_68h._4_4_;
    *(undefined4 *)(piVar13 + 3) = (undefined4)var_60h;
    *(undefined4 *)((int64_t)piVar13 + 0x1c) = var_60h._4_4_;
    piVar13[1] = iVar11;
    *(int64_t **)arg2 = piVar13;
    uVar5 = *(undefined4 *)arg4;
    uVar6 = *(undefined4 *)(arg4 + 4);
    uVar7 = *(undefined4 *)(arg4 + 8);
    uVar8 = *(undefined4 *)(arg4 + 0xc);
    uVar1 = *(undefined4 *)(arg4 + 0x10);
    *(undefined8 *)(arg2 + 0x10) = uVar14;
    *(undefined4 *)((int64_t)piVar13 + 0x24) = uVar5;
    *(undefined4 *)(piVar13 + 5) = uVar6;
    *(undefined4 *)((int64_t)piVar13 + 0x2c) = uVar7;
    *(undefined4 *)(piVar13 + 6) = uVar8;
    *(undefined4 *)((int64_t)piVar13 + 0x34) = uVar1;
    *(undefined8 *)(arg2 + 8) = *(undefined8 *)(arg_28h + 4);
    *(undefined8 *)(arg2 + 0x18) = uVar15;
    return arg2;
}

// ============================================================
// Function: FUN_1800e5a70
// Address: 0x1800e5a70
// Size: 3015 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_1b8h
// WARNING: Variable defined which should be unmapped: var_14h
// WARNING: Variable defined which should be unmapped: var_ch
// WARNING: Variable defined which should be unmapped: var_1ch
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_6fh
// WARNING: [rz-ghidra] Detected overlap for variable var_173h
// WARNING: [rz-ghidra] Detected overlap for variable var_6dh
// WARNING: [rz-ghidra] Detected overlap for variable var_171h
// WARNING: [rz-ghidra] Detected overlap for variable var_1a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_19ch
// WARNING: [rz-ghidra] Detected overlap for variable var_194h
// WARNING: [rz-ghidra] Detected overlap for variable var_18ch
// WARNING: [rz-ghidra] Detected overlap for variable var_180h
// WARNING: [rz-ghidra] Detected overlap for variable var_178h
// WARNING: [rz-ghidra] Detected overlap for variable arg_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_198h
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_4fh
// WARNING: [rz-ghidra] Detected overlap for variable var_4dh
// WARNING: [rz-ghidra] Detected overlap for variable var_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h

int64_t **
fcn.1800e5a70(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_e0h, int64_t arg_e8h, int64_t arg_f0h, int64_t arg_f8h)
{
    int64_t *piVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined auVar5 [12];
    undefined auVar6 [12];
    undefined auVar7 [12];
    int32_t iVar8;
    int32_t iVar9;
    int32_t iVar10;
    int32_t iVar11;
    bool bVar12;
    undefined auVar13 [16];
    undefined8 uVar14;
    undefined8 uVar15;
    char cVar16;
    char cVar17;
    int32_t iVar18;
    int32_t *piVar19;
    int64_t iVar20;
    int64_t *piVar21;
    undefined8 uVar22;
    undefined8 uVar23;
    int64_t *piVar24;
    int64_t **ppiVar25;
    int32_t iVar26;
    int64_t iVar27;
    int64_t iVar28;
    undefined8 *puVar29;
    undefined in_DL;
    int64_t iVar30;
    int64_t *piVar31;
    int64_t *piVar32;
    int64_t *piVar33;
    int64_t **ppiVar34;
    int64_t **ppiVar35;
    int64_t iVar36;
    undefined4 uVar37;
    undefined4 uVar38;
    undefined4 uVar39;
    undefined4 uVar40;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_1b8h;
    int64_t var_1b0h;
    int64_t var_1a8h;
    int64_t var_1a0h;
    int32_t var_198h;
    int32_t var_194h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t *var_180h;
    undefined4 var_178h;
    int64_t var_174h;
    int64_t var_168h;
    int64_t var_160h;
    undefined8 uStack_158;
    undefined8 uStack_150;
    undefined2 uStack_147;
    undefined uStack_145;
    undefined auStack_138 [16];
    char cStack_128;
    undefined2 uStack_127;
    undefined uStack_125;
    uint32_t uStack_118;
    undefined8 uStack_110;
    undefined8 uStack_108;
    undefined8 uStack_100;
    int32_t iStack_f8;
    int32_t iStack_f4;
    int32_t iStack_f0;
    undefined4 uStack_ec;
    undefined8 uStack_e8;
    undefined8 uStack_e0;
    int64_t *piStack_d8;
    int64_t iStack_d0;
    int64_t *piStack_c8;
    int64_t *piStack_c0;
    int64_t iStack_b8;
    int64_t *piStack_b0;
    int32_t iStack_a8;
    int32_t iStack_a4;
    int32_t iStack_a0;
    int32_t iStack_9c;
    int32_t iStack_98;
    int32_t iStack_94;
    int32_t iStack_90;
    int32_t iStack_8c;
    int64_t iStack_88;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_1ch;
    int64_t var_14h;
    int64_t var_ch;
    
    *(int32_t *)(arg1 + 0x114) = *(int32_t *)(arg1 + 0x114) + 1;
    if (*(uint32_t *)0x180778500 < *(uint32_t *)(arg1 + 0x114)) {
        iVar20 = func_0x0001800d90d0(arg1 + 0x60);
        func_0x0001800d9940(iVar20 + 4, 0x180644050, 0x1806436c0);
        pcVar4 = (code *)swi(3);
        ppiVar25 = (int64_t **)(*pcVar4)();
        return ppiVar25;
    }
    piVar31 = (int64_t *)(arg1 + 800);
    iStack_b8 = (*(int64_t *)(arg1 + 0x328) - *piVar31 >> 3) * 0x6db6db6db6db6db7;
    iVar20 = 0;
    piStack_b0 = (int64_t *)0x0;
    piVar21 = (int64_t *)(arg1 + 0x338);
    iStack_d0 = (*(int64_t *)(arg1 + 0x340) - *piVar21 >> 3) * 0x6db6db6db6db6db7;
    piStack_c8 = (int64_t *)0x0;
    var_168h = 0;
    uStack_e8 = *(undefined8 *)(arg1 + 0x84);
    var_78h._0_4_ = *(int32_t *)(arg1 + 0x80);
    unique0x0000c280 = *(undefined8 *)(arg1 + 0x84);
    var_10h._0_1_ = in_DL;
    piStack_d8 = piVar21;
    piStack_c0 = piVar31;
    if ((int32_t)var_78h == 0x7b) {
        fcn.1800f0350(arg1);
    } else {
        func_0x0001800ef2a0(arg1, 0x7b, 0x1806436e0);
    }
    uVar15 = uStack_e8;
    var_18h._0_1_ = 0;
    iVar18 = *(int32_t *)(arg1 + 0x80);
    iStack_88 = 0x20;
    if (iVar18 != 0x7d) {
code_r0x0001800e5b80:
        iVar36 = 3;
        var_160h._0_4_ = 3;
        cVar16 = '\0';
        var_8h = var_8h & 0xffffffffffffff00;
        if (iVar18 == 0x119) {
            piVar19 = (int32_t *)func_0x0001800d70e0(arg1 + 0x60, &var_1a8h);
            iVar27 = 0;
            if ((*piVar19 == 0x3a) || (iVar3 = *(int64_t *)(arg1 + 0x98), iVar28 = iVar27, iVar3 == 0))
            goto code_r0x0001800e5c6f;
            do {
                iVar30 = iVar28 + 1;
                if (*(char *)(iVar3 + iVar28) != *(char *)(iVar28 + 0x1806431b4)) goto code_r0x0001800e5c30;
                iVar28 = iVar30;
            } while (iVar30 != 5);
            uVar37 = *(undefined4 *)(arg1 + 0x84);
            uVar38 = *(undefined4 *)(arg1 + 0x88);
            uVar39 = *(undefined4 *)(arg1 + 0x8c);
            uVar40 = *(undefined4 *)(arg1 + 0x90);
            cVar16 = '\x01';
            var_8h = CONCAT71(var_8h._1_7_, 1);
            iVar36 = 1;
            var_160h._0_4_ = 1;
            func_0x0001800d7020(arg1 + 0x60);
        } else {
code_r0x0001800e5c6f:
            uVar37 = (undefined4)uStack_158;
            uVar38 = uStack_158._4_4_;
            uVar39 = (undefined4)uStack_150;
            uVar40 = uStack_150._4_4_;
        }
        goto code_r0x0001800e5c73;
    }
code_r0x0001800e6338:
    uStack_158 = *(undefined8 *)(arg1 + 0x84);
    uStack_150 = *(undefined8 *)(arg1 + 0x8c);
    if (*(int32_t *)(arg1 + 0x80) == 0x7d) {
        fcn.1800f0350(arg1);
    } else {
        func_0x0001800ef5a0(arg1, 0x7d, &var_78h, 0);
        cVar16 = func_0x0001800ef4e0(arg1, 0x7d);
        if (cVar16 == '\0') {
            uStack_158 = *(undefined8 *)(arg1 + 0xa0);
            uStack_150 = *(undefined8 *)(arg1 + 0xa8);
        }
    }
    piVar24 = piStack_b0;
    ppiVar25 = *(int64_t ***)(arg1 + 0xd8);
    var_8h = (int64_t)ppiVar25;
    if (piStack_b0 == (int64_t *)0x0) {
        piVar33 = (int64_t *)0x0;
    } else {
        var_20h = iStack_b8 * 0x38 + *piVar31;
        piVar33 = (int64_t *)func_0x0001800d4d20(ppiVar25);
        piVar32 = (int64_t *)0x0;
        if (piVar24 != (int64_t *)0x0) {
            do {
                iVar20 = (int64_t)piVar32 * 0x38;
                puVar2 = (undefined4 *)(var_20h + iVar20);
                uVar37 = puVar2[1];
                uVar38 = puVar2[2];
                uVar39 = puVar2[3];
                piVar1 = piVar33 + (int64_t)piVar32 * 7;
                *(undefined4 *)piVar1 = *puVar2;
                *(undefined4 *)((int64_t)piVar1 + 4) = uVar37;
                *(undefined4 *)(piVar1 + 1) = uVar38;
                *(undefined4 *)((int64_t)piVar1 + 0xc) = uVar39;
                puVar2 = (undefined4 *)(var_20h + 0x10 + iVar20);
                uVar37 = puVar2[1];
                uVar38 = puVar2[2];
                uVar39 = puVar2[3];
                piVar1 = piVar33 + (int64_t)piVar32 * 7 + 2;
                *(undefined4 *)piVar1 = *puVar2;
                *(undefined4 *)((int64_t)piVar1 + 4) = uVar37;
                *(undefined4 *)(piVar1 + 1) = uVar38;
                *(undefined4 *)((int64_t)piVar1 + 0xc) = uVar39;
                puVar2 = (undefined4 *)(var_20h + 0x20 + iVar20);
                uVar37 = puVar2[1];
                uVar38 = puVar2[2];
                uVar39 = puVar2[3];
                piVar1 = piVar33 + (int64_t)piVar32 * 7 + 4;
                *(undefined4 *)piVar1 = *puVar2;
                *(undefined4 *)((int64_t)piVar1 + 4) = uVar37;
                *(undefined4 *)(piVar1 + 1) = uVar38;
                *(undefined4 *)((int64_t)piVar1 + 0xc) = uVar39;
                piVar33[(int64_t)piVar32 * 7 + 6] = *(int64_t *)(var_20h + 0x30 + iVar20);
                piVar32 = (int64_t *)((int64_t)piVar32 + 1);
            } while (piVar32 < piVar24);
        }
    }
    uStack_e0 = uStack_150;
    iVar20 = (int64_t)*ppiVar25;
    uStack_e8 = uVar15;
    if (iVar20 == 0) {
code_r0x0001800e644e:
        ppiVar34 = (int64_t **)func_0x000180459890(0x2008);
        *ppiVar34 = *ppiVar25;
        *ppiVar25 = (int64_t *)ppiVar34;
        ppiVar34 = ppiVar34 + 1;
        iVar20 = 0x38;
    } else {
        ppiVar34 = (int64_t **)((int64_t)ppiVar25[1] + iVar20 + 0xf & 0xfffffffffffffff8);
        ppiVar25 = (int64_t **)var_8h;
        if ((int64_t **)(iVar20 + 0x2008) < ppiVar34 + 7) goto code_r0x0001800e644e;
        iVar20 = (int64_t)ppiVar34 + (0x38 - (iVar20 + 8));
    }
    piVar32 = piStack_c8;
    *(int64_t *)(var_8h + 8) = iVar20;
    *(undefined4 *)(ppiVar34 + 1) = *(undefined4 *)0x180782704;
    *(int32_t *)((int64_t)ppiVar34 + 0xc) = (int32_t)uStack_e8;
    *(undefined4 *)(ppiVar34 + 2) = uStack_e8._4_4_;
    *(undefined4 *)((int64_t)ppiVar34 + 0x14) = (undefined4)uStack_e0;
    *(undefined4 *)(ppiVar34 + 3) = uStack_e0._4_4_;
    *ppiVar34 = (int64_t *)0x180641f00;
    ppiVar34[4] = piVar33;
    ppiVar34[5] = piVar24;
    ppiVar34[6] = (int64_t *)var_168h;
    if (*(char *)(arg1 + 0x58) == '\0') goto code_r0x0001800e65c7;
    ppiVar25 = *(int64_t ***)(arg1 + 0xd8);
    var_8h = (int64_t)ppiVar25;
    if (piStack_c8 == (int64_t *)0x0) {
        piVar24 = (int64_t *)0x0;
    } else {
        var_20h = iStack_d0 * 0x38 + *piVar21;
        piVar24 = (int64_t *)func_0x0001800d4d20(ppiVar25);
        piVar33 = (int64_t *)0x0;
        if (piVar32 != (int64_t *)0x0) {
            do {
                iVar20 = (int64_t)piVar33 * 0x38;
                puVar2 = (undefined4 *)(var_20h + iVar20);
                uVar37 = puVar2[1];
                uVar38 = puVar2[2];
                uVar39 = puVar2[3];
                piVar1 = piVar24 + (int64_t)piVar33 * 7;
                *(undefined4 *)piVar1 = *puVar2;
                *(undefined4 *)((int64_t)piVar1 + 4) = uVar37;
                *(undefined4 *)(piVar1 + 1) = uVar38;
                *(undefined4 *)((int64_t)piVar1 + 0xc) = uVar39;
                puVar2 = (undefined4 *)(var_20h + 0x10 + iVar20);
                uVar37 = puVar2[1];
                uVar38 = puVar2[2];
                uVar39 = puVar2[3];
                piVar1 = piVar24 + (int64_t)piVar33 * 7 + 2;
                *(undefined4 *)piVar1 = *puVar2;
                *(undefined4 *)((int64_t)piVar1 + 4) = uVar37;
                *(undefined4 *)(piVar1 + 1) = uVar38;
                *(undefined4 *)((int64_t)piVar1 + 0xc) = uVar39;
                puVar2 = (undefined4 *)(var_20h + 0x20 + iVar20);
                uVar37 = puVar2[1];
                uVar38 = puVar2[2];
                uVar39 = puVar2[3];
                piVar1 = piVar24 + (int64_t)piVar33 * 7 + 4;
                *(undefined4 *)piVar1 = *puVar2;
                *(undefined4 *)((int64_t)piVar1 + 4) = uVar37;
                *(undefined4 *)(piVar1 + 1) = uVar38;
                *(undefined4 *)((int64_t)piVar1 + 0xc) = uVar39;
                piVar24[(int64_t)piVar33 * 7 + 6] = *(int64_t *)(var_20h + 0x30 + iVar20);
                piVar33 = (int64_t *)((int64_t)piVar33 + 1);
            } while (piVar33 < piVar32);
        }
    }
    iVar20 = (int64_t)*ppiVar25;
    if (iVar20 == 0) {
code_r0x0001800e656a:
        ppiVar35 = (int64_t **)func_0x000180459890(0x2008);
        *ppiVar35 = *ppiVar25;
        *ppiVar25 = (int64_t *)ppiVar35;
        ppiVar35 = ppiVar35 + 1;
    } else {
        ppiVar35 = (int64_t **)((int64_t)ppiVar25[1] + iVar20 + 0xf & 0xfffffffffffffff8);
        ppiVar25 = (int64_t **)var_8h;
        if ((int64_t **)(iVar20 + 0x2008U) < ppiVar35 + 4) goto code_r0x0001800e656a;
        iStack_88 = (int64_t)ppiVar35 + (0x20 - (iVar20 + 8));
    }
    *(int64_t *)(var_8h + 8) = iStack_88;
    *(undefined4 *)ppiVar35 = *(undefined4 *)0x180782a84;
    ppiVar35[1] = piVar24;
    ppiVar35[2] = piVar32;
    *(undefined *)(ppiVar35 + 3) = (undefined)var_18h;
    var_8h = (int64_t)ppiVar34;
    ppiVar25 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_8h);
    *ppiVar25 = (int64_t *)ppiVar35;
code_r0x0001800e65c7:
    iVar20 = iStack_d0 * 0x38 + *piVar21;
    if (iVar20 != piVar21[1]) {
        piVar21[1] = iVar20;
    }
    iVar20 = iStack_b8 * 0x38 + *piVar31;
    if (iVar20 != piVar31[1]) {
        piVar31[1] = iVar20;
    }
    return ppiVar34;
    while (iVar27 = iVar28, iVar28 != 6) {
code_r0x0001800e5c30:
        iVar28 = iVar27 + 1;
        if (*(char *)(iVar3 + iVar27) != *(char *)(iVar27 + 0x18064333c)) goto code_r0x0001800e5c6f;
    }
    uVar37 = *(undefined4 *)(arg1 + 0x84);
    uVar38 = *(undefined4 *)(arg1 + 0x88);
    uVar39 = *(undefined4 *)(arg1 + 0x8c);
    uVar40 = *(undefined4 *)(arg1 + 0x90);
    cVar16 = '\x01';
    var_8h = CONCAT71(var_8h._1_7_, 1);
    iVar36 = 2;
    var_160h._0_4_ = 2;
    func_0x0001800d7020(arg1 + 0x60);
code_r0x0001800e5c73:
    iVar18 = *(int32_t *)(arg1 + 0x80);
    iVar26 = 0;
    if (iVar18 == 0x5b) {
        iStack_a4 = *(int32_t *)(arg1 + 0x84);
        iStack_a0 = *(int32_t *)(arg1 + 0x88);
        iStack_9c = *(int32_t *)(arg1 + 0x8c);
        iVar8 = *(int32_t *)(arg1 + 0x90);
        iVar9 = *(int32_t *)(arg1 + 0x94);
        iVar10 = *(int32_t *)(arg1 + 0x98);
        iVar11 = *(int32_t *)(arg1 + 0x9c);
        iStack_a8 = iVar18;
        iStack_98 = iVar8;
        iStack_94 = iVar9;
        iStack_90 = iVar10;
        iStack_8c = iVar11;
        fcn.1800f0350(arg1);
        if ((1 < *(int32_t *)(arg1 + 0x80) - 0x116U) ||
           (piVar19 = (int32_t *)func_0x0001800d70e0(arg1 + 0x60, &var_1a8h), *piVar19 != 0x5d)) {
            auStack_138._4_4_ = uVar38;
            auStack_138._0_4_ = uVar37;
            auStack_138._8_4_ = uVar39;
            auStack_138._12_4_ = uVar40;
            uStack_127 = uStack_147;
            uStack_125 = uStack_145;
            cStack_128 = cVar16;
            if (iVar20 == 0) {
                var_1a8h._0_4_ = iStack_a8;
                var_1a8h._4_4_ = iStack_a4;
                var_1a0h._0_4_ = iStack_a0;
                var_1a0h._4_4_ = iStack_9c;
                var_198h = iVar8;
                var_194h = iVar9;
                var_190h._0_4_ = iVar10;
                var_190h._4_4_ = iVar11;
                fcn.1800e58a0(arg1, (int64_t)&iStack_a8, iVar36, (int64_t)auStack_138, (int64_t)&var_1a8h);
                iVar20 = CONCAT44(iStack_a4, iStack_a8);
                var_168h = iVar20;
                if (*(char *)(arg1 + 0x58) != '\0') {
                    if (*(int32_t *)(arg1 + 0x80) != 0x2c) {
                        iVar26 = (*(int32_t *)(arg1 + 0x80) != 0x3b) + 1;
                    }
                    var_1a8h._0_4_ = 0;
                    var_1a8h._4_4_ = iStack_a0;
                    var_1a0h._0_4_ = iStack_9c;
                    var_1a0h._4_4_ = iStack_98;
                    var_198h = iStack_94;
                    var_194h = iStack_90;
                    var_190h._0_4_ = iStack_8c;
                    if (iVar26 == 2) {
                        iVar36 = 0xffffffff;
                        var_188h._4_4_ = 0xffffffff;
                    } else {
                        iVar36 = *(int64_t *)(arg1 + 0x84);
                        var_8h._4_4_ = (undefined4)((uint64_t)iVar36 >> 0x20);
                        var_188h._4_4_ = var_8h._4_4_;
                        var_8h = iVar36;
                    }
                    var_188h._0_4_ = (undefined4)iVar36;
                    var_180h = (int64_t *)0x0;
                    var_178h = 0;
                    var_174h._0_1_ = '\0';
                    var_174h._1_2_ = 0;
                    var_174h._3_1_ = 0;
                    var_190h._4_4_ = iVar26;
                    func_0x0001800f23a0(&piStack_d8);
                }
            } else {
                iStack_98 = iVar8;
                iStack_94 = iVar9;
                iStack_90 = iVar10;
                iStack_8c = iVar11;
                piVar31 = (int64_t *)
                          fcn.1800e58a0(arg1, (int64_t)&var_1a8h, iVar36, (int64_t)auStack_138, (int64_t)&iStack_a8);
                fcn.1800efe70(arg1, *piVar31 + 0x10, 0x180643580);
            }
            goto code_r0x0001800e625c;
        }
        var_160h._4_4_ = 0;
        if (*(char *)(arg1 + 0x58) != '\0') {
            var_160h._4_4_ = 0;
            iVar26 = *(int32_t *)(arg1 + 0x80);
            if (iVar26 == 0x10d) {
                uStack_118 = 3;
                var_20h = CONCAT44(var_20h._4_4_, 3);
            } else if (iVar26 == 0x116) {
                uStack_118 = 2;
                var_20h = CONCAT44(var_20h._4_4_, 2);
                puVar29 = (undefined8 *)0x0;
                do {
                    var_160h._4_4_ = (int32_t)puVar29;
                    puVar29 = (undefined8 *)(uint64_t)(var_160h._4_4_ + 1);
                } while (*(char *)((int64_t)puVar29 + (uint64_t)*(uint32_t *)(arg1 + 0x94) + *(int64_t *)(arg1 + 0x98))
                         != ']');
            } else if (iVar26 == 0x117) {
                uStack_118 = (uint32_t)
                             (*(char *)((uint64_t)*(uint32_t *)(arg1 + 0x94) + *(int64_t *)(arg1 + 0x98)) != '\'');
                var_20h = CONCAT44(var_20h._4_4_, uStack_118);
            } else {
                uStack_118 = (uint32_t)var_20h;
            }
        }
        uVar23 = *(undefined8 *)(arg1 + 0x84);
        uStack_158 = 0;
        uStack_150 = 0;
        puVar29 = &uStack_158;
        if (*(char *)(arg1 + 0x58) == '\0') {
            puVar29 = (undefined8 *)0x0;
        }
        func_0x0001800edd70(arg1, auStack_138, puVar29);
        iVar8 = iStack_a0;
        iVar26 = iStack_a4;
        iStack_f4 = iStack_a4;
        iStack_f0 = iStack_a0;
        iStack_f8 = iVar18;
        if (*(int32_t *)(arg1 + 0x80) == 0x5d) {
            fcn.1800f0350(arg1);
code_r0x0001800e5de7:
            uStack_108 = *(undefined8 *)(arg1 + 0xa0);
        } else {
            func_0x0001800ef5a0(arg1, 0x5d, &iStack_f8, 0);
            cVar16 = func_0x0001800ef4e0(arg1, 0x5d);
            if (cVar16 != '\0') goto code_r0x0001800e5de7;
            uStack_108 = 0xffffffffffffffff;
        }
        if (*(int32_t *)(arg1 + 0x80) == 0x3a) {
            fcn.1800f0350(arg1);
code_r0x0001800e5e27:
            uStack_110 = *(undefined8 *)(arg1 + 0xa0);
        } else {
            cVar16 = func_0x0001800ef2a0(arg1, 0x3a, 0x1806436d0);
            if (cVar16 != '\0') goto code_r0x0001800e5e27;
            uStack_110 = 0xffffffffffffffff;
        }
        uVar14 = uStack_110;
        var_80h = func_0x0001800e8150(arg1, 0);
        cVar16 = cStack_128;
        auVar13 = auStack_138;
        if (cStack_128 == '\0') {
code_r0x0001800e5e65:
            bVar12 = false;
        } else {
            iVar20 = func_0x000180498a80(auStack_138._0_8_, 0, auStack_138._8_8_);
            if (iVar20 == 0) goto code_r0x0001800e5e65;
            bVar12 = true;
        }
        if ((cVar16 == '\0') || (bVar12)) {
            fcn.1800efe70(arg1, &iStack_a4, 0x180643148);
            iVar20 = var_168h;
            goto code_r0x0001800e625c;
        }
        var_1a8h._0_4_ = auVar13._0_4_;
        var_1a8h._4_4_ = auVar13._4_4_;
        var_1a0h._0_4_ = iStack_a4;
        var_1a0h._4_4_ = iStack_a0;
        var_198h = iStack_9c;
        var_194h = iStack_98;
        var_190h._0_4_ = (int32_t)var_80h;
        var_190h._4_4_ = (int32_t)((uint64_t)var_80h >> 0x20);
        var_188h._0_4_ = (undefined4)var_160h;
        auVar5._4_4_ = uVar38;
        auVar5._0_4_ = uVar37;
        auVar5._8_4_ = uVar39;
        var_180h = auVar5._4_8_;
        var_174h._0_1_ = (char)var_8h;
        var_174h._1_2_ = uStack_147;
        var_174h._3_1_ = uStack_145;
        var_188h._4_4_ = uVar37;
        var_178h = uVar40;
        func_0x0001800f23a0(&piStack_c0);
        iVar20 = var_168h;
        if (*(char *)(arg1 + 0x58) == '\0') goto code_r0x0001800e625c;
        var_190h._4_4_ = 0;
        if (*(int32_t *)(arg1 + 0x80) != 0x2c) {
            var_190h._4_4_ = (*(int32_t *)(arg1 + 0x80) != 0x3b) + 1;
        }
        var_1a8h._0_4_ = 2;
        var_1a8h._4_4_ = iVar26;
        var_1a0h._0_4_ = iVar8;
        var_1a0h._4_4_ = (int32_t)uStack_108;
        var_198h = (int32_t)((uint64_t)uStack_108 >> 0x20);
        var_194h = (int32_t)uVar14;
        var_190h._0_4_ = (int32_t)((uint64_t)uVar14 >> 0x20);
        if (var_190h._4_4_ == 2) {
            iVar20 = 0xffffffff;
            var_188h._4_4_ = 0xffffffff;
        } else {
            iVar20 = *(int64_t *)(arg1 + 0x84);
            var_8h._4_4_ = (undefined4)((uint64_t)iVar20 >> 0x20);
            var_188h._4_4_ = var_8h._4_4_;
            var_8h = iVar20;
        }
        var_188h._0_4_ = (undefined4)iVar20;
        ppiVar25 = *(int64_t ***)(arg1 + 0xd8);
        iVar20 = (int64_t)*ppiVar25;
        if (iVar20 == 0) {
code_r0x0001800e5f6e:
            piVar31 = (int64_t *)func_0x000180459890(0x2008);
            *piVar31 = (int64_t)*ppiVar25;
            *ppiVar25 = piVar31;
            piVar31 = piVar31 + 1;
            piVar21 = (int64_t *)0x20;
        } else {
            piVar31 = (int64_t *)((int64_t)ppiVar25[1] + iVar20 + 0xf & 0xfffffffffffffff8);
            if ((int64_t *)(iVar20 + 0x2008U) < piVar31 + 4) goto code_r0x0001800e5f6e;
            piVar21 = (int64_t *)((int64_t)piVar31 + (0x20 - (iVar20 + 8)));
        }
        ppiVar25[1] = piVar21;
        *(undefined4 *)piVar31 = *(undefined4 *)0x180782a64;
        *(undefined4 *)(piVar31 + 1) = (undefined4)uStack_158;
        *(undefined4 *)((int64_t)piVar31 + 0xc) = uStack_158._4_4_;
        *(undefined4 *)(piVar31 + 2) = (undefined4)uStack_150;
        *(undefined4 *)((int64_t)piVar31 + 0x14) = uStack_150._4_4_;
        *(uint32_t *)(piVar31 + 3) = uStack_118;
        *(int32_t *)((int64_t)piVar31 + 0x1c) = var_160h._4_4_;
        var_178h = (undefined4)uVar23;
        var_174h._0_1_ = (char)((uint64_t)uVar23 >> 0x20);
        var_174h._1_2_ = (undefined2)((uint64_t)uVar23 >> 0x28);
        var_174h._3_1_ = (undefined)((uint64_t)uVar23 >> 0x38);
        var_180h = piVar31;
    } else {
        if (((piStack_b0 == (int64_t *)0x0) && (iVar20 == 0)) &&
           ((iVar18 != 0x119 || (piVar19 = (int32_t *)func_0x0001800d70e0(arg1 + 0x60, &var_1a8h), *piVar19 != 0x3a))))
        {
            iVar20 = func_0x0001800e8150(arg1, 0);
            var_18h._0_1_ = 1;
            iStack_f8 = (int32_t)uVar15;
            iStack_f4 = (int32_t)((uint64_t)uVar15 >> 0x20);
            iStack_f0 = (int32_t)uStack_e8;
            uStack_ec = uStack_e8._4_4_;
            uVar23 = func_0x0001800f1550(*(undefined8 *)(arg1 + 0xd8), &iStack_f8);
            var_1a8h._0_4_ = (int32_t)uVar23;
            var_1a8h._4_4_ = (int32_t)((uint64_t)uVar23 >> 0x20);
            var_1a0h._0_4_ = (int32_t)iVar20;
            var_1a0h._4_4_ = (int32_t)((uint64_t)iVar20 >> 0x20);
            var_198h = *(int32_t *)(iVar20 + 0xc);
            var_194h = *(int32_t *)(iVar20 + 0x10);
            var_190h._0_4_ = *(int32_t *)(iVar20 + 0x14);
            var_190h._4_4_ = *(int32_t *)(iVar20 + 0x18);
            auVar7._4_4_ = uVar38;
            auVar7._0_4_ = uVar37;
            auVar7._8_4_ = uVar39;
            var_180h = auVar7._4_8_;
            var_174h._1_2_ = uStack_147;
            var_174h._3_1_ = uStack_145;
            var_188h._0_4_ = (int32_t)iVar36;
            var_188h._4_4_ = uVar37;
            var_178h = uVar40;
            var_174h._0_1_ = cVar16;
            var_168h = func_0x0001800f14a0(*(undefined8 *)(arg1 + 0xd8), &var_1a8h);
            piVar31 = piStack_c0;
            piVar21 = piStack_d8;
            goto code_r0x0001800e6338;
        }
        if (*(int32_t *)(arg1 + 0x80) != 0x119) {
            func_0x0001800efe90(arg1, 0x1806436d0);
            piVar31 = piStack_c0;
            piVar21 = piStack_d8;
            goto code_r0x0001800e6338;
        }
        uVar23 = *(undefined8 *)(arg1 + 0x98);
        iVar18 = *(int32_t *)(arg1 + 0x84);
        iVar8 = *(int32_t *)(arg1 + 0x88);
        iVar9 = *(int32_t *)(arg1 + 0x8c);
        iVar10 = *(int32_t *)(arg1 + 0x90);
        fcn.1800f0350();
        if (*(int32_t *)(arg1 + 0x80) == 0x3a) {
            fcn.1800f0350(arg1);
code_r0x0001800e6175:
            uStack_100 = *(undefined8 *)(arg1 + 0xa0);
        } else {
            cVar17 = func_0x0001800ef2a0(arg1, 0x3a, 0x1806436d0);
            if (cVar17 != '\0') goto code_r0x0001800e6175;
            uStack_100 = 0xffffffffffffffff;
        }
        uVar14 = uStack_100;
        uVar22 = func_0x0001800e8150(arg1, (undefined)var_10h);
        var_1a8h._0_4_ = (int32_t)uVar23;
        var_1a8h._4_4_ = (int32_t)((uint64_t)uVar23 >> 0x20);
        var_190h._0_4_ = (int32_t)uVar22;
        var_190h._4_4_ = (int32_t)((uint64_t)uVar22 >> 0x20);
        auVar6._4_4_ = uVar38;
        auVar6._0_4_ = uVar37;
        auVar6._8_4_ = uVar39;
        var_180h = auVar6._4_8_;
        var_174h._1_2_ = uStack_147;
        var_174h._3_1_ = uStack_145;
        var_1a0h._0_4_ = iVar18;
        var_1a0h._4_4_ = iVar8;
        var_198h = iVar9;
        var_194h = iVar10;
        var_188h._0_4_ = (int32_t)iVar36;
        var_188h._4_4_ = uVar37;
        var_178h = uVar40;
        var_174h._0_1_ = cVar16;
        func_0x0001800f23a0(&piStack_c0);
        iVar20 = var_168h;
        if (*(char *)(arg1 + 0x58) == '\0') goto code_r0x0001800e625c;
        if (*(int32_t *)(arg1 + 0x80) != 0x2c) {
            iVar26 = (*(int32_t *)(arg1 + 0x80) != 0x3b) + 1;
        }
        var_1a8h._0_4_ = 1;
        var_1a8h._4_4_ = -1;
        var_1a0h._0_4_ = -1;
        var_1a0h._4_4_ = -1;
        var_198h = -1;
        var_194h = (int32_t)uVar14;
        var_190h._0_4_ = (int32_t)((uint64_t)uVar14 >> 0x20);
        if (iVar26 == 2) {
            iVar20 = 0xffffffff;
            var_188h._4_4_ = 0xffffffff;
        } else {
            iVar20 = *(int64_t *)(arg1 + 0x84);
            var_8h._4_4_ = (undefined4)((uint64_t)iVar20 >> 0x20);
            var_188h._4_4_ = var_8h._4_4_;
            var_8h = iVar20;
        }
        var_188h._0_4_ = (undefined4)iVar20;
        var_180h = (int64_t *)0x0;
        var_178h = 0;
        var_174h._0_1_ = '\0';
        var_174h._1_2_ = 0;
        var_174h._3_1_ = 0;
        var_190h._4_4_ = iVar26;
    }
    func_0x0001800f23a0(&piStack_d8);
    iVar20 = var_168h;
code_r0x0001800e625c:
    iVar18 = *(int32_t *)(arg1 + 0x80);
    if ((iVar18 == 0x2c) || (iVar18 == 0x3b)) {
        fcn.1800f0350(arg1);
    } else {
        piVar31 = piStack_c0;
        piVar21 = piStack_d8;
        if (iVar18 != 0x7d) goto code_r0x0001800e6338;
    }
    iVar18 = *(int32_t *)(arg1 + 0x80);
    piVar31 = piStack_c0;
    piVar21 = piStack_d8;
    if (iVar18 == 0x7d) goto code_r0x0001800e6338;
    goto code_r0x0001800e5b80;
}

// ============================================================
// Function: FUN_1800e6640
// Address: 0x1800e6640
// Size: 4060 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_208h
// WARNING: Variable defined which should be unmapped: var_200h
// WARNING: Variable defined which should be unmapped: var_1f8h
// WARNING: Variable defined which should be unmapped: var_1f0h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_2ch
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_1e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_1b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_1b0h
// WARNING: [rz-ghidra] Detected overlap for variable arg_a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

int64_t * fcn.1800e6640(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h,
                       int64_t arg_30h, undefined8 placeholder_6, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                       int64_t arg_58h, int64_t arg_60h, undefined8 placeholder_12, int64_t arg_70h,
                       undefined8 placeholder_14, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h,
                       undefined8 placeholder_18, int64_t arg_a0h, undefined8 placeholder_20, int64_t arg_b0h,
                       int64_t arg_130h, int64_t arg_138h, int64_t arg_140h, int64_t arg_148h)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    undefined4 *puVar3;
    int64_t *piVar4;
    int32_t iVar5;
    int64_t iVar6;
    code *pcVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    int64_t ***pppiVar15;
    bool bVar16;
    undefined4 uVar17;
    int64_t *piVar18;
    undefined4 uVar19;
    undefined4 uVar20;
    undefined uVar21;
    undefined8 *puVar22;
    int32_t *piVar23;
    undefined8 uVar24;
    int64_t *piVar25;
    uint64_t uVar26;
    int64_t *piVar27;
    int64_t *piVar28;
    int64_t **ppiVar29;
    bool bVar30;
    int64_t iVar31;
    int64_t *piVar32;
    int64_t iVar33;
    int64_t iVar34;
    int64_t **ppiVar35;
    int64_t *piVar36;
    int64_t *piVar37;
    undefined8 uStackX_8;
    int64_t *piStackX_10;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_208h;
    int64_t var_200h;
    int64_t var_1f8h;
    int64_t var_1f0h;
    char var_1e8h;
    int64_t var_1e7h;
    int64_t var_1d8h;
    int64_t var_1d0h;
    int64_t var_1c8h;
    int64_t var_1b8h;
    undefined4 var_1b0h;
    undefined4 uStack_1ac;
    undefined4 uStack_1a8;
    undefined4 uStack_1a4;
    undefined uStack_1a0;
    int64_t *piStack_198;
    int64_t iStack_190;
    int64_t iStack_188;
    int64_t *piStack_180;
    int64_t iStack_178;
    int64_t *piStack_170;
    int64_t iStack_168;
    int64_t *piStack_160;
    undefined4 uStack_158;
    undefined4 uStack_154;
    undefined4 uStack_150;
    undefined4 uStack_14c;
    undefined4 uStack_148;
    undefined4 uStack_144;
    undefined4 uStack_140;
    undefined4 uStack_13c;
    int64_t *piStack_138;
    int64_t iStack_130;
    int64_t *piStack_128;
    int64_t ****ppppiStack_120;
    undefined4 uStack_118;
    undefined4 uStack_114;
    undefined4 uStack_108;
    undefined4 uStack_104;
    undefined8 uStack_100;
    int64_t ***pppiStack_f8;
    undefined4 uStack_f0;
    undefined4 uStack_ec;
    undefined8 uStack_e8;
    undefined8 uStack_e0;
    int64_t *piStack_d8;
    int64_t iStack_d0;
    int64_t *piStack_c8;
    int64_t *piStack_b8;
    undefined4 uStack_b0;
    undefined4 uStack_ac;
    int64_t *piStack_a8;
    int64_t iStack_a0;
    int64_t *piStack_98;
    undefined4 uStack_88;
    undefined4 uStack_84;
    undefined4 uStack_80;
    undefined4 uStack_7c;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_2ch;
    int64_t var_20h;
    int64_t var_10h;
    int64_t var_8h;
    
    *(int32_t *)(arg1 + 0x114) = *(int32_t *)(arg1 + 0x114) + 1;
    piStackX_10 = (int64_t *)arg2;
    var_18h._0_1_ = (char)placeholder_2;
    iStackX_20 = arg4;
    if (*(uint32_t *)0x180778500 < *(uint32_t *)(arg1 + 0x114)) {
        iVar33 = func_0x0001800d90d0(arg1 + 0x60);
        func_0x0001800d9940(iVar33 + 4, 0x180644050, 0x1806436c0);
        pcVar7 = (code *)swi(3);
        piVar27 = (int64_t *)(*pcVar7)();
        return piVar27;
    }
    iVar5 = *(int32_t *)(arg1 + 0x80);
    uStack_88 = *(undefined4 *)(arg1 + 0x80);
    uStack_84 = *(undefined4 *)(arg1 + 0x84);
    uStack_80 = *(undefined4 *)(arg1 + 0x88);
    uStack_7c = *(undefined4 *)(arg1 + 0x8c);
    var_78h._0_4_ = *(undefined4 *)(arg1 + 0x90);
    var_78h._4_4_ = *(undefined4 *)(arg1 + 0x94);
    var_70h._0_4_ = *(undefined4 *)(arg1 + 0x98);
    var_70h._4_4_ = *(undefined4 *)(arg1 + 0x9c);
    uStack_100 = 0xffffffffffffffff;
    piVar27 = (int64_t *)0x0;
    uStack_e8 = (int64_t *)0x0;
    uStack_e0 = 0;
    var_1c8h = -1;
    if (*(char *)(arg1 + 0x58) == '\0') {
        var_200h = 0;
        var_208h = 0;
        puVar22 = (undefined8 *)0x0;
        ppiVar29 = &piStack_d8;
    } else {
        var_200h = (int64_t)&var_1c8h;
        var_208h = (int64_t)&uStack_e8;
        puVar22 = &uStack_100;
        ppiVar29 = &piStack_a8;
    }
    puVar22 = (undefined8 *)func_0x0001800ecbd0(uStack_88, ppiVar29, 0, puVar22, var_208h, var_200h);
    pppiVar15 = (int64_t ***)*puVar22;
    uVar8 = *(undefined4 *)(puVar22 + 1);
    uVar9 = *(undefined4 *)((int64_t)puVar22 + 0xc);
    piVar37 = (int64_t *)puVar22[2];
    uVar10 = *(undefined4 *)(puVar22 + 3);
    uVar11 = *(undefined4 *)((int64_t)puVar22 + 0x1c);
    uStackX_8 = (int64_t ***)CONCAT44(uStackX_8._4_4_, *(int32_t *)(arg1 + 0x80));
    uStack_154 = *(undefined4 *)(arg1 + 0x84);
    uStack_150 = *(undefined4 *)(arg1 + 0x88);
    uStack_14c = *(undefined4 *)(arg1 + 0x8c);
    uStack_148 = *(undefined4 *)(arg1 + 0x90);
    uStack_144 = *(undefined4 *)(arg1 + 0x94);
    uStack_140 = *(undefined4 *)(arg1 + 0x98);
    uStack_13c = *(undefined4 *)(arg1 + 0x9c);
    if (*(int32_t *)(arg1 + 0x80) == 0x28) {
        fcn.1800f0350(arg1);
        var_1e8h = '\x01';
    } else {
        var_1e8h = func_0x0001800ef2a0(arg1, 0x28, 0x1806435a8);
    }
    piVar23 = (int32_t *)(*(int64_t *)(arg1 + 0x1e8) + 0x41c);
    *piVar23 = *piVar23 + 1;
    piStack_138 = (int64_t *)(arg1 + 0x350);
    iStack_188 = *(int64_t *)(arg1 + 0x358) - *piStack_138 >> 3;
    piStack_128 = (int64_t *)0x0;
    var_1d8h = arg1 + 0x428;
    var_1d0h = *(int64_t *)(arg1 + 0x430) - *(int64_t *)var_1d8h >> 5;
    piStack_160 = (int64_t *)0x0;
    piStack_180 = (int64_t *)(arg1 + 0x440);
    iStack_178 = *(int64_t *)(arg1 + 0x448) - *piStack_180 >> 3;
    piStack_c8 = (int64_t *)0x0;
    piStack_198 = (int64_t *)(arg1 + 0x458);
    iStack_190 = *(int64_t *)(arg1 + 0x460) - *piStack_198 >> 3;
    piStack_98 = (int64_t *)0x0;
    stack0xfffffffffffffe20 = (int64_t *)0x0;
    piVar25 = piVar27;
    piStack_170 = (int64_t *)var_1d8h;
    iStack_168 = var_1d0h;
    iStack_130 = iStack_188;
    piStack_d8 = piStack_180;
    iStack_d0 = iStack_178;
    piStack_a8 = piStack_198;
    iStack_a0 = iStack_190;
    if (*(int32_t *)(arg1 + 0x80) != 0x29) {
        if (*(char *)(arg1 + 0x58) == '\0') {
            do {
                piVar25 = piStack_128;
                if ((*(int32_t *)(arg1 + 0x80) == 0x106) ||
                   ((*(int32_t *)(arg1 + 0x80) == 0x119 &&
                    (piVar23 = (int32_t *)func_0x0001800d70e0(arg1 + 0x60, &var_1b8h), *piVar23 == 0x106)))) {
                    *(int64_t *)0x0 = (int64_t *)func_0x0001800e8e20(arg1);
                    goto code_r0x0001800e6bb6;
                }
                if ((*(int32_t *)(arg1 + 0x80) == 0x119) &&
                   (piVar23 = (int32_t *)func_0x0001800d70e0(arg1 + 0x60, &var_1b8h), *piVar23 == 0x3a)) {
                    while (piStack_160 < piVar25) {
                        uStack_1a0 = 0;
                        func_0x0001800f1e20(&piStack_170, &var_1b8h);
                    }
                    ppppiStack_120 = *(int64_t *****)(arg1 + 0x98);
                    var_1b8h._0_4_ = SUB84(ppppiStack_120, 0);
                    var_1b8h._4_4_ = (undefined4)((uint64_t)ppppiStack_120 >> 0x20);
                    var_1b0h = *(undefined4 *)(arg1 + 0x84);
                    uStack_1ac = *(undefined4 *)(arg1 + 0x88);
                    uStack_1a8 = *(undefined4 *)(arg1 + 0x8c);
                    uStack_1a4 = *(undefined4 *)(arg1 + 0x90);
                    uStack_108._1_3_ = (unkbyte3)((uint32_t)uStack_1a8 >> 8);
                    uStack_108 = CONCAT31(uStack_108._1_3_, 1);
                    uStack_118 = var_1b0h;
                    uStack_114 = uStack_1ac;
                    uStack_104 = uStack_1a4;
                    func_0x0001800f1e20(&piStack_170, &ppppiStack_120);
                    fcn.1800f0350(arg1);
                    if (*(int32_t *)(arg1 + 0x80) == 0x3a) {
                        fcn.1800f0350(arg1);
                    } else {
                        func_0x0001800ef2a0(arg1, 0x3a, 0);
                    }
                } else if (piStack_160 != (int64_t *)0x0) {
                    uStack_1a0 = 0;
                    func_0x0001800f1e20(&piStack_170, &var_1b8h);
                }
                uVar24 = func_0x0001800e8150(arg1, 0);
                var_1b8h._0_4_ = (undefined4)uVar24;
                var_1b8h._4_4_ = (undefined4)((uint64_t)uVar24 >> 0x20);
                func_0x0001800f1a70(&piStack_138);
                if (*(int32_t *)(arg1 + 0x80) != 0x2c) goto code_r0x0001800e6b7c;
                fcn.1800f0350(arg1);
            } while (*(int32_t *)(arg1 + 0x80) != 0x29);
            fcn.1800efe70(arg1, arg1 + 0x84, 0x180643400);
code_r0x0001800e6b7c:
            stack0xfffffffffffffe20 = (int64_t *)0x0;
            piVar25 = piStack_128;
        } else {
            do {
                piVar25 = piStack_128;
                if ((*(int32_t *)(arg1 + 0x80) == 0x106) ||
                   ((*(int32_t *)(arg1 + 0x80) == 0x119 &&
                    (piVar23 = (int32_t *)func_0x0001800d70e0(arg1 + 0x60, &var_1b8h), *piVar23 == 0x106)))) {
                    *(int64_t *)0x0 = (int64_t *)func_0x0001800e8e20(arg1);
                    goto code_r0x0001800e69f7;
                }
                if ((*(int32_t *)(arg1 + 0x80) == 0x119) &&
                   (piVar23 = (int32_t *)func_0x0001800d70e0(arg1 + 0x60, &var_1b8h), *piVar23 == 0x3a)) {
                    while (piStack_160 < piVar25) {
                        uStack_1a0 = 0;
                        func_0x0001800f1e20(&piStack_170, &var_1b8h);
                    }
                    while (piStack_c8 < piVar25) {
                        var_1d8h = -1;
                        func_0x0001800f1a70(&piStack_d8, &var_1d8h);
                    }
                    ppppiStack_120 = *(int64_t *****)(arg1 + 0x98);
                    var_1b8h._0_4_ = SUB84(ppppiStack_120, 0);
                    var_1b8h._4_4_ = (undefined4)((uint64_t)ppppiStack_120 >> 0x20);
                    var_1b0h = *(undefined4 *)(arg1 + 0x84);
                    uStack_1ac = *(undefined4 *)(arg1 + 0x88);
                    uStack_1a8 = *(undefined4 *)(arg1 + 0x8c);
                    uStack_1a4 = *(undefined4 *)(arg1 + 0x90);
                    uStack_108._1_3_ = (unkbyte3)((uint32_t)uStack_1a8 >> 8);
                    uStack_108 = CONCAT31(uStack_108._1_3_, 1);
                    uStack_118 = var_1b0h;
                    uStack_114 = uStack_1ac;
                    uStack_104 = uStack_1a4;
                    func_0x0001800f1e20(&piStack_170, &ppppiStack_120);
                    fcn.1800f0350(arg1);
                    func_0x0001800f1a70(&piStack_d8, arg1 + 0x84);
                    if (*(int32_t *)(arg1 + 0x80) == 0x3a) {
                        fcn.1800f0350(arg1);
                    } else {
                        func_0x0001800ef2a0(arg1, 0x3a, 0);
                    }
                } else if (piStack_160 != (int64_t *)0x0) {
                    uStack_1a0 = 0;
                    func_0x0001800f1e20(&piStack_170, &var_1b8h);
                    var_1d0h = -1;
                    func_0x0001800f1a70(&piStack_d8, &var_1d0h);
                }
                uVar24 = func_0x0001800e8150(arg1, 0);
                var_1b8h._0_4_ = (undefined4)uVar24;
                var_1b8h._4_4_ = (undefined4)((uint64_t)uVar24 >> 0x20);
                func_0x0001800f1a70(&piStack_138, &var_1b8h);
                if (*(int32_t *)(arg1 + 0x80) != 0x2c) goto code_r0x0001800e69db;
                func_0x0001800f1a70(&piStack_a8);
                fcn.1800f0350(arg1);
            } while (*(int32_t *)(arg1 + 0x80) != 0x29);
            fcn.1800efe70(arg1, arg1 + 0x84, 0x180643400);
code_r0x0001800e69db:
            stack0xfffffffffffffe20 = (int64_t *)0x0;
            piVar25 = piStack_128;
code_r0x0001800e69f7:
            iStack_178 = iStack_d0;
            piStack_180 = piStack_d8;
            iStack_190 = iStack_a0;
            piStack_198 = piStack_a8;
            piVar27 = piStack_98;
        }
    }
code_r0x0001800e6bb6:
    piVar18 = piStack_138;
    uVar13 = uStack_150;
    uVar12 = uStack_154;
    iVar33 = iStack_168;
    piVar28 = piStack_170;
    ppppiStack_120 = *(int64_t *****)(arg1 + 0x84);
    uStack_118 = *(undefined4 *)(arg1 + 0x8c);
    uStack_114 = *(undefined4 *)(arg1 + 0x90);
    var_1b8h._0_4_ = (undefined4)uStackX_8;
    piVar36 = (int64_t *)CONCAT44(uStack_150, uStack_154);
    var_1b8h._4_4_ = uStack_154;
    var_1b0h = uStack_150;
    var_1d8h = (int64_t)piStack_170;
    var_1d0h = iStack_168;
    iStack_188 = iStack_130;
    if (*(int32_t *)(arg1 + 0x80) == 0x29) {
        fcn.1800f0350(arg1);
        uStackX_8 = (int64_t ***)CONCAT71(uStackX_8._1_7_, 1);
    } else {
        func_0x0001800ef5a0(arg1, 0x29, &var_1b8h, 0);
        uVar21 = func_0x0001800ef4e0(arg1, 0x29);
        uStackX_8 = (int64_t ***)CONCAT71(uStackX_8._1_7_, uVar21);
    }
    piVar23 = (int32_t *)(*(int64_t *)(arg1 + 0x1e8) + 0x41c);
    *piVar23 = *piVar23 + -1;
    if (piVar25 == (int64_t *)0x0) {
        iVar34 = 0;
    } else {
        iVar34 = *piVar18 + iStack_188 * 8;
    }
    func_0x0001800f1110(arg1, &uStack_158, iVar34, piVar25);
    uVar17 = uStack_14c;
    uVar14 = uStack_150;
    piVar4 = piStack_160;
    bVar30 = piStack_160 != (int64_t *)0x0 || iVar5 == 0x3c;
    if ((*(int32_t *)(arg1 + 0x80) == 0x107) || (*(int32_t *)(arg1 + 0x80) == 0x3a)) {
        bVar16 = true;
    } else {
        bVar16 = false;
    }
    uStack_150 = SUB84(piVar27, 0);
    uVar19 = uStack_150;
    uStack_14c = (undefined4)((uint64_t)piVar27 >> 0x20);
    uVar20 = uStack_14c;
    uStack_150 = uVar14;
    uStack_14c = uVar17;
    if ((piVar25 == (int64_t *)0x1) && (stack0xfffffffffffffe20 == (int64_t *)0x0)) {
        if ((bVar30) || (bVar16)) goto code_r0x0001800e722d;
        ppiVar29 = *(int64_t ***)(arg1 + 0xd8);
        iVar34 = (int64_t)*ppiVar29;
        if ((char)var_18h == '\0') {
            iVar6 = *piVar18;
            iVar31 = iStack_188 * 8;
            uStack_e0._0_4_ = uStack_118;
            uStack_e0._4_4_ = uStack_114;
            uStack_e8 = piVar36;
            if (iVar34 == 0) {
code_r0x0001800e6efd:
                ppiVar35 = (int64_t **)func_0x000180459890(0x2008);
                *ppiVar35 = *ppiVar29;
                *ppiVar29 = (int64_t *)ppiVar35;
                ppiVar35 = ppiVar35 + 1;
                piVar27 = (int64_t *)0x28;
            } else {
                ppiVar35 = (int64_t **)((int64_t)ppiVar29[1] + iVar34 + 0xf & 0xfffffffffffffff8);
                if ((int64_t **)(iVar34 + 0x2008) < ppiVar35 + 5) goto code_r0x0001800e6efd;
                piVar27 = (int64_t *)((int64_t)ppiVar35 + (0x28 - (iVar34 + 8)));
            }
            ppiVar29[1] = piVar27;
            piVar27 = *(int64_t **)(iVar6 + iVar31);
            *(undefined4 *)(ppiVar35 + 1) = *(undefined4 *)0x180782784;
            *(undefined4 *)((int64_t)ppiVar35 + 0xc) = (undefined4)uStack_e8;
            *(undefined4 *)(ppiVar35 + 2) = uStack_e8._4_4_;
            *(undefined4 *)((int64_t)ppiVar35 + 0x14) = (undefined4)uStack_e0;
            *(undefined4 *)(ppiVar35 + 3) = uStack_e0._4_4_;
            *ppiVar35 = (int64_t *)0x180641d70;
            ppiVar35[4] = piVar27;
            if ((*(char *)0x180778140 != '\0') && (*(char *)(arg1 + 0x58) != '\0')) {
                if ((char)uStackX_8 == '\0') {
                    uStackX_8 = (int64_t ***)0xffffffffffffffff;
                } else {
                    uStackX_8 = (int64_t ***)ppppiStack_120;
                }
                uVar24 = func_0x0001800f1400(*(undefined8 *)(arg1 + 0xd8), &uStackX_8);
                uStackX_8 = (int64_t ***)ppiVar35;
                puVar22 = (undefined8 *)func_0x0001800cc970(arg1 + 0x490, &uStackX_8);
                *puVar22 = uVar24;
            }
            *piStackX_10 = (int64_t)ppiVar35;
            piStackX_10[1] = 0;
            iVar34 = *piStack_198 + iStack_190 * 8;
            if (iVar34 != piStack_198[1]) {
                piStack_198[1] = iVar34;
            }
            iVar34 = *piStack_180 + iStack_178 * 8;
            if (iVar34 != piStack_180[1]) {
                piStack_180[1] = iVar34;
            }
            iVar33 = *(int64_t *)var_1d8h + iVar33 * 0x20;
        } else {
            if (iVar34 == 0) {
code_r0x0001800e6ce1:
                piVar37 = (int64_t *)func_0x000180459890(0x2008);
                *piVar37 = (int64_t)*ppiVar29;
                *ppiVar29 = piVar37;
                piVar37 = piVar37 + 1;
                piVar25 = (int64_t *)0x38;
            } else {
                piVar37 = (int64_t *)((int64_t)ppiVar29[1] + iVar34 + 0xf & 0xfffffffffffffff8);
                if ((int64_t *)(iVar34 + 0x2008) < piVar37 + 7) goto code_r0x0001800e6ce1;
                piVar25 = (int64_t *)((int64_t)piVar37 + (0x38 - (iVar34 + 8)));
            }
            ppiVar29[1] = piVar25;
            *(undefined4 *)(piVar37 + 1) = *(undefined4 *)0x18078268c;
            *(undefined4 *)((int64_t)piVar37 + 0xc) = uStack_84;
            *(undefined4 *)(piVar37 + 2) = uStack_80;
            *(undefined4 *)((int64_t)piVar37 + 0x14) = uStack_7c;
            *(undefined4 *)(piVar37 + 3) = (undefined4)var_78h;
            *piVar37 = 0x180641fc8;
            *(undefined4 *)(piVar37 + 4) = uStack_158;
            *(undefined4 *)((int64_t)piVar37 + 0x24) = uStack_154;
            *(undefined4 *)(piVar37 + 5) = uStack_150;
            *(undefined4 *)((int64_t)piVar37 + 0x2c) = uStack_14c;
            piVar37[6] = 0;
            if (*(char *)(arg1 + 0x58) != '\0') {
                uVar24 = *(undefined8 *)(arg1 + 0xd8);
                uStack_158 = uVar19;
                uVar8 = uVar20;
                if (piVar27 != (int64_t *)0x0) {
                    iVar33 = *piStack_198;
                    uVar26 = func_0x0001800d4d20(uVar24, (int64_t)piVar27 * 8);
                    uStack_158 = (undefined4)uVar26;
                    uStack_154 = (undefined4)(uVar26 >> 0x20);
                    uVar8 = uStack_154;
                    if (piVar27 != (int64_t *)0x0) {
                        uVar1 = iVar33 + iStack_190 * 8;
                        piVar25 = (int64_t *)0x0;
                        if ((piVar27 < (int64_t *)0x2) ||
                           ((uVar26 <= (uVar1 - 8) + (int64_t)piVar27 * 8 &&
                            (piVar25 = (int64_t *)0x0, uVar1 <= uVar26 + ((int64_t)piVar27 + -1) * 8)))) {
                            do {
                                *(undefined8 *)(uVar26 + (int64_t)piVar25 * 8) =
                                     *(undefined8 *)(uVar1 + (int64_t)piVar25 * 8);
                                piVar25 = (int64_t *)((int64_t)piVar25 + 1);
                            } while (piVar25 < piVar27);
                        } else {
                            uStack_150 = uVar19;
                            uStack_14c = uVar20;
                            func_0x000180498030(uVar26, uVar1, (int64_t)piVar27 * 8);
                            uVar8 = uStack_154;
                            uVar19 = uStack_150;
                            uVar20 = uStack_14c;
                        }
                    }
                }
                uStack_14c = uVar20;
                uStack_150 = uVar19;
                uStack_154 = uVar8;
                if ((char)uStackX_8 == '\0') {
                    uStackX_8 = (int64_t ***)0xffffffffffffffff;
                } else {
                    uStackX_8 = (int64_t ***)ppppiStack_120;
                }
                if (var_1e8h == '\0') {
                    var_1c8h = -1;
                    piVar27 = &var_1c8h;
                } else {
                    var_1b8h._0_4_ = uVar12;
                    var_1b8h._4_4_ = uVar13;
                    piVar27 = &var_1b8h;
                }
                uVar24 = func_0x0001800f1670(uVar24, piVar27, &uStackX_8, &uStack_158);
                uStackX_8 = (int64_t ***)piVar37;
                puVar22 = (undefined8 *)func_0x0001800cc970(arg1 + 0x490, &uStackX_8);
                *puVar22 = uVar24;
            }
            *piStackX_10 = 0;
            piStackX_10[1] = (int64_t)piVar37;
            iVar33 = *piStack_198 + iStack_190 * 8;
            if (iVar33 != piStack_198[1]) {
                piStack_198[1] = iVar33;
            }
            iVar33 = *piStack_180 + iStack_178 * 8;
            if (iVar33 != piStack_180[1]) {
                piStack_180[1] = iVar33;
            }
            iVar33 = var_1d0h * 0x20 + *(int64_t *)var_1d8h;
        }
        if (iVar33 != *(int64_t *)(var_1d8h + 8)) {
            *(int64_t *)(var_1d8h + 8) = iVar33;
        }
        goto code_r0x0001800e75be;
    }
    if (((bVar30) || (bVar16)) || ((char)var_18h == '\0')) {
code_r0x0001800e722d:
        if (piStack_160 == (int64_t *)0x0) {
            iVar33 = 0;
        } else {
            iVar34 = var_1d0h * 0x20 + *piVar28;
            iVar33 = func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8));
            piVar25 = (int64_t *)0x0;
            if (piVar4 != (int64_t *)0x0) {
                do {
                    iVar31 = (int64_t)piVar25 * 0x20;
                    puVar2 = (undefined4 *)(iVar34 + iVar31);
                    uVar12 = puVar2[1];
                    uVar13 = puVar2[2];
                    uVar14 = puVar2[3];
                    puVar3 = (undefined4 *)(iVar31 + iVar33);
                    *puVar3 = *puVar2;
                    puVar3[1] = uVar12;
                    puVar3[2] = uVar13;
                    puVar3[3] = uVar14;
                    puVar2 = (undefined4 *)(iVar34 + 0x10 + iVar31);
                    uVar12 = puVar2[1];
                    uVar13 = puVar2[2];
                    uVar14 = puVar2[3];
                    puVar3 = (undefined4 *)(iVar31 + 0x10 + iVar33);
                    *puVar3 = *puVar2;
                    puVar3[1] = uVar12;
                    puVar3[2] = uVar13;
                    puVar3[3] = uVar14;
                    piVar25 = (int64_t *)((int64_t)piVar25 + 1);
                } while (piVar25 < piVar4);
            }
        }
        piVar25 = *(int64_t **)(arg1 + 0x84);
        var_1b8h._0_4_ = (undefined4)iVar33;
        var_1b8h._4_4_ = (undefined4)((uint64_t)iVar33 >> 0x20);
        var_1b0h = SUB84(piVar4, 0);
        uStack_1ac = (undefined4)((uint64_t)piVar4 >> 0x20);
        pppiStack_f8 = pppiVar15;
        uStack_f0 = uVar8;
        uStack_ec = uVar9;
        piStack_b8 = piVar37;
        uStack_b0 = uVar10;
        uStack_ac = uVar11;
        iVar33 = func_0x0001800e7620(arg1, &uStack_88, iStackX_20, &pppiStack_f8, &piStack_b8, &uStack_158, &var_1b8h, 
                                     stack0xfffffffffffffe20);
        var_1b8h._0_4_ = (undefined4)iVar33;
        var_1b8h._4_4_ = (undefined4)((uint64_t)iVar33 >> 0x20);
        if ((*(char *)(arg1 + 0x58) != '\0') && (*(int32_t *)(iVar33 + 8) == *(int32_t *)0x1807826ac)) {
            uVar24 = *(undefined8 *)(arg1 + 0xd8);
            uStack_158 = (undefined4)uVar24;
            uStack_154 = (undefined4)((uint64_t)uVar24 >> 0x20);
            if ((char)uStackX_8 == '\0') {
                pppiStack_f8 = (int64_t ***)0xffffffffffffffff;
            } else {
                pppiStack_f8 = (int64_t ***)ppppiStack_120;
            }
            ppppiStack_120 = &pppiStack_f8;
            if (piVar27 == (int64_t *)0x0) {
                unique0x1000146d = (int64_t *)0x0;
            } else {
                iVar33 = *piStack_198;
                *(int64_t **)0x0 = (int64_t *)func_0x0001800d4d20(uVar24, (int64_t)piVar27 * 8);
                if (piVar27 != (int64_t *)0x0) {
                    piVar37 = (int64_t *)(iVar33 + iStack_190 * 8);
                    piVar28 = (int64_t *)0x0;
                    if ((piVar27 < (int64_t *)0x2) ||
                       ((*(int64_t **)0x0 <= piVar37 + (int64_t)piVar27 + -1 &&
                        (piVar37 <= *(int64_t **)0x0 + (int64_t)piVar27 + -1)))) {
                        do {
                            (*(int64_t **)0x0)[(int64_t)piVar28] = piVar37[(int64_t)piVar28];
                            piVar28 = (int64_t *)((int64_t)piVar28 + 1);
                        } while (piVar28 < piVar27);
                    } else {
                        func_0x000180498030(*(int64_t **)0x0, piVar37, (int64_t)piVar27 * 8);
                    }
                }
            }
            piVar37 = piStack_c8;
            if (piStack_c8 == (int64_t *)0x0) {
                uStackX_8 = (int64_t ***)piStack_c8;
                piVar28 = (int64_t *)uStackX_8;
            } else {
                uStackX_8 = (int64_t ***)*piStack_180;
                piVar28 = (int64_t *)func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), (int64_t)piStack_c8 * 8);
                if (piVar37 != (int64_t *)0x0) {
                    piVar4 = (int64_t *)((int64_t)uStackX_8 + iStack_178 * 8);
                    piVar32 = (int64_t *)0x0;
                    if ((piVar37 < (int64_t *)0x2) ||
                       ((piVar28 <= piVar4 + (int64_t)piVar37 + -1 && (piVar4 <= piVar28 + (int64_t)piVar37 + -1)))) {
                        do {
                            piVar28[(int64_t)piVar32] = piVar4[(int64_t)piVar32];
                            piVar32 = (int64_t *)((int64_t)piVar32 + 1);
                        } while (piVar32 < piVar37);
                    } else {
                        uStackX_8 = (int64_t ***)piVar28;
                        func_0x000180498030(piVar28, piVar4, (int64_t)piVar37 * 8);
                    }
                }
            }
            uStackX_8 = (int64_t ***)piVar28;
            if (var_1e8h == '\0') {
                piStack_b8 = (int64_t *)0xffffffffffffffff;
                piVar36 = (int64_t *)0xffffffffffffffff;
            }
            ppiVar29 = (int64_t **)CONCAT44(uStack_154, uStack_158);
            piVar28 = *ppiVar29;
            if (piVar28 == (int64_t *)0x0) {
code_r0x0001800e74c2:
                ppiVar35 = (int64_t **)func_0x000180459890(0x2008);
                ppiVar29 = (int64_t **)CONCAT44(uStack_154, uStack_158);
                *ppiVar35 = *ppiVar29;
                *ppiVar29 = (int64_t *)ppiVar35;
                ppiVar35 = ppiVar35 + 1;
                piVar28 = (int64_t *)0x60;
            } else {
                ppiVar35 = (int64_t **)((int64_t)ppiVar29[1] + 7 + (int64_t)(piVar28 + 1) & 0xfffffffffffffff8);
                if (piVar28 + 0x401 < ppiVar35 + 0xc) goto code_r0x0001800e74c2;
                piVar28 = (int64_t *)((int64_t)ppiVar35 + (0x60 - (int64_t)(piVar28 + 1)));
            }
            ppiVar29[1] = piVar28;
            *(undefined4 *)ppiVar35 = *(undefined4 *)0x180782a74;
            *(undefined8 *)((int64_t)ppiVar35 + 4) = uStack_100;
            *(undefined4 *)(ppiVar35 + 2) = (undefined4)uStack_e8;
            *(undefined4 *)((int64_t)ppiVar35 + 0x14) = uStack_e8._4_4_;
            *(undefined4 *)(ppiVar35 + 3) = (undefined4)uStack_e0;
            *(undefined4 *)((int64_t)ppiVar35 + 0x1c) = uStack_e0._4_4_;
            ppiVar35[4] = (int64_t *)var_1c8h;
            ppiVar35[5] = piVar36;
            ppiVar35[6] = (int64_t *)uStackX_8;
            ppiVar35[7] = piVar37;
            ppiVar35[8] = stack0xfffffffffffffe20;
            ppiVar35[9] = piVar27;
            ppiVar35[10] = (int64_t *)*ppppiStack_120;
            ppiVar35[0xb] = piVar25;
            uStackX_8 = (int64_t ***)CONCAT44(var_1b8h._4_4_, (undefined4)var_1b8h);
            ppiVar29 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &uStackX_8);
            *ppiVar29 = (int64_t *)ppiVar35;
            iVar33 = CONCAT44(var_1b8h._4_4_, (undefined4)var_1b8h);
        }
        *piStackX_10 = iVar33;
        piStackX_10[1] = 0;
        iVar33 = *piStack_198 + iStack_190 * 8;
        if (iVar33 != piStack_198[1]) {
            piStack_198[1] = iVar33;
        }
        iVar33 = *piStack_180 + iStack_178 * 8;
        if (iVar33 != piStack_180[1]) {
            piStack_180[1] = iVar33;
        }
        iVar33 = var_1d0h * 0x20 + *(int64_t *)var_1d8h;
        if (iVar33 != *(int64_t *)(var_1d8h + 8)) {
            *(int64_t *)(var_1d8h + 8) = iVar33;
        }
        goto code_r0x0001800e75be;
    }
    ppiVar29 = *(int64_t ***)(arg1 + 0xd8);
    var_1b8h._0_4_ = SUB84(ppiVar29, 0);
    var_1b8h._4_4_ = (undefined4)((uint64_t)ppiVar29 >> 0x20);
    iVar33 = (int64_t)*ppiVar29;
    if (iVar33 == 0) {
code_r0x0001800e7064:
        piVar37 = (int64_t *)func_0x000180459890(0x2008);
        *piVar37 = (int64_t)*ppiVar29;
        *ppiVar29 = piVar37;
        piVar37 = piVar37 + 1;
        piVar25 = (int64_t *)0x38;
    } else {
        piVar37 = (int64_t *)((int64_t)ppiVar29[1] + iVar33 + 0xf & 0xfffffffffffffff8);
        if ((int64_t *)(iVar33 + 0x2008) < piVar37 + 7) goto code_r0x0001800e7064;
        piVar25 = (int64_t *)((int64_t)piVar37 + (0x38 - (iVar33 + 8)));
    }
    ppiVar29[1] = piVar25;
    *(undefined4 *)(piVar37 + 1) = *(undefined4 *)0x18078268c;
    *(undefined4 *)((int64_t)piVar37 + 0xc) = uStack_84;
    *(undefined4 *)(piVar37 + 2) = uStack_80;
    *(undefined4 *)((int64_t)piVar37 + 0x14) = uStack_7c;
    *(undefined4 *)(piVar37 + 3) = (undefined4)var_78h;
    *piVar37 = 0x180641fc8;
    *(undefined4 *)(piVar37 + 4) = uStack_158;
    *(undefined4 *)((int64_t)piVar37 + 0x24) = uStack_154;
    *(undefined4 *)(piVar37 + 5) = uStack_150;
    *(undefined4 *)((int64_t)piVar37 + 0x2c) = uStack_14c;
    piVar37[6] = (int64_t)stack0xfffffffffffffe20;
    if (*(char *)(arg1 + 0x58) != '\0') {
        var_1d8h = *(int64_t *)(arg1 + 0xd8);
        uStack_158 = uVar19;
        uVar8 = uVar20;
        if (piVar27 != (int64_t *)0x0) {
            iVar33 = *piStack_198;
            uVar26 = func_0x0001800d4d20(var_1d8h, (int64_t)piVar27 * 8);
            uStack_158 = (undefined4)uVar26;
            uStack_154 = (undefined4)(uVar26 >> 0x20);
            uVar8 = uStack_154;
            if (piVar27 != (int64_t *)0x0) {
                uVar1 = iVar33 + iStack_190 * 8;
                piVar25 = (int64_t *)0x0;
                if ((piVar27 < (int64_t *)0x2) ||
                   ((uVar26 <= (uVar1 - 8) + (int64_t)piVar27 * 8 &&
                    (piVar25 = (int64_t *)0x0, uVar1 <= uVar26 + ((int64_t)piVar27 + -1) * 8)))) {
                    do {
                        *(undefined8 *)(uVar26 + (int64_t)piVar25 * 8) = *(undefined8 *)(uVar1 + (int64_t)piVar25 * 8);
                        piVar25 = (int64_t *)((int64_t)piVar25 + 1);
                    } while (piVar25 < piVar27);
                } else {
                    uStack_150 = uVar19;
                    uStack_14c = uVar20;
                    func_0x000180498030(uVar26, uVar1, (int64_t)piVar27 * 8);
                    uVar8 = uStack_154;
                    uVar19 = uStack_150;
                    uVar20 = uStack_14c;
                }
            }
        }
        uStack_14c = uVar20;
        uStack_150 = uVar19;
        uStack_154 = uVar8;
        if ((char)uStackX_8 == '\0') {
            uStackX_8 = (int64_t ***)0xffffffffffffffff;
        } else {
            uStackX_8 = (int64_t ***)ppppiStack_120;
        }
        if (var_1e8h == '\0') {
            var_1c8h = -1;
            piVar27 = &var_1c8h;
        } else {
            var_1b8h._0_4_ = uVar12;
            var_1b8h._4_4_ = uVar13;
            piVar27 = &var_1b8h;
        }
        uVar24 = func_0x0001800f1670(var_1d8h, piVar27, &uStackX_8, &uStack_158);
        uStackX_8 = (int64_t ***)piVar37;
        puVar22 = (undefined8 *)func_0x0001800cc970(arg1 + 0x490, &uStackX_8);
        *puVar22 = uVar24;
    }
    *piStackX_10 = 0;
    piStackX_10[1] = (int64_t)piVar37;
    iVar33 = *piStack_198 + iStack_190 * 8;
    if (iVar33 != piStack_198[1]) {
        piStack_198[1] = iVar33;
    }
    iVar33 = *piStack_180 + iStack_178 * 8;
    if (iVar33 != piStack_180[1]) {
        piStack_180[1] = iVar33;
    }
    iVar33 = var_1d0h * 0x20 + *piVar28;
    if (iVar33 != piVar28[1]) {
        piVar28[1] = iVar33;
    }
code_r0x0001800e75be:
    iVar33 = *piVar18 + iStack_188 * 8;
    if (iVar33 != piVar18[1]) {
        piVar18[1] = iVar33;
    }
    return piStackX_10;
}

// ============================================================
// Function: FUN_1800e7620
// Address: 0x1800e7620
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_3fh
// WARNING: [rz-ghidra] Detected overlap for variable var_3bh
// WARNING: [rz-ghidra] Detected overlap for variable var_39h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h

int64_t * fcn.1800e7620(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                       int64_t arg_38h, int64_t arg_40h)
{
    int64_t **ppiVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    uint32_t uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t iVar12;
    int64_t *piVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    undefined var_38h;
    int64_t var_37h;
    int64_t var_28h;
    
    *(int32_t *)(arg1 + 0x114) = *(int32_t *)(arg1 + 0x114) + 1;
    if (*(uint32_t *)0x180778500 < *(uint32_t *)(arg1 + 0x114)) {
        iVar12 = func_0x0001800d90d0(arg1 + 0x60);
        func_0x0001800d9940(iVar12 + 4, 0x180644050, 0x1806436c0);
        pcVar2 = (code *)swi(3);
        piVar13 = (int64_t *)(*pcVar2)();
        return piVar13;
    }
    if (*(int32_t *)(arg1 + 0x80) == 0x3a) {
        fcn.1800efe70(arg1, arg1 + 0x84, 0x1806435c0);
        func_0x0001800d7020(arg1 + 0x60);
    } else if (*(int32_t *)(arg1 + 0x80) == 0x107) {
        fcn.1800f0350();
    } else {
        if (((*(int64_t *)(arg4 + 8) == 0) && (*(int64_t *)(arg_28h + 8) == 0)) && (*(int64_t *)(arg_30h + 8) == 0)) {
            var_48h = *(int64_t *)(arg2 + 4);
            var_40h = *(int64_t *)(arg1 + 0xa8);
            fcn.1800efe70(arg1, &var_48h, 0x180643610);
            ppiVar1 = *(int64_t ***)(arg1 + 0xd8);
            iVar12 = (int64_t)*ppiVar1;
            if (iVar12 != 0) {
                piVar13 = (int64_t *)((int64_t)ppiVar1[1] + iVar12 + 0xf & 0xfffffffffffffff8);
                if (piVar13 + 0xf <= (int64_t *)(iVar12 + 0x2008)) {
                    piVar11 = (int64_t *)((int64_t)piVar13 + (0x78 - (iVar12 + 8)));
                    goto code_r0x0001800e7746;
                }
            }
            piVar11 = (int64_t *)func_0x000180459890(0x2008);
            *piVar11 = (int64_t)*ppiVar1;
            piVar13 = piVar11 + 1;
            *ppiVar1 = piVar11;
            piVar11 = (int64_t *)0x78;
code_r0x0001800e7746:
            uVar3 = _var_38h;
            ppiVar1[1] = piVar11;
            iVar12 = *(int64_t *)(arg1 + 0x130);
            uVar8 = (undefined4)var_40h;
            uVar9 = var_40h._4_4_;
            uVar7 = (uint32_t)_var_38h >> 8;
            *(undefined4 *)(piVar13 + 1) = *(undefined4 *)0x1807826bc;
            *piVar13 = 0x180642298;
            uVar3 = *(undefined4 *)(arg2 + 4);
            uVar4 = *(undefined4 *)(arg2 + 8);
            uVar5 = *(undefined4 *)(arg2 + 0xc);
            uVar6 = *(undefined4 *)(arg2 + 0x10);
            *piVar13 = 0x1806419a0;
            piVar13[5] = var_48h;
            *(undefined4 *)((int64_t)piVar13 + 0x31) = var_40h._1_4_;
            *(undefined2 *)((int64_t)piVar13 + 0x35) = var_40h._5_2_;
            *(undefined *)((int64_t)piVar13 + 0x37) = var_40h._7_1_;
            *(undefined4 *)(piVar13 + 7) = (undefined4)var_48h;
            *(undefined4 *)((int64_t)piVar13 + 0x3c) = var_48h._4_4_;
            *(undefined4 *)(piVar13 + 8) = uVar8;
            *(undefined4 *)((int64_t)piVar13 + 0x44) = uVar9;
            *(undefined4 *)((int64_t)piVar13 + 0xc) = uVar3;
            *(undefined4 *)(piVar13 + 2) = uVar4;
            *(undefined4 *)((int64_t)piVar13 + 0x14) = uVar5;
            *(undefined4 *)(piVar13 + 3) = uVar6;
            *(undefined *)(piVar13 + 4) = 0;
            *(undefined *)(piVar13 + 6) = 0;
            *(undefined4 *)(piVar13 + 9) = _var_38h;
            piVar13[10] = iVar12;
            uVar3 = *(undefined4 *)(arg2 + 4);
            uVar4 = *(undefined4 *)(arg2 + 8);
            uVar5 = *(undefined4 *)(arg2 + 0xc);
            uVar6 = *(undefined4 *)(arg2 + 0x10);
            piVar13[0xd] = 0;
            piVar13[0xe] = 0;
            *(undefined4 *)(piVar13 + 0xb) = uVar3;
            *(undefined4 *)((int64_t)piVar13 + 0x5c) = uVar4;
            *(undefined4 *)(piVar13 + 0xc) = uVar5;
            *(undefined4 *)((int64_t)piVar13 + 100) = uVar6;
            return piVar13;
        }
        func_0x0001800ef2a0(arg1, 0x107, 0x1806437d0);
    }
    iVar10 = fcn.1800e48f0(arg1);
    var_48h = *(int64_t *)(arg2 + 4);
    ppiVar1 = *(int64_t ***)(arg1 + 0xd8);
    var_40h = *(int64_t *)(iVar10 + 0x14);
    iVar12 = (int64_t)*ppiVar1;
    if (iVar12 != 0) {
        piVar13 = (int64_t *)((int64_t)ppiVar1[1] + iVar12 + 0xf & 0xfffffffffffffff8);
        if (piVar13 + 0x10 <= (int64_t *)(iVar12 + 0x2008)) {
            piVar11 = (int64_t *)((int64_t)piVar13 + (0x80 - (iVar12 + 8)));
            goto code_r0x0001800e7889;
        }
    }
    piVar11 = (int64_t *)func_0x000180459890(0x2008);
    *piVar11 = (int64_t)*ppiVar1;
    piVar13 = piVar11 + 1;
    *ppiVar1 = piVar11;
    piVar11 = (int64_t *)0x80;
code_r0x0001800e7889:
    ppiVar1[1] = piVar11;
    *(undefined4 *)(piVar13 + 1) = *(undefined4 *)0x1807826ac;
    *piVar13 = 0x180642270;
    *(undefined4 *)((int64_t)piVar13 + 0xc) = (undefined4)var_48h;
    *(undefined4 *)(piVar13 + 2) = var_48h._4_4_;
    *(undefined4 *)((int64_t)piVar13 + 0x14) = (undefined4)var_40h;
    *(undefined4 *)(piVar13 + 3) = var_40h._4_4_;
    uVar3 = *(undefined4 *)arg3;
    uVar4 = *(undefined4 *)(arg3 + 4);
    uVar5 = *(undefined4 *)(arg3 + 8);
    uVar6 = *(undefined4 *)(arg3 + 0xc);
    piVar13[0xc] = arg_40h;
    *(undefined4 *)(piVar13 + 4) = uVar3;
    *(undefined4 *)((int64_t)piVar13 + 0x24) = uVar4;
    *(undefined4 *)(piVar13 + 5) = uVar5;
    *(undefined4 *)((int64_t)piVar13 + 0x2c) = uVar6;
    piVar13[0xf] = iVar10;
    uVar3 = *(undefined4 *)(arg4 + 4);
    uVar4 = *(undefined4 *)(arg4 + 8);
    uVar5 = *(undefined4 *)(arg4 + 0xc);
    *(undefined4 *)(piVar13 + 6) = *(undefined4 *)arg4;
    *(undefined4 *)((int64_t)piVar13 + 0x34) = uVar3;
    *(undefined4 *)(piVar13 + 7) = uVar4;
    *(undefined4 *)((int64_t)piVar13 + 0x3c) = uVar5;
    uVar3 = *(undefined4 *)(arg_28h + 4);
    uVar4 = *(undefined4 *)(arg_28h + 8);
    uVar5 = *(undefined4 *)(arg_28h + 0xc);
    *(undefined4 *)(piVar13 + 8) = *(undefined4 *)arg_28h;
    *(undefined4 *)((int64_t)piVar13 + 0x44) = uVar3;
    *(undefined4 *)(piVar13 + 9) = uVar4;
    *(undefined4 *)((int64_t)piVar13 + 0x4c) = uVar5;
    uVar3 = *(undefined4 *)(arg_30h + 4);
    uVar4 = *(undefined4 *)(arg_30h + 8);
    uVar5 = *(undefined4 *)(arg_30h + 0xc);
    *(undefined4 *)(piVar13 + 10) = *(undefined4 *)arg_30h;
    *(undefined4 *)((int64_t)piVar13 + 0x54) = uVar3;
    *(undefined4 *)(piVar13 + 0xb) = uVar4;
    *(undefined4 *)((int64_t)piVar13 + 0x5c) = uVar5;
    uVar3 = *(undefined4 *)(arg_38h + 4);
    uVar4 = *(undefined4 *)(arg_38h + 8);
    uVar5 = *(undefined4 *)(arg_38h + 0xc);
    *(undefined4 *)(piVar13 + 0xd) = *(undefined4 *)arg_38h;
    *(undefined4 *)((int64_t)piVar13 + 0x6c) = uVar3;
    *(undefined4 *)(piVar13 + 0xe) = uVar4;
    *(undefined4 *)((int64_t)piVar13 + 0x74) = uVar5;
    return piVar13;
}

// ============================================================
// Function: FUN_1800e7655
// Address: 0x1800e7655
// Size: 437 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_3fh
// WARNING: [rz-ghidra] Detected overlap for variable var_3bh
// WARNING: [rz-ghidra] Detected overlap for variable var_39h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h

int64_t * fcn.1800e7620(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                       int64_t arg_38h, int64_t arg_40h)
{
    int64_t **ppiVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    uint32_t uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t iVar12;
    int64_t *piVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    undefined var_38h;
    int64_t var_37h;
    int64_t var_28h;
    
    *(int32_t *)(arg1 + 0x114) = *(int32_t *)(arg1 + 0x114) + 1;
    if (*(uint32_t *)0x180778500 < *(uint32_t *)(arg1 + 0x114)) {
        iVar12 = func_0x0001800d90d0(arg1 + 0x60);
        func_0x0001800d9940(iVar12 + 4, 0x180644050, 0x1806436c0);
        pcVar2 = (code *)swi(3);
        piVar13 = (int64_t *)(*pcVar2)();
        return piVar13;
    }
    if (*(int32_t *)(arg1 + 0x80) == 0x3a) {
        fcn.1800efe70(arg1, arg1 + 0x84, 0x1806435c0);
        func_0x0001800d7020(arg1 + 0x60);
    } else if (*(int32_t *)(arg1 + 0x80) == 0x107) {
        fcn.1800f0350();
    } else {
        if (((*(int64_t *)(arg4 + 8) == 0) && (*(int64_t *)(arg_28h + 8) == 0)) && (*(int64_t *)(arg_30h + 8) == 0)) {
            var_48h = *(int64_t *)(arg2 + 4);
            var_40h = *(int64_t *)(arg1 + 0xa8);
            fcn.1800efe70(arg1, &var_48h, 0x180643610);
            ppiVar1 = *(int64_t ***)(arg1 + 0xd8);
            iVar12 = (int64_t)*ppiVar1;
            if (iVar12 != 0) {
                piVar13 = (int64_t *)((int64_t)ppiVar1[1] + iVar12 + 0xf & 0xfffffffffffffff8);
                if (piVar13 + 0xf <= (int64_t *)(iVar12 + 0x2008)) {
                    piVar11 = (int64_t *)((int64_t)piVar13 + (0x78 - (iVar12 + 8)));
                    goto code_r0x0001800e7746;
                }
            }
            piVar11 = (int64_t *)func_0x000180459890(0x2008);
            *piVar11 = (int64_t)*ppiVar1;
            piVar13 = piVar11 + 1;
            *ppiVar1 = piVar11;
            piVar11 = (int64_t *)0x78;
code_r0x0001800e7746:
            uVar3 = _var_38h;
            ppiVar1[1] = piVar11;
            iVar12 = *(int64_t *)(arg1 + 0x130);
            uVar8 = (undefined4)var_40h;
            uVar9 = var_40h._4_4_;
            uVar7 = (uint32_t)_var_38h >> 8;
            *(undefined4 *)(piVar13 + 1) = *(undefined4 *)0x1807826bc;
            *piVar13 = 0x180642298;
            uVar3 = *(undefined4 *)(arg2 + 4);
            uVar4 = *(undefined4 *)(arg2 + 8);
            uVar5 = *(undefined4 *)(arg2 + 0xc);
            uVar6 = *(undefined4 *)(arg2 + 0x10);
            *piVar13 = 0x1806419a0;
            piVar13[5] = var_48h;
            *(undefined4 *)((int64_t)piVar13 + 0x31) = var_40h._1_4_;
            *(undefined2 *)((int64_t)piVar13 + 0x35) = var_40h._5_2_;
            *(undefined *)((int64_t)piVar13 + 0x37) = var_40h._7_1_;
            *(undefined4 *)(piVar13 + 7) = (undefined4)var_48h;
            *(undefined4 *)((int64_t)piVar13 + 0x3c) = var_48h._4_4_;
            *(undefined4 *)(piVar13 + 8) = uVar8;
            *(undefined4 *)((int64_t)piVar13 + 0x44) = uVar9;
            *(undefined4 *)((int64_t)piVar13 + 0xc) = uVar3;
            *(undefined4 *)(piVar13 + 2) = uVar4;
            *(undefined4 *)((int64_t)piVar13 + 0x14) = uVar5;
            *(undefined4 *)(piVar13 + 3) = uVar6;
            *(undefined *)(piVar13 + 4) = 0;
            *(undefined *)(piVar13 + 6) = 0;
            *(undefined4 *)(piVar13 + 9) = _var_38h;
            piVar13[10] = iVar12;
            uVar3 = *(undefined4 *)(arg2 + 4);
            uVar4 = *(undefined4 *)(arg2 + 8);
            uVar5 = *(undefined4 *)(arg2 + 0xc);
            uVar6 = *(undefined4 *)(arg2 + 0x10);
            piVar13[0xd] = 0;
            piVar13[0xe] = 0;
            *(undefined4 *)(piVar13 + 0xb) = uVar3;
            *(undefined4 *)((int64_t)piVar13 + 0x5c) = uVar4;
            *(undefined4 *)(piVar13 + 0xc) = uVar5;
            *(undefined4 *)((int64_t)piVar13 + 100) = uVar6;
            return piVar13;
        }
        func_0x0001800ef2a0(arg1, 0x107, 0x1806437d0);
    }
    iVar10 = fcn.1800e48f0(arg1);
    var_48h = *(int64_t *)(arg2 + 4);
    ppiVar1 = *(int64_t ***)(arg1 + 0xd8);
    var_40h = *(int64_t *)(iVar10 + 0x14);
    iVar12 = (int64_t)*ppiVar1;
    if (iVar12 != 0) {
        piVar13 = (int64_t *)((int64_t)ppiVar1[1] + iVar12 + 0xf & 0xfffffffffffffff8);
        if (piVar13 + 0x10 <= (int64_t *)(iVar12 + 0x2008)) {
            piVar11 = (int64_t *)((int64_t)piVar13 + (0x80 - (iVar12 + 8)));
            goto code_r0x0001800e7889;
        }
    }
    piVar11 = (int64_t *)func_0x000180459890(0x2008);
    *piVar11 = (int64_t)*ppiVar1;
    piVar13 = piVar11 + 1;
    *ppiVar1 = piVar11;
    piVar11 = (int64_t *)0x80;
code_r0x0001800e7889:
    ppiVar1[1] = piVar11;
    *(undefined4 *)(piVar13 + 1) = *(undefined4 *)0x1807826ac;
    *piVar13 = 0x180642270;
    *(undefined4 *)((int64_t)piVar13 + 0xc) = (undefined4)var_48h;
    *(undefined4 *)(piVar13 + 2) = var_48h._4_4_;
    *(undefined4 *)((int64_t)piVar13 + 0x14) = (undefined4)var_40h;
    *(undefined4 *)(piVar13 + 3) = var_40h._4_4_;
    uVar3 = *(undefined4 *)arg3;
    uVar4 = *(undefined4 *)(arg3 + 4);
    uVar5 = *(undefined4 *)(arg3 + 8);
    uVar6 = *(undefined4 *)(arg3 + 0xc);
    piVar13[0xc] = arg_40h;
    *(undefined4 *)(piVar13 + 4) = uVar3;
    *(undefined4 *)((int64_t)piVar13 + 0x24) = uVar4;
    *(undefined4 *)(piVar13 + 5) = uVar5;
    *(undefined4 *)((int64_t)piVar13 + 0x2c) = uVar6;
    piVar13[0xf] = iVar10;
    uVar3 = *(undefined4 *)(arg4 + 4);
    uVar4 = *(undefined4 *)(arg4 + 8);
    uVar5 = *(undefined4 *)(arg4 + 0xc);
    *(undefined4 *)(piVar13 + 6) = *(undefined4 *)arg4;
    *(undefined4 *)((int64_t)piVar13 + 0x34) = uVar3;
    *(undefined4 *)(piVar13 + 7) = uVar4;
    *(undefined4 *)((int64_t)piVar13 + 0x3c) = uVar5;
    uVar3 = *(undefined4 *)(arg_28h + 4);
    uVar4 = *(undefined4 *)(arg_28h + 8);
    uVar5 = *(undefined4 *)(arg_28h + 0xc);
    *(undefined4 *)(piVar13 + 8) = *(undefined4 *)arg_28h;
    *(undefined4 *)((int64_t)piVar13 + 0x44) = uVar3;
    *(undefined4 *)(piVar13 + 9) = uVar4;
    *(undefined4 *)((int64_t)piVar13 + 0x4c) = uVar5;
    uVar3 = *(undefined4 *)(arg_30h + 4);
    uVar4 = *(undefined4 *)(arg_30h + 8);
    uVar5 = *(undefined4 *)(arg_30h + 0xc);
    *(undefined4 *)(piVar13 + 10) = *(undefined4 *)arg_30h;
    *(undefined4 *)((int64_t)piVar13 + 0x54) = uVar3;
    *(undefined4 *)(piVar13 + 0xb) = uVar4;
    *(undefined4 *)((int64_t)piVar13 + 0x5c) = uVar5;
    uVar3 = *(undefined4 *)(arg_38h + 4);
    uVar4 = *(undefined4 *)(arg_38h + 8);
    uVar5 = *(undefined4 *)(arg_38h + 0xc);
    *(undefined4 *)(piVar13 + 0xd) = *(undefined4 *)arg_38h;
    *(undefined4 *)((int64_t)piVar13 + 0x6c) = uVar3;
    *(undefined4 *)(piVar13 + 0xe) = uVar4;
    *(undefined4 *)((int64_t)piVar13 + 0x74) = uVar5;
    return piVar13;
}

// ============================================================
// Function: FUN_1800e780a
// Address: 0x1800e780a
// Size: 233 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_3fh
// WARNING: [rz-ghidra] Detected overlap for variable var_3bh
// WARNING: [rz-ghidra] Detected overlap for variable var_39h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h

int64_t * fcn.1800e7620(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                       int64_t arg_38h, int64_t arg_40h)
{
    int64_t **ppiVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    uint32_t uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t iVar12;
    int64_t *piVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    undefined var_38h;
    int64_t var_37h;
    int64_t var_28h;
    
    *(int32_t *)(arg1 + 0x114) = *(int32_t *)(arg1 + 0x114) + 1;
    if (*(uint32_t *)0x180778500 < *(uint32_t *)(arg1 + 0x114)) {
        iVar12 = func_0x0001800d90d0(arg1 + 0x60);
        func_0x0001800d9940(iVar12 + 4, 0x180644050, 0x1806436c0);
        pcVar2 = (code *)swi(3);
        piVar13 = (int64_t *)(*pcVar2)();
        return piVar13;
    }
    if (*(int32_t *)(arg1 + 0x80) == 0x3a) {
        fcn.1800efe70(arg1, arg1 + 0x84, 0x1806435c0);
        func_0x0001800d7020(arg1 + 0x60);
    } else if (*(int32_t *)(arg1 + 0x80) == 0x107) {
        fcn.1800f0350();
    } else {
        if (((*(int64_t *)(arg4 + 8) == 0) && (*(int64_t *)(arg_28h + 8) == 0)) && (*(int64_t *)(arg_30h + 8) == 0)) {
            var_48h = *(int64_t *)(arg2 + 4);
            var_40h = *(int64_t *)(arg1 + 0xa8);
            fcn.1800efe70(arg1, &var_48h, 0x180643610);
            ppiVar1 = *(int64_t ***)(arg1 + 0xd8);
            iVar12 = (int64_t)*ppiVar1;
            if (iVar12 != 0) {
                piVar13 = (int64_t *)((int64_t)ppiVar1[1] + iVar12 + 0xf & 0xfffffffffffffff8);
                if (piVar13 + 0xf <= (int64_t *)(iVar12 + 0x2008)) {
                    piVar11 = (int64_t *)((int64_t)piVar13 + (0x78 - (iVar12 + 8)));
                    goto code_r0x0001800e7746;
                }
            }
            piVar11 = (int64_t *)func_0x000180459890(0x2008);
            *piVar11 = (int64_t)*ppiVar1;
            piVar13 = piVar11 + 1;
            *ppiVar1 = piVar11;
            piVar11 = (int64_t *)0x78;
code_r0x0001800e7746:
            uVar3 = _var_38h;
            ppiVar1[1] = piVar11;
            iVar12 = *(int64_t *)(arg1 + 0x130);
            uVar8 = (undefined4)var_40h;
            uVar9 = var_40h._4_4_;
            uVar7 = (uint32_t)_var_38h >> 8;
            *(undefined4 *)(piVar13 + 1) = *(undefined4 *)0x1807826bc;
            *piVar13 = 0x180642298;
            uVar3 = *(undefined4 *)(arg2 + 4);
            uVar4 = *(undefined4 *)(arg2 + 8);
            uVar5 = *(undefined4 *)(arg2 + 0xc);
            uVar6 = *(undefined4 *)(arg2 + 0x10);
            *piVar13 = 0x1806419a0;
            piVar13[5] = var_48h;
            *(undefined4 *)((int64_t)piVar13 + 0x31) = var_40h._1_4_;
            *(undefined2 *)((int64_t)piVar13 + 0x35) = var_40h._5_2_;
            *(undefined *)((int64_t)piVar13 + 0x37) = var_40h._7_1_;
            *(undefined4 *)(piVar13 + 7) = (undefined4)var_48h;
            *(undefined4 *)((int64_t)piVar13 + 0x3c) = var_48h._4_4_;
            *(undefined4 *)(piVar13 + 8) = uVar8;
            *(undefined4 *)((int64_t)piVar13 + 0x44) = uVar9;
            *(undefined4 *)((int64_t)piVar13 + 0xc) = uVar3;
            *(undefined4 *)(piVar13 + 2) = uVar4;
            *(undefined4 *)((int64_t)piVar13 + 0x14) = uVar5;
            *(undefined4 *)(piVar13 + 3) = uVar6;
            *(undefined *)(piVar13 + 4) = 0;
            *(undefined *)(piVar13 + 6) = 0;
            *(undefined4 *)(piVar13 + 9) = _var_38h;
            piVar13[10] = iVar12;
            uVar3 = *(undefined4 *)(arg2 + 4);
            uVar4 = *(undefined4 *)(arg2 + 8);
            uVar5 = *(undefined4 *)(arg2 + 0xc);
            uVar6 = *(undefined4 *)(arg2 + 0x10);
            piVar13[0xd] = 0;
            piVar13[0xe] = 0;
            *(undefined4 *)(piVar13 + 0xb) = uVar3;
            *(undefined4 *)((int64_t)piVar13 + 0x5c) = uVar4;
            *(undefined4 *)(piVar13 + 0xc) = uVar5;
            *(undefined4 *)((int64_t)piVar13 + 100) = uVar6;
            return piVar13;
        }
        func_0x0001800ef2a0(arg1, 0x107, 0x1806437d0);
    }
    iVar10 = fcn.1800e48f0(arg1);
    var_48h = *(int64_t *)(arg2 + 4);
    ppiVar1 = *(int64_t ***)(arg1 + 0xd8);
    var_40h = *(int64_t *)(iVar10 + 0x14);
    iVar12 = (int64_t)*ppiVar1;
    if (iVar12 != 0) {
        piVar13 = (int64_t *)((int64_t)ppiVar1[1] + iVar12 + 0xf & 0xfffffffffffffff8);
        if (piVar13 + 0x10 <= (int64_t *)(iVar12 + 0x2008)) {
            piVar11 = (int64_t *)((int64_t)piVar13 + (0x80 - (iVar12 + 8)));
            goto code_r0x0001800e7889;
        }
    }
    piVar11 = (int64_t *)func_0x000180459890(0x2008);
    *piVar11 = (int64_t)*ppiVar1;
    piVar13 = piVar11 + 1;
    *ppiVar1 = piVar11;
    piVar11 = (int64_t *)0x80;
code_r0x0001800e7889:
    ppiVar1[1] = piVar11;
    *(undefined4 *)(piVar13 + 1) = *(undefined4 *)0x1807826ac;
    *piVar13 = 0x180642270;
    *(undefined4 *)((int64_t)piVar13 + 0xc) = (undefined4)var_48h;
    *(undefined4 *)(piVar13 + 2) = var_48h._4_4_;
    *(undefined4 *)((int64_t)piVar13 + 0x14) = (undefined4)var_40h;
    *(undefined4 *)(piVar13 + 3) = var_40h._4_4_;
    uVar3 = *(undefined4 *)arg3;
    uVar4 = *(undefined4 *)(arg3 + 4);
    uVar5 = *(undefined4 *)(arg3 + 8);
    uVar6 = *(undefined4 *)(arg3 + 0xc);
    piVar13[0xc] = arg_40h;
    *(undefined4 *)(piVar13 + 4) = uVar3;
    *(undefined4 *)((int64_t)piVar13 + 0x24) = uVar4;
    *(undefined4 *)(piVar13 + 5) = uVar5;
    *(undefined4 *)((int64_t)piVar13 + 0x2c) = uVar6;
    piVar13[0xf] = iVar10;
    uVar3 = *(undefined4 *)(arg4 + 4);
    uVar4 = *(undefined4 *)(arg4 + 8);
    uVar5 = *(undefined4 *)(arg4 + 0xc);
    *(undefined4 *)(piVar13 + 6) = *(undefined4 *)arg4;
    *(undefined4 *)((int64_t)piVar13 + 0x34) = uVar3;
    *(undefined4 *)(piVar13 + 7) = uVar4;
    *(undefined4 *)((int64_t)piVar13 + 0x3c) = uVar5;
    uVar3 = *(undefined4 *)(arg_28h + 4);
    uVar4 = *(undefined4 *)(arg_28h + 8);
    uVar5 = *(undefined4 *)(arg_28h + 0xc);
    *(undefined4 *)(piVar13 + 8) = *(undefined4 *)arg_28h;
    *(undefined4 *)((int64_t)piVar13 + 0x44) = uVar3;
    *(undefined4 *)(piVar13 + 9) = uVar4;
    *(undefined4 *)((int64_t)piVar13 + 0x4c) = uVar5;
    uVar3 = *(undefined4 *)(arg_30h + 4);
    uVar4 = *(undefined4 *)(arg_30h + 8);
    uVar5 = *(undefined4 *)(arg_30h + 0xc);
    *(undefined4 *)(piVar13 + 10) = *(undefined4 *)arg_30h;
    *(undefined4 *)((int64_t)piVar13 + 0x54) = uVar3;
    *(undefined4 *)(piVar13 + 0xb) = uVar4;
    *(undefined4 *)((int64_t)piVar13 + 0x5c) = uVar5;
    uVar3 = *(undefined4 *)(arg_38h + 4);
    uVar4 = *(undefined4 *)(arg_38h + 8);
    uVar5 = *(undefined4 *)(arg_38h + 0xc);
    *(undefined4 *)(piVar13 + 0xd) = *(undefined4 *)arg_38h;
    *(undefined4 *)((int64_t)piVar13 + 0x6c) = uVar3;
    *(undefined4 *)(piVar13 + 0xe) = uVar4;
    *(undefined4 *)((int64_t)piVar13 + 0x74) = uVar5;
    return piVar13;
}

// ============================================================
// Function: FUN_1800e78f3
// Address: 0x1800e78f3
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_3fh
// WARNING: [rz-ghidra] Detected overlap for variable var_3bh
// WARNING: [rz-ghidra] Detected overlap for variable var_39h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h

int64_t * fcn.1800e7620(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                       int64_t arg_38h, int64_t arg_40h)
{
    int64_t **ppiVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    uint32_t uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t iVar12;
    int64_t *piVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    undefined var_38h;
    int64_t var_37h;
    int64_t var_28h;
    
    *(int32_t *)(arg1 + 0x114) = *(int32_t *)(arg1 + 0x114) + 1;
    if (*(uint32_t *)0x180778500 < *(uint32_t *)(arg1 + 0x114)) {
        iVar12 = func_0x0001800d90d0(arg1 + 0x60);
        func_0x0001800d9940(iVar12 + 4, 0x180644050, 0x1806436c0);
        pcVar2 = (code *)swi(3);
        piVar13 = (int64_t *)(*pcVar2)();
        return piVar13;
    }
    if (*(int32_t *)(arg1 + 0x80) == 0x3a) {
        fcn.1800efe70(arg1, arg1 + 0x84, 0x1806435c0);
        func_0x0001800d7020(arg1 + 0x60);
    } else if (*(int32_t *)(arg1 + 0x80) == 0x107) {
        fcn.1800f0350();
    } else {
        if (((*(int64_t *)(arg4 + 8) == 0) && (*(int64_t *)(arg_28h + 8) == 0)) && (*(int64_t *)(arg_30h + 8) == 0)) {
            var_48h = *(int64_t *)(arg2 + 4);
            var_40h = *(int64_t *)(arg1 + 0xa8);
            fcn.1800efe70(arg1, &var_48h, 0x180643610);
            ppiVar1 = *(int64_t ***)(arg1 + 0xd8);
            iVar12 = (int64_t)*ppiVar1;
            if (iVar12 != 0) {
                piVar13 = (int64_t *)((int64_t)ppiVar1[1] + iVar12 + 0xf & 0xfffffffffffffff8);
                if (piVar13 + 0xf <= (int64_t *)(iVar12 + 0x2008)) {
                    piVar11 = (int64_t *)((int64_t)piVar13 + (0x78 - (iVar12 + 8)));
                    goto code_r0x0001800e7746;
                }
            }
            piVar11 = (int64_t *)func_0x000180459890(0x2008);
            *piVar11 = (int64_t)*ppiVar1;
            piVar13 = piVar11 + 1;
            *ppiVar1 = piVar11;
            piVar11 = (int64_t *)0x78;
code_r0x0001800e7746:
            uVar3 = _var_38h;
            ppiVar1[1] = piVar11;
            iVar12 = *(int64_t *)(arg1 + 0x130);
            uVar8 = (undefined4)var_40h;
            uVar9 = var_40h._4_4_;
            uVar7 = (uint32_t)_var_38h >> 8;
            *(undefined4 *)(piVar13 + 1) = *(undefined4 *)0x1807826bc;
            *piVar13 = 0x180642298;
            uVar3 = *(undefined4 *)(arg2 + 4);
            uVar4 = *(undefined4 *)(arg2 + 8);
            uVar5 = *(undefined4 *)(arg2 + 0xc);
            uVar6 = *(undefined4 *)(arg2 + 0x10);
            *piVar13 = 0x1806419a0;
            piVar13[5] = var_48h;
            *(undefined4 *)((int64_t)piVar13 + 0x31) = var_40h._1_4_;
            *(undefined2 *)((int64_t)piVar13 + 0x35) = var_40h._5_2_;
            *(undefined *)((int64_t)piVar13 + 0x37) = var_40h._7_1_;
            *(undefined4 *)(piVar13 + 7) = (undefined4)var_48h;
            *(undefined4 *)((int64_t)piVar13 + 0x3c) = var_48h._4_4_;
            *(undefined4 *)(piVar13 + 8) = uVar8;
            *(undefined4 *)((int64_t)piVar13 + 0x44) = uVar9;
            *(undefined4 *)((int64_t)piVar13 + 0xc) = uVar3;
            *(undefined4 *)(piVar13 + 2) = uVar4;
            *(undefined4 *)((int64_t)piVar13 + 0x14) = uVar5;
            *(undefined4 *)(piVar13 + 3) = uVar6;
            *(undefined *)(piVar13 + 4) = 0;
            *(undefined *)(piVar13 + 6) = 0;
            *(undefined4 *)(piVar13 + 9) = _var_38h;
            piVar13[10] = iVar12;
            uVar3 = *(undefined4 *)(arg2 + 4);
            uVar4 = *(undefined4 *)(arg2 + 8);
            uVar5 = *(undefined4 *)(arg2 + 0xc);
            uVar6 = *(undefined4 *)(arg2 + 0x10);
            piVar13[0xd] = 0;
            piVar13[0xe] = 0;
            *(undefined4 *)(piVar13 + 0xb) = uVar3;
            *(undefined4 *)((int64_t)piVar13 + 0x5c) = uVar4;
            *(undefined4 *)(piVar13 + 0xc) = uVar5;
            *(undefined4 *)((int64_t)piVar13 + 100) = uVar6;
            return piVar13;
        }
        func_0x0001800ef2a0(arg1, 0x107, 0x1806437d0);
    }
    iVar10 = fcn.1800e48f0(arg1);
    var_48h = *(int64_t *)(arg2 + 4);
    ppiVar1 = *(int64_t ***)(arg1 + 0xd8);
    var_40h = *(int64_t *)(iVar10 + 0x14);
    iVar12 = (int64_t)*ppiVar1;
    if (iVar12 != 0) {
        piVar13 = (int64_t *)((int64_t)ppiVar1[1] + iVar12 + 0xf & 0xfffffffffffffff8);
        if (piVar13 + 0x10 <= (int64_t *)(iVar12 + 0x2008)) {
            piVar11 = (int64_t *)((int64_t)piVar13 + (0x80 - (iVar12 + 8)));
            goto code_r0x0001800e7889;
        }
    }
    piVar11 = (int64_t *)func_0x000180459890(0x2008);
    *piVar11 = (int64_t)*ppiVar1;
    piVar13 = piVar11 + 1;
    *ppiVar1 = piVar11;
    piVar11 = (int64_t *)0x80;
code_r0x0001800e7889:
    ppiVar1[1] = piVar11;
    *(undefined4 *)(piVar13 + 1) = *(undefined4 *)0x1807826ac;
    *piVar13 = 0x180642270;
    *(undefined4 *)((int64_t)piVar13 + 0xc) = (undefined4)var_48h;
    *(undefined4 *)(piVar13 + 2) = var_48h._4_4_;
    *(undefined4 *)((int64_t)piVar13 + 0x14) = (undefined4)var_40h;
    *(undefined4 *)(piVar13 + 3) = var_40h._4_4_;
    uVar3 = *(undefined4 *)arg3;
    uVar4 = *(undefined4 *)(arg3 + 4);
    uVar5 = *(undefined4 *)(arg3 + 8);
    uVar6 = *(undefined4 *)(arg3 + 0xc);
    piVar13[0xc] = arg_40h;
    *(undefined4 *)(piVar13 + 4) = uVar3;
    *(undefined4 *)((int64_t)piVar13 + 0x24) = uVar4;
    *(undefined4 *)(piVar13 + 5) = uVar5;
    *(undefined4 *)((int64_t)piVar13 + 0x2c) = uVar6;
    piVar13[0xf] = iVar10;
    uVar3 = *(undefined4 *)(arg4 + 4);
    uVar4 = *(undefined4 *)(arg4 + 8);
    uVar5 = *(undefined4 *)(arg4 + 0xc);
    *(undefined4 *)(piVar13 + 6) = *(undefined4 *)arg4;
    *(undefined4 *)((int64_t)piVar13 + 0x34) = uVar3;
    *(undefined4 *)(piVar13 + 7) = uVar4;
    *(undefined4 *)((int64_t)piVar13 + 0x3c) = uVar5;
    uVar3 = *(undefined4 *)(arg_28h + 4);
    uVar4 = *(undefined4 *)(arg_28h + 8);
    uVar5 = *(undefined4 *)(arg_28h + 0xc);
    *(undefined4 *)(piVar13 + 8) = *(undefined4 *)arg_28h;
    *(undefined4 *)((int64_t)piVar13 + 0x44) = uVar3;
    *(undefined4 *)(piVar13 + 9) = uVar4;
    *(undefined4 *)((int64_t)piVar13 + 0x4c) = uVar5;
    uVar3 = *(undefined4 *)(arg_30h + 4);
    uVar4 = *(undefined4 *)(arg_30h + 8);
    uVar5 = *(undefined4 *)(arg_30h + 0xc);
    *(undefined4 *)(piVar13 + 10) = *(undefined4 *)arg_30h;
    *(undefined4 *)((int64_t)piVar13 + 0x54) = uVar3;
    *(undefined4 *)(piVar13 + 0xb) = uVar4;
    *(undefined4 *)((int64_t)piVar13 + 0x5c) = uVar5;
    uVar3 = *(undefined4 *)(arg_38h + 4);
    uVar4 = *(undefined4 *)(arg_38h + 8);
    uVar5 = *(undefined4 *)(arg_38h + 0xc);
    *(undefined4 *)(piVar13 + 0xd) = *(undefined4 *)arg_38h;
    *(undefined4 *)((int64_t)piVar13 + 0x6c) = uVar3;
    *(undefined4 *)(piVar13 + 0xe) = uVar4;
    *(undefined4 *)((int64_t)piVar13 + 0x74) = uVar5;
    return piVar13;
}

// ============================================================
// Function: FUN_1800e790d
// Address: 0x1800e790d
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_3fh
// WARNING: [rz-ghidra] Detected overlap for variable var_3bh
// WARNING: [rz-ghidra] Detected overlap for variable var_39h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h

int64_t * fcn.1800e7620(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                       int64_t arg_38h, int64_t arg_40h)
{
    int64_t **ppiVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    uint32_t uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t iVar12;
    int64_t *piVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    undefined var_38h;
    int64_t var_37h;
    int64_t var_28h;
    
    *(int32_t *)(arg1 + 0x114) = *(int32_t *)(arg1 + 0x114) + 1;
    if (*(uint32_t *)0x180778500 < *(uint32_t *)(arg1 + 0x114)) {
        iVar12 = func_0x0001800d90d0(arg1 + 0x60);
        func_0x0001800d9940(iVar12 + 4, 0x180644050, 0x1806436c0);
        pcVar2 = (code *)swi(3);
        piVar13 = (int64_t *)(*pcVar2)();
        return piVar13;
    }
    if (*(int32_t *)(arg1 + 0x80) == 0x3a) {
        fcn.1800efe70(arg1, arg1 + 0x84, 0x1806435c0);
        func_0x0001800d7020(arg1 + 0x60);
    } else if (*(int32_t *)(arg1 + 0x80) == 0x107) {
        fcn.1800f0350();
    } else {
        if (((*(int64_t *)(arg4 + 8) == 0) && (*(int64_t *)(arg_28h + 8) == 0)) && (*(int64_t *)(arg_30h + 8) == 0)) {
            var_48h = *(int64_t *)(arg2 + 4);
            var_40h = *(int64_t *)(arg1 + 0xa8);
            fcn.1800efe70(arg1, &var_48h, 0x180643610);
            ppiVar1 = *(int64_t ***)(arg1 + 0xd8);
            iVar12 = (int64_t)*ppiVar1;
            if (iVar12 != 0) {
                piVar13 = (int64_t *)((int64_t)ppiVar1[1] + iVar12 + 0xf & 0xfffffffffffffff8);
                if (piVar13 + 0xf <= (int64_t *)(iVar12 + 0x2008)) {
                    piVar11 = (int64_t *)((int64_t)piVar13 + (0x78 - (iVar12 + 8)));
                    goto code_r0x0001800e7746;
                }
            }
            piVar11 = (int64_t *)func_0x000180459890(0x2008);
            *piVar11 = (int64_t)*ppiVar1;
            piVar13 = piVar11 + 1;
            *ppiVar1 = piVar11;
            piVar11 = (int64_t *)0x78;
code_r0x0001800e7746:
            uVar3 = _var_38h;
            ppiVar1[1] = piVar11;
            iVar12 = *(int64_t *)(arg1 + 0x130);
            uVar8 = (undefined4)var_40h;
            uVar9 = var_40h._4_4_;
            uVar7 = (uint32_t)_var_38h >> 8;
            *(undefined4 *)(piVar13 + 1) = *(undefined4 *)0x1807826bc;
            *piVar13 = 0x180642298;
            uVar3 = *(undefined4 *)(arg2 + 4);
            uVar4 = *(undefined4 *)(arg2 + 8);
            uVar5 = *(undefined4 *)(arg2 + 0xc);
            uVar6 = *(undefined4 *)(arg2 + 0x10);
            *piVar13 = 0x1806419a0;
            piVar13[5] = var_48h;
            *(undefined4 *)((int64_t)piVar13 + 0x31) = var_40h._1_4_;
            *(undefined2 *)((int64_t)piVar13 + 0x35) = var_40h._5_2_;
            *(undefined *)((int64_t)piVar13 + 0x37) = var_40h._7_1_;
            *(undefined4 *)(piVar13 + 7) = (undefined4)var_48h;
            *(undefined4 *)((int64_t)piVar13 + 0x3c) = var_48h._4_4_;
            *(undefined4 *)(piVar13 + 8) = uVar8;
            *(undefined4 *)((int64_t)piVar13 + 0x44) = uVar9;
            *(undefined4 *)((int64_t)piVar13 + 0xc) = uVar3;
            *(undefined4 *)(piVar13 + 2) = uVar4;
            *(undefined4 *)((int64_t)piVar13 + 0x14) = uVar5;
            *(undefined4 *)(piVar13 + 3) = uVar6;
            *(undefined *)(piVar13 + 4) = 0;
            *(undefined *)(piVar13 + 6) = 0;
            *(undefined4 *)(piVar13 + 9) = _var_38h;
            piVar13[10] = iVar12;
            uVar3 = *(undefined4 *)(arg2 + 4);
            uVar4 = *(undefined4 *)(arg2 + 8);
            uVar5 = *(undefined4 *)(arg2 + 0xc);
            uVar6 = *(undefined4 *)(arg2 + 0x10);
            piVar13[0xd] = 0;
            piVar13[0xe] = 0;
            *(undefined4 *)(piVar13 + 0xb) = uVar3;
            *(undefined4 *)((int64_t)piVar13 + 0x5c) = uVar4;
            *(undefined4 *)(piVar13 + 0xc) = uVar5;
            *(undefined4 *)((int64_t)piVar13 + 100) = uVar6;
            return piVar13;
        }
        func_0x0001800ef2a0(arg1, 0x107, 0x1806437d0);
    }
    iVar10 = fcn.1800e48f0(arg1);
    var_48h = *(int64_t *)(arg2 + 4);
    ppiVar1 = *(int64_t ***)(arg1 + 0xd8);
    var_40h = *(int64_t *)(iVar10 + 0x14);
    iVar12 = (int64_t)*ppiVar1;
    if (iVar12 != 0) {
        piVar13 = (int64_t *)((int64_t)ppiVar1[1] + iVar12 + 0xf & 0xfffffffffffffff8);
        if (piVar13 + 0x10 <= (int64_t *)(iVar12 + 0x2008)) {
            piVar11 = (int64_t *)((int64_t)piVar13 + (0x80 - (iVar12 + 8)));
            goto code_r0x0001800e7889;
        }
    }
    piVar11 = (int64_t *)func_0x000180459890(0x2008);
    *piVar11 = (int64_t)*ppiVar1;
    piVar13 = piVar11 + 1;
    *ppiVar1 = piVar11;
    piVar11 = (int64_t *)0x80;
code_r0x0001800e7889:
    ppiVar1[1] = piVar11;
    *(undefined4 *)(piVar13 + 1) = *(undefined4 *)0x1807826ac;
    *piVar13 = 0x180642270;
    *(undefined4 *)((int64_t)piVar13 + 0xc) = (undefined4)var_48h;
    *(undefined4 *)(piVar13 + 2) = var_48h._4_4_;
    *(undefined4 *)((int64_t)piVar13 + 0x14) = (undefined4)var_40h;
    *(undefined4 *)(piVar13 + 3) = var_40h._4_4_;
    uVar3 = *(undefined4 *)arg3;
    uVar4 = *(undefined4 *)(arg3 + 4);
    uVar5 = *(undefined4 *)(arg3 + 8);
    uVar6 = *(undefined4 *)(arg3 + 0xc);
    piVar13[0xc] = arg_40h;
    *(undefined4 *)(piVar13 + 4) = uVar3;
    *(undefined4 *)((int64_t)piVar13 + 0x24) = uVar4;
    *(undefined4 *)(piVar13 + 5) = uVar5;
    *(undefined4 *)((int64_t)piVar13 + 0x2c) = uVar6;
    piVar13[0xf] = iVar10;
    uVar3 = *(undefined4 *)(arg4 + 4);
    uVar4 = *(undefined4 *)(arg4 + 8);
    uVar5 = *(undefined4 *)(arg4 + 0xc);
    *(undefined4 *)(piVar13 + 6) = *(undefined4 *)arg4;
    *(undefined4 *)((int64_t)piVar13 + 0x34) = uVar3;
    *(undefined4 *)(piVar13 + 7) = uVar4;
    *(undefined4 *)((int64_t)piVar13 + 0x3c) = uVar5;
    uVar3 = *(undefined4 *)(arg_28h + 4);
    uVar4 = *(undefined4 *)(arg_28h + 8);
    uVar5 = *(undefined4 *)(arg_28h + 0xc);
    *(undefined4 *)(piVar13 + 8) = *(undefined4 *)arg_28h;
    *(undefined4 *)((int64_t)piVar13 + 0x44) = uVar3;
    *(undefined4 *)(piVar13 + 9) = uVar4;
    *(undefined4 *)((int64_t)piVar13 + 0x4c) = uVar5;
    uVar3 = *(undefined4 *)(arg_30h + 4);
    uVar4 = *(undefined4 *)(arg_30h + 8);
    uVar5 = *(undefined4 *)(arg_30h + 0xc);
    *(undefined4 *)(piVar13 + 10) = *(undefined4 *)arg_30h;
    *(undefined4 *)((int64_t)piVar13 + 0x54) = uVar3;
    *(undefined4 *)(piVar13 + 0xb) = uVar4;
    *(undefined4 *)((int64_t)piVar13 + 0x5c) = uVar5;
    uVar3 = *(undefined4 *)(arg_38h + 4);
    uVar4 = *(undefined4 *)(arg_38h + 8);
    uVar5 = *(undefined4 *)(arg_38h + 0xc);
    *(undefined4 *)(piVar13 + 0xd) = *(undefined4 *)arg_38h;
    *(undefined4 *)((int64_t)piVar13 + 0x6c) = uVar3;
    *(undefined4 *)(piVar13 + 0xe) = uVar4;
    *(undefined4 *)((int64_t)piVar13 + 0x74) = uVar5;
    return piVar13;
}

// ============================================================
// Function: FUN_1800e7930
// Address: 0x1800e7930
// Size: 2079 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_11h
// WARNING: Variable defined which should be unmapped: var_21h
// WARNING: Variable defined which should be unmapped: var_29h
// WARNING: Variable defined which should be unmapped: var_31h
// WARNING: Variable defined which should be unmapped: var_39h
// WARNING: Variable defined which should be unmapped: var_41h
// WARNING: [rz-ghidra] Removing arg arg_67h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_5dh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

int64_t * fcn.1800e7930(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    bool bVar6;
    uint32_t uVar7;
    undefined4 uVar8;
    undefined8 uVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint64_t uVar12;
    int64_t **ppiVar13;
    int64_t *piVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    int64_t *piVar17;
    char cVar18;
    int64_t iVar19;
    uint64_t uVar20;
    undefined8 uStackX_8;
    undefined8 uStackX_10;
    undefined8 *puStackX_18;
    undefined8 uStackX_20;
    int64_t *piStack_d8;
    int64_t *piStack_d0;
    uint64_t uStack_c8;
    int64_t *apiStack_c0 [2];
    uint64_t uStack_b0;
    int64_t *piStack_a8;
    int64_t iStack_a0;
    uint64_t uStack_98;
    undefined8 uStack_90;
    undefined8 uStack_88;
    undefined4 uStack_80;
    undefined auStack_7c [3];
    int64_t var_79h;
    int64_t var_71h;
    int64_t var_69h;
    int64_t var_61h;
    int64_t var_51h;
    int64_t var_49h;
    int64_t var_41h;
    int64_t var_39h;
    int64_t var_31h;
    int64_t var_29h;
    int64_t var_21h;
    int64_t var_11h;
    
    piStack_d8 = (int64_t *)(arg1 + 0x350);
    piStack_d0 = (int64_t *)(*(int64_t *)(arg1 + 0x358) - *piStack_d8 >> 3);
    uStack_c8 = 0;
    piStack_a8 = (int64_t *)(arg1 + 0x440);
    iStack_a0 = *(int64_t *)(arg1 + 0x448) - *piStack_a8 >> 3;
    uStack_98 = 0;
    uStackX_10 = arg2;
    puStackX_18 = (undefined8 *)arg3;
    if (arg2 != 0) {
        func_0x0001800f1a70(&piStack_d8);
    }
    uVar7 = *(int32_t *)(arg1 + 0x114) + 1;
    *(uint32_t *)(arg1 + 0x114) = uVar7;
    if (*(uint32_t *)0x180778500 < uVar7) {
        iVar19 = func_0x0001800d90d0(arg1 + 0x60);
        func_0x0001800d9940(iVar19 + 4, 0x180644050, 0x1806436c0);
        pcVar2 = (code *)swi(3);
        piVar14 = (int64_t *)(*pcVar2)();
        return piVar14;
    }
    uStackX_8._0_4_ = -1;
    uVar20 = 0xffffffff;
    uStack_b0 = 0xffffffff;
    bVar6 = false;
    cVar18 = '\0';
    uStackX_10 = uStackX_10 & 0xffffffffffffff00;
    uStackX_20 = (int64_t *)((uint64_t)uStackX_20._4_4_ << 0x20);
    uStack_90 = *puStackX_18;
    uStack_88 = puStackX_18[1];
    do {
        piVar17 = piStack_d0;
        piVar10 = piStack_d8;
        iVar1 = *(int32_t *)(arg1 + 0x80);
        piVar14 = *(int64_t **)(arg1 + 0x84);
        apiStack_c0[0] = piVar14;
        if (iVar1 == 0x7c) {
            fcn.1800f0350(arg1);
            uVar8 = *(undefined4 *)(arg1 + 0x114);
            uVar9 = func_0x0001800e81c0(arg1, &uStack_80, 0, 0);
            func_0x0001800f1a70(&piStack_d8, uVar9);
            *(undefined4 *)(arg1 + 0x114) = uVar8;
            bVar6 = true;
            if (*(char *)(arg1 + 0x58) != '\0') {
                if (((arg2 == 0) && ((int32_t)uStackX_8 == -1)) && ((int32_t)uVar20 == -1)) {
                    uVar20 = (uint64_t)piVar14 >> 0x20;
                    cVar18 = (char)uStackX_10;
                    uStack_b0 = uVar20;
                    uStackX_8._0_4_ = (int32_t)piVar14;
                } else {
                    func_0x0001800f1a70(&piStack_a8, apiStack_c0);
                    cVar18 = (char)uStackX_10;
                }
                goto code_r0x0001800e7bc8;
            }
code_r0x0001800e7b29:
            bVar6 = true;
            cVar18 = (char)uStackX_10;
        } else {
            if (iVar1 == 0x3f) {
                uVar8 = *(undefined4 *)(arg1 + 0x84);
                uVar3 = *(undefined4 *)(arg1 + 0x88);
                uVar4 = *(undefined4 *)(arg1 + 0x8c);
                uVar5 = *(undefined4 *)(arg1 + 0x90);
                fcn.1800f0350(arg1);
                ppiVar13 = *(int64_t ***)(arg1 + 0xd8);
                iVar19 = (int64_t)*ppiVar13;
                if (iVar19 == 0) {
code_r0x0001800e7adb:
                    piVar14 = (int64_t *)func_0x000180459890(0x2008);
                    *piVar14 = (int64_t)*ppiVar13;
                    *ppiVar13 = piVar14;
                    piVar14 = piVar14 + 1;
                    piVar10 = (int64_t *)0x20;
                } else {
                    piVar14 = (int64_t *)((int64_t)ppiVar13[1] + iVar19 + 0xf & 0xfffffffffffffff8);
                    if ((int64_t *)(iVar19 + 0x2008) < piVar14 + 4) goto code_r0x0001800e7adb;
                    piVar10 = (int64_t *)((int64_t)piVar14 + (0x20 - (iVar19 + 8)));
                }
                ppiVar13[1] = piVar10;
                *(undefined4 *)(piVar14 + 1) = *(undefined4 *)0x1807826c8;
                *(undefined4 *)((int64_t)piVar14 + 0xc) = uVar8;
                *(undefined4 *)(piVar14 + 2) = uVar3;
                *(undefined4 *)((int64_t)piVar14 + 0x14) = uVar4;
                *(undefined4 *)(piVar14 + 3) = uVar5;
                *piVar14 = 0x180641c58;
                apiStack_c0[0] = piVar14;
                func_0x0001800f1a70(&piStack_d8, apiStack_c0);
                uStackX_20 = (int64_t *)CONCAT44(uStackX_20._4_4_, (int32_t)uStackX_20 + 1);
                goto code_r0x0001800e7b29;
            }
            if (iVar1 == 0x26) {
                fcn.1800f0350(arg1);
                uVar8 = *(undefined4 *)(arg1 + 0x114);
                uVar9 = func_0x0001800e81c0(arg1, (int64_t)&var_71h + 1, 0, 0);
                func_0x0001800f1a70(&piStack_d8, uVar9);
                *(undefined4 *)(arg1 + 0x114) = uVar8;
                cVar18 = '\x01';
                uStackX_10 = CONCAT71(uStackX_10._1_7_, 1);
                if (*(char *)(arg1 + 0x58) != '\0') {
                    if (((arg2 == 0) && ((int32_t)uStackX_8 == -1)) && ((int32_t)uVar20 == -1)) {
                        uVar20 = (uint64_t)apiStack_c0[0] >> 0x20;
                        uStack_b0 = uVar20;
                        uStackX_8._0_4_ = (int32_t)piVar14;
                    } else {
                        func_0x0001800f1a70(&piStack_a8, apiStack_c0);
                    }
                }
            } else {
                if (iVar1 != 0x106) {
                    if (uStack_c8 == 1) {
                        if (bVar6) {
code_r0x0001800e7c5d:
                            if (cVar18 != '\0') {
                                if (uStack_c8 == 0) {
                                    iVar19 = 0;
                                } else {
                                    iVar19 = *piStack_d8 + (int64_t)piStack_d0 * 8;
                                }
                                func_0x0001800f1110(arg1, apiStack_c0, iVar19);
                                uStack_90 = *puStackX_18;
                                uStack_88 = *(undefined8 *)(*(int64_t *)(piVar10[1] + -8) + 0x14);
                                piVar14 = (int64_t *)func_0x0001800f0170(arg1, &uStack_90, apiStack_c0, 0x180643870);
                                iVar19 = *piStack_a8 + iStack_a0 * 8;
                                if (iVar19 != piStack_a8[1]) {
                                    piStack_a8[1] = iVar19;
                                }
                                iVar19 = *piVar10 + (int64_t)piVar17 * 8;
                                if (iVar19 == piVar10[1]) {
                                    return piVar14;
                                }
                                piVar10[1] = iVar19;
                                return piVar14;
                            }
                        } else if (cVar18 == '\0') {
                            piVar14 = *(int64_t **)((int64_t)piStack_d0 * 8 + *piStack_d8);
                            iVar19 = *piStack_a8 + iStack_a0 * 8;
                            if (iVar19 != piStack_a8[1]) {
                                piStack_a8[1] = iVar19;
                            }
                            iVar19 = *piStack_d8 + (int64_t)piStack_d0 * 8;
                            if (iVar19 == piStack_d8[1]) {
                                return piVar14;
                            }
                            piStack_d8[1] = iVar19;
                            return piVar14;
                        }
                    } else if (bVar6) goto code_r0x0001800e7c5d;
                    uStack_88 = *(undefined8 *)(*(int64_t *)(piStack_d8[1] + -8) + 0x14);
                    if (bVar6) {
                        ppiVar13 = *(int64_t ***)(arg1 + 0xd8);
                        apiStack_c0[0] = piStack_d0;
                        if (uStack_c8 == 0) {
                            iVar19 = 0;
                        } else {
                            iVar19 = *piStack_d8 + (int64_t)piStack_d0 * 8;
                        }
                        func_0x0001800f1110(arg1, &uStack_80, iVar19);
                        iVar19 = (int64_t)*ppiVar13;
                        if (iVar19 == 0) {
code_r0x0001800e7d7a:
                            piVar14 = (int64_t *)func_0x000180459890(0x2008);
                            *piVar14 = (int64_t)*ppiVar13;
                            *ppiVar13 = piVar14;
                            piVar14 = piVar14 + 1;
                            piVar11 = (int64_t *)0x30;
                        } else {
                            piVar14 = (int64_t *)((int64_t)ppiVar13[1] + iVar19 + 0xf & 0xfffffffffffffff8);
                            if ((int64_t *)(iVar19 + 0x2008) < piVar14 + 6) goto code_r0x0001800e7d7a;
                            piVar11 = (int64_t *)((int64_t)piVar14 + (0x30 - (iVar19 + 8)));
                        }
                        uVar20 = uStack_98;
                        ppiVar13[1] = piVar11;
                        *(undefined4 *)(piVar14 + 1) = *(undefined4 *)0x18078277c;
                        *(undefined4 *)((int64_t)piVar14 + 0xc) = (undefined4)uStack_90;
                        *(undefined4 *)(piVar14 + 2) = uStack_90._4_4_;
                        *(undefined4 *)((int64_t)piVar14 + 0x14) = (undefined4)uStack_88;
                        *(undefined4 *)(piVar14 + 3) = uStack_88._4_4_;
                        *piVar14 = 0x180641b68;
                        *(undefined4 *)(piVar14 + 4) = uStack_80;
                        *(undefined4 *)((int64_t)piVar14 + 0x24) = _auStack_7c;
                        *(undefined4 *)(piVar14 + 5) = var_79h._1_4_;
                        *(undefined4 *)((int64_t)piVar14 + 0x2c) = stack0xffffffffffffff8c;
                        uStackX_10 = iStack_a0;
                        uStackX_20 = piStack_a8;
                        if (*(char *)(arg1 + 0x58) == '\0') goto code_r0x0001800e7f01;
                        ppiVar13 = *(int64_t ***)(arg1 + 0xd8);
                        if (uStack_98 == 0) {
                            uVar12 = 0;
                        } else {
                            iVar19 = *piStack_a8;
                            uVar12 = func_0x0001800d4d20(ppiVar13, uStack_98 * 8);
                            if (uVar20 != 0) {
                                uVar16 = uStackX_10 * 8 + iVar19;
                                uVar15 = 0;
                                if ((uVar20 < 2) ||
                                   ((uVar12 <= uVar16 + (uVar20 - 1) * 8 && (uVar16 <= uVar12 + (uVar20 - 1) * 8)))) {
                                    do {
                                        *(undefined8 *)(uVar12 + uVar15 * 8) = *(undefined8 *)(uVar16 + uVar15 * 8);
                                        uVar15 = uVar15 + 1;
                                    } while (uVar15 < uVar20);
                                } else {
                                    func_0x000180498030(uVar12, uVar16, uVar20 * 8);
                                }
                            }
                        }
                        iVar19 = (int64_t)*ppiVar13;
                        if (iVar19 == 0) {
code_r0x0001800e7ea2:
                            piVar17 = (int64_t *)func_0x000180459890(0x2008);
                            *piVar17 = (int64_t)*ppiVar13;
                            *ppiVar13 = piVar17;
                            piVar17 = piVar17 + 1;
                            piVar11 = (int64_t *)0x20;
                        } else {
                            piVar17 = (int64_t *)((int64_t)ppiVar13[1] + iVar19 + 0xf & 0xfffffffffffffff8);
                            if ((int64_t *)(iVar19 + 0x2008U) < piVar17 + 4) goto code_r0x0001800e7ea2;
                            piVar11 = (int64_t *)((int64_t)piVar17 + (0x20 - (iVar19 + 8)));
                        }
                        ppiVar13[1] = piVar11;
                        uVar8 = *(undefined4 *)0x180782ab0;
                    } else {
                        if (cVar18 == '\0') {
                            func_0x0001800d9940(puStackX_18, 0x1806436f0);
                            pcVar2 = (code *)swi(3);
                            piVar14 = (int64_t *)(*pcVar2)();
                            return piVar14;
                        }
                        ppiVar13 = *(int64_t ***)(arg1 + 0xd8);
                        apiStack_c0[0] = piStack_d0;
                        if (uStack_c8 == 0) {
                            iVar19 = 0;
                        } else {
                            iVar19 = *piStack_d8 + (int64_t)piStack_d0 * 8;
                        }
                        func_0x0001800f1110(arg1, &uStack_80, iVar19);
                        iVar19 = (int64_t)*ppiVar13;
                        if (iVar19 == 0) {
code_r0x0001800e7f9f:
                            piVar14 = (int64_t *)func_0x000180459890(0x2008);
                            *piVar14 = (int64_t)*ppiVar13;
                            *ppiVar13 = piVar14;
                            piVar14 = piVar14 + 1;
                            piVar11 = (int64_t *)0x30;
                        } else {
                            piVar14 = (int64_t *)((int64_t)ppiVar13[1] + iVar19 + 0xf & 0xfffffffffffffff8);
                            if ((int64_t *)(iVar19 + 0x2008) < piVar14 + 6) goto code_r0x0001800e7f9f;
                            piVar11 = (int64_t *)((int64_t)piVar14 + (0x30 - (iVar19 + 8)));
                        }
                        uVar20 = uStack_98;
                        ppiVar13[1] = piVar11;
                        *(undefined4 *)(piVar14 + 1) = *(undefined4 *)0x180782694;
                        *(undefined4 *)((int64_t)piVar14 + 0xc) = (undefined4)uStack_90;
                        *(undefined4 *)(piVar14 + 2) = uStack_90._4_4_;
                        *(undefined4 *)((int64_t)piVar14 + 0x14) = (undefined4)uStack_88;
                        *(undefined4 *)(piVar14 + 3) = uStack_88._4_4_;
                        *piVar14 = 0x180642130;
                        *(undefined4 *)(piVar14 + 4) = uStack_80;
                        *(undefined4 *)((int64_t)piVar14 + 0x24) = _auStack_7c;
                        *(undefined4 *)(piVar14 + 5) = var_79h._1_4_;
                        *(undefined4 *)((int64_t)piVar14 + 0x2c) = stack0xffffffffffffff8c;
                        uStackX_10 = iStack_a0;
                        uStackX_20 = piStack_a8;
                        if (*(char *)(arg1 + 0x58) == '\0') goto code_r0x0001800e7f01;
                        ppiVar13 = *(int64_t ***)(arg1 + 0xd8);
                        if (uStack_98 == 0) {
                            uVar12 = 0;
                        } else {
                            iVar19 = *piStack_a8;
                            uVar12 = func_0x0001800d4d20(ppiVar13, uStack_98 * 8);
                            if (uVar20 != 0) {
                                uVar16 = uStackX_10 * 8 + iVar19;
                                uVar15 = 0;
                                if ((uVar20 < 2) ||
                                   ((uVar12 <= uVar16 + (uVar20 - 1) * 8 && (uVar16 <= uVar12 + (uVar20 - 1) * 8)))) {
                                    do {
                                        *(undefined8 *)(uVar12 + uVar15 * 8) = *(undefined8 *)(uVar16 + uVar15 * 8);
                                        uVar15 = uVar15 + 1;
                                    } while (uVar15 < uVar20);
                                } else {
                                    func_0x000180498030(uVar12, uVar16, uVar20 * 8);
                                }
                            }
                        }
                        iVar19 = (int64_t)*ppiVar13;
                        if (iVar19 != 0) {
                            piVar17 = (int64_t *)((int64_t)ppiVar13[1] + iVar19 + 0xf & 0xfffffffffffffff8);
                            if (piVar17 + 4 <= (int64_t *)(iVar19 + 0x2008U)) {
                                ppiVar13[1] = (int64_t *)((int64_t)piVar17 + (0x20 - (iVar19 + 8)));
                                uVar8 = *(undefined4 *)0x180782a80;
                                goto code_r0x0001800e7ecb;
                            }
                        }
                        piVar17 = (int64_t *)func_0x000180459890(0x2008);
                        *piVar17 = (int64_t)*ppiVar13;
                        *ppiVar13 = piVar17;
                        piVar17 = piVar17 + 1;
                        ppiVar13[1] = (int64_t *)0x20;
                        uVar8 = *(undefined4 *)0x180782a80;
                    }
code_r0x0001800e7ecb:
                    *(undefined4 *)piVar17 = uVar8;
                    *(int32_t *)((int64_t)piVar17 + 4) = (int32_t)uStackX_8;
                    *(int32_t *)(piVar17 + 1) = (int32_t)uStack_b0;
                    piVar17[2] = uVar12;
                    piVar17[3] = uVar20;
                    uStackX_8 = piVar14;
                    ppiVar13 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &uStackX_8);
                    *ppiVar13 = piVar17;
                    piStack_a8 = uStackX_20;
                    piVar17 = apiStack_c0[0];
code_r0x0001800e7f01:
                    iVar19 = *piStack_a8 + uStackX_10 * 8;
                    if (iVar19 != piStack_a8[1]) {
                        piStack_a8[1] = iVar19;
                    }
                    iVar19 = *piVar10 + (int64_t)piVar17 * 8;
                    if (iVar19 != piVar10[1]) {
                        piVar10[1] = iVar19;
                    }
                    return piVar14;
                }
                fcn.1800efe70(arg1, arg1 + 0x84);
                fcn.1800f0350(arg1);
            }
        }
code_r0x0001800e7bc8:
        if ((uint32_t)(*(int32_t *)0x180778160 + (int32_t)uStackX_20) < uStack_c8) {
            piVar14 = (int64_t *)func_0x0001800f1df0(&piStack_d8);
            func_0x0001800d9940(*piVar14 + 0xc, 0x180643810);
            pcVar2 = (code *)swi(3);
            piVar14 = (int64_t *)(*pcVar2)();
            return piVar14;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1800e8150
// Address: 0x1800e8150
// Size: 105 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_137h
// WARNING: [rz-ghidra] Detected overlap for variable var_138h
// WARNING: [rz-ghidra] Detected overlap for variable var_107h
// WARNING: [rz-ghidra] Detected overlap for variable var_103h
// WARNING: [rz-ghidra] Detected overlap for variable var_101h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Removing arg arg_67h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_5dh

void fcn.1800e8150(int64_t arg1)
{
    undefined4 uVar1;
    int64_t *piVar2;
    undefined in_DL;
    int64_t arg2;
    int64_t var_8h;
    int64_t var_28h;
    undefined4 uStack_20;
    undefined4 uStack_1c;
    int64_t var_18h;
    
    var_28h._0_4_ = *(undefined4 *)(arg1 + 0x84);
    var_28h._4_4_ = *(undefined4 *)(arg1 + 0x88);
    uStack_20 = *(undefined4 *)(arg1 + 0x8c);
    uStack_1c = *(undefined4 *)(arg1 + 0x90);
    uVar1 = *(undefined4 *)(arg1 + 0x114);
    arg2 = 0;
    if ((*(int32_t *)(arg1 + 0x80) != 0x7c) && (*(int32_t *)(arg1 + 0x80) != 0x26)) {
        piVar2 = (int64_t *)fcn.1800e81c0((undefined4)var_28h, &var_18h, 0, in_DL);
        arg2 = *piVar2;
        *(undefined4 *)(arg1 + 0x114) = uVar1;
    }
    fcn.1800e7930(arg1, arg2, (int64_t)&var_28h);
    *(undefined4 *)(arg1 + 0x114) = uVar1;
    return;
}

// ============================================================
// Function: FUN_1800e81c0
// Address: 0x1800e81c0
// Size: 3168 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_148h
// WARNING: Variable defined which should be unmapped: var_140h
// WARNING: Variable defined which should be unmapped: var_128h
// WARNING: Variable defined which should be unmapped: var_120h
// WARNING: Variable defined which should be unmapped: var_110h
// WARNING: Variable defined which should be unmapped: var_80h
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Removing unreachable block (ram,0x0001800e88bb)
// WARNING: Removing unreachable block (ram,0x0001800e88e9)
// WARNING: Removing unreachable block (ram,0x0001800e88fb)
// WARNING: Removing unreachable block (ram,0x0001800e8908)
// WARNING: Removing unreachable block (ram,0x0001800e8940)
// WARNING: Removing unreachable block (ram,0x0001800e8950)
// WARNING: Removing unreachable block (ram,0x0001800e891a)
// WARNING: Removing unreachable block (ram,0x0001800e892f)
// WARNING: [rz-ghidra] Detected overlap for variable var_137h
// WARNING: [rz-ghidra] Detected overlap for variable var_138h
// WARNING: [rz-ghidra] Detected overlap for variable var_107h
// WARNING: [rz-ghidra] Detected overlap for variable var_103h
// WARNING: [rz-ghidra] Detected overlap for variable var_101h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_6fh
// WARNING: [rz-ghidra] Detected overlap for variable var_173h
// WARNING: [rz-ghidra] Detected overlap for variable var_6dh
// WARNING: [rz-ghidra] Detected overlap for variable var_171h
// WARNING: [rz-ghidra] Detected overlap for variable var_1a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_19ch
// WARNING: [rz-ghidra] Detected overlap for variable var_194h
// WARNING: [rz-ghidra] Detected overlap for variable var_18ch
// WARNING: [rz-ghidra] Detected overlap for variable var_180h
// WARNING: [rz-ghidra] Detected overlap for variable var_178h
// WARNING: [rz-ghidra] Detected overlap for variable arg_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_198h
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_4fh
// WARNING: [rz-ghidra] Detected overlap for variable var_4dh
// WARNING: [rz-ghidra] Detected overlap for variable var_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_1b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_1b0h
// WARNING: [rz-ghidra] Detected overlap for variable arg_a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_28h

void fcn.1800e81c0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    undefined auVar2 [16];
    uint64_t uVar3;
    int64_t iVar4;
    char cVar5;
    char cVar6;
    uint64_t uVar7;
    undefined8 uVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    int64_t iVar11;
    undefined8 *puVar12;
    int64_t *piVar13;
    int64_t **ppiVar14;
    int64_t *piVar15;
    int64_t iVar16;
    undefined8 *puVar17;
    undefined *puVar18;
    int64_t *piVar19;
    int64_t *in_R8;
    char in_R9B;
    uint32_t uVar20;
    int32_t iVar21;
    undefined4 uVar22;
    int32_t iVar23;
    undefined4 uVar24;
    undefined4 uVar25;
    undefined auStackY_168 [8];
    undefined auStackY_160 [24];
    int64_t var_148h;
    int64_t var_140h;
    undefined in_stack_fffffffffffffec8;
    undefined uVar26;
    undefined in_stack_fffffffffffffec9;
    undefined uVar27;
    unkbyte6 in_stack_fffffffffffffeca;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    undefined in_stack_fffffffffffffee8;
    undefined2 in_stack_fffffffffffffee9;
    undefined in_stack_fffffffffffffeeb;
    undefined4 in_stack_fffffffffffffeec;
    int64_t var_110h;
    undefined4 var_108h;
    undefined uStack_104;
    undefined2 var_103h;
    undefined var_101h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    undefined4 uStack_e8;
    undefined4 uStack_e4;
    int64_t *piStack_e0;
    undefined4 uStack_d8;
    undefined4 uStack_d4;
    undefined8 uStack_c8;
    undefined8 uStack_c0;
    int64_t iStack_b8;
    undefined8 uStack_b0;
    undefined8 uStack_a8;
    undefined4 uStack_a0;
    undefined4 uStack_9c;
    int32_t iStack_98;
    undefined4 uStack_94;
    int64_t in_stack_ffffffffffffff70;
    undefined4 in_stack_ffffffffffffff78;
    undefined4 uVar28;
    undefined4 in_stack_ffffffffffffff7c;
    undefined4 uVar29;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    puVar18 = auStackY_168;
    uVar7 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_168;
    *(int32_t *)(arg1 + 0x114) = *(int32_t *)(arg1 + 0x114) + 1;
    if (*(uint32_t *)0x180778500 < *(uint32_t *)(arg1 + 0x114)) {
        iVar9 = func_0x0001800d90d0(arg1 + 0x60);
        func_0x0001800d9940(iVar9 + 4, 0x180644050, 0x1806436c0);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar24 = *(undefined4 *)(int64_t *)(arg1 + 0x84);
    uVar25 = *(undefined4 *)(arg1 + 0x88);
    var_f0h = *(int64_t *)(arg1 + 0x84);
    uVar22 = *(undefined4 *)(int64_t *)(arg1 + 0x8c);
    uVar28 = *(undefined4 *)(arg1 + 0x90);
    uStack_e8 = uVar22;
    uStack_e4 = uVar28;
    iVar23 = *(int32_t *)(arg1 + 0x80);
    if (iVar23 - 0x11cU < 2) {
        if (in_R9B == '\0') {
            var_128h = 0;
            var_120h = 0;
            uVar8 = 0x180643728;
            piVar15 = &var_128h;
            goto code_r0x0001800e8405;
        }
        piVar15 = (int64_t *)func_0x0001800de530(arg1, &var_128h);
        var_128h = *piVar15;
        var_120h = piVar15[1];
        in_R8 = (int64_t *)((uint64_t)in_R8 & 0xff);
        puVar18 = auStackY_168;
code_r0x0001800e8dbe:
        *(undefined8 *)(puVar18 + -8) = 0x1800e8dcb;
        fcn.1800e6640(arg1, arg2, in_R8, (int64_t)(puVar18 + 0x40), *(int64_t *)(puVar18 + 0x20), 
                      *(int64_t *)(puVar18 + 0x28), *(undefined8 *)(puVar18 + 0x30), *(int64_t *)(puVar18 + 0x38), 
                      *(int64_t *)(puVar18 + 0x40), *(int64_t *)(puVar18 + 0x48), *(int64_t *)(puVar18 + 0x50), 
                      *(int64_t *)(puVar18 + 0x58), *(undefined8 *)(puVar18 + 0x60), *(int64_t *)(puVar18 + 0x68), 
                      *(undefined8 *)(puVar18 + 0x70), *(int64_t *)(puVar18 + 0x78), *(int64_t *)(puVar18 + 0x80), 
                      *(int64_t *)(puVar18 + 0x88), *(undefined8 *)(puVar18 + 0x90), *(int64_t *)(puVar18 + 0x98), 
                      *(undefined8 *)(puVar18 + 0xa0), *(int64_t *)(puVar18 + 0xa8), *(int64_t *)(puVar18 + 0x128), 
                      *(int64_t *)(puVar18 + 0x130), *(int64_t *)(puVar18 + 0x138), *(int64_t *)(puVar18 + 0x140));
        goto code_r0x0001800e8dcb;
    }
    if (iVar23 == 0x12f) {
        fcn.1800f0350(arg1);
        var_140h = (int64_t)&var_f0h;
        uVar8 = func_0x0001800f1550(*(undefined8 *)(arg1 + 0xd8), &var_f0h);
        *(undefined8 *)arg2 = uVar8;
        *(undefined8 *)(arg2 + 8) = 0;
        puVar18 = auStackY_168;
        goto code_r0x0001800e8dcb;
    }
    if (iVar23 != 0x135) {
        if (iVar23 != 0x129) {
            if (1 < iVar23 - 0x116U) {
                if ((iVar23 == 0x10a) || (iVar23 == 0x10d)) {
                    func_0x0001800ee150(arg1);
                    var_128h = 0;
                    var_120h = 0;
                    uVar8 = 0x180643798;
                    piVar15 = &var_128h;
                } else if (iVar23 == 0x11e) {
                    fcn.1800f0350(arg1);
                    uStack_c8 = 0;
                    uStack_c0 = 0;
                    uVar8 = 0x180643938;
                    piVar15 = &uStack_c8;
                } else {
                    if (iVar23 == 0x119) {
                        var_100h = -1;
                        func_0x0001800ecb20(arg1, &uStack_a0, 0x180642dc8);
                        iVar23 = *(int32_t *)(arg1 + 0x80);
                        iVar9 = 0;
                        if (iVar23 == 0x2e) {
                            iVar9 = *(int64_t *)(arg1 + 0x84);
                            fcn.1800f0350(arg1);
                            uVar24 = uStack_94;
                            iVar23 = iStack_98;
                            uVar8 = CONCAT44(uStack_9c, uStack_a0);
                            uVar25 = (undefined4)in_stack_ffffffffffffff70;
                            uVar3 = (uint64_t)in_stack_ffffffffffffff70 >> 0x20;
                            uVar27 = 1;
                            if ((*(int32_t *)(arg1 + 0x80) == 0x119) ||
                               ((func_0x0001800efe90(arg1, 0x180642a90), *(int32_t *)(arg1 + 0x80) - 0x123U < 0x15 &&
                                (*(int32_t *)(arg1 + 0x84) == (int32_t)iVar9)))) {
                                var_80h._0_4_ = *(int32_t *)(arg1 + 0x84);
                                var_80h._4_4_ = *(undefined4 *)(arg1 + 0x88);
                                iVar21 = *(int32_t *)(arg1 + 0x8c);
                                uVar22 = *(undefined4 *)(arg1 + 0x90);
                                uVar28 = (undefined4)*(undefined8 *)(arg1 + 0x98);
                                uVar29 = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x98) >> 0x20);
                                fcn.1800f0350(arg1);
                                uStack_a0 = uVar28;
                                uStack_9c = uVar29;
                            } else {
                                iVar21 = *(int32_t *)(arg1 + 0x84);
                                uVar22 = *(undefined4 *)(arg1 + 0x88);
                                uStack_104 = (undefined)uVar22;
                                var_103h = (undefined2)((uint32_t)uVar22 >> 8);
                                var_101h = (undefined)((uint32_t)uVar22 >> 0x18);
                                uStack_a0 = (undefined4)*(undefined8 *)(arg1 + 0x128);
                                uStack_9c = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x128) >> 0x20);
                                var_110h._0_4_ = iVar21;
                                var_110h._4_4_ = uVar22;
                                var_108h = iVar21;
                                var_80h._0_4_ = iVar21;
                                var_80h._4_4_ = uVar22;
                            }
                            iStack_98 = (int32_t)var_80h;
                            uStack_94 = var_80h._4_4_;
                            in_stack_ffffffffffffff70 = CONCAT44(uVar22, iVar21);
                            iVar11 = CONCAT44(uStack_9c, uStack_a0);
                            uVar22 = (int32_t)uVar3;
                        } else {
                            uVar27 = 0;
                            if (iVar23 == 0x106) {
                                fcn.1800efe70(arg1, arg1 + 0x84, 0x180643970);
                                fcn.1800f0350(arg1);
                                iVar11 = CONCAT44(uStack_9c, uStack_a0);
                            } else {
                                iVar11 = CONCAT44(uStack_9c, uStack_a0);
                                if (iVar11 != 0) {
                                    do {
                                        iVar16 = iVar9 + 1;
                                        if (*(char *)(iVar11 + iVar9) != *(char *)(iVar9 + 0x180626234))
                                        goto code_r0x0001800e8547;
                                        iVar9 = iVar16;
                                    } while (iVar16 != 7);
                                    uVar24 = *(undefined4 *)(arg1 + 0x84);
                                    iVar21 = *(int32_t *)(arg1 + 0x88);
                                    if (iVar23 == 0x28) {
                                        fcn.1800f0350(arg1);
                                        cVar5 = '\x01';
                                        var_110h._4_4_ = uVar24;
                                    } else {
                                        cVar5 = func_0x0001800ef2a0(arg1, 0x28, 0x1806439c0);
                                        var_110h._4_4_ = uVar24;
                                    }
                                    iVar9 = func_0x0001800e9350(arg1, 0);
                                    piStack_e0 = *(int64_t **)(arg1 + 0x84);
                                    uStack_d8 = *(undefined4 *)(arg1 + 0x8c);
                                    uStack_d4 = *(undefined4 *)(arg1 + 0x90);
                                    uVar8 = CONCAT44(iVar21, var_110h._4_4_);
                                    var_110h._0_4_ = iVar23;
                                    var_108h = iVar21;
                                    cVar6 = func_0x0001800ef470(arg1, 0x29, &var_110h, 0);
                                    uStack_c8 = var_f0h;
                                    uStack_c0 = CONCAT44(uStack_d4, uStack_d8);
                                    piVar15 = (int64_t *)func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), 0x28);
                                    *(undefined4 *)(piVar15 + 1) = *(undefined4 *)0x180782744;
                                    *(undefined4 *)((int64_t)piVar15 + 0xc) = (undefined4)uStack_c8;
                                    *(undefined4 *)(piVar15 + 2) = uStack_c8._4_4_;
                                    *(undefined4 *)((int64_t)piVar15 + 0x14) = (undefined4)uStack_c0;
                                    *(undefined4 *)(piVar15 + 3) = uStack_c0._4_4_;
                                    *piVar15 = 0x180641a18;
                                    piVar15[4] = iVar9;
                                    if (*(char *)(arg1 + 0x58) != '\0') {
                                        if (cVar6 == '\0') {
                                            piStack_e0 = (int64_t *)0xffffffffffffffff;
                                        }
                                        piVar19 = piStack_e0;
                                        if (cVar5 == '\0') {
                                            piStack_e0 = (int64_t *)0xffffffffffffffff;
                                            uVar8 = 0xffffffffffffffff;
                                        }
                                        puVar10 = (undefined4 *)func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), 0x14);
                                        *puVar10 = *(undefined4 *)0x180782a6c;
                                        *(undefined8 *)(puVar10 + 1) = uVar8;
                                        *(int64_t **)(puVar10 + 3) = piVar19;
                                        piStack_e0 = piVar15;
                                        puVar17 = (undefined8 *)func_0x0001800cc970(arg1 + 0x490, &piStack_e0);
                                        *puVar17 = puVar10;
                                    }
                                    *(int64_t **)arg2 = piVar15;
                                    *(undefined8 *)(arg2 + 8) = 0;
                                    puVar18 = auStackY_168;
                                    goto code_r0x0001800e8dcb;
                                }
                            }
code_r0x0001800e8547:
                            uVar8 = CONCAT44(var_110h._4_4_, (int32_t)var_110h);
                            iVar9 = var_100h;
                            iVar23 = (int32_t)var_128h;
                            uVar24 = var_128h._4_4_;
                            uVar25 = (undefined4)var_120h;
                            uVar22 = var_120h._4_4_;
                        }
                        uStack_b0 = 0xffffffffffffffff;
                        piStack_e0 = (int64_t *)(arg1 + 0x440);
                        iVar16 = *(int64_t *)(arg1 + 0x448) - *piStack_e0;
                        var_100h = iVar16 >> 3;
                        var_80h._0_4_ = (int32_t)var_100h;
                        var_80h._4_4_ = (int32_t)(iVar16 >> 0x23);
                        uStack_a8 = 0xffffffffffffffff;
                        if (*(int32_t *)(arg1 + 0x80) == 0x3c) {
                            uVar26 = 1;
                            if (*(char *)(arg1 + 0x58) == '\0') {
                                var_148h = 0;
                                piVar15 = (int64_t *)func_0x0001800ed8e0(arg1, &var_128h, 0, 0);
                                var_130h = *piVar15;
                                iStack_b8 = piVar15[1];
                            } else {
                                var_148h = (int64_t)&uStack_a8;
                                piVar15 = (int64_t *)
                                          func_0x0001800ed8e0(arg1, &var_128h, &uStack_b0, &stack0xffffffffffffff78);
                                var_130h = *piVar15;
                                iStack_b8 = piVar15[1];
                                var_100h = CONCAT44(var_80h._4_4_, (int32_t)var_80h);
                            }
                        } else {
                            uVar26 = 0;
                            var_130h = 0;
                            iStack_b8 = 0;
                        }
                        uStack_c8 = *(int64_t *)(arg1 + 0xa0);
                        var_120h = *(int64_t *)(arg1 + 0xa8);
                        piVar15 = *(int64_t **)(arg1 + 0xd8);
                        var_110h._0_4_ = (int32_t)piVar15;
                        var_110h._4_4_ = (undefined4)((uint64_t)piVar15 >> 0x20);
                        var_128h = var_f0h;
                        iVar16 = *piVar15;
                        piVar15 = piVar15 + 1;
                        uStack_c0 = var_120h;
                        if (iVar16 == 0) {
code_r0x0001800e87eb:
                            var_f8h = (int64_t)piVar15;
                            puVar17 = (undefined8 *)func_0x000180459890(0x2008);
                            *puVar17 = *(undefined8 *)CONCAT44(var_110h._4_4_, (int32_t)var_110h);
                            *(undefined8 *)CONCAT44(var_110h._4_4_, (int32_t)var_110h) = puVar17;
                            var_f0h = (int64_t)(puVar17 + 1);
                            iVar16 = 0x78;
                            piVar15 = (int64_t *)var_f8h;
                        } else {
                            var_f0h = *piVar15 + 7 + iVar16 + 8 & 0xfffffffffffffff8;
                            if ((undefined8 *)(iVar16 + 0x2008) < (undefined8 *)(var_f0h + 0x78))
                            goto code_r0x0001800e87eb;
                            iVar16 = var_f0h + (0x78 - (iVar16 + 8));
                        }
                        iVar4 = var_100h;
                        *piVar15 = iVar16;
                        *(undefined4 *)(var_f0h + 8) = *(undefined4 *)0x1807826bc;
                        *(int32_t *)(var_f0h + 0xc) = (int32_t)var_128h;
                        *(undefined4 *)(var_f0h + 0x10) = var_128h._4_4_;
                        *(undefined4 *)(var_f0h + 0x14) = (undefined4)var_120h;
                        *(undefined4 *)(var_f0h + 0x18) = var_120h._4_4_;
                        *(undefined8 *)var_f0h = 0x1806419a0;
                        *(undefined *)(var_f0h + 0x20) = uVar26;
                        *(undefined8 *)(var_f0h + 0x28) = uVar8;
                        *(undefined *)(var_f0h + 0x30) = uVar27;
                        *(uint32_t *)(var_f0h + 0x31) = CONCAT13(uStack_104, var_108h._1_3_);
                        *(undefined2 *)(var_f0h + 0x35) = var_103h;
                        *(undefined *)(var_f0h + 0x37) = var_101h;
                        auVar2._4_4_ = uVar24;
                        auVar2._0_4_ = iVar23;
                        auVar2._8_4_ = uVar25;
                        auVar2._12_4_ = uVar22;
                        *(undefined (*) [16])(var_f0h + 0x38) = auVar2;
                        *(undefined *)(var_f0h + 0x48) = uVar27;
                        *(undefined2 *)(var_f0h + 0x49) = in_stack_fffffffffffffee9;
                        *(undefined *)(var_f0h + 0x4b) = in_stack_fffffffffffffeeb;
                        *(int64_t *)(var_f0h + 0x50) = iVar11;
                        *(int32_t *)(var_f0h + 0x58) = iStack_98;
                        *(undefined4 *)(var_f0h + 0x5c) = uStack_94;
                        *(int32_t *)(var_f0h + 0x60) = (int32_t)in_stack_ffffffffffffff70;
                        *(int32_t *)(var_f0h + 100) = (int32_t)((uint64_t)in_stack_ffffffffffffff70 >> 0x20);
                        *(int64_t *)(var_f0h + 0x68) = var_130h;
                        *(int64_t *)(var_f0h + 0x70) = iStack_b8;
                        if (*(char *)(arg1 + 0x58) != '\0') {
                            var_f8h = *(int64_t *)(arg1 + 0xd8);
                            iVar11 = *(int64_t *)var_f8h;
                            if (iVar11 == 0) {
code_r0x0001800e8998:
                                puVar17 = (undefined8 *)func_0x000180459890(0x2008);
                                *puVar17 = *(undefined8 *)var_f8h;
                                *(undefined8 **)var_f8h = puVar17;
                                puVar17 = puVar17 + 1;
                                iVar11 = 0x30;
                            } else {
                                puVar17 = (undefined8 *)
                                          (*(int64_t *)(var_f8h + 8) + 7 + iVar11 + 8 & 0xfffffffffffffff8);
                                if ((undefined8 *)(iVar11 + 0x2008U) < puVar17 + 6) goto code_r0x0001800e8998;
                                iVar11 = (int64_t)puVar17 + (0x30 - (iVar11 + 8));
                            }
                            *(int64_t *)(var_f8h + 8) = iVar11;
                            *(undefined4 *)puVar17 = *(undefined4 *)0x180782a98;
                            *(int64_t *)((int64_t)puVar17 + 4) = iVar9;
                            *(undefined8 *)((int64_t)puVar17 + 0xc) = uStack_b0;
                            puVar17[3] = 0;
                            puVar17[4] = 0;
                            puVar17[5] = uStack_a8;
                            var_110h._0_4_ = (int32_t)var_f0h;
                            var_110h._4_4_ = (undefined4)((uint64_t)var_f0h >> 0x20);
                            puVar12 = (undefined8 *)func_0x0001800cc970(arg1 + 0x490, &var_110h);
                            *puVar12 = puVar17;
                        }
                        *(int64_t *)arg2 = var_f0h;
                        *(undefined8 *)(arg2 + 8) = 0;
                        iVar9 = *piStack_e0 + iVar4 * 8;
                        puVar18 = auStackY_168;
                        if (iVar9 != piStack_e0[1]) {
                            piStack_e0[1] = iVar9;
                            puVar18 = auStackY_168;
                        }
                        goto code_r0x0001800e8dcb;
                    }
                    iVar23 = *(int32_t *)(arg1 + 0x80);
                    if (iVar23 == 0x7b) {
                        uVar8 = fcn.1800e5a70(arg1, var_148h, var_140h, 
                                              CONCAT62(in_stack_fffffffffffffeca, 
                                                       CONCAT11(in_stack_fffffffffffffec9, in_stack_fffffffffffffec8)), 
                                              var_128h, var_120h, 
                                              CONCAT44(in_stack_fffffffffffffeec, 
                                                       CONCAT13(in_stack_fffffffffffffeeb, 
                                                                CONCAT21(in_stack_fffffffffffffee9, 
                                                                         in_stack_fffffffffffffee8))), 
                                              CONCAT44(var_110h._4_4_, (int32_t)var_110h), in_stack_ffffffffffffff70, 
                                              CONCAT44(in_stack_ffffffffffffff7c, in_stack_ffffffffffffff78), 
                                              CONCAT44(var_80h._4_4_, (int32_t)var_80h), var_78h);
                        *(undefined8 *)arg2 = uVar8;
                        *(undefined8 *)(arg2 + 8) = 0;
                        puVar18 = auStackY_168;
                        goto code_r0x0001800e8dcb;
                    }
                    puVar18 = auStackY_168;
                    if ((iVar23 == 0x28) || (puVar18 = auStackY_168, iVar23 == 0x3c)) {
code_r0x0001800e8b4c:
                        *(undefined8 *)(puVar18 + 0x40) = 0;
                        *(undefined8 *)(puVar18 + 0x48) = 0;
                        goto code_r0x0001800e8dbe;
                    }
                    if (iVar23 != 299) {
                        var_128h = *(int64_t *)(arg1 + 0xa8);
                        var_120h = var_f0h;
                        uStack_c8 = var_128h;
                        uStack_c0 = *(int64_t *)(arg1 + 0x8c);
                        var_148h = func_0x0001800d62b0(arg1 + 0x80, &stack0xffffffffffffff78);
                        if (0xf < *(uint64_t *)(var_148h + 0x18)) {
                            var_148h = *(int64_t *)var_148h;
                        }
                        in_R8 = &var_128h;
                        uVar8 = func_0x0001800f0260(arg1, &uStack_c8, in_R8, 0x1806438c8);
                        *(undefined8 *)arg2 = uVar8;
                        *(undefined8 *)(arg2 + 8) = 0;
                        puVar18 = auStackY_168;
                        if ((uint64_t)var_70h < 0x10) goto code_r0x0001800e8dcb;
                        arg2 = var_70h + 1;
                        iVar11 = CONCAT44(in_stack_ffffffffffffff7c, in_stack_ffffffffffffff78);
                        iVar9 = iVar11;
                        if (0xfff < (uint64_t)arg2) {
                            iVar9 = *(int64_t *)(iVar11 + -8);
                            if (0x1f < (iVar11 - iVar9) - 8U) {
                                pcVar1 = (code *)swi(0x29);
                                (*pcVar1)(5);
                                puVar18 = auStackY_160;
                                goto code_r0x0001800e8b4c;
                            }
                            arg2 = var_70h + 0x28;
                        }
                        func_0x000180459c3c(iVar9, arg2);
                        puVar18 = auStackY_168;
                        goto code_r0x0001800e8dcb;
                    }
                    fcn.1800f0350(arg1);
                    var_128h = 0;
                    var_120h = 0;
                    uVar8 = 0x1806439d0;
                    piVar15 = &var_128h;
                }
code_r0x0001800e8405:
                uVar8 = func_0x0001800f0170(arg1, &var_f0h, piVar15, uVar8);
                *(undefined8 *)arg2 = uVar8;
                *(undefined8 *)(arg2 + 8) = 0;
                puVar18 = auStackY_168;
                goto code_r0x0001800e8dcb;
            }
            var_130h._0_4_ = 0;
            if (*(char *)(arg1 + 0x58) == '\0') {
                uVar20 = (uint32_t)var_f8h;
            } else {
                var_130h._0_4_ = 0;
                iVar21 = (uint32_t)var_130h;
                var_130h._0_4_ = iVar21;
                if (iVar23 == 0x10d) {
                    uVar20 = 3;
                } else if (iVar23 == 0x116) {
                    uVar20 = 2;
                    puVar17 = (undefined8 *)0x0;
                    do {
                        var_130h._0_4_ = (uint32_t)puVar17;
                        puVar17 = (undefined8 *)(uint64_t)((uint32_t)var_130h + 1);
                    } while (*(char *)((int64_t)puVar17 +
                                      (uint64_t)*(uint32_t *)(arg1 + 0x94) + *(int64_t *)(arg1 + 0x98)) != ']');
                } else if (iVar23 == 0x117) {
                    uVar20 = (uint32_t)
                             (*(char *)((uint64_t)*(uint32_t *)(arg1 + 0x94) + *(int64_t *)(arg1 + 0x98)) != '\'');
                } else {
                    var_130h._0_4_ = 0;
                    uVar20 = (uint32_t)var_130h;
                    var_130h._0_4_ = iVar21;
                }
            }
            uStack_c8 = 0;
            uStack_c0 = 0;
            puVar17 = &uStack_c8;
            if (*(char *)(arg1 + 0x58) == '\0') {
                puVar17 = (undefined8 *)0x0;
            }
            func_0x0001800edd70(arg1, &stack0xffffffffffffff78, puVar17);
            if ((char)var_78h == '\0') {
                var_128h = 0;
                var_120h = 0;
                uVar8 = 0x180643760;
                piVar15 = &var_128h;
                goto code_r0x0001800e8405;
            }
            ppiVar14 = *(int64_t ***)(arg1 + 0xd8);
            iVar9 = (int64_t)*ppiVar14;
            if (iVar9 == 0) {
code_r0x0001800e8c76:
                piVar15 = (int64_t *)func_0x000180459890(0x2008);
                *piVar15 = (int64_t)*ppiVar14;
                *ppiVar14 = piVar15;
                piVar15 = piVar15 + 1;
                piVar19 = (int64_t *)0x30;
            } else {
                piVar15 = (int64_t *)((int64_t)ppiVar14[1] + iVar9 + 0xf & 0xfffffffffffffff8);
                if ((int64_t *)(iVar9 + 0x2008) < piVar15 + 6) goto code_r0x0001800e8c76;
                piVar19 = (int64_t *)((int64_t)piVar15 + (0x30 - (iVar9 + 8)));
            }
            ppiVar14[1] = piVar19;
            *(undefined4 *)(piVar15 + 1) = *(undefined4 *)0x18078272c;
            *(undefined4 *)((int64_t)piVar15 + 0xc) = uVar24;
            *(undefined4 *)(piVar15 + 2) = uVar25;
            *(undefined4 *)((int64_t)piVar15 + 0x14) = uVar22;
            *(undefined4 *)(piVar15 + 3) = uVar28;
            *piVar15 = 0x180641ff0;
            *(undefined4 *)(piVar15 + 4) = in_stack_ffffffffffffff78;
            *(undefined4 *)((int64_t)piVar15 + 0x24) = in_stack_ffffffffffffff7c;
            *(int32_t *)(piVar15 + 5) = (int32_t)var_80h;
            *(int32_t *)((int64_t)piVar15 + 0x2c) = var_80h._4_4_;
            if (*(char *)(arg1 + 0x58) != '\0') {
                ppiVar14 = *(int64_t ***)(arg1 + 0xd8);
                var_110h._0_4_ = (int32_t)ppiVar14;
                var_110h._4_4_ = (undefined4)((uint64_t)ppiVar14 >> 0x20);
                iVar9 = (int64_t)*ppiVar14;
                if (iVar9 == 0) {
code_r0x0001800e8d06:
                    piVar19 = (int64_t *)func_0x000180459890(0x2008);
                    *piVar19 = (int64_t)*ppiVar14;
                    *ppiVar14 = piVar19;
                    piVar19 = piVar19 + 1;
                    piVar13 = (int64_t *)0x20;
                } else {
                    piVar19 = (int64_t *)((int64_t)ppiVar14[1] + iVar9 + 0xf & 0xfffffffffffffff8);
                    if ((int64_t *)(iVar9 + 0x2008U) < piVar19 + 4) goto code_r0x0001800e8d06;
                    piVar13 = (int64_t *)((int64_t)piVar19 + (0x20 - (iVar9 + 8)));
                }
                ppiVar14[1] = piVar13;
                *(undefined4 *)piVar19 = *(undefined4 *)0x180782a90;
                *(undefined4 *)(piVar19 + 1) = (undefined4)uStack_c8;
                *(undefined4 *)((int64_t)piVar19 + 0xc) = uStack_c8._4_4_;
                *(undefined4 *)(piVar19 + 2) = (undefined4)uStack_c0;
                *(undefined4 *)((int64_t)piVar19 + 0x14) = uStack_c0._4_4_;
                *(uint32_t *)(piVar19 + 3) = uVar20;
                *(uint32_t *)((int64_t)piVar19 + 0x1c) = (uint32_t)var_130h;
                var_110h._0_4_ = (int32_t)piVar15;
                var_110h._4_4_ = (undefined4)((uint64_t)piVar15 >> 0x20);
                ppiVar14 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_110h);
                *ppiVar14 = piVar19;
            }
            *(int64_t **)arg2 = piVar15;
            *(undefined8 *)(arg2 + 8) = 0;
            goto code_r0x0001800e8dcb;
        }
        fcn.1800f0350(arg1);
        ppiVar14 = *(int64_t ***)(arg1 + 0xd8);
        iVar9 = (int64_t)*ppiVar14;
        if (iVar9 == 0) {
code_r0x0001800e8369:
            piVar15 = (int64_t *)func_0x000180459890(0x2008);
            *piVar15 = (int64_t)*ppiVar14;
            *ppiVar14 = piVar15;
            piVar15 = piVar15 + 1;
            piVar19 = (int64_t *)0x28;
        } else {
            piVar15 = (int64_t *)((int64_t)ppiVar14[1] + iVar9 + 0xf & 0xfffffffffffffff8);
            if ((int64_t *)(iVar9 + 0x2008) < piVar15 + 5) goto code_r0x0001800e8369;
            piVar19 = (int64_t *)((int64_t)piVar15 + (0x28 - (iVar9 + 8)));
        }
        ppiVar14[1] = piVar19;
        *(undefined4 *)(piVar15 + 1) = *(undefined4 *)0x180782680;
        *(undefined4 *)((int64_t)piVar15 + 0xc) = uVar24;
        *(undefined4 *)(piVar15 + 2) = uVar25;
        *(undefined4 *)((int64_t)piVar15 + 0x14) = uVar22;
        *(undefined4 *)(piVar15 + 3) = uVar28;
        *piVar15 = 0x180641e88;
        *(undefined *)(piVar15 + 4) = 0;
        *(int64_t **)arg2 = piVar15;
        *(undefined8 *)(arg2 + 8) = 0;
        puVar18 = auStackY_168;
        goto code_r0x0001800e8dcb;
    }
    fcn.1800f0350(arg1);
    ppiVar14 = *(int64_t ***)(arg1 + 0xd8);
    iVar9 = (int64_t)*ppiVar14;
    if (iVar9 == 0) {
code_r0x0001800e82cb:
        piVar15 = (int64_t *)func_0x000180459890(0x2008);
        *piVar15 = (int64_t)*ppiVar14;
        *ppiVar14 = piVar15;
        piVar15 = piVar15 + 1;
        piVar19 = (int64_t *)0x28;
    } else {
        piVar15 = (int64_t *)((int64_t)ppiVar14[1] + iVar9 + 0xf & 0xfffffffffffffff8);
        if ((int64_t *)(iVar9 + 0x2008) < piVar15 + 5) goto code_r0x0001800e82cb;
        piVar19 = (int64_t *)((int64_t)piVar15 + (0x28 - (iVar9 + 8)));
    }
    ppiVar14[1] = piVar19;
    *(undefined4 *)(piVar15 + 1) = *(undefined4 *)0x180782680;
    *(undefined4 *)((int64_t)piVar15 + 0xc) = uVar24;
    *(undefined4 *)(piVar15 + 2) = uVar25;
    *(undefined4 *)((int64_t)piVar15 + 0x14) = uVar22;
    *(undefined4 *)(piVar15 + 3) = uVar28;
    *piVar15 = 0x180641e88;
    *(undefined *)(piVar15 + 4) = 1;
    *(int64_t **)arg2 = piVar15;
    *(undefined8 *)(arg2 + 8) = 0;
    puVar18 = auStackY_168;
code_r0x0001800e8dcb:
    *(undefined8 *)(puVar18 + -8) = 0x1800e8dda;
    func_0x000180459870(uVar7 ^ (uint64_t)puVar18);
    return;
}

// ============================================================
// Function: FUN_1800e8e20
// Address: 0x1800e8e20
// Size: 324 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

int64_t * fcn.1800e8e20(int64_t arg1)
{
    int64_t **ppiVar1;
    int64_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int32_t *piVar6;
    undefined8 uVar7;
    undefined8 *puVar8;
    int64_t *piVar9;
    int64_t var_8h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    
    if (*(int32_t *)(arg1 + 0x80) != 0x106) {
        if (*(int32_t *)(arg1 + 0x80) == 0x119) {
            piVar6 = (int32_t *)func_0x0001800d70e0(arg1 + 0x60, &var_58h);
            if (*piVar6 == 0x106) {
                if (*(int32_t *)(arg1 + 0x80) == 0x119) {
                    var_58h = *(int64_t *)(arg1 + 0x98);
                    var_50h = *(int64_t *)(arg1 + 0x84);
                    iVar2 = *(int64_t *)(arg1 + 0x8c);
                    var_48h = iVar2;
                    fcn.1800f0350(arg1);
                    var_48h = iVar2;
                } else {
                    func_0x0001800efe90(arg1, 0x1806438e0);
                    piVar9 = (int64_t *)(arg1 + 0x84);
                    var_50h = *piVar9;
                    var_78h = *piVar9;
                    var_58h = *(int64_t *)(arg1 + 0x128);
                    var_70h = var_78h;
                    var_48h = *piVar9;
                }
                var_68h._0_4_ = *(undefined4 *)(arg1 + 0x84);
                var_68h._4_4_ = *(undefined4 *)(arg1 + 0x88);
                var_60h._0_4_ = *(undefined4 *)(arg1 + 0x8c);
                var_60h._4_4_ = *(undefined4 *)(arg1 + 0x90);
                if (*(int32_t *)(arg1 + 0x80) == 0x106) {
                    fcn.1800f0350(arg1);
                } else {
                    func_0x0001800ef2a0(arg1, 0x106, 0x1806438f0);
                }
                var_78h = var_50h;
                var_70h = CONCAT44(var_60h._4_4_, (undefined4)var_60h);
                piVar9 = (int64_t *)func_0x0001800f1710(*(undefined8 *)(arg1 + 0xd8), &var_78h, &var_58h);
                if (*(char *)(arg1 + 0x58) != '\0') {
                    uVar7 = func_0x0001800f17c0(*(undefined8 *)(arg1 + 0xd8), &var_68h);
                    var_8h = (int64_t)piVar9;
                    puVar8 = (undefined8 *)func_0x0001800cc970(arg1 + 0x490, &var_8h);
                    *puVar8 = uVar7;
                }
                return piVar9;
            }
        }
        return (int64_t *)0x0;
    }
    var_68h._0_4_ = *(undefined4 *)(arg1 + 0x84);
    var_68h._4_4_ = *(undefined4 *)(arg1 + 0x88);
    var_60h._0_4_ = *(undefined4 *)(arg1 + 0x8c);
    var_60h._4_4_ = *(undefined4 *)(arg1 + 0x90);
    fcn.1800f0350();
    iVar4 = fcn.1800e8150(arg1);
    var_78h = CONCAT44(var_68h._4_4_, (undefined4)var_68h);
    ppiVar1 = *(int64_t ***)(arg1 + 0xd8);
    var_70h = *(int64_t *)(iVar4 + 0x14);
    iVar2 = (int64_t)*ppiVar1;
    if (iVar2 != 0) {
        piVar9 = (int64_t *)((int64_t)ppiVar1[1] + iVar2 + 0xf & 0xfffffffffffffff8);
        if (piVar9 + 5 <= (int64_t *)(iVar2 + 0x2008)) {
            piVar5 = (int64_t *)((int64_t)piVar9 + (0x28 - (iVar2 + 8)));
            goto code_r0x0001800e8ec7;
        }
    }
    piVar5 = (int64_t *)func_0x000180459890(0x2008);
    *piVar5 = (int64_t)*ppiVar1;
    piVar9 = piVar5 + 1;
    *ppiVar1 = piVar5;
    piVar5 = (int64_t *)0x28;
code_r0x0001800e8ec7:
    ppiVar1[1] = piVar5;
    uVar3 = *(undefined4 *)0x180782688;
    *piVar9 = 0x180642068;
    *(undefined4 *)(piVar9 + 1) = uVar3;
    *(undefined4 *)((int64_t)piVar9 + 0xc) = (undefined4)var_78h;
    *(undefined4 *)(piVar9 + 2) = var_78h._4_4_;
    *(undefined4 *)((int64_t)piVar9 + 0x14) = (undefined4)var_70h;
    *(undefined4 *)(piVar9 + 3) = var_70h._4_4_;
    piVar9[4] = iVar4;
    return piVar9;
}

// ============================================================
// Function: FUN_1800e8f64
// Address: 0x1800e8f64
// Size: 47 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

int64_t * fcn.1800e8e20(int64_t arg1)
{
    int64_t **ppiVar1;
    int64_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int32_t *piVar6;
    undefined8 uVar7;
    undefined8 *puVar8;
    int64_t *piVar9;
    int64_t var_8h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    
    if (*(int32_t *)(arg1 + 0x80) != 0x106) {
        if (*(int32_t *)(arg1 + 0x80) == 0x119) {
            piVar6 = (int32_t *)func_0x0001800d70e0(arg1 + 0x60, &var_58h);
            if (*piVar6 == 0x106) {
                if (*(int32_t *)(arg1 + 0x80) == 0x119) {
                    var_58h = *(int64_t *)(arg1 + 0x98);
                    var_50h = *(int64_t *)(arg1 + 0x84);
                    iVar2 = *(int64_t *)(arg1 + 0x8c);
                    var_48h = iVar2;
                    fcn.1800f0350(arg1);
                    var_48h = iVar2;
                } else {
                    func_0x0001800efe90(arg1, 0x1806438e0);
                    piVar9 = (int64_t *)(arg1 + 0x84);
                    var_50h = *piVar9;
                    var_78h = *piVar9;
                    var_58h = *(int64_t *)(arg1 + 0x128);
                    var_70h = var_78h;
                    var_48h = *piVar9;
                }
                var_68h._0_4_ = *(undefined4 *)(arg1 + 0x84);
                var_68h._4_4_ = *(undefined4 *)(arg1 + 0x88);
                var_60h._0_4_ = *(undefined4 *)(arg1 + 0x8c);
                var_60h._4_4_ = *(undefined4 *)(arg1 + 0x90);
                if (*(int32_t *)(arg1 + 0x80) == 0x106) {
                    fcn.1800f0350(arg1);
                } else {
                    func_0x0001800ef2a0(arg1, 0x106, 0x1806438f0);
                }
                var_78h = var_50h;
                var_70h = CONCAT44(var_60h._4_4_, (undefined4)var_60h);
                piVar9 = (int64_t *)func_0x0001800f1710(*(undefined8 *)(arg1 + 0xd8), &var_78h, &var_58h);
                if (*(char *)(arg1 + 0x58) != '\0') {
                    uVar7 = func_0x0001800f17c0(*(undefined8 *)(arg1 + 0xd8), &var_68h);
                    var_8h = (int64_t)piVar9;
                    puVar8 = (undefined8 *)func_0x0001800cc970(arg1 + 0x490, &var_8h);
                    *puVar8 = uVar7;
                }
                return piVar9;
            }
        }
        return (int64_t *)0x0;
    }
    var_68h._0_4_ = *(undefined4 *)(arg1 + 0x84);
    var_68h._4_4_ = *(undefined4 *)(arg1 + 0x88);
    var_60h._0_4_ = *(undefined4 *)(arg1 + 0x8c);
    var_60h._4_4_ = *(undefined4 *)(arg1 + 0x90);
    fcn.1800f0350();
    iVar4 = fcn.1800e8150(arg1);
    var_78h = CONCAT44(var_68h._4_4_, (undefined4)var_68h);
    ppiVar1 = *(int64_t ***)(arg1 + 0xd8);
    var_70h = *(int64_t *)(iVar4 + 0x14);
    iVar2 = (int64_t)*ppiVar1;
    if (iVar2 != 0) {
        piVar9 = (int64_t *)((int64_t)ppiVar1[1] + iVar2 + 0xf & 0xfffffffffffffff8);
        if (piVar9 + 5 <= (int64_t *)(iVar2 + 0x2008)) {
            piVar5 = (int64_t *)((int64_t)piVar9 + (0x28 - (iVar2 + 8)));
            goto code_r0x0001800e8ec7;
        }
    }
    piVar5 = (int64_t *)func_0x000180459890(0x2008);
    *piVar5 = (int64_t)*ppiVar1;
    piVar9 = piVar5 + 1;
    *ppiVar1 = piVar5;
    piVar5 = (int64_t *)0x28;
code_r0x0001800e8ec7:
    ppiVar1[1] = piVar5;
    uVar3 = *(undefined4 *)0x180782688;
    *piVar9 = 0x180642068;
    *(undefined4 *)(piVar9 + 1) = uVar3;
    *(undefined4 *)((int64_t)piVar9 + 0xc) = (undefined4)var_78h;
    *(undefined4 *)(piVar9 + 2) = var_78h._4_4_;
    *(undefined4 *)((int64_t)piVar9 + 0x14) = (undefined4)var_70h;
    *(undefined4 *)(piVar9 + 3) = var_70h._4_4_;
    piVar9[4] = iVar4;
    return piVar9;
}

// ============================================================
// Function: FUN_1800e8f93
// Address: 0x1800e8f93
// Size: 160 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

int64_t * fcn.1800e8e20(int64_t arg1)
{
    int64_t **ppiVar1;
    int64_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int32_t *piVar6;
    undefined8 uVar7;
    undefined8 *puVar8;
    int64_t *piVar9;
    int64_t var_8h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    
    if (*(int32_t *)(arg1 + 0x80) != 0x106) {
        if (*(int32_t *)(arg1 + 0x80) == 0x119) {
            piVar6 = (int32_t *)func_0x0001800d70e0(arg1 + 0x60, &var_58h);
            if (*piVar6 == 0x106) {
                if (*(int32_t *)(arg1 + 0x80) == 0x119) {
                    var_58h = *(int64_t *)(arg1 + 0x98);
                    var_50h = *(int64_t *)(arg1 + 0x84);
                    iVar2 = *(int64_t *)(arg1 + 0x8c);
                    var_48h = iVar2;
                    fcn.1800f0350(arg1);
                    var_48h = iVar2;
                } else {
                    func_0x0001800efe90(arg1, 0x1806438e0);
                    piVar9 = (int64_t *)(arg1 + 0x84);
                    var_50h = *piVar9;
                    var_78h = *piVar9;
                    var_58h = *(int64_t *)(arg1 + 0x128);
                    var_70h = var_78h;
                    var_48h = *piVar9;
                }
                var_68h._0_4_ = *(undefined4 *)(arg1 + 0x84);
                var_68h._4_4_ = *(undefined4 *)(arg1 + 0x88);
                var_60h._0_4_ = *(undefined4 *)(arg1 + 0x8c);
                var_60h._4_4_ = *(undefined4 *)(arg1 + 0x90);
                if (*(int32_t *)(arg1 + 0x80) == 0x106) {
                    fcn.1800f0350(arg1);
                } else {
                    func_0x0001800ef2a0(arg1, 0x106, 0x1806438f0);
                }
                var_78h = var_50h;
                var_70h = CONCAT44(var_60h._4_4_, (undefined4)var_60h);
                piVar9 = (int64_t *)func_0x0001800f1710(*(undefined8 *)(arg1 + 0xd8), &var_78h, &var_58h);
                if (*(char *)(arg1 + 0x58) != '\0') {
                    uVar7 = func_0x0001800f17c0(*(undefined8 *)(arg1 + 0xd8), &var_68h);
                    var_8h = (int64_t)piVar9;
                    puVar8 = (undefined8 *)func_0x0001800cc970(arg1 + 0x490, &var_8h);
                    *puVar8 = uVar7;
                }
                return piVar9;
            }
        }
        return (int64_t *)0x0;
    }
    var_68h._0_4_ = *(undefined4 *)(arg1 + 0x84);
    var_68h._4_4_ = *(undefined4 *)(arg1 + 0x88);
    var_60h._0_4_ = *(undefined4 *)(arg1 + 0x8c);
    var_60h._4_4_ = *(undefined4 *)(arg1 + 0x90);
    fcn.1800f0350();
    iVar4 = fcn.1800e8150(arg1);
    var_78h = CONCAT44(var_68h._4_4_, (undefined4)var_68h);
    ppiVar1 = *(int64_t ***)(arg1 + 0xd8);
    var_70h = *(int64_t *)(iVar4 + 0x14);
    iVar2 = (int64_t)*ppiVar1;
    if (iVar2 != 0) {
        piVar9 = (int64_t *)((int64_t)ppiVar1[1] + iVar2 + 0xf & 0xfffffffffffffff8);
        if (piVar9 + 5 <= (int64_t *)(iVar2 + 0x2008)) {
            piVar5 = (int64_t *)((int64_t)piVar9 + (0x28 - (iVar2 + 8)));
            goto code_r0x0001800e8ec7;
        }
    }
    piVar5 = (int64_t *)func_0x000180459890(0x2008);
    *piVar5 = (int64_t)*ppiVar1;
    piVar9 = piVar5 + 1;
    *ppiVar1 = piVar5;
    piVar5 = (int64_t *)0x28;
code_r0x0001800e8ec7:
    ppiVar1[1] = piVar5;
    uVar3 = *(undefined4 *)0x180782688;
    *piVar9 = 0x180642068;
    *(undefined4 *)(piVar9 + 1) = uVar3;
    *(undefined4 *)((int64_t)piVar9 + 0xc) = (undefined4)var_78h;
    *(undefined4 *)(piVar9 + 2) = var_78h._4_4_;
    *(undefined4 *)((int64_t)piVar9 + 0x14) = (undefined4)var_70h;
    *(undefined4 *)(piVar9 + 3) = var_70h._4_4_;
    piVar9[4] = iVar4;
    return piVar9;
}

// ============================================================
// Function: FUN_1800e9190
// Address: 0x1800e9190
// Size: 444 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

int64_t fcn.1800e9190(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4)
{
    int32_t iVar1;
    uint32_t uVar2;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    uVar2 = (uint32_t)arg4;
    iVar1 = *(int32_t *)(arg1 + 0x80);
    if (((iVar1 == 0x26) || (iVar1 == 0x7c)) || (iVar1 == 0x21)) {
        var_58h = *(int64_t *)(arg1 + 0x84);
        var_50h = *(int64_t *)(arg1 + 0x8c);
        func_0x0001800d70e0(arg1 + 0x60, &var_48h);
        iVar1 = *(int32_t *)(arg1 + 0x80);
        if (iVar1 == 0x26) {
            if ((((int32_t)var_48h == 0x26) && (*(int32_t *)(arg1 + 0x90) == (int32_t)var_40h)) &&
               ((*(int32_t *)(arg1 + 0x8c) == var_48h._4_4_ && (uVar2 < 2)))) {
                fcn.1800f0350(arg1);
                var_50h = stack0xffffffffffffffc4;
                fcn.1800efe70(arg1, &var_58h, 0x180643ad8);
                *(undefined4 *)arg2 = 0xe;
                *(undefined *)(arg2 + 4) = 1;
                return arg2;
            }
        } else if (iVar1 == 0x7c) {
            if (((((int32_t)var_48h == 0x7c) && (*(int32_t *)(arg1 + 0x90) == (int32_t)var_40h)) &&
                (*(int32_t *)(arg1 + 0x8c) == var_48h._4_4_)) && (uVar2 == 0)) {
                fcn.1800f0350(arg1);
                var_50h = stack0xffffffffffffffc4;
                fcn.1800efe70(arg1, &var_58h, 0x180643b00);
                *(undefined4 *)arg2 = 0xf;
                *(undefined *)(arg2 + 4) = 1;
                return arg2;
            }
        } else if (((iVar1 == 0x21) && ((int32_t)var_48h == 0x3d)) &&
                  ((*(int32_t *)(arg1 + 0x90) == (int32_t)var_40h &&
                   ((*(int32_t *)(arg1 + 0x8c) == var_48h._4_4_ && (uVar2 < 3)))))) {
            fcn.1800f0350(arg1);
            var_50h = stack0xffffffffffffffc4;
            fcn.1800efe70(arg1, &var_58h, 0x180643b28);
            *(undefined4 *)arg2 = 8;
            *(undefined *)(arg2 + 4) = 1;
            return arg2;
        }
    }
    *(undefined *)(arg2 + 4) = 0;
    return arg2;
}

// ============================================================
// Function: FUN_1800e9350
// Address: 0x1800e9350
// Size: 5061 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_318h
// WARNING: Variable defined which should be unmapped: var_310h
// WARNING: Variable defined which should be unmapped: var_308h
// WARNING: Variable defined which should be unmapped: var_300h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_137h
// WARNING: [rz-ghidra] Detected overlap for variable var_138h
// WARNING: [rz-ghidra] Detected overlap for variable var_107h
// WARNING: [rz-ghidra] Detected overlap for variable var_103h
// WARNING: [rz-ghidra] Detected overlap for variable var_101h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Removing arg arg_67h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_5dh
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_23h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable arg_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_135h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h

void fcn.1800e9350(int64_t arg1, int64_t arg2, int64_t arg_1d0h)
{
    uint8_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t *piVar7;
    char cVar8;
    int32_t iVar9;
    int32_t iVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    int32_t *piVar13;
    undefined4 *puVar14;
    int64_t iVar15;
    int64_t *piVar16;
    int64_t **ppiVar17;
    undefined8 *puVar18;
    int64_t *piVar19;
    int64_t iVar20;
    uint64_t uVar21;
    uint64_t uVar22;
    char **ppcVar23;
    uint64_t uVar24;
    uint64_t uVar25;
    uint64_t uVar26;
    undefined *puVar27;
    undefined *puVar28;
    int64_t **in_R8;
    uint64_t *puVar29;
    undefined8 uVar30;
    uint64_t uVar31;
    undefined4 uVar32;
    int64_t iVar33;
    int64_t **ppiVar34;
    int64_t *piVar35;
    double dVar36;
    undefined auStackY_338 [8];
    undefined auStackY_330 [24];
    int64_t var_318h;
    int64_t var_310h;
    int64_t var_308h;
    int64_t var_300h;
    int64_t var_2f8h;
    undefined8 var_2f0h;
    int64_t var_2e8h;
    int64_t var_2e0h;
    int64_t var_2d8h;
    int64_t var_2d0h;
    int64_t var_2c8h;
    int64_t var_2c0h;
    undefined8 uStack_2b8;
    undefined4 uStack_2b0;
    undefined4 uStack_2ac;
    undefined4 uStack_2a8;
    undefined4 uStack_2a4;
    int32_t iStack_2a0;
    undefined4 uStack_298;
    undefined4 uStack_294;
    undefined4 uStack_290;
    undefined4 uStack_28c;
    undefined8 uStack_288;
    undefined8 uStack_280;
    uint64_t uStack_270;
    undefined auStack_268 [248];
    int64_t in_stack_fffffffffffffe90;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    puVar27 = auStackY_338;
    puVar28 = auStackY_338;
    uVar12 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_338;
    var_2e0h._0_4_ = (undefined4)arg2;
    iStack_2a0 = *(int32_t *)(arg1 + 0x114);
    *(uint32_t *)(arg1 + 0x114) = iStack_2a0 + 1U;
    if (*(uint32_t *)0x180778500 < iStack_2a0 + 1U) {
        iVar20 = func_0x0001800d90d0(arg1 + 0x60);
        func_0x0001800d9940(iVar20 + 4, 0x180644050, 0x180643b50);
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    piVar7 = *(int64_t **)(arg1 + 0x84);
    uStack_280 = *(undefined8 *)(arg1 + 0x8c);
    iVar9 = *(int32_t *)(arg1 + 0x80);
    uStack_288 = piVar7;
    if (iVar9 == 0x130) {
code_r0x0001800ea150:
        uVar32 = 0;
code_r0x0001800ea153:
        var_2f8h = *(int64_t *)(arg1 + 0x84);
        fcn.1800f0350(arg1);
        iVar15 = fcn.1800e9350(arg1, 8, in_stack_fffffffffffffe90);
        ppiVar17 = *(int64_t ***)(arg1 + 0xd8);
        uStack_2b8 = *(undefined8 *)(iVar15 + 0x14);
        iVar20 = (int64_t)*ppiVar17;
        var_2c0h = (int64_t)piVar7;
        if (iVar20 == 0) {
code_r0x0001800ea1c4:
            piVar35 = (int64_t *)func_0x000180459890(0x2008);
            *piVar35 = (int64_t)*ppiVar17;
            *ppiVar17 = piVar35;
            piVar35 = piVar35 + 1;
            piVar16 = (int64_t *)0x30;
        } else {
            piVar35 = (int64_t *)((int64_t)ppiVar17[1] + iVar20 + 0xf & 0xfffffffffffffff8);
            if ((int64_t *)(iVar20 + 0x2008) < piVar35 + 6) goto code_r0x0001800ea1c4;
            piVar16 = (int64_t *)((int64_t)piVar35 + (0x30 - (iVar20 + 8)));
        }
        ppiVar17[1] = piVar16;
        *(undefined4 *)(piVar35 + 1) = *(undefined4 *)0x180782768;
        *(undefined4 *)((int64_t)piVar35 + 0xc) = (undefined4)var_2c0h;
        *(undefined4 *)(piVar35 + 2) = var_2c0h._4_4_;
        *(undefined4 *)((int64_t)piVar35 + 0x14) = (undefined4)uStack_2b8;
        *(undefined4 *)(piVar35 + 3) = uStack_2b8._4_4_;
        *piVar35 = 0x1806420b8;
        *(undefined4 *)(piVar35 + 4) = uVar32;
        piVar35[5] = iVar15;
        puVar28 = auStackY_338;
        piVar16 = piVar35;
        if (*(char *)(arg1 + 0x58) == '\0') goto code_r0x0001800ea240;
        piVar16 = (int64_t *)func_0x0001800f1860(*(undefined8 *)(arg1 + 0xd8), &var_2f8h);
        puVar28 = auStackY_338;
    } else {
        if (iVar9 == 0x2d) {
            uVar32 = 1;
            goto code_r0x0001800ea153;
        }
        if (iVar9 == 0x23) {
            uVar32 = 2;
            goto code_r0x0001800ea153;
        }
        uVar32 = *(undefined4 *)(int64_t *)(arg1 + 0x84);
        uVar4 = *(undefined4 *)(arg1 + 0x88);
        var_2c0h = *(int64_t *)(arg1 + 0x84);
        uVar5 = *(undefined4 *)(undefined8 *)(arg1 + 0x8c);
        uVar6 = *(undefined4 *)(arg1 + 0x90);
        uStack_2b8 = *(undefined8 *)(arg1 + 0x8c);
        uStack_298 = uVar32;
        uStack_294 = uVar4;
        uStack_290 = uVar5;
        uStack_28c = uVar6;
        if (iVar9 == 0x21) {
            in_R8 = (int64_t **)0x180643910;
            fcn.1800efe70(uVar32, &uStack_298);
            goto code_r0x0001800ea150;
        }
        var_2d0h = 0;
        var_2c8h = 0;
        if (iVar9 - 0x11cU < 2) {
            piVar35 = (int64_t *)func_0x0001800de530(arg1, &uStack_288);
            var_2d0h = *piVar35;
            var_2c8h = piVar35[1];
            iVar9 = *(int32_t *)(arg1 + 0x80);
            if (iVar9 == 299) goto code_r0x0001800e94e9;
            var_318h = func_0x0001800d62b0(arg1 + 0x80, &uStack_288);
            if (0xf < *(uint64_t *)(var_318h + 0x18)) {
                var_318h = *(int64_t *)var_318h;
            }
            var_2f8h = 0;
            var_2f0h = 0;
            in_R8 = (int64_t **)&var_2f8h;
            piVar16 = (int64_t *)func_0x0001800f0080(arg1, &var_2c0h, in_R8, 0x180643c90);
            puVar28 = auStackY_338;
            if (0xf < uStack_270) {
                piVar35 = uStack_288;
                if (0xfff < uStack_270 + 1) {
                    if ((uint64_t)((int64_t)uStack_288 + (-8 - uStack_288[-1])) < 0x20) {
                        func_0x000180459c3c(uStack_288[-1], uStack_270 + 0x28);
                        puVar28 = auStackY_338;
                        goto code_r0x0001800e9f9f;
                    }
                    pcVar3 = (code *)swi(0x29);
                    piVar35 = (int64_t *)(*pcVar3)(5);
                    puVar27 = auStackY_330;
                }
                *(undefined8 *)(puVar27 + -8) = 0x1800e94e4;
                func_0x000180459c3c(piVar35);
                puVar28 = puVar27;
            }
            goto code_r0x0001800e9f9f;
        }
code_r0x0001800e94e9:
        if (iVar9 == 0x12f) {
            fcn.1800f0350(arg1);
            ppiVar17 = *(int64_t ***)(arg1 + 0xd8);
            iVar20 = (int64_t)*ppiVar17;
            if (iVar20 == 0) {
code_r0x0001800e953b:
                piVar16 = (int64_t *)func_0x000180459890(0x2008);
                *piVar16 = (int64_t)*ppiVar17;
                *ppiVar17 = piVar16;
                piVar16 = piVar16 + 1;
                piVar35 = (int64_t *)0x20;
            } else {
                piVar16 = (int64_t *)((int64_t)ppiVar17[1] + iVar20 + 0xf & 0xfffffffffffffff8);
                if ((int64_t *)(iVar20 + 0x2008) < piVar16 + 4) goto code_r0x0001800e953b;
                piVar35 = (int64_t *)((int64_t)piVar16 + (0x20 - (iVar20 + 8)));
            }
            ppiVar17[1] = piVar35;
            *(undefined4 *)(piVar16 + 1) = *(undefined4 *)0x180782670;
            *(undefined4 *)((int64_t)piVar16 + 0xc) = uVar32;
            *(undefined4 *)(piVar16 + 2) = uVar4;
            *(undefined4 *)((int64_t)piVar16 + 0x14) = uVar5;
            *(undefined4 *)(piVar16 + 3) = uVar6;
            *piVar16 = 0x180641978;
            puVar28 = auStackY_338;
        } else if (iVar9 == 0x135) {
            fcn.1800f0350(arg1);
            ppiVar17 = *(int64_t ***)(arg1 + 0xd8);
            iVar20 = (int64_t)*ppiVar17;
            if (iVar20 == 0) {
code_r0x0001800e95cc:
                piVar16 = (int64_t *)func_0x000180459890(0x2008);
                *piVar16 = (int64_t)*ppiVar17;
                *ppiVar17 = piVar16;
                piVar16 = piVar16 + 1;
                piVar35 = (int64_t *)0x28;
            } else {
                piVar16 = (int64_t *)((int64_t)ppiVar17[1] + iVar20 + 0xf & 0xfffffffffffffff8);
                if ((int64_t *)(iVar20 + 0x2008) < piVar16 + 5) goto code_r0x0001800e95cc;
                piVar35 = (int64_t *)((int64_t)piVar16 + (0x28 - (iVar20 + 8)));
            }
            ppiVar17[1] = piVar35;
            *(undefined4 *)(piVar16 + 1) = *(undefined4 *)0x1807826cc;
            *(undefined4 *)((int64_t)piVar16 + 0xc) = uVar32;
            *(undefined4 *)(piVar16 + 2) = uVar4;
            *(undefined4 *)((int64_t)piVar16 + 0x14) = uVar5;
            *(undefined4 *)(piVar16 + 3) = uVar6;
            *piVar16 = 0x1806420e0;
            *(undefined *)(piVar16 + 4) = 1;
            puVar28 = auStackY_338;
        } else if (iVar9 == 0x129) {
            fcn.1800f0350(arg1);
            ppiVar17 = *(int64_t ***)(arg1 + 0xd8);
            iVar20 = (int64_t)*ppiVar17;
            if (iVar20 == 0) {
code_r0x0001800e9661:
                piVar16 = (int64_t *)func_0x000180459890(0x2008);
                *piVar16 = (int64_t)*ppiVar17;
                *ppiVar17 = piVar16;
                piVar16 = piVar16 + 1;
                piVar35 = (int64_t *)0x28;
            } else {
                piVar16 = (int64_t *)((int64_t)ppiVar17[1] + iVar20 + 0xf & 0xfffffffffffffff8);
                if ((int64_t *)(iVar20 + 0x2008) < piVar16 + 5) goto code_r0x0001800e9661;
                piVar35 = (int64_t *)((int64_t)piVar16 + (0x28 - (iVar20 + 8)));
            }
            ppiVar17[1] = piVar35;
            *(undefined4 *)(piVar16 + 1) = *(undefined4 *)0x1807826cc;
            *(undefined4 *)((int64_t)piVar16 + 0xc) = uVar32;
            *(undefined4 *)(piVar16 + 2) = uVar4;
            *(undefined4 *)((int64_t)piVar16 + 0x14) = uVar5;
            *(undefined4 *)(piVar16 + 3) = uVar6;
            *piVar16 = 0x1806420e0;
            *(undefined *)(piVar16 + 4) = 0;
            puVar28 = auStackY_338;
        } else {
            if (iVar9 == 299) {
                var_2c0h = *(int64_t *)(arg1 + 0x80);
                uStack_2b8 = *(undefined8 *)(arg1 + 0x88);
                uStack_2b0 = *(undefined4 *)(arg1 + 0x90);
                uStack_2ac = *(undefined4 *)(arg1 + 0x94);
                uStack_2a8 = *(undefined4 *)(arg1 + 0x98);
                uStack_2a4 = *(undefined4 *)(arg1 + 0x9c);
                fcn.1800f0350(arg1);
                var_2f8h = 0;
                var_300h._0_1_ = 0;
                var_308h = (int64_t)&var_2d0h;
                var_310h = 0;
                var_318h = (int64_t)&var_2f8h;
                in_R8 = (int64_t **)0x0;
                ppiVar17 = (int64_t **)
                           fcn.1800e3690(arg1, (int64_t)&uStack_288, 0, (int64_t)&var_2c0h, var_318h, 0, var_308h, 
                                         (uint64_t)var_300h._1_7_ << 8);
                piVar16 = *ppiVar17;
                puVar28 = auStackY_338;
                goto code_r0x0001800e9f9f;
            }
            if (iVar9 == 0x118) {
                uVar32 = *(undefined4 *)(int64_t *)(arg1 + 0x84);
                uVar4 = *(undefined4 *)(arg1 + 0x88);
                var_2c0h = *(int64_t *)(arg1 + 0x84);
                uVar5 = *(undefined4 *)(undefined8 *)(arg1 + 0x8c);
                uVar6 = *(undefined4 *)(arg1 + 0x90);
                uStack_2b8 = *(undefined8 *)(arg1 + 0x8c);
                ppiVar17 = (int64_t **)(arg1 + 0x470);
                in_R8 = (int64_t **)(uint64_t)*(uint32_t *)(arg1 + 0x94);
                func_0x00018000f180(ppiVar17, *(undefined8 *)(arg1 + 0x98));
                if (*(char *)(arg1 + 0x58) == '\0') {
                    var_2d0h = 0;
                    var_2d8h = 0;
                } else {
                    in_R8 = ppiVar17;
                    piVar35 = (int64_t *)func_0x0001800efa10(arg1, &uStack_288);
                    var_2d8h = *piVar35;
                    var_2d0h = piVar35[1];
                }
                ppiVar34 = ppiVar17;
                if (0xf < *(uint64_t *)(arg1 + 0x488)) {
                    ppiVar34 = (int64_t **)*ppiVar17;
                }
                if (*(int64_t *)(arg1 + 0x480) != 0) {
                    iVar20 = (int64_t)ppiVar34 + *(int64_t *)(arg1 + 0x480);
                    in_R8 = (int64_t **)CONCAT71((unkint7)((uint64_t)in_R8 >> 8), 0x5f);
                    iVar15 = func_0x0001804580f0(ppiVar34, iVar20);
                    if ((iVar15 != iVar20) && (iVar15 - (int64_t)ppiVar34 != -1)) {
                        puVar18 = (undefined8 *)(arg1 + 0x470);
                        if (*(uint64_t *)(arg1 + 0x488) < 0x10) {
                            iVar15 = arg1 + 0x470 + *(int64_t *)(arg1 + 0x480);
                            iVar33 = (int64_t)ppiVar17 + *(int64_t *)(arg1 + 0x480);
                            iVar20 = arg1 + 0x470;
                        } else {
                            iVar15 = *(int64_t *)(arg1 + 0x470) + *(int64_t *)(arg1 + 0x480);
                            iVar20 = *(int64_t *)(arg1 + 0x470);
                            iVar33 = (int64_t)*ppiVar17 + *(int64_t *)(arg1 + 0x480);
                        }
                        iVar20 = func_0x0001804580f0(iVar20, iVar33, 0x5f);
                        if (iVar20 != iVar33) {
                            iVar20 = func_0x000180458110(iVar20, iVar33, 0x5f);
                        }
                        puVar2 = puVar18;
                        if (0xf < *(uint64_t *)(arg1 + 0x488)) {
                            puVar2 = (undefined8 *)*puVar18;
                            puVar18 = (undefined8 *)*puVar18;
                        }
                        iVar33 = iVar20 - (int64_t)puVar2;
                        uVar24 = *(int64_t *)(arg1 + 0x480) - iVar33;
                        uVar21 = iVar15 - iVar20;
                        if (uVar24 < (uint64_t)(iVar15 - iVar20)) {
                            uVar21 = uVar24;
                        }
                        iVar20 = *(int64_t *)(arg1 + 0x480) - uVar21;
                        in_R8 = (int64_t **)((iVar20 - iVar33) + 1);
                        func_0x000180498030((int64_t)puVar18 + iVar33, (int64_t)puVar18 + iVar33 + uVar21);
                        *(int64_t *)(arg1 + 0x480) = iVar20;
                    }
                }
                if (*(char *)0x180778580 == '\0') {
code_r0x0001800e9c02:
                    var_2e8h = 0;
                    ppcVar23 = (char **)(arg1 + 0x470);
                    if (0xf < *(uint64_t *)(arg1 + 0x488)) {
                        ppcVar23 = (char **)*ppcVar23;
                    }
                    if (*(char *)ppcVar23 == '0') {
                        if (((*(char *)((int64_t)ppcVar23 + 1) + 0xbeU & 0xdf) == 0) &&
                           (*(char *)(char **)((int64_t)ppcVar23 + 2) != '\0')) {
                            in_R8 = (int64_t **)0x2;
                            ppcVar23 = (char **)((int64_t)ppcVar23 + 2);
                        } else {
                            if (((*(char *)((int64_t)ppcVar23 + 1) + 0xa8U & 0xdf) != 0) ||
                               (*(char *)((int64_t)ppcVar23 + 2) == '\0')) goto code_r0x0001800e9c81;
                            in_R8 = (int64_t **)0x10;
                        }
                        iVar9 = func_0x0001800eb4e0(&var_2e8h, ppcVar23);
                        fcn.1800f0350(arg1);
                        dVar36 = (double)var_2e8h;
                        if (iVar9 == 2) {
                            uVar30 = 0x1806440c0;
                            goto code_r0x0001800e9a08;
                        }
                    } else {
code_r0x0001800e9c81:
                        var_2f8h = 0;
                        dVar36 = (double)func_0x00018046b62c(ppcVar23, &var_2f8h);
                        if (*(char *)var_2f8h != '\0') {
                            fcn.1800f0350(arg1);
                            uVar30 = 0x1806440c0;
                            goto code_r0x0001800e9a08;
                        }
                        if (dVar36 < 9007199254740992.0) {
code_r0x0001800e9d22:
                            iVar9 = 0;
                        } else {
                            iVar20 = func_0x000180498cd0(ppcVar23);
                            iVar15 = func_0x00018046ed00(ppcVar23, 0x180643ac0);
                            if (iVar15 != iVar20) goto code_r0x0001800e9d22;
                            in_R8 = (int64_t **)0x180643acc;
                            func_0x000180065f60(auStack_268, 0x200, 0x180643acc, dVar36);
                            iVar10 = func_0x000180498f10(auStack_268, ppcVar23);
                            iVar9 = 1;
                            if (iVar10 == 0) goto code_r0x0001800e9d22;
                        }
                        fcn.1800f0350(arg1);
                    }
                    ppiVar17 = *(int64_t ***)(arg1 + 0xd8);
                    iVar20 = (int64_t)*ppiVar17;
                    if (iVar20 == 0) {
code_r0x0001800e9d6c:
                        piVar16 = (int64_t *)func_0x000180459890(0x2008);
                        *piVar16 = (int64_t)*ppiVar17;
                        *ppiVar17 = piVar16;
                        piVar16 = piVar16 + 1;
                        piVar35 = (int64_t *)0x30;
                    } else {
                        piVar16 = (int64_t *)((int64_t)ppiVar17[1] + iVar20 + 0xf & 0xfffffffffffffff8);
                        if ((int64_t *)(iVar20 + 0x2008) < piVar16 + 6) goto code_r0x0001800e9d6c;
                        piVar35 = (int64_t *)((int64_t)piVar16 + (0x30 - (iVar20 + 8)));
                    }
                    ppiVar17[1] = piVar35;
                    *(undefined4 *)(piVar16 + 1) = *(undefined4 *)0x1807826b4;
                    *(undefined4 *)((int64_t)piVar16 + 0xc) = uVar32;
                    *(undefined4 *)(piVar16 + 2) = uVar4;
                    *(undefined4 *)((int64_t)piVar16 + 0x14) = uVar5;
                    *(undefined4 *)(piVar16 + 3) = uVar6;
                    *piVar16 = 0x180641cf8;
                    piVar16[4] = (int64_t)dVar36;
                    *(int32_t *)(piVar16 + 5) = iVar9;
                    puVar28 = auStackY_338;
                    if (*(char *)(arg1 + 0x58) != '\0') {
                        ppiVar17 = *(int64_t ***)(arg1 + 0xd8);
                        iVar20 = (int64_t)*ppiVar17;
                        if (iVar20 == 0) {
code_r0x0001800e9df7:
                            piVar35 = (int64_t *)func_0x000180459890(0x2008);
                            *piVar35 = (int64_t)*ppiVar17;
                            *ppiVar17 = piVar35;
                            piVar35 = piVar35 + 1;
                            piVar19 = (int64_t *)0x18;
                        } else {
                            piVar35 = (int64_t *)((int64_t)ppiVar17[1] + iVar20 + 0xf & 0xfffffffffffffff8);
                            if ((int64_t *)(iVar20 + 0x2008U) < piVar35 + 3) goto code_r0x0001800e9df7;
                            piVar19 = (int64_t *)((int64_t)piVar35 + (0x18 - (iVar20 + 8)));
                        }
                        ppiVar17[1] = piVar19;
                        *(undefined4 *)piVar35 = *(undefined4 *)0x180782ab8;
                        piVar35[1] = var_2d8h;
                        piVar35[2] = var_2d0h;
                        var_2f8h = (int64_t)piVar16;
                        ppiVar17 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_2f8h);
                        *ppiVar17 = piVar35;
                        puVar28 = auStackY_338;
                    }
                } else {
                    iVar20 = arg1 + 0x470;
                    uVar21 = *(uint64_t *)(arg1 + 0x488);
                    if (0xf < uVar21) {
                        iVar20 = *(int64_t *)(arg1 + 0x470);
                    }
                    if (*(char *)(*(int64_t *)(arg1 + 0x480) + -1 + iVar20) != 'i') goto code_r0x0001800e9c02;
                    iVar20 = 0;
                    var_2e8h = 0;
                    piVar35 = (int64_t *)(arg1 + 0x470);
                    if (0xf < uVar21) {
                        piVar35 = (int64_t *)*piVar35;
                    }
                    iVar10 = 2;
                    iVar9 = func_0x000180498f90(piVar35, 0x1805ab2c0, 2);
                    if (iVar9 == 0) {
code_r0x0001800e9a34:
                        puVar18 = (undefined8 *)(arg1 + 0x470);
                        if (0xf < *(uint64_t *)(arg1 + 0x488)) {
                            puVar18 = (undefined8 *)*puVar18;
                        }
                        var_2e8h = 0;
                        in_R8 = (int64_t **)0x10;
                        iVar15 = func_0x00018046c748(puVar18, &var_2e8h);
                        if ((((undefined8 *)var_2e8h != puVar18) && (*(char *)var_2e8h == 'i')) &&
                           (*(char *)(var_2e8h + 1) == '\0')) {
                            if ((iVar15 == -1) && (piVar13 = (int32_t *)func_0x00018046b77c(), *piVar13 == 0x22)) {
                                puVar14 = (undefined4 *)func_0x00018046b77c();
                                *puVar14 = 0;
                                in_R8 = (int64_t **)0x10;
                                iVar15 = func_0x00018046c748(puVar18, &var_2e8h);
                                piVar13 = (int32_t *)func_0x00018046b77c();
                                if (*piVar13 == 0x22) {
                                    iVar10 = 4;
                                    goto code_r0x0001800e99ef;
                                }
                            }
                            iVar20 = iVar15;
                            iVar10 = 0;
                        }
                    } else {
                        piVar35 = (int64_t *)(arg1 + 0x470);
                        if (0xf < uVar21) {
                            piVar35 = (int64_t *)*piVar35;
                        }
                        iVar9 = func_0x000180498f90(piVar35, 0x180643fe8, 2);
                        if (iVar9 == 0) goto code_r0x0001800e9a34;
                        piVar35 = (int64_t *)(arg1 + 0x470);
                        uVar21 = *(uint64_t *)(arg1 + 0x488);
                        if (0xf < uVar21) {
                            piVar35 = (int64_t *)*piVar35;
                        }
                        iVar9 = func_0x000180498f90(piVar35, 0x180643f08, 2);
                        if (iVar9 == 0) {
code_r0x0001800e9970:
                            puVar18 = (undefined8 *)(arg1 + 0x470);
                            if (0xf < uVar21) {
                                puVar18 = (undefined8 *)*puVar18;
                            }
                            iVar15 = (int64_t)puVar18 + 2;
                            var_2e8h = 0;
                            in_R8 = (int64_t **)0x2;
                            iVar33 = func_0x00018046c748(iVar15, &var_2e8h);
                            if (((var_2e8h != iVar15) && (*(char *)var_2e8h == 'i')) &&
                               (*(char *)(var_2e8h + 1) == '\0')) {
                                if ((iVar33 == -1) && (piVar13 = (int32_t *)func_0x00018046b77c(), *piVar13 == 0x22)) {
                                    puVar14 = (undefined4 *)func_0x00018046b77c();
                                    *puVar14 = 0;
                                    in_R8 = (int64_t **)0x2;
                                    iVar33 = func_0x00018046c748(iVar15, &var_2e8h);
                                    piVar13 = (int32_t *)func_0x00018046b77c();
                                    if (*piVar13 == 0x22) {
                                        iVar10 = 3;
                                        goto code_r0x0001800e99ef;
                                    }
                                }
                                iVar10 = 0;
                                iVar20 = iVar33;
                            }
                        } else {
                            piVar35 = (int64_t *)(arg1 + 0x470);
                            if (0xf < uVar21) {
                                piVar35 = (int64_t *)*piVar35;
                            }
                            iVar9 = func_0x000180498f90(piVar35, 0x180643f0c, 2);
                            if (iVar9 == 0) goto code_r0x0001800e9970;
                            piVar35 = (int64_t *)(arg1 + 0x470);
                            if (0xf < uVar21) {
                                piVar35 = (int64_t *)*piVar35;
                            }
                            in_R8 = (int64_t **)0xa;
                            iVar10 = func_0x0001800eb600(&var_2e8h, piVar35);
                            iVar20 = var_2e8h;
                        }
                    }
code_r0x0001800e99ef:
                    fcn.1800f0350(arg1);
                    if (iVar10 == 2) {
                        uVar30 = 0x180643f10;
                    } else {
                        if (iVar10 == 0) {
                            ppiVar17 = *(int64_t ***)(arg1 + 0xd8);
                            iVar15 = (int64_t)*ppiVar17;
                            if (iVar15 == 0) {
code_r0x0001800e9b1c:
                                piVar16 = (int64_t *)func_0x000180459890(0x2008);
                                *piVar16 = (int64_t)*ppiVar17;
                                *ppiVar17 = piVar16;
                                piVar16 = piVar16 + 1;
                                piVar35 = (int64_t *)0x30;
                            } else {
                                piVar16 = (int64_t *)((int64_t)ppiVar17[1] + iVar15 + 0xf & 0xfffffffffffffff8);
                                if ((int64_t *)(iVar15 + 0x2008) < piVar16 + 6) goto code_r0x0001800e9b1c;
                                piVar35 = (int64_t *)((int64_t)piVar16 + (0x30 - (iVar15 + 8)));
                            }
                            ppiVar17[1] = piVar35;
                            *(undefined4 *)(piVar16 + 1) = *(undefined4 *)0x18078271c;
                            *(undefined4 *)((int64_t)piVar16 + 0xc) = uVar32;
                            *(undefined4 *)(piVar16 + 2) = uVar4;
                            *(undefined4 *)((int64_t)piVar16 + 0x14) = uVar5;
                            *(undefined4 *)(piVar16 + 3) = uVar6;
                            *piVar16 = 0x180641bb8;
                            piVar16[4] = iVar20;
                            *(undefined4 *)(piVar16 + 5) = 0;
                            puVar28 = auStackY_338;
                            if (*(char *)(arg1 + 0x58) == '\0') goto code_r0x0001800e9f9f;
                            ppiVar17 = *(int64_t ***)(arg1 + 0xd8);
                            iVar20 = (int64_t)*ppiVar17;
                            if (iVar20 == 0) {
code_r0x0001800e9ba6:
                                piVar35 = (int64_t *)func_0x000180459890(0x2008);
                                *piVar35 = (int64_t)*ppiVar17;
                                *ppiVar17 = piVar35;
                                piVar35 = piVar35 + 1;
                                piVar19 = (int64_t *)0x18;
                            } else {
                                piVar35 = (int64_t *)((int64_t)ppiVar17[1] + iVar20 + 0xf & 0xfffffffffffffff8);
                                if ((int64_t *)(iVar20 + 0x2008U) < piVar35 + 3) goto code_r0x0001800e9ba6;
                                piVar19 = (int64_t *)((int64_t)piVar35 + (0x18 - (iVar20 + 8)));
                            }
                            ppiVar17[1] = piVar19;
                            *(undefined4 *)piVar35 = *(undefined4 *)0x180782a94;
                            piVar35[1] = var_2d8h;
                            piVar35[2] = var_2d0h;
                            var_2f8h = (int64_t)piVar16;
                            ppiVar17 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_2f8h);
                            *ppiVar17 = piVar35;
                            puVar28 = auStackY_338;
                            goto code_r0x0001800e9f9f;
                        }
                        uVar30 = 0x180643f28;
                    }
code_r0x0001800e9a08:
                    var_2f0h = 0;
                    var_2f8h = 0;
                    in_R8 = (int64_t **)&var_2f8h;
                    piVar16 = (int64_t *)func_0x0001800f0080(arg1, &var_2c0h, in_R8, uVar30);
                    puVar28 = auStackY_338;
                }
            } else if ((iVar9 - 0x116U < 2) || (iVar9 == 0x10d)) {
                piVar16 = (int64_t *)func_0x0001800edec0(arg1);
            } else {
                if (iVar9 != 0x10a) {
                    if (iVar9 == 0x11e) {
                        fcn.1800f0350(arg1);
                        uVar30 = 0x180643938;
                    } else {
                        if (iVar9 != 0x121) {
                            if (iVar9 != 0x106) {
                                if (iVar9 == 0x7b) {
                                    piVar16 = (int64_t *)func_0x0001800ebfc0(arg1);
                                    puVar28 = auStackY_338;
                                } else if (iVar9 == 300) {
                                    piVar16 = (int64_t *)func_0x0001800ec7c0();
                                    puVar28 = auStackY_338;
                                } else {
                                    piVar16 = (int64_t *)func_0x0001800ea9f0(arg1, 0);
                                    puVar28 = auStackY_338;
                                }
                                goto code_r0x0001800e9f9f;
                            }
                            if (*(char *)(*(int64_t *)(arg1 + 0x150) + -8) == '\0') {
                                fcn.1800f0350(arg1);
                                uVar30 = 0x180643d30;
                                goto code_r0x0001800e9a08;
                            }
                            fcn.1800f0350(arg1);
                            ppiVar17 = *(int64_t ***)(arg1 + 0xd8);
                            iVar20 = (int64_t)*ppiVar17;
                            if (iVar20 == 0) {
code_r0x0001800e9f1d:
                                piVar16 = (int64_t *)func_0x000180459890(0x2008);
                                *piVar16 = (int64_t)*ppiVar17;
                                *ppiVar17 = piVar16;
                                piVar16 = piVar16 + 1;
                                piVar35 = (int64_t *)0x20;
                            } else {
                                piVar16 = (int64_t *)((int64_t)ppiVar17[1] + iVar20 + 0xf & 0xfffffffffffffff8);
                                if ((int64_t *)(iVar20 + 0x2008) < piVar16 + 4) goto code_r0x0001800e9f1d;
                                piVar35 = (int64_t *)((int64_t)piVar16 + (0x20 - (iVar20 + 8)));
                            }
                            ppiVar17[1] = piVar35;
                            *(undefined4 *)(piVar16 + 1) = *(undefined4 *)0x1807826b8;
                            *(undefined4 *)((int64_t)piVar16 + 0xc) = uVar32;
                            *(undefined4 *)(piVar16 + 2) = uVar4;
                            *(undefined4 *)((int64_t)piVar16 + 0x14) = uVar5;
                            *(undefined4 *)(piVar16 + 3) = uVar6;
                            *piVar16 = 0x180641fa0;
                            puVar28 = auStackY_338;
                            goto code_r0x0001800e9f9f;
                        }
                        fcn.1800f0350(arg1);
                        uVar30 = 0x180643ce0;
                    }
                    goto code_r0x0001800e9a08;
                }
                piVar16 = (int64_t *)func_0x0001800ee150(arg1);
                puVar28 = auStackY_338;
            }
        }
code_r0x0001800e9f9f:
        iVar20 = 0;
        if (*(int32_t *)(arg1 + 0x80) != 0x108) goto code_r0x0001800ea240;
        *(undefined8 *)(puVar28 + 0x40) = *(undefined8 *)(arg1 + 0x84);
        *(undefined8 *)(puVar28 + -8) = 0x1800e9fc3;
        fcn.1800f0350(arg1);
        uVar32 = *(undefined4 *)(arg1 + 0x114);
        uStack_288 = *(int64_t **)(arg1 + 0x84);
        uStack_280 = *(undefined8 *)(arg1 + 0x8c);
        if ((*(int32_t *)(arg1 + 0x80) != 0x7c) && (*(int32_t *)(arg1 + 0x80) != 0x26)) {
            *(undefined8 *)(puVar28 + -8) = 0x1800e9ffb;
            piVar35 = (int64_t *)fcn.1800e81c0(arg1, (int64_t)(puVar28 + 0x78));
            iVar20 = *piVar35;
            *(undefined4 *)(arg1 + 0x114) = uVar32;
        }
        in_R8 = (int64_t **)&uStack_288;
        *(undefined8 *)(puVar28 + -8) = 0x1800ea011;
        iVar15 = fcn.1800e7930(arg1, iVar20, (int64_t)in_R8);
        *(undefined4 *)(arg1 + 0x114) = uVar32;
        ppiVar17 = *(int64_t ***)(arg1 + 0xd8);
        *(uint64_t *)(puVar28 + 0x78) = CONCAT44(uStack_294, uStack_298);
        uStack_2b8 = *(undefined8 *)(iVar15 + 0x14);
        iVar20 = (int64_t)*ppiVar17;
        if (iVar20 == 0) {
code_r0x0001800ea06c:
            *(undefined8 *)(puVar28 + -8) = 0x1800ea076;
            piVar35 = (int64_t *)func_0x000180459890(0x2008);
            *piVar35 = (int64_t)*ppiVar17;
            *ppiVar17 = piVar35;
            piVar35 = piVar35 + 1;
            piVar19 = (int64_t *)0x30;
        } else {
            piVar35 = (int64_t *)((int64_t)ppiVar17[1] + iVar20 + 0xf & 0xfffffffffffffff8);
            if ((int64_t *)(iVar20 + 0x2008) < piVar35 + 6) goto code_r0x0001800ea06c;
            piVar19 = (int64_t *)((int64_t)piVar35 + (0x30 - (iVar20 + 8)));
        }
        ppiVar17[1] = piVar19;
        *(undefined4 *)(piVar35 + 1) = *(undefined4 *)0x180782708;
        uVar32 = *(undefined4 *)(puVar28 + 0x7c);
        uVar4 = *(undefined4 *)(puVar28 + 0x80);
        uVar5 = *(undefined4 *)(puVar28 + 0x84);
        *(undefined4 *)((int64_t)piVar35 + 0xc) = *(undefined4 *)(puVar28 + 0x78);
        *(undefined4 *)(piVar35 + 2) = uVar32;
        *(undefined4 *)((int64_t)piVar35 + 0x14) = uVar4;
        *(undefined4 *)(piVar35 + 3) = uVar5;
        *piVar35 = 0x180642248;
        piVar35[4] = (int64_t)piVar16;
        piVar35[5] = iVar15;
        piVar16 = piVar35;
        if (*(char *)(arg1 + 0x58) == '\0') goto code_r0x0001800ea240;
        ppiVar17 = *(int64_t ***)(arg1 + 0xd8);
        iVar20 = (int64_t)*ppiVar17;
        if (iVar20 == 0) {
code_r0x0001800ea0ff:
            *(undefined8 *)(puVar28 + -8) = 0x1800ea109;
            piVar16 = (int64_t *)func_0x000180459890(0x2008);
            *piVar16 = (int64_t)*ppiVar17;
            *ppiVar17 = piVar16;
            piVar16 = piVar16 + 1;
            piVar19 = (int64_t *)0xc;
        } else {
            piVar16 = (int64_t *)((int64_t)ppiVar17[1] + iVar20 + 0xf & 0xfffffffffffffff8);
            if (iVar20 + 0x2008U < (int64_t)piVar16 + 0xcU) goto code_r0x0001800ea0ff;
            piVar19 = (int64_t *)((int64_t)piVar16 + (0xc - (iVar20 + 8)));
        }
        ppiVar17[1] = piVar19;
        *(undefined4 *)piVar16 = *(undefined4 *)0x180782aa0;
        *(undefined8 *)((int64_t)piVar16 + 4) = *(undefined8 *)(puVar28 + 0x40);
    }
    *(int64_t **)(puVar28 + 0x40) = piVar35;
    *(undefined8 *)(puVar28 + -8) = 0x1800ea23d;
    ppiVar17 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, puVar28 + 0x40);
    *ppiVar17 = piVar16;
    piVar16 = piVar35;
code_r0x0001800ea240:
    *(undefined8 *)(puVar28 + -8) = 0x1800ea251;
    func_0x0001800e9040(puVar28 + 0x40, arg1 + 0x80);
    uVar11 = *(uint32_t *)(puVar28 + 0x58);
    if (puVar28[0x44] == '\0') {
        *(undefined8 *)(puVar28 + -8) = 0x1800ea26d;
        puVar18 = (undefined8 *)fcn.1800e9190(arg1, (int64_t)(puVar28 + 0x40), in_R8, (uint64_t)uVar11);
        uVar30 = *puVar18;
    } else {
        uVar30 = *(undefined8 *)(puVar28 + 0x40);
    }
    cVar8 = (char)((uint64_t)uVar30 >> 0x20);
    while (cVar8 != '\0') {
        iVar9 = (int32_t)uVar30;
        if (*(uint8_t *)((int64_t)iVar9 * 2 + 0x1806441b0) <= uVar11) break;
        *(undefined8 *)(puVar28 + 0x60) = *(undefined8 *)(arg1 + 0x84);
        *(undefined8 *)(puVar28 + -8) = 0x1800ea2b6;
        fcn.1800f0350(arg1);
        uVar1 = *(uint8_t *)((int64_t)iVar9 * 2 + 0x1806441b1);
        *(undefined8 *)(puVar28 + -8) = 0x1800ea2c4;
        iVar15 = fcn.1800e9350(arg1, (uint64_t)uVar1, *(int64_t *)(puVar28 + 0x1c8));
        ppiVar17 = *(int64_t ***)(arg1 + 0xd8);
        uStack_280 = *(undefined8 *)(iVar15 + 0x14);
        iVar20 = (int64_t)*ppiVar17;
        if (iVar20 == 0) {
code_r0x0001800ea320:
            *(undefined8 *)(puVar28 + -8) = 0x1800ea32a;
            uStack_288 = piVar7;
            piVar35 = (int64_t *)func_0x000180459890(0x2008);
            *piVar35 = (int64_t)*ppiVar17;
            *ppiVar17 = piVar35;
            piVar35 = piVar35 + 1;
            piVar19 = (int64_t *)0x38;
        } else {
            uVar21 = (int64_t)ppiVar17[1] + iVar20 + 0xf & 0xfffffffffffffff8;
            *(uint64_t *)(puVar28 + 0x40) = uVar21;
            if (iVar20 + 0x2008U < uVar21 + 0x38) goto code_r0x0001800ea320;
            piVar35 = *(int64_t **)(puVar28 + 0x40);
            piVar19 = (int64_t *)((int64_t)piVar35 + (0x38 - (iVar20 + 8)));
            uStack_288 = piVar7;
        }
        ppiVar17[1] = piVar19;
        *(undefined4 *)(piVar35 + 1) = *(undefined4 *)0x180782668;
        *(undefined4 *)((int64_t)piVar35 + 0xc) = (undefined4)uStack_288;
        *(undefined4 *)(piVar35 + 2) = uStack_288._4_4_;
        *(undefined4 *)((int64_t)piVar35 + 0x14) = (undefined4)uStack_280;
        *(undefined4 *)(piVar35 + 3) = uStack_280._4_4_;
        *piVar35 = 0x180641b90;
        *(int32_t *)(piVar35 + 4) = iVar9;
        piVar35[5] = (int64_t)piVar16;
        piVar35[6] = iVar15;
        if (*(char *)(arg1 + 0x58) != '\0') {
            ppiVar17 = *(int64_t ***)(arg1 + 0xd8);
            iVar20 = (int64_t)*ppiVar17;
            if (iVar20 == 0) {
code_r0x0001800ea3bd:
                *(undefined8 *)(puVar28 + -8) = 0x1800ea3c7;
                piVar16 = (int64_t *)func_0x000180459890(0x2008);
                *piVar16 = (int64_t)*ppiVar17;
                *ppiVar17 = piVar16;
                piVar16 = piVar16 + 1;
                *(int64_t **)(puVar28 + 0x68) = piVar16;
                piVar19 = (int64_t *)0xc;
            } else {
                piVar16 = (int64_t *)((int64_t)ppiVar17[1] + iVar20 + 0xf & 0xfffffffffffffff8);
                *(int64_t **)(puVar28 + 0x68) = piVar16;
                if (iVar20 + 0x2008U < (int64_t)piVar16 + 0xcU) goto code_r0x0001800ea3bd;
                piVar19 = (int64_t *)((int64_t)piVar16 + (0xc - (iVar20 + 8)));
            }
            ppiVar17[1] = piVar19;
            *(undefined4 *)piVar16 = *(undefined4 *)0x180782aac;
            *(undefined8 *)((int64_t)piVar16 + 4) = *(undefined8 *)(puVar28 + 0x60);
            if ((uint64_t)(*(int64_t *)(arg1 + 0x498) * 3) >> 2 <= *(uint64_t *)(arg1 + 0x4a0)) {
                if ((*(uint64_t *)(arg1 + 0x4a0) != 0) && (piVar35 != *(int64_t **)(arg1 + 0x4a8))) {
                    uVar31 = *(int64_t *)(arg1 + 0x498) - 1;
                    uVar21 = ((uint64_t)piVar35 >> 5 ^ (uint64_t)piVar35) >> 4;
                    uVar24 = 0;
                    do {
                        uVar21 = uVar21 & uVar31;
                        piVar19 = *(int64_t **)(*(int64_t *)(arg1 + 0x490) + uVar21 * 0x10);
                        if (piVar19 == piVar35) goto code_r0x0001800ea5c1;
                        if (piVar19 == *(int64_t **)(arg1 + 0x4a8)) break;
                        uVar21 = uVar21 + 1 + uVar24;
                        uVar24 = uVar24 + 1;
                    } while (uVar24 <= uVar31);
                }
                iVar20 = *(int64_t *)(arg1 + 0x498);
                uVar21 = *(uint64_t *)(arg1 + 0x4a8);
                if (iVar20 == 0) {
                    uVar24 = 0x10;
                    *(undefined8 *)(puVar28 + -8) = 0x1800ea48c;
                    iVar15 = func_0x000180459890(0x100);
                    uVar25 = 0;
                    uVar31 = 0x10;
                    iVar20 = iVar15;
code_r0x0001800ea4c0:
                    do {
                        *(undefined8 *)(iVar15 + uVar25 * 0x10) = *(undefined8 *)(arg1 + 0x4a8);
                        *(undefined8 *)(iVar15 + 8 + uVar25 * 0x10) = 0;
                        uVar25 = uVar25 + 1;
                    } while (uVar25 < uVar24);
                } else {
                    uVar24 = iVar20 * 2;
                    if (uVar24 == 0) {
                        uVar31 = 0;
                        iVar20 = 0;
                    } else {
                        *(undefined8 *)(puVar28 + -8) = 0x1800ea4aa;
                        iVar15 = func_0x000180459890(iVar20 << 5);
                        uVar25 = 0;
                        uVar31 = uVar24;
                        iVar20 = iVar15;
                        if (uVar24 != 0) goto code_r0x0001800ea4c0;
                    }
                }
                uVar24 = 0;
                if (*(int64_t *)(arg1 + 0x498) != 0) {
                    do {
                        uVar25 = *(uint64_t *)(*(int64_t *)(arg1 + 0x490) + uVar24 * 0x10);
                        if (uVar25 != *(uint64_t *)(arg1 + 0x4a8)) {
                            uVar22 = (uVar25 >> 5 ^ uVar25) >> 4;
                            uVar26 = 0;
                            do {
                                uVar22 = uVar22 & uVar31 - 1;
                                puVar29 = (uint64_t *)(uVar22 * 0x10 + iVar20);
                                if (*puVar29 == uVar21) {
                                    *puVar29 = uVar25;
                                    goto code_r0x0001800ea570;
                                }
                                if (*puVar29 == uVar25) goto code_r0x0001800ea570;
                                uVar22 = uVar22 + 1 + uVar26;
                                uVar26 = uVar26 + 1;
                            } while (uVar26 <= uVar31 - 1);
                            puVar29 = (uint64_t *)0x0;
code_r0x0001800ea570:
                            iVar15 = *(int64_t *)(arg1 + 0x490);
                            *puVar29 = *(uint64_t *)(iVar15 + uVar24 * 0x10);
                            puVar29[1] = *(uint64_t *)(iVar15 + 8 + uVar24 * 0x10);
                        }
                        uVar24 = uVar24 + 1;
                    } while (uVar24 < *(uint64_t *)(arg1 + 0x498));
                }
                iVar15 = *(int64_t *)(arg1 + 0x490);
                *(int64_t *)(arg1 + 0x490) = iVar20;
                *(uint64_t *)(arg1 + 0x498) = uVar31;
                if (iVar15 != 0) {
                    *(undefined8 *)(puVar28 + -8) = 0x1800ea5bc;
                    func_0x0001800f4640();
                }
                piVar16 = *(int64_t **)(puVar28 + 0x68);
            }
code_r0x0001800ea5c1:
            uVar31 = *(int64_t *)(arg1 + 0x498) - 1;
            uVar21 = ((uint64_t)piVar35 >> 5 ^ (uint64_t)piVar35) >> 4;
            uVar24 = 0;
            do {
                uVar21 = uVar21 & uVar31;
                in_R8 = (int64_t **)(uVar21 * 0x10 + *(int64_t *)(arg1 + 0x490));
                if (*in_R8 == *(int64_t **)(arg1 + 0x4a8)) {
                    *in_R8 = piVar35;
                    *(int64_t *)(arg1 + 0x4a0) = *(int64_t *)(arg1 + 0x4a0) + 1;
                    goto code_r0x0001800ea627;
                }
                if (*in_R8 == piVar35) goto code_r0x0001800ea627;
                uVar21 = uVar21 + 1 + uVar24;
                uVar24 = uVar24 + 1;
            } while (uVar24 <= uVar31);
            in_R8 = (int64_t **)0x0;
code_r0x0001800ea627:
            in_R8[1] = piVar16;
        }
        *(undefined8 *)(puVar28 + -8) = 0x1800ea63c;
        puVar18 = (undefined8 *)func_0x0001800e9040(puVar28 + 0x50, arg1 + 0x80);
        uVar30 = *puVar18;
        if ((char)((uint64_t)uVar30 >> 0x20) == '\0') {
            *(undefined8 *)(puVar28 + -8) = 0x1800ea65c;
            puVar18 = (undefined8 *)
                      fcn.1800e9190(arg1, (int64_t)(puVar28 + 0x78), in_R8, (uint64_t)*(uint32_t *)(puVar28 + 0x58));
            uVar30 = *puVar18;
        }
        uVar11 = *(int32_t *)(arg1 + 0x114) + 1;
        *(uint32_t *)(arg1 + 0x114) = uVar11;
        if (*(uint32_t *)0x180778500 < uVar11) {
            *(undefined8 *)(puVar28 + -8) = 0x1800ea6fd;
            iVar20 = func_0x0001800d90d0(arg1 + 0x60);
            *(undefined8 *)(puVar28 + -8) = 0x1800ea714;
            func_0x0001800d9940(iVar20 + 4, 0x180644050, 0x180643b50);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        uVar11 = *(uint32_t *)(puVar28 + 0x58);
        piVar16 = piVar35;
        cVar8 = (char)((uint64_t)uVar30 >> 0x20);
    }
    *(int32_t *)(arg1 + 0x114) = iStack_2a0;
    *(undefined8 *)(puVar28 + -8) = 0x1800ea6ae;
    func_0x000180459870(uVar12 ^ (uint64_t)puVar28);
    return;
}

// ============================================================
// Function: FUN_1800ea720
// Address: 0x1800ea720
// Size: 254 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

int64_t * fcn.1800ea720(int64_t arg1)
{
    int64_t iVar1;
    int64_t **ppiVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    uint64_t uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t *piVar10;
    int64_t iVar11;
    undefined4 uVar12;
    int64_t *piVar13;
    int64_t var_8h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    undefined4 uStack_48;
    undefined4 uStack_44;
    int64_t var_40h;
    int64_t var_38h;
    
    if (*(int32_t *)(arg1 + 0x80) != 0x119) {
        func_0x0001800efe90();
        iVar1 = *(int64_t *)(arg1 + 0x1d8);
        iVar11 = *(int64_t *)(arg1 + 0x1d0);
        ppiVar2 = *(int64_t ***)(arg1 + 0xd8);
        func_0x0001800f1110(arg1, &var_58h, 0, 0);
        iVar3 = (int64_t)*ppiVar2;
        if (iVar3 != 0) {
            piVar13 = (int64_t *)((int64_t)ppiVar2[1] + iVar3 + 0xf & 0xfffffffffffffff8);
            if (piVar13 + 7 <= (int64_t *)(iVar3 + 0x2008)) {
                piVar10 = (int64_t *)((int64_t)piVar13 + (0x38 - (iVar3 + 8)));
                goto code_r0x0001800ea7d3;
            }
        }
        piVar10 = (int64_t *)func_0x000180459890(0x2008);
        *piVar10 = (int64_t)*ppiVar2;
        piVar13 = piVar10 + 1;
        *ppiVar2 = piVar10;
        piVar10 = (int64_t *)0x38;
code_r0x0001800ea7d3:
        ppiVar2[1] = piVar10;
        uVar6 = *(undefined4 *)0x1807826f0;
        *piVar13 = 0x180642298;
        *(undefined4 *)(piVar13 + 1) = uVar6;
        uVar6 = *(undefined4 *)(arg1 + 0x84);
        uVar7 = *(undefined4 *)(arg1 + 0x88);
        uVar8 = *(undefined4 *)(arg1 + 0x8c);
        uVar9 = *(undefined4 *)(arg1 + 0x90);
        *piVar13 = 0x180641ae0;
        *(int32_t *)(piVar13 + 6) = (int32_t)(iVar1 - iVar11 >> 3) * 0x38e38e39 + -1;
        *(undefined4 *)((int64_t)piVar13 + 0xc) = uVar6;
        *(undefined4 *)(piVar13 + 2) = uVar7;
        *(undefined4 *)((int64_t)piVar13 + 0x14) = uVar8;
        *(undefined4 *)(piVar13 + 3) = uVar9;
        *(undefined4 *)(piVar13 + 4) = (undefined4)var_58h;
        *(undefined4 *)((int64_t)piVar13 + 0x24) = var_58h._4_4_;
        *(undefined4 *)(piVar13 + 5) = (undefined4)var_50h;
        *(undefined4 *)((int64_t)piVar13 + 0x2c) = var_50h._4_4_;
        return piVar13;
    }
    iVar1 = *(int64_t *)(arg1 + 0x98);
    uVar6 = *(undefined4 *)(int64_t *)(arg1 + 0x84);
    uVar7 = *(undefined4 *)(arg1 + 0x88);
    iVar11 = *(int64_t *)(arg1 + 0x84);
    uVar8 = *(undefined4 *)(arg1 + 0x8c);
    uVar9 = *(undefined4 *)(arg1 + 0x90);
    fcn.1800f0350();
    var_40h._0_1_ = 1;
    var_58h = iVar1;
    var_50h = iVar11;
    uStack_48 = uVar8;
    uStack_44 = uVar9;
    iVar11 = func_0x0001800ac7f0(arg1 + 0x168, &var_58h);
    if (((iVar11 == 0) || ((int64_t *)(iVar11 + 8) == (int64_t *)0x0)) ||
       (puVar4 = *(undefined8 **)(int64_t *)(iVar11 + 8), puVar4 == (undefined8 *)0x0)) {
        ppiVar2 = *(int64_t ***)(arg1 + 0xd8);
        iVar11 = (int64_t)*ppiVar2;
        if (iVar11 == 0) {
code_r0x0001800ea99a:
            piVar10 = (int64_t *)func_0x000180459890(0x2008);
            *piVar10 = (int64_t)*ppiVar2;
            piVar13 = piVar10 + 1;
            *ppiVar2 = piVar10;
            piVar10 = (int64_t *)0x28;
        } else {
            piVar13 = (int64_t *)((int64_t)ppiVar2[1] + iVar11 + 0xf & 0xfffffffffffffff8);
            if ((int64_t *)(iVar11 + 0x2008U) < piVar13 + 5) goto code_r0x0001800ea99a;
            piVar10 = (int64_t *)((int64_t)piVar13 + (0x28 - (iVar11 + 8)));
        }
        ppiVar2[1] = piVar10;
        uVar12 = *(undefined4 *)0x180782738;
        iVar11 = 0x180641e38;
        piVar13[4] = iVar1;
        goto code_r0x0001800ea9cb;
    }
    uVar5 = puVar4[4];
    if (uVar5 < *(uint64_t *)(arg1 + 0x160)) {
        var_58h = 0;
        var_50h = 0;
        piVar13 = (int64_t *)func_0x0001800f0080(arg1, arg1 + 0x84, &var_58h, 0x180643a58, *puVar4);
        return piVar13;
    }
    iVar1 = *(int64_t *)(arg1 + 0x150);
    iVar3 = *(int64_t *)(arg1 + 0x148);
    ppiVar2 = *(int64_t ***)(arg1 + 0xd8);
    iVar11 = (int64_t)*ppiVar2;
    if (iVar11 == 0) {
code_r0x0001800ea91d:
        piVar10 = (int64_t *)func_0x000180459890(0x2008);
        *piVar10 = (int64_t)*ppiVar2;
        piVar13 = piVar10 + 1;
        *ppiVar2 = piVar10;
        piVar10 = (int64_t *)0x30;
    } else {
        piVar13 = (int64_t *)((int64_t)ppiVar2[1] + iVar11 + 0xf & 0xfffffffffffffff8);
        if ((int64_t *)(iVar11 + 0x2008U) < piVar13 + 6) goto code_r0x0001800ea91d;
        piVar10 = (int64_t *)((int64_t)piVar13 + (0x30 - (iVar11 + 8)));
    }
    ppiVar2[1] = piVar10;
    uVar12 = *(undefined4 *)0x180782728;
    iVar11 = 0x180641f78;
    piVar13[4] = (int64_t)puVar4;
    *(bool *)(piVar13 + 5) = uVar5 != (iVar1 - iVar3 >> 3) - 1U;
code_r0x0001800ea9cb:
    *piVar13 = iVar11;
    *(undefined4 *)((int64_t)piVar13 + 0xc) = uVar6;
    *(undefined4 *)(piVar13 + 2) = uVar7;
    *(undefined4 *)((int64_t)piVar13 + 0x14) = uVar8;
    *(undefined4 *)(piVar13 + 3) = uVar9;
    *(undefined4 *)(piVar13 + 1) = uVar12;
    return piVar13;
}

// ============================================================
// Function: FUN_1800ea81e
// Address: 0x1800ea81e
// Size: 157 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

int64_t * fcn.1800ea720(int64_t arg1)
{
    int64_t iVar1;
    int64_t **ppiVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    uint64_t uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t *piVar10;
    int64_t iVar11;
    undefined4 uVar12;
    int64_t *piVar13;
    int64_t var_8h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    undefined4 uStack_48;
    undefined4 uStack_44;
    int64_t var_40h;
    int64_t var_38h;
    
    if (*(int32_t *)(arg1 + 0x80) != 0x119) {
        func_0x0001800efe90();
        iVar1 = *(int64_t *)(arg1 + 0x1d8);
        iVar11 = *(int64_t *)(arg1 + 0x1d0);
        ppiVar2 = *(int64_t ***)(arg1 + 0xd8);
        func_0x0001800f1110(arg1, &var_58h, 0, 0);
        iVar3 = (int64_t)*ppiVar2;
        if (iVar3 != 0) {
            piVar13 = (int64_t *)((int64_t)ppiVar2[1] + iVar3 + 0xf & 0xfffffffffffffff8);
            if (piVar13 + 7 <= (int64_t *)(iVar3 + 0x2008)) {
                piVar10 = (int64_t *)((int64_t)piVar13 + (0x38 - (iVar3 + 8)));
                goto code_r0x0001800ea7d3;
            }
        }
        piVar10 = (int64_t *)func_0x000180459890(0x2008);
        *piVar10 = (int64_t)*ppiVar2;
        piVar13 = piVar10 + 1;
        *ppiVar2 = piVar10;
        piVar10 = (int64_t *)0x38;
code_r0x0001800ea7d3:
        ppiVar2[1] = piVar10;
        uVar6 = *(undefined4 *)0x1807826f0;
        *piVar13 = 0x180642298;
        *(undefined4 *)(piVar13 + 1) = uVar6;
        uVar6 = *(undefined4 *)(arg1 + 0x84);
        uVar7 = *(undefined4 *)(arg1 + 0x88);
        uVar8 = *(undefined4 *)(arg1 + 0x8c);
        uVar9 = *(undefined4 *)(arg1 + 0x90);
        *piVar13 = 0x180641ae0;
        *(int32_t *)(piVar13 + 6) = (int32_t)(iVar1 - iVar11 >> 3) * 0x38e38e39 + -1;
        *(undefined4 *)((int64_t)piVar13 + 0xc) = uVar6;
        *(undefined4 *)(piVar13 + 2) = uVar7;
        *(undefined4 *)((int64_t)piVar13 + 0x14) = uVar8;
        *(undefined4 *)(piVar13 + 3) = uVar9;
        *(undefined4 *)(piVar13 + 4) = (undefined4)var_58h;
        *(undefined4 *)((int64_t)piVar13 + 0x24) = var_58h._4_4_;
        *(undefined4 *)(piVar13 + 5) = (undefined4)var_50h;
        *(undefined4 *)((int64_t)piVar13 + 0x2c) = var_50h._4_4_;
        return piVar13;
    }
    iVar1 = *(int64_t *)(arg1 + 0x98);
    uVar6 = *(undefined4 *)(int64_t *)(arg1 + 0x84);
    uVar7 = *(undefined4 *)(arg1 + 0x88);
    iVar11 = *(int64_t *)(arg1 + 0x84);
    uVar8 = *(undefined4 *)(arg1 + 0x8c);
    uVar9 = *(undefined4 *)(arg1 + 0x90);
    fcn.1800f0350();
    var_40h._0_1_ = 1;
    var_58h = iVar1;
    var_50h = iVar11;
    uStack_48 = uVar8;
    uStack_44 = uVar9;
    iVar11 = func_0x0001800ac7f0(arg1 + 0x168, &var_58h);
    if (((iVar11 == 0) || ((int64_t *)(iVar11 + 8) == (int64_t *)0x0)) ||
       (puVar4 = *(undefined8 **)(int64_t *)(iVar11 + 8), puVar4 == (undefined8 *)0x0)) {
        ppiVar2 = *(int64_t ***)(arg1 + 0xd8);
        iVar11 = (int64_t)*ppiVar2;
        if (iVar11 == 0) {
code_r0x0001800ea99a:
            piVar10 = (int64_t *)func_0x000180459890(0x2008);
            *piVar10 = (int64_t)*ppiVar2;
            piVar13 = piVar10 + 1;
            *ppiVar2 = piVar10;
            piVar10 = (int64_t *)0x28;
        } else {
            piVar13 = (int64_t *)((int64_t)ppiVar2[1] + iVar11 + 0xf & 0xfffffffffffffff8);
            if ((int64_t *)(iVar11 + 0x2008U) < piVar13 + 5) goto code_r0x0001800ea99a;
            piVar10 = (int64_t *)((int64_t)piVar13 + (0x28 - (iVar11 + 8)));
        }
        ppiVar2[1] = piVar10;
        uVar12 = *(undefined4 *)0x180782738;
        iVar11 = 0x180641e38;
        piVar13[4] = iVar1;
        goto code_r0x0001800ea9cb;
    }
    uVar5 = puVar4[4];
    if (uVar5 < *(uint64_t *)(arg1 + 0x160)) {
        var_58h = 0;
        var_50h = 0;
        piVar13 = (int64_t *)func_0x0001800f0080(arg1, arg1 + 0x84, &var_58h, 0x180643a58, *puVar4);
        return piVar13;
    }
    iVar1 = *(int64_t *)(arg1 + 0x150);
    iVar3 = *(int64_t *)(arg1 + 0x148);
    ppiVar2 = *(int64_t ***)(arg1 + 0xd8);
    iVar11 = (int64_t)*ppiVar2;
    if (iVar11 == 0) {
code_r0x0001800ea91d:
        piVar10 = (int64_t *)func_0x000180459890(0x2008);
        *piVar10 = (int64_t)*ppiVar2;
        piVar13 = piVar10 + 1;
        *ppiVar2 = piVar10;
        piVar10 = (int64_t *)0x30;
    } else {
        piVar13 = (int64_t *)((int64_t)ppiVar2[1] + iVar11 + 0xf & 0xfffffffffffffff8);
        if ((int64_t *)(iVar11 + 0x2008U) < piVar13 + 6) goto code_r0x0001800ea91d;
        piVar10 = (int64_t *)((int64_t)piVar13 + (0x30 - (iVar11 + 8)));
    }
    ppiVar2[1] = piVar10;
    uVar12 = *(undefined4 *)0x180782728;
    iVar11 = 0x180641f78;
    piVar13[4] = (int64_t)puVar4;
    *(bool *)(piVar13 + 5) = uVar5 != (iVar1 - iVar3 >> 3) - 1U;
code_r0x0001800ea9cb:
    *piVar13 = iVar11;
    *(undefined4 *)((int64_t)piVar13 + 0xc) = uVar6;
    *(undefined4 *)(piVar13 + 2) = uVar7;
    *(undefined4 *)((int64_t)piVar13 + 0x14) = uVar8;
    *(undefined4 *)(piVar13 + 3) = uVar9;
    *(undefined4 *)(piVar13 + 1) = uVar12;
    return piVar13;
}

// ============================================================
// Function: FUN_1800ea8bb
// Address: 0x1800ea8bb
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

int64_t * fcn.1800ea720(int64_t arg1)
{
    int64_t iVar1;
    int64_t **ppiVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    uint64_t uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t *piVar10;
    int64_t iVar11;
    undefined4 uVar12;
    int64_t *piVar13;
    int64_t var_8h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    undefined4 uStack_48;
    undefined4 uStack_44;
    int64_t var_40h;
    int64_t var_38h;
    
    if (*(int32_t *)(arg1 + 0x80) != 0x119) {
        func_0x0001800efe90();
        iVar1 = *(int64_t *)(arg1 + 0x1d8);
        iVar11 = *(int64_t *)(arg1 + 0x1d0);
        ppiVar2 = *(int64_t ***)(arg1 + 0xd8);
        func_0x0001800f1110(arg1, &var_58h, 0, 0);
        iVar3 = (int64_t)*ppiVar2;
        if (iVar3 != 0) {
            piVar13 = (int64_t *)((int64_t)ppiVar2[1] + iVar3 + 0xf & 0xfffffffffffffff8);
            if (piVar13 + 7 <= (int64_t *)(iVar3 + 0x2008)) {
                piVar10 = (int64_t *)((int64_t)piVar13 + (0x38 - (iVar3 + 8)));
                goto code_r0x0001800ea7d3;
            }
        }
        piVar10 = (int64_t *)func_0x000180459890(0x2008);
        *piVar10 = (int64_t)*ppiVar2;
        piVar13 = piVar10 + 1;
        *ppiVar2 = piVar10;
        piVar10 = (int64_t *)0x38;
code_r0x0001800ea7d3:
        ppiVar2[1] = piVar10;
        uVar6 = *(undefined4 *)0x1807826f0;
        *piVar13 = 0x180642298;
        *(undefined4 *)(piVar13 + 1) = uVar6;
        uVar6 = *(undefined4 *)(arg1 + 0x84);
        uVar7 = *(undefined4 *)(arg1 + 0x88);
        uVar8 = *(undefined4 *)(arg1 + 0x8c);
        uVar9 = *(undefined4 *)(arg1 + 0x90);
        *piVar13 = 0x180641ae0;
        *(int32_t *)(piVar13 + 6) = (int32_t)(iVar1 - iVar11 >> 3) * 0x38e38e39 + -1;
        *(undefined4 *)((int64_t)piVar13 + 0xc) = uVar6;
        *(undefined4 *)(piVar13 + 2) = uVar7;
        *(undefined4 *)((int64_t)piVar13 + 0x14) = uVar8;
        *(undefined4 *)(piVar13 + 3) = uVar9;
        *(undefined4 *)(piVar13 + 4) = (undefined4)var_58h;
        *(undefined4 *)((int64_t)piVar13 + 0x24) = var_58h._4_4_;
        *(undefined4 *)(piVar13 + 5) = (undefined4)var_50h;
        *(undefined4 *)((int64_t)piVar13 + 0x2c) = var_50h._4_4_;
        return piVar13;
    }
    iVar1 = *(int64_t *)(arg1 + 0x98);
    uVar6 = *(undefined4 *)(int64_t *)(arg1 + 0x84);
    uVar7 = *(undefined4 *)(arg1 + 0x88);
    iVar11 = *(int64_t *)(arg1 + 0x84);
    uVar8 = *(undefined4 *)(arg1 + 0x8c);
    uVar9 = *(undefined4 *)(arg1 + 0x90);
    fcn.1800f0350();
    var_40h._0_1_ = 1;
    var_58h = iVar1;
    var_50h = iVar11;
    uStack_48 = uVar8;
    uStack_44 = uVar9;
    iVar11 = func_0x0001800ac7f0(arg1 + 0x168, &var_58h);
    if (((iVar11 == 0) || ((int64_t *)(iVar11 + 8) == (int64_t *)0x0)) ||
       (puVar4 = *(undefined8 **)(int64_t *)(iVar11 + 8), puVar4 == (undefined8 *)0x0)) {
        ppiVar2 = *(int64_t ***)(arg1 + 0xd8);
        iVar11 = (int64_t)*ppiVar2;
        if (iVar11 == 0) {
code_r0x0001800ea99a:
            piVar10 = (int64_t *)func_0x000180459890(0x2008);
            *piVar10 = (int64_t)*ppiVar2;
            piVar13 = piVar10 + 1;
            *ppiVar2 = piVar10;
            piVar10 = (int64_t *)0x28;
        } else {
            piVar13 = (int64_t *)((int64_t)ppiVar2[1] + iVar11 + 0xf & 0xfffffffffffffff8);
            if ((int64_t *)(iVar11 + 0x2008U) < piVar13 + 5) goto code_r0x0001800ea99a;
            piVar10 = (int64_t *)((int64_t)piVar13 + (0x28 - (iVar11 + 8)));
        }
        ppiVar2[1] = piVar10;
        uVar12 = *(undefined4 *)0x180782738;
        iVar11 = 0x180641e38;
        piVar13[4] = iVar1;
        goto code_r0x0001800ea9cb;
    }
    uVar5 = puVar4[4];
    if (uVar5 < *(uint64_t *)(arg1 + 0x160)) {
        var_58h = 0;
        var_50h = 0;
        piVar13 = (int64_t *)func_0x0001800f0080(arg1, arg1 + 0x84, &var_58h, 0x180643a58, *puVar4);
        return piVar13;
    }
    iVar1 = *(int64_t *)(arg1 + 0x150);
    iVar3 = *(int64_t *)(arg1 + 0x148);
    ppiVar2 = *(int64_t ***)(arg1 + 0xd8);
    iVar11 = (int64_t)*ppiVar2;
    if (iVar11 == 0) {
code_r0x0001800ea91d:
        piVar10 = (int64_t *)func_0x000180459890(0x2008);
        *piVar10 = (int64_t)*ppiVar2;
        piVar13 = piVar10 + 1;
        *ppiVar2 = piVar10;
        piVar10 = (int64_t *)0x30;
    } else {
        piVar13 = (int64_t *)((int64_t)ppiVar2[1] + iVar11 + 0xf & 0xfffffffffffffff8);
        if ((int64_t *)(iVar11 + 0x2008U) < piVar13 + 6) goto code_r0x0001800ea91d;
        piVar10 = (int64_t *)((int64_t)piVar13 + (0x30 - (iVar11 + 8)));
    }
    ppiVar2[1] = piVar10;
    uVar12 = *(undefined4 *)0x180782728;
    iVar11 = 0x180641f78;
    piVar13[4] = (int64_t)puVar4;
    *(bool *)(piVar13 + 5) = uVar5 != (iVar1 - iVar3 >> 3) - 1U;
code_r0x0001800ea9cb:
    *piVar13 = iVar11;
    *(undefined4 *)((int64_t)piVar13 + 0xc) = uVar6;
    *(undefined4 *)(piVar13 + 2) = uVar7;
    *(undefined4 *)((int64_t)piVar13 + 0x14) = uVar8;
    *(undefined4 *)(piVar13 + 3) = uVar9;
    *(undefined4 *)(piVar13 + 1) = uVar12;
    return piVar13;
}

// ============================================================
// Function: FUN_1800ea8d0
// Address: 0x1800ea8d0
// Size: 140 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

int64_t * fcn.1800ea720(int64_t arg1)
{
    int64_t iVar1;
    int64_t **ppiVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    uint64_t uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t *piVar10;
    int64_t iVar11;
    undefined4 uVar12;
    int64_t *piVar13;
    int64_t var_8h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    undefined4 uStack_48;
    undefined4 uStack_44;
    int64_t var_40h;
    int64_t var_38h;
    
    if (*(int32_t *)(arg1 + 0x80) != 0x119) {
        func_0x0001800efe90();
        iVar1 = *(int64_t *)(arg1 + 0x1d8);
        iVar11 = *(int64_t *)(arg1 + 0x1d0);
        ppiVar2 = *(int64_t ***)(arg1 + 0xd8);
        func_0x0001800f1110(arg1, &var_58h, 0, 0);
        iVar3 = (int64_t)*ppiVar2;
        if (iVar3 != 0) {
            piVar13 = (int64_t *)((int64_t)ppiVar2[1] + iVar3 + 0xf & 0xfffffffffffffff8);
            if (piVar13 + 7 <= (int64_t *)(iVar3 + 0x2008)) {
                piVar10 = (int64_t *)((int64_t)piVar13 + (0x38 - (iVar3 + 8)));
                goto code_r0x0001800ea7d3;
            }
        }
        piVar10 = (int64_t *)func_0x000180459890(0x2008);
        *piVar10 = (int64_t)*ppiVar2;
        piVar13 = piVar10 + 1;
        *ppiVar2 = piVar10;
        piVar10 = (int64_t *)0x38;
code_r0x0001800ea7d3:
        ppiVar2[1] = piVar10;
        uVar6 = *(undefined4 *)0x1807826f0;
        *piVar13 = 0x180642298;
        *(undefined4 *)(piVar13 + 1) = uVar6;
        uVar6 = *(undefined4 *)(arg1 + 0x84);
        uVar7 = *(undefined4 *)(arg1 + 0x88);
        uVar8 = *(undefined4 *)(arg1 + 0x8c);
        uVar9 = *(undefined4 *)(arg1 + 0x90);
        *piVar13 = 0x180641ae0;
        *(int32_t *)(piVar13 + 6) = (int32_t)(iVar1 - iVar11 >> 3) * 0x38e38e39 + -1;
        *(undefined4 *)((int64_t)piVar13 + 0xc) = uVar6;
        *(undefined4 *)(piVar13 + 2) = uVar7;
        *(undefined4 *)((int64_t)piVar13 + 0x14) = uVar8;
        *(undefined4 *)(piVar13 + 3) = uVar9;
        *(undefined4 *)(piVar13 + 4) = (undefined4)var_58h;
        *(undefined4 *)((int64_t)piVar13 + 0x24) = var_58h._4_4_;
        *(undefined4 *)(piVar13 + 5) = (undefined4)var_50h;
        *(undefined4 *)((int64_t)piVar13 + 0x2c) = var_50h._4_4_;
        return piVar13;
    }
    iVar1 = *(int64_t *)(arg1 + 0x98);
    uVar6 = *(undefined4 *)(int64_t *)(arg1 + 0x84);
    uVar7 = *(undefined4 *)(arg1 + 0x88);
    iVar11 = *(int64_t *)(arg1 + 0x84);
    uVar8 = *(undefined4 *)(arg1 + 0x8c);
    uVar9 = *(undefined4 *)(arg1 + 0x90);
    fcn.1800f0350();
    var_40h._0_1_ = 1;
    var_58h = iVar1;
    var_50h = iVar11;
    uStack_48 = uVar8;
    uStack_44 = uVar9;
    iVar11 = func_0x0001800ac7f0(arg1 + 0x168, &var_58h);
    if (((iVar11 == 0) || ((int64_t *)(iVar11 + 8) == (int64_t *)0x0)) ||
       (puVar4 = *(undefined8 **)(int64_t *)(iVar11 + 8), puVar4 == (undefined8 *)0x0)) {
        ppiVar2 = *(int64_t ***)(arg1 + 0xd8);
        iVar11 = (int64_t)*ppiVar2;
        if (iVar11 == 0) {
code_r0x0001800ea99a:
            piVar10 = (int64_t *)func_0x000180459890(0x2008);
            *piVar10 = (int64_t)*ppiVar2;
            piVar13 = piVar10 + 1;
            *ppiVar2 = piVar10;
            piVar10 = (int64_t *)0x28;
        } else {
            piVar13 = (int64_t *)((int64_t)ppiVar2[1] + iVar11 + 0xf & 0xfffffffffffffff8);
            if ((int64_t *)(iVar11 + 0x2008U) < piVar13 + 5) goto code_r0x0001800ea99a;
            piVar10 = (int64_t *)((int64_t)piVar13 + (0x28 - (iVar11 + 8)));
        }
        ppiVar2[1] = piVar10;
        uVar12 = *(undefined4 *)0x180782738;
        iVar11 = 0x180641e38;
        piVar13[4] = iVar1;
        goto code_r0x0001800ea9cb;
    }
    uVar5 = puVar4[4];
    if (uVar5 < *(uint64_t *)(arg1 + 0x160)) {
        var_58h = 0;
        var_50h = 0;
        piVar13 = (int64_t *)func_0x0001800f0080(arg1, arg1 + 0x84, &var_58h, 0x180643a58, *puVar4);
        return piVar13;
    }
    iVar1 = *(int64_t *)(arg1 + 0x150);
    iVar3 = *(int64_t *)(arg1 + 0x148);
    ppiVar2 = *(int64_t ***)(arg1 + 0xd8);
    iVar11 = (int64_t)*ppiVar2;
    if (iVar11 == 0) {
code_r0x0001800ea91d:
        piVar10 = (int64_t *)func_0x000180459890(0x2008);
        *piVar10 = (int64_t)*ppiVar2;
        piVar13 = piVar10 + 1;
        *ppiVar2 = piVar10;
        piVar10 = (int64_t *)0x30;
    } else {
        piVar13 = (int64_t *)((int64_t)ppiVar2[1] + iVar11 + 0xf & 0xfffffffffffffff8);
        if ((int64_t *)(iVar11 + 0x2008U) < piVar13 + 6) goto code_r0x0001800ea91d;
        piVar10 = (int64_t *)((int64_t)piVar13 + (0x30 - (iVar11 + 8)));
    }
    ppiVar2[1] = piVar10;
    uVar12 = *(undefined4 *)0x180782728;
    iVar11 = 0x180641f78;
    piVar13[4] = (int64_t)puVar4;
    *(bool *)(piVar13 + 5) = uVar5 != (iVar1 - iVar3 >> 3) - 1U;
code_r0x0001800ea9cb:
    *piVar13 = iVar11;
    *(undefined4 *)((int64_t)piVar13 + 0xc) = uVar6;
    *(undefined4 *)(piVar13 + 2) = uVar7;
    *(undefined4 *)((int64_t)piVar13 + 0x14) = uVar8;
    *(undefined4 *)(piVar13 + 3) = uVar9;
    *(undefined4 *)(piVar13 + 1) = uVar12;
    return piVar13;
}

// ============================================================
// Function: FUN_1800ea95c
// Address: 0x1800ea95c
// Size: 138 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

int64_t * fcn.1800ea720(int64_t arg1)
{
    int64_t iVar1;
    int64_t **ppiVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    uint64_t uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t *piVar10;
    int64_t iVar11;
    undefined4 uVar12;
    int64_t *piVar13;
    int64_t var_8h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    undefined4 uStack_48;
    undefined4 uStack_44;
    int64_t var_40h;
    int64_t var_38h;
    
    if (*(int32_t *)(arg1 + 0x80) != 0x119) {
        func_0x0001800efe90();
        iVar1 = *(int64_t *)(arg1 + 0x1d8);
        iVar11 = *(int64_t *)(arg1 + 0x1d0);
        ppiVar2 = *(int64_t ***)(arg1 + 0xd8);
        func_0x0001800f1110(arg1, &var_58h, 0, 0);
        iVar3 = (int64_t)*ppiVar2;
        if (iVar3 != 0) {
            piVar13 = (int64_t *)((int64_t)ppiVar2[1] + iVar3 + 0xf & 0xfffffffffffffff8);
            if (piVar13 + 7 <= (int64_t *)(iVar3 + 0x2008)) {
                piVar10 = (int64_t *)((int64_t)piVar13 + (0x38 - (iVar3 + 8)));
                goto code_r0x0001800ea7d3;
            }
        }
        piVar10 = (int64_t *)func_0x000180459890(0x2008);
        *piVar10 = (int64_t)*ppiVar2;
        piVar13 = piVar10 + 1;
        *ppiVar2 = piVar10;
        piVar10 = (int64_t *)0x38;
code_r0x0001800ea7d3:
        ppiVar2[1] = piVar10;
        uVar6 = *(undefined4 *)0x1807826f0;
        *piVar13 = 0x180642298;
        *(undefined4 *)(piVar13 + 1) = uVar6;
        uVar6 = *(undefined4 *)(arg1 + 0x84);
        uVar7 = *(undefined4 *)(arg1 + 0x88);
        uVar8 = *(undefined4 *)(arg1 + 0x8c);
        uVar9 = *(undefined4 *)(arg1 + 0x90);
        *piVar13 = 0x180641ae0;
        *(int32_t *)(piVar13 + 6) = (int32_t)(iVar1 - iVar11 >> 3) * 0x38e38e39 + -1;
        *(undefined4 *)((int64_t)piVar13 + 0xc) = uVar6;
        *(undefined4 *)(piVar13 + 2) = uVar7;
        *(undefined4 *)((int64_t)piVar13 + 0x14) = uVar8;
        *(undefined4 *)(piVar13 + 3) = uVar9;
        *(undefined4 *)(piVar13 + 4) = (undefined4)var_58h;
        *(undefined4 *)((int64_t)piVar13 + 0x24) = var_58h._4_4_;
        *(undefined4 *)(piVar13 + 5) = (undefined4)var_50h;
        *(undefined4 *)((int64_t)piVar13 + 0x2c) = var_50h._4_4_;
        return piVar13;
    }
    iVar1 = *(int64_t *)(arg1 + 0x98);
    uVar6 = *(undefined4 *)(int64_t *)(arg1 + 0x84);
    uVar7 = *(undefined4 *)(arg1 + 0x88);
    iVar11 = *(int64_t *)(arg1 + 0x84);
    uVar8 = *(undefined4 *)(arg1 + 0x8c);
    uVar9 = *(undefined4 *)(arg1 + 0x90);
    fcn.1800f0350();
    var_40h._0_1_ = 1;
    var_58h = iVar1;
    var_50h = iVar11;
    uStack_48 = uVar8;
    uStack_44 = uVar9;
    iVar11 = func_0x0001800ac7f0(arg1 + 0x168, &var_58h);
    if (((iVar11 == 0) || ((int64_t *)(iVar11 + 8) == (int64_t *)0x0)) ||
       (puVar4 = *(undefined8 **)(int64_t *)(iVar11 + 8), puVar4 == (undefined8 *)0x0)) {
        ppiVar2 = *(int64_t ***)(arg1 + 0xd8);
        iVar11 = (int64_t)*ppiVar2;
        if (iVar11 == 0) {
code_r0x0001800ea99a:
            piVar10 = (int64_t *)func_0x000180459890(0x2008);
            *piVar10 = (int64_t)*ppiVar2;
            piVar13 = piVar10 + 1;
            *ppiVar2 = piVar10;
            piVar10 = (int64_t *)0x28;
        } else {
            piVar13 = (int64_t *)((int64_t)ppiVar2[1] + iVar11 + 0xf & 0xfffffffffffffff8);
            if ((int64_t *)(iVar11 + 0x2008U) < piVar13 + 5) goto code_r0x0001800ea99a;
            piVar10 = (int64_t *)((int64_t)piVar13 + (0x28 - (iVar11 + 8)));
        }
        ppiVar2[1] = piVar10;
        uVar12 = *(undefined4 *)0x180782738;
        iVar11 = 0x180641e38;
        piVar13[4] = iVar1;
        goto code_r0x0001800ea9cb;
    }
    uVar5 = puVar4[4];
    if (uVar5 < *(uint64_t *)(arg1 + 0x160)) {
        var_58h = 0;
        var_50h = 0;
        piVar13 = (int64_t *)func_0x0001800f0080(arg1, arg1 + 0x84, &var_58h, 0x180643a58, *puVar4);
        return piVar13;
    }
    iVar1 = *(int64_t *)(arg1 + 0x150);
    iVar3 = *(int64_t *)(arg1 + 0x148);
    ppiVar2 = *(int64_t ***)(arg1 + 0xd8);
    iVar11 = (int64_t)*ppiVar2;
    if (iVar11 == 0) {
code_r0x0001800ea91d:
        piVar10 = (int64_t *)func_0x000180459890(0x2008);
        *piVar10 = (int64_t)*ppiVar2;
        piVar13 = piVar10 + 1;
        *ppiVar2 = piVar10;
        piVar10 = (int64_t *)0x30;
    } else {
        piVar13 = (int64_t *)((int64_t)ppiVar2[1] + iVar11 + 0xf & 0xfffffffffffffff8);
        if ((int64_t *)(iVar11 + 0x2008U) < piVar13 + 6) goto code_r0x0001800ea91d;
        piVar10 = (int64_t *)((int64_t)piVar13 + (0x30 - (iVar11 + 8)));
    }
    ppiVar2[1] = piVar10;
    uVar12 = *(undefined4 *)0x180782728;
    iVar11 = 0x180641f78;
    piVar13[4] = (int64_t)puVar4;
    *(bool *)(piVar13 + 5) = uVar5 != (iVar1 - iVar3 >> 3) - 1U;
code_r0x0001800ea9cb:
    *piVar13 = iVar11;
    *(undefined4 *)((int64_t)piVar13 + 0xc) = uVar6;
    *(undefined4 *)(piVar13 + 2) = uVar7;
    *(undefined4 *)((int64_t)piVar13 + 0x14) = uVar8;
    *(undefined4 *)(piVar13 + 3) = uVar9;
    *(undefined4 *)(piVar13 + 1) = uVar12;
    return piVar13;
}

// ============================================================
// Function: FUN_1800ea9f0
// Address: 0x1800ea9f0
// Size: 2302 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f0h

int64_t * fcn.1800ea9f0(int64_t arg1)
{
    int32_t **ppiVar1;
    int64_t iVar2;
    code *pcVar3;
    bool bVar4;
    uint32_t uVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    int64_t **ppiVar9;
    int32_t *piVar10;
    int64_t iVar11;
    uint64_t uVar12;
    int32_t *piVar13;
    char in_DL;
    uint64_t uVar14;
    int32_t iVar15;
    int64_t iVar16;
    undefined8 uVar17;
    uint64_t uVar18;
    int64_t *piVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t in_stack_000000a0;
    int64_t var_108h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    undefined8 uStack_d0;
    int64_t var_c0h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_58h;
    
    iVar11 = *(int64_t *)(arg1 + 0x84);
    var_10h._0_1_ = in_DL;
    if (*(int32_t *)(arg1 + 0x80) != 0x28) {
        piVar19 = (int64_t *)fcn.1800ea720(arg1);
        goto code_r0x0001800eabe9;
    }
    var_c0h._0_4_ = *(int32_t *)(arg1 + 0x80);
    unique0x10000e41 = iVar11;
    fcn.1800f0350();
    iVar6 = fcn.1800e9350(arg1, 0, in_stack_000000a0);
    if (*(int32_t *)(arg1 + 0x80) == 0x29) {
        iVar16 = *(int64_t *)(arg1 + 0x8c);
        bVar4 = true;
        fcn.1800f0350(arg1);
    } else {
        bVar4 = false;
        uVar17 = 0;
        if (*(int32_t *)(arg1 + 0x80) == 0x3d) {
            uVar17 = 0x180643a88;
        }
        func_0x0001800ef5a0(arg1, 0x29, &var_c0h, uVar17);
        iVar16 = *(int64_t *)(arg1 + 0xa8);
    }
    ppiVar9 = *(int64_t ***)(arg1 + 0xd8);
    iVar2 = (int64_t)*ppiVar9;
    var_b0h = iVar11;
    var_a8h = iVar16;
    if (iVar2 == 0) {
code_r0x0001800eaadb:
        piVar19 = (int64_t *)func_0x000180459890(0x2008);
        *piVar19 = (int64_t)*ppiVar9;
        *ppiVar9 = piVar19;
        piVar19 = piVar19 + 1;
        piVar7 = (int64_t *)0x28;
    } else {
        piVar19 = (int64_t *)((int64_t)ppiVar9[1] + iVar2 + 0xf & 0xfffffffffffffff8);
        if ((int64_t *)(iVar2 + 0x2008) < piVar19 + 5) goto code_r0x0001800eaadb;
        piVar7 = (int64_t *)((int64_t)piVar19 + (0x28 - (iVar2 + 8)));
    }
    ppiVar9[1] = piVar7;
    *(undefined4 *)(piVar19 + 1) = *(undefined4 *)0x1807826c0;
    *(undefined4 *)((int64_t)piVar19 + 0xc) = (undefined4)var_b0h;
    *(undefined4 *)(piVar19 + 2) = var_b0h._4_4_;
    *(undefined4 *)((int64_t)piVar19 + 0x14) = (undefined4)var_a8h;
    *(undefined4 *)(piVar19 + 3) = var_a8h._4_4_;
    *piVar19 = 0x180641c08;
    piVar19[4] = iVar6;
    in_DL = (char)var_10h;
    if ((*(char *)0x1807784a0 == '\0') || (*(char *)(arg1 + 0x58) == '\0')) goto code_r0x0001800eabe9;
    ppiVar9 = *(int64_t ***)(arg1 + 0xd8);
    if (bVar4) {
        uVar17 = *(undefined8 *)(arg1 + 0xa0);
    } else {
        var_8h = -1;
        uVar17 = 0xffffffffffffffff;
    }
    iVar6 = (int64_t)*ppiVar9;
    if (iVar6 == 0) {
code_r0x0001800eab8e:
        piVar7 = (int64_t *)func_0x000180459890(0x2008);
        *piVar7 = (int64_t)*ppiVar9;
        *ppiVar9 = piVar7;
        piVar7 = piVar7 + 1;
        piVar8 = (int64_t *)0xc;
    } else {
        piVar7 = (int64_t *)((int64_t)ppiVar9[1] + iVar6 + 0xf & 0xfffffffffffffff8);
        if (iVar6 + 0x2008U < (int64_t)piVar7 + 0xcU) goto code_r0x0001800eab8e;
        piVar8 = (int64_t *)((int64_t)piVar7 + (0xc - (iVar6 + 8)));
    }
    ppiVar9[1] = piVar8;
    *(undefined4 *)piVar7 = *(undefined4 *)0x180782a88;
    *(undefined8 *)((int64_t)piVar7 + 4) = uVar17;
    var_8h = (int64_t)piVar19;
    ppiVar9 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_8h);
    *ppiVar9 = piVar7;
    in_DL = (char)var_10h;
code_r0x0001800eabe9:
    var_18h._0_4_ = *(undefined4 *)(arg1 + 0x114);
    do {
        iVar15 = *(int32_t *)(arg1 + 0x80);
        if (iVar15 == 0x2e) {
            iVar6 = *(int64_t *)(arg1 + 0x84);
            fcn.1800f0350(arg1);
            if ((*(int32_t *)(arg1 + 0x80) == 0x119) ||
               ((func_0x0001800efe90(arg1, 0), *(int32_t *)(arg1 + 0x80) - 0x123U < 0x15 &&
                (*(int32_t *)(arg1 + 0x84) == (int32_t)iVar6)))) {
                iVar2 = *(int64_t *)(arg1 + 0x8c);
                var_d8h._0_4_ = (undefined4)*(undefined8 *)(arg1 + 0x84);
                var_d8h._4_4_ = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x84) >> 0x20);
                var_e0h._0_4_ = (undefined4)*(undefined8 *)(arg1 + 0x98);
                var_e0h._4_4_ = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x98) >> 0x20);
                uStack_d0 = iVar2;
                fcn.1800f0350(arg1);
                var_f8h = CONCAT44(var_e0h._4_4_, (undefined4)var_e0h);
                var_f0h = CONCAT44(var_d8h._4_4_, (undefined4)var_d8h);
                iVar16 = var_f8h;
                var_e8h = iVar2;
            } else {
                piVar7 = (int64_t *)(arg1 + 0x84);
                var_e0h._0_4_ = *(undefined4 *)piVar7;
                var_e0h._4_4_ = *(undefined4 *)(arg1 + 0x88);
                var_e8h = *piVar7;
                var_f0h = *piVar7;
                iVar16 = *(int64_t *)(arg1 + 0x128);
                var_d8h._0_4_ = (undefined4)var_e0h;
                var_d8h._4_4_ = var_e0h._4_4_;
            }
            ppiVar9 = *(int64_t ***)(arg1 + 0xd8);
            var_98h = var_e8h;
            iVar2 = (int64_t)*ppiVar9;
            var_a0h = iVar11;
            if (iVar2 == 0) {
code_r0x0001800ead06:
                piVar7 = (int64_t *)func_0x000180459890(0x2008);
                *piVar7 = (int64_t)*ppiVar9;
                *ppiVar9 = piVar7;
                piVar7 = piVar7 + 1;
                piVar8 = (int64_t *)0x50;
            } else {
                piVar7 = (int64_t *)((int64_t)ppiVar9[1] + iVar2 + 0xf & 0xfffffffffffffff8);
                if ((int64_t *)(iVar2 + 0x2008) < piVar7 + 10) goto code_r0x0001800ead06;
                piVar8 = (int64_t *)((int64_t)piVar7 + (0x50 - (iVar2 + 8)));
            }
            ppiVar9[1] = piVar8;
            *(undefined4 *)(piVar7 + 1) = *(undefined4 *)0x18078269c;
            *(undefined4 *)((int64_t)piVar7 + 0xc) = (undefined4)var_a0h;
            *(undefined4 *)(piVar7 + 2) = var_a0h._4_4_;
            *(undefined4 *)((int64_t)piVar7 + 0x14) = (undefined4)var_98h;
            *(undefined4 *)(piVar7 + 3) = var_98h._4_4_;
            *piVar7 = 0x180641ca8;
            piVar7[4] = (int64_t)piVar19;
            piVar7[5] = iVar16;
            *(undefined4 *)(piVar7 + 6) = (undefined4)var_f0h;
            *(undefined4 *)((int64_t)piVar7 + 0x34) = var_f0h._4_4_;
            *(undefined4 *)(piVar7 + 7) = (undefined4)var_e8h;
            *(undefined4 *)((int64_t)piVar7 + 0x3c) = var_e8h._4_4_;
            piVar7[8] = iVar6;
            *(undefined *)(piVar7 + 9) = 0x2e;
        } else if (iVar15 == 0x5b) {
            piVar7 = (int64_t *)func_0x0001800eb2f0(arg1, iVar11);
        } else if (iVar15 == 0x3a) {
            iVar6 = *(int64_t *)(arg1 + 0x84);
            fcn.1800f0350(arg1);
            if ((*(int32_t *)(arg1 + 0x80) == 0x119) ||
               ((func_0x0001800efe90(arg1, 0x180642aa0), *(int32_t *)(arg1 + 0x80) - 0x123U < 0x15 &&
                (*(int32_t *)(arg1 + 0x84) == (int32_t)iVar6)))) {
                iVar2 = *(int64_t *)(arg1 + 0x8c);
                var_d8h._0_4_ = (undefined4)*(undefined8 *)(arg1 + 0x84);
                var_d8h._4_4_ = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x84) >> 0x20);
                var_e0h._0_4_ = (undefined4)*(undefined8 *)(arg1 + 0x98);
                var_e0h._4_4_ = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x98) >> 0x20);
                uStack_d0 = iVar2;
                fcn.1800f0350(arg1);
                var_f8h = CONCAT44(var_e0h._4_4_, (undefined4)var_e0h);
                var_f0h = CONCAT44(var_d8h._4_4_, (undefined4)var_d8h);
                iVar16 = var_f8h;
                var_e8h = iVar2;
            } else {
                piVar7 = (int64_t *)(arg1 + 0x84);
                var_e0h._0_4_ = *(undefined4 *)piVar7;
                var_e0h._4_4_ = *(undefined4 *)(arg1 + 0x88);
                var_e8h = *piVar7;
                var_f0h = *piVar7;
                iVar16 = *(int64_t *)(arg1 + 0x128);
                var_d8h._0_4_ = (undefined4)var_e0h;
                var_d8h._4_4_ = var_e0h._4_4_;
            }
            ppiVar9 = *(int64_t ***)(arg1 + 0xd8);
            var_88h = var_e8h;
            iVar2 = (int64_t)*ppiVar9;
            var_90h = iVar11;
            if (iVar2 == 0) {
code_r0x0001800eae84:
                piVar7 = (int64_t *)func_0x000180459890(0x2008);
                *piVar7 = (int64_t)*ppiVar9;
                *ppiVar9 = piVar7;
                var_20h = (int64_t)(piVar7 + 1);
                piVar7 = (int64_t *)0x50;
            } else {
                var_20h = (int64_t)ppiVar9[1] + iVar2 + 0xf & 0xfffffffffffffff8;
                if ((int64_t *)(iVar2 + 0x2008) < (int64_t *)(var_20h + 0x50)) goto code_r0x0001800eae84;
                piVar7 = (int64_t *)(var_20h + (0x50 - (iVar2 + 8)));
            }
            ppiVar9[1] = piVar7;
            *(undefined4 *)(var_20h + 8) = *(undefined4 *)0x18078269c;
            *(undefined4 *)(var_20h + 0xc) = (undefined4)var_90h;
            *(undefined4 *)(var_20h + 0x10) = var_90h._4_4_;
            *(undefined4 *)(var_20h + 0x14) = (undefined4)var_88h;
            *(undefined4 *)(var_20h + 0x18) = var_88h._4_4_;
            *(int64_t *)var_20h = 0x180641ca8;
            *(int64_t **)(var_20h + 0x20) = piVar19;
            *(int64_t *)(var_20h + 0x28) = iVar16;
            *(undefined4 *)(var_20h + 0x30) = (undefined4)var_f0h;
            *(undefined4 *)(var_20h + 0x34) = var_f0h._4_4_;
            *(undefined4 *)(var_20h + 0x38) = (undefined4)var_e8h;
            *(undefined4 *)(var_20h + 0x3c) = var_e8h._4_4_;
            *(int64_t *)(var_20h + 0x40) = iVar6;
            *(undefined *)(var_20h + 0x48) = 0x3a;
            iVar6 = 0;
            if (*(char *)(arg1 + 0x58) == '\0') {
                piVar19 = (int64_t *)0x0;
            } else {
                ppiVar9 = *(int64_t ***)(arg1 + 0xd8);
                iVar16 = (int64_t)*ppiVar9;
                if (iVar16 == 0) {
code_r0x0001800eaf2d:
                    piVar19 = (int64_t *)func_0x000180459890(0x2008);
                    *piVar19 = (int64_t)*ppiVar9;
                    *ppiVar9 = piVar19;
                    piVar19 = piVar19 + 1;
                    piVar7 = (int64_t *)0x30;
                } else {
                    piVar19 = (int64_t *)((int64_t)ppiVar9[1] + iVar16 + 0xf & 0xfffffffffffffff8);
                    if ((int64_t *)(iVar16 + 0x2008) < piVar19 + 6) goto code_r0x0001800eaf2d;
                    piVar7 = (int64_t *)((int64_t)piVar19 + (0x30 - (iVar16 + 8)));
                }
                ppiVar9[1] = piVar7;
                *piVar19 = -1;
                piVar19[1] = -1;
                piVar19[2] = 0;
                piVar19[3] = 0;
                piVar19[4] = -1;
                piVar19[5] = -1;
            }
            iVar16 = iVar6;
            if ((*(int32_t *)(arg1 + 0x80) == 0x3c) &&
               (piVar10 = (int32_t *)func_0x0001800d70e0(arg1 + 0x60, &var_80h), *piVar10 == 0x3c)) {
                if (piVar19 != (int64_t *)0x0) {
                    *piVar19 = *(int64_t *)(arg1 + 0x84);
                }
                iVar15 = *(int32_t *)(arg1 + 0x80);
                var_8h = CONCAT44(var_8h._4_4_, iVar15);
                var_e0h._4_4_ = *(undefined4 *)(arg1 + 0x84);
                var_d8h._0_4_ = *(undefined4 *)(arg1 + 0x88);
                var_d8h._4_4_ = *(undefined4 *)(arg1 + 0x8c);
                uStack_d0 = CONCAT44(uStack_d0._4_4_, *(undefined4 *)(arg1 + 0x90));
                func_0x0001800d7020(arg1 + 0x60);
                var_f8h = arg1 + 0x440;
                var_f0h = *(int64_t *)(arg1 + 0x448) - *(int64_t *)var_f8h >> 3;
                var_e8h = 0;
                if (piVar19 == (int64_t *)0x0) {
                    func_0x0001800ed8e0(arg1, &var_b0h, 0, 0, 0);
                    piVar7 = (int64_t *)var_f8h;
                } else {
                    func_0x0001800ed8e0(arg1, &var_b0h, piVar19 + 1, &var_f8h, piVar19 + 4);
                    iVar6 = var_e8h;
                    piVar7 = (int64_t *)var_f8h;
                    if (var_e8h == 0) {
                        uVar12 = 0;
                    } else {
                        iVar16 = *(int64_t *)var_f8h;
                        uVar12 = func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), var_e8h * 8);
                        if (iVar6 != 0) {
                            uVar14 = iVar16 + var_f0h * 8;
                            uVar18 = 0;
                            if (((uint64_t)iVar6 < 2) ||
                               ((uVar12 <= uVar14 + (iVar6 + -1) * 8 && (uVar14 <= uVar12 + (iVar6 + -1) * 8)))) {
                                do {
                                    *(undefined8 *)(uVar12 + uVar18 * 8) = *(undefined8 *)(uVar14 + uVar18 * 8);
                                    uVar18 = uVar18 + 1;
                                } while (uVar18 < (uint64_t)iVar6);
                            } else {
                                func_0x000180498030(uVar12, uVar14, iVar6 * 8);
                            }
                        }
                        iVar15 = (int32_t)var_8h;
                    }
                    piVar19[2] = uVar12;
                    piVar19[3] = iVar6;
                    if (*(int32_t *)(arg1 + 0x80) == 0x3e) {
                        piVar19[5] = *(int64_t *)(arg1 + 0x84);
                    }
                }
                unique0x10000a08 = CONCAT44((undefined4)var_d8h, var_e0h._4_4_);
                var_c0h._0_4_ = iVar15;
                if (*(int32_t *)(arg1 + 0x80) == 0x3e) {
                    fcn.1800f0350(arg1);
                } else {
                    func_0x0001800ef5a0(arg1, 0x3e, &var_c0h);
                    func_0x0001800ef4e0(arg1, 0x3e);
                }
                iVar2 = *piVar7 + var_f0h * 8;
                iVar6 = var_b0h;
                iVar16 = var_a8h;
                if (iVar2 != piVar7[1]) {
                    piVar7[1] = iVar2;
                }
            }
            piVar7 = (int64_t *)func_0x0001800eb750(arg1, var_20h, 1);
            if (((*(char *)(arg1 + 0x58) != '\0') && (*(int64_t *)(arg1 + 0x4a0) != 0)) &&
               (piVar7 != *(int64_t **)(arg1 + 0x4a8))) {
                uVar18 = *(int64_t *)(arg1 + 0x498) - 1;
                uVar12 = ((uint64_t)piVar7 >> 5 ^ (uint64_t)piVar7) >> 4;
                uVar14 = 0;
                do {
                    uVar12 = uVar12 & uVar18;
                    piVar8 = *(int64_t **)(*(int64_t *)(arg1 + 0x490) + uVar12 * 0x10);
                    if (piVar8 == piVar7) {
                        ppiVar1 = (int32_t **)(*(int64_t *)(arg1 + 0x490) + 8 + uVar12 * 0x10);
                        if (ppiVar1 != (int32_t **)0x0) {
                            piVar10 = *ppiVar1;
                            piVar13 = (int32_t *)0x0;
                            if (*piVar10 == *(int32_t *)0x180782ab4) {
                                piVar13 = piVar10;
                            }
                            *(int64_t **)(piVar13 + 10) = piVar19;
                        }
                        break;
                    }
                    if (piVar8 == *(int64_t **)(arg1 + 0x4a8)) break;
                    uVar12 = uVar12 + 1 + uVar14;
                    uVar14 = uVar14 + 1;
                } while (uVar14 <= uVar18);
            }
            piVar19 = (int64_t *)0x0;
            if (*(int32_t *)(piVar7 + 1) == *(int32_t *)0x180782740) {
                piVar19 = piVar7;
            }
            if ((piVar19 != (int64_t *)0x0) && (iVar16 != 0)) {
                piVar19[5] = iVar6;
                piVar19[6] = iVar16;
            }
        } else {
            if (iVar15 == 0x28) {
                if ((in_DL == '\0') && (*(int32_t *)((int64_t)piVar19 + 0x14) != *(int32_t *)(arg1 + 0x84))) {
                    func_0x0001800ebfa0(arg1);
code_r0x0001800eb2a4:
                    *(undefined4 *)(arg1 + 0x114) = (undefined4)var_18h;
                    return piVar19;
                }
            } else if ((iVar15 != 0x7b) && (1 < iVar15 - 0x116U)) {
                if ((iVar15 != 0x3c) ||
                   (piVar10 = (int32_t *)func_0x0001800d70e0(arg1 + 0x60, &var_80h), *piVar10 != 0x3c))
                goto code_r0x0001800eb2a4;
                piVar7 = (int64_t *)func_0x0001800eec20(arg1, iVar11, piVar19);
                goto code_r0x0001800eb244;
            }
            piVar7 = (int64_t *)func_0x0001800eb750(arg1, piVar19, 0);
        }
code_r0x0001800eb244:
        uVar5 = *(int32_t *)(arg1 + 0x114) + 1;
        *(uint32_t *)(arg1 + 0x114) = uVar5;
        piVar19 = piVar7;
        in_DL = (char)var_10h;
        if (*(uint32_t *)0x180778500 < uVar5) {
            iVar11 = func_0x0001800d90d0(arg1 + 0x60);
            func_0x0001800d9940(iVar11 + 4, 0x180644050, 0x180643b50);
            pcVar3 = (code *)swi(3);
            piVar19 = (int64_t *)(*pcVar3)();
            return piVar19;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1800eb2f0
// Address: 0x1800eb2f0
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_84h
// WARNING: [rz-ghidra] Removing arg arg_8ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Removing arg arg_490h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f0h

int64_t * fcn.1800eb2f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h, int64_t arg_80h, int64_t arg_d8h)
{
    int64_t iVar1;
    int64_t iVar2;
    char cVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t **ppiVar7;
    int64_t *piVar8;
    undefined8 uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t in_stack_00000160;
    undefined4 var_48h;
    undefined4 var_44h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    var_48h = (undefined4)*(undefined8 *)(arg1 + 0x80);
    var_44h = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x80) >> 0x20);
    var_40h._0_4_ = *(undefined4 *)(arg1 + 0x88);
    fcn.1800f0350();
    iVar4 = fcn.1800e9350(arg1, 0, in_stack_00000160);
    uVar9 = *(undefined8 *)(arg1 + 0x84);
    iVar1 = *(int64_t *)(arg1 + 0x8c);
    if (*(int32_t *)(arg1 + 0x80) == 0x5d) {
        fcn.1800f0350(arg1);
        cVar3 = '\x01';
    } else {
        func_0x0001800ef5a0(arg1, 0x5d, &var_48h, 0);
        cVar3 = func_0x0001800ef4e0(arg1, 0x5d);
    }
    ppiVar7 = *(int64_t ***)(arg1 + 0xd8);
    iVar2 = (int64_t)*ppiVar7;
    var_38h = arg2;
    var_30h = iVar1;
    if (iVar2 == 0) {
code_r0x0001800eb3cb:
        piVar5 = (int64_t *)func_0x000180459890(0x2008);
        *piVar5 = (int64_t)*ppiVar7;
        piVar8 = piVar5 + 1;
        *ppiVar7 = piVar5;
        piVar5 = (int64_t *)0x30;
    } else {
        piVar8 = (int64_t *)((int64_t)ppiVar7[1] + iVar2 + 0xf & 0xfffffffffffffff8);
        if ((int64_t *)(iVar2 + 0x2008) < piVar8 + 6) goto code_r0x0001800eb3cb;
        piVar5 = (int64_t *)((int64_t)piVar8 + (0x30 - (iVar2 + 8)));
    }
    ppiVar7[1] = piVar5;
    *(undefined4 *)(piVar8 + 1) = *(undefined4 *)0x180782730;
    piVar8[4] = arg3;
    piVar8[5] = iVar4;
    *(undefined4 *)((int64_t)piVar8 + 0xc) = (undefined4)var_38h;
    *(undefined4 *)(piVar8 + 2) = var_38h._4_4_;
    *(undefined4 *)((int64_t)piVar8 + 0x14) = (undefined4)var_30h;
    *(undefined4 *)(piVar8 + 3) = var_30h._4_4_;
    *piVar8 = 0x180642090;
    if (*(char *)(arg1 + 0x58) == '\0') {
        return piVar8;
    }
    ppiVar7 = *(int64_t ***)(arg1 + 0xd8);
    if (cVar3 == '\0') {
        var_8h = -1;
        uVar9 = 0xffffffffffffffff;
    }
    iVar1 = (int64_t)*ppiVar7;
    if (iVar1 != 0) {
        piVar5 = (int64_t *)((int64_t)ppiVar7[1] + iVar1 + 0xf & 0xfffffffffffffff8);
        if ((int64_t)piVar5 + 0x14U <= iVar1 + 0x2008U) {
            piVar6 = (int64_t *)((int64_t)piVar5 + (0x14 - (iVar1 + 8)));
            goto code_r0x0001800eb493;
        }
    }
    piVar6 = (int64_t *)func_0x000180459890(0x2008);
    *piVar6 = (int64_t)*ppiVar7;
    piVar5 = piVar6 + 1;
    *ppiVar7 = piVar6;
    piVar6 = (int64_t *)0x14;
code_r0x0001800eb493:
    ppiVar7[1] = piVar6;
    *(undefined4 *)piVar5 = *(undefined4 *)0x180782a9c;
    *(uint64_t *)((int64_t)piVar5 + 4) = CONCAT44((undefined4)var_40h, var_44h);
    *(undefined8 *)((int64_t)piVar5 + 0xc) = uVar9;
    var_8h = (int64_t)piVar8;
    ppiVar7 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_8h);
    *ppiVar7 = piVar5;
    return piVar8;
}

// ============================================================
// Function: FUN_1800eb30d
// Address: 0x1800eb30d
// Size: 281 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_84h
// WARNING: [rz-ghidra] Removing arg arg_8ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Removing arg arg_490h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f0h

int64_t * fcn.1800eb2f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h, int64_t arg_80h, int64_t arg_d8h)
{
    int64_t iVar1;
    int64_t iVar2;
    char cVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t **ppiVar7;
    int64_t *piVar8;
    undefined8 uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t in_stack_00000160;
    undefined4 var_48h;
    undefined4 var_44h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    var_48h = (undefined4)*(undefined8 *)(arg1 + 0x80);
    var_44h = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x80) >> 0x20);
    var_40h._0_4_ = *(undefined4 *)(arg1 + 0x88);
    fcn.1800f0350();
    iVar4 = fcn.1800e9350(arg1, 0, in_stack_00000160);
    uVar9 = *(undefined8 *)(arg1 + 0x84);
    iVar1 = *(int64_t *)(arg1 + 0x8c);
    if (*(int32_t *)(arg1 + 0x80) == 0x5d) {
        fcn.1800f0350(arg1);
        cVar3 = '\x01';
    } else {
        func_0x0001800ef5a0(arg1, 0x5d, &var_48h, 0);
        cVar3 = func_0x0001800ef4e0(arg1, 0x5d);
    }
    ppiVar7 = *(int64_t ***)(arg1 + 0xd8);
    iVar2 = (int64_t)*ppiVar7;
    var_38h = arg2;
    var_30h = iVar1;
    if (iVar2 == 0) {
code_r0x0001800eb3cb:
        piVar5 = (int64_t *)func_0x000180459890(0x2008);
        *piVar5 = (int64_t)*ppiVar7;
        piVar8 = piVar5 + 1;
        *ppiVar7 = piVar5;
        piVar5 = (int64_t *)0x30;
    } else {
        piVar8 = (int64_t *)((int64_t)ppiVar7[1] + iVar2 + 0xf & 0xfffffffffffffff8);
        if ((int64_t *)(iVar2 + 0x2008) < piVar8 + 6) goto code_r0x0001800eb3cb;
        piVar5 = (int64_t *)((int64_t)piVar8 + (0x30 - (iVar2 + 8)));
    }
    ppiVar7[1] = piVar5;
    *(undefined4 *)(piVar8 + 1) = *(undefined4 *)0x180782730;
    piVar8[4] = arg3;
    piVar8[5] = iVar4;
    *(undefined4 *)((int64_t)piVar8 + 0xc) = (undefined4)var_38h;
    *(undefined4 *)(piVar8 + 2) = var_38h._4_4_;
    *(undefined4 *)((int64_t)piVar8 + 0x14) = (undefined4)var_30h;
    *(undefined4 *)(piVar8 + 3) = var_30h._4_4_;
    *piVar8 = 0x180642090;
    if (*(char *)(arg1 + 0x58) == '\0') {
        return piVar8;
    }
    ppiVar7 = *(int64_t ***)(arg1 + 0xd8);
    if (cVar3 == '\0') {
        var_8h = -1;
        uVar9 = 0xffffffffffffffff;
    }
    iVar1 = (int64_t)*ppiVar7;
    if (iVar1 != 0) {
        piVar5 = (int64_t *)((int64_t)ppiVar7[1] + iVar1 + 0xf & 0xfffffffffffffff8);
        if ((int64_t)piVar5 + 0x14U <= iVar1 + 0x2008U) {
            piVar6 = (int64_t *)((int64_t)piVar5 + (0x14 - (iVar1 + 8)));
            goto code_r0x0001800eb493;
        }
    }
    piVar6 = (int64_t *)func_0x000180459890(0x2008);
    *piVar6 = (int64_t)*ppiVar7;
    piVar5 = piVar6 + 1;
    *ppiVar7 = piVar6;
    piVar6 = (int64_t *)0x14;
code_r0x0001800eb493:
    ppiVar7[1] = piVar6;
    *(undefined4 *)piVar5 = *(undefined4 *)0x180782a9c;
    *(uint64_t *)((int64_t)piVar5 + 4) = CONCAT44((undefined4)var_40h, var_44h);
    *(undefined8 *)((int64_t)piVar5 + 0xc) = uVar9;
    var_8h = (int64_t)piVar8;
    ppiVar7 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_8h);
    *ppiVar7 = piVar5;
    return piVar8;
}

// ============================================================
// Function: FUN_1800eb426
// Address: 0x1800eb426
// Size: 182 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_84h
// WARNING: [rz-ghidra] Removing arg arg_8ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Removing arg arg_490h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f0h

int64_t * fcn.1800eb2f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h, int64_t arg_80h, int64_t arg_d8h)
{
    int64_t iVar1;
    int64_t iVar2;
    char cVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t **ppiVar7;
    int64_t *piVar8;
    undefined8 uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t in_stack_00000160;
    undefined4 var_48h;
    undefined4 var_44h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    var_48h = (undefined4)*(undefined8 *)(arg1 + 0x80);
    var_44h = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x80) >> 0x20);
    var_40h._0_4_ = *(undefined4 *)(arg1 + 0x88);
    fcn.1800f0350();
    iVar4 = fcn.1800e9350(arg1, 0, in_stack_00000160);
    uVar9 = *(undefined8 *)(arg1 + 0x84);
    iVar1 = *(int64_t *)(arg1 + 0x8c);
    if (*(int32_t *)(arg1 + 0x80) == 0x5d) {
        fcn.1800f0350(arg1);
        cVar3 = '\x01';
    } else {
        func_0x0001800ef5a0(arg1, 0x5d, &var_48h, 0);
        cVar3 = func_0x0001800ef4e0(arg1, 0x5d);
    }
    ppiVar7 = *(int64_t ***)(arg1 + 0xd8);
    iVar2 = (int64_t)*ppiVar7;
    var_38h = arg2;
    var_30h = iVar1;
    if (iVar2 == 0) {
code_r0x0001800eb3cb:
        piVar5 = (int64_t *)func_0x000180459890(0x2008);
        *piVar5 = (int64_t)*ppiVar7;
        piVar8 = piVar5 + 1;
        *ppiVar7 = piVar5;
        piVar5 = (int64_t *)0x30;
    } else {
        piVar8 = (int64_t *)((int64_t)ppiVar7[1] + iVar2 + 0xf & 0xfffffffffffffff8);
        if ((int64_t *)(iVar2 + 0x2008) < piVar8 + 6) goto code_r0x0001800eb3cb;
        piVar5 = (int64_t *)((int64_t)piVar8 + (0x30 - (iVar2 + 8)));
    }
    ppiVar7[1] = piVar5;
    *(undefined4 *)(piVar8 + 1) = *(undefined4 *)0x180782730;
    piVar8[4] = arg3;
    piVar8[5] = iVar4;
    *(undefined4 *)((int64_t)piVar8 + 0xc) = (undefined4)var_38h;
    *(undefined4 *)(piVar8 + 2) = var_38h._4_4_;
    *(undefined4 *)((int64_t)piVar8 + 0x14) = (undefined4)var_30h;
    *(undefined4 *)(piVar8 + 3) = var_30h._4_4_;
    *piVar8 = 0x180642090;
    if (*(char *)(arg1 + 0x58) == '\0') {
        return piVar8;
    }
    ppiVar7 = *(int64_t ***)(arg1 + 0xd8);
    if (cVar3 == '\0') {
        var_8h = -1;
        uVar9 = 0xffffffffffffffff;
    }
    iVar1 = (int64_t)*ppiVar7;
    if (iVar1 != 0) {
        piVar5 = (int64_t *)((int64_t)ppiVar7[1] + iVar1 + 0xf & 0xfffffffffffffff8);
        if ((int64_t)piVar5 + 0x14U <= iVar1 + 0x2008U) {
            piVar6 = (int64_t *)((int64_t)piVar5 + (0x14 - (iVar1 + 8)));
            goto code_r0x0001800eb493;
        }
    }
    piVar6 = (int64_t *)func_0x000180459890(0x2008);
    *piVar6 = (int64_t)*ppiVar7;
    piVar5 = piVar6 + 1;
    *ppiVar7 = piVar6;
    piVar6 = (int64_t *)0x14;
code_r0x0001800eb493:
    ppiVar7[1] = piVar6;
    *(undefined4 *)piVar5 = *(undefined4 *)0x180782a9c;
    *(uint64_t *)((int64_t)piVar5 + 4) = CONCAT44((undefined4)var_40h, var_44h);
    *(undefined8 *)((int64_t)piVar5 + 0xc) = uVar9;
    var_8h = (int64_t)piVar8;
    ppiVar7 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_8h);
    *ppiVar7 = piVar5;
    return piVar8;
}

// ============================================================
// Function: FUN_1800eb4e0
// Address: 0x1800eb4e0
// Size: 278 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

undefined fcn.1800eb4e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    int32_t *piVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    double dVar5;
    int64_t var_20h;
    
    var_20h = 0;
    uVar1 = fcn.18046c748(arg2, &var_20h);
    if (*(char *)var_20h != '\0') {
        return 2;
    }
    if ((int64_t)uVar1 < 0) {
        dVar5 = (double)(uVar1 >> 1 | (uint64_t)((uint32_t)uVar1 & 1));
        dVar5 = dVar5 + dVar5;
    } else {
        dVar5 = (double)uVar1;
    }
    *(double *)arg1 = dVar5;
    if (uVar1 == 0xffffffffffffffff) {
        piVar2 = (int32_t *)fcn.18046b77c();
        if (*piVar2 != 0x22) goto code_r0x0001800eb5a7;
        puVar3 = (undefined4 *)fcn.18046b77c();
        *puVar3 = 0;
        uVar1 = fcn.18046c748(arg2, &var_20h, arg3 & 0xffffffff);
        piVar2 = (int32_t *)fcn.18046b77c();
        if (*piVar2 == 0x22) {
            return ((int32_t)arg3 != 2) + '\x03';
        }
    }
    if (uVar1 < 0x20000000000000) {
        return false;
    }
code_r0x0001800eb5a7:
    dVar5 = *(double *)arg1;
    iVar4 = 0;
    if ((9.223372036854776e+18 <= dVar5) && (dVar5 = dVar5 - 9.223372036854776e+18, dVar5 < 9.223372036854776e+18)) {
        iVar4 = -0x8000000000000000;
    }
    return (int64_t)dVar5 + iVar4 != uVar1;
}

// ============================================================
// Function: FUN_1800eb600
// Address: 0x1800eb600
// Size: 322 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

char fcn.1800eb600(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int32_t *piVar2;
    undefined4 *puVar3;
    undefined8 uVar4;
    char cVar5;
    int64_t var_20h;
    
    var_20h = 0;
    if ((int32_t)arg3 == 10) {
        iVar1 = fcn.18046c5e0();
        *(int64_t *)arg1 = iVar1;
        if (((var_20h == arg2) || (*(char *)var_20h != 'i')) || (*(char *)(var_20h + 1) != '\0')) {
            return '\x02';
        }
        if (((iVar1 + 0x8000000000000001U & 0xfffffffffffffffe) == 0) &&
           (piVar2 = (int32_t *)fcn.18046b77c(), *piVar2 == 0x22)) {
            puVar3 = (undefined4 *)fcn.18046b77c();
            *puVar3 = 0;
            uVar4 = fcn.18046c5e0(arg2, &var_20h, arg3 & 0xffffffff);
            *(undefined8 *)arg1 = uVar4;
            piVar2 = (int32_t *)fcn.18046b77c();
            cVar5 = '\0';
            if (*piVar2 == 0x22) {
                cVar5 = '\x05';
            }
            return cVar5;
        }
    } else {
        iVar1 = fcn.18046c748(arg2, &var_20h);
        if (var_20h == arg2) {
            return '\x02';
        }
        if (*(char *)var_20h != 'i') {
            return '\x02';
        }
        if (*(char *)(var_20h + 1) != '\0') {
            return '\x02';
        }
        if ((iVar1 == -1) && (piVar2 = (int32_t *)fcn.18046b77c(), *piVar2 == 0x22)) {
            puVar3 = (undefined4 *)fcn.18046b77c();
            *puVar3 = 0;
            iVar1 = fcn.18046c748(arg2, &var_20h, arg3 & 0xffffffff);
            piVar2 = (int32_t *)fcn.18046b77c();
            if (*piVar2 == 0x22) {
                return ((int32_t)arg3 != 2) + '\x03';
            }
        }
        *(int64_t *)arg1 = iVar1;
    }
    return '\0';
}

// ============================================================
// Function: FUN_1800eb750
// Address: 0x1800eb750
// Size: 1788 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_11h
// WARNING: Variable defined which should be unmapped: var_19h
// WARNING: Variable defined which should be unmapped: var_21h
// WARNING: Variable defined which should be unmapped: var_29h
// WARNING: Variable defined which should be unmapped: var_31h
// WARNING: Variable defined which should be unmapped: var_39h
// WARNING: Variable defined which should be unmapped: var_41h
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_67h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_59h
// WARNING: [rz-ghidra] Detected overlap for variable var_51h
// WARNING: [rz-ghidra] Removing arg arg_6fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_55h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f0h

int64_t **
fcn.1800eb750(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h)
{
    int64_t **ppiVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t *piVar8;
    int64_t **ppiVar9;
    undefined uVar10;
    undefined4 uVar11;
    int64_t *piVar12;
    int64_t **ppiVar13;
    int64_t iVar14;
    undefined8 uVar15;
    undefined8 *puVar16;
    int64_t **ppiVar17;
    int64_t **ppiVar18;
    int64_t *piVar19;
    undefined8 uStackX_8;
    int64_t *piStackX_10;
    undefined uStackX_18;
    int64_t **ppiStackX_20;
    int64_t in_stack_000000c0;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t *piStack_d8;
    int64_t iStack_d0;
    undefined8 uStack_c8;
    undefined8 uStack_c0;
    undefined4 uStack_b8;
    undefined4 uStack_b4;
    undefined4 uStack_b0;
    undefined4 uStack_ac;
    int64_t iStack_a8;
    int64_t *piStack_a0;
    int64_t iStack_98;
    int64_t **ppiStack_90;
    int64_t *piStack_88;
    undefined auStack_80 [7];
    int64_t var_79h;
    int64_t var_71h;
    int64_t var_69h;
    int64_t var_61h;
    int64_t var_58h;
    int64_t var_49h;
    int64_t var_41h;
    int64_t var_39h;
    int64_t var_31h;
    int64_t var_29h;
    int64_t var_21h;
    int64_t var_19h;
    int64_t var_11h;
    
    iVar2 = *(int32_t *)(arg1 + 0x80);
    piStackX_10 = (int64_t *)arg2;
    uStackX_18 = (undefined)placeholder_2;
    if (iVar2 != 0x28) {
        if (iVar2 != 0x7b) {
            if (1 < iVar2 - 0x116U) {
                ppiVar17 = (int64_t **)func_0x0001800ebe50();
                return ppiVar17;
            }
            uVar4 = *(undefined4 *)(arg1 + 0x84);
            uVar5 = *(undefined4 *)(arg1 + 0x88);
            uVar6 = *(undefined4 *)(arg1 + 0x8c);
            uVar7 = *(undefined4 *)(arg1 + 0x90);
            iVar14 = func_0x0001800edec0();
            ppiVar17 = *(int64_t ***)(arg1 + 0xd8);
            iVar3 = (int64_t)*ppiVar17;
            if (iVar3 == 0) {
code_r0x0001800ebd0a:
                piVar19 = (int64_t *)func_0x000180459890(0x2008);
                *piVar19 = (int64_t)*ppiVar17;
                *ppiVar17 = piVar19;
                piVar19 = piVar19 + 1;
                piVar12 = (int64_t *)0x8;
            } else {
                piVar19 = (int64_t *)((int64_t)ppiVar17[1] + iVar3 + 0xf & 0xfffffffffffffff8);
                if ((int64_t *)(iVar3 + 0x2008U) < piVar19 + 1) goto code_r0x0001800ebd0a;
                piVar12 = (int64_t *)((int64_t)piVar19 + (8 - (iVar3 + 8)));
            }
            ppiVar17[1] = piVar12;
            *piVar19 = iVar14;
            var_e8h = *(int64_t *)(arg2 + 0xc);
            var_e0h = *(int64_t *)(iVar14 + 0x14);
            piVar12 = *ppiVar17;
            if (piVar12 == (int64_t *)0x0) {
code_r0x0001800ebd76:
                ppiVar13 = (int64_t **)func_0x000180459890(0x2008);
                *ppiVar13 = *ppiVar17;
                *ppiVar17 = (int64_t *)ppiVar13;
                ppiVar13 = ppiVar13 + 1;
                piVar12 = (int64_t *)0x60;
            } else {
                ppiVar13 = (int64_t **)((int64_t)ppiVar17[1] + 7 + (int64_t)(piVar12 + 1) & 0xfffffffffffffff8);
                if (piVar12 + 0x401 < ppiVar13 + 0xc) goto code_r0x0001800ebd76;
                piVar12 = (int64_t *)((int64_t)ppiVar13 + (0x60 - (int64_t)(piVar12 + 1)));
            }
            ppiVar17[1] = piVar12;
            uVar11 = *(undefined4 *)0x180782740;
            *(undefined4 *)((int64_t)ppiVar13 + 0xc) = (undefined4)var_e8h;
            *(undefined4 *)(ppiVar13 + 2) = var_e8h._4_4_;
            *(undefined4 *)((int64_t)ppiVar13 + 0x14) = (undefined4)var_e0h;
            *(undefined4 *)(ppiVar13 + 3) = var_e0h._4_4_;
            *(undefined4 *)((int64_t)ppiVar13 + 0x4c) = uVar4;
            *(undefined4 *)(ppiVar13 + 10) = uVar5;
            *(undefined4 *)((int64_t)ppiVar13 + 0x54) = uVar6;
            *(undefined4 *)(ppiVar13 + 0xb) = uVar7;
            goto code_r0x0001800ebda9;
        }
        uVar15 = *(undefined8 *)(arg1 + 0x8c);
        iVar14 = func_0x0001800ebfc0();
        ppiVar17 = *(int64_t ***)(arg1 + 0xd8);
        uStack_b8 = (undefined4)uVar15;
        uStack_b4 = (undefined4)((uint64_t)uVar15 >> 0x20);
        uStack_b0 = (undefined4)*(undefined8 *)(arg1 + 0xa8);
        uStack_ac = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0xa8) >> 0x20);
        iVar3 = (int64_t)*ppiVar17;
        if (iVar3 == 0) {
code_r0x0001800ebc01:
            piVar19 = (int64_t *)func_0x000180459890(0x2008);
            *piVar19 = (int64_t)*ppiVar17;
            *ppiVar17 = piVar19;
            piVar19 = piVar19 + 1;
            piVar12 = (int64_t *)0x8;
        } else {
            piVar19 = (int64_t *)((int64_t)ppiVar17[1] + iVar3 + 0xf & 0xfffffffffffffff8);
            if ((int64_t *)(iVar3 + 0x2008U) < piVar19 + 1) goto code_r0x0001800ebc01;
            piVar12 = (int64_t *)((int64_t)piVar19 + (8 - (iVar3 + 8)));
        }
        ppiVar17[1] = piVar12;
        *piVar19 = iVar14;
        var_e8h = *(int64_t *)(arg2 + 0xc);
        var_e0h = *(int64_t *)(iVar14 + 0x14);
        piVar12 = *ppiVar17;
        if (piVar12 == (int64_t *)0x0) {
code_r0x0001800ebc6d:
            ppiVar13 = (int64_t **)func_0x000180459890(0x2008);
            *ppiVar13 = *ppiVar17;
            *ppiVar17 = (int64_t *)ppiVar13;
            ppiVar13 = ppiVar13 + 1;
            piVar12 = (int64_t *)0x60;
        } else {
            ppiVar13 = (int64_t **)((int64_t)ppiVar17[1] + 7 + (int64_t)(piVar12 + 1) & 0xfffffffffffffff8);
            if (piVar12 + 0x401 < ppiVar13 + 0xc) goto code_r0x0001800ebc6d;
            piVar12 = (int64_t *)((int64_t)ppiVar13 + (0x60 - (int64_t)(piVar12 + 1)));
        }
        ppiVar17[1] = piVar12;
        uVar11 = *(undefined4 *)0x180782740;
        *(undefined4 *)((int64_t)ppiVar13 + 0xc) = (undefined4)var_e8h;
        *(undefined4 *)(ppiVar13 + 2) = var_e8h._4_4_;
        *(undefined4 *)((int64_t)ppiVar13 + 0x14) = (undefined4)var_e0h;
        *(undefined4 *)(ppiVar13 + 3) = var_e0h._4_4_;
        *(undefined4 *)((int64_t)ppiVar13 + 0x4c) = uStack_b8;
        *(undefined4 *)(ppiVar13 + 10) = uStack_b4;
        *(undefined4 *)((int64_t)ppiVar13 + 0x54) = uStack_b0;
        *(undefined4 *)(ppiVar13 + 0xb) = uStack_ac;
code_r0x0001800ebda9:
        *(undefined4 *)(ppiVar13 + 1) = uVar11;
        *ppiVar13 = (int64_t *)0x1806419f0;
        ppiVar13[4] = (int64_t *)arg2;
        ppiVar13[5] = (int64_t *)0x0;
        ppiVar13[6] = (int64_t *)0x0;
        ppiVar13[7] = piVar19;
        ppiVar13[8] = (int64_t *)0x1;
        *(undefined *)(ppiVar13 + 9) = uStackX_18;
        if (*(char *)(arg1 + 0x58) == '\0') {
            return ppiVar13;
        }
        var_e8h = 0;
        var_e0h = 0;
        uStackX_8 = (int64_t **)0xffffffffffffffff;
        ppiStackX_20 = (int64_t **)0xffffffffffffffff;
        uVar15 = func_0x0001800f1900(*(undefined8 *)(arg1 + 0xd8), &ppiStackX_20, &uStackX_8, &var_e8h);
        uStackX_8 = ppiVar13;
        puVar16 = (undefined8 *)func_0x0001800cc970(arg1 + 0x490, &uStackX_8);
        *puVar16 = uVar15;
        return ppiVar13;
    }
    iVar3 = *(int64_t *)(arg1 + 0x8c);
    if (*(int32_t *)(arg2 + 0x14) != *(int32_t *)(arg1 + 0x84)) {
        func_0x0001800ebfa0();
    }
    uStack_b8 = (undefined4)*(undefined8 *)(arg1 + 0x80);
    uStack_b4 = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x80) >> 0x20);
    uStack_b0 = *(undefined4 *)(arg1 + 0x88);
    fcn.1800f0350(arg1);
    piVar19 = (int64_t *)(arg1 + 0x290);
    iStack_a8 = *(int64_t *)(arg1 + 0x298) - *piVar19 >> 3;
    ppiVar13 = (int64_t **)0x0;
    stack0xffffffffffffff88 = (int64_t **)0x0;
    piStack_d8 = (int64_t *)(arg1 + 0x440);
    iStack_d0 = *(int64_t *)(arg1 + 0x448) - *piStack_d8 >> 3;
    ppiStack_90 = (int64_t **)0x0;
    ppiVar17 = ppiVar13;
    piStack_a0 = piStack_d8;
    iStack_98 = iStack_d0;
    piStack_88 = piVar19;
    _auStack_80 = iStack_a8;
    if (*(int32_t *)(arg1 + 0x80) != 0x29) {
        ppiVar18 = &piStack_a0;
        if (*(char *)(arg1 + 0x58) == '\0') {
            ppiVar18 = ppiVar13;
        }
        uStackX_8 = (int64_t **)fcn.1800e9350(arg1, 0, in_stack_000000c0);
        func_0x0001800bf890(piVar19);
        ppiVar17 = (int64_t **)0x1;
        stack0xffffffffffffff88 = (int64_t **)0x1;
        if (*(int32_t *)(arg1 + 0x80) == 0x2c) {
            do {
                ppiVar17 = stack0xffffffffffffff88;
                if (ppiVar18 != (int64_t **)0x0) {
                    func_0x0001800f1a70(ppiVar18);
                }
                fcn.1800f0350(arg1);
                if (*(int32_t *)(arg1 + 0x80) == 0x29) {
                    fcn.1800efe70(arg1, arg1 + 0x84, 0x1806433c8);
                    break;
                }
                uStackX_8 = (int64_t **)fcn.1800e9350(arg1, 0, in_stack_000000c0);
                func_0x0001800bf890(piVar19);
                ppiVar17 = (int64_t **)((int64_t)ppiVar17 + 1);
                unique0x10000aae = ppiVar17;
            } while (*(int32_t *)(arg1 + 0x80) == 0x2c);
            piStack_d8 = piStack_a0;
            iStack_d0 = iStack_98;
        }
    }
    var_e8h = *(int64_t *)(arg1 + 0x84);
    iVar14 = *(int64_t *)(arg1 + 0x8c);
    var_e0h = iVar14;
    if (*(int32_t *)(arg1 + 0x80) == 0x29) {
        fcn.1800f0350(arg1);
        uStackX_8 = (int64_t **)CONCAT71(uStackX_8._1_7_, 1);
    } else {
        func_0x0001800ef5a0(arg1, 0x29, &uStack_b8, 0);
        uVar10 = func_0x0001800ef4e0(arg1, 0x29);
        uStackX_8 = (int64_t **)CONCAT71(uStackX_8._1_7_, uVar10);
    }
    ppiStackX_20 = *(int64_t ***)(arg1 + 0xd8);
    ppiVar18 = ppiVar13;
    if (ppiVar17 != (int64_t **)0x0) {
        ppiVar18 = (int64_t **)(*piVar19 + iStack_a8 * 8);
    }
    var_e8h = iVar3;
    var_e0h = iVar14;
    func_0x0001800f1110(arg1, (int64_t)&var_71h + 1, ppiVar18, ppiVar17);
    ppiVar17 = ppiStackX_20;
    piVar8 = piStackX_10;
    uStack_c8 = *(int64_t ***)((int64_t)piStackX_10 + 0xc);
    piVar12 = *ppiStackX_20;
    uStack_c0 = iVar14;
    if (piVar12 == (int64_t *)0x0) {
code_r0x0001800eb99f:
        ppiVar18 = (int64_t **)func_0x000180459890(0x2008);
        *ppiVar18 = *ppiVar17;
        *ppiVar17 = (int64_t *)ppiVar18;
        ppiVar18 = ppiVar18 + 1;
        piVar12 = (int64_t *)0x60;
    } else {
        ppiVar18 = (int64_t **)((int64_t)ppiStackX_20[1] + 7 + (int64_t)(piVar12 + 1) & 0xfffffffffffffff8);
        if (piVar12 + 0x401 < ppiVar18 + 0xc) goto code_r0x0001800eb99f;
        piVar12 = (int64_t *)((int64_t)ppiVar18 + (0x60 - (int64_t)(piVar12 + 1)));
    }
    ppiVar9 = ppiStack_90;
    ppiVar17[1] = piVar12;
    *(undefined4 *)(ppiVar18 + 1) = *(undefined4 *)0x180782740;
    *(undefined4 *)((int64_t)ppiVar18 + 0xc) = (undefined4)uStack_c8;
    *(undefined4 *)(ppiVar18 + 2) = uStack_c8._4_4_;
    *(undefined4 *)((int64_t)ppiVar18 + 0x14) = (undefined4)uStack_c0;
    *(undefined4 *)(ppiVar18 + 3) = uStack_c0._4_4_;
    *ppiVar18 = (int64_t *)0x1806419f0;
    ppiVar18[4] = piVar8;
    ppiVar18[5] = (int64_t *)0x0;
    ppiVar18[6] = (int64_t *)0x0;
    *(undefined4 *)(ppiVar18 + 7) = var_71h._1_4_;
    *(undefined4 *)((int64_t)ppiVar18 + 0x3c) = stack0xffffffffffffff94;
    *(undefined4 *)(ppiVar18 + 8) = var_69h._1_4_;
    *(undefined4 *)((int64_t)ppiVar18 + 0x44) = stack0xffffffffffffff9c;
    *(undefined *)(ppiVar18 + 9) = uStackX_18;
    *(undefined4 *)((int64_t)ppiVar18 + 0x4c) = (undefined4)var_e8h;
    *(undefined4 *)(ppiVar18 + 10) = var_e8h._4_4_;
    *(undefined4 *)((int64_t)ppiVar18 + 0x54) = (undefined4)var_e0h;
    *(undefined4 *)(ppiVar18 + 0xb) = var_e0h._4_4_;
    if (*(char *)(arg1 + 0x58) == '\0') goto code_r0x0001800ebb65;
    uStack_c8 = *(int64_t ***)(arg1 + 0xd8);
    if (ppiStack_90 == (int64_t **)0x0) {
        ppiStackX_20 = (int64_t **)0x0;
    } else {
        iVar3 = *piStack_d8;
        ppiVar17 = (int64_t **)func_0x0001800d4d20(uStack_c8, (int64_t)ppiStack_90 * 8);
        ppiStackX_20 = ppiVar17;
        if (ppiVar9 != (int64_t **)0x0) {
            ppiVar1 = (int64_t **)(iVar3 + iStack_d0 * 8);
            if ((ppiVar9 < (int64_t **)0x2) ||
               ((ppiVar17 <= ppiVar1 + (int64_t)ppiVar9 + -1 && (ppiVar1 <= ppiVar17 + (int64_t)ppiVar9 + -1)))) {
                do {
                    ppiVar17[(int64_t)ppiVar13] = ppiVar1[(int64_t)ppiVar13];
                    ppiVar13 = (int64_t **)((int64_t)ppiVar13 + 1);
                } while (ppiVar13 < ppiVar9);
            } else {
                func_0x000180498030(ppiVar17, ppiVar1, (int64_t)ppiVar9 * 8);
                ppiStackX_20 = ppiVar17;
            }
        }
    }
    if ((char)uStackX_8 == '\0') {
        uStackX_8 = (int64_t **)0xffffffffffffffff;
        uVar15 = 0xffffffffffffffff;
    } else {
        uVar15 = *(undefined8 *)(arg1 + 0xa0);
    }
    piVar12 = *uStack_c8;
    if (piVar12 == (int64_t *)0x0) {
code_r0x0001800ebb06:
        ppiVar17 = (int64_t **)func_0x000180459890(0x2008);
        *ppiVar17 = *uStack_c8;
        *uStack_c8 = (int64_t *)ppiVar17;
        ppiVar17 = ppiVar17 + 1;
        piVar12 = (int64_t *)0x30;
    } else {
        ppiVar17 = (int64_t **)((int64_t)uStack_c8[1] + (int64_t)(piVar12 + 1) + 7 & 0xfffffffffffffff8);
        if (piVar12 + 0x401 < ppiVar17 + 6) goto code_r0x0001800ebb06;
        piVar12 = (int64_t *)((int64_t)ppiVar17 + (0x30 - (int64_t)(piVar12 + 1)));
    }
    uStack_c8[1] = piVar12;
    *(undefined4 *)ppiVar17 = *(undefined4 *)0x180782ab4;
    *(uint64_t *)((int64_t)ppiVar17 + 4) = CONCAT44(uStack_b0, uStack_b4);
    *(undefined8 *)((int64_t)ppiVar17 + 0xc) = uVar15;
    ppiVar17[3] = (int64_t *)ppiStackX_20;
    ppiVar17[4] = (int64_t *)ppiVar9;
    ppiVar17[5] = (int64_t *)0x0;
    uStackX_8 = ppiVar18;
    ppiVar13 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &uStackX_8);
    *ppiVar13 = (int64_t *)ppiVar17;
code_r0x0001800ebb65:
    iVar3 = *piStack_d8 + iStack_d0 * 8;
    if (iVar3 != piStack_d8[1]) {
        piStack_d8[1] = iVar3;
    }
    iVar3 = *piVar19 + iStack_a8 * 8;
    if (iVar3 != *(int64_t *)(arg1 + 0x298)) {
        *(int64_t *)(arg1 + 0x298) = iVar3;
    }
    return ppiVar18;
}

// ============================================================
// Function: FUN_1800ebe50
// Address: 0x1800ebe50
// Size: 321 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800ebe50(int64_t arg1, int64_t arg2, int64_t arg_60h)
{
    code *pcVar1;
    int64_t iVar2;
    undefined *puVar3;
    char in_R8B;
    int64_t var_ch;
    int64_t var_18h;
    undefined auStack_98 [8];
    undefined auStack_90 [24];
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_28h;
    int64_t var_20h;
    
    puVar3 = auStack_98;
    var_20h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_98;
    var_68h = arg2;
    if ((in_R8B == '\0') || (*(int32_t *)(arg1 + 0x84) == *(int32_t *)(arg2 + 0x14))) {
        var_78h = func_0x0001800d62b0(arg1 + 0x80, &var_40h);
        if (0xf < *(uint64_t *)(var_78h + 0x18)) {
            var_78h = *(int64_t *)var_78h;
        }
        func_0x0001800f1110(arg1, &var_50h, &var_68h, 1);
        var_60h = *(int64_t *)(arg2 + 0xc);
        var_58h = *(int64_t *)(arg1 + 0x84);
        func_0x0001800f0080(arg1, &var_60h, &var_50h, 0x180643b60);
        if (0xf < (uint64_t)var_28h) {
            puVar3 = auStack_98;
            iVar2 = var_40h;
            if ((0xfff < var_28h + 1U) &&
               (iVar2 = *(int64_t *)(var_40h + -8), puVar3 = auStack_98, 0x1f < (var_40h - iVar2) - 8U)) {
                iVar2 = 5;
                pcVar1 = (code *)swi(0x29);
                (*pcVar1)(5);
                puVar3 = auStack_90;
            }
            *(undefined8 *)(puVar3 + -8) = 0x1800ebf6e;
            func_0x000180459c3c(iVar2);
        }
    } else {
        func_0x0001800f1110(arg1, &var_60h, &var_68h, 1);
        func_0x0001800f0080(arg1, arg2 + 0xc, &var_60h, 0x180643d60);
        puVar3 = auStack_98;
    }
    *(undefined8 *)(puVar3 + -8) = 0x1800ebf7e;
    func_0x000180459870(*(uint64_t *)(puVar3 + 0x78) ^ (uint64_t)puVar3);
    return;
}

// ============================================================
// Function: FUN_1800ebfc0
// Address: 0x1800ebfc0
// Size: 2043 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_d8h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f0h

undefined8 * fcn.1800ebfc0(int64_t arg1)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    undefined auVar3 [16];
    int64_t iVar4;
    char cVar5;
    int32_t iVar6;
    int32_t *piVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t iVar12;
    int64_t **ppiVar13;
    uint64_t uVar14;
    int64_t **ppiVar15;
    undefined8 *puVar16;
    int64_t iVar17;
    int64_t iVar18;
    undefined4 uVar19;
    undefined4 uVar20;
    undefined4 uVar21;
    undefined4 uVar22;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t in_stack_000000b0;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    undefined4 var_88h;
    undefined4 uStack_84;
    int64_t var_80h;
    int64_t var_70h;
    undefined4 uStack_68;
    undefined4 uStack_64;
    int64_t var_58h;
    
    piVar11 = (int64_t *)(arg1 + 0x3b0);
    iVar17 = (*(int64_t *)(arg1 + 0x3b8) - *piVar11 >> 3) * -0x5555555555555555;
    var_b0h = 0;
    piVar8 = (int64_t *)(arg1 + 0x3c8);
    iVar18 = (*(int64_t *)(arg1 + 0x3d0) - *piVar8 >> 2) * -0x71c71c71c71c71c7;
    var_98h = 0;
    var_70h._0_4_ = *(undefined4 *)(arg1 + 0x84);
    var_70h._4_4_ = *(undefined4 *)(arg1 + 0x88);
    uStack_68 = *(undefined4 *)(arg1 + 0x8c);
    uStack_64 = *(undefined4 *)(arg1 + 0x90);
    var_90h._0_4_ = *(int32_t *)(arg1 + 0x80);
    var_90h._4_4_ = (undefined4)*(undefined8 *)(arg1 + 0x84);
    var_88h = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x84) >> 0x20);
    var_10h = (int64_t)piVar8;
    var_18h = (int64_t)piVar11;
    var_c0h = (int64_t)piVar11;
    var_b8h = iVar17;
    var_a8h = (int64_t)piVar8;
    var_a0h = iVar18;
    if ((int32_t)var_90h == 0x7b) {
        fcn.1800f0350(arg1);
    } else {
        func_0x0001800ef2a0(arg1, 0x7b, 0x180643c48);
    }
    var_8h = (uint64_t)var_8h._4_4_ << 0x20;
    iVar6 = *(int32_t *)(arg1 + 0x80);
    if (iVar6 != 0x7d) {
        do {
            if (*(char *)0x180778180 == '\0') {
                var_8h = CONCAT44(var_8h._4_4_, *(undefined4 *)(arg1 + 0x88));
            }
            if (iVar6 == 0x5b) {
                unique0x0000c280 = *(undefined8 *)(arg1 + 0x84);
                var_80h._0_4_ = iVar6;
                fcn.1800f0350(arg1);
                fcn.1800e9350(arg1, 0, in_stack_000000b0);
                if (*(int32_t *)(arg1 + 0x80) == 0x5d) {
                    fcn.1800f0350(arg1);
code_r0x0001800ec126:
                    var_10h = *(int64_t *)(arg1 + 0xa0);
                } else {
                    func_0x0001800ef5a0(arg1, 0x5d, &var_80h, 0);
                    cVar5 = func_0x0001800ef4e0(arg1);
                    if (cVar5 != '\0') goto code_r0x0001800ec126;
                    var_10h = -1;
                }
                if (*(int32_t *)(arg1 + 0x80) == 0x3d) {
                    fcn.1800f0350(arg1);
code_r0x0001800ec165:
                    var_18h = *(int64_t *)(arg1 + 0xa0);
                } else {
                    cVar5 = func_0x0001800ef2a0(arg1, 0x3d, 0x1806436d0);
                    if (cVar5 != '\0') goto code_r0x0001800ec165;
                    var_18h = -1;
                }
                fcn.1800e9350(arg1, 0, in_stack_000000b0);
                func_0x0001800f25b0(&var_c0h);
                if (*(char *)(arg1 + 0x58) != '\0') {
                    cVar5 = '\0';
                    if (*(int32_t *)(arg1 + 0x80) != 0x2c) {
                        cVar5 = (*(int32_t *)(arg1 + 0x80) != 0x3b) + '\x01';
                    }
                    if (cVar5 == '\x02') {
                        var_20h = -1;
                    } else {
                        var_20h = *(int64_t *)(arg1 + 0x84);
                    }
code_r0x0001800ec1f5:
                    func_0x0001800f27d0(&var_a8h);
                }
            } else if ((iVar6 == 0x119) && (piVar7 = (int32_t *)func_0x0001800d70e0(arg1 + 0x60), *piVar7 == 0x3d)) {
                if (*(int32_t *)(arg1 + 0x80) == 0x119) {
                    iVar17 = *(int64_t *)(arg1 + 0x98);
                    uVar19 = *(undefined4 *)(arg1 + 0x84);
                    uVar20 = *(undefined4 *)(arg1 + 0x88);
                    uVar21 = *(undefined4 *)(arg1 + 0x8c);
                    uVar22 = *(undefined4 *)(arg1 + 0x90);
                    fcn.1800f0350(arg1);
                } else {
                    func_0x0001800efe90();
                    uVar19 = *(undefined4 *)(arg1 + 0x84);
                    uVar20 = *(undefined4 *)(arg1 + 0x88);
                    iVar17 = *(int64_t *)(arg1 + 0x128);
                    uVar21 = uVar19;
                    uVar22 = uVar20;
                }
                if (*(int32_t *)(arg1 + 0x80) == 0x3d) {
                    fcn.1800f0350(arg1);
                } else {
                    func_0x0001800ef2a0(arg1, 0x3d, 0x1806436d0);
                }
                iVar12 = func_0x000180498cd0(iVar17);
                ppiVar13 = *(int64_t ***)(arg1 + 0xd8);
                iVar18 = (int64_t)*ppiVar13;
                if (iVar18 == 0) {
code_r0x0001800ec2ee:
                    piVar11 = (int64_t *)func_0x000180459890(0x2008);
                    *piVar11 = (int64_t)*ppiVar13;
                    *ppiVar13 = piVar11;
                    piVar11 = piVar11 + 1;
                    piVar8 = (int64_t *)0x38;
                } else {
                    piVar11 = (int64_t *)((int64_t)ppiVar13[1] + iVar18 + 0xf & 0xfffffffffffffff8);
                    if ((int64_t *)(iVar18 + 0x2008) < piVar11 + 7) goto code_r0x0001800ec2ee;
                    piVar8 = (int64_t *)((int64_t)piVar11 + (0x38 - (iVar18 + 8)));
                }
                ppiVar13[1] = piVar8;
                *(undefined4 *)(piVar11 + 1) = *(undefined4 *)0x18078273c;
                auVar3._4_4_ = uVar20;
                auVar3._0_4_ = uVar19;
                auVar3._8_4_ = uVar21;
                auVar3._12_4_ = uVar22;
                *(undefined (*) [16])((int64_t)piVar11 + 0xc) = auVar3;
                *piVar11 = 0x180642158;
                piVar11[4] = iVar17;
                piVar11[5] = iVar12;
                *(undefined4 *)(piVar11 + 6) = 3;
                iVar12 = fcn.1800e9350(arg1, 0, in_stack_000000b0);
                iVar18 = 0;
                if (*(int32_t *)(iVar12 + 8) == *(int32_t *)0x1807826a0) {
                    iVar18 = iVar12;
                }
                if (iVar18 != 0) {
                    *(int64_t *)(iVar18 + 0xa0) = iVar17;
                }
                func_0x0001800f25b0(&var_c0h);
                if (*(char *)(arg1 + 0x58) != '\0') {
                    func_0x0001800f27d0(&var_a8h);
                }
            } else {
                fcn.1800e9350(arg1, 0, in_stack_000000b0);
                func_0x0001800f25b0(&var_c0h);
                if (*(char *)(arg1 + 0x58) != '\0') goto code_r0x0001800ec1f5;
            }
            iVar6 = *(int32_t *)(arg1 + 0x80);
            if ((iVar6 == 0x2c) || (iVar6 == 0x3b)) {
                fcn.1800f0350(arg1);
            } else if (((iVar6 == 0x5b) || (iVar6 == 0x119)) &&
                      ((*(char *)0x180778180 != '\0' || (*(int32_t *)(arg1 + 0x88) == (int32_t)var_8h)))) {
                fcn.1800efe70(arg1, arg1 + 0x84, 0x180643c58);
            } else if (iVar6 != 0x7d) break;
            iVar6 = *(int32_t *)(arg1 + 0x80);
        } while (iVar6 != 0x7d);
        var_10h = var_a8h;
        var_18h = var_c0h;
        piVar11 = (int64_t *)var_c0h;
        iVar17 = var_b8h;
        iVar18 = var_a0h;
        piVar8 = (int64_t *)var_a8h;
    }
    var_f0h = *(int64_t *)(arg1 + 0x8c);
    if (iVar6 == 0x7d) {
        fcn.1800f0350(arg1);
    } else {
        func_0x0001800ef5a0(arg1, 0x7d, &var_90h, 0);
        cVar5 = func_0x0001800ef4e0(arg1, 0x7d);
        if (cVar5 == '\0') {
            var_f0h = *(int64_t *)(arg1 + 0xa8);
        }
    }
    iVar12 = var_b0h;
    var_8h = *(int64_t *)(arg1 + 0xd8);
    if (var_b0h == 0) {
        iVar9 = 0;
    } else {
        iVar10 = *piVar11 + iVar17 * 0x18;
        iVar9 = func_0x0001800d4d20(var_8h);
        uVar14 = 0;
        if (iVar12 != 0) {
            do {
                puVar1 = (undefined4 *)(iVar10 + uVar14 * 0x18);
                uVar19 = puVar1[1];
                uVar20 = puVar1[2];
                uVar21 = puVar1[3];
                puVar2 = (undefined4 *)(iVar9 + uVar14 * 0x18);
                *puVar2 = *puVar1;
                puVar2[1] = uVar19;
                puVar2[2] = uVar20;
                puVar2[3] = uVar21;
                *(undefined8 *)(iVar9 + 0x10 + uVar14 * 0x18) = *(undefined8 *)(iVar10 + 0x10 + uVar14 * 0x18);
                uVar14 = uVar14 + 1;
            } while (uVar14 < (uint64_t)iVar12);
        }
    }
    var_90h._0_4_ = (undefined4)var_70h;
    var_90h._4_4_ = var_70h._4_4_;
    var_88h = (undefined4)var_f0h;
    uStack_84 = (undefined4)((uint64_t)var_f0h >> 0x20);
    iVar10 = *(int64_t *)var_8h;
    if (iVar10 == 0) {
code_r0x0001800ec60c:
        puVar16 = (undefined8 *)func_0x000180459890(0x2008);
        *puVar16 = *(undefined8 *)var_8h;
        *(undefined8 **)var_8h = puVar16;
        puVar16 = puVar16 + 1;
        iVar10 = 0x30;
    } else {
        puVar16 = (undefined8 *)(*(int64_t *)(var_8h + 8) + 7 + iVar10 + 8 & 0xfffffffffffffff8);
        if ((undefined8 *)(iVar10 + 0x2008) < puVar16 + 6) goto code_r0x0001800ec60c;
        iVar10 = (int64_t)puVar16 + (0x30 - (iVar10 + 8));
    }
    iVar4 = var_98h;
    *(int64_t *)(var_8h + 8) = iVar10;
    *(undefined4 *)(puVar16 + 1) = *(undefined4 *)0x180782758;
    *(int32_t *)((int64_t)puVar16 + 0xc) = (int32_t)var_90h;
    *(undefined4 *)(puVar16 + 2) = var_90h._4_4_;
    *(undefined4 *)((int64_t)puVar16 + 0x14) = var_88h;
    *(undefined4 *)(puVar16 + 3) = uStack_84;
    *puVar16 = 0x180641d98;
    puVar16[4] = iVar9;
    puVar16[5] = iVar12;
    if (*(char *)(arg1 + 0x58) == '\0') goto code_r0x0001800ec763;
    ppiVar13 = *(int64_t ***)(arg1 + 0xd8);
    var_8h = (int64_t)ppiVar13;
    if (var_98h == 0) {
        piVar11 = (int64_t *)0x0;
    } else {
        var_20h = *piVar8 + iVar18 * 0x24;
        piVar11 = (int64_t *)func_0x0001800d4d20(ppiVar13);
        uVar14 = 0;
        if (iVar4 != 0) {
            do {
                puVar1 = (undefined4 *)(var_20h + uVar14 * 0x24);
                uVar19 = puVar1[1];
                uVar20 = puVar1[2];
                uVar21 = puVar1[3];
                puVar2 = (undefined4 *)((int64_t)piVar11 + uVar14 * 0x24);
                *puVar2 = *puVar1;
                puVar2[1] = uVar19;
                puVar2[2] = uVar20;
                puVar2[3] = uVar21;
                puVar1 = (undefined4 *)(var_20h + 0x10 + uVar14 * 0x24);
                uVar19 = puVar1[1];
                uVar20 = puVar1[2];
                uVar21 = puVar1[3];
                puVar2 = (undefined4 *)((int64_t)piVar11 + uVar14 * 0x24 + 0x10);
                *puVar2 = *puVar1;
                puVar2[1] = uVar19;
                puVar2[2] = uVar20;
                puVar2[3] = uVar21;
                *(undefined4 *)((int64_t)piVar11 + uVar14 * 0x24 + 0x20) =
                     *(undefined4 *)(var_20h + 0x20 + uVar14 * 0x24);
                uVar14 = uVar14 + 1;
                ppiVar13 = (int64_t **)var_8h;
            } while (uVar14 < (uint64_t)iVar4);
        }
    }
    piVar8 = *ppiVar13;
    if (piVar8 == (int64_t *)0x0) {
code_r0x0001800ec718:
        ppiVar15 = (int64_t **)func_0x000180459890(0x2008);
        *ppiVar15 = *ppiVar13;
        *ppiVar13 = (int64_t *)ppiVar15;
        ppiVar15 = ppiVar15 + 1;
        iVar12 = 0x18;
    } else {
        ppiVar15 = (int64_t **)((int64_t)ppiVar13[1] + 7 + (int64_t)(piVar8 + 1) & 0xfffffffffffffff8);
        ppiVar13 = (int64_t **)var_8h;
        if (piVar8 + 0x401 < ppiVar15 + 3) goto code_r0x0001800ec718;
        iVar12 = (int64_t)ppiVar15 + (0x18 - (int64_t)(piVar8 + 1));
    }
    *(int64_t *)(var_8h + 8) = iVar12;
    *(undefined4 *)ppiVar15 = *(undefined4 *)0x180782ac4;
    ppiVar15[1] = piVar11;
    ppiVar15[2] = (int64_t *)iVar4;
    var_8h = (int64_t)puVar16;
    ppiVar13 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_8h);
    *ppiVar13 = (int64_t *)ppiVar15;
code_r0x0001800ec763:
    iVar18 = *(int64_t *)var_10h + iVar18 * 0x24;
    if (iVar18 != *(int64_t *)(var_10h + 8)) {
        *(int64_t *)(var_10h + 8) = iVar18;
    }
    iVar17 = *(int64_t *)var_18h + iVar17 * 0x18;
    if (iVar17 != *(int64_t *)(var_18h + 8)) {
        *(int64_t *)(var_18h + 8) = iVar17;
    }
    return puVar16;
}

// ============================================================
// Function: FUN_1800ec7c0
// Address: 0x1800ec7c0
// Size: 130 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f0h

int64_t * fcn.1800ec7c0(int64_t arg1)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    char cVar9;
    undefined uVar10;
    int64_t iVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    int64_t **ppiVar14;
    int64_t *piVar15;
    undefined8 uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStackX_20;
    int64_t in_stack_00000140;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar5 = *(undefined4 *)(arg1 + 0x84);
    uVar6 = *(undefined4 *)(arg1 + 0x88);
    fcn.1800f0350();
    var_10h = fcn.1800e9350(arg1, 0, in_stack_00000140);
    if (*(int32_t *)(arg1 + 0x80) == 0x134) {
        fcn.1800f0350(arg1);
        cVar9 = '\x01';
code_r0x0001800ec834:
        uVar16 = *(undefined8 *)(arg1 + 0xa0);
    } else {
        cVar9 = func_0x0001800ef2a0(arg1, 0x134, 0x180643e68);
        if (cVar9 != '\0') goto code_r0x0001800ec834;
        var_8h = -1;
        uVar16 = 0xffffffffffffffff;
    }
    var_18h = fcn.1800e9350(arg1, 0, in_stack_00000140);
    uStackX_20 = *(undefined8 *)(arg1 + 0x84);
    if (*(int32_t *)(arg1 + 0x80) == 0x127) {
        iVar2 = *(int32_t *)(arg1 + 0x114);
        uVar1 = iVar2 + 1;
        *(uint32_t *)(arg1 + 0x114) = uVar1;
        if (*(uint32_t *)0x180778500 < uVar1) {
            iVar11 = func_0x0001800d90d0(arg1 + 0x60);
            func_0x0001800d9940(iVar11 + 4, 0x180644050, 0x180643b50);
            pcVar4 = (code *)swi(3);
            piVar15 = (int64_t *)(*pcVar4)();
            return piVar15;
        }
        uVar10 = 1;
        iVar11 = fcn.1800ec7c0(arg1);
        *(int32_t *)(arg1 + 0x114) = iVar2;
        var_8h = CONCAT71(var_8h._1_7_, 1);
    } else {
        var_8h = var_8h & 0xffffffffffffff00;
        if (*(int32_t *)(arg1 + 0x80) == 0x126) {
            fcn.1800f0350(arg1);
            uVar10 = 1;
        } else {
            uVar10 = func_0x0001800ef2a0(arg1, 0x126, 0x180643e68);
        }
        iVar11 = fcn.1800e9350(arg1, 0, in_stack_00000140);
    }
    uVar7 = *(undefined4 *)(iVar11 + 0x14);
    uVar8 = *(undefined4 *)(iVar11 + 0x18);
    ppiVar14 = *(int64_t ***)(arg1 + 0xd8);
    iVar3 = (int64_t)*ppiVar14;
    if (iVar3 == 0) {
code_r0x0001800ec954:
        piVar12 = (int64_t *)func_0x000180459890(0x2008);
        *piVar12 = (int64_t)*ppiVar14;
        piVar15 = piVar12 + 1;
        *ppiVar14 = piVar12;
        piVar12 = (int64_t *)0x48;
    } else {
        piVar15 = (int64_t *)((int64_t)ppiVar14[1] + iVar3 + 0xf & 0xfffffffffffffff8);
        if ((int64_t *)(iVar3 + 0x2008) < piVar15 + 9) goto code_r0x0001800ec954;
        piVar12 = (int64_t *)((int64_t)piVar15 + (0x48 - (iVar3 + 8)));
    }
    ppiVar14[1] = piVar12;
    *(undefined4 *)(piVar15 + 1) = *(undefined4 *)0x18078270c;
    *piVar15 = 0x180641cd0;
    piVar15[4] = var_10h;
    piVar15[6] = var_18h;
    *(undefined4 *)((int64_t)piVar15 + 0xc) = uVar5;
    *(undefined4 *)(piVar15 + 2) = uVar6;
    *(undefined4 *)((int64_t)piVar15 + 0x14) = uVar7;
    *(undefined4 *)(piVar15 + 3) = uVar8;
    *(char *)(piVar15 + 5) = cVar9;
    *(undefined *)(piVar15 + 7) = uVar10;
    piVar15[8] = iVar11;
    if (*(char *)(arg1 + 0x58) == '\0') {
        return piVar15;
    }
    ppiVar14 = *(int64_t ***)(arg1 + 0xd8);
    iVar11 = (int64_t)*ppiVar14;
    if (iVar11 != 0) {
        piVar12 = (int64_t *)((int64_t)ppiVar14[1] + iVar11 + 0xf & 0xfffffffffffffff8);
        if (piVar12 + 3 <= (int64_t *)(iVar11 + 0x2008U)) {
            piVar13 = (int64_t *)((int64_t)piVar12 + (0x18 - (iVar11 + 8)));
            goto code_r0x0001800eca20;
        }
    }
    piVar13 = (int64_t *)func_0x000180459890(0x2008);
    *piVar13 = (int64_t)*ppiVar14;
    piVar12 = piVar13 + 1;
    *ppiVar14 = piVar13;
    piVar13 = (int64_t *)0x18;
code_r0x0001800eca20:
    ppiVar14[1] = piVar13;
    uVar5 = *(undefined4 *)0x180782a58;
    *(undefined8 *)((int64_t)piVar12 + 0xc) = uStackX_20;
    *(undefined4 *)piVar12 = uVar5;
    *(undefined *)((int64_t)piVar12 + 0x14) = (undefined)var_8h;
    *(undefined8 *)((int64_t)piVar12 + 4) = uVar16;
    var_8h = (int64_t)piVar15;
    ppiVar14 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_8h);
    *ppiVar14 = piVar12;
    return piVar15;
}

// ============================================================
// Function: FUN_1800ec842
// Address: 0x1800ec842
// Size: 172 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f0h

int64_t * fcn.1800ec7c0(int64_t arg1)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    char cVar9;
    undefined uVar10;
    int64_t iVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    int64_t **ppiVar14;
    int64_t *piVar15;
    undefined8 uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStackX_20;
    int64_t in_stack_00000140;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar5 = *(undefined4 *)(arg1 + 0x84);
    uVar6 = *(undefined4 *)(arg1 + 0x88);
    fcn.1800f0350();
    var_10h = fcn.1800e9350(arg1, 0, in_stack_00000140);
    if (*(int32_t *)(arg1 + 0x80) == 0x134) {
        fcn.1800f0350(arg1);
        cVar9 = '\x01';
code_r0x0001800ec834:
        uVar16 = *(undefined8 *)(arg1 + 0xa0);
    } else {
        cVar9 = func_0x0001800ef2a0(arg1, 0x134, 0x180643e68);
        if (cVar9 != '\0') goto code_r0x0001800ec834;
        var_8h = -1;
        uVar16 = 0xffffffffffffffff;
    }
    var_18h = fcn.1800e9350(arg1, 0, in_stack_00000140);
    uStackX_20 = *(undefined8 *)(arg1 + 0x84);
    if (*(int32_t *)(arg1 + 0x80) == 0x127) {
        iVar2 = *(int32_t *)(arg1 + 0x114);
        uVar1 = iVar2 + 1;
        *(uint32_t *)(arg1 + 0x114) = uVar1;
        if (*(uint32_t *)0x180778500 < uVar1) {
            iVar11 = func_0x0001800d90d0(arg1 + 0x60);
            func_0x0001800d9940(iVar11 + 4, 0x180644050, 0x180643b50);
            pcVar4 = (code *)swi(3);
            piVar15 = (int64_t *)(*pcVar4)();
            return piVar15;
        }
        uVar10 = 1;
        iVar11 = fcn.1800ec7c0(arg1);
        *(int32_t *)(arg1 + 0x114) = iVar2;
        var_8h = CONCAT71(var_8h._1_7_, 1);
    } else {
        var_8h = var_8h & 0xffffffffffffff00;
        if (*(int32_t *)(arg1 + 0x80) == 0x126) {
            fcn.1800f0350(arg1);
            uVar10 = 1;
        } else {
            uVar10 = func_0x0001800ef2a0(arg1, 0x126, 0x180643e68);
        }
        iVar11 = fcn.1800e9350(arg1, 0, in_stack_00000140);
    }
    uVar7 = *(undefined4 *)(iVar11 + 0x14);
    uVar8 = *(undefined4 *)(iVar11 + 0x18);
    ppiVar14 = *(int64_t ***)(arg1 + 0xd8);
    iVar3 = (int64_t)*ppiVar14;
    if (iVar3 == 0) {
code_r0x0001800ec954:
        piVar12 = (int64_t *)func_0x000180459890(0x2008);
        *piVar12 = (int64_t)*ppiVar14;
        piVar15 = piVar12 + 1;
        *ppiVar14 = piVar12;
        piVar12 = (int64_t *)0x48;
    } else {
        piVar15 = (int64_t *)((int64_t)ppiVar14[1] + iVar3 + 0xf & 0xfffffffffffffff8);
        if ((int64_t *)(iVar3 + 0x2008) < piVar15 + 9) goto code_r0x0001800ec954;
        piVar12 = (int64_t *)((int64_t)piVar15 + (0x48 - (iVar3 + 8)));
    }
    ppiVar14[1] = piVar12;
    *(undefined4 *)(piVar15 + 1) = *(undefined4 *)0x18078270c;
    *piVar15 = 0x180641cd0;
    piVar15[4] = var_10h;
    piVar15[6] = var_18h;
    *(undefined4 *)((int64_t)piVar15 + 0xc) = uVar5;
    *(undefined4 *)(piVar15 + 2) = uVar6;
    *(undefined4 *)((int64_t)piVar15 + 0x14) = uVar7;
    *(undefined4 *)(piVar15 + 3) = uVar8;
    *(char *)(piVar15 + 5) = cVar9;
    *(undefined *)(piVar15 + 7) = uVar10;
    piVar15[8] = iVar11;
    if (*(char *)(arg1 + 0x58) == '\0') {
        return piVar15;
    }
    ppiVar14 = *(int64_t ***)(arg1 + 0xd8);
    iVar11 = (int64_t)*ppiVar14;
    if (iVar11 != 0) {
        piVar12 = (int64_t *)((int64_t)ppiVar14[1] + iVar11 + 0xf & 0xfffffffffffffff8);
        if (piVar12 + 3 <= (int64_t *)(iVar11 + 0x2008U)) {
            piVar13 = (int64_t *)((int64_t)piVar12 + (0x18 - (iVar11 + 8)));
            goto code_r0x0001800eca20;
        }
    }
    piVar13 = (int64_t *)func_0x000180459890(0x2008);
    *piVar13 = (int64_t)*ppiVar14;
    piVar12 = piVar13 + 1;
    *ppiVar14 = piVar13;
    piVar13 = (int64_t *)0x18;
code_r0x0001800eca20:
    ppiVar14[1] = piVar13;
    uVar5 = *(undefined4 *)0x180782a58;
    *(undefined8 *)((int64_t)piVar12 + 0xc) = uStackX_20;
    *(undefined4 *)piVar12 = uVar5;
    *(undefined *)((int64_t)piVar12 + 0x14) = (undefined)var_8h;
    *(undefined8 *)((int64_t)piVar12 + 4) = uVar16;
    var_8h = (int64_t)piVar15;
    ppiVar14 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_8h);
    *ppiVar14 = piVar12;
    return piVar15;
}

// ============================================================
// Function: FUN_1800ec8ee
// Address: 0x1800ec8ee
// Size: 216 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f0h

int64_t * fcn.1800ec7c0(int64_t arg1)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    char cVar9;
    undefined uVar10;
    int64_t iVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    int64_t **ppiVar14;
    int64_t *piVar15;
    undefined8 uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStackX_20;
    int64_t in_stack_00000140;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar5 = *(undefined4 *)(arg1 + 0x84);
    uVar6 = *(undefined4 *)(arg1 + 0x88);
    fcn.1800f0350();
    var_10h = fcn.1800e9350(arg1, 0, in_stack_00000140);
    if (*(int32_t *)(arg1 + 0x80) == 0x134) {
        fcn.1800f0350(arg1);
        cVar9 = '\x01';
code_r0x0001800ec834:
        uVar16 = *(undefined8 *)(arg1 + 0xa0);
    } else {
        cVar9 = func_0x0001800ef2a0(arg1, 0x134, 0x180643e68);
        if (cVar9 != '\0') goto code_r0x0001800ec834;
        var_8h = -1;
        uVar16 = 0xffffffffffffffff;
    }
    var_18h = fcn.1800e9350(arg1, 0, in_stack_00000140);
    uStackX_20 = *(undefined8 *)(arg1 + 0x84);
    if (*(int32_t *)(arg1 + 0x80) == 0x127) {
        iVar2 = *(int32_t *)(arg1 + 0x114);
        uVar1 = iVar2 + 1;
        *(uint32_t *)(arg1 + 0x114) = uVar1;
        if (*(uint32_t *)0x180778500 < uVar1) {
            iVar11 = func_0x0001800d90d0(arg1 + 0x60);
            func_0x0001800d9940(iVar11 + 4, 0x180644050, 0x180643b50);
            pcVar4 = (code *)swi(3);
            piVar15 = (int64_t *)(*pcVar4)();
            return piVar15;
        }
        uVar10 = 1;
        iVar11 = fcn.1800ec7c0(arg1);
        *(int32_t *)(arg1 + 0x114) = iVar2;
        var_8h = CONCAT71(var_8h._1_7_, 1);
    } else {
        var_8h = var_8h & 0xffffffffffffff00;
        if (*(int32_t *)(arg1 + 0x80) == 0x126) {
            fcn.1800f0350(arg1);
            uVar10 = 1;
        } else {
            uVar10 = func_0x0001800ef2a0(arg1, 0x126, 0x180643e68);
        }
        iVar11 = fcn.1800e9350(arg1, 0, in_stack_00000140);
    }
    uVar7 = *(undefined4 *)(iVar11 + 0x14);
    uVar8 = *(undefined4 *)(iVar11 + 0x18);
    ppiVar14 = *(int64_t ***)(arg1 + 0xd8);
    iVar3 = (int64_t)*ppiVar14;
    if (iVar3 == 0) {
code_r0x0001800ec954:
        piVar12 = (int64_t *)func_0x000180459890(0x2008);
        *piVar12 = (int64_t)*ppiVar14;
        piVar15 = piVar12 + 1;
        *ppiVar14 = piVar12;
        piVar12 = (int64_t *)0x48;
    } else {
        piVar15 = (int64_t *)((int64_t)ppiVar14[1] + iVar3 + 0xf & 0xfffffffffffffff8);
        if ((int64_t *)(iVar3 + 0x2008) < piVar15 + 9) goto code_r0x0001800ec954;
        piVar12 = (int64_t *)((int64_t)piVar15 + (0x48 - (iVar3 + 8)));
    }
    ppiVar14[1] = piVar12;
    *(undefined4 *)(piVar15 + 1) = *(undefined4 *)0x18078270c;
    *piVar15 = 0x180641cd0;
    piVar15[4] = var_10h;
    piVar15[6] = var_18h;
    *(undefined4 *)((int64_t)piVar15 + 0xc) = uVar5;
    *(undefined4 *)(piVar15 + 2) = uVar6;
    *(undefined4 *)((int64_t)piVar15 + 0x14) = uVar7;
    *(undefined4 *)(piVar15 + 3) = uVar8;
    *(char *)(piVar15 + 5) = cVar9;
    *(undefined *)(piVar15 + 7) = uVar10;
    piVar15[8] = iVar11;
    if (*(char *)(arg1 + 0x58) == '\0') {
        return piVar15;
    }
    ppiVar14 = *(int64_t ***)(arg1 + 0xd8);
    iVar11 = (int64_t)*ppiVar14;
    if (iVar11 != 0) {
        piVar12 = (int64_t *)((int64_t)ppiVar14[1] + iVar11 + 0xf & 0xfffffffffffffff8);
        if (piVar12 + 3 <= (int64_t *)(iVar11 + 0x2008U)) {
            piVar13 = (int64_t *)((int64_t)piVar12 + (0x18 - (iVar11 + 8)));
            goto code_r0x0001800eca20;
        }
    }
    piVar13 = (int64_t *)func_0x000180459890(0x2008);
    *piVar13 = (int64_t)*ppiVar14;
    piVar12 = piVar13 + 1;
    *ppiVar14 = piVar13;
    piVar13 = (int64_t *)0x18;
code_r0x0001800eca20:
    ppiVar14[1] = piVar13;
    uVar5 = *(undefined4 *)0x180782a58;
    *(undefined8 *)((int64_t)piVar12 + 0xc) = uStackX_20;
    *(undefined4 *)piVar12 = uVar5;
    *(undefined *)((int64_t)piVar12 + 0x14) = (undefined)var_8h;
    *(undefined8 *)((int64_t)piVar12 + 4) = uVar16;
    var_8h = (int64_t)piVar15;
    ppiVar14 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_8h);
    *ppiVar14 = piVar12;
    return piVar15;
}

// ============================================================
// Function: FUN_1800ec9c6
// Address: 0x1800ec9c6
// Size: 192 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f0h

int64_t * fcn.1800ec7c0(int64_t arg1)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    char cVar9;
    undefined uVar10;
    int64_t iVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    int64_t **ppiVar14;
    int64_t *piVar15;
    undefined8 uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStackX_20;
    int64_t in_stack_00000140;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar5 = *(undefined4 *)(arg1 + 0x84);
    uVar6 = *(undefined4 *)(arg1 + 0x88);
    fcn.1800f0350();
    var_10h = fcn.1800e9350(arg1, 0, in_stack_00000140);
    if (*(int32_t *)(arg1 + 0x80) == 0x134) {
        fcn.1800f0350(arg1);
        cVar9 = '\x01';
code_r0x0001800ec834:
        uVar16 = *(undefined8 *)(arg1 + 0xa0);
    } else {
        cVar9 = func_0x0001800ef2a0(arg1, 0x134, 0x180643e68);
        if (cVar9 != '\0') goto code_r0x0001800ec834;
        var_8h = -1;
        uVar16 = 0xffffffffffffffff;
    }
    var_18h = fcn.1800e9350(arg1, 0, in_stack_00000140);
    uStackX_20 = *(undefined8 *)(arg1 + 0x84);
    if (*(int32_t *)(arg1 + 0x80) == 0x127) {
        iVar2 = *(int32_t *)(arg1 + 0x114);
        uVar1 = iVar2 + 1;
        *(uint32_t *)(arg1 + 0x114) = uVar1;
        if (*(uint32_t *)0x180778500 < uVar1) {
            iVar11 = func_0x0001800d90d0(arg1 + 0x60);
            func_0x0001800d9940(iVar11 + 4, 0x180644050, 0x180643b50);
            pcVar4 = (code *)swi(3);
            piVar15 = (int64_t *)(*pcVar4)();
            return piVar15;
        }
        uVar10 = 1;
        iVar11 = fcn.1800ec7c0(arg1);
        *(int32_t *)(arg1 + 0x114) = iVar2;
        var_8h = CONCAT71(var_8h._1_7_, 1);
    } else {
        var_8h = var_8h & 0xffffffffffffff00;
        if (*(int32_t *)(arg1 + 0x80) == 0x126) {
            fcn.1800f0350(arg1);
            uVar10 = 1;
        } else {
            uVar10 = func_0x0001800ef2a0(arg1, 0x126, 0x180643e68);
        }
        iVar11 = fcn.1800e9350(arg1, 0, in_stack_00000140);
    }
    uVar7 = *(undefined4 *)(iVar11 + 0x14);
    uVar8 = *(undefined4 *)(iVar11 + 0x18);
    ppiVar14 = *(int64_t ***)(arg1 + 0xd8);
    iVar3 = (int64_t)*ppiVar14;
    if (iVar3 == 0) {
code_r0x0001800ec954:
        piVar12 = (int64_t *)func_0x000180459890(0x2008);
        *piVar12 = (int64_t)*ppiVar14;
        piVar15 = piVar12 + 1;
        *ppiVar14 = piVar12;
        piVar12 = (int64_t *)0x48;
    } else {
        piVar15 = (int64_t *)((int64_t)ppiVar14[1] + iVar3 + 0xf & 0xfffffffffffffff8);
        if ((int64_t *)(iVar3 + 0x2008) < piVar15 + 9) goto code_r0x0001800ec954;
        piVar12 = (int64_t *)((int64_t)piVar15 + (0x48 - (iVar3 + 8)));
    }
    ppiVar14[1] = piVar12;
    *(undefined4 *)(piVar15 + 1) = *(undefined4 *)0x18078270c;
    *piVar15 = 0x180641cd0;
    piVar15[4] = var_10h;
    piVar15[6] = var_18h;
    *(undefined4 *)((int64_t)piVar15 + 0xc) = uVar5;
    *(undefined4 *)(piVar15 + 2) = uVar6;
    *(undefined4 *)((int64_t)piVar15 + 0x14) = uVar7;
    *(undefined4 *)(piVar15 + 3) = uVar8;
    *(char *)(piVar15 + 5) = cVar9;
    *(undefined *)(piVar15 + 7) = uVar10;
    piVar15[8] = iVar11;
    if (*(char *)(arg1 + 0x58) == '\0') {
        return piVar15;
    }
    ppiVar14 = *(int64_t ***)(arg1 + 0xd8);
    iVar11 = (int64_t)*ppiVar14;
    if (iVar11 != 0) {
        piVar12 = (int64_t *)((int64_t)ppiVar14[1] + iVar11 + 0xf & 0xfffffffffffffff8);
        if (piVar12 + 3 <= (int64_t *)(iVar11 + 0x2008U)) {
            piVar13 = (int64_t *)((int64_t)piVar12 + (0x18 - (iVar11 + 8)));
            goto code_r0x0001800eca20;
        }
    }
    piVar13 = (int64_t *)func_0x000180459890(0x2008);
    *piVar13 = (int64_t)*ppiVar14;
    piVar12 = piVar13 + 1;
    *ppiVar14 = piVar13;
    piVar13 = (int64_t *)0x18;
code_r0x0001800eca20:
    ppiVar14[1] = piVar13;
    uVar5 = *(undefined4 *)0x180782a58;
    *(undefined8 *)((int64_t)piVar12 + 0xc) = uStackX_20;
    *(undefined4 *)piVar12 = uVar5;
    *(undefined *)((int64_t)piVar12 + 0x14) = (undefined)var_8h;
    *(undefined8 *)((int64_t)piVar12 + 4) = uVar16;
    var_8h = (int64_t)piVar15;
    ppiVar14 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_8h);
    *ppiVar14 = piVar12;
    return piVar15;
}

// ============================================================
// Function: FUN_1800eca86
// Address: 0x1800eca86
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f0h

int64_t * fcn.1800ec7c0(int64_t arg1)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    char cVar9;
    undefined uVar10;
    int64_t iVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    int64_t **ppiVar14;
    int64_t *piVar15;
    undefined8 uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStackX_20;
    int64_t in_stack_00000140;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar5 = *(undefined4 *)(arg1 + 0x84);
    uVar6 = *(undefined4 *)(arg1 + 0x88);
    fcn.1800f0350();
    var_10h = fcn.1800e9350(arg1, 0, in_stack_00000140);
    if (*(int32_t *)(arg1 + 0x80) == 0x134) {
        fcn.1800f0350(arg1);
        cVar9 = '\x01';
code_r0x0001800ec834:
        uVar16 = *(undefined8 *)(arg1 + 0xa0);
    } else {
        cVar9 = func_0x0001800ef2a0(arg1, 0x134, 0x180643e68);
        if (cVar9 != '\0') goto code_r0x0001800ec834;
        var_8h = -1;
        uVar16 = 0xffffffffffffffff;
    }
    var_18h = fcn.1800e9350(arg1, 0, in_stack_00000140);
    uStackX_20 = *(undefined8 *)(arg1 + 0x84);
    if (*(int32_t *)(arg1 + 0x80) == 0x127) {
        iVar2 = *(int32_t *)(arg1 + 0x114);
        uVar1 = iVar2 + 1;
        *(uint32_t *)(arg1 + 0x114) = uVar1;
        if (*(uint32_t *)0x180778500 < uVar1) {
            iVar11 = func_0x0001800d90d0(arg1 + 0x60);
            func_0x0001800d9940(iVar11 + 4, 0x180644050, 0x180643b50);
            pcVar4 = (code *)swi(3);
            piVar15 = (int64_t *)(*pcVar4)();
            return piVar15;
        }
        uVar10 = 1;
        iVar11 = fcn.1800ec7c0(arg1);
        *(int32_t *)(arg1 + 0x114) = iVar2;
        var_8h = CONCAT71(var_8h._1_7_, 1);
    } else {
        var_8h = var_8h & 0xffffffffffffff00;
        if (*(int32_t *)(arg1 + 0x80) == 0x126) {
            fcn.1800f0350(arg1);
            uVar10 = 1;
        } else {
            uVar10 = func_0x0001800ef2a0(arg1, 0x126, 0x180643e68);
        }
        iVar11 = fcn.1800e9350(arg1, 0, in_stack_00000140);
    }
    uVar7 = *(undefined4 *)(iVar11 + 0x14);
    uVar8 = *(undefined4 *)(iVar11 + 0x18);
    ppiVar14 = *(int64_t ***)(arg1 + 0xd8);
    iVar3 = (int64_t)*ppiVar14;
    if (iVar3 == 0) {
code_r0x0001800ec954:
        piVar12 = (int64_t *)func_0x000180459890(0x2008);
        *piVar12 = (int64_t)*ppiVar14;
        piVar15 = piVar12 + 1;
        *ppiVar14 = piVar12;
        piVar12 = (int64_t *)0x48;
    } else {
        piVar15 = (int64_t *)((int64_t)ppiVar14[1] + iVar3 + 0xf & 0xfffffffffffffff8);
        if ((int64_t *)(iVar3 + 0x2008) < piVar15 + 9) goto code_r0x0001800ec954;
        piVar12 = (int64_t *)((int64_t)piVar15 + (0x48 - (iVar3 + 8)));
    }
    ppiVar14[1] = piVar12;
    *(undefined4 *)(piVar15 + 1) = *(undefined4 *)0x18078270c;
    *piVar15 = 0x180641cd0;
    piVar15[4] = var_10h;
    piVar15[6] = var_18h;
    *(undefined4 *)((int64_t)piVar15 + 0xc) = uVar5;
    *(undefined4 *)(piVar15 + 2) = uVar6;
    *(undefined4 *)((int64_t)piVar15 + 0x14) = uVar7;
    *(undefined4 *)(piVar15 + 3) = uVar8;
    *(char *)(piVar15 + 5) = cVar9;
    *(undefined *)(piVar15 + 7) = uVar10;
    piVar15[8] = iVar11;
    if (*(char *)(arg1 + 0x58) == '\0') {
        return piVar15;
    }
    ppiVar14 = *(int64_t ***)(arg1 + 0xd8);
    iVar11 = (int64_t)*ppiVar14;
    if (iVar11 != 0) {
        piVar12 = (int64_t *)((int64_t)ppiVar14[1] + iVar11 + 0xf & 0xfffffffffffffff8);
        if (piVar12 + 3 <= (int64_t *)(iVar11 + 0x2008U)) {
            piVar13 = (int64_t *)((int64_t)piVar12 + (0x18 - (iVar11 + 8)));
            goto code_r0x0001800eca20;
        }
    }
    piVar13 = (int64_t *)func_0x000180459890(0x2008);
    *piVar13 = (int64_t)*ppiVar14;
    piVar12 = piVar13 + 1;
    *ppiVar14 = piVar13;
    piVar13 = (int64_t *)0x18;
code_r0x0001800eca20:
    ppiVar14[1] = piVar13;
    uVar5 = *(undefined4 *)0x180782a58;
    *(undefined8 *)((int64_t)piVar12 + 0xc) = uStackX_20;
    *(undefined4 *)piVar12 = uVar5;
    *(undefined *)((int64_t)piVar12 + 0x14) = (undefined)var_8h;
    *(undefined8 *)((int64_t)piVar12 + 4) = uVar16;
    var_8h = (int64_t)piVar15;
    ppiVar14 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_8h);
    *ppiVar14 = piVar12;
    return piVar15;
}

// ============================================================
// Function: FUN_1800ecab0
// Address: 0x1800ecab0
// Size: 111 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

int64_t fcn.1800ecab0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_38h;
    int64_t var_30h;
    int64_t in_stack_ffffffffffffffd8;
    int64_t var_18h;
    
    if (*(int32_t *)(arg1 + 0x80) != 0x119) {
        fcn.1800efe90(in_stack_ffffffffffffffd8);
        *(undefined *)(arg2 + 0x18) = 0;
        return arg2;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x98);
    uVar2 = *(undefined8 *)(arg1 + 0x84);
    uVar3 = *(undefined8 *)(arg1 + 0x8c);
    fcn.1800f0350();
    var_38h._0_4_ = (undefined4)uVar1;
    var_38h._4_4_ = (undefined4)((uint64_t)uVar1 >> 0x20);
    var_30h._0_4_ = (undefined4)uVar2;
    var_30h._4_4_ = (undefined4)((uint64_t)uVar2 >> 0x20);
    *(undefined *)(arg2 + 0x18) = 1;
    *(undefined4 *)arg2 = (undefined4)var_38h;
    *(undefined4 *)(arg2 + 4) = var_38h._4_4_;
    *(undefined4 *)(arg2 + 8) = (undefined4)var_30h;
    *(undefined4 *)(arg2 + 0xc) = var_30h._4_4_;
    *(undefined8 *)(arg2 + 0x10) = uVar3;
    return arg2;
}

// ============================================================
// Function: FUN_1800ecb20
// Address: 0x1800ecb20
// Size: 161 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

int64_t fcn.1800ecb20(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t var_8h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t in_stack_ffffffffffffffd8;
    int64_t var_18h;
    
    if (*(int32_t *)(arg1 + 0x80) != 0x119) {
        fcn.1800efe90(in_stack_ffffffffffffffd8);
        uVar4 = *(undefined4 *)(arg1 + 0x84);
        uVar5 = *(undefined4 *)(arg1 + 0x88);
        *(undefined8 *)arg2 = *(undefined8 *)(arg1 + 0x128);
        *(undefined4 *)(arg2 + 8) = uVar4;
        *(undefined4 *)(arg2 + 0xc) = uVar5;
        *(undefined4 *)(arg2 + 0x10) = uVar4;
        *(undefined4 *)(arg2 + 0x14) = uVar5;
        return arg2;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x98);
    uVar2 = *(undefined8 *)(arg1 + 0x84);
    uVar3 = *(undefined8 *)(arg1 + 0x8c);
    fcn.1800f0350();
    var_38h._0_4_ = (undefined4)uVar1;
    var_38h._4_4_ = (undefined4)((uint64_t)uVar1 >> 0x20);
    var_30h._0_4_ = (undefined4)uVar2;
    var_30h._4_4_ = (undefined4)((uint64_t)uVar2 >> 0x20);
    *(undefined4 *)arg2 = (undefined4)var_38h;
    *(undefined4 *)(arg2 + 4) = var_38h._4_4_;
    *(undefined4 *)(arg2 + 8) = (undefined4)var_30h;
    *(undefined4 *)(arg2 + 0xc) = var_30h._4_4_;
    *(undefined8 *)(arg2 + 0x10) = uVar3;
    return arg2;
}

