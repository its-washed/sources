// Chunk 119 - 50 functions

// ============================================================
// Function: FUN_180199150
// Address: 0x180199150
// Size: 1022 bytes
// ============================================================
uint64_t fcn.180199150(int64_t arg1, int64_t arg_60h)
{
    int32_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t in_RDX;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    var_40h = 0x180199172;
    iVar5 = arg1;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    uVar6 = 0;
    var_48h = 0;
    var_20h = 0;
    iVar8 = 0;
    var_18h._0_4_ = 0;
    var_58h = 0;
    var_50h = 0;
    if ((iVar5 == 0) || (in_RDX == 0)) {
        *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x1801994aa;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x1801994c2;
        func_0x0001802295a0(0x1804a9818, 0x36c, 0x1804a9928);
        uVar4 = 0xc0102;
    } else {
        *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x1801991aa;
        uVar4 = func_0x00018023faa0();
        *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x1801991b2;
        iVar8 = func_0x00018021a7c0(uVar4);
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x1801991bf;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x1801991d7;
            func_0x0001802295a0(0x1804a9818, 0x372, 0x1804a9928);
            uVar4 = 0x80007;
        } else {
            *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x1801991f7;
            iVar1 = func_0x000180219d10(iVar8, 0x6c, 3, in_RDX);
            if (iVar1 < 1) {
                *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x180199200;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x180199218;
                func_0x0001802295a0(0x1804a9818, 0x376, 0x1804a9928);
                uVar4 = 0x80002;
            } else {
                var_40h = 0;
                *(int64_t **)(&stack0xffffffffffffffe8 + iVar3) = &var_18h;
                *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x180199243;
                iVar1 = func_0x0001802416c0(iVar8, &var_58h, &var_50h, &var_20h);
                uVar11 = uVar6;
                if (iVar1 != 0) {
                    do {
                        iVar5 = var_58h;
                        *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x18019925d;
                        uVar2 = func_0x000180498cd0(var_58h);
                        if (uVar2 < 0xf) {
                            *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x18019947a;
                            func_0x000180229480();
                            uVar4 = 0x38c;
code_r0x00018019945b:
                            *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x18019946e;
                            func_0x0001802295a0(0x1804a9818, uVar4, 0x1804a9928);
                            uVar4 = 0x188;
                            goto code_r0x0001801994c7;
                        }
                        *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x18019927e;
                        iVar1 = func_0x000180498f90(iVar5, 0x1804a9948, 0xf);
                        if (iVar1 != 0) {
                            if (uVar2 < 0x11) {
                                *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x180199456;
                                func_0x000180229480();
                                uVar4 = 0x393;
                                goto code_r0x00018019945b;
                            }
                            *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x1801992ed;
                            iVar1 = func_0x000180498f90(var_58h, 0x1804a9958, 0x11);
                            if (iVar1 == 0) {
                                iVar1 = 2;
                                if ((7 < (int32_t)var_18h) &&
                                   ((uint32_t)*(uint8_t *)(var_20h + 6) * 0x100 + (uint32_t)*(uint8_t *)(var_20h + 7) ==
                                    (int32_t)var_18h + -8)) goto code_r0x000180199322;
                                *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x180199423;
                                func_0x000180229480();
                                uVar4 = 0x3ac;
code_r0x0001801992b1:
                                *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x1801992c4;
                                func_0x0001802295a0(0x1804a9818, uVar4, 0x1804a9928);
                                uVar4 = 0x186;
                            } else {
                                *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x180199432;
                                func_0x000180229480();
                                *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x18019944a;
                                func_0x0001802295a0(0x1804a9818, 0x397, 0x1804a9928);
                                uVar4 = 0x187;
                            }
                            goto code_r0x0001801994c7;
                        }
                        iVar1 = 1;
                        if (((int32_t)var_18h < 4) ||
                           ((uint32_t)*(uint8_t *)(var_20h + 2) * 0x100 + (uint32_t)*(uint8_t *)(var_20h + 3) !=
                            (int32_t)var_18h + -4)) {
                            *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x1801992ac;
                            func_0x000180229480();
                            uVar4 = 0x3a4;
                            goto code_r0x0001801992b1;
                        }
code_r0x000180199322:
                        uVar9 = uVar6;
                        if (iVar1 == 1) {
                            uVar9 = 4;
                        }
                        uVar7 = (int64_t)(int32_t)var_18h + uVar9 + uVar11;
                        *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x18019934e;
                        iVar5 = func_0x0001802249c0(var_48h, uVar7, 0x1804a9818, 0x3b2);
                        if (iVar5 == 0) goto code_r0x0001801994d4;
                        if (iVar1 == 1) {
                            *(undefined4 *)(iVar5 + uVar11) = 0xd0010000;
                        }
                        *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x18019937d;
                        var_48h = iVar5;
                        func_0x000180498030(uVar9 + (int64_t)(undefined4 *)(iVar5 + uVar11), var_20h, 
                                            (int64_t)(int32_t)var_18h);
                        *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x180199396;
                        func_0x000180224990(var_58h, 0x1804a9818, 0x3ba);
                        var_58h = 0;
                        *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x1801993b0;
                        func_0x000180224990(var_50h, 0x1804a9818, 0x3bc);
                        var_50h = 0;
                        *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x1801993ca;
                        func_0x000180224990(var_20h, 0x1804a9818, 0x3be);
                        iVar10 = var_40h + 1;
                        var_20h = 0;
                        *(int64_t **)(&stack0xffffffffffffffe8 + iVar3) = &var_18h;
                        var_40h = iVar10;
                        *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x1801993f6;
                        iVar1 = func_0x0001802416c0(iVar8, &var_58h, &var_50h, &var_20h);
                        uVar11 = uVar7;
                    } while (iVar1 != 0);
                    if (iVar10 != 0) {
                        *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x180199417;
                        uVar2 = func_0x000180198f40(arg1, 2, iVar5, uVar7);
                        uVar6 = (uint64_t)uVar2;
                        goto code_r0x0001801994d4;
                    }
                }
                *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x180199486;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x18019949e;
                func_0x0001802295a0(0x1804a9818, 900, 0x1804a9928);
                uVar4 = 0x185;
            }
        }
    }
code_r0x0001801994c7:
    *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x1801994d4;
    func_0x0001802296d0(0x14, uVar4, 0);
code_r0x0001801994d4:
    *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x1801994ea;
    func_0x000180224990(var_58h, 0x1804a9818, 0x3c6);
    *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x180199500;
    func_0x000180224990(var_50h, 0x1804a9818, 0x3c7);
    *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x180199516;
    func_0x000180224990(var_20h, 0x1804a9818, 0x3c8);
    *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x18019952c;
    func_0x000180224990(var_48h, 0x1804a9818, 0x3c9);
    *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x180199534;
    func_0x000180219f80(iVar8);
    return uVar6;
}

// ============================================================
// Function: FUN_180199550
// Address: 0x180199550
// Size: 133 bytes
// ============================================================
undefined8 fcn.180199550(int64_t arg_28h, int64_t arg_48h, int64_t arg_60h, int64_t arg_90h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t *in_RCX;
    int64_t *piVar6;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18019955c;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019957c;
        in_RCX = (int32_t *)func_0x0001801bda50(in_RCX);
        if (in_RCX == (int32_t *)0x0) {
            return 0;
        }
    }
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019958b;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801995a3;
        func_0x0001802295a0(0x1804a9818, 0xa3, 0x1804a9838);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801995b5;
        func_0x0001802296d0(0x14, 0xc0102, 0);
        return 0;
    }
    uVar1 = *(undefined8 *)(in_RCX + 2);
    piVar6 = *(int64_t **)(in_RCX + 0x21e);
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8);
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3) = 0x180199e90;
    iVar4 = func_0x00018045a350(piVar6, in_RDX, uVar1);
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar3) = 0x180199ea6;
    iVar5 = func_0x0001801a2080(in_RDX, (int64_t)&arg_60h + iVar4 + iVar3);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar3) = 0x180199eb0;
        func_0x000180229480();
        *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar3) = 0x180199ec8;
        func_0x0001802295a0(0x1804a9818, 0x8a, 0x1804a9828);
        *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar3) = 0x180199eda;
        func_0x0001802296d0(0x14, 0xf7, 0);
    } else {
        iVar5 = *(int64_t *)(piVar6[4] + *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3) * 0x28);
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar3) = 0x180199f05;
            iVar2 = func_0x000180238100(iVar5, in_RDX);
            if (iVar2 == 0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar3) = 0x180199f11;
        iVar2 = func_0x0001802308d0(in_RDX);
        if (iVar2 != 0) {
            uVar1 = *(undefined8 *)(piVar6[4] + 8 + *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3) * 0x28);
            *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar3) = 0x180199f2c;
            func_0x00018022ecc0(uVar1);
            *(int64_t *)(piVar6[4] + 8 + *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3) * 0x28) = in_RDX;
            *piVar6 = piVar6[4] + *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3) * 0x28;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801995e0
// Address: 0x1801995e0
// Size: 548 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1801995e0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    uint32_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int32_t *piVar8;
    int64_t iVar9;
    int32_t *in_RCX;
    int64_t in_RDX;
    undefined8 uVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180199600;
    iVar6 = func_0x00018045a350();
    iVar6 = -iVar6;
    uVar11 = 0;
    uVar12 = uVar11;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18019961a;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180199632;
        func_0x0001802295a0(0x1804a9818, 0xb1, 0x1804a9850);
        uVar10 = 0xc0102;
        uVar7 = uVar11;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180199641;
        uVar10 = func_0x00018023faa0();
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180199649;
        uVar7 = func_0x00018021a7c0(uVar10);
        if (uVar7 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180199656;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18019966e;
            func_0x0001802295a0(0x1804a9818, 0xb7, 0x1804a9850);
            uVar10 = 0x80007;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18019968e;
            iVar4 = func_0x000180219d10(uVar7, 0x6c, 3, in_RDX);
            if (iVar4 < 1) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180199697;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801996af;
                func_0x0001802295a0(0x1804a9818, 0xbc, 0x1804a9850);
                uVar10 = 0x80002;
            } else {
                if (in_R8D == 1) {
                    if (in_RCX == (int32_t *)0x0) goto code_r0x0001801997df;
                    piVar8 = in_RCX;
                    if (*in_RCX != 0) {
                        if (-1 < (char)*in_RCX) goto code_r0x0001801997df;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801996e2;
                        piVar8 = (int32_t *)func_0x0001801bda50(in_RCX);
                        uVar12 = 0;
                        if (piVar8 == (int32_t *)0x0) goto code_r0x0001801997df;
                    }
                    puVar1 = *(undefined8 **)(in_RCX + 2);
                    uVar2 = *(undefined8 *)(piVar8 + 0x546);
                    uVar10 = 0x80009;
                    uVar3 = *(undefined8 *)(piVar8 + 0x544);
                    *(undefined8 *)((int64_t)&var_20h + iVar6) = puVar1[0x8c];
                    *(undefined8 *)((int64_t)&var_18h + iVar6) = *puVar1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180199724;
                    iVar9 = func_0x000180242cd0(uVar7, 0, uVar3, uVar2);
                } else {
                    if (in_R8D != 2) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801997b5;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801997cd;
                        func_0x0001802295a0(0x1804a9818, 0xd0, 0x1804a9850);
                        uVar10 = 0x7c;
                        goto code_r0x0001801997d2;
                    }
                    uVar10 = 0x8000d;
                    uVar2 = (*(undefined8 **)(in_RCX + 2))[0x8c];
                    uVar3 = **(undefined8 **)(in_RCX + 2);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18019974d;
                    iVar9 = func_0x000180240690(uVar7, 0, uVar3, uVar2);
                }
                if (iVar9 != 0) {
                    if (*in_RCX == 0) {
code_r0x000180199791:
                        uVar10 = *(undefined8 *)(in_RCX + 2);
                        uVar2 = *(undefined8 *)(in_RCX + 0x21e);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801997a4;
                        uVar5 = func_0x000180199e80(uVar2, iVar9, uVar10);
                        uVar11 = (uint64_t)uVar5;
                    } else if ((char)*in_RCX < '\0') {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180199789;
                        in_RCX = (int32_t *)func_0x0001801bda50(in_RCX);
                        if (in_RCX != (int32_t *)0x0) goto code_r0x000180199791;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801997ae;
                    func_0x00018022ecc0(iVar9);
                    uVar12 = uVar11;
                    goto code_r0x0001801997df;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18019975a;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180199772;
                func_0x0001802295a0(0x1804a9818, 0xd4, 0x1804a9850);
            }
        }
    }
code_r0x0001801997d2:
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801997df;
    func_0x0001802296d0(0x14, uVar10, 0);
    uVar12 = uVar11;
code_r0x0001801997df:
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801997e7;
    func_0x000180219f80(uVar7);
    return uVar12;
}

// ============================================================
// Function: FUN_180199810
// Address: 0x180199810
// Size: 121 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8
fcn.180199810(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
             int64_t arg_70h, int64_t arg_a0h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t *in_RCX;
    int64_t *piVar7;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180199820;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019983d;
        in_RCX = (int32_t *)func_0x0001801bda50();
        if (in_RCX == (int32_t *)0x0) {
            return 0;
        }
    }
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019984f;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180199867;
        func_0x0001802295a0(0x1804a9818, 0x29, 0x1804a9800);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180199879;
        func_0x0001802296d0(0x14, 0xc0102, 0);
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined4 *)((int64_t)&uStackX_20 + iVar3 + -8) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801998a3;
    iVar2 = func_0x0001801a8d20(in_RCX, 0, in_RDX, 0);
    if (iVar2 == 1) {
        uVar8 = *(undefined8 *)(in_RCX + 2);
        piVar7 = *(int64_t **)(in_RCX + 0x21e);
        uVar1 = *(undefined8 *)((int64_t)&arg_38h + iVar3);
        *(undefined8 *)((int64_t)&arg_38h + iVar3) = *(undefined8 *)((int64_t)&arg_40h + iVar3);
        *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_48h + iVar3) = uVar1;
        *(undefined8 *)(&stack0x00000028 + iVar3) = *(undefined8 *)(&stack0x00000028 + iVar3);
        *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x180199cba;
        iVar4 = func_0x00018045a350(piVar7, in_RDX, uVar8);
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199cce;
        iVar5 = func_0x000180238400(in_RDX);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199cdb;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199cf3;
            func_0x0001802295a0(0x1804a9818, 0x108, 0x1804a9880);
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d05;
            func_0x0001802296d0(0x14, 0x10c, 0);
        } else {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d1c;
            iVar6 = func_0x0001801a2080(iVar5, (int64_t)&arg_70h + iVar4 + iVar3, uVar8);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d26;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d3e;
                func_0x0001802295a0(0x1804a9818, 0x10d, 0x1804a9880);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d50;
                func_0x0001802296d0(0x14, 0xf7, 0);
                return 0;
            }
            iVar6 = *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3);
            if (iVar6 == 3) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d6a;
                iVar2 = func_0x00018022e600(iVar5);
                if (iVar2 == 0) {
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d73;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d8b;
                    func_0x0001802295a0(0x1804a9818, 0x112, 0x1804a9880);
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d9d;
                    func_0x0001802296d0(0x14, 0x13e, 0);
                    return 0;
                }
                iVar6 = *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3);
            }
            if (*(int64_t *)(piVar7[4] + 8 + iVar6 * 0x28) != 0) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199dc3;
                func_0x00018022e6c0(iVar5);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199dc8;
                func_0x0001802203d0();
                uVar8 = *(undefined8 *)(piVar7[4] + 8 + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199de2;
                iVar2 = func_0x000180238100(in_RDX, uVar8);
                if (iVar2 == 0) {
                    uVar8 = *(undefined8 *)(piVar7[4] + 8 + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28);
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199dfd;
                    func_0x00018022ecc0(uVar8);
                    *(undefined8 *)(piVar7[4] + 8 + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28) = 0;
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199e18;
                    func_0x0001802203d0();
                }
            }
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199e20;
            iVar2 = func_0x0001802375f0(in_RDX);
            if (iVar2 != 0) {
                uVar8 = *(undefined8 *)(piVar7[4] + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199e3e;
                func_0x00018021fe80(uVar8);
                *(int64_t *)(piVar7[4] + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28) = in_RDX;
                *piVar7 = piVar7[4] + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28;
                return 1;
            }
        }
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801998af;
    func_0x000180229480();
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801998c7;
    func_0x0001802295a0(0x1804a9818, 0x2f, 0x1804a9800);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801998d6;
    func_0x0001802296d0(0x14, iVar2, 0);
    return 0;
}

// ============================================================
// Function: FUN_180199889
// Address: 0x180199889
// Size: 95 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8
fcn.180199810(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
             int64_t arg_70h, int64_t arg_a0h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t *in_RCX;
    int64_t *piVar7;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180199820;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019983d;
        in_RCX = (int32_t *)func_0x0001801bda50();
        if (in_RCX == (int32_t *)0x0) {
            return 0;
        }
    }
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019984f;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180199867;
        func_0x0001802295a0(0x1804a9818, 0x29, 0x1804a9800);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180199879;
        func_0x0001802296d0(0x14, 0xc0102, 0);
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined4 *)((int64_t)&uStackX_20 + iVar3 + -8) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801998a3;
    iVar2 = func_0x0001801a8d20(in_RCX, 0, in_RDX, 0);
    if (iVar2 == 1) {
        uVar8 = *(undefined8 *)(in_RCX + 2);
        piVar7 = *(int64_t **)(in_RCX + 0x21e);
        uVar1 = *(undefined8 *)((int64_t)&arg_38h + iVar3);
        *(undefined8 *)((int64_t)&arg_38h + iVar3) = *(undefined8 *)((int64_t)&arg_40h + iVar3);
        *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_48h + iVar3) = uVar1;
        *(undefined8 *)(&stack0x00000028 + iVar3) = *(undefined8 *)(&stack0x00000028 + iVar3);
        *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x180199cba;
        iVar4 = func_0x00018045a350(piVar7, in_RDX, uVar8);
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199cce;
        iVar5 = func_0x000180238400(in_RDX);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199cdb;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199cf3;
            func_0x0001802295a0(0x1804a9818, 0x108, 0x1804a9880);
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d05;
            func_0x0001802296d0(0x14, 0x10c, 0);
        } else {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d1c;
            iVar6 = func_0x0001801a2080(iVar5, (int64_t)&arg_70h + iVar4 + iVar3, uVar8);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d26;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d3e;
                func_0x0001802295a0(0x1804a9818, 0x10d, 0x1804a9880);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d50;
                func_0x0001802296d0(0x14, 0xf7, 0);
                return 0;
            }
            iVar6 = *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3);
            if (iVar6 == 3) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d6a;
                iVar2 = func_0x00018022e600(iVar5);
                if (iVar2 == 0) {
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d73;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d8b;
                    func_0x0001802295a0(0x1804a9818, 0x112, 0x1804a9880);
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d9d;
                    func_0x0001802296d0(0x14, 0x13e, 0);
                    return 0;
                }
                iVar6 = *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3);
            }
            if (*(int64_t *)(piVar7[4] + 8 + iVar6 * 0x28) != 0) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199dc3;
                func_0x00018022e6c0(iVar5);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199dc8;
                func_0x0001802203d0();
                uVar8 = *(undefined8 *)(piVar7[4] + 8 + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199de2;
                iVar2 = func_0x000180238100(in_RDX, uVar8);
                if (iVar2 == 0) {
                    uVar8 = *(undefined8 *)(piVar7[4] + 8 + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28);
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199dfd;
                    func_0x00018022ecc0(uVar8);
                    *(undefined8 *)(piVar7[4] + 8 + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28) = 0;
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199e18;
                    func_0x0001802203d0();
                }
            }
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199e20;
            iVar2 = func_0x0001802375f0(in_RDX);
            if (iVar2 != 0) {
                uVar8 = *(undefined8 *)(piVar7[4] + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199e3e;
                func_0x00018021fe80(uVar8);
                *(int64_t *)(piVar7[4] + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28) = in_RDX;
                *piVar7 = piVar7[4] + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28;
                return 1;
            }
        }
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801998af;
    func_0x000180229480();
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801998c7;
    func_0x0001802295a0(0x1804a9818, 0x2f, 0x1804a9800);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801998d6;
    func_0x0001802296d0(0x14, iVar2, 0);
    return 0;
}

// ============================================================
// Function: FUN_1801998e8
// Address: 0x1801998e8
// Size: 34 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8
fcn.180199810(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
             int64_t arg_70h, int64_t arg_a0h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t *in_RCX;
    int64_t *piVar7;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180199820;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019983d;
        in_RCX = (int32_t *)func_0x0001801bda50();
        if (in_RCX == (int32_t *)0x0) {
            return 0;
        }
    }
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019984f;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180199867;
        func_0x0001802295a0(0x1804a9818, 0x29, 0x1804a9800);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180199879;
        func_0x0001802296d0(0x14, 0xc0102, 0);
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined4 *)((int64_t)&uStackX_20 + iVar3 + -8) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801998a3;
    iVar2 = func_0x0001801a8d20(in_RCX, 0, in_RDX, 0);
    if (iVar2 == 1) {
        uVar8 = *(undefined8 *)(in_RCX + 2);
        piVar7 = *(int64_t **)(in_RCX + 0x21e);
        uVar1 = *(undefined8 *)((int64_t)&arg_38h + iVar3);
        *(undefined8 *)((int64_t)&arg_38h + iVar3) = *(undefined8 *)((int64_t)&arg_40h + iVar3);
        *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_48h + iVar3) = uVar1;
        *(undefined8 *)(&stack0x00000028 + iVar3) = *(undefined8 *)(&stack0x00000028 + iVar3);
        *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x180199cba;
        iVar4 = func_0x00018045a350(piVar7, in_RDX, uVar8);
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199cce;
        iVar5 = func_0x000180238400(in_RDX);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199cdb;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199cf3;
            func_0x0001802295a0(0x1804a9818, 0x108, 0x1804a9880);
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d05;
            func_0x0001802296d0(0x14, 0x10c, 0);
        } else {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d1c;
            iVar6 = func_0x0001801a2080(iVar5, (int64_t)&arg_70h + iVar4 + iVar3, uVar8);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d26;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d3e;
                func_0x0001802295a0(0x1804a9818, 0x10d, 0x1804a9880);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d50;
                func_0x0001802296d0(0x14, 0xf7, 0);
                return 0;
            }
            iVar6 = *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3);
            if (iVar6 == 3) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d6a;
                iVar2 = func_0x00018022e600(iVar5);
                if (iVar2 == 0) {
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d73;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d8b;
                    func_0x0001802295a0(0x1804a9818, 0x112, 0x1804a9880);
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d9d;
                    func_0x0001802296d0(0x14, 0x13e, 0);
                    return 0;
                }
                iVar6 = *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3);
            }
            if (*(int64_t *)(piVar7[4] + 8 + iVar6 * 0x28) != 0) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199dc3;
                func_0x00018022e6c0(iVar5);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199dc8;
                func_0x0001802203d0();
                uVar8 = *(undefined8 *)(piVar7[4] + 8 + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199de2;
                iVar2 = func_0x000180238100(in_RDX, uVar8);
                if (iVar2 == 0) {
                    uVar8 = *(undefined8 *)(piVar7[4] + 8 + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28);
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199dfd;
                    func_0x00018022ecc0(uVar8);
                    *(undefined8 *)(piVar7[4] + 8 + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28) = 0;
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199e18;
                    func_0x0001802203d0();
                }
            }
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199e20;
            iVar2 = func_0x0001802375f0(in_RDX);
            if (iVar2 != 0) {
                uVar8 = *(undefined8 *)(piVar7[4] + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199e3e;
                func_0x00018021fe80(uVar8);
                *(int64_t *)(piVar7[4] + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28) = in_RDX;
                *piVar7 = piVar7[4] + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28;
                return 1;
            }
        }
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801998af;
    func_0x000180229480();
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801998c7;
    func_0x0001802295a0(0x1804a9818, 0x2f, 0x1804a9800);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801998d6;
    func_0x0001802296d0(0x14, iVar2, 0);
    return 0;
}

// ============================================================
// Function: FUN_180199910
// Address: 0x180199910
// Size: 30 bytes
// ============================================================
int32_t fcn.180199910(int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int32_t *in_RCX;
    undefined8 *puVar11;
    int64_t in_RDX;
    undefined8 uVar12;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int32_t iVar13;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 uVar14;
    undefined8 unaff_R14;
    undefined8 *puVar15;
    undefined8 unaff_R15;
    int64_t var_18h;
    undefined8 uStackX_20;
    undefined8 auStack_10 [2];
    
    auStack_10[1] = 0x18019991a;
    iVar5 = func_0x00018045a350();
    iVar5 = -iVar5;
    puVar11 = (undefined8 *)0x0;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + -8) = unaff_RBP;
    *(undefined8 *)(&stack0x00000010 + iVar5) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar5) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + -0x20) = unaff_R14;
    iVar10 = iVar5 + -8;
    *(undefined8 *)((int64_t)auStack_10 + iVar5 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStack_10 + iVar5) = 0x180199f83;
    iVar6 = func_0x00018045a350();
    iVar6 = -iVar6;
    iVar13 = 0;
    iVar8 = 0;
    *(undefined8 *)((int64_t)&arg_60h + iVar6 + iVar5) = 0;
    puVar15 = puVar11;
    if (in_RCX != (int32_t *)0x0) {
        puVar15 = *(undefined8 **)(in_RCX + 2);
    }
    *(undefined8 *)((int64_t)&arg_68h + iVar6 + iVar5) = unaff_R12;
    *(undefined8 *)((int64_t)&var_18h + iVar6 + iVar5) = unaff_R13;
    if (puVar11 == (undefined8 *)0x0) {
        if (in_RCX == (int32_t *)0x0) {
            return 0;
        }
        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x180199fbe;
        func_0x0001802203d0();
        if (*in_RCX == 0) {
            uVar12 = *(undefined8 *)(in_RCX + 0x544);
            uVar14 = *(undefined8 *)(in_RCX + 0x546);
        } else {
            if (-1 < (char)*in_RCX) {
                return 0;
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x180199fe3;
            iVar9 = func_0x0001801bda50(in_RCX);
            if (iVar9 == 0) {
                return 0;
            }
            uVar12 = *(undefined8 *)(iVar9 + 0x1510);
            uVar14 = *(undefined8 *)(iVar9 + 0x1518);
        }
    } else {
        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a004;
        func_0x0001802203d0();
        uVar12 = puVar11[0x17];
        uVar14 = puVar11[0x18];
    }
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a01c;
        func_0x000180229480();
        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a034;
        func_0x0001802295a0(0x1804a9818, 0x1ea, 0x1804a98e8);
        uVar12 = 0xc0102;
    } else {
        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a043;
        uVar7 = func_0x00018023faa0();
        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a04b;
        iVar8 = func_0x00018021a7c0(uVar7);
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a058;
            func_0x000180229480();
            *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a070;
            func_0x0001802295a0(0x1804a9818, 0x1f0, 0x1804a98e8);
            uVar12 = 0x80007;
        } else {
            *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a090;
            iVar2 = func_0x000180219d10(iVar8, 0x6c, 3, in_RDX);
            if (iVar2 < 1) {
                *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a099;
                func_0x000180229480();
                *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a0b1;
                func_0x0001802295a0(0x1804a9818, 0x1f5, 0x1804a98e8);
                uVar12 = 0x80002;
            } else {
                uVar7 = puVar15[0x8c];
                uVar1 = *puVar15;
                *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a0ca;
                iVar9 = func_0x00018021ff10(uVar1, uVar7);
                *(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5) = iVar9;
                if (iVar9 == 0) {
                    *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a0d9;
                    func_0x000180229480();
                    uVar12 = 0x1fb;
                } else {
                    *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a0f6;
                    iVar9 = func_0x000180242c60(iVar8, (int64_t)&arg_60h + iVar6 + iVar5, uVar12, uVar14);
                    if (iVar9 == 0) {
                        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a100;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a118;
                        func_0x0001802295a0(0x1804a9818, 0x200, 0x1804a98e8);
                        uVar12 = 0x80009;
                        iVar13 = 0;
                        goto code_r0x00018019a21f;
                    }
                    if (puVar11 == (undefined8 *)0x0) {
                        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a13e;
                        iVar2 = fcn.180199810(*(int64_t *)(&stack0x00000028 + iVar6 + iVar5), 
                                              *(int64_t *)(&stack0x00000030 + iVar6 + iVar5), 
                                              *(int64_t *)(&stack0x00000038 + iVar6 + iVar5), 
                                              *(int64_t *)(&stack0x00000048 + iVar6 + iVar5), 
                                              *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5), 
                                              *(int64_t *)(&stack0x00000090 + iVar6 + iVar5));
                    } else {
                        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a134;
                        iVar2 = func_0x000180198c50(puVar11, *(undefined8 *)((int64_t)&arg_60h + iVar6 + iVar5));
                    }
                    *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar10 + 8) = 0x18019a145;
                    iVar3 = func_0x000180220920();
                    if (iVar3 == 0) {
                        iVar13 = iVar2;
                    }
                    if (iVar13 == 0) goto code_r0x00018019a22c;
                    if (puVar11 == (undefined8 *)0x0) {
                        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar10 + 8) = 0x18019a174;
                        iVar2 = func_0x000180193380(in_RCX, 0x58, 0, 0);
                    } else {
                        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar10 + 8) = 0x18019a16a;
                        iVar2 = func_0x000180191a20(puVar11);
                    }
                    if (iVar2 == 0) {
code_r0x00018019a261:
                        iVar13 = 0;
                        goto code_r0x00018019a22c;
                    }
                    uVar7 = puVar15[0x8c];
                    uVar1 = *puVar15;
                    *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a18b;
                    iVar10 = func_0x00018021ff10(uVar1, uVar7);
                    *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5) = iVar10;
                    while (iVar10 != 0) {
                        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a1b3;
                        iVar10 = func_0x0001802201c0(iVar8, (int64_t)&arg_58h + iVar6 + iVar5, uVar12, uVar14);
                        if (iVar10 == 0) {
                            *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a26f;
                            func_0x00018021fe80(*(undefined8 *)((int64_t)&arg_58h + iVar6 + iVar5));
                            *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a274;
                            uVar4 = func_0x000180220a00();
                            if ((((int32_t)uVar4 < 0) || ((uVar4 & 0x7f800000) != 0x4800000)) ||
                               ((((int32_t)uVar4 >> 0x1f & 0x7f800000U) + 0x7fffff & uVar4) != 0x6c))
                            goto code_r0x00018019a261;
                            *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a2a5;
                            func_0x0001802203d0();
                            goto code_r0x00018019a22c;
                        }
                        if (puVar11 == (undefined8 *)0x0) {
                            *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a1e0;
                            iVar2 = func_0x000180193380(in_RCX, 0x59, 0, 
                                                        *(undefined8 *)((int64_t)&arg_58h + iVar6 + iVar5));
                        } else {
                            *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a1d6;
                            iVar2 = func_0x000180191a20(puVar11);
                        }
                        if (iVar2 == 0) {
                            *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a261;
                            func_0x00018021fe80(*(undefined8 *)((int64_t)&arg_58h + iVar6 + iVar5));
                            goto code_r0x00018019a261;
                        }
                        uVar7 = puVar15[0x8c];
                        uVar1 = *puVar15;
                        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a1f3;
                        iVar10 = func_0x00018021ff10(uVar1, uVar7);
                        *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5) = iVar10;
                    }
                    *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a202;
                    func_0x000180229480();
                    uVar12 = 0x222;
                }
                *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a21a;
                func_0x0001802295a0(0x1804a9818, uVar12, 0x1804a98e8);
                uVar12 = 0x8000d;
            }
        }
    }
code_r0x00018019a21f:
    *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a22c;
    func_0x0001802296d0(0x14, uVar12, 0);
code_r0x00018019a22c:
    *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a236;
    func_0x00018021fe80(*(undefined8 *)((int64_t)&arg_60h + iVar6 + iVar5));
    *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a23e;
    func_0x000180219f80(iVar8);
    return iVar13;
}

// ============================================================
// Function: FUN_180199930
// Address: 0x180199930
// Size: 392 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180199930(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    undefined *puVar1;
    undefined *puVar2;
    undefined *puVar3;
    undefined uVar4;
    undefined uVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int32_t in_ECX;
    uint64_t uVar8;
    undefined *in_RDX;
    int32_t iVar9;
    uint64_t in_R8;
    int64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180199954;
    iVar6 = func_0x00018045a350();
    iVar6 = -iVar6;
    if ((((in_RDX == (undefined *)0x0) || (in_R8 == 0)) || (1 < in_ECX - 1U)) || (0x7fffffffffffffff < in_R8)) {
code_r0x000180199a97:
        uVar7 = 0;
    } else {
        do {
            iVar9 = 0;
            if (in_ECX == 2) {
                if (in_R8 < 4) goto code_r0x000180199a97;
                puVar1 = in_RDX + 1;
                uVar4 = *in_RDX;
                puVar2 = in_RDX + 2;
                puVar3 = in_RDX + 3;
                in_RDX = in_RDX + 4;
                iVar9 = CONCAT31(CONCAT21(CONCAT11(uVar4, *puVar1), *puVar2), *puVar3);
                in_R8 = in_R8 - 4;
            }
            if ((in_R8 < 2) || (uVar4 = *in_RDX, uVar5 = in_RDX[1], in_R8 - 2 < 2)) goto code_r0x000180199a97;
            uVar8 = (uint64_t)CONCAT11(in_RDX[2], in_RDX[3]);
            if (in_R8 - 4 < uVar8) goto code_r0x000180199a97;
            in_R8 = (in_R8 - 4) - uVar8;
            in_RDX = in_RDX + uVar8 + 4;
            if (in_R9 != 0) {
                if ((in_ECX == 1) || (iVar9 == 0x1d0)) {
                    *(undefined8 *)((int64_t)&var_18h + iVar6) = 0;
                    *(undefined8 *)((int64_t)&var_10h + iVar6) = 0x180199b10;
                    *(undefined8 *)((int64_t)&var_8h + iVar6) = 0;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180199a83;
                    iVar9 = func_0x00018019a640(in_R9, CONCAT11(uVar4, uVar5), 0x180199ac0, 0);
                } else {
                    *(undefined8 *)((int64_t)&var_20h + iVar6) = 0;
                    *(undefined8 *)((int64_t)&var_18h + iVar6) = 0x180199c80;
                    *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
                    *(undefined8 *)((int64_t)&var_8h + iVar6) = 0;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180199a60;
                    iVar9 = func_0x00018019a490(in_R9, CONCAT11(uVar4, uVar5), iVar9, 0x180199b30);
                }
                if (iVar9 == 0) goto code_r0x000180199a97;
            }
        } while (in_R8 != 0);
        uVar7 = 1;
    }
    return uVar7;
}

// ============================================================
// Function: FUN_180199ac0
// Address: 0x180199ac0
// Size: 72 bytes
// ============================================================
void fcn.180199ac0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_80h, int64_t arg_88h)
{
    int64_t iVar1;
    undefined8 in_R9;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180199aca;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_40h + iVar1) = *(undefined8 *)((int64_t)&arg_88h + iVar1);
    *(undefined8 *)((int64_t)&arg_38h + iVar1) = *(undefined8 *)((int64_t)&arg_80h + iVar1);
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = in_R9;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180199b03;
    fcn.180199b30(*(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)((int64_t)&arg_38h + iVar1), 
                  *(int64_t *)((int64_t)&arg_40h + iVar1), *(int64_t *)(&stack0x00000048 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1), *(int64_t *)(&stack0x00000060 + iVar1), 
                  *(int64_t *)(&stack0x00000068 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180199b30
// Address: 0x180199b30
// Size: 326 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.180199b30(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_68h,
             int64_t arg_70h)
{
    undefined *puVar1;
    undefined *puVar2;
    int64_t iVar3;
    uint64_t *puVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int32_t *in_RCX;
    uint32_t in_EDX;
    uint64_t uVar8;
    uint32_t in_R8D;
    int64_t *in_R9;
    uint64_t uVar9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x180199b4a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar6) = 0;
    if (in_RCX == (int32_t *)0x0) goto code_r0x000180199c51;
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) goto code_r0x000180199c51;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180199b83;
        in_RCX = (int32_t *)func_0x0001801bda50(in_RCX);
        if (in_RCX == (int32_t *)0x0) goto code_r0x000180199c51;
    }
    if (((in_R8D >> 0xc & 1) == 0) || (*(int64_t *)((int64_t)&arg_68h + iVar6) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180199baf;
        iVar5 = func_0x0001801976f0(in_RCX, (int64_t)&arg_38h + iVar6, (int64_t)&var_18h + iVar6);
        if (iVar5 != 0) {
            puVar4 = *(uint64_t **)((int64_t)&arg_58h + iVar6);
            iVar7 = *(int64_t *)((int64_t)&arg_38h + iVar6);
            *in_R9 = 0;
            *puVar4 = 0;
            if ((iVar7 == 0) || (uVar8 = *(uint64_t *)((int64_t)&var_18h + iVar6), 0x7ffffffffffffffe < uVar8 - 1)) {
code_r0x000180199c51:
                **(undefined4 **)((int64_t)&arg_70h + iVar6) = 0x50;
                return 0xffffffff;
            }
            do {
                if ((uVar8 < 4) ||
                   ((uVar8 - 4 < 2 ||
                    (puVar1 = (undefined *)(iVar7 + 4), puVar2 = (undefined *)(iVar7 + 5), uVar8 - 6 < 2))))
                goto code_r0x000180199c51;
                iVar3 = iVar7 + 8;
                uVar9 = (uint64_t)CONCAT11(*(undefined *)(iVar7 + 6), *(undefined *)(iVar7 + 7));
                if (uVar8 - 8 < uVar9) goto code_r0x000180199c51;
                uVar8 = (uVar8 - 8) - uVar9;
                iVar7 = uVar9 + iVar3;
                if (CONCAT11(*puVar1, *puVar2) == in_EDX) {
                    *in_R9 = iVar3;
                    *puVar4 = uVar9;
                    return 1;
                }
            } while (uVar8 != 0);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180199ca0
// Address: 0x180199ca0
// Size: 477 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8
fcn.180199810(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
             int64_t arg_70h, int64_t arg_a0h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t *in_RCX;
    int64_t *piVar7;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180199820;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019983d;
        in_RCX = (int32_t *)func_0x0001801bda50();
        if (in_RCX == (int32_t *)0x0) {
            return 0;
        }
    }
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019984f;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180199867;
        func_0x0001802295a0(0x1804a9818, 0x29, 0x1804a9800);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180199879;
        func_0x0001802296d0(0x14, 0xc0102, 0);
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined4 *)((int64_t)&uStackX_20 + iVar3 + -8) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801998a3;
    iVar2 = func_0x0001801a8d20(in_RCX, 0, in_RDX, 0);
    if (iVar2 == 1) {
        uVar8 = *(undefined8 *)(in_RCX + 2);
        piVar7 = *(int64_t **)(in_RCX + 0x21e);
        uVar1 = *(undefined8 *)((int64_t)&arg_38h + iVar3);
        *(undefined8 *)((int64_t)&arg_38h + iVar3) = *(undefined8 *)((int64_t)&arg_40h + iVar3);
        *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_48h + iVar3) = uVar1;
        *(undefined8 *)(&stack0x00000028 + iVar3) = *(undefined8 *)(&stack0x00000028 + iVar3);
        *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x180199cba;
        iVar4 = fcn.18045a350(piVar7, in_RDX, uVar8);
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199cce;
        iVar5 = func_0x000180238400(in_RDX);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199cdb;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199cf3;
            func_0x0001802295a0(0x1804a9818, 0x108, 0x1804a9880);
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d05;
            func_0x0001802296d0(0x14, 0x10c, 0);
        } else {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d1c;
            iVar6 = func_0x0001801a2080(iVar5, (int64_t)&arg_70h + iVar4 + iVar3, uVar8);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d26;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d3e;
                func_0x0001802295a0(0x1804a9818, 0x10d, 0x1804a9880);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d50;
                func_0x0001802296d0(0x14, 0xf7, 0);
                return 0;
            }
            iVar6 = *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3);
            if (iVar6 == 3) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d6a;
                iVar2 = func_0x00018022e600(iVar5);
                if (iVar2 == 0) {
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d73;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d8b;
                    func_0x0001802295a0(0x1804a9818, 0x112, 0x1804a9880);
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199d9d;
                    func_0x0001802296d0(0x14, 0x13e, 0);
                    return 0;
                }
                iVar6 = *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3);
            }
            if (*(int64_t *)(piVar7[4] + 8 + iVar6 * 0x28) != 0) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199dc3;
                func_0x00018022e6c0(iVar5);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199dc8;
                func_0x0001802203d0();
                uVar8 = *(undefined8 *)(piVar7[4] + 8 + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199de2;
                iVar2 = func_0x000180238100(in_RDX, uVar8);
                if (iVar2 == 0) {
                    uVar8 = *(undefined8 *)(piVar7[4] + 8 + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28);
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199dfd;
                    func_0x00018022ecc0(uVar8);
                    *(undefined8 *)(piVar7[4] + 8 + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28) = 0;
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199e18;
                    func_0x0001802203d0();
                }
            }
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199e20;
            iVar2 = func_0x0001802375f0(in_RDX);
            if (iVar2 != 0) {
                uVar8 = *(undefined8 *)(piVar7[4] + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180199e3e;
                func_0x00018021fe80(uVar8);
                *(int64_t *)(piVar7[4] + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28) = in_RDX;
                *piVar7 = piVar7[4] + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28;
                return 1;
            }
        }
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801998af;
    func_0x000180229480();
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801998c7;
    func_0x0001802295a0(0x1804a9818, 0x2f, 0x1804a9800);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801998d6;
    func_0x0001802296d0(0x14, iVar2, 0);
    return 0;
}

// ============================================================
// Function: FUN_180199e80
// Address: 0x180199e80
// Size: 226 bytes
// ============================================================
undefined8 fcn.180199550(int64_t arg_28h, int64_t arg_48h, int64_t arg_60h, int64_t arg_90h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t *in_RCX;
    int64_t *piVar6;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18019955c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019957c;
        in_RCX = (int32_t *)func_0x0001801bda50(in_RCX);
        if (in_RCX == (int32_t *)0x0) {
            return 0;
        }
    }
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019958b;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801995a3;
        func_0x0001802295a0(0x1804a9818, 0xa3, 0x1804a9838);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801995b5;
        func_0x0001802296d0(0x14, 0xc0102, 0);
        return 0;
    }
    uVar1 = *(undefined8 *)(in_RCX + 2);
    piVar6 = *(int64_t **)(in_RCX + 0x21e);
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8);
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3) = 0x180199e90;
    iVar4 = fcn.18045a350(piVar6, in_RDX, uVar1);
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar3) = 0x180199ea6;
    iVar5 = func_0x0001801a2080(in_RDX, (int64_t)&arg_60h + iVar4 + iVar3);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar3) = 0x180199eb0;
        func_0x000180229480();
        *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar3) = 0x180199ec8;
        func_0x0001802295a0(0x1804a9818, 0x8a, 0x1804a9828);
        *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar3) = 0x180199eda;
        func_0x0001802296d0(0x14, 0xf7, 0);
    } else {
        iVar5 = *(int64_t *)(piVar6[4] + *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3) * 0x28);
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar3) = 0x180199f05;
            iVar2 = func_0x000180238100(iVar5, in_RDX);
            if (iVar2 == 0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar3) = 0x180199f11;
        iVar2 = func_0x0001802308d0(in_RDX);
        if (iVar2 != 0) {
            uVar1 = *(undefined8 *)(piVar6[4] + 8 + *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3) * 0x28);
            *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar3) = 0x180199f2c;
            func_0x00018022ecc0(uVar1);
            *(int64_t *)(piVar6[4] + 8 + *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3) * 0x28) = in_RDX;
            *piVar6 = piVar6[4] + *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3) * 0x28;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180199f70
// Address: 0x180199f70
// Size: 823 bytes
// ============================================================
int32_t fcn.180199910(int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int32_t *in_RCX;
    undefined8 *puVar11;
    int64_t in_RDX;
    undefined8 uVar12;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int32_t iVar13;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 uVar14;
    undefined8 unaff_R14;
    undefined8 *puVar15;
    undefined8 unaff_R15;
    int64_t var_18h;
    undefined8 uStackX_20;
    undefined8 auStack_10 [2];
    
    auStack_10[1] = 0x18019991a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar11 = (undefined8 *)0x0;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + -8) = unaff_RBP;
    *(undefined8 *)(&stack0x00000010 + iVar5) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar5) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar5 + -0x20) = unaff_R14;
    iVar10 = iVar5 + -8;
    *(undefined8 *)((int64_t)auStack_10 + iVar5 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStack_10 + iVar5) = 0x180199f83;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar13 = 0;
    iVar8 = 0;
    *(undefined8 *)((int64_t)&arg_60h + iVar6 + iVar5) = 0;
    puVar15 = puVar11;
    if (in_RCX != (int32_t *)0x0) {
        puVar15 = *(undefined8 **)(in_RCX + 2);
    }
    *(undefined8 *)((int64_t)&arg_68h + iVar6 + iVar5) = unaff_R12;
    *(undefined8 *)((int64_t)&var_18h + iVar6 + iVar5) = unaff_R13;
    if (puVar11 == (undefined8 *)0x0) {
        if (in_RCX == (int32_t *)0x0) {
            return 0;
        }
        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x180199fbe;
        func_0x0001802203d0();
        if (*in_RCX == 0) {
            uVar12 = *(undefined8 *)(in_RCX + 0x544);
            uVar14 = *(undefined8 *)(in_RCX + 0x546);
        } else {
            if (-1 < (char)*in_RCX) {
                return 0;
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x180199fe3;
            iVar9 = func_0x0001801bda50(in_RCX);
            if (iVar9 == 0) {
                return 0;
            }
            uVar12 = *(undefined8 *)(iVar9 + 0x1510);
            uVar14 = *(undefined8 *)(iVar9 + 0x1518);
        }
    } else {
        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a004;
        func_0x0001802203d0();
        uVar12 = puVar11[0x17];
        uVar14 = puVar11[0x18];
    }
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a01c;
        func_0x000180229480();
        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a034;
        func_0x0001802295a0(0x1804a9818, 0x1ea, 0x1804a98e8);
        uVar12 = 0xc0102;
    } else {
        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a043;
        uVar7 = func_0x00018023faa0();
        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a04b;
        iVar8 = func_0x00018021a7c0(uVar7);
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a058;
            func_0x000180229480();
            *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a070;
            func_0x0001802295a0(0x1804a9818, 0x1f0, 0x1804a98e8);
            uVar12 = 0x80007;
        } else {
            *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a090;
            iVar2 = func_0x000180219d10(iVar8, 0x6c, 3, in_RDX);
            if (iVar2 < 1) {
                *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a099;
                func_0x000180229480();
                *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a0b1;
                func_0x0001802295a0(0x1804a9818, 0x1f5, 0x1804a98e8);
                uVar12 = 0x80002;
            } else {
                uVar7 = puVar15[0x8c];
                uVar1 = *puVar15;
                *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a0ca;
                iVar9 = func_0x00018021ff10(uVar1, uVar7);
                *(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5) = iVar9;
                if (iVar9 == 0) {
                    *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a0d9;
                    func_0x000180229480();
                    uVar12 = 0x1fb;
                } else {
                    *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a0f6;
                    iVar9 = func_0x000180242c60(iVar8, (int64_t)&arg_60h + iVar6 + iVar5, uVar12, uVar14);
                    if (iVar9 == 0) {
                        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a100;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a118;
                        func_0x0001802295a0(0x1804a9818, 0x200, 0x1804a98e8);
                        uVar12 = 0x80009;
                        iVar13 = 0;
                        goto code_r0x00018019a21f;
                    }
                    if (puVar11 == (undefined8 *)0x0) {
                        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a13e;
                        iVar2 = fcn.180199810(*(int64_t *)(&stack0x00000028 + iVar6 + iVar5), 
                                              *(int64_t *)(&stack0x00000030 + iVar6 + iVar5), 
                                              *(int64_t *)(&stack0x00000038 + iVar6 + iVar5), 
                                              *(int64_t *)(&stack0x00000048 + iVar6 + iVar5), 
                                              *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5), 
                                              *(int64_t *)(&stack0x00000090 + iVar6 + iVar5));
                    } else {
                        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a134;
                        iVar2 = func_0x000180198c50(puVar11, *(undefined8 *)((int64_t)&arg_60h + iVar6 + iVar5));
                    }
                    *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar10 + 8) = 0x18019a145;
                    iVar3 = func_0x000180220920();
                    if (iVar3 == 0) {
                        iVar13 = iVar2;
                    }
                    if (iVar13 == 0) goto code_r0x00018019a22c;
                    if (puVar11 == (undefined8 *)0x0) {
                        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar10 + 8) = 0x18019a174;
                        iVar2 = func_0x000180193380(in_RCX, 0x58, 0, 0);
                    } else {
                        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar10 + 8) = 0x18019a16a;
                        iVar2 = func_0x000180191a20(puVar11);
                    }
                    if (iVar2 == 0) {
code_r0x00018019a261:
                        iVar13 = 0;
                        goto code_r0x00018019a22c;
                    }
                    uVar7 = puVar15[0x8c];
                    uVar1 = *puVar15;
                    *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a18b;
                    iVar10 = func_0x00018021ff10(uVar1, uVar7);
                    *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5) = iVar10;
                    while (iVar10 != 0) {
                        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a1b3;
                        iVar10 = func_0x0001802201c0(iVar8, (int64_t)&arg_58h + iVar6 + iVar5, uVar12, uVar14);
                        if (iVar10 == 0) {
                            *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a26f;
                            func_0x00018021fe80(*(undefined8 *)((int64_t)&arg_58h + iVar6 + iVar5));
                            *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a274;
                            uVar4 = func_0x000180220a00();
                            if ((((int32_t)uVar4 < 0) || ((uVar4 & 0x7f800000) != 0x4800000)) ||
                               ((((int32_t)uVar4 >> 0x1f & 0x7f800000U) + 0x7fffff & uVar4) != 0x6c))
                            goto code_r0x00018019a261;
                            *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a2a5;
                            func_0x0001802203d0();
                            goto code_r0x00018019a22c;
                        }
                        if (puVar11 == (undefined8 *)0x0) {
                            *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a1e0;
                            iVar2 = func_0x000180193380(in_RCX, 0x59, 0, 
                                                        *(undefined8 *)((int64_t)&arg_58h + iVar6 + iVar5));
                        } else {
                            *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a1d6;
                            iVar2 = func_0x000180191a20(puVar11);
                        }
                        if (iVar2 == 0) {
                            *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a261;
                            func_0x00018021fe80(*(undefined8 *)((int64_t)&arg_58h + iVar6 + iVar5));
                            goto code_r0x00018019a261;
                        }
                        uVar7 = puVar15[0x8c];
                        uVar1 = *puVar15;
                        *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a1f3;
                        iVar10 = func_0x00018021ff10(uVar1, uVar7);
                        *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5) = iVar10;
                    }
                    *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a202;
                    func_0x000180229480();
                    uVar12 = 0x222;
                }
                *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a21a;
                func_0x0001802295a0(0x1804a9818, uVar12, 0x1804a98e8);
                uVar12 = 0x8000d;
            }
        }
    }
code_r0x00018019a21f:
    *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a22c;
    func_0x0001802296d0(0x14, uVar12, 0);
code_r0x00018019a22c:
    *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a236;
    func_0x00018021fe80(*(undefined8 *)((int64_t)&arg_60h + iVar6 + iVar5));
    *(undefined8 *)((int64_t)auStack_10 + iVar6 + iVar5) = 0x18019a23e;
    func_0x000180219f80(iVar8);
    return iVar13;
}

// ============================================================
// Function: FUN_18019a3b0
// Address: 0x18019a3b0
// Size: 167 bytes
// ============================================================
bool fcn.18019a3b0(void)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18019a3ba;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int32_t *)0x18077e270 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18019a427;
        iVar1 = fcn.180243560(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                              *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3));
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18019a43e;
            iVar2 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_20 + iVar3));
            iVar1 = 0;
            if (iVar2 != 0) {
                iVar1 = *(int32_t *)0x18077e27c;
            }
            return iVar1 != 0;
        }
    } else if (*(int32_t *)0x18077e280 == 0) {
        *(int32_t *)0x18077e280 = 1;
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18019a3e1;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18019a3f9;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18019a40b;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
    }
    return false;
}

// ============================================================
// Function: FUN_18019a460
// Address: 0x18019a460
// Size: 48 bytes
// ============================================================
void fcn.18019a460(void)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x18019a46a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18019a472;
    fcn.18019e120();
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18019a477;
    fcn.1801c6a40(*(int64_t *)(&stack0x00000058 + iVar1));
    *(undefined4 *)0x18077e278 = 1;
    *(undefined4 *)0x18077e27c = 1;
    return;
}

// ============================================================
// Function: FUN_18019a490
// Address: 0x18019a490
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.18019a490(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h)
{
    int64_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint16_t *puVar7;
    int64_t in_RCX;
    uint16_t *puVar8;
    uint64_t in_RDX;
    uint64_t uVar9;
    undefined4 uVar10;
    undefined8 unaff_RSI;
    uint32_t uVar11;
    undefined4 in_R8D;
    int64_t in_R9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18019a4af;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar1 = *(int64_t *)((int64_t)&arg_48h + iVar6);
    if ((in_R9 == 0) && (iVar1 != 0)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RSI;
    iVar2 = *(int64_t *)(in_RCX + 0x158);
    uVar11 = (uint32_t)in_RDX;
    if (uVar11 == 0x12) {
        if ((char)in_R8D < '\0') {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019a4f1;
            iVar5 = func_0x000180191a10();
            if (iVar5 != 0) {
                return 0;
            }
        }
    } else {
        if (uVar11 < 0x3375) {
    // switch table (52 cases) at 0x18019a600
            switch(in_RDX & 0xffffffff) {
            default:
                goto code_r0x00018019a4fe;
            case 2:
            case 3:
            case 4:
            case 6:
            case 7:
            case 8:
            case 9:
            case 0xf:
            case 0x11:
            case 0x18:
            case 0x19:
            case 0x1a:
            case 0x1c:
            case 0x1d:
            case 0x1e:
            case 0x1f:
            case 0x20:
            case 0x21:
            case 0x22:
            case 0x24:
            case 0x25:
            case 0x26:
            case 0x27:
            case 0x28:
            case 0x2e:
            case 0x30:
            case 0x32:
                goto code_r0x00018019a552;
            }
        }
        if (uVar11 == 0xff01) {
            return 0;
        }
        if (0xffff < uVar11) {
            return 0;
        }
    }
code_r0x00018019a552:
    uVar3 = *(uint64_t *)(iVar2 + 0x88);
    uVar9 = 0;
    puVar7 = *(uint16_t **)(iVar2 + 0x80);
    uVar10 = 0;
    puVar8 = puVar7;
    if (uVar3 != 0) {
        do {
            if (uVar11 == *puVar8) {
                return 0;
            }
            uVar9 = uVar9 + 1;
            puVar8 = puVar8 + 0x1c;
        } while (uVar9 < uVar3);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019a595;
    puVar7 = (uint16_t *)func_0x0001802249c0(puVar7, (uVar3 + 1) * 0x38, 0x1804ab2a8, 0x1cb);
    if (puVar7 != (uint16_t *)0x0) {
        *(uint16_t **)(iVar2 + 0x80) = puVar7;
        puVar7 = puVar7 + *(int64_t *)(iVar2 + 0x88) * 0x1c;
        uVar4 = *(undefined8 *)((int64_t)&arg_58h + iVar6);
        puVar7[1] = 0;
        *(undefined8 *)(puVar7 + 0x14) = uVar4;
        if (in_RCX == 0) {
            uVar10 = 4;
        }
        *(undefined4 *)(puVar7 + 2) = 2;
        *(undefined8 *)(puVar7 + 0x10) = *(undefined8 *)((int64_t)&arg_50h + iVar6);
        *(undefined8 *)(puVar7 + 0x18) = *(undefined8 *)((int64_t)&arg_60h + iVar6);
        *(undefined4 *)(puVar7 + 4) = in_R8D;
        *(int64_t *)(puVar7 + 8) = in_R9;
        *(int64_t *)(puVar7 + 0xc) = iVar1;
        *puVar7 = (uint16_t)(in_RDX & 0xffffffff);
        *(undefined4 *)(puVar7 + 6) = uVar10;
        *(int64_t *)(iVar2 + 0x88) = *(int64_t *)(iVar2 + 0x88) + 1;
        return 1;
    }
code_r0x00018019a4fe:
    return 0;
}

// ============================================================
// Function: FUN_18019a4d2
// Address: 0x18019a4d2
// Size: 44 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.18019a490(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h)
{
    int64_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint16_t *puVar7;
    int64_t in_RCX;
    uint16_t *puVar8;
    uint64_t in_RDX;
    uint64_t uVar9;
    undefined4 uVar10;
    undefined8 unaff_RSI;
    uint32_t uVar11;
    undefined4 in_R8D;
    int64_t in_R9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18019a4af;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar1 = *(int64_t *)((int64_t)&arg_48h + iVar6);
    if ((in_R9 == 0) && (iVar1 != 0)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RSI;
    iVar2 = *(int64_t *)(in_RCX + 0x158);
    uVar11 = (uint32_t)in_RDX;
    if (uVar11 == 0x12) {
        if ((char)in_R8D < '\0') {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019a4f1;
            iVar5 = func_0x000180191a10();
            if (iVar5 != 0) {
                return 0;
            }
        }
    } else {
        if (uVar11 < 0x3375) {
    // switch table (52 cases) at 0x18019a600
            switch(in_RDX & 0xffffffff) {
            default:
                goto code_r0x00018019a4fe;
            case 2:
            case 3:
            case 4:
            case 6:
            case 7:
            case 8:
            case 9:
            case 0xf:
            case 0x11:
            case 0x18:
            case 0x19:
            case 0x1a:
            case 0x1c:
            case 0x1d:
            case 0x1e:
            case 0x1f:
            case 0x20:
            case 0x21:
            case 0x22:
            case 0x24:
            case 0x25:
            case 0x26:
            case 0x27:
            case 0x28:
            case 0x2e:
            case 0x30:
            case 0x32:
                goto code_r0x00018019a552;
            }
        }
        if (uVar11 == 0xff01) {
            return 0;
        }
        if (0xffff < uVar11) {
            return 0;
        }
    }
code_r0x00018019a552:
    uVar3 = *(uint64_t *)(iVar2 + 0x88);
    uVar9 = 0;
    puVar7 = *(uint16_t **)(iVar2 + 0x80);
    uVar10 = 0;
    puVar8 = puVar7;
    if (uVar3 != 0) {
        do {
            if (uVar11 == *puVar8) {
                return 0;
            }
            uVar9 = uVar9 + 1;
            puVar8 = puVar8 + 0x1c;
        } while (uVar9 < uVar3);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019a595;
    puVar7 = (uint16_t *)func_0x0001802249c0(puVar7, (uVar3 + 1) * 0x38, 0x1804ab2a8, 0x1cb);
    if (puVar7 != (uint16_t *)0x0) {
        *(uint16_t **)(iVar2 + 0x80) = puVar7;
        puVar7 = puVar7 + *(int64_t *)(iVar2 + 0x88) * 0x1c;
        uVar4 = *(undefined8 *)((int64_t)&arg_58h + iVar6);
        puVar7[1] = 0;
        *(undefined8 *)(puVar7 + 0x14) = uVar4;
        if (in_RCX == 0) {
            uVar10 = 4;
        }
        *(undefined4 *)(puVar7 + 2) = 2;
        *(undefined8 *)(puVar7 + 0x10) = *(undefined8 *)((int64_t)&arg_50h + iVar6);
        *(undefined8 *)(puVar7 + 0x18) = *(undefined8 *)((int64_t)&arg_60h + iVar6);
        *(undefined4 *)(puVar7 + 4) = in_R8D;
        *(int64_t *)(puVar7 + 8) = in_R9;
        *(int64_t *)(puVar7 + 0xc) = iVar1;
        *puVar7 = (uint16_t)(in_RDX & 0xffffffff);
        *(undefined4 *)(puVar7 + 6) = uVar10;
        *(int64_t *)(iVar2 + 0x88) = *(int64_t *)(iVar2 + 0x88) + 1;
        return 1;
    }
code_r0x00018019a4fe:
    return 0;
}

// ============================================================
// Function: FUN_18019a4fe
// Address: 0x18019a4fe
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.18019a490(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h)
{
    int64_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint16_t *puVar7;
    int64_t in_RCX;
    uint16_t *puVar8;
    uint64_t in_RDX;
    uint64_t uVar9;
    undefined4 uVar10;
    undefined8 unaff_RSI;
    uint32_t uVar11;
    undefined4 in_R8D;
    int64_t in_R9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18019a4af;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar1 = *(int64_t *)((int64_t)&arg_48h + iVar6);
    if ((in_R9 == 0) && (iVar1 != 0)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RSI;
    iVar2 = *(int64_t *)(in_RCX + 0x158);
    uVar11 = (uint32_t)in_RDX;
    if (uVar11 == 0x12) {
        if ((char)in_R8D < '\0') {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019a4f1;
            iVar5 = func_0x000180191a10();
            if (iVar5 != 0) {
                return 0;
            }
        }
    } else {
        if (uVar11 < 0x3375) {
    // switch table (52 cases) at 0x18019a600
            switch(in_RDX & 0xffffffff) {
            default:
                goto code_r0x00018019a4fe;
            case 2:
            case 3:
            case 4:
            case 6:
            case 7:
            case 8:
            case 9:
            case 0xf:
            case 0x11:
            case 0x18:
            case 0x19:
            case 0x1a:
            case 0x1c:
            case 0x1d:
            case 0x1e:
            case 0x1f:
            case 0x20:
            case 0x21:
            case 0x22:
            case 0x24:
            case 0x25:
            case 0x26:
            case 0x27:
            case 0x28:
            case 0x2e:
            case 0x30:
            case 0x32:
                goto code_r0x00018019a552;
            }
        }
        if (uVar11 == 0xff01) {
            return 0;
        }
        if (0xffff < uVar11) {
            return 0;
        }
    }
code_r0x00018019a552:
    uVar3 = *(uint64_t *)(iVar2 + 0x88);
    uVar9 = 0;
    puVar7 = *(uint16_t **)(iVar2 + 0x80);
    uVar10 = 0;
    puVar8 = puVar7;
    if (uVar3 != 0) {
        do {
            if (uVar11 == *puVar8) {
                return 0;
            }
            uVar9 = uVar9 + 1;
            puVar8 = puVar8 + 0x1c;
        } while (uVar9 < uVar3);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019a595;
    puVar7 = (uint16_t *)func_0x0001802249c0(puVar7, (uVar3 + 1) * 0x38, 0x1804ab2a8, 0x1cb);
    if (puVar7 != (uint16_t *)0x0) {
        *(uint16_t **)(iVar2 + 0x80) = puVar7;
        puVar7 = puVar7 + *(int64_t *)(iVar2 + 0x88) * 0x1c;
        uVar4 = *(undefined8 *)((int64_t)&arg_58h + iVar6);
        puVar7[1] = 0;
        *(undefined8 *)(puVar7 + 0x14) = uVar4;
        if (in_RCX == 0) {
            uVar10 = 4;
        }
        *(undefined4 *)(puVar7 + 2) = 2;
        *(undefined8 *)(puVar7 + 0x10) = *(undefined8 *)((int64_t)&arg_50h + iVar6);
        *(undefined8 *)(puVar7 + 0x18) = *(undefined8 *)((int64_t)&arg_60h + iVar6);
        *(undefined4 *)(puVar7 + 4) = in_R8D;
        *(int64_t *)(puVar7 + 8) = in_R9;
        *(int64_t *)(puVar7 + 0xc) = iVar1;
        *puVar7 = (uint16_t)(in_RDX & 0xffffffff);
        *(undefined4 *)(puVar7 + 6) = uVar10;
        *(int64_t *)(iVar2 + 0x88) = *(int64_t *)(iVar2 + 0x88) + 1;
        return 1;
    }
code_r0x00018019a4fe:
    return 0;
}

// ============================================================
// Function: FUN_18019a518
// Address: 0x18019a518
// Size: 292 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.18019a490(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h)
{
    int64_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint16_t *puVar7;
    int64_t in_RCX;
    uint16_t *puVar8;
    uint64_t in_RDX;
    uint64_t uVar9;
    undefined4 uVar10;
    undefined8 unaff_RSI;
    uint32_t uVar11;
    undefined4 in_R8D;
    int64_t in_R9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18019a4af;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar1 = *(int64_t *)((int64_t)&arg_48h + iVar6);
    if ((in_R9 == 0) && (iVar1 != 0)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RSI;
    iVar2 = *(int64_t *)(in_RCX + 0x158);
    uVar11 = (uint32_t)in_RDX;
    if (uVar11 == 0x12) {
        if ((char)in_R8D < '\0') {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019a4f1;
            iVar5 = func_0x000180191a10();
            if (iVar5 != 0) {
                return 0;
            }
        }
    } else {
        if (uVar11 < 0x3375) {
    // switch table (52 cases) at 0x18019a600
            switch(in_RDX & 0xffffffff) {
            default:
                goto code_r0x00018019a4fe;
            case 2:
            case 3:
            case 4:
            case 6:
            case 7:
            case 8:
            case 9:
            case 0xf:
            case 0x11:
            case 0x18:
            case 0x19:
            case 0x1a:
            case 0x1c:
            case 0x1d:
            case 0x1e:
            case 0x1f:
            case 0x20:
            case 0x21:
            case 0x22:
            case 0x24:
            case 0x25:
            case 0x26:
            case 0x27:
            case 0x28:
            case 0x2e:
            case 0x30:
            case 0x32:
                goto code_r0x00018019a552;
            }
        }
        if (uVar11 == 0xff01) {
            return 0;
        }
        if (0xffff < uVar11) {
            return 0;
        }
    }
code_r0x00018019a552:
    uVar3 = *(uint64_t *)(iVar2 + 0x88);
    uVar9 = 0;
    puVar7 = *(uint16_t **)(iVar2 + 0x80);
    uVar10 = 0;
    puVar8 = puVar7;
    if (uVar3 != 0) {
        do {
            if (uVar11 == *puVar8) {
                return 0;
            }
            uVar9 = uVar9 + 1;
            puVar8 = puVar8 + 0x1c;
        } while (uVar9 < uVar3);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019a595;
    puVar7 = (uint16_t *)func_0x0001802249c0(puVar7, (uVar3 + 1) * 0x38, 0x1804ab2a8, 0x1cb);
    if (puVar7 != (uint16_t *)0x0) {
        *(uint16_t **)(iVar2 + 0x80) = puVar7;
        puVar7 = puVar7 + *(int64_t *)(iVar2 + 0x88) * 0x1c;
        uVar4 = *(undefined8 *)((int64_t)&arg_58h + iVar6);
        puVar7[1] = 0;
        *(undefined8 *)(puVar7 + 0x14) = uVar4;
        if (in_RCX == 0) {
            uVar10 = 4;
        }
        *(undefined4 *)(puVar7 + 2) = 2;
        *(undefined8 *)(puVar7 + 0x10) = *(undefined8 *)((int64_t)&arg_50h + iVar6);
        *(undefined8 *)(puVar7 + 0x18) = *(undefined8 *)((int64_t)&arg_60h + iVar6);
        *(undefined4 *)(puVar7 + 4) = in_R8D;
        *(int64_t *)(puVar7 + 8) = in_R9;
        *(int64_t *)(puVar7 + 0xc) = iVar1;
        *puVar7 = (uint16_t)(in_RDX & 0xffffffff);
        *(undefined4 *)(puVar7 + 6) = uVar10;
        *(int64_t *)(iVar2 + 0x88) = *(int64_t *)(iVar2 + 0x88) + 1;
        return 1;
    }
code_r0x00018019a4fe:
    return 0;
}

// ============================================================
// Function: FUN_18019a640
// Address: 0x18019a640
// Size: 86 bytes
// ============================================================
void fcn.18019a640(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_80h, int64_t arg_88h,
                  int64_t arg_90h)
{
    int64_t iVar1;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18019a64a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_40h + iVar1) = *(undefined8 *)((int64_t)&arg_90h + iVar1);
    *(undefined8 *)((int64_t)&arg_38h + iVar1) = *(undefined8 *)((int64_t)&arg_88h + iVar1);
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = *(undefined8 *)((int64_t)&arg_80h + iVar1);
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = in_R9;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = in_R8;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18019a691;
    fcn.18019a6f0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1), *(int64_t *)(&stack0x00000058 + iVar1), 
                  *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x00000070 + iVar1), 
                  *(int64_t *)(&stack0x00000078 + iVar1), *(int64_t *)((int64_t)&arg_80h + iVar1), 
                  *(int64_t *)((int64_t)&arg_88h + iVar1), *(int64_t *)((int64_t)&arg_90h + iVar1));
    return;
}

// ============================================================
// Function: FUN_18019a6f0
// Address: 0x18019a6f0
// Size: 363 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.18019a6f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
                     int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    undefined8 *puVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    uint64_t in_R8;
    undefined4 in_R9D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18019a70e;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18019a734;
    puVar3 = (undefined8 *)func_0x0001802248d0(0x18, 0x1804ab2a8, 0x1e8);
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18019a74e;
    puVar4 = (undefined8 *)func_0x0001802248d0(0x10, 0x1804ab2a8, 0x1ea);
    if ((puVar3 == (undefined8 *)0x0) || (puVar4 == (undefined8 *)0x0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18019a828;
        func_0x000180224990(puVar3, 0x1804ab2a8, 0x1ee);
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18019a83d;
        func_0x000180224990(puVar4, 0x1804ab2a8, 0x1ef);
        iVar1 = 0;
    } else {
        *puVar3 = *(undefined8 *)((int64_t)&arg_88h + iVar2);
        puVar3[1] = *(undefined8 *)((int64_t)&arg_78h + iVar2);
        puVar3[2] = *(undefined8 *)((int64_t)&arg_80h + iVar2);
        *puVar4 = *(undefined8 *)((int64_t)&arg_98h + iVar2);
        *(undefined8 **)((int64_t)&arg_30h + iVar2) = puVar4;
        puVar4[1] = *(undefined8 *)((int64_t)&arg_90h + iVar2);
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = 0x18019ab50;
        *(undefined8 **)((int64_t)&var_20h + iVar2) = puVar3;
        *(undefined8 *)((int64_t)&var_18h + iVar2) = 0x18019abf0;
        *(undefined8 *)((int64_t)&var_10h + iVar2) = 0x18019ab50;
        *(undefined4 *)((int64_t)&var_8h + iVar2) = in_R9D;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18019a7df;
        iVar1 = func_0x00018019b000(in_RCX, 0, in_RDX & 0xffffffff, in_R8 & 0xffffffff);
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18019a7fa;
            func_0x000180224990(puVar3, 0x1804ab2a8, 0x202);
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18019a80f;
            func_0x000180224990(puVar4, 0x1804ab2a8, 0x203);
        }
    }
    return iVar1;
}

// ============================================================
// Function: FUN_18019a860
// Address: 0x18019a860
// Size: 740 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8
fcn.18019a860(int64_t arg4, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h,
             int64_t arg_90h)
{
    undefined2 uVar1;
    undefined4 uVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 in_R8;
    code *pcVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_40;
    int64_t var_10h;
    
    uStack_40 = 0x18019a87f;
    var_20h = arg4;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar4 = *(int64_t *)(in_RCX + 0x878);
    uVar10 = 0;
    uVar11 = uVar10;
    if (*(int64_t *)(iVar4 + 0x88) != 0) {
        do {
            iVar5 = *(int64_t *)(iVar4 + 0x80);
            *(undefined8 *)((int64_t)&arg_68h + iVar8) = 0;
            *(undefined8 *)((int64_t)&var_18h + iVar8) = 0;
            uVar2 = *(undefined4 *)(iVar5 + 8 + uVar11);
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18019a8de;
            iVar7 = func_0x0001801c93d0(in_RCX, uVar2, in_RDX & 0xffffffff, *(undefined4 *)((int64_t)&arg_90h + iVar8));
            if ((iVar7 != 0) && (((in_RDX & 0x11f00) == 0 || ((*(uint8_t *)(iVar5 + 0xc + uVar11) & 1) != 0)))) {
                if ((char)in_RDX < '\0') {
                    pcVar9 = *(code **)(iVar5 + 0x10 + uVar11);
                    if (pcVar9 != (code *)0x0) goto code_r0x00018019a91c;
code_r0x00018019a97c:
                    uVar1 = *(undefined2 *)(iVar5 + uVar11);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18019a98f;
                    iVar7 = func_0x0001802446f0(in_R8, uVar1, 2);
                    if (iVar7 != 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18019a9a4;
                        iVar7 = func_0x000180244a90(in_R8, 2);
                        if (iVar7 != 0) {
                            if (*(int64_t *)((int64_t)&var_18h + iVar8) != 0) {
                                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18019a9c6;
                                iVar7 = func_0x0001802445f0(in_R8, *(undefined8 *)((int64_t)&arg_68h + iVar8));
                                if (iVar7 == 0) goto code_r0x00018019aac0;
                            }
                            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18019a9d6;
                            iVar7 = func_0x000180244000(in_R8);
                            if (iVar7 != 0) {
                                if ((char)in_RDX < '\0') {
                                    uVar3 = *(uint32_t *)(iVar5 + 0xc + uVar11);
                                    if ((uVar3 & 2) != 0) {
                                        pcVar9 = *(code **)(iVar5 + 0x18 + uVar11);
                                        if (pcVar9 != (code *)0x0) {
                                            uVar1 = *(undefined2 *)(iVar5 + uVar11);
                                            uVar6 = *(undefined8 *)(in_RCX + 0x40);
                                            *(undefined8 *)(&stack0xffffffffffffffe8 + iVar8) =
                                                 *(undefined8 *)(iVar5 + 0x20 + uVar11);
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18019aaaf;
                                            (*pcVar9)(uVar6, uVar1, in_RDX & 0xffffffff, 
                                                      *(undefined8 *)((int64_t)&arg_68h + iVar8));
                                        }
                                        if ((in_RDX & 0x8000) != 0) {
                                            return 0;
                                        }
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18019aab9;
                                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                                                      *(int64_t *)((int64_t)&var_10h + iVar8));
                                        goto code_r0x00018019aafa;
                                    }
                                    *(uint32_t *)(iVar5 + 0xc + uVar11) = uVar3 | 2;
                                }
                                pcVar9 = *(code **)(iVar5 + 0x18 + uVar11);
                                if (pcVar9 != (code *)0x0) {
                                    uVar1 = *(undefined2 *)(iVar5 + uVar11);
                                    uVar6 = *(undefined8 *)(in_RCX + 0x40);
                                    *(undefined8 *)(&stack0xffffffffffffffe8 + iVar8) =
                                         *(undefined8 *)(iVar5 + 0x20 + uVar11);
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18019aa23;
                                    (*pcVar9)(uVar6, uVar1, in_RDX & 0xffffffff, 
                                              *(undefined8 *)((int64_t)&arg_68h + iVar8));
                                }
                                goto code_r0x00018019aa23;
                            }
                        }
                    }
code_r0x00018019aac0:
                    pcVar9 = *(code **)(iVar5 + 0x18 + uVar11);
                    if (pcVar9 != (code *)0x0) {
                        uVar1 = *(undefined2 *)(iVar5 + uVar11);
                        uVar6 = *(undefined8 *)(in_RCX + 0x40);
                        *(undefined8 *)(&stack0xffffffffffffffe8 + iVar8) = *(undefined8 *)(iVar5 + 0x20 + uVar11);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18019aaeb;
                        (*pcVar9)(uVar6, uVar1, in_RDX & 0xffffffff, *(undefined8 *)((int64_t)&arg_68h + iVar8));
                    }
                    if ((in_RDX & 0x8000) != 0) {
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18019aaf5;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                                  *(int64_t *)((int64_t)&var_10h + iVar8));
code_r0x00018019aafa:
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18019ab0d;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                                  *(int64_t *)((int64_t)&var_10h + iVar8), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8)
                                  , *(int64_t *)((int64_t)&var_18h + iVar8));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18019ab23;
                    func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
                    return 0;
                }
                if (*(int64_t *)(iVar5 + 0x10 + uVar11) != 0) {
                    pcVar9 = *(code **)(iVar5 + 0x10 + uVar11);
code_r0x00018019a91c:
                    uVar1 = *(undefined2 *)(iVar5 + uVar11);
                    uVar6 = *(undefined8 *)(in_RCX + 0x40);
                    *(undefined8 *)((int64_t)&var_8h + iVar8) = *(undefined8 *)(iVar5 + 0x20 + uVar11);
                    *(int64_t *)(&stack0x00000000 + iVar8) = (int64_t)&arg_70h + iVar8;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8) = *(undefined8 *)((int64_t)&arg_88h + iVar8);
                    *(undefined8 *)((int64_t)&var_10h + iVar8) = *(undefined8 *)((int64_t)&arg_80h + iVar8);
                    *(int64_t *)(&stack0xffffffffffffffe8 + iVar8) = (int64_t)&var_18h + iVar8;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18019a96e;
                    iVar7 = (*pcVar9)(uVar6, uVar1, in_RDX & 0xffffffff, (int64_t)&arg_68h + iVar8);
                    if (iVar7 < 0) {
                        if ((in_RDX & 0x8000) != 0) {
                            return 0;
                        }
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18019aa4d;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                                      *(int64_t *)((int64_t)&var_10h + iVar8));
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18019aa65;
                        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                                      *(int64_t *)((int64_t)&var_10h + iVar8), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                                      *(int64_t *)(&stack0x00000000 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8));
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18019aa7d;
                        func_0x00018019b5e0(in_RCX, *(undefined4 *)((int64_t)&arg_70h + iVar8), 0xea, 0);
                        return 0;
                    }
                    if (iVar7 != 0) goto code_r0x00018019a97c;
                }
            }
code_r0x00018019aa23:
            uVar10 = uVar10 + 1;
            uVar11 = uVar11 + 0x38;
        } while (uVar10 < *(uint64_t *)(iVar4 + 0x88));
    }
    return 1;
}

// ============================================================
// Function: FUN_18019ab50
// Address: 0x18019ab50
// Size: 76 bytes
// ============================================================
undefined8 fcn.18019ab50(int64_t arg_60h, int64_t arg_68h, int64_t arg_78h, int64_t arg_80h)
{
    code *UNRECOVERED_JUMPTABLE;
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 in_RCX;
    undefined8 in_RDX;
    undefined8 in_R9;
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    UNRECOVERED_JUMPTABLE = (code *)(*(undefined8 **)((int64_t)&arg_80h + iVar1))[1];
    if (UNRECOVERED_JUMPTABLE == (code *)0x0) {
        return 1;
    }
    uVar2 = *(undefined8 *)((int64_t)&arg_60h + iVar1);
    *(undefined8 *)((int64_t)&arg_68h + iVar1) = **(undefined8 **)((int64_t)&arg_80h + iVar1);
    *(undefined8 *)((int64_t)&arg_60h + iVar1) = *(undefined8 *)((int64_t)&arg_78h + iVar1);
    // WARNING: Could not recover jumptable at 0x00018019ab99. Too many branches
    // WARNING: Treating indirect jump as call
    uVar2 = (*UNRECOVERED_JUMPTABLE)(in_RCX, in_RDX, in_R9, uVar2);
    return uVar2;
}

// ============================================================
// Function: FUN_18019abf0
// Address: 0x18019abf0
// Size: 48 bytes
// ============================================================
void fcn.18019abf0(int64_t arg_50h)
{
    code *UNRECOVERED_JUMPTABLE;
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_RDX;
    undefined8 in_R9;
    
    iVar1 = fcn.18045a350();
    UNRECOVERED_JUMPTABLE = (code *)(*(undefined8 **)((int64_t)&arg_50h - iVar1))[2];
    if (UNRECOVERED_JUMPTABLE != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018019ac18. Too many branches
    // WARNING: Treating indirect jump as call
        (*UNRECOVERED_JUMPTABLE)(in_RCX, in_RDX, in_R9, **(undefined8 **)((int64_t)&arg_50h - iVar1));
        return;
    }
    return;
}

// ============================================================
// Function: FUN_18019ac50
// Address: 0x18019ac50
// Size: 409 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8
fcn.18019ac50(int64_t arg_28h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_78h, int64_t arg_80h,
             int64_t arg_88h)
{
    undefined4 uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    code *pcVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    uint64_t in_RDX;
    uint16_t *puVar8;
    uint64_t in_R8;
    undefined8 in_R9;
    uint64_t uVar9;
    uint32_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18019ac68;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar9 = 0;
    iVar2 = *(int64_t *)(in_RCX + 0x878);
    *(undefined4 *)((int64_t)&arg_60h + iVar7) = 0;
    uVar10 = 2;
    if ((in_RDX & 0x180) != 0) {
        uVar10 = (uint32_t)(*(int32_t *)(in_RCX + 0x78) != 0);
    }
    puVar8 = *(uint16_t **)(iVar2 + 0x80);
    uVar3 = *(uint64_t *)(iVar2 + 0x88);
    if (uVar3 != 0) {
        do {
            if (((uint32_t)in_R8 == (uint32_t)*puVar8) &&
               (((uVar10 == 2 || (uVar10 == *(uint32_t *)(puVar8 + 2))) || (*(uint32_t *)(puVar8 + 2) == 2)))) {
                uVar1 = *(undefined4 *)(puVar8 + 4);
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18019ad00;
                iVar6 = func_0x0001801c9310(in_RCX, uVar1, in_RDX & 0xffffffff);
                if (iVar6 == 0) {
                    return 1;
                }
                if (((in_RDX & 0x700) != 0) && ((*(uint8_t *)(puVar8 + 6) & 2) == 0)) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18019ad17;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18019ad2f;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                                  *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar7));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18019ad42;
                    func_0x00018019b5e0(in_RCX, 0x6e, 0x6e, 0);
                    return 0;
                }
                if ((in_RDX & 0x4080) != 0) {
                    *(uint32_t *)(puVar8 + 6) = *(uint32_t *)(puVar8 + 6) | 1;
                }
                pcVar4 = *(code **)(puVar8 + 0x14);
                if (pcVar4 == (code *)0x0) {
                    return 1;
                }
                uVar5 = *(undefined8 *)(in_RCX + 0x40);
                *(undefined8 *)((int64_t)&arg_28h + iVar7) = *(undefined8 *)(puVar8 + 0x18);
                *(int64_t *)((int64_t)&var_20h + iVar7) = (int64_t)&arg_60h + iVar7;
                *(undefined8 *)((int64_t)&var_18h + iVar7) = *(undefined8 *)((int64_t)&arg_88h + iVar7);
                *(undefined8 *)((int64_t)&var_10h + iVar7) = *(undefined8 *)((int64_t)&arg_80h + iVar7);
                *(undefined8 *)((int64_t)&var_8h + iVar7) = *(undefined8 *)((int64_t)&arg_78h + iVar7);
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18019ada8;
                iVar6 = (*pcVar4)(uVar5, in_R8 & 0xffffffff, in_RDX & 0xffffffff, in_R9);
                if (0 < iVar6) {
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18019adb5;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18019adcd;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                              *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18019ade2;
                func_0x00018019b5e0(in_RCX, *(undefined4 *)((int64_t)&arg_60h + iVar7), 0x6e, 0);
                return 0;
            }
            uVar9 = uVar9 + 1;
            puVar8 = puVar8 + 0x1c;
        } while (uVar9 < uVar3);
    }
    return 1;
}

// ============================================================
// Function: FUN_18019adf0
// Address: 0x18019adf0
// Size: 107 bytes
// ============================================================
undefined8 fcn.18019adf0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t *in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 unaff_RDI;
    int64_t iVar7;
    undefined8 unaff_R15;
    undefined8 uStack_30;
    
    uStack_30 = 0x18019ae03;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    iVar2 = in_RDX[1];
    uVar4 = 0;
    if (iVar2 != 0) {
        iVar7 = *in_RDX;
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x18019ae38;
        iVar2 = func_0x000180223170(iVar7, iVar2 * 0x38, 0x1804ab2a8, 0x13c);
        *in_RCX = iVar2;
        if (iVar2 == 0) {
            return 0;
        }
        in_RCX[1] = in_RDX[1];
        if (in_RDX[1] != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_30h + iVar1) = unaff_RDI;
            *(undefined8 *)((int64_t)&arg_38h + iVar1) = unaff_R15;
            uVar5 = uVar4;
            uVar6 = uVar4;
            do {
                iVar2 = *in_RDX;
                iVar7 = *in_RCX + uVar4;
                if (*(code **)(iVar2 + 0x10 + uVar4) == fcn.18019ab50) {
                    if ((int32_t)uVar5 == 0) {
                        uVar3 = *(undefined8 *)(iVar2 + 0x20 + uVar4);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x18019aebb;
                        uVar3 = func_0x000180223170(uVar3, 0x18, 0x1804ab2a8, 0x129);
                        *(undefined8 *)(iVar7 + 0x20) = uVar3;
                        uVar3 = *(undefined8 *)(iVar2 + 0x30 + uVar4);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x18019aedb;
                        iVar2 = func_0x000180223170(uVar3, 0x10, 0x1804ab2a8, 299);
                        *(int64_t *)(iVar7 + 0x30) = iVar2;
                        if ((*(int64_t *)(iVar7 + 0x20) == 0) || (iVar2 == 0)) {
                            uVar5 = 1;
                        }
                    } else {
                        *(undefined8 *)(iVar7 + 0x20) = 0;
                        *(undefined8 *)(iVar7 + 0x30) = 0;
                    }
                }
                uVar6 = uVar6 + 1;
                uVar4 = uVar4 + 0x38;
            } while (uVar6 < (uint64_t)in_RDX[1]);
            if ((int32_t)uVar5 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x18019af22;
                func_0x00018019af50(in_RCX);
                return 0;
            }
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18019ae5b
// Address: 0x18019ae5b
// Size: 191 bytes
// ============================================================
undefined8 fcn.18019adf0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t *in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 unaff_RDI;
    int64_t iVar7;
    undefined8 unaff_R15;
    undefined8 uStack_30;
    
    uStack_30 = 0x18019ae03;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    iVar2 = in_RDX[1];
    uVar4 = 0;
    if (iVar2 != 0) {
        iVar7 = *in_RDX;
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x18019ae38;
        iVar2 = func_0x000180223170(iVar7, iVar2 * 0x38, 0x1804ab2a8, 0x13c);
        *in_RCX = iVar2;
        if (iVar2 == 0) {
            return 0;
        }
        in_RCX[1] = in_RDX[1];
        if (in_RDX[1] != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_30h + iVar1) = unaff_RDI;
            *(undefined8 *)((int64_t)&arg_38h + iVar1) = unaff_R15;
            uVar5 = uVar4;
            uVar6 = uVar4;
            do {
                iVar2 = *in_RDX;
                iVar7 = *in_RCX + uVar4;
                if (*(code **)(iVar2 + 0x10 + uVar4) == fcn.18019ab50) {
                    if ((int32_t)uVar5 == 0) {
                        uVar3 = *(undefined8 *)(iVar2 + 0x20 + uVar4);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x18019aebb;
                        uVar3 = func_0x000180223170(uVar3, 0x18, 0x1804ab2a8, 0x129);
                        *(undefined8 *)(iVar7 + 0x20) = uVar3;
                        uVar3 = *(undefined8 *)(iVar2 + 0x30 + uVar4);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x18019aedb;
                        iVar2 = func_0x000180223170(uVar3, 0x10, 0x1804ab2a8, 299);
                        *(int64_t *)(iVar7 + 0x30) = iVar2;
                        if ((*(int64_t *)(iVar7 + 0x20) == 0) || (iVar2 == 0)) {
                            uVar5 = 1;
                        }
                    } else {
                        *(undefined8 *)(iVar7 + 0x20) = 0;
                        *(undefined8 *)(iVar7 + 0x30) = 0;
                    }
                }
                uVar6 = uVar6 + 1;
                uVar4 = uVar4 + 0x38;
            } while (uVar6 < (uint64_t)in_RDX[1]);
            if ((int32_t)uVar5 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x18019af22;
                func_0x00018019af50(in_RCX);
                return 0;
            }
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18019af1a
// Address: 0x18019af1a
// Size: 41 bytes
// ============================================================
undefined8 fcn.18019adf0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t *in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 unaff_RDI;
    int64_t iVar7;
    undefined8 unaff_R15;
    undefined8 uStack_30;
    
    uStack_30 = 0x18019ae03;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    iVar2 = in_RDX[1];
    uVar4 = 0;
    if (iVar2 != 0) {
        iVar7 = *in_RDX;
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x18019ae38;
        iVar2 = func_0x000180223170(iVar7, iVar2 * 0x38, 0x1804ab2a8, 0x13c);
        *in_RCX = iVar2;
        if (iVar2 == 0) {
            return 0;
        }
        in_RCX[1] = in_RDX[1];
        if (in_RDX[1] != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_30h + iVar1) = unaff_RDI;
            *(undefined8 *)((int64_t)&arg_38h + iVar1) = unaff_R15;
            uVar5 = uVar4;
            uVar6 = uVar4;
            do {
                iVar2 = *in_RDX;
                iVar7 = *in_RCX + uVar4;
                if (*(code **)(iVar2 + 0x10 + uVar4) == fcn.18019ab50) {
                    if ((int32_t)uVar5 == 0) {
                        uVar3 = *(undefined8 *)(iVar2 + 0x20 + uVar4);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x18019aebb;
                        uVar3 = func_0x000180223170(uVar3, 0x18, 0x1804ab2a8, 0x129);
                        *(undefined8 *)(iVar7 + 0x20) = uVar3;
                        uVar3 = *(undefined8 *)(iVar2 + 0x30 + uVar4);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x18019aedb;
                        iVar2 = func_0x000180223170(uVar3, 0x10, 0x1804ab2a8, 299);
                        *(int64_t *)(iVar7 + 0x30) = iVar2;
                        if ((*(int64_t *)(iVar7 + 0x20) == 0) || (iVar2 == 0)) {
                            uVar5 = 1;
                        }
                    } else {
                        *(undefined8 *)(iVar7 + 0x20) = 0;
                        *(undefined8 *)(iVar7 + 0x30) = 0;
                    }
                }
                uVar6 = uVar6 + 1;
                uVar4 = uVar4 + 0x38;
            } while (uVar6 < (uint64_t)in_RDX[1]);
            if ((int32_t)uVar5 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x18019af22;
                func_0x00018019af50(in_RCX);
                return 0;
            }
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18019af50
// Address: 0x18019af50
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18019af50(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    undefined8 *puVar5;
    undefined8 unaff_RBP;
    uint64_t uVar6;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019af65;
    iVar4 = fcn.18045a350();
    iVar3 = -iVar4;
    iVar1 = *in_RCX;
    uVar6 = 0;
    if (in_RCX[1] != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBP;
        puVar5 = (undefined8 *)(iVar1 + iVar4);
        do {
            if ((code *)puVar5[-2] == fcn.18019ab50) {
                uVar2 = *puVar5;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019afa0;
                func_0x000180224990(uVar2, 0x1804ab2a8, 0x18b);
                uVar2 = puVar5[2];
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019afb6;
                func_0x000180224990(uVar2, 0x1804ab2a8, 0x18c);
            }
            uVar6 = uVar6 + 1;
            puVar5 = puVar5 + 7;
        } while (uVar6 < (uint64_t)in_RCX[1]);
    }
    iVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019afdd;
    func_0x000180224990(iVar1, 0x1804ab2a8, 0x18e);
    *in_RCX = 0;
    in_RCX[1] = 0;
    return;
}

// ============================================================
// Function: FUN_18019af76
// Address: 0x18019af76
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18019af50(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    undefined8 *puVar5;
    undefined8 unaff_RBP;
    uint64_t uVar6;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019af65;
    iVar4 = fcn.18045a350();
    iVar3 = -iVar4;
    iVar1 = *in_RCX;
    uVar6 = 0;
    if (in_RCX[1] != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBP;
        puVar5 = (undefined8 *)(iVar1 + iVar4);
        do {
            if ((code *)puVar5[-2] == fcn.18019ab50) {
                uVar2 = *puVar5;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019afa0;
                func_0x000180224990(uVar2, 0x1804ab2a8, 0x18b);
                uVar2 = puVar5[2];
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019afb6;
                func_0x000180224990(uVar2, 0x1804ab2a8, 0x18c);
            }
            uVar6 = uVar6 + 1;
            puVar5 = puVar5 + 7;
        } while (uVar6 < (uint64_t)in_RCX[1]);
    }
    iVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019afdd;
    func_0x000180224990(iVar1, 0x1804ab2a8, 0x18e);
    *in_RCX = 0;
    in_RCX[1] = 0;
    return;
}

// ============================================================
// Function: FUN_18019afc8
// Address: 0x18019afc8
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18019af50(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    undefined8 *puVar5;
    undefined8 unaff_RBP;
    uint64_t uVar6;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019af65;
    iVar4 = fcn.18045a350();
    iVar3 = -iVar4;
    iVar1 = *in_RCX;
    uVar6 = 0;
    if (in_RCX[1] != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBP;
        puVar5 = (undefined8 *)(iVar1 + iVar4);
        do {
            if ((code *)puVar5[-2] == fcn.18019ab50) {
                uVar2 = *puVar5;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019afa0;
                func_0x000180224990(uVar2, 0x1804ab2a8, 0x18b);
                uVar2 = puVar5[2];
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019afb6;
                func_0x000180224990(uVar2, 0x1804ab2a8, 0x18c);
            }
            uVar6 = uVar6 + 1;
            puVar5 = puVar5 + 7;
        } while (uVar6 < (uint64_t)in_RCX[1]);
    }
    iVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019afdd;
    func_0x000180224990(iVar1, 0x1804ab2a8, 0x18e);
    *in_RCX = 0;
    in_RCX[1] = 0;
    return;
}

// ============================================================
// Function: FUN_18019b000
// Address: 0x18019b000
// Size: 476 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8
fcn.18019b000(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
             int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    undefined4 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint16_t *puVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint16_t *puVar7;
    int64_t in_RCX;
    uint16_t **in_RDX;
    uint16_t *puVar8;
    uint32_t uVar9;
    int32_t in_R8D;
    uint16_t *puVar10;
    uint64_t in_R9;
    undefined4 uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18019b022;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar2 = *(int64_t *)((int64_t)&arg_50h + iVar6);
    iVar3 = *(int64_t *)((int64_t)&arg_58h + iVar6);
    if ((iVar2 == 0) && (iVar3 != 0)) {
        return 0;
    }
    if (in_RDX == (uint16_t **)0x0) {
        in_RDX = (uint16_t **)(*(int64_t *)(in_RCX + 0x158) + 0x80);
    }
    uVar1 = *(undefined4 *)((int64_t)&arg_48h + iVar6);
    uVar9 = (uint32_t)in_R9;
    if (uVar9 == 0x12) {
        if (((char)uVar1 < '\0') && (in_RCX != 0)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18019b071;
            iVar5 = func_0x000180191a10();
            if (iVar5 != 0) {
                return 0;
            }
        }
    } else {
        if (uVar9 < 0x3375) {
    // switch table (52 cases) at 0x18019b1a0
            switch(in_R9 & 0xffffffff) {
            default:
                goto code_r0x00018019b077;
            case 2:
            case 3:
            case 4:
            case 6:
            case 7:
            case 8:
            case 9:
            case 0xf:
            case 0x11:
            case 0x18:
            case 0x19:
            case 0x1a:
            case 0x1c:
            case 0x1d:
            case 0x1e:
            case 0x1f:
            case 0x20:
            case 0x21:
            case 0x22:
            case 0x24:
            case 0x25:
            case 0x26:
            case 0x27:
            case 0x28:
            case 0x2e:
            case 0x30:
            case 0x32:
                goto code_r0x00018019b0ce;
            }
        }
        if ((in_R9 & 0xffff0000) != 0) {
            return 0;
        }
        if (uVar9 == 0xff01) {
            return 0;
        }
    }
code_r0x00018019b0ce:
    puVar7 = in_RDX[1];
    puVar10 = (uint16_t *)0x0;
    puVar4 = *in_RDX;
    uVar11 = 0;
    puVar8 = puVar4;
    if (puVar7 != (uint16_t *)0x0) {
        do {
            if (uVar9 == *puVar8) {
                if (in_R8D == 2) {
                    return 0;
                }
                if (in_R8D == *(int32_t *)(puVar8 + 2)) {
                    return 0;
                }
                if (*(int32_t *)(puVar8 + 2) == 2) {
                    return 0;
                }
            }
            puVar10 = (uint16_t *)((int64_t)puVar10 + 1);
            puVar8 = puVar8 + 0x1c;
        } while (puVar10 < puVar7);
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18019b129;
    puVar7 = (uint16_t *)func_0x0001802249c0(puVar4, ((int64_t)puVar7 + 1) * 0x38, 0x1804ab2a8, 0x1cb);
    if (puVar7 != (uint16_t *)0x0) {
        puVar4 = in_RDX[1];
        *in_RDX = puVar7;
        puVar7[(int64_t)puVar4 * 0x1c + 1] = 0;
        *(int32_t *)(puVar7 + (int64_t)puVar4 * 0x1c + 2) = in_R8D;
        *(undefined4 *)(puVar7 + (int64_t)puVar4 * 0x1c + 4) = uVar1;
        *(undefined8 *)(puVar7 + (int64_t)puVar4 * 0x1c + 0x14) = *(undefined8 *)((int64_t)&arg_68h + iVar6);
        if (in_RCX == 0) {
            uVar11 = 4;
        }
        *(int64_t *)(puVar7 + (int64_t)puVar4 * 0x1c + 8) = iVar2;
        *(undefined8 *)(puVar7 + (int64_t)puVar4 * 0x1c + 0x10) = *(undefined8 *)((int64_t)&arg_60h + iVar6);
        *(undefined8 *)(puVar7 + (int64_t)puVar4 * 0x1c + 0x18) = *(undefined8 *)((int64_t)&arg_70h + iVar6);
        *(int64_t *)(puVar7 + (int64_t)puVar4 * 0x1c + 0xc) = iVar3;
        puVar7[(int64_t)puVar4 * 0x1c] = (uint16_t)(in_R9 & 0xffffffff);
        *(undefined4 *)(puVar7 + (int64_t)puVar4 * 0x1c + 6) = uVar11;
        in_RDX[1] = (uint16_t *)((int64_t)in_RDX[1] + 1);
        return 1;
    }
code_r0x00018019b077:
    return 0;
}

// ============================================================
// Function: FUN_18019b210
// Address: 0x18019b210
// Size: 59 bytes
// ============================================================
int32_t fcn.18019b210(int32_t *param_1)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x18019b21a;
    iVar1 = fcn.18045a350();
    if (param_1 != (int32_t *)0x0) {
        if (*param_1 == 0) {
code_r0x00018019b239:
            return param_1[0x2b];
        }
        if ((char)*param_1 < '\0') {
            *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x18019b231;
            param_1 = (int32_t *)func_0x0001801bda50();
            if (param_1 != (int32_t *)0x0) goto code_r0x00018019b239;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18019b250
// Address: 0x18019b250
// Size: 79 bytes
// ============================================================
undefined8 fcn.18019b250(int32_t *param_1)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x18019b25a;
    iVar1 = fcn.18045a350();
    if (param_1 == (int32_t *)0x0) {
        return 0;
    }
    if (*param_1 != 0) {
        if (-1 < (char)*param_1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x18019b277;
        param_1 = (int32_t *)func_0x0001801bda50(param_1);
        if (param_1 == (int32_t *)0x0) {
            return 0;
        }
    }
    if ((param_1[0x2b] == 0) && (param_1[0x26] == 0)) {
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_18019b2a0
// Address: 0x18019b2a0
// Size: 59 bytes
// ============================================================
int32_t fcn.18019b2a0(int32_t *param_1)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x18019b2aa;
    iVar1 = fcn.18045a350();
    if (param_1 != (int32_t *)0x0) {
        if (*param_1 == 0) {
code_r0x00018019b2c9:
            return param_1[0x2d];
        }
        if ((char)*param_1 < '\0') {
            *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x18019b2c1;
            param_1 = (int32_t *)func_0x0001801bda50();
            if (param_1 != (int32_t *)0x0) goto code_r0x00018019b2c9;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18019b2e0
// Address: 0x18019b2e0
// Size: 79 bytes
// ============================================================
undefined8 fcn.18019b2e0(int32_t *param_1)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x18019b2ea;
    iVar1 = fcn.18045a350();
    if (param_1 == (int32_t *)0x0) {
        return 0;
    }
    if (*param_1 != 0) {
        if (-1 < (char)*param_1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x18019b307;
        param_1 = (int32_t *)func_0x0001801bda50(param_1);
        if (param_1 == (int32_t *)0x0) {
            return 0;
        }
    }
    if ((param_1[0x2d] == 0) && (param_1[0x2b] == 1)) {
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_18019b330
// Address: 0x18019b330
// Size: 71 bytes
// ============================================================
undefined4
fcn.18019b330(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_60h, int64_t arg_68h,
             int64_t arg_70h, int64_t arg_78h)
{
    undefined8 uVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t *piVar7;
    int32_t *in_RCX;
    int32_t iVar8;
    undefined8 uVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    code *pcVar10;
    undefined4 uVar11;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    code *pcVar12;
    undefined8 unaff_R12;
    code *pcVar13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 uStack_8;
    
    uStack_8 = 0x18019b33a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX == (int32_t *)0x0) {
        return 0xffffffff;
    }
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0xffffffff;
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x18019b357;
        in_RCX = (int32_t *)func_0x0001801bda50(in_RCX);
        if (in_RCX == (int32_t *)0x0) {
            return 0xffffffff;
        }
    }
    iVar8 = 1;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RDI;
    *(undefined8 *)(&stack0x00000020 + iVar4) = unaff_R12;
    *(undefined8 *)(&stack0x00000018 + iVar4) = unaff_R14;
    *(undefined8 *)(&stack0x00000010 + iVar4) = unaff_R15;
    *(undefined8 *)(&stack0x00000008 + iVar4) = 0x18019bc54;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar1 = *(undefined8 *)(in_RCX + 0x10);
    pcVar13 = (code *)0x0;
    pcVar12 = (code *)0x0;
    uVar11 = 0xffffffff;
    if (in_RCX[0x26] == 1) {
        return 0xffffffff;
    }
    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bc7e;
    func_0x0001802203d0();
    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bc86;
    (*(code *)0x69a006)(0);
    pcVar10 = *(code **)(in_RCX + 0x256);
    if ((*(code **)(in_RCX + 0x256) == (code *)0x0) &&
       (pcVar10 = pcVar13, *(code **)(*(int64_t *)(in_RCX + 2) + 0x120) != (code *)0x0)) {
        pcVar10 = *(code **)(*(int64_t *)(in_RCX + 2) + 0x120);
    }
    in_RCX[0x2f] = in_RCX[0x2f] + 1;
    piVar7 = in_RCX;
    if (*in_RCX == 0) {
code_r0x00018019bcc9:
        if (piVar7[0x2d] == 0) goto code_r0x00018019bd00;
        piVar7 = in_RCX;
        if (*in_RCX == 0) {
code_r0x00018019bcee:
            if ((piVar7[0x2b] == 0) && (piVar7[0x26] == 0)) goto code_r0x00018019bd00;
        } else if ((char)*in_RCX < '\0') {
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bce9;
            piVar7 = (int32_t *)func_0x0001801bda50(in_RCX);
            if (piVar7 != (int32_t *)0x0) goto code_r0x00018019bcee;
        }
    } else {
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bcc4;
            piVar7 = (int32_t *)func_0x0001801bda50(in_RCX);
            if (piVar7 != (int32_t *)0x0) goto code_r0x00018019bcc9;
        }
code_r0x00018019bd00:
        if ((in_RCX[0x58] & 0x800U) == 0) {
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bd14;
            iVar2 = func_0x0001801930d0(in_RCX);
            if (iVar2 == 0) {
                return 0xffffffff;
            }
        }
    }
    iVar2 = in_RCX[0x26];
    if (iVar2 == 0) {
        *(undefined8 *)(in_RCX + 0x2b) = 0;
    } else if (iVar2 != 4) {
        while( true ) {
            while (iVar2 == 2) {
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bf40;
                iVar2 = func_0x00018019b830(in_RCX);
                pcVar12 = pcVar13;
                if (iVar2 != 1) goto code_r0x00018019c005;
code_r0x00018019bf27:
                *(undefined8 *)(in_RCX + 0x26) = 3;
                iVar2 = 3;
            }
            if (iVar2 != 3) break;
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bf58;
            iVar2 = func_0x00018019c0a0(in_RCX);
            if (iVar2 != 1) {
                pcVar12 = pcVar13;
                if (iVar2 == 2) {
                    in_RCX[0x26] = 4;
                    uVar11 = 1;
                    pcVar12 = (code *)0x0;
                }
                goto code_r0x00018019c005;
            }
            in_RCX[0x26] = 2;
            iVar2 = 2;
            in_RCX[0x29] = 0;
        }
        if ((in_RCX[0x2d] == 0) || (iVar2 != 1)) {
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bfa5;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bfbd;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_48h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bfd3;
            func_0x00018019b5e0(in_RCX, 0x50, 0x100, 0);
        }
        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bfd8;
        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bff0;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4), 
                      *(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_48h + iVar5 + iVar4), 
                      *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019c002;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
        pcVar12 = pcVar13;
        goto code_r0x00018019c005;
    }
    in_RCX[0x1e] = iVar8;
    if ((pcVar10 != (code *)0x0) &&
       ((((*(int64_t *)(in_RCX + 0x98) == 0 || (*(int64_t *)(in_RCX + 0xba) == 0)) ||
         ((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 6) + 0x36) + 0x50) & 8) != 0)) ||
        ((iVar2 = **(int32_t **)(in_RCX + 6), iVar2 < 0x304 || (iVar2 == 0x10000)))))) {
        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bd83;
        (*pcVar10)(uVar1, 0x10, 1);
    }
    if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 6) + 0xd8) + 0x50) & 8) == 0) {
        if ((in_RCX[0x12] & 0xffffff00U) == 0x300) goto code_r0x00018019be00;
        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bdf9;
        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
    } else {
        uVar3 = in_RCX[0x12] & 0xff00;
        if ((uVar3 == 0xfe00) || ((iVar8 == 0 && (uVar3 == 0x100)))) {
code_r0x00018019be00:
            *(undefined8 *)((int64_t)&arg_30h + iVar5 + iVar4) = 0;
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019be15;
            iVar2 = func_0x0001801a2690(in_RCX, 9, 0);
            if (iVar2 == 0) {
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019be1e;
                fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                              *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
            } else {
                if (*(int64_t *)(in_RCX + 0x3e) != 0) {
code_r0x00018019be72:
                    *(undefined8 *)(in_RCX + 0x42) = 0;
                    in_RCX[0x6e] = 0;
                    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019be88;
                    iVar2 = func_0x000180197970(in_RCX);
                    if (iVar2 == 0) {
                        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019be91;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
                        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bea9;
                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar5 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
                        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bebc;
                        func_0x00018019b5e0(in_RCX, 0xffffffff, 0xc0103, 0);
                        pcVar12 = pcVar13;
                        goto code_r0x00018019c005;
                    }
                    piVar7 = in_RCX;
                    if (*in_RCX == 0) {
code_r0x00018019bedd:
                        if ((piVar7[0x2b] != 0) || (piVar7[0x26] != 0)) goto code_r0x00018019beef;
                    } else {
                        if ((char)*in_RCX < '\0') {
                            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bed8;
                            piVar7 = (int32_t *)func_0x0001801bda50(in_RCX);
                            if (piVar7 != (int32_t *)0x0) goto code_r0x00018019bedd;
                        }
code_r0x00018019beef:
                        if (in_RCX[0x2e8] == 0) goto code_r0x00018019bf27;
                    }
                    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bf03;
                    iVar2 = func_0x0001801b24a0(in_RCX);
                    pcVar12 = (code *)0x0;
                    if (iVar2 != 0) {
                        if ((*(int64_t *)(in_RCX + 0x98) != 0) && (*(int64_t *)(in_RCX + 0xba) != 0))
                        goto code_r0x00018019bf27;
                        in_RCX[0x2e] = 1;
                        goto code_r0x00018019bf27;
                    }
                    goto code_r0x00018019c005;
                }
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019be33;
                pcVar12 = (code *)func_0x000180226610();
                if (pcVar12 == (code *)0x0) {
                    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019be40;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
                } else {
                    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019be57;
                    iVar6 = func_0x000180226380(pcVar12, 0x4000);
                    if (iVar6 != 0) {
                        *(code **)(in_RCX + 0x3e) = pcVar12;
                        goto code_r0x00018019be72;
                    }
                    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019be61;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
                }
            }
        } else {
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bdb8;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
            pcVar12 = pcVar13;
        }
    }
    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bdd0;
    fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4), 
                  *(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_48h + iVar5 + iVar4), 
                  *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bde3;
    func_0x00018019b5e0(in_RCX, 0xffffffff, 0xc0103, 0);
code_r0x00018019c005:
    in_RCX[0x2f] = in_RCX[0x2f] + -1;
    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019c013;
    func_0x000180226310(pcVar12);
    if (pcVar10 != (code *)0x0) {
        uVar9 = 0x2002;
        if (iVar8 == 0) {
            uVar9 = 0x1002;
        }
        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019c02f;
        (*pcVar10)(uVar1, uVar9, uVar11);
    }
    return uVar11;
}

// ============================================================
// Function: FUN_18019b3c0
// Address: 0x18019b3c0
// Size: 304 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18019b3c0(int64_t arg_28h)
{
    int32_t iVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int32_t in_EDX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019b3d0;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_EDX == -1) {
        if ((*(int32_t *)(in_RCX + 0xac) != 0x33) && (*(int32_t *)(in_RCX + 0xac) != 0x32)) {
            return 1;
        }
        *(undefined4 *)(in_RCX + 0xb4) = 1;
        if ((*(int64_t *)(in_RCX + 0xc68) != 0) &&
           (pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0xc68) + 0x80), pcVar2 != (code *)0x0)) {
            uVar3 = *(undefined8 *)(in_RCX + 0xc78);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019b42a;
            (*pcVar2)(uVar3, 1);
        }
    } else {
        if (*(int32_t *)(in_RCX + 0x78) != 0) {
            if (*(int32_t *)(in_RCX + 0xf0) != 0xc) {
                return 1;
            }
            if (*(int32_t *)(in_RCX + 0xac) != 0x32) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019b4e0;
            func_0x00018019b750();
            return 1;
        }
        iVar1 = *(int32_t *)(in_RCX + 0xac);
        if (in_EDX == 0) {
            if (iVar1 != 0x32) {
                return 1;
            }
        } else {
            if ((iVar1 != 0x33) && (iVar1 != 0x32)) {
                return 1;
            }
            if (*(int32_t *)(in_RCX + 0xf0) == 4) {
                return 1;
            }
        }
        *(undefined4 *)(in_RCX + 0xb4) = 1;
        if ((*(int64_t *)(in_RCX + 0xc68) != 0) &&
           (pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0xc68) + 0x80), pcVar2 != (code *)0x0)) {
            uVar3 = *(undefined8 *)(in_RCX + 0xc78);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019b49d;
            (*pcVar2)(uVar3, 1);
        }
        if (in_EDX == 0) {
            return 1;
        }
    }
    if (*(int32_t *)(in_RCX + 0xf0) != 3) {
        return 1;
    }
    *(undefined4 *)(in_RCX + 0xf0) = 7;
    return 1;
}

// ============================================================
// Function: FUN_18019b4f0
// Address: 0x18019b4f0
// Size: 119 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18019b4f0(int64_t arg_28h)
{
    code *pcVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019b500;
    iVar3 = fcn.18045a350();
    *(undefined4 *)(in_RCX + 0x98) = 0;
    *(undefined4 *)(in_RCX + 0xac) = 0;
    *(undefined4 *)(in_RCX + 0xb4) = 1;
    if ((*(int64_t *)(in_RCX + 0xc68) != 0) &&
       (pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0xc68) + 0x80), pcVar1 != (code *)0x0)) {
        uVar2 = *(undefined8 *)(in_RCX + 0xc78);
        *(undefined8 *)((int64_t)&uStack_10 - iVar3) = 0x18019b545;
        (*pcVar1)(uVar2, 1);
        *(undefined4 *)(in_RCX + 0xc4) = 0;
        return;
    }
    *(undefined4 *)(in_RCX + 0xc4) = 0;
    return;
}

// ============================================================
// Function: FUN_18019b570
// Address: 0x18019b570
// Size: 68 bytes
// ============================================================
undefined4 fcn.18019b570(int32_t *param_1)
{
    undefined8 uVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t *piVar7;
    int32_t iVar8;
    undefined8 uVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    code *pcVar10;
    undefined4 uVar11;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    code *pcVar12;
    undefined8 unaff_R12;
    code *pcVar13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 uStack_8;
    
    uStack_8 = 0x18019b57a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (param_1 == (int32_t *)0x0) {
        return 0xffffffff;
    }
    if (*param_1 != 0) {
        if (-1 < (char)*param_1) {
            return 0xffffffff;
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x18019b597;
        param_1 = (int32_t *)func_0x0001801bda50(param_1);
        if (param_1 == (int32_t *)0x0) {
            return 0xffffffff;
        }
    }
    iVar8 = 0;
    *(undefined8 *)(&stack0x00000030 + iVar4) = unaff_RBX;
    *(undefined8 *)(&stack0x00000038 + iVar4) = unaff_RBP;
    *(undefined8 *)(&stack0x00000040 + iVar4) = unaff_RSI;
    *(undefined8 *)(&stack0x00000048 + iVar4) = unaff_RDI;
    *(undefined8 *)(&stack0x00000020 + iVar4) = unaff_R12;
    *(undefined8 *)(&stack0x00000018 + iVar4) = unaff_R14;
    *(undefined8 *)(&stack0x00000010 + iVar4) = unaff_R15;
    *(undefined8 *)(&stack0x00000008 + iVar4) = 0x18019bc54;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar1 = *(undefined8 *)(param_1 + 0x10);
    pcVar13 = (code *)0x0;
    pcVar12 = (code *)0x0;
    uVar11 = 0xffffffff;
    if (param_1[0x26] == 1) {
        return 0xffffffff;
    }
    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bc7e;
    func_0x0001802203d0();
    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bc86;
    (*(code *)0x69a006)(0);
    pcVar10 = *(code **)(param_1 + 0x256);
    if ((*(code **)(param_1 + 0x256) == (code *)0x0) &&
       (pcVar10 = pcVar13, *(code **)(*(int64_t *)(param_1 + 2) + 0x120) != (code *)0x0)) {
        pcVar10 = *(code **)(*(int64_t *)(param_1 + 2) + 0x120);
    }
    param_1[0x2f] = param_1[0x2f] + 1;
    piVar7 = param_1;
    if (*param_1 == 0) {
code_r0x00018019bcc9:
        if (piVar7[0x2d] == 0) goto code_r0x00018019bd00;
        piVar7 = param_1;
        if (*param_1 == 0) {
code_r0x00018019bcee:
            if ((piVar7[0x2b] == 0) && (piVar7[0x26] == 0)) goto code_r0x00018019bd00;
        } else if ((char)*param_1 < '\0') {
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bce9;
            piVar7 = (int32_t *)func_0x0001801bda50(param_1);
            if (piVar7 != (int32_t *)0x0) goto code_r0x00018019bcee;
        }
    } else {
        if ((char)*param_1 < '\0') {
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bcc4;
            piVar7 = (int32_t *)func_0x0001801bda50(param_1);
            if (piVar7 != (int32_t *)0x0) goto code_r0x00018019bcc9;
        }
code_r0x00018019bd00:
        if ((param_1[0x58] & 0x800U) == 0) {
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bd14;
            iVar2 = func_0x0001801930d0(param_1);
            if (iVar2 == 0) {
                return 0xffffffff;
            }
        }
    }
    iVar2 = param_1[0x26];
    if (iVar2 == 0) {
        *(undefined8 *)(param_1 + 0x2b) = 0;
    } else if (iVar2 != 4) {
        while( true ) {
            while (iVar2 == 2) {
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bf40;
                iVar2 = func_0x00018019b830(param_1);
                pcVar12 = pcVar13;
                if (iVar2 != 1) goto code_r0x00018019c005;
code_r0x00018019bf27:
                *(undefined8 *)(param_1 + 0x26) = 3;
                iVar2 = 3;
            }
            if (iVar2 != 3) break;
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bf58;
            iVar2 = func_0x00018019c0a0(param_1);
            if (iVar2 != 1) {
                pcVar12 = pcVar13;
                if (iVar2 == 2) {
                    param_1[0x26] = 4;
                    uVar11 = 1;
                    pcVar12 = (code *)0x0;
                }
                goto code_r0x00018019c005;
            }
            param_1[0x26] = 2;
            iVar2 = 2;
            param_1[0x29] = 0;
        }
        if ((param_1[0x2d] == 0) || (iVar2 != 1)) {
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bfa5;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar5 + iVar4), *(int64_t *)(&stack0x00000038 + iVar5 + iVar4)
                         );
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bfbd;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar5 + iVar4), *(int64_t *)(&stack0x00000038 + iVar5 + iVar4)
                          , *(int64_t *)(&stack0x00000040 + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), *(int64_t *)(&stack0x00000060 + iVar5 + iVar4)
                         );
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bfd3;
            func_0x00018019b5e0(param_1, 0x50, 0x100, 0);
        }
        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bfd8;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar5 + iVar4), *(int64_t *)(&stack0x00000038 + iVar5 + iVar4));
        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bff0;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar5 + iVar4), *(int64_t *)(&stack0x00000038 + iVar5 + iVar4), 
                      *(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                      *(int64_t *)(&stack0x00000060 + iVar5 + iVar4));
        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019c002;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
        pcVar12 = pcVar13;
        goto code_r0x00018019c005;
    }
    param_1[0x1e] = iVar8;
    if ((pcVar10 != (code *)0x0) &&
       ((((*(int64_t *)(param_1 + 0x98) == 0 || (*(int64_t *)(param_1 + 0xba) == 0)) ||
         ((*(uint8_t *)(*(int64_t *)(*(int32_t **)(param_1 + 6) + 0x36) + 0x50) & 8) != 0)) ||
        ((iVar2 = **(int32_t **)(param_1 + 6), iVar2 < 0x304 || (iVar2 == 0x10000)))))) {
        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bd83;
        (*pcVar10)(uVar1, 0x10, 1);
    }
    if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(param_1 + 6) + 0xd8) + 0x50) & 8) == 0) {
        if ((param_1[0x12] & 0xffffff00U) == 0x300) goto code_r0x00018019be00;
        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bdf9;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar5 + iVar4), *(int64_t *)(&stack0x00000038 + iVar5 + iVar4));
    } else {
        uVar3 = param_1[0x12] & 0xff00;
        if ((uVar3 == 0xfe00) || ((iVar8 == 0 && (uVar3 == 0x100)))) {
code_r0x00018019be00:
            *(undefined8 *)(&stack0x00000030 + iVar5 + iVar4) = 0;
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019be15;
            iVar2 = func_0x0001801a2690(param_1, 9, 0);
            if (iVar2 == 0) {
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019be1e;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000038 + iVar5 + iVar4));
            } else {
                if (*(int64_t *)(param_1 + 0x3e) != 0) {
code_r0x00018019be72:
                    *(undefined8 *)(param_1 + 0x42) = 0;
                    param_1[0x6e] = 0;
                    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019be88;
                    iVar2 = func_0x000180197970(param_1);
                    if (iVar2 == 0) {
                        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019be91;
                        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar5 + iVar4), 
                                      *(int64_t *)(&stack0x00000038 + iVar5 + iVar4));
                        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bea9;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar5 + iVar4), 
                                      *(int64_t *)(&stack0x00000038 + iVar5 + iVar4), 
                                      *(int64_t *)(&stack0x00000040 + iVar5 + iVar4), 
                                      *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                                      *(int64_t *)(&stack0x00000060 + iVar5 + iVar4));
                        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bebc;
                        func_0x00018019b5e0(param_1, 0xffffffff, 0xc0103, 0);
                        pcVar12 = pcVar13;
                        goto code_r0x00018019c005;
                    }
                    piVar7 = param_1;
                    if (*param_1 == 0) {
code_r0x00018019bedd:
                        if ((piVar7[0x2b] != 0) || (piVar7[0x26] != 0)) goto code_r0x00018019beef;
                    } else {
                        if ((char)*param_1 < '\0') {
                            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bed8;
                            piVar7 = (int32_t *)func_0x0001801bda50(param_1);
                            if (piVar7 != (int32_t *)0x0) goto code_r0x00018019bedd;
                        }
code_r0x00018019beef:
                        if (param_1[0x2e8] == 0) goto code_r0x00018019bf27;
                    }
                    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bf03;
                    iVar2 = func_0x0001801b24a0(param_1);
                    pcVar12 = (code *)0x0;
                    if (iVar2 != 0) {
                        if ((*(int64_t *)(param_1 + 0x98) != 0) && (*(int64_t *)(param_1 + 0xba) != 0))
                        goto code_r0x00018019bf27;
                        param_1[0x2e] = 1;
                        goto code_r0x00018019bf27;
                    }
                    goto code_r0x00018019c005;
                }
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019be33;
                pcVar12 = (code *)func_0x000180226610();
                if (pcVar12 == (code *)0x0) {
                    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019be40;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000038 + iVar5 + iVar4));
                } else {
                    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019be57;
                    iVar6 = func_0x000180226380(pcVar12, 0x4000);
                    if (iVar6 != 0) {
                        *(code **)(param_1 + 0x3e) = pcVar12;
                        goto code_r0x00018019be72;
                    }
                    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019be61;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000038 + iVar5 + iVar4));
                }
            }
        } else {
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bdb8;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar5 + iVar4), *(int64_t *)(&stack0x00000038 + iVar5 + iVar4)
                         );
            pcVar12 = pcVar13;
        }
    }
    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bdd0;
    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar5 + iVar4), *(int64_t *)(&stack0x00000038 + iVar5 + iVar4), 
                  *(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                  *(int64_t *)(&stack0x00000060 + iVar5 + iVar4));
    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bde3;
    func_0x00018019b5e0(param_1, 0xffffffff, 0xc0103, 0);
code_r0x00018019c005:
    param_1[0x2f] = param_1[0x2f] + -1;
    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019c013;
    func_0x000180226310(pcVar12);
    if (pcVar10 != (code *)0x0) {
        uVar9 = 0x2002;
        if (iVar8 == 0) {
            uVar9 = 0x1002;
        }
        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019c02f;
        (*pcVar10)(uVar1, uVar9, uVar11);
    }
    return uVar11;
}

// ============================================================
// Function: FUN_18019b5e0
// Address: 0x18019b5e0
// Size: 157 bytes
// ============================================================
void fcn.18019b5e0(int64_t arg4, int64_t arg_48h)
{
    code *pcVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t in_RCX;
    uint64_t in_RDX;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18019b5f2;
    var_20h = arg4;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18019b614;
    fcn.180229700(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3));
    if ((*(int32_t *)(in_RCX + 0xb4) == 0) || (*(int32_t *)(in_RCX + 0x98) != 1)) {
        *(undefined4 *)(in_RCX + 0xb4) = 1;
        if ((*(int64_t *)(in_RCX + 0xc68) != 0) &&
           (pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0xc68) + 0x80), pcVar1 != (code *)0x0)) {
            uVar2 = *(undefined8 *)(in_RCX + 0xc78);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18019b656;
            (*pcVar1)(uVar2, 1);
        }
        *(undefined4 *)(in_RCX + 0x98) = 1;
        if ((int32_t)in_RDX != -1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18019b675;
            func_0x0001801c6e50(in_RCX, 2, in_RDX & 0xffffffff);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18019b6a0
// Address: 0x18019b6a0
// Size: 142 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18019b6a0(int64_t arg_28h, int64_t arg_30h)
{
    code *pcVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t in_RCX;
    uint64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019b6b5;
    iVar3 = fcn.18045a350();
    if ((*(int32_t *)(in_RCX + 0xb4) == 0) || (*(int32_t *)(in_RCX + 0x98) != 1)) {
        *(undefined4 *)(in_RCX + 0xb4) = 1;
        if ((*(int64_t *)(in_RCX + 0xc68) != 0) &&
           (pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0xc68) + 0x80), pcVar1 != (code *)0x0)) {
            uVar2 = *(undefined8 *)(in_RCX + 0xc78);
            *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x18019b6ff;
            (*pcVar1)(uVar2, 1);
        }
        *(undefined4 *)(in_RCX + 0x98) = 1;
        if ((int32_t)in_RDX != -1) {
            *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x18019b71e;
            func_0x0001801c6e50(in_RCX, 2, in_RDX & 0xffffffff);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18019b750
// Address: 0x18019b750
// Size: 62 bytes
// ============================================================
void fcn.18019b750(int64_t param_1, undefined4 param_2)
{
    code *UNRECOVERED_JUMPTABLE;
    
    fcn.18045a350();
    *(undefined4 *)(param_1 + 0xb4) = param_2;
    if ((*(int64_t *)(param_1 + 0xc68) != 0) &&
       (UNRECOVERED_JUMPTABLE = *(code **)(*(int64_t *)(param_1 + 0xc68) + 0x80), UNRECOVERED_JUMPTABLE != (code *)0x0))
    {
    // WARNING: Could not recover jumptable at 0x00018019b786. Too many branches
    // WARNING: Treating indirect jump as call
        (*UNRECOVERED_JUMPTABLE)(*(undefined8 *)(param_1 + 0xc78));
        return;
    }
    return;
}

// ============================================================
// Function: FUN_18019b790
// Address: 0x18019b790
// Size: 99 bytes
// ============================================================
void fcn.18019b790(int64_t param_1)
{
    code *pcVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019b79c;
    iVar3 = fcn.18045a350();
    *(undefined4 *)(param_1 + 0xb4) = 1;
    if ((*(int64_t *)(param_1 + 0xc68) != 0) &&
       (pcVar1 = *(code **)(*(int64_t *)(param_1 + 0xc68) + 0x80), pcVar1 != (code *)0x0)) {
        uVar2 = *(undefined8 *)(param_1 + 0xc78);
        *(undefined8 *)((int64_t)&uStack_10 - iVar3) = 0x18019b7d3;
        (*pcVar1)(uVar2, 1);
        *(undefined4 *)(param_1 + 0xb0) = 0x15;
        return;
    }
    *(undefined4 *)(param_1 + 0xb0) = 0x15;
    return;
}

// ============================================================
// Function: FUN_18019b830
// Address: 0x18019b830
// Size: 1020 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18019b830(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    uint8_t uVar1;
    undefined8 uVar2;
    uint64_t uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    int64_t in_RCX;
    undefined8 uVar9;
    code *pcVar10;
    code *pcVar11;
    code *pcVar12;
    code *pcVar13;
    code *pcVar14;
    bool bVar15;
    int64_t aiStackX_8 [3];
    int64_t var_20h;
    code *pcStack_40;
    int64_t var_18h;
    int64_t var_10h;
    
    pcStack_40 = (code *)0x18019b84a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    pcVar10 = *(code **)(in_RCX + 0x958);
    uVar2 = *(undefined8 *)(in_RCX + 0x40);
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = 0;
    if ((pcVar10 == (code *)0x0) &&
       (pcVar12 = *(code **)(*(int64_t *)(in_RCX + 8) + 0x120), pcVar10 = (code *)0x0, pcVar12 != (code *)0x0)) {
        pcVar10 = pcVar12;
    }
    bVar15 = *(int32_t *)(in_RCX + 0x78) == 0;
    pcVar12 = (code *)0x1801b5ad0;
    pcVar13 = (code *)0x1801b5a30;
    if (bVar15) {
        pcVar12 = (code *)0x1801ccdc0;
    }
    pcVar11 = (code *)0x1801b6340;
    if (bVar15) {
        pcVar13 = (code *)0x1801ccca0;
    }
    pcVar14 = (code *)0x1801b6760;
    if (bVar15) {
        pcVar11 = (code *)0x1801cd2d0;
        pcVar14 = (code *)0x1801cd910;
    }
    *(code **)((int64_t)&arg_48h + iVar6) = pcVar11;
    if (*(int32_t *)(in_RCX + 0xb8) != 0) {
        *(undefined4 *)(in_RCX + 0x9c8) = 1;
        *(undefined4 *)(in_RCX + 0xb8) = 0;
    }
code_r0x00018019b8f0:
    do {
        iVar5 = *(int32_t *)(in_RCX + 0xa4);
        if (iVar5 != 0) {
            if (iVar5 == 1) goto code_r0x00018019ba1c;
            if (iVar5 != 2) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar6) = 0x18019bb1e;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                goto code_r0x00018019bb23;
            }
            break;
        }
        if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
            *(undefined8 *)((int64_t)&pcStack_40 + iVar6) = 0x18019b95d;
            iVar5 = func_0x0001801b0e50(in_RCX, (int64_t)&arg_38h + iVar6);
        } else {
            *(undefined8 *)((int64_t)&pcStack_40 + iVar6) = 0x18019b956;
            iVar5 = func_0x0001801cbe80();
        }
        if (iVar5 == 0) {
            return 0;
        }
        if (pcVar10 != (code *)0x0) {
            uVar9 = 0x2001;
            if (*(int32_t *)(in_RCX + 0x78) == 0) {
                uVar9 = 0x1001;
            }
            *(undefined8 *)((int64_t)&pcStack_40 + iVar6) = 0x18019b985;
            (*pcVar10)(uVar2, uVar9, 1);
        }
        *(undefined8 *)((int64_t)&pcStack_40 + iVar6) = 0x18019b98f;
        iVar5 = (*pcVar14)(in_RCX, *(undefined4 *)((int64_t)&arg_38h + iVar6));
        if (iVar5 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&pcStack_40 + iVar6) = 0x18019b99d;
        uVar7 = (*pcVar13)(in_RCX);
        uVar3 = *(uint64_t *)(in_RCX + 0x2f0);
        if (uVar7 < uVar3) {
            *(undefined8 *)((int64_t)&pcStack_40 + iVar6) = 0x18019bbc5;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            *(undefined8 *)((int64_t)&pcStack_40 + iVar6) = 0x18019bbdd;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10));
            goto code_r0x00018019bbe8;
        }
        if (((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) && (uVar3 != 0)) {
            iVar8 = *(int64_t *)(in_RCX + 0xf8);
            uVar7 = *(int64_t *)(in_RCX + 0x100) - *(int64_t *)(iVar8 + 8);
            *(undefined8 *)((int64_t)&pcStack_40 + iVar6) = 0x18019b9e1;
            iVar8 = func_0x0001802264b0(iVar8, (int64_t)(int32_t)(uVar3 + 4));
            if ((iVar8 == 0) || (uVar3 + 4 < uVar7)) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar6) = 0x18019bb4b;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                *(undefined8 *)((int64_t)&pcStack_40 + iVar6) = 0x18019bb63;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10));
                goto code_r0x00018019bbe8;
            }
            pcVar11 = *(code **)((int64_t)&arg_48h + iVar6);
            *(uint64_t *)(in_RCX + 0x100) = *(int64_t *)(*(int64_t *)(in_RCX + 0xf8) + 8) + uVar7;
        }
        *(undefined4 *)(in_RCX + 0xa4) = 1;
code_r0x00018019ba1c:
        if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
            *(undefined8 *)((int64_t)&pcStack_40 + iVar6) = 0x18019ba41;
            iVar5 = func_0x0001801b0ba0(in_RCX, (int64_t)&arg_40h + iVar6);
        } else {
            *(undefined8 *)((int64_t)&pcStack_40 + iVar6) = 0x18019ba3a;
            iVar5 = func_0x0001801cc020();
        }
        if (iVar5 == 0) {
            return 0;
        }
        uVar3 = *(uint64_t *)((int64_t)&arg_40h + iVar6);
        *(undefined4 *)(in_RCX + 0x9c8) = 0;
        if (0x7fffffffffffffff < uVar3) {
            *(undefined8 *)((int64_t)&pcStack_40 + iVar6) = 0x18019bbb6;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
code_r0x00018019bb23:
            *(undefined8 *)((int64_t)&pcStack_40 + iVar6) = 0x18019bb36;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10));
            goto code_r0x00018019bbe8;
        }
        uVar9 = *(undefined8 *)(in_RCX + 0x100);
        *(uint64_t *)((int64_t)&var_10h + iVar6) = uVar3;
        *(undefined8 *)((int64_t)&var_18h + iVar6) = uVar9;
        *(undefined8 *)((int64_t)&pcStack_40 + iVar6) = 0x18019ba82;
        iVar5 = (*pcVar11)(in_RCX, (int64_t)&var_18h + iVar6);
        *(undefined8 *)(in_RCX + 0x108) = 0;
        if (iVar5 == 0) {
            if ((*(int32_t *)(in_RCX + 0xb4) != 0) && (*(int32_t *)(in_RCX + 0x98) == 1)) {
                return 0;
            }
            *(undefined8 *)((int64_t)&pcStack_40 + iVar6) = 0x18019bba7;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            goto code_r0x00018019bae5;
        }
        if (iVar5 == 1) {
            uVar1 = *(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50);
            goto code_r0x00018019bb7f;
        }
        if (iVar5 != 2) goto code_r0x00018019baa1;
        *(undefined4 *)(in_RCX + 0xa4) = 2;
        *(undefined4 *)(in_RCX + 0xa8) = 4;
    } while( true );
    uVar4 = *(undefined4 *)(in_RCX + 0xa8);
    *(undefined8 *)((int64_t)&pcStack_40 + iVar6) = 0x18019b918;
    uVar4 = (*pcVar12)(in_RCX, uVar4);
    *(undefined4 *)(in_RCX + 0xa8) = uVar4;
    // switch table (7 cases) at 0x18019bc10
    switch(uVar4) {
    case 0:
        if ((*(int32_t *)(in_RCX + 0xb4) != 0) && (*(int32_t *)(in_RCX + 0x98) == 1)) {
            return 0;
        }
        *(undefined8 *)((int64_t)&pcStack_40 + iVar6) = 0x18019bae0;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
code_r0x00018019bae5:
        *(undefined8 *)((int64_t)&pcStack_40 + iVar6) = 0x18019baf8;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10));
code_r0x00018019bbe8:
        *(code **)((int64_t)&pcStack_40 + iVar6) = case.0x18019b936.4;
        fcn.18019b5e0(0, *(int64_t *)((int64_t)aiStackX_8 + iVar6));
        return 0;
    case 1:
    case 3:
        uVar1 = *(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50);
code_r0x00018019bb7f:
        if ((uVar1 & 8) != 0) {
            *(undefined8 *)((int64_t)&pcStack_40 + iVar6) = 0x18019bb89;
            func_0x0001801c3040(in_RCX);
        }
        return 1;
    case 2:
code_r0x00018019baa1:
        *(undefined4 *)(in_RCX + 0xa4) = 0;
        break;
    case 4:
    case 5:
    case 6:
        return 0;
    }
    goto code_r0x00018019b8f0;
}

// ============================================================
// Function: FUN_18019bc30
// Address: 0x18019bc30
// Size: 1056 bytes
// ============================================================
undefined4
fcn.18019b330(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_60h, int64_t arg_68h,
             int64_t arg_70h, int64_t arg_78h)
{
    undefined8 uVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t *piVar7;
    int32_t *in_RCX;
    int32_t iVar8;
    undefined8 uVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    code *pcVar10;
    undefined4 uVar11;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    code *pcVar12;
    undefined8 unaff_R12;
    code *pcVar13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 uStack_8;
    
    uStack_8 = 0x18019b33a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX == (int32_t *)0x0) {
        return 0xffffffff;
    }
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0xffffffff;
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x18019b357;
        in_RCX = (int32_t *)func_0x0001801bda50(in_RCX);
        if (in_RCX == (int32_t *)0x0) {
            return 0xffffffff;
        }
    }
    iVar8 = 1;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RDI;
    *(undefined8 *)(&stack0x00000020 + iVar4) = unaff_R12;
    *(undefined8 *)(&stack0x00000018 + iVar4) = unaff_R14;
    *(undefined8 *)(&stack0x00000010 + iVar4) = unaff_R15;
    *(undefined8 *)(&stack0x00000008 + iVar4) = 0x18019bc54;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar1 = *(undefined8 *)(in_RCX + 0x10);
    pcVar13 = (code *)0x0;
    pcVar12 = (code *)0x0;
    uVar11 = 0xffffffff;
    if (in_RCX[0x26] == 1) {
        return 0xffffffff;
    }
    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bc7e;
    func_0x0001802203d0();
    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bc86;
    (*(code *)0x69a006)(0);
    pcVar10 = *(code **)(in_RCX + 0x256);
    if ((*(code **)(in_RCX + 0x256) == (code *)0x0) &&
       (pcVar10 = pcVar13, *(code **)(*(int64_t *)(in_RCX + 2) + 0x120) != (code *)0x0)) {
        pcVar10 = *(code **)(*(int64_t *)(in_RCX + 2) + 0x120);
    }
    in_RCX[0x2f] = in_RCX[0x2f] + 1;
    piVar7 = in_RCX;
    if (*in_RCX == 0) {
code_r0x00018019bcc9:
        if (piVar7[0x2d] == 0) goto code_r0x00018019bd00;
        piVar7 = in_RCX;
        if (*in_RCX == 0) {
code_r0x00018019bcee:
            if ((piVar7[0x2b] == 0) && (piVar7[0x26] == 0)) goto code_r0x00018019bd00;
        } else if ((char)*in_RCX < '\0') {
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bce9;
            piVar7 = (int32_t *)func_0x0001801bda50(in_RCX);
            if (piVar7 != (int32_t *)0x0) goto code_r0x00018019bcee;
        }
    } else {
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bcc4;
            piVar7 = (int32_t *)func_0x0001801bda50(in_RCX);
            if (piVar7 != (int32_t *)0x0) goto code_r0x00018019bcc9;
        }
code_r0x00018019bd00:
        if ((in_RCX[0x58] & 0x800U) == 0) {
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bd14;
            iVar2 = func_0x0001801930d0(in_RCX);
            if (iVar2 == 0) {
                return 0xffffffff;
            }
        }
    }
    iVar2 = in_RCX[0x26];
    if (iVar2 == 0) {
        *(undefined8 *)(in_RCX + 0x2b) = 0;
    } else if (iVar2 != 4) {
        while( true ) {
            while (iVar2 == 2) {
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bf40;
                iVar2 = fcn.18019b830(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar5 + iVar4), 
                                      *(int64_t *)(&stack0x00000050 + iVar5 + iVar4), 
                                      *(int64_t *)(&stack0x00000058 + iVar5 + iVar4));
                pcVar12 = pcVar13;
                if (iVar2 != 1) goto code_r0x00018019c005;
code_r0x00018019bf27:
                *(undefined8 *)(in_RCX + 0x26) = 3;
                iVar2 = 3;
            }
            if (iVar2 != 3) break;
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bf58;
            iVar2 = func_0x00018019c0a0(in_RCX);
            if (iVar2 != 1) {
                pcVar12 = pcVar13;
                if (iVar2 == 2) {
                    in_RCX[0x26] = 4;
                    uVar11 = 1;
                    pcVar12 = (code *)0x0;
                }
                goto code_r0x00018019c005;
            }
            in_RCX[0x26] = 2;
            iVar2 = 2;
            in_RCX[0x29] = 0;
        }
        if ((in_RCX[0x2d] == 0) || (iVar2 != 1)) {
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bfa5;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bfbd;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_48h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bfd3;
            fcn.18019b5e0(0, *(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
        }
        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bfd8;
        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bff0;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4), 
                      *(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_48h + iVar5 + iVar4), 
                      *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019c002;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
        pcVar12 = pcVar13;
        goto code_r0x00018019c005;
    }
    in_RCX[0x1e] = iVar8;
    if ((pcVar10 != (code *)0x0) &&
       ((((*(int64_t *)(in_RCX + 0x98) == 0 || (*(int64_t *)(in_RCX + 0xba) == 0)) ||
         ((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 6) + 0x36) + 0x50) & 8) != 0)) ||
        ((iVar2 = **(int32_t **)(in_RCX + 6), iVar2 < 0x304 || (iVar2 == 0x10000)))))) {
        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bd83;
        (*pcVar10)(uVar1, 0x10, 1);
    }
    if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 6) + 0xd8) + 0x50) & 8) == 0) {
        if ((in_RCX[0x12] & 0xffffff00U) == 0x300) goto code_r0x00018019be00;
        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bdf9;
        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
    } else {
        uVar3 = in_RCX[0x12] & 0xff00;
        if ((uVar3 == 0xfe00) || ((iVar8 == 0 && (uVar3 == 0x100)))) {
code_r0x00018019be00:
            *(undefined8 *)((int64_t)&arg_30h + iVar5 + iVar4) = 0;
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019be15;
            iVar2 = func_0x0001801a2690(in_RCX, 9, 0);
            if (iVar2 == 0) {
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019be1e;
                fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                              *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
            } else {
                if (*(int64_t *)(in_RCX + 0x3e) != 0) {
code_r0x00018019be72:
                    *(undefined8 *)(in_RCX + 0x42) = 0;
                    in_RCX[0x6e] = 0;
                    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019be88;
                    iVar2 = func_0x000180197970(in_RCX);
                    if (iVar2 == 0) {
                        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019be91;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
                        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bea9;
                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar5 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
                        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bebc;
                        fcn.18019b5e0(0, *(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
                        pcVar12 = pcVar13;
                        goto code_r0x00018019c005;
                    }
                    piVar7 = in_RCX;
                    if (*in_RCX == 0) {
code_r0x00018019bedd:
                        if ((piVar7[0x2b] != 0) || (piVar7[0x26] != 0)) goto code_r0x00018019beef;
                    } else {
                        if ((char)*in_RCX < '\0') {
                            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bed8;
                            piVar7 = (int32_t *)func_0x0001801bda50(in_RCX);
                            if (piVar7 != (int32_t *)0x0) goto code_r0x00018019bedd;
                        }
code_r0x00018019beef:
                        if (in_RCX[0x2e8] == 0) goto code_r0x00018019bf27;
                    }
                    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bf03;
                    iVar2 = func_0x0001801b24a0(in_RCX);
                    pcVar12 = (code *)0x0;
                    if (iVar2 != 0) {
                        if ((*(int64_t *)(in_RCX + 0x98) != 0) && (*(int64_t *)(in_RCX + 0xba) != 0))
                        goto code_r0x00018019bf27;
                        in_RCX[0x2e] = 1;
                        goto code_r0x00018019bf27;
                    }
                    goto code_r0x00018019c005;
                }
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019be33;
                pcVar12 = (code *)func_0x000180226610();
                if (pcVar12 == (code *)0x0) {
                    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019be40;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
                } else {
                    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019be57;
                    iVar6 = func_0x000180226380(pcVar12, 0x4000);
                    if (iVar6 != 0) {
                        *(code **)(in_RCX + 0x3e) = pcVar12;
                        goto code_r0x00018019be72;
                    }
                    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019be61;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
                }
            }
        } else {
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bdb8;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
            pcVar12 = pcVar13;
        }
    }
    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bdd0;
    fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4), 
                  *(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_48h + iVar5 + iVar4), 
                  *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019bde3;
    fcn.18019b5e0(0, *(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
code_r0x00018019c005:
    in_RCX[0x2f] = in_RCX[0x2f] + -1;
    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019c013;
    func_0x000180226310(pcVar12);
    if (pcVar10 != (code *)0x0) {
        uVar9 = 0x2002;
        if (iVar8 == 0) {
            uVar9 = 0x1002;
        }
        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar4) = 0x18019c02f;
        (*pcVar10)(uVar1, uVar9, uVar11);
    }
    return uVar11;
}

// ============================================================
// Function: FUN_18019c050
// Address: 0x18019c050
// Size: 75 bytes
// ============================================================
undefined8 fcn.18019c050(int64_t param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019c05c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined4 *)(param_1 + 0x68) = 2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019c07d;
    iVar1 = fcn.180219d10(*(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
    if (iVar1 < 1) {
        return 0;
    }
    *(undefined4 *)(param_1 + 0x68) = 1;
    return 1;
}

// ============================================================
// Function: FUN_18019c0a0
// Address: 0x18019c0a0
// Size: 1156 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18019c0a0(int64_t arg_68h, int64_t arg_70h, int64_t arg_78h)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 uVar6;
    code *pcVar7;
    code *pcVar8;
    code *pcVar9;
    code *pcVar10;
    code *pcVar11;
    bool bVar12;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    code *pcStack_40;
    
    pcStack_40 = (code *)0x18019c0ba;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    pcVar8 = *(code **)(in_RCX + 0x958);
    uVar1 = *(undefined8 *)(in_RCX + 0x40);
    if ((pcVar8 == (code *)0x0) && (pcVar10 = *(code **)(*(int64_t *)(in_RCX + 8) + 0x120), pcVar10 != (code *)0x0)) {
        pcVar8 = pcVar10;
    }
    bVar12 = *(int32_t *)(in_RCX + 0x78) == 0;
    pcVar11 = (code *)0x1801b5790;
    pcVar10 = (code *)0x1801b5bd0;
    if (bVar12) {
        pcVar11 = (code *)0x1801cca90;
    }
    pcVar9 = (code *)0x1801b6060;
    if (bVar12) {
        pcVar10 = (code *)0x1801cce40;
    }
    pcVar7 = (code *)0x1801b6bb0;
    if (bVar12) {
        pcVar9 = (code *)0x1801cd170;
        pcVar7 = (code *)0x1801cdf30;
    }
code_r0x00018019c140:
    while (iVar3 = *(int32_t *)(in_RCX + 0x9c), iVar3 == 0) {
        if (pcVar8 != (code *)0x0) {
            uVar6 = 0x2001;
            if (*(int32_t *)(in_RCX + 0x78) == 0) {
                uVar6 = 0x1001;
            }
            *(undefined8 *)((int64_t)&pcStack_40 + iVar5) = 0x18019c3a1;
            (*pcVar8)(uVar1, uVar6, 1);
        }
        *(undefined8 *)((int64_t)&pcStack_40 + iVar5) = 0x18019c3a6;
        iVar3 = (*pcVar7)(in_RCX);
        if (iVar3 == 0) {
            if ((*(int32_t *)(in_RCX + 0xb4) != 0) && (*(int32_t *)(in_RCX + 0x98) == 1)) {
                return 0;
            }
            *(undefined8 *)((int64_t)&pcStack_40 + iVar5) = 0x18019c4a4;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), *(int64_t *)(&stack0xfffffffffffffff0 + iVar5)
                         );
            goto code_r0x00018019c4a9;
        }
        if (iVar3 == 1) {
            *(undefined4 *)(in_RCX + 0x9c) = 1;
            *(undefined4 *)(in_RCX + 0xa0) = 4;
        } else if (iVar3 == 2) {
code_r0x00018019c4d4:
            return 1;
        }
    }
    if (iVar3 == 1) {
        uVar4 = *(undefined4 *)(in_RCX + 0xa0);
        *(undefined8 *)((int64_t)&pcStack_40 + iVar5) = 0x18019c199;
        uVar4 = (*pcVar9)(in_RCX, uVar4);
        *(undefined4 *)(in_RCX + 0xa0) = uVar4;
    // switch table (7 cases) at 0x18019c4ec
        switch(uVar4) {
        case 0:
            if ((*(int32_t *)(in_RCX + 0xb4) != 0) && (*(int32_t *)(in_RCX + 0x98) == 1)) {
                return 0;
            }
            *(undefined8 *)((int64_t)&pcStack_40 + iVar5) = 0x18019c3fc;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), *(int64_t *)(&stack0xfffffffffffffff0 + iVar5)
                         );
            goto code_r0x00018019c4a9;
        case 1:
            goto code_r0x00018019c4d4;
        case 2:
            *(undefined4 *)(in_RCX + 0x9c) = 2;
            break;
        case 3:
            goto code_r0x00018019c4d4;
        case 4:
        case 5:
        case 6:
            goto code_r0x00018019c4d4;
        }
        *(undefined8 *)((int64_t)&pcStack_40 + iVar5) = 0x18019c1d3;
        iVar3 = (*pcVar11)(in_RCX, (int64_t)&arg_70h + iVar5, (int64_t)&arg_68h + iVar5);
        if (iVar3 == 0) {
            return 0;
        }
        if (*(int32_t *)((int64_t)&arg_68h + iVar5) == -1) {
            *(undefined4 *)(in_RCX + 0x9c) = 3;
            *(undefined4 *)(in_RCX + 0xa0) = 4;
            goto code_r0x00018019c140;
        }
        uVar6 = *(undefined8 *)(in_RCX + 0xf8);
        *(undefined8 *)((int64_t)&pcStack_40 + iVar5) = 0x18019c20f;
        iVar3 = func_0x000180244300(&stack0xffffffffffffffe8 + iVar5, uVar6);
        if (iVar3 != 0) {
            pcVar2 = *(code **)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x58);
            *(undefined8 *)((int64_t)&pcStack_40 + iVar5) = 0x18019c238;
            iVar3 = (*pcVar2)(in_RCX, &stack0xffffffffffffffe8 + iVar5, *(undefined4 *)((int64_t)&arg_68h + iVar5));
            if (iVar3 != 0) {
                if (*(code **)((int64_t)&arg_70h + iVar5) != (code *)0x0) {
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar5) = 0x18019c257;
                    iVar3 = (**(code **)((int64_t)&arg_70h + iVar5))(in_RCX, &stack0xffffffffffffffe8 + iVar5);
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&pcStack_40 + iVar5) = 0x18019c410;
                        func_0x000180243fb0(&stack0xffffffffffffffe8 + iVar5);
                        if ((*(int32_t *)(in_RCX + 0xb4) != 0) && (*(int32_t *)(in_RCX + 0x98) == 1)) {
                            return 0;
                        }
                        *(undefined8 *)((int64_t)&pcStack_40 + iVar5) = 0x18019c42b;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar5));
                        goto code_r0x00018019c4a9;
                    }
                    if (iVar3 == 2) {
                        *(undefined8 *)((int64_t)&pcStack_40 + iVar5) = 0x18019c26e;
                        func_0x000180243fb0(&stack0xffffffffffffffe8 + iVar5);
                        *(undefined4 *)(in_RCX + 0x9c) = 3;
                        *(undefined4 *)(in_RCX + 0xa0) = 4;
                        goto code_r0x00018019c140;
                    }
                }
                pcVar2 = *(code **)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x60);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar5) = 0x18019c2a8;
                iVar3 = (*pcVar2)(in_RCX, &stack0xffffffffffffffe8 + iVar5, *(undefined4 *)((int64_t)&arg_68h + iVar5));
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar5) = 0x18019c2ba;
                    iVar3 = func_0x000180244200(&stack0xffffffffffffffe8 + iVar5);
                    if (iVar3 != 0) goto code_r0x00018019c2c2;
                }
                *(undefined8 *)((int64_t)&pcStack_40 + iVar5) = 0x18019c465;
                func_0x000180243fb0(&stack0xffffffffffffffe8 + iVar5);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar5) = 0x18019c46a;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar5));
                goto code_r0x00018019c16f;
            }
        }
        *(undefined8 *)((int64_t)&pcStack_40 + iVar5) = 0x18019c47e;
        func_0x000180243fb0(&stack0xffffffffffffffe8 + iVar5);
        *(undefined8 *)((int64_t)&pcStack_40 + iVar5) = 0x18019c483;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), *(int64_t *)(&stack0xfffffffffffffff0 + iVar5));
code_r0x00018019c16f:
        *(undefined8 *)((int64_t)&pcStack_40 + iVar5) = 0x18019c182;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), *(int64_t *)(&stack0xfffffffffffffff0 + iVar5), 
                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                      *(int64_t *)((int64_t)&var_18h + iVar5));
    } else {
        if (iVar3 == 2) {
code_r0x00018019c2c2:
            if (((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) != 0) &&
               (*(int32_t *)(in_RCX + 200) != 0)) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar5) = 0x18019c2e4;
                func_0x0001801c2f70(in_RCX);
            }
            if ((*(int32_t *)(in_RCX + 0xac) == 0x12) || (*(int32_t *)(in_RCX + 0xac) == 0x27)) {
                if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar5) = 0x18019c32c;
                    iVar3 = func_0x0001801aea80(in_RCX, 0x14);
                } else {
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar5) = 0x18019c325;
                    iVar3 = func_0x0001801ca8a0();
                }
            } else {
                pcVar2 = *(code **)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x68);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar5) = 0x18019c308;
                iVar3 = (*pcVar2)(in_RCX);
            }
            if (iVar3 < 1) {
                return 0;
            }
            *(undefined4 *)(in_RCX + 0x9c) = 3;
            *(undefined4 *)(in_RCX + 0xa0) = 4;
        } else if (iVar3 != 3) {
            *(undefined8 *)((int64_t)&pcStack_40 + iVar5) = 0x18019c16a;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), *(int64_t *)(&stack0xfffffffffffffff0 + iVar5)
                         );
            goto code_r0x00018019c16f;
        }
        uVar4 = *(undefined4 *)(in_RCX + 0xa0);
        *(undefined8 *)((int64_t)&pcStack_40 + iVar5) = 0x18019c354;
        uVar4 = (*pcVar10)(in_RCX, uVar4);
        *(undefined4 *)(in_RCX + 0xa0) = uVar4;
    // switch table (7 cases) at 0x18019c508
        switch(uVar4) {
        case 0:
            if ((*(int32_t *)(in_RCX + 0xb4) != 0) && (*(int32_t *)(in_RCX + 0x98) == 1)) {
                return 0;
            }
            *(undefined8 *)((int64_t)&pcStack_40 + iVar5) = 0x18019c44d;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), *(int64_t *)(&stack0xfffffffffffffff0 + iVar5)
                         );
code_r0x00018019c4a9:
            *(undefined8 *)((int64_t)&pcStack_40 + iVar5) = 0x18019c4bc;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), *(int64_t *)(&stack0xfffffffffffffff0 + iVar5)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                          *(int64_t *)((int64_t)&var_18h + iVar5));
            break;
        case 1:
code_r0x00018019c4d4:
            return 2;
        case 2:
            *(undefined4 *)(in_RCX + 0x9c) = 0;
            goto code_r0x00018019c140;
        case 3:
            goto code_r0x00018019c4d4;
        case 4:
        case 5:
        case 6:
            goto code_r0x00018019c4d4;
        default:
            goto code_r0x00018019c140;
        }
    }
    *(code **)((int64_t)&pcStack_40 + iVar5) = case.0x18019c370.4;
    fcn.18019b5e0(0, *(int64_t *)((int64_t)aiStackX_8 + iVar5));
code_r0x00018019c4d4:
    return 0;
}

// ============================================================
// Function: FUN_18019c530
// Address: 0x18019c530
// Size: 261 bytes
// ============================================================
undefined8 fcn.18019c530(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t *piVar1;
    undefined8 uVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 uVar10;
    undefined8 unaff_R15;
    bool bVar11;
    int64_t aiStackX_8 [4];
    undefined8 uStack_20;
    
    uStack_20 = 0x18019c540;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar10 = 0;
    LOCK();
    piVar1 = (int32_t *)(in_RDX + 0x390);
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    if (1 < iVar4 + 1) {
        uVar2 = *(undefined8 *)(in_RCX + 0x3e0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c56c;
        iVar4 = fcn.180222950(uVar2);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBP;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c595;
            iVar7 = fcn.180228fb0(*(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar6));
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c5c5;
                iVar9 = fcn.180229240(*(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
                if (iVar9 == 0) {
                    iVar7 = in_RDX;
                }
            } else if (iVar7 != in_RDX) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c5ad;
                fcn.18019cc80(in_RCX, iVar7);
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c5b5;
                fcn.18019c980(iVar7);
                iVar7 = 0;
            }
            if ((*(uint32_t *)(in_RCX + 0x50) & 0x400) != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c5da;
                iVar8 = fcn.1802450c0(*(int64_t *)((int64_t)aiStackX_8 + iVar6), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10));
                *(int64_t *)(in_RDX + 0x2e0) = iVar8;
                iVar9 = -1;
                if (*(uint64_t *)(in_RDX + 0x2d8) <= -iVar8 - 1U) {
                    iVar9 = iVar8 + *(uint64_t *)(in_RDX + 0x2d8);
                }
                *(int64_t *)(in_RDX + 0x2e8) = iVar9;
            }
            if (iVar7 == 0) {
                uVar10 = 1;
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c62a;
                iVar4 = fcn.180191a20(*(int64_t *)((int64_t)aiStackX_8 + iVar6), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)(&stack0x000000b8 + iVar6), 
                                      *(int64_t *)(&stack0x000000c0 + iVar6), *(int64_t *)(&stack0x000000d0 + iVar6), 
                                      *(int64_t *)(&stack0x000001d0 + iVar6));
                if (0 < iVar4) {
                    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c64a;
                    iVar4 = fcn.180191a20(*(int64_t *)((int64_t)aiStackX_8 + iVar6), 
                                          *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                                          *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                          *(int64_t *)(&stack0x000000b8 + iVar6), *(int64_t *)(&stack0x000000c0 + iVar6)
                                          , *(int64_t *)(&stack0x000000d0 + iVar6), 
                                          *(int64_t *)(&stack0x000001d0 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c65f;
                    iVar5 = fcn.180191a20(*(int64_t *)((int64_t)aiStackX_8 + iVar6), 
                                          *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                                          *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                          *(int64_t *)(&stack0x000000b8 + iVar6), *(int64_t *)(&stack0x000000c0 + iVar6)
                                          , *(int64_t *)(&stack0x000000d0 + iVar6), 
                                          *(int64_t *)(&stack0x000001d0 + iVar6));
                    if (iVar4 <= iVar5) {
                        *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_R15;
                        *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RSI;
                        do {
                            iVar9 = *(int64_t *)(in_RCX + 0x48);
                            if ((iVar9 == 0) || (*(int64_t *)(iVar9 + 0x250) == 0)) break;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c6a9;
                            iVar8 = fcn.180229240(*(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
                            bVar11 = iVar8 == 0;
                            if (!bVar11) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c6c0;
                                iVar8 = fcn.180228b10(*(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), 
                                                      *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), 
                                                      *(int64_t *)((int64_t)&arg_28h + iVar6));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c6ce;
                                fcn.18019cc80(in_RCX, iVar8);
                            }
                            *(undefined4 *)(iVar9 + 0x2b0) = 1;
                            pcVar3 = *(code **)(in_RCX + 0x68);
                            if (pcVar3 != (code *)0x0) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c6e6;
                                (*pcVar3)(in_RCX, iVar9);
                            }
                            if (bVar11) break;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c6f3;
                            fcn.18019c980(iVar8);
                            LOCK();
                            *(int32_t *)(in_RCX + 0x98) = *(int32_t *)(in_RCX + 0x98) + 1;
                            UNLOCK();
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c70d;
                            iVar4 = fcn.180191a20(*(int64_t *)((int64_t)aiStackX_8 + iVar6), 
                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                                  *(int64_t *)(&stack0x000000b8 + iVar6), 
                                                  *(int64_t *)(&stack0x000000c0 + iVar6), 
                                                  *(int64_t *)(&stack0x000000d0 + iVar6), 
                                                  *(int64_t *)(&stack0x000001d0 + iVar6));
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c722;
                            iVar5 = fcn.180191a20(*(int64_t *)((int64_t)aiStackX_8 + iVar6), 
                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                                  *(int64_t *)(&stack0x000000b8 + iVar6), 
                                                  *(int64_t *)(&stack0x000000c0 + iVar6), 
                                                  *(int64_t *)(&stack0x000000d0 + iVar6), 
                                                  *(int64_t *)(&stack0x000001d0 + iVar6));
                        } while (iVar4 <= iVar5);
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c744;
            fcn.18019cb50(in_RCX, in_RDX);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c751;
                fcn.18019c980(iVar7);
                uVar10 = 0;
            }
            uVar2 = *(undefined8 *)(in_RCX + 0x3e0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c760;
            fcn.180222910(uVar2);
            return uVar10;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c578;
        fcn.18019c980(in_RDX);
    }
    return 0;
}

// ============================================================
// Function: FUN_18019c635
// Address: 0x18019c635
// Size: 50 bytes
// ============================================================
undefined8 fcn.18019c530(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t *piVar1;
    undefined8 uVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 uVar10;
    undefined8 unaff_R15;
    bool bVar11;
    int64_t aiStackX_8 [4];
    undefined8 uStack_20;
    
    uStack_20 = 0x18019c540;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar10 = 0;
    LOCK();
    piVar1 = (int32_t *)(in_RDX + 0x390);
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    if (1 < iVar4 + 1) {
        uVar2 = *(undefined8 *)(in_RCX + 0x3e0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c56c;
        iVar4 = fcn.180222950(uVar2);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBP;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c595;
            iVar7 = fcn.180228fb0(*(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar6));
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c5c5;
                iVar9 = fcn.180229240(*(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
                if (iVar9 == 0) {
                    iVar7 = in_RDX;
                }
            } else if (iVar7 != in_RDX) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c5ad;
                fcn.18019cc80(in_RCX, iVar7);
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c5b5;
                fcn.18019c980(iVar7);
                iVar7 = 0;
            }
            if ((*(uint32_t *)(in_RCX + 0x50) & 0x400) != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c5da;
                iVar8 = fcn.1802450c0(*(int64_t *)((int64_t)aiStackX_8 + iVar6), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10));
                *(int64_t *)(in_RDX + 0x2e0) = iVar8;
                iVar9 = -1;
                if (*(uint64_t *)(in_RDX + 0x2d8) <= -iVar8 - 1U) {
                    iVar9 = iVar8 + *(uint64_t *)(in_RDX + 0x2d8);
                }
                *(int64_t *)(in_RDX + 0x2e8) = iVar9;
            }
            if (iVar7 == 0) {
                uVar10 = 1;
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c62a;
                iVar4 = fcn.180191a20(*(int64_t *)((int64_t)aiStackX_8 + iVar6), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)(&stack0x000000b8 + iVar6), 
                                      *(int64_t *)(&stack0x000000c0 + iVar6), *(int64_t *)(&stack0x000000d0 + iVar6), 
                                      *(int64_t *)(&stack0x000001d0 + iVar6));
                if (0 < iVar4) {
                    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c64a;
                    iVar4 = fcn.180191a20(*(int64_t *)((int64_t)aiStackX_8 + iVar6), 
                                          *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                                          *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                          *(int64_t *)(&stack0x000000b8 + iVar6), *(int64_t *)(&stack0x000000c0 + iVar6)
                                          , *(int64_t *)(&stack0x000000d0 + iVar6), 
                                          *(int64_t *)(&stack0x000001d0 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c65f;
                    iVar5 = fcn.180191a20(*(int64_t *)((int64_t)aiStackX_8 + iVar6), 
                                          *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                                          *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                          *(int64_t *)(&stack0x000000b8 + iVar6), *(int64_t *)(&stack0x000000c0 + iVar6)
                                          , *(int64_t *)(&stack0x000000d0 + iVar6), 
                                          *(int64_t *)(&stack0x000001d0 + iVar6));
                    if (iVar4 <= iVar5) {
                        *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_R15;
                        *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RSI;
                        do {
                            iVar9 = *(int64_t *)(in_RCX + 0x48);
                            if ((iVar9 == 0) || (*(int64_t *)(iVar9 + 0x250) == 0)) break;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c6a9;
                            iVar8 = fcn.180229240(*(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
                            bVar11 = iVar8 == 0;
                            if (!bVar11) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c6c0;
                                iVar8 = fcn.180228b10(*(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), 
                                                      *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), 
                                                      *(int64_t *)((int64_t)&arg_28h + iVar6));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c6ce;
                                fcn.18019cc80(in_RCX, iVar8);
                            }
                            *(undefined4 *)(iVar9 + 0x2b0) = 1;
                            pcVar3 = *(code **)(in_RCX + 0x68);
                            if (pcVar3 != (code *)0x0) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c6e6;
                                (*pcVar3)(in_RCX, iVar9);
                            }
                            if (bVar11) break;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c6f3;
                            fcn.18019c980(iVar8);
                            LOCK();
                            *(int32_t *)(in_RCX + 0x98) = *(int32_t *)(in_RCX + 0x98) + 1;
                            UNLOCK();
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c70d;
                            iVar4 = fcn.180191a20(*(int64_t *)((int64_t)aiStackX_8 + iVar6), 
                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                                  *(int64_t *)(&stack0x000000b8 + iVar6), 
                                                  *(int64_t *)(&stack0x000000c0 + iVar6), 
                                                  *(int64_t *)(&stack0x000000d0 + iVar6), 
                                                  *(int64_t *)(&stack0x000001d0 + iVar6));
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c722;
                            iVar5 = fcn.180191a20(*(int64_t *)((int64_t)aiStackX_8 + iVar6), 
                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                                  *(int64_t *)(&stack0x000000b8 + iVar6), 
                                                  *(int64_t *)(&stack0x000000c0 + iVar6), 
                                                  *(int64_t *)(&stack0x000000d0 + iVar6), 
                                                  *(int64_t *)(&stack0x000001d0 + iVar6));
                        } while (iVar4 <= iVar5);
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c744;
            fcn.18019cb50(in_RCX, in_RDX);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c751;
                fcn.18019c980(iVar7);
                uVar10 = 0;
            }
            uVar2 = *(undefined8 *)(in_RCX + 0x3e0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c760;
            fcn.180222910(uVar2);
            return uVar10;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18019c578;
        fcn.18019c980(in_RDX);
    }
    return 0;
}

