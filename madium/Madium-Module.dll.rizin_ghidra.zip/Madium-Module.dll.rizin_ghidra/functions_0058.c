// Chunk 58 - 50 functions

// ============================================================
// Function: FUN_1800c0314
// Address: 0x1800c0314
// Size: 126 bytes
// ============================================================
uint64_t * fcn.1800c0314(int64_t arg_38h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t *puVar6;
    int64_t *unaff_RBX;
    int64_t unaff_RDI;
    uint64_t in_R11;
    int64_t unaff_R14;
    uint64_t *unaff_R15;
    
    do {
        uVar1 = *(uint64_t *)(*unaff_RBX + in_R11 * 8);
        if (uVar1 != unaff_RBX[3]) {
            uVar4 = (uVar1 >> 5 ^ uVar1) >> 4;
            uVar5 = 0;
            do {
                uVar4 = uVar4 & unaff_R14 - 1U;
                uVar2 = *(uint64_t *)(unaff_RDI + uVar4 * 8);
                puVar6 = (uint64_t *)(unaff_RDI + uVar4 * 8);
                if (uVar2 == arg_38h) {
                    *puVar6 = uVar1;
                    goto code_r0x0001800c037a;
                }
                if (uVar2 == uVar1) goto code_r0x0001800c037a;
                uVar4 = uVar4 + 1 + uVar5;
                uVar5 = uVar5 + 1;
            } while (uVar5 <= unaff_R14 - 1U);
            puVar6 = (uint64_t *)0x0;
code_r0x0001800c037a:
            *puVar6 = *(uint64_t *)(*unaff_RBX + in_R11 * 8);
        }
        in_R11 = in_R11 + 1;
        if ((uint64_t)unaff_RBX[1] <= in_R11) {
            iVar3 = *unaff_RBX;
            unaff_RBX[1] = unaff_R14;
            *unaff_RBX = unaff_RDI;
            if (iVar3 != 0) {
                func_0x0001800f4640();
            }
            uVar1 = *unaff_R15;
            uVar4 = (uVar1 >> 5 ^ uVar1) >> 4;
            uVar5 = 0;
            while( true ) {
                uVar4 = uVar4 & unaff_RBX[1] - 1U;
                uVar2 = *(uint64_t *)(*unaff_RBX + uVar4 * 8);
                puVar6 = (uint64_t *)(*unaff_RBX + uVar4 * 8);
                if (uVar2 == unaff_RBX[3]) {
                    *puVar6 = uVar1;
                    unaff_RBX[2] = unaff_RBX[2] + 1;
                    return puVar6;
                }
                if (uVar2 == uVar1) break;
                uVar4 = uVar4 + 1 + uVar5;
                uVar5 = uVar5 + 1;
                if (unaff_RBX[1] - 1U < uVar5) {
                    return (uint64_t *)0x0;
                }
            }
            return puVar6;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1800c0392
// Address: 0x1800c0392
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_78h

uint64_t * fcn.1800c0314(int64_t arg_38h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t *puVar6;
    int64_t *unaff_RBX;
    int64_t unaff_RDI;
    uint64_t in_R11;
    int64_t unaff_R14;
    uint64_t *unaff_R15;
    
    do {
        uVar1 = *(uint64_t *)(*unaff_RBX + in_R11 * 8);
        if (uVar1 != unaff_RBX[3]) {
            uVar4 = (uVar1 >> 5 ^ uVar1) >> 4;
            uVar5 = 0;
            do {
                uVar4 = uVar4 & unaff_R14 - 1U;
                uVar2 = *(uint64_t *)(unaff_RDI + uVar4 * 8);
                puVar6 = (uint64_t *)(unaff_RDI + uVar4 * 8);
                if (uVar2 == arg_38h) {
                    *puVar6 = uVar1;
                    goto code_r0x0001800c037a;
                }
                if (uVar2 == uVar1) goto code_r0x0001800c037a;
                uVar4 = uVar4 + 1 + uVar5;
                uVar5 = uVar5 + 1;
            } while (uVar5 <= unaff_R14 - 1U);
            puVar6 = (uint64_t *)0x0;
code_r0x0001800c037a:
            *puVar6 = *(uint64_t *)(*unaff_RBX + in_R11 * 8);
        }
        in_R11 = in_R11 + 1;
        if ((uint64_t)unaff_RBX[1] <= in_R11) {
            iVar3 = *unaff_RBX;
            unaff_RBX[1] = unaff_R14;
            *unaff_RBX = unaff_RDI;
            if (iVar3 != 0) {
                func_0x0001800f4640();
            }
            uVar1 = *unaff_R15;
            uVar4 = (uVar1 >> 5 ^ uVar1) >> 4;
            uVar5 = 0;
            while( true ) {
                uVar4 = uVar4 & unaff_RBX[1] - 1U;
                uVar2 = *(uint64_t *)(*unaff_RBX + uVar4 * 8);
                puVar6 = (uint64_t *)(*unaff_RBX + uVar4 * 8);
                if (uVar2 == unaff_RBX[3]) {
                    *puVar6 = uVar1;
                    unaff_RBX[2] = unaff_RBX[2] + 1;
                    return puVar6;
                }
                if (uVar2 == uVar1) break;
                uVar4 = uVar4 + 1 + uVar5;
                uVar5 = uVar5 + 1;
                if (unaff_RBX[1] - 1U < uVar5) {
                    return (uint64_t *)0x0;
                }
            }
            return puVar6;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1800c03ae
// Address: 0x1800c03ae
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_78h

uint64_t * fcn.1800c0314(int64_t arg_38h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t *puVar6;
    int64_t *unaff_RBX;
    int64_t unaff_RDI;
    uint64_t in_R11;
    int64_t unaff_R14;
    uint64_t *unaff_R15;
    
    do {
        uVar1 = *(uint64_t *)(*unaff_RBX + in_R11 * 8);
        if (uVar1 != unaff_RBX[3]) {
            uVar4 = (uVar1 >> 5 ^ uVar1) >> 4;
            uVar5 = 0;
            do {
                uVar4 = uVar4 & unaff_R14 - 1U;
                uVar2 = *(uint64_t *)(unaff_RDI + uVar4 * 8);
                puVar6 = (uint64_t *)(unaff_RDI + uVar4 * 8);
                if (uVar2 == arg_38h) {
                    *puVar6 = uVar1;
                    goto code_r0x0001800c037a;
                }
                if (uVar2 == uVar1) goto code_r0x0001800c037a;
                uVar4 = uVar4 + 1 + uVar5;
                uVar5 = uVar5 + 1;
            } while (uVar5 <= unaff_R14 - 1U);
            puVar6 = (uint64_t *)0x0;
code_r0x0001800c037a:
            *puVar6 = *(uint64_t *)(*unaff_RBX + in_R11 * 8);
        }
        in_R11 = in_R11 + 1;
        if ((uint64_t)unaff_RBX[1] <= in_R11) {
            iVar3 = *unaff_RBX;
            unaff_RBX[1] = unaff_R14;
            *unaff_RBX = unaff_RDI;
            if (iVar3 != 0) {
                func_0x0001800f4640();
            }
            uVar1 = *unaff_R15;
            uVar4 = (uVar1 >> 5 ^ uVar1) >> 4;
            uVar5 = 0;
            while( true ) {
                uVar4 = uVar4 & unaff_RBX[1] - 1U;
                uVar2 = *(uint64_t *)(*unaff_RBX + uVar4 * 8);
                puVar6 = (uint64_t *)(*unaff_RBX + uVar4 * 8);
                if (uVar2 == unaff_RBX[3]) {
                    *puVar6 = uVar1;
                    unaff_RBX[2] = unaff_RBX[2] + 1;
                    return puVar6;
                }
                if (uVar2 == uVar1) break;
                uVar4 = uVar4 + 1 + uVar5;
                uVar5 = uVar5 + 1;
                if (unaff_RBX[1] - 1U < uVar5) {
                    return (uint64_t *)0x0;
                }
            }
            return puVar6;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1800c03e0
// Address: 0x1800c03e0
// Size: 40 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800c03e0(int64_t arg1, int64_t arg2, int64_t arg_68h)
{
    uint64_t uVar1;
    uint64_t *puVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t *puVar6;
    uint64_t *puVar7;
    uint64_t *puVar8;
    uint64_t *puVar9;
    uint64_t *puVar10;
    uint64_t *puVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)(arg1 + 8);
    if (*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar4 * 3) >> 2) goto code_r0x0001800c05b9;
    puVar10 = (uint64_t *)0x0;
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        uVar1 = *(uint64_t *)arg2;
        if (uVar1 != *(uint64_t *)(arg1 + 0x18)) {
            uVar5 = (uVar1 >> 5 ^ uVar1) >> 4;
            puVar6 = puVar10;
            do {
                uVar5 = uVar5 & (uint64_t)(uint64_t *)(iVar4 - 1U);
                uVar3 = *(uint64_t *)(*(int64_t *)arg1 + uVar5 * 0x10);
                if (uVar3 == uVar1) goto code_r0x0001800c05b9;
                if (uVar3 == *(uint64_t *)(arg1 + 0x18)) break;
                uVar5 = uVar5 + 1 + (int64_t)puVar6;
                puVar6 = (uint64_t *)((int64_t)puVar6 + 1);
            } while (puVar6 <= (uint64_t *)(iVar4 - 1U));
        }
    }
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar4 == 0) {
        puVar6 = (uint64_t *)0x10;
        puVar2 = (uint64_t *)func_0x000180459890(0x100);
        puVar8 = puVar10;
        puVar9 = puVar2;
        puVar11 = (uint64_t *)0x10;
code_r0x0001800c04e0:
        do {
            puVar7 = (uint64_t *)((int64_t)puVar8 + 1);
            puVar9[(int64_t)puVar8 * 2] = *(uint64_t *)(arg1 + 0x18);
            puVar9[(int64_t)puVar8 * 2 + 1] = 0;
            puVar8 = puVar7;
        } while (puVar7 < puVar6);
    } else {
        puVar6 = (uint64_t *)(iVar4 * 2);
        puVar2 = puVar10;
        puVar11 = puVar10;
        if ((puVar6 != (uint64_t *)0x0) &&
           (puVar2 = (uint64_t *)func_0x000180459890(iVar4 << 5), puVar8 = puVar10, puVar9 = puVar2, puVar11 = puVar6,
           puVar6 != (uint64_t *)0x0)) goto code_r0x0001800c04e0;
    }
    puVar6 = puVar10;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar5 = *(uint64_t *)(*(int64_t *)arg1 + (int64_t)puVar6 * 0x10);
            if (uVar5 != *(uint64_t *)(arg1 + 0x18)) {
                uVar3 = (uVar5 >> 5 ^ uVar5) >> 4;
                puVar8 = puVar10;
                do {
                    uVar3 = uVar3 & (uint64_t)(uint64_t *)((int64_t)puVar11 - 1U);
                    puVar9 = puVar2 + uVar3 * 2;
                    if (*puVar9 == uVar1) {
                        *puVar9 = uVar5;
                        break;
                    }
                    if (*puVar9 == uVar5) break;
                    uVar3 = uVar3 + 1 + (int64_t)puVar8;
                    puVar8 = (uint64_t *)((int64_t)puVar8 + 1);
                    puVar9 = puVar10;
                } while (puVar8 <= (uint64_t *)((int64_t)puVar11 - 1U));
                iVar4 = *(int64_t *)arg1;
                *puVar9 = *(uint64_t *)(iVar4 + (int64_t)puVar6 * 0x10);
                puVar9[1] = *(uint64_t *)(iVar4 + 8 + (int64_t)puVar6 * 0x10);
            }
            puVar6 = (uint64_t *)((int64_t)puVar6 + 1);
        } while (puVar6 < *(uint64_t **)(arg1 + 8));
    }
    iVar4 = *(int64_t *)arg1;
    *(uint64_t **)(arg1 + 8) = puVar11;
    *(uint64_t **)arg1 = puVar2;
    if (iVar4 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800c05b9:
    iVar4 = func_0x0001800ac6e0(arg1, arg2);
    return iVar4 + 8;
}

// ============================================================
// Function: FUN_1800c0408
// Address: 0x1800c0408
// Size: 114 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800c03e0(int64_t arg1, int64_t arg2, int64_t arg_68h)
{
    uint64_t uVar1;
    uint64_t *puVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t *puVar6;
    uint64_t *puVar7;
    uint64_t *puVar8;
    uint64_t *puVar9;
    uint64_t *puVar10;
    uint64_t *puVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)(arg1 + 8);
    if (*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar4 * 3) >> 2) goto code_r0x0001800c05b9;
    puVar10 = (uint64_t *)0x0;
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        uVar1 = *(uint64_t *)arg2;
        if (uVar1 != *(uint64_t *)(arg1 + 0x18)) {
            uVar5 = (uVar1 >> 5 ^ uVar1) >> 4;
            puVar6 = puVar10;
            do {
                uVar5 = uVar5 & (uint64_t)(uint64_t *)(iVar4 - 1U);
                uVar3 = *(uint64_t *)(*(int64_t *)arg1 + uVar5 * 0x10);
                if (uVar3 == uVar1) goto code_r0x0001800c05b9;
                if (uVar3 == *(uint64_t *)(arg1 + 0x18)) break;
                uVar5 = uVar5 + 1 + (int64_t)puVar6;
                puVar6 = (uint64_t *)((int64_t)puVar6 + 1);
            } while (puVar6 <= (uint64_t *)(iVar4 - 1U));
        }
    }
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar4 == 0) {
        puVar6 = (uint64_t *)0x10;
        puVar2 = (uint64_t *)func_0x000180459890(0x100);
        puVar8 = puVar10;
        puVar9 = puVar2;
        puVar11 = (uint64_t *)0x10;
code_r0x0001800c04e0:
        do {
            puVar7 = (uint64_t *)((int64_t)puVar8 + 1);
            puVar9[(int64_t)puVar8 * 2] = *(uint64_t *)(arg1 + 0x18);
            puVar9[(int64_t)puVar8 * 2 + 1] = 0;
            puVar8 = puVar7;
        } while (puVar7 < puVar6);
    } else {
        puVar6 = (uint64_t *)(iVar4 * 2);
        puVar2 = puVar10;
        puVar11 = puVar10;
        if ((puVar6 != (uint64_t *)0x0) &&
           (puVar2 = (uint64_t *)func_0x000180459890(iVar4 << 5), puVar8 = puVar10, puVar9 = puVar2, puVar11 = puVar6,
           puVar6 != (uint64_t *)0x0)) goto code_r0x0001800c04e0;
    }
    puVar6 = puVar10;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar5 = *(uint64_t *)(*(int64_t *)arg1 + (int64_t)puVar6 * 0x10);
            if (uVar5 != *(uint64_t *)(arg1 + 0x18)) {
                uVar3 = (uVar5 >> 5 ^ uVar5) >> 4;
                puVar8 = puVar10;
                do {
                    uVar3 = uVar3 & (uint64_t)(uint64_t *)((int64_t)puVar11 - 1U);
                    puVar9 = puVar2 + uVar3 * 2;
                    if (*puVar9 == uVar1) {
                        *puVar9 = uVar5;
                        break;
                    }
                    if (*puVar9 == uVar5) break;
                    uVar3 = uVar3 + 1 + (int64_t)puVar8;
                    puVar8 = (uint64_t *)((int64_t)puVar8 + 1);
                    puVar9 = puVar10;
                } while (puVar8 <= (uint64_t *)((int64_t)puVar11 - 1U));
                iVar4 = *(int64_t *)arg1;
                *puVar9 = *(uint64_t *)(iVar4 + (int64_t)puVar6 * 0x10);
                puVar9[1] = *(uint64_t *)(iVar4 + 8 + (int64_t)puVar6 * 0x10);
            }
            puVar6 = (uint64_t *)((int64_t)puVar6 + 1);
        } while (puVar6 < *(uint64_t **)(arg1 + 8));
    }
    iVar4 = *(int64_t *)arg1;
    *(uint64_t **)(arg1 + 8) = puVar11;
    *(uint64_t **)arg1 = puVar2;
    if (iVar4 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800c05b9:
    iVar4 = func_0x0001800ac6e0(arg1, arg2);
    return iVar4 + 8;
}

// ============================================================
// Function: FUN_1800c047a
// Address: 0x1800c047a
// Size: 299 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800c03e0(int64_t arg1, int64_t arg2, int64_t arg_68h)
{
    uint64_t uVar1;
    uint64_t *puVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t *puVar6;
    uint64_t *puVar7;
    uint64_t *puVar8;
    uint64_t *puVar9;
    uint64_t *puVar10;
    uint64_t *puVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)(arg1 + 8);
    if (*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar4 * 3) >> 2) goto code_r0x0001800c05b9;
    puVar10 = (uint64_t *)0x0;
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        uVar1 = *(uint64_t *)arg2;
        if (uVar1 != *(uint64_t *)(arg1 + 0x18)) {
            uVar5 = (uVar1 >> 5 ^ uVar1) >> 4;
            puVar6 = puVar10;
            do {
                uVar5 = uVar5 & (uint64_t)(uint64_t *)(iVar4 - 1U);
                uVar3 = *(uint64_t *)(*(int64_t *)arg1 + uVar5 * 0x10);
                if (uVar3 == uVar1) goto code_r0x0001800c05b9;
                if (uVar3 == *(uint64_t *)(arg1 + 0x18)) break;
                uVar5 = uVar5 + 1 + (int64_t)puVar6;
                puVar6 = (uint64_t *)((int64_t)puVar6 + 1);
            } while (puVar6 <= (uint64_t *)(iVar4 - 1U));
        }
    }
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar4 == 0) {
        puVar6 = (uint64_t *)0x10;
        puVar2 = (uint64_t *)func_0x000180459890(0x100);
        puVar8 = puVar10;
        puVar9 = puVar2;
        puVar11 = (uint64_t *)0x10;
code_r0x0001800c04e0:
        do {
            puVar7 = (uint64_t *)((int64_t)puVar8 + 1);
            puVar9[(int64_t)puVar8 * 2] = *(uint64_t *)(arg1 + 0x18);
            puVar9[(int64_t)puVar8 * 2 + 1] = 0;
            puVar8 = puVar7;
        } while (puVar7 < puVar6);
    } else {
        puVar6 = (uint64_t *)(iVar4 * 2);
        puVar2 = puVar10;
        puVar11 = puVar10;
        if ((puVar6 != (uint64_t *)0x0) &&
           (puVar2 = (uint64_t *)func_0x000180459890(iVar4 << 5), puVar8 = puVar10, puVar9 = puVar2, puVar11 = puVar6,
           puVar6 != (uint64_t *)0x0)) goto code_r0x0001800c04e0;
    }
    puVar6 = puVar10;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar5 = *(uint64_t *)(*(int64_t *)arg1 + (int64_t)puVar6 * 0x10);
            if (uVar5 != *(uint64_t *)(arg1 + 0x18)) {
                uVar3 = (uVar5 >> 5 ^ uVar5) >> 4;
                puVar8 = puVar10;
                do {
                    uVar3 = uVar3 & (uint64_t)(uint64_t *)((int64_t)puVar11 - 1U);
                    puVar9 = puVar2 + uVar3 * 2;
                    if (*puVar9 == uVar1) {
                        *puVar9 = uVar5;
                        break;
                    }
                    if (*puVar9 == uVar5) break;
                    uVar3 = uVar3 + 1 + (int64_t)puVar8;
                    puVar8 = (uint64_t *)((int64_t)puVar8 + 1);
                    puVar9 = puVar10;
                } while (puVar8 <= (uint64_t *)((int64_t)puVar11 - 1U));
                iVar4 = *(int64_t *)arg1;
                *puVar9 = *(uint64_t *)(iVar4 + (int64_t)puVar6 * 0x10);
                puVar9[1] = *(uint64_t *)(iVar4 + 8 + (int64_t)puVar6 * 0x10);
            }
            puVar6 = (uint64_t *)((int64_t)puVar6 + 1);
        } while (puVar6 < *(uint64_t **)(arg1 + 8));
    }
    iVar4 = *(int64_t *)arg1;
    *(uint64_t **)(arg1 + 8) = puVar11;
    *(uint64_t **)arg1 = puVar2;
    if (iVar4 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800c05b9:
    iVar4 = func_0x0001800ac6e0(arg1, arg2);
    return iVar4 + 8;
}

// ============================================================
// Function: FUN_1800c05a5
// Address: 0x1800c05a5
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800c03e0(int64_t arg1, int64_t arg2, int64_t arg_68h)
{
    uint64_t uVar1;
    uint64_t *puVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t *puVar6;
    uint64_t *puVar7;
    uint64_t *puVar8;
    uint64_t *puVar9;
    uint64_t *puVar10;
    uint64_t *puVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)(arg1 + 8);
    if (*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar4 * 3) >> 2) goto code_r0x0001800c05b9;
    puVar10 = (uint64_t *)0x0;
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        uVar1 = *(uint64_t *)arg2;
        if (uVar1 != *(uint64_t *)(arg1 + 0x18)) {
            uVar5 = (uVar1 >> 5 ^ uVar1) >> 4;
            puVar6 = puVar10;
            do {
                uVar5 = uVar5 & (uint64_t)(uint64_t *)(iVar4 - 1U);
                uVar3 = *(uint64_t *)(*(int64_t *)arg1 + uVar5 * 0x10);
                if (uVar3 == uVar1) goto code_r0x0001800c05b9;
                if (uVar3 == *(uint64_t *)(arg1 + 0x18)) break;
                uVar5 = uVar5 + 1 + (int64_t)puVar6;
                puVar6 = (uint64_t *)((int64_t)puVar6 + 1);
            } while (puVar6 <= (uint64_t *)(iVar4 - 1U));
        }
    }
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar4 == 0) {
        puVar6 = (uint64_t *)0x10;
        puVar2 = (uint64_t *)func_0x000180459890(0x100);
        puVar8 = puVar10;
        puVar9 = puVar2;
        puVar11 = (uint64_t *)0x10;
code_r0x0001800c04e0:
        do {
            puVar7 = (uint64_t *)((int64_t)puVar8 + 1);
            puVar9[(int64_t)puVar8 * 2] = *(uint64_t *)(arg1 + 0x18);
            puVar9[(int64_t)puVar8 * 2 + 1] = 0;
            puVar8 = puVar7;
        } while (puVar7 < puVar6);
    } else {
        puVar6 = (uint64_t *)(iVar4 * 2);
        puVar2 = puVar10;
        puVar11 = puVar10;
        if ((puVar6 != (uint64_t *)0x0) &&
           (puVar2 = (uint64_t *)func_0x000180459890(iVar4 << 5), puVar8 = puVar10, puVar9 = puVar2, puVar11 = puVar6,
           puVar6 != (uint64_t *)0x0)) goto code_r0x0001800c04e0;
    }
    puVar6 = puVar10;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar5 = *(uint64_t *)(*(int64_t *)arg1 + (int64_t)puVar6 * 0x10);
            if (uVar5 != *(uint64_t *)(arg1 + 0x18)) {
                uVar3 = (uVar5 >> 5 ^ uVar5) >> 4;
                puVar8 = puVar10;
                do {
                    uVar3 = uVar3 & (uint64_t)(uint64_t *)((int64_t)puVar11 - 1U);
                    puVar9 = puVar2 + uVar3 * 2;
                    if (*puVar9 == uVar1) {
                        *puVar9 = uVar5;
                        break;
                    }
                    if (*puVar9 == uVar5) break;
                    uVar3 = uVar3 + 1 + (int64_t)puVar8;
                    puVar8 = (uint64_t *)((int64_t)puVar8 + 1);
                    puVar9 = puVar10;
                } while (puVar8 <= (uint64_t *)((int64_t)puVar11 - 1U));
                iVar4 = *(int64_t *)arg1;
                *puVar9 = *(uint64_t *)(iVar4 + (int64_t)puVar6 * 0x10);
                puVar9[1] = *(uint64_t *)(iVar4 + 8 + (int64_t)puVar6 * 0x10);
            }
            puVar6 = (uint64_t *)((int64_t)puVar6 + 1);
        } while (puVar6 < *(uint64_t **)(arg1 + 8));
    }
    iVar4 = *(int64_t *)arg1;
    *(uint64_t **)(arg1 + 8) = puVar11;
    *(uint64_t **)arg1 = puVar2;
    if (iVar4 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800c05b9:
    iVar4 = func_0x0001800ac6e0(arg1, arg2);
    return iVar4 + 8;
}

// ============================================================
// Function: FUN_1800c05b9
// Address: 0x1800c05b9
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800c03e0(int64_t arg1, int64_t arg2, int64_t arg_68h)
{
    uint64_t uVar1;
    uint64_t *puVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t *puVar6;
    uint64_t *puVar7;
    uint64_t *puVar8;
    uint64_t *puVar9;
    uint64_t *puVar10;
    uint64_t *puVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)(arg1 + 8);
    if (*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar4 * 3) >> 2) goto code_r0x0001800c05b9;
    puVar10 = (uint64_t *)0x0;
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        uVar1 = *(uint64_t *)arg2;
        if (uVar1 != *(uint64_t *)(arg1 + 0x18)) {
            uVar5 = (uVar1 >> 5 ^ uVar1) >> 4;
            puVar6 = puVar10;
            do {
                uVar5 = uVar5 & (uint64_t)(uint64_t *)(iVar4 - 1U);
                uVar3 = *(uint64_t *)(*(int64_t *)arg1 + uVar5 * 0x10);
                if (uVar3 == uVar1) goto code_r0x0001800c05b9;
                if (uVar3 == *(uint64_t *)(arg1 + 0x18)) break;
                uVar5 = uVar5 + 1 + (int64_t)puVar6;
                puVar6 = (uint64_t *)((int64_t)puVar6 + 1);
            } while (puVar6 <= (uint64_t *)(iVar4 - 1U));
        }
    }
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar4 == 0) {
        puVar6 = (uint64_t *)0x10;
        puVar2 = (uint64_t *)func_0x000180459890(0x100);
        puVar8 = puVar10;
        puVar9 = puVar2;
        puVar11 = (uint64_t *)0x10;
code_r0x0001800c04e0:
        do {
            puVar7 = (uint64_t *)((int64_t)puVar8 + 1);
            puVar9[(int64_t)puVar8 * 2] = *(uint64_t *)(arg1 + 0x18);
            puVar9[(int64_t)puVar8 * 2 + 1] = 0;
            puVar8 = puVar7;
        } while (puVar7 < puVar6);
    } else {
        puVar6 = (uint64_t *)(iVar4 * 2);
        puVar2 = puVar10;
        puVar11 = puVar10;
        if ((puVar6 != (uint64_t *)0x0) &&
           (puVar2 = (uint64_t *)func_0x000180459890(iVar4 << 5), puVar8 = puVar10, puVar9 = puVar2, puVar11 = puVar6,
           puVar6 != (uint64_t *)0x0)) goto code_r0x0001800c04e0;
    }
    puVar6 = puVar10;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar5 = *(uint64_t *)(*(int64_t *)arg1 + (int64_t)puVar6 * 0x10);
            if (uVar5 != *(uint64_t *)(arg1 + 0x18)) {
                uVar3 = (uVar5 >> 5 ^ uVar5) >> 4;
                puVar8 = puVar10;
                do {
                    uVar3 = uVar3 & (uint64_t)(uint64_t *)((int64_t)puVar11 - 1U);
                    puVar9 = puVar2 + uVar3 * 2;
                    if (*puVar9 == uVar1) {
                        *puVar9 = uVar5;
                        break;
                    }
                    if (*puVar9 == uVar5) break;
                    uVar3 = uVar3 + 1 + (int64_t)puVar8;
                    puVar8 = (uint64_t *)((int64_t)puVar8 + 1);
                    puVar9 = puVar10;
                } while (puVar8 <= (uint64_t *)((int64_t)puVar11 - 1U));
                iVar4 = *(int64_t *)arg1;
                *puVar9 = *(uint64_t *)(iVar4 + (int64_t)puVar6 * 0x10);
                puVar9[1] = *(uint64_t *)(iVar4 + 8 + (int64_t)puVar6 * 0x10);
            }
            puVar6 = (uint64_t *)((int64_t)puVar6 + 1);
        } while (puVar6 < *(uint64_t **)(arg1 + 8));
    }
    iVar4 = *(int64_t *)arg1;
    *(uint64_t **)(arg1 + 8) = puVar11;
    *(uint64_t **)arg1 = puVar2;
    if (iVar4 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800c05b9:
    iVar4 = func_0x0001800ac6e0(arg1, arg2);
    return iVar4 + 8;
}

// ============================================================
// Function: FUN_1800c05e0
// Address: 0x1800c05e0
// Size: 55 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800c05e0(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    undefined4 *puVar2;
    uint64_t uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint64_t *puVar12;
    uint64_t *puVar13;
    uint64_t uVar14;
    uint64_t *puVar15;
    uint64_t *puVar16;
    uint64_t uVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar10 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar10 * 3) >> 2) || (iVar7 = func_0x0001800c13d0(), iVar7 != 0))
    goto code_r0x0001800c07a6;
    puVar1 = (uint64_t *)(arg1 + 0x18);
    uVar3 = *puVar1;
    if (iVar10 == 0) {
        uVar14 = 0x10;
        uVar8 = func_0x000180459890(0x200);
        uVar11 = 0;
        uVar9 = uVar8;
        uVar17 = 0x10;
code_r0x0001800c0690:
        do {
            iVar10 = uVar11 * 0x20;
            uVar11 = uVar11 + 1;
            *(uint64_t *)(iVar10 + uVar9) = *puVar1;
            *(undefined (*) [16])(iVar10 + 8 + uVar9) = ZEXT816(0);
            *(undefined8 *)(iVar10 + 0x18 + uVar9) = 0;
            *(undefined8 *)(iVar10 + 8 + uVar9) = 0;
            *(undefined8 *)(iVar10 + 0x10 + uVar9) = 0;
        } while (uVar11 < uVar14);
    } else {
        uVar14 = iVar10 * 2;
        if (uVar14 == 0) {
            uVar8 = 0;
            uVar17 = uVar8;
        } else {
            uVar8 = func_0x000180459890(iVar10 << 6);
            uVar11 = 0;
            uVar9 = uVar8;
            uVar17 = uVar14;
            if (uVar14 != 0) goto code_r0x0001800c0690;
        }
    }
    puVar13 = (uint64_t *)0x0;
    puVar16 = puVar13;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            iVar10 = (int64_t)puVar16 * 0x20;
            uVar14 = *(uint64_t *)(iVar10 + *(int64_t *)arg1);
            if (uVar14 != *puVar1) {
                uVar9 = (uVar14 >> 5 ^ uVar14) >> 4;
                puVar12 = puVar13;
                do {
                    uVar9 = uVar9 & (uint64_t)(uint64_t *)(uVar17 - 1);
                    puVar15 = (uint64_t *)(uVar9 * 0x20 + uVar8);
                    if (*puVar15 == uVar3) {
                        *puVar15 = uVar14;
                        break;
                    }
                    if (*puVar15 == uVar14) break;
                    uVar9 = uVar9 + 1 + (int64_t)puVar12;
                    puVar12 = (uint64_t *)((int64_t)puVar12 + 1);
                    puVar15 = puVar13;
                } while (puVar12 <= (uint64_t *)(uVar17 - 1));
                iVar7 = *(int64_t *)arg1;
                *puVar15 = *(uint64_t *)(iVar7 + iVar10);
                puVar2 = (undefined4 *)(iVar7 + 8 + iVar10);
                uVar4 = puVar2[1];
                uVar5 = puVar2[2];
                uVar6 = puVar2[3];
                *(undefined4 *)(puVar15 + 1) = *puVar2;
                *(undefined4 *)((int64_t)puVar15 + 0xc) = uVar4;
                *(undefined4 *)(puVar15 + 2) = uVar5;
                *(undefined4 *)((int64_t)puVar15 + 0x14) = uVar6;
                puVar15[3] = *(uint64_t *)(iVar7 + 0x18 + iVar10);
            }
            puVar16 = (uint64_t *)((int64_t)puVar16 + 1);
        } while (puVar16 < *(uint64_t **)(arg1 + 8));
    }
    iVar10 = *(int64_t *)arg1;
    *(uint64_t *)arg1 = uVar8;
    *(uint64_t *)(arg1 + 8) = uVar17;
    if (iVar10 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800c07a6:
    iVar10 = func_0x0001800c1450(arg1, arg2);
    return iVar10 + 8;
}

// ============================================================
// Function: FUN_1800c0617
// Address: 0x1800c0617
// Size: 394 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800c05e0(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    undefined4 *puVar2;
    uint64_t uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint64_t *puVar12;
    uint64_t *puVar13;
    uint64_t uVar14;
    uint64_t *puVar15;
    uint64_t *puVar16;
    uint64_t uVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar10 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar10 * 3) >> 2) || (iVar7 = func_0x0001800c13d0(), iVar7 != 0))
    goto code_r0x0001800c07a6;
    puVar1 = (uint64_t *)(arg1 + 0x18);
    uVar3 = *puVar1;
    if (iVar10 == 0) {
        uVar14 = 0x10;
        uVar8 = func_0x000180459890(0x200);
        uVar11 = 0;
        uVar9 = uVar8;
        uVar17 = 0x10;
code_r0x0001800c0690:
        do {
            iVar10 = uVar11 * 0x20;
            uVar11 = uVar11 + 1;
            *(uint64_t *)(iVar10 + uVar9) = *puVar1;
            *(undefined (*) [16])(iVar10 + 8 + uVar9) = ZEXT816(0);
            *(undefined8 *)(iVar10 + 0x18 + uVar9) = 0;
            *(undefined8 *)(iVar10 + 8 + uVar9) = 0;
            *(undefined8 *)(iVar10 + 0x10 + uVar9) = 0;
        } while (uVar11 < uVar14);
    } else {
        uVar14 = iVar10 * 2;
        if (uVar14 == 0) {
            uVar8 = 0;
            uVar17 = uVar8;
        } else {
            uVar8 = func_0x000180459890(iVar10 << 6);
            uVar11 = 0;
            uVar9 = uVar8;
            uVar17 = uVar14;
            if (uVar14 != 0) goto code_r0x0001800c0690;
        }
    }
    puVar13 = (uint64_t *)0x0;
    puVar16 = puVar13;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            iVar10 = (int64_t)puVar16 * 0x20;
            uVar14 = *(uint64_t *)(iVar10 + *(int64_t *)arg1);
            if (uVar14 != *puVar1) {
                uVar9 = (uVar14 >> 5 ^ uVar14) >> 4;
                puVar12 = puVar13;
                do {
                    uVar9 = uVar9 & (uint64_t)(uint64_t *)(uVar17 - 1);
                    puVar15 = (uint64_t *)(uVar9 * 0x20 + uVar8);
                    if (*puVar15 == uVar3) {
                        *puVar15 = uVar14;
                        break;
                    }
                    if (*puVar15 == uVar14) break;
                    uVar9 = uVar9 + 1 + (int64_t)puVar12;
                    puVar12 = (uint64_t *)((int64_t)puVar12 + 1);
                    puVar15 = puVar13;
                } while (puVar12 <= (uint64_t *)(uVar17 - 1));
                iVar7 = *(int64_t *)arg1;
                *puVar15 = *(uint64_t *)(iVar7 + iVar10);
                puVar2 = (undefined4 *)(iVar7 + 8 + iVar10);
                uVar4 = puVar2[1];
                uVar5 = puVar2[2];
                uVar6 = puVar2[3];
                *(undefined4 *)(puVar15 + 1) = *puVar2;
                *(undefined4 *)((int64_t)puVar15 + 0xc) = uVar4;
                *(undefined4 *)(puVar15 + 2) = uVar5;
                *(undefined4 *)((int64_t)puVar15 + 0x14) = uVar6;
                puVar15[3] = *(uint64_t *)(iVar7 + 0x18 + iVar10);
            }
            puVar16 = (uint64_t *)((int64_t)puVar16 + 1);
        } while (puVar16 < *(uint64_t **)(arg1 + 8));
    }
    iVar10 = *(int64_t *)arg1;
    *(uint64_t *)arg1 = uVar8;
    *(uint64_t *)(arg1 + 8) = uVar17;
    if (iVar10 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800c07a6:
    iVar10 = func_0x0001800c1450(arg1, arg2);
    return iVar10 + 8;
}

// ============================================================
// Function: FUN_1800c07a1
// Address: 0x1800c07a1
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800c05e0(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    undefined4 *puVar2;
    uint64_t uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint64_t *puVar12;
    uint64_t *puVar13;
    uint64_t uVar14;
    uint64_t *puVar15;
    uint64_t *puVar16;
    uint64_t uVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar10 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar10 * 3) >> 2) || (iVar7 = func_0x0001800c13d0(), iVar7 != 0))
    goto code_r0x0001800c07a6;
    puVar1 = (uint64_t *)(arg1 + 0x18);
    uVar3 = *puVar1;
    if (iVar10 == 0) {
        uVar14 = 0x10;
        uVar8 = func_0x000180459890(0x200);
        uVar11 = 0;
        uVar9 = uVar8;
        uVar17 = 0x10;
code_r0x0001800c0690:
        do {
            iVar10 = uVar11 * 0x20;
            uVar11 = uVar11 + 1;
            *(uint64_t *)(iVar10 + uVar9) = *puVar1;
            *(undefined (*) [16])(iVar10 + 8 + uVar9) = ZEXT816(0);
            *(undefined8 *)(iVar10 + 0x18 + uVar9) = 0;
            *(undefined8 *)(iVar10 + 8 + uVar9) = 0;
            *(undefined8 *)(iVar10 + 0x10 + uVar9) = 0;
        } while (uVar11 < uVar14);
    } else {
        uVar14 = iVar10 * 2;
        if (uVar14 == 0) {
            uVar8 = 0;
            uVar17 = uVar8;
        } else {
            uVar8 = func_0x000180459890(iVar10 << 6);
            uVar11 = 0;
            uVar9 = uVar8;
            uVar17 = uVar14;
            if (uVar14 != 0) goto code_r0x0001800c0690;
        }
    }
    puVar13 = (uint64_t *)0x0;
    puVar16 = puVar13;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            iVar10 = (int64_t)puVar16 * 0x20;
            uVar14 = *(uint64_t *)(iVar10 + *(int64_t *)arg1);
            if (uVar14 != *puVar1) {
                uVar9 = (uVar14 >> 5 ^ uVar14) >> 4;
                puVar12 = puVar13;
                do {
                    uVar9 = uVar9 & (uint64_t)(uint64_t *)(uVar17 - 1);
                    puVar15 = (uint64_t *)(uVar9 * 0x20 + uVar8);
                    if (*puVar15 == uVar3) {
                        *puVar15 = uVar14;
                        break;
                    }
                    if (*puVar15 == uVar14) break;
                    uVar9 = uVar9 + 1 + (int64_t)puVar12;
                    puVar12 = (uint64_t *)((int64_t)puVar12 + 1);
                    puVar15 = puVar13;
                } while (puVar12 <= (uint64_t *)(uVar17 - 1));
                iVar7 = *(int64_t *)arg1;
                *puVar15 = *(uint64_t *)(iVar7 + iVar10);
                puVar2 = (undefined4 *)(iVar7 + 8 + iVar10);
                uVar4 = puVar2[1];
                uVar5 = puVar2[2];
                uVar6 = puVar2[3];
                *(undefined4 *)(puVar15 + 1) = *puVar2;
                *(undefined4 *)((int64_t)puVar15 + 0xc) = uVar4;
                *(undefined4 *)(puVar15 + 2) = uVar5;
                *(undefined4 *)((int64_t)puVar15 + 0x14) = uVar6;
                puVar15[3] = *(uint64_t *)(iVar7 + 0x18 + iVar10);
            }
            puVar16 = (uint64_t *)((int64_t)puVar16 + 1);
        } while (puVar16 < *(uint64_t **)(arg1 + 8));
    }
    iVar10 = *(int64_t *)arg1;
    *(uint64_t *)arg1 = uVar8;
    *(uint64_t *)(arg1 + 8) = uVar17;
    if (iVar10 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800c07a6:
    iVar10 = func_0x0001800c1450(arg1, arg2);
    return iVar10 + 8;
}

// ============================================================
// Function: FUN_1800c07c0
// Address: 0x1800c07c0
// Size: 122 bytes
// ============================================================
void fcn.1800c07c0(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined *puVar5;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar5 = auStack_28;
    uVar4 = *(uint64_t *)arg1;
    if (uVar4 != 0) {
        uVar3 = ((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar4) >> 3) * 8;
        if (0xfff < uVar3) {
            puVar1 = (uint64_t *)(uVar4 - 8);
            uVar4 = (uVar4 - *puVar1) - 8;
            if (uVar4 < 0x20) {
                uVar3 = uVar3 + 0x27;
                uVar4 = *puVar1;
                puVar5 = auStack_28;
            } else {
                pcVar2 = (code *)swi(0x29);
                uVar3 = (*pcVar2)(5);
                puVar5 = auStack_20;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x1800c0827;
        func_0x000180459c3c(uVar4, uVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c0840
// Address: 0x1800c0840
// Size: 119 bytes
// ============================================================
void fcn.1800c0840(int64_t arg1)
{
    uint64_t uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    
    if (*(int64_t *)(arg1 + 0x10) != 0) {
        uVar1 = *(uint64_t *)(arg1 + 8);
        iVar2 = *(int64_t *)arg1;
        if (0x20 < uVar1) {
            fcn.1800f4640(iVar2);
            *(undefined8 *)arg1 = 0;
            *(undefined8 *)(arg1 + 8) = 0;
            *(undefined8 *)(arg1 + 0x10) = 0;
            return;
        }
        uVar3 = 0;
        if (uVar1 != 0) {
            do {
                uVar4 = uVar3 + 1;
                *(undefined8 *)(iVar2 + uVar3 * 0x10) = *(undefined8 *)(arg1 + 0x18);
                *(undefined4 *)(iVar2 + 8 + uVar3 * 0x10) = 0;
                uVar3 = uVar4;
            } while (uVar4 < uVar1);
        }
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c08c0
// Address: 0x1800c08c0
// Size: 208 bytes
// ============================================================
int64_t fcn.1800c08c0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined *puVar5;
    undefined *puVar6;
    int64_t iVar7;
    uint64_t uVar8;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    
    puVar5 = auStack_48;
    iVar3 = *(int64_t *)arg2;
    uVar4 = 0;
    iVar7 = *(int64_t *)(arg2 + 8) - iVar3;
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    uVar8 = iVar7 >> 3;
    *(undefined8 *)(arg1 + 0x10) = 0;
    if (uVar8 != 0) {
        if (0x1fffffffffffffff < uVar8) {
            func_0x000180010010();
            pcVar1 = (code *)swi(3);
            iVar3 = (*pcVar1)();
            return iVar3;
        }
        uVar8 = uVar8 * 8;
        puVar6 = auStack_48;
        if (uVar8 != 0) {
            if (uVar8 < 0x1000) {
                uVar4 = func_0x000180459890(uVar8);
                puVar6 = auStack_48;
            } else {
                if (uVar8 + 0x27 <= uVar8) {
                    func_0x000180004720();
                    pcVar1 = (code *)swi(3);
                    iVar3 = (*pcVar1)();
                    return iVar3;
                }
                iVar2 = func_0x000180459890();
                if (iVar2 == 0) {
                    pcVar1 = (code *)swi(0x29);
                    iVar2 = (*pcVar1)(5);
                    puVar5 = auStack_40;
                }
                uVar4 = iVar2 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar4 - 8) = iVar2;
                puVar6 = puVar5;
            }
        }
        *(uint64_t *)arg1 = uVar4;
        *(uint64_t *)(arg1 + 8) = uVar4;
        *(uint64_t *)(arg1 + 0x10) = uVar8 + uVar4;
        *(undefined8 *)(puVar6 + -8) = 0x1800c096e;
        func_0x000180498030(uVar4, iVar3, iVar7);
        *(uint64_t *)(arg1 + 8) = uVar8 + uVar4;
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800c0990
// Address: 0x1800c0990
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c0990(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x38) {
            func_0x000180004e40(iVar3 + 0x18);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 3) * 8)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x1800c0a20;
        func_0x000180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c09a9
// Address: 0x1800c09a9
// Size: 78 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c0990(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x38) {
            func_0x000180004e40(iVar3 + 0x18);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 3) * 8)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x1800c0a20;
        func_0x000180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c09f7
// Address: 0x1800c09f7
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c0990(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x38) {
            func_0x000180004e40(iVar3 + 0x18);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 3) * 8)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x1800c0a20;
        func_0x000180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c0a50
// Address: 0x1800c0a50
// Size: 350 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1800c0a50(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 *puVar8;
    undefined *puVar9;
    undefined *puVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    
    puVar9 = auStack_68;
    puVar8 = (undefined8 *)0x0;
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    iVar6 = *(int64_t *)(arg2 + 8) - *(int64_t *)arg2 >> 3;
    if (iVar6 * -0x71c71c71c71c71c7 != 0) {
        if (0x38e38e38e38e38e < (uint64_t)(iVar6 * -0x71c71c71c71c71c7)) {
            func_0x000180010010();
            pcVar2 = (code *)swi(3);
            iVar6 = (*pcVar2)();
            return iVar6;
        }
        uVar1 = iVar6 * 8;
        puVar10 = auStack_68;
        if (uVar1 != 0) {
            if (uVar1 < 0x1000) {
                puVar8 = (undefined8 *)func_0x000180459890(uVar1);
                puVar10 = auStack_68;
            } else {
                if (uVar1 + 0x27 <= uVar1) {
                    func_0x000180004720();
                    pcVar2 = (code *)swi(3);
                    iVar6 = (*pcVar2)();
                    return iVar6;
                }
                iVar7 = func_0x000180459890();
                if (iVar7 == 0) {
                    pcVar2 = (code *)swi(0x29);
                    iVar7 = (*pcVar2)(5);
                    puVar9 = auStack_60;
                }
                puVar8 = (undefined8 *)(iVar7 + 0x27U & 0xffffffffffffffe0);
                puVar8[-1] = iVar7;
                puVar10 = puVar9;
            }
        }
        *(undefined8 **)arg1 = puVar8;
        *(undefined8 **)(arg1 + 8) = puVar8;
        *(undefined8 **)(arg1 + 0x10) = puVar8 + iVar6;
        *(int64_t *)(puVar10 + 0x70) = arg1;
        iVar6 = *(int64_t *)(arg2 + 8);
        arg2 = *(int64_t *)arg2;
        *(undefined8 **)(puVar10 + 0x20) = puVar8;
        *(undefined8 **)(puVar10 + 0x28) = puVar8;
        *(int64_t *)(puVar10 + 0x30) = arg1;
        for (; arg2 != iVar6; arg2 = arg2 + 0x48) {
            *(undefined8 **)(puVar10 + 0x78) = puVar8;
            *puVar8 = 0x1804a5358;
            *(undefined (*) [16])(puVar8 + 1) = ZEXT816(0);
            *(undefined8 *)(puVar10 + -8) = 0x1800c0b5b;
            func_0x00018045b4e4(arg2 + 8);
            *puVar8 = 0x180640168;
            uVar3 = *(undefined4 *)(arg2 + 0x1c);
            uVar4 = *(undefined4 *)(arg2 + 0x20);
            uVar5 = *(undefined4 *)(arg2 + 0x24);
            *(undefined4 *)(puVar8 + 3) = *(undefined4 *)(arg2 + 0x18);
            *(undefined4 *)((int64_t)puVar8 + 0x1c) = uVar3;
            *(undefined4 *)(puVar8 + 4) = uVar4;
            *(undefined4 *)((int64_t)puVar8 + 0x24) = uVar5;
            *(undefined8 *)(puVar10 + -8) = 0x1800c0b74;
            func_0x00018000b4d0(puVar8 + 5, arg2 + 0x28);
            puVar8 = puVar8 + 9;
            *(undefined8 **)(puVar10 + 0x28) = puVar8;
        }
        *(undefined8 **)(arg1 + 8) = puVar8;
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800c0bd0
// Address: 0x1800c0bd0
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c0bd0(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x28) {
            func_0x000180004e40(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 3) * 8)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x1800c0c67;
        func_0x000180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c0be9
// Address: 0x1800c0be9
// Size: 85 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c0bd0(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x28) {
            func_0x000180004e40(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 3) * 8)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x1800c0c67;
        func_0x000180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c0c3e
// Address: 0x1800c0c3e
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c0bd0(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x28) {
            func_0x000180004e40(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 3) * 8)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x1800c0c67;
        func_0x000180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c0c80
// Address: 0x1800c0c80
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c0c80(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x38) {
            func_0x00018002ee50(iVar3 + 0x20);
            func_0x00018002ee50(iVar3 + 8);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 3) * 8)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x1800c0d19;
        func_0x000180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c0c99
// Address: 0x1800c0c99
// Size: 87 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c0c80(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x38) {
            func_0x00018002ee50(iVar3 + 0x20);
            func_0x00018002ee50(iVar3 + 8);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 3) * 8)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x1800c0d19;
        func_0x000180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c0cf0
// Address: 0x1800c0cf0
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c0c80(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x38) {
            func_0x00018002ee50(iVar3 + 0x20);
            func_0x00018002ee50(iVar3 + 8);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 3) * 8)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x1800c0d19;
        func_0x000180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c0d50
// Address: 0x1800c0d50
// Size: 133 bytes
// ============================================================
void fcn.1800c0d50(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined *puVar5;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar5 = auStack_28;
    if (*(int64_t *)arg1 != 0) {
        func_0x0001800c1e20(*(int64_t *)arg1, *(undefined8 *)(arg1 + 8));
        uVar4 = *(uint64_t *)arg1;
        uVar3 = ((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar4) >> 3) * 8;
        if (0xfff < uVar3) {
            puVar1 = (uint64_t *)(uVar4 - 8);
            uVar4 = (uVar4 - *puVar1) - 8;
            if (uVar4 < 0x20) {
                uVar3 = uVar3 + 0x27;
                uVar4 = *puVar1;
                puVar5 = auStack_28;
            } else {
                uVar3 = 5;
                pcVar2 = (code *)swi(0x29);
                (*pcVar2)(5);
                puVar5 = auStack_20;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x1800c0dc2;
        func_0x000180459c3c(uVar4, uVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c0de0
// Address: 0x1800c0de0
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800c0de0(int64_t arg1, int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)arg1;
    if ((uint64_t)(*(int64_t *)(arg1 + 0x10) - iVar1 >> 3) < 0x10) {
        iVar2 = *(int64_t *)(arg1 + 8);
        uVar3 = fcn.180459890(0x80);
        fcn.180498030(uVar3, *(int64_t *)arg1, *(int64_t *)(arg1 + 8) - *(int64_t *)arg1);
        fcn.1800c2120(arg1, uVar3, iVar2 - iVar1 >> 3, 0x10);
    }
    return;
}

// ============================================================
// Function: FUN_1800c0dfd
// Address: 0x1800c0dfd
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800c0de0(int64_t arg1, int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)arg1;
    if ((uint64_t)(*(int64_t *)(arg1 + 0x10) - iVar1 >> 3) < 0x10) {
        iVar2 = *(int64_t *)(arg1 + 8);
        uVar3 = fcn.180459890(0x80);
        fcn.180498030(uVar3, *(int64_t *)arg1, *(int64_t *)(arg1 + 8) - *(int64_t *)arg1);
        fcn.1800c2120(arg1, uVar3, iVar2 - iVar1 >> 3, 0x10);
    }
    return;
}

// ============================================================
// Function: FUN_1800c0e4f
// Address: 0x1800c0e4f
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800c0de0(int64_t arg1, int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)arg1;
    if ((uint64_t)(*(int64_t *)(arg1 + 0x10) - iVar1 >> 3) < 0x10) {
        iVar2 = *(int64_t *)(arg1 + 8);
        uVar3 = fcn.180459890(0x80);
        fcn.180498030(uVar3, *(int64_t *)arg1, *(int64_t *)(arg1 + 8) - *(int64_t *)arg1);
        fcn.1800c2120(arg1, uVar3, iVar2 - iVar1 >> 3, 0x10);
    }
    return;
}

// ============================================================
// Function: FUN_1800c0e60
// Address: 0x1800c0e60
// Size: 104 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c0e60(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined *puVar5;
    undefined *puVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t var_8h;
    undefined auStack_48 [8];
    undefined auStack_40 [32];
    
    puVar5 = auStack_48;
    puVar6 = auStack_48;
    iVar3 = *(int64_t *)(arg1 + 8);
    iVar1 = *(int64_t *)arg1;
    uVar8 = iVar3 - iVar1 >> 3;
    if ((uint64_t)arg2 < uVar8) {
        *(int64_t *)(arg1 + 8) = iVar1 + arg2 * 8;
        return;
    }
    if (uVar8 < (uint64_t)arg2) {
        uVar4 = *(int64_t *)(arg1 + 0x10) - iVar1 >> 3;
        if ((uint64_t)arg2 <= uVar4) {
            iVar1 = (arg2 - uVar8) * 8;
            fcn.1804986e0(iVar3, 0, iVar1);
            *(int64_t *)(arg1 + 8) = iVar1 + iVar3;
            return;
        }
        if (0x1fffffffffffffff < (uint64_t)arg2) {
            fcn.180010010();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        if ((0x1fffffffffffffff - (uVar4 >> 1) < uVar4) ||
           ((uVar4 = uVar4 + (uVar4 >> 1), uVar7 = arg2, (uint64_t)arg2 <= uVar4 &&
            (uVar7 = uVar4, 0x1fffffffffffffff < uVar4)))) {
code_r0x0001800c0fb8:
            fcn.180004720();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        uVar4 = uVar7 * 8;
        if (uVar4 == 0) {
            uVar4 = 0;
            puVar6 = auStack_48;
        } else if (uVar4 < 0x1000) {
            uVar4 = fcn.180459890();
        } else {
            if (uVar4 + 0x27 <= uVar4) goto code_r0x0001800c0fb8;
            iVar3 = fcn.180459890(uVar4 + 0x27);
            if (iVar3 == 0) {
                pcVar2 = (code *)swi(0x29);
                iVar3 = (*pcVar2)(5);
                puVar5 = auStack_40;
            }
            uVar4 = iVar3 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar4 - 8) = iVar3;
            puVar6 = puVar5;
        }
        *(undefined8 *)(puVar6 + -8) = 0x1800c0f5c;
        fcn.1804986e0(uVar4 + uVar8 * 8, 0, (arg2 - uVar8) * 8);
        iVar3 = *(int64_t *)arg1;
        iVar1 = *(int64_t *)(arg1 + 8);
        *(undefined8 *)(puVar6 + -8) = 0x1800c0f6e;
        fcn.180498030(uVar4, iVar3, iVar1 - iVar3);
        *(undefined8 *)(puVar6 + -8) = 0x1800c0f7f;
        fcn.1800c2120(arg1, uVar4, arg2, uVar7);
    }
    return;
}

// ============================================================
// Function: FUN_1800c0ec8
// Address: 0x1800c0ec8
// Size: 188 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c0e60(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined *puVar5;
    undefined *puVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t var_8h;
    undefined auStack_48 [8];
    undefined auStack_40 [32];
    
    puVar5 = auStack_48;
    puVar6 = auStack_48;
    iVar3 = *(int64_t *)(arg1 + 8);
    iVar1 = *(int64_t *)arg1;
    uVar8 = iVar3 - iVar1 >> 3;
    if ((uint64_t)arg2 < uVar8) {
        *(int64_t *)(arg1 + 8) = iVar1 + arg2 * 8;
        return;
    }
    if (uVar8 < (uint64_t)arg2) {
        uVar4 = *(int64_t *)(arg1 + 0x10) - iVar1 >> 3;
        if ((uint64_t)arg2 <= uVar4) {
            iVar1 = (arg2 - uVar8) * 8;
            fcn.1804986e0(iVar3, 0, iVar1);
            *(int64_t *)(arg1 + 8) = iVar1 + iVar3;
            return;
        }
        if (0x1fffffffffffffff < (uint64_t)arg2) {
            fcn.180010010();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        if ((0x1fffffffffffffff - (uVar4 >> 1) < uVar4) ||
           ((uVar4 = uVar4 + (uVar4 >> 1), uVar7 = arg2, (uint64_t)arg2 <= uVar4 &&
            (uVar7 = uVar4, 0x1fffffffffffffff < uVar4)))) {
code_r0x0001800c0fb8:
            fcn.180004720();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        uVar4 = uVar7 * 8;
        if (uVar4 == 0) {
            uVar4 = 0;
            puVar6 = auStack_48;
        } else if (uVar4 < 0x1000) {
            uVar4 = fcn.180459890();
        } else {
            if (uVar4 + 0x27 <= uVar4) goto code_r0x0001800c0fb8;
            iVar3 = fcn.180459890(uVar4 + 0x27);
            if (iVar3 == 0) {
                pcVar2 = (code *)swi(0x29);
                iVar3 = (*pcVar2)(5);
                puVar5 = auStack_40;
            }
            uVar4 = iVar3 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar4 - 8) = iVar3;
            puVar6 = puVar5;
        }
        *(undefined8 *)(puVar6 + -8) = 0x1800c0f5c;
        fcn.1804986e0(uVar4 + uVar8 * 8, 0, (arg2 - uVar8) * 8);
        iVar3 = *(int64_t *)arg1;
        iVar1 = *(int64_t *)(arg1 + 8);
        *(undefined8 *)(puVar6 + -8) = 0x1800c0f6e;
        fcn.180498030(uVar4, iVar3, iVar1 - iVar3);
        *(undefined8 *)(puVar6 + -8) = 0x1800c0f7f;
        fcn.1800c2120(arg1, uVar4, arg2, uVar7);
    }
    return;
}

// ============================================================
// Function: FUN_1800c0f84
// Address: 0x1800c0f84
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c0e60(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined *puVar5;
    undefined *puVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t var_8h;
    undefined auStack_48 [8];
    undefined auStack_40 [32];
    
    puVar5 = auStack_48;
    puVar6 = auStack_48;
    iVar3 = *(int64_t *)(arg1 + 8);
    iVar1 = *(int64_t *)arg1;
    uVar8 = iVar3 - iVar1 >> 3;
    if ((uint64_t)arg2 < uVar8) {
        *(int64_t *)(arg1 + 8) = iVar1 + arg2 * 8;
        return;
    }
    if (uVar8 < (uint64_t)arg2) {
        uVar4 = *(int64_t *)(arg1 + 0x10) - iVar1 >> 3;
        if ((uint64_t)arg2 <= uVar4) {
            iVar1 = (arg2 - uVar8) * 8;
            fcn.1804986e0(iVar3, 0, iVar1);
            *(int64_t *)(arg1 + 8) = iVar1 + iVar3;
            return;
        }
        if (0x1fffffffffffffff < (uint64_t)arg2) {
            fcn.180010010();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        if ((0x1fffffffffffffff - (uVar4 >> 1) < uVar4) ||
           ((uVar4 = uVar4 + (uVar4 >> 1), uVar7 = arg2, (uint64_t)arg2 <= uVar4 &&
            (uVar7 = uVar4, 0x1fffffffffffffff < uVar4)))) {
code_r0x0001800c0fb8:
            fcn.180004720();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        uVar4 = uVar7 * 8;
        if (uVar4 == 0) {
            uVar4 = 0;
            puVar6 = auStack_48;
        } else if (uVar4 < 0x1000) {
            uVar4 = fcn.180459890();
        } else {
            if (uVar4 + 0x27 <= uVar4) goto code_r0x0001800c0fb8;
            iVar3 = fcn.180459890(uVar4 + 0x27);
            if (iVar3 == 0) {
                pcVar2 = (code *)swi(0x29);
                iVar3 = (*pcVar2)(5);
                puVar5 = auStack_40;
            }
            uVar4 = iVar3 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar4 - 8) = iVar3;
            puVar6 = puVar5;
        }
        *(undefined8 *)(puVar6 + -8) = 0x1800c0f5c;
        fcn.1804986e0(uVar4 + uVar8 * 8, 0, (arg2 - uVar8) * 8);
        iVar3 = *(int64_t *)arg1;
        iVar1 = *(int64_t *)(arg1 + 8);
        *(undefined8 *)(puVar6 + -8) = 0x1800c0f6e;
        fcn.180498030(uVar4, iVar3, iVar1 - iVar3);
        *(undefined8 *)(puVar6 + -8) = 0x1800c0f7f;
        fcn.1800c2120(arg1, uVar4, arg2, uVar7);
    }
    return;
}

// ============================================================
// Function: FUN_1800c0fb8
// Address: 0x1800c0fb8
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c0e60(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined *puVar5;
    undefined *puVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t var_8h;
    undefined auStack_48 [8];
    undefined auStack_40 [32];
    
    puVar5 = auStack_48;
    puVar6 = auStack_48;
    iVar3 = *(int64_t *)(arg1 + 8);
    iVar1 = *(int64_t *)arg1;
    uVar8 = iVar3 - iVar1 >> 3;
    if ((uint64_t)arg2 < uVar8) {
        *(int64_t *)(arg1 + 8) = iVar1 + arg2 * 8;
        return;
    }
    if (uVar8 < (uint64_t)arg2) {
        uVar4 = *(int64_t *)(arg1 + 0x10) - iVar1 >> 3;
        if ((uint64_t)arg2 <= uVar4) {
            iVar1 = (arg2 - uVar8) * 8;
            fcn.1804986e0(iVar3, 0, iVar1);
            *(int64_t *)(arg1 + 8) = iVar1 + iVar3;
            return;
        }
        if (0x1fffffffffffffff < (uint64_t)arg2) {
            fcn.180010010();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        if ((0x1fffffffffffffff - (uVar4 >> 1) < uVar4) ||
           ((uVar4 = uVar4 + (uVar4 >> 1), uVar7 = arg2, (uint64_t)arg2 <= uVar4 &&
            (uVar7 = uVar4, 0x1fffffffffffffff < uVar4)))) {
code_r0x0001800c0fb8:
            fcn.180004720();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        uVar4 = uVar7 * 8;
        if (uVar4 == 0) {
            uVar4 = 0;
            puVar6 = auStack_48;
        } else if (uVar4 < 0x1000) {
            uVar4 = fcn.180459890();
        } else {
            if (uVar4 + 0x27 <= uVar4) goto code_r0x0001800c0fb8;
            iVar3 = fcn.180459890(uVar4 + 0x27);
            if (iVar3 == 0) {
                pcVar2 = (code *)swi(0x29);
                iVar3 = (*pcVar2)(5);
                puVar5 = auStack_40;
            }
            uVar4 = iVar3 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar4 - 8) = iVar3;
            puVar6 = puVar5;
        }
        *(undefined8 *)(puVar6 + -8) = 0x1800c0f5c;
        fcn.1804986e0(uVar4 + uVar8 * 8, 0, (arg2 - uVar8) * 8);
        iVar3 = *(int64_t *)arg1;
        iVar1 = *(int64_t *)(arg1 + 8);
        *(undefined8 *)(puVar6 + -8) = 0x1800c0f6e;
        fcn.180498030(uVar4, iVar3, iVar1 - iVar3);
        *(undefined8 *)(puVar6 + -8) = 0x1800c0f7f;
        fcn.1800c2120(arg1, uVar4, arg2, uVar7);
    }
    return;
}

// ============================================================
// Function: FUN_1800c0fbe
// Address: 0x1800c0fbe
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c0e60(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined *puVar5;
    undefined *puVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t var_8h;
    undefined auStack_48 [8];
    undefined auStack_40 [32];
    
    puVar5 = auStack_48;
    puVar6 = auStack_48;
    iVar3 = *(int64_t *)(arg1 + 8);
    iVar1 = *(int64_t *)arg1;
    uVar8 = iVar3 - iVar1 >> 3;
    if ((uint64_t)arg2 < uVar8) {
        *(int64_t *)(arg1 + 8) = iVar1 + arg2 * 8;
        return;
    }
    if (uVar8 < (uint64_t)arg2) {
        uVar4 = *(int64_t *)(arg1 + 0x10) - iVar1 >> 3;
        if ((uint64_t)arg2 <= uVar4) {
            iVar1 = (arg2 - uVar8) * 8;
            fcn.1804986e0(iVar3, 0, iVar1);
            *(int64_t *)(arg1 + 8) = iVar1 + iVar3;
            return;
        }
        if (0x1fffffffffffffff < (uint64_t)arg2) {
            fcn.180010010();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        if ((0x1fffffffffffffff - (uVar4 >> 1) < uVar4) ||
           ((uVar4 = uVar4 + (uVar4 >> 1), uVar7 = arg2, (uint64_t)arg2 <= uVar4 &&
            (uVar7 = uVar4, 0x1fffffffffffffff < uVar4)))) {
code_r0x0001800c0fb8:
            fcn.180004720();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        uVar4 = uVar7 * 8;
        if (uVar4 == 0) {
            uVar4 = 0;
            puVar6 = auStack_48;
        } else if (uVar4 < 0x1000) {
            uVar4 = fcn.180459890();
        } else {
            if (uVar4 + 0x27 <= uVar4) goto code_r0x0001800c0fb8;
            iVar3 = fcn.180459890(uVar4 + 0x27);
            if (iVar3 == 0) {
                pcVar2 = (code *)swi(0x29);
                iVar3 = (*pcVar2)(5);
                puVar5 = auStack_40;
            }
            uVar4 = iVar3 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar4 - 8) = iVar3;
            puVar6 = puVar5;
        }
        *(undefined8 *)(puVar6 + -8) = 0x1800c0f5c;
        fcn.1804986e0(uVar4 + uVar8 * 8, 0, (arg2 - uVar8) * 8);
        iVar3 = *(int64_t *)arg1;
        iVar1 = *(int64_t *)(arg1 + 8);
        *(undefined8 *)(puVar6 + -8) = 0x1800c0f6e;
        fcn.180498030(uVar4, iVar3, iVar1 - iVar3);
        *(undefined8 *)(puVar6 + -8) = 0x1800c0f7f;
        fcn.1800c2120(arg1, uVar4, arg2, uVar7);
    }
    return;
}

// ============================================================
// Function: FUN_1800c0fd0
// Address: 0x1800c0fd0
// Size: 240 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1800c0fd0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    undefined *puVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar6 = auStack_38;
    if (arg1 != arg2) {
        uVar8 = *(uint64_t *)arg1;
        iVar3 = *(int64_t *)arg2;
        uVar5 = *(int64_t *)(arg2 + 8) - iVar3 >> 3;
        uVar4 = (int64_t)(*(int64_t *)(arg1 + 0x10) - uVar8) >> 3;
        if (uVar4 < uVar5) {
            if (0x1fffffffffffffff < uVar5) {
                fcn.180010010();
                pcVar1 = (code *)swi(3);
                iVar3 = (*pcVar1)();
                return iVar3;
            }
            uVar7 = 0x1fffffffffffffff;
            if ((uVar4 <= 0x1fffffffffffffff - (uVar4 >> 1)) && (uVar7 = uVar4 + (uVar4 >> 1), uVar7 < uVar5)) {
                uVar7 = uVar5;
            }
            if (uVar8 != 0) {
                uVar4 = uVar8;
                puVar6 = auStack_38;
                if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar8) >> 3) * 8)) {
                    uVar4 = *(uint64_t *)(uVar8 - 8);
                    uVar8 = (uVar8 - uVar4) - 8;
                    puVar6 = auStack_38;
                    if (0x1f < uVar8) {
                        pcVar1 = (code *)swi(0x29);
                        (*pcVar1)(5);
                        uVar4 = uVar8;
                        puVar6 = auStack_30;
                    }
                }
                *(undefined8 *)(puVar6 + -8) = 0x1800c1089;
                func_0x000180459c3c(uVar4);
                *(undefined8 *)arg1 = 0;
                *(undefined8 *)(arg1 + 8) = 0;
                *(undefined8 *)(arg1 + 0x10) = 0;
            }
            *(undefined8 *)(puVar6 + -8) = 0x1800c10a1;
            func_0x0001800c2450(arg1, uVar7);
            iVar2 = *(int64_t *)arg1;
            *(undefined8 *)(puVar6 + -8) = 0x1800c10ba;
            fcn.180498030(iVar2, iVar3, uVar5 * 8);
            iVar2 = iVar2 + uVar5 * 8;
        } else {
            uVar4 = (int64_t)(*(int64_t *)(arg1 + 8) - uVar8) >> 3;
            if (uVar4 < uVar5) {
                fcn.180498030(uVar8, iVar3, uVar4 * 8);
                uVar8 = *(uint64_t *)(arg1 + 8);
                iVar3 = iVar3 + uVar4 * 8;
                uVar5 = uVar5 - uVar4;
            }
            fcn.180498030(uVar8, iVar3, uVar5 * 8);
            iVar2 = uVar5 * 8 + uVar8;
        }
        *(int64_t *)(arg1 + 8) = iVar2;
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800c10c0
// Address: 0x1800c10c0
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1800c0fd0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    undefined *puVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar6 = auStack_38;
    if (arg1 != arg2) {
        uVar8 = *(uint64_t *)arg1;
        iVar3 = *(int64_t *)arg2;
        uVar5 = *(int64_t *)(arg2 + 8) - iVar3 >> 3;
        uVar4 = (int64_t)(*(int64_t *)(arg1 + 0x10) - uVar8) >> 3;
        if (uVar4 < uVar5) {
            if (0x1fffffffffffffff < uVar5) {
                fcn.180010010();
                pcVar1 = (code *)swi(3);
                iVar3 = (*pcVar1)();
                return iVar3;
            }
            uVar7 = 0x1fffffffffffffff;
            if ((uVar4 <= 0x1fffffffffffffff - (uVar4 >> 1)) && (uVar7 = uVar4 + (uVar4 >> 1), uVar7 < uVar5)) {
                uVar7 = uVar5;
            }
            if (uVar8 != 0) {
                uVar4 = uVar8;
                puVar6 = auStack_38;
                if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar8) >> 3) * 8)) {
                    uVar4 = *(uint64_t *)(uVar8 - 8);
                    uVar8 = (uVar8 - uVar4) - 8;
                    puVar6 = auStack_38;
                    if (0x1f < uVar8) {
                        pcVar1 = (code *)swi(0x29);
                        (*pcVar1)(5);
                        uVar4 = uVar8;
                        puVar6 = auStack_30;
                    }
                }
                *(undefined8 *)(puVar6 + -8) = 0x1800c1089;
                func_0x000180459c3c(uVar4);
                *(undefined8 *)arg1 = 0;
                *(undefined8 *)(arg1 + 8) = 0;
                *(undefined8 *)(arg1 + 0x10) = 0;
            }
            *(undefined8 *)(puVar6 + -8) = 0x1800c10a1;
            func_0x0001800c2450(arg1, uVar7);
            iVar2 = *(int64_t *)arg1;
            *(undefined8 *)(puVar6 + -8) = 0x1800c10ba;
            fcn.180498030(iVar2, iVar3, uVar5 * 8);
            iVar2 = iVar2 + uVar5 * 8;
        } else {
            uVar4 = (int64_t)(*(int64_t *)(arg1 + 8) - uVar8) >> 3;
            if (uVar4 < uVar5) {
                fcn.180498030(uVar8, iVar3, uVar4 * 8);
                uVar8 = *(uint64_t *)(arg1 + 8);
                iVar3 = iVar3 + uVar4 * 8;
                uVar5 = uVar5 - uVar4;
            }
            fcn.180498030(uVar8, iVar3, uVar5 * 8);
            iVar2 = uVar5 * 8 + uVar8;
        }
        *(int64_t *)(arg1 + 8) = iVar2;
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800c1112
// Address: 0x1800c1112
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1800c0fd0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    undefined *puVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar6 = auStack_38;
    if (arg1 != arg2) {
        uVar8 = *(uint64_t *)arg1;
        iVar3 = *(int64_t *)arg2;
        uVar5 = *(int64_t *)(arg2 + 8) - iVar3 >> 3;
        uVar4 = (int64_t)(*(int64_t *)(arg1 + 0x10) - uVar8) >> 3;
        if (uVar4 < uVar5) {
            if (0x1fffffffffffffff < uVar5) {
                fcn.180010010();
                pcVar1 = (code *)swi(3);
                iVar3 = (*pcVar1)();
                return iVar3;
            }
            uVar7 = 0x1fffffffffffffff;
            if ((uVar4 <= 0x1fffffffffffffff - (uVar4 >> 1)) && (uVar7 = uVar4 + (uVar4 >> 1), uVar7 < uVar5)) {
                uVar7 = uVar5;
            }
            if (uVar8 != 0) {
                uVar4 = uVar8;
                puVar6 = auStack_38;
                if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar8) >> 3) * 8)) {
                    uVar4 = *(uint64_t *)(uVar8 - 8);
                    uVar8 = (uVar8 - uVar4) - 8;
                    puVar6 = auStack_38;
                    if (0x1f < uVar8) {
                        pcVar1 = (code *)swi(0x29);
                        (*pcVar1)(5);
                        uVar4 = uVar8;
                        puVar6 = auStack_30;
                    }
                }
                *(undefined8 *)(puVar6 + -8) = 0x1800c1089;
                func_0x000180459c3c(uVar4);
                *(undefined8 *)arg1 = 0;
                *(undefined8 *)(arg1 + 8) = 0;
                *(undefined8 *)(arg1 + 0x10) = 0;
            }
            *(undefined8 *)(puVar6 + -8) = 0x1800c10a1;
            func_0x0001800c2450(arg1, uVar7);
            iVar2 = *(int64_t *)arg1;
            *(undefined8 *)(puVar6 + -8) = 0x1800c10ba;
            fcn.180498030(iVar2, iVar3, uVar5 * 8);
            iVar2 = iVar2 + uVar5 * 8;
        } else {
            uVar4 = (int64_t)(*(int64_t *)(arg1 + 8) - uVar8) >> 3;
            if (uVar4 < uVar5) {
                fcn.180498030(uVar8, iVar3, uVar4 * 8);
                uVar8 = *(uint64_t *)(arg1 + 8);
                iVar3 = iVar3 + uVar4 * 8;
                uVar5 = uVar5 - uVar4;
            }
            fcn.180498030(uVar8, iVar3, uVar5 * 8);
            iVar2 = uVar5 * 8 + uVar8;
        }
        *(int64_t *)(arg1 + 8) = iVar2;
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800c1140
// Address: 0x1800c1140
// Size: 70 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 * fcn.1800c1140(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    code *pcVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    uint64_t uVar7;
    undefined8 *puVar8;
    undefined *puVar9;
    undefined *puVar10;
    uint64_t uVar11;
    int64_t iVar12;
    undefined8 *puVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    puVar10 = auStack_38;
    puVar6 = *(undefined8 **)(arg1 + 8);
    if (puVar6 != *(undefined8 **)(arg1 + 0x10)) {
        *puVar6 = *(undefined8 *)arg2;
        puVar6 = *(undefined8 **)(arg1 + 8);
        *(undefined8 **)(arg1 + 8) = puVar6 + 1;
        return puVar6;
    }
    iVar12 = (int64_t)puVar6 - *(int64_t *)arg1 >> 3;
    if (iVar12 == 0x1fffffffffffffff) {
        fcn.180010010();
        pcVar4 = (code *)swi(3);
        puVar6 = (undefined8 *)(*pcVar4)();
        return puVar6;
    }
    uVar7 = (int64_t)*(undefined8 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3;
    if (uVar7 <= 0x1fffffffffffffff - (uVar7 >> 1)) {
        uVar1 = iVar12 + 1;
        uVar7 = uVar7 + (uVar7 >> 1);
        uVar11 = uVar1;
        if (uVar1 <= uVar7) {
            uVar11 = uVar7;
        }
        if (uVar11 < 0x2000000000000000) {
            uVar7 = uVar11 * 8;
            if (uVar7 == 0) {
                puVar13 = (undefined8 *)0x0;
                puVar10 = auStack_38;
            } else if (uVar7 < 0x1000) {
                puVar13 = (undefined8 *)fcn.180459890();
            } else {
                if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800c12a9;
                iVar5 = fcn.180459890(uVar7 + 0x27);
                if (iVar5 == 0) {
                    pcVar4 = (code *)swi(0x29);
                    iVar5 = (*pcVar4)(5);
                    puVar9 = auStack_30;
                }
                puVar13 = (undefined8 *)(iVar5 + 0x27U & 0xffffffffffffffe0);
                puVar13[-1] = iVar5;
                puVar10 = puVar9;
            }
            puVar2 = puVar13 + iVar12;
            *puVar2 = *(undefined8 *)arg2;
            puVar3 = *(undefined8 **)arg1;
            if (puVar6 == *(undefined8 **)(arg1 + 8)) {
                iVar12 = (int64_t)*(undefined8 **)(arg1 + 8) - (int64_t)puVar3;
                puVar8 = puVar13;
                puVar6 = puVar3;
            } else {
                *(undefined8 *)(puVar10 + -8) = 0x1800c125e;
                fcn.180498030(puVar13, puVar3, (int64_t)puVar6 - (int64_t)puVar3);
                puVar8 = puVar2 + 1;
                iVar12 = *(int64_t *)(arg1 + 8) - (int64_t)puVar6;
            }
            *(undefined8 *)(puVar10 + -8) = 0x1800c1271;
            fcn.180498030(puVar8, puVar6, iVar12);
            *(undefined8 *)(puVar10 + -8) = 0x1800c1282;
            fcn.1800c2120(arg1, puVar13, uVar1, uVar11);
            return puVar2;
        }
    }
code_r0x0001800c12a9:
    fcn.180004720();
    pcVar4 = (code *)swi(3);
    puVar6 = (undefined8 *)(*pcVar4)();
    return puVar6;
}

// ============================================================
// Function: FUN_1800c1186
// Address: 0x1800c1186
// Size: 285 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 * fcn.1800c1140(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    code *pcVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    uint64_t uVar7;
    undefined8 *puVar8;
    undefined *puVar9;
    undefined *puVar10;
    uint64_t uVar11;
    int64_t iVar12;
    undefined8 *puVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    puVar10 = auStack_38;
    puVar6 = *(undefined8 **)(arg1 + 8);
    if (puVar6 != *(undefined8 **)(arg1 + 0x10)) {
        *puVar6 = *(undefined8 *)arg2;
        puVar6 = *(undefined8 **)(arg1 + 8);
        *(undefined8 **)(arg1 + 8) = puVar6 + 1;
        return puVar6;
    }
    iVar12 = (int64_t)puVar6 - *(int64_t *)arg1 >> 3;
    if (iVar12 == 0x1fffffffffffffff) {
        fcn.180010010();
        pcVar4 = (code *)swi(3);
        puVar6 = (undefined8 *)(*pcVar4)();
        return puVar6;
    }
    uVar7 = (int64_t)*(undefined8 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3;
    if (uVar7 <= 0x1fffffffffffffff - (uVar7 >> 1)) {
        uVar1 = iVar12 + 1;
        uVar7 = uVar7 + (uVar7 >> 1);
        uVar11 = uVar1;
        if (uVar1 <= uVar7) {
            uVar11 = uVar7;
        }
        if (uVar11 < 0x2000000000000000) {
            uVar7 = uVar11 * 8;
            if (uVar7 == 0) {
                puVar13 = (undefined8 *)0x0;
                puVar10 = auStack_38;
            } else if (uVar7 < 0x1000) {
                puVar13 = (undefined8 *)fcn.180459890();
            } else {
                if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800c12a9;
                iVar5 = fcn.180459890(uVar7 + 0x27);
                if (iVar5 == 0) {
                    pcVar4 = (code *)swi(0x29);
                    iVar5 = (*pcVar4)(5);
                    puVar9 = auStack_30;
                }
                puVar13 = (undefined8 *)(iVar5 + 0x27U & 0xffffffffffffffe0);
                puVar13[-1] = iVar5;
                puVar10 = puVar9;
            }
            puVar2 = puVar13 + iVar12;
            *puVar2 = *(undefined8 *)arg2;
            puVar3 = *(undefined8 **)arg1;
            if (puVar6 == *(undefined8 **)(arg1 + 8)) {
                iVar12 = (int64_t)*(undefined8 **)(arg1 + 8) - (int64_t)puVar3;
                puVar8 = puVar13;
                puVar6 = puVar3;
            } else {
                *(undefined8 *)(puVar10 + -8) = 0x1800c125e;
                fcn.180498030(puVar13, puVar3, (int64_t)puVar6 - (int64_t)puVar3);
                puVar8 = puVar2 + 1;
                iVar12 = *(int64_t *)(arg1 + 8) - (int64_t)puVar6;
            }
            *(undefined8 *)(puVar10 + -8) = 0x1800c1271;
            fcn.180498030(puVar8, puVar6, iVar12);
            *(undefined8 *)(puVar10 + -8) = 0x1800c1282;
            fcn.1800c2120(arg1, puVar13, uVar1, uVar11);
            return puVar2;
        }
    }
code_r0x0001800c12a9:
    fcn.180004720();
    pcVar4 = (code *)swi(3);
    puVar6 = (undefined8 *)(*pcVar4)();
    return puVar6;
}

// ============================================================
// Function: FUN_1800c12a3
// Address: 0x1800c12a3
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 * fcn.1800c1140(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    code *pcVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    uint64_t uVar7;
    undefined8 *puVar8;
    undefined *puVar9;
    undefined *puVar10;
    uint64_t uVar11;
    int64_t iVar12;
    undefined8 *puVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    puVar10 = auStack_38;
    puVar6 = *(undefined8 **)(arg1 + 8);
    if (puVar6 != *(undefined8 **)(arg1 + 0x10)) {
        *puVar6 = *(undefined8 *)arg2;
        puVar6 = *(undefined8 **)(arg1 + 8);
        *(undefined8 **)(arg1 + 8) = puVar6 + 1;
        return puVar6;
    }
    iVar12 = (int64_t)puVar6 - *(int64_t *)arg1 >> 3;
    if (iVar12 == 0x1fffffffffffffff) {
        fcn.180010010();
        pcVar4 = (code *)swi(3);
        puVar6 = (undefined8 *)(*pcVar4)();
        return puVar6;
    }
    uVar7 = (int64_t)*(undefined8 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3;
    if (uVar7 <= 0x1fffffffffffffff - (uVar7 >> 1)) {
        uVar1 = iVar12 + 1;
        uVar7 = uVar7 + (uVar7 >> 1);
        uVar11 = uVar1;
        if (uVar1 <= uVar7) {
            uVar11 = uVar7;
        }
        if (uVar11 < 0x2000000000000000) {
            uVar7 = uVar11 * 8;
            if (uVar7 == 0) {
                puVar13 = (undefined8 *)0x0;
                puVar10 = auStack_38;
            } else if (uVar7 < 0x1000) {
                puVar13 = (undefined8 *)fcn.180459890();
            } else {
                if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800c12a9;
                iVar5 = fcn.180459890(uVar7 + 0x27);
                if (iVar5 == 0) {
                    pcVar4 = (code *)swi(0x29);
                    iVar5 = (*pcVar4)(5);
                    puVar9 = auStack_30;
                }
                puVar13 = (undefined8 *)(iVar5 + 0x27U & 0xffffffffffffffe0);
                puVar13[-1] = iVar5;
                puVar10 = puVar9;
            }
            puVar2 = puVar13 + iVar12;
            *puVar2 = *(undefined8 *)arg2;
            puVar3 = *(undefined8 **)arg1;
            if (puVar6 == *(undefined8 **)(arg1 + 8)) {
                iVar12 = (int64_t)*(undefined8 **)(arg1 + 8) - (int64_t)puVar3;
                puVar8 = puVar13;
                puVar6 = puVar3;
            } else {
                *(undefined8 *)(puVar10 + -8) = 0x1800c125e;
                fcn.180498030(puVar13, puVar3, (int64_t)puVar6 - (int64_t)puVar3);
                puVar8 = puVar2 + 1;
                iVar12 = *(int64_t *)(arg1 + 8) - (int64_t)puVar6;
            }
            *(undefined8 *)(puVar10 + -8) = 0x1800c1271;
            fcn.180498030(puVar8, puVar6, iVar12);
            *(undefined8 *)(puVar10 + -8) = 0x1800c1282;
            fcn.1800c2120(arg1, puVar13, uVar1, uVar11);
            return puVar2;
        }
    }
code_r0x0001800c12a9:
    fcn.180004720();
    pcVar4 = (code *)swi(3);
    puVar6 = (undefined8 *)(*pcVar4)();
    return puVar6;
}

// ============================================================
// Function: FUN_1800c12a9
// Address: 0x1800c12a9
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 * fcn.1800c1140(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    code *pcVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    uint64_t uVar7;
    undefined8 *puVar8;
    undefined *puVar9;
    undefined *puVar10;
    uint64_t uVar11;
    int64_t iVar12;
    undefined8 *puVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    puVar10 = auStack_38;
    puVar6 = *(undefined8 **)(arg1 + 8);
    if (puVar6 != *(undefined8 **)(arg1 + 0x10)) {
        *puVar6 = *(undefined8 *)arg2;
        puVar6 = *(undefined8 **)(arg1 + 8);
        *(undefined8 **)(arg1 + 8) = puVar6 + 1;
        return puVar6;
    }
    iVar12 = (int64_t)puVar6 - *(int64_t *)arg1 >> 3;
    if (iVar12 == 0x1fffffffffffffff) {
        fcn.180010010();
        pcVar4 = (code *)swi(3);
        puVar6 = (undefined8 *)(*pcVar4)();
        return puVar6;
    }
    uVar7 = (int64_t)*(undefined8 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3;
    if (uVar7 <= 0x1fffffffffffffff - (uVar7 >> 1)) {
        uVar1 = iVar12 + 1;
        uVar7 = uVar7 + (uVar7 >> 1);
        uVar11 = uVar1;
        if (uVar1 <= uVar7) {
            uVar11 = uVar7;
        }
        if (uVar11 < 0x2000000000000000) {
            uVar7 = uVar11 * 8;
            if (uVar7 == 0) {
                puVar13 = (undefined8 *)0x0;
                puVar10 = auStack_38;
            } else if (uVar7 < 0x1000) {
                puVar13 = (undefined8 *)fcn.180459890();
            } else {
                if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800c12a9;
                iVar5 = fcn.180459890(uVar7 + 0x27);
                if (iVar5 == 0) {
                    pcVar4 = (code *)swi(0x29);
                    iVar5 = (*pcVar4)(5);
                    puVar9 = auStack_30;
                }
                puVar13 = (undefined8 *)(iVar5 + 0x27U & 0xffffffffffffffe0);
                puVar13[-1] = iVar5;
                puVar10 = puVar9;
            }
            puVar2 = puVar13 + iVar12;
            *puVar2 = *(undefined8 *)arg2;
            puVar3 = *(undefined8 **)arg1;
            if (puVar6 == *(undefined8 **)(arg1 + 8)) {
                iVar12 = (int64_t)*(undefined8 **)(arg1 + 8) - (int64_t)puVar3;
                puVar8 = puVar13;
                puVar6 = puVar3;
            } else {
                *(undefined8 *)(puVar10 + -8) = 0x1800c125e;
                fcn.180498030(puVar13, puVar3, (int64_t)puVar6 - (int64_t)puVar3);
                puVar8 = puVar2 + 1;
                iVar12 = *(int64_t *)(arg1 + 8) - (int64_t)puVar6;
            }
            *(undefined8 *)(puVar10 + -8) = 0x1800c1271;
            fcn.180498030(puVar8, puVar6, iVar12);
            *(undefined8 *)(puVar10 + -8) = 0x1800c1282;
            fcn.1800c2120(arg1, puVar13, uVar1, uVar11);
            return puVar2;
        }
    }
code_r0x0001800c12a9:
    fcn.180004720();
    pcVar4 = (code *)swi(3);
    puVar6 = (undefined8 *)(*pcVar4)();
    return puVar6;
}

// ============================================================
// Function: FUN_1800c12b0
// Address: 0x1800c12b0
// Size: 143 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.1800c12b0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = *(undefined8 *)arg2;
    if (arg3 != 0) {
        iVar1 = fcn.180459890(arg3 << 4);
        uVar2 = 0;
        *(int64_t *)arg1 = iVar1;
        *(int64_t *)(arg1 + 8) = arg3;
        if (arg3 != 0) {
            do {
                uVar3 = uVar2 + 1;
                *(undefined8 *)(iVar1 + uVar2 * 0x10) = *(undefined8 *)arg2;
                *(undefined *)(iVar1 + 8 + uVar2 * 0x10) = 0;
                uVar2 = uVar3;
            } while (uVar3 < (uint64_t)arg3);
        }
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800c1340
// Address: 0x1800c1340
// Size: 138 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t * fcn.1800c1340(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint64_t *puVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar1 = *(uint64_t *)arg2;
    uVar5 = *(int64_t *)(arg1 + 8) - 1;
    uVar2 = (uVar1 >> 5 ^ uVar1) >> 4;
    uVar3 = 0;
    while( true ) {
        uVar2 = uVar2 & uVar5;
        puVar4 = (uint64_t *)(uVar2 * 0x10 + *(int64_t *)arg1);
        if (*puVar4 == *(uint64_t *)(arg1 + 0x18)) {
            *puVar4 = uVar1;
            *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
            return puVar4;
        }
        if (*puVar4 == uVar1) break;
        uVar2 = uVar2 + 1 + uVar3;
        uVar3 = uVar3 + 1;
        if (uVar5 < uVar3) {
            return (uint64_t *)0x0;
        }
    }
    return puVar4;
}

// ============================================================
// Function: FUN_1800c13d0
// Address: 0x1800c13d0
// Size: 121 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t * fcn.1800c13d0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    uint64_t *puVar5;
    uint64_t uVar6;
    int64_t var_8h;
    
    if (*(int64_t *)(arg1 + 0x10) != 0) {
        uVar1 = *(uint64_t *)arg2;
        if (uVar1 != *(uint64_t *)(arg1 + 0x18)) {
            uVar6 = *(int64_t *)(arg1 + 8) - 1;
            uVar3 = (uVar1 >> 5 ^ uVar1) >> 4;
            uVar4 = 0;
            do {
                uVar3 = uVar3 & uVar6;
                puVar5 = (uint64_t *)(uVar3 * 0x20 + *(int64_t *)arg1);
                uVar2 = *puVar5;
                if (uVar2 == uVar1) {
                    return puVar5;
                }
                if (uVar2 == *(uint64_t *)(arg1 + 0x18)) {
                    return (uint64_t *)0x0;
                }
                uVar3 = uVar3 + 1 + uVar4;
                uVar4 = uVar4 + 1;
            } while (uVar4 <= uVar6);
        }
    }
    return (uint64_t *)0x0;
}

// ============================================================
// Function: FUN_1800c1450
// Address: 0x1800c1450
// Size: 138 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t * fcn.1800c1450(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint64_t *puVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar1 = *(uint64_t *)arg2;
    uVar5 = *(int64_t *)(arg1 + 8) - 1;
    uVar2 = (uVar1 >> 5 ^ uVar1) >> 4;
    uVar3 = 0;
    while( true ) {
        uVar2 = uVar2 & uVar5;
        puVar4 = (uint64_t *)(uVar2 * 0x20 + *(int64_t *)arg1);
        if (*puVar4 == *(uint64_t *)(arg1 + 0x18)) {
            *puVar4 = uVar1;
            *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
            return puVar4;
        }
        if (*puVar4 == uVar1) break;
        uVar2 = uVar2 + 1 + uVar3;
        uVar3 = uVar3 + 1;
        if (uVar5 < uVar3) {
            return (uint64_t *)0x0;
        }
    }
    return puVar4;
}

// ============================================================
// Function: FUN_1800c14e0
// Address: 0x1800c14e0
// Size: 122 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t * fcn.1800c14e0(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar2 = *(uint64_t *)arg2;
    uVar6 = *(int64_t *)(arg1 + 8) - 1;
    uVar4 = (uVar2 >> 5 ^ uVar2) >> 4;
    uVar5 = 0;
    while( true ) {
        uVar4 = uVar4 & uVar6;
        puVar1 = (uint64_t *)(*(int64_t *)arg1 + uVar4 * 0x18);
        uVar3 = *(uint64_t *)(*(int64_t *)arg1 + uVar4 * 0x18);
        if (uVar3 == *(uint64_t *)(arg1 + 0x18)) {
            *puVar1 = uVar2;
            *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
            return puVar1;
        }
        if (uVar3 == uVar2) break;
        uVar4 = uVar4 + 1 + uVar5;
        uVar5 = uVar5 + 1;
        if (uVar6 < uVar5) {
            return (uint64_t *)0x0;
        }
    }
    return puVar1;
}

// ============================================================
// Function: FUN_1800c1560
// Address: 0x1800c1560
// Size: 116 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800c1560(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t var_8h;
    
    if (*(int64_t *)(arg1 + 0x10) != 0) {
        uVar1 = *(uint64_t *)arg2;
        if (uVar1 != *(uint64_t *)(arg1 + 0x18)) {
            uVar5 = *(int64_t *)(arg1 + 8) - 1;
            uVar3 = (uVar1 >> 5 ^ uVar1) >> 4;
            uVar4 = 0;
            do {
                uVar3 = uVar3 & uVar5;
                uVar2 = *(uint64_t *)(*(int64_t *)arg1 + uVar3 * 8);
                if (uVar2 == uVar1) {
                    return *(int64_t *)arg1 + uVar3 * 8;
                }
                if (uVar2 == *(uint64_t *)(arg1 + 0x18)) {
                    return 0;
                }
                uVar3 = uVar3 + 1 + uVar4;
                uVar4 = uVar4 + 1;
            } while (uVar4 <= uVar5);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1800c15e0
// Address: 0x1800c15e0
// Size: 118 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_78h

uint64_t * fcn.1800c0314(int64_t arg_38h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t *puVar6;
    int64_t *unaff_RBX;
    int64_t unaff_RDI;
    uint64_t in_R11;
    int64_t unaff_R14;
    uint64_t *unaff_R15;
    
    do {
        uVar1 = *(uint64_t *)(*unaff_RBX + in_R11 * 8);
        if (uVar1 != unaff_RBX[3]) {
            uVar4 = (uVar1 >> 5 ^ uVar1) >> 4;
            uVar5 = 0;
            do {
                uVar4 = uVar4 & unaff_R14 - 1U;
                uVar2 = *(uint64_t *)(unaff_RDI + uVar4 * 8);
                puVar6 = (uint64_t *)(unaff_RDI + uVar4 * 8);
                if (uVar2 == arg_38h) {
                    *puVar6 = uVar1;
                    goto code_r0x0001800c037a;
                }
                if (uVar2 == uVar1) goto code_r0x0001800c037a;
                uVar4 = uVar4 + 1 + uVar5;
                uVar5 = uVar5 + 1;
            } while (uVar5 <= unaff_R14 - 1U);
            puVar6 = (uint64_t *)0x0;
code_r0x0001800c037a:
            *puVar6 = *(uint64_t *)(*unaff_RBX + in_R11 * 8);
        }
        in_R11 = in_R11 + 1;
        if ((uint64_t)unaff_RBX[1] <= in_R11) {
            iVar3 = *unaff_RBX;
            unaff_RBX[1] = unaff_R14;
            *unaff_RBX = unaff_RDI;
            if (iVar3 != 0) {
                fcn.1800f4640();
            }
            uVar1 = *unaff_R15;
            uVar4 = (uVar1 >> 5 ^ uVar1) >> 4;
            uVar5 = 0;
            while( true ) {
                uVar4 = uVar4 & unaff_RBX[1] - 1U;
                uVar2 = *(uint64_t *)(*unaff_RBX + uVar4 * 8);
                puVar6 = (uint64_t *)(*unaff_RBX + uVar4 * 8);
                if (uVar2 == unaff_RBX[3]) {
                    *puVar6 = uVar1;
                    unaff_RBX[2] = unaff_RBX[2] + 1;
                    return puVar6;
                }
                if (uVar2 == uVar1) break;
                uVar4 = uVar4 + 1 + uVar5;
                uVar5 = uVar5 + 1;
                if (unaff_RBX[1] - 1U < uVar5) {
                    return (uint64_t *)0x0;
                }
            }
            return puVar6;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1800c1660
// Address: 0x1800c1660
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800c1660(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    undefined8 uVar1;
    undefined8 *puVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined8 *puVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = *(undefined8 *)arg2;
    if (arg3 != 0) {
        puVar2 = (undefined8 *)fcn.180459890();
        *(undefined8 **)arg1 = puVar2;
        *(int64_t *)(arg1 + 8) = arg3;
        if (arg3 != 0) {
            uVar3 = 0;
            if ((uint64_t)arg3 < 2) goto code_r0x0001800c1720;
            if ((puVar2 <= (uint64_t)arg2) && ((uint64_t)arg2 <= puVar2 + arg3 + -1)) goto code_r0x0001800c1720;
            uVar1 = *(undefined8 *)arg2;
            do {
                uVar3 = uVar3 + 2;
            } while (uVar3 < (arg3 & 0xfffffffffffffffeU));
            puVar5 = puVar2;
            for (uVar4 = (((uint64_t)arg3 >> 1) << 4) >> 3; uVar4 != 0; uVar4 = uVar4 - 1) {
                *puVar5 = uVar1;
                puVar5 = puVar5 + 1;
            }
            for (; uVar3 < (uint64_t)arg3; uVar3 = uVar3 + 1) {
code_r0x0001800c1720:
                puVar2[uVar3] = *(undefined8 *)arg2;
            }
        }
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800c16a0
// Address: 0x1800c16a0
// Size: 148 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800c1660(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    undefined8 uVar1;
    undefined8 *puVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined8 *puVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = *(undefined8 *)arg2;
    if (arg3 != 0) {
        puVar2 = (undefined8 *)fcn.180459890();
        *(undefined8 **)arg1 = puVar2;
        *(int64_t *)(arg1 + 8) = arg3;
        if (arg3 != 0) {
            uVar3 = 0;
            if ((uint64_t)arg3 < 2) goto code_r0x0001800c1720;
            if ((puVar2 <= (uint64_t)arg2) && ((uint64_t)arg2 <= puVar2 + arg3 + -1)) goto code_r0x0001800c1720;
            uVar1 = *(undefined8 *)arg2;
            do {
                uVar3 = uVar3 + 2;
            } while (uVar3 < (arg3 & 0xfffffffffffffffeU));
            puVar5 = puVar2;
            for (uVar4 = (((uint64_t)arg3 >> 1) << 4) >> 3; uVar4 != 0; uVar4 = uVar4 - 1) {
                *puVar5 = uVar1;
                puVar5 = puVar5 + 1;
            }
            for (; uVar3 < (uint64_t)arg3; uVar3 = uVar3 + 1) {
code_r0x0001800c1720:
                puVar2[uVar3] = *(undefined8 *)arg2;
            }
        }
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800c1734
// Address: 0x1800c1734
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800c1660(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    undefined8 uVar1;
    undefined8 *puVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined8 *puVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = *(undefined8 *)arg2;
    if (arg3 != 0) {
        puVar2 = (undefined8 *)fcn.180459890();
        *(undefined8 **)arg1 = puVar2;
        *(int64_t *)(arg1 + 8) = arg3;
        if (arg3 != 0) {
            uVar3 = 0;
            if ((uint64_t)arg3 < 2) goto code_r0x0001800c1720;
            if ((puVar2 <= (uint64_t)arg2) && ((uint64_t)arg2 <= puVar2 + arg3 + -1)) goto code_r0x0001800c1720;
            uVar1 = *(undefined8 *)arg2;
            do {
                uVar3 = uVar3 + 2;
            } while (uVar3 < (arg3 & 0xfffffffffffffffeU));
            puVar5 = puVar2;
            for (uVar4 = (((uint64_t)arg3 >> 1) << 4) >> 3; uVar4 != 0; uVar4 = uVar4 - 1) {
                *puVar5 = uVar1;
                puVar5 = puVar5 + 1;
            }
            for (; uVar3 < (uint64_t)arg3; uVar3 = uVar3 + 1) {
code_r0x0001800c1720:
                puVar2[uVar3] = *(undefined8 *)arg2;
            }
        }
    }
    return arg1;
}

