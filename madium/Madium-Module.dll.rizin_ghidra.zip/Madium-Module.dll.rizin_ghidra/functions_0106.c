// Chunk 106 - 50 functions

// ============================================================
// Function: FUN_1801723e0
// Address: 0x1801723e0
// Size: 20 bytes
// ============================================================
undefined8 * fcn.1801723e0(int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    undefined8 uVar4;
    undefined *puVar5;
    int64_t iVar6;
    undefined8 uStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_8h;
    
    if (*(undefined8 **)0x18077e0b0 == (undefined8 *)0x0) {
        uStackX_8 = fcn.180467bd4(0);
        iVar2 = fcn.180461948(&uStackX_8);
        iVar1 = *(int32_t *)(iVar2 + 8);
        iVar2 = fcn.18046e560(&uStackX_8);
        *(int32_t *)0x18069c0a0 = (iVar1 - *(int32_t *)(iVar2 + 8)) * 0xe10;
        puVar3 = (undefined8 *)fcn.18046d050(0x2b8);
        iVar2 = 0;
        *puVar3 = 0;
        *(undefined4 *)(puVar3 + 1) = 0x4000;
        uVar4 = fcn.18046d050(0x4000);
        puVar3[2] = uVar4;
        puVar3[3] = 2;
        fcn.180498d90(puVar3 + 4, 0x1804a5988, 0x3f);
        puVar3[0x2f] = 0;
        puVar3[0x2c] = 0x1000000;
        *(undefined4 *)(puVar3 + 0x2d) = 0x3f7d70a4;
        *(undefined4 *)((int64_t)puVar3 + 0x16c) = 1;
        *(undefined4 *)(puVar3 + 0x2e) = 1;
        fcn.180498d90(puVar3 + 0xc, 0x1804a59a4, 0xff);
        puVar5 = (undefined *)fcn.18045b9a8(puVar3 + 0xc, 0x2e);
        if (puVar5 != (undefined *)0x0) {
            do {
                iVar6 = iVar2 + 1;
                if (puVar5[iVar2] != *(char *)(iVar2 + 0x1804a59c4)) goto code_r0x0001801724f8;
                iVar2 = iVar6;
            } while (iVar6 != 5);
            *puVar5 = 0;
        }
code_r0x0001801724f8:
        puVar3[0x50] = 0;
        *(undefined4 *)(puVar3 + 0x51) = 0xffffffff;
        (*(code *)0x699f00)(puVar3 + 0x52);
        *(undefined8 **)0x18077e0b0 = puVar3;
        fcn.180459c24(0x180172540);
    }
    return *(undefined8 **)0x18077e0b0;
}

// ============================================================
// Function: FUN_1801723f4
// Address: 0x1801723f4
// Size: 228 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 * fcn.1801723e0(int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    undefined8 uVar4;
    undefined *puVar5;
    int64_t iVar6;
    undefined8 uStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_8h;
    
    if (*(undefined8 **)0x18077e0b0 == (undefined8 *)0x0) {
        uStackX_8 = fcn.180467bd4(0);
        iVar2 = fcn.180461948(&uStackX_8);
        iVar1 = *(int32_t *)(iVar2 + 8);
        iVar2 = fcn.18046e560(&uStackX_8);
        *(int32_t *)0x18069c0a0 = (iVar1 - *(int32_t *)(iVar2 + 8)) * 0xe10;
        puVar3 = (undefined8 *)fcn.18046d050(0x2b8);
        iVar2 = 0;
        *puVar3 = 0;
        *(undefined4 *)(puVar3 + 1) = 0x4000;
        uVar4 = fcn.18046d050(0x4000);
        puVar3[2] = uVar4;
        puVar3[3] = 2;
        fcn.180498d90(puVar3 + 4, 0x1804a5988, 0x3f);
        puVar3[0x2f] = 0;
        puVar3[0x2c] = 0x1000000;
        *(undefined4 *)(puVar3 + 0x2d) = 0x3f7d70a4;
        *(undefined4 *)((int64_t)puVar3 + 0x16c) = 1;
        *(undefined4 *)(puVar3 + 0x2e) = 1;
        fcn.180498d90(puVar3 + 0xc, 0x1804a59a4, 0xff);
        puVar5 = (undefined *)fcn.18045b9a8(puVar3 + 0xc, 0x2e);
        if (puVar5 != (undefined *)0x0) {
            do {
                iVar6 = iVar2 + 1;
                if (puVar5[iVar2] != *(char *)(iVar2 + 0x1804a59c4)) goto code_r0x0001801724f8;
                iVar2 = iVar6;
            } while (iVar6 != 5);
            *puVar5 = 0;
        }
code_r0x0001801724f8:
        puVar3[0x50] = 0;
        *(undefined4 *)(puVar3 + 0x51) = 0xffffffff;
        (*(code *)0x699f00)(puVar3 + 0x52);
        *(undefined8 **)0x18077e0b0 = puVar3;
        fcn.180459c24(0x180172540);
    }
    return *(undefined8 **)0x18077e0b0;
}

// ============================================================
// Function: FUN_1801724d8
// Address: 0x1801724d8
// Size: 98 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 * fcn.1801723e0(int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    undefined8 uVar4;
    undefined *puVar5;
    int64_t iVar6;
    undefined8 uStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_8h;
    
    if (*(undefined8 **)0x18077e0b0 == (undefined8 *)0x0) {
        uStackX_8 = fcn.180467bd4(0);
        iVar2 = fcn.180461948(&uStackX_8);
        iVar1 = *(int32_t *)(iVar2 + 8);
        iVar2 = fcn.18046e560(&uStackX_8);
        *(int32_t *)0x18069c0a0 = (iVar1 - *(int32_t *)(iVar2 + 8)) * 0xe10;
        puVar3 = (undefined8 *)fcn.18046d050(0x2b8);
        iVar2 = 0;
        *puVar3 = 0;
        *(undefined4 *)(puVar3 + 1) = 0x4000;
        uVar4 = fcn.18046d050(0x4000);
        puVar3[2] = uVar4;
        puVar3[3] = 2;
        fcn.180498d90(puVar3 + 4, 0x1804a5988, 0x3f);
        puVar3[0x2f] = 0;
        puVar3[0x2c] = 0x1000000;
        *(undefined4 *)(puVar3 + 0x2d) = 0x3f7d70a4;
        *(undefined4 *)((int64_t)puVar3 + 0x16c) = 1;
        *(undefined4 *)(puVar3 + 0x2e) = 1;
        fcn.180498d90(puVar3 + 0xc, 0x1804a59a4, 0xff);
        puVar5 = (undefined *)fcn.18045b9a8(puVar3 + 0xc, 0x2e);
        if (puVar5 != (undefined *)0x0) {
            do {
                iVar6 = iVar2 + 1;
                if (puVar5[iVar2] != *(char *)(iVar2 + 0x1804a59c4)) goto code_r0x0001801724f8;
                iVar2 = iVar6;
            } while (iVar6 != 5);
            *puVar5 = 0;
        }
code_r0x0001801724f8:
        puVar3[0x50] = 0;
        *(undefined4 *)(puVar3 + 0x51) = 0xffffffff;
        (*(code *)0x699f00)(puVar3 + 0x52);
        *(undefined8 **)0x18077e0b0 = puVar3;
        fcn.180459c24(0x180172540);
    }
    return *(undefined8 **)0x18077e0b0;
}

// ============================================================
// Function: FUN_18017253a
// Address: 0x18017253a
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 * fcn.1801723e0(int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    undefined8 uVar4;
    undefined *puVar5;
    int64_t iVar6;
    undefined8 uStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_8h;
    
    if (*(undefined8 **)0x18077e0b0 == (undefined8 *)0x0) {
        uStackX_8 = fcn.180467bd4(0);
        iVar2 = fcn.180461948(&uStackX_8);
        iVar1 = *(int32_t *)(iVar2 + 8);
        iVar2 = fcn.18046e560(&uStackX_8);
        *(int32_t *)0x18069c0a0 = (iVar1 - *(int32_t *)(iVar2 + 8)) * 0xe10;
        puVar3 = (undefined8 *)fcn.18046d050(0x2b8);
        iVar2 = 0;
        *puVar3 = 0;
        *(undefined4 *)(puVar3 + 1) = 0x4000;
        uVar4 = fcn.18046d050(0x4000);
        puVar3[2] = uVar4;
        puVar3[3] = 2;
        fcn.180498d90(puVar3 + 4, 0x1804a5988, 0x3f);
        puVar3[0x2f] = 0;
        puVar3[0x2c] = 0x1000000;
        *(undefined4 *)(puVar3 + 0x2d) = 0x3f7d70a4;
        *(undefined4 *)((int64_t)puVar3 + 0x16c) = 1;
        *(undefined4 *)(puVar3 + 0x2e) = 1;
        fcn.180498d90(puVar3 + 0xc, 0x1804a59a4, 0xff);
        puVar5 = (undefined *)fcn.18045b9a8(puVar3 + 0xc, 0x2e);
        if (puVar5 != (undefined *)0x0) {
            do {
                iVar6 = iVar2 + 1;
                if (puVar5[iVar2] != *(char *)(iVar2 + 0x1804a59c4)) goto code_r0x0001801724f8;
                iVar2 = iVar6;
            } while (iVar6 != 5);
            *puVar5 = 0;
        }
code_r0x0001801724f8:
        puVar3[0x50] = 0;
        *(undefined4 *)(puVar3 + 0x51) = 0xffffffff;
        (*(code *)0x699f00)(puVar3 + 0x52);
        *(undefined8 **)0x18077e0b0 = puVar3;
        fcn.180459c24(0x180172540);
    }
    return *(undefined8 **)0x18077e0b0;
}

// ============================================================
// Function: FUN_180172540
// Address: 0x180172540
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180172540(void)
{
    int64_t iVar1;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)0x18077e0b0;
    if (*(int64_t *)0x18077e0b0 != 0) {
        (*(code *)0x699f1c)(*(int64_t *)0x18077e0b0 + 0x290);
        if (*(int64_t *)(iVar1 + 0x178) != 0) {
            func_0x00018045fdf8();
        }
        (*(code *)0x699f34)(iVar1 + 0x290);
        iVar1 = *(int64_t *)0x18077e0b0;
        if (*(int64_t *)0x18077e0b0 != 0) {
            if (*(int64_t *)(*(int64_t *)0x18077e0b0 + 0x10) != 0) {
                func_0x000180460d90();
                *(undefined8 *)(iVar1 + 0x10) = 0;
            }
            if (*(int64_t *)(iVar1 + 0x178) != 0) {
                func_0x00018045ff84();
                *(undefined8 *)(iVar1 + 0x178) = 0;
            }
            (*(code *)0x699f4c)(iVar1 + 0x290);
            func_0x000180460d90(iVar1);
        }
        *(int64_t *)0x18077e0b0 = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18017255d
// Address: 0x18017255d
// Size: 130 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180172540(void)
{
    int64_t iVar1;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)0x18077e0b0;
    if (*(int64_t *)0x18077e0b0 != 0) {
        (*(code *)0x699f1c)(*(int64_t *)0x18077e0b0 + 0x290);
        if (*(int64_t *)(iVar1 + 0x178) != 0) {
            func_0x00018045fdf8();
        }
        (*(code *)0x699f34)(iVar1 + 0x290);
        iVar1 = *(int64_t *)0x18077e0b0;
        if (*(int64_t *)0x18077e0b0 != 0) {
            if (*(int64_t *)(*(int64_t *)0x18077e0b0 + 0x10) != 0) {
                func_0x000180460d90();
                *(undefined8 *)(iVar1 + 0x10) = 0;
            }
            if (*(int64_t *)(iVar1 + 0x178) != 0) {
                func_0x00018045ff84();
                *(undefined8 *)(iVar1 + 0x178) = 0;
            }
            (*(code *)0x699f4c)(iVar1 + 0x290);
            func_0x000180460d90(iVar1);
        }
        *(int64_t *)0x18077e0b0 = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1801725df
// Address: 0x1801725df
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180172540(void)
{
    int64_t iVar1;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)0x18077e0b0;
    if (*(int64_t *)0x18077e0b0 != 0) {
        (*(code *)0x699f1c)(*(int64_t *)0x18077e0b0 + 0x290);
        if (*(int64_t *)(iVar1 + 0x178) != 0) {
            func_0x00018045fdf8();
        }
        (*(code *)0x699f34)(iVar1 + 0x290);
        iVar1 = *(int64_t *)0x18077e0b0;
        if (*(int64_t *)0x18077e0b0 != 0) {
            if (*(int64_t *)(*(int64_t *)0x18077e0b0 + 0x10) != 0) {
                func_0x000180460d90();
                *(undefined8 *)(iVar1 + 0x10) = 0;
            }
            if (*(int64_t *)(iVar1 + 0x178) != 0) {
                func_0x00018045ff84();
                *(undefined8 *)(iVar1 + 0x178) = 0;
            }
            (*(code *)0x699f4c)(iVar1 + 0x290);
            func_0x000180460d90(iVar1);
        }
        *(int64_t *)0x18077e0b0 = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1801725f0
// Address: 0x1801725f0
// Size: 178 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801725f0(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined auVar3 [16];
    int64_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_168 [32];
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_128h;
    int64_t var_118h;
    uint64_t uStack_18;
    int64_t var_8h;
    
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_168;
    iVar4 = fcn.180467bd4(0);
    if (*(int64_t *)(arg1 + 0x280) == 0) {
        iVar6 = 0;
    } else {
        iVar6 = (int32_t)((*(int32_t *)0x18069c0a0 + iVar4) / 0x15180) -
                (int32_t)(((int64_t)*(int32_t *)0x18069c0a0 + *(int64_t *)(arg1 + 0x280)) / 0x15180);
    }
    if (*(int64_t *)(arg1 + 0x178) == 0) {
        iVar6 = 0x1e;
code_r0x0001801726a2:
        iVar2 = *(int32_t *)(arg1 + 0x16c);
        if (-1 < iVar2) {
            func_0x0001804986e0(&var_118h, 0, 0x100);
            if (iVar6 < iVar2) {
                var_128h = iVar4 - iVar2 * 0x15180;
                iVar5 = fcn.180461948(&var_128h);
                var_140h._0_4_ = *(int32_t *)(iVar5 + 0x10) + 1;
                var_138h._0_4_ = *(undefined4 *)(iVar5 + 0xc);
                var_148h._0_4_ = *(int32_t *)(iVar5 + 0x14) + 0x76c;
                func_0x000180065f60(&var_118h, 0x100, 0x1804a59d0, arg1 + 0x60);
                func_0x000180471d2c(&var_118h);
            } else {
                do {
                    var_128h = iVar4 - iVar6 * 0x15180;
                    iVar5 = fcn.180461948(&var_128h);
                    var_140h._0_4_ = *(int32_t *)(iVar5 + 0x10) + 1;
                    var_138h._0_4_ = *(undefined4 *)(iVar5 + 0xc);
                    var_148h._0_4_ = *(int32_t *)(iVar5 + 0x14) + 0x76c;
                    func_0x000180065f60(&var_118h, 0x100, 0x1804a59d0, arg1 + 0x60);
                    func_0x000180471d2c(&var_118h);
                    iVar6 = iVar6 + -1;
                } while (*(int32_t *)(arg1 + 0x16c) <= iVar6);
            }
        }
    } else if (0 < iVar6) {
        func_0x00018045ff84();
        *(undefined8 *)(arg1 + 0x178) = 0;
        goto code_r0x0001801726a2;
    }
    iVar5 = *(int64_t *)(arg1 + 0x178);
    if (iVar5 == 0) {
        var_128h = iVar4;
        iVar5 = fcn.180461948(&var_128h);
        var_140h._0_4_ = *(int32_t *)(iVar5 + 0x10) + 1;
        var_138h._0_4_ = *(undefined4 *)(iVar5 + 0xc);
        var_148h._0_4_ = *(int32_t *)(iVar5 + 0x14) + 0x76c;
        func_0x000180065f60(arg1 + 0x180, 0x100, 0x1804a59d0, arg1 + 0x60);
        iVar5 = func_0x00018046d990(arg1 + 0x180);
        *(int64_t *)(arg1 + 0x178) = iVar5;
        *(int64_t *)(arg1 + 0x280) = iVar4;
        if (iVar5 == 0) goto code_r0x00018017287b;
    }
    piVar1 = (int32_t *)(arg1 + 0x288);
    *piVar1 = *piVar1 + -1;
    if (*piVar1 < 0) {
        func_0x000180461598(iVar5, 0, 2);
        iVar6 = func_0x00018046d704(*(undefined8 *)(arg1 + 0x178));
        if (*(uint64_t *)(arg1 + 0x160) < (uint64_t)(int64_t)iVar6) {
            func_0x0001801728a0(arg1);
        } else {
            auVar3._8_8_ = 0;
            auVar3._0_8_ = *(uint64_t *)(arg1 + 0x160) - (int64_t)iVar6;
            *(int32_t *)(arg1 + 0x288) = SUB164(auVar3 / ZEXT416(*(uint32_t *)(arg1 + 8)), 0);
        }
    }
code_r0x00018017287b:
    func_0x000180459870(uStack_18 ^ (uint64_t)auStack_168);
    return;
}

// ============================================================
// Function: FUN_1801726a2
// Address: 0x1801726a2
// Size: 256 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801725f0(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined auVar3 [16];
    int64_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_168 [32];
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_128h;
    int64_t var_118h;
    uint64_t uStack_18;
    int64_t var_8h;
    
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_168;
    iVar4 = fcn.180467bd4(0);
    if (*(int64_t *)(arg1 + 0x280) == 0) {
        iVar6 = 0;
    } else {
        iVar6 = (int32_t)((*(int32_t *)0x18069c0a0 + iVar4) / 0x15180) -
                (int32_t)(((int64_t)*(int32_t *)0x18069c0a0 + *(int64_t *)(arg1 + 0x280)) / 0x15180);
    }
    if (*(int64_t *)(arg1 + 0x178) == 0) {
        iVar6 = 0x1e;
code_r0x0001801726a2:
        iVar2 = *(int32_t *)(arg1 + 0x16c);
        if (-1 < iVar2) {
            func_0x0001804986e0(&var_118h, 0, 0x100);
            if (iVar6 < iVar2) {
                var_128h = iVar4 - iVar2 * 0x15180;
                iVar5 = fcn.180461948(&var_128h);
                var_140h._0_4_ = *(int32_t *)(iVar5 + 0x10) + 1;
                var_138h._0_4_ = *(undefined4 *)(iVar5 + 0xc);
                var_148h._0_4_ = *(int32_t *)(iVar5 + 0x14) + 0x76c;
                func_0x000180065f60(&var_118h, 0x100, 0x1804a59d0, arg1 + 0x60);
                func_0x000180471d2c(&var_118h);
            } else {
                do {
                    var_128h = iVar4 - iVar6 * 0x15180;
                    iVar5 = fcn.180461948(&var_128h);
                    var_140h._0_4_ = *(int32_t *)(iVar5 + 0x10) + 1;
                    var_138h._0_4_ = *(undefined4 *)(iVar5 + 0xc);
                    var_148h._0_4_ = *(int32_t *)(iVar5 + 0x14) + 0x76c;
                    func_0x000180065f60(&var_118h, 0x100, 0x1804a59d0, arg1 + 0x60);
                    func_0x000180471d2c(&var_118h);
                    iVar6 = iVar6 + -1;
                } while (*(int32_t *)(arg1 + 0x16c) <= iVar6);
            }
        }
    } else if (0 < iVar6) {
        func_0x00018045ff84();
        *(undefined8 *)(arg1 + 0x178) = 0;
        goto code_r0x0001801726a2;
    }
    iVar5 = *(int64_t *)(arg1 + 0x178);
    if (iVar5 == 0) {
        var_128h = iVar4;
        iVar5 = fcn.180461948(&var_128h);
        var_140h._0_4_ = *(int32_t *)(iVar5 + 0x10) + 1;
        var_138h._0_4_ = *(undefined4 *)(iVar5 + 0xc);
        var_148h._0_4_ = *(int32_t *)(iVar5 + 0x14) + 0x76c;
        func_0x000180065f60(arg1 + 0x180, 0x100, 0x1804a59d0, arg1 + 0x60);
        iVar5 = func_0x00018046d990(arg1 + 0x180);
        *(int64_t *)(arg1 + 0x178) = iVar5;
        *(int64_t *)(arg1 + 0x280) = iVar4;
        if (iVar5 == 0) goto code_r0x00018017287b;
    }
    piVar1 = (int32_t *)(arg1 + 0x288);
    *piVar1 = *piVar1 + -1;
    if (*piVar1 < 0) {
        func_0x000180461598(iVar5, 0, 2);
        iVar6 = func_0x00018046d704(*(undefined8 *)(arg1 + 0x178));
        if (*(uint64_t *)(arg1 + 0x160) < (uint64_t)(int64_t)iVar6) {
            func_0x0001801728a0(arg1);
        } else {
            auVar3._8_8_ = 0;
            auVar3._0_8_ = *(uint64_t *)(arg1 + 0x160) - (int64_t)iVar6;
            *(int32_t *)(arg1 + 0x288) = SUB164(auVar3 / ZEXT416(*(uint32_t *)(arg1 + 8)), 0);
        }
    }
code_r0x00018017287b:
    func_0x000180459870(uStack_18 ^ (uint64_t)auStack_168);
    return;
}

// ============================================================
// Function: FUN_1801727a2
// Address: 0x1801727a2
// Size: 254 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801725f0(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined auVar3 [16];
    int64_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_168 [32];
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_128h;
    int64_t var_118h;
    uint64_t uStack_18;
    int64_t var_8h;
    
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_168;
    iVar4 = fcn.180467bd4(0);
    if (*(int64_t *)(arg1 + 0x280) == 0) {
        iVar6 = 0;
    } else {
        iVar6 = (int32_t)((*(int32_t *)0x18069c0a0 + iVar4) / 0x15180) -
                (int32_t)(((int64_t)*(int32_t *)0x18069c0a0 + *(int64_t *)(arg1 + 0x280)) / 0x15180);
    }
    if (*(int64_t *)(arg1 + 0x178) == 0) {
        iVar6 = 0x1e;
code_r0x0001801726a2:
        iVar2 = *(int32_t *)(arg1 + 0x16c);
        if (-1 < iVar2) {
            func_0x0001804986e0(&var_118h, 0, 0x100);
            if (iVar6 < iVar2) {
                var_128h = iVar4 - iVar2 * 0x15180;
                iVar5 = fcn.180461948(&var_128h);
                var_140h._0_4_ = *(int32_t *)(iVar5 + 0x10) + 1;
                var_138h._0_4_ = *(undefined4 *)(iVar5 + 0xc);
                var_148h._0_4_ = *(int32_t *)(iVar5 + 0x14) + 0x76c;
                func_0x000180065f60(&var_118h, 0x100, 0x1804a59d0, arg1 + 0x60);
                func_0x000180471d2c(&var_118h);
            } else {
                do {
                    var_128h = iVar4 - iVar6 * 0x15180;
                    iVar5 = fcn.180461948(&var_128h);
                    var_140h._0_4_ = *(int32_t *)(iVar5 + 0x10) + 1;
                    var_138h._0_4_ = *(undefined4 *)(iVar5 + 0xc);
                    var_148h._0_4_ = *(int32_t *)(iVar5 + 0x14) + 0x76c;
                    func_0x000180065f60(&var_118h, 0x100, 0x1804a59d0, arg1 + 0x60);
                    func_0x000180471d2c(&var_118h);
                    iVar6 = iVar6 + -1;
                } while (*(int32_t *)(arg1 + 0x16c) <= iVar6);
            }
        }
    } else if (0 < iVar6) {
        func_0x00018045ff84();
        *(undefined8 *)(arg1 + 0x178) = 0;
        goto code_r0x0001801726a2;
    }
    iVar5 = *(int64_t *)(arg1 + 0x178);
    if (iVar5 == 0) {
        var_128h = iVar4;
        iVar5 = fcn.180461948(&var_128h);
        var_140h._0_4_ = *(int32_t *)(iVar5 + 0x10) + 1;
        var_138h._0_4_ = *(undefined4 *)(iVar5 + 0xc);
        var_148h._0_4_ = *(int32_t *)(iVar5 + 0x14) + 0x76c;
        func_0x000180065f60(arg1 + 0x180, 0x100, 0x1804a59d0, arg1 + 0x60);
        iVar5 = func_0x00018046d990(arg1 + 0x180);
        *(int64_t *)(arg1 + 0x178) = iVar5;
        *(int64_t *)(arg1 + 0x280) = iVar4;
        if (iVar5 == 0) goto code_r0x00018017287b;
    }
    piVar1 = (int32_t *)(arg1 + 0x288);
    *piVar1 = *piVar1 + -1;
    if (*piVar1 < 0) {
        func_0x000180461598(iVar5, 0, 2);
        iVar6 = func_0x00018046d704(*(undefined8 *)(arg1 + 0x178));
        if (*(uint64_t *)(arg1 + 0x160) < (uint64_t)(int64_t)iVar6) {
            func_0x0001801728a0(arg1);
        } else {
            auVar3._8_8_ = 0;
            auVar3._0_8_ = *(uint64_t *)(arg1 + 0x160) - (int64_t)iVar6;
            *(int32_t *)(arg1 + 0x288) = SUB164(auVar3 / ZEXT416(*(uint32_t *)(arg1 + 8)), 0);
        }
    }
code_r0x00018017287b:
    func_0x000180459870(uStack_18 ^ (uint64_t)auStack_168);
    return;
}

// ============================================================
// Function: FUN_1801728a0
// Address: 0x1801728a0
// Size: 595 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_1128h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1138h because it doesn't fit into ProtoModel

void fcn.1801728a0(int64_t arg_128h)
{
    int64_t *piVar1;
    float fVar2;
    undefined8 uVar3;
    bool bVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t in_RCX;
    char *pcVar11;
    undefined8 unaff_RSI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801728b5;
    iVar7 = func_0x00018045a350();
    iVar7 = -iVar7;
    *(uint64_t *)(&stack0x00001128 + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar7);
    piVar1 = (int64_t *)(in_RCX + 0x178);
    if (*piVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801728e1;
        func_0x00018045ff84();
        *piVar1 = 0;
    }
    *(undefined8 *)(&stack0x00001150 + iVar7) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180172902;
    func_0x0001804986e0((int64_t)&var_18h + iVar7, 0, 0x104);
    if (*(float *)(in_RCX + 0x168) <= 1.0 && *(float *)(in_RCX + 0x168) != 1.0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180172934;
        func_0x000180065f60((int64_t)&var_18h + iVar7, 0x104, 0x1804a59e4, in_RCX + 0x180);
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180172945;
        iVar8 = func_0x00018046d990((int64_t)&var_18h + iVar7, 0x180621ec0);
        iVar10 = in_RCX + 0x180;
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180172967;
            iVar9 = func_0x00018046d990(iVar10, 0x1804a59ec);
            *piVar1 = iVar9;
            if (iVar9 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180172983;
                func_0x000180461598(iVar9, 0, 2);
                uVar3 = *(undefined8 *)(in_RCX + 0x178);
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18017298f;
                iVar6 = func_0x00018046d704(uVar3);
                fVar2 = *(float *)(in_RCX + 0x168);
                iVar9 = *piVar1;
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801729ba;
                func_0x000180461598(iVar9, (int32_t)((float)iVar6 * fVar2) - iVar6, 1);
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801729cf;
                func_0x0001804986e0((int64_t)&arg_128h + iVar7, 0, 0x1000);
                iVar9 = *piVar1;
                bVar4 = false;
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801729ed;
                for (iVar9 = func_0x0001804611b4((int64_t)&arg_128h + iVar7, 1, 0x1000, iVar9); iVar9 != 0;
                    iVar9 = func_0x0001804611b4((int64_t)&arg_128h + iVar7, 1, 0x1000, iVar9)) {
                    pcVar11 = (char *)((int64_t)&arg_128h + iVar7);
                    iVar5 = iVar9;
                    if (bVar4) {
code_r0x000180172a26:
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180172a36;
                        func_0x000180460a38(pcVar11, 1, iVar9, iVar8);
                    } else {
                        for (; iVar5 != 0; iVar5 = iVar5 + -1) {
                            iVar9 = iVar5 + -1;
                            if (*pcVar11 == '\n') {
                                bVar4 = true;
                                if (iVar9 != 0) {
                                    pcVar11 = pcVar11 + 1;
                                    goto code_r0x000180172a26;
                                }
                                break;
                            }
                            pcVar11 = pcVar11 + 1;
                        }
                    }
                    iVar9 = *piVar1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180172a51;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180172a5e;
                func_0x00018045ff84(iVar8);
                iVar8 = *piVar1;
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180172a66;
                func_0x00018045ff84(iVar8);
                *piVar1 = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180172a75;
                func_0x000180471d2c(iVar10);
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180172a82;
                func_0x000180471e10((int64_t)&var_18h + iVar7, iVar10);
            }
            goto code_r0x000180172ab4;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180172a9d;
    iVar10 = func_0x00018046d990(in_RCX + 0x180, 0x180621ec0);
    *piVar1 = iVar10;
    if (iVar10 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180172aad;
        func_0x00018045ff84(iVar10);
        *piVar1 = 0;
    }
code_r0x000180172ab4:
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180172ac3;
    iVar10 = func_0x00018046d990(in_RCX + 0x180, 0x1804a59f0);
    *piVar1 = iVar10;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180172ade;
    func_0x000180459870(*(uint64_t *)(&stack0x00001128 + iVar7) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar7));
    return;
}

// ============================================================
// Function: FUN_180172b00
// Address: 0x180172b00
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

void fcn.180172b00(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    uint64_t *puVar5;
    char cVar6;
    undefined *puVar7;
    undefined8 uVar8;
    int32_t iVar9;
    int64_t iVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    uint32_t uVar13;
    char *pcVar14;
    undefined *puVar15;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_f8 [32];
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    uint32_t var_98h;
    uint32_t var_94h;
    uint32_t var_90h;
    uint32_t var_8ch;
    uint32_t var_88h;
    int64_t var_84h;
    int64_t var_7ch;
    int64_t var_70h;
    int64_t var_68h;
    uint16_t var_60h;
    uint16_t var_5eh;
    uint16_t var_5ch;
    uint16_t var_5ah;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_f8;
    iVar9 = (int32_t)arg2;
    var_20h = arg4;
    var_7ch._0_4_ = iVar9;
    if (iVar9 < *(int32_t *)(arg1 + 0x18)) goto code_r0x0001801734bf;
    (*(code *)0x699f64)(&var_68h);
    var_84h._0_4_ = (uint32_t)(uint16_t)var_68h;
    var_88h = (uint32_t)var_68h._2_2_;
    var_8ch = (uint32_t)var_68h._6_2_;
    var_90h = (uint32_t)var_60h;
    var_94h = (uint32_t)var_5eh;
    var_98h = (uint32_t)var_5ch;
    uVar11 = (uint32_t)var_5ah * 1000;
    if (iVar9 == 1) {
        puVar15 = (undefined *)0x1804a59ac;
        uVar8 = 0x1804a59f4;
    } else if (iVar9 == 2) {
        puVar15 = (undefined *)0x1804a59fc;
        uVar8 = 0x1804a5a04;
    } else if (iVar9 == 3) {
        puVar15 = (undefined *)0x1804a5a0c;
        uVar8 = 0x1804a5a14;
    } else if (iVar9 == 4) {
        puVar15 = (undefined *)0x1804a59b4;
        uVar8 = 0x1804a5a1c;
    } else if (iVar9 == 5) {
        puVar15 = (undefined *)0x1804a59bc;
        uVar8 = 0x1804a5a28;
    } else {
        puVar15 = (undefined *)0x1805aadb1;
        uVar8 = 0x1805aadb1;
    }
    unique0x00003200 = arg1 + 0x290;
    var_84h._4_4_ = uVar11;
    (*(code *)0x699f1c)(unique0x00003200);
    iVar1 = *(int64_t *)(arg1 + 0x10);
    iVar3 = 0;
    iVar9 = *(int32_t *)(arg1 + 8);
    if (*(int32_t *)(arg1 + 0x1c) != 0) {
        iVar3 = func_0x000180065f60(iVar1, (int64_t)iVar9, 0x18063cc8c, uVar8);
    }
    cVar6 = *(char *)(arg1 + 0x20);
    iVar10 = arg1 + 0x20;
    if (cVar6 == '\0') {
        var_b0h._0_4_ = uVar11 / 1000;
        var_b8h._0_4_ = var_98h;
        var_c0h._0_4_ = var_94h;
        var_c8h._0_4_ = var_90h;
        var_d0h = CONCAT44(var_d0h._4_4_, var_8ch);
        var_d8h = CONCAT44(var_d8h._4_4_, var_88h);
        var_a8h = (int64_t)puVar15;
        iVar4 = func_0x000180065f60(iVar3 + iVar1, (int64_t)(iVar9 - iVar3), 0x1804a5a38, (uint32_t)var_84h);
        iVar4 = iVar4 + iVar3;
        puVar5 = (uint64_t *)func_0x0001800102c0();
        var_d8h = 0;
        var_d0h = (int64_t)&var_20h;
        iVar3 = func_0x000180467554(*puVar5 | 2, iVar4 + iVar1, (int64_t)(iVar9 - iVar4), arg3);
        if (iVar3 < 0) {
            iVar3 = -1;
        }
        iVar3 = iVar3 + iVar4;
    } else {
        do {
            if (cVar6 != '%') {
                *(char *)(iVar3 + iVar1) = cVar6;
                goto code_r0x00018017330f;
            }
            puVar7 = (undefined *)(iVar10 + 1);
            iVar10 = iVar10 + 1;
    // switch table (13 cases) at 0x1801734dc
            switch(*puVar7) {
            case 0x25:
                *(undefined *)(iVar3 + iVar1) = 0x25;
                goto code_r0x00018017330f;
            case 0x48:
                uVar12 = var_90h;
                if (var_90h == 0) {
                    *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
                } else {
code_r0x000180172e4b:
                    uVar13 = uVar12 / 10;
                    *(char *)((int64_t)iVar3 + 1 + iVar1) = (char)uVar12 + (char)uVar13 * -10 + '0';
                    if (uVar13 != 0) {
                        *(char *)(iVar3 + iVar1) = (char)uVar13 + (char)(uVar13 / 10) * -10 + '0';
                        iVar3 = iVar3 + 2;
                        break;
                    }
                }
                goto code_r0x000180172e79;
            case 0x4c:
                puVar7 = (undefined *)(iVar3 + iVar1);
                iVar3 = iVar3 + 5;
                *puVar7 = *puVar15;
                puVar7[1] = puVar15[1];
                puVar7[2] = puVar15[2];
                puVar7[3] = puVar15[3];
                puVar7[4] = puVar15[4];
                break;
            case 0x4d:
                uVar12 = var_94h;
                if (var_94h != 0) goto code_r0x000180172e4b;
                *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
                goto code_r0x000180172e79;
            case 0x53:
                uVar12 = var_98h;
                if (var_98h != 0) goto code_r0x000180172e4b;
                *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
                goto code_r0x000180172e79;
            case 0x5a:
                pcVar14 = (char *)(iVar3 + iVar1);
                if (uVar11 == 0) {
                    pcVar14[5] = '0';
                    pcVar14[4] = '0';
                    pcVar14[3] = '0';
                    iVar3 = iVar3 + 6;
                    pcVar14[2] = '0';
                    pcVar14[1] = '0';
                    *pcVar14 = '0';
                } else {
                    iVar4 = (int32_t)uVar11 / 10;
                    pcVar14[5] = (char)uVar11 + (char)iVar4 * -10 + '0';
                    if (iVar4 == 0) {
                        pcVar14[4] = '0';
                        pcVar14[3] = '0';
                        pcVar14[2] = '0';
                        iVar3 = iVar3 + 6;
                        pcVar14[1] = '0';
                        *pcVar14 = '0';
                    } else {
                        iVar2 = iVar4 / 10;
                        pcVar14[4] = (char)iVar4 + (char)iVar2 * -10 + '0';
                        if (iVar2 == 0) {
                            pcVar14[3] = '0';
                            pcVar14[2] = '0';
                            pcVar14[1] = '0';
                            iVar3 = iVar3 + 6;
                            *pcVar14 = '0';
                        } else {
                            iVar4 = iVar2 / 10;
                            pcVar14[3] = (char)iVar2 + (char)iVar4 * -10 + '0';
                            if (iVar4 == 0) {
                                pcVar14[2] = '0';
                                pcVar14[1] = '0';
                                *pcVar14 = '0';
                                iVar3 = iVar3 + 6;
                            } else {
                                iVar2 = iVar4 / 10;
                                pcVar14[2] = (char)iVar4 + (char)iVar2 * -10 + '0';
                                if (iVar2 == 0) {
                                    pcVar14[1] = '0';
                                    *pcVar14 = '0';
                                    iVar3 = iVar3 + 6;
                                } else {
                                    iVar4 = iVar2 / 10;
                                    pcVar14[1] = (char)iVar2 + (char)iVar4 * -10 + '0';
                                    if (iVar4 == 0) {
                                        *pcVar14 = '0';
                                        iVar3 = iVar3 + 6;
                                    } else {
                                        *pcVar14 = (char)iVar4 + (char)(iVar4 / 10) * -10 + '0';
                                        iVar3 = iVar3 + 6;
                                    }
                                }
                            }
                        }
                    }
                }
                break;
            case 100:
                uVar12 = var_8ch;
                if (var_8ch != 0) goto code_r0x000180172e4b;
                *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
code_r0x000180172e79:
                *(undefined *)(iVar3 + iVar1) = 0x30;
                iVar3 = iVar3 + 2;
                break;
            case 0x6c:
                *(undefined *)(iVar3 + iVar1) = *puVar15;
code_r0x00018017330f:
                iVar3 = iVar3 + 1;
                break;
            case 0x6d:
                uVar12 = var_88h;
                if (var_88h != 0) goto code_r0x000180172e4b;
                *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
                *(undefined *)(iVar3 + iVar1) = 0x30;
                iVar3 = iVar3 + 2;
                break;
            case 0x73:
                puVar5 = (uint64_t *)func_0x0001800102c0();
                var_d0h = (int64_t)&var_20h;
                var_d8h = 0;
                iVar4 = func_0x000180467554(*puVar5 | 2, iVar3 + iVar1, (int64_t)(iVar9 - iVar3), arg3);
                var_70h = 0;
                if (iVar4 < 0) {
                    iVar4 = -1;
                }
                iVar3 = iVar3 + iVar4;
                uVar11 = var_84h._4_4_;
                break;
            case 0x79:
                pcVar14 = (char *)(iVar3 + iVar1);
                if ((uint32_t)var_84h == 0) {
                    pcVar14[3] = '0';
                    pcVar14[2] = '0';
                    pcVar14[1] = '0';
                    iVar3 = iVar3 + 4;
                    *pcVar14 = '0';
                } else {
                    uVar12 = (uint32_t)var_84h / 10;
                    pcVar14[3] = (char)(uint32_t)var_84h + (char)uVar12 * -10 + '0';
                    if (uVar12 == 0) {
                        pcVar14[2] = '0';
                        pcVar14[1] = '0';
                        *pcVar14 = '0';
                        iVar3 = iVar3 + 4;
                    } else {
                        uVar13 = uVar12 / 10;
                        pcVar14[2] = (char)uVar12 + (char)uVar13 * -10 + '0';
                        if (uVar13 == 0) {
                            pcVar14[1] = '0';
                            *pcVar14 = '0';
                            iVar3 = iVar3 + 4;
                        } else {
                            uVar12 = uVar13 / 10;
                            pcVar14[1] = (char)uVar13 + (char)uVar12 * -10 + '0';
                            if (uVar12 == 0) {
                                *pcVar14 = '0';
                                iVar3 = iVar3 + 4;
                            } else {
                                *pcVar14 = (char)uVar12 + (char)(uVar12 / 10) * -10 + '0';
                                iVar3 = iVar3 + 4;
                            }
                        }
                    }
                }
                break;
            case 0x7a:
                pcVar14 = (char *)(iVar3 + iVar1);
                iVar4 = (int32_t)uVar11 / 1000;
                if (iVar4 == 0) {
                    pcVar14[2] = '0';
                    pcVar14[1] = '0';
                    *pcVar14 = '0';
                    iVar3 = iVar3 + 3;
                } else {
                    iVar2 = iVar4 / 10;
                    pcVar14[2] = (char)iVar4 + (char)iVar2 * -10 + '0';
                    if (iVar2 == 0) {
                        pcVar14[1] = '0';
                        *pcVar14 = '0';
                        iVar3 = iVar3 + 3;
                    } else {
                        iVar4 = iVar2 / 10;
                        pcVar14[1] = (char)iVar2 + (char)iVar4 * -10 + '0';
                        if (iVar4 == 0) {
                            *pcVar14 = '0';
                            iVar3 = iVar3 + 3;
                        } else {
                            *pcVar14 = (char)iVar4 + (char)(iVar4 / 10) * -10 + '0';
                            iVar3 = iVar3 + 3;
                        }
                    }
                }
            }
            if (iVar9 <= iVar3) break;
            cVar6 = *(char *)(iVar10 + 1);
            iVar10 = iVar10 + 1;
        } while (cVar6 != '\0');
    }
    if (*(int32_t *)(arg1 + 0x1c) == 0) {
code_r0x000180173431:
        if (iVar9 <= iVar3) goto code_r0x000180173442;
        iVar9 = iVar3 + 1;
        *(undefined *)(iVar3 + iVar1) = 10;
    } else {
        if (iVar3 < iVar9) {
            iVar4 = func_0x000180065f60(iVar3 + iVar1, (int64_t)(iVar9 - iVar3), 0x18063cc8c, 0x1804a5a60);
            iVar3 = iVar3 + iVar4;
            goto code_r0x000180173431;
        }
code_r0x000180173442:
        *(undefined *)((int64_t)iVar9 + -1 + iVar1) = 10;
    }
    if (*(code **)arg1 == (code *)0x0) {
        iVar10 = fcn.1801725f0(arg1);
        if ((iVar10 != 0) && (func_0x000180460a38(iVar1, 1, (int64_t)iVar9, iVar10), *(int32_t *)(arg1 + 0x170) != 0)) {
            func_0x00018045fdf8(iVar10);
        }
    } else {
        (**(code **)arg1)((int32_t)var_7ch, iVar1, iVar9);
    }
    (*(code *)0x699f34)(stack0xffffffffffffff88);
code_r0x0001801734bf:
    func_0x000180459870(var_58h ^ (uint64_t)auStack_f8);
    return;
}

// ============================================================
// Function: FUN_180172b3e
// Address: 0x180172b3e
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

void fcn.180172b00(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    uint64_t *puVar5;
    char cVar6;
    undefined *puVar7;
    undefined8 uVar8;
    int32_t iVar9;
    int64_t iVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    uint32_t uVar13;
    char *pcVar14;
    undefined *puVar15;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_f8 [32];
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    uint32_t var_98h;
    uint32_t var_94h;
    uint32_t var_90h;
    uint32_t var_8ch;
    uint32_t var_88h;
    int64_t var_84h;
    int64_t var_7ch;
    int64_t var_70h;
    int64_t var_68h;
    uint16_t var_60h;
    uint16_t var_5eh;
    uint16_t var_5ch;
    uint16_t var_5ah;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_f8;
    iVar9 = (int32_t)arg2;
    var_20h = arg4;
    var_7ch._0_4_ = iVar9;
    if (iVar9 < *(int32_t *)(arg1 + 0x18)) goto code_r0x0001801734bf;
    (*(code *)0x699f64)(&var_68h);
    var_84h._0_4_ = (uint32_t)(uint16_t)var_68h;
    var_88h = (uint32_t)var_68h._2_2_;
    var_8ch = (uint32_t)var_68h._6_2_;
    var_90h = (uint32_t)var_60h;
    var_94h = (uint32_t)var_5eh;
    var_98h = (uint32_t)var_5ch;
    uVar11 = (uint32_t)var_5ah * 1000;
    if (iVar9 == 1) {
        puVar15 = (undefined *)0x1804a59ac;
        uVar8 = 0x1804a59f4;
    } else if (iVar9 == 2) {
        puVar15 = (undefined *)0x1804a59fc;
        uVar8 = 0x1804a5a04;
    } else if (iVar9 == 3) {
        puVar15 = (undefined *)0x1804a5a0c;
        uVar8 = 0x1804a5a14;
    } else if (iVar9 == 4) {
        puVar15 = (undefined *)0x1804a59b4;
        uVar8 = 0x1804a5a1c;
    } else if (iVar9 == 5) {
        puVar15 = (undefined *)0x1804a59bc;
        uVar8 = 0x1804a5a28;
    } else {
        puVar15 = (undefined *)0x1805aadb1;
        uVar8 = 0x1805aadb1;
    }
    unique0x00003200 = arg1 + 0x290;
    var_84h._4_4_ = uVar11;
    (*(code *)0x699f1c)(unique0x00003200);
    iVar1 = *(int64_t *)(arg1 + 0x10);
    iVar3 = 0;
    iVar9 = *(int32_t *)(arg1 + 8);
    if (*(int32_t *)(arg1 + 0x1c) != 0) {
        iVar3 = func_0x000180065f60(iVar1, (int64_t)iVar9, 0x18063cc8c, uVar8);
    }
    cVar6 = *(char *)(arg1 + 0x20);
    iVar10 = arg1 + 0x20;
    if (cVar6 == '\0') {
        var_b0h._0_4_ = uVar11 / 1000;
        var_b8h._0_4_ = var_98h;
        var_c0h._0_4_ = var_94h;
        var_c8h._0_4_ = var_90h;
        var_d0h = CONCAT44(var_d0h._4_4_, var_8ch);
        var_d8h = CONCAT44(var_d8h._4_4_, var_88h);
        var_a8h = (int64_t)puVar15;
        iVar4 = func_0x000180065f60(iVar3 + iVar1, (int64_t)(iVar9 - iVar3), 0x1804a5a38, (uint32_t)var_84h);
        iVar4 = iVar4 + iVar3;
        puVar5 = (uint64_t *)func_0x0001800102c0();
        var_d8h = 0;
        var_d0h = (int64_t)&var_20h;
        iVar3 = func_0x000180467554(*puVar5 | 2, iVar4 + iVar1, (int64_t)(iVar9 - iVar4), arg3);
        if (iVar3 < 0) {
            iVar3 = -1;
        }
        iVar3 = iVar3 + iVar4;
    } else {
        do {
            if (cVar6 != '%') {
                *(char *)(iVar3 + iVar1) = cVar6;
                goto code_r0x00018017330f;
            }
            puVar7 = (undefined *)(iVar10 + 1);
            iVar10 = iVar10 + 1;
    // switch table (13 cases) at 0x1801734dc
            switch(*puVar7) {
            case 0x25:
                *(undefined *)(iVar3 + iVar1) = 0x25;
                goto code_r0x00018017330f;
            case 0x48:
                uVar12 = var_90h;
                if (var_90h == 0) {
                    *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
                } else {
code_r0x000180172e4b:
                    uVar13 = uVar12 / 10;
                    *(char *)((int64_t)iVar3 + 1 + iVar1) = (char)uVar12 + (char)uVar13 * -10 + '0';
                    if (uVar13 != 0) {
                        *(char *)(iVar3 + iVar1) = (char)uVar13 + (char)(uVar13 / 10) * -10 + '0';
                        iVar3 = iVar3 + 2;
                        break;
                    }
                }
                goto code_r0x000180172e79;
            case 0x4c:
                puVar7 = (undefined *)(iVar3 + iVar1);
                iVar3 = iVar3 + 5;
                *puVar7 = *puVar15;
                puVar7[1] = puVar15[1];
                puVar7[2] = puVar15[2];
                puVar7[3] = puVar15[3];
                puVar7[4] = puVar15[4];
                break;
            case 0x4d:
                uVar12 = var_94h;
                if (var_94h != 0) goto code_r0x000180172e4b;
                *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
                goto code_r0x000180172e79;
            case 0x53:
                uVar12 = var_98h;
                if (var_98h != 0) goto code_r0x000180172e4b;
                *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
                goto code_r0x000180172e79;
            case 0x5a:
                pcVar14 = (char *)(iVar3 + iVar1);
                if (uVar11 == 0) {
                    pcVar14[5] = '0';
                    pcVar14[4] = '0';
                    pcVar14[3] = '0';
                    iVar3 = iVar3 + 6;
                    pcVar14[2] = '0';
                    pcVar14[1] = '0';
                    *pcVar14 = '0';
                } else {
                    iVar4 = (int32_t)uVar11 / 10;
                    pcVar14[5] = (char)uVar11 + (char)iVar4 * -10 + '0';
                    if (iVar4 == 0) {
                        pcVar14[4] = '0';
                        pcVar14[3] = '0';
                        pcVar14[2] = '0';
                        iVar3 = iVar3 + 6;
                        pcVar14[1] = '0';
                        *pcVar14 = '0';
                    } else {
                        iVar2 = iVar4 / 10;
                        pcVar14[4] = (char)iVar4 + (char)iVar2 * -10 + '0';
                        if (iVar2 == 0) {
                            pcVar14[3] = '0';
                            pcVar14[2] = '0';
                            pcVar14[1] = '0';
                            iVar3 = iVar3 + 6;
                            *pcVar14 = '0';
                        } else {
                            iVar4 = iVar2 / 10;
                            pcVar14[3] = (char)iVar2 + (char)iVar4 * -10 + '0';
                            if (iVar4 == 0) {
                                pcVar14[2] = '0';
                                pcVar14[1] = '0';
                                *pcVar14 = '0';
                                iVar3 = iVar3 + 6;
                            } else {
                                iVar2 = iVar4 / 10;
                                pcVar14[2] = (char)iVar4 + (char)iVar2 * -10 + '0';
                                if (iVar2 == 0) {
                                    pcVar14[1] = '0';
                                    *pcVar14 = '0';
                                    iVar3 = iVar3 + 6;
                                } else {
                                    iVar4 = iVar2 / 10;
                                    pcVar14[1] = (char)iVar2 + (char)iVar4 * -10 + '0';
                                    if (iVar4 == 0) {
                                        *pcVar14 = '0';
                                        iVar3 = iVar3 + 6;
                                    } else {
                                        *pcVar14 = (char)iVar4 + (char)(iVar4 / 10) * -10 + '0';
                                        iVar3 = iVar3 + 6;
                                    }
                                }
                            }
                        }
                    }
                }
                break;
            case 100:
                uVar12 = var_8ch;
                if (var_8ch != 0) goto code_r0x000180172e4b;
                *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
code_r0x000180172e79:
                *(undefined *)(iVar3 + iVar1) = 0x30;
                iVar3 = iVar3 + 2;
                break;
            case 0x6c:
                *(undefined *)(iVar3 + iVar1) = *puVar15;
code_r0x00018017330f:
                iVar3 = iVar3 + 1;
                break;
            case 0x6d:
                uVar12 = var_88h;
                if (var_88h != 0) goto code_r0x000180172e4b;
                *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
                *(undefined *)(iVar3 + iVar1) = 0x30;
                iVar3 = iVar3 + 2;
                break;
            case 0x73:
                puVar5 = (uint64_t *)func_0x0001800102c0();
                var_d0h = (int64_t)&var_20h;
                var_d8h = 0;
                iVar4 = func_0x000180467554(*puVar5 | 2, iVar3 + iVar1, (int64_t)(iVar9 - iVar3), arg3);
                var_70h = 0;
                if (iVar4 < 0) {
                    iVar4 = -1;
                }
                iVar3 = iVar3 + iVar4;
                uVar11 = var_84h._4_4_;
                break;
            case 0x79:
                pcVar14 = (char *)(iVar3 + iVar1);
                if ((uint32_t)var_84h == 0) {
                    pcVar14[3] = '0';
                    pcVar14[2] = '0';
                    pcVar14[1] = '0';
                    iVar3 = iVar3 + 4;
                    *pcVar14 = '0';
                } else {
                    uVar12 = (uint32_t)var_84h / 10;
                    pcVar14[3] = (char)(uint32_t)var_84h + (char)uVar12 * -10 + '0';
                    if (uVar12 == 0) {
                        pcVar14[2] = '0';
                        pcVar14[1] = '0';
                        *pcVar14 = '0';
                        iVar3 = iVar3 + 4;
                    } else {
                        uVar13 = uVar12 / 10;
                        pcVar14[2] = (char)uVar12 + (char)uVar13 * -10 + '0';
                        if (uVar13 == 0) {
                            pcVar14[1] = '0';
                            *pcVar14 = '0';
                            iVar3 = iVar3 + 4;
                        } else {
                            uVar12 = uVar13 / 10;
                            pcVar14[1] = (char)uVar13 + (char)uVar12 * -10 + '0';
                            if (uVar12 == 0) {
                                *pcVar14 = '0';
                                iVar3 = iVar3 + 4;
                            } else {
                                *pcVar14 = (char)uVar12 + (char)(uVar12 / 10) * -10 + '0';
                                iVar3 = iVar3 + 4;
                            }
                        }
                    }
                }
                break;
            case 0x7a:
                pcVar14 = (char *)(iVar3 + iVar1);
                iVar4 = (int32_t)uVar11 / 1000;
                if (iVar4 == 0) {
                    pcVar14[2] = '0';
                    pcVar14[1] = '0';
                    *pcVar14 = '0';
                    iVar3 = iVar3 + 3;
                } else {
                    iVar2 = iVar4 / 10;
                    pcVar14[2] = (char)iVar4 + (char)iVar2 * -10 + '0';
                    if (iVar2 == 0) {
                        pcVar14[1] = '0';
                        *pcVar14 = '0';
                        iVar3 = iVar3 + 3;
                    } else {
                        iVar4 = iVar2 / 10;
                        pcVar14[1] = (char)iVar2 + (char)iVar4 * -10 + '0';
                        if (iVar4 == 0) {
                            *pcVar14 = '0';
                            iVar3 = iVar3 + 3;
                        } else {
                            *pcVar14 = (char)iVar4 + (char)(iVar4 / 10) * -10 + '0';
                            iVar3 = iVar3 + 3;
                        }
                    }
                }
            }
            if (iVar9 <= iVar3) break;
            cVar6 = *(char *)(iVar10 + 1);
            iVar10 = iVar10 + 1;
        } while (cVar6 != '\0');
    }
    if (*(int32_t *)(arg1 + 0x1c) == 0) {
code_r0x000180173431:
        if (iVar9 <= iVar3) goto code_r0x000180173442;
        iVar9 = iVar3 + 1;
        *(undefined *)(iVar3 + iVar1) = 10;
    } else {
        if (iVar3 < iVar9) {
            iVar4 = func_0x000180065f60(iVar3 + iVar1, (int64_t)(iVar9 - iVar3), 0x18063cc8c, 0x1804a5a60);
            iVar3 = iVar3 + iVar4;
            goto code_r0x000180173431;
        }
code_r0x000180173442:
        *(undefined *)((int64_t)iVar9 + -1 + iVar1) = 10;
    }
    if (*(code **)arg1 == (code *)0x0) {
        iVar10 = fcn.1801725f0(arg1);
        if ((iVar10 != 0) && (func_0x000180460a38(iVar1, 1, (int64_t)iVar9, iVar10), *(int32_t *)(arg1 + 0x170) != 0)) {
            func_0x00018045fdf8(iVar10);
        }
    } else {
        (**(code **)arg1)((int32_t)var_7ch, iVar1, iVar9);
    }
    (*(code *)0x699f34)(stack0xffffffffffffff88);
code_r0x0001801734bf:
    func_0x000180459870(var_58h ^ (uint64_t)auStack_f8);
    return;
}

// ============================================================
// Function: FUN_180172b4e
// Address: 0x180172b4e
// Size: 2235 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

void fcn.180172b00(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    uint64_t *puVar5;
    char cVar6;
    undefined *puVar7;
    undefined8 uVar8;
    int32_t iVar9;
    int64_t iVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    uint32_t uVar13;
    char *pcVar14;
    undefined *puVar15;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_f8 [32];
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    uint32_t var_98h;
    uint32_t var_94h;
    uint32_t var_90h;
    uint32_t var_8ch;
    uint32_t var_88h;
    int64_t var_84h;
    int64_t var_7ch;
    int64_t var_70h;
    int64_t var_68h;
    uint16_t var_60h;
    uint16_t var_5eh;
    uint16_t var_5ch;
    uint16_t var_5ah;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_f8;
    iVar9 = (int32_t)arg2;
    var_20h = arg4;
    var_7ch._0_4_ = iVar9;
    if (iVar9 < *(int32_t *)(arg1 + 0x18)) goto code_r0x0001801734bf;
    (*(code *)0x699f64)(&var_68h);
    var_84h._0_4_ = (uint32_t)(uint16_t)var_68h;
    var_88h = (uint32_t)var_68h._2_2_;
    var_8ch = (uint32_t)var_68h._6_2_;
    var_90h = (uint32_t)var_60h;
    var_94h = (uint32_t)var_5eh;
    var_98h = (uint32_t)var_5ch;
    uVar11 = (uint32_t)var_5ah * 1000;
    if (iVar9 == 1) {
        puVar15 = (undefined *)0x1804a59ac;
        uVar8 = 0x1804a59f4;
    } else if (iVar9 == 2) {
        puVar15 = (undefined *)0x1804a59fc;
        uVar8 = 0x1804a5a04;
    } else if (iVar9 == 3) {
        puVar15 = (undefined *)0x1804a5a0c;
        uVar8 = 0x1804a5a14;
    } else if (iVar9 == 4) {
        puVar15 = (undefined *)0x1804a59b4;
        uVar8 = 0x1804a5a1c;
    } else if (iVar9 == 5) {
        puVar15 = (undefined *)0x1804a59bc;
        uVar8 = 0x1804a5a28;
    } else {
        puVar15 = (undefined *)0x1805aadb1;
        uVar8 = 0x1805aadb1;
    }
    unique0x00003200 = arg1 + 0x290;
    var_84h._4_4_ = uVar11;
    (*(code *)0x699f1c)(unique0x00003200);
    iVar1 = *(int64_t *)(arg1 + 0x10);
    iVar3 = 0;
    iVar9 = *(int32_t *)(arg1 + 8);
    if (*(int32_t *)(arg1 + 0x1c) != 0) {
        iVar3 = func_0x000180065f60(iVar1, (int64_t)iVar9, 0x18063cc8c, uVar8);
    }
    cVar6 = *(char *)(arg1 + 0x20);
    iVar10 = arg1 + 0x20;
    if (cVar6 == '\0') {
        var_b0h._0_4_ = uVar11 / 1000;
        var_b8h._0_4_ = var_98h;
        var_c0h._0_4_ = var_94h;
        var_c8h._0_4_ = var_90h;
        var_d0h = CONCAT44(var_d0h._4_4_, var_8ch);
        var_d8h = CONCAT44(var_d8h._4_4_, var_88h);
        var_a8h = (int64_t)puVar15;
        iVar4 = func_0x000180065f60(iVar3 + iVar1, (int64_t)(iVar9 - iVar3), 0x1804a5a38, (uint32_t)var_84h);
        iVar4 = iVar4 + iVar3;
        puVar5 = (uint64_t *)func_0x0001800102c0();
        var_d8h = 0;
        var_d0h = (int64_t)&var_20h;
        iVar3 = func_0x000180467554(*puVar5 | 2, iVar4 + iVar1, (int64_t)(iVar9 - iVar4), arg3);
        if (iVar3 < 0) {
            iVar3 = -1;
        }
        iVar3 = iVar3 + iVar4;
    } else {
        do {
            if (cVar6 != '%') {
                *(char *)(iVar3 + iVar1) = cVar6;
                goto code_r0x00018017330f;
            }
            puVar7 = (undefined *)(iVar10 + 1);
            iVar10 = iVar10 + 1;
    // switch table (13 cases) at 0x1801734dc
            switch(*puVar7) {
            case 0x25:
                *(undefined *)(iVar3 + iVar1) = 0x25;
                goto code_r0x00018017330f;
            case 0x48:
                uVar12 = var_90h;
                if (var_90h == 0) {
                    *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
                } else {
code_r0x000180172e4b:
                    uVar13 = uVar12 / 10;
                    *(char *)((int64_t)iVar3 + 1 + iVar1) = (char)uVar12 + (char)uVar13 * -10 + '0';
                    if (uVar13 != 0) {
                        *(char *)(iVar3 + iVar1) = (char)uVar13 + (char)(uVar13 / 10) * -10 + '0';
                        iVar3 = iVar3 + 2;
                        break;
                    }
                }
                goto code_r0x000180172e79;
            case 0x4c:
                puVar7 = (undefined *)(iVar3 + iVar1);
                iVar3 = iVar3 + 5;
                *puVar7 = *puVar15;
                puVar7[1] = puVar15[1];
                puVar7[2] = puVar15[2];
                puVar7[3] = puVar15[3];
                puVar7[4] = puVar15[4];
                break;
            case 0x4d:
                uVar12 = var_94h;
                if (var_94h != 0) goto code_r0x000180172e4b;
                *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
                goto code_r0x000180172e79;
            case 0x53:
                uVar12 = var_98h;
                if (var_98h != 0) goto code_r0x000180172e4b;
                *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
                goto code_r0x000180172e79;
            case 0x5a:
                pcVar14 = (char *)(iVar3 + iVar1);
                if (uVar11 == 0) {
                    pcVar14[5] = '0';
                    pcVar14[4] = '0';
                    pcVar14[3] = '0';
                    iVar3 = iVar3 + 6;
                    pcVar14[2] = '0';
                    pcVar14[1] = '0';
                    *pcVar14 = '0';
                } else {
                    iVar4 = (int32_t)uVar11 / 10;
                    pcVar14[5] = (char)uVar11 + (char)iVar4 * -10 + '0';
                    if (iVar4 == 0) {
                        pcVar14[4] = '0';
                        pcVar14[3] = '0';
                        pcVar14[2] = '0';
                        iVar3 = iVar3 + 6;
                        pcVar14[1] = '0';
                        *pcVar14 = '0';
                    } else {
                        iVar2 = iVar4 / 10;
                        pcVar14[4] = (char)iVar4 + (char)iVar2 * -10 + '0';
                        if (iVar2 == 0) {
                            pcVar14[3] = '0';
                            pcVar14[2] = '0';
                            pcVar14[1] = '0';
                            iVar3 = iVar3 + 6;
                            *pcVar14 = '0';
                        } else {
                            iVar4 = iVar2 / 10;
                            pcVar14[3] = (char)iVar2 + (char)iVar4 * -10 + '0';
                            if (iVar4 == 0) {
                                pcVar14[2] = '0';
                                pcVar14[1] = '0';
                                *pcVar14 = '0';
                                iVar3 = iVar3 + 6;
                            } else {
                                iVar2 = iVar4 / 10;
                                pcVar14[2] = (char)iVar4 + (char)iVar2 * -10 + '0';
                                if (iVar2 == 0) {
                                    pcVar14[1] = '0';
                                    *pcVar14 = '0';
                                    iVar3 = iVar3 + 6;
                                } else {
                                    iVar4 = iVar2 / 10;
                                    pcVar14[1] = (char)iVar2 + (char)iVar4 * -10 + '0';
                                    if (iVar4 == 0) {
                                        *pcVar14 = '0';
                                        iVar3 = iVar3 + 6;
                                    } else {
                                        *pcVar14 = (char)iVar4 + (char)(iVar4 / 10) * -10 + '0';
                                        iVar3 = iVar3 + 6;
                                    }
                                }
                            }
                        }
                    }
                }
                break;
            case 100:
                uVar12 = var_8ch;
                if (var_8ch != 0) goto code_r0x000180172e4b;
                *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
code_r0x000180172e79:
                *(undefined *)(iVar3 + iVar1) = 0x30;
                iVar3 = iVar3 + 2;
                break;
            case 0x6c:
                *(undefined *)(iVar3 + iVar1) = *puVar15;
code_r0x00018017330f:
                iVar3 = iVar3 + 1;
                break;
            case 0x6d:
                uVar12 = var_88h;
                if (var_88h != 0) goto code_r0x000180172e4b;
                *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
                *(undefined *)(iVar3 + iVar1) = 0x30;
                iVar3 = iVar3 + 2;
                break;
            case 0x73:
                puVar5 = (uint64_t *)func_0x0001800102c0();
                var_d0h = (int64_t)&var_20h;
                var_d8h = 0;
                iVar4 = func_0x000180467554(*puVar5 | 2, iVar3 + iVar1, (int64_t)(iVar9 - iVar3), arg3);
                var_70h = 0;
                if (iVar4 < 0) {
                    iVar4 = -1;
                }
                iVar3 = iVar3 + iVar4;
                uVar11 = var_84h._4_4_;
                break;
            case 0x79:
                pcVar14 = (char *)(iVar3 + iVar1);
                if ((uint32_t)var_84h == 0) {
                    pcVar14[3] = '0';
                    pcVar14[2] = '0';
                    pcVar14[1] = '0';
                    iVar3 = iVar3 + 4;
                    *pcVar14 = '0';
                } else {
                    uVar12 = (uint32_t)var_84h / 10;
                    pcVar14[3] = (char)(uint32_t)var_84h + (char)uVar12 * -10 + '0';
                    if (uVar12 == 0) {
                        pcVar14[2] = '0';
                        pcVar14[1] = '0';
                        *pcVar14 = '0';
                        iVar3 = iVar3 + 4;
                    } else {
                        uVar13 = uVar12 / 10;
                        pcVar14[2] = (char)uVar12 + (char)uVar13 * -10 + '0';
                        if (uVar13 == 0) {
                            pcVar14[1] = '0';
                            *pcVar14 = '0';
                            iVar3 = iVar3 + 4;
                        } else {
                            uVar12 = uVar13 / 10;
                            pcVar14[1] = (char)uVar13 + (char)uVar12 * -10 + '0';
                            if (uVar12 == 0) {
                                *pcVar14 = '0';
                                iVar3 = iVar3 + 4;
                            } else {
                                *pcVar14 = (char)uVar12 + (char)(uVar12 / 10) * -10 + '0';
                                iVar3 = iVar3 + 4;
                            }
                        }
                    }
                }
                break;
            case 0x7a:
                pcVar14 = (char *)(iVar3 + iVar1);
                iVar4 = (int32_t)uVar11 / 1000;
                if (iVar4 == 0) {
                    pcVar14[2] = '0';
                    pcVar14[1] = '0';
                    *pcVar14 = '0';
                    iVar3 = iVar3 + 3;
                } else {
                    iVar2 = iVar4 / 10;
                    pcVar14[2] = (char)iVar4 + (char)iVar2 * -10 + '0';
                    if (iVar2 == 0) {
                        pcVar14[1] = '0';
                        *pcVar14 = '0';
                        iVar3 = iVar3 + 3;
                    } else {
                        iVar4 = iVar2 / 10;
                        pcVar14[1] = (char)iVar2 + (char)iVar4 * -10 + '0';
                        if (iVar4 == 0) {
                            *pcVar14 = '0';
                            iVar3 = iVar3 + 3;
                        } else {
                            *pcVar14 = (char)iVar4 + (char)(iVar4 / 10) * -10 + '0';
                            iVar3 = iVar3 + 3;
                        }
                    }
                }
            }
            if (iVar9 <= iVar3) break;
            cVar6 = *(char *)(iVar10 + 1);
            iVar10 = iVar10 + 1;
        } while (cVar6 != '\0');
    }
    if (*(int32_t *)(arg1 + 0x1c) == 0) {
code_r0x000180173431:
        if (iVar9 <= iVar3) goto code_r0x000180173442;
        iVar9 = iVar3 + 1;
        *(undefined *)(iVar3 + iVar1) = 10;
    } else {
        if (iVar3 < iVar9) {
            iVar4 = func_0x000180065f60(iVar3 + iVar1, (int64_t)(iVar9 - iVar3), 0x18063cc8c, 0x1804a5a60);
            iVar3 = iVar3 + iVar4;
            goto code_r0x000180173431;
        }
code_r0x000180173442:
        *(undefined *)((int64_t)iVar9 + -1 + iVar1) = 10;
    }
    if (*(code **)arg1 == (code *)0x0) {
        iVar10 = fcn.1801725f0(arg1);
        if ((iVar10 != 0) && (func_0x000180460a38(iVar1, 1, (int64_t)iVar9, iVar10), *(int32_t *)(arg1 + 0x170) != 0)) {
            func_0x00018045fdf8(iVar10);
        }
    } else {
        (**(code **)arg1)((int32_t)var_7ch, iVar1, iVar9);
    }
    (*(code *)0x699f34)(stack0xffffffffffffff88);
code_r0x0001801734bf:
    func_0x000180459870(var_58h ^ (uint64_t)auStack_f8);
    return;
}

// ============================================================
// Function: FUN_180173409
// Address: 0x180173409
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

void fcn.180172b00(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    uint64_t *puVar5;
    char cVar6;
    undefined *puVar7;
    undefined8 uVar8;
    int32_t iVar9;
    int64_t iVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    uint32_t uVar13;
    char *pcVar14;
    undefined *puVar15;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_f8 [32];
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    uint32_t var_98h;
    uint32_t var_94h;
    uint32_t var_90h;
    uint32_t var_8ch;
    uint32_t var_88h;
    int64_t var_84h;
    int64_t var_7ch;
    int64_t var_70h;
    int64_t var_68h;
    uint16_t var_60h;
    uint16_t var_5eh;
    uint16_t var_5ch;
    uint16_t var_5ah;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_f8;
    iVar9 = (int32_t)arg2;
    var_20h = arg4;
    var_7ch._0_4_ = iVar9;
    if (iVar9 < *(int32_t *)(arg1 + 0x18)) goto code_r0x0001801734bf;
    (*(code *)0x699f64)(&var_68h);
    var_84h._0_4_ = (uint32_t)(uint16_t)var_68h;
    var_88h = (uint32_t)var_68h._2_2_;
    var_8ch = (uint32_t)var_68h._6_2_;
    var_90h = (uint32_t)var_60h;
    var_94h = (uint32_t)var_5eh;
    var_98h = (uint32_t)var_5ch;
    uVar11 = (uint32_t)var_5ah * 1000;
    if (iVar9 == 1) {
        puVar15 = (undefined *)0x1804a59ac;
        uVar8 = 0x1804a59f4;
    } else if (iVar9 == 2) {
        puVar15 = (undefined *)0x1804a59fc;
        uVar8 = 0x1804a5a04;
    } else if (iVar9 == 3) {
        puVar15 = (undefined *)0x1804a5a0c;
        uVar8 = 0x1804a5a14;
    } else if (iVar9 == 4) {
        puVar15 = (undefined *)0x1804a59b4;
        uVar8 = 0x1804a5a1c;
    } else if (iVar9 == 5) {
        puVar15 = (undefined *)0x1804a59bc;
        uVar8 = 0x1804a5a28;
    } else {
        puVar15 = (undefined *)0x1805aadb1;
        uVar8 = 0x1805aadb1;
    }
    unique0x00003200 = arg1 + 0x290;
    var_84h._4_4_ = uVar11;
    (*(code *)0x699f1c)(unique0x00003200);
    iVar1 = *(int64_t *)(arg1 + 0x10);
    iVar3 = 0;
    iVar9 = *(int32_t *)(arg1 + 8);
    if (*(int32_t *)(arg1 + 0x1c) != 0) {
        iVar3 = func_0x000180065f60(iVar1, (int64_t)iVar9, 0x18063cc8c, uVar8);
    }
    cVar6 = *(char *)(arg1 + 0x20);
    iVar10 = arg1 + 0x20;
    if (cVar6 == '\0') {
        var_b0h._0_4_ = uVar11 / 1000;
        var_b8h._0_4_ = var_98h;
        var_c0h._0_4_ = var_94h;
        var_c8h._0_4_ = var_90h;
        var_d0h = CONCAT44(var_d0h._4_4_, var_8ch);
        var_d8h = CONCAT44(var_d8h._4_4_, var_88h);
        var_a8h = (int64_t)puVar15;
        iVar4 = func_0x000180065f60(iVar3 + iVar1, (int64_t)(iVar9 - iVar3), 0x1804a5a38, (uint32_t)var_84h);
        iVar4 = iVar4 + iVar3;
        puVar5 = (uint64_t *)func_0x0001800102c0();
        var_d8h = 0;
        var_d0h = (int64_t)&var_20h;
        iVar3 = func_0x000180467554(*puVar5 | 2, iVar4 + iVar1, (int64_t)(iVar9 - iVar4), arg3);
        if (iVar3 < 0) {
            iVar3 = -1;
        }
        iVar3 = iVar3 + iVar4;
    } else {
        do {
            if (cVar6 != '%') {
                *(char *)(iVar3 + iVar1) = cVar6;
                goto code_r0x00018017330f;
            }
            puVar7 = (undefined *)(iVar10 + 1);
            iVar10 = iVar10 + 1;
    // switch table (13 cases) at 0x1801734dc
            switch(*puVar7) {
            case 0x25:
                *(undefined *)(iVar3 + iVar1) = 0x25;
                goto code_r0x00018017330f;
            case 0x48:
                uVar12 = var_90h;
                if (var_90h == 0) {
                    *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
                } else {
code_r0x000180172e4b:
                    uVar13 = uVar12 / 10;
                    *(char *)((int64_t)iVar3 + 1 + iVar1) = (char)uVar12 + (char)uVar13 * -10 + '0';
                    if (uVar13 != 0) {
                        *(char *)(iVar3 + iVar1) = (char)uVar13 + (char)(uVar13 / 10) * -10 + '0';
                        iVar3 = iVar3 + 2;
                        break;
                    }
                }
                goto code_r0x000180172e79;
            case 0x4c:
                puVar7 = (undefined *)(iVar3 + iVar1);
                iVar3 = iVar3 + 5;
                *puVar7 = *puVar15;
                puVar7[1] = puVar15[1];
                puVar7[2] = puVar15[2];
                puVar7[3] = puVar15[3];
                puVar7[4] = puVar15[4];
                break;
            case 0x4d:
                uVar12 = var_94h;
                if (var_94h != 0) goto code_r0x000180172e4b;
                *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
                goto code_r0x000180172e79;
            case 0x53:
                uVar12 = var_98h;
                if (var_98h != 0) goto code_r0x000180172e4b;
                *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
                goto code_r0x000180172e79;
            case 0x5a:
                pcVar14 = (char *)(iVar3 + iVar1);
                if (uVar11 == 0) {
                    pcVar14[5] = '0';
                    pcVar14[4] = '0';
                    pcVar14[3] = '0';
                    iVar3 = iVar3 + 6;
                    pcVar14[2] = '0';
                    pcVar14[1] = '0';
                    *pcVar14 = '0';
                } else {
                    iVar4 = (int32_t)uVar11 / 10;
                    pcVar14[5] = (char)uVar11 + (char)iVar4 * -10 + '0';
                    if (iVar4 == 0) {
                        pcVar14[4] = '0';
                        pcVar14[3] = '0';
                        pcVar14[2] = '0';
                        iVar3 = iVar3 + 6;
                        pcVar14[1] = '0';
                        *pcVar14 = '0';
                    } else {
                        iVar2 = iVar4 / 10;
                        pcVar14[4] = (char)iVar4 + (char)iVar2 * -10 + '0';
                        if (iVar2 == 0) {
                            pcVar14[3] = '0';
                            pcVar14[2] = '0';
                            pcVar14[1] = '0';
                            iVar3 = iVar3 + 6;
                            *pcVar14 = '0';
                        } else {
                            iVar4 = iVar2 / 10;
                            pcVar14[3] = (char)iVar2 + (char)iVar4 * -10 + '0';
                            if (iVar4 == 0) {
                                pcVar14[2] = '0';
                                pcVar14[1] = '0';
                                *pcVar14 = '0';
                                iVar3 = iVar3 + 6;
                            } else {
                                iVar2 = iVar4 / 10;
                                pcVar14[2] = (char)iVar4 + (char)iVar2 * -10 + '0';
                                if (iVar2 == 0) {
                                    pcVar14[1] = '0';
                                    *pcVar14 = '0';
                                    iVar3 = iVar3 + 6;
                                } else {
                                    iVar4 = iVar2 / 10;
                                    pcVar14[1] = (char)iVar2 + (char)iVar4 * -10 + '0';
                                    if (iVar4 == 0) {
                                        *pcVar14 = '0';
                                        iVar3 = iVar3 + 6;
                                    } else {
                                        *pcVar14 = (char)iVar4 + (char)(iVar4 / 10) * -10 + '0';
                                        iVar3 = iVar3 + 6;
                                    }
                                }
                            }
                        }
                    }
                }
                break;
            case 100:
                uVar12 = var_8ch;
                if (var_8ch != 0) goto code_r0x000180172e4b;
                *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
code_r0x000180172e79:
                *(undefined *)(iVar3 + iVar1) = 0x30;
                iVar3 = iVar3 + 2;
                break;
            case 0x6c:
                *(undefined *)(iVar3 + iVar1) = *puVar15;
code_r0x00018017330f:
                iVar3 = iVar3 + 1;
                break;
            case 0x6d:
                uVar12 = var_88h;
                if (var_88h != 0) goto code_r0x000180172e4b;
                *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
                *(undefined *)(iVar3 + iVar1) = 0x30;
                iVar3 = iVar3 + 2;
                break;
            case 0x73:
                puVar5 = (uint64_t *)func_0x0001800102c0();
                var_d0h = (int64_t)&var_20h;
                var_d8h = 0;
                iVar4 = func_0x000180467554(*puVar5 | 2, iVar3 + iVar1, (int64_t)(iVar9 - iVar3), arg3);
                var_70h = 0;
                if (iVar4 < 0) {
                    iVar4 = -1;
                }
                iVar3 = iVar3 + iVar4;
                uVar11 = var_84h._4_4_;
                break;
            case 0x79:
                pcVar14 = (char *)(iVar3 + iVar1);
                if ((uint32_t)var_84h == 0) {
                    pcVar14[3] = '0';
                    pcVar14[2] = '0';
                    pcVar14[1] = '0';
                    iVar3 = iVar3 + 4;
                    *pcVar14 = '0';
                } else {
                    uVar12 = (uint32_t)var_84h / 10;
                    pcVar14[3] = (char)(uint32_t)var_84h + (char)uVar12 * -10 + '0';
                    if (uVar12 == 0) {
                        pcVar14[2] = '0';
                        pcVar14[1] = '0';
                        *pcVar14 = '0';
                        iVar3 = iVar3 + 4;
                    } else {
                        uVar13 = uVar12 / 10;
                        pcVar14[2] = (char)uVar12 + (char)uVar13 * -10 + '0';
                        if (uVar13 == 0) {
                            pcVar14[1] = '0';
                            *pcVar14 = '0';
                            iVar3 = iVar3 + 4;
                        } else {
                            uVar12 = uVar13 / 10;
                            pcVar14[1] = (char)uVar13 + (char)uVar12 * -10 + '0';
                            if (uVar12 == 0) {
                                *pcVar14 = '0';
                                iVar3 = iVar3 + 4;
                            } else {
                                *pcVar14 = (char)uVar12 + (char)(uVar12 / 10) * -10 + '0';
                                iVar3 = iVar3 + 4;
                            }
                        }
                    }
                }
                break;
            case 0x7a:
                pcVar14 = (char *)(iVar3 + iVar1);
                iVar4 = (int32_t)uVar11 / 1000;
                if (iVar4 == 0) {
                    pcVar14[2] = '0';
                    pcVar14[1] = '0';
                    *pcVar14 = '0';
                    iVar3 = iVar3 + 3;
                } else {
                    iVar2 = iVar4 / 10;
                    pcVar14[2] = (char)iVar4 + (char)iVar2 * -10 + '0';
                    if (iVar2 == 0) {
                        pcVar14[1] = '0';
                        *pcVar14 = '0';
                        iVar3 = iVar3 + 3;
                    } else {
                        iVar4 = iVar2 / 10;
                        pcVar14[1] = (char)iVar2 + (char)iVar4 * -10 + '0';
                        if (iVar4 == 0) {
                            *pcVar14 = '0';
                            iVar3 = iVar3 + 3;
                        } else {
                            *pcVar14 = (char)iVar4 + (char)(iVar4 / 10) * -10 + '0';
                            iVar3 = iVar3 + 3;
                        }
                    }
                }
            }
            if (iVar9 <= iVar3) break;
            cVar6 = *(char *)(iVar10 + 1);
            iVar10 = iVar10 + 1;
        } while (cVar6 != '\0');
    }
    if (*(int32_t *)(arg1 + 0x1c) == 0) {
code_r0x000180173431:
        if (iVar9 <= iVar3) goto code_r0x000180173442;
        iVar9 = iVar3 + 1;
        *(undefined *)(iVar3 + iVar1) = 10;
    } else {
        if (iVar3 < iVar9) {
            iVar4 = func_0x000180065f60(iVar3 + iVar1, (int64_t)(iVar9 - iVar3), 0x18063cc8c, 0x1804a5a60);
            iVar3 = iVar3 + iVar4;
            goto code_r0x000180173431;
        }
code_r0x000180173442:
        *(undefined *)((int64_t)iVar9 + -1 + iVar1) = 10;
    }
    if (*(code **)arg1 == (code *)0x0) {
        iVar10 = fcn.1801725f0(arg1);
        if ((iVar10 != 0) && (func_0x000180460a38(iVar1, 1, (int64_t)iVar9, iVar10), *(int32_t *)(arg1 + 0x170) != 0)) {
            func_0x00018045fdf8(iVar10);
        }
    } else {
        (**(code **)arg1)((int32_t)var_7ch, iVar1, iVar9);
    }
    (*(code *)0x699f34)(stack0xffffffffffffff88);
code_r0x0001801734bf:
    func_0x000180459870(var_58h ^ (uint64_t)auStack_f8);
    return;
}

// ============================================================
// Function: FUN_18017345c
// Address: 0x18017345c
// Size: 99 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

void fcn.180172b00(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    uint64_t *puVar5;
    char cVar6;
    undefined *puVar7;
    undefined8 uVar8;
    int32_t iVar9;
    int64_t iVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    uint32_t uVar13;
    char *pcVar14;
    undefined *puVar15;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_f8 [32];
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    uint32_t var_98h;
    uint32_t var_94h;
    uint32_t var_90h;
    uint32_t var_8ch;
    uint32_t var_88h;
    int64_t var_84h;
    int64_t var_7ch;
    int64_t var_70h;
    int64_t var_68h;
    uint16_t var_60h;
    uint16_t var_5eh;
    uint16_t var_5ch;
    uint16_t var_5ah;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_f8;
    iVar9 = (int32_t)arg2;
    var_20h = arg4;
    var_7ch._0_4_ = iVar9;
    if (iVar9 < *(int32_t *)(arg1 + 0x18)) goto code_r0x0001801734bf;
    (*(code *)0x699f64)(&var_68h);
    var_84h._0_4_ = (uint32_t)(uint16_t)var_68h;
    var_88h = (uint32_t)var_68h._2_2_;
    var_8ch = (uint32_t)var_68h._6_2_;
    var_90h = (uint32_t)var_60h;
    var_94h = (uint32_t)var_5eh;
    var_98h = (uint32_t)var_5ch;
    uVar11 = (uint32_t)var_5ah * 1000;
    if (iVar9 == 1) {
        puVar15 = (undefined *)0x1804a59ac;
        uVar8 = 0x1804a59f4;
    } else if (iVar9 == 2) {
        puVar15 = (undefined *)0x1804a59fc;
        uVar8 = 0x1804a5a04;
    } else if (iVar9 == 3) {
        puVar15 = (undefined *)0x1804a5a0c;
        uVar8 = 0x1804a5a14;
    } else if (iVar9 == 4) {
        puVar15 = (undefined *)0x1804a59b4;
        uVar8 = 0x1804a5a1c;
    } else if (iVar9 == 5) {
        puVar15 = (undefined *)0x1804a59bc;
        uVar8 = 0x1804a5a28;
    } else {
        puVar15 = (undefined *)0x1805aadb1;
        uVar8 = 0x1805aadb1;
    }
    unique0x00003200 = arg1 + 0x290;
    var_84h._4_4_ = uVar11;
    (*(code *)0x699f1c)(unique0x00003200);
    iVar1 = *(int64_t *)(arg1 + 0x10);
    iVar3 = 0;
    iVar9 = *(int32_t *)(arg1 + 8);
    if (*(int32_t *)(arg1 + 0x1c) != 0) {
        iVar3 = func_0x000180065f60(iVar1, (int64_t)iVar9, 0x18063cc8c, uVar8);
    }
    cVar6 = *(char *)(arg1 + 0x20);
    iVar10 = arg1 + 0x20;
    if (cVar6 == '\0') {
        var_b0h._0_4_ = uVar11 / 1000;
        var_b8h._0_4_ = var_98h;
        var_c0h._0_4_ = var_94h;
        var_c8h._0_4_ = var_90h;
        var_d0h = CONCAT44(var_d0h._4_4_, var_8ch);
        var_d8h = CONCAT44(var_d8h._4_4_, var_88h);
        var_a8h = (int64_t)puVar15;
        iVar4 = func_0x000180065f60(iVar3 + iVar1, (int64_t)(iVar9 - iVar3), 0x1804a5a38, (uint32_t)var_84h);
        iVar4 = iVar4 + iVar3;
        puVar5 = (uint64_t *)func_0x0001800102c0();
        var_d8h = 0;
        var_d0h = (int64_t)&var_20h;
        iVar3 = func_0x000180467554(*puVar5 | 2, iVar4 + iVar1, (int64_t)(iVar9 - iVar4), arg3);
        if (iVar3 < 0) {
            iVar3 = -1;
        }
        iVar3 = iVar3 + iVar4;
    } else {
        do {
            if (cVar6 != '%') {
                *(char *)(iVar3 + iVar1) = cVar6;
                goto code_r0x00018017330f;
            }
            puVar7 = (undefined *)(iVar10 + 1);
            iVar10 = iVar10 + 1;
    // switch table (13 cases) at 0x1801734dc
            switch(*puVar7) {
            case 0x25:
                *(undefined *)(iVar3 + iVar1) = 0x25;
                goto code_r0x00018017330f;
            case 0x48:
                uVar12 = var_90h;
                if (var_90h == 0) {
                    *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
                } else {
code_r0x000180172e4b:
                    uVar13 = uVar12 / 10;
                    *(char *)((int64_t)iVar3 + 1 + iVar1) = (char)uVar12 + (char)uVar13 * -10 + '0';
                    if (uVar13 != 0) {
                        *(char *)(iVar3 + iVar1) = (char)uVar13 + (char)(uVar13 / 10) * -10 + '0';
                        iVar3 = iVar3 + 2;
                        break;
                    }
                }
                goto code_r0x000180172e79;
            case 0x4c:
                puVar7 = (undefined *)(iVar3 + iVar1);
                iVar3 = iVar3 + 5;
                *puVar7 = *puVar15;
                puVar7[1] = puVar15[1];
                puVar7[2] = puVar15[2];
                puVar7[3] = puVar15[3];
                puVar7[4] = puVar15[4];
                break;
            case 0x4d:
                uVar12 = var_94h;
                if (var_94h != 0) goto code_r0x000180172e4b;
                *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
                goto code_r0x000180172e79;
            case 0x53:
                uVar12 = var_98h;
                if (var_98h != 0) goto code_r0x000180172e4b;
                *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
                goto code_r0x000180172e79;
            case 0x5a:
                pcVar14 = (char *)(iVar3 + iVar1);
                if (uVar11 == 0) {
                    pcVar14[5] = '0';
                    pcVar14[4] = '0';
                    pcVar14[3] = '0';
                    iVar3 = iVar3 + 6;
                    pcVar14[2] = '0';
                    pcVar14[1] = '0';
                    *pcVar14 = '0';
                } else {
                    iVar4 = (int32_t)uVar11 / 10;
                    pcVar14[5] = (char)uVar11 + (char)iVar4 * -10 + '0';
                    if (iVar4 == 0) {
                        pcVar14[4] = '0';
                        pcVar14[3] = '0';
                        pcVar14[2] = '0';
                        iVar3 = iVar3 + 6;
                        pcVar14[1] = '0';
                        *pcVar14 = '0';
                    } else {
                        iVar2 = iVar4 / 10;
                        pcVar14[4] = (char)iVar4 + (char)iVar2 * -10 + '0';
                        if (iVar2 == 0) {
                            pcVar14[3] = '0';
                            pcVar14[2] = '0';
                            pcVar14[1] = '0';
                            iVar3 = iVar3 + 6;
                            *pcVar14 = '0';
                        } else {
                            iVar4 = iVar2 / 10;
                            pcVar14[3] = (char)iVar2 + (char)iVar4 * -10 + '0';
                            if (iVar4 == 0) {
                                pcVar14[2] = '0';
                                pcVar14[1] = '0';
                                *pcVar14 = '0';
                                iVar3 = iVar3 + 6;
                            } else {
                                iVar2 = iVar4 / 10;
                                pcVar14[2] = (char)iVar4 + (char)iVar2 * -10 + '0';
                                if (iVar2 == 0) {
                                    pcVar14[1] = '0';
                                    *pcVar14 = '0';
                                    iVar3 = iVar3 + 6;
                                } else {
                                    iVar4 = iVar2 / 10;
                                    pcVar14[1] = (char)iVar2 + (char)iVar4 * -10 + '0';
                                    if (iVar4 == 0) {
                                        *pcVar14 = '0';
                                        iVar3 = iVar3 + 6;
                                    } else {
                                        *pcVar14 = (char)iVar4 + (char)(iVar4 / 10) * -10 + '0';
                                        iVar3 = iVar3 + 6;
                                    }
                                }
                            }
                        }
                    }
                }
                break;
            case 100:
                uVar12 = var_8ch;
                if (var_8ch != 0) goto code_r0x000180172e4b;
                *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
code_r0x000180172e79:
                *(undefined *)(iVar3 + iVar1) = 0x30;
                iVar3 = iVar3 + 2;
                break;
            case 0x6c:
                *(undefined *)(iVar3 + iVar1) = *puVar15;
code_r0x00018017330f:
                iVar3 = iVar3 + 1;
                break;
            case 0x6d:
                uVar12 = var_88h;
                if (var_88h != 0) goto code_r0x000180172e4b;
                *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
                *(undefined *)(iVar3 + iVar1) = 0x30;
                iVar3 = iVar3 + 2;
                break;
            case 0x73:
                puVar5 = (uint64_t *)func_0x0001800102c0();
                var_d0h = (int64_t)&var_20h;
                var_d8h = 0;
                iVar4 = func_0x000180467554(*puVar5 | 2, iVar3 + iVar1, (int64_t)(iVar9 - iVar3), arg3);
                var_70h = 0;
                if (iVar4 < 0) {
                    iVar4 = -1;
                }
                iVar3 = iVar3 + iVar4;
                uVar11 = var_84h._4_4_;
                break;
            case 0x79:
                pcVar14 = (char *)(iVar3 + iVar1);
                if ((uint32_t)var_84h == 0) {
                    pcVar14[3] = '0';
                    pcVar14[2] = '0';
                    pcVar14[1] = '0';
                    iVar3 = iVar3 + 4;
                    *pcVar14 = '0';
                } else {
                    uVar12 = (uint32_t)var_84h / 10;
                    pcVar14[3] = (char)(uint32_t)var_84h + (char)uVar12 * -10 + '0';
                    if (uVar12 == 0) {
                        pcVar14[2] = '0';
                        pcVar14[1] = '0';
                        *pcVar14 = '0';
                        iVar3 = iVar3 + 4;
                    } else {
                        uVar13 = uVar12 / 10;
                        pcVar14[2] = (char)uVar12 + (char)uVar13 * -10 + '0';
                        if (uVar13 == 0) {
                            pcVar14[1] = '0';
                            *pcVar14 = '0';
                            iVar3 = iVar3 + 4;
                        } else {
                            uVar12 = uVar13 / 10;
                            pcVar14[1] = (char)uVar13 + (char)uVar12 * -10 + '0';
                            if (uVar12 == 0) {
                                *pcVar14 = '0';
                                iVar3 = iVar3 + 4;
                            } else {
                                *pcVar14 = (char)uVar12 + (char)(uVar12 / 10) * -10 + '0';
                                iVar3 = iVar3 + 4;
                            }
                        }
                    }
                }
                break;
            case 0x7a:
                pcVar14 = (char *)(iVar3 + iVar1);
                iVar4 = (int32_t)uVar11 / 1000;
                if (iVar4 == 0) {
                    pcVar14[2] = '0';
                    pcVar14[1] = '0';
                    *pcVar14 = '0';
                    iVar3 = iVar3 + 3;
                } else {
                    iVar2 = iVar4 / 10;
                    pcVar14[2] = (char)iVar4 + (char)iVar2 * -10 + '0';
                    if (iVar2 == 0) {
                        pcVar14[1] = '0';
                        *pcVar14 = '0';
                        iVar3 = iVar3 + 3;
                    } else {
                        iVar4 = iVar2 / 10;
                        pcVar14[1] = (char)iVar2 + (char)iVar4 * -10 + '0';
                        if (iVar4 == 0) {
                            *pcVar14 = '0';
                            iVar3 = iVar3 + 3;
                        } else {
                            *pcVar14 = (char)iVar4 + (char)(iVar4 / 10) * -10 + '0';
                            iVar3 = iVar3 + 3;
                        }
                    }
                }
            }
            if (iVar9 <= iVar3) break;
            cVar6 = *(char *)(iVar10 + 1);
            iVar10 = iVar10 + 1;
        } while (cVar6 != '\0');
    }
    if (*(int32_t *)(arg1 + 0x1c) == 0) {
code_r0x000180173431:
        if (iVar9 <= iVar3) goto code_r0x000180173442;
        iVar9 = iVar3 + 1;
        *(undefined *)(iVar3 + iVar1) = 10;
    } else {
        if (iVar3 < iVar9) {
            iVar4 = func_0x000180065f60(iVar3 + iVar1, (int64_t)(iVar9 - iVar3), 0x18063cc8c, 0x1804a5a60);
            iVar3 = iVar3 + iVar4;
            goto code_r0x000180173431;
        }
code_r0x000180173442:
        *(undefined *)((int64_t)iVar9 + -1 + iVar1) = 10;
    }
    if (*(code **)arg1 == (code *)0x0) {
        iVar10 = fcn.1801725f0(arg1);
        if ((iVar10 != 0) && (func_0x000180460a38(iVar1, 1, (int64_t)iVar9, iVar10), *(int32_t *)(arg1 + 0x170) != 0)) {
            func_0x00018045fdf8(iVar10);
        }
    } else {
        (**(code **)arg1)((int32_t)var_7ch, iVar1, iVar9);
    }
    (*(code *)0x699f34)(stack0xffffffffffffff88);
code_r0x0001801734bf:
    func_0x000180459870(var_58h ^ (uint64_t)auStack_f8);
    return;
}

// ============================================================
// Function: FUN_1801734bf
// Address: 0x1801734bf
// Size: 167 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

void fcn.180172b00(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    uint64_t *puVar5;
    char cVar6;
    undefined *puVar7;
    undefined8 uVar8;
    int32_t iVar9;
    int64_t iVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    uint32_t uVar13;
    char *pcVar14;
    undefined *puVar15;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_f8 [32];
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    uint32_t var_98h;
    uint32_t var_94h;
    uint32_t var_90h;
    uint32_t var_8ch;
    uint32_t var_88h;
    int64_t var_84h;
    int64_t var_7ch;
    int64_t var_70h;
    int64_t var_68h;
    uint16_t var_60h;
    uint16_t var_5eh;
    uint16_t var_5ch;
    uint16_t var_5ah;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_f8;
    iVar9 = (int32_t)arg2;
    var_20h = arg4;
    var_7ch._0_4_ = iVar9;
    if (iVar9 < *(int32_t *)(arg1 + 0x18)) goto code_r0x0001801734bf;
    (*(code *)0x699f64)(&var_68h);
    var_84h._0_4_ = (uint32_t)(uint16_t)var_68h;
    var_88h = (uint32_t)var_68h._2_2_;
    var_8ch = (uint32_t)var_68h._6_2_;
    var_90h = (uint32_t)var_60h;
    var_94h = (uint32_t)var_5eh;
    var_98h = (uint32_t)var_5ch;
    uVar11 = (uint32_t)var_5ah * 1000;
    if (iVar9 == 1) {
        puVar15 = (undefined *)0x1804a59ac;
        uVar8 = 0x1804a59f4;
    } else if (iVar9 == 2) {
        puVar15 = (undefined *)0x1804a59fc;
        uVar8 = 0x1804a5a04;
    } else if (iVar9 == 3) {
        puVar15 = (undefined *)0x1804a5a0c;
        uVar8 = 0x1804a5a14;
    } else if (iVar9 == 4) {
        puVar15 = (undefined *)0x1804a59b4;
        uVar8 = 0x1804a5a1c;
    } else if (iVar9 == 5) {
        puVar15 = (undefined *)0x1804a59bc;
        uVar8 = 0x1804a5a28;
    } else {
        puVar15 = (undefined *)0x1805aadb1;
        uVar8 = 0x1805aadb1;
    }
    unique0x00003200 = arg1 + 0x290;
    var_84h._4_4_ = uVar11;
    (*(code *)0x699f1c)(unique0x00003200);
    iVar1 = *(int64_t *)(arg1 + 0x10);
    iVar3 = 0;
    iVar9 = *(int32_t *)(arg1 + 8);
    if (*(int32_t *)(arg1 + 0x1c) != 0) {
        iVar3 = func_0x000180065f60(iVar1, (int64_t)iVar9, 0x18063cc8c, uVar8);
    }
    cVar6 = *(char *)(arg1 + 0x20);
    iVar10 = arg1 + 0x20;
    if (cVar6 == '\0') {
        var_b0h._0_4_ = uVar11 / 1000;
        var_b8h._0_4_ = var_98h;
        var_c0h._0_4_ = var_94h;
        var_c8h._0_4_ = var_90h;
        var_d0h = CONCAT44(var_d0h._4_4_, var_8ch);
        var_d8h = CONCAT44(var_d8h._4_4_, var_88h);
        var_a8h = (int64_t)puVar15;
        iVar4 = func_0x000180065f60(iVar3 + iVar1, (int64_t)(iVar9 - iVar3), 0x1804a5a38, (uint32_t)var_84h);
        iVar4 = iVar4 + iVar3;
        puVar5 = (uint64_t *)func_0x0001800102c0();
        var_d8h = 0;
        var_d0h = (int64_t)&var_20h;
        iVar3 = func_0x000180467554(*puVar5 | 2, iVar4 + iVar1, (int64_t)(iVar9 - iVar4), arg3);
        if (iVar3 < 0) {
            iVar3 = -1;
        }
        iVar3 = iVar3 + iVar4;
    } else {
        do {
            if (cVar6 != '%') {
                *(char *)(iVar3 + iVar1) = cVar6;
                goto code_r0x00018017330f;
            }
            puVar7 = (undefined *)(iVar10 + 1);
            iVar10 = iVar10 + 1;
    // switch table (13 cases) at 0x1801734dc
            switch(*puVar7) {
            case 0x25:
                *(undefined *)(iVar3 + iVar1) = 0x25;
                goto code_r0x00018017330f;
            case 0x48:
                uVar12 = var_90h;
                if (var_90h == 0) {
                    *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
                } else {
code_r0x000180172e4b:
                    uVar13 = uVar12 / 10;
                    *(char *)((int64_t)iVar3 + 1 + iVar1) = (char)uVar12 + (char)uVar13 * -10 + '0';
                    if (uVar13 != 0) {
                        *(char *)(iVar3 + iVar1) = (char)uVar13 + (char)(uVar13 / 10) * -10 + '0';
                        iVar3 = iVar3 + 2;
                        break;
                    }
                }
                goto code_r0x000180172e79;
            case 0x4c:
                puVar7 = (undefined *)(iVar3 + iVar1);
                iVar3 = iVar3 + 5;
                *puVar7 = *puVar15;
                puVar7[1] = puVar15[1];
                puVar7[2] = puVar15[2];
                puVar7[3] = puVar15[3];
                puVar7[4] = puVar15[4];
                break;
            case 0x4d:
                uVar12 = var_94h;
                if (var_94h != 0) goto code_r0x000180172e4b;
                *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
                goto code_r0x000180172e79;
            case 0x53:
                uVar12 = var_98h;
                if (var_98h != 0) goto code_r0x000180172e4b;
                *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
                goto code_r0x000180172e79;
            case 0x5a:
                pcVar14 = (char *)(iVar3 + iVar1);
                if (uVar11 == 0) {
                    pcVar14[5] = '0';
                    pcVar14[4] = '0';
                    pcVar14[3] = '0';
                    iVar3 = iVar3 + 6;
                    pcVar14[2] = '0';
                    pcVar14[1] = '0';
                    *pcVar14 = '0';
                } else {
                    iVar4 = (int32_t)uVar11 / 10;
                    pcVar14[5] = (char)uVar11 + (char)iVar4 * -10 + '0';
                    if (iVar4 == 0) {
                        pcVar14[4] = '0';
                        pcVar14[3] = '0';
                        pcVar14[2] = '0';
                        iVar3 = iVar3 + 6;
                        pcVar14[1] = '0';
                        *pcVar14 = '0';
                    } else {
                        iVar2 = iVar4 / 10;
                        pcVar14[4] = (char)iVar4 + (char)iVar2 * -10 + '0';
                        if (iVar2 == 0) {
                            pcVar14[3] = '0';
                            pcVar14[2] = '0';
                            pcVar14[1] = '0';
                            iVar3 = iVar3 + 6;
                            *pcVar14 = '0';
                        } else {
                            iVar4 = iVar2 / 10;
                            pcVar14[3] = (char)iVar2 + (char)iVar4 * -10 + '0';
                            if (iVar4 == 0) {
                                pcVar14[2] = '0';
                                pcVar14[1] = '0';
                                *pcVar14 = '0';
                                iVar3 = iVar3 + 6;
                            } else {
                                iVar2 = iVar4 / 10;
                                pcVar14[2] = (char)iVar4 + (char)iVar2 * -10 + '0';
                                if (iVar2 == 0) {
                                    pcVar14[1] = '0';
                                    *pcVar14 = '0';
                                    iVar3 = iVar3 + 6;
                                } else {
                                    iVar4 = iVar2 / 10;
                                    pcVar14[1] = (char)iVar2 + (char)iVar4 * -10 + '0';
                                    if (iVar4 == 0) {
                                        *pcVar14 = '0';
                                        iVar3 = iVar3 + 6;
                                    } else {
                                        *pcVar14 = (char)iVar4 + (char)(iVar4 / 10) * -10 + '0';
                                        iVar3 = iVar3 + 6;
                                    }
                                }
                            }
                        }
                    }
                }
                break;
            case 100:
                uVar12 = var_8ch;
                if (var_8ch != 0) goto code_r0x000180172e4b;
                *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
code_r0x000180172e79:
                *(undefined *)(iVar3 + iVar1) = 0x30;
                iVar3 = iVar3 + 2;
                break;
            case 0x6c:
                *(undefined *)(iVar3 + iVar1) = *puVar15;
code_r0x00018017330f:
                iVar3 = iVar3 + 1;
                break;
            case 0x6d:
                uVar12 = var_88h;
                if (var_88h != 0) goto code_r0x000180172e4b;
                *(undefined *)((int64_t)iVar3 + 1 + iVar1) = 0x30;
                *(undefined *)(iVar3 + iVar1) = 0x30;
                iVar3 = iVar3 + 2;
                break;
            case 0x73:
                puVar5 = (uint64_t *)func_0x0001800102c0();
                var_d0h = (int64_t)&var_20h;
                var_d8h = 0;
                iVar4 = func_0x000180467554(*puVar5 | 2, iVar3 + iVar1, (int64_t)(iVar9 - iVar3), arg3);
                var_70h = 0;
                if (iVar4 < 0) {
                    iVar4 = -1;
                }
                iVar3 = iVar3 + iVar4;
                uVar11 = var_84h._4_4_;
                break;
            case 0x79:
                pcVar14 = (char *)(iVar3 + iVar1);
                if ((uint32_t)var_84h == 0) {
                    pcVar14[3] = '0';
                    pcVar14[2] = '0';
                    pcVar14[1] = '0';
                    iVar3 = iVar3 + 4;
                    *pcVar14 = '0';
                } else {
                    uVar12 = (uint32_t)var_84h / 10;
                    pcVar14[3] = (char)(uint32_t)var_84h + (char)uVar12 * -10 + '0';
                    if (uVar12 == 0) {
                        pcVar14[2] = '0';
                        pcVar14[1] = '0';
                        *pcVar14 = '0';
                        iVar3 = iVar3 + 4;
                    } else {
                        uVar13 = uVar12 / 10;
                        pcVar14[2] = (char)uVar12 + (char)uVar13 * -10 + '0';
                        if (uVar13 == 0) {
                            pcVar14[1] = '0';
                            *pcVar14 = '0';
                            iVar3 = iVar3 + 4;
                        } else {
                            uVar12 = uVar13 / 10;
                            pcVar14[1] = (char)uVar13 + (char)uVar12 * -10 + '0';
                            if (uVar12 == 0) {
                                *pcVar14 = '0';
                                iVar3 = iVar3 + 4;
                            } else {
                                *pcVar14 = (char)uVar12 + (char)(uVar12 / 10) * -10 + '0';
                                iVar3 = iVar3 + 4;
                            }
                        }
                    }
                }
                break;
            case 0x7a:
                pcVar14 = (char *)(iVar3 + iVar1);
                iVar4 = (int32_t)uVar11 / 1000;
                if (iVar4 == 0) {
                    pcVar14[2] = '0';
                    pcVar14[1] = '0';
                    *pcVar14 = '0';
                    iVar3 = iVar3 + 3;
                } else {
                    iVar2 = iVar4 / 10;
                    pcVar14[2] = (char)iVar4 + (char)iVar2 * -10 + '0';
                    if (iVar2 == 0) {
                        pcVar14[1] = '0';
                        *pcVar14 = '0';
                        iVar3 = iVar3 + 3;
                    } else {
                        iVar4 = iVar2 / 10;
                        pcVar14[1] = (char)iVar2 + (char)iVar4 * -10 + '0';
                        if (iVar4 == 0) {
                            *pcVar14 = '0';
                            iVar3 = iVar3 + 3;
                        } else {
                            *pcVar14 = (char)iVar4 + (char)(iVar4 / 10) * -10 + '0';
                            iVar3 = iVar3 + 3;
                        }
                    }
                }
            }
            if (iVar9 <= iVar3) break;
            cVar6 = *(char *)(iVar10 + 1);
            iVar10 = iVar10 + 1;
        } while (cVar6 != '\0');
    }
    if (*(int32_t *)(arg1 + 0x1c) == 0) {
code_r0x000180173431:
        if (iVar9 <= iVar3) goto code_r0x000180173442;
        iVar9 = iVar3 + 1;
        *(undefined *)(iVar3 + iVar1) = 10;
    } else {
        if (iVar3 < iVar9) {
            iVar4 = func_0x000180065f60(iVar3 + iVar1, (int64_t)(iVar9 - iVar3), 0x18063cc8c, 0x1804a5a60);
            iVar3 = iVar3 + iVar4;
            goto code_r0x000180173431;
        }
code_r0x000180173442:
        *(undefined *)((int64_t)iVar9 + -1 + iVar1) = 10;
    }
    if (*(code **)arg1 == (code *)0x0) {
        iVar10 = fcn.1801725f0(arg1);
        if ((iVar10 != 0) && (func_0x000180460a38(iVar1, 1, (int64_t)iVar9, iVar10), *(int32_t *)(arg1 + 0x170) != 0)) {
            func_0x00018045fdf8(iVar10);
        }
    } else {
        (**(code **)arg1)((int32_t)var_7ch, iVar1, iVar9);
    }
    (*(code *)0x699f34)(stack0xffffffffffffff88);
code_r0x0001801734bf:
    func_0x000180459870(var_58h ^ (uint64_t)auStack_f8);
    return;
}

// ============================================================
// Function: FUN_1801735b0
// Address: 0x1801735b0
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

undefined8 fcn.1801735b0(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t arg1_00;
    undefined8 uVar3;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStackY_48;
    undefined8 uStackY_40;
    undefined8 uStackY_38;
    undefined8 uStackY_30;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(uint32_t *)(arg1 + 0xa0) < (uint32_t)arg2) {
        unique0x100000ea = var_18h;
        iVar2 = fcn.18045b9a8(0x1804a5a70, 0x5c);
        uVar1 = *(uint32_t *)(arg1 + 0xa0);
        arg1_00 = fcn.1801723e0(stack0xfffffffffffffff0);
        var_18h = 0x1804a5ad8;
        var_20h = CONCAT44(var_20h._4_4_, 0x2b5);
        var_28h = iVar2 + 1;
        fcn.180172b00(arg1_00, 4, 0x1804a5af0, (uint64_t)uVar1);
        *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
        uStackY_48 = 0;
        uStackY_40 = 0;
        uStackY_38 = 0;
        _var_18h = ZEXT816(0);
        uStackY_30 = 0x180181d50;
        var_20h = (int64_t)*(uint32_t *)(arg1 + 0x44);
        var_28h = arg1;
        fcn.1801823b0(*(undefined8 *)arg1, &uStackY_48);
        return 0;
    }
    *(int64_t *)0x18 = (int64_t)(int32_t)(uint32_t)arg2;
    if ((*(uint32_t *)(arg1 + 0x3c) >> 0xe & 1) == 0) {
        uVar3 = fcn.1801813b0(*(int64_t *)0x18);
    } else {
        uVar3 = fcn.180181320(*(undefined8 *)(arg1 + 0x78), *(int64_t *)0x18, *(undefined8 *)(arg1 + 0x80));
    }
    *(undefined8 *)(arg1 + 0x78) = uVar3;
    *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 0x4000;
    *(int64_t *)(arg1 + 0x80) = *(int64_t *)0x18;
    *(undefined4 *)(arg1 + 0xa4) = 0;
    return uVar3;
}

// ============================================================
// Function: FUN_1801735ca
// Address: 0x1801735ca
// Size: 110 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

undefined8 fcn.1801735b0(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t arg1_00;
    undefined8 uVar3;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStackY_48;
    undefined8 uStackY_40;
    undefined8 uStackY_38;
    undefined8 uStackY_30;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(uint32_t *)(arg1 + 0xa0) < (uint32_t)arg2) {
        unique0x100000ea = var_18h;
        iVar2 = fcn.18045b9a8(0x1804a5a70, 0x5c);
        uVar1 = *(uint32_t *)(arg1 + 0xa0);
        arg1_00 = fcn.1801723e0(stack0xfffffffffffffff0);
        var_18h = 0x1804a5ad8;
        var_20h = CONCAT44(var_20h._4_4_, 0x2b5);
        var_28h = iVar2 + 1;
        fcn.180172b00(arg1_00, 4, 0x1804a5af0, (uint64_t)uVar1);
        *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
        uStackY_48 = 0;
        uStackY_40 = 0;
        uStackY_38 = 0;
        _var_18h = ZEXT816(0);
        uStackY_30 = 0x180181d50;
        var_20h = (int64_t)*(uint32_t *)(arg1 + 0x44);
        var_28h = arg1;
        fcn.1801823b0(*(undefined8 *)arg1, &uStackY_48);
        return 0;
    }
    *(int64_t *)0x18 = (int64_t)(int32_t)(uint32_t)arg2;
    if ((*(uint32_t *)(arg1 + 0x3c) >> 0xe & 1) == 0) {
        uVar3 = fcn.1801813b0(*(int64_t *)0x18);
    } else {
        uVar3 = fcn.180181320(*(undefined8 *)(arg1 + 0x78), *(int64_t *)0x18, *(undefined8 *)(arg1 + 0x80));
    }
    *(undefined8 *)(arg1 + 0x78) = uVar3;
    *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 0x4000;
    *(int64_t *)(arg1 + 0x80) = *(int64_t *)0x18;
    *(undefined4 *)(arg1 + 0xa4) = 0;
    return uVar3;
}

// ============================================================
// Function: FUN_180173638
// Address: 0x180173638
// Size: 81 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

undefined8 fcn.1801735b0(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t arg1_00;
    undefined8 uVar3;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStackY_48;
    undefined8 uStackY_40;
    undefined8 uStackY_38;
    undefined8 uStackY_30;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(uint32_t *)(arg1 + 0xa0) < (uint32_t)arg2) {
        unique0x100000ea = var_18h;
        iVar2 = fcn.18045b9a8(0x1804a5a70, 0x5c);
        uVar1 = *(uint32_t *)(arg1 + 0xa0);
        arg1_00 = fcn.1801723e0(stack0xfffffffffffffff0);
        var_18h = 0x1804a5ad8;
        var_20h = CONCAT44(var_20h._4_4_, 0x2b5);
        var_28h = iVar2 + 1;
        fcn.180172b00(arg1_00, 4, 0x1804a5af0, (uint64_t)uVar1);
        *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
        uStackY_48 = 0;
        uStackY_40 = 0;
        uStackY_38 = 0;
        _var_18h = ZEXT816(0);
        uStackY_30 = 0x180181d50;
        var_20h = (int64_t)*(uint32_t *)(arg1 + 0x44);
        var_28h = arg1;
        fcn.1801823b0(*(undefined8 *)arg1, &uStackY_48);
        return 0;
    }
    *(int64_t *)0x18 = (int64_t)(int32_t)(uint32_t)arg2;
    if ((*(uint32_t *)(arg1 + 0x3c) >> 0xe & 1) == 0) {
        uVar3 = fcn.1801813b0(*(int64_t *)0x18);
    } else {
        uVar3 = fcn.180181320(*(undefined8 *)(arg1 + 0x78), *(int64_t *)0x18, *(undefined8 *)(arg1 + 0x80));
    }
    *(undefined8 *)(arg1 + 0x78) = uVar3;
    *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 0x4000;
    *(int64_t *)(arg1 + 0x80) = *(int64_t *)0x18;
    *(undefined4 *)(arg1 + 0xa4) = 0;
    return uVar3;
}

// ============================================================
// Function: FUN_1801736e0
// Address: 0x1801736e0
// Size: 47 bytes
// ============================================================
void fcn.1801736e0(int64_t arg1)
{
    if (*(int64_t *)(arg1 + 0x148) != 0) {
        fcn.180182cf0();
        *(undefined8 *)(arg1 + 0x148) = 0;
        *(undefined4 *)(arg1 + 0x124) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180173710
// Address: 0x180173710
// Size: 47 bytes
// ============================================================
void fcn.180173710(int64_t arg1)
{
    if (*(int64_t *)(arg1 + 0x140) != 0) {
        fcn.180182cf0();
        *(undefined8 *)(arg1 + 0x140) = 0;
        *(undefined4 *)(arg1 + 0x120) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180173740
// Address: 0x180173740
// Size: 54 bytes
// ============================================================
void fcn.180173740(int64_t arg1)
{
    if (*(int64_t *)(arg1 + 0x168) != 0) {
        fcn.180182cf0();
        *(undefined8 *)(arg1 + 0x168) = 0;
        *(undefined4 *)(arg1 + 0x134) = 0;
        *(undefined8 *)(arg1 + 0x138) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180173780
// Address: 0x180173780
// Size: 47 bytes
// ============================================================
void fcn.180173780(int64_t arg1)
{
    if (*(int64_t *)(arg1 + 0x160) != 0) {
        fcn.180182cf0();
        *(undefined8 *)(arg1 + 0x160) = 0;
        *(undefined4 *)(arg1 + 0x130) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1801737b0
// Address: 0x1801737b0
// Size: 47 bytes
// ============================================================
void fcn.1801737b0(int64_t arg1)
{
    if (*(int64_t *)(arg1 + 0x150) != 0) {
        fcn.180182cf0();
        *(undefined8 *)(arg1 + 0x150) = 0;
        *(undefined4 *)(arg1 + 0x128) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1801737e0
// Address: 0x1801737e0
// Size: 47 bytes
// ============================================================
void fcn.1801737e0(int64_t arg1)
{
    if (*(int64_t *)(arg1 + 0x158) != 0) {
        fcn.180182cf0();
        *(undefined8 *)(arg1 + 0x158) = 0;
        *(undefined4 *)(arg1 + 300) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180173810
// Address: 0x180173810
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180173810(int64_t arg1, int64_t arg_48h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    if ((*(uint32_t *)(arg1 + 0x3c) & 8) != 0) {
        *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xfffffff7;
        func_0x000180181d70(arg1, 5);
        if ((*(uint32_t *)(arg1 + 0x3c) >> 0xe & 1) != 0) {
            if (*(int64_t *)(arg1 + 0x78) != 0) {
                func_0x000180180fe0();
                *(undefined8 *)(arg1 + 0x78) = 0;
            }
            *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xffffbfff;
            *(undefined8 *)(arg1 + 0x78) = *(undefined8 *)(*(int64_t *)arg1 + 0x138);
            *(undefined8 *)(arg1 + 0x80) = *(undefined8 *)(*(int64_t *)arg1 + 0x140);
        }
        (*(code *)0x699f1c)(arg1 + 200);
        iVar2 = *(int64_t *)(arg1 + 0xb0);
        while (iVar2 != 0) {
            piVar3 = (int64_t *)0x0;
            if (*(int64_t *)(arg1 + 0xb0) != 0) {
                piVar3 = (int64_t *)(*(int64_t *)(arg1 + 0xa8) + *(int64_t *)(arg1 + 0xc0) * 0x18);
            }
            if (*piVar3 != 0) {
                func_0x000180180fe0();
                *piVar3 = 0;
            }
            iVar2 = *(int64_t *)(arg1 + 0xb0) + -1;
            iVar1 = *(int64_t *)(arg1 + 0xc0) + 1;
            *(int64_t *)(arg1 + 0xb0) = iVar2;
            *(int64_t *)(arg1 + 0xc0) = iVar1;
            if (iVar1 == *(int64_t *)(arg1 + 0xb8)) {
                *(undefined8 *)(arg1 + 0xc0) = 0;
            }
        }
        if (*(int64_t *)(arg1 + 0xa8) != 0) {
            func_0x000180180fe0();
            *(undefined8 *)(arg1 + 0xa8) = 0;
        }
        *(undefined8 *)(arg1 + 0xb8) = 0;
        *(undefined8 *)(arg1 + 0xb0) = 0;
        *(undefined8 *)(arg1 + 0xc0) = 0;
        (*(code *)0x699f34)(arg1 + 200);
    }
    return;
}

// ============================================================
// Function: FUN_180173827
// Address: 0x180173827
// Size: 110 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180173810(int64_t arg1, int64_t arg_48h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    if ((*(uint32_t *)(arg1 + 0x3c) & 8) != 0) {
        *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xfffffff7;
        func_0x000180181d70(arg1, 5);
        if ((*(uint32_t *)(arg1 + 0x3c) >> 0xe & 1) != 0) {
            if (*(int64_t *)(arg1 + 0x78) != 0) {
                func_0x000180180fe0();
                *(undefined8 *)(arg1 + 0x78) = 0;
            }
            *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xffffbfff;
            *(undefined8 *)(arg1 + 0x78) = *(undefined8 *)(*(int64_t *)arg1 + 0x138);
            *(undefined8 *)(arg1 + 0x80) = *(undefined8 *)(*(int64_t *)arg1 + 0x140);
        }
        (*(code *)0x699f1c)(arg1 + 200);
        iVar2 = *(int64_t *)(arg1 + 0xb0);
        while (iVar2 != 0) {
            piVar3 = (int64_t *)0x0;
            if (*(int64_t *)(arg1 + 0xb0) != 0) {
                piVar3 = (int64_t *)(*(int64_t *)(arg1 + 0xa8) + *(int64_t *)(arg1 + 0xc0) * 0x18);
            }
            if (*piVar3 != 0) {
                func_0x000180180fe0();
                *piVar3 = 0;
            }
            iVar2 = *(int64_t *)(arg1 + 0xb0) + -1;
            iVar1 = *(int64_t *)(arg1 + 0xc0) + 1;
            *(int64_t *)(arg1 + 0xb0) = iVar2;
            *(int64_t *)(arg1 + 0xc0) = iVar1;
            if (iVar1 == *(int64_t *)(arg1 + 0xb8)) {
                *(undefined8 *)(arg1 + 0xc0) = 0;
            }
        }
        if (*(int64_t *)(arg1 + 0xa8) != 0) {
            func_0x000180180fe0();
            *(undefined8 *)(arg1 + 0xa8) = 0;
        }
        *(undefined8 *)(arg1 + 0xb8) = 0;
        *(undefined8 *)(arg1 + 0xb0) = 0;
        *(undefined8 *)(arg1 + 0xc0) = 0;
        (*(code *)0x699f34)(arg1 + 200);
    }
    return;
}

// ============================================================
// Function: FUN_180173895
// Address: 0x180173895
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180173810(int64_t arg1, int64_t arg_48h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    if ((*(uint32_t *)(arg1 + 0x3c) & 8) != 0) {
        *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xfffffff7;
        func_0x000180181d70(arg1, 5);
        if ((*(uint32_t *)(arg1 + 0x3c) >> 0xe & 1) != 0) {
            if (*(int64_t *)(arg1 + 0x78) != 0) {
                func_0x000180180fe0();
                *(undefined8 *)(arg1 + 0x78) = 0;
            }
            *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xffffbfff;
            *(undefined8 *)(arg1 + 0x78) = *(undefined8 *)(*(int64_t *)arg1 + 0x138);
            *(undefined8 *)(arg1 + 0x80) = *(undefined8 *)(*(int64_t *)arg1 + 0x140);
        }
        (*(code *)0x699f1c)(arg1 + 200);
        iVar2 = *(int64_t *)(arg1 + 0xb0);
        while (iVar2 != 0) {
            piVar3 = (int64_t *)0x0;
            if (*(int64_t *)(arg1 + 0xb0) != 0) {
                piVar3 = (int64_t *)(*(int64_t *)(arg1 + 0xa8) + *(int64_t *)(arg1 + 0xc0) * 0x18);
            }
            if (*piVar3 != 0) {
                func_0x000180180fe0();
                *piVar3 = 0;
            }
            iVar2 = *(int64_t *)(arg1 + 0xb0) + -1;
            iVar1 = *(int64_t *)(arg1 + 0xc0) + 1;
            *(int64_t *)(arg1 + 0xb0) = iVar2;
            *(int64_t *)(arg1 + 0xc0) = iVar1;
            if (iVar1 == *(int64_t *)(arg1 + 0xb8)) {
                *(undefined8 *)(arg1 + 0xc0) = 0;
            }
        }
        if (*(int64_t *)(arg1 + 0xa8) != 0) {
            func_0x000180180fe0();
            *(undefined8 *)(arg1 + 0xa8) = 0;
        }
        *(undefined8 *)(arg1 + 0xb8) = 0;
        *(undefined8 *)(arg1 + 0xb0) = 0;
        *(undefined8 *)(arg1 + 0xc0) = 0;
        (*(code *)0x699f34)(arg1 + 200);
    }
    return;
}

// ============================================================
// Function: FUN_180173910
// Address: 0x180173910
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180173810(int64_t arg1, int64_t arg_48h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    if ((*(uint32_t *)(arg1 + 0x3c) & 8) != 0) {
        *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xfffffff7;
        func_0x000180181d70(arg1, 5);
        if ((*(uint32_t *)(arg1 + 0x3c) >> 0xe & 1) != 0) {
            if (*(int64_t *)(arg1 + 0x78) != 0) {
                func_0x000180180fe0();
                *(undefined8 *)(arg1 + 0x78) = 0;
            }
            *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xffffbfff;
            *(undefined8 *)(arg1 + 0x78) = *(undefined8 *)(*(int64_t *)arg1 + 0x138);
            *(undefined8 *)(arg1 + 0x80) = *(undefined8 *)(*(int64_t *)arg1 + 0x140);
        }
        (*(code *)0x699f1c)(arg1 + 200);
        iVar2 = *(int64_t *)(arg1 + 0xb0);
        while (iVar2 != 0) {
            piVar3 = (int64_t *)0x0;
            if (*(int64_t *)(arg1 + 0xb0) != 0) {
                piVar3 = (int64_t *)(*(int64_t *)(arg1 + 0xa8) + *(int64_t *)(arg1 + 0xc0) * 0x18);
            }
            if (*piVar3 != 0) {
                func_0x000180180fe0();
                *piVar3 = 0;
            }
            iVar2 = *(int64_t *)(arg1 + 0xb0) + -1;
            iVar1 = *(int64_t *)(arg1 + 0xc0) + 1;
            *(int64_t *)(arg1 + 0xb0) = iVar2;
            *(int64_t *)(arg1 + 0xc0) = iVar1;
            if (iVar1 == *(int64_t *)(arg1 + 0xb8)) {
                *(undefined8 *)(arg1 + 0xc0) = 0;
            }
        }
        if (*(int64_t *)(arg1 + 0xa8) != 0) {
            func_0x000180180fe0();
            *(undefined8 *)(arg1 + 0xa8) = 0;
        }
        *(undefined8 *)(arg1 + 0xb8) = 0;
        *(undefined8 *)(arg1 + 0xb0) = 0;
        *(undefined8 *)(arg1 + 0xc0) = 0;
        (*(code *)0x699f34)(arg1 + 200);
    }
    return;
}

// ============================================================
// Function: FUN_180173954
// Address: 0x180173954
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180173810(int64_t arg1, int64_t arg_48h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    if ((*(uint32_t *)(arg1 + 0x3c) & 8) != 0) {
        *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xfffffff7;
        func_0x000180181d70(arg1, 5);
        if ((*(uint32_t *)(arg1 + 0x3c) >> 0xe & 1) != 0) {
            if (*(int64_t *)(arg1 + 0x78) != 0) {
                func_0x000180180fe0();
                *(undefined8 *)(arg1 + 0x78) = 0;
            }
            *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xffffbfff;
            *(undefined8 *)(arg1 + 0x78) = *(undefined8 *)(*(int64_t *)arg1 + 0x138);
            *(undefined8 *)(arg1 + 0x80) = *(undefined8 *)(*(int64_t *)arg1 + 0x140);
        }
        (*(code *)0x699f1c)(arg1 + 200);
        iVar2 = *(int64_t *)(arg1 + 0xb0);
        while (iVar2 != 0) {
            piVar3 = (int64_t *)0x0;
            if (*(int64_t *)(arg1 + 0xb0) != 0) {
                piVar3 = (int64_t *)(*(int64_t *)(arg1 + 0xa8) + *(int64_t *)(arg1 + 0xc0) * 0x18);
            }
            if (*piVar3 != 0) {
                func_0x000180180fe0();
                *piVar3 = 0;
            }
            iVar2 = *(int64_t *)(arg1 + 0xb0) + -1;
            iVar1 = *(int64_t *)(arg1 + 0xc0) + 1;
            *(int64_t *)(arg1 + 0xb0) = iVar2;
            *(int64_t *)(arg1 + 0xc0) = iVar1;
            if (iVar1 == *(int64_t *)(arg1 + 0xb8)) {
                *(undefined8 *)(arg1 + 0xc0) = 0;
            }
        }
        if (*(int64_t *)(arg1 + 0xa8) != 0) {
            func_0x000180180fe0();
            *(undefined8 *)(arg1 + 0xa8) = 0;
        }
        *(undefined8 *)(arg1 + 0xb8) = 0;
        *(undefined8 *)(arg1 + 0xb0) = 0;
        *(undefined8 *)(arg1 + 0xc0) = 0;
        (*(code *)0x699f34)(arg1 + 200);
    }
    return;
}

// ============================================================
// Function: FUN_180173980
// Address: 0x180173980
// Size: 102 bytes
// ============================================================
void fcn.180173980(int64_t arg1)
{
    if ((arg1 != 0) && ((*(uint32_t *)(arg1 + 0x3c) & 1) == 0)) {
        *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 1;
        func_0x000180183710();
        (*(code *)0x699f4c)(arg1 + 200);
        if (*(int64_t *)(arg1 + 0x58) != 0) {
            func_0x000180180fe0();
            *(undefined8 *)(arg1 + 0x58) = 0;
        }
        if (*(int64_t *)(arg1 + 0x60) != 0) {
            func_0x000180180fe0();
            *(undefined8 *)(arg1 + 0x60) = 0;
        }
        func_0x000180180fe0(arg1);
    }
    return;
}

// ============================================================
// Function: FUN_180173a20
// Address: 0x180173a20
// Size: 409 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x000180173b35: Changing call to branch
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

uint64_t fcn.180173a20(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t unaff_RBX;
    undefined8 unaff_RSI;
    uint64_t unaff_RDI;
    int32_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStackY_48;
    undefined8 uStackY_40;
    undefined8 uStackY_38;
    undefined8 uStackY_30;
    int64_t iStackY_28;
    undefined8 uStackY_20;
    int64_t iStackY_18;
    
    uVar6 = 0;
    unique0x10000289 = iStackY_18;
    if (*(int64_t *)(arg1 + 0x178) == 0) {
        iVar4 = *(int64_t *)(arg1 + 0x88);
        uVar3 = *(uint32_t *)(arg1 + 0x98);
        iVar5 = *(int64_t *)(arg1 + 0x78) + iVar4;
        iVar9 = (int32_t)arg3;
        if ((uVar3 & 2) == 0) {
            if ((uVar3 & 4) == 0) {
                *(undefined8 *)(arg1 + 0x90) = 0;
                uVar7 = (uint64_t)(uint32_t)((int32_t)(iVar9 + arg2) - (int32_t)iVar5);
                *(undefined8 *)(arg1 + 0x88) = 0;
                goto code_r0x000180173b2f;
            }
            if (0 < iVar9) {
                uVar7 = uVar6;
                do {
                    if (*(char *)arg2 == *(char *)(arg1 + 0x9c)) {
                        uVar2 = ((int32_t)arg2 - (int32_t)iVar5) + 1;
                        uVar7 = (uint64_t)uVar2;
                        iVar4 = (int32_t)uVar2 + iVar4;
                        *(int64_t *)(arg1 + 0x88) = iVar4;
                        if (iVar4 == *(int64_t *)(arg1 + 0x90)) {
                            *(undefined8 *)(arg1 + 0x90) = 0;
                            *(undefined8 *)(arg1 + 0x88) = 0;
                        }
                        *(uint32_t *)(arg1 + 0x98) = uVar3 & 0xfffffffb;
                        goto code_r0x000180173cb0;
                    }
                    uVar2 = (int32_t)uVar7 + 1;
                    uVar7 = (uint64_t)uVar2;
                    arg2 = arg2 + 1;
                } while ((int32_t)uVar2 < iVar9);
            }
        } else {
            uVar7 = (uint64_t)*(uint32_t *)(arg1 + 0x9c);
            if ((int64_t)uVar7 <= (iVar9 + arg2) - iVar5) {
                *(uint64_t *)(arg1 + 0x88) = uVar7 + iVar4;
                if (uVar7 + iVar4 == *(int64_t *)(arg1 + 0x90)) {
                    *(undefined8 *)(arg1 + 0x90) = 0;
                    *(undefined8 *)(arg1 + 0x88) = 0;
                }
                *(uint32_t *)(arg1 + 0x98) = uVar3 & 0xfffffffd;
code_r0x000180173b2f:
                *(undefined8 **)0x20 = (BADSPACEBASE *)&uStackY_30;
                uStackY_30 = 0x180173b3a;
                unaff_RBX = arg1;
                unaff_RDI = uVar6;
code_r0x000180173cb0:
                *(int64_t *)((int64_t)*(undefined **)0x20 + 8) = unaff_RBX;
                *(undefined8 *)((int64_t)*(undefined **)0x20 + 0x10) = unaff_RSI;
                *(uint64_t *)((int64_t)*(undefined **)0x20 + -8) = unaff_RDI;
                if ((*(uint32_t *)(arg1 + 0x98) & 1) != 0) {
                    *(uint32_t *)(arg1 + 0x98) = *(uint32_t *)(arg1 + 0x98) & 0xfffffffe;
                    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x180173ce5;
                    func_0x000180181d70(arg1, 1);
                }
                pcVar1 = *(code **)(arg1 + 0xf8);
                if ((pcVar1 != (code *)0x0) && ((*(uint8_t *)(arg1 + 0x3c) & 0x20) == 0)) {
                    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x180173d02;
                    (*pcVar1)(arg1, iVar5, uVar7);
                }
                uVar3 = *(uint32_t *)(arg1 + 0x3c) >> 0xe;
                uVar6 = (uint64_t)uVar3;
                if (((uVar3 & 1) != 0) && (0x10000 < *(uint64_t *)(arg1 + 0x80))) {
                    if ((uint64_t)(int64_t)(int32_t)uVar7 < *(uint64_t *)(arg1 + 0x80) >> 1) {
                        *(int32_t *)(arg1 + 0xa4) = *(int32_t *)(arg1 + 0xa4) + 1;
                        return uVar6;
                    }
                    *(undefined4 *)(arg1 + 0xa4) = 0;
                }
                return uVar6;
            }
        }
    } else {
        uStackY_30 = 0x180173a3d;
        func_0x000180184df0();
    }
    uVar7 = *(uint64_t *)(arg1 + 0x90);
    uVar8 = *(uint64_t *)(arg1 + 0x88);
    if (*(uint64_t *)(arg1 + 0x88) == *(uint64_t *)(arg1 + 0x90)) {
        *(undefined8 *)(arg1 + 0x90) = 0;
        *(undefined8 *)(arg1 + 0x88) = 0;
        uVar7 = uVar6;
        uVar8 = uVar6;
    }
    uVar6 = *(uint64_t *)(arg1 + 0x80);
    if (uVar7 != uVar6) {
        if ((uVar7 < uVar6 >> 1) && (2 < *(uint32_t *)(arg1 + 0xa4))) {
            uStackY_30 = 0x180173bae;
            uVar7 = fcn.1801735b0(arg1, uVar6 >> 1);
        }
        return uVar7;
    }
    if (uVar8 != 0) {
        uVar6 = *(uint64_t *)(arg1 + 0x88);
        uVar7 = *(uint64_t *)(arg1 + 0x90);
        if (uVar7 != uVar6) {
            if (uVar6 < uVar7) {
                *(int64_t *)0x38 = uVar7 - uVar6;
                uStackY_30 = 0x180173c50;
                func_0x000180498030(*(int64_t *)(arg1 + 0x78), *(int64_t *)(arg1 + 0x78) + uVar6, *(int64_t *)0x38);
                uVar6 = 0;
                *(int64_t *)(arg1 + 0x90) = *(int64_t *)0x38;
                *(undefined8 *)(arg1 + 0x88) = 0;
            }
            return uVar6;
        }
        *(undefined8 *)(arg1 + 0x90) = 0;
        *(undefined8 *)(arg1 + 0x88) = 0;
        return 0;
    }
    uVar3 = (int32_t)uVar6 * 2;
    if (uVar3 <= *(uint32_t *)(arg1 + 0xa0)) {
        *(int64_t *)0x18 = (int64_t)(int32_t)uVar3;
        if ((*(uint32_t *)(arg1 + 0x3c) >> 0xe & 1) == 0) {
            uVar6 = fcn.1801813b0(*(int64_t *)0x18);
        } else {
            uVar6 = fcn.180181320(*(undefined8 *)(arg1 + 0x78), *(int64_t *)0x18, *(undefined8 *)(arg1 + 0x80));
        }
        *(uint64_t *)(arg1 + 0x78) = uVar6;
        *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 0x4000;
        *(int64_t *)(arg1 + 0x80) = *(int64_t *)0x18;
        *(undefined4 *)(arg1 + 0xa4) = 0;
        return uVar6;
    }
    iVar4 = fcn.18045b9a8(0x1804a5a70, 0x5c);
    uVar3 = *(uint32_t *)(arg1 + 0xa0);
    iVar5 = fcn.1801723e0(stack0xfffffffffffffff0);
    iStackY_18 = 0x1804a5ad8;
    uStackY_20 = CONCAT44(uStackY_20._4_4_, 0x2b5);
    iStackY_28 = iVar4 + 1;
    fcn.180172b00(iVar5, 4, 0x1804a5af0, (uint64_t)uVar3);
    *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
    uStackY_48 = 0;
    uStackY_40 = 0;
    uStackY_38 = 0;
    _iStackY_18 = ZEXT816(0);
    uStackY_30 = 0x180181d50;
    uStackY_20 = (uint64_t)*(uint32_t *)(arg1 + 0x44);
    iStackY_28 = arg1;
    fcn.1801823b0(*(undefined8 *)arg1, &uStackY_48);
    return 0;
}

// ============================================================
// Function: FUN_180173c00
// Address: 0x180173c00
// Size: 107 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x000180173b35: Changing call to branch
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

uint64_t fcn.180173a20(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t unaff_RBX;
    undefined8 unaff_RSI;
    uint64_t unaff_RDI;
    int32_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStackY_48;
    undefined8 uStackY_40;
    undefined8 uStackY_38;
    undefined8 uStackY_30;
    int64_t iStackY_28;
    undefined8 uStackY_20;
    int64_t iStackY_18;
    
    uVar6 = 0;
    unique0x10000289 = iStackY_18;
    if (*(int64_t *)(arg1 + 0x178) == 0) {
        iVar4 = *(int64_t *)(arg1 + 0x88);
        uVar3 = *(uint32_t *)(arg1 + 0x98);
        iVar5 = *(int64_t *)(arg1 + 0x78) + iVar4;
        iVar9 = (int32_t)arg3;
        if ((uVar3 & 2) == 0) {
            if ((uVar3 & 4) == 0) {
                *(undefined8 *)(arg1 + 0x90) = 0;
                uVar7 = (uint64_t)(uint32_t)((int32_t)(iVar9 + arg2) - (int32_t)iVar5);
                *(undefined8 *)(arg1 + 0x88) = 0;
                goto code_r0x000180173b2f;
            }
            if (0 < iVar9) {
                uVar7 = uVar6;
                do {
                    if (*(char *)arg2 == *(char *)(arg1 + 0x9c)) {
                        uVar2 = ((int32_t)arg2 - (int32_t)iVar5) + 1;
                        uVar7 = (uint64_t)uVar2;
                        iVar4 = (int32_t)uVar2 + iVar4;
                        *(int64_t *)(arg1 + 0x88) = iVar4;
                        if (iVar4 == *(int64_t *)(arg1 + 0x90)) {
                            *(undefined8 *)(arg1 + 0x90) = 0;
                            *(undefined8 *)(arg1 + 0x88) = 0;
                        }
                        *(uint32_t *)(arg1 + 0x98) = uVar3 & 0xfffffffb;
                        goto code_r0x000180173cb0;
                    }
                    uVar2 = (int32_t)uVar7 + 1;
                    uVar7 = (uint64_t)uVar2;
                    arg2 = arg2 + 1;
                } while ((int32_t)uVar2 < iVar9);
            }
        } else {
            uVar7 = (uint64_t)*(uint32_t *)(arg1 + 0x9c);
            if ((int64_t)uVar7 <= (iVar9 + arg2) - iVar5) {
                *(uint64_t *)(arg1 + 0x88) = uVar7 + iVar4;
                if (uVar7 + iVar4 == *(int64_t *)(arg1 + 0x90)) {
                    *(undefined8 *)(arg1 + 0x90) = 0;
                    *(undefined8 *)(arg1 + 0x88) = 0;
                }
                *(uint32_t *)(arg1 + 0x98) = uVar3 & 0xfffffffd;
code_r0x000180173b2f:
                *(undefined8 **)0x20 = (BADSPACEBASE *)&uStackY_30;
                uStackY_30 = 0x180173b3a;
                unaff_RBX = arg1;
                unaff_RDI = uVar6;
code_r0x000180173cb0:
                *(int64_t *)((int64_t)*(undefined **)0x20 + 8) = unaff_RBX;
                *(undefined8 *)((int64_t)*(undefined **)0x20 + 0x10) = unaff_RSI;
                *(uint64_t *)((int64_t)*(undefined **)0x20 + -8) = unaff_RDI;
                if ((*(uint32_t *)(arg1 + 0x98) & 1) != 0) {
                    *(uint32_t *)(arg1 + 0x98) = *(uint32_t *)(arg1 + 0x98) & 0xfffffffe;
                    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x180173ce5;
                    func_0x000180181d70(arg1, 1);
                }
                pcVar1 = *(code **)(arg1 + 0xf8);
                if ((pcVar1 != (code *)0x0) && ((*(uint8_t *)(arg1 + 0x3c) & 0x20) == 0)) {
                    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x180173d02;
                    (*pcVar1)(arg1, iVar5, uVar7);
                }
                uVar3 = *(uint32_t *)(arg1 + 0x3c) >> 0xe;
                uVar6 = (uint64_t)uVar3;
                if (((uVar3 & 1) != 0) && (0x10000 < *(uint64_t *)(arg1 + 0x80))) {
                    if ((uint64_t)(int64_t)(int32_t)uVar7 < *(uint64_t *)(arg1 + 0x80) >> 1) {
                        *(int32_t *)(arg1 + 0xa4) = *(int32_t *)(arg1 + 0xa4) + 1;
                        return uVar6;
                    }
                    *(undefined4 *)(arg1 + 0xa4) = 0;
                }
                return uVar6;
            }
        }
    } else {
        uStackY_30 = 0x180173a3d;
        func_0x000180184df0();
    }
    uVar7 = *(uint64_t *)(arg1 + 0x90);
    uVar8 = *(uint64_t *)(arg1 + 0x88);
    if (*(uint64_t *)(arg1 + 0x88) == *(uint64_t *)(arg1 + 0x90)) {
        *(undefined8 *)(arg1 + 0x90) = 0;
        *(undefined8 *)(arg1 + 0x88) = 0;
        uVar7 = uVar6;
        uVar8 = uVar6;
    }
    uVar6 = *(uint64_t *)(arg1 + 0x80);
    if (uVar7 != uVar6) {
        if ((uVar7 < uVar6 >> 1) && (2 < *(uint32_t *)(arg1 + 0xa4))) {
            uStackY_30 = 0x180173bae;
            uVar7 = fcn.1801735b0(arg1, uVar6 >> 1);
        }
        return uVar7;
    }
    if (uVar8 != 0) {
        uVar6 = *(uint64_t *)(arg1 + 0x88);
        uVar7 = *(uint64_t *)(arg1 + 0x90);
        if (uVar7 != uVar6) {
            if (uVar6 < uVar7) {
                *(int64_t *)0x38 = uVar7 - uVar6;
                uStackY_30 = 0x180173c50;
                func_0x000180498030(*(int64_t *)(arg1 + 0x78), *(int64_t *)(arg1 + 0x78) + uVar6, *(int64_t *)0x38);
                uVar6 = 0;
                *(int64_t *)(arg1 + 0x90) = *(int64_t *)0x38;
                *(undefined8 *)(arg1 + 0x88) = 0;
            }
            return uVar6;
        }
        *(undefined8 *)(arg1 + 0x90) = 0;
        *(undefined8 *)(arg1 + 0x88) = 0;
        return 0;
    }
    uVar3 = (int32_t)uVar6 * 2;
    if (uVar3 <= *(uint32_t *)(arg1 + 0xa0)) {
        *(int64_t *)0x18 = (int64_t)(int32_t)uVar3;
        if ((*(uint32_t *)(arg1 + 0x3c) >> 0xe & 1) == 0) {
            uVar6 = fcn.1801813b0(*(int64_t *)0x18);
        } else {
            uVar6 = fcn.180181320(*(undefined8 *)(arg1 + 0x78), *(int64_t *)0x18, *(undefined8 *)(arg1 + 0x80));
        }
        *(uint64_t *)(arg1 + 0x78) = uVar6;
        *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 0x4000;
        *(int64_t *)(arg1 + 0x80) = *(int64_t *)0x18;
        *(undefined4 *)(arg1 + 0xa4) = 0;
        return uVar6;
    }
    iVar4 = fcn.18045b9a8(0x1804a5a70, 0x5c);
    uVar3 = *(uint32_t *)(arg1 + 0xa0);
    iVar5 = fcn.1801723e0(stack0xfffffffffffffff0);
    iStackY_18 = 0x1804a5ad8;
    uStackY_20 = CONCAT44(uStackY_20._4_4_, 0x2b5);
    iStackY_28 = iVar4 + 1;
    fcn.180172b00(iVar5, 4, 0x1804a5af0, (uint64_t)uVar3);
    *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
    uStackY_48 = 0;
    uStackY_40 = 0;
    uStackY_38 = 0;
    _iStackY_18 = ZEXT816(0);
    uStackY_30 = 0x180181d50;
    uStackY_20 = (uint64_t)*(uint32_t *)(arg1 + 0x44);
    iStackY_28 = arg1;
    fcn.1801823b0(*(undefined8 *)arg1, &uStackY_48);
    return 0;
}

// ============================================================
// Function: FUN_180173c70
// Address: 0x180173c70
// Size: 62 bytes
// ============================================================
undefined8 fcn.180173c70(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    
    iVar1 = fcn.180183180(arg2);
    if (iVar1 == 0) {
        return 0x411;
    }
    *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 0x8000;
    *(int64_t *)(arg1 + 0x188) = iVar1;
    *(undefined4 *)(arg1 + 0x40) = 0x1000000;
    return 0;
}

// ============================================================
// Function: FUN_180173cb0
// Address: 0x180173cb0
// Size: 164 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x000180173b35: Changing call to branch
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

uint64_t fcn.180173a20(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t unaff_RBX;
    undefined8 unaff_RSI;
    uint64_t unaff_RDI;
    int32_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStackY_48;
    undefined8 uStackY_40;
    undefined8 uStackY_38;
    undefined8 uStackY_30;
    int64_t iStackY_28;
    undefined8 uStackY_20;
    int64_t iStackY_18;
    
    uVar6 = 0;
    unique0x10000289 = iStackY_18;
    if (*(int64_t *)(arg1 + 0x178) == 0) {
        iVar4 = *(int64_t *)(arg1 + 0x88);
        uVar3 = *(uint32_t *)(arg1 + 0x98);
        iVar5 = *(int64_t *)(arg1 + 0x78) + iVar4;
        iVar9 = (int32_t)arg3;
        if ((uVar3 & 2) == 0) {
            if ((uVar3 & 4) == 0) {
                *(undefined8 *)(arg1 + 0x90) = 0;
                uVar7 = (uint64_t)(uint32_t)((int32_t)(iVar9 + arg2) - (int32_t)iVar5);
                *(undefined8 *)(arg1 + 0x88) = 0;
                goto code_r0x000180173b2f;
            }
            if (0 < iVar9) {
                uVar7 = uVar6;
                do {
                    if (*(char *)arg2 == *(char *)(arg1 + 0x9c)) {
                        uVar2 = ((int32_t)arg2 - (int32_t)iVar5) + 1;
                        uVar7 = (uint64_t)uVar2;
                        iVar4 = (int32_t)uVar2 + iVar4;
                        *(int64_t *)(arg1 + 0x88) = iVar4;
                        if (iVar4 == *(int64_t *)(arg1 + 0x90)) {
                            *(undefined8 *)(arg1 + 0x90) = 0;
                            *(undefined8 *)(arg1 + 0x88) = 0;
                        }
                        *(uint32_t *)(arg1 + 0x98) = uVar3 & 0xfffffffb;
                        goto code_r0x000180173cb0;
                    }
                    uVar2 = (int32_t)uVar7 + 1;
                    uVar7 = (uint64_t)uVar2;
                    arg2 = arg2 + 1;
                } while ((int32_t)uVar2 < iVar9);
            }
        } else {
            uVar7 = (uint64_t)*(uint32_t *)(arg1 + 0x9c);
            if ((int64_t)uVar7 <= (iVar9 + arg2) - iVar5) {
                *(uint64_t *)(arg1 + 0x88) = uVar7 + iVar4;
                if (uVar7 + iVar4 == *(int64_t *)(arg1 + 0x90)) {
                    *(undefined8 *)(arg1 + 0x90) = 0;
                    *(undefined8 *)(arg1 + 0x88) = 0;
                }
                *(uint32_t *)(arg1 + 0x98) = uVar3 & 0xfffffffd;
code_r0x000180173b2f:
                *(undefined8 **)0x20 = (BADSPACEBASE *)&uStackY_30;
                uStackY_30 = 0x180173b3a;
                unaff_RBX = arg1;
                unaff_RDI = uVar6;
code_r0x000180173cb0:
                *(int64_t *)((int64_t)*(undefined **)0x20 + 8) = unaff_RBX;
                *(undefined8 *)((int64_t)*(undefined **)0x20 + 0x10) = unaff_RSI;
                *(uint64_t *)((int64_t)*(undefined **)0x20 + -8) = unaff_RDI;
                if ((*(uint32_t *)(arg1 + 0x98) & 1) != 0) {
                    *(uint32_t *)(arg1 + 0x98) = *(uint32_t *)(arg1 + 0x98) & 0xfffffffe;
                    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x180173ce5;
                    func_0x000180181d70(arg1, 1);
                }
                pcVar1 = *(code **)(arg1 + 0xf8);
                if ((pcVar1 != (code *)0x0) && ((*(uint8_t *)(arg1 + 0x3c) & 0x20) == 0)) {
                    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x180173d02;
                    (*pcVar1)(arg1, iVar5, uVar7);
                }
                uVar3 = *(uint32_t *)(arg1 + 0x3c) >> 0xe;
                uVar6 = (uint64_t)uVar3;
                if (((uVar3 & 1) != 0) && (0x10000 < *(uint64_t *)(arg1 + 0x80))) {
                    if ((uint64_t)(int64_t)(int32_t)uVar7 < *(uint64_t *)(arg1 + 0x80) >> 1) {
                        *(int32_t *)(arg1 + 0xa4) = *(int32_t *)(arg1 + 0xa4) + 1;
                        return uVar6;
                    }
                    *(undefined4 *)(arg1 + 0xa4) = 0;
                }
                return uVar6;
            }
        }
    } else {
        uStackY_30 = 0x180173a3d;
        func_0x000180184df0();
    }
    uVar7 = *(uint64_t *)(arg1 + 0x90);
    uVar8 = *(uint64_t *)(arg1 + 0x88);
    if (*(uint64_t *)(arg1 + 0x88) == *(uint64_t *)(arg1 + 0x90)) {
        *(undefined8 *)(arg1 + 0x90) = 0;
        *(undefined8 *)(arg1 + 0x88) = 0;
        uVar7 = uVar6;
        uVar8 = uVar6;
    }
    uVar6 = *(uint64_t *)(arg1 + 0x80);
    if (uVar7 != uVar6) {
        if ((uVar7 < uVar6 >> 1) && (2 < *(uint32_t *)(arg1 + 0xa4))) {
            uStackY_30 = 0x180173bae;
            uVar7 = fcn.1801735b0(arg1, uVar6 >> 1);
        }
        return uVar7;
    }
    if (uVar8 != 0) {
        uVar6 = *(uint64_t *)(arg1 + 0x88);
        uVar7 = *(uint64_t *)(arg1 + 0x90);
        if (uVar7 != uVar6) {
            if (uVar6 < uVar7) {
                *(int64_t *)0x38 = uVar7 - uVar6;
                uStackY_30 = 0x180173c50;
                func_0x000180498030(*(int64_t *)(arg1 + 0x78), *(int64_t *)(arg1 + 0x78) + uVar6, *(int64_t *)0x38);
                uVar6 = 0;
                *(int64_t *)(arg1 + 0x90) = *(int64_t *)0x38;
                *(undefined8 *)(arg1 + 0x88) = 0;
            }
            return uVar6;
        }
        *(undefined8 *)(arg1 + 0x90) = 0;
        *(undefined8 *)(arg1 + 0x88) = 0;
        return 0;
    }
    uVar3 = (int32_t)uVar6 * 2;
    if (uVar3 <= *(uint32_t *)(arg1 + 0xa0)) {
        *(int64_t *)0x18 = (int64_t)(int32_t)uVar3;
        if ((*(uint32_t *)(arg1 + 0x3c) >> 0xe & 1) == 0) {
            uVar6 = fcn.1801813b0(*(int64_t *)0x18);
        } else {
            uVar6 = fcn.180181320(*(undefined8 *)(arg1 + 0x78), *(int64_t *)0x18, *(undefined8 *)(arg1 + 0x80));
        }
        *(uint64_t *)(arg1 + 0x78) = uVar6;
        *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 0x4000;
        *(int64_t *)(arg1 + 0x80) = *(int64_t *)0x18;
        *(undefined4 *)(arg1 + 0xa4) = 0;
        return uVar6;
    }
    iVar4 = fcn.18045b9a8(0x1804a5a70, 0x5c);
    uVar3 = *(uint32_t *)(arg1 + 0xa0);
    iVar5 = fcn.1801723e0(stack0xfffffffffffffff0);
    iStackY_18 = 0x1804a5ad8;
    uStackY_20 = CONCAT44(uStackY_20._4_4_, 0x2b5);
    iStackY_28 = iVar4 + 1;
    fcn.180172b00(iVar5, 4, 0x1804a5af0, (uint64_t)uVar3);
    *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
    uStackY_48 = 0;
    uStackY_40 = 0;
    uStackY_38 = 0;
    _iStackY_18 = ZEXT816(0);
    uStackY_30 = 0x180181d50;
    uStackY_20 = (uint64_t)*(uint32_t *)(arg1 + 0x44);
    iStackY_28 = arg1;
    fcn.1801823b0(*(undefined8 *)arg1, &uStackY_48);
    return 0;
}

// ============================================================
// Function: FUN_180173d60
// Address: 0x180173d60
// Size: 65 bytes
// ============================================================
int32_t fcn.180173d60(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    
    iVar2 = *(int32_t *)(arg1 + 0x90) - *(int32_t *)(arg1 + 0x88);
    if (0 < iVar2) {
        iVar1 = *(int64_t *)(arg1 + 0x88);
        *(undefined8 *)(arg1 + 0x90) = 0;
        *(undefined8 *)(arg1 + 0x88) = 0;
        fcn.180173cb0(arg1, iVar1 + *(int64_t *)(arg1 + 0x78), iVar2);
    }
    return iVar2;
}

// ============================================================
// Function: FUN_180173db0
// Address: 0x180173db0
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180173db0(int64_t arg1, int64_t arg_58h)
{
    int64_t iVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t var_8h;
    undefined4 auStackX_10 [2];
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_28h;
    int64_t var_10h;
    
    if ((*(uint32_t *)(arg1 + 0x3c) & 8) != 0) {
        return;
    }
    *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xffffc00f | 8;
    *(int32_t *)0x18077e0bc = *(int32_t *)0x18077e0bc + 1;
    iVar1 = *(int64_t *)arg1;
    *(int32_t *)(arg1 + 0x44) = *(int32_t *)0x18077e0bc;
    *(undefined4 *)(arg1 + 0x40) = 0;
    *(undefined8 *)(arg1 + 0x4c) = 0;
    *(undefined4 *)(arg1 + 0x54) = 0;
    uVar3 = *(undefined8 *)(iVar1 + 0x20);
    *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xffffbfff;
    *(undefined8 *)(arg1 + 0x70) = uVar3;
    *(undefined8 *)(arg1 + 0x68) = uVar3;
    if (*(int64_t *)(iVar1 + 0x140) == 0) {
        *(undefined8 *)(iVar1 + 0x140) = 0x2000;
        uVar3 = fcn.1801813b0(0x2000);
        *(undefined8 *)(iVar1 + 0x138) = uVar3;
    }
    *(undefined8 *)(arg1 + 0x78) = *(undefined8 *)(iVar1 + 0x138);
    uVar3 = *(undefined8 *)(iVar1 + 0x140);
    *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xffff7fff;
    *(undefined8 *)(arg1 + 0x80) = uVar3;
    *(undefined8 *)(arg1 + 0x90) = 0;
    *(undefined8 *)(arg1 + 0x88) = 0;
    *(undefined8 *)(arg1 + 0x98) = 0;
    *(undefined8 *)(arg1 + 0xa0) = 0x1000000;
    *(undefined4 *)(arg1 + 0xf0) = 0;
    *(undefined4 *)(arg1 + 0xf4) = 0x1000000;
    *(undefined8 *)(arg1 + 0xf8) = 0;
    *(undefined8 *)(arg1 + 0x100) = 0;
    *(undefined8 *)(arg1 + 0x108) = 0;
    *(undefined8 *)(arg1 + 0x110) = 0;
    *(undefined8 *)(arg1 + 0x118) = 0;
    *(undefined8 *)(arg1 + 0x120) = 0;
    *(undefined8 *)(arg1 + 0x140) = 0;
    *(undefined8 *)(arg1 + 0x148) = 0;
    *(undefined8 *)(arg1 + 0x128) = 0;
    *(undefined8 *)(arg1 + 0x150) = 0;
    *(undefined8 *)(arg1 + 0x158) = 0;
    *(undefined8 *)(arg1 + 0x130) = 0;
    *(undefined8 *)(arg1 + 0x160) = 0;
    *(undefined8 *)(arg1 + 0x138) = 0;
    *(undefined8 *)(arg1 + 0x168) = 0;
    *(undefined8 *)(arg1 + 0x170) = 0;
    *(undefined8 *)(arg1 + 0x178) = 0;
    *(undefined8 *)(arg1 + 0x180) = 0;
    *(undefined8 *)(arg1 + 0x188) = 0;
    *(undefined8 *)(arg1 + 400) = 0;
    *(undefined8 *)(arg1 + 0x198) = 0;
    var_8h._0_4_ = 0;
    auStackX_10[0] = 4;
    iVar2 = (*(code *)0x8000000000000007)((int64_t)*(int32_t *)(arg1 + 0x48), 0xffff, 0x1008, &var_8h, auStackX_10);
    if (iVar2 == 0) {
        if ((int32_t)var_8h != 1) {
            if ((int32_t)var_8h == 2) {
                *(undefined4 *)(arg1 + 0x40) = 0x1000;
            } else if ((int32_t)var_8h == 3) {
                *(undefined4 *)(arg1 + 0x40) = 0x100;
            } else {
                *(undefined4 *)(arg1 + 0x40) = 0xfffff00;
            }
            goto code_r0x000180173fe9;
        }
    } else {
        iVar2 = (*(code *)0x800000000000006f)();
        if (iVar2 == 0x2736) {
            iVar2 = *(int32_t *)(arg1 + 0x48);
            if (iVar2 == 0) {
                *(undefined4 *)(arg1 + 0x40) = 1;
                return;
            }
            if (iVar2 == 1) {
                *(undefined4 *)(arg1 + 0x40) = 2;
                return;
            }
            if (iVar2 == 2) {
                *(undefined4 *)(arg1 + 0x40) = 4;
                return;
            }
            *(undefined4 *)(arg1 + 0x40) = 0x10;
            return;
        }
    }
    *(undefined4 *)(arg1 + 0x40) = 0x100000;
code_r0x000180173fe9:
    auStackX_10[0] = 1;
    (*(code *)0x800000000000000a)((int64_t)*(int32_t *)(arg1 + 0x48), 0x8004667e, auStackX_10);
    if (*(int64_t *)(arg1 + 0x58) == 0) {
        uVar3 = fcn.1801813b0(0x1c);
        *(undefined8 *)(arg1 + 0x58) = uVar3;
    }
    if (*(int64_t *)(arg1 + 0x60) == 0) {
        uVar3 = fcn.1801813b0(0x1c);
        *(undefined8 *)(arg1 + 0x60) = uVar3;
    }
    var_8h._0_4_ = 0x1c;
    (*(code *)0x8000000000000006)((int64_t)*(int32_t *)(arg1 + 0x48), *(undefined8 *)(arg1 + 0x58), &var_8h);
    if ((*(uint32_t *)(arg1 + 0x40) & 0xff00000) != 0) {
        var_8h._0_4_ = 0x1c;
        (*(code *)0x8000000000000005)((int64_t)*(int32_t *)(arg1 + 0x48), *(undefined8 *)(arg1 + 0x60), &var_8h);
    }
    return;
}

// ============================================================
// Function: FUN_180173dc9
// Address: 0x180173dc9
// Size: 409 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180173db0(int64_t arg1, int64_t arg_58h)
{
    int64_t iVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t var_8h;
    undefined4 auStackX_10 [2];
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_28h;
    int64_t var_10h;
    
    if ((*(uint32_t *)(arg1 + 0x3c) & 8) != 0) {
        return;
    }
    *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xffffc00f | 8;
    *(int32_t *)0x18077e0bc = *(int32_t *)0x18077e0bc + 1;
    iVar1 = *(int64_t *)arg1;
    *(int32_t *)(arg1 + 0x44) = *(int32_t *)0x18077e0bc;
    *(undefined4 *)(arg1 + 0x40) = 0;
    *(undefined8 *)(arg1 + 0x4c) = 0;
    *(undefined4 *)(arg1 + 0x54) = 0;
    uVar3 = *(undefined8 *)(iVar1 + 0x20);
    *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xffffbfff;
    *(undefined8 *)(arg1 + 0x70) = uVar3;
    *(undefined8 *)(arg1 + 0x68) = uVar3;
    if (*(int64_t *)(iVar1 + 0x140) == 0) {
        *(undefined8 *)(iVar1 + 0x140) = 0x2000;
        uVar3 = fcn.1801813b0(0x2000);
        *(undefined8 *)(iVar1 + 0x138) = uVar3;
    }
    *(undefined8 *)(arg1 + 0x78) = *(undefined8 *)(iVar1 + 0x138);
    uVar3 = *(undefined8 *)(iVar1 + 0x140);
    *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xffff7fff;
    *(undefined8 *)(arg1 + 0x80) = uVar3;
    *(undefined8 *)(arg1 + 0x90) = 0;
    *(undefined8 *)(arg1 + 0x88) = 0;
    *(undefined8 *)(arg1 + 0x98) = 0;
    *(undefined8 *)(arg1 + 0xa0) = 0x1000000;
    *(undefined4 *)(arg1 + 0xf0) = 0;
    *(undefined4 *)(arg1 + 0xf4) = 0x1000000;
    *(undefined8 *)(arg1 + 0xf8) = 0;
    *(undefined8 *)(arg1 + 0x100) = 0;
    *(undefined8 *)(arg1 + 0x108) = 0;
    *(undefined8 *)(arg1 + 0x110) = 0;
    *(undefined8 *)(arg1 + 0x118) = 0;
    *(undefined8 *)(arg1 + 0x120) = 0;
    *(undefined8 *)(arg1 + 0x140) = 0;
    *(undefined8 *)(arg1 + 0x148) = 0;
    *(undefined8 *)(arg1 + 0x128) = 0;
    *(undefined8 *)(arg1 + 0x150) = 0;
    *(undefined8 *)(arg1 + 0x158) = 0;
    *(undefined8 *)(arg1 + 0x130) = 0;
    *(undefined8 *)(arg1 + 0x160) = 0;
    *(undefined8 *)(arg1 + 0x138) = 0;
    *(undefined8 *)(arg1 + 0x168) = 0;
    *(undefined8 *)(arg1 + 0x170) = 0;
    *(undefined8 *)(arg1 + 0x178) = 0;
    *(undefined8 *)(arg1 + 0x180) = 0;
    *(undefined8 *)(arg1 + 0x188) = 0;
    *(undefined8 *)(arg1 + 400) = 0;
    *(undefined8 *)(arg1 + 0x198) = 0;
    var_8h._0_4_ = 0;
    auStackX_10[0] = 4;
    iVar2 = (*(code *)0x8000000000000007)((int64_t)*(int32_t *)(arg1 + 0x48), 0xffff, 0x1008, &var_8h, auStackX_10);
    if (iVar2 == 0) {
        if ((int32_t)var_8h != 1) {
            if ((int32_t)var_8h == 2) {
                *(undefined4 *)(arg1 + 0x40) = 0x1000;
            } else if ((int32_t)var_8h == 3) {
                *(undefined4 *)(arg1 + 0x40) = 0x100;
            } else {
                *(undefined4 *)(arg1 + 0x40) = 0xfffff00;
            }
            goto code_r0x000180173fe9;
        }
    } else {
        iVar2 = (*(code *)0x800000000000006f)();
        if (iVar2 == 0x2736) {
            iVar2 = *(int32_t *)(arg1 + 0x48);
            if (iVar2 == 0) {
                *(undefined4 *)(arg1 + 0x40) = 1;
                return;
            }
            if (iVar2 == 1) {
                *(undefined4 *)(arg1 + 0x40) = 2;
                return;
            }
            if (iVar2 == 2) {
                *(undefined4 *)(arg1 + 0x40) = 4;
                return;
            }
            *(undefined4 *)(arg1 + 0x40) = 0x10;
            return;
        }
    }
    *(undefined4 *)(arg1 + 0x40) = 0x100000;
code_r0x000180173fe9:
    auStackX_10[0] = 1;
    (*(code *)0x800000000000000a)((int64_t)*(int32_t *)(arg1 + 0x48), 0x8004667e, auStackX_10);
    if (*(int64_t *)(arg1 + 0x58) == 0) {
        uVar3 = fcn.1801813b0(0x1c);
        *(undefined8 *)(arg1 + 0x58) = uVar3;
    }
    if (*(int64_t *)(arg1 + 0x60) == 0) {
        uVar3 = fcn.1801813b0(0x1c);
        *(undefined8 *)(arg1 + 0x60) = uVar3;
    }
    var_8h._0_4_ = 0x1c;
    (*(code *)0x8000000000000006)((int64_t)*(int32_t *)(arg1 + 0x48), *(undefined8 *)(arg1 + 0x58), &var_8h);
    if ((*(uint32_t *)(arg1 + 0x40) & 0xff00000) != 0) {
        var_8h._0_4_ = 0x1c;
        (*(code *)0x8000000000000005)((int64_t)*(int32_t *)(arg1 + 0x48), *(undefined8 *)(arg1 + 0x60), &var_8h);
    }
    return;
}

// ============================================================
// Function: FUN_180173f62
// Address: 0x180173f62
// Size: 274 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180173db0(int64_t arg1, int64_t arg_58h)
{
    int64_t iVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t var_8h;
    undefined4 auStackX_10 [2];
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_28h;
    int64_t var_10h;
    
    if ((*(uint32_t *)(arg1 + 0x3c) & 8) != 0) {
        return;
    }
    *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xffffc00f | 8;
    *(int32_t *)0x18077e0bc = *(int32_t *)0x18077e0bc + 1;
    iVar1 = *(int64_t *)arg1;
    *(int32_t *)(arg1 + 0x44) = *(int32_t *)0x18077e0bc;
    *(undefined4 *)(arg1 + 0x40) = 0;
    *(undefined8 *)(arg1 + 0x4c) = 0;
    *(undefined4 *)(arg1 + 0x54) = 0;
    uVar3 = *(undefined8 *)(iVar1 + 0x20);
    *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xffffbfff;
    *(undefined8 *)(arg1 + 0x70) = uVar3;
    *(undefined8 *)(arg1 + 0x68) = uVar3;
    if (*(int64_t *)(iVar1 + 0x140) == 0) {
        *(undefined8 *)(iVar1 + 0x140) = 0x2000;
        uVar3 = fcn.1801813b0(0x2000);
        *(undefined8 *)(iVar1 + 0x138) = uVar3;
    }
    *(undefined8 *)(arg1 + 0x78) = *(undefined8 *)(iVar1 + 0x138);
    uVar3 = *(undefined8 *)(iVar1 + 0x140);
    *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xffff7fff;
    *(undefined8 *)(arg1 + 0x80) = uVar3;
    *(undefined8 *)(arg1 + 0x90) = 0;
    *(undefined8 *)(arg1 + 0x88) = 0;
    *(undefined8 *)(arg1 + 0x98) = 0;
    *(undefined8 *)(arg1 + 0xa0) = 0x1000000;
    *(undefined4 *)(arg1 + 0xf0) = 0;
    *(undefined4 *)(arg1 + 0xf4) = 0x1000000;
    *(undefined8 *)(arg1 + 0xf8) = 0;
    *(undefined8 *)(arg1 + 0x100) = 0;
    *(undefined8 *)(arg1 + 0x108) = 0;
    *(undefined8 *)(arg1 + 0x110) = 0;
    *(undefined8 *)(arg1 + 0x118) = 0;
    *(undefined8 *)(arg1 + 0x120) = 0;
    *(undefined8 *)(arg1 + 0x140) = 0;
    *(undefined8 *)(arg1 + 0x148) = 0;
    *(undefined8 *)(arg1 + 0x128) = 0;
    *(undefined8 *)(arg1 + 0x150) = 0;
    *(undefined8 *)(arg1 + 0x158) = 0;
    *(undefined8 *)(arg1 + 0x130) = 0;
    *(undefined8 *)(arg1 + 0x160) = 0;
    *(undefined8 *)(arg1 + 0x138) = 0;
    *(undefined8 *)(arg1 + 0x168) = 0;
    *(undefined8 *)(arg1 + 0x170) = 0;
    *(undefined8 *)(arg1 + 0x178) = 0;
    *(undefined8 *)(arg1 + 0x180) = 0;
    *(undefined8 *)(arg1 + 0x188) = 0;
    *(undefined8 *)(arg1 + 400) = 0;
    *(undefined8 *)(arg1 + 0x198) = 0;
    var_8h._0_4_ = 0;
    auStackX_10[0] = 4;
    iVar2 = (*(code *)0x8000000000000007)((int64_t)*(int32_t *)(arg1 + 0x48), 0xffff, 0x1008, &var_8h, auStackX_10);
    if (iVar2 == 0) {
        if ((int32_t)var_8h != 1) {
            if ((int32_t)var_8h == 2) {
                *(undefined4 *)(arg1 + 0x40) = 0x1000;
            } else if ((int32_t)var_8h == 3) {
                *(undefined4 *)(arg1 + 0x40) = 0x100;
            } else {
                *(undefined4 *)(arg1 + 0x40) = 0xfffff00;
            }
            goto code_r0x000180173fe9;
        }
    } else {
        iVar2 = (*(code *)0x800000000000006f)();
        if (iVar2 == 0x2736) {
            iVar2 = *(int32_t *)(arg1 + 0x48);
            if (iVar2 == 0) {
                *(undefined4 *)(arg1 + 0x40) = 1;
                return;
            }
            if (iVar2 == 1) {
                *(undefined4 *)(arg1 + 0x40) = 2;
                return;
            }
            if (iVar2 == 2) {
                *(undefined4 *)(arg1 + 0x40) = 4;
                return;
            }
            *(undefined4 *)(arg1 + 0x40) = 0x10;
            return;
        }
    }
    *(undefined4 *)(arg1 + 0x40) = 0x100000;
code_r0x000180173fe9:
    auStackX_10[0] = 1;
    (*(code *)0x800000000000000a)((int64_t)*(int32_t *)(arg1 + 0x48), 0x8004667e, auStackX_10);
    if (*(int64_t *)(arg1 + 0x58) == 0) {
        uVar3 = fcn.1801813b0(0x1c);
        *(undefined8 *)(arg1 + 0x58) = uVar3;
    }
    if (*(int64_t *)(arg1 + 0x60) == 0) {
        uVar3 = fcn.1801813b0(0x1c);
        *(undefined8 *)(arg1 + 0x60) = uVar3;
    }
    var_8h._0_4_ = 0x1c;
    (*(code *)0x8000000000000006)((int64_t)*(int32_t *)(arg1 + 0x48), *(undefined8 *)(arg1 + 0x58), &var_8h);
    if ((*(uint32_t *)(arg1 + 0x40) & 0xff00000) != 0) {
        var_8h._0_4_ = 0x1c;
        (*(code *)0x8000000000000005)((int64_t)*(int32_t *)(arg1 + 0x48), *(undefined8 *)(arg1 + 0x60), &var_8h);
    }
    return;
}

// ============================================================
// Function: FUN_1801740a0
// Address: 0x1801740a0
// Size: 158 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801740a0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t var_8h;
    int64_t var_10h;
    
    if ((int32_t)arg2 < 1) {
        if (*(int64_t *)(arg1 + 0x168) != 0) {
            fcn.180182cf0();
            *(undefined8 *)(arg1 + 0x168) = 0;
            *(undefined4 *)(arg1 + 0x134) = 0;
            *(undefined8 *)(arg1 + 0x138) = 0;
            return;
        }
    } else {
        if (*(int64_t *)(arg1 + 0x168) == 0) {
            iVar1 = fcn.180182c00(*(undefined8 *)arg1, 0x180173580, arg2 & 0xffffffff, 0xffffffff);
            *(int64_t *)(arg1 + 0x168) = iVar1;
            *(int64_t *)(iVar1 + 0x28) = arg1;
        } else {
            fcn.180182d70();
        }
        *(int32_t *)(arg1 + 0x134) = (int32_t)arg2;
        *(int64_t *)(arg1 + 0x138) = arg3;
    }
    return;
}

// ============================================================
// Function: FUN_180174140
// Address: 0x180174140
// Size: 72 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180174140(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int64_t var_8h;
    
    if (*(int64_t *)(arg1 + 400) != 0) {
        fcn.180460d90();
        *(undefined8 *)(arg1 + 400) = 0;
    }
    uVar1 = fcn.180476480(arg2);
    *(undefined8 *)(arg1 + 400) = uVar1;
    return 0;
}

// ============================================================
// Function: FUN_180174190
// Address: 0x180174190
// Size: 76 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180174190(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined auVar1 [16];
    undefined auVar2 [16];
    undefined uVar3;
    undefined2 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    undefined4 uVar18;
    undefined4 uVar19;
    undefined (*pauVar20) [32];
    undefined (*pauVar21) [32];
    undefined (*pauVar22) [32];
    undefined4 *puVar23;
    undefined (*pauVar24) [16];
    undefined (*pauVar25) [16];
    undefined (*pauVar26) [32];
    undefined (*pauVar27) [32];
    undefined4 *puVar28;
    uint64_t uVar29;
    int64_t iVar30;
    uint64_t uVar31;
    undefined auVar32 [16];
    undefined auVar33 [32];
    undefined auVar34 [32];
    undefined auVar35 [32];
    undefined auVar36 [32];
    undefined auVar37 [32];
    undefined auVar38 [32];
    int64_t var_8h;
    int64_t var_10h;
    
    pauVar20 = *(undefined (**) [32])(arg1 + 0x60);
    uVar29 = (uint64_t)(int32_t)arg3;
    if (pauVar20 == (undefined (*) [32])0x0) {
        pauVar20 = (undefined (*) [32])fcn.1801813b0(0x1c);
        *(undefined (**) [32])(arg1 + 0x60) = pauVar20;
    }
    // switch table (16 cases) at 0x180650960
    switch(uVar29) {
    case 0:
        return;
    case 1:
        (*pauVar20)[0] = *(undefined *)arg2;
        return;
    case 2:
        *(undefined2 *)*pauVar20 = *(undefined2 *)arg2;
        return;
    case 3:
        uVar3 = *(undefined *)(arg2 + 2);
        *(undefined2 *)*pauVar20 = *(undefined2 *)arg2;
        (*pauVar20)[2] = uVar3;
        return;
    case 4:
        *(undefined4 *)*pauVar20 = *(undefined4 *)arg2;
        return;
    case 5:
        uVar3 = *(undefined *)(arg2 + 4);
        *(undefined4 *)*pauVar20 = *(undefined4 *)arg2;
        (*pauVar20)[4] = uVar3;
        return;
    case 6:
        uVar4 = *(undefined2 *)(arg2 + 4);
        *(undefined4 *)*pauVar20 = *(undefined4 *)arg2;
        *(undefined2 *)(*pauVar20 + 4) = uVar4;
        return;
    case 7:
        uVar4 = *(undefined2 *)(arg2 + 4);
        uVar3 = *(undefined *)(arg2 + 6);
        *(undefined4 *)*pauVar20 = *(undefined4 *)arg2;
        *(undefined2 *)(*pauVar20 + 4) = uVar4;
        (*pauVar20)[6] = uVar3;
        return;
    case 8:
        *(undefined8 *)*pauVar20 = *(undefined8 *)arg2;
        return;
    case 9:
        uVar3 = *(undefined *)(arg2 + 8);
        *(undefined8 *)*pauVar20 = *(undefined8 *)arg2;
        (*pauVar20)[8] = uVar3;
        return;
    case 10:
        uVar4 = *(undefined2 *)(arg2 + 8);
        *(undefined8 *)*pauVar20 = *(undefined8 *)arg2;
        *(undefined2 *)(*pauVar20 + 8) = uVar4;
        return;
    case 0xb:
        uVar4 = *(undefined2 *)(arg2 + 8);
        uVar3 = *(undefined *)(arg2 + 10);
        *(undefined8 *)*pauVar20 = *(undefined8 *)arg2;
        *(undefined2 *)(*pauVar20 + 8) = uVar4;
        (*pauVar20)[10] = uVar3;
        return;
    case 0xc:
        uVar5 = *(undefined4 *)(arg2 + 8);
        *(undefined8 *)*pauVar20 = *(undefined8 *)arg2;
        *(undefined4 *)(*pauVar20 + 8) = uVar5;
        return;
    case 0xd:
        uVar5 = *(undefined4 *)(arg2 + 8);
        uVar3 = *(undefined *)(arg2 + 0xc);
        *(undefined8 *)*pauVar20 = *(undefined8 *)arg2;
        *(undefined4 *)(*pauVar20 + 8) = uVar5;
        (*pauVar20)[0xc] = uVar3;
        return;
    case 0xe:
        uVar5 = *(undefined4 *)(arg2 + 8);
        uVar4 = *(undefined2 *)(arg2 + 0xc);
        *(undefined8 *)*pauVar20 = *(undefined8 *)arg2;
        *(undefined4 *)(*pauVar20 + 8) = uVar5;
        *(undefined2 *)(*pauVar20 + 0xc) = uVar4;
        return;
    case 0xf:
        uVar5 = *(undefined4 *)(arg2 + 8);
        uVar4 = *(undefined2 *)(arg2 + 0xc);
        uVar3 = *(undefined *)(arg2 + 0xe);
        *(undefined8 *)*pauVar20 = *(undefined8 *)arg2;
        *(undefined4 *)(*pauVar20 + 8) = uVar5;
        *(undefined2 *)(*pauVar20 + 0xc) = uVar4;
        (*pauVar20)[0xe] = uVar3;
        return;
    }
    if (uVar29 < 0x21) {
        uVar5 = *(undefined4 *)(arg2 + 4);
        uVar6 = *(undefined4 *)(arg2 + 8);
        uVar7 = *(undefined4 *)(arg2 + 0xc);
        puVar23 = (undefined4 *)(arg2 + -0x10 + uVar29);
        uVar8 = *puVar23;
        uVar9 = puVar23[1];
        uVar10 = puVar23[2];
        uVar11 = puVar23[3];
        *(undefined4 *)*pauVar20 = *(undefined4 *)arg2;
        *(undefined4 *)(*pauVar20 + 4) = uVar5;
        *(undefined4 *)(*pauVar20 + 8) = uVar6;
        *(undefined4 *)(*pauVar20 + 0xc) = uVar7;
        puVar23 = (undefined4 *)(pauVar20[-1] + uVar29 + 0x10);
        *puVar23 = uVar8;
        puVar23[1] = uVar9;
        puVar23[2] = uVar10;
        puVar23[3] = uVar11;
        return;
    }
    pauVar21 = (undefined (*) [32])(arg2 + uVar29);
    if (pauVar20 <= (uint64_t)arg2) {
        pauVar21 = pauVar20;
    }
    if (pauVar20 < pauVar21) {
        uVar5 = *(undefined4 *)arg2;
        uVar6 = *(undefined4 *)(arg2 + 4);
        uVar7 = *(undefined4 *)(arg2 + 8);
        uVar8 = *(undefined4 *)(arg2 + 0xc);
        arg2 = arg2 - (int64_t)pauVar20;
        auVar1 = *(undefined (*) [16])((int64_t)pauVar20 + arg2 + (uVar29 - 0x10));
        pauVar25 = (undefined (*) [16])(pauVar20[-1] + uVar29 + 0x10);
        uVar29 = uVar29 - 0x10;
        pauVar24 = pauVar25;
        auVar32 = auVar1;
        if (((uint64_t)pauVar25 & 0xf) != 0) {
            pauVar24 = (undefined (*) [16])((uint64_t)pauVar25 & 0xfffffffffffffff0);
            auVar32 = *(undefined (*) [16])((int64_t)pauVar24 + arg2);
            *pauVar25 = auVar1;
            uVar29 = (int64_t)pauVar24 - (int64_t)pauVar20;
        }
        uVar31 = uVar29 >> 7;
        if (uVar31 != 0) {
            *pauVar24 = auVar32;
            pauVar25 = pauVar24;
            while( true ) {
                puVar23 = (undefined4 *)((int64_t)pauVar25 + arg2 + -0x10);
                uVar9 = puVar23[1];
                uVar10 = puVar23[2];
                uVar11 = puVar23[3];
                puVar28 = (undefined4 *)((int64_t)pauVar25 + arg2 + -0x20);
                uVar12 = *puVar28;
                uVar13 = puVar28[1];
                uVar14 = puVar28[2];
                uVar15 = puVar28[3];
                pauVar24 = pauVar25 + -8;
                *(undefined4 *)pauVar25[-1] = *puVar23;
                *(undefined4 *)(pauVar25[-1] + 4) = uVar9;
                *(undefined4 *)(pauVar25[-1] + 8) = uVar10;
                *(undefined4 *)(pauVar25[-1] + 0xc) = uVar11;
                *(undefined4 *)pauVar25[-2] = uVar12;
                *(undefined4 *)(pauVar25[-2] + 4) = uVar13;
                *(undefined4 *)(pauVar25[-2] + 8) = uVar14;
                *(undefined4 *)(pauVar25[-2] + 0xc) = uVar15;
                puVar23 = (undefined4 *)((int64_t)pauVar25 + arg2 + -0x30);
                uVar9 = puVar23[1];
                uVar10 = puVar23[2];
                uVar11 = puVar23[3];
                puVar28 = (undefined4 *)((int64_t)pauVar25 + arg2 + -0x40);
                uVar12 = *puVar28;
                uVar13 = puVar28[1];
                uVar14 = puVar28[2];
                uVar15 = puVar28[3];
                uVar31 = uVar31 - 1;
                *(undefined4 *)pauVar25[-3] = *puVar23;
                *(undefined4 *)(pauVar25[-3] + 4) = uVar9;
                *(undefined4 *)(pauVar25[-3] + 8) = uVar10;
                *(undefined4 *)(pauVar25[-3] + 0xc) = uVar11;
                *(undefined4 *)pauVar25[-4] = uVar12;
                *(undefined4 *)(pauVar25[-4] + 4) = uVar13;
                *(undefined4 *)(pauVar25[-4] + 8) = uVar14;
                *(undefined4 *)(pauVar25[-4] + 0xc) = uVar15;
                puVar23 = (undefined4 *)((int64_t)pauVar25 + arg2 + -0x50);
                uVar9 = puVar23[1];
                uVar10 = puVar23[2];
                uVar11 = puVar23[3];
                puVar28 = (undefined4 *)((int64_t)pauVar25 + arg2 + -0x60);
                uVar12 = *puVar28;
                uVar13 = puVar28[1];
                uVar14 = puVar28[2];
                uVar15 = puVar28[3];
                *(undefined4 *)pauVar25[-5] = *puVar23;
                *(undefined4 *)(pauVar25[-5] + 4) = uVar9;
                *(undefined4 *)(pauVar25[-5] + 8) = uVar10;
                *(undefined4 *)(pauVar25[-5] + 0xc) = uVar11;
                *(undefined4 *)pauVar25[-6] = uVar12;
                *(undefined4 *)(pauVar25[-6] + 4) = uVar13;
                *(undefined4 *)(pauVar25[-6] + 8) = uVar14;
                *(undefined4 *)(pauVar25[-6] + 0xc) = uVar15;
                puVar23 = (undefined4 *)((int64_t)pauVar25 + arg2 + -0x70);
                uVar9 = puVar23[1];
                uVar10 = puVar23[2];
                uVar11 = puVar23[3];
                auVar32 = *(undefined (*) [16])((int64_t)pauVar24 + arg2);
                if (uVar31 == 0) break;
                *(undefined4 *)pauVar25[-7] = *puVar23;
                *(undefined4 *)(pauVar25[-7] + 4) = uVar9;
                *(undefined4 *)(pauVar25[-7] + 8) = uVar10;
                *(undefined4 *)(pauVar25[-7] + 0xc) = uVar11;
                *pauVar24 = auVar32;
                pauVar25 = pauVar24;
            }
            *(undefined4 *)pauVar25[-7] = *puVar23;
            *(undefined4 *)(pauVar25[-7] + 4) = uVar9;
            *(undefined4 *)(pauVar25[-7] + 8) = uVar10;
            *(undefined4 *)(pauVar25[-7] + 0xc) = uVar11;
            uVar29 = uVar29 & 0x7f;
        }
        for (uVar31 = uVar29 >> 4; uVar31 != 0; uVar31 = uVar31 - 1) {
            *pauVar24 = auVar32;
            pauVar24 = pauVar24 + -1;
            auVar32 = *(undefined (*) [16])((int64_t)pauVar24 + arg2);
        }
        if ((uVar29 & 0xf) != 0) {
            *(undefined4 *)*pauVar20 = uVar5;
            *(undefined4 *)(*pauVar20 + 4) = uVar6;
            *(undefined4 *)(*pauVar20 + 8) = uVar7;
            *(undefined4 *)(*pauVar20 + 0xc) = uVar8;
        }
        *pauVar24 = auVar32;
        return;
    }
    if (*(uint32_t *)0x1806a3990 < 3) {
        if ((uVar29 < 0x801) || ((*(uint8_t *)0x18078131c & 2) == 0)) {
            if (0x80 < uVar29) {
                iVar30 = ((uint64_t)pauVar20 & 0xf) - 0x10;
                puVar23 = (undefined4 *)((int64_t)pauVar20 - iVar30);
                puVar28 = (undefined4 *)(arg2 - iVar30);
                uVar29 = uVar29 + iVar30;
                if (0x80 < uVar29) {
                    do {
                        uVar5 = puVar28[1];
                        uVar6 = puVar28[2];
                        uVar7 = puVar28[3];
                        uVar8 = puVar28[4];
                        uVar9 = puVar28[5];
                        uVar10 = puVar28[6];
                        uVar11 = puVar28[7];
                        uVar12 = puVar28[8];
                        uVar13 = puVar28[9];
                        uVar14 = puVar28[10];
                        uVar15 = puVar28[0xb];
                        uVar16 = puVar28[0xc];
                        uVar17 = puVar28[0xd];
                        uVar18 = puVar28[0xe];
                        uVar19 = puVar28[0xf];
                        *puVar23 = *puVar28;
                        puVar23[1] = uVar5;
                        puVar23[2] = uVar6;
                        puVar23[3] = uVar7;
                        puVar23[4] = uVar8;
                        puVar23[5] = uVar9;
                        puVar23[6] = uVar10;
                        puVar23[7] = uVar11;
                        puVar23[8] = uVar12;
                        puVar23[9] = uVar13;
                        puVar23[10] = uVar14;
                        puVar23[0xb] = uVar15;
                        puVar23[0xc] = uVar16;
                        puVar23[0xd] = uVar17;
                        puVar23[0xe] = uVar18;
                        puVar23[0xf] = uVar19;
                        auVar1 = *(undefined (*) [16])(puVar28 + 0x14);
                        auVar32 = *(undefined (*) [16])(puVar28 + 0x18);
                        auVar2 = *(undefined (*) [16])(puVar28 + 0x1c);
                        *(undefined (*) [16])(puVar23 + 0x10) = *(undefined (*) [16])(puVar28 + 0x10);
                        *(undefined (*) [16])(puVar23 + 0x14) = auVar1;
                        *(undefined (*) [16])(puVar23 + 0x18) = auVar32;
                        *(undefined (*) [16])(puVar23 + 0x1c) = auVar2;
                        puVar23 = puVar23 + 0x20;
                        puVar28 = puVar28 + 0x20;
                        uVar29 = uVar29 - 0x80;
                    } while (0x7f < uVar29);
                }
            }
    // WARNING: Could not recover jumptable at 0x000180498556. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (9 cases) at 0x1806509e8
            (*(code *)((uint64_t)*(uint32_t *)((uVar29 + 0xf >> 4) * 4 + 0x1806509e8) + 0x180000000))();
            return;
        }
code_r0x00018049802b:
        for (; uVar29 != 0; uVar29 = uVar29 - 1) {
            (*pauVar20)[0] = *(undefined *)arg2;
            arg2 = (int64_t)(arg2 + 1);
            pauVar20 = (undefined (*) [32])(*pauVar20 + 1);
        }
        return;
    }
    if ((0x2000 < uVar29) && (uVar29 < 0x180001)) {
        pauVar21 = pauVar20 + 2;
        if ((uint64_t)arg2 < pauVar20) {
            pauVar21 = (undefined (*) [32])arg2;
        }
        if ((pauVar21 <= (uint64_t)arg2) && ((*(uint8_t *)0x18078131c & 2) != 0)) goto code_r0x00018049802b;
    }
    auVar33 = vmovdqu_avx(*(undefined (*) [32])arg2);
    auVar38 = vmovdqu_avx(*(undefined (*) [32])(arg2 + -0x20 + uVar29));
    if (0x100 < uVar29) {
        iVar30 = ((uint64_t)pauVar20 & 0x1f) - 0x20;
        pauVar21 = (undefined (*) [32])((int64_t)pauVar20 - iVar30);
        pauVar26 = (undefined (*) [32])(arg2 - iVar30);
        uVar29 = uVar29 + iVar30;
        if (0x100 < uVar29) {
            if (0x180000 < uVar29) {
                do {
                    uVar31 = uVar29;
                    pauVar27 = pauVar26;
                    pauVar22 = pauVar21;
                    auVar34 = vmovdqu_avx(*pauVar27);
                    auVar36 = vmovdqu_avx(pauVar27[1]);
                    auVar35 = vmovdqu_avx(pauVar27[2]);
                    auVar37 = vmovdqu_avx(pauVar27[3]);
                    auVar34 = vmovntdq_avx(auVar34);
                    *pauVar22 = auVar34;
                    auVar34 = vmovntdq_avx(auVar36);
                    pauVar22[1] = auVar34;
                    auVar34 = vmovntdq_avx(auVar35);
                    pauVar22[2] = auVar34;
                    auVar34 = vmovntdq_avx(auVar37);
                    pauVar22[3] = auVar34;
                    auVar34 = vmovdqu_avx(pauVar27[4]);
                    auVar36 = vmovdqu_avx(pauVar27[5]);
                    auVar35 = vmovdqu_avx(pauVar27[6]);
                    auVar37 = vmovdqu_avx(pauVar27[7]);
                    auVar34 = vmovntdq_avx(auVar34);
                    pauVar22[4] = auVar34;
                    auVar34 = vmovntdq_avx(auVar36);
                    pauVar22[5] = auVar34;
                    auVar34 = vmovntdq_avx(auVar35);
                    pauVar22[6] = auVar34;
                    auVar34 = vmovntdq_avx(auVar37);
                    pauVar22[7] = auVar34;
                    pauVar21 = pauVar22 + 8;
                    pauVar26 = pauVar27 + 8;
                    uVar29 = uVar31 - 0x100;
                } while (0xff < uVar31 - 0x100);
                uVar29 = uVar31 - 0xe1 & 0xffffffffffffffe0;
    // switch table (18 cases) at 0x1806509c4
                switch(uVar31) {
                case 0x1e1:
                case 0x1e2:
                case 0x1e3:
                case 0x1e4:
                case 0x1e5:
                case 0x1e6:
                case 0x1e7:
                case 0x1e8:
                case 0x1e9:
                case 0x1ea:
                case 0x1eb:
                case 0x1ec:
                case 0x1ed:
                case 0x1ee:
                case 0x1ef:
                case 0x1f0:
                case 0x1f1:
                case 0x1f2:
                case 499:
                case 500:
                case 0x1f5:
                case 0x1f6:
                case 0x1f7:
                case 0x1f8:
                case 0x1f9:
                case 0x1fa:
                case 0x1fb:
                case 0x1fc:
                case 0x1fd:
                case 0x1fe:
                case 0x1ff:
                    auVar34 = vmovdqu_avx(*(undefined (*) [32])(*pauVar27 + uVar29));
                    auVar34 = vmovntdq_avx(auVar34);
                    *(undefined (*) [32])(*pauVar22 + uVar29) = auVar34;
                case 0x1c1:
                case 0x1c2:
                case 0x1c3:
                case 0x1c4:
                case 0x1c5:
                case 0x1c6:
                case 0x1c7:
                case 0x1c8:
                case 0x1c9:
                case 0x1ca:
                case 0x1cb:
                case 0x1cc:
                case 0x1cd:
                case 0x1ce:
                case 0x1cf:
                case 0x1d0:
                case 0x1d1:
                case 0x1d2:
                case 0x1d3:
                case 0x1d4:
                case 0x1d5:
                case 0x1d6:
                case 0x1d7:
                case 0x1d8:
                case 0x1d9:
                case 0x1da:
                case 0x1db:
                case 0x1dc:
                case 0x1dd:
                case 0x1de:
                case 0x1df:
                case 0x1e0:
                    auVar34 = vmovdqu_avx(*(undefined (*) [32])(pauVar27[1] + uVar29));
                    auVar34 = vmovntdq_avx(auVar34);
                    *(undefined (*) [32])(pauVar22[1] + uVar29) = auVar34;
                case 0x1a1:
                case 0x1a2:
                case 0x1a3:
                case 0x1a4:
                case 0x1a5:
                case 0x1a6:
                case 0x1a7:
                case 0x1a8:
                case 0x1a9:
                case 0x1aa:
                case 0x1ab:
                case 0x1ac:
                case 0x1ad:
                case 0x1ae:
                case 0x1af:
                case 0x1b0:
                case 0x1b1:
                case 0x1b2:
                case 0x1b3:
                case 0x1b4:
                case 0x1b5:
                case 0x1b6:
                case 0x1b7:
                case 0x1b8:
                case 0x1b9:
                case 0x1ba:
                case 0x1bb:
                case 0x1bc:
                case 0x1bd:
                case 0x1be:
                case 0x1bf:
                case 0x1c0:
                    auVar34 = vmovdqu_avx(*(undefined (*) [32])(pauVar27[2] + uVar29));
                    auVar34 = vmovntdq_avx(auVar34);
                    *(undefined (*) [32])(pauVar22[2] + uVar29) = auVar34;
                case 0x181:
                case 0x182:
                case 0x183:
                case 0x184:
                case 0x185:
                case 0x186:
                case 0x187:
                case 0x188:
                case 0x189:
                case 0x18a:
                case 0x18b:
                case 0x18c:
                case 0x18d:
                case 0x18e:
                case 399:
                case 400:
                case 0x191:
                case 0x192:
                case 0x193:
                case 0x194:
                case 0x195:
                case 0x196:
                case 0x197:
                case 0x198:
                case 0x199:
                case 0x19a:
                case 0x19b:
                case 0x19c:
                case 0x19d:
                case 0x19e:
                case 0x19f:
                case 0x1a0:
                    auVar34 = vmovdqu_avx(*(undefined (*) [32])(pauVar27[3] + uVar29));
                    auVar34 = vmovntdq_avx(auVar34);
                    *(undefined (*) [32])(pauVar22[3] + uVar29) = auVar34;
                case 0x161:
                case 0x162:
                case 0x163:
                case 0x164:
                case 0x165:
                case 0x166:
                case 0x167:
                case 0x168:
                case 0x169:
                case 0x16a:
                case 0x16b:
                case 0x16c:
                case 0x16d:
                case 0x16e:
                case 0x16f:
                case 0x170:
                case 0x171:
                case 0x172:
                case 0x173:
                case 0x174:
                case 0x175:
                case 0x176:
                case 0x177:
                case 0x178:
                case 0x179:
                case 0x17a:
                case 0x17b:
                case 0x17c:
                case 0x17d:
                case 0x17e:
                case 0x17f:
                case 0x180:
                    auVar34 = vmovdqu_avx(*(undefined (*) [32])(pauVar27[4] + uVar29));
                    auVar34 = vmovntdq_avx(auVar34);
                    *(undefined (*) [32])(pauVar22[4] + uVar29) = auVar34;
                case 0x141:
                case 0x142:
                case 0x143:
                case 0x144:
                case 0x145:
                case 0x146:
                case 0x147:
                case 0x148:
                case 0x149:
                case 0x14a:
                case 0x14b:
                case 0x14c:
                case 0x14d:
                case 0x14e:
                case 0x14f:
                case 0x150:
                case 0x151:
                case 0x152:
                case 0x153:
                case 0x154:
                case 0x155:
                case 0x156:
                case 0x157:
                case 0x158:
                case 0x159:
                case 0x15a:
                case 0x15b:
                case 0x15c:
                case 0x15d:
                case 0x15e:
                case 0x15f:
                case 0x160:
                    auVar34 = vmovdqu_avx(*(undefined (*) [32])(pauVar27[5] + uVar29));
                    auVar34 = vmovntdq_avx(auVar34);
                    *(undefined (*) [32])(pauVar22[5] + uVar29) = auVar34;
                case 0x121:
                case 0x122:
                case 0x123:
                case 0x124:
                case 0x125:
                case 0x126:
                case 0x127:
                case 0x128:
                case 0x129:
                case 0x12a:
                case 299:
                case 300:
                case 0x12d:
                case 0x12e:
                case 0x12f:
                case 0x130:
                case 0x131:
                case 0x132:
                case 0x133:
                case 0x134:
                case 0x135:
                case 0x136:
                case 0x137:
                case 0x138:
                case 0x139:
                case 0x13a:
                case 0x13b:
                case 0x13c:
                case 0x13d:
                case 0x13e:
                case 0x13f:
                case 0x140:
                    auVar34 = vmovdqu_avx(*(undefined (*) [32])(pauVar27[6] + uVar29));
                    auVar34 = vmovntdq_avx(auVar34);
                    *(undefined (*) [32])(pauVar22[6] + uVar29) = auVar34;
                default:
                    auVar38 = vmovdqu_avx(auVar38);
                    *(undefined (*) [32])(pauVar22[-1] + uVar31) = auVar38;
                case 0x100:
                    auVar33 = vmovdqu_avx(auVar33);
                    *pauVar20 = auVar33;
                    return;
                }
            }
            do {
                auVar33 = vmovdqu_avx(*pauVar26);
                auVar38 = vmovdqu_avx(pauVar26[1]);
                auVar34 = vmovdqu_avx(pauVar26[2]);
                auVar36 = vmovdqu_avx(pauVar26[3]);
                *pauVar21 = auVar33;
                pauVar21[1] = auVar38;
                pauVar21[2] = auVar34;
                pauVar21[3] = auVar36;
                auVar33 = vmovdqu_avx(pauVar26[4]);
                auVar38 = vmovdqu_avx(pauVar26[5]);
                auVar34 = vmovdqu_avx(pauVar26[6]);
                auVar36 = vmovdqu_avx(pauVar26[7]);
                pauVar21[4] = auVar33;
                pauVar21[5] = auVar38;
                pauVar21[6] = auVar34;
                pauVar21[7] = auVar36;
                pauVar21 = pauVar21 + 8;
                pauVar26 = pauVar26 + 8;
                uVar29 = uVar29 - 0x100;
            } while (0xff < uVar29);
        }
    }
    // WARNING: Could not recover jumptable at 0x0001804982b2. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (27 cases) at 0x1806509a0
    (*(code *)((uint64_t)*(uint32_t *)((uVar29 + 0x1f >> 5) * 4 + 0x1806509a0) + 0x180000000))();
    return;
}

// ============================================================
// Function: FUN_1801741e0
// Address: 0x1801741e0
// Size: 261 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801741e0(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    uint32_t uVar2;
    int32_t *piVar3;
    undefined2 uVar4;
    uint64_t arg2_00;
    int64_t var_8h;
    
    if ((*(int64_t *)(arg1 + 0x178) != 0) &&
       (*(undefined8 *)(arg1 + 0x178) = 0, (*(uint32_t *)(arg1 + 0x3c) >> 0xe & 1) != 0)) {
        if (*(int64_t *)(arg1 + 0x78) != 0) {
            func_0x000180180fe0();
            *(undefined8 *)(arg1 + 0x78) = 0;
        }
        *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xffffbfff;
        *(undefined8 *)(arg1 + 0x78) = *(undefined8 *)(*(int64_t *)arg1 + 0x138);
        *(undefined8 *)(arg1 + 0x80) = *(undefined8 *)(*(int64_t *)arg1 + 0x140);
    }
    if (arg2 != 0) {
        *(int64_t *)(arg1 + 0x178) = arg2;
        if (*(int32_t *)(arg2 + 4) == 0) {
            *(undefined4 *)(arg2 + 4) = 0x200000;
        }
        piVar3 = *(int32_t **)(arg1 + 0x178);
        iVar1 = *piVar3;
        if (iVar1 != 1) {
            if (iVar1 == 2) {
                if (*(int16_t *)(piVar3 + 4) == 0) {
                    uVar4 = func_0x000180498cd0(piVar3 + 2);
                    *(undefined2 *)(piVar3 + 4) = uVar4;
                }
            } else if ((iVar1 == 3) && (piVar3[4] == 0)) {
                piVar3[4] = 0x10e1;
            }
        }
        piVar3 = *(int32_t **)(arg1 + 0x178);
        if (*piVar3 == 1) {
            arg2_00 = (uint64_t)(uint32_t)piVar3[2];
        } else {
            uVar2 = piVar3[1];
            arg2_00 = (uint64_t)uVar2;
            if (0x2000 < uVar2) {
                arg2_00 = 0x2000;
            }
        }
        *(uint64_t *)(arg1 + 0x80) = arg2_00;
        *(int32_t *)(arg1 + 0xa0) = piVar3[1];
        fcn.1801735b0(arg1, arg2_00);
    }
    return;
}

// ============================================================
// Function: FUN_180174370
// Address: 0x180174370
// Size: 444 bytes
// ============================================================
undefined4 * fcn.180174370(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 *puVar6;
    undefined4 *puVar7;
    undefined4 *puVar8;
    uint64_t uVar9;
    int64_t iVar10;
    undefined *puVar11;
    undefined *puVar12;
    uint64_t uVar13;
    undefined4 *puVar14;
    int64_t iVar15;
    undefined auStack_68 [8];
    undefined auStack_60 [32];
    
    puVar12 = auStack_68;
    puVar11 = auStack_68;
    iVar15 = *(int64_t *)arg1;
    iVar10 = *(int64_t *)(arg1 + 8) - iVar15 >> 4;
    if (iVar10 == 0xfffffffffffffff) {
        func_0x000180010010();
        pcVar2 = (code *)swi(3);
        puVar14 = (undefined4 *)(*pcVar2)();
        return puVar14;
    }
    uVar9 = *(int64_t *)(arg1 + 0x10) - iVar15 >> 4;
    if (uVar9 <= 0xfffffffffffffff - (uVar9 >> 1)) {
        uVar1 = iVar10 + 1;
        uVar9 = uVar9 + (uVar9 >> 1);
        uVar13 = uVar1;
        if (uVar1 <= uVar9) {
            uVar13 = uVar9;
        }
        if (uVar13 < 0x1000000000000000) {
            uVar9 = uVar13 * 0x10;
            puVar14 = (undefined4 *)0x0;
            if (uVar9 != 0) {
                if (uVar9 < 0x1000) {
                    puVar14 = (undefined4 *)func_0x000180459890();
                    puVar12 = auStack_68;
                } else {
                    if (uVar9 + 0x27 <= uVar9) goto code_r0x000180174526;
                    iVar10 = func_0x000180459890(uVar9 + 0x27);
                    if (iVar10 == 0) {
                        pcVar2 = (code *)swi(0x29);
                        iVar10 = (*pcVar2)(5);
                        puVar11 = auStack_60;
                    }
                    puVar14 = (undefined4 *)(iVar10 + 0x27U & 0xffffffffffffffe0);
                    *(int64_t *)(puVar14 + -2) = iVar10;
                    puVar12 = puVar11;
                }
            }
            iVar15 = arg2 - iVar15 >> 4;
            uVar3 = *(undefined4 *)(arg3 + 4);
            uVar4 = *(undefined4 *)(arg3 + 8);
            uVar5 = *(undefined4 *)(arg3 + 0xc);
            puVar8 = puVar14 + iVar15 * 4;
            *puVar8 = *(undefined4 *)arg3;
            puVar8[1] = uVar3;
            puVar8[2] = uVar4;
            puVar8[3] = uVar5;
            *(undefined *)arg3 = 0;
            *(undefined8 *)(arg3 + 8) = 0;
            puVar8 = *(undefined4 **)(arg1 + 8);
            puVar7 = *(undefined4 **)arg1;
            puVar6 = puVar14;
            if ((undefined4 *)arg2 == puVar8) {
                for (; puVar7 != puVar8; puVar7 = puVar7 + 4) {
                    uVar3 = puVar7[1];
                    uVar4 = puVar7[2];
                    uVar5 = puVar7[3];
                    *puVar6 = *puVar7;
                    puVar6[1] = uVar3;
                    puVar6[2] = uVar4;
                    puVar6[3] = uVar5;
                    *(undefined *)puVar7 = 0;
                    *(undefined8 *)(puVar7 + 2) = 0;
                    puVar6 = puVar6 + 4;
                }
            } else {
                for (; puVar7 != (undefined4 *)arg2; puVar7 = puVar7 + 4) {
                    uVar3 = puVar7[1];
                    uVar4 = puVar7[2];
                    uVar5 = puVar7[3];
                    *puVar6 = *puVar7;
                    puVar6[1] = uVar3;
                    puVar6[2] = uVar4;
                    puVar6[3] = uVar5;
                    *(undefined *)puVar7 = 0;
                    *(undefined8 *)(puVar7 + 2) = 0;
                    puVar6 = puVar6 + 4;
                }
                puVar7 = *(undefined4 **)(arg1 + 8);
                puVar8 = puVar14 + iVar15 * 4 + 4;
                if ((undefined4 *)arg2 != puVar7) {
                    do {
                        uVar3 = *(undefined4 *)(arg2 + 4);
                        uVar4 = *(undefined4 *)(arg2 + 8);
                        uVar5 = *(undefined4 *)(arg2 + 0xc);
                        *puVar8 = *(undefined4 *)arg2;
                        puVar8[1] = uVar3;
                        puVar8[2] = uVar4;
                        puVar8[3] = uVar5;
                        *(undefined *)arg2 = 0;
                        *(undefined8 *)(arg2 + 8) = 0;
                        puVar8 = puVar8 + 4;
                        arg2 = arg2 + 0x10;
                    } while ((undefined4 *)arg2 != puVar7);
                }
            }
            *(undefined8 *)(puVar12 + -8) = 0x18017450b;
            func_0x000180178dc0(arg1, puVar14, uVar1, uVar13);
            return puVar14 + iVar15 * 4;
        }
    }
code_r0x000180174526:
    func_0x000180004720();
    pcVar2 = (code *)swi(3);
    puVar14 = (undefined4 *)(*pcVar2)();
    return puVar14;
}

// ============================================================
// Function: FUN_180174530
// Address: 0x180174530
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180174530(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_40h, int64_t arg_48h, int64_t arg_60h)
{
    char cVar1;
    int64_t *piVar2;
    int64_t unaff_RBP;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    cVar1 = *(char *)(arg3 + 0x19);
    while (cVar1 == '\0') {
        fcn.180174530(arg1, arg2, *(int64_t *)(arg3 + 0x10), unaff_retaddr, unaff_RBP, var_20h);
        piVar2 = *(int64_t **)arg3;
        fcn.180004e40((int64_t *)(arg3 + 0x60));
        fcn.180004e40((int64_t *)(arg3 + 0x40));
        fcn.180004e40((int64_t *)(arg3 + 0x20));
        fcn.180459c3c(arg3, 0x80);
        arg3 = (int64_t)piVar2;
        cVar1 = *(char *)((int64_t)piVar2 + 0x19);
    }
    return;
}

// ============================================================
// Function: FUN_18017454a
// Address: 0x18017454a
// Size: 104 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180174530(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_40h, int64_t arg_48h, int64_t arg_60h)
{
    char cVar1;
    int64_t *piVar2;
    int64_t unaff_RBP;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    cVar1 = *(char *)(arg3 + 0x19);
    while (cVar1 == '\0') {
        fcn.180174530(arg1, arg2, *(int64_t *)(arg3 + 0x10), unaff_retaddr, unaff_RBP, var_20h);
        piVar2 = *(int64_t **)arg3;
        fcn.180004e40((int64_t *)(arg3 + 0x60));
        fcn.180004e40((int64_t *)(arg3 + 0x40));
        fcn.180004e40((int64_t *)(arg3 + 0x20));
        fcn.180459c3c(arg3, 0x80);
        arg3 = (int64_t)piVar2;
        cVar1 = *(char *)((int64_t)piVar2 + 0x19);
    }
    return;
}

// ============================================================
// Function: FUN_1801745b2
// Address: 0x1801745b2
// Size: 10 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180174530(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_40h, int64_t arg_48h, int64_t arg_60h)
{
    char cVar1;
    int64_t *piVar2;
    int64_t unaff_RBP;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    cVar1 = *(char *)(arg3 + 0x19);
    while (cVar1 == '\0') {
        fcn.180174530(arg1, arg2, *(int64_t *)(arg3 + 0x10), unaff_retaddr, unaff_RBP, var_20h);
        piVar2 = *(int64_t **)arg3;
        fcn.180004e40((int64_t *)(arg3 + 0x60));
        fcn.180004e40((int64_t *)(arg3 + 0x40));
        fcn.180004e40((int64_t *)(arg3 + 0x20));
        fcn.180459c3c(arg3, 0x80);
        arg3 = (int64_t)piVar2;
        cVar1 = *(char *)((int64_t)piVar2 + 0x19);
    }
    return;
}

// ============================================================
// Function: FUN_1801745c0
// Address: 0x1801745c0
// Size: 106 bytes
// ============================================================
void fcn.1801745c0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    char cVar1;
    int64_t *piVar2;
    
    cVar1 = *(char *)(arg3 + 0x19);
    while (cVar1 == '\0') {
        fcn.1801745c0(arg1, arg2, *(int64_t *)(arg3 + 0x10));
        piVar2 = *(int64_t **)arg3;
        func_0x000180178f50((int64_t *)(arg3 + 0x48), *(undefined *)(arg3 + 0x40));
        fcn.180004e40((int64_t *)(arg3 + 0x20));
        fcn.180459c3c(arg3, 0x50);
        arg3 = (int64_t)piVar2;
        cVar1 = *(char *)((int64_t)piVar2 + 0x19);
    }
    return;
}

// ============================================================
// Function: FUN_180174630
// Address: 0x180174630
// Size: 102 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180174630(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (arg1 != arg2) {
        do {
            func_0x0001801754f0(arg3, arg1);
            arg3 = arg3 + 0xc0;
            arg1 = arg1 + 0xc0;
        } while (arg1 != arg2);
    }
    return arg3;
}

