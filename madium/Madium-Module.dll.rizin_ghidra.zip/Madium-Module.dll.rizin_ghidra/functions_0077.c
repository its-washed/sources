// Chunk 77 - 50 functions

// ============================================================
// Function: FUN_1800ff916
// Address: 0x1800ff916
// Size: 17 bytes
// ============================================================
uint32_t fcn.1800ff916(int64_t arg_30h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                      int64_t arg_70h, int64_t arg_78h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h,
                      int64_t arg_c0h, int64_t arg_c8h, int64_t arg_d0h, int64_t arg_e0h, int64_t arg_f0h,
                      int64_t arg_100h, int64_t arg_110h, int64_t arg_120h, int64_t arg_130h, int64_t arg_140h,
                      int64_t arg_150h, int64_t arg_160h, int64_t arg_168h, int64_t arg_170h, int64_t arg_1b8h)
{
    uint8_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    float fVar8;
    undefined4 uVar9;
    int64_t iVar10;
    undefined4 *puVar11;
    uint64_t in_RCX;
    int64_t *piVar12;
    uint64_t uVar13;
    uint32_t uVar14;
    uint32_t *unaff_RBX;
    int64_t unaff_RBP;
    int64_t unaff_RDI;
    int64_t iVar15;
    int32_t unaff_R13D;
    int64_t iVar16;
    uint32_t uVar17;
    float *pfVar18;
    bool bVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    float fVar31;
    int64_t var_20h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_4ch;
    
    iVar7 = *(int64_t *)0x180781f28;
    arg_48h._4_4_ = 0;
    if (unaff_R13D < 1) {
        fVar23 = 0.0;
    } else {
        fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) * 1.35;
        fVar20 = *(float *)(unaff_RDI + 0x98) + 1.0 + *(float *)(*(int64_t *)0x180781f28 + 0x12f8) * 0.2;
        if (fVar23 <= fVar20) {
            fVar23 = fVar20;
        }
        fVar23 = (float)(int32_t)((float)(int32_t)fVar23 * 0.75);
    }
    pfVar18 = *(float **)(unaff_RBP + 200);
    fVar20 = *(float *)(*(int64_t *)0x180781f28 + 0x15d4);
    fVar29 = *pfVar18;
    fVar27 = pfVar18[3];
    fVar31 = pfVar18[1];
    arg_38h = CONCAT44(arg_38h._4_4_, pfVar18[2]);
    if (((*(uint8_t *)(unaff_RDI + 0x130) & 1) == 0) && ((in_RCX & 1) == 0)) {
        fVar31 = fVar31 - *(float *)(unaff_RDI + 0xa0);
        arg_30h._3_1_ = '\x01';
    } else {
        arg_30h._3_1_ = '\0';
    }
    uVar17 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x34);
    *(float *)(unaff_RBP + 0xa0) = fVar31;
    arg_70h._0_4_ = 3.402823e+38;
    arg_70h._4_4_ = 3.402823e+38;
    arg_50h = 0x7f7fffff7f7fffff;
    if ((((uVar17 & 0x1000) == 0) || (*(int32_t *)(iVar7 + 0x134) != *(int32_t *)(unaff_RDI + 0x50))) ||
       ((*(uint8_t *)(*(int64_t *)(unaff_RDI + 0x48) + 4) & 8) == 0)) {
        iVar15 = *(int64_t *)(unaff_RDI + 0x48);
        fVar22 = *(float *)(iVar15 + 8);
        fVar24 = *(float *)(iVar15 + 0xc);
        fVar30 = *(float *)(iVar15 + 0x10);
        fVar21 = *(float *)(iVar15 + 0x14);
        *(float *)(unaff_RDI + 0x2b8) = fVar22;
        *(float *)(unaff_RDI + 700) = fVar24;
        *(float *)(unaff_RDI + 0x2c0) = fVar22 + fVar30;
        *(float *)(unaff_RDI + 0x2c4) = fVar24 + fVar21;
    }
    *(undefined4 *)(unaff_RDI + 0x1b0) = 1;
    arg_40h._0_4_ = fVar23;
    arg_40h._4_4_ = fVar27;
    arg_48h._0_4_ = fVar29;
    func_0x000180107590();
    uVar17 = 0;
    if (0 < unaff_R13D) {
        iVar15 = 0;
        do {
            fVar29 = *(float *)(unaff_RDI + 0x60);
            fVar27 = *(float *)(unaff_RDI + 100);
            iVar16 = iVar15 * 0x18;
            fVar22 = *(float *)(iVar15 * 0x18 + 0x1806185cc);
            fVar24 = *(float *)(iVar15 * 0x18 + 0x1806185c8);
            pfVar18 = (float *)(iVar16 + 0x1806185c0);
            fVar29 = ((fVar29 + *(float *)(unaff_RDI + 0x68)) - fVar29) * *pfVar18 + fVar29;
            fVar30 = fVar23 * fVar24 + fVar29;
            fVar27 = ((fVar27 + *(float *)(unaff_RDI + 0x6c)) - fVar27) * *(float *)(iVar15 * 0x18 + 0x1806185c4) +
                     fVar27;
            fVar29 = fVar29 - fVar20 * fVar24;
            *(float *)(unaff_RBP + -0x78) = fVar30;
            fVar23 = fVar22 * (float)arg_40h + fVar27;
            fVar27 = fVar27 - fVar22 * fVar20;
            *(float *)(unaff_RBP + -0x80) = fVar29;
            *(float *)(unaff_RBP + -0x74) = fVar23;
            *(float *)(unaff_RBP + -0x7c) = fVar27;
            if (fVar30 < fVar29) {
                *(float *)(unaff_RBP + -0x80) = fVar30;
                *(float *)(unaff_RBP + -0x78) = fVar29;
            }
            if (fVar23 < fVar27) {
                *(float *)(unaff_RBP + -0x7c) = fVar23;
                *(float *)(unaff_RBP + -0x74) = fVar27;
            }
            piVar12 = &arg_60h;
            arg_60h._0_4_ = uVar17;
            uVar14 = ~*(uint32_t *)(*(int64_t *)(unaff_RDI + 0x150) + -4 + (int64_t)*(int32_t *)(unaff_RDI + 0x148) * 4)
            ;
            do {
                uVar1 = *(uint8_t *)piVar12;
                piVar12 = (int64_t *)((int64_t)piVar12 + 1);
                uVar14 = uVar14 >> 8 ^ *(uint32_t *)(((uint64_t)(uVar14 & 0xff) ^ (uint64_t)uVar1) * 4 + 0x180618620);
            } while (piVar12 < (int64_t *)((int64_t)&arg_60h + 4U));
            func_0x00018010b530(unaff_RBP + -0x80, ~uVar14, 0, 2);
            func_0x000180139d40(unaff_RBP + -0x80, ~uVar14, (int64_t)&arg_30h + 2, (int64_t)&arg_30h + 1, 0x40800);
            if ((arg_30h._2_1_ == '\0') && (arg_30h._1_1_ == '\0')) {
code_r0x0001800ffe50:
                if ((uVar17 == 0) && ((*(uint32_t *)(unaff_RDI + 0x14) & 0x1000000) == 0)) goto code_r0x0001800ffe5e;
            } else {
                *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2650) = (~uVar17 & 1) + 5;
                if (arg_30h._1_1_ == '\0') {
code_r0x0001800ffe47:
                    if (arg_30h._2_1_ == '\0') goto code_r0x0001800ffe50;
                } else {
                    if (*(char *)(iVar7 + 0xb55) == '\0') {
                        fVar23 = *(float *)(iVar16 + 0x1806185c4);
                        if ((fVar23 != 1.0) && ((fVar23 != 0.0 || (arg_30h._3_1_ == '\0')))) {
                            fVar31 = -3.402823e+38;
                        }
                        fVar29 = *pfVar18;
                        arg_78h._0_4_ = (float)arg_48h;
                        if (fVar29 != 1.0) {
                            arg_78h._0_4_ = -3.402823e+38;
                        }
                        fVar27 = arg_40h._4_4_;
                        if (fVar23 != 0.0) {
                            fVar27 = 3.402823e+38;
                        }
                        fVar22 = 3.402823e+38;
                        if (fVar29 == 0.0) {
                            fVar22 = (float)arg_38h;
                        }
                        fVar30 = *(float *)(iVar16 + 0x1806185cc) * fVar20;
                        fVar24 = *(float *)(iVar16 + 0x1806185c8) * fVar20;
                        fVar24 = ((float)((uint32_t)(float)arg_40h ^ 0x80000000) * *(float *)(iVar16 + 0x1806185c8) -
                                 fVar24) * fVar29 + fVar24;
                        fVar23 = (*(float *)(iVar7 + 0x11c) - *(float *)(iVar7 + 0x1670)) +
                                 ((float)((uint32_t)(float)arg_40h ^ 0x80000000) * *(float *)(iVar16 + 0x1806185cc) -
                                 fVar30) * fVar23 + fVar30;
                        fVar29 = (*(float *)(iVar7 + 0x118) - *(float *)(iVar7 + 0x166c)) + fVar24;
                        arg_78h._4_4_ = fVar31;
                        if ((fVar31 <= fVar23) && (arg_78h._4_4_ = fVar27, fVar23 <= fVar27)) {
                            arg_78h._4_4_ = fVar23;
                        }
                        if (((float)arg_78h <= fVar29) && (arg_78h._0_4_ = fVar22, fVar29 <= fVar22)) {
                            arg_78h._0_4_ = fVar29;
                        }
                        func_0x0001800ff590(fVar24, &arg_78h, pfVar18, &arg_70h, &arg_50h);
                        fVar31 = *(float *)(unaff_RBP + 0xa0);
                    } else {
                        func_0x0001800ff2b0(&arg_58h);
                        piVar12 = (int64_t *)func_0x0001800ff010(unaff_RBP + -0x60);
                        arg_48h._4_4_ = 3;
                        arg_50h = *piVar12;
                        func_0x0001800f9f30(0, 0);
                    }
                    if (arg_30h._1_1_ == '\0') goto code_r0x0001800ffe47;
                }
code_r0x0001800ffe5e:
                iVar16 = *(int64_t *)0x180781f28;
                if (arg_30h._1_1_ == '\0') {
                    iVar10 = (uint64_t)(arg_30h._2_1_ != '\0') + 0x1e;
                } else {
                    iVar10 = 0x20;
                }
                puVar11 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar10 + 0x14) * 0x10);
                uVar9 = puVar11[1];
                uVar4 = puVar11[2];
                fVar23 = (float)puVar11[3];
                *(undefined4 *)(unaff_RBP + -0x70) = *puVar11;
                *(undefined4 *)(unaff_RBP + -0x6c) = uVar9;
                *(undefined4 *)(unaff_RBP + -0x68) = uVar4;
                *(float *)(unaff_RBP + -100) = fVar23;
                *(float *)(unaff_RBP + -100) = fVar23 * *(float *)(iVar16 + 0xd9c);
                uVar9 = func_0x0001800f5fa0(unaff_RBP + -0x70);
                *(undefined4 *)(*(int64_t *)(unaff_RBP + 0xc0) + iVar15 * 4) = uVar9;
            }
            uVar17 = uVar17 + 1;
            iVar15 = iVar15 + 1;
            fVar23 = (float)arg_40h;
        } while ((int32_t)uVar17 < unaff_R13D);
        unaff_RBX = *(uint32_t **)(unaff_RBP + 0xb0);
        fVar29 = (float)arg_48h;
        fVar27 = arg_40h._4_4_;
    }
    if ((*(uint32_t *)(unaff_RDI + 0x14) & 0x1000000) == 0) {
        uVar17 = -(uint32_t)(*(char *)(iVar7 + 0x92) != '\0') & 0xf;
    } else {
        uVar17 = *(uint32_t *)(unaff_RDI + 0x1c) >> 1 & 2 | *(uint32_t *)(unaff_RDI + 0x1c) & 8;
    }
    fVar23 = (float)arg_38h;
    uVar14 = 0;
    arg_48h._0_4_ = 1.401298e-45;
    arg_40h._4_4_ = (float)uVar17;
    do {
        fVar20 = (float)arg_40h;
        iVar15 = 0x180000000;
        if ((uVar17 & (uint32_t)(float)arg_48h) != 0) {
            if (uVar14 < 2) {
                arg_38h = (uint64_t)(uint32_t)arg_38h._4_4_ << 0x20;
                uVar9 = 4;
                iVar16 = 0;
            } else {
                arg_38h = CONCAT44(arg_38h._4_4_, 1);
                uVar9 = 3;
                iVar16 = 4;
            }
            var_20h = (int64_t)*(uint32_t *)(iVar7 + 0x15d4);
            func_0x0001800ff770(unaff_RBP + -0x70);
            arg_68h._0_4_ = uVar14 + 4;
            piVar12 = &arg_68h;
            uVar17 = ~*(uint32_t *)(*(int64_t *)(unaff_RDI + 0x150) + -4 + (int64_t)*(int32_t *)(unaff_RDI + 0x148) * 4)
            ;
            do {
                uVar1 = *(uint8_t *)piVar12;
                piVar12 = (int64_t *)((int64_t)piVar12 + 1);
                uVar17 = uVar17 >> 8 ^
                         *(uint32_t *)(iVar15 + 0x618620 + ((uint64_t)(uVar17 & 0xff) ^ (uint64_t)uVar1) * 4);
            } while (piVar12 < (int64_t *)((int64_t)&arg_68h + 4U));
            func_0x00018010b530(unaff_RBP + -0x70, ~uVar17, 0, 2, var_20h);
            func_0x000180139d40(unaff_RBP + -0x70, ~uVar17, unaff_RBP + 0xa0, &arg_30h, 0x40800);
            if (*(char *)(unaff_RBP + 0xa0) == '\0') {
code_r0x00018010002f:
                if ((char)arg_30h != '\0') goto code_r0x00018010003a;
            } else {
                if (*(float *)(iVar7 + 0x1648) <= 0.04) {
                    *(undefined *)(unaff_RBP + 0xa0) = 0;
                    goto code_r0x00018010002f;
                }
code_r0x00018010003a:
                *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2650) = uVar9;
                if ((char)arg_30h != '\0') {
                    if (*(char *)(iVar7 + 0xb55) == '\0') {
                        iVar15 = *(int64_t *)(iVar7 + 0x1608);
                        iVar16 = (uint64_t)uVar14 * 0x1c;
                        if ((iVar15 == 0) ||
                           (iVar10 = unaff_RDI, *(int32_t *)(iVar7 + 0x161c) != *(int32_t *)(iVar7 + 4))) {
code_r0x00018010011c:
                            bVar19 = false;
                        } else {
                            do {
                                iVar3 = *(int64_t *)(*(int64_t *)(iVar10 + 0x418) + 0x428);
                                bVar19 = iVar10 != iVar3;
                                iVar10 = iVar3;
                            } while (bVar19);
                            iVar10 = unaff_RDI;
                            if (iVar3 != iVar15) {
                                do {
                                    if (iVar10 == iVar15) goto code_r0x000180100247;
                                } while ((iVar10 != iVar3) &&
                                        (piVar12 = (int64_t *)(iVar10 + 0x408), iVar10 = *piVar12, *piVar12 != 0));
                                goto code_r0x00018010011c;
                            }
code_r0x000180100247:
                            bVar19 = true;
                        }
                        if ((*(char *)(iVar7 + 0x1660) != '\0') || (bVar19)) {
                            uVar9 = *(undefined4 *)(unaff_RBP + -0x70);
                            uVar4 = *(undefined4 *)(unaff_RBP + -0x6c);
                            uVar5 = *(undefined4 *)(unaff_RBP + -0x68);
                            uVar6 = *(undefined4 *)(unaff_RBP + -100);
                            *(undefined *)(iVar7 + 0x27fc) = 0;
                            *(undefined4 *)(iVar7 + 0x27ec) = uVar9;
                            *(undefined4 *)(iVar7 + 0x27f0) = uVar4;
                            *(undefined4 *)(iVar7 + 0x27f4) = uVar5;
                            *(undefined4 *)(iVar7 + 0x27f8) = uVar6;
                        }
                        if (((*(uint32_t *)(unaff_RDI + 0x14) & 0x1000000) != 0) &&
                           ((*(int64_t *)(iVar7 + 0x27ec) != *(int64_t *)(unaff_RBP + -0x70) ||
                            (*(int64_t *)(iVar7 + 0x27f4) != *(int64_t *)(unaff_RBP + -0x68))))) {
                            *(undefined *)(iVar7 + 0x27fc) = 1;
                        }
                        uVar13 = arg_38h & 0xffffffff;
                        fVar22 = *(float *)(iVar16 + 0x180618478);
                        if (*(float *)(iVar16 + 0x180618480) <= *(float *)(iVar16 + 0x180618478)) {
                            fVar22 = *(float *)(iVar16 + 0x180618480);
                        }
                        fVar24 = *(float *)(iVar16 + 0x18061847c);
                        if (*(float *)(iVar16 + 0x180618484) <= *(float *)(iVar16 + 0x18061847c)) {
                            fVar24 = *(float *)(iVar16 + 0x180618484);
                        }
                        fVar30 = *(float *)(unaff_RDI + 0x6c);
                        fVar25 = (*(float *)(iVar7 + 0x118 + uVar13 * 4) - *(float *)(iVar7 + 0x166c + uVar13 * 4)) +
                                 *(float *)(iVar7 + 0x15d4);
                        fVar21 = *(float *)(unaff_RDI + 100);
                        arg_78h._0_4_ = fVar22 * *(float *)(unaff_RDI + 0x68) + *(float *)(unaff_RDI + 0x60);
                        arg_38h = *(int64_t *)(unaff_RDI + 0x60);
                        *(float *)((int64_t)&arg_38h + uVar13 * 4) = fVar25;
                        bVar19 = false;
                        arg_78h._4_4_ = fVar24 * fVar30 + fVar21;
                        if (*(char *)(iVar7 + 0x27fc) != '\0') {
                            fVar30 = *(float *)(iVar7 + 0x104 + uVar13 * 4);
                            fVar21 = fVar30 + *(float *)((int64_t)&arg_78h + uVar13 * 4);
                            *(float *)((int64_t)&arg_38h + uVar13 * 4) = fVar21;
                            if ((fVar30 == 0.0) || (0.0 < fVar30 == fVar25 < fVar21)) {
                                bVar19 = true;
                            }
                        }
                        fVar30 = fVar31;
                        if ((uVar14 != 3) && ((uVar14 != 2 || (arg_30h._3_1_ == '\0')))) {
                            fVar30 = -3.402823e+38;
                        }
                        if (uVar14 == 1) {
                            fVar21 = fVar29;
                            fVar8 = 3.402823e+38;
code_r0x000180100264:
                            fVar26 = fVar8;
                            fVar28 = 3.402823e+38;
                            fVar25 = fVar21;
                        } else {
                            fVar25 = -3.402823e+38;
                            fVar21 = -3.402823e+38;
                            fVar8 = fVar27;
                            if (uVar14 == 2) goto code_r0x000180100264;
                            fVar26 = 3.402823e+38;
                            fVar28 = fVar23;
                            fVar8 = 3.402823e+38;
                            if (uVar14 != 0) goto code_r0x000180100264;
                        }
                        if ((fVar30 <= arg_38h._4_4_) && (fVar30 = fVar26, arg_38h._4_4_ <= fVar26)) {
                            fVar30 = arg_38h._4_4_;
                        }
                        if ((fVar25 <= (float)arg_38h) && (fVar25 = fVar28, (float)arg_38h <= fVar28)) {
                            fVar25 = (float)arg_38h;
                        }
                        arg_38h = CONCAT44(fVar30, fVar25);
                        if (!bVar19) {
                            arg_58h._0_4_ = fVar22;
                            arg_58h._4_4_ = fVar24;
                            func_0x0001800ff590();
                        }
                    } else {
                        if ((uVar14 - 1 & 0xfffffffd) == 0) {
                            func_0x0001800ff2b0(unaff_RBP + -0x60);
                            iVar15 = func_0x0001800ff010(unaff_RBP + -0x58);
                            *(undefined4 *)((int64_t)&arg_50h + (arg_38h & 0xffffffffU) * 4) =
                                 *(undefined4 *)(iVar15 + iVar16);
                            arg_48h._4_4_ = arg_48h._4_4_ | 1 << ((uint32_t)(float)arg_38h & 0x1f);
                            arg_30h._0_1_ = '\0';
                            *(undefined *)(unaff_RBP + 0xa0) = 0;
                        }
                        func_0x0001800f9f30(0, 0);
                    }
                }
            }
            if (*(char *)(unaff_RBP + 0xa0) != '\0') {
                **(uint32_t **)(unaff_RBP + 0xa8) = uVar14;
            }
            unaff_RBX = *(uint32_t **)(unaff_RBP + 0xb0);
            uVar17 = (uint32_t)arg_40h._4_4_;
            if ((char)arg_30h != '\0') {
                *unaff_RBX = uVar14;
            }
        }
        arg_48h._0_4_ = (float)((int32_t)(float)arg_48h << 1 | (uint32_t)((int32_t)(float)arg_48h < 0));
        uVar14 = uVar14 + 1;
    } while ((int32_t)uVar14 < 4);
    iVar2 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
    if (iVar2 < 2) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
        }
    } else {
        *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar2 + -1;
    }
    *(undefined4 *)(unaff_RDI + 0x1b0) = 0;
    iVar15 = *(int64_t *)0x180781f28;
    if ((*(int64_t *)(iVar7 + 0x23c0) != 0) && (*(int64_t *)(*(int64_t *)(iVar7 + 0x23c0) + 0x428) == unaff_RDI)) {
        if (*(int32_t *)(iVar7 + 0x2228) == 2) {
            if (*(char *)(iVar7 + 0x139) == '\0') goto code_r0x00018010059a;
            fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x16c) - *(float *)(*(int64_t *)0x180781f28 + 0x15c);
            fVar27 = *(float *)(*(int64_t *)0x180781f28 + 0x18c) - *(float *)(*(int64_t *)0x180781f28 + 0x17c);
        } else {
            if (*(int32_t *)(iVar7 + 0x2228) != 3) goto code_r0x00018010059a;
            fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x93c) - *(float *)(*(int64_t *)0x180781f28 + 0x92c);
            fVar27 = *(float *)(*(int64_t *)0x180781f28 + 0x95c) - *(float *)(*(int64_t *)0x180781f28 + 0x94c);
        }
        if ((fVar23 != 0.0) || (fVar27 != 0.0)) {
            fVar22 = *(float *)(iVar7 + 0x48) * 600.0 * *(float *)(*(int64_t *)0x180781f28 + 0x12c4);
            fVar27 = fVar22 * fVar27 + *(float *)(iVar7 + 0x23f8);
            fVar23 = fVar22 * fVar23 + *(float *)(iVar7 + 0x23f4);
            *(float *)(iVar7 + 0x23f8) = fVar27;
            *(float *)(iVar7 + 0x23f4) = fVar23;
            fVar31 = (fVar31 - *(float *)(unaff_RDI + 100)) - *(float *)(unaff_RDI + 0x6c);
            fVar29 = (fVar29 - *(float *)(unaff_RDI + 0x60)) - *(float *)(unaff_RDI + 0x68);
            *(undefined *)(iVar7 + 0x23e4) = 0;
            *(undefined *)(iVar7 + 0x21cd) = 1;
            if (fVar27 <= fVar31) {
                fVar27 = fVar31;
            }
            if (fVar23 <= fVar29) {
                fVar23 = fVar29;
            }
            *(float *)(iVar7 + 0x23f8) = fVar27;
            *(float *)(iVar7 + 0x23f4) = fVar23;
            uVar9 = *(undefined4 *)(iVar15 + 0x10d4);
            uVar4 = *(undefined4 *)(iVar15 + 0x10d8);
            fVar23 = *(float *)(iVar15 + 0x10dc);
            *(undefined4 *)(unaff_RBP + -0x58) = *(undefined4 *)(iVar15 + 0x10d0);
            *(undefined4 *)(unaff_RBP + -0x54) = uVar9;
            *(undefined4 *)(unaff_RBP + -0x50) = uVar4;
            *(float *)(unaff_RBP + -0x4c) = fVar23;
            *(float *)(unaff_RBP + -0x4c) = fVar23 * *(float *)(iVar15 + 0xd9c);
            uVar9 = func_0x0001800f5fa0(unaff_RBP + -0x58);
            **(undefined4 **)(unaff_RBP + 0xc0) = uVar9;
            fVar29 = (float)(int32_t)*(float *)(iVar7 + 0x23f4);
            fVar23 = (float)(int32_t)*(float *)(iVar7 + 0x23f8);
            if ((fVar29 != 0.0) || (fVar23 != 0.0)) {
                arg_58h._0_4_ = fVar29 + *(float *)(unaff_RDI + 0x70);
                arg_58h._4_4_ = fVar23 + *(float *)(unaff_RDI + 0x74);
                piVar12 = (int64_t *)func_0x0001800ff010(unaff_RBP + -0x58, arg_58h._4_4_, &arg_58h);
                arg_50h = *piVar12;
                *(float *)(iVar7 + 0x23f4) = *(float *)(iVar7 + 0x23f4) - fVar29;
                *(float *)(iVar7 + 0x23f8) = *(float *)(iVar7 + 0x23f8) - fVar23;
            }
        }
    }
code_r0x00018010059a:
    fVar23 = *(float *)(unaff_RDI + 0x60);
    fVar29 = *(float *)(unaff_RDI + 100);
    fVar27 = *(float *)(unaff_RDI + 0x70);
    fVar31 = *(float *)(unaff_RDI + 0x74);
    fVar22 = fVar27;
    if (((float)arg_50h != 3.402823e+38) &&
       ((*(float *)(unaff_RDI + 0x68) != (float)arg_50h || (fVar27 != (float)arg_50h)))) {
        *(float *)(unaff_RDI + 0x70) = (float)arg_50h;
        *(float *)(unaff_RDI + 0x68) = (float)arg_50h;
        fVar22 = (float)arg_50h;
    }
    if ((arg_50h._4_4_ != 3.402823e+38) &&
       ((*(float *)(unaff_RDI + 0x6c) != arg_50h._4_4_ || (*(float *)(unaff_RDI + 0x74) != arg_50h._4_4_)))) {
        *(float *)(unaff_RDI + 0x74) = arg_50h._4_4_;
        *(float *)(unaff_RDI + 0x6c) = arg_50h._4_4_;
    }
    if (((float)arg_70h != 3.402823e+38) && (fVar23 != (float)(int32_t)(float)arg_70h)) {
        *(float *)(unaff_RDI + 0x60) = (float)(int32_t)(float)arg_70h;
    }
    if ((arg_70h._4_4_ != 3.402823e+38) && (*(float *)(unaff_RDI + 100) != (float)(int32_t)arg_70h._4_4_)) {
        *(float *)(unaff_RDI + 100) = (float)(int32_t)arg_70h._4_4_;
    }
    if (((((fVar23 != *(float *)(unaff_RDI + 0x60)) || (fVar29 != *(float *)(unaff_RDI + 100))) || (fVar27 != fVar22))
        || (fVar31 != *(float *)(unaff_RDI + 0x74))) &&
       (((*(uint32_t *)(unaff_RDI + 0x14) & 0x100) == 0 && (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0)))) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
    }
    if (*unaff_RBX != 0xffffffff) {
        var_20h = (int64_t)*(uint32_t *)(iVar7 + 0x15d4);
        puVar11 = (undefined4 *)func_0x0001800ff770(unaff_RBP + -0x70, fVar22, *unaff_RBX, fVar20, var_20h);
        uVar9 = puVar11[1];
        uVar4 = puVar11[2];
        uVar5 = puVar11[3];
        *(undefined4 *)(iVar7 + 0x27ec) = *puVar11;
        *(undefined4 *)(iVar7 + 0x27f0) = uVar9;
        *(undefined4 *)(iVar7 + 0x27f4) = uVar4;
        *(undefined4 *)(iVar7 + 0x27f8) = uVar5;
    }
    return arg_48h._4_4_;
}

// ============================================================
// Function: FUN_1800ff927
// Address: 0x1800ff927
// Size: 442 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: arg_1b8h
// WARNING: Variable defined which should be unmapped: arg_170h
// WARNING: Variable defined which should be unmapped: arg_168h
// WARNING: Variable defined which should be unmapped: arg_160h
// WARNING: Variable defined which should be unmapped: arg_150h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h
// WARNING: [rz-ghidra] Detected overlap for variable arg_33h
// WARNING: [rz-ghidra] Detected overlap for variable arg_74h
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_7ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Detected overlap for variable arg_31h
// WARNING: [rz-ghidra] Detected overlap for variable arg_32h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

uint32_t fcn.1800ff916(int64_t arg_30h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                      int64_t arg_70h, int64_t arg_78h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h,
                      int64_t arg_c0h, int64_t arg_c8h, int64_t arg_d0h, int64_t arg_e0h, int64_t arg_f0h,
                      int64_t arg_100h, int64_t arg_110h, int64_t arg_120h, int64_t arg_130h, int64_t arg_140h,
                      int64_t arg_150h, int64_t arg_160h, int64_t arg_168h, int64_t arg_170h, int64_t arg_1b8h)
{
    uint8_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    float fVar8;
    undefined4 uVar9;
    int64_t iVar10;
    undefined4 *puVar11;
    uint64_t in_RCX;
    int64_t *piVar12;
    uint64_t uVar13;
    uint32_t uVar14;
    uint32_t *unaff_RBX;
    int64_t unaff_RBP;
    int64_t unaff_RDI;
    int64_t iVar15;
    int32_t unaff_R13D;
    int64_t iVar16;
    uint32_t uVar17;
    float *pfVar18;
    bool bVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    float fVar31;
    int64_t var_20h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_4ch;
    
    iVar7 = *(int64_t *)0x180781f28;
    arg_48h._4_4_ = 0;
    if (unaff_R13D < 1) {
        fVar23 = 0.0;
    } else {
        fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) * 1.35;
        fVar20 = *(float *)(unaff_RDI + 0x98) + 1.0 + *(float *)(*(int64_t *)0x180781f28 + 0x12f8) * 0.2;
        if (fVar23 <= fVar20) {
            fVar23 = fVar20;
        }
        fVar23 = (float)(int32_t)((float)(int32_t)fVar23 * 0.75);
    }
    pfVar18 = *(float **)(unaff_RBP + 200);
    fVar20 = *(float *)(*(int64_t *)0x180781f28 + 0x15d4);
    fVar29 = *pfVar18;
    fVar27 = pfVar18[3];
    fVar31 = pfVar18[1];
    arg_38h = CONCAT44(arg_38h._4_4_, pfVar18[2]);
    if (((*(uint8_t *)(unaff_RDI + 0x130) & 1) == 0) && ((in_RCX & 1) == 0)) {
        fVar31 = fVar31 - *(float *)(unaff_RDI + 0xa0);
        arg_30h._3_1_ = '\x01';
    } else {
        arg_30h._3_1_ = '\0';
    }
    uVar17 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x34);
    *(float *)(unaff_RBP + 0xa0) = fVar31;
    arg_70h._0_4_ = 3.402823e+38;
    arg_70h._4_4_ = 3.402823e+38;
    arg_50h = 0x7f7fffff7f7fffff;
    if ((((uVar17 & 0x1000) == 0) || (*(int32_t *)(iVar7 + 0x134) != *(int32_t *)(unaff_RDI + 0x50))) ||
       ((*(uint8_t *)(*(int64_t *)(unaff_RDI + 0x48) + 4) & 8) == 0)) {
        iVar15 = *(int64_t *)(unaff_RDI + 0x48);
        fVar22 = *(float *)(iVar15 + 8);
        fVar24 = *(float *)(iVar15 + 0xc);
        fVar30 = *(float *)(iVar15 + 0x10);
        fVar21 = *(float *)(iVar15 + 0x14);
        *(float *)(unaff_RDI + 0x2b8) = fVar22;
        *(float *)(unaff_RDI + 700) = fVar24;
        *(float *)(unaff_RDI + 0x2c0) = fVar22 + fVar30;
        *(float *)(unaff_RDI + 0x2c4) = fVar24 + fVar21;
    }
    *(undefined4 *)(unaff_RDI + 0x1b0) = 1;
    arg_40h._0_4_ = fVar23;
    arg_40h._4_4_ = fVar27;
    arg_48h._0_4_ = fVar29;
    func_0x000180107590();
    uVar17 = 0;
    if (0 < unaff_R13D) {
        iVar15 = 0;
        do {
            fVar29 = *(float *)(unaff_RDI + 0x60);
            fVar27 = *(float *)(unaff_RDI + 100);
            iVar16 = iVar15 * 0x18;
            fVar22 = *(float *)(iVar15 * 0x18 + 0x1806185cc);
            fVar24 = *(float *)(iVar15 * 0x18 + 0x1806185c8);
            pfVar18 = (float *)(iVar16 + 0x1806185c0);
            fVar29 = ((fVar29 + *(float *)(unaff_RDI + 0x68)) - fVar29) * *pfVar18 + fVar29;
            fVar30 = fVar23 * fVar24 + fVar29;
            fVar27 = ((fVar27 + *(float *)(unaff_RDI + 0x6c)) - fVar27) * *(float *)(iVar15 * 0x18 + 0x1806185c4) +
                     fVar27;
            fVar29 = fVar29 - fVar20 * fVar24;
            *(float *)(unaff_RBP + -0x78) = fVar30;
            fVar23 = fVar22 * (float)arg_40h + fVar27;
            fVar27 = fVar27 - fVar22 * fVar20;
            *(float *)(unaff_RBP + -0x80) = fVar29;
            *(float *)(unaff_RBP + -0x74) = fVar23;
            *(float *)(unaff_RBP + -0x7c) = fVar27;
            if (fVar30 < fVar29) {
                *(float *)(unaff_RBP + -0x80) = fVar30;
                *(float *)(unaff_RBP + -0x78) = fVar29;
            }
            if (fVar23 < fVar27) {
                *(float *)(unaff_RBP + -0x7c) = fVar23;
                *(float *)(unaff_RBP + -0x74) = fVar27;
            }
            piVar12 = &arg_60h;
            arg_60h._0_4_ = uVar17;
            uVar14 = ~*(uint32_t *)(*(int64_t *)(unaff_RDI + 0x150) + -4 + (int64_t)*(int32_t *)(unaff_RDI + 0x148) * 4)
            ;
            do {
                uVar1 = *(uint8_t *)piVar12;
                piVar12 = (int64_t *)((int64_t)piVar12 + 1);
                uVar14 = uVar14 >> 8 ^ *(uint32_t *)(((uint64_t)(uVar14 & 0xff) ^ (uint64_t)uVar1) * 4 + 0x180618620);
            } while (piVar12 < (int64_t *)((int64_t)&arg_60h + 4U));
            func_0x00018010b530(unaff_RBP + -0x80, ~uVar14, 0, 2);
            func_0x000180139d40(unaff_RBP + -0x80, ~uVar14, (int64_t)&arg_30h + 2, (int64_t)&arg_30h + 1, 0x40800);
            if ((arg_30h._2_1_ == '\0') && (arg_30h._1_1_ == '\0')) {
code_r0x0001800ffe50:
                if ((uVar17 == 0) && ((*(uint32_t *)(unaff_RDI + 0x14) & 0x1000000) == 0)) goto code_r0x0001800ffe5e;
            } else {
                *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2650) = (~uVar17 & 1) + 5;
                if (arg_30h._1_1_ == '\0') {
code_r0x0001800ffe47:
                    if (arg_30h._2_1_ == '\0') goto code_r0x0001800ffe50;
                } else {
                    if (*(char *)(iVar7 + 0xb55) == '\0') {
                        fVar23 = *(float *)(iVar16 + 0x1806185c4);
                        if ((fVar23 != 1.0) && ((fVar23 != 0.0 || (arg_30h._3_1_ == '\0')))) {
                            fVar31 = -3.402823e+38;
                        }
                        fVar29 = *pfVar18;
                        arg_78h._0_4_ = (float)arg_48h;
                        if (fVar29 != 1.0) {
                            arg_78h._0_4_ = -3.402823e+38;
                        }
                        fVar27 = arg_40h._4_4_;
                        if (fVar23 != 0.0) {
                            fVar27 = 3.402823e+38;
                        }
                        fVar22 = 3.402823e+38;
                        if (fVar29 == 0.0) {
                            fVar22 = (float)arg_38h;
                        }
                        fVar30 = *(float *)(iVar16 + 0x1806185cc) * fVar20;
                        fVar24 = *(float *)(iVar16 + 0x1806185c8) * fVar20;
                        fVar24 = ((float)((uint32_t)(float)arg_40h ^ 0x80000000) * *(float *)(iVar16 + 0x1806185c8) -
                                 fVar24) * fVar29 + fVar24;
                        fVar23 = (*(float *)(iVar7 + 0x11c) - *(float *)(iVar7 + 0x1670)) +
                                 ((float)((uint32_t)(float)arg_40h ^ 0x80000000) * *(float *)(iVar16 + 0x1806185cc) -
                                 fVar30) * fVar23 + fVar30;
                        fVar29 = (*(float *)(iVar7 + 0x118) - *(float *)(iVar7 + 0x166c)) + fVar24;
                        arg_78h._4_4_ = fVar31;
                        if ((fVar31 <= fVar23) && (arg_78h._4_4_ = fVar27, fVar23 <= fVar27)) {
                            arg_78h._4_4_ = fVar23;
                        }
                        if (((float)arg_78h <= fVar29) && (arg_78h._0_4_ = fVar22, fVar29 <= fVar22)) {
                            arg_78h._0_4_ = fVar29;
                        }
                        func_0x0001800ff590(fVar24, &arg_78h, pfVar18, &arg_70h, &arg_50h);
                        fVar31 = *(float *)(unaff_RBP + 0xa0);
                    } else {
                        func_0x0001800ff2b0(&arg_58h);
                        piVar12 = (int64_t *)func_0x0001800ff010(unaff_RBP + -0x60);
                        arg_48h._4_4_ = 3;
                        arg_50h = *piVar12;
                        func_0x0001800f9f30(0, 0);
                    }
                    if (arg_30h._1_1_ == '\0') goto code_r0x0001800ffe47;
                }
code_r0x0001800ffe5e:
                iVar16 = *(int64_t *)0x180781f28;
                if (arg_30h._1_1_ == '\0') {
                    iVar10 = (uint64_t)(arg_30h._2_1_ != '\0') + 0x1e;
                } else {
                    iVar10 = 0x20;
                }
                puVar11 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar10 + 0x14) * 0x10);
                uVar9 = puVar11[1];
                uVar4 = puVar11[2];
                fVar23 = (float)puVar11[3];
                *(undefined4 *)(unaff_RBP + -0x70) = *puVar11;
                *(undefined4 *)(unaff_RBP + -0x6c) = uVar9;
                *(undefined4 *)(unaff_RBP + -0x68) = uVar4;
                *(float *)(unaff_RBP + -100) = fVar23;
                *(float *)(unaff_RBP + -100) = fVar23 * *(float *)(iVar16 + 0xd9c);
                uVar9 = func_0x0001800f5fa0(unaff_RBP + -0x70);
                *(undefined4 *)(*(int64_t *)(unaff_RBP + 0xc0) + iVar15 * 4) = uVar9;
            }
            uVar17 = uVar17 + 1;
            iVar15 = iVar15 + 1;
            fVar23 = (float)arg_40h;
        } while ((int32_t)uVar17 < unaff_R13D);
        unaff_RBX = *(uint32_t **)(unaff_RBP + 0xb0);
        fVar29 = (float)arg_48h;
        fVar27 = arg_40h._4_4_;
    }
    if ((*(uint32_t *)(unaff_RDI + 0x14) & 0x1000000) == 0) {
        uVar17 = -(uint32_t)(*(char *)(iVar7 + 0x92) != '\0') & 0xf;
    } else {
        uVar17 = *(uint32_t *)(unaff_RDI + 0x1c) >> 1 & 2 | *(uint32_t *)(unaff_RDI + 0x1c) & 8;
    }
    fVar23 = (float)arg_38h;
    uVar14 = 0;
    arg_48h._0_4_ = 1.401298e-45;
    arg_40h._4_4_ = (float)uVar17;
    do {
        fVar20 = (float)arg_40h;
        iVar15 = 0x180000000;
        if ((uVar17 & (uint32_t)(float)arg_48h) != 0) {
            if (uVar14 < 2) {
                arg_38h = (uint64_t)(uint32_t)arg_38h._4_4_ << 0x20;
                uVar9 = 4;
                iVar16 = 0;
            } else {
                arg_38h = CONCAT44(arg_38h._4_4_, 1);
                uVar9 = 3;
                iVar16 = 4;
            }
            var_20h = (int64_t)*(uint32_t *)(iVar7 + 0x15d4);
            func_0x0001800ff770(unaff_RBP + -0x70);
            arg_68h._0_4_ = uVar14 + 4;
            piVar12 = &arg_68h;
            uVar17 = ~*(uint32_t *)(*(int64_t *)(unaff_RDI + 0x150) + -4 + (int64_t)*(int32_t *)(unaff_RDI + 0x148) * 4)
            ;
            do {
                uVar1 = *(uint8_t *)piVar12;
                piVar12 = (int64_t *)((int64_t)piVar12 + 1);
                uVar17 = uVar17 >> 8 ^
                         *(uint32_t *)(iVar15 + 0x618620 + ((uint64_t)(uVar17 & 0xff) ^ (uint64_t)uVar1) * 4);
            } while (piVar12 < (int64_t *)((int64_t)&arg_68h + 4U));
            func_0x00018010b530(unaff_RBP + -0x70, ~uVar17, 0, 2, var_20h);
            func_0x000180139d40(unaff_RBP + -0x70, ~uVar17, unaff_RBP + 0xa0, &arg_30h, 0x40800);
            if (*(char *)(unaff_RBP + 0xa0) == '\0') {
code_r0x00018010002f:
                if ((char)arg_30h != '\0') goto code_r0x00018010003a;
            } else {
                if (*(float *)(iVar7 + 0x1648) <= 0.04) {
                    *(undefined *)(unaff_RBP + 0xa0) = 0;
                    goto code_r0x00018010002f;
                }
code_r0x00018010003a:
                *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2650) = uVar9;
                if ((char)arg_30h != '\0') {
                    if (*(char *)(iVar7 + 0xb55) == '\0') {
                        iVar15 = *(int64_t *)(iVar7 + 0x1608);
                        iVar16 = (uint64_t)uVar14 * 0x1c;
                        if ((iVar15 == 0) ||
                           (iVar10 = unaff_RDI, *(int32_t *)(iVar7 + 0x161c) != *(int32_t *)(iVar7 + 4))) {
code_r0x00018010011c:
                            bVar19 = false;
                        } else {
                            do {
                                iVar3 = *(int64_t *)(*(int64_t *)(iVar10 + 0x418) + 0x428);
                                bVar19 = iVar10 != iVar3;
                                iVar10 = iVar3;
                            } while (bVar19);
                            iVar10 = unaff_RDI;
                            if (iVar3 != iVar15) {
                                do {
                                    if (iVar10 == iVar15) goto code_r0x000180100247;
                                } while ((iVar10 != iVar3) &&
                                        (piVar12 = (int64_t *)(iVar10 + 0x408), iVar10 = *piVar12, *piVar12 != 0));
                                goto code_r0x00018010011c;
                            }
code_r0x000180100247:
                            bVar19 = true;
                        }
                        if ((*(char *)(iVar7 + 0x1660) != '\0') || (bVar19)) {
                            uVar9 = *(undefined4 *)(unaff_RBP + -0x70);
                            uVar4 = *(undefined4 *)(unaff_RBP + -0x6c);
                            uVar5 = *(undefined4 *)(unaff_RBP + -0x68);
                            uVar6 = *(undefined4 *)(unaff_RBP + -100);
                            *(undefined *)(iVar7 + 0x27fc) = 0;
                            *(undefined4 *)(iVar7 + 0x27ec) = uVar9;
                            *(undefined4 *)(iVar7 + 0x27f0) = uVar4;
                            *(undefined4 *)(iVar7 + 0x27f4) = uVar5;
                            *(undefined4 *)(iVar7 + 0x27f8) = uVar6;
                        }
                        if (((*(uint32_t *)(unaff_RDI + 0x14) & 0x1000000) != 0) &&
                           ((*(int64_t *)(iVar7 + 0x27ec) != *(int64_t *)(unaff_RBP + -0x70) ||
                            (*(int64_t *)(iVar7 + 0x27f4) != *(int64_t *)(unaff_RBP + -0x68))))) {
                            *(undefined *)(iVar7 + 0x27fc) = 1;
                        }
                        uVar13 = arg_38h & 0xffffffff;
                        fVar22 = *(float *)(iVar16 + 0x180618478);
                        if (*(float *)(iVar16 + 0x180618480) <= *(float *)(iVar16 + 0x180618478)) {
                            fVar22 = *(float *)(iVar16 + 0x180618480);
                        }
                        fVar24 = *(float *)(iVar16 + 0x18061847c);
                        if (*(float *)(iVar16 + 0x180618484) <= *(float *)(iVar16 + 0x18061847c)) {
                            fVar24 = *(float *)(iVar16 + 0x180618484);
                        }
                        fVar30 = *(float *)(unaff_RDI + 0x6c);
                        fVar25 = (*(float *)(iVar7 + 0x118 + uVar13 * 4) - *(float *)(iVar7 + 0x166c + uVar13 * 4)) +
                                 *(float *)(iVar7 + 0x15d4);
                        fVar21 = *(float *)(unaff_RDI + 100);
                        arg_78h._0_4_ = fVar22 * *(float *)(unaff_RDI + 0x68) + *(float *)(unaff_RDI + 0x60);
                        arg_38h = *(int64_t *)(unaff_RDI + 0x60);
                        *(float *)((int64_t)&arg_38h + uVar13 * 4) = fVar25;
                        bVar19 = false;
                        arg_78h._4_4_ = fVar24 * fVar30 + fVar21;
                        if (*(char *)(iVar7 + 0x27fc) != '\0') {
                            fVar30 = *(float *)(iVar7 + 0x104 + uVar13 * 4);
                            fVar21 = fVar30 + *(float *)((int64_t)&arg_78h + uVar13 * 4);
                            *(float *)((int64_t)&arg_38h + uVar13 * 4) = fVar21;
                            if ((fVar30 == 0.0) || (0.0 < fVar30 == fVar25 < fVar21)) {
                                bVar19 = true;
                            }
                        }
                        fVar30 = fVar31;
                        if ((uVar14 != 3) && ((uVar14 != 2 || (arg_30h._3_1_ == '\0')))) {
                            fVar30 = -3.402823e+38;
                        }
                        if (uVar14 == 1) {
                            fVar21 = fVar29;
                            fVar8 = 3.402823e+38;
code_r0x000180100264:
                            fVar26 = fVar8;
                            fVar28 = 3.402823e+38;
                            fVar25 = fVar21;
                        } else {
                            fVar25 = -3.402823e+38;
                            fVar21 = -3.402823e+38;
                            fVar8 = fVar27;
                            if (uVar14 == 2) goto code_r0x000180100264;
                            fVar26 = 3.402823e+38;
                            fVar28 = fVar23;
                            fVar8 = 3.402823e+38;
                            if (uVar14 != 0) goto code_r0x000180100264;
                        }
                        if ((fVar30 <= arg_38h._4_4_) && (fVar30 = fVar26, arg_38h._4_4_ <= fVar26)) {
                            fVar30 = arg_38h._4_4_;
                        }
                        if ((fVar25 <= (float)arg_38h) && (fVar25 = fVar28, (float)arg_38h <= fVar28)) {
                            fVar25 = (float)arg_38h;
                        }
                        arg_38h = CONCAT44(fVar30, fVar25);
                        if (!bVar19) {
                            arg_58h._0_4_ = fVar22;
                            arg_58h._4_4_ = fVar24;
                            func_0x0001800ff590();
                        }
                    } else {
                        if ((uVar14 - 1 & 0xfffffffd) == 0) {
                            func_0x0001800ff2b0(unaff_RBP + -0x60);
                            iVar15 = func_0x0001800ff010(unaff_RBP + -0x58);
                            *(undefined4 *)((int64_t)&arg_50h + (arg_38h & 0xffffffffU) * 4) =
                                 *(undefined4 *)(iVar15 + iVar16);
                            arg_48h._4_4_ = arg_48h._4_4_ | 1 << ((uint32_t)(float)arg_38h & 0x1f);
                            arg_30h._0_1_ = '\0';
                            *(undefined *)(unaff_RBP + 0xa0) = 0;
                        }
                        func_0x0001800f9f30(0, 0);
                    }
                }
            }
            if (*(char *)(unaff_RBP + 0xa0) != '\0') {
                **(uint32_t **)(unaff_RBP + 0xa8) = uVar14;
            }
            unaff_RBX = *(uint32_t **)(unaff_RBP + 0xb0);
            uVar17 = (uint32_t)arg_40h._4_4_;
            if ((char)arg_30h != '\0') {
                *unaff_RBX = uVar14;
            }
        }
        arg_48h._0_4_ = (float)((int32_t)(float)arg_48h << 1 | (uint32_t)((int32_t)(float)arg_48h < 0));
        uVar14 = uVar14 + 1;
    } while ((int32_t)uVar14 < 4);
    iVar2 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
    if (iVar2 < 2) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
        }
    } else {
        *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar2 + -1;
    }
    *(undefined4 *)(unaff_RDI + 0x1b0) = 0;
    iVar15 = *(int64_t *)0x180781f28;
    if ((*(int64_t *)(iVar7 + 0x23c0) != 0) && (*(int64_t *)(*(int64_t *)(iVar7 + 0x23c0) + 0x428) == unaff_RDI)) {
        if (*(int32_t *)(iVar7 + 0x2228) == 2) {
            if (*(char *)(iVar7 + 0x139) == '\0') goto code_r0x00018010059a;
            fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x16c) - *(float *)(*(int64_t *)0x180781f28 + 0x15c);
            fVar27 = *(float *)(*(int64_t *)0x180781f28 + 0x18c) - *(float *)(*(int64_t *)0x180781f28 + 0x17c);
        } else {
            if (*(int32_t *)(iVar7 + 0x2228) != 3) goto code_r0x00018010059a;
            fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x93c) - *(float *)(*(int64_t *)0x180781f28 + 0x92c);
            fVar27 = *(float *)(*(int64_t *)0x180781f28 + 0x95c) - *(float *)(*(int64_t *)0x180781f28 + 0x94c);
        }
        if ((fVar23 != 0.0) || (fVar27 != 0.0)) {
            fVar22 = *(float *)(iVar7 + 0x48) * 600.0 * *(float *)(*(int64_t *)0x180781f28 + 0x12c4);
            fVar27 = fVar22 * fVar27 + *(float *)(iVar7 + 0x23f8);
            fVar23 = fVar22 * fVar23 + *(float *)(iVar7 + 0x23f4);
            *(float *)(iVar7 + 0x23f8) = fVar27;
            *(float *)(iVar7 + 0x23f4) = fVar23;
            fVar31 = (fVar31 - *(float *)(unaff_RDI + 100)) - *(float *)(unaff_RDI + 0x6c);
            fVar29 = (fVar29 - *(float *)(unaff_RDI + 0x60)) - *(float *)(unaff_RDI + 0x68);
            *(undefined *)(iVar7 + 0x23e4) = 0;
            *(undefined *)(iVar7 + 0x21cd) = 1;
            if (fVar27 <= fVar31) {
                fVar27 = fVar31;
            }
            if (fVar23 <= fVar29) {
                fVar23 = fVar29;
            }
            *(float *)(iVar7 + 0x23f8) = fVar27;
            *(float *)(iVar7 + 0x23f4) = fVar23;
            uVar9 = *(undefined4 *)(iVar15 + 0x10d4);
            uVar4 = *(undefined4 *)(iVar15 + 0x10d8);
            fVar23 = *(float *)(iVar15 + 0x10dc);
            *(undefined4 *)(unaff_RBP + -0x58) = *(undefined4 *)(iVar15 + 0x10d0);
            *(undefined4 *)(unaff_RBP + -0x54) = uVar9;
            *(undefined4 *)(unaff_RBP + -0x50) = uVar4;
            *(float *)(unaff_RBP + -0x4c) = fVar23;
            *(float *)(unaff_RBP + -0x4c) = fVar23 * *(float *)(iVar15 + 0xd9c);
            uVar9 = func_0x0001800f5fa0(unaff_RBP + -0x58);
            **(undefined4 **)(unaff_RBP + 0xc0) = uVar9;
            fVar29 = (float)(int32_t)*(float *)(iVar7 + 0x23f4);
            fVar23 = (float)(int32_t)*(float *)(iVar7 + 0x23f8);
            if ((fVar29 != 0.0) || (fVar23 != 0.0)) {
                arg_58h._0_4_ = fVar29 + *(float *)(unaff_RDI + 0x70);
                arg_58h._4_4_ = fVar23 + *(float *)(unaff_RDI + 0x74);
                piVar12 = (int64_t *)func_0x0001800ff010(unaff_RBP + -0x58, arg_58h._4_4_, &arg_58h);
                arg_50h = *piVar12;
                *(float *)(iVar7 + 0x23f4) = *(float *)(iVar7 + 0x23f4) - fVar29;
                *(float *)(iVar7 + 0x23f8) = *(float *)(iVar7 + 0x23f8) - fVar23;
            }
        }
    }
code_r0x00018010059a:
    fVar23 = *(float *)(unaff_RDI + 0x60);
    fVar29 = *(float *)(unaff_RDI + 100);
    fVar27 = *(float *)(unaff_RDI + 0x70);
    fVar31 = *(float *)(unaff_RDI + 0x74);
    fVar22 = fVar27;
    if (((float)arg_50h != 3.402823e+38) &&
       ((*(float *)(unaff_RDI + 0x68) != (float)arg_50h || (fVar27 != (float)arg_50h)))) {
        *(float *)(unaff_RDI + 0x70) = (float)arg_50h;
        *(float *)(unaff_RDI + 0x68) = (float)arg_50h;
        fVar22 = (float)arg_50h;
    }
    if ((arg_50h._4_4_ != 3.402823e+38) &&
       ((*(float *)(unaff_RDI + 0x6c) != arg_50h._4_4_ || (*(float *)(unaff_RDI + 0x74) != arg_50h._4_4_)))) {
        *(float *)(unaff_RDI + 0x74) = arg_50h._4_4_;
        *(float *)(unaff_RDI + 0x6c) = arg_50h._4_4_;
    }
    if (((float)arg_70h != 3.402823e+38) && (fVar23 != (float)(int32_t)(float)arg_70h)) {
        *(float *)(unaff_RDI + 0x60) = (float)(int32_t)(float)arg_70h;
    }
    if ((arg_70h._4_4_ != 3.402823e+38) && (*(float *)(unaff_RDI + 100) != (float)(int32_t)arg_70h._4_4_)) {
        *(float *)(unaff_RDI + 100) = (float)(int32_t)arg_70h._4_4_;
    }
    if (((((fVar23 != *(float *)(unaff_RDI + 0x60)) || (fVar29 != *(float *)(unaff_RDI + 100))) || (fVar27 != fVar22))
        || (fVar31 != *(float *)(unaff_RDI + 0x74))) &&
       (((*(uint32_t *)(unaff_RDI + 0x14) & 0x100) == 0 && (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0)))) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
    }
    if (*unaff_RBX != 0xffffffff) {
        var_20h = (int64_t)*(uint32_t *)(iVar7 + 0x15d4);
        puVar11 = (undefined4 *)func_0x0001800ff770(unaff_RBP + -0x70, fVar22, *unaff_RBX, fVar20, var_20h);
        uVar9 = puVar11[1];
        uVar4 = puVar11[2];
        uVar5 = puVar11[3];
        *(undefined4 *)(iVar7 + 0x27ec) = *puVar11;
        *(undefined4 *)(iVar7 + 0x27f0) = uVar9;
        *(undefined4 *)(iVar7 + 0x27f4) = uVar4;
        *(undefined4 *)(iVar7 + 0x27f8) = uVar5;
    }
    return arg_48h._4_4_;
}

// ============================================================
// Function: FUN_1800ffae1
// Address: 0x1800ffae1
// Size: 2220 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: arg_1b8h
// WARNING: Variable defined which should be unmapped: arg_170h
// WARNING: Variable defined which should be unmapped: arg_168h
// WARNING: Variable defined which should be unmapped: arg_160h
// WARNING: Variable defined which should be unmapped: arg_150h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h
// WARNING: [rz-ghidra] Detected overlap for variable arg_33h
// WARNING: [rz-ghidra] Detected overlap for variable arg_74h
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_7ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Detected overlap for variable arg_31h
// WARNING: [rz-ghidra] Detected overlap for variable arg_32h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

uint32_t fcn.1800ff916(int64_t arg_30h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                      int64_t arg_70h, int64_t arg_78h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h,
                      int64_t arg_c0h, int64_t arg_c8h, int64_t arg_d0h, int64_t arg_e0h, int64_t arg_f0h,
                      int64_t arg_100h, int64_t arg_110h, int64_t arg_120h, int64_t arg_130h, int64_t arg_140h,
                      int64_t arg_150h, int64_t arg_160h, int64_t arg_168h, int64_t arg_170h, int64_t arg_1b8h)
{
    uint8_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    float fVar8;
    undefined4 uVar9;
    int64_t iVar10;
    undefined4 *puVar11;
    uint64_t in_RCX;
    int64_t *piVar12;
    uint64_t uVar13;
    uint32_t uVar14;
    uint32_t *unaff_RBX;
    int64_t unaff_RBP;
    int64_t unaff_RDI;
    int64_t iVar15;
    int32_t unaff_R13D;
    int64_t iVar16;
    uint32_t uVar17;
    float *pfVar18;
    bool bVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    float fVar31;
    int64_t var_20h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_4ch;
    
    iVar7 = *(int64_t *)0x180781f28;
    arg_48h._4_4_ = 0;
    if (unaff_R13D < 1) {
        fVar23 = 0.0;
    } else {
        fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) * 1.35;
        fVar20 = *(float *)(unaff_RDI + 0x98) + 1.0 + *(float *)(*(int64_t *)0x180781f28 + 0x12f8) * 0.2;
        if (fVar23 <= fVar20) {
            fVar23 = fVar20;
        }
        fVar23 = (float)(int32_t)((float)(int32_t)fVar23 * 0.75);
    }
    pfVar18 = *(float **)(unaff_RBP + 200);
    fVar20 = *(float *)(*(int64_t *)0x180781f28 + 0x15d4);
    fVar29 = *pfVar18;
    fVar27 = pfVar18[3];
    fVar31 = pfVar18[1];
    arg_38h = CONCAT44(arg_38h._4_4_, pfVar18[2]);
    if (((*(uint8_t *)(unaff_RDI + 0x130) & 1) == 0) && ((in_RCX & 1) == 0)) {
        fVar31 = fVar31 - *(float *)(unaff_RDI + 0xa0);
        arg_30h._3_1_ = '\x01';
    } else {
        arg_30h._3_1_ = '\0';
    }
    uVar17 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x34);
    *(float *)(unaff_RBP + 0xa0) = fVar31;
    arg_70h._0_4_ = 3.402823e+38;
    arg_70h._4_4_ = 3.402823e+38;
    arg_50h = 0x7f7fffff7f7fffff;
    if ((((uVar17 & 0x1000) == 0) || (*(int32_t *)(iVar7 + 0x134) != *(int32_t *)(unaff_RDI + 0x50))) ||
       ((*(uint8_t *)(*(int64_t *)(unaff_RDI + 0x48) + 4) & 8) == 0)) {
        iVar15 = *(int64_t *)(unaff_RDI + 0x48);
        fVar22 = *(float *)(iVar15 + 8);
        fVar24 = *(float *)(iVar15 + 0xc);
        fVar30 = *(float *)(iVar15 + 0x10);
        fVar21 = *(float *)(iVar15 + 0x14);
        *(float *)(unaff_RDI + 0x2b8) = fVar22;
        *(float *)(unaff_RDI + 700) = fVar24;
        *(float *)(unaff_RDI + 0x2c0) = fVar22 + fVar30;
        *(float *)(unaff_RDI + 0x2c4) = fVar24 + fVar21;
    }
    *(undefined4 *)(unaff_RDI + 0x1b0) = 1;
    arg_40h._0_4_ = fVar23;
    arg_40h._4_4_ = fVar27;
    arg_48h._0_4_ = fVar29;
    func_0x000180107590();
    uVar17 = 0;
    if (0 < unaff_R13D) {
        iVar15 = 0;
        do {
            fVar29 = *(float *)(unaff_RDI + 0x60);
            fVar27 = *(float *)(unaff_RDI + 100);
            iVar16 = iVar15 * 0x18;
            fVar22 = *(float *)(iVar15 * 0x18 + 0x1806185cc);
            fVar24 = *(float *)(iVar15 * 0x18 + 0x1806185c8);
            pfVar18 = (float *)(iVar16 + 0x1806185c0);
            fVar29 = ((fVar29 + *(float *)(unaff_RDI + 0x68)) - fVar29) * *pfVar18 + fVar29;
            fVar30 = fVar23 * fVar24 + fVar29;
            fVar27 = ((fVar27 + *(float *)(unaff_RDI + 0x6c)) - fVar27) * *(float *)(iVar15 * 0x18 + 0x1806185c4) +
                     fVar27;
            fVar29 = fVar29 - fVar20 * fVar24;
            *(float *)(unaff_RBP + -0x78) = fVar30;
            fVar23 = fVar22 * (float)arg_40h + fVar27;
            fVar27 = fVar27 - fVar22 * fVar20;
            *(float *)(unaff_RBP + -0x80) = fVar29;
            *(float *)(unaff_RBP + -0x74) = fVar23;
            *(float *)(unaff_RBP + -0x7c) = fVar27;
            if (fVar30 < fVar29) {
                *(float *)(unaff_RBP + -0x80) = fVar30;
                *(float *)(unaff_RBP + -0x78) = fVar29;
            }
            if (fVar23 < fVar27) {
                *(float *)(unaff_RBP + -0x7c) = fVar23;
                *(float *)(unaff_RBP + -0x74) = fVar27;
            }
            piVar12 = &arg_60h;
            arg_60h._0_4_ = uVar17;
            uVar14 = ~*(uint32_t *)(*(int64_t *)(unaff_RDI + 0x150) + -4 + (int64_t)*(int32_t *)(unaff_RDI + 0x148) * 4)
            ;
            do {
                uVar1 = *(uint8_t *)piVar12;
                piVar12 = (int64_t *)((int64_t)piVar12 + 1);
                uVar14 = uVar14 >> 8 ^ *(uint32_t *)(((uint64_t)(uVar14 & 0xff) ^ (uint64_t)uVar1) * 4 + 0x180618620);
            } while (piVar12 < (int64_t *)((int64_t)&arg_60h + 4U));
            func_0x00018010b530(unaff_RBP + -0x80, ~uVar14, 0, 2);
            func_0x000180139d40(unaff_RBP + -0x80, ~uVar14, (int64_t)&arg_30h + 2, (int64_t)&arg_30h + 1, 0x40800);
            if ((arg_30h._2_1_ == '\0') && (arg_30h._1_1_ == '\0')) {
code_r0x0001800ffe50:
                if ((uVar17 == 0) && ((*(uint32_t *)(unaff_RDI + 0x14) & 0x1000000) == 0)) goto code_r0x0001800ffe5e;
            } else {
                *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2650) = (~uVar17 & 1) + 5;
                if (arg_30h._1_1_ == '\0') {
code_r0x0001800ffe47:
                    if (arg_30h._2_1_ == '\0') goto code_r0x0001800ffe50;
                } else {
                    if (*(char *)(iVar7 + 0xb55) == '\0') {
                        fVar23 = *(float *)(iVar16 + 0x1806185c4);
                        if ((fVar23 != 1.0) && ((fVar23 != 0.0 || (arg_30h._3_1_ == '\0')))) {
                            fVar31 = -3.402823e+38;
                        }
                        fVar29 = *pfVar18;
                        arg_78h._0_4_ = (float)arg_48h;
                        if (fVar29 != 1.0) {
                            arg_78h._0_4_ = -3.402823e+38;
                        }
                        fVar27 = arg_40h._4_4_;
                        if (fVar23 != 0.0) {
                            fVar27 = 3.402823e+38;
                        }
                        fVar22 = 3.402823e+38;
                        if (fVar29 == 0.0) {
                            fVar22 = (float)arg_38h;
                        }
                        fVar30 = *(float *)(iVar16 + 0x1806185cc) * fVar20;
                        fVar24 = *(float *)(iVar16 + 0x1806185c8) * fVar20;
                        fVar24 = ((float)((uint32_t)(float)arg_40h ^ 0x80000000) * *(float *)(iVar16 + 0x1806185c8) -
                                 fVar24) * fVar29 + fVar24;
                        fVar23 = (*(float *)(iVar7 + 0x11c) - *(float *)(iVar7 + 0x1670)) +
                                 ((float)((uint32_t)(float)arg_40h ^ 0x80000000) * *(float *)(iVar16 + 0x1806185cc) -
                                 fVar30) * fVar23 + fVar30;
                        fVar29 = (*(float *)(iVar7 + 0x118) - *(float *)(iVar7 + 0x166c)) + fVar24;
                        arg_78h._4_4_ = fVar31;
                        if ((fVar31 <= fVar23) && (arg_78h._4_4_ = fVar27, fVar23 <= fVar27)) {
                            arg_78h._4_4_ = fVar23;
                        }
                        if (((float)arg_78h <= fVar29) && (arg_78h._0_4_ = fVar22, fVar29 <= fVar22)) {
                            arg_78h._0_4_ = fVar29;
                        }
                        func_0x0001800ff590(fVar24, &arg_78h, pfVar18, &arg_70h, &arg_50h);
                        fVar31 = *(float *)(unaff_RBP + 0xa0);
                    } else {
                        func_0x0001800ff2b0(&arg_58h);
                        piVar12 = (int64_t *)func_0x0001800ff010(unaff_RBP + -0x60);
                        arg_48h._4_4_ = 3;
                        arg_50h = *piVar12;
                        func_0x0001800f9f30(0, 0);
                    }
                    if (arg_30h._1_1_ == '\0') goto code_r0x0001800ffe47;
                }
code_r0x0001800ffe5e:
                iVar16 = *(int64_t *)0x180781f28;
                if (arg_30h._1_1_ == '\0') {
                    iVar10 = (uint64_t)(arg_30h._2_1_ != '\0') + 0x1e;
                } else {
                    iVar10 = 0x20;
                }
                puVar11 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar10 + 0x14) * 0x10);
                uVar9 = puVar11[1];
                uVar4 = puVar11[2];
                fVar23 = (float)puVar11[3];
                *(undefined4 *)(unaff_RBP + -0x70) = *puVar11;
                *(undefined4 *)(unaff_RBP + -0x6c) = uVar9;
                *(undefined4 *)(unaff_RBP + -0x68) = uVar4;
                *(float *)(unaff_RBP + -100) = fVar23;
                *(float *)(unaff_RBP + -100) = fVar23 * *(float *)(iVar16 + 0xd9c);
                uVar9 = func_0x0001800f5fa0(unaff_RBP + -0x70);
                *(undefined4 *)(*(int64_t *)(unaff_RBP + 0xc0) + iVar15 * 4) = uVar9;
            }
            uVar17 = uVar17 + 1;
            iVar15 = iVar15 + 1;
            fVar23 = (float)arg_40h;
        } while ((int32_t)uVar17 < unaff_R13D);
        unaff_RBX = *(uint32_t **)(unaff_RBP + 0xb0);
        fVar29 = (float)arg_48h;
        fVar27 = arg_40h._4_4_;
    }
    if ((*(uint32_t *)(unaff_RDI + 0x14) & 0x1000000) == 0) {
        uVar17 = -(uint32_t)(*(char *)(iVar7 + 0x92) != '\0') & 0xf;
    } else {
        uVar17 = *(uint32_t *)(unaff_RDI + 0x1c) >> 1 & 2 | *(uint32_t *)(unaff_RDI + 0x1c) & 8;
    }
    fVar23 = (float)arg_38h;
    uVar14 = 0;
    arg_48h._0_4_ = 1.401298e-45;
    arg_40h._4_4_ = (float)uVar17;
    do {
        fVar20 = (float)arg_40h;
        iVar15 = 0x180000000;
        if ((uVar17 & (uint32_t)(float)arg_48h) != 0) {
            if (uVar14 < 2) {
                arg_38h = (uint64_t)(uint32_t)arg_38h._4_4_ << 0x20;
                uVar9 = 4;
                iVar16 = 0;
            } else {
                arg_38h = CONCAT44(arg_38h._4_4_, 1);
                uVar9 = 3;
                iVar16 = 4;
            }
            var_20h = (int64_t)*(uint32_t *)(iVar7 + 0x15d4);
            func_0x0001800ff770(unaff_RBP + -0x70);
            arg_68h._0_4_ = uVar14 + 4;
            piVar12 = &arg_68h;
            uVar17 = ~*(uint32_t *)(*(int64_t *)(unaff_RDI + 0x150) + -4 + (int64_t)*(int32_t *)(unaff_RDI + 0x148) * 4)
            ;
            do {
                uVar1 = *(uint8_t *)piVar12;
                piVar12 = (int64_t *)((int64_t)piVar12 + 1);
                uVar17 = uVar17 >> 8 ^
                         *(uint32_t *)(iVar15 + 0x618620 + ((uint64_t)(uVar17 & 0xff) ^ (uint64_t)uVar1) * 4);
            } while (piVar12 < (int64_t *)((int64_t)&arg_68h + 4U));
            func_0x00018010b530(unaff_RBP + -0x70, ~uVar17, 0, 2, var_20h);
            func_0x000180139d40(unaff_RBP + -0x70, ~uVar17, unaff_RBP + 0xa0, &arg_30h, 0x40800);
            if (*(char *)(unaff_RBP + 0xa0) == '\0') {
code_r0x00018010002f:
                if ((char)arg_30h != '\0') goto code_r0x00018010003a;
            } else {
                if (*(float *)(iVar7 + 0x1648) <= 0.04) {
                    *(undefined *)(unaff_RBP + 0xa0) = 0;
                    goto code_r0x00018010002f;
                }
code_r0x00018010003a:
                *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2650) = uVar9;
                if ((char)arg_30h != '\0') {
                    if (*(char *)(iVar7 + 0xb55) == '\0') {
                        iVar15 = *(int64_t *)(iVar7 + 0x1608);
                        iVar16 = (uint64_t)uVar14 * 0x1c;
                        if ((iVar15 == 0) ||
                           (iVar10 = unaff_RDI, *(int32_t *)(iVar7 + 0x161c) != *(int32_t *)(iVar7 + 4))) {
code_r0x00018010011c:
                            bVar19 = false;
                        } else {
                            do {
                                iVar3 = *(int64_t *)(*(int64_t *)(iVar10 + 0x418) + 0x428);
                                bVar19 = iVar10 != iVar3;
                                iVar10 = iVar3;
                            } while (bVar19);
                            iVar10 = unaff_RDI;
                            if (iVar3 != iVar15) {
                                do {
                                    if (iVar10 == iVar15) goto code_r0x000180100247;
                                } while ((iVar10 != iVar3) &&
                                        (piVar12 = (int64_t *)(iVar10 + 0x408), iVar10 = *piVar12, *piVar12 != 0));
                                goto code_r0x00018010011c;
                            }
code_r0x000180100247:
                            bVar19 = true;
                        }
                        if ((*(char *)(iVar7 + 0x1660) != '\0') || (bVar19)) {
                            uVar9 = *(undefined4 *)(unaff_RBP + -0x70);
                            uVar4 = *(undefined4 *)(unaff_RBP + -0x6c);
                            uVar5 = *(undefined4 *)(unaff_RBP + -0x68);
                            uVar6 = *(undefined4 *)(unaff_RBP + -100);
                            *(undefined *)(iVar7 + 0x27fc) = 0;
                            *(undefined4 *)(iVar7 + 0x27ec) = uVar9;
                            *(undefined4 *)(iVar7 + 0x27f0) = uVar4;
                            *(undefined4 *)(iVar7 + 0x27f4) = uVar5;
                            *(undefined4 *)(iVar7 + 0x27f8) = uVar6;
                        }
                        if (((*(uint32_t *)(unaff_RDI + 0x14) & 0x1000000) != 0) &&
                           ((*(int64_t *)(iVar7 + 0x27ec) != *(int64_t *)(unaff_RBP + -0x70) ||
                            (*(int64_t *)(iVar7 + 0x27f4) != *(int64_t *)(unaff_RBP + -0x68))))) {
                            *(undefined *)(iVar7 + 0x27fc) = 1;
                        }
                        uVar13 = arg_38h & 0xffffffff;
                        fVar22 = *(float *)(iVar16 + 0x180618478);
                        if (*(float *)(iVar16 + 0x180618480) <= *(float *)(iVar16 + 0x180618478)) {
                            fVar22 = *(float *)(iVar16 + 0x180618480);
                        }
                        fVar24 = *(float *)(iVar16 + 0x18061847c);
                        if (*(float *)(iVar16 + 0x180618484) <= *(float *)(iVar16 + 0x18061847c)) {
                            fVar24 = *(float *)(iVar16 + 0x180618484);
                        }
                        fVar30 = *(float *)(unaff_RDI + 0x6c);
                        fVar25 = (*(float *)(iVar7 + 0x118 + uVar13 * 4) - *(float *)(iVar7 + 0x166c + uVar13 * 4)) +
                                 *(float *)(iVar7 + 0x15d4);
                        fVar21 = *(float *)(unaff_RDI + 100);
                        arg_78h._0_4_ = fVar22 * *(float *)(unaff_RDI + 0x68) + *(float *)(unaff_RDI + 0x60);
                        arg_38h = *(int64_t *)(unaff_RDI + 0x60);
                        *(float *)((int64_t)&arg_38h + uVar13 * 4) = fVar25;
                        bVar19 = false;
                        arg_78h._4_4_ = fVar24 * fVar30 + fVar21;
                        if (*(char *)(iVar7 + 0x27fc) != '\0') {
                            fVar30 = *(float *)(iVar7 + 0x104 + uVar13 * 4);
                            fVar21 = fVar30 + *(float *)((int64_t)&arg_78h + uVar13 * 4);
                            *(float *)((int64_t)&arg_38h + uVar13 * 4) = fVar21;
                            if ((fVar30 == 0.0) || (0.0 < fVar30 == fVar25 < fVar21)) {
                                bVar19 = true;
                            }
                        }
                        fVar30 = fVar31;
                        if ((uVar14 != 3) && ((uVar14 != 2 || (arg_30h._3_1_ == '\0')))) {
                            fVar30 = -3.402823e+38;
                        }
                        if (uVar14 == 1) {
                            fVar21 = fVar29;
                            fVar8 = 3.402823e+38;
code_r0x000180100264:
                            fVar26 = fVar8;
                            fVar28 = 3.402823e+38;
                            fVar25 = fVar21;
                        } else {
                            fVar25 = -3.402823e+38;
                            fVar21 = -3.402823e+38;
                            fVar8 = fVar27;
                            if (uVar14 == 2) goto code_r0x000180100264;
                            fVar26 = 3.402823e+38;
                            fVar28 = fVar23;
                            fVar8 = 3.402823e+38;
                            if (uVar14 != 0) goto code_r0x000180100264;
                        }
                        if ((fVar30 <= arg_38h._4_4_) && (fVar30 = fVar26, arg_38h._4_4_ <= fVar26)) {
                            fVar30 = arg_38h._4_4_;
                        }
                        if ((fVar25 <= (float)arg_38h) && (fVar25 = fVar28, (float)arg_38h <= fVar28)) {
                            fVar25 = (float)arg_38h;
                        }
                        arg_38h = CONCAT44(fVar30, fVar25);
                        if (!bVar19) {
                            arg_58h._0_4_ = fVar22;
                            arg_58h._4_4_ = fVar24;
                            func_0x0001800ff590();
                        }
                    } else {
                        if ((uVar14 - 1 & 0xfffffffd) == 0) {
                            func_0x0001800ff2b0(unaff_RBP + -0x60);
                            iVar15 = func_0x0001800ff010(unaff_RBP + -0x58);
                            *(undefined4 *)((int64_t)&arg_50h + (arg_38h & 0xffffffffU) * 4) =
                                 *(undefined4 *)(iVar15 + iVar16);
                            arg_48h._4_4_ = arg_48h._4_4_ | 1 << ((uint32_t)(float)arg_38h & 0x1f);
                            arg_30h._0_1_ = '\0';
                            *(undefined *)(unaff_RBP + 0xa0) = 0;
                        }
                        func_0x0001800f9f30(0, 0);
                    }
                }
            }
            if (*(char *)(unaff_RBP + 0xa0) != '\0') {
                **(uint32_t **)(unaff_RBP + 0xa8) = uVar14;
            }
            unaff_RBX = *(uint32_t **)(unaff_RBP + 0xb0);
            uVar17 = (uint32_t)arg_40h._4_4_;
            if ((char)arg_30h != '\0') {
                *unaff_RBX = uVar14;
            }
        }
        arg_48h._0_4_ = (float)((int32_t)(float)arg_48h << 1 | (uint32_t)((int32_t)(float)arg_48h < 0));
        uVar14 = uVar14 + 1;
    } while ((int32_t)uVar14 < 4);
    iVar2 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
    if (iVar2 < 2) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
        }
    } else {
        *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar2 + -1;
    }
    *(undefined4 *)(unaff_RDI + 0x1b0) = 0;
    iVar15 = *(int64_t *)0x180781f28;
    if ((*(int64_t *)(iVar7 + 0x23c0) != 0) && (*(int64_t *)(*(int64_t *)(iVar7 + 0x23c0) + 0x428) == unaff_RDI)) {
        if (*(int32_t *)(iVar7 + 0x2228) == 2) {
            if (*(char *)(iVar7 + 0x139) == '\0') goto code_r0x00018010059a;
            fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x16c) - *(float *)(*(int64_t *)0x180781f28 + 0x15c);
            fVar27 = *(float *)(*(int64_t *)0x180781f28 + 0x18c) - *(float *)(*(int64_t *)0x180781f28 + 0x17c);
        } else {
            if (*(int32_t *)(iVar7 + 0x2228) != 3) goto code_r0x00018010059a;
            fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x93c) - *(float *)(*(int64_t *)0x180781f28 + 0x92c);
            fVar27 = *(float *)(*(int64_t *)0x180781f28 + 0x95c) - *(float *)(*(int64_t *)0x180781f28 + 0x94c);
        }
        if ((fVar23 != 0.0) || (fVar27 != 0.0)) {
            fVar22 = *(float *)(iVar7 + 0x48) * 600.0 * *(float *)(*(int64_t *)0x180781f28 + 0x12c4);
            fVar27 = fVar22 * fVar27 + *(float *)(iVar7 + 0x23f8);
            fVar23 = fVar22 * fVar23 + *(float *)(iVar7 + 0x23f4);
            *(float *)(iVar7 + 0x23f8) = fVar27;
            *(float *)(iVar7 + 0x23f4) = fVar23;
            fVar31 = (fVar31 - *(float *)(unaff_RDI + 100)) - *(float *)(unaff_RDI + 0x6c);
            fVar29 = (fVar29 - *(float *)(unaff_RDI + 0x60)) - *(float *)(unaff_RDI + 0x68);
            *(undefined *)(iVar7 + 0x23e4) = 0;
            *(undefined *)(iVar7 + 0x21cd) = 1;
            if (fVar27 <= fVar31) {
                fVar27 = fVar31;
            }
            if (fVar23 <= fVar29) {
                fVar23 = fVar29;
            }
            *(float *)(iVar7 + 0x23f8) = fVar27;
            *(float *)(iVar7 + 0x23f4) = fVar23;
            uVar9 = *(undefined4 *)(iVar15 + 0x10d4);
            uVar4 = *(undefined4 *)(iVar15 + 0x10d8);
            fVar23 = *(float *)(iVar15 + 0x10dc);
            *(undefined4 *)(unaff_RBP + -0x58) = *(undefined4 *)(iVar15 + 0x10d0);
            *(undefined4 *)(unaff_RBP + -0x54) = uVar9;
            *(undefined4 *)(unaff_RBP + -0x50) = uVar4;
            *(float *)(unaff_RBP + -0x4c) = fVar23;
            *(float *)(unaff_RBP + -0x4c) = fVar23 * *(float *)(iVar15 + 0xd9c);
            uVar9 = func_0x0001800f5fa0(unaff_RBP + -0x58);
            **(undefined4 **)(unaff_RBP + 0xc0) = uVar9;
            fVar29 = (float)(int32_t)*(float *)(iVar7 + 0x23f4);
            fVar23 = (float)(int32_t)*(float *)(iVar7 + 0x23f8);
            if ((fVar29 != 0.0) || (fVar23 != 0.0)) {
                arg_58h._0_4_ = fVar29 + *(float *)(unaff_RDI + 0x70);
                arg_58h._4_4_ = fVar23 + *(float *)(unaff_RDI + 0x74);
                piVar12 = (int64_t *)func_0x0001800ff010(unaff_RBP + -0x58, arg_58h._4_4_, &arg_58h);
                arg_50h = *piVar12;
                *(float *)(iVar7 + 0x23f4) = *(float *)(iVar7 + 0x23f4) - fVar29;
                *(float *)(iVar7 + 0x23f8) = *(float *)(iVar7 + 0x23f8) - fVar23;
            }
        }
    }
code_r0x00018010059a:
    fVar23 = *(float *)(unaff_RDI + 0x60);
    fVar29 = *(float *)(unaff_RDI + 100);
    fVar27 = *(float *)(unaff_RDI + 0x70);
    fVar31 = *(float *)(unaff_RDI + 0x74);
    fVar22 = fVar27;
    if (((float)arg_50h != 3.402823e+38) &&
       ((*(float *)(unaff_RDI + 0x68) != (float)arg_50h || (fVar27 != (float)arg_50h)))) {
        *(float *)(unaff_RDI + 0x70) = (float)arg_50h;
        *(float *)(unaff_RDI + 0x68) = (float)arg_50h;
        fVar22 = (float)arg_50h;
    }
    if ((arg_50h._4_4_ != 3.402823e+38) &&
       ((*(float *)(unaff_RDI + 0x6c) != arg_50h._4_4_ || (*(float *)(unaff_RDI + 0x74) != arg_50h._4_4_)))) {
        *(float *)(unaff_RDI + 0x74) = arg_50h._4_4_;
        *(float *)(unaff_RDI + 0x6c) = arg_50h._4_4_;
    }
    if (((float)arg_70h != 3.402823e+38) && (fVar23 != (float)(int32_t)(float)arg_70h)) {
        *(float *)(unaff_RDI + 0x60) = (float)(int32_t)(float)arg_70h;
    }
    if ((arg_70h._4_4_ != 3.402823e+38) && (*(float *)(unaff_RDI + 100) != (float)(int32_t)arg_70h._4_4_)) {
        *(float *)(unaff_RDI + 100) = (float)(int32_t)arg_70h._4_4_;
    }
    if (((((fVar23 != *(float *)(unaff_RDI + 0x60)) || (fVar29 != *(float *)(unaff_RDI + 100))) || (fVar27 != fVar22))
        || (fVar31 != *(float *)(unaff_RDI + 0x74))) &&
       (((*(uint32_t *)(unaff_RDI + 0x14) & 0x100) == 0 && (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0)))) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
    }
    if (*unaff_RBX != 0xffffffff) {
        var_20h = (int64_t)*(uint32_t *)(iVar7 + 0x15d4);
        puVar11 = (undefined4 *)func_0x0001800ff770(unaff_RBP + -0x70, fVar22, *unaff_RBX, fVar20, var_20h);
        uVar9 = puVar11[1];
        uVar4 = puVar11[2];
        uVar5 = puVar11[3];
        *(undefined4 *)(iVar7 + 0x27ec) = *puVar11;
        *(undefined4 *)(iVar7 + 0x27f0) = uVar9;
        *(undefined4 *)(iVar7 + 0x27f4) = uVar4;
        *(undefined4 *)(iVar7 + 0x27f8) = uVar5;
    }
    return arg_48h._4_4_;
}

// ============================================================
// Function: FUN_18010038d
// Address: 0x18010038d
// Size: 586 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: arg_1b8h
// WARNING: Variable defined which should be unmapped: arg_170h
// WARNING: Variable defined which should be unmapped: arg_168h
// WARNING: Variable defined which should be unmapped: arg_160h
// WARNING: Variable defined which should be unmapped: arg_150h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h
// WARNING: [rz-ghidra] Detected overlap for variable arg_33h
// WARNING: [rz-ghidra] Detected overlap for variable arg_74h
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_7ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Detected overlap for variable arg_31h
// WARNING: [rz-ghidra] Detected overlap for variable arg_32h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

uint32_t fcn.1800ff916(int64_t arg_30h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                      int64_t arg_70h, int64_t arg_78h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h,
                      int64_t arg_c0h, int64_t arg_c8h, int64_t arg_d0h, int64_t arg_e0h, int64_t arg_f0h,
                      int64_t arg_100h, int64_t arg_110h, int64_t arg_120h, int64_t arg_130h, int64_t arg_140h,
                      int64_t arg_150h, int64_t arg_160h, int64_t arg_168h, int64_t arg_170h, int64_t arg_1b8h)
{
    uint8_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    float fVar8;
    undefined4 uVar9;
    int64_t iVar10;
    undefined4 *puVar11;
    uint64_t in_RCX;
    int64_t *piVar12;
    uint64_t uVar13;
    uint32_t uVar14;
    uint32_t *unaff_RBX;
    int64_t unaff_RBP;
    int64_t unaff_RDI;
    int64_t iVar15;
    int32_t unaff_R13D;
    int64_t iVar16;
    uint32_t uVar17;
    float *pfVar18;
    bool bVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    float fVar31;
    int64_t var_20h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_4ch;
    
    iVar7 = *(int64_t *)0x180781f28;
    arg_48h._4_4_ = 0;
    if (unaff_R13D < 1) {
        fVar23 = 0.0;
    } else {
        fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) * 1.35;
        fVar20 = *(float *)(unaff_RDI + 0x98) + 1.0 + *(float *)(*(int64_t *)0x180781f28 + 0x12f8) * 0.2;
        if (fVar23 <= fVar20) {
            fVar23 = fVar20;
        }
        fVar23 = (float)(int32_t)((float)(int32_t)fVar23 * 0.75);
    }
    pfVar18 = *(float **)(unaff_RBP + 200);
    fVar20 = *(float *)(*(int64_t *)0x180781f28 + 0x15d4);
    fVar29 = *pfVar18;
    fVar27 = pfVar18[3];
    fVar31 = pfVar18[1];
    arg_38h = CONCAT44(arg_38h._4_4_, pfVar18[2]);
    if (((*(uint8_t *)(unaff_RDI + 0x130) & 1) == 0) && ((in_RCX & 1) == 0)) {
        fVar31 = fVar31 - *(float *)(unaff_RDI + 0xa0);
        arg_30h._3_1_ = '\x01';
    } else {
        arg_30h._3_1_ = '\0';
    }
    uVar17 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x34);
    *(float *)(unaff_RBP + 0xa0) = fVar31;
    arg_70h._0_4_ = 3.402823e+38;
    arg_70h._4_4_ = 3.402823e+38;
    arg_50h = 0x7f7fffff7f7fffff;
    if ((((uVar17 & 0x1000) == 0) || (*(int32_t *)(iVar7 + 0x134) != *(int32_t *)(unaff_RDI + 0x50))) ||
       ((*(uint8_t *)(*(int64_t *)(unaff_RDI + 0x48) + 4) & 8) == 0)) {
        iVar15 = *(int64_t *)(unaff_RDI + 0x48);
        fVar22 = *(float *)(iVar15 + 8);
        fVar24 = *(float *)(iVar15 + 0xc);
        fVar30 = *(float *)(iVar15 + 0x10);
        fVar21 = *(float *)(iVar15 + 0x14);
        *(float *)(unaff_RDI + 0x2b8) = fVar22;
        *(float *)(unaff_RDI + 700) = fVar24;
        *(float *)(unaff_RDI + 0x2c0) = fVar22 + fVar30;
        *(float *)(unaff_RDI + 0x2c4) = fVar24 + fVar21;
    }
    *(undefined4 *)(unaff_RDI + 0x1b0) = 1;
    arg_40h._0_4_ = fVar23;
    arg_40h._4_4_ = fVar27;
    arg_48h._0_4_ = fVar29;
    func_0x000180107590();
    uVar17 = 0;
    if (0 < unaff_R13D) {
        iVar15 = 0;
        do {
            fVar29 = *(float *)(unaff_RDI + 0x60);
            fVar27 = *(float *)(unaff_RDI + 100);
            iVar16 = iVar15 * 0x18;
            fVar22 = *(float *)(iVar15 * 0x18 + 0x1806185cc);
            fVar24 = *(float *)(iVar15 * 0x18 + 0x1806185c8);
            pfVar18 = (float *)(iVar16 + 0x1806185c0);
            fVar29 = ((fVar29 + *(float *)(unaff_RDI + 0x68)) - fVar29) * *pfVar18 + fVar29;
            fVar30 = fVar23 * fVar24 + fVar29;
            fVar27 = ((fVar27 + *(float *)(unaff_RDI + 0x6c)) - fVar27) * *(float *)(iVar15 * 0x18 + 0x1806185c4) +
                     fVar27;
            fVar29 = fVar29 - fVar20 * fVar24;
            *(float *)(unaff_RBP + -0x78) = fVar30;
            fVar23 = fVar22 * (float)arg_40h + fVar27;
            fVar27 = fVar27 - fVar22 * fVar20;
            *(float *)(unaff_RBP + -0x80) = fVar29;
            *(float *)(unaff_RBP + -0x74) = fVar23;
            *(float *)(unaff_RBP + -0x7c) = fVar27;
            if (fVar30 < fVar29) {
                *(float *)(unaff_RBP + -0x80) = fVar30;
                *(float *)(unaff_RBP + -0x78) = fVar29;
            }
            if (fVar23 < fVar27) {
                *(float *)(unaff_RBP + -0x7c) = fVar23;
                *(float *)(unaff_RBP + -0x74) = fVar27;
            }
            piVar12 = &arg_60h;
            arg_60h._0_4_ = uVar17;
            uVar14 = ~*(uint32_t *)(*(int64_t *)(unaff_RDI + 0x150) + -4 + (int64_t)*(int32_t *)(unaff_RDI + 0x148) * 4)
            ;
            do {
                uVar1 = *(uint8_t *)piVar12;
                piVar12 = (int64_t *)((int64_t)piVar12 + 1);
                uVar14 = uVar14 >> 8 ^ *(uint32_t *)(((uint64_t)(uVar14 & 0xff) ^ (uint64_t)uVar1) * 4 + 0x180618620);
            } while (piVar12 < (int64_t *)((int64_t)&arg_60h + 4U));
            func_0x00018010b530(unaff_RBP + -0x80, ~uVar14, 0, 2);
            func_0x000180139d40(unaff_RBP + -0x80, ~uVar14, (int64_t)&arg_30h + 2, (int64_t)&arg_30h + 1, 0x40800);
            if ((arg_30h._2_1_ == '\0') && (arg_30h._1_1_ == '\0')) {
code_r0x0001800ffe50:
                if ((uVar17 == 0) && ((*(uint32_t *)(unaff_RDI + 0x14) & 0x1000000) == 0)) goto code_r0x0001800ffe5e;
            } else {
                *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2650) = (~uVar17 & 1) + 5;
                if (arg_30h._1_1_ == '\0') {
code_r0x0001800ffe47:
                    if (arg_30h._2_1_ == '\0') goto code_r0x0001800ffe50;
                } else {
                    if (*(char *)(iVar7 + 0xb55) == '\0') {
                        fVar23 = *(float *)(iVar16 + 0x1806185c4);
                        if ((fVar23 != 1.0) && ((fVar23 != 0.0 || (arg_30h._3_1_ == '\0')))) {
                            fVar31 = -3.402823e+38;
                        }
                        fVar29 = *pfVar18;
                        arg_78h._0_4_ = (float)arg_48h;
                        if (fVar29 != 1.0) {
                            arg_78h._0_4_ = -3.402823e+38;
                        }
                        fVar27 = arg_40h._4_4_;
                        if (fVar23 != 0.0) {
                            fVar27 = 3.402823e+38;
                        }
                        fVar22 = 3.402823e+38;
                        if (fVar29 == 0.0) {
                            fVar22 = (float)arg_38h;
                        }
                        fVar30 = *(float *)(iVar16 + 0x1806185cc) * fVar20;
                        fVar24 = *(float *)(iVar16 + 0x1806185c8) * fVar20;
                        fVar24 = ((float)((uint32_t)(float)arg_40h ^ 0x80000000) * *(float *)(iVar16 + 0x1806185c8) -
                                 fVar24) * fVar29 + fVar24;
                        fVar23 = (*(float *)(iVar7 + 0x11c) - *(float *)(iVar7 + 0x1670)) +
                                 ((float)((uint32_t)(float)arg_40h ^ 0x80000000) * *(float *)(iVar16 + 0x1806185cc) -
                                 fVar30) * fVar23 + fVar30;
                        fVar29 = (*(float *)(iVar7 + 0x118) - *(float *)(iVar7 + 0x166c)) + fVar24;
                        arg_78h._4_4_ = fVar31;
                        if ((fVar31 <= fVar23) && (arg_78h._4_4_ = fVar27, fVar23 <= fVar27)) {
                            arg_78h._4_4_ = fVar23;
                        }
                        if (((float)arg_78h <= fVar29) && (arg_78h._0_4_ = fVar22, fVar29 <= fVar22)) {
                            arg_78h._0_4_ = fVar29;
                        }
                        func_0x0001800ff590(fVar24, &arg_78h, pfVar18, &arg_70h, &arg_50h);
                        fVar31 = *(float *)(unaff_RBP + 0xa0);
                    } else {
                        func_0x0001800ff2b0(&arg_58h);
                        piVar12 = (int64_t *)func_0x0001800ff010(unaff_RBP + -0x60);
                        arg_48h._4_4_ = 3;
                        arg_50h = *piVar12;
                        func_0x0001800f9f30(0, 0);
                    }
                    if (arg_30h._1_1_ == '\0') goto code_r0x0001800ffe47;
                }
code_r0x0001800ffe5e:
                iVar16 = *(int64_t *)0x180781f28;
                if (arg_30h._1_1_ == '\0') {
                    iVar10 = (uint64_t)(arg_30h._2_1_ != '\0') + 0x1e;
                } else {
                    iVar10 = 0x20;
                }
                puVar11 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar10 + 0x14) * 0x10);
                uVar9 = puVar11[1];
                uVar4 = puVar11[2];
                fVar23 = (float)puVar11[3];
                *(undefined4 *)(unaff_RBP + -0x70) = *puVar11;
                *(undefined4 *)(unaff_RBP + -0x6c) = uVar9;
                *(undefined4 *)(unaff_RBP + -0x68) = uVar4;
                *(float *)(unaff_RBP + -100) = fVar23;
                *(float *)(unaff_RBP + -100) = fVar23 * *(float *)(iVar16 + 0xd9c);
                uVar9 = func_0x0001800f5fa0(unaff_RBP + -0x70);
                *(undefined4 *)(*(int64_t *)(unaff_RBP + 0xc0) + iVar15 * 4) = uVar9;
            }
            uVar17 = uVar17 + 1;
            iVar15 = iVar15 + 1;
            fVar23 = (float)arg_40h;
        } while ((int32_t)uVar17 < unaff_R13D);
        unaff_RBX = *(uint32_t **)(unaff_RBP + 0xb0);
        fVar29 = (float)arg_48h;
        fVar27 = arg_40h._4_4_;
    }
    if ((*(uint32_t *)(unaff_RDI + 0x14) & 0x1000000) == 0) {
        uVar17 = -(uint32_t)(*(char *)(iVar7 + 0x92) != '\0') & 0xf;
    } else {
        uVar17 = *(uint32_t *)(unaff_RDI + 0x1c) >> 1 & 2 | *(uint32_t *)(unaff_RDI + 0x1c) & 8;
    }
    fVar23 = (float)arg_38h;
    uVar14 = 0;
    arg_48h._0_4_ = 1.401298e-45;
    arg_40h._4_4_ = (float)uVar17;
    do {
        fVar20 = (float)arg_40h;
        iVar15 = 0x180000000;
        if ((uVar17 & (uint32_t)(float)arg_48h) != 0) {
            if (uVar14 < 2) {
                arg_38h = (uint64_t)(uint32_t)arg_38h._4_4_ << 0x20;
                uVar9 = 4;
                iVar16 = 0;
            } else {
                arg_38h = CONCAT44(arg_38h._4_4_, 1);
                uVar9 = 3;
                iVar16 = 4;
            }
            var_20h = (int64_t)*(uint32_t *)(iVar7 + 0x15d4);
            func_0x0001800ff770(unaff_RBP + -0x70);
            arg_68h._0_4_ = uVar14 + 4;
            piVar12 = &arg_68h;
            uVar17 = ~*(uint32_t *)(*(int64_t *)(unaff_RDI + 0x150) + -4 + (int64_t)*(int32_t *)(unaff_RDI + 0x148) * 4)
            ;
            do {
                uVar1 = *(uint8_t *)piVar12;
                piVar12 = (int64_t *)((int64_t)piVar12 + 1);
                uVar17 = uVar17 >> 8 ^
                         *(uint32_t *)(iVar15 + 0x618620 + ((uint64_t)(uVar17 & 0xff) ^ (uint64_t)uVar1) * 4);
            } while (piVar12 < (int64_t *)((int64_t)&arg_68h + 4U));
            func_0x00018010b530(unaff_RBP + -0x70, ~uVar17, 0, 2, var_20h);
            func_0x000180139d40(unaff_RBP + -0x70, ~uVar17, unaff_RBP + 0xa0, &arg_30h, 0x40800);
            if (*(char *)(unaff_RBP + 0xa0) == '\0') {
code_r0x00018010002f:
                if ((char)arg_30h != '\0') goto code_r0x00018010003a;
            } else {
                if (*(float *)(iVar7 + 0x1648) <= 0.04) {
                    *(undefined *)(unaff_RBP + 0xa0) = 0;
                    goto code_r0x00018010002f;
                }
code_r0x00018010003a:
                *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2650) = uVar9;
                if ((char)arg_30h != '\0') {
                    if (*(char *)(iVar7 + 0xb55) == '\0') {
                        iVar15 = *(int64_t *)(iVar7 + 0x1608);
                        iVar16 = (uint64_t)uVar14 * 0x1c;
                        if ((iVar15 == 0) ||
                           (iVar10 = unaff_RDI, *(int32_t *)(iVar7 + 0x161c) != *(int32_t *)(iVar7 + 4))) {
code_r0x00018010011c:
                            bVar19 = false;
                        } else {
                            do {
                                iVar3 = *(int64_t *)(*(int64_t *)(iVar10 + 0x418) + 0x428);
                                bVar19 = iVar10 != iVar3;
                                iVar10 = iVar3;
                            } while (bVar19);
                            iVar10 = unaff_RDI;
                            if (iVar3 != iVar15) {
                                do {
                                    if (iVar10 == iVar15) goto code_r0x000180100247;
                                } while ((iVar10 != iVar3) &&
                                        (piVar12 = (int64_t *)(iVar10 + 0x408), iVar10 = *piVar12, *piVar12 != 0));
                                goto code_r0x00018010011c;
                            }
code_r0x000180100247:
                            bVar19 = true;
                        }
                        if ((*(char *)(iVar7 + 0x1660) != '\0') || (bVar19)) {
                            uVar9 = *(undefined4 *)(unaff_RBP + -0x70);
                            uVar4 = *(undefined4 *)(unaff_RBP + -0x6c);
                            uVar5 = *(undefined4 *)(unaff_RBP + -0x68);
                            uVar6 = *(undefined4 *)(unaff_RBP + -100);
                            *(undefined *)(iVar7 + 0x27fc) = 0;
                            *(undefined4 *)(iVar7 + 0x27ec) = uVar9;
                            *(undefined4 *)(iVar7 + 0x27f0) = uVar4;
                            *(undefined4 *)(iVar7 + 0x27f4) = uVar5;
                            *(undefined4 *)(iVar7 + 0x27f8) = uVar6;
                        }
                        if (((*(uint32_t *)(unaff_RDI + 0x14) & 0x1000000) != 0) &&
                           ((*(int64_t *)(iVar7 + 0x27ec) != *(int64_t *)(unaff_RBP + -0x70) ||
                            (*(int64_t *)(iVar7 + 0x27f4) != *(int64_t *)(unaff_RBP + -0x68))))) {
                            *(undefined *)(iVar7 + 0x27fc) = 1;
                        }
                        uVar13 = arg_38h & 0xffffffff;
                        fVar22 = *(float *)(iVar16 + 0x180618478);
                        if (*(float *)(iVar16 + 0x180618480) <= *(float *)(iVar16 + 0x180618478)) {
                            fVar22 = *(float *)(iVar16 + 0x180618480);
                        }
                        fVar24 = *(float *)(iVar16 + 0x18061847c);
                        if (*(float *)(iVar16 + 0x180618484) <= *(float *)(iVar16 + 0x18061847c)) {
                            fVar24 = *(float *)(iVar16 + 0x180618484);
                        }
                        fVar30 = *(float *)(unaff_RDI + 0x6c);
                        fVar25 = (*(float *)(iVar7 + 0x118 + uVar13 * 4) - *(float *)(iVar7 + 0x166c + uVar13 * 4)) +
                                 *(float *)(iVar7 + 0x15d4);
                        fVar21 = *(float *)(unaff_RDI + 100);
                        arg_78h._0_4_ = fVar22 * *(float *)(unaff_RDI + 0x68) + *(float *)(unaff_RDI + 0x60);
                        arg_38h = *(int64_t *)(unaff_RDI + 0x60);
                        *(float *)((int64_t)&arg_38h + uVar13 * 4) = fVar25;
                        bVar19 = false;
                        arg_78h._4_4_ = fVar24 * fVar30 + fVar21;
                        if (*(char *)(iVar7 + 0x27fc) != '\0') {
                            fVar30 = *(float *)(iVar7 + 0x104 + uVar13 * 4);
                            fVar21 = fVar30 + *(float *)((int64_t)&arg_78h + uVar13 * 4);
                            *(float *)((int64_t)&arg_38h + uVar13 * 4) = fVar21;
                            if ((fVar30 == 0.0) || (0.0 < fVar30 == fVar25 < fVar21)) {
                                bVar19 = true;
                            }
                        }
                        fVar30 = fVar31;
                        if ((uVar14 != 3) && ((uVar14 != 2 || (arg_30h._3_1_ == '\0')))) {
                            fVar30 = -3.402823e+38;
                        }
                        if (uVar14 == 1) {
                            fVar21 = fVar29;
                            fVar8 = 3.402823e+38;
code_r0x000180100264:
                            fVar26 = fVar8;
                            fVar28 = 3.402823e+38;
                            fVar25 = fVar21;
                        } else {
                            fVar25 = -3.402823e+38;
                            fVar21 = -3.402823e+38;
                            fVar8 = fVar27;
                            if (uVar14 == 2) goto code_r0x000180100264;
                            fVar26 = 3.402823e+38;
                            fVar28 = fVar23;
                            fVar8 = 3.402823e+38;
                            if (uVar14 != 0) goto code_r0x000180100264;
                        }
                        if ((fVar30 <= arg_38h._4_4_) && (fVar30 = fVar26, arg_38h._4_4_ <= fVar26)) {
                            fVar30 = arg_38h._4_4_;
                        }
                        if ((fVar25 <= (float)arg_38h) && (fVar25 = fVar28, (float)arg_38h <= fVar28)) {
                            fVar25 = (float)arg_38h;
                        }
                        arg_38h = CONCAT44(fVar30, fVar25);
                        if (!bVar19) {
                            arg_58h._0_4_ = fVar22;
                            arg_58h._4_4_ = fVar24;
                            func_0x0001800ff590();
                        }
                    } else {
                        if ((uVar14 - 1 & 0xfffffffd) == 0) {
                            func_0x0001800ff2b0(unaff_RBP + -0x60);
                            iVar15 = func_0x0001800ff010(unaff_RBP + -0x58);
                            *(undefined4 *)((int64_t)&arg_50h + (arg_38h & 0xffffffffU) * 4) =
                                 *(undefined4 *)(iVar15 + iVar16);
                            arg_48h._4_4_ = arg_48h._4_4_ | 1 << ((uint32_t)(float)arg_38h & 0x1f);
                            arg_30h._0_1_ = '\0';
                            *(undefined *)(unaff_RBP + 0xa0) = 0;
                        }
                        func_0x0001800f9f30(0, 0);
                    }
                }
            }
            if (*(char *)(unaff_RBP + 0xa0) != '\0') {
                **(uint32_t **)(unaff_RBP + 0xa8) = uVar14;
            }
            unaff_RBX = *(uint32_t **)(unaff_RBP + 0xb0);
            uVar17 = (uint32_t)arg_40h._4_4_;
            if ((char)arg_30h != '\0') {
                *unaff_RBX = uVar14;
            }
        }
        arg_48h._0_4_ = (float)((int32_t)(float)arg_48h << 1 | (uint32_t)((int32_t)(float)arg_48h < 0));
        uVar14 = uVar14 + 1;
    } while ((int32_t)uVar14 < 4);
    iVar2 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
    if (iVar2 < 2) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
        }
    } else {
        *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar2 + -1;
    }
    *(undefined4 *)(unaff_RDI + 0x1b0) = 0;
    iVar15 = *(int64_t *)0x180781f28;
    if ((*(int64_t *)(iVar7 + 0x23c0) != 0) && (*(int64_t *)(*(int64_t *)(iVar7 + 0x23c0) + 0x428) == unaff_RDI)) {
        if (*(int32_t *)(iVar7 + 0x2228) == 2) {
            if (*(char *)(iVar7 + 0x139) == '\0') goto code_r0x00018010059a;
            fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x16c) - *(float *)(*(int64_t *)0x180781f28 + 0x15c);
            fVar27 = *(float *)(*(int64_t *)0x180781f28 + 0x18c) - *(float *)(*(int64_t *)0x180781f28 + 0x17c);
        } else {
            if (*(int32_t *)(iVar7 + 0x2228) != 3) goto code_r0x00018010059a;
            fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x93c) - *(float *)(*(int64_t *)0x180781f28 + 0x92c);
            fVar27 = *(float *)(*(int64_t *)0x180781f28 + 0x95c) - *(float *)(*(int64_t *)0x180781f28 + 0x94c);
        }
        if ((fVar23 != 0.0) || (fVar27 != 0.0)) {
            fVar22 = *(float *)(iVar7 + 0x48) * 600.0 * *(float *)(*(int64_t *)0x180781f28 + 0x12c4);
            fVar27 = fVar22 * fVar27 + *(float *)(iVar7 + 0x23f8);
            fVar23 = fVar22 * fVar23 + *(float *)(iVar7 + 0x23f4);
            *(float *)(iVar7 + 0x23f8) = fVar27;
            *(float *)(iVar7 + 0x23f4) = fVar23;
            fVar31 = (fVar31 - *(float *)(unaff_RDI + 100)) - *(float *)(unaff_RDI + 0x6c);
            fVar29 = (fVar29 - *(float *)(unaff_RDI + 0x60)) - *(float *)(unaff_RDI + 0x68);
            *(undefined *)(iVar7 + 0x23e4) = 0;
            *(undefined *)(iVar7 + 0x21cd) = 1;
            if (fVar27 <= fVar31) {
                fVar27 = fVar31;
            }
            if (fVar23 <= fVar29) {
                fVar23 = fVar29;
            }
            *(float *)(iVar7 + 0x23f8) = fVar27;
            *(float *)(iVar7 + 0x23f4) = fVar23;
            uVar9 = *(undefined4 *)(iVar15 + 0x10d4);
            uVar4 = *(undefined4 *)(iVar15 + 0x10d8);
            fVar23 = *(float *)(iVar15 + 0x10dc);
            *(undefined4 *)(unaff_RBP + -0x58) = *(undefined4 *)(iVar15 + 0x10d0);
            *(undefined4 *)(unaff_RBP + -0x54) = uVar9;
            *(undefined4 *)(unaff_RBP + -0x50) = uVar4;
            *(float *)(unaff_RBP + -0x4c) = fVar23;
            *(float *)(unaff_RBP + -0x4c) = fVar23 * *(float *)(iVar15 + 0xd9c);
            uVar9 = func_0x0001800f5fa0(unaff_RBP + -0x58);
            **(undefined4 **)(unaff_RBP + 0xc0) = uVar9;
            fVar29 = (float)(int32_t)*(float *)(iVar7 + 0x23f4);
            fVar23 = (float)(int32_t)*(float *)(iVar7 + 0x23f8);
            if ((fVar29 != 0.0) || (fVar23 != 0.0)) {
                arg_58h._0_4_ = fVar29 + *(float *)(unaff_RDI + 0x70);
                arg_58h._4_4_ = fVar23 + *(float *)(unaff_RDI + 0x74);
                piVar12 = (int64_t *)func_0x0001800ff010(unaff_RBP + -0x58, arg_58h._4_4_, &arg_58h);
                arg_50h = *piVar12;
                *(float *)(iVar7 + 0x23f4) = *(float *)(iVar7 + 0x23f4) - fVar29;
                *(float *)(iVar7 + 0x23f8) = *(float *)(iVar7 + 0x23f8) - fVar23;
            }
        }
    }
code_r0x00018010059a:
    fVar23 = *(float *)(unaff_RDI + 0x60);
    fVar29 = *(float *)(unaff_RDI + 100);
    fVar27 = *(float *)(unaff_RDI + 0x70);
    fVar31 = *(float *)(unaff_RDI + 0x74);
    fVar22 = fVar27;
    if (((float)arg_50h != 3.402823e+38) &&
       ((*(float *)(unaff_RDI + 0x68) != (float)arg_50h || (fVar27 != (float)arg_50h)))) {
        *(float *)(unaff_RDI + 0x70) = (float)arg_50h;
        *(float *)(unaff_RDI + 0x68) = (float)arg_50h;
        fVar22 = (float)arg_50h;
    }
    if ((arg_50h._4_4_ != 3.402823e+38) &&
       ((*(float *)(unaff_RDI + 0x6c) != arg_50h._4_4_ || (*(float *)(unaff_RDI + 0x74) != arg_50h._4_4_)))) {
        *(float *)(unaff_RDI + 0x74) = arg_50h._4_4_;
        *(float *)(unaff_RDI + 0x6c) = arg_50h._4_4_;
    }
    if (((float)arg_70h != 3.402823e+38) && (fVar23 != (float)(int32_t)(float)arg_70h)) {
        *(float *)(unaff_RDI + 0x60) = (float)(int32_t)(float)arg_70h;
    }
    if ((arg_70h._4_4_ != 3.402823e+38) && (*(float *)(unaff_RDI + 100) != (float)(int32_t)arg_70h._4_4_)) {
        *(float *)(unaff_RDI + 100) = (float)(int32_t)arg_70h._4_4_;
    }
    if (((((fVar23 != *(float *)(unaff_RDI + 0x60)) || (fVar29 != *(float *)(unaff_RDI + 100))) || (fVar27 != fVar22))
        || (fVar31 != *(float *)(unaff_RDI + 0x74))) &&
       (((*(uint32_t *)(unaff_RDI + 0x14) & 0x100) == 0 && (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0)))) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
    }
    if (*unaff_RBX != 0xffffffff) {
        var_20h = (int64_t)*(uint32_t *)(iVar7 + 0x15d4);
        puVar11 = (undefined4 *)func_0x0001800ff770(unaff_RBP + -0x70, fVar22, *unaff_RBX, fVar20, var_20h);
        uVar9 = puVar11[1];
        uVar4 = puVar11[2];
        uVar5 = puVar11[3];
        *(undefined4 *)(iVar7 + 0x27ec) = *puVar11;
        *(undefined4 *)(iVar7 + 0x27f0) = uVar9;
        *(undefined4 *)(iVar7 + 0x27f4) = uVar4;
        *(undefined4 *)(iVar7 + 0x27f8) = uVar5;
    }
    return arg_48h._4_4_;
}

// ============================================================
// Function: FUN_1801005d7
// Address: 0x1801005d7
// Size: 163 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: arg_1b8h
// WARNING: Variable defined which should be unmapped: arg_170h
// WARNING: Variable defined which should be unmapped: arg_168h
// WARNING: Variable defined which should be unmapped: arg_160h
// WARNING: Variable defined which should be unmapped: arg_150h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h
// WARNING: [rz-ghidra] Detected overlap for variable arg_33h
// WARNING: [rz-ghidra] Detected overlap for variable arg_74h
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_7ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Detected overlap for variable arg_31h
// WARNING: [rz-ghidra] Detected overlap for variable arg_32h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

uint32_t fcn.1800ff916(int64_t arg_30h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                      int64_t arg_70h, int64_t arg_78h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h,
                      int64_t arg_c0h, int64_t arg_c8h, int64_t arg_d0h, int64_t arg_e0h, int64_t arg_f0h,
                      int64_t arg_100h, int64_t arg_110h, int64_t arg_120h, int64_t arg_130h, int64_t arg_140h,
                      int64_t arg_150h, int64_t arg_160h, int64_t arg_168h, int64_t arg_170h, int64_t arg_1b8h)
{
    uint8_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    float fVar8;
    undefined4 uVar9;
    int64_t iVar10;
    undefined4 *puVar11;
    uint64_t in_RCX;
    int64_t *piVar12;
    uint64_t uVar13;
    uint32_t uVar14;
    uint32_t *unaff_RBX;
    int64_t unaff_RBP;
    int64_t unaff_RDI;
    int64_t iVar15;
    int32_t unaff_R13D;
    int64_t iVar16;
    uint32_t uVar17;
    float *pfVar18;
    bool bVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    float fVar31;
    int64_t var_20h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_4ch;
    
    iVar7 = *(int64_t *)0x180781f28;
    arg_48h._4_4_ = 0;
    if (unaff_R13D < 1) {
        fVar23 = 0.0;
    } else {
        fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) * 1.35;
        fVar20 = *(float *)(unaff_RDI + 0x98) + 1.0 + *(float *)(*(int64_t *)0x180781f28 + 0x12f8) * 0.2;
        if (fVar23 <= fVar20) {
            fVar23 = fVar20;
        }
        fVar23 = (float)(int32_t)((float)(int32_t)fVar23 * 0.75);
    }
    pfVar18 = *(float **)(unaff_RBP + 200);
    fVar20 = *(float *)(*(int64_t *)0x180781f28 + 0x15d4);
    fVar29 = *pfVar18;
    fVar27 = pfVar18[3];
    fVar31 = pfVar18[1];
    arg_38h = CONCAT44(arg_38h._4_4_, pfVar18[2]);
    if (((*(uint8_t *)(unaff_RDI + 0x130) & 1) == 0) && ((in_RCX & 1) == 0)) {
        fVar31 = fVar31 - *(float *)(unaff_RDI + 0xa0);
        arg_30h._3_1_ = '\x01';
    } else {
        arg_30h._3_1_ = '\0';
    }
    uVar17 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x34);
    *(float *)(unaff_RBP + 0xa0) = fVar31;
    arg_70h._0_4_ = 3.402823e+38;
    arg_70h._4_4_ = 3.402823e+38;
    arg_50h = 0x7f7fffff7f7fffff;
    if ((((uVar17 & 0x1000) == 0) || (*(int32_t *)(iVar7 + 0x134) != *(int32_t *)(unaff_RDI + 0x50))) ||
       ((*(uint8_t *)(*(int64_t *)(unaff_RDI + 0x48) + 4) & 8) == 0)) {
        iVar15 = *(int64_t *)(unaff_RDI + 0x48);
        fVar22 = *(float *)(iVar15 + 8);
        fVar24 = *(float *)(iVar15 + 0xc);
        fVar30 = *(float *)(iVar15 + 0x10);
        fVar21 = *(float *)(iVar15 + 0x14);
        *(float *)(unaff_RDI + 0x2b8) = fVar22;
        *(float *)(unaff_RDI + 700) = fVar24;
        *(float *)(unaff_RDI + 0x2c0) = fVar22 + fVar30;
        *(float *)(unaff_RDI + 0x2c4) = fVar24 + fVar21;
    }
    *(undefined4 *)(unaff_RDI + 0x1b0) = 1;
    arg_40h._0_4_ = fVar23;
    arg_40h._4_4_ = fVar27;
    arg_48h._0_4_ = fVar29;
    func_0x000180107590();
    uVar17 = 0;
    if (0 < unaff_R13D) {
        iVar15 = 0;
        do {
            fVar29 = *(float *)(unaff_RDI + 0x60);
            fVar27 = *(float *)(unaff_RDI + 100);
            iVar16 = iVar15 * 0x18;
            fVar22 = *(float *)(iVar15 * 0x18 + 0x1806185cc);
            fVar24 = *(float *)(iVar15 * 0x18 + 0x1806185c8);
            pfVar18 = (float *)(iVar16 + 0x1806185c0);
            fVar29 = ((fVar29 + *(float *)(unaff_RDI + 0x68)) - fVar29) * *pfVar18 + fVar29;
            fVar30 = fVar23 * fVar24 + fVar29;
            fVar27 = ((fVar27 + *(float *)(unaff_RDI + 0x6c)) - fVar27) * *(float *)(iVar15 * 0x18 + 0x1806185c4) +
                     fVar27;
            fVar29 = fVar29 - fVar20 * fVar24;
            *(float *)(unaff_RBP + -0x78) = fVar30;
            fVar23 = fVar22 * (float)arg_40h + fVar27;
            fVar27 = fVar27 - fVar22 * fVar20;
            *(float *)(unaff_RBP + -0x80) = fVar29;
            *(float *)(unaff_RBP + -0x74) = fVar23;
            *(float *)(unaff_RBP + -0x7c) = fVar27;
            if (fVar30 < fVar29) {
                *(float *)(unaff_RBP + -0x80) = fVar30;
                *(float *)(unaff_RBP + -0x78) = fVar29;
            }
            if (fVar23 < fVar27) {
                *(float *)(unaff_RBP + -0x7c) = fVar23;
                *(float *)(unaff_RBP + -0x74) = fVar27;
            }
            piVar12 = &arg_60h;
            arg_60h._0_4_ = uVar17;
            uVar14 = ~*(uint32_t *)(*(int64_t *)(unaff_RDI + 0x150) + -4 + (int64_t)*(int32_t *)(unaff_RDI + 0x148) * 4)
            ;
            do {
                uVar1 = *(uint8_t *)piVar12;
                piVar12 = (int64_t *)((int64_t)piVar12 + 1);
                uVar14 = uVar14 >> 8 ^ *(uint32_t *)(((uint64_t)(uVar14 & 0xff) ^ (uint64_t)uVar1) * 4 + 0x180618620);
            } while (piVar12 < (int64_t *)((int64_t)&arg_60h + 4U));
            func_0x00018010b530(unaff_RBP + -0x80, ~uVar14, 0, 2);
            func_0x000180139d40(unaff_RBP + -0x80, ~uVar14, (int64_t)&arg_30h + 2, (int64_t)&arg_30h + 1, 0x40800);
            if ((arg_30h._2_1_ == '\0') && (arg_30h._1_1_ == '\0')) {
code_r0x0001800ffe50:
                if ((uVar17 == 0) && ((*(uint32_t *)(unaff_RDI + 0x14) & 0x1000000) == 0)) goto code_r0x0001800ffe5e;
            } else {
                *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2650) = (~uVar17 & 1) + 5;
                if (arg_30h._1_1_ == '\0') {
code_r0x0001800ffe47:
                    if (arg_30h._2_1_ == '\0') goto code_r0x0001800ffe50;
                } else {
                    if (*(char *)(iVar7 + 0xb55) == '\0') {
                        fVar23 = *(float *)(iVar16 + 0x1806185c4);
                        if ((fVar23 != 1.0) && ((fVar23 != 0.0 || (arg_30h._3_1_ == '\0')))) {
                            fVar31 = -3.402823e+38;
                        }
                        fVar29 = *pfVar18;
                        arg_78h._0_4_ = (float)arg_48h;
                        if (fVar29 != 1.0) {
                            arg_78h._0_4_ = -3.402823e+38;
                        }
                        fVar27 = arg_40h._4_4_;
                        if (fVar23 != 0.0) {
                            fVar27 = 3.402823e+38;
                        }
                        fVar22 = 3.402823e+38;
                        if (fVar29 == 0.0) {
                            fVar22 = (float)arg_38h;
                        }
                        fVar30 = *(float *)(iVar16 + 0x1806185cc) * fVar20;
                        fVar24 = *(float *)(iVar16 + 0x1806185c8) * fVar20;
                        fVar24 = ((float)((uint32_t)(float)arg_40h ^ 0x80000000) * *(float *)(iVar16 + 0x1806185c8) -
                                 fVar24) * fVar29 + fVar24;
                        fVar23 = (*(float *)(iVar7 + 0x11c) - *(float *)(iVar7 + 0x1670)) +
                                 ((float)((uint32_t)(float)arg_40h ^ 0x80000000) * *(float *)(iVar16 + 0x1806185cc) -
                                 fVar30) * fVar23 + fVar30;
                        fVar29 = (*(float *)(iVar7 + 0x118) - *(float *)(iVar7 + 0x166c)) + fVar24;
                        arg_78h._4_4_ = fVar31;
                        if ((fVar31 <= fVar23) && (arg_78h._4_4_ = fVar27, fVar23 <= fVar27)) {
                            arg_78h._4_4_ = fVar23;
                        }
                        if (((float)arg_78h <= fVar29) && (arg_78h._0_4_ = fVar22, fVar29 <= fVar22)) {
                            arg_78h._0_4_ = fVar29;
                        }
                        func_0x0001800ff590(fVar24, &arg_78h, pfVar18, &arg_70h, &arg_50h);
                        fVar31 = *(float *)(unaff_RBP + 0xa0);
                    } else {
                        func_0x0001800ff2b0(&arg_58h);
                        piVar12 = (int64_t *)func_0x0001800ff010(unaff_RBP + -0x60);
                        arg_48h._4_4_ = 3;
                        arg_50h = *piVar12;
                        func_0x0001800f9f30(0, 0);
                    }
                    if (arg_30h._1_1_ == '\0') goto code_r0x0001800ffe47;
                }
code_r0x0001800ffe5e:
                iVar16 = *(int64_t *)0x180781f28;
                if (arg_30h._1_1_ == '\0') {
                    iVar10 = (uint64_t)(arg_30h._2_1_ != '\0') + 0x1e;
                } else {
                    iVar10 = 0x20;
                }
                puVar11 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar10 + 0x14) * 0x10);
                uVar9 = puVar11[1];
                uVar4 = puVar11[2];
                fVar23 = (float)puVar11[3];
                *(undefined4 *)(unaff_RBP + -0x70) = *puVar11;
                *(undefined4 *)(unaff_RBP + -0x6c) = uVar9;
                *(undefined4 *)(unaff_RBP + -0x68) = uVar4;
                *(float *)(unaff_RBP + -100) = fVar23;
                *(float *)(unaff_RBP + -100) = fVar23 * *(float *)(iVar16 + 0xd9c);
                uVar9 = func_0x0001800f5fa0(unaff_RBP + -0x70);
                *(undefined4 *)(*(int64_t *)(unaff_RBP + 0xc0) + iVar15 * 4) = uVar9;
            }
            uVar17 = uVar17 + 1;
            iVar15 = iVar15 + 1;
            fVar23 = (float)arg_40h;
        } while ((int32_t)uVar17 < unaff_R13D);
        unaff_RBX = *(uint32_t **)(unaff_RBP + 0xb0);
        fVar29 = (float)arg_48h;
        fVar27 = arg_40h._4_4_;
    }
    if ((*(uint32_t *)(unaff_RDI + 0x14) & 0x1000000) == 0) {
        uVar17 = -(uint32_t)(*(char *)(iVar7 + 0x92) != '\0') & 0xf;
    } else {
        uVar17 = *(uint32_t *)(unaff_RDI + 0x1c) >> 1 & 2 | *(uint32_t *)(unaff_RDI + 0x1c) & 8;
    }
    fVar23 = (float)arg_38h;
    uVar14 = 0;
    arg_48h._0_4_ = 1.401298e-45;
    arg_40h._4_4_ = (float)uVar17;
    do {
        fVar20 = (float)arg_40h;
        iVar15 = 0x180000000;
        if ((uVar17 & (uint32_t)(float)arg_48h) != 0) {
            if (uVar14 < 2) {
                arg_38h = (uint64_t)(uint32_t)arg_38h._4_4_ << 0x20;
                uVar9 = 4;
                iVar16 = 0;
            } else {
                arg_38h = CONCAT44(arg_38h._4_4_, 1);
                uVar9 = 3;
                iVar16 = 4;
            }
            var_20h = (int64_t)*(uint32_t *)(iVar7 + 0x15d4);
            func_0x0001800ff770(unaff_RBP + -0x70);
            arg_68h._0_4_ = uVar14 + 4;
            piVar12 = &arg_68h;
            uVar17 = ~*(uint32_t *)(*(int64_t *)(unaff_RDI + 0x150) + -4 + (int64_t)*(int32_t *)(unaff_RDI + 0x148) * 4)
            ;
            do {
                uVar1 = *(uint8_t *)piVar12;
                piVar12 = (int64_t *)((int64_t)piVar12 + 1);
                uVar17 = uVar17 >> 8 ^
                         *(uint32_t *)(iVar15 + 0x618620 + ((uint64_t)(uVar17 & 0xff) ^ (uint64_t)uVar1) * 4);
            } while (piVar12 < (int64_t *)((int64_t)&arg_68h + 4U));
            func_0x00018010b530(unaff_RBP + -0x70, ~uVar17, 0, 2, var_20h);
            func_0x000180139d40(unaff_RBP + -0x70, ~uVar17, unaff_RBP + 0xa0, &arg_30h, 0x40800);
            if (*(char *)(unaff_RBP + 0xa0) == '\0') {
code_r0x00018010002f:
                if ((char)arg_30h != '\0') goto code_r0x00018010003a;
            } else {
                if (*(float *)(iVar7 + 0x1648) <= 0.04) {
                    *(undefined *)(unaff_RBP + 0xa0) = 0;
                    goto code_r0x00018010002f;
                }
code_r0x00018010003a:
                *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2650) = uVar9;
                if ((char)arg_30h != '\0') {
                    if (*(char *)(iVar7 + 0xb55) == '\0') {
                        iVar15 = *(int64_t *)(iVar7 + 0x1608);
                        iVar16 = (uint64_t)uVar14 * 0x1c;
                        if ((iVar15 == 0) ||
                           (iVar10 = unaff_RDI, *(int32_t *)(iVar7 + 0x161c) != *(int32_t *)(iVar7 + 4))) {
code_r0x00018010011c:
                            bVar19 = false;
                        } else {
                            do {
                                iVar3 = *(int64_t *)(*(int64_t *)(iVar10 + 0x418) + 0x428);
                                bVar19 = iVar10 != iVar3;
                                iVar10 = iVar3;
                            } while (bVar19);
                            iVar10 = unaff_RDI;
                            if (iVar3 != iVar15) {
                                do {
                                    if (iVar10 == iVar15) goto code_r0x000180100247;
                                } while ((iVar10 != iVar3) &&
                                        (piVar12 = (int64_t *)(iVar10 + 0x408), iVar10 = *piVar12, *piVar12 != 0));
                                goto code_r0x00018010011c;
                            }
code_r0x000180100247:
                            bVar19 = true;
                        }
                        if ((*(char *)(iVar7 + 0x1660) != '\0') || (bVar19)) {
                            uVar9 = *(undefined4 *)(unaff_RBP + -0x70);
                            uVar4 = *(undefined4 *)(unaff_RBP + -0x6c);
                            uVar5 = *(undefined4 *)(unaff_RBP + -0x68);
                            uVar6 = *(undefined4 *)(unaff_RBP + -100);
                            *(undefined *)(iVar7 + 0x27fc) = 0;
                            *(undefined4 *)(iVar7 + 0x27ec) = uVar9;
                            *(undefined4 *)(iVar7 + 0x27f0) = uVar4;
                            *(undefined4 *)(iVar7 + 0x27f4) = uVar5;
                            *(undefined4 *)(iVar7 + 0x27f8) = uVar6;
                        }
                        if (((*(uint32_t *)(unaff_RDI + 0x14) & 0x1000000) != 0) &&
                           ((*(int64_t *)(iVar7 + 0x27ec) != *(int64_t *)(unaff_RBP + -0x70) ||
                            (*(int64_t *)(iVar7 + 0x27f4) != *(int64_t *)(unaff_RBP + -0x68))))) {
                            *(undefined *)(iVar7 + 0x27fc) = 1;
                        }
                        uVar13 = arg_38h & 0xffffffff;
                        fVar22 = *(float *)(iVar16 + 0x180618478);
                        if (*(float *)(iVar16 + 0x180618480) <= *(float *)(iVar16 + 0x180618478)) {
                            fVar22 = *(float *)(iVar16 + 0x180618480);
                        }
                        fVar24 = *(float *)(iVar16 + 0x18061847c);
                        if (*(float *)(iVar16 + 0x180618484) <= *(float *)(iVar16 + 0x18061847c)) {
                            fVar24 = *(float *)(iVar16 + 0x180618484);
                        }
                        fVar30 = *(float *)(unaff_RDI + 0x6c);
                        fVar25 = (*(float *)(iVar7 + 0x118 + uVar13 * 4) - *(float *)(iVar7 + 0x166c + uVar13 * 4)) +
                                 *(float *)(iVar7 + 0x15d4);
                        fVar21 = *(float *)(unaff_RDI + 100);
                        arg_78h._0_4_ = fVar22 * *(float *)(unaff_RDI + 0x68) + *(float *)(unaff_RDI + 0x60);
                        arg_38h = *(int64_t *)(unaff_RDI + 0x60);
                        *(float *)((int64_t)&arg_38h + uVar13 * 4) = fVar25;
                        bVar19 = false;
                        arg_78h._4_4_ = fVar24 * fVar30 + fVar21;
                        if (*(char *)(iVar7 + 0x27fc) != '\0') {
                            fVar30 = *(float *)(iVar7 + 0x104 + uVar13 * 4);
                            fVar21 = fVar30 + *(float *)((int64_t)&arg_78h + uVar13 * 4);
                            *(float *)((int64_t)&arg_38h + uVar13 * 4) = fVar21;
                            if ((fVar30 == 0.0) || (0.0 < fVar30 == fVar25 < fVar21)) {
                                bVar19 = true;
                            }
                        }
                        fVar30 = fVar31;
                        if ((uVar14 != 3) && ((uVar14 != 2 || (arg_30h._3_1_ == '\0')))) {
                            fVar30 = -3.402823e+38;
                        }
                        if (uVar14 == 1) {
                            fVar21 = fVar29;
                            fVar8 = 3.402823e+38;
code_r0x000180100264:
                            fVar26 = fVar8;
                            fVar28 = 3.402823e+38;
                            fVar25 = fVar21;
                        } else {
                            fVar25 = -3.402823e+38;
                            fVar21 = -3.402823e+38;
                            fVar8 = fVar27;
                            if (uVar14 == 2) goto code_r0x000180100264;
                            fVar26 = 3.402823e+38;
                            fVar28 = fVar23;
                            fVar8 = 3.402823e+38;
                            if (uVar14 != 0) goto code_r0x000180100264;
                        }
                        if ((fVar30 <= arg_38h._4_4_) && (fVar30 = fVar26, arg_38h._4_4_ <= fVar26)) {
                            fVar30 = arg_38h._4_4_;
                        }
                        if ((fVar25 <= (float)arg_38h) && (fVar25 = fVar28, (float)arg_38h <= fVar28)) {
                            fVar25 = (float)arg_38h;
                        }
                        arg_38h = CONCAT44(fVar30, fVar25);
                        if (!bVar19) {
                            arg_58h._0_4_ = fVar22;
                            arg_58h._4_4_ = fVar24;
                            func_0x0001800ff590();
                        }
                    } else {
                        if ((uVar14 - 1 & 0xfffffffd) == 0) {
                            func_0x0001800ff2b0(unaff_RBP + -0x60);
                            iVar15 = func_0x0001800ff010(unaff_RBP + -0x58);
                            *(undefined4 *)((int64_t)&arg_50h + (arg_38h & 0xffffffffU) * 4) =
                                 *(undefined4 *)(iVar15 + iVar16);
                            arg_48h._4_4_ = arg_48h._4_4_ | 1 << ((uint32_t)(float)arg_38h & 0x1f);
                            arg_30h._0_1_ = '\0';
                            *(undefined *)(unaff_RBP + 0xa0) = 0;
                        }
                        func_0x0001800f9f30(0, 0);
                    }
                }
            }
            if (*(char *)(unaff_RBP + 0xa0) != '\0') {
                **(uint32_t **)(unaff_RBP + 0xa8) = uVar14;
            }
            unaff_RBX = *(uint32_t **)(unaff_RBP + 0xb0);
            uVar17 = (uint32_t)arg_40h._4_4_;
            if ((char)arg_30h != '\0') {
                *unaff_RBX = uVar14;
            }
        }
        arg_48h._0_4_ = (float)((int32_t)(float)arg_48h << 1 | (uint32_t)((int32_t)(float)arg_48h < 0));
        uVar14 = uVar14 + 1;
    } while ((int32_t)uVar14 < 4);
    iVar2 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
    if (iVar2 < 2) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
        }
    } else {
        *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar2 + -1;
    }
    *(undefined4 *)(unaff_RDI + 0x1b0) = 0;
    iVar15 = *(int64_t *)0x180781f28;
    if ((*(int64_t *)(iVar7 + 0x23c0) != 0) && (*(int64_t *)(*(int64_t *)(iVar7 + 0x23c0) + 0x428) == unaff_RDI)) {
        if (*(int32_t *)(iVar7 + 0x2228) == 2) {
            if (*(char *)(iVar7 + 0x139) == '\0') goto code_r0x00018010059a;
            fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x16c) - *(float *)(*(int64_t *)0x180781f28 + 0x15c);
            fVar27 = *(float *)(*(int64_t *)0x180781f28 + 0x18c) - *(float *)(*(int64_t *)0x180781f28 + 0x17c);
        } else {
            if (*(int32_t *)(iVar7 + 0x2228) != 3) goto code_r0x00018010059a;
            fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x93c) - *(float *)(*(int64_t *)0x180781f28 + 0x92c);
            fVar27 = *(float *)(*(int64_t *)0x180781f28 + 0x95c) - *(float *)(*(int64_t *)0x180781f28 + 0x94c);
        }
        if ((fVar23 != 0.0) || (fVar27 != 0.0)) {
            fVar22 = *(float *)(iVar7 + 0x48) * 600.0 * *(float *)(*(int64_t *)0x180781f28 + 0x12c4);
            fVar27 = fVar22 * fVar27 + *(float *)(iVar7 + 0x23f8);
            fVar23 = fVar22 * fVar23 + *(float *)(iVar7 + 0x23f4);
            *(float *)(iVar7 + 0x23f8) = fVar27;
            *(float *)(iVar7 + 0x23f4) = fVar23;
            fVar31 = (fVar31 - *(float *)(unaff_RDI + 100)) - *(float *)(unaff_RDI + 0x6c);
            fVar29 = (fVar29 - *(float *)(unaff_RDI + 0x60)) - *(float *)(unaff_RDI + 0x68);
            *(undefined *)(iVar7 + 0x23e4) = 0;
            *(undefined *)(iVar7 + 0x21cd) = 1;
            if (fVar27 <= fVar31) {
                fVar27 = fVar31;
            }
            if (fVar23 <= fVar29) {
                fVar23 = fVar29;
            }
            *(float *)(iVar7 + 0x23f8) = fVar27;
            *(float *)(iVar7 + 0x23f4) = fVar23;
            uVar9 = *(undefined4 *)(iVar15 + 0x10d4);
            uVar4 = *(undefined4 *)(iVar15 + 0x10d8);
            fVar23 = *(float *)(iVar15 + 0x10dc);
            *(undefined4 *)(unaff_RBP + -0x58) = *(undefined4 *)(iVar15 + 0x10d0);
            *(undefined4 *)(unaff_RBP + -0x54) = uVar9;
            *(undefined4 *)(unaff_RBP + -0x50) = uVar4;
            *(float *)(unaff_RBP + -0x4c) = fVar23;
            *(float *)(unaff_RBP + -0x4c) = fVar23 * *(float *)(iVar15 + 0xd9c);
            uVar9 = func_0x0001800f5fa0(unaff_RBP + -0x58);
            **(undefined4 **)(unaff_RBP + 0xc0) = uVar9;
            fVar29 = (float)(int32_t)*(float *)(iVar7 + 0x23f4);
            fVar23 = (float)(int32_t)*(float *)(iVar7 + 0x23f8);
            if ((fVar29 != 0.0) || (fVar23 != 0.0)) {
                arg_58h._0_4_ = fVar29 + *(float *)(unaff_RDI + 0x70);
                arg_58h._4_4_ = fVar23 + *(float *)(unaff_RDI + 0x74);
                piVar12 = (int64_t *)func_0x0001800ff010(unaff_RBP + -0x58, arg_58h._4_4_, &arg_58h);
                arg_50h = *piVar12;
                *(float *)(iVar7 + 0x23f4) = *(float *)(iVar7 + 0x23f4) - fVar29;
                *(float *)(iVar7 + 0x23f8) = *(float *)(iVar7 + 0x23f8) - fVar23;
            }
        }
    }
code_r0x00018010059a:
    fVar23 = *(float *)(unaff_RDI + 0x60);
    fVar29 = *(float *)(unaff_RDI + 100);
    fVar27 = *(float *)(unaff_RDI + 0x70);
    fVar31 = *(float *)(unaff_RDI + 0x74);
    fVar22 = fVar27;
    if (((float)arg_50h != 3.402823e+38) &&
       ((*(float *)(unaff_RDI + 0x68) != (float)arg_50h || (fVar27 != (float)arg_50h)))) {
        *(float *)(unaff_RDI + 0x70) = (float)arg_50h;
        *(float *)(unaff_RDI + 0x68) = (float)arg_50h;
        fVar22 = (float)arg_50h;
    }
    if ((arg_50h._4_4_ != 3.402823e+38) &&
       ((*(float *)(unaff_RDI + 0x6c) != arg_50h._4_4_ || (*(float *)(unaff_RDI + 0x74) != arg_50h._4_4_)))) {
        *(float *)(unaff_RDI + 0x74) = arg_50h._4_4_;
        *(float *)(unaff_RDI + 0x6c) = arg_50h._4_4_;
    }
    if (((float)arg_70h != 3.402823e+38) && (fVar23 != (float)(int32_t)(float)arg_70h)) {
        *(float *)(unaff_RDI + 0x60) = (float)(int32_t)(float)arg_70h;
    }
    if ((arg_70h._4_4_ != 3.402823e+38) && (*(float *)(unaff_RDI + 100) != (float)(int32_t)arg_70h._4_4_)) {
        *(float *)(unaff_RDI + 100) = (float)(int32_t)arg_70h._4_4_;
    }
    if (((((fVar23 != *(float *)(unaff_RDI + 0x60)) || (fVar29 != *(float *)(unaff_RDI + 100))) || (fVar27 != fVar22))
        || (fVar31 != *(float *)(unaff_RDI + 0x74))) &&
       (((*(uint32_t *)(unaff_RDI + 0x14) & 0x100) == 0 && (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0)))) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
    }
    if (*unaff_RBX != 0xffffffff) {
        var_20h = (int64_t)*(uint32_t *)(iVar7 + 0x15d4);
        puVar11 = (undefined4 *)func_0x0001800ff770(unaff_RBP + -0x70, fVar22, *unaff_RBX, fVar20, var_20h);
        uVar9 = puVar11[1];
        uVar4 = puVar11[2];
        uVar5 = puVar11[3];
        *(undefined4 *)(iVar7 + 0x27ec) = *puVar11;
        *(undefined4 *)(iVar7 + 0x27f0) = uVar9;
        *(undefined4 *)(iVar7 + 0x27f4) = uVar4;
        *(undefined4 *)(iVar7 + 0x27f8) = uVar5;
    }
    return arg_48h._4_4_;
}

// ============================================================
// Function: FUN_18010067a
// Address: 0x18010067a
// Size: 121 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: arg_1b8h
// WARNING: Variable defined which should be unmapped: arg_170h
// WARNING: Variable defined which should be unmapped: arg_168h
// WARNING: Variable defined which should be unmapped: arg_160h
// WARNING: Variable defined which should be unmapped: arg_150h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h
// WARNING: [rz-ghidra] Detected overlap for variable arg_33h
// WARNING: [rz-ghidra] Detected overlap for variable arg_74h
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_7ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Detected overlap for variable arg_31h
// WARNING: [rz-ghidra] Detected overlap for variable arg_32h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

uint32_t fcn.1800ff916(int64_t arg_30h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                      int64_t arg_70h, int64_t arg_78h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h,
                      int64_t arg_c0h, int64_t arg_c8h, int64_t arg_d0h, int64_t arg_e0h, int64_t arg_f0h,
                      int64_t arg_100h, int64_t arg_110h, int64_t arg_120h, int64_t arg_130h, int64_t arg_140h,
                      int64_t arg_150h, int64_t arg_160h, int64_t arg_168h, int64_t arg_170h, int64_t arg_1b8h)
{
    uint8_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    float fVar8;
    undefined4 uVar9;
    int64_t iVar10;
    undefined4 *puVar11;
    uint64_t in_RCX;
    int64_t *piVar12;
    uint64_t uVar13;
    uint32_t uVar14;
    uint32_t *unaff_RBX;
    int64_t unaff_RBP;
    int64_t unaff_RDI;
    int64_t iVar15;
    int32_t unaff_R13D;
    int64_t iVar16;
    uint32_t uVar17;
    float *pfVar18;
    bool bVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    float fVar31;
    int64_t var_20h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_4ch;
    
    iVar7 = *(int64_t *)0x180781f28;
    arg_48h._4_4_ = 0;
    if (unaff_R13D < 1) {
        fVar23 = 0.0;
    } else {
        fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) * 1.35;
        fVar20 = *(float *)(unaff_RDI + 0x98) + 1.0 + *(float *)(*(int64_t *)0x180781f28 + 0x12f8) * 0.2;
        if (fVar23 <= fVar20) {
            fVar23 = fVar20;
        }
        fVar23 = (float)(int32_t)((float)(int32_t)fVar23 * 0.75);
    }
    pfVar18 = *(float **)(unaff_RBP + 200);
    fVar20 = *(float *)(*(int64_t *)0x180781f28 + 0x15d4);
    fVar29 = *pfVar18;
    fVar27 = pfVar18[3];
    fVar31 = pfVar18[1];
    arg_38h = CONCAT44(arg_38h._4_4_, pfVar18[2]);
    if (((*(uint8_t *)(unaff_RDI + 0x130) & 1) == 0) && ((in_RCX & 1) == 0)) {
        fVar31 = fVar31 - *(float *)(unaff_RDI + 0xa0);
        arg_30h._3_1_ = '\x01';
    } else {
        arg_30h._3_1_ = '\0';
    }
    uVar17 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x34);
    *(float *)(unaff_RBP + 0xa0) = fVar31;
    arg_70h._0_4_ = 3.402823e+38;
    arg_70h._4_4_ = 3.402823e+38;
    arg_50h = 0x7f7fffff7f7fffff;
    if ((((uVar17 & 0x1000) == 0) || (*(int32_t *)(iVar7 + 0x134) != *(int32_t *)(unaff_RDI + 0x50))) ||
       ((*(uint8_t *)(*(int64_t *)(unaff_RDI + 0x48) + 4) & 8) == 0)) {
        iVar15 = *(int64_t *)(unaff_RDI + 0x48);
        fVar22 = *(float *)(iVar15 + 8);
        fVar24 = *(float *)(iVar15 + 0xc);
        fVar30 = *(float *)(iVar15 + 0x10);
        fVar21 = *(float *)(iVar15 + 0x14);
        *(float *)(unaff_RDI + 0x2b8) = fVar22;
        *(float *)(unaff_RDI + 700) = fVar24;
        *(float *)(unaff_RDI + 0x2c0) = fVar22 + fVar30;
        *(float *)(unaff_RDI + 0x2c4) = fVar24 + fVar21;
    }
    *(undefined4 *)(unaff_RDI + 0x1b0) = 1;
    arg_40h._0_4_ = fVar23;
    arg_40h._4_4_ = fVar27;
    arg_48h._0_4_ = fVar29;
    func_0x000180107590();
    uVar17 = 0;
    if (0 < unaff_R13D) {
        iVar15 = 0;
        do {
            fVar29 = *(float *)(unaff_RDI + 0x60);
            fVar27 = *(float *)(unaff_RDI + 100);
            iVar16 = iVar15 * 0x18;
            fVar22 = *(float *)(iVar15 * 0x18 + 0x1806185cc);
            fVar24 = *(float *)(iVar15 * 0x18 + 0x1806185c8);
            pfVar18 = (float *)(iVar16 + 0x1806185c0);
            fVar29 = ((fVar29 + *(float *)(unaff_RDI + 0x68)) - fVar29) * *pfVar18 + fVar29;
            fVar30 = fVar23 * fVar24 + fVar29;
            fVar27 = ((fVar27 + *(float *)(unaff_RDI + 0x6c)) - fVar27) * *(float *)(iVar15 * 0x18 + 0x1806185c4) +
                     fVar27;
            fVar29 = fVar29 - fVar20 * fVar24;
            *(float *)(unaff_RBP + -0x78) = fVar30;
            fVar23 = fVar22 * (float)arg_40h + fVar27;
            fVar27 = fVar27 - fVar22 * fVar20;
            *(float *)(unaff_RBP + -0x80) = fVar29;
            *(float *)(unaff_RBP + -0x74) = fVar23;
            *(float *)(unaff_RBP + -0x7c) = fVar27;
            if (fVar30 < fVar29) {
                *(float *)(unaff_RBP + -0x80) = fVar30;
                *(float *)(unaff_RBP + -0x78) = fVar29;
            }
            if (fVar23 < fVar27) {
                *(float *)(unaff_RBP + -0x7c) = fVar23;
                *(float *)(unaff_RBP + -0x74) = fVar27;
            }
            piVar12 = &arg_60h;
            arg_60h._0_4_ = uVar17;
            uVar14 = ~*(uint32_t *)(*(int64_t *)(unaff_RDI + 0x150) + -4 + (int64_t)*(int32_t *)(unaff_RDI + 0x148) * 4)
            ;
            do {
                uVar1 = *(uint8_t *)piVar12;
                piVar12 = (int64_t *)((int64_t)piVar12 + 1);
                uVar14 = uVar14 >> 8 ^ *(uint32_t *)(((uint64_t)(uVar14 & 0xff) ^ (uint64_t)uVar1) * 4 + 0x180618620);
            } while (piVar12 < (int64_t *)((int64_t)&arg_60h + 4U));
            func_0x00018010b530(unaff_RBP + -0x80, ~uVar14, 0, 2);
            func_0x000180139d40(unaff_RBP + -0x80, ~uVar14, (int64_t)&arg_30h + 2, (int64_t)&arg_30h + 1, 0x40800);
            if ((arg_30h._2_1_ == '\0') && (arg_30h._1_1_ == '\0')) {
code_r0x0001800ffe50:
                if ((uVar17 == 0) && ((*(uint32_t *)(unaff_RDI + 0x14) & 0x1000000) == 0)) goto code_r0x0001800ffe5e;
            } else {
                *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2650) = (~uVar17 & 1) + 5;
                if (arg_30h._1_1_ == '\0') {
code_r0x0001800ffe47:
                    if (arg_30h._2_1_ == '\0') goto code_r0x0001800ffe50;
                } else {
                    if (*(char *)(iVar7 + 0xb55) == '\0') {
                        fVar23 = *(float *)(iVar16 + 0x1806185c4);
                        if ((fVar23 != 1.0) && ((fVar23 != 0.0 || (arg_30h._3_1_ == '\0')))) {
                            fVar31 = -3.402823e+38;
                        }
                        fVar29 = *pfVar18;
                        arg_78h._0_4_ = (float)arg_48h;
                        if (fVar29 != 1.0) {
                            arg_78h._0_4_ = -3.402823e+38;
                        }
                        fVar27 = arg_40h._4_4_;
                        if (fVar23 != 0.0) {
                            fVar27 = 3.402823e+38;
                        }
                        fVar22 = 3.402823e+38;
                        if (fVar29 == 0.0) {
                            fVar22 = (float)arg_38h;
                        }
                        fVar30 = *(float *)(iVar16 + 0x1806185cc) * fVar20;
                        fVar24 = *(float *)(iVar16 + 0x1806185c8) * fVar20;
                        fVar24 = ((float)((uint32_t)(float)arg_40h ^ 0x80000000) * *(float *)(iVar16 + 0x1806185c8) -
                                 fVar24) * fVar29 + fVar24;
                        fVar23 = (*(float *)(iVar7 + 0x11c) - *(float *)(iVar7 + 0x1670)) +
                                 ((float)((uint32_t)(float)arg_40h ^ 0x80000000) * *(float *)(iVar16 + 0x1806185cc) -
                                 fVar30) * fVar23 + fVar30;
                        fVar29 = (*(float *)(iVar7 + 0x118) - *(float *)(iVar7 + 0x166c)) + fVar24;
                        arg_78h._4_4_ = fVar31;
                        if ((fVar31 <= fVar23) && (arg_78h._4_4_ = fVar27, fVar23 <= fVar27)) {
                            arg_78h._4_4_ = fVar23;
                        }
                        if (((float)arg_78h <= fVar29) && (arg_78h._0_4_ = fVar22, fVar29 <= fVar22)) {
                            arg_78h._0_4_ = fVar29;
                        }
                        func_0x0001800ff590(fVar24, &arg_78h, pfVar18, &arg_70h, &arg_50h);
                        fVar31 = *(float *)(unaff_RBP + 0xa0);
                    } else {
                        func_0x0001800ff2b0(&arg_58h);
                        piVar12 = (int64_t *)func_0x0001800ff010(unaff_RBP + -0x60);
                        arg_48h._4_4_ = 3;
                        arg_50h = *piVar12;
                        func_0x0001800f9f30(0, 0);
                    }
                    if (arg_30h._1_1_ == '\0') goto code_r0x0001800ffe47;
                }
code_r0x0001800ffe5e:
                iVar16 = *(int64_t *)0x180781f28;
                if (arg_30h._1_1_ == '\0') {
                    iVar10 = (uint64_t)(arg_30h._2_1_ != '\0') + 0x1e;
                } else {
                    iVar10 = 0x20;
                }
                puVar11 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar10 + 0x14) * 0x10);
                uVar9 = puVar11[1];
                uVar4 = puVar11[2];
                fVar23 = (float)puVar11[3];
                *(undefined4 *)(unaff_RBP + -0x70) = *puVar11;
                *(undefined4 *)(unaff_RBP + -0x6c) = uVar9;
                *(undefined4 *)(unaff_RBP + -0x68) = uVar4;
                *(float *)(unaff_RBP + -100) = fVar23;
                *(float *)(unaff_RBP + -100) = fVar23 * *(float *)(iVar16 + 0xd9c);
                uVar9 = func_0x0001800f5fa0(unaff_RBP + -0x70);
                *(undefined4 *)(*(int64_t *)(unaff_RBP + 0xc0) + iVar15 * 4) = uVar9;
            }
            uVar17 = uVar17 + 1;
            iVar15 = iVar15 + 1;
            fVar23 = (float)arg_40h;
        } while ((int32_t)uVar17 < unaff_R13D);
        unaff_RBX = *(uint32_t **)(unaff_RBP + 0xb0);
        fVar29 = (float)arg_48h;
        fVar27 = arg_40h._4_4_;
    }
    if ((*(uint32_t *)(unaff_RDI + 0x14) & 0x1000000) == 0) {
        uVar17 = -(uint32_t)(*(char *)(iVar7 + 0x92) != '\0') & 0xf;
    } else {
        uVar17 = *(uint32_t *)(unaff_RDI + 0x1c) >> 1 & 2 | *(uint32_t *)(unaff_RDI + 0x1c) & 8;
    }
    fVar23 = (float)arg_38h;
    uVar14 = 0;
    arg_48h._0_4_ = 1.401298e-45;
    arg_40h._4_4_ = (float)uVar17;
    do {
        fVar20 = (float)arg_40h;
        iVar15 = 0x180000000;
        if ((uVar17 & (uint32_t)(float)arg_48h) != 0) {
            if (uVar14 < 2) {
                arg_38h = (uint64_t)(uint32_t)arg_38h._4_4_ << 0x20;
                uVar9 = 4;
                iVar16 = 0;
            } else {
                arg_38h = CONCAT44(arg_38h._4_4_, 1);
                uVar9 = 3;
                iVar16 = 4;
            }
            var_20h = (int64_t)*(uint32_t *)(iVar7 + 0x15d4);
            func_0x0001800ff770(unaff_RBP + -0x70);
            arg_68h._0_4_ = uVar14 + 4;
            piVar12 = &arg_68h;
            uVar17 = ~*(uint32_t *)(*(int64_t *)(unaff_RDI + 0x150) + -4 + (int64_t)*(int32_t *)(unaff_RDI + 0x148) * 4)
            ;
            do {
                uVar1 = *(uint8_t *)piVar12;
                piVar12 = (int64_t *)((int64_t)piVar12 + 1);
                uVar17 = uVar17 >> 8 ^
                         *(uint32_t *)(iVar15 + 0x618620 + ((uint64_t)(uVar17 & 0xff) ^ (uint64_t)uVar1) * 4);
            } while (piVar12 < (int64_t *)((int64_t)&arg_68h + 4U));
            func_0x00018010b530(unaff_RBP + -0x70, ~uVar17, 0, 2, var_20h);
            func_0x000180139d40(unaff_RBP + -0x70, ~uVar17, unaff_RBP + 0xa0, &arg_30h, 0x40800);
            if (*(char *)(unaff_RBP + 0xa0) == '\0') {
code_r0x00018010002f:
                if ((char)arg_30h != '\0') goto code_r0x00018010003a;
            } else {
                if (*(float *)(iVar7 + 0x1648) <= 0.04) {
                    *(undefined *)(unaff_RBP + 0xa0) = 0;
                    goto code_r0x00018010002f;
                }
code_r0x00018010003a:
                *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2650) = uVar9;
                if ((char)arg_30h != '\0') {
                    if (*(char *)(iVar7 + 0xb55) == '\0') {
                        iVar15 = *(int64_t *)(iVar7 + 0x1608);
                        iVar16 = (uint64_t)uVar14 * 0x1c;
                        if ((iVar15 == 0) ||
                           (iVar10 = unaff_RDI, *(int32_t *)(iVar7 + 0x161c) != *(int32_t *)(iVar7 + 4))) {
code_r0x00018010011c:
                            bVar19 = false;
                        } else {
                            do {
                                iVar3 = *(int64_t *)(*(int64_t *)(iVar10 + 0x418) + 0x428);
                                bVar19 = iVar10 != iVar3;
                                iVar10 = iVar3;
                            } while (bVar19);
                            iVar10 = unaff_RDI;
                            if (iVar3 != iVar15) {
                                do {
                                    if (iVar10 == iVar15) goto code_r0x000180100247;
                                } while ((iVar10 != iVar3) &&
                                        (piVar12 = (int64_t *)(iVar10 + 0x408), iVar10 = *piVar12, *piVar12 != 0));
                                goto code_r0x00018010011c;
                            }
code_r0x000180100247:
                            bVar19 = true;
                        }
                        if ((*(char *)(iVar7 + 0x1660) != '\0') || (bVar19)) {
                            uVar9 = *(undefined4 *)(unaff_RBP + -0x70);
                            uVar4 = *(undefined4 *)(unaff_RBP + -0x6c);
                            uVar5 = *(undefined4 *)(unaff_RBP + -0x68);
                            uVar6 = *(undefined4 *)(unaff_RBP + -100);
                            *(undefined *)(iVar7 + 0x27fc) = 0;
                            *(undefined4 *)(iVar7 + 0x27ec) = uVar9;
                            *(undefined4 *)(iVar7 + 0x27f0) = uVar4;
                            *(undefined4 *)(iVar7 + 0x27f4) = uVar5;
                            *(undefined4 *)(iVar7 + 0x27f8) = uVar6;
                        }
                        if (((*(uint32_t *)(unaff_RDI + 0x14) & 0x1000000) != 0) &&
                           ((*(int64_t *)(iVar7 + 0x27ec) != *(int64_t *)(unaff_RBP + -0x70) ||
                            (*(int64_t *)(iVar7 + 0x27f4) != *(int64_t *)(unaff_RBP + -0x68))))) {
                            *(undefined *)(iVar7 + 0x27fc) = 1;
                        }
                        uVar13 = arg_38h & 0xffffffff;
                        fVar22 = *(float *)(iVar16 + 0x180618478);
                        if (*(float *)(iVar16 + 0x180618480) <= *(float *)(iVar16 + 0x180618478)) {
                            fVar22 = *(float *)(iVar16 + 0x180618480);
                        }
                        fVar24 = *(float *)(iVar16 + 0x18061847c);
                        if (*(float *)(iVar16 + 0x180618484) <= *(float *)(iVar16 + 0x18061847c)) {
                            fVar24 = *(float *)(iVar16 + 0x180618484);
                        }
                        fVar30 = *(float *)(unaff_RDI + 0x6c);
                        fVar25 = (*(float *)(iVar7 + 0x118 + uVar13 * 4) - *(float *)(iVar7 + 0x166c + uVar13 * 4)) +
                                 *(float *)(iVar7 + 0x15d4);
                        fVar21 = *(float *)(unaff_RDI + 100);
                        arg_78h._0_4_ = fVar22 * *(float *)(unaff_RDI + 0x68) + *(float *)(unaff_RDI + 0x60);
                        arg_38h = *(int64_t *)(unaff_RDI + 0x60);
                        *(float *)((int64_t)&arg_38h + uVar13 * 4) = fVar25;
                        bVar19 = false;
                        arg_78h._4_4_ = fVar24 * fVar30 + fVar21;
                        if (*(char *)(iVar7 + 0x27fc) != '\0') {
                            fVar30 = *(float *)(iVar7 + 0x104 + uVar13 * 4);
                            fVar21 = fVar30 + *(float *)((int64_t)&arg_78h + uVar13 * 4);
                            *(float *)((int64_t)&arg_38h + uVar13 * 4) = fVar21;
                            if ((fVar30 == 0.0) || (0.0 < fVar30 == fVar25 < fVar21)) {
                                bVar19 = true;
                            }
                        }
                        fVar30 = fVar31;
                        if ((uVar14 != 3) && ((uVar14 != 2 || (arg_30h._3_1_ == '\0')))) {
                            fVar30 = -3.402823e+38;
                        }
                        if (uVar14 == 1) {
                            fVar21 = fVar29;
                            fVar8 = 3.402823e+38;
code_r0x000180100264:
                            fVar26 = fVar8;
                            fVar28 = 3.402823e+38;
                            fVar25 = fVar21;
                        } else {
                            fVar25 = -3.402823e+38;
                            fVar21 = -3.402823e+38;
                            fVar8 = fVar27;
                            if (uVar14 == 2) goto code_r0x000180100264;
                            fVar26 = 3.402823e+38;
                            fVar28 = fVar23;
                            fVar8 = 3.402823e+38;
                            if (uVar14 != 0) goto code_r0x000180100264;
                        }
                        if ((fVar30 <= arg_38h._4_4_) && (fVar30 = fVar26, arg_38h._4_4_ <= fVar26)) {
                            fVar30 = arg_38h._4_4_;
                        }
                        if ((fVar25 <= (float)arg_38h) && (fVar25 = fVar28, (float)arg_38h <= fVar28)) {
                            fVar25 = (float)arg_38h;
                        }
                        arg_38h = CONCAT44(fVar30, fVar25);
                        if (!bVar19) {
                            arg_58h._0_4_ = fVar22;
                            arg_58h._4_4_ = fVar24;
                            func_0x0001800ff590();
                        }
                    } else {
                        if ((uVar14 - 1 & 0xfffffffd) == 0) {
                            func_0x0001800ff2b0(unaff_RBP + -0x60);
                            iVar15 = func_0x0001800ff010(unaff_RBP + -0x58);
                            *(undefined4 *)((int64_t)&arg_50h + (arg_38h & 0xffffffffU) * 4) =
                                 *(undefined4 *)(iVar15 + iVar16);
                            arg_48h._4_4_ = arg_48h._4_4_ | 1 << ((uint32_t)(float)arg_38h & 0x1f);
                            arg_30h._0_1_ = '\0';
                            *(undefined *)(unaff_RBP + 0xa0) = 0;
                        }
                        func_0x0001800f9f30(0, 0);
                    }
                }
            }
            if (*(char *)(unaff_RBP + 0xa0) != '\0') {
                **(uint32_t **)(unaff_RBP + 0xa8) = uVar14;
            }
            unaff_RBX = *(uint32_t **)(unaff_RBP + 0xb0);
            uVar17 = (uint32_t)arg_40h._4_4_;
            if ((char)arg_30h != '\0') {
                *unaff_RBX = uVar14;
            }
        }
        arg_48h._0_4_ = (float)((int32_t)(float)arg_48h << 1 | (uint32_t)((int32_t)(float)arg_48h < 0));
        uVar14 = uVar14 + 1;
    } while ((int32_t)uVar14 < 4);
    iVar2 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
    if (iVar2 < 2) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
        }
    } else {
        *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar2 + -1;
    }
    *(undefined4 *)(unaff_RDI + 0x1b0) = 0;
    iVar15 = *(int64_t *)0x180781f28;
    if ((*(int64_t *)(iVar7 + 0x23c0) != 0) && (*(int64_t *)(*(int64_t *)(iVar7 + 0x23c0) + 0x428) == unaff_RDI)) {
        if (*(int32_t *)(iVar7 + 0x2228) == 2) {
            if (*(char *)(iVar7 + 0x139) == '\0') goto code_r0x00018010059a;
            fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x16c) - *(float *)(*(int64_t *)0x180781f28 + 0x15c);
            fVar27 = *(float *)(*(int64_t *)0x180781f28 + 0x18c) - *(float *)(*(int64_t *)0x180781f28 + 0x17c);
        } else {
            if (*(int32_t *)(iVar7 + 0x2228) != 3) goto code_r0x00018010059a;
            fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x93c) - *(float *)(*(int64_t *)0x180781f28 + 0x92c);
            fVar27 = *(float *)(*(int64_t *)0x180781f28 + 0x95c) - *(float *)(*(int64_t *)0x180781f28 + 0x94c);
        }
        if ((fVar23 != 0.0) || (fVar27 != 0.0)) {
            fVar22 = *(float *)(iVar7 + 0x48) * 600.0 * *(float *)(*(int64_t *)0x180781f28 + 0x12c4);
            fVar27 = fVar22 * fVar27 + *(float *)(iVar7 + 0x23f8);
            fVar23 = fVar22 * fVar23 + *(float *)(iVar7 + 0x23f4);
            *(float *)(iVar7 + 0x23f8) = fVar27;
            *(float *)(iVar7 + 0x23f4) = fVar23;
            fVar31 = (fVar31 - *(float *)(unaff_RDI + 100)) - *(float *)(unaff_RDI + 0x6c);
            fVar29 = (fVar29 - *(float *)(unaff_RDI + 0x60)) - *(float *)(unaff_RDI + 0x68);
            *(undefined *)(iVar7 + 0x23e4) = 0;
            *(undefined *)(iVar7 + 0x21cd) = 1;
            if (fVar27 <= fVar31) {
                fVar27 = fVar31;
            }
            if (fVar23 <= fVar29) {
                fVar23 = fVar29;
            }
            *(float *)(iVar7 + 0x23f8) = fVar27;
            *(float *)(iVar7 + 0x23f4) = fVar23;
            uVar9 = *(undefined4 *)(iVar15 + 0x10d4);
            uVar4 = *(undefined4 *)(iVar15 + 0x10d8);
            fVar23 = *(float *)(iVar15 + 0x10dc);
            *(undefined4 *)(unaff_RBP + -0x58) = *(undefined4 *)(iVar15 + 0x10d0);
            *(undefined4 *)(unaff_RBP + -0x54) = uVar9;
            *(undefined4 *)(unaff_RBP + -0x50) = uVar4;
            *(float *)(unaff_RBP + -0x4c) = fVar23;
            *(float *)(unaff_RBP + -0x4c) = fVar23 * *(float *)(iVar15 + 0xd9c);
            uVar9 = func_0x0001800f5fa0(unaff_RBP + -0x58);
            **(undefined4 **)(unaff_RBP + 0xc0) = uVar9;
            fVar29 = (float)(int32_t)*(float *)(iVar7 + 0x23f4);
            fVar23 = (float)(int32_t)*(float *)(iVar7 + 0x23f8);
            if ((fVar29 != 0.0) || (fVar23 != 0.0)) {
                arg_58h._0_4_ = fVar29 + *(float *)(unaff_RDI + 0x70);
                arg_58h._4_4_ = fVar23 + *(float *)(unaff_RDI + 0x74);
                piVar12 = (int64_t *)func_0x0001800ff010(unaff_RBP + -0x58, arg_58h._4_4_, &arg_58h);
                arg_50h = *piVar12;
                *(float *)(iVar7 + 0x23f4) = *(float *)(iVar7 + 0x23f4) - fVar29;
                *(float *)(iVar7 + 0x23f8) = *(float *)(iVar7 + 0x23f8) - fVar23;
            }
        }
    }
code_r0x00018010059a:
    fVar23 = *(float *)(unaff_RDI + 0x60);
    fVar29 = *(float *)(unaff_RDI + 100);
    fVar27 = *(float *)(unaff_RDI + 0x70);
    fVar31 = *(float *)(unaff_RDI + 0x74);
    fVar22 = fVar27;
    if (((float)arg_50h != 3.402823e+38) &&
       ((*(float *)(unaff_RDI + 0x68) != (float)arg_50h || (fVar27 != (float)arg_50h)))) {
        *(float *)(unaff_RDI + 0x70) = (float)arg_50h;
        *(float *)(unaff_RDI + 0x68) = (float)arg_50h;
        fVar22 = (float)arg_50h;
    }
    if ((arg_50h._4_4_ != 3.402823e+38) &&
       ((*(float *)(unaff_RDI + 0x6c) != arg_50h._4_4_ || (*(float *)(unaff_RDI + 0x74) != arg_50h._4_4_)))) {
        *(float *)(unaff_RDI + 0x74) = arg_50h._4_4_;
        *(float *)(unaff_RDI + 0x6c) = arg_50h._4_4_;
    }
    if (((float)arg_70h != 3.402823e+38) && (fVar23 != (float)(int32_t)(float)arg_70h)) {
        *(float *)(unaff_RDI + 0x60) = (float)(int32_t)(float)arg_70h;
    }
    if ((arg_70h._4_4_ != 3.402823e+38) && (*(float *)(unaff_RDI + 100) != (float)(int32_t)arg_70h._4_4_)) {
        *(float *)(unaff_RDI + 100) = (float)(int32_t)arg_70h._4_4_;
    }
    if (((((fVar23 != *(float *)(unaff_RDI + 0x60)) || (fVar29 != *(float *)(unaff_RDI + 100))) || (fVar27 != fVar22))
        || (fVar31 != *(float *)(unaff_RDI + 0x74))) &&
       (((*(uint32_t *)(unaff_RDI + 0x14) & 0x100) == 0 && (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0)))) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
    }
    if (*unaff_RBX != 0xffffffff) {
        var_20h = (int64_t)*(uint32_t *)(iVar7 + 0x15d4);
        puVar11 = (undefined4 *)func_0x0001800ff770(unaff_RBP + -0x70, fVar22, *unaff_RBX, fVar20, var_20h);
        uVar9 = puVar11[1];
        uVar4 = puVar11[2];
        uVar5 = puVar11[3];
        *(undefined4 *)(iVar7 + 0x27ec) = *puVar11;
        *(undefined4 *)(iVar7 + 0x27f0) = uVar9;
        *(undefined4 *)(iVar7 + 0x27f4) = uVar4;
        *(undefined4 *)(iVar7 + 0x27f8) = uVar5;
    }
    return arg_48h._4_4_;
}

// ============================================================
// Function: FUN_1801006f3
// Address: 0x1801006f3
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: arg_1b8h
// WARNING: Variable defined which should be unmapped: arg_170h
// WARNING: Variable defined which should be unmapped: arg_168h
// WARNING: Variable defined which should be unmapped: arg_160h
// WARNING: Variable defined which should be unmapped: arg_150h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h
// WARNING: [rz-ghidra] Detected overlap for variable arg_33h
// WARNING: [rz-ghidra] Detected overlap for variable arg_74h
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_7ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Detected overlap for variable arg_31h
// WARNING: [rz-ghidra] Detected overlap for variable arg_32h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

uint32_t fcn.1800ff916(int64_t arg_30h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                      int64_t arg_70h, int64_t arg_78h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h,
                      int64_t arg_c0h, int64_t arg_c8h, int64_t arg_d0h, int64_t arg_e0h, int64_t arg_f0h,
                      int64_t arg_100h, int64_t arg_110h, int64_t arg_120h, int64_t arg_130h, int64_t arg_140h,
                      int64_t arg_150h, int64_t arg_160h, int64_t arg_168h, int64_t arg_170h, int64_t arg_1b8h)
{
    uint8_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    float fVar8;
    undefined4 uVar9;
    int64_t iVar10;
    undefined4 *puVar11;
    uint64_t in_RCX;
    int64_t *piVar12;
    uint64_t uVar13;
    uint32_t uVar14;
    uint32_t *unaff_RBX;
    int64_t unaff_RBP;
    int64_t unaff_RDI;
    int64_t iVar15;
    int32_t unaff_R13D;
    int64_t iVar16;
    uint32_t uVar17;
    float *pfVar18;
    bool bVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    float fVar31;
    int64_t var_20h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_4ch;
    
    iVar7 = *(int64_t *)0x180781f28;
    arg_48h._4_4_ = 0;
    if (unaff_R13D < 1) {
        fVar23 = 0.0;
    } else {
        fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) * 1.35;
        fVar20 = *(float *)(unaff_RDI + 0x98) + 1.0 + *(float *)(*(int64_t *)0x180781f28 + 0x12f8) * 0.2;
        if (fVar23 <= fVar20) {
            fVar23 = fVar20;
        }
        fVar23 = (float)(int32_t)((float)(int32_t)fVar23 * 0.75);
    }
    pfVar18 = *(float **)(unaff_RBP + 200);
    fVar20 = *(float *)(*(int64_t *)0x180781f28 + 0x15d4);
    fVar29 = *pfVar18;
    fVar27 = pfVar18[3];
    fVar31 = pfVar18[1];
    arg_38h = CONCAT44(arg_38h._4_4_, pfVar18[2]);
    if (((*(uint8_t *)(unaff_RDI + 0x130) & 1) == 0) && ((in_RCX & 1) == 0)) {
        fVar31 = fVar31 - *(float *)(unaff_RDI + 0xa0);
        arg_30h._3_1_ = '\x01';
    } else {
        arg_30h._3_1_ = '\0';
    }
    uVar17 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x34);
    *(float *)(unaff_RBP + 0xa0) = fVar31;
    arg_70h._0_4_ = 3.402823e+38;
    arg_70h._4_4_ = 3.402823e+38;
    arg_50h = 0x7f7fffff7f7fffff;
    if ((((uVar17 & 0x1000) == 0) || (*(int32_t *)(iVar7 + 0x134) != *(int32_t *)(unaff_RDI + 0x50))) ||
       ((*(uint8_t *)(*(int64_t *)(unaff_RDI + 0x48) + 4) & 8) == 0)) {
        iVar15 = *(int64_t *)(unaff_RDI + 0x48);
        fVar22 = *(float *)(iVar15 + 8);
        fVar24 = *(float *)(iVar15 + 0xc);
        fVar30 = *(float *)(iVar15 + 0x10);
        fVar21 = *(float *)(iVar15 + 0x14);
        *(float *)(unaff_RDI + 0x2b8) = fVar22;
        *(float *)(unaff_RDI + 700) = fVar24;
        *(float *)(unaff_RDI + 0x2c0) = fVar22 + fVar30;
        *(float *)(unaff_RDI + 0x2c4) = fVar24 + fVar21;
    }
    *(undefined4 *)(unaff_RDI + 0x1b0) = 1;
    arg_40h._0_4_ = fVar23;
    arg_40h._4_4_ = fVar27;
    arg_48h._0_4_ = fVar29;
    func_0x000180107590();
    uVar17 = 0;
    if (0 < unaff_R13D) {
        iVar15 = 0;
        do {
            fVar29 = *(float *)(unaff_RDI + 0x60);
            fVar27 = *(float *)(unaff_RDI + 100);
            iVar16 = iVar15 * 0x18;
            fVar22 = *(float *)(iVar15 * 0x18 + 0x1806185cc);
            fVar24 = *(float *)(iVar15 * 0x18 + 0x1806185c8);
            pfVar18 = (float *)(iVar16 + 0x1806185c0);
            fVar29 = ((fVar29 + *(float *)(unaff_RDI + 0x68)) - fVar29) * *pfVar18 + fVar29;
            fVar30 = fVar23 * fVar24 + fVar29;
            fVar27 = ((fVar27 + *(float *)(unaff_RDI + 0x6c)) - fVar27) * *(float *)(iVar15 * 0x18 + 0x1806185c4) +
                     fVar27;
            fVar29 = fVar29 - fVar20 * fVar24;
            *(float *)(unaff_RBP + -0x78) = fVar30;
            fVar23 = fVar22 * (float)arg_40h + fVar27;
            fVar27 = fVar27 - fVar22 * fVar20;
            *(float *)(unaff_RBP + -0x80) = fVar29;
            *(float *)(unaff_RBP + -0x74) = fVar23;
            *(float *)(unaff_RBP + -0x7c) = fVar27;
            if (fVar30 < fVar29) {
                *(float *)(unaff_RBP + -0x80) = fVar30;
                *(float *)(unaff_RBP + -0x78) = fVar29;
            }
            if (fVar23 < fVar27) {
                *(float *)(unaff_RBP + -0x7c) = fVar23;
                *(float *)(unaff_RBP + -0x74) = fVar27;
            }
            piVar12 = &arg_60h;
            arg_60h._0_4_ = uVar17;
            uVar14 = ~*(uint32_t *)(*(int64_t *)(unaff_RDI + 0x150) + -4 + (int64_t)*(int32_t *)(unaff_RDI + 0x148) * 4)
            ;
            do {
                uVar1 = *(uint8_t *)piVar12;
                piVar12 = (int64_t *)((int64_t)piVar12 + 1);
                uVar14 = uVar14 >> 8 ^ *(uint32_t *)(((uint64_t)(uVar14 & 0xff) ^ (uint64_t)uVar1) * 4 + 0x180618620);
            } while (piVar12 < (int64_t *)((int64_t)&arg_60h + 4U));
            func_0x00018010b530(unaff_RBP + -0x80, ~uVar14, 0, 2);
            func_0x000180139d40(unaff_RBP + -0x80, ~uVar14, (int64_t)&arg_30h + 2, (int64_t)&arg_30h + 1, 0x40800);
            if ((arg_30h._2_1_ == '\0') && (arg_30h._1_1_ == '\0')) {
code_r0x0001800ffe50:
                if ((uVar17 == 0) && ((*(uint32_t *)(unaff_RDI + 0x14) & 0x1000000) == 0)) goto code_r0x0001800ffe5e;
            } else {
                *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2650) = (~uVar17 & 1) + 5;
                if (arg_30h._1_1_ == '\0') {
code_r0x0001800ffe47:
                    if (arg_30h._2_1_ == '\0') goto code_r0x0001800ffe50;
                } else {
                    if (*(char *)(iVar7 + 0xb55) == '\0') {
                        fVar23 = *(float *)(iVar16 + 0x1806185c4);
                        if ((fVar23 != 1.0) && ((fVar23 != 0.0 || (arg_30h._3_1_ == '\0')))) {
                            fVar31 = -3.402823e+38;
                        }
                        fVar29 = *pfVar18;
                        arg_78h._0_4_ = (float)arg_48h;
                        if (fVar29 != 1.0) {
                            arg_78h._0_4_ = -3.402823e+38;
                        }
                        fVar27 = arg_40h._4_4_;
                        if (fVar23 != 0.0) {
                            fVar27 = 3.402823e+38;
                        }
                        fVar22 = 3.402823e+38;
                        if (fVar29 == 0.0) {
                            fVar22 = (float)arg_38h;
                        }
                        fVar30 = *(float *)(iVar16 + 0x1806185cc) * fVar20;
                        fVar24 = *(float *)(iVar16 + 0x1806185c8) * fVar20;
                        fVar24 = ((float)((uint32_t)(float)arg_40h ^ 0x80000000) * *(float *)(iVar16 + 0x1806185c8) -
                                 fVar24) * fVar29 + fVar24;
                        fVar23 = (*(float *)(iVar7 + 0x11c) - *(float *)(iVar7 + 0x1670)) +
                                 ((float)((uint32_t)(float)arg_40h ^ 0x80000000) * *(float *)(iVar16 + 0x1806185cc) -
                                 fVar30) * fVar23 + fVar30;
                        fVar29 = (*(float *)(iVar7 + 0x118) - *(float *)(iVar7 + 0x166c)) + fVar24;
                        arg_78h._4_4_ = fVar31;
                        if ((fVar31 <= fVar23) && (arg_78h._4_4_ = fVar27, fVar23 <= fVar27)) {
                            arg_78h._4_4_ = fVar23;
                        }
                        if (((float)arg_78h <= fVar29) && (arg_78h._0_4_ = fVar22, fVar29 <= fVar22)) {
                            arg_78h._0_4_ = fVar29;
                        }
                        func_0x0001800ff590(fVar24, &arg_78h, pfVar18, &arg_70h, &arg_50h);
                        fVar31 = *(float *)(unaff_RBP + 0xa0);
                    } else {
                        func_0x0001800ff2b0(&arg_58h);
                        piVar12 = (int64_t *)func_0x0001800ff010(unaff_RBP + -0x60);
                        arg_48h._4_4_ = 3;
                        arg_50h = *piVar12;
                        func_0x0001800f9f30(0, 0);
                    }
                    if (arg_30h._1_1_ == '\0') goto code_r0x0001800ffe47;
                }
code_r0x0001800ffe5e:
                iVar16 = *(int64_t *)0x180781f28;
                if (arg_30h._1_1_ == '\0') {
                    iVar10 = (uint64_t)(arg_30h._2_1_ != '\0') + 0x1e;
                } else {
                    iVar10 = 0x20;
                }
                puVar11 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar10 + 0x14) * 0x10);
                uVar9 = puVar11[1];
                uVar4 = puVar11[2];
                fVar23 = (float)puVar11[3];
                *(undefined4 *)(unaff_RBP + -0x70) = *puVar11;
                *(undefined4 *)(unaff_RBP + -0x6c) = uVar9;
                *(undefined4 *)(unaff_RBP + -0x68) = uVar4;
                *(float *)(unaff_RBP + -100) = fVar23;
                *(float *)(unaff_RBP + -100) = fVar23 * *(float *)(iVar16 + 0xd9c);
                uVar9 = func_0x0001800f5fa0(unaff_RBP + -0x70);
                *(undefined4 *)(*(int64_t *)(unaff_RBP + 0xc0) + iVar15 * 4) = uVar9;
            }
            uVar17 = uVar17 + 1;
            iVar15 = iVar15 + 1;
            fVar23 = (float)arg_40h;
        } while ((int32_t)uVar17 < unaff_R13D);
        unaff_RBX = *(uint32_t **)(unaff_RBP + 0xb0);
        fVar29 = (float)arg_48h;
        fVar27 = arg_40h._4_4_;
    }
    if ((*(uint32_t *)(unaff_RDI + 0x14) & 0x1000000) == 0) {
        uVar17 = -(uint32_t)(*(char *)(iVar7 + 0x92) != '\0') & 0xf;
    } else {
        uVar17 = *(uint32_t *)(unaff_RDI + 0x1c) >> 1 & 2 | *(uint32_t *)(unaff_RDI + 0x1c) & 8;
    }
    fVar23 = (float)arg_38h;
    uVar14 = 0;
    arg_48h._0_4_ = 1.401298e-45;
    arg_40h._4_4_ = (float)uVar17;
    do {
        fVar20 = (float)arg_40h;
        iVar15 = 0x180000000;
        if ((uVar17 & (uint32_t)(float)arg_48h) != 0) {
            if (uVar14 < 2) {
                arg_38h = (uint64_t)(uint32_t)arg_38h._4_4_ << 0x20;
                uVar9 = 4;
                iVar16 = 0;
            } else {
                arg_38h = CONCAT44(arg_38h._4_4_, 1);
                uVar9 = 3;
                iVar16 = 4;
            }
            var_20h = (int64_t)*(uint32_t *)(iVar7 + 0x15d4);
            func_0x0001800ff770(unaff_RBP + -0x70);
            arg_68h._0_4_ = uVar14 + 4;
            piVar12 = &arg_68h;
            uVar17 = ~*(uint32_t *)(*(int64_t *)(unaff_RDI + 0x150) + -4 + (int64_t)*(int32_t *)(unaff_RDI + 0x148) * 4)
            ;
            do {
                uVar1 = *(uint8_t *)piVar12;
                piVar12 = (int64_t *)((int64_t)piVar12 + 1);
                uVar17 = uVar17 >> 8 ^
                         *(uint32_t *)(iVar15 + 0x618620 + ((uint64_t)(uVar17 & 0xff) ^ (uint64_t)uVar1) * 4);
            } while (piVar12 < (int64_t *)((int64_t)&arg_68h + 4U));
            func_0x00018010b530(unaff_RBP + -0x70, ~uVar17, 0, 2, var_20h);
            func_0x000180139d40(unaff_RBP + -0x70, ~uVar17, unaff_RBP + 0xa0, &arg_30h, 0x40800);
            if (*(char *)(unaff_RBP + 0xa0) == '\0') {
code_r0x00018010002f:
                if ((char)arg_30h != '\0') goto code_r0x00018010003a;
            } else {
                if (*(float *)(iVar7 + 0x1648) <= 0.04) {
                    *(undefined *)(unaff_RBP + 0xa0) = 0;
                    goto code_r0x00018010002f;
                }
code_r0x00018010003a:
                *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2650) = uVar9;
                if ((char)arg_30h != '\0') {
                    if (*(char *)(iVar7 + 0xb55) == '\0') {
                        iVar15 = *(int64_t *)(iVar7 + 0x1608);
                        iVar16 = (uint64_t)uVar14 * 0x1c;
                        if ((iVar15 == 0) ||
                           (iVar10 = unaff_RDI, *(int32_t *)(iVar7 + 0x161c) != *(int32_t *)(iVar7 + 4))) {
code_r0x00018010011c:
                            bVar19 = false;
                        } else {
                            do {
                                iVar3 = *(int64_t *)(*(int64_t *)(iVar10 + 0x418) + 0x428);
                                bVar19 = iVar10 != iVar3;
                                iVar10 = iVar3;
                            } while (bVar19);
                            iVar10 = unaff_RDI;
                            if (iVar3 != iVar15) {
                                do {
                                    if (iVar10 == iVar15) goto code_r0x000180100247;
                                } while ((iVar10 != iVar3) &&
                                        (piVar12 = (int64_t *)(iVar10 + 0x408), iVar10 = *piVar12, *piVar12 != 0));
                                goto code_r0x00018010011c;
                            }
code_r0x000180100247:
                            bVar19 = true;
                        }
                        if ((*(char *)(iVar7 + 0x1660) != '\0') || (bVar19)) {
                            uVar9 = *(undefined4 *)(unaff_RBP + -0x70);
                            uVar4 = *(undefined4 *)(unaff_RBP + -0x6c);
                            uVar5 = *(undefined4 *)(unaff_RBP + -0x68);
                            uVar6 = *(undefined4 *)(unaff_RBP + -100);
                            *(undefined *)(iVar7 + 0x27fc) = 0;
                            *(undefined4 *)(iVar7 + 0x27ec) = uVar9;
                            *(undefined4 *)(iVar7 + 0x27f0) = uVar4;
                            *(undefined4 *)(iVar7 + 0x27f4) = uVar5;
                            *(undefined4 *)(iVar7 + 0x27f8) = uVar6;
                        }
                        if (((*(uint32_t *)(unaff_RDI + 0x14) & 0x1000000) != 0) &&
                           ((*(int64_t *)(iVar7 + 0x27ec) != *(int64_t *)(unaff_RBP + -0x70) ||
                            (*(int64_t *)(iVar7 + 0x27f4) != *(int64_t *)(unaff_RBP + -0x68))))) {
                            *(undefined *)(iVar7 + 0x27fc) = 1;
                        }
                        uVar13 = arg_38h & 0xffffffff;
                        fVar22 = *(float *)(iVar16 + 0x180618478);
                        if (*(float *)(iVar16 + 0x180618480) <= *(float *)(iVar16 + 0x180618478)) {
                            fVar22 = *(float *)(iVar16 + 0x180618480);
                        }
                        fVar24 = *(float *)(iVar16 + 0x18061847c);
                        if (*(float *)(iVar16 + 0x180618484) <= *(float *)(iVar16 + 0x18061847c)) {
                            fVar24 = *(float *)(iVar16 + 0x180618484);
                        }
                        fVar30 = *(float *)(unaff_RDI + 0x6c);
                        fVar25 = (*(float *)(iVar7 + 0x118 + uVar13 * 4) - *(float *)(iVar7 + 0x166c + uVar13 * 4)) +
                                 *(float *)(iVar7 + 0x15d4);
                        fVar21 = *(float *)(unaff_RDI + 100);
                        arg_78h._0_4_ = fVar22 * *(float *)(unaff_RDI + 0x68) + *(float *)(unaff_RDI + 0x60);
                        arg_38h = *(int64_t *)(unaff_RDI + 0x60);
                        *(float *)((int64_t)&arg_38h + uVar13 * 4) = fVar25;
                        bVar19 = false;
                        arg_78h._4_4_ = fVar24 * fVar30 + fVar21;
                        if (*(char *)(iVar7 + 0x27fc) != '\0') {
                            fVar30 = *(float *)(iVar7 + 0x104 + uVar13 * 4);
                            fVar21 = fVar30 + *(float *)((int64_t)&arg_78h + uVar13 * 4);
                            *(float *)((int64_t)&arg_38h + uVar13 * 4) = fVar21;
                            if ((fVar30 == 0.0) || (0.0 < fVar30 == fVar25 < fVar21)) {
                                bVar19 = true;
                            }
                        }
                        fVar30 = fVar31;
                        if ((uVar14 != 3) && ((uVar14 != 2 || (arg_30h._3_1_ == '\0')))) {
                            fVar30 = -3.402823e+38;
                        }
                        if (uVar14 == 1) {
                            fVar21 = fVar29;
                            fVar8 = 3.402823e+38;
code_r0x000180100264:
                            fVar26 = fVar8;
                            fVar28 = 3.402823e+38;
                            fVar25 = fVar21;
                        } else {
                            fVar25 = -3.402823e+38;
                            fVar21 = -3.402823e+38;
                            fVar8 = fVar27;
                            if (uVar14 == 2) goto code_r0x000180100264;
                            fVar26 = 3.402823e+38;
                            fVar28 = fVar23;
                            fVar8 = 3.402823e+38;
                            if (uVar14 != 0) goto code_r0x000180100264;
                        }
                        if ((fVar30 <= arg_38h._4_4_) && (fVar30 = fVar26, arg_38h._4_4_ <= fVar26)) {
                            fVar30 = arg_38h._4_4_;
                        }
                        if ((fVar25 <= (float)arg_38h) && (fVar25 = fVar28, (float)arg_38h <= fVar28)) {
                            fVar25 = (float)arg_38h;
                        }
                        arg_38h = CONCAT44(fVar30, fVar25);
                        if (!bVar19) {
                            arg_58h._0_4_ = fVar22;
                            arg_58h._4_4_ = fVar24;
                            func_0x0001800ff590();
                        }
                    } else {
                        if ((uVar14 - 1 & 0xfffffffd) == 0) {
                            func_0x0001800ff2b0(unaff_RBP + -0x60);
                            iVar15 = func_0x0001800ff010(unaff_RBP + -0x58);
                            *(undefined4 *)((int64_t)&arg_50h + (arg_38h & 0xffffffffU) * 4) =
                                 *(undefined4 *)(iVar15 + iVar16);
                            arg_48h._4_4_ = arg_48h._4_4_ | 1 << ((uint32_t)(float)arg_38h & 0x1f);
                            arg_30h._0_1_ = '\0';
                            *(undefined *)(unaff_RBP + 0xa0) = 0;
                        }
                        func_0x0001800f9f30(0, 0);
                    }
                }
            }
            if (*(char *)(unaff_RBP + 0xa0) != '\0') {
                **(uint32_t **)(unaff_RBP + 0xa8) = uVar14;
            }
            unaff_RBX = *(uint32_t **)(unaff_RBP + 0xb0);
            uVar17 = (uint32_t)arg_40h._4_4_;
            if ((char)arg_30h != '\0') {
                *unaff_RBX = uVar14;
            }
        }
        arg_48h._0_4_ = (float)((int32_t)(float)arg_48h << 1 | (uint32_t)((int32_t)(float)arg_48h < 0));
        uVar14 = uVar14 + 1;
    } while ((int32_t)uVar14 < 4);
    iVar2 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
    if (iVar2 < 2) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
        }
    } else {
        *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar2 + -1;
    }
    *(undefined4 *)(unaff_RDI + 0x1b0) = 0;
    iVar15 = *(int64_t *)0x180781f28;
    if ((*(int64_t *)(iVar7 + 0x23c0) != 0) && (*(int64_t *)(*(int64_t *)(iVar7 + 0x23c0) + 0x428) == unaff_RDI)) {
        if (*(int32_t *)(iVar7 + 0x2228) == 2) {
            if (*(char *)(iVar7 + 0x139) == '\0') goto code_r0x00018010059a;
            fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x16c) - *(float *)(*(int64_t *)0x180781f28 + 0x15c);
            fVar27 = *(float *)(*(int64_t *)0x180781f28 + 0x18c) - *(float *)(*(int64_t *)0x180781f28 + 0x17c);
        } else {
            if (*(int32_t *)(iVar7 + 0x2228) != 3) goto code_r0x00018010059a;
            fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x93c) - *(float *)(*(int64_t *)0x180781f28 + 0x92c);
            fVar27 = *(float *)(*(int64_t *)0x180781f28 + 0x95c) - *(float *)(*(int64_t *)0x180781f28 + 0x94c);
        }
        if ((fVar23 != 0.0) || (fVar27 != 0.0)) {
            fVar22 = *(float *)(iVar7 + 0x48) * 600.0 * *(float *)(*(int64_t *)0x180781f28 + 0x12c4);
            fVar27 = fVar22 * fVar27 + *(float *)(iVar7 + 0x23f8);
            fVar23 = fVar22 * fVar23 + *(float *)(iVar7 + 0x23f4);
            *(float *)(iVar7 + 0x23f8) = fVar27;
            *(float *)(iVar7 + 0x23f4) = fVar23;
            fVar31 = (fVar31 - *(float *)(unaff_RDI + 100)) - *(float *)(unaff_RDI + 0x6c);
            fVar29 = (fVar29 - *(float *)(unaff_RDI + 0x60)) - *(float *)(unaff_RDI + 0x68);
            *(undefined *)(iVar7 + 0x23e4) = 0;
            *(undefined *)(iVar7 + 0x21cd) = 1;
            if (fVar27 <= fVar31) {
                fVar27 = fVar31;
            }
            if (fVar23 <= fVar29) {
                fVar23 = fVar29;
            }
            *(float *)(iVar7 + 0x23f8) = fVar27;
            *(float *)(iVar7 + 0x23f4) = fVar23;
            uVar9 = *(undefined4 *)(iVar15 + 0x10d4);
            uVar4 = *(undefined4 *)(iVar15 + 0x10d8);
            fVar23 = *(float *)(iVar15 + 0x10dc);
            *(undefined4 *)(unaff_RBP + -0x58) = *(undefined4 *)(iVar15 + 0x10d0);
            *(undefined4 *)(unaff_RBP + -0x54) = uVar9;
            *(undefined4 *)(unaff_RBP + -0x50) = uVar4;
            *(float *)(unaff_RBP + -0x4c) = fVar23;
            *(float *)(unaff_RBP + -0x4c) = fVar23 * *(float *)(iVar15 + 0xd9c);
            uVar9 = func_0x0001800f5fa0(unaff_RBP + -0x58);
            **(undefined4 **)(unaff_RBP + 0xc0) = uVar9;
            fVar29 = (float)(int32_t)*(float *)(iVar7 + 0x23f4);
            fVar23 = (float)(int32_t)*(float *)(iVar7 + 0x23f8);
            if ((fVar29 != 0.0) || (fVar23 != 0.0)) {
                arg_58h._0_4_ = fVar29 + *(float *)(unaff_RDI + 0x70);
                arg_58h._4_4_ = fVar23 + *(float *)(unaff_RDI + 0x74);
                piVar12 = (int64_t *)func_0x0001800ff010(unaff_RBP + -0x58, arg_58h._4_4_, &arg_58h);
                arg_50h = *piVar12;
                *(float *)(iVar7 + 0x23f4) = *(float *)(iVar7 + 0x23f4) - fVar29;
                *(float *)(iVar7 + 0x23f8) = *(float *)(iVar7 + 0x23f8) - fVar23;
            }
        }
    }
code_r0x00018010059a:
    fVar23 = *(float *)(unaff_RDI + 0x60);
    fVar29 = *(float *)(unaff_RDI + 100);
    fVar27 = *(float *)(unaff_RDI + 0x70);
    fVar31 = *(float *)(unaff_RDI + 0x74);
    fVar22 = fVar27;
    if (((float)arg_50h != 3.402823e+38) &&
       ((*(float *)(unaff_RDI + 0x68) != (float)arg_50h || (fVar27 != (float)arg_50h)))) {
        *(float *)(unaff_RDI + 0x70) = (float)arg_50h;
        *(float *)(unaff_RDI + 0x68) = (float)arg_50h;
        fVar22 = (float)arg_50h;
    }
    if ((arg_50h._4_4_ != 3.402823e+38) &&
       ((*(float *)(unaff_RDI + 0x6c) != arg_50h._4_4_ || (*(float *)(unaff_RDI + 0x74) != arg_50h._4_4_)))) {
        *(float *)(unaff_RDI + 0x74) = arg_50h._4_4_;
        *(float *)(unaff_RDI + 0x6c) = arg_50h._4_4_;
    }
    if (((float)arg_70h != 3.402823e+38) && (fVar23 != (float)(int32_t)(float)arg_70h)) {
        *(float *)(unaff_RDI + 0x60) = (float)(int32_t)(float)arg_70h;
    }
    if ((arg_70h._4_4_ != 3.402823e+38) && (*(float *)(unaff_RDI + 100) != (float)(int32_t)arg_70h._4_4_)) {
        *(float *)(unaff_RDI + 100) = (float)(int32_t)arg_70h._4_4_;
    }
    if (((((fVar23 != *(float *)(unaff_RDI + 0x60)) || (fVar29 != *(float *)(unaff_RDI + 100))) || (fVar27 != fVar22))
        || (fVar31 != *(float *)(unaff_RDI + 0x74))) &&
       (((*(uint32_t *)(unaff_RDI + 0x14) & 0x100) == 0 && (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0)))) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
    }
    if (*unaff_RBX != 0xffffffff) {
        var_20h = (int64_t)*(uint32_t *)(iVar7 + 0x15d4);
        puVar11 = (undefined4 *)func_0x0001800ff770(unaff_RBP + -0x70, fVar22, *unaff_RBX, fVar20, var_20h);
        uVar9 = puVar11[1];
        uVar4 = puVar11[2];
        uVar5 = puVar11[3];
        *(undefined4 *)(iVar7 + 0x27ec) = *puVar11;
        *(undefined4 *)(iVar7 + 0x27f0) = uVar9;
        *(undefined4 *)(iVar7 + 0x27f4) = uVar4;
        *(undefined4 *)(iVar7 + 0x27f8) = uVar5;
    }
    return arg_48h._4_4_;
}

// ============================================================
// Function: FUN_18010073d
// Address: 0x18010073d
// Size: 15 bytes
// ============================================================
undefined8 fcn.18010073d(void)
{
    return 0;
}

// ============================================================
// Function: FUN_1801007f0
// Address: 0x1801007f0
// Size: 520 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_80h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch

void fcn.1801007f0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t unaff_RBP;
    undefined4 in_XMM3_Da;
    undefined4 unaff_XMM13_Dc;
    undefined4 unaff_XMM13_Dd;
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t iVar2;
    int64_t var_18h;
    
    iVar2 = CONCAT44(unaff_XMM13_Dd, unaff_XMM13_Dc);
    iVar1 = (int64_t)(int32_t)arg2 * 0x1c;
    fcn.1800ff770((uint64_t)var_88h._4_4_ << 0x20);
    fcn.180125bc0(CONCAT44(var_88h._4_4_, *(undefined4 *)(iVar1 + 0x180618488)), (uint64_t)var_80h._4_4_ << 0x20, iVar2
                  , unaff_RBP);
    fcn.180125bc0(CONCAT44(var_88h._4_4_, *(float *)(iVar1 + 0x180618488) + 0.7853982), (uint64_t)var_80h._4_4_ << 0x20
                  , iVar2, unaff_RBP);
    iVar2 = *(int64_t *)(arg1 + 800);
    fcn.1801248e0((uint64_t)var_88h._4_4_ << 0x20, CONCAT44(var_80h._4_4_, in_XMM3_Da));
    *(undefined4 *)(iVar2 + 0x50) = 0;
    return;
}

// ============================================================
// Function: FUN_180100a00
// Address: 0x180100a00
// Size: 34 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h

void fcn.180100a00(int64_t arg1)
{
    undefined4 *puVar1;
    int64_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    char cVar5;
    uint64_t arg3;
    char cVar6;
    float fVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    undefined4 uStack_40;
    int64_t var_3ch;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar2 = *(int64_t *)0x180781f28;
    fVar7 = *(float *)(arg1 + 0x9c);
    var_48h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf20);
    var_48h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf24);
    uStack_40 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf28);
    var_3ch._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xf2c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar3 = func_0x0001800f5fa0(&var_48h);
    arg3 = (uint64_t)uVar3;
    if (0.0 < fVar7) {
        if ((*(uint8_t *)(arg1 + 0x14) & 0x80) == 0) {
            var_8h._0_4_ = *(float *)(arg1 + 0x60) + *(float *)(arg1 + 0x68);
            var_8h._4_4_ = *(float *)(arg1 + 100) + *(float *)(arg1 + 0x6c);
            func_0x000180126460(*(undefined8 *)(arg1 + 800), arg1 + 0x60, &var_8h, uVar3, *(undefined4 *)(arg1 + 0x98));
        } else {
            if ((*(uint8_t *)(arg1 + 0x1c) & 4) != 0) {
                fcn.1801007f0(arg1, 1, arg3);
            }
            if ((*(uint8_t *)(arg1 + 0x1c) & 8) != 0) {
                fcn.1801007f0(arg1, 3, arg3);
            }
        }
    }
    cVar6 = *(char *)(arg1 + 0x115);
    if (cVar6 == -1) {
        if (*(char *)(arg1 + 0x116) == -1) goto code_r0x000180100b94;
        cVar5 = *(char *)(arg1 + 0x116);
code_r0x000180100b22:
        cVar6 = cVar5;
    } else {
        cVar5 = *(char *)(arg1 + 0x116);
        if (cVar5 != -1) goto code_r0x000180100b22;
    }
    iVar4 = 0x300;
    if (cVar5 != -1) {
        iVar4 = 0x310;
    }
    puVar1 = (undefined4 *)(iVar4 + 0xd90 + *(int64_t *)0x180781f28);
    var_48h._0_4_ = *puVar1;
    var_48h._4_4_ = puVar1[1];
    uStack_40 = puVar1[2];
    var_3ch._0_4_ = (float)puVar1[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar3 = func_0x0001800f5fa0(&var_48h);
    fcn.1801007f0(arg1, (uint64_t)(uint32_t)(int32_t)cVar6, (uint64_t)uVar3);
code_r0x000180100b94:
    if (((0.0 < *(float *)(iVar2 + 0xde8)) && ((*(uint8_t *)(arg1 + 0x14) & 1) == 0)) &&
       ((*(uint8_t *)(arg1 + 0x495) & 1) == 0)) {
        fVar7 = fVar7 * 0.5;
        var_10h._0_4_ = *(float *)(arg1 + 0x60) + fVar7;
        var_8h._0_4_ = (*(float *)(arg1 + 0x60) + *(float *)(arg1 + 0x68)) - fVar7;
        var_8h._4_4_ = (*(float *)(arg1 + 0xa0) + *(float *)(arg1 + 100)) - 1.0;
        var_10h._4_4_ = var_8h._4_4_;
        func_0x000180126300(*(undefined8 *)(arg1 + 800), &var_10h, &var_8h, arg3, *(float *)(iVar2 + 0xde8));
    }
    return;
}

// ============================================================
// Function: FUN_180100a22
// Address: 0x180100a22
// Size: 276 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h

void fcn.180100a00(int64_t arg1)
{
    undefined4 *puVar1;
    int64_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    char cVar5;
    uint64_t arg3;
    char cVar6;
    float fVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    undefined4 uStack_40;
    int64_t var_3ch;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar2 = *(int64_t *)0x180781f28;
    fVar7 = *(float *)(arg1 + 0x9c);
    var_48h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf20);
    var_48h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf24);
    uStack_40 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf28);
    var_3ch._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xf2c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar3 = func_0x0001800f5fa0(&var_48h);
    arg3 = (uint64_t)uVar3;
    if (0.0 < fVar7) {
        if ((*(uint8_t *)(arg1 + 0x14) & 0x80) == 0) {
            var_8h._0_4_ = *(float *)(arg1 + 0x60) + *(float *)(arg1 + 0x68);
            var_8h._4_4_ = *(float *)(arg1 + 100) + *(float *)(arg1 + 0x6c);
            func_0x000180126460(*(undefined8 *)(arg1 + 800), arg1 + 0x60, &var_8h, uVar3, *(undefined4 *)(arg1 + 0x98));
        } else {
            if ((*(uint8_t *)(arg1 + 0x1c) & 4) != 0) {
                fcn.1801007f0(arg1, 1, arg3);
            }
            if ((*(uint8_t *)(arg1 + 0x1c) & 8) != 0) {
                fcn.1801007f0(arg1, 3, arg3);
            }
        }
    }
    cVar6 = *(char *)(arg1 + 0x115);
    if (cVar6 == -1) {
        if (*(char *)(arg1 + 0x116) == -1) goto code_r0x000180100b94;
        cVar5 = *(char *)(arg1 + 0x116);
code_r0x000180100b22:
        cVar6 = cVar5;
    } else {
        cVar5 = *(char *)(arg1 + 0x116);
        if (cVar5 != -1) goto code_r0x000180100b22;
    }
    iVar4 = 0x300;
    if (cVar5 != -1) {
        iVar4 = 0x310;
    }
    puVar1 = (undefined4 *)(iVar4 + 0xd90 + *(int64_t *)0x180781f28);
    var_48h._0_4_ = *puVar1;
    var_48h._4_4_ = puVar1[1];
    uStack_40 = puVar1[2];
    var_3ch._0_4_ = (float)puVar1[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar3 = func_0x0001800f5fa0(&var_48h);
    fcn.1801007f0(arg1, (uint64_t)(uint32_t)(int32_t)cVar6, (uint64_t)uVar3);
code_r0x000180100b94:
    if (((0.0 < *(float *)(iVar2 + 0xde8)) && ((*(uint8_t *)(arg1 + 0x14) & 1) == 0)) &&
       ((*(uint8_t *)(arg1 + 0x495) & 1) == 0)) {
        fVar7 = fVar7 * 0.5;
        var_10h._0_4_ = *(float *)(arg1 + 0x60) + fVar7;
        var_8h._0_4_ = (*(float *)(arg1 + 0x60) + *(float *)(arg1 + 0x68)) - fVar7;
        var_8h._4_4_ = (*(float *)(arg1 + 0xa0) + *(float *)(arg1 + 100)) - 1.0;
        var_10h._4_4_ = var_8h._4_4_;
        func_0x000180126300(*(undefined8 *)(arg1 + 800), &var_10h, &var_8h, arg3, *(float *)(iVar2 + 0xde8));
    }
    return;
}

// ============================================================
// Function: FUN_180100b36
// Address: 0x180100b36
// Size: 94 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h

void fcn.180100a00(int64_t arg1)
{
    undefined4 *puVar1;
    int64_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    char cVar5;
    uint64_t arg3;
    char cVar6;
    float fVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    undefined4 uStack_40;
    int64_t var_3ch;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar2 = *(int64_t *)0x180781f28;
    fVar7 = *(float *)(arg1 + 0x9c);
    var_48h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf20);
    var_48h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf24);
    uStack_40 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf28);
    var_3ch._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xf2c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar3 = func_0x0001800f5fa0(&var_48h);
    arg3 = (uint64_t)uVar3;
    if (0.0 < fVar7) {
        if ((*(uint8_t *)(arg1 + 0x14) & 0x80) == 0) {
            var_8h._0_4_ = *(float *)(arg1 + 0x60) + *(float *)(arg1 + 0x68);
            var_8h._4_4_ = *(float *)(arg1 + 100) + *(float *)(arg1 + 0x6c);
            func_0x000180126460(*(undefined8 *)(arg1 + 800), arg1 + 0x60, &var_8h, uVar3, *(undefined4 *)(arg1 + 0x98));
        } else {
            if ((*(uint8_t *)(arg1 + 0x1c) & 4) != 0) {
                fcn.1801007f0(arg1, 1, arg3);
            }
            if ((*(uint8_t *)(arg1 + 0x1c) & 8) != 0) {
                fcn.1801007f0(arg1, 3, arg3);
            }
        }
    }
    cVar6 = *(char *)(arg1 + 0x115);
    if (cVar6 == -1) {
        if (*(char *)(arg1 + 0x116) == -1) goto code_r0x000180100b94;
        cVar5 = *(char *)(arg1 + 0x116);
code_r0x000180100b22:
        cVar6 = cVar5;
    } else {
        cVar5 = *(char *)(arg1 + 0x116);
        if (cVar5 != -1) goto code_r0x000180100b22;
    }
    iVar4 = 0x300;
    if (cVar5 != -1) {
        iVar4 = 0x310;
    }
    puVar1 = (undefined4 *)(iVar4 + 0xd90 + *(int64_t *)0x180781f28);
    var_48h._0_4_ = *puVar1;
    var_48h._4_4_ = puVar1[1];
    uStack_40 = puVar1[2];
    var_3ch._0_4_ = (float)puVar1[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar3 = func_0x0001800f5fa0(&var_48h);
    fcn.1801007f0(arg1, (uint64_t)(uint32_t)(int32_t)cVar6, (uint64_t)uVar3);
code_r0x000180100b94:
    if (((0.0 < *(float *)(iVar2 + 0xde8)) && ((*(uint8_t *)(arg1 + 0x14) & 1) == 0)) &&
       ((*(uint8_t *)(arg1 + 0x495) & 1) == 0)) {
        fVar7 = fVar7 * 0.5;
        var_10h._0_4_ = *(float *)(arg1 + 0x60) + fVar7;
        var_8h._0_4_ = (*(float *)(arg1 + 0x60) + *(float *)(arg1 + 0x68)) - fVar7;
        var_8h._4_4_ = (*(float *)(arg1 + 0xa0) + *(float *)(arg1 + 100)) - 1.0;
        var_10h._4_4_ = var_8h._4_4_;
        func_0x000180126300(*(undefined8 *)(arg1 + 800), &var_10h, &var_8h, arg3, *(float *)(iVar2 + 0xde8));
    }
    return;
}

// ============================================================
// Function: FUN_180100b94
// Address: 0x180100b94
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h

void fcn.180100a00(int64_t arg1)
{
    undefined4 *puVar1;
    int64_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    char cVar5;
    uint64_t arg3;
    char cVar6;
    float fVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    undefined4 uStack_40;
    int64_t var_3ch;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar2 = *(int64_t *)0x180781f28;
    fVar7 = *(float *)(arg1 + 0x9c);
    var_48h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf20);
    var_48h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf24);
    uStack_40 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf28);
    var_3ch._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xf2c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar3 = func_0x0001800f5fa0(&var_48h);
    arg3 = (uint64_t)uVar3;
    if (0.0 < fVar7) {
        if ((*(uint8_t *)(arg1 + 0x14) & 0x80) == 0) {
            var_8h._0_4_ = *(float *)(arg1 + 0x60) + *(float *)(arg1 + 0x68);
            var_8h._4_4_ = *(float *)(arg1 + 100) + *(float *)(arg1 + 0x6c);
            func_0x000180126460(*(undefined8 *)(arg1 + 800), arg1 + 0x60, &var_8h, uVar3, *(undefined4 *)(arg1 + 0x98));
        } else {
            if ((*(uint8_t *)(arg1 + 0x1c) & 4) != 0) {
                fcn.1801007f0(arg1, 1, arg3);
            }
            if ((*(uint8_t *)(arg1 + 0x1c) & 8) != 0) {
                fcn.1801007f0(arg1, 3, arg3);
            }
        }
    }
    cVar6 = *(char *)(arg1 + 0x115);
    if (cVar6 == -1) {
        if (*(char *)(arg1 + 0x116) == -1) goto code_r0x000180100b94;
        cVar5 = *(char *)(arg1 + 0x116);
code_r0x000180100b22:
        cVar6 = cVar5;
    } else {
        cVar5 = *(char *)(arg1 + 0x116);
        if (cVar5 != -1) goto code_r0x000180100b22;
    }
    iVar4 = 0x300;
    if (cVar5 != -1) {
        iVar4 = 0x310;
    }
    puVar1 = (undefined4 *)(iVar4 + 0xd90 + *(int64_t *)0x180781f28);
    var_48h._0_4_ = *puVar1;
    var_48h._4_4_ = puVar1[1];
    uStack_40 = puVar1[2];
    var_3ch._0_4_ = (float)puVar1[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar3 = func_0x0001800f5fa0(&var_48h);
    fcn.1801007f0(arg1, (uint64_t)(uint32_t)(int32_t)cVar6, (uint64_t)uVar3);
code_r0x000180100b94:
    if (((0.0 < *(float *)(iVar2 + 0xde8)) && ((*(uint8_t *)(arg1 + 0x14) & 1) == 0)) &&
       ((*(uint8_t *)(arg1 + 0x495) & 1) == 0)) {
        fVar7 = fVar7 * 0.5;
        var_10h._0_4_ = *(float *)(arg1 + 0x60) + fVar7;
        var_8h._0_4_ = (*(float *)(arg1 + 0x60) + *(float *)(arg1 + 0x68)) - fVar7;
        var_8h._4_4_ = (*(float *)(arg1 + 0xa0) + *(float *)(arg1 + 100)) - 1.0;
        var_10h._4_4_ = var_8h._4_4_;
        func_0x000180126300(*(undefined8 *)(arg1 + 800), &var_10h, &var_8h, arg3, *(float *)(iVar2 + 0xde8));
    }
    return;
}

// ============================================================
// Function: FUN_180100bb4
// Address: 0x180100bb4
// Size: 164 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h

void fcn.180100a00(int64_t arg1)
{
    undefined4 *puVar1;
    int64_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    char cVar5;
    uint64_t arg3;
    char cVar6;
    float fVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    undefined4 uStack_40;
    int64_t var_3ch;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar2 = *(int64_t *)0x180781f28;
    fVar7 = *(float *)(arg1 + 0x9c);
    var_48h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf20);
    var_48h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf24);
    uStack_40 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf28);
    var_3ch._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xf2c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar3 = func_0x0001800f5fa0(&var_48h);
    arg3 = (uint64_t)uVar3;
    if (0.0 < fVar7) {
        if ((*(uint8_t *)(arg1 + 0x14) & 0x80) == 0) {
            var_8h._0_4_ = *(float *)(arg1 + 0x60) + *(float *)(arg1 + 0x68);
            var_8h._4_4_ = *(float *)(arg1 + 100) + *(float *)(arg1 + 0x6c);
            func_0x000180126460(*(undefined8 *)(arg1 + 800), arg1 + 0x60, &var_8h, uVar3, *(undefined4 *)(arg1 + 0x98));
        } else {
            if ((*(uint8_t *)(arg1 + 0x1c) & 4) != 0) {
                fcn.1801007f0(arg1, 1, arg3);
            }
            if ((*(uint8_t *)(arg1 + 0x1c) & 8) != 0) {
                fcn.1801007f0(arg1, 3, arg3);
            }
        }
    }
    cVar6 = *(char *)(arg1 + 0x115);
    if (cVar6 == -1) {
        if (*(char *)(arg1 + 0x116) == -1) goto code_r0x000180100b94;
        cVar5 = *(char *)(arg1 + 0x116);
code_r0x000180100b22:
        cVar6 = cVar5;
    } else {
        cVar5 = *(char *)(arg1 + 0x116);
        if (cVar5 != -1) goto code_r0x000180100b22;
    }
    iVar4 = 0x300;
    if (cVar5 != -1) {
        iVar4 = 0x310;
    }
    puVar1 = (undefined4 *)(iVar4 + 0xd90 + *(int64_t *)0x180781f28);
    var_48h._0_4_ = *puVar1;
    var_48h._4_4_ = puVar1[1];
    uStack_40 = puVar1[2];
    var_3ch._0_4_ = (float)puVar1[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar3 = func_0x0001800f5fa0(&var_48h);
    fcn.1801007f0(arg1, (uint64_t)(uint32_t)(int32_t)cVar6, (uint64_t)uVar3);
code_r0x000180100b94:
    if (((0.0 < *(float *)(iVar2 + 0xde8)) && ((*(uint8_t *)(arg1 + 0x14) & 1) == 0)) &&
       ((*(uint8_t *)(arg1 + 0x495) & 1) == 0)) {
        fVar7 = fVar7 * 0.5;
        var_10h._0_4_ = *(float *)(arg1 + 0x60) + fVar7;
        var_8h._0_4_ = (*(float *)(arg1 + 0x60) + *(float *)(arg1 + 0x68)) - fVar7;
        var_8h._4_4_ = (*(float *)(arg1 + 0xa0) + *(float *)(arg1 + 100)) - 1.0;
        var_10h._4_4_ = var_8h._4_4_;
        func_0x000180126300(*(undefined8 *)(arg1 + 800), &var_10h, &var_8h, arg3, *(float *)(iVar2 + 0xde8));
    }
    return;
}

// ============================================================
// Function: FUN_180100c60
// Address: 0x180100c60
// Size: 263 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_138h
// WARNING: Variable defined which should be unmapped: var_130h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable arg_61h
// WARNING: [rz-ghidra] Detected overlap for variable arg_63h
// WARNING: [rz-ghidra] Detected overlap for variable arg_91h
// WARNING: [rz-ghidra] Detected overlap for variable var_ffh
// WARNING: [rz-ghidra] Detected overlap for variable arg_93h
// WARNING: [rz-ghidra] Detected overlap for variable var_fdh
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_fbh
// WARNING: [rz-ghidra] Detected overlap for variable var_f9h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e3h
// WARNING: [rz-ghidra] Detected overlap for variable var_e1h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e7h
// WARNING: [rz-ghidra] Detected overlap for variable var_e5h
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_10fh
// WARNING: [rz-ghidra] Detected overlap for variable var_10dh
// WARNING: [rz-ghidra] Detected overlap for variable var_10bh
// WARNING: [rz-ghidra] Detected overlap for variable var_109h
// WARNING: [rz-ghidra] Detected overlap for variable var_f3h
// WARNING: [rz-ghidra] Detected overlap for variable var_f1h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f7h
// WARNING: [rz-ghidra] Detected overlap for variable var_f5h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.180100c60(int64_t arg1, int64_t arg2, int64_t arg_60h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
                  int64_t arg_88h, int64_t arg_90h)
{
    int32_t *piVar1;
    uint8_t *puVar2;
    undefined4 *puVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    bool bVar9;
    char cVar10;
    uint8_t uVar11;
    uint32_t uVar12;
    undefined4 uVar13;
    uint32_t uVar14;
    int32_t iVar15;
    int64_t iVar16;
    float *pfVar17;
    int64_t *piVar18;
    uint32_t uVar19;
    int64_t iVar21;
    uint8_t in_R8B;
    int32_t iVar22;
    char in_R9B;
    int64_t iVar23;
    uint64_t uVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    undefined4 uStackX_8;
    float fStackX_c;
    int64_t var_10h;
    uint8_t uStackX_18;
    char cStackX_20;
    int32_t in_stack_00000028;
    int64_t in_stack_00000030;
    undefined uStack0000000000000038;
    undefined2 uStack0000000000000039;
    undefined uStack000000000000003b;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    float var_118h;
    float var_114h;
    float var_110h;
    int64_t var_10ch;
    float var_104h;
    int64_t var_100h;
    undefined var_f8h;
    undefined2 var_f7h;
    undefined var_f5h;
    undefined var_f4h;
    undefined2 var_f3h;
    undefined var_f1h;
    int64_t var_f0h;
    float var_e8h;
    int64_t var_e4h;
    float var_dch;
    uint32_t uStack_d8;
    uint32_t uStack_d4;
    int64_t var_b8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uVar20;
    
    iVar21 = *(int64_t *)0x180781f28;
    fVar4 = *(float *)(arg1 + 0x98);
    fVar5 = *(float *)(arg1 + 0x9c);
    *(undefined *)(arg1 + 0x10e) = 0;
    *(undefined4 *)(arg1 + 0x1b0) = 1;
    if (*(char *)(arg1 + 0x10c) != '\0') {
        uVar13 = *(undefined4 *)(iVar21 + 0xde8);
        *(float *)(iVar21 + 0xde8) = fVar5;
        if ((in_R8B == 0) || (iVar16 = 0x1f0, *(char *)(iVar21 + 0x21cc) == '\0')) {
            iVar16 = 0x200;
        }
        puVar3 = (undefined4 *)(iVar16 + 0xd90 + iVar21);
        var_120h._0_4_ = (float)*puVar3;
        var_120h._4_4_ = (float)puVar3[1];
        var_118h = (float)puVar3[2];
        var_114h = (float)puVar3[3] * *(float *)(iVar21 + 0xd9c);
        uVar12 = func_0x0001800f5fa0(&var_120h);
        uVar19 = uVar12 | 0xff000000;
        if (*(char *)(arg1 + 0x108) == '\0') {
            uVar19 = uVar12;
        }
        func_0x0001800f7a00(*(undefined8 *)arg2, *(undefined8 *)(arg2 + 8), uVar19, 1, fVar4);
        *(undefined4 *)(iVar21 + 0xde8) = uVar13;
        *(undefined4 *)(arg1 + 0x1b0) = 0;
        return;
    }
    uVar19 = *(uint32_t *)(arg1 + 0x14);
    uStackX_18 = in_R8B;
    cStackX_20 = in_R9B;
    if (-1 < (char)uVar19) {
        bVar9 = false;
        if ((((*(char *)(iVar21 + 0x2400) != '\0') && (*(int32_t *)(iVar21 + 4) - *(int32_t *)(iVar21 + 0x248c) < 2)) &&
            (*(char *)(iVar21 + 0x84) != '\0')) &&
           ((cVar10 = func_0x0001800f3aa0(iVar21 + 0x2410), cVar10 != '\0' &&
            (bVar9 = false, **(int64_t **)(iVar21 + 0x2410) == arg1)))) {
            bVar9 = true;
        }
        if ((uVar19 & 0x6000000) == 0) {
            if (((uVar19 >> 0x18 & 1) == 0) || (iVar16 = 0x170, (*(uint8_t *)(arg1 + 0x495) & 1) != 0)) {
                iVar16 = 0x160;
            }
        } else {
            iVar16 = 0x180;
        }
        pfVar17 = (float *)(iVar16 + 0xd90 + *(int64_t *)0x180781f28);
        var_120h._0_4_ = *pfVar17;
        var_120h._4_4_ = pfVar17[1];
        var_118h = pfVar17[2];
        var_114h = pfVar17[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar12 = func_0x0001800f5fa0(&var_120h);
        if (*(char *)(arg1 + 0x108) == '\0') {
            uVar14 = *(uint32_t *)(iVar21 + 0x2008) & 0x40;
            if (uVar14 == 0) {
                fVar25 = 1.0;
            } else {
                fVar25 = *(float *)(iVar21 + 0x2070);
            }
            if (bVar9) {
                fVar25 = fVar25 * 0.5;
            } else if (uVar14 == 0) goto code_r0x000180100ed9;
            if (0.0 <= fVar25) {
                fVar26 = 1.0;
                if (fVar25 <= 1.0) {
                    fVar26 = fVar25;
                }
            } else {
                fVar26 = 0.0;
            }
            uVar12 = (int32_t)(fVar26 * 255.0 + 0.5) << 0x18 | uVar12 & 0xffffff;
        } else {
            uVar12 = uVar12 | 0xff000000;
            if (bVar9) {
                *(float *)(*(int64_t *)(arg1 + 0x48) + 0xa0) = *(float *)(*(int64_t *)(arg1 + 0x48) + 0xa0) * 0.5;
            }
        }
code_r0x000180100ed9:
        if ((*(uint8_t *)(arg1 + 0x495) & 1) != 0) {
            *(uint32_t *)(*(int64_t *)(arg1 + 0x4c0) + 0x90) = uVar12;
        }
        if (((uVar19 >> 0x17 & 1) == 0) && ((uVar12 & 0xff000000) != 0)) {
            var_120h._0_4_ = *(float *)(arg1 + 0x60) + 0.0;
            var_118h = *(float *)(arg1 + 0x60) + *(float *)(arg1 + 0x68);
            var_120h._4_4_ = *(float *)(arg1 + 100) + *(float *)(arg1 + 0xa0);
            var_114h = *(float *)(arg1 + 100) + *(float *)(arg1 + 0x6c);
            if ((*(uint8_t *)(arg1 + 0x495) & 1) == 0) {
                iVar16 = *(int64_t *)(arg1 + 800);
                uVar13 = 0xc0;
                if ((uVar19 & 1) != 0) {
                    uVar13 = 0xf0;
                }
                iVar23 = iVar16 + 0x88;
            } else {
                iVar16 = *(int64_t *)(*(int64_t *)(arg1 + 0x4c0) + 0x98);
                var_110h = *(float *)(iVar16 + 0x60);
                var_10ch._0_4_ = *(float *)(iVar16 + 100);
                var_10ch._4_4_ = var_110h + *(float *)(iVar16 + 0x68);
                var_104h = (float)var_10ch + *(float *)(iVar16 + 0x6c);
                iVar16 = *(int64_t *)(iVar16 + 800);
                iVar23 = iVar16 + 0x88;
                func_0x000180127010(iVar23, iVar16, 0);
                uVar13 = func_0x000180130fb0(&var_120h, &var_110h);
            }
            func_0x000180126550(iVar16, &var_120h, &var_118h, uVar12, fVar4, uVar13);
            if ((*(uint8_t *)(arg1 + 0x495) & 1) != 0) {
                func_0x000180127010(iVar23, iVar16, 1);
            }
        }
    }
    uVar11 = *(uint8_t *)(arg1 + 0x495);
    if ((uVar11 & 1) != 0) {
        puVar2 = (uint8_t *)(*(int64_t *)(arg1 + 0x4c0) + 0xdc);
        *puVar2 = *puVar2 | 4;
        uVar11 = *(uint8_t *)(arg1 + 0x495);
    }
    if (((uVar19 & 1) == 0) && ((uVar11 & 1) == 0)) {
        pfVar17 = (float *)(*(int64_t *)0x180781f28 + 0xd90 + ((uint64_t)uStackX_18 + 0x1e) * 0x10);
        var_120h._0_4_ = *pfVar17;
        var_120h._4_4_ = pfVar17[1];
        var_118h = pfVar17[2];
        var_114h = pfVar17[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar14 = func_0x0001800f5fa0(&var_120h);
        uVar12 = uVar14 | 0xff000000;
        if (*(char *)(arg1 + 0x108) == '\0') {
            uVar12 = uVar14;
        }
        func_0x000180126550(*(undefined8 *)(arg1 + 800), arg2, arg2 + 8, uVar12, fVar4, 0x30);
    }
    if ((uVar19 >> 10 & 1) != 0) {
        fVar25 = *(float *)(arg1 + 0x60);
        fVar26 = *(float *)(arg1 + 100);
        fVar28 = fVar26 + *(float *)(arg1 + 0xa0);
        fVar29 = fVar25 + *(float *)(arg1 + 0x70);
        fVar27 = fVar25 + *(float *)(arg1 + 0x68);
        var_120h._4_4_ = fVar28;
        if (fVar28 <= fVar26) {
            var_120h._4_4_ = fVar26;
        }
        if (fVar27 <= fVar29) {
            fVar29 = fVar27;
        }
        fVar26 = fVar26 + *(float *)(arg1 + 0x6c);
        fVar28 = fVar28 + *(float *)(arg1 + 0xa4);
        if (fVar26 <= fVar28) {
            fVar28 = fVar26;
        }
        fVar26 = fVar4;
        if ((uVar19 & 1) == 0) {
            fVar26 = 0.0;
        }
        var_110h = *(float *)(*(int64_t *)0x180781f28 + 4000);
        var_10ch._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xfa4);
        var_10ch._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xfa8);
        var_104h = *(float *)(*(int64_t *)0x180781f28 + 0xfac) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        var_120h._0_4_ = fVar25;
        var_118h = fVar29;
        var_114h = fVar28;
        uVar13 = func_0x0001800f5fa0(&var_110h);
        func_0x000180126550(*(undefined8 *)(arg1 + 800), &var_120h, &var_118h, uVar13, fVar26, 0x30);
        fVar26 = *(float *)(iVar21 + 0xde8);
        if ((0.0 < fVar26) && (fVar28 < *(float *)(arg1 + 0x6c) + *(float *)(arg1 + 100))) {
            var_110h = *(float *)(*(int64_t *)0x180781f28 + 0xf20);
            var_10ch._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xf24);
            var_10ch._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xf28);
            uStackX_8 = fVar29 - fVar5 * 0.5;
            var_120h._0_4_ = fVar5 * 0.5 + fVar25;
            var_104h = *(float *)(*(int64_t *)0x180781f28 + 0xf2c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            fStackX_c = fVar28 - 0.0;
            var_120h._4_4_ = fVar28 + 0.0;
            uVar13 = func_0x0001800f5fa0(&var_110h);
            func_0x000180126300(*(undefined8 *)(arg1 + 800), &var_120h, &uStackX_8, uVar13, fVar26);
        }
    }
    uVar20 = 0;
    if ((*(uint8_t *)(arg1 + 0x495) & 1) == 0) goto code_r0x0001801014aa;
    iVar16 = *(int64_t *)(arg1 + 0x4c0);
    if (((*(uint32_t *)(iVar16 + 0x10) >> 0xd & 1) == 0) || ((*(uint32_t *)(iVar16 + 0x10) >> 0xc & 1) != 0))
    goto code_r0x0001801014aa;
    fVar25 = *(float *)(iVar16 + 0x48);
    fVar26 = *(float *)(iVar16 + 0x4c);
    fVar28 = (float)(int32_t)(*(float *)(iVar21 + 0x12f8) * 0.7);
    var_dch = (float)(int32_t)(*(float *)(iVar21 + 0x12f8) * 0.55);
    var_e4h._4_4_ = fVar25 + var_dch;
    var_dch = fVar26 + var_dch;
    var_e8h = fVar25;
    var_e4h._0_4_ = fVar26;
    iVar15 = func_0x0001800f5a90(0x180644598, 0, 
                                 *(undefined4 *)
                                  (*(int64_t *)(arg1 + 0x150) + -4 + (int64_t)*(int32_t *)(arg1 + 0x148) * 4));
    iVar21 = *(int64_t *)0x180781f28;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == iVar15) {
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = iVar15;
    }
    if (*(int32_t *)(iVar21 + 0x1684) == iVar15) {
        *(undefined *)(iVar21 + 0x168d) = 1;
    }
    cVar10 = func_0x000180139d40(&var_e8h, iVar15, &uStackX_8, &var_128h, 0x800);
    if (cVar10 == '\0') {
        if ((char)var_128h != '\0') {
            if ((*(char *)(*(int64_t *)0x180781f28 + 0x120) != '\0') &&
               (*(float *)(*(int64_t *)0x180781f28 + 0xa4) * *(float *)(*(int64_t *)0x180781f28 + 0xa4) <=
                *(float *)(*(int64_t *)0x180781f28 + 0xbfc))) {
                func_0x0001800faaf0(arg1, iVar16, 1);
            }
            goto code_r0x000180101384;
        }
code_r0x000180101399:
        if (((*(uint8_t *)(iVar16 + 0xdc) & 2) != 0) && ((char)uStackX_8 == '\0')) goto code_r0x0001801013a6;
        iVar21 = (uint64_t)((char)uStackX_8 != '\0') + 0x15;
    } else {
        *(uint8_t *)(iVar16 + 0xdd) = *(uint8_t *)(iVar16 + 0xdd) | 4;
code_r0x000180101384:
        if (((char)var_128h == '\0') || ((char)uStackX_8 == '\0')) goto code_r0x000180101399;
code_r0x0001801013a6:
        iVar21 = 0x17;
    }
    puVar3 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar21 + 0x14) * 0x10);
    var_120h._0_4_ = (float)*puVar3;
    var_120h._4_4_ = (float)puVar3[1];
    var_118h = (float)puVar3[2];
    var_114h = (float)puVar3[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar12 = func_0x0001800f5fa0(&var_120h);
    var_110h = fVar25 + 0.0;
    var_120h._0_4_ = fVar25 + fVar28;
    var_10ch._0_4_ = fVar26 + fVar28;
    var_120h._4_4_ = fVar26 + 0.0;
    if ((uVar12 & 0xff000000) != 0) {
        iVar21 = *(int64_t *)(arg1 + 800);
        iVar15 = *(int32_t *)(iVar21 + 0x54);
        if (*(int32_t *)(iVar21 + 0x50) == iVar15) {
            iVar22 = *(int32_t *)(iVar21 + 0x50) + 1;
            if (iVar15 == 0) {
                iVar15 = 8;
            } else {
                iVar15 = iVar15 / 2 + iVar15;
            }
            if (iVar22 < iVar15) {
                iVar22 = iVar15;
            }
            func_0x00018011f4f0(iVar21 + 0x50, iVar22);
        }
        iVar15 = *(int32_t *)(iVar21 + 0x50);
        iVar16 = *(int64_t *)(iVar21 + 0x58);
        *(float *)(iVar16 + (int64_t)iVar15 * 8) = fVar25;
        *(float *)(iVar16 + 4 + (int64_t)iVar15 * 8) = fVar26;
        *(int32_t *)(iVar21 + 0x50) = *(int32_t *)(iVar21 + 0x50) + 1;
        func_0x0001800f3b50(iVar21, &var_120h);
        func_0x0001800f3b50(iVar21, &var_110h);
        func_0x0001800f3bc0(iVar21, uVar12);
    }
code_r0x0001801014aa:
    if (*(char *)(arg1 + 0x104) != '\0') {
        func_0x00018013b430(0);
    }
    if (*(char *)(arg1 + 0x105) != '\0') {
        func_0x00018013b430(1);
    }
    fVar25 = _uStack0000000000000038;
    if (cStackX_20 != '\0') {
        if (((uVar19 & 2) == 0) && (var_f0h._0_4_ = 0, uVar24 = uVar20, 0 < in_stack_00000028)) {
            do {
                uStack_d4 = *(uint32_t *)(in_stack_00000030 + uVar24 * 4);
                uVar19 = (uint32_t)uVar20;
                if ((uStack_d4 & 0xff000000) != 0) {
                    fVar26 = *(float *)(arg1 + 0x60);
                    fVar28 = *(float *)(arg1 + 100);
                    iVar21 = *(int64_t *)(arg1 + 800);
                    uStack_d8 = (uint32_t)uVar20 & 1;
                    fVar26 = ((fVar26 + *(float *)(arg1 + 0x68)) - fVar26) * *(float *)(uVar24 * 0x18 + 0x1806185c0) +
                             fVar26;
                    fVar28 = ((fVar28 + *(float *)(arg1 + 0x6c)) - fVar28) * *(float *)(uVar24 * 0x18 + 0x1806185c4) +
                             fVar28;
                    fVar29 = (float)(int32_t)(fVar5 * 0.5 + 0.5);
                    uStackX_8._0_1_ = SUB41(fVar29, 0);
                    uStackX_8._1_2_ = (undefined2)((uint32_t)fVar29 >> 8);
                    uStackX_8._3_1_ = (undefined)((uint32_t)fVar29 >> 0x18);
                    if ((uVar20 & 1) == 0) {
                        var_100h._0_1_ = uStack0000000000000038;
                        var_100h._1_2_ = uStack0000000000000039;
                        var_100h._3_1_ = uStack000000000000003b;
                        var_100h._4_1_ = (char)uStackX_8;
                        var_100h._5_2_ = uStackX_8._1_2_;
                        var_100h._7_1_ = uStackX_8._3_1_;
                        fVar27 = fVar25;
                    } else {
                        var_f4h = uStack0000000000000038;
                        var_f3h = uStack0000000000000039;
                        var_f1h = uStack000000000000003b;
                        var_f8h = (char)uStackX_8;
                        var_f7h = uStackX_8._1_2_;
                        var_f5h = uStackX_8._3_1_;
                        fVar27 = fVar29;
                    }
                    fVar6 = *(float *)(uVar24 * 0x18 + 0x1806185c8);
                    piVar1 = (int32_t *)(iVar21 + 0x50);
                    iVar15 = *(int32_t *)(iVar21 + 0x54);
                    pfVar17 = (float *)((int64_t)&var_100h + 4);
                    if ((uVar20 & 1) != 0) {
                        pfVar17 = (float *)&var_f4h;
                    }
                    fVar7 = *pfVar17;
                    fVar8 = *(float *)(uVar24 * 0x18 + 0x1806185cc);
                    uStackX_8 = fVar29;
                    if (*piVar1 == iVar15) {
                        iVar22 = *piVar1 + 1;
                        if (iVar15 == 0) {
                            iVar15 = 8;
                        } else {
                            iVar15 = iVar15 / 2 + iVar15;
                        }
                        if (iVar22 < iVar15) {
                            iVar22 = iVar15;
                        }
                        func_0x00018011f4f0(piVar1, iVar22);
                    }
                    iVar15 = *piVar1;
                    iVar21 = *(int64_t *)(iVar21 + 0x58);
                    *(float *)(iVar21 + (int64_t)iVar15 * 8) = fVar27 * fVar6 + fVar26;
                    *(float *)(iVar21 + 4 + (int64_t)iVar15 * 8) = fVar7 * fVar8 + fVar28;
                    *piVar1 = *piVar1 + 1;
                    iVar21 = *(int64_t *)(arg1 + 800);
                    if (uStack_d8 == 0) {
                        var_e4h._0_4_ = _uStack0000000000000038;
                        var_e8h = fVar29;
                        fVar27 = fVar29;
                    } else {
                        var_110h = _uStack0000000000000038;
                        var_10ch._0_4_ = fVar29;
                        fVar27 = fVar25;
                    }
                    fVar6 = *(float *)(uVar24 * 0x18 + 0x1806185c8);
                    piVar1 = (int32_t *)(iVar21 + 0x50);
                    iVar15 = *(int32_t *)(iVar21 + 0x54);
                    piVar18 = &var_e4h;
                    if (uStack_d8 != 0) {
                        piVar18 = &var_10ch;
                    }
                    fVar7 = *(float *)piVar18;
                    fVar8 = *(float *)(uVar24 * 0x18 + 0x1806185cc);
                    if (*piVar1 == iVar15) {
                        iVar22 = *piVar1 + 1;
                        if (iVar15 == 0) {
                            iVar15 = 8;
                        } else {
                            iVar15 = iVar15 / 2 + iVar15;
                        }
                        if (iVar22 < iVar15) {
                            iVar22 = iVar15;
                        }
                        func_0x00018011f4f0(piVar1, iVar22);
                    }
                    iVar15 = *piVar1;
                    iVar21 = *(int64_t *)(iVar21 + 0x58);
                    *(float *)(iVar21 + (int64_t)iVar15 * 8) = fVar27 * fVar6 + fVar26;
                    *(float *)(iVar21 + 4 + (int64_t)iVar15 * 8) = fVar7 * fVar8 + fVar28;
                    *piVar1 = *piVar1 + 1;
                    var_120h._0_4_ = (fVar29 + fVar4) * *(float *)(uVar24 * 0x18 + 0x1806185c8) + fVar26;
                    var_120h._4_4_ = (fVar29 + fVar4) * *(float *)(uVar24 * 0x18 + 0x1806185cc) + fVar28;
                    if (0.5 <= fVar4) {
                        func_0x0001801257a0(*(int64_t *)(arg1 + 800), &var_120h);
                    } else {
                        func_0x00018011f490(*(int64_t *)(arg1 + 800) + 0x50);
                    }
                    func_0x0001800f3bc0(*(undefined8 *)(arg1 + 800), uStack_d4);
                    uVar19 = (uint32_t)var_f0h;
                }
                var_f0h._0_4_ = uVar19 + 1;
                uVar20 = (uint64_t)(uint32_t)var_f0h;
                uVar24 = uVar24 + 1;
            } while ((int32_t)(uint32_t)var_f0h < in_stack_00000028);
        }
        if (*(int64_t *)(arg1 + 0x4c8) == 0) {
            fcn.180100a00(arg1);
        }
    }
    *(undefined4 *)(arg1 + 0x1b0) = 0;
    return;
}

// ============================================================
// Function: FUN_180100d67
// Address: 0x180100d67
// Size: 844 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_138h
// WARNING: Variable defined which should be unmapped: var_130h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable arg_61h
// WARNING: [rz-ghidra] Detected overlap for variable arg_63h
// WARNING: [rz-ghidra] Detected overlap for variable arg_91h
// WARNING: [rz-ghidra] Detected overlap for variable var_ffh
// WARNING: [rz-ghidra] Detected overlap for variable arg_93h
// WARNING: [rz-ghidra] Detected overlap for variable var_fdh
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_fbh
// WARNING: [rz-ghidra] Detected overlap for variable var_f9h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e3h
// WARNING: [rz-ghidra] Detected overlap for variable var_e1h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e7h
// WARNING: [rz-ghidra] Detected overlap for variable var_e5h
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_10fh
// WARNING: [rz-ghidra] Detected overlap for variable var_10dh
// WARNING: [rz-ghidra] Detected overlap for variable var_10bh
// WARNING: [rz-ghidra] Detected overlap for variable var_109h
// WARNING: [rz-ghidra] Detected overlap for variable var_f3h
// WARNING: [rz-ghidra] Detected overlap for variable var_f1h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f7h
// WARNING: [rz-ghidra] Detected overlap for variable var_f5h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.180100c60(int64_t arg1, int64_t arg2, int64_t arg_60h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
                  int64_t arg_88h, int64_t arg_90h)
{
    int32_t *piVar1;
    uint8_t *puVar2;
    undefined4 *puVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    bool bVar9;
    char cVar10;
    uint8_t uVar11;
    uint32_t uVar12;
    undefined4 uVar13;
    uint32_t uVar14;
    int32_t iVar15;
    int64_t iVar16;
    float *pfVar17;
    int64_t *piVar18;
    uint32_t uVar19;
    int64_t iVar21;
    uint8_t in_R8B;
    int32_t iVar22;
    char in_R9B;
    int64_t iVar23;
    uint64_t uVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    undefined4 uStackX_8;
    float fStackX_c;
    int64_t var_10h;
    uint8_t uStackX_18;
    char cStackX_20;
    int32_t in_stack_00000028;
    int64_t in_stack_00000030;
    undefined uStack0000000000000038;
    undefined2 uStack0000000000000039;
    undefined uStack000000000000003b;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    float var_118h;
    float var_114h;
    float var_110h;
    int64_t var_10ch;
    float var_104h;
    int64_t var_100h;
    undefined var_f8h;
    undefined2 var_f7h;
    undefined var_f5h;
    undefined var_f4h;
    undefined2 var_f3h;
    undefined var_f1h;
    int64_t var_f0h;
    float var_e8h;
    int64_t var_e4h;
    float var_dch;
    uint32_t uStack_d8;
    uint32_t uStack_d4;
    int64_t var_b8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uVar20;
    
    iVar21 = *(int64_t *)0x180781f28;
    fVar4 = *(float *)(arg1 + 0x98);
    fVar5 = *(float *)(arg1 + 0x9c);
    *(undefined *)(arg1 + 0x10e) = 0;
    *(undefined4 *)(arg1 + 0x1b0) = 1;
    if (*(char *)(arg1 + 0x10c) != '\0') {
        uVar13 = *(undefined4 *)(iVar21 + 0xde8);
        *(float *)(iVar21 + 0xde8) = fVar5;
        if ((in_R8B == 0) || (iVar16 = 0x1f0, *(char *)(iVar21 + 0x21cc) == '\0')) {
            iVar16 = 0x200;
        }
        puVar3 = (undefined4 *)(iVar16 + 0xd90 + iVar21);
        var_120h._0_4_ = (float)*puVar3;
        var_120h._4_4_ = (float)puVar3[1];
        var_118h = (float)puVar3[2];
        var_114h = (float)puVar3[3] * *(float *)(iVar21 + 0xd9c);
        uVar12 = func_0x0001800f5fa0(&var_120h);
        uVar19 = uVar12 | 0xff000000;
        if (*(char *)(arg1 + 0x108) == '\0') {
            uVar19 = uVar12;
        }
        func_0x0001800f7a00(*(undefined8 *)arg2, *(undefined8 *)(arg2 + 8), uVar19, 1, fVar4);
        *(undefined4 *)(iVar21 + 0xde8) = uVar13;
        *(undefined4 *)(arg1 + 0x1b0) = 0;
        return;
    }
    uVar19 = *(uint32_t *)(arg1 + 0x14);
    uStackX_18 = in_R8B;
    cStackX_20 = in_R9B;
    if (-1 < (char)uVar19) {
        bVar9 = false;
        if ((((*(char *)(iVar21 + 0x2400) != '\0') && (*(int32_t *)(iVar21 + 4) - *(int32_t *)(iVar21 + 0x248c) < 2)) &&
            (*(char *)(iVar21 + 0x84) != '\0')) &&
           ((cVar10 = func_0x0001800f3aa0(iVar21 + 0x2410), cVar10 != '\0' &&
            (bVar9 = false, **(int64_t **)(iVar21 + 0x2410) == arg1)))) {
            bVar9 = true;
        }
        if ((uVar19 & 0x6000000) == 0) {
            if (((uVar19 >> 0x18 & 1) == 0) || (iVar16 = 0x170, (*(uint8_t *)(arg1 + 0x495) & 1) != 0)) {
                iVar16 = 0x160;
            }
        } else {
            iVar16 = 0x180;
        }
        pfVar17 = (float *)(iVar16 + 0xd90 + *(int64_t *)0x180781f28);
        var_120h._0_4_ = *pfVar17;
        var_120h._4_4_ = pfVar17[1];
        var_118h = pfVar17[2];
        var_114h = pfVar17[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar12 = func_0x0001800f5fa0(&var_120h);
        if (*(char *)(arg1 + 0x108) == '\0') {
            uVar14 = *(uint32_t *)(iVar21 + 0x2008) & 0x40;
            if (uVar14 == 0) {
                fVar25 = 1.0;
            } else {
                fVar25 = *(float *)(iVar21 + 0x2070);
            }
            if (bVar9) {
                fVar25 = fVar25 * 0.5;
            } else if (uVar14 == 0) goto code_r0x000180100ed9;
            if (0.0 <= fVar25) {
                fVar26 = 1.0;
                if (fVar25 <= 1.0) {
                    fVar26 = fVar25;
                }
            } else {
                fVar26 = 0.0;
            }
            uVar12 = (int32_t)(fVar26 * 255.0 + 0.5) << 0x18 | uVar12 & 0xffffff;
        } else {
            uVar12 = uVar12 | 0xff000000;
            if (bVar9) {
                *(float *)(*(int64_t *)(arg1 + 0x48) + 0xa0) = *(float *)(*(int64_t *)(arg1 + 0x48) + 0xa0) * 0.5;
            }
        }
code_r0x000180100ed9:
        if ((*(uint8_t *)(arg1 + 0x495) & 1) != 0) {
            *(uint32_t *)(*(int64_t *)(arg1 + 0x4c0) + 0x90) = uVar12;
        }
        if (((uVar19 >> 0x17 & 1) == 0) && ((uVar12 & 0xff000000) != 0)) {
            var_120h._0_4_ = *(float *)(arg1 + 0x60) + 0.0;
            var_118h = *(float *)(arg1 + 0x60) + *(float *)(arg1 + 0x68);
            var_120h._4_4_ = *(float *)(arg1 + 100) + *(float *)(arg1 + 0xa0);
            var_114h = *(float *)(arg1 + 100) + *(float *)(arg1 + 0x6c);
            if ((*(uint8_t *)(arg1 + 0x495) & 1) == 0) {
                iVar16 = *(int64_t *)(arg1 + 800);
                uVar13 = 0xc0;
                if ((uVar19 & 1) != 0) {
                    uVar13 = 0xf0;
                }
                iVar23 = iVar16 + 0x88;
            } else {
                iVar16 = *(int64_t *)(*(int64_t *)(arg1 + 0x4c0) + 0x98);
                var_110h = *(float *)(iVar16 + 0x60);
                var_10ch._0_4_ = *(float *)(iVar16 + 100);
                var_10ch._4_4_ = var_110h + *(float *)(iVar16 + 0x68);
                var_104h = (float)var_10ch + *(float *)(iVar16 + 0x6c);
                iVar16 = *(int64_t *)(iVar16 + 800);
                iVar23 = iVar16 + 0x88;
                func_0x000180127010(iVar23, iVar16, 0);
                uVar13 = func_0x000180130fb0(&var_120h, &var_110h);
            }
            func_0x000180126550(iVar16, &var_120h, &var_118h, uVar12, fVar4, uVar13);
            if ((*(uint8_t *)(arg1 + 0x495) & 1) != 0) {
                func_0x000180127010(iVar23, iVar16, 1);
            }
        }
    }
    uVar11 = *(uint8_t *)(arg1 + 0x495);
    if ((uVar11 & 1) != 0) {
        puVar2 = (uint8_t *)(*(int64_t *)(arg1 + 0x4c0) + 0xdc);
        *puVar2 = *puVar2 | 4;
        uVar11 = *(uint8_t *)(arg1 + 0x495);
    }
    if (((uVar19 & 1) == 0) && ((uVar11 & 1) == 0)) {
        pfVar17 = (float *)(*(int64_t *)0x180781f28 + 0xd90 + ((uint64_t)uStackX_18 + 0x1e) * 0x10);
        var_120h._0_4_ = *pfVar17;
        var_120h._4_4_ = pfVar17[1];
        var_118h = pfVar17[2];
        var_114h = pfVar17[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar14 = func_0x0001800f5fa0(&var_120h);
        uVar12 = uVar14 | 0xff000000;
        if (*(char *)(arg1 + 0x108) == '\0') {
            uVar12 = uVar14;
        }
        func_0x000180126550(*(undefined8 *)(arg1 + 800), arg2, arg2 + 8, uVar12, fVar4, 0x30);
    }
    if ((uVar19 >> 10 & 1) != 0) {
        fVar25 = *(float *)(arg1 + 0x60);
        fVar26 = *(float *)(arg1 + 100);
        fVar28 = fVar26 + *(float *)(arg1 + 0xa0);
        fVar29 = fVar25 + *(float *)(arg1 + 0x70);
        fVar27 = fVar25 + *(float *)(arg1 + 0x68);
        var_120h._4_4_ = fVar28;
        if (fVar28 <= fVar26) {
            var_120h._4_4_ = fVar26;
        }
        if (fVar27 <= fVar29) {
            fVar29 = fVar27;
        }
        fVar26 = fVar26 + *(float *)(arg1 + 0x6c);
        fVar28 = fVar28 + *(float *)(arg1 + 0xa4);
        if (fVar26 <= fVar28) {
            fVar28 = fVar26;
        }
        fVar26 = fVar4;
        if ((uVar19 & 1) == 0) {
            fVar26 = 0.0;
        }
        var_110h = *(float *)(*(int64_t *)0x180781f28 + 4000);
        var_10ch._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xfa4);
        var_10ch._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xfa8);
        var_104h = *(float *)(*(int64_t *)0x180781f28 + 0xfac) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        var_120h._0_4_ = fVar25;
        var_118h = fVar29;
        var_114h = fVar28;
        uVar13 = func_0x0001800f5fa0(&var_110h);
        func_0x000180126550(*(undefined8 *)(arg1 + 800), &var_120h, &var_118h, uVar13, fVar26, 0x30);
        fVar26 = *(float *)(iVar21 + 0xde8);
        if ((0.0 < fVar26) && (fVar28 < *(float *)(arg1 + 0x6c) + *(float *)(arg1 + 100))) {
            var_110h = *(float *)(*(int64_t *)0x180781f28 + 0xf20);
            var_10ch._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xf24);
            var_10ch._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xf28);
            uStackX_8 = fVar29 - fVar5 * 0.5;
            var_120h._0_4_ = fVar5 * 0.5 + fVar25;
            var_104h = *(float *)(*(int64_t *)0x180781f28 + 0xf2c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            fStackX_c = fVar28 - 0.0;
            var_120h._4_4_ = fVar28 + 0.0;
            uVar13 = func_0x0001800f5fa0(&var_110h);
            func_0x000180126300(*(undefined8 *)(arg1 + 800), &var_120h, &uStackX_8, uVar13, fVar26);
        }
    }
    uVar20 = 0;
    if ((*(uint8_t *)(arg1 + 0x495) & 1) == 0) goto code_r0x0001801014aa;
    iVar16 = *(int64_t *)(arg1 + 0x4c0);
    if (((*(uint32_t *)(iVar16 + 0x10) >> 0xd & 1) == 0) || ((*(uint32_t *)(iVar16 + 0x10) >> 0xc & 1) != 0))
    goto code_r0x0001801014aa;
    fVar25 = *(float *)(iVar16 + 0x48);
    fVar26 = *(float *)(iVar16 + 0x4c);
    fVar28 = (float)(int32_t)(*(float *)(iVar21 + 0x12f8) * 0.7);
    var_dch = (float)(int32_t)(*(float *)(iVar21 + 0x12f8) * 0.55);
    var_e4h._4_4_ = fVar25 + var_dch;
    var_dch = fVar26 + var_dch;
    var_e8h = fVar25;
    var_e4h._0_4_ = fVar26;
    iVar15 = func_0x0001800f5a90(0x180644598, 0, 
                                 *(undefined4 *)
                                  (*(int64_t *)(arg1 + 0x150) + -4 + (int64_t)*(int32_t *)(arg1 + 0x148) * 4));
    iVar21 = *(int64_t *)0x180781f28;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == iVar15) {
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = iVar15;
    }
    if (*(int32_t *)(iVar21 + 0x1684) == iVar15) {
        *(undefined *)(iVar21 + 0x168d) = 1;
    }
    cVar10 = func_0x000180139d40(&var_e8h, iVar15, &uStackX_8, &var_128h, 0x800);
    if (cVar10 == '\0') {
        if ((char)var_128h != '\0') {
            if ((*(char *)(*(int64_t *)0x180781f28 + 0x120) != '\0') &&
               (*(float *)(*(int64_t *)0x180781f28 + 0xa4) * *(float *)(*(int64_t *)0x180781f28 + 0xa4) <=
                *(float *)(*(int64_t *)0x180781f28 + 0xbfc))) {
                func_0x0001800faaf0(arg1, iVar16, 1);
            }
            goto code_r0x000180101384;
        }
code_r0x000180101399:
        if (((*(uint8_t *)(iVar16 + 0xdc) & 2) != 0) && ((char)uStackX_8 == '\0')) goto code_r0x0001801013a6;
        iVar21 = (uint64_t)((char)uStackX_8 != '\0') + 0x15;
    } else {
        *(uint8_t *)(iVar16 + 0xdd) = *(uint8_t *)(iVar16 + 0xdd) | 4;
code_r0x000180101384:
        if (((char)var_128h == '\0') || ((char)uStackX_8 == '\0')) goto code_r0x000180101399;
code_r0x0001801013a6:
        iVar21 = 0x17;
    }
    puVar3 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar21 + 0x14) * 0x10);
    var_120h._0_4_ = (float)*puVar3;
    var_120h._4_4_ = (float)puVar3[1];
    var_118h = (float)puVar3[2];
    var_114h = (float)puVar3[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar12 = func_0x0001800f5fa0(&var_120h);
    var_110h = fVar25 + 0.0;
    var_120h._0_4_ = fVar25 + fVar28;
    var_10ch._0_4_ = fVar26 + fVar28;
    var_120h._4_4_ = fVar26 + 0.0;
    if ((uVar12 & 0xff000000) != 0) {
        iVar21 = *(int64_t *)(arg1 + 800);
        iVar15 = *(int32_t *)(iVar21 + 0x54);
        if (*(int32_t *)(iVar21 + 0x50) == iVar15) {
            iVar22 = *(int32_t *)(iVar21 + 0x50) + 1;
            if (iVar15 == 0) {
                iVar15 = 8;
            } else {
                iVar15 = iVar15 / 2 + iVar15;
            }
            if (iVar22 < iVar15) {
                iVar22 = iVar15;
            }
            func_0x00018011f4f0(iVar21 + 0x50, iVar22);
        }
        iVar15 = *(int32_t *)(iVar21 + 0x50);
        iVar16 = *(int64_t *)(iVar21 + 0x58);
        *(float *)(iVar16 + (int64_t)iVar15 * 8) = fVar25;
        *(float *)(iVar16 + 4 + (int64_t)iVar15 * 8) = fVar26;
        *(int32_t *)(iVar21 + 0x50) = *(int32_t *)(iVar21 + 0x50) + 1;
        func_0x0001800f3b50(iVar21, &var_120h);
        func_0x0001800f3b50(iVar21, &var_110h);
        func_0x0001800f3bc0(iVar21, uVar12);
    }
code_r0x0001801014aa:
    if (*(char *)(arg1 + 0x104) != '\0') {
        func_0x00018013b430(0);
    }
    if (*(char *)(arg1 + 0x105) != '\0') {
        func_0x00018013b430(1);
    }
    fVar25 = _uStack0000000000000038;
    if (cStackX_20 != '\0') {
        if (((uVar19 & 2) == 0) && (var_f0h._0_4_ = 0, uVar24 = uVar20, 0 < in_stack_00000028)) {
            do {
                uStack_d4 = *(uint32_t *)(in_stack_00000030 + uVar24 * 4);
                uVar19 = (uint32_t)uVar20;
                if ((uStack_d4 & 0xff000000) != 0) {
                    fVar26 = *(float *)(arg1 + 0x60);
                    fVar28 = *(float *)(arg1 + 100);
                    iVar21 = *(int64_t *)(arg1 + 800);
                    uStack_d8 = (uint32_t)uVar20 & 1;
                    fVar26 = ((fVar26 + *(float *)(arg1 + 0x68)) - fVar26) * *(float *)(uVar24 * 0x18 + 0x1806185c0) +
                             fVar26;
                    fVar28 = ((fVar28 + *(float *)(arg1 + 0x6c)) - fVar28) * *(float *)(uVar24 * 0x18 + 0x1806185c4) +
                             fVar28;
                    fVar29 = (float)(int32_t)(fVar5 * 0.5 + 0.5);
                    uStackX_8._0_1_ = SUB41(fVar29, 0);
                    uStackX_8._1_2_ = (undefined2)((uint32_t)fVar29 >> 8);
                    uStackX_8._3_1_ = (undefined)((uint32_t)fVar29 >> 0x18);
                    if ((uVar20 & 1) == 0) {
                        var_100h._0_1_ = uStack0000000000000038;
                        var_100h._1_2_ = uStack0000000000000039;
                        var_100h._3_1_ = uStack000000000000003b;
                        var_100h._4_1_ = (char)uStackX_8;
                        var_100h._5_2_ = uStackX_8._1_2_;
                        var_100h._7_1_ = uStackX_8._3_1_;
                        fVar27 = fVar25;
                    } else {
                        var_f4h = uStack0000000000000038;
                        var_f3h = uStack0000000000000039;
                        var_f1h = uStack000000000000003b;
                        var_f8h = (char)uStackX_8;
                        var_f7h = uStackX_8._1_2_;
                        var_f5h = uStackX_8._3_1_;
                        fVar27 = fVar29;
                    }
                    fVar6 = *(float *)(uVar24 * 0x18 + 0x1806185c8);
                    piVar1 = (int32_t *)(iVar21 + 0x50);
                    iVar15 = *(int32_t *)(iVar21 + 0x54);
                    pfVar17 = (float *)((int64_t)&var_100h + 4);
                    if ((uVar20 & 1) != 0) {
                        pfVar17 = (float *)&var_f4h;
                    }
                    fVar7 = *pfVar17;
                    fVar8 = *(float *)(uVar24 * 0x18 + 0x1806185cc);
                    uStackX_8 = fVar29;
                    if (*piVar1 == iVar15) {
                        iVar22 = *piVar1 + 1;
                        if (iVar15 == 0) {
                            iVar15 = 8;
                        } else {
                            iVar15 = iVar15 / 2 + iVar15;
                        }
                        if (iVar22 < iVar15) {
                            iVar22 = iVar15;
                        }
                        func_0x00018011f4f0(piVar1, iVar22);
                    }
                    iVar15 = *piVar1;
                    iVar21 = *(int64_t *)(iVar21 + 0x58);
                    *(float *)(iVar21 + (int64_t)iVar15 * 8) = fVar27 * fVar6 + fVar26;
                    *(float *)(iVar21 + 4 + (int64_t)iVar15 * 8) = fVar7 * fVar8 + fVar28;
                    *piVar1 = *piVar1 + 1;
                    iVar21 = *(int64_t *)(arg1 + 800);
                    if (uStack_d8 == 0) {
                        var_e4h._0_4_ = _uStack0000000000000038;
                        var_e8h = fVar29;
                        fVar27 = fVar29;
                    } else {
                        var_110h = _uStack0000000000000038;
                        var_10ch._0_4_ = fVar29;
                        fVar27 = fVar25;
                    }
                    fVar6 = *(float *)(uVar24 * 0x18 + 0x1806185c8);
                    piVar1 = (int32_t *)(iVar21 + 0x50);
                    iVar15 = *(int32_t *)(iVar21 + 0x54);
                    piVar18 = &var_e4h;
                    if (uStack_d8 != 0) {
                        piVar18 = &var_10ch;
                    }
                    fVar7 = *(float *)piVar18;
                    fVar8 = *(float *)(uVar24 * 0x18 + 0x1806185cc);
                    if (*piVar1 == iVar15) {
                        iVar22 = *piVar1 + 1;
                        if (iVar15 == 0) {
                            iVar15 = 8;
                        } else {
                            iVar15 = iVar15 / 2 + iVar15;
                        }
                        if (iVar22 < iVar15) {
                            iVar22 = iVar15;
                        }
                        func_0x00018011f4f0(piVar1, iVar22);
                    }
                    iVar15 = *piVar1;
                    iVar21 = *(int64_t *)(iVar21 + 0x58);
                    *(float *)(iVar21 + (int64_t)iVar15 * 8) = fVar27 * fVar6 + fVar26;
                    *(float *)(iVar21 + 4 + (int64_t)iVar15 * 8) = fVar7 * fVar8 + fVar28;
                    *piVar1 = *piVar1 + 1;
                    var_120h._0_4_ = (fVar29 + fVar4) * *(float *)(uVar24 * 0x18 + 0x1806185c8) + fVar26;
                    var_120h._4_4_ = (fVar29 + fVar4) * *(float *)(uVar24 * 0x18 + 0x1806185cc) + fVar28;
                    if (0.5 <= fVar4) {
                        func_0x0001801257a0(*(int64_t *)(arg1 + 800), &var_120h);
                    } else {
                        func_0x00018011f490(*(int64_t *)(arg1 + 800) + 0x50);
                    }
                    func_0x0001800f3bc0(*(undefined8 *)(arg1 + 800), uStack_d4);
                    uVar19 = (uint32_t)var_f0h;
                }
                var_f0h._0_4_ = uVar19 + 1;
                uVar20 = (uint64_t)(uint32_t)var_f0h;
                uVar24 = uVar24 + 1;
            } while ((int32_t)(uint32_t)var_f0h < in_stack_00000028);
        }
        if (*(int64_t *)(arg1 + 0x4c8) == 0) {
            fcn.180100a00(arg1);
        }
    }
    *(undefined4 *)(arg1 + 0x1b0) = 0;
    return;
}

// ============================================================
// Function: FUN_1801010b3
// Address: 0x1801010b3
// Size: 1089 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_138h
// WARNING: Variable defined which should be unmapped: var_130h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable arg_61h
// WARNING: [rz-ghidra] Detected overlap for variable arg_63h
// WARNING: [rz-ghidra] Detected overlap for variable arg_91h
// WARNING: [rz-ghidra] Detected overlap for variable var_ffh
// WARNING: [rz-ghidra] Detected overlap for variable arg_93h
// WARNING: [rz-ghidra] Detected overlap for variable var_fdh
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_fbh
// WARNING: [rz-ghidra] Detected overlap for variable var_f9h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e3h
// WARNING: [rz-ghidra] Detected overlap for variable var_e1h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e7h
// WARNING: [rz-ghidra] Detected overlap for variable var_e5h
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_10fh
// WARNING: [rz-ghidra] Detected overlap for variable var_10dh
// WARNING: [rz-ghidra] Detected overlap for variable var_10bh
// WARNING: [rz-ghidra] Detected overlap for variable var_109h
// WARNING: [rz-ghidra] Detected overlap for variable var_f3h
// WARNING: [rz-ghidra] Detected overlap for variable var_f1h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f7h
// WARNING: [rz-ghidra] Detected overlap for variable var_f5h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.180100c60(int64_t arg1, int64_t arg2, int64_t arg_60h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
                  int64_t arg_88h, int64_t arg_90h)
{
    int32_t *piVar1;
    uint8_t *puVar2;
    undefined4 *puVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    bool bVar9;
    char cVar10;
    uint8_t uVar11;
    uint32_t uVar12;
    undefined4 uVar13;
    uint32_t uVar14;
    int32_t iVar15;
    int64_t iVar16;
    float *pfVar17;
    int64_t *piVar18;
    uint32_t uVar19;
    int64_t iVar21;
    uint8_t in_R8B;
    int32_t iVar22;
    char in_R9B;
    int64_t iVar23;
    uint64_t uVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    undefined4 uStackX_8;
    float fStackX_c;
    int64_t var_10h;
    uint8_t uStackX_18;
    char cStackX_20;
    int32_t in_stack_00000028;
    int64_t in_stack_00000030;
    undefined uStack0000000000000038;
    undefined2 uStack0000000000000039;
    undefined uStack000000000000003b;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    float var_118h;
    float var_114h;
    float var_110h;
    int64_t var_10ch;
    float var_104h;
    int64_t var_100h;
    undefined var_f8h;
    undefined2 var_f7h;
    undefined var_f5h;
    undefined var_f4h;
    undefined2 var_f3h;
    undefined var_f1h;
    int64_t var_f0h;
    float var_e8h;
    int64_t var_e4h;
    float var_dch;
    uint32_t uStack_d8;
    uint32_t uStack_d4;
    int64_t var_b8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uVar20;
    
    iVar21 = *(int64_t *)0x180781f28;
    fVar4 = *(float *)(arg1 + 0x98);
    fVar5 = *(float *)(arg1 + 0x9c);
    *(undefined *)(arg1 + 0x10e) = 0;
    *(undefined4 *)(arg1 + 0x1b0) = 1;
    if (*(char *)(arg1 + 0x10c) != '\0') {
        uVar13 = *(undefined4 *)(iVar21 + 0xde8);
        *(float *)(iVar21 + 0xde8) = fVar5;
        if ((in_R8B == 0) || (iVar16 = 0x1f0, *(char *)(iVar21 + 0x21cc) == '\0')) {
            iVar16 = 0x200;
        }
        puVar3 = (undefined4 *)(iVar16 + 0xd90 + iVar21);
        var_120h._0_4_ = (float)*puVar3;
        var_120h._4_4_ = (float)puVar3[1];
        var_118h = (float)puVar3[2];
        var_114h = (float)puVar3[3] * *(float *)(iVar21 + 0xd9c);
        uVar12 = func_0x0001800f5fa0(&var_120h);
        uVar19 = uVar12 | 0xff000000;
        if (*(char *)(arg1 + 0x108) == '\0') {
            uVar19 = uVar12;
        }
        func_0x0001800f7a00(*(undefined8 *)arg2, *(undefined8 *)(arg2 + 8), uVar19, 1, fVar4);
        *(undefined4 *)(iVar21 + 0xde8) = uVar13;
        *(undefined4 *)(arg1 + 0x1b0) = 0;
        return;
    }
    uVar19 = *(uint32_t *)(arg1 + 0x14);
    uStackX_18 = in_R8B;
    cStackX_20 = in_R9B;
    if (-1 < (char)uVar19) {
        bVar9 = false;
        if ((((*(char *)(iVar21 + 0x2400) != '\0') && (*(int32_t *)(iVar21 + 4) - *(int32_t *)(iVar21 + 0x248c) < 2)) &&
            (*(char *)(iVar21 + 0x84) != '\0')) &&
           ((cVar10 = func_0x0001800f3aa0(iVar21 + 0x2410), cVar10 != '\0' &&
            (bVar9 = false, **(int64_t **)(iVar21 + 0x2410) == arg1)))) {
            bVar9 = true;
        }
        if ((uVar19 & 0x6000000) == 0) {
            if (((uVar19 >> 0x18 & 1) == 0) || (iVar16 = 0x170, (*(uint8_t *)(arg1 + 0x495) & 1) != 0)) {
                iVar16 = 0x160;
            }
        } else {
            iVar16 = 0x180;
        }
        pfVar17 = (float *)(iVar16 + 0xd90 + *(int64_t *)0x180781f28);
        var_120h._0_4_ = *pfVar17;
        var_120h._4_4_ = pfVar17[1];
        var_118h = pfVar17[2];
        var_114h = pfVar17[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar12 = func_0x0001800f5fa0(&var_120h);
        if (*(char *)(arg1 + 0x108) == '\0') {
            uVar14 = *(uint32_t *)(iVar21 + 0x2008) & 0x40;
            if (uVar14 == 0) {
                fVar25 = 1.0;
            } else {
                fVar25 = *(float *)(iVar21 + 0x2070);
            }
            if (bVar9) {
                fVar25 = fVar25 * 0.5;
            } else if (uVar14 == 0) goto code_r0x000180100ed9;
            if (0.0 <= fVar25) {
                fVar26 = 1.0;
                if (fVar25 <= 1.0) {
                    fVar26 = fVar25;
                }
            } else {
                fVar26 = 0.0;
            }
            uVar12 = (int32_t)(fVar26 * 255.0 + 0.5) << 0x18 | uVar12 & 0xffffff;
        } else {
            uVar12 = uVar12 | 0xff000000;
            if (bVar9) {
                *(float *)(*(int64_t *)(arg1 + 0x48) + 0xa0) = *(float *)(*(int64_t *)(arg1 + 0x48) + 0xa0) * 0.5;
            }
        }
code_r0x000180100ed9:
        if ((*(uint8_t *)(arg1 + 0x495) & 1) != 0) {
            *(uint32_t *)(*(int64_t *)(arg1 + 0x4c0) + 0x90) = uVar12;
        }
        if (((uVar19 >> 0x17 & 1) == 0) && ((uVar12 & 0xff000000) != 0)) {
            var_120h._0_4_ = *(float *)(arg1 + 0x60) + 0.0;
            var_118h = *(float *)(arg1 + 0x60) + *(float *)(arg1 + 0x68);
            var_120h._4_4_ = *(float *)(arg1 + 100) + *(float *)(arg1 + 0xa0);
            var_114h = *(float *)(arg1 + 100) + *(float *)(arg1 + 0x6c);
            if ((*(uint8_t *)(arg1 + 0x495) & 1) == 0) {
                iVar16 = *(int64_t *)(arg1 + 800);
                uVar13 = 0xc0;
                if ((uVar19 & 1) != 0) {
                    uVar13 = 0xf0;
                }
                iVar23 = iVar16 + 0x88;
            } else {
                iVar16 = *(int64_t *)(*(int64_t *)(arg1 + 0x4c0) + 0x98);
                var_110h = *(float *)(iVar16 + 0x60);
                var_10ch._0_4_ = *(float *)(iVar16 + 100);
                var_10ch._4_4_ = var_110h + *(float *)(iVar16 + 0x68);
                var_104h = (float)var_10ch + *(float *)(iVar16 + 0x6c);
                iVar16 = *(int64_t *)(iVar16 + 800);
                iVar23 = iVar16 + 0x88;
                func_0x000180127010(iVar23, iVar16, 0);
                uVar13 = func_0x000180130fb0(&var_120h, &var_110h);
            }
            func_0x000180126550(iVar16, &var_120h, &var_118h, uVar12, fVar4, uVar13);
            if ((*(uint8_t *)(arg1 + 0x495) & 1) != 0) {
                func_0x000180127010(iVar23, iVar16, 1);
            }
        }
    }
    uVar11 = *(uint8_t *)(arg1 + 0x495);
    if ((uVar11 & 1) != 0) {
        puVar2 = (uint8_t *)(*(int64_t *)(arg1 + 0x4c0) + 0xdc);
        *puVar2 = *puVar2 | 4;
        uVar11 = *(uint8_t *)(arg1 + 0x495);
    }
    if (((uVar19 & 1) == 0) && ((uVar11 & 1) == 0)) {
        pfVar17 = (float *)(*(int64_t *)0x180781f28 + 0xd90 + ((uint64_t)uStackX_18 + 0x1e) * 0x10);
        var_120h._0_4_ = *pfVar17;
        var_120h._4_4_ = pfVar17[1];
        var_118h = pfVar17[2];
        var_114h = pfVar17[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar14 = func_0x0001800f5fa0(&var_120h);
        uVar12 = uVar14 | 0xff000000;
        if (*(char *)(arg1 + 0x108) == '\0') {
            uVar12 = uVar14;
        }
        func_0x000180126550(*(undefined8 *)(arg1 + 800), arg2, arg2 + 8, uVar12, fVar4, 0x30);
    }
    if ((uVar19 >> 10 & 1) != 0) {
        fVar25 = *(float *)(arg1 + 0x60);
        fVar26 = *(float *)(arg1 + 100);
        fVar28 = fVar26 + *(float *)(arg1 + 0xa0);
        fVar29 = fVar25 + *(float *)(arg1 + 0x70);
        fVar27 = fVar25 + *(float *)(arg1 + 0x68);
        var_120h._4_4_ = fVar28;
        if (fVar28 <= fVar26) {
            var_120h._4_4_ = fVar26;
        }
        if (fVar27 <= fVar29) {
            fVar29 = fVar27;
        }
        fVar26 = fVar26 + *(float *)(arg1 + 0x6c);
        fVar28 = fVar28 + *(float *)(arg1 + 0xa4);
        if (fVar26 <= fVar28) {
            fVar28 = fVar26;
        }
        fVar26 = fVar4;
        if ((uVar19 & 1) == 0) {
            fVar26 = 0.0;
        }
        var_110h = *(float *)(*(int64_t *)0x180781f28 + 4000);
        var_10ch._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xfa4);
        var_10ch._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xfa8);
        var_104h = *(float *)(*(int64_t *)0x180781f28 + 0xfac) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        var_120h._0_4_ = fVar25;
        var_118h = fVar29;
        var_114h = fVar28;
        uVar13 = func_0x0001800f5fa0(&var_110h);
        func_0x000180126550(*(undefined8 *)(arg1 + 800), &var_120h, &var_118h, uVar13, fVar26, 0x30);
        fVar26 = *(float *)(iVar21 + 0xde8);
        if ((0.0 < fVar26) && (fVar28 < *(float *)(arg1 + 0x6c) + *(float *)(arg1 + 100))) {
            var_110h = *(float *)(*(int64_t *)0x180781f28 + 0xf20);
            var_10ch._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xf24);
            var_10ch._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xf28);
            uStackX_8 = fVar29 - fVar5 * 0.5;
            var_120h._0_4_ = fVar5 * 0.5 + fVar25;
            var_104h = *(float *)(*(int64_t *)0x180781f28 + 0xf2c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            fStackX_c = fVar28 - 0.0;
            var_120h._4_4_ = fVar28 + 0.0;
            uVar13 = func_0x0001800f5fa0(&var_110h);
            func_0x000180126300(*(undefined8 *)(arg1 + 800), &var_120h, &uStackX_8, uVar13, fVar26);
        }
    }
    uVar20 = 0;
    if ((*(uint8_t *)(arg1 + 0x495) & 1) == 0) goto code_r0x0001801014aa;
    iVar16 = *(int64_t *)(arg1 + 0x4c0);
    if (((*(uint32_t *)(iVar16 + 0x10) >> 0xd & 1) == 0) || ((*(uint32_t *)(iVar16 + 0x10) >> 0xc & 1) != 0))
    goto code_r0x0001801014aa;
    fVar25 = *(float *)(iVar16 + 0x48);
    fVar26 = *(float *)(iVar16 + 0x4c);
    fVar28 = (float)(int32_t)(*(float *)(iVar21 + 0x12f8) * 0.7);
    var_dch = (float)(int32_t)(*(float *)(iVar21 + 0x12f8) * 0.55);
    var_e4h._4_4_ = fVar25 + var_dch;
    var_dch = fVar26 + var_dch;
    var_e8h = fVar25;
    var_e4h._0_4_ = fVar26;
    iVar15 = func_0x0001800f5a90(0x180644598, 0, 
                                 *(undefined4 *)
                                  (*(int64_t *)(arg1 + 0x150) + -4 + (int64_t)*(int32_t *)(arg1 + 0x148) * 4));
    iVar21 = *(int64_t *)0x180781f28;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == iVar15) {
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = iVar15;
    }
    if (*(int32_t *)(iVar21 + 0x1684) == iVar15) {
        *(undefined *)(iVar21 + 0x168d) = 1;
    }
    cVar10 = func_0x000180139d40(&var_e8h, iVar15, &uStackX_8, &var_128h, 0x800);
    if (cVar10 == '\0') {
        if ((char)var_128h != '\0') {
            if ((*(char *)(*(int64_t *)0x180781f28 + 0x120) != '\0') &&
               (*(float *)(*(int64_t *)0x180781f28 + 0xa4) * *(float *)(*(int64_t *)0x180781f28 + 0xa4) <=
                *(float *)(*(int64_t *)0x180781f28 + 0xbfc))) {
                func_0x0001800faaf0(arg1, iVar16, 1);
            }
            goto code_r0x000180101384;
        }
code_r0x000180101399:
        if (((*(uint8_t *)(iVar16 + 0xdc) & 2) != 0) && ((char)uStackX_8 == '\0')) goto code_r0x0001801013a6;
        iVar21 = (uint64_t)((char)uStackX_8 != '\0') + 0x15;
    } else {
        *(uint8_t *)(iVar16 + 0xdd) = *(uint8_t *)(iVar16 + 0xdd) | 4;
code_r0x000180101384:
        if (((char)var_128h == '\0') || ((char)uStackX_8 == '\0')) goto code_r0x000180101399;
code_r0x0001801013a6:
        iVar21 = 0x17;
    }
    puVar3 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar21 + 0x14) * 0x10);
    var_120h._0_4_ = (float)*puVar3;
    var_120h._4_4_ = (float)puVar3[1];
    var_118h = (float)puVar3[2];
    var_114h = (float)puVar3[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar12 = func_0x0001800f5fa0(&var_120h);
    var_110h = fVar25 + 0.0;
    var_120h._0_4_ = fVar25 + fVar28;
    var_10ch._0_4_ = fVar26 + fVar28;
    var_120h._4_4_ = fVar26 + 0.0;
    if ((uVar12 & 0xff000000) != 0) {
        iVar21 = *(int64_t *)(arg1 + 800);
        iVar15 = *(int32_t *)(iVar21 + 0x54);
        if (*(int32_t *)(iVar21 + 0x50) == iVar15) {
            iVar22 = *(int32_t *)(iVar21 + 0x50) + 1;
            if (iVar15 == 0) {
                iVar15 = 8;
            } else {
                iVar15 = iVar15 / 2 + iVar15;
            }
            if (iVar22 < iVar15) {
                iVar22 = iVar15;
            }
            func_0x00018011f4f0(iVar21 + 0x50, iVar22);
        }
        iVar15 = *(int32_t *)(iVar21 + 0x50);
        iVar16 = *(int64_t *)(iVar21 + 0x58);
        *(float *)(iVar16 + (int64_t)iVar15 * 8) = fVar25;
        *(float *)(iVar16 + 4 + (int64_t)iVar15 * 8) = fVar26;
        *(int32_t *)(iVar21 + 0x50) = *(int32_t *)(iVar21 + 0x50) + 1;
        func_0x0001800f3b50(iVar21, &var_120h);
        func_0x0001800f3b50(iVar21, &var_110h);
        func_0x0001800f3bc0(iVar21, uVar12);
    }
code_r0x0001801014aa:
    if (*(char *)(arg1 + 0x104) != '\0') {
        func_0x00018013b430(0);
    }
    if (*(char *)(arg1 + 0x105) != '\0') {
        func_0x00018013b430(1);
    }
    fVar25 = _uStack0000000000000038;
    if (cStackX_20 != '\0') {
        if (((uVar19 & 2) == 0) && (var_f0h._0_4_ = 0, uVar24 = uVar20, 0 < in_stack_00000028)) {
            do {
                uStack_d4 = *(uint32_t *)(in_stack_00000030 + uVar24 * 4);
                uVar19 = (uint32_t)uVar20;
                if ((uStack_d4 & 0xff000000) != 0) {
                    fVar26 = *(float *)(arg1 + 0x60);
                    fVar28 = *(float *)(arg1 + 100);
                    iVar21 = *(int64_t *)(arg1 + 800);
                    uStack_d8 = (uint32_t)uVar20 & 1;
                    fVar26 = ((fVar26 + *(float *)(arg1 + 0x68)) - fVar26) * *(float *)(uVar24 * 0x18 + 0x1806185c0) +
                             fVar26;
                    fVar28 = ((fVar28 + *(float *)(arg1 + 0x6c)) - fVar28) * *(float *)(uVar24 * 0x18 + 0x1806185c4) +
                             fVar28;
                    fVar29 = (float)(int32_t)(fVar5 * 0.5 + 0.5);
                    uStackX_8._0_1_ = SUB41(fVar29, 0);
                    uStackX_8._1_2_ = (undefined2)((uint32_t)fVar29 >> 8);
                    uStackX_8._3_1_ = (undefined)((uint32_t)fVar29 >> 0x18);
                    if ((uVar20 & 1) == 0) {
                        var_100h._0_1_ = uStack0000000000000038;
                        var_100h._1_2_ = uStack0000000000000039;
                        var_100h._3_1_ = uStack000000000000003b;
                        var_100h._4_1_ = (char)uStackX_8;
                        var_100h._5_2_ = uStackX_8._1_2_;
                        var_100h._7_1_ = uStackX_8._3_1_;
                        fVar27 = fVar25;
                    } else {
                        var_f4h = uStack0000000000000038;
                        var_f3h = uStack0000000000000039;
                        var_f1h = uStack000000000000003b;
                        var_f8h = (char)uStackX_8;
                        var_f7h = uStackX_8._1_2_;
                        var_f5h = uStackX_8._3_1_;
                        fVar27 = fVar29;
                    }
                    fVar6 = *(float *)(uVar24 * 0x18 + 0x1806185c8);
                    piVar1 = (int32_t *)(iVar21 + 0x50);
                    iVar15 = *(int32_t *)(iVar21 + 0x54);
                    pfVar17 = (float *)((int64_t)&var_100h + 4);
                    if ((uVar20 & 1) != 0) {
                        pfVar17 = (float *)&var_f4h;
                    }
                    fVar7 = *pfVar17;
                    fVar8 = *(float *)(uVar24 * 0x18 + 0x1806185cc);
                    uStackX_8 = fVar29;
                    if (*piVar1 == iVar15) {
                        iVar22 = *piVar1 + 1;
                        if (iVar15 == 0) {
                            iVar15 = 8;
                        } else {
                            iVar15 = iVar15 / 2 + iVar15;
                        }
                        if (iVar22 < iVar15) {
                            iVar22 = iVar15;
                        }
                        func_0x00018011f4f0(piVar1, iVar22);
                    }
                    iVar15 = *piVar1;
                    iVar21 = *(int64_t *)(iVar21 + 0x58);
                    *(float *)(iVar21 + (int64_t)iVar15 * 8) = fVar27 * fVar6 + fVar26;
                    *(float *)(iVar21 + 4 + (int64_t)iVar15 * 8) = fVar7 * fVar8 + fVar28;
                    *piVar1 = *piVar1 + 1;
                    iVar21 = *(int64_t *)(arg1 + 800);
                    if (uStack_d8 == 0) {
                        var_e4h._0_4_ = _uStack0000000000000038;
                        var_e8h = fVar29;
                        fVar27 = fVar29;
                    } else {
                        var_110h = _uStack0000000000000038;
                        var_10ch._0_4_ = fVar29;
                        fVar27 = fVar25;
                    }
                    fVar6 = *(float *)(uVar24 * 0x18 + 0x1806185c8);
                    piVar1 = (int32_t *)(iVar21 + 0x50);
                    iVar15 = *(int32_t *)(iVar21 + 0x54);
                    piVar18 = &var_e4h;
                    if (uStack_d8 != 0) {
                        piVar18 = &var_10ch;
                    }
                    fVar7 = *(float *)piVar18;
                    fVar8 = *(float *)(uVar24 * 0x18 + 0x1806185cc);
                    if (*piVar1 == iVar15) {
                        iVar22 = *piVar1 + 1;
                        if (iVar15 == 0) {
                            iVar15 = 8;
                        } else {
                            iVar15 = iVar15 / 2 + iVar15;
                        }
                        if (iVar22 < iVar15) {
                            iVar22 = iVar15;
                        }
                        func_0x00018011f4f0(piVar1, iVar22);
                    }
                    iVar15 = *piVar1;
                    iVar21 = *(int64_t *)(iVar21 + 0x58);
                    *(float *)(iVar21 + (int64_t)iVar15 * 8) = fVar27 * fVar6 + fVar26;
                    *(float *)(iVar21 + 4 + (int64_t)iVar15 * 8) = fVar7 * fVar8 + fVar28;
                    *piVar1 = *piVar1 + 1;
                    var_120h._0_4_ = (fVar29 + fVar4) * *(float *)(uVar24 * 0x18 + 0x1806185c8) + fVar26;
                    var_120h._4_4_ = (fVar29 + fVar4) * *(float *)(uVar24 * 0x18 + 0x1806185cc) + fVar28;
                    if (0.5 <= fVar4) {
                        func_0x0001801257a0(*(int64_t *)(arg1 + 800), &var_120h);
                    } else {
                        func_0x00018011f490(*(int64_t *)(arg1 + 800) + 0x50);
                    }
                    func_0x0001800f3bc0(*(undefined8 *)(arg1 + 800), uStack_d4);
                    uVar19 = (uint32_t)var_f0h;
                }
                var_f0h._0_4_ = uVar19 + 1;
                uVar20 = (uint64_t)(uint32_t)var_f0h;
                uVar24 = uVar24 + 1;
            } while ((int32_t)(uint32_t)var_f0h < in_stack_00000028);
        }
        if (*(int64_t *)(arg1 + 0x4c8) == 0) {
            fcn.180100a00(arg1);
        }
    }
    *(undefined4 *)(arg1 + 0x1b0) = 0;
    return;
}

// ============================================================
// Function: FUN_1801014f4
// Address: 0x1801014f4
// Size: 821 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_138h
// WARNING: Variable defined which should be unmapped: var_130h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable arg_61h
// WARNING: [rz-ghidra] Detected overlap for variable arg_63h
// WARNING: [rz-ghidra] Detected overlap for variable arg_91h
// WARNING: [rz-ghidra] Detected overlap for variable var_ffh
// WARNING: [rz-ghidra] Detected overlap for variable arg_93h
// WARNING: [rz-ghidra] Detected overlap for variable var_fdh
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_fbh
// WARNING: [rz-ghidra] Detected overlap for variable var_f9h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e3h
// WARNING: [rz-ghidra] Detected overlap for variable var_e1h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e7h
// WARNING: [rz-ghidra] Detected overlap for variable var_e5h
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_10fh
// WARNING: [rz-ghidra] Detected overlap for variable var_10dh
// WARNING: [rz-ghidra] Detected overlap for variable var_10bh
// WARNING: [rz-ghidra] Detected overlap for variable var_109h
// WARNING: [rz-ghidra] Detected overlap for variable var_f3h
// WARNING: [rz-ghidra] Detected overlap for variable var_f1h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f7h
// WARNING: [rz-ghidra] Detected overlap for variable var_f5h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.180100c60(int64_t arg1, int64_t arg2, int64_t arg_60h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
                  int64_t arg_88h, int64_t arg_90h)
{
    int32_t *piVar1;
    uint8_t *puVar2;
    undefined4 *puVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    bool bVar9;
    char cVar10;
    uint8_t uVar11;
    uint32_t uVar12;
    undefined4 uVar13;
    uint32_t uVar14;
    int32_t iVar15;
    int64_t iVar16;
    float *pfVar17;
    int64_t *piVar18;
    uint32_t uVar19;
    int64_t iVar21;
    uint8_t in_R8B;
    int32_t iVar22;
    char in_R9B;
    int64_t iVar23;
    uint64_t uVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    undefined4 uStackX_8;
    float fStackX_c;
    int64_t var_10h;
    uint8_t uStackX_18;
    char cStackX_20;
    int32_t in_stack_00000028;
    int64_t in_stack_00000030;
    undefined uStack0000000000000038;
    undefined2 uStack0000000000000039;
    undefined uStack000000000000003b;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    float var_118h;
    float var_114h;
    float var_110h;
    int64_t var_10ch;
    float var_104h;
    int64_t var_100h;
    undefined var_f8h;
    undefined2 var_f7h;
    undefined var_f5h;
    undefined var_f4h;
    undefined2 var_f3h;
    undefined var_f1h;
    int64_t var_f0h;
    float var_e8h;
    int64_t var_e4h;
    float var_dch;
    uint32_t uStack_d8;
    uint32_t uStack_d4;
    int64_t var_b8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uVar20;
    
    iVar21 = *(int64_t *)0x180781f28;
    fVar4 = *(float *)(arg1 + 0x98);
    fVar5 = *(float *)(arg1 + 0x9c);
    *(undefined *)(arg1 + 0x10e) = 0;
    *(undefined4 *)(arg1 + 0x1b0) = 1;
    if (*(char *)(arg1 + 0x10c) != '\0') {
        uVar13 = *(undefined4 *)(iVar21 + 0xde8);
        *(float *)(iVar21 + 0xde8) = fVar5;
        if ((in_R8B == 0) || (iVar16 = 0x1f0, *(char *)(iVar21 + 0x21cc) == '\0')) {
            iVar16 = 0x200;
        }
        puVar3 = (undefined4 *)(iVar16 + 0xd90 + iVar21);
        var_120h._0_4_ = (float)*puVar3;
        var_120h._4_4_ = (float)puVar3[1];
        var_118h = (float)puVar3[2];
        var_114h = (float)puVar3[3] * *(float *)(iVar21 + 0xd9c);
        uVar12 = func_0x0001800f5fa0(&var_120h);
        uVar19 = uVar12 | 0xff000000;
        if (*(char *)(arg1 + 0x108) == '\0') {
            uVar19 = uVar12;
        }
        func_0x0001800f7a00(*(undefined8 *)arg2, *(undefined8 *)(arg2 + 8), uVar19, 1, fVar4);
        *(undefined4 *)(iVar21 + 0xde8) = uVar13;
        *(undefined4 *)(arg1 + 0x1b0) = 0;
        return;
    }
    uVar19 = *(uint32_t *)(arg1 + 0x14);
    uStackX_18 = in_R8B;
    cStackX_20 = in_R9B;
    if (-1 < (char)uVar19) {
        bVar9 = false;
        if ((((*(char *)(iVar21 + 0x2400) != '\0') && (*(int32_t *)(iVar21 + 4) - *(int32_t *)(iVar21 + 0x248c) < 2)) &&
            (*(char *)(iVar21 + 0x84) != '\0')) &&
           ((cVar10 = func_0x0001800f3aa0(iVar21 + 0x2410), cVar10 != '\0' &&
            (bVar9 = false, **(int64_t **)(iVar21 + 0x2410) == arg1)))) {
            bVar9 = true;
        }
        if ((uVar19 & 0x6000000) == 0) {
            if (((uVar19 >> 0x18 & 1) == 0) || (iVar16 = 0x170, (*(uint8_t *)(arg1 + 0x495) & 1) != 0)) {
                iVar16 = 0x160;
            }
        } else {
            iVar16 = 0x180;
        }
        pfVar17 = (float *)(iVar16 + 0xd90 + *(int64_t *)0x180781f28);
        var_120h._0_4_ = *pfVar17;
        var_120h._4_4_ = pfVar17[1];
        var_118h = pfVar17[2];
        var_114h = pfVar17[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar12 = func_0x0001800f5fa0(&var_120h);
        if (*(char *)(arg1 + 0x108) == '\0') {
            uVar14 = *(uint32_t *)(iVar21 + 0x2008) & 0x40;
            if (uVar14 == 0) {
                fVar25 = 1.0;
            } else {
                fVar25 = *(float *)(iVar21 + 0x2070);
            }
            if (bVar9) {
                fVar25 = fVar25 * 0.5;
            } else if (uVar14 == 0) goto code_r0x000180100ed9;
            if (0.0 <= fVar25) {
                fVar26 = 1.0;
                if (fVar25 <= 1.0) {
                    fVar26 = fVar25;
                }
            } else {
                fVar26 = 0.0;
            }
            uVar12 = (int32_t)(fVar26 * 255.0 + 0.5) << 0x18 | uVar12 & 0xffffff;
        } else {
            uVar12 = uVar12 | 0xff000000;
            if (bVar9) {
                *(float *)(*(int64_t *)(arg1 + 0x48) + 0xa0) = *(float *)(*(int64_t *)(arg1 + 0x48) + 0xa0) * 0.5;
            }
        }
code_r0x000180100ed9:
        if ((*(uint8_t *)(arg1 + 0x495) & 1) != 0) {
            *(uint32_t *)(*(int64_t *)(arg1 + 0x4c0) + 0x90) = uVar12;
        }
        if (((uVar19 >> 0x17 & 1) == 0) && ((uVar12 & 0xff000000) != 0)) {
            var_120h._0_4_ = *(float *)(arg1 + 0x60) + 0.0;
            var_118h = *(float *)(arg1 + 0x60) + *(float *)(arg1 + 0x68);
            var_120h._4_4_ = *(float *)(arg1 + 100) + *(float *)(arg1 + 0xa0);
            var_114h = *(float *)(arg1 + 100) + *(float *)(arg1 + 0x6c);
            if ((*(uint8_t *)(arg1 + 0x495) & 1) == 0) {
                iVar16 = *(int64_t *)(arg1 + 800);
                uVar13 = 0xc0;
                if ((uVar19 & 1) != 0) {
                    uVar13 = 0xf0;
                }
                iVar23 = iVar16 + 0x88;
            } else {
                iVar16 = *(int64_t *)(*(int64_t *)(arg1 + 0x4c0) + 0x98);
                var_110h = *(float *)(iVar16 + 0x60);
                var_10ch._0_4_ = *(float *)(iVar16 + 100);
                var_10ch._4_4_ = var_110h + *(float *)(iVar16 + 0x68);
                var_104h = (float)var_10ch + *(float *)(iVar16 + 0x6c);
                iVar16 = *(int64_t *)(iVar16 + 800);
                iVar23 = iVar16 + 0x88;
                func_0x000180127010(iVar23, iVar16, 0);
                uVar13 = func_0x000180130fb0(&var_120h, &var_110h);
            }
            func_0x000180126550(iVar16, &var_120h, &var_118h, uVar12, fVar4, uVar13);
            if ((*(uint8_t *)(arg1 + 0x495) & 1) != 0) {
                func_0x000180127010(iVar23, iVar16, 1);
            }
        }
    }
    uVar11 = *(uint8_t *)(arg1 + 0x495);
    if ((uVar11 & 1) != 0) {
        puVar2 = (uint8_t *)(*(int64_t *)(arg1 + 0x4c0) + 0xdc);
        *puVar2 = *puVar2 | 4;
        uVar11 = *(uint8_t *)(arg1 + 0x495);
    }
    if (((uVar19 & 1) == 0) && ((uVar11 & 1) == 0)) {
        pfVar17 = (float *)(*(int64_t *)0x180781f28 + 0xd90 + ((uint64_t)uStackX_18 + 0x1e) * 0x10);
        var_120h._0_4_ = *pfVar17;
        var_120h._4_4_ = pfVar17[1];
        var_118h = pfVar17[2];
        var_114h = pfVar17[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar14 = func_0x0001800f5fa0(&var_120h);
        uVar12 = uVar14 | 0xff000000;
        if (*(char *)(arg1 + 0x108) == '\0') {
            uVar12 = uVar14;
        }
        func_0x000180126550(*(undefined8 *)(arg1 + 800), arg2, arg2 + 8, uVar12, fVar4, 0x30);
    }
    if ((uVar19 >> 10 & 1) != 0) {
        fVar25 = *(float *)(arg1 + 0x60);
        fVar26 = *(float *)(arg1 + 100);
        fVar28 = fVar26 + *(float *)(arg1 + 0xa0);
        fVar29 = fVar25 + *(float *)(arg1 + 0x70);
        fVar27 = fVar25 + *(float *)(arg1 + 0x68);
        var_120h._4_4_ = fVar28;
        if (fVar28 <= fVar26) {
            var_120h._4_4_ = fVar26;
        }
        if (fVar27 <= fVar29) {
            fVar29 = fVar27;
        }
        fVar26 = fVar26 + *(float *)(arg1 + 0x6c);
        fVar28 = fVar28 + *(float *)(arg1 + 0xa4);
        if (fVar26 <= fVar28) {
            fVar28 = fVar26;
        }
        fVar26 = fVar4;
        if ((uVar19 & 1) == 0) {
            fVar26 = 0.0;
        }
        var_110h = *(float *)(*(int64_t *)0x180781f28 + 4000);
        var_10ch._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xfa4);
        var_10ch._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xfa8);
        var_104h = *(float *)(*(int64_t *)0x180781f28 + 0xfac) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        var_120h._0_4_ = fVar25;
        var_118h = fVar29;
        var_114h = fVar28;
        uVar13 = func_0x0001800f5fa0(&var_110h);
        func_0x000180126550(*(undefined8 *)(arg1 + 800), &var_120h, &var_118h, uVar13, fVar26, 0x30);
        fVar26 = *(float *)(iVar21 + 0xde8);
        if ((0.0 < fVar26) && (fVar28 < *(float *)(arg1 + 0x6c) + *(float *)(arg1 + 100))) {
            var_110h = *(float *)(*(int64_t *)0x180781f28 + 0xf20);
            var_10ch._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xf24);
            var_10ch._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xf28);
            uStackX_8 = fVar29 - fVar5 * 0.5;
            var_120h._0_4_ = fVar5 * 0.5 + fVar25;
            var_104h = *(float *)(*(int64_t *)0x180781f28 + 0xf2c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            fStackX_c = fVar28 - 0.0;
            var_120h._4_4_ = fVar28 + 0.0;
            uVar13 = func_0x0001800f5fa0(&var_110h);
            func_0x000180126300(*(undefined8 *)(arg1 + 800), &var_120h, &uStackX_8, uVar13, fVar26);
        }
    }
    uVar20 = 0;
    if ((*(uint8_t *)(arg1 + 0x495) & 1) == 0) goto code_r0x0001801014aa;
    iVar16 = *(int64_t *)(arg1 + 0x4c0);
    if (((*(uint32_t *)(iVar16 + 0x10) >> 0xd & 1) == 0) || ((*(uint32_t *)(iVar16 + 0x10) >> 0xc & 1) != 0))
    goto code_r0x0001801014aa;
    fVar25 = *(float *)(iVar16 + 0x48);
    fVar26 = *(float *)(iVar16 + 0x4c);
    fVar28 = (float)(int32_t)(*(float *)(iVar21 + 0x12f8) * 0.7);
    var_dch = (float)(int32_t)(*(float *)(iVar21 + 0x12f8) * 0.55);
    var_e4h._4_4_ = fVar25 + var_dch;
    var_dch = fVar26 + var_dch;
    var_e8h = fVar25;
    var_e4h._0_4_ = fVar26;
    iVar15 = func_0x0001800f5a90(0x180644598, 0, 
                                 *(undefined4 *)
                                  (*(int64_t *)(arg1 + 0x150) + -4 + (int64_t)*(int32_t *)(arg1 + 0x148) * 4));
    iVar21 = *(int64_t *)0x180781f28;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == iVar15) {
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = iVar15;
    }
    if (*(int32_t *)(iVar21 + 0x1684) == iVar15) {
        *(undefined *)(iVar21 + 0x168d) = 1;
    }
    cVar10 = func_0x000180139d40(&var_e8h, iVar15, &uStackX_8, &var_128h, 0x800);
    if (cVar10 == '\0') {
        if ((char)var_128h != '\0') {
            if ((*(char *)(*(int64_t *)0x180781f28 + 0x120) != '\0') &&
               (*(float *)(*(int64_t *)0x180781f28 + 0xa4) * *(float *)(*(int64_t *)0x180781f28 + 0xa4) <=
                *(float *)(*(int64_t *)0x180781f28 + 0xbfc))) {
                func_0x0001800faaf0(arg1, iVar16, 1);
            }
            goto code_r0x000180101384;
        }
code_r0x000180101399:
        if (((*(uint8_t *)(iVar16 + 0xdc) & 2) != 0) && ((char)uStackX_8 == '\0')) goto code_r0x0001801013a6;
        iVar21 = (uint64_t)((char)uStackX_8 != '\0') + 0x15;
    } else {
        *(uint8_t *)(iVar16 + 0xdd) = *(uint8_t *)(iVar16 + 0xdd) | 4;
code_r0x000180101384:
        if (((char)var_128h == '\0') || ((char)uStackX_8 == '\0')) goto code_r0x000180101399;
code_r0x0001801013a6:
        iVar21 = 0x17;
    }
    puVar3 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar21 + 0x14) * 0x10);
    var_120h._0_4_ = (float)*puVar3;
    var_120h._4_4_ = (float)puVar3[1];
    var_118h = (float)puVar3[2];
    var_114h = (float)puVar3[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar12 = func_0x0001800f5fa0(&var_120h);
    var_110h = fVar25 + 0.0;
    var_120h._0_4_ = fVar25 + fVar28;
    var_10ch._0_4_ = fVar26 + fVar28;
    var_120h._4_4_ = fVar26 + 0.0;
    if ((uVar12 & 0xff000000) != 0) {
        iVar21 = *(int64_t *)(arg1 + 800);
        iVar15 = *(int32_t *)(iVar21 + 0x54);
        if (*(int32_t *)(iVar21 + 0x50) == iVar15) {
            iVar22 = *(int32_t *)(iVar21 + 0x50) + 1;
            if (iVar15 == 0) {
                iVar15 = 8;
            } else {
                iVar15 = iVar15 / 2 + iVar15;
            }
            if (iVar22 < iVar15) {
                iVar22 = iVar15;
            }
            func_0x00018011f4f0(iVar21 + 0x50, iVar22);
        }
        iVar15 = *(int32_t *)(iVar21 + 0x50);
        iVar16 = *(int64_t *)(iVar21 + 0x58);
        *(float *)(iVar16 + (int64_t)iVar15 * 8) = fVar25;
        *(float *)(iVar16 + 4 + (int64_t)iVar15 * 8) = fVar26;
        *(int32_t *)(iVar21 + 0x50) = *(int32_t *)(iVar21 + 0x50) + 1;
        func_0x0001800f3b50(iVar21, &var_120h);
        func_0x0001800f3b50(iVar21, &var_110h);
        func_0x0001800f3bc0(iVar21, uVar12);
    }
code_r0x0001801014aa:
    if (*(char *)(arg1 + 0x104) != '\0') {
        func_0x00018013b430(0);
    }
    if (*(char *)(arg1 + 0x105) != '\0') {
        func_0x00018013b430(1);
    }
    fVar25 = _uStack0000000000000038;
    if (cStackX_20 != '\0') {
        if (((uVar19 & 2) == 0) && (var_f0h._0_4_ = 0, uVar24 = uVar20, 0 < in_stack_00000028)) {
            do {
                uStack_d4 = *(uint32_t *)(in_stack_00000030 + uVar24 * 4);
                uVar19 = (uint32_t)uVar20;
                if ((uStack_d4 & 0xff000000) != 0) {
                    fVar26 = *(float *)(arg1 + 0x60);
                    fVar28 = *(float *)(arg1 + 100);
                    iVar21 = *(int64_t *)(arg1 + 800);
                    uStack_d8 = (uint32_t)uVar20 & 1;
                    fVar26 = ((fVar26 + *(float *)(arg1 + 0x68)) - fVar26) * *(float *)(uVar24 * 0x18 + 0x1806185c0) +
                             fVar26;
                    fVar28 = ((fVar28 + *(float *)(arg1 + 0x6c)) - fVar28) * *(float *)(uVar24 * 0x18 + 0x1806185c4) +
                             fVar28;
                    fVar29 = (float)(int32_t)(fVar5 * 0.5 + 0.5);
                    uStackX_8._0_1_ = SUB41(fVar29, 0);
                    uStackX_8._1_2_ = (undefined2)((uint32_t)fVar29 >> 8);
                    uStackX_8._3_1_ = (undefined)((uint32_t)fVar29 >> 0x18);
                    if ((uVar20 & 1) == 0) {
                        var_100h._0_1_ = uStack0000000000000038;
                        var_100h._1_2_ = uStack0000000000000039;
                        var_100h._3_1_ = uStack000000000000003b;
                        var_100h._4_1_ = (char)uStackX_8;
                        var_100h._5_2_ = uStackX_8._1_2_;
                        var_100h._7_1_ = uStackX_8._3_1_;
                        fVar27 = fVar25;
                    } else {
                        var_f4h = uStack0000000000000038;
                        var_f3h = uStack0000000000000039;
                        var_f1h = uStack000000000000003b;
                        var_f8h = (char)uStackX_8;
                        var_f7h = uStackX_8._1_2_;
                        var_f5h = uStackX_8._3_1_;
                        fVar27 = fVar29;
                    }
                    fVar6 = *(float *)(uVar24 * 0x18 + 0x1806185c8);
                    piVar1 = (int32_t *)(iVar21 + 0x50);
                    iVar15 = *(int32_t *)(iVar21 + 0x54);
                    pfVar17 = (float *)((int64_t)&var_100h + 4);
                    if ((uVar20 & 1) != 0) {
                        pfVar17 = (float *)&var_f4h;
                    }
                    fVar7 = *pfVar17;
                    fVar8 = *(float *)(uVar24 * 0x18 + 0x1806185cc);
                    uStackX_8 = fVar29;
                    if (*piVar1 == iVar15) {
                        iVar22 = *piVar1 + 1;
                        if (iVar15 == 0) {
                            iVar15 = 8;
                        } else {
                            iVar15 = iVar15 / 2 + iVar15;
                        }
                        if (iVar22 < iVar15) {
                            iVar22 = iVar15;
                        }
                        func_0x00018011f4f0(piVar1, iVar22);
                    }
                    iVar15 = *piVar1;
                    iVar21 = *(int64_t *)(iVar21 + 0x58);
                    *(float *)(iVar21 + (int64_t)iVar15 * 8) = fVar27 * fVar6 + fVar26;
                    *(float *)(iVar21 + 4 + (int64_t)iVar15 * 8) = fVar7 * fVar8 + fVar28;
                    *piVar1 = *piVar1 + 1;
                    iVar21 = *(int64_t *)(arg1 + 800);
                    if (uStack_d8 == 0) {
                        var_e4h._0_4_ = _uStack0000000000000038;
                        var_e8h = fVar29;
                        fVar27 = fVar29;
                    } else {
                        var_110h = _uStack0000000000000038;
                        var_10ch._0_4_ = fVar29;
                        fVar27 = fVar25;
                    }
                    fVar6 = *(float *)(uVar24 * 0x18 + 0x1806185c8);
                    piVar1 = (int32_t *)(iVar21 + 0x50);
                    iVar15 = *(int32_t *)(iVar21 + 0x54);
                    piVar18 = &var_e4h;
                    if (uStack_d8 != 0) {
                        piVar18 = &var_10ch;
                    }
                    fVar7 = *(float *)piVar18;
                    fVar8 = *(float *)(uVar24 * 0x18 + 0x1806185cc);
                    if (*piVar1 == iVar15) {
                        iVar22 = *piVar1 + 1;
                        if (iVar15 == 0) {
                            iVar15 = 8;
                        } else {
                            iVar15 = iVar15 / 2 + iVar15;
                        }
                        if (iVar22 < iVar15) {
                            iVar22 = iVar15;
                        }
                        func_0x00018011f4f0(piVar1, iVar22);
                    }
                    iVar15 = *piVar1;
                    iVar21 = *(int64_t *)(iVar21 + 0x58);
                    *(float *)(iVar21 + (int64_t)iVar15 * 8) = fVar27 * fVar6 + fVar26;
                    *(float *)(iVar21 + 4 + (int64_t)iVar15 * 8) = fVar7 * fVar8 + fVar28;
                    *piVar1 = *piVar1 + 1;
                    var_120h._0_4_ = (fVar29 + fVar4) * *(float *)(uVar24 * 0x18 + 0x1806185c8) + fVar26;
                    var_120h._4_4_ = (fVar29 + fVar4) * *(float *)(uVar24 * 0x18 + 0x1806185cc) + fVar28;
                    if (0.5 <= fVar4) {
                        func_0x0001801257a0(*(int64_t *)(arg1 + 800), &var_120h);
                    } else {
                        func_0x00018011f490(*(int64_t *)(arg1 + 800) + 0x50);
                    }
                    func_0x0001800f3bc0(*(undefined8 *)(arg1 + 800), uStack_d4);
                    uVar19 = (uint32_t)var_f0h;
                }
                var_f0h._0_4_ = uVar19 + 1;
                uVar20 = (uint64_t)(uint32_t)var_f0h;
                uVar24 = uVar24 + 1;
            } while ((int32_t)(uint32_t)var_f0h < in_stack_00000028);
        }
        if (*(int64_t *)(arg1 + 0x4c8) == 0) {
            fcn.180100a00(arg1);
        }
    }
    *(undefined4 *)(arg1 + 0x1b0) = 0;
    return;
}

// ============================================================
// Function: FUN_180101829
// Address: 0x180101829
// Size: 93 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_138h
// WARNING: Variable defined which should be unmapped: var_130h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable arg_61h
// WARNING: [rz-ghidra] Detected overlap for variable arg_63h
// WARNING: [rz-ghidra] Detected overlap for variable arg_91h
// WARNING: [rz-ghidra] Detected overlap for variable var_ffh
// WARNING: [rz-ghidra] Detected overlap for variable arg_93h
// WARNING: [rz-ghidra] Detected overlap for variable var_fdh
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_fbh
// WARNING: [rz-ghidra] Detected overlap for variable var_f9h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e3h
// WARNING: [rz-ghidra] Detected overlap for variable var_e1h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e7h
// WARNING: [rz-ghidra] Detected overlap for variable var_e5h
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_10fh
// WARNING: [rz-ghidra] Detected overlap for variable var_10dh
// WARNING: [rz-ghidra] Detected overlap for variable var_10bh
// WARNING: [rz-ghidra] Detected overlap for variable var_109h
// WARNING: [rz-ghidra] Detected overlap for variable var_f3h
// WARNING: [rz-ghidra] Detected overlap for variable var_f1h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f7h
// WARNING: [rz-ghidra] Detected overlap for variable var_f5h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.180100c60(int64_t arg1, int64_t arg2, int64_t arg_60h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
                  int64_t arg_88h, int64_t arg_90h)
{
    int32_t *piVar1;
    uint8_t *puVar2;
    undefined4 *puVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    bool bVar9;
    char cVar10;
    uint8_t uVar11;
    uint32_t uVar12;
    undefined4 uVar13;
    uint32_t uVar14;
    int32_t iVar15;
    int64_t iVar16;
    float *pfVar17;
    int64_t *piVar18;
    uint32_t uVar19;
    int64_t iVar21;
    uint8_t in_R8B;
    int32_t iVar22;
    char in_R9B;
    int64_t iVar23;
    uint64_t uVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    undefined4 uStackX_8;
    float fStackX_c;
    int64_t var_10h;
    uint8_t uStackX_18;
    char cStackX_20;
    int32_t in_stack_00000028;
    int64_t in_stack_00000030;
    undefined uStack0000000000000038;
    undefined2 uStack0000000000000039;
    undefined uStack000000000000003b;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    float var_118h;
    float var_114h;
    float var_110h;
    int64_t var_10ch;
    float var_104h;
    int64_t var_100h;
    undefined var_f8h;
    undefined2 var_f7h;
    undefined var_f5h;
    undefined var_f4h;
    undefined2 var_f3h;
    undefined var_f1h;
    int64_t var_f0h;
    float var_e8h;
    int64_t var_e4h;
    float var_dch;
    uint32_t uStack_d8;
    uint32_t uStack_d4;
    int64_t var_b8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uVar20;
    
    iVar21 = *(int64_t *)0x180781f28;
    fVar4 = *(float *)(arg1 + 0x98);
    fVar5 = *(float *)(arg1 + 0x9c);
    *(undefined *)(arg1 + 0x10e) = 0;
    *(undefined4 *)(arg1 + 0x1b0) = 1;
    if (*(char *)(arg1 + 0x10c) != '\0') {
        uVar13 = *(undefined4 *)(iVar21 + 0xde8);
        *(float *)(iVar21 + 0xde8) = fVar5;
        if ((in_R8B == 0) || (iVar16 = 0x1f0, *(char *)(iVar21 + 0x21cc) == '\0')) {
            iVar16 = 0x200;
        }
        puVar3 = (undefined4 *)(iVar16 + 0xd90 + iVar21);
        var_120h._0_4_ = (float)*puVar3;
        var_120h._4_4_ = (float)puVar3[1];
        var_118h = (float)puVar3[2];
        var_114h = (float)puVar3[3] * *(float *)(iVar21 + 0xd9c);
        uVar12 = func_0x0001800f5fa0(&var_120h);
        uVar19 = uVar12 | 0xff000000;
        if (*(char *)(arg1 + 0x108) == '\0') {
            uVar19 = uVar12;
        }
        func_0x0001800f7a00(*(undefined8 *)arg2, *(undefined8 *)(arg2 + 8), uVar19, 1, fVar4);
        *(undefined4 *)(iVar21 + 0xde8) = uVar13;
        *(undefined4 *)(arg1 + 0x1b0) = 0;
        return;
    }
    uVar19 = *(uint32_t *)(arg1 + 0x14);
    uStackX_18 = in_R8B;
    cStackX_20 = in_R9B;
    if (-1 < (char)uVar19) {
        bVar9 = false;
        if ((((*(char *)(iVar21 + 0x2400) != '\0') && (*(int32_t *)(iVar21 + 4) - *(int32_t *)(iVar21 + 0x248c) < 2)) &&
            (*(char *)(iVar21 + 0x84) != '\0')) &&
           ((cVar10 = func_0x0001800f3aa0(iVar21 + 0x2410), cVar10 != '\0' &&
            (bVar9 = false, **(int64_t **)(iVar21 + 0x2410) == arg1)))) {
            bVar9 = true;
        }
        if ((uVar19 & 0x6000000) == 0) {
            if (((uVar19 >> 0x18 & 1) == 0) || (iVar16 = 0x170, (*(uint8_t *)(arg1 + 0x495) & 1) != 0)) {
                iVar16 = 0x160;
            }
        } else {
            iVar16 = 0x180;
        }
        pfVar17 = (float *)(iVar16 + 0xd90 + *(int64_t *)0x180781f28);
        var_120h._0_4_ = *pfVar17;
        var_120h._4_4_ = pfVar17[1];
        var_118h = pfVar17[2];
        var_114h = pfVar17[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar12 = func_0x0001800f5fa0(&var_120h);
        if (*(char *)(arg1 + 0x108) == '\0') {
            uVar14 = *(uint32_t *)(iVar21 + 0x2008) & 0x40;
            if (uVar14 == 0) {
                fVar25 = 1.0;
            } else {
                fVar25 = *(float *)(iVar21 + 0x2070);
            }
            if (bVar9) {
                fVar25 = fVar25 * 0.5;
            } else if (uVar14 == 0) goto code_r0x000180100ed9;
            if (0.0 <= fVar25) {
                fVar26 = 1.0;
                if (fVar25 <= 1.0) {
                    fVar26 = fVar25;
                }
            } else {
                fVar26 = 0.0;
            }
            uVar12 = (int32_t)(fVar26 * 255.0 + 0.5) << 0x18 | uVar12 & 0xffffff;
        } else {
            uVar12 = uVar12 | 0xff000000;
            if (bVar9) {
                *(float *)(*(int64_t *)(arg1 + 0x48) + 0xa0) = *(float *)(*(int64_t *)(arg1 + 0x48) + 0xa0) * 0.5;
            }
        }
code_r0x000180100ed9:
        if ((*(uint8_t *)(arg1 + 0x495) & 1) != 0) {
            *(uint32_t *)(*(int64_t *)(arg1 + 0x4c0) + 0x90) = uVar12;
        }
        if (((uVar19 >> 0x17 & 1) == 0) && ((uVar12 & 0xff000000) != 0)) {
            var_120h._0_4_ = *(float *)(arg1 + 0x60) + 0.0;
            var_118h = *(float *)(arg1 + 0x60) + *(float *)(arg1 + 0x68);
            var_120h._4_4_ = *(float *)(arg1 + 100) + *(float *)(arg1 + 0xa0);
            var_114h = *(float *)(arg1 + 100) + *(float *)(arg1 + 0x6c);
            if ((*(uint8_t *)(arg1 + 0x495) & 1) == 0) {
                iVar16 = *(int64_t *)(arg1 + 800);
                uVar13 = 0xc0;
                if ((uVar19 & 1) != 0) {
                    uVar13 = 0xf0;
                }
                iVar23 = iVar16 + 0x88;
            } else {
                iVar16 = *(int64_t *)(*(int64_t *)(arg1 + 0x4c0) + 0x98);
                var_110h = *(float *)(iVar16 + 0x60);
                var_10ch._0_4_ = *(float *)(iVar16 + 100);
                var_10ch._4_4_ = var_110h + *(float *)(iVar16 + 0x68);
                var_104h = (float)var_10ch + *(float *)(iVar16 + 0x6c);
                iVar16 = *(int64_t *)(iVar16 + 800);
                iVar23 = iVar16 + 0x88;
                func_0x000180127010(iVar23, iVar16, 0);
                uVar13 = func_0x000180130fb0(&var_120h, &var_110h);
            }
            func_0x000180126550(iVar16, &var_120h, &var_118h, uVar12, fVar4, uVar13);
            if ((*(uint8_t *)(arg1 + 0x495) & 1) != 0) {
                func_0x000180127010(iVar23, iVar16, 1);
            }
        }
    }
    uVar11 = *(uint8_t *)(arg1 + 0x495);
    if ((uVar11 & 1) != 0) {
        puVar2 = (uint8_t *)(*(int64_t *)(arg1 + 0x4c0) + 0xdc);
        *puVar2 = *puVar2 | 4;
        uVar11 = *(uint8_t *)(arg1 + 0x495);
    }
    if (((uVar19 & 1) == 0) && ((uVar11 & 1) == 0)) {
        pfVar17 = (float *)(*(int64_t *)0x180781f28 + 0xd90 + ((uint64_t)uStackX_18 + 0x1e) * 0x10);
        var_120h._0_4_ = *pfVar17;
        var_120h._4_4_ = pfVar17[1];
        var_118h = pfVar17[2];
        var_114h = pfVar17[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar14 = func_0x0001800f5fa0(&var_120h);
        uVar12 = uVar14 | 0xff000000;
        if (*(char *)(arg1 + 0x108) == '\0') {
            uVar12 = uVar14;
        }
        func_0x000180126550(*(undefined8 *)(arg1 + 800), arg2, arg2 + 8, uVar12, fVar4, 0x30);
    }
    if ((uVar19 >> 10 & 1) != 0) {
        fVar25 = *(float *)(arg1 + 0x60);
        fVar26 = *(float *)(arg1 + 100);
        fVar28 = fVar26 + *(float *)(arg1 + 0xa0);
        fVar29 = fVar25 + *(float *)(arg1 + 0x70);
        fVar27 = fVar25 + *(float *)(arg1 + 0x68);
        var_120h._4_4_ = fVar28;
        if (fVar28 <= fVar26) {
            var_120h._4_4_ = fVar26;
        }
        if (fVar27 <= fVar29) {
            fVar29 = fVar27;
        }
        fVar26 = fVar26 + *(float *)(arg1 + 0x6c);
        fVar28 = fVar28 + *(float *)(arg1 + 0xa4);
        if (fVar26 <= fVar28) {
            fVar28 = fVar26;
        }
        fVar26 = fVar4;
        if ((uVar19 & 1) == 0) {
            fVar26 = 0.0;
        }
        var_110h = *(float *)(*(int64_t *)0x180781f28 + 4000);
        var_10ch._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xfa4);
        var_10ch._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xfa8);
        var_104h = *(float *)(*(int64_t *)0x180781f28 + 0xfac) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        var_120h._0_4_ = fVar25;
        var_118h = fVar29;
        var_114h = fVar28;
        uVar13 = func_0x0001800f5fa0(&var_110h);
        func_0x000180126550(*(undefined8 *)(arg1 + 800), &var_120h, &var_118h, uVar13, fVar26, 0x30);
        fVar26 = *(float *)(iVar21 + 0xde8);
        if ((0.0 < fVar26) && (fVar28 < *(float *)(arg1 + 0x6c) + *(float *)(arg1 + 100))) {
            var_110h = *(float *)(*(int64_t *)0x180781f28 + 0xf20);
            var_10ch._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xf24);
            var_10ch._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xf28);
            uStackX_8 = fVar29 - fVar5 * 0.5;
            var_120h._0_4_ = fVar5 * 0.5 + fVar25;
            var_104h = *(float *)(*(int64_t *)0x180781f28 + 0xf2c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            fStackX_c = fVar28 - 0.0;
            var_120h._4_4_ = fVar28 + 0.0;
            uVar13 = func_0x0001800f5fa0(&var_110h);
            func_0x000180126300(*(undefined8 *)(arg1 + 800), &var_120h, &uStackX_8, uVar13, fVar26);
        }
    }
    uVar20 = 0;
    if ((*(uint8_t *)(arg1 + 0x495) & 1) == 0) goto code_r0x0001801014aa;
    iVar16 = *(int64_t *)(arg1 + 0x4c0);
    if (((*(uint32_t *)(iVar16 + 0x10) >> 0xd & 1) == 0) || ((*(uint32_t *)(iVar16 + 0x10) >> 0xc & 1) != 0))
    goto code_r0x0001801014aa;
    fVar25 = *(float *)(iVar16 + 0x48);
    fVar26 = *(float *)(iVar16 + 0x4c);
    fVar28 = (float)(int32_t)(*(float *)(iVar21 + 0x12f8) * 0.7);
    var_dch = (float)(int32_t)(*(float *)(iVar21 + 0x12f8) * 0.55);
    var_e4h._4_4_ = fVar25 + var_dch;
    var_dch = fVar26 + var_dch;
    var_e8h = fVar25;
    var_e4h._0_4_ = fVar26;
    iVar15 = func_0x0001800f5a90(0x180644598, 0, 
                                 *(undefined4 *)
                                  (*(int64_t *)(arg1 + 0x150) + -4 + (int64_t)*(int32_t *)(arg1 + 0x148) * 4));
    iVar21 = *(int64_t *)0x180781f28;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == iVar15) {
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = iVar15;
    }
    if (*(int32_t *)(iVar21 + 0x1684) == iVar15) {
        *(undefined *)(iVar21 + 0x168d) = 1;
    }
    cVar10 = func_0x000180139d40(&var_e8h, iVar15, &uStackX_8, &var_128h, 0x800);
    if (cVar10 == '\0') {
        if ((char)var_128h != '\0') {
            if ((*(char *)(*(int64_t *)0x180781f28 + 0x120) != '\0') &&
               (*(float *)(*(int64_t *)0x180781f28 + 0xa4) * *(float *)(*(int64_t *)0x180781f28 + 0xa4) <=
                *(float *)(*(int64_t *)0x180781f28 + 0xbfc))) {
                func_0x0001800faaf0(arg1, iVar16, 1);
            }
            goto code_r0x000180101384;
        }
code_r0x000180101399:
        if (((*(uint8_t *)(iVar16 + 0xdc) & 2) != 0) && ((char)uStackX_8 == '\0')) goto code_r0x0001801013a6;
        iVar21 = (uint64_t)((char)uStackX_8 != '\0') + 0x15;
    } else {
        *(uint8_t *)(iVar16 + 0xdd) = *(uint8_t *)(iVar16 + 0xdd) | 4;
code_r0x000180101384:
        if (((char)var_128h == '\0') || ((char)uStackX_8 == '\0')) goto code_r0x000180101399;
code_r0x0001801013a6:
        iVar21 = 0x17;
    }
    puVar3 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar21 + 0x14) * 0x10);
    var_120h._0_4_ = (float)*puVar3;
    var_120h._4_4_ = (float)puVar3[1];
    var_118h = (float)puVar3[2];
    var_114h = (float)puVar3[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar12 = func_0x0001800f5fa0(&var_120h);
    var_110h = fVar25 + 0.0;
    var_120h._0_4_ = fVar25 + fVar28;
    var_10ch._0_4_ = fVar26 + fVar28;
    var_120h._4_4_ = fVar26 + 0.0;
    if ((uVar12 & 0xff000000) != 0) {
        iVar21 = *(int64_t *)(arg1 + 800);
        iVar15 = *(int32_t *)(iVar21 + 0x54);
        if (*(int32_t *)(iVar21 + 0x50) == iVar15) {
            iVar22 = *(int32_t *)(iVar21 + 0x50) + 1;
            if (iVar15 == 0) {
                iVar15 = 8;
            } else {
                iVar15 = iVar15 / 2 + iVar15;
            }
            if (iVar22 < iVar15) {
                iVar22 = iVar15;
            }
            func_0x00018011f4f0(iVar21 + 0x50, iVar22);
        }
        iVar15 = *(int32_t *)(iVar21 + 0x50);
        iVar16 = *(int64_t *)(iVar21 + 0x58);
        *(float *)(iVar16 + (int64_t)iVar15 * 8) = fVar25;
        *(float *)(iVar16 + 4 + (int64_t)iVar15 * 8) = fVar26;
        *(int32_t *)(iVar21 + 0x50) = *(int32_t *)(iVar21 + 0x50) + 1;
        func_0x0001800f3b50(iVar21, &var_120h);
        func_0x0001800f3b50(iVar21, &var_110h);
        func_0x0001800f3bc0(iVar21, uVar12);
    }
code_r0x0001801014aa:
    if (*(char *)(arg1 + 0x104) != '\0') {
        func_0x00018013b430(0);
    }
    if (*(char *)(arg1 + 0x105) != '\0') {
        func_0x00018013b430(1);
    }
    fVar25 = _uStack0000000000000038;
    if (cStackX_20 != '\0') {
        if (((uVar19 & 2) == 0) && (var_f0h._0_4_ = 0, uVar24 = uVar20, 0 < in_stack_00000028)) {
            do {
                uStack_d4 = *(uint32_t *)(in_stack_00000030 + uVar24 * 4);
                uVar19 = (uint32_t)uVar20;
                if ((uStack_d4 & 0xff000000) != 0) {
                    fVar26 = *(float *)(arg1 + 0x60);
                    fVar28 = *(float *)(arg1 + 100);
                    iVar21 = *(int64_t *)(arg1 + 800);
                    uStack_d8 = (uint32_t)uVar20 & 1;
                    fVar26 = ((fVar26 + *(float *)(arg1 + 0x68)) - fVar26) * *(float *)(uVar24 * 0x18 + 0x1806185c0) +
                             fVar26;
                    fVar28 = ((fVar28 + *(float *)(arg1 + 0x6c)) - fVar28) * *(float *)(uVar24 * 0x18 + 0x1806185c4) +
                             fVar28;
                    fVar29 = (float)(int32_t)(fVar5 * 0.5 + 0.5);
                    uStackX_8._0_1_ = SUB41(fVar29, 0);
                    uStackX_8._1_2_ = (undefined2)((uint32_t)fVar29 >> 8);
                    uStackX_8._3_1_ = (undefined)((uint32_t)fVar29 >> 0x18);
                    if ((uVar20 & 1) == 0) {
                        var_100h._0_1_ = uStack0000000000000038;
                        var_100h._1_2_ = uStack0000000000000039;
                        var_100h._3_1_ = uStack000000000000003b;
                        var_100h._4_1_ = (char)uStackX_8;
                        var_100h._5_2_ = uStackX_8._1_2_;
                        var_100h._7_1_ = uStackX_8._3_1_;
                        fVar27 = fVar25;
                    } else {
                        var_f4h = uStack0000000000000038;
                        var_f3h = uStack0000000000000039;
                        var_f1h = uStack000000000000003b;
                        var_f8h = (char)uStackX_8;
                        var_f7h = uStackX_8._1_2_;
                        var_f5h = uStackX_8._3_1_;
                        fVar27 = fVar29;
                    }
                    fVar6 = *(float *)(uVar24 * 0x18 + 0x1806185c8);
                    piVar1 = (int32_t *)(iVar21 + 0x50);
                    iVar15 = *(int32_t *)(iVar21 + 0x54);
                    pfVar17 = (float *)((int64_t)&var_100h + 4);
                    if ((uVar20 & 1) != 0) {
                        pfVar17 = (float *)&var_f4h;
                    }
                    fVar7 = *pfVar17;
                    fVar8 = *(float *)(uVar24 * 0x18 + 0x1806185cc);
                    uStackX_8 = fVar29;
                    if (*piVar1 == iVar15) {
                        iVar22 = *piVar1 + 1;
                        if (iVar15 == 0) {
                            iVar15 = 8;
                        } else {
                            iVar15 = iVar15 / 2 + iVar15;
                        }
                        if (iVar22 < iVar15) {
                            iVar22 = iVar15;
                        }
                        func_0x00018011f4f0(piVar1, iVar22);
                    }
                    iVar15 = *piVar1;
                    iVar21 = *(int64_t *)(iVar21 + 0x58);
                    *(float *)(iVar21 + (int64_t)iVar15 * 8) = fVar27 * fVar6 + fVar26;
                    *(float *)(iVar21 + 4 + (int64_t)iVar15 * 8) = fVar7 * fVar8 + fVar28;
                    *piVar1 = *piVar1 + 1;
                    iVar21 = *(int64_t *)(arg1 + 800);
                    if (uStack_d8 == 0) {
                        var_e4h._0_4_ = _uStack0000000000000038;
                        var_e8h = fVar29;
                        fVar27 = fVar29;
                    } else {
                        var_110h = _uStack0000000000000038;
                        var_10ch._0_4_ = fVar29;
                        fVar27 = fVar25;
                    }
                    fVar6 = *(float *)(uVar24 * 0x18 + 0x1806185c8);
                    piVar1 = (int32_t *)(iVar21 + 0x50);
                    iVar15 = *(int32_t *)(iVar21 + 0x54);
                    piVar18 = &var_e4h;
                    if (uStack_d8 != 0) {
                        piVar18 = &var_10ch;
                    }
                    fVar7 = *(float *)piVar18;
                    fVar8 = *(float *)(uVar24 * 0x18 + 0x1806185cc);
                    if (*piVar1 == iVar15) {
                        iVar22 = *piVar1 + 1;
                        if (iVar15 == 0) {
                            iVar15 = 8;
                        } else {
                            iVar15 = iVar15 / 2 + iVar15;
                        }
                        if (iVar22 < iVar15) {
                            iVar22 = iVar15;
                        }
                        func_0x00018011f4f0(piVar1, iVar22);
                    }
                    iVar15 = *piVar1;
                    iVar21 = *(int64_t *)(iVar21 + 0x58);
                    *(float *)(iVar21 + (int64_t)iVar15 * 8) = fVar27 * fVar6 + fVar26;
                    *(float *)(iVar21 + 4 + (int64_t)iVar15 * 8) = fVar7 * fVar8 + fVar28;
                    *piVar1 = *piVar1 + 1;
                    var_120h._0_4_ = (fVar29 + fVar4) * *(float *)(uVar24 * 0x18 + 0x1806185c8) + fVar26;
                    var_120h._4_4_ = (fVar29 + fVar4) * *(float *)(uVar24 * 0x18 + 0x1806185cc) + fVar28;
                    if (0.5 <= fVar4) {
                        func_0x0001801257a0(*(int64_t *)(arg1 + 800), &var_120h);
                    } else {
                        func_0x00018011f490(*(int64_t *)(arg1 + 800) + 0x50);
                    }
                    func_0x0001800f3bc0(*(undefined8 *)(arg1 + 800), uStack_d4);
                    uVar19 = (uint32_t)var_f0h;
                }
                var_f0h._0_4_ = uVar19 + 1;
                uVar20 = (uint64_t)(uint32_t)var_f0h;
                uVar24 = uVar24 + 1;
            } while ((int32_t)(uint32_t)var_f0h < in_stack_00000028);
        }
        if (*(int64_t *)(arg1 + 0x4c8) == 0) {
            fcn.180100a00(arg1);
        }
    }
    *(undefined4 *)(arg1 + 0x1b0) = 0;
    return;
}

// ============================================================
// Function: FUN_180101886
// Address: 0x180101886
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_138h
// WARNING: Variable defined which should be unmapped: var_130h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable arg_61h
// WARNING: [rz-ghidra] Detected overlap for variable arg_63h
// WARNING: [rz-ghidra] Detected overlap for variable arg_91h
// WARNING: [rz-ghidra] Detected overlap for variable var_ffh
// WARNING: [rz-ghidra] Detected overlap for variable arg_93h
// WARNING: [rz-ghidra] Detected overlap for variable var_fdh
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_fbh
// WARNING: [rz-ghidra] Detected overlap for variable var_f9h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e3h
// WARNING: [rz-ghidra] Detected overlap for variable var_e1h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e7h
// WARNING: [rz-ghidra] Detected overlap for variable var_e5h
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_10fh
// WARNING: [rz-ghidra] Detected overlap for variable var_10dh
// WARNING: [rz-ghidra] Detected overlap for variable var_10bh
// WARNING: [rz-ghidra] Detected overlap for variable var_109h
// WARNING: [rz-ghidra] Detected overlap for variable var_f3h
// WARNING: [rz-ghidra] Detected overlap for variable var_f1h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f7h
// WARNING: [rz-ghidra] Detected overlap for variable var_f5h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.180100c60(int64_t arg1, int64_t arg2, int64_t arg_60h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
                  int64_t arg_88h, int64_t arg_90h)
{
    int32_t *piVar1;
    uint8_t *puVar2;
    undefined4 *puVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    bool bVar9;
    char cVar10;
    uint8_t uVar11;
    uint32_t uVar12;
    undefined4 uVar13;
    uint32_t uVar14;
    int32_t iVar15;
    int64_t iVar16;
    float *pfVar17;
    int64_t *piVar18;
    uint32_t uVar19;
    int64_t iVar21;
    uint8_t in_R8B;
    int32_t iVar22;
    char in_R9B;
    int64_t iVar23;
    uint64_t uVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    undefined4 uStackX_8;
    float fStackX_c;
    int64_t var_10h;
    uint8_t uStackX_18;
    char cStackX_20;
    int32_t in_stack_00000028;
    int64_t in_stack_00000030;
    undefined uStack0000000000000038;
    undefined2 uStack0000000000000039;
    undefined uStack000000000000003b;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    float var_118h;
    float var_114h;
    float var_110h;
    int64_t var_10ch;
    float var_104h;
    int64_t var_100h;
    undefined var_f8h;
    undefined2 var_f7h;
    undefined var_f5h;
    undefined var_f4h;
    undefined2 var_f3h;
    undefined var_f1h;
    int64_t var_f0h;
    float var_e8h;
    int64_t var_e4h;
    float var_dch;
    uint32_t uStack_d8;
    uint32_t uStack_d4;
    int64_t var_b8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uVar20;
    
    iVar21 = *(int64_t *)0x180781f28;
    fVar4 = *(float *)(arg1 + 0x98);
    fVar5 = *(float *)(arg1 + 0x9c);
    *(undefined *)(arg1 + 0x10e) = 0;
    *(undefined4 *)(arg1 + 0x1b0) = 1;
    if (*(char *)(arg1 + 0x10c) != '\0') {
        uVar13 = *(undefined4 *)(iVar21 + 0xde8);
        *(float *)(iVar21 + 0xde8) = fVar5;
        if ((in_R8B == 0) || (iVar16 = 0x1f0, *(char *)(iVar21 + 0x21cc) == '\0')) {
            iVar16 = 0x200;
        }
        puVar3 = (undefined4 *)(iVar16 + 0xd90 + iVar21);
        var_120h._0_4_ = (float)*puVar3;
        var_120h._4_4_ = (float)puVar3[1];
        var_118h = (float)puVar3[2];
        var_114h = (float)puVar3[3] * *(float *)(iVar21 + 0xd9c);
        uVar12 = func_0x0001800f5fa0(&var_120h);
        uVar19 = uVar12 | 0xff000000;
        if (*(char *)(arg1 + 0x108) == '\0') {
            uVar19 = uVar12;
        }
        func_0x0001800f7a00(*(undefined8 *)arg2, *(undefined8 *)(arg2 + 8), uVar19, 1, fVar4);
        *(undefined4 *)(iVar21 + 0xde8) = uVar13;
        *(undefined4 *)(arg1 + 0x1b0) = 0;
        return;
    }
    uVar19 = *(uint32_t *)(arg1 + 0x14);
    uStackX_18 = in_R8B;
    cStackX_20 = in_R9B;
    if (-1 < (char)uVar19) {
        bVar9 = false;
        if ((((*(char *)(iVar21 + 0x2400) != '\0') && (*(int32_t *)(iVar21 + 4) - *(int32_t *)(iVar21 + 0x248c) < 2)) &&
            (*(char *)(iVar21 + 0x84) != '\0')) &&
           ((cVar10 = func_0x0001800f3aa0(iVar21 + 0x2410), cVar10 != '\0' &&
            (bVar9 = false, **(int64_t **)(iVar21 + 0x2410) == arg1)))) {
            bVar9 = true;
        }
        if ((uVar19 & 0x6000000) == 0) {
            if (((uVar19 >> 0x18 & 1) == 0) || (iVar16 = 0x170, (*(uint8_t *)(arg1 + 0x495) & 1) != 0)) {
                iVar16 = 0x160;
            }
        } else {
            iVar16 = 0x180;
        }
        pfVar17 = (float *)(iVar16 + 0xd90 + *(int64_t *)0x180781f28);
        var_120h._0_4_ = *pfVar17;
        var_120h._4_4_ = pfVar17[1];
        var_118h = pfVar17[2];
        var_114h = pfVar17[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar12 = func_0x0001800f5fa0(&var_120h);
        if (*(char *)(arg1 + 0x108) == '\0') {
            uVar14 = *(uint32_t *)(iVar21 + 0x2008) & 0x40;
            if (uVar14 == 0) {
                fVar25 = 1.0;
            } else {
                fVar25 = *(float *)(iVar21 + 0x2070);
            }
            if (bVar9) {
                fVar25 = fVar25 * 0.5;
            } else if (uVar14 == 0) goto code_r0x000180100ed9;
            if (0.0 <= fVar25) {
                fVar26 = 1.0;
                if (fVar25 <= 1.0) {
                    fVar26 = fVar25;
                }
            } else {
                fVar26 = 0.0;
            }
            uVar12 = (int32_t)(fVar26 * 255.0 + 0.5) << 0x18 | uVar12 & 0xffffff;
        } else {
            uVar12 = uVar12 | 0xff000000;
            if (bVar9) {
                *(float *)(*(int64_t *)(arg1 + 0x48) + 0xa0) = *(float *)(*(int64_t *)(arg1 + 0x48) + 0xa0) * 0.5;
            }
        }
code_r0x000180100ed9:
        if ((*(uint8_t *)(arg1 + 0x495) & 1) != 0) {
            *(uint32_t *)(*(int64_t *)(arg1 + 0x4c0) + 0x90) = uVar12;
        }
        if (((uVar19 >> 0x17 & 1) == 0) && ((uVar12 & 0xff000000) != 0)) {
            var_120h._0_4_ = *(float *)(arg1 + 0x60) + 0.0;
            var_118h = *(float *)(arg1 + 0x60) + *(float *)(arg1 + 0x68);
            var_120h._4_4_ = *(float *)(arg1 + 100) + *(float *)(arg1 + 0xa0);
            var_114h = *(float *)(arg1 + 100) + *(float *)(arg1 + 0x6c);
            if ((*(uint8_t *)(arg1 + 0x495) & 1) == 0) {
                iVar16 = *(int64_t *)(arg1 + 800);
                uVar13 = 0xc0;
                if ((uVar19 & 1) != 0) {
                    uVar13 = 0xf0;
                }
                iVar23 = iVar16 + 0x88;
            } else {
                iVar16 = *(int64_t *)(*(int64_t *)(arg1 + 0x4c0) + 0x98);
                var_110h = *(float *)(iVar16 + 0x60);
                var_10ch._0_4_ = *(float *)(iVar16 + 100);
                var_10ch._4_4_ = var_110h + *(float *)(iVar16 + 0x68);
                var_104h = (float)var_10ch + *(float *)(iVar16 + 0x6c);
                iVar16 = *(int64_t *)(iVar16 + 800);
                iVar23 = iVar16 + 0x88;
                func_0x000180127010(iVar23, iVar16, 0);
                uVar13 = func_0x000180130fb0(&var_120h, &var_110h);
            }
            func_0x000180126550(iVar16, &var_120h, &var_118h, uVar12, fVar4, uVar13);
            if ((*(uint8_t *)(arg1 + 0x495) & 1) != 0) {
                func_0x000180127010(iVar23, iVar16, 1);
            }
        }
    }
    uVar11 = *(uint8_t *)(arg1 + 0x495);
    if ((uVar11 & 1) != 0) {
        puVar2 = (uint8_t *)(*(int64_t *)(arg1 + 0x4c0) + 0xdc);
        *puVar2 = *puVar2 | 4;
        uVar11 = *(uint8_t *)(arg1 + 0x495);
    }
    if (((uVar19 & 1) == 0) && ((uVar11 & 1) == 0)) {
        pfVar17 = (float *)(*(int64_t *)0x180781f28 + 0xd90 + ((uint64_t)uStackX_18 + 0x1e) * 0x10);
        var_120h._0_4_ = *pfVar17;
        var_120h._4_4_ = pfVar17[1];
        var_118h = pfVar17[2];
        var_114h = pfVar17[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar14 = func_0x0001800f5fa0(&var_120h);
        uVar12 = uVar14 | 0xff000000;
        if (*(char *)(arg1 + 0x108) == '\0') {
            uVar12 = uVar14;
        }
        func_0x000180126550(*(undefined8 *)(arg1 + 800), arg2, arg2 + 8, uVar12, fVar4, 0x30);
    }
    if ((uVar19 >> 10 & 1) != 0) {
        fVar25 = *(float *)(arg1 + 0x60);
        fVar26 = *(float *)(arg1 + 100);
        fVar28 = fVar26 + *(float *)(arg1 + 0xa0);
        fVar29 = fVar25 + *(float *)(arg1 + 0x70);
        fVar27 = fVar25 + *(float *)(arg1 + 0x68);
        var_120h._4_4_ = fVar28;
        if (fVar28 <= fVar26) {
            var_120h._4_4_ = fVar26;
        }
        if (fVar27 <= fVar29) {
            fVar29 = fVar27;
        }
        fVar26 = fVar26 + *(float *)(arg1 + 0x6c);
        fVar28 = fVar28 + *(float *)(arg1 + 0xa4);
        if (fVar26 <= fVar28) {
            fVar28 = fVar26;
        }
        fVar26 = fVar4;
        if ((uVar19 & 1) == 0) {
            fVar26 = 0.0;
        }
        var_110h = *(float *)(*(int64_t *)0x180781f28 + 4000);
        var_10ch._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xfa4);
        var_10ch._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xfa8);
        var_104h = *(float *)(*(int64_t *)0x180781f28 + 0xfac) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        var_120h._0_4_ = fVar25;
        var_118h = fVar29;
        var_114h = fVar28;
        uVar13 = func_0x0001800f5fa0(&var_110h);
        func_0x000180126550(*(undefined8 *)(arg1 + 800), &var_120h, &var_118h, uVar13, fVar26, 0x30);
        fVar26 = *(float *)(iVar21 + 0xde8);
        if ((0.0 < fVar26) && (fVar28 < *(float *)(arg1 + 0x6c) + *(float *)(arg1 + 100))) {
            var_110h = *(float *)(*(int64_t *)0x180781f28 + 0xf20);
            var_10ch._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xf24);
            var_10ch._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xf28);
            uStackX_8 = fVar29 - fVar5 * 0.5;
            var_120h._0_4_ = fVar5 * 0.5 + fVar25;
            var_104h = *(float *)(*(int64_t *)0x180781f28 + 0xf2c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            fStackX_c = fVar28 - 0.0;
            var_120h._4_4_ = fVar28 + 0.0;
            uVar13 = func_0x0001800f5fa0(&var_110h);
            func_0x000180126300(*(undefined8 *)(arg1 + 800), &var_120h, &uStackX_8, uVar13, fVar26);
        }
    }
    uVar20 = 0;
    if ((*(uint8_t *)(arg1 + 0x495) & 1) == 0) goto code_r0x0001801014aa;
    iVar16 = *(int64_t *)(arg1 + 0x4c0);
    if (((*(uint32_t *)(iVar16 + 0x10) >> 0xd & 1) == 0) || ((*(uint32_t *)(iVar16 + 0x10) >> 0xc & 1) != 0))
    goto code_r0x0001801014aa;
    fVar25 = *(float *)(iVar16 + 0x48);
    fVar26 = *(float *)(iVar16 + 0x4c);
    fVar28 = (float)(int32_t)(*(float *)(iVar21 + 0x12f8) * 0.7);
    var_dch = (float)(int32_t)(*(float *)(iVar21 + 0x12f8) * 0.55);
    var_e4h._4_4_ = fVar25 + var_dch;
    var_dch = fVar26 + var_dch;
    var_e8h = fVar25;
    var_e4h._0_4_ = fVar26;
    iVar15 = func_0x0001800f5a90(0x180644598, 0, 
                                 *(undefined4 *)
                                  (*(int64_t *)(arg1 + 0x150) + -4 + (int64_t)*(int32_t *)(arg1 + 0x148) * 4));
    iVar21 = *(int64_t *)0x180781f28;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == iVar15) {
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = iVar15;
    }
    if (*(int32_t *)(iVar21 + 0x1684) == iVar15) {
        *(undefined *)(iVar21 + 0x168d) = 1;
    }
    cVar10 = func_0x000180139d40(&var_e8h, iVar15, &uStackX_8, &var_128h, 0x800);
    if (cVar10 == '\0') {
        if ((char)var_128h != '\0') {
            if ((*(char *)(*(int64_t *)0x180781f28 + 0x120) != '\0') &&
               (*(float *)(*(int64_t *)0x180781f28 + 0xa4) * *(float *)(*(int64_t *)0x180781f28 + 0xa4) <=
                *(float *)(*(int64_t *)0x180781f28 + 0xbfc))) {
                func_0x0001800faaf0(arg1, iVar16, 1);
            }
            goto code_r0x000180101384;
        }
code_r0x000180101399:
        if (((*(uint8_t *)(iVar16 + 0xdc) & 2) != 0) && ((char)uStackX_8 == '\0')) goto code_r0x0001801013a6;
        iVar21 = (uint64_t)((char)uStackX_8 != '\0') + 0x15;
    } else {
        *(uint8_t *)(iVar16 + 0xdd) = *(uint8_t *)(iVar16 + 0xdd) | 4;
code_r0x000180101384:
        if (((char)var_128h == '\0') || ((char)uStackX_8 == '\0')) goto code_r0x000180101399;
code_r0x0001801013a6:
        iVar21 = 0x17;
    }
    puVar3 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar21 + 0x14) * 0x10);
    var_120h._0_4_ = (float)*puVar3;
    var_120h._4_4_ = (float)puVar3[1];
    var_118h = (float)puVar3[2];
    var_114h = (float)puVar3[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar12 = func_0x0001800f5fa0(&var_120h);
    var_110h = fVar25 + 0.0;
    var_120h._0_4_ = fVar25 + fVar28;
    var_10ch._0_4_ = fVar26 + fVar28;
    var_120h._4_4_ = fVar26 + 0.0;
    if ((uVar12 & 0xff000000) != 0) {
        iVar21 = *(int64_t *)(arg1 + 800);
        iVar15 = *(int32_t *)(iVar21 + 0x54);
        if (*(int32_t *)(iVar21 + 0x50) == iVar15) {
            iVar22 = *(int32_t *)(iVar21 + 0x50) + 1;
            if (iVar15 == 0) {
                iVar15 = 8;
            } else {
                iVar15 = iVar15 / 2 + iVar15;
            }
            if (iVar22 < iVar15) {
                iVar22 = iVar15;
            }
            func_0x00018011f4f0(iVar21 + 0x50, iVar22);
        }
        iVar15 = *(int32_t *)(iVar21 + 0x50);
        iVar16 = *(int64_t *)(iVar21 + 0x58);
        *(float *)(iVar16 + (int64_t)iVar15 * 8) = fVar25;
        *(float *)(iVar16 + 4 + (int64_t)iVar15 * 8) = fVar26;
        *(int32_t *)(iVar21 + 0x50) = *(int32_t *)(iVar21 + 0x50) + 1;
        func_0x0001800f3b50(iVar21, &var_120h);
        func_0x0001800f3b50(iVar21, &var_110h);
        func_0x0001800f3bc0(iVar21, uVar12);
    }
code_r0x0001801014aa:
    if (*(char *)(arg1 + 0x104) != '\0') {
        func_0x00018013b430(0);
    }
    if (*(char *)(arg1 + 0x105) != '\0') {
        func_0x00018013b430(1);
    }
    fVar25 = _uStack0000000000000038;
    if (cStackX_20 != '\0') {
        if (((uVar19 & 2) == 0) && (var_f0h._0_4_ = 0, uVar24 = uVar20, 0 < in_stack_00000028)) {
            do {
                uStack_d4 = *(uint32_t *)(in_stack_00000030 + uVar24 * 4);
                uVar19 = (uint32_t)uVar20;
                if ((uStack_d4 & 0xff000000) != 0) {
                    fVar26 = *(float *)(arg1 + 0x60);
                    fVar28 = *(float *)(arg1 + 100);
                    iVar21 = *(int64_t *)(arg1 + 800);
                    uStack_d8 = (uint32_t)uVar20 & 1;
                    fVar26 = ((fVar26 + *(float *)(arg1 + 0x68)) - fVar26) * *(float *)(uVar24 * 0x18 + 0x1806185c0) +
                             fVar26;
                    fVar28 = ((fVar28 + *(float *)(arg1 + 0x6c)) - fVar28) * *(float *)(uVar24 * 0x18 + 0x1806185c4) +
                             fVar28;
                    fVar29 = (float)(int32_t)(fVar5 * 0.5 + 0.5);
                    uStackX_8._0_1_ = SUB41(fVar29, 0);
                    uStackX_8._1_2_ = (undefined2)((uint32_t)fVar29 >> 8);
                    uStackX_8._3_1_ = (undefined)((uint32_t)fVar29 >> 0x18);
                    if ((uVar20 & 1) == 0) {
                        var_100h._0_1_ = uStack0000000000000038;
                        var_100h._1_2_ = uStack0000000000000039;
                        var_100h._3_1_ = uStack000000000000003b;
                        var_100h._4_1_ = (char)uStackX_8;
                        var_100h._5_2_ = uStackX_8._1_2_;
                        var_100h._7_1_ = uStackX_8._3_1_;
                        fVar27 = fVar25;
                    } else {
                        var_f4h = uStack0000000000000038;
                        var_f3h = uStack0000000000000039;
                        var_f1h = uStack000000000000003b;
                        var_f8h = (char)uStackX_8;
                        var_f7h = uStackX_8._1_2_;
                        var_f5h = uStackX_8._3_1_;
                        fVar27 = fVar29;
                    }
                    fVar6 = *(float *)(uVar24 * 0x18 + 0x1806185c8);
                    piVar1 = (int32_t *)(iVar21 + 0x50);
                    iVar15 = *(int32_t *)(iVar21 + 0x54);
                    pfVar17 = (float *)((int64_t)&var_100h + 4);
                    if ((uVar20 & 1) != 0) {
                        pfVar17 = (float *)&var_f4h;
                    }
                    fVar7 = *pfVar17;
                    fVar8 = *(float *)(uVar24 * 0x18 + 0x1806185cc);
                    uStackX_8 = fVar29;
                    if (*piVar1 == iVar15) {
                        iVar22 = *piVar1 + 1;
                        if (iVar15 == 0) {
                            iVar15 = 8;
                        } else {
                            iVar15 = iVar15 / 2 + iVar15;
                        }
                        if (iVar22 < iVar15) {
                            iVar22 = iVar15;
                        }
                        func_0x00018011f4f0(piVar1, iVar22);
                    }
                    iVar15 = *piVar1;
                    iVar21 = *(int64_t *)(iVar21 + 0x58);
                    *(float *)(iVar21 + (int64_t)iVar15 * 8) = fVar27 * fVar6 + fVar26;
                    *(float *)(iVar21 + 4 + (int64_t)iVar15 * 8) = fVar7 * fVar8 + fVar28;
                    *piVar1 = *piVar1 + 1;
                    iVar21 = *(int64_t *)(arg1 + 800);
                    if (uStack_d8 == 0) {
                        var_e4h._0_4_ = _uStack0000000000000038;
                        var_e8h = fVar29;
                        fVar27 = fVar29;
                    } else {
                        var_110h = _uStack0000000000000038;
                        var_10ch._0_4_ = fVar29;
                        fVar27 = fVar25;
                    }
                    fVar6 = *(float *)(uVar24 * 0x18 + 0x1806185c8);
                    piVar1 = (int32_t *)(iVar21 + 0x50);
                    iVar15 = *(int32_t *)(iVar21 + 0x54);
                    piVar18 = &var_e4h;
                    if (uStack_d8 != 0) {
                        piVar18 = &var_10ch;
                    }
                    fVar7 = *(float *)piVar18;
                    fVar8 = *(float *)(uVar24 * 0x18 + 0x1806185cc);
                    if (*piVar1 == iVar15) {
                        iVar22 = *piVar1 + 1;
                        if (iVar15 == 0) {
                            iVar15 = 8;
                        } else {
                            iVar15 = iVar15 / 2 + iVar15;
                        }
                        if (iVar22 < iVar15) {
                            iVar22 = iVar15;
                        }
                        func_0x00018011f4f0(piVar1, iVar22);
                    }
                    iVar15 = *piVar1;
                    iVar21 = *(int64_t *)(iVar21 + 0x58);
                    *(float *)(iVar21 + (int64_t)iVar15 * 8) = fVar27 * fVar6 + fVar26;
                    *(float *)(iVar21 + 4 + (int64_t)iVar15 * 8) = fVar7 * fVar8 + fVar28;
                    *piVar1 = *piVar1 + 1;
                    var_120h._0_4_ = (fVar29 + fVar4) * *(float *)(uVar24 * 0x18 + 0x1806185c8) + fVar26;
                    var_120h._4_4_ = (fVar29 + fVar4) * *(float *)(uVar24 * 0x18 + 0x1806185cc) + fVar28;
                    if (0.5 <= fVar4) {
                        func_0x0001801257a0(*(int64_t *)(arg1 + 800), &var_120h);
                    } else {
                        func_0x00018011f490(*(int64_t *)(arg1 + 800) + 0x50);
                    }
                    func_0x0001800f3bc0(*(undefined8 *)(arg1 + 800), uStack_d4);
                    uVar19 = (uint32_t)var_f0h;
                }
                var_f0h._0_4_ = uVar19 + 1;
                uVar20 = (uint64_t)(uint32_t)var_f0h;
                uVar24 = uVar24 + 1;
            } while ((int32_t)(uint32_t)var_f0h < in_stack_00000028);
        }
        if (*(int64_t *)(arg1 + 0x4c8) == 0) {
            fcn.180100a00(arg1);
        }
    }
    *(undefined4 *)(arg1 + 0x1b0) = 0;
    return;
}

// ============================================================
// Function: FUN_180101980
// Address: 0x180101980
// Size: 99 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180101980(int64_t arg1)
{
    int64_t *piVar1;
    int64_t arg1_00;
    int64_t *piVar2;
    int64_t var_8h;
    
    *(undefined *)(arg1 + 0x109) = 1;
    piVar2 = *(int64_t **)(arg1 + 0x1f8);
    piVar1 = piVar2 + *(int32_t *)(arg1 + 0x1f0);
    for (; piVar2 != piVar1; piVar2 = piVar2 + 1) {
        arg1_00 = *piVar2;
        if (*(char *)(arg1_00 + 0x111) == '\0') {
            *(undefined *)(arg1_00 + 0x10f) = 1;
            *(undefined *)(arg1_00 + 0x109) = 1;
            fcn.180101980(arg1_00);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801019f0
// Address: 0x1801019f0
// Size: 16935 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_270h
// WARNING: Variable defined which should be unmapped: var_260h
// WARNING: Variable defined which should be unmapped: var_258h
// WARNING: Variable defined which should be unmapped: var_250h
// WARNING: Variable defined which should be unmapped: var_ch
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Type propagation algorithm not settling
// WARNING: [rz-ghidra] Detected overlap for variable var_27ch
// WARNING: [rz-ghidra] Detected overlap for variable var_286h
// WARNING: [rz-ghidra] Detected overlap for variable var_284h
// WARNING: [rz-ghidra] Detected overlap for variable var_278h
// WARNING: [rz-ghidra] Detected overlap for variable var_288h
// WARNING: [rz-ghidra] Detected overlap for variable var_287h
// WARNING: [rz-ghidra] Detected overlap for variable arg_74h
// WARNING: [rz-ghidra] Detected overlap for variable arg_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_285h
// WARNING: [rz-ghidra] Detected overlap for variable var_274h
// WARNING: [rz-ghidra] Detected overlap for variable var_24ch
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Removing arg arg_94h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable arg_61h
// WARNING: [rz-ghidra] Detected overlap for variable arg_63h
// WARNING: [rz-ghidra] Detected overlap for variable arg_91h
// WARNING: [rz-ghidra] Detected overlap for variable var_ffh
// WARNING: [rz-ghidra] Detected overlap for variable arg_93h
// WARNING: [rz-ghidra] Detected overlap for variable var_fdh
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_fbh
// WARNING: [rz-ghidra] Detected overlap for variable var_f9h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e3h
// WARNING: [rz-ghidra] Detected overlap for variable var_e1h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e7h
// WARNING: [rz-ghidra] Detected overlap for variable var_e5h
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_10fh
// WARNING: [rz-ghidra] Detected overlap for variable var_10dh
// WARNING: [rz-ghidra] Detected overlap for variable var_10bh
// WARNING: [rz-ghidra] Detected overlap for variable var_109h
// WARNING: [rz-ghidra] Detected overlap for variable var_f3h
// WARNING: [rz-ghidra] Detected overlap for variable var_f1h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f7h
// WARNING: [rz-ghidra] Detected overlap for variable var_f5h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h

void fcn.1801019f0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h,
                  undefined8 placeholder_17, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h,
                  int64_t arg_b8h, int64_t arg_c0h, int64_t arg_c8h, int64_t arg_d0h, undefined8 placeholder_26,
                  int64_t arg_e0h)
{
    undefined (*pauVar1) [16];
    int16_t *piVar2;
    int32_t **ppiVar3;
    undefined4 uVar4;
    char cVar5;
    code *pcVar6;
    undefined4 uVar7;
    bool bVar8;
    bool bVar9;
    bool bVar10;
    bool bVar11;
    int64_t iVar12;
    uint8_t uVar13;
    char cVar14;
    char cVar15;
    char cVar16;
    uint8_t uVar17;
    int32_t iVar18;
    int32_t iVar19;
    undefined4 uVar20;
    uint32_t uVar21;
    uint32_t uVar22;
    int64_t *piVar23;
    int64_t *piVar24;
    int64_t iVar25;
    undefined8 uVar26;
    int64_t iVar27;
    int64_t **ppiVar28;
    float *pfVar29;
    uint32_t *puVar30;
    uint32_t uVar31;
    int64_t iVar32;
    int32_t **ppiVar33;
    undefined *puVar34;
    undefined2 uVar35;
    uint32_t uVar36;
    uint64_t uVar37;
    undefined2 *puVar38;
    undefined8 *puVar39;
    int64_t iVar40;
    char *pcVar41;
    int32_t iVar42;
    undefined4 *puVar43;
    uint32_t uVar44;
    uint8_t *puVar45;
    undefined8 *puVar46;
    uint32_t uVar47;
    uint64_t uVar48;
    uint64_t uVar49;
    int32_t *piVar50;
    int64_t iVar51;
    undefined uVar52;
    float fVar53;
    float fVar54;
    undefined4 uVar55;
    float fVar56;
    float fVar57;
    float fVar58;
    undefined8 extraout_XMM0_Qa;
    undefined8 extraout_XMM0_Qa_00;
    undefined auVar59 [16];
    float fVar60;
    float fVar61;
    float fVar62;
    float fVar63;
    float fVar64;
    float fVar65;
    int64_t var_ch;
    int64_t var_14h;
    undefined auStackY_2c8 [32];
    int64_t var_2a8h;
    int64_t var_2a0h;
    int64_t var_298h;
    char var_288h;
    char var_287h;
    char var_286h;
    char var_285h;
    char var_284h;
    int64_t var_280h;
    undefined4 var_278h;
    char var_274h;
    int64_t var_270h;
    int64_t var_268h;
    int64_t var_260h;
    int64_t var_258h;
    int64_t var_250h;
    int64_t in_stack_fffffffffffffdb8;
    uint8_t *puVar66;
    undefined4 uStack_238;
    undefined4 uStack_234;
    int64_t *piStack_230;
    float fStack_228;
    float fStack_224;
    float fStack_220;
    float fStack_21c;
    float fStack_218;
    float fStack_214;
    float fStack_210;
    float fStack_20c;
    int64_t iStack_208;
    undefined8 uStack_200;
    float fStack_1f8;
    float fStack_1f4;
    float fStack_1f0;
    float fStack_1ec;
    int64_t *piStack_1e8;
    float fStack_1e0;
    float fStack_1dc;
    int64_t *piStack_1d8;
    float fStack_1d0;
    float fStack_1cc;
    float fStack_1c8;
    undefined4 uStack_1c4;
    float fStack_1c0;
    float fStack_1bc;
    float fStack_1b8;
    float fStack_1b4;
    float fStack_1b0;
    float fStack_1ac;
    float fStack_1a8;
    float fStack_1a4;
    float fStack_1a0;
    float fStack_19c;
    float fStack_198;
    float fStack_194;
    float fStack_190;
    float fStack_18c;
    float fStack_188;
    float fStack_184;
    float fStack_180;
    float fStack_17c;
    float fStack_178;
    float fStack_174;
    float fStack_170;
    float fStack_16c;
    float fStack_168;
    float fStack_164;
    float fStack_160;
    float fStack_15c;
    float fStack_158;
    undefined4 uStack_154;
    float fStack_150;
    float fStack_14c;
    int64_t *piStack_148;
    undefined4 uStack_140;
    undefined4 uStack_13c;
    undefined4 uStack_138;
    float fStack_134;
    undefined auStack_130 [8];
    undefined auStack_128 [8];
    undefined auStack_120 [8];
    undefined auStack_118 [8];
    undefined auStack_110 [8];
    undefined auStack_108 [8];
    undefined auStack_100 [8];
    undefined auStack_f8 [16];
    uint64_t uStack_e8;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar12 = *(int64_t *)0x180781f28;
    uStack_e8 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_2c8;
    uVar48 = arg3 & 0xffffffff;
    piVar23 = (int64_t *)func_0x0001800fecc0();
    var_270h._0_4_ = CONCAT31(var_270h._1_3_, piVar23 == (int64_t *)0x0);
    uVar21 = (uint32_t)arg3;
    iVar25 = iVar12;
    piStack_230 = piVar23;
    if (piVar23 == (int64_t *)0x0) {
        var_258h = (int64_t)piVar23;
        piVar24 = (int64_t *)func_0x00018046d050(0x4d8);
        piStack_1d8 = &var_260h;
        piVar23 = (int64_t *)0x0;
        uStack_200 = piVar24;
        piStack_1e8 = piVar24;
        if (piVar24 != (int64_t *)0x0) {
            pauVar1 = (undefined (*) [16])(piVar24 + 4);
            auVar59 = ZEXT816(0);
            *pauVar1 = auVar59;
            *(undefined (*) [16])(piVar24 + 6) = auVar59;
            piVar24[8] = 0;
            *(undefined4 *)((int64_t)piVar24 + 0x24) = 0xffffffff;
            *(undefined *)((int64_t)piVar24 + 0x3d) = 1;
            *(undefined8 *)((int64_t)piVar24 + 0x54) = 0;
            piVar24[0xc] = 0;
            piVar24[0xd] = 0;
            piVar24[0xe] = 0;
            piVar24[0xf] = 0;
            piVar24[0x10] = 0;
            piVar24[0x11] = 0;
            piVar24[0x12] = 0;
            *(undefined8 *)((int64_t)piVar24 + 0xd4) = 0;
            *(undefined8 *)((int64_t)piVar24 + 0xdc) = 0;
            *(undefined8 *)((int64_t)piVar24 + 0xe4) = 0;
            *(undefined8 *)((int64_t)piVar24 + 0xec) = 0;
            *(undefined8 *)((int64_t)piVar24 + 0xf4) = 0;
            *(undefined8 *)((int64_t)piVar24 + 0xfc) = 0;
            piVar24[0x27] = 0;
            piVar24[0x28] = 0;
            piVar24[0x29] = 0;
            piVar24[0x2a] = 0;
            piVar24[0x2b] = 0;
            piVar24[0x2c] = 0;
            piVar24[0x2d] = 0;
            piVar24[0x2e] = 0;
            piVar24[0x2f] = 0;
            piVar24[0x30] = 0;
            piVar24[0x31] = 0;
            *(undefined8 *)((int64_t)piVar24 + 0x19c) = 0;
            *(undefined8 *)((int64_t)piVar24 + 0x1a4) = 0;
            *(undefined4 *)((int64_t)piVar24 + 0x1ac) = 0;
            *(undefined8 *)((int64_t)piVar24 + 0x1bc) = 0;
            *(undefined (*) [16])((int64_t)piVar24 + 0x1c4) = auVar59;
            *(undefined (*) [16])(piVar24 + 0x3a) = auVar59;
            piVar24[0x3e] = 0;
            piVar24[0x3f] = 0;
            *(undefined8 *)((int64_t)piVar24 + 0x22c) = 0;
            *(undefined8 *)((int64_t)piVar24 + 0x234) = 0;
            piVar24[0x49] = 0;
            piVar24[0x4a] = 0;
            piVar24[0x4b] = 0;
            piVar24[0x4c] = 0;
            piVar24[0x4d] = 0;
            piVar24[0x4e] = 0;
            piVar24[0x4f] = 0;
            piVar24[0x50] = 0;
            piVar24[0x51] = 0;
            piVar24[0x52] = 0;
            piVar24[0x53] = 0;
            piVar24[0x54] = 0;
            piVar24[0x55] = 0;
            piVar24[0x56] = 0;
            piVar24[0x57] = 0;
            piVar24[0x58] = 0;
            piVar24[0x59] = 0;
            piVar24[0x5a] = 0;
            piVar24[0x5b] = 0;
            piVar24[0x5e] = 0;
            piVar24[0x5f] = 0;
            piVar24[0x60] = 0;
            piVar24[0x61] = 0;
            func_0x000180123d20(piVar24 + 0x65, 0);
            func_0x0001804986e0(piVar24 + 1, 0, 0x4d0);
            *piVar24 = iVar12;
            iVar25 = func_0x000180498cd0(arg1);
            uVar26 = func_0x00018046d050(iVar25 + 1);
            puVar66 = (uint8_t *)arg1;
            iVar25 = func_0x000180498030(uVar26, arg1, iVar25 + 1);
            piVar24[1] = iVar25;
            iVar18 = func_0x000180498cd0(arg1);
            *(int32_t *)(piVar24 + 0x18) = iVar18 + 1;
            uVar37 = 0xffffffff;
            uVar22 = 0xffffffff;
            uVar17 = *(uint8_t *)arg1;
            while (uVar17 != 0) {
                puVar45 = (uint8_t *)(arg1 + 1);
                if (((uVar17 == 0x23) && (*puVar45 == 0x23)) && (*(uint8_t *)(arg1 + 2) == 0x23)) {
                    uVar37 = 0xffffffff;
                    puVar45 = (uint8_t *)(arg1 + 3);
                } else {
                    uVar37 = (uint64_t)
                             ((uint32_t)(uVar37 >> 8) ^
                             *(uint32_t *)((uVar37 & 0xff ^ (uint64_t)uVar17) * 4 + 0x180618620));
                }
                uVar22 = (uint32_t)uVar37;
                arg1 = (int64_t)puVar45;
                uVar17 = *puVar45;
            }
            *(uint32_t *)(piVar24 + 2) = ~uVar22;
            iVar18 = *(int32_t *)((int64_t)piVar24 + 0x14c);
            if (*(int32_t *)(piVar24 + 0x29) == iVar18) {
                iVar42 = *(int32_t *)(piVar24 + 0x29) + 1;
                if (iVar18 == 0) {
                    iVar19 = 8;
                } else {
                    iVar19 = iVar18 / 2 + iVar18;
                }
                if (iVar42 < iVar19) {
                    iVar42 = iVar19;
                }
                if (iVar18 < iVar42) {
                    iVar25 = func_0x00018046d050((int64_t)iVar42 << 2);
                    if (piVar24[0x2a] != 0) {
                        func_0x000180498030(iVar25, piVar24[0x2a], (int64_t)*(int32_t *)(piVar24 + 0x29) << 2);
                        func_0x000180460d90(piVar24[0x2a]);
                    }
                    piVar24[0x2a] = iVar25;
                    *(int32_t *)((int64_t)piVar24 + 0x14c) = iVar42;
                }
            }
            *(undefined4 *)(piVar24[0x2a] + (int64_t)*(int32_t *)(piVar24 + 0x29) * 4) = *(undefined4 *)(piVar24 + 2);
            *(int32_t *)(piVar24 + 0x29) = *(int32_t *)(piVar24 + 0x29) + 1;
            *(undefined4 *)((int64_t)piVar24 + 0x5c) = 0xffffffff;
            *(undefined4 *)((int64_t)piVar24 + 0x54) = 0x7f7fffff;
            *(undefined4 *)(piVar24 + 0xb) = 0x7f7fffff;
            iVar18 = *(int32_t *)(piVar24 + 0x29);
            uVar20 = func_0x0001800f5a90(0x180644434, 0, *(undefined4 *)(piVar24[0x2a] + -4 + (int64_t)iVar18 * 4));
            *(undefined4 *)((int64_t)piVar24 + 0xc4) = uVar20;
            uVar20 = func_0x0001800f5a90(0x18064443c, 0, *(undefined4 *)(piVar24[0x2a] + -4 + (int64_t)iVar18 * 4));
            *(undefined4 *)(piVar24 + 0x19) = uVar20;
            *(undefined4 *)((int64_t)piVar24 + 0xe4) = 0x7f7fffff;
            *(undefined4 *)(piVar24 + 0x1d) = 0x7f7fffff;
            *(undefined4 *)((int64_t)piVar24 + 0xec) = 0x3f000000;
            *(undefined4 *)(piVar24 + 0x1e) = 0x3f000000;
            *(undefined4 *)((int64_t)piVar24 + 0x124) = 0xffffffff;
            *(undefined2 *)(piVar24 + 0x25) = 0xffff;
            *(undefined4 *)((int64_t)piVar24 + 0x131) = 0;
            *(undefined4 *)(piVar24 + 0x28) = 0x7f7fffff;
            *(undefined4 *)((int64_t)piVar24 + 0x144) = 0x7f7fffff;
            *(undefined4 *)(piVar24 + 0x27) = 0x7f7fffff;
            *(undefined4 *)((int64_t)piVar24 + 0x13c) = 0x7f7fffff;
            piVar24[0x5c] = -1;
            *(undefined4 *)(piVar24 + 0x5d) = 0xbf800000;
            *(undefined8 *)((int64_t)piVar24 + 0x314) = 0x3f800000;
            *(undefined4 *)(piVar24 + 0x62) = 0x3f800000;
            *(undefined4 *)((int64_t)piVar24 + 0x31c) = 0xffffffff;
            *(undefined2 *)((int64_t)piVar24 + 0x496) = 0xffff;
            piVar24[100] = (int64_t)(piVar24 + 0x65);
            piVar24[0x80] = piVar24[1];
            func_0x000180123ed0(piVar24[100], *piVar24 + 0x1310);
            *(undefined4 *)(piVar24 + 0x90) = 0x7f7fffff;
            *(undefined4 *)((int64_t)piVar24 + 0x484) = 0x7f7fffff;
            piVar24[0x8f] = piVar24[0x90];
            piVar23 = piVar24;
            arg1 = (int64_t)puVar66;
            if (pauVar1 != (undefined (*) [16])0x0) {
                *pauVar1 = ZEXT816(0);
                *(undefined (*) [16])(piVar24 + 6) = ZEXT816(0);
                piVar24[8] = 0;
                *(undefined4 *)((int64_t)piVar24 + 0x24) = 0xffffffff;
                *(undefined *)((int64_t)piVar24 + 0x3d) = 1;
            }
        }
        *(uint32_t *)((int64_t)piVar23 + 0x14) = uVar21;
        func_0x0001800f6220(iVar12 + 0x15c0, *(undefined4 *)(piVar23 + 2), piVar23);
        if ((uVar21 >> 8 & 1) == 0) {
            if (*(int32_t *)((int64_t)piVar23 + 0x31c) == -1) {
                iVar25 = func_0x000180112cf0(*(undefined4 *)(piVar23 + 2), 0);
            } else {
                iVar25 = (int64_t)*(int32_t *)((int64_t)piVar23 + 0x31c) +
                         *(int64_t *)(*(int64_t *)0x180781f28 + 0x2958);
            }
            if (iVar25 != 0) {
                *(int32_t *)((int64_t)piVar23 + 0x31c) = (int32_t)iVar25 - *(int32_t *)(iVar12 + 0x2958);
            }
        }
        func_0x0001800fee20(piVar23);
        piVar50 = (int32_t *)(iVar12 + 0x1580);
        iVar18 = *piVar50;
        iVar42 = *(int32_t *)(iVar12 + 0x1584);
        iVar19 = 8;
        if ((uVar21 >> 0xd & 1) == 0) {
            if (iVar18 == iVar42) {
                if (iVar42 != 0) {
                    iVar19 = iVar42 / 2 + iVar42;
                }
                iVar42 = iVar18 + 1;
                if (iVar18 + 1 < iVar19) {
                    iVar42 = iVar19;
                }
code_r0x00018010203a:
                func_0x00018011f4f0(piVar50, iVar42);
            }
code_r0x000180102042:
            *(int64_t **)(*(int64_t *)(iVar12 + 0x1588) + (int64_t)*piVar50 * 8) = piVar23;
        } else {
            if (iVar18 == 0) {
                if (iVar42 == 0) {
                    iVar42 = 8;
                    goto code_r0x00018010203a;
                }
                goto code_r0x000180102042;
            }
            if (iVar18 == iVar42) {
                if (iVar42 != 0) {
                    iVar19 = iVar42 / 2 + iVar42;
                }
                iVar42 = iVar18 + 1;
                if (iVar18 + 1 < iVar19) {
                    iVar42 = iVar19;
                }
                func_0x00018011f4f0(piVar50, iVar42);
            }
            if (0 < (int64_t)*piVar50) {
                func_0x000180498030(*(int64_t *)(iVar12 + 0x1588) + 8, *(int64_t *)(iVar12 + 0x1588), 
                                    (int64_t)*piVar50 * 8);
            }
            **(int64_t ***)(iVar12 + 0x1588) = piVar23;
        }
        *piVar50 = *piVar50 + 1;
        iVar25 = *(int64_t *)0x180781f28;
    }
    var_258h = (int64_t)piVar23;
    if (*(int32_t *)(iVar12 + 0x15d8) == *(int32_t *)(piVar23 + 2)) {
        pcVar6 = (code *)swi(3);
        (*pcVar6)();
        return;
    }
    if ((uVar21 & 0x30200) == 0x30200) {
        uVar48 = (uint64_t)(uVar21 | 6);
    }
    iVar18 = *(int32_t *)(iVar12 + 4);
    var_280h._4_4_ = *(int32_t *)(piVar23 + 0x5c);
    if ((*(int32_t *)(iVar12 + 0x15b0) == 0) && (*(char *)(iVar12 + 2) != '\0')) {
        uVar52 = 1;
    } else {
        uVar52 = 0;
    }
    *(undefined *)((int64_t)piVar23 + 0x112) = uVar52;
    var_286h = *(int32_t *)(piVar23 + 0x5c) < iVar18 + -1;
    uVar21 = (uint32_t)uVar48;
    if ((uVar48 & 0x4000000) != 0) {
        iVar32 = (int64_t)*(int32_t *)(iVar12 + 0x2130) * 0x38;
        var_286h = (piVar23 != *(int64_t **)(iVar32 + *(int64_t *)(iVar12 + 0x2128) + 8) ||
                   *(int32_t *)(piVar23 + 0x1a) != *(int32_t *)(iVar32 + *(int64_t *)(iVar12 + 0x2128))) ||
                   (bool)var_286h;
    }
    var_284h = *(char *)(piVar23 + 0x22);
    var_280h._0_4_ = iVar18;
    if (var_280h._4_4_ == iVar18) {
        uVar48 = (uint64_t)*(uint32_t *)((int64_t)piVar23 + 0x14);
    } else {
        if (((uVar21 >> 0x18 & 1) == 0) || (((uVar48 & 0x4000000) != 0 && ((uVar21 >> 0x1c & 1) == 0)))) {
            cVar14 = '\0';
        } else {
            cVar14 = '\x01';
        }
        if ((piStack_230 == (int64_t *)0x0) || (cVar14 != *(char *)((int64_t)piVar23 + 0x113))) {
            if (cVar14 == '\0') {
                piVar50 = (int32_t *)(iVar25 + 0x1590);
                iVar32 = iVar25;
                if (*piVar50 == *(int32_t *)(iVar25 + 0x1594)) {
                    func_0x00018011f4f0(piVar50);
                    iVar32 = *(int64_t *)0x180781f28;
                }
                *(int64_t **)(*(int64_t *)(iVar25 + 0x1598) + (int64_t)*piVar50 * 8) = piVar23;
                *piVar50 = *piVar50 + 1;
                *(int16_t *)(piVar23 + 0x24) = (int16_t)*piVar50 + -1;
                iVar25 = iVar32;
                iVar18 = (int32_t)var_280h;
            } else if (((piStack_230 != (int64_t *)0x0) && (cVar14 != *(char *)((int64_t)piVar23 + 0x113))) &&
                      (cVar14 != '\0')) {
                iVar19 = *(int16_t *)(piVar23 + 0x24) + 1;
                iVar42 = *(int32_t *)(iVar25 + 0x1590);
                if (iVar19 < iVar42) {
                    do {
                        piVar2 = (int16_t *)(*(int64_t *)(*(int64_t *)(iVar25 + 0x1598) + (int64_t)iVar19 * 8) + 0x120);
                        *piVar2 = *piVar2 + -1;
                        iVar19 = iVar19 + 1;
                        iVar42 = *(int32_t *)(iVar25 + 0x1590);
                    } while (iVar19 < iVar42);
                }
                iVar32 = *(int64_t *)(iVar25 + 0x1598) + (int64_t)*(int16_t *)(piVar23 + 0x24) * 8;
                func_0x000180498030(iVar32, iVar32 + 8, 
                                    ((int64_t)iVar42 - (int64_t)*(int16_t *)(piVar23 + 0x24)) * 8 + -8);
                *(int32_t *)(iVar25 + 0x1590) = *(int32_t *)(iVar25 + 0x1590) + -1;
                *(undefined2 *)(piVar23 + 0x24) = 0xffff;
            }
        }
        *(char *)((int64_t)piVar23 + 0x113) = cVar14;
        *(char *)(piVar23 + 0x22) = var_286h;
        if (var_286h != '\0') {
            *(uint8_t *)((int64_t)piVar23 + 0x131) = *(uint8_t *)((int64_t)piVar23 + 0x131) | 8;
            *(uint8_t *)((int64_t)piVar23 + 0x132) = *(uint8_t *)((int64_t)piVar23 + 0x132) | 8;
            *(uint8_t *)((int64_t)piVar23 + 0x133) = *(uint8_t *)((int64_t)piVar23 + 0x133) | 8;
            *(uint8_t *)((int64_t)piVar23 + 0x134) = *(uint8_t *)((int64_t)piVar23 + 0x134) | 8;
        }
        *(undefined4 *)(piVar23 + 3) = *(undefined4 *)((int64_t)piVar23 + 0x14);
        *(uint32_t *)((int64_t)piVar23 + 0x14) = uVar21;
        if ((*(uint32_t *)(iVar12 + 0x2008) & 0x200) == 0) {
            uVar20 = 0;
        } else {
            uVar20 = *(undefined4 *)(iVar12 + 0x2048);
        }
        *(undefined4 *)((int64_t)piVar23 + 0x1c) = uVar20;
        *(int32_t *)(piVar23 + 0x5c) = iVar18;
        *(float *)(piVar23 + 0x5d) = (float)*(double *)(iVar12 + 0x18);
        *(undefined2 *)((int64_t)piVar23 + 0x11c) = 0;
        uVar35 = *(undefined2 *)(iVar12 + 0x15d0);
        *(int32_t *)(iVar12 + 0x15d0) = *(int32_t *)(iVar12 + 0x15d0) + 1;
        *(undefined2 *)((int64_t)piVar23 + 0x11e) = uVar35;
    }
    iVar42 = var_280h._4_4_;
    if ((*(uint32_t *)(iVar12 + 0x2008) & 0x1000) != 0) {
        func_0x00018011c070(piVar23, *(undefined4 *)(iVar12 + 0x2078), *(undefined4 *)(iVar12 + 0x2018));
        iVar25 = *(int64_t *)0x180781f28;
    }
    if (iVar42 != iVar18) {
        if ((*(int32_t *)(piVar23 + 0x9a) == 0) && (piVar23[0x98] == 0)) {
            cVar14 = '\0';
            if (((*(char *)(iVar25 + 0x83) == '\0') && (*(char *)((int64_t)piVar23 + 0x3c) == '\0')) ||
               (((*(uint32_t *)((int64_t)piVar23 + 0x14) & 0x1080001) != 0 ||
                (*(char *)((int64_t)piVar23 + 0x112) != '\0')))) goto code_r0x000180102361;
            uVar17 = *(uint8_t *)((int64_t)piVar23 + 0x495);
            *(uint8_t *)((int64_t)piVar23 + 0x495) = uVar17 & 0xf8;
        } else {
            cVar14 = '\x01';
code_r0x000180102361:
            uVar17 = *(uint8_t *)((int64_t)piVar23 + 0x495);
            *(uint8_t *)((int64_t)piVar23 + 0x495) = uVar17 & 0xf8;
            if (cVar14 == '\0') goto code_r0x0001801027ae;
        }
        if ((*(char *)((int64_t)piVar23 + 0x112) == '\0') || (*(char *)((int64_t)piVar23 + 0x10a) != '\0')) {
            if (((*(char *)(iVar25 + 0x83) == '\0') && (*(char *)((int64_t)piVar23 + 0x3c) == '\0')) ||
               (((*(uint32_t *)((int64_t)piVar23 + 0x14) & 0x1080001) != 0 ||
                (*(char *)((int64_t)piVar23 + 0x112) != '\0')))) {
                if ((((*(uint8_t *)(iVar25 + 0x2008) & 1) == 0) ||
                    (((*(uint32_t *)(iVar25 + 0x200c) & (int32_t)*(char *)((int64_t)piVar23 + 0x131)) == 0 ||
                     (*(char *)(iVar25 + 0x204c) == '\0')))) &&
                   ((*(uint32_t *)((int64_t)piVar23 + 0x14) & 0x80000) == 0)) goto code_r0x0001801023e5;
                func_0x000180115d50(cVar14, piVar23, 1);
                iVar18 = (int32_t)var_280h;
            } else {
                if (*(int32_t *)(piVar23 + 0x9a) == 0) {
                    uVar20 = func_0x0001801151e0(iVar25);
                    *(undefined4 *)(piVar23 + 0x9a) = uVar20;
                }
code_r0x0001801023e5:
                iVar32 = piVar23[0x98];
                iVar18 = *(int32_t *)(piVar23 + 0x9a);
                iVar51 = iVar25;
                if ((iVar18 != 0) && (iVar32 == 0)) {
                    iVar32 = func_0x0001800f60f0(iVar25 + 0x28e8, iVar18);
                    if (iVar32 == 0) {
                        iVar32 = func_0x000180115230(iVar25, iVar18);
                        *(uint32_t *)(iVar32 + 0xd8) = *(uint32_t *)(iVar32 + 0xd8) & 0xfffffe92;
                        *(uint32_t *)(iVar32 + 0xd8) = *(uint32_t *)(iVar32 + 0xd8) | 0x92;
                        *(undefined4 *)(iVar32 + 0xbc) = *(undefined4 *)(iVar25 + 4);
                    } else if (*(int64_t *)(iVar32 + 0x20) != 0) {
                        func_0x000180115d50(extraout_XMM0_Qa, piVar23, 1);
                        iVar18 = (int32_t)var_280h;
                        iVar42 = var_280h._4_4_;
                        goto code_r0x000180102724;
                    }
                    iVar51 = iVar32;
                    if ((*(uint8_t *)(iVar32 + 0xdc) & 1) == 0) {
                        do {
                            iVar40 = *(int64_t *)(iVar51 + 0x18);
                            if (iVar40 == 0) break;
                            iVar51 = iVar40;
                        } while ((*(uint8_t *)(iVar40 + 0xdc) & 1) == 0);
                        iVar27 = *(int64_t *)(iVar51 + 0x18);
                        iVar40 = iVar51;
                        while (iVar27 != 0) {
                            iVar40 = *(int64_t *)(iVar40 + 0x18);
                            iVar27 = *(int64_t *)(iVar40 + 0x18);
                        }
                        func_0x000180116c40();
                        func_0x00018011b1e0(iVar51, *(undefined8 *)(iVar51 + 0x48), *(undefined8 *)(iVar51 + 0x50), 
                                            iVar32);
                    }
                    uVar13 = *(uint8_t *)(iVar32 + 0xdc);
                    func_0x0001801162d0(iVar32, piVar23, 1);
                    *(uint8_t *)(iVar32 + 0xdc) =
                         (*(uint8_t *)(iVar32 + 0xdc) ^ uVar13) & 1 ^ *(uint8_t *)(iVar32 + 0xdc);
                    iVar51 = *(int64_t *)0x180781f28;
                }
                if (*(int32_t *)(iVar32 + 0xbc) < *(int32_t *)(iVar25 + 4)) {
                    iVar25 = *(int64_t *)(iVar32 + 0x18);
                    while (iVar25 != 0) {
                        iVar32 = *(int64_t *)(iVar32 + 0x18);
                        iVar25 = *(int64_t *)(iVar32 + 0x18);
                    }
                    if (*(int32_t *)(iVar32 + 0xbc) < *(int32_t *)(iVar25 + 4)) {
                        func_0x000180115d50();
                        iVar18 = (int32_t)var_280h;
                        iVar42 = var_280h._4_4_;
                    } else {
                        *(uint8_t *)((int64_t)piVar23 + 0x495) = *(uint8_t *)((int64_t)piVar23 + 0x495) | 1;
                        iVar18 = (int32_t)var_280h;
                        iVar42 = var_280h._4_4_;
                    }
                } else {
                    uVar26 = func_0x00018011cdb0(piVar23);
                    iVar42 = var_280h._4_4_;
                    iVar18 = (int32_t)var_280h;
                    if (*(int64_t *)(iVar32 + 0x98) == 0) {
                        if (*(int32_t *)(iVar32 + 0x14) == 2) {
                            *(uint8_t *)((int64_t)piVar23 + 0x495) = *(uint8_t *)((int64_t)piVar23 + 0x495) | 1;
                        }
                        if ((1 < *(int32_t *)(iVar32 + 0x30)) && (*(char *)(piVar23 + 0x22) != '\0'))
                        goto code_r0x000180102391;
                    } else {
                        *(undefined4 *)(iVar32 + 0x14) = 3;
                        if (((*(uint8_t *)(iVar32 + 0x10) & 1) == 0) &&
                           (*(int16_t *)((int64_t)piVar23 + 0x11e) < *(int16_t *)(*(int64_t *)(iVar32 + 0x98) + 0x11e)))
                        {
                            func_0x000180115d50(uVar26, piVar23, 1);
                            iVar18 = (int32_t)var_280h;
                            iVar42 = var_280h._4_4_;
                        } else {
                            *(uint32_t *)(iVar51 + 0x2008) = *(uint32_t *)(iVar51 + 0x2008) | 1;
                            *(undefined8 *)(iVar51 + 0x201c) = *(undefined8 *)(iVar32 + 0x48);
                            uVar48 = 0;
                            *(undefined8 *)(iVar51 + 0x2024) = 0;
                            *(undefined4 *)(iVar51 + 0x200c) = 1;
                            *(undefined *)(iVar51 + 0x204c) = 1;
                            *(uint32_t *)(iVar51 + 0x2008) = *(uint32_t *)(iVar51 + 0x2008) | 2;
                            *(undefined8 *)(iVar51 + 0x202c) = *(undefined8 *)(iVar32 + 0x50);
                            *(undefined4 *)(iVar51 + 0x2010) = 1;
                            *(undefined *)(iVar25 + 0x204c) = 0;
                            uVar13 = *(uint8_t *)((int64_t)piVar23 + 0x495) & 0xfb;
                            *(uint8_t *)((int64_t)piVar23 + 0x495) = uVar13 | 3;
                            if ((*(uint8_t *)(iVar32 + 0x10) & 1) == 0) {
                                if (*(int64_t **)(iVar32 + 0xa0) == piVar23) {
                                    *(uint8_t *)((int64_t)piVar23 + 0x495) = uVar13 | 7;
                                }
                                *(uint32_t *)((int64_t)piVar23 + 0x14) =
                                     *(uint32_t *)((int64_t)piVar23 + 0x14) | 0x1000002;
                                *(uint32_t *)((int64_t)piVar23 + 0x1c) = *(uint32_t *)((int64_t)piVar23 + 0x1c) | 2;
                                if (((*(uint32_t *)(iVar32 + 0x10) >> 0xd & 1) == 0) &&
                                   ((*(uint32_t *)(iVar32 + 0x10) >> 0xc & 1) == 0)) {
                                    uVar21 = *(uint32_t *)((int64_t)piVar23 + 0x14) & 0xfffffffe;
                                } else {
                                    uVar21 = *(uint32_t *)((int64_t)piVar23 + 0x14) | 1;
                                }
                                *(uint32_t *)((int64_t)piVar23 + 0x14) = uVar21;
                                if ((*(int64_t *)(iVar32 + 0x40) != 0) && (*(char *)((int64_t)piVar23 + 0x10a) != '\0'))
                                {
                                    iVar25 = *(int64_t *)(piVar23[0x98] + 0x40);
                                    if ((iVar25 != 0) &&
                                       ((*(int32_t *)(piVar23 + 0x19) != 0 && (0 < *(int32_t *)(iVar25 + 8))))) {
                                        do {
                                            if (*(int32_t *)(*(int64_t *)(iVar25 + 0x10) + uVar48 * 0x38) ==
                                                *(int32_t *)(piVar23 + 0x19)) {
                                                uVar35 = (undefined2)((uVar48 * 0x38) / 0x38);
                                                goto code_r0x0001801026dc;
                                            }
                                            uVar21 = (int32_t)uVar48 + 1;
                                            uVar48 = (uint64_t)uVar21;
                                        } while ((int32_t)uVar21 < *(int32_t *)(iVar25 + 8));
                                    }
                                    uVar35 = 0xffff;
code_r0x0001801026dc:
                                    *(undefined2 *)((int64_t)piVar23 + 0x496) = uVar35;
                                }
                                uVar20 = func_0x0001800f5a90(piVar23[1], 0, 
                                                             *(undefined4 *)
                                                              (*(int64_t *)(*(int64_t *)(piVar23[0x98] + 0x98) + 0x150)
                                                               + -4 + (int64_t)*(int32_t *)
                                                                                (*(int64_t *)(piVar23[0x98] + 0x98) +
                                                                                0x148) * 4));
                                *(undefined4 *)((int64_t)piVar23 + 0xcc) = uVar20;
                                piVar23 = (int64_t *)var_258h;
                                iVar18 = (int32_t)var_280h;
                                iVar42 = var_280h._4_4_;
                            }
                        }
                    }
                }
            }
        } else {
code_r0x000180102391:
            *(undefined *)((int64_t)piVar23 + 0x111) = 1;
            *(char *)((int64_t)piVar23 + 299) = (*(char *)((int64_t)piVar23 + 0x109) == '\0') + '\x01';
        }
code_r0x000180102724:
        uVar48 = (uint64_t)*(uint32_t *)((int64_t)piVar23 + 0x14);
        if ((*(uint8_t *)((int64_t)piVar23 + 0x495) & 1) != 0) {
            *(uint32_t *)(iVar12 + 0x2008) = *(uint32_t *)(iVar12 + 0x2008) & 0xffffffef;
        }
        if (((((*(uint8_t *)((int64_t)piVar23 + 0x495) & 4) != 0) && ((uVar17 & 6) == 2)) &&
            (*(char *)(piVar23 + 0x22) == '\0')) && (var_284h == '\0')) {
            *(undefined *)(piVar23 + 0x22) = 1;
            *(uint8_t *)((int64_t)piVar23 + 0x131) = *(uint8_t *)((int64_t)piVar23 + 0x131) | 8;
            *(uint8_t *)((int64_t)piVar23 + 0x132) = *(uint8_t *)((int64_t)piVar23 + 0x132) | 8;
            *(uint8_t *)((int64_t)piVar23 + 0x133) = *(uint8_t *)((int64_t)piVar23 + 0x133) | 8;
            *(uint8_t *)((int64_t)piVar23 + 0x134) = *(uint8_t *)((int64_t)piVar23 + 0x134) | 8;
        }
    }
code_r0x0001801027ae:
    piVar50 = (int32_t *)(iVar12 + 0x15b0);
    uVar21 = (uint32_t)uVar48;
    if (((*(uint8_t *)((int64_t)piVar23 + 0x495) & 1) == 0) ||
       (iVar25 = *(int64_t *)(piVar23[0x98] + 0x98), iVar25 == 0)) {
        if (*piVar50 == 0) {
            iVar25 = 0;
        } else {
            iVar25 = *(int64_t *)((int64_t)*piVar50 * 0x78 + -0x78 + *(int64_t *)(iVar12 + 0x15b8));
        }
    }
    if (iVar42 == iVar18) {
        var_268h = piVar23[0x81];
    } else {
        var_268h = 0;
        if ((uVar48 & 0x7000000) != 0) {
            var_268h = iVar25;
        }
    }
    iStack_208 = iVar25;
    if (*(int32_t *)(piVar23 + 0x29) == 0) {
        func_0x00018011f5e0(piVar23 + 0x29, piVar23 + 2);
    }
    *(int64_t **)(iVar12 + 0x15e0) = piVar23;
    func_0x00018011f370(piVar50, *piVar50 + 1);
    iVar51 = (int64_t)*piVar50 * 0x78;
    iVar32 = *(int64_t *)(iVar12 + 0x15b8);
    *(int64_t **)(iVar51 + -0x78 + iVar32) = piVar23;
    uVar20 = *(undefined4 *)(iVar12 + 0x1fbc);
    uVar55 = *(undefined4 *)(iVar12 + 0x1fc0);
    uVar4 = *(undefined4 *)(iVar12 + 0x1fc4);
    puVar43 = (undefined4 *)(iVar51 + -0x70 + iVar32);
    *puVar43 = *(undefined4 *)(iVar12 + 0x1fb8);
    puVar43[1] = uVar20;
    puVar43[2] = uVar55;
    puVar43[3] = uVar4;
    uVar20 = *(undefined4 *)(iVar12 + 0x1fcc);
    uVar55 = *(undefined4 *)(iVar12 + 0x1fd0);
    uVar4 = *(undefined4 *)(iVar12 + 0x1fd4);
    puVar43 = (undefined4 *)(iVar51 + -0x60 + iVar32);
    *puVar43 = *(undefined4 *)(iVar12 + 0x1fc8);
    puVar43[1] = uVar20;
    puVar43[2] = uVar55;
    puVar43[3] = uVar4;
    uVar20 = *(undefined4 *)(iVar12 + 0x1fdc);
    uVar55 = *(undefined4 *)(iVar12 + 0x1fe0);
    uVar4 = *(undefined4 *)(iVar12 + 0x1fe4);
    puVar43 = (undefined4 *)(iVar51 + -0x50 + iVar32);
    *puVar43 = *(undefined4 *)(iVar12 + 0x1fd8);
    puVar43[1] = uVar20;
    puVar43[2] = uVar55;
    puVar43[3] = uVar4;
    uVar20 = *(undefined4 *)(iVar12 + 0x1fec);
    uVar55 = *(undefined4 *)(iVar12 + 0x1ff0);
    uVar4 = *(undefined4 *)(iVar12 + 0x1ff4);
    puVar43 = (undefined4 *)(iVar51 + -0x40 + iVar32);
    *puVar43 = *(undefined4 *)(iVar12 + 0x1fe8);
    puVar43[1] = uVar20;
    puVar43[2] = uVar55;
    puVar43[3] = uVar4;
    uVar20 = *(undefined4 *)(iVar12 + 0x1ffc);
    uVar55 = *(undefined4 *)(iVar12 + 0x2000);
    uVar4 = *(undefined4 *)(iVar12 + 0x2004);
    puVar43 = (undefined4 *)(iVar51 + -0x30 + iVar32);
    *puVar43 = *(undefined4 *)(iVar12 + 0x1ff8);
    puVar43[1] = uVar20;
    puVar43[2] = uVar55;
    puVar43[3] = uVar4;
    if (((uVar48 & 0x2000000) == 0) || ((*(uint8_t *)(iVar12 + 0x1f78) & 0x40) == 0)) {
        uVar52 = 0;
    } else {
        uVar52 = 1;
    }
    *(undefined *)(iVar51 + -10 + iVar32) = uVar52;
    *(undefined4 *)(iVar51 + -8 + iVar32) = 0;
    iVar40 = *(int64_t *)0x180781f28;
    puVar38 = (undefined2 *)(iVar32 + -0x20 + iVar51);
    *puVar38 = *(undefined2 *)(*(int64_t *)0x180781f28 + 0x15b0);
    puVar38[1] = *(undefined2 *)(*(int64_t *)(iVar40 + 0x15e0) + 0x148);
    puVar38[2] = *(undefined2 *)(*(int64_t *)(iVar40 + 0x15e0) + 0x1e0);
    puVar38[3] = *(undefined2 *)(iVar40 + 0x20c0);
    puVar38[4] = *(undefined2 *)(iVar40 + 0x20d0);
    puVar38[5] = *(undefined2 *)(iVar40 + 0x20e0);
    puVar38[6] = *(undefined2 *)(iVar40 + 0x20f0);
    puVar38[7] = *(undefined2 *)(iVar40 + 0x2110);
    puVar38[8] = *(undefined2 *)(iVar40 + 0x2100);
    puVar38[9] = *(undefined2 *)(iVar40 + 0x2130);
    puVar38[10] = *(undefined2 *)(iVar40 + 0x281c);
    *(undefined2 **)(iVar12 + 0x2a78) = puVar38;
    var_278h = uVar21 & 0x10000000;
    if ((uVar48 & 0x10000000) != 0) {
        *(int32_t *)(iVar12 + 0x278c) = *(int32_t *)(iVar12 + 0x278c) + 1;
    }
    uVar20 = 0x3f800000;
    if (var_280h._4_4_ != (int32_t)var_280h) {
        func_0x0001801018b0(piVar23, uVar48, var_268h);
        piVar23[0x82] = iVar25;
        iVar27 = 0;
        if ((int64_t *)piVar23[0x83] != piVar23) {
            iVar27 = iVar25;
        }
        piVar23[0x88] = iVar27;
        if (((iVar27 == 0) && (iVar25 = piVar23[0x98], iVar25 != 0)) && ((*(uint32_t *)(iVar25 + 0x10) & 0x40000) != 0))
        {
            piVar23[0x88] = *(int64_t *)(iVar25 + 0x98);
        }
        if (*(int32_t *)(piVar23 + 5) != 0) {
            iVar25 = func_0x0001800f60f0(iVar40 + 0x15c0);
            piVar23[0x88] = iVar25;
        }
        if (var_268h == 0) {
            fVar53 = 1.0;
        } else {
            fVar53 = *(float *)(var_268h + 0x314) * *(float *)(var_268h + 0x310);
        }
        *(float *)((int64_t)piVar23 + 0x314) = fVar53;
    }
    func_0x000180106750();
    *(undefined4 *)(piVar23 + 0x91) = *(undefined4 *)(iVar12 + 0x1f74);
    if ((uVar21 >> 0x1a & 1) != 0) {
        puVar43 = (undefined4 *)((int64_t)*(int32_t *)(iVar12 + 0x2130) * 0x38 + *(int64_t *)(iVar12 + 0x2128));
        *(int64_t **)(puVar43 + 2) = piVar23;
        puVar43[6] = *(undefined4 *)(iStack_208 + 0x1b0);
        func_0x00018011f0c0();
        *(undefined4 *)(piVar23 + 0x1a) = *puVar43;
    }
    var_284h = '\0';
    var_288h = '\0';
    var_287h = '\0';
    if ((*(uint8_t *)(iVar12 + 0x2008) & 1) != 0) {
        var_284h = (*(uint32_t *)(iVar12 + 0x200c) & (int32_t)*(char *)((int64_t)piVar23 + 0x131)) != 0;
        if (((*(uint32_t *)(iVar12 + 0x200c) & (int32_t)*(char *)((int64_t)piVar23 + 0x131)) == 0) ||
           (*(float *)(iVar12 + 0x2028) * *(float *)(iVar12 + 0x2028) +
            *(float *)(iVar12 + 0x2024) * *(float *)(iVar12 + 0x2024) <= 1e-05)) {
            func_0x000180106470(piVar23);
        } else {
            piVar23[0x27] = *(int64_t *)(iVar12 + 0x201c);
            piVar23[0x28] = *(int64_t *)(iVar12 + 0x2024);
            *(uint32_t *)(piVar23 + 0x26) =
                 (*(uint32_t *)(piVar23 + 0x26) >> 8 & 0xf1) << 8 | *(uint32_t *)(piVar23 + 0x26) & 0xffff00ff;
        }
    }
    if ((*(uint8_t *)(iVar12 + 0x2008) & 2) != 0) {
        uVar22 = (int32_t)*(char *)((int64_t)piVar23 + 0x132) & *(uint32_t *)(iVar12 + 0x2010);
        if ((uVar22 == 0) || (*(float *)(iVar12 + 0x202c) <= 0.0)) {
            var_288h = '\0';
            if (uVar22 != 0) goto code_r0x000180102b7c;
code_r0x000180102b9b:
            var_287h = '\0';
        } else {
            var_288h = '\x01';
code_r0x000180102b7c:
            if (*(float *)(iVar12 + 0x2030) <= 0.0) goto code_r0x000180102b9b;
            var_287h = '\x01';
        }
        if (((*(uint8_t *)((int64_t)piVar23 + 0x1c) & 4) != 0) &&
           (((int32_t)*(char *)((int64_t)piVar23 + 0x132) & 4U) == 0)) {
            *(undefined4 *)(iVar12 + 0x202c) = *(undefined4 *)(piVar23 + 0xe);
        }
        if (((*(uint8_t *)((int64_t)piVar23 + 0x1c) & 8) != 0) && ((*(uint8_t *)((int64_t)piVar23 + 0x132) & 4) == 0)) {
            *(undefined4 *)(iVar12 + 0x2030) = *(undefined4 *)((int64_t)piVar23 + 0x74);
        }
        func_0x0001801065c0(piVar23, iVar12 + 0x202c, *(uint32_t *)(iVar12 + 0x2010));
    }
    if ((*(uint8_t *)(iVar12 + 0x2008) & 0x80) != 0) {
        if (0.0 <= *(float *)(iVar12 + 0x203c)) {
            *(float *)((int64_t)piVar23 + 0xe4) = *(float *)(iVar12 + 0x203c);
            *(undefined4 *)((int64_t)piVar23 + 0xec) = 0;
        }
        if (0.0 <= *(float *)(iVar12 + 0x2040)) {
            *(float *)(piVar23 + 0x1d) = *(float *)(iVar12 + 0x2040);
            *(undefined4 *)(piVar23 + 0x1e) = 0;
        }
    }
    if ((*(uint8_t *)(iVar12 + 0x2008) & 4) == 0) {
        if (var_280h._4_4_ != (int32_t)var_280h) {
            piVar23[0x11] = 0;
        }
    } else {
        piVar23[0x11] = *(int64_t *)(iVar12 + 0x2034);
    }
    if ((*(uint32_t *)(iVar12 + 0x2008) & 0x2000) != 0) {
        uVar55 = *(undefined4 *)(iVar12 + 0x2084);
        uVar4 = *(undefined4 *)(iVar12 + 0x2088);
        uVar7 = *(undefined4 *)(iVar12 + 0x208c);
        *(undefined4 *)(piVar23 + 4) = *(undefined4 *)(iVar12 + 0x2080);
        *(undefined4 *)((int64_t)piVar23 + 0x24) = uVar55;
        *(undefined4 *)(piVar23 + 5) = uVar4;
        *(undefined4 *)((int64_t)piVar23 + 0x2c) = uVar7;
        uVar55 = *(undefined4 *)(iVar12 + 0x2094);
        uVar4 = *(undefined4 *)(iVar12 + 0x2098);
        uVar7 = *(undefined4 *)(iVar12 + 0x209c);
        *(undefined4 *)(piVar23 + 6) = *(undefined4 *)(iVar12 + 0x2090);
        *(undefined4 *)((int64_t)piVar23 + 0x34) = uVar55;
        *(undefined4 *)(piVar23 + 7) = uVar4;
        *(undefined4 *)((int64_t)piVar23 + 0x3c) = uVar7;
        piVar23[8] = *(int64_t *)(iVar12 + 0x20a0);
    }
    if (((*(uint8_t *)(iVar12 + 0x2008) & 8) != 0) &&
       ((*(uint32_t *)(iVar12 + 0x2014) == 0 ||
        ((*(uint32_t *)(iVar12 + 0x2014) & (int32_t)*(char *)((int64_t)piVar23 + 0x133)) != 0)))) {
        cVar14 = *(char *)(iVar12 + 0x204d);
        *(uint8_t *)((int64_t)piVar23 + 0x133) = *(uint8_t *)((int64_t)piVar23 + 0x133) & 0xf1;
        if (*(char *)((int64_t)piVar23 + 0x10d) != '\0') {
            *(uint8_t *)((int64_t)piVar23 + 0x10c) = *(uint8_t *)((int64_t)piVar23 + 0x10c) ^ 1;
        }
        *(bool *)((int64_t)piVar23 + 0x10d) = *(char *)((int64_t)piVar23 + 0x10c) != cVar14;
    }
    if ((*(uint8_t *)(iVar12 + 0x2008) & 0x20) != 0) {
        func_0x00018010e050(piVar23);
    }
    if (*(char *)(piVar23 + 0x22) != '\0') {
        *(uint8_t *)((int64_t)piVar23 + 0x131) = *(uint8_t *)((int64_t)piVar23 + 0x131) & 0xf7;
        *(uint8_t *)((int64_t)piVar23 + 0x132) = *(uint8_t *)((int64_t)piVar23 + 0x132) & 0xf7;
        *(uint8_t *)((int64_t)piVar23 + 0x133) = *(uint8_t *)((int64_t)piVar23 + 0x133) & 0xf7;
        *(uint8_t *)((int64_t)piVar23 + 0x134) = *(uint8_t *)((int64_t)piVar23 + 0x134) & 0xf7;
    }
    iVar25 = *(int64_t *)0x180781f28;
    *(undefined *)((int64_t)piVar23 + 0x10f) = 0;
    if (((((*(uint32_t *)(iVar25 + 0x2008) & 0x400) != 0) &&
         (uVar22 = *(uint32_t *)(iVar25 + 0x20b0), (uVar22 & 1) != 0)) && (*(char *)(piVar23 + 0x22) == '\0')) &&
       (*(char *)((int64_t)piVar23 + 0x111) == '\0')) {
        if (((uVar22 & 2) != 0) && (*(int64_t *)(iVar25 + 0x15e8) != 0)) {
            piVar24 = *(int64_t **)(*(int64_t *)(iVar25 + 0x15e8) + 0x418);
            if (((int64_t *)piVar23[0x83] == piVar24) || ((int64_t *)piVar24[0x83] == piVar23))
            goto code_r0x000180102df3;
            do {
                if (piVar24 == piVar23) goto code_r0x000180102df3;
                piVar24 = (int64_t *)piVar24[0x82];
            } while (piVar24 != (int64_t *)0x0);
        }
        if (((uVar22 & 4) != 0) && (*(int64_t *)(iVar25 + 0x21d8) != 0)) {
            piVar24 = *(int64_t **)(*(int64_t *)(iVar25 + 0x21d8) + 0x418);
            if (((int64_t *)piVar23[0x83] == piVar24) || ((int64_t *)piVar24[0x83] == piVar23))
            goto code_r0x000180102df3;
            do {
                if (piVar24 == piVar23) goto code_r0x000180102df3;
                piVar24 = (int64_t *)piVar24[0x82];
            } while (piVar24 != (int64_t *)0x0);
        }
        piVar23[100] = 0;
        *(undefined *)((int64_t)piVar23 + 0x10f) = 1;
    }
code_r0x000180102df3:
    iVar40 = iVar25;
    if ((*(char *)(iVar51 + -10 + iVar32) != '\0') && ((int64_t *)piVar23[0x83] == piVar23)) {
        *(undefined4 *)((int64_t)*(int32_t *)(iVar25 + 0x15b0) * 0x78 + -8 + *(int64_t *)(iVar25 + 0x15b8)) =
             *(undefined4 *)(iVar25 + 0xd9c);
        *(undefined4 *)(iVar25 + 0xd9c) = *(undefined4 *)(iVar25 + 0x2818);
        *(uint32_t *)(iVar25 + 0x1f78) = *(uint32_t *)(iVar25 + 0x1f78) & 0xffffffbf;
        piVar50 = (int32_t *)(iVar25 + 0x2100);
        iVar18 = *(int32_t *)(iVar25 + 0x2104);
        if (*piVar50 == iVar18) {
            iVar42 = *piVar50 + 1;
            if (iVar18 == 0) {
                iVar18 = 8;
            } else {
                iVar18 = iVar18 / 2 + iVar18;
            }
            if (iVar42 < iVar18) {
                iVar42 = iVar18;
            }
            func_0x00018011fb10(piVar50, iVar42);
            iVar40 = *(int64_t *)0x180781f28;
        }
        *(undefined4 *)(*(int64_t *)(iVar25 + 0x2108) + (int64_t)*piVar50 * 4) = *(undefined4 *)(iVar25 + 0x1f78);
        *piVar50 = *piVar50 + 1;
        *(int16_t *)(iVar25 + 0x281c) = *(int16_t *)(iVar25 + 0x281c) + 1;
    }
    iVar25 = var_258h;
    iVar42 = var_280h._4_4_;
    iVar18 = (int32_t)var_280h;
    uVar26 = 0;
    *(undefined8 *)(iVar12 + 0x15e0) = 0;
    if (var_280h._4_4_ == (int32_t)var_280h) {
        if (*(char *)((int64_t)piVar23 + 0x10f) != '\0') goto code_r0x000180105837;
code_r0x00018010583f:
        iVar25 = piVar23[9];
        if (iVar25 != 0) {
            *(undefined4 *)(iVar25 + 0x84) = *(undefined4 *)(iVar40 + 4);
        }
        if (*(int64_t *)(iVar40 + 0x2160) != iVar25) {
            if (iVar25 != 0) {
                uVar20 = *(undefined4 *)(iVar25 + 0x30);
            }
            *(undefined4 *)(iVar40 + 0x1308) = uVar20;
            *(int64_t *)(iVar40 + 0x2160) = iVar25;
            if (*(char *)(iVar40 + 0x8a) != (char)uVar26) {
                *(undefined4 *)(iVar40 + 0xd98) = uVar20;
            }
            if ((iVar25 != 0) && (*(code **)(iVar40 + 0xd20) != (code *)0x0)) {
                (**(code **)(iVar40 + 0xd20))();
                uVar26 = 0;
                iVar40 = *(int64_t *)0x180781f28;
            }
        }
        *(int64_t **)(iVar40 + 0x15e0) = piVar23;
        if (piVar23 == (int64_t *)0x0) {
            *(undefined8 *)(iVar40 + 0x2a78) = uVar26;
code_r0x0001801058fe:
            *(undefined8 *)(iVar40 + 0x24d0) = uVar26;
            if (piVar23 != (int64_t *)0x0) goto code_r0x00018010590a;
        } else {
            *(int64_t *)(iVar40 + 0x2a78) =
                 (int64_t)(*(int32_t *)(iVar40 + 0x15b0) + -1) * 0x78 + *(int64_t *)(iVar40 + 0x15b8) + 0x58;
            if (*(int32_t *)(piVar23 + 0x42) == -1) goto code_r0x0001801058fe;
            *(int64_t *)(iVar40 + 0x24d0) =
                 (int64_t)*(int32_t *)(piVar23 + 0x42) * 0x250 + *(int64_t *)(iVar40 + 0x24f8);
code_r0x00018010590a:
            if ((*(uint8_t *)(iVar40 + 0x34) & 0x10) != 0) {
                fVar53 = *(float *)(piVar23[9] + 0x18);
                if (fVar53 == 0.0) {
                    fVar53 = *(float *)(iVar40 + 0x40);
                }
                *(float *)(iVar40 + 0x1304) = fVar53;
            }
            uVar52 = *(undefined *)((int64_t)piVar23 + 0x10e);
            *(undefined *)((int64_t)piVar23 + 0x10e) = 0;
            func_0x0001801073c0();
            *(undefined *)((int64_t)piVar23 + 0x10e) = uVar52;
            if ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0) == 0) &&
               (*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x208) == 0)) {
                uVar52 = 1;
            } else {
                uVar52 = 0;
            }
            *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x1b8) = uVar52;
            uVar26 = 0;
        }
        *(int32_t *)(iVar12 + 0x2008) = (int32_t)uVar26;
        fStack_158 = *(float *)(piVar23 + 0xc);
        uStack_154 = *(undefined4 *)((int64_t)piVar23 + 100);
        fStack_150 = fStack_158 + *(float *)(piVar23 + 0xe);
        fStack_14c = *(float *)(piVar23 + 0x14) + *(float *)((int64_t)piVar23 + 100);
        func_0x0001800fa750(piVar23, &fStack_158);
        iVar25 = var_268h;
    } else {
        if (*(char *)((int64_t)piVar23 + 0x10f) != '\0') {
code_r0x000180105837:
            fcn.180101980((int64_t)piVar23);
            goto code_r0x00018010583f;
        }
        if (((uVar21 >> 0x18 & 1) == 0) || (var_285h = '\x01', (uVar48 & 0x2000000) == 0)) {
            var_285h = '\0';
        }
        var_274h = *(char *)((int64_t)piVar23 + 300);
        *(undefined *)((int64_t)piVar23 + 0x109) = 1;
        *(undefined *)((int64_t)piVar23 + 0x114) = 0;
        *(undefined4 *)(piVar23 + 0x57) = 0xff7fffff;
        *(undefined4 *)((int64_t)piVar23 + 700) = 0xff7fffff;
        *(undefined4 *)(piVar23 + 0x58) = 0x7f7fffff;
        *(undefined4 *)((int64_t)piVar23 + 0x2c4) = 0x7f7fffff;
        iVar18 = *(int32_t *)(var_258h + 0x14c);
        if (iVar18 < 1) {
            if (iVar18 == 0) {
                iVar18 = 8;
            } else {
                iVar18 = iVar18 / 2 + iVar18;
            }
            iVar42 = 1;
            if (1 < iVar18) {
                iVar42 = iVar18;
            }
            func_0x00018011fb10(var_258h + 0x148, iVar42);
        }
        *(undefined4 *)(iVar25 + 0x148) = 1;
        func_0x000180123f80(*(undefined8 *)(iVar25 + 800));
        *(undefined4 *)(iVar25 + 0x210) = 0xffffffff;
        if ((uVar21 >> 0x17 & 1) != 0) {
            func_0x000180126ad0(*(int64_t *)(iVar25 + 800) + 0x88);
            func_0x000180127010(*(int64_t *)(iVar25 + 800) + 0x88, *(int64_t *)(iVar25 + 800), 1);
        }
        if (*(char *)(iVar25 + 0x494) != '\0') {
            *(undefined *)(iVar25 + 0x494) = 0;
            func_0x00018011f8d0(*(int64_t *)(iVar25 + 800) + 0x10, *(undefined4 *)(iVar25 + 0x48c));
            func_0x00018011f6f0(*(int64_t *)(iVar25 + 800) + 0x20, *(undefined4 *)(iVar25 + 0x490));
            *(undefined8 *)(iVar25 + 0x48c) = 0;
        }
        piVar23 = piStack_230;
        cVar14 = var_286h;
        if ((((((*(int64_t *)(iVar25 + 0x48) != 0) && (*(int64_t *)(*(int64_t *)(iVar25 + 0x48) + 0x78) == iVar25)) ||
              ((*(uint8_t *)(iVar25 + 0x495) & 1) != 0)) ||
             (((*(int64_t *)(iVar12 + 0x23d0) != 0 && (*(char *)(*(int64_t *)(iVar12 + 0x23d0) + 0x10a) != '\0')) &&
              ((uVar21 >> 0x11 & 1) == 0)))) || ((var_278h != 0 || (var_286h != '\0')))) &&
           (piStack_230 != (int64_t *)0x0)) {
            uVar26 = *(undefined8 *)(iVar25 + 8);
            iVar18 = func_0x000180498f10(arg1, uVar26);
            if (iVar18 != 0) {
                iVar18 = *(int32_t *)(iVar25 + 0xc0);
                iVar32 = func_0x000180498cd0(arg1);
                uVar37 = iVar32 + 1;
                uVar49 = (int64_t)iVar18;
                if ((uint64_t)(int64_t)iVar18 < uVar37) {
                    func_0x000180460d90(uVar26);
                    uVar26 = func_0x00018046d050(uVar37);
                    uVar49 = uVar37;
                }
                uVar26 = func_0x000180498030(uVar26, arg1, uVar37);
                *(undefined8 *)(iVar25 + 8) = uVar26;
                *(int32_t *)(iVar25 + 0xc0) = (int32_t)uVar49;
                piVar23 = piStack_230;
            }
        }
        puVar46 = (undefined8 *)(iVar25 + 0x80);
        puVar39 = (undefined8 *)(iVar25 + 0x78);
        func_0x0001800ff150(iVar25);
        if ('\0' < *(char *)(iVar25 + 299)) {
            *(char *)(iVar25 + 299) = *(char *)(iVar25 + 299) + -1;
        }
        if ('\0' < *(char *)(iVar25 + 300)) {
            *(char *)(iVar25 + 300) = *(char *)(iVar25 + 300) + -1;
        }
        if ('\0' < *(char *)(iVar25 + 0x12d)) {
            *(char *)(iVar25 + 0x12d) = *(char *)(iVar25 + 0x12d) + -1;
        }
        if ((piVar23 == (int64_t *)0x0) && ((var_288h == '\0' || (var_287h == '\0')))) {
            *(undefined *)(iVar25 + 300) = 1;
        }
        if (((cVar14 != '\0') && ((uVar48 & 0x6000000) != 0)) &&
           (*(undefined *)(iVar25 + 300) = 1, (uVar48 & 0x40) != 0)) {
            if (var_288h == '\0') {
                *(undefined4 *)(iVar25 + 0x70) = 0;
                *(undefined4 *)(iVar25 + 0x68) = 0;
            }
            if (var_287h == '\0') {
                *(undefined4 *)(iVar25 + 0x74) = 0;
                *(undefined4 *)(iVar25 + 0x6c) = 0;
            }
            *puVar46 = 0;
            *puVar39 = 0;
        }
        iVar32 = *(int64_t *)0x180781f28;
        *(undefined4 *)(iVar25 + 0x5c) = 0xffffffff;
        piStack_1d8 = **(int64_t ***)(iVar32 + 0x2158);
        iVar51 = iVar25;
        if ((*(uint32_t *)(iVar32 + 0x12cc) & 0x400) == 0) {
            if ((*(char *)(iVar25 + 0x108) != '\0') && (*(int64_t *)(*(int64_t *)(iVar25 + 0x48) + 0x78) == iVar25)) {
                *(undefined8 *)(*(int64_t *)(iVar25 + 0x48) + 0x10) = 0;
            }
            *(int64_t **)(iVar25 + 0x48) = piStack_1d8;
            *(undefined4 *)(iVar25 + 0x50) = *(undefined4 *)piStack_1d8;
            *(bool *)(iVar25 + 0x108) = piStack_1d8[0xf] == iVar25;
        } else {
            uVar21 = *(uint32_t *)(iVar25 + 0x14);
            *(undefined *)(iVar25 + 0x108) = 0;
            var_278h = uVar21 & 0x6000000;
            if ((var_278h != 0) && (*(char *)(iVar25 + 0x110) != '\0')) {
                *(undefined8 *)(iVar25 + 0x48) = 0;
                *(undefined4 *)(iVar25 + 0x50) = 0;
            }
            if (((((*(uint32_t *)(iVar32 + 0x2008) & 0x800) == 0) && (*(int64_t *)(iVar25 + 0x48) == 0)) &&
                ((iVar40 = *(int64_t *)(iVar25 + 0x408), iVar40 == 0 ||
                 (((*(char *)(iVar40 + 0x112) != '\0' && (*(char *)(iVar40 + 0x10a) == '\0')) ||
                  (iVar40 = *(int64_t *)(iVar40 + 0x48), *(int64_t *)(iVar25 + 0x48) = iVar40, iVar40 == 0)))))) &&
               (*(int32_t *)(iVar25 + 0x50) != 0)) {
                iVar40 = func_0x0001801134f0();
                *(int64_t *)(iVar25 + 0x48) = iVar40;
                if (((iVar40 == 0) && (*(float *)(iVar25 + 0x54) != 3.402823e+38)) &&
                   (*(float *)(iVar25 + 0x58) != 3.402823e+38)) {
                    var_2a8h = var_2a8h & 0xffffffff00000000;
                    uVar26 = func_0x000180114730();
                    *(undefined8 *)(iVar25 + 0x48) = uVar26;
                }
            }
            if ((*(uint32_t *)(iVar32 + 0x2008) & 0x800) == 0) {
                bVar8 = false;
                if ((uVar21 & 0x11000000) == 0) {
                    if ((*(int64_t *)(iVar25 + 0x4c0) == 0) ||
                       (iVar40 = *(int64_t *)(*(int64_t *)(iVar25 + 0x4c0) + 0x98), iVar40 == 0)) {
                        if ((uVar21 >> 0x19 & 1) == 0) {
                            cVar14 = func_0x000180113530();
                            if (cVar14 == '\0') {
                                if ((((*(int64_t *)(iVar32 + 0x1600) == 0) ||
                                     (*(int64_t *)(*(int64_t *)(iVar32 + 0x1600) + 0x428) != iVar25)) ||
                                    (*(float *)(*(int64_t *)0x180781f28 + 0x118) < -256000.0)) ||
                                   (*(float *)(*(int64_t *)0x180781f28 + 0x11c) < -256000.0)) {
                                    if (((*(int64_t *)(iVar25 + 0x48) != 0) &&
                                        (iVar25 == *(int64_t *)(*(int64_t *)(iVar25 + 0x48) + 0x78))) &&
                                       ((*(int32_t *)(iVar32 + 0x1654) == 0 || (*(char *)(iVar32 + 0x1661) != '\0')))) {
                                        func_0x000180113580();
                                    }
                                } else if ((*(int64_t *)(iVar25 + 0x48) != 0) &&
                                          (*(int64_t *)(*(int64_t *)(iVar25 + 0x48) + 0x78) == iVar25))
                                goto code_r0x0001801033cd;
                            } else {
code_r0x0001801033cd:
                                var_2a8h = var_2a8h & 0xffffffff00000000;
                                uVar26 = func_0x000180114730();
                                *(undefined8 *)(iVar25 + 0x48) = uVar26;
                            }
                        } else {
                            *(undefined8 *)(iVar25 + 0x48) = *(undefined8 *)(iVar32 + 0x2168);
                        }
                    } else {
                        *(undefined8 *)(iVar25 + 0x48) = *(undefined8 *)(iVar40 + 0x48);
                    }
                } else {
                    *(undefined8 *)(iVar25 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar25 + 0x408) + 0x48);
                }
            } else {
                ppiVar33 = *(int32_t ***)(*(int64_t *)0x180781f28 + 0x2158);
                ppiVar3 = ppiVar33 + *(int32_t *)(*(int64_t *)0x180781f28 + 0x2150);
                if (ppiVar33 != ppiVar3) {
                    do {
                        piVar50 = *ppiVar33;
                        if (*piVar50 == *(int32_t *)(iVar32 + 0x2074)) {
                            *(int32_t **)(iVar25 + 0x48) = piVar50;
                            *(undefined4 *)(iVar25 + 0x50) = *(undefined4 *)(iVar32 + 0x2074);
                            if (((*(uint32_t *)(iVar25 + 0x14) & 0x800000) == 0) || (*(int64_t *)(piVar50 + 0x1e) == 0))
                            goto code_r0x0001801032e1;
                            *(int64_t *)(piVar50 + 0x1e) = iVar25;
                            *(int32_t *)(iVar25 + 0x50) = *(int32_t *)(iVar25 + 0x10);
                            **(int32_t **)(iVar25 + 0x48) = *(int32_t *)(iVar25 + 0x10);
                            bVar8 = true;
                            goto code_r0x000180103439;
                        }
                        ppiVar33 = ppiVar33 + 1;
                    } while (ppiVar33 != ppiVar3);
                }
                *(undefined8 *)(iVar25 + 0x48) = 0;
                *(undefined4 *)(iVar25 + 0x50) = *(undefined4 *)(iVar32 + 0x2074);
code_r0x0001801032e1:
                bVar8 = true;
            }
code_r0x000180103439:
            piVar23 = (int64_t *)(iVar25 + 0x48);
            if ((*piVar23 == 0) && (cVar14 = func_0x000180113580(), cVar14 == '\0')) {
                var_2a8h = var_2a8h & 0xffffffff00000000;
                iVar40 = func_0x000180114730(iVar25, *(undefined4 *)(iVar25 + 0x10), iVar25 + 0x60, iVar25 + 0x68);
                *piVar23 = iVar40;
            }
            if (!bVar8) {
                if (var_278h == 0) {
                    iVar40 = *piVar23;
                    if ((((iVar40 == 0) || (iVar25 == *(int64_t *)(iVar40 + 0x78))) ||
                        (*(int64_t *)(iVar40 + 0x78) == 0)) ||
                       (((uVar21 >> 0x18 & 1) != 0 || (*(int64_t *)(iVar25 + 0x4c0) != 0)))) {
                        if ((*(int32_t *)(iVar25 + 0x5c) < 0) && ((uVar21 >> 0x18 & 1) == 0)) {
                            *(int32_t *)(iVar25 + 0x5c) = (int32_t)*(int16_t *)(iVar40 + 0xaa);
                        }
                    } else if ((((*(uint32_t *)(iVar25 + 0x14) & 0x800000) == 0) ||
                               (*(int32_t *)(iVar32 + 4) <= *(int32_t *)(iVar40 + 0x84))) ||
                              ((*(uint8_t *)(iVar25 + 0x495) & 5) == 1)) {
                        cVar14 = func_0x000180113580(iVar25, **(undefined8 **)(*(int64_t *)0x180781f28 + 0x2158));
                        if (cVar14 == '\0') {
                            var_2a8h = CONCAT44(var_2a8h._4_4_, 0x20);
                            uVar26 = func_0x000180114730(iVar25, *(undefined4 *)(iVar25 + 0x10), iVar25 + 0x60, 
                                                         iVar25 + 0x68);
                            *(undefined8 *)(iVar25 + 0x48) = uVar26;
                        }
                    } else {
                        *(int64_t *)(iVar40 + 0x78) = iVar25;
                        **(undefined4 **)(iVar25 + 0x48) = *(undefined4 *)(iVar25 + 0x10);
                        *(undefined4 *)(*(int64_t *)(iVar25 + 0x48) + 0x8c) = 0;
                    }
                } else {
                    if ((uVar21 >> 0x19 & 1) == 0) {
                        ppiVar28 = (int64_t **)
                                   (*(int64_t *)(iVar32 + 0x2138) + 0x2c +
                                   (int64_t)(*(int32_t *)(iVar32 + 0x2130) + -1) * 0x38);
                    } else {
                        ppiVar28 = (int64_t **)(iVar32 + 0x118);
                    }
                    piVar23 = *ppiVar28;
                    if (((*(char *)(iVar32 + 0x21cc) == '\0') || (*(char *)(iVar32 + 0x21cd) == '\0')) ||
                       (*(int64_t *)(iVar32 + 0x21d8) == 0)) {
                        bVar8 = true;
                    } else {
                        bVar8 = false;
                    }
                    if ((SUB84(piVar23, 0) < -256000.0) ||
                       (uStack_200._4_4_ = (float)((uint64_t)piVar23 >> 0x20), uStack_200._4_4_ < -256000.0)) {
                        bVar9 = false;
                    } else {
                        bVar9 = true;
                    }
                    uStack_200 = piVar23;
                    if ((*(char *)(iVar25 + 0x110) == '\0') && ((uVar21 & 0x12000000) == 0)) {
code_r0x00018010350a:
                        *(int32_t *)(iVar25 + 0x5c) = (int32_t)*(int16_t *)(*(int64_t *)(iVar25 + 0x48) + 0xaa);
                        iVar51 = var_258h;
                    } else {
                        if (bVar8) {
                            if (!bVar9) goto code_r0x00018010350a;
                            piStack_148 = *ppiVar28;
                            ppiVar28 = &piStack_148;
                        } else {
                            ppiVar28 = (int64_t **)func_0x00018010ef90(auStack_130);
                        }
                        if (0 < *(int32_t *)(*(int64_t *)0x180781f28 + 0xd60)) {
                            iVar18 = 0;
                            iVar32 = *(int64_t *)(*(int64_t *)0x180781f28 + 0xd68);
                            do {
                                iVar51 = (int64_t)iVar18;
                                fVar53 = *(float *)(iVar32 + iVar51 * 0x30);
                                if (fVar53 <= *(float *)ppiVar28) {
                                    fVar62 = *(float *)(iVar32 + 4 + iVar51 * 0x30);
                                    if (((fVar62 <= *(float *)((int64_t)ppiVar28 + 4)) &&
                                        (*(float *)ppiVar28 < fVar53 + *(float *)(iVar32 + 8 + iVar51 * 0x30))) &&
                                       (*(float *)((int64_t)ppiVar28 + 4) <
                                        fVar62 + *(float *)(iVar32 + 0xc + iVar51 * 0x30))) goto code_r0x0001801035bb;
                                }
                                iVar18 = iVar18 + 1;
                            } while (iVar18 < *(int32_t *)(*(int64_t *)0x180781f28 + 0xd60));
                        }
                        iVar18 = -1;
code_r0x0001801035bb:
                        *(int32_t *)(iVar25 + 0x5c) = iVar18;
                        iVar51 = var_258h;
                    }
                }
            }
            *(bool *)(iVar25 + 0x108) = iVar25 == *(int64_t *)(*(undefined4 **)(iVar25 + 0x48) + 0x1e);
            *(undefined4 *)(iVar25 + 0x50) = **(undefined4 **)(iVar25 + 0x48);
        }
        iVar32 = *(int64_t *)0x180781f28;
        iVar25 = *(int64_t *)(iVar51 + 0x48);
        if (iVar25 != 0) {
            *(undefined4 *)(iVar25 + 0x84) = *(undefined4 *)(*(int64_t *)0x180781f28 + 4);
        }
        if (*(int64_t *)(iVar32 + 0x2160) != iVar25) {
            if (iVar25 == 0) {
                uVar20 = 0x3f800000;
            } else {
                uVar20 = *(undefined4 *)(iVar25 + 0x30);
            }
            *(undefined4 *)(iVar32 + 0x1308) = uVar20;
            *(int64_t *)(iVar32 + 0x2160) = iVar25;
            if (*(char *)(iVar32 + 0x8a) != '\0') {
                *(undefined4 *)(iVar32 + 0xd98) = uVar20;
            }
            if ((iVar25 != 0) && (*(code **)(iVar32 + 0xd20) != (code *)0x0)) {
                (**(code **)(iVar32 + 0xd20))();
            }
        }
        func_0x0001800f9e20(iVar51);
        uVar21 = *(uint32_t *)(iVar51 + 0x14);
        if (((*(uint8_t *)(iVar51 + 0x495) & 1) == 0) && ((uVar21 >> 0x18 & 1) != 0)) {
            *(undefined4 *)(iVar51 + 0x9c) = *(undefined4 *)(iVar12 + 0xdd0);
        } else {
            if (((uVar21 & 0x6000000) == 0) || ((uVar21 >> 0x1b & 1) != 0)) {
                uVar20 = *(undefined4 *)(iVar12 + 0xdb0);
            } else {
                uVar20 = *(undefined4 *)(iVar12 + 0xdd8);
            }
            *(undefined4 *)(iVar51 + 0x9c) = uVar20;
        }
        *(undefined8 *)(iVar51 + 0x90) = *(undefined8 *)(iVar12 + 0xda4);
        if (((((*(uint8_t *)(iVar51 + 0x495) & 1) == 0) && ((uVar21 & 0x5000000) == 0x1000000)) &&
            ((*(uint8_t *)(iVar51 + 0x1c) & 2) == 0)) && (*(float *)(iVar51 + 0x9c) == 0.0)) {
            if ((uVar21 >> 10 & 1) == 0) {
                uVar20 = 0;
            } else {
                uVar20 = *(undefined4 *)(iVar12 + 0xda8);
            }
            *(undefined4 *)(iVar51 + 0x90) = 0;
            *(undefined4 *)(iVar51 + 0x94) = uVar20;
        }
        fVar53 = *(float *)(iVar51 + 0x90);
        if (*(float *)(iVar51 + 0x90) <= *(float *)(iVar12 + 0xdec)) {
            fVar53 = *(float *)(iVar12 + 0xdec);
        }
        if (fVar53 <= *(float *)(iVar12 + 0x20a8)) {
            fVar53 = *(float *)(iVar12 + 0x20a8);
        }
        *(float *)(iVar51 + 0x1bc) = fVar53;
        *(undefined4 *)(iVar51 + 0x1c0) = *(undefined4 *)(iVar12 + 0x20ac);
        if ((uVar21 & 1) == 0) {
            fVar53 = *(float *)(iVar12 + 0xde0) + *(float *)(iVar12 + 0xde0) + *(float *)(iVar12 + 0x12f8);
        } else {
            fVar53 = 0.0;
        }
        *(float *)(iVar51 + 0xa0) = fVar53;
        if ((uVar21 >> 10 & 1) == 0) {
            fVar53 = 0.0;
        } else {
            fVar53 = *(float *)(iVar12 + 0x12f8) + *(float *)(iVar51 + 0x1c0) +
                     *(float *)(iVar12 + 0xde0) + *(float *)(iVar12 + 0xde0);
        }
        *(float *)(iVar51 + 0xa4) = fVar53;
        *(undefined4 *)(iVar51 + 0x318) = *(undefined4 *)(iVar12 + 0x12f8);
        uVar17 = (uint8_t)var_270h;
        var_278h = (uint32_t)var_270h & 0xff;
        if ((var_288h != '\0') && (*(float *)(iVar51 + 0x88) != 0.0)) {
            var_270h._0_4_ = CONCAT31(var_270h._1_3_, 1);
        }
        if ((var_287h != '\0') && (*(float *)(iVar51 + 0x8c) != 0.0)) {
            uVar17 = 1;
            var_278h = 1;
        }
        if (((uVar21 & 0x21) == 0) && ((*(uint8_t *)(iVar51 + 0x495) & 1) == 0)) {
            fStack_1c8 = *(float *)(iVar51 + 0x60);
            uStack_1c4 = *(undefined4 *)(iVar51 + 100);
            fStack_1c0 = fStack_1c8 + *(float *)(iVar51 + 0x70);
            fStack_1bc = *(float *)(iVar51 + 0xa0) + *(float *)(iVar51 + 100);
            if ((((*(int64_t *)(iVar12 + 0x15e8) == iVar51) && (*(int32_t *)(iVar12 + 0x163c) == 0)) &&
                (*(int32_t *)(iVar12 + 0x1640) == 0)) && (*(int32_t *)(iVar12 + 0x1654) == 0)) {
                uVar52 = 1;
                cVar14 = func_0x000180108120(&fStack_1c8, &fStack_1c0);
                if (((cVar14 != '\0') && (*(int16_t *)(iVar12 + 0xb5a) == 2)) &&
                   (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1d8c) == -1)) {
                    *(undefined *)(iVar51 + 0x10d) = uVar52;
                }
            }
            uVar48 = 1;
            cVar14 = var_288h;
            cVar16 = var_287h;
            if (*(char *)(iVar51 + 0x10d) != '\0') {
                cVar5 = *(char *)(iVar51 + 0x10c);
                *(bool *)(iVar51 + 0x10c) = cVar5 == '\0';
                var_278h = (uint32_t)uVar17;
                if (cVar5 != '\0') {
                    var_278h = 1;
                }
                func_0x000180112770(iVar51);
            }
        } else {
            *(undefined *)(iVar51 + 0x10c) = 0;
            uVar48 = 1;
            cVar14 = var_288h;
            cVar16 = var_287h;
        }
        *(undefined *)(iVar51 + 0x10d) = 0;
        fVar62 = *(float *)(iVar51 + 0xfc);
        fVar53 = *(float *)(iVar51 + 0x100);
        *(undefined4 *)(iVar51 + 0xa8) = 0;
        *(undefined8 *)(iVar51 + 0xb0) = 0;
        *(float *)(iVar51 + 0xac) = *(float *)(iVar51 + 0xa4) + *(float *)(iVar51 + 0xa0);
        *(undefined8 *)(iVar51 + 0xfc) = 0;
        if (((cVar14 == '\0') && ((uVar21 & 0x40) != 0)) && (*(char *)(iVar51 + 0x10c) == '\0')) {
            bVar8 = true;
        } else {
            bVar8 = false;
        }
        if (((cVar16 == '\0') && ((uVar21 & 0x40) != 0)) && (*(char *)(iVar51 + 0x10c) == '\0')) {
            bVar9 = true;
        } else {
            bVar9 = false;
        }
        if ((cVar14 == '\0') && ('\0' < *(char *)(iVar51 + 0x128))) {
            bVar10 = true;
        } else {
            bVar10 = false;
        }
        if ((cVar16 == '\0') && ('\0' < *(char *)(iVar51 + 0x129))) {
            bVar11 = true;
        } else {
            bVar11 = false;
        }
        if ((bVar8) || (uVar37 = 0, bVar10)) {
            uVar37 = uVar48 & 0xffffffff;
        }
        if ((bVar9) || (bVar11)) {
            uVar37 = (uint64_t)((uint32_t)uVar37 | 2);
        }
        func_0x0001800ff2b0(&var_250h, iVar51, iVar51 + 0x80, uVar37);
        fVar60 = *(float *)(iVar51 + 0x70);
        fVar54 = *(float *)(iVar51 + 0x74);
        fVar65 = (float)var_250h;
        if (bVar8) {
code_r0x000180103ab8:
            *(float *)(iVar51 + 0x70) = fVar65;
            var_270h._0_4_ = CONCAT31(var_270h._1_3_, 1);
        } else if (bVar10) {
            if ((*(char *)(iVar51 + 0x12a) != '\0') && (fVar65 = fVar60, fVar60 <= (float)var_250h)) {
                fVar65 = (float)var_250h;
            }
            goto code_r0x000180103ab8;
        }
        if (bVar9) {
code_r0x000180103aea:
            *(float *)(iVar51 + 0x74) = var_250h._4_4_;
            uVar22 = 1;
        } else {
            uVar22 = var_278h;
            if (bVar11) {
                if (*(char *)(iVar51 + 0x12a) == '\0') goto code_r0x000180103aea;
                fVar65 = *(float *)(iVar51 + 0x74);
                if (*(float *)(iVar51 + 0x74) <= var_250h._4_4_) {
                    fVar65 = var_250h._4_4_;
                }
                *(float *)(iVar51 + 0x74) = fVar65;
                uVar22 = 1;
            }
        }
        cVar14 = (char)uVar22;
        if ((((fVar60 != *(float *)(iVar51 + 0x70)) || (fVar54 != *(float *)(iVar51 + 0x74))) &&
            ((*(uint32_t *)(iVar51 + 0x14) & 0x100) == 0)) && (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0)) {
            *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
        }
        pfVar29 = (float *)func_0x0001800ff010(auStack_128, iVar51, iVar51 + 0x70);
        iVar25 = var_268h;
        cVar5 = var_284h;
        cVar16 = var_286h;
        fVar60 = *pfVar29;
        fVar54 = pfVar29[1];
        *(float *)(iVar51 + 0x70) = fVar60;
        *(float *)(iVar51 + 0x74) = fVar54;
        if ((*(char *)(iVar51 + 0x10c) != '\0') && ((uVar21 >> 0x18 & 1) == 0)) {
            fVar60 = (*(float *)(iVar51 + 0x60) + *(float *)(iVar51 + 0x70)) - *(float *)(iVar51 + 0x60);
            fVar54 = (*(float *)(iVar51 + 0xa0) + *(float *)(iVar51 + 100)) - *(float *)(iVar51 + 100);
        }
        *(float *)(iVar51 + 0x68) = fVar60;
        *(float *)(iVar51 + 0x6c) = fVar54;
        if (((var_286h != '\0') && (*(undefined4 *)(iVar51 + 0x124) = 0xffffffff, (uVar21 & 0xc000000) == 0x4000000)) &&
           (var_284h == '\0')) {
            iVar32 = (int64_t)*(int32_t *)(iVar12 + 0x2130) * 0x38;
            uVar20 = *(undefined4 *)(iVar32 + -0x10 + *(int64_t *)(iVar12 + 0x2138));
            *(undefined4 *)(iVar51 + 0x60) = *(undefined4 *)(iVar32 + -0x14 + *(int64_t *)(iVar12 + 0x2138));
            *(undefined4 *)(iVar51 + 100) = uVar20;
        }
        if ((uVar21 >> 0x18 & 1) != 0) {
            *(undefined2 *)(iVar51 + 0x11c) = *(undefined2 *)(var_268h + 0x1f0);
            func_0x00018011f490();
            if ((((uVar21 >> 0x1a & 1) == 0) && (cVar5 == '\0')) && (var_285h == '\0')) {
                *(undefined8 *)(iVar51 + 0x60) = *(undefined8 *)(iVar25 + 0x158);
            }
        }
        if ((*(float *)(iVar51 + 0x138) == 3.402823e+38) || (*(char *)(iVar51 + 300) != '\0')) {
            if ((uVar21 >> 0x1c & 1) == 0) {
                if ((((uVar21 >> 0x1a & 1) == 0) || (cVar5 != '\0')) || (var_274h < '\x01')) {
                    if ((((uVar21 >> 0x19 & 1) == 0) || (cVar5 != '\0')) || (var_285h != '\0'))
                    goto code_r0x000180103cef;
                    puVar34 = auStack_110;
                } else {
                    puVar34 = auStack_118;
                }
            } else {
                puVar34 = auStack_120;
            }
            puVar43 = (undefined4 *)func_0x00018010dc40(puVar34);
            uVar20 = puVar43[1];
            *(undefined4 *)(iVar51 + 0x60) = *puVar43;
            *(undefined4 *)(iVar51 + 100) = uVar20;
        } else {
            fStack_1e0 = *(float *)(iVar51 + 0x138) - *(float *)(iVar51 + 0x68) * *(float *)(iVar51 + 0x140);
            fStack_1dc = *(float *)(iVar51 + 0x13c) - *(float *)(iVar51 + 0x6c) * *(float *)(iVar51 + 0x144);
            func_0x000180106470(iVar51, &fStack_1e0, 0);
        }
code_r0x000180103cef:
        if (*(int32_t *)(iVar51 + 0x5c) < 0) {
code_r0x000180103e08:
            if (*(char *)(iVar51 + 0x108) != '\0') goto code_r0x000180103e15;
        } else {
            if (*(char *)(iVar51 + 0x108) == '\0') {
                iVar25 = *(int64_t *)(iVar51 + 0x48);
                if ((*(uint32_t *)(iVar25 + 4) & 0x1000) == 0) {
                    fStack_188 = *(float *)(iVar25 + 8);
                    fStack_184 = *(float *)(iVar25 + 0xc);
                    fStack_180 = fStack_188 + *(float *)(iVar25 + 0x10);
                    fStack_17c = fStack_184 + *(float *)(iVar25 + 0x14);
                    fStack_198 = *(float *)(iVar51 + 0x60);
                    fStack_194 = *(float *)(iVar51 + 100);
                    fStack_190 = fStack_198 + *(float *)(iVar51 + 0x68);
                    fStack_18c = fStack_194 + *(float *)(iVar51 + 0x6c);
                    cVar15 = func_0x0001800f4150(&fStack_188);
                    if (cVar15 == '\0') {
                        var_2a8h = CONCAT44(var_2a8h._4_4_, 0x20);
                        iVar32 = func_0x000180114730(iVar51, *(undefined4 *)(iVar51 + 0x10));
                        *(int64_t *)(iVar51 + 0x48) = iVar32;
                        iVar25 = *(int64_t *)0x180781f28;
                        if (iVar32 != 0) {
                            *(undefined4 *)(iVar32 + 0x84) = *(undefined4 *)(*(int64_t *)0x180781f28 + 4);
                        }
                        if (*(int64_t *)(iVar25 + 0x2160) != iVar32) {
                            if (iVar32 == 0) {
                                uVar20 = 0x3f800000;
                            } else {
                                uVar20 = *(undefined4 *)(iVar32 + 0x30);
                            }
                            *(undefined4 *)(iVar25 + 0x1308) = uVar20;
                            *(int64_t *)(iVar25 + 0x2160) = iVar32;
                            if (*(char *)(iVar25 + 0x8a) != '\0') {
                                *(undefined4 *)(iVar25 + 0xd98) = uVar20;
                            }
                            if ((iVar32 != 0) && (*(code **)(iVar25 + 0xd20) != (code *)0x0)) {
                                (**(code **)(iVar25 + 0xd20))(iVar32);
                            }
                        }
                        func_0x0001800f9e20(iVar51);
                    }
                }
                goto code_r0x000180103e08;
            }
code_r0x000180103e15:
            iVar32 = *(int64_t *)0x180781f28;
            cVar15 = '\0';
            iVar25 = *(int64_t *)(iVar51 + 0x48);
            if (*(char *)(iVar25 + 0x71) == '\0') {
                if (*(int64_t *)(iVar25 + 8) != *(int64_t *)(iVar51 + 0x60)) {
                    cVar15 = '\x01';
                    *(undefined8 *)(iVar25 + 8) = *(undefined8 *)(iVar51 + 0x60);
                }
            } else {
                *(undefined8 *)(iVar51 + 0x60) = *(undefined8 *)(iVar25 + 8);
                if (((*(uint32_t *)(iVar51 + 0x14) & 0x100) == 0) && (*(float *)(iVar32 + 0x292c) <= 0.0)) {
                    *(undefined4 *)(iVar32 + 0x292c) = *(undefined4 *)(iVar32 + 0x4c);
                }
            }
            iVar25 = *(int64_t *)(iVar51 + 0x48);
            if (*(char *)(iVar25 + 0x72) == '\0') {
                if (*(int64_t *)(iVar25 + 0x10) == *(int64_t *)(iVar51 + 0x68)) goto code_r0x000180103ead;
                *(undefined8 *)(iVar25 + 0x10) = *(undefined8 *)(iVar51 + 0x68);
                func_0x0001800f4490(*(undefined8 *)(iVar51 + 0x48));
code_r0x000180103eba:
                func_0x000180114a60(*(undefined8 *)(iVar51 + 0x48));
            } else {
                uVar20 = *(undefined4 *)(iVar25 + 0x10);
                uVar55 = *(undefined4 *)(iVar25 + 0x14);
                *(undefined4 *)(iVar51 + 0x70) = uVar20;
                *(undefined4 *)(iVar51 + 0x74) = uVar55;
                *(undefined4 *)(iVar51 + 0x68) = uVar20;
                *(undefined4 *)(iVar51 + 0x6c) = uVar55;
                if (((*(uint32_t *)(iVar51 + 0x14) & 0x100) == 0) && (*(float *)(iVar32 + 0x292c) <= 0.0)) {
                    *(undefined4 *)(iVar32 + 0x292c) = *(undefined4 *)(iVar32 + 0x4c);
                }
code_r0x000180103ead:
                func_0x0001800f4490(*(undefined8 *)(iVar51 + 0x48));
                if (cVar15 != '\0') goto code_r0x000180103eba;
            }
            uVar31 = *(uint32_t *)(*(int64_t *)(iVar51 + 0x48) + 4) & 0xfffffae7;
            uVar22 = *(uint32_t *)(iVar51 + 0x14);
            uVar47 = uVar22 & 0x8000000;
            uVar44 = uVar22 & 0x16000000;
            uVar36 = uVar31 | 0x400;
            if ((uVar22 >> 0x19 & 1) == 0) {
                uVar36 = uVar31;
            }
            if (((*(char *)(iVar32 + 0x86) != '\0') || (uVar44 != 0)) && (uVar47 == 0)) {
                uVar36 = uVar36 | 0x10;
            }
            if (*(char *)(iVar32 + 0x87) == '\0') {
                uVar31 = uVar36;
                if (uVar44 != 0) {
                    uVar31 = uVar36 | 0x68;
                    if (uVar47 != 0) {
                        uVar31 = uVar36 | 8;
                    }
                }
            } else {
                uVar31 = uVar36 | 8;
                if ((uVar44 != 0) && (uVar31 = uVar36 | 0x68, uVar47 != 0)) {
                    uVar31 = uVar36 | 8;
                }
            }
            uVar36 = *(uint32_t *)(iVar51 + 0x2c) | uVar31;
            if (*(uint32_t *)(iVar51 + 0x2c) == 0) {
                uVar36 = uVar31;
            }
            if (*(uint32_t *)(iVar51 + 0x30) != 0) {
                uVar36 = ~*(uint32_t *)(iVar51 + 0x30) & uVar36;
            }
            uVar31 = uVar36 | 0x100;
            if ((uVar22 & 0x80) != 0) {
                uVar31 = uVar36;
            }
            *(uint32_t *)(*(int64_t *)(iVar51 + 0x48) + 4) = uVar31;
            *(undefined8 *)(*(int64_t *)(iVar51 + 0x48) + 0x58) = *(undefined8 *)(iVar51 + 0x40);
            if (*(int32_t *)(iVar51 + 0x24) == -1) {
                if ((((uVar22 & 0x6000000) == 0) || (iStack_208 == 0)) ||
                   ((*(char *)(iStack_208 + 0x112) != '\0' && (*(char *)(iStack_208 + 0x10a) == '\0')))) {
                    if (*(char *)(iVar32 + 0x88) == '\0') {
                        uVar26 = **(undefined8 **)(iVar32 + 0x2158);
                    } else {
                        uVar26 = 0;
                    }
                    *(undefined8 *)(*(int64_t *)(iVar51 + 0x48) + 0x38) = uVar26;
                    uVar20 = 0x11111111;
                    if (*(char *)(iVar32 + 0x88) != '\0') {
                        uVar20 = 0;
                    }
                    *(undefined4 *)(*(int64_t *)(iVar51 + 0x48) + 0x34) = uVar20;
                } else {
                    *(undefined8 *)(*(int64_t *)(iVar51 + 0x48) + 0x38) = *(undefined8 *)(iStack_208 + 0x48);
                    *(undefined4 *)(*(int64_t *)(iVar51 + 0x48) + 0x34) = **(undefined4 **)(iStack_208 + 0x48);
                }
            } else {
                iVar18 = *(int32_t *)(*(int64_t *)(iVar51 + 0x48) + 0x34);
                *(int32_t *)(*(int64_t *)(iVar51 + 0x48) + 0x34) = *(int32_t *)(iVar51 + 0x24);
                iVar25 = *(int64_t *)(iVar51 + 0x48);
                if (*(int32_t *)(iVar25 + 0x34) != iVar18) {
                    uVar26 = func_0x0001801134f0();
                    *(undefined8 *)(iVar25 + 0x38) = uVar26;
                }
            }
        }
        iVar25 = *(int64_t *)(iVar51 + 0x48);
        fStack_1f8 = *(float *)(iVar25 + 8);
        fStack_1f4 = *(float *)(iVar25 + 0xc);
        fStack_1f0 = fStack_1f8 + *(float *)(iVar25 + 0x10);
        fStack_1ec = fStack_1f4 + *(float *)(iVar25 + 0x14);
        fVar60 = *(float *)(iVar12 + 0xeac);
        if (*(float *)(iVar12 + 0xeac) <= *(float *)(iVar12 + 0xeb4)) {
            fVar60 = *(float *)(iVar12 + 0xeb4);
        }
        fVar54 = *(float *)(iVar12 + 0xea8);
        if (*(float *)(iVar12 + 0xea8) <= *(float *)(iVar12 + 0xeb0)) {
            fVar54 = *(float *)(iVar12 + 0xeb0);
        }
        fStack_220 = (*(float *)(iVar25 + 0x20) + *(float *)(iVar25 + 0x28)) - fVar54;
        fStack_21c = (*(float *)(iVar25 + 0x24) + *(float *)(iVar25 + 0x2c)) - fVar60;
        fStack_228 = fVar54 + *(float *)(iVar25 + 0x20);
        fStack_224 = fVar60 + *(float *)(iVar25 + 0x24);
        if ((cVar5 == '\0') && ((uVar21 >> 0x18 & 1) == 0)) {
            if (*(char *)(iVar51 + 0x108) == '\0') {
                if ((0.0 < fStack_1f0 - fStack_1f8) && (0.0 < fStack_1ec - fStack_1f4)) {
code_r0x0001801041ca:
                    func_0x000180100750(iVar51);
                }
            } else if (0 < *(int32_t *)(iVar12 + 0xd60)) {
                if ((*(int64_t *)(iVar12 + 0x1600) == 0) ||
                   (*(int64_t *)(iVar51 + 0x428) != *(int64_t *)(*(int64_t *)(iVar12 + 0x1600) + 0x428))) {
                    iVar25 = func_0x000180114c10(*(undefined8 *)(iVar51 + 0x48));
                    fStack_228 = *(float *)(iVar25 + 0x10);
                    fStack_220 = fStack_228 + *(float *)(iVar25 + 0x18);
                    fStack_224 = *(float *)(iVar25 + 0x14);
                    fStack_21c = fStack_224 + *(float *)(iVar25 + 0x1c);
                } else {
                    fStack_228 = *(float *)(iVar12 + 0x21b0);
                    fStack_224 = *(float *)(iVar12 + 0x21b4);
                    fStack_220 = *(float *)(iVar12 + 0x21b8);
                    fStack_21c = *(float *)(iVar12 + 0x21bc);
                }
                fStack_228 = fStack_228 - (float)((uint32_t)fVar54 ^ 0x80000000);
                fStack_224 = fStack_224 - (float)((uint32_t)fVar60 ^ 0x80000000);
                fStack_220 = fStack_220 + (float)((uint32_t)fVar54 ^ 0x80000000);
                fStack_21c = fStack_21c + (float)((uint32_t)fVar60 ^ 0x80000000);
                goto code_r0x0001801041ca;
            }
        }
        *(float *)(iVar51 + 0x60) = (float)(int32_t)*(float *)(iVar51 + 0x60);
        *(float *)(iVar51 + 100) = (float)(int32_t)*(float *)(iVar51 + 100);
        if (((uVar21 >> 0x18 & 1) == 0) || ((*(uint8_t *)(iVar51 + 0x495) & 1) != 0)) {
            uVar48 = *(uint64_t *)(iVar51 + 0x428);
            if (*(char *)(uVar48 + 0x108) == '\0') {
                puVar30 = (uint32_t *)(iVar12 + 0xdd4);
                if ((uVar21 & 0xc000000) != 0x4000000) {
                    puVar30 = (uint32_t *)(iVar12 + 0xdac);
                }
                uVar22 = *puVar30;
                goto code_r0x00018010424b;
            }
            *(undefined4 *)(iVar51 + 0x98) = 0;
        } else {
            uVar22 = *(uint32_t *)(iVar12 + 0xdcc);
code_r0x00018010424b:
            uVar48 = (uint64_t)uVar22;
            *(uint32_t *)(iVar51 + 0x98) = uVar22;
        }
        var_278h = (uint32_t)uVar48 & 0xffffff00;
        if ((cVar16 != '\0') && ((uVar21 >> 0xc & 1) == 0)) {
            if ((uVar21 >> 0x1a & 1) == 0) {
                if (((*(uint8_t *)(iVar51 + 0x495) & 1) != 0) || ((uVar21 >> 0x18 & 1) == 0)) {
                    var_278h = (uint32_t)((uVar21 >> 0x19 & 1) == 0);
                }
            } else {
                uVar22 = var_278h >> 8;
                var_278h = CONCAT31((unkint3)uVar22, 1);
            }
        }
        if ((*(int64_t *)(iVar51 + 0x4c8) == 0) && ((*(uint8_t *)(iVar51 + 0x495) & 1) != 0)) {
            bVar8 = false;
        } else {
            bVar8 = true;
        }
        bVar9 = bVar8;
        if (((uVar21 >> 0x18 & 1) != 0) && (bVar9 = false, *(char *)(*(int64_t *)(iVar51 + 0x408) + 0x10e) == '\0')) {
            bVar9 = bVar8;
        }
        uStack_238 = 0xffffffff;
        uStack_234 = 0xffffffff;
        auStack_f8 = ZEXT816(0);
        if ((uVar21 & 0x5000000) == 0x1000000) {
            uVar22 = (uint32_t)(((uint8_t)*(undefined4 *)(iVar51 + 0x1c) & 0xc) == 0xc);
        } else {
            uVar22 = (*(char *)(iVar12 + 0x92) != '\0') + 1;
        }
        fVar60 = *(float *)(iVar12 + 0x12f8) * 1.1;
        fVar54 = *(float *)(iVar51 + 0x98) + 1.0 + *(float *)(iVar12 + 0x12f8) * 0.2;
        if (fVar60 <= fVar54) {
            fVar60 = fVar54;
        }
        uVar36 = (uint32_t)var_270h;
        if ((bVar9) && (*(char *)(iVar51 + 0x10c) == '\0')) {
            var_2a0h = (int64_t)&fStack_228;
            var_2a8h = (int64_t)auStack_f8;
            uVar31 = func_0x0001800ff8b0(iVar51, &uStack_238, &uStack_234, uVar22);
            uVar36 = (uint32_t)var_270h;
            if (uVar31 != 0) {
                uVar36 = (uint32_t)var_270h & 0xff;
                if ((uVar31 & 1) != 0) {
                    uVar36 = 1;
                }
                if ((uVar31 & 2) != 0) {
                    cVar14 = '\x01';
                }
            }
        }
        cVar16 = (char)uVar36;
        *(undefined *)(iVar51 + 0x115) = (undefined)uStack_238;
        *(undefined *)(iVar51 + 0x116) = (undefined)uStack_234;
        if (*(char *)(iVar51 + 0x108) != '\0') {
            if (*(char *)(*(int64_t *)(iVar51 + 0x48) + 0x71) == '\0') {
                *(undefined8 *)(*(int64_t *)(iVar51 + 0x48) + 8) = *(undefined8 *)(iVar51 + 0x60);
            }
            if (*(char *)(*(int64_t *)(iVar51 + 0x48) + 0x72) == '\0') {
                *(undefined8 *)(*(int64_t *)(iVar51 + 0x48) + 0x10) = *(undefined8 *)(iVar51 + 0x68);
            }
            func_0x0001800f4490(*(undefined8 *)(iVar51 + 0x48));
            iVar25 = *(int64_t *)(iVar51 + 0x48);
            fStack_1f8 = *(float *)(iVar25 + 8);
            fStack_1f4 = *(float *)(iVar25 + 0xc);
            fStack_1f0 = *(float *)(iVar25 + 8) + *(float *)(iVar25 + 0x10);
            fStack_1ec = *(float *)(iVar25 + 0xc) + *(float *)(iVar25 + 0x14);
        }
        *(undefined8 *)(iVar51 + 0x54) = *(undefined8 *)(*(int64_t *)(iVar51 + 0x48) + 8);
        if (*(char *)(iVar51 + 0x10c) == '\0') {
            if (piStack_230 == (int64_t *)0x0) {
                fVar65 = 0.0;
                fVar54 = 0.0;
            } else {
                fVar65 = *(float *)(iVar51 + 0x90) + *(float *)(iVar51 + 0x90) + *(float *)(iVar51 + 0x78);
                fVar54 = *(float *)(iVar51 + 0x94) + *(float *)(iVar51 + 0x94) + *(float *)(iVar51 + 0x7c);
            }
            if (cVar16 == '\0') {
                fVar62 = (*(float *)(iVar51 + 0x280) - *(float *)(iVar51 + 0x278)) + fVar62;
            } else {
                fVar62 = *(float *)(iVar51 + 0x70);
            }
            if (cVar14 == '\0') {
                fVar53 = (*(float *)(iVar51 + 0x284) - *(float *)(iVar51 + 0x27c)) + fVar53;
            } else {
                fVar53 = *(float *)(iVar51 + 0x74) - (*(float *)(iVar51 + 0xb4) + *(float *)(iVar51 + 0xac));
            }
            cVar14 = *(char *)(iVar51 + 0x104);
            if (((uVar21 >> 0xe & 1) != 0) || ((fVar53 < fVar54 && ((uVar21 & 8) == 0)))) {
                cVar16 = '\x01';
            } else {
                cVar16 = '\0';
            }
            *(char *)(iVar51 + 0x105) = cVar16;
            if ((uVar21 >> 0xf & 1) == 0) {
                if (cVar16 == '\0') {
                    fVar61 = 0.0;
                } else {
                    fVar61 = *(float *)(iVar12 + 0xe14);
                }
                if ((fVar62 - fVar61 < fVar65) && ((uVar21 & 0x808) == 0x800)) goto code_r0x000180104523;
                cVar16 = '\0';
            } else {
code_r0x000180104523:
                cVar16 = '\x01';
            }
            *(char *)(iVar51 + 0x104) = cVar16;
            *(char *)(iVar51 + 0x107) = *(char *)(iVar51 + 0x107) << 1;
            uVar17 = cVar14 != cVar16 | *(uint8_t *)(iVar51 + 0x107);
            *(uint8_t *)(iVar51 + 0x107) = uVar17;
            if (uVar17 == 0) {
code_r0x000180104568:
                uVar52 = 0;
            } else {
                uVar36 = 0;
                do {
                    uVar36 = uVar36 + 1;
                    uVar17 = uVar17 & uVar17 - 1;
                } while (uVar17 != 0);
                if (uVar36 < 4) goto code_r0x000180104568;
                uVar52 = 1;
                *(undefined *)(iVar51 + 0x104) = 1;
            }
            *(undefined *)(iVar51 + 0x106) = uVar52;
            if (*(char *)(iVar51 + 0x104) == '\0') {
code_r0x0001801045b4:
                uVar20 = 0;
            } else {
                if (*(char *)(iVar51 + 0x105) == '\0') {
                    if ((fVar54 <= fVar53 - *(float *)(iVar12 + 0xe14)) || ((uVar21 & 8) != 0)) {
                        uVar52 = 0;
                    } else {
                        uVar52 = 1;
                    }
                    *(undefined *)(iVar51 + 0x105) = uVar52;
                }
                if (*(char *)(iVar51 + 0x104) == '\0') goto code_r0x0001801045b4;
                uVar20 = *(undefined4 *)(iVar12 + 0xe14);
            }
            if (*(char *)(iVar51 + 0x105) == '\0') {
                uVar55 = 0;
            } else {
                uVar55 = *(undefined4 *)(iVar12 + 0xe14);
            }
            *(undefined4 *)(iVar51 + 0xfc) = uVar55;
            *(undefined4 *)(iVar51 + 0x100) = uVar20;
            *(float *)(iVar51 + 0xb0) = *(float *)(iVar51 + 0xfc) + *(float *)(iVar51 + 0xb0);
            *(float *)(iVar51 + 0xb4) = *(float *)(iVar51 + 0x100) + *(float *)(iVar51 + 0xb4);
        }
        if (((uVar21 & 0x5000000) == 0x1000000) && (var_285h == '\0')) {
            pfVar29 = (float *)(var_268h + 0x2b8);
        } else {
            pfVar29 = &fStack_1f8;
        }
        fVar53 = *pfVar29;
        fVar62 = pfVar29[1];
        fVar54 = pfVar29[2];
        fVar65 = pfVar29[3];
        fStack_218 = *(float *)(iVar51 + 0x60);
        fVar61 = *(float *)(iVar51 + 100);
        fStack_210 = fStack_218 + *(float *)(iVar51 + 0x70);
        fStack_20c = fVar61 + *(float *)(iVar51 + 0xa0);
        fStack_214 = *(float *)(iVar51 + 100);
        *(float *)(iVar51 + 0x268) = fStack_218;
        *(float *)(iVar51 + 0x26c) = fVar61;
        *(float *)(iVar51 + 0x270) = fStack_218 + *(float *)(iVar51 + 0x68);
        *(float *)(iVar51 + 0x274) = fVar61 + *(float *)(iVar51 + 0x6c);
        if ((*(uint8_t *)(var_258h + 0x495) & 1) != 0) {
            *(float *)(var_258h + 0x26c) = *(float *)(var_258h + 0xa0) + *(float *)(var_258h + 0x26c);
        }
        fVar61 = *(float *)(var_258h + 0x26c);
        if (*(float *)(var_258h + 0x26c) <= fVar62) {
            fVar61 = fVar62;
        }
        fVar63 = *(float *)(var_258h + 0x268);
        if (*(float *)(var_258h + 0x268) <= fVar53) {
            fVar63 = fVar53;
        }
        *(float *)(var_258h + 0x268) = fVar63;
        *(float *)(var_258h + 0x26c) = fVar61;
        fVar61 = *(float *)(var_258h + 0x274);
        if (fVar65 <= *(float *)(var_258h + 0x274)) {
            fVar61 = fVar65;
        }
        fVar63 = *(float *)(var_258h + 0x270);
        if (fVar54 <= *(float *)(var_258h + 0x270)) {
            fVar63 = fVar54;
        }
        *(float *)(var_258h + 0x270) = fVar63;
        *(float *)(var_258h + 0x274) = fVar61;
        *(float *)(var_258h + 0x278) = *(float *)(var_258h + 0xa8) + *(float *)(var_258h + 0x60);
        *(float *)(var_258h + 0x27c) = *(float *)(var_258h + 0xac) + *(float *)(var_258h + 100);
        *(float *)(var_258h + 0x280) =
             (*(float *)(var_258h + 0x68) + *(float *)(var_258h + 0x60)) - *(float *)(var_258h + 0xb0);
        *(float *)(var_258h + 0x284) =
             (*(float *)(var_258h + 0x6c) + *(float *)(var_258h + 100)) - *(float *)(var_258h + 0xb4);
        if ((uVar21 & 0x401) == 1) {
            fVar61 = *(float *)(var_258h + 0x9c);
        } else {
            fVar61 = *(float *)(iVar12 + 0xde8);
        }
        fVar63 = *(float *)(var_258h + 0x9c) * 0.5 + *(float *)(var_258h + 0x278) + 0.5;
        iVar18 = (int32_t)fVar63;
        if ((fVar63 < 0.0) && ((float)iVar18 != fVar63)) {
            iVar18 = iVar18 + -1;
        }
        *(float *)(var_258h + 0x288) = (float)iVar18;
        fVar61 = fVar61 * 0.5 + *(float *)(var_258h + 0x27c) + 0.5;
        iVar18 = (int32_t)fVar61;
        if ((fVar61 < 0.0) && ((float)iVar18 != fVar61)) {
            iVar18 = iVar18 + -1;
        }
        *(float *)(var_258h + 0x28c) = (float)iVar18;
        fVar61 = *(float *)(var_258h + 0x280) - *(float *)(var_258h + 0x9c) * 0.5;
        iVar18 = (int32_t)fVar61;
        if ((fVar61 < 0.0) && ((float)iVar18 != fVar61)) {
            iVar18 = iVar18 + -1;
        }
        *(float *)(var_258h + 0x290) = (float)iVar18;
        fVar61 = *(float *)(var_258h + 0x284) - *(float *)(var_258h + 0x9c) * 0.5;
        iVar18 = (int32_t)fVar61;
        if ((fVar61 < 0.0) && ((float)iVar18 != fVar61)) {
            iVar18 = iVar18 + -1;
        }
        *(float *)(var_258h + 0x294) = (float)iVar18;
        fVar61 = *(float *)(var_258h + 0x28c);
        fVar63 = fVar62;
        if ((fVar62 <= fVar61) && (fVar63 = fVar65, fVar61 <= fVar65)) {
            fVar63 = fVar61;
        }
        fVar61 = *(float *)(var_258h + 0x288);
        fVar56 = fVar53;
        if ((fVar53 <= fVar61) && (fVar56 = fVar54, fVar61 <= fVar54)) {
            fVar56 = fVar61;
        }
        *(float *)(var_258h + 0x288) = fVar56;
        *(float *)(var_258h + 0x28c) = fVar63;
        fVar61 = *(float *)(var_258h + 0x294);
        fVar63 = fVar62;
        if ((fVar62 <= fVar61) && (fVar63 = fVar65, fVar61 <= fVar65)) {
            fVar63 = fVar61;
        }
        fVar61 = *(float *)(var_258h + 0x290);
        fVar56 = fVar53;
        if ((fVar53 <= fVar61) && (fVar56 = fVar54, fVar61 <= fVar54)) {
            fVar56 = fVar61;
        }
        *(float *)(var_258h + 0x290) = fVar56;
        *(float *)(var_258h + 0x294) = fVar63;
        fVar63 = (*(float *)(var_258h + 0x90) + *(float *)(var_258h + 0x90) + *(float *)(var_258h + 0x78)) -
                 (*(float *)(var_258h + 0x280) - *(float *)(var_258h + 0x278));
        fVar61 = 0.0;
        if (0.0 <= fVar63) {
            fVar61 = fVar63;
        }
        *(float *)(var_258h + 0xdc) = fVar61;
        fVar63 = (*(float *)(var_258h + 0x94) + *(float *)(var_258h + 0x94) + *(float *)(var_258h + 0x7c)) -
                 (*(float *)(var_258h + 0x284) - *(float *)(var_258h + 0x27c));
        fVar61 = 0.0;
        if (0.0 <= fVar63) {
            fVar61 = fVar63;
        }
        *(float *)(var_258h + 0xe0) = fVar61;
        iVar25 = var_258h;
        puVar43 = (undefined4 *)func_0x00018010c510(auStack_108);
        uVar20 = puVar43[1];
        *(undefined4 *)(iVar25 + 0xd4) = *puVar43;
        *(undefined4 *)(iVar25 + 0xd8) = uVar20;
        *(undefined4 *)(iVar25 + 0xe4) = 0x7f7fffff;
        *(undefined4 *)(iVar25 + 0xe8) = 0x7f7fffff;
        *(undefined8 *)(iVar25 + 0xb8) = 0;
        iVar25 = *(int64_t *)(iVar25 + 800);
        iVar32 = *(int64_t *)(*(int64_t *)(iVar12 + 0x12e8) + 8);
        uVar20 = *(undefined4 *)(iVar32 + 0x28);
        uVar55 = *(undefined4 *)(iVar32 + 0x2c);
        uVar4 = *(undefined4 *)(iVar32 + 0x30);
        uVar7 = *(undefined4 *)(iVar32 + 0x34);
        iVar18 = *(int32_t *)(iVar25 + 0xb4);
        if (*(int32_t *)(iVar25 + 0xb0) == iVar18) {
            iVar42 = *(int32_t *)(iVar25 + 0xb0) + 1;
            if (iVar18 == 0) {
                iVar19 = 8;
            } else {
                iVar19 = iVar18 / 2 + iVar18;
            }
            if (iVar42 < iVar19) {
                iVar42 = iVar19;
            }
            if (iVar18 < iVar42) {
                uVar26 = func_0x00018046d050((int64_t)iVar42 << 4);
                if (*(int64_t *)(iVar25 + 0xb8) != 0) {
                    func_0x000180498030(uVar26, *(int64_t *)(iVar25 + 0xb8), (int64_t)*(int32_t *)(iVar25 + 0xb0) << 4);
                    func_0x000180460d90(*(undefined8 *)(iVar25 + 0xb8));
                }
                *(undefined8 *)(iVar25 + 0xb8) = uVar26;
                *(int32_t *)(iVar25 + 0xb4) = iVar42;
            }
        }
        puVar43 = (undefined4 *)(*(int64_t *)(iVar25 + 0xb8) + (int64_t)*(int32_t *)(iVar25 + 0xb0) * 0x10);
        *puVar43 = uVar20;
        puVar43[1] = uVar55;
        puVar43[2] = uVar4;
        puVar43[3] = uVar7;
        *(int32_t *)(iVar25 + 0xb0) = *(int32_t *)(iVar25 + 0xb0) + 1;
        *(undefined4 *)(iVar25 + 0x70) = uVar20;
        *(undefined4 *)(iVar25 + 0x74) = uVar55;
        *(undefined4 *)(iVar25 + 0x78) = uVar4;
        *(undefined4 *)(iVar25 + 0x7c) = uVar7;
        func_0x000180124360(iVar25);
        iVar25 = *(int64_t *)0x180781f28;
        *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
        iVar25 = *(int64_t *)(iVar25 + 0x15e0);
        iVar32 = *(int64_t *)(iVar25 + 800);
        fVar61 = fVar53;
        if (fVar53 <= fVar54) {
            fVar61 = fVar54;
        }
        fVar54 = fVar62;
        if (fVar62 <= fVar65) {
            fVar54 = fVar65;
        }
        piVar50 = (int32_t *)(iVar32 + 0xa0);
        iVar18 = *(int32_t *)(iVar32 + 0xa4);
        if (*piVar50 == iVar18) {
            iVar42 = *piVar50 + 1;
            if (iVar18 == 0) {
                iVar18 = 8;
            } else {
                iVar18 = iVar18 / 2 + iVar18;
            }
            if (iVar42 < iVar18) {
                iVar42 = iVar18;
            }
            func_0x00018011faa0(piVar50, iVar42);
        }
        iVar40 = (int64_t)*piVar50;
        iVar51 = *(int64_t *)(iVar32 + 0xa8);
        *(float *)(iVar51 + iVar40 * 0x10) = fVar53;
        *(float *)(iVar51 + 4 + iVar40 * 0x10) = fVar62;
        *(float *)(iVar51 + 8 + iVar40 * 0x10) = fVar61;
        *(float *)(iVar51 + 0xc + iVar40 * 0x10) = fVar54;
        *piVar50 = *piVar50 + 1;
        *(float *)(iVar32 + 0x60) = fVar53;
        *(float *)(iVar32 + 100) = fVar62;
        *(float *)(iVar32 + 0x68) = fVar61;
        *(float *)(iVar32 + 0x6c) = fVar54;
        func_0x0001801242c0(iVar32);
        piVar23 = (int64_t *)var_258h;
        iVar51 = (int64_t)*(int32_t *)(*(int64_t *)(iVar25 + 800) + 0xa0);
        iVar32 = *(int64_t *)(*(int64_t *)(iVar25 + 800) + 0xa8);
        uVar20 = *(undefined4 *)(iVar32 + -0xc + iVar51 * 0x10);
        uVar55 = *(undefined4 *)(iVar32 + -8 + iVar51 * 0x10);
        uVar4 = *(undefined4 *)(iVar32 + -4 + iVar51 * 0x10);
        *(undefined4 *)(iVar25 + 0x2b8) = *(undefined4 *)(iVar32 + -0x10 + iVar51 * 0x10);
        *(undefined4 *)(iVar25 + 700) = uVar20;
        *(undefined4 *)(iVar25 + 0x2c0) = uVar55;
        *(undefined4 *)(iVar25 + 0x2c4) = uVar4;
        if ((*(uint8_t *)(var_258h + 0x495) & 5) == 1) {
            cVar14 = (char)var_278h;
        } else {
            bVar8 = false;
            if (((uVar21 & 0x5000000) == 0x1000000) && (var_285h == '\0')) {
                iVar25 = var_268h;
                if ((*(int32_t *)(var_268h + 0x1f0) < 2) ||
                   (iVar32 = *(int64_t *)
                              (*(int64_t *)(var_268h + 0x1f8) + -0x10 + (int64_t)*(int32_t *)(var_268h + 0x1f0) * 8),
                   iVar32 == 0)) {
                    cVar14 = '\0';
                } else {
                    fStack_168 = *(float *)(iVar32 + 0x60);
                    fStack_164 = *(float *)(iVar32 + 100);
                    fStack_160 = fStack_168 + *(float *)(iVar32 + 0x68);
                    fStack_15c = fStack_164 + *(float *)(iVar32 + 0x6c);
                    fStack_178 = *(float *)(var_258h + 0x60);
                    fStack_174 = *(float *)(var_258h + 100);
                    fStack_170 = fStack_178 + *(float *)(var_258h + 0x68);
                    fStack_16c = fStack_174 + *(float *)(var_258h + 0x6c);
                    cVar14 = func_0x0001800f4180(&fStack_168, &fStack_178);
                }
                if (((*(int32_t *)
                       (*(int64_t *)(*(int32_t **)((int64_t)piVar23 + 800) + 2) + -0x20 +
                       (int64_t)**(int32_t **)((int64_t)piVar23 + 800) * 0x48) == 0) &&
                    (*(int32_t *)(*(int64_t *)(iVar25 + 800) + 0x20) != 0)) && (cVar14 == '\0')) {
                    bVar8 = true;
                    *(int64_t *)((int64_t)piVar23 + 800) = *(int64_t *)(iVar25 + 800);
                }
            }
            cVar14 = (char)var_278h;
            var_298h = CONCAT44(var_298h._4_4_, (float)(int32_t)fVar60);
            var_2a0h = (int64_t)auStack_f8;
            var_2a8h = CONCAT44(var_2a8h._4_4_, uVar22);
            fcn.180100c60((int64_t)piVar23, (int64_t)&fStack_218, CONCAT44(var_270h._4_4_, (uint32_t)var_270h), var_260h
                          , var_258h, CONCAT44(var_250h._4_4_, (float)var_250h), in_stack_fffffffffffffdb8, arg1);
            if (bVar8) {
                *(int64_t *)((int64_t)piVar23 + 800) = (int64_t)piVar23 + 0x328;
            }
        }
        if (((uVar21 & 8) == 0) && ((uVar21 >> 0xb & 1) != 0)) {
            bVar8 = true;
        } else {
            bVar8 = false;
        }
        fVar53 = *(float *)((int64_t)piVar23 + 0x88);
        if (*(float *)((int64_t)piVar23 + 0x88) == 0.0) {
            fVar62 = (*(float *)((int64_t)piVar23 + 0x68) -
                     (*(float *)((int64_t)piVar23 + 0x90) + *(float *)((int64_t)piVar23 + 0x90))) -
                     (*(float *)((int64_t)piVar23 + 0xb0) + *(float *)((int64_t)piVar23 + 0xa8));
            if (bVar8) {
                fVar53 = *(float *)((int64_t)piVar23 + 0x78);
            } else {
                fVar53 = 0.0;
            }
            if (fVar53 <= fVar62) {
                fVar53 = fVar62;
            }
        }
        fVar62 = *(float *)((int64_t)piVar23 + 0x8c);
        if (*(float *)((int64_t)piVar23 + 0x8c) == 0.0) {
            fVar60 = (*(float *)((int64_t)piVar23 + 0x6c) -
                     (*(float *)((int64_t)piVar23 + 0x94) + *(float *)((int64_t)piVar23 + 0x94))) -
                     (*(float *)((int64_t)piVar23 + 0xb4) + *(float *)((int64_t)piVar23 + 0xac));
            if ((uVar21 & 8) == 0) {
                fVar62 = *(float *)((int64_t)piVar23 + 0x7c);
            } else {
                fVar62 = 0.0;
            }
            if (fVar62 <= fVar60) {
                fVar62 = fVar60;
            }
        }
        fVar60 = *(float *)((int64_t)piVar23 + 0x90);
        if (*(float *)((int64_t)piVar23 + 0x90) <= *(float *)((int64_t)piVar23 + 0x9c)) {
            fVar60 = *(float *)((int64_t)piVar23 + 0x9c);
        }
        *(float *)((int64_t)piVar23 + 0x298) =
             (float)(int32_t)(fVar60 + (*(float *)((int64_t)piVar23 + 0x278) - *(float *)((int64_t)piVar23 + 0xd4)));
        fVar60 = *(float *)((int64_t)piVar23 + 0x94);
        if (*(float *)((int64_t)piVar23 + 0x94) <= *(float *)((int64_t)piVar23 + 0x9c)) {
            fVar60 = *(float *)((int64_t)piVar23 + 0x9c);
        }
        *(float *)((int64_t)piVar23 + 0x29c) =
             (float)(int32_t)((*(float *)((int64_t)piVar23 + 0x27c) - *(float *)((int64_t)piVar23 + 0xd8)) + fVar60);
        *(float *)((int64_t)piVar23 + 0x2a0) = fVar53 + *(float *)((int64_t)piVar23 + 0x298);
        *(float *)((int64_t)piVar23 + 0x2a4) = fVar62 + *(float *)((int64_t)piVar23 + 0x29c);
        *(undefined4 *)((int64_t)piVar23 + 0x2a8) = *(undefined4 *)((int64_t)piVar23 + 0x298);
        *(undefined4 *)((int64_t)piVar23 + 0x2ac) = *(undefined4 *)((int64_t)piVar23 + 0x29c);
        *(undefined4 *)((int64_t)piVar23 + 0x2b0) = *(undefined4 *)((int64_t)piVar23 + 0x2a0);
        *(undefined4 *)((int64_t)piVar23 + 0x2b4) = *(undefined4 *)((int64_t)piVar23 + 0x2a4);
        *(float *)((int64_t)piVar23 + 0x2c8) =
             (*(float *)((int64_t)piVar23 + 0x60) - *(float *)((int64_t)piVar23 + 0xd4)) +
             *(float *)((int64_t)piVar23 + 0x90) + *(float *)((int64_t)piVar23 + 0xa8);
        *(float *)((int64_t)piVar23 + 0x2cc) =
             (*(float *)((int64_t)piVar23 + 100) - *(float *)((int64_t)piVar23 + 0xd8)) +
             *(float *)((int64_t)piVar23 + 0x94) + *(float *)((int64_t)piVar23 + 0xac);
        fVar53 = *(float *)((int64_t)piVar23 + 0x88);
        if (fVar53 == 0.0) {
            fVar53 = (*(float *)((int64_t)piVar23 + 0x68) -
                     (*(float *)((int64_t)piVar23 + 0x90) + *(float *)((int64_t)piVar23 + 0x90))) -
                     (*(float *)((int64_t)piVar23 + 0xb0) + *(float *)((int64_t)piVar23 + 0xa8));
        }
        *(float *)((int64_t)piVar23 + 0x2d0) = fVar53 + *(float *)((int64_t)piVar23 + 0x2c8);
        fVar53 = *(float *)((int64_t)piVar23 + 0x8c);
        if (fVar53 == 0.0) {
            fVar53 = (*(float *)((int64_t)piVar23 + 0x6c) -
                     (*(float *)((int64_t)piVar23 + 0x94) + *(float *)((int64_t)piVar23 + 0x94))) -
                     (*(float *)((int64_t)piVar23 + 0xb4) + *(float *)((int64_t)piVar23 + 0xac));
        }
        *(float *)((int64_t)piVar23 + 0x2d4) = fVar53 + *(float *)((int64_t)piVar23 + 0x2cc);
        *(float *)((int64_t)piVar23 + 0x19c) =
             (*(float *)((int64_t)piVar23 + 0xa8) + *(float *)((int64_t)piVar23 + 0x90)) -
             *(float *)((int64_t)piVar23 + 0xd4);
        *(undefined8 *)((int64_t)piVar23 + 0x1a0) = 0;
        fVar62 = ((*(float *)((int64_t)piVar23 + 0x90) + *(float *)((int64_t)piVar23 + 0x60)) -
                 *(float *)((int64_t)piVar23 + 0xd4)) + *(float *)((int64_t)piVar23 + 0xa8) + 0.0;
        fVar53 = ((*(float *)((int64_t)piVar23 + 0x94) + *(float *)((int64_t)piVar23 + 100)) -
                 *(float *)((int64_t)piVar23 + 0xd8)) + *(float *)((int64_t)piVar23 + 0xac);
        *(float *)((int64_t)piVar23 + 0x168) = fVar62;
        *(float *)((int64_t)piVar23 + 0x16c) = fVar53;
        *(float *)((int64_t)piVar23 + 0x1a8) = fVar62 - *(float *)((int64_t)piVar23 + 0x168);
        *(float *)((int64_t)piVar23 + 0x1ac) = fVar53 - *(float *)((int64_t)piVar23 + 0x16c);
        uVar20 = *(undefined4 *)((int64_t)piVar23 + 0x168);
        uVar55 = *(undefined4 *)((int64_t)piVar23 + 0x16c);
        *(undefined4 *)((int64_t)piVar23 + 0x158) = uVar20;
        *(undefined4 *)((int64_t)piVar23 + 0x15c) = uVar55;
        *(undefined4 *)((int64_t)piVar23 + 0x160) = uVar20;
        *(undefined4 *)((int64_t)piVar23 + 0x164) = uVar55;
        *(undefined4 *)((int64_t)piVar23 + 0x170) = uVar20;
        *(undefined4 *)((int64_t)piVar23 + 0x174) = uVar55;
        *(undefined4 *)((int64_t)piVar23 + 0x178) = uVar20;
        *(undefined4 *)((int64_t)piVar23 + 0x17c) = uVar55;
        *(undefined8 *)((int64_t)piVar23 + 0x188) = 0;
        *(undefined8 *)((int64_t)piVar23 + 0x180) = 0;
        *(undefined8 *)((int64_t)piVar23 + 400) = 0;
        *(undefined2 *)((int64_t)piVar23 + 0x198) = 0;
        *(undefined4 *)((int64_t)piVar23 + 0x1b0) = 0;
        *(undefined2 *)((int64_t)piVar23 + 0x1b4) = *(undefined2 *)((int64_t)piVar23 + 0x1b6);
        *(undefined4 *)((int64_t)piVar23 + 0x1b6) = 0x10000;
        *(bool *)((int64_t)piVar23 + 0x1ba) = 0.0 < *(float *)((int64_t)piVar23 + 0xe0);
        *(undefined *)((int64_t)piVar23 + 0x1bb) = 0;
        puVar43 = (undefined4 *)((int64_t)piVar23 + 0x1c4);
        fVar53 = *(float *)(iVar12 + 0xdec);
        if (var_286h != '\0') {
            *(undefined8 *)((int64_t)piVar23 + 0x1d6) = 0;
        }
        *(int16_t *)((int64_t)piVar23 + 0x1cc) = (int16_t)(int32_t)fVar53;
        func_0x000180147d90(puVar43);
        *(undefined8 *)((int64_t)puVar43 + 0x12) = 0;
        *puVar43 = puVar43[1];
        puVar43[1] = 0;
        *(undefined8 *)((int64_t)piVar23 + 0x1e0) = 0;
        *(undefined4 *)((int64_t)piVar23 + 0x1e8) = 0;
        func_0x00018011f560((int64_t)piVar23 + 0x1f0);
        iVar25 = var_268h;
        *(int64_t *)((int64_t)piVar23 + 0x200) = (int64_t)piVar23 + 0x2f0;
        *(undefined8 *)((int64_t)piVar23 + 0x208) = 0;
        uVar20 = 1;
        *(undefined4 *)((int64_t)piVar23 + 0x214) = 1;
        if (var_268h != 0) {
            uVar20 = *(undefined4 *)(var_268h + 0x214);
        }
        *(undefined4 *)((int64_t)piVar23 + 0x218) = uVar20;
        fVar53 = *(float *)((int64_t)piVar23 + 0x68);
        if ((uVar21 >> 0x18 & 1) == 0) {
            if ((fVar53 <= 0.0) || ((uVar21 & 0x40) != 0)) goto code_r0x000180105198;
code_r0x000180105306:
            fVar53 = fVar53 * 0.65;
        } else {
            if ((fVar53 <= 0.0) || ((*(uint8_t *)((int64_t)piVar23 + 0x1c) & 0x50) != 0)) {
                bVar8 = false;
            } else {
                bVar8 = true;
            }
            if (bVar8) goto code_r0x000180105306;
code_r0x000180105198:
            fVar53 = *(float *)(iVar12 + 0x12f8) * 16.0;
        }
        *(float *)((int64_t)piVar23 + 0x240) = (float)(int32_t)fVar53;
        *(float *)((int64_t)piVar23 + 0x23c) = (float)(int32_t)fVar53;
        func_0x00018011f5a0((int64_t)piVar23 + 0x248);
        *(undefined4 *)((int64_t)piVar23 + 0x244) = 0xbf800000;
        func_0x00018011f5a0((int64_t)piVar23 + 600);
        if ((uVar21 >> 0x1b & 1) != 0) {
            uVar20 = func_0x0001800f5fa0(*(int64_t *)0x180781f28 + 0x12a0);
            *(undefined4 *)((int64_t)piVar23 + 0x21c) = uVar20;
        }
        if ('\0' < *(char *)((int64_t)piVar23 + 0x128)) {
            *(char *)((int64_t)piVar23 + 0x128) = *(char *)((int64_t)piVar23 + 0x128) + -1;
        }
        if ('\0' < *(char *)((int64_t)piVar23 + 0x129)) {
            *(char *)((int64_t)piVar23 + 0x129) = *(char *)((int64_t)piVar23 + 0x129) + -1;
        }
        *(undefined4 *)(iVar12 + 0x2008) = 0;
        if ((cVar14 != '\0') && (func_0x00018010e050(piVar23), piVar23 == (int64_t *)*(int64_t *)(iVar12 + 0x21d8))) {
            func_0x00018010ee50(piVar23);
        }
        if ((((*(char *)(iVar12 + 0x94) != '\0') && (*(int64_t *)(iVar12 + 0x21d8) != 0)) &&
            ((int64_t *)*(int64_t *)(*(int64_t *)(iVar12 + 0x21d8) + 0x418) == piVar23)) &&
           ((*(int32_t *)(iVar12 + 0x1654) == 0 && (cVar14 = func_0x000180109d80(0x1224, 0, 0), cVar14 != '\0')))) {
            func_0x000180112700();
        }
        fVar62 = fStack_20c;
        fVar53 = fStack_214;
        iVar32 = *(int64_t *)0x180781f28;
        if ((uVar21 & 1) == 0) {
            if ((*(uint8_t *)((int64_t)piVar23 + 0x495) & 1) == 0) {
                fVar60 = *(float *)((int64_t)piVar23 + 0x9c) + fStack_218;
                fVar54 = fStack_210 - *(float *)((int64_t)piVar23 + 0x9c);
                uVar22 = *(uint32_t *)((int64_t)piVar23 + 0x14);
                if (((uVar22 & 0x20) == 0) && (*(int32_t *)(*(int64_t *)0x180781f28 + 0xdc8) != -1)) {
                    bVar8 = true;
                } else {
                    bVar8 = false;
                }
                uVar36 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78);
                *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) = uVar36 | 4;
                *(undefined4 *)((int64_t)piVar23 + 0x1b0) = 1;
                fVar65 = *(float *)(iVar32 + 0xddc);
                fVar61 = *(float *)(iVar32 + 0x12f8);
                fVar63 = fVar65;
                if (bVar8) {
                    if (*(int32_t *)(iVar32 + 0xdc8) == 1) {
                        fVar65 = fVar61 + *(float *)(iVar32 + 0xdf4) + fVar65;
                    } else if (*(int32_t *)(iVar32 + 0xdc8) == 0) {
                        fVar63 = fVar61 + *(float *)(iVar32 + 0xdf4) + fVar65;
                    }
                    uVar20 = func_0x0001800f5a90(0x180644220, 0, 
                                                 *(undefined4 *)
                                                  (*(int64_t *)((int64_t)piVar23 + 0x150) + -4 +
                                                  (int64_t)*(int32_t *)((int64_t)piVar23 + 0x148) * 4));
                    cVar14 = func_0x00018013afb0(uVar20, &stack0xfffffffffffffdb8, 0);
                    if (cVar14 != '\0') {
                        *(undefined *)((int64_t)piVar23 + 0x10d) = 1;
                    }
                }
                *(undefined4 *)((int64_t)piVar23 + 0x1b0) = 0;
                *(uint32_t *)(iVar32 + 0x1f78) = uVar36;
                if ((uVar22 >> 0x12 & 1) == 0) {
                    fVar61 = 0.0;
                } else {
                    fVar61 = fVar61 * 0.8;
                }
                var_2a8h = CONCAT44(var_2a8h._4_4_, 0xbf800000);
                pfVar29 = (float *)func_0x0001800fe0a0(auStack_100, arg1, 0, 1);
                fStack_1d0 = fVar61 + *pfVar29;
                fStack_1cc = pfVar29[1] + 0.0;
                if (*(float *)(iVar32 + 0xddc) < fVar63) {
                    fVar63 = fVar63 + *(float *)(iVar32 + 0xdf4);
                }
                if (*(float *)(iVar32 + 0xddc) < fVar65) {
                    fVar65 = fVar65 + *(float *)(iVar32 + 0xdf4);
                }
                fVar56 = *(float *)(iVar32 + 0xdc0);
                if ((0.0 < fVar56) && (fVar56 < 1.0)) {
                    fVar57 = (float)((uint32_t)(fVar56 - 0.5) & 0x7fffffff);
                    fVar57 = 1.0 - (fVar57 + fVar57);
                    if (0.0 <= fVar57) {
                        fVar64 = 1.0;
                        if (fVar57 <= 1.0) {
                            fVar64 = fVar57;
                        }
                    } else {
                        fVar64 = 0.0;
                    }
                    fVar57 = fVar63;
                    if (fVar63 <= fVar65) {
                        fVar57 = fVar65;
                    }
                    fVar58 = (((fVar54 - fVar60) - fVar63) - fVar65) - fStack_1d0;
                    if (fVar58 <= fVar57) {
                        fVar57 = fVar58;
                    }
                    fVar57 = fVar57 * fVar64;
                    if (fVar63 <= fVar57) {
                        fVar63 = fVar57;
                    }
                    if (fVar65 <= fVar57) {
                        fVar65 = fVar57;
                    }
                }
                fStack_1b8 = fVar60 + fVar63;
                fStack_1a4 = fVar53;
                fStack_1a0 = fVar54 - fVar65;
                fStack_19c = fVar62;
                fVar60 = fStack_1a0 + *(float *)(iVar32 + 0xdf4);
                if (fVar54 <= fVar60) {
                    fVar60 = fVar54;
                }
                fStack_1b4 = fVar53;
                fStack_1ac = fVar62;
                fStack_1b0 = fVar60;
                fStack_1a8 = fStack_1b8;
                if ((uVar22 >> 0x12 & 1) != 0) {
                    fVar65 = ((fStack_1a0 - fStack_1b8) - fStack_1d0) * fVar56 + fStack_1b8 + fStack_1d0;
                    fVar54 = fStack_1b8;
                    if ((fStack_1b8 <= fVar65) && (fVar54 = fStack_1a0, fVar65 <= fStack_1a0)) {
                        fVar54 = fVar65;
                    }
                    if (fStack_1b8 < fVar54) {
                        uStack_140 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1260);
                        uStack_13c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1264);
                        uStack_138 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1268);
                        fStack_134 = *(float *)(*(int64_t *)0x180781f28 + 0x126c) *
                                     *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                        uVar20 = func_0x0001800f5fa0(&uStack_140);
                        func_0x000180130370(*(undefined8 *)((int64_t)piVar23 + 800), 
                                            CONCAT44((fVar62 + fVar53) * 0.5, fVar54), uVar20);
                        fVar54 = fVar54 - (float)(int32_t)(fVar61 * 0.5);
                        fStack_1b0 = fVar60;
                        if (fVar54 <= fVar60) {
                            fStack_1b0 = fVar54;
                        }
                    }
                }
                var_2a0h = iVar32 + 0xdc0;
                var_298h = (int64_t)&fStack_1b8;
                var_2a8h = (int64_t)&fStack_1d0;
                func_0x0001800f7200(&fStack_1a8, &fStack_1a0, arg1, 0);
            } else {
                for (pcVar41 = *(char **)((int64_t)piVar23 + 8);
                    ((pcVar41 != (char *)0xffffffffffffffff && (*pcVar41 != '\0')) &&
                    ((*pcVar41 != '#' || (pcVar41[1] != '#')))); pcVar41 = pcVar41 + 1) {
                }
                func_0x0001801124e0(0x180644508, (int32_t)pcVar41 - *(int32_t *)((int64_t)piVar23 + 8));
            }
        }
        *(undefined4 *)((int64_t)piVar23 + 0x2d8) = 0;
        if ((uVar21 >> 0x19 & 1) != 0) {
            *(int64_t **)(iVar12 + 0x2820) = piVar23;
        }
        iVar32 = *(int64_t *)0x180781f28;
        if ((*(uint8_t *)(iVar12 + 0x30) & 0x80) != 0) {
            if (((int64_t *)*(int64_t *)(iVar12 + 0x1600) == piVar23) &&
               ((*(uint32_t *)(*(int64_t *)((int64_t)piVar23 + 0x428) + 0x14) & 0x80000) == 0)) {
                cVar14 = *(char *)(*(int64_t *)0x180781f28 + 0x82);
                if (cVar14 == *(char *)(*(int64_t *)0x180781f28 + 0x139)) {
                    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fb8) = *(undefined4 *)((int64_t)piVar23 + 0xc4);
                    piStack_1e8 = *(int64_t **)((int64_t)piVar23 + 0x428);
                    if (((cVar14 != '\0') ||
                        ((((0.0 <= *(float *)(iVar32 + 0x166c) && (0.0 <= *(float *)(iVar32 + 0x1670))) &&
                          (*(float *)(iVar32 + 0x166c) < *(float *)(piStack_1e8 + 0xe))) &&
                         (*(float *)(iVar32 + 0x1670) <
                          *(float *)(iVar32 + 0xde0) + *(float *)(iVar32 + 0xde0) + *(float *)(iVar32 + 0x12f8))))) &&
                       (cVar14 = func_0x000180112150(), cVar14 != '\0')) {
                        func_0x0001801122b0(extraout_XMM0_Qa_00, &piStack_1e8);
                        func_0x000180112270();
                        func_0x00018011cdb0(piStack_1e8);
                    }
                } else if (((cVar14 != '\0') && (1.0 <= *(float *)(*(int64_t *)0x180781f28 + 0x2654))) &&
                          (1.0 <= (float)(uint64_t)*(uint32_t *)(*(int64_t *)0x180781f28 + 0x1654))) {
                    iVar32 = 0x180644210;
                    if (*(int64_t *)(*(int64_t *)0x180781f28 + 0x29e8) != 0) {
                        iVar32 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x29e8);
                    }
                    func_0x00018010ce60(0x18063cc8c, iVar32);
                }
            }
            if (((*(char *)(iVar12 + 0x2400) != '\0') && ((uVar21 >> 0x13 & 1) == 0)) &&
               (((*(int64_t *)(iVar12 + 0x1600) == 0 ||
                 ((int64_t *)*(int64_t *)(*(int64_t *)(iVar12 + 0x1600) + 0x428) != piVar23)) &&
                ((piVar23 == (int64_t *)*(int64_t *)((int64_t)piVar23 + 0x428) &&
                 ((*(uint32_t *)((int64_t)piVar23 + 0x14) & 0x800000) == 0)))))) {
                func_0x00018011d040(piVar23);
            }
        }
        if ((uVar21 >> 0x18 & 1) == 0) {
            uVar52 = *(char *)(iVar12 + 0x93) == '\0';
        } else {
            uVar52 = *(undefined *)(iVar25 + 0x130);
        }
        *(undefined *)((int64_t)piVar23 + 0x130) = uVar52;
        *(undefined4 *)((int64_t)piVar23 + 0x220) = 0;
        uVar17 = func_0x000180108120(&fStack_218, &fStack_210, 0);
        *(uint32_t *)((int64_t)piVar23 + 0x220) = *(uint32_t *)((int64_t)piVar23 + 0x220) | (uint32_t)uVar17;
        func_0x0001800fa750(piVar23, &fStack_218);
        iVar18 = (int32_t)var_280h;
        iVar42 = var_280h._4_4_;
    }
    if (((uVar21 >> 0x17 & 1) == 0) && (*(char *)((int64_t)piVar23 + 0x10f) == '\0')) {
        func_0x0001800fc860(piVar23 + 0x51, piVar23 + 0x52, 1);
    }
    *(undefined *)((int64_t)piVar23 + 0x10b) = 0;
    *(int16_t *)(piVar23 + 0x23) = *(int16_t *)(piVar23 + 0x23) + 1;
    if (iVar42 == iVar18) goto code_r0x000180105bab;
    if (*(char *)((int64_t)piVar23 + 0x10f) != '\0') {
        *(undefined *)((int64_t)piVar23 + 0x10e) = 1;
        goto code_r0x000180105bab;
    }
    if ((*(uint8_t *)((int64_t)piVar23 + 0x495) & 5) == 1) {
        if (*(int32_t *)((int64_t)piVar23 + 0x2e4) == *(int32_t *)(iVar12 + 4)) {
            *(undefined *)((int64_t)piVar23 + 300) = 1;
        } else {
            *(undefined *)((int64_t)piVar23 + 299) = 1;
        }
    }
    if ((uVar21 & 0x11000000) == 0x1000000) {
        if (((((*(uint32_t *)((int64_t)piVar23 + 0x1c) & 0x100) == 0) || (*(char *)(iVar12 + 0x2239) == '\0')) ||
            (*(int64_t *)(iVar12 + 0x21d8) == 0)) ||
           (*(int64_t *)(*(int64_t *)(iVar12 + 0x21d8) + 0x438) != piVar23[0x87])) {
            bVar8 = false;
        } else {
            bVar8 = true;
        }
        if (((*(char *)(iVar12 + 0x29f8) == '\0') && (!bVar8)) &&
           ((*(float *)(piVar23 + 0x4e) <= *(float *)(piVar23 + 0x4d) ||
            (*(float *)((int64_t)piVar23 + 0x274) <= *(float *)((int64_t)piVar23 + 0x26c))))) {
            if ((*(char *)(piVar23 + 0x25) < '\x01') && (*(char *)((int64_t)piVar23 + 0x129) < '\x01')) {
                *(undefined *)((int64_t)piVar23 + 299) = 1;
            } else {
                *(undefined *)((int64_t)piVar23 + 300) = 1;
            }
        }
        if (iVar25 != 0) {
            if ((*(char *)(iVar25 + 0x10c) != '\0') || ('\0' < *(char *)(iVar25 + 299))) {
                *(undefined *)((int64_t)piVar23 + 299) = 1;
            }
            if ('\0' < *(char *)(iVar25 + 300)) {
                *(undefined *)((int64_t)piVar23 + 300) = 1;
            }
        }
    }
    if (*(float *)(iVar12 + 0xd9c) <= 0.0) {
        *(undefined *)((int64_t)piVar23 + 299) = 1;
    }
    if ((*(char *)((int64_t)piVar23 + 299) < '\x01') && (*(char *)((int64_t)piVar23 + 300) < '\x01')) {
        bVar8 = false;
        if ('\0' < *(char *)((int64_t)piVar23 + 0x12d)) goto code_r0x000180105b31;
        uVar52 = 0;
    } else {
        bVar8 = true;
code_r0x000180105b31:
        uVar52 = 1;
    }
    *(undefined *)((int64_t)piVar23 + 0x111) = uVar52;
    if ('\0' < *(char *)((int64_t)piVar23 + 0x12e)) {
        *(char *)((int64_t)piVar23 + 0x12e) = *(char *)((int64_t)piVar23 + 0x12e) + -1;
        *(uint32_t *)((int64_t)piVar23 + 0x14) = *(uint32_t *)((int64_t)piVar23 + 0x14) | 0x30200;
    }
    if (((((*(char *)((int64_t)piVar23 + 0x10c) == '\0') && (*(char *)((int64_t)piVar23 + 0x109) != '\0')) && (!bVar8))
        || (('\0' < *(char *)(piVar23 + 0x25) || ('\0' < *(char *)((int64_t)piVar23 + 0x129))))) ||
       ('\0' < *(char *)((int64_t)piVar23 + 300))) {
        *(undefined *)((int64_t)piVar23 + 0x10e) = 0;
    } else {
        *(undefined *)((int64_t)piVar23 + 0x10e) = 1;
        *(undefined2 *)((int64_t)piVar23 + 0x1b6) = *(undefined2 *)((int64_t)piVar23 + 0x1b4);
    }
code_r0x000180105bab:
    func_0x000180459870(uStack_e8 ^ (uint64_t)auStackY_2c8);
    return;
}

// ============================================================
// Function: FUN_180105c20
// Address: 0x180105c20
// Size: 76 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180105c20(void)
{
    undefined4 *puVar1;
    float fVar2;
    float fVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    int32_t iVar11;
    uint32_t uVar12;
    undefined8 uVar13;
    int64_t iVar14;
    int64_t iVar15;
    undefined4 uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar8 = *(int64_t *)0x180781f28;
    if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x15b0) < 2) && (*(char *)(*(int64_t *)0x180781f28 + 2) != '\0')) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180105c69. Too many branches
    // WARNING: Treating indirect jump as call
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644510);
            return;
        }
    } else {
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        iVar6 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15b8);
        iVar15 = (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x15b0) * 0x78;
        uVar12 = *(uint32_t *)(iVar5 + 0x14);
        if (((uVar12 >> 0x1a & 1) != 0) &&
           ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x154c) != *(int32_t *)(iVar5 + 0x10) &&
            (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0)))) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644530);
            uVar12 = *(uint32_t *)(iVar5 + 0x14);
        }
        if (((((uVar12 & 0x1800000) == 0x1000000) && ((*(uint8_t *)(iVar5 + 0x495) & 1) == 0)) &&
            (*(int32_t *)(iVar8 + 0x1548) != *(int32_t *)(iVar5 + 0x10))) &&
           (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0)) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644558);
        }
        if (*(int64_t *)(iVar5 + 0x208) != 0) {
            func_0x000180138d00();
        }
        if (((*(uint32_t *)(iVar5 + 0x14) & 0x800000) == 0) && (*(char *)(iVar5 + 0x10f) == '\0')) {
            func_0x0001800fc8f0();
        }
        func_0x0001801067d0();
        iVar7 = *(int64_t *)0x180781f28;
        if ((*(char *)(iVar6 + -10 + iVar15) != '\0') && (*(int64_t *)(iVar5 + 0x418) == iVar5)) {
            *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) = *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) + -1;
            iVar4 = *(int32_t *)(iVar7 + 0x2100);
            *(int32_t *)(iVar7 + 0x2100) = iVar4 + -1;
            *(undefined4 *)(iVar7 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar7 + 0x2108) + -8 + (int64_t)iVar4 * 4);
            *(undefined4 *)(iVar7 + 0xd9c) =
                 *(undefined4 *)((int64_t)*(int32_t *)(iVar7 + 0x15b0) * 0x78 + -8 + *(int64_t *)(iVar7 + 0x15b8));
        }
        if (*(char *)(iVar5 + 0x10f) != '\0') {
            *(int64_t *)(iVar5 + 800) = iVar5 + 0x328;
        }
        uVar13 = 0;
        if ((*(int64_t *)(iVar8 + 0x2a00) == iVar5) && (*(char *)(iVar7 + 0x29f8) != '\0')) {
            func_0x0001801124e0(0x180644f68);
            uVar12 = *(uint32_t *)(iVar7 + 0x29fc) & 0xf;
            if (uVar12 == 1) {
                func_0x00018045fdf8(*(undefined8 *)(iVar7 + 0x2a08));
            } else if (uVar12 == 2) {
                func_0x00018045ff84(*(undefined8 *)(iVar7 + 0x2a08));
            } else if ((uVar12 == 8) && (1 < *(int32_t *)(iVar7 + 0x2a10))) {
                iVar14 = 0x180781edb;
                if (*(int64_t *)(iVar7 + 0x2a18) != 0) {
                    iVar14 = *(int64_t *)(iVar7 + 0x2a18);
                }
                if (*(code **)(*(int64_t *)0x180781f28 + 0xc50) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0xc50))(*(int64_t *)0x180781f28, iVar14);
                }
            }
            *(undefined *)(iVar7 + 0x1652) = 0;
            *(undefined *)(iVar7 + 0x29f8) = 0;
            *(undefined4 *)(iVar7 + 0x29fc) = 0;
            *(undefined8 *)(iVar7 + 0x2a08) = 0;
            if (*(int64_t *)(iVar7 + 0x2a18) != 0) {
                *(undefined8 *)(iVar7 + 0x2a10) = 0;
                func_0x000180460d90();
                *(undefined8 *)(iVar7 + 0x2a18) = 0;
            }
        }
        if (*(char *)(iVar5 + 0x199) != '\0') {
            func_0x000180109fd0();
        }
        if (((*(int64_t *)(iVar5 + 0x4c0) != 0) && ((*(uint8_t *)(iVar5 + 0x495) & 4) != 0)) &&
           (iVar7 = *(int64_t *)(*(int64_t *)(iVar5 + 0x4c0) + 0x98), iVar7 != 0)) {
            fVar2 = *(float *)(iVar5 + 0x170);
            fVar3 = *(float *)(iVar5 + 0x90);
            *(float *)(iVar7 + 0x174) =
                 (*(float *)(iVar5 + 0x174) + *(float *)(iVar5 + 0x94)) - *(float *)(iVar7 + 0x94);
            *(float *)(iVar7 + 0x170) = (fVar2 + fVar3) - *(float *)(iVar7 + 0x90);
        }
        puVar1 = (undefined4 *)(iVar6 + -0x70 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fb8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fbc) = uVar16;
        *(undefined4 *)(iVar8 + 0x1fc0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1fc4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x60 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fc8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fcc) = uVar16;
        *(undefined4 *)(iVar8 + 0x1fd0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1fd4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x50 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fd8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fdc) = uVar16;
        *(undefined4 *)(iVar8 + 0x1fe0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1fe4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x40 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fe8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fec) = uVar16;
        *(undefined4 *)(iVar8 + 0x1ff0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1ff4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x30 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1ff8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1ffc) = uVar16;
        *(undefined4 *)(iVar8 + 0x2000) = uVar9;
        *(undefined4 *)(iVar8 + 0x2004) = uVar10;
        if ((*(uint32_t *)(iVar5 + 0x14) & 0x10000000) != 0) {
            *(int32_t *)(iVar8 + 0x278c) = *(int32_t *)(iVar8 + 0x278c) + -1;
        }
        if ((*(uint32_t *)(iVar5 + 0x14) & 0x4000000) != 0) {
            *(int32_t *)(iVar8 + 0x2130) = *(int32_t *)(iVar8 + 0x2130) + -1;
        }
        if (*(char *)(iVar8 + 0xb0) != '\0') {
            func_0x00018010a070(iVar6 + -0x20 + iVar15);
        }
        iVar4 = *(int32_t *)(iVar8 + 0x15b0);
        iVar11 = iVar4 + -1;
        *(int32_t *)(iVar8 + 0x15b0) = iVar11;
        if (iVar11 != 0) {
            uVar13 = *(undefined8 *)(((int64_t)iVar4 + -2) * 0x78 + *(int64_t *)(iVar8 + 0x15b8));
        }
        func_0x0001800f9e20(uVar13);
        iVar5 = *(int64_t *)0x180781f28;
        if (*(int64_t *)(iVar8 + 0x15e0) != 0) {
            iVar8 = *(int64_t *)(*(int64_t *)(iVar8 + 0x15e0) + 0x48);
            if (iVar8 != 0) {
                *(undefined4 *)(iVar8 + 0x84) = *(undefined4 *)(*(int64_t *)0x180781f28 + 4);
            }
            if (*(int64_t *)(iVar5 + 0x2160) != iVar8) {
                if (iVar8 == 0) {
                    uVar16 = 0x3f800000;
                } else {
                    uVar16 = *(undefined4 *)(iVar8 + 0x30);
                }
                *(undefined4 *)(iVar5 + 0x1308) = uVar16;
                *(int64_t *)(iVar5 + 0x2160) = iVar8;
                if (*(char *)(iVar5 + 0x8a) != '\0') {
                    *(undefined4 *)(iVar5 + 0xd98) = uVar16;
                }
                if ((iVar8 != 0) && (*(code **)(iVar5 + 0xd20) != (code *)0x0)) {
    // WARNING: Could not recover jumptable at 0x000180106024. Too many branches
    // WARNING: Treating indirect jump as call
                    (**(code **)(iVar5 + 0xd20))();
                    return;
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180105c6c
// Address: 0x180105c6c
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180105c20(void)
{
    undefined4 *puVar1;
    float fVar2;
    float fVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    int32_t iVar11;
    uint32_t uVar12;
    undefined8 uVar13;
    int64_t iVar14;
    int64_t iVar15;
    undefined4 uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar8 = *(int64_t *)0x180781f28;
    if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x15b0) < 2) && (*(char *)(*(int64_t *)0x180781f28 + 2) != '\0')) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180105c69. Too many branches
    // WARNING: Treating indirect jump as call
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644510);
            return;
        }
    } else {
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        iVar6 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15b8);
        iVar15 = (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x15b0) * 0x78;
        uVar12 = *(uint32_t *)(iVar5 + 0x14);
        if (((uVar12 >> 0x1a & 1) != 0) &&
           ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x154c) != *(int32_t *)(iVar5 + 0x10) &&
            (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0)))) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644530);
            uVar12 = *(uint32_t *)(iVar5 + 0x14);
        }
        if (((((uVar12 & 0x1800000) == 0x1000000) && ((*(uint8_t *)(iVar5 + 0x495) & 1) == 0)) &&
            (*(int32_t *)(iVar8 + 0x1548) != *(int32_t *)(iVar5 + 0x10))) &&
           (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0)) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644558);
        }
        if (*(int64_t *)(iVar5 + 0x208) != 0) {
            func_0x000180138d00();
        }
        if (((*(uint32_t *)(iVar5 + 0x14) & 0x800000) == 0) && (*(char *)(iVar5 + 0x10f) == '\0')) {
            func_0x0001800fc8f0();
        }
        func_0x0001801067d0();
        iVar7 = *(int64_t *)0x180781f28;
        if ((*(char *)(iVar6 + -10 + iVar15) != '\0') && (*(int64_t *)(iVar5 + 0x418) == iVar5)) {
            *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) = *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) + -1;
            iVar4 = *(int32_t *)(iVar7 + 0x2100);
            *(int32_t *)(iVar7 + 0x2100) = iVar4 + -1;
            *(undefined4 *)(iVar7 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar7 + 0x2108) + -8 + (int64_t)iVar4 * 4);
            *(undefined4 *)(iVar7 + 0xd9c) =
                 *(undefined4 *)((int64_t)*(int32_t *)(iVar7 + 0x15b0) * 0x78 + -8 + *(int64_t *)(iVar7 + 0x15b8));
        }
        if (*(char *)(iVar5 + 0x10f) != '\0') {
            *(int64_t *)(iVar5 + 800) = iVar5 + 0x328;
        }
        uVar13 = 0;
        if ((*(int64_t *)(iVar8 + 0x2a00) == iVar5) && (*(char *)(iVar7 + 0x29f8) != '\0')) {
            func_0x0001801124e0(0x180644f68);
            uVar12 = *(uint32_t *)(iVar7 + 0x29fc) & 0xf;
            if (uVar12 == 1) {
                func_0x00018045fdf8(*(undefined8 *)(iVar7 + 0x2a08));
            } else if (uVar12 == 2) {
                func_0x00018045ff84(*(undefined8 *)(iVar7 + 0x2a08));
            } else if ((uVar12 == 8) && (1 < *(int32_t *)(iVar7 + 0x2a10))) {
                iVar14 = 0x180781edb;
                if (*(int64_t *)(iVar7 + 0x2a18) != 0) {
                    iVar14 = *(int64_t *)(iVar7 + 0x2a18);
                }
                if (*(code **)(*(int64_t *)0x180781f28 + 0xc50) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0xc50))(*(int64_t *)0x180781f28, iVar14);
                }
            }
            *(undefined *)(iVar7 + 0x1652) = 0;
            *(undefined *)(iVar7 + 0x29f8) = 0;
            *(undefined4 *)(iVar7 + 0x29fc) = 0;
            *(undefined8 *)(iVar7 + 0x2a08) = 0;
            if (*(int64_t *)(iVar7 + 0x2a18) != 0) {
                *(undefined8 *)(iVar7 + 0x2a10) = 0;
                func_0x000180460d90();
                *(undefined8 *)(iVar7 + 0x2a18) = 0;
            }
        }
        if (*(char *)(iVar5 + 0x199) != '\0') {
            func_0x000180109fd0();
        }
        if (((*(int64_t *)(iVar5 + 0x4c0) != 0) && ((*(uint8_t *)(iVar5 + 0x495) & 4) != 0)) &&
           (iVar7 = *(int64_t *)(*(int64_t *)(iVar5 + 0x4c0) + 0x98), iVar7 != 0)) {
            fVar2 = *(float *)(iVar5 + 0x170);
            fVar3 = *(float *)(iVar5 + 0x90);
            *(float *)(iVar7 + 0x174) =
                 (*(float *)(iVar5 + 0x174) + *(float *)(iVar5 + 0x94)) - *(float *)(iVar7 + 0x94);
            *(float *)(iVar7 + 0x170) = (fVar2 + fVar3) - *(float *)(iVar7 + 0x90);
        }
        puVar1 = (undefined4 *)(iVar6 + -0x70 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fb8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fbc) = uVar16;
        *(undefined4 *)(iVar8 + 0x1fc0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1fc4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x60 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fc8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fcc) = uVar16;
        *(undefined4 *)(iVar8 + 0x1fd0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1fd4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x50 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fd8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fdc) = uVar16;
        *(undefined4 *)(iVar8 + 0x1fe0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1fe4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x40 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fe8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fec) = uVar16;
        *(undefined4 *)(iVar8 + 0x1ff0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1ff4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x30 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1ff8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1ffc) = uVar16;
        *(undefined4 *)(iVar8 + 0x2000) = uVar9;
        *(undefined4 *)(iVar8 + 0x2004) = uVar10;
        if ((*(uint32_t *)(iVar5 + 0x14) & 0x10000000) != 0) {
            *(int32_t *)(iVar8 + 0x278c) = *(int32_t *)(iVar8 + 0x278c) + -1;
        }
        if ((*(uint32_t *)(iVar5 + 0x14) & 0x4000000) != 0) {
            *(int32_t *)(iVar8 + 0x2130) = *(int32_t *)(iVar8 + 0x2130) + -1;
        }
        if (*(char *)(iVar8 + 0xb0) != '\0') {
            func_0x00018010a070(iVar6 + -0x20 + iVar15);
        }
        iVar4 = *(int32_t *)(iVar8 + 0x15b0);
        iVar11 = iVar4 + -1;
        *(int32_t *)(iVar8 + 0x15b0) = iVar11;
        if (iVar11 != 0) {
            uVar13 = *(undefined8 *)(((int64_t)iVar4 + -2) * 0x78 + *(int64_t *)(iVar8 + 0x15b8));
        }
        func_0x0001800f9e20(uVar13);
        iVar5 = *(int64_t *)0x180781f28;
        if (*(int64_t *)(iVar8 + 0x15e0) != 0) {
            iVar8 = *(int64_t *)(*(int64_t *)(iVar8 + 0x15e0) + 0x48);
            if (iVar8 != 0) {
                *(undefined4 *)(iVar8 + 0x84) = *(undefined4 *)(*(int64_t *)0x180781f28 + 4);
            }
            if (*(int64_t *)(iVar5 + 0x2160) != iVar8) {
                if (iVar8 == 0) {
                    uVar16 = 0x3f800000;
                } else {
                    uVar16 = *(undefined4 *)(iVar8 + 0x30);
                }
                *(undefined4 *)(iVar5 + 0x1308) = uVar16;
                *(int64_t *)(iVar5 + 0x2160) = iVar8;
                if (*(char *)(iVar5 + 0x8a) != '\0') {
                    *(undefined4 *)(iVar5 + 0xd98) = uVar16;
                }
                if ((iVar8 != 0) && (*(code **)(iVar5 + 0xd20) != (code *)0x0)) {
    // WARNING: Could not recover jumptable at 0x000180106024. Too many branches
    // WARNING: Treating indirect jump as call
                    (**(code **)(iVar5 + 0xd20))();
                    return;
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180105c71
// Address: 0x180105c71
// Size: 540 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180105c20(void)
{
    undefined4 *puVar1;
    float fVar2;
    float fVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    int32_t iVar11;
    uint32_t uVar12;
    undefined8 uVar13;
    int64_t iVar14;
    int64_t iVar15;
    undefined4 uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar8 = *(int64_t *)0x180781f28;
    if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x15b0) < 2) && (*(char *)(*(int64_t *)0x180781f28 + 2) != '\0')) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180105c69. Too many branches
    // WARNING: Treating indirect jump as call
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644510);
            return;
        }
    } else {
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        iVar6 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15b8);
        iVar15 = (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x15b0) * 0x78;
        uVar12 = *(uint32_t *)(iVar5 + 0x14);
        if (((uVar12 >> 0x1a & 1) != 0) &&
           ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x154c) != *(int32_t *)(iVar5 + 0x10) &&
            (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0)))) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644530);
            uVar12 = *(uint32_t *)(iVar5 + 0x14);
        }
        if (((((uVar12 & 0x1800000) == 0x1000000) && ((*(uint8_t *)(iVar5 + 0x495) & 1) == 0)) &&
            (*(int32_t *)(iVar8 + 0x1548) != *(int32_t *)(iVar5 + 0x10))) &&
           (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0)) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644558);
        }
        if (*(int64_t *)(iVar5 + 0x208) != 0) {
            func_0x000180138d00();
        }
        if (((*(uint32_t *)(iVar5 + 0x14) & 0x800000) == 0) && (*(char *)(iVar5 + 0x10f) == '\0')) {
            func_0x0001800fc8f0();
        }
        func_0x0001801067d0();
        iVar7 = *(int64_t *)0x180781f28;
        if ((*(char *)(iVar6 + -10 + iVar15) != '\0') && (*(int64_t *)(iVar5 + 0x418) == iVar5)) {
            *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) = *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) + -1;
            iVar4 = *(int32_t *)(iVar7 + 0x2100);
            *(int32_t *)(iVar7 + 0x2100) = iVar4 + -1;
            *(undefined4 *)(iVar7 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar7 + 0x2108) + -8 + (int64_t)iVar4 * 4);
            *(undefined4 *)(iVar7 + 0xd9c) =
                 *(undefined4 *)((int64_t)*(int32_t *)(iVar7 + 0x15b0) * 0x78 + -8 + *(int64_t *)(iVar7 + 0x15b8));
        }
        if (*(char *)(iVar5 + 0x10f) != '\0') {
            *(int64_t *)(iVar5 + 800) = iVar5 + 0x328;
        }
        uVar13 = 0;
        if ((*(int64_t *)(iVar8 + 0x2a00) == iVar5) && (*(char *)(iVar7 + 0x29f8) != '\0')) {
            func_0x0001801124e0(0x180644f68);
            uVar12 = *(uint32_t *)(iVar7 + 0x29fc) & 0xf;
            if (uVar12 == 1) {
                func_0x00018045fdf8(*(undefined8 *)(iVar7 + 0x2a08));
            } else if (uVar12 == 2) {
                func_0x00018045ff84(*(undefined8 *)(iVar7 + 0x2a08));
            } else if ((uVar12 == 8) && (1 < *(int32_t *)(iVar7 + 0x2a10))) {
                iVar14 = 0x180781edb;
                if (*(int64_t *)(iVar7 + 0x2a18) != 0) {
                    iVar14 = *(int64_t *)(iVar7 + 0x2a18);
                }
                if (*(code **)(*(int64_t *)0x180781f28 + 0xc50) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0xc50))(*(int64_t *)0x180781f28, iVar14);
                }
            }
            *(undefined *)(iVar7 + 0x1652) = 0;
            *(undefined *)(iVar7 + 0x29f8) = 0;
            *(undefined4 *)(iVar7 + 0x29fc) = 0;
            *(undefined8 *)(iVar7 + 0x2a08) = 0;
            if (*(int64_t *)(iVar7 + 0x2a18) != 0) {
                *(undefined8 *)(iVar7 + 0x2a10) = 0;
                func_0x000180460d90();
                *(undefined8 *)(iVar7 + 0x2a18) = 0;
            }
        }
        if (*(char *)(iVar5 + 0x199) != '\0') {
            func_0x000180109fd0();
        }
        if (((*(int64_t *)(iVar5 + 0x4c0) != 0) && ((*(uint8_t *)(iVar5 + 0x495) & 4) != 0)) &&
           (iVar7 = *(int64_t *)(*(int64_t *)(iVar5 + 0x4c0) + 0x98), iVar7 != 0)) {
            fVar2 = *(float *)(iVar5 + 0x170);
            fVar3 = *(float *)(iVar5 + 0x90);
            *(float *)(iVar7 + 0x174) =
                 (*(float *)(iVar5 + 0x174) + *(float *)(iVar5 + 0x94)) - *(float *)(iVar7 + 0x94);
            *(float *)(iVar7 + 0x170) = (fVar2 + fVar3) - *(float *)(iVar7 + 0x90);
        }
        puVar1 = (undefined4 *)(iVar6 + -0x70 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fb8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fbc) = uVar16;
        *(undefined4 *)(iVar8 + 0x1fc0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1fc4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x60 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fc8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fcc) = uVar16;
        *(undefined4 *)(iVar8 + 0x1fd0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1fd4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x50 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fd8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fdc) = uVar16;
        *(undefined4 *)(iVar8 + 0x1fe0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1fe4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x40 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fe8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fec) = uVar16;
        *(undefined4 *)(iVar8 + 0x1ff0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1ff4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x30 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1ff8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1ffc) = uVar16;
        *(undefined4 *)(iVar8 + 0x2000) = uVar9;
        *(undefined4 *)(iVar8 + 0x2004) = uVar10;
        if ((*(uint32_t *)(iVar5 + 0x14) & 0x10000000) != 0) {
            *(int32_t *)(iVar8 + 0x278c) = *(int32_t *)(iVar8 + 0x278c) + -1;
        }
        if ((*(uint32_t *)(iVar5 + 0x14) & 0x4000000) != 0) {
            *(int32_t *)(iVar8 + 0x2130) = *(int32_t *)(iVar8 + 0x2130) + -1;
        }
        if (*(char *)(iVar8 + 0xb0) != '\0') {
            func_0x00018010a070(iVar6 + -0x20 + iVar15);
        }
        iVar4 = *(int32_t *)(iVar8 + 0x15b0);
        iVar11 = iVar4 + -1;
        *(int32_t *)(iVar8 + 0x15b0) = iVar11;
        if (iVar11 != 0) {
            uVar13 = *(undefined8 *)(((int64_t)iVar4 + -2) * 0x78 + *(int64_t *)(iVar8 + 0x15b8));
        }
        func_0x0001800f9e20(uVar13);
        iVar5 = *(int64_t *)0x180781f28;
        if (*(int64_t *)(iVar8 + 0x15e0) != 0) {
            iVar8 = *(int64_t *)(*(int64_t *)(iVar8 + 0x15e0) + 0x48);
            if (iVar8 != 0) {
                *(undefined4 *)(iVar8 + 0x84) = *(undefined4 *)(*(int64_t *)0x180781f28 + 4);
            }
            if (*(int64_t *)(iVar5 + 0x2160) != iVar8) {
                if (iVar8 == 0) {
                    uVar16 = 0x3f800000;
                } else {
                    uVar16 = *(undefined4 *)(iVar8 + 0x30);
                }
                *(undefined4 *)(iVar5 + 0x1308) = uVar16;
                *(int64_t *)(iVar5 + 0x2160) = iVar8;
                if (*(char *)(iVar5 + 0x8a) != '\0') {
                    *(undefined4 *)(iVar5 + 0xd98) = uVar16;
                }
                if ((iVar8 != 0) && (*(code **)(iVar5 + 0xd20) != (code *)0x0)) {
    // WARNING: Could not recover jumptable at 0x000180106024. Too many branches
    // WARNING: Treating indirect jump as call
                    (**(code **)(iVar5 + 0xd20))();
                    return;
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180105e8d
// Address: 0x180105e8d
// Size: 196 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180105c20(void)
{
    undefined4 *puVar1;
    float fVar2;
    float fVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    int32_t iVar11;
    uint32_t uVar12;
    undefined8 uVar13;
    int64_t iVar14;
    int64_t iVar15;
    undefined4 uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar8 = *(int64_t *)0x180781f28;
    if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x15b0) < 2) && (*(char *)(*(int64_t *)0x180781f28 + 2) != '\0')) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180105c69. Too many branches
    // WARNING: Treating indirect jump as call
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644510);
            return;
        }
    } else {
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        iVar6 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15b8);
        iVar15 = (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x15b0) * 0x78;
        uVar12 = *(uint32_t *)(iVar5 + 0x14);
        if (((uVar12 >> 0x1a & 1) != 0) &&
           ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x154c) != *(int32_t *)(iVar5 + 0x10) &&
            (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0)))) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644530);
            uVar12 = *(uint32_t *)(iVar5 + 0x14);
        }
        if (((((uVar12 & 0x1800000) == 0x1000000) && ((*(uint8_t *)(iVar5 + 0x495) & 1) == 0)) &&
            (*(int32_t *)(iVar8 + 0x1548) != *(int32_t *)(iVar5 + 0x10))) &&
           (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0)) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644558);
        }
        if (*(int64_t *)(iVar5 + 0x208) != 0) {
            func_0x000180138d00();
        }
        if (((*(uint32_t *)(iVar5 + 0x14) & 0x800000) == 0) && (*(char *)(iVar5 + 0x10f) == '\0')) {
            func_0x0001800fc8f0();
        }
        func_0x0001801067d0();
        iVar7 = *(int64_t *)0x180781f28;
        if ((*(char *)(iVar6 + -10 + iVar15) != '\0') && (*(int64_t *)(iVar5 + 0x418) == iVar5)) {
            *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) = *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) + -1;
            iVar4 = *(int32_t *)(iVar7 + 0x2100);
            *(int32_t *)(iVar7 + 0x2100) = iVar4 + -1;
            *(undefined4 *)(iVar7 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar7 + 0x2108) + -8 + (int64_t)iVar4 * 4);
            *(undefined4 *)(iVar7 + 0xd9c) =
                 *(undefined4 *)((int64_t)*(int32_t *)(iVar7 + 0x15b0) * 0x78 + -8 + *(int64_t *)(iVar7 + 0x15b8));
        }
        if (*(char *)(iVar5 + 0x10f) != '\0') {
            *(int64_t *)(iVar5 + 800) = iVar5 + 0x328;
        }
        uVar13 = 0;
        if ((*(int64_t *)(iVar8 + 0x2a00) == iVar5) && (*(char *)(iVar7 + 0x29f8) != '\0')) {
            func_0x0001801124e0(0x180644f68);
            uVar12 = *(uint32_t *)(iVar7 + 0x29fc) & 0xf;
            if (uVar12 == 1) {
                func_0x00018045fdf8(*(undefined8 *)(iVar7 + 0x2a08));
            } else if (uVar12 == 2) {
                func_0x00018045ff84(*(undefined8 *)(iVar7 + 0x2a08));
            } else if ((uVar12 == 8) && (1 < *(int32_t *)(iVar7 + 0x2a10))) {
                iVar14 = 0x180781edb;
                if (*(int64_t *)(iVar7 + 0x2a18) != 0) {
                    iVar14 = *(int64_t *)(iVar7 + 0x2a18);
                }
                if (*(code **)(*(int64_t *)0x180781f28 + 0xc50) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0xc50))(*(int64_t *)0x180781f28, iVar14);
                }
            }
            *(undefined *)(iVar7 + 0x1652) = 0;
            *(undefined *)(iVar7 + 0x29f8) = 0;
            *(undefined4 *)(iVar7 + 0x29fc) = 0;
            *(undefined8 *)(iVar7 + 0x2a08) = 0;
            if (*(int64_t *)(iVar7 + 0x2a18) != 0) {
                *(undefined8 *)(iVar7 + 0x2a10) = 0;
                func_0x000180460d90();
                *(undefined8 *)(iVar7 + 0x2a18) = 0;
            }
        }
        if (*(char *)(iVar5 + 0x199) != '\0') {
            func_0x000180109fd0();
        }
        if (((*(int64_t *)(iVar5 + 0x4c0) != 0) && ((*(uint8_t *)(iVar5 + 0x495) & 4) != 0)) &&
           (iVar7 = *(int64_t *)(*(int64_t *)(iVar5 + 0x4c0) + 0x98), iVar7 != 0)) {
            fVar2 = *(float *)(iVar5 + 0x170);
            fVar3 = *(float *)(iVar5 + 0x90);
            *(float *)(iVar7 + 0x174) =
                 (*(float *)(iVar5 + 0x174) + *(float *)(iVar5 + 0x94)) - *(float *)(iVar7 + 0x94);
            *(float *)(iVar7 + 0x170) = (fVar2 + fVar3) - *(float *)(iVar7 + 0x90);
        }
        puVar1 = (undefined4 *)(iVar6 + -0x70 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fb8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fbc) = uVar16;
        *(undefined4 *)(iVar8 + 0x1fc0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1fc4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x60 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fc8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fcc) = uVar16;
        *(undefined4 *)(iVar8 + 0x1fd0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1fd4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x50 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fd8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fdc) = uVar16;
        *(undefined4 *)(iVar8 + 0x1fe0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1fe4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x40 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fe8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fec) = uVar16;
        *(undefined4 *)(iVar8 + 0x1ff0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1ff4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x30 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1ff8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1ffc) = uVar16;
        *(undefined4 *)(iVar8 + 0x2000) = uVar9;
        *(undefined4 *)(iVar8 + 0x2004) = uVar10;
        if ((*(uint32_t *)(iVar5 + 0x14) & 0x10000000) != 0) {
            *(int32_t *)(iVar8 + 0x278c) = *(int32_t *)(iVar8 + 0x278c) + -1;
        }
        if ((*(uint32_t *)(iVar5 + 0x14) & 0x4000000) != 0) {
            *(int32_t *)(iVar8 + 0x2130) = *(int32_t *)(iVar8 + 0x2130) + -1;
        }
        if (*(char *)(iVar8 + 0xb0) != '\0') {
            func_0x00018010a070(iVar6 + -0x20 + iVar15);
        }
        iVar4 = *(int32_t *)(iVar8 + 0x15b0);
        iVar11 = iVar4 + -1;
        *(int32_t *)(iVar8 + 0x15b0) = iVar11;
        if (iVar11 != 0) {
            uVar13 = *(undefined8 *)(((int64_t)iVar4 + -2) * 0x78 + *(int64_t *)(iVar8 + 0x15b8));
        }
        func_0x0001800f9e20(uVar13);
        iVar5 = *(int64_t *)0x180781f28;
        if (*(int64_t *)(iVar8 + 0x15e0) != 0) {
            iVar8 = *(int64_t *)(*(int64_t *)(iVar8 + 0x15e0) + 0x48);
            if (iVar8 != 0) {
                *(undefined4 *)(iVar8 + 0x84) = *(undefined4 *)(*(int64_t *)0x180781f28 + 4);
            }
            if (*(int64_t *)(iVar5 + 0x2160) != iVar8) {
                if (iVar8 == 0) {
                    uVar16 = 0x3f800000;
                } else {
                    uVar16 = *(undefined4 *)(iVar8 + 0x30);
                }
                *(undefined4 *)(iVar5 + 0x1308) = uVar16;
                *(int64_t *)(iVar5 + 0x2160) = iVar8;
                if (*(char *)(iVar5 + 0x8a) != '\0') {
                    *(undefined4 *)(iVar5 + 0xd98) = uVar16;
                }
                if ((iVar8 != 0) && (*(code **)(iVar5 + 0xd20) != (code *)0x0)) {
    // WARNING: Could not recover jumptable at 0x000180106024. Too many branches
    // WARNING: Treating indirect jump as call
                    (**(code **)(iVar5 + 0xd20))();
                    return;
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180105f51
// Address: 0x180105f51
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180105c20(void)
{
    undefined4 *puVar1;
    float fVar2;
    float fVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    int32_t iVar11;
    uint32_t uVar12;
    undefined8 uVar13;
    int64_t iVar14;
    int64_t iVar15;
    undefined4 uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar8 = *(int64_t *)0x180781f28;
    if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x15b0) < 2) && (*(char *)(*(int64_t *)0x180781f28 + 2) != '\0')) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180105c69. Too many branches
    // WARNING: Treating indirect jump as call
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644510);
            return;
        }
    } else {
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        iVar6 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15b8);
        iVar15 = (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x15b0) * 0x78;
        uVar12 = *(uint32_t *)(iVar5 + 0x14);
        if (((uVar12 >> 0x1a & 1) != 0) &&
           ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x154c) != *(int32_t *)(iVar5 + 0x10) &&
            (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0)))) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644530);
            uVar12 = *(uint32_t *)(iVar5 + 0x14);
        }
        if (((((uVar12 & 0x1800000) == 0x1000000) && ((*(uint8_t *)(iVar5 + 0x495) & 1) == 0)) &&
            (*(int32_t *)(iVar8 + 0x1548) != *(int32_t *)(iVar5 + 0x10))) &&
           (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0)) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644558);
        }
        if (*(int64_t *)(iVar5 + 0x208) != 0) {
            func_0x000180138d00();
        }
        if (((*(uint32_t *)(iVar5 + 0x14) & 0x800000) == 0) && (*(char *)(iVar5 + 0x10f) == '\0')) {
            func_0x0001800fc8f0();
        }
        func_0x0001801067d0();
        iVar7 = *(int64_t *)0x180781f28;
        if ((*(char *)(iVar6 + -10 + iVar15) != '\0') && (*(int64_t *)(iVar5 + 0x418) == iVar5)) {
            *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) = *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) + -1;
            iVar4 = *(int32_t *)(iVar7 + 0x2100);
            *(int32_t *)(iVar7 + 0x2100) = iVar4 + -1;
            *(undefined4 *)(iVar7 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar7 + 0x2108) + -8 + (int64_t)iVar4 * 4);
            *(undefined4 *)(iVar7 + 0xd9c) =
                 *(undefined4 *)((int64_t)*(int32_t *)(iVar7 + 0x15b0) * 0x78 + -8 + *(int64_t *)(iVar7 + 0x15b8));
        }
        if (*(char *)(iVar5 + 0x10f) != '\0') {
            *(int64_t *)(iVar5 + 800) = iVar5 + 0x328;
        }
        uVar13 = 0;
        if ((*(int64_t *)(iVar8 + 0x2a00) == iVar5) && (*(char *)(iVar7 + 0x29f8) != '\0')) {
            func_0x0001801124e0(0x180644f68);
            uVar12 = *(uint32_t *)(iVar7 + 0x29fc) & 0xf;
            if (uVar12 == 1) {
                func_0x00018045fdf8(*(undefined8 *)(iVar7 + 0x2a08));
            } else if (uVar12 == 2) {
                func_0x00018045ff84(*(undefined8 *)(iVar7 + 0x2a08));
            } else if ((uVar12 == 8) && (1 < *(int32_t *)(iVar7 + 0x2a10))) {
                iVar14 = 0x180781edb;
                if (*(int64_t *)(iVar7 + 0x2a18) != 0) {
                    iVar14 = *(int64_t *)(iVar7 + 0x2a18);
                }
                if (*(code **)(*(int64_t *)0x180781f28 + 0xc50) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0xc50))(*(int64_t *)0x180781f28, iVar14);
                }
            }
            *(undefined *)(iVar7 + 0x1652) = 0;
            *(undefined *)(iVar7 + 0x29f8) = 0;
            *(undefined4 *)(iVar7 + 0x29fc) = 0;
            *(undefined8 *)(iVar7 + 0x2a08) = 0;
            if (*(int64_t *)(iVar7 + 0x2a18) != 0) {
                *(undefined8 *)(iVar7 + 0x2a10) = 0;
                func_0x000180460d90();
                *(undefined8 *)(iVar7 + 0x2a18) = 0;
            }
        }
        if (*(char *)(iVar5 + 0x199) != '\0') {
            func_0x000180109fd0();
        }
        if (((*(int64_t *)(iVar5 + 0x4c0) != 0) && ((*(uint8_t *)(iVar5 + 0x495) & 4) != 0)) &&
           (iVar7 = *(int64_t *)(*(int64_t *)(iVar5 + 0x4c0) + 0x98), iVar7 != 0)) {
            fVar2 = *(float *)(iVar5 + 0x170);
            fVar3 = *(float *)(iVar5 + 0x90);
            *(float *)(iVar7 + 0x174) =
                 (*(float *)(iVar5 + 0x174) + *(float *)(iVar5 + 0x94)) - *(float *)(iVar7 + 0x94);
            *(float *)(iVar7 + 0x170) = (fVar2 + fVar3) - *(float *)(iVar7 + 0x90);
        }
        puVar1 = (undefined4 *)(iVar6 + -0x70 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fb8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fbc) = uVar16;
        *(undefined4 *)(iVar8 + 0x1fc0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1fc4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x60 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fc8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fcc) = uVar16;
        *(undefined4 *)(iVar8 + 0x1fd0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1fd4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x50 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fd8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fdc) = uVar16;
        *(undefined4 *)(iVar8 + 0x1fe0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1fe4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x40 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fe8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fec) = uVar16;
        *(undefined4 *)(iVar8 + 0x1ff0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1ff4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x30 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1ff8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1ffc) = uVar16;
        *(undefined4 *)(iVar8 + 0x2000) = uVar9;
        *(undefined4 *)(iVar8 + 0x2004) = uVar10;
        if ((*(uint32_t *)(iVar5 + 0x14) & 0x10000000) != 0) {
            *(int32_t *)(iVar8 + 0x278c) = *(int32_t *)(iVar8 + 0x278c) + -1;
        }
        if ((*(uint32_t *)(iVar5 + 0x14) & 0x4000000) != 0) {
            *(int32_t *)(iVar8 + 0x2130) = *(int32_t *)(iVar8 + 0x2130) + -1;
        }
        if (*(char *)(iVar8 + 0xb0) != '\0') {
            func_0x00018010a070(iVar6 + -0x20 + iVar15);
        }
        iVar4 = *(int32_t *)(iVar8 + 0x15b0);
        iVar11 = iVar4 + -1;
        *(int32_t *)(iVar8 + 0x15b0) = iVar11;
        if (iVar11 != 0) {
            uVar13 = *(undefined8 *)(((int64_t)iVar4 + -2) * 0x78 + *(int64_t *)(iVar8 + 0x15b8));
        }
        func_0x0001800f9e20(uVar13);
        iVar5 = *(int64_t *)0x180781f28;
        if (*(int64_t *)(iVar8 + 0x15e0) != 0) {
            iVar8 = *(int64_t *)(*(int64_t *)(iVar8 + 0x15e0) + 0x48);
            if (iVar8 != 0) {
                *(undefined4 *)(iVar8 + 0x84) = *(undefined4 *)(*(int64_t *)0x180781f28 + 4);
            }
            if (*(int64_t *)(iVar5 + 0x2160) != iVar8) {
                if (iVar8 == 0) {
                    uVar16 = 0x3f800000;
                } else {
                    uVar16 = *(undefined4 *)(iVar8 + 0x30);
                }
                *(undefined4 *)(iVar5 + 0x1308) = uVar16;
                *(int64_t *)(iVar5 + 0x2160) = iVar8;
                if (*(char *)(iVar5 + 0x8a) != '\0') {
                    *(undefined4 *)(iVar5 + 0xd98) = uVar16;
                }
                if ((iVar8 != 0) && (*(code **)(iVar5 + 0xd20) != (code *)0x0)) {
    // WARNING: Could not recover jumptable at 0x000180106024. Too many branches
    // WARNING: Treating indirect jump as call
                    (**(code **)(iVar5 + 0xd20))();
                    return;
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180105f8a
// Address: 0x180105f8a
// Size: 46 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180105c20(void)
{
    undefined4 *puVar1;
    float fVar2;
    float fVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    int32_t iVar11;
    uint32_t uVar12;
    undefined8 uVar13;
    int64_t iVar14;
    int64_t iVar15;
    undefined4 uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar8 = *(int64_t *)0x180781f28;
    if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x15b0) < 2) && (*(char *)(*(int64_t *)0x180781f28 + 2) != '\0')) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180105c69. Too many branches
    // WARNING: Treating indirect jump as call
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644510);
            return;
        }
    } else {
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        iVar6 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15b8);
        iVar15 = (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x15b0) * 0x78;
        uVar12 = *(uint32_t *)(iVar5 + 0x14);
        if (((uVar12 >> 0x1a & 1) != 0) &&
           ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x154c) != *(int32_t *)(iVar5 + 0x10) &&
            (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0)))) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644530);
            uVar12 = *(uint32_t *)(iVar5 + 0x14);
        }
        if (((((uVar12 & 0x1800000) == 0x1000000) && ((*(uint8_t *)(iVar5 + 0x495) & 1) == 0)) &&
            (*(int32_t *)(iVar8 + 0x1548) != *(int32_t *)(iVar5 + 0x10))) &&
           (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0)) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644558);
        }
        if (*(int64_t *)(iVar5 + 0x208) != 0) {
            func_0x000180138d00();
        }
        if (((*(uint32_t *)(iVar5 + 0x14) & 0x800000) == 0) && (*(char *)(iVar5 + 0x10f) == '\0')) {
            func_0x0001800fc8f0();
        }
        func_0x0001801067d0();
        iVar7 = *(int64_t *)0x180781f28;
        if ((*(char *)(iVar6 + -10 + iVar15) != '\0') && (*(int64_t *)(iVar5 + 0x418) == iVar5)) {
            *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) = *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) + -1;
            iVar4 = *(int32_t *)(iVar7 + 0x2100);
            *(int32_t *)(iVar7 + 0x2100) = iVar4 + -1;
            *(undefined4 *)(iVar7 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar7 + 0x2108) + -8 + (int64_t)iVar4 * 4);
            *(undefined4 *)(iVar7 + 0xd9c) =
                 *(undefined4 *)((int64_t)*(int32_t *)(iVar7 + 0x15b0) * 0x78 + -8 + *(int64_t *)(iVar7 + 0x15b8));
        }
        if (*(char *)(iVar5 + 0x10f) != '\0') {
            *(int64_t *)(iVar5 + 800) = iVar5 + 0x328;
        }
        uVar13 = 0;
        if ((*(int64_t *)(iVar8 + 0x2a00) == iVar5) && (*(char *)(iVar7 + 0x29f8) != '\0')) {
            func_0x0001801124e0(0x180644f68);
            uVar12 = *(uint32_t *)(iVar7 + 0x29fc) & 0xf;
            if (uVar12 == 1) {
                func_0x00018045fdf8(*(undefined8 *)(iVar7 + 0x2a08));
            } else if (uVar12 == 2) {
                func_0x00018045ff84(*(undefined8 *)(iVar7 + 0x2a08));
            } else if ((uVar12 == 8) && (1 < *(int32_t *)(iVar7 + 0x2a10))) {
                iVar14 = 0x180781edb;
                if (*(int64_t *)(iVar7 + 0x2a18) != 0) {
                    iVar14 = *(int64_t *)(iVar7 + 0x2a18);
                }
                if (*(code **)(*(int64_t *)0x180781f28 + 0xc50) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0xc50))(*(int64_t *)0x180781f28, iVar14);
                }
            }
            *(undefined *)(iVar7 + 0x1652) = 0;
            *(undefined *)(iVar7 + 0x29f8) = 0;
            *(undefined4 *)(iVar7 + 0x29fc) = 0;
            *(undefined8 *)(iVar7 + 0x2a08) = 0;
            if (*(int64_t *)(iVar7 + 0x2a18) != 0) {
                *(undefined8 *)(iVar7 + 0x2a10) = 0;
                func_0x000180460d90();
                *(undefined8 *)(iVar7 + 0x2a18) = 0;
            }
        }
        if (*(char *)(iVar5 + 0x199) != '\0') {
            func_0x000180109fd0();
        }
        if (((*(int64_t *)(iVar5 + 0x4c0) != 0) && ((*(uint8_t *)(iVar5 + 0x495) & 4) != 0)) &&
           (iVar7 = *(int64_t *)(*(int64_t *)(iVar5 + 0x4c0) + 0x98), iVar7 != 0)) {
            fVar2 = *(float *)(iVar5 + 0x170);
            fVar3 = *(float *)(iVar5 + 0x90);
            *(float *)(iVar7 + 0x174) =
                 (*(float *)(iVar5 + 0x174) + *(float *)(iVar5 + 0x94)) - *(float *)(iVar7 + 0x94);
            *(float *)(iVar7 + 0x170) = (fVar2 + fVar3) - *(float *)(iVar7 + 0x90);
        }
        puVar1 = (undefined4 *)(iVar6 + -0x70 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fb8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fbc) = uVar16;
        *(undefined4 *)(iVar8 + 0x1fc0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1fc4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x60 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fc8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fcc) = uVar16;
        *(undefined4 *)(iVar8 + 0x1fd0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1fd4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x50 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fd8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fdc) = uVar16;
        *(undefined4 *)(iVar8 + 0x1fe0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1fe4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x40 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fe8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fec) = uVar16;
        *(undefined4 *)(iVar8 + 0x1ff0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1ff4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x30 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1ff8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1ffc) = uVar16;
        *(undefined4 *)(iVar8 + 0x2000) = uVar9;
        *(undefined4 *)(iVar8 + 0x2004) = uVar10;
        if ((*(uint32_t *)(iVar5 + 0x14) & 0x10000000) != 0) {
            *(int32_t *)(iVar8 + 0x278c) = *(int32_t *)(iVar8 + 0x278c) + -1;
        }
        if ((*(uint32_t *)(iVar5 + 0x14) & 0x4000000) != 0) {
            *(int32_t *)(iVar8 + 0x2130) = *(int32_t *)(iVar8 + 0x2130) + -1;
        }
        if (*(char *)(iVar8 + 0xb0) != '\0') {
            func_0x00018010a070(iVar6 + -0x20 + iVar15);
        }
        iVar4 = *(int32_t *)(iVar8 + 0x15b0);
        iVar11 = iVar4 + -1;
        *(int32_t *)(iVar8 + 0x15b0) = iVar11;
        if (iVar11 != 0) {
            uVar13 = *(undefined8 *)(((int64_t)iVar4 + -2) * 0x78 + *(int64_t *)(iVar8 + 0x15b8));
        }
        func_0x0001800f9e20(uVar13);
        iVar5 = *(int64_t *)0x180781f28;
        if (*(int64_t *)(iVar8 + 0x15e0) != 0) {
            iVar8 = *(int64_t *)(*(int64_t *)(iVar8 + 0x15e0) + 0x48);
            if (iVar8 != 0) {
                *(undefined4 *)(iVar8 + 0x84) = *(undefined4 *)(*(int64_t *)0x180781f28 + 4);
            }
            if (*(int64_t *)(iVar5 + 0x2160) != iVar8) {
                if (iVar8 == 0) {
                    uVar16 = 0x3f800000;
                } else {
                    uVar16 = *(undefined4 *)(iVar8 + 0x30);
                }
                *(undefined4 *)(iVar5 + 0x1308) = uVar16;
                *(int64_t *)(iVar5 + 0x2160) = iVar8;
                if (*(char *)(iVar5 + 0x8a) != '\0') {
                    *(undefined4 *)(iVar5 + 0xd98) = uVar16;
                }
                if ((iVar8 != 0) && (*(code **)(iVar5 + 0xd20) != (code *)0x0)) {
    // WARNING: Could not recover jumptable at 0x000180106024. Too many branches
    // WARNING: Treating indirect jump as call
                    (**(code **)(iVar5 + 0xd20))();
                    return;
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180105fb8
// Address: 0x180105fb8
// Size: 117 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180105c20(void)
{
    undefined4 *puVar1;
    float fVar2;
    float fVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    int32_t iVar11;
    uint32_t uVar12;
    undefined8 uVar13;
    int64_t iVar14;
    int64_t iVar15;
    undefined4 uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar8 = *(int64_t *)0x180781f28;
    if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x15b0) < 2) && (*(char *)(*(int64_t *)0x180781f28 + 2) != '\0')) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180105c69. Too many branches
    // WARNING: Treating indirect jump as call
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644510);
            return;
        }
    } else {
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        iVar6 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15b8);
        iVar15 = (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x15b0) * 0x78;
        uVar12 = *(uint32_t *)(iVar5 + 0x14);
        if (((uVar12 >> 0x1a & 1) != 0) &&
           ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x154c) != *(int32_t *)(iVar5 + 0x10) &&
            (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0)))) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644530);
            uVar12 = *(uint32_t *)(iVar5 + 0x14);
        }
        if (((((uVar12 & 0x1800000) == 0x1000000) && ((*(uint8_t *)(iVar5 + 0x495) & 1) == 0)) &&
            (*(int32_t *)(iVar8 + 0x1548) != *(int32_t *)(iVar5 + 0x10))) &&
           (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0)) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644558);
        }
        if (*(int64_t *)(iVar5 + 0x208) != 0) {
            func_0x000180138d00();
        }
        if (((*(uint32_t *)(iVar5 + 0x14) & 0x800000) == 0) && (*(char *)(iVar5 + 0x10f) == '\0')) {
            func_0x0001800fc8f0();
        }
        func_0x0001801067d0();
        iVar7 = *(int64_t *)0x180781f28;
        if ((*(char *)(iVar6 + -10 + iVar15) != '\0') && (*(int64_t *)(iVar5 + 0x418) == iVar5)) {
            *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) = *(int16_t *)(*(int64_t *)0x180781f28 + 0x281c) + -1;
            iVar4 = *(int32_t *)(iVar7 + 0x2100);
            *(int32_t *)(iVar7 + 0x2100) = iVar4 + -1;
            *(undefined4 *)(iVar7 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar7 + 0x2108) + -8 + (int64_t)iVar4 * 4);
            *(undefined4 *)(iVar7 + 0xd9c) =
                 *(undefined4 *)((int64_t)*(int32_t *)(iVar7 + 0x15b0) * 0x78 + -8 + *(int64_t *)(iVar7 + 0x15b8));
        }
        if (*(char *)(iVar5 + 0x10f) != '\0') {
            *(int64_t *)(iVar5 + 800) = iVar5 + 0x328;
        }
        uVar13 = 0;
        if ((*(int64_t *)(iVar8 + 0x2a00) == iVar5) && (*(char *)(iVar7 + 0x29f8) != '\0')) {
            func_0x0001801124e0(0x180644f68);
            uVar12 = *(uint32_t *)(iVar7 + 0x29fc) & 0xf;
            if (uVar12 == 1) {
                func_0x00018045fdf8(*(undefined8 *)(iVar7 + 0x2a08));
            } else if (uVar12 == 2) {
                func_0x00018045ff84(*(undefined8 *)(iVar7 + 0x2a08));
            } else if ((uVar12 == 8) && (1 < *(int32_t *)(iVar7 + 0x2a10))) {
                iVar14 = 0x180781edb;
                if (*(int64_t *)(iVar7 + 0x2a18) != 0) {
                    iVar14 = *(int64_t *)(iVar7 + 0x2a18);
                }
                if (*(code **)(*(int64_t *)0x180781f28 + 0xc50) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0xc50))(*(int64_t *)0x180781f28, iVar14);
                }
            }
            *(undefined *)(iVar7 + 0x1652) = 0;
            *(undefined *)(iVar7 + 0x29f8) = 0;
            *(undefined4 *)(iVar7 + 0x29fc) = 0;
            *(undefined8 *)(iVar7 + 0x2a08) = 0;
            if (*(int64_t *)(iVar7 + 0x2a18) != 0) {
                *(undefined8 *)(iVar7 + 0x2a10) = 0;
                func_0x000180460d90();
                *(undefined8 *)(iVar7 + 0x2a18) = 0;
            }
        }
        if (*(char *)(iVar5 + 0x199) != '\0') {
            func_0x000180109fd0();
        }
        if (((*(int64_t *)(iVar5 + 0x4c0) != 0) && ((*(uint8_t *)(iVar5 + 0x495) & 4) != 0)) &&
           (iVar7 = *(int64_t *)(*(int64_t *)(iVar5 + 0x4c0) + 0x98), iVar7 != 0)) {
            fVar2 = *(float *)(iVar5 + 0x170);
            fVar3 = *(float *)(iVar5 + 0x90);
            *(float *)(iVar7 + 0x174) =
                 (*(float *)(iVar5 + 0x174) + *(float *)(iVar5 + 0x94)) - *(float *)(iVar7 + 0x94);
            *(float *)(iVar7 + 0x170) = (fVar2 + fVar3) - *(float *)(iVar7 + 0x90);
        }
        puVar1 = (undefined4 *)(iVar6 + -0x70 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fb8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fbc) = uVar16;
        *(undefined4 *)(iVar8 + 0x1fc0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1fc4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x60 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fc8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fcc) = uVar16;
        *(undefined4 *)(iVar8 + 0x1fd0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1fd4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x50 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fd8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fdc) = uVar16;
        *(undefined4 *)(iVar8 + 0x1fe0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1fe4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x40 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1fe8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1fec) = uVar16;
        *(undefined4 *)(iVar8 + 0x1ff0) = uVar9;
        *(undefined4 *)(iVar8 + 0x1ff4) = uVar10;
        puVar1 = (undefined4 *)(iVar6 + -0x30 + iVar15);
        uVar16 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        *(undefined4 *)(iVar8 + 0x1ff8) = *puVar1;
        *(undefined4 *)(iVar8 + 0x1ffc) = uVar16;
        *(undefined4 *)(iVar8 + 0x2000) = uVar9;
        *(undefined4 *)(iVar8 + 0x2004) = uVar10;
        if ((*(uint32_t *)(iVar5 + 0x14) & 0x10000000) != 0) {
            *(int32_t *)(iVar8 + 0x278c) = *(int32_t *)(iVar8 + 0x278c) + -1;
        }
        if ((*(uint32_t *)(iVar5 + 0x14) & 0x4000000) != 0) {
            *(int32_t *)(iVar8 + 0x2130) = *(int32_t *)(iVar8 + 0x2130) + -1;
        }
        if (*(char *)(iVar8 + 0xb0) != '\0') {
            func_0x00018010a070(iVar6 + -0x20 + iVar15);
        }
        iVar4 = *(int32_t *)(iVar8 + 0x15b0);
        iVar11 = iVar4 + -1;
        *(int32_t *)(iVar8 + 0x15b0) = iVar11;
        if (iVar11 != 0) {
            uVar13 = *(undefined8 *)(((int64_t)iVar4 + -2) * 0x78 + *(int64_t *)(iVar8 + 0x15b8));
        }
        func_0x0001800f9e20(uVar13);
        iVar5 = *(int64_t *)0x180781f28;
        if (*(int64_t *)(iVar8 + 0x15e0) != 0) {
            iVar8 = *(int64_t *)(*(int64_t *)(iVar8 + 0x15e0) + 0x48);
            if (iVar8 != 0) {
                *(undefined4 *)(iVar8 + 0x84) = *(undefined4 *)(*(int64_t *)0x180781f28 + 4);
            }
            if (*(int64_t *)(iVar5 + 0x2160) != iVar8) {
                if (iVar8 == 0) {
                    uVar16 = 0x3f800000;
                } else {
                    uVar16 = *(undefined4 *)(iVar8 + 0x30);
                }
                *(undefined4 *)(iVar5 + 0x1308) = uVar16;
                *(int64_t *)(iVar5 + 0x2160) = iVar8;
                if (*(char *)(iVar5 + 0x8a) != '\0') {
                    *(undefined4 *)(iVar5 + 0xd98) = uVar16;
                }
                if ((iVar8 != 0) && (*(code **)(iVar5 + 0xd20) != (code *)0x0)) {
    // WARNING: Could not recover jumptable at 0x000180106024. Too many branches
    // WARNING: Treating indirect jump as call
                    (**(code **)(iVar5 + 0xd20))();
                    return;
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180106080
// Address: 0x180106080
// Size: 167 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180106080(undefined8 placeholder_0, int64_t arg2)
{
    float *pfVar1;
    int32_t *piVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t var_8h;
    
    iVar4 = *(int64_t *)0x180781f28;
    uVar3 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78);
    if ((uVar3 & 0x40) == 0) {
        if ((char)placeholder_0 == '\0') goto code_r0x0001801060c8;
        pfVar1 = (float *)(*(int64_t *)0x180781f28 + 0xd9c);
        *(float *)(*(int64_t *)0x180781f28 + 0x2818) = *pfVar1;
        *(float *)(iVar4 + 0xd9c) = *pfVar1 * *(float *)(iVar4 + 0xda0);
    }
    *(uint32_t *)(iVar4 + 0x1f78) = uVar3 | 0x40;
code_r0x0001801060c8:
    piVar2 = (int32_t *)(iVar4 + 0x2100);
    iVar5 = *(int32_t *)(iVar4 + 0x2104);
    if (*piVar2 == iVar5) {
        iVar6 = *piVar2 + 1;
        if (iVar5 == 0) {
            iVar5 = 8;
        } else {
            iVar5 = iVar5 / 2 + iVar5;
        }
        if (iVar6 < iVar5) {
            iVar6 = iVar5;
        }
        func_0x00018011fb10(piVar2, iVar6);
    }
    *(undefined4 *)(*(int64_t *)(iVar4 + 0x2108) + (int64_t)*piVar2 * 4) = *(undefined4 *)(iVar4 + 0x1f78);
    *piVar2 = *piVar2 + 1;
    *(int16_t *)(iVar4 + 0x281c) = *(int16_t *)(iVar4 + 0x281c) + 1;
    return;
}

// ============================================================
// Function: FUN_1801061c0
// Address: 0x1801061c0
// Size: 133 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801061c0(undefined8 placeholder_0, int64_t arg2)
{
    int32_t *piVar1;
    int64_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    undefined4 in_XMM0_Da;
    int64_t var_8h;
    int64_t var_18h;
    
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    piVar1 = (int32_t *)(iVar2 + 600);
    iVar3 = *(int32_t *)(iVar2 + 0x25c);
    if (*piVar1 == iVar3) {
        iVar4 = *piVar1 + 1;
        if (iVar3 == 0) {
            iVar3 = 8;
        } else {
            iVar3 = iVar3 / 2 + iVar3;
        }
        if (iVar4 < iVar3) {
            iVar4 = iVar3;
        }
        func_0x00018011fb10(piVar1, iVar4);
    }
    *(undefined4 *)(*(int64_t *)(iVar2 + 0x260) + (int64_t)*piVar1 * 4) = *(undefined4 *)(iVar2 + 0x244);
    *piVar1 = *piVar1 + 1;
    *(undefined4 *)(iVar2 + 0x244) = in_XMM0_Da;
    return;
}

// ============================================================
// Function: FUN_1801062b0
// Address: 0x1801062b0
// Size: 438 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1801062b0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    char cVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint32_t uVar7;
    int64_t iVar8;
    bool bVar9;
    int64_t var_8h;
    
    iVar2 = *(int64_t *)0x180781f28;
    uVar7 = (uint32_t)arg1;
    if (((arg1 & 0xffffcf40U) != 0) && (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0)) {
        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806446a8);
    }
    iVar8 = *(int64_t *)(iVar2 + 0x15e8);
    if (iVar8 != 0) {
        if ((arg1 & 4U) == 0) {
            iVar4 = *(int64_t *)(iVar2 + 0x15e0);
            iVar6 = iVar4;
            if ((arg1 & 2U) != 0) {
                if ((arg1 & 0x10U) == 0) {
                    if (iVar4 != 0) {
                        do {
                            iVar6 = *(int64_t *)(iVar4 + 0x418);
                            if ((arg1 & 8U) == 0) {
                                iVar6 = *(int64_t *)(iVar6 + 0x420);
                            }
                            bVar9 = iVar4 != iVar6;
                            iVar4 = iVar6;
                        } while (bVar9);
                    }
                } else if (iVar4 != 0) {
                    do {
                        iVar6 = *(int64_t *)(iVar4 + 0x418);
                        if ((arg1 & 8U) == 0) {
                            iVar6 = *(int64_t *)(iVar6 + 0x420);
                        }
                        iVar6 = *(int64_t *)(iVar6 + 0x428);
                        bVar9 = iVar4 != iVar6;
                        iVar4 = iVar6;
                    } while (bVar9);
                }
            }
            if ((arg1 & 1U) == 0) {
                bVar9 = iVar8 == iVar6;
            } else {
                iVar4 = iVar8;
                if ((arg1 & 8U) == 0) {
                    do {
                        iVar5 = *(int64_t *)(*(int64_t *)(iVar4 + 0x418) + 0x420);
                        if ((arg1 & 0x10U) != 0) {
                            iVar5 = *(int64_t *)(iVar5 + 0x428);
                        }
                        bVar9 = iVar4 != iVar5;
                        iVar4 = iVar5;
                    } while (bVar9);
                } else {
                    do {
                        iVar5 = *(int64_t *)(iVar4 + 0x418);
                        if ((arg1 & 0x10U) != 0) {
                            iVar5 = *(int64_t *)(iVar5 + 0x428);
                        }
                        bVar9 = iVar4 != iVar5;
                        iVar4 = iVar5;
                    } while (bVar9);
                }
                iVar4 = iVar8;
                if (iVar5 == iVar6) {
code_r0x0001801063c7:
                    bVar9 = true;
                } else {
                    do {
                        if (iVar4 == iVar6) goto code_r0x0001801063c7;
                    } while ((iVar4 != iVar5) && (piVar1 = (int64_t *)(iVar4 + 0x408), iVar4 = *piVar1, *piVar1 != 0));
                    bVar9 = false;
                }
            }
            if (!bVar9) {
                return false;
            }
        }
        cVar3 = func_0x0001800fa0b0(iVar8, arg1 & 0xffffffff);
        if (cVar3 != '\0') {
            if ((((-1 < (char)arg1) && (*(int32_t *)(iVar2 + 0x1654) != 0)) && (*(char *)(iVar2 + 0x1661) == '\0')) &&
               (*(int32_t *)(iVar2 + 0x1654) != *(int32_t *)(iVar8 + 0xc4))) {
                return false;
            }
            if ((uVar7 >> 0xc & 1) != 0) {
                uVar7 = uVar7 | *(uint32_t *)(iVar2 + 0x12bc);
            }
            if ((uVar7 >> 0xd & 1) != 0) {
                return *(int32_t *)(iVar2 + 0x264c) == *(int32_t *)(iVar8 + 0x10);
            }
            return true;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_180106750
// Address: 0x180106750
// Size: 122 bytes
// ============================================================
void fcn.180106750(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    
    iVar4 = *(int64_t *)0x180781f28;
    piVar1 = (int32_t *)(*(int64_t *)0x180781f28 + 0x20f0);
    iVar5 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x20f4);
    uVar2 = *(undefined4 *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10);
    if (*piVar1 == iVar5) {
        iVar6 = *piVar1 + 1;
        if (iVar5 == 0) {
            iVar5 = 8;
        } else {
            iVar5 = iVar5 / 2 + iVar5;
        }
        if (iVar6 < iVar5) {
            iVar6 = iVar5;
        }
        func_0x00018011f4f0(piVar1, iVar6);
    }
    iVar5 = *piVar1;
    iVar3 = *(int64_t *)(iVar4 + 0x20f8);
    *(int32_t *)(iVar3 + (int64_t)iVar5 * 8) = (int32_t)arg1;
    *(undefined4 *)(iVar3 + 4 + (int64_t)iVar5 * 8) = uVar2;
    *piVar1 = *piVar1 + 1;
    *(int32_t *)(iVar4 + 0x1f74) = (int32_t)arg1;
    return;
}

// ============================================================
// Function: FUN_180106840
// Address: 0x180106840
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180106840(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int32_t *piVar1;
    undefined8 *puVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    int32_t iVar9;
    int32_t iVar10;
    uint32_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar8 = *(int64_t *)0x180781f28;
    iVar9 = (int32_t)arg1;
    piVar1 = (int32_t *)(*(int64_t *)0x180781f28 + 0x2200);
    *(int32_t *)(*(int64_t *)0x180781f28 + 0x21e0) = iVar9;
    iVar10 = *(int32_t *)(iVar8 + 0x2204);
    if (iVar10 < 0) {
        iVar10 = iVar10 + iVar10 / 2;
        iVar7 = 0;
        if (0 < iVar10) {
            iVar7 = iVar10;
        }
        func_0x00018011f4f0(piVar1, iVar7);
    }
    *piVar1 = 0;
    if (iVar9 != 0) {
        if (iVar9 == *(int32_t *)(iVar8 + 0x1f74)) {
            iVar10 = 0;
            uVar11 = *(int32_t *)(iVar8 + 0x20f0) - 1;
            if (-1 < (int32_t)uVar11) {
                iVar10 = 0;
                do {
                    puVar2 = (undefined8 *)(*(int64_t *)(iVar8 + 0x20f8) + (uint64_t)uVar11 * 8);
                    if (*(int32_t *)((int64_t)puVar2 + 4) != *(int32_t *)(*(int64_t *)(iVar8 + 0x15e0) + 0x10)) break;
                    iVar9 = *(int32_t *)(iVar8 + 0x2204);
                    if (iVar10 == iVar9) {
                        if (iVar9 == 0) {
                            iVar9 = 8;
                        } else {
                            iVar9 = iVar9 / 2 + iVar9;
                        }
                        iVar7 = iVar10 + 1;
                        if (iVar10 + 1 < iVar9) {
                            iVar7 = iVar9;
                        }
                        func_0x00018011f4f0(piVar1, iVar7);
                    }
                    *(undefined8 *)(*(int64_t *)(iVar8 + 0x2208) + (int64_t)*piVar1 * 8) = *puVar2;
                    *piVar1 = *piVar1 + 1;
                    uVar11 = uVar11 - 1;
                    iVar10 = *piVar1;
                } while (-1 < (int32_t)uVar11);
            }
        } else {
            if (iVar9 != *(int32_t *)(*(int64_t *)(iVar8 + 0x21d8) + 0x488)) {
                return;
            }
            uVar3 = *(undefined4 *)(*(int64_t *)(iVar8 + 0x21d8) + 0x10);
            if (*(int32_t *)(iVar8 + 0x2204) == 0) {
                func_0x00018011f4f0(piVar1, 8);
            }
            iVar10 = *piVar1;
            iVar5 = *(int64_t *)(iVar8 + 0x2208);
            *(int32_t *)(iVar5 + (int64_t)iVar10 * 8) = iVar9;
            *(undefined4 *)(iVar5 + 4 + (int64_t)iVar10 * 8) = uVar3;
            *piVar1 = *piVar1 + 1;
            iVar10 = *piVar1;
        }
        for (iVar5 = *(int64_t *)(*(int64_t *)(iVar8 + 0x21d8) + 0x440); iVar5 != 0; iVar5 = *(int64_t *)(iVar5 + 0x440)
            ) {
            iVar9 = *(int32_t *)(iVar8 + 0x2204);
            uVar3 = *(undefined4 *)(iVar5 + 0x488);
            uVar4 = *(undefined4 *)(iVar5 + 0x10);
            if (iVar10 == iVar9) {
                if (iVar9 == 0) {
                    iVar9 = 8;
                } else {
                    iVar9 = iVar9 / 2 + iVar9;
                }
                iVar7 = iVar10 + 1;
                if (iVar10 + 1 < iVar9) {
                    iVar7 = iVar9;
                }
                func_0x00018011f4f0(piVar1, iVar7);
            }
            iVar10 = *piVar1;
            iVar6 = *(int64_t *)(iVar8 + 0x2208);
            *(undefined4 *)(iVar6 + (int64_t)iVar10 * 8) = uVar3;
            *(undefined4 *)(iVar6 + 4 + (int64_t)iVar10 * 8) = uVar4;
            *piVar1 = *piVar1 + 1;
            iVar10 = *piVar1;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180106892
// Address: 0x180106892
// Size: 341 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180106840(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int32_t *piVar1;
    undefined8 *puVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    int32_t iVar9;
    int32_t iVar10;
    uint32_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar8 = *(int64_t *)0x180781f28;
    iVar9 = (int32_t)arg1;
    piVar1 = (int32_t *)(*(int64_t *)0x180781f28 + 0x2200);
    *(int32_t *)(*(int64_t *)0x180781f28 + 0x21e0) = iVar9;
    iVar10 = *(int32_t *)(iVar8 + 0x2204);
    if (iVar10 < 0) {
        iVar10 = iVar10 + iVar10 / 2;
        iVar7 = 0;
        if (0 < iVar10) {
            iVar7 = iVar10;
        }
        func_0x00018011f4f0(piVar1, iVar7);
    }
    *piVar1 = 0;
    if (iVar9 != 0) {
        if (iVar9 == *(int32_t *)(iVar8 + 0x1f74)) {
            iVar10 = 0;
            uVar11 = *(int32_t *)(iVar8 + 0x20f0) - 1;
            if (-1 < (int32_t)uVar11) {
                iVar10 = 0;
                do {
                    puVar2 = (undefined8 *)(*(int64_t *)(iVar8 + 0x20f8) + (uint64_t)uVar11 * 8);
                    if (*(int32_t *)((int64_t)puVar2 + 4) != *(int32_t *)(*(int64_t *)(iVar8 + 0x15e0) + 0x10)) break;
                    iVar9 = *(int32_t *)(iVar8 + 0x2204);
                    if (iVar10 == iVar9) {
                        if (iVar9 == 0) {
                            iVar9 = 8;
                        } else {
                            iVar9 = iVar9 / 2 + iVar9;
                        }
                        iVar7 = iVar10 + 1;
                        if (iVar10 + 1 < iVar9) {
                            iVar7 = iVar9;
                        }
                        func_0x00018011f4f0(piVar1, iVar7);
                    }
                    *(undefined8 *)(*(int64_t *)(iVar8 + 0x2208) + (int64_t)*piVar1 * 8) = *puVar2;
                    *piVar1 = *piVar1 + 1;
                    uVar11 = uVar11 - 1;
                    iVar10 = *piVar1;
                } while (-1 < (int32_t)uVar11);
            }
        } else {
            if (iVar9 != *(int32_t *)(*(int64_t *)(iVar8 + 0x21d8) + 0x488)) {
                return;
            }
            uVar3 = *(undefined4 *)(*(int64_t *)(iVar8 + 0x21d8) + 0x10);
            if (*(int32_t *)(iVar8 + 0x2204) == 0) {
                func_0x00018011f4f0(piVar1, 8);
            }
            iVar10 = *piVar1;
            iVar5 = *(int64_t *)(iVar8 + 0x2208);
            *(int32_t *)(iVar5 + (int64_t)iVar10 * 8) = iVar9;
            *(undefined4 *)(iVar5 + 4 + (int64_t)iVar10 * 8) = uVar3;
            *piVar1 = *piVar1 + 1;
            iVar10 = *piVar1;
        }
        for (iVar5 = *(int64_t *)(*(int64_t *)(iVar8 + 0x21d8) + 0x440); iVar5 != 0; iVar5 = *(int64_t *)(iVar5 + 0x440)
            ) {
            iVar9 = *(int32_t *)(iVar8 + 0x2204);
            uVar3 = *(undefined4 *)(iVar5 + 0x488);
            uVar4 = *(undefined4 *)(iVar5 + 0x10);
            if (iVar10 == iVar9) {
                if (iVar9 == 0) {
                    iVar9 = 8;
                } else {
                    iVar9 = iVar9 / 2 + iVar9;
                }
                iVar7 = iVar10 + 1;
                if (iVar10 + 1 < iVar9) {
                    iVar7 = iVar9;
                }
                func_0x00018011f4f0(piVar1, iVar7);
            }
            iVar10 = *piVar1;
            iVar6 = *(int64_t *)(iVar8 + 0x2208);
            *(undefined4 *)(iVar6 + (int64_t)iVar10 * 8) = uVar3;
            *(undefined4 *)(iVar6 + 4 + (int64_t)iVar10 * 8) = uVar4;
            *piVar1 = *piVar1 + 1;
            iVar10 = *piVar1;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801069e7
// Address: 0x1801069e7
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180106840(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int32_t *piVar1;
    undefined8 *puVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    int32_t iVar9;
    int32_t iVar10;
    uint32_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar8 = *(int64_t *)0x180781f28;
    iVar9 = (int32_t)arg1;
    piVar1 = (int32_t *)(*(int64_t *)0x180781f28 + 0x2200);
    *(int32_t *)(*(int64_t *)0x180781f28 + 0x21e0) = iVar9;
    iVar10 = *(int32_t *)(iVar8 + 0x2204);
    if (iVar10 < 0) {
        iVar10 = iVar10 + iVar10 / 2;
        iVar7 = 0;
        if (0 < iVar10) {
            iVar7 = iVar10;
        }
        func_0x00018011f4f0(piVar1, iVar7);
    }
    *piVar1 = 0;
    if (iVar9 != 0) {
        if (iVar9 == *(int32_t *)(iVar8 + 0x1f74)) {
            iVar10 = 0;
            uVar11 = *(int32_t *)(iVar8 + 0x20f0) - 1;
            if (-1 < (int32_t)uVar11) {
                iVar10 = 0;
                do {
                    puVar2 = (undefined8 *)(*(int64_t *)(iVar8 + 0x20f8) + (uint64_t)uVar11 * 8);
                    if (*(int32_t *)((int64_t)puVar2 + 4) != *(int32_t *)(*(int64_t *)(iVar8 + 0x15e0) + 0x10)) break;
                    iVar9 = *(int32_t *)(iVar8 + 0x2204);
                    if (iVar10 == iVar9) {
                        if (iVar9 == 0) {
                            iVar9 = 8;
                        } else {
                            iVar9 = iVar9 / 2 + iVar9;
                        }
                        iVar7 = iVar10 + 1;
                        if (iVar10 + 1 < iVar9) {
                            iVar7 = iVar9;
                        }
                        func_0x00018011f4f0(piVar1, iVar7);
                    }
                    *(undefined8 *)(*(int64_t *)(iVar8 + 0x2208) + (int64_t)*piVar1 * 8) = *puVar2;
                    *piVar1 = *piVar1 + 1;
                    uVar11 = uVar11 - 1;
                    iVar10 = *piVar1;
                } while (-1 < (int32_t)uVar11);
            }
        } else {
            if (iVar9 != *(int32_t *)(*(int64_t *)(iVar8 + 0x21d8) + 0x488)) {
                return;
            }
            uVar3 = *(undefined4 *)(*(int64_t *)(iVar8 + 0x21d8) + 0x10);
            if (*(int32_t *)(iVar8 + 0x2204) == 0) {
                func_0x00018011f4f0(piVar1, 8);
            }
            iVar10 = *piVar1;
            iVar5 = *(int64_t *)(iVar8 + 0x2208);
            *(int32_t *)(iVar5 + (int64_t)iVar10 * 8) = iVar9;
            *(undefined4 *)(iVar5 + 4 + (int64_t)iVar10 * 8) = uVar3;
            *piVar1 = *piVar1 + 1;
            iVar10 = *piVar1;
        }
        for (iVar5 = *(int64_t *)(*(int64_t *)(iVar8 + 0x21d8) + 0x440); iVar5 != 0; iVar5 = *(int64_t *)(iVar5 + 0x440)
            ) {
            iVar9 = *(int32_t *)(iVar8 + 0x2204);
            uVar3 = *(undefined4 *)(iVar5 + 0x488);
            uVar4 = *(undefined4 *)(iVar5 + 0x10);
            if (iVar10 == iVar9) {
                if (iVar9 == 0) {
                    iVar9 = 8;
                } else {
                    iVar9 = iVar9 / 2 + iVar9;
                }
                iVar7 = iVar10 + 1;
                if (iVar10 + 1 < iVar9) {
                    iVar7 = iVar9;
                }
                func_0x00018011f4f0(piVar1, iVar7);
            }
            iVar10 = *piVar1;
            iVar6 = *(int64_t *)(iVar8 + 0x2208);
            *(undefined4 *)(iVar6 + (int64_t)iVar10 * 8) = uVar3;
            *(undefined4 *)(iVar6 + 4 + (int64_t)iVar10 * 8) = uVar4;
            *piVar1 = *piVar1 + 1;
            iVar10 = *piVar1;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180106a00
// Address: 0x180106a00
// Size: 154 bytes
// ============================================================
void fcn.180106a00(void)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    
    iVar2 = *(int64_t *)0x180781f28;
    if ((*(char *)(*(int64_t *)0x180781f28 + 0x2400) == '\0') && (*(int64_t *)(*(int64_t *)0x180781f28 + 0x1600) == 0))
    {
        iVar1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        if (*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) != iVar1) {
            *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) = iVar1;
            *(undefined8 *)(iVar2 + 0x2230) = 0xffffffffffffffff;
        }
        *(undefined2 *)(iVar2 + 0x2278) = 0;
        *(undefined2 *)(iVar2 + 0x2239) = 0;
        uVar3 = 3;
        if (*(char *)(iVar1 + 0x110) != '\0') {
            uVar3 = 0x21;
        }
        fcn.18010eb00(0xffffffff, 3, 0x5600, uVar3);
        *(undefined4 *)(iVar2 + 0x22b8) = 1;
        *(undefined4 *)(iVar2 + 0x22bc) = 1;
    }
    return;
}

// ============================================================
// Function: FUN_180106aa0
// Address: 0x180106aa0
// Size: 861 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_a4h because it doesn't fit into ProtoModel

void fcn.180106aa0(int64_t arg_c0h, int64_t arg_d0h, int64_t arg_d8h, int64_t arg_e8h)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t iVar8;
    uint32_t uVar9;
    int32_t iVar10;
    uint32_t uVar11;
    undefined8 *puVar12;
    int32_t iVar13;
    undefined4 *puVar14;
    uint32_t uVar15;
    int32_t iVar16;
    uint32_t uVar17;
    undefined4 *puVar18;
    uint32_t uVar19;
    int64_t iVar20;
    int64_t *piVar21;
    int64_t var_8h;
    
    iVar8 = *(int64_t *)0x180781f28;
    uVar19 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x34) >> 4;
    piVar21 = *(int64_t **)(*(int64_t *)0x180781f28 + 0x12e0);
    piVar1 = piVar21 + *(int32_t *)(*(int64_t *)0x180781f28 + 0x12d8);
    do {
        if (piVar21 == piVar1) {
            return;
        }
        iVar4 = *piVar21;
        if (*(int64_t *)(iVar4 + 0x2d8) == iVar8) {
            uVar3 = *(undefined4 *)(iVar8 + 4);
            *(uint8_t *)(iVar4 + 0x51) = (uint8_t)uVar19 & 1;
            if (((uVar19 & 1) != 0) && (*(undefined *)(iVar4 + 0x52) = 1, *(int64_t *)(iVar4 + 0x2b0) == 0)) {
                func_0x000180128500(iVar4);
            }
            if (*(char *)(iVar4 + 0x51) == '\0') {
                if (*(char *)(iVar4 + 0x52) == '\0') {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x1806454a0);
                    }
                    goto code_r0x000180106b52;
                }
code_r0x000180106b58:
                if (((*(char *)(*(int64_t *)(iVar4 + 0x2b0) + 0xb9) != '\0') && (*(char *)(iVar4 + 0x51) != '\0')) &&
                   (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0)) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806455b0);
                }
            } else {
code_r0x000180106b52:
                if (*(char *)(iVar4 + 0x52) != '\0') goto code_r0x000180106b58;
            }
            iVar5 = *(int64_t *)(iVar4 + 0x2b0);
            *(undefined4 *)(iVar5 + 0xa4) = uVar3;
            puVar12 = *(undefined8 **)(iVar4 + 0x70);
            puVar2 = puVar12 + *(int32_t *)(iVar4 + 0x68);
            for (; puVar12 != puVar2; puVar12 = puVar12 + 1) {
                *(undefined8 *)*puVar12 = 0;
            }
            if (0 < *(int32_t *)(iVar5 + 0xe8)) {
                uVar17 = 0;
                uVar15 = 0;
                iVar16 = *(int32_t *)(iVar5 + 0xc0);
                if (0 < iVar16) {
                    do {
                        uVar11 = uVar15 & 0x1f;
                        uVar9 = uVar15;
                        if ((int32_t)uVar15 < 0) {
                            uVar9 = uVar15 + 0x1f;
                            uVar11 = uVar11 - 0x20;
                        }
                        puVar18 = (undefined4 *)
                                  (*(int64_t *)(*(int64_t *)(iVar5 + 0xd0) + (int64_t)((int32_t)uVar9 >> 5) * 8) +
                                  (int64_t)(int32_t)uVar11 * 0x68);
                        if ((puVar18[0x13] & 0x4000000) == 0) {
                            uVar11 = uVar17 & 0x1f;
                            uVar9 = uVar17;
                            if ((int32_t)uVar17 < 0) {
                                uVar9 = uVar17 + 0x1f;
                                uVar11 = uVar11 - 0x20;
                            }
                            puVar14 = (undefined4 *)
                                      (*(int64_t *)(*(int64_t *)(iVar5 + 0xd0) + (int64_t)((int32_t)uVar9 >> 5) * 8) +
                                      (int64_t)(int32_t)uVar11 * 0x68);
                            uVar17 = uVar17 + 1;
                            if (puVar14 != puVar18) {
                                uVar3 = puVar18[1];
                                uVar6 = puVar18[2];
                                uVar7 = puVar18[3];
                                *puVar14 = *puVar18;
                                puVar14[1] = uVar3;
                                puVar14[2] = uVar6;
                                puVar14[3] = uVar7;
                                uVar3 = puVar18[5];
                                uVar6 = puVar18[6];
                                uVar7 = puVar18[7];
                                puVar14[4] = puVar18[4];
                                puVar14[5] = uVar3;
                                puVar14[6] = uVar6;
                                puVar14[7] = uVar7;
                                uVar3 = puVar18[9];
                                uVar6 = puVar18[10];
                                uVar7 = puVar18[0xb];
                                puVar14[8] = puVar18[8];
                                puVar14[9] = uVar3;
                                puVar14[10] = uVar6;
                                puVar14[0xb] = uVar7;
                                uVar3 = puVar18[0xd];
                                uVar6 = puVar18[0xe];
                                uVar7 = puVar18[0xf];
                                puVar14[0xc] = puVar18[0xc];
                                puVar14[0xd] = uVar3;
                                puVar14[0xe] = uVar6;
                                puVar14[0xf] = uVar7;
                                uVar3 = puVar18[0x11];
                                uVar6 = puVar18[0x12];
                                uVar7 = puVar18[0x13];
                                puVar14[0x10] = puVar18[0x10];
                                puVar14[0x11] = uVar3;
                                puVar14[0x12] = uVar6;
                                puVar14[0x13] = uVar7;
                                uVar3 = puVar18[0x15];
                                uVar6 = puVar18[0x16];
                                uVar7 = puVar18[0x17];
                                puVar14[0x14] = puVar18[0x14];
                                puVar14[0x15] = uVar3;
                                puVar14[0x16] = uVar6;
                                puVar14[0x17] = uVar7;
                                *(undefined8 *)(puVar14 + 0x18) = *(undefined8 *)(puVar18 + 0x18);
                                func_0x0001800f6220(iVar5 + 0xd8, puVar14[0x15], puVar14);
                            }
                        }
                        uVar15 = uVar15 + 1;
                        iVar16 = *(int32_t *)(iVar5 + 0xc0);
                    } while ((int32_t)uVar15 < iVar16);
                }
                *(int32_t *)(iVar5 + 0xc0) = iVar16 - *(int32_t *)(iVar5 + 0xe8);
                *(undefined4 *)(iVar5 + 0xe8) = 0;
            }
            iVar16 = 0;
            if (0 < *(int32_t *)(iVar4 + 0x40)) {
                do {
                    iVar20 = (int64_t)iVar16;
                    iVar5 = *(int64_t *)(*(int64_t *)(iVar4 + 0x48) + iVar20 * 8);
                    iVar10 = *(int32_t *)(iVar5 + 4);
                    if (iVar10 == 0) {
                        iVar10 = *(int32_t *)(iVar5 + 0x44);
                        if (iVar10 < 0) {
                            iVar10 = (iVar10 + 1 >> 1) + iVar10;
                            iVar13 = 0;
                            if (0 < iVar10) {
                                iVar13 = iVar10;
                            }
                            func_0x00018011f4f0(iVar5 + 0x40, iVar13);
                        }
                        *(undefined8 *)(iVar5 + 0x3c) = 0;
                        *(undefined4 *)(iVar5 + 0x38) = 0xffffffff;
                        iVar10 = *(int32_t *)(iVar5 + 4);
                    }
                    if (*(char *)(iVar5 + 0x57) == '\0') {
                        if (iVar10 == 4) goto code_r0x000180106da7;
code_r0x000180106d38:
                        if (iVar10 == 1) goto code_r0x000180106d41;
                        if (iVar10 == 4) {
code_r0x000180106dcc:
                            *(int32_t *)(iVar5 + 0x50) = *(int32_t *)(iVar5 + 0x50) + 1;
                        }
                    } else {
                        if (iVar10 == 1) {
                            iVar10 = 1;
                            goto code_r0x000180106d38;
                        }
                        if (iVar10 != 4) {
                            *(undefined4 *)(iVar5 + 4) = 4;
                        }
code_r0x000180106da7:
                        if ((*(int64_t *)(iVar5 + 0x10) != 0) || (*(int64_t *)(iVar5 + 8) != 0))
                        goto code_r0x000180106dcc;
                        *(undefined4 *)(iVar5 + 4) = 1;
code_r0x000180106d41:
                        if (*(char *)(iVar5 + 0x57) == '\0') {
                            *(undefined4 *)(iVar5 + 4) = 2;
                        } else {
                            if (*(int64_t *)(iVar5 + 0x28) != 0) {
                                func_0x000180460d90();
                            }
                            *(undefined8 *)(iVar5 + 0x28) = 0;
                            *(undefined *)(iVar5 + 0x56) = 0;
                            if (iVar5 != 0) {
                                if (*(int64_t *)(iVar5 + 0x48) != 0) {
                                    func_0x000180460d90();
                                }
                                func_0x000180460d90(iVar5);
                            }
                            iVar5 = *(int64_t *)(iVar4 + 0x48) + iVar20 * 8;
                            func_0x000180498030(iVar5, iVar5 + 8, (*(int32_t *)(iVar4 + 0x40) - iVar20) * 8 + -8);
                            *(int32_t *)(iVar4 + 0x40) = *(int32_t *)(iVar4 + 0x40) + -1;
                            iVar16 = iVar16 + -1;
                        }
                    }
                    iVar16 = iVar16 + 1;
                } while (iVar16 < *(int32_t *)(iVar4 + 0x40));
            }
        }
        piVar21 = piVar21 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_180106e00
// Address: 0x180106e00
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.180106e00(undefined8 placeholder_0, int64_t arg2)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    undefined8 *puVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int32_t iVar9;
    int64_t *piVar10;
    undefined8 *puVar11;
    int32_t iVar12;
    int64_t *piVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_28h;
    
    iVar8 = *(int64_t *)0x180781f28;
    piVar1 = (int32_t *)(*(int64_t *)0x180781f28 + 0xd70);
    iVar9 = *(int32_t *)(*(int64_t *)0x180781f28 + 0xd74);
    if (iVar9 < 0) {
        iVar9 = iVar9 + iVar9 / 2;
        iVar12 = 0;
        if (0 < iVar9) {
            iVar12 = iVar9;
        }
        func_0x00018011f4f0(piVar1, iVar12);
    }
    *piVar1 = 0;
    piVar13 = *(int64_t **)(iVar8 + 0x12e0);
    piVar2 = piVar13 + *(int32_t *)(iVar8 + 0x12d8);
    for (; piVar13 != piVar2; piVar13 = piVar13 + 1) {
        iVar5 = *piVar13;
        piVar10 = *(int64_t **)(iVar5 + 0x48);
        piVar3 = piVar10 + *(int32_t *)(iVar5 + 0x40);
        for (; piVar10 != piVar3; piVar10 = piVar10 + 1) {
            iVar6 = *piVar10;
            *(undefined2 *)(iVar6 + 0x54) = *(undefined2 *)(iVar5 + 0x2d4);
            iVar9 = *(int32_t *)(iVar8 + 0xd74);
            if (*piVar1 == iVar9) {
                iVar12 = *piVar1 + 1;
                if (iVar9 == 0) {
                    iVar9 = 8;
                } else {
                    iVar9 = iVar9 / 2 + iVar9;
                }
                if (iVar12 < iVar9) {
                    iVar12 = iVar9;
                }
                func_0x00018011f4f0(piVar1, iVar12);
            }
            *(int64_t *)(*(int64_t *)(iVar8 + 0xd78) + (int64_t)*piVar1 * 8) = iVar6;
            *piVar1 = *piVar1 + 1;
        }
    }
    puVar11 = *(undefined8 **)(iVar8 + 0x28e0);
    puVar4 = puVar11 + *(int32_t *)(iVar8 + 0x28d8);
    for (; puVar11 != puVar4; puVar11 = puVar11 + 1) {
        iVar9 = *(int32_t *)(iVar8 + 0xd74);
        uVar7 = *puVar11;
        if (*(int32_t *)(iVar8 + 0xd70) == iVar9) {
            iVar12 = *(int32_t *)(iVar8 + 0xd70) + 1;
            if (iVar9 == 0) {
                iVar9 = 8;
            } else {
                iVar9 = iVar9 / 2 + iVar9;
            }
            if (iVar12 < iVar9) {
                iVar12 = iVar9;
            }
            func_0x00018011f4f0(piVar1, iVar12);
        }
        *(undefined8 *)(*(int64_t *)(iVar8 + 0xd78) + (int64_t)*(int32_t *)(iVar8 + 0xd70) * 8) = uVar7;
        *piVar1 = *piVar1 + 1;
    }
    return;
}

// ============================================================
// Function: FUN_180106e11
// Address: 0x180106e11
// Size: 81 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.180106e00(undefined8 placeholder_0, int64_t arg2)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    undefined8 *puVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int32_t iVar9;
    int64_t *piVar10;
    undefined8 *puVar11;
    int32_t iVar12;
    int64_t *piVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_28h;
    
    iVar8 = *(int64_t *)0x180781f28;
    piVar1 = (int32_t *)(*(int64_t *)0x180781f28 + 0xd70);
    iVar9 = *(int32_t *)(*(int64_t *)0x180781f28 + 0xd74);
    if (iVar9 < 0) {
        iVar9 = iVar9 + iVar9 / 2;
        iVar12 = 0;
        if (0 < iVar9) {
            iVar12 = iVar9;
        }
        func_0x00018011f4f0(piVar1, iVar12);
    }
    *piVar1 = 0;
    piVar13 = *(int64_t **)(iVar8 + 0x12e0);
    piVar2 = piVar13 + *(int32_t *)(iVar8 + 0x12d8);
    for (; piVar13 != piVar2; piVar13 = piVar13 + 1) {
        iVar5 = *piVar13;
        piVar10 = *(int64_t **)(iVar5 + 0x48);
        piVar3 = piVar10 + *(int32_t *)(iVar5 + 0x40);
        for (; piVar10 != piVar3; piVar10 = piVar10 + 1) {
            iVar6 = *piVar10;
            *(undefined2 *)(iVar6 + 0x54) = *(undefined2 *)(iVar5 + 0x2d4);
            iVar9 = *(int32_t *)(iVar8 + 0xd74);
            if (*piVar1 == iVar9) {
                iVar12 = *piVar1 + 1;
                if (iVar9 == 0) {
                    iVar9 = 8;
                } else {
                    iVar9 = iVar9 / 2 + iVar9;
                }
                if (iVar12 < iVar9) {
                    iVar12 = iVar9;
                }
                func_0x00018011f4f0(piVar1, iVar12);
            }
            *(int64_t *)(*(int64_t *)(iVar8 + 0xd78) + (int64_t)*piVar1 * 8) = iVar6;
            *piVar1 = *piVar1 + 1;
        }
    }
    puVar11 = *(undefined8 **)(iVar8 + 0x28e0);
    puVar4 = puVar11 + *(int32_t *)(iVar8 + 0x28d8);
    for (; puVar11 != puVar4; puVar11 = puVar11 + 1) {
        iVar9 = *(int32_t *)(iVar8 + 0xd74);
        uVar7 = *puVar11;
        if (*(int32_t *)(iVar8 + 0xd70) == iVar9) {
            iVar12 = *(int32_t *)(iVar8 + 0xd70) + 1;
            if (iVar9 == 0) {
                iVar9 = 8;
            } else {
                iVar9 = iVar9 / 2 + iVar9;
            }
            if (iVar12 < iVar9) {
                iVar12 = iVar9;
            }
            func_0x00018011f4f0(piVar1, iVar12);
        }
        *(undefined8 *)(*(int64_t *)(iVar8 + 0xd78) + (int64_t)*(int32_t *)(iVar8 + 0xd70) * 8) = uVar7;
        *piVar1 = *piVar1 + 1;
    }
    return;
}

// ============================================================
// Function: FUN_180106e62
// Address: 0x180106e62
// Size: 163 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.180106e00(undefined8 placeholder_0, int64_t arg2)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    undefined8 *puVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int32_t iVar9;
    int64_t *piVar10;
    undefined8 *puVar11;
    int32_t iVar12;
    int64_t *piVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_28h;
    
    iVar8 = *(int64_t *)0x180781f28;
    piVar1 = (int32_t *)(*(int64_t *)0x180781f28 + 0xd70);
    iVar9 = *(int32_t *)(*(int64_t *)0x180781f28 + 0xd74);
    if (iVar9 < 0) {
        iVar9 = iVar9 + iVar9 / 2;
        iVar12 = 0;
        if (0 < iVar9) {
            iVar12 = iVar9;
        }
        func_0x00018011f4f0(piVar1, iVar12);
    }
    *piVar1 = 0;
    piVar13 = *(int64_t **)(iVar8 + 0x12e0);
    piVar2 = piVar13 + *(int32_t *)(iVar8 + 0x12d8);
    for (; piVar13 != piVar2; piVar13 = piVar13 + 1) {
        iVar5 = *piVar13;
        piVar10 = *(int64_t **)(iVar5 + 0x48);
        piVar3 = piVar10 + *(int32_t *)(iVar5 + 0x40);
        for (; piVar10 != piVar3; piVar10 = piVar10 + 1) {
            iVar6 = *piVar10;
            *(undefined2 *)(iVar6 + 0x54) = *(undefined2 *)(iVar5 + 0x2d4);
            iVar9 = *(int32_t *)(iVar8 + 0xd74);
            if (*piVar1 == iVar9) {
                iVar12 = *piVar1 + 1;
                if (iVar9 == 0) {
                    iVar9 = 8;
                } else {
                    iVar9 = iVar9 / 2 + iVar9;
                }
                if (iVar12 < iVar9) {
                    iVar12 = iVar9;
                }
                func_0x00018011f4f0(piVar1, iVar12);
            }
            *(int64_t *)(*(int64_t *)(iVar8 + 0xd78) + (int64_t)*piVar1 * 8) = iVar6;
            *piVar1 = *piVar1 + 1;
        }
    }
    puVar11 = *(undefined8 **)(iVar8 + 0x28e0);
    puVar4 = puVar11 + *(int32_t *)(iVar8 + 0x28d8);
    for (; puVar11 != puVar4; puVar11 = puVar11 + 1) {
        iVar9 = *(int32_t *)(iVar8 + 0xd74);
        uVar7 = *puVar11;
        if (*(int32_t *)(iVar8 + 0xd70) == iVar9) {
            iVar12 = *(int32_t *)(iVar8 + 0xd70) + 1;
            if (iVar9 == 0) {
                iVar9 = 8;
            } else {
                iVar9 = iVar9 / 2 + iVar9;
            }
            if (iVar12 < iVar9) {
                iVar12 = iVar9;
            }
            func_0x00018011f4f0(piVar1, iVar12);
        }
        *(undefined8 *)(*(int64_t *)(iVar8 + 0xd78) + (int64_t)*(int32_t *)(iVar8 + 0xd70) * 8) = uVar7;
        *piVar1 = *piVar1 + 1;
    }
    return;
}

// ============================================================
// Function: FUN_180106f05
// Address: 0x180106f05
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.180106e00(undefined8 placeholder_0, int64_t arg2)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    undefined8 *puVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int32_t iVar9;
    int64_t *piVar10;
    undefined8 *puVar11;
    int32_t iVar12;
    int64_t *piVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_28h;
    
    iVar8 = *(int64_t *)0x180781f28;
    piVar1 = (int32_t *)(*(int64_t *)0x180781f28 + 0xd70);
    iVar9 = *(int32_t *)(*(int64_t *)0x180781f28 + 0xd74);
    if (iVar9 < 0) {
        iVar9 = iVar9 + iVar9 / 2;
        iVar12 = 0;
        if (0 < iVar9) {
            iVar12 = iVar9;
        }
        func_0x00018011f4f0(piVar1, iVar12);
    }
    *piVar1 = 0;
    piVar13 = *(int64_t **)(iVar8 + 0x12e0);
    piVar2 = piVar13 + *(int32_t *)(iVar8 + 0x12d8);
    for (; piVar13 != piVar2; piVar13 = piVar13 + 1) {
        iVar5 = *piVar13;
        piVar10 = *(int64_t **)(iVar5 + 0x48);
        piVar3 = piVar10 + *(int32_t *)(iVar5 + 0x40);
        for (; piVar10 != piVar3; piVar10 = piVar10 + 1) {
            iVar6 = *piVar10;
            *(undefined2 *)(iVar6 + 0x54) = *(undefined2 *)(iVar5 + 0x2d4);
            iVar9 = *(int32_t *)(iVar8 + 0xd74);
            if (*piVar1 == iVar9) {
                iVar12 = *piVar1 + 1;
                if (iVar9 == 0) {
                    iVar9 = 8;
                } else {
                    iVar9 = iVar9 / 2 + iVar9;
                }
                if (iVar12 < iVar9) {
                    iVar12 = iVar9;
                }
                func_0x00018011f4f0(piVar1, iVar12);
            }
            *(int64_t *)(*(int64_t *)(iVar8 + 0xd78) + (int64_t)*piVar1 * 8) = iVar6;
            *piVar1 = *piVar1 + 1;
        }
    }
    puVar11 = *(undefined8 **)(iVar8 + 0x28e0);
    puVar4 = puVar11 + *(int32_t *)(iVar8 + 0x28d8);
    for (; puVar11 != puVar4; puVar11 = puVar11 + 1) {
        iVar9 = *(int32_t *)(iVar8 + 0xd74);
        uVar7 = *puVar11;
        if (*(int32_t *)(iVar8 + 0xd70) == iVar9) {
            iVar12 = *(int32_t *)(iVar8 + 0xd70) + 1;
            if (iVar9 == 0) {
                iVar9 = 8;
            } else {
                iVar9 = iVar9 / 2 + iVar9;
            }
            if (iVar12 < iVar9) {
                iVar12 = iVar9;
            }
            func_0x00018011f4f0(piVar1, iVar12);
        }
        *(undefined8 *)(*(int64_t *)(iVar8 + 0xd78) + (int64_t)*(int32_t *)(iVar8 + 0xd70) * 8) = uVar7;
        *piVar1 = *piVar1 + 1;
    }
    return;
}

// ============================================================
// Function: FUN_180106f30
// Address: 0x180106f30
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.180106e00(undefined8 placeholder_0, int64_t arg2)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    undefined8 *puVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int32_t iVar9;
    int64_t *piVar10;
    undefined8 *puVar11;
    int32_t iVar12;
    int64_t *piVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_28h;
    
    iVar8 = *(int64_t *)0x180781f28;
    piVar1 = (int32_t *)(*(int64_t *)0x180781f28 + 0xd70);
    iVar9 = *(int32_t *)(*(int64_t *)0x180781f28 + 0xd74);
    if (iVar9 < 0) {
        iVar9 = iVar9 + iVar9 / 2;
        iVar12 = 0;
        if (0 < iVar9) {
            iVar12 = iVar9;
        }
        func_0x00018011f4f0(piVar1, iVar12);
    }
    *piVar1 = 0;
    piVar13 = *(int64_t **)(iVar8 + 0x12e0);
    piVar2 = piVar13 + *(int32_t *)(iVar8 + 0x12d8);
    for (; piVar13 != piVar2; piVar13 = piVar13 + 1) {
        iVar5 = *piVar13;
        piVar10 = *(int64_t **)(iVar5 + 0x48);
        piVar3 = piVar10 + *(int32_t *)(iVar5 + 0x40);
        for (; piVar10 != piVar3; piVar10 = piVar10 + 1) {
            iVar6 = *piVar10;
            *(undefined2 *)(iVar6 + 0x54) = *(undefined2 *)(iVar5 + 0x2d4);
            iVar9 = *(int32_t *)(iVar8 + 0xd74);
            if (*piVar1 == iVar9) {
                iVar12 = *piVar1 + 1;
                if (iVar9 == 0) {
                    iVar9 = 8;
                } else {
                    iVar9 = iVar9 / 2 + iVar9;
                }
                if (iVar12 < iVar9) {
                    iVar12 = iVar9;
                }
                func_0x00018011f4f0(piVar1, iVar12);
            }
            *(int64_t *)(*(int64_t *)(iVar8 + 0xd78) + (int64_t)*piVar1 * 8) = iVar6;
            *piVar1 = *piVar1 + 1;
        }
    }
    puVar11 = *(undefined8 **)(iVar8 + 0x28e0);
    puVar4 = puVar11 + *(int32_t *)(iVar8 + 0x28d8);
    for (; puVar11 != puVar4; puVar11 = puVar11 + 1) {
        iVar9 = *(int32_t *)(iVar8 + 0xd74);
        uVar7 = *puVar11;
        if (*(int32_t *)(iVar8 + 0xd70) == iVar9) {
            iVar12 = *(int32_t *)(iVar8 + 0xd70) + 1;
            if (iVar9 == 0) {
                iVar9 = 8;
            } else {
                iVar9 = iVar9 / 2 + iVar9;
            }
            if (iVar12 < iVar9) {
                iVar12 = iVar9;
            }
            func_0x00018011f4f0(piVar1, iVar12);
        }
        *(undefined8 *)(*(int64_t *)(iVar8 + 0xd78) + (int64_t)*(int32_t *)(iVar8 + 0xd70) * 8) = uVar7;
        *piVar1 = *piVar1 + 1;
    }
    return;
}

// ============================================================
// Function: FUN_180106fa0
// Address: 0x180106fa0
// Size: 416 bytes
// ============================================================
void fcn.180106fa0(void)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    float fVar11;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar4 = *(int64_t *)0x180781f28;
    if ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x34) & 0x10) == 0) {
        piVar7 = *(int64_t **)(*(int64_t *)0x180781f28 + 0x12e0);
        piVar1 = piVar7 + *(int32_t *)(*(int64_t *)0x180781f28 + 0x12d8);
        for (; piVar7 != piVar1; piVar7 = piVar7 + 1) {
            *(undefined *)(*piVar7 + 0x50) = 1;
        }
    }
    fVar11 = *(float *)(iVar4 + 0x12c8);
    if (fVar11 == 0.0) {
        fVar11 = *(float *)(iVar4 + 0xd90);
    } else {
        *(float *)(iVar4 + 0xd90) = fVar11;
        *(undefined4 *)(iVar4 + 0x12c8) = 0;
    }
    iVar3 = *(int64_t *)(iVar4 + 0x68);
    if ((*(int64_t *)(iVar3 + 0x2b0) == 0) || (*(int32_t *)(iVar3 + 0x68) == 0)) {
        func_0x000180128500(iVar3);
        fVar11 = *(float *)(iVar4 + 0xd90);
    }
    iVar9 = *(int64_t *)(iVar4 + 0x70);
    if (iVar9 == 0) {
        iVar9 = **(int64_t **)(iVar3 + 0x70);
    }
    if (fVar11 <= 0.0) {
        fVar11 = *(float *)(iVar9 + 0x1c);
        if (fVar11 <= 0.0) {
            fVar11 = 20.0;
        }
        *(float *)(iVar4 + 0xd90) = fVar11;
    }
    *(float *)(iVar4 + 0x12fc) = fVar11;
    *(int64_t *)(iVar4 + 0x12e8) = iVar9;
    *(undefined4 *)(iVar4 + 0x12f8) = 0;
    func_0x0001801072d0(iVar9, fVar11, 0);
    iVar2 = *(int32_t *)(iVar4 + 0x20e4);
    if (*(int32_t *)(iVar4 + 0x20e0) == iVar2) {
        iVar10 = *(int32_t *)(iVar4 + 0x20e0) + 1;
        if (iVar2 == 0) {
            iVar5 = 8;
        } else {
            iVar5 = iVar2 / 2 + iVar2;
        }
        if (iVar10 < iVar5) {
            iVar10 = iVar5;
        }
        if (iVar2 < iVar10) {
            uVar6 = func_0x00018046d050((int64_t)iVar10 << 4);
            if (*(int64_t *)(iVar4 + 0x20e8) != 0) {
                func_0x000180498030(uVar6, *(int64_t *)(iVar4 + 0x20e8), (int64_t)*(int32_t *)(iVar4 + 0x20e0) << 4);
                func_0x000180460d90(*(undefined8 *)(iVar4 + 0x20e8));
            }
            *(undefined8 *)(iVar4 + 0x20e8) = uVar6;
            *(int32_t *)(iVar4 + 0x20e4) = iVar10;
        }
    }
    iVar8 = (int64_t)*(int32_t *)(iVar4 + 0x20e0);
    iVar3 = *(int64_t *)(iVar4 + 0x20e8);
    *(int64_t *)(iVar3 + iVar8 * 0x10) = iVar9;
    *(float *)(iVar3 + 8 + iVar8 * 0x10) = fVar11;
    *(float *)(iVar3 + 0xc + iVar8 * 0x10) = fVar11;
    *(int32_t *)(iVar4 + 0x20e0) = *(int32_t *)(iVar4 + 0x20e0) + 1;
    return;
}

// ============================================================
// Function: FUN_180107140
// Address: 0x180107140
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180107140(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    *(int32_t *)(arg1 + 0x2d4) = *(int32_t *)(arg1 + 0x2d4) + 1;
    iVar3 = *(int64_t *)0x180781f28;
    iVar7 = 8;
    iVar2 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x12dc);
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x12d8) == iVar2) {
        iVar8 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x12d8) + 1;
        if (iVar2 == 0) {
            iVar4 = 8;
        } else {
            arg2 = (int64_t)(uint32_t)(iVar2 >> 0x1f);
            iVar4 = iVar2 / 2 + iVar2;
        }
        if (iVar8 < iVar4) {
            iVar8 = iVar4;
        }
        if (iVar2 < iVar8) {
            uVar5 = func_0x00018046d050((int64_t)iVar8 << 3, arg2);
            if (*(int64_t *)(iVar3 + 0x12e0) != 0) {
                func_0x000180498030(uVar5, *(int64_t *)(iVar3 + 0x12e0), (int64_t)*(int32_t *)(iVar3 + 0x12d8) << 3);
                func_0x000180460d90(*(undefined8 *)(iVar3 + 0x12e0));
            }
            *(undefined8 *)(iVar3 + 0x12e0) = uVar5;
            *(int32_t *)(iVar3 + 0x12dc) = iVar8;
        }
    }
    *(int64_t *)(*(int64_t *)(iVar3 + 0x12e0) + (int64_t)*(int32_t *)(iVar3 + 0x12d8) * 8) = arg1;
    *(int32_t *)(iVar3 + 0x12d8) = *(int32_t *)(iVar3 + 0x12d8) + 1;
    iVar2 = *(int32_t *)(arg1 + 0x2a4);
    if (*(int32_t *)(arg1 + 0x2a0) == iVar2) {
        iVar8 = *(int32_t *)(arg1 + 0x2a0) + 1;
        if (iVar2 != 0) {
            iVar7 = iVar2 + iVar2 / 2;
        }
        if (iVar8 < iVar7) {
            iVar8 = iVar7;
        }
        if (iVar2 < iVar8) {
            uVar5 = func_0x00018046d050((int64_t)iVar8 << 3);
            if (*(int64_t *)(arg1 + 0x2a8) != 0) {
                func_0x000180498030(uVar5, *(int64_t *)(arg1 + 0x2a8), (int64_t)*(int32_t *)(arg1 + 0x2a0) << 3);
                func_0x000180460d90(*(undefined8 *)(arg1 + 0x2a8));
            }
            *(undefined8 *)(arg1 + 0x2a8) = uVar5;
            *(int32_t *)(arg1 + 0x2a4) = iVar8;
        }
    }
    *(int64_t *)(*(int64_t *)(arg1 + 0x2a8) + (int64_t)*(int32_t *)(arg1 + 0x2a0) * 8) = iVar3 + 0x1310;
    *(int32_t *)(arg1 + 0x2a0) = *(int32_t *)(arg1 + 0x2a0) + 1;
    piVar6 = *(int64_t **)(arg1 + 0x48);
    piVar1 = piVar6 + *(int32_t *)(arg1 + 0x40);
    for (; piVar6 != piVar1; piVar6 = piVar6 + 1) {
        *(undefined2 *)(*piVar6 + 0x54) = *(undefined2 *)(arg1 + 0x2d4);
    }
    return;
}

// ============================================================
// Function: FUN_18010714f
// Address: 0x18010714f
// Size: 78 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180107140(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    *(int32_t *)(arg1 + 0x2d4) = *(int32_t *)(arg1 + 0x2d4) + 1;
    iVar3 = *(int64_t *)0x180781f28;
    iVar7 = 8;
    iVar2 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x12dc);
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x12d8) == iVar2) {
        iVar8 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x12d8) + 1;
        if (iVar2 == 0) {
            iVar4 = 8;
        } else {
            arg2 = (int64_t)(uint32_t)(iVar2 >> 0x1f);
            iVar4 = iVar2 / 2 + iVar2;
        }
        if (iVar8 < iVar4) {
            iVar8 = iVar4;
        }
        if (iVar2 < iVar8) {
            uVar5 = func_0x00018046d050((int64_t)iVar8 << 3, arg2);
            if (*(int64_t *)(iVar3 + 0x12e0) != 0) {
                func_0x000180498030(uVar5, *(int64_t *)(iVar3 + 0x12e0), (int64_t)*(int32_t *)(iVar3 + 0x12d8) << 3);
                func_0x000180460d90(*(undefined8 *)(iVar3 + 0x12e0));
            }
            *(undefined8 *)(iVar3 + 0x12e0) = uVar5;
            *(int32_t *)(iVar3 + 0x12dc) = iVar8;
        }
    }
    *(int64_t *)(*(int64_t *)(iVar3 + 0x12e0) + (int64_t)*(int32_t *)(iVar3 + 0x12d8) * 8) = arg1;
    *(int32_t *)(iVar3 + 0x12d8) = *(int32_t *)(iVar3 + 0x12d8) + 1;
    iVar2 = *(int32_t *)(arg1 + 0x2a4);
    if (*(int32_t *)(arg1 + 0x2a0) == iVar2) {
        iVar8 = *(int32_t *)(arg1 + 0x2a0) + 1;
        if (iVar2 != 0) {
            iVar7 = iVar2 + iVar2 / 2;
        }
        if (iVar8 < iVar7) {
            iVar8 = iVar7;
        }
        if (iVar2 < iVar8) {
            uVar5 = func_0x00018046d050((int64_t)iVar8 << 3);
            if (*(int64_t *)(arg1 + 0x2a8) != 0) {
                func_0x000180498030(uVar5, *(int64_t *)(arg1 + 0x2a8), (int64_t)*(int32_t *)(arg1 + 0x2a0) << 3);
                func_0x000180460d90(*(undefined8 *)(arg1 + 0x2a8));
            }
            *(undefined8 *)(arg1 + 0x2a8) = uVar5;
            *(int32_t *)(arg1 + 0x2a4) = iVar8;
        }
    }
    *(int64_t *)(*(int64_t *)(arg1 + 0x2a8) + (int64_t)*(int32_t *)(arg1 + 0x2a0) * 8) = iVar3 + 0x1310;
    *(int32_t *)(arg1 + 0x2a0) = *(int32_t *)(arg1 + 0x2a0) + 1;
    piVar6 = *(int64_t **)(arg1 + 0x48);
    piVar1 = piVar6 + *(int32_t *)(arg1 + 0x40);
    for (; piVar6 != piVar1; piVar6 = piVar6 + 1) {
        *(undefined2 *)(*piVar6 + 0x54) = *(undefined2 *)(arg1 + 0x2d4);
    }
    return;
}

// ============================================================
// Function: FUN_18010719d
// Address: 0x18010719d
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180107140(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    *(int32_t *)(arg1 + 0x2d4) = *(int32_t *)(arg1 + 0x2d4) + 1;
    iVar3 = *(int64_t *)0x180781f28;
    iVar7 = 8;
    iVar2 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x12dc);
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x12d8) == iVar2) {
        iVar8 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x12d8) + 1;
        if (iVar2 == 0) {
            iVar4 = 8;
        } else {
            arg2 = (int64_t)(uint32_t)(iVar2 >> 0x1f);
            iVar4 = iVar2 / 2 + iVar2;
        }
        if (iVar8 < iVar4) {
            iVar8 = iVar4;
        }
        if (iVar2 < iVar8) {
            uVar5 = func_0x00018046d050((int64_t)iVar8 << 3, arg2);
            if (*(int64_t *)(iVar3 + 0x12e0) != 0) {
                func_0x000180498030(uVar5, *(int64_t *)(iVar3 + 0x12e0), (int64_t)*(int32_t *)(iVar3 + 0x12d8) << 3);
                func_0x000180460d90(*(undefined8 *)(iVar3 + 0x12e0));
            }
            *(undefined8 *)(iVar3 + 0x12e0) = uVar5;
            *(int32_t *)(iVar3 + 0x12dc) = iVar8;
        }
    }
    *(int64_t *)(*(int64_t *)(iVar3 + 0x12e0) + (int64_t)*(int32_t *)(iVar3 + 0x12d8) * 8) = arg1;
    *(int32_t *)(iVar3 + 0x12d8) = *(int32_t *)(iVar3 + 0x12d8) + 1;
    iVar2 = *(int32_t *)(arg1 + 0x2a4);
    if (*(int32_t *)(arg1 + 0x2a0) == iVar2) {
        iVar8 = *(int32_t *)(arg1 + 0x2a0) + 1;
        if (iVar2 != 0) {
            iVar7 = iVar2 + iVar2 / 2;
        }
        if (iVar8 < iVar7) {
            iVar8 = iVar7;
        }
        if (iVar2 < iVar8) {
            uVar5 = func_0x00018046d050((int64_t)iVar8 << 3);
            if (*(int64_t *)(arg1 + 0x2a8) != 0) {
                func_0x000180498030(uVar5, *(int64_t *)(arg1 + 0x2a8), (int64_t)*(int32_t *)(arg1 + 0x2a0) << 3);
                func_0x000180460d90(*(undefined8 *)(arg1 + 0x2a8));
            }
            *(undefined8 *)(arg1 + 0x2a8) = uVar5;
            *(int32_t *)(arg1 + 0x2a4) = iVar8;
        }
    }
    *(int64_t *)(*(int64_t *)(arg1 + 0x2a8) + (int64_t)*(int32_t *)(arg1 + 0x2a0) * 8) = iVar3 + 0x1310;
    *(int32_t *)(arg1 + 0x2a0) = *(int32_t *)(arg1 + 0x2a0) + 1;
    piVar6 = *(int64_t **)(arg1 + 0x48);
    piVar1 = piVar6 + *(int32_t *)(arg1 + 0x40);
    for (; piVar6 != piVar1; piVar6 = piVar6 + 1) {
        *(undefined2 *)(*piVar6 + 0x54) = *(undefined2 *)(arg1 + 0x2d4);
    }
    return;
}

// ============================================================
// Function: FUN_1801071e7
// Address: 0x1801071e7
// Size: 201 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180107140(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    *(int32_t *)(arg1 + 0x2d4) = *(int32_t *)(arg1 + 0x2d4) + 1;
    iVar3 = *(int64_t *)0x180781f28;
    iVar7 = 8;
    iVar2 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x12dc);
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x12d8) == iVar2) {
        iVar8 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x12d8) + 1;
        if (iVar2 == 0) {
            iVar4 = 8;
        } else {
            arg2 = (int64_t)(uint32_t)(iVar2 >> 0x1f);
            iVar4 = iVar2 / 2 + iVar2;
        }
        if (iVar8 < iVar4) {
            iVar8 = iVar4;
        }
        if (iVar2 < iVar8) {
            uVar5 = func_0x00018046d050((int64_t)iVar8 << 3, arg2);
            if (*(int64_t *)(iVar3 + 0x12e0) != 0) {
                func_0x000180498030(uVar5, *(int64_t *)(iVar3 + 0x12e0), (int64_t)*(int32_t *)(iVar3 + 0x12d8) << 3);
                func_0x000180460d90(*(undefined8 *)(iVar3 + 0x12e0));
            }
            *(undefined8 *)(iVar3 + 0x12e0) = uVar5;
            *(int32_t *)(iVar3 + 0x12dc) = iVar8;
        }
    }
    *(int64_t *)(*(int64_t *)(iVar3 + 0x12e0) + (int64_t)*(int32_t *)(iVar3 + 0x12d8) * 8) = arg1;
    *(int32_t *)(iVar3 + 0x12d8) = *(int32_t *)(iVar3 + 0x12d8) + 1;
    iVar2 = *(int32_t *)(arg1 + 0x2a4);
    if (*(int32_t *)(arg1 + 0x2a0) == iVar2) {
        iVar8 = *(int32_t *)(arg1 + 0x2a0) + 1;
        if (iVar2 != 0) {
            iVar7 = iVar2 + iVar2 / 2;
        }
        if (iVar8 < iVar7) {
            iVar8 = iVar7;
        }
        if (iVar2 < iVar8) {
            uVar5 = func_0x00018046d050((int64_t)iVar8 << 3);
            if (*(int64_t *)(arg1 + 0x2a8) != 0) {
                func_0x000180498030(uVar5, *(int64_t *)(arg1 + 0x2a8), (int64_t)*(int32_t *)(arg1 + 0x2a0) << 3);
                func_0x000180460d90(*(undefined8 *)(arg1 + 0x2a8));
            }
            *(undefined8 *)(arg1 + 0x2a8) = uVar5;
            *(int32_t *)(arg1 + 0x2a4) = iVar8;
        }
    }
    *(int64_t *)(*(int64_t *)(arg1 + 0x2a8) + (int64_t)*(int32_t *)(arg1 + 0x2a0) * 8) = iVar3 + 0x1310;
    *(int32_t *)(arg1 + 0x2a0) = *(int32_t *)(arg1 + 0x2a0) + 1;
    piVar6 = *(int64_t **)(arg1 + 0x48);
    piVar1 = piVar6 + *(int32_t *)(arg1 + 0x40);
    for (; piVar6 != piVar1; piVar6 = piVar6 + 1) {
        *(undefined2 *)(*piVar6 + 0x54) = *(undefined2 *)(arg1 + 0x2d4);
    }
    return;
}

// ============================================================
// Function: FUN_1801072b0
// Address: 0x1801072b0
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180107140(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    *(int32_t *)(arg1 + 0x2d4) = *(int32_t *)(arg1 + 0x2d4) + 1;
    iVar3 = *(int64_t *)0x180781f28;
    iVar7 = 8;
    iVar2 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x12dc);
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x12d8) == iVar2) {
        iVar8 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x12d8) + 1;
        if (iVar2 == 0) {
            iVar4 = 8;
        } else {
            arg2 = (int64_t)(uint32_t)(iVar2 >> 0x1f);
            iVar4 = iVar2 / 2 + iVar2;
        }
        if (iVar8 < iVar4) {
            iVar8 = iVar4;
        }
        if (iVar2 < iVar8) {
            uVar5 = func_0x00018046d050((int64_t)iVar8 << 3, arg2);
            if (*(int64_t *)(iVar3 + 0x12e0) != 0) {
                func_0x000180498030(uVar5, *(int64_t *)(iVar3 + 0x12e0), (int64_t)*(int32_t *)(iVar3 + 0x12d8) << 3);
                func_0x000180460d90(*(undefined8 *)(iVar3 + 0x12e0));
            }
            *(undefined8 *)(iVar3 + 0x12e0) = uVar5;
            *(int32_t *)(iVar3 + 0x12dc) = iVar8;
        }
    }
    *(int64_t *)(*(int64_t *)(iVar3 + 0x12e0) + (int64_t)*(int32_t *)(iVar3 + 0x12d8) * 8) = arg1;
    *(int32_t *)(iVar3 + 0x12d8) = *(int32_t *)(iVar3 + 0x12d8) + 1;
    iVar2 = *(int32_t *)(arg1 + 0x2a4);
    if (*(int32_t *)(arg1 + 0x2a0) == iVar2) {
        iVar8 = *(int32_t *)(arg1 + 0x2a0) + 1;
        if (iVar2 != 0) {
            iVar7 = iVar2 + iVar2 / 2;
        }
        if (iVar8 < iVar7) {
            iVar8 = iVar7;
        }
        if (iVar2 < iVar8) {
            uVar5 = func_0x00018046d050((int64_t)iVar8 << 3);
            if (*(int64_t *)(arg1 + 0x2a8) != 0) {
                func_0x000180498030(uVar5, *(int64_t *)(arg1 + 0x2a8), (int64_t)*(int32_t *)(arg1 + 0x2a0) << 3);
                func_0x000180460d90(*(undefined8 *)(arg1 + 0x2a8));
            }
            *(undefined8 *)(arg1 + 0x2a8) = uVar5;
            *(int32_t *)(arg1 + 0x2a4) = iVar8;
        }
    }
    *(int64_t *)(*(int64_t *)(arg1 + 0x2a8) + (int64_t)*(int32_t *)(arg1 + 0x2a0) * 8) = iVar3 + 0x1310;
    *(int32_t *)(arg1 + 0x2a0) = *(int32_t *)(arg1 + 0x2a0) + 1;
    piVar6 = *(int64_t **)(arg1 + 0x48);
    piVar1 = piVar6 + *(int32_t *)(arg1 + 0x40);
    for (; piVar6 != piVar1; piVar6 = piVar6 + 1) {
        *(undefined2 *)(*piVar6 + 0x54) = *(undefined2 *)(arg1 + 0x2d4);
    }
    return;
}

// ============================================================
// Function: FUN_1801072d0
// Address: 0x1801072d0
// Size: 225 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801072d0(int64_t arg1)
{
    undefined8 *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    undefined4 in_XMM1_Da;
    undefined4 in_XMM2_Da;
    undefined4 in_XMM2_Db;
    int64_t var_8h;
    
    iVar5 = *(int64_t *)0x180781f28;
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x12fc) = in_XMM1_Da;
    *(int64_t *)(iVar5 + 0x12e8) = arg1;
    func_0x0001801073c0(CONCAT44(in_XMM2_Db, in_XMM2_Da));
    if (arg1 != 0) {
        iVar3 = *(int64_t *)(arg1 + 8);
        *(int64_t *)(iVar5 + 0x1320) = iVar3;
        *(int64_t *)(iVar5 + 0x1328) = arg1;
        puVar7 = *(undefined8 **)(iVar3 + 0x2a8);
        puVar1 = puVar7 + *(int32_t *)(iVar3 + 0x2a0);
        for (; puVar7 != puVar1; puVar7 = puVar7 + 1) {
            puVar4 = (undefined8 *)*puVar7;
            if (puVar4[2] == iVar3) {
                *puVar4 = *(undefined8 *)(iVar3 + 0x5c);
                puVar4[1] = iVar3 + 0x88;
            }
        }
        if (*(int64_t *)(iVar5 + 0x15e0) != 0) {
            iVar5 = *(int64_t *)(*(int64_t *)(iVar5 + 0x15e0) + 800);
            iVar6 = *(int64_t *)(iVar3 + 0x30);
            iVar3 = *(int64_t *)(iVar3 + 0x28);
            if ((*(int64_t *)(iVar5 + 0x78) != iVar6) || (*(int64_t *)(iVar5 + 0x70) != iVar3)) {
                *(int64_t *)(iVar5 + 0x70) = iVar3;
                *(int64_t *)(iVar5 + 0x78) = iVar6;
                iVar2 = *(int32_t *)(iVar5 + 0xb0);
                iVar5 = *(int64_t *)(iVar5 + 0xb8);
                *(int64_t *)(iVar5 + -0x10 + (int64_t)iVar2 * 0x10) = iVar3;
                *(int64_t *)(iVar5 + -8 + (int64_t)iVar2 * 0x10) = iVar6;
                func_0x000180124360();
            }
        }
    }
    return;
}

