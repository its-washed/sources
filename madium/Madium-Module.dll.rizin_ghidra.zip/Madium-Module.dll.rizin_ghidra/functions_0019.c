// Chunk 19 - 50 functions

// ============================================================
// Function: FUN_180034ac0
// Address: 0x180034ac0
// Size: 78 bytes
// ============================================================
undefined8 fcn.180034ac0(int64_t arg1, int64_t arg2, int64_t arg_30h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t *in_RAX;
    int64_t iVar3;
    undefined8 uVar4;
    
    if (in_RAX == (int64_t *)arg1) {
        in_RAX = (int64_t *)arg2;
    }
    iVar3 = *in_RAX;
    iVar2 = fcn.180088860();
    if (iVar2 < 1) {
        fcn.180088380();
        pcVar1 = (code *)swi(3);
        uVar4 = (*pcVar1)();
        return uVar4;
    }
    if ((int32_t)(uint32_t)*(uint8_t *)(iVar3 + 4) < iVar2) {
        fcn.180088380();
        pcVar1 = (code *)swi(3);
        uVar4 = (*pcVar1)();
        return uVar4;
    }
    iVar3 = fcn.180088160();
    if (iVar3 != 0) {
        return 1;
    }
    fcn.1800883d0();
    pcVar1 = (code *)swi(3);
    uVar4 = (*pcVar1)();
    return uVar4;
}

// ============================================================
// Function: FUN_180034b0e
// Address: 0x180034b0e
// Size: 39 bytes
// ============================================================
void fcn.180034b0e(void)
{
    code *pcVar1;
    
    fcn.180088380();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180034b35
// Address: 0x180034b35
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_30h

undefined8 fcn.180034ac0(int64_t arg1, int64_t arg2, int64_t arg_30h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t *in_RAX;
    int64_t iVar3;
    undefined8 uVar4;
    
    if (in_RAX == (int64_t *)arg1) {
        in_RAX = (int64_t *)arg2;
    }
    iVar3 = *in_RAX;
    iVar2 = fcn.180088860();
    if (iVar2 < 1) {
        fcn.180088380();
        pcVar1 = (code *)swi(3);
        uVar4 = (*pcVar1)();
        return uVar4;
    }
    if ((int32_t)(uint32_t)*(uint8_t *)(iVar3 + 4) < iVar2) {
        fcn.180088380();
        pcVar1 = (code *)swi(3);
        uVar4 = (*pcVar1)();
        return uVar4;
    }
    iVar3 = fcn.180088160();
    if (iVar3 != 0) {
        return 1;
    }
    fcn.1800883d0();
    pcVar1 = (code *)swi(3);
    uVar4 = (*pcVar1)();
    return uVar4;
}

// ============================================================
// Function: FUN_180034b70
// Address: 0x180034b70
// Size: 120 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180034b70(int64_t arg1)
{
    uint8_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t *piVar10;
    undefined8 uVar11;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
        iVar9 = func_0x000180085d50(arg1);
        if (iVar9 == 0) {
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar5 = (code *)swi(3);
            uVar11 = (*pcVar5)();
            return uVar11;
        }
        func_0x000180033bd0();
    } else {
        func_0x000180085bf0(arg1);
    }
    piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    if (piVar10 == *(int64_t **)0x180782430) {
        piVar10 = (int64_t *)0x0;
    }
    iVar2 = *piVar10;
    if (*(char *)(iVar2 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    iVar9 = fcn.180088860(arg1, 2);
    if (iVar9 < 1) {
        fcn.180088380(arg1, 1, 0x180622550);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    if (iVar9 <= (int32_t)(uint32_t)*(uint8_t *)(iVar2 + 4)) {
        piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
        if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
            piVar10 = *(int64_t **)0x180782430;
        }
        if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) == -1)) {
            fcn.180088560(arg1, 0x18063da20, 3);
            pcVar5 = (code *)swi(3);
            uVar11 = (*pcVar5)();
            return uVar11;
        }
        func_0x000180085bf0(arg1, 3);
        iVar2 = *(int64_t *)(arg1 + 0x40);
        if (*(int32_t *)(iVar2 + -0x14) != 8) {
            return 0;
        }
        iVar3 = *(int64_t *)(iVar2 + -0x20);
        if (*(char *)(iVar3 + 3) == '\0') {
            iVar4 = *(int64_t *)(iVar3 + 0x20);
            if ((int32_t)(uint32_t)*(uint8_t *)(iVar4 + 6) < iVar9) {
                return 0;
            }
            piVar10 = (int64_t *)((int64_t)iVar9 * 0x10 + 0x18 + iVar3);
            if (*(int32_t *)((int64_t)piVar10 + 0xc) == 0x10) {
                piVar10 = *(int64_t **)(*piVar10 + 8);
            }
            if ((iVar9 <= *(int32_t *)(iVar4 + 0x94)) &&
               (*(int64_t *)(((int64_t)iVar9 * 8 - *(int64_t *)(iVar4 + 8)) + iVar4) == -0x18)) {
                return 0;
            }
        } else {
            if ((int32_t)(uint32_t)*(uint8_t *)(iVar3 + 4) < iVar9) {
                return 0;
            }
            piVar10 = (int64_t *)((int64_t)(iVar9 + -1) * 0x10 + 0x38 + iVar3);
        }
        *(undefined4 **)(arg1 + 0x40) = (undefined4 *)(iVar2 + -0x10);
        uVar6 = *(undefined4 *)(iVar2 + -0xc);
        uVar7 = *(undefined4 *)(iVar2 + -8);
        uVar8 = *(undefined4 *)(iVar2 + -4);
        *(undefined4 *)piVar10 = *(undefined4 *)(iVar2 + -0x10);
        *(undefined4 *)((int64_t)piVar10 + 4) = uVar6;
        *(undefined4 *)(piVar10 + 1) = uVar7;
        *(undefined4 *)((int64_t)piVar10 + 0xc) = uVar8;
        if (5 < *(int32_t *)((int64_t)*(int64_t **)(arg1 + 0x40) + 0xc)) {
            uVar1 = *(uint8_t *)(*(int64_t *)(iVar2 + -0x20) + 1);
            if (((uVar1 & 4) != 0) && ((*(uint8_t *)(**(int64_t **)(arg1 + 0x40) + 1) & 3) != 0)) {
                iVar3 = *(int64_t *)(arg1 + 0x20);
                if (2 < (uint8_t)(*(char *)(iVar3 + 0x59) - 1U)) {
                    *(uint8_t *)(*(int64_t *)(iVar2 + -0x20) + 1) = *(uint8_t *)(iVar3 + 0x58) & 3 | uVar1 & 0xf8;
                    return 0;
                }
                func_0x000180094420(iVar3);
            }
        }
        return 0;
    }
    fcn.180088380(arg1, 2, 0x1806225b0);
    pcVar5 = (code *)swi(3);
    uVar11 = (*pcVar5)();
    return uVar11;
}

// ============================================================
// Function: FUN_180034be8
// Address: 0x180034be8
// Size: 348 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180034b70(int64_t arg1)
{
    uint8_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t *piVar10;
    undefined8 uVar11;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
        iVar9 = func_0x000180085d50(arg1);
        if (iVar9 == 0) {
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar5 = (code *)swi(3);
            uVar11 = (*pcVar5)();
            return uVar11;
        }
        func_0x000180033bd0();
    } else {
        func_0x000180085bf0(arg1);
    }
    piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    if (piVar10 == *(int64_t **)0x180782430) {
        piVar10 = (int64_t *)0x0;
    }
    iVar2 = *piVar10;
    if (*(char *)(iVar2 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    iVar9 = fcn.180088860(arg1, 2);
    if (iVar9 < 1) {
        fcn.180088380(arg1, 1, 0x180622550);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    if (iVar9 <= (int32_t)(uint32_t)*(uint8_t *)(iVar2 + 4)) {
        piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
        if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
            piVar10 = *(int64_t **)0x180782430;
        }
        if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) == -1)) {
            fcn.180088560(arg1, 0x18063da20, 3);
            pcVar5 = (code *)swi(3);
            uVar11 = (*pcVar5)();
            return uVar11;
        }
        func_0x000180085bf0(arg1, 3);
        iVar2 = *(int64_t *)(arg1 + 0x40);
        if (*(int32_t *)(iVar2 + -0x14) != 8) {
            return 0;
        }
        iVar3 = *(int64_t *)(iVar2 + -0x20);
        if (*(char *)(iVar3 + 3) == '\0') {
            iVar4 = *(int64_t *)(iVar3 + 0x20);
            if ((int32_t)(uint32_t)*(uint8_t *)(iVar4 + 6) < iVar9) {
                return 0;
            }
            piVar10 = (int64_t *)((int64_t)iVar9 * 0x10 + 0x18 + iVar3);
            if (*(int32_t *)((int64_t)piVar10 + 0xc) == 0x10) {
                piVar10 = *(int64_t **)(*piVar10 + 8);
            }
            if ((iVar9 <= *(int32_t *)(iVar4 + 0x94)) &&
               (*(int64_t *)(((int64_t)iVar9 * 8 - *(int64_t *)(iVar4 + 8)) + iVar4) == -0x18)) {
                return 0;
            }
        } else {
            if ((int32_t)(uint32_t)*(uint8_t *)(iVar3 + 4) < iVar9) {
                return 0;
            }
            piVar10 = (int64_t *)((int64_t)(iVar9 + -1) * 0x10 + 0x38 + iVar3);
        }
        *(undefined4 **)(arg1 + 0x40) = (undefined4 *)(iVar2 + -0x10);
        uVar6 = *(undefined4 *)(iVar2 + -0xc);
        uVar7 = *(undefined4 *)(iVar2 + -8);
        uVar8 = *(undefined4 *)(iVar2 + -4);
        *(undefined4 *)piVar10 = *(undefined4 *)(iVar2 + -0x10);
        *(undefined4 *)((int64_t)piVar10 + 4) = uVar6;
        *(undefined4 *)(piVar10 + 1) = uVar7;
        *(undefined4 *)((int64_t)piVar10 + 0xc) = uVar8;
        if (5 < *(int32_t *)((int64_t)*(int64_t **)(arg1 + 0x40) + 0xc)) {
            uVar1 = *(uint8_t *)(*(int64_t *)(iVar2 + -0x20) + 1);
            if (((uVar1 & 4) != 0) && ((*(uint8_t *)(**(int64_t **)(arg1 + 0x40) + 1) & 3) != 0)) {
                iVar3 = *(int64_t *)(arg1 + 0x20);
                if (2 < (uint8_t)(*(char *)(iVar3 + 0x59) - 1U)) {
                    *(uint8_t *)(*(int64_t *)(iVar2 + -0x20) + 1) = *(uint8_t *)(iVar3 + 0x58) & 3 | uVar1 & 0xf8;
                    return 0;
                }
                func_0x000180094420(iVar3);
            }
        }
        return 0;
    }
    fcn.180088380(arg1, 2, 0x1806225b0);
    pcVar5 = (code *)swi(3);
    uVar11 = (*pcVar5)();
    return uVar11;
}

// ============================================================
// Function: FUN_180034d44
// Address: 0x180034d44
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180034b70(int64_t arg1)
{
    uint8_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t *piVar10;
    undefined8 uVar11;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
        iVar9 = func_0x000180085d50(arg1);
        if (iVar9 == 0) {
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar5 = (code *)swi(3);
            uVar11 = (*pcVar5)();
            return uVar11;
        }
        func_0x000180033bd0();
    } else {
        func_0x000180085bf0(arg1);
    }
    piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    if (piVar10 == *(int64_t **)0x180782430) {
        piVar10 = (int64_t *)0x0;
    }
    iVar2 = *piVar10;
    if (*(char *)(iVar2 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    iVar9 = fcn.180088860(arg1, 2);
    if (iVar9 < 1) {
        fcn.180088380(arg1, 1, 0x180622550);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    if (iVar9 <= (int32_t)(uint32_t)*(uint8_t *)(iVar2 + 4)) {
        piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
        if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
            piVar10 = *(int64_t **)0x180782430;
        }
        if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) == -1)) {
            fcn.180088560(arg1, 0x18063da20, 3);
            pcVar5 = (code *)swi(3);
            uVar11 = (*pcVar5)();
            return uVar11;
        }
        func_0x000180085bf0(arg1, 3);
        iVar2 = *(int64_t *)(arg1 + 0x40);
        if (*(int32_t *)(iVar2 + -0x14) != 8) {
            return 0;
        }
        iVar3 = *(int64_t *)(iVar2 + -0x20);
        if (*(char *)(iVar3 + 3) == '\0') {
            iVar4 = *(int64_t *)(iVar3 + 0x20);
            if ((int32_t)(uint32_t)*(uint8_t *)(iVar4 + 6) < iVar9) {
                return 0;
            }
            piVar10 = (int64_t *)((int64_t)iVar9 * 0x10 + 0x18 + iVar3);
            if (*(int32_t *)((int64_t)piVar10 + 0xc) == 0x10) {
                piVar10 = *(int64_t **)(*piVar10 + 8);
            }
            if ((iVar9 <= *(int32_t *)(iVar4 + 0x94)) &&
               (*(int64_t *)(((int64_t)iVar9 * 8 - *(int64_t *)(iVar4 + 8)) + iVar4) == -0x18)) {
                return 0;
            }
        } else {
            if ((int32_t)(uint32_t)*(uint8_t *)(iVar3 + 4) < iVar9) {
                return 0;
            }
            piVar10 = (int64_t *)((int64_t)(iVar9 + -1) * 0x10 + 0x38 + iVar3);
        }
        *(undefined4 **)(arg1 + 0x40) = (undefined4 *)(iVar2 + -0x10);
        uVar6 = *(undefined4 *)(iVar2 + -0xc);
        uVar7 = *(undefined4 *)(iVar2 + -8);
        uVar8 = *(undefined4 *)(iVar2 + -4);
        *(undefined4 *)piVar10 = *(undefined4 *)(iVar2 + -0x10);
        *(undefined4 *)((int64_t)piVar10 + 4) = uVar6;
        *(undefined4 *)(piVar10 + 1) = uVar7;
        *(undefined4 *)((int64_t)piVar10 + 0xc) = uVar8;
        if (5 < *(int32_t *)((int64_t)*(int64_t **)(arg1 + 0x40) + 0xc)) {
            uVar1 = *(uint8_t *)(*(int64_t *)(iVar2 + -0x20) + 1);
            if (((uVar1 & 4) != 0) && ((*(uint8_t *)(**(int64_t **)(arg1 + 0x40) + 1) & 3) != 0)) {
                iVar3 = *(int64_t *)(arg1 + 0x20);
                if (2 < (uint8_t)(*(char *)(iVar3 + 0x59) - 1U)) {
                    *(uint8_t *)(*(int64_t *)(iVar2 + -0x20) + 1) = *(uint8_t *)(iVar3 + 0x58) & 3 | uVar1 & 0xf8;
                    return 0;
                }
                func_0x000180094420(iVar3);
            }
        }
        return 0;
    }
    fcn.180088380(arg1, 2, 0x1806225b0);
    pcVar5 = (code *)swi(3);
    uVar11 = (*pcVar5)();
    return uVar11;
}

// ============================================================
// Function: FUN_180034d5e
// Address: 0x180034d5e
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180034b70(int64_t arg1)
{
    uint8_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t *piVar10;
    undefined8 uVar11;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
        iVar9 = func_0x000180085d50(arg1);
        if (iVar9 == 0) {
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar5 = (code *)swi(3);
            uVar11 = (*pcVar5)();
            return uVar11;
        }
        func_0x000180033bd0();
    } else {
        func_0x000180085bf0(arg1);
    }
    piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    if (piVar10 == *(int64_t **)0x180782430) {
        piVar10 = (int64_t *)0x0;
    }
    iVar2 = *piVar10;
    if (*(char *)(iVar2 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    iVar9 = fcn.180088860(arg1, 2);
    if (iVar9 < 1) {
        fcn.180088380(arg1, 1, 0x180622550);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    if (iVar9 <= (int32_t)(uint32_t)*(uint8_t *)(iVar2 + 4)) {
        piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
        if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
            piVar10 = *(int64_t **)0x180782430;
        }
        if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) == -1)) {
            fcn.180088560(arg1, 0x18063da20, 3);
            pcVar5 = (code *)swi(3);
            uVar11 = (*pcVar5)();
            return uVar11;
        }
        func_0x000180085bf0(arg1, 3);
        iVar2 = *(int64_t *)(arg1 + 0x40);
        if (*(int32_t *)(iVar2 + -0x14) != 8) {
            return 0;
        }
        iVar3 = *(int64_t *)(iVar2 + -0x20);
        if (*(char *)(iVar3 + 3) == '\0') {
            iVar4 = *(int64_t *)(iVar3 + 0x20);
            if ((int32_t)(uint32_t)*(uint8_t *)(iVar4 + 6) < iVar9) {
                return 0;
            }
            piVar10 = (int64_t *)((int64_t)iVar9 * 0x10 + 0x18 + iVar3);
            if (*(int32_t *)((int64_t)piVar10 + 0xc) == 0x10) {
                piVar10 = *(int64_t **)(*piVar10 + 8);
            }
            if ((iVar9 <= *(int32_t *)(iVar4 + 0x94)) &&
               (*(int64_t *)(((int64_t)iVar9 * 8 - *(int64_t *)(iVar4 + 8)) + iVar4) == -0x18)) {
                return 0;
            }
        } else {
            if ((int32_t)(uint32_t)*(uint8_t *)(iVar3 + 4) < iVar9) {
                return 0;
            }
            piVar10 = (int64_t *)((int64_t)(iVar9 + -1) * 0x10 + 0x38 + iVar3);
        }
        *(undefined4 **)(arg1 + 0x40) = (undefined4 *)(iVar2 + -0x10);
        uVar6 = *(undefined4 *)(iVar2 + -0xc);
        uVar7 = *(undefined4 *)(iVar2 + -8);
        uVar8 = *(undefined4 *)(iVar2 + -4);
        *(undefined4 *)piVar10 = *(undefined4 *)(iVar2 + -0x10);
        *(undefined4 *)((int64_t)piVar10 + 4) = uVar6;
        *(undefined4 *)(piVar10 + 1) = uVar7;
        *(undefined4 *)((int64_t)piVar10 + 0xc) = uVar8;
        if (5 < *(int32_t *)((int64_t)*(int64_t **)(arg1 + 0x40) + 0xc)) {
            uVar1 = *(uint8_t *)(*(int64_t *)(iVar2 + -0x20) + 1);
            if (((uVar1 & 4) != 0) && ((*(uint8_t *)(**(int64_t **)(arg1 + 0x40) + 1) & 3) != 0)) {
                iVar3 = *(int64_t *)(arg1 + 0x20);
                if (2 < (uint8_t)(*(char *)(iVar3 + 0x59) - 1U)) {
                    *(uint8_t *)(*(int64_t *)(iVar2 + -0x20) + 1) = *(uint8_t *)(iVar3 + 0x58) & 3 | uVar1 & 0xf8;
                    return 0;
                }
                func_0x000180094420(iVar3);
            }
        }
        return 0;
    }
    fcn.180088380(arg1, 2, 0x1806225b0);
    pcVar5 = (code *)swi(3);
    uVar11 = (*pcVar5)();
    return uVar11;
}

// ============================================================
// Function: FUN_180034d85
// Address: 0x180034d85
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180034b70(int64_t arg1)
{
    uint8_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t *piVar10;
    undefined8 uVar11;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
        iVar9 = func_0x000180085d50(arg1);
        if (iVar9 == 0) {
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar5 = (code *)swi(3);
            uVar11 = (*pcVar5)();
            return uVar11;
        }
        func_0x000180033bd0();
    } else {
        func_0x000180085bf0(arg1);
    }
    piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    if (piVar10 == *(int64_t **)0x180782430) {
        piVar10 = (int64_t *)0x0;
    }
    iVar2 = *piVar10;
    if (*(char *)(iVar2 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    iVar9 = fcn.180088860(arg1, 2);
    if (iVar9 < 1) {
        fcn.180088380(arg1, 1, 0x180622550);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    if (iVar9 <= (int32_t)(uint32_t)*(uint8_t *)(iVar2 + 4)) {
        piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
        if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
            piVar10 = *(int64_t **)0x180782430;
        }
        if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) == -1)) {
            fcn.180088560(arg1, 0x18063da20, 3);
            pcVar5 = (code *)swi(3);
            uVar11 = (*pcVar5)();
            return uVar11;
        }
        func_0x000180085bf0(arg1, 3);
        iVar2 = *(int64_t *)(arg1 + 0x40);
        if (*(int32_t *)(iVar2 + -0x14) != 8) {
            return 0;
        }
        iVar3 = *(int64_t *)(iVar2 + -0x20);
        if (*(char *)(iVar3 + 3) == '\0') {
            iVar4 = *(int64_t *)(iVar3 + 0x20);
            if ((int32_t)(uint32_t)*(uint8_t *)(iVar4 + 6) < iVar9) {
                return 0;
            }
            piVar10 = (int64_t *)((int64_t)iVar9 * 0x10 + 0x18 + iVar3);
            if (*(int32_t *)((int64_t)piVar10 + 0xc) == 0x10) {
                piVar10 = *(int64_t **)(*piVar10 + 8);
            }
            if ((iVar9 <= *(int32_t *)(iVar4 + 0x94)) &&
               (*(int64_t *)(((int64_t)iVar9 * 8 - *(int64_t *)(iVar4 + 8)) + iVar4) == -0x18)) {
                return 0;
            }
        } else {
            if ((int32_t)(uint32_t)*(uint8_t *)(iVar3 + 4) < iVar9) {
                return 0;
            }
            piVar10 = (int64_t *)((int64_t)(iVar9 + -1) * 0x10 + 0x38 + iVar3);
        }
        *(undefined4 **)(arg1 + 0x40) = (undefined4 *)(iVar2 + -0x10);
        uVar6 = *(undefined4 *)(iVar2 + -0xc);
        uVar7 = *(undefined4 *)(iVar2 + -8);
        uVar8 = *(undefined4 *)(iVar2 + -4);
        *(undefined4 *)piVar10 = *(undefined4 *)(iVar2 + -0x10);
        *(undefined4 *)((int64_t)piVar10 + 4) = uVar6;
        *(undefined4 *)(piVar10 + 1) = uVar7;
        *(undefined4 *)((int64_t)piVar10 + 0xc) = uVar8;
        if (5 < *(int32_t *)((int64_t)*(int64_t **)(arg1 + 0x40) + 0xc)) {
            uVar1 = *(uint8_t *)(*(int64_t *)(iVar2 + -0x20) + 1);
            if (((uVar1 & 4) != 0) && ((*(uint8_t *)(**(int64_t **)(arg1 + 0x40) + 1) & 3) != 0)) {
                iVar3 = *(int64_t *)(arg1 + 0x20);
                if (2 < (uint8_t)(*(char *)(iVar3 + 0x59) - 1U)) {
                    *(uint8_t *)(*(int64_t *)(iVar2 + -0x20) + 1) = *(uint8_t *)(iVar3 + 0x58) & 3 | uVar1 & 0xf8;
                    return 0;
                }
                func_0x000180094420(iVar3);
            }
        }
        return 0;
    }
    fcn.180088380(arg1, 2, 0x1806225b0);
    pcVar5 = (code *)swi(3);
    uVar11 = (*pcVar5)();
    return uVar11;
}

// ============================================================
// Function: FUN_180034d97
// Address: 0x180034d97
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180034b70(int64_t arg1)
{
    uint8_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t *piVar10;
    undefined8 uVar11;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
        iVar9 = func_0x000180085d50(arg1);
        if (iVar9 == 0) {
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar5 = (code *)swi(3);
            uVar11 = (*pcVar5)();
            return uVar11;
        }
        func_0x000180033bd0();
    } else {
        func_0x000180085bf0(arg1);
    }
    piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    if (piVar10 == *(int64_t **)0x180782430) {
        piVar10 = (int64_t *)0x0;
    }
    iVar2 = *piVar10;
    if (*(char *)(iVar2 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    iVar9 = fcn.180088860(arg1, 2);
    if (iVar9 < 1) {
        fcn.180088380(arg1, 1, 0x180622550);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    if (iVar9 <= (int32_t)(uint32_t)*(uint8_t *)(iVar2 + 4)) {
        piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
        if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
            piVar10 = *(int64_t **)0x180782430;
        }
        if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) == -1)) {
            fcn.180088560(arg1, 0x18063da20, 3);
            pcVar5 = (code *)swi(3);
            uVar11 = (*pcVar5)();
            return uVar11;
        }
        func_0x000180085bf0(arg1, 3);
        iVar2 = *(int64_t *)(arg1 + 0x40);
        if (*(int32_t *)(iVar2 + -0x14) != 8) {
            return 0;
        }
        iVar3 = *(int64_t *)(iVar2 + -0x20);
        if (*(char *)(iVar3 + 3) == '\0') {
            iVar4 = *(int64_t *)(iVar3 + 0x20);
            if ((int32_t)(uint32_t)*(uint8_t *)(iVar4 + 6) < iVar9) {
                return 0;
            }
            piVar10 = (int64_t *)((int64_t)iVar9 * 0x10 + 0x18 + iVar3);
            if (*(int32_t *)((int64_t)piVar10 + 0xc) == 0x10) {
                piVar10 = *(int64_t **)(*piVar10 + 8);
            }
            if ((iVar9 <= *(int32_t *)(iVar4 + 0x94)) &&
               (*(int64_t *)(((int64_t)iVar9 * 8 - *(int64_t *)(iVar4 + 8)) + iVar4) == -0x18)) {
                return 0;
            }
        } else {
            if ((int32_t)(uint32_t)*(uint8_t *)(iVar3 + 4) < iVar9) {
                return 0;
            }
            piVar10 = (int64_t *)((int64_t)(iVar9 + -1) * 0x10 + 0x38 + iVar3);
        }
        *(undefined4 **)(arg1 + 0x40) = (undefined4 *)(iVar2 + -0x10);
        uVar6 = *(undefined4 *)(iVar2 + -0xc);
        uVar7 = *(undefined4 *)(iVar2 + -8);
        uVar8 = *(undefined4 *)(iVar2 + -4);
        *(undefined4 *)piVar10 = *(undefined4 *)(iVar2 + -0x10);
        *(undefined4 *)((int64_t)piVar10 + 4) = uVar6;
        *(undefined4 *)(piVar10 + 1) = uVar7;
        *(undefined4 *)((int64_t)piVar10 + 0xc) = uVar8;
        if (5 < *(int32_t *)((int64_t)*(int64_t **)(arg1 + 0x40) + 0xc)) {
            uVar1 = *(uint8_t *)(*(int64_t *)(iVar2 + -0x20) + 1);
            if (((uVar1 & 4) != 0) && ((*(uint8_t *)(**(int64_t **)(arg1 + 0x40) + 1) & 3) != 0)) {
                iVar3 = *(int64_t *)(arg1 + 0x20);
                if (2 < (uint8_t)(*(char *)(iVar3 + 0x59) - 1U)) {
                    *(uint8_t *)(*(int64_t *)(iVar2 + -0x20) + 1) = *(uint8_t *)(iVar3 + 0x58) & 3 | uVar1 & 0xf8;
                    return 0;
                }
                func_0x000180094420(iVar3);
            }
        }
        return 0;
    }
    fcn.180088380(arg1, 2, 0x1806225b0);
    pcVar5 = (code *)swi(3);
    uVar11 = (*pcVar5)();
    return uVar11;
}

// ============================================================
// Function: FUN_180034de0
// Address: 0x180034de0
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h

undefined8 fcn.180034de0(int64_t arg1, int64_t arg_80h, int64_t arg_a8h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t *piVar10;
    undefined4 *puVar11;
    undefined8 uVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t *piVar15;
    undefined8 *puVar16;
    int32_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar15 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar15 = *(int64_t **)0x180782430;
    }
    if ((piVar15 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar15 + 0xc) != 8)) {
        iVar17 = func_0x000180085d50(arg1, 1);
        if (iVar17 == 0) {
            piVar15 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar10 = piVar15;
            if (piVar1 <= piVar15) {
                piVar10 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar10 + 0xc) == 2)) {
                piVar10 = piVar15;
                if (piVar1 <= piVar15) {
                    piVar10 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) && (*(char *)(*piVar10 + 3) == 'x')) {
                    if (piVar1 <= piVar15) {
                        piVar15 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar15 + 0xc) == 9) && (*(char *)(*piVar15 + 3) == 'x')) {
                        puVar11 = (undefined4 *)(*piVar15 + 0x10);
                    } else {
                        puVar11 = (undefined4 *)0x0;
                    }
                    iVar17 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar11);
                    if (iVar17 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar5 = (code *)swi(3);
                        uVar12 = (*pcVar5)();
                        return uVar12;
                    }
                    goto code_r0x000180034e15;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar5 = (code *)swi(3);
            uVar12 = (*pcVar5)();
            return uVar12;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180034e15:
    piVar15 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar15 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    if (piVar15 == *(int64_t **)0x180782430) {
        piVar15 = (int64_t *)0x0;
    }
    if (*(char *)(*piVar15 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    iVar2 = *(int64_t *)(*piVar15 + 0x20);
    func_0x000180086fd0(arg1, *(undefined4 *)(iVar2 + 0xa8), 0);
    iVar17 = 0;
    if (0 < *(int32_t *)(iVar2 + 0xa8)) {
        do {
            puVar16 = (undefined8 *)((int64_t)iVar17 * 0x10 + *(int64_t *)(iVar2 + 0x38));
            if (*(int32_t *)((int64_t)puVar16 + 0xc) == 8) {
                func_0x000180087f70(arg1, 0, 0);
            } else {
                if ((5 < *(int32_t *)((int64_t)puVar16 + 0xc)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                **(undefined8 **)(arg1 + 0x40) = *puVar16;
                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)((int64_t)puVar16 + 0xc);
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar13 = *(int32_t *)(arg1 + 0x60) - (int32_t)arg1;
                    iVar14 = iVar13 + -0x60;
                    iVar6 = iVar14 * 2;
                    if (iVar14 < 1) {
                        iVar6 = iVar13 + -0x5f;
                    }
                    func_0x000180093240(arg1, iVar6, 0);
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            }
            iVar3 = *(int64_t *)(arg1 + 0x40);
            if (*(char *)(*(int64_t *)(iVar3 + -0x20) + 4) != '\0') {
                func_0x000180092f10(arg1);
                pcVar5 = (code *)swi(3);
                uVar12 = (*pcVar5)();
                return uVar12;
            }
            iVar17 = iVar17 + 1;
            puVar11 = (undefined4 *)func_0x0001800a1010();
            uVar7 = *(undefined4 *)(iVar3 + -0xc);
            uVar8 = *(undefined4 *)(iVar3 + -8);
            uVar9 = *(undefined4 *)(iVar3 + -4);
            *puVar11 = *(undefined4 *)(iVar3 + -0x10);
            puVar11[1] = uVar7;
            puVar11[2] = uVar8;
            puVar11[3] = uVar9;
            if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                iVar3 = *(int64_t *)(iVar3 + -0x20);
                if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                   ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                    iVar4 = *(int64_t *)(arg1 + 0x20);
                    if (*(char *)(iVar4 + 0x59) == '\x02') {
                        func_0x000180094420();
                    } else {
                        *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                        *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar4 + 0x18);
                        *(int64_t *)(iVar4 + 0x18) = iVar3;
                    }
                }
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        } while (iVar17 < *(int32_t *)(iVar2 + 0xa8));
    }
    return 1;
}

// ============================================================
// Function: FUN_180034e39
// Address: 0x180034e39
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h

undefined8 fcn.180034de0(int64_t arg1, int64_t arg_80h, int64_t arg_a8h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t *piVar10;
    undefined4 *puVar11;
    undefined8 uVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t *piVar15;
    undefined8 *puVar16;
    int32_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar15 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar15 = *(int64_t **)0x180782430;
    }
    if ((piVar15 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar15 + 0xc) != 8)) {
        iVar17 = func_0x000180085d50(arg1, 1);
        if (iVar17 == 0) {
            piVar15 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar10 = piVar15;
            if (piVar1 <= piVar15) {
                piVar10 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar10 + 0xc) == 2)) {
                piVar10 = piVar15;
                if (piVar1 <= piVar15) {
                    piVar10 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) && (*(char *)(*piVar10 + 3) == 'x')) {
                    if (piVar1 <= piVar15) {
                        piVar15 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar15 + 0xc) == 9) && (*(char *)(*piVar15 + 3) == 'x')) {
                        puVar11 = (undefined4 *)(*piVar15 + 0x10);
                    } else {
                        puVar11 = (undefined4 *)0x0;
                    }
                    iVar17 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar11);
                    if (iVar17 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar5 = (code *)swi(3);
                        uVar12 = (*pcVar5)();
                        return uVar12;
                    }
                    goto code_r0x000180034e15;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar5 = (code *)swi(3);
            uVar12 = (*pcVar5)();
            return uVar12;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180034e15:
    piVar15 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar15 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    if (piVar15 == *(int64_t **)0x180782430) {
        piVar15 = (int64_t *)0x0;
    }
    if (*(char *)(*piVar15 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    iVar2 = *(int64_t *)(*piVar15 + 0x20);
    func_0x000180086fd0(arg1, *(undefined4 *)(iVar2 + 0xa8), 0);
    iVar17 = 0;
    if (0 < *(int32_t *)(iVar2 + 0xa8)) {
        do {
            puVar16 = (undefined8 *)((int64_t)iVar17 * 0x10 + *(int64_t *)(iVar2 + 0x38));
            if (*(int32_t *)((int64_t)puVar16 + 0xc) == 8) {
                func_0x000180087f70(arg1, 0, 0);
            } else {
                if ((5 < *(int32_t *)((int64_t)puVar16 + 0xc)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                **(undefined8 **)(arg1 + 0x40) = *puVar16;
                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)((int64_t)puVar16 + 0xc);
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar13 = *(int32_t *)(arg1 + 0x60) - (int32_t)arg1;
                    iVar14 = iVar13 + -0x60;
                    iVar6 = iVar14 * 2;
                    if (iVar14 < 1) {
                        iVar6 = iVar13 + -0x5f;
                    }
                    func_0x000180093240(arg1, iVar6, 0);
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            }
            iVar3 = *(int64_t *)(arg1 + 0x40);
            if (*(char *)(*(int64_t *)(iVar3 + -0x20) + 4) != '\0') {
                func_0x000180092f10(arg1);
                pcVar5 = (code *)swi(3);
                uVar12 = (*pcVar5)();
                return uVar12;
            }
            iVar17 = iVar17 + 1;
            puVar11 = (undefined4 *)func_0x0001800a1010();
            uVar7 = *(undefined4 *)(iVar3 + -0xc);
            uVar8 = *(undefined4 *)(iVar3 + -8);
            uVar9 = *(undefined4 *)(iVar3 + -4);
            *puVar11 = *(undefined4 *)(iVar3 + -0x10);
            puVar11[1] = uVar7;
            puVar11[2] = uVar8;
            puVar11[3] = uVar9;
            if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                iVar3 = *(int64_t *)(iVar3 + -0x20);
                if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                   ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                    iVar4 = *(int64_t *)(arg1 + 0x20);
                    if (*(char *)(iVar4 + 0x59) == '\x02') {
                        func_0x000180094420();
                    } else {
                        *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                        *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar4 + 0x18);
                        *(int64_t *)(iVar4 + 0x18) = iVar3;
                    }
                }
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        } while (iVar17 < *(int32_t *)(iVar2 + 0xa8));
    }
    return 1;
}

// ============================================================
// Function: FUN_180034e59
// Address: 0x180034e59
// Size: 166 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h

undefined8 fcn.180034de0(int64_t arg1, int64_t arg_80h, int64_t arg_a8h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t *piVar10;
    undefined4 *puVar11;
    undefined8 uVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t *piVar15;
    undefined8 *puVar16;
    int32_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar15 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar15 = *(int64_t **)0x180782430;
    }
    if ((piVar15 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar15 + 0xc) != 8)) {
        iVar17 = func_0x000180085d50(arg1, 1);
        if (iVar17 == 0) {
            piVar15 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar10 = piVar15;
            if (piVar1 <= piVar15) {
                piVar10 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar10 + 0xc) == 2)) {
                piVar10 = piVar15;
                if (piVar1 <= piVar15) {
                    piVar10 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) && (*(char *)(*piVar10 + 3) == 'x')) {
                    if (piVar1 <= piVar15) {
                        piVar15 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar15 + 0xc) == 9) && (*(char *)(*piVar15 + 3) == 'x')) {
                        puVar11 = (undefined4 *)(*piVar15 + 0x10);
                    } else {
                        puVar11 = (undefined4 *)0x0;
                    }
                    iVar17 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar11);
                    if (iVar17 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar5 = (code *)swi(3);
                        uVar12 = (*pcVar5)();
                        return uVar12;
                    }
                    goto code_r0x000180034e15;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar5 = (code *)swi(3);
            uVar12 = (*pcVar5)();
            return uVar12;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180034e15:
    piVar15 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar15 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    if (piVar15 == *(int64_t **)0x180782430) {
        piVar15 = (int64_t *)0x0;
    }
    if (*(char *)(*piVar15 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    iVar2 = *(int64_t *)(*piVar15 + 0x20);
    func_0x000180086fd0(arg1, *(undefined4 *)(iVar2 + 0xa8), 0);
    iVar17 = 0;
    if (0 < *(int32_t *)(iVar2 + 0xa8)) {
        do {
            puVar16 = (undefined8 *)((int64_t)iVar17 * 0x10 + *(int64_t *)(iVar2 + 0x38));
            if (*(int32_t *)((int64_t)puVar16 + 0xc) == 8) {
                func_0x000180087f70(arg1, 0, 0);
            } else {
                if ((5 < *(int32_t *)((int64_t)puVar16 + 0xc)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                **(undefined8 **)(arg1 + 0x40) = *puVar16;
                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)((int64_t)puVar16 + 0xc);
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar13 = *(int32_t *)(arg1 + 0x60) - (int32_t)arg1;
                    iVar14 = iVar13 + -0x60;
                    iVar6 = iVar14 * 2;
                    if (iVar14 < 1) {
                        iVar6 = iVar13 + -0x5f;
                    }
                    func_0x000180093240(arg1, iVar6, 0);
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            }
            iVar3 = *(int64_t *)(arg1 + 0x40);
            if (*(char *)(*(int64_t *)(iVar3 + -0x20) + 4) != '\0') {
                func_0x000180092f10(arg1);
                pcVar5 = (code *)swi(3);
                uVar12 = (*pcVar5)();
                return uVar12;
            }
            iVar17 = iVar17 + 1;
            puVar11 = (undefined4 *)func_0x0001800a1010();
            uVar7 = *(undefined4 *)(iVar3 + -0xc);
            uVar8 = *(undefined4 *)(iVar3 + -8);
            uVar9 = *(undefined4 *)(iVar3 + -4);
            *puVar11 = *(undefined4 *)(iVar3 + -0x10);
            puVar11[1] = uVar7;
            puVar11[2] = uVar8;
            puVar11[3] = uVar9;
            if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                iVar3 = *(int64_t *)(iVar3 + -0x20);
                if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                   ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                    iVar4 = *(int64_t *)(arg1 + 0x20);
                    if (*(char *)(iVar4 + 0x59) == '\x02') {
                        func_0x000180094420();
                    } else {
                        *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                        *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar4 + 0x18);
                        *(int64_t *)(iVar4 + 0x18) = iVar3;
                    }
                }
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        } while (iVar17 < *(int32_t *)(iVar2 + 0xa8));
    }
    return 1;
}

// ============================================================
// Function: FUN_180034eff
// Address: 0x180034eff
// Size: 336 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h

undefined8 fcn.180034de0(int64_t arg1, int64_t arg_80h, int64_t arg_a8h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t *piVar10;
    undefined4 *puVar11;
    undefined8 uVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t *piVar15;
    undefined8 *puVar16;
    int32_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar15 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar15 = *(int64_t **)0x180782430;
    }
    if ((piVar15 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar15 + 0xc) != 8)) {
        iVar17 = func_0x000180085d50(arg1, 1);
        if (iVar17 == 0) {
            piVar15 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar10 = piVar15;
            if (piVar1 <= piVar15) {
                piVar10 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar10 + 0xc) == 2)) {
                piVar10 = piVar15;
                if (piVar1 <= piVar15) {
                    piVar10 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) && (*(char *)(*piVar10 + 3) == 'x')) {
                    if (piVar1 <= piVar15) {
                        piVar15 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar15 + 0xc) == 9) && (*(char *)(*piVar15 + 3) == 'x')) {
                        puVar11 = (undefined4 *)(*piVar15 + 0x10);
                    } else {
                        puVar11 = (undefined4 *)0x0;
                    }
                    iVar17 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar11);
                    if (iVar17 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar5 = (code *)swi(3);
                        uVar12 = (*pcVar5)();
                        return uVar12;
                    }
                    goto code_r0x000180034e15;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar5 = (code *)swi(3);
            uVar12 = (*pcVar5)();
            return uVar12;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180034e15:
    piVar15 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar15 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    if (piVar15 == *(int64_t **)0x180782430) {
        piVar15 = (int64_t *)0x0;
    }
    if (*(char *)(*piVar15 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    iVar2 = *(int64_t *)(*piVar15 + 0x20);
    func_0x000180086fd0(arg1, *(undefined4 *)(iVar2 + 0xa8), 0);
    iVar17 = 0;
    if (0 < *(int32_t *)(iVar2 + 0xa8)) {
        do {
            puVar16 = (undefined8 *)((int64_t)iVar17 * 0x10 + *(int64_t *)(iVar2 + 0x38));
            if (*(int32_t *)((int64_t)puVar16 + 0xc) == 8) {
                func_0x000180087f70(arg1, 0, 0);
            } else {
                if ((5 < *(int32_t *)((int64_t)puVar16 + 0xc)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                **(undefined8 **)(arg1 + 0x40) = *puVar16;
                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)((int64_t)puVar16 + 0xc);
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar13 = *(int32_t *)(arg1 + 0x60) - (int32_t)arg1;
                    iVar14 = iVar13 + -0x60;
                    iVar6 = iVar14 * 2;
                    if (iVar14 < 1) {
                        iVar6 = iVar13 + -0x5f;
                    }
                    func_0x000180093240(arg1, iVar6, 0);
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            }
            iVar3 = *(int64_t *)(arg1 + 0x40);
            if (*(char *)(*(int64_t *)(iVar3 + -0x20) + 4) != '\0') {
                func_0x000180092f10(arg1);
                pcVar5 = (code *)swi(3);
                uVar12 = (*pcVar5)();
                return uVar12;
            }
            iVar17 = iVar17 + 1;
            puVar11 = (undefined4 *)func_0x0001800a1010();
            uVar7 = *(undefined4 *)(iVar3 + -0xc);
            uVar8 = *(undefined4 *)(iVar3 + -8);
            uVar9 = *(undefined4 *)(iVar3 + -4);
            *puVar11 = *(undefined4 *)(iVar3 + -0x10);
            puVar11[1] = uVar7;
            puVar11[2] = uVar8;
            puVar11[3] = uVar9;
            if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                iVar3 = *(int64_t *)(iVar3 + -0x20);
                if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                   ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                    iVar4 = *(int64_t *)(arg1 + 0x20);
                    if (*(char *)(iVar4 + 0x59) == '\x02') {
                        func_0x000180094420();
                    } else {
                        *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                        *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar4 + 0x18);
                        *(int64_t *)(iVar4 + 0x18) = iVar3;
                    }
                }
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        } while (iVar17 < *(int32_t *)(iVar2 + 0xa8));
    }
    return 1;
}

// ============================================================
// Function: FUN_18003504f
// Address: 0x18003504f
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h

undefined8 fcn.180034de0(int64_t arg1, int64_t arg_80h, int64_t arg_a8h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t *piVar10;
    undefined4 *puVar11;
    undefined8 uVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t *piVar15;
    undefined8 *puVar16;
    int32_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar15 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar15 = *(int64_t **)0x180782430;
    }
    if ((piVar15 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar15 + 0xc) != 8)) {
        iVar17 = func_0x000180085d50(arg1, 1);
        if (iVar17 == 0) {
            piVar15 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar10 = piVar15;
            if (piVar1 <= piVar15) {
                piVar10 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar10 + 0xc) == 2)) {
                piVar10 = piVar15;
                if (piVar1 <= piVar15) {
                    piVar10 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) && (*(char *)(*piVar10 + 3) == 'x')) {
                    if (piVar1 <= piVar15) {
                        piVar15 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar15 + 0xc) == 9) && (*(char *)(*piVar15 + 3) == 'x')) {
                        puVar11 = (undefined4 *)(*piVar15 + 0x10);
                    } else {
                        puVar11 = (undefined4 *)0x0;
                    }
                    iVar17 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar11);
                    if (iVar17 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar5 = (code *)swi(3);
                        uVar12 = (*pcVar5)();
                        return uVar12;
                    }
                    goto code_r0x000180034e15;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar5 = (code *)swi(3);
            uVar12 = (*pcVar5)();
            return uVar12;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180034e15:
    piVar15 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar15 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    if (piVar15 == *(int64_t **)0x180782430) {
        piVar15 = (int64_t *)0x0;
    }
    if (*(char *)(*piVar15 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    iVar2 = *(int64_t *)(*piVar15 + 0x20);
    func_0x000180086fd0(arg1, *(undefined4 *)(iVar2 + 0xa8), 0);
    iVar17 = 0;
    if (0 < *(int32_t *)(iVar2 + 0xa8)) {
        do {
            puVar16 = (undefined8 *)((int64_t)iVar17 * 0x10 + *(int64_t *)(iVar2 + 0x38));
            if (*(int32_t *)((int64_t)puVar16 + 0xc) == 8) {
                func_0x000180087f70(arg1, 0, 0);
            } else {
                if ((5 < *(int32_t *)((int64_t)puVar16 + 0xc)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                **(undefined8 **)(arg1 + 0x40) = *puVar16;
                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)((int64_t)puVar16 + 0xc);
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar13 = *(int32_t *)(arg1 + 0x60) - (int32_t)arg1;
                    iVar14 = iVar13 + -0x60;
                    iVar6 = iVar14 * 2;
                    if (iVar14 < 1) {
                        iVar6 = iVar13 + -0x5f;
                    }
                    func_0x000180093240(arg1, iVar6, 0);
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            }
            iVar3 = *(int64_t *)(arg1 + 0x40);
            if (*(char *)(*(int64_t *)(iVar3 + -0x20) + 4) != '\0') {
                func_0x000180092f10(arg1);
                pcVar5 = (code *)swi(3);
                uVar12 = (*pcVar5)();
                return uVar12;
            }
            iVar17 = iVar17 + 1;
            puVar11 = (undefined4 *)func_0x0001800a1010();
            uVar7 = *(undefined4 *)(iVar3 + -0xc);
            uVar8 = *(undefined4 *)(iVar3 + -8);
            uVar9 = *(undefined4 *)(iVar3 + -4);
            *puVar11 = *(undefined4 *)(iVar3 + -0x10);
            puVar11[1] = uVar7;
            puVar11[2] = uVar8;
            puVar11[3] = uVar9;
            if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                iVar3 = *(int64_t *)(iVar3 + -0x20);
                if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                   ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                    iVar4 = *(int64_t *)(arg1 + 0x20);
                    if (*(char *)(iVar4 + 0x59) == '\x02') {
                        func_0x000180094420();
                    } else {
                        *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                        *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar4 + 0x18);
                        *(int64_t *)(iVar4 + 0x18) = iVar3;
                    }
                }
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        } while (iVar17 < *(int32_t *)(iVar2 + 0xa8));
    }
    return 1;
}

// ============================================================
// Function: FUN_180035064
// Address: 0x180035064
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h

undefined8 fcn.180034de0(int64_t arg1, int64_t arg_80h, int64_t arg_a8h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t *piVar10;
    undefined4 *puVar11;
    undefined8 uVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t *piVar15;
    undefined8 *puVar16;
    int32_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar15 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar15 = *(int64_t **)0x180782430;
    }
    if ((piVar15 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar15 + 0xc) != 8)) {
        iVar17 = func_0x000180085d50(arg1, 1);
        if (iVar17 == 0) {
            piVar15 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar10 = piVar15;
            if (piVar1 <= piVar15) {
                piVar10 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar10 + 0xc) == 2)) {
                piVar10 = piVar15;
                if (piVar1 <= piVar15) {
                    piVar10 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) && (*(char *)(*piVar10 + 3) == 'x')) {
                    if (piVar1 <= piVar15) {
                        piVar15 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar15 + 0xc) == 9) && (*(char *)(*piVar15 + 3) == 'x')) {
                        puVar11 = (undefined4 *)(*piVar15 + 0x10);
                    } else {
                        puVar11 = (undefined4 *)0x0;
                    }
                    iVar17 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar11);
                    if (iVar17 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar5 = (code *)swi(3);
                        uVar12 = (*pcVar5)();
                        return uVar12;
                    }
                    goto code_r0x000180034e15;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar5 = (code *)swi(3);
            uVar12 = (*pcVar5)();
            return uVar12;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180034e15:
    piVar15 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar15 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    if (piVar15 == *(int64_t **)0x180782430) {
        piVar15 = (int64_t *)0x0;
    }
    if (*(char *)(*piVar15 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    iVar2 = *(int64_t *)(*piVar15 + 0x20);
    func_0x000180086fd0(arg1, *(undefined4 *)(iVar2 + 0xa8), 0);
    iVar17 = 0;
    if (0 < *(int32_t *)(iVar2 + 0xa8)) {
        do {
            puVar16 = (undefined8 *)((int64_t)iVar17 * 0x10 + *(int64_t *)(iVar2 + 0x38));
            if (*(int32_t *)((int64_t)puVar16 + 0xc) == 8) {
                func_0x000180087f70(arg1, 0, 0);
            } else {
                if ((5 < *(int32_t *)((int64_t)puVar16 + 0xc)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                **(undefined8 **)(arg1 + 0x40) = *puVar16;
                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)((int64_t)puVar16 + 0xc);
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar13 = *(int32_t *)(arg1 + 0x60) - (int32_t)arg1;
                    iVar14 = iVar13 + -0x60;
                    iVar6 = iVar14 * 2;
                    if (iVar14 < 1) {
                        iVar6 = iVar13 + -0x5f;
                    }
                    func_0x000180093240(arg1, iVar6, 0);
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            }
            iVar3 = *(int64_t *)(arg1 + 0x40);
            if (*(char *)(*(int64_t *)(iVar3 + -0x20) + 4) != '\0') {
                func_0x000180092f10(arg1);
                pcVar5 = (code *)swi(3);
                uVar12 = (*pcVar5)();
                return uVar12;
            }
            iVar17 = iVar17 + 1;
            puVar11 = (undefined4 *)func_0x0001800a1010();
            uVar7 = *(undefined4 *)(iVar3 + -0xc);
            uVar8 = *(undefined4 *)(iVar3 + -8);
            uVar9 = *(undefined4 *)(iVar3 + -4);
            *puVar11 = *(undefined4 *)(iVar3 + -0x10);
            puVar11[1] = uVar7;
            puVar11[2] = uVar8;
            puVar11[3] = uVar9;
            if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                iVar3 = *(int64_t *)(iVar3 + -0x20);
                if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                   ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                    iVar4 = *(int64_t *)(arg1 + 0x20);
                    if (*(char *)(iVar4 + 0x59) == '\x02') {
                        func_0x000180094420();
                    } else {
                        *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                        *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar4 + 0x18);
                        *(int64_t *)(iVar4 + 0x18) = iVar3;
                    }
                }
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        } while (iVar17 < *(int32_t *)(iVar2 + 0xa8));
    }
    return 1;
}

// ============================================================
// Function: FUN_180035076
// Address: 0x180035076
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h

undefined8 fcn.180034de0(int64_t arg1, int64_t arg_80h, int64_t arg_a8h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t *piVar10;
    undefined4 *puVar11;
    undefined8 uVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t *piVar15;
    undefined8 *puVar16;
    int32_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar15 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar15 = *(int64_t **)0x180782430;
    }
    if ((piVar15 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar15 + 0xc) != 8)) {
        iVar17 = func_0x000180085d50(arg1, 1);
        if (iVar17 == 0) {
            piVar15 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar10 = piVar15;
            if (piVar1 <= piVar15) {
                piVar10 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar10 + 0xc) == 2)) {
                piVar10 = piVar15;
                if (piVar1 <= piVar15) {
                    piVar10 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) && (*(char *)(*piVar10 + 3) == 'x')) {
                    if (piVar1 <= piVar15) {
                        piVar15 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar15 + 0xc) == 9) && (*(char *)(*piVar15 + 3) == 'x')) {
                        puVar11 = (undefined4 *)(*piVar15 + 0x10);
                    } else {
                        puVar11 = (undefined4 *)0x0;
                    }
                    iVar17 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar11);
                    if (iVar17 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar5 = (code *)swi(3);
                        uVar12 = (*pcVar5)();
                        return uVar12;
                    }
                    goto code_r0x000180034e15;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar5 = (code *)swi(3);
            uVar12 = (*pcVar5)();
            return uVar12;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180034e15:
    piVar15 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar15 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    if (piVar15 == *(int64_t **)0x180782430) {
        piVar15 = (int64_t *)0x0;
    }
    if (*(char *)(*piVar15 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    iVar2 = *(int64_t *)(*piVar15 + 0x20);
    func_0x000180086fd0(arg1, *(undefined4 *)(iVar2 + 0xa8), 0);
    iVar17 = 0;
    if (0 < *(int32_t *)(iVar2 + 0xa8)) {
        do {
            puVar16 = (undefined8 *)((int64_t)iVar17 * 0x10 + *(int64_t *)(iVar2 + 0x38));
            if (*(int32_t *)((int64_t)puVar16 + 0xc) == 8) {
                func_0x000180087f70(arg1, 0, 0);
            } else {
                if ((5 < *(int32_t *)((int64_t)puVar16 + 0xc)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                **(undefined8 **)(arg1 + 0x40) = *puVar16;
                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)((int64_t)puVar16 + 0xc);
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar13 = *(int32_t *)(arg1 + 0x60) - (int32_t)arg1;
                    iVar14 = iVar13 + -0x60;
                    iVar6 = iVar14 * 2;
                    if (iVar14 < 1) {
                        iVar6 = iVar13 + -0x5f;
                    }
                    func_0x000180093240(arg1, iVar6, 0);
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            }
            iVar3 = *(int64_t *)(arg1 + 0x40);
            if (*(char *)(*(int64_t *)(iVar3 + -0x20) + 4) != '\0') {
                func_0x000180092f10(arg1);
                pcVar5 = (code *)swi(3);
                uVar12 = (*pcVar5)();
                return uVar12;
            }
            iVar17 = iVar17 + 1;
            puVar11 = (undefined4 *)func_0x0001800a1010();
            uVar7 = *(undefined4 *)(iVar3 + -0xc);
            uVar8 = *(undefined4 *)(iVar3 + -8);
            uVar9 = *(undefined4 *)(iVar3 + -4);
            *puVar11 = *(undefined4 *)(iVar3 + -0x10);
            puVar11[1] = uVar7;
            puVar11[2] = uVar8;
            puVar11[3] = uVar9;
            if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                iVar3 = *(int64_t *)(iVar3 + -0x20);
                if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                   ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                    iVar4 = *(int64_t *)(arg1 + 0x20);
                    if (*(char *)(iVar4 + 0x59) == '\x02') {
                        func_0x000180094420();
                    } else {
                        *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                        *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar4 + 0x18);
                        *(int64_t *)(iVar4 + 0x18) = iVar3;
                    }
                }
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        } while (iVar17 < *(int32_t *)(iVar2 + 0xa8));
    }
    return 1;
}

// ============================================================
// Function: FUN_180035086
// Address: 0x180035086
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h

undefined8 fcn.180034de0(int64_t arg1, int64_t arg_80h, int64_t arg_a8h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t *piVar10;
    undefined4 *puVar11;
    undefined8 uVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t *piVar15;
    undefined8 *puVar16;
    int32_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar15 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar15 = *(int64_t **)0x180782430;
    }
    if ((piVar15 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar15 + 0xc) != 8)) {
        iVar17 = func_0x000180085d50(arg1, 1);
        if (iVar17 == 0) {
            piVar15 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar10 = piVar15;
            if (piVar1 <= piVar15) {
                piVar10 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar10 + 0xc) == 2)) {
                piVar10 = piVar15;
                if (piVar1 <= piVar15) {
                    piVar10 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) && (*(char *)(*piVar10 + 3) == 'x')) {
                    if (piVar1 <= piVar15) {
                        piVar15 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar15 + 0xc) == 9) && (*(char *)(*piVar15 + 3) == 'x')) {
                        puVar11 = (undefined4 *)(*piVar15 + 0x10);
                    } else {
                        puVar11 = (undefined4 *)0x0;
                    }
                    iVar17 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar11);
                    if (iVar17 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar5 = (code *)swi(3);
                        uVar12 = (*pcVar5)();
                        return uVar12;
                    }
                    goto code_r0x000180034e15;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar5 = (code *)swi(3);
            uVar12 = (*pcVar5)();
            return uVar12;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180034e15:
    piVar15 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar15 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    if (piVar15 == *(int64_t **)0x180782430) {
        piVar15 = (int64_t *)0x0;
    }
    if (*(char *)(*piVar15 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    iVar2 = *(int64_t *)(*piVar15 + 0x20);
    func_0x000180086fd0(arg1, *(undefined4 *)(iVar2 + 0xa8), 0);
    iVar17 = 0;
    if (0 < *(int32_t *)(iVar2 + 0xa8)) {
        do {
            puVar16 = (undefined8 *)((int64_t)iVar17 * 0x10 + *(int64_t *)(iVar2 + 0x38));
            if (*(int32_t *)((int64_t)puVar16 + 0xc) == 8) {
                func_0x000180087f70(arg1, 0, 0);
            } else {
                if ((5 < *(int32_t *)((int64_t)puVar16 + 0xc)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                **(undefined8 **)(arg1 + 0x40) = *puVar16;
                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)((int64_t)puVar16 + 0xc);
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar13 = *(int32_t *)(arg1 + 0x60) - (int32_t)arg1;
                    iVar14 = iVar13 + -0x60;
                    iVar6 = iVar14 * 2;
                    if (iVar14 < 1) {
                        iVar6 = iVar13 + -0x5f;
                    }
                    func_0x000180093240(arg1, iVar6, 0);
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            }
            iVar3 = *(int64_t *)(arg1 + 0x40);
            if (*(char *)(*(int64_t *)(iVar3 + -0x20) + 4) != '\0') {
                func_0x000180092f10(arg1);
                pcVar5 = (code *)swi(3);
                uVar12 = (*pcVar5)();
                return uVar12;
            }
            iVar17 = iVar17 + 1;
            puVar11 = (undefined4 *)func_0x0001800a1010();
            uVar7 = *(undefined4 *)(iVar3 + -0xc);
            uVar8 = *(undefined4 *)(iVar3 + -8);
            uVar9 = *(undefined4 *)(iVar3 + -4);
            *puVar11 = *(undefined4 *)(iVar3 + -0x10);
            puVar11[1] = uVar7;
            puVar11[2] = uVar8;
            puVar11[3] = uVar9;
            if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                iVar3 = *(int64_t *)(iVar3 + -0x20);
                if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                   ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                    iVar4 = *(int64_t *)(arg1 + 0x20);
                    if (*(char *)(iVar4 + 0x59) == '\x02') {
                        func_0x000180094420();
                    } else {
                        *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                        *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar4 + 0x18);
                        *(int64_t *)(iVar4 + 0x18) = iVar3;
                    }
                }
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        } while (iVar17 < *(int32_t *)(iVar2 + 0xa8));
    }
    return 1;
}

// ============================================================
// Function: FUN_18003508c
// Address: 0x18003508c
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h

undefined8 fcn.180034de0(int64_t arg1, int64_t arg_80h, int64_t arg_a8h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t *piVar10;
    undefined4 *puVar11;
    undefined8 uVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t *piVar15;
    undefined8 *puVar16;
    int32_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar15 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar15 = *(int64_t **)0x180782430;
    }
    if ((piVar15 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar15 + 0xc) != 8)) {
        iVar17 = func_0x000180085d50(arg1, 1);
        if (iVar17 == 0) {
            piVar15 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar10 = piVar15;
            if (piVar1 <= piVar15) {
                piVar10 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar10 + 0xc) == 2)) {
                piVar10 = piVar15;
                if (piVar1 <= piVar15) {
                    piVar10 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) && (*(char *)(*piVar10 + 3) == 'x')) {
                    if (piVar1 <= piVar15) {
                        piVar15 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar15 + 0xc) == 9) && (*(char *)(*piVar15 + 3) == 'x')) {
                        puVar11 = (undefined4 *)(*piVar15 + 0x10);
                    } else {
                        puVar11 = (undefined4 *)0x0;
                    }
                    iVar17 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar11);
                    if (iVar17 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar5 = (code *)swi(3);
                        uVar12 = (*pcVar5)();
                        return uVar12;
                    }
                    goto code_r0x000180034e15;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar5 = (code *)swi(3);
            uVar12 = (*pcVar5)();
            return uVar12;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180034e15:
    piVar15 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar15 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    if (piVar15 == *(int64_t **)0x180782430) {
        piVar15 = (int64_t *)0x0;
    }
    if (*(char *)(*piVar15 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    iVar2 = *(int64_t *)(*piVar15 + 0x20);
    func_0x000180086fd0(arg1, *(undefined4 *)(iVar2 + 0xa8), 0);
    iVar17 = 0;
    if (0 < *(int32_t *)(iVar2 + 0xa8)) {
        do {
            puVar16 = (undefined8 *)((int64_t)iVar17 * 0x10 + *(int64_t *)(iVar2 + 0x38));
            if (*(int32_t *)((int64_t)puVar16 + 0xc) == 8) {
                func_0x000180087f70(arg1, 0, 0);
            } else {
                if ((5 < *(int32_t *)((int64_t)puVar16 + 0xc)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                **(undefined8 **)(arg1 + 0x40) = *puVar16;
                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)((int64_t)puVar16 + 0xc);
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar13 = *(int32_t *)(arg1 + 0x60) - (int32_t)arg1;
                    iVar14 = iVar13 + -0x60;
                    iVar6 = iVar14 * 2;
                    if (iVar14 < 1) {
                        iVar6 = iVar13 + -0x5f;
                    }
                    func_0x000180093240(arg1, iVar6, 0);
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            }
            iVar3 = *(int64_t *)(arg1 + 0x40);
            if (*(char *)(*(int64_t *)(iVar3 + -0x20) + 4) != '\0') {
                func_0x000180092f10(arg1);
                pcVar5 = (code *)swi(3);
                uVar12 = (*pcVar5)();
                return uVar12;
            }
            iVar17 = iVar17 + 1;
            puVar11 = (undefined4 *)func_0x0001800a1010();
            uVar7 = *(undefined4 *)(iVar3 + -0xc);
            uVar8 = *(undefined4 *)(iVar3 + -8);
            uVar9 = *(undefined4 *)(iVar3 + -4);
            *puVar11 = *(undefined4 *)(iVar3 + -0x10);
            puVar11[1] = uVar7;
            puVar11[2] = uVar8;
            puVar11[3] = uVar9;
            if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                iVar3 = *(int64_t *)(iVar3 + -0x20);
                if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                   ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                    iVar4 = *(int64_t *)(arg1 + 0x20);
                    if (*(char *)(iVar4 + 0x59) == '\x02') {
                        func_0x000180094420();
                    } else {
                        *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                        *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar4 + 0x18);
                        *(int64_t *)(iVar4 + 0x18) = iVar3;
                    }
                }
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        } while (iVar17 < *(int32_t *)(iVar2 + 0xa8));
    }
    return 1;
}

// ============================================================
// Function: FUN_1800350b0
// Address: 0x1800350b0
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800350b0(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    int64_t var_8h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        iVar3 = func_0x000180085d50(arg1, 1);
        if (iVar3 == 0) {
            piVar7 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar4 = piVar7;
            if (piVar1 <= piVar7) {
                piVar4 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar4 + 0xc) == 2)) {
                piVar4 = piVar7;
                if (piVar1 <= piVar7) {
                    piVar4 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) && (*(char *)(*piVar4 + 3) == 'x')) {
                    if (piVar1 <= piVar7) {
                        piVar7 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar7 + 0xc) == 9) && (*(char *)(*piVar7 + 3) == 'x')) {
                        puVar9 = (undefined4 *)(*piVar7 + 0x10);
                    } else {
                        puVar9 = (undefined4 *)0x0;
                    }
                    iVar3 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar9);
                    if (iVar3 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar2 = (code *)swi(3);
                        uVar5 = (*pcVar2)();
                        return uVar5;
                    }
                    goto code_r0x0001800350e5;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x0001800350e5:
    piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    if (piVar7 == *(int64_t **)0x180782430) {
        piVar7 = (int64_t *)0x0;
    }
    iVar8 = *piVar7;
    if (*(char *)(iVar8 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar3 = fcn.180088860(arg1, 2);
    if (iVar3 < 1) {
        fcn.180088380(arg1, 1, 0x180622528);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar8 = *(int64_t *)(iVar8 + 0x20);
    if (*(int32_t *)(iVar8 + 0xa8) < iVar3) {
        fcn.180088380(arg1, 2, 0x1806225b0);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar8 = (int64_t)iVar3 * 0x10 + *(int64_t *)(iVar8 + 0x38);
    if (*(int32_t *)(iVar8 + -4) != 8) {
        if ((5 < *(int32_t *)(iVar8 + -4)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar8 + -0x10);
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)(iVar8 + -4);
        if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
            iVar6 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
            iVar3 = iVar6 * 2;
            if (iVar6 < 1) {
                iVar3 = iVar6 + 1;
            }
            func_0x000180093240(arg1, iVar3, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
    func_0x000180087f70(arg1, 0, 0);
    return 1;
}

// ============================================================
// Function: FUN_180035109
// Address: 0x180035109
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800350b0(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    int64_t var_8h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        iVar3 = func_0x000180085d50(arg1, 1);
        if (iVar3 == 0) {
            piVar7 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar4 = piVar7;
            if (piVar1 <= piVar7) {
                piVar4 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar4 + 0xc) == 2)) {
                piVar4 = piVar7;
                if (piVar1 <= piVar7) {
                    piVar4 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) && (*(char *)(*piVar4 + 3) == 'x')) {
                    if (piVar1 <= piVar7) {
                        piVar7 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar7 + 0xc) == 9) && (*(char *)(*piVar7 + 3) == 'x')) {
                        puVar9 = (undefined4 *)(*piVar7 + 0x10);
                    } else {
                        puVar9 = (undefined4 *)0x0;
                    }
                    iVar3 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar9);
                    if (iVar3 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar2 = (code *)swi(3);
                        uVar5 = (*pcVar2)();
                        return uVar5;
                    }
                    goto code_r0x0001800350e5;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x0001800350e5:
    piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    if (piVar7 == *(int64_t **)0x180782430) {
        piVar7 = (int64_t *)0x0;
    }
    iVar8 = *piVar7;
    if (*(char *)(iVar8 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar3 = fcn.180088860(arg1, 2);
    if (iVar3 < 1) {
        fcn.180088380(arg1, 1, 0x180622528);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar8 = *(int64_t *)(iVar8 + 0x20);
    if (*(int32_t *)(iVar8 + 0xa8) < iVar3) {
        fcn.180088380(arg1, 2, 0x1806225b0);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar8 = (int64_t)iVar3 * 0x10 + *(int64_t *)(iVar8 + 0x38);
    if (*(int32_t *)(iVar8 + -4) != 8) {
        if ((5 < *(int32_t *)(iVar8 + -4)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar8 + -0x10);
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)(iVar8 + -4);
        if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
            iVar6 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
            iVar3 = iVar6 * 2;
            if (iVar6 < 1) {
                iVar3 = iVar6 + 1;
            }
            func_0x000180093240(arg1, iVar3, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
    func_0x000180087f70(arg1, 0, 0);
    return 1;
}

// ============================================================
// Function: FUN_180035129
// Address: 0x180035129
// Size: 166 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800350b0(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    int64_t var_8h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        iVar3 = func_0x000180085d50(arg1, 1);
        if (iVar3 == 0) {
            piVar7 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar4 = piVar7;
            if (piVar1 <= piVar7) {
                piVar4 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar4 + 0xc) == 2)) {
                piVar4 = piVar7;
                if (piVar1 <= piVar7) {
                    piVar4 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) && (*(char *)(*piVar4 + 3) == 'x')) {
                    if (piVar1 <= piVar7) {
                        piVar7 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar7 + 0xc) == 9) && (*(char *)(*piVar7 + 3) == 'x')) {
                        puVar9 = (undefined4 *)(*piVar7 + 0x10);
                    } else {
                        puVar9 = (undefined4 *)0x0;
                    }
                    iVar3 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar9);
                    if (iVar3 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar2 = (code *)swi(3);
                        uVar5 = (*pcVar2)();
                        return uVar5;
                    }
                    goto code_r0x0001800350e5;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x0001800350e5:
    piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    if (piVar7 == *(int64_t **)0x180782430) {
        piVar7 = (int64_t *)0x0;
    }
    iVar8 = *piVar7;
    if (*(char *)(iVar8 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar3 = fcn.180088860(arg1, 2);
    if (iVar3 < 1) {
        fcn.180088380(arg1, 1, 0x180622528);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar8 = *(int64_t *)(iVar8 + 0x20);
    if (*(int32_t *)(iVar8 + 0xa8) < iVar3) {
        fcn.180088380(arg1, 2, 0x1806225b0);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar8 = (int64_t)iVar3 * 0x10 + *(int64_t *)(iVar8 + 0x38);
    if (*(int32_t *)(iVar8 + -4) != 8) {
        if ((5 < *(int32_t *)(iVar8 + -4)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar8 + -0x10);
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)(iVar8 + -4);
        if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
            iVar6 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
            iVar3 = iVar6 * 2;
            if (iVar6 < 1) {
                iVar3 = iVar6 + 1;
            }
            func_0x000180093240(arg1, iVar3, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
    func_0x000180087f70(arg1, 0, 0);
    return 1;
}

// ============================================================
// Function: FUN_1800351cf
// Address: 0x1800351cf
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800350b0(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    int64_t var_8h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        iVar3 = func_0x000180085d50(arg1, 1);
        if (iVar3 == 0) {
            piVar7 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar4 = piVar7;
            if (piVar1 <= piVar7) {
                piVar4 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar4 + 0xc) == 2)) {
                piVar4 = piVar7;
                if (piVar1 <= piVar7) {
                    piVar4 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) && (*(char *)(*piVar4 + 3) == 'x')) {
                    if (piVar1 <= piVar7) {
                        piVar7 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar7 + 0xc) == 9) && (*(char *)(*piVar7 + 3) == 'x')) {
                        puVar9 = (undefined4 *)(*piVar7 + 0x10);
                    } else {
                        puVar9 = (undefined4 *)0x0;
                    }
                    iVar3 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar9);
                    if (iVar3 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar2 = (code *)swi(3);
                        uVar5 = (*pcVar2)();
                        return uVar5;
                    }
                    goto code_r0x0001800350e5;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x0001800350e5:
    piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    if (piVar7 == *(int64_t **)0x180782430) {
        piVar7 = (int64_t *)0x0;
    }
    iVar8 = *piVar7;
    if (*(char *)(iVar8 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar3 = fcn.180088860(arg1, 2);
    if (iVar3 < 1) {
        fcn.180088380(arg1, 1, 0x180622528);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar8 = *(int64_t *)(iVar8 + 0x20);
    if (*(int32_t *)(iVar8 + 0xa8) < iVar3) {
        fcn.180088380(arg1, 2, 0x1806225b0);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar8 = (int64_t)iVar3 * 0x10 + *(int64_t *)(iVar8 + 0x38);
    if (*(int32_t *)(iVar8 + -4) != 8) {
        if ((5 < *(int32_t *)(iVar8 + -4)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar8 + -0x10);
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)(iVar8 + -4);
        if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
            iVar6 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
            iVar3 = iVar6 * 2;
            if (iVar6 < 1) {
                iVar3 = iVar6 + 1;
            }
            func_0x000180093240(arg1, iVar3, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
    func_0x000180087f70(arg1, 0, 0);
    return 1;
}

// ============================================================
// Function: FUN_180035222
// Address: 0x180035222
// Size: 122 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800350b0(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    int64_t var_8h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        iVar3 = func_0x000180085d50(arg1, 1);
        if (iVar3 == 0) {
            piVar7 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar4 = piVar7;
            if (piVar1 <= piVar7) {
                piVar4 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar4 + 0xc) == 2)) {
                piVar4 = piVar7;
                if (piVar1 <= piVar7) {
                    piVar4 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) && (*(char *)(*piVar4 + 3) == 'x')) {
                    if (piVar1 <= piVar7) {
                        piVar7 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar7 + 0xc) == 9) && (*(char *)(*piVar7 + 3) == 'x')) {
                        puVar9 = (undefined4 *)(*piVar7 + 0x10);
                    } else {
                        puVar9 = (undefined4 *)0x0;
                    }
                    iVar3 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar9);
                    if (iVar3 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar2 = (code *)swi(3);
                        uVar5 = (*pcVar2)();
                        return uVar5;
                    }
                    goto code_r0x0001800350e5;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x0001800350e5:
    piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    if (piVar7 == *(int64_t **)0x180782430) {
        piVar7 = (int64_t *)0x0;
    }
    iVar8 = *piVar7;
    if (*(char *)(iVar8 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar3 = fcn.180088860(arg1, 2);
    if (iVar3 < 1) {
        fcn.180088380(arg1, 1, 0x180622528);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar8 = *(int64_t *)(iVar8 + 0x20);
    if (*(int32_t *)(iVar8 + 0xa8) < iVar3) {
        fcn.180088380(arg1, 2, 0x1806225b0);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar8 = (int64_t)iVar3 * 0x10 + *(int64_t *)(iVar8 + 0x38);
    if (*(int32_t *)(iVar8 + -4) != 8) {
        if ((5 < *(int32_t *)(iVar8 + -4)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar8 + -0x10);
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)(iVar8 + -4);
        if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
            iVar6 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
            iVar3 = iVar6 * 2;
            if (iVar6 < 1) {
                iVar3 = iVar6 + 1;
            }
            func_0x000180093240(arg1, iVar3, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
    func_0x000180087f70(arg1, 0, 0);
    return 1;
}

// ============================================================
// Function: FUN_18003529c
// Address: 0x18003529c
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800350b0(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    int64_t var_8h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        iVar3 = func_0x000180085d50(arg1, 1);
        if (iVar3 == 0) {
            piVar7 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar4 = piVar7;
            if (piVar1 <= piVar7) {
                piVar4 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar4 + 0xc) == 2)) {
                piVar4 = piVar7;
                if (piVar1 <= piVar7) {
                    piVar4 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) && (*(char *)(*piVar4 + 3) == 'x')) {
                    if (piVar1 <= piVar7) {
                        piVar7 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar7 + 0xc) == 9) && (*(char *)(*piVar7 + 3) == 'x')) {
                        puVar9 = (undefined4 *)(*piVar7 + 0x10);
                    } else {
                        puVar9 = (undefined4 *)0x0;
                    }
                    iVar3 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar9);
                    if (iVar3 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar2 = (code *)swi(3);
                        uVar5 = (*pcVar2)();
                        return uVar5;
                    }
                    goto code_r0x0001800350e5;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x0001800350e5:
    piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    if (piVar7 == *(int64_t **)0x180782430) {
        piVar7 = (int64_t *)0x0;
    }
    iVar8 = *piVar7;
    if (*(char *)(iVar8 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar3 = fcn.180088860(arg1, 2);
    if (iVar3 < 1) {
        fcn.180088380(arg1, 1, 0x180622528);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar8 = *(int64_t *)(iVar8 + 0x20);
    if (*(int32_t *)(iVar8 + 0xa8) < iVar3) {
        fcn.180088380(arg1, 2, 0x1806225b0);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar8 = (int64_t)iVar3 * 0x10 + *(int64_t *)(iVar8 + 0x38);
    if (*(int32_t *)(iVar8 + -4) != 8) {
        if ((5 < *(int32_t *)(iVar8 + -4)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar8 + -0x10);
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)(iVar8 + -4);
        if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
            iVar6 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
            iVar3 = iVar6 * 2;
            if (iVar6 < 1) {
                iVar3 = iVar6 + 1;
            }
            func_0x000180093240(arg1, iVar3, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
    func_0x000180087f70(arg1, 0, 0);
    return 1;
}

// ============================================================
// Function: FUN_1800352b1
// Address: 0x1800352b1
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800350b0(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    int64_t var_8h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        iVar3 = func_0x000180085d50(arg1, 1);
        if (iVar3 == 0) {
            piVar7 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar4 = piVar7;
            if (piVar1 <= piVar7) {
                piVar4 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar4 + 0xc) == 2)) {
                piVar4 = piVar7;
                if (piVar1 <= piVar7) {
                    piVar4 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) && (*(char *)(*piVar4 + 3) == 'x')) {
                    if (piVar1 <= piVar7) {
                        piVar7 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar7 + 0xc) == 9) && (*(char *)(*piVar7 + 3) == 'x')) {
                        puVar9 = (undefined4 *)(*piVar7 + 0x10);
                    } else {
                        puVar9 = (undefined4 *)0x0;
                    }
                    iVar3 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar9);
                    if (iVar3 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar2 = (code *)swi(3);
                        uVar5 = (*pcVar2)();
                        return uVar5;
                    }
                    goto code_r0x0001800350e5;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x0001800350e5:
    piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    if (piVar7 == *(int64_t **)0x180782430) {
        piVar7 = (int64_t *)0x0;
    }
    iVar8 = *piVar7;
    if (*(char *)(iVar8 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar3 = fcn.180088860(arg1, 2);
    if (iVar3 < 1) {
        fcn.180088380(arg1, 1, 0x180622528);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar8 = *(int64_t *)(iVar8 + 0x20);
    if (*(int32_t *)(iVar8 + 0xa8) < iVar3) {
        fcn.180088380(arg1, 2, 0x1806225b0);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar8 = (int64_t)iVar3 * 0x10 + *(int64_t *)(iVar8 + 0x38);
    if (*(int32_t *)(iVar8 + -4) != 8) {
        if ((5 < *(int32_t *)(iVar8 + -4)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar8 + -0x10);
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)(iVar8 + -4);
        if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
            iVar6 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
            iVar3 = iVar6 * 2;
            if (iVar6 < 1) {
                iVar3 = iVar6 + 1;
            }
            func_0x000180093240(arg1, iVar3, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
    func_0x000180087f70(arg1, 0, 0);
    return 1;
}

// ============================================================
// Function: FUN_1800352c3
// Address: 0x1800352c3
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800350b0(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    int64_t var_8h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        iVar3 = func_0x000180085d50(arg1, 1);
        if (iVar3 == 0) {
            piVar7 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar4 = piVar7;
            if (piVar1 <= piVar7) {
                piVar4 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar4 + 0xc) == 2)) {
                piVar4 = piVar7;
                if (piVar1 <= piVar7) {
                    piVar4 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) && (*(char *)(*piVar4 + 3) == 'x')) {
                    if (piVar1 <= piVar7) {
                        piVar7 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar7 + 0xc) == 9) && (*(char *)(*piVar7 + 3) == 'x')) {
                        puVar9 = (undefined4 *)(*piVar7 + 0x10);
                    } else {
                        puVar9 = (undefined4 *)0x0;
                    }
                    iVar3 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar9);
                    if (iVar3 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar2 = (code *)swi(3);
                        uVar5 = (*pcVar2)();
                        return uVar5;
                    }
                    goto code_r0x0001800350e5;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x0001800350e5:
    piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    if (piVar7 == *(int64_t **)0x180782430) {
        piVar7 = (int64_t *)0x0;
    }
    iVar8 = *piVar7;
    if (*(char *)(iVar8 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar3 = fcn.180088860(arg1, 2);
    if (iVar3 < 1) {
        fcn.180088380(arg1, 1, 0x180622528);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar8 = *(int64_t *)(iVar8 + 0x20);
    if (*(int32_t *)(iVar8 + 0xa8) < iVar3) {
        fcn.180088380(arg1, 2, 0x1806225b0);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar8 = (int64_t)iVar3 * 0x10 + *(int64_t *)(iVar8 + 0x38);
    if (*(int32_t *)(iVar8 + -4) != 8) {
        if ((5 < *(int32_t *)(iVar8 + -4)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar8 + -0x10);
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)(iVar8 + -4);
        if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
            iVar6 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
            iVar3 = iVar6 * 2;
            if (iVar6 < 1) {
                iVar3 = iVar6 + 1;
            }
            func_0x000180093240(arg1, iVar3, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
    func_0x000180087f70(arg1, 0, 0);
    return 1;
}

// ============================================================
// Function: FUN_1800352d3
// Address: 0x1800352d3
// Size: 42 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800350b0(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    int64_t var_8h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        iVar3 = func_0x000180085d50(arg1, 1);
        if (iVar3 == 0) {
            piVar7 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar4 = piVar7;
            if (piVar1 <= piVar7) {
                piVar4 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar4 + 0xc) == 2)) {
                piVar4 = piVar7;
                if (piVar1 <= piVar7) {
                    piVar4 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) && (*(char *)(*piVar4 + 3) == 'x')) {
                    if (piVar1 <= piVar7) {
                        piVar7 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar7 + 0xc) == 9) && (*(char *)(*piVar7 + 3) == 'x')) {
                        puVar9 = (undefined4 *)(*piVar7 + 0x10);
                    } else {
                        puVar9 = (undefined4 *)0x0;
                    }
                    iVar3 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar9);
                    if (iVar3 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar2 = (code *)swi(3);
                        uVar5 = (*pcVar2)();
                        return uVar5;
                    }
                    goto code_r0x0001800350e5;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x0001800350e5:
    piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    if (piVar7 == *(int64_t **)0x180782430) {
        piVar7 = (int64_t *)0x0;
    }
    iVar8 = *piVar7;
    if (*(char *)(iVar8 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar3 = fcn.180088860(arg1, 2);
    if (iVar3 < 1) {
        fcn.180088380(arg1, 1, 0x180622528);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar8 = *(int64_t *)(iVar8 + 0x20);
    if (*(int32_t *)(iVar8 + 0xa8) < iVar3) {
        fcn.180088380(arg1, 2, 0x1806225b0);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar8 = (int64_t)iVar3 * 0x10 + *(int64_t *)(iVar8 + 0x38);
    if (*(int32_t *)(iVar8 + -4) != 8) {
        if ((5 < *(int32_t *)(iVar8 + -4)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar8 + -0x10);
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)(iVar8 + -4);
        if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
            iVar6 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
            iVar3 = iVar6 * 2;
            if (iVar6 < 1) {
                iVar3 = iVar6 + 1;
            }
            func_0x000180093240(arg1, iVar3, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
    func_0x000180087f70(arg1, 0, 0);
    return 1;
}

// ============================================================
// Function: FUN_1800352fd
// Address: 0x1800352fd
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800350b0(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    int64_t var_8h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        iVar3 = func_0x000180085d50(arg1, 1);
        if (iVar3 == 0) {
            piVar7 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar4 = piVar7;
            if (piVar1 <= piVar7) {
                piVar4 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar4 + 0xc) == 2)) {
                piVar4 = piVar7;
                if (piVar1 <= piVar7) {
                    piVar4 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) && (*(char *)(*piVar4 + 3) == 'x')) {
                    if (piVar1 <= piVar7) {
                        piVar7 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar7 + 0xc) == 9) && (*(char *)(*piVar7 + 3) == 'x')) {
                        puVar9 = (undefined4 *)(*piVar7 + 0x10);
                    } else {
                        puVar9 = (undefined4 *)0x0;
                    }
                    iVar3 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar9);
                    if (iVar3 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar2 = (code *)swi(3);
                        uVar5 = (*pcVar2)();
                        return uVar5;
                    }
                    goto code_r0x0001800350e5;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x0001800350e5:
    piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    if (piVar7 == *(int64_t **)0x180782430) {
        piVar7 = (int64_t *)0x0;
    }
    iVar8 = *piVar7;
    if (*(char *)(iVar8 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar3 = fcn.180088860(arg1, 2);
    if (iVar3 < 1) {
        fcn.180088380(arg1, 1, 0x180622528);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar8 = *(int64_t *)(iVar8 + 0x20);
    if (*(int32_t *)(iVar8 + 0xa8) < iVar3) {
        fcn.180088380(arg1, 2, 0x1806225b0);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar8 = (int64_t)iVar3 * 0x10 + *(int64_t *)(iVar8 + 0x38);
    if (*(int32_t *)(iVar8 + -4) != 8) {
        if ((5 < *(int32_t *)(iVar8 + -4)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar8 + -0x10);
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)(iVar8 + -4);
        if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
            iVar6 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
            iVar3 = iVar6 * 2;
            if (iVar6 < 1) {
                iVar3 = iVar6 + 1;
            }
            func_0x000180093240(arg1, iVar3, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
    func_0x000180087f70(arg1, 0, 0);
    return 1;
}

// ============================================================
// Function: FUN_180035320
// Address: 0x180035320
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180035320(int64_t arg1, int64_t arg_38h)
{
    uint8_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t *piVar8;
    undefined8 uVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint8_t uVar12;
    undefined4 *puVar13;
    int64_t iVar14;
    int64_t var_8h;
    
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
        iVar7 = func_0x000180085d50(arg1, 1);
        if (iVar7 == 0) {
            piVar10 = *(int64_t **)(arg1 + 0x28);
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar8 = piVar10;
            if (piVar11 <= piVar10) {
                piVar8 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar8 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar8 + 0xc) == 2)) {
                piVar8 = piVar10;
                if (piVar11 <= piVar10) {
                    piVar8 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar8 + 0xc) == 9) && (*(char *)(*piVar8 + 3) == 'x')) {
                    if (piVar11 <= piVar10) {
                        piVar10 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) && (*(char *)(*piVar10 + 3) == 'x')) {
                        puVar13 = (undefined4 *)(*piVar10 + 0x10);
                    } else {
                        puVar13 = (undefined4 *)0x0;
                    }
                    iVar7 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar13);
                    if (iVar7 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar3 = (code *)swi(3);
                        uVar9 = (*pcVar3)();
                        return uVar9;
                    }
                    goto code_r0x000180035355;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180035355:
    piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    if (piVar10 == *(int64_t **)0x180782430) {
        piVar10 = (int64_t *)0x0;
    }
    iVar2 = *piVar10;
    if (*(char *)(iVar2 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    iVar7 = fcn.180088860(arg1, 2);
    if (iVar7 < 1) {
        fcn.180088380(arg1, 1, 0x180622528);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    if (*(int32_t *)(*(int64_t *)(iVar2 + 0x20) + 0xa8) < iVar7) {
        fcn.180088380(arg1, 2, 0x1806225b0);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    piVar10 = piVar11;
    if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar10 + 0xc) != -1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (piVar11 == *(int64_t **)0x180782430) {
            piVar11 = (int64_t *)0x0;
        }
        iVar14 = (int64_t)iVar7 * 0x10 + *(int64_t *)(*(int64_t *)(iVar2 + 0x20) + 0x38);
        if (*(int32_t *)(iVar14 + -4) != *(int32_t *)((int64_t)piVar11 + 0xc)) {
            fcn.180088380(arg1, 3, 0x1806225c8);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        if (*(int32_t *)(iVar14 + -4) == 8) {
            fcn.180088380(arg1, 3, 0x180622610);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        uVar4 = *(undefined4 *)((int64_t)piVar11 + 4);
        uVar5 = *(undefined4 *)(piVar11 + 1);
        uVar6 = *(undefined4 *)((int64_t)piVar11 + 0xc);
        *(undefined4 *)(iVar14 + -0x10) = *(undefined4 *)piVar11;
        *(undefined4 *)(iVar14 + -0xc) = uVar4;
        *(undefined4 *)(iVar14 + -8) = uVar5;
        *(undefined4 *)(iVar14 + -4) = uVar6;
        if (5 < *(int32_t *)((int64_t)piVar11 + 0xc)) {
            iVar14 = *(int64_t *)(arg1 + 0x20);
            uVar1 = *(uint8_t *)(*(int64_t *)(iVar2 + 0x20) + 1);
            uVar12 = ~*(uint8_t *)(iVar14 + 0x58) & 3;
            if (((((uVar1 & 0xb) != uVar12) && ((*(uint8_t *)((int64_t)piVar11 + 1) & 0xb) != uVar12)) &&
                ((uVar1 & 4) != 0)) && ((*(uint8_t *)((int64_t)piVar11 + 1) & 3) != 0)) {
                if (2 < (uint8_t)(*(char *)(iVar14 + 0x59) - 1U)) {
                    *(uint8_t *)(*(int64_t *)(iVar2 + 0x20) + 1) = uVar1 & 0xf8 | *(uint8_t *)(iVar14 + 0x58) & 3;
                    return 1;
                }
                func_0x000180094420(iVar14);
            }
        }
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 3);
    pcVar3 = (code *)swi(3);
    uVar9 = (*pcVar3)();
    return uVar9;
}

// ============================================================
// Function: FUN_180035379
// Address: 0x180035379
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180035320(int64_t arg1, int64_t arg_38h)
{
    uint8_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t *piVar8;
    undefined8 uVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint8_t uVar12;
    undefined4 *puVar13;
    int64_t iVar14;
    int64_t var_8h;
    
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
        iVar7 = func_0x000180085d50(arg1, 1);
        if (iVar7 == 0) {
            piVar10 = *(int64_t **)(arg1 + 0x28);
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar8 = piVar10;
            if (piVar11 <= piVar10) {
                piVar8 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar8 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar8 + 0xc) == 2)) {
                piVar8 = piVar10;
                if (piVar11 <= piVar10) {
                    piVar8 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar8 + 0xc) == 9) && (*(char *)(*piVar8 + 3) == 'x')) {
                    if (piVar11 <= piVar10) {
                        piVar10 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) && (*(char *)(*piVar10 + 3) == 'x')) {
                        puVar13 = (undefined4 *)(*piVar10 + 0x10);
                    } else {
                        puVar13 = (undefined4 *)0x0;
                    }
                    iVar7 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar13);
                    if (iVar7 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar3 = (code *)swi(3);
                        uVar9 = (*pcVar3)();
                        return uVar9;
                    }
                    goto code_r0x000180035355;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180035355:
    piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    if (piVar10 == *(int64_t **)0x180782430) {
        piVar10 = (int64_t *)0x0;
    }
    iVar2 = *piVar10;
    if (*(char *)(iVar2 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    iVar7 = fcn.180088860(arg1, 2);
    if (iVar7 < 1) {
        fcn.180088380(arg1, 1, 0x180622528);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    if (*(int32_t *)(*(int64_t *)(iVar2 + 0x20) + 0xa8) < iVar7) {
        fcn.180088380(arg1, 2, 0x1806225b0);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    piVar10 = piVar11;
    if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar10 + 0xc) != -1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (piVar11 == *(int64_t **)0x180782430) {
            piVar11 = (int64_t *)0x0;
        }
        iVar14 = (int64_t)iVar7 * 0x10 + *(int64_t *)(*(int64_t *)(iVar2 + 0x20) + 0x38);
        if (*(int32_t *)(iVar14 + -4) != *(int32_t *)((int64_t)piVar11 + 0xc)) {
            fcn.180088380(arg1, 3, 0x1806225c8);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        if (*(int32_t *)(iVar14 + -4) == 8) {
            fcn.180088380(arg1, 3, 0x180622610);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        uVar4 = *(undefined4 *)((int64_t)piVar11 + 4);
        uVar5 = *(undefined4 *)(piVar11 + 1);
        uVar6 = *(undefined4 *)((int64_t)piVar11 + 0xc);
        *(undefined4 *)(iVar14 + -0x10) = *(undefined4 *)piVar11;
        *(undefined4 *)(iVar14 + -0xc) = uVar4;
        *(undefined4 *)(iVar14 + -8) = uVar5;
        *(undefined4 *)(iVar14 + -4) = uVar6;
        if (5 < *(int32_t *)((int64_t)piVar11 + 0xc)) {
            iVar14 = *(int64_t *)(arg1 + 0x20);
            uVar1 = *(uint8_t *)(*(int64_t *)(iVar2 + 0x20) + 1);
            uVar12 = ~*(uint8_t *)(iVar14 + 0x58) & 3;
            if (((((uVar1 & 0xb) != uVar12) && ((*(uint8_t *)((int64_t)piVar11 + 1) & 0xb) != uVar12)) &&
                ((uVar1 & 4) != 0)) && ((*(uint8_t *)((int64_t)piVar11 + 1) & 3) != 0)) {
                if (2 < (uint8_t)(*(char *)(iVar14 + 0x59) - 1U)) {
                    *(uint8_t *)(*(int64_t *)(iVar2 + 0x20) + 1) = uVar1 & 0xf8 | *(uint8_t *)(iVar14 + 0x58) & 3;
                    return 1;
                }
                func_0x000180094420(iVar14);
            }
        }
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 3);
    pcVar3 = (code *)swi(3);
    uVar9 = (*pcVar3)();
    return uVar9;
}

// ============================================================
// Function: FUN_180035399
// Address: 0x180035399
// Size: 166 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180035320(int64_t arg1, int64_t arg_38h)
{
    uint8_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t *piVar8;
    undefined8 uVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint8_t uVar12;
    undefined4 *puVar13;
    int64_t iVar14;
    int64_t var_8h;
    
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
        iVar7 = func_0x000180085d50(arg1, 1);
        if (iVar7 == 0) {
            piVar10 = *(int64_t **)(arg1 + 0x28);
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar8 = piVar10;
            if (piVar11 <= piVar10) {
                piVar8 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar8 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar8 + 0xc) == 2)) {
                piVar8 = piVar10;
                if (piVar11 <= piVar10) {
                    piVar8 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar8 + 0xc) == 9) && (*(char *)(*piVar8 + 3) == 'x')) {
                    if (piVar11 <= piVar10) {
                        piVar10 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) && (*(char *)(*piVar10 + 3) == 'x')) {
                        puVar13 = (undefined4 *)(*piVar10 + 0x10);
                    } else {
                        puVar13 = (undefined4 *)0x0;
                    }
                    iVar7 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar13);
                    if (iVar7 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar3 = (code *)swi(3);
                        uVar9 = (*pcVar3)();
                        return uVar9;
                    }
                    goto code_r0x000180035355;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180035355:
    piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    if (piVar10 == *(int64_t **)0x180782430) {
        piVar10 = (int64_t *)0x0;
    }
    iVar2 = *piVar10;
    if (*(char *)(iVar2 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    iVar7 = fcn.180088860(arg1, 2);
    if (iVar7 < 1) {
        fcn.180088380(arg1, 1, 0x180622528);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    if (*(int32_t *)(*(int64_t *)(iVar2 + 0x20) + 0xa8) < iVar7) {
        fcn.180088380(arg1, 2, 0x1806225b0);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    piVar10 = piVar11;
    if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar10 + 0xc) != -1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (piVar11 == *(int64_t **)0x180782430) {
            piVar11 = (int64_t *)0x0;
        }
        iVar14 = (int64_t)iVar7 * 0x10 + *(int64_t *)(*(int64_t *)(iVar2 + 0x20) + 0x38);
        if (*(int32_t *)(iVar14 + -4) != *(int32_t *)((int64_t)piVar11 + 0xc)) {
            fcn.180088380(arg1, 3, 0x1806225c8);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        if (*(int32_t *)(iVar14 + -4) == 8) {
            fcn.180088380(arg1, 3, 0x180622610);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        uVar4 = *(undefined4 *)((int64_t)piVar11 + 4);
        uVar5 = *(undefined4 *)(piVar11 + 1);
        uVar6 = *(undefined4 *)((int64_t)piVar11 + 0xc);
        *(undefined4 *)(iVar14 + -0x10) = *(undefined4 *)piVar11;
        *(undefined4 *)(iVar14 + -0xc) = uVar4;
        *(undefined4 *)(iVar14 + -8) = uVar5;
        *(undefined4 *)(iVar14 + -4) = uVar6;
        if (5 < *(int32_t *)((int64_t)piVar11 + 0xc)) {
            iVar14 = *(int64_t *)(arg1 + 0x20);
            uVar1 = *(uint8_t *)(*(int64_t *)(iVar2 + 0x20) + 1);
            uVar12 = ~*(uint8_t *)(iVar14 + 0x58) & 3;
            if (((((uVar1 & 0xb) != uVar12) && ((*(uint8_t *)((int64_t)piVar11 + 1) & 0xb) != uVar12)) &&
                ((uVar1 & 4) != 0)) && ((*(uint8_t *)((int64_t)piVar11 + 1) & 3) != 0)) {
                if (2 < (uint8_t)(*(char *)(iVar14 + 0x59) - 1U)) {
                    *(uint8_t *)(*(int64_t *)(iVar2 + 0x20) + 1) = uVar1 & 0xf8 | *(uint8_t *)(iVar14 + 0x58) & 3;
                    return 1;
                }
                func_0x000180094420(iVar14);
            }
        }
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 3);
    pcVar3 = (code *)swi(3);
    uVar9 = (*pcVar3)();
    return uVar9;
}

// ============================================================
// Function: FUN_18003543f
// Address: 0x18003543f
// Size: 253 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180035320(int64_t arg1, int64_t arg_38h)
{
    uint8_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t *piVar8;
    undefined8 uVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint8_t uVar12;
    undefined4 *puVar13;
    int64_t iVar14;
    int64_t var_8h;
    
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
        iVar7 = func_0x000180085d50(arg1, 1);
        if (iVar7 == 0) {
            piVar10 = *(int64_t **)(arg1 + 0x28);
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar8 = piVar10;
            if (piVar11 <= piVar10) {
                piVar8 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar8 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar8 + 0xc) == 2)) {
                piVar8 = piVar10;
                if (piVar11 <= piVar10) {
                    piVar8 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar8 + 0xc) == 9) && (*(char *)(*piVar8 + 3) == 'x')) {
                    if (piVar11 <= piVar10) {
                        piVar10 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) && (*(char *)(*piVar10 + 3) == 'x')) {
                        puVar13 = (undefined4 *)(*piVar10 + 0x10);
                    } else {
                        puVar13 = (undefined4 *)0x0;
                    }
                    iVar7 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar13);
                    if (iVar7 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar3 = (code *)swi(3);
                        uVar9 = (*pcVar3)();
                        return uVar9;
                    }
                    goto code_r0x000180035355;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180035355:
    piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    if (piVar10 == *(int64_t **)0x180782430) {
        piVar10 = (int64_t *)0x0;
    }
    iVar2 = *piVar10;
    if (*(char *)(iVar2 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    iVar7 = fcn.180088860(arg1, 2);
    if (iVar7 < 1) {
        fcn.180088380(arg1, 1, 0x180622528);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    if (*(int32_t *)(*(int64_t *)(iVar2 + 0x20) + 0xa8) < iVar7) {
        fcn.180088380(arg1, 2, 0x1806225b0);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    piVar10 = piVar11;
    if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar10 + 0xc) != -1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (piVar11 == *(int64_t **)0x180782430) {
            piVar11 = (int64_t *)0x0;
        }
        iVar14 = (int64_t)iVar7 * 0x10 + *(int64_t *)(*(int64_t *)(iVar2 + 0x20) + 0x38);
        if (*(int32_t *)(iVar14 + -4) != *(int32_t *)((int64_t)piVar11 + 0xc)) {
            fcn.180088380(arg1, 3, 0x1806225c8);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        if (*(int32_t *)(iVar14 + -4) == 8) {
            fcn.180088380(arg1, 3, 0x180622610);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        uVar4 = *(undefined4 *)((int64_t)piVar11 + 4);
        uVar5 = *(undefined4 *)(piVar11 + 1);
        uVar6 = *(undefined4 *)((int64_t)piVar11 + 0xc);
        *(undefined4 *)(iVar14 + -0x10) = *(undefined4 *)piVar11;
        *(undefined4 *)(iVar14 + -0xc) = uVar4;
        *(undefined4 *)(iVar14 + -8) = uVar5;
        *(undefined4 *)(iVar14 + -4) = uVar6;
        if (5 < *(int32_t *)((int64_t)piVar11 + 0xc)) {
            iVar14 = *(int64_t *)(arg1 + 0x20);
            uVar1 = *(uint8_t *)(*(int64_t *)(iVar2 + 0x20) + 1);
            uVar12 = ~*(uint8_t *)(iVar14 + 0x58) & 3;
            if (((((uVar1 & 0xb) != uVar12) && ((*(uint8_t *)((int64_t)piVar11 + 1) & 0xb) != uVar12)) &&
                ((uVar1 & 4) != 0)) && ((*(uint8_t *)((int64_t)piVar11 + 1) & 3) != 0)) {
                if (2 < (uint8_t)(*(char *)(iVar14 + 0x59) - 1U)) {
                    *(uint8_t *)(*(int64_t *)(iVar2 + 0x20) + 1) = uVar1 & 0xf8 | *(uint8_t *)(iVar14 + 0x58) & 3;
                    return 1;
                }
                func_0x000180094420(iVar14);
            }
        }
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 3);
    pcVar3 = (code *)swi(3);
    uVar9 = (*pcVar3)();
    return uVar9;
}

// ============================================================
// Function: FUN_18003553c
// Address: 0x18003553c
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180035320(int64_t arg1, int64_t arg_38h)
{
    uint8_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t *piVar8;
    undefined8 uVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint8_t uVar12;
    undefined4 *puVar13;
    int64_t iVar14;
    int64_t var_8h;
    
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
        iVar7 = func_0x000180085d50(arg1, 1);
        if (iVar7 == 0) {
            piVar10 = *(int64_t **)(arg1 + 0x28);
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar8 = piVar10;
            if (piVar11 <= piVar10) {
                piVar8 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar8 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar8 + 0xc) == 2)) {
                piVar8 = piVar10;
                if (piVar11 <= piVar10) {
                    piVar8 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar8 + 0xc) == 9) && (*(char *)(*piVar8 + 3) == 'x')) {
                    if (piVar11 <= piVar10) {
                        piVar10 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) && (*(char *)(*piVar10 + 3) == 'x')) {
                        puVar13 = (undefined4 *)(*piVar10 + 0x10);
                    } else {
                        puVar13 = (undefined4 *)0x0;
                    }
                    iVar7 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar13);
                    if (iVar7 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar3 = (code *)swi(3);
                        uVar9 = (*pcVar3)();
                        return uVar9;
                    }
                    goto code_r0x000180035355;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180035355:
    piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    if (piVar10 == *(int64_t **)0x180782430) {
        piVar10 = (int64_t *)0x0;
    }
    iVar2 = *piVar10;
    if (*(char *)(iVar2 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    iVar7 = fcn.180088860(arg1, 2);
    if (iVar7 < 1) {
        fcn.180088380(arg1, 1, 0x180622528);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    if (*(int32_t *)(*(int64_t *)(iVar2 + 0x20) + 0xa8) < iVar7) {
        fcn.180088380(arg1, 2, 0x1806225b0);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    piVar10 = piVar11;
    if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar10 + 0xc) != -1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (piVar11 == *(int64_t **)0x180782430) {
            piVar11 = (int64_t *)0x0;
        }
        iVar14 = (int64_t)iVar7 * 0x10 + *(int64_t *)(*(int64_t *)(iVar2 + 0x20) + 0x38);
        if (*(int32_t *)(iVar14 + -4) != *(int32_t *)((int64_t)piVar11 + 0xc)) {
            fcn.180088380(arg1, 3, 0x1806225c8);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        if (*(int32_t *)(iVar14 + -4) == 8) {
            fcn.180088380(arg1, 3, 0x180622610);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        uVar4 = *(undefined4 *)((int64_t)piVar11 + 4);
        uVar5 = *(undefined4 *)(piVar11 + 1);
        uVar6 = *(undefined4 *)((int64_t)piVar11 + 0xc);
        *(undefined4 *)(iVar14 + -0x10) = *(undefined4 *)piVar11;
        *(undefined4 *)(iVar14 + -0xc) = uVar4;
        *(undefined4 *)(iVar14 + -8) = uVar5;
        *(undefined4 *)(iVar14 + -4) = uVar6;
        if (5 < *(int32_t *)((int64_t)piVar11 + 0xc)) {
            iVar14 = *(int64_t *)(arg1 + 0x20);
            uVar1 = *(uint8_t *)(*(int64_t *)(iVar2 + 0x20) + 1);
            uVar12 = ~*(uint8_t *)(iVar14 + 0x58) & 3;
            if (((((uVar1 & 0xb) != uVar12) && ((*(uint8_t *)((int64_t)piVar11 + 1) & 0xb) != uVar12)) &&
                ((uVar1 & 4) != 0)) && ((*(uint8_t *)((int64_t)piVar11 + 1) & 3) != 0)) {
                if (2 < (uint8_t)(*(char *)(iVar14 + 0x59) - 1U)) {
                    *(uint8_t *)(*(int64_t *)(iVar2 + 0x20) + 1) = uVar1 & 0xf8 | *(uint8_t *)(iVar14 + 0x58) & 3;
                    return 1;
                }
                func_0x000180094420(iVar14);
            }
        }
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 3);
    pcVar3 = (code *)swi(3);
    uVar9 = (*pcVar3)();
    return uVar9;
}

// ============================================================
// Function: FUN_180035554
// Address: 0x180035554
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180035320(int64_t arg1, int64_t arg_38h)
{
    uint8_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t *piVar8;
    undefined8 uVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint8_t uVar12;
    undefined4 *puVar13;
    int64_t iVar14;
    int64_t var_8h;
    
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
        iVar7 = func_0x000180085d50(arg1, 1);
        if (iVar7 == 0) {
            piVar10 = *(int64_t **)(arg1 + 0x28);
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar8 = piVar10;
            if (piVar11 <= piVar10) {
                piVar8 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar8 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar8 + 0xc) == 2)) {
                piVar8 = piVar10;
                if (piVar11 <= piVar10) {
                    piVar8 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar8 + 0xc) == 9) && (*(char *)(*piVar8 + 3) == 'x')) {
                    if (piVar11 <= piVar10) {
                        piVar10 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) && (*(char *)(*piVar10 + 3) == 'x')) {
                        puVar13 = (undefined4 *)(*piVar10 + 0x10);
                    } else {
                        puVar13 = (undefined4 *)0x0;
                    }
                    iVar7 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar13);
                    if (iVar7 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar3 = (code *)swi(3);
                        uVar9 = (*pcVar3)();
                        return uVar9;
                    }
                    goto code_r0x000180035355;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180035355:
    piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    if (piVar10 == *(int64_t **)0x180782430) {
        piVar10 = (int64_t *)0x0;
    }
    iVar2 = *piVar10;
    if (*(char *)(iVar2 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    iVar7 = fcn.180088860(arg1, 2);
    if (iVar7 < 1) {
        fcn.180088380(arg1, 1, 0x180622528);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    if (*(int32_t *)(*(int64_t *)(iVar2 + 0x20) + 0xa8) < iVar7) {
        fcn.180088380(arg1, 2, 0x1806225b0);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    piVar10 = piVar11;
    if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar10 + 0xc) != -1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (piVar11 == *(int64_t **)0x180782430) {
            piVar11 = (int64_t *)0x0;
        }
        iVar14 = (int64_t)iVar7 * 0x10 + *(int64_t *)(*(int64_t *)(iVar2 + 0x20) + 0x38);
        if (*(int32_t *)(iVar14 + -4) != *(int32_t *)((int64_t)piVar11 + 0xc)) {
            fcn.180088380(arg1, 3, 0x1806225c8);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        if (*(int32_t *)(iVar14 + -4) == 8) {
            fcn.180088380(arg1, 3, 0x180622610);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        uVar4 = *(undefined4 *)((int64_t)piVar11 + 4);
        uVar5 = *(undefined4 *)(piVar11 + 1);
        uVar6 = *(undefined4 *)((int64_t)piVar11 + 0xc);
        *(undefined4 *)(iVar14 + -0x10) = *(undefined4 *)piVar11;
        *(undefined4 *)(iVar14 + -0xc) = uVar4;
        *(undefined4 *)(iVar14 + -8) = uVar5;
        *(undefined4 *)(iVar14 + -4) = uVar6;
        if (5 < *(int32_t *)((int64_t)piVar11 + 0xc)) {
            iVar14 = *(int64_t *)(arg1 + 0x20);
            uVar1 = *(uint8_t *)(*(int64_t *)(iVar2 + 0x20) + 1);
            uVar12 = ~*(uint8_t *)(iVar14 + 0x58) & 3;
            if (((((uVar1 & 0xb) != uVar12) && ((*(uint8_t *)((int64_t)piVar11 + 1) & 0xb) != uVar12)) &&
                ((uVar1 & 4) != 0)) && ((*(uint8_t *)((int64_t)piVar11 + 1) & 3) != 0)) {
                if (2 < (uint8_t)(*(char *)(iVar14 + 0x59) - 1U)) {
                    *(uint8_t *)(*(int64_t *)(iVar2 + 0x20) + 1) = uVar1 & 0xf8 | *(uint8_t *)(iVar14 + 0x58) & 3;
                    return 1;
                }
                func_0x000180094420(iVar14);
            }
        }
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 3);
    pcVar3 = (code *)swi(3);
    uVar9 = (*pcVar3)();
    return uVar9;
}

// ============================================================
// Function: FUN_180035569
// Address: 0x180035569
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180035320(int64_t arg1, int64_t arg_38h)
{
    uint8_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t *piVar8;
    undefined8 uVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint8_t uVar12;
    undefined4 *puVar13;
    int64_t iVar14;
    int64_t var_8h;
    
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
        iVar7 = func_0x000180085d50(arg1, 1);
        if (iVar7 == 0) {
            piVar10 = *(int64_t **)(arg1 + 0x28);
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar8 = piVar10;
            if (piVar11 <= piVar10) {
                piVar8 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar8 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar8 + 0xc) == 2)) {
                piVar8 = piVar10;
                if (piVar11 <= piVar10) {
                    piVar8 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar8 + 0xc) == 9) && (*(char *)(*piVar8 + 3) == 'x')) {
                    if (piVar11 <= piVar10) {
                        piVar10 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) && (*(char *)(*piVar10 + 3) == 'x')) {
                        puVar13 = (undefined4 *)(*piVar10 + 0x10);
                    } else {
                        puVar13 = (undefined4 *)0x0;
                    }
                    iVar7 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar13);
                    if (iVar7 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar3 = (code *)swi(3);
                        uVar9 = (*pcVar3)();
                        return uVar9;
                    }
                    goto code_r0x000180035355;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180035355:
    piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    if (piVar10 == *(int64_t **)0x180782430) {
        piVar10 = (int64_t *)0x0;
    }
    iVar2 = *piVar10;
    if (*(char *)(iVar2 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    iVar7 = fcn.180088860(arg1, 2);
    if (iVar7 < 1) {
        fcn.180088380(arg1, 1, 0x180622528);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    if (*(int32_t *)(*(int64_t *)(iVar2 + 0x20) + 0xa8) < iVar7) {
        fcn.180088380(arg1, 2, 0x1806225b0);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    piVar10 = piVar11;
    if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar10 + 0xc) != -1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (piVar11 == *(int64_t **)0x180782430) {
            piVar11 = (int64_t *)0x0;
        }
        iVar14 = (int64_t)iVar7 * 0x10 + *(int64_t *)(*(int64_t *)(iVar2 + 0x20) + 0x38);
        if (*(int32_t *)(iVar14 + -4) != *(int32_t *)((int64_t)piVar11 + 0xc)) {
            fcn.180088380(arg1, 3, 0x1806225c8);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        if (*(int32_t *)(iVar14 + -4) == 8) {
            fcn.180088380(arg1, 3, 0x180622610);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        uVar4 = *(undefined4 *)((int64_t)piVar11 + 4);
        uVar5 = *(undefined4 *)(piVar11 + 1);
        uVar6 = *(undefined4 *)((int64_t)piVar11 + 0xc);
        *(undefined4 *)(iVar14 + -0x10) = *(undefined4 *)piVar11;
        *(undefined4 *)(iVar14 + -0xc) = uVar4;
        *(undefined4 *)(iVar14 + -8) = uVar5;
        *(undefined4 *)(iVar14 + -4) = uVar6;
        if (5 < *(int32_t *)((int64_t)piVar11 + 0xc)) {
            iVar14 = *(int64_t *)(arg1 + 0x20);
            uVar1 = *(uint8_t *)(*(int64_t *)(iVar2 + 0x20) + 1);
            uVar12 = ~*(uint8_t *)(iVar14 + 0x58) & 3;
            if (((((uVar1 & 0xb) != uVar12) && ((*(uint8_t *)((int64_t)piVar11 + 1) & 0xb) != uVar12)) &&
                ((uVar1 & 4) != 0)) && ((*(uint8_t *)((int64_t)piVar11 + 1) & 3) != 0)) {
                if (2 < (uint8_t)(*(char *)(iVar14 + 0x59) - 1U)) {
                    *(uint8_t *)(*(int64_t *)(iVar2 + 0x20) + 1) = uVar1 & 0xf8 | *(uint8_t *)(iVar14 + 0x58) & 3;
                    return 1;
                }
                func_0x000180094420(iVar14);
            }
        }
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 3);
    pcVar3 = (code *)swi(3);
    uVar9 = (*pcVar3)();
    return uVar9;
}

// ============================================================
// Function: FUN_18003557b
// Address: 0x18003557b
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180035320(int64_t arg1, int64_t arg_38h)
{
    uint8_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t *piVar8;
    undefined8 uVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint8_t uVar12;
    undefined4 *puVar13;
    int64_t iVar14;
    int64_t var_8h;
    
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
        iVar7 = func_0x000180085d50(arg1, 1);
        if (iVar7 == 0) {
            piVar10 = *(int64_t **)(arg1 + 0x28);
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar8 = piVar10;
            if (piVar11 <= piVar10) {
                piVar8 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar8 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar8 + 0xc) == 2)) {
                piVar8 = piVar10;
                if (piVar11 <= piVar10) {
                    piVar8 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar8 + 0xc) == 9) && (*(char *)(*piVar8 + 3) == 'x')) {
                    if (piVar11 <= piVar10) {
                        piVar10 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) && (*(char *)(*piVar10 + 3) == 'x')) {
                        puVar13 = (undefined4 *)(*piVar10 + 0x10);
                    } else {
                        puVar13 = (undefined4 *)0x0;
                    }
                    iVar7 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar13);
                    if (iVar7 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar3 = (code *)swi(3);
                        uVar9 = (*pcVar3)();
                        return uVar9;
                    }
                    goto code_r0x000180035355;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180035355:
    piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    if (piVar10 == *(int64_t **)0x180782430) {
        piVar10 = (int64_t *)0x0;
    }
    iVar2 = *piVar10;
    if (*(char *)(iVar2 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    iVar7 = fcn.180088860(arg1, 2);
    if (iVar7 < 1) {
        fcn.180088380(arg1, 1, 0x180622528);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    if (*(int32_t *)(*(int64_t *)(iVar2 + 0x20) + 0xa8) < iVar7) {
        fcn.180088380(arg1, 2, 0x1806225b0);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    piVar10 = piVar11;
    if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar10 + 0xc) != -1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (piVar11 == *(int64_t **)0x180782430) {
            piVar11 = (int64_t *)0x0;
        }
        iVar14 = (int64_t)iVar7 * 0x10 + *(int64_t *)(*(int64_t *)(iVar2 + 0x20) + 0x38);
        if (*(int32_t *)(iVar14 + -4) != *(int32_t *)((int64_t)piVar11 + 0xc)) {
            fcn.180088380(arg1, 3, 0x1806225c8);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        if (*(int32_t *)(iVar14 + -4) == 8) {
            fcn.180088380(arg1, 3, 0x180622610);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        uVar4 = *(undefined4 *)((int64_t)piVar11 + 4);
        uVar5 = *(undefined4 *)(piVar11 + 1);
        uVar6 = *(undefined4 *)((int64_t)piVar11 + 0xc);
        *(undefined4 *)(iVar14 + -0x10) = *(undefined4 *)piVar11;
        *(undefined4 *)(iVar14 + -0xc) = uVar4;
        *(undefined4 *)(iVar14 + -8) = uVar5;
        *(undefined4 *)(iVar14 + -4) = uVar6;
        if (5 < *(int32_t *)((int64_t)piVar11 + 0xc)) {
            iVar14 = *(int64_t *)(arg1 + 0x20);
            uVar1 = *(uint8_t *)(*(int64_t *)(iVar2 + 0x20) + 1);
            uVar12 = ~*(uint8_t *)(iVar14 + 0x58) & 3;
            if (((((uVar1 & 0xb) != uVar12) && ((*(uint8_t *)((int64_t)piVar11 + 1) & 0xb) != uVar12)) &&
                ((uVar1 & 4) != 0)) && ((*(uint8_t *)((int64_t)piVar11 + 1) & 3) != 0)) {
                if (2 < (uint8_t)(*(char *)(iVar14 + 0x59) - 1U)) {
                    *(uint8_t *)(*(int64_t *)(iVar2 + 0x20) + 1) = uVar1 & 0xf8 | *(uint8_t *)(iVar14 + 0x58) & 3;
                    return 1;
                }
                func_0x000180094420(iVar14);
            }
        }
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 3);
    pcVar3 = (code *)swi(3);
    uVar9 = (*pcVar3)();
    return uVar9;
}

// ============================================================
// Function: FUN_18003558b
// Address: 0x18003558b
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180035320(int64_t arg1, int64_t arg_38h)
{
    uint8_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t *piVar8;
    undefined8 uVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint8_t uVar12;
    undefined4 *puVar13;
    int64_t iVar14;
    int64_t var_8h;
    
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
        iVar7 = func_0x000180085d50(arg1, 1);
        if (iVar7 == 0) {
            piVar10 = *(int64_t **)(arg1 + 0x28);
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar8 = piVar10;
            if (piVar11 <= piVar10) {
                piVar8 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar8 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar8 + 0xc) == 2)) {
                piVar8 = piVar10;
                if (piVar11 <= piVar10) {
                    piVar8 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar8 + 0xc) == 9) && (*(char *)(*piVar8 + 3) == 'x')) {
                    if (piVar11 <= piVar10) {
                        piVar10 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) && (*(char *)(*piVar10 + 3) == 'x')) {
                        puVar13 = (undefined4 *)(*piVar10 + 0x10);
                    } else {
                        puVar13 = (undefined4 *)0x0;
                    }
                    iVar7 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar13);
                    if (iVar7 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar3 = (code *)swi(3);
                        uVar9 = (*pcVar3)();
                        return uVar9;
                    }
                    goto code_r0x000180035355;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180035355:
    piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    if (piVar10 == *(int64_t **)0x180782430) {
        piVar10 = (int64_t *)0x0;
    }
    iVar2 = *piVar10;
    if (*(char *)(iVar2 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    iVar7 = fcn.180088860(arg1, 2);
    if (iVar7 < 1) {
        fcn.180088380(arg1, 1, 0x180622528);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    if (*(int32_t *)(*(int64_t *)(iVar2 + 0x20) + 0xa8) < iVar7) {
        fcn.180088380(arg1, 2, 0x1806225b0);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    piVar10 = piVar11;
    if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar10 + 0xc) != -1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (piVar11 == *(int64_t **)0x180782430) {
            piVar11 = (int64_t *)0x0;
        }
        iVar14 = (int64_t)iVar7 * 0x10 + *(int64_t *)(*(int64_t *)(iVar2 + 0x20) + 0x38);
        if (*(int32_t *)(iVar14 + -4) != *(int32_t *)((int64_t)piVar11 + 0xc)) {
            fcn.180088380(arg1, 3, 0x1806225c8);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        if (*(int32_t *)(iVar14 + -4) == 8) {
            fcn.180088380(arg1, 3, 0x180622610);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        uVar4 = *(undefined4 *)((int64_t)piVar11 + 4);
        uVar5 = *(undefined4 *)(piVar11 + 1);
        uVar6 = *(undefined4 *)((int64_t)piVar11 + 0xc);
        *(undefined4 *)(iVar14 + -0x10) = *(undefined4 *)piVar11;
        *(undefined4 *)(iVar14 + -0xc) = uVar4;
        *(undefined4 *)(iVar14 + -8) = uVar5;
        *(undefined4 *)(iVar14 + -4) = uVar6;
        if (5 < *(int32_t *)((int64_t)piVar11 + 0xc)) {
            iVar14 = *(int64_t *)(arg1 + 0x20);
            uVar1 = *(uint8_t *)(*(int64_t *)(iVar2 + 0x20) + 1);
            uVar12 = ~*(uint8_t *)(iVar14 + 0x58) & 3;
            if (((((uVar1 & 0xb) != uVar12) && ((*(uint8_t *)((int64_t)piVar11 + 1) & 0xb) != uVar12)) &&
                ((uVar1 & 4) != 0)) && ((*(uint8_t *)((int64_t)piVar11 + 1) & 3) != 0)) {
                if (2 < (uint8_t)(*(char *)(iVar14 + 0x59) - 1U)) {
                    *(uint8_t *)(*(int64_t *)(iVar2 + 0x20) + 1) = uVar1 & 0xf8 | *(uint8_t *)(iVar14 + 0x58) & 3;
                    return 1;
                }
                func_0x000180094420(iVar14);
            }
        }
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 3);
    pcVar3 = (code *)swi(3);
    uVar9 = (*pcVar3)();
    return uVar9;
}

// ============================================================
// Function: FUN_1800355f5
// Address: 0x1800355f5
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180035320(int64_t arg1, int64_t arg_38h)
{
    uint8_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t *piVar8;
    undefined8 uVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint8_t uVar12;
    undefined4 *puVar13;
    int64_t iVar14;
    int64_t var_8h;
    
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
        iVar7 = func_0x000180085d50(arg1, 1);
        if (iVar7 == 0) {
            piVar10 = *(int64_t **)(arg1 + 0x28);
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar8 = piVar10;
            if (piVar11 <= piVar10) {
                piVar8 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar8 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar8 + 0xc) == 2)) {
                piVar8 = piVar10;
                if (piVar11 <= piVar10) {
                    piVar8 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar8 + 0xc) == 9) && (*(char *)(*piVar8 + 3) == 'x')) {
                    if (piVar11 <= piVar10) {
                        piVar10 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) && (*(char *)(*piVar10 + 3) == 'x')) {
                        puVar13 = (undefined4 *)(*piVar10 + 0x10);
                    } else {
                        puVar13 = (undefined4 *)0x0;
                    }
                    iVar7 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar13);
                    if (iVar7 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar3 = (code *)swi(3);
                        uVar9 = (*pcVar3)();
                        return uVar9;
                    }
                    goto code_r0x000180035355;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        func_0x000180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180035355:
    piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    if (piVar10 == *(int64_t **)0x180782430) {
        piVar10 = (int64_t *)0x0;
    }
    iVar2 = *piVar10;
    if (*(char *)(iVar2 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    iVar7 = fcn.180088860(arg1, 2);
    if (iVar7 < 1) {
        fcn.180088380(arg1, 1, 0x180622528);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    if (*(int32_t *)(*(int64_t *)(iVar2 + 0x20) + 0xa8) < iVar7) {
        fcn.180088380(arg1, 2, 0x1806225b0);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    piVar10 = piVar11;
    if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar10 + 0xc) != -1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (piVar11 == *(int64_t **)0x180782430) {
            piVar11 = (int64_t *)0x0;
        }
        iVar14 = (int64_t)iVar7 * 0x10 + *(int64_t *)(*(int64_t *)(iVar2 + 0x20) + 0x38);
        if (*(int32_t *)(iVar14 + -4) != *(int32_t *)((int64_t)piVar11 + 0xc)) {
            fcn.180088380(arg1, 3, 0x1806225c8);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        if (*(int32_t *)(iVar14 + -4) == 8) {
            fcn.180088380(arg1, 3, 0x180622610);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        uVar4 = *(undefined4 *)((int64_t)piVar11 + 4);
        uVar5 = *(undefined4 *)(piVar11 + 1);
        uVar6 = *(undefined4 *)((int64_t)piVar11 + 0xc);
        *(undefined4 *)(iVar14 + -0x10) = *(undefined4 *)piVar11;
        *(undefined4 *)(iVar14 + -0xc) = uVar4;
        *(undefined4 *)(iVar14 + -8) = uVar5;
        *(undefined4 *)(iVar14 + -4) = uVar6;
        if (5 < *(int32_t *)((int64_t)piVar11 + 0xc)) {
            iVar14 = *(int64_t *)(arg1 + 0x20);
            uVar1 = *(uint8_t *)(*(int64_t *)(iVar2 + 0x20) + 1);
            uVar12 = ~*(uint8_t *)(iVar14 + 0x58) & 3;
            if (((((uVar1 & 0xb) != uVar12) && ((*(uint8_t *)((int64_t)piVar11 + 1) & 0xb) != uVar12)) &&
                ((uVar1 & 4) != 0)) && ((*(uint8_t *)((int64_t)piVar11 + 1) & 3) != 0)) {
                if (2 < (uint8_t)(*(char *)(iVar14 + 0x59) - 1U)) {
                    *(uint8_t *)(*(int64_t *)(iVar2 + 0x20) + 1) = uVar1 & 0xf8 | *(uint8_t *)(iVar14 + 0x58) & 3;
                    return 1;
                }
                func_0x000180094420(iVar14);
            }
        }
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 3);
    pcVar3 = (code *)swi(3);
    uVar9 = (*pcVar3)();
    return uVar9;
}

// ============================================================
// Function: FUN_180035610
// Address: 0x180035610
// Size: 188 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_12fh
// WARNING: [rz-ghidra] Detected overlap for variable var_12eh

void fcn.180035610(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    bool bVar3;
    char cVar4;
    int32_t iVar5;
    int64_t *piVar6;
    int32_t iVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    undefined8 uVar10;
    int64_t iVar11;
    undefined4 *puVar12;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_188 [32];
    int64_t var_168h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_134h;
    uint64_t uStack_18;
    int64_t var_8h;
    
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_188;
    var_168h = 0;
    cVar4 = func_0x000180051370(arg1, &var_168h);
    iVar11 = arg1;
    if (cVar4 != '\0') {
        iVar11 = var_168h;
    }
    iVar5 = func_0x000180085d50(arg1, 1);
    if (iVar5 == 0) {
        piVar9 = *(int64_t **)(arg1 + 0x28);
        piVar8 = *(int64_t **)(arg1 + 0x40);
        piVar6 = piVar9;
        if (piVar8 <= piVar9) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if ((piVar6 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar6 + 0xc) == 8)) {
            iVar5 = func_0x000180092a10(arg1, -(int32_t)((int64_t)piVar8 - (int64_t)piVar9 >> 4), 0x180622604, &var_158h
                                       );
            if (iVar5 == 0) goto code_r0x000180035894;
            goto code_r0x000180035754;
        }
        piVar6 = piVar9;
        if (piVar8 <= piVar9) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar6 + 0xc) != 9) && (*(int32_t *)((int64_t)piVar6 + 0xc) != 2)) {
code_r0x000180035a32:
            fcn.180088380(arg1, 1, 0x180622640);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        piVar6 = piVar9;
        if (piVar8 <= piVar9) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar6 + 0xc) != 9) || (*(char *)(*piVar6 + 3) != 'x')) goto code_r0x000180035a32;
        if (piVar8 <= piVar9) {
            piVar9 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar9 + 0xc) == 9) && (*(char *)(*piVar9 + 3) == 'x')) {
            puVar12 = (undefined4 *)(*piVar9 + 0x10);
        } else {
            puVar12 = (undefined4 *)0x0;
        }
        iVar5 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar12);
        if (iVar5 != 8) {
            fcn.180088560(arg1, 0x1806224c8);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        bVar3 = true;
        iVar5 = func_0x000180092a10(arg1, 0xffffffff, 0x180622604, &var_158h);
        if (iVar5 == 0) goto code_r0x000180035894;
    } else {
        iVar5 = func_0x000180085f50(arg1, 1, 0);
        if (iVar5 < 0) {
            fcn.180088380(arg1, 1, 0x180621ad8);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        iVar5 = func_0x000180092a10(iVar11, iVar5, 0x180622604, &var_158h);
        if (iVar5 == 0) goto code_r0x000180035894;
        if (iVar11 != arg1) {
            piVar9 = (int64_t *)(*(int64_t *)(iVar11 + 0x40) + -0x10);
            if ((piVar9 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(iVar11 + 0x40) + -4) != 8)) {
                *(int64_t **)(iVar11 + 0x40) = piVar9;
            } else {
                piVar8 = piVar9;
                if (piVar9 == *(int64_t **)0x180782430) {
                    piVar8 = (int64_t *)0x0;
                }
                iVar1 = *piVar8;
                *(int64_t **)(iVar11 + 0x40) = piVar9;
                func_0x000180085610(arg1, 1);
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                piVar9 = *(int64_t **)(arg1 + 0x40);
                *piVar9 = iVar1;
                *(undefined4 *)((int64_t)piVar9 + 0xc) = 8;
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar7 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
                    iVar5 = iVar7 * 2;
                    if (iVar7 < 1) {
                        iVar5 = iVar7 + 1;
                    }
                    func_0x000180093240(arg1, iVar5, 0);
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            }
        }
code_r0x000180035754:
        bVar3 = false;
    }
    func_0x000180086fd0(arg1, 0, 0);
    uVar10 = 0xfffffffe;
    if (bVar3) {
        uVar10 = 1;
    }
    func_0x000180085bf0(arg1, uVar10);
    func_0x000180087370(arg1, 0xfffffffe, 0x180622638);
    if (var_148h == 0) {
        func_0x000180086510(arg1);
    } else {
        uVar10 = func_0x000180498cd0(var_148h);
        func_0x0001800867f0(arg1, var_148h, uVar10);
    }
    func_0x000180087370(arg1, 0xfffffffe, 0x18062266c);
    if (var_140h == 0) {
        func_0x000180086510(arg1);
    } else {
        uVar10 = func_0x000180498cd0(var_140h);
        func_0x0001800867f0(arg1, var_140h, uVar10);
    }
    func_0x000180087370(arg1, 0xfffffffe, 0x180622660);
    if (var_150h == 0) {
        func_0x000180086510(arg1);
    } else {
        uVar10 = func_0x000180498cd0(var_150h);
        func_0x0001800867f0(arg1, var_150h, uVar10);
    }
    func_0x000180087370(arg1, 0xfffffffe, 0x180622684);
    func_0x0001800865e0(arg1, (undefined4)var_134h);
    func_0x000180087370(arg1, 0xfffffffe, 0x180622678);
    iVar11 = 0x1805aadb1;
    if (var_158h != 0) {
        iVar11 = var_158h;
    }
    uVar10 = func_0x000180498cd0(iVar11);
    func_0x0001800867f0(arg1, iVar11, uVar10);
    func_0x000180087370(arg1, 0xfffffffe, 0x180622694);
    func_0x0001800865e0(arg1, var_134h._4_1_);
    func_0x000180087370(arg1, 0xfffffffe, 0x18062268c);
    func_0x0001800865e0(arg1, var_134h._5_1_);
    func_0x000180087370(arg1, 0xfffffffe, 0x1806226b0);
    func_0x000180086570(arg1, (double)(uint32_t)(var_134h._6_1_ != '\0'));
    func_0x000180087370(arg1, 0xfffffffe, 0x1806226a0);
code_r0x000180035894:
    func_0x000180459870(uStack_18 ^ (uint64_t)auStack_188);
    return;
}

// ============================================================
// Function: FUN_1800356cc
// Address: 0x1800356cc
// Size: 100 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_12fh
// WARNING: [rz-ghidra] Detected overlap for variable var_12eh

void fcn.180035610(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    bool bVar3;
    char cVar4;
    int32_t iVar5;
    int64_t *piVar6;
    int32_t iVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    undefined8 uVar10;
    int64_t iVar11;
    undefined4 *puVar12;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_188 [32];
    int64_t var_168h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_134h;
    uint64_t uStack_18;
    int64_t var_8h;
    
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_188;
    var_168h = 0;
    cVar4 = func_0x000180051370(arg1, &var_168h);
    iVar11 = arg1;
    if (cVar4 != '\0') {
        iVar11 = var_168h;
    }
    iVar5 = func_0x000180085d50(arg1, 1);
    if (iVar5 == 0) {
        piVar9 = *(int64_t **)(arg1 + 0x28);
        piVar8 = *(int64_t **)(arg1 + 0x40);
        piVar6 = piVar9;
        if (piVar8 <= piVar9) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if ((piVar6 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar6 + 0xc) == 8)) {
            iVar5 = func_0x000180092a10(arg1, -(int32_t)((int64_t)piVar8 - (int64_t)piVar9 >> 4), 0x180622604, &var_158h
                                       );
            if (iVar5 == 0) goto code_r0x000180035894;
            goto code_r0x000180035754;
        }
        piVar6 = piVar9;
        if (piVar8 <= piVar9) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar6 + 0xc) != 9) && (*(int32_t *)((int64_t)piVar6 + 0xc) != 2)) {
code_r0x000180035a32:
            fcn.180088380(arg1, 1, 0x180622640);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        piVar6 = piVar9;
        if (piVar8 <= piVar9) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar6 + 0xc) != 9) || (*(char *)(*piVar6 + 3) != 'x')) goto code_r0x000180035a32;
        if (piVar8 <= piVar9) {
            piVar9 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar9 + 0xc) == 9) && (*(char *)(*piVar9 + 3) == 'x')) {
            puVar12 = (undefined4 *)(*piVar9 + 0x10);
        } else {
            puVar12 = (undefined4 *)0x0;
        }
        iVar5 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar12);
        if (iVar5 != 8) {
            fcn.180088560(arg1, 0x1806224c8);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        bVar3 = true;
        iVar5 = func_0x000180092a10(arg1, 0xffffffff, 0x180622604, &var_158h);
        if (iVar5 == 0) goto code_r0x000180035894;
    } else {
        iVar5 = func_0x000180085f50(arg1, 1, 0);
        if (iVar5 < 0) {
            fcn.180088380(arg1, 1, 0x180621ad8);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        iVar5 = func_0x000180092a10(iVar11, iVar5, 0x180622604, &var_158h);
        if (iVar5 == 0) goto code_r0x000180035894;
        if (iVar11 != arg1) {
            piVar9 = (int64_t *)(*(int64_t *)(iVar11 + 0x40) + -0x10);
            if ((piVar9 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(iVar11 + 0x40) + -4) != 8)) {
                *(int64_t **)(iVar11 + 0x40) = piVar9;
            } else {
                piVar8 = piVar9;
                if (piVar9 == *(int64_t **)0x180782430) {
                    piVar8 = (int64_t *)0x0;
                }
                iVar1 = *piVar8;
                *(int64_t **)(iVar11 + 0x40) = piVar9;
                func_0x000180085610(arg1, 1);
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                piVar9 = *(int64_t **)(arg1 + 0x40);
                *piVar9 = iVar1;
                *(undefined4 *)((int64_t)piVar9 + 0xc) = 8;
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar7 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
                    iVar5 = iVar7 * 2;
                    if (iVar7 < 1) {
                        iVar5 = iVar7 + 1;
                    }
                    func_0x000180093240(arg1, iVar5, 0);
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            }
        }
code_r0x000180035754:
        bVar3 = false;
    }
    func_0x000180086fd0(arg1, 0, 0);
    uVar10 = 0xfffffffe;
    if (bVar3) {
        uVar10 = 1;
    }
    func_0x000180085bf0(arg1, uVar10);
    func_0x000180087370(arg1, 0xfffffffe, 0x180622638);
    if (var_148h == 0) {
        func_0x000180086510(arg1);
    } else {
        uVar10 = func_0x000180498cd0(var_148h);
        func_0x0001800867f0(arg1, var_148h, uVar10);
    }
    func_0x000180087370(arg1, 0xfffffffe, 0x18062266c);
    if (var_140h == 0) {
        func_0x000180086510(arg1);
    } else {
        uVar10 = func_0x000180498cd0(var_140h);
        func_0x0001800867f0(arg1, var_140h, uVar10);
    }
    func_0x000180087370(arg1, 0xfffffffe, 0x180622660);
    if (var_150h == 0) {
        func_0x000180086510(arg1);
    } else {
        uVar10 = func_0x000180498cd0(var_150h);
        func_0x0001800867f0(arg1, var_150h, uVar10);
    }
    func_0x000180087370(arg1, 0xfffffffe, 0x180622684);
    func_0x0001800865e0(arg1, (undefined4)var_134h);
    func_0x000180087370(arg1, 0xfffffffe, 0x180622678);
    iVar11 = 0x1805aadb1;
    if (var_158h != 0) {
        iVar11 = var_158h;
    }
    uVar10 = func_0x000180498cd0(iVar11);
    func_0x0001800867f0(arg1, iVar11, uVar10);
    func_0x000180087370(arg1, 0xfffffffe, 0x180622694);
    func_0x0001800865e0(arg1, var_134h._4_1_);
    func_0x000180087370(arg1, 0xfffffffe, 0x18062268c);
    func_0x0001800865e0(arg1, var_134h._5_1_);
    func_0x000180087370(arg1, 0xfffffffe, 0x1806226b0);
    func_0x000180086570(arg1, (double)(uint32_t)(var_134h._6_1_ != '\0'));
    func_0x000180087370(arg1, 0xfffffffe, 0x1806226a0);
code_r0x000180035894:
    func_0x000180459870(uStack_18 ^ (uint64_t)auStack_188);
    return;
}

// ============================================================
// Function: FUN_180035730
// Address: 0x180035730
// Size: 819 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_12fh
// WARNING: [rz-ghidra] Detected overlap for variable var_12eh

void fcn.180035610(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    bool bVar3;
    char cVar4;
    int32_t iVar5;
    int64_t *piVar6;
    int32_t iVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    undefined8 uVar10;
    int64_t iVar11;
    undefined4 *puVar12;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_188 [32];
    int64_t var_168h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_134h;
    uint64_t uStack_18;
    int64_t var_8h;
    
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_188;
    var_168h = 0;
    cVar4 = func_0x000180051370(arg1, &var_168h);
    iVar11 = arg1;
    if (cVar4 != '\0') {
        iVar11 = var_168h;
    }
    iVar5 = func_0x000180085d50(arg1, 1);
    if (iVar5 == 0) {
        piVar9 = *(int64_t **)(arg1 + 0x28);
        piVar8 = *(int64_t **)(arg1 + 0x40);
        piVar6 = piVar9;
        if (piVar8 <= piVar9) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if ((piVar6 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar6 + 0xc) == 8)) {
            iVar5 = func_0x000180092a10(arg1, -(int32_t)((int64_t)piVar8 - (int64_t)piVar9 >> 4), 0x180622604, &var_158h
                                       );
            if (iVar5 == 0) goto code_r0x000180035894;
            goto code_r0x000180035754;
        }
        piVar6 = piVar9;
        if (piVar8 <= piVar9) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar6 + 0xc) != 9) && (*(int32_t *)((int64_t)piVar6 + 0xc) != 2)) {
code_r0x000180035a32:
            fcn.180088380(arg1, 1, 0x180622640);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        piVar6 = piVar9;
        if (piVar8 <= piVar9) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar6 + 0xc) != 9) || (*(char *)(*piVar6 + 3) != 'x')) goto code_r0x000180035a32;
        if (piVar8 <= piVar9) {
            piVar9 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar9 + 0xc) == 9) && (*(char *)(*piVar9 + 3) == 'x')) {
            puVar12 = (undefined4 *)(*piVar9 + 0x10);
        } else {
            puVar12 = (undefined4 *)0x0;
        }
        iVar5 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar12);
        if (iVar5 != 8) {
            fcn.180088560(arg1, 0x1806224c8);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        bVar3 = true;
        iVar5 = func_0x000180092a10(arg1, 0xffffffff, 0x180622604, &var_158h);
        if (iVar5 == 0) goto code_r0x000180035894;
    } else {
        iVar5 = func_0x000180085f50(arg1, 1, 0);
        if (iVar5 < 0) {
            fcn.180088380(arg1, 1, 0x180621ad8);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        iVar5 = func_0x000180092a10(iVar11, iVar5, 0x180622604, &var_158h);
        if (iVar5 == 0) goto code_r0x000180035894;
        if (iVar11 != arg1) {
            piVar9 = (int64_t *)(*(int64_t *)(iVar11 + 0x40) + -0x10);
            if ((piVar9 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(iVar11 + 0x40) + -4) != 8)) {
                *(int64_t **)(iVar11 + 0x40) = piVar9;
            } else {
                piVar8 = piVar9;
                if (piVar9 == *(int64_t **)0x180782430) {
                    piVar8 = (int64_t *)0x0;
                }
                iVar1 = *piVar8;
                *(int64_t **)(iVar11 + 0x40) = piVar9;
                func_0x000180085610(arg1, 1);
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                piVar9 = *(int64_t **)(arg1 + 0x40);
                *piVar9 = iVar1;
                *(undefined4 *)((int64_t)piVar9 + 0xc) = 8;
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar7 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
                    iVar5 = iVar7 * 2;
                    if (iVar7 < 1) {
                        iVar5 = iVar7 + 1;
                    }
                    func_0x000180093240(arg1, iVar5, 0);
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            }
        }
code_r0x000180035754:
        bVar3 = false;
    }
    func_0x000180086fd0(arg1, 0, 0);
    uVar10 = 0xfffffffe;
    if (bVar3) {
        uVar10 = 1;
    }
    func_0x000180085bf0(arg1, uVar10);
    func_0x000180087370(arg1, 0xfffffffe, 0x180622638);
    if (var_148h == 0) {
        func_0x000180086510(arg1);
    } else {
        uVar10 = func_0x000180498cd0(var_148h);
        func_0x0001800867f0(arg1, var_148h, uVar10);
    }
    func_0x000180087370(arg1, 0xfffffffe, 0x18062266c);
    if (var_140h == 0) {
        func_0x000180086510(arg1);
    } else {
        uVar10 = func_0x000180498cd0(var_140h);
        func_0x0001800867f0(arg1, var_140h, uVar10);
    }
    func_0x000180087370(arg1, 0xfffffffe, 0x180622660);
    if (var_150h == 0) {
        func_0x000180086510(arg1);
    } else {
        uVar10 = func_0x000180498cd0(var_150h);
        func_0x0001800867f0(arg1, var_150h, uVar10);
    }
    func_0x000180087370(arg1, 0xfffffffe, 0x180622684);
    func_0x0001800865e0(arg1, (undefined4)var_134h);
    func_0x000180087370(arg1, 0xfffffffe, 0x180622678);
    iVar11 = 0x1805aadb1;
    if (var_158h != 0) {
        iVar11 = var_158h;
    }
    uVar10 = func_0x000180498cd0(iVar11);
    func_0x0001800867f0(arg1, iVar11, uVar10);
    func_0x000180087370(arg1, 0xfffffffe, 0x180622694);
    func_0x0001800865e0(arg1, var_134h._4_1_);
    func_0x000180087370(arg1, 0xfffffffe, 0x18062268c);
    func_0x0001800865e0(arg1, var_134h._5_1_);
    func_0x000180087370(arg1, 0xfffffffe, 0x1806226b0);
    func_0x000180086570(arg1, (double)(uint32_t)(var_134h._6_1_ != '\0'));
    func_0x000180087370(arg1, 0xfffffffe, 0x1806226a0);
code_r0x000180035894:
    func_0x000180459870(uStack_18 ^ (uint64_t)auStack_188);
    return;
}

// ============================================================
// Function: FUN_180035a70
// Address: 0x180035a70
// Size: 144 bytes
// ============================================================
undefined8 fcn.180035a70(int64_t arg1)
{
    undefined4 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    undefined4 *puVar7;
    undefined8 uVar8;
    
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar6 = func_0x000180085510(arg1, 1);
        if (iVar6 == 0) {
            func_0x000180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            uVar8 = (*pcVar2)();
            return uVar8;
        }
    }
    puVar7 = (undefined4 *)fcn.180085370(arg1, 0xffffd8f0);
    puVar1 = *(undefined4 **)(arg1 + 0x40);
    uVar3 = puVar7[1];
    uVar4 = puVar7[2];
    uVar5 = puVar7[3];
    *puVar1 = *puVar7;
    puVar1[1] = uVar3;
    puVar1[2] = uVar4;
    puVar1[3] = uVar5;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_180035b00
// Address: 0x180035b00
// Size: 98 bytes
// ============================================================
undefined8 fcn.180035b00(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    
    uVar4 = *(uint64_t *)(arg1 + 0x28);
    if (*(uint64_t *)(arg1 + 0x40) <= *(uint64_t *)(arg1 + 0x28)) {
        uVar4 = *(uint64_t *)0x180782430;
    }
    if ((uVar4 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar4 + 0xc) != -1)) {
        iVar2 = fcn.180087120(arg1, 1);
        if (iVar2 == 0) {
            fcn.180086510(arg1);
        }
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 1);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_180035b70
// Address: 0x180035b70
// Size: 181 bytes
// ============================================================
undefined8 fcn.180035b70(int64_t arg1)
{
    uint64_t uVar1;
    code *pcVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined8 uVar5;
    
    uVar4 = *(uint64_t *)(arg1 + 0x28);
    uVar1 = *(uint64_t *)(arg1 + 0x40);
    uVar3 = uVar4;
    if (uVar1 <= uVar4) {
        uVar3 = *(uint64_t *)0x180782430;
    }
    if ((uVar3 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar3 + 0xc) == -1)) {
        fcn.180088560(arg1, 0x18063da20, 1);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    uVar4 = uVar4 + 0x10;
    uVar3 = uVar4;
    if (uVar1 <= uVar4) {
        uVar3 = *(uint64_t *)0x180782430;
    }
    if ((uVar3 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar3 + 0xc) != 0)) {
        if (uVar1 <= uVar4) {
            uVar4 = *(uint64_t *)0x180782430;
        }
        if ((uVar4 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar4 + 0xc) != 7)) {
            fcn.1800883d0(arg1, 2, 0x1806226e8);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
    }
    func_0x0001800858c0(arg1, 2);
    func_0x000180087650(arg1, 1);
    func_0x000180085bf0(arg1, 1);
    return 1;
}

// ============================================================
// Function: FUN_180035c30
// Address: 0x180035c30
// Size: 2078 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_d7h
// WARNING: [rz-ghidra] Detected overlap for variable var_d0h
// WARNING: [rz-ghidra] Detected overlap for variable var_d8h

void fcn.180035c30(int64_t arg1)
{
    uint64_t uVar1;
    code *pcVar2;
    undefined auVar3 [16];
    undefined auVar4 [16];
    undefined auVar5 [16];
    bool bVar6;
    bool bVar7;
    undefined auVar8 [16];
    undefined auVar9 [16];
    int32_t iVar10;
    int64_t *piVar11;
    int64_t *piVar12;
    undefined8 uVar13;
    int64_t iVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    int64_t iVar17;
    int64_t iVar18;
    undefined *puVar19;
    undefined *puVar20;
    int64_t *piVar21;
    int64_t *piVar22;
    undefined4 extraout_XMM0_Da;
    undefined4 uVar23;
    undefined8 uStack_100;
    undefined auStack_f8 [8];
    undefined auStack_f0 [24];
    char var_d8h;
    char var_d7h;
    int64_t var_d4h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    undefined8 uStack_88;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    
    puVar19 = auStack_f8;
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_f8;
    piVar21 = (int64_t *)0x0;
    piVar12 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) != 8)) {
        iVar10 = func_0x000180085d50(arg1, 1);
        if (iVar10 != 0) {
            func_0x000180033bd0(arg1);
            goto code_r0x000180035c91;
        }
        piVar12 = *(int64_t **)(arg1 + 0x28);
        piVar22 = *(int64_t **)(arg1 + 0x40);
        piVar11 = piVar12;
        if (piVar22 <= piVar12) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar11 + 0xc) != 9) && (*(int32_t *)((int64_t)piVar11 + 0xc) != 2))
        goto code_r0x0001800363cd;
        piVar11 = piVar12;
        if (piVar22 <= piVar12) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar11 + 0xc) != 9) || (*(char *)(*piVar11 + 3) != 'x')) goto code_r0x0001800363cd;
        if (piVar22 <= piVar12) {
            piVar12 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar12 + 0xc) != 9) ||
           (piVar22 = (int64_t *)(*piVar12 + 0x10), *(char *)(*piVar12 + 3) != 'x')) {
            piVar22 = piVar21;
        }
        iVar10 = func_0x000180086ed0(arg1, 0xffffd8f0, *(undefined4 *)piVar22);
        if (iVar10 == 8) goto code_r0x000180035c91;
        fcn.180088560(arg1, 0x1806224c8);
code_r0x0001800363c7:
        func_0x000180004720();
code_r0x0001800363cd:
        fcn.180088380(arg1, 1, 0x180622478);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    func_0x000180085bf0(arg1, 1);
code_r0x000180035c91:
    piVar22 = *(int64_t **)(arg1 + 0x40);
    piVar12 = piVar22 + -2;
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar22 + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    if (piVar12 == *(int64_t **)0x180782430) {
        piVar12 = piVar21;
    }
    if (*(char *)(*piVar12 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
code_r0x0001800363f7:
        uVar23 = fcn.180088560(arg1, 0x1806226c0);
        goto code_r0x000180036407;
    }
    piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (piVar22 <= piVar11) {
        piVar11 = *(int64_t **)0x180782430;
    }
    if ((piVar11 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar11 + 0xc) != 7)) goto code_r0x00018003643a;
    iVar18 = *(int64_t *)(*piVar12 + 0x20);
    var_60h = 0;
    var_58h = 0xf;
    stack0xffffffffffffff91 = SUB1615(ZEXT816(0), 1);
    auVar3[15] = 0;
    auVar3._0_15_ = stack0xffffffffffffff91;
    _var_70h = auVar3 << 8;
    bVar7 = false;
    iVar10 = func_0x000180086cc0(arg1, 2, 0x180622660);
    if (0 < iVar10) {
        piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10);
        if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 6))
        goto code_r0x0001800363f7;
        iVar14 = *piVar12;
        uVar13 = func_0x000180498cd0(iVar14 + 0x18);
        func_0x00018000f180(&var_70h, iVar14 + 0x18, uVar13);
        bVar7 = true;
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    var_a0h = 0;
    var_98h = 0xf;
    stack0xffffffffffffff51 = SUB1615(ZEXT816(0), 1);
    auVar4[15] = 0;
    auVar4._0_15_ = stack0xffffffffffffff51;
    _var_b0h = auVar4 << 8;
    bVar6 = false;
    iVar10 = func_0x000180086cc0(arg1, 2, 0x18062266c);
    if (0 < iVar10) {
        piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10);
        if (piVar12 == *(int64_t **)0x180782430) {
code_r0x000180036414:
            fcn.180088560(arg1, 0x180622720);
            goto code_r0x000180036424;
        }
        iVar10 = *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4);
        if (iVar10 == 6) {
code_r0x000180035ec8:
            piVar12 = (int64_t *)(*piVar12 + 0x18);
        } else {
            if (iVar10 != 3) goto code_r0x000180036414;
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar10 = func_0x0001800a8360(arg1);
            piVar12 = piVar21;
            if (iVar10 != 0) {
                if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30))
                {
                    (**(code **)0x180782658)(arg1, 1);
                }
                piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10);
                goto code_r0x000180035ec8;
            }
        }
        uVar13 = func_0x000180498cd0(piVar12);
        func_0x00018000f180(&var_b0h, piVar12, uVar13);
        bVar6 = true;
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    iVar10 = func_0x000180086cc0(arg1, 2, 0x180622678);
    if (iVar10 < 1) {
        var_d4h._0_4_ = 0;
        var_d7h = '\0';
    } else {
        iVar10 = func_0x000180085d50(arg1, 0xffffffff);
        uVar23 = extraout_XMM0_Da;
        if (iVar10 == 0) {
code_r0x000180036407:
            fcn.180088560(uVar23, 0x1806226f8);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        var_d4h._0_4_ = func_0x000180085f50(arg1, 0xffffffff, 0);
        var_d7h = '\x01';
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    var_c0h = 0;
    var_b8h = 0xf;
    stack0xffffffffffffff31 = SUB1615(ZEXT816(0), 1);
    auVar5[15] = 0;
    auVar5._0_15_ = stack0xffffffffffffff31;
    stack0xffffffffffffff30 = auVar5 << 8;
    var_d8h = '\0';
    iVar10 = func_0x000180086cc0(arg1, 2, 0x180622694);
    if (0 < iVar10) {
        piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10);
        if (piVar12 == *(int64_t **)0x180782430) {
code_r0x000180036424:
            fcn.180088560(arg1, 0x180622748);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        iVar10 = *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4);
        if (iVar10 == 6) {
code_r0x000180035ff2:
            piVar21 = (int64_t *)(*piVar12 + 0x18);
        } else {
            if (iVar10 != 3) goto code_r0x000180036424;
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar10 = func_0x0001800a8360(arg1);
            if (iVar10 != 0) {
                if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30))
                {
                    (**(code **)0x180782658)(arg1, 1);
                }
                piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10);
                goto code_r0x000180035ff2;
            }
        }
        uVar13 = func_0x000180498cd0(piVar21);
        func_0x00018000f180((int64_t)&var_d4h + 4, piVar21, uVar13);
        var_d8h = '\x01';
    }
    iVar14 = var_60h;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    if (bVar6) {
        piVar12 = &var_b0h;
        if (0xf < (uint64_t)var_98h) {
            piVar12 = (int64_t *)var_b0h;
        }
        iVar14 = func_0x00018009a8e0(arg1, piVar12, var_a0h);
        *(int64_t *)(iVar18 + 0x10) = iVar14 + 0x10 + iVar18;
        puVar20 = auStack_f8;
        if (((*(uint8_t *)(iVar18 + 1) & 4) != 0) && (puVar20 = auStack_f8, (*(uint8_t *)(iVar14 + 1) & 3) != 0)) {
            iVar17 = *(int64_t *)(arg1 + 0x20);
            if ((uint8_t)(*(char *)(iVar17 + 0x59) - 1U) < 3) {
                func_0x000180094420(iVar17, iVar14);
                puVar20 = auStack_f8;
            } else {
                *(uint8_t *)(iVar18 + 1) = *(uint8_t *)(iVar17 + 0x58) & 3 | *(uint8_t *)(iVar18 + 1) & 0xf8;
                puVar20 = auStack_f8;
            }
        }
        goto code_r0x00018003622b;
    }
    puVar20 = auStack_f8;
    if (!bVar7) goto code_r0x00018003622b;
    if (var_60h == 0x7fffffffffffffff) {
        func_0x0001800047c0();
code_r0x00018003643a:
        func_0x000180088470(arg1, 2, 7);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    piVar12 = &var_70h;
    if (0xf < (uint64_t)var_58h) {
        piVar12 = (int64_t *)var_70h;
    }
    _var_90h = ZEXT816(0);
    var_80h = 0;
    var_78h = 0;
    uVar1 = var_60h + 1;
    if (uVar1 < 0x10) {
        uVar15 = 0xf;
        piVar21 = &var_90h;
code_r0x000180036163:
        var_80h = uVar1;
        var_78h = uVar15;
        *(undefined *)piVar21 = 0x3d;
        func_0x000180498030((undefined *)((int64_t)piVar21 + 1), piVar12, iVar14);
        *(undefined *)((int64_t)piVar21 + uVar1) = 0;
        piVar12 = &var_90h;
        if (0xf < (uint64_t)var_78h) {
            piVar12 = (int64_t *)var_90h;
        }
        iVar14 = func_0x00018009a8e0(arg1, piVar12, var_80h);
        *(int64_t *)(iVar18 + 0x10) = iVar14 + 0x10 + iVar18;
        if (((*(uint8_t *)(iVar18 + 1) & 4) != 0) && ((*(uint8_t *)(iVar14 + 1) & 3) != 0)) {
            iVar17 = *(int64_t *)(arg1 + 0x20);
            if ((uint8_t)(*(char *)(iVar17 + 0x59) - 1U) < 3) {
                func_0x000180094420(iVar17, iVar14);
            } else {
                *(uint8_t *)(iVar18 + 1) = *(uint8_t *)(iVar17 + 0x58) & 3 | *(uint8_t *)(iVar18 + 1) & 0xf8;
            }
        }
        puVar20 = auStack_f8;
        if ((uint64_t)var_78h < 0x10) goto code_r0x00018003622b;
        iVar14 = var_90h;
        if ((0xfff < var_78h + 1U) &&
           (iVar14 = *(int64_t *)(var_90h + -8), puVar19 = auStack_f8,
           0x1f < (var_90h - *(int64_t *)(var_90h + -8)) - 8U)) goto code_r0x000180036219;
    } else {
        uVar15 = uVar1 | 0xf;
        if (uVar15 < 0x8000000000000000) {
            if (uVar15 < 0x16) {
                uVar15 = 0x16;
            }
            if (uVar15 == 0xffffffffffffffff) {
                piVar21 = (int64_t *)0x0;
                _var_90h = ZEXT816(0);
            } else {
                if (0xfff < uVar15 + 1) {
                    uVar16 = uVar15 + 0x28;
                    if (uVar16 <= uVar15 + 1) goto code_r0x0001800363c7;
                    goto code_r0x0001800360f1;
                }
                piVar21 = (int64_t *)func_0x000180459890();
                var_90h = (int64_t)piVar21;
            }
            goto code_r0x000180036163;
        }
        uVar16 = 0x8000000000000027;
        uVar15 = 0x7fffffffffffffff;
code_r0x0001800360f1:
        iVar17 = func_0x000180459890(uVar16);
        if (iVar17 != 0) {
            piVar21 = (int64_t *)(iVar17 + 0x27U & 0xffffffffffffffe0);
            piVar21[-1] = iVar17;
            var_90h = (int64_t)piVar21;
            goto code_r0x000180036163;
        }
code_r0x000180036219:
        pcVar2 = (code *)swi(0x29);
        iVar14 = (*pcVar2)(5);
        puVar19 = auStack_f0;
    }
    *(undefined8 *)(puVar19 + -8) = 0x180036228;
    func_0x000180459c3c(iVar14);
    puVar20 = puVar19;
code_r0x00018003622b:
    if (var_d8h != '\0') {
        iVar14 = (int64_t)&var_d4h + 4;
        if (0xf < (uint64_t)var_b8h) {
            iVar14 = stack0xffffffffffffff30;
        }
        *(undefined8 *)(puVar20 + -8) = 0x18003624b;
        iVar14 = func_0x00018009a8e0(arg1, iVar14, var_c0h);
        *(int64_t *)(iVar18 + 0x20) = (iVar18 + 0x20) - iVar14;
        if (((*(uint8_t *)(iVar18 + 1) & 4) != 0) && ((*(uint8_t *)(iVar14 + 1) & 3) != 0)) {
            iVar17 = *(int64_t *)(arg1 + 0x20);
            if ((uint8_t)(*(char *)(iVar17 + 0x59) - 1U) < 3) {
                *(undefined8 *)(puVar20 + -8) = 0x180036290;
                func_0x000180094420(iVar17, iVar14);
            } else {
                *(uint8_t *)(iVar18 + 1) = *(uint8_t *)(iVar17 + 0x58) & 3 | *(uint8_t *)(iVar18 + 1) & 0xf8;
            }
        }
    }
    if (var_d7h != '\0') {
        *(undefined4 *)(iVar18 + 0x8c) = (undefined4)var_d4h;
    }
    if (0xf < (uint64_t)var_b8h) {
        iVar18 = stack0xffffffffffffff30;
        if ((0xfff < var_b8h + 1U) &&
           (iVar18 = *(int64_t *)(stack0xffffffffffffff30 + -8), 0x1f < (stack0xffffffffffffff30 - iVar18) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar18 = (*pcVar2)(5);
            puVar20 = puVar20 + 8;
        }
        *(undefined8 *)(puVar20 + -8) = 0x1800362e0;
        func_0x000180459c3c(iVar18);
    }
    var_c0h = 0;
    var_b8h = 0xf;
    auVar8[15] = 0;
    auVar8._0_15_ = stack0xffffffffffffff31;
    stack0xffffffffffffff30 = auVar8 << 8;
    if (0xf < (uint64_t)var_98h) {
        iVar18 = var_b0h;
        if ((0xfff < var_98h + 1U) && (iVar18 = *(int64_t *)(var_b0h + -8), 0x1f < (var_b0h - iVar18) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar18 = (*pcVar2)(5);
            puVar20 = puVar20 + 8;
        }
        *(undefined8 *)(puVar20 + -8) = 0x180036330;
        func_0x000180459c3c(iVar18);
    }
    var_a0h = 0;
    var_98h = 0xf;
    auVar9[15] = 0;
    auVar9._0_15_ = stack0xffffffffffffff51;
    _var_b0h = auVar9 << 8;
    if (0xf < (uint64_t)var_58h) {
        iVar18 = var_70h;
        if ((0xfff < var_58h + 1U) && (iVar18 = *(int64_t *)(var_70h + -8), 0x1f < (var_70h - iVar18) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar18 = (*pcVar2)(5);
            puVar20 = puVar20 + 8;
        }
        *(undefined8 *)(puVar20 + -8) = 0x180036380;
        func_0x000180459c3c(iVar18);
    }
    *(undefined8 *)(puVar20 + -8) = 0x18003638e;
    func_0x000180459870(var_50h ^ (uint64_t)puVar20);
    return;
}

// ============================================================
// Function: FUN_180036450
// Address: 0x180036450
// Size: 133 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180036450(int64_t arg1)
{
    undefined4 *puVar1;
    uint32_t *puVar2;
    code *pcVar3;
    char cVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint64_t uVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t iVar10;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStackY_188 [32];
    int64_t var_168h;
    int64_t var_158h;
    int64_t in_stack_fffffffffffffeb0;
    int64_t var_8h;
    
    uVar7 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_188;
    iVar5 = fcn.180088860(arg1, 1);
    if (iVar5 < 1) {
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar5 = fcn.180085510(in_stack_fffffffffffffeb0), iVar5 == 0)) {
code_r0x0001800365c7:
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        puVar1 = *(undefined4 **)(arg1 + 0x40);
        *puVar1 = 0;
        puVar1[3] = 1;
    } else {
        piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        piVar8 = piVar9;
        if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
            piVar8 = *(int64_t **)0x180782430;
        }
        if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 10)) {
            var_168h = 0;
            cVar4 = func_0x000180051370(arg1, &var_168h);
            iVar10 = arg1;
            if (cVar4 != '\0') {
                iVar10 = var_168h;
            }
        } else {
            if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
                piVar9 = *(int64_t **)0x180782430;
            }
            iVar10 = 0;
            if (*(int32_t *)((int64_t)piVar9 + 0xc) == 10) {
                iVar10 = *piVar9;
            }
        }
        iVar5 = func_0x000180092a10(iVar10, iVar5, 0x180621b1c, &var_158h);
        if (iVar5 != 0) {
            *(int64_t *)(iVar10 + 0x40) = *(int64_t *)(iVar10 + 0x40) + -0x10;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(in_stack_fffffffffffffeb0), iVar6 == 0)) goto code_r0x0001800365c7;
        puVar2 = *(uint32_t **)(arg1 + 0x40);
        *puVar2 = (uint32_t)(iVar5 != 0);
        puVar2[3] = 1;
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    func_0x000180459870(uVar7 ^ (uint64_t)auStackY_188);
    return;
}

// ============================================================
// Function: FUN_1800364d5
// Address: 0x1800364d5
// Size: 142 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180036450(int64_t arg1)
{
    undefined4 *puVar1;
    uint32_t *puVar2;
    code *pcVar3;
    char cVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint64_t uVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t iVar10;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStackY_188 [32];
    int64_t var_168h;
    int64_t var_158h;
    int64_t in_stack_fffffffffffffeb0;
    int64_t var_8h;
    
    uVar7 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_188;
    iVar5 = fcn.180088860(arg1, 1);
    if (iVar5 < 1) {
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar5 = fcn.180085510(in_stack_fffffffffffffeb0), iVar5 == 0)) {
code_r0x0001800365c7:
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        puVar1 = *(undefined4 **)(arg1 + 0x40);
        *puVar1 = 0;
        puVar1[3] = 1;
    } else {
        piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        piVar8 = piVar9;
        if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
            piVar8 = *(int64_t **)0x180782430;
        }
        if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 10)) {
            var_168h = 0;
            cVar4 = func_0x000180051370(arg1, &var_168h);
            iVar10 = arg1;
            if (cVar4 != '\0') {
                iVar10 = var_168h;
            }
        } else {
            if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
                piVar9 = *(int64_t **)0x180782430;
            }
            iVar10 = 0;
            if (*(int32_t *)((int64_t)piVar9 + 0xc) == 10) {
                iVar10 = *piVar9;
            }
        }
        iVar5 = func_0x000180092a10(iVar10, iVar5, 0x180621b1c, &var_158h);
        if (iVar5 != 0) {
            *(int64_t *)(iVar10 + 0x40) = *(int64_t *)(iVar10 + 0x40) + -0x10;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(in_stack_fffffffffffffeb0), iVar6 == 0)) goto code_r0x0001800365c7;
        puVar2 = *(uint32_t **)(arg1 + 0x40);
        *puVar2 = (uint32_t)(iVar5 != 0);
        puVar2[3] = 1;
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    func_0x000180459870(uVar7 ^ (uint64_t)auStackY_188);
    return;
}

// ============================================================
// Function: FUN_180036563
// Address: 0x180036563
// Size: 124 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180036450(int64_t arg1)
{
    undefined4 *puVar1;
    uint32_t *puVar2;
    code *pcVar3;
    char cVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint64_t uVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t iVar10;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStackY_188 [32];
    int64_t var_168h;
    int64_t var_158h;
    int64_t in_stack_fffffffffffffeb0;
    int64_t var_8h;
    
    uVar7 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_188;
    iVar5 = fcn.180088860(arg1, 1);
    if (iVar5 < 1) {
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar5 = fcn.180085510(in_stack_fffffffffffffeb0), iVar5 == 0)) {
code_r0x0001800365c7:
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        puVar1 = *(undefined4 **)(arg1 + 0x40);
        *puVar1 = 0;
        puVar1[3] = 1;
    } else {
        piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        piVar8 = piVar9;
        if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
            piVar8 = *(int64_t **)0x180782430;
        }
        if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 10)) {
            var_168h = 0;
            cVar4 = func_0x000180051370(arg1, &var_168h);
            iVar10 = arg1;
            if (cVar4 != '\0') {
                iVar10 = var_168h;
            }
        } else {
            if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
                piVar9 = *(int64_t **)0x180782430;
            }
            iVar10 = 0;
            if (*(int32_t *)((int64_t)piVar9 + 0xc) == 10) {
                iVar10 = *piVar9;
            }
        }
        iVar5 = func_0x000180092a10(iVar10, iVar5, 0x180621b1c, &var_158h);
        if (iVar5 != 0) {
            *(int64_t *)(iVar10 + 0x40) = *(int64_t *)(iVar10 + 0x40) + -0x10;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(in_stack_fffffffffffffeb0), iVar6 == 0)) goto code_r0x0001800365c7;
        puVar2 = *(uint32_t **)(arg1 + 0x40);
        *puVar2 = (uint32_t)(iVar5 != 0);
        puVar2[3] = 1;
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    func_0x000180459870(uVar7 ^ (uint64_t)auStackY_188);
    return;
}

// ============================================================
// Function: FUN_1800365e0
// Address: 0x1800365e0
// Size: 936 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800365e0(int64_t arg1)
{
    double *pdVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    char cVar7;
    int32_t iVar8;
    uint64_t uVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    undefined8 uVar12;
    undefined4 *puVar13;
    int32_t iVar14;
    int32_t iVar15;
    int64_t *piVar16;
    int64_t iVar17;
    int32_t iVar18;
    int64_t iVar19;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStackY_198 [32];
    int64_t var_178h;
    int64_t var_168h;
    int64_t in_stack_fffffffffffffea0;
    int64_t var_158h;
    int64_t var_144h;
    int64_t var_28h;
    
    uVar9 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_198;
    piVar16 = *(int64_t **)(arg1 + 0x28);
    piVar10 = piVar16;
    if (*(int64_t **)(arg1 + 0x40) <= piVar16) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 10)) {
        var_178h = 0;
        cVar7 = func_0x000180051370(arg1, &var_178h);
        iVar19 = arg1;
        if (cVar7 != '\0') {
            iVar19 = var_178h;
        }
    } else {
        if (*(int64_t **)(arg1 + 0x40) <= piVar16) {
            piVar16 = *(int64_t **)0x180782430;
        }
        iVar19 = 0;
        if (*(int32_t *)((int64_t)piVar16 + 0xc) == 10) {
            iVar19 = *piVar16;
        }
    }
    func_0x000180086fd0(arg1, 0, 0);
    iVar18 = 1;
    iVar8 = func_0x000180092a10(iVar19, 1, 0x180622740, &var_168h);
    while( true ) {
        if (iVar8 == 0) {
            func_0x000180459870(uVar9 ^ (uint64_t)auStackY_198);
            return;
        }
        func_0x000180086fd0(arg1, 0, 0);
        piVar16 = (int64_t *)(*(int64_t *)(iVar19 + 0x40) - 0x10);
        if ((piVar16 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(iVar19 + 0x40) + -4) != 8)) {
            *(int64_t **)(iVar19 + 0x40) = piVar16;
            if ((*(char *)0x180777010 != '\0') &&
               ((**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U &&
                (iVar8 = fcn.180085510(in_stack_fffffffffffffea0), iVar8 == 0)))) break;
            *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
        } else {
            piVar10 = piVar16;
            if (piVar16 == *(int64_t **)0x180782430) {
                piVar10 = (int64_t *)0x0;
            }
            iVar17 = *piVar10;
            *(int64_t **)(iVar19 + 0x40) = piVar16;
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                iVar14 = *(int32_t *)(arg1 + 0x60) - (int32_t)arg1;
                iVar15 = iVar14 + -0x60;
                iVar8 = iVar15 * 2;
                if (iVar15 < 1) {
                    iVar8 = iVar14 + -0x5f;
                }
                func_0x000180093240(arg1, iVar8, 0);
            }
            uVar11 = *(int64_t *)(arg1 + 0x40) + 0x10;
            if (**(uint64_t **)(arg1 + 0x18) < uVar11) {
                **(uint64_t **)(arg1 + 0x18) = uVar11;
            }
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            piVar16 = *(int64_t **)(arg1 + 0x40);
            *piVar16 = iVar17;
            *(undefined4 *)((int64_t)piVar16 + 0xc) = 8;
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                iVar14 = *(int32_t *)(arg1 + 0x60) - (int32_t)arg1;
                iVar15 = iVar14 + -0x60;
                iVar8 = iVar15 * 2;
                if (iVar15 < 1) {
                    iVar8 = iVar14 + -0x5f;
                }
                func_0x000180093240(arg1, iVar8, 0);
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x000180087370(arg1, 0xfffffffe, 0x180622638);
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar8 = fcn.180085510(in_stack_fffffffffffffea0), iVar8 == 0)) break;
        pdVar1 = *(double **)(arg1 + 0x40);
        *(undefined4 *)((int64_t)pdVar1 + 0xc) = 3;
        *pdVar1 = (double)(int32_t)var_144h;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x000180087370(arg1, 0xfffffffe, 0x180622678);
        iVar17 = 0x1805aadb1;
        if (var_158h != 0) {
            iVar17 = var_158h;
        }
        uVar12 = func_0x000180498cd0(iVar17);
        func_0x0001800867f0(arg1, iVar17, uVar12);
        func_0x000180087370(arg1, 0xfffffffe, 0x18062266c);
        iVar17 = 0x1805aadb1;
        if (var_168h != 0) {
            iVar17 = var_168h;
        }
        uVar12 = func_0x000180498cd0(iVar17);
        func_0x0001800867f0(arg1, iVar17, uVar12);
        func_0x000180087370(arg1, 0xfffffffe, 0x180622694);
        iVar17 = *(int64_t *)(arg1 + 0x40);
        if (*(char *)(*(int64_t *)(iVar17 + -0x20) + 4) != '\0') {
            func_0x000180092f10(arg1);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        puVar13 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar17 + -0x20), iVar18);
        uVar4 = *(undefined4 *)(iVar17 + -0xc);
        uVar5 = *(undefined4 *)(iVar17 + -8);
        uVar6 = *(undefined4 *)(iVar17 + -4);
        *puVar13 = *(undefined4 *)(iVar17 + -0x10);
        puVar13[1] = uVar4;
        puVar13[2] = uVar5;
        puVar13[3] = uVar6;
        if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
            iVar17 = *(int64_t *)(iVar17 + -0x20);
            if (((*(uint8_t *)(iVar17 + 1) & 4) != 0) &&
               ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                iVar2 = *(int64_t *)(arg1 + 0x20);
                if (*(char *)(iVar2 + 0x59) == '\x02') {
                    func_0x000180094420();
                } else {
                    *(uint8_t *)(iVar17 + 1) = *(uint8_t *)(iVar17 + 1) & 0xfb;
                    *(undefined8 *)(iVar17 + 0x18) = *(undefined8 *)(iVar2 + 0x18);
                    *(int64_t *)(iVar2 + 0x18) = iVar17;
                }
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        iVar18 = iVar18 + 1;
        iVar8 = func_0x000180092a10(iVar19, iVar18, 0x180622740, &var_168h);
    }
    fcn.180099450(arg1, 0x18063d8d0);
    fcn.180087960(arg1);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_180036990
// Address: 0x180036990
// Size: 145 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180036990(int64_t arg1)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    char cVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t *piVar9;
    undefined4 *puVar10;
    int64_t *piVar11;
    int64_t iVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar9 = piVar11;
    if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if ((piVar9 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar9 + 0xc) != 10)) {
        iVar8 = 0;
        var_8h = 0;
        cVar5 = func_0x000180051370(arg1, &var_8h);
        iVar12 = arg1;
        if (cVar5 != '\0') {
            iVar12 = var_8h;
        }
    } else {
        if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar11 + 0xc) == 10) {
            iVar8 = 1;
            iVar12 = *piVar11;
        } else {
            iVar8 = 1;
            iVar12 = 0;
        }
    }
    iVar6 = func_0x000180085d50(arg1, iVar8 + 1);
    if (iVar6 == 0) {
        iVar6 = func_0x000180085e40(arg1, iVar8 + 1);
        if (iVar6 != 0) {
            iVar6 = func_0x0001800863e0(arg1, iVar8 + 1);
            if (iVar6 == 0x78) {
                puVar10 = (undefined4 *)func_0x000180086370(arg1, iVar8 + 1, 0x78);
                iVar8 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar10);
                if (iVar8 != 8) {
                    fcn.180088560(arg1, 0x1806224c8);
                    pcVar1 = (code *)swi(3);
                    (*pcVar1)();
                    return;
                }
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                piVar11 = *(int64_t **)(arg1 + 0x40);
                piVar9 = *(int64_t **)(arg1 + 0x28);
                if (piVar11 <= *(int64_t **)(arg1 + 0x28)) {
                    piVar9 = *(int64_t **)0x180782430;
                }
                uVar2 = *(undefined4 *)((int64_t)piVar11 + -0xc);
                uVar3 = *(undefined4 *)(piVar11 + -1);
                uVar4 = *(undefined4 *)((int64_t)piVar11 + -4);
                *(undefined4 *)piVar9 = *(undefined4 *)(piVar11 + -2);
                *(undefined4 *)((int64_t)piVar9 + 4) = uVar2;
                *(undefined4 *)(piVar9 + 1) = uVar3;
                *(undefined4 *)((int64_t)piVar9 + 0xc) = uVar4;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            }
        }
    } else {
        iVar6 = func_0x000180085f50(arg1, iVar8 + 1, 0);
        iVar7 = func_0x000180033c60(iVar12, iVar6);
        if (iVar6 != iVar7) {
            func_0x0001800865e0(arg1, iVar7);
            func_0x000180085a50(arg1, iVar8 + 1);
        }
        if ((iVar12 != arg1) && (iVar8 == 0)) {
            func_0x000180085610(arg1, 1);
            func_0x000180051290(arg1, iVar12);
            func_0x0001800859a0(arg1, 1);
        }
    }
    // WARNING: Could not recover jumptable at 0x000180036b1c. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x180782100)(arg1);
    return;
}

