// Chunk 86 - 50 functions

// ============================================================
// Function: FUN_18011fd1f
// Address: 0x18011fd1f
// Size: 17 bytes
// ============================================================
undefined4 fcn.18011fd1f(int64_t arg_50h)
{
    undefined4 unaff_ESI;
    undefined4 unaff_EDI;
    
    *(undefined4 *)arg_50h = unaff_ESI;
    return unaff_EDI;
}

// ============================================================
// Function: FUN_18011fd30
// Address: 0x18011fd30
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18011fd30(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int32_t iVar2;
    uint8_t uVar3;
    int32_t iVar4;
    uint8_t uVar5;
    int64_t iVar6;
    int32_t iVar7;
    uint32_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    
    iVar1 = *(int32_t *)(arg2 + 8);
    iVar2 = *(int32_t *)(arg2 + 0xc);
    uVar8 = 0;
    iVar7 = 2;
    iVar4 = iVar1;
    do {
        if (iVar4 < iVar2) {
            iVar6 = (int64_t)iVar4;
            iVar4 = iVar4 + 1;
            uVar5 = *(uint8_t *)(iVar6 + *(int64_t *)arg2);
            *(int32_t *)(arg2 + 8) = iVar4;
        } else {
            uVar5 = 0;
        }
        uVar8 = uVar8 << 8 | (uint32_t)uVar5;
        iVar7 = iVar7 + -1;
    } while (iVar7 != 0);
    if (uVar8 != 0) {
        if (iVar4 < iVar2) {
            iVar6 = (int64_t)iVar4;
            iVar4 = iVar4 + 1;
            uVar5 = *(uint8_t *)(iVar6 + *(int64_t *)arg2);
        } else {
            uVar5 = 0;
        }
        iVar4 = uVar8 * uVar5 + iVar4;
        if ((iVar2 < iVar4) || (iVar4 < 0)) {
            iVar4 = iVar2;
        }
        uVar8 = 0;
        *(int32_t *)(arg2 + 8) = iVar4;
        if (uVar5 != 0) {
            iVar7 = 0;
            do {
                if (iVar4 < iVar2) {
                    iVar6 = (int64_t)iVar4;
                    iVar4 = iVar4 + 1;
                    uVar3 = *(uint8_t *)(iVar6 + *(int64_t *)arg2);
                    *(int32_t *)(arg2 + 8) = iVar4;
                } else {
                    uVar3 = 0;
                }
                iVar7 = iVar7 + 1;
                uVar8 = uVar8 << 8 | (uint32_t)uVar3;
            } while (iVar7 < (int32_t)(uint32_t)uVar5);
        }
        iVar4 = (uVar8 - 1) + iVar4;
        if ((iVar2 < iVar4) || (iVar4 < 0)) {
            iVar4 = iVar2;
        }
        *(int32_t *)(arg2 + 8) = iVar4;
    }
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    if ((((-1 < iVar1) && (iVar4 = iVar4 - iVar1, -1 < iVar4)) && (iVar1 <= *(int32_t *)(arg2 + 0xc))) &&
       (iVar4 <= *(int32_t *)(arg2 + 0xc) - iVar1)) {
        *(int64_t *)arg1 = (int64_t)iVar1 + *(int64_t *)arg2;
        *(int32_t *)(arg1 + 0xc) = iVar4;
    }
    return arg1;
}

// ============================================================
// Function: FUN_18011fd3f
// Address: 0x18011fd3f
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18011fd30(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int32_t iVar2;
    uint8_t uVar3;
    int32_t iVar4;
    uint8_t uVar5;
    int64_t iVar6;
    int32_t iVar7;
    uint32_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    
    iVar1 = *(int32_t *)(arg2 + 8);
    iVar2 = *(int32_t *)(arg2 + 0xc);
    uVar8 = 0;
    iVar7 = 2;
    iVar4 = iVar1;
    do {
        if (iVar4 < iVar2) {
            iVar6 = (int64_t)iVar4;
            iVar4 = iVar4 + 1;
            uVar5 = *(uint8_t *)(iVar6 + *(int64_t *)arg2);
            *(int32_t *)(arg2 + 8) = iVar4;
        } else {
            uVar5 = 0;
        }
        uVar8 = uVar8 << 8 | (uint32_t)uVar5;
        iVar7 = iVar7 + -1;
    } while (iVar7 != 0);
    if (uVar8 != 0) {
        if (iVar4 < iVar2) {
            iVar6 = (int64_t)iVar4;
            iVar4 = iVar4 + 1;
            uVar5 = *(uint8_t *)(iVar6 + *(int64_t *)arg2);
        } else {
            uVar5 = 0;
        }
        iVar4 = uVar8 * uVar5 + iVar4;
        if ((iVar2 < iVar4) || (iVar4 < 0)) {
            iVar4 = iVar2;
        }
        uVar8 = 0;
        *(int32_t *)(arg2 + 8) = iVar4;
        if (uVar5 != 0) {
            iVar7 = 0;
            do {
                if (iVar4 < iVar2) {
                    iVar6 = (int64_t)iVar4;
                    iVar4 = iVar4 + 1;
                    uVar3 = *(uint8_t *)(iVar6 + *(int64_t *)arg2);
                    *(int32_t *)(arg2 + 8) = iVar4;
                } else {
                    uVar3 = 0;
                }
                iVar7 = iVar7 + 1;
                uVar8 = uVar8 << 8 | (uint32_t)uVar3;
            } while (iVar7 < (int32_t)(uint32_t)uVar5);
        }
        iVar4 = (uVar8 - 1) + iVar4;
        if ((iVar2 < iVar4) || (iVar4 < 0)) {
            iVar4 = iVar2;
        }
        *(int32_t *)(arg2 + 8) = iVar4;
    }
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    if ((((-1 < iVar1) && (iVar4 = iVar4 - iVar1, -1 < iVar4)) && (iVar1 <= *(int32_t *)(arg2 + 0xc))) &&
       (iVar4 <= *(int32_t *)(arg2 + 0xc) - iVar1)) {
        *(int64_t *)arg1 = (int64_t)iVar1 + *(int64_t *)arg2;
        *(int32_t *)(arg1 + 0xc) = iVar4;
    }
    return arg1;
}

// ============================================================
// Function: FUN_18011fd81
// Address: 0x18011fd81
// Size: 120 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18011fd30(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int32_t iVar2;
    uint8_t uVar3;
    int32_t iVar4;
    uint8_t uVar5;
    int64_t iVar6;
    int32_t iVar7;
    uint32_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    
    iVar1 = *(int32_t *)(arg2 + 8);
    iVar2 = *(int32_t *)(arg2 + 0xc);
    uVar8 = 0;
    iVar7 = 2;
    iVar4 = iVar1;
    do {
        if (iVar4 < iVar2) {
            iVar6 = (int64_t)iVar4;
            iVar4 = iVar4 + 1;
            uVar5 = *(uint8_t *)(iVar6 + *(int64_t *)arg2);
            *(int32_t *)(arg2 + 8) = iVar4;
        } else {
            uVar5 = 0;
        }
        uVar8 = uVar8 << 8 | (uint32_t)uVar5;
        iVar7 = iVar7 + -1;
    } while (iVar7 != 0);
    if (uVar8 != 0) {
        if (iVar4 < iVar2) {
            iVar6 = (int64_t)iVar4;
            iVar4 = iVar4 + 1;
            uVar5 = *(uint8_t *)(iVar6 + *(int64_t *)arg2);
        } else {
            uVar5 = 0;
        }
        iVar4 = uVar8 * uVar5 + iVar4;
        if ((iVar2 < iVar4) || (iVar4 < 0)) {
            iVar4 = iVar2;
        }
        uVar8 = 0;
        *(int32_t *)(arg2 + 8) = iVar4;
        if (uVar5 != 0) {
            iVar7 = 0;
            do {
                if (iVar4 < iVar2) {
                    iVar6 = (int64_t)iVar4;
                    iVar4 = iVar4 + 1;
                    uVar3 = *(uint8_t *)(iVar6 + *(int64_t *)arg2);
                    *(int32_t *)(arg2 + 8) = iVar4;
                } else {
                    uVar3 = 0;
                }
                iVar7 = iVar7 + 1;
                uVar8 = uVar8 << 8 | (uint32_t)uVar3;
            } while (iVar7 < (int32_t)(uint32_t)uVar5);
        }
        iVar4 = (uVar8 - 1) + iVar4;
        if ((iVar2 < iVar4) || (iVar4 < 0)) {
            iVar4 = iVar2;
        }
        *(int32_t *)(arg2 + 8) = iVar4;
    }
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    if ((((-1 < iVar1) && (iVar4 = iVar4 - iVar1, -1 < iVar4)) && (iVar1 <= *(int32_t *)(arg2 + 0xc))) &&
       (iVar4 <= *(int32_t *)(arg2 + 0xc) - iVar1)) {
        *(int64_t *)arg1 = (int64_t)iVar1 + *(int64_t *)arg2;
        *(int32_t *)(arg1 + 0xc) = iVar4;
    }
    return arg1;
}

// ============================================================
// Function: FUN_18011fdf9
// Address: 0x18011fdf9
// Size: 35 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18011fd30(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int32_t iVar2;
    uint8_t uVar3;
    int32_t iVar4;
    uint8_t uVar5;
    int64_t iVar6;
    int32_t iVar7;
    uint32_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    
    iVar1 = *(int32_t *)(arg2 + 8);
    iVar2 = *(int32_t *)(arg2 + 0xc);
    uVar8 = 0;
    iVar7 = 2;
    iVar4 = iVar1;
    do {
        if (iVar4 < iVar2) {
            iVar6 = (int64_t)iVar4;
            iVar4 = iVar4 + 1;
            uVar5 = *(uint8_t *)(iVar6 + *(int64_t *)arg2);
            *(int32_t *)(arg2 + 8) = iVar4;
        } else {
            uVar5 = 0;
        }
        uVar8 = uVar8 << 8 | (uint32_t)uVar5;
        iVar7 = iVar7 + -1;
    } while (iVar7 != 0);
    if (uVar8 != 0) {
        if (iVar4 < iVar2) {
            iVar6 = (int64_t)iVar4;
            iVar4 = iVar4 + 1;
            uVar5 = *(uint8_t *)(iVar6 + *(int64_t *)arg2);
        } else {
            uVar5 = 0;
        }
        iVar4 = uVar8 * uVar5 + iVar4;
        if ((iVar2 < iVar4) || (iVar4 < 0)) {
            iVar4 = iVar2;
        }
        uVar8 = 0;
        *(int32_t *)(arg2 + 8) = iVar4;
        if (uVar5 != 0) {
            iVar7 = 0;
            do {
                if (iVar4 < iVar2) {
                    iVar6 = (int64_t)iVar4;
                    iVar4 = iVar4 + 1;
                    uVar3 = *(uint8_t *)(iVar6 + *(int64_t *)arg2);
                    *(int32_t *)(arg2 + 8) = iVar4;
                } else {
                    uVar3 = 0;
                }
                iVar7 = iVar7 + 1;
                uVar8 = uVar8 << 8 | (uint32_t)uVar3;
            } while (iVar7 < (int32_t)(uint32_t)uVar5);
        }
        iVar4 = (uVar8 - 1) + iVar4;
        if ((iVar2 < iVar4) || (iVar4 < 0)) {
            iVar4 = iVar2;
        }
        *(int32_t *)(arg2 + 8) = iVar4;
    }
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    if ((((-1 < iVar1) && (iVar4 = iVar4 - iVar1, -1 < iVar4)) && (iVar1 <= *(int32_t *)(arg2 + 0xc))) &&
       (iVar4 <= *(int32_t *)(arg2 + 0xc) - iVar1)) {
        *(int64_t *)arg1 = (int64_t)iVar1 + *(int64_t *)arg2;
        *(int32_t *)(arg1 + 0xc) = iVar4;
    }
    return arg1;
}

// ============================================================
// Function: FUN_18011fe1c
// Address: 0x18011fe1c
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18011fd30(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int32_t iVar2;
    uint8_t uVar3;
    int32_t iVar4;
    uint8_t uVar5;
    int64_t iVar6;
    int32_t iVar7;
    uint32_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    
    iVar1 = *(int32_t *)(arg2 + 8);
    iVar2 = *(int32_t *)(arg2 + 0xc);
    uVar8 = 0;
    iVar7 = 2;
    iVar4 = iVar1;
    do {
        if (iVar4 < iVar2) {
            iVar6 = (int64_t)iVar4;
            iVar4 = iVar4 + 1;
            uVar5 = *(uint8_t *)(iVar6 + *(int64_t *)arg2);
            *(int32_t *)(arg2 + 8) = iVar4;
        } else {
            uVar5 = 0;
        }
        uVar8 = uVar8 << 8 | (uint32_t)uVar5;
        iVar7 = iVar7 + -1;
    } while (iVar7 != 0);
    if (uVar8 != 0) {
        if (iVar4 < iVar2) {
            iVar6 = (int64_t)iVar4;
            iVar4 = iVar4 + 1;
            uVar5 = *(uint8_t *)(iVar6 + *(int64_t *)arg2);
        } else {
            uVar5 = 0;
        }
        iVar4 = uVar8 * uVar5 + iVar4;
        if ((iVar2 < iVar4) || (iVar4 < 0)) {
            iVar4 = iVar2;
        }
        uVar8 = 0;
        *(int32_t *)(arg2 + 8) = iVar4;
        if (uVar5 != 0) {
            iVar7 = 0;
            do {
                if (iVar4 < iVar2) {
                    iVar6 = (int64_t)iVar4;
                    iVar4 = iVar4 + 1;
                    uVar3 = *(uint8_t *)(iVar6 + *(int64_t *)arg2);
                    *(int32_t *)(arg2 + 8) = iVar4;
                } else {
                    uVar3 = 0;
                }
                iVar7 = iVar7 + 1;
                uVar8 = uVar8 << 8 | (uint32_t)uVar3;
            } while (iVar7 < (int32_t)(uint32_t)uVar5);
        }
        iVar4 = (uVar8 - 1) + iVar4;
        if ((iVar2 < iVar4) || (iVar4 < 0)) {
            iVar4 = iVar2;
        }
        *(int32_t *)(arg2 + 8) = iVar4;
    }
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    if ((((-1 < iVar1) && (iVar4 = iVar4 - iVar1, -1 < iVar4)) && (iVar1 <= *(int32_t *)(arg2 + 0xc))) &&
       (iVar4 <= *(int32_t *)(arg2 + 0xc) - iVar1)) {
        *(int64_t *)arg1 = (int64_t)iVar1 + *(int64_t *)arg2;
        *(int32_t *)(arg1 + 0xc) = iVar4;
    }
    return arg1;
}

// ============================================================
// Function: FUN_180120020
// Address: 0x180120020
// Size: 352 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_30h

void fcn.180120020(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int32_t iVar1;
    int64_t iVar2;
    uint8_t uVar3;
    uint32_t uVar4;
    undefined4 uVar5;
    int64_t iVar6;
    int32_t iVar7;
    uint64_t uVar8;
    int32_t iVar9;
    int64_t var_38h;
    int32_t var_30h;
    int64_t var_2ch;
    
    iVar1 = *(int32_t *)(arg1 + 0xc);
    iVar9 = 0;
    if (iVar1 < 0) {
        iVar9 = iVar1;
    }
    *(int32_t *)(arg1 + 8) = iVar9;
    if (iVar1 <= iVar9) {
code_r0x00018012010b:
        var_38h = 0;
        if (-1 < *(int32_t *)(arg1 + 0xc)) {
            var_38h = *(int64_t *)arg1;
        }
        var_2ch._0_4_ = 0;
code_r0x000180120117:
        uVar8 = 0;
        var_30h = 0;
        if (0 < (int32_t)arg3) {
            do {
                if ((int32_t)var_2ch <= var_30h) {
                    return;
                }
                uVar5 = func_0x00018011fe40(&var_38h);
                *(undefined4 *)(arg4 + uVar8 * 4) = uVar5;
                uVar4 = (int32_t)uVar8 + 1;
                uVar8 = (uint64_t)uVar4;
            } while ((int32_t)uVar4 < (int32_t)arg3);
        }
        return;
    }
code_r0x000180120050:
    do {
        var_2ch._0_4_ = *(int32_t *)(arg1 + 8);
        iVar1 = *(int32_t *)(arg1 + 0xc);
        if ((int32_t)var_2ch < iVar1) {
            iVar2 = *(int64_t *)arg1;
            uVar3 = *(uint8_t *)(iVar2 + (int32_t)var_2ch);
            if (0x1b < uVar3) {
                if (uVar3 == 0x1e) {
                    var_2ch._0_4_ = (int32_t)var_2ch + 1;
                    if ((iVar1 < (int32_t)var_2ch) || ((int32_t)var_2ch < 0)) {
                        *(int32_t *)(arg1 + 8) = iVar1;
                    } else {
                        *(int32_t *)(arg1 + 8) = (int32_t)var_2ch;
                        iVar7 = (int32_t)var_2ch;
                        while ((int32_t)var_2ch < iVar1) {
                            if (iVar7 < iVar1) {
                                iVar6 = (int64_t)(int32_t)var_2ch;
                                var_2ch._0_4_ = iVar7 + 1;
                                uVar3 = *(uint8_t *)(iVar6 + iVar2);
                                *(int32_t *)(arg1 + 8) = (int32_t)var_2ch;
                                if (((uVar3 & 0xf) == 0xf) || (iVar7 = (int32_t)var_2ch, (uVar3 & 0xf0) == 0xf0)) break;
                            }
                        }
                    }
                } else {
                    func_0x00018011fe40(arg1);
                }
                goto code_r0x000180120050;
            }
            iVar7 = (int32_t)var_2ch + 1;
            *(int32_t *)(arg1 + 8) = iVar7;
            if (uVar3 != 0xc) goto code_r0x0001801200f9;
            if (iVar7 < iVar1) {
                iVar6 = (int64_t)iVar7;
                iVar7 = (int32_t)var_2ch + 2;
                uVar4 = *(uint8_t *)(iVar6 + iVar2) | 0x100;
                *(int32_t *)(arg1 + 8) = iVar7;
            } else {
                uVar4 = 0x100;
            }
        } else {
            uVar3 = 0;
            iVar7 = (int32_t)var_2ch;
code_r0x0001801200f9:
            uVar4 = (uint32_t)uVar3;
        }
        if (uVar4 == (uint32_t)arg2) {
            if ((((iVar9 < 0) || (var_2ch._0_4_ = (int32_t)var_2ch - iVar9, (int32_t)var_2ch < 0)) || (iVar1 < iVar9))
               || (iVar1 - iVar9 < (int32_t)var_2ch)) {
                var_2ch._0_4_ = 0;
                var_38h = 0;
            } else {
                var_38h = (int64_t)iVar9 + *(int64_t *)arg1;
            }
            goto code_r0x000180120117;
        }
        iVar9 = iVar7;
        if (iVar1 <= iVar7) goto code_r0x00018012010b;
    } while( true );
}

// ============================================================
// Function: FUN_180120180
// Address: 0x180120180
// Size: 12 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180120180(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h)
{
    int32_t iVar1;
    uint8_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int32_t iVar10;
    uint32_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int32_t *)(arg2 + 0xc);
    iVar8 = 0;
    if (iVar1 < 0) {
        iVar8 = iVar1;
    }
    if (iVar8 < iVar1) {
        iVar5 = *(int64_t *)arg2;
        iVar10 = iVar8 + 1;
        if (iVar10 < iVar1) {
            iVar3 = iVar8 + 2;
            uVar7 = (uint32_t)CONCAT11(*(uint8_t *)(iVar8 + iVar5), *(undefined *)(iVar10 + iVar5));
            if (iVar3 < iVar1) {
                iVar4 = (int64_t)iVar3;
                iVar3 = iVar8 + 3;
                uVar2 = *(uint8_t *)(iVar4 + iVar5);
            } else {
                uVar2 = 0;
            }
        } else {
            uVar7 = (uint32_t)*(uint8_t *)(iVar8 + iVar5) << 8;
            uVar2 = 0;
            iVar3 = iVar10;
        }
    } else {
        uVar7 = 0;
        uVar2 = 0;
        iVar3 = iVar8;
    }
    uVar6 = (uint32_t)uVar2;
    iVar3 = uVar6 * (int32_t)placeholder_2 + iVar3;
    if ((iVar1 < iVar3) || (iVar3 < 0)) {
        iVar3 = iVar1;
    }
    uVar11 = 0;
    *(int32_t *)(arg2 + 8) = iVar3;
    uVar9 = 0;
    if (uVar2 != 0) {
        do {
            if (iVar3 < iVar1) {
                iVar5 = (int64_t)iVar3;
                iVar3 = iVar3 + 1;
                *(int32_t *)(arg2 + 8) = iVar3;
                uVar2 = *(uint8_t *)(iVar5 + *(int64_t *)arg2);
            } else {
                uVar2 = 0;
            }
            uVar9 = uVar9 + 1;
            uVar11 = uVar11 << 8 | (uint32_t)uVar2;
        } while ((int32_t)uVar9 < (int32_t)uVar6);
        uVar9 = 0;
        iVar8 = 0;
        do {
            if (iVar3 < iVar1) {
                iVar5 = (int64_t)iVar3;
                iVar3 = iVar3 + 1;
                *(int32_t *)(arg2 + 8) = iVar3;
                uVar2 = *(uint8_t *)(iVar5 + *(int64_t *)arg2);
            } else {
                uVar2 = 0;
            }
            iVar8 = iVar8 + 1;
            uVar9 = uVar9 << 8 | (uint32_t)uVar2;
        } while (iVar8 < (int32_t)uVar6);
    }
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    iVar8 = uVar11 + 2 + (uVar7 + 1) * uVar6;
    if ((((-1 < iVar8) && (iVar10 = uVar9 - uVar11, -1 < iVar10)) && (iVar8 <= iVar1)) && (iVar10 <= iVar1 - iVar8)) {
        *(int64_t *)arg1 = (int64_t)iVar8 + *(int64_t *)arg2;
        *(int32_t *)(arg1 + 0xc) = iVar10;
    }
    return arg1;
}

// ============================================================
// Function: FUN_18012018c
// Address: 0x18012018c
// Size: 136 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180120180(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h)
{
    int32_t iVar1;
    uint8_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int32_t iVar10;
    uint32_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int32_t *)(arg2 + 0xc);
    iVar8 = 0;
    if (iVar1 < 0) {
        iVar8 = iVar1;
    }
    if (iVar8 < iVar1) {
        iVar5 = *(int64_t *)arg2;
        iVar10 = iVar8 + 1;
        if (iVar10 < iVar1) {
            iVar3 = iVar8 + 2;
            uVar7 = (uint32_t)CONCAT11(*(uint8_t *)(iVar8 + iVar5), *(undefined *)(iVar10 + iVar5));
            if (iVar3 < iVar1) {
                iVar4 = (int64_t)iVar3;
                iVar3 = iVar8 + 3;
                uVar2 = *(uint8_t *)(iVar4 + iVar5);
            } else {
                uVar2 = 0;
            }
        } else {
            uVar7 = (uint32_t)*(uint8_t *)(iVar8 + iVar5) << 8;
            uVar2 = 0;
            iVar3 = iVar10;
        }
    } else {
        uVar7 = 0;
        uVar2 = 0;
        iVar3 = iVar8;
    }
    uVar6 = (uint32_t)uVar2;
    iVar3 = uVar6 * (int32_t)placeholder_2 + iVar3;
    if ((iVar1 < iVar3) || (iVar3 < 0)) {
        iVar3 = iVar1;
    }
    uVar11 = 0;
    *(int32_t *)(arg2 + 8) = iVar3;
    uVar9 = 0;
    if (uVar2 != 0) {
        do {
            if (iVar3 < iVar1) {
                iVar5 = (int64_t)iVar3;
                iVar3 = iVar3 + 1;
                *(int32_t *)(arg2 + 8) = iVar3;
                uVar2 = *(uint8_t *)(iVar5 + *(int64_t *)arg2);
            } else {
                uVar2 = 0;
            }
            uVar9 = uVar9 + 1;
            uVar11 = uVar11 << 8 | (uint32_t)uVar2;
        } while ((int32_t)uVar9 < (int32_t)uVar6);
        uVar9 = 0;
        iVar8 = 0;
        do {
            if (iVar3 < iVar1) {
                iVar5 = (int64_t)iVar3;
                iVar3 = iVar3 + 1;
                *(int32_t *)(arg2 + 8) = iVar3;
                uVar2 = *(uint8_t *)(iVar5 + *(int64_t *)arg2);
            } else {
                uVar2 = 0;
            }
            iVar8 = iVar8 + 1;
            uVar9 = uVar9 << 8 | (uint32_t)uVar2;
        } while (iVar8 < (int32_t)uVar6);
    }
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    iVar8 = uVar11 + 2 + (uVar7 + 1) * uVar6;
    if ((((-1 < iVar8) && (iVar10 = uVar9 - uVar11, -1 < iVar10)) && (iVar8 <= iVar1)) && (iVar10 <= iVar1 - iVar8)) {
        *(int64_t *)arg1 = (int64_t)iVar8 + *(int64_t *)arg2;
        *(int32_t *)(arg1 + 0xc) = iVar10;
    }
    return arg1;
}

// ============================================================
// Function: FUN_180120214
// Address: 0x180120214
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180120180(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h)
{
    int32_t iVar1;
    uint8_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int32_t iVar10;
    uint32_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int32_t *)(arg2 + 0xc);
    iVar8 = 0;
    if (iVar1 < 0) {
        iVar8 = iVar1;
    }
    if (iVar8 < iVar1) {
        iVar5 = *(int64_t *)arg2;
        iVar10 = iVar8 + 1;
        if (iVar10 < iVar1) {
            iVar3 = iVar8 + 2;
            uVar7 = (uint32_t)CONCAT11(*(uint8_t *)(iVar8 + iVar5), *(undefined *)(iVar10 + iVar5));
            if (iVar3 < iVar1) {
                iVar4 = (int64_t)iVar3;
                iVar3 = iVar8 + 3;
                uVar2 = *(uint8_t *)(iVar4 + iVar5);
            } else {
                uVar2 = 0;
            }
        } else {
            uVar7 = (uint32_t)*(uint8_t *)(iVar8 + iVar5) << 8;
            uVar2 = 0;
            iVar3 = iVar10;
        }
    } else {
        uVar7 = 0;
        uVar2 = 0;
        iVar3 = iVar8;
    }
    uVar6 = (uint32_t)uVar2;
    iVar3 = uVar6 * (int32_t)placeholder_2 + iVar3;
    if ((iVar1 < iVar3) || (iVar3 < 0)) {
        iVar3 = iVar1;
    }
    uVar11 = 0;
    *(int32_t *)(arg2 + 8) = iVar3;
    uVar9 = 0;
    if (uVar2 != 0) {
        do {
            if (iVar3 < iVar1) {
                iVar5 = (int64_t)iVar3;
                iVar3 = iVar3 + 1;
                *(int32_t *)(arg2 + 8) = iVar3;
                uVar2 = *(uint8_t *)(iVar5 + *(int64_t *)arg2);
            } else {
                uVar2 = 0;
            }
            uVar9 = uVar9 + 1;
            uVar11 = uVar11 << 8 | (uint32_t)uVar2;
        } while ((int32_t)uVar9 < (int32_t)uVar6);
        uVar9 = 0;
        iVar8 = 0;
        do {
            if (iVar3 < iVar1) {
                iVar5 = (int64_t)iVar3;
                iVar3 = iVar3 + 1;
                *(int32_t *)(arg2 + 8) = iVar3;
                uVar2 = *(uint8_t *)(iVar5 + *(int64_t *)arg2);
            } else {
                uVar2 = 0;
            }
            iVar8 = iVar8 + 1;
            uVar9 = uVar9 << 8 | (uint32_t)uVar2;
        } while (iVar8 < (int32_t)uVar6);
    }
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    iVar8 = uVar11 + 2 + (uVar7 + 1) * uVar6;
    if ((((-1 < iVar8) && (iVar10 = uVar9 - uVar11, -1 < iVar10)) && (iVar8 <= iVar1)) && (iVar10 <= iVar1 - iVar8)) {
        *(int64_t *)arg1 = (int64_t)iVar8 + *(int64_t *)arg2;
        *(int32_t *)(arg1 + 0xc) = iVar10;
    }
    return arg1;
}

// ============================================================
// Function: FUN_18012027e
// Address: 0x18012027e
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180120180(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h)
{
    int32_t iVar1;
    uint8_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int32_t iVar10;
    uint32_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int32_t *)(arg2 + 0xc);
    iVar8 = 0;
    if (iVar1 < 0) {
        iVar8 = iVar1;
    }
    if (iVar8 < iVar1) {
        iVar5 = *(int64_t *)arg2;
        iVar10 = iVar8 + 1;
        if (iVar10 < iVar1) {
            iVar3 = iVar8 + 2;
            uVar7 = (uint32_t)CONCAT11(*(uint8_t *)(iVar8 + iVar5), *(undefined *)(iVar10 + iVar5));
            if (iVar3 < iVar1) {
                iVar4 = (int64_t)iVar3;
                iVar3 = iVar8 + 3;
                uVar2 = *(uint8_t *)(iVar4 + iVar5);
            } else {
                uVar2 = 0;
            }
        } else {
            uVar7 = (uint32_t)*(uint8_t *)(iVar8 + iVar5) << 8;
            uVar2 = 0;
            iVar3 = iVar10;
        }
    } else {
        uVar7 = 0;
        uVar2 = 0;
        iVar3 = iVar8;
    }
    uVar6 = (uint32_t)uVar2;
    iVar3 = uVar6 * (int32_t)placeholder_2 + iVar3;
    if ((iVar1 < iVar3) || (iVar3 < 0)) {
        iVar3 = iVar1;
    }
    uVar11 = 0;
    *(int32_t *)(arg2 + 8) = iVar3;
    uVar9 = 0;
    if (uVar2 != 0) {
        do {
            if (iVar3 < iVar1) {
                iVar5 = (int64_t)iVar3;
                iVar3 = iVar3 + 1;
                *(int32_t *)(arg2 + 8) = iVar3;
                uVar2 = *(uint8_t *)(iVar5 + *(int64_t *)arg2);
            } else {
                uVar2 = 0;
            }
            uVar9 = uVar9 + 1;
            uVar11 = uVar11 << 8 | (uint32_t)uVar2;
        } while ((int32_t)uVar9 < (int32_t)uVar6);
        uVar9 = 0;
        iVar8 = 0;
        do {
            if (iVar3 < iVar1) {
                iVar5 = (int64_t)iVar3;
                iVar3 = iVar3 + 1;
                *(int32_t *)(arg2 + 8) = iVar3;
                uVar2 = *(uint8_t *)(iVar5 + *(int64_t *)arg2);
            } else {
                uVar2 = 0;
            }
            iVar8 = iVar8 + 1;
            uVar9 = uVar9 << 8 | (uint32_t)uVar2;
        } while (iVar8 < (int32_t)uVar6);
    }
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    iVar8 = uVar11 + 2 + (uVar7 + 1) * uVar6;
    if ((((-1 < iVar8) && (iVar10 = uVar9 - uVar11, -1 < iVar10)) && (iVar8 <= iVar1)) && (iVar10 <= iVar1 - iVar8)) {
        *(int64_t *)arg1 = (int64_t)iVar8 + *(int64_t *)arg2;
        *(int32_t *)(arg1 + 0xc) = iVar10;
    }
    return arg1;
}

// ============================================================
// Function: FUN_1801202a5
// Address: 0x1801202a5
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180120180(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h)
{
    int32_t iVar1;
    uint8_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int32_t iVar10;
    uint32_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int32_t *)(arg2 + 0xc);
    iVar8 = 0;
    if (iVar1 < 0) {
        iVar8 = iVar1;
    }
    if (iVar8 < iVar1) {
        iVar5 = *(int64_t *)arg2;
        iVar10 = iVar8 + 1;
        if (iVar10 < iVar1) {
            iVar3 = iVar8 + 2;
            uVar7 = (uint32_t)CONCAT11(*(uint8_t *)(iVar8 + iVar5), *(undefined *)(iVar10 + iVar5));
            if (iVar3 < iVar1) {
                iVar4 = (int64_t)iVar3;
                iVar3 = iVar8 + 3;
                uVar2 = *(uint8_t *)(iVar4 + iVar5);
            } else {
                uVar2 = 0;
            }
        } else {
            uVar7 = (uint32_t)*(uint8_t *)(iVar8 + iVar5) << 8;
            uVar2 = 0;
            iVar3 = iVar10;
        }
    } else {
        uVar7 = 0;
        uVar2 = 0;
        iVar3 = iVar8;
    }
    uVar6 = (uint32_t)uVar2;
    iVar3 = uVar6 * (int32_t)placeholder_2 + iVar3;
    if ((iVar1 < iVar3) || (iVar3 < 0)) {
        iVar3 = iVar1;
    }
    uVar11 = 0;
    *(int32_t *)(arg2 + 8) = iVar3;
    uVar9 = 0;
    if (uVar2 != 0) {
        do {
            if (iVar3 < iVar1) {
                iVar5 = (int64_t)iVar3;
                iVar3 = iVar3 + 1;
                *(int32_t *)(arg2 + 8) = iVar3;
                uVar2 = *(uint8_t *)(iVar5 + *(int64_t *)arg2);
            } else {
                uVar2 = 0;
            }
            uVar9 = uVar9 + 1;
            uVar11 = uVar11 << 8 | (uint32_t)uVar2;
        } while ((int32_t)uVar9 < (int32_t)uVar6);
        uVar9 = 0;
        iVar8 = 0;
        do {
            if (iVar3 < iVar1) {
                iVar5 = (int64_t)iVar3;
                iVar3 = iVar3 + 1;
                *(int32_t *)(arg2 + 8) = iVar3;
                uVar2 = *(uint8_t *)(iVar5 + *(int64_t *)arg2);
            } else {
                uVar2 = 0;
            }
            iVar8 = iVar8 + 1;
            uVar9 = uVar9 << 8 | (uint32_t)uVar2;
        } while (iVar8 < (int32_t)uVar6);
    }
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    iVar8 = uVar11 + 2 + (uVar7 + 1) * uVar6;
    if ((((-1 < iVar8) && (iVar10 = uVar9 - uVar11, -1 < iVar10)) && (iVar8 <= iVar1)) && (iVar10 <= iVar1 - iVar8)) {
        *(int64_t *)arg1 = (int64_t)iVar8 + *(int64_t *)arg2;
        *(int32_t *)(arg1 + 0xc) = iVar10;
    }
    return arg1;
}

// ============================================================
// Function: FUN_1801202d0
// Address: 0x1801202d0
// Size: 170 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int32_t fcn.1801202d0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t *puVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar3 = (uint32_t)*(uint8_t *)((arg2 & 0xffffffffU) + 4 + arg1) * 0x100 +
            (uint32_t)*(uint8_t *)((arg2 & 0xffffffffU) + 5 + arg1);
    if (iVar3 != 0) {
        iVar2 = 0;
        do {
            puVar1 = (uint8_t *)((uint64_t)(uint32_t)(iVar2 * 0x10 + (int32_t)arg2 + 0xc) + arg1);
            if (((((uint32_t)*puVar1 == (int32_t)*(char *)arg3) && ((uint32_t)puVar1[1] == (int32_t)*(char *)(arg3 + 1))
                 ) && ((uint32_t)puVar1[2] == (int32_t)*(char *)(arg3 + 2))) &&
               ((uint32_t)puVar1[3] == (int32_t)*(char *)(arg3 + 3))) {
                return (uint32_t)puVar1[9] * 0x10000 + (uint32_t)puVar1[10] * 0x100 + (uint32_t)puVar1[8] * 0x1000000 +
                       (uint32_t)puVar1[0xb];
            }
            iVar2 = iVar2 + 1;
        } while (iVar2 < iVar3);
    }
    return 0;
}

// ============================================================
// Function: FUN_180120380
// Address: 0x180120380
// Size: 931 bytes
// ============================================================
uint32_t fcn.180120380(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int16_t iVar8;
    uint32_t uVar9;
    int32_t iVar10;
    int32_t iVar11;
    int32_t iVar12;
    uint16_t uVar13;
    uint16_t uVar14;
    int64_t var_eh;
    
    iVar1 = *(int64_t *)(arg1 + 8);
    uVar7 = (uint64_t)*(uint32_t *)(arg1 + 0x38);
    uVar4 = (uint32_t)arg2;
    iVar8 = (uint16_t)*(uint8_t *)(iVar1 + uVar7) * 0x100 + (uint16_t)*(uint8_t *)(iVar1 + 1 + uVar7);
    if (iVar8 == 0) {
        if ((int32_t)uVar4 <
            (int32_t)((uint32_t)*(uint8_t *)(iVar1 + 2 + uVar7) * 0x100 + (*(uint8_t *)(iVar1 + 3 + uVar7) - 6))) {
            return (uint32_t)*(uint8_t *)((int64_t)(int32_t)uVar4 + uVar7 + 6 + iVar1);
        }
    } else if (iVar8 == 6) {
        uVar5 = (uint32_t)*(uint8_t *)(iVar1 + 6 + uVar7) * 0x100 + (uint32_t)*(uint8_t *)(iVar1 + 7 + uVar7);
        if ((uVar5 <= uVar4) &&
           (uVar4 < (uint32_t)*(uint8_t *)(iVar1 + 9 + uVar7) +
                    (uint32_t)*(uint8_t *)(iVar1 + 8 + uVar7) * 0x100 + uVar5)) {
            iVar3 = (uVar4 - uVar5) * 2 + uVar7;
            return (uint32_t)*(uint8_t *)(iVar3 + 0xb + iVar1) + (uint32_t)*(uint8_t *)(iVar3 + 10 + iVar1) * 0x100;
        }
    } else if (iVar8 != 2) {
        if (iVar8 == 4) {
            uVar14 = (uint16_t)
                     ((uint16_t)*(uint8_t *)(iVar1 + 6 + uVar7) * 0x100 + (uint16_t)*(uint8_t *)(iVar1 + 7 + uVar7)) >>
                     1;
            iVar8 = (uint16_t)*(uint8_t *)(iVar1 + 10 + uVar7) * 0x100 + (uint16_t)*(uint8_t *)(iVar1 + 0xb + uVar7);
            uVar13 = (uint16_t)
                     ((uint16_t)*(uint8_t *)(iVar1 + 8 + uVar7) * 0x100 + (uint16_t)*(uint8_t *)(iVar1 + 9 + uVar7)) >>
                     1;
            if ((int32_t)uVar4 < 0x10000) {
                uVar9 = *(uint32_t *)(arg1 + 0x38) + 0xe;
                uVar5 = (uint32_t)*(uint8_t *)(iVar1 + 0xd + uVar7) +
                        (uint32_t)*(uint8_t *)(iVar1 + 0xc + uVar7) * 0x100 & 0xfffffffe;
                iVar3 = (uint64_t)uVar5 + (uint64_t)uVar9;
                uVar5 = uVar5 + uVar9;
                if ((int32_t)uVar4 <
                    (int32_t)((uint32_t)*(uint8_t *)(iVar3 + 1 + iVar1) + (uint32_t)*(uint8_t *)(iVar3 + iVar1) * 0x100)
                   ) {
                    uVar5 = uVar9;
                }
                uVar5 = uVar5 - 2;
                for (; iVar8 != 0; iVar8 = iVar8 + -1) {
                    uVar13 = uVar13 >> 1;
                    iVar3 = (uint64_t)((uint32_t)uVar13 + (uint32_t)uVar13) + (uint64_t)uVar5;
                    uVar2 = (uint32_t)uVar13 + (uint32_t)uVar13 + uVar5;
                    if ((int32_t)uVar4 <=
                        (int32_t)((uint32_t)*(uint8_t *)(iVar3 + iVar1) * 0x100 +
                                 (uint32_t)*(uint8_t *)(iVar1 + 1 + iVar3))) {
                        uVar2 = uVar5;
                    }
                    uVar5 = uVar2;
                }
                iVar3 = (uint64_t)((uVar5 - uVar9) + 2 >> 1 & 0xffff) * 2;
                iVar6 = (uint64_t)((uint32_t)uVar14 + (uint32_t)uVar14) + iVar3 + uVar7;
                iVar10 = (uint32_t)*(uint8_t *)(iVar6 + 0x11 + iVar1) +
                         (uint32_t)*(uint8_t *)(iVar6 + 0x10 + iVar1) * 0x100;
                if ((iVar10 <= (int32_t)uVar4) &&
                   (iVar6 = (uint64_t)uVar9 + iVar3,
                   (int32_t)uVar4 <=
                   (int32_t)((uint32_t)*(uint8_t *)(iVar6 + 1 + iVar1) + (uint32_t)*(uint8_t *)(iVar6 + iVar1) * 0x100))
                   ) {
                    uVar5 = ((uint32_t)uVar14 + (uint32_t)uVar14 * 2) * 2;
                    iVar6 = (uint64_t)uVar5 + iVar3 + uVar7;
                    uVar13 = (uint16_t)*(uint8_t *)(iVar6 + 0x10 + iVar1) * 0x100 +
                             (uint16_t)*(uint8_t *)(iVar6 + 0x11 + iVar1);
                    if (uVar13 != 0) {
                        iVar3 = (uint64_t)uVar13 + (int64_t)(int32_t)((uVar4 - iVar10) * 2) + (uint64_t)uVar5 + iVar3 +
                                uVar7;
                        return (uint32_t)*(uint8_t *)(iVar3 + 0x11 + iVar1) +
                               (uint32_t)*(uint8_t *)(iVar3 + 0x10 + iVar1) * 0x100;
                    }
                    iVar3 = (uint64_t)((uint32_t)uVar14 * 4) + iVar3 + uVar7;
                    return (uint32_t)
                           (uint16_t)
                           ((uint16_t)*(uint8_t *)(iVar3 + 0x11 + iVar1) +
                            (uint16_t)*(uint8_t *)(iVar3 + 0x10 + iVar1) * 0x100 + (int16_t)arg2);
                }
            }
        } else if ((iVar8 == 0xc) || (iVar8 == 0xd)) {
            iVar10 = 0;
            iVar11 = (((uint32_t)*(uint8_t *)(iVar1 + 0xd + uVar7) + (uint32_t)*(uint8_t *)(iVar1 + 0xc + uVar7) * 0x100
                      ) * 0x100 + (uint32_t)*(uint8_t *)(iVar1 + 0xe + uVar7)) * 0x100 +
                     (uint32_t)*(uint8_t *)(iVar1 + 0xf + uVar7);
            if (0 < iVar11) {
                do {
                    iVar12 = (iVar11 - iVar10 >> 1) + iVar10;
                    iVar3 = (int64_t)(iVar12 * 0xc) + uVar7;
                    uVar5 = (uint32_t)*(uint8_t *)(iVar1 + 0x11 + iVar3) * 0x10000 +
                            (uint32_t)*(uint8_t *)(iVar3 + 0x12 + iVar1) * 0x100 +
                            (uint32_t)*(uint8_t *)((int64_t)(iVar12 * 0xc) + 0x10 + iVar1 + uVar7) * 0x1000000 +
                            (uint32_t)*(uint8_t *)(iVar3 + 0x13 + iVar1);
                    if (uVar5 <= uVar4) {
                        if (uVar4 <= (uint32_t)*(uint8_t *)(iVar3 + 0x15 + iVar1) * 0x10000 +
                                     (uint32_t)*(uint8_t *)(iVar3 + 0x16 + iVar1) * 0x100 +
                                     (uint32_t)*(uint8_t *)(iVar3 + 0x14 + iVar1) * 0x1000000 +
                                     (uint32_t)*(uint8_t *)(iVar3 + 0x17 + iVar1)) {
                            uVar9 = (uint32_t)*(uint8_t *)(iVar3 + 0x1b + iVar1) +
                                    (uint32_t)*(uint8_t *)(iVar3 + 0x19 + iVar1) * 0x10000 +
                                    (uint32_t)*(uint8_t *)(iVar3 + 0x1a + iVar1) * 0x100 +
                                    (uint32_t)*(uint8_t *)(iVar3 + 0x18 + iVar1) * 0x1000000;
                            if (iVar8 != 0xc) {
                                return uVar9;
                            }
                            return (uVar9 - uVar5) + uVar4;
                        }
                        iVar10 = iVar12 + 1;
                        iVar12 = iVar11;
                    }
                    iVar11 = iVar12;
                } while (iVar10 < iVar11);
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180120800
// Address: 0x180120800
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int32_t fcn.180120800(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                     int64_t arg_38h, undefined8 placeholder_7, undefined8 placeholder_8, int64_t arg_50h,
                     int64_t arg_58h)
{
    int64_t iVar1;
    int32_t iVar2;
    undefined2 uVar3;
    int64_t var_8h;
    
    uVar3 = (undefined2)(int32_t)placeholder_8;
    iVar2 = (int32_t)arg2;
    if ((int32_t)arg4 != 0) {
        if ((int32_t)arg3 != 0) {
            iVar1 = (int64_t)iVar2 * 0xe;
            iVar2 = iVar2 + 1;
            *(int16_t *)(iVar1 + arg1) = (int16_t)((int32_t)arg_38h + (int32_t)placeholder_8 >> 1);
            *(undefined *)(iVar1 + 0xc + arg1) = 3;
            *(undefined2 *)(iVar1 + 4 + arg1) = uVar3;
            *(undefined2 *)(iVar1 + 6 + arg1) = (undefined2)arg_50h;
            *(int16_t *)(iVar1 + 2 + arg1) = (int16_t)((int32_t)placeholder_7 + (int32_t)arg_50h >> 1);
        }
        iVar1 = (int64_t)iVar2 * 0xe;
        *(undefined2 *)(iVar1 + arg1) = (undefined2)arg_28h;
        *(undefined2 *)(iVar1 + 2 + arg1) = (undefined2)arg_30h;
        *(int16_t *)(iVar1 + 4 + arg1) = (int16_t)arg_38h;
        *(undefined *)(iVar1 + 0xc + arg1) = 3;
        *(int16_t *)(iVar1 + 6 + arg1) = (int16_t)(int32_t)placeholder_7;
        return iVar2 + 1;
    }
    iVar1 = (int64_t)iVar2 * 0xe;
    *(undefined2 *)(iVar1 + arg1) = (undefined2)arg_28h;
    *(undefined2 *)(iVar1 + 2 + arg1) = (undefined2)arg_30h;
    if ((int32_t)arg3 != 0) {
        *(undefined2 *)(iVar1 + 4 + arg1) = uVar3;
        *(undefined2 *)(iVar1 + 6 + arg1) = (undefined2)arg_50h;
        *(undefined *)(iVar1 + 0xc + arg1) = 3;
        return iVar2 + 1;
    }
    *(undefined *)(iVar1 + 0xc + arg1) = 2;
    *(undefined4 *)(iVar1 + 4 + arg1) = 0;
    return iVar2 + 1;
}

// ============================================================
// Function: FUN_180120818
// Address: 0x180120818
// Size: 127 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int32_t fcn.180120800(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                     int64_t arg_38h, undefined8 placeholder_7, undefined8 placeholder_8, int64_t arg_50h,
                     int64_t arg_58h)
{
    int64_t iVar1;
    int32_t iVar2;
    undefined2 uVar3;
    int64_t var_8h;
    
    uVar3 = (undefined2)(int32_t)placeholder_8;
    iVar2 = (int32_t)arg2;
    if ((int32_t)arg4 != 0) {
        if ((int32_t)arg3 != 0) {
            iVar1 = (int64_t)iVar2 * 0xe;
            iVar2 = iVar2 + 1;
            *(int16_t *)(iVar1 + arg1) = (int16_t)((int32_t)arg_38h + (int32_t)placeholder_8 >> 1);
            *(undefined *)(iVar1 + 0xc + arg1) = 3;
            *(undefined2 *)(iVar1 + 4 + arg1) = uVar3;
            *(undefined2 *)(iVar1 + 6 + arg1) = (undefined2)arg_50h;
            *(int16_t *)(iVar1 + 2 + arg1) = (int16_t)((int32_t)placeholder_7 + (int32_t)arg_50h >> 1);
        }
        iVar1 = (int64_t)iVar2 * 0xe;
        *(undefined2 *)(iVar1 + arg1) = (undefined2)arg_28h;
        *(undefined2 *)(iVar1 + 2 + arg1) = (undefined2)arg_30h;
        *(int16_t *)(iVar1 + 4 + arg1) = (int16_t)arg_38h;
        *(undefined *)(iVar1 + 0xc + arg1) = 3;
        *(int16_t *)(iVar1 + 6 + arg1) = (int16_t)(int32_t)placeholder_7;
        return iVar2 + 1;
    }
    iVar1 = (int64_t)iVar2 * 0xe;
    *(undefined2 *)(iVar1 + arg1) = (undefined2)arg_28h;
    *(undefined2 *)(iVar1 + 2 + arg1) = (undefined2)arg_30h;
    if ((int32_t)arg3 != 0) {
        *(undefined2 *)(iVar1 + 4 + arg1) = uVar3;
        *(undefined2 *)(iVar1 + 6 + arg1) = (undefined2)arg_50h;
        *(undefined *)(iVar1 + 0xc + arg1) = 3;
        return iVar2 + 1;
    }
    *(undefined *)(iVar1 + 0xc + arg1) = 2;
    *(undefined4 *)(iVar1 + 4 + arg1) = 0;
    return iVar2 + 1;
}

// ============================================================
// Function: FUN_180120897
// Address: 0x180120897
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int32_t fcn.180120800(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                     int64_t arg_38h, undefined8 placeholder_7, undefined8 placeholder_8, int64_t arg_50h,
                     int64_t arg_58h)
{
    int64_t iVar1;
    int32_t iVar2;
    undefined2 uVar3;
    int64_t var_8h;
    
    uVar3 = (undefined2)(int32_t)placeholder_8;
    iVar2 = (int32_t)arg2;
    if ((int32_t)arg4 != 0) {
        if ((int32_t)arg3 != 0) {
            iVar1 = (int64_t)iVar2 * 0xe;
            iVar2 = iVar2 + 1;
            *(int16_t *)(iVar1 + arg1) = (int16_t)((int32_t)arg_38h + (int32_t)placeholder_8 >> 1);
            *(undefined *)(iVar1 + 0xc + arg1) = 3;
            *(undefined2 *)(iVar1 + 4 + arg1) = uVar3;
            *(undefined2 *)(iVar1 + 6 + arg1) = (undefined2)arg_50h;
            *(int16_t *)(iVar1 + 2 + arg1) = (int16_t)((int32_t)placeholder_7 + (int32_t)arg_50h >> 1);
        }
        iVar1 = (int64_t)iVar2 * 0xe;
        *(undefined2 *)(iVar1 + arg1) = (undefined2)arg_28h;
        *(undefined2 *)(iVar1 + 2 + arg1) = (undefined2)arg_30h;
        *(int16_t *)(iVar1 + 4 + arg1) = (int16_t)arg_38h;
        *(undefined *)(iVar1 + 0xc + arg1) = 3;
        *(int16_t *)(iVar1 + 6 + arg1) = (int16_t)(int32_t)placeholder_7;
        return iVar2 + 1;
    }
    iVar1 = (int64_t)iVar2 * 0xe;
    *(undefined2 *)(iVar1 + arg1) = (undefined2)arg_28h;
    *(undefined2 *)(iVar1 + 2 + arg1) = (undefined2)arg_30h;
    if ((int32_t)arg3 != 0) {
        *(undefined2 *)(iVar1 + 4 + arg1) = uVar3;
        *(undefined2 *)(iVar1 + 6 + arg1) = (undefined2)arg_50h;
        *(undefined *)(iVar1 + 0xc + arg1) = 3;
        return iVar2 + 1;
    }
    *(undefined *)(iVar1 + 0xc + arg1) = 2;
    *(undefined4 *)(iVar1 + 4 + arg1) = 0;
    return iVar2 + 1;
}

// ============================================================
// Function: FUN_1801208f0
// Address: 0x1801208f0
// Size: 3232 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_158h
// WARNING: Variable defined which should be unmapped: var_150h
// WARNING: Variable defined which should be unmapped: var_148h
// WARNING: Variable defined which should be unmapped: var_140h
// WARNING: Variable defined which should be unmapped: var_138h
// WARNING: Variable defined which should be unmapped: var_130h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_128h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_6h

int32_t fcn.1801208f0(int64_t arg1, undefined8 placeholder_1, int64_t arg3)
{
    uint8_t *puVar1;
    uint8_t *puVar2;
    uint8_t uVar3;
    int16_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int16_t *piVar8;
    undefined uVar9;
    uint16_t uVar10;
    uint8_t uVar11;
    uint8_t uVar12;
    int64_t iVar13;
    int32_t iVar14;
    int32_t iVar15;
    uint8_t *puVar16;
    uint8_t *puVar17;
    uint32_t uVar18;
    int32_t iVar19;
    int64_t iVar20;
    int16_t iVar21;
    int32_t iVar22;
    uint8_t *puVar23;
    uint64_t arg4;
    uint32_t uVar24;
    uint8_t uVar25;
    int32_t iVar26;
    int32_t iVar27;
    int32_t iVar28;
    int32_t iVar29;
    int64_t iVar30;
    int32_t iVar31;
    int64_t iVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    float fVar36;
    float fVar37;
    float fVar38;
    float fVar39;
    float fVar40;
    float fVar41;
    float fVar42;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int32_t in_stack_fffffffffffffed8;
    int32_t iVar43;
    int64_t var_120h;
    int16_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_ech;
    int64_t var_38h;
    
    iVar5 = func_0x000180120730();
    *(undefined8 *)arg3 = 0;
    if (-1 < iVar5) {
        iVar20 = *(int64_t *)(arg1 + 8);
        iVar30 = (int64_t)iVar5;
        iVar21 = (uint16_t)*(uint8_t *)(iVar30 + 1 + iVar20) + (uint16_t)*(uint8_t *)(iVar30 + iVar20) * 0x100;
        if (iVar21 < 1) {
            if (iVar21 < 0) {
                puVar23 = (uint8_t *)(iVar20 + 10 + iVar30);
                iVar5 = 0;
                iVar20 = 0;
                do {
                    uVar12 = puVar23[1];
                    fVar41 = 0.0;
                    uVar25 = puVar23[3];
                    fVar42 = 0.0;
                    uVar11 = puVar23[2];
                    puVar16 = puVar23 + 4;
                    var_8h = 0;
                    if ((uVar12 & 2) != 0) {
                        if ((uVar12 & 1) == 0) {
                            iVar43 = (int32_t)(char)*puVar16;
                            puVar17 = puVar23 + 6;
                            iVar14 = (int32_t)(char)puVar23[5];
                        } else {
                            puVar17 = puVar23 + 8;
                            iVar43 = (int32_t)(int16_t)((uint16_t)*puVar16 * 0x100 + (uint16_t)puVar23[5]);
                            iVar14 = (int32_t)(int16_t)((uint16_t)puVar23[7] + (uint16_t)puVar23[6] * 0x100);
                        }
                        fVar42 = (float)iVar14;
                        fVar41 = (float)iVar43;
                        puVar16 = puVar17;
                    }
                    puVar23 = puVar16;
                    if ((uVar12 & 8) == 0) {
                        if ((uVar12 & 0x40) == 0) {
                            if ((char)uVar12 < '\0') {
                                puVar16 = puVar23 + 4;
                                puVar17 = puVar23 + 5;
                                fVar37 = (float)(int32_t)(int16_t)((uint16_t)puVar23[1] + (uint16_t)*puVar23 * 0x100) *
                                         6.103516e-05;
                                puVar1 = puVar23 + 6;
                                puVar2 = puVar23 + 7;
                                fVar39 = (float)(int32_t)(int16_t)((uint16_t)puVar23[3] + (uint16_t)puVar23[2] * 0x100)
                                         * 6.103516e-05;
                                puVar23 = puVar23 + 8;
                                fVar40 = (float)(int32_t)(int16_t)((uint16_t)*puVar17 + (uint16_t)*puVar16 * 0x100) *
                                         6.103516e-05;
                                fVar38 = (float)(int32_t)(int16_t)((uint16_t)*puVar2 + (uint16_t)*puVar1 * 0x100) *
                                         6.103516e-05;
                            } else {
                                fVar38 = 1.0;
                                fVar40 = 0.0;
                                fVar39 = 0.0;
                                fVar37 = 1.0;
                            }
                        } else {
                            puVar16 = puVar23 + 1;
                            fVar40 = 0.0;
                            uVar3 = *puVar23;
                            fVar39 = 0.0;
                            puVar17 = puVar23 + 2;
                            puVar1 = puVar23 + 3;
                            puVar23 = puVar23 + 4;
                            fVar37 = (float)(int32_t)(int16_t)((uint16_t)*puVar16 + (uint16_t)uVar3 * 0x100) *
                                     6.103516e-05;
                            fVar38 = (float)(int32_t)(int16_t)((uint16_t)*puVar1 + (uint16_t)*puVar17 * 0x100) *
                                     6.103516e-05;
                        }
                    } else {
                        puVar16 = puVar23 + 1;
                        fVar40 = 0.0;
                        uVar3 = *puVar23;
                        fVar39 = 0.0;
                        puVar23 = puVar23 + 2;
                        fVar37 = (float)(int32_t)(int16_t)((uint16_t)*puVar16 + (uint16_t)uVar3 * 0x100) * 6.103516e-05;
                        fVar38 = fVar37;
                    }
                    fVar34 = fVar39 * fVar39 + fVar37 * fVar37;
                    if (fVar34 < 0.0) {
                        fVar34 = (float)func_0x000180494560(fVar34);
                    } else {
                        fVar34 = SQRT(fVar34);
                    }
                    fVar33 = fVar38 * fVar38 + fVar40 * fVar40;
                    if (fVar33 < 0.0) {
                        fVar33 = (float)func_0x000180494560();
                    } else {
                        fVar33 = SQRT(fVar33);
                    }
                    if (*(int32_t *)(arg1 + 0x4c) == 0) {
                        iVar14 = fcn.1801208f0(arg1, (uint64_t)((uint32_t)uVar11 * 0x100 + (uint32_t)uVar25), 
                                               (int64_t)&var_8h);
                    } else {
                        iVar14 = func_0x000180122760();
                    }
                    iVar30 = iVar20;
                    if (0 < iVar14) {
                        iVar43 = 0;
                        if (iVar14 < 4) goto code_r0x00018012139f;
                        do {
                            iVar7 = (int64_t)iVar43;
                            iVar30 = iVar7 * 0xe;
                            fVar35 = (float)(int32_t)*(int16_t *)(iVar30 + 2 + var_8h);
                            iVar21 = *(int16_t *)(iVar30 + var_8h);
                            *(int16_t *)(iVar30 + var_8h) =
                                 (int16_t)(int32_t)((fVar37 * (float)(int32_t)iVar21 + fVar40 * fVar35 + fVar41) *
                                                   fVar34);
                            *(int16_t *)(iVar30 + 2 + var_8h) =
                                 (int16_t)(int32_t)((fVar39 * (float)(int32_t)iVar21 + fVar38 * fVar35 + fVar42) *
                                                   fVar33);
                            fVar36 = (float)(int32_t)*(int16_t *)(iVar30 + 6 + var_8h);
                            fVar35 = (float)(int32_t)*(int16_t *)(iVar30 + 4 + var_8h);
                            *(int16_t *)(iVar30 + 4 + var_8h) =
                                 (int16_t)(int32_t)((fVar37 * fVar35 + fVar40 * fVar36 + fVar41) * fVar34);
                            *(int16_t *)(iVar30 + 6 + var_8h) =
                                 (int16_t)(int32_t)((fVar39 * fVar35 + fVar38 * fVar36 + fVar42) * fVar33);
                            iVar30 = (iVar7 + 1) * 0xe;
                            fVar35 = (float)(int32_t)*(int16_t *)(iVar30 + 2 + var_8h);
                            iVar21 = *(int16_t *)(iVar30 + var_8h);
                            *(int16_t *)(iVar30 + var_8h) =
                                 (int16_t)(int32_t)((fVar37 * (float)(int32_t)iVar21 + fVar40 * fVar35 + fVar41) *
                                                   fVar34);
                            *(int16_t *)(iVar30 + 2 + var_8h) =
                                 (int16_t)(int32_t)((fVar39 * (float)(int32_t)iVar21 + fVar38 * fVar35 + fVar42) *
                                                   fVar33);
                            fVar36 = (float)(int32_t)*(int16_t *)(iVar30 + 6 + var_8h);
                            fVar35 = (float)(int32_t)*(int16_t *)(iVar30 + 4 + var_8h);
                            *(int16_t *)(iVar30 + 4 + var_8h) =
                                 (int16_t)(int32_t)((fVar37 * fVar35 + fVar40 * fVar36 + fVar41) * fVar34);
                            *(int16_t *)(iVar30 + 6 + var_8h) =
                                 (int16_t)(int32_t)((fVar39 * fVar35 + fVar38 * fVar36 + fVar42) * fVar33);
                            iVar30 = (iVar7 + 2) * 0xe;
                            fVar35 = (float)(int32_t)*(int16_t *)(iVar30 + 2 + var_8h);
                            iVar21 = *(int16_t *)(iVar30 + var_8h);
                            *(int16_t *)(iVar30 + var_8h) =
                                 (int16_t)(int32_t)((fVar37 * (float)(int32_t)iVar21 + fVar40 * fVar35 + fVar41) *
                                                   fVar34);
                            *(int16_t *)(iVar30 + 2 + var_8h) =
                                 (int16_t)(int32_t)((fVar39 * (float)(int32_t)iVar21 + fVar38 * fVar35 + fVar42) *
                                                   fVar33);
                            fVar36 = (float)(int32_t)*(int16_t *)(iVar30 + 6 + var_8h);
                            fVar35 = (float)(int32_t)*(int16_t *)(iVar30 + 4 + var_8h);
                            *(int16_t *)(iVar30 + 4 + var_8h) =
                                 (int16_t)(int32_t)((fVar37 * fVar35 + fVar40 * fVar36 + fVar41) * fVar34);
                            *(int16_t *)(iVar30 + 6 + var_8h) =
                                 (int16_t)(int32_t)((fVar39 * fVar35 + fVar38 * fVar36 + fVar42) * fVar33);
                            iVar30 = (iVar7 + 3) * 0xe;
                            fVar35 = (float)(int32_t)*(int16_t *)(iVar30 + 2 + var_8h);
                            iVar21 = *(int16_t *)(iVar30 + var_8h);
                            iVar43 = iVar43 + 4;
                            *(int16_t *)(iVar30 + var_8h) =
                                 (int16_t)(int32_t)((fVar37 * (float)(int32_t)iVar21 + fVar40 * fVar35 + fVar41) *
                                                   fVar34);
                            *(int16_t *)(iVar30 + 2 + var_8h) =
                                 (int16_t)(int32_t)((fVar39 * (float)(int32_t)iVar21 + fVar38 * fVar35 + fVar42) *
                                                   fVar33);
                            fVar36 = (float)(int32_t)*(int16_t *)(iVar30 + 6 + var_8h);
                            fVar35 = (float)(int32_t)*(int16_t *)(iVar30 + 4 + var_8h);
                            *(int16_t *)(iVar30 + 4 + var_8h) =
                                 (int16_t)(int32_t)((fVar37 * fVar35 + fVar40 * fVar36 + fVar41) * fVar34);
                            *(int16_t *)(iVar30 + 6 + var_8h) =
                                 (int16_t)(int32_t)((fVar39 * fVar35 + fVar38 * fVar36 + fVar42) * fVar33);
                        } while (iVar43 < iVar14 + -3);
                        for (; iVar43 < iVar14; iVar43 = iVar43 + 1) {
code_r0x00018012139f:
                            iVar30 = (int64_t)iVar43 * 0xe;
                            iVar21 = *(int16_t *)(iVar30 + var_8h);
                            fVar35 = (float)(int32_t)*(int16_t *)(iVar30 + 2 + var_8h);
                            *(int16_t *)(iVar30 + var_8h) =
                                 (int16_t)(int32_t)((fVar37 * (float)(int32_t)iVar21 + fVar40 * fVar35 + fVar41) *
                                                   fVar34);
                            *(int16_t *)(iVar30 + 2 + var_8h) =
                                 (int16_t)(int32_t)((fVar39 * (float)(int32_t)iVar21 + fVar38 * fVar35 + fVar42) *
                                                   fVar33);
                            fVar36 = (float)(int32_t)*(int16_t *)(iVar30 + 6 + var_8h);
                            fVar35 = (float)(int32_t)*(int16_t *)(iVar30 + 4 + var_8h);
                            *(int16_t *)(iVar30 + 4 + var_8h) =
                                 (int16_t)(int32_t)((fVar37 * fVar35 + fVar40 * fVar36 + fVar41) * fVar34);
                            *(int16_t *)(iVar30 + 6 + var_8h) =
                                 (int16_t)(int32_t)((fVar39 * fVar35 + fVar38 * fVar36 + fVar42) * fVar33);
                        }
                        iVar30 = func_0x00018046d050((int64_t)(iVar14 + iVar5) * 0xe);
                        if (iVar30 == 0) {
                            if (iVar20 != 0) {
                                func_0x000180460d90(iVar20);
                            }
                            if (var_8h == 0) {
                                return 0;
                            }
                            func_0x000180460d90();
                            return 0;
                        }
                        if ((0 < iVar5) && (iVar20 != 0)) {
                            func_0x000180498030(iVar30, iVar20, (int64_t)iVar5 * 0xe);
                        }
                        func_0x000180498030((int64_t)iVar5 * 0xe + iVar30, var_8h, (int64_t)iVar14 * 0xe);
                        if (iVar20 != 0) {
                            func_0x000180460d90(iVar20);
                        }
                        func_0x000180460d90(var_8h);
                        iVar5 = iVar14 + iVar5;
                    }
                    iVar20 = iVar30;
                } while ((uVar12 & 0x20) != 0);
            } else {
                iVar30 = 0;
                iVar5 = 0;
            }
            *(int64_t *)arg3 = iVar30;
            return iVar5;
        }
        iVar13 = iVar20 + 10 + iVar30;
        iVar5 = iVar21 * 2;
        iVar32 = (int64_t)iVar5;
        uVar12 = *(uint8_t *)(iVar32 + iVar30 + 10 + iVar20);
        var_8h = CONCAT71(var_8h._1_7_, *(undefined *)(iVar32 + iVar30 + 0xb + iVar20));
        iVar14 = (uint32_t)*(uint8_t *)(iVar32 + -2 + iVar13) * 0x100 + *(uint8_t *)(iVar32 + -1 + iVar13) + 1;
        iVar7 = func_0x00018046d050((int64_t)(iVar5 + iVar14) * 0xe);
        if (iVar7 != 0) {
            uVar18 = 0;
            var_120h._0_4_ = 0;
            iVar43 = 0;
            uVar25 = 0;
            arg4 = 0;
            uVar11 = 0;
            uVar24 = 0;
            puVar23 = (uint8_t *)((var_8h & 0xffU) + 0xc + (uint64_t)uVar12 * 0x100 + iVar32 + iVar30 + iVar20);
            if (iVar14 == 0) {
                iVar6 = 0;
                iVar22 = 0;
                iVar29 = 0;
                iVar31 = 0;
                iVar26 = 0;
                iVar15 = 0;
            } else {
                do {
                    if (uVar11 == 0) {
                        uVar25 = *puVar23;
                        if ((uVar25 & 8) != 0) {
                            uVar11 = puVar23[1];
                        }
                        puVar23 = puVar23 + (uint64_t)((uVar25 & 8) != 0) + 1;
                    } else {
                        uVar11 = uVar11 - 1;
                    }
                    iVar6 = uVar24 + iVar5;
                    uVar24 = uVar24 + 1;
                    *(uint8_t *)((int64_t)iVar6 * 0xe + 0xc + iVar7) = uVar25;
                } while ((int32_t)uVar24 < iVar14);
                iVar21 = 0;
                iVar6 = 0;
                do {
                    iVar20 = (int64_t)(iVar6 + iVar5) * 0xe;
                    uVar12 = *(uint8_t *)(iVar20 + 0xc + iVar7) & 0x10;
                    if ((*(uint8_t *)(iVar20 + 0xc + iVar7) & 2) == 0) {
                        if (uVar12 == 0) {
                            iVar21 = iVar21 + (uint16_t)puVar23[1] + (uint16_t)*puVar23 * 0x100;
                            puVar23 = puVar23 + 2;
                        }
                    } else {
                        uVar25 = *puVar23;
                        puVar23 = puVar23 + 1;
                        uVar10 = (uint16_t)uVar25;
                        if (uVar12 == 0) {
                            uVar10 = -(uint16_t)uVar25;
                        }
                        iVar21 = iVar21 + uVar10;
                    }
                    iVar6 = iVar6 + 1;
                    *(int16_t *)(iVar20 + iVar7) = iVar21;
                } while (iVar6 < iVar14);
                iVar21 = 0;
                iVar6 = 0;
                do {
                    iVar20 = (int64_t)(iVar6 + iVar5) * 0xe;
                    uVar12 = *(uint8_t *)(iVar20 + 0xc + iVar7) & 0x20;
                    if ((*(uint8_t *)(iVar20 + 0xc + iVar7) & 4) == 0) {
                        if (uVar12 == 0) {
                            iVar21 = iVar21 + (uint16_t)puVar23[1] + (uint16_t)*puVar23 * 0x100;
                            puVar23 = puVar23 + 2;
                        }
                    } else {
                        uVar25 = *puVar23;
                        puVar23 = puVar23 + 1;
                        uVar10 = (uint16_t)uVar25;
                        if (uVar12 == 0) {
                            uVar10 = -(uint16_t)uVar25;
                        }
                        iVar21 = iVar21 + uVar10;
                    }
                    iVar6 = iVar6 + 1;
                    *(int16_t *)(iVar20 + 2 + iVar7) = iVar21;
                } while (iVar6 < iVar14);
                iVar6 = 0;
                iVar22 = 0;
                uVar24 = 0;
                var_20h._0_4_ = 0;
                iVar29 = 0;
                in_stack_fffffffffffffed8 = 0;
                iVar31 = 0;
                iVar26 = 0;
                iVar15 = 0;
                iVar19 = 0;
                do {
                    iVar20 = (int64_t)(iVar19 + iVar5) * 0xe;
                    uVar12 = *(uint8_t *)(iVar7 + 0xc + iVar20);
                    iVar21 = *(int16_t *)(iVar7 + iVar20);
                    iVar27 = (int32_t)iVar21;
                    iVar4 = *(int16_t *)(iVar7 + 2 + iVar20);
                    iVar28 = (int32_t)iVar4;
                    var_8h = CONCAT71(var_8h._1_7_, uVar12);
                    if (iVar43 == iVar19) {
                        if (iVar19 != 0) {
                            uVar24 = fcn.180120800(iVar7, (uint64_t)uVar24, (uint64_t)uVar18, arg4, 
                                                   CONCAT44(var_158h._4_4_, iVar15), CONCAT44(var_150h._4_4_, iVar26), 
                                                   CONCAT44(var_148h._4_4_, iVar22), CONCAT44(var_140h._4_4_, iVar6), 
                                                   CONCAT44(var_138h._4_4_, iVar31), CONCAT44(var_130h._4_4_, iVar29), 
                                                   CONCAT44(iVar43, in_stack_fffffffffffffed8));
                            uVar12 = (uint8_t)var_8h;
                        }
                        arg4 = (uint64_t)(~(uint32_t)uVar12 & 1);
                        iVar26 = iVar28;
                        iVar15 = iVar27;
                        if ((~(uint32_t)uVar12 & 1) != 0) {
                            iVar20 = ((int64_t)(iVar19 + iVar5) + 1) * 0xe;
                            iVar26 = (int32_t)*(int16_t *)(iVar20 + 2 + iVar7);
                            var_20h._0_4_ = iVar28;
                            in_stack_fffffffffffffed8 = iVar27;
                            if ((*(uint8_t *)(iVar20 + 0xc + iVar7) & 1) == 0) {
                                iVar26 = iVar26 + iVar28 >> 1;
                                iVar15 = *(int16_t *)(iVar20 + iVar7) + iVar27 >> 1;
                            } else {
                                iVar19 = iVar19 + 1;
                                iVar15 = (int32_t)*(int16_t *)(iVar20 + iVar7);
                            }
                        }
                        iVar20 = (int64_t)(int32_t)uVar24 * 0xe;
                        *(undefined4 *)(iVar7 + 4 + iVar20) = 0;
                        *(undefined *)(iVar7 + 0xc + iVar20) = 1;
                        *(int16_t *)(iVar7 + iVar20) = (int16_t)iVar15;
                        *(int16_t *)(iVar7 + 2 + iVar20) = (int16_t)iVar26;
                        iVar43 = (uint32_t)*(uint8_t *)((int32_t)var_120h * 2 + iVar13) * 0x100 +
                                 *(uint8_t *)((int64_t)((int32_t)var_120h * 2) + 1 + iVar13) + 1;
                        var_120h._0_4_ = (int32_t)var_120h + 1;
                        iVar22 = in_stack_fffffffffffffed8;
code_r0x000180120d25:
                        uVar24 = uVar24 + 1;
                        uVar18 = 0;
                        iVar6 = (int32_t)var_20h;
                        in_stack_fffffffffffffed8 = iVar22;
                    } else {
                        var_120h._4_2_ = (int16_t)iVar31;
                        var_118h = (int16_t)iVar29;
                        if ((uVar12 & 1) != 0) {
                            piVar8 = (int16_t *)((int64_t)(int32_t)uVar24 * 0xe + iVar7);
                            if (uVar18 == 0) {
                                var_118h = 0;
                                var_120h._4_2_ = 0;
                                uVar9 = 2;
                            } else {
                                uVar9 = 3;
                            }
                            *(undefined *)(piVar8 + 6) = uVar9;
                            *piVar8 = iVar21;
                            piVar8[1] = iVar4;
                            piVar8[2] = var_120h._4_2_;
                            piVar8[3] = var_118h;
                            iVar22 = in_stack_fffffffffffffed8;
                            goto code_r0x000180120d25;
                        }
                        if (uVar18 != 0) {
                            iVar20 = (int64_t)(int32_t)uVar24;
                            uVar24 = uVar24 + 1;
                            iVar20 = iVar20 * 0xe;
                            *(int16_t *)(iVar7 + iVar20) = (int16_t)(iVar31 + iVar27 >> 1);
                            *(int16_t *)(iVar7 + 2 + iVar20) = (int16_t)(iVar29 + iVar28 >> 1);
                            *(undefined *)(iVar7 + 0xc + iVar20) = 3;
                            *(int16_t *)(iVar7 + 4 + iVar20) = var_120h._4_2_;
                            *(int16_t *)(iVar7 + 6 + iVar20) = var_118h;
                        }
                        uVar18 = 1;
                        iVar31 = iVar27;
                        iVar29 = iVar28;
                    }
                    iVar19 = iVar19 + 1;
                } while (iVar19 < iVar14);
            }
            iVar5 = fcn.180120800(iVar7, (uint64_t)uVar24, (uint64_t)uVar18, arg4, CONCAT44(var_158h._4_4_, iVar15), 
                                  CONCAT44(var_150h._4_4_, iVar26), CONCAT44(var_148h._4_4_, iVar22), 
                                  CONCAT44(var_140h._4_4_, iVar6), CONCAT44(var_138h._4_4_, iVar31), 
                                  CONCAT44(var_130h._4_4_, iVar29), CONCAT44(iVar43, in_stack_fffffffffffffed8));
            *(int64_t *)arg3 = iVar7;
            return iVar5;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180121590
// Address: 0x180121590
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180121590(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined2 *puVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    
    if (*(int32_t *)arg1 == 0) {
        puVar3 = (undefined2 *)((int64_t)*(int32_t *)(arg1 + 0x30) * 0xe + *(int64_t *)(arg1 + 0x28));
        *(int32_t *)(arg1 + 0x30) = *(int32_t *)(arg1 + 0x30) + 1;
        puVar3[2] = (undefined2)arg_28h;
        puVar3[3] = (undefined2)arg_30h;
        *(char *)(puVar3 + 6) = (char)arg2;
        *puVar3 = (int16_t)arg3;
        puVar3[1] = (int16_t)arg4;
        puVar3[4] = (undefined2)arg_38h;
        puVar3[5] = (undefined2)arg_40h;
        return;
    }
    iVar6 = (int32_t)arg3;
    if ((*(int32_t *)(arg1 + 0x1c) < iVar6) || (iVar7 = *(int32_t *)(arg1 + 0x1c), *(int32_t *)(arg1 + 4) == 0)) {
        *(int32_t *)(arg1 + 0x1c) = iVar6;
        iVar7 = iVar6;
    }
    iVar1 = (int32_t)arg4;
    if ((*(int32_t *)(arg1 + 0x24) < iVar1) || (iVar4 = *(int32_t *)(arg1 + 0x24), *(int32_t *)(arg1 + 4) == 0)) {
        *(int32_t *)(arg1 + 0x24) = iVar1;
        iVar4 = iVar1;
    }
    if ((iVar6 < *(int32_t *)(arg1 + 0x18)) || (iVar5 = *(int32_t *)(arg1 + 0x18), *(int32_t *)(arg1 + 4) == 0)) {
        *(int32_t *)(arg1 + 0x18) = iVar6;
        iVar5 = iVar6;
    }
    if ((iVar1 < *(int32_t *)(arg1 + 0x20)) || (iVar6 = *(int32_t *)(arg1 + 0x20), *(int32_t *)(arg1 + 4) == 0)) {
        *(int32_t *)(arg1 + 0x20) = iVar1;
        iVar6 = iVar1;
    }
    *(undefined4 *)(arg1 + 4) = 1;
    if ((char)arg2 == '\x04') {
        iVar1 = (int32_t)arg_28h;
        if (iVar7 < iVar1) {
            *(int32_t *)(arg1 + 0x1c) = iVar1;
            iVar7 = iVar1;
        }
        iVar2 = (int32_t)arg_30h;
        if (iVar4 < iVar2) {
            *(int32_t *)(arg1 + 0x24) = iVar2;
            iVar4 = iVar2;
        }
        if (iVar1 < iVar5) {
            *(int32_t *)(arg1 + 0x18) = iVar1;
            iVar5 = iVar1;
        }
        if (iVar2 < iVar6) {
            *(int32_t *)(arg1 + 0x20) = iVar2;
            iVar6 = iVar2;
        }
        iVar1 = (int32_t)arg_38h;
        if (iVar7 < iVar1) {
            *(int32_t *)(arg1 + 0x1c) = iVar1;
        }
        iVar7 = (int32_t)arg_40h;
        if (iVar4 < iVar7) {
            *(int32_t *)(arg1 + 0x24) = iVar7;
        }
        if (iVar1 < iVar5) {
            *(int32_t *)(arg1 + 0x18) = iVar1;
        }
        if (iVar7 < iVar6) {
            *(int32_t *)(arg1 + 0x20) = iVar7;
        }
    }
    *(int32_t *)(arg1 + 0x30) = *(int32_t *)(arg1 + 0x30) + 1;
    return;
}

// ============================================================
// Function: FUN_1801215a5
// Address: 0x1801215a5
// Size: 217 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180121590(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined2 *puVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    
    if (*(int32_t *)arg1 == 0) {
        puVar3 = (undefined2 *)((int64_t)*(int32_t *)(arg1 + 0x30) * 0xe + *(int64_t *)(arg1 + 0x28));
        *(int32_t *)(arg1 + 0x30) = *(int32_t *)(arg1 + 0x30) + 1;
        puVar3[2] = (undefined2)arg_28h;
        puVar3[3] = (undefined2)arg_30h;
        *(char *)(puVar3 + 6) = (char)arg2;
        *puVar3 = (int16_t)arg3;
        puVar3[1] = (int16_t)arg4;
        puVar3[4] = (undefined2)arg_38h;
        puVar3[5] = (undefined2)arg_40h;
        return;
    }
    iVar6 = (int32_t)arg3;
    if ((*(int32_t *)(arg1 + 0x1c) < iVar6) || (iVar7 = *(int32_t *)(arg1 + 0x1c), *(int32_t *)(arg1 + 4) == 0)) {
        *(int32_t *)(arg1 + 0x1c) = iVar6;
        iVar7 = iVar6;
    }
    iVar1 = (int32_t)arg4;
    if ((*(int32_t *)(arg1 + 0x24) < iVar1) || (iVar4 = *(int32_t *)(arg1 + 0x24), *(int32_t *)(arg1 + 4) == 0)) {
        *(int32_t *)(arg1 + 0x24) = iVar1;
        iVar4 = iVar1;
    }
    if ((iVar6 < *(int32_t *)(arg1 + 0x18)) || (iVar5 = *(int32_t *)(arg1 + 0x18), *(int32_t *)(arg1 + 4) == 0)) {
        *(int32_t *)(arg1 + 0x18) = iVar6;
        iVar5 = iVar6;
    }
    if ((iVar1 < *(int32_t *)(arg1 + 0x20)) || (iVar6 = *(int32_t *)(arg1 + 0x20), *(int32_t *)(arg1 + 4) == 0)) {
        *(int32_t *)(arg1 + 0x20) = iVar1;
        iVar6 = iVar1;
    }
    *(undefined4 *)(arg1 + 4) = 1;
    if ((char)arg2 == '\x04') {
        iVar1 = (int32_t)arg_28h;
        if (iVar7 < iVar1) {
            *(int32_t *)(arg1 + 0x1c) = iVar1;
            iVar7 = iVar1;
        }
        iVar2 = (int32_t)arg_30h;
        if (iVar4 < iVar2) {
            *(int32_t *)(arg1 + 0x24) = iVar2;
            iVar4 = iVar2;
        }
        if (iVar1 < iVar5) {
            *(int32_t *)(arg1 + 0x18) = iVar1;
            iVar5 = iVar1;
        }
        if (iVar2 < iVar6) {
            *(int32_t *)(arg1 + 0x20) = iVar2;
            iVar6 = iVar2;
        }
        iVar1 = (int32_t)arg_38h;
        if (iVar7 < iVar1) {
            *(int32_t *)(arg1 + 0x1c) = iVar1;
        }
        iVar7 = (int32_t)arg_40h;
        if (iVar4 < iVar7) {
            *(int32_t *)(arg1 + 0x24) = iVar7;
        }
        if (iVar1 < iVar5) {
            *(int32_t *)(arg1 + 0x18) = iVar1;
        }
        if (iVar7 < iVar6) {
            *(int32_t *)(arg1 + 0x20) = iVar7;
        }
    }
    *(int32_t *)(arg1 + 0x30) = *(int32_t *)(arg1 + 0x30) + 1;
    return;
}

// ============================================================
// Function: FUN_18012167e
// Address: 0x18012167e
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180121590(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined2 *puVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    
    if (*(int32_t *)arg1 == 0) {
        puVar3 = (undefined2 *)((int64_t)*(int32_t *)(arg1 + 0x30) * 0xe + *(int64_t *)(arg1 + 0x28));
        *(int32_t *)(arg1 + 0x30) = *(int32_t *)(arg1 + 0x30) + 1;
        puVar3[2] = (undefined2)arg_28h;
        puVar3[3] = (undefined2)arg_30h;
        *(char *)(puVar3 + 6) = (char)arg2;
        *puVar3 = (int16_t)arg3;
        puVar3[1] = (int16_t)arg4;
        puVar3[4] = (undefined2)arg_38h;
        puVar3[5] = (undefined2)arg_40h;
        return;
    }
    iVar6 = (int32_t)arg3;
    if ((*(int32_t *)(arg1 + 0x1c) < iVar6) || (iVar7 = *(int32_t *)(arg1 + 0x1c), *(int32_t *)(arg1 + 4) == 0)) {
        *(int32_t *)(arg1 + 0x1c) = iVar6;
        iVar7 = iVar6;
    }
    iVar1 = (int32_t)arg4;
    if ((*(int32_t *)(arg1 + 0x24) < iVar1) || (iVar4 = *(int32_t *)(arg1 + 0x24), *(int32_t *)(arg1 + 4) == 0)) {
        *(int32_t *)(arg1 + 0x24) = iVar1;
        iVar4 = iVar1;
    }
    if ((iVar6 < *(int32_t *)(arg1 + 0x18)) || (iVar5 = *(int32_t *)(arg1 + 0x18), *(int32_t *)(arg1 + 4) == 0)) {
        *(int32_t *)(arg1 + 0x18) = iVar6;
        iVar5 = iVar6;
    }
    if ((iVar1 < *(int32_t *)(arg1 + 0x20)) || (iVar6 = *(int32_t *)(arg1 + 0x20), *(int32_t *)(arg1 + 4) == 0)) {
        *(int32_t *)(arg1 + 0x20) = iVar1;
        iVar6 = iVar1;
    }
    *(undefined4 *)(arg1 + 4) = 1;
    if ((char)arg2 == '\x04') {
        iVar1 = (int32_t)arg_28h;
        if (iVar7 < iVar1) {
            *(int32_t *)(arg1 + 0x1c) = iVar1;
            iVar7 = iVar1;
        }
        iVar2 = (int32_t)arg_30h;
        if (iVar4 < iVar2) {
            *(int32_t *)(arg1 + 0x24) = iVar2;
            iVar4 = iVar2;
        }
        if (iVar1 < iVar5) {
            *(int32_t *)(arg1 + 0x18) = iVar1;
            iVar5 = iVar1;
        }
        if (iVar2 < iVar6) {
            *(int32_t *)(arg1 + 0x20) = iVar2;
            iVar6 = iVar2;
        }
        iVar1 = (int32_t)arg_38h;
        if (iVar7 < iVar1) {
            *(int32_t *)(arg1 + 0x1c) = iVar1;
        }
        iVar7 = (int32_t)arg_40h;
        if (iVar4 < iVar7) {
            *(int32_t *)(arg1 + 0x24) = iVar7;
        }
        if (iVar1 < iVar5) {
            *(int32_t *)(arg1 + 0x18) = iVar1;
        }
        if (iVar7 < iVar6) {
            *(int32_t *)(arg1 + 0x20) = iVar7;
        }
    }
    *(int32_t *)(arg1 + 0x30) = *(int32_t *)(arg1 + 0x30) + 1;
    return;
}

// ============================================================
// Function: FUN_180121770
// Address: 0x180121770
// Size: 198 bytes
// ============================================================
void fcn.180121770(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    float in_XMM1_Da;
    float in_XMM2_Da;
    
    func_0x0001801216c0();
    in_XMM1_Da = in_XMM1_Da + *(float *)(arg1 + 0x10);
    in_XMM2_Da = in_XMM2_Da + *(float *)(arg1 + 0x14);
    *(float *)(arg1 + 0x10) = in_XMM1_Da;
    *(float *)(arg1 + 8) = in_XMM1_Da;
    *(float *)(arg1 + 0x14) = in_XMM2_Da;
    *(float *)(arg1 + 0xc) = in_XMM2_Da;
    iVar4 = (int32_t)in_XMM1_Da;
    if (*(int32_t *)arg1 != 0) {
        if ((*(int32_t *)(arg1 + 0x1c) < iVar4) || (*(int32_t *)(arg1 + 4) == 0)) {
            *(int32_t *)(arg1 + 0x1c) = iVar4;
        }
        iVar2 = (int32_t)in_XMM2_Da;
        if ((*(int32_t *)(arg1 + 0x24) < iVar2) || (*(int32_t *)(arg1 + 4) == 0)) {
            *(int32_t *)(arg1 + 0x24) = iVar2;
        }
        if ((iVar4 < *(int32_t *)(arg1 + 0x18)) || (*(int32_t *)(arg1 + 4) == 0)) {
            *(int32_t *)(arg1 + 0x18) = iVar4;
        }
        if ((iVar2 < *(int32_t *)(arg1 + 0x20)) || (*(int32_t *)(arg1 + 4) == 0)) {
            *(int32_t *)(arg1 + 0x20) = iVar2;
        }
        *(int32_t *)(arg1 + 0x30) = *(int32_t *)(arg1 + 0x30) + 1;
        *(int32_t *)(arg1 + 4) = 1;
        return;
    }
    iVar1 = *(int64_t *)(arg1 + 0x28);
    iVar3 = (int64_t)*(int32_t *)(arg1 + 0x30) * 0xe;
    *(int16_t *)(iVar3 + 2 + iVar1) = (int16_t)(int32_t)in_XMM2_Da;
    *(int32_t *)(arg1 + 0x30) = *(int32_t *)(arg1 + 0x30) + 1;
    *(undefined8 *)(iVar3 + 4 + iVar1) = 0;
    *(undefined *)(iVar3 + 0xc + iVar1) = 1;
    *(int16_t *)(iVar3 + iVar1) = (int16_t)iVar4;
    return;
}

// ============================================================
// Function: FUN_1801218e0
// Address: 0x1801218e0
// Size: 145 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1801218e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h)
{
    int32_t iVar1;
    float in_XMM1_Da;
    float in_XMM2_Da;
    float in_XMM3_Da;
    float fVar2;
    float fVar3;
    float fVar4;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    fVar3 = in_XMM2_Da + *(float *)(arg1 + 0x14);
    fVar4 = in_XMM1_Da + *(float *)(arg1 + 0x10);
    iVar1 = (int32_t)fVar3;
    fVar3 = fVar3 + (float)arg_28h;
    fVar2 = fVar4 + in_XMM3_Da;
    arg_30h._0_4_ = fVar2 + (float)arg_30h;
    arg_38h._0_4_ = fVar3 + (float)arg_38h;
    *(float *)(arg1 + 0x10) = (float)arg_30h;
    *(float *)(arg1 + 0x14) = (float)arg_38h;
    fcn.180121590(arg1, CONCAT44((int32_t)((uint64_t)arg2 >> 0x20), CONCAT31((unkint3)((uint32_t)iVar1 >> 8), 4)), 
                  CONCAT44((int32_t)((uint64_t)arg3 >> 0x20), (int32_t)(float)arg_30h), 
                  CONCAT44((int32_t)((uint64_t)arg4 >> 0x20), (int32_t)(float)arg_38h), 
                  CONCAT44(var_38h._4_4_, (int32_t)fVar4), CONCAT44(var_30h._4_4_, iVar1), 
                  CONCAT44(var_28h._4_4_, (int32_t)fVar2), CONCAT44(var_20h._4_4_, (int32_t)fVar3));
    return;
}

// ============================================================
// Function: FUN_180121980
// Address: 0x180121980
// Size: 3552 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_348h
// WARNING: Variable defined which should be unmapped: var_340h
// WARNING: Variable defined which should be unmapped: var_338h
// WARNING: Variable defined which should be unmapped: var_1ch
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f4h
// WARNING: [rz-ghidra] Removing arg arg_34h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_2fch
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_30h

void fcn.180121980(int64_t arg1, int64_t arg2, int64_t arg3, uint64_t placeholder_3, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_d0h, int64_t arg_180h)
{
    uint32_t uVar1;
    char *pcVar2;
    uint8_t *puVar3;
    int64_t iVar4;
    uint8_t uVar5;
    uint8_t uVar6;
    char cVar7;
    undefined uVar8;
    undefined uVar9;
    undefined uVar10;
    undefined uVar11;
    int16_t iVar12;
    int32_t iVar13;
    undefined (*pauVar14) [16];
    undefined4 *puVar15;
    int64_t iVar16;
    uint32_t uVar17;
    uint32_t uVar18;
    uint8_t **ppuVar19;
    uint64_t uVar20;
    uint32_t uVar21;
    int32_t iVar22;
    uint32_t uVar23;
    int32_t iVar24;
    uint32_t uVar25;
    int64_t iVar26;
    uint64_t uVar27;
    uint32_t uVar28;
    uint32_t uVar29;
    float fVar30;
    undefined auVar31 [16];
    float fVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    float fVar36;
    float fVar37;
    float fVar38;
    int64_t var_10h;
    int64_t var_1ch;
    undefined auStackY_368 [32];
    int64_t var_348h;
    int64_t var_340h;
    int64_t var_338h;
    int64_t var_328h;
    int64_t var_318h;
    int64_t var_310h;
    int64_t var_308h;
    int64_t var_300h;
    int64_t var_2f8h;
    int32_t var_2f0h;
    int64_t var_2ech;
    undefined8 uStack_2e0;
    int64_t iStack_2d8;
    undefined8 uStack_2c8;
    undefined8 uStack_2c0;
    undefined auStack_2b8 [12];
    undefined4 uStack_2ac;
    undefined8 uStack_2a8;
    undefined8 uStack_2a0;
    uint64_t uStack_298;
    undefined8 uStack_290;
    undefined4 uStack_288;
    undefined4 uStack_284;
    undefined4 uStack_280;
    undefined4 uStack_27c;
    undefined4 uStack_268;
    undefined4 uStack_264;
    undefined4 uStack_260;
    undefined4 uStack_25c;
    undefined auStack_258 [12];
    float afStack_24c [5];
    float fStack_238;
    float fStack_234;
    float fStack_230;
    float fStack_22c;
    float fStack_228;
    float fStack_224;
    float fStack_220;
    float fStack_21c;
    undefined auStack_198 [16];
    undefined4 auStack_188 [40];
    uint64_t uStack_e8;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_310h = var_318h;
    uStack_e8 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_368;
    uStack_268 = *(undefined4 *)(arg1 + 0x70);
    uStack_264 = *(undefined4 *)(arg1 + 0x74);
    uStack_260 = *(undefined4 *)(arg1 + 0x78);
    uStack_25c = *(undefined4 *)(arg1 + 0x7c);
    var_2ech._0_4_ = (int32_t)arg2;
    _auStack_2b8 = *(undefined (*) [16])(arg1 + 0x50);
    var_2f8h._0_4_ = 0;
    var_2f0h = 0;
    var_2ech._4_4_ = 0;
    var_2f8h._4_4_ = 1;
    iStack_2d8 = arg1;
    pauVar14 = (undefined (*) [16])
               fcn.180120180((int64_t)&uStack_288, (int64_t)auStack_2b8, arg2 & 0xffffffff, placeholder_3, 
                             CONCAT44(var_348h._4_4_, (float)var_348h));
    uVar25 = *(uint32_t *)(*pauVar14 + 8);
    var_308h = SUB168(*pauVar14, 0);
    uVar28 = SUB164(*pauVar14, 0xc);
    var_300h = *(undefined8 *)(*pauVar14 + 8);
    var_318h = var_308h;
    uVar20 = var_308h;
    fVar30 = afStack_24c[1];
    fVar34 = afStack_24c[4];
    fVar35 = afStack_24c[2];
    fVar36 = afStack_24c[3];
    fVar37 = fStack_238;
    fVar38 = fStack_234;
    uVar29 = 0;
    iVar13 = 0;
code_r0x000180121a92:
    fVar33 = fStack_22c;
    iVar16 = iStack_2d8;
    iVar26 = 0x180000000;
    iVar24 = (int32_t)var_328h;
    if ((int32_t)var_300h._4_4_ <= (int32_t)uVar25) {
code_r0x000180121c00:
        var_328h._0_4_ = iVar24;
        func_0x000180459870(uStack_e8 ^ (uint64_t)auStackY_368);
        return;
    }
    uVar23 = uVar25 + 1;
    iVar4 = var_308h;
    var_300h._0_4_ = uVar23;
    uVar6 = *(uint8_t *)((int64_t)(int32_t)uVar25 + uVar20);
    iVar22 = 0;
    var_328h._0_4_ = 1;
    iVar24 = (int32_t)var_328h;
    uVar17 = uVar29;
    // switch table (31 cases) at 0x1801226e4
    switch(uVar6) {
    case 1:
    case 3:
    case 0x12:
    case 0x17:
        var_2f8h._0_4_ = (int32_t)var_2f8h + (int32_t)uVar29 / 2;
        break;
    default:
        var_328h._0_4_ = 1;
        if (uVar6 == 0xff) {
            if ((int32_t)uVar23 < (int32_t)uVar28) {
                iVar16 = (int64_t)(int32_t)uVar23;
                uVar23 = uVar25 + 2;
                var_300h._0_4_ = uVar23;
                var_308h = iVar4;
                uVar8 = *(undefined *)(iVar16 + uVar20);
            } else {
                uVar8 = 0;
            }
            if ((int32_t)uVar23 < (int32_t)uVar28) {
                iVar16 = (int64_t)(int32_t)uVar23;
                uVar23 = uVar23 + 1;
                var_300h._0_4_ = uVar23;
                uVar9 = *(undefined *)(iVar16 + uVar20);
            } else {
                uVar9 = 0;
            }
            if ((int32_t)uVar23 < (int32_t)uVar28) {
                iVar16 = (int64_t)(int32_t)uVar23;
                uVar23 = uVar23 + 1;
                var_300h._0_4_ = uVar23;
                uVar10 = *(undefined *)(iVar16 + uVar20);
            } else {
                uVar10 = 0;
            }
            if ((int32_t)uVar23 < (int32_t)uVar28) {
                iVar16 = (int64_t)(int32_t)uVar23;
                uVar23 = uVar23 + 1;
                var_300h._0_4_ = uVar23;
                uVar11 = *(undefined *)(iVar16 + uVar20);
            } else {
                uVar11 = 0;
            }
            fVar30 = (float)CONCAT31(CONCAT21(CONCAT11(uVar8, uVar9), uVar10), uVar11) * 1.525879e-05;
        } else {
            if (((uVar6 & 0xe0) == 0) && (uVar6 != 0x1c)) goto code_r0x000180121c00;
            if ((int32_t)uVar28 < (int32_t)uVar25) {
code_r0x0001801225d5:
                var_300h._0_4_ = uVar28;
            } else {
                var_300h._0_4_ = uVar25;
                var_308h = iVar4;
                if ((int32_t)uVar25 < 0) goto code_r0x0001801225d5;
            }
            iVar12 = func_0x00018011fe40(&var_308h);
            var_318h = var_308h;
            fVar30 = (float)(int32_t)iVar12;
            uVar20 = var_308h;
            uVar23 = (uint32_t)var_300h;
            uVar28 = var_300h._4_4_;
        }
        iVar24 = (int32_t)var_328h;
        if ((int32_t)uVar29 < 0x30) {
            var_328h._0_4_ = 0;
            afStack_24c[(int64_t)(int32_t)uVar29 + 1] = fVar30;
            fVar30 = afStack_24c[1];
            fVar34 = afStack_24c[4];
            fVar35 = afStack_24c[2];
            fVar36 = afStack_24c[3];
            fVar37 = fStack_238;
            fVar38 = fStack_234;
            uVar17 = uVar29 + 1;
            uVar25 = uVar23;
            goto code_r0x000180121b7b;
        }
        goto code_r0x000180121c00;
    case 4:
        if (0 < (int32_t)uVar29) goto code_r0x000180121b6e;
        goto code_r0x000180121c00;
    case 5:
        if ((int32_t)uVar29 < 2) goto code_r0x000180121c00;
        do {
            func_0x000180121840(arg3);
            iVar13 = iVar22 + 3;
            iVar22 = iVar22 + 2;
        } while (iVar13 < (int32_t)uVar29);
        break;
    case 6:
        if ((int32_t)uVar29 < 1) goto code_r0x000180121c00;
        do {
            func_0x000180121840(arg3);
            iVar22 = iVar22 + 1;
code_r0x000180121c89:
            if ((int32_t)uVar29 <= iVar22) break;
            func_0x000180121840(arg3);
            iVar22 = iVar22 + 1;
        } while (iVar22 < (int32_t)uVar29);
        break;
    case 7:
        if (0 < (int32_t)uVar29) goto code_r0x000180121c89;
        goto code_r0x000180121c00;
    case 8:
        if ((int32_t)uVar29 < 6) goto code_r0x000180121c00;
        do {
            var_338h._0_4_ = afStack_24c[(int64_t)iVar22 + 6];
            var_340h._0_4_ = afStack_24c[(int64_t)iVar22 + 5];
            var_348h._0_4_ = afStack_24c[(int64_t)iVar22 + 4];
            fcn.1801218e0(arg3, uVar20, iVar26, placeholder_3, CONCAT44(var_348h._4_4_, (float)var_348h), 
                          CONCAT44(var_340h._4_4_, (float)var_340h), CONCAT44(var_338h._4_4_, (float)var_338h));
            iVar13 = iVar22 + 0xb;
            iVar22 = iVar22 + 6;
        } while (iVar13 < (int32_t)uVar29);
        break;
    case 10:
        if (iVar13 == 0) {
            if (*(int32_t *)(iStack_2d8 + 0x9c) != 0) {
                uVar25 = *(uint32_t *)(iStack_2d8 + 0x9c);
                pcVar2 = *(char **)(iStack_2d8 + 0x90);
                uVar28 = uVar25;
                if (((int32_t)uVar25 < 0) || (uVar28 = 0, (int32_t)uVar25 < 1)) {
code_r0x0001801220f1:
                    iVar13 = (int32_t)var_2ech + uVar28;
                    if ((((int32_t)uVar25 < iVar13) || (iVar13 < 0)) || ((int32_t)uVar25 <= iVar13)) {
                        uVar20 = 0;
                    } else {
                        uVar20 = (uint64_t)(uint8_t)pcVar2[iVar13];
                    }
code_r0x000180122111:
                    _var_318h = *(undefined (*) [16])(iStack_2d8 + 0x80);
                    puVar15 = (undefined4 *)
                              fcn.180120180((int64_t)auStack_258, (int64_t)&var_318h, uVar20, (uint64_t)uVar25, 
                                            CONCAT44(var_348h._4_4_, (float)var_348h));
                    auVar31 = *(undefined (*) [16])(iVar16 + 0x40);
                    var_328h._0_4_ = 0;
                    uStack_288 = *puVar15;
                    uStack_284 = puVar15[1];
                    uStack_280 = puVar15[2];
                    uStack_27c = puVar15[3];
                    uStack_2e0 = 0;
                    _var_318h = auVar31;
                    fcn.180120020((int64_t)&uStack_288, 0x12, 2, (int64_t)&uStack_2e0);
                    iVar13 = uStack_2e0._4_4_;
                    if ((uStack_2e0._4_4_ == 0) || ((int32_t)uStack_2e0 == 0)) goto code_r0x0001801220c3;
                    uStack_2c8 = 0;
                    uStack_2c0 = 0;
                    iVar24 = auVar31._12_4_;
                    if ((((-1 < uStack_2e0) && (-1 < (int32_t)uStack_2e0)) && (uStack_2e0._4_4_ <= iVar24)) &&
                       ((int32_t)uStack_2e0 <= iVar24 - uStack_2e0._4_4_)) {
                        uStack_2c0 = uStack_2e0 << 0x20;
                        uStack_2c8 = auVar31._0_8_ + (int64_t)uStack_2e0._4_4_;
                    }
                    uStack_288 = (undefined4)uStack_2c8;
                    uStack_284 = uStack_2c8._4_4_;
                    uStack_280 = 0;
                    uStack_27c = uStack_2c0._4_4_;
                    fcn.180120020((int64_t)&uStack_288, 0x13, 1, (int64_t)&var_328h);
                    if ((int32_t)var_328h == 0) goto code_r0x0001801220c3;
                    iVar13 = (int32_t)var_328h + iVar13;
                    if (iVar24 < iVar13) {
code_r0x0001801221ee:
                        var_310h._0_4_ = iVar24;
                    } else {
                        var_310h._0_4_ = iVar13;
                        if (iVar13 < 0) goto code_r0x0001801221ee;
                    }
                    fcn.18011fd30((int64_t)&uStack_2a8, (int64_t)&var_318h);
                } else {
                    uVar28 = 1;
                    if (*pcVar2 == '\0') goto code_r0x0001801220f1;
                    if (*pcVar2 == '\x03') {
                        if ((int32_t)uVar25 < 2) {
                            uVar17 = 0;
                            uVar23 = 0;
                            uVar5 = 0;
                        } else if ((int32_t)uVar25 < 3) {
                            uVar17 = (uint32_t)(uint8_t)pcVar2[1] << 8;
                            uVar23 = 0;
                            uVar5 = 0;
                            uVar28 = 2;
                        } else {
                            uVar28 = 3;
                            uVar17 = (uint32_t)CONCAT11(pcVar2[1], pcVar2[2]);
                            if ((int32_t)uVar25 < 4) {
                                uVar23 = 0;
                                uVar5 = 0;
                            } else {
                                uVar23 = (uint32_t)(uint8_t)pcVar2[3];
                                uVar28 = 4;
                                if ((int32_t)uVar25 < 5) {
                                    uVar5 = 0;
                                } else {
                                    uVar5 = pcVar2[4];
                                    uVar28 = 5;
                                }
                            }
                        }
                        uVar23 = uVar23 << 8 | (uint32_t)uVar5;
                        if (uVar17 != 0) {
                            do {
                                if ((int32_t)uVar28 < (int32_t)uVar25) {
                                    uVar21 = uVar28 + 1;
                                    uVar20 = (uint64_t)(uint8_t)pcVar2[(int32_t)uVar28];
                                    if ((int32_t)uVar21 < (int32_t)uVar25) {
                                        uVar1 = uVar28 + 2;
                                        uVar18 = (uint32_t)(uint8_t)pcVar2[(int32_t)uVar21];
                                        if ((int32_t)uVar1 < (int32_t)uVar25) {
                                            uVar28 = uVar28 + 3;
                                            uVar5 = pcVar2[(int32_t)uVar1];
                                        } else {
                                            uVar5 = 0;
                                            uVar28 = uVar1;
                                        }
                                    } else {
                                        uVar18 = 0;
                                        uVar5 = 0;
                                        uVar28 = uVar21;
                                    }
                                } else {
                                    uVar20 = 0;
                                    uVar18 = 0;
                                    uVar5 = 0;
                                }
                                uVar21 = uVar18 << 8 | (uint32_t)uVar5;
                                if (((int32_t)uVar23 <= (int32_t)var_2ech) && ((int32_t)var_2ech < (int32_t)uVar21))
                                goto code_r0x000180122111;
                                iVar22 = iVar22 + 1;
                                uVar23 = uVar21;
                            } while (iVar22 < (int32_t)uVar17);
                        }
                    }
code_r0x0001801220c3:
                    uStack_2a8 = 0;
                    uStack_2a0 = 0;
                }
                uStack_268 = (undefined4)uStack_2a8;
                uStack_264 = uStack_2a8._4_4_;
                uStack_260 = (undefined4)uStack_2a0;
                uStack_25c = uStack_2a0._4_4_;
            }
            var_2ech._4_4_ = 1;
        }
        goto code_r0x000180122209;
    case 0xb:
        iVar16 = (int64_t)var_2f0h;
        if (0 < var_2f0h) goto code_r0x00018012233b;
        goto code_r0x000180121c00;
    case 0xc:
        if ((int32_t)uVar23 < (int32_t)var_300h._4_4_) {
            iVar16 = (int64_t)(int32_t)uVar23;
            uVar23 = uVar25 + 2;
            var_300h._0_4_ = uVar23;
            var_308h = iVar4;
            cVar7 = *(char *)(iVar16 + uVar20);
        } else {
            cVar7 = '\0';
        }
        if (cVar7 == '\"') {
            if ((int32_t)uVar29 < 7) goto code_r0x000180121c00;
            var_338h._0_4_ = 0.0;
            fcn.1801218e0(arg3, uVar20, 0x180000000, placeholder_3, CONCAT44(var_348h._4_4_, fVar36), 
                          CONCAT44(var_340h._4_4_, fVar34), (uint64_t)var_338h._4_4_ << 0x20);
            fVar33 = (float)((uint32_t)fVar36 ^ 0x80000000);
            var_338h._0_4_ = 0.0;
            var_340h._0_4_ = fStack_230;
        } else if (cVar7 == '#') {
            if ((int32_t)uVar29 < 0xd) goto code_r0x000180121c00;
            fcn.1801218e0(arg3, uVar20, 0x180000000, placeholder_3, CONCAT44(var_348h._4_4_, fVar34), 
                          CONCAT44(var_340h._4_4_, fVar37), CONCAT44(var_338h._4_4_, fVar38));
            var_338h._0_4_ = fStack_21c;
            var_340h._0_4_ = fStack_220;
            fVar33 = fStack_224;
        } else if (cVar7 == '$') {
            if ((int32_t)uVar29 < 9) goto code_r0x000180121c00;
            var_338h._0_4_ = 0.0;
            fcn.1801218e0(arg3, uVar20, 0x180000000, placeholder_3, CONCAT44(var_348h._4_4_, fVar34), 
                          CONCAT44(var_340h._4_4_, fVar37), (uint64_t)var_338h._4_4_ << 0x20);
            var_338h._0_4_ = (float)((uint32_t)(fVar35 + fVar34 + fVar33) ^ 0x80000000);
            var_340h._0_4_ = fStack_228;
        } else {
            if ((cVar7 != '%') || ((int32_t)uVar29 < 0xb)) goto code_r0x000180121c00;
            fVar33 = fVar36 + fVar30 + fVar37 + fStack_230 + fStack_228;
            fVar32 = fVar35 + fVar34 + fVar38 + fStack_22c + fStack_224;
            if ((float)((uint32_t)fVar33 & 0x7fffffff) <= (float)((uint32_t)fVar32 & 0x7fffffff)) {
                fVar33 = (float)((uint32_t)fVar33 ^ 0x80000000);
                fVar32 = fStack_220;
            } else {
                fVar32 = (float)((uint32_t)fVar32 ^ 0x80000000);
                fVar33 = fStack_220;
            }
            fcn.1801218e0(arg3, uVar20, 0x180000000, placeholder_3, CONCAT44(var_348h._4_4_, fVar34), 
                          CONCAT44(var_340h._4_4_, fVar37), CONCAT44(var_338h._4_4_, fVar38));
            var_338h._0_4_ = fVar32;
            var_340h._0_4_ = fVar33;
            fVar33 = fStack_224;
        }
        var_348h._0_4_ = fVar33;
        fcn.1801218e0(arg3, uVar20, iVar26, placeholder_3, CONCAT44(var_348h._4_4_, fVar33), 
                      CONCAT44(var_340h._4_4_, (float)var_340h), CONCAT44(var_338h._4_4_, (float)var_338h));
        break;
    case 0xe:
        func_0x0001801216c0(arg3);
        iVar24 = (int32_t)var_328h;
        goto code_r0x000180121c00;
    case 0x13:
    case 0x14:
        if (var_2f8h._4_4_ != 0) {
            var_2f8h._0_4_ = (int32_t)var_2f8h + (int32_t)uVar29 / 2;
            uVar20 = var_318h;
        }
        iVar13 = (int32_t)var_2f8h + 7;
        var_2f8h._4_4_ = 0;
        if (iVar13 < 0) {
            iVar13 = (int32_t)var_2f8h + 0xe;
        }
        var_300h._0_4_ = uVar23 + (iVar13 >> 3);
        if (((int32_t)uVar28 < (int32_t)(uint32_t)var_300h) || ((int32_t)(uint32_t)var_300h < 0)) {
            var_300h._0_4_ = uVar28;
            var_308h = iVar4;
            uVar25 = uVar28;
        } else {
            var_308h = iVar4;
            uVar25 = (uint32_t)var_300h;
        }
        goto code_r0x000180121b7b;
    case 0x15:
        if (1 < (int32_t)uVar29) goto code_r0x000180121b6e;
        goto code_r0x000180121c00;
    case 0x16:
        if ((int32_t)uVar29 < 1) goto code_r0x000180121c00;
code_r0x000180121b6e:
        var_2f8h._4_4_ = 0;
        fcn.180121770(arg3);
        break;
    case 0x18:
        if ((int32_t)uVar29 < 8) goto code_r0x000180121c00;
        if (5 < (int32_t)(uVar29 - 2)) {
            do {
                iVar13 = iVar22;
                var_338h._0_4_ = afStack_24c[(int64_t)iVar13 + 6];
                var_340h._0_4_ = afStack_24c[(int64_t)iVar13 + 5];
                var_348h._0_4_ = afStack_24c[(int64_t)iVar13 + 4];
                fcn.1801218e0(arg3, uVar20, iVar26, placeholder_3, CONCAT44(var_348h._4_4_, (float)var_348h), 
                              CONCAT44(var_340h._4_4_, (float)var_340h), CONCAT44(var_338h._4_4_, (float)var_338h));
                iVar22 = iVar13 + 6;
            } while (iVar13 + 0xb < (int32_t)(uVar29 - 2));
            iVar24 = (int32_t)var_328h;
            if ((int32_t)uVar29 <= iVar13 + 7) goto code_r0x000180121c00;
        }
        func_0x000180121840(arg3);
        break;
    case 0x19:
        if ((int32_t)uVar29 < 8) goto code_r0x000180121c00;
        uVar27 = (uint64_t)(uVar29 - 6);
        if (1 < (int32_t)(uVar29 - 6)) {
            do {
                iVar13 = iVar22;
                func_0x000180121840(arg3);
                iVar22 = iVar13 + 2;
            } while (iVar13 + 3 < (int32_t)uVar27);
            iVar24 = (int32_t)var_328h;
            if ((int32_t)uVar29 <= iVar13 + 7) goto code_r0x000180121c00;
        }
        iVar16 = (int64_t)iVar22;
        var_338h._0_4_ = afStack_24c[iVar16 + 6];
        var_340h._0_4_ = afStack_24c[iVar16 + 5];
        var_348h._0_4_ = afStack_24c[iVar16 + 4];
        fcn.1801218e0(arg3, uVar20, iVar26, placeholder_3, CONCAT44(var_348h._4_4_, (float)var_348h), 
                      CONCAT44(var_340h._4_4_, (float)var_340h), CONCAT44(var_338h._4_4_, (float)var_338h));
        break;
    case 0x1a:
    case 0x1b:
        if (3 < (int32_t)uVar29) {
            uVar21 = uVar29 & 1;
            if ((uVar21 == 0) || (uVar25 = uVar23, (int32_t)(uVar21 + 3) < (int32_t)uVar29)) {
                do {
                    var_338h._0_4_ = afStack_24c[(int64_t)(int32_t)uVar21 + 4];
                    if (uVar6 == 0x1b) {
                        var_340h._0_4_ = (float)var_338h;
                        var_338h._0_4_ = 0.0;
                    } else {
                        var_340h._0_4_ = 0.0;
                    }
                    var_348h._0_4_ = afStack_24c[(int64_t)(int32_t)uVar21 + 3];
                    fcn.1801218e0(arg3, uVar20, iVar26, placeholder_3, CONCAT44(var_348h._4_4_, (float)var_348h), 
                                  CONCAT44(var_340h._4_4_, (float)var_340h), CONCAT44(var_338h._4_4_, (float)var_338h));
                    iVar13 = uVar21 + 7;
                    uVar21 = uVar21 + 4;
                } while (iVar13 < (int32_t)uVar29);
                break;
            }
            goto code_r0x000180121b7b;
        }
        goto code_r0x000180121c00;
    case 0x1d:
code_r0x000180122209:
        iVar13 = var_2f0h;
        iVar24 = (int32_t)var_328h;
        if (((int32_t)uVar29 < 1) || (iVar26 = (int64_t)var_2f0h, 9 < var_2f0h)) goto code_r0x000180121c00;
        auStack_188[iVar26 * 4] = (undefined4)var_308h;
        auStack_188[iVar26 * 4 + 1] = var_308h._4_4_;
        auStack_188[iVar26 * 4 + 2] = (uint32_t)var_300h;
        auStack_188[iVar26 * 4 + 3] = var_300h._4_4_;
        ppuVar19 = (uint8_t **)&uStack_268;
        if (uVar6 != 10) {
            ppuVar19 = (uint8_t **)(iVar16 + 0x60);
        }
        puVar3 = *ppuVar19;
        placeholder_3 = 0;
        uVar28 = *(uint32_t *)((int64_t)ppuVar19 + 0xc);
        uVar25 = 0;
        uVar17 = uVar25;
        if ((int32_t)uVar28 < 0) {
            placeholder_3 = (uint64_t)uVar28;
code_r0x000180122280:
            uVar23 = uVar17;
            uVar6 = 0;
        } else {
            if ((int32_t)uVar28 < 1) goto code_r0x000180122280;
            uVar23 = (uint32_t)*puVar3;
            placeholder_3 = 1;
            uVar17 = (uint32_t)*puVar3;
            if ((int32_t)uVar28 < 2) goto code_r0x000180122280;
            uVar6 = puVar3[1];
            placeholder_3 = 2;
        }
        uVar17 = uVar23 << 8 | (uint32_t)uVar6;
        if (uVar17 < 0x846c) {
            iVar24 = 0x46b;
            if (uVar17 < 0x4d8) {
                iVar24 = 0x6b;
            }
        } else {
            iVar24 = 0x8000;
        }
        uVar23 = (int32_t)afStack_24c[(int32_t)uVar29] + iVar24;
        if (((int32_t)uVar23 < 0) || ((int32_t)uVar17 <= (int32_t)uVar23)) {
            uStack_298 = 0;
            uStack_290 = 0;
        } else {
            auStack_2b8._8_4_ = (int32_t)placeholder_3;
            auStack_2b8._0_8_ = puVar3;
            uStack_2ac = uVar28;
            fcn.180120180((int64_t)&uStack_298, (int64_t)auStack_2b8, (uint64_t)uVar23, placeholder_3, 
                          CONCAT44(var_348h._4_4_, (float)var_348h));
        }
        var_300h = uStack_290;
        var_308h = uStack_298;
        uVar28 = (uint32_t)((uint64_t)uStack_290 >> 0x20);
        iVar24 = (int32_t)var_328h;
        if (uVar28 == 0) goto code_r0x000180121c00;
        var_2f0h = iVar13 + 1;
        var_300h._0_4_ = 0;
        var_300h._4_4_ = uVar28;
        var_318h = uStack_298;
        uVar20 = uStack_298;
        uVar29 = uVar29 - 1;
        iVar13 = var_2ech._4_4_;
        goto code_r0x000180121a92;
    case 0x1e:
        if ((int32_t)uVar29 < 4) goto code_r0x000180121c00;
        do {
            if (uVar29 - iVar22 == 5) {
                var_338h._0_4_ = afStack_24c[(int64_t)(iVar22 + 4) + 1];
            } else {
                var_338h._0_4_ = 0.0;
            }
            var_348h._0_4_ = afStack_24c[(int64_t)iVar22 + 3];
            var_340h._0_4_ = afStack_24c[(int64_t)iVar22 + 4];
            fcn.1801218e0(arg3, uVar20, iVar26, placeholder_3, CONCAT44(var_348h._4_4_, (float)var_348h), 
                          CONCAT44(var_340h._4_4_, (float)var_340h), CONCAT44(var_338h._4_4_, (float)var_338h));
            iVar13 = iVar22 + 4;
code_r0x000180121d20:
            if ((int32_t)uVar29 <= iVar13 + 3) break;
            iVar22 = iVar13 + 4;
            var_338h._0_4_ = afStack_24c[(int64_t)iVar13 + 4];
            if (uVar29 - iVar13 == 5) {
                var_340h._0_4_ = afStack_24c[(int64_t)iVar22 + 1];
            } else {
                var_340h._0_4_ = 0.0;
            }
            var_348h._0_4_ = afStack_24c[(int64_t)iVar13 + 3];
            fcn.1801218e0(arg3, uVar20, iVar26, placeholder_3, CONCAT44(var_348h._4_4_, (float)var_348h), 
                          CONCAT44(var_340h._4_4_, (float)var_340h), CONCAT44(var_338h._4_4_, (float)var_338h));
        } while (iVar13 + 7 < (int32_t)uVar29);
        break;
    case 0x1f:
        iVar13 = iVar22;
        if (3 < (int32_t)uVar29) goto code_r0x000180121d20;
        goto code_r0x000180121c00;
    }
    uVar20 = var_318h;
    uVar25 = uVar23;
code_r0x000180121b7b:
    uVar29 = 0;
    iVar13 = var_2ech._4_4_;
    if ((int32_t)var_328h == 0) {
        uVar29 = uVar17;
    }
    goto code_r0x000180121a92;
code_r0x00018012233b:
    var_2f0h = var_2f0h + -1;
    _var_308h = *(undefined (*) [16])(auStack_198 + iVar16 * 0x10);
    uVar28 = SUB164(_var_308h, 0xc);
    uVar20 = SUB168(_var_308h, 0);
    uVar25 = SUB164(_var_308h, 8);
    var_318h = uVar20;
    iVar13 = var_2ech._4_4_;
    goto code_r0x000180121a92;
}

// ============================================================
// Function: FUN_180122760
// Address: 0x180122760
// Size: 166 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f4h
// WARNING: [rz-ghidra] Removing arg arg_34h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_2fch
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

undefined4 fcn.180122760(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_90h)
{
    int32_t iVar1;
    undefined8 uVar2;
    undefined8 in_R9;
    int64_t in_stack_00000010;
    int64_t in_stack_000000c0;
    int64_t var_98h;
    int64_t var_90h;
    undefined auVar3 [16];
    int64_t var_70h;
    int64_t var_68h;
    undefined8 uStack_60;
    undefined auStack_58 [16];
    undefined auStack_48 [16];
    undefined8 uStack_38;
    int32_t iStack_30;
    
    uStack_60 = 1;
    var_98h = 0;
    _var_90h = ZEXT816(0);
    uStack_38 = 0;
    auVar3 = ZEXT816(0);
    iStack_30 = 0;
    auStack_58 = ZEXT816(0);
    auStack_48 = ZEXT816(0);
    iVar1 = fcn.180121980(arg1, arg2, (int64_t)&uStack_60, in_R9, 0, 0, 0, 0, 0, in_stack_00000010, in_stack_000000c0);
    if (iVar1 != 0) {
        uVar2 = fcn.18046d050((int64_t)iStack_30 * 0xe);
        *(undefined8 *)arg3 = uVar2;
        iVar1 = fcn.180121980(arg1, arg2 & 0xffffffff, (int64_t)&var_98h, in_R9, var_98h, var_90h, SUB168(_var_90h, 8), 
                              auVar3._0_8_, auVar3._8_8_, in_stack_00000010, in_stack_000000c0);
        if (iVar1 != 0) {
            return 0;
        }
    }
    *(undefined8 *)arg3 = 0;
    return 0;
}

// ============================================================
// Function: FUN_180122810
// Address: 0x180122810
// Size: 45 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_70h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_128h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_6h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f4h
// WARNING: [rz-ghidra] Removing arg arg_34h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_2fch
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

undefined8 fcn.180122810(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    undefined8 uVar2;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_00000030;
    int64_t in_stack_000000e0;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    undefined8 uStack_18;
    int32_t iStack_10;
    
    if (*(int32_t *)(arg1 + 0x4c) == 0) {
        uVar2 = fcn.1801208f0(arg1, arg2, arg3);
        return uVar2;
    }
    var_40h = 1;
    uStack_18 = 0;
    iStack_10 = 0;
    var_78h = 0;
    _var_38h = ZEXT816(0);
    _var_28h = ZEXT816(0);
    _var_70h = ZEXT816(0);
    iVar1 = fcn.180121980(arg1, arg2, (int64_t)&var_40h, in_R9, 0, 0, 0, 0, 0, in_stack_00000030, in_stack_000000e0);
    if (iVar1 != 0) {
        uVar2 = fcn.18046d050((int64_t)iStack_10 * 0xe);
        *(undefined8 *)arg3 = uVar2;
        iVar1 = fcn.180121980(arg1, arg2 & 0xffffffff, (int64_t)&var_78h, in_R9, var_78h, var_70h, SUB168(_var_70h, 8), 
                              0, 0, in_stack_00000030, in_stack_000000e0);
        if (iVar1 != 0) {
            return 0;
        }
    }
    *(undefined8 *)arg3 = 0;
    return 0;
}

// ============================================================
// Function: FUN_18012283d
// Address: 0x18012283d
// Size: 150 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_70h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_128h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_6h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f4h
// WARNING: [rz-ghidra] Removing arg arg_34h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_2fch
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

undefined8 fcn.180122810(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    undefined8 uVar2;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_00000030;
    int64_t in_stack_000000e0;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    undefined8 uStack_18;
    int32_t iStack_10;
    
    if (*(int32_t *)(arg1 + 0x4c) == 0) {
        uVar2 = fcn.1801208f0(arg1, arg2, arg3);
        return uVar2;
    }
    var_40h = 1;
    uStack_18 = 0;
    iStack_10 = 0;
    var_78h = 0;
    _var_38h = ZEXT816(0);
    _var_28h = ZEXT816(0);
    _var_70h = ZEXT816(0);
    iVar1 = fcn.180121980(arg1, arg2, (int64_t)&var_40h, in_R9, 0, 0, 0, 0, 0, in_stack_00000030, in_stack_000000e0);
    if (iVar1 != 0) {
        uVar2 = fcn.18046d050((int64_t)iStack_10 * 0xe);
        *(undefined8 *)arg3 = uVar2;
        iVar1 = fcn.180121980(arg1, arg2 & 0xffffffff, (int64_t)&var_78h, in_R9, var_78h, var_70h, SUB168(_var_70h, 8), 
                              0, 0, in_stack_00000030, in_stack_000000e0);
        if (iVar1 != 0) {
            return 0;
        }
    }
    *(undefined8 *)arg3 = 0;
    return 0;
}

// ============================================================
// Function: FUN_1801228d3
// Address: 0x1801228d3
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_70h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_128h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_6h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f4h
// WARNING: [rz-ghidra] Removing arg arg_34h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_2fch
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

undefined8 fcn.180122810(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    undefined8 uVar2;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_00000030;
    int64_t in_stack_000000e0;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    undefined8 uStack_18;
    int32_t iStack_10;
    
    if (*(int32_t *)(arg1 + 0x4c) == 0) {
        uVar2 = fcn.1801208f0(arg1, arg2, arg3);
        return uVar2;
    }
    var_40h = 1;
    uStack_18 = 0;
    iStack_10 = 0;
    var_78h = 0;
    _var_38h = ZEXT816(0);
    _var_28h = ZEXT816(0);
    _var_70h = ZEXT816(0);
    iVar1 = fcn.180121980(arg1, arg2, (int64_t)&var_40h, in_R9, 0, 0, 0, 0, 0, in_stack_00000030, in_stack_000000e0);
    if (iVar1 != 0) {
        uVar2 = fcn.18046d050((int64_t)iStack_10 * 0xe);
        *(undefined8 *)arg3 = uVar2;
        iVar1 = fcn.180121980(arg1, arg2 & 0xffffffff, (int64_t)&var_78h, in_R9, var_78h, var_70h, SUB168(_var_70h, 8), 
                              0, 0, in_stack_00000030, in_stack_000000e0);
        if (iVar1 != 0) {
            return 0;
        }
    }
    *(undefined8 *)arg3 = 0;
    return 0;
}

// ============================================================
// Function: FUN_1801228f0
// Address: 0x1801228f0
// Size: 27 bytes
// ============================================================
void fcn.1801228f0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h)
{
    float fVar1;
    int32_t iVar2;
    float fVar3;
    float in_XMM3_Da;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar2 = (int32_t)arg2;
    if ((((float)arg_28h != (float)arg_38h) && (fVar3 = *(float *)(arg3 + 0x1c), (float)arg_28h <= fVar3)) &&
       (fVar1 = *(float *)(arg3 + 0x18), fVar1 <= (float)arg_38h)) {
        if ((float)arg_28h < fVar1) {
            in_XMM3_Da = in_XMM3_Da +
                         ((fVar1 - (float)arg_28h) * ((float)arg_30h - in_XMM3_Da)) / ((float)arg_38h - (float)arg_28h);
            arg_28h._0_4_ = fVar1;
        }
        if (fVar3 < (float)arg_38h) {
            arg_30h._0_4_ =
                 (float)arg_30h +
                 ((fVar3 - (float)arg_38h) * ((float)arg_30h - in_XMM3_Da)) / ((float)arg_38h - (float)arg_28h);
            arg_38h._0_4_ = fVar3;
        }
        fVar3 = (float)iVar2;
        if ((in_XMM3_Da <= fVar3) && ((float)arg_30h <= fVar3)) {
            *(float *)(arg1 + (int64_t)iVar2 * 4) =
                 ((float)arg_38h - (float)arg_28h) * *(float *)(arg3 + 0x14) + *(float *)(arg1 + (int64_t)iVar2 * 4);
            return;
        }
        if ((in_XMM3_Da < (float)(iVar2 + 1)) || ((float)arg_30h < (float)(iVar2 + 1))) {
            *(float *)(arg1 + (int64_t)iVar2 * 4) =
                 (1.0 - ((in_XMM3_Da - fVar3) + ((float)arg_30h - fVar3)) * 0.5) *
                 ((float)arg_38h - (float)arg_28h) * *(float *)(arg3 + 0x14) + *(float *)(arg1 + (int64_t)iVar2 * 4);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18012290b
// Address: 0x18012290b
// Size: 194 bytes
// ============================================================
void fcn.1801228f0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h)
{
    float fVar1;
    int32_t iVar2;
    float fVar3;
    float in_XMM3_Da;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar2 = (int32_t)arg2;
    if ((((float)arg_28h != (float)arg_38h) && (fVar3 = *(float *)(arg3 + 0x1c), (float)arg_28h <= fVar3)) &&
       (fVar1 = *(float *)(arg3 + 0x18), fVar1 <= (float)arg_38h)) {
        if ((float)arg_28h < fVar1) {
            in_XMM3_Da = in_XMM3_Da +
                         ((fVar1 - (float)arg_28h) * ((float)arg_30h - in_XMM3_Da)) / ((float)arg_38h - (float)arg_28h);
            arg_28h._0_4_ = fVar1;
        }
        if (fVar3 < (float)arg_38h) {
            arg_30h._0_4_ =
                 (float)arg_30h +
                 ((fVar3 - (float)arg_38h) * ((float)arg_30h - in_XMM3_Da)) / ((float)arg_38h - (float)arg_28h);
            arg_38h._0_4_ = fVar3;
        }
        fVar3 = (float)iVar2;
        if ((in_XMM3_Da <= fVar3) && ((float)arg_30h <= fVar3)) {
            *(float *)(arg1 + (int64_t)iVar2 * 4) =
                 ((float)arg_38h - (float)arg_28h) * *(float *)(arg3 + 0x14) + *(float *)(arg1 + (int64_t)iVar2 * 4);
            return;
        }
        if ((in_XMM3_Da < (float)(iVar2 + 1)) || ((float)arg_30h < (float)(iVar2 + 1))) {
            *(float *)(arg1 + (int64_t)iVar2 * 4) =
                 (1.0 - ((in_XMM3_Da - fVar3) + ((float)arg_30h - fVar3)) * 0.5) *
                 ((float)arg_38h - (float)arg_28h) * *(float *)(arg3 + 0x14) + *(float *)(arg1 + (int64_t)iVar2 * 4);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801229cd
// Address: 0x1801229cd
// Size: 84 bytes
// ============================================================
void fcn.1801228f0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h)
{
    float fVar1;
    int32_t iVar2;
    float fVar3;
    float in_XMM3_Da;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar2 = (int32_t)arg2;
    if ((((float)arg_28h != (float)arg_38h) && (fVar3 = *(float *)(arg3 + 0x1c), (float)arg_28h <= fVar3)) &&
       (fVar1 = *(float *)(arg3 + 0x18), fVar1 <= (float)arg_38h)) {
        if ((float)arg_28h < fVar1) {
            in_XMM3_Da = in_XMM3_Da +
                         ((fVar1 - (float)arg_28h) * ((float)arg_30h - in_XMM3_Da)) / ((float)arg_38h - (float)arg_28h);
            arg_28h._0_4_ = fVar1;
        }
        if (fVar3 < (float)arg_38h) {
            arg_30h._0_4_ =
                 (float)arg_30h +
                 ((fVar3 - (float)arg_38h) * ((float)arg_30h - in_XMM3_Da)) / ((float)arg_38h - (float)arg_28h);
            arg_38h._0_4_ = fVar3;
        }
        fVar3 = (float)iVar2;
        if ((in_XMM3_Da <= fVar3) && ((float)arg_30h <= fVar3)) {
            *(float *)(arg1 + (int64_t)iVar2 * 4) =
                 ((float)arg_38h - (float)arg_28h) * *(float *)(arg3 + 0x14) + *(float *)(arg1 + (int64_t)iVar2 * 4);
            return;
        }
        if ((in_XMM3_Da < (float)(iVar2 + 1)) || ((float)arg_30h < (float)(iVar2 + 1))) {
            *(float *)(arg1 + (int64_t)iVar2 * 4) =
                 (1.0 - ((in_XMM3_Da - fVar3) + ((float)arg_30h - fVar3)) * 0.5) *
                 ((float)arg_38h - (float)arg_28h) * *(float *)(arg3 + 0x14) + *(float *)(arg1 + (int64_t)iVar2 * 4);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180122a21
// Address: 0x180122a21
// Size: 5 bytes
// ============================================================
void fcn.1801228f0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h)
{
    float fVar1;
    int32_t iVar2;
    float fVar3;
    float in_XMM3_Da;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar2 = (int32_t)arg2;
    if ((((float)arg_28h != (float)arg_38h) && (fVar3 = *(float *)(arg3 + 0x1c), (float)arg_28h <= fVar3)) &&
       (fVar1 = *(float *)(arg3 + 0x18), fVar1 <= (float)arg_38h)) {
        if ((float)arg_28h < fVar1) {
            in_XMM3_Da = in_XMM3_Da +
                         ((fVar1 - (float)arg_28h) * ((float)arg_30h - in_XMM3_Da)) / ((float)arg_38h - (float)arg_28h);
            arg_28h._0_4_ = fVar1;
        }
        if (fVar3 < (float)arg_38h) {
            arg_30h._0_4_ =
                 (float)arg_30h +
                 ((fVar3 - (float)arg_38h) * ((float)arg_30h - in_XMM3_Da)) / ((float)arg_38h - (float)arg_28h);
            arg_38h._0_4_ = fVar3;
        }
        fVar3 = (float)iVar2;
        if ((in_XMM3_Da <= fVar3) && ((float)arg_30h <= fVar3)) {
            *(float *)(arg1 + (int64_t)iVar2 * 4) =
                 ((float)arg_38h - (float)arg_28h) * *(float *)(arg3 + 0x14) + *(float *)(arg1 + (int64_t)iVar2 * 4);
            return;
        }
        if ((in_XMM3_Da < (float)(iVar2 + 1)) || ((float)arg_30h < (float)(iVar2 + 1))) {
            *(float *)(arg1 + (int64_t)iVar2 * 4) =
                 (1.0 - ((in_XMM3_Da - fVar3) + ((float)arg_30h - fVar3)) * 0.5) *
                 ((float)arg_38h - (float)arg_28h) * *(float *)(arg3 + 0x14) + *(float *)(arg1 + (int64_t)iVar2 * 4);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180122a26
// Address: 0x180122a26
// Size: 5 bytes
// ============================================================
void fcn.1801228f0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h)
{
    float fVar1;
    int32_t iVar2;
    float fVar3;
    float in_XMM3_Da;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar2 = (int32_t)arg2;
    if ((((float)arg_28h != (float)arg_38h) && (fVar3 = *(float *)(arg3 + 0x1c), (float)arg_28h <= fVar3)) &&
       (fVar1 = *(float *)(arg3 + 0x18), fVar1 <= (float)arg_38h)) {
        if ((float)arg_28h < fVar1) {
            in_XMM3_Da = in_XMM3_Da +
                         ((fVar1 - (float)arg_28h) * ((float)arg_30h - in_XMM3_Da)) / ((float)arg_38h - (float)arg_28h);
            arg_28h._0_4_ = fVar1;
        }
        if (fVar3 < (float)arg_38h) {
            arg_30h._0_4_ =
                 (float)arg_30h +
                 ((fVar3 - (float)arg_38h) * ((float)arg_30h - in_XMM3_Da)) / ((float)arg_38h - (float)arg_28h);
            arg_38h._0_4_ = fVar3;
        }
        fVar3 = (float)iVar2;
        if ((in_XMM3_Da <= fVar3) && ((float)arg_30h <= fVar3)) {
            *(float *)(arg1 + (int64_t)iVar2 * 4) =
                 ((float)arg_38h - (float)arg_28h) * *(float *)(arg3 + 0x14) + *(float *)(arg1 + (int64_t)iVar2 * 4);
            return;
        }
        if ((in_XMM3_Da < (float)(iVar2 + 1)) || ((float)arg_30h < (float)(iVar2 + 1))) {
            *(float *)(arg1 + (int64_t)iVar2 * 4) =
                 (1.0 - ((in_XMM3_Da - fVar3) + ((float)arg_30h - fVar3)) * 0.5) *
                 ((float)arg_38h - (float)arg_28h) * *(float *)(arg3 + 0x14) + *(float *)(arg1 + (int64_t)iVar2 * 4);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180122a2b
// Address: 0x180122a2b
// Size: 5 bytes
// ============================================================
void fcn.1801228f0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h)
{
    float fVar1;
    int32_t iVar2;
    float fVar3;
    float in_XMM3_Da;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar2 = (int32_t)arg2;
    if ((((float)arg_28h != (float)arg_38h) && (fVar3 = *(float *)(arg3 + 0x1c), (float)arg_28h <= fVar3)) &&
       (fVar1 = *(float *)(arg3 + 0x18), fVar1 <= (float)arg_38h)) {
        if ((float)arg_28h < fVar1) {
            in_XMM3_Da = in_XMM3_Da +
                         ((fVar1 - (float)arg_28h) * ((float)arg_30h - in_XMM3_Da)) / ((float)arg_38h - (float)arg_28h);
            arg_28h._0_4_ = fVar1;
        }
        if (fVar3 < (float)arg_38h) {
            arg_30h._0_4_ =
                 (float)arg_30h +
                 ((fVar3 - (float)arg_38h) * ((float)arg_30h - in_XMM3_Da)) / ((float)arg_38h - (float)arg_28h);
            arg_38h._0_4_ = fVar3;
        }
        fVar3 = (float)iVar2;
        if ((in_XMM3_Da <= fVar3) && ((float)arg_30h <= fVar3)) {
            *(float *)(arg1 + (int64_t)iVar2 * 4) =
                 ((float)arg_38h - (float)arg_28h) * *(float *)(arg3 + 0x14) + *(float *)(arg1 + (int64_t)iVar2 * 4);
            return;
        }
        if ((in_XMM3_Da < (float)(iVar2 + 1)) || ((float)arg_30h < (float)(iVar2 + 1))) {
            *(float *)(arg1 + (int64_t)iVar2 * 4) =
                 (1.0 - ((in_XMM3_Da - fVar3) + ((float)arg_30h - fVar3)) * 0.5) *
                 ((float)arg_38h - (float)arg_28h) * *(float *)(arg3 + 0x14) + *(float *)(arg1 + (int64_t)iVar2 * 4);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180122a30
// Address: 0x180122a30
// Size: 414 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180122a30(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    float fVar2;
    float fVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    uint64_t uVar12;
    int64_t iVar13;
    undefined4 *puVar14;
    uint32_t uVar15;
    uint64_t uVar16;
    uint32_t uVar17;
    uint32_t uVar18;
    int32_t iVar19;
    int64_t var_8h;
    int64_t var_10h;
    
    if (0xc < (int32_t)arg2) {
        uVar16 = arg2 & 0xffffffff;
        do {
            uVar12 = uVar16 >> 1;
            fVar2 = *(float *)(arg1 + (uVar12 * 5 + 1) * 4);
            fVar3 = *(float *)(arg1 + (uVar16 * 5 + -4) * 4);
            uVar17 = (int32_t)uVar16 - 1;
            if (*(float *)(arg1 + 4) < fVar2 != fVar2 < fVar3) {
                puVar1 = (undefined4 *)(arg1 + uVar12 * 5 * 4);
                uVar5 = puVar1[1];
                uVar6 = puVar1[2];
                uVar7 = puVar1[3];
                uVar18 = 0;
                if (*(float *)(arg1 + 4) < fVar3 != fVar2 < fVar3) {
                    uVar18 = uVar17;
                }
                iVar13 = (int64_t)(int32_t)uVar18;
                puVar14 = (undefined4 *)(arg1 + iVar13 * 5 * 4);
                uVar8 = *puVar14;
                uVar9 = puVar14[1];
                uVar10 = puVar14[2];
                uVar11 = puVar14[3];
                uVar4 = *(undefined4 *)(arg1 + (iVar13 * 5 + 4) * 4);
                puVar14 = (undefined4 *)(arg1 + iVar13 * 5 * 4);
                *puVar14 = *puVar1;
                puVar14[1] = uVar5;
                puVar14[2] = uVar6;
                puVar14[3] = uVar7;
                *(undefined4 *)(arg1 + (iVar13 * 5 + 4) * 4) = *(undefined4 *)(arg1 + (uVar12 * 5 + 4) * 4);
                puVar1 = (undefined4 *)(arg1 + uVar12 * 5 * 4);
                *puVar1 = uVar8;
                puVar1[1] = uVar9;
                puVar1[2] = uVar10;
                puVar1[3] = uVar11;
                *(undefined4 *)(arg1 + (uVar12 * 5 + 4) * 4) = uVar4;
            }
            puVar1 = (undefined4 *)(arg1 + uVar12 * 5 * 4);
            uVar6 = puVar1[1];
            uVar7 = puVar1[2];
            uVar4 = puVar1[3];
            uVar5 = *(undefined4 *)(arg1 + 0x10);
            uVar8 = *(undefined4 *)arg1;
            uVar9 = *(undefined4 *)(arg1 + 4);
            uVar10 = *(undefined4 *)(arg1 + 8);
            uVar11 = *(undefined4 *)(arg1 + 0xc);
            *(undefined4 *)arg1 = *puVar1;
            *(undefined4 *)(arg1 + 4) = uVar6;
            *(undefined4 *)(arg1 + 8) = uVar7;
            *(undefined4 *)(arg1 + 0xc) = uVar4;
            *(undefined4 *)(arg1 + 0x10) = *(undefined4 *)(arg1 + (uVar12 * 5 + 4) * 4);
            puVar1 = (undefined4 *)(arg1 + uVar12 * 5 * 4);
            *puVar1 = uVar8;
            puVar1[1] = uVar9;
            puVar1[2] = uVar10;
            puVar1[3] = uVar11;
            *(undefined4 *)(arg1 + (uVar12 * 5 + 4) * 4) = uVar5;
            iVar19 = 1;
            while( true ) {
                fVar2 = *(float *)(arg1 + 4);
                if (*(float *)(arg1 + ((int64_t)iVar19 * 5 + 1) * 4) <= fVar2 &&
                    fVar2 != *(float *)(arg1 + ((int64_t)iVar19 * 5 + 1) * 4)) {
                    do {
                        iVar19 = iVar19 + 1;
                    } while (*(float *)(arg1 + ((int64_t)iVar19 * 5 + 1) * 4) <= fVar2 &&
                             fVar2 != *(float *)(arg1 + ((int64_t)iVar19 * 5 + 1) * 4));
                }
                fVar3 = *(float *)(arg1 + ((int64_t)(int32_t)uVar17 * 5 + 1) * 4);
                while (fVar2 < fVar3) {
                    uVar17 = uVar17 - 1;
                    fVar3 = *(float *)(arg1 + ((int64_t)(int32_t)uVar17 * 5 + 1) * 4);
                }
                puVar1 = (undefined4 *)(arg1 + (int64_t)iVar19 * 5 * 4);
                if ((int32_t)uVar17 <= iVar19) break;
                uVar6 = *puVar1;
                uVar7 = puVar1[1];
                uVar4 = puVar1[2];
                uVar8 = puVar1[3];
                uVar5 = puVar1[4];
                iVar19 = iVar19 + 1;
                iVar13 = (int64_t)(int32_t)uVar17;
                uVar17 = uVar17 - 1;
                puVar14 = (undefined4 *)(arg1 + iVar13 * 5 * 4);
                uVar9 = puVar14[1];
                uVar10 = puVar14[2];
                uVar11 = puVar14[3];
                *puVar1 = *puVar14;
                puVar1[1] = uVar9;
                puVar1[2] = uVar10;
                puVar1[3] = uVar11;
                puVar1[4] = *(undefined4 *)(arg1 + (iVar13 * 5 + 4) * 4);
                puVar1 = (undefined4 *)(arg1 + iVar13 * 5 * 4);
                *puVar1 = uVar6;
                puVar1[1] = uVar7;
                puVar1[2] = uVar4;
                puVar1[3] = uVar8;
                *(undefined4 *)(arg1 + (iVar13 * 5 + 4) * 4) = uVar5;
            }
            uVar15 = (int32_t)uVar16 - iVar19;
            puVar14 = puVar1;
            uVar18 = uVar15;
            if ((int32_t)uVar17 < (int32_t)uVar15) {
                puVar14 = (undefined4 *)arg1;
                arg1 = (int64_t)puVar1;
                uVar18 = uVar17;
                uVar17 = uVar15;
            }
            uVar16 = (uint64_t)uVar17;
            fcn.180122a30((int64_t)puVar14, (uint64_t)uVar18);
        } while (0xc < (int32_t)uVar17);
    }
    return;
}

// ============================================================
// Function: FUN_180122bd0
// Address: 0x180122bd0
// Size: 41 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_a8h
// WARNING: Variable defined which should be unmapped: var_a0h
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_90h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.180122bd0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
             int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    float fVar2;
    float fVar3;
    float in_XMM2_Da;
    float in_XMM3_Da;
    float fVar4;
    float fVar5;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    if ((int32_t)arg_50h < 0x11) {
        fVar4 = ((float)arg_28h + (float)arg_28h + in_XMM2_Da + (float)arg_38h) * 0.25;
        fVar5 = ((float)arg_30h + (float)arg_30h + in_XMM3_Da + (float)arg_40h) * 0.25;
        fVar3 = (in_XMM2_Da + (float)arg_38h) * 0.5 - fVar4;
        fVar2 = (in_XMM3_Da + (float)arg_40h) * 0.5 - fVar5;
        if (fVar2 * fVar2 + fVar3 * fVar3 <= (float)arg_48h) {
            iVar1 = *(int32_t *)arg2;
            if (arg1 != 0) {
                *(float *)(arg1 + (int64_t)iVar1 * 8) = (float)arg_38h;
                *(float *)(arg1 + 4 + (int64_t)iVar1 * 8) = (float)arg_40h;
            }
            *(int32_t *)arg2 = iVar1 + 1;
        } else {
            fcn.180122bd0(arg1, arg2, placeholder_2, placeholder_3, 
                          CONCAT44(var_b8h._4_4_, (in_XMM2_Da + (float)arg_28h) * 0.5), 
                          CONCAT44(var_b0h._4_4_, (in_XMM3_Da + (float)arg_30h) * 0.5), CONCAT44(var_a8h._4_4_, fVar4), 
                          CONCAT44(var_a0h._4_4_, fVar5), CONCAT44(var_98h._4_4_, (float)arg_48h), 
                          CONCAT44(var_90h._4_4_, (int32_t)arg_50h + 1));
            fcn.180122bd0(arg1, arg2, placeholder_2, placeholder_3, 
                          CONCAT44(var_b8h._4_4_, ((float)arg_28h + (float)arg_38h) * 0.5), 
                          CONCAT44(var_b0h._4_4_, ((float)arg_30h + (float)arg_40h) * 0.5), 
                          CONCAT44(var_a8h._4_4_, (float)arg_38h), CONCAT44(var_a0h._4_4_, (float)arg_40h), 
                          CONCAT44(var_98h._4_4_, (float)arg_48h), CONCAT44(var_90h._4_4_, (int32_t)arg_50h + 1));
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_180122bf9
// Address: 0x180122bf9
// Size: 441 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_a8h
// WARNING: Variable defined which should be unmapped: var_a0h
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_90h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.180122bd0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
             int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    float fVar2;
    float fVar3;
    float in_XMM2_Da;
    float in_XMM3_Da;
    float fVar4;
    float fVar5;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    if ((int32_t)arg_50h < 0x11) {
        fVar4 = ((float)arg_28h + (float)arg_28h + in_XMM2_Da + (float)arg_38h) * 0.25;
        fVar5 = ((float)arg_30h + (float)arg_30h + in_XMM3_Da + (float)arg_40h) * 0.25;
        fVar3 = (in_XMM2_Da + (float)arg_38h) * 0.5 - fVar4;
        fVar2 = (in_XMM3_Da + (float)arg_40h) * 0.5 - fVar5;
        if (fVar2 * fVar2 + fVar3 * fVar3 <= (float)arg_48h) {
            iVar1 = *(int32_t *)arg2;
            if (arg1 != 0) {
                *(float *)(arg1 + (int64_t)iVar1 * 8) = (float)arg_38h;
                *(float *)(arg1 + 4 + (int64_t)iVar1 * 8) = (float)arg_40h;
            }
            *(int32_t *)arg2 = iVar1 + 1;
        } else {
            fcn.180122bd0(arg1, arg2, placeholder_2, placeholder_3, 
                          CONCAT44(var_b8h._4_4_, (in_XMM2_Da + (float)arg_28h) * 0.5), 
                          CONCAT44(var_b0h._4_4_, (in_XMM3_Da + (float)arg_30h) * 0.5), CONCAT44(var_a8h._4_4_, fVar4), 
                          CONCAT44(var_a0h._4_4_, fVar5), CONCAT44(var_98h._4_4_, (float)arg_48h), 
                          CONCAT44(var_90h._4_4_, (int32_t)arg_50h + 1));
            fcn.180122bd0(arg1, arg2, placeholder_2, placeholder_3, 
                          CONCAT44(var_b8h._4_4_, ((float)arg_28h + (float)arg_38h) * 0.5), 
                          CONCAT44(var_b0h._4_4_, ((float)arg_30h + (float)arg_40h) * 0.5), 
                          CONCAT44(var_a8h._4_4_, (float)arg_38h), CONCAT44(var_a0h._4_4_, (float)arg_40h), 
                          CONCAT44(var_98h._4_4_, (float)arg_48h), CONCAT44(var_90h._4_4_, (int32_t)arg_50h + 1));
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_180122db2
// Address: 0x180122db2
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_a8h
// WARNING: Variable defined which should be unmapped: var_a0h
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_90h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.180122bd0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
             int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    float fVar2;
    float fVar3;
    float in_XMM2_Da;
    float in_XMM3_Da;
    float fVar4;
    float fVar5;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    if ((int32_t)arg_50h < 0x11) {
        fVar4 = ((float)arg_28h + (float)arg_28h + in_XMM2_Da + (float)arg_38h) * 0.25;
        fVar5 = ((float)arg_30h + (float)arg_30h + in_XMM3_Da + (float)arg_40h) * 0.25;
        fVar3 = (in_XMM2_Da + (float)arg_38h) * 0.5 - fVar4;
        fVar2 = (in_XMM3_Da + (float)arg_40h) * 0.5 - fVar5;
        if (fVar2 * fVar2 + fVar3 * fVar3 <= (float)arg_48h) {
            iVar1 = *(int32_t *)arg2;
            if (arg1 != 0) {
                *(float *)(arg1 + (int64_t)iVar1 * 8) = (float)arg_38h;
                *(float *)(arg1 + 4 + (int64_t)iVar1 * 8) = (float)arg_40h;
            }
            *(int32_t *)arg2 = iVar1 + 1;
        } else {
            fcn.180122bd0(arg1, arg2, placeholder_2, placeholder_3, 
                          CONCAT44(var_b8h._4_4_, (in_XMM2_Da + (float)arg_28h) * 0.5), 
                          CONCAT44(var_b0h._4_4_, (in_XMM3_Da + (float)arg_30h) * 0.5), CONCAT44(var_a8h._4_4_, fVar4), 
                          CONCAT44(var_a0h._4_4_, fVar5), CONCAT44(var_98h._4_4_, (float)arg_48h), 
                          CONCAT44(var_90h._4_4_, (int32_t)arg_50h + 1));
            fcn.180122bd0(arg1, arg2, placeholder_2, placeholder_3, 
                          CONCAT44(var_b8h._4_4_, ((float)arg_28h + (float)arg_38h) * 0.5), 
                          CONCAT44(var_b0h._4_4_, ((float)arg_30h + (float)arg_40h) * 0.5), 
                          CONCAT44(var_a8h._4_4_, (float)arg_38h), CONCAT44(var_a0h._4_4_, (float)arg_40h), 
                          CONCAT44(var_98h._4_4_, (float)arg_48h), CONCAT44(var_90h._4_4_, (int32_t)arg_50h + 1));
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_180122dd0
// Address: 0x180122dd0
// Size: 421 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_e8h
// WARNING: Variable defined which should be unmapped: var_e0h
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_d0h
// WARNING: Variable defined which should be unmapped: var_c8h
// WARNING: Variable defined which should be unmapped: var_c0h
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180122dd0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_60h)
{
    int32_t iVar1;
    float fVar2;
    float in_XMM2_Da;
    float in_XMM3_Da;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_8h;
    
    fVar2 = ((float)arg_40h - (float)arg_30h) * ((float)arg_40h - (float)arg_30h) +
            ((float)arg_38h - (float)arg_28h) * ((float)arg_38h - (float)arg_28h);
    if (fVar2 < 0.0) {
        fVar2 = (float)func_0x000180494560(fVar2);
    } else {
        fVar2 = SQRT(fVar2);
    }
    fVar4 = ((float)arg_30h - in_XMM3_Da) * ((float)arg_30h - in_XMM3_Da) +
            ((float)arg_28h - in_XMM2_Da) * ((float)arg_28h - in_XMM2_Da);
    if (fVar4 < 0.0) {
        fVar4 = (float)func_0x000180494560(fVar4);
    } else {
        fVar4 = SQRT(fVar4);
    }
    fVar5 = ((float)arg_50h - (float)arg_40h) * ((float)arg_50h - (float)arg_40h) +
            ((float)arg_48h - (float)arg_38h) * ((float)arg_48h - (float)arg_38h);
    if (fVar5 < 0.0) {
        fVar5 = (float)func_0x000180494560(fVar5);
    } else {
        fVar5 = SQRT(fVar5);
    }
    fVar5 = fVar2 + fVar4 + fVar5;
    fVar2 = ((float)arg_50h - in_XMM3_Da) * ((float)arg_50h - in_XMM3_Da) +
            ((float)arg_48h - in_XMM2_Da) * ((float)arg_48h - in_XMM2_Da);
    if (fVar2 < 0.0) {
        fVar2 = (float)func_0x000180494560(fVar2);
    } else {
        fVar2 = SQRT(fVar2);
    }
    fVar2 = fVar5 * fVar5 - fVar2 * fVar2;
    while( true ) {
        if (0x10 < (int32_t)arg_60h) {
            return;
        }
        if (fVar2 <= (float)arg_58h) break;
        arg_60h._0_4_ = (int32_t)arg_60h + 1;
        fVar5 = (in_XMM3_Da + (float)arg_30h) * 0.5;
        fVar2 = ((float)arg_30h + (float)arg_40h) * 0.5;
        fVar8 = ((float)arg_28h + (float)arg_38h) * 0.5;
        fVar7 = ((float)arg_40h + (float)arg_50h) * 0.5;
        fVar6 = ((float)arg_38h + (float)arg_48h) * 0.5;
        fVar3 = (in_XMM2_Da + (float)arg_28h) * 0.5;
        arg_30h._0_4_ = (fVar7 + fVar2) * 0.5;
        fVar2 = (fVar2 + fVar5) * 0.5;
        fVar4 = (fVar8 + fVar3) * 0.5;
        arg_28h._0_4_ = (fVar6 + fVar8) * 0.5;
        in_XMM3_Da = ((float)arg_30h + fVar2) * 0.5;
        in_XMM2_Da = ((float)arg_28h + fVar4) * 0.5;
        fcn.180122dd0(arg1, arg2, placeholder_2, placeholder_3, CONCAT44(var_e8h._4_4_, fVar3), 
                      CONCAT44(var_e0h._4_4_, fVar5), CONCAT44(var_d8h._4_4_, fVar4), CONCAT44(var_d0h._4_4_, fVar2), 
                      CONCAT44(var_c8h._4_4_, in_XMM2_Da), CONCAT44(var_c0h._4_4_, in_XMM3_Da), 
                      CONCAT44(var_b8h._4_4_, (float)arg_58h), CONCAT44(var_b0h._4_4_, (int32_t)arg_60h));
        fVar2 = (fVar7 - (float)arg_30h) * (fVar7 - (float)arg_30h) +
                (fVar6 - (float)arg_28h) * (fVar6 - (float)arg_28h);
        if (fVar2 < 0.0) {
            fVar2 = (float)func_0x000180494560(fVar2);
        } else {
            fVar2 = SQRT(fVar2);
        }
        fVar4 = ((float)arg_30h - in_XMM3_Da) * ((float)arg_30h - in_XMM3_Da) +
                ((float)arg_28h - in_XMM2_Da) * ((float)arg_28h - in_XMM2_Da);
        if (fVar4 < 0.0) {
            fVar4 = (float)func_0x000180494560(fVar4);
        } else {
            fVar4 = SQRT(fVar4);
        }
        fVar5 = ((float)arg_50h - fVar7) * ((float)arg_50h - fVar7) +
                ((float)arg_48h - fVar6) * ((float)arg_48h - fVar6);
        if (fVar5 < 0.0) {
            fVar5 = (float)func_0x000180494560(fVar5);
        } else {
            fVar5 = SQRT(fVar5);
        }
        fVar5 = fVar2 + fVar4 + fVar5;
        fVar2 = ((float)arg_50h - in_XMM3_Da) * ((float)arg_50h - in_XMM3_Da) +
                ((float)arg_48h - in_XMM2_Da) * ((float)arg_48h - in_XMM2_Da);
        if (fVar2 < 0.0) {
            fVar2 = (float)func_0x000180494560(fVar2);
        } else {
            fVar2 = SQRT(fVar2);
        }
        arg_40h = (int64_t)(uint32_t)fVar7;
        arg_38h = (int64_t)(uint32_t)fVar6;
        fVar2 = fVar5 * fVar5 - fVar2 * fVar2;
    }
    iVar1 = *(int32_t *)arg2;
    if (arg1 != 0) {
        *(float *)(arg1 + (int64_t)iVar1 * 8) = (float)arg_48h;
        *(float *)(arg1 + 4 + (int64_t)iVar1 * 8) = (float)arg_50h;
    }
    *(int32_t *)arg2 = iVar1 + 1;
    return;
}

// ============================================================
// Function: FUN_180122f75
// Address: 0x180122f75
// Size: 691 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_e8h
// WARNING: Variable defined which should be unmapped: var_e0h
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_d0h
// WARNING: Variable defined which should be unmapped: var_c8h
// WARNING: Variable defined which should be unmapped: var_c0h
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180122dd0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_60h)
{
    int32_t iVar1;
    float fVar2;
    float in_XMM2_Da;
    float in_XMM3_Da;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_8h;
    
    fVar2 = ((float)arg_40h - (float)arg_30h) * ((float)arg_40h - (float)arg_30h) +
            ((float)arg_38h - (float)arg_28h) * ((float)arg_38h - (float)arg_28h);
    if (fVar2 < 0.0) {
        fVar2 = (float)func_0x000180494560(fVar2);
    } else {
        fVar2 = SQRT(fVar2);
    }
    fVar4 = ((float)arg_30h - in_XMM3_Da) * ((float)arg_30h - in_XMM3_Da) +
            ((float)arg_28h - in_XMM2_Da) * ((float)arg_28h - in_XMM2_Da);
    if (fVar4 < 0.0) {
        fVar4 = (float)func_0x000180494560(fVar4);
    } else {
        fVar4 = SQRT(fVar4);
    }
    fVar5 = ((float)arg_50h - (float)arg_40h) * ((float)arg_50h - (float)arg_40h) +
            ((float)arg_48h - (float)arg_38h) * ((float)arg_48h - (float)arg_38h);
    if (fVar5 < 0.0) {
        fVar5 = (float)func_0x000180494560(fVar5);
    } else {
        fVar5 = SQRT(fVar5);
    }
    fVar5 = fVar2 + fVar4 + fVar5;
    fVar2 = ((float)arg_50h - in_XMM3_Da) * ((float)arg_50h - in_XMM3_Da) +
            ((float)arg_48h - in_XMM2_Da) * ((float)arg_48h - in_XMM2_Da);
    if (fVar2 < 0.0) {
        fVar2 = (float)func_0x000180494560(fVar2);
    } else {
        fVar2 = SQRT(fVar2);
    }
    fVar2 = fVar5 * fVar5 - fVar2 * fVar2;
    while( true ) {
        if (0x10 < (int32_t)arg_60h) {
            return;
        }
        if (fVar2 <= (float)arg_58h) break;
        arg_60h._0_4_ = (int32_t)arg_60h + 1;
        fVar5 = (in_XMM3_Da + (float)arg_30h) * 0.5;
        fVar2 = ((float)arg_30h + (float)arg_40h) * 0.5;
        fVar8 = ((float)arg_28h + (float)arg_38h) * 0.5;
        fVar7 = ((float)arg_40h + (float)arg_50h) * 0.5;
        fVar6 = ((float)arg_38h + (float)arg_48h) * 0.5;
        fVar3 = (in_XMM2_Da + (float)arg_28h) * 0.5;
        arg_30h._0_4_ = (fVar7 + fVar2) * 0.5;
        fVar2 = (fVar2 + fVar5) * 0.5;
        fVar4 = (fVar8 + fVar3) * 0.5;
        arg_28h._0_4_ = (fVar6 + fVar8) * 0.5;
        in_XMM3_Da = ((float)arg_30h + fVar2) * 0.5;
        in_XMM2_Da = ((float)arg_28h + fVar4) * 0.5;
        fcn.180122dd0(arg1, arg2, placeholder_2, placeholder_3, CONCAT44(var_e8h._4_4_, fVar3), 
                      CONCAT44(var_e0h._4_4_, fVar5), CONCAT44(var_d8h._4_4_, fVar4), CONCAT44(var_d0h._4_4_, fVar2), 
                      CONCAT44(var_c8h._4_4_, in_XMM2_Da), CONCAT44(var_c0h._4_4_, in_XMM3_Da), 
                      CONCAT44(var_b8h._4_4_, (float)arg_58h), CONCAT44(var_b0h._4_4_, (int32_t)arg_60h));
        fVar2 = (fVar7 - (float)arg_30h) * (fVar7 - (float)arg_30h) +
                (fVar6 - (float)arg_28h) * (fVar6 - (float)arg_28h);
        if (fVar2 < 0.0) {
            fVar2 = (float)func_0x000180494560(fVar2);
        } else {
            fVar2 = SQRT(fVar2);
        }
        fVar4 = ((float)arg_30h - in_XMM3_Da) * ((float)arg_30h - in_XMM3_Da) +
                ((float)arg_28h - in_XMM2_Da) * ((float)arg_28h - in_XMM2_Da);
        if (fVar4 < 0.0) {
            fVar4 = (float)func_0x000180494560(fVar4);
        } else {
            fVar4 = SQRT(fVar4);
        }
        fVar5 = ((float)arg_50h - fVar7) * ((float)arg_50h - fVar7) +
                ((float)arg_48h - fVar6) * ((float)arg_48h - fVar6);
        if (fVar5 < 0.0) {
            fVar5 = (float)func_0x000180494560(fVar5);
        } else {
            fVar5 = SQRT(fVar5);
        }
        fVar5 = fVar2 + fVar4 + fVar5;
        fVar2 = ((float)arg_50h - in_XMM3_Da) * ((float)arg_50h - in_XMM3_Da) +
                ((float)arg_48h - in_XMM2_Da) * ((float)arg_48h - in_XMM2_Da);
        if (fVar2 < 0.0) {
            fVar2 = (float)func_0x000180494560(fVar2);
        } else {
            fVar2 = SQRT(fVar2);
        }
        arg_40h = (int64_t)(uint32_t)fVar7;
        arg_38h = (int64_t)(uint32_t)fVar6;
        fVar2 = fVar5 * fVar5 - fVar2 * fVar2;
    }
    iVar1 = *(int32_t *)arg2;
    if (arg1 != 0) {
        *(float *)(arg1 + (int64_t)iVar1 * 8) = (float)arg_48h;
        *(float *)(arg1 + 4 + (int64_t)iVar1 * 8) = (float)arg_50h;
    }
    *(int32_t *)arg2 = iVar1 + 1;
    return;
}

// ============================================================
// Function: FUN_180123228
// Address: 0x180123228
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_e8h
// WARNING: Variable defined which should be unmapped: var_e0h
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_d0h
// WARNING: Variable defined which should be unmapped: var_c8h
// WARNING: Variable defined which should be unmapped: var_c0h
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180122dd0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_60h)
{
    int32_t iVar1;
    float fVar2;
    float in_XMM2_Da;
    float in_XMM3_Da;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_8h;
    
    fVar2 = ((float)arg_40h - (float)arg_30h) * ((float)arg_40h - (float)arg_30h) +
            ((float)arg_38h - (float)arg_28h) * ((float)arg_38h - (float)arg_28h);
    if (fVar2 < 0.0) {
        fVar2 = (float)func_0x000180494560(fVar2);
    } else {
        fVar2 = SQRT(fVar2);
    }
    fVar4 = ((float)arg_30h - in_XMM3_Da) * ((float)arg_30h - in_XMM3_Da) +
            ((float)arg_28h - in_XMM2_Da) * ((float)arg_28h - in_XMM2_Da);
    if (fVar4 < 0.0) {
        fVar4 = (float)func_0x000180494560(fVar4);
    } else {
        fVar4 = SQRT(fVar4);
    }
    fVar5 = ((float)arg_50h - (float)arg_40h) * ((float)arg_50h - (float)arg_40h) +
            ((float)arg_48h - (float)arg_38h) * ((float)arg_48h - (float)arg_38h);
    if (fVar5 < 0.0) {
        fVar5 = (float)func_0x000180494560(fVar5);
    } else {
        fVar5 = SQRT(fVar5);
    }
    fVar5 = fVar2 + fVar4 + fVar5;
    fVar2 = ((float)arg_50h - in_XMM3_Da) * ((float)arg_50h - in_XMM3_Da) +
            ((float)arg_48h - in_XMM2_Da) * ((float)arg_48h - in_XMM2_Da);
    if (fVar2 < 0.0) {
        fVar2 = (float)func_0x000180494560(fVar2);
    } else {
        fVar2 = SQRT(fVar2);
    }
    fVar2 = fVar5 * fVar5 - fVar2 * fVar2;
    while( true ) {
        if (0x10 < (int32_t)arg_60h) {
            return;
        }
        if (fVar2 <= (float)arg_58h) break;
        arg_60h._0_4_ = (int32_t)arg_60h + 1;
        fVar5 = (in_XMM3_Da + (float)arg_30h) * 0.5;
        fVar2 = ((float)arg_30h + (float)arg_40h) * 0.5;
        fVar8 = ((float)arg_28h + (float)arg_38h) * 0.5;
        fVar7 = ((float)arg_40h + (float)arg_50h) * 0.5;
        fVar6 = ((float)arg_38h + (float)arg_48h) * 0.5;
        fVar3 = (in_XMM2_Da + (float)arg_28h) * 0.5;
        arg_30h._0_4_ = (fVar7 + fVar2) * 0.5;
        fVar2 = (fVar2 + fVar5) * 0.5;
        fVar4 = (fVar8 + fVar3) * 0.5;
        arg_28h._0_4_ = (fVar6 + fVar8) * 0.5;
        in_XMM3_Da = ((float)arg_30h + fVar2) * 0.5;
        in_XMM2_Da = ((float)arg_28h + fVar4) * 0.5;
        fcn.180122dd0(arg1, arg2, placeholder_2, placeholder_3, CONCAT44(var_e8h._4_4_, fVar3), 
                      CONCAT44(var_e0h._4_4_, fVar5), CONCAT44(var_d8h._4_4_, fVar4), CONCAT44(var_d0h._4_4_, fVar2), 
                      CONCAT44(var_c8h._4_4_, in_XMM2_Da), CONCAT44(var_c0h._4_4_, in_XMM3_Da), 
                      CONCAT44(var_b8h._4_4_, (float)arg_58h), CONCAT44(var_b0h._4_4_, (int32_t)arg_60h));
        fVar2 = (fVar7 - (float)arg_30h) * (fVar7 - (float)arg_30h) +
                (fVar6 - (float)arg_28h) * (fVar6 - (float)arg_28h);
        if (fVar2 < 0.0) {
            fVar2 = (float)func_0x000180494560(fVar2);
        } else {
            fVar2 = SQRT(fVar2);
        }
        fVar4 = ((float)arg_30h - in_XMM3_Da) * ((float)arg_30h - in_XMM3_Da) +
                ((float)arg_28h - in_XMM2_Da) * ((float)arg_28h - in_XMM2_Da);
        if (fVar4 < 0.0) {
            fVar4 = (float)func_0x000180494560(fVar4);
        } else {
            fVar4 = SQRT(fVar4);
        }
        fVar5 = ((float)arg_50h - fVar7) * ((float)arg_50h - fVar7) +
                ((float)arg_48h - fVar6) * ((float)arg_48h - fVar6);
        if (fVar5 < 0.0) {
            fVar5 = (float)func_0x000180494560(fVar5);
        } else {
            fVar5 = SQRT(fVar5);
        }
        fVar5 = fVar2 + fVar4 + fVar5;
        fVar2 = ((float)arg_50h - in_XMM3_Da) * ((float)arg_50h - in_XMM3_Da) +
                ((float)arg_48h - in_XMM2_Da) * ((float)arg_48h - in_XMM2_Da);
        if (fVar2 < 0.0) {
            fVar2 = (float)func_0x000180494560(fVar2);
        } else {
            fVar2 = SQRT(fVar2);
        }
        arg_40h = (int64_t)(uint32_t)fVar7;
        arg_38h = (int64_t)(uint32_t)fVar6;
        fVar2 = fVar5 * fVar5 - fVar2 * fVar2;
    }
    iVar1 = *(int32_t *)arg2;
    if (arg1 != 0) {
        *(float *)(arg1 + (int64_t)iVar1 * 8) = (float)arg_48h;
        *(float *)(arg1 + 4 + (int64_t)iVar1 * 8) = (float)arg_50h;
    }
    *(int32_t *)arg2 = iVar1 + 1;
    return;
}

// ============================================================
// Function: FUN_180123270
// Address: 0x180123270
// Size: 2678 bytes
// ============================================================
void fcn.180123270(int64_t arg1)
{
    int64_t var_28h;
    int64_t var_18h;
    
    if (arg1 == 0) {
        arg1 = *(int64_t *)0x180781f28 + 0xd90;
    }
    *(undefined4 *)(arg1 + 0x140) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x144) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x148) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x14c) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x150) = 0x3f000000;
    *(undefined4 *)(arg1 + 0x154) = 0x3f000000;
    *(undefined4 *)(arg1 + 0x158) = 0x3f000000;
    *(undefined4 *)(arg1 + 0x15c) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x160) = 0x3d75c28f;
    *(undefined4 *)(arg1 + 0x164) = 0x3d75c28f;
    *(undefined4 *)(arg1 + 0x168) = 0x3d75c28f;
    *(undefined8 *)(arg1 + 0x16c) = 0x3f70a3d7;
    *(undefined8 *)(arg1 + 0x174) = 0;
    *(undefined4 *)(arg1 + 0x17c) = 0;
    *(undefined4 *)(arg1 + 0x180) = 0x3da3d70a;
    *(undefined4 *)(arg1 + 0x184) = 0x3da3d70a;
    *(undefined4 *)(arg1 + 0x188) = 0x3da3d70a;
    *(undefined4 *)(arg1 + 0x18c) = 0x3f70a3d7;
    *(undefined4 *)(arg1 + 400) = 0x3edc28f6;
    *(undefined4 *)(arg1 + 0x194) = 0x3edc28f6;
    *(undefined4 *)(arg1 + 0x198) = 0x3f000000;
    *(undefined8 *)(arg1 + 0x19c) = 0x3f000000;
    *(undefined8 *)(arg1 + 0x1a4) = 0;
    *(undefined4 *)(arg1 + 0x1ac) = 0;
    *(undefined4 *)(arg1 + 0x1b0) = 0x3e23d70a;
    *(undefined4 *)(arg1 + 0x1b4) = 0x3e947ae1;
    *(undefined4 *)(arg1 + 0x1b8) = 0x3ef5c28f;
    *(undefined4 *)(arg1 + 0x1bc) = 0x3f0a3d71;
    *(undefined4 *)(arg1 + 0x1c0) = 0x3e851eb8;
    *(undefined4 *)(arg1 + 0x1c4) = 0x3f170a3d;
    *(undefined4 *)(arg1 + 0x1c8) = 0x3f7ae148;
    *(undefined4 *)(arg1 + 0x1cc) = 0x3ecccccd;
    *(undefined4 *)(arg1 + 0x1d0) = 0x3e851eb8;
    *(undefined4 *)(arg1 + 0x1d4) = 0x3f170a3d;
    *(undefined4 *)(arg1 + 0x1d8) = 0x3f7ae148;
    *(undefined4 *)(arg1 + 0x1dc) = 0x3f2b851f;
    *(undefined4 *)(arg1 + 0x1e0) = 0x3d23d70a;
    *(undefined4 *)(arg1 + 0x1e4) = 0x3d23d70a;
    *(undefined4 *)(arg1 + 0x1e8) = 0x3d23d70a;
    *(undefined4 *)(arg1 + 0x1ec) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x1f0) = 0x3e23d70a;
    *(undefined4 *)(arg1 + 500) = 0x3e947ae1;
    *(undefined4 *)(arg1 + 0x1f8) = 0x3ef5c28f;
    *(undefined8 *)(arg1 + 0x1fc) = 0x3f800000;
    *(undefined8 *)(arg1 + 0x204) = 0;
    *(undefined4 *)(arg1 + 0x20c) = 0x3f028f5c;
    *(undefined4 *)(arg1 + 0x210) = 0x3e0f5c29;
    *(undefined4 *)(arg1 + 0x214) = 0x3e0f5c29;
    *(undefined4 *)(arg1 + 0x218) = 0x3e0f5c29;
    *(undefined4 *)(arg1 + 0x21c) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x220) = 0x3ca3d70a;
    *(undefined4 *)(arg1 + 0x224) = 0x3ca3d70a;
    *(undefined4 *)(arg1 + 0x228) = 0x3ca3d70a;
    *(undefined4 *)(arg1 + 0x22c) = 0x3f07ae14;
    *(undefined4 *)(arg1 + 0x230) = 0x3e9eb852;
    *(undefined4 *)(arg1 + 0x234) = 0x3e9eb852;
    *(undefined4 *)(arg1 + 0x238) = 0x3e9eb852;
    *(undefined4 *)(arg1 + 0x23c) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x240) = 0x3ed1eb85;
    *(undefined4 *)(arg1 + 0x244) = 0x3ed1eb85;
    *(undefined4 *)(arg1 + 0x248) = 0x3ed1eb85;
    *(undefined4 *)(arg1 + 0x24c) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x250) = 0x3f028f5c;
    *(undefined4 *)(arg1 + 0x254) = 0x3f028f5c;
    *(undefined4 *)(arg1 + 600) = 0x3f028f5c;
    *(undefined4 *)(arg1 + 0x25c) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x260) = 0x3e851eb8;
    *(undefined4 *)(arg1 + 0x264) = 0x3f170a3d;
    *(undefined4 *)(arg1 + 0x268) = 0x3f7ae148;
    *(undefined4 *)(arg1 + 0x26c) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x270) = 0x3e75c28f;
    *(undefined4 *)(arg1 + 0x274) = 0x3f051eb8;
    *(undefined4 *)(arg1 + 0x278) = 0x3f6147ae;
    *(undefined4 *)(arg1 + 0x27c) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x280) = 0x3e851eb8;
    *(undefined4 *)(arg1 + 0x284) = 0x3f170a3d;
    *(undefined4 *)(arg1 + 0x288) = 0x3f7ae148;
    *(undefined4 *)(arg1 + 0x28c) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x290) = 0x3e851eb8;
    *(undefined4 *)(arg1 + 0x294) = 0x3f170a3d;
    *(undefined4 *)(arg1 + 0x298) = 0x3f7ae148;
    *(undefined4 *)(arg1 + 0x29c) = 0x3ecccccd;
    *(undefined4 *)(arg1 + 0x2a0) = 0x3e851eb8;
    *(undefined4 *)(arg1 + 0x2a4) = 0x3f170a3d;
    *(undefined4 *)(arg1 + 0x2a8) = 0x3f7ae148;
    *(undefined4 *)(arg1 + 0x2ac) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x2b0) = 0x3d75c28f;
    *(undefined4 *)(arg1 + 0x2b4) = 0x3f07ae14;
    *(undefined4 *)(arg1 + 0x2b8) = 0x3f7ae148;
    *(undefined4 *)(arg1 + 700) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x2c0) = 0x3e851eb8;
    *(undefined4 *)(arg1 + 0x2c4) = 0x3f170a3d;
    *(undefined4 *)(arg1 + 0x2c8) = 0x3f7ae148;
    *(undefined4 *)(arg1 + 0x2cc) = 0x3e9eb852;
    *(undefined4 *)(arg1 + 0x2d0) = 0x3e851eb8;
    *(undefined4 *)(arg1 + 0x2d4) = 0x3f170a3d;
    *(undefined4 *)(arg1 + 0x2d8) = 0x3f7ae148;
    *(undefined4 *)(arg1 + 0x2dc) = 0x3f4ccccd;
    *(undefined4 *)(arg1 + 0x2e0) = 0x3e851eb8;
    *(undefined4 *)(arg1 + 0x2e4) = 0x3f170a3d;
    *(undefined4 *)(arg1 + 0x2e8) = 0x3f7ae148;
    *(undefined4 *)(arg1 + 0x2ec) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x2f0) = *(undefined4 *)(arg1 + 400);
    *(undefined4 *)(arg1 + 0x2f4) = *(undefined4 *)(arg1 + 0x194);
    *(undefined4 *)(arg1 + 0x2f8) = *(undefined4 *)(arg1 + 0x198);
    *(undefined4 *)(arg1 + 0x2fc) = *(undefined4 *)(arg1 + 0x19c);
    *(undefined4 *)(arg1 + 0x300) = 0x3dcccccd;
    *(undefined4 *)(arg1 + 0x304) = 0x3ecccccd;
    *(undefined4 *)(arg1 + 0x308) = 0x3f400000;
    *(undefined4 *)(arg1 + 0x30c) = 0x3f47ae14;
    *(undefined4 *)(arg1 + 0x310) = 0x3dcccccd;
    *(undefined4 *)(arg1 + 0x314) = 0x3ecccccd;
    *(undefined4 *)(arg1 + 0x318) = 0x3f400000;
    *(undefined4 *)(arg1 + 0x31c) = 0x3f800000;
    *(undefined4 *)(arg1 + 800) = 0x3e851eb8;
    *(undefined4 *)(arg1 + 0x324) = 0x3f170a3d;
    *(undefined4 *)(arg1 + 0x328) = 0x3f7ae148;
    *(undefined4 *)(arg1 + 0x32c) = 0x3e4ccccd;
    *(undefined4 *)(arg1 + 0x330) = 0x3e851eb8;
    *(undefined4 *)(arg1 + 0x334) = 0x3f170a3d;
    *(undefined4 *)(arg1 + 0x338) = 0x3f7ae148;
    *(undefined4 *)(arg1 + 0x33c) = 0x3f2b851f;
    *(undefined4 *)(arg1 + 0x340) = 0x3e851eb8;
    *(undefined4 *)(arg1 + 0x344) = 0x3f170a3d;
    *(undefined4 *)(arg1 + 0x348) = 0x3f7ae148;
    *(undefined4 *)(arg1 + 0x34c) = 0x3f733333;
    *(undefined4 *)(arg1 + 0x350) = *(undefined4 *)(arg1 + 0x140);
    *(undefined4 *)(arg1 + 0x354) = *(undefined4 *)(arg1 + 0x144);
    *(undefined4 *)(arg1 + 0x358) = *(undefined4 *)(arg1 + 0x148);
    *(undefined4 *)(arg1 + 0x35c) = *(undefined4 *)(arg1 + 0x14c);
    *(undefined4 *)(arg1 + 0x360) = *(undefined4 *)(arg1 + 0x2d0);
    *(undefined4 *)(arg1 + 0x364) = *(undefined4 *)(arg1 + 0x2d4);
    *(undefined4 *)(arg1 + 0x368) = *(undefined4 *)(arg1 + 0x2d8);
    *(undefined4 *)(arg1 + 0x36c) = *(undefined4 *)(arg1 + 0x2dc);
    *(float *)(arg1 + 0x370) = (*(float *)(arg1 + 0x1f0) - *(float *)(arg1 + 0x2c0)) * 0.8 + *(float *)(arg1 + 0x2c0);
    *(float *)(arg1 + 0x374) = (*(float *)(arg1 + 500) - *(float *)(arg1 + 0x2c4)) * 0.8 + *(float *)(arg1 + 0x2c4);
    *(float *)(arg1 + 0x378) = (*(float *)(arg1 + 0x1f8) - *(float *)(arg1 + 0x2c8)) * 0.8 + *(float *)(arg1 + 0x2c8);
    *(float *)(arg1 + 0x37c) = (*(float *)(arg1 + 0x1fc) - *(float *)(arg1 + 0x2cc)) * 0.8 + *(float *)(arg1 + 0x2cc);
    *(float *)(arg1 + 0x380) = (*(float *)(arg1 + 0x1f0) - *(float *)(arg1 + 0x2e0)) * 0.6 + *(float *)(arg1 + 0x2e0);
    *(float *)(arg1 + 900) = (*(float *)(arg1 + 500) - *(float *)(arg1 + 0x2e4)) * 0.6 + *(float *)(arg1 + 0x2e4);
    *(float *)(arg1 + 0x388) = (*(float *)(arg1 + 0x1f8) - *(float *)(arg1 + 0x2e8)) * 0.6 + *(float *)(arg1 + 0x2e8);
    *(float *)(arg1 + 0x38c) = (*(float *)(arg1 + 0x1fc) - *(float *)(arg1 + 0x2ec)) * 0.6 + *(float *)(arg1 + 0x2ec);
    *(undefined4 *)(arg1 + 0x390) = *(undefined4 *)(arg1 + 0x2e0);
    *(undefined4 *)(arg1 + 0x394) = *(undefined4 *)(arg1 + 0x2e4);
    *(undefined4 *)(arg1 + 0x398) = *(undefined4 *)(arg1 + 0x2e8);
    *(undefined4 *)(arg1 + 0x39c) = *(undefined4 *)(arg1 + 0x2ec);
    *(float *)(arg1 + 0x3a0) = (*(float *)(arg1 + 0x1e0) - *(float *)(arg1 + 0x370)) * 0.8 + *(float *)(arg1 + 0x370);
    *(float *)(arg1 + 0x3a4) = (*(float *)(arg1 + 0x1e4) - *(float *)(arg1 + 0x374)) * 0.8 + *(float *)(arg1 + 0x374);
    *(float *)(arg1 + 0x3a8) = (*(float *)(arg1 + 0x1e8) - *(float *)(arg1 + 0x378)) * 0.8 + *(float *)(arg1 + 0x378);
    *(float *)(arg1 + 0x3ac) = (*(float *)(arg1 + 0x1ec) - *(float *)(arg1 + 0x37c)) * 0.8 + *(float *)(arg1 + 0x37c);
    *(float *)(arg1 + 0x3b0) = (*(float *)(arg1 + 0x1e0) - *(float *)(arg1 + 0x380)) * 0.4 + *(float *)(arg1 + 0x380);
    *(float *)(arg1 + 0x3b4) = (*(float *)(arg1 + 0x1e4) - *(float *)(arg1 + 900)) * 0.4 + *(float *)(arg1 + 900);
    *(float *)(arg1 + 0x3b8) = (*(float *)(arg1 + 0x1e8) - *(float *)(arg1 + 0x388)) * 0.4 + *(float *)(arg1 + 0x388);
    *(float *)(arg1 + 0x3bc) = (*(float *)(arg1 + 0x1ec) - *(float *)(arg1 + 0x38c)) * 0.4 + *(float *)(arg1 + 0x38c);
    *(undefined4 *)(arg1 + 0x3c0) = 0x3f000000;
    *(undefined4 *)(arg1 + 0x3c4) = 0x3f000000;
    *(undefined8 *)(arg1 + 0x3c8) = 0x3f000000;
    *(undefined4 *)(arg1 + 0x3d0) = *(undefined4 *)(arg1 + 0x2e0);
    *(undefined4 *)(arg1 + 0x3d4) = *(undefined4 *)(arg1 + 0x2e4);
    *(undefined4 *)(arg1 + 0x3d8) = *(undefined4 *)(arg1 + 0x2e8);
    *(float *)(arg1 + 0x3dc) = *(float *)(arg1 + 0x2ec) * 0.7;
    *(undefined4 *)(arg1 + 0x3e0) = 0x3e4ccccd;
    *(undefined4 *)(arg1 + 0x3e4) = 0x3e4ccccd;
    *(undefined4 *)(arg1 + 1000) = 0x3e4ccccd;
    *(undefined4 *)(arg1 + 0x3ec) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x3f0) = 0x3f1c28f6;
    *(undefined4 *)(arg1 + 0x3f4) = 0x3f1c28f6;
    *(undefined4 *)(arg1 + 0x3f8) = 0x3f1c28f6;
    *(undefined4 *)(arg1 + 0x3fc) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x400) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x404) = 0x3edc28f6;
    *(undefined4 *)(arg1 + 0x408) = 0x3eb33333;
    *(undefined4 *)(arg1 + 0x40c) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x410) = 0x3f666666;
    *(undefined8 *)(arg1 + 0x414) = 0x3f333333;
    *(undefined4 *)(arg1 + 0x41c) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x420) = 0x3f800000;
    *(undefined8 *)(arg1 + 0x424) = 0x3f19999a;
    *(undefined4 *)(arg1 + 0x42c) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x430) = 0x3e428f5c;
    *(undefined4 *)(arg1 + 0x434) = 0x3e428f5c;
    *(undefined4 *)(arg1 + 0x438) = 0x3e4ccccd;
    *(undefined4 *)(arg1 + 0x43c) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x440) = 0x3e9eb852;
    *(undefined4 *)(arg1 + 0x444) = 0x3e9eb852;
    *(undefined4 *)(arg1 + 0x448) = 0x3eb33333;
    *(undefined4 *)(arg1 + 0x44c) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x450) = 0x3e6b851f;
    *(undefined4 *)(arg1 + 0x454) = 0x3e6b851f;
    *(undefined4 *)(arg1 + 0x458) = 0x3e800000;
    *(undefined8 *)(arg1 + 0x45c) = 0x3f800000;
    *(undefined8 *)(arg1 + 0x464) = 0;
    *(undefined4 *)(arg1 + 0x46c) = 0;
    *(undefined4 *)(arg1 + 0x470) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x474) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x478) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x47c) = 0x3d75c28f;
    *(undefined4 *)(arg1 + 0x480) = *(undefined4 *)(arg1 + 0x2e0);
    *(undefined4 *)(arg1 + 0x484) = *(undefined4 *)(arg1 + 0x2e4);
    *(undefined4 *)(arg1 + 0x488) = *(undefined4 *)(arg1 + 0x2e8);
    *(undefined4 *)(arg1 + 0x48c) = *(undefined4 *)(arg1 + 0x2ec);
    *(undefined4 *)(arg1 + 0x490) = 0x3e851eb8;
    *(undefined4 *)(arg1 + 0x494) = 0x3f170a3d;
    *(undefined4 *)(arg1 + 0x498) = 0x3f7ae148;
    *(undefined4 *)(arg1 + 0x49c) = 0x3eb33333;
    *(undefined4 *)(arg1 + 0x4a0) = *(undefined4 *)(arg1 + 400);
    *(undefined4 *)(arg1 + 0x4a4) = *(undefined4 *)(arg1 + 0x194);
    *(undefined4 *)(arg1 + 0x4a8) = *(undefined4 *)(arg1 + 0x198);
    *(undefined4 *)(arg1 + 0x4ac) = *(undefined4 *)(arg1 + 0x19c);
    *(undefined4 *)(arg1 + 0x4b0) = 0x3f800000;
    *(undefined8 *)(arg1 + 0x4b4) = 0x3f800000;
    *(undefined8 *)(arg1 + 0x4bc) = 0x3f666666;
    *(undefined8 *)(arg1 + 0x4c4) = 0;
    *(undefined4 *)(arg1 + 0x4cc) = 0;
    *(undefined4 *)(arg1 + 0x4d0) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x4d4) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x4d8) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x4dc) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x4e0) = 0x3e851eb8;
    *(undefined4 *)(arg1 + 0x4e4) = 0x3f170a3d;
    *(undefined4 *)(arg1 + 0x4e8) = 0x3f7ae148;
    *(undefined4 *)(arg1 + 0x4ec) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x4f0) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x4f4) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x4f8) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x4fc) = 0x3f333333;
    *(undefined4 *)(arg1 + 0x500) = 0x3f4ccccd;
    *(undefined4 *)(arg1 + 0x504) = 0x3f4ccccd;
    *(undefined4 *)(arg1 + 0x508) = 0x3f4ccccd;
    *(undefined4 *)(arg1 + 0x50c) = 0x3e4ccccd;
    *(undefined4 *)(arg1 + 0x510) = 0x3f4ccccd;
    *(undefined4 *)(arg1 + 0x514) = 0x3f4ccccd;
    *(undefined4 *)(arg1 + 0x518) = 0x3f4ccccd;
    *(undefined4 *)(arg1 + 0x51c) = 0x3eb33333;
    return;
}

// ============================================================
// Function: FUN_180123cf0
// Address: 0x180123cf0
// Size: 45 bytes
// ============================================================
void fcn.180123cf0(int64_t arg1)
{
    if (*(int64_t *)(arg1 + 0x60) != 0) {
        func_0x000180460d90();
    }
    if (*(int64_t *)(arg1 + 0x50) != 0) {
        func_0x000180460d90();
    }
    return;
}

// ============================================================
// Function: FUN_180123d20
// Address: 0x180123d20
// Size: 173 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180123d20(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    int64_t var_10h;
    
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)(arg1 + 0x20) = 0;
    *(undefined8 *)(arg1 + 0x28) = 0;
    *(undefined8 *)(arg1 + 0x50) = 0;
    *(undefined8 *)(arg1 + 0x58) = 0;
    *(undefined8 *)(arg1 + 0x60) = 0;
    *(undefined8 *)(arg1 + 0x68) = 0;
    *(undefined8 *)(arg1 + 0x70) = 0;
    *(undefined8 *)(arg1 + 0x78) = 0;
    *(undefined (*) [16])(arg1 + 0x88) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x98) = 0;
    *(undefined8 *)(arg1 + 0xa0) = 0;
    *(undefined8 *)(arg1 + 0xa8) = 0;
    *(undefined8 *)(arg1 + 0xb0) = 0;
    *(undefined8 *)(arg1 + 0xb8) = 0;
    *(undefined8 *)(arg1 + 0xc0) = 0;
    *(undefined8 *)(arg1 + 200) = 0;
    fcn.1804986e0(arg1, 0, 0xe0);
    fcn.180123ed0(arg1, arg2);
    return arg1;
}

// ============================================================
// Function: FUN_180123dd0
// Address: 0x180123dd0
// Size: 255 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180123dd0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    int64_t var_8h;
    
    func_0x000180124110();
    iVar2 = *(int64_t *)(arg1 + 0x38);
    if (iVar2 != 0) {
        piVar3 = *(int64_t **)(iVar2 + 0x60);
        piVar1 = piVar3 + *(int32_t *)(iVar2 + 0x58);
        for (piVar4 = piVar3; piVar4 < piVar1; piVar4 = piVar4 + 1) {
            if (*piVar4 == arg1) {
                if (piVar4 < piVar1 + -1) {
                    piVar3[(int64_t)piVar4 - (int64_t)piVar3 >> 3] = piVar1[-1];
                }
                *(int32_t *)(iVar2 + 0x58) = *(int32_t *)(iVar2 + 0x58) + -1;
                break;
            }
        }
    }
    *(undefined8 *)(arg1 + 0x38) = 0;
    if (*(int64_t *)(arg1 + 200) != 0) {
        func_0x000180460d90();
    }
    if (*(int64_t *)(arg1 + 0xb8) != 0) {
        func_0x000180460d90();
    }
    if (*(int64_t *)(arg1 + 0xa8) != 0) {
        func_0x000180460d90();
    }
    func_0x000180126a10(arg1 + 0x88);
    if (*(int64_t *)(arg1 + 0x98) != 0) {
        func_0x000180460d90();
    }
    if (*(int64_t *)(arg1 + 0x58) != 0) {
        func_0x000180460d90();
    }
    if (*(int64_t *)(arg1 + 0x28) != 0) {
        func_0x000180460d90();
    }
    if (*(int64_t *)(arg1 + 0x18) != 0) {
        func_0x000180460d90();
    }
    if (*(int64_t *)(arg1 + 8) != 0) {
        func_0x000180460d90();
    }
    return;
}

// ============================================================
// Function: FUN_180123ed0
// Address: 0x180123ed0
// Size: 97 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180123ed0(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t var_8h;
    
    iVar3 = *(int64_t *)(arg1 + 0x38);
    if (iVar3 != 0) {
        piVar4 = *(int64_t **)(iVar3 + 0x60);
        piVar2 = piVar4 + *(int32_t *)(iVar3 + 0x58);
        for (piVar7 = piVar4; piVar7 < piVar2; piVar7 = piVar7 + 1) {
            if (*piVar7 == arg1) {
                if (piVar7 < piVar2 + -1) {
                    piVar4[(int64_t)piVar7 - (int64_t)piVar4 >> 3] = piVar2[-1];
                }
                *(int32_t *)(iVar3 + 0x58) = *(int32_t *)(iVar3 + 0x58) + -1;
                break;
            }
        }
    }
    *(int64_t *)(arg1 + 0x38) = arg2;
    if (arg2 != 0) {
        iVar5 = *(int32_t *)(arg2 + 0x5c);
        piVar1 = (int32_t *)(arg2 + 0x58);
        if (*(int32_t *)(arg2 + 0x58) == iVar5) {
            iVar6 = *(int32_t *)(arg2 + 0x58) + 1;
            if (iVar5 == 0) {
                iVar5 = 8;
            } else {
                iVar5 = iVar5 / 2 + iVar5;
            }
            if (iVar6 < iVar5) {
                iVar6 = iVar5;
            }
            func_0x00018011f4f0(piVar1, iVar6);
        }
        *(int64_t *)(*(int64_t *)(arg2 + 0x60) + (int64_t)*piVar1 * 8) = arg1;
        *piVar1 = *piVar1 + 1;
    }
    return;
}

// ============================================================
// Function: FUN_180123f31
// Address: 0x180123f31
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180123ed0(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t var_8h;
    
    iVar3 = *(int64_t *)(arg1 + 0x38);
    if (iVar3 != 0) {
        piVar4 = *(int64_t **)(iVar3 + 0x60);
        piVar2 = piVar4 + *(int32_t *)(iVar3 + 0x58);
        for (piVar7 = piVar4; piVar7 < piVar2; piVar7 = piVar7 + 1) {
            if (*piVar7 == arg1) {
                if (piVar7 < piVar2 + -1) {
                    piVar4[(int64_t)piVar7 - (int64_t)piVar4 >> 3] = piVar2[-1];
                }
                *(int32_t *)(iVar3 + 0x58) = *(int32_t *)(iVar3 + 0x58) + -1;
                break;
            }
        }
    }
    *(int64_t *)(arg1 + 0x38) = arg2;
    if (arg2 != 0) {
        iVar5 = *(int32_t *)(arg2 + 0x5c);
        piVar1 = (int32_t *)(arg2 + 0x58);
        if (*(int32_t *)(arg2 + 0x58) == iVar5) {
            iVar6 = *(int32_t *)(arg2 + 0x58) + 1;
            if (iVar5 == 0) {
                iVar5 = 8;
            } else {
                iVar5 = iVar5 / 2 + iVar5;
            }
            if (iVar6 < iVar5) {
                iVar6 = iVar5;
            }
            func_0x00018011f4f0(piVar1, iVar6);
        }
        *(int64_t *)(*(int64_t *)(arg2 + 0x60) + (int64_t)*piVar1 * 8) = arg1;
        *piVar1 = *piVar1 + 1;
    }
    return;
}

// ============================================================
// Function: FUN_180123f7a
// Address: 0x180123f7a
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180123ed0(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t var_8h;
    
    iVar3 = *(int64_t *)(arg1 + 0x38);
    if (iVar3 != 0) {
        piVar4 = *(int64_t **)(iVar3 + 0x60);
        piVar2 = piVar4 + *(int32_t *)(iVar3 + 0x58);
        for (piVar7 = piVar4; piVar7 < piVar2; piVar7 = piVar7 + 1) {
            if (*piVar7 == arg1) {
                if (piVar7 < piVar2 + -1) {
                    piVar4[(int64_t)piVar7 - (int64_t)piVar4 >> 3] = piVar2[-1];
                }
                *(int32_t *)(iVar3 + 0x58) = *(int32_t *)(iVar3 + 0x58) + -1;
                break;
            }
        }
    }
    *(int64_t *)(arg1 + 0x38) = arg2;
    if (arg2 != 0) {
        iVar5 = *(int32_t *)(arg2 + 0x5c);
        piVar1 = (int32_t *)(arg2 + 0x58);
        if (*(int32_t *)(arg2 + 0x58) == iVar5) {
            iVar6 = *(int32_t *)(arg2 + 0x58) + 1;
            if (iVar5 == 0) {
                iVar5 = 8;
            } else {
                iVar5 = iVar5 / 2 + iVar5;
            }
            if (iVar6 < iVar5) {
                iVar6 = iVar5;
            }
            func_0x00018011f4f0(piVar1, iVar6);
        }
        *(int64_t *)(*(int64_t *)(arg2 + 0x60) + (int64_t)*piVar1 * 8) = arg1;
        *piVar1 = *piVar1 + 1;
    }
    return;
}

// ============================================================
// Function: FUN_180123f80
// Address: 0x180123f80
// Size: 400 bytes
// ============================================================
void fcn.180123f80(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    
    if (1 < *(int32_t *)(arg1 + 0x8c)) {
        func_0x000180126c00(arg1 + 0x88, arg1);
    }
    iVar1 = *(int32_t *)(arg1 + 4);
    iVar3 = 0;
    if (iVar1 < 0) {
        iVar1 = iVar1 + iVar1 / 2;
        iVar2 = iVar3;
        if (0 < iVar1) {
            iVar2 = iVar1;
        }
        func_0x00018011fc10(arg1, iVar2);
    }
    *(undefined4 *)arg1 = 0;
    iVar1 = *(int32_t *)(arg1 + 0x14);
    if (iVar1 < 0) {
        iVar1 = iVar1 + iVar1 / 2;
        iVar2 = iVar3;
        if (0 < iVar1) {
            iVar2 = iVar1;
        }
        func_0x00018011f8d0(arg1 + 0x10, iVar2);
    }
    *(undefined4 *)(arg1 + 0x10) = 0;
    iVar1 = *(int32_t *)(arg1 + 0x24);
    if (iVar1 < 0) {
        iVar1 = iVar1 + iVar1 / 2;
        iVar2 = iVar3;
        if (0 < iVar1) {
            iVar2 = iVar1;
        }
        func_0x00018011f6f0(arg1 + 0x20, iVar2);
    }
    *(undefined4 *)(arg1 + 0x20) = 0;
    *(undefined4 *)(arg1 + 0x30) = *(undefined4 *)(*(int64_t *)(arg1 + 0x38) + 0x34);
    *(undefined (*) [16])(arg1 + 0x60) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x70) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x80) = 0;
    *(undefined4 *)(arg1 + 0x34) = 0;
    *(undefined8 *)(arg1 + 0x40) = 0;
    *(undefined8 *)(arg1 + 0x48) = 0;
    iVar1 = *(int32_t *)(arg1 + 0xa4);
    if (iVar1 < 0) {
        iVar1 = iVar1 + iVar1 / 2;
        iVar2 = iVar3;
        if (0 < iVar1) {
            iVar2 = iVar1;
        }
        func_0x00018011faa0(arg1 + 0xa0, iVar2);
    }
    *(undefined4 *)(arg1 + 0xa0) = 0;
    iVar1 = *(int32_t *)(arg1 + 0xb4);
    if (iVar1 < 0) {
        iVar1 = iVar1 + iVar1 / 2;
        iVar2 = iVar3;
        if (0 < iVar1) {
            iVar2 = iVar1;
        }
        func_0x00018011faa0(arg1 + 0xb0, iVar2);
    }
    *(undefined4 *)(arg1 + 0xb0) = 0;
    func_0x00018011f640(arg1 + 0xc0, 0);
    iVar1 = *(int32_t *)(arg1 + 0x54);
    if (iVar1 < 0) {
        iVar1 = iVar1 + iVar1 / 2;
        if (0 < iVar1) {
            iVar3 = iVar1;
        }
        func_0x00018011f4f0(arg1 + 0x50, iVar3);
    }
    *(undefined4 *)(arg1 + 0x50) = 0;
    *(undefined4 *)(arg1 + 0x88) = 0;
    var_38h = 0;
    *(undefined4 *)(arg1 + 0x8c) = 1;
    _var_78h = ZEXT816(0);
    _var_68h = ZEXT816(0);
    _var_58h = ZEXT816(0);
    _var_48h = ZEXT816(0);
    func_0x00018011fb80(arg1, &var_78h);
    *(undefined4 *)(arg1 + 0xd0) = *(undefined4 *)(*(int64_t *)(arg1 + 0x38) + 0x30);
    return;
}

// ============================================================
// Function: FUN_180124110
// Address: 0x180124110
// Size: 229 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180124110(int64_t arg1, int64_t arg_40h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if (*(int64_t *)(arg1 + 8) != 0) {
        *(undefined8 *)arg1 = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg1 + 8) = 0;
    }
    if (*(int64_t *)(arg1 + 0x18) != 0) {
        *(undefined8 *)(arg1 + 0x10) = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg1 + 0x18) = 0;
    }
    if (*(int64_t *)(arg1 + 0x28) != 0) {
        *(undefined8 *)(arg1 + 0x20) = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg1 + 0x28) = 0;
    }
    *(undefined8 *)(arg1 + 0x30) = 0;
    *(undefined8 *)(arg1 + 0x40) = 0;
    *(undefined8 *)(arg1 + 0x48) = 0;
    if (*(int64_t *)(arg1 + 0xa8) != 0) {
        *(undefined8 *)(arg1 + 0xa0) = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg1 + 0xa8) = 0;
    }
    if (*(int64_t *)(arg1 + 0xb8) != 0) {
        *(undefined8 *)(arg1 + 0xb0) = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg1 + 0xb8) = 0;
    }
    if (*(int64_t *)(arg1 + 200) != 0) {
        *(undefined8 *)(arg1 + 0xc0) = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg1 + 200) = 0;
    }
    if (*(int64_t *)(arg1 + 0x58) != 0) {
        *(undefined8 *)(arg1 + 0x50) = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg1 + 0x58) = 0;
    }
    iVar2 = 0;
    if (0 < *(int32_t *)(arg1 + 0x90)) {
        do {
            iVar3 = (int64_t)iVar2 * 0x20;
            if (iVar2 == *(int32_t *)(arg1 + 0x88)) {
                iVar1 = *(int64_t *)(arg1 + 0x98);
                *(undefined (*) [16])(iVar3 + iVar1) = ZEXT816(0);
                *(undefined (*) [16])(iVar3 + 0x10 + iVar1) = ZEXT816(0);
            }
            iVar1 = *(int64_t *)(arg1 + 0x98);
            if (*(int64_t *)(iVar1 + 8 + iVar3) != 0) {
                *(undefined8 *)(iVar1 + iVar3) = 0;
                func_0x000180460d90();
                *(undefined8 *)(iVar1 + 8 + iVar3) = 0;
            }
            iVar3 = iVar3 + *(int64_t *)(arg1 + 0x98);
            if (*(int64_t *)(iVar3 + 0x18) != 0) {
                *(undefined8 *)(iVar3 + 0x10) = 0;
                func_0x000180460d90();
                *(undefined8 *)(iVar3 + 0x18) = 0;
            }
            iVar2 = iVar2 + 1;
        } while (iVar2 < *(int32_t *)(arg1 + 0x90));
    }
    *(int32_t *)(arg1 + 0x88) = 0;
    *(undefined4 *)(arg1 + 0x8c) = 1;
    if (*(int64_t *)(arg1 + 0x98) != 0) {
        *(undefined8 *)(arg1 + 0x90) = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg1 + 0x98) = 0;
    }
    return;
}

