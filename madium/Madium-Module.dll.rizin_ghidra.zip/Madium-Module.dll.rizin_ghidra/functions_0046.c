// Chunk 46 - 50 functions

// ============================================================
// Function: FUN_1800952a0
// Address: 0x1800952a0
// Size: 167 bytes
// ============================================================
undefined8 fcn.1800952a0(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    int32_t iVar3;
    uint64_t uVar4;
    undefined8 uVar5;
    uint64_t uVar6;
    int32_t iVar7;
    
    iVar7 = 1;
    uVar6 = 0xffffffffffffffff;
    iVar3 = (int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4);
    if (0 < iVar3) {
        do {
            uVar4 = func_0x000180088910(arg1, iVar7);
            uVar6 = uVar6 & uVar4;
            iVar7 = iVar7 + 1;
        } while (iVar7 <= iVar3);
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
       (iVar3 = func_0x000180085510(arg1, 1), iVar3 == 0)) {
        func_0x000180099450(arg1, 0x18063d8d0);
        func_0x000180087960(arg1);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    puVar1 = *(uint64_t **)(arg1 + 0x40);
    *puVar1 = uVar6;
    *(undefined4 *)((int64_t)puVar1 + 0xc) = 4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_180095350
// Address: 0x180095350
// Size: 154 bytes
// ============================================================
undefined8 fcn.180095350(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    int32_t iVar3;
    uint64_t uVar4;
    undefined8 uVar5;
    uint64_t uVar6;
    int32_t iVar7;
    
    uVar6 = 0;
    iVar7 = 1;
    iVar3 = (int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4);
    if (0 < iVar3) {
        do {
            uVar4 = func_0x000180088910(arg1, iVar7);
            uVar6 = uVar6 | uVar4;
            iVar7 = iVar7 + 1;
        } while (iVar7 <= iVar3);
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar3 = func_0x000180085510(arg1, 1);
        if (iVar3 == 0) {
            func_0x000180099450(arg1, 0x18063d8d0);
            func_0x000180087960(arg1);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
    }
    puVar1 = *(uint64_t **)(arg1 + 0x40);
    *puVar1 = uVar6;
    *(undefined4 *)((int64_t)puVar1 + 0xc) = 4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_1800953f0
// Address: 0x1800953f0
// Size: 111 bytes
// ============================================================
undefined8 fcn.1800953f0(int64_t arg1)
{
    code *pcVar1;
    uint64_t *puVar2;
    undefined8 uVar3;
    uint64_t *puVar4;
    
    puVar2 = *(uint64_t **)(arg1 + 0x28);
    puVar4 = puVar2;
    if (*(uint64_t **)(arg1 + 0x40) <= puVar2) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if ((puVar4 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar4 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    if (*(uint64_t **)(arg1 + 0x40) <= puVar2) {
        puVar2 = *(uint64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)puVar2 + 0xc) == 4) {
        fcn.180086660(arg1, ~*puVar2);
        return 1;
    }
    fcn.180086660(arg1, 0xffffffffffffffff);
    return 1;
}

// ============================================================
// Function: FUN_180095460
// Address: 0x180095460
// Size: 154 bytes
// ============================================================
undefined8 fcn.180095460(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    int32_t iVar3;
    uint64_t uVar4;
    undefined8 uVar5;
    int64_t unaff_RBP;
    uint64_t uVar6;
    int32_t iVar7;
    
    uVar6 = 0;
    iVar7 = 1;
    iVar3 = (int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4);
    if (0 < iVar3) {
        do {
            uVar4 = func_0x000180088910(arg1, iVar7);
            uVar6 = uVar6 ^ uVar4;
            iVar7 = iVar7 + 1;
        } while (iVar7 <= iVar3);
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar3 = fcn.180085510(unaff_RBP);
        if (iVar3 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
    }
    puVar1 = *(uint64_t **)(arg1 + 0x40);
    *puVar1 = uVar6;
    *(undefined4 *)((int64_t)puVar1 + 0xc) = 4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_180095500
// Address: 0x180095500
// Size: 168 bytes
// ============================================================
undefined8 fcn.180095500(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    
    piVar4 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar3 = piVar4;
    if (piVar1 <= piVar4) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar3 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    piVar3 = piVar4;
    if (piVar1 <= piVar4) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar3 + 0xc) == 4) {
        iVar7 = *piVar3;
    } else {
        iVar7 = 0;
    }
    piVar4 = piVar4 + 2;
    piVar3 = piVar4;
    if (piVar1 <= piVar4) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar3 + 0xc) == 4)) {
        if (piVar1 <= piVar4) {
            piVar4 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar4 + 0xc) == 4) {
            iVar6 = *piVar4;
        } else {
            iVar6 = 0;
        }
        func_0x000180086b20(arg1, iVar7 < iVar6);
        return 1;
    }
    fcn.180088470(arg1, 2, 4);
    pcVar2 = (code *)swi(3);
    uVar5 = (*pcVar2)();
    return uVar5;
}

// ============================================================
// Function: FUN_1800955b0
// Address: 0x1800955b0
// Size: 168 bytes
// ============================================================
undefined8 fcn.1800955b0(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    
    piVar4 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar3 = piVar4;
    if (piVar1 <= piVar4) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar3 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    piVar3 = piVar4;
    if (piVar1 <= piVar4) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar3 + 0xc) == 4) {
        iVar7 = *piVar3;
    } else {
        iVar7 = 0;
    }
    piVar4 = piVar4 + 2;
    piVar3 = piVar4;
    if (piVar1 <= piVar4) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar3 + 0xc) == 4)) {
        if (piVar1 <= piVar4) {
            piVar4 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar4 + 0xc) == 4) {
            iVar6 = *piVar4;
        } else {
            iVar6 = 0;
        }
        func_0x000180086b20(arg1, iVar7 <= iVar6);
        return 1;
    }
    fcn.180088470(arg1, 2, 4);
    pcVar2 = (code *)swi(3);
    uVar5 = (*pcVar2)();
    return uVar5;
}

// ============================================================
// Function: FUN_180095660
// Address: 0x180095660
// Size: 168 bytes
// ============================================================
undefined8 fcn.180095660(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    uint64_t *puVar3;
    uint64_t *puVar4;
    undefined8 uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    
    puVar4 = *(uint64_t **)(arg1 + 0x28);
    puVar1 = *(uint64_t **)(arg1 + 0x40);
    puVar3 = puVar4;
    if (puVar1 <= puVar4) {
        puVar3 = *(uint64_t **)0x180782430;
    }
    if ((puVar3 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar3 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    puVar3 = puVar4;
    if (puVar1 <= puVar4) {
        puVar3 = *(uint64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)puVar3 + 0xc) == 4) {
        uVar7 = *puVar3;
    } else {
        uVar7 = 0;
    }
    puVar4 = puVar4 + 2;
    puVar3 = puVar4;
    if (puVar1 <= puVar4) {
        puVar3 = *(uint64_t **)0x180782430;
    }
    if ((puVar3 != *(uint64_t **)0x180782430) && (*(int32_t *)((int64_t)puVar3 + 0xc) == 4)) {
        if (puVar1 <= puVar4) {
            puVar4 = *(uint64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)puVar4 + 0xc) == 4) {
            uVar6 = *puVar4;
        } else {
            uVar6 = 0;
        }
        func_0x000180086b20(arg1, uVar7 < uVar6);
        return 1;
    }
    fcn.180088470(arg1, 2, 4);
    pcVar2 = (code *)swi(3);
    uVar5 = (*pcVar2)();
    return uVar5;
}

// ============================================================
// Function: FUN_180095710
// Address: 0x180095710
// Size: 168 bytes
// ============================================================
undefined8 fcn.180095710(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    uint64_t *puVar3;
    uint64_t *puVar4;
    undefined8 uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    
    puVar4 = *(uint64_t **)(arg1 + 0x28);
    puVar1 = *(uint64_t **)(arg1 + 0x40);
    puVar3 = puVar4;
    if (puVar1 <= puVar4) {
        puVar3 = *(uint64_t **)0x180782430;
    }
    if ((puVar3 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar3 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    puVar3 = puVar4;
    if (puVar1 <= puVar4) {
        puVar3 = *(uint64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)puVar3 + 0xc) == 4) {
        uVar7 = *puVar3;
    } else {
        uVar7 = 0;
    }
    puVar4 = puVar4 + 2;
    puVar3 = puVar4;
    if (puVar1 <= puVar4) {
        puVar3 = *(uint64_t **)0x180782430;
    }
    if ((puVar3 != *(uint64_t **)0x180782430) && (*(int32_t *)((int64_t)puVar3 + 0xc) == 4)) {
        if (puVar1 <= puVar4) {
            puVar4 = *(uint64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)puVar4 + 0xc) == 4) {
            uVar6 = *puVar4;
        } else {
            uVar6 = 0;
        }
        func_0x000180086b20(arg1, uVar7 <= uVar6);
        return 1;
    }
    fcn.180088470(arg1, 2, 4);
    pcVar2 = (code *)swi(3);
    uVar5 = (*pcVar2)();
    return uVar5;
}

// ============================================================
// Function: FUN_1800957c0
// Address: 0x1800957c0
// Size: 168 bytes
// ============================================================
undefined8 fcn.1800957c0(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    
    piVar4 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar3 = piVar4;
    if (piVar1 <= piVar4) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar3 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    piVar3 = piVar4;
    if (piVar1 <= piVar4) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar3 + 0xc) == 4) {
        iVar7 = *piVar3;
    } else {
        iVar7 = 0;
    }
    piVar4 = piVar4 + 2;
    piVar3 = piVar4;
    if (piVar1 <= piVar4) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar3 + 0xc) == 4)) {
        if (piVar1 <= piVar4) {
            piVar4 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar4 + 0xc) == 4) {
            iVar6 = *piVar4;
        } else {
            iVar6 = 0;
        }
        func_0x000180086b20(arg1, iVar6 < iVar7);
        return 1;
    }
    fcn.180088470(arg1, 2, 4);
    pcVar2 = (code *)swi(3);
    uVar5 = (*pcVar2)();
    return uVar5;
}

// ============================================================
// Function: FUN_180095870
// Address: 0x180095870
// Size: 168 bytes
// ============================================================
undefined8 fcn.180095870(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    
    piVar4 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar3 = piVar4;
    if (piVar1 <= piVar4) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar3 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    piVar3 = piVar4;
    if (piVar1 <= piVar4) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar3 + 0xc) == 4) {
        iVar7 = *piVar3;
    } else {
        iVar7 = 0;
    }
    piVar4 = piVar4 + 2;
    piVar3 = piVar4;
    if (piVar1 <= piVar4) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar3 + 0xc) == 4)) {
        if (piVar1 <= piVar4) {
            piVar4 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar4 + 0xc) == 4) {
            iVar6 = *piVar4;
        } else {
            iVar6 = 0;
        }
        func_0x000180086b20(arg1, iVar6 <= iVar7);
        return 1;
    }
    fcn.180088470(arg1, 2, 4);
    pcVar2 = (code *)swi(3);
    uVar5 = (*pcVar2)();
    return uVar5;
}

// ============================================================
// Function: FUN_180095920
// Address: 0x180095920
// Size: 168 bytes
// ============================================================
undefined8 fcn.180095920(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    uint64_t *puVar3;
    uint64_t *puVar4;
    undefined8 uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    
    puVar4 = *(uint64_t **)(arg1 + 0x28);
    puVar1 = *(uint64_t **)(arg1 + 0x40);
    puVar3 = puVar4;
    if (puVar1 <= puVar4) {
        puVar3 = *(uint64_t **)0x180782430;
    }
    if ((puVar3 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar3 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    puVar3 = puVar4;
    if (puVar1 <= puVar4) {
        puVar3 = *(uint64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)puVar3 + 0xc) == 4) {
        uVar7 = *puVar3;
    } else {
        uVar7 = 0;
    }
    puVar4 = puVar4 + 2;
    puVar3 = puVar4;
    if (puVar1 <= puVar4) {
        puVar3 = *(uint64_t **)0x180782430;
    }
    if ((puVar3 != *(uint64_t **)0x180782430) && (*(int32_t *)((int64_t)puVar3 + 0xc) == 4)) {
        if (puVar1 <= puVar4) {
            puVar4 = *(uint64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)puVar4 + 0xc) == 4) {
            uVar6 = *puVar4;
        } else {
            uVar6 = 0;
        }
        func_0x000180086b20(arg1, uVar6 < uVar7);
        return 1;
    }
    fcn.180088470(arg1, 2, 4);
    pcVar2 = (code *)swi(3);
    uVar5 = (*pcVar2)();
    return uVar5;
}

// ============================================================
// Function: FUN_1800959d0
// Address: 0x1800959d0
// Size: 168 bytes
// ============================================================
undefined8 fcn.1800959d0(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    uint64_t *puVar3;
    uint64_t *puVar4;
    undefined8 uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    
    puVar4 = *(uint64_t **)(arg1 + 0x28);
    puVar1 = *(uint64_t **)(arg1 + 0x40);
    puVar3 = puVar4;
    if (puVar1 <= puVar4) {
        puVar3 = *(uint64_t **)0x180782430;
    }
    if ((puVar3 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar3 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    puVar3 = puVar4;
    if (puVar1 <= puVar4) {
        puVar3 = *(uint64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)puVar3 + 0xc) == 4) {
        uVar7 = *puVar3;
    } else {
        uVar7 = 0;
    }
    puVar4 = puVar4 + 2;
    puVar3 = puVar4;
    if (puVar1 <= puVar4) {
        puVar3 = *(uint64_t **)0x180782430;
    }
    if ((puVar3 != *(uint64_t **)0x180782430) && (*(int32_t *)((int64_t)puVar3 + 0xc) == 4)) {
        if (puVar1 <= puVar4) {
            puVar4 = *(uint64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)puVar4 + 0xc) == 4) {
            uVar6 = *puVar4;
        } else {
            uVar6 = 0;
        }
        func_0x000180086b20(arg1, uVar6 <= uVar7);
        return 1;
    }
    fcn.180088470(arg1, 2, 4);
    pcVar2 = (code *)swi(3);
    uVar5 = (*pcVar2)();
    return uVar5;
}

// ============================================================
// Function: FUN_180095a80
// Address: 0x180095a80
// Size: 237 bytes
// ============================================================
undefined8 fcn.180095a80(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    undefined8 uVar3;
    uint64_t *puVar4;
    uint64_t *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    
    puVar5 = *(uint64_t **)(arg1 + 0x28);
    puVar1 = *(uint64_t **)(arg1 + 0x40);
    puVar4 = puVar5;
    if (puVar1 <= puVar5) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if ((puVar4 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar4 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    puVar4 = puVar5;
    if (puVar1 <= puVar5) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)puVar4 + 0xc) == 4) {
        uVar7 = *puVar4;
    } else {
        uVar7 = 0;
    }
    puVar5 = puVar5 + 2;
    puVar4 = puVar5;
    if (puVar1 <= puVar5) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if ((puVar4 != *(uint64_t **)0x180782430) && (*(int32_t *)((int64_t)puVar4 + 0xc) == 4)) {
        if (puVar1 <= puVar5) {
            puVar5 = *(uint64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)puVar5 + 0xc) == 4) {
            uVar6 = *puVar5;
            if (0x7e < uVar6 + 0x3f) {
                fcn.180086660(arg1, 0);
                return 1;
            }
            if ((int64_t)uVar6 < 0) {
                fcn.180086660(arg1, uVar7 >> (-(char)uVar6 & 0x3fU));
                return 1;
            }
        } else {
            uVar6 = 0;
        }
        fcn.180086660(arg1, uVar7 << ((uint8_t)uVar6 & 0x3f));
        return 1;
    }
    fcn.180088470(arg1, 2, 4);
    pcVar2 = (code *)swi(3);
    uVar3 = (*pcVar2)();
    return uVar3;
}

// ============================================================
// Function: FUN_180095b70
// Address: 0x180095b70
// Size: 237 bytes
// ============================================================
undefined8 fcn.180095b70(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    undefined8 uVar3;
    uint64_t *puVar4;
    uint64_t *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    
    puVar5 = *(uint64_t **)(arg1 + 0x28);
    puVar1 = *(uint64_t **)(arg1 + 0x40);
    puVar4 = puVar5;
    if (puVar1 <= puVar5) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if ((puVar4 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar4 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    puVar4 = puVar5;
    if (puVar1 <= puVar5) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)puVar4 + 0xc) == 4) {
        uVar7 = *puVar4;
    } else {
        uVar7 = 0;
    }
    puVar5 = puVar5 + 2;
    puVar4 = puVar5;
    if (puVar1 <= puVar5) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if ((puVar4 != *(uint64_t **)0x180782430) && (*(int32_t *)((int64_t)puVar4 + 0xc) == 4)) {
        if (puVar1 <= puVar5) {
            puVar5 = *(uint64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)puVar5 + 0xc) == 4) {
            uVar6 = *puVar5;
            if (0x7e < uVar6 + 0x3f) {
                fcn.180086660(arg1, 0);
                return 1;
            }
            if ((int64_t)uVar6 < 0) {
                fcn.180086660(arg1, uVar7 << (-(char)uVar6 & 0x3fU));
                return 1;
            }
        } else {
            uVar6 = 0;
        }
        fcn.180086660(arg1, uVar7 >> ((uint8_t)uVar6 & 0x3f));
        return 1;
    }
    fcn.180088470(arg1, 2, 4);
    pcVar2 = (code *)swi(3);
    uVar3 = (*pcVar2)();
    return uVar3;
}

// ============================================================
// Function: FUN_180095c60
// Address: 0x180095c60
// Size: 269 bytes
// ============================================================
undefined8 fcn.180095c60(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t *piVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    
    piVar4 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar6 = piVar4;
    if (piVar1 <= piVar4) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    piVar6 = piVar4;
    if (piVar1 <= piVar4) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 4) {
        iVar7 = *piVar6;
    } else {
        iVar7 = 0;
    }
    piVar4 = piVar4 + 2;
    piVar6 = piVar4;
    if (piVar1 <= piVar4) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar6 + 0xc) == 4)) {
        if (piVar1 <= piVar4) {
            piVar4 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar4 + 0xc) == 4) {
            iVar5 = *piVar4;
            if (iVar5 < -0x3f) {
                fcn.180086660(arg1, 0);
                return 1;
            }
            if (0x3f < iVar5) {
                fcn.180086660(arg1, iVar7 >> 0x3f);
                return 1;
            }
            if (iVar5 < 0) {
                fcn.180086660(arg1, iVar7 << (-(char)iVar5 & 0x3fU));
                return 1;
            }
        } else {
            iVar5 = 0;
        }
        fcn.180086660(arg1, iVar7 >> ((uint8_t)iVar5 & 0x3f));
        return 1;
    }
    fcn.180088470(arg1, 2, 4);
    pcVar2 = (code *)swi(3);
    uVar3 = (*pcVar2)();
    return uVar3;
}

// ============================================================
// Function: FUN_180095d70
// Address: 0x180095d70
// Size: 178 bytes
// ============================================================
undefined8 fcn.180095d70(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    undefined8 uVar3;
    int8_t iVar4;
    uint32_t uVar5;
    uint64_t *puVar6;
    uint64_t *puVar7;
    uint64_t uVar8;
    
    puVar7 = *(uint64_t **)(arg1 + 0x28);
    puVar1 = *(uint64_t **)(arg1 + 0x40);
    puVar6 = puVar7;
    if (puVar1 <= puVar7) {
        puVar6 = *(uint64_t **)0x180782430;
    }
    if ((puVar6 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar6 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    puVar6 = puVar7;
    if (puVar1 <= puVar7) {
        puVar6 = *(uint64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)puVar6 + 0xc) == 4) {
        uVar8 = *puVar6;
    } else {
        uVar8 = 0;
    }
    puVar7 = puVar7 + 2;
    puVar6 = puVar7;
    if (puVar1 <= puVar7) {
        puVar6 = *(uint64_t **)0x180782430;
    }
    if ((puVar6 != *(uint64_t **)0x180782430) && (*(int32_t *)((int64_t)puVar6 + 0xc) == 4)) {
        if (puVar1 <= puVar7) {
            puVar7 = *(uint64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)puVar7 + 0xc) == 4) {
            uVar5 = (uint32_t)*puVar7;
        } else {
            uVar5 = 0;
        }
        if ((uVar5 & 0x3f) != 0) {
            iVar4 = (int8_t)(uVar5 & 0x3f);
            uVar8 = uVar8 << iVar4 | uVar8 >> 0x40 - iVar4;
        }
        fcn.180086660(arg1, uVar8);
        return 1;
    }
    fcn.180088470(arg1, 2, 4);
    pcVar2 = (code *)swi(3);
    uVar3 = (*pcVar2)();
    return uVar3;
}

// ============================================================
// Function: FUN_180095e30
// Address: 0x180095e30
// Size: 178 bytes
// ============================================================
undefined8 fcn.180095e30(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    undefined8 uVar3;
    int8_t iVar4;
    uint32_t uVar5;
    uint64_t *puVar6;
    uint64_t *puVar7;
    uint64_t uVar8;
    
    puVar7 = *(uint64_t **)(arg1 + 0x28);
    puVar1 = *(uint64_t **)(arg1 + 0x40);
    puVar6 = puVar7;
    if (puVar1 <= puVar7) {
        puVar6 = *(uint64_t **)0x180782430;
    }
    if ((puVar6 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar6 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    puVar6 = puVar7;
    if (puVar1 <= puVar7) {
        puVar6 = *(uint64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)puVar6 + 0xc) == 4) {
        uVar8 = *puVar6;
    } else {
        uVar8 = 0;
    }
    puVar7 = puVar7 + 2;
    puVar6 = puVar7;
    if (puVar1 <= puVar7) {
        puVar6 = *(uint64_t **)0x180782430;
    }
    if ((puVar6 != *(uint64_t **)0x180782430) && (*(int32_t *)((int64_t)puVar6 + 0xc) == 4)) {
        if (puVar1 <= puVar7) {
            puVar7 = *(uint64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)puVar7 + 0xc) == 4) {
            uVar5 = (uint32_t)*puVar7;
        } else {
            uVar5 = 0;
        }
        if ((uVar5 & 0x3f) != 0) {
            iVar4 = (int8_t)(uVar5 & 0x3f);
            uVar8 = uVar8 >> iVar4 | uVar8 << 0x40 - iVar4;
        }
        fcn.180086660(arg1, uVar8);
        return 1;
    }
    fcn.180088470(arg1, 2, 4);
    pcVar2 = (code *)swi(3);
    uVar3 = (*pcVar2)();
    return uVar3;
}

// ============================================================
// Function: FUN_180095ef0
// Address: 0x180095ef0
// Size: 390 bytes
// ============================================================
undefined8 fcn.180095ef0(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    undefined8 uVar3;
    uint64_t *puVar4;
    uint64_t *puVar5;
    uint64_t uVar6;
    uint64_t *puVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    
    puVar5 = *(uint64_t **)(arg1 + 0x28);
    puVar1 = *(uint64_t **)(arg1 + 0x40);
    puVar4 = puVar5;
    if (puVar1 <= puVar5) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if ((puVar4 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar4 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    puVar4 = puVar5;
    if (puVar1 <= puVar5) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)puVar4 + 0xc) == 4) {
        uVar9 = *puVar4;
    } else {
        uVar9 = 0;
    }
    puVar4 = puVar5 + 2;
    puVar7 = puVar4;
    if (puVar1 <= puVar4) {
        puVar7 = *(uint64_t **)0x180782430;
    }
    if ((puVar7 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar7 + 0xc) != 4)) {
        fcn.180088470(arg1, 2, 4);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    if (puVar1 <= puVar4) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)puVar4 + 0xc) == 4) {
        uVar8 = *puVar4;
    } else {
        uVar8 = 0;
    }
    puVar5 = puVar5 + 4;
    puVar4 = puVar5;
    if (puVar1 <= puVar5) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if ((puVar4 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar4 + 0xc) < 1)) {
        uVar6 = 1;
    } else {
        puVar4 = puVar5;
        if (puVar1 <= puVar5) {
            puVar4 = *(uint64_t **)0x180782430;
        }
        if ((puVar4 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar4 + 0xc) != 4)) {
            fcn.180088470(arg1, 3, 4);
            pcVar2 = (code *)swi(3);
            uVar3 = (*pcVar2)();
            return uVar3;
        }
        if (puVar1 <= puVar5) {
            puVar5 = *(uint64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)puVar5 + 0xc) == 4) {
            uVar6 = *puVar5;
        } else {
            uVar6 = 0;
        }
    }
    if (0x3f < uVar8) {
        func_0x000180088380(arg1, 2, 0x18063dc20);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    if (0 < (int64_t)uVar6) {
        if ((int64_t)(uVar8 + uVar6) < 0x41) {
            fcn.180086660(arg1, 0xffffffffffffffffU >> (0x40U - (char)uVar6 & 0x3f) & uVar9 >> ((uint8_t)uVar8 & 0x3f));
            return 1;
        }
        fcn.180088560(arg1, 0x18063dc58);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    func_0x000180088380(arg1, 3, 0x18063dc08);
    pcVar2 = (code *)swi(3);
    uVar3 = (*pcVar2)();
    return uVar3;
}

// ============================================================
// Function: FUN_180096080
// Address: 0x180096080
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180096080(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    undefined8 uVar3;
    uint64_t *puVar4;
    uint64_t *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t *puVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int64_t var_8h;
    
    puVar5 = *(uint64_t **)(arg1 + 0x28);
    puVar1 = *(uint64_t **)(arg1 + 0x40);
    puVar4 = puVar5;
    if (puVar1 <= puVar5) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if ((puVar4 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar4 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    puVar4 = puVar5;
    if (puVar1 <= puVar5) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)puVar4 + 0xc) == 4) {
        uVar6 = *puVar4;
    } else {
        uVar6 = 0;
    }
    puVar4 = puVar5 + 2;
    puVar8 = puVar4;
    if (puVar1 <= puVar4) {
        puVar8 = *(uint64_t **)0x180782430;
    }
    if ((puVar8 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar8 + 0xc) != 4)) {
        fcn.180088470(arg1, 2, 4);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    if (puVar1 <= puVar4) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)puVar4 + 0xc) == 4) {
        uVar10 = *puVar4;
    } else {
        uVar10 = 0;
    }
    puVar4 = puVar5 + 4;
    puVar8 = puVar4;
    if (puVar1 <= puVar4) {
        puVar8 = *(uint64_t **)0x180782430;
    }
    if ((puVar8 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar8 + 0xc) != 4)) {
        fcn.180088470(arg1, 3, 4);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    if (puVar1 <= puVar4) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)puVar4 + 0xc) == 4) {
        uVar9 = *puVar4;
    } else {
        uVar9 = 0;
    }
    puVar5 = puVar5 + 6;
    puVar4 = puVar5;
    if (puVar1 <= puVar5) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if ((puVar4 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar4 + 0xc) < 1)) {
        uVar7 = 1;
    } else {
        puVar4 = puVar5;
        if (puVar1 <= puVar5) {
            puVar4 = *(uint64_t **)0x180782430;
        }
        if ((puVar4 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar4 + 0xc) != 4)) {
            fcn.180088470(arg1, 4, 4);
            pcVar2 = (code *)swi(3);
            uVar3 = (*pcVar2)();
            return uVar3;
        }
        if (puVar1 <= puVar5) {
            puVar5 = *(uint64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)puVar5 + 0xc) == 4) {
            uVar7 = *puVar5;
        } else {
            uVar7 = 0;
        }
    }
    if (0x3f < uVar9) {
        func_0x000180088380(arg1, 3, 0x18063dc20);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    if (0 < (int64_t)uVar7) {
        if ((int64_t)(uVar9 + uVar7) < 0x41) {
            uVar7 = 0xffffffffffffffff >> (0x40U - (char)uVar7 & 0x3f);
            fcn.180086660(arg1, ~(uVar7 << ((uint8_t)uVar9 & 0x3f)) & uVar6 |
                                (uVar7 & uVar10) << ((uint8_t)uVar9 & 0x3f));
            return 1;
        }
        fcn.180088560(arg1, 0x18063dc58);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    func_0x000180088380(arg1, 4, 0x18063dc08);
    pcVar2 = (code *)swi(3);
    uVar3 = (*pcVar2)();
    return uVar3;
}

// ============================================================
// Function: FUN_1800960b6
// Address: 0x1800960b6
// Size: 314 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180096080(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    undefined8 uVar3;
    uint64_t *puVar4;
    uint64_t *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t *puVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int64_t var_8h;
    
    puVar5 = *(uint64_t **)(arg1 + 0x28);
    puVar1 = *(uint64_t **)(arg1 + 0x40);
    puVar4 = puVar5;
    if (puVar1 <= puVar5) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if ((puVar4 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar4 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    puVar4 = puVar5;
    if (puVar1 <= puVar5) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)puVar4 + 0xc) == 4) {
        uVar6 = *puVar4;
    } else {
        uVar6 = 0;
    }
    puVar4 = puVar5 + 2;
    puVar8 = puVar4;
    if (puVar1 <= puVar4) {
        puVar8 = *(uint64_t **)0x180782430;
    }
    if ((puVar8 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar8 + 0xc) != 4)) {
        fcn.180088470(arg1, 2, 4);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    if (puVar1 <= puVar4) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)puVar4 + 0xc) == 4) {
        uVar10 = *puVar4;
    } else {
        uVar10 = 0;
    }
    puVar4 = puVar5 + 4;
    puVar8 = puVar4;
    if (puVar1 <= puVar4) {
        puVar8 = *(uint64_t **)0x180782430;
    }
    if ((puVar8 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar8 + 0xc) != 4)) {
        fcn.180088470(arg1, 3, 4);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    if (puVar1 <= puVar4) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)puVar4 + 0xc) == 4) {
        uVar9 = *puVar4;
    } else {
        uVar9 = 0;
    }
    puVar5 = puVar5 + 6;
    puVar4 = puVar5;
    if (puVar1 <= puVar5) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if ((puVar4 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar4 + 0xc) < 1)) {
        uVar7 = 1;
    } else {
        puVar4 = puVar5;
        if (puVar1 <= puVar5) {
            puVar4 = *(uint64_t **)0x180782430;
        }
        if ((puVar4 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar4 + 0xc) != 4)) {
            fcn.180088470(arg1, 4, 4);
            pcVar2 = (code *)swi(3);
            uVar3 = (*pcVar2)();
            return uVar3;
        }
        if (puVar1 <= puVar5) {
            puVar5 = *(uint64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)puVar5 + 0xc) == 4) {
            uVar7 = *puVar5;
        } else {
            uVar7 = 0;
        }
    }
    if (0x3f < uVar9) {
        func_0x000180088380(arg1, 3, 0x18063dc20);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    if (0 < (int64_t)uVar7) {
        if ((int64_t)(uVar9 + uVar7) < 0x41) {
            uVar7 = 0xffffffffffffffff >> (0x40U - (char)uVar7 & 0x3f);
            fcn.180086660(arg1, ~(uVar7 << ((uint8_t)uVar9 & 0x3f)) & uVar6 |
                                (uVar7 & uVar10) << ((uint8_t)uVar9 & 0x3f));
            return 1;
        }
        fcn.180088560(arg1, 0x18063dc58);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    func_0x000180088380(arg1, 4, 0x18063dc08);
    pcVar2 = (code *)swi(3);
    uVar3 = (*pcVar2)();
    return uVar3;
}

// ============================================================
// Function: FUN_1800961f0
// Address: 0x1800961f0
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180096080(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    undefined8 uVar3;
    uint64_t *puVar4;
    uint64_t *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t *puVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int64_t var_8h;
    
    puVar5 = *(uint64_t **)(arg1 + 0x28);
    puVar1 = *(uint64_t **)(arg1 + 0x40);
    puVar4 = puVar5;
    if (puVar1 <= puVar5) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if ((puVar4 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar4 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    puVar4 = puVar5;
    if (puVar1 <= puVar5) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)puVar4 + 0xc) == 4) {
        uVar6 = *puVar4;
    } else {
        uVar6 = 0;
    }
    puVar4 = puVar5 + 2;
    puVar8 = puVar4;
    if (puVar1 <= puVar4) {
        puVar8 = *(uint64_t **)0x180782430;
    }
    if ((puVar8 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar8 + 0xc) != 4)) {
        fcn.180088470(arg1, 2, 4);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    if (puVar1 <= puVar4) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)puVar4 + 0xc) == 4) {
        uVar10 = *puVar4;
    } else {
        uVar10 = 0;
    }
    puVar4 = puVar5 + 4;
    puVar8 = puVar4;
    if (puVar1 <= puVar4) {
        puVar8 = *(uint64_t **)0x180782430;
    }
    if ((puVar8 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar8 + 0xc) != 4)) {
        fcn.180088470(arg1, 3, 4);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    if (puVar1 <= puVar4) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)puVar4 + 0xc) == 4) {
        uVar9 = *puVar4;
    } else {
        uVar9 = 0;
    }
    puVar5 = puVar5 + 6;
    puVar4 = puVar5;
    if (puVar1 <= puVar5) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if ((puVar4 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar4 + 0xc) < 1)) {
        uVar7 = 1;
    } else {
        puVar4 = puVar5;
        if (puVar1 <= puVar5) {
            puVar4 = *(uint64_t **)0x180782430;
        }
        if ((puVar4 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar4 + 0xc) != 4)) {
            fcn.180088470(arg1, 4, 4);
            pcVar2 = (code *)swi(3);
            uVar3 = (*pcVar2)();
            return uVar3;
        }
        if (puVar1 <= puVar5) {
            puVar5 = *(uint64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)puVar5 + 0xc) == 4) {
            uVar7 = *puVar5;
        } else {
            uVar7 = 0;
        }
    }
    if (0x3f < uVar9) {
        func_0x000180088380(arg1, 3, 0x18063dc20);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    if (0 < (int64_t)uVar7) {
        if ((int64_t)(uVar9 + uVar7) < 0x41) {
            uVar7 = 0xffffffffffffffff >> (0x40U - (char)uVar7 & 0x3f);
            fcn.180086660(arg1, ~(uVar7 << ((uint8_t)uVar9 & 0x3f)) & uVar6 |
                                (uVar7 & uVar10) << ((uint8_t)uVar9 & 0x3f));
            return 1;
        }
        fcn.180088560(arg1, 0x18063dc58);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    func_0x000180088380(arg1, 4, 0x18063dc08);
    pcVar2 = (code *)swi(3);
    uVar3 = (*pcVar2)();
    return uVar3;
}

// ============================================================
// Function: FUN_180096204
// Address: 0x180096204
// Size: 115 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180096080(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    undefined8 uVar3;
    uint64_t *puVar4;
    uint64_t *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t *puVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int64_t var_8h;
    
    puVar5 = *(uint64_t **)(arg1 + 0x28);
    puVar1 = *(uint64_t **)(arg1 + 0x40);
    puVar4 = puVar5;
    if (puVar1 <= puVar5) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if ((puVar4 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar4 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    puVar4 = puVar5;
    if (puVar1 <= puVar5) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)puVar4 + 0xc) == 4) {
        uVar6 = *puVar4;
    } else {
        uVar6 = 0;
    }
    puVar4 = puVar5 + 2;
    puVar8 = puVar4;
    if (puVar1 <= puVar4) {
        puVar8 = *(uint64_t **)0x180782430;
    }
    if ((puVar8 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar8 + 0xc) != 4)) {
        fcn.180088470(arg1, 2, 4);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    if (puVar1 <= puVar4) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)puVar4 + 0xc) == 4) {
        uVar10 = *puVar4;
    } else {
        uVar10 = 0;
    }
    puVar4 = puVar5 + 4;
    puVar8 = puVar4;
    if (puVar1 <= puVar4) {
        puVar8 = *(uint64_t **)0x180782430;
    }
    if ((puVar8 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar8 + 0xc) != 4)) {
        fcn.180088470(arg1, 3, 4);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    if (puVar1 <= puVar4) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)puVar4 + 0xc) == 4) {
        uVar9 = *puVar4;
    } else {
        uVar9 = 0;
    }
    puVar5 = puVar5 + 6;
    puVar4 = puVar5;
    if (puVar1 <= puVar5) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if ((puVar4 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar4 + 0xc) < 1)) {
        uVar7 = 1;
    } else {
        puVar4 = puVar5;
        if (puVar1 <= puVar5) {
            puVar4 = *(uint64_t **)0x180782430;
        }
        if ((puVar4 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar4 + 0xc) != 4)) {
            fcn.180088470(arg1, 4, 4);
            pcVar2 = (code *)swi(3);
            uVar3 = (*pcVar2)();
            return uVar3;
        }
        if (puVar1 <= puVar5) {
            puVar5 = *(uint64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)puVar5 + 0xc) == 4) {
            uVar7 = *puVar5;
        } else {
            uVar7 = 0;
        }
    }
    if (0x3f < uVar9) {
        func_0x000180088380(arg1, 3, 0x18063dc20);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    if (0 < (int64_t)uVar7) {
        if ((int64_t)(uVar9 + uVar7) < 0x41) {
            uVar7 = 0xffffffffffffffff >> (0x40U - (char)uVar7 & 0x3f);
            fcn.180086660(arg1, ~(uVar7 << ((uint8_t)uVar9 & 0x3f)) & uVar6 |
                                (uVar7 & uVar10) << ((uint8_t)uVar9 & 0x3f));
            return 1;
        }
        fcn.180088560(arg1, 0x18063dc58);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    func_0x000180088380(arg1, 4, 0x18063dc08);
    pcVar2 = (code *)swi(3);
    uVar3 = (*pcVar2)();
    return uVar3;
}

// ============================================================
// Function: FUN_180096280
// Address: 0x180096280
// Size: 277 bytes
// ============================================================
undefined8 fcn.180096280(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t *piVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t *piVar9;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar5 = piVar7;
    if (piVar1 <= piVar7) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if ((piVar5 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar5 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar2 = (code *)swi(3);
        uVar4 = (*pcVar2)();
        return uVar4;
    }
    piVar5 = piVar7;
    if (piVar1 <= piVar7) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 4) {
        iVar8 = *piVar5;
    } else {
        iVar8 = 0;
    }
    piVar5 = piVar7 + 2;
    piVar9 = piVar5;
    if (piVar1 <= piVar5) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if ((piVar9 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar9 + 0xc) == 4)) {
        if (piVar1 <= piVar5) {
            piVar5 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar5 + 0xc) == 4) {
            iVar6 = *piVar5;
        } else {
            iVar6 = 0;
        }
        piVar7 = piVar7 + 4;
        piVar5 = piVar7;
        if (piVar1 <= piVar7) {
            piVar5 = *(int64_t **)0x180782430;
        }
        if ((piVar5 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar5 + 0xc) == 4)) {
            if (piVar1 <= piVar7) {
                piVar7 = *(int64_t **)0x180782430;
            }
            if (*(int32_t *)((int64_t)piVar7 + 0xc) == 4) {
                iVar3 = *piVar7;
            } else {
                iVar3 = 0;
            }
            if (iVar6 <= iVar3) {
                if ((iVar6 <= iVar8) && (iVar6 = iVar8, iVar3 < iVar8)) {
                    iVar6 = iVar3;
                }
                fcn.180086660(arg1, iVar6);
                return 1;
            }
            func_0x000180088380(arg1, 3, 0x18063e200);
            pcVar2 = (code *)swi(3);
            uVar4 = (*pcVar2)();
            return uVar4;
        }
        fcn.180088470(arg1, 3, 4);
        pcVar2 = (code *)swi(3);
        uVar4 = (*pcVar2)();
        return uVar4;
    }
    fcn.180088470(arg1, 2, 4);
    pcVar2 = (code *)swi(3);
    uVar4 = (*pcVar2)();
    return uVar4;
}

// ============================================================
// Function: FUN_1800963a0
// Address: 0x1800963a0
// Size: 174 bytes
// ============================================================
undefined8 fcn.1800963a0(int64_t arg1)
{
    uint32_t *puVar1;
    code *pcVar2;
    int32_t iVar3;
    uint64_t uVar4;
    undefined8 uVar5;
    int64_t unaff_RBP;
    uint64_t uVar6;
    int32_t iVar7;
    
    iVar7 = 1;
    uVar6 = 0xffffffffffffffff;
    iVar3 = (int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4);
    if (0 < iVar3) {
        do {
            uVar4 = func_0x000180088910(arg1, iVar7);
            uVar6 = uVar6 & uVar4;
            iVar7 = iVar7 + 1;
        } while (iVar7 <= iVar3);
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
       (iVar3 = fcn.180085510(unaff_RBP), iVar3 == 0)) {
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    puVar1 = *(uint32_t **)(arg1 + 0x40);
    *puVar1 = (uint32_t)(uVar6 != 0);
    puVar1[3] = 1;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_180096450
// Address: 0x180096450
// Size: 116 bytes
// ============================================================
undefined8 fcn.180096450(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    uint64_t *puVar4;
    undefined8 uVar5;
    uint64_t uVar6;
    uint64_t *puVar7;
    
    puVar4 = *(uint64_t **)(arg1 + 0x28);
    puVar7 = puVar4;
    if (*(uint64_t **)(arg1 + 0x40) <= puVar4) {
        puVar7 = *(uint64_t **)0x180782430;
    }
    if ((puVar7 != *(uint64_t **)0x180782430) && (*(int32_t *)((int64_t)puVar7 + 0xc) == 4)) {
        if (*(uint64_t **)(arg1 + 0x40) <= puVar4) {
            puVar4 = *(uint64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)puVar4 + 0xc) == 4) {
            uVar6 = *puVar4;
        } else {
            uVar6 = 0;
        }
        iVar1 = 0;
        if (uVar6 != 0) {
            for (; (uVar6 >> iVar1 & 1) == 0; iVar1 = iVar1 + 1) {
            }
        }
        iVar3 = 0x40;
        if (uVar6 != 0) {
            iVar3 = (int32_t)iVar1;
        }
        fcn.180086660(arg1, (int64_t)iVar3);
        return 1;
    }
    fcn.180088470(arg1, 1, 4);
    pcVar2 = (code *)swi(3);
    uVar5 = (*pcVar2)();
    return uVar5;
}

// ============================================================
// Function: FUN_1800964d0
// Address: 0x1800964d0
// Size: 124 bytes
// ============================================================
undefined8 fcn.1800964d0(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    uint64_t *puVar4;
    undefined8 uVar5;
    uint64_t uVar6;
    uint64_t *puVar7;
    
    puVar4 = *(uint64_t **)(arg1 + 0x28);
    puVar7 = puVar4;
    if (*(uint64_t **)(arg1 + 0x40) <= puVar4) {
        puVar7 = *(uint64_t **)0x180782430;
    }
    if ((puVar7 != *(uint64_t **)0x180782430) && (*(int32_t *)((int64_t)puVar7 + 0xc) == 4)) {
        if (*(uint64_t **)(arg1 + 0x40) <= puVar4) {
            puVar4 = *(uint64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)puVar4 + 0xc) == 4) {
            uVar6 = *puVar4;
        } else {
            uVar6 = 0;
        }
        iVar1 = 0x3f;
        if (uVar6 != 0) {
            for (; uVar6 >> iVar1 == 0; iVar1 = iVar1 + -1) {
            }
        }
        if (uVar6 == 0) {
            iVar3 = 0x40;
        } else {
            iVar3 = 0x3f - (int32_t)iVar1;
        }
        fcn.180086660(arg1, (int64_t)iVar3);
        return 1;
    }
    fcn.180088470(arg1, 1, 4);
    pcVar2 = (code *)swi(3);
    uVar5 = (*pcVar2)();
    return uVar5;
}

// ============================================================
// Function: FUN_180096550
// Address: 0x180096550
// Size: 111 bytes
// ============================================================
undefined8 fcn.180096550(int64_t arg1)
{
    uint64_t uVar1;
    code *pcVar2;
    uint64_t *puVar3;
    undefined8 uVar4;
    uint64_t *puVar5;
    
    puVar3 = *(uint64_t **)(arg1 + 0x28);
    puVar5 = puVar3;
    if (*(uint64_t **)(arg1 + 0x40) <= puVar3) {
        puVar5 = *(uint64_t **)0x180782430;
    }
    if ((puVar5 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar5 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar2 = (code *)swi(3);
        uVar4 = (*pcVar2)();
        return uVar4;
    }
    if (*(uint64_t **)(arg1 + 0x40) <= puVar3) {
        puVar3 = *(uint64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)puVar3 + 0xc) == 4) {
        uVar1 = *puVar3;
        fcn.180086660(arg1, uVar1 >> 0x38 | (uVar1 & 0xff000000000000) >> 0x28 | (uVar1 & 0xff0000000000) >> 0x18 |
                            (uVar1 & 0xff00000000) >> 8 | (uVar1 & 0xff000000) << 8 | (uVar1 & 0xff0000) << 0x18 |
                            (uVar1 & 0xff00) << 0x28 | uVar1 << 0x38);
        return 1;
    }
    fcn.180086660(arg1, 0);
    return 1;
}

// ============================================================
// Function: FUN_1800965c0
// Address: 0x1800965c0
// Size: 525 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h

undefined8 fcn.1800965c0(int64_t arg1)
{
    code *pcVar1;
    int64_t *piVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    undefined8 uVar5;
    undefined4 *puVar6;
    undefined8 *puVar7;
    int32_t iVar8;
    int64_t unaff_RDI;
    int64_t var_38h;
    
    puVar7 = (undefined8 *)0x180611e60;
    iVar8 = 0;
    piVar2 = (int64_t *)0x180611e60;
    do {
        iVar8 = iVar8 + 1;
        piVar2 = piVar2 + 2;
    } while (*piVar2 != 0);
    func_0x000180088ce0(arg1, 0xffffd8f0, 0x18063da18, 1);
    func_0x000180086cc0(arg1, 0xffffffff, 0x18063e1a0);
    iVar3 = *(int64_t *)(arg1 + 0x40) + -0x10;
    if ((iVar3 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 7)) {
        *(int64_t *)(arg1 + 0x40) = iVar3;
        iVar3 = func_0x000180088ce0(arg1, 0xffffd8ee, 0x18063e1a0, iVar8);
        if (iVar3 != 0) {
            fcn.180088560(arg1, 0x18063da68, 0x18063e1a0);
            pcVar1 = (code *)swi(3);
            uVar5 = (*pcVar1)();
            return uVar5;
        }
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar8 = fcn.180085510(unaff_RDI), iVar8 == 0)) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar1 = (code *)swi(3);
            uVar5 = (*pcVar1)();
            return uVar5;
        }
        puVar4 = *(undefined4 **)(arg1 + 0x40);
        *puVar4 = puVar4[-4];
        puVar4[1] = puVar4[-3];
        puVar4[2] = puVar4[-2];
        puVar4[3] = puVar4[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x000180087370(arg1, 0xfffffffd, 0x18063e1a0);
    }
    puVar6 = *(undefined4 **)(arg1 + 0x40);
    puVar4 = puVar6 + -4;
    if (puVar4 < puVar6) {
        do {
            puVar4[-4] = *puVar4;
            puVar4[-3] = puVar4[1];
            puVar4[-2] = puVar4[2];
            puVar4[-1] = puVar4[3];
            puVar6 = *(undefined4 **)(arg1 + 0x40);
            puVar4 = puVar4 + 4;
        } while (puVar4 < puVar6);
    }
    *(undefined4 **)(arg1 + 0x40) = puVar6 + -4;
    iVar3 = 0x18063c32c;
    do {
        func_0x0001800869f0(arg1, puVar7[1], iVar3, 0, 0);
        func_0x000180087370(arg1, 0xfffffffe, *puVar7);
        iVar3 = puVar7[2];
        puVar7 = puVar7 + 2;
    } while (iVar3 != 0);
    fcn.180086660(arg1, 0x7fffffffffffffff);
    func_0x000180087370(arg1, 0xfffffffe, 0x18063e268);
    fcn.180086660(arg1, 0x8000000000000000);
    func_0x000180087370(arg1, 0xfffffffe, 0x18063e288);
    return 1;
}

// ============================================================
// Function: FUN_1800967d0
// Address: 0x1800967d0
// Size: 77 bytes
// ============================================================
undefined8 fcn.1800967d0(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    int64_t var_10h;
    
    uVar3 = fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h != 0) {
        fcn.180086570(arg1, uVar3);
        return 1;
    }
    fcn.180088470(arg1, 1, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180096820
// Address: 0x180096820
// Size: 78 bytes
// ============================================================
undefined8 fcn.180096820(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    int64_t in_stack_00000008;
    int64_t var_10h;
    
    fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h != 0) {
        uVar3 = fcn.180493440(in_stack_00000008);
        fcn.180086570(arg1, uVar3);
        return 1;
    }
    fcn.180088470(arg1, 1, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180096870
// Address: 0x180096870
// Size: 78 bytes
// ============================================================
undefined8 fcn.180096870(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    int64_t var_10h;
    int64_t in_stack_00000048;
    
    fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h != 0) {
        uVar3 = fcn.180494070(in_stack_00000048);
        fcn.180086570(arg1, uVar3);
        return 1;
    }
    fcn.180088470(arg1, 1, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_1800968c0
// Address: 0x1800968c0
// Size: 78 bytes
// ============================================================
undefined8 fcn.1800968c0(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    int64_t var_10h;
    
    fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h != 0) {
        uVar3 = fcn.18048f790();
        fcn.180086570(arg1, uVar3);
        return 1;
    }
    fcn.180088470(arg1, 1, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180096910
// Address: 0x180096910
// Size: 78 bytes
// ============================================================
undefined8 fcn.180096910(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    int64_t var_10h;
    int64_t in_stack_00000048;
    int64_t in_stack_00000058;
    
    fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h != 0) {
        uVar3 = fcn.1804901d0(in_stack_00000048, in_stack_00000058);
        fcn.180086570(arg1, uVar3);
        return 1;
    }
    fcn.180088470(arg1, 1, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180096960
// Address: 0x180096960
// Size: 78 bytes
// ============================================================
undefined8 fcn.180096960(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    int64_t var_10h;
    
    fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h != 0) {
        uVar3 = fcn.180494600();
        fcn.180086570(arg1, uVar3);
        return 1;
    }
    fcn.180088470(arg1, 1, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_1800969b0
// Address: 0x1800969b0
// Size: 78 bytes
// ============================================================
undefined8 fcn.1800969b0(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    int64_t var_10h;
    
    fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h != 0) {
        uVar3 = fcn.180494da0();
        fcn.180086570(arg1, uVar3);
        return 1;
    }
    fcn.180088470(arg1, 1, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180096a00
// Address: 0x180096a00
// Size: 78 bytes
// ============================================================
undefined8 fcn.180096a00(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    int64_t var_10h;
    int64_t in_stack_00000028;
    
    fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h != 0) {
        uVar3 = fcn.18048ec30(in_stack_00000028);
        fcn.180086570(arg1, uVar3);
        return 1;
    }
    fcn.180088470(arg1, 1, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180096a50
// Address: 0x180096a50
// Size: 78 bytes
// ============================================================
undefined8 fcn.180096a50(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    int64_t var_10h;
    int64_t in_stack_00000038;
    
    fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h != 0) {
        uVar3 = fcn.18048e730(in_stack_00000038);
        fcn.180086570(arg1, uVar3);
        return 1;
    }
    fcn.180088470(arg1, 1, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180096aa0
// Address: 0x180096aa0
// Size: 78 bytes
// ============================================================
undefined8 fcn.180096aa0(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    int64_t unaff_RBX;
    undefined4 uVar3;
    int64_t var_10h;
    
    fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h != 0) {
        uVar3 = fcn.18048eec0(unaff_RBX);
        fcn.180086570(arg1, uVar3);
        return 1;
    }
    fcn.180088470(arg1, 1, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180096af0
// Address: 0x180096af0
// Size: 139 bytes
// ============================================================
undefined8 fcn.180096af0(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar3 = fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 1, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    uVar4 = fcn.180085ea0(arg1, 2, &var_10h);
    if ((int32_t)var_10h != 0) {
        uVar3 = fcn.18048f110(uVar3, uVar4);
        fcn.180086570(arg1, uVar3);
        return 1;
    }
    fcn.180088470(arg1, 2, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180096b80
// Address: 0x180096b80
// Size: 78 bytes
// ============================================================
undefined8 fcn.180096b80(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    int64_t var_10h;
    
    fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h != 0) {
        uVar3 = fcn.18048d6f0();
        fcn.180086570(arg1, uVar3);
        return 1;
    }
    fcn.180088470(arg1, 1, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180096bd0
// Address: 0x180096bd0
// Size: 78 bytes
// ============================================================
undefined8 fcn.180096bd0(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    int64_t var_10h;
    
    fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h != 0) {
        uVar3 = fcn.1804909e0();
        fcn.180086570(arg1, uVar3);
        return 1;
    }
    fcn.180088470(arg1, 1, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180096c20
// Address: 0x180096c20
// Size: 139 bytes
// ============================================================
undefined8 fcn.180096c20(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar3 = fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 1, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    uVar4 = fcn.180085ea0(arg1, 2, &var_10h);
    if ((int32_t)var_10h != 0) {
        uVar3 = fcn.180490b30(uVar3, uVar4);
        fcn.180086570(arg1, uVar3);
        return 1;
    }
    fcn.180088470(arg1, 2, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180096cb0
// Address: 0x180096cb0
// Size: 36 bytes
// ============================================================
undefined8 fcn.180096cb0(int64_t arg1)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined8 uVar3;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar2 = fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h != 0) {
        uVar3 = fcn.18046df90(uVar2, &var_18h);
        fcn.180086570(arg1, var_18h);
        fcn.180086570(arg1, uVar3);
        return 2;
    }
    fcn.180088470(arg1, 1, 3);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_180096cd4
// Address: 0x180096cd4
// Size: 54 bytes
// ============================================================
undefined8 fcn.180096cb0(int64_t arg1)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined8 uVar3;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar2 = fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h != 0) {
        uVar3 = fcn.18046df90(uVar2, &var_18h);
        fcn.180086570(arg1, var_18h);
        fcn.180086570(arg1, uVar3);
        return 2;
    }
    fcn.180088470(arg1, 1, 3);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_180096d0a
// Address: 0x180096d0a
// Size: 20 bytes
// ============================================================
undefined8 fcn.180096cb0(int64_t arg1)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined8 uVar3;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar2 = fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h != 0) {
        uVar3 = fcn.18046df90(uVar2, &var_18h);
        fcn.180086570(arg1, var_18h);
        fcn.180086570(arg1, uVar3);
        return 2;
    }
    fcn.180088470(arg1, 1, 3);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_180096d20
// Address: 0x180096d20
// Size: 102 bytes
// ============================================================
undefined8 fcn.180096d20(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    double dVar4;
    int64_t var_10h;
    
    dVar4 = (double)fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h != 0) {
        if (dVar4 < 0.0) {
            uVar3 = func_0x0001804944a0(dVar4);
        } else {
            uVar3 = SUB84(SQRT(dVar4), 0);
        }
        fcn.180086570(arg1, uVar3);
        return 1;
    }
    fcn.180088470(arg1, 1, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180096d90
// Address: 0x180096d90
// Size: 139 bytes
// ============================================================
undefined8 fcn.180096d90(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar3 = fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 1, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    uVar4 = fcn.180085ea0(arg1, 2, &var_10h);
    if ((int32_t)var_10h != 0) {
        uVar3 = fcn.180491d70(uVar3, uVar4);
        fcn.180086570(arg1, uVar3);
        return 1;
    }
    fcn.180088470(arg1, 2, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180096e20
// Address: 0x180096e20
// Size: 51 bytes
// ============================================================
undefined8 fcn.180096e20(int64_t arg1)
{
    code *pcVar1;
    double dVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    undefined4 uVar5;
    double dVar6;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    uVar5 = fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 1, 3);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    uVar4 = *(int64_t *)(arg1 + 0x28) + 0x10;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar4) {
        uVar4 = *(uint64_t *)0x180782430;
    }
    if ((uVar4 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar4 + 0xc) < 1)) {
        uVar5 = func_0x000180491150();
    } else {
        dVar6 = (double)fcn.180085ea0(arg1, 2, &var_10h);
        if ((int32_t)var_10h == 0) {
            fcn.180088470(arg1, 2, 3);
            pcVar1 = (code *)swi(3);
            uVar3 = (*pcVar1)();
            return uVar3;
        }
        if (dVar6 == 2.0) {
            uVar5 = func_0x000180491680(uVar5);
        } else if (dVar6 == 10.0) {
            uVar5 = func_0x00018048d7c0(uVar5);
        } else {
            dVar2 = (double)func_0x000180491150(uVar5);
            dVar6 = (double)func_0x000180491150(SUB84(dVar6, 0));
            uVar5 = SUB84(dVar2 / dVar6, 0);
        }
    }
    fcn.180086570(arg1, uVar5);
    return 1;
}

// ============================================================
// Function: FUN_180096e53
// Address: 0x180096e53
// Size: 173 bytes
// ============================================================
undefined8 fcn.180096e20(int64_t arg1)
{
    code *pcVar1;
    double dVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    undefined4 uVar5;
    double dVar6;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    uVar5 = fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 1, 3);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    uVar4 = *(int64_t *)(arg1 + 0x28) + 0x10;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar4) {
        uVar4 = *(uint64_t *)0x180782430;
    }
    if ((uVar4 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar4 + 0xc) < 1)) {
        uVar5 = func_0x000180491150();
    } else {
        dVar6 = (double)fcn.180085ea0(arg1, 2, &var_10h);
        if ((int32_t)var_10h == 0) {
            fcn.180088470(arg1, 2, 3);
            pcVar1 = (code *)swi(3);
            uVar3 = (*pcVar1)();
            return uVar3;
        }
        if (dVar6 == 2.0) {
            uVar5 = func_0x000180491680(uVar5);
        } else if (dVar6 == 10.0) {
            uVar5 = func_0x00018048d7c0(uVar5);
        } else {
            dVar2 = (double)func_0x000180491150(uVar5);
            dVar6 = (double)func_0x000180491150(SUB84(dVar6, 0));
            uVar5 = SUB84(dVar2 / dVar6, 0);
        }
    }
    fcn.180086570(arg1, uVar5);
    return 1;
}

// ============================================================
// Function: FUN_180096f00
// Address: 0x180096f00
// Size: 20 bytes
// ============================================================
undefined8 fcn.180096e20(int64_t arg1)
{
    code *pcVar1;
    double dVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    undefined4 uVar5;
    double dVar6;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    uVar5 = fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 1, 3);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    uVar4 = *(int64_t *)(arg1 + 0x28) + 0x10;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar4) {
        uVar4 = *(uint64_t *)0x180782430;
    }
    if ((uVar4 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar4 + 0xc) < 1)) {
        uVar5 = func_0x000180491150();
    } else {
        dVar6 = (double)fcn.180085ea0(arg1, 2, &var_10h);
        if ((int32_t)var_10h == 0) {
            fcn.180088470(arg1, 2, 3);
            pcVar1 = (code *)swi(3);
            uVar3 = (*pcVar1)();
            return uVar3;
        }
        if (dVar6 == 2.0) {
            uVar5 = func_0x000180491680(uVar5);
        } else if (dVar6 == 10.0) {
            uVar5 = func_0x00018048d7c0(uVar5);
        } else {
            dVar2 = (double)func_0x000180491150(uVar5);
            dVar6 = (double)func_0x000180491150(SUB84(dVar6, 0));
            uVar5 = SUB84(dVar2 / dVar6, 0);
        }
    }
    fcn.180086570(arg1, uVar5);
    return 1;
}

