// Chunk 1 - 50 functions

// ============================================================
// Function: FUN_180001020
// Address: 0x180001020
// Size: 106 bytes
// ============================================================
int32_t fcn.180001020(void)
{
    undefined4 *puVar1;
    int64_t iVar2;
    
    puVar1 = (undefined4 *)fcn.180459890(0x40);
    *(undefined8 *)0x1807825f0 = 0x3a;
    *(undefined8 *)0x1807825f8 = 0x3f;
    *(undefined4 **)0x1807825e0 = puVar1;
    *puVar1 = 0x6964614d;
    puVar1[1] = 0x68206d75;
    puVar1[2] = 0x63207361;
    puVar1[3] = 0x68736172;
    puVar1[4] = 0x202c6465;
    puVar1[5] = 0x20646e61;
    puVar1[6] = 0x6c626f52;
    puVar1[7] = 0x6e20786f;
    puVar1[8] = 0x73646565;
    puVar1[9] = 0x206f7420;
    puVar1[10] = 0x74697571;
    puVar1[0xb] = 0x6557202e;
    *(undefined4 *)((int64_t)puVar1 + 0x2a) = 0x202e7469;
    *(undefined4 *)((int64_t)puVar1 + 0x2e) = 0x72276557;
    *(undefined4 *)((int64_t)puVar1 + 0x32) = 0x6f732065;
    *(undefined4 *)((int64_t)puVar1 + 0x36) = 0x21797272;
    *(undefined *)((int64_t)puVar1 + 0x3a) = 0;
    iVar2 = fcn.180459be8(0x1804a1ed0);
    return (iVar2 != 0) - 1;
}

// ============================================================
// Function: FUN_180001090
// Address: 0x180001090
// Size: 30 bytes
// ============================================================
void fcn.180001090(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782570 = iVar1 + 0x1d5cb60;
    return;
}

// ============================================================
// Function: FUN_1800010b0
// Address: 0x1800010b0
// Size: 30 bytes
// ============================================================
void fcn.1800010b0(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782558 = iVar1 + 0x82d0;
    return;
}

// ============================================================
// Function: FUN_1800010d0
// Address: 0x1800010d0
// Size: 30 bytes
// ============================================================
void fcn.1800010d0(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782588 = iVar1 + 0x4ac34c0;
    return;
}

// ============================================================
// Function: FUN_1800010f0
// Address: 0x1800010f0
// Size: 30 bytes
// ============================================================
void fcn.1800010f0(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x1807825c8 = iVar1 + 0x4ac94b0;
    return;
}

// ============================================================
// Function: FUN_180001110
// Address: 0x180001110
// Size: 30 bytes
// ============================================================
void fcn.180001110(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782630 = iVar1 + 0x1d4fbb0;
    return;
}

// ============================================================
// Function: FUN_180001130
// Address: 0x180001130
// Size: 30 bytes
// ============================================================
void fcn.180001130(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782580 = iVar1 + 0xc7a740;
    return;
}

// ============================================================
// Function: FUN_180001150
// Address: 0x180001150
// Size: 30 bytes
// ============================================================
void fcn.180001150(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782660 = iVar1 + 0x4937de0;
    return;
}

// ============================================================
// Function: FUN_180001170
// Address: 0x180001170
// Size: 30 bytes
// ============================================================
void fcn.180001170(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782578 = iVar1 + 0x4937f20;
    return;
}

// ============================================================
// Function: FUN_180001190
// Address: 0x180001190
// Size: 30 bytes
// ============================================================
void fcn.180001190(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782590 = iVar1 + 0x26b2310;
    return;
}

// ============================================================
// Function: FUN_1800011b0
// Address: 0x1800011b0
// Size: 30 bytes
// ============================================================
void fcn.1800011b0(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782650 = iVar1 + 0x26709b0;
    return;
}

// ============================================================
// Function: FUN_1800011d0
// Address: 0x1800011d0
// Size: 30 bytes
// ============================================================
void fcn.1800011d0(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782548 = iVar1 + 0x2671020;
    return;
}

// ============================================================
// Function: FUN_1800011f0
// Address: 0x1800011f0
// Size: 30 bytes
// ============================================================
void fcn.1800011f0(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782560 = iVar1 + 0x2670bc0;
    return;
}

// ============================================================
// Function: FUN_180001210
// Address: 0x180001210
// Size: 30 bytes
// ============================================================
void fcn.180001210(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782550 = iVar1 + 0x2670db0;
    return;
}

// ============================================================
// Function: FUN_180001230
// Address: 0x180001230
// Size: 30 bytes
// ============================================================
void fcn.180001230(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782628 = iVar1 + 0x2ac5820;
    return;
}

// ============================================================
// Function: FUN_180001250
// Address: 0x180001250
// Size: 30 bytes
// ============================================================
void fcn.180001250(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782530 = iVar1 + 0x1e2dbf0;
    return;
}

// ============================================================
// Function: FUN_180001270
// Address: 0x180001270
// Size: 30 bytes
// ============================================================
void fcn.180001270(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782568 = iVar1 + 0x4adef90;
    return;
}

// ============================================================
// Function: FUN_180001290
// Address: 0x180001290
// Size: 30 bytes
// ============================================================
void fcn.180001290(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782540 = iVar1 + 0x1d41120;
    return;
}

// ============================================================
// Function: FUN_1800012b0
// Address: 0x1800012b0
// Size: 30 bytes
// ============================================================
void fcn.1800012b0(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782538 = iVar1 + 0x46d6ac0;
    return;
}

// ============================================================
// Function: FUN_1800012d0
// Address: 0x1800012d0
// Size: 30 bytes
// ============================================================
void fcn.1800012d0(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782598 = iVar1 + 0x1e9e280;
    return;
}

// ============================================================
// Function: FUN_1800012f0
// Address: 0x1800012f0
// Size: 30 bytes
// ============================================================
void fcn.1800012f0(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782648 = iVar1 + 0x4917d60;
    return;
}

// ============================================================
// Function: FUN_180001310
// Address: 0x180001310
// Size: 30 bytes
// ============================================================
void fcn.180001310(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782618 = iVar1 + 0x466dd00;
    return;
}

// ============================================================
// Function: FUN_180001330
// Address: 0x180001330
// Size: 30 bytes
// ============================================================
void fcn.180001330(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x1807825d0 = iVar1 + 0x466f070;
    return;
}

// ============================================================
// Function: FUN_180001350
// Address: 0x180001350
// Size: 30 bytes
// ============================================================
void fcn.180001350(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x1807825a0 = iVar1 + 0x4683820;
    return;
}

// ============================================================
// Function: FUN_180001370
// Address: 0x180001370
// Size: 30 bytes
// ============================================================
void fcn.180001370(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782658 = iVar1 + 0x4676120;
    return;
}

// ============================================================
// Function: FUN_180001390
// Address: 0x180001390
// Size: 30 bytes
// ============================================================
void fcn.180001390(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782608 = iVar1 + 0x817e148;
    return;
}

// ============================================================
// Function: FUN_1800013b0
// Address: 0x1800013b0
// Size: 30 bytes
// ============================================================
void fcn.1800013b0(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782610 = iVar1 + 0x814d5f0;
    return;
}

// ============================================================
// Function: FUN_1800013d0
// Address: 0x1800013d0
// Size: 30 bytes
// ============================================================
void fcn.1800013d0(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x1807825b8 = iVar1 + 0x83cd300;
    return;
}

// ============================================================
// Function: FUN_1800013f0
// Address: 0x1800013f0
// Size: 30 bytes
// ============================================================
void fcn.1800013f0(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x1807825a8 = iVar1 + 0x815c668;
    return;
}

// ============================================================
// Function: FUN_180001410
// Address: 0x180001410
// Size: 30 bytes
// ============================================================
void fcn.180001410(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782600 = iVar1 + 0x61a7d80;
    return;
}

// ============================================================
// Function: FUN_180001430
// Address: 0x180001430
// Size: 30 bytes
// ============================================================
void fcn.180001430(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x1807825b0 = iVar1 + 0x82ea3f8;
    return;
}

// ============================================================
// Function: FUN_180001450
// Address: 0x180001450
// Size: 30 bytes
// ============================================================
void fcn.180001450(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782640 = iVar1 + 0x77ec150;
    return;
}

// ============================================================
// Function: FUN_180001470
// Address: 0x180001470
// Size: 30 bytes
// ============================================================
void fcn.180001470(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x1807825c0 = iVar1 + 0x68fcd10;
    return;
}

// ============================================================
// Function: FUN_180001490
// Address: 0x180001490
// Size: 30 bytes
// ============================================================
void fcn.180001490(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782638 = iVar1 + 0x68fcbb8;
    return;
}

// ============================================================
// Function: FUN_1800014b0
// Address: 0x1800014b0
// Size: 30 bytes
// ============================================================
void fcn.1800014b0(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x1807825d8 = iVar1 + 0x69a5218;
    return;
}

// ============================================================
// Function: FUN_1800014d0
// Address: 0x1800014d0
// Size: 30 bytes
// ============================================================
void fcn.1800014d0(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782520 = iVar1 + 0x5e48610;
    return;
}

// ============================================================
// Function: FUN_1800014f0
// Address: 0x1800014f0
// Size: 30 bytes
// ============================================================
void fcn.1800014f0(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782528 = iVar1 + 0x5e48678;
    return;
}

// ============================================================
// Function: FUN_180001510
// Address: 0x180001510
// Size: 30 bytes
// ============================================================
void fcn.180001510(void)
{
    int64_t iVar1;
    
    iVar1 = (*(code *)0x699d1e)(0);
    *(int64_t *)0x180782620 = iVar1 + 0x5e48530;
    return;
}

// ============================================================
// Function: FUN_180001530
// Address: 0x180001530
// Size: 119 bytes
// ============================================================
int32_t fcn.180001530(void)
{
    int64_t iVar1;
    
    *(int64_t *)0x18077af48 = fcn.180459890(0x20);
    *(int64_t *)*(int64_t *)0x18077af48 = *(int64_t *)0x18077af48;
    *(int64_t *)(*(int64_t *)0x18077af48 + 8) = *(int64_t *)0x18077af48;
    *(undefined8 *)0x18077af58 = 0;
    *(undefined (*) [16])0x18077af60 = ZEXT816(0);
    *(undefined8 *)0x18077af70 = 7;
    *(undefined8 *)0x18077af78 = 8;
    *(undefined4 *)0x18077af40 = 0x3f800000;
    func_0x00018000f7e0(0x18077af58, 0x10, *(int64_t *)0x18077af48);
    iVar1 = fcn.180459be8(0x1804a1f40);
    return (iVar1 != 0) - 1;
}

// ============================================================
// Function: FUN_1800015b0
// Address: 0x1800015b0
// Size: 54 bytes
// ============================================================
int32_t fcn.1800015b0(void)
{
    int64_t iVar1;
    
    *(int64_t *)0x1807826e0 = fcn.180459890(0x30);
    *(int64_t *)*(int64_t *)0x1807826e0 = *(int64_t *)0x1807826e0;
    *(int64_t *)(*(int64_t *)0x1807826e0 + 8) = *(int64_t *)0x1807826e0;
    *(int64_t *)(*(int64_t *)0x1807826e0 + 0x10) = *(int64_t *)0x1807826e0;
    *(undefined2 *)(*(int64_t *)0x1807826e0 + 0x18) = 0x101;
    iVar1 = fcn.180459be8(0x1804a1f60);
    return (iVar1 != 0) - 1;
}

// ============================================================
// Function: FUN_180001d80
// Address: 0x180001d80
// Size: 119 bytes
// ============================================================
int32_t fcn.180001d80(void)
{
    int64_t iVar1;
    
    *(int64_t *)0x18077af88 = fcn.180459890(0x18);
    *(int64_t *)*(int64_t *)0x18077af88 = *(int64_t *)0x18077af88;
    *(int64_t *)(*(int64_t *)0x18077af88 + 8) = *(int64_t *)0x18077af88;
    *(undefined8 *)0x18077af98 = 0;
    *(undefined (*) [16])0x18077afa0 = ZEXT816(0);
    *(undefined8 *)0x18077afb0 = 7;
    *(undefined8 *)0x18077afb8 = 8;
    *(undefined4 *)0x18077af80 = 0x3f800000;
    func_0x00018000f7e0(0x18077af98, 0x10, *(int64_t *)0x18077af88);
    iVar1 = fcn.180459be8(0x1804a2160);
    return (iVar1 != 0) - 1;
}

// ============================================================
// Function: FUN_180001e10
// Address: 0x180001e10
// Size: 119 bytes
// ============================================================
int32_t fcn.180001e10(void)
{
    int64_t iVar1;
    
    *(int64_t *)0x180782008 = fcn.180459890(0x68);
    *(int64_t *)*(int64_t *)0x180782008 = *(int64_t *)0x180782008;
    *(int64_t *)(*(int64_t *)0x180782008 + 8) = *(int64_t *)0x180782008;
    *(undefined8 *)0x180782018 = 0;
    *(undefined (*) [16])0x180782020 = ZEXT816(0);
    *(undefined8 *)0x180782030 = 7;
    *(undefined8 *)0x180782038 = 8;
    *(undefined4 *)0x180782000 = 0x3f800000;
    func_0x00018000f7e0(0x180782018, 0x10, *(int64_t *)0x180782008);
    iVar1 = fcn.180459be8(0x1804a2250);
    return (iVar1 != 0) - 1;
}

// ============================================================
// Function: FUN_180001e90
// Address: 0x180001e90
// Size: 119 bytes
// ============================================================
int32_t fcn.180001e90(void)
{
    int64_t iVar1;
    
    *(int64_t *)0x180782048 = fcn.180459890(0x20);
    *(int64_t *)*(int64_t *)0x180782048 = *(int64_t *)0x180782048;
    *(int64_t *)(*(int64_t *)0x180782048 + 8) = *(int64_t *)0x180782048;
    *(undefined8 *)0x180782058 = 0;
    *(undefined (*) [16])0x180782060 = ZEXT816(0);
    *(undefined8 *)0x180782070 = 7;
    *(undefined8 *)0x180782078 = 8;
    *(undefined4 *)0x180782040 = 0x3f800000;
    func_0x00018000f7e0(0x180782058, 0x10, *(int64_t *)0x180782048);
    iVar1 = fcn.180459be8(0x1804a22d0);
    return (iVar1 != 0) - 1;
}

// ============================================================
// Function: FUN_180001f10
// Address: 0x180001f10
// Size: 119 bytes
// ============================================================
int32_t fcn.180001f10(void)
{
    int64_t iVar1;
    
    *(int64_t *)0x180782088 = fcn.180459890(0x28);
    *(int64_t *)*(int64_t *)0x180782088 = *(int64_t *)0x180782088;
    *(int64_t *)(*(int64_t *)0x180782088 + 8) = *(int64_t *)0x180782088;
    *(undefined8 *)0x180782098 = 0;
    *(undefined (*) [16])0x1807820a0 = ZEXT816(0);
    *(undefined8 *)0x1807820b0 = 7;
    *(undefined8 *)0x1807820b8 = 8;
    *(undefined4 *)0x180782080 = 0x3f800000;
    func_0x00018000f7e0(0x180782098, 0x10, *(int64_t *)0x180782088);
    iVar1 = fcn.180459be8(0x1804a22f0);
    return (iVar1 != 0) - 1;
}

// ============================================================
// Function: FUN_180001f90
// Address: 0x180001f90
// Size: 119 bytes
// ============================================================
int32_t fcn.180001f90(void)
{
    int64_t iVar1;
    
    *(int64_t *)0x1807820c8 = fcn.180459890(0x20);
    *(int64_t *)*(int64_t *)0x1807820c8 = *(int64_t *)0x1807820c8;
    *(int64_t *)(*(int64_t *)0x1807820c8 + 8) = *(int64_t *)0x1807820c8;
    *(undefined8 *)0x1807820d8 = 0;
    *(undefined (*) [16])0x1807820e0 = ZEXT816(0);
    *(undefined8 *)0x1807820f0 = 7;
    *(undefined8 *)0x1807820f8 = 8;
    *(undefined4 *)0x1807820c0 = 0x3f800000;
    func_0x00018000f7e0(0x1807820d8, 0x10, *(int64_t *)0x1807820c8);
    iVar1 = fcn.180459be8(0x1804a2330);
    return (iVar1 != 0) - 1;
}

// ============================================================
// Function: FUN_180002010
// Address: 0x180002010
// Size: 1176 bytes
// ============================================================
uint64_t fcn.180002010(void)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 *puVar3;
    code *pcVar4;
    unkbyte3 Var5;
    uint8_t uVar6;
    uint32_t uVar7;
    char cVar14;
    int64_t iVar8;
    undefined8 *puVar9;
    undefined8 uVar10;
    uint64_t *puVar11;
    uint64_t uVar12;
    int64_t iVar13;
    char cVar15;
    int64_t iVar16;
    unkbyte7 Var18;
    char *pcVar17;
    int64_t iVar19;
    undefined *puVar20;
    int64_t iVar21;
    int64_t iVar22;
    bool bVar23;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_d8 [8];
    undefined auStack_d0 [24];
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_44h;
    
    puVar20 = auStack_d8;
    var_20h = 0x180781f38;
    *(int64_t *)0x180781f50 = func_0x0001804558e8(1);
    func_0x000180455714(&var_10h, 0);
    var_18h = *(int64_t *)0x180782480;
    if (*(uint64_t *)0x180782850 == 0) {
        func_0x000180455714(&var_8h, 0);
        if (*(uint64_t *)0x180782850 == 0) {
            *(int32_t *)0x180780f30 = *(int32_t *)0x180780f30 + 1;
            *(uint64_t *)0x180782850 = (uint64_t)*(int32_t *)0x180780f30;
        }
        func_0x00018045578c(&var_8h);
    }
    uVar12 = *(uint64_t *)0x180782850;
    iVar13 = *(uint64_t *)0x180782850 * 8;
    iVar22 = 0;
    iVar8 = iVar22;
    if ((*(uint64_t *)0x180782850 < *(uint64_t *)(*(int64_t *)0x180781f50 + 0x18)) &&
       (iVar8 = *(int64_t *)(iVar13 + *(int64_t *)(*(int64_t *)0x180781f50 + 0x10)), iVar8 != 0))
    goto code_r0x00018000212b;
    if (*(char *)(*(int64_t *)0x180781f50 + 0x24) == '\0') {
code_r0x0001800020df:
        if (iVar8 != 0) goto code_r0x00018000212b;
    } else {
        iVar8 = func_0x0001804558e0();
        if (uVar12 < *(uint64_t *)(iVar8 + 0x18)) {
            iVar8 = *(int64_t *)(iVar13 + *(int64_t *)(iVar8 + 0x10));
            goto code_r0x0001800020df;
        }
    }
    iVar8 = var_18h;
    if (var_18h == 0) {
        iVar16 = 0x180781f48;
        iVar8 = func_0x00018002e5c0(&var_18h);
        iVar13 = var_18h;
        if (iVar8 == -1) {
            puVar11 = (uint64_t *)func_0x000180005b10();
            uVar12 = *puVar11;
            *(undefined *)(iVar16 + -0x5cffffdd) = *(undefined *)(iVar16 + -0x5cffffdd);
            uVar7 = (uint32_t)(uint32_t *)((uint64_t)puVar11 & uVar12) & *(uint32_t *)((uint64_t)puVar11 & uVar12);
            cVar14 = (char)(uVar7 >> 8);
            Var18 = (unkbyte7)((uint64_t)iVar16 >> 8);
            cVar15 = (char)iVar16 + cVar14 * '\x02';
            Var5 = (unkbyte3)(uVar7 >> 8);
            uVar6 = (uint8_t)uVar7 & *(uint8_t *)(uint64_t)uVar7;
            uVar7 = CONCAT31(Var5, uVar6 & *(uint8_t *)(uint64_t)CONCAT31(Var5, uVar6));
            *(char *)0xffffffff9a000023 = *(char *)0xffffffff9a000023 + cVar14;
            uVar7 = uVar7 & *(uint32_t *)(uint64_t)uVar7;
            uVar6 = (uint8_t)(uVar7 >> 8);
            *(char *)0xffffffffa3000023 = *(char *)0xffffffffa3000023 + uVar6;
            pcVar17 = (char *)(CONCAT71(Var18, cVar15) + -0x5cffffde);
            *pcVar17 = *pcVar17 + (uVar6 & (uint8_t)((uint32_t)*(undefined4 *)(uint64_t)uVar7 >> 8));
            pcVar17 = (char *)CONCAT71(Var18, cVar15);
            *pcVar17 = *pcVar17 + (char)((uint64_t)iVar16 >> 8);
            pcVar4 = (code *)swi(3);
            uVar12 = (*pcVar4)();
            return uVar12;
        }
        var_8h = var_18h;
        func_0x0001804558a4(var_18h);
        (**(code **)(*(int64_t *)iVar13 + 8))(iVar13);
        *(int64_t *)0x180782480 = var_18h;
        iVar8 = var_18h;
    }
code_r0x00018000212b:
    func_0x00018045578c(&var_10h);
    *(int64_t *)0x180781f38 = iVar8;
    *(undefined8 *)0x180781f40 = func_0x00018000a390(0x180781f48);
    var_b8h = 0x180621ab8;
    var_b0h = 0x180621ad7;
    var_a8h = 0;
    var_a0h = 0;
    _var_98h = ZEXT816(0);
    var_88h = 0;
    var_80h = fcn.180459890(0x30);
    *(undefined8 *)(var_80h + 8) = 0x14;
    *(undefined8 *)(var_80h + 0x10) = 0;
    *(undefined8 *)(var_80h + 0x18) = 0;
    *(undefined8 *)var_80h = 0x1806221d0;
    *(undefined8 *)(var_80h + 0x20) = 0;
    *(undefined8 *)(var_80h + 0x28) = 0;
    var_70h._0_4_ = 0x401;
    var_68h = 0x180781f38;
    var_60h = 0x180781f38;
    var_50h._0_4_ = 0x401;
    var_44h._0_1_ = 0;
    var_58h = 0x43baefb;
    var_78h = var_80h;
    func_0x00018002b970(&var_b8h);
    var_8h = (int64_t)&var_80h;
    puVar9 = (undefined8 *)fcn.180459890(0x28);
    puVar9[1] = 0xd;
    puVar9[2] = 0;
    puVar9[3] = 0;
    *puVar9 = 0x1806220a8;
    *(undefined4 *)(puVar9 + 4) = 0;
    uVar10 = func_0x00018002e210(&var_80h, puVar9);
    func_0x00018002bb90(&var_b8h);
    func_0x00018002bf70(&var_80h, uVar10);
    puVar9 = (undefined8 *)fcn.180459890(0x20);
    *puVar9 = 0x1806220a0;
    puVar9[1] = 0x15;
    puVar9[2] = 0;
    puVar9[3] = 0;
    func_0x00018002e210(&var_80h, puVar9);
    iVar16 = var_80h;
    *(uint32_t *)(var_80h + 0x20) = (uint32_t)var_50h;
    *(int32_t *)(var_80h + 0x28) = (int32_t)var_a8h + 1;
    iVar8 = iVar22;
    iVar13 = var_80h;
    do {
        if (iVar13 == 0) {
            LOCK();
            piVar1 = (int32_t *)(iVar16 + 0x2c);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
            if (*(undefined8 **)0x180781f30 != (undefined8 *)0x0) {
                LOCK();
                piVar1 = (int32_t *)((int64_t)*(undefined8 **)0x180781f30 + 0x2c);
                iVar2 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                puVar9 = *(undefined8 **)0x180781f30;
                if (iVar2 == 1) {
                    while (puVar9 != (undefined8 *)0x0) {
                        puVar3 = (undefined8 *)puVar9[2];
                        puVar9[2] = 0;
                        (**(code **)*puVar9)(puVar9, 1);
                        puVar9 = puVar3;
                    }
                }
            }
            *(int64_t *)0x180781f30 = (undefined8 *)iVar16;
            if (var_a0h != 0) {
                iVar13 = var_a0h;
                puVar20 = auStack_d8;
                if ((0xfff < (uint64_t)((var_90h - var_a0h >> 2) * 4)) &&
                   (iVar13 = *(int64_t *)(var_a0h + -8), puVar20 = auStack_d8, 0x1f < (var_a0h - iVar13) - 8U)) {
                    iVar13 = 5;
                    pcVar4 = (code *)swi(0x29);
                    (*pcVar4)(5);
                    puVar20 = auStack_d0;
                }
                *(undefined8 *)(puVar20 + -8) = 0x180002451;
                func_0x000180459c3c(iVar13);
            }
            *(undefined8 *)(puVar20 + 0xa8) = 0x180459c2d;
            iVar13 = fcn.180459be8(0x1804a2350);
            return (uint64_t)((iVar13 != 0) - 1);
        }
        iVar19 = iVar8;
    // switch table (13 cases) at 0x180002474
        switch(*(undefined4 *)(iVar13 + 8)) {
        case 7:
            if (iVar8 != 0) {
                if (((*(int64_t *)(iVar13 + 0x20) == 0) ||
                    ((((*(int64_t *)(iVar13 + 0x28) == 0 && (*(int64_t *)(iVar13 + 0x30) == 0)) &&
                      (*(int64_t *)(iVar13 + 0x38) == 0)) &&
                     ((*(int16_t *)(iVar13 + 0x40) == 0 && (*(int64_t *)(*(int64_t *)(iVar13 + 0x20) + 0x18) == 0))))))
                   && (*(int64_t *)(iVar13 + 0x48) == 0)) {
                    if (((uint32_t)var_50h & 0x800) == 0) break;
                    if (*(int64_t *)(iVar13 + 0x38) == 0) {
                        bVar23 = (*(uint8_t *)(iVar13 + 0xc) & 1) == 0;
                        goto code_r0x00018000239d;
                    }
                }
code_r0x00018000239f:
                *(undefined4 *)(iVar8 + 0x34) = 0;
            }
            break;
        case 8:
        case 0xd:
            bVar23 = iVar8 == 0;
code_r0x00018000239d:
            if (!bVar23) goto code_r0x00018000239f;
            break;
        case 10:
        case 0xb:
            func_0x00018002bdb0(&var_b8h, *(undefined8 *)(iVar13 + 0x20), 0, 0);
            break;
        case 0x10:
            if (iVar8 != 0) {
                *(undefined4 *)(iVar8 + 0x34) = 0;
            }
            for (iVar21 = *(int64_t *)(iVar13 + 0x28); iVar21 != 0; iVar21 = *(int64_t *)(iVar21 + 0x28)) {
                func_0x00018002bdb0(&var_b8h, *(undefined8 *)(iVar21 + 0x10), *(undefined8 *)(iVar21 + 0x20), iVar8);
            }
            break;
        case 0x12:
            iVar19 = iVar13;
            if (iVar8 != 0) {
                *(undefined4 *)(iVar8 + 0x34) = 0;
                if (*(uint32_t *)(iVar8 + 0x24) < 2) {
                    func_0x00018002bdb0(&var_b8h, *(undefined8 *)(iVar13 + 0x10), 
                                        *(undefined8 *)(*(int64_t *)(iVar13 + 0x28) + 0x10), iVar13);
                    iVar13 = *(int64_t *)(iVar13 + 0x28);
                    iVar19 = iVar8;
                } else {
                    *(undefined4 *)(iVar13 + 0x34) = 0;
                    iVar19 = iVar8;
                }
            }
            break;
        case 0x13:
            if ((iVar8 == *(int64_t *)(iVar13 + 0x20)) && (iVar19 = iVar22, *(int32_t *)(iVar8 + 0x34) == -1)) {
                *(undefined4 *)(iVar8 + 0x34) = 1;
            }
        }
        iVar13 = *(int64_t *)(iVar13 + 0x10);
        iVar8 = iVar19;
    } while( true );
}

// ============================================================
// Function: FUN_1800024b0
// Address: 0x1800024b0
// Size: 362 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_b2h
// WARNING: [rz-ghidra] Detected overlap for variable var_b1h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.1800024b0(void)
{
    undefined auStack_118 [32];
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_118;
    var_e8h._0_4_ = 0;
    var_d0h = 8;
    var_c8h = 0xf;
    var_e0h = 0x797469746e656469;
    var_d8h = 0;
    var_c0h._0_4_ = 1;
    var_a8h = 7;
    var_a0h = 0xf;
    _var_b8h = ZEXT716(0x6574616c666564);
    var_98h._0_4_ = 2;
    var_80h = 4;
    var_78h = 0xf;
    stack0xffffffffffffff75 = SUB1611(ZEXT816(0), 5);
    var_90h._0_5_ = 0x62696c7a;
    var_70h._0_4_ = 3;
    var_58h = 4;
    var_50h = 0xf;
    stack0xffffffffffffff9d = SUB1611(ZEXT816(0), 5);
    var_68h._0_5_ = 0x70697a67;
    var_48h._0_4_ = 4;
    var_30h = 8;
    var_28h = 0xf;
    var_40h = 0x64656c6261736964;
    var_38h = 0;
    var_f8h = (int64_t)&var_e8h;
    var_f0h = (int64_t)&var_20h;
    fcn.18003e070(0x180781f58, &var_f8h);
    fcn.180459d94(&var_e8h, 0x28, 5, 0x1800131a0);
    fcn.180459c24(0x1804a23f0);
    fcn.180459870(var_18h ^ (uint64_t)auStack_118);
    return;
}

// ============================================================
// Function: FUN_180002620
// Address: 0x180002620
// Size: 362 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_b2h
// WARNING: [rz-ghidra] Detected overlap for variable var_b1h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.180002620(void)
{
    undefined auStack_118 [32];
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_118;
    var_e8h._0_4_ = 0;
    var_d0h = 8;
    var_c8h = 0xf;
    var_e0h = 0x797469746e656469;
    var_d8h = 0;
    var_c0h._0_4_ = 1;
    var_a8h = 7;
    var_a0h = 0xf;
    _var_b8h = ZEXT716(0x6574616c666564);
    var_98h._0_4_ = 2;
    var_80h = 4;
    var_78h = 0xf;
    stack0xffffffffffffff75 = SUB1611(ZEXT816(0), 5);
    var_90h._0_5_ = 0x62696c7a;
    var_70h._0_4_ = 3;
    var_58h = 4;
    var_50h = 0xf;
    stack0xffffffffffffff9d = SUB1611(ZEXT816(0), 5);
    var_68h._0_5_ = 0x70697a67;
    var_48h._0_4_ = 4;
    var_30h = 8;
    var_28h = 0xf;
    var_40h = 0x64656c6261736964;
    var_38h = 0;
    var_f8h = (int64_t)&var_e8h;
    var_f0h = (int64_t)&var_20h;
    fcn.18003e070(0x180781f68, &var_f8h);
    fcn.180459d94(&var_e8h, 0x28, 5, 0x1800131a0);
    fcn.180459c24(0x1804a2470);
    fcn.180459870(var_18h ^ (uint64_t)auStack_118);
    return;
}

// ============================================================
// Function: FUN_1800027a0
// Address: 0x1800027a0
// Size: 362 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_b2h
// WARNING: [rz-ghidra] Detected overlap for variable var_b1h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.1800027a0(void)
{
    undefined auStack_118 [32];
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_118;
    var_e8h._0_4_ = 0;
    var_d0h = 8;
    var_c8h = 0xf;
    var_e0h = 0x797469746e656469;
    var_d8h = 0;
    var_c0h._0_4_ = 1;
    var_a8h = 7;
    var_a0h = 0xf;
    _var_b8h = ZEXT716(0x6574616c666564);
    var_98h._0_4_ = 2;
    var_80h = 4;
    var_78h = 0xf;
    stack0xffffffffffffff75 = SUB1611(ZEXT816(0), 5);
    var_90h._0_5_ = 0x62696c7a;
    var_70h._0_4_ = 3;
    var_58h = 4;
    var_50h = 0xf;
    stack0xffffffffffffff9d = SUB1611(ZEXT816(0), 5);
    var_68h._0_5_ = 0x70697a67;
    var_48h._0_4_ = 4;
    var_30h = 8;
    var_28h = 0xf;
    var_40h = 0x64656c6261736964;
    var_38h = 0;
    var_f8h = (int64_t)&var_e8h;
    var_f0h = (int64_t)&var_20h;
    fcn.18003e070(0x180781f78, &var_f8h);
    fcn.180459d94(&var_e8h, 0x28, 5, 0x1800131a0);
    fcn.180459c24(0x1804a2560);
    fcn.180459870(var_18h ^ (uint64_t)auStack_118);
    return;
}

// ============================================================
// Function: FUN_180002940
// Address: 0x180002940
// Size: 58 bytes
// ============================================================
int32_t fcn.180002940(void)
{
    int64_t iVar1;
    
    func_0x000180498d90(0x1807828c0, 0x1805aadb1, 0xff);
    *(undefined *)0x1807829bf = 0;
    func_0x0001800f62d0();
    iVar1 = fcn.180459be8(0x1804a27a0);
    return (iVar1 != 0) - 1;
}

