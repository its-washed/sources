// Chunk 39 - 50 functions

// ============================================================
// Function: FUN_180088560
// Address: 0x180088560
// Size: 72 bytes
// ============================================================
void fcn.180088560(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    code *pcVar1;
    int64_t unaff_retaddr;
    int64_t in_stack_00000008;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t in_stack_ffffffffffffffe8;
    
    var_18h = arg3;
    var_20h = arg4;
    fcn.1800884a0(arg1, 1);
    fcn.180086910(arg1, arg2, &var_18h);
    fcn.180087c00(in_stack_ffffffffffffffe8, unaff_retaddr, in_stack_00000008);
    fcn.180087960(arg1);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1800885b0
// Address: 0x1800885b0
// Size: 234 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800885b0(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t var_8h;
    
    func_0x000180086cc0(arg1, 0xffffd8f0, arg2);
    iVar4 = *(int64_t *)(arg1 + 0x40) + -0x10;
    if ((iVar4 != *(int64_t *)0x180782430) && (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 0)) {
        *(int64_t *)(arg1 + 0x40) = iVar4;
        func_0x000180086fd0(arg1, 0, 0);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
            iVar3 = func_0x000180085510(arg1, 1);
            if (iVar3 == 0) {
                func_0x000180099450(arg1, 0x18063d8d0);
                fcn.180087960(arg1);
                pcVar2 = (code *)swi(3);
                uVar5 = (*pcVar2)();
                return uVar5;
            }
        }
        puVar1 = *(undefined4 **)(arg1 + 0x40);
        *puVar1 = puVar1[-4];
        puVar1[1] = puVar1[-3];
        puVar1[2] = puVar1[-2];
        puVar1[3] = puVar1[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x000180087370(arg1, 0xffffd8f0, arg2);
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1800886a0
// Address: 0x1800886a0
// Size: 125 bytes
// ============================================================
void fcn.1800886a0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint64_t uVar2;
    int32_t iVar3;
    uint64_t uVar4;
    
    iVar3 = (int32_t)arg2;
    uVar4 = (uint64_t)iVar3;
    if (iVar3 < 1) {
        if (iVar3 < -9999) {
            uVar2 = func_0x000180085370(arg1, arg2 & 0xffffffff);
        } else {
            uVar2 = uVar4 * 0x10 + *(int64_t *)(arg1 + 0x40);
        }
    } else {
        uVar2 = *(int64_t *)(arg1 + 0x28) + -0x10 + uVar4 * 0x10;
        if (*(uint64_t *)(arg1 + 0x40) <= uVar2) {
            uVar2 = *(uint64_t *)0x180782430;
        }
    }
    if (uVar2 == *(uint64_t *)0x180782430) {
        iVar3 = -1;
    } else {
        iVar3 = *(int32_t *)(uVar2 + 0xc);
    }
    if (iVar3 != (int32_t)arg3) {
        func_0x000180088470(arg1, uVar4 & 0xffffffff, arg3 & 0xffffffff);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    return;
}

// ============================================================
// Function: FUN_180088720
// Address: 0x180088720
// Size: 189 bytes
// ============================================================
int64_t fcn.180088720(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    code *pcVar1;
    uint64_t uVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int32_t iVar5;
    uint64_t uVar6;
    
    iVar5 = (int32_t)arg2;
    uVar6 = *(uint64_t *)0x180782430;
    if (iVar5 < 1) {
        if (iVar5 < -9999) {
            uVar2 = func_0x000180085370(arg1, arg2 & 0xffffffff);
        } else {
            uVar2 = (int64_t)iVar5 * 0x10 + *(int64_t *)(arg1 + 0x40);
        }
    } else {
        uVar2 = *(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar5 * 0x10;
        if (*(uint64_t *)(arg1 + 0x40) <= uVar2) {
            uVar2 = *(uint64_t *)0x180782430;
        }
    }
    if ((uVar2 == uVar6) || (*(int32_t *)(uVar2 + 0xc) < 1)) {
        if (arg4 != 0) {
            if (arg3 != 0) {
                uVar3 = func_0x000180498cd0(arg3);
                *(undefined8 *)arg4 = uVar3;
                return arg3;
            }
            *(undefined8 *)arg4 = 0;
        }
    } else {
        arg3 = func_0x0001800860c0(arg1, arg2 & 0xffffffff, arg4);
        if (arg3 == 0) {
            func_0x000180088470(arg1, arg2 & 0xffffffff, 6);
            pcVar1 = (code *)swi(3);
            iVar4 = (*pcVar1)();
            return iVar4;
        }
    }
    return arg3;
}

// ============================================================
// Function: FUN_1800887e0
// Address: 0x1800887e0
// Size: 124 bytes
// ============================================================
undefined8 fcn.1800887e0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int32_t *piVar2;
    undefined8 uVar3;
    int32_t iVar4;
    uint64_t uVar5;
    
    iVar4 = (int32_t)arg2;
    uVar5 = (uint64_t)iVar4;
    if (iVar4 < 1) {
        if (iVar4 < -9999) {
            piVar2 = (int32_t *)func_0x000180085370(arg1, arg2 & 0xffffffff);
        } else {
            piVar2 = (int32_t *)(uVar5 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        piVar2 = (int32_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + uVar5 * 0x10);
        if (*(int32_t **)(arg1 + 0x40) <= piVar2) {
            piVar2 = *(int32_t **)0x180782430;
        }
    }
    iVar4 = (int32_t)uVar5;
    if ((piVar2 == *(int32_t **)0x180782430) || (piVar2[3] != 1)) {
        func_0x000180088470(arg1, uVar5 & 0xffffffff, 1);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    if (iVar4 < 1) {
        if (iVar4 < -9999) {
            piVar2 = (int32_t *)func_0x000180085370();
        } else {
            piVar2 = (int32_t *)((int64_t)iVar4 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        piVar2 = (int32_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar4 * 0x10);
        if (*(int32_t **)(arg1 + 0x40) <= piVar2) {
            piVar2 = *(int32_t **)0x180782430;
        }
    }
    if ((piVar2[3] != 0) && ((piVar2[3] != 1 || (*piVar2 != 0)))) {
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180088860
// Address: 0x180088860
// Size: 171 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.180088860(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int32_t iVar2;
    double *pdVar3;
    int64_t var_18h;
    double adStack_18 [2];
    
    iVar2 = (int32_t)arg2;
    if (iVar2 < 1) {
        if (iVar2 < -9999) {
            pdVar3 = (double *)func_0x000180085370(arg1, arg2 & 0xffffffff);
        } else {
            pdVar3 = (double *)((int64_t)iVar2 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        pdVar3 = (double *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar2 * 0x10);
        if (*(double **)(arg1 + 0x40) <= pdVar3) {
            pdVar3 = *(double **)0x180782430;
        }
    }
    if (*(int32_t *)((int64_t)pdVar3 + 0xc) == 3) {
        return (int32_t)*pdVar3;
    }
    if ((*(int32_t *)((int64_t)pdVar3 + 0xc) == 6) &&
       (iVar2 = func_0x0001800992c0((int64_t)*pdVar3 + 0x18, adStack_18), iVar2 != 0)) {
        return (int32_t)adStack_18[0];
    }
    func_0x000180088470(arg1, arg2 & 0xffffffff, 3);
    pcVar1 = (code *)swi(3);
    iVar2 = (*pcVar1)();
    return iVar2;
}

// ============================================================
// Function: FUN_180088910
// Address: 0x180088910
// Size: 209 bytes
// ============================================================
undefined8 fcn.180088910(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    int32_t iVar4;
    uint64_t *puVar5;
    uint64_t uVar6;
    
    iVar4 = (int32_t)arg2;
    uVar6 = (uint64_t)iVar4;
    if (iVar4 < 1) {
        if (iVar4 < -9999) {
            puVar2 = (undefined8 *)func_0x000180085370(arg1, arg2 & 0xffffffff);
            puVar5 = (uint64_t *)(arg1 + 0x40);
        } else {
            puVar5 = (uint64_t *)(arg1 + 0x40);
            puVar2 = (undefined8 *)(uVar6 * 0x10 + *puVar5);
        }
    } else {
        puVar5 = (uint64_t *)(arg1 + 0x40);
        puVar2 = (undefined8 *)(*(int64_t *)(arg1 + 0x28) + -0x10 + uVar6 * 0x10);
        if ((undefined8 *)*puVar5 <= puVar2) {
            puVar2 = *(undefined8 **)0x180782430;
        }
    }
    if ((puVar2 == *(undefined8 **)0x180782430) || (*(int32_t *)((int64_t)puVar2 + 0xc) != 4)) {
        func_0x000180088470(arg1, uVar6 & 0xffffffff, 4);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    if ((int32_t)uVar6 < 1) {
        if ((int32_t)uVar6 < -9999) {
            puVar2 = (undefined8 *)func_0x000180085370(arg1, uVar6 & 0xffffffff);
        } else {
            puVar2 = (undefined8 *)(uVar6 * 0x10 + *puVar5);
        }
    } else {
        puVar2 = (undefined8 *)(*(int64_t *)(arg1 + 0x28) + -0x10 + uVar6 * 0x10);
        if ((undefined8 *)*puVar5 <= puVar2) {
            puVar2 = *(undefined8 **)0x180782430;
        }
    }
    if (*(int32_t *)((int64_t)puVar2 + 0xc) != 4) {
        return 0;
    }
    return *puVar2;
}

// ============================================================
// Function: FUN_1800889f0
// Address: 0x1800889f0
// Size: 120 bytes
// ============================================================
uint64_t fcn.1800889f0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    int32_t iVar2;
    double *pdVar3;
    uint64_t uVar4;
    double adStack_18 [2];
    
    iVar2 = (int32_t)arg2;
    uVar4 = (uint64_t)iVar2;
    if (iVar2 < 1) {
        if (iVar2 < -9999) {
            pdVar3 = (double *)func_0x000180085370(arg1, arg2 & 0xffffffff);
        } else {
            pdVar3 = (double *)(uVar4 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        pdVar3 = (double *)(*(int64_t *)(arg1 + 0x28) + -0x10 + uVar4 * 0x10);
        if (*(double **)(arg1 + 0x40) <= pdVar3) {
            pdVar3 = *(double **)0x180782430;
        }
    }
    if ((pdVar3 == *(double **)0x180782430) || (*(int32_t *)((int64_t)pdVar3 + 0xc) < 1)) {
        return arg3 & 0xffffffff;
    }
    iVar2 = (int32_t)uVar4;
    if (iVar2 < 1) {
        if (iVar2 < -9999) {
            pdVar3 = (double *)func_0x000180085370(arg1, uVar4 & 0xffffffff);
        } else {
            pdVar3 = (double *)((int64_t)iVar2 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        pdVar3 = (double *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar2 * 0x10);
        if (*(double **)(arg1 + 0x40) <= pdVar3) {
            pdVar3 = *(double **)0x180782430;
        }
    }
    if (*(int32_t *)((int64_t)pdVar3 + 0xc) == 3) {
        return (uint64_t)(uint32_t)(int32_t)*pdVar3;
    }
    if ((*(int32_t *)((int64_t)pdVar3 + 0xc) == 6) &&
       (iVar2 = func_0x0001800992c0((int64_t)*pdVar3 + 0x18, adStack_18), iVar2 != 0)) {
        return (uint64_t)(uint32_t)(int32_t)adStack_18[0];
    }
    func_0x000180088470(arg1, uVar4 & 0xffffffff, 3);
    pcVar1 = (code *)swi(3);
    uVar4 = (*pcVar1)();
    return uVar4;
}

// ============================================================
// Function: FUN_180088a70
// Address: 0x180088a70
// Size: 173 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180088a70(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int32_t iVar2;
    double *pdVar3;
    int64_t iVar4;
    int64_t var_18h;
    double adStack_18 [2];
    
    iVar2 = (int32_t)arg2;
    if (iVar2 < 1) {
        if (iVar2 < -9999) {
            pdVar3 = (double *)func_0x000180085370(arg1, arg2 & 0xffffffff);
        } else {
            pdVar3 = (double *)((int64_t)iVar2 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        pdVar3 = (double *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar2 * 0x10);
        if (*(double **)(arg1 + 0x40) <= pdVar3) {
            pdVar3 = *(double **)0x180782430;
        }
    }
    if (*(int32_t *)((int64_t)pdVar3 + 0xc) == 3) {
        return (int64_t)*pdVar3;
    }
    if ((*(int32_t *)((int64_t)pdVar3 + 0xc) == 6) &&
       (iVar2 = func_0x0001800992c0((int64_t)*pdVar3 + 0x18, adStack_18), iVar2 != 0)) {
        return (int64_t)adStack_18[0];
    }
    func_0x000180088470(arg1, arg2 & 0xffffffff, 3);
    pcVar1 = (code *)swi(3);
    iVar4 = (*pcVar1)();
    return iVar4;
}

// ============================================================
// Function: FUN_180088b20
// Address: 0x180088b20
// Size: 442 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.180088b20(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined4 *puVar6;
    uint32_t uVar7;
    uint64_t arg4;
    int64_t var_38h;
    
    if (arg2 != 0) {
        uVar7 = 0;
        iVar4 = *(int64_t *)arg3;
        piVar1 = (int64_t *)arg3;
        while (iVar4 != 0) {
            uVar7 = uVar7 + 1;
            piVar1 = piVar1 + 2;
            iVar4 = *piVar1;
        }
        func_0x000180088ce0(arg1, 0xffffd8f0, 0x18063da18, 1);
        func_0x000180086cc0(arg1, 0xffffffff, arg2);
        iVar4 = *(int64_t *)(arg1 + 0x40) + -0x10;
        if ((iVar4 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 7)) {
            arg4 = (uint64_t)uVar7;
            *(int64_t *)(arg1 + 0x40) = iVar4;
            iVar4 = func_0x000180088ce0(arg1, 0xffffd8ee, arg2);
            if (iVar4 != 0) {
                fcn.180088560(arg1, 0x18063da68, arg2, arg4);
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U))
               && (iVar3 = func_0x000180085510(arg1, 1), iVar3 == 0)) {
                func_0x000180099450(arg1, 0x18063d8d0);
                fcn.180087960(arg1);
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
            puVar5 = *(undefined4 **)(arg1 + 0x40);
            *puVar5 = puVar5[-4];
            puVar5[1] = puVar5[-3];
            puVar5[2] = puVar5[-2];
            puVar5[3] = puVar5[-1];
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x000180087370(arg1, 0xfffffffd, arg2);
        }
        puVar6 = *(undefined4 **)(arg1 + 0x40);
        puVar5 = puVar6 + -4;
        if (puVar5 < puVar6) {
            do {
                puVar5[-4] = *puVar5;
                puVar5[-3] = puVar5[1];
                puVar5[-2] = puVar5[2];
                puVar5[-1] = puVar5[3];
                puVar6 = *(undefined4 **)(arg1 + 0x40);
                puVar5 = puVar5 + 4;
            } while (puVar5 < puVar6);
        }
        *(undefined4 **)(arg1 + 0x40) = puVar6 + -4;
    }
    iVar4 = *(int64_t *)arg3;
    while (iVar4 != 0) {
        func_0x0001800869f0(arg1, *(undefined8 *)(arg3 + 8), iVar4, 0, 0);
        func_0x000180087370(arg1, 0xfffffffe, *(undefined8 *)arg3);
        piVar1 = (int64_t *)(arg3 + 0x10);
        arg3 = arg3 + 0x10;
        iVar4 = *piVar1;
    }
    return;
}

// ============================================================
// Function: FUN_180088ce0
// Address: 0x180088ce0
// Size: 703 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

char * fcn.180088ce0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4)
{
    uint8_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 *puVar7;
    int32_t iVar8;
    int32_t iVar9;
    char *pcVar10;
    int64_t iVar11;
    undefined4 *puVar12;
    undefined *puVar13;
    undefined4 *puVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    func_0x000180085bf0();
    do {
        pcVar10 = (char *)func_0x00018045b928(arg3, 0x2e);
        if (pcVar10 == (char *)0x0) {
            iVar11 = func_0x000180498cd0(arg3);
            pcVar10 = (char *)(arg3 + iVar11);
        }
        func_0x0001800867f0(arg1, arg3, (int64_t)pcVar10 - arg3);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar11 = *(int64_t *)(arg1 + 0x40);
        puVar12 = (undefined4 *)func_0x0001800a0ea0(*(undefined8 *)(iVar11 + -0x20), (undefined4 *)(iVar11 + -0x10));
        puVar7 = *(undefined4 **)0x180782430;
        uVar4 = puVar12[1];
        uVar5 = puVar12[2];
        uVar6 = puVar12[3];
        *(undefined4 *)(iVar11 + -0x10) = *puVar12;
        *(undefined4 *)(iVar11 + -0xc) = uVar4;
        *(undefined4 *)(iVar11 + -8) = uVar5;
        *(undefined4 *)(iVar11 + -4) = uVar6;
        puVar14 = *(undefined4 **)(arg1 + 0x40);
        puVar12 = puVar14 + -4;
        if (puVar12 == puVar7) {
code_r0x000180088f5f:
            *(undefined4 **)(arg1 + 0x40) = puVar14 + -8;
            return (char *)arg3;
        }
        if (puVar14[-1] == 0) {
            iVar9 = (int32_t)arg4;
            *(undefined4 **)(arg1 + 0x40) = puVar12;
            if (*pcVar10 == '.') {
                iVar9 = 1;
            }
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, CONCAT71((unkint7)((uint64_t)puVar12 >> 8), 1));
            }
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U))
               && (iVar8 = func_0x000180085510(arg1, 1), iVar8 == 0)) {
code_r0x000180088f87:
                func_0x000180099450(arg1, 0x18063d8d0);
                fcn.180087960(arg1);
                pcVar3 = (code *)swi(3);
                pcVar10 = (char *)(*pcVar3)();
                return pcVar10;
            }
            puVar2 = *(undefined8 **)(arg1 + 0x40);
            puVar13 = (undefined *)func_0x000180098710(arg1, 0x30, *(undefined *)(arg1 + 4));
            uVar1 = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58);
            puVar13[2] = 7;
            puVar13[1] = uVar1 & 3;
            *puVar13 = *(undefined *)(arg1 + 4);
            *(undefined8 *)(puVar13 + 0x10) = 0;
            *(undefined8 *)(puVar13 + 0x20) = 0;
            *(undefined8 *)(puVar13 + 8) = 0;
            puVar13[3] = 0;
            *(undefined8 *)(puVar13 + 0x28) = *(undefined8 *)0x1807823c8;
            *(undefined4 *)(puVar13 + 4) = 0xff00;
            if (0 < iVar9) {
                func_0x0001800a0320(arg1, puVar13, iVar9);
            }
            *puVar2 = puVar13;
            *(undefined4 *)((int64_t)puVar2 + 0xc) = 7;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x0001800867f0(arg1, arg3, (int64_t)pcVar10 - arg3);
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U))
               && (iVar9 = func_0x000180085510(arg1, 1), iVar9 == 0)) goto code_r0x000180088f87;
            puVar12 = *(undefined4 **)(arg1 + 0x40);
            *puVar12 = puVar12[-8];
            puVar12[1] = puVar12[-7];
            puVar12[2] = puVar12[-6];
            puVar12[3] = puVar12[-5];
            iVar11 = *(int64_t *)(arg1 + 0x40);
            *(int64_t *)(arg1 + 0x40) = iVar11 + 0x10;
            func_0x0001800a8680(arg1, iVar11 + -0x30, iVar11 + -0x10);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
            puVar14 = *(undefined4 **)(arg1 + 0x40);
        } else if ((puVar12 == puVar7) || (puVar14[-1] != 7)) goto code_r0x000180088f5f;
        puVar12 = puVar14 + -4;
        if (puVar12 < puVar14) {
            do {
                puVar12[-4] = *puVar12;
                puVar12[-3] = puVar12[1];
                puVar12[-2] = puVar12[2];
                puVar12[-1] = puVar12[3];
                puVar14 = *(undefined4 **)(arg1 + 0x40);
                puVar12 = puVar12 + 4;
            } while (puVar12 < puVar14);
        }
        *(undefined4 **)(arg1 + 0x40) = puVar14 + -4;
        if (*pcVar10 != '.') {
            return (char *)0x0;
        }
        arg3 = (int64_t)(pcVar10 + 1);
    } while( true );
}

// ============================================================
// Function: FUN_180088fa0
// Address: 0x180088fa0
// Size: 49 bytes
// ============================================================
int64_t fcn.180088fa0(int64_t arg1)
{
    int64_t iVar1;
    
    iVar1 = fcn.180085430();
    if (iVar1 != 0) {
        iVar1 = fcn.1800a3b90(arg1, iVar1);
        return iVar1 + 0x18;
    }
    return 0x18063d8c0;
}

// ============================================================
// Function: FUN_180088fe0
// Address: 0x180088fe0
// Size: 221 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180088fe0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4)
{
    uint32_t *puVar1;
    char cVar2;
    int64_t iVar3;
    int32_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    iVar4 = (int32_t)arg4;
    iVar3 = **(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8);
    *(int32_t *)(*(int64_t *)(arg1 + 0x18) + 0x18) = iVar4;
    puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
    *puVar1 = *puVar1 | 2;
    var_18h = *(int64_t *)(arg1 + 0x40) + (int64_t)((int32_t)arg2 + 1) * -0x10;
    var_10h._0_4_ = 0xffffffff;
    if (iVar4 == 0) {
        iVar6 = 0;
    } else {
        iVar6 = ((int64_t)(iVar4 + -1) * 0x10 + *(int64_t *)(arg1 + 0x28)) - *(int64_t *)(arg1 + 0x38);
    }
    iVar4 = func_0x000180094080(arg1, 0x1800890c0, &var_18h, var_18h - *(int64_t *)(arg1 + 0x38), iVar6);
    if (**(uint64_t **)(arg1 + 0x18) < *(uint64_t *)(arg1 + 0x40)) {
        **(uint64_t **)(arg1 + 0x18) = *(uint64_t *)(arg1 + 0x40);
    }
    if ((iVar4 == 0) && (((cVar2 = *(char *)(arg1 + 3), cVar2 == '\x01' || (cVar2 == '\x06')) || (cVar2 == '\x7f')))) {
        return 0xffffffff;
    }
    puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
    *puVar1 = *puVar1 & 0xfffffffd;
    uVar5 = (*(code *)(*(int64_t *)(iVar3 + 0x28) + 0x28 + iVar3))(arg1);
    return uVar5;
}

// ============================================================
// Function: FUN_1800890e0
// Address: 0x1800890e0
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800890e0(int64_t arg1, uint64_t placeholder_1, int64_t arg3)
{
    uint64_t arg4;
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint64_t arg3_00;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    
    iVar1 = *(int64_t *)(arg1 + 0x10);
    iVar5 = *(int64_t *)(arg1 + 0x18) + 0x18;
    if (*(int64_t *)(arg1 + 0x18) == 0) {
        iVar5 = arg1 + 0x20;
    }
    arg3_00 = *(int64_t *)(arg1 + 8) - iVar5;
    arg4 = arg3_00 + placeholder_1;
    if (arg3_00 <= ~arg4) {
        if (arg4 <= arg3_00 + (arg3_00 >> 1)) {
            placeholder_1 = arg3_00 >> 1;
        }
        iVar3 = fcn.18009a770(iVar1, placeholder_1 + arg3_00);
        fcn.180498030(iVar3 + 0x18, iVar5, *(int64_t *)arg1 - iVar5);
        if (iVar5 == arg1 + 0x20) {
            fcn.180086510(iVar1);
            fcn.1800859a0(iVar1, arg3 & 0xffffffff);
        }
        iVar1 = *(int64_t *)(iVar1 + 0x40);
        *(int64_t *)(iVar1 + (int64_t)(int32_t)arg3 * 0x10) = iVar3;
        *(undefined4 *)(iVar1 + 0xc + (int64_t)(int32_t)arg3 * 0x10) = 6;
        *(int64_t *)(arg1 + 0x18) = iVar3;
        *(int64_t *)arg1 = *(int64_t *)arg1 + (iVar3 - iVar5) + 0x18;
        *(uint64_t *)(arg1 + 8) = placeholder_1 + arg3_00 + 0x18 + iVar3;
        return *(undefined8 *)arg1;
    }
    fcn.180088560(iVar1, 0x18063da50, arg3_00, arg4);
    pcVar2 = (code *)swi(3);
    uVar4 = (*pcVar2)();
    return uVar4;
}

// ============================================================
// Function: FUN_18008912d
// Address: 0x18008912d
// Size: 168 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800890e0(int64_t arg1, uint64_t placeholder_1, int64_t arg3)
{
    uint64_t arg4;
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint64_t arg3_00;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    
    iVar1 = *(int64_t *)(arg1 + 0x10);
    iVar5 = *(int64_t *)(arg1 + 0x18) + 0x18;
    if (*(int64_t *)(arg1 + 0x18) == 0) {
        iVar5 = arg1 + 0x20;
    }
    arg3_00 = *(int64_t *)(arg1 + 8) - iVar5;
    arg4 = arg3_00 + placeholder_1;
    if (arg3_00 <= ~arg4) {
        if (arg4 <= arg3_00 + (arg3_00 >> 1)) {
            placeholder_1 = arg3_00 >> 1;
        }
        iVar3 = fcn.18009a770(iVar1, placeholder_1 + arg3_00);
        fcn.180498030(iVar3 + 0x18, iVar5, *(int64_t *)arg1 - iVar5);
        if (iVar5 == arg1 + 0x20) {
            fcn.180086510(iVar1);
            fcn.1800859a0(iVar1, arg3 & 0xffffffff);
        }
        iVar1 = *(int64_t *)(iVar1 + 0x40);
        *(int64_t *)(iVar1 + (int64_t)(int32_t)arg3 * 0x10) = iVar3;
        *(undefined4 *)(iVar1 + 0xc + (int64_t)(int32_t)arg3 * 0x10) = 6;
        *(int64_t *)(arg1 + 0x18) = iVar3;
        *(int64_t *)arg1 = *(int64_t *)arg1 + (iVar3 - iVar5) + 0x18;
        *(uint64_t *)(arg1 + 8) = placeholder_1 + arg3_00 + 0x18 + iVar3;
        return *(undefined8 *)arg1;
    }
    fcn.180088560(iVar1, 0x18063da50, arg3_00, arg4);
    pcVar2 = (code *)swi(3);
    uVar4 = (*pcVar2)();
    return uVar4;
}

// ============================================================
// Function: FUN_1800891d5
// Address: 0x1800891d5
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800890e0(int64_t arg1, uint64_t placeholder_1, int64_t arg3)
{
    uint64_t arg4;
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint64_t arg3_00;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    
    iVar1 = *(int64_t *)(arg1 + 0x10);
    iVar5 = *(int64_t *)(arg1 + 0x18) + 0x18;
    if (*(int64_t *)(arg1 + 0x18) == 0) {
        iVar5 = arg1 + 0x20;
    }
    arg3_00 = *(int64_t *)(arg1 + 8) - iVar5;
    arg4 = arg3_00 + placeholder_1;
    if (arg3_00 <= ~arg4) {
        if (arg4 <= arg3_00 + (arg3_00 >> 1)) {
            placeholder_1 = arg3_00 >> 1;
        }
        iVar3 = fcn.18009a770(iVar1, placeholder_1 + arg3_00);
        fcn.180498030(iVar3 + 0x18, iVar5, *(int64_t *)arg1 - iVar5);
        if (iVar5 == arg1 + 0x20) {
            fcn.180086510(iVar1);
            fcn.1800859a0(iVar1, arg3 & 0xffffffff);
        }
        iVar1 = *(int64_t *)(iVar1 + 0x40);
        *(int64_t *)(iVar1 + (int64_t)(int32_t)arg3 * 0x10) = iVar3;
        *(undefined4 *)(iVar1 + 0xc + (int64_t)(int32_t)arg3 * 0x10) = 6;
        *(int64_t *)(arg1 + 0x18) = iVar3;
        *(int64_t *)arg1 = *(int64_t *)arg1 + (iVar3 - iVar5) + 0x18;
        *(uint64_t *)(arg1 + 8) = placeholder_1 + arg3_00 + 0x18 + iVar3;
        return *(undefined8 *)arg1;
    }
    fcn.180088560(iVar1, 0x18063da50, arg3_00, arg4);
    pcVar2 = (code *)swi(3);
    uVar4 = (*pcVar2)();
    return uVar4;
}

// ============================================================
// Function: FUN_1800891f0
// Address: 0x1800891f0
// Size: 113 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800891f0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar2 = *(int64_t *)(arg1 + 0x10);
    iVar3 = *(int64_t *)(iVar2 + 0x40);
    if (*(int32_t *)(iVar3 + -4) != 6) {
        if ((*(uint8_t *)(iVar2 + 1) & 4) != 0) {
            *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
            *(undefined8 *)(iVar2 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar2 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(iVar2 + 0x20) + 0x18) = iVar2;
        }
        iVar4 = func_0x0001800a8360(iVar2);
        if (iVar4 == 0) {
            return;
        }
        if (*(uint64_t *)(*(int64_t *)(iVar2 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(iVar2 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(iVar2, 1);
        }
        iVar3 = *(int64_t *)(iVar2 + 0x40);
    }
    iVar1 = *(int64_t *)(iVar3 + -0x10) + 0x18;
    if (iVar1 != 0) {
        uVar5 = (uint64_t)*(uint32_t *)(*(int64_t *)(iVar3 + -0x10) + 0x14);
        if ((uint64_t)(*(int64_t *)(arg1 + 8) - *(int64_t *)arg1) < uVar5) {
            fcn.1800890e0(arg1, (*(int64_t *)arg1 - *(int64_t *)(arg1 + 8)) + uVar5, 0xfffffffe);
        }
        fcn.180498030(*(undefined8 *)arg1, iVar1, uVar5);
        *(uint64_t *)arg1 = *(int64_t *)arg1 + uVar5;
        *(int64_t *)(iVar2 + 0x40) = *(int64_t *)(iVar2 + 0x40) + -0x10;
    }
    return;
}

// ============================================================
// Function: FUN_180089261
// Address: 0x180089261
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800891f0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar2 = *(int64_t *)(arg1 + 0x10);
    iVar3 = *(int64_t *)(iVar2 + 0x40);
    if (*(int32_t *)(iVar3 + -4) != 6) {
        if ((*(uint8_t *)(iVar2 + 1) & 4) != 0) {
            *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
            *(undefined8 *)(iVar2 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar2 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(iVar2 + 0x20) + 0x18) = iVar2;
        }
        iVar4 = func_0x0001800a8360(iVar2);
        if (iVar4 == 0) {
            return;
        }
        if (*(uint64_t *)(*(int64_t *)(iVar2 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(iVar2 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(iVar2, 1);
        }
        iVar3 = *(int64_t *)(iVar2 + 0x40);
    }
    iVar1 = *(int64_t *)(iVar3 + -0x10) + 0x18;
    if (iVar1 != 0) {
        uVar5 = (uint64_t)*(uint32_t *)(*(int64_t *)(iVar3 + -0x10) + 0x14);
        if ((uint64_t)(*(int64_t *)(arg1 + 8) - *(int64_t *)arg1) < uVar5) {
            fcn.1800890e0(arg1, (*(int64_t *)arg1 - *(int64_t *)(arg1 + 8)) + uVar5, 0xfffffffe);
        }
        fcn.180498030(*(undefined8 *)arg1, iVar1, uVar5);
        *(uint64_t *)arg1 = *(int64_t *)arg1 + uVar5;
        *(int64_t *)(iVar2 + 0x40) = *(int64_t *)(iVar2 + 0x40) + -0x10;
    }
    return;
}

// ============================================================
// Function: FUN_1800892b3
// Address: 0x1800892b3
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800891f0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar2 = *(int64_t *)(arg1 + 0x10);
    iVar3 = *(int64_t *)(iVar2 + 0x40);
    if (*(int32_t *)(iVar3 + -4) != 6) {
        if ((*(uint8_t *)(iVar2 + 1) & 4) != 0) {
            *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
            *(undefined8 *)(iVar2 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar2 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(iVar2 + 0x20) + 0x18) = iVar2;
        }
        iVar4 = func_0x0001800a8360(iVar2);
        if (iVar4 == 0) {
            return;
        }
        if (*(uint64_t *)(*(int64_t *)(iVar2 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(iVar2 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(iVar2, 1);
        }
        iVar3 = *(int64_t *)(iVar2 + 0x40);
    }
    iVar1 = *(int64_t *)(iVar3 + -0x10) + 0x18;
    if (iVar1 != 0) {
        uVar5 = (uint64_t)*(uint32_t *)(*(int64_t *)(iVar3 + -0x10) + 0x14);
        if ((uint64_t)(*(int64_t *)(arg1 + 8) - *(int64_t *)arg1) < uVar5) {
            fcn.1800890e0(arg1, (*(int64_t *)arg1 - *(int64_t *)(arg1 + 8)) + uVar5, 0xfffffffe);
        }
        fcn.180498030(*(undefined8 *)arg1, iVar1, uVar5);
        *(uint64_t *)arg1 = *(int64_t *)arg1 + uVar5;
        *(int64_t *)(iVar2 + 0x40) = *(int64_t *)(iVar2 + 0x40) + -0x10;
    }
    return;
}

// ============================================================
// Function: FUN_1800892d0
// Address: 0x1800892d0
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.1800892d0(int64_t arg1)
{
    undefined8 *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    undefined8 uVar7;
    int64_t unaff_RBP;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar2 = *(int64_t *)(arg1 + 0x18);
    iVar3 = *(int64_t *)(arg1 + 0x10);
    if (iVar2 == 0) {
        iVar2 = *(int64_t *)arg1;
        if (*(uint64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(iVar3, CONCAT71((unkint7)((uint64_t)(arg1 + 0x20) >> 8), 1));
        }
        if ((*(uint8_t *)(iVar3 + 1) & 4) != 0) {
            *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
            *(undefined8 *)(iVar3 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar3 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x18) = iVar3;
        }
        if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar3 + 0x18) < *(int64_t *)(iVar3 + 0x40) + 0x10U)) {
            iVar6 = fcn.180085510(unaff_RBP);
            if (iVar6 == 0) {
                fcn.180099450(iVar3, 0x18063d8d0);
                fcn.180087960(iVar3);
                pcVar5 = (code *)swi(3);
                (*pcVar5)();
                return;
            }
        }
        puVar1 = *(undefined8 **)(iVar3 + 0x40);
        uVar7 = func_0x00018009a8e0(iVar3, arg1 + 0x20, (iVar2 - arg1) + -0x20);
        *puVar1 = uVar7;
        *(undefined4 *)((int64_t)puVar1 + 0xc) = 6;
        *(int64_t *)(iVar3 + 0x40) = *(int64_t *)(iVar3 + 0x40) + 0x10;
        return;
    }
    iVar4 = *(int64_t *)(iVar3 + 0x20);
    if (*(uint64_t *)(iVar4 + 0x28) <= *(uint64_t *)(iVar4 + 0x30)) {
        (**(code **)0x180782658)(iVar3, CONCAT71((unkint7)((uint64_t)iVar4 >> 8), 1));
    }
    iVar4 = *(int64_t *)(iVar3 + 0x40);
    if (*(int64_t *)arg1 == *(int64_t *)(arg1 + 8)) {
        uVar7 = func_0x00018009a7e0(iVar3, iVar2);
        *(undefined8 *)(iVar4 + -0x10) = uVar7;
        *(undefined4 *)(iVar4 + -4) = 6;
        return;
    }
    uVar7 = func_0x00018009a8e0(iVar3, iVar2 + 0x18, (*(int64_t *)arg1 - iVar2) + -0x18);
    *(undefined8 *)(iVar4 + -0x10) = uVar7;
    *(undefined4 *)(iVar4 + -4) = 6;
    return;
}

// ============================================================
// Function: FUN_1800892f7
// Address: 0x1800892f7
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.1800892d0(int64_t arg1)
{
    undefined8 *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    undefined8 uVar7;
    int64_t unaff_RBP;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar2 = *(int64_t *)(arg1 + 0x18);
    iVar3 = *(int64_t *)(arg1 + 0x10);
    if (iVar2 == 0) {
        iVar2 = *(int64_t *)arg1;
        if (*(uint64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(iVar3, CONCAT71((unkint7)((uint64_t)(arg1 + 0x20) >> 8), 1));
        }
        if ((*(uint8_t *)(iVar3 + 1) & 4) != 0) {
            *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
            *(undefined8 *)(iVar3 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar3 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x18) = iVar3;
        }
        if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar3 + 0x18) < *(int64_t *)(iVar3 + 0x40) + 0x10U)) {
            iVar6 = fcn.180085510(unaff_RBP);
            if (iVar6 == 0) {
                fcn.180099450(iVar3, 0x18063d8d0);
                fcn.180087960(iVar3);
                pcVar5 = (code *)swi(3);
                (*pcVar5)();
                return;
            }
        }
        puVar1 = *(undefined8 **)(iVar3 + 0x40);
        uVar7 = func_0x00018009a8e0(iVar3, arg1 + 0x20, (iVar2 - arg1) + -0x20);
        *puVar1 = uVar7;
        *(undefined4 *)((int64_t)puVar1 + 0xc) = 6;
        *(int64_t *)(iVar3 + 0x40) = *(int64_t *)(iVar3 + 0x40) + 0x10;
        return;
    }
    iVar4 = *(int64_t *)(iVar3 + 0x20);
    if (*(uint64_t *)(iVar4 + 0x28) <= *(uint64_t *)(iVar4 + 0x30)) {
        (**(code **)0x180782658)(iVar3, CONCAT71((unkint7)((uint64_t)iVar4 >> 8), 1));
    }
    iVar4 = *(int64_t *)(iVar3 + 0x40);
    if (*(int64_t *)arg1 == *(int64_t *)(arg1 + 8)) {
        uVar7 = func_0x00018009a7e0(iVar3, iVar2);
        *(undefined8 *)(iVar4 + -0x10) = uVar7;
        *(undefined4 *)(iVar4 + -4) = 6;
        return;
    }
    uVar7 = func_0x00018009a8e0(iVar3, iVar2 + 0x18, (*(int64_t *)arg1 - iVar2) + -0x18);
    *(undefined8 *)(iVar4 + -0x10) = uVar7;
    *(undefined4 *)(iVar4 + -4) = 6;
    return;
}

// ============================================================
// Function: FUN_18008934a
// Address: 0x18008934a
// Size: 44 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.1800892d0(int64_t arg1)
{
    undefined8 *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    undefined8 uVar7;
    int64_t unaff_RBP;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar2 = *(int64_t *)(arg1 + 0x18);
    iVar3 = *(int64_t *)(arg1 + 0x10);
    if (iVar2 == 0) {
        iVar2 = *(int64_t *)arg1;
        if (*(uint64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(iVar3, CONCAT71((unkint7)((uint64_t)(arg1 + 0x20) >> 8), 1));
        }
        if ((*(uint8_t *)(iVar3 + 1) & 4) != 0) {
            *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
            *(undefined8 *)(iVar3 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar3 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x18) = iVar3;
        }
        if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar3 + 0x18) < *(int64_t *)(iVar3 + 0x40) + 0x10U)) {
            iVar6 = fcn.180085510(unaff_RBP);
            if (iVar6 == 0) {
                fcn.180099450(iVar3, 0x18063d8d0);
                fcn.180087960(iVar3);
                pcVar5 = (code *)swi(3);
                (*pcVar5)();
                return;
            }
        }
        puVar1 = *(undefined8 **)(iVar3 + 0x40);
        uVar7 = func_0x00018009a8e0(iVar3, arg1 + 0x20, (iVar2 - arg1) + -0x20);
        *puVar1 = uVar7;
        *(undefined4 *)((int64_t)puVar1 + 0xc) = 6;
        *(int64_t *)(iVar3 + 0x40) = *(int64_t *)(iVar3 + 0x40) + 0x10;
        return;
    }
    iVar4 = *(int64_t *)(iVar3 + 0x20);
    if (*(uint64_t *)(iVar4 + 0x28) <= *(uint64_t *)(iVar4 + 0x30)) {
        (**(code **)0x180782658)(iVar3, CONCAT71((unkint7)((uint64_t)iVar4 >> 8), 1));
    }
    iVar4 = *(int64_t *)(iVar3 + 0x40);
    if (*(int64_t *)arg1 == *(int64_t *)(arg1 + 8)) {
        uVar7 = func_0x00018009a7e0(iVar3, iVar2);
        *(undefined8 *)(iVar4 + -0x10) = uVar7;
        *(undefined4 *)(iVar4 + -4) = 6;
        return;
    }
    uVar7 = func_0x00018009a8e0(iVar3, iVar2 + 0x18, (*(int64_t *)arg1 - iVar2) + -0x18);
    *(undefined8 *)(iVar4 + -0x10) = uVar7;
    *(undefined4 *)(iVar4 + -4) = 6;
    return;
}

// ============================================================
// Function: FUN_180089376
// Address: 0x180089376
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.1800892d0(int64_t arg1)
{
    undefined8 *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    undefined8 uVar7;
    int64_t unaff_RBP;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar2 = *(int64_t *)(arg1 + 0x18);
    iVar3 = *(int64_t *)(arg1 + 0x10);
    if (iVar2 == 0) {
        iVar2 = *(int64_t *)arg1;
        if (*(uint64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(iVar3, CONCAT71((unkint7)((uint64_t)(arg1 + 0x20) >> 8), 1));
        }
        if ((*(uint8_t *)(iVar3 + 1) & 4) != 0) {
            *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
            *(undefined8 *)(iVar3 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar3 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x18) = iVar3;
        }
        if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar3 + 0x18) < *(int64_t *)(iVar3 + 0x40) + 0x10U)) {
            iVar6 = fcn.180085510(unaff_RBP);
            if (iVar6 == 0) {
                fcn.180099450(iVar3, 0x18063d8d0);
                fcn.180087960(iVar3);
                pcVar5 = (code *)swi(3);
                (*pcVar5)();
                return;
            }
        }
        puVar1 = *(undefined8 **)(iVar3 + 0x40);
        uVar7 = func_0x00018009a8e0(iVar3, arg1 + 0x20, (iVar2 - arg1) + -0x20);
        *puVar1 = uVar7;
        *(undefined4 *)((int64_t)puVar1 + 0xc) = 6;
        *(int64_t *)(iVar3 + 0x40) = *(int64_t *)(iVar3 + 0x40) + 0x10;
        return;
    }
    iVar4 = *(int64_t *)(iVar3 + 0x20);
    if (*(uint64_t *)(iVar4 + 0x28) <= *(uint64_t *)(iVar4 + 0x30)) {
        (**(code **)0x180782658)(iVar3, CONCAT71((unkint7)((uint64_t)iVar4 >> 8), 1));
    }
    iVar4 = *(int64_t *)(iVar3 + 0x40);
    if (*(int64_t *)arg1 == *(int64_t *)(arg1 + 8)) {
        uVar7 = func_0x00018009a7e0(iVar3, iVar2);
        *(undefined8 *)(iVar4 + -0x10) = uVar7;
        *(undefined4 *)(iVar4 + -4) = 6;
        return;
    }
    uVar7 = func_0x00018009a8e0(iVar3, iVar2 + 0x18, (*(int64_t *)arg1 - iVar2) + -0x18);
    *(undefined8 *)(iVar4 + -0x10) = uVar7;
    *(undefined4 *)(iVar4 + -4) = 6;
    return;
}

// ============================================================
// Function: FUN_1800893a0
// Address: 0x1800893a0
// Size: 1140 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.1800893a0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int32_t iVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int64_t iVar12;
    undefined8 uVar13;
    int64_t iVar14;
    int64_t iVar15;
    undefined4 *puVar16;
    uint32_t uVar17;
    int64_t *piVar19;
    int64_t in_R9;
    undefined4 *puVar20;
    undefined auStack_128 [32];
    int64_t var_108h;
    int64_t var_d8h;
    int64_t var_48h;
    int64_t var_38h;
    uint64_t uVar18;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_128;
    iVar9 = (int32_t)arg2;
    uVar18 = arg2 & 0xffffffff;
    if (iVar9 + 9999U < 10000) {
        uVar18 = (uint64_t)(uint32_t)((int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4) + 1 + iVar9)
        ;
    }
    iVar8 = func_0x000180087120(arg1, uVar18);
    if (iVar8 == 0) {
        puVar16 = *(undefined4 **)(arg1 + 0x40);
        puVar20 = *(undefined4 **)0x180782430;
    } else {
        func_0x0001800867f0(arg1, 0x180622440, 10);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar12 = *(int64_t *)(arg1 + 0x40);
        puVar10 = (undefined4 *)func_0x0001800a0ea0(*(undefined8 *)(iVar12 + -0x20), (undefined4 *)(iVar12 + -0x10));
        puVar20 = *(undefined4 **)0x180782430;
        uVar5 = puVar10[1];
        uVar6 = puVar10[2];
        uVar7 = puVar10[3];
        *(undefined4 *)(iVar12 + -0x10) = *puVar10;
        *(undefined4 *)(iVar12 + -0xc) = uVar5;
        *(undefined4 *)(iVar12 + -8) = uVar6;
        *(undefined4 *)(iVar12 + -4) = uVar7;
        puVar16 = *(undefined4 **)(arg1 + 0x40);
        puVar10 = puVar16 + -4;
        if ((puVar10 == puVar20) || (puVar16[-1] != 0)) {
            if (puVar10 < puVar16) {
                do {
                    puVar10[-4] = *puVar10;
                    puVar10[-3] = puVar10[1];
                    puVar10[-2] = puVar10[2];
                    puVar10[-1] = puVar10[3];
                    puVar16 = *(undefined4 **)(arg1 + 0x40);
                    puVar10 = puVar10 + 4;
                } while (puVar10 < puVar16);
            }
            *(undefined4 **)(arg1 + 0x40) = puVar16 + -4;
            func_0x000180085bf0(arg1, uVar18);
            func_0x000180087810(arg1, 1);
            piVar19 = (int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10);
            if (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 6) {
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                iVar9 = func_0x0001800a8360(arg1, piVar19);
                if (iVar9 == 0) {
                    if (arg3 != 0) {
                        *(undefined8 *)arg3 = 0;
                    }
                    goto code_r0x0001800897e7;
                }
                if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30))
                {
                    (**(code **)0x180782658)(arg1, 1);
                }
                piVar19 = (int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10);
            }
            if (arg3 != 0) {
                *(uint64_t *)arg3 = (uint64_t)*(uint32_t *)(*piVar19 + 0x14);
            }
            if (*piVar19 == -0x18) {
code_r0x0001800897e7:
                fcn.180088560(arg1, 0x18063da98, (int64_t)piVar19, in_R9);
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            goto code_r0x0001800896fc;
        }
        puVar16 = puVar16 + -8;
        *(undefined4 **)(arg1 + 0x40) = puVar16;
    }
    if (iVar9 < 1) {
        if (iVar9 < -9999) {
            puVar10 = (undefined4 *)fcn.180085370(arg1, arg2 & 0xffffffff);
        } else {
            puVar10 = puVar16 + (int64_t)iVar9 * 4;
        }
    } else {
        puVar10 = (undefined4 *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar9 * 0x10);
        if (puVar16 <= puVar10) {
            puVar10 = puVar20;
        }
    }
    uVar18 = 0;
    if (puVar10 == puVar20) {
code_r0x000180089614:
        iVar14 = func_0x0001800864a0(arg1, arg2 & 0xffffffff);
        iVar12 = *(int64_t *)(arg1 + 0x20);
        iVar1 = *(int64_t *)(iVar12 + 0x4e8);
        iVar2 = *(int64_t *)(iVar12 + 0x4e0);
        iVar3 = *(int64_t *)(iVar12 + 0x4f8);
        iVar12 = *(int64_t *)(iVar12 + 0x4f0);
        iVar15 = fcn.180085430(arg1, arg2 & 0xffffffff);
        if (iVar15 == 0) {
            iVar15 = 0x18063d8c0;
        } else {
            iVar15 = fcn.1800a3b90(arg1, iVar15);
            iVar15 = iVar15 + 0x18;
        }
        func_0x000180086980(arg1, 0x18063da88, iVar15, iVar14 * iVar1 + iVar3 ^ iVar14 * iVar2 + iVar12);
    } else {
    // switch table (7 cases) at 0x1800897f8
        switch(puVar10[3]) {
        case 0:
            func_0x0001800867f0(arg1, 0x18063da4c, 3);
            break;
        case 1:
            iVar9 = func_0x000180085ff0(arg1, arg2 & 0xffffffff);
            uVar13 = 0x1805ab28c;
            if (iVar9 != 0) {
                uVar13 = 0x1805ab294;
            }
            uVar11 = func_0x000180498cd0(uVar13);
            func_0x0001800867f0(arg1, uVar13, uVar11);
            break;
        default:
            goto code_r0x000180089614;
        case 3:
            uVar13 = func_0x000180085ea0(arg1, arg2 & 0xffffffff, 0);
            iVar12 = func_0x000180098ac0(&var_108h, uVar13);
            func_0x0001800867f0(arg1, &var_108h, iVar12 - (int64_t)&var_108h);
            break;
        case 4:
            uVar13 = func_0x000180086060(arg1, arg2 & 0xffffffff);
            iVar12 = func_0x000180099080(&var_108h, uVar13);
            func_0x0001800867f0(arg1, &var_108h, iVar12 - (int64_t)&var_108h);
            break;
        case 5:
            iVar12 = func_0x000180086200(arg1, arg2 & 0xffffffff);
            piVar19 = &var_d8h;
            do {
                if ((int32_t)uVar18 != 0) {
                    *(undefined2 *)piVar19 = 0x202c;
                    piVar19 = (int64_t *)((int64_t)piVar19 + 2);
                }
                piVar19 = (int64_t *)func_0x000180098ac0(piVar19, (double)*(float *)(iVar12 + uVar18 * 4));
                uVar17 = (int32_t)uVar18 + 1;
                uVar18 = (uint64_t)uVar17;
            } while ((int32_t)uVar17 < 3);
            func_0x0001800867f0(arg1, &var_d8h, (int64_t)piVar19 - (int64_t)&var_d8h);
            break;
        case 6:
            func_0x000180085bf0(arg1, arg2 & 0xffffffff);
        }
    }
    iVar12 = *(int64_t *)(arg1 + 0x40);
    if (*(int32_t *)(iVar12 + -4) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar9 = func_0x0001800a8360(arg1);
        if (iVar9 == 0) {
            if (arg3 != 0) {
                *(undefined8 *)arg3 = 0;
            }
            goto code_r0x0001800896fc;
        }
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        iVar12 = *(int64_t *)(arg1 + 0x40);
    }
    if (arg3 != 0) {
        *(uint64_t *)arg3 = (uint64_t)*(uint32_t *)(*(int64_t *)(iVar12 + -0x10) + 0x14);
    }
code_r0x0001800896fc:
    func_0x000180459870(var_48h ^ (uint64_t)auStack_128);
    return;
}

// ============================================================
// Function: FUN_180089820
// Address: 0x180089820
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180089820(int64_t arg1, int64_t arg_40h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    uint32_t uVar3;
    uint64_t arg2;
    int32_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    arg2 = 1;
    iVar4 = (int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4);
    if (0 < iVar4) {
        do {
            uVar1 = fcn.1800893a0(arg1, arg2, (int64_t)&var_8h);
            if (1 < (int32_t)arg2) {
                uVar2 = func_0x0001804605f8(1);
                func_0x000180460a38(0x18063dad4, 1, 1, uVar2);
            }
            uVar2 = func_0x0001804605f8(1);
            func_0x000180460a38(uVar1, 1, var_8h, uVar2);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            uVar3 = (int32_t)arg2 + 1;
            arg2 = (uint64_t)uVar3;
        } while ((int32_t)uVar3 <= iVar4);
    }
    uVar1 = func_0x0001804605f8(1);
    func_0x000180460a38(0x1805ab2a0, 1, 1, uVar1);
    return 0;
}

// ============================================================
// Function: FUN_180089847
// Address: 0x180089847
// Size: 112 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180089820(int64_t arg1, int64_t arg_40h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    uint32_t uVar3;
    uint64_t arg2;
    int32_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    arg2 = 1;
    iVar4 = (int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4);
    if (0 < iVar4) {
        do {
            uVar1 = fcn.1800893a0(arg1, arg2, (int64_t)&var_8h);
            if (1 < (int32_t)arg2) {
                uVar2 = func_0x0001804605f8(1);
                func_0x000180460a38(0x18063dad4, 1, 1, uVar2);
            }
            uVar2 = func_0x0001804605f8(1);
            func_0x000180460a38(uVar1, 1, var_8h, uVar2);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            uVar3 = (int32_t)arg2 + 1;
            arg2 = (uint64_t)uVar3;
        } while ((int32_t)uVar3 <= iVar4);
    }
    uVar1 = func_0x0001804605f8(1);
    func_0x000180460a38(0x1805ab2a0, 1, 1, uVar1);
    return 0;
}

// ============================================================
// Function: FUN_1800898b7
// Address: 0x1800898b7
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180089820(int64_t arg1, int64_t arg_40h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    uint32_t uVar3;
    uint64_t arg2;
    int32_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    arg2 = 1;
    iVar4 = (int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4);
    if (0 < iVar4) {
        do {
            uVar1 = fcn.1800893a0(arg1, arg2, (int64_t)&var_8h);
            if (1 < (int32_t)arg2) {
                uVar2 = func_0x0001804605f8(1);
                func_0x000180460a38(0x18063dad4, 1, 1, uVar2);
            }
            uVar2 = func_0x0001804605f8(1);
            func_0x000180460a38(uVar1, 1, var_8h, uVar2);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            uVar3 = (int32_t)arg2 + 1;
            arg2 = (uint64_t)uVar3;
        } while ((int32_t)uVar3 <= iVar4);
    }
    uVar1 = func_0x0001804605f8(1);
    func_0x000180460a38(0x1805ab2a0, 1, 1, uVar1);
    return 0;
}

// ============================================================
// Function: FUN_1800898f0
// Address: 0x1800898f0
// Size: 518 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800898f0(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    uint64_t uVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t in_R9;
    double dVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) < 1)) ||
       (iVar2 = fcn.180088860(arg1, 2), iVar2 == 10)) {
        var_8h = var_8h & 0xffffffff00000000;
        dVar8 = (double)func_0x000180085ea0(arg1, 1, &var_8h);
        if ((int32_t)var_8h != 0) {
code_r0x000180089a34:
            func_0x000180086570(arg1, dVar8);
            return 1;
        }
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) == -1)) {
            fcn.180088560(arg1, 0x18063da20, 1, in_R9);
            pcVar1 = (code *)swi(3);
            uVar5 = (*pcVar1)();
            return uVar5;
        }
    } else {
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar3 = func_0x0001800a8360(arg1);
            if (iVar3 == 0) goto code_r0x000180089acd;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar6 = *(int64_t **)(arg1 + 0x28);
            if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
                piVar6 = *(int64_t **)0x180782430;
            }
        }
        iVar7 = *piVar6 + 0x18;
        if (iVar7 == 0) {
code_r0x000180089acd:
            func_0x000180088470(arg1, 1, 6);
            pcVar1 = (code *)swi(3);
            uVar5 = (*pcVar1)();
            return uVar5;
        }
        if (0x22 < iVar2 - 2U) {
            func_0x000180088380(arg1, 2, 0x18063dac0);
            pcVar1 = (code *)swi(3);
            uVar5 = (*pcVar1)();
            return uVar5;
        }
        uVar4 = func_0x00018046c748(iVar7, &var_8h, iVar2);
        if (iVar7 != var_8h) {
            iVar2 = func_0x00018046ce40(*(undefined *)var_8h);
            while (iVar2 != 0) {
                var_8h = var_8h + 1;
                iVar2 = func_0x00018046ce40(*(char *)var_8h);
            }
            if (*(char *)var_8h == '\0') {
                if ((int64_t)uVar4 < 0) {
                    dVar8 = (double)(uVar4 >> 1 | (uint64_t)((uint32_t)uVar4 & 1));
                    dVar8 = dVar8 + dVar8;
                } else {
                    dVar8 = (double)uVar4;
                }
                goto code_r0x000180089a34;
            }
        }
    }
    fcn.180086510(arg1);
    return 1;
}

// ============================================================
// Function: FUN_180089b00
// Address: 0x180089b00
// Size: 105 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

void fcn.180089b00(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t unaff_RDI;
    int64_t var_8h;
    int64_t in_stack_00000010;
    int64_t in_stack_00000018;
    
    iVar2 = fcn.1800889f0(arg1, 2, 1);
    fcn.1800858c0(arg1, 1);
    iVar3 = fcn.180085dd0(arg1, 1);
    if ((iVar3 != 0) && (0 < iVar2)) {
        fcn.1800884a0(arg1, iVar2);
        fcn.180085bf0(arg1, 1);
        fcn.180087c00(unaff_RDI, in_stack_00000010, in_stack_00000018);
    }
    fcn.180087960(arg1);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180089b70
// Address: 0x180089b70
// Size: 104 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180089b70(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    undefined4 *puVar7;
    undefined8 uVar8;
    undefined4 *puVar9;
    int64_t var_8h;
    
    puVar7 = *(undefined4 **)(arg1 + 0x28);
    if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
        puVar7 = *(undefined4 **)0x180782430;
    }
    if ((puVar7 == *(undefined4 **)0x180782430) || (puVar7[3] == -1)) {
        fcn.180088560(arg1, 0x18063da20, 1, arg4);
        pcVar2 = (code *)swi(3);
        uVar8 = (*pcVar2)();
        return uVar8;
    }
    iVar6 = fcn.180087120(arg1, 1);
    if (iVar6 == 0) {
        fcn.180086510();
    } else {
        iVar6 = fcn.180087120(arg1, 1);
        if (iVar6 != 0) {
            fcn.1800867f0(arg1, 0x1806224a0, 0xb);
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar1 = *(int64_t *)(arg1 + 0x40);
            puVar7 = (undefined4 *)fcn.1800a0ea0(*(undefined8 *)(iVar1 + -0x20), (undefined4 *)(iVar1 + -0x10));
            uVar3 = puVar7[1];
            uVar4 = puVar7[2];
            uVar5 = puVar7[3];
            *(undefined4 *)(iVar1 + -0x10) = *puVar7;
            *(undefined4 *)(iVar1 + -0xc) = uVar3;
            *(undefined4 *)(iVar1 + -8) = uVar4;
            *(undefined4 *)(iVar1 + -4) = uVar5;
            puVar9 = *(undefined4 **)(arg1 + 0x40);
            puVar7 = puVar9 + -4;
            if ((puVar7 != *(undefined4 **)0x180782430) && (puVar9[-1] == 0)) {
                *(undefined4 **)(arg1 + 0x40) = puVar9 + -8;
                return 1;
            }
            if (puVar7 < puVar9) {
                do {
                    puVar7[-4] = *puVar7;
                    puVar7[-3] = puVar7[1];
                    puVar7[-2] = puVar7[2];
                    puVar7[-1] = puVar7[3];
                    puVar9 = *(undefined4 **)(arg1 + 0x40);
                    puVar7 = puVar7 + 4;
                } while (puVar7 < puVar9);
            }
            *(undefined4 **)(arg1 + 0x40) = puVar9 + -4;
            return 1;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_180089bd8
// Address: 0x180089bd8
// Size: 97 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180089b70(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    undefined4 *puVar7;
    undefined8 uVar8;
    undefined4 *puVar9;
    int64_t var_8h;
    
    puVar7 = *(undefined4 **)(arg1 + 0x28);
    if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
        puVar7 = *(undefined4 **)0x180782430;
    }
    if ((puVar7 == *(undefined4 **)0x180782430) || (puVar7[3] == -1)) {
        fcn.180088560(arg1, 0x18063da20, 1, arg4);
        pcVar2 = (code *)swi(3);
        uVar8 = (*pcVar2)();
        return uVar8;
    }
    iVar6 = fcn.180087120(arg1, 1);
    if (iVar6 == 0) {
        fcn.180086510();
    } else {
        iVar6 = fcn.180087120(arg1, 1);
        if (iVar6 != 0) {
            fcn.1800867f0(arg1, 0x1806224a0, 0xb);
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar1 = *(int64_t *)(arg1 + 0x40);
            puVar7 = (undefined4 *)fcn.1800a0ea0(*(undefined8 *)(iVar1 + -0x20), (undefined4 *)(iVar1 + -0x10));
            uVar3 = puVar7[1];
            uVar4 = puVar7[2];
            uVar5 = puVar7[3];
            *(undefined4 *)(iVar1 + -0x10) = *puVar7;
            *(undefined4 *)(iVar1 + -0xc) = uVar3;
            *(undefined4 *)(iVar1 + -8) = uVar4;
            *(undefined4 *)(iVar1 + -4) = uVar5;
            puVar9 = *(undefined4 **)(arg1 + 0x40);
            puVar7 = puVar9 + -4;
            if ((puVar7 != *(undefined4 **)0x180782430) && (puVar9[-1] == 0)) {
                *(undefined4 **)(arg1 + 0x40) = puVar9 + -8;
                return 1;
            }
            if (puVar7 < puVar9) {
                do {
                    puVar7[-4] = *puVar7;
                    puVar7[-3] = puVar7[1];
                    puVar7[-2] = puVar7[2];
                    puVar7[-1] = puVar7[3];
                    puVar9 = *(undefined4 **)(arg1 + 0x40);
                    puVar7 = puVar7 + 4;
                } while (puVar7 < puVar9);
            }
            *(undefined4 **)(arg1 + 0x40) = puVar9 + -4;
            return 1;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_180089c39
// Address: 0x180089c39
// Size: 100 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180089b70(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    undefined4 *puVar7;
    undefined8 uVar8;
    undefined4 *puVar9;
    int64_t var_8h;
    
    puVar7 = *(undefined4 **)(arg1 + 0x28);
    if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
        puVar7 = *(undefined4 **)0x180782430;
    }
    if ((puVar7 == *(undefined4 **)0x180782430) || (puVar7[3] == -1)) {
        fcn.180088560(arg1, 0x18063da20, 1, arg4);
        pcVar2 = (code *)swi(3);
        uVar8 = (*pcVar2)();
        return uVar8;
    }
    iVar6 = fcn.180087120(arg1, 1);
    if (iVar6 == 0) {
        fcn.180086510();
    } else {
        iVar6 = fcn.180087120(arg1, 1);
        if (iVar6 != 0) {
            fcn.1800867f0(arg1, 0x1806224a0, 0xb);
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar1 = *(int64_t *)(arg1 + 0x40);
            puVar7 = (undefined4 *)fcn.1800a0ea0(*(undefined8 *)(iVar1 + -0x20), (undefined4 *)(iVar1 + -0x10));
            uVar3 = puVar7[1];
            uVar4 = puVar7[2];
            uVar5 = puVar7[3];
            *(undefined4 *)(iVar1 + -0x10) = *puVar7;
            *(undefined4 *)(iVar1 + -0xc) = uVar3;
            *(undefined4 *)(iVar1 + -8) = uVar4;
            *(undefined4 *)(iVar1 + -4) = uVar5;
            puVar9 = *(undefined4 **)(arg1 + 0x40);
            puVar7 = puVar9 + -4;
            if ((puVar7 != *(undefined4 **)0x180782430) && (puVar9[-1] == 0)) {
                *(undefined4 **)(arg1 + 0x40) = puVar9 + -8;
                return 1;
            }
            if (puVar7 < puVar9) {
                do {
                    puVar7[-4] = *puVar7;
                    puVar7[-3] = puVar7[1];
                    puVar7[-2] = puVar7[2];
                    puVar7[-1] = puVar7[3];
                    puVar9 = *(undefined4 **)(arg1 + 0x40);
                    puVar7 = puVar7 + 4;
                } while (puVar7 < puVar9);
            }
            *(undefined4 **)(arg1 + 0x40) = puVar9 + -4;
            return 1;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_180089ca0
// Address: 0x180089ca0
// Size: 112 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180089ca0(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    undefined4 *puVar7;
    undefined8 uVar8;
    undefined4 *puVar9;
    int64_t arg3;
    int64_t in_R9;
    int64_t var_8h;
    
    puVar7 = *(undefined4 **)(arg1 + 0x28);
    puVar9 = puVar7 + 4;
    if (*(undefined4 **)(arg1 + 0x40) <= puVar7 + 4) {
        puVar9 = *(undefined4 **)0x180782430;
    }
    if (puVar9 == *(undefined4 **)0x180782430) {
        iVar6 = -1;
    } else {
        iVar6 = puVar9[3];
    }
    if (*(undefined4 **)(arg1 + 0x40) <= puVar7) {
        puVar7 = *(undefined4 **)0x180782430;
    }
    if ((puVar7 != *(undefined4 **)0x180782430) && (puVar7[3] == 7)) {
        if ((iVar6 != 0) && (iVar6 != 7)) {
            func_0x0001800883d0(arg1, 2, 0x18063db30);
            pcVar2 = (code *)swi(3);
            uVar8 = (*pcVar2)();
            return uVar8;
        }
        iVar6 = fcn.180087120(arg1, 1);
        if (iVar6 != 0) {
            arg3 = 0xb;
            fcn.1800867f0(arg1, 0x1806224a0);
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar1 = *(int64_t *)(arg1 + 0x40);
            puVar7 = (undefined4 *)fcn.1800a0ea0(*(undefined8 *)(iVar1 + -0x20), (undefined4 *)(iVar1 + -0x10));
            uVar3 = puVar7[1];
            uVar4 = puVar7[2];
            uVar5 = puVar7[3];
            *(undefined4 *)(iVar1 + -0x10) = *puVar7;
            *(undefined4 *)(iVar1 + -0xc) = uVar3;
            *(undefined4 *)(iVar1 + -8) = uVar4;
            *(undefined4 *)(iVar1 + -4) = uVar5;
            puVar9 = *(undefined4 **)(arg1 + 0x40);
            puVar7 = puVar9 + -4;
            if ((puVar7 == *(undefined4 **)0x180782430) || (puVar9[-1] != 0)) {
                if (puVar7 < puVar9) {
                    do {
                        puVar7[-4] = *puVar7;
                        puVar7[-3] = puVar7[1];
                        puVar7[-2] = puVar7[2];
                        puVar7[-1] = puVar7[3];
                        puVar9 = *(undefined4 **)(arg1 + 0x40);
                        puVar7 = puVar7 + 4;
                    } while (puVar7 < puVar9);
                }
                *(undefined4 **)(arg1 + 0x40) = puVar9 + -4;
                fcn.180088560(arg1, 0x18063db08, arg3, in_R9);
                pcVar2 = (code *)swi(3);
                uVar8 = (*pcVar2)();
                return uVar8;
            }
            *(undefined4 **)(arg1 + 0x40) = puVar9 + -8;
        }
        fcn.1800858c0(arg1, 2);
        func_0x000180087650(arg1, 1);
        return 1;
    }
    func_0x000180088470(arg1, 1, 7);
    pcVar2 = (code *)swi(3);
    uVar8 = (*pcVar2)();
    return uVar8;
}

// ============================================================
// Function: FUN_180089d10
// Address: 0x180089d10
// Size: 97 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180089ca0(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    undefined4 *puVar7;
    undefined8 uVar8;
    undefined4 *puVar9;
    int64_t arg3;
    int64_t in_R9;
    int64_t var_8h;
    
    puVar7 = *(undefined4 **)(arg1 + 0x28);
    puVar9 = puVar7 + 4;
    if (*(undefined4 **)(arg1 + 0x40) <= puVar7 + 4) {
        puVar9 = *(undefined4 **)0x180782430;
    }
    if (puVar9 == *(undefined4 **)0x180782430) {
        iVar6 = -1;
    } else {
        iVar6 = puVar9[3];
    }
    if (*(undefined4 **)(arg1 + 0x40) <= puVar7) {
        puVar7 = *(undefined4 **)0x180782430;
    }
    if ((puVar7 != *(undefined4 **)0x180782430) && (puVar7[3] == 7)) {
        if ((iVar6 != 0) && (iVar6 != 7)) {
            func_0x0001800883d0(arg1, 2, 0x18063db30);
            pcVar2 = (code *)swi(3);
            uVar8 = (*pcVar2)();
            return uVar8;
        }
        iVar6 = fcn.180087120(arg1, 1);
        if (iVar6 != 0) {
            arg3 = 0xb;
            fcn.1800867f0(arg1, 0x1806224a0);
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar1 = *(int64_t *)(arg1 + 0x40);
            puVar7 = (undefined4 *)fcn.1800a0ea0(*(undefined8 *)(iVar1 + -0x20), (undefined4 *)(iVar1 + -0x10));
            uVar3 = puVar7[1];
            uVar4 = puVar7[2];
            uVar5 = puVar7[3];
            *(undefined4 *)(iVar1 + -0x10) = *puVar7;
            *(undefined4 *)(iVar1 + -0xc) = uVar3;
            *(undefined4 *)(iVar1 + -8) = uVar4;
            *(undefined4 *)(iVar1 + -4) = uVar5;
            puVar9 = *(undefined4 **)(arg1 + 0x40);
            puVar7 = puVar9 + -4;
            if ((puVar7 == *(undefined4 **)0x180782430) || (puVar9[-1] != 0)) {
                if (puVar7 < puVar9) {
                    do {
                        puVar7[-4] = *puVar7;
                        puVar7[-3] = puVar7[1];
                        puVar7[-2] = puVar7[2];
                        puVar7[-1] = puVar7[3];
                        puVar9 = *(undefined4 **)(arg1 + 0x40);
                        puVar7 = puVar7 + 4;
                    } while (puVar7 < puVar9);
                }
                *(undefined4 **)(arg1 + 0x40) = puVar9 + -4;
                fcn.180088560(arg1, 0x18063db08, arg3, in_R9);
                pcVar2 = (code *)swi(3);
                uVar8 = (*pcVar2)();
                return uVar8;
            }
            *(undefined4 **)(arg1 + 0x40) = puVar9 + -8;
        }
        fcn.1800858c0(arg1, 2);
        func_0x000180087650(arg1, 1);
        return 1;
    }
    func_0x000180088470(arg1, 1, 7);
    pcVar2 = (code *)swi(3);
    uVar8 = (*pcVar2)();
    return uVar8;
}

// ============================================================
// Function: FUN_180089d71
// Address: 0x180089d71
// Size: 150 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180089ca0(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    undefined4 *puVar7;
    undefined8 uVar8;
    undefined4 *puVar9;
    int64_t arg3;
    int64_t in_R9;
    int64_t var_8h;
    
    puVar7 = *(undefined4 **)(arg1 + 0x28);
    puVar9 = puVar7 + 4;
    if (*(undefined4 **)(arg1 + 0x40) <= puVar7 + 4) {
        puVar9 = *(undefined4 **)0x180782430;
    }
    if (puVar9 == *(undefined4 **)0x180782430) {
        iVar6 = -1;
    } else {
        iVar6 = puVar9[3];
    }
    if (*(undefined4 **)(arg1 + 0x40) <= puVar7) {
        puVar7 = *(undefined4 **)0x180782430;
    }
    if ((puVar7 != *(undefined4 **)0x180782430) && (puVar7[3] == 7)) {
        if ((iVar6 != 0) && (iVar6 != 7)) {
            func_0x0001800883d0(arg1, 2, 0x18063db30);
            pcVar2 = (code *)swi(3);
            uVar8 = (*pcVar2)();
            return uVar8;
        }
        iVar6 = fcn.180087120(arg1, 1);
        if (iVar6 != 0) {
            arg3 = 0xb;
            fcn.1800867f0(arg1, 0x1806224a0);
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar1 = *(int64_t *)(arg1 + 0x40);
            puVar7 = (undefined4 *)fcn.1800a0ea0(*(undefined8 *)(iVar1 + -0x20), (undefined4 *)(iVar1 + -0x10));
            uVar3 = puVar7[1];
            uVar4 = puVar7[2];
            uVar5 = puVar7[3];
            *(undefined4 *)(iVar1 + -0x10) = *puVar7;
            *(undefined4 *)(iVar1 + -0xc) = uVar3;
            *(undefined4 *)(iVar1 + -8) = uVar4;
            *(undefined4 *)(iVar1 + -4) = uVar5;
            puVar9 = *(undefined4 **)(arg1 + 0x40);
            puVar7 = puVar9 + -4;
            if ((puVar7 == *(undefined4 **)0x180782430) || (puVar9[-1] != 0)) {
                if (puVar7 < puVar9) {
                    do {
                        puVar7[-4] = *puVar7;
                        puVar7[-3] = puVar7[1];
                        puVar7[-2] = puVar7[2];
                        puVar7[-1] = puVar7[3];
                        puVar9 = *(undefined4 **)(arg1 + 0x40);
                        puVar7 = puVar7 + 4;
                    } while (puVar7 < puVar9);
                }
                *(undefined4 **)(arg1 + 0x40) = puVar9 + -4;
                fcn.180088560(arg1, 0x18063db08, arg3, in_R9);
                pcVar2 = (code *)swi(3);
                uVar8 = (*pcVar2)();
                return uVar8;
            }
            *(undefined4 **)(arg1 + 0x40) = puVar9 + -8;
        }
        fcn.1800858c0(arg1, 2);
        func_0x000180087650(arg1, 1);
        return 1;
    }
    func_0x000180088470(arg1, 1, 7);
    pcVar2 = (code *)swi(3);
    uVar8 = (*pcVar2)();
    return uVar8;
}

// ============================================================
// Function: FUN_180089e10
// Address: 0x180089e10
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180089e10(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    uint32_t uVar2;
    int32_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t *arg4;
    int64_t var_10h;
    undefined auStack_178 [32];
    int64_t var_158h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_178;
    uVar4 = *(uint64_t *)(arg1 + 0x28);
    uVar5 = uVar4;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar4) {
        uVar5 = *(uint64_t *)0x180782430;
    }
    if ((uVar5 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar5 + 0xc) == 8)) {
        fcn.180085bf0(arg1, 1);
        goto code_r0x000180089ed3;
    }
    if ((int32_t)arg2 == 0) {
code_r0x000180089e87:
        uVar2 = fcn.180088860(arg1, 1);
    } else {
        if (*(uint64_t *)(arg1 + 0x40) <= uVar4) {
            uVar4 = *(uint64_t *)0x180782430;
        }
        if ((uVar4 != *(uint64_t *)0x180782430) && (0 < *(int32_t *)(uVar4 + 0xc))) goto code_r0x000180089e87;
        uVar2 = 1;
    }
    if ((int32_t)uVar2 < 0) {
        func_0x000180088380(arg1, 1, 0x18063dae8);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    arg4 = &var_158h;
    iVar3 = func_0x000180092a10(arg1, uVar2, 0x180621b1c);
    if (iVar3 == 0) {
        func_0x000180088380(arg1, 1, 0x18063dad8);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    if ((*(int64_t *)(arg1 + 0x40) - 0x10U != *(uint64_t *)0x180782430) &&
       (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 0)) {
        fcn.180088560(arg1, 0x18063dbb0, (uint64_t)uVar2, (int64_t)arg4);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
code_r0x000180089ed3:
    func_0x000180459870(var_18h ^ (uint64_t)auStack_178);
    return;
}

// ============================================================
// Function: FUN_180089e62
// Address: 0x180089e62
// Size: 113 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180089e10(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    uint32_t uVar2;
    int32_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t *arg4;
    int64_t var_10h;
    undefined auStack_178 [32];
    int64_t var_158h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_178;
    uVar4 = *(uint64_t *)(arg1 + 0x28);
    uVar5 = uVar4;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar4) {
        uVar5 = *(uint64_t *)0x180782430;
    }
    if ((uVar5 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar5 + 0xc) == 8)) {
        fcn.180085bf0(arg1, 1);
        goto code_r0x000180089ed3;
    }
    if ((int32_t)arg2 == 0) {
code_r0x000180089e87:
        uVar2 = fcn.180088860(arg1, 1);
    } else {
        if (*(uint64_t *)(arg1 + 0x40) <= uVar4) {
            uVar4 = *(uint64_t *)0x180782430;
        }
        if ((uVar4 != *(uint64_t *)0x180782430) && (0 < *(int32_t *)(uVar4 + 0xc))) goto code_r0x000180089e87;
        uVar2 = 1;
    }
    if ((int32_t)uVar2 < 0) {
        func_0x000180088380(arg1, 1, 0x18063dae8);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    arg4 = &var_158h;
    iVar3 = func_0x000180092a10(arg1, uVar2, 0x180621b1c);
    if (iVar3 == 0) {
        func_0x000180088380(arg1, 1, 0x18063dad8);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    if ((*(int64_t *)(arg1 + 0x40) - 0x10U != *(uint64_t *)0x180782430) &&
       (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 0)) {
        fcn.180088560(arg1, 0x18063dbb0, (uint64_t)uVar2, (int64_t)arg4);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
code_r0x000180089ed3:
    func_0x000180459870(var_18h ^ (uint64_t)auStack_178);
    return;
}

// ============================================================
// Function: FUN_180089ed3
// Address: 0x180089ed3
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180089e10(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    uint32_t uVar2;
    int32_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t *arg4;
    int64_t var_10h;
    undefined auStack_178 [32];
    int64_t var_158h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_178;
    uVar4 = *(uint64_t *)(arg1 + 0x28);
    uVar5 = uVar4;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar4) {
        uVar5 = *(uint64_t *)0x180782430;
    }
    if ((uVar5 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar5 + 0xc) == 8)) {
        fcn.180085bf0(arg1, 1);
        goto code_r0x000180089ed3;
    }
    if ((int32_t)arg2 == 0) {
code_r0x000180089e87:
        uVar2 = fcn.180088860(arg1, 1);
    } else {
        if (*(uint64_t *)(arg1 + 0x40) <= uVar4) {
            uVar4 = *(uint64_t *)0x180782430;
        }
        if ((uVar4 != *(uint64_t *)0x180782430) && (0 < *(int32_t *)(uVar4 + 0xc))) goto code_r0x000180089e87;
        uVar2 = 1;
    }
    if ((int32_t)uVar2 < 0) {
        func_0x000180088380(arg1, 1, 0x18063dae8);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    arg4 = &var_158h;
    iVar3 = func_0x000180092a10(arg1, uVar2, 0x180621b1c);
    if (iVar3 == 0) {
        func_0x000180088380(arg1, 1, 0x18063dad8);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    if ((*(int64_t *)(arg1 + 0x40) - 0x10U != *(uint64_t *)0x180782430) &&
       (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 0)) {
        fcn.180088560(arg1, 0x18063dbb0, (uint64_t)uVar2, (int64_t)arg4);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
code_r0x000180089ed3:
    func_0x000180459870(var_18h ^ (uint64_t)auStack_178);
    return;
}

// ============================================================
// Function: FUN_180089eec
// Address: 0x180089eec
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180089e10(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    uint32_t uVar2;
    int32_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t *arg4;
    int64_t var_10h;
    undefined auStack_178 [32];
    int64_t var_158h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_178;
    uVar4 = *(uint64_t *)(arg1 + 0x28);
    uVar5 = uVar4;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar4) {
        uVar5 = *(uint64_t *)0x180782430;
    }
    if ((uVar5 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar5 + 0xc) == 8)) {
        fcn.180085bf0(arg1, 1);
        goto code_r0x000180089ed3;
    }
    if ((int32_t)arg2 == 0) {
code_r0x000180089e87:
        uVar2 = fcn.180088860(arg1, 1);
    } else {
        if (*(uint64_t *)(arg1 + 0x40) <= uVar4) {
            uVar4 = *(uint64_t *)0x180782430;
        }
        if ((uVar4 != *(uint64_t *)0x180782430) && (0 < *(int32_t *)(uVar4 + 0xc))) goto code_r0x000180089e87;
        uVar2 = 1;
    }
    if ((int32_t)uVar2 < 0) {
        func_0x000180088380(arg1, 1, 0x18063dae8);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    arg4 = &var_158h;
    iVar3 = func_0x000180092a10(arg1, uVar2, 0x180621b1c);
    if (iVar3 == 0) {
        func_0x000180088380(arg1, 1, 0x18063dad8);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    if ((*(int64_t *)(arg1 + 0x40) - 0x10U != *(uint64_t *)0x180782430) &&
       (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 0)) {
        fcn.180088560(arg1, 0x18063dbb0, (uint64_t)uVar2, (int64_t)arg4);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
code_r0x000180089ed3:
    func_0x000180459870(var_18h ^ (uint64_t)auStack_178);
    return;
}

// ============================================================
// Function: FUN_180089f30
// Address: 0x180089f30
// Size: 201 bytes
// ============================================================
undefined8 fcn.180089f30(int64_t arg1)
{
    undefined4 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    undefined4 *puVar7;
    undefined8 uVar8;
    int64_t in_stack_00000010;
    
    fcn.180089e10(arg1, 1);
    if ((*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 8) &&
       (*(char *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 3) != '\0')) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
            iVar6 = fcn.180085510(in_stack_00000010);
            if (iVar6 == 0) {
                fcn.180099450(arg1, 0x18063d8d0);
                fcn.180087960(arg1);
                pcVar2 = (code *)swi(3);
                uVar8 = (*pcVar2)();
                return uVar8;
            }
        }
        puVar7 = (undefined4 *)fcn.180085370(arg1, 0xffffd8ee);
        puVar1 = *(undefined4 **)(arg1 + 0x40);
        uVar3 = puVar7[1];
        uVar4 = puVar7[2];
        uVar5 = puVar7[3];
        *puVar1 = *puVar7;
        puVar1[1] = uVar3;
        puVar1[2] = uVar4;
        puVar1[3] = uVar5;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    } else {
        func_0x000180087250(arg1, 0xffffffff);
    }
    *(undefined *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 6) = 0;
    return 1;
}

// ============================================================
// Function: FUN_18008a000
// Address: 0x18008a000
// Size: 316 bytes
// ============================================================
undefined8 fcn.18008a000(int64_t arg1)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    code *pcVar3;
    double dVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 uVar9;
    uint64_t uVar10;
    int64_t in_R8;
    int64_t in_R9;
    
    uVar10 = *(int64_t *)(arg1 + 0x28) + 0x10;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar10) {
        uVar10 = *(uint64_t *)0x180782430;
    }
    if ((uVar10 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar10 + 0xc) != 7)) {
        func_0x000180088470(arg1, 2, 7);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    fcn.180089e10(arg1, 0);
    fcn.180085bf0(arg1, 2);
    *(undefined *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 6) = 0;
    iVar8 = func_0x000180085d50(arg1, 1);
    if (iVar8 != 0) {
        in_R8 = 0;
        dVar4 = (double)func_0x000180085ea0(arg1, 1);
        if (dVar4 == 0.0) {
            func_0x000180086c20(arg1);
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            puVar1 = *(undefined4 **)(arg1 + 0x40);
            for (puVar2 = puVar1; puVar1 + -8 < puVar2; puVar2 = puVar2 + -4) {
                *puVar2 = puVar2[-4];
                puVar2[1] = puVar2[-3];
                puVar2[2] = puVar2[-2];
                puVar2[3] = puVar2[-1];
            }
            puVar2 = *(undefined4 **)(arg1 + 0x40);
            uVar5 = puVar2[1];
            uVar6 = puVar2[2];
            uVar7 = puVar2[3];
            puVar1[-8] = *puVar2;
            puVar1[-7] = uVar5;
            puVar1[-6] = uVar6;
            puVar1[-5] = uVar7;
            func_0x000180087760(arg1);
            return 0;
        }
    }
    if (((*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -0x14) != 8) ||
        (*(char *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x20) + 3) == '\0')) &&
       (iVar8 = func_0x000180087760(arg1), iVar8 != 0)) {
        return 1;
    }
    fcn.180088560(arg1, 0x18063db78, in_R8, in_R9);
    pcVar3 = (code *)swi(3);
    uVar9 = (*pcVar3)();
    return uVar9;
}

// ============================================================
// Function: FUN_18008a140
// Address: 0x18008a140
// Size: 184 bytes
// ============================================================
undefined8 fcn.18008a140(int64_t arg1)
{
    uint64_t arg4;
    code *pcVar1;
    undefined4 uVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    
    uVar4 = *(uint64_t *)(arg1 + 0x28);
    arg4 = *(uint64_t *)(arg1 + 0x40);
    uVar5 = uVar4;
    if (arg4 <= uVar4) {
        uVar5 = *(uint64_t *)0x180782430;
    }
    if ((uVar5 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar5 + 0xc) == -1)) {
        fcn.180088560(arg1, 0x18063da20, 1, arg4);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    uVar5 = uVar4 + 0x10;
    uVar6 = uVar5;
    if (arg4 <= uVar5) {
        uVar6 = *(uint64_t *)0x180782430;
    }
    if ((uVar6 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar6 + 0xc) != -1)) {
        if (arg4 <= uVar4) {
            uVar4 = *(uint64_t *)0x180782430;
        }
        if (arg4 <= uVar5) {
            uVar5 = *(uint64_t *)0x180782430;
        }
        if ((uVar4 != *(uint64_t *)0x180782430) && (uVar5 != *(uint64_t *)0x180782430)) {
            uVar2 = fcn.180099140();
            fcn.180086b20(arg1, uVar2);
            return 1;
        }
        fcn.180086b20(arg1, 0);
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 2, arg4);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_18008a200
// Address: 0x18008a200
// Size: 202 bytes
// ============================================================
undefined8 fcn.18008a200(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4)
{
    undefined8 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined8 *puVar6;
    undefined4 *puVar7;
    undefined8 uVar8;
    
    puVar1 = *(undefined8 **)(arg1 + 0x28);
    puVar6 = puVar1;
    if (*(undefined8 **)(arg1 + 0x40) <= puVar1) {
        puVar6 = *(undefined8 **)0x180782430;
    }
    if ((puVar6 == *(undefined8 **)0x180782430) || (*(int32_t *)((int64_t)puVar6 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar2 = (code *)swi(3);
        uVar8 = (*pcVar2)();
        return uVar8;
    }
    puVar6 = puVar1 + 2;
    if (*(undefined8 **)(arg1 + 0x40) <= puVar1 + 2) {
        puVar6 = *(undefined8 **)0x180782430;
    }
    if ((puVar6 != *(undefined8 **)0x180782430) && (*(int32_t *)((int64_t)puVar6 + 0xc) != -1)) {
        fcn.1800858c0(arg1, 2);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        puVar1 = *(undefined8 **)(arg1 + 0x40);
        puVar6 = *(undefined8 **)(arg1 + 0x28);
        if (puVar1 <= *(undefined8 **)(arg1 + 0x28)) {
            puVar6 = *(undefined8 **)0x180782430;
        }
        puVar7 = (undefined4 *)fcn.1800a0ea0(*puVar6, puVar1 + -2);
        uVar3 = puVar7[1];
        uVar4 = puVar7[2];
        uVar5 = puVar7[3];
        *(undefined4 *)(puVar1 + -2) = *puVar7;
        *(undefined4 *)((int64_t)puVar1 - 0xc) = uVar3;
        *(undefined4 *)(puVar1 + -1) = uVar4;
        *(undefined4 *)((int64_t)puVar1 - 4) = uVar5;
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 2, arg4);
    pcVar2 = (code *)swi(3);
    uVar8 = (*pcVar2)();
    return uVar8;
}

// ============================================================
// Function: FUN_18008a2d0
// Address: 0x18008a2d0
// Size: 190 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h

undefined8 fcn.18008a2d0(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4)
{
    uint64_t uVar1;
    uint64_t uVar2;
    code *pcVar3;
    uint64_t uVar4;
    undefined8 uVar5;
    
    uVar1 = *(uint64_t *)(arg1 + 0x28);
    uVar2 = *(uint64_t *)(arg1 + 0x40);
    uVar4 = uVar1;
    if (uVar2 <= uVar1) {
        uVar4 = *(uint64_t *)0x180782430;
    }
    if ((uVar4 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar4 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar3 = (code *)swi(3);
        uVar5 = (*pcVar3)();
        return uVar5;
    }
    uVar4 = uVar1 + 0x10;
    if (uVar2 <= uVar1 + 0x10) {
        uVar4 = *(uint64_t *)0x180782430;
    }
    if ((uVar4 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar4 + 0xc) != -1)) {
        uVar4 = uVar1 + 0x20;
        if (uVar2 <= uVar1 + 0x20) {
            uVar4 = *(uint64_t *)0x180782430;
        }
        if ((uVar4 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar4 + 0xc) != -1)) {
            fcn.1800858c0(arg1, 3);
            fcn.180087440(arg1, 1);
            return 1;
        }
        fcn.180088560(arg1, 0x18063da20, 3, arg4);
        pcVar3 = (code *)swi(3);
        uVar5 = (*pcVar3)();
        return uVar5;
    }
    fcn.180088560(arg1, 0x18063da20, 2, arg4);
    pcVar3 = (code *)swi(3);
    uVar5 = (*pcVar3)();
    return uVar5;
}

// ============================================================
// Function: FUN_18008a390
// Address: 0x18008a390
// Size: 150 bytes
// ============================================================
undefined8 fcn.18008a390(int64_t arg1)
{
    int32_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    piVar4 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if ((piVar4 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar4 + 0xc) - 6U < 2)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
            piVar6 = *(int64_t **)0x180782430;
        }
        iVar1 = *(int32_t *)((int64_t)piVar6 + 0xc);
        if (iVar1 == 6) {
            uVar3 = *(undefined4 *)(*piVar6 + 0x14);
        } else if (iVar1 == 7) {
            uVar3 = func_0x0001800a1110(*piVar6);
        } else if ((iVar1 == 9) || (iVar1 == 0xb)) {
            uVar3 = *(undefined4 *)(*piVar6 + 4);
        } else {
            uVar3 = 0;
        }
        func_0x0001800865e0(arg1, uVar3);
        return 1;
    }
    func_0x000180088380(arg1, 1, 0x18063db58);
    pcVar2 = (code *)swi(3);
    uVar5 = (*pcVar2)();
    return uVar5;
}

// ============================================================
// Function: FUN_18008a430
// Address: 0x18008a430
// Size: 31 bytes
// ============================================================
undefined8 fcn.18008a430(int64_t arg1)
{
    fcn.1800865e0(arg1, *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30) >> 10);
    return 1;
}

// ============================================================
// Function: FUN_18008a450
// Address: 0x18008a450
// Size: 48 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18008a450(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4)
{
    code *pcVar1;
    uint64_t uVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t var_8h;
    
    uVar2 = *(uint64_t *)(arg1 + 0x28);
    uVar4 = uVar2;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar2) {
        uVar4 = *(uint64_t *)0x180782430;
    }
    if ((uVar4 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar4 + 0xc) != -1)) {
        if (*(uint64_t *)(arg1 + 0x40) <= uVar2) {
            uVar2 = *(uint64_t *)0x180782430;
        }
        if ((uVar2 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar2 + 0xc) == -1)) {
            iVar5 = 0x18063d8c0;
        } else {
            iVar5 = *(int64_t *)((int64_t)*(int32_t *)(uVar2 + 0xc) * 8 + 0x180612cd0);
            if (iVar5 == 0) {
                fcn.180086510(arg1);
                return 1;
            }
        }
        uVar3 = fcn.180498cd0(iVar5);
        fcn.1800867f0(arg1, iVar5, uVar3);
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 1, arg4);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_18008a480
// Address: 0x18008a480
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18008a450(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4)
{
    code *pcVar1;
    uint64_t uVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t var_8h;
    
    uVar2 = *(uint64_t *)(arg1 + 0x28);
    uVar4 = uVar2;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar2) {
        uVar4 = *(uint64_t *)0x180782430;
    }
    if ((uVar4 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar4 + 0xc) != -1)) {
        if (*(uint64_t *)(arg1 + 0x40) <= uVar2) {
            uVar2 = *(uint64_t *)0x180782430;
        }
        if ((uVar2 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar2 + 0xc) == -1)) {
            iVar5 = 0x18063d8c0;
        } else {
            iVar5 = *(int64_t *)((int64_t)*(int32_t *)(uVar2 + 0xc) * 8 + 0x180612cd0);
            if (iVar5 == 0) {
                fcn.180086510(arg1);
                return 1;
            }
        }
        uVar3 = fcn.180498cd0(iVar5);
        fcn.1800867f0(arg1, iVar5, uVar3);
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 1, arg4);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_18008a4bf
// Address: 0x18008a4bf
// Size: 45 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18008a450(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4)
{
    code *pcVar1;
    uint64_t uVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t var_8h;
    
    uVar2 = *(uint64_t *)(arg1 + 0x28);
    uVar4 = uVar2;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar2) {
        uVar4 = *(uint64_t *)0x180782430;
    }
    if ((uVar4 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar4 + 0xc) != -1)) {
        if (*(uint64_t *)(arg1 + 0x40) <= uVar2) {
            uVar2 = *(uint64_t *)0x180782430;
        }
        if ((uVar2 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar2 + 0xc) == -1)) {
            iVar5 = 0x18063d8c0;
        } else {
            iVar5 = *(int64_t *)((int64_t)*(int32_t *)(uVar2 + 0xc) * 8 + 0x180612cd0);
            if (iVar5 == 0) {
                fcn.180086510(arg1);
                return 1;
            }
        }
        uVar3 = fcn.180498cd0(iVar5);
        fcn.1800867f0(arg1, iVar5, uVar3);
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 1, arg4);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_18008a4ec
// Address: 0x18008a4ec
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18008a450(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4)
{
    code *pcVar1;
    uint64_t uVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t var_8h;
    
    uVar2 = *(uint64_t *)(arg1 + 0x28);
    uVar4 = uVar2;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar2) {
        uVar4 = *(uint64_t *)0x180782430;
    }
    if ((uVar4 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar4 + 0xc) != -1)) {
        if (*(uint64_t *)(arg1 + 0x40) <= uVar2) {
            uVar2 = *(uint64_t *)0x180782430;
        }
        if ((uVar2 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar2 + 0xc) == -1)) {
            iVar5 = 0x18063d8c0;
        } else {
            iVar5 = *(int64_t *)((int64_t)*(int32_t *)(uVar2 + 0xc) * 8 + 0x180612cd0);
            if (iVar5 == 0) {
                fcn.180086510(arg1);
                return 1;
            }
        }
        uVar3 = fcn.180498cd0(iVar5);
        fcn.1800867f0(arg1, iVar5, uVar3);
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 1, arg4);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

