// Chunk 181 - 50 functions

// ============================================================
// Function: FUN_18023d689
// Address: 0x18023d689
// Size: 33 bytes
// ============================================================
undefined8 fcn.18023d689(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_88h, int64_t arg_90h)
{
    fcn.180224990(arg_88h, 0x1804e2fa0, 0x364);
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18023d6aa
// Address: 0x18023d6aa
// Size: 16 bytes
// ============================================================
undefined8 fcn.18023d6aa(void)
{
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_18023d6c0
// Address: 0x18023d6c0
// Size: 321 bytes
// ============================================================
int32_t fcn.18023d6c0(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t *piVar5;
    int64_t in_RDX;
    int32_t iVar6;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18023d6d1;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RDX == 0) {
        return -2;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_58h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_60h + iVar3) = unaff_R12;
    *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_R13;
    iVar6 = 0;
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18023d726;
        in_R8 = fcn.180498cd0(in_RDX);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18023d73c;
    iVar4 = fcn.1802394c0(*(int64_t *)((int64_t)&iStackX_18 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar3), 
                          *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                          *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                          *(int64_t *)(&stack0x00000040 + iVar3));
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18023d753;
        iVar1 = fcn.180222010(iVar4);
        iVar2 = iVar6;
        if (0 < iVar1) {
            do {
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18023d76a;
                piVar5 = (int32_t *)fcn.180222340(iVar4, iVar6);
                iVar1 = *piVar5;
                if (iVar1 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18023d7c0;
                    fcn.18022cd20(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&iStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
                } else if (((iVar1 != 1) && (iVar1 != 2)) && (iVar1 == 7)) {
                    *(undefined8 *)((int64_t)&iStackX_18 + iVar3 + -8) = 0;
                    *(int64_t *)((int64_t)&var_8h + iVar3) = in_R8;
                    *(int64_t *)(&stack0x00000000 + iVar3) = in_RDX;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18023d7ac;
                    iVar2 = fcn.18023dac0(*(int64_t *)((int64_t)&iStackX_18 + iVar3 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_18 + iVar3), 
                                          *(int64_t *)((int64_t)&var_20h + iVar3), 
                                          *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3)
                                          , *(int64_t *)(&stack0x00000040 + iVar3));
                    if (iVar2 != 0) break;
                }
                iVar6 = iVar6 + 1;
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18023d7ca;
                iVar1 = fcn.180222010(iVar4);
            } while (iVar6 < iVar1);
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18023d7d6;
        fcn.18028f450(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3));
        if (iVar2 != 0) {
            return iVar2;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18023d810
// Address: 0x18023d810
// Size: 125 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Removing arg arg_ach because it doesn't fit into ProtoModel

void fcn.18023d810(int64_t arg_28h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023d820;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(uint64_t *)((int64_t)&arg_28h + iVar2) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023d83f;
    iVar1 = fcn.18023e3a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                          *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                          *(int64_t *)(&stack0x00000068 + iVar2), *(int64_t *)(&stack0x00000070 + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023d84a;
        iVar3 = fcn.1802288e0();
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023d862;
            iVar1 = fcn.180260b20(*(int64_t *)(&stack0x00000040 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar2));
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023d86e;
                fcn.180228780(*(int64_t *)(&stack0x00000040 + iVar2));
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023d87d;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_28h + iVar2) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2));
    return;
}

// ============================================================
// Function: FUN_18023d890
// Address: 0x18023d890
// Size: 286 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Removing arg arg_ach because it doesn't fit into ProtoModel

void fcn.18023d890(int64_t arg_38h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023d8aa;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_38h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar3);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023d8cb;
    iVar4 = func_0x00018045b928();
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023d8ec;
        iVar5 = func_0x0001802231e0(in_RCX, 0x1804e2fa0, 0x46f);
        if (iVar5 != 0) {
            *(undefined *)(iVar4 + (iVar5 - in_RCX)) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023d90d;
            iVar1 = fcn.18023e3a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_68h + iVar3), *(int64_t *)((int64_t)&arg_70h + iVar3));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023d925;
                iVar2 = fcn.18023e3a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                      *(int64_t *)((int64_t)&arg_68h + iVar3), *(int64_t *)((int64_t)&arg_70h + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023d93c;
                fcn.180224990(iVar5, 0x1804e2fa0, 0x47c);
                iVar4 = 0;
                iVar5 = 0;
                if ((iVar2 != 0) && (iVar5 = iVar4, iVar1 == iVar2)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023d94b;
                    iVar4 = fcn.1802288e0();
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023d964;
                        iVar1 = fcn.180260b20(*(int64_t *)(&stack0x00000040 + iVar3), 
                                              *(int64_t *)(&stack0x00000048 + iVar3), 
                                              *(int64_t *)(&stack0x00000050 + iVar3));
                        if (iVar1 != 0) goto code_r0x00018023d98c;
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023d982;
            fcn.180224990(iVar5, 0x1804e2fa0, 0x48b);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023d98a;
            fcn.180228780(*(int64_t *)(&stack0x00000040 + iVar3));
        }
    }
code_r0x00018023d98c:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023d999;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_38h + iVar3) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar3));
    return;
}

// ============================================================
// Function: FUN_18023d9b0
// Address: 0x18023d9b0
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined2 *
fcn.18023d9b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    char *pcVar4;
    int64_t iVar5;
    int64_t *piVar6;
    undefined2 *puVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 in_RCX;
    undefined8 uVar10;
    int64_t *piVar11;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    char *pcVar12;
    undefined2 *puVar13;
    undefined *puVar14;
    undefined8 unaff_R12;
    int64_t iVar15;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iVar16;
    int64_t aiStackX_8 [4];
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x18023d9bc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023d9c7;
    iVar2 = func_0x000180255500();
    if (0x7f < iVar2) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023d9e0;
        pcVar4 = (char *)func_0x000180297ec0(in_RCX);
        if (pcVar4 == (char *)0x0) {
            return (undefined2 *)0x0;
        }
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023da00;
        iVar5 = fcn.180498cd0(pcVar4);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023da19;
        puVar7 = (undefined2 *)
                 fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x10), 
                               *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18));
        if (puVar7 != (undefined2 *)0x0) {
            cVar1 = *pcVar4;
            *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
            pcVar12 = pcVar4 + 1;
            if (cVar1 != '-') {
                pcVar12 = pcVar4;
            }
            uVar10 = 0x1804e2fe0;
            if (cVar1 != '-') {
                uVar10 = 0x1805ab2c0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023da76;
            func_0x000180223790(puVar7, uVar10, iVar5 + 3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023da84;
            func_0x000180223710(puVar7, pcVar12, iVar5 + 3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023da99;
            fcn.180224990(pcVar4, 0x1804e2fa0, 0xa2);
            return puVar7;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023da36;
        fcn.180224990(pcVar4, 0x1804e2fa0, 0x96);
        return (undefined2 *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = *(undefined8 *)((int64_t)aiStackX_8 + iVar3 + 0x10);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)aiStackX_8 + iVar3 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)aiStackX_8 + iVar3 + 8) = unaff_R12;
    *(undefined8 *)((int64_t)aiStackX_8 + iVar3) = unaff_R13;
    *(undefined8 *)((int64_t)aiStackX_8 + iVar3 + -8) = unaff_R14;
    *(undefined8 *)((int64_t)&var_8h + iVar3) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180297ca2;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar8 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297caf;
    iVar2 = func_0x000180255500();
    iVar2 = (iVar2 * 3) / 10 + (iVar2 * 3) / 1000;
    iVar15 = (int64_t)((iVar2 + 2) / 0x13 + 1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297d13;
    piVar6 = (int64_t *)func_0x000180224ed0(iVar15, 8, 0x1804eda20, 0x42);
    iVar16 = (int64_t)iVar2 + 5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297d32;
    puVar7 = (undefined2 *)
             fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_8 + iVar5 + iVar3 + 0x10), 
                           *(int64_t *)((int64_t)aiStackX_8 + iVar5 + iVar3 + 0x18));
    if ((puVar7 != (undefined2 *)0x0) && (piVar6 != (int64_t *)0x0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297d4f;
        iVar8 = func_0x0001802551a0(in_RCX);
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297d69;
            iVar2 = func_0x0001802553f0(iVar8);
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297d80;
                iVar2 = func_0x000180255370(iVar8);
                puVar13 = puVar7;
                if (iVar2 != 0) {
                    *(undefined *)puVar7 = 0x2d;
                    puVar13 = (undefined2 *)((int64_t)puVar7 + 1);
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297d94;
                iVar2 = func_0x0001802553f0(iVar8);
                piVar11 = piVar6;
                while (iVar2 == 0) {
                    if (iVar15 <= (int64_t)piVar11 - (int64_t)piVar6 >> 3) goto code_r0x000180297e60;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297dc0;
                    iVar9 = func_0x000180297060(iVar8, 10000000000000000000);
                    *piVar11 = iVar9;
                    if (iVar9 == -1) goto code_r0x000180297e60;
                    piVar11 = piVar11 + 1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297dd9;
                    iVar2 = func_0x0001802553f0(iVar8);
                }
                iVar15 = piVar11[-1];
                *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297dfd;
                iVar2 = func_0x000180245f70(puVar13, (undefined *)((iVar16 - (int64_t)puVar13) + (int64_t)puVar7), 
                                            0x1804eda34, iVar15);
                if (iVar2 < 0) goto code_r0x000180297e60;
                puVar14 = (undefined *)((int64_t)puVar13 + (int64_t)iVar2);
                while (piVar11 = piVar11 + -1, piVar11 != piVar6) {
                    iVar15 = piVar11[-1];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297e30;
                    iVar2 = func_0x000180245f70(puVar14, (undefined *)((iVar16 - (int64_t)puVar14) + (int64_t)puVar7), 
                                                0x1804eda40, iVar15);
                    if (iVar2 < 0) goto code_r0x000180297e60;
                    puVar14 = puVar14 + iVar2;
                }
            } else {
                *puVar7 = 0x30;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297e53;
            fcn.180224990(piVar6, 0x1804eda20, 0x6e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297e5b;
            func_0x000180255290(iVar8);
            return puVar7;
        }
    }
code_r0x000180297e60:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297e75;
    fcn.180224990(piVar6, 0x1804eda20, 0x6e);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297e7d;
    func_0x000180255290(iVar8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297e92;
    fcn.180224990(puVar7, 0x1804eda20, 0x72);
    return (undefined2 *)0x0;
}

// ============================================================
// Function: FUN_18023d9ee
// Address: 0x18023d9ee
// Size: 90 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined2 *
fcn.18023d9b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    char *pcVar4;
    int64_t iVar5;
    int64_t *piVar6;
    undefined2 *puVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 in_RCX;
    undefined8 uVar10;
    int64_t *piVar11;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    char *pcVar12;
    undefined2 *puVar13;
    undefined *puVar14;
    undefined8 unaff_R12;
    int64_t iVar15;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iVar16;
    int64_t aiStackX_8 [4];
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x18023d9bc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023d9c7;
    iVar2 = func_0x000180255500();
    if (0x7f < iVar2) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023d9e0;
        pcVar4 = (char *)func_0x000180297ec0(in_RCX);
        if (pcVar4 == (char *)0x0) {
            return (undefined2 *)0x0;
        }
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023da00;
        iVar5 = fcn.180498cd0(pcVar4);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023da19;
        puVar7 = (undefined2 *)
                 fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x10), 
                               *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18));
        if (puVar7 != (undefined2 *)0x0) {
            cVar1 = *pcVar4;
            *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
            pcVar12 = pcVar4 + 1;
            if (cVar1 != '-') {
                pcVar12 = pcVar4;
            }
            uVar10 = 0x1804e2fe0;
            if (cVar1 != '-') {
                uVar10 = 0x1805ab2c0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023da76;
            func_0x000180223790(puVar7, uVar10, iVar5 + 3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023da84;
            func_0x000180223710(puVar7, pcVar12, iVar5 + 3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023da99;
            fcn.180224990(pcVar4, 0x1804e2fa0, 0xa2);
            return puVar7;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023da36;
        fcn.180224990(pcVar4, 0x1804e2fa0, 0x96);
        return (undefined2 *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = *(undefined8 *)((int64_t)aiStackX_8 + iVar3 + 0x10);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)aiStackX_8 + iVar3 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)aiStackX_8 + iVar3 + 8) = unaff_R12;
    *(undefined8 *)((int64_t)aiStackX_8 + iVar3) = unaff_R13;
    *(undefined8 *)((int64_t)aiStackX_8 + iVar3 + -8) = unaff_R14;
    *(undefined8 *)((int64_t)&var_8h + iVar3) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180297ca2;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar8 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297caf;
    iVar2 = func_0x000180255500();
    iVar2 = (iVar2 * 3) / 10 + (iVar2 * 3) / 1000;
    iVar15 = (int64_t)((iVar2 + 2) / 0x13 + 1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297d13;
    piVar6 = (int64_t *)func_0x000180224ed0(iVar15, 8, 0x1804eda20, 0x42);
    iVar16 = (int64_t)iVar2 + 5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297d32;
    puVar7 = (undefined2 *)
             fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_8 + iVar5 + iVar3 + 0x10), 
                           *(int64_t *)((int64_t)aiStackX_8 + iVar5 + iVar3 + 0x18));
    if ((puVar7 != (undefined2 *)0x0) && (piVar6 != (int64_t *)0x0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297d4f;
        iVar8 = func_0x0001802551a0(in_RCX);
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297d69;
            iVar2 = func_0x0001802553f0(iVar8);
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297d80;
                iVar2 = func_0x000180255370(iVar8);
                puVar13 = puVar7;
                if (iVar2 != 0) {
                    *(undefined *)puVar7 = 0x2d;
                    puVar13 = (undefined2 *)((int64_t)puVar7 + 1);
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297d94;
                iVar2 = func_0x0001802553f0(iVar8);
                piVar11 = piVar6;
                while (iVar2 == 0) {
                    if (iVar15 <= (int64_t)piVar11 - (int64_t)piVar6 >> 3) goto code_r0x000180297e60;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297dc0;
                    iVar9 = func_0x000180297060(iVar8, 10000000000000000000);
                    *piVar11 = iVar9;
                    if (iVar9 == -1) goto code_r0x000180297e60;
                    piVar11 = piVar11 + 1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297dd9;
                    iVar2 = func_0x0001802553f0(iVar8);
                }
                iVar15 = piVar11[-1];
                *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297dfd;
                iVar2 = func_0x000180245f70(puVar13, (undefined *)((iVar16 - (int64_t)puVar13) + (int64_t)puVar7), 
                                            0x1804eda34, iVar15);
                if (iVar2 < 0) goto code_r0x000180297e60;
                puVar14 = (undefined *)((int64_t)puVar13 + (int64_t)iVar2);
                while (piVar11 = piVar11 + -1, piVar11 != piVar6) {
                    iVar15 = piVar11[-1];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297e30;
                    iVar2 = func_0x000180245f70(puVar14, (undefined *)((iVar16 - (int64_t)puVar14) + (int64_t)puVar7), 
                                                0x1804eda40, iVar15);
                    if (iVar2 < 0) goto code_r0x000180297e60;
                    puVar14 = puVar14 + iVar2;
                }
            } else {
                *puVar7 = 0x30;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297e53;
            fcn.180224990(piVar6, 0x1804eda20, 0x6e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297e5b;
            func_0x000180255290(iVar8);
            return puVar7;
        }
    }
code_r0x000180297e60:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297e75;
    fcn.180224990(piVar6, 0x1804eda20, 0x6e);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297e7d;
    func_0x000180255290(iVar8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297e92;
    fcn.180224990(puVar7, 0x1804eda20, 0x72);
    return (undefined2 *)0x0;
}

// ============================================================
// Function: FUN_18023da48
// Address: 0x18023da48
// Size: 105 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined2 *
fcn.18023d9b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    char *pcVar4;
    int64_t iVar5;
    int64_t *piVar6;
    undefined2 *puVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 in_RCX;
    undefined8 uVar10;
    int64_t *piVar11;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    char *pcVar12;
    undefined2 *puVar13;
    undefined *puVar14;
    undefined8 unaff_R12;
    int64_t iVar15;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iVar16;
    int64_t aiStackX_8 [4];
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x18023d9bc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023d9c7;
    iVar2 = func_0x000180255500();
    if (0x7f < iVar2) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023d9e0;
        pcVar4 = (char *)func_0x000180297ec0(in_RCX);
        if (pcVar4 == (char *)0x0) {
            return (undefined2 *)0x0;
        }
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023da00;
        iVar5 = fcn.180498cd0(pcVar4);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023da19;
        puVar7 = (undefined2 *)
                 fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x10), 
                               *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18));
        if (puVar7 != (undefined2 *)0x0) {
            cVar1 = *pcVar4;
            *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
            pcVar12 = pcVar4 + 1;
            if (cVar1 != '-') {
                pcVar12 = pcVar4;
            }
            uVar10 = 0x1804e2fe0;
            if (cVar1 != '-') {
                uVar10 = 0x1805ab2c0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023da76;
            func_0x000180223790(puVar7, uVar10, iVar5 + 3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023da84;
            func_0x000180223710(puVar7, pcVar12, iVar5 + 3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023da99;
            fcn.180224990(pcVar4, 0x1804e2fa0, 0xa2);
            return puVar7;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023da36;
        fcn.180224990(pcVar4, 0x1804e2fa0, 0x96);
        return (undefined2 *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = *(undefined8 *)((int64_t)aiStackX_8 + iVar3 + 0x10);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)aiStackX_8 + iVar3 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)aiStackX_8 + iVar3 + 8) = unaff_R12;
    *(undefined8 *)((int64_t)aiStackX_8 + iVar3) = unaff_R13;
    *(undefined8 *)((int64_t)aiStackX_8 + iVar3 + -8) = unaff_R14;
    *(undefined8 *)((int64_t)&var_8h + iVar3) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180297ca2;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar8 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297caf;
    iVar2 = func_0x000180255500();
    iVar2 = (iVar2 * 3) / 10 + (iVar2 * 3) / 1000;
    iVar15 = (int64_t)((iVar2 + 2) / 0x13 + 1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297d13;
    piVar6 = (int64_t *)func_0x000180224ed0(iVar15, 8, 0x1804eda20, 0x42);
    iVar16 = (int64_t)iVar2 + 5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297d32;
    puVar7 = (undefined2 *)
             fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_8 + iVar5 + iVar3 + 0x10), 
                           *(int64_t *)((int64_t)aiStackX_8 + iVar5 + iVar3 + 0x18));
    if ((puVar7 != (undefined2 *)0x0) && (piVar6 != (int64_t *)0x0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297d4f;
        iVar8 = func_0x0001802551a0(in_RCX);
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297d69;
            iVar2 = func_0x0001802553f0(iVar8);
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297d80;
                iVar2 = func_0x000180255370(iVar8);
                puVar13 = puVar7;
                if (iVar2 != 0) {
                    *(undefined *)puVar7 = 0x2d;
                    puVar13 = (undefined2 *)((int64_t)puVar7 + 1);
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297d94;
                iVar2 = func_0x0001802553f0(iVar8);
                piVar11 = piVar6;
                while (iVar2 == 0) {
                    if (iVar15 <= (int64_t)piVar11 - (int64_t)piVar6 >> 3) goto code_r0x000180297e60;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297dc0;
                    iVar9 = func_0x000180297060(iVar8, 10000000000000000000);
                    *piVar11 = iVar9;
                    if (iVar9 == -1) goto code_r0x000180297e60;
                    piVar11 = piVar11 + 1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297dd9;
                    iVar2 = func_0x0001802553f0(iVar8);
                }
                iVar15 = piVar11[-1];
                *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297dfd;
                iVar2 = func_0x000180245f70(puVar13, (undefined *)((iVar16 - (int64_t)puVar13) + (int64_t)puVar7), 
                                            0x1804eda34, iVar15);
                if (iVar2 < 0) goto code_r0x000180297e60;
                puVar14 = (undefined *)((int64_t)puVar13 + (int64_t)iVar2);
                while (piVar11 = piVar11 + -1, piVar11 != piVar6) {
                    iVar15 = piVar11[-1];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297e30;
                    iVar2 = func_0x000180245f70(puVar14, (undefined *)((iVar16 - (int64_t)puVar14) + (int64_t)puVar7), 
                                                0x1804eda40, iVar15);
                    if (iVar2 < 0) goto code_r0x000180297e60;
                    puVar14 = puVar14 + iVar2;
                }
            } else {
                *puVar7 = 0x30;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297e53;
            fcn.180224990(piVar6, 0x1804eda20, 0x6e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297e5b;
            func_0x000180255290(iVar8);
            return puVar7;
        }
    }
code_r0x000180297e60:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297e75;
    fcn.180224990(piVar6, 0x1804eda20, 0x6e);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297e7d;
    func_0x000180255290(iVar8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar3) = 0x180297e92;
    fcn.180224990(puVar7, 0x1804eda20, 0x72);
    return (undefined2 *)0x0;
}

// ============================================================
// Function: FUN_18023dac0
// Address: 0x18023dac0
// Size: 391 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.18023dac0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h,
                     int64_t arg_68h)
{
    int64_t *piVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t *in_RCX;
    int32_t in_EDX;
    code *in_R8;
    undefined4 in_R9D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18023dad8;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar6 = *(int64_t *)(in_RCX + 2);
    if (iVar6 != 0) {
        iVar3 = *in_RCX;
        if (iVar3 != 0) {
            if (in_EDX < 1) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18023dba4;
                iVar3 = func_0x0001802a7f60((int64_t)&arg_38h + iVar5, in_RCX);
                if (-1 < iVar3) {
                    *(undefined4 *)((int64_t)&var_8h + iVar5) = in_R9D;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18023dbc4;
                    iVar4 = (*in_R8)(*(undefined8 *)((int64_t)&arg_38h + iVar5), (int64_t)iVar3, 
                                     *(undefined8 *)((int64_t)&arg_58h + iVar5), 
                                     *(undefined8 *)((int64_t)&arg_60h + iVar5));
                    if ((0 < iVar4) && (piVar1 = *(int64_t **)((int64_t)&arg_68h + iVar5), piVar1 != (int64_t *)0x0)) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18023dbf1;
                        iVar6 = func_0x000180223270(*(undefined8 *)((int64_t)&arg_38h + iVar5), (int64_t)iVar3, 
                                                    0x1804e2fa0, 0x362);
                        *piVar1 = iVar6;
                        if (iVar6 == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18023dc10;
                            fcn.180224990(*(undefined8 *)((int64_t)&arg_38h + iVar5), 0x1804e2fa0, 0x364);
                            return -1;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18023dc2e;
                    fcn.180224990(*(undefined8 *)((int64_t)&arg_38h + iVar5), 0x1804e2fa0, 0x368);
                    return iVar4;
                }
            } else {
                if (in_EDX != in_RCX[1]) {
                    return 0;
                }
                if (in_EDX == 0x16) {
                    *(undefined4 *)((int64_t)&var_8h + iVar5) = in_R9D;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18023db29;
                    iVar3 = (*in_R8)(iVar6, (int64_t)iVar3, *(undefined8 *)((int64_t)&arg_58h + iVar5), 
                                     *(undefined8 *)((int64_t)&arg_60h + iVar5));
                    if (iVar3 < 1) {
                        return iVar3;
                    }
                } else {
                    if (iVar3 != (int32_t)*(undefined8 *)((int64_t)&arg_60h + iVar5)) {
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18023db4d;
                    iVar3 = func_0x000180497f30(iVar6, *(undefined8 *)((int64_t)&arg_58h + iVar5));
                    if (iVar3 != 0) {
                        return 0;
                    }
                    iVar3 = 1;
                }
                piVar1 = *(int64_t **)((int64_t)&arg_68h + iVar5);
                if (piVar1 == (int64_t *)0x0) {
                    return iVar3;
                }
                iVar4 = *in_RCX;
                uVar2 = *(undefined8 *)(in_RCX + 2);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18023db84;
                iVar6 = func_0x000180223270(uVar2, (int64_t)iVar4, 0x1804e2fa0, 0x351);
                *piVar1 = iVar6;
                if (iVar6 != 0) {
                    return iVar3;
                }
            }
            return -1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18023dc50
// Address: 0x18023dc50
// Size: 123 bytes
// ============================================================
bool fcn.18023dc50(int64_t arg_48h)
{
    uint32_t uVar1;
    uint64_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    char *in_RCX;
    uint64_t in_RDX;
    uint64_t in_R9;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023dc5c;
    iVar4 = fcn.18045a350();
    uVar1 = *(uint32_t *)((int64_t)&arg_48h + -iVar4);
    uVar2 = in_RDX;
    if ((uVar1 >> 0xf & 1) != 0) {
        for (; in_R9 < uVar2; uVar2 = uVar2 - 1) {
            if (*in_RCX == '\0') {
                return false;
            }
            if (((uVar1 & 0x10) != 0) && (*in_RCX == '.')) break;
            in_RCX = in_RCX + 1;
        }
        if (uVar2 == in_R9) goto code_r0x00018023dcb4;
    }
    if (in_RDX != in_R9) {
        return false;
    }
code_r0x00018023dcb4:
    *(undefined8 *)((int64_t)&uStack_10 + -iVar4) = 0x18023dcbc;
    iVar3 = func_0x000180497f30();
    return iVar3 == 0;
}

// ============================================================
// Function: FUN_18023dcd0
// Address: 0x18023dcd0
// Size: 193 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.18023dcd0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    char *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t iVar4;
    int64_t in_R8;
    char *pcVar5;
    int64_t in_R9;
    bool bVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023dcf0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RDX == in_R9) {
        iVar4 = in_RDX;
        if (in_RDX != 0) {
            pcVar5 = (char *)(in_R8 + in_RDX);
            do {
                pcVar5 = pcVar5 + -1;
                iVar4 = iVar4 + -1;
                pcVar1 = pcVar5 + (in_RCX - in_R8);
                if (pcVar5[in_RCX - in_R8] == '@') {
                    pcVar5 = (char *)(iVar4 + in_R8);
code_r0x00018023dd42:
                    *(undefined4 *)((int64_t)&var_18h + iVar3) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023dd51;
                    iVar2 = func_0x00018023dda0(pcVar1, in_RDX - iVar4, pcVar5, in_RDX - iVar4);
                    if (iVar2 == 0) goto code_r0x00018023dd74;
                    break;
                }
                if (*pcVar5 == '@') goto code_r0x00018023dd42;
            } while (iVar4 != 0);
        }
        if (iVar4 == 0) {
            iVar4 = in_RDX;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023dd6a;
        iVar2 = func_0x000180497f30(in_RCX, in_R8, iVar4);
        bVar6 = iVar2 == 0;
    } else {
code_r0x00018023dd74:
        bVar6 = false;
    }
    return bVar6;
}

// ============================================================
// Function: FUN_18023dda0
// Address: 0x18023dda0
// Size: 166 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18023dda0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    char cVar1;
    char cVar2;
    uint64_t uVar3;
    char *pcVar4;
    int64_t iVar5;
    int64_t var_8h;
    
    uVar3 = arg2;
    pcVar4 = (char *)arg1;
    if (((uint32_t)arg_28h >> 0xf & 1) != 0) {
        if ((uint64_t)arg4 < (uint64_t)arg2) {
            do {
                if (*pcVar4 == '\0') {
                    return 0;
                }
                if (((arg_28h & 0x10U) != 0) && (*pcVar4 == '.')) break;
                pcVar4 = pcVar4 + 1;
                uVar3 = uVar3 - 1;
            } while ((uint64_t)arg4 < uVar3);
        }
        if (uVar3 == arg4) goto code_r0x00018023ddec;
    }
    uVar3 = arg2;
    pcVar4 = (char *)arg1;
    if (arg2 != arg4) {
        return 0;
    }
code_r0x00018023ddec:
    if (uVar3 != 0) {
        iVar5 = (int64_t)pcVar4 - arg3;
        do {
            cVar1 = *(char *)(arg3 + iVar5);
            cVar2 = *(char *)arg3;
            if (cVar1 == '\0') {
                return 0;
            }
            if (cVar1 != cVar2) {
                if ((uint8_t)(cVar1 + 0xbfU) < 0x1a) {
                    cVar1 = cVar1 + ' ';
                }
                if ((uint8_t)(cVar2 + 0xbfU) < 0x1a) {
                    cVar2 = cVar2 + ' ';
                }
                if (cVar1 != cVar2) {
                    return 0;
                }
            }
            arg3 = arg3 + 1;
            uVar3 = uVar3 - 1;
        } while (uVar3 != 0);
    }
    return 1;
}

// ============================================================
// Function: FUN_18023de50
// Address: 0x18023de50
// Size: 104 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.18023de50(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    bool bVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    int64_t in_RDX;
    uint8_t *puVar8;
    undefined8 unaff_RSI;
    uint8_t *arg1;
    uint32_t uVar9;
    uint32_t uVar10;
    char *in_R8;
    uint64_t in_R9;
    undefined8 unaff_R13;
    int64_t arg2;
    int64_t var_8h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18023de67;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar2 = *(uint32_t *)((int64_t)&arg_68h + iVar5);
    if ((in_R9 < 2) || (*in_R8 != '.')) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023de92;
        iVar6 = func_0x00018023e980();
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_R13;
            *(int64_t *)((int64_t)&arg_60h + iVar5) = iVar6 + 1;
            arg2 = iVar6 - in_RCX;
            in_RDX = (in_RCX - iVar6) + -1 + in_RDX;
            uVar9 = 0;
            *(int64_t *)((int64_t)&var_8h + iVar5) = in_RDX;
            bVar3 = false;
            uVar10 = 0;
            if ((uint64_t)(arg2 + in_RDX) <= in_R9) {
                *(uint32_t *)(&stack0xfffffffffffffff8 + iVar5) = uVar2;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023df01;
                iVar4 = fcn.18023dda0(in_RCX, arg2, (int64_t)in_R8, arg2, *(int64_t *)(&stack0xfffffffffffffff8 + iVar5)
                                     );
                uVar10 = uVar9;
                if (iVar4 != 0) {
                    iVar6 = *(int64_t *)((int64_t)&var_8h + iVar5);
                    puVar8 = (uint8_t *)(in_R8 + arg2);
                    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RSI;
                    *(uint32_t *)(&stack0xfffffffffffffff8 + iVar5) = uVar2;
                    arg1 = (uint8_t *)(in_R8 + (in_R9 - iVar6));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023df3b;
                    iVar4 = fcn.18023dda0((int64_t)arg1, iVar6, *(int64_t *)((int64_t)&arg_60h + iVar5), iVar6, 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar5));
                    uVar10 = 0;
                    if (iVar4 != 0) {
                        if ((arg2 == 0) && (**(char **)((int64_t)&arg_60h + iVar5) == '.')) {
                            uVar10 = uVar9;
                            if (puVar8 == arg1) goto code_r0x00018023dfe3;
                            if ((uVar2 & 8) != 0) {
                                bVar3 = true;
                            }
                        } else if (3 < in_R9) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023df87;
                            iVar4 = func_0x0001802237e0(in_R8, 0x1804e307c, 4);
                            uVar10 = uVar9;
                            if (iVar4 == 0) goto code_r0x00018023dfe3;
                        }
                        if ((arg1 != puVar8 + 1) || (*puVar8 != 0x2a)) {
                            for (; puVar8 != arg1; puVar8 = puVar8 + 1) {
                                uVar1 = *puVar8;
                                if (((((uVar1 < 0x30) || (0x39 < uVar1)) &&
                                     ((0x39 < (uint8_t)(uVar1 - 0x41) ||
                                      ((0x3ffffff03ffffffU >> ((uint64_t)(uVar1 - 0x41) & 0x3f) & 1) == 0)))) &&
                                    (uVar1 != 0x2d)) && ((uVar10 = uVar9, !bVar3 || (uVar1 != 0x2e))))
                                goto code_r0x00018023dfe3;
                            }
                        }
                        uVar10 = 1;
                    }
                }
            }
code_r0x00018023dfe3:
            return (uint64_t)uVar10;
        }
    }
    *(uint32_t *)(&stack0xfffffffffffffff8 + iVar5) = uVar2;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023deb0;
    uVar7 = fcn.18023dda0(in_RCX, in_RDX, (int64_t)in_R8, in_R9, *(int64_t *)(&stack0xfffffffffffffff8 + iVar5));
    return uVar7;
}

// ============================================================
// Function: FUN_18023deb8
// Address: 0x18023deb8
// Size: 101 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.18023de50(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    bool bVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    int64_t in_RDX;
    uint8_t *puVar8;
    undefined8 unaff_RSI;
    uint8_t *arg1;
    uint32_t uVar9;
    uint32_t uVar10;
    char *in_R8;
    uint64_t in_R9;
    undefined8 unaff_R13;
    int64_t arg2;
    int64_t var_8h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18023de67;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar2 = *(uint32_t *)((int64_t)&arg_68h + iVar5);
    if ((in_R9 < 2) || (*in_R8 != '.')) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023de92;
        iVar6 = func_0x00018023e980();
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_R13;
            *(int64_t *)((int64_t)&arg_60h + iVar5) = iVar6 + 1;
            arg2 = iVar6 - in_RCX;
            in_RDX = (in_RCX - iVar6) + -1 + in_RDX;
            uVar9 = 0;
            *(int64_t *)((int64_t)&var_8h + iVar5) = in_RDX;
            bVar3 = false;
            uVar10 = 0;
            if ((uint64_t)(arg2 + in_RDX) <= in_R9) {
                *(uint32_t *)(&stack0xfffffffffffffff8 + iVar5) = uVar2;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023df01;
                iVar4 = fcn.18023dda0(in_RCX, arg2, (int64_t)in_R8, arg2, *(int64_t *)(&stack0xfffffffffffffff8 + iVar5)
                                     );
                uVar10 = uVar9;
                if (iVar4 != 0) {
                    iVar6 = *(int64_t *)((int64_t)&var_8h + iVar5);
                    puVar8 = (uint8_t *)(in_R8 + arg2);
                    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RSI;
                    *(uint32_t *)(&stack0xfffffffffffffff8 + iVar5) = uVar2;
                    arg1 = (uint8_t *)(in_R8 + (in_R9 - iVar6));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023df3b;
                    iVar4 = fcn.18023dda0((int64_t)arg1, iVar6, *(int64_t *)((int64_t)&arg_60h + iVar5), iVar6, 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar5));
                    uVar10 = 0;
                    if (iVar4 != 0) {
                        if ((arg2 == 0) && (**(char **)((int64_t)&arg_60h + iVar5) == '.')) {
                            uVar10 = uVar9;
                            if (puVar8 == arg1) goto code_r0x00018023dfe3;
                            if ((uVar2 & 8) != 0) {
                                bVar3 = true;
                            }
                        } else if (3 < in_R9) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023df87;
                            iVar4 = func_0x0001802237e0(in_R8, 0x1804e307c, 4);
                            uVar10 = uVar9;
                            if (iVar4 == 0) goto code_r0x00018023dfe3;
                        }
                        if ((arg1 != puVar8 + 1) || (*puVar8 != 0x2a)) {
                            for (; puVar8 != arg1; puVar8 = puVar8 + 1) {
                                uVar1 = *puVar8;
                                if (((((uVar1 < 0x30) || (0x39 < uVar1)) &&
                                     ((0x39 < (uint8_t)(uVar1 - 0x41) ||
                                      ((0x3ffffff03ffffffU >> ((uint64_t)(uVar1 - 0x41) & 0x3f) & 1) == 0)))) &&
                                    (uVar1 != 0x2d)) && ((uVar10 = uVar9, !bVar3 || (uVar1 != 0x2e))))
                                goto code_r0x00018023dfe3;
                            }
                        }
                        uVar10 = 1;
                    }
                }
            }
code_r0x00018023dfe3:
            return (uint64_t)uVar10;
        }
    }
    *(uint32_t *)(&stack0xfffffffffffffff8 + iVar5) = uVar2;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023deb0;
    uVar7 = fcn.18023dda0(in_RCX, in_RDX, (int64_t)in_R8, in_R9, *(int64_t *)(&stack0xfffffffffffffff8 + iVar5));
    return uVar7;
}

// ============================================================
// Function: FUN_18023df1d
// Address: 0x18023df1d
// Size: 198 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.18023de50(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    bool bVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    int64_t in_RDX;
    uint8_t *puVar8;
    undefined8 unaff_RSI;
    uint8_t *arg1;
    uint32_t uVar9;
    uint32_t uVar10;
    char *in_R8;
    uint64_t in_R9;
    undefined8 unaff_R13;
    int64_t arg2;
    int64_t var_8h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18023de67;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar2 = *(uint32_t *)((int64_t)&arg_68h + iVar5);
    if ((in_R9 < 2) || (*in_R8 != '.')) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023de92;
        iVar6 = func_0x00018023e980();
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_R13;
            *(int64_t *)((int64_t)&arg_60h + iVar5) = iVar6 + 1;
            arg2 = iVar6 - in_RCX;
            in_RDX = (in_RCX - iVar6) + -1 + in_RDX;
            uVar9 = 0;
            *(int64_t *)((int64_t)&var_8h + iVar5) = in_RDX;
            bVar3 = false;
            uVar10 = 0;
            if ((uint64_t)(arg2 + in_RDX) <= in_R9) {
                *(uint32_t *)(&stack0xfffffffffffffff8 + iVar5) = uVar2;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023df01;
                iVar4 = fcn.18023dda0(in_RCX, arg2, (int64_t)in_R8, arg2, *(int64_t *)(&stack0xfffffffffffffff8 + iVar5)
                                     );
                uVar10 = uVar9;
                if (iVar4 != 0) {
                    iVar6 = *(int64_t *)((int64_t)&var_8h + iVar5);
                    puVar8 = (uint8_t *)(in_R8 + arg2);
                    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RSI;
                    *(uint32_t *)(&stack0xfffffffffffffff8 + iVar5) = uVar2;
                    arg1 = (uint8_t *)(in_R8 + (in_R9 - iVar6));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023df3b;
                    iVar4 = fcn.18023dda0((int64_t)arg1, iVar6, *(int64_t *)((int64_t)&arg_60h + iVar5), iVar6, 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar5));
                    uVar10 = 0;
                    if (iVar4 != 0) {
                        if ((arg2 == 0) && (**(char **)((int64_t)&arg_60h + iVar5) == '.')) {
                            uVar10 = uVar9;
                            if (puVar8 == arg1) goto code_r0x00018023dfe3;
                            if ((uVar2 & 8) != 0) {
                                bVar3 = true;
                            }
                        } else if (3 < in_R9) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023df87;
                            iVar4 = func_0x0001802237e0(in_R8, 0x1804e307c, 4);
                            uVar10 = uVar9;
                            if (iVar4 == 0) goto code_r0x00018023dfe3;
                        }
                        if ((arg1 != puVar8 + 1) || (*puVar8 != 0x2a)) {
                            for (; puVar8 != arg1; puVar8 = puVar8 + 1) {
                                uVar1 = *puVar8;
                                if (((((uVar1 < 0x30) || (0x39 < uVar1)) &&
                                     ((0x39 < (uint8_t)(uVar1 - 0x41) ||
                                      ((0x3ffffff03ffffffU >> ((uint64_t)(uVar1 - 0x41) & 0x3f) & 1) == 0)))) &&
                                    (uVar1 != 0x2d)) && ((uVar10 = uVar9, !bVar3 || (uVar1 != 0x2e))))
                                goto code_r0x00018023dfe3;
                            }
                        }
                        uVar10 = 1;
                    }
                }
            }
code_r0x00018023dfe3:
            return (uint64_t)uVar10;
        }
    }
    *(uint32_t *)(&stack0xfffffffffffffff8 + iVar5) = uVar2;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023deb0;
    uVar7 = fcn.18023dda0(in_RCX, in_RDX, (int64_t)in_R8, in_R9, *(int64_t *)(&stack0xfffffffffffffff8 + iVar5));
    return uVar7;
}

// ============================================================
// Function: FUN_18023dfe3
// Address: 0x18023dfe3
// Size: 7 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.18023de50(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    bool bVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    int64_t in_RDX;
    uint8_t *puVar8;
    undefined8 unaff_RSI;
    uint8_t *arg1;
    uint32_t uVar9;
    uint32_t uVar10;
    char *in_R8;
    uint64_t in_R9;
    undefined8 unaff_R13;
    int64_t arg2;
    int64_t var_8h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18023de67;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar2 = *(uint32_t *)((int64_t)&arg_68h + iVar5);
    if ((in_R9 < 2) || (*in_R8 != '.')) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023de92;
        iVar6 = func_0x00018023e980();
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_R13;
            *(int64_t *)((int64_t)&arg_60h + iVar5) = iVar6 + 1;
            arg2 = iVar6 - in_RCX;
            in_RDX = (in_RCX - iVar6) + -1 + in_RDX;
            uVar9 = 0;
            *(int64_t *)((int64_t)&var_8h + iVar5) = in_RDX;
            bVar3 = false;
            uVar10 = 0;
            if ((uint64_t)(arg2 + in_RDX) <= in_R9) {
                *(uint32_t *)(&stack0xfffffffffffffff8 + iVar5) = uVar2;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023df01;
                iVar4 = fcn.18023dda0(in_RCX, arg2, (int64_t)in_R8, arg2, *(int64_t *)(&stack0xfffffffffffffff8 + iVar5)
                                     );
                uVar10 = uVar9;
                if (iVar4 != 0) {
                    iVar6 = *(int64_t *)((int64_t)&var_8h + iVar5);
                    puVar8 = (uint8_t *)(in_R8 + arg2);
                    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RSI;
                    *(uint32_t *)(&stack0xfffffffffffffff8 + iVar5) = uVar2;
                    arg1 = (uint8_t *)(in_R8 + (in_R9 - iVar6));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023df3b;
                    iVar4 = fcn.18023dda0((int64_t)arg1, iVar6, *(int64_t *)((int64_t)&arg_60h + iVar5), iVar6, 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar5));
                    uVar10 = 0;
                    if (iVar4 != 0) {
                        if ((arg2 == 0) && (**(char **)((int64_t)&arg_60h + iVar5) == '.')) {
                            uVar10 = uVar9;
                            if (puVar8 == arg1) goto code_r0x00018023dfe3;
                            if ((uVar2 & 8) != 0) {
                                bVar3 = true;
                            }
                        } else if (3 < in_R9) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023df87;
                            iVar4 = func_0x0001802237e0(in_R8, 0x1804e307c, 4);
                            uVar10 = uVar9;
                            if (iVar4 == 0) goto code_r0x00018023dfe3;
                        }
                        if ((arg1 != puVar8 + 1) || (*puVar8 != 0x2a)) {
                            for (; puVar8 != arg1; puVar8 = puVar8 + 1) {
                                uVar1 = *puVar8;
                                if (((((uVar1 < 0x30) || (0x39 < uVar1)) &&
                                     ((0x39 < (uint8_t)(uVar1 - 0x41) ||
                                      ((0x3ffffff03ffffffU >> ((uint64_t)(uVar1 - 0x41) & 0x3f) & 1) == 0)))) &&
                                    (uVar1 != 0x2d)) && ((uVar10 = uVar9, !bVar3 || (uVar1 != 0x2e))))
                                goto code_r0x00018023dfe3;
                            }
                        }
                        uVar10 = 1;
                    }
                }
            }
code_r0x00018023dfe3:
            return (uint64_t)uVar10;
        }
    }
    *(uint32_t *)(&stack0xfffffffffffffff8 + iVar5) = uVar2;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023deb0;
    uVar7 = fcn.18023dda0(in_RCX, in_RDX, (int64_t)in_R8, in_R9, *(int64_t *)(&stack0xfffffffffffffff8 + iVar5));
    return uVar7;
}

// ============================================================
// Function: FUN_18023dfea
// Address: 0x18023dfea
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.18023de50(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    bool bVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    int64_t in_RDX;
    uint8_t *puVar8;
    undefined8 unaff_RSI;
    uint8_t *arg1;
    uint32_t uVar9;
    uint32_t uVar10;
    char *in_R8;
    uint64_t in_R9;
    undefined8 unaff_R13;
    int64_t arg2;
    int64_t var_8h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18023de67;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar2 = *(uint32_t *)((int64_t)&arg_68h + iVar5);
    if ((in_R9 < 2) || (*in_R8 != '.')) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023de92;
        iVar6 = func_0x00018023e980();
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_R13;
            *(int64_t *)((int64_t)&arg_60h + iVar5) = iVar6 + 1;
            arg2 = iVar6 - in_RCX;
            in_RDX = (in_RCX - iVar6) + -1 + in_RDX;
            uVar9 = 0;
            *(int64_t *)((int64_t)&var_8h + iVar5) = in_RDX;
            bVar3 = false;
            uVar10 = 0;
            if ((uint64_t)(arg2 + in_RDX) <= in_R9) {
                *(uint32_t *)(&stack0xfffffffffffffff8 + iVar5) = uVar2;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023df01;
                iVar4 = fcn.18023dda0(in_RCX, arg2, (int64_t)in_R8, arg2, *(int64_t *)(&stack0xfffffffffffffff8 + iVar5)
                                     );
                uVar10 = uVar9;
                if (iVar4 != 0) {
                    iVar6 = *(int64_t *)((int64_t)&var_8h + iVar5);
                    puVar8 = (uint8_t *)(in_R8 + arg2);
                    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RSI;
                    *(uint32_t *)(&stack0xfffffffffffffff8 + iVar5) = uVar2;
                    arg1 = (uint8_t *)(in_R8 + (in_R9 - iVar6));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023df3b;
                    iVar4 = fcn.18023dda0((int64_t)arg1, iVar6, *(int64_t *)((int64_t)&arg_60h + iVar5), iVar6, 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar5));
                    uVar10 = 0;
                    if (iVar4 != 0) {
                        if ((arg2 == 0) && (**(char **)((int64_t)&arg_60h + iVar5) == '.')) {
                            uVar10 = uVar9;
                            if (puVar8 == arg1) goto code_r0x00018023dfe3;
                            if ((uVar2 & 8) != 0) {
                                bVar3 = true;
                            }
                        } else if (3 < in_R9) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023df87;
                            iVar4 = func_0x0001802237e0(in_R8, 0x1804e307c, 4);
                            uVar10 = uVar9;
                            if (iVar4 == 0) goto code_r0x00018023dfe3;
                        }
                        if ((arg1 != puVar8 + 1) || (*puVar8 != 0x2a)) {
                            for (; puVar8 != arg1; puVar8 = puVar8 + 1) {
                                uVar1 = *puVar8;
                                if (((((uVar1 < 0x30) || (0x39 < uVar1)) &&
                                     ((0x39 < (uint8_t)(uVar1 - 0x41) ||
                                      ((0x3ffffff03ffffffU >> ((uint64_t)(uVar1 - 0x41) & 0x3f) & 1) == 0)))) &&
                                    (uVar1 != 0x2d)) && ((uVar10 = uVar9, !bVar3 || (uVar1 != 0x2e))))
                                goto code_r0x00018023dfe3;
                            }
                        }
                        uVar10 = 1;
                    }
                }
            }
code_r0x00018023dfe3:
            return (uint64_t)uVar10;
        }
    }
    *(uint32_t *)(&stack0xfffffffffffffff8 + iVar5) = uVar2;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023deb0;
    uVar7 = fcn.18023dda0(in_RCX, in_RDX, (int64_t)in_R8, in_R9, *(int64_t *)(&stack0xfffffffffffffff8 + iVar5));
    return uVar7;
}

// ============================================================
// Function: FUN_18023e000
// Address: 0x18023e000
// Size: 144 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18023e000(int64_t arg_28h, int64_t arg_30h)
{
    char *pcVar1;
    char cVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined *in_RCX;
    char **in_RDX;
    uint32_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023e015;
    iVar4 = fcn.18045a350();
    uVar5 = 0;
    cVar2 = **in_RDX;
    *(undefined8 *)((int64_t)&uStack_10 + -iVar4) = 0x18023e02b;
    iVar3 = func_0x000180275480((int32_t)cVar2);
    while( true ) {
        if (iVar3 == 0) {
            return 0;
        }
        uVar5 = (int32_t)**in_RDX + (uVar5 * 5 + -0x18) * 2;
        if (0xff < uVar5) break;
        pcVar1 = *in_RDX + 1;
        *in_RDX = pcVar1;
        cVar2 = *pcVar1;
        if ((cVar2 == '.') || (cVar2 == '\0')) {
            *in_RCX = (char)uVar5;
            return 1;
        }
        if (uVar5 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + -iVar4) = 0x18023e063;
        iVar3 = func_0x000180275480();
    }
    return 0;
}

// ============================================================
// Function: FUN_18023e090
// Address: 0x18023e090
// Size: 175 bytes
// ============================================================
int64_t fcn.18023e090(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023e09c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    iVar3 = 0;
    if (in_RDX == 0) {
        return in_RDX;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023e0be;
    iVar2 = fcn.18025fd50(*(int64_t *)(&stack0x00000040 + iVar1));
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023e0cb;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023e0e3;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023e0f2;
        iVar3 = fcn.18023d9b0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                              *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1));
        if (iVar3 != 0) goto code_r0x00018023e129;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023e0ff;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023e117;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023e129;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
code_r0x00018023e129:
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023e131;
    fcn.180255290(iVar2);
    return iVar3;
}

// ============================================================
// Function: FUN_18023e140
// Address: 0x18023e140
// Size: 175 bytes
// ============================================================
int64_t fcn.18023e140(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023e14c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    iVar3 = 0;
    if (in_RDX == 0) {
        return in_RDX;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023e16e;
    iVar2 = fcn.18025ff60(in_RDX, 0);
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023e17b;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023e193;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023e1a2;
        iVar3 = fcn.18023d9b0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                              *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1));
        if (iVar3 != 0) goto code_r0x00018023e1d9;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023e1af;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023e1c7;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023e1d9;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
code_r0x00018023e1d9:
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023e1e1;
    fcn.180255290(iVar2);
    return iVar3;
}

// ============================================================
// Function: FUN_18023e1f0
// Address: 0x18023e1f0
// Size: 170 bytes
// ============================================================
bool fcn.18023e1f0(undefined8 placeholder_0, int64_t arg2, int64_t arg_30h, int64_t arg_60h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023e200;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023e210;
    iVar1 = fcn.18023e000(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    if ((iVar1 != 0) && (**(char **)((int64_t)&arg_30h + iVar2) == '.')) {
        *(char **)((int64_t)&arg_30h + iVar2) = *(char **)((int64_t)&arg_30h + iVar2) + 1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023e234;
        iVar1 = fcn.18023e000(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
        if ((iVar1 != 0) && (**(char **)((int64_t)&arg_30h + iVar2) == '.')) {
            *(char **)((int64_t)&arg_30h + iVar2) = *(char **)((int64_t)&arg_30h + iVar2) + 1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023e258;
            iVar1 = fcn.18023e000(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            if ((iVar1 != 0) && (**(char **)((int64_t)&arg_30h + iVar2) == '.')) {
                *(char **)((int64_t)&arg_30h + iVar2) = *(char **)((int64_t)&arg_30h + iVar2) + 1;
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023e27c;
                iVar1 = fcn.18023e000(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
                if (iVar1 != 0) {
                    return **(char **)((int64_t)&arg_30h + iVar2) == '\0';
                }
            }
        }
    }
    return false;
}

// ============================================================
// Function: FUN_18023e2a0
// Address: 0x18023e2a0
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18023e2a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined *in_RCX;
    int64_t iVar4;
    int32_t in_EDX;
    uint32_t uVar5;
    uint32_t uVar6;
    uint64_t uVar7;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023e2c0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar7 = (uint64_t)in_EDX;
    iVar2 = *(int32_t *)(in_R8 + 0x10);
    iVar4 = (int64_t)iVar2;
    if (iVar2 != 0x10) {
        if (in_EDX == 0) {
            if (*(int32_t *)(in_R8 + 0x14) == -1) {
                *(int32_t *)(in_R8 + 0x18) = *(int32_t *)(in_R8 + 0x18) + 1;
                *(int32_t *)(in_R8 + 0x14) = iVar2;
                return 1;
            }
            if (*(int32_t *)(in_R8 + 0x14) == iVar2) {
                *(int32_t *)(in_R8 + 0x18) = *(int32_t *)(in_R8 + 0x18) + 1;
                return 1;
            }
        } else if (in_EDX < 5) {
            uVar5 = 0;
            while( true ) {
                uVar1 = *in_RCX;
                in_RCX = in_RCX + 1;
                uVar6 = (int32_t)uVar7 - 1;
                uVar7 = (uint64_t)uVar6;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023e34f;
                iVar2 = func_0x000180223440(uVar1);
                if (iVar2 < 0) break;
                uVar5 = uVar5 << 4 | (int32_t)(char)iVar2;
                if (uVar6 == 0) {
                    *(char *)(iVar4 + 1 + in_R8) = (char)uVar5;
                    *(char *)(iVar4 + in_R8) = (char)(uVar5 >> 8);
                    *(int32_t *)(in_R8 + 0x10) = *(int32_t *)(in_R8 + 0x10) + 2;
                    return 1;
                }
            }
        } else if ((iVar2 < 0xd) && (in_RCX[uVar7] == '\0')) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023e323;
            iVar2 = fcn.18023e1f0(iVar4 + in_R8, (int64_t)in_RCX, *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar3));
            if (iVar2 != 0) {
                *(int32_t *)(in_R8 + 0x10) = *(int32_t *)(in_R8 + 0x10) + 4;
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18023e3a0
// Address: 0x18023e3a0
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Removing arg arg_ach because it doesn't fit into ProtoModel

void fcn.18023e3a0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_78h, int64_t arg_80h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined4 *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023e3b0;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_48h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar7);
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e3d5;
    iVar8 = func_0x00018045b928(in_RDX, 0x3a);
    if (iVar8 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e50c;
        fcn.18023e1f0(in_RCX, in_RDX, *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)(&stack0x00000050 + iVar7));
    } else {
        *(undefined8 *)((int64_t)&arg_78h + iVar7) = unaff_RDI;
        *(undefined4 *)((int64_t)&arg_38h + iVar7) = 0;
        *(undefined4 *)((int64_t)&arg_40h + iVar7) = 0;
        *(undefined4 *)((int64_t)&arg_38h + iVar7 + 4) = 0xffffffff;
        *(int64_t *)((int64_t)&var_18h + iVar7) = (int64_t)&arg_28h + iVar7;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e419;
        iVar6 = func_0x00018024a850(in_RDX, 0x3a, 0, fcn.18023e2a0);
        if (iVar6 != 0) {
            iVar6 = *(int32_t *)((int64_t)&arg_38h + iVar7 + 4);
            if (iVar6 == -1) {
                if (*(int32_t *)((int64_t)&arg_38h + iVar7) != 0x10) goto code_r0x00018023e43c;
            } else {
                iVar1 = *(int32_t *)((int64_t)&arg_38h + iVar7);
                if (iVar1 == 0x10) goto code_r0x00018023e43c;
                iVar2 = *(int32_t *)((int64_t)&arg_40h + iVar7);
                if (3 < iVar2) goto code_r0x00018023e43c;
                if (iVar2 == 3) {
                    if (0 < iVar1) goto code_r0x00018023e43c;
                } else if (iVar2 == 2) {
                    if ((iVar6 != 0) && (iVar6 != iVar1)) goto code_r0x00018023e43c;
                } else if ((iVar6 == 0) || (iVar6 == iVar1)) goto code_r0x00018023e43c;
                if (-1 < iVar6) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e49f;
                    func_0x000180498030(in_RCX, (int64_t)&arg_28h + iVar7, (int64_t)iVar6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e4b4;
                    fcn.1804986e0((int64_t)iVar6 + (int64_t)in_RCX, 0, (int64_t)(0x10 - iVar1));
                    iVar6 = *(int32_t *)((int64_t)&arg_38h + iVar7);
                    iVar1 = *(int32_t *)((int64_t)&arg_38h + iVar7 + 4);
                    if (iVar6 != iVar1) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e4e5;
                        func_0x000180498030(((int64_t)iVar1 - (int64_t)iVar6) + 0x10 + (int64_t)in_RCX, 
                                            (int64_t)&arg_28h + iVar1 + iVar7, (int64_t)(iVar6 - iVar1));
                    }
                    goto code_r0x00018023e43c;
                }
            }
            uVar3 = *(undefined4 *)((int64_t)&arg_28h + iVar7 + 4);
            uVar4 = *(undefined4 *)(&stack0x00000030 + iVar7);
            uVar5 = *(undefined4 *)(&stack0x00000034 + iVar7);
            *in_RCX = *(undefined4 *)((int64_t)&arg_28h + iVar7);
            in_RCX[1] = uVar3;
            in_RCX[2] = uVar4;
            in_RCX[3] = uVar5;
        }
    }
code_r0x00018023e43c:
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e449;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_48h + iVar7) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar7));
    return;
}

// ============================================================
// Function: FUN_18023e3e0
// Address: 0x18023e3e0
// Size: 92 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Removing arg arg_ach because it doesn't fit into ProtoModel

void fcn.18023e3a0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_78h, int64_t arg_80h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined4 *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023e3b0;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_48h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar7);
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e3d5;
    iVar8 = func_0x00018045b928(in_RDX, 0x3a);
    if (iVar8 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e50c;
        fcn.18023e1f0(in_RCX, in_RDX, *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)(&stack0x00000050 + iVar7));
    } else {
        *(undefined8 *)((int64_t)&arg_78h + iVar7) = unaff_RDI;
        *(undefined4 *)((int64_t)&arg_38h + iVar7) = 0;
        *(undefined4 *)((int64_t)&arg_40h + iVar7) = 0;
        *(undefined4 *)((int64_t)&arg_38h + iVar7 + 4) = 0xffffffff;
        *(int64_t *)((int64_t)&var_18h + iVar7) = (int64_t)&arg_28h + iVar7;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e419;
        iVar6 = func_0x00018024a850(in_RDX, 0x3a, 0, fcn.18023e2a0);
        if (iVar6 != 0) {
            iVar6 = *(int32_t *)((int64_t)&arg_38h + iVar7 + 4);
            if (iVar6 == -1) {
                if (*(int32_t *)((int64_t)&arg_38h + iVar7) != 0x10) goto code_r0x00018023e43c;
            } else {
                iVar1 = *(int32_t *)((int64_t)&arg_38h + iVar7);
                if (iVar1 == 0x10) goto code_r0x00018023e43c;
                iVar2 = *(int32_t *)((int64_t)&arg_40h + iVar7);
                if (3 < iVar2) goto code_r0x00018023e43c;
                if (iVar2 == 3) {
                    if (0 < iVar1) goto code_r0x00018023e43c;
                } else if (iVar2 == 2) {
                    if ((iVar6 != 0) && (iVar6 != iVar1)) goto code_r0x00018023e43c;
                } else if ((iVar6 == 0) || (iVar6 == iVar1)) goto code_r0x00018023e43c;
                if (-1 < iVar6) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e49f;
                    func_0x000180498030(in_RCX, (int64_t)&arg_28h + iVar7, (int64_t)iVar6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e4b4;
                    fcn.1804986e0((int64_t)iVar6 + (int64_t)in_RCX, 0, (int64_t)(0x10 - iVar1));
                    iVar6 = *(int32_t *)((int64_t)&arg_38h + iVar7);
                    iVar1 = *(int32_t *)((int64_t)&arg_38h + iVar7 + 4);
                    if (iVar6 != iVar1) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e4e5;
                        func_0x000180498030(((int64_t)iVar1 - (int64_t)iVar6) + 0x10 + (int64_t)in_RCX, 
                                            (int64_t)&arg_28h + iVar1 + iVar7, (int64_t)(iVar6 - iVar1));
                    }
                    goto code_r0x00018023e43c;
                }
            }
            uVar3 = *(undefined4 *)((int64_t)&arg_28h + iVar7 + 4);
            uVar4 = *(undefined4 *)(&stack0x00000030 + iVar7);
            uVar5 = *(undefined4 *)(&stack0x00000034 + iVar7);
            *in_RCX = *(undefined4 *)((int64_t)&arg_28h + iVar7);
            in_RCX[1] = uVar3;
            in_RCX[2] = uVar4;
            in_RCX[3] = uVar5;
        }
    }
code_r0x00018023e43c:
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e449;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_48h + iVar7) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar7));
    return;
}

// ============================================================
// Function: FUN_18023e43c
// Address: 0x18023e43c
// Size: 27 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Removing arg arg_ach because it doesn't fit into ProtoModel

void fcn.18023e3a0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_78h, int64_t arg_80h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined4 *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023e3b0;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_48h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar7);
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e3d5;
    iVar8 = func_0x00018045b928(in_RDX, 0x3a);
    if (iVar8 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e50c;
        fcn.18023e1f0(in_RCX, in_RDX, *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)(&stack0x00000050 + iVar7));
    } else {
        *(undefined8 *)((int64_t)&arg_78h + iVar7) = unaff_RDI;
        *(undefined4 *)((int64_t)&arg_38h + iVar7) = 0;
        *(undefined4 *)((int64_t)&arg_40h + iVar7) = 0;
        *(undefined4 *)((int64_t)&arg_38h + iVar7 + 4) = 0xffffffff;
        *(int64_t *)((int64_t)&var_18h + iVar7) = (int64_t)&arg_28h + iVar7;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e419;
        iVar6 = func_0x00018024a850(in_RDX, 0x3a, 0, fcn.18023e2a0);
        if (iVar6 != 0) {
            iVar6 = *(int32_t *)((int64_t)&arg_38h + iVar7 + 4);
            if (iVar6 == -1) {
                if (*(int32_t *)((int64_t)&arg_38h + iVar7) != 0x10) goto code_r0x00018023e43c;
            } else {
                iVar1 = *(int32_t *)((int64_t)&arg_38h + iVar7);
                if (iVar1 == 0x10) goto code_r0x00018023e43c;
                iVar2 = *(int32_t *)((int64_t)&arg_40h + iVar7);
                if (3 < iVar2) goto code_r0x00018023e43c;
                if (iVar2 == 3) {
                    if (0 < iVar1) goto code_r0x00018023e43c;
                } else if (iVar2 == 2) {
                    if ((iVar6 != 0) && (iVar6 != iVar1)) goto code_r0x00018023e43c;
                } else if ((iVar6 == 0) || (iVar6 == iVar1)) goto code_r0x00018023e43c;
                if (-1 < iVar6) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e49f;
                    func_0x000180498030(in_RCX, (int64_t)&arg_28h + iVar7, (int64_t)iVar6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e4b4;
                    fcn.1804986e0((int64_t)iVar6 + (int64_t)in_RCX, 0, (int64_t)(0x10 - iVar1));
                    iVar6 = *(int32_t *)((int64_t)&arg_38h + iVar7);
                    iVar1 = *(int32_t *)((int64_t)&arg_38h + iVar7 + 4);
                    if (iVar6 != iVar1) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e4e5;
                        func_0x000180498030(((int64_t)iVar1 - (int64_t)iVar6) + 0x10 + (int64_t)in_RCX, 
                                            (int64_t)&arg_28h + iVar1 + iVar7, (int64_t)(iVar6 - iVar1));
                    }
                    goto code_r0x00018023e43c;
                }
            }
            uVar3 = *(undefined4 *)((int64_t)&arg_28h + iVar7 + 4);
            uVar4 = *(undefined4 *)(&stack0x00000030 + iVar7);
            uVar5 = *(undefined4 *)(&stack0x00000034 + iVar7);
            *in_RCX = *(undefined4 *)((int64_t)&arg_28h + iVar7);
            in_RCX[1] = uVar3;
            in_RCX[2] = uVar4;
            in_RCX[3] = uVar5;
        }
    }
code_r0x00018023e43c:
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e449;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_48h + iVar7) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar7));
    return;
}

// ============================================================
// Function: FUN_18023e457
// Address: 0x18023e457
// Size: 170 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Removing arg arg_ach because it doesn't fit into ProtoModel

void fcn.18023e3a0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_78h, int64_t arg_80h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined4 *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023e3b0;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_48h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar7);
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e3d5;
    iVar8 = func_0x00018045b928(in_RDX, 0x3a);
    if (iVar8 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e50c;
        fcn.18023e1f0(in_RCX, in_RDX, *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)(&stack0x00000050 + iVar7));
    } else {
        *(undefined8 *)((int64_t)&arg_78h + iVar7) = unaff_RDI;
        *(undefined4 *)((int64_t)&arg_38h + iVar7) = 0;
        *(undefined4 *)((int64_t)&arg_40h + iVar7) = 0;
        *(undefined4 *)((int64_t)&arg_38h + iVar7 + 4) = 0xffffffff;
        *(int64_t *)((int64_t)&var_18h + iVar7) = (int64_t)&arg_28h + iVar7;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e419;
        iVar6 = func_0x00018024a850(in_RDX, 0x3a, 0, fcn.18023e2a0);
        if (iVar6 != 0) {
            iVar6 = *(int32_t *)((int64_t)&arg_38h + iVar7 + 4);
            if (iVar6 == -1) {
                if (*(int32_t *)((int64_t)&arg_38h + iVar7) != 0x10) goto code_r0x00018023e43c;
            } else {
                iVar1 = *(int32_t *)((int64_t)&arg_38h + iVar7);
                if (iVar1 == 0x10) goto code_r0x00018023e43c;
                iVar2 = *(int32_t *)((int64_t)&arg_40h + iVar7);
                if (3 < iVar2) goto code_r0x00018023e43c;
                if (iVar2 == 3) {
                    if (0 < iVar1) goto code_r0x00018023e43c;
                } else if (iVar2 == 2) {
                    if ((iVar6 != 0) && (iVar6 != iVar1)) goto code_r0x00018023e43c;
                } else if ((iVar6 == 0) || (iVar6 == iVar1)) goto code_r0x00018023e43c;
                if (-1 < iVar6) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e49f;
                    func_0x000180498030(in_RCX, (int64_t)&arg_28h + iVar7, (int64_t)iVar6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e4b4;
                    fcn.1804986e0((int64_t)iVar6 + (int64_t)in_RCX, 0, (int64_t)(0x10 - iVar1));
                    iVar6 = *(int32_t *)((int64_t)&arg_38h + iVar7);
                    iVar1 = *(int32_t *)((int64_t)&arg_38h + iVar7 + 4);
                    if (iVar6 != iVar1) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e4e5;
                        func_0x000180498030(((int64_t)iVar1 - (int64_t)iVar6) + 0x10 + (int64_t)in_RCX, 
                                            (int64_t)&arg_28h + iVar1 + iVar7, (int64_t)(iVar6 - iVar1));
                    }
                    goto code_r0x00018023e43c;
                }
            }
            uVar3 = *(undefined4 *)((int64_t)&arg_28h + iVar7 + 4);
            uVar4 = *(undefined4 *)(&stack0x00000030 + iVar7);
            uVar5 = *(undefined4 *)(&stack0x00000034 + iVar7);
            *in_RCX = *(undefined4 *)((int64_t)&arg_28h + iVar7);
            in_RCX[1] = uVar3;
            in_RCX[2] = uVar4;
            in_RCX[3] = uVar5;
        }
    }
code_r0x00018023e43c:
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e449;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_48h + iVar7) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar7));
    return;
}

// ============================================================
// Function: FUN_18023e501
// Address: 0x18023e501
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Removing arg arg_ach because it doesn't fit into ProtoModel

void fcn.18023e3a0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_78h, int64_t arg_80h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined4 *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023e3b0;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_48h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar7);
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e3d5;
    iVar8 = func_0x00018045b928(in_RDX, 0x3a);
    if (iVar8 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e50c;
        fcn.18023e1f0(in_RCX, in_RDX, *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)(&stack0x00000050 + iVar7));
    } else {
        *(undefined8 *)((int64_t)&arg_78h + iVar7) = unaff_RDI;
        *(undefined4 *)((int64_t)&arg_38h + iVar7) = 0;
        *(undefined4 *)((int64_t)&arg_40h + iVar7) = 0;
        *(undefined4 *)((int64_t)&arg_38h + iVar7 + 4) = 0xffffffff;
        *(int64_t *)((int64_t)&var_18h + iVar7) = (int64_t)&arg_28h + iVar7;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e419;
        iVar6 = func_0x00018024a850(in_RDX, 0x3a, 0, fcn.18023e2a0);
        if (iVar6 != 0) {
            iVar6 = *(int32_t *)((int64_t)&arg_38h + iVar7 + 4);
            if (iVar6 == -1) {
                if (*(int32_t *)((int64_t)&arg_38h + iVar7) != 0x10) goto code_r0x00018023e43c;
            } else {
                iVar1 = *(int32_t *)((int64_t)&arg_38h + iVar7);
                if (iVar1 == 0x10) goto code_r0x00018023e43c;
                iVar2 = *(int32_t *)((int64_t)&arg_40h + iVar7);
                if (3 < iVar2) goto code_r0x00018023e43c;
                if (iVar2 == 3) {
                    if (0 < iVar1) goto code_r0x00018023e43c;
                } else if (iVar2 == 2) {
                    if ((iVar6 != 0) && (iVar6 != iVar1)) goto code_r0x00018023e43c;
                } else if ((iVar6 == 0) || (iVar6 == iVar1)) goto code_r0x00018023e43c;
                if (-1 < iVar6) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e49f;
                    func_0x000180498030(in_RCX, (int64_t)&arg_28h + iVar7, (int64_t)iVar6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e4b4;
                    fcn.1804986e0((int64_t)iVar6 + (int64_t)in_RCX, 0, (int64_t)(0x10 - iVar1));
                    iVar6 = *(int32_t *)((int64_t)&arg_38h + iVar7);
                    iVar1 = *(int32_t *)((int64_t)&arg_38h + iVar7 + 4);
                    if (iVar6 != iVar1) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e4e5;
                        func_0x000180498030(((int64_t)iVar1 - (int64_t)iVar6) + 0x10 + (int64_t)in_RCX, 
                                            (int64_t)&arg_28h + iVar1 + iVar7, (int64_t)(iVar6 - iVar1));
                    }
                    goto code_r0x00018023e43c;
                }
            }
            uVar3 = *(undefined4 *)((int64_t)&arg_28h + iVar7 + 4);
            uVar4 = *(undefined4 *)(&stack0x00000030 + iVar7);
            uVar5 = *(undefined4 *)(&stack0x00000034 + iVar7);
            *in_RCX = *(undefined4 *)((int64_t)&arg_28h + iVar7);
            in_RCX[1] = uVar3;
            in_RCX[2] = uVar4;
            in_RCX[3] = uVar5;
        }
    }
code_r0x00018023e43c:
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023e449;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_48h + iVar7) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar7));
    return;
}

// ============================================================
// Function: FUN_18023e520
// Address: 0x18023e520
// Size: 40 bytes
// ============================================================
bool fcn.18023e520(int64_t arg_28h, int64_t arg_58h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023e52c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_R8D == 0) {
        return true;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023e555;
    iVar3 = fcn.180223300(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2));
    if (iVar3 == 0) {
        return false;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023e573;
    iVar1 = fcn.18021a9d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000070 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023e58f;
    fcn.180224990(iVar3, 0x1804e2fa0, 0x5ac);
    return 0 < iVar1;
}

// ============================================================
// Function: FUN_18023e548
// Address: 0x18023e548
// Size: 32 bytes
// ============================================================
bool fcn.18023e520(int64_t arg_28h, int64_t arg_58h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023e52c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_R8D == 0) {
        return true;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023e555;
    iVar3 = fcn.180223300(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2));
    if (iVar3 == 0) {
        return false;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023e573;
    iVar1 = fcn.18021a9d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000070 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023e58f;
    fcn.180224990(iVar3, 0x1804e2fa0, 0x5ac);
    return 0 < iVar1;
}

// ============================================================
// Function: FUN_18023e568
// Address: 0x18023e568
// Size: 52 bytes
// ============================================================
bool fcn.18023e520(int64_t arg_28h, int64_t arg_58h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023e52c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_R8D == 0) {
        return true;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023e555;
    iVar3 = fcn.180223300(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2));
    if (iVar3 == 0) {
        return false;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023e573;
    iVar1 = fcn.18021a9d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000070 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023e58f;
    fcn.180224990(iVar3, 0x1804e2fa0, 0x5ac);
    return 0 < iVar1;
}

// ============================================================
// Function: FUN_18023e5a0
// Address: 0x18023e5a0
// Size: 282 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18023e5a0(int64_t arg_28h, int64_t arg_50h, int64_t arg_58h)
{
    undefined uVar1;
    undefined uVar2;
    uint8_t uVar3;
    uint8_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined *in_RCX;
    uint64_t in_RDX;
    int32_t iVar7;
    int64_t iVar8;
    int32_t iVar9;
    undefined8 uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18023e5b8;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_50h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar6);
    iVar5 = 0;
    if ((int32_t)in_RDX == 4) {
        uVar3 = in_RCX[2];
        uVar4 = in_RCX[1];
        uVar1 = *in_RCX;
        *(uint32_t *)((int64_t)&var_18h + iVar6) = (uint32_t)(uint8_t)in_RCX[3];
        *(uint32_t *)((int64_t)&var_10h + iVar6) = (uint32_t)uVar3;
        *(uint32_t *)((int64_t)&var_8h + iVar6) = (uint32_t)uVar4;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18023e681;
        func_0x000180245f70((int64_t)&arg_28h + iVar6, 0x28, 0x1804e3088, uVar1);
    } else if ((int32_t)in_RDX == 0x10) {
        iVar8 = (int64_t)&arg_28h + iVar6;
        iVar7 = 8;
        iVar9 = 0x28;
        do {
            iVar7 = iVar7 + -1;
            if (iVar5 < 0) break;
            uVar1 = *in_RCX;
            uVar10 = 0x1804e3098;
            uVar2 = in_RCX[1];
            if (0 < iVar7) {
                uVar10 = 0x1804e3094;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18023e63d;
            iVar5 = func_0x000180245f70(iVar8, (int64_t)iVar9, uVar10, CONCAT11(uVar1, uVar2));
            in_RCX = in_RCX + 2;
            iVar8 = iVar8 + iVar5;
            iVar9 = iVar9 - iVar5;
        } while (0 < iVar7);
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18023e5f2;
        func_0x000180245f70((int64_t)&arg_28h + iVar6, 0x28, 0x1804e30a0, in_RDX & 0xffffffff);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18023e698;
    func_0x0001802231e0((int64_t)&arg_28h + iVar6, 0x1804e2fa0, 0x446);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18023e6a5;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_50h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_18023e6c0
// Address: 0x18023e6c0
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint32_t fcn.18023e6c0(int64_t arg_28h, int64_t arg_30h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023e6d5;
    iVar2 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x18023e6e6;
    iVar3 = fcn.180498cd0(in_RDX);
    *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x18023e6f7;
    uVar1 = fcn.180498f90(in_RCX, in_RDX, iVar3);
    if ((uVar1 == 0) && (*(char *)(iVar3 + in_RCX) != '\0')) {
        uVar1 = (uint32_t)(*(char *)(iVar3 + in_RCX) != '.');
    }
    return uVar1;
}

// ============================================================
// Function: FUN_18023e720
// Address: 0x18023e720
// Size: 443 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_27h

int64_t fcn.18023e720(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    char cVar1;
    char cVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    char *in_RDX;
    undefined8 unaff_RBX;
    char *pcVar6;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    bool bVar7;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023e72c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX == (char *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023e73c;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023e754;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023e766;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023e773;
    iVar5 = fcn.1802554c0();
    *(int64_t *)((int64_t)&arg_30h + iVar4) = iVar5;
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RSI;
        cVar1 = *in_RDX;
        cVar2 = cVar1;
        if (cVar1 == '-') {
            cVar2 = in_RDX[1];
        }
        pcVar6 = in_RDX + 1;
        if (cVar1 != '-') {
            pcVar6 = in_RDX;
        }
        bVar7 = cVar1 == '-';
        if ((cVar2 == '0') && ((pcVar6[1] + 0xa8U & 0xdf) == 0)) {
            pcVar6 = pcVar6 + 2;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023e809;
            iVar3 = fcn.180298170(*(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4));
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023e818;
            iVar3 = fcn.180297fc0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4));
        }
        if ((iVar3 == 0) || (pcVar6[iVar3] != '\0')) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023e895;
            fcn.180255290(*(undefined8 *)((int64_t)&arg_30h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023e89a;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023e8b2;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
        } else {
            if (cVar1 == '-') {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023e834;
                iVar3 = fcn.1802553f0(*(undefined8 *)((int64_t)&arg_30h + iVar4));
                if (iVar3 != 0) {
                    bVar7 = false;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023e845;
            iVar5 = fcn.18025ff80(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                                  *(int64_t *)(&stack0x00000050 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023e852;
            fcn.180255290(*(undefined8 *)((int64_t)&arg_30h + iVar4));
            if (iVar5 != 0) {
                if (!bVar7) {
                    return iVar5;
                }
                *(uint32_t *)(iVar5 + 4) = *(uint32_t *)(iVar5 + 4) | 0x100;
                return iVar5;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023e85c;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023e874;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023e8c4;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023e782;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023e79a;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                  *(int64_t *)(&stack0x00000048 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023e7ac;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_18023e8e0
// Address: 0x18023e8e0
// Size: 156 bytes
// ============================================================
char * fcn.18023e8e0(int64_t arg_28h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    char *in_RCX;
    undefined8 unaff_RDI;
    char *pcVar5;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023e8ec;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    cVar1 = *in_RCX;
    if (cVar1 == '\0') {
code_r0x00018023e924:
        if (*in_RCX != '\0') {
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023e936;
            iVar4 = fcn.180498cd0(in_RCX);
            pcVar5 = in_RCX + iVar4 + -1;
            do {
                if (pcVar5 == in_RCX) {
code_r0x00018023e966:
                    if (*in_RCX == '\0') {
                        in_RCX = (char *)0x0;
                    }
                    return in_RCX;
                }
                cVar1 = *pcVar5;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023e94f;
                iVar2 = func_0x000180275490((int32_t)cVar1, 8);
                if (iVar2 == 0) {
                    if (in_RCX != pcVar5) {
                        pcVar5[1] = '\0';
                    }
                    goto code_r0x00018023e966;
                }
                pcVar5 = pcVar5 + -1;
            } while( true );
        }
    } else {
        do {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023e90d;
            iVar2 = func_0x000180275490((int32_t)cVar1, 8);
            if (iVar2 == 0) goto code_r0x00018023e924;
            cVar1 = in_RCX[1];
            in_RCX = in_RCX + 1;
        } while (cVar1 != '\0');
    }
    return (char *)0x0;
}

// ============================================================
// Function: FUN_18023e980
// Address: 0x18023e980
// Size: 358 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

char * fcn.18023e980(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    char cVar1;
    bool bVar2;
    bool bVar3;
    int32_t iVar4;
    int64_t iVar5;
    char *in_RCX;
    uint64_t in_RDX;
    uint32_t uVar6;
    char *pcVar7;
    char *pcVar8;
    char *pcVar9;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18023e9a2;
    iVar5 = fcn.18045a350();
    pcVar7 = (char *)0x0;
    uVar6 = 1;
    bVar2 = false;
    if (in_RDX != 0) {
        pcVar8 = pcVar7;
        pcVar9 = in_RCX;
        do {
            cVar1 = *pcVar9;
            if (cVar1 == '*') {
                if ((-(int64_t)in_RCX + (int64_t)pcVar9 == in_RDX - 1) || (bVar3 = false, pcVar9[1] == '.')) {
                    bVar3 = true;
                }
                if (pcVar8 != (char *)0x0) {
                    return (char *)0x0;
                }
                if (bVar2) {
                    return (char *)0x0;
                }
                if ((int32_t)pcVar7 != 0) {
                    return (char *)0x0;
                }
                if ((in_R8 & 4) != 0) {
                    if ((uVar6 & 1) == 0) {
                        return (char *)0x0;
                    }
                    if (!bVar3) {
                        return (char *)0x0;
                    }
                }
                if (((uVar6 & 1) == 0) && (!bVar3)) {
                    return (char *)0x0;
                }
                uVar6 = uVar6 & 0xfffffffe;
                pcVar8 = pcVar9;
            } else if ((((uint8_t)(cVar1 + 0x9fU) < 0x1a) || ((uint8_t)(cVar1 + 0xbfU) < 0x1a)) ||
                      ((uint8_t)(cVar1 - 0x30U) < 10)) {
                if (((uVar6 & 1) != 0) && ((char *)0x3 < in_RCX + (in_RDX - (int64_t)pcVar9))) {
                    *(undefined8 *)((int64_t)&uStack_30 - iVar5) = 0x18023ea9c;
                    iVar4 = func_0x0001802237e0(pcVar9, 0x1804e307c, 4);
                    if (iVar4 == 0) {
                        bVar2 = true;
                    }
                }
                uVar6 = 0;
            } else if (cVar1 == '.') {
                if (uVar6 != 0) {
                    return (char *)0x0;
                }
                uVar6 = 1;
                bVar2 = false;
                pcVar7 = (char *)(uint64_t)((int32_t)pcVar7 + 1);
            } else {
                if (cVar1 != '-') {
                    return (char *)0x0;
                }
                if ((uVar6 & 1) != 0) {
                    return (char *)0x0;
                }
                uVar6 = uVar6 | 4;
            }
            pcVar9 = pcVar9 + 1;
        } while ((uint64_t)(-(int64_t)in_RCX + (int64_t)pcVar9) < in_RDX);
        if (uVar6 == 0) {
            if (1 < (int32_t)pcVar7) {
                return pcVar8;
            }
            return (char *)0x0;
        }
    }
    return (char *)0x0;
}

// ============================================================
// Function: FUN_18023eaf0
// Address: 0x18023eaf0
// Size: 408 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18023eaf0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 in_R8;
    int64_t *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18023eb14;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar1 = *in_R9;
    puVar7 = (undefined8 *)0x0;
    iVar4 = 0;
    iVar6 = 0;
    if (in_RCX == 0) {
code_r0x00018023eb4e:
        if (in_RDX != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023eb60;
            iVar5 = func_0x000180498a80(in_RDX, 0, in_R8);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023eb81;
                iVar6 = func_0x000180223270(in_RDX, in_R8, 0x1804e2fa0, 0x35);
                if (iVar6 != 0) goto code_r0x00018023eb8d;
            }
            goto code_r0x00018023ec14;
        }
code_r0x00018023eb8d:
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023eba4;
        puVar7 = (undefined8 *)
                 fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
        if (puVar7 == (undefined8 *)0x0) goto code_r0x00018023ec14;
        if (iVar1 != 0) {
code_r0x00018023ebef:
            *puVar7 = 0;
            puVar7[1] = iVar4;
            puVar7[2] = iVar6;
            iVar5 = *in_R9;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023ec09;
            iVar2 = func_0x000180222110(iVar5, puVar7);
            if (iVar2 != 0) {
                return 1;
            }
            goto code_r0x00018023ec14;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023ebb6;
        iVar5 = func_0x000180221f20();
        *in_R9 = iVar5;
        if (iVar5 != 0) goto code_r0x00018023ebef;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023ebc3;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023ebdb;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                      *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)((int64_t)&arg_38h + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023ebed;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar3));
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023eb42;
        iVar4 = func_0x0001802231e0();
        if (iVar4 != 0) goto code_r0x00018023eb4e;
code_r0x00018023ec14:
        if (iVar1 != 0) goto code_r0x00018023ec28;
    }
    iVar1 = *in_R9;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023ec21;
    func_0x000180221d50(iVar1);
    *in_R9 = 0;
code_r0x00018023ec28:
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023ec3d;
    fcn.180224990(puVar7, 0x1804e2fa0, 0x4a);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023ec52;
    fcn.180224990(iVar4, 0x1804e2fa0, 0x4b);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023ec67;
    fcn.180224990(iVar6, 0x1804e2fa0, 0x4c);
    return 0;
}

// ============================================================
// Function: FUN_18023ec90
// Address: 0x18023ec90
// Size: 22 bytes
// ============================================================
undefined8 fcn.18023ec90(int64_t param_1, int64_t param_2, undefined8 param_3, int64_t *param_4)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    int64_t iVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 auStackX_8 [4];
    
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(undefined8 *)(&stack0x00000030 + iVar8) = unaff_RBX;
    *(undefined8 *)(&stack0x00000038 + iVar8) = unaff_RBP;
    *(undefined8 *)(&stack0x00000040 + iVar8) = unaff_RSI;
    *(undefined8 *)(&stack0x00000048 + iVar8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + 0x18) = unaff_R12;
    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + 0x10) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_8 + iVar8) = 0x18023eb14;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar1 = *param_4;
    puVar7 = (undefined8 *)0x0;
    iVar4 = 0;
    iVar6 = 0;
    if (param_1 == 0) {
code_r0x00018023eb4e:
        if (param_2 != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar8) = 0x18023eb60;
            iVar5 = func_0x000180498a80(param_2, 0, param_3);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar8) = 0x18023eb81;
                iVar6 = func_0x000180223270(param_2, param_3, 0x1804e2fa0, 0x35);
                if (iVar6 != 0) goto code_r0x00018023eb8d;
            }
            goto code_r0x00018023ec14;
        }
code_r0x00018023eb8d:
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar8) = 0x18023eba4;
        puVar7 = (undefined8 *)
                 fcn.1802248d0(*(int64_t *)(&stack0x00000030 + iVar3 + iVar8), 
                               *(int64_t *)(&stack0x00000038 + iVar3 + iVar8));
        if (puVar7 == (undefined8 *)0x0) goto code_r0x00018023ec14;
        if (iVar1 != 0) {
code_r0x00018023ebef:
            *puVar7 = 0;
            puVar7[1] = iVar4;
            puVar7[2] = iVar6;
            iVar5 = *param_4;
            *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar8) = 0x18023ec09;
            iVar2 = func_0x000180222110(iVar5, puVar7);
            if (iVar2 != 0) {
                return 1;
            }
            goto code_r0x00018023ec14;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar8) = 0x18023ebb6;
        iVar5 = func_0x000180221f20();
        *param_4 = iVar5;
        if (iVar5 != 0) goto code_r0x00018023ebef;
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar8) = 0x18023ebc3;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar3 + iVar8), *(int64_t *)(&stack0x00000038 + iVar3 + iVar8));
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar8) = 0x18023ebdb;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar3 + iVar8), *(int64_t *)(&stack0x00000038 + iVar3 + iVar8), 
                      *(int64_t *)(&stack0x00000040 + iVar3 + iVar8), *(int64_t *)(&stack0x00000048 + iVar3 + iVar8), 
                      *(int64_t *)(&stack0x00000060 + iVar3 + iVar8));
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar8) = 0x18023ebed;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar8));
    } else {
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar8) = 0x18023eb42;
        iVar4 = func_0x0001802231e0();
        if (iVar4 != 0) goto code_r0x00018023eb4e;
code_r0x00018023ec14:
        if (iVar1 != 0) goto code_r0x00018023ec28;
    }
    iVar1 = *param_4;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar8) = 0x18023ec21;
    func_0x000180221d50(iVar1);
    *param_4 = 0;
code_r0x00018023ec28:
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar8) = 0x18023ec3d;
    fcn.180224990(puVar7, 0x1804e2fa0, 0x4a);
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar8) = 0x18023ec52;
    fcn.180224990(iVar4, 0x1804e2fa0, 0x4b);
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar8) = 0x18023ec67;
    fcn.180224990(iVar6, 0x1804e2fa0, 0x4c);
    return 0;
}

// ============================================================
// Function: FUN_18023ecb0
// Address: 0x18023ecb0
// Size: 488 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.18023ecb0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 in_RCX;
    int64_t in_RDX;
    bool bVar3;
    int32_t in_R8D;
    int32_t in_R9D;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x18023ecc8;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023ece6;
    func_0x000180467bd4((int64_t)&iStackX_10 + iVar2 + -8);
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023ecee;
    iVar1 = func_0x0001802ae720(in_RCX);
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023ecf7;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar2));
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023ed0f;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar2), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                      *(int64_t *)((int64_t)&arg_38h + iVar2));
code_r0x00018023edac:
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023edb9;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar2));
        bVar3 = false;
    } else {
        *(int64_t *)((int64_t)&arg_40h + iVar2) = *(int64_t *)((int64_t)&iStackX_10 + iVar2 + -8) + (int64_t)in_R8D;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023ed33;
        iVar1 = func_0x00018024c3a0(in_RCX, (int64_t)&arg_40h + iVar2);
        bVar3 = iVar1 < 1;
        if (!bVar3) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023ed3c;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar2));
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023ed54;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar2), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                          *(int64_t *)((int64_t)&arg_38h + iVar2));
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023ed66;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar2));
        }
        if (-1 < in_R9D) {
            *(int64_t *)((int64_t)&arg_40h + iVar2) = *(int64_t *)((int64_t)&iStackX_10 + iVar2 + -8) - (int64_t)in_R9D;
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023ed86;
            iVar1 = func_0x00018024c3a0(in_RCX, (int64_t)&arg_40h + iVar2);
            if (iVar1 < 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023ed8f;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar2 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar2));
                *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023eda7;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar2 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar2), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)((int64_t)&arg_38h + iVar2));
                goto code_r0x00018023edac;
            }
        }
    }
    if (in_RDX == 0) {
        return bVar3;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023edcc;
    iVar1 = func_0x0001802ae720(in_RDX);
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023edd5;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar2));
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023eded;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar2), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                      *(int64_t *)((int64_t)&arg_38h + iVar2));
    } else {
        *(int64_t *)((int64_t)&arg_40h + iVar2) = *(int64_t *)((int64_t)&iStackX_10 + iVar2 + -8) - (int64_t)in_R8D;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023ee0e;
        iVar1 = func_0x00018024c3a0(in_RDX, (int64_t)&arg_40h + iVar2);
        if (-1 < iVar1) goto code_r0x00018023ee43;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023ee17;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar2));
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023ee2f;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar2), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                      *(int64_t *)((int64_t)&arg_38h + iVar2));
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023ee41;
    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar2));
    bVar3 = false;
code_r0x00018023ee43:
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023ee4e;
    iVar1 = func_0x000180296530(in_RDX, in_RCX);
    if (iVar1 < 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023ee57;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar2));
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023ee6f;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar2), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                      *(int64_t *)((int64_t)&arg_38h + iVar2));
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023ee81;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar2));
        bVar3 = false;
    }
    return bVar3;
}

// ============================================================
// Function: FUN_18023eea0
// Address: 0x18023eea0
// Size: 41 bytes
// ============================================================
undefined4 fcn.18023eea0(int64_t param_1)
{
    undefined4 uVar1;
    
    fcn.18045a350();
    if (param_1 == 0) {
        return 0xffffffff;
    }
    uVar1 = 0xffffffff;
    if (*(undefined4 **)(param_1 + 0x20) != (undefined4 *)0x0) {
        uVar1 = **(undefined4 **)(param_1 + 0x20);
    }
    return uVar1;
}

// ============================================================
// Function: FUN_18023eed0
// Address: 0x18023eed0
// Size: 278 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8
fcn.18023eed0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    int64_t iVar7;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t iVar8;
    int32_t *in_R8;
    undefined4 *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18023eeee;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX != 0) {
        uVar1 = *(undefined8 *)(in_RCX + 0x20);
        iVar8 = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18023ef10;
        iVar3 = fcn.180222010(uVar1);
        if (0 < iVar3) {
            do {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18023ef1e;
                puVar6 = (undefined8 *)fcn.180222340(uVar1, iVar8);
                uVar2 = *puVar6;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18023ef29;
                iVar3 = func_0x0001802aec30(in_RDX, uVar2);
                if (iVar3 == 0) {
                    if (iVar8 < 0) {
                        return 0;
                    }
                    uVar1 = *(undefined8 *)(in_RCX + 0x20);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18023ef65;
                    iVar7 = fcn.180222340(uVar1, iVar8);
                    if (iVar7 == 0) {
                        iVar3 = -1;
                    } else {
                        iVar3 = **(int32_t **)(iVar7 + 8);
                        if (iVar3 == 1) {
                            puVar6 = *(undefined8 **)(*(int32_t **)(iVar7 + 8) + 2);
                            if (*(undefined8 **)((int64_t)&arg_48h + iVar5) != (undefined8 *)0x0) {
                                **(undefined8 **)((int64_t)&arg_48h + iVar5) = *puVar6;
                            }
                            if (in_R9 != (undefined4 *)0x0) {
                                if (puVar6[1] == 0) {
                                    *in_R9 = 0xffffffff;
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18023efa6;
                                    uVar4 = func_0x00018025fcd0();
                                    *in_R9 = uVar4;
                                }
                            }
                        }
                        if (*(undefined8 **)((int64_t)&arg_50h + iVar5) != (undefined8 *)0x0) {
                            **(undefined8 **)((int64_t)&arg_50h + iVar5) = *(undefined8 *)(iVar7 + 0x10);
                        }
                        if (*(undefined8 **)((int64_t)&arg_58h + iVar5) != (undefined8 *)0x0) {
                            **(undefined8 **)((int64_t)&arg_58h + iVar5) = *(undefined8 *)(iVar7 + 0x18);
                        }
                    }
                    if (in_R8 != (int32_t *)0x0) {
                        *in_R8 = iVar3;
                    }
                    return 1;
                }
                iVar8 = iVar8 + 1;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18023ef37;
                iVar3 = fcn.180222010(uVar1);
            } while (iVar8 < iVar3);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18023eff0
// Address: 0x18023eff0
// Size: 38 bytes
// ============================================================
undefined8 fcn.18023eff0(int64_t param_1, int32_t param_2)
{
    int32_t *piVar1;
    
    fcn.18045a350();
    if (param_1 == 0) {
        return 0;
    }
    piVar1 = *(int32_t **)(param_1 + 0x20);
    if (((piVar1 != (int32_t *)0x0) && (-1 < param_2)) && (param_2 < *piVar1)) {
        return *(undefined8 *)(*(int64_t *)(piVar1 + 2) + (int64_t)param_2 * 8);
    }
    return 0;
}

// ============================================================
// Function: FUN_18023f020
// Address: 0x18023f020
// Size: 174 bytes
// ============================================================
int64_t fcn.18023f020(int64_t arg_48h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023f02c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar5 = *(int64_t *)(in_RCX + 8);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023f03d;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar2 + 8), *(int64_t *)((int64_t)aiStackX_10 + iVar2 + 0x10))
        ;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023f055;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar2 + 8), *(int64_t *)((int64_t)aiStackX_10 + iVar2 + 0x10)
                      , *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)((int64_t)&arg_48h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023f067;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023f077;
    iVar1 = fcn.18022cd20(*(int64_t *)((int64_t)aiStackX_10 + iVar2 + 0x10), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                          *(int64_t *)((int64_t)&arg_48h + iVar2), *(int64_t *)(&stack0x00000060 + iVar2));
    if (iVar1 != 0x16d) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023f083;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar2 + 8), *(int64_t *)((int64_t)aiStackX_10 + iVar2 + 0x10))
        ;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023f09b;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar2 + 8), *(int64_t *)((int64_t)aiStackX_10 + iVar2 + 0x10)
                      , *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)((int64_t)&arg_48h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023f0ad;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    iVar5 = *(int64_t *)(iVar5 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023f0be;
    uVar3 = fcn.18023f1b0();
    *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + 8) = *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + 8);
    *(undefined8 *)((int64_t)aiStackX_10 + iVar2) = 0x1802ae95c;
    iVar4 = fcn.18045a350(iVar5, uVar3);
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_48h + iVar4 + iVar2) = *(undefined8 *)(iVar5 + 8);
    *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + iVar2) = 0x1802ae97a;
    iVar5 = fcn.180261770(*(int64_t *)(&stack0x00000038 + iVar4 + iVar2), *(int64_t *)(&stack0x00000040 + iVar4 + iVar2)
                          , *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar2), 
                          *(int64_t *)(&stack0x00000058 + iVar4 + iVar2), *(int64_t *)(&stack0x00000060 + iVar4 + iVar2)
                          , *(int64_t *)(&stack0x00000078 + iVar4 + iVar2));
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + iVar2) = 0x1802ae987;
        fcn.180229480(*(int64_t *)(&stack0x00000038 + iVar4 + iVar2), *(int64_t *)(&stack0x00000040 + iVar4 + iVar2));
        *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + iVar2) = 0x1802ae99f;
        fcn.1802295a0(*(int64_t *)(&stack0x00000038 + iVar4 + iVar2), *(int64_t *)(&stack0x00000040 + iVar4 + iVar2), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar2), *(int64_t *)(&stack0x00000050 + iVar4 + iVar2), 
                      *(int64_t *)(&stack0x00000068 + iVar4 + iVar2));
        *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + iVar2) = 0x1802ae9b1;
        fcn.1802296d0(*(int64_t *)(&stack0x00000058 + iVar4 + iVar2));
    }
    return iVar5;
}

// ============================================================
// Function: FUN_18023f0d0
// Address: 0x18023f0d0
// Size: 25 bytes
// ============================================================
int64_t fcn.18023f0d0(int64_t arg_58h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t **in_RCX;
    int32_t *piVar4;
    undefined8 uStackX_20;
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    piVar4 = *in_RCX;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2) = 0x18025fcda;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (piVar4 == (int32_t *)0x0) {
        return 0;
    }
    if (((piVar4[1] & 0xfffffeffU) == 10) && (*piVar4 < 5)) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18025fd0a;
        iVar1 = fcn.180260030((int64_t)&arg_58h + iVar3 + iVar2, piVar4, 10);
        if ((iVar1 != 0) && (iVar2 = *(int64_t *)((int64_t)&arg_58h + iVar3 + iVar2), iVar2 + 0x80000000U < 0x100000000)
           ) {
            return iVar2;
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18023f190
// Address: 0x18023f190
// Size: 29 bytes
// ============================================================
void fcn.18023f190(undefined8 param_1)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uStackX_20;
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00000030 + iVar1) = param_1;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar1) = 0x1802612bf;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar1) = 0x1802612cf;
    fcn.1802612e0(*(int64_t *)(&stack0x00000048 + iVar2 + iVar1), *(int64_t *)(&stack0x00000050 + iVar2 + iVar1), 
                  *(int64_t *)(&stack0x00000058 + iVar2 + iVar1), *(int64_t *)(&stack0x00000060 + iVar2 + iVar1));
    return;
}

// ============================================================
// Function: FUN_18023f1c0
// Address: 0x18023f1c0
// Size: 29 bytes
// ============================================================
void fcn.18023f1c0(undefined8 param_1)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uStackX_20;
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00000030 + iVar1) = param_1;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar1) = 0x1802612bf;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar1) = 0x1802612cf;
    fcn.1802612e0(*(int64_t *)(&stack0x00000048 + iVar2 + iVar1), *(int64_t *)(&stack0x00000050 + iVar2 + iVar1), 
                  *(int64_t *)(&stack0x00000058 + iVar2 + iVar1), *(int64_t *)(&stack0x00000060 + iVar2 + iVar1));
    return;
}

// ============================================================
// Function: FUN_18023f1e0
// Address: 0x18023f1e0
// Size: 29 bytes
// ============================================================
undefined8 fcn.18023f1e0(int64_t arg_40h, int64_t arg_68h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined8 uVar4;
    undefined8 auStackX_18 [2];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x180260b4c;
    iVar3 = fcn.18045a350(0x1804e3220);
    iVar3 = -iVar3;
    uVar4 = 0;
    *(undefined8 *)((int64_t)&arg_68h + iVar3 + iVar2) = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar3 + iVar2) = 0;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180260b6e;
    iVar1 = fcn.180260bc0(*(int64_t *)((int64_t)&arg_40h + iVar3 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar3 + iVar2), *(int64_t *)(&stack0x00000050 + iVar3 + iVar2)
                          , *(int64_t *)(&stack0x00000060 + iVar3 + iVar2));
    if (0 < iVar1) {
        uVar4 = *(undefined8 *)((int64_t)&arg_68h + iVar3 + iVar2);
    }
    return uVar4;
}

// ============================================================
// Function: FUN_18023f210
// Address: 0x18023f210
// Size: 29 bytes
// ============================================================
void fcn.18023f210(undefined8 param_1)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uStackX_20;
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00000030 + iVar1) = param_1;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar1) = 0x1802612bf;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar1) = 0x1802612cf;
    fcn.1802612e0(*(int64_t *)(&stack0x00000048 + iVar2 + iVar1), *(int64_t *)(&stack0x00000050 + iVar2 + iVar1), 
                  *(int64_t *)(&stack0x00000058 + iVar2 + iVar1), *(int64_t *)(&stack0x00000060 + iVar2 + iVar1));
    return;
}

// ============================================================
// Function: FUN_18023f230
// Address: 0x18023f230
// Size: 29 bytes
// ============================================================
void fcn.18023f230(undefined8 param_1)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uStackX_20;
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00000030 + iVar1) = param_1;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar1) = 0x1802612bf;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar1) = 0x1802612cf;
    fcn.1802612e0(*(int64_t *)(&stack0x00000048 + iVar2 + iVar1), *(int64_t *)(&stack0x00000050 + iVar2 + iVar1), 
                  *(int64_t *)(&stack0x00000058 + iVar2 + iVar1), *(int64_t *)(&stack0x00000060 + iVar2 + iVar1));
    return;
}

// ============================================================
// Function: FUN_18023f260
// Address: 0x18023f260
// Size: 29 bytes
// ============================================================
void fcn.18023f260(undefined *param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined *puVar4;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar5;
    undefined8 uStackX_8;
    undefined8 auStackX_10 [3];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar5 = 0x1804e3500;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 0x10) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 8) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStackX_8 + iVar2) = 0x18026177e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)(&stack0x00000090 + iVar3 + iVar2) = *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_10 + iVar3 + iVar2;
    *(undefined8 *)(&stack0x00000070 + iVar3 + iVar2) = 0;
    (&stack0x00000078)[iVar3 + iVar2] = 0;
    puVar4 = &stack0x00000070 + iVar3 + iVar2;
    if (param_1 != (undefined *)0x0) {
        puVar4 = param_1;
    }
    if ((puVar4 == (undefined *)0x0) || (iVar5 == 0)) {
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x180261804;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar3 + iVar2), *(int64_t *)(&stack0x00000038 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x18026181c;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar3 + iVar2), *(int64_t *)(&stack0x00000038 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000060 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x18026182e;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
    } else {
        *(undefined8 *)(&stack0x00000060 + iVar3 + iVar2) = 0;
        *(undefined8 *)(&stack0x00000058 + iVar3 + iVar2) = 0;
        *(undefined4 *)(&stack0x00000050 + iVar3 + iVar2) = 0;
        *(undefined **)(&stack0x00000048 + iVar3 + iVar2) = &stack0x00000078 + iVar3 + iVar2;
        (&stack0x00000040)[iVar3 + iVar2] = 0;
        *(undefined4 *)(&stack0x00000038 + iVar3 + iVar2) = 0;
        *(undefined4 *)(&stack0x00000030 + iVar3 + iVar2) = 0xffffffff;
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x1802617e9;
        iVar1 = func_0x0001802629a0(puVar4);
        if (iVar1 < 1) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x1802617f8;
            func_0x000180261290(puVar4, iVar5);
        }
    }
    *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x180261841;
    fcn.180459870(*(uint64_t *)(&stack0x00000090 + iVar3 + iVar2) ^ (int64_t)auStackX_10 + iVar3 + iVar2);
    return;
}

// ============================================================
// Function: FUN_18023f280
// Address: 0x18023f280
// Size: 29 bytes
// ============================================================
void fcn.18023f280(undefined *param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined *puVar4;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar5;
    undefined8 uStackX_8;
    undefined8 auStackX_10 [3];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar5 = 0x1804e3490;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 0x10) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 8) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStackX_8 + iVar2) = 0x18026177e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)(&stack0x00000090 + iVar3 + iVar2) = *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_10 + iVar3 + iVar2;
    *(undefined8 *)(&stack0x00000070 + iVar3 + iVar2) = 0;
    (&stack0x00000078)[iVar3 + iVar2] = 0;
    puVar4 = &stack0x00000070 + iVar3 + iVar2;
    if (param_1 != (undefined *)0x0) {
        puVar4 = param_1;
    }
    if ((puVar4 == (undefined *)0x0) || (iVar5 == 0)) {
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x180261804;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar3 + iVar2), *(int64_t *)(&stack0x00000038 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x18026181c;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar3 + iVar2), *(int64_t *)(&stack0x00000038 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000060 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x18026182e;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
    } else {
        *(undefined8 *)(&stack0x00000060 + iVar3 + iVar2) = 0;
        *(undefined8 *)(&stack0x00000058 + iVar3 + iVar2) = 0;
        *(undefined4 *)(&stack0x00000050 + iVar3 + iVar2) = 0;
        *(undefined **)(&stack0x00000048 + iVar3 + iVar2) = &stack0x00000078 + iVar3 + iVar2;
        (&stack0x00000040)[iVar3 + iVar2] = 0;
        *(undefined4 *)(&stack0x00000038 + iVar3 + iVar2) = 0;
        *(undefined4 *)(&stack0x00000030 + iVar3 + iVar2) = 0xffffffff;
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x1802617e9;
        iVar1 = func_0x0001802629a0(puVar4);
        if (iVar1 < 1) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x1802617f8;
            func_0x000180261290(puVar4, iVar5);
        }
    }
    *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x180261841;
    fcn.180459870(*(uint64_t *)(&stack0x00000090 + iVar3 + iVar2) ^ (int64_t)auStackX_10 + iVar3 + iVar2);
    return;
}

