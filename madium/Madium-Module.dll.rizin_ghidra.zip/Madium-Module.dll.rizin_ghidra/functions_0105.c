// Chunk 105 - 50 functions

// ============================================================
// Function: FUN_18016d9c4
// Address: 0x18016d9c4
// Size: 52 bytes
// ============================================================
void fcn.18016d9c4(int64_t arg1, int64_t arg_28h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_60h,
                  int64_t arg_68h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h)
{
    undefined8 *puVar1;
    code *pcVar2;
    int64_t iVar3;
    char in_AL;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    int64_t *piVar7;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    int64_t unaff_RDI;
    undefined8 *puVar8;
    int64_t unaff_R14;
    undefined8 *puVar9;
    int64_t unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    
    if (in_AL == '\x03') {
        if (*(int64_t *)(*(int64_t *)(arg1 + 0x48) + 0x18) != 0) {
            func_0x000180412b80();
        }
        uVar4 = func_0x000180412c60(**(undefined8 **)(unaff_RBP + 0x48));
        *(undefined8 *)(*(int64_t *)(unaff_RBP + 0x48) + 0x18) = uVar4;
        if (*(char *)(unaff_RBP + 0x40) != '\x03') {
            func_0x000180016af0();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        puVar8 = *(undefined8 **)(unaff_RBP + 0x18);
        puVar1 = *(undefined8 **)(unaff_RBP + 0x20);
        arg_60h = unaff_R15;
        arg_98h = unaff_RDI;
        if (puVar8 != puVar1) {
            puVar9 = puVar8 + 4;
            arg_68h = unaff_R14;
            arg_90h = unaff_RSI;
            do {
                if (*(char *)(puVar8 + 0xe) == '\0') {
                    uVar4 = func_0x000180412740(*(undefined8 *)(*(int64_t *)(unaff_RBP + 0x48) + 0x18));
                    if (puVar8[10] != 0) {
                        piVar7 = puVar8 + 8;
                        if (0xf < (uint64_t)puVar8[0xb]) {
                            piVar7 = (int64_t *)*piVar7;
                        }
                        func_0x000180412e40(uVar4, piVar7);
                    }
                    if (*(char *)((int64_t)puVar8 + 0x71) == '\0') {
                        puVar6 = puVar8;
                        if (0xf < (uint64_t)puVar8[3]) {
                            puVar6 = (undefined8 *)*puVar8;
                        }
                        func_0x000180412d00(uVar4, puVar6);
                        puVar6 = puVar9;
                        if (0xf < (uint64_t)puVar9[3]) {
                            puVar6 = (undefined8 *)*puVar9;
                        }
                        func_0x000180412800(uVar4, puVar6, 0xffffffffffffffff);
                    } else {
                        puVar6 = puVar8;
                        if (0xf < (uint64_t)puVar8[3]) {
                            puVar6 = (undefined8 *)*puVar8;
                        }
                        func_0x000180412d00(uVar4, puVar6);
                        func_0x000180412800(uVar4, puVar8[0xc], puVar8[0xd]);
                        puVar6 = puVar9;
                        if (0xf < (uint64_t)puVar9[3]) {
                            puVar6 = (undefined8 *)*puVar9;
                        }
                        func_0x000180412b10(uVar4, puVar6);
                    }
                } else {
                    func_0x000180171230(puVar8 + 0xf, &var_20h);
                    func_0x000180171240(puVar8 + 0xf, &arg_28h);
                    if (var_20h != arg_28h) {
                        do {
                            iVar3 = var_20h;
                            uVar4 = func_0x000180412740(*(undefined8 *)(*(int64_t *)(unaff_RBP + 0x48) + 0x18));
                            if (puVar8[10] != 0) {
                                piVar7 = puVar8 + 8;
                                if (0xf < (uint64_t)puVar8[0xb]) {
                                    piVar7 = (int64_t *)*piVar7;
                                }
                                func_0x000180412e40(uVar4, piVar7);
                            }
                            iVar5 = iVar3;
                            if (0xf < *(uint64_t *)(iVar3 + 0x18)) {
                                iVar5 = *(int64_t *)iVar3;
                            }
                            func_0x000180412950(uVar4, iVar5);
                            puVar6 = puVar8;
                            if (0xf < (uint64_t)puVar8[3]) {
                                puVar6 = (undefined8 *)*puVar8;
                            }
                            func_0x000180412d00(uVar4, puVar6);
                            if (*(int64_t *)(iVar3 + 0x30) != 0) {
                                piVar7 = (int64_t *)(iVar3 + 0x20);
                                if (0xf < *(uint64_t *)(iVar3 + 0x38)) {
                                    piVar7 = (int64_t *)*piVar7;
                                }
                                func_0x000180412b10(uVar4, piVar7);
                            }
                            var_20h = var_20h + 0x40;
                        } while (var_20h != arg_28h);
                    }
                }
                puVar8 = puVar8 + 0x12;
                puVar9 = puVar9 + 0x12;
            } while (puVar8 != puVar1);
        }
        func_0x0001804166c0(**(undefined8 **)(unaff_RBP + 0x48), 0x281d, (*(undefined8 **)(unaff_RBP + 0x48))[3]);
    }
    func_0x000180459870(arg_50h ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_18016d9f8
// Address: 0x18016d9f8
// Size: 30 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_90h
// WARNING: Variable defined which should be unmapped: arg_98h
// WARNING: Variable defined which should be unmapped: arg_68h
// WARNING: Variable defined which should be unmapped: arg_60h

void fcn.18016d9c4(int64_t arg1, int64_t arg_28h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_60h,
                  int64_t arg_68h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h)
{
    undefined8 *puVar1;
    code *pcVar2;
    int64_t iVar3;
    char in_AL;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    int64_t *piVar7;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    int64_t unaff_RDI;
    undefined8 *puVar8;
    int64_t unaff_R14;
    undefined8 *puVar9;
    int64_t unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    
    if (in_AL == '\x03') {
        if (*(int64_t *)(*(int64_t *)(arg1 + 0x48) + 0x18) != 0) {
            func_0x000180412b80();
        }
        uVar4 = func_0x000180412c60(**(undefined8 **)(unaff_RBP + 0x48));
        *(undefined8 *)(*(int64_t *)(unaff_RBP + 0x48) + 0x18) = uVar4;
        if (*(char *)(unaff_RBP + 0x40) != '\x03') {
            func_0x000180016af0();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        puVar8 = *(undefined8 **)(unaff_RBP + 0x18);
        puVar1 = *(undefined8 **)(unaff_RBP + 0x20);
        arg_60h = unaff_R15;
        arg_98h = unaff_RDI;
        if (puVar8 != puVar1) {
            puVar9 = puVar8 + 4;
            arg_68h = unaff_R14;
            arg_90h = unaff_RSI;
            do {
                if (*(char *)(puVar8 + 0xe) == '\0') {
                    uVar4 = func_0x000180412740(*(undefined8 *)(*(int64_t *)(unaff_RBP + 0x48) + 0x18));
                    if (puVar8[10] != 0) {
                        piVar7 = puVar8 + 8;
                        if (0xf < (uint64_t)puVar8[0xb]) {
                            piVar7 = (int64_t *)*piVar7;
                        }
                        func_0x000180412e40(uVar4, piVar7);
                    }
                    if (*(char *)((int64_t)puVar8 + 0x71) == '\0') {
                        puVar6 = puVar8;
                        if (0xf < (uint64_t)puVar8[3]) {
                            puVar6 = (undefined8 *)*puVar8;
                        }
                        func_0x000180412d00(uVar4, puVar6);
                        puVar6 = puVar9;
                        if (0xf < (uint64_t)puVar9[3]) {
                            puVar6 = (undefined8 *)*puVar9;
                        }
                        func_0x000180412800(uVar4, puVar6, 0xffffffffffffffff);
                    } else {
                        puVar6 = puVar8;
                        if (0xf < (uint64_t)puVar8[3]) {
                            puVar6 = (undefined8 *)*puVar8;
                        }
                        func_0x000180412d00(uVar4, puVar6);
                        func_0x000180412800(uVar4, puVar8[0xc], puVar8[0xd]);
                        puVar6 = puVar9;
                        if (0xf < (uint64_t)puVar9[3]) {
                            puVar6 = (undefined8 *)*puVar9;
                        }
                        func_0x000180412b10(uVar4, puVar6);
                    }
                } else {
                    func_0x000180171230(puVar8 + 0xf, &var_20h);
                    func_0x000180171240(puVar8 + 0xf, &arg_28h);
                    if (var_20h != arg_28h) {
                        do {
                            iVar3 = var_20h;
                            uVar4 = func_0x000180412740(*(undefined8 *)(*(int64_t *)(unaff_RBP + 0x48) + 0x18));
                            if (puVar8[10] != 0) {
                                piVar7 = puVar8 + 8;
                                if (0xf < (uint64_t)puVar8[0xb]) {
                                    piVar7 = (int64_t *)*piVar7;
                                }
                                func_0x000180412e40(uVar4, piVar7);
                            }
                            iVar5 = iVar3;
                            if (0xf < *(uint64_t *)(iVar3 + 0x18)) {
                                iVar5 = *(int64_t *)iVar3;
                            }
                            func_0x000180412950(uVar4, iVar5);
                            puVar6 = puVar8;
                            if (0xf < (uint64_t)puVar8[3]) {
                                puVar6 = (undefined8 *)*puVar8;
                            }
                            func_0x000180412d00(uVar4, puVar6);
                            if (*(int64_t *)(iVar3 + 0x30) != 0) {
                                piVar7 = (int64_t *)(iVar3 + 0x20);
                                if (0xf < *(uint64_t *)(iVar3 + 0x38)) {
                                    piVar7 = (int64_t *)*piVar7;
                                }
                                func_0x000180412b10(uVar4, piVar7);
                            }
                            var_20h = var_20h + 0x40;
                        } while (var_20h != arg_28h);
                    }
                }
                puVar8 = puVar8 + 0x12;
                puVar9 = puVar9 + 0x12;
            } while (puVar8 != puVar1);
        }
        func_0x0001804166c0(**(undefined8 **)(unaff_RBP + 0x48), 0x281d, (*(undefined8 **)(unaff_RBP + 0x48))[3]);
    }
    func_0x000180459870(arg_50h ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_18016da16
// Address: 0x18016da16
// Size: 440 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_90h
// WARNING: Variable defined which should be unmapped: arg_98h
// WARNING: Variable defined which should be unmapped: arg_68h
// WARNING: Variable defined which should be unmapped: arg_60h

void fcn.18016d9c4(int64_t arg1, int64_t arg_28h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_60h,
                  int64_t arg_68h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h)
{
    undefined8 *puVar1;
    code *pcVar2;
    int64_t iVar3;
    char in_AL;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    int64_t *piVar7;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    int64_t unaff_RDI;
    undefined8 *puVar8;
    int64_t unaff_R14;
    undefined8 *puVar9;
    int64_t unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    
    if (in_AL == '\x03') {
        if (*(int64_t *)(*(int64_t *)(arg1 + 0x48) + 0x18) != 0) {
            func_0x000180412b80();
        }
        uVar4 = func_0x000180412c60(**(undefined8 **)(unaff_RBP + 0x48));
        *(undefined8 *)(*(int64_t *)(unaff_RBP + 0x48) + 0x18) = uVar4;
        if (*(char *)(unaff_RBP + 0x40) != '\x03') {
            func_0x000180016af0();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        puVar8 = *(undefined8 **)(unaff_RBP + 0x18);
        puVar1 = *(undefined8 **)(unaff_RBP + 0x20);
        arg_60h = unaff_R15;
        arg_98h = unaff_RDI;
        if (puVar8 != puVar1) {
            puVar9 = puVar8 + 4;
            arg_68h = unaff_R14;
            arg_90h = unaff_RSI;
            do {
                if (*(char *)(puVar8 + 0xe) == '\0') {
                    uVar4 = func_0x000180412740(*(undefined8 *)(*(int64_t *)(unaff_RBP + 0x48) + 0x18));
                    if (puVar8[10] != 0) {
                        piVar7 = puVar8 + 8;
                        if (0xf < (uint64_t)puVar8[0xb]) {
                            piVar7 = (int64_t *)*piVar7;
                        }
                        func_0x000180412e40(uVar4, piVar7);
                    }
                    if (*(char *)((int64_t)puVar8 + 0x71) == '\0') {
                        puVar6 = puVar8;
                        if (0xf < (uint64_t)puVar8[3]) {
                            puVar6 = (undefined8 *)*puVar8;
                        }
                        func_0x000180412d00(uVar4, puVar6);
                        puVar6 = puVar9;
                        if (0xf < (uint64_t)puVar9[3]) {
                            puVar6 = (undefined8 *)*puVar9;
                        }
                        func_0x000180412800(uVar4, puVar6, 0xffffffffffffffff);
                    } else {
                        puVar6 = puVar8;
                        if (0xf < (uint64_t)puVar8[3]) {
                            puVar6 = (undefined8 *)*puVar8;
                        }
                        func_0x000180412d00(uVar4, puVar6);
                        func_0x000180412800(uVar4, puVar8[0xc], puVar8[0xd]);
                        puVar6 = puVar9;
                        if (0xf < (uint64_t)puVar9[3]) {
                            puVar6 = (undefined8 *)*puVar9;
                        }
                        func_0x000180412b10(uVar4, puVar6);
                    }
                } else {
                    func_0x000180171230(puVar8 + 0xf, &var_20h);
                    func_0x000180171240(puVar8 + 0xf, &arg_28h);
                    if (var_20h != arg_28h) {
                        do {
                            iVar3 = var_20h;
                            uVar4 = func_0x000180412740(*(undefined8 *)(*(int64_t *)(unaff_RBP + 0x48) + 0x18));
                            if (puVar8[10] != 0) {
                                piVar7 = puVar8 + 8;
                                if (0xf < (uint64_t)puVar8[0xb]) {
                                    piVar7 = (int64_t *)*piVar7;
                                }
                                func_0x000180412e40(uVar4, piVar7);
                            }
                            iVar5 = iVar3;
                            if (0xf < *(uint64_t *)(iVar3 + 0x18)) {
                                iVar5 = *(int64_t *)iVar3;
                            }
                            func_0x000180412950(uVar4, iVar5);
                            puVar6 = puVar8;
                            if (0xf < (uint64_t)puVar8[3]) {
                                puVar6 = (undefined8 *)*puVar8;
                            }
                            func_0x000180412d00(uVar4, puVar6);
                            if (*(int64_t *)(iVar3 + 0x30) != 0) {
                                piVar7 = (int64_t *)(iVar3 + 0x20);
                                if (0xf < *(uint64_t *)(iVar3 + 0x38)) {
                                    piVar7 = (int64_t *)*piVar7;
                                }
                                func_0x000180412b10(uVar4, piVar7);
                            }
                            var_20h = var_20h + 0x40;
                        } while (var_20h != arg_28h);
                    }
                }
                puVar8 = puVar8 + 0x12;
                puVar9 = puVar9 + 0x12;
            } while (puVar8 != puVar1);
        }
        func_0x0001804166c0(**(undefined8 **)(unaff_RBP + 0x48), 0x281d, (*(undefined8 **)(unaff_RBP + 0x48))[3]);
    }
    func_0x000180459870(arg_50h ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_18016dbce
// Address: 0x18016dbce
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_90h
// WARNING: Variable defined which should be unmapped: arg_98h
// WARNING: Variable defined which should be unmapped: arg_68h
// WARNING: Variable defined which should be unmapped: arg_60h

void fcn.18016d9c4(int64_t arg1, int64_t arg_28h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_60h,
                  int64_t arg_68h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h)
{
    undefined8 *puVar1;
    code *pcVar2;
    int64_t iVar3;
    char in_AL;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    int64_t *piVar7;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    int64_t unaff_RDI;
    undefined8 *puVar8;
    int64_t unaff_R14;
    undefined8 *puVar9;
    int64_t unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    
    if (in_AL == '\x03') {
        if (*(int64_t *)(*(int64_t *)(arg1 + 0x48) + 0x18) != 0) {
            func_0x000180412b80();
        }
        uVar4 = func_0x000180412c60(**(undefined8 **)(unaff_RBP + 0x48));
        *(undefined8 *)(*(int64_t *)(unaff_RBP + 0x48) + 0x18) = uVar4;
        if (*(char *)(unaff_RBP + 0x40) != '\x03') {
            func_0x000180016af0();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        puVar8 = *(undefined8 **)(unaff_RBP + 0x18);
        puVar1 = *(undefined8 **)(unaff_RBP + 0x20);
        arg_60h = unaff_R15;
        arg_98h = unaff_RDI;
        if (puVar8 != puVar1) {
            puVar9 = puVar8 + 4;
            arg_68h = unaff_R14;
            arg_90h = unaff_RSI;
            do {
                if (*(char *)(puVar8 + 0xe) == '\0') {
                    uVar4 = func_0x000180412740(*(undefined8 *)(*(int64_t *)(unaff_RBP + 0x48) + 0x18));
                    if (puVar8[10] != 0) {
                        piVar7 = puVar8 + 8;
                        if (0xf < (uint64_t)puVar8[0xb]) {
                            piVar7 = (int64_t *)*piVar7;
                        }
                        func_0x000180412e40(uVar4, piVar7);
                    }
                    if (*(char *)((int64_t)puVar8 + 0x71) == '\0') {
                        puVar6 = puVar8;
                        if (0xf < (uint64_t)puVar8[3]) {
                            puVar6 = (undefined8 *)*puVar8;
                        }
                        func_0x000180412d00(uVar4, puVar6);
                        puVar6 = puVar9;
                        if (0xf < (uint64_t)puVar9[3]) {
                            puVar6 = (undefined8 *)*puVar9;
                        }
                        func_0x000180412800(uVar4, puVar6, 0xffffffffffffffff);
                    } else {
                        puVar6 = puVar8;
                        if (0xf < (uint64_t)puVar8[3]) {
                            puVar6 = (undefined8 *)*puVar8;
                        }
                        func_0x000180412d00(uVar4, puVar6);
                        func_0x000180412800(uVar4, puVar8[0xc], puVar8[0xd]);
                        puVar6 = puVar9;
                        if (0xf < (uint64_t)puVar9[3]) {
                            puVar6 = (undefined8 *)*puVar9;
                        }
                        func_0x000180412b10(uVar4, puVar6);
                    }
                } else {
                    func_0x000180171230(puVar8 + 0xf, &var_20h);
                    func_0x000180171240(puVar8 + 0xf, &arg_28h);
                    if (var_20h != arg_28h) {
                        do {
                            iVar3 = var_20h;
                            uVar4 = func_0x000180412740(*(undefined8 *)(*(int64_t *)(unaff_RBP + 0x48) + 0x18));
                            if (puVar8[10] != 0) {
                                piVar7 = puVar8 + 8;
                                if (0xf < (uint64_t)puVar8[0xb]) {
                                    piVar7 = (int64_t *)*piVar7;
                                }
                                func_0x000180412e40(uVar4, piVar7);
                            }
                            iVar5 = iVar3;
                            if (0xf < *(uint64_t *)(iVar3 + 0x18)) {
                                iVar5 = *(int64_t *)iVar3;
                            }
                            func_0x000180412950(uVar4, iVar5);
                            puVar6 = puVar8;
                            if (0xf < (uint64_t)puVar8[3]) {
                                puVar6 = (undefined8 *)*puVar8;
                            }
                            func_0x000180412d00(uVar4, puVar6);
                            if (*(int64_t *)(iVar3 + 0x30) != 0) {
                                piVar7 = (int64_t *)(iVar3 + 0x20);
                                if (0xf < *(uint64_t *)(iVar3 + 0x38)) {
                                    piVar7 = (int64_t *)*piVar7;
                                }
                                func_0x000180412b10(uVar4, piVar7);
                            }
                            var_20h = var_20h + 0x40;
                        } while (var_20h != arg_28h);
                    }
                }
                puVar8 = puVar8 + 0x12;
                puVar9 = puVar9 + 0x12;
            } while (puVar8 != puVar1);
        }
        func_0x0001804166c0(**(undefined8 **)(unaff_RBP + 0x48), 0x281d, (*(undefined8 **)(unaff_RBP + 0x48))[3]);
    }
    func_0x000180459870(arg_50h ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_18016dbf5
// Address: 0x18016dbf5
// Size: 6 bytes
// ============================================================
void fcn.18016dbf5(void)
{
    code *pcVar1;
    
    fcn.180016af0();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_18016dbfb
// Address: 0x18016dbfb
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_90h
// WARNING: Variable defined which should be unmapped: arg_98h
// WARNING: Variable defined which should be unmapped: arg_68h
// WARNING: Variable defined which should be unmapped: arg_60h

void fcn.18016d9c4(int64_t arg1, int64_t arg_28h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_60h,
                  int64_t arg_68h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h)
{
    undefined8 *puVar1;
    code *pcVar2;
    int64_t iVar3;
    char in_AL;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    int64_t *piVar7;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    int64_t unaff_RDI;
    undefined8 *puVar8;
    int64_t unaff_R14;
    undefined8 *puVar9;
    int64_t unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    
    if (in_AL == '\x03') {
        if (*(int64_t *)(*(int64_t *)(arg1 + 0x48) + 0x18) != 0) {
            func_0x000180412b80();
        }
        uVar4 = func_0x000180412c60(**(undefined8 **)(unaff_RBP + 0x48));
        *(undefined8 *)(*(int64_t *)(unaff_RBP + 0x48) + 0x18) = uVar4;
        if (*(char *)(unaff_RBP + 0x40) != '\x03') {
            fcn.180016af0();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        puVar8 = *(undefined8 **)(unaff_RBP + 0x18);
        puVar1 = *(undefined8 **)(unaff_RBP + 0x20);
        arg_60h = unaff_R15;
        arg_98h = unaff_RDI;
        if (puVar8 != puVar1) {
            puVar9 = puVar8 + 4;
            arg_68h = unaff_R14;
            arg_90h = unaff_RSI;
            do {
                if (*(char *)(puVar8 + 0xe) == '\0') {
                    uVar4 = func_0x000180412740(*(undefined8 *)(*(int64_t *)(unaff_RBP + 0x48) + 0x18));
                    if (puVar8[10] != 0) {
                        piVar7 = puVar8 + 8;
                        if (0xf < (uint64_t)puVar8[0xb]) {
                            piVar7 = (int64_t *)*piVar7;
                        }
                        func_0x000180412e40(uVar4, piVar7);
                    }
                    if (*(char *)((int64_t)puVar8 + 0x71) == '\0') {
                        puVar6 = puVar8;
                        if (0xf < (uint64_t)puVar8[3]) {
                            puVar6 = (undefined8 *)*puVar8;
                        }
                        func_0x000180412d00(uVar4, puVar6);
                        puVar6 = puVar9;
                        if (0xf < (uint64_t)puVar9[3]) {
                            puVar6 = (undefined8 *)*puVar9;
                        }
                        func_0x000180412800(uVar4, puVar6, 0xffffffffffffffff);
                    } else {
                        puVar6 = puVar8;
                        if (0xf < (uint64_t)puVar8[3]) {
                            puVar6 = (undefined8 *)*puVar8;
                        }
                        func_0x000180412d00(uVar4, puVar6);
                        func_0x000180412800(uVar4, puVar8[0xc], puVar8[0xd]);
                        puVar6 = puVar9;
                        if (0xf < (uint64_t)puVar9[3]) {
                            puVar6 = (undefined8 *)*puVar9;
                        }
                        func_0x000180412b10(uVar4, puVar6);
                    }
                } else {
                    func_0x000180171230(puVar8 + 0xf, &var_20h);
                    func_0x000180171240(puVar8 + 0xf, &arg_28h);
                    if (var_20h != arg_28h) {
                        do {
                            iVar3 = var_20h;
                            uVar4 = func_0x000180412740(*(undefined8 *)(*(int64_t *)(unaff_RBP + 0x48) + 0x18));
                            if (puVar8[10] != 0) {
                                piVar7 = puVar8 + 8;
                                if (0xf < (uint64_t)puVar8[0xb]) {
                                    piVar7 = (int64_t *)*piVar7;
                                }
                                func_0x000180412e40(uVar4, piVar7);
                            }
                            iVar5 = iVar3;
                            if (0xf < *(uint64_t *)(iVar3 + 0x18)) {
                                iVar5 = *(int64_t *)iVar3;
                            }
                            func_0x000180412950(uVar4, iVar5);
                            puVar6 = puVar8;
                            if (0xf < (uint64_t)puVar8[3]) {
                                puVar6 = (undefined8 *)*puVar8;
                            }
                            func_0x000180412d00(uVar4, puVar6);
                            if (*(int64_t *)(iVar3 + 0x30) != 0) {
                                piVar7 = (int64_t *)(iVar3 + 0x20);
                                if (0xf < *(uint64_t *)(iVar3 + 0x38)) {
                                    piVar7 = (int64_t *)*piVar7;
                                }
                                func_0x000180412b10(uVar4, piVar7);
                            }
                            var_20h = var_20h + 0x40;
                        } while (var_20h != arg_28h);
                    }
                }
                puVar8 = puVar8 + 0x12;
                puVar9 = puVar9 + 0x12;
            } while (puVar8 != puVar1);
        }
        func_0x0001804166c0(**(undefined8 **)(unaff_RBP + 0x48), 0x281d, (*(undefined8 **)(unaff_RBP + 0x48))[3]);
    }
    func_0x000180459870(arg_50h ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_18016dc10
// Address: 0x18016dc10
// Size: 1580 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_128h

void fcn.18016dc10(int64_t arg1)
{
    uint32_t uVar1;
    code *pcVar2;
    char cVar3;
    undefined8 *puVar4;
    undefined8 uVar5;
    undefined8 *puVar6;
    undefined *puVar7;
    int64_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    undefined *puVar11;
    int64_t *piVar12;
    int64_t **ppiVar13;
    int64_t **ppiVar14;
    undefined8 uStack_170;
    undefined auStack_168 [8];
    undefined auStack_160 [24];
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    undefined var_128h;
    int64_t var_124h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_f8h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t iStack_d0;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_168;
    func_0x00018016d880();
    func_0x00018016e240(arg1);
    func_0x000180171890(arg1 + 0x80, &var_90h, *(undefined8 *)(arg1 + 0x48));
    ppiVar13 = (int64_t **)(arg1 + 0x60);
    if (var_80h == 0) {
        if (0xf < *(uint64_t *)(arg1 + 0x78)) {
            ppiVar13 = (int64_t **)*ppiVar13;
        }
        func_0x0001804166c0(**(undefined8 **)(arg1 + 0x48), 0x2712, ppiVar13);
        goto code_r0x00018016de5d;
    }
    if (*(int64_t *)(arg1 + 0x70) == 0x7fffffffffffffff) {
code_r0x00018016e236:
        func_0x0001800047c0();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    ppiVar14 = ppiVar13;
    if (0xf < *(uint64_t *)(arg1 + 0x78)) {
        ppiVar14 = (int64_t **)*ppiVar13;
    }
    var_138h = 1;
    var_140h = 0x18063d884;
    var_148h = *(int64_t *)(arg1 + 0x70);
    func_0x0001800384c0(&var_d8h, var_128h, ppiVar13, ppiVar14);
    var_118h = var_d8h;
    var_110h = iStack_d0;
    var_68h = var_d8h;
    var_58h = var_c8h;
    var_50h = var_c0h;
    var_70h = 0x1804a56f0;
    if (0x7fffffffffffffffU - var_c8h < (uint64_t)var_80h) {
        func_0x0001800047c0();
        goto code_r0x00018016e236;
    }
    piVar12 = &var_68h;
    if (0xf < (uint64_t)var_c0h) {
        piVar12 = (int64_t *)var_d8h;
    }
    var_140h = (int64_t)&var_90h;
    if (0xf < (uint64_t)var_78h) {
        var_140h = var_90h;
    }
    var_138h = var_80h;
    var_148h = var_c8h;
    func_0x0001800384c0(&var_d8h, var_128h, &var_68h, piVar12);
    var_118h = var_d8h;
    var_110h = iStack_d0;
    var_b0h = var_d8h;
    var_a0h = var_c8h;
    var_98h = var_c0h;
    var_b8h = 0x1804a56f0;
    if ((uint64_t)var_50h < 0x10) {
code_r0x00018016ddd6:
        piVar12 = &var_b0h;
        if (0xf < (uint64_t)var_98h) {
            piVar12 = (int64_t *)var_b0h;
        }
        func_0x0001804166c0(**(undefined8 **)(arg1 + 0x48), 0x2712, piVar12);
        if (0xf < (uint64_t)var_98h) {
            if (var_98h + 1U < 0x1000) {
                func_0x000180459c3c(var_b0h);
            } else {
                puVar11 = auStack_168;
                if (0x1f < (var_b0h - *(int64_t *)(var_b0h + -8)) - 8U) goto code_r0x00018016e1b4;
                func_0x000180459c3c(*(int64_t *)(var_b0h + -8), var_98h + 0x28);
            }
        }
code_r0x00018016de5d:
        puVar6 = (undefined8 *)(arg1 + 0x60);
        puVar4 = puVar6;
        if (0xf < *(uint64_t *)(arg1 + 0x78)) {
            puVar4 = (undefined8 *)*puVar6;
        }
        if (*(int64_t *)(arg1 + 0x70) == 0) {
            uVar10 = 0xffffffffffffffff;
        } else {
            iVar9 = *(int64_t *)(arg1 + 0x70) + (int64_t)puVar4;
            iVar8 = func_0x0001804580f0(puVar4, iVar9, 0x3a);
            uVar10 = 0xffffffffffffffff;
            if (iVar8 != iVar9) {
                uVar10 = iVar8 - (int64_t)puVar4;
            }
        }
        _var_f8h = ZEXT816(0);
        var_e8h = 0;
        var_e0h = 0;
        if (*(uint64_t *)(arg1 + 0x70) < uVar10) {
            uVar10 = *(uint64_t *)(arg1 + 0x70);
        }
        if (0xf < *(uint64_t *)(arg1 + 0x78)) {
            puVar6 = (undefined8 *)*puVar6;
        }
        func_0x000180004830(&var_f8h, puVar6, uVar10);
        cVar3 = func_0x000180170500(arg1 + 0xa0, &var_f8h);
        if (cVar3 != '\0') {
            puVar4 = (undefined8 *)func_0x0001801721b0(arg1 + 0xa0, &var_f8h);
            if (0xf < (uint64_t)puVar4[3]) {
                puVar4 = (undefined8 *)*puVar4;
            }
            func_0x0001804166c0(**(undefined8 **)(arg1 + 0x48), 0x2714, puVar4);
            cVar3 = func_0x000180170500(arg1 + 0xb0, &var_f8h);
            if (cVar3 != '\0') {
                uVar5 = func_0x0001801704e0(arg1 + 0xb0, &var_f8h);
                func_0x0001804166c0(**(undefined8 **)(arg1 + 0x48), 0x27bf, uVar5);
                uVar5 = func_0x0001801704c0(arg1 + 0xb0, &var_f8h);
                func_0x0001804166c0(**(undefined8 **)(arg1 + 0x48), 0x27c0, uVar5);
            }
        }
        cVar3 = func_0x000180170c40(arg1 + 0xd0);
        if (cVar3 == '\0') {
            cVar3 = func_0x000180170b00(arg1 + 0xd0);
            if (cVar3 == '\0') {
                puVar4 = (undefined8 *)func_0x000180170c50(arg1 + 0xd0, &var_d8h);
                if (0xf < (uint64_t)puVar4[3]) {
                    puVar4 = (undefined8 *)*puVar4;
                }
                func_0x0001804166c0(**(undefined8 **)(arg1 + 0x48), 0x2776, puVar4);
                puVar11 = auStack_168;
                if (0xf < (uint64_t)var_c0h) {
                    iVar9 = var_d8h;
                    puVar11 = auStack_168;
                    if ((0xfff < var_c0h + 1U) &&
                       (iVar9 = *(int64_t *)(var_d8h + -8), puVar11 = auStack_168, 0x1f < (var_d8h - iVar9) - 8U)) {
                        pcVar2 = (code *)swi(0x29);
                        iVar9 = (*pcVar2)(5);
                        puVar11 = auStack_160;
                    }
                    *(undefined8 *)(puVar11 + -8) = 0x18016e03b;
                    func_0x000180459c3c(iVar9);
                }
            } else {
                func_0x0001804166c0(**(undefined8 **)(arg1 + 0x48), 0x2776, 0);
                puVar11 = auStack_168;
            }
        } else {
            func_0x0001804166c0(**(undefined8 **)(arg1 + 0x48), 0x2776, 0x1805aadb1);
            puVar11 = auStack_168;
        }
        *(undefined4 *)(puVar11 + 0x44) = 0;
        uVar5 = **(undefined8 **)(arg1 + 0x48);
        *(undefined8 *)(puVar11 + -8) = 0x18016e056;
        func_0x0001804166c0(uVar5, 0xd8, puVar11 + 0x44);
        uVar1 = *(uint32_t *)(puVar11 + 0x44);
        uVar5 = **(undefined8 **)(arg1 + 0x48);
        *(undefined8 *)(puVar11 + -8) = 0x18016e073;
        func_0x0001804166c0(uVar5, 0xd8, 0x10);
        if ((uVar1 >> 1 & 1) != 0) {
            uVar5 = **(undefined8 **)(arg1 + 0x48);
            *(undefined8 *)(puVar11 + -8) = 0x18016e08f;
            func_0x0001804166c0(uVar5, 0xd8, 2);
        }
        *(undefined *)(*(int64_t *)(arg1 + 0x48) + 0x20) = 0;
        puVar4 = (undefined8 *)(arg1 + 0x120);
        *(undefined8 *)(arg1 + 0x130) = 0;
        puVar6 = puVar4;
        if (0xf < *(uint64_t *)(arg1 + 0x138)) {
            puVar6 = (undefined8 *)*puVar4;
        }
        *(undefined *)puVar6 = 0;
        if (*(int64_t *)(arg1 + 0x118) != 0) {
            *(undefined8 *)(puVar11 + -8) = 0x18016e0c8;
            func_0x00018000b240(puVar4);
        }
        *(undefined8 *)(arg1 + 0x150) = 0;
        if (*(uint64_t *)(arg1 + 0x158) < 0x10) {
            puVar7 = (undefined *)(arg1 + 0x140);
        } else {
            puVar7 = *(undefined **)(arg1 + 0x140);
        }
        *puVar7 = 0;
        if (*(int64_t *)(*(int64_t *)(arg1 + 0x110) + 0xd8) == 0) {
            uVar5 = **(undefined8 **)(arg1 + 0x48);
            *(undefined8 *)(puVar11 + -8) = 0x18016e115;
            func_0x0001804166c0(uVar5, 0x4e2b, 0x1801701d0);
            uVar5 = **(undefined8 **)(arg1 + 0x48);
            *(undefined8 *)(puVar11 + -8) = 0x18016e129;
            func_0x0001804166c0(uVar5, 0x2711, puVar4);
        }
        if (*(int64_t *)(*(int64_t *)(arg1 + 0x110) + 0x90) == 0) {
            uVar5 = **(undefined8 **)(arg1 + 0x48);
            *(undefined8 *)(puVar11 + -8) = 0x18016e152;
            func_0x0001804166c0(uVar5, 0x4e6f, 0x1801701d0);
            uVar5 = **(undefined8 **)(arg1 + 0x48);
            *(undefined8 *)(puVar11 + -8) = 0x18016e16a;
            func_0x0001804166c0(uVar5, 0x272d, arg1 + 0x140);
        }
        uVar5 = **(undefined8 **)(arg1 + 0x48);
        *(undefined8 *)(puVar11 + -8) = 0x18016e181;
        func_0x0001804166c0(uVar5, 0xac, 1);
        if ((uint64_t)var_e0h < 0x10) goto code_r0x00018016e1c3;
        iVar9 = *(int64_t *)(puVar11 + 0x70);
        if ((0xfff < var_e0h + 1U) &&
           (iVar8 = iVar9 - *(int64_t *)(iVar9 + -8), iVar9 = *(int64_t *)(iVar9 + -8), 0x1f < iVar8 - 8U))
        goto code_r0x00018016e1b4;
    } else {
        uVar10 = var_50h + 1;
        if (uVar10 < 0x1000) {
code_r0x00018016ddc9:
            func_0x000180459c3c(var_68h, uVar10);
            goto code_r0x00018016ddd6;
        }
        puVar11 = auStack_168;
        if ((var_68h - *(int64_t *)(var_68h + -8)) - 8U < 0x20) {
            uVar10 = var_50h + 0x28;
            var_68h = *(int64_t *)(var_68h + -8);
            goto code_r0x00018016ddc9;
        }
code_r0x00018016e1b4:
        pcVar2 = (code *)swi(0x29);
        iVar9 = (*pcVar2)(5);
        puVar11 = puVar11 + 8;
    }
    *(undefined8 *)(puVar11 + -8) = 0x18016e1c3;
    func_0x000180459c3c(iVar9);
code_r0x00018016e1c3:
    var_e8h = 0;
    var_e0h = 0xf;
    puVar11[0x70] = 0;
    if (0xf < (uint64_t)var_78h) {
        iVar9 = var_90h;
        if ((0xfff < var_78h + 1U) && (iVar9 = *(int64_t *)(var_90h + -8), 0x1f < (var_90h - iVar9) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar9 = (*pcVar2)(5);
            puVar11 = puVar11 + 8;
        }
        *(undefined8 *)(puVar11 + -8) = 0x18016e214;
        func_0x000180459c3c(iVar9);
    }
    *(undefined8 *)(puVar11 + -8) = 0x18016e220;
    func_0x000180459870(var_48h ^ (uint64_t)puVar11);
    return;
}

// ============================================================
// Function: FUN_18016e240
// Address: 0x18016e240
// Size: 1545 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_b0h
// WARNING: [rz-ghidra] Detected overlap for variable var_b8h

void fcn.18016e240(int64_t arg1)
{
    code *pcVar1;
    undefined auVar2 [16];
    char cVar3;
    int64_t *piVar4;
    int64_t *piVar5;
    undefined4 *puVar6;
    int64_t **ppiVar7;
    int64_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int64_t **ppiVar11;
    int64_t **ppiVar12;
    undefined *puVar13;
    undefined *puVar14;
    undefined *puVar15;
    int64_t **ppiVar16;
    int64_t **ppiVar17;
    undefined (*pauVar18) [16];
    int64_t *piVar19;
    int64_t iVar20;
    undefined8 uStack_f0;
    undefined auStack_e8 [8];
    undefined auStack_e0 [24];
    int64_t var_c8h;
    uint8_t var_b8h;
    int64_t var_b4h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    undefined8 uStack_88;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    undefined8 uStack_68;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    
    puVar15 = auStack_e8;
    puVar13 = auStack_e8;
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_e8;
    piVar19 = (int64_t *)0x0;
    var_b4h._0_4_ = 0;
    stack0xffffffffffffff50 = (int64_t *)0x0;
    var_a0h = arg1 + 0xc0;
    ppiVar12 = (int64_t **)**(int64_t **)var_a0h;
    piVar5 = piVar19;
    var_98h = arg1;
    if (*(char *)((int64_t)ppiVar12 + 0x19) == '\0') {
        ppiVar16 = (int64_t **)(uint64_t)var_b8h;
        do {
            uVar10 = 0;
            pauVar18 = (undefined (*) [16])(ppiVar12 + 4);
            auVar2 = ZEXT816(0);
            uStack_88 = 0;
            var_80h = 0;
            var_78h = 0;
            piVar5 = ppiVar12[6];
            if ((int64_t *)0xf < ppiVar12[7]) {
                pauVar18 = *(undefined (**) [16])*pauVar18;
            }
            _var_90h = auVar2;
            if ((int64_t *)0x7fffffffffffffff < piVar5) {
                func_0x0001800047c0();
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
            if ((int64_t *)0xf < piVar5) {
                piVar19 = (int64_t *)((uint64_t)piVar5 | 0xf);
                if (piVar19 < (int64_t *)0x8000000000000000) {
                    if (piVar19 < (int64_t *)0x16) {
                        piVar19 = (int64_t *)0x16;
                    }
                    if (piVar19 == (int64_t *)0xffffffffffffffff) goto code_r0x00018016e376;
                    if ((int64_t *)((int64_t)piVar19 + 1U) < (int64_t *)0x1000) {
                        uVar10 = func_0x000180459890();
                        goto code_r0x00018016e376;
                    }
                    piVar4 = piVar19 + 5;
                    if ((int64_t *)((int64_t)piVar19 + 1U) < piVar4) goto code_r0x00018016e34f;
                    func_0x000180004720();
code_r0x00018016e83d:
                    func_0x000180004720();
code_r0x00018016e843:
                    func_0x0001800047c0();
                    pcVar1 = (code *)swi(3);
                    (*pcVar1)();
                    return;
                }
                piVar19 = (int64_t *)0x7fffffffffffffff;
                piVar4 = (int64_t *)0x8000000000000027;
code_r0x00018016e34f:
                iVar8 = func_0x000180459890(piVar4);
                puVar14 = auStack_e8;
                if (iVar8 != 0) {
                    uVar10 = iVar8 + 0x27U & 0xffffffffffffffe0;
                    *(int64_t *)(uVar10 - 8) = iVar8;
code_r0x00018016e376:
                    var_90h = uVar10;
                    var_80h = (int64_t)piVar5;
                    var_78h = (int64_t)piVar19;
                    func_0x000180498030(uVar10, pauVar18);
                    piVar19 = stack0xffffffffffffff50;
                    goto code_r0x00018016e3ba;
                }
                goto code_r0x00018016e7a9;
            }
            var_78h = 0xf;
            _var_90h = *pauVar18;
            var_80h = (int64_t)piVar5;
code_r0x00018016e3ba:
            piVar5 = (int64_t *)var_80h;
            piVar4 = (int64_t *)0x0;
            if (ppiVar12[10] == (int64_t *)0x0) {
                piVar4 = piVar19;
                if (var_78h == var_80h) {
                    var_c8h = 1;
                    func_0x00018000ee80(&var_90h, 1, var_b8h, 0x1804a5784);
                } else {
                    piVar19 = &var_90h;
                    if (0xf < (uint64_t)var_78h) {
                        piVar19 = (int64_t *)var_90h;
                    }
                    puVar14 = (undefined *)((int64_t)piVar19 + var_80h);
                    var_80h = var_80h + 1;
                    *puVar14 = 0x3b;
                    *(undefined *)((int64_t)piVar19 + (int64_t)piVar5 + 1) = 0;
                }
            } else {
                ppiVar7 = ppiVar12 + 8;
                var_a8h = (int64_t)ppiVar12[10];
                if (0x7fffffffffffffffU - var_a8h < 2) goto code_r0x00018016e843;
                if ((int64_t *)0xf < ppiVar12[0xb]) {
                    ppiVar7 = (int64_t **)*ppiVar7;
                }
                _var_70h = ZEXT816(0);
                var_60h = 0;
                var_58h = 0;
                pauVar18 = (undefined (*) [16])(var_a8h + 2);
                if (pauVar18 < (undefined (*) [16])0x10) {
                    piVar19 = (int64_t *)0xf;
                    piVar4 = &var_70h;
                } else {
                    piVar19 = (int64_t *)((uint64_t)pauVar18 | 0xf);
                    if (piVar19 < (int64_t *)0x8000000000000000) {
                        if (piVar19 < (int64_t *)0x16) {
                            piVar19 = (int64_t *)0x16;
                        }
                        if (piVar19 == (int64_t *)0xffffffffffffffff) {
                            _var_70h = ZEXT816(0);
                        } else {
                            if ((int64_t *)0xfff < (int64_t *)((int64_t)piVar19 + 1U)) {
                                piVar4 = piVar19 + 5;
                                if (piVar4 <= (int64_t *)((int64_t)piVar19 + 1U)) goto code_r0x00018016e83d;
                                goto code_r0x00018016e4a2;
                            }
                            piVar4 = (int64_t *)func_0x000180459890();
                            var_70h = (int64_t)piVar4;
                        }
                    } else {
                        piVar19 = (int64_t *)0x7fffffffffffffff;
                        piVar4 = (int64_t *)0x8000000000000027;
code_r0x00018016e4a2:
                        iVar8 = func_0x000180459890(piVar4);
                        if (iVar8 == 0) goto code_r0x00018016e72a;
                        piVar4 = (int64_t *)(iVar8 + 0x27U & 0xffffffffffffffe0);
                        piVar4[-1] = iVar8;
                        var_70h = (int64_t)piVar4;
                    }
                }
                var_60h = (int64_t)pauVar18;
                var_58h = (int64_t)piVar19;
                *(undefined2 *)piVar4 = 0x203a;
                func_0x000180498030((undefined2 *)((int64_t)piVar4 + 2), ppiVar7, var_a8h);
                *(undefined *)((int64_t)piVar4 + (int64_t)pauVar18) = 0;
                pauVar18 = (undefined (*) [16])var_58h;
                iVar20 = var_60h;
                var_b4h._0_4_ = (uint32_t)var_b4h | 2;
                iVar8 = var_70h;
                piVar5 = &var_70h;
                if (0xf < (uint64_t)var_58h) {
                    piVar5 = (int64_t *)var_70h;
                }
                var_a8h = var_80h;
                if ((uint64_t)(var_78h - var_80h) < (uint64_t)var_60h) {
                    var_c8h = var_60h;
                    func_0x00018000ee80(&var_90h, var_60h);
                    pauVar18 = (undefined (*) [16])var_58h;
                    iVar8 = var_70h;
                } else {
                    piVar19 = &var_90h;
                    if (0xf < (uint64_t)var_78h) {
                        piVar19 = (int64_t *)var_90h;
                    }
                    iVar9 = var_80h + (int64_t)piVar19;
                    var_80h = var_60h + var_80h;
                    func_0x000180498030(iVar9, piVar5);
                    *(undefined *)((int64_t)piVar19 + var_a8h + iVar20) = 0;
                }
                piVar4 = stack0xffffffffffffff50;
                if ((undefined (*) [16])0xf < pauVar18) {
                    ppiVar7 = (int64_t **)((int64_t)*pauVar18 + 1);
                    iVar20 = iVar8;
                    if ((int64_t **)0xfff < ppiVar7) {
                        iVar20 = *(int64_t *)(iVar8 + -8);
                        piVar5 = (int64_t *)((iVar8 - iVar20) + -8);
                        if ((int64_t *)0x1f < piVar5) {
code_r0x00018016e72a:
                            pcVar1 = (code *)swi(0x29);
                            (*pcVar1)(5);
                            puVar13 = auStack_e0;
                            goto code_r0x00018016e731;
                        }
                        ppiVar7 = (int64_t **)((int64_t)pauVar18[2] + 8);
                    }
                    func_0x000180459c3c(iVar20, ppiVar7);
                    piVar4 = stack0xffffffffffffff50;
                }
            }
            piVar5 = &var_90h;
            if (0xf < (uint64_t)var_78h) {
                piVar5 = (int64_t *)var_90h;
            }
            piVar5 = (int64_t *)func_0x000180413c50(piVar4, piVar5);
            piVar19 = piVar4;
            if (piVar5 != (int64_t *)0x0) {
                piVar19 = piVar5;
            }
            unique0x10000846 = piVar19;
            if (0xf < (uint64_t)var_78h) {
                uVar10 = var_78h + 1;
                iVar8 = var_90h;
                if (0xfff < uVar10) {
                    iVar8 = *(int64_t *)(var_90h + -8);
                    puVar14 = auStack_e8;
                    if (0x1f < (var_90h - iVar8) - 8U) goto code_r0x00018016e7a9;
                    uVar10 = var_78h + 0x28;
                }
                func_0x000180459c3c(iVar8, uVar10);
            }
            var_80h = 0;
            var_78h = 0xf;
            auVar2[15] = 0;
            auVar2._0_15_ = stack0xffffffffffffff71;
            _var_90h = auVar2 << 8;
            ppiVar7 = (int64_t **)ppiVar12[2];
            if (*(char *)((int64_t)ppiVar7 + 0x19) == '\0') {
                cVar3 = *(char *)((int64_t)*ppiVar7 + 0x19);
                ppiVar12 = ppiVar7;
                ppiVar7 = (int64_t **)*ppiVar7;
                while (cVar3 == '\0') {
                    cVar3 = *(char *)((int64_t)*ppiVar7 + 0x19);
                    ppiVar12 = ppiVar7;
                    ppiVar7 = (int64_t **)*ppiVar7;
                }
            } else {
                cVar3 = *(char *)((int64_t)ppiVar12[1] + 0x19);
                ppiVar17 = (int64_t **)ppiVar12[1];
                ppiVar7 = ppiVar12;
                while ((ppiVar12 = ppiVar17, cVar3 == '\0' && (ppiVar7 == (int64_t **)ppiVar12[2]))) {
                    cVar3 = *(char *)((int64_t)ppiVar12[1] + 0x19);
                    ppiVar17 = (int64_t **)ppiVar12[1];
                    ppiVar7 = ppiVar12;
                }
            }
        } while (*(char *)((int64_t)ppiVar12 + 0x19) == '\0');
        piVar5 = (int64_t *)(uint64_t)(uint32_t)var_b4h;
    }
    pauVar18 = (undefined (*) [16])var_98h;
    ppiVar16 = (int64_t **)var_a0h;
    if (*(char *)(var_98h + 0x10) != '\0') {
        _var_70h = ZEXT816(0);
        var_60h = 0;
        var_58h = 0;
        puVar6 = (undefined4 *)func_0x000180459890(0x20);
        var_70h = (int64_t)puVar6;
        var_60h = 0x11;
        var_58h = 0x1f;
        *puVar6 = 0x6e617254;
        puVar6[1] = 0x72656673;
        puVar6[2] = 0x636e452d;
        puVar6[3] = 0x6e69646f;
        *(undefined *)(puVar6 + 4) = 0x67;
        *(undefined *)((int64_t)puVar6 + 0x11) = 0;
        piVar5 = (int64_t *)(uint64_t)((uint32_t)piVar5 | 1);
        ppiVar7 = (int64_t **)*ppiVar16;
        ppiVar12 = (int64_t **)ppiVar7[1];
        puVar15 = auStack_e8;
        ppiVar17 = ppiVar7;
        if (*(char *)((int64_t)ppiVar12 + 0x19) == '\0') {
            do {
                *(undefined8 *)(puVar13 + -8) = 0x18016e720;
                cVar3 = func_0x00018016b240(ppiVar16, ppiVar12 + 4, &var_70h);
                if (cVar3 == '\0') {
code_r0x00018016e731:
                    ppiVar11 = (int64_t **)*ppiVar12;
                    ppiVar17 = ppiVar12;
                } else {
                    ppiVar11 = (int64_t **)ppiVar12[2];
                    ppiVar17 = ppiVar7;
                }
                ppiVar12 = ppiVar11;
                ppiVar7 = ppiVar17;
            } while (*(char *)((int64_t)ppiVar11 + 0x19) == '\0');
            ppiVar7 = (int64_t **)*ppiVar16;
            puVar15 = puVar13;
        }
        if (*(char *)((int64_t)ppiVar17 + 0x19) == '\0') {
            *(undefined8 *)(puVar15 + -8) = 0x18016e75b;
            cVar3 = func_0x00018016b240(ppiVar16, &var_70h, ppiVar17 + 4);
            ppiVar7 = ppiVar17;
            if (cVar3 != '\0') {
                ppiVar7 = (int64_t **)*ppiVar16;
            }
        }
        if (ppiVar7 == (int64_t **)*ppiVar16) {
            ppiVar12 = (int64_t **)0x1;
            goto code_r0x00018016e772;
        }
    }
    ppiVar12 = (int64_t **)0x0;
code_r0x00018016e772:
    cVar3 = (char)ppiVar12;
    if ((((uint64_t)piVar5 & 1) != 0) && (0xf < (uint64_t)var_58h)) {
        iVar8 = var_70h;
        if ((0xfff < var_58h + 1U) &&
           (iVar8 = *(int64_t *)(var_70h + -8), puVar14 = puVar15, 0x1f < (var_70h - iVar8) - 8U)) {
code_r0x00018016e7a9:
            cVar3 = (char)ppiVar12;
            pcVar1 = (code *)swi(0x29);
            iVar8 = (*pcVar1)(5);
            puVar15 = puVar14 + 8;
        }
        *(undefined8 *)(puVar15 + -8) = 0x18016e7b8;
        func_0x000180459c3c(iVar8);
    }
    if (cVar3 != '\0') {
        *(undefined8 *)(puVar15 + -8) = 0x18016e7cb;
        piVar5 = (int64_t *)func_0x000180413c50(piVar19, 0x1804a57a0);
        if (piVar5 != (int64_t *)0x0) {
            piVar19 = piVar5;
        }
    }
    *(undefined8 *)(puVar15 + -8) = 0x18016e7e1;
    piVar5 = (int64_t *)func_0x000180413c50(piVar19, 0x1804a57c0);
    if (piVar5 != (int64_t *)0x0) {
        piVar19 = piVar5;
    }
    iVar8 = **(int64_t **)((int64_t)pauVar18[4] + 8);
    *(undefined8 *)(puVar15 + -8) = 0x18016e7fc;
    func_0x0001804166c0(iVar8, 0x2727, piVar19);
    iVar8 = (*(int64_t **)((int64_t)pauVar18[4] + 8))[1];
    *(undefined8 *)(puVar15 + -8) = 0x18016e809;
    func_0x000180413cf0(iVar8);
    (*(int64_t **)((int64_t)pauVar18[4] + 8))[1] = (int64_t)piVar19;
    *(undefined8 *)(puVar15 + -8) = 0x18016e81d;
    func_0x000180459870(var_50h ^ (uint64_t)puVar15);
    return;
}

// ============================================================
// Function: FUN_18016e850
// Address: 0x18016e850
// Size: 448 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18016e850(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    int32_t *piVar3;
    uint8_t *puVar4;
    code *pcVar5;
    uint32_t uVar6;
    int32_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    uint8_t in_DL;
    uint32_t uVar10;
    undefined8 uVar11;
    bool bVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    
    uVar6 = (uint32_t)in_DL;
    piVar1 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 8))();
    }
    iVar9 = *(int64_t *)arg1;
    if (*(int32_t *)((int64_t)*(int32_t *)(iVar9 + 4) + 0x10 + arg1) == 0) {
        iVar2 = *(int64_t *)((int64_t)*(int32_t *)(iVar9 + 4) + 0x50 + arg1);
        if ((iVar2 == 0) || (iVar2 == arg1)) {
            bVar12 = true;
        } else {
            func_0x00018000fad0(iVar2);
            iVar9 = *(int64_t *)arg1;
            bVar12 = *(int32_t *)((int64_t)*(int32_t *)(iVar9 + 4) + 0x10 + arg1) == 0;
        }
    } else {
        bVar12 = false;
    }
    if (bVar12) {
        piVar1 = *(int64_t **)((int64_t)*(int32_t *)(iVar9 + 4) + 0x48 + arg1);
        if ((*(int64_t *)piVar1[8] == 0) || (piVar3 = (int32_t *)piVar1[0xb], *piVar3 < 1)) {
            uVar6 = (**(code **)(*piVar1 + 0x18))(piVar1, uVar6);
        } else {
            *piVar3 = *piVar3 + -1;
            puVar4 = *(uint8_t **)piVar1[8];
            *(uint8_t **)piVar1[8] = puVar4 + 1;
            *puVar4 = in_DL;
        }
        uVar10 = 0;
        if (uVar6 == 0xffffffff) {
            uVar10 = 4;
        }
    } else {
        uVar10 = 4;
    }
    iVar9 = (int64_t)*(int32_t *)(*(int64_t *)arg1 + 4);
    uVar6 = 4;
    if (*(int64_t *)(iVar9 + 0x48 + arg1) != 0) {
        uVar6 = 0;
    }
    uVar10 = uVar6 | *(uint32_t *)(iVar9 + 0x10 + arg1) & 0x17 | uVar10;
    *(uint32_t *)(iVar9 + 0x10 + arg1) = uVar10;
    uVar10 = uVar10 & *(uint32_t *)(iVar9 + 0x14 + arg1);
    if (uVar10 != 0) {
        if ((uVar10 & 4) == 0) {
            uVar11 = 0x1805aae00;
            if ((uVar10 & 2) == 0) {
                uVar11 = 0x1805aae18;
            }
        } else {
            uVar11 = 0x1805aade8;
        }
        uVar8 = func_0x000180005e50(&var_48h, 1);
        func_0x0001800069f0(&var_38h, uVar11, uVar8);
        fcn.18045bae0(arg1);
        pcVar5 = (code *)swi(3);
        iVar9 = (*pcVar5)();
        return iVar9;
    }
    iVar7 = func_0x0001804557c0();
    if (iVar7 == 0) {
        func_0x00018000fc20(arg1);
    }
    piVar1 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x10))();
    }
    return arg1;
}

// ============================================================
// Function: FUN_18016ea10
// Address: 0x18016ea10
// Size: 586 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined (*) [16] fcn.18016ea10(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 *puVar7;
    undefined (*pauVar8) [16];
    uint64_t uVar9;
    int64_t iVar10;
    undefined *puVar11;
    undefined *puVar12;
    undefined (*pauVar13) [16];
    int64_t iVar14;
    uint64_t uVar15;
    undefined auStack_98 [8];
    undefined auStack_90 [24];
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_8h;
    
    puVar11 = auStack_98;
    puVar12 = auStack_98;
    iVar14 = *(int64_t *)arg1;
    iVar10 = *(int64_t *)(arg1 + 8) - iVar14 >> 5;
    if (iVar10 == 0x7ffffffffffffff) {
        func_0x000180010010();
        pcVar3 = (code *)swi(3);
        pauVar13 = (undefined (*) [16])(*pcVar3)();
        return pauVar13;
    }
    uVar9 = *(int64_t *)(arg1 + 0x10) - iVar14 >> 5;
    if (uVar9 <= 0x7ffffffffffffff - (uVar9 >> 1)) {
        uVar1 = iVar10 + 1;
        uVar9 = uVar9 + (uVar9 >> 1);
        uVar15 = uVar1;
        if (uVar1 <= uVar9) {
            uVar15 = uVar9;
        }
        if (uVar15 < 0x800000000000000) {
            uVar9 = uVar15 * 0x20;
            if (uVar9 == 0) {
                pauVar13 = (undefined (*) [16])0x0;
                puVar12 = auStack_98;
            } else if (uVar9 < 0x1000) {
                pauVar13 = (undefined (*) [16])func_0x000180459890();
            } else {
                if (uVar9 + 0x27 <= uVar9) goto code_r0x00018016ec54;
                iVar10 = func_0x000180459890(uVar9 + 0x27);
                if (iVar10 == 0) {
                    pcVar3 = (code *)swi(0x29);
                    iVar10 = (*pcVar3)(5);
                    puVar11 = auStack_90;
                }
                pauVar13 = (undefined (*) [16])(iVar10 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(pauVar13[-1] + 8) = iVar10;
                puVar12 = puVar11;
            }
            iVar14 = arg2 - iVar14 >> 5;
            pauVar8 = pauVar13 + iVar14 * 2;
            *(int64_t *)(puVar12 + 0x20) = arg1;
            *(undefined (**) [16])(puVar12 + 0x28) = pauVar13;
            *(uint64_t *)(puVar12 + 0x30) = uVar15;
            *(undefined (**) [16])(puVar12 + 0x38) = pauVar8 + 2;
            *(undefined (**) [16])(puVar12 + 0x40) = pauVar8 + 2;
            *pauVar8 = ZEXT816(0);
            *(undefined8 *)pauVar8[1] = 0;
            *(undefined8 *)(pauVar8[1] + 8) = 0;
            *(undefined8 *)(puVar12 + -8) = 0x18016eb25;
            func_0x000180498cd0(arg3);
            *(undefined8 *)(puVar12 + -8) = 0x18016eb33;
            func_0x000180004830(pauVar8, arg3);
            puVar2 = *(undefined4 **)(arg1 + 8);
            puVar7 = *(undefined4 **)arg1;
            pauVar8 = pauVar13;
            if ((undefined4 *)arg2 == puVar2) {
                for (; puVar7 != puVar2; puVar7 = puVar7 + 8) {
                    *pauVar8 = ZEXT816(0);
                    *(undefined8 *)pauVar8[1] = 0;
                    *(undefined8 *)(pauVar8[1] + 8) = 0;
                    uVar4 = puVar7[1];
                    uVar5 = puVar7[2];
                    uVar6 = puVar7[3];
                    *(undefined4 *)*pauVar8 = *puVar7;
                    *(undefined4 *)(*pauVar8 + 4) = uVar4;
                    *(undefined4 *)(*pauVar8 + 8) = uVar5;
                    *(undefined4 *)(*pauVar8 + 0xc) = uVar6;
                    uVar4 = puVar7[5];
                    uVar5 = puVar7[6];
                    uVar6 = puVar7[7];
                    *(undefined4 *)pauVar8[1] = puVar7[4];
                    *(undefined4 *)(pauVar8[1] + 4) = uVar4;
                    *(undefined4 *)(pauVar8[1] + 8) = uVar5;
                    *(undefined4 *)(pauVar8[1] + 0xc) = uVar6;
                    *(undefined8 *)(puVar7 + 4) = 0;
                    *(undefined8 *)(puVar7 + 6) = 0xf;
                    *(undefined *)puVar7 = 0;
                    pauVar8 = pauVar8 + 2;
                }
            } else {
                for (; puVar7 != (undefined4 *)arg2; puVar7 = puVar7 + 8) {
                    *pauVar8 = ZEXT816(0);
                    *(undefined8 *)pauVar8[1] = 0;
                    *(undefined8 *)(pauVar8[1] + 8) = 0;
                    uVar4 = puVar7[1];
                    uVar5 = puVar7[2];
                    uVar6 = puVar7[3];
                    *(undefined4 *)*pauVar8 = *puVar7;
                    *(undefined4 *)(*pauVar8 + 4) = uVar4;
                    *(undefined4 *)(*pauVar8 + 8) = uVar5;
                    *(undefined4 *)(*pauVar8 + 0xc) = uVar6;
                    uVar4 = puVar7[5];
                    uVar5 = puVar7[6];
                    uVar6 = puVar7[7];
                    *(undefined4 *)pauVar8[1] = puVar7[4];
                    *(undefined4 *)(pauVar8[1] + 4) = uVar4;
                    *(undefined4 *)(pauVar8[1] + 8) = uVar5;
                    *(undefined4 *)(pauVar8[1] + 0xc) = uVar6;
                    *(undefined8 *)(puVar7 + 4) = 0;
                    *(undefined8 *)(puVar7 + 6) = 0xf;
                    *(undefined *)puVar7 = 0;
                    pauVar8 = pauVar8 + 2;
                }
                puVar2 = *(undefined4 **)(arg1 + 8);
                pauVar8 = pauVar13 + iVar14 * 2 + 2;
                if ((undefined4 *)arg2 != puVar2) {
                    do {
                        *pauVar8 = ZEXT816(0);
                        *(undefined8 *)pauVar8[1] = 0;
                        *(undefined8 *)(pauVar8[1] + 8) = 0;
                        uVar4 = *(undefined4 *)(arg2 + 4);
                        uVar5 = *(undefined4 *)(arg2 + 8);
                        uVar6 = *(undefined4 *)(arg2 + 0xc);
                        *(undefined4 *)*pauVar8 = *(undefined4 *)arg2;
                        *(undefined4 *)(*pauVar8 + 4) = uVar4;
                        *(undefined4 *)(*pauVar8 + 8) = uVar5;
                        *(undefined4 *)(*pauVar8 + 0xc) = uVar6;
                        uVar4 = *(undefined4 *)(arg2 + 0x14);
                        uVar5 = *(undefined4 *)(arg2 + 0x18);
                        uVar6 = *(undefined4 *)(arg2 + 0x1c);
                        *(undefined4 *)pauVar8[1] = *(undefined4 *)(arg2 + 0x10);
                        *(undefined4 *)(pauVar8[1] + 4) = uVar4;
                        *(undefined4 *)(pauVar8[1] + 8) = uVar5;
                        *(undefined4 *)(pauVar8[1] + 0xc) = uVar6;
                        *(undefined8 *)(arg2 + 0x10) = 0;
                        *(undefined8 *)(arg2 + 0x18) = 0xf;
                        *(undefined *)arg2 = 0;
                        pauVar8 = pauVar8 + 2;
                        arg2 = arg2 + 0x20;
                    } while ((undefined4 *)arg2 != puVar2);
                }
            }
            *(undefined8 *)(puVar12 + -8) = 0x18016ec39;
            func_0x00018007f6f0(arg1, pauVar13, uVar1, uVar15);
            return pauVar13 + iVar14 * 2;
        }
    }
code_r0x00018016ec54:
    func_0x000180004720();
    pcVar3 = (code *)swi(3);
    pauVar13 = (undefined (*) [16])(*pcVar3)();
    return pauVar13;
}

// ============================================================
// Function: FUN_18016ec60
// Address: 0x18016ec60
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.18016ec60(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t *puVar1;
    uint8_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint8_t *puVar5;
    int64_t var_128h;
    int64_t var_28h;
    
    iVar4 = func_0x000180498cd0(arg2);
    uVar3 = *(uint64_t *)(arg1 + 0x10);
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        arg1 = *(int64_t *)arg1;
    }
    if ((uint64_t)arg3 < uVar3) {
        puVar5 = (uint8_t *)(arg3 + arg1);
        if (iVar4 + (uVar3 - arg3) < 0x10) {
            func_0x0001804986e0(&var_128h, 0, 0x100);
            puVar1 = (uint8_t *)(iVar4 + arg2);
            if ((uint8_t *)arg2 != puVar1) {
                do {
                    uVar2 = *(uint8_t *)arg2;
                    arg2 = arg2 + 1;
                    *(undefined *)((int64_t)&var_128h + (uint64_t)uVar2) = 1;
                } while ((uint8_t *)arg2 != puVar1);
            }
            for (; puVar5 < (uint8_t *)(uVar3 + arg1); puVar5 = puVar5 + 1) {
                if (*(char *)((int64_t)&var_128h + (uint64_t)*puVar5) == '\0') {
                    return (int64_t)puVar5 - arg1;
                }
            }
            arg3 = -1;
        } else {
            iVar4 = func_0x000180457f50(puVar5, uVar3 - arg3, arg2, iVar4);
            arg3 = iVar4 + arg3;
            if (iVar4 == -1) {
                arg3 = -1;
            }
        }
        return arg3;
    }
    return -1;
}

// ============================================================
// Function: FUN_18016ecad
// Address: 0x18016ecad
// Size: 167 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.18016ec60(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t *puVar1;
    uint8_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint8_t *puVar5;
    int64_t var_128h;
    int64_t var_28h;
    
    iVar4 = func_0x000180498cd0(arg2);
    uVar3 = *(uint64_t *)(arg1 + 0x10);
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        arg1 = *(int64_t *)arg1;
    }
    if ((uint64_t)arg3 < uVar3) {
        puVar5 = (uint8_t *)(arg3 + arg1);
        if (iVar4 + (uVar3 - arg3) < 0x10) {
            func_0x0001804986e0(&var_128h, 0, 0x100);
            puVar1 = (uint8_t *)(iVar4 + arg2);
            if ((uint8_t *)arg2 != puVar1) {
                do {
                    uVar2 = *(uint8_t *)arg2;
                    arg2 = arg2 + 1;
                    *(undefined *)((int64_t)&var_128h + (uint64_t)uVar2) = 1;
                } while ((uint8_t *)arg2 != puVar1);
            }
            for (; puVar5 < (uint8_t *)(uVar3 + arg1); puVar5 = puVar5 + 1) {
                if (*(char *)((int64_t)&var_128h + (uint64_t)*puVar5) == '\0') {
                    return (int64_t)puVar5 - arg1;
                }
            }
            arg3 = -1;
        } else {
            iVar4 = func_0x000180457f50(puVar5, uVar3 - arg3, arg2, iVar4);
            arg3 = iVar4 + arg3;
            if (iVar4 == -1) {
                arg3 = -1;
            }
        }
        return arg3;
    }
    return -1;
}

// ============================================================
// Function: FUN_18016ed54
// Address: 0x18016ed54
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.18016ec60(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t *puVar1;
    uint8_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint8_t *puVar5;
    int64_t var_128h;
    int64_t var_28h;
    
    iVar4 = func_0x000180498cd0(arg2);
    uVar3 = *(uint64_t *)(arg1 + 0x10);
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        arg1 = *(int64_t *)arg1;
    }
    if ((uint64_t)arg3 < uVar3) {
        puVar5 = (uint8_t *)(arg3 + arg1);
        if (iVar4 + (uVar3 - arg3) < 0x10) {
            func_0x0001804986e0(&var_128h, 0, 0x100);
            puVar1 = (uint8_t *)(iVar4 + arg2);
            if ((uint8_t *)arg2 != puVar1) {
                do {
                    uVar2 = *(uint8_t *)arg2;
                    arg2 = arg2 + 1;
                    *(undefined *)((int64_t)&var_128h + (uint64_t)uVar2) = 1;
                } while ((uint8_t *)arg2 != puVar1);
            }
            for (; puVar5 < (uint8_t *)(uVar3 + arg1); puVar5 = puVar5 + 1) {
                if (*(char *)((int64_t)&var_128h + (uint64_t)*puVar5) == '\0') {
                    return (int64_t)puVar5 - arg1;
                }
            }
            arg3 = -1;
        } else {
            iVar4 = func_0x000180457f50(puVar5, uVar3 - arg3, arg2, iVar4);
            arg3 = iVar4 + arg3;
            if (iVar4 == -1) {
                arg3 = -1;
            }
        }
        return arg3;
    }
    return -1;
}

// ============================================================
// Function: FUN_18016ed60
// Address: 0x18016ed60
// Size: 218 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18016ed60(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t *piVar1;
    uint8_t *puVar2;
    uint8_t uVar3;
    char cVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t var_20h;
    int64_t var_118h;
    
    iVar5 = func_0x000180498cd0(arg2);
    piVar1 = (int64_t *)(arg1 + 0x10);
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        arg1 = *(int64_t *)arg1;
    }
    if (*piVar1 == 0) {
code_r0x00018016ed97:
        iVar5 = -1;
    } else {
        uVar6 = *piVar1 - 1;
        if (uVar6 < (uint64_t)arg3) {
            arg3 = uVar6;
        }
        if (arg3 + 1U + iVar5 < 0x10) {
            func_0x0001804986e0(&var_118h, 0, 0x100);
            puVar2 = (uint8_t *)(iVar5 + arg2);
            if ((uint8_t *)arg2 != puVar2) {
                do {
                    uVar3 = *(uint8_t *)arg2;
                    arg2 = arg2 + 1;
                    *(undefined *)((int64_t)&var_118h + (uint64_t)uVar3) = 1;
                } while ((uint8_t *)arg2 != puVar2);
            }
            iVar5 = arg3 + arg1;
            cVar4 = *(char *)((int64_t)&var_118h + (uint64_t)*(uint8_t *)(arg3 + arg1));
            while (cVar4 != '\0') {
                if (iVar5 == arg1) goto code_r0x00018016ed97;
                puVar2 = (uint8_t *)(iVar5 + -1);
                iVar5 = iVar5 + -1;
                cVar4 = *(char *)((int64_t)&var_118h + (uint64_t)*puVar2);
            }
            iVar5 = iVar5 - arg1;
        } else {
            iVar5 = func_0x0001804580e0(arg1, arg3 + 1U, arg2, iVar5);
        }
    }
    return iVar5;
}

// ============================================================
// Function: FUN_18016ee40
// Address: 0x18016ee40
// Size: 27 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18016ee40(int64_t arg1)
{
    code *pcVar1;
    undefined uVar2;
    int64_t *piVar3;
    undefined *puVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_70h;
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar4 = auStack_68;
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    func_0x00018000b4d0(&var_48h, arg1);
    piVar6 = (int64_t *)var_48h;
    if ((uint64_t)var_30h < 0x10) {
        piVar6 = &var_48h;
    }
    piVar3 = (int64_t *)(var_38h + (int64_t)piVar6);
    piVar5 = piVar6;
    for (; piVar6 != piVar3; piVar6 = (int64_t *)((int64_t)piVar6 + 1)) {
        uVar2 = func_0x000180460320(*(undefined *)piVar6);
        *(undefined *)piVar5 = uVar2;
        piVar5 = (int64_t *)((int64_t)piVar5 + 1);
    }
    piVar6 = &var_48h;
    if (0xf < (uint64_t)var_30h) {
        piVar6 = (int64_t *)var_48h;
    }
    if (var_38h == 4) {
        func_0x000180497f30(piVar6, 0x1805ab294);
    }
    if (0xf < (uint64_t)var_30h) {
        piVar6 = (int64_t *)var_48h;
        puVar4 = auStack_68;
        if (0xfff < var_30h + 1U) {
            piVar6 = *(int64_t **)(var_48h + -8);
            piVar5 = (int64_t *)(var_48h + (-8 - (int64_t)piVar6));
            puVar4 = auStack_68;
            if ((int64_t *)0x1f < piVar5) {
                pcVar1 = (code *)swi(0x29);
                (*pcVar1)(5);
                piVar6 = piVar5;
                puVar4 = auStack_60;
            }
        }
        *(undefined8 *)(puVar4 + -8) = 0x18016ef43;
        func_0x000180459c3c(piVar6);
    }
    *(undefined8 *)(puVar4 + -8) = 0x18016ef53;
    func_0x000180459870(*(uint64_t *)(puVar4 + 0x40) ^ (uint64_t)puVar4);
    return;
}

// ============================================================
// Function: FUN_18016ee5b
// Address: 0x18016ee5b
// Size: 154 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18016ee40(int64_t arg1)
{
    code *pcVar1;
    undefined uVar2;
    int64_t *piVar3;
    undefined *puVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_70h;
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar4 = auStack_68;
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    func_0x00018000b4d0(&var_48h, arg1);
    piVar6 = (int64_t *)var_48h;
    if ((uint64_t)var_30h < 0x10) {
        piVar6 = &var_48h;
    }
    piVar3 = (int64_t *)(var_38h + (int64_t)piVar6);
    piVar5 = piVar6;
    for (; piVar6 != piVar3; piVar6 = (int64_t *)((int64_t)piVar6 + 1)) {
        uVar2 = func_0x000180460320(*(undefined *)piVar6);
        *(undefined *)piVar5 = uVar2;
        piVar5 = (int64_t *)((int64_t)piVar5 + 1);
    }
    piVar6 = &var_48h;
    if (0xf < (uint64_t)var_30h) {
        piVar6 = (int64_t *)var_48h;
    }
    if (var_38h == 4) {
        func_0x000180497f30(piVar6, 0x1805ab294);
    }
    if (0xf < (uint64_t)var_30h) {
        piVar6 = (int64_t *)var_48h;
        puVar4 = auStack_68;
        if (0xfff < var_30h + 1U) {
            piVar6 = *(int64_t **)(var_48h + -8);
            piVar5 = (int64_t *)(var_48h + (-8 - (int64_t)piVar6));
            puVar4 = auStack_68;
            if ((int64_t *)0x1f < piVar5) {
                pcVar1 = (code *)swi(0x29);
                (*pcVar1)(5);
                piVar6 = piVar5;
                puVar4 = auStack_60;
            }
        }
        *(undefined8 *)(puVar4 + -8) = 0x18016ef43;
        func_0x000180459c3c(piVar6);
    }
    *(undefined8 *)(puVar4 + -8) = 0x18016ef53;
    func_0x000180459870(*(uint64_t *)(puVar4 + 0x40) ^ (uint64_t)puVar4);
    return;
}

// ============================================================
// Function: FUN_18016eef5
// Address: 0x18016eef5
// Size: 103 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18016ee40(int64_t arg1)
{
    code *pcVar1;
    undefined uVar2;
    int64_t *piVar3;
    undefined *puVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_70h;
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar4 = auStack_68;
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    func_0x00018000b4d0(&var_48h, arg1);
    piVar6 = (int64_t *)var_48h;
    if ((uint64_t)var_30h < 0x10) {
        piVar6 = &var_48h;
    }
    piVar3 = (int64_t *)(var_38h + (int64_t)piVar6);
    piVar5 = piVar6;
    for (; piVar6 != piVar3; piVar6 = (int64_t *)((int64_t)piVar6 + 1)) {
        uVar2 = func_0x000180460320(*(undefined *)piVar6);
        *(undefined *)piVar5 = uVar2;
        piVar5 = (int64_t *)((int64_t)piVar5 + 1);
    }
    piVar6 = &var_48h;
    if (0xf < (uint64_t)var_30h) {
        piVar6 = (int64_t *)var_48h;
    }
    if (var_38h == 4) {
        func_0x000180497f30(piVar6, 0x1805ab294);
    }
    if (0xf < (uint64_t)var_30h) {
        piVar6 = (int64_t *)var_48h;
        puVar4 = auStack_68;
        if (0xfff < var_30h + 1U) {
            piVar6 = *(int64_t **)(var_48h + -8);
            piVar5 = (int64_t *)(var_48h + (-8 - (int64_t)piVar6));
            puVar4 = auStack_68;
            if ((int64_t *)0x1f < piVar5) {
                pcVar1 = (code *)swi(0x29);
                (*pcVar1)(5);
                piVar6 = piVar5;
                puVar4 = auStack_60;
            }
        }
        *(undefined8 *)(puVar4 + -8) = 0x18016ef43;
        func_0x000180459c3c(piVar6);
    }
    *(undefined8 *)(puVar4 + -8) = 0x18016ef53;
    func_0x000180459870(*(uint64_t *)(puVar4 + 0x40) ^ (uint64_t)puVar4);
    return;
}

// ============================================================
// Function: FUN_18016ef60
// Address: 0x18016ef60
// Size: 861 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h

void fcn.18016ef60(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    code *pcVar2;
    undefined uVar3;
    undefined8 uVar4;
    int32_t *piVar5;
    int64_t iVar6;
    uint64_t uVar7;
    undefined8 *puVar8;
    undefined *puVar9;
    undefined *puVar10;
    int64_t var_18h;
    undefined8 uStack_170;
    undefined auStack_168 [8];
    undefined auStack_160 [24];
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_c8h;
    int64_t var_a8h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    
    puVar9 = auStack_168;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_168;
    *(undefined *)arg1 = 1;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0;
    var_128h._0_4_ = 1;
    puVar10 = auStack_168;
    var_120h = arg1;
    var_110h = arg1;
    if (arg2 != 0) {
        do {
            _var_108h = ZEXT816(0);
            var_f8h = 0;
            var_f0h = 0;
            uVar4 = func_0x000180498cd0(*(undefined8 *)arg2);
            func_0x000180004830(&var_108h, *(undefined8 *)arg2, uVar4);
            func_0x00018016ff80(&var_140h, &var_108h, 9);
            if (0xf < (uint64_t)var_f0h) {
                uVar7 = var_f0h + 1;
                iVar6 = var_108h;
                if (uVar7 < 0x1000) {
code_r0x00018016f036:
                    func_0x000180459c3c(iVar6, uVar7);
                    goto code_r0x00018016f03b;
                }
                iVar6 = *(int64_t *)(var_108h + -8);
                if ((var_108h - iVar6) - 8U < 0x20) {
                    uVar7 = var_f0h + 0x28;
                    goto code_r0x00018016f036;
                }
                pcVar2 = (code *)swi(0x29);
                (*pcVar2)(5);
                puVar9 = auStack_160;
code_r0x00018016f266:
                pcVar2 = (code *)swi(0x29);
                (*pcVar2)(5);
                puVar10 = puVar9 + 8;
                break;
            }
code_r0x00018016f03b:
            if ((uint64_t)(var_138h - var_140h >> 5) < 7) {
                do {
                    if (var_138h == var_130h) {
                        fcn.18016ea10((int64_t)&var_140h, var_138h, 0x1805aadb1);
                    } else {
                        *(undefined (*) [16])var_138h = ZEXT816(0);
                        *(undefined8 *)(var_138h + 0x10) = 0;
                        *(undefined8 *)(var_138h + 0x18) = 0xf;
                        *(undefined *)var_138h = 0;
                        var_138h = var_138h + 0x20;
                    }
                } while ((uint64_t)(var_138h - var_140h >> 5) < 7);
            } else if ((uint64_t)(var_138h - var_140h >> 5) < 5) {
                func_0x000180060370();
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
            iVar6 = var_140h;
            puVar8 = (undefined8 *)(var_140h + 0x80);
            piVar5 = (int32_t *)func_0x00018046b77c();
            if (0xf < *(uint64_t *)(iVar6 + 0x98)) {
                puVar8 = (undefined8 *)*puVar8;
            }
            *piVar5 = 0;
            var_128h._4_4_ = func_0x00018046c694(puVar8, &var_118h, 10);
            iVar6 = var_140h;
            if (puVar8 == (undefined8 *)var_118h) {
                func_0x0001804546b0(0x1804a5828);
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
            if (*piVar5 == 0x22) {
                func_0x0001804546f8(0x1804a5840);
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
            if (((uint64_t)(var_138h - var_140h >> 5) < 7) ||
               (var_148h._0_1_ = fcn.18016ee40(var_140h + 0x20), (uint64_t)(var_138h - var_140h >> 5) < 4)) {
                func_0x000180060370();
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
            iVar1 = var_140h + 0x40;
            uVar3 = fcn.18016ee40(var_140h + 0x60);
            uVar7 = (uint64_t)var_128h._4_4_;
            func_0x00018000b4d0(&var_e8h, iVar6 + 0xa0);
            func_0x00018000b4d0(&var_c8h, iVar6 + 0xc0);
            func_0x00018000b4d0(&var_a8h, iVar6);
            var_88h._0_1_ = (undefined)var_148h;
            func_0x00018000b4d0(&var_80h, iVar1);
            var_60h._0_1_ = uVar3;
            var_58h = uVar7 * 10000000;
            func_0x00018016c230(var_120h, &var_e8h);
            func_0x000180004e40(&var_80h);
            func_0x000180004e40(&var_a8h);
            func_0x000180004e40(&var_c8h);
            func_0x000180004e40(&var_e8h);
            iVar1 = var_138h;
            iVar6 = var_140h;
            if (var_140h != 0) {
                for (; iVar6 != iVar1; iVar6 = iVar6 + 0x20) {
                    func_0x000180004e40(iVar6);
                }
                uVar7 = var_130h - var_140h & 0xffffffffffffffe0;
                iVar6 = var_140h;
                if (0xfff < uVar7) {
                    if (0x1f < (var_140h - *(int64_t *)(var_140h + -8)) - 8U) goto code_r0x00018016f266;
                    uVar7 = uVar7 + 0x27;
                    iVar6 = *(int64_t *)(var_140h + -8);
                }
                func_0x000180459c3c(iVar6, uVar7);
            }
            arg2 = *(undefined8 *)(arg2 + 8);
            puVar10 = auStack_168;
        } while ((undefined8 *)arg2 != (undefined8 *)0x0);
    }
    *(undefined8 *)(puVar10 + -8) = 0x18016f27c;
    func_0x000180459870(var_48h ^ (uint64_t)puVar10);
    return;
}

// ============================================================
// Function: FUN_18016f2c0
// Address: 0x18016f2c0
// Size: 3187 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_304h
// WARNING: [rz-ghidra] Detected overlap for variable var_308h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ech
// WARNING: [rz-ghidra] Detected overlap for variable var_2ach

void fcn.18016f2c0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_50h)
{
    int64_t *piVar1;
    uint8_t uVar2;
    undefined8 uVar3;
    code *pcVar4;
    undefined auVar5 [16];
    undefined auVar6 [16];
    int64_t *piVar7;
    char cVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t *piVar11;
    uint8_t *puVar12;
    uint8_t **ppuVar13;
    uint64_t uVar14;
    undefined8 *puVar15;
    int64_t iVar16;
    uint8_t **ppuVar17;
    int64_t *piVar18;
    uint64_t uVar19;
    uint64_t uVar20;
    undefined uVar21;
    undefined *puVar22;
    uint32_t uVar23;
    int64_t iVar24;
    undefined8 *puVar25;
    undefined uVar26;
    uint8_t *puVar27;
    undefined8 *puVar28;
    uint8_t **ppuVar29;
    uint64_t uVar30;
    bool bVar31;
    undefined8 uStack_340;
    undefined auStack_338 [8];
    undefined auStack_330 [24];
    int64_t var_318h;
    undefined var_308h;
    uint32_t var_304h;
    int64_t var_300h;
    int64_t var_2f8h;
    int64_t var_2f0h;
    int64_t var_2e8h;
    int64_t var_2e0h;
    int64_t var_2d8h;
    int64_t var_2d0h;
    int64_t var_2c8h;
    int64_t var_2b8h;
    int64_t var_2b0h;
    int64_t var_2a8h;
    int64_t var_2a0h;
    int64_t var_298h;
    int64_t var_288h;
    int64_t var_208h;
    int64_t var_200h;
    int64_t var_1f8h;
    int64_t var_1f0h;
    int64_t var_1e8h;
    int64_t var_1d8h;
    int64_t var_1c8h;
    int64_t var_1c0h;
    int64_t var_1b8h;
    int64_t var_1b0h;
    int64_t var_1a8h;
    int64_t var_198h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    undefined4 uStack_70;
    undefined4 uStack_6c;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_338;
    var_304h = 0;
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    var_300h = arg1;
    var_2e0h = arg4;
    var_2d8h = arg3;
    var_1a8h = arg1;
    iVar10 = func_0x000180459890(0x60);
    *(int64_t *)iVar10 = iVar10;
    *(int64_t *)(iVar10 + 8) = iVar10;
    *(int64_t *)(iVar10 + 0x10) = iVar10;
    *(undefined2 *)(iVar10 + 0x18) = 0x101;
    *(int64_t *)arg1 = iVar10;
    _var_2f8h = ZEXT816(0);
    var_2e8h = 0;
    var_298h = 0x18063d288;
    var_200h = 0;
    var_1f8h = 0;
    var_1f0h._0_4_ = 0;
    _var_1e8h = ZEXT816(0);
    _var_1d8h = ZEXT816(0);
    var_1c8h = 0;
    var_208h = 0x1804a54e0;
    var_1c0h = 0;
    var_1b8h = 0;
    var_1b0h._0_1_ = 0;
    var_304h = 0x11;
    func_0x00018000fce0(&var_298h, &var_288h, 0, 0);
    *(undefined8 *)((int64_t)&var_298h + (int64_t)*(int32_t *)(var_298h + 4)) = 0x1804a5868;
    *(int32_t *)((int64_t)&var_2a0h + (int64_t)*(int32_t *)(var_298h + 4) + 4) = *(int32_t *)(var_298h + 4) + -0x90;
    func_0x00018007d9f0(&var_288h, arg2, 1);
    var_68h = 0;
    var_60h = 0xf;
    stack0xffffffffffffff89 = SUB1615(ZEXT816(0), 1);
    auVar5[15] = 0;
    auVar5._0_15_ = stack0xffffffffffffff89;
    _var_78h = auVar5 << 8;
    piVar11 = (int64_t *)func_0x00018007d3a0(&var_298h, &var_78h, 10);
    uVar2 = *(uint8_t *)((int64_t)*(int32_t *)(*piVar11 + 4) + 0x10 + (int64_t)piVar11);
    while ((uVar2 & 6) == 0) {
        if (var_2f0h == var_2e8h) {
            func_0x00018007e850(&var_2f8h, var_2f0h, &var_78h);
        } else {
            func_0x00018000b4d0(var_2f0h, &var_78h);
            var_2f0h = var_2f0h + 0x20;
        }
        piVar11 = (int64_t *)func_0x00018007d3a0(&var_298h, &var_78h, 10);
        uVar2 = *(uint8_t *)((int64_t)*(int32_t *)(*piVar11 + 4) + 0x10 + (int64_t)piVar11);
    }
    if (0xf < (uint64_t)var_60h) {
        uVar20 = var_60h + 1;
        if (0xfff < uVar20) {
            piVar11 = (int64_t *)(var_78h + -8);
            iVar10 = var_78h - *piVar11;
            puVar22 = auStack_338;
            if (0x1f < iVar10 - 8U) {
code_r0x00018016fe28:
                pcVar4 = (code *)swi(0x29);
                (*pcVar4)(5);
                puVar22 = puVar22 + 8;
                goto code_r0x00018016fe2f;
            }
            uVar20 = var_60h + 0x28;
            var_78h = *piVar11;
        }
        iVar10 = var_78h;
        func_0x000180459c3c(iVar10, uVar20);
    }
    var_2c8h = var_2f0h;
    puVar22 = auStack_338;
    ppuVar29 = (uint8_t **)var_2f8h;
    uVar26 = var_308h;
    uVar21 = var_308h;
    uVar23 = 0x11;
    if (var_2f8h != var_2f0h) {
        do {
            _var_78h = ZEXT816(0);
            var_68h = 0;
            var_60h = 0;
            puVar27 = (uint8_t *)0x5;
            if (ppuVar29[2] < (uint8_t *)0x5) {
                puVar27 = ppuVar29[2];
            }
            ppuVar13 = ppuVar29;
            if ((uint8_t *)0xf < ppuVar29[3]) {
                ppuVar13 = (uint8_t **)*ppuVar29;
            }
            func_0x000180004830(&var_78h, ppuVar13, puVar27);
            iVar16 = var_60h;
            var_304h = uVar23 | 2;
            iVar10 = var_78h;
            piVar11 = &var_78h;
            if (0xf < (uint64_t)var_60h) {
                piVar11 = (int64_t *)var_78h;
            }
            if (var_68h == 5) {
                iVar9 = func_0x000180497f30(piVar11, 0x1804a5870);
                bVar31 = iVar9 == 0;
            } else {
                bVar31 = false;
            }
            if (0xf < (uint64_t)iVar16) {
                uVar20 = iVar16 + 1;
                iVar24 = iVar10;
                if (0xfff < uVar20) {
                    iVar24 = *(int64_t *)(iVar10 + -8);
                    puVar22 = auStack_338;
                    if (0x1f < (iVar10 - iVar24) - 8U) goto code_r0x00018016fe28;
                    uVar20 = iVar16 + 0x28;
                }
                func_0x000180459c3c(iVar24, uVar20);
            }
            iVar10 = var_2d8h;
            if (bVar31) {
                if ((var_2d8h != 0) || (var_2e0h != 0)) {
                    ppuVar13 = ppuVar29;
                    if ((uint8_t *)0xf < ppuVar29[3]) {
                        ppuVar13 = (uint8_t **)*ppuVar29;
                    }
                    if (ppuVar29[2] == (uint8_t *)0x0) {
code_r0x00018016f5e3:
                        iVar16 = -1;
                    } else {
                        puVar12 = ppuVar29[2] + -1;
                        puVar27 = (uint8_t *)0xffffffffffffffff;
                        if (puVar12 != (uint8_t *)0xffffffffffffffff) {
                            puVar27 = puVar12;
                        }
                        if (puVar27 + 5 < (uint8_t *)0x10) {
                            func_0x0001804986e0(&var_198h, 0, 0x100);
                            puVar12 = (uint8_t *)0x1804a5878;
                            do {
                                *(undefined *)((int64_t)&var_198h + (uint64_t)*puVar12) = 1;
                                puVar12 = puVar12 + 1;
                            } while (puVar12 != (uint8_t *)0x1804a587c);
                            ppuVar17 = (uint8_t **)(puVar27 + (int64_t)ppuVar13);
                            cVar8 = *(char *)((int64_t)&var_198h + (uint64_t)*(uint8_t *)ppuVar17);
                            while (uVar21 = var_308h, cVar8 != '\0') {
                                if (ppuVar17 == ppuVar13) goto code_r0x00018016f5e3;
                                ppuVar17 = (uint8_t **)((int64_t)ppuVar17 + -1);
                                cVar8 = *(char *)((int64_t)&var_198h + (uint64_t)*(uint8_t *)ppuVar17);
                            }
                            iVar16 = (int64_t)ppuVar17 - (int64_t)ppuVar13;
                        } else {
                            iVar16 = func_0x0001804580e0(ppuVar13, puVar27 + 1, 0x1804a5878, 4);
                        }
                    }
                    puVar27 = ppuVar29[2];
                    puVar12 = puVar27;
                    if ((uint8_t *)(iVar16 + 1U) < puVar27) {
                        puVar12 = (uint8_t *)(iVar16 + 1U);
                    }
                    if (puVar27 < puVar12) {
                        uVar20 = (int64_t)puVar12 - (int64_t)puVar27;
                        if ((uint64_t)((int64_t)ppuVar29[3] - (int64_t)puVar27) < uVar20) {
                            var_318h._0_1_ = 0;
                            func_0x00018000f2f0(ppuVar29, uVar20, uVar26, uVar20);
                        } else {
                            ppuVar29[2] = puVar12;
                            ppuVar13 = ppuVar29;
                            if ((uint8_t *)0xf < ppuVar29[3]) {
                                ppuVar13 = (uint8_t **)*ppuVar29;
                            }
                            func_0x0001804986e0(puVar27 + (int64_t)ppuVar13, 0, uVar20);
                            (puVar27 + (int64_t)ppuVar13)[uVar20] = 0;
                        }
                    } else {
                        ppuVar29[2] = puVar12;
                        ppuVar13 = ppuVar29;
                        if ((uint8_t *)0xf < ppuVar29[3]) {
                            ppuVar13 = (uint8_t **)*ppuVar29;
                        }
                        puVar12[(int64_t)ppuVar13] = 0;
                    }
                    if ((iVar10 != 0) && ((uint8_t **)iVar10 != ppuVar29)) {
                        ppuVar13 = ppuVar29;
                        if ((uint8_t *)0xf < ppuVar29[3]) {
                            ppuVar13 = (uint8_t **)*ppuVar29;
                        }
                        func_0x00018000f180(iVar10, ppuVar13, ppuVar29[2]);
                    }
                    iVar10 = var_2e0h;
                    if (var_2e0h != 0) {
                        puVar27 = ppuVar29[2];
                        ppuVar13 = ppuVar29;
                        if ((uint8_t *)0xf < ppuVar29[3]) {
                            ppuVar13 = (uint8_t **)*ppuVar29;
                        }
                        if (puVar27 != (uint8_t *)0x0) {
                            if (puVar27 + 2 < (uint8_t *)0x10) {
                                func_0x0001804986e0(&var_198h, 0, 0x100);
                                puVar12 = (uint8_t *)0x1804a5880;
                                do {
                                    *(undefined *)((int64_t)&var_198h + (uint64_t)*puVar12) = 1;
                                    puVar12 = puVar12 + 1;
                                    ppuVar17 = ppuVar13;
                                } while (puVar12 != (uint8_t *)0x1804a5882);
                                for (; arg1 = var_300h, ppuVar17 < puVar27 + (int64_t)ppuVar13;
                                    ppuVar17 = (uint8_t **)((int64_t)ppuVar17 + 1)) {
                                    if (*(char *)((int64_t)&var_198h + (uint64_t)*(uint8_t *)ppuVar17) != '\0') {
                                        iVar16 = (int64_t)ppuVar17 - (int64_t)ppuVar13;
                                        goto code_r0x00018016f80b;
                                    }
                                }
                            } else {
                                iVar16 = func_0x000180458040(ppuVar13, puVar27, 0x1804a5880, 2);
code_r0x00018016f80b:
                                if ((iVar16 != -1) &&
                                   (iVar16 = func_0x0001800147e0(ppuVar29, 0x1804a5880, iVar16 + 1), iVar16 != -1)) {
                                    puVar27 = ppuVar29[2];
                                    puVar12 = (uint8_t *)(iVar16 + 1);
                                    if (puVar27 < (uint8_t *)(iVar16 + 1)) {
                                        puVar12 = puVar27;
                                    }
                                    ppuVar13 = ppuVar29;
                                    if ((uint8_t *)0xf < ppuVar29[3]) {
                                        ppuVar13 = (uint8_t **)*ppuVar29;
                                    }
                                    puVar27 = puVar27 + -(int64_t)puVar12;
                                    func_0x000180498030(ppuVar13, (uint8_t *)((int64_t)ppuVar13 + (int64_t)puVar12), 
                                                        puVar27 + 1);
                                    ppuVar29[2] = puVar27;
                                    if ((uint8_t **)iVar10 != ppuVar29) {
                                        ppuVar13 = ppuVar29;
                                        if ((uint8_t *)0xf < ppuVar29[3]) {
                                            ppuVar13 = (uint8_t **)*ppuVar29;
                                        }
                                        func_0x00018000f180(iVar10, ppuVar13, puVar27);
                                    }
                                }
                            }
                        }
                    }
                }
                iVar10 = *(int64_t *)arg1;
                func_0x000180015170(arg1, arg1, *(undefined8 *)(iVar10 + 8));
                *(int64_t *)(iVar10 + 8) = iVar10;
                *(int64_t *)iVar10 = iVar10;
                *(int64_t *)(iVar10 + 0x10) = iVar10;
                *(int64_t *)(arg1 + 8) = 0;
            }
            if (ppuVar29[2] != (uint8_t *)0x0) {
                ppuVar13 = ppuVar29;
                if ((uint8_t *)0xf < ppuVar29[3]) {
                    ppuVar13 = (uint8_t **)*ppuVar29;
                }
                puVar27 = ppuVar29[2] + (int64_t)ppuVar13;
                puVar12 = (uint8_t *)func_0x0001804580f0(ppuVar13, puVar27, 0x3a);
                var_2d0h = -1;
                if (puVar12 != puVar27) {
                    var_2d0h = (int64_t)puVar12 - (int64_t)ppuVar13;
                }
                if (var_2d0h != -1) {
                    puVar27 = (uint8_t *)(var_2d0h + 1);
                    _var_98h = ZEXT816(0);
                    var_88h = 0;
                    var_80h = 0;
                    if (ppuVar29[2] < puVar27) {
                        func_0x00018000f930();
                        goto code_r0x00018016ff2d;
                    }
                    iVar16 = (int64_t)ppuVar29[2] - (int64_t)puVar27;
                    iVar10 = -1;
                    if (iVar16 != -1) {
                        iVar10 = iVar16;
                    }
                    ppuVar13 = ppuVar29;
                    if ((uint8_t *)0xf < ppuVar29[3]) {
                        ppuVar13 = (uint8_t **)*ppuVar29;
                    }
                    func_0x000180004830(&var_98h, puVar27 + (int64_t)ppuVar13, iVar10);
                    uVar20 = var_88h;
                    var_304h = var_304h | 4;
                    piVar11 = (int64_t *)var_98h;
                    piVar18 = &var_98h;
                    if (0xf < (uint64_t)var_80h) {
                        piVar18 = (int64_t *)var_98h;
                    }
                    if (var_88h == 0) {
code_r0x00018016fa15:
                        uVar14 = 0xffffffffffffffff;
                    } else {
                        if (var_88h + 2U < 0x10) {
                            piVar1 = (int64_t *)(var_88h + (int64_t)piVar18);
                            func_0x0001804986e0(&var_198h, 0, 0x100);
                            puVar27 = (uint8_t *)0x1804a5880;
                            do {
                                *(undefined *)((int64_t)&var_198h + (uint64_t)*puVar27) = 1;
                                puVar27 = puVar27 + 1;
                                piVar7 = piVar18;
                            } while (puVar27 != (uint8_t *)0x1804a5882);
                            for (; uVar21 = var_308h, piVar7 < piVar1; piVar7 = (int64_t *)((int64_t)piVar7 + 1)) {
                                if (*(char *)((int64_t)&var_198h + (uint64_t)*(uint8_t *)piVar7) == '\0') {
                                    uVar14 = (int64_t)piVar7 - (int64_t)piVar18;
                                    goto code_r0x00018016fa1c;
                                }
                            }
                            goto code_r0x00018016fa15;
                        }
                        uVar14 = func_0x000180457f50(piVar18, var_88h, 0x1804a5880, 2);
                        uVar20 = var_88h;
                        piVar11 = (int64_t *)var_98h;
                    }
code_r0x00018016fa1c:
                    if (uVar20 < uVar14) {
                        uVar14 = uVar20;
                    }
                    piVar18 = &var_98h;
                    if (0xf < (uint64_t)var_80h) {
                        piVar18 = piVar11;
                    }
                    uVar20 = uVar20 - uVar14;
                    func_0x000180498030(piVar18, uVar14 + (int64_t)piVar18, uVar20 + 1);
                    uVar14 = var_80h;
                    piVar11 = &var_98h;
                    if (0xf < (uint64_t)var_80h) {
                        piVar11 = (int64_t *)var_98h;
                    }
                    var_88h = uVar20;
                    if (uVar20 == 0) {
                        iVar10 = -1;
                    } else {
                        iVar10 = -1;
                        if (uVar20 - 1 != -1) {
                            iVar10 = uVar20 - 1;
                        }
                        if (iVar10 + 5U < 0x10) {
                            func_0x0001804986e0(&var_198h, 0, 0x100);
                            puVar27 = (uint8_t *)0x1804a5878;
                            do {
                                *(undefined *)((int64_t)&var_198h + (uint64_t)*puVar27) = 1;
                                puVar27 = puVar27 + 1;
                            } while (puVar27 != (uint8_t *)0x1804a587c);
                            piVar18 = (int64_t *)(iVar10 + (int64_t)piVar11);
                            cVar8 = *(char *)((int64_t)&var_198h + (uint64_t)*(uint8_t *)piVar18);
                            while (uVar26 = var_308h, cVar8 != '\0') {
                                if (piVar18 == piVar11) {
                                    iVar10 = -1;
                                    goto code_r0x00018016fb38;
                                }
                                piVar18 = (int64_t *)((int64_t)piVar18 + -1);
                                cVar8 = *(char *)((int64_t)&var_198h + (uint64_t)*(uint8_t *)piVar18);
                            }
                            iVar10 = (int64_t)piVar18 - (int64_t)piVar11;
                        } else {
                            iVar10 = func_0x0001804580e0(piVar11, iVar10 + 1, 0x1804a5878, 4);
                            uVar20 = var_88h;
                            uVar14 = var_80h;
                        }
code_r0x00018016fb38:
                    }
                    uVar19 = uVar20;
                    if (iVar10 + 1U < uVar20) {
                        uVar19 = iVar10 + 1U;
                    }
                    if (uVar20 < uVar19) {
                        uVar30 = uVar19 - uVar20;
                        if (uVar14 - uVar20 < uVar30) {
                            var_318h._0_1_ = 0;
                            func_0x00018000f2f0(&var_98h, uVar30, uVar21, uVar30);
                        } else {
                            piVar11 = &var_98h;
                            if (0xf < uVar14) {
                                piVar11 = (int64_t *)var_98h;
                            }
                            var_88h = uVar19;
                            func_0x0001804986e0(uVar20 + (int64_t)piVar11, 0, uVar30);
                            *(undefined *)(uVar20 + (int64_t)piVar11 + uVar30) = 0;
                        }
                    } else {
                        piVar11 = &var_98h;
                        if (0xf < uVar14) {
                            piVar11 = (int64_t *)var_98h;
                        }
                        var_88h = uVar19;
                        *(undefined *)(uVar19 + (int64_t)piVar11) = 0;
                    }
                    _var_78h = ZEXT816(0);
                    var_68h = 0;
                    var_60h = 0;
                    puVar27 = (uint8_t *)var_2d0h;
                    if (ppuVar29[2] < (uint64_t)var_2d0h) {
                        puVar27 = ppuVar29[2];
                    }
                    ppuVar13 = ppuVar29;
                    if ((uint8_t *)0xf < ppuVar29[3]) {
                        ppuVar13 = (uint8_t **)*ppuVar29;
                    }
                    func_0x000180004830(&var_78h, ppuVar13, puVar27);
                    iVar10 = var_300h;
                    var_304h = var_304h | 8;
                    puVar15 = *(undefined8 **)var_300h;
                    puVar28 = (undefined8 *)puVar15[1];
                    puVar25 = puVar28;
                    if (*(char *)((int64_t)puVar28 + 0x19) == '\0') {
                        do {
                            puVar28 = puVar25;
                            cVar8 = func_0x00018016b240(iVar10, puVar28 + 4, &var_78h);
                            if (cVar8 == '\0') {
                                puVar25 = (undefined8 *)*puVar28;
                                puVar15 = puVar28;
                            } else {
                                puVar25 = (undefined8 *)puVar28[2];
                            }
                            uVar23 = (uint32_t)(cVar8 == '\0');
                            uVar26 = var_308h;
                        } while (*(char *)((int64_t)puVar25 + 0x19) == '\0');
                    } else {
                        uVar23 = 0;
                    }
                    if ((*(char *)((int64_t)puVar15 + 0x19) != '\0') ||
                       (cVar8 = func_0x00018016b240(var_300h, &var_78h, puVar15 + 4), cVar8 != '\0')) {
                        iVar10 = var_300h;
                        if (*(int64_t *)(var_300h + 8) == 0x2aaaaaaaaaaaaaa) {
code_r0x00018016ff2d:
                            func_0x000180013c00();
                            pcVar4 = (code *)swi(3);
                            (*pcVar4)();
                            return;
                        }
                        uVar3 = *(undefined8 *)var_300h;
                        var_2a8h = var_300h;
                        var_2a0h = 0;
                        puVar15 = (undefined8 *)func_0x000180459890(0x60);
                        *(undefined4 *)(puVar15 + 4) = (undefined4)var_78h;
                        *(undefined4 *)((int64_t)puVar15 + 0x24) = var_78h._4_4_;
                        *(undefined4 *)(puVar15 + 5) = uStack_70;
                        *(undefined4 *)((int64_t)puVar15 + 0x2c) = uStack_6c;
                        *(undefined4 *)(puVar15 + 6) = (undefined4)var_68h;
                        *(undefined4 *)((int64_t)puVar15 + 0x34) = var_68h._4_4_;
                        *(undefined4 *)(puVar15 + 7) = (undefined4)var_60h;
                        *(undefined4 *)((int64_t)puVar15 + 0x3c) = var_60h._4_4_;
                        var_68h = 0;
                        var_60h = 0xf;
                        auVar6[15] = 0;
                        auVar6._0_15_ = stack0xffffffffffffff89;
                        _var_78h = auVar6 << 8;
                        *(undefined (*) [16])(puVar15 + 8) = ZEXT816(0);
                        puVar15[10] = 0;
                        puVar15[0xb] = 0xf;
                        *(undefined *)(puVar15 + 8) = 0;
                        *puVar15 = uVar3;
                        puVar15[1] = uVar3;
                        puVar15[2] = uVar3;
                        *(undefined2 *)(puVar15 + 3) = 0;
                        var_2a0h = 0;
                        var_2b0h._4_4_ = var_2f0h._4_4_;
                        var_2b8h = (int64_t)puVar28;
                        var_2b0h._0_4_ = uVar23;
                        puVar15 = (undefined8 *)func_0x0001800156d0(iVar10, &var_2b8h);
                    }
                    if (puVar15 + 8 != &var_98h) {
                        piVar11 = &var_98h;
                        if (0xf < (uint64_t)var_80h) {
                            piVar11 = (int64_t *)var_98h;
                        }
                        func_0x00018000f180(puVar15 + 8, piVar11, var_88h);
                    }
                    if (0xf < (uint64_t)var_60h) {
                        uVar20 = var_60h + 1;
                        iVar10 = var_78h;
                        if (0xfff < uVar20) {
                            iVar10 = *(int64_t *)(var_78h + -8);
                            if (0x1f < (var_78h - iVar10) - 8U) {
                                pcVar4 = (code *)swi(0x29);
                                (*pcVar4)(5);
                                puVar22 = auStack_330;
                                goto code_r0x00018016fe28;
                            }
                            uVar20 = var_60h + 0x28;
                        }
                        func_0x000180459c3c(iVar10, uVar20);
                    }
                    arg1 = var_300h;
                    if (0xf < (uint64_t)var_80h) {
                        uVar20 = var_80h + 1;
                        iVar10 = var_98h;
                        if (0xfff < uVar20) {
                            iVar10 = *(int64_t *)(var_98h + -8);
                            puVar22 = auStack_338;
                            if (0x1f < (var_98h - iVar10) - 8U) goto code_r0x00018016fe28;
                            uVar20 = var_80h + 0x28;
                        }
                        func_0x000180459c3c(iVar10, uVar20);
                        arg1 = var_300h;
                    }
                }
            }
            ppuVar29 = ppuVar29 + 4;
            puVar22 = auStack_338;
            uVar23 = var_304h;
        } while (ppuVar29 != (uint8_t **)var_2c8h);
    }
code_r0x00018016fe2f:
    *(undefined8 *)((int64_t)&var_298h + (int64_t)*(int32_t *)(var_298h + 4)) = 0x1804a5868;
    *(int32_t *)((int64_t)&var_2a0h + (int64_t)*(int32_t *)(var_298h + 4) + 4) = *(int32_t *)(var_298h + 4) + -0x90;
    *(undefined8 *)(puVar22 + -8) = 0x18016fe5e;
    func_0x00018000c970(&var_288h);
    *(undefined8 *)((int64_t)&var_298h + (int64_t)*(int32_t *)(var_298h + 4)) = 0x1804a5600;
    *(int32_t *)((int64_t)&var_2a0h + (int64_t)*(int32_t *)(var_298h + 4) + 4) = *(int32_t *)(var_298h + 4) + -0x18;
    var_208h = 0x1804a54d0;
    *(undefined8 *)(puVar22 + -8) = 0x18016fe95;
    func_0x000180455c14(&var_208h);
    uVar20 = *(uint64_t *)(puVar22 + 0x40);
    if (uVar20 != 0) {
        uVar14 = *(uint64_t *)(puVar22 + 0x48);
        if (uVar20 != uVar14) {
            do {
                *(undefined8 *)(puVar22 + -8) = 0x18016feb8;
                func_0x000180004e40(uVar20);
                uVar20 = uVar20 + 0x20;
            } while (uVar20 != uVar14);
            uVar20 = *(uint64_t *)(puVar22 + 0x40);
        }
        uVar14 = uVar20;
        if (0xfff < (*(int64_t *)(puVar22 + 0x50) - uVar20 & 0xffffffffffffffe0)) {
            uVar14 = *(uint64_t *)(uVar20 - 8);
            uVar20 = (uVar20 - uVar14) - 8;
            if (0x1f < uVar20) {
                pcVar4 = (code *)swi(0x29);
                (*pcVar4)(5);
                puVar22 = puVar22 + 8;
                uVar14 = uVar20;
            }
        }
        *(undefined8 *)(puVar22 + -8) = 0x18016ff01;
        func_0x000180459c3c(uVar14);
    }
    *(undefined8 *)(puVar22 + -8) = 0x18016ff13;
    func_0x000180459870(var_58h ^ (uint64_t)puVar22);
    return;
}

// ============================================================
// Function: FUN_18016ff40
// Address: 0x18016ff40
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18016ff40(int64_t arg1)
{
    int64_t iVar1;
    undefined *puVar2;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg1 + 0x10);
    if (iVar1 != 0) {
        puVar2 = (undefined *)arg1;
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            puVar2 = *(undefined **)arg1;
        }
        for (; iVar1 != 0; iVar1 = iVar1 + -1) {
            *puVar2 = 0;
            puVar2 = puVar2 + 1;
        }
        *(undefined8 *)(arg1 + 0x10) = 0;
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            arg1 = *(int64_t *)arg1;
        }
        *(undefined *)arg1 = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18016ff55
// Address: 0x18016ff55
// Size: 31 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18016ff40(int64_t arg1)
{
    int64_t iVar1;
    undefined *puVar2;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg1 + 0x10);
    if (iVar1 != 0) {
        puVar2 = (undefined *)arg1;
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            puVar2 = *(undefined **)arg1;
        }
        for (; iVar1 != 0; iVar1 = iVar1 + -1) {
            *puVar2 = 0;
            puVar2 = puVar2 + 1;
        }
        *(undefined8 *)(arg1 + 0x10) = 0;
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            arg1 = *(int64_t *)arg1;
        }
        *(undefined *)arg1 = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18016ff74
// Address: 0x18016ff74
// Size: 10 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18016ff40(int64_t arg1)
{
    int64_t iVar1;
    undefined *puVar2;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg1 + 0x10);
    if (iVar1 != 0) {
        puVar2 = (undefined *)arg1;
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            puVar2 = *(undefined **)arg1;
        }
        for (; iVar1 != 0; iVar1 = iVar1 + -1) {
            *puVar2 = 0;
            puVar2 = puVar2 + 1;
        }
        *(undefined8 *)(arg1 + 0x10) = 0;
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            arg1 = *(int64_t *)arg1;
        }
        *(undefined *)arg1 = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18016ff80
// Address: 0x18016ff80
// Size: 578 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18016ff80(int64_t arg1, int64_t arg2)
{
    uint8_t uVar1;
    code *pcVar2;
    undefined auVar3 [16];
    int64_t *piVar4;
    int64_t iVar5;
    undefined *puVar6;
    undefined in_R8B;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_178 [8];
    undefined auStack_170 [24];
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int32_t iStack_13c;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    undefined auStack_78 [16];
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar6 = auStack_178;
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_178;
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    var_148h = 0x1804a5628;
    var_138h = 0x1804a5630;
    var_a8h = 0;
    var_a0h = 0;
    var_98h._0_4_ = 0;
    var_90h = 0;
    _var_88h = ZEXT816(0);
    auStack_78 = ZEXT816(0);
    var_b0h = 0x1804a54e0;
    _var_68h = ZEXT816(0);
    var_58h._0_1_ = 0;
    var_158h._0_4_ = 3;
    var_150h = arg1;
    func_0x00018000fce0(&var_148h, &var_130h, 0, 0);
    *(undefined8 *)((int64_t)&var_138h + (int64_t)*(int32_t *)(var_138h + 4)) = 0x1804a54f0;
    *(int32_t *)((int64_t)&iStack_13c + (int64_t)*(int32_t *)(var_138h + 4)) = *(int32_t *)(var_138h + 4) + -0x10;
    *(undefined8 *)((int64_t)&var_148h + (int64_t)*(int32_t *)(var_148h + 4)) = 0x1804a5610;
    *(int32_t *)((int64_t)&var_150h + (int64_t)*(int32_t *)(var_148h + 4) + 4) = *(int32_t *)(var_148h + 4) + -0x20;
    *(undefined8 *)((int64_t)&var_148h + (int64_t)*(int32_t *)(var_148h + 4)) = 0x1804a5620;
    *(int32_t *)((int64_t)&var_150h + (int64_t)*(int32_t *)(var_148h + 4) + 4) = *(int32_t *)(var_148h + 4) + -0x98;
    func_0x00018007d9f0(&var_130h, arg2, 3);
    var_38h = 0;
    var_30h = 0xf;
    stack0xffffffffffffffb9 = SUB1615(ZEXT816(0), 1);
    auVar3[15] = 0;
    auVar3._0_15_ = stack0xffffffffffffffb9;
    _var_48h = auVar3 << 8;
    piVar4 = (int64_t *)func_0x00018007d3a0(&var_148h, &var_48h, in_R8B);
    uVar1 = *(uint8_t *)((int64_t)*(int32_t *)(*piVar4 + 4) + 0x10 + (int64_t)piVar4);
    while ((uVar1 & 6) == 0) {
        iVar5 = *(int64_t *)(arg1 + 8);
        if (iVar5 == *(int64_t *)(arg1 + 0x10)) {
            func_0x00018007e850(arg1, iVar5, &var_48h);
        } else {
            func_0x00018000b4d0(iVar5, &var_48h);
            *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 0x20;
        }
        piVar4 = (int64_t *)func_0x00018007d3a0(&var_148h, &var_48h, in_R8B);
        uVar1 = *(uint8_t *)((int64_t)*(int32_t *)(*piVar4 + 4) + 0x10 + (int64_t)piVar4);
    }
    if (0xf < (uint64_t)var_30h) {
        iVar5 = var_48h;
        puVar6 = auStack_178;
        if ((0xfff < var_30h + 1U) &&
           (iVar5 = *(int64_t *)(var_48h + -8), puVar6 = auStack_178, 0x1f < (var_48h - iVar5) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar5 = (*pcVar2)(5);
            puVar6 = auStack_170;
        }
        *(undefined8 *)(puVar6 + -8) = 0x18017018f;
        func_0x000180459c3c(iVar5);
    }
    *(undefined8 *)(puVar6 + -8) = 0x18017019a;
    func_0x00018016b9c0(puVar6 + 0x30);
    *(undefined8 *)(puVar6 + -8) = 0x1801701a9;
    func_0x000180459870(var_28h ^ (uint64_t)puVar6);
    return;
}

// ============================================================
// Function: FUN_1801701d0
// Address: 0x1801701d0
// Size: 36 bytes
// ============================================================
int64_t fcn.1801701d0(int64_t arg1, int64_t arg2, int64_t placeholder_2, int64_t arg4)
{
    int64_t in_stack_00000020;
    
    fcn.18000d970(in_stack_00000020);
    return arg2 * placeholder_2;
}

// ============================================================
// Function: FUN_180170200
// Address: 0x180170200
// Size: 42 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180170200(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_48h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int32_t iVar4;
    undefined4 uVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    arg1 = *(int64_t *)arg1;
    *(undefined4 *)(arg2 + 8) = 0;
    *(int64_t *)(arg2 + 0x10) = arg1;
    piVar8 = *(int64_t **)(arg1 + 8);
    *(int64_t **)arg2 = piVar8;
    if (*(char *)((int64_t)piVar8 + 0x19) == '\0') {
        uVar1 = *(uint64_t *)(arg3 + 0x10);
        uVar2 = *(uint64_t *)(arg3 + 0x18);
        do {
            *(int64_t **)arg2 = piVar8;
            piVar6 = piVar8 + 4;
            iVar7 = arg3;
            if (0xf < uVar2) {
                iVar7 = *(int64_t *)arg3;
            }
            uVar3 = piVar8[6];
            if (0xf < (uint64_t)piVar8[7]) {
                piVar6 = (int64_t *)*piVar6;
            }
            uVar9 = uVar3;
            if (uVar1 < uVar3) {
                uVar9 = uVar1;
            }
            iVar4 = func_0x000180497f30(piVar6, iVar7, uVar9);
            if (iVar4 == 0) {
                if (uVar1 <= uVar3) goto code_r0x000180170279;
code_r0x0001801702ae:
                uVar5 = 0;
                piVar8 = piVar8 + 2;
            } else {
                if (iVar4 < 0) goto code_r0x0001801702ae;
code_r0x000180170279:
                *(int64_t **)(arg2 + 0x10) = piVar8;
                uVar5 = 1;
            }
            piVar8 = (int64_t *)*piVar8;
            *(undefined4 *)(arg2 + 8) = uVar5;
        } while (*(char *)((int64_t)piVar8 + 0x19) == '\0');
    }
    return arg2;
}

// ============================================================
// Function: FUN_18017022a
// Address: 0x18017022a
// Size: 115 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180170200(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_48h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int32_t iVar4;
    undefined4 uVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    arg1 = *(int64_t *)arg1;
    *(undefined4 *)(arg2 + 8) = 0;
    *(int64_t *)(arg2 + 0x10) = arg1;
    piVar8 = *(int64_t **)(arg1 + 8);
    *(int64_t **)arg2 = piVar8;
    if (*(char *)((int64_t)piVar8 + 0x19) == '\0') {
        uVar1 = *(uint64_t *)(arg3 + 0x10);
        uVar2 = *(uint64_t *)(arg3 + 0x18);
        do {
            *(int64_t **)arg2 = piVar8;
            piVar6 = piVar8 + 4;
            iVar7 = arg3;
            if (0xf < uVar2) {
                iVar7 = *(int64_t *)arg3;
            }
            uVar3 = piVar8[6];
            if (0xf < (uint64_t)piVar8[7]) {
                piVar6 = (int64_t *)*piVar6;
            }
            uVar9 = uVar3;
            if (uVar1 < uVar3) {
                uVar9 = uVar1;
            }
            iVar4 = func_0x000180497f30(piVar6, iVar7, uVar9);
            if (iVar4 == 0) {
                if (uVar1 <= uVar3) goto code_r0x000180170279;
code_r0x0001801702ae:
                uVar5 = 0;
                piVar8 = piVar8 + 2;
            } else {
                if (iVar4 < 0) goto code_r0x0001801702ae;
code_r0x000180170279:
                *(int64_t **)(arg2 + 0x10) = piVar8;
                uVar5 = 1;
            }
            piVar8 = (int64_t *)*piVar8;
            *(undefined4 *)(arg2 + 8) = uVar5;
        } while (*(char *)((int64_t)piVar8 + 0x19) == '\0');
    }
    return arg2;
}

// ============================================================
// Function: FUN_18017029d
// Address: 0x18017029d
// Size: 12 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180170200(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_48h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int32_t iVar4;
    undefined4 uVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    arg1 = *(int64_t *)arg1;
    *(undefined4 *)(arg2 + 8) = 0;
    *(int64_t *)(arg2 + 0x10) = arg1;
    piVar8 = *(int64_t **)(arg1 + 8);
    *(int64_t **)arg2 = piVar8;
    if (*(char *)((int64_t)piVar8 + 0x19) == '\0') {
        uVar1 = *(uint64_t *)(arg3 + 0x10);
        uVar2 = *(uint64_t *)(arg3 + 0x18);
        do {
            *(int64_t **)arg2 = piVar8;
            piVar6 = piVar8 + 4;
            iVar7 = arg3;
            if (0xf < uVar2) {
                iVar7 = *(int64_t *)arg3;
            }
            uVar3 = piVar8[6];
            if (0xf < (uint64_t)piVar8[7]) {
                piVar6 = (int64_t *)*piVar6;
            }
            uVar9 = uVar3;
            if (uVar1 < uVar3) {
                uVar9 = uVar1;
            }
            iVar4 = func_0x000180497f30(piVar6, iVar7, uVar9);
            if (iVar4 == 0) {
                if (uVar1 <= uVar3) goto code_r0x000180170279;
code_r0x0001801702ae:
                uVar5 = 0;
                piVar8 = piVar8 + 2;
            } else {
                if (iVar4 < 0) goto code_r0x0001801702ae;
code_r0x000180170279:
                *(int64_t **)(arg2 + 0x10) = piVar8;
                uVar5 = 1;
            }
            piVar8 = (int64_t *)*piVar8;
            *(undefined4 *)(arg2 + 8) = uVar5;
        } while (*(char *)((int64_t)piVar8 + 0x19) == '\0');
    }
    return arg2;
}

// ============================================================
// Function: FUN_1801702a9
// Address: 0x1801702a9
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180170200(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_48h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int32_t iVar4;
    undefined4 uVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    arg1 = *(int64_t *)arg1;
    *(undefined4 *)(arg2 + 8) = 0;
    *(int64_t *)(arg2 + 0x10) = arg1;
    piVar8 = *(int64_t **)(arg1 + 8);
    *(int64_t **)arg2 = piVar8;
    if (*(char *)((int64_t)piVar8 + 0x19) == '\0') {
        uVar1 = *(uint64_t *)(arg3 + 0x10);
        uVar2 = *(uint64_t *)(arg3 + 0x18);
        do {
            *(int64_t **)arg2 = piVar8;
            piVar6 = piVar8 + 4;
            iVar7 = arg3;
            if (0xf < uVar2) {
                iVar7 = *(int64_t *)arg3;
            }
            uVar3 = piVar8[6];
            if (0xf < (uint64_t)piVar8[7]) {
                piVar6 = (int64_t *)*piVar6;
            }
            uVar9 = uVar3;
            if (uVar1 < uVar3) {
                uVar9 = uVar1;
            }
            iVar4 = func_0x000180497f30(piVar6, iVar7, uVar9);
            if (iVar4 == 0) {
                if (uVar1 <= uVar3) goto code_r0x000180170279;
code_r0x0001801702ae:
                uVar5 = 0;
                piVar8 = piVar8 + 2;
            } else {
                if (iVar4 < 0) goto code_r0x0001801702ae;
code_r0x000180170279:
                *(int64_t **)(arg2 + 0x10) = piVar8;
                uVar5 = 1;
            }
            piVar8 = (int64_t *)*piVar8;
            *(undefined4 *)(arg2 + 8) = uVar5;
        } while (*(char *)((int64_t)piVar8 + 0x19) == '\0');
    }
    return arg2;
}

// ============================================================
// Function: FUN_1801702c0
// Address: 0x1801702c0
// Size: 69 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001801702ed: Changing call to branch
// WARNING: Removing unreachable block (ram,0x0001801702f2)
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801702c0(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    int64_t iStack_38;
    undefined8 uStack_30;
    
    *(undefined8 *)arg1 = 0x1804a5720;
    uStack_30 = 0x1801702e0;
    fcn.18016ff40(arg1 + 8);
    uStack_30 = 0x1801702e9;
    fcn.18016ff40(arg1 + 0x28);
    uStack_30 = 0x1801702f2;
    if (0xf < *(uint64_t *)(arg1 + 0x40)) {
        iVar1 = *(int64_t *)(arg1 + 0x28);
        iVar3 = iVar1;
        puVar4 = auStack_58;
        iStack_38 = arg1;
        if ((0xfff < *(uint64_t *)(arg1 + 0x40) + 1) &&
           (iVar3 = *(int64_t *)(iVar1 + -8), puVar4 = auStack_58, 0x1f < (iVar1 - iVar3) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)(5);
            puVar4 = auStack_50;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180004e88;
        func_0x000180459c3c(iVar3);
    }
    *(undefined8 *)(arg1 + 0x38) = 0;
    *(undefined8 *)(arg1 + 0x40) = 0xf;
    *(undefined *)(int64_t *)(arg1 + 0x28) = 0;
    return;
}

// ============================================================
// Function: FUN_180170310
// Address: 0x180170310
// Size: 263 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h

int64_t fcn.180170310(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    code *pcVar2;
    char cVar3;
    undefined8 *puVar4;
    int64_t iVar5;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    
    fcn.180170200(arg1, (int64_t)&var_48h, arg2, var_38h);
    if (*(char *)(var_38h + 0x19) == '\0') {
        cVar3 = func_0x000180170420(arg1, arg2, var_38h + 0x20);
        if (cVar3 == '\0') goto code_r0x000180170402;
    }
    if (*(int64_t *)(arg1 + 8) == 0x1e1e1e1e1e1e1e1) {
        func_0x000180013c00();
        pcVar2 = (code *)swi(3);
        iVar5 = (*pcVar2)();
        return iVar5;
    }
    uVar1 = *(undefined8 *)arg1;
    var_50h = 0;
    var_58h = arg1;
    puVar4 = (undefined8 *)func_0x000180459890(0x88);
    var_50h = (int64_t)puVar4;
    func_0x00018000b4d0(puVar4 + 4, arg2);
    puVar4[8] = 0x1804a5720;
    *(undefined (*) [16])(puVar4 + 9) = ZEXT816(0);
    puVar4[0xb] = 0;
    puVar4[0xc] = 0xf;
    *(undefined *)(puVar4 + 9) = 0;
    *(undefined (*) [16])(puVar4 + 0xd) = ZEXT816(0);
    puVar4[0xf] = 0;
    puVar4[0x10] = 0xf;
    *(undefined *)(puVar4 + 0xd) = 0;
    *puVar4 = uVar1;
    puVar4[1] = uVar1;
    puVar4[2] = uVar1;
    *(undefined2 *)(puVar4 + 3) = 0;
    var_38h = func_0x0001800156d0(arg1, &var_58h, puVar4);
code_r0x000180170402:
    return var_38h + 0x40;
}

// ============================================================
// Function: FUN_180170420
// Address: 0x180170420
// Size: 151 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x00018017047d)
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.180170420(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint8_t uVar3;
    int32_t iVar4;
    uint64_t uVar5;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(arg3 + 0x10);
    if (0xf < *(uint64_t *)(arg3 + 0x18)) {
        arg3 = *(int64_t *)arg3;
    }
    uVar2 = *(uint64_t *)(arg2 + 0x10);
    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
        arg2 = *(int64_t *)arg2;
    }
    uVar5 = uVar2;
    if (uVar1 < uVar2) {
        uVar5 = uVar1;
    }
    uVar5 = func_0x000180497f30(arg2, arg3, uVar5);
    iVar4 = (int32_t)uVar5;
    if (iVar4 == 0) {
        if (uVar2 < uVar1) {
            return 1;
        }
        if (uVar2 <= uVar1) {
            return uVar5 & 0xffffffffffffff00;
        }
        iVar4 = 1;
    }
    uVar3 = 0xff;
    if (-1 < iVar4) {
        uVar3 = 0;
    }
    return (uint64_t)(uVar3 >> 7);
}

// ============================================================
// Function: FUN_1801704c0
// Address: 0x1801704c0
// Size: 28 bytes
// ============================================================
undefined8 * fcn.1801704c0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    undefined8 *puVar2;
    
    iVar1 = fcn.180170310(arg1, arg2);
    puVar2 = (undefined8 *)(iVar1 + 0x28);
    if (0xf < *(uint64_t *)(iVar1 + 0x40)) {
        puVar2 = (undefined8 *)*puVar2;
    }
    return puVar2;
}

// ============================================================
// Function: FUN_1801704e0
// Address: 0x1801704e0
// Size: 28 bytes
// ============================================================
undefined8 * fcn.1801704e0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    undefined8 *puVar2;
    
    iVar1 = fcn.180170310(arg1, arg2);
    puVar2 = (undefined8 *)(iVar1 + 8);
    if (0xf < *(uint64_t *)(iVar1 + 0x20)) {
        puVar2 = (undefined8 *)*puVar2;
    }
    return puVar2;
}

// ============================================================
// Function: FUN_180170500
// Address: 0x180170500
// Size: 85 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined fcn.180170500(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    char cVar2;
    int64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_28h;
    
    iVar1 = fcn.180170200(arg1, (int64_t)&var_28h, arg2, unaff_RDI);
    if (*(char *)(*(int64_t *)(iVar1 + 0x10) + 0x19) == '\0') {
        cVar2 = fcn.180170420(arg1, arg2, *(int64_t *)(iVar1 + 0x10) + 0x20);
        if (cVar2 == '\0') {
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180170560
// Address: 0x180170560
// Size: 132 bytes
// ============================================================
int64_t fcn.180170560(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0;
    fcn.1804986e0(arg1 + 0x20, 0, 0x100);
    iVar2 = fcn.180456008(0x18069c000);
    if (iVar2 != 0) {
        fcn.1804542e8(5);
        pcVar1 = (code *)swi(3);
        iVar4 = (*pcVar1)();
        return iVar4;
    }
    if (*(int32_t *)0x18069c04c != 0x7fffffff) {
        uVar3 = fcn.180416830();
        *(undefined8 *)arg1 = uVar3;
        fcn.180456010(0x18069c000);
        return arg1;
    }
    *(undefined4 *)0x18069c04c = 0x7ffffffe;
    fcn.1804542e8(6);
    pcVar1 = (code *)swi(3);
    iVar4 = (*pcVar1)();
    return iVar4;
}

// ============================================================
// Function: FUN_1801705f0
// Address: 0x1801705f0
// Size: 49 bytes
// ============================================================
void fcn.1801705f0(int64_t arg1, int64_t arg_38h)
{
    int32_t *piStackX_8;
    int64_t var_10h;
    
    fcn.180413cf0(*(undefined8 *)(arg1 + 8));
    fcn.180413cf0(*(undefined8 *)(arg1 + 0x10));
    fcn.180412b80(*(undefined8 *)(arg1 + 0x18));
    piStackX_8 = *(int32_t **)arg1;
    if ((piStackX_8 != (int32_t *)0x0) && (*piStackX_8 == -0x3f212453)) {
        fcn.18041e090(&piStackX_8);
    }
    return;
}

// ============================================================
// Function: FUN_180170630
// Address: 0x180170630
// Size: 180 bytes
// ============================================================
void fcn.180170630(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 *puVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined auStack_78 [40];
    int64_t var_50h;
    int64_t var_48h;
    undefined4 uStack_40;
    undefined4 uStack_3c;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_78;
    puVar1 = (undefined4 *)(arg3 + 0x10);
    if (0xf < *(uint64_t *)(arg3 + 0x18)) {
        arg3 = *(int64_t *)arg3;
    }
    var_50h = arg2;
    iVar2 = func_0x000180416c80(*(undefined8 *)arg1, arg3, *puVar1);
    if (iVar2 == 0) {
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined *)arg2 = 0;
    } else {
        var_38h = 0;
        _var_48h = ZEXT816(0);
        var_30h = 0;
        uVar3 = func_0x000180498cd0(iVar2);
        func_0x000180004830(&var_48h, iVar2, uVar3);
        func_0x000180416dd0(iVar2);
        *(undefined4 *)arg2 = (undefined4)var_48h;
        *(undefined4 *)(arg2 + 4) = var_48h._4_4_;
        *(undefined4 *)(arg2 + 8) = uStack_40;
        *(undefined4 *)(arg2 + 0xc) = uStack_3c;
        *(undefined4 *)(arg2 + 0x10) = (undefined4)var_38h;
        *(undefined4 *)(arg2 + 0x14) = var_38h._4_4_;
        *(undefined4 *)(arg2 + 0x18) = (undefined4)var_30h;
        *(undefined4 *)(arg2 + 0x1c) = var_30h._4_4_;
    }
    func_0x000180459870(var_28h ^ (uint64_t)auStack_78);
    return;
}

// ============================================================
// Function: FUN_1801706f0
// Address: 0x1801706f0
// Size: 937 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801706f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
                  undefined8 placeholder_5, int64_t arg_38h)
{
    uint64_t uVar1;
    code *pcVar2;
    undefined auVar3 [16];
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint64_t uVar12;
    undefined *puVar13;
    undefined *puVar14;
    int64_t var_10h;
    undefined8 uStack_130;
    undefined auStack_128 [8];
    undefined auStack_120 [24];
    int64_t var_108h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    undefined8 uStack_e0;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    undefined4 uStack_c0;
    undefined4 uStack_bc;
    int64_t var_b8h;
    uint64_t uStack_b0;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    undefined4 uStack_80;
    undefined4 uStack_7c;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    undefined4 uStack_60;
    undefined4 uStack_5c;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    puVar14 = auStack_128;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_128;
    var_a0h = arg1;
    var_90h = arg4;
    var_f0h = arg1;
    if (arg2 != arg3) {
        do {
            var_f0h = arg2 + 0x10;
            auVar3 = ZEXT816(0);
            uStack_e0 = 0;
            var_d8h = 0;
            var_d0h = 0;
            uVar1 = *(uint64_t *)(arg2 + 0x20);
            if (0xf < *(uint64_t *)(arg2 + 0x28)) {
                var_f0h = *(int64_t *)var_f0h;
            }
            _var_e8h = auVar3;
            if (0x7fffffffffffffff < uVar1) {
                func_0x0001800047c0();
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
            if (0xf < uVar1) {
                uVar12 = uVar1 | 0xf;
                if (uVar12 < 0x8000000000000000) {
                    if (uVar12 < 0x16) {
                        uVar12 = 0x16;
                    }
                    if (uVar12 == 0xffffffffffffffff) {
                        uVar8 = 0;
                    } else {
                        if (0xfff < uVar12 + 1) {
                            uVar8 = uVar12 + 0x28;
                            if (uVar8 <= uVar12 + 1) goto code_r0x000180170a8d;
                            goto code_r0x0001801707f9;
                        }
                        uVar8 = func_0x000180459890();
                    }
code_r0x000180170820:
                    var_e8h = uVar8;
                    var_d8h = uVar1;
                    var_d0h = uVar12;
                    func_0x000180498030(uVar8, var_f0h, uVar1 + 1);
                    goto code_r0x00018017083f;
                }
                uVar12 = 0x7fffffffffffffff;
                uVar8 = 0x8000000000000027;
code_r0x0001801707f9:
                iVar9 = func_0x000180459890(uVar8);
                puVar13 = auStack_128;
                if (iVar9 != 0) {
                    uVar8 = iVar9 + 0x27U & 0xffffffffffffffe0;
                    *(int64_t *)(uVar8 - 8) = iVar9;
                    goto code_r0x000180170820;
                }
code_r0x000180170a86:
                pcVar2 = (code *)swi(0x29);
                (*pcVar2)(5);
                puVar14 = puVar13 + 8;
code_r0x000180170a8d:
                *(undefined8 *)(puVar14 + -8) = 0x180170a92;
                func_0x000180004720();
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
            var_d0h = 0xf;
            _var_e8h = *(undefined (*) [16])var_f0h;
            var_d8h = uVar1;
code_r0x00018017083f:
            var_f0h = (int64_t)&var_e8h;
            piVar10 = *(int64_t **)arg4;
            var_c8h._0_4_ = *(undefined4 *)arg4;
            var_c8h._4_4_ = *(undefined4 *)(arg4 + 4);
            uStack_c0 = *(undefined4 *)(arg4 + 8);
            uStack_bc = *(undefined4 *)(arg4 + 0xc);
            iVar9 = *(int64_t *)(arg4 + 0x10);
            uStack_b0 = *(uint64_t *)(arg4 + 0x18);
            *(undefined8 *)(arg4 + 0x10) = 0;
            *(undefined8 *)(arg4 + 0x18) = 0xf;
            *(undefined *)arg4 = 0;
            var_98h = (int64_t)&var_c8h;
            if (uStack_b0 - iVar9 < 2) {
                var_108h = 2;
                var_b8h = iVar9;
                piVar10 = (int64_t *)func_0x00018000ee80(&var_c8h, 2, (undefined)var_f8h, 0x180641928);
            } else {
                var_b8h = iVar9 + 2;
                piVar11 = &var_c8h;
                if (0xf < uStack_b0) {
                    piVar11 = piVar10;
                }
                *(undefined2 *)((int64_t)piVar11 + iVar9) = 0x202c;
                *(undefined *)((int64_t)piVar11 + iVar9 + 2) = 0;
                piVar10 = &var_c8h;
            }
            var_68h._0_4_ = *(undefined4 *)piVar10;
            var_68h._4_4_ = *(undefined4 *)((int64_t)piVar10 + 4);
            uStack_60 = *(undefined4 *)(piVar10 + 1);
            uStack_5c = *(undefined4 *)((int64_t)piVar10 + 0xc);
            var_58h._0_4_ = *(undefined4 *)(piVar10 + 2);
            var_58h._4_4_ = *(undefined4 *)((int64_t)piVar10 + 0x14);
            var_50h._0_4_ = *(undefined4 *)(piVar10 + 3);
            var_50h._4_4_ = *(undefined4 *)((int64_t)piVar10 + 0x1c);
            piVar10[2] = 0;
            piVar10[3] = 0xf;
            *(undefined *)piVar10 = 0;
            func_0x00018007d810(&var_88h, (undefined)var_f8h, &var_68h, &var_e8h);
            uVar1 = CONCAT44(var_50h._4_4_, (undefined4)var_50h);
            if (0xf < uVar1) {
                uVar12 = uVar1 + 1;
                iVar7 = CONCAT44(var_68h._4_4_, (undefined4)var_68h);
                iVar9 = iVar7;
                if (0xfff < uVar12) {
                    iVar9 = *(int64_t *)(iVar7 + -8);
                    if (0x1f < (iVar7 - iVar9) - 8U) {
                        pcVar2 = (code *)swi(0x29);
                        (*pcVar2)(5);
                        puVar13 = auStack_120;
                        goto code_r0x000180170a86;
                    }
                    uVar12 = uVar1 + 0x28;
                }
                func_0x000180459c3c(iVar9, uVar12);
            }
            func_0x000180004e40(&var_c8h);
            func_0x000180004e40(&var_e8h);
            if ((int64_t *)arg4 == &var_88h) {
                uVar1 = CONCAT44(var_70h._4_4_, (undefined4)var_70h);
                if (0xf < uVar1) {
                    uVar12 = uVar1 + 1;
                    iVar7 = CONCAT44(var_88h._4_4_, (undefined4)var_88h);
                    iVar9 = iVar7;
                    if (0xfff < uVar12) {
                        iVar9 = *(int64_t *)(iVar7 + -8);
                        puVar13 = auStack_128;
                        if (0x1f < (iVar7 - iVar9) - 8U) goto code_r0x000180170a86;
                        uVar12 = uVar1 + 0x28;
                    }
                    func_0x000180459c3c(iVar9, uVar12);
                }
            } else {
                uVar1 = *(uint64_t *)(arg4 + 0x18);
                if (0xf < uVar1) {
                    iVar9 = *(int64_t *)arg4;
                    uVar12 = uVar1 + 1;
                    if (0xfff < uVar12) {
                        puVar13 = auStack_128;
                        if (0x1f < (iVar9 - *(int64_t *)(iVar9 + -8)) - 8U) goto code_r0x000180170a86;
                        uVar12 = uVar1 + 0x28;
                        iVar9 = *(int64_t *)(iVar9 + -8);
                    }
                    func_0x000180459c3c(iVar9, uVar12);
                }
                *(undefined8 *)(arg4 + 0x18) = 0xf;
                *(undefined *)arg4 = 0;
                *(undefined4 *)arg4 = (undefined4)var_88h;
                *(undefined4 *)(arg4 + 4) = var_88h._4_4_;
                *(undefined4 *)(arg4 + 8) = uStack_80;
                *(undefined4 *)(arg4 + 0xc) = uStack_7c;
                *(undefined4 *)(arg4 + 0x10) = (undefined4)var_78h;
                *(undefined4 *)(arg4 + 0x14) = var_78h._4_4_;
                *(undefined4 *)(arg4 + 0x18) = (undefined4)var_70h;
                *(undefined4 *)(arg4 + 0x1c) = var_70h._4_4_;
            }
            arg2 = *(int64_t *)arg2;
        } while (arg2 != arg3);
    }
    *(undefined (*) [16])var_a0h = ZEXT816(0);
    *(undefined8 *)(var_a0h + 0x10) = 0;
    *(undefined8 *)(var_a0h + 0x18) = 0;
    uVar4 = *(undefined4 *)(arg4 + 4);
    uVar5 = *(undefined4 *)(arg4 + 8);
    uVar6 = *(undefined4 *)(arg4 + 0xc);
    *(undefined4 *)var_a0h = *(undefined4 *)arg4;
    *(undefined4 *)(var_a0h + 4) = uVar4;
    *(undefined4 *)(var_a0h + 8) = uVar5;
    *(undefined4 *)(var_a0h + 0xc) = uVar6;
    uVar4 = *(undefined4 *)(arg4 + 0x14);
    uVar5 = *(undefined4 *)(arg4 + 0x18);
    uVar6 = *(undefined4 *)(arg4 + 0x1c);
    *(undefined4 *)(var_a0h + 0x10) = *(undefined4 *)(arg4 + 0x10);
    *(undefined4 *)(var_a0h + 0x14) = uVar4;
    *(undefined4 *)(var_a0h + 0x18) = uVar5;
    *(undefined4 *)(var_a0h + 0x1c) = uVar6;
    *(undefined8 *)(arg4 + 0x18) = 0xf;
    *(undefined *)arg4 = 0;
    *(undefined8 *)(arg4 + 0x10) = 0;
    *(undefined8 *)(arg4 + 0x18) = 0xf;
    *(undefined *)arg4 = 0;
    func_0x000180459870(var_48h ^ (uint64_t)auStack_128);
    return;
}

// ============================================================
// Function: FUN_180170aa0
// Address: 0x180170aa0
// Size: 81 bytes
// ============================================================
int64_t fcn.180170aa0(int64_t arg1, int64_t arg2)
{
    int64_t var_18h;
    int64_t var_10h;
    
    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
        arg2 = *(int64_t *)arg2;
    }
    *(undefined8 *)arg1 = 0x1804a5358;
    var_10h._0_1_ = 1;
    *(undefined (*) [16])(arg1 + 8) = ZEXT816(0);
    var_18h = arg2;
    fcn.18045b4e4(&var_18h);
    *(undefined8 *)arg1 = 0x1804a5678;
    return arg1;
}

// ============================================================
// Function: FUN_180170b00
// Address: 0x180170b00
// Size: 305 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h

void fcn.180170b00(int64_t arg1)
{
    int64_t **ppiVar1;
    char cVar2;
    code *pcVar3;
    int64_t *piVar4;
    int64_t *piVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    int64_t **ppiVar10;
    uint64_t uVar11;
    undefined auStackY_88 [32];
    int64_t var_68h;
    int64_t var_50h;
    int64_t var_30h;
    int64_t var_10h;
    
    var_10h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_88;
    piVar5 = (int64_t *)(*(int64_t **)0x18077e098)[1];
    cVar2 = *(char *)((int64_t)piVar5 + 0x19);
    piVar4 = *(int64_t **)0x18077e098;
    while (cVar2 == '\0') {
        piVar8 = piVar5;
        if (*(int32_t *)(piVar5 + 4) < 4) {
            piVar5 = piVar5 + 2;
            piVar8 = piVar4;
        }
        piVar5 = (int64_t *)*piVar5;
        piVar4 = piVar8;
        cVar2 = *(char *)((int64_t)piVar5 + 0x19);
    }
    if ((*(char *)((int64_t)piVar4 + 0x19) == '\0') && (*(int32_t *)(piVar4 + 4) < 5)) {
        ppiVar1 = (int64_t **)(piVar4 + 5);
        ppiVar10 = ppiVar1;
        if (0xf < (uint64_t)piVar4[8]) {
            ppiVar10 = (int64_t **)*ppiVar1;
        }
        uVar9 = 0;
        uVar11 = 0xcbf29ce484222325;
        if (piVar4[7] != 0) {
            do {
                uVar11 = (uVar11 ^ *(uint8_t *)((int64_t)ppiVar10 + uVar9)) * 0x100000001b3;
                uVar9 = uVar9 + 1;
            } while (uVar9 < (uint64_t)piVar4[7]);
        }
        iVar6 = func_0x00018001fd20(arg1, &var_68h, ppiVar1, uVar11);
        if (((*(int64_t *)(iVar6 + 8) == 0) || (*(int64_t *)(iVar6 + 8) == *(int64_t *)(arg1 + 8))) ||
           (*(int64_t *)(arg1 + 0x10) == 1)) {
            func_0x000180459870(var_10h ^ (uint64_t)auStackY_88);
            return;
        }
        uVar7 = func_0x000180170c50(arg1, &var_50h);
        iVar6 = func_0x000180038430(&var_30h, 0x1804a5890, uVar7);
        fcn.180170aa0((int64_t)&var_68h, iVar6);
        fcn.18045bae0(var_68h);
    }
    func_0x0001804546f8(0x1804a5900);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_180170c50
// Address: 0x180170c50
// Size: 86 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180170c50(int64_t arg1, int64_t arg2)
{
    int64_t arg4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_48h;
    undefined8 in_stack_ffffffffffffffc0;
    int64_t in_stack_ffffffffffffffc8;
    int64_t var_30h;
    
    arg4 = fcn.18000b4d0(&var_30h, **(int64_t **)(arg1 + 8) + 0x10);
    var_10h._0_1_ = (undefined)arg2;
    fcn.1801706f0(arg2, ***(int64_t ***)(arg1 + 8), (int64_t)*(int64_t ***)(arg1 + 8), arg4, 
                  CONCAT71(var_48h._1_7_, (undefined)var_10h), in_stack_ffffffffffffffc0, in_stack_ffffffffffffffc8);
    return arg2;
}

// ============================================================
// Function: FUN_180170de0
// Address: 0x180170de0
// Size: 1102 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_304h
// WARNING: [rz-ghidra] Detected overlap for variable var_308h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ech
// WARNING: [rz-ghidra] Detected overlap for variable var_2ach

void fcn.180170de0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int64_t *piVar1;
    undefined (*pauVar2) [16];
    int32_t *piVar3;
    undefined (*arg2_00) [16];
    undefined (*arg3_00) [16];
    undefined (*arg4_00) [16];
    int32_t iVar4;
    char cVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    code *pcVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined auVar12 [16];
    int64_t iVar13;
    int64_t *piVar14;
    undefined8 uVar15;
    uint64_t uVar16;
    undefined *puVar17;
    uint64_t uVar18;
    undefined auStackY_c8 [8];
    undefined auStackY_c0 [24];
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    
    puVar17 = auStackY_c8;
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_c8;
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)arg1 = *(undefined8 *)arg2;
    *(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg2 + 8);
    *(undefined8 *)arg2 = 0;
    *(undefined8 *)(arg2 + 8) = 0;
    *(undefined4 *)(arg1 + 0x10) = 0;
    *(undefined (*) [16])(arg1 + 0x18) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x28) = 0;
    *(undefined8 *)(arg1 + 0x30) = 0;
    uVar9 = *(undefined4 *)(arg3 + 4);
    uVar10 = *(undefined4 *)(arg3 + 8);
    uVar11 = *(undefined4 *)(arg3 + 0xc);
    *(undefined4 *)(arg1 + 0x18) = *(undefined4 *)arg3;
    *(undefined4 *)(arg1 + 0x1c) = uVar9;
    *(undefined4 *)(arg1 + 0x20) = uVar10;
    *(undefined4 *)(arg1 + 0x24) = uVar11;
    uVar9 = *(undefined4 *)(arg3 + 0x14);
    uVar10 = *(undefined4 *)(arg3 + 0x18);
    uVar11 = *(undefined4 *)(arg3 + 0x1c);
    *(undefined4 *)(arg1 + 0x28) = *(undefined4 *)(arg3 + 0x10);
    *(undefined4 *)(arg1 + 0x2c) = uVar9;
    *(undefined4 *)(arg1 + 0x30) = uVar10;
    *(undefined4 *)(arg1 + 0x34) = uVar11;
    *(undefined8 *)(arg3 + 0x10) = 0;
    *(undefined8 *)(arg3 + 0x18) = 0xf;
    *(undefined *)arg3 = 0;
    piVar1 = (int64_t *)(arg1 + 0x38);
    *piVar1 = 0;
    *(undefined8 *)(arg1 + 0x40) = 0;
    var_90h = arg2;
    var_88h = arg1;
    var_80h = arg2;
    iVar13 = func_0x000180459890(0x60);
    *(int64_t *)iVar13 = iVar13;
    *(int64_t *)(iVar13 + 8) = iVar13;
    *(int64_t *)(iVar13 + 0x10) = iVar13;
    *(undefined2 *)(iVar13 + 0x18) = 0x101;
    *piVar1 = iVar13;
    pauVar2 = (undefined (*) [16])(arg1 + 0x50);
    *pauVar2 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x60) = 0;
    *(undefined8 *)(arg1 + 0x68) = 0xf;
    (*pauVar2)[0] = 0;
    *(undefined8 *)(arg1 + 0x48) = 0x1804a56f0;
    *(undefined8 *)(arg1 + 0x70) = 0;
    *(undefined *)(arg1 + 0x78) = *(undefined *)arg_28h;
    uVar15 = *(undefined8 *)(arg_28h + 0x18);
    *(undefined8 *)(arg_28h + 0x18) = 0;
    uVar6 = *(undefined8 *)(arg_28h + 0x10);
    *(undefined8 *)(arg_28h + 0x10) = 0;
    uVar7 = *(undefined8 *)(arg_28h + 8);
    *(undefined8 *)(arg_28h + 8) = 0;
    *(undefined8 *)(arg1 + 0x80) = uVar7;
    *(undefined8 *)(arg1 + 0x88) = uVar6;
    *(undefined8 *)(arg1 + 0x90) = uVar15;
    *(undefined4 *)(arg1 + 0x98) = *(undefined4 *)arg_30h;
    *(undefined (*) [16])(arg1 + 0xa0) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0xb0) = 0;
    *(undefined8 *)(arg1 + 0xb8) = 0;
    uVar9 = *(undefined4 *)(arg_30h + 0xc);
    uVar10 = *(undefined4 *)(arg_30h + 0x10);
    uVar11 = *(undefined4 *)(arg_30h + 0x14);
    *(undefined4 *)(arg1 + 0xa0) = *(undefined4 *)(arg_30h + 8);
    *(undefined4 *)(arg1 + 0xa4) = uVar9;
    *(undefined4 *)(arg1 + 0xa8) = uVar10;
    *(undefined4 *)(arg1 + 0xac) = uVar11;
    uVar9 = *(undefined4 *)(arg_30h + 0x1c);
    uVar10 = *(undefined4 *)(arg_30h + 0x20);
    uVar11 = *(undefined4 *)(arg_30h + 0x24);
    *(undefined4 *)(arg1 + 0xb0) = *(undefined4 *)(arg_30h + 0x18);
    *(undefined4 *)(arg1 + 0xb4) = uVar9;
    *(undefined4 *)(arg1 + 0xb8) = uVar10;
    *(undefined4 *)(arg1 + 0xbc) = uVar11;
    *(undefined8 *)(arg_30h + 0x18) = 0;
    *(undefined8 *)(arg_30h + 0x20) = 0xf;
    *(undefined *)(arg_30h + 8) = 0;
    arg2_00 = (undefined (*) [16])(arg1 + 0xc0);
    *arg2_00 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0xd0) = 0;
    *(undefined8 *)(arg1 + 0xd8) = 0;
    uVar9 = *(undefined4 *)(arg4 + 4);
    uVar10 = *(undefined4 *)(arg4 + 8);
    uVar11 = *(undefined4 *)(arg4 + 0xc);
    *(undefined4 *)*arg2_00 = *(undefined4 *)arg4;
    *(undefined4 *)(arg1 + 0xc4) = uVar9;
    *(undefined4 *)(arg1 + 200) = uVar10;
    *(undefined4 *)(arg1 + 0xcc) = uVar11;
    uVar9 = *(undefined4 *)(arg4 + 0x14);
    uVar10 = *(undefined4 *)(arg4 + 0x18);
    uVar11 = *(undefined4 *)(arg4 + 0x1c);
    *(undefined4 *)(arg1 + 0xd0) = *(undefined4 *)(arg4 + 0x10);
    *(undefined4 *)(arg1 + 0xd4) = uVar9;
    *(undefined4 *)(arg1 + 0xd8) = uVar10;
    *(undefined4 *)(arg1 + 0xdc) = uVar11;
    *(undefined8 *)(arg4 + 0x10) = 0;
    *(undefined8 *)(arg4 + 0x18) = 0xf;
    *(undefined *)arg4 = 0;
    arg3_00 = (undefined (*) [16])(arg1 + 0xe0);
    *arg3_00 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0xf0) = 0;
    *(undefined8 *)(arg1 + 0xf8) = 0xf;
    (*arg3_00)[0] = 0;
    arg4_00 = (undefined (*) [16])(arg1 + 0x100);
    *arg4_00 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x110) = 0;
    *(undefined8 *)(arg1 + 0x118) = 0xf;
    (*arg4_00)[0] = 0;
    *(undefined8 *)(arg1 + 0x120) = 0;
    *(undefined8 *)(arg1 + 0x128) = 0;
    *(undefined4 *)(arg1 + 0x130) = 0;
    piVar14 = (int64_t *)fcn.18016f2c0((int64_t)&var_a0h, (int64_t)arg2_00, (int64_t)arg3_00, (int64_t)arg4_00, var_80h)
    ;
    if (piVar1 != piVar14) {
        iVar13 = *piVar1;
        func_0x000180015170(piVar1, piVar1, *(undefined8 *)(iVar13 + 8));
        *(int64_t *)(iVar13 + 8) = iVar13;
        *(int64_t *)iVar13 = iVar13;
        *(int64_t *)(iVar13 + 0x10) = iVar13;
        *(undefined8 *)(arg1 + 0x40) = 0;
        iVar13 = *piVar1;
        *piVar1 = *piVar14;
        *piVar14 = iVar13;
        iVar13 = *(int64_t *)(arg1 + 0x40);
        *(int64_t *)(arg1 + 0x40) = piVar14[1];
        piVar14[1] = iVar13;
    }
    cVar5 = *(char *)((int64_t)*(int64_t **)(var_a0h + 8) + 0x19);
    piVar1 = *(int64_t **)(var_a0h + 8);
    while (cVar5 == '\0') {
        func_0x000180015170(&var_a0h, &var_a0h, piVar1[2]);
        piVar14 = (int64_t *)*piVar1;
        func_0x000180004e40(piVar1 + 8);
        func_0x000180004e40(piVar1 + 4);
        func_0x000180459c3c(piVar1, 0x60);
        piVar1 = piVar14;
        cVar5 = *(char *)((int64_t)piVar14 + 0x19);
    }
    func_0x000180459c3c(var_a0h, 0x60);
    func_0x000180416800(**(undefined8 **)arg1, 0x200002, arg1 + 0x10);
    func_0x000180416800(**(undefined8 **)arg1, 0x300003, arg1 + 0x70);
    var_a8h = 0;
    func_0x000180416800(**(undefined8 **)arg1, 0x100001, &var_a8h);
    var_78h = 0x1804a56e0;
    _var_70h = ZEXT816(0);
    var_60h = 0;
    var_58h = 0;
    uVar15 = func_0x000180498cd0(var_a8h);
    func_0x000180004830(&var_70h, var_a8h, uVar15);
    uVar18 = var_58h;
    if (pauVar2 == (undefined (*) [16])&var_70h) {
code_r0x00018017114f:
        if (uVar18 < 0x10) goto code_r0x00018017118c;
        iVar13 = var_70h;
        puVar17 = auStackY_c8;
        if ((0xfff < uVar18 + 1) &&
           (iVar13 = *(int64_t *)(var_70h + -8), puVar17 = auStackY_c8,
           0x1f < (var_70h - *(int64_t *)(var_70h + -8)) - 8U)) goto code_r0x00018017117d;
    } else {
        uVar18 = *(uint64_t *)(arg1 + 0x68);
        if (uVar18 < 0x10) {
code_r0x000180171122:
            *(int64_t *)*pauVar2 = var_70h;
            *(int64_t *)(arg1 + 0x58) = var_68h;
            *(int64_t *)(arg1 + 0x60) = var_60h;
            *(int64_t *)(arg1 + 0x68) = var_58h;
            auVar12[15] = 0;
            auVar12._0_15_ = stack0xffffffffffffff91;
            _var_70h = auVar12 << 8;
            uVar18 = 0xf;
            goto code_r0x00018017114f;
        }
        iVar13 = *(int64_t *)*pauVar2;
        uVar16 = uVar18 + 1;
        if (uVar16 < 0x1000) {
code_r0x00018017111d:
            func_0x000180459c3c(iVar13, uVar16);
            goto code_r0x000180171122;
        }
        if ((iVar13 - *(int64_t *)(iVar13 + -8)) - 8U < 0x20) {
            uVar16 = uVar18 + 0x28;
            iVar13 = *(int64_t *)(iVar13 + -8);
            goto code_r0x00018017111d;
        }
code_r0x00018017117d:
        pcVar8 = (code *)swi(0x29);
        iVar13 = (*pcVar8)(5);
        puVar17 = auStackY_c0;
    }
    *(undefined8 *)(puVar17 + -8) = 0x18017118c;
    func_0x000180459c3c(iVar13);
code_r0x00018017118c:
    uVar15 = **(undefined8 **)arg1;
    *(undefined8 *)(puVar17 + -8) = 0x1801711a3;
    func_0x000180416800(uVar15, 0x600008, arg1 + 0x128);
    uVar15 = **(undefined8 **)arg1;
    *(undefined8 *)(puVar17 + -8) = 0x1801711ba;
    func_0x000180416800(uVar15, 0x600007, arg1 + 0x120);
    uVar15 = **(undefined8 **)arg1;
    *(undefined8 *)(puVar17 + -8) = 0x1801711d1;
    func_0x000180416800(uVar15, 0x200014, arg1 + 0x130);
    piVar1 = *(int64_t **)(var_90h + 8);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        piVar14 = piVar1 + 1;
        iVar4 = *(int32_t *)piVar14;
        *(int32_t *)piVar14 = *(int32_t *)piVar14 + -1;
        UNLOCK();
        if (iVar4 == 1) {
            pcVar8 = *(code **)*piVar1;
            *(undefined8 *)(puVar17 + -8) = 0x1801711f8;
            (*pcVar8)(piVar1);
            LOCK();
            piVar3 = (int32_t *)((int64_t)piVar1 + 0xc);
            iVar4 = *piVar3;
            *piVar3 = *piVar3 + -1;
            UNLOCK();
            if (iVar4 == 1) {
                pcVar8 = *(code **)(*piVar1 + 8);
                *(undefined8 *)(puVar17 + -8) = 0x18017120b;
                (*pcVar8)(piVar1);
            }
        }
    }
    *(undefined8 *)(puVar17 + -8) = 0x18017121a;
    func_0x000180459870(var_50h ^ (uint64_t)puVar17);
    return;
}

// ============================================================
// Function: FUN_180171250
// Address: 0x180171250
// Size: 1593 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_e0h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180171250(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    undefined auVar2 [16];
    int64_t iVar3;
    undefined (*pauVar4) [16];
    uint64_t uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    uint32_t *puVar8;
    uint64_t uVar9;
    undefined *puVar10;
    undefined *puVar11;
    undefined *puVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t *piVar15;
    uint32_t uVar16;
    int64_t iVar17;
    int64_t var_20h;
    undefined8 uStackY_130;
    undefined auStackY_128 [8];
    undefined auStackY_120 [24];
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    undefined8 uStack_b8;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    undefined8 uStack_98;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    uint32_t uStack_78;
    uint32_t uStack_74;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    undefined8 uStack_58;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    puVar10 = auStackY_128;
    puVar11 = auStackY_128;
    var_40h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_128;
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0xf;
    *(undefined *)arg2 = 0;
    uVar16 = 1;
    var_108h._0_4_ = 1;
    iVar17 = *(int64_t *)(arg1 + 8);
    var_d8h = *(int64_t *)(arg1 + 0x10);
    puVar12 = auStackY_128;
    var_100h = iVar17;
    var_e8h = arg3;
    var_e0h = arg2;
    var_d0h = arg1;
    var_c8h = arg2;
    if (iVar17 != var_d8h) {
        do {
            iVar7 = var_d0h;
            uVar9 = 0;
            var_100h = iVar17;
            if (*(int64_t *)(arg2 + 0x10) != 0) {
                fcn.18000d970(var_e0h);
            }
            pauVar4 = (undefined (*) [16])(iVar17 + 0x20);
            if (*(char *)iVar7 == '\0') {
                auVar2 = ZEXT816(0);
                uStack_b8 = 0;
                var_b0h = 0;
                var_a8h = 0;
                uVar6 = *(uint64_t *)(iVar17 + 0x30);
                if (0xf < *(uint64_t *)(iVar17 + 0x38)) {
                    pauVar4 = *(undefined (**) [16])*pauVar4;
                }
                _var_c0h = auVar2;
                if (0x7fffffffffffffff < uVar6) {
                    func_0x0001800047c0();
                    pcVar1 = (code *)swi(3);
                    (*pcVar1)();
                    return;
                }
                if (uVar6 < 0x10) {
                    var_b0h = uVar6;
                    uVar14 = 0xf;
                    var_a8h = 0xf;
                    uVar5 = *(uint64_t *)*pauVar4;
                    _var_c0h = *pauVar4;
code_r0x000180171422:
                    pauVar4 = (undefined (*) [16])&var_c0h;
                    uVar16 = uVar16 | 4;
                    goto code_r0x00018017142a;
                }
                uVar14 = uVar6 | 0xf;
                if (uVar14 < 0x8000000000000000) {
                    if (uVar14 < 0x16) {
                        uVar14 = 0x16;
                    }
                    uVar5 = uVar9;
                    if (uVar14 == 0xffffffffffffffff) {
code_r0x000180171407:
                        var_c0h = uVar5;
                        var_b0h = uVar6;
                        var_a8h = uVar14;
                        func_0x000180498030(uVar5, pauVar4, uVar6 + 1);
                        goto code_r0x000180171422;
                    }
                    if (uVar14 + 1 < 0x1000) {
                        uVar5 = func_0x000180459890();
                        goto code_r0x000180171407;
                    }
                    uVar5 = uVar14 + 0x28;
                    if (uVar14 + 1 < uVar5) goto code_r0x0001801713e0;
                    func_0x000180004720();
code_r0x000180171871:
                    func_0x000180004720();
                    goto code_r0x000180171877;
                }
                uVar14 = 0x7fffffffffffffff;
                uVar5 = 0x8000000000000027;
code_r0x0001801713e0:
                iVar17 = func_0x000180459890(uVar5);
                puVar12 = auStackY_128;
                if (iVar17 != 0) {
                    uVar5 = iVar17 + 0x27U & 0xffffffffffffffe0;
                    *(int64_t *)(uVar5 - 8) = iVar17;
                    goto code_r0x000180171407;
                }
code_r0x000180171834:
                pcVar1 = (code *)swi(0x29);
                (*pcVar1)(5);
                puVar12 = puVar12 + 8;
                break;
            }
            pauVar4 = (undefined (*) [16])fcn.180170630(var_e8h, (int64_t)&var_80h, (int64_t)pauVar4);
            uVar16 = uVar16 | 2;
            uVar5 = var_c0h;
            uVar14 = var_a8h;
code_r0x00018017142a:
            _var_a0h = ZEXT816(0);
            auVar2 = _var_a0h;
            uStack_98 = 0;
            var_90h = 0;
            var_88h = 0;
            uVar6 = *(uint64_t *)pauVar4[1];
            if (0xf < *(uint64_t *)(pauVar4[1] + 8)) {
                pauVar4 = *(undefined (**) [16])*pauVar4;
            }
            var_108h._0_4_ = uVar16;
            if (0x7fffffffffffffff < uVar6) goto code_r0x000180171883;
            if (0xf < uVar6) {
                uVar13 = uVar6 | 0xf;
                _var_a0h = auVar2;
                if (uVar13 < 0x8000000000000000) {
                    if (uVar13 < 0x16) {
                        uVar13 = 0x16;
                    }
                    if (uVar13 != 0xffffffffffffffff) {
                        if (0xfff < uVar13 + 1) {
                            uVar9 = uVar13 + 0x28;
                            if (uVar9 <= uVar13 + 1) goto code_r0x000180171871;
                            goto code_r0x0001801714cb;
                        }
                        uVar9 = func_0x000180459890();
                    }
code_r0x0001801714f2:
                    var_a0h = uVar9;
                    var_90h = uVar6;
                    var_88h = uVar13;
                    func_0x000180498030(uVar9, pauVar4, uVar6 + 1);
                    goto code_r0x00018017150f;
                }
                uVar13 = 0x7fffffffffffffff;
                uVar9 = 0x8000000000000027;
code_r0x0001801714cb:
                iVar17 = func_0x000180459890(uVar9);
                if (iVar17 != 0) {
                    uVar9 = iVar17 + 0x27U & 0xffffffffffffffe0;
                    *(int64_t *)(uVar9 - 8) = iVar17;
                    goto code_r0x0001801714f2;
                }
                pcVar1 = (code *)swi(0x29);
                (*pcVar1)(5);
                puVar10 = auStackY_120;
code_r0x00018017181f:
                pcVar1 = (code *)swi(0x29);
                (*pcVar1)(5);
                puVar11 = puVar10 + 8;
code_r0x000180171826:
                pcVar1 = (code *)swi(0x29);
                (*pcVar1)(5);
                puVar12 = puVar11 + 8;
code_r0x00018017182d:
                pcVar1 = (code *)swi(0x29);
                (*pcVar1)(5);
                puVar12 = puVar12 + 8;
                goto code_r0x000180171834;
            }
            var_90h = uVar6;
            var_88h = 0xf;
            _var_a0h = *pauVar4;
code_r0x00018017150f:
            if (((uVar16 & 4) != 0) && (uVar16 = uVar16 & 0xfffffffb, var_108h._0_4_ = uVar16, 0xf < uVar14)) {
                uVar9 = uVar14 + 1;
                uVar6 = uVar5;
                if (0xfff < uVar9) {
                    uVar6 = *(uint64_t *)(uVar5 - 8);
                    if (0x1f < (uVar5 - uVar6) - 8) goto code_r0x00018017181f;
                    uVar9 = uVar14 + 0x28;
                }
                func_0x000180459c3c(uVar6, uVar9);
            }
            if ((uVar16 & 2) != 0) {
                uVar16 = uVar16 & 0xfffffffd;
                var_108h._0_4_ = uVar16;
                if ((uint64_t)var_68h < 0x10) {
code_r0x0001801715a0:
                    var_70h = 0;
                    var_68h = 0xf;
                    var_80h._0_4_ = (uint32_t)var_80h & 0xffffff00;
                    goto code_r0x0001801715b6;
                }
                uVar9 = var_68h + 1;
                iVar7 = CONCAT44(var_80h._4_4_, (uint32_t)var_80h);
                iVar17 = iVar7;
                if (uVar9 < 0x1000) {
code_r0x00018017159b:
                    func_0x000180459c3c(iVar17, uVar9);
                    goto code_r0x0001801715a0;
                }
                iVar17 = *(int64_t *)(iVar7 + -8);
                puVar12 = auStackY_128;
                if ((iVar7 - iVar17) - 8U < 0x20) {
                    uVar9 = var_68h + 0x28;
                    goto code_r0x00018017159b;
                }
                goto code_r0x00018017182d;
            }
code_r0x0001801715b6:
            iVar17 = var_100h;
            piVar15 = (int64_t *)0x0;
            var_f8h = *(int64_t *)(var_100h + 0x10);
            if (var_f8h == 0x7fffffffffffffff) {
                func_0x0001800047c0();
                auVar2 = _var_a0h;
code_r0x000180171883:
                _var_a0h = auVar2;
                func_0x0001800047c0();
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
            if (0xf < *(uint64_t *)(var_100h + 0x18)) {
                var_100h = *(int64_t *)var_100h;
            }
            auVar2 = ZEXT816(0);
            uStack_58 = 0;
            var_50h = 0;
            var_48h = 0;
            var_f0h = var_f8h + 1;
            _var_60h = auVar2;
            if ((uint64_t)var_f0h < 0x10) {
                uVar9 = 0xf;
                piVar15 = &var_60h;
            } else {
                uVar9 = var_f0h | 0xf;
                if (uVar9 < 0x8000000000000000) {
                    if (uVar9 < 0x16) {
                        uVar9 = 0x16;
                    }
                    if (uVar9 != 0xffffffffffffffff) {
                        if (0xfff < uVar9 + 1) {
                            uVar6 = uVar9 + 0x28;
                            if (uVar6 <= uVar9 + 1) {
code_r0x000180171877:
                                func_0x000180004720();
                                pcVar1 = (code *)swi(3);
                                (*pcVar1)();
                                return;
                            }
                            goto code_r0x00018017165d;
                        }
                        piVar15 = (int64_t *)func_0x000180459890();
                    }
                    var_60h = (int64_t)piVar15;
                } else {
                    uVar9 = 0x7fffffffffffffff;
                    uVar6 = 0x8000000000000027;
code_r0x00018017165d:
                    iVar7 = func_0x000180459890(uVar6);
                    puVar12 = auStackY_128;
                    if (iVar7 == 0) goto code_r0x00018017182d;
                    piVar15 = (int64_t *)(iVar7 + 0x27U & 0xffffffffffffffe0);
                    piVar15[-1] = iVar7;
                    var_60h = (int64_t)piVar15;
                }
            }
            var_50h = var_f0h;
            var_48h = uVar9;
            func_0x000180498030(piVar15, var_100h, var_f8h);
            *(undefined *)(var_f8h + (int64_t)piVar15) = 0x3d;
            *(undefined *)(var_f8h + 1 + (int64_t)piVar15) = 0;
            var_108h._0_4_ = uVar16 | 8;
            puVar8 = (uint32_t *)fcn.18000d970(var_e0h);
            arg2 = var_e0h;
            var_80h._0_4_ = *puVar8;
            var_80h._4_4_ = puVar8[1];
            uStack_78 = puVar8[2];
            uStack_74 = puVar8[3];
            var_70h = *(int64_t *)(puVar8 + 4);
            var_68h = *(int64_t *)(puVar8 + 6);
            *(undefined8 *)(puVar8 + 4) = 0;
            *(undefined8 *)(puVar8 + 6) = 0xf;
            *(undefined *)puVar8 = 0;
            uVar16 = uVar16 | 0x18;
            var_108h._0_4_ = uVar16;
            fcn.18000d970(var_e0h);
            if (0xf < (uint64_t)var_68h) {
                uVar9 = var_68h + 1;
                iVar3 = CONCAT44(var_80h._4_4_, (uint32_t)var_80h);
                iVar7 = iVar3;
                if (0xfff < uVar9) {
                    iVar7 = *(int64_t *)(iVar3 + -8);
                    if (0x1f < (iVar3 - iVar7) - 8U) goto code_r0x000180171826;
                    uVar9 = var_68h + 0x28;
                }
                func_0x000180459c3c(iVar7, uVar9);
            }
            if (0xf < (uint64_t)var_48h) {
                uVar9 = var_48h + 1;
                iVar7 = var_60h;
                if (0xfff < uVar9) {
                    iVar7 = *(int64_t *)(var_60h + -8);
                    puVar12 = auStackY_128;
                    if (0x1f < (var_60h - iVar7) - 8U) goto code_r0x00018017182d;
                    uVar9 = var_48h + 0x28;
                }
                func_0x000180459c3c(iVar7, uVar9);
            }
            if (0xf < (uint64_t)var_88h) {
                uVar9 = var_88h + 1;
                iVar7 = var_a0h;
                if (0xfff < uVar9) {
                    iVar7 = *(int64_t *)(var_a0h + -8);
                    puVar12 = auStackY_128;
                    if (0x1f < (var_a0h - iVar7) - 8U) goto code_r0x000180171834;
                    uVar9 = var_88h + 0x28;
                }
                func_0x000180459c3c(iVar7, uVar9);
            }
            iVar17 = iVar17 + 0x40;
            puVar12 = auStackY_128;
            var_100h = iVar17;
        } while (iVar17 != var_d8h);
    }
    *(undefined8 *)(puVar12 + -8) = 0x18017184a;
    func_0x000180459870(var_40h ^ (uint64_t)puVar12);
    return;
}

// ============================================================
// Function: FUN_180171890
// Address: 0x180171890
// Size: 2335 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_130h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180171890(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    undefined auVar2 [16];
    int64_t iVar3;
    undefined (*pauVar4) [16];
    uint64_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    undefined *puVar10;
    undefined *puVar11;
    undefined *puVar12;
    undefined *puVar13;
    uint32_t uVar14;
    uint64_t uVar15;
    int64_t *piVar16;
    uint64_t uVar17;
    int64_t *piVar18;
    int64_t var_20h;
    undefined8 uStackY_180;
    undefined auStackY_178 [8];
    undefined auStackY_170 [24];
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    undefined8 uStack_f8;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    undefined8 uStack_d8;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    undefined8 uStack_b8;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    undefined8 uStack_98;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    undefined8 uStack_78;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    puVar10 = auStackY_178;
    puVar11 = auStackY_178;
    puVar12 = auStackY_178;
    var_40h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_178;
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0xf;
    *(undefined *)arg2 = 0;
    uVar14 = 1;
    var_158h._0_4_ = 1;
    pauVar4 = *(undefined (**) [16])(arg1 + 8);
    var_110h = *(int64_t *)(arg1 + 0x10);
    puVar13 = auStackY_178;
    var_138h = (int64_t)pauVar4;
    var_130h = arg3;
    var_120h = arg2;
    var_118h = arg1;
    var_108h = arg2;
    if (pauVar4 != (undefined (*) [16])var_110h) {
        do {
            iVar6 = var_118h;
            piVar18 = (int64_t *)0x0;
            var_138h = (int64_t)pauVar4;
            if (*(int64_t *)(arg2 + 0x10) != 0) {
                fcn.18000d970(var_130h);
            }
            if (*(char *)iVar6 == '\0') {
                auVar2 = ZEXT816(0);
                uStack_98 = 0;
                var_90h = 0;
                var_88h = 0;
                uVar8 = *(uint64_t *)pauVar4[1];
                if (0xf < *(uint64_t *)(pauVar4[1] + 8)) {
                    pauVar4 = *(undefined (**) [16])*pauVar4;
                }
                _var_a0h = auVar2;
                if (0x7fffffffffffffff < uVar8) {
                    func_0x0001800047c0();
                    pcVar1 = (code *)swi(3);
                    (*pcVar1)();
                    return;
                }
                if (uVar8 < 0x10) {
                    var_90h = uVar8;
                    uVar7 = 0xf;
                    var_88h = 0xf;
                    piVar16 = *(int64_t **)*pauVar4;
                    _var_a0h = *pauVar4;
code_r0x000180171a5c:
                    pauVar4 = (undefined (*) [16])&var_a0h;
                    uVar14 = uVar14 | 4;
                    goto code_r0x000180171a63;
                }
                uVar7 = uVar8 | 0xf;
                if (uVar7 < 0x8000000000000000) {
                    if (uVar7 < 0x16) {
                        uVar7 = 0x16;
                    }
                    piVar16 = piVar18;
                    if (uVar7 == 0xffffffffffffffff) {
code_r0x000180171a41:
                        var_a0h = (int64_t)piVar16;
                        var_90h = uVar8;
                        var_88h = uVar7;
                        func_0x000180498030(piVar16, pauVar4, uVar8 + 1);
                        goto code_r0x000180171a5c;
                    }
                    if (uVar7 + 1 < 0x1000) {
                        piVar16 = (int64_t *)func_0x000180459890();
                        goto code_r0x000180171a41;
                    }
                    uVar17 = uVar7 + 0x28;
                    if (uVar7 + 1 < uVar17) goto code_r0x000180171a1a;
                    func_0x000180004720();
code_r0x00018017217f:
                    func_0x000180004720();
code_r0x000180172185:
                    func_0x000180004720();
code_r0x00018017218b:
                    func_0x000180004720();
                    goto code_r0x000180172191;
                }
                uVar7 = 0x7fffffffffffffff;
                uVar17 = 0x8000000000000027;
code_r0x000180171a1a:
                iVar6 = func_0x000180459890(uVar17);
                puVar13 = auStackY_178;
                if (iVar6 != 0) {
                    piVar16 = (int64_t *)(iVar6 + 0x27U & 0xffffffffffffffe0);
                    piVar16[-1] = iVar6;
                    goto code_r0x000180171a41;
                }
code_r0x000180172142:
                pcVar1 = (code *)swi(0x29);
                (*pcVar1)(5);
                puVar13 = puVar13 + 8;
                break;
            }
            pauVar4 = (undefined (*) [16])fcn.180170630(var_130h, (int64_t)&var_100h, (int64_t)pauVar4);
            uVar14 = uVar14 | 2;
            piVar16 = (int64_t *)var_a0h;
            uVar7 = var_88h;
code_r0x000180171a63:
            auVar2 = ZEXT816(0);
            uStack_d8 = 0;
            var_d0h = 0;
            var_c8h = 0;
            uVar8 = *(uint64_t *)pauVar4[1];
            if (0xf < *(uint64_t *)(pauVar4[1] + 8)) {
                pauVar4 = *(undefined (**) [16])*pauVar4;
            }
            var_158h._0_4_ = uVar14;
            var_148h = uVar8;
            if (0x7fffffffffffffff < uVar8) goto code_r0x0001801721a9;
            if (0xf < uVar8) {
                uVar17 = uVar8 | 0xf;
                _var_e0h = auVar2;
                if (uVar17 < 0x8000000000000000) {
                    if (uVar17 < 0x16) {
                        uVar17 = 0x16;
                    }
                    if (uVar17 != 0xffffffffffffffff) {
                        if (0xfff < uVar17 + 1) {
                            uVar15 = uVar17 + 0x28;
                            if (uVar15 <= uVar17 + 1) goto code_r0x00018017217f;
                            goto code_r0x000180171b0f;
                        }
                        piVar18 = (int64_t *)func_0x000180459890();
                    }
code_r0x000180171b36:
                    var_e0h = (int64_t)piVar18;
                    var_d0h = uVar8;
                    var_c8h = uVar17;
                    func_0x000180498030(piVar18, pauVar4, uVar8 + 1);
                    goto code_r0x000180171b52;
                }
                uVar17 = 0x7fffffffffffffff;
                uVar15 = 0x8000000000000027;
code_r0x000180171b0f:
                iVar6 = func_0x000180459890(uVar15);
                if (iVar6 != 0) {
                    piVar18 = (int64_t *)(iVar6 + 0x27U & 0xffffffffffffffe0);
                    piVar18[-1] = iVar6;
                    goto code_r0x000180171b36;
                }
                pcVar1 = (code *)swi(0x29);
                (*pcVar1)(5);
                puVar10 = auStackY_170;
code_r0x00018017211f:
                pcVar1 = (code *)swi(0x29);
                (*pcVar1)(5);
                puVar11 = puVar10 + 8;
code_r0x000180172126:
                pcVar1 = (code *)swi(0x29);
                (*pcVar1)(5);
                puVar12 = puVar11 + 8;
code_r0x00018017212d:
                pcVar1 = (code *)swi(0x29);
                (*pcVar1)(5);
                puVar13 = puVar12 + 8;
code_r0x000180172134:
                pcVar1 = (code *)swi(0x29);
                (*pcVar1)(5);
                puVar13 = puVar13 + 8;
code_r0x00018017213b:
                pcVar1 = (code *)swi(0x29);
                (*pcVar1)(5);
                puVar13 = puVar13 + 8;
                goto code_r0x000180172142;
            }
            uVar17 = 0xf;
            var_c8h = 0xf;
            piVar18 = *(int64_t **)*pauVar4;
            _var_e0h = *pauVar4;
            var_d0h = uVar8;
code_r0x000180171b52:
            if (((uVar14 & 4) != 0) && (uVar14 = uVar14 & 0xfffffffb, var_158h._0_4_ = uVar14, 0xf < uVar7)) {
                piVar9 = piVar16;
                if ((0xfff < uVar7 + 1) &&
                   (piVar9 = (int64_t *)piVar16[-1], 0x1f < (uint64_t)((int64_t)piVar16 + (-8 - (int64_t)piVar9))))
                goto code_r0x00018017211f;
                func_0x000180459c3c(piVar9);
            }
            if ((uVar14 & 2) != 0) {
                uVar14 = uVar14 & 0xfffffffd;
                var_158h._0_4_ = uVar14;
                if ((uint64_t)var_e8h < 0x10) {
code_r0x000180171be0:
                    var_f0h = 0;
                    var_e8h = 0xf;
                    auVar2[15] = 0;
                    auVar2._0_15_ = stack0xffffffffffffff01;
                    _var_100h = auVar2 << 8;
                    goto code_r0x000180171bf6;
                }
                iVar6 = var_100h;
                if ((var_e8h + 1U < 0x1000) ||
                   (iVar6 = *(int64_t *)(var_100h + -8), puVar13 = auStackY_178, (var_100h - iVar6) - 8U < 0x20)) {
                    func_0x000180459c3c(iVar6);
                    goto code_r0x000180171be0;
                }
                goto code_r0x00018017213b;
            }
code_r0x000180171bf6:
            arg2 = var_120h;
            iVar6 = var_138h;
            uVar8 = 0;
            if (*(int64_t *)(var_138h + 0x30) != 0) {
                pauVar4 = (undefined (*) [16])(var_138h + 0x20);
                if (*(char *)var_118h == '\0') {
                    auVar2 = ZEXT816(0);
                    uStack_78 = 0;
                    var_70h = 0;
                    var_68h = 0;
                    uVar7 = *(uint64_t *)(var_138h + 0x30);
                    if (0xf < *(uint64_t *)(var_138h + 0x38)) {
                        pauVar4 = *(undefined (**) [16])*pauVar4;
                    }
                    if (uVar7 < 0x8000000000000000) {
                        if (uVar7 < 0x10) {
                            var_70h = uVar7;
                            uVar15 = 0xf;
                            var_68h = 0xf;
                            uVar8 = *(uint64_t *)*pauVar4;
                            _var_80h = *pauVar4;
                        } else {
                            uVar15 = uVar7 | 0xf;
                            _var_80h = auVar2;
                            if (uVar15 < 0x8000000000000000) {
                                if (uVar15 < 0x16) {
                                    uVar15 = 0x16;
                                }
                                if (uVar15 != 0xffffffffffffffff) {
                                    if (0xfff < uVar15 + 1) {
                                        uVar8 = uVar15 + 0x28;
                                        if (uVar8 <= uVar15 + 1) goto code_r0x000180172185;
                                        goto code_r0x000180171cfe;
                                    }
                                    uVar8 = func_0x000180459890();
                                }
                            } else {
                                uVar15 = 0x7fffffffffffffff;
                                uVar8 = 0x8000000000000027;
code_r0x000180171cfe:
                                iVar6 = func_0x000180459890(uVar8);
                                puVar13 = auStackY_178;
                                if (iVar6 == 0) goto code_r0x00018017213b;
                                uVar8 = iVar6 + 0x27U & 0xffffffffffffffe0;
                                *(int64_t *)(uVar8 - 8) = iVar6;
                            }
                            var_80h = uVar8;
                            var_70h = uVar7;
                            var_68h = uVar15;
                            func_0x000180498030(uVar8, pauVar4, uVar7 + 1);
                        }
                        pauVar4 = (undefined (*) [16])&var_80h;
                        uVar14 = uVar14 | 0x10;
                        goto code_r0x000180171d47;
                    }
                } else {
                    pauVar4 = (undefined (*) [16])fcn.180170630(var_130h, (int64_t)&var_60h, (int64_t)pauVar4);
                    uVar14 = uVar14 | 8;
                    uVar8 = var_80h;
                    uVar15 = var_68h;
code_r0x000180171d47:
                    auVar2 = ZEXT816(0);
                    uStack_f8 = 0;
                    var_f0h = 0;
                    var_e8h = 0;
                    var_140h = *(int64_t *)pauVar4[1];
                    if (0xf < *(uint64_t *)(pauVar4[1] + 8)) {
                        pauVar4 = *(undefined (**) [16])*pauVar4;
                    }
                    var_158h._0_4_ = uVar14;
                    if ((uint64_t)var_140h < 0x8000000000000000) {
                        if ((uint64_t)var_140h < 0x10) {
                            var_e8h = 0xf;
                            _var_100h = *pauVar4;
                            var_f0h = var_140h;
                        } else {
                            uVar7 = var_140h | 0xf;
                            _var_100h = auVar2;
                            if (uVar7 < 0x8000000000000000) {
                                if (uVar7 < 0x16) {
                                    uVar7 = 0x16;
                                }
                                if (uVar7 == 0xffffffffffffffff) {
                                    var_150h = 0;
                                } else {
                                    if (0xfff < uVar7 + 1) {
                                        uVar5 = uVar7 + 0x28;
                                        if (uVar5 <= uVar7 + 1) goto code_r0x00018017218b;
                                        goto code_r0x000180171e00;
                                    }
                                    var_150h = func_0x000180459890();
                                }
                            } else {
                                uVar7 = 0x7fffffffffffffff;
                                uVar5 = 0x8000000000000027;
code_r0x000180171e00:
                                iVar6 = func_0x000180459890(uVar5);
                                if (iVar6 == 0) goto code_r0x000180172126;
                                var_150h = iVar6 + 0x27U & 0xffffffffffffffe0;
                                *(int64_t *)(var_150h - 8) = iVar6;
                            }
                            var_100h = var_150h;
                            var_f0h = var_140h;
                            var_e8h = uVar7;
                            func_0x000180498030(var_150h, pauVar4, var_140h + 1);
                        }
                        if (((uVar14 & 0x10) != 0) &&
                           (uVar14 = uVar14 & 0xffffffef, var_158h._0_4_ = uVar14, 0xf < uVar15)) {
                            uVar7 = uVar15 + 1;
                            uVar5 = uVar8;
                            if (0xfff < uVar7) {
                                uVar5 = *(uint64_t *)(uVar8 - 8);
                                if (0x1f < (uVar8 - uVar5) - 8) goto code_r0x00018017212d;
                                uVar7 = uVar15 + 0x28;
                            }
                            func_0x000180459c3c(uVar5, uVar7);
                        }
                        if ((uVar14 & 8) != 0) {
                            uVar14 = uVar14 & 0xfffffff7;
                            var_158h._0_4_ = uVar14;
                            if (0xf < (uint64_t)var_48h) {
                                uVar8 = var_48h + 1;
                                iVar3 = CONCAT71(var_60h._1_7_, (undefined)var_60h);
                                iVar6 = iVar3;
                                if (0xfff < uVar8) {
                                    iVar6 = *(int64_t *)(iVar3 + -8);
                                    puVar13 = auStackY_178;
                                    if (0x1f < (iVar3 - iVar6) - 8U) goto code_r0x000180172134;
                                    uVar8 = var_48h + 0x28;
                                }
                                func_0x000180459c3c(iVar6, uVar8);
                            }
                            var_50h = 0;
                            var_48h = 0xf;
                            var_60h._0_1_ = 0;
                        }
                        piVar16 = (int64_t *)0x0;
                        if (var_148h != 0x7fffffffffffffff) {
                            var_128h = (int64_t)&var_e0h;
                            if (0xf < uVar17) {
                                var_128h = (int64_t)piVar18;
                            }
                            _var_c0h = ZEXT816(0);
                            var_b0h = 0;
                            var_a8h = 0;
                            var_150h = var_148h + 1;
                            if ((uint64_t)var_150h < 0x10) {
                                uVar8 = 0xf;
                                piVar16 = &var_c0h;
                            } else {
                                uVar8 = var_150h | 0xf;
                                if (uVar8 < 0x8000000000000000) {
                                    if (uVar8 < 0x16) {
                                        uVar8 = 0x16;
                                    }
                                    if (uVar8 == 0xffffffffffffffff) {
                                        _var_c0h = ZEXT816(0);
                                        goto code_r0x000180171fe0;
                                    }
                                    if (0xfff < uVar8 + 1) {
                                        uVar7 = uVar8 + 0x28;
                                        if (uVar7 <= uVar8 + 1) {
code_r0x000180172191:
                                            func_0x000180004720();
                                            pcVar1 = (code *)swi(3);
                                            (*pcVar1)();
                                            return;
                                        }
                                        goto code_r0x000180171f9b;
                                    }
                                    piVar16 = (int64_t *)func_0x000180459890();
                                } else {
                                    uVar8 = 0x7fffffffffffffff;
                                    uVar7 = 0x8000000000000027;
code_r0x000180171f9b:
                                    iVar6 = func_0x000180459890(uVar7);
                                    puVar13 = auStackY_178;
                                    if (iVar6 == 0) goto code_r0x000180172134;
                                    piVar16 = (int64_t *)(iVar6 + 0x27U & 0xffffffffffffffe0);
                                    piVar16[-1] = iVar6;
                                }
                                var_c0h = (int64_t)piVar16;
                            }
code_r0x000180171fe0:
                            var_b0h = var_150h;
                            var_a8h = uVar8;
                            func_0x000180498030(piVar16, var_128h, var_148h);
                            arg2 = var_120h;
                            *(undefined *)((int64_t)piVar16 + var_148h) = 0x3d;
                            *(undefined *)((int64_t)piVar16 + var_148h + 1) = 0;
                            uVar14 = uVar14 | 0x20;
                            var_158h._0_4_ = uVar14;
                            fcn.18000d970(var_130h);
                            if (0xf < (uint64_t)var_a8h) {
                                uVar8 = var_a8h + 1;
                                iVar6 = var_c0h;
                                if (0xfff < uVar8) {
                                    iVar6 = *(int64_t *)(var_c0h + -8);
                                    puVar13 = auStackY_178;
                                    if (0x1f < (var_c0h - iVar6) - 8U) goto code_r0x000180172134;
                                    uVar8 = var_a8h + 0x28;
                                }
                                func_0x000180459c3c(iVar6, uVar8);
                            }
                            fcn.18000d970(var_130h);
                            iVar6 = var_138h;
                            if (0xf < (uint64_t)var_e8h) {
                                uVar8 = var_e8h + 1;
                                iVar6 = var_100h;
                                if (0xfff < uVar8) {
                                    iVar6 = *(int64_t *)(var_100h + -8);
                                    puVar13 = auStackY_178;
                                    if (0x1f < (var_100h - iVar6) - 8U) goto code_r0x00018017213b;
                                    uVar8 = var_e8h + 0x28;
                                }
                                func_0x000180459c3c(iVar6, uVar8);
                                iVar6 = var_138h;
                            }
                            goto code_r0x0001801720c2;
                        }
                        func_0x0001800047c0();
                        auVar2 = _var_100h;
                    }
                    _var_100h = auVar2;
                    func_0x0001800047c0();
                    auVar2 = _var_80h;
                }
                _var_80h = auVar2;
                func_0x0001800047c0();
                auVar2 = _var_e0h;
code_r0x0001801721a9:
                _var_e0h = auVar2;
                func_0x0001800047c0();
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
            fcn.18000d970(var_130h);
            uVar17 = var_c8h;
            piVar18 = (int64_t *)var_e0h;
code_r0x0001801720c2:
            if (0xf < uVar17) {
                uVar8 = uVar17 + 1;
                piVar16 = piVar18;
                if (0xfff < uVar8) {
                    piVar16 = (int64_t *)piVar18[-1];
                    puVar13 = auStackY_178;
                    if (0x1f < (uint64_t)((int64_t)piVar18 + (-8 - (int64_t)piVar16))) goto code_r0x000180172142;
                    uVar8 = uVar17 + 0x28;
                }
                func_0x000180459c3c(piVar16, uVar8);
            }
            pauVar4 = (undefined (*) [16])(iVar6 + 0x40);
            puVar13 = auStackY_178;
            var_138h = (int64_t)pauVar4;
        } while (pauVar4 != (undefined (*) [16])var_110h);
    }
    *(undefined8 *)(puVar13 + -8) = 0x180172158;
    func_0x000180459870(var_40h ^ (uint64_t)puVar13);
    return;
}

// ============================================================
// Function: FUN_1801721b0
// Address: 0x1801721b0
// Size: 225 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h

int64_t fcn.1801721b0(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    code *pcVar2;
    char cVar3;
    undefined8 *puVar4;
    int64_t iVar5;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    
    fcn.180170200(arg1, (int64_t)&var_48h, arg2, var_38h);
    if (*(char *)(var_38h + 0x19) == '\0') {
        cVar3 = fcn.180170420(arg1, arg2, var_38h + 0x20);
        if (cVar3 == '\0') goto code_r0x00018017227c;
    }
    if (*(int64_t *)(arg1 + 8) == 0x2aaaaaaaaaaaaaa) {
        func_0x000180013c00();
        pcVar2 = (code *)swi(3);
        iVar5 = (*pcVar2)();
        return iVar5;
    }
    uVar1 = *(undefined8 *)arg1;
    var_50h = 0;
    var_58h = arg1;
    puVar4 = (undefined8 *)func_0x000180459890(0x60);
    var_50h = (int64_t)puVar4;
    fcn.18000b4d0(puVar4 + 4, arg2);
    *(undefined (*) [16])(puVar4 + 8) = ZEXT816(0);
    puVar4[10] = 0;
    puVar4[0xb] = 0xf;
    *(undefined *)(puVar4 + 8) = 0;
    *puVar4 = uVar1;
    puVar4[1] = uVar1;
    puVar4[2] = uVar1;
    *(undefined2 *)(puVar4 + 3) = 0;
    var_38h = func_0x0001800156d0(arg1, &var_58h, puVar4);
code_r0x00018017227c:
    return var_38h + 0x40;
}

// ============================================================
// Function: FUN_1801722c0
// Address: 0x1801722c0
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Removing unreachable block (ram,0x000180172330)
// WARNING: Removing unreachable block (ram,0x000180172352)
// WARNING: Removing unreachable block (ram,0x000180172349)

undefined8 fcn.1801722c0(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    int64_t unaff_RBX;
    int64_t var_8h;
    int64_t var_18h;
    int64_t in_stack_00000028;
    
    if ((arg3 != 0) && (arg2 != 0)) {
        fcn.1802198e0(unaff_RBX, in_stack_00000028);
        fcn.1802201c0(unaff_RBX);
        fcn.180172390(0x1804a5948);
        return 0x2a;
    }
    fcn.180172390(0x1804a5928);
    return 0x2a;
}

// ============================================================
// Function: FUN_1801722e0
// Address: 0x1801722e0
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Removing unreachable block (ram,0x000180172330)
// WARNING: Removing unreachable block (ram,0x000180172352)
// WARNING: Removing unreachable block (ram,0x000180172349)

undefined8 fcn.1801722c0(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    int64_t unaff_RBX;
    int64_t var_8h;
    int64_t var_18h;
    int64_t in_stack_00000028;
    
    if ((arg3 != 0) && (arg2 != 0)) {
        fcn.1802198e0(unaff_RBX, in_stack_00000028);
        fcn.1802201c0(unaff_RBX);
        fcn.180172390(0x1804a5948);
        return 0x2a;
    }
    fcn.180172390(0x1804a5928);
    return 0x2a;
}

// ============================================================
// Function: FUN_180172330
// Address: 0x180172330
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Removing unreachable block (ram,0x000180172330)
// WARNING: Removing unreachable block (ram,0x000180172352)
// WARNING: Removing unreachable block (ram,0x000180172349)

undefined8 fcn.1801722c0(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    int64_t unaff_RBX;
    int64_t var_8h;
    int64_t var_18h;
    int64_t in_stack_00000028;
    
    if ((arg3 != 0) && (arg2 != 0)) {
        fcn.1802198e0(unaff_RBX, in_stack_00000028);
        fcn.1802201c0(unaff_RBX);
        fcn.180172390(0x1804a5948);
        return 0x2a;
    }
    fcn.180172390(0x1804a5928);
    return 0x2a;
}

// ============================================================
// Function: FUN_180172371
// Address: 0x180172371
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Removing unreachable block (ram,0x000180172330)
// WARNING: Removing unreachable block (ram,0x000180172352)
// WARNING: Removing unreachable block (ram,0x000180172349)

undefined8 fcn.1801722c0(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    int64_t unaff_RBX;
    int64_t var_8h;
    int64_t var_18h;
    int64_t in_stack_00000028;
    
    if ((arg3 != 0) && (arg2 != 0)) {
        fcn.1802198e0(unaff_RBX, in_stack_00000028);
        fcn.1802201c0(unaff_RBX);
        fcn.180172390(0x1804a5948);
        return 0x2a;
    }
    fcn.180172390(0x1804a5928);
    return 0x2a;
}

// ============================================================
// Function: FUN_180172390
// Address: 0x180172390
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.180172390(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    var_10h = arg2;
    var_18h = arg3;
    var_20h = arg4;
    fcn.1804605f8(1);
    fcn.1800102c0();
    fcn.180467430((int64_t)&var_10h);
    return;
}

