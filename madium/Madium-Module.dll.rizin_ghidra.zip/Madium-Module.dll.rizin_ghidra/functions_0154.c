// Chunk 154 - 50 functions

// ============================================================
// Function: FUN_180206d2c
// Address: 0x180206d2c
// Size: 4 bytes
// ============================================================
undefined8 fcn.180206d2c(int64_t arg_a0h, int64_t arg_b0h, int64_t arg_f0h)
{
    return 0;
}

// ============================================================
// Function: FUN_180206d30
// Address: 0x180206d30
// Size: 4 bytes
// ============================================================
undefined8 fcn.180206d30(void)
{
    return 0;
}

// ============================================================
// Function: FUN_180206d90
// Address: 0x180206d90
// Size: 19 bytes
// ============================================================
uint64_t fcn.180206d90(int64_t arg4, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h
                      , int64_t arg_68h, int64_t arg_70h, int64_t arg_78h)
{
    uint64_t *puVar1;
    int64_t iVar2;
    uint64_t in_RCX;
    uint64_t in_RDX;
    uint64_t uVar3;
    undefined8 unaff_RBX;
    uint64_t uVar4;
    undefined8 unaff_RSI;
    uint64_t uVar5;
    undefined8 unaff_RDI;
    uint64_t uVar6;
    int64_t in_R8;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar10;
    bool bVar11;
    bool bVar12;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    
    var_20h = arg4;
    iVar2 = func_0x00018045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&arg_58h + iVar2) = unaff_RBX;
    uVar7 = in_R8 + 1;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_RSI;
    uVar4 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_R13;
    *(undefined8 *)((int64_t)&var_20h + iVar2) = unaff_R14;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = unaff_R15;
    *(uint64_t *)((int64_t)&var_8h + iVar2) = uVar7;
    if ((in_RDX == 0) && (uVar7 <= in_RCX)) {
        *(int64_t *)(&stack0x00000000 + iVar2) = in_R8 + 2;
        bVar10 = true;
        uVar3 = uVar4;
code_r0x000180206e3c:
        if (in_RCX < in_R8 + 2U) goto code_r0x000180206e54;
        *(int64_t *)(&stack0xfffffffffffffff8 + iVar2) = in_R8 + 4;
        bVar11 = true;
        uVar7 = uVar4;
code_r0x000180206e98:
        if (in_RCX < in_R8 + 4U) goto code_r0x000180206eb1;
        *(int64_t *)((int64_t)&arg_68h + iVar2) = in_R8 + 8;
        bVar12 = true;
        uVar6 = uVar4;
code_r0x000180206ef5:
        uVar5 = uVar4;
        if (in_RCX < in_R8 + 8U) goto code_r0x000180206eff;
    } else {
        uVar3 = 0x3f;
        if (in_RDX < 0x40) {
            uVar3 = in_RDX;
        }
        if ((in_RCX < in_R8 + 1 + uVar3) && (uVar3 = uVar4, uVar7 <= in_RCX)) {
            uVar3 = (in_RCX - in_R8) - 1;
        }
        bVar10 = uVar3 != 0;
        *(int64_t *)(&stack0x00000000 + iVar2) = in_R8 + 2;
        if (in_RDX == 0) goto code_r0x000180206e3c;
code_r0x000180206e54:
        uVar7 = 0x3fff;
        if (in_RDX < 0x4000) {
            uVar7 = in_RDX;
        }
        if ((in_RCX < in_R8 + 2U + uVar7) && (uVar7 = uVar4, in_R8 + 2U <= in_RCX)) {
            uVar7 = (in_RCX - in_R8) - 2;
        }
        bVar11 = uVar7 != 0;
        *(int64_t *)(&stack0xfffffffffffffff8 + iVar2) = in_R8 + 4;
        if (in_RDX == 0) goto code_r0x000180206e98;
code_r0x000180206eb1:
        uVar6 = 0x3fffffff;
        if (in_RDX < 0x40000000) {
            uVar6 = in_RDX;
        }
        if ((in_RCX < in_R8 + 4U + uVar6) && (uVar6 = uVar4, in_R8 + 4U <= in_RCX)) {
            uVar6 = (in_RCX - in_R8) - 4;
        }
        bVar12 = uVar6 != 0;
        *(int64_t *)((int64_t)&arg_68h + iVar2) = in_R8 + 8;
        if (in_RDX == 0) goto code_r0x000180206ef5;
code_r0x000180206eff:
        uVar5 = 0x3fffffffffffffff;
        if (in_RDX < 0x4000000000000000) {
            uVar5 = in_RDX;
        }
        if ((in_RCX < in_R8 + 8U + uVar5) && (uVar5 = uVar4, in_R8 + 8U <= in_RCX)) {
            uVar5 = (in_RCX - in_R8) - 8;
        }
        uVar8 = uVar4;
        uVar9 = uVar4;
        if (uVar5 == 0) goto code_r0x000180206f43;
    }
    uVar4 = *(uint64_t *)((int64_t)&arg_68h + iVar2);
    uVar8 = 1;
    uVar9 = uVar5;
code_r0x000180206f43:
    if ((bVar12) && (uVar9 <= uVar6)) {
        uVar4 = *(uint64_t *)(&stack0xfffffffffffffff8 + iVar2);
        uVar8 = 1;
        uVar9 = uVar6;
    }
    if ((bVar11) && (uVar9 <= uVar7)) {
        uVar4 = *(uint64_t *)(&stack0x00000000 + iVar2);
        uVar8 = 1;
        uVar9 = uVar7;
    }
    if ((bVar10) && (uVar9 <= uVar3)) {
        uVar4 = *(uint64_t *)((int64_t)&var_8h + iVar2);
        uVar8 = 1;
        uVar9 = uVar3;
    }
    puVar1 = *(uint64_t **)((int64_t)&arg_78h + iVar2);
    **(uint64_t **)((int64_t)&arg_70h + iVar2) = uVar4;
    *puVar1 = uVar9;
    return uVar8;
}

// ============================================================
// Function: FUN_180206da3
// Address: 0x180206da3
// Size: 441 bytes
// ============================================================
uint64_t fcn.180206d90(int64_t arg4, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h
                      , int64_t arg_68h, int64_t arg_70h, int64_t arg_78h)
{
    uint64_t *puVar1;
    int64_t iVar2;
    uint64_t in_RCX;
    uint64_t in_RDX;
    uint64_t uVar3;
    undefined8 unaff_RBX;
    uint64_t uVar4;
    undefined8 unaff_RSI;
    uint64_t uVar5;
    undefined8 unaff_RDI;
    uint64_t uVar6;
    int64_t in_R8;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar10;
    bool bVar11;
    bool bVar12;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    
    var_20h = arg4;
    iVar2 = func_0x00018045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&arg_58h + iVar2) = unaff_RBX;
    uVar7 = in_R8 + 1;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_RSI;
    uVar4 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_R13;
    *(undefined8 *)((int64_t)&var_20h + iVar2) = unaff_R14;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = unaff_R15;
    *(uint64_t *)((int64_t)&var_8h + iVar2) = uVar7;
    if ((in_RDX == 0) && (uVar7 <= in_RCX)) {
        *(int64_t *)(&stack0x00000000 + iVar2) = in_R8 + 2;
        bVar10 = true;
        uVar3 = uVar4;
code_r0x000180206e3c:
        if (in_RCX < in_R8 + 2U) goto code_r0x000180206e54;
        *(int64_t *)(&stack0xfffffffffffffff8 + iVar2) = in_R8 + 4;
        bVar11 = true;
        uVar7 = uVar4;
code_r0x000180206e98:
        if (in_RCX < in_R8 + 4U) goto code_r0x000180206eb1;
        *(int64_t *)((int64_t)&arg_68h + iVar2) = in_R8 + 8;
        bVar12 = true;
        uVar6 = uVar4;
code_r0x000180206ef5:
        uVar5 = uVar4;
        if (in_RCX < in_R8 + 8U) goto code_r0x000180206eff;
    } else {
        uVar3 = 0x3f;
        if (in_RDX < 0x40) {
            uVar3 = in_RDX;
        }
        if ((in_RCX < in_R8 + 1 + uVar3) && (uVar3 = uVar4, uVar7 <= in_RCX)) {
            uVar3 = (in_RCX - in_R8) - 1;
        }
        bVar10 = uVar3 != 0;
        *(int64_t *)(&stack0x00000000 + iVar2) = in_R8 + 2;
        if (in_RDX == 0) goto code_r0x000180206e3c;
code_r0x000180206e54:
        uVar7 = 0x3fff;
        if (in_RDX < 0x4000) {
            uVar7 = in_RDX;
        }
        if ((in_RCX < in_R8 + 2U + uVar7) && (uVar7 = uVar4, in_R8 + 2U <= in_RCX)) {
            uVar7 = (in_RCX - in_R8) - 2;
        }
        bVar11 = uVar7 != 0;
        *(int64_t *)(&stack0xfffffffffffffff8 + iVar2) = in_R8 + 4;
        if (in_RDX == 0) goto code_r0x000180206e98;
code_r0x000180206eb1:
        uVar6 = 0x3fffffff;
        if (in_RDX < 0x40000000) {
            uVar6 = in_RDX;
        }
        if ((in_RCX < in_R8 + 4U + uVar6) && (uVar6 = uVar4, in_R8 + 4U <= in_RCX)) {
            uVar6 = (in_RCX - in_R8) - 4;
        }
        bVar12 = uVar6 != 0;
        *(int64_t *)((int64_t)&arg_68h + iVar2) = in_R8 + 8;
        if (in_RDX == 0) goto code_r0x000180206ef5;
code_r0x000180206eff:
        uVar5 = 0x3fffffffffffffff;
        if (in_RDX < 0x4000000000000000) {
            uVar5 = in_RDX;
        }
        if ((in_RCX < in_R8 + 8U + uVar5) && (uVar5 = uVar4, in_R8 + 8U <= in_RCX)) {
            uVar5 = (in_RCX - in_R8) - 8;
        }
        uVar8 = uVar4;
        uVar9 = uVar4;
        if (uVar5 == 0) goto code_r0x000180206f43;
    }
    uVar4 = *(uint64_t *)((int64_t)&arg_68h + iVar2);
    uVar8 = 1;
    uVar9 = uVar5;
code_r0x000180206f43:
    if ((bVar12) && (uVar9 <= uVar6)) {
        uVar4 = *(uint64_t *)(&stack0xfffffffffffffff8 + iVar2);
        uVar8 = 1;
        uVar9 = uVar6;
    }
    if ((bVar11) && (uVar9 <= uVar7)) {
        uVar4 = *(uint64_t *)(&stack0x00000000 + iVar2);
        uVar8 = 1;
        uVar9 = uVar7;
    }
    if ((bVar10) && (uVar9 <= uVar3)) {
        uVar4 = *(uint64_t *)((int64_t)&var_8h + iVar2);
        uVar8 = 1;
        uVar9 = uVar3;
    }
    puVar1 = *(uint64_t **)((int64_t)&arg_78h + iVar2);
    **(uint64_t **)((int64_t)&arg_70h + iVar2) = uVar4;
    *puVar1 = uVar9;
    return uVar8;
}

// ============================================================
// Function: FUN_180206f5c
// Address: 0x180206f5c
// Size: 33 bytes
// ============================================================
uint64_t fcn.180206d90(int64_t arg4, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h
                      , int64_t arg_68h, int64_t arg_70h, int64_t arg_78h)
{
    uint64_t *puVar1;
    int64_t iVar2;
    uint64_t in_RCX;
    uint64_t in_RDX;
    uint64_t uVar3;
    undefined8 unaff_RBX;
    uint64_t uVar4;
    undefined8 unaff_RSI;
    uint64_t uVar5;
    undefined8 unaff_RDI;
    uint64_t uVar6;
    int64_t in_R8;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar10;
    bool bVar11;
    bool bVar12;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    
    var_20h = arg4;
    iVar2 = func_0x00018045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&arg_58h + iVar2) = unaff_RBX;
    uVar7 = in_R8 + 1;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_RSI;
    uVar4 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_R13;
    *(undefined8 *)((int64_t)&var_20h + iVar2) = unaff_R14;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = unaff_R15;
    *(uint64_t *)((int64_t)&var_8h + iVar2) = uVar7;
    if ((in_RDX == 0) && (uVar7 <= in_RCX)) {
        *(int64_t *)(&stack0x00000000 + iVar2) = in_R8 + 2;
        bVar10 = true;
        uVar3 = uVar4;
code_r0x000180206e3c:
        if (in_RCX < in_R8 + 2U) goto code_r0x000180206e54;
        *(int64_t *)(&stack0xfffffffffffffff8 + iVar2) = in_R8 + 4;
        bVar11 = true;
        uVar7 = uVar4;
code_r0x000180206e98:
        if (in_RCX < in_R8 + 4U) goto code_r0x000180206eb1;
        *(int64_t *)((int64_t)&arg_68h + iVar2) = in_R8 + 8;
        bVar12 = true;
        uVar6 = uVar4;
code_r0x000180206ef5:
        uVar5 = uVar4;
        if (in_RCX < in_R8 + 8U) goto code_r0x000180206eff;
    } else {
        uVar3 = 0x3f;
        if (in_RDX < 0x40) {
            uVar3 = in_RDX;
        }
        if ((in_RCX < in_R8 + 1 + uVar3) && (uVar3 = uVar4, uVar7 <= in_RCX)) {
            uVar3 = (in_RCX - in_R8) - 1;
        }
        bVar10 = uVar3 != 0;
        *(int64_t *)(&stack0x00000000 + iVar2) = in_R8 + 2;
        if (in_RDX == 0) goto code_r0x000180206e3c;
code_r0x000180206e54:
        uVar7 = 0x3fff;
        if (in_RDX < 0x4000) {
            uVar7 = in_RDX;
        }
        if ((in_RCX < in_R8 + 2U + uVar7) && (uVar7 = uVar4, in_R8 + 2U <= in_RCX)) {
            uVar7 = (in_RCX - in_R8) - 2;
        }
        bVar11 = uVar7 != 0;
        *(int64_t *)(&stack0xfffffffffffffff8 + iVar2) = in_R8 + 4;
        if (in_RDX == 0) goto code_r0x000180206e98;
code_r0x000180206eb1:
        uVar6 = 0x3fffffff;
        if (in_RDX < 0x40000000) {
            uVar6 = in_RDX;
        }
        if ((in_RCX < in_R8 + 4U + uVar6) && (uVar6 = uVar4, in_R8 + 4U <= in_RCX)) {
            uVar6 = (in_RCX - in_R8) - 4;
        }
        bVar12 = uVar6 != 0;
        *(int64_t *)((int64_t)&arg_68h + iVar2) = in_R8 + 8;
        if (in_RDX == 0) goto code_r0x000180206ef5;
code_r0x000180206eff:
        uVar5 = 0x3fffffffffffffff;
        if (in_RDX < 0x4000000000000000) {
            uVar5 = in_RDX;
        }
        if ((in_RCX < in_R8 + 8U + uVar5) && (uVar5 = uVar4, in_R8 + 8U <= in_RCX)) {
            uVar5 = (in_RCX - in_R8) - 8;
        }
        uVar8 = uVar4;
        uVar9 = uVar4;
        if (uVar5 == 0) goto code_r0x000180206f43;
    }
    uVar4 = *(uint64_t *)((int64_t)&arg_68h + iVar2);
    uVar8 = 1;
    uVar9 = uVar5;
code_r0x000180206f43:
    if ((bVar12) && (uVar9 <= uVar6)) {
        uVar4 = *(uint64_t *)(&stack0xfffffffffffffff8 + iVar2);
        uVar8 = 1;
        uVar9 = uVar6;
    }
    if ((bVar11) && (uVar9 <= uVar7)) {
        uVar4 = *(uint64_t *)(&stack0x00000000 + iVar2);
        uVar8 = 1;
        uVar9 = uVar7;
    }
    if ((bVar10) && (uVar9 <= uVar3)) {
        uVar4 = *(uint64_t *)((int64_t)&var_8h + iVar2);
        uVar8 = 1;
        uVar9 = uVar3;
    }
    puVar1 = *(uint64_t **)((int64_t)&arg_78h + iVar2);
    **(uint64_t **)((int64_t)&arg_70h + iVar2) = uVar4;
    *puVar1 = uVar9;
    return uVar8;
}

// ============================================================
// Function: FUN_180206f7d
// Address: 0x180206f7d
// Size: 29 bytes
// ============================================================
uint64_t fcn.180206d90(int64_t arg4, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h
                      , int64_t arg_68h, int64_t arg_70h, int64_t arg_78h)
{
    uint64_t *puVar1;
    int64_t iVar2;
    uint64_t in_RCX;
    uint64_t in_RDX;
    uint64_t uVar3;
    undefined8 unaff_RBX;
    uint64_t uVar4;
    undefined8 unaff_RSI;
    uint64_t uVar5;
    undefined8 unaff_RDI;
    uint64_t uVar6;
    int64_t in_R8;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar10;
    bool bVar11;
    bool bVar12;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    
    var_20h = arg4;
    iVar2 = func_0x00018045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&arg_58h + iVar2) = unaff_RBX;
    uVar7 = in_R8 + 1;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_RSI;
    uVar4 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_R13;
    *(undefined8 *)((int64_t)&var_20h + iVar2) = unaff_R14;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = unaff_R15;
    *(uint64_t *)((int64_t)&var_8h + iVar2) = uVar7;
    if ((in_RDX == 0) && (uVar7 <= in_RCX)) {
        *(int64_t *)(&stack0x00000000 + iVar2) = in_R8 + 2;
        bVar10 = true;
        uVar3 = uVar4;
code_r0x000180206e3c:
        if (in_RCX < in_R8 + 2U) goto code_r0x000180206e54;
        *(int64_t *)(&stack0xfffffffffffffff8 + iVar2) = in_R8 + 4;
        bVar11 = true;
        uVar7 = uVar4;
code_r0x000180206e98:
        if (in_RCX < in_R8 + 4U) goto code_r0x000180206eb1;
        *(int64_t *)((int64_t)&arg_68h + iVar2) = in_R8 + 8;
        bVar12 = true;
        uVar6 = uVar4;
code_r0x000180206ef5:
        uVar5 = uVar4;
        if (in_RCX < in_R8 + 8U) goto code_r0x000180206eff;
    } else {
        uVar3 = 0x3f;
        if (in_RDX < 0x40) {
            uVar3 = in_RDX;
        }
        if ((in_RCX < in_R8 + 1 + uVar3) && (uVar3 = uVar4, uVar7 <= in_RCX)) {
            uVar3 = (in_RCX - in_R8) - 1;
        }
        bVar10 = uVar3 != 0;
        *(int64_t *)(&stack0x00000000 + iVar2) = in_R8 + 2;
        if (in_RDX == 0) goto code_r0x000180206e3c;
code_r0x000180206e54:
        uVar7 = 0x3fff;
        if (in_RDX < 0x4000) {
            uVar7 = in_RDX;
        }
        if ((in_RCX < in_R8 + 2U + uVar7) && (uVar7 = uVar4, in_R8 + 2U <= in_RCX)) {
            uVar7 = (in_RCX - in_R8) - 2;
        }
        bVar11 = uVar7 != 0;
        *(int64_t *)(&stack0xfffffffffffffff8 + iVar2) = in_R8 + 4;
        if (in_RDX == 0) goto code_r0x000180206e98;
code_r0x000180206eb1:
        uVar6 = 0x3fffffff;
        if (in_RDX < 0x40000000) {
            uVar6 = in_RDX;
        }
        if ((in_RCX < in_R8 + 4U + uVar6) && (uVar6 = uVar4, in_R8 + 4U <= in_RCX)) {
            uVar6 = (in_RCX - in_R8) - 4;
        }
        bVar12 = uVar6 != 0;
        *(int64_t *)((int64_t)&arg_68h + iVar2) = in_R8 + 8;
        if (in_RDX == 0) goto code_r0x000180206ef5;
code_r0x000180206eff:
        uVar5 = 0x3fffffffffffffff;
        if (in_RDX < 0x4000000000000000) {
            uVar5 = in_RDX;
        }
        if ((in_RCX < in_R8 + 8U + uVar5) && (uVar5 = uVar4, in_R8 + 8U <= in_RCX)) {
            uVar5 = (in_RCX - in_R8) - 8;
        }
        uVar8 = uVar4;
        uVar9 = uVar4;
        if (uVar5 == 0) goto code_r0x000180206f43;
    }
    uVar4 = *(uint64_t *)((int64_t)&arg_68h + iVar2);
    uVar8 = 1;
    uVar9 = uVar5;
code_r0x000180206f43:
    if ((bVar12) && (uVar9 <= uVar6)) {
        uVar4 = *(uint64_t *)(&stack0xfffffffffffffff8 + iVar2);
        uVar8 = 1;
        uVar9 = uVar6;
    }
    if ((bVar11) && (uVar9 <= uVar7)) {
        uVar4 = *(uint64_t *)(&stack0x00000000 + iVar2);
        uVar8 = 1;
        uVar9 = uVar7;
    }
    if ((bVar10) && (uVar9 <= uVar3)) {
        uVar4 = *(uint64_t *)((int64_t)&var_8h + iVar2);
        uVar8 = 1;
        uVar9 = uVar3;
    }
    puVar1 = *(uint64_t **)((int64_t)&arg_78h + iVar2);
    **(uint64_t **)((int64_t)&arg_70h + iVar2) = uVar4;
    *puVar1 = uVar9;
    return uVar8;
}

// ============================================================
// Function: FUN_180206f9a
// Address: 0x180206f9a
// Size: 47 bytes
// ============================================================
uint64_t fcn.180206d90(int64_t arg4, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h
                      , int64_t arg_68h, int64_t arg_70h, int64_t arg_78h)
{
    uint64_t *puVar1;
    int64_t iVar2;
    uint64_t in_RCX;
    uint64_t in_RDX;
    uint64_t uVar3;
    undefined8 unaff_RBX;
    uint64_t uVar4;
    undefined8 unaff_RSI;
    uint64_t uVar5;
    undefined8 unaff_RDI;
    uint64_t uVar6;
    int64_t in_R8;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar10;
    bool bVar11;
    bool bVar12;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    
    var_20h = arg4;
    iVar2 = func_0x00018045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&arg_58h + iVar2) = unaff_RBX;
    uVar7 = in_R8 + 1;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_RSI;
    uVar4 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_R13;
    *(undefined8 *)((int64_t)&var_20h + iVar2) = unaff_R14;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = unaff_R15;
    *(uint64_t *)((int64_t)&var_8h + iVar2) = uVar7;
    if ((in_RDX == 0) && (uVar7 <= in_RCX)) {
        *(int64_t *)(&stack0x00000000 + iVar2) = in_R8 + 2;
        bVar10 = true;
        uVar3 = uVar4;
code_r0x000180206e3c:
        if (in_RCX < in_R8 + 2U) goto code_r0x000180206e54;
        *(int64_t *)(&stack0xfffffffffffffff8 + iVar2) = in_R8 + 4;
        bVar11 = true;
        uVar7 = uVar4;
code_r0x000180206e98:
        if (in_RCX < in_R8 + 4U) goto code_r0x000180206eb1;
        *(int64_t *)((int64_t)&arg_68h + iVar2) = in_R8 + 8;
        bVar12 = true;
        uVar6 = uVar4;
code_r0x000180206ef5:
        uVar5 = uVar4;
        if (in_RCX < in_R8 + 8U) goto code_r0x000180206eff;
    } else {
        uVar3 = 0x3f;
        if (in_RDX < 0x40) {
            uVar3 = in_RDX;
        }
        if ((in_RCX < in_R8 + 1 + uVar3) && (uVar3 = uVar4, uVar7 <= in_RCX)) {
            uVar3 = (in_RCX - in_R8) - 1;
        }
        bVar10 = uVar3 != 0;
        *(int64_t *)(&stack0x00000000 + iVar2) = in_R8 + 2;
        if (in_RDX == 0) goto code_r0x000180206e3c;
code_r0x000180206e54:
        uVar7 = 0x3fff;
        if (in_RDX < 0x4000) {
            uVar7 = in_RDX;
        }
        if ((in_RCX < in_R8 + 2U + uVar7) && (uVar7 = uVar4, in_R8 + 2U <= in_RCX)) {
            uVar7 = (in_RCX - in_R8) - 2;
        }
        bVar11 = uVar7 != 0;
        *(int64_t *)(&stack0xfffffffffffffff8 + iVar2) = in_R8 + 4;
        if (in_RDX == 0) goto code_r0x000180206e98;
code_r0x000180206eb1:
        uVar6 = 0x3fffffff;
        if (in_RDX < 0x40000000) {
            uVar6 = in_RDX;
        }
        if ((in_RCX < in_R8 + 4U + uVar6) && (uVar6 = uVar4, in_R8 + 4U <= in_RCX)) {
            uVar6 = (in_RCX - in_R8) - 4;
        }
        bVar12 = uVar6 != 0;
        *(int64_t *)((int64_t)&arg_68h + iVar2) = in_R8 + 8;
        if (in_RDX == 0) goto code_r0x000180206ef5;
code_r0x000180206eff:
        uVar5 = 0x3fffffffffffffff;
        if (in_RDX < 0x4000000000000000) {
            uVar5 = in_RDX;
        }
        if ((in_RCX < in_R8 + 8U + uVar5) && (uVar5 = uVar4, in_R8 + 8U <= in_RCX)) {
            uVar5 = (in_RCX - in_R8) - 8;
        }
        uVar8 = uVar4;
        uVar9 = uVar4;
        if (uVar5 == 0) goto code_r0x000180206f43;
    }
    uVar4 = *(uint64_t *)((int64_t)&arg_68h + iVar2);
    uVar8 = 1;
    uVar9 = uVar5;
code_r0x000180206f43:
    if ((bVar12) && (uVar9 <= uVar6)) {
        uVar4 = *(uint64_t *)(&stack0xfffffffffffffff8 + iVar2);
        uVar8 = 1;
        uVar9 = uVar6;
    }
    if ((bVar11) && (uVar9 <= uVar7)) {
        uVar4 = *(uint64_t *)(&stack0x00000000 + iVar2);
        uVar8 = 1;
        uVar9 = uVar7;
    }
    if ((bVar10) && (uVar9 <= uVar3)) {
        uVar4 = *(uint64_t *)((int64_t)&var_8h + iVar2);
        uVar8 = 1;
        uVar9 = uVar3;
    }
    puVar1 = *(uint64_t **)((int64_t)&arg_78h + iVar2);
    **(uint64_t **)((int64_t)&arg_70h + iVar2) = uVar4;
    *puVar1 = uVar9;
    return uVar8;
}

// ============================================================
// Function: FUN_180206fd0
// Address: 0x180206fd0
// Size: 65 bytes
// ============================================================
undefined8 fcn.180206fd0(int64_t param_1, uint64_t param_2, int64_t param_3)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x180206fda;
    iVar1 = fcn.18045a350();
    if (param_1 == -1) {
        return *(undefined8 *)(param_3 + 0xd0 + (param_2 & 0xffffffff) * 8);
    }
    *(undefined8 *)((int64_t)&uStack_8 + -iVar1) = 0x180206ffe;
    iVar1 = fcn.1801e7870(*(int64_t *)(&stack0x00000050 + -iVar1));
    if (iVar1 == 0) {
        return 0;
    }
    return *(undefined8 *)(iVar1 + 0x70);
}

// ============================================================
// Function: FUN_180207020
// Address: 0x180207020
// Size: 72 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018020708d: Changing call to branch

void fcn.180207020(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h,
                  int64_t arg_c0h)
{
    int64_t **ppiVar1;
    char cVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    code *pcVar5;
    uint32_t uVar6;
    int32_t iVar7;
    uint32_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t *piVar12;
    int64_t iVar13;
    int64_t *piVar14;
    int64_t iVar15;
    int64_t *piVar16;
    int64_t in_RCX;
    undefined *puVar17;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t *unaff_RDI;
    int64_t in_R9;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    undefined auStackX_20 [8];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020702c;
    iVar13 = fcn.18045a350();
    iVar13 = -iVar13;
    if (in_RCX == 4) {
        *(int64_t **)((int64_t)&arg_28h + iVar13) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar13) = 0x180207072;
        piVar14 = (int64_t *)fcn.1801e7870(*(int64_t *)(&stack0x00000048 + iVar13));
        if (piVar14 == (int64_t *)0x0) {
            return;
        }
        uVar3 = *(undefined8 *)(in_R9 + 0x70);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13) = 0x180207086;
        func_0x0001801e7b50(uVar3, piVar14);
        iVar15 = *(int64_t *)(in_R9 + 0x70);
        puVar17 = (undefined *)((int64_t)&uStack_10 + iVar13);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13) = 0x180207092;
        unaff_RDI = piVar14;
    } else {
        if (in_RCX != 5) {
            return;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar13) = 0x180207047;
        piVar14 = (int64_t *)fcn.1801e7870(*(int64_t *)(&stack0x00000048 + iVar13));
        if (piVar14 == (int64_t *)0x0) {
            return;
        }
        *(uint32_t *)((int64_t)piVar14 + 0x104) = *(uint32_t *)((int64_t)piVar14 + 0x104) | 0x10;
        iVar15 = *(int64_t *)(in_R9 + 0x70);
        in_R9 = *(int64_t *)((int64_t)&iStackX_18 + iVar13);
        puVar17 = auStackX_20 + iVar13;
    }
    *(int64_t *)(puVar17 + 0x20) = in_R9;
    *(undefined8 *)(puVar17 + -8) = unaff_RBP;
    *(undefined8 *)(puVar17 + -0x10) = unaff_RSI;
    *(undefined8 *)(puVar17 + -0x18) = unaff_R15;
    *(undefined8 *)(puVar17 + -0x20) = 0x1801e7fc3;
    iVar13 = fcn.18045a350();
    iVar13 = -iVar13;
    uVar8 = *(uint32_t *)(piVar14 + 0x20);
    uVar3 = *(undefined8 *)(iVar15 + 8);
    *(undefined8 *)(puVar17 + iVar13 + 0x98) = unaff_R14;
    bVar18 = true;
    *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e7fe9;
    uVar6 = func_0x0001801e3b40(uVar3);
    if ((uVar8 & 1) == uVar6) {
        uVar8 = *(uint32_t *)(piVar14 + 0x20);
        uVar4 = piVar14[7];
        pcVar5 = *(code **)(iVar15 + 0x70);
        if (pcVar5 != (code *)0x0) {
            uVar3 = *(undefined8 *)(iVar15 + 0x78);
            *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e801c;
            uVar9 = (*pcVar5)((uVar8 & 2) != 0, uVar3);
            bVar18 = uVar4 >> 2 < uVar9;
        }
    }
    cVar2 = *(char *)((int64_t)piVar14 + 0x101);
    *(int64_t **)(puVar17 + iVar13 + 0x90) = unaff_RDI;
    if (cVar2 == '\x03') {
        iVar10 = piVar14[0xe];
        *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e8040;
        iVar7 = func_0x0001801e6440(iVar10);
        if (iVar7 == 0) goto code_r0x0001801e8094;
        if ((*(char *)((int64_t)piVar14 + 0x101) != '\0') && (*(char *)((int64_t)piVar14 + 0x101) == '\x03')) {
            iVar10 = piVar14[0xe];
            *(undefined *)((int64_t)piVar14 + 0x101) = 4;
            *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e8063;
            func_0x0001801e6180(iVar10);
            piVar14[0xe] = 0;
            if ((char)*(uint32_t *)((int64_t)piVar14 + 0x104) < '\0') {
                *(uint32_t *)((int64_t)piVar14 + 0x104) = *(uint32_t *)((int64_t)piVar14 + 0x104) & 0xffffff7f;
                piVar16 = (int64_t *)(iVar15 + 0x60);
                *piVar16 = *piVar16 + -1;
                if (*piVar16 == 0) {
                    uVar3 = *(undefined8 *)(iVar15 + 8);
                    *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e808b;
                    func_0x0001801e3de0(uVar3);
                }
            }
        }
    } else {
code_r0x0001801e8094:
        if (((*(uint8_t *)((int64_t)piVar14 + 0x104) & 0x80) != 0) && (*(char *)((int64_t)piVar14 + 0x101) == '\x02')) {
            iVar10 = piVar14[0xe];
            *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e80b2;
            iVar7 = func_0x0001801e6440(iVar10);
            if (iVar7 != 0) {
                *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e80c1;
                func_0x0001801e8310(iVar15, piVar14);
            }
        }
    }
    uVar8 = *(uint32_t *)((int64_t)piVar14 + 0x104);
    if ((uVar8 & 0x40) == 0) {
        if ((((uVar8 & 0x20) == 0) || ((*(char *)((int64_t)piVar14 + 0x102) != '\0' && ((uVar8 & 0x10) == 0)))) ||
           ((cVar2 = *(char *)((int64_t)piVar14 + 0x101), cVar2 != '\0' && ((cVar2 != '\x04' && (cVar2 != '\x06')))))) {
            *(uint32_t *)((int64_t)piVar14 + 0x104) = uVar8 & 0xffffffbf;
        } else {
            piVar16 = piVar14 + 4;
            *(uint32_t *)((int64_t)piVar14 + 0x104) = uVar8 | 0x40;
            ppiVar1 = (int64_t **)(iVar15 + 0x30);
            piVar12 = *ppiVar1;
            *piVar16 = (int64_t)piVar12;
            piVar12[1] = (int64_t)piVar16;
            *ppiVar1 = piVar16;
            piVar14[5] = (int64_t)ppiVar1;
        }
    }
    if ((bVar18) && ((*(uint32_t *)((int64_t)piVar14 + 0x104) & 0x40) == 0)) {
        if ((*(char *)((int64_t)piVar14 + 0x102) == '\0') || (*(char *)((int64_t)piVar14 + 0x102) != '\x01')) {
code_r0x0001801e816c:
            if ((*(uint8_t *)((int64_t)piVar14 + 0x104) & 0xc) == 0) {
                if (((*(uint32_t *)(piVar14 + 0x20) >> 0x1b & 1) == 0) &&
                   (((uVar8 = *(uint32_t *)(piVar14 + 0x20) >> 8 & 0xff, uVar8 == 1 || (uVar8 == 2)) || (uVar8 == 3))))
                {
                    iVar10 = piVar14[0xe];
                    *(undefined **)(puVar17 + iVar13 + 8) = puVar17 + iVar13 + 0x88;
                    *(undefined8 *)(puVar17 + iVar13 + 0x88) = 2;
                    *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e81d0;
                    iVar7 = func_0x0001801e6230(iVar10, 0, puVar17 + iVar13 + 0x38, puVar17 + iVar13 + 0x18);
                    if (iVar7 != 0) {
                        *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e81e2;
                        iVar10 = func_0x0001801e5c20(piVar14 + 0x10, 0);
                        *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e81f1;
                        iVar11 = func_0x0001801bc820(piVar14 + 0x10);
                        if ((((puVar17[iVar13 + 0x58] & 2) != 0) && (*(int64_t *)(puVar17 + iVar13 + 0x48) == 0)) ||
                           (*(uint64_t *)(puVar17 + iVar13 + 0x40) < (uint64_t)(iVar11 + iVar10)))
                        goto code_r0x0001801e8209;
                    }
                }
                goto code_r0x0001801e8245;
            }
        } else if ((*(uint32_t *)((int64_t)piVar14 + 0x104) & 2) == 0) {
            *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e8164;
            iVar7 = func_0x0001801e59a0(piVar14 + 0x14, 0);
            if (iVar7 == 0) goto code_r0x0001801e816c;
        }
code_r0x0001801e8209:
        if ((*(uint32_t *)(piVar14 + 0x20) & 0x1000000) == 0) {
            iVar13 = *(int64_t *)(iVar15 + 0x10);
            *piVar14 = iVar13;
            *(int64_t **)(iVar13 + 8) = piVar14;
            *(int64_t **)(iVar15 + 0x10) = piVar14;
            piVar14[1] = (int64_t)(int64_t **)(iVar15 + 0x10);
            if (*(int64_t *)(iVar15 + 0x68) == 0) {
                *(int64_t **)(iVar15 + 0x68) = piVar14;
            }
            *(uint32_t *)(piVar14 + 0x20) = *(uint32_t *)(piVar14 + 0x20) | 0x1000000;
        }
    } else {
code_r0x0001801e8245:
        if ((*(uint32_t *)(piVar14 + 0x20) & 0x1000000) != 0) {
            if (*(int64_t **)(iVar15 + 0x68) == piVar14) {
                piVar16 = (int64_t *)piVar14[1];
                if (piVar16 == (int64_t *)(iVar15 + 0x10)) {
                    piVar16 = (int64_t *)piVar16[1];
                }
                piVar12 = (int64_t *)0x0;
                if (piVar16 != (int64_t *)(iVar15 + 0x10)) {
                    piVar12 = piVar16;
                }
                *(int64_t **)(iVar15 + 0x68) = piVar12;
                if (piVar12 == piVar14) {
                    *(undefined8 *)(iVar15 + 0x68) = 0;
                }
            }
            *(int64_t *)(*piVar14 + 8) = piVar14[1];
            *(int64_t *)piVar14[1] = *piVar14;
            *(uint32_t *)(piVar14 + 0x20) = *(uint32_t *)(piVar14 + 0x20) & 0xfeffffff;
            *piVar14 = 0;
            piVar14[1] = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180207068
// Address: 0x180207068
// Size: 47 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018020708d: Changing call to branch

void fcn.180207020(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h,
                  int64_t arg_c0h)
{
    int64_t **ppiVar1;
    char cVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    code *pcVar5;
    uint32_t uVar6;
    int32_t iVar7;
    uint32_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t *piVar12;
    int64_t iVar13;
    int64_t *piVar14;
    int64_t iVar15;
    int64_t *piVar16;
    int64_t in_RCX;
    undefined *puVar17;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t *unaff_RDI;
    int64_t in_R9;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    undefined auStackX_20 [8];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020702c;
    iVar13 = fcn.18045a350();
    iVar13 = -iVar13;
    if (in_RCX == 4) {
        *(int64_t **)((int64_t)&arg_28h + iVar13) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar13) = 0x180207072;
        piVar14 = (int64_t *)fcn.1801e7870(*(int64_t *)(&stack0x00000048 + iVar13));
        if (piVar14 == (int64_t *)0x0) {
            return;
        }
        uVar3 = *(undefined8 *)(in_R9 + 0x70);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13) = 0x180207086;
        func_0x0001801e7b50(uVar3, piVar14);
        iVar15 = *(int64_t *)(in_R9 + 0x70);
        puVar17 = (undefined *)((int64_t)&uStack_10 + iVar13);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13) = 0x180207092;
        unaff_RDI = piVar14;
    } else {
        if (in_RCX != 5) {
            return;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar13) = 0x180207047;
        piVar14 = (int64_t *)fcn.1801e7870(*(int64_t *)(&stack0x00000048 + iVar13));
        if (piVar14 == (int64_t *)0x0) {
            return;
        }
        *(uint32_t *)((int64_t)piVar14 + 0x104) = *(uint32_t *)((int64_t)piVar14 + 0x104) | 0x10;
        iVar15 = *(int64_t *)(in_R9 + 0x70);
        in_R9 = *(int64_t *)((int64_t)&iStackX_18 + iVar13);
        puVar17 = auStackX_20 + iVar13;
    }
    *(int64_t *)(puVar17 + 0x20) = in_R9;
    *(undefined8 *)(puVar17 + -8) = unaff_RBP;
    *(undefined8 *)(puVar17 + -0x10) = unaff_RSI;
    *(undefined8 *)(puVar17 + -0x18) = unaff_R15;
    *(undefined8 *)(puVar17 + -0x20) = 0x1801e7fc3;
    iVar13 = fcn.18045a350();
    iVar13 = -iVar13;
    uVar8 = *(uint32_t *)(piVar14 + 0x20);
    uVar3 = *(undefined8 *)(iVar15 + 8);
    *(undefined8 *)(puVar17 + iVar13 + 0x98) = unaff_R14;
    bVar18 = true;
    *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e7fe9;
    uVar6 = func_0x0001801e3b40(uVar3);
    if ((uVar8 & 1) == uVar6) {
        uVar8 = *(uint32_t *)(piVar14 + 0x20);
        uVar4 = piVar14[7];
        pcVar5 = *(code **)(iVar15 + 0x70);
        if (pcVar5 != (code *)0x0) {
            uVar3 = *(undefined8 *)(iVar15 + 0x78);
            *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e801c;
            uVar9 = (*pcVar5)((uVar8 & 2) != 0, uVar3);
            bVar18 = uVar4 >> 2 < uVar9;
        }
    }
    cVar2 = *(char *)((int64_t)piVar14 + 0x101);
    *(int64_t **)(puVar17 + iVar13 + 0x90) = unaff_RDI;
    if (cVar2 == '\x03') {
        iVar10 = piVar14[0xe];
        *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e8040;
        iVar7 = func_0x0001801e6440(iVar10);
        if (iVar7 == 0) goto code_r0x0001801e8094;
        if ((*(char *)((int64_t)piVar14 + 0x101) != '\0') && (*(char *)((int64_t)piVar14 + 0x101) == '\x03')) {
            iVar10 = piVar14[0xe];
            *(undefined *)((int64_t)piVar14 + 0x101) = 4;
            *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e8063;
            func_0x0001801e6180(iVar10);
            piVar14[0xe] = 0;
            if ((char)*(uint32_t *)((int64_t)piVar14 + 0x104) < '\0') {
                *(uint32_t *)((int64_t)piVar14 + 0x104) = *(uint32_t *)((int64_t)piVar14 + 0x104) & 0xffffff7f;
                piVar16 = (int64_t *)(iVar15 + 0x60);
                *piVar16 = *piVar16 + -1;
                if (*piVar16 == 0) {
                    uVar3 = *(undefined8 *)(iVar15 + 8);
                    *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e808b;
                    func_0x0001801e3de0(uVar3);
                }
            }
        }
    } else {
code_r0x0001801e8094:
        if (((*(uint8_t *)((int64_t)piVar14 + 0x104) & 0x80) != 0) && (*(char *)((int64_t)piVar14 + 0x101) == '\x02')) {
            iVar10 = piVar14[0xe];
            *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e80b2;
            iVar7 = func_0x0001801e6440(iVar10);
            if (iVar7 != 0) {
                *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e80c1;
                func_0x0001801e8310(iVar15, piVar14);
            }
        }
    }
    uVar8 = *(uint32_t *)((int64_t)piVar14 + 0x104);
    if ((uVar8 & 0x40) == 0) {
        if ((((uVar8 & 0x20) == 0) || ((*(char *)((int64_t)piVar14 + 0x102) != '\0' && ((uVar8 & 0x10) == 0)))) ||
           ((cVar2 = *(char *)((int64_t)piVar14 + 0x101), cVar2 != '\0' && ((cVar2 != '\x04' && (cVar2 != '\x06')))))) {
            *(uint32_t *)((int64_t)piVar14 + 0x104) = uVar8 & 0xffffffbf;
        } else {
            piVar16 = piVar14 + 4;
            *(uint32_t *)((int64_t)piVar14 + 0x104) = uVar8 | 0x40;
            ppiVar1 = (int64_t **)(iVar15 + 0x30);
            piVar12 = *ppiVar1;
            *piVar16 = (int64_t)piVar12;
            piVar12[1] = (int64_t)piVar16;
            *ppiVar1 = piVar16;
            piVar14[5] = (int64_t)ppiVar1;
        }
    }
    if ((bVar18) && ((*(uint32_t *)((int64_t)piVar14 + 0x104) & 0x40) == 0)) {
        if ((*(char *)((int64_t)piVar14 + 0x102) == '\0') || (*(char *)((int64_t)piVar14 + 0x102) != '\x01')) {
code_r0x0001801e816c:
            if ((*(uint8_t *)((int64_t)piVar14 + 0x104) & 0xc) == 0) {
                if (((*(uint32_t *)(piVar14 + 0x20) >> 0x1b & 1) == 0) &&
                   (((uVar8 = *(uint32_t *)(piVar14 + 0x20) >> 8 & 0xff, uVar8 == 1 || (uVar8 == 2)) || (uVar8 == 3))))
                {
                    iVar10 = piVar14[0xe];
                    *(undefined **)(puVar17 + iVar13 + 8) = puVar17 + iVar13 + 0x88;
                    *(undefined8 *)(puVar17 + iVar13 + 0x88) = 2;
                    *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e81d0;
                    iVar7 = func_0x0001801e6230(iVar10, 0, puVar17 + iVar13 + 0x38, puVar17 + iVar13 + 0x18);
                    if (iVar7 != 0) {
                        *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e81e2;
                        iVar10 = func_0x0001801e5c20(piVar14 + 0x10, 0);
                        *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e81f1;
                        iVar11 = func_0x0001801bc820(piVar14 + 0x10);
                        if ((((puVar17[iVar13 + 0x58] & 2) != 0) && (*(int64_t *)(puVar17 + iVar13 + 0x48) == 0)) ||
                           (*(uint64_t *)(puVar17 + iVar13 + 0x40) < (uint64_t)(iVar11 + iVar10)))
                        goto code_r0x0001801e8209;
                    }
                }
                goto code_r0x0001801e8245;
            }
        } else if ((*(uint32_t *)((int64_t)piVar14 + 0x104) & 2) == 0) {
            *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e8164;
            iVar7 = func_0x0001801e59a0(piVar14 + 0x14, 0);
            if (iVar7 == 0) goto code_r0x0001801e816c;
        }
code_r0x0001801e8209:
        if ((*(uint32_t *)(piVar14 + 0x20) & 0x1000000) == 0) {
            iVar13 = *(int64_t *)(iVar15 + 0x10);
            *piVar14 = iVar13;
            *(int64_t **)(iVar13 + 8) = piVar14;
            *(int64_t **)(iVar15 + 0x10) = piVar14;
            piVar14[1] = (int64_t)(int64_t **)(iVar15 + 0x10);
            if (*(int64_t *)(iVar15 + 0x68) == 0) {
                *(int64_t **)(iVar15 + 0x68) = piVar14;
            }
            *(uint32_t *)(piVar14 + 0x20) = *(uint32_t *)(piVar14 + 0x20) | 0x1000000;
        }
    } else {
code_r0x0001801e8245:
        if ((*(uint32_t *)(piVar14 + 0x20) & 0x1000000) != 0) {
            if (*(int64_t **)(iVar15 + 0x68) == piVar14) {
                piVar16 = (int64_t *)piVar14[1];
                if (piVar16 == (int64_t *)(iVar15 + 0x10)) {
                    piVar16 = (int64_t *)piVar16[1];
                }
                piVar12 = (int64_t *)0x0;
                if (piVar16 != (int64_t *)(iVar15 + 0x10)) {
                    piVar12 = piVar16;
                }
                *(int64_t **)(iVar15 + 0x68) = piVar12;
                if (piVar12 == piVar14) {
                    *(undefined8 *)(iVar15 + 0x68) = 0;
                }
            }
            *(int64_t *)(*piVar14 + 8) = piVar14[1];
            *(int64_t *)piVar14[1] = *piVar14;
            *(uint32_t *)(piVar14 + 0x20) = *(uint32_t *)(piVar14 + 0x20) & 0xfeffffff;
            *piVar14 = 0;
            piVar14[1] = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180207097
// Address: 0x180207097
// Size: 6 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018020708d: Changing call to branch

void fcn.180207020(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h,
                  int64_t arg_c0h)
{
    int64_t **ppiVar1;
    char cVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    code *pcVar5;
    uint32_t uVar6;
    int32_t iVar7;
    uint32_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t *piVar12;
    int64_t iVar13;
    int64_t *piVar14;
    int64_t iVar15;
    int64_t *piVar16;
    int64_t in_RCX;
    undefined *puVar17;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t *unaff_RDI;
    int64_t in_R9;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    undefined auStackX_20 [8];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020702c;
    iVar13 = fcn.18045a350();
    iVar13 = -iVar13;
    if (in_RCX == 4) {
        *(int64_t **)((int64_t)&arg_28h + iVar13) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar13) = 0x180207072;
        piVar14 = (int64_t *)fcn.1801e7870(*(int64_t *)(&stack0x00000048 + iVar13));
        if (piVar14 == (int64_t *)0x0) {
            return;
        }
        uVar3 = *(undefined8 *)(in_R9 + 0x70);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13) = 0x180207086;
        func_0x0001801e7b50(uVar3, piVar14);
        iVar15 = *(int64_t *)(in_R9 + 0x70);
        puVar17 = (undefined *)((int64_t)&uStack_10 + iVar13);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13) = 0x180207092;
        unaff_RDI = piVar14;
    } else {
        if (in_RCX != 5) {
            return;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar13) = 0x180207047;
        piVar14 = (int64_t *)fcn.1801e7870(*(int64_t *)(&stack0x00000048 + iVar13));
        if (piVar14 == (int64_t *)0x0) {
            return;
        }
        *(uint32_t *)((int64_t)piVar14 + 0x104) = *(uint32_t *)((int64_t)piVar14 + 0x104) | 0x10;
        iVar15 = *(int64_t *)(in_R9 + 0x70);
        in_R9 = *(int64_t *)((int64_t)&iStackX_18 + iVar13);
        puVar17 = auStackX_20 + iVar13;
    }
    *(int64_t *)(puVar17 + 0x20) = in_R9;
    *(undefined8 *)(puVar17 + -8) = unaff_RBP;
    *(undefined8 *)(puVar17 + -0x10) = unaff_RSI;
    *(undefined8 *)(puVar17 + -0x18) = unaff_R15;
    *(undefined8 *)(puVar17 + -0x20) = 0x1801e7fc3;
    iVar13 = fcn.18045a350();
    iVar13 = -iVar13;
    uVar8 = *(uint32_t *)(piVar14 + 0x20);
    uVar3 = *(undefined8 *)(iVar15 + 8);
    *(undefined8 *)(puVar17 + iVar13 + 0x98) = unaff_R14;
    bVar18 = true;
    *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e7fe9;
    uVar6 = func_0x0001801e3b40(uVar3);
    if ((uVar8 & 1) == uVar6) {
        uVar8 = *(uint32_t *)(piVar14 + 0x20);
        uVar4 = piVar14[7];
        pcVar5 = *(code **)(iVar15 + 0x70);
        if (pcVar5 != (code *)0x0) {
            uVar3 = *(undefined8 *)(iVar15 + 0x78);
            *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e801c;
            uVar9 = (*pcVar5)((uVar8 & 2) != 0, uVar3);
            bVar18 = uVar4 >> 2 < uVar9;
        }
    }
    cVar2 = *(char *)((int64_t)piVar14 + 0x101);
    *(int64_t **)(puVar17 + iVar13 + 0x90) = unaff_RDI;
    if (cVar2 == '\x03') {
        iVar10 = piVar14[0xe];
        *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e8040;
        iVar7 = func_0x0001801e6440(iVar10);
        if (iVar7 == 0) goto code_r0x0001801e8094;
        if ((*(char *)((int64_t)piVar14 + 0x101) != '\0') && (*(char *)((int64_t)piVar14 + 0x101) == '\x03')) {
            iVar10 = piVar14[0xe];
            *(undefined *)((int64_t)piVar14 + 0x101) = 4;
            *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e8063;
            func_0x0001801e6180(iVar10);
            piVar14[0xe] = 0;
            if ((char)*(uint32_t *)((int64_t)piVar14 + 0x104) < '\0') {
                *(uint32_t *)((int64_t)piVar14 + 0x104) = *(uint32_t *)((int64_t)piVar14 + 0x104) & 0xffffff7f;
                piVar16 = (int64_t *)(iVar15 + 0x60);
                *piVar16 = *piVar16 + -1;
                if (*piVar16 == 0) {
                    uVar3 = *(undefined8 *)(iVar15 + 8);
                    *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e808b;
                    func_0x0001801e3de0(uVar3);
                }
            }
        }
    } else {
code_r0x0001801e8094:
        if (((*(uint8_t *)((int64_t)piVar14 + 0x104) & 0x80) != 0) && (*(char *)((int64_t)piVar14 + 0x101) == '\x02')) {
            iVar10 = piVar14[0xe];
            *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e80b2;
            iVar7 = func_0x0001801e6440(iVar10);
            if (iVar7 != 0) {
                *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e80c1;
                func_0x0001801e8310(iVar15, piVar14);
            }
        }
    }
    uVar8 = *(uint32_t *)((int64_t)piVar14 + 0x104);
    if ((uVar8 & 0x40) == 0) {
        if ((((uVar8 & 0x20) == 0) || ((*(char *)((int64_t)piVar14 + 0x102) != '\0' && ((uVar8 & 0x10) == 0)))) ||
           ((cVar2 = *(char *)((int64_t)piVar14 + 0x101), cVar2 != '\0' && ((cVar2 != '\x04' && (cVar2 != '\x06')))))) {
            *(uint32_t *)((int64_t)piVar14 + 0x104) = uVar8 & 0xffffffbf;
        } else {
            piVar16 = piVar14 + 4;
            *(uint32_t *)((int64_t)piVar14 + 0x104) = uVar8 | 0x40;
            ppiVar1 = (int64_t **)(iVar15 + 0x30);
            piVar12 = *ppiVar1;
            *piVar16 = (int64_t)piVar12;
            piVar12[1] = (int64_t)piVar16;
            *ppiVar1 = piVar16;
            piVar14[5] = (int64_t)ppiVar1;
        }
    }
    if ((bVar18) && ((*(uint32_t *)((int64_t)piVar14 + 0x104) & 0x40) == 0)) {
        if ((*(char *)((int64_t)piVar14 + 0x102) == '\0') || (*(char *)((int64_t)piVar14 + 0x102) != '\x01')) {
code_r0x0001801e816c:
            if ((*(uint8_t *)((int64_t)piVar14 + 0x104) & 0xc) == 0) {
                if (((*(uint32_t *)(piVar14 + 0x20) >> 0x1b & 1) == 0) &&
                   (((uVar8 = *(uint32_t *)(piVar14 + 0x20) >> 8 & 0xff, uVar8 == 1 || (uVar8 == 2)) || (uVar8 == 3))))
                {
                    iVar10 = piVar14[0xe];
                    *(undefined **)(puVar17 + iVar13 + 8) = puVar17 + iVar13 + 0x88;
                    *(undefined8 *)(puVar17 + iVar13 + 0x88) = 2;
                    *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e81d0;
                    iVar7 = func_0x0001801e6230(iVar10, 0, puVar17 + iVar13 + 0x38, puVar17 + iVar13 + 0x18);
                    if (iVar7 != 0) {
                        *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e81e2;
                        iVar10 = func_0x0001801e5c20(piVar14 + 0x10, 0);
                        *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e81f1;
                        iVar11 = func_0x0001801bc820(piVar14 + 0x10);
                        if ((((puVar17[iVar13 + 0x58] & 2) != 0) && (*(int64_t *)(puVar17 + iVar13 + 0x48) == 0)) ||
                           (*(uint64_t *)(puVar17 + iVar13 + 0x40) < (uint64_t)(iVar11 + iVar10)))
                        goto code_r0x0001801e8209;
                    }
                }
                goto code_r0x0001801e8245;
            }
        } else if ((*(uint32_t *)((int64_t)piVar14 + 0x104) & 2) == 0) {
            *(undefined8 *)(puVar17 + iVar13 + -0x20) = 0x1801e8164;
            iVar7 = func_0x0001801e59a0(piVar14 + 0x14, 0);
            if (iVar7 == 0) goto code_r0x0001801e816c;
        }
code_r0x0001801e8209:
        if ((*(uint32_t *)(piVar14 + 0x20) & 0x1000000) == 0) {
            iVar13 = *(int64_t *)(iVar15 + 0x10);
            *piVar14 = iVar13;
            *(int64_t **)(iVar13 + 8) = piVar14;
            *(int64_t **)(iVar15 + 0x10) = piVar14;
            piVar14[1] = (int64_t)(int64_t **)(iVar15 + 0x10);
            if (*(int64_t *)(iVar15 + 0x68) == 0) {
                *(int64_t **)(iVar15 + 0x68) = piVar14;
            }
            *(uint32_t *)(piVar14 + 0x20) = *(uint32_t *)(piVar14 + 0x20) | 0x1000000;
        }
    } else {
code_r0x0001801e8245:
        if ((*(uint32_t *)(piVar14 + 0x20) & 0x1000000) != 0) {
            if (*(int64_t **)(iVar15 + 0x68) == piVar14) {
                piVar16 = (int64_t *)piVar14[1];
                if (piVar16 == (int64_t *)(iVar15 + 0x10)) {
                    piVar16 = (int64_t *)piVar16[1];
                }
                piVar12 = (int64_t *)0x0;
                if (piVar16 != (int64_t *)(iVar15 + 0x10)) {
                    piVar12 = piVar16;
                }
                *(int64_t **)(iVar15 + 0x68) = piVar12;
                if (piVar12 == piVar14) {
                    *(undefined8 *)(iVar15 + 0x68) = 0;
                }
            }
            *(int64_t *)(*piVar14 + 8) = piVar14[1];
            *(int64_t *)piVar14[1] = *piVar14;
            *(uint32_t *)(piVar14 + 0x20) = *(uint32_t *)(piVar14 + 0x20) & 0xfeffffff;
            *piVar14 = 0;
            piVar14[1] = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1802070a0
// Address: 0x1802070a0
// Size: 336 bytes
// ============================================================
int64_t * fcn.1802070a0(int64_t param_1, undefined8 param_2, int64_t param_3, int64_t param_4)
{
    char cVar1;
    uint8_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t **ppiVar12;
    int64_t iVar13;
    int64_t *piVar14;
    int64_t **ppiVar15;
    int64_t **ppiVar16;
    undefined8 uVar17;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar18;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802070ac;
    iVar13 = fcn.18045a350();
    iVar13 = -iVar13;
    piVar14 = (int64_t *)(uint64_t)*(uint8_t *)(param_1 + 0x1802071d1);
    // switch table (28 cases) at 0x1802071b0
    switch(param_1) {
    case 3:
        uVar6 = *(uint32_t *)(param_4 + 0x198);
        uVar4 = *(uint32_t *)(param_3 + 0x20) & 3;
        *(uint32_t *)(param_4 + 0x198) = ((uVar6 >> 4 & 7 | 1 << uVar4) << 4 ^ uVar6) & 0x70 ^ uVar6;
        return (int64_t *)(uint64_t)uVar4;
    case 4:
        *(undefined8 *)((int64_t)&uStack_10 + iVar13) = 0x18020718d;
        ppiVar15 = (int64_t **)fcn.1801e7870(*(int64_t *)(&stack0x00000048 + iVar13));
        if (ppiVar15 == (int64_t **)0x0) {
            return (int64_t *)0x0;
        }
        *(uint32_t *)((int64_t)ppiVar15 + 0x104) = *(uint32_t *)((int64_t)ppiVar15 + 0x104) | 8;
        iVar7 = *(int64_t *)(param_4 + 0x70);
        uVar17 = *(undefined8 *)(&stack0x00000018 + iVar13);
        break;
    case 5:
        *(undefined8 *)((int64_t)&uStack_10 + iVar13) = 0x18020716e;
        piVar14 = (int64_t *)fcn.1801e7870(*(int64_t *)(&stack0x00000048 + iVar13));
        if (piVar14 != (int64_t *)0x0) {
            uVar17 = *(undefined8 *)(param_4 + 0x70);
            *(undefined8 *)(&stack0x00000018 + iVar13) = 0x1801e7eaa;
            iVar7 = fcn.18045a350(uVar17);
            iVar7 = -iVar7;
            if ((*(uint32_t *)(piVar14 + 0x20) >> 0x1a & 1) != 0) {
                if (((*(uint32_t *)((int64_t)piVar14 + 0x104) & 4) == 0) &&
                   ((uVar6 = *(uint32_t *)(piVar14 + 0x20) >> 0x10 & 0xff, uVar6 == 1 || (uVar6 == 2)))) {
                    *(uint32_t *)((int64_t)piVar14 + 0x104) = *(uint32_t *)((int64_t)piVar14 + 0x104) | 4;
                    *(undefined8 *)(&stack0x00000018 + iVar7 + iVar13) = 0x1801e7eef;
                    fcn.1801e7fb0(*(int64_t *)(&stack0x00000040 + iVar7 + iVar13), 
                                  *(int64_t *)(&stack0x00000048 + iVar7 + iVar13), 
                                  *(int64_t *)(&stack0x00000050 + iVar7 + iVar13), 
                                  *(int64_t *)(&stack0x00000058 + iVar7 + iVar13), 
                                  *(int64_t *)(&stack0x00000070 + iVar7 + iVar13), 
                                  *(int64_t *)(&stack0x00000078 + iVar7 + iVar13), 
                                  *(int64_t *)(&stack0x00000080 + iVar7 + iVar13), 
                                  *(int64_t *)(&stack0x00000088 + iVar7 + iVar13), 
                                  *(int64_t *)(&stack0x00000090 + iVar7 + iVar13), 
                                  *(int64_t *)(&stack0x000000c0 + iVar7 + iVar13), 
                                  *(int64_t *)(&stack0x000000c8 + iVar7 + iVar13), 
                                  *(int64_t *)(&stack0x000000d0 + iVar7 + iVar13), 
                                  *(int64_t *)(&stack0x000000d8 + iVar7 + iVar13));
                }
                return (int64_t *)0x1;
            }
            return (int64_t *)0x0;
        }
    default:
        return piVar14;
    case 0x10:
        *(uint32_t *)(param_4 + 0x198) = *(uint32_t *)(param_4 + 0x198) | 2;
        return piVar14;
    case 0x11:
        *(undefined8 *)((int64_t)&uStack_10 + iVar13) = 0x180207148;
        ppiVar15 = (int64_t **)fcn.1801e7870(*(int64_t *)(&stack0x00000048 + iVar13));
        if (ppiVar15 == (int64_t **)0x0) {
            return (int64_t *)0x0;
        }
        *(uint32_t *)((int64_t)ppiVar15 + 0x104) = *(uint32_t *)((int64_t)ppiVar15 + 0x104) | 2;
        iVar7 = *(int64_t *)(param_4 + 0x70);
        uVar17 = *(undefined8 *)(&stack0x00000018 + iVar13);
        break;
    case 0x12:
        *(uint32_t *)(param_4 + 0x198) = *(uint32_t *)(param_4 + 0x198) | 4;
        return piVar14;
    case 0x13:
        *(uint32_t *)(param_4 + 0x198) = *(uint32_t *)(param_4 + 0x198) | 8;
        return piVar14;
    case 0x1e:
        *(uint32_t *)(param_4 + 0x198) = *(uint32_t *)(param_4 + 0x198) | 1;
        return piVar14;
    }
    *(undefined8 *)(&stack0x00000040 + iVar13) = uVar17;
    *(undefined8 *)(&stack0x00000018 + iVar13) = unaff_RBP;
    *(undefined8 *)(&stack0x00000010 + iVar13) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar13) = unaff_R15;
    *(undefined8 *)(&stack0x00000018 + iVar13 + -0x18) = 0x1801e7fc3;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    uVar6 = *(uint32_t *)(ppiVar15 + 0x20);
    uVar17 = *(undefined8 *)(iVar7 + 8);
    *(undefined8 *)(&stack0x000000b8 + iVar8 + iVar13) = unaff_R14;
    bVar18 = true;
    *(undefined8 *)(&stack0x00000018 + iVar8 + iVar13 + -0x18) = 0x1801e7fe9;
    uVar4 = func_0x0001801e3b40(uVar17);
    if ((uVar6 & 1) == uVar4) {
        uVar6 = *(uint32_t *)(ppiVar15 + 0x20);
        piVar14 = ppiVar15[7];
        pcVar3 = *(code **)(iVar7 + 0x70);
        if (pcVar3 != (code *)0x0) {
            uVar17 = *(undefined8 *)(iVar7 + 0x78);
            *(undefined8 *)(&stack0x00000018 + iVar8 + iVar13 + -0x18) = 0x1801e801c;
            uVar9 = (*pcVar3)((uVar6 & 2) != 0, uVar17);
            bVar18 = (uint64_t)piVar14 >> 2 < uVar9;
        }
    }
    cVar1 = *(char *)((int64_t)ppiVar15 + 0x101);
    *(undefined8 *)(&stack0x000000b0 + iVar8 + iVar13) = unaff_RDI;
    if (cVar1 == '\x03') {
        piVar14 = ppiVar15[0xe];
        *(undefined8 *)(&stack0x00000018 + iVar8 + iVar13 + -0x18) = 0x1801e8040;
        iVar5 = func_0x0001801e6440(piVar14);
        if (iVar5 == 0) goto code_r0x0001801e8094;
        if ((*(char *)((int64_t)ppiVar15 + 0x101) != '\0') && (*(char *)((int64_t)ppiVar15 + 0x101) == '\x03')) {
            piVar14 = ppiVar15[0xe];
            *(undefined *)((int64_t)ppiVar15 + 0x101) = 4;
            *(undefined8 *)(&stack0x00000018 + iVar8 + iVar13 + -0x18) = 0x1801e8063;
            func_0x0001801e6180(piVar14);
            ppiVar15[0xe] = (int64_t *)0x0;
            if ((char)*(uint32_t *)((int64_t)ppiVar15 + 0x104) < '\0') {
                *(uint32_t *)((int64_t)ppiVar15 + 0x104) = *(uint32_t *)((int64_t)ppiVar15 + 0x104) & 0xffffff7f;
                piVar14 = (int64_t *)(iVar7 + 0x60);
                *piVar14 = *piVar14 + -1;
                if (*piVar14 == 0) {
                    uVar17 = *(undefined8 *)(iVar7 + 8);
                    *(undefined8 *)(&stack0x00000018 + iVar8 + iVar13 + -0x18) = 0x1801e808b;
                    func_0x0001801e3de0(uVar17);
                }
            }
        }
    } else {
code_r0x0001801e8094:
        if (((*(uint8_t *)((int64_t)ppiVar15 + 0x104) & 0x80) != 0) && (*(char *)((int64_t)ppiVar15 + 0x101) == '\x02'))
        {
            piVar14 = ppiVar15[0xe];
            *(undefined8 *)(&stack0x00000018 + iVar8 + iVar13 + -0x18) = 0x1801e80b2;
            iVar5 = func_0x0001801e6440(piVar14);
            if (iVar5 != 0) {
                *(undefined8 *)(&stack0x00000018 + iVar8 + iVar13 + -0x18) = 0x1801e80c1;
                func_0x0001801e8310(iVar7, ppiVar15);
            }
        }
    }
    uVar6 = *(uint32_t *)((int64_t)ppiVar15 + 0x104);
    piVar14 = (int64_t *)(uint64_t)uVar6;
    if ((uVar6 & 0x40) == 0) {
        if ((((uVar6 & 0x20) == 0) || ((*(char *)((int64_t)ppiVar15 + 0x102) != '\0' && ((uVar6 & 0x10) == 0)))) ||
           ((cVar1 = *(char *)((int64_t)ppiVar15 + 0x101), cVar1 != '\0' && ((cVar1 != '\x04' && (cVar1 != '\x06'))))))
        {
            piVar14 = (int64_t *)(uint64_t)(uVar6 & 0xffffffbf);
            *(uint32_t *)((int64_t)ppiVar15 + 0x104) = uVar6 & 0xffffffbf;
        } else {
            ppiVar16 = ppiVar15 + 4;
            *(uint32_t *)((int64_t)ppiVar15 + 0x104) = uVar6 | 0x40;
            ppiVar12 = (int64_t **)(iVar7 + 0x30);
            piVar14 = *ppiVar12;
            *ppiVar16 = piVar14;
            piVar14[1] = (int64_t)ppiVar16;
            *ppiVar12 = (int64_t *)ppiVar16;
            ppiVar15[5] = (int64_t *)ppiVar12;
        }
    }
    if ((bVar18) && ((*(uint32_t *)((int64_t)ppiVar15 + 0x104) & 0x40) == 0)) {
        uVar2 = *(uint8_t *)((int64_t)ppiVar15 + 0x102);
        piVar14 = (int64_t *)(uint64_t)uVar2;
        if ((uVar2 != 0) && (uVar2 == 1)) {
            if ((*(uint32_t *)((int64_t)ppiVar15 + 0x104) & 2) != 0) goto code_r0x0001801e8209;
            *(undefined8 *)(&stack0x00000018 + iVar8 + iVar13 + -0x18) = 0x1801e8164;
            piVar14 = (int64_t *)func_0x0001801e59a0(ppiVar15 + 0x14, 0);
            if ((int32_t)piVar14 != 0) goto code_r0x0001801e8209;
        }
        if ((*(uint8_t *)((int64_t)ppiVar15 + 0x104) & 0xc) != 0) {
code_r0x0001801e8209:
            if ((*(uint32_t *)(ppiVar15 + 0x20) & 0x1000000) == 0) {
                piVar14 = *(int64_t **)(iVar7 + 0x10);
                *ppiVar15 = piVar14;
                piVar14[1] = (int64_t)ppiVar15;
                *(int64_t *)(iVar7 + 0x10) = (int64_t)ppiVar15;
                ppiVar15[1] = (int64_t *)(iVar7 + 0x10);
                if (*(int64_t *)(iVar7 + 0x68) == 0) {
                    *(int64_t ***)(iVar7 + 0x68) = ppiVar15;
                }
                *(uint32_t *)(ppiVar15 + 0x20) = *(uint32_t *)(ppiVar15 + 0x20) | 0x1000000;
            }
            return piVar14;
        }
        uVar6 = *(uint32_t *)(ppiVar15 + 0x20);
        piVar14 = (int64_t *)(uint64_t)uVar6;
        if ((uVar6 >> 0x1b & 1) == 0) {
            uVar6 = uVar6 >> 8 & 0xff;
            if (uVar6 != 1) {
                uVar6 = uVar6 - 2;
                piVar14 = (int64_t *)(uint64_t)uVar6;
                if ((uVar6 != 0) && (uVar6 != 1)) goto code_r0x0001801e8245;
            }
            piVar14 = ppiVar15[0xe];
            *(undefined **)(&stack0x00000028 + iVar8 + iVar13) = &stack0x000000a8 + iVar8 + iVar13;
            *(undefined8 *)(&stack0x000000a8 + iVar8 + iVar13) = 2;
            *(undefined8 *)(&stack0x00000018 + iVar8 + iVar13 + -0x18) = 0x1801e81d0;
            piVar14 = (int64_t *)
                      func_0x0001801e6230(piVar14, 0, &stack0x00000058 + iVar8 + iVar13, 
                                          &stack0x00000038 + iVar8 + iVar13);
            if ((int32_t)piVar14 != 0) {
                *(undefined8 *)(&stack0x00000018 + iVar8 + iVar13 + -0x18) = 0x1801e81e2;
                iVar10 = func_0x0001801e5c20(ppiVar15 + 0x10, 0);
                *(undefined8 *)(&stack0x00000018 + iVar8 + iVar13 + -0x18) = 0x1801e81f1;
                iVar11 = func_0x0001801bc820(ppiVar15 + 0x10);
                piVar14 = (int64_t *)(iVar11 + iVar10);
                if (((((&stack0x00000078)[iVar8 + iVar13] & 2) != 0) &&
                    (*(int64_t *)(&stack0x00000068 + iVar8 + iVar13) == 0)) ||
                   (*(int64_t **)(&stack0x00000060 + iVar8 + iVar13) < piVar14)) goto code_r0x0001801e8209;
            }
        }
    }
code_r0x0001801e8245:
    if ((*(uint32_t *)(ppiVar15 + 0x20) & 0x1000000) == 0) {
        return piVar14;
    }
    if (*(int64_t ***)(iVar7 + 0x68) == ppiVar15) {
        ppiVar16 = (int64_t **)ppiVar15[1];
        if (ppiVar16 == (int64_t **)(iVar7 + 0x10)) {
            ppiVar16 = (int64_t **)ppiVar16[1];
        }
        ppiVar12 = (int64_t **)0x0;
        if (ppiVar16 != (int64_t **)(iVar7 + 0x10)) {
            ppiVar12 = ppiVar16;
        }
        *(int64_t ***)(iVar7 + 0x68) = ppiVar12;
        if (ppiVar12 == ppiVar15) {
            *(undefined8 *)(iVar7 + 0x68) = 0;
        }
    }
    (*ppiVar15)[1] = (int64_t)ppiVar15[1];
    piVar14 = *ppiVar15;
    *ppiVar15[1] = (int64_t)piVar14;
    *(uint32_t *)(ppiVar15 + 0x20) = *(uint32_t *)(ppiVar15 + 0x20) & 0xfeffffff;
    *ppiVar15 = (int64_t *)0x0;
    ppiVar15[1] = (int64_t *)0x0;
    return piVar14;
}

// ============================================================
// Function: FUN_1802071f0
// Address: 0x1802071f0
// Size: 58 bytes
// ============================================================
void fcn.1802071f0(undefined8 param_1, int64_t param_2)
{
    int64_t **ppiVar1;
    char cVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    code *pcVar5;
    uint32_t uVar6;
    int32_t iVar7;
    uint32_t uVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t *piVar13;
    int64_t iVar14;
    int64_t *piVar15;
    int64_t iVar16;
    int64_t *piVar17;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar18;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802071fc;
    iVar14 = fcn.18045a350();
    iVar14 = -iVar14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar14) = 0x18020720e;
    piVar15 = (int64_t *)fcn.1801e7870(*(int64_t *)(&stack0x00000048 + iVar14));
    if (piVar15 == (int64_t *)0x0) {
        return;
    }
    iVar16 = *(int64_t *)(param_2 + 0x70);
    *(undefined8 *)(&stack0x00000040 + iVar14) = *(undefined8 *)(&stack0x00000018 + iVar14);
    *(undefined8 *)(&stack0x00000018 + iVar14) = unaff_RBP;
    *(undefined8 *)(&stack0x00000010 + iVar14) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar14) = unaff_R15;
    *(undefined8 *)(&stack0x00000018 + iVar14 + -0x18) = 0x1801e7fc3;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    uVar8 = *(uint32_t *)(piVar15 + 0x20);
    uVar3 = *(undefined8 *)(iVar16 + 8);
    *(undefined8 *)(&stack0x000000b8 + iVar9 + iVar14) = unaff_R14;
    bVar18 = true;
    *(undefined8 *)(&stack0x00000018 + iVar9 + iVar14 + -0x18) = 0x1801e7fe9;
    uVar6 = func_0x0001801e3b40(uVar3);
    if ((uVar8 & 1) == uVar6) {
        uVar8 = *(uint32_t *)(piVar15 + 0x20);
        uVar4 = piVar15[7];
        pcVar5 = *(code **)(iVar16 + 0x70);
        if (pcVar5 != (code *)0x0) {
            uVar3 = *(undefined8 *)(iVar16 + 0x78);
            *(undefined8 *)(&stack0x00000018 + iVar9 + iVar14 + -0x18) = 0x1801e801c;
            uVar10 = (*pcVar5)((uVar8 & 2) != 0, uVar3);
            bVar18 = uVar4 >> 2 < uVar10;
        }
    }
    cVar2 = *(char *)((int64_t)piVar15 + 0x101);
    *(undefined8 *)(&stack0x000000b0 + iVar9 + iVar14) = unaff_RDI;
    if (cVar2 == '\x03') {
        iVar11 = piVar15[0xe];
        *(undefined8 *)(&stack0x00000018 + iVar9 + iVar14 + -0x18) = 0x1801e8040;
        iVar7 = func_0x0001801e6440(iVar11);
        if (iVar7 == 0) goto code_r0x0001801e8094;
        if ((*(char *)((int64_t)piVar15 + 0x101) != '\0') && (*(char *)((int64_t)piVar15 + 0x101) == '\x03')) {
            iVar11 = piVar15[0xe];
            *(undefined *)((int64_t)piVar15 + 0x101) = 4;
            *(undefined8 *)(&stack0x00000018 + iVar9 + iVar14 + -0x18) = 0x1801e8063;
            func_0x0001801e6180(iVar11);
            piVar15[0xe] = 0;
            if ((char)*(uint32_t *)((int64_t)piVar15 + 0x104) < '\0') {
                *(uint32_t *)((int64_t)piVar15 + 0x104) = *(uint32_t *)((int64_t)piVar15 + 0x104) & 0xffffff7f;
                piVar17 = (int64_t *)(iVar16 + 0x60);
                *piVar17 = *piVar17 + -1;
                if (*piVar17 == 0) {
                    uVar3 = *(undefined8 *)(iVar16 + 8);
                    *(undefined8 *)(&stack0x00000018 + iVar9 + iVar14 + -0x18) = 0x1801e808b;
                    func_0x0001801e3de0(uVar3);
                }
            }
        }
    } else {
code_r0x0001801e8094:
        if (((*(uint8_t *)((int64_t)piVar15 + 0x104) & 0x80) != 0) && (*(char *)((int64_t)piVar15 + 0x101) == '\x02')) {
            iVar11 = piVar15[0xe];
            *(undefined8 *)(&stack0x00000018 + iVar9 + iVar14 + -0x18) = 0x1801e80b2;
            iVar7 = func_0x0001801e6440(iVar11);
            if (iVar7 != 0) {
                *(undefined8 *)(&stack0x00000018 + iVar9 + iVar14 + -0x18) = 0x1801e80c1;
                func_0x0001801e8310(iVar16, piVar15);
            }
        }
    }
    uVar8 = *(uint32_t *)((int64_t)piVar15 + 0x104);
    if ((uVar8 & 0x40) == 0) {
        if ((((uVar8 & 0x20) == 0) || ((*(char *)((int64_t)piVar15 + 0x102) != '\0' && ((uVar8 & 0x10) == 0)))) ||
           ((cVar2 = *(char *)((int64_t)piVar15 + 0x101), cVar2 != '\0' && ((cVar2 != '\x04' && (cVar2 != '\x06')))))) {
            *(uint32_t *)((int64_t)piVar15 + 0x104) = uVar8 & 0xffffffbf;
        } else {
            piVar17 = piVar15 + 4;
            *(uint32_t *)((int64_t)piVar15 + 0x104) = uVar8 | 0x40;
            ppiVar1 = (int64_t **)(iVar16 + 0x30);
            piVar13 = *ppiVar1;
            *piVar17 = (int64_t)piVar13;
            piVar13[1] = (int64_t)piVar17;
            *ppiVar1 = piVar17;
            piVar15[5] = (int64_t)ppiVar1;
        }
    }
    if ((bVar18) && ((*(uint32_t *)((int64_t)piVar15 + 0x104) & 0x40) == 0)) {
        if ((*(char *)((int64_t)piVar15 + 0x102) == '\0') || (*(char *)((int64_t)piVar15 + 0x102) != '\x01')) {
code_r0x0001801e816c:
            if ((*(uint8_t *)((int64_t)piVar15 + 0x104) & 0xc) == 0) {
                if (((*(uint32_t *)(piVar15 + 0x20) >> 0x1b & 1) == 0) &&
                   (((uVar8 = *(uint32_t *)(piVar15 + 0x20) >> 8 & 0xff, uVar8 == 1 || (uVar8 == 2)) || (uVar8 == 3))))
                {
                    iVar11 = piVar15[0xe];
                    *(undefined **)(&stack0x00000028 + iVar9 + iVar14) = &stack0x000000a8 + iVar9 + iVar14;
                    *(undefined8 *)(&stack0x000000a8 + iVar9 + iVar14) = 2;
                    *(undefined8 *)(&stack0x00000018 + iVar9 + iVar14 + -0x18) = 0x1801e81d0;
                    iVar7 = func_0x0001801e6230(iVar11, 0, &stack0x00000058 + iVar9 + iVar14, 
                                                &stack0x00000038 + iVar9 + iVar14);
                    if (iVar7 != 0) {
                        *(undefined8 *)(&stack0x00000018 + iVar9 + iVar14 + -0x18) = 0x1801e81e2;
                        iVar11 = func_0x0001801e5c20(piVar15 + 0x10, 0);
                        *(undefined8 *)(&stack0x00000018 + iVar9 + iVar14 + -0x18) = 0x1801e81f1;
                        iVar12 = func_0x0001801bc820(piVar15 + 0x10);
                        if (((((&stack0x00000078)[iVar9 + iVar14] & 2) != 0) &&
                            (*(int64_t *)(&stack0x00000068 + iVar9 + iVar14) == 0)) ||
                           (*(uint64_t *)(&stack0x00000060 + iVar9 + iVar14) < (uint64_t)(iVar12 + iVar11)))
                        goto code_r0x0001801e8209;
                    }
                }
                goto code_r0x0001801e8245;
            }
        } else if ((*(uint32_t *)((int64_t)piVar15 + 0x104) & 2) == 0) {
            *(undefined8 *)(&stack0x00000018 + iVar9 + iVar14 + -0x18) = 0x1801e8164;
            iVar7 = func_0x0001801e59a0(piVar15 + 0x14, 0);
            if (iVar7 == 0) goto code_r0x0001801e816c;
        }
code_r0x0001801e8209:
        if ((*(uint32_t *)(piVar15 + 0x20) & 0x1000000) == 0) {
            iVar14 = *(int64_t *)(iVar16 + 0x10);
            *piVar15 = iVar14;
            *(int64_t **)(iVar14 + 8) = piVar15;
            *(int64_t **)(iVar16 + 0x10) = piVar15;
            piVar15[1] = (int64_t)(int64_t **)(iVar16 + 0x10);
            if (*(int64_t *)(iVar16 + 0x68) == 0) {
                *(int64_t **)(iVar16 + 0x68) = piVar15;
            }
            *(uint32_t *)(piVar15 + 0x20) = *(uint32_t *)(piVar15 + 0x20) | 0x1000000;
        }
    } else {
code_r0x0001801e8245:
        if ((*(uint32_t *)(piVar15 + 0x20) & 0x1000000) != 0) {
            if (*(int64_t **)(iVar16 + 0x68) == piVar15) {
                piVar17 = (int64_t *)piVar15[1];
                if (piVar17 == (int64_t *)(iVar16 + 0x10)) {
                    piVar17 = (int64_t *)piVar17[1];
                }
                piVar13 = (int64_t *)0x0;
                if (piVar17 != (int64_t *)(iVar16 + 0x10)) {
                    piVar13 = piVar17;
                }
                *(int64_t **)(iVar16 + 0x68) = piVar13;
                if (piVar13 == piVar15) {
                    *(undefined8 *)(iVar16 + 0x68) = 0;
                }
            }
            *(int64_t *)(*piVar15 + 8) = piVar15[1];
            *(int64_t *)piVar15[1] = *piVar15;
            *(uint32_t *)(piVar15 + 0x20) = *(uint32_t *)(piVar15 + 0x20) & 0xfeffffff;
            *piVar15 = 0;
            piVar15[1] = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180207270
// Address: 0x180207270
// Size: 160 bytes
// ============================================================
undefined8 fcn.180207270(int64_t param_1, uint32_t param_2)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020727a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (3 < param_2) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180207287;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18020729f;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802072b1;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    if (param_2 != 1) {
        if (param_2 != 0) {
            if ((param_2 != 1) && (param_2 == 2)) {
                *(undefined8 *)(param_1 + 0xd8) = 0;
                return 1;
            }
            *(undefined8 *)(param_1 + 0xe0) = 0;
            return 1;
        }
        *(undefined8 *)(param_1 + 0xd0) = 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_180207310
// Address: 0x180207310
// Size: 26 bytes
// ============================================================
void fcn.180207310(int64_t arg1, int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 unaff_RSI;
    int64_t iVar5;
    undefined8 unaff_RDI;
    undefined8 *puVar6;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180207324;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RSI;
        uVar1 = *(undefined8 *)(arg1 + 0x50);
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020733d;
        func_0x0001801fb7c0(uVar1);
        iVar5 = *(int64_t *)(arg1 + 0xe8);
        if ((iVar5 != 0) && (pcVar2 = *(code **)(arg1 + 0xf8), pcVar2 != (code *)0x0)) {
            uVar1 = *(undefined8 *)(arg1 + 0x100);
            uVar3 = *(undefined8 *)(arg1 + 0xf0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180207365;
            (*pcVar2)(iVar5, uVar3, uVar1);
        }
        *(undefined8 *)(arg1 + 0xe8) = 0;
        *(undefined8 *)(arg1 + 0xf0) = 0;
        *(undefined8 *)(arg1 + 0xf8) = 0;
        *(undefined8 *)(arg1 + 0x100) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020738f;
        func_0x0001800086f0(arg1 + 0x108);
        uVar1 = *(undefined8 *)(arg1 + 0x1b8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802073a8;
        func_0x000180224990(uVar1, 0x1804ba078, 0x24c);
        puVar6 = (undefined8 *)(arg1 + 0x1d8);
        iVar5 = 4;
        do {
            uVar1 = puVar6[2];
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802073ca;
            func_0x000180224990(uVar1, 0x1804ba078, 0x251);
            uVar1 = *puVar6;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802073df;
            func_0x000180224990(uVar1, 0x1804ba078, 0x252);
            puVar6 = puVar6 + 4;
            iVar5 = iVar5 + -1;
        } while (iVar5 != 0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180207408;
        func_0x000180224990(arg1, 0x1804ba078, 0x255);
    }
    return;
}

// ============================================================
// Function: FUN_18020732a
// Address: 0x18020732a
// Size: 227 bytes
// ============================================================
void fcn.180207310(int64_t arg1, int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 unaff_RSI;
    int64_t iVar5;
    undefined8 unaff_RDI;
    undefined8 *puVar6;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180207324;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RSI;
        uVar1 = *(undefined8 *)(arg1 + 0x50);
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020733d;
        func_0x0001801fb7c0(uVar1);
        iVar5 = *(int64_t *)(arg1 + 0xe8);
        if ((iVar5 != 0) && (pcVar2 = *(code **)(arg1 + 0xf8), pcVar2 != (code *)0x0)) {
            uVar1 = *(undefined8 *)(arg1 + 0x100);
            uVar3 = *(undefined8 *)(arg1 + 0xf0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180207365;
            (*pcVar2)(iVar5, uVar3, uVar1);
        }
        *(undefined8 *)(arg1 + 0xe8) = 0;
        *(undefined8 *)(arg1 + 0xf0) = 0;
        *(undefined8 *)(arg1 + 0xf8) = 0;
        *(undefined8 *)(arg1 + 0x100) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020738f;
        func_0x0001800086f0(arg1 + 0x108);
        uVar1 = *(undefined8 *)(arg1 + 0x1b8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802073a8;
        func_0x000180224990(uVar1, 0x1804ba078, 0x24c);
        puVar6 = (undefined8 *)(arg1 + 0x1d8);
        iVar5 = 4;
        do {
            uVar1 = puVar6[2];
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802073ca;
            func_0x000180224990(uVar1, 0x1804ba078, 0x251);
            uVar1 = *puVar6;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802073df;
            func_0x000180224990(uVar1, 0x1804ba078, 0x252);
            puVar6 = puVar6 + 4;
            iVar5 = iVar5 + -1;
        } while (iVar5 != 0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180207408;
        func_0x000180224990(arg1, 0x1804ba078, 0x255);
    }
    return;
}

// ============================================================
// Function: FUN_18020740d
// Address: 0x18020740d
// Size: 1 bytes
// ============================================================
void fcn.180207310(int64_t arg1, int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 unaff_RSI;
    int64_t iVar5;
    undefined8 unaff_RDI;
    undefined8 *puVar6;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180207324;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RSI;
        uVar1 = *(undefined8 *)(arg1 + 0x50);
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020733d;
        func_0x0001801fb7c0(uVar1);
        iVar5 = *(int64_t *)(arg1 + 0xe8);
        if ((iVar5 != 0) && (pcVar2 = *(code **)(arg1 + 0xf8), pcVar2 != (code *)0x0)) {
            uVar1 = *(undefined8 *)(arg1 + 0x100);
            uVar3 = *(undefined8 *)(arg1 + 0xf0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180207365;
            (*pcVar2)(iVar5, uVar3, uVar1);
        }
        *(undefined8 *)(arg1 + 0xe8) = 0;
        *(undefined8 *)(arg1 + 0xf0) = 0;
        *(undefined8 *)(arg1 + 0xf8) = 0;
        *(undefined8 *)(arg1 + 0x100) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020738f;
        func_0x0001800086f0(arg1 + 0x108);
        uVar1 = *(undefined8 *)(arg1 + 0x1b8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802073a8;
        func_0x000180224990(uVar1, 0x1804ba078, 0x24c);
        puVar6 = (undefined8 *)(arg1 + 0x1d8);
        iVar5 = 4;
        do {
            uVar1 = puVar6[2];
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802073ca;
            func_0x000180224990(uVar1, 0x1804ba078, 0x251);
            uVar1 = *puVar6;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802073df;
            func_0x000180224990(uVar1, 0x1804ba078, 0x252);
            puVar6 = puVar6 + 4;
            iVar5 = iVar5 + -1;
        } while (iVar5 != 0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180207408;
        func_0x000180224990(arg1, 0x1804ba078, 0x255);
    }
    return;
}

// ============================================================
// Function: FUN_180207410
// Address: 0x180207410
// Size: 1856 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_508h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_254h
// WARNING: [rz-ghidra] Detected overlap for variable var_374h
// WARNING: [rz-ghidra] Detected overlap for variable var_494h

void fcn.180207410(int64_t arg_28h, int64_t arg_38h)
{
    int64_t *piVar1;
    uint32_t *puVar2;
    undefined8 uVar3;
    code *pcVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int32_t *piVar10;
    int64_t iVar11;
    uint32_t uVar12;
    int64_t in_RCX;
    undefined (*in_RDX) [16];
    uint64_t uVar14;
    uint64_t uVar15;
    uint32_t uVar16;
    int64_t iVar17;
    int64_t var_4h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_498h;
    int64_t var_490h;
    int64_t var_488h;
    int64_t var_450h;
    int64_t var_448h;
    int64_t var_440h;
    int64_t var_430h;
    int64_t var_428h;
    int64_t var_3e8h;
    int64_t var_3c8h;
    int64_t var_3c0h;
    int64_t var_3b4h;
    int64_t var_3a8h;
    int64_t var_398h;
    int64_t var_378h;
    int64_t var_370h;
    int64_t var_368h;
    int64_t var_330h;
    int64_t var_328h;
    int64_t var_320h;
    int64_t var_310h;
    int64_t var_308h;
    int64_t var_2c8h;
    int64_t var_2a0h;
    int64_t var_294h;
    int64_t var_288h;
    int64_t var_278h;
    int64_t var_258h;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_210h;
    int64_t var_208h;
    int64_t var_200h;
    int64_t var_1f0h;
    int64_t var_1e8h;
    int64_t var_1a8h;
    int64_t var_180h;
    int64_t var_174h;
    int64_t var_168h;
    int64_t var_158h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_88h;
    int64_t var_60h;
    int64_t var_54h;
    int64_t var_48h;
    undefined8 uStack_40;
    int64_t var_8h;
    uint64_t uVar13;
    
    uStack_40 = 0x180207432;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar8);
    iVar9 = *(int64_t *)(in_RCX + 0x98);
    *(undefined (**) [16])((int64_t)&var_10h + iVar8) = in_RDX;
    uVar3 = *(undefined8 *)(in_RCX + 0xa0);
    uVar15 = 0;
    uVar16 = 4;
    *(undefined4 *)(&stack0x00000000 + iVar8) = 0;
    pcVar4 = *(code **)(iVar9 + 0x30);
    *(undefined4 *)((int64_t)&var_8h + iVar8) = 4;
    *(undefined8 *)((int64_t)&var_4h + iVar8 + 4) = 0;
    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020747b;
    iVar9 = (*pcVar4)(uVar3);
    *(int64_t *)((int64_t)&var_18h + iVar8) = iVar9;
    *in_RDX = ZEXT816(0);
    uVar3 = *(undefined8 *)(in_RCX + 0x50);
    var_448h._0_4_ = 0;
    var_328h._0_4_ = 0;
    var_208h._0_4_ = 0;
    var_e8h._0_4_ = 0;
    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802074aa;
    func_0x0001801fb380(uVar3);
    uVar3 = *(undefined8 *)(in_RCX + 0x68);
    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802074b3;
    piVar10 = (int32_t *)func_0x0001802026c0(uVar3);
    uVar14 = 1;
    if ((*piVar10 == 0) && (piVar10[1] == 0)) {
        piVar10 = piVar10 + 2;
        uVar13 = uVar15;
        do {
            if (*piVar10 != 0) goto code_r0x0001802074e7;
            uVar12 = (int32_t)uVar13 + 1;
            uVar13 = (uint64_t)uVar12;
            piVar10 = piVar10 + 1;
        } while (uVar12 < 3);
        uVar14 = uVar15;
        if (iVar9 == 0) {
            uVar14 = 2;
        }
    }
code_r0x0001802074e7:
    *(int32_t *)((int64_t)&var_4h + iVar8) = (int32_t)uVar14;
    uVar13 = uVar15;
    do {
        iVar11 = 0;
        iVar6 = (int32_t)uVar13;
        iVar7 = (int32_t)uVar15;
        if (iVar7 != 0) {
            iVar11 = (&var_3c8h)[(uint64_t)(iVar7 - 1) * 0x24];
        }
        iVar17 = uVar15 * 0x120;
        *(int64_t *)(&stack0xffffffffffffffe8 + iVar8) = (int64_t)&var_8h + iVar8;
        (&var_3c8h)[uVar15 * 0x24] = iVar11;
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180207536;
        iVar5 = func_0x00018020a2f0(in_RCX, uVar15, uVar14, iVar9);
        if (iVar5 != 0) {
            iVar9 = (int64_t)&arg_28h + iVar17 + iVar8;
            *(int64_t *)(&stack0xffffffffffffffe8 + iVar8) = iVar11;
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020755a;
            iVar5 = func_0x000180209f50(iVar9, in_RCX, uVar15, *(undefined4 *)((int64_t)&var_4h + iVar8));
            if (iVar5 == 0) break;
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180207574;
            iVar6 = func_0x0001802088b0(in_RCX, iVar9, *(int32_t *)((int64_t)&var_8h + iVar8) == iVar7);
            if (iVar6 != 1) goto code_r0x0001802079d6;
            iVar9 = *(int64_t *)((int64_t)&var_18h + iVar8);
            if (*(int32_t *)((int64_t)&var_3b4h + iVar17 + 4) != 0) {
                uVar13 = 1;
            }
            (&var_3c8h)[uVar15 * 0x24] =
                 (&var_3c0h)[uVar15 * 0x24] + *(int64_t *)((int64_t)&arg_38h + iVar17 + iVar8) + iVar11;
        }
        iVar6 = (int32_t)uVar13;
        uVar15 = (uint64_t)(iVar7 + 1U);
        if (3 < iVar7 + 1U) break;
        uVar14 = (uint64_t)*(uint32_t *)((int64_t)&var_4h + iVar8);
    } while( true );
    iVar9 = *(int64_t *)((int64_t)&arg_38h + iVar8);
    if ((((int32_t)var_448h != 0) && (iVar9 != 0)) || (iVar6 != 0)) {
        uVar14 = 0;
        if (((int32_t)var_448h != 0) && (uVar14 = 0, iVar9 != 0)) {
            uVar14 = 4;
            if ((((uint32_t)var_3b4h & 0x4000) != 0) && (uVar14 = 4, (var_498h._4_1_ & 2) == 0)) {
                uVar14 = 0;
            }
            uVar16 = (uint32_t)uVar14;
            if ((int32_t)var_498h != 0) {
                uVar3 = *(undefined8 *)(in_RCX + 0x50);
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802075ff;
                iVar7 = func_0x0001801fb280(uVar3, (int32_t)var_498h, iVar9, (int64_t)&var_8h + iVar8);
                if (iVar7 == 0) {
                    iVar9 = *(int64_t *)((int64_t)&arg_38h + iVar8);
                } else {
                    var_3e8h = *(int64_t *)((int64_t)&var_8h + iVar8);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180207619;
                    iVar11 = func_0x0001801f97e0((undefined)var_428h, &var_430h);
                    iVar9 = *(int64_t *)((int64_t)&arg_38h + iVar8);
                    var_3c0h = (iVar11 - iVar9) + *(int64_t *)((int64_t)&var_8h + iVar8);
                }
            }
            uVar14 = var_3c0h + iVar9;
        }
        if (((int32_t)var_328h != 0) && (var_398h != 0)) {
            if ((uVar16 == 4) && ((((uint32_t)var_294h & 0x4000) != 0 && ((var_378h._4_1_ & 2) == 0)))) {
                uVar16 = 1;
            }
            if ((int32_t)var_378h != 0) {
                uVar3 = *(undefined8 *)(in_RCX + 0x50);
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180207692;
                iVar7 = func_0x0001801fb280(uVar3, (int32_t)var_378h, var_398h, (int64_t)&var_8h + iVar8);
                if (iVar7 != 0) {
                    var_2c8h = *(int64_t *)((int64_t)&var_8h + iVar8);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802076b5;
                    iVar9 = func_0x0001801f97e0((undefined)var_308h, &var_310h);
                    var_2a0h = (iVar9 - var_398h) + *(int64_t *)((int64_t)&var_8h + iVar8);
                }
            }
            uVar14 = uVar14 + var_398h + var_2a0h;
        }
        if (((int32_t)var_208h != 0) && (var_278h != 0)) {
            if ((uVar16 == 4) && ((((uint32_t)var_174h & 0x4000) != 0 && ((var_258h._4_1_ & 2) == 0)))) {
                uVar16 = 2;
            }
            if ((int32_t)var_258h != 0) {
                uVar3 = *(undefined8 *)(in_RCX + 0x50);
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180207739;
                iVar7 = func_0x0001801fb280(uVar3, (int32_t)var_258h, var_278h, (int64_t)&var_8h + iVar8);
                if (iVar7 != 0) {
                    var_1a8h = *(int64_t *)((int64_t)&var_8h + iVar8);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020775c;
                    iVar9 = func_0x0001801f97e0((undefined)var_1e8h, &var_1f0h);
                    var_180h = (iVar9 - var_278h) + *(int64_t *)((int64_t)&var_8h + iVar8);
                    uVar14 = uVar14 + var_278h + var_180h;
                    goto code_r0x000180207793;
                }
            }
            uVar14 = uVar14 + var_278h + var_180h;
        }
code_r0x000180207793:
        if (((int32_t)var_e8h != 0) && (var_158h != 0)) {
            if ((uVar16 == 4) && ((((uint32_t)var_54h & 0x4000) != 0 && ((var_138h._4_1_ & 2) == 0)))) {
                uVar16 = 3;
            }
            if ((int32_t)var_138h != 0) {
                uVar3 = *(undefined8 *)(in_RCX + 0x50);
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802077ed;
                iVar7 = func_0x0001801fb280(uVar3, (int32_t)var_138h, var_158h, (int64_t)&var_8h + iVar8);
                if (iVar7 != 0) {
                    var_88h = *(int64_t *)((int64_t)&var_8h + iVar8);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180207810;
                    iVar9 = func_0x0001801f97e0((undefined)var_c8h, &var_d0h);
                    var_60h = (iVar9 - var_158h) + *(int64_t *)((int64_t)&var_8h + iVar8);
                }
            }
            uVar14 = uVar14 + var_158h + var_60h;
        }
        if (uVar14 < 0x4b0) {
            if (uVar16 == 4) goto code_r0x0001802079d6;
            iVar11 = 0x4b0 - uVar14;
            iVar9 = (int64_t)&arg_28h + (uint64_t)uVar16 * 0x120 + iVar8;
            if (iVar11 != 0) {
                if ((*(int32_t *)(iVar9 + 0x80) == 0) || (*(int64_t *)(iVar9 + 0x88) == 0)) goto code_r0x0001802079d6;
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180207886;
                iVar17 = func_0x0001802082c0(iVar9);
                if (iVar17 == 0) goto code_r0x0001802079d6;
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180207896;
                iVar7 = func_0x0001801fe680(iVar17, iVar11);
                if (iVar7 == 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802078a2;
                    func_0x000180208590();
                    goto code_r0x0001802079d6;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802078af;
                iVar7 = func_0x000180208380(iVar9);
                if (iVar7 == 0) goto code_r0x0001802079d6;
                piVar1 = (int64_t *)(*(int64_t *)(iVar9 + 0x88) + 8);
                *piVar1 = *piVar1 + iVar11;
                puVar2 = (uint32_t *)(*(int64_t *)(iVar9 + 0x88) + 0x20);
                *puVar2 = *puVar2 | 4;
            }
            *(uint32_t *)((&var_440h)[(uint64_t)uVar16 * 0x24] + 0x20) =
                 *(uint32_t *)((&var_440h)[(uint64_t)uVar16 * 0x24] + 0x20) | 4;
        }
    }
    uVar14 = 0;
    do {
        if ((*(int32_t *)(&var_448h + uVar14 * 0x24) != 0) &&
           (uVar15 = *(uint64_t *)((int64_t)&arg_38h + uVar14 * 0x120 + iVar8), uVar15 != 0)) {
            uVar13 = *(uint64_t *)(in_RCX + 400);
            if (uVar13 <= uVar15) break;
            if (uVar13 != 0xffffffffffffffff) {
                *(uint64_t *)(in_RCX + 400) = uVar13 - uVar15;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020793d;
            iVar7 = func_0x000180209b50(in_RCX, (int64_t)&arg_28h + uVar14 * 0x120 + iVar8, 
                                        *(undefined4 *)((int64_t)&var_4h + iVar8), (int64_t)&var_8h + iVar8);
            if (iVar7 != 0) {
                piVar10 = *(int32_t **)((int64_t)&var_10h + iVar8);
                if ((*piVar10 != 0) || (iVar6 = 0, (*(uint8_t *)((&var_440h)[uVar14 * 0x24] + 0x20) & 8) != 0)) {
                    iVar6 = 1;
                }
                *piVar10 = iVar6;
                if ((int32_t)uVar14 == 2) {
                    if ((*(int32_t *)(&var_448h + uVar14 * 0x24) == 0) ||
                       (iVar6 = 1, *(int64_t *)((int64_t)&arg_38h + uVar14 * 0x120 + iVar8) == 0)) {
                        iVar6 = 0;
                    }
                    piVar10[1] = iVar6;
                }
            }
            if (*(int32_t *)((int64_t)&var_8h + iVar8) != 0) {
                (&var_440h)[uVar14 * 0x24] = 0;
            }
            if (iVar7 == 0) break;
            piVar1 = (int64_t *)((int64_t)&var_4h + iVar8 + 4);
            *piVar1 = *piVar1 + 1;
        }
        uVar16 = (int32_t)uVar14 + 1;
        uVar14 = (uint64_t)uVar16;
    } while (uVar16 < 4);
code_r0x0001802079d6:
    uVar3 = *(undefined8 *)(in_RCX + 0x50);
    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802079df;
    func_0x0001801fb380(uVar3);
    if ((int32_t)var_448h != 0) {
        if (((uint32_t)var_450h & 1) != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802079f4;
            func_0x000180243fb0(&var_488h);
            var_450h._0_4_ = (uint32_t)var_450h & 0xfffffffe;
        }
        *(undefined8 *)((int64_t)&arg_28h + iVar8) = 0;
        var_448h._0_4_ = 0;
        if (var_440h != 0) {
            uVar3 = *(undefined8 *)(in_RCX + 0x58);
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180207a17;
            func_0x000180203dd0(uVar3);
            var_440h = 0;
        }
    }
    if ((int32_t)var_328h != 0) {
        if (((uint32_t)var_330h & 1) != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180207a39;
            func_0x000180243fb0(&var_368h);
            var_330h._0_4_ = (uint32_t)var_330h & 0xfffffffe;
            var_370h = 0;
        }
        var_3a8h = 0;
        var_328h._0_4_ = 0;
        if (var_320h != 0) {
            uVar3 = *(undefined8 *)(in_RCX + 0x58);
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180207a6a;
            func_0x000180203dd0(uVar3);
            var_320h = 0;
        }
    }
    if ((int32_t)var_208h != 0) {
        if (((uint32_t)var_210h & 1) != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180207a8f;
            func_0x000180243fb0(&var_248h);
            var_210h._0_4_ = (uint32_t)var_210h & 0xfffffffe;
            var_250h = 0;
        }
        var_288h = 0;
        var_208h._0_4_ = 0;
        if (var_200h != 0) {
            uVar3 = *(undefined8 *)(in_RCX + 0x58);
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180207ac0;
            func_0x000180203dd0(uVar3);
            var_200h = 0;
        }
    }
    if ((int32_t)var_e8h != 0) {
        if (((uint32_t)var_f0h & 1) != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180207ae5;
            func_0x000180243fb0(&var_128h);
            var_f0h._0_4_ = (uint32_t)var_f0h & 0xfffffffe;
            var_130h = 0;
        }
        var_168h = 0;
        var_e8h._0_4_ = 0;
        if (var_e0h != 0) {
            uVar3 = *(undefined8 *)(in_RCX + 0x58);
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180207b16;
            func_0x000180203dd0(uVar3);
        }
    }
    *(undefined8 *)(*(int64_t *)((int64_t)&var_10h + iVar8) + 8) = *(undefined8 *)((int64_t)&var_4h + iVar8 + 4);
    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180207b35;
    func_0x000180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_180207b50
// Address: 0x180207b50
// Size: 196 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.180207b50(int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    undefined8 uVar8;
    uint32_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180207b65;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar9 = 0;
    uVar7 = 0xffffffffffffffff;
    do {
        uVar8 = *(undefined8 *)(in_RCX + 0x50);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180207b7f;
        iVar3 = func_0x0001801fb7e0(uVar8, uVar9);
        uVar5 = uVar7;
        if (iVar3 != 0) {
            if (uVar9 == 0) {
                uVar8 = 0;
            } else if ((uVar9 == 1) || (uVar9 != 2)) {
                uVar8 = 2;
            } else {
                uVar8 = 1;
            }
            uVar1 = *(undefined8 *)(in_RCX + 0x68);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180207bac;
            uVar5 = func_0x0001802026d0(uVar1, uVar8);
            if (uVar7 < uVar5) {
                uVar5 = uVar7;
            }
        }
        uVar9 = uVar9 + 1;
        uVar7 = uVar5;
    } while (uVar9 < 4);
    uVar8 = *(undefined8 *)(in_RCX + 0xa0);
    pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0x98) + 0x30);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180207bd1;
    iVar6 = (*pcVar2)(uVar8);
    if (iVar6 != 0) {
        return uVar5;
    }
    uVar8 = *(undefined8 *)(in_RCX + 0xa0);
    pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0x98) + 0x38);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180207bea;
    uVar7 = (*pcVar2)(uVar8);
    if (uVar5 < uVar7) {
        uVar7 = uVar5;
    }
    return uVar7;
}

// ============================================================
// Function: FUN_180207c40
// Address: 0x180207c40
// Size: 154 bytes
// ============================================================
undefined4 *
fcn.180207c40(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_78h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    undefined4 *in_RCX;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180207c4c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((((((in_RCX != (undefined4 *)0x0) && (*(int64_t *)(in_RCX + 0x14) != 0)) && (*(int64_t *)(in_RCX + 0x16) != 0))
         && ((*(int64_t *)(in_RCX + 0x18) != 0 && (*(int64_t *)(in_RCX + 0x1a) != 0)))) &&
        ((*(int64_t *)(in_RCX + 0x1c) != 0 && ((*(int64_t *)(in_RCX + 0x1e) != 0 && (*(int64_t *)(in_RCX + 0x20) != 0)))
         ))) && ((*(int64_t *)(in_RCX + 0x22) != 0 && ((*(int64_t *)(in_RCX + 0x24) != 0 && (in_RCX[0x32] != 0)))))) {
        *(undefined8 *)((int64_t)&arg_78h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180207cf3;
        puVar6 = (undefined4 *)fcn.180224d60(*(int64_t *)((int64_t)&var_18h + iVar5));
        if (puVar6 != (undefined4 *)0x0) {
            uVar1 = in_RCX[1];
            uVar2 = in_RCX[2];
            uVar3 = in_RCX[3];
            *puVar6 = *in_RCX;
            puVar6[1] = uVar1;
            puVar6[2] = uVar2;
            puVar6[3] = uVar3;
            uVar1 = in_RCX[5];
            uVar2 = in_RCX[6];
            uVar3 = in_RCX[7];
            puVar6[4] = in_RCX[4];
            puVar6[5] = uVar1;
            puVar6[6] = uVar2;
            puVar6[7] = uVar3;
            uVar1 = in_RCX[9];
            uVar2 = in_RCX[10];
            uVar3 = in_RCX[0xb];
            puVar6[8] = in_RCX[8];
            puVar6[9] = uVar1;
            puVar6[10] = uVar2;
            puVar6[0xb] = uVar3;
            uVar1 = in_RCX[0xd];
            uVar2 = in_RCX[0xe];
            uVar3 = in_RCX[0xf];
            puVar6[0xc] = in_RCX[0xc];
            puVar6[0xd] = uVar1;
            puVar6[0xe] = uVar2;
            puVar6[0xf] = uVar3;
            uVar1 = in_RCX[0x11];
            uVar2 = in_RCX[0x12];
            uVar3 = in_RCX[0x13];
            puVar6[0x10] = in_RCX[0x10];
            puVar6[0x11] = uVar1;
            puVar6[0x12] = uVar2;
            puVar6[0x13] = uVar3;
            uVar1 = in_RCX[0x15];
            uVar2 = in_RCX[0x16];
            uVar3 = in_RCX[0x17];
            puVar6[0x14] = in_RCX[0x14];
            puVar6[0x15] = uVar1;
            puVar6[0x16] = uVar2;
            puVar6[0x17] = uVar3;
            uVar1 = in_RCX[0x19];
            uVar2 = in_RCX[0x1a];
            uVar3 = in_RCX[0x1b];
            puVar6[0x18] = in_RCX[0x18];
            puVar6[0x19] = uVar1;
            puVar6[0x1a] = uVar2;
            puVar6[0x1b] = uVar3;
            uVar1 = in_RCX[0x1d];
            uVar2 = in_RCX[0x1e];
            uVar3 = in_RCX[0x1f];
            puVar6[0x1c] = in_RCX[0x1c];
            puVar6[0x1d] = uVar1;
            puVar6[0x1e] = uVar2;
            puVar6[0x1f] = uVar3;
            uVar1 = in_RCX[0x21];
            uVar2 = in_RCX[0x22];
            uVar3 = in_RCX[0x23];
            puVar6[0x20] = in_RCX[0x20];
            puVar6[0x21] = uVar1;
            puVar6[0x22] = uVar2;
            puVar6[0x23] = uVar3;
            uVar1 = in_RCX[0x25];
            uVar2 = in_RCX[0x26];
            uVar3 = in_RCX[0x27];
            puVar6[0x24] = in_RCX[0x24];
            puVar6[0x25] = uVar1;
            puVar6[0x26] = uVar2;
            puVar6[0x27] = uVar3;
            uVar1 = in_RCX[0x29];
            uVar2 = in_RCX[0x2a];
            uVar3 = in_RCX[0x2b];
            puVar6[0x28] = in_RCX[0x28];
            puVar6[0x29] = uVar1;
            puVar6[0x2a] = uVar2;
            puVar6[0x2b] = uVar3;
            uVar1 = in_RCX[0x2d];
            uVar2 = in_RCX[0x2e];
            uVar3 = in_RCX[0x2f];
            puVar6[0x2c] = in_RCX[0x2c];
            puVar6[0x2d] = uVar1;
            puVar6[0x2e] = uVar2;
            puVar6[0x2f] = uVar3;
            uVar1 = in_RCX[0x31];
            uVar2 = in_RCX[0x32];
            uVar3 = in_RCX[0x33];
            puVar6[0x30] = in_RCX[0x30];
            puVar6[0x31] = uVar1;
            puVar6[0x32] = uVar2;
            puVar6[0x33] = uVar3;
            uVar1 = in_RCX[0x35];
            uVar2 = in_RCX[0x36];
            uVar3 = in_RCX[0x37];
            puVar6[0x34] = in_RCX[0x34];
            puVar6[0x35] = uVar1;
            puVar6[0x36] = uVar2;
            puVar6[0x37] = uVar3;
            *(undefined8 *)(puVar6 + 0x38) = *(undefined8 *)(in_RCX + 0x38);
            *(undefined8 *)(puVar6 + 0x62) = 0;
            *(undefined8 *)((int64_t)&arg_60h + iVar5) = *(undefined8 *)(in_RCX + 0x30);
            *(undefined8 *)((int64_t)&arg_58h + iVar5) = *(undefined8 *)(in_RCX + 0x2e);
            *(undefined4 **)((int64_t)&arg_50h + iVar5) = puVar6;
            *(code **)((int64_t)&arg_48h + iVar5) = fcn.1802071f0;
            *(undefined4 **)((int64_t)&arg_40h + iVar5) = puVar6;
            *(code **)((int64_t)&arg_38h + iVar5) = fcn.180207020;
            *(undefined4 **)((int64_t)&arg_30h + iVar5) = puVar6;
            *(code **)((int64_t)&arg_28h + iVar5) = fcn.1802070a0;
            *(undefined4 **)((int64_t)&var_20h + iVar5) = puVar6;
            *(code **)((int64_t)&var_18h + iVar5) = fcn.180206fd0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180207e00;
            iVar4 = fcn.18020e210(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar5), *(int64_t *)((int64_t)&arg_60h + iVar5));
            if (iVar4 != 0) {
                return puVar6;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180207e19;
            fcn.180224990(puVar6, 0x1804ba078, 0x23c);
        }
        return (undefined4 *)0x0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180207e3f;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180207e57;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                  *(int64_t *)((int64_t)&arg_48h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180207e69;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
    return (undefined4 *)0x0;
}

// ============================================================
// Function: FUN_180207cda
// Address: 0x180207cda
// Size: 335 bytes
// ============================================================
undefined4 *
fcn.180207c40(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_78h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    undefined4 *in_RCX;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180207c4c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((((((in_RCX != (undefined4 *)0x0) && (*(int64_t *)(in_RCX + 0x14) != 0)) && (*(int64_t *)(in_RCX + 0x16) != 0))
         && ((*(int64_t *)(in_RCX + 0x18) != 0 && (*(int64_t *)(in_RCX + 0x1a) != 0)))) &&
        ((*(int64_t *)(in_RCX + 0x1c) != 0 && ((*(int64_t *)(in_RCX + 0x1e) != 0 && (*(int64_t *)(in_RCX + 0x20) != 0)))
         ))) && ((*(int64_t *)(in_RCX + 0x22) != 0 && ((*(int64_t *)(in_RCX + 0x24) != 0 && (in_RCX[0x32] != 0)))))) {
        *(undefined8 *)((int64_t)&arg_78h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180207cf3;
        puVar6 = (undefined4 *)fcn.180224d60(*(int64_t *)((int64_t)&var_18h + iVar5));
        if (puVar6 != (undefined4 *)0x0) {
            uVar1 = in_RCX[1];
            uVar2 = in_RCX[2];
            uVar3 = in_RCX[3];
            *puVar6 = *in_RCX;
            puVar6[1] = uVar1;
            puVar6[2] = uVar2;
            puVar6[3] = uVar3;
            uVar1 = in_RCX[5];
            uVar2 = in_RCX[6];
            uVar3 = in_RCX[7];
            puVar6[4] = in_RCX[4];
            puVar6[5] = uVar1;
            puVar6[6] = uVar2;
            puVar6[7] = uVar3;
            uVar1 = in_RCX[9];
            uVar2 = in_RCX[10];
            uVar3 = in_RCX[0xb];
            puVar6[8] = in_RCX[8];
            puVar6[9] = uVar1;
            puVar6[10] = uVar2;
            puVar6[0xb] = uVar3;
            uVar1 = in_RCX[0xd];
            uVar2 = in_RCX[0xe];
            uVar3 = in_RCX[0xf];
            puVar6[0xc] = in_RCX[0xc];
            puVar6[0xd] = uVar1;
            puVar6[0xe] = uVar2;
            puVar6[0xf] = uVar3;
            uVar1 = in_RCX[0x11];
            uVar2 = in_RCX[0x12];
            uVar3 = in_RCX[0x13];
            puVar6[0x10] = in_RCX[0x10];
            puVar6[0x11] = uVar1;
            puVar6[0x12] = uVar2;
            puVar6[0x13] = uVar3;
            uVar1 = in_RCX[0x15];
            uVar2 = in_RCX[0x16];
            uVar3 = in_RCX[0x17];
            puVar6[0x14] = in_RCX[0x14];
            puVar6[0x15] = uVar1;
            puVar6[0x16] = uVar2;
            puVar6[0x17] = uVar3;
            uVar1 = in_RCX[0x19];
            uVar2 = in_RCX[0x1a];
            uVar3 = in_RCX[0x1b];
            puVar6[0x18] = in_RCX[0x18];
            puVar6[0x19] = uVar1;
            puVar6[0x1a] = uVar2;
            puVar6[0x1b] = uVar3;
            uVar1 = in_RCX[0x1d];
            uVar2 = in_RCX[0x1e];
            uVar3 = in_RCX[0x1f];
            puVar6[0x1c] = in_RCX[0x1c];
            puVar6[0x1d] = uVar1;
            puVar6[0x1e] = uVar2;
            puVar6[0x1f] = uVar3;
            uVar1 = in_RCX[0x21];
            uVar2 = in_RCX[0x22];
            uVar3 = in_RCX[0x23];
            puVar6[0x20] = in_RCX[0x20];
            puVar6[0x21] = uVar1;
            puVar6[0x22] = uVar2;
            puVar6[0x23] = uVar3;
            uVar1 = in_RCX[0x25];
            uVar2 = in_RCX[0x26];
            uVar3 = in_RCX[0x27];
            puVar6[0x24] = in_RCX[0x24];
            puVar6[0x25] = uVar1;
            puVar6[0x26] = uVar2;
            puVar6[0x27] = uVar3;
            uVar1 = in_RCX[0x29];
            uVar2 = in_RCX[0x2a];
            uVar3 = in_RCX[0x2b];
            puVar6[0x28] = in_RCX[0x28];
            puVar6[0x29] = uVar1;
            puVar6[0x2a] = uVar2;
            puVar6[0x2b] = uVar3;
            uVar1 = in_RCX[0x2d];
            uVar2 = in_RCX[0x2e];
            uVar3 = in_RCX[0x2f];
            puVar6[0x2c] = in_RCX[0x2c];
            puVar6[0x2d] = uVar1;
            puVar6[0x2e] = uVar2;
            puVar6[0x2f] = uVar3;
            uVar1 = in_RCX[0x31];
            uVar2 = in_RCX[0x32];
            uVar3 = in_RCX[0x33];
            puVar6[0x30] = in_RCX[0x30];
            puVar6[0x31] = uVar1;
            puVar6[0x32] = uVar2;
            puVar6[0x33] = uVar3;
            uVar1 = in_RCX[0x35];
            uVar2 = in_RCX[0x36];
            uVar3 = in_RCX[0x37];
            puVar6[0x34] = in_RCX[0x34];
            puVar6[0x35] = uVar1;
            puVar6[0x36] = uVar2;
            puVar6[0x37] = uVar3;
            *(undefined8 *)(puVar6 + 0x38) = *(undefined8 *)(in_RCX + 0x38);
            *(undefined8 *)(puVar6 + 0x62) = 0;
            *(undefined8 *)((int64_t)&arg_60h + iVar5) = *(undefined8 *)(in_RCX + 0x30);
            *(undefined8 *)((int64_t)&arg_58h + iVar5) = *(undefined8 *)(in_RCX + 0x2e);
            *(undefined4 **)((int64_t)&arg_50h + iVar5) = puVar6;
            *(code **)((int64_t)&arg_48h + iVar5) = fcn.1802071f0;
            *(undefined4 **)((int64_t)&arg_40h + iVar5) = puVar6;
            *(code **)((int64_t)&arg_38h + iVar5) = fcn.180207020;
            *(undefined4 **)((int64_t)&arg_30h + iVar5) = puVar6;
            *(code **)((int64_t)&arg_28h + iVar5) = fcn.1802070a0;
            *(undefined4 **)((int64_t)&var_20h + iVar5) = puVar6;
            *(code **)((int64_t)&var_18h + iVar5) = fcn.180206fd0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180207e00;
            iVar4 = fcn.18020e210(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar5), *(int64_t *)((int64_t)&arg_60h + iVar5));
            if (iVar4 != 0) {
                return puVar6;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180207e19;
            fcn.180224990(puVar6, 0x1804ba078, 0x23c);
        }
        return (undefined4 *)0x0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180207e3f;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180207e57;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                  *(int64_t *)((int64_t)&arg_48h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180207e69;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
    return (undefined4 *)0x0;
}

// ============================================================
// Function: FUN_180207e29
// Address: 0x180207e29
// Size: 17 bytes
// ============================================================
undefined4 *
fcn.180207c40(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_78h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    undefined4 *in_RCX;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180207c4c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((((((in_RCX != (undefined4 *)0x0) && (*(int64_t *)(in_RCX + 0x14) != 0)) && (*(int64_t *)(in_RCX + 0x16) != 0))
         && ((*(int64_t *)(in_RCX + 0x18) != 0 && (*(int64_t *)(in_RCX + 0x1a) != 0)))) &&
        ((*(int64_t *)(in_RCX + 0x1c) != 0 && ((*(int64_t *)(in_RCX + 0x1e) != 0 && (*(int64_t *)(in_RCX + 0x20) != 0)))
         ))) && ((*(int64_t *)(in_RCX + 0x22) != 0 && ((*(int64_t *)(in_RCX + 0x24) != 0 && (in_RCX[0x32] != 0)))))) {
        *(undefined8 *)((int64_t)&arg_78h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180207cf3;
        puVar6 = (undefined4 *)fcn.180224d60(*(int64_t *)((int64_t)&var_18h + iVar5));
        if (puVar6 != (undefined4 *)0x0) {
            uVar1 = in_RCX[1];
            uVar2 = in_RCX[2];
            uVar3 = in_RCX[3];
            *puVar6 = *in_RCX;
            puVar6[1] = uVar1;
            puVar6[2] = uVar2;
            puVar6[3] = uVar3;
            uVar1 = in_RCX[5];
            uVar2 = in_RCX[6];
            uVar3 = in_RCX[7];
            puVar6[4] = in_RCX[4];
            puVar6[5] = uVar1;
            puVar6[6] = uVar2;
            puVar6[7] = uVar3;
            uVar1 = in_RCX[9];
            uVar2 = in_RCX[10];
            uVar3 = in_RCX[0xb];
            puVar6[8] = in_RCX[8];
            puVar6[9] = uVar1;
            puVar6[10] = uVar2;
            puVar6[0xb] = uVar3;
            uVar1 = in_RCX[0xd];
            uVar2 = in_RCX[0xe];
            uVar3 = in_RCX[0xf];
            puVar6[0xc] = in_RCX[0xc];
            puVar6[0xd] = uVar1;
            puVar6[0xe] = uVar2;
            puVar6[0xf] = uVar3;
            uVar1 = in_RCX[0x11];
            uVar2 = in_RCX[0x12];
            uVar3 = in_RCX[0x13];
            puVar6[0x10] = in_RCX[0x10];
            puVar6[0x11] = uVar1;
            puVar6[0x12] = uVar2;
            puVar6[0x13] = uVar3;
            uVar1 = in_RCX[0x15];
            uVar2 = in_RCX[0x16];
            uVar3 = in_RCX[0x17];
            puVar6[0x14] = in_RCX[0x14];
            puVar6[0x15] = uVar1;
            puVar6[0x16] = uVar2;
            puVar6[0x17] = uVar3;
            uVar1 = in_RCX[0x19];
            uVar2 = in_RCX[0x1a];
            uVar3 = in_RCX[0x1b];
            puVar6[0x18] = in_RCX[0x18];
            puVar6[0x19] = uVar1;
            puVar6[0x1a] = uVar2;
            puVar6[0x1b] = uVar3;
            uVar1 = in_RCX[0x1d];
            uVar2 = in_RCX[0x1e];
            uVar3 = in_RCX[0x1f];
            puVar6[0x1c] = in_RCX[0x1c];
            puVar6[0x1d] = uVar1;
            puVar6[0x1e] = uVar2;
            puVar6[0x1f] = uVar3;
            uVar1 = in_RCX[0x21];
            uVar2 = in_RCX[0x22];
            uVar3 = in_RCX[0x23];
            puVar6[0x20] = in_RCX[0x20];
            puVar6[0x21] = uVar1;
            puVar6[0x22] = uVar2;
            puVar6[0x23] = uVar3;
            uVar1 = in_RCX[0x25];
            uVar2 = in_RCX[0x26];
            uVar3 = in_RCX[0x27];
            puVar6[0x24] = in_RCX[0x24];
            puVar6[0x25] = uVar1;
            puVar6[0x26] = uVar2;
            puVar6[0x27] = uVar3;
            uVar1 = in_RCX[0x29];
            uVar2 = in_RCX[0x2a];
            uVar3 = in_RCX[0x2b];
            puVar6[0x28] = in_RCX[0x28];
            puVar6[0x29] = uVar1;
            puVar6[0x2a] = uVar2;
            puVar6[0x2b] = uVar3;
            uVar1 = in_RCX[0x2d];
            uVar2 = in_RCX[0x2e];
            uVar3 = in_RCX[0x2f];
            puVar6[0x2c] = in_RCX[0x2c];
            puVar6[0x2d] = uVar1;
            puVar6[0x2e] = uVar2;
            puVar6[0x2f] = uVar3;
            uVar1 = in_RCX[0x31];
            uVar2 = in_RCX[0x32];
            uVar3 = in_RCX[0x33];
            puVar6[0x30] = in_RCX[0x30];
            puVar6[0x31] = uVar1;
            puVar6[0x32] = uVar2;
            puVar6[0x33] = uVar3;
            uVar1 = in_RCX[0x35];
            uVar2 = in_RCX[0x36];
            uVar3 = in_RCX[0x37];
            puVar6[0x34] = in_RCX[0x34];
            puVar6[0x35] = uVar1;
            puVar6[0x36] = uVar2;
            puVar6[0x37] = uVar3;
            *(undefined8 *)(puVar6 + 0x38) = *(undefined8 *)(in_RCX + 0x38);
            *(undefined8 *)(puVar6 + 0x62) = 0;
            *(undefined8 *)((int64_t)&arg_60h + iVar5) = *(undefined8 *)(in_RCX + 0x30);
            *(undefined8 *)((int64_t)&arg_58h + iVar5) = *(undefined8 *)(in_RCX + 0x2e);
            *(undefined4 **)((int64_t)&arg_50h + iVar5) = puVar6;
            *(code **)((int64_t)&arg_48h + iVar5) = fcn.1802071f0;
            *(undefined4 **)((int64_t)&arg_40h + iVar5) = puVar6;
            *(code **)((int64_t)&arg_38h + iVar5) = fcn.180207020;
            *(undefined4 **)((int64_t)&arg_30h + iVar5) = puVar6;
            *(code **)((int64_t)&arg_28h + iVar5) = fcn.1802070a0;
            *(undefined4 **)((int64_t)&var_20h + iVar5) = puVar6;
            *(code **)((int64_t)&var_18h + iVar5) = fcn.180206fd0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180207e00;
            iVar4 = fcn.18020e210(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar5), *(int64_t *)((int64_t)&arg_60h + iVar5));
            if (iVar4 != 0) {
                return puVar6;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180207e19;
            fcn.180224990(puVar6, 0x1804ba078, 0x23c);
        }
        return (undefined4 *)0x0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180207e3f;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180207e57;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                  *(int64_t *)((int64_t)&arg_48h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180207e69;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
    return (undefined4 *)0x0;
}

// ============================================================
// Function: FUN_180207e3a
// Address: 0x180207e3a
// Size: 55 bytes
// ============================================================
undefined4 *
fcn.180207c40(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_78h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    undefined4 *in_RCX;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180207c4c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((((((in_RCX != (undefined4 *)0x0) && (*(int64_t *)(in_RCX + 0x14) != 0)) && (*(int64_t *)(in_RCX + 0x16) != 0))
         && ((*(int64_t *)(in_RCX + 0x18) != 0 && (*(int64_t *)(in_RCX + 0x1a) != 0)))) &&
        ((*(int64_t *)(in_RCX + 0x1c) != 0 && ((*(int64_t *)(in_RCX + 0x1e) != 0 && (*(int64_t *)(in_RCX + 0x20) != 0)))
         ))) && ((*(int64_t *)(in_RCX + 0x22) != 0 && ((*(int64_t *)(in_RCX + 0x24) != 0 && (in_RCX[0x32] != 0)))))) {
        *(undefined8 *)((int64_t)&arg_78h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180207cf3;
        puVar6 = (undefined4 *)fcn.180224d60(*(int64_t *)((int64_t)&var_18h + iVar5));
        if (puVar6 != (undefined4 *)0x0) {
            uVar1 = in_RCX[1];
            uVar2 = in_RCX[2];
            uVar3 = in_RCX[3];
            *puVar6 = *in_RCX;
            puVar6[1] = uVar1;
            puVar6[2] = uVar2;
            puVar6[3] = uVar3;
            uVar1 = in_RCX[5];
            uVar2 = in_RCX[6];
            uVar3 = in_RCX[7];
            puVar6[4] = in_RCX[4];
            puVar6[5] = uVar1;
            puVar6[6] = uVar2;
            puVar6[7] = uVar3;
            uVar1 = in_RCX[9];
            uVar2 = in_RCX[10];
            uVar3 = in_RCX[0xb];
            puVar6[8] = in_RCX[8];
            puVar6[9] = uVar1;
            puVar6[10] = uVar2;
            puVar6[0xb] = uVar3;
            uVar1 = in_RCX[0xd];
            uVar2 = in_RCX[0xe];
            uVar3 = in_RCX[0xf];
            puVar6[0xc] = in_RCX[0xc];
            puVar6[0xd] = uVar1;
            puVar6[0xe] = uVar2;
            puVar6[0xf] = uVar3;
            uVar1 = in_RCX[0x11];
            uVar2 = in_RCX[0x12];
            uVar3 = in_RCX[0x13];
            puVar6[0x10] = in_RCX[0x10];
            puVar6[0x11] = uVar1;
            puVar6[0x12] = uVar2;
            puVar6[0x13] = uVar3;
            uVar1 = in_RCX[0x15];
            uVar2 = in_RCX[0x16];
            uVar3 = in_RCX[0x17];
            puVar6[0x14] = in_RCX[0x14];
            puVar6[0x15] = uVar1;
            puVar6[0x16] = uVar2;
            puVar6[0x17] = uVar3;
            uVar1 = in_RCX[0x19];
            uVar2 = in_RCX[0x1a];
            uVar3 = in_RCX[0x1b];
            puVar6[0x18] = in_RCX[0x18];
            puVar6[0x19] = uVar1;
            puVar6[0x1a] = uVar2;
            puVar6[0x1b] = uVar3;
            uVar1 = in_RCX[0x1d];
            uVar2 = in_RCX[0x1e];
            uVar3 = in_RCX[0x1f];
            puVar6[0x1c] = in_RCX[0x1c];
            puVar6[0x1d] = uVar1;
            puVar6[0x1e] = uVar2;
            puVar6[0x1f] = uVar3;
            uVar1 = in_RCX[0x21];
            uVar2 = in_RCX[0x22];
            uVar3 = in_RCX[0x23];
            puVar6[0x20] = in_RCX[0x20];
            puVar6[0x21] = uVar1;
            puVar6[0x22] = uVar2;
            puVar6[0x23] = uVar3;
            uVar1 = in_RCX[0x25];
            uVar2 = in_RCX[0x26];
            uVar3 = in_RCX[0x27];
            puVar6[0x24] = in_RCX[0x24];
            puVar6[0x25] = uVar1;
            puVar6[0x26] = uVar2;
            puVar6[0x27] = uVar3;
            uVar1 = in_RCX[0x29];
            uVar2 = in_RCX[0x2a];
            uVar3 = in_RCX[0x2b];
            puVar6[0x28] = in_RCX[0x28];
            puVar6[0x29] = uVar1;
            puVar6[0x2a] = uVar2;
            puVar6[0x2b] = uVar3;
            uVar1 = in_RCX[0x2d];
            uVar2 = in_RCX[0x2e];
            uVar3 = in_RCX[0x2f];
            puVar6[0x2c] = in_RCX[0x2c];
            puVar6[0x2d] = uVar1;
            puVar6[0x2e] = uVar2;
            puVar6[0x2f] = uVar3;
            uVar1 = in_RCX[0x31];
            uVar2 = in_RCX[0x32];
            uVar3 = in_RCX[0x33];
            puVar6[0x30] = in_RCX[0x30];
            puVar6[0x31] = uVar1;
            puVar6[0x32] = uVar2;
            puVar6[0x33] = uVar3;
            uVar1 = in_RCX[0x35];
            uVar2 = in_RCX[0x36];
            uVar3 = in_RCX[0x37];
            puVar6[0x34] = in_RCX[0x34];
            puVar6[0x35] = uVar1;
            puVar6[0x36] = uVar2;
            puVar6[0x37] = uVar3;
            *(undefined8 *)(puVar6 + 0x38) = *(undefined8 *)(in_RCX + 0x38);
            *(undefined8 *)(puVar6 + 0x62) = 0;
            *(undefined8 *)((int64_t)&arg_60h + iVar5) = *(undefined8 *)(in_RCX + 0x30);
            *(undefined8 *)((int64_t)&arg_58h + iVar5) = *(undefined8 *)(in_RCX + 0x2e);
            *(undefined4 **)((int64_t)&arg_50h + iVar5) = puVar6;
            *(code **)((int64_t)&arg_48h + iVar5) = fcn.1802071f0;
            *(undefined4 **)((int64_t)&arg_40h + iVar5) = puVar6;
            *(code **)((int64_t)&arg_38h + iVar5) = fcn.180207020;
            *(undefined4 **)((int64_t)&arg_30h + iVar5) = puVar6;
            *(code **)((int64_t)&arg_28h + iVar5) = fcn.1802070a0;
            *(undefined4 **)((int64_t)&var_20h + iVar5) = puVar6;
            *(code **)((int64_t)&var_18h + iVar5) = fcn.180206fd0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180207e00;
            iVar4 = fcn.18020e210(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar5), *(int64_t *)((int64_t)&arg_60h + iVar5));
            if (iVar4 != 0) {
                return puVar6;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180207e19;
            fcn.180224990(puVar6, 0x1804ba078, 0x23c);
        }
        return (undefined4 *)0x0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180207e3f;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180207e57;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                  *(int64_t *)((int64_t)&arg_48h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180207e69;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
    return (undefined4 *)0x0;
}

// ============================================================
// Function: FUN_180207f00
// Address: 0x180207f00
// Size: 200 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180207f00(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint64_t uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t in_RCX;
    undefined4 *in_RDX;
    uint64_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180207f20;
    iVar6 = fcn.18045a350();
    uVar1 = *(uint64_t *)(in_RDX + 8);
    uVar9 = *(undefined8 *)(in_RCX + 0x50);
    iVar8 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + -iVar6) = 0x180207f38;
    uVar7 = func_0x0001801fb7c0(uVar9);
    if ((*(uint32_t *)(in_RCX + 0x198) & 0x400) == 0) {
        uVar10 = uVar7 >> 1;
        if (uVar1 <= uVar7 >> 1) {
            uVar10 = uVar1;
        }
        if (uVar10 != 0) {
            uVar9 = *(undefined8 *)(in_RDX + 6);
            *(undefined8 *)((int64_t)&uStack_10 + -iVar6) = 0x180207f6f;
            iVar8 = func_0x000180223170(uVar9, uVar10, 0x1804ba078, 0xc76);
            if (iVar8 == 0) goto code_r0x000180207fab;
        }
        uVar2 = in_RDX[1];
        uVar3 = in_RDX[2];
        uVar4 = in_RDX[3];
        uVar9 = 1;
        *(undefined4 *)(in_RCX + 0x1a0) = *in_RDX;
        *(undefined4 *)(in_RCX + 0x1a4) = uVar2;
        *(undefined4 *)(in_RCX + 0x1a8) = uVar3;
        *(undefined4 *)(in_RCX + 0x1ac) = uVar4;
        uVar2 = in_RDX[4];
        uVar3 = in_RDX[5];
        uVar4 = in_RDX[6];
        uVar5 = in_RDX[7];
        *(uint32_t *)(in_RCX + 0x198) = *(uint32_t *)(in_RCX + 0x198) | 0x400;
        *(undefined4 *)(in_RCX + 0x1b0) = uVar2;
        *(undefined4 *)(in_RCX + 0x1b4) = uVar3;
        *(undefined4 *)(in_RCX + 0x1b8) = uVar4;
        *(undefined4 *)(in_RCX + 0x1bc) = uVar5;
        *(int64_t *)(in_RCX + 0x1b8) = iVar8;
        *(uint64_t *)(in_RCX + 0x1c0) = uVar10;
    } else {
code_r0x000180207fab:
        uVar9 = 0;
    }
    return uVar9;
}

// ============================================================
// Function: FUN_180207ff0
// Address: 0x180207ff0
// Size: 102 bytes
// ============================================================
undefined8 fcn.180207ff0(int64_t param_1, undefined4 *param_2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x180207ffa;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (param_2 == (undefined4 *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180208007;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4), *(int64_t *)(&stack0x00000028 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x18020801f;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)(&stack0x00000030 + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                      *(int64_t *)(&stack0x00000050 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180208031;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar4));
        return 0;
    }
    uVar1 = param_2[1];
    uVar2 = param_2[2];
    uVar3 = param_2[3];
    *(undefined4 *)(param_1 + 0x15) = *param_2;
    *(undefined4 *)(param_1 + 0x19) = uVar1;
    *(undefined4 *)(param_1 + 0x1d) = uVar2;
    *(undefined4 *)(param_1 + 0x21) = uVar3;
    *(undefined4 *)(param_1 + 0x25) = param_2[4];
    *(undefined *)(param_1 + 0x29) = *(undefined *)(param_2 + 5);
    return 1;
}

// ============================================================
// Function: FUN_180208060
// Address: 0x180208060
// Size: 101 bytes
// ============================================================
undefined8 fcn.180208060(undefined4 *param_1, undefined4 *param_2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020806a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (param_2 == (undefined4 *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180208077;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4), *(int64_t *)(&stack0x00000028 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x18020808f;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)(&stack0x00000030 + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                      *(int64_t *)(&stack0x00000050 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x1802080a1;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar4));
        return 0;
    }
    uVar1 = param_2[1];
    uVar2 = param_2[2];
    uVar3 = param_2[3];
    *param_1 = *param_2;
    param_1[1] = uVar1;
    param_1[2] = uVar2;
    param_1[3] = uVar3;
    param_1[4] = param_2[4];
    *(undefined *)(param_1 + 5) = *(undefined *)(param_2 + 5);
    return 1;
}

// ============================================================
// Function: FUN_1802080d0
// Address: 0x1802080d0
// Size: 182 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1802080d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint64_t in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802080ea;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar6 = *(undefined8 *)(in_RCX + 0x50);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180208102;
    uVar5 = func_0x0001801fb7c0(uVar6);
    if ((in_R8 == 0) || (((in_R8 < uVar5 && (0xa0 < uVar5)) && (in_R8 <= uVar5 - 0xa0)))) {
        iVar1 = *(int64_t *)(in_RCX + 0xe8);
        if ((iVar1 != 0) && (pcVar2 = *(code **)(in_RCX + 0xf8), pcVar2 != (code *)0x0)) {
            uVar6 = *(undefined8 *)(in_RCX + 0x100);
            uVar3 = *(undefined8 *)(in_RCX + 0xf0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020814b;
            (*pcVar2)(iVar1, uVar3, uVar6);
        }
        *(undefined8 *)(in_RCX + 0x100) = *(undefined8 *)((int64_t)&arg_48h + iVar4);
        uVar6 = 1;
        *(undefined8 *)(in_RCX + 0xe8) = in_RDX;
        *(uint64_t *)(in_RCX + 0xf0) = in_R8;
        *(undefined8 *)(in_RCX + 0xf8) = in_R9;
    } else {
        uVar6 = 0;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_1802081b0
// Address: 0x1802081b0
// Size: 46 bytes
// ============================================================
undefined8 fcn.1802081b0(int64_t param_1, undefined4 *param_2)
{
    int16_t iVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    undefined (*pauVar6) [16];
    undefined8 uStack_8;
    
    uStack_8 = 0x1802081ba;
    iVar5 = fcn.18045a350();
    pauVar6 = (undefined (*) [16])(param_1 + 0x2c);
    if (param_2 == (undefined4 *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 - iVar5) = 0x1802081cb;
        fcn.18026be30();
        return 1;
    }
    if ((pauVar6 != (undefined (*) [16])0x0) && (param_2 != (undefined4 *)0x0)) {
        iVar1 = *(int16_t *)param_2;
        *pauVar6 = ZEXT816(0);
        *(undefined8 *)(param_1 + 0x3c) = 0;
        *(undefined4 *)(param_1 + 0x44) = 0;
        if (iVar1 != 0) {
            if (*(int16_t *)param_2 != 2) {
                if (*(int16_t *)param_2 != 0x17) {
                    return 0;
                }
                uVar2 = param_2[1];
                uVar3 = param_2[2];
                uVar4 = param_2[3];
                *(undefined4 *)*pauVar6 = *param_2;
                *(undefined4 *)(param_1 + 0x30) = uVar2;
                *(undefined4 *)(param_1 + 0x34) = uVar3;
                *(undefined4 *)(param_1 + 0x38) = uVar4;
                *(undefined8 *)(param_1 + 0x3c) = *(undefined8 *)(param_2 + 4);
                *(undefined4 *)(param_1 + 0x44) = param_2[6];
                return 1;
            }
            uVar2 = param_2[1];
            uVar3 = param_2[2];
            uVar4 = param_2[3];
            *(undefined4 *)*pauVar6 = *param_2;
            *(undefined4 *)(param_1 + 0x30) = uVar2;
            *(undefined4 *)(param_1 + 0x34) = uVar3;
            *(undefined4 *)(param_1 + 0x38) = uVar4;
        }
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1802081f0
// Address: 0x1802081f0
// Size: 29 bytes
// ============================================================
void fcn.1802081f0(int64_t param_1, undefined8 param_2, undefined8 param_3)
{
    fcn.18045a350();
    *(undefined8 *)(param_1 + 0x160) = param_2;
    *(undefined8 *)(param_1 + 0x168) = param_3;
    return;
}

// ============================================================
// Function: FUN_180208220
// Address: 0x180208220
// Size: 157 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180208220(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t *in_RCX;
    undefined8 in_RDX;
    int64_t iVar5;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020823a;
    iVar3 = fcn.18045a350();
    iVar5 = (uint64_t)*(uint32_t *)(in_RCX + 6) * 0x20 + *in_RCX;
    if (in_R8 == 0) {
code_r0x00018020829f:
        uVar4 = 1;
    } else {
        if ((*(uint8_t *)((int64_t)in_RCX + 0x34) & 2) == 0) {
            iVar1 = in_RCX[5];
            *(undefined8 *)((int64_t)&uStack_10 - iVar3) = 0x18020826e;
            iVar2 = func_0x0001802085d0(iVar5 + 0x1d8, iVar1 + 1);
            if (iVar2 != 0) {
                *(undefined8 *)(*(int64_t *)(iVar5 + 0x1e8) + in_RCX[5] * 0x10) = in_RDX;
                *(int64_t *)(*(int64_t *)(iVar5 + 0x1e8) + 8 + in_RCX[5] * 0x10) = in_R8;
                in_RCX[5] = in_RCX[5] + 1;
                in_RCX[2] = in_RCX[2] + in_R8;
                goto code_r0x00018020829f;
            }
        }
        uVar4 = 0;
    }
    return uVar4;
}

// ============================================================
// Function: FUN_1802082c0
// Address: 0x1802082c0
// Size: 191 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t * fcn.1802082c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *in_RCX;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802082da;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (((*(uint8_t *)(in_RCX + 0xf) & 1) == 0) && ((*(uint32_t *)((int64_t)in_RCX + 0x34) & 2) == 0)) {
        uVar6 = *(int64_t *)((uint64_t)*(uint32_t *)(in_RCX + 6) * 0x20 + 0x1e0 + *in_RCX) - in_RCX[3];
        iVar4 = *(int64_t *)((uint64_t)*(uint32_t *)(in_RCX + 6) * 0x20 + 0x1d8 + *in_RCX) + in_RCX[3];
        if ((*(uint32_t *)((int64_t)in_RCX + 0x34) & 1) == 0) {
            iVar3 = in_RCX[4];
        } else {
            iVar3 = 0;
        }
        uVar5 = (in_RCX[1] - in_RCX[2]) - iVar3;
        if (uVar5 <= uVar6) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020833d;
            iVar1 = func_0x000180244550(in_RCX + 8, iVar4, uVar6, 0);
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020834d;
                iVar1 = func_0x0001802449a0(in_RCX + 8, uVar5);
                if (iVar1 != 0) {
                    *(uint32_t *)(in_RCX + 0xf) = *(uint32_t *)(in_RCX + 0xf) | 1;
                    in_RCX[7] = iVar4;
                    return in_RCX + 8;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020835a;
                func_0x000180243fb0(in_RCX + 8);
            }
        }
    }
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_180208380
// Address: 0x180208380
// Size: 55 bytes
// ============================================================
undefined8
fcn.180208380(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_70h,
             int64_t arg_78h, int64_t arg_80h, int64_t arg_1c8h, int64_t arg_1d8h)
{
    uint8_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t *in_RCX;
    undefined4 uVar7;
    undefined8 unaff_RBP;
    int64_t iVar8;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar9;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18020838e;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar1 = *(uint8_t *)(in_RCX + 0xf);
    *(undefined8 *)((int64_t)&arg_70h + iVar5) = 0;
    if ((uVar1 & 1) == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1802083c5;
    iVar4 = fcn.1802442e0(in_RCX + 8, (int64_t)&arg_70h + iVar5);
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1802083d2;
        fcn.180243fb0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5));
        *(uint32_t *)(in_RCX + 0xf) = *(uint32_t *)(in_RCX + 0xf) & 0xfffffffe;
        in_RCX[7] = 0;
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_80h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RDI;
    uVar9 = *(uint64_t *)((int64_t)&arg_70h + iVar5);
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_R14;
    iVar2 = in_RCX[7];
    if (uVar9 == 0) {
code_r0x000180208470:
        if ((*(int64_t *)(*in_RCX + 600) == 0) || (uVar9 == 0)) {
code_r0x000180208549:
            in_RCX[3] = in_RCX[3] + uVar9;
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180208556;
            fcn.180244200(*(int64_t *)((int64_t)&var_10h + iVar5));
            *(uint32_t *)(in_RCX + 0xf) = *(uint32_t *)(in_RCX + 0xf) & 0xfffffffe;
            uVar6 = 1;
            goto code_r0x00018020855f;
        }
        uVar7 = 0x202;
        if (uVar9 < 0x8000000000000000) {
            *(int64_t *)((int64_t)&arg_30h + iVar5) = in_RCX[7];
            *(uint64_t *)((int64_t)&arg_38h + iVar5) = uVar9;
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1802084c0;
            iVar4 = fcn.1801feb70(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar5));
            if (iVar4 != 0) {
                uVar9 = *(uint64_t *)((int64_t)&arg_78h + iVar5);
                if (uVar9 == 0) {
                    uVar7 = 0x204;
                } else if (((uVar9 & 0xfffffffffffffff8) == 8) || (uVar9 == 6)) {
                    uVar7 = 0x203;
                }
                iVar2 = *in_RCX;
                iVar8 = in_RCX[7];
                pcVar3 = *(code **)(iVar2 + 600);
                *(undefined8 *)((int64_t)&var_20h + iVar5) = *(undefined8 *)(iVar2 + 0x260);
                *(undefined8 *)((int64_t)&var_18h + iVar5) = *(undefined8 *)(iVar2 + 0x268);
                *(undefined8 *)((int64_t)&var_10h + iVar5) = *(undefined8 *)((int64_t)&arg_70h + iVar5);
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180208541;
                (*pcVar3)(1, 1, uVar7, iVar8);
                uVar9 = *(uint64_t *)((int64_t)&arg_70h + iVar5);
                goto code_r0x000180208549;
            }
        }
    } else if ((*(uint8_t *)((int64_t)in_RCX + 0x34) & 2) == 0) {
        iVar8 = (uint64_t)*(uint32_t *)(in_RCX + 6) * 0x20 + *in_RCX;
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180208433;
        iVar4 = fcn.1802085d0(*(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000060 + iVar5));
        if (iVar4 != 0) {
            *(int64_t *)(*(int64_t *)(iVar8 + 0x1e8) + in_RCX[5] * 0x10) = iVar2;
            *(uint64_t *)(*(int64_t *)(iVar8 + 0x1e8) + 8 + in_RCX[5] * 0x10) = uVar9;
            in_RCX[5] = in_RCX[5] + 1;
            in_RCX[2] = in_RCX[2] + uVar9;
            uVar9 = *(uint64_t *)((int64_t)&arg_70h + iVar5);
            goto code_r0x000180208470;
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1802084e1;
    fcn.180243fb0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5));
    *(uint32_t *)(in_RCX + 0xf) = *(uint32_t *)(in_RCX + 0xf) & 0xfffffffe;
    uVar6 = 0;
code_r0x00018020855f:
    in_RCX[7] = 0;
    return uVar6;
}

// ============================================================
// Function: FUN_1802083b7
// Address: 0x1802083b7
// Size: 50 bytes
// ============================================================
undefined8
fcn.180208380(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_70h,
             int64_t arg_78h, int64_t arg_80h, int64_t arg_1c8h, int64_t arg_1d8h)
{
    uint8_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t *in_RCX;
    undefined4 uVar7;
    undefined8 unaff_RBP;
    int64_t iVar8;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar9;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18020838e;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar1 = *(uint8_t *)(in_RCX + 0xf);
    *(undefined8 *)((int64_t)&arg_70h + iVar5) = 0;
    if ((uVar1 & 1) == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1802083c5;
    iVar4 = fcn.1802442e0(in_RCX + 8, (int64_t)&arg_70h + iVar5);
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1802083d2;
        fcn.180243fb0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5));
        *(uint32_t *)(in_RCX + 0xf) = *(uint32_t *)(in_RCX + 0xf) & 0xfffffffe;
        in_RCX[7] = 0;
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_80h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RDI;
    uVar9 = *(uint64_t *)((int64_t)&arg_70h + iVar5);
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_R14;
    iVar2 = in_RCX[7];
    if (uVar9 == 0) {
code_r0x000180208470:
        if ((*(int64_t *)(*in_RCX + 600) == 0) || (uVar9 == 0)) {
code_r0x000180208549:
            in_RCX[3] = in_RCX[3] + uVar9;
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180208556;
            fcn.180244200(*(int64_t *)((int64_t)&var_10h + iVar5));
            *(uint32_t *)(in_RCX + 0xf) = *(uint32_t *)(in_RCX + 0xf) & 0xfffffffe;
            uVar6 = 1;
            goto code_r0x00018020855f;
        }
        uVar7 = 0x202;
        if (uVar9 < 0x8000000000000000) {
            *(int64_t *)((int64_t)&arg_30h + iVar5) = in_RCX[7];
            *(uint64_t *)((int64_t)&arg_38h + iVar5) = uVar9;
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1802084c0;
            iVar4 = fcn.1801feb70(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar5));
            if (iVar4 != 0) {
                uVar9 = *(uint64_t *)((int64_t)&arg_78h + iVar5);
                if (uVar9 == 0) {
                    uVar7 = 0x204;
                } else if (((uVar9 & 0xfffffffffffffff8) == 8) || (uVar9 == 6)) {
                    uVar7 = 0x203;
                }
                iVar2 = *in_RCX;
                iVar8 = in_RCX[7];
                pcVar3 = *(code **)(iVar2 + 600);
                *(undefined8 *)((int64_t)&var_20h + iVar5) = *(undefined8 *)(iVar2 + 0x260);
                *(undefined8 *)((int64_t)&var_18h + iVar5) = *(undefined8 *)(iVar2 + 0x268);
                *(undefined8 *)((int64_t)&var_10h + iVar5) = *(undefined8 *)((int64_t)&arg_70h + iVar5);
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180208541;
                (*pcVar3)(1, 1, uVar7, iVar8);
                uVar9 = *(uint64_t *)((int64_t)&arg_70h + iVar5);
                goto code_r0x000180208549;
            }
        }
    } else if ((*(uint8_t *)((int64_t)in_RCX + 0x34) & 2) == 0) {
        iVar8 = (uint64_t)*(uint32_t *)(in_RCX + 6) * 0x20 + *in_RCX;
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180208433;
        iVar4 = fcn.1802085d0(*(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000060 + iVar5));
        if (iVar4 != 0) {
            *(int64_t *)(*(int64_t *)(iVar8 + 0x1e8) + in_RCX[5] * 0x10) = iVar2;
            *(uint64_t *)(*(int64_t *)(iVar8 + 0x1e8) + 8 + in_RCX[5] * 0x10) = uVar9;
            in_RCX[5] = in_RCX[5] + 1;
            in_RCX[2] = in_RCX[2] + uVar9;
            uVar9 = *(uint64_t *)((int64_t)&arg_70h + iVar5);
            goto code_r0x000180208470;
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1802084e1;
    fcn.180243fb0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5));
    *(uint32_t *)(in_RCX + 0xf) = *(uint32_t *)(in_RCX + 0xf) & 0xfffffffe;
    uVar6 = 0;
code_r0x00018020855f:
    in_RCX[7] = 0;
    return uVar6;
}

// ============================================================
// Function: FUN_1802083e9
// Address: 0x1802083e9
// Size: 409 bytes
// ============================================================
undefined8
fcn.180208380(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_70h,
             int64_t arg_78h, int64_t arg_80h, int64_t arg_1c8h, int64_t arg_1d8h)
{
    uint8_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t *in_RCX;
    undefined4 uVar7;
    undefined8 unaff_RBP;
    int64_t iVar8;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar9;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18020838e;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar1 = *(uint8_t *)(in_RCX + 0xf);
    *(undefined8 *)((int64_t)&arg_70h + iVar5) = 0;
    if ((uVar1 & 1) == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1802083c5;
    iVar4 = fcn.1802442e0(in_RCX + 8, (int64_t)&arg_70h + iVar5);
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1802083d2;
        fcn.180243fb0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5));
        *(uint32_t *)(in_RCX + 0xf) = *(uint32_t *)(in_RCX + 0xf) & 0xfffffffe;
        in_RCX[7] = 0;
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_80h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RDI;
    uVar9 = *(uint64_t *)((int64_t)&arg_70h + iVar5);
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_R14;
    iVar2 = in_RCX[7];
    if (uVar9 == 0) {
code_r0x000180208470:
        if ((*(int64_t *)(*in_RCX + 600) == 0) || (uVar9 == 0)) {
code_r0x000180208549:
            in_RCX[3] = in_RCX[3] + uVar9;
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180208556;
            fcn.180244200(*(int64_t *)((int64_t)&var_10h + iVar5));
            *(uint32_t *)(in_RCX + 0xf) = *(uint32_t *)(in_RCX + 0xf) & 0xfffffffe;
            uVar6 = 1;
            goto code_r0x00018020855f;
        }
        uVar7 = 0x202;
        if (uVar9 < 0x8000000000000000) {
            *(int64_t *)((int64_t)&arg_30h + iVar5) = in_RCX[7];
            *(uint64_t *)((int64_t)&arg_38h + iVar5) = uVar9;
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1802084c0;
            iVar4 = fcn.1801feb70(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar5));
            if (iVar4 != 0) {
                uVar9 = *(uint64_t *)((int64_t)&arg_78h + iVar5);
                if (uVar9 == 0) {
                    uVar7 = 0x204;
                } else if (((uVar9 & 0xfffffffffffffff8) == 8) || (uVar9 == 6)) {
                    uVar7 = 0x203;
                }
                iVar2 = *in_RCX;
                iVar8 = in_RCX[7];
                pcVar3 = *(code **)(iVar2 + 600);
                *(undefined8 *)((int64_t)&var_20h + iVar5) = *(undefined8 *)(iVar2 + 0x260);
                *(undefined8 *)((int64_t)&var_18h + iVar5) = *(undefined8 *)(iVar2 + 0x268);
                *(undefined8 *)((int64_t)&var_10h + iVar5) = *(undefined8 *)((int64_t)&arg_70h + iVar5);
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180208541;
                (*pcVar3)(1, 1, uVar7, iVar8);
                uVar9 = *(uint64_t *)((int64_t)&arg_70h + iVar5);
                goto code_r0x000180208549;
            }
        }
    } else if ((*(uint8_t *)((int64_t)in_RCX + 0x34) & 2) == 0) {
        iVar8 = (uint64_t)*(uint32_t *)(in_RCX + 6) * 0x20 + *in_RCX;
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180208433;
        iVar4 = fcn.1802085d0(*(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000060 + iVar5));
        if (iVar4 != 0) {
            *(int64_t *)(*(int64_t *)(iVar8 + 0x1e8) + in_RCX[5] * 0x10) = iVar2;
            *(uint64_t *)(*(int64_t *)(iVar8 + 0x1e8) + 8 + in_RCX[5] * 0x10) = uVar9;
            in_RCX[5] = in_RCX[5] + 1;
            in_RCX[2] = in_RCX[2] + uVar9;
            uVar9 = *(uint64_t *)((int64_t)&arg_70h + iVar5);
            goto code_r0x000180208470;
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1802084e1;
    fcn.180243fb0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5));
    *(uint32_t *)(in_RCX + 0xf) = *(uint32_t *)(in_RCX + 0xf) & 0xfffffffe;
    uVar6 = 0;
code_r0x00018020855f:
    in_RCX[7] = 0;
    return uVar6;
}

// ============================================================
// Function: FUN_180208590
// Address: 0x180208590
// Size: 51 bytes
// ============================================================
void fcn.180208590(int64_t param_1)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020859c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if ((*(uint8_t *)(param_1 + 0x78) & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802085b1;
        fcn.180243fb0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1));
        *(uint32_t *)(param_1 + 0x78) = *(uint32_t *)(param_1 + 0x78) & 0xfffffffe;
        *(undefined8 *)(param_1 + 0x38) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1802085d0
// Address: 0x1802085d0
// Size: 38 bytes
// ============================================================
undefined8 fcn.1802085d0(int64_t arg_38h, int64_t arg_78h)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t iVar3;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802085dc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar1 = *(uint64_t *)(in_RCX + 0x18);
    if (in_RDX <= uVar1) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RBX;
    iVar3 = uVar1 * 2;
    if (uVar1 == 0) {
        iVar3 = 8;
    }
    *(undefined4 *)((int64_t)&iStackX_20 + iVar2 + -8) = 0xc5b;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020862a;
    iVar2 = fcn.180224f60(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                          *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)((int64_t)&arg_38h + iVar2), 
                          *(int64_t *)(&stack0x00000040 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                          *(int64_t *)(&stack0x00000068 + iVar2));
    if (iVar2 == 0) {
        return 0;
    }
    *(int64_t *)(in_RCX + 0x10) = iVar2;
    *(int64_t *)(in_RCX + 0x18) = iVar3;
    return 1;
}

// ============================================================
// Function: FUN_1802085f6
// Address: 0x1802085f6
// Size: 68 bytes
// ============================================================
undefined8 fcn.1802085d0(int64_t arg_38h, int64_t arg_78h)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t iVar3;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802085dc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar1 = *(uint64_t *)(in_RCX + 0x18);
    if (in_RDX <= uVar1) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RBX;
    iVar3 = uVar1 * 2;
    if (uVar1 == 0) {
        iVar3 = 8;
    }
    *(undefined4 *)((int64_t)&iStackX_20 + iVar2 + -8) = 0xc5b;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020862a;
    iVar2 = fcn.180224f60(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                          *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)((int64_t)&arg_38h + iVar2), 
                          *(int64_t *)(&stack0x00000040 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                          *(int64_t *)(&stack0x00000068 + iVar2));
    if (iVar2 == 0) {
        return 0;
    }
    *(int64_t *)(in_RCX + 0x10) = iVar2;
    *(int64_t *)(in_RCX + 0x18) = iVar3;
    return 1;
}

// ============================================================
// Function: FUN_18020863a
// Address: 0x18020863a
// Size: 24 bytes
// ============================================================
undefined8 fcn.1802085d0(int64_t arg_38h, int64_t arg_78h)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t iVar3;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802085dc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar1 = *(uint64_t *)(in_RCX + 0x18);
    if (in_RDX <= uVar1) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RBX;
    iVar3 = uVar1 * 2;
    if (uVar1 == 0) {
        iVar3 = 8;
    }
    *(undefined4 *)((int64_t)&iStackX_20 + iVar2 + -8) = 0xc5b;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020862a;
    iVar2 = fcn.180224f60(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                          *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)((int64_t)&arg_38h + iVar2), 
                          *(int64_t *)(&stack0x00000040 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                          *(int64_t *)(&stack0x00000068 + iVar2));
    if (iVar2 == 0) {
        return 0;
    }
    *(int64_t *)(in_RCX + 0x10) = iVar2;
    *(int64_t *)(in_RCX + 0x18) = iVar3;
    return 1;
}

// ============================================================
// Function: FUN_180208660
// Address: 0x180208660
// Size: 585 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180208660(int64_t arg_f0h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    uint64_t uVar6;
    undefined4 *in_R8;
    int64_t iVar7;
    int64_t aiStackX_8 [3];
    int64_t var_20h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_18h;
    
    var_40h = 0x18020867f;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    var_40h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar3);
    iVar2 = *(int32_t *)(in_RDX + 0x30);
    if (iVar2 == 0) {
        iVar7 = 0xd0;
    } else if ((iVar2 == 1) || (iVar2 != 2)) {
        iVar7 = 0xe0;
    } else {
        iVar7 = 0xd8;
    }
    var_b8h = *(int64_t *)(in_RDX + 0x88);
    var_90h = 0;
    iVar5 = 0;
    var_c0h = 0;
    _var_b0h = ZEXT816(0);
    _var_a0h = ZEXT816(0);
    var_d0h = 0;
    var_c8h = 0;
    _var_60h = ZEXT816(0);
    _var_50h = ZEXT816(0);
    while( true ) {
        if ((*(uint8_t *)(in_RDX + 0x34) & 1) == 0) {
            iVar4 = *(int64_t *)(in_RDX + 0x20);
        } else {
            iVar4 = 0;
        }
        if ((uint64_t)((*(int64_t *)(in_RDX + 8) - *(int64_t *)(in_RDX + 0x10)) - iVar4) < 4) goto code_r0x00018020887e;
        uVar1 = *(undefined8 *)(iVar7 + in_RCX);
        *(int64_t **)((int64_t)&var_18h + iVar3) = &var_d8h;
        var_d8h = 2;
        *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x18020873e;
        iVar2 = func_0x0001801e6230(uVar1, iVar5, &var_b0h, &var_80h);
        if (iVar2 == 0) goto code_r0x00018020887e;
        iVar5 = var_a0h;
        var_d0h = var_a8h;
        if (var_a0h == 0) goto code_r0x00018020887e;
        var_c8h = 0;
        *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x18020876c;
        iVar4 = func_0x0001801fe8b0(&var_d0h);
        var_c8h = iVar5;
        if (iVar4 == 0) goto code_r0x00018020887e;
        *(int64_t **)((int64_t)&var_18h + iVar3) = &var_c8h;
        *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x180208795;
        iVar2 = fcn.180206d90((int64_t)&var_88h, *(int64_t *)((int64_t)&var_18h + iVar3), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar3), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000000 + iVar3), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x10), *(int64_t *)(&stack0x00000028 + iVar3), 
                              *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3));
        if (iVar2 == 0) goto code_r0x00018020887e;
        *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x1802087ae;
        func_0x0001801e5f40(var_c8h, &var_80h, var_d8h);
        *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x1802087cc;
        iVar2 = fcn.1802085d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3));
        if (iVar2 == 0) goto code_r0x00018020887e;
        *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x1802087dc;
        iVar5 = fcn.1802082c0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)(&stack0xfffffffffffffff0 + iVar3), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar3));
        if (iVar5 == 0) goto code_r0x00018020887e;
        *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x1802087f1;
        iVar2 = func_0x0001801fe1a0(iVar5, &var_d0h);
        if (iVar2 == 0) break;
        *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x1802087fd;
        iVar2 = fcn.180208380(*(int64_t *)(&stack0xfffffffffffffff0 + iVar3), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000000 + iVar3), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                              *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                              *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000188 + iVar3), 
                              *(int64_t *)(&stack0x00000198 + iVar3));
        if (iVar2 == 0) goto code_r0x00018020887e;
        uVar6 = 0;
        if (var_d8h != 0) {
            do {
                *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x180208820;
                fcn.180208220(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)(&stack0xfffffffffffffff0 + iVar3), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar3));
                uVar6 = uVar6 + 1;
            } while (uVar6 < (uint64_t)var_d8h);
        }
        var_48h._0_4_ = (uint32_t)var_48h & 0xfffffffe;
        var_50h = var_d0h + var_c8h + -1;
        *in_R8 = 1;
        *(uint32_t *)(in_RDX + 0x34) = *(uint32_t *)(in_RDX + 0x34) | 1;
        var_58h = var_d0h;
        var_60h = 0xffffffffffffffff;
        *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x180208868;
        iVar2 = func_0x000180203c60(var_b8h, &var_60h);
        if (iVar2 == 0) goto code_r0x00018020887e;
        iVar5 = uVar6 + 1;
    }
    *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x180208879;
    fcn.180208590(in_RDX);
code_r0x00018020887e:
    uVar6 = var_40h ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar3);
    *(undefined8 *)((int64_t)&var_40h + iVar3) = 0x18020888a;
    func_0x000180459870(uVar6);
    return;
}

// ============================================================
// Function: FUN_1802088b0
// Address: 0x1802088b0
// Size: 1540 bytes
// ============================================================
undefined8
fcn.1802088b0(int64_t placeholder_0, int64_t placeholder_1, int64_t arg3, int64_t arg_50h, int64_t arg_58h,
             int64_t arg_60h, int64_t arg_68h)
{
    code *pcVar1;
    uint32_t uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    uint32_t uVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    int64_t iVar12;
    undefined8 unaff_RDI;
    undefined8 unaff_R13;
    uint32_t uVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_38;
    
    var_18h._0_4_ = (undefined4)arg3;
    uStack_38 = 0x1802088c8;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar3 = *(int32_t *)(placeholder_1 + 0x30);
    uVar11 = 0;
    if (iVar3 != 0) {
        if ((iVar3 == 1) || (iVar3 != 2)) {
            uVar11 = 2;
        } else {
            uVar11 = 1;
        }
    }
    uVar5 = *(uint32_t *)(placeholder_1 + 0x114);
    uVar14 = 0;
    *(undefined4 *)((int64_t)&arg_50h + iVar6) = 0;
    *(undefined4 *)((int64_t)&arg_68h + iVar6) = 0;
    *(undefined8 *)((int64_t)&var_10h + iVar6) = unaff_RDI;
    *(int32_t *)((int64_t)&arg_58h + iVar6) = (int32_t)uVar11;
    *(undefined8 *)((int64_t)&var_8h + iVar6) = unaff_R13;
    *(undefined4 *)(&stack0xfffffffffffffff0 + iVar6) = 1;
    if (0x3fffffffffffffff < *(uint64_t *)(placeholder_0 + 0x170 + uVar11 * 8)) {
        return 0;
    }
    if (*(int64_t *)(placeholder_1 + 0x88) != 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208955;
    puVar7 = (undefined8 *)func_0x000180203b30();
    *(undefined8 **)(placeholder_1 + 0x88) = puVar7;
    if (puVar7 == (undefined8 *)0x0) {
        return 0;
    }
    uVar15 = 0;
    if (((uVar5 & 8) != 0) && (uVar15 = uVar14, (*(uint8_t *)(placeholder_0 + 0x198) & 1) != 0)) {
        if ((*(uint8_t *)(placeholder_1 + 0x34) & 1) == 0) {
            iVar8 = *(int64_t *)(placeholder_1 + 0x20);
        } else {
            iVar8 = 0;
        }
        if (*(int64_t *)(placeholder_1 + 8) - *(int64_t *)(placeholder_1 + 0x10) != iVar8) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x18020899d;
            iVar8 = fcn.1802082c0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6)
                                 );
            if (iVar8 == 0) goto code_r0x000180208e7a;
            *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1802089ae;
            iVar3 = func_0x0001801fe210(iVar8);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1802089da;
                fcn.180208590();
            } else {
                *(uint32_t *)((int64_t)puVar7 + 0x7c) = *(uint32_t *)((int64_t)puVar7 + 0x7c) | 1;
                *(undefined4 *)((int64_t)&arg_50h + iVar6) = 1;
                *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1802089c8;
                iVar3 = fcn.180208380(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                      *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6), 
                                      *(int64_t *)(&stack0x00000048 + iVar6), *(int64_t *)(&stack0x00000190 + iVar6), 
                                      *(int64_t *)(&stack0x000001a0 + iVar6));
                if (iVar3 == 0) goto code_r0x000180208e7a;
                *(uint32_t *)(placeholder_1 + 0x34) = *(uint32_t *)(placeholder_1 + 0x34) | 1;
                uVar15 = 1;
            }
        }
    }
    if ((uVar5 >> 9 & 1) != 0) {
        if ((*(uint8_t *)(placeholder_0 + 0x198) & 2) == 0) {
            uVar9 = *(undefined8 *)(placeholder_0 + 0x80);
            *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1802089fc;
            iVar3 = func_0x0001801e59a0(uVar9, 0);
            if (iVar3 != 0) goto code_r0x000180208a00;
        } else {
code_r0x000180208a00:
            if ((*(uint8_t *)(placeholder_1 + 0x34) & 1) == 0) {
                iVar8 = *(int64_t *)(placeholder_1 + 0x20);
            } else {
                iVar8 = 0;
            }
            if (1 < (uint64_t)((*(int64_t *)(placeholder_1 + 8) - *(int64_t *)(placeholder_1 + 0x10)) - iVar8)) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208a27;
                iVar8 = fcn.1802082c0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)(&stack0x00000000 + iVar6));
                uVar9 = *(undefined8 *)(placeholder_0 + 0x80);
                *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208a36;
                uVar9 = func_0x00018001ed90(uVar9);
                if (iVar8 == 0) goto code_r0x000180208e7a;
                *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208a4a;
                iVar3 = func_0x0001801fe230(iVar8, uVar9);
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208a77;
                    fcn.180208590();
                } else {
                    *(uint32_t *)((int64_t)puVar7 + 0x7c) = *(uint32_t *)((int64_t)puVar7 + 0x7c) | 2;
                    uVar15 = 1;
                    *(undefined4 *)((int64_t)&arg_50h + iVar6) = 1;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208a65;
                    iVar3 = fcn.180208380(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                          *(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6)
                                          , *(int64_t *)((int64_t)&var_10h + iVar6), 
                                          *(int64_t *)((int64_t)&var_18h + iVar6), 
                                          *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6)
                                          , *(int64_t *)(&stack0x00000048 + iVar6), 
                                          *(int64_t *)(&stack0x00000190 + iVar6), *(int64_t *)(&stack0x000001a0 + iVar6)
                                         );
                    if (iVar3 == 0) goto code_r0x000180208e7a;
                    *(uint32_t *)(placeholder_1 + 0x34) = *(uint32_t *)(placeholder_1 + 0x34) | 1;
                }
            }
        }
        if ((*(uint8_t *)(placeholder_0 + 0x198) & 4) == 0) {
            uVar9 = *(undefined8 *)(placeholder_0 + 0x88);
            *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208a8f;
            iVar3 = func_0x0001801e59a0(uVar9, 0);
            if (iVar3 != 0) goto code_r0x000180208a93;
        } else {
code_r0x000180208a93:
            if ((*(uint8_t *)(placeholder_1 + 0x34) & 1) == 0) {
                iVar8 = *(int64_t *)(placeholder_1 + 0x20);
            } else {
                iVar8 = 0;
            }
            if (1 < (uint64_t)((*(int64_t *)(placeholder_1 + 8) - *(int64_t *)(placeholder_1 + 0x10)) - iVar8)) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208aba;
                iVar8 = fcn.1802082c0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)(&stack0x00000000 + iVar6));
                uVar9 = *(undefined8 *)(placeholder_0 + 0x88);
                *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208ac9;
                uVar9 = func_0x00018001ed90(uVar9);
                if (iVar8 == 0) goto code_r0x000180208e7a;
                *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208adf;
                iVar3 = func_0x0001801fe310(iVar8, 0, uVar9);
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208b0c;
                    fcn.180208590();
                } else {
                    *(uint32_t *)((int64_t)puVar7 + 0x7c) = *(uint32_t *)((int64_t)puVar7 + 0x7c) | 4;
                    uVar15 = 1;
                    *(undefined4 *)((int64_t)&arg_50h + iVar6) = 1;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208afa;
                    iVar3 = fcn.180208380(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                          *(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6)
                                          , *(int64_t *)((int64_t)&var_10h + iVar6), 
                                          *(int64_t *)((int64_t)&var_18h + iVar6), 
                                          *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6)
                                          , *(int64_t *)(&stack0x00000048 + iVar6), 
                                          *(int64_t *)(&stack0x00000190 + iVar6), *(int64_t *)(&stack0x000001a0 + iVar6)
                                         );
                    if (iVar3 == 0) goto code_r0x000180208e7a;
                    *(uint32_t *)(placeholder_1 + 0x34) = *(uint32_t *)(placeholder_1 + 0x34) | 1;
                }
            }
        }
        if ((*(uint8_t *)(placeholder_0 + 0x198) & 8) == 0) {
            uVar9 = *(undefined8 *)(placeholder_0 + 0x90);
            *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208b24;
            iVar3 = func_0x0001801e59a0(uVar9, 0);
            if (iVar3 == 0) goto code_r0x000180208ba3;
        }
        if ((*(uint8_t *)(placeholder_1 + 0x34) & 1) == 0) {
            iVar8 = *(int64_t *)(placeholder_1 + 0x20);
        } else {
            iVar8 = 0;
        }
        if (1 < (uint64_t)((*(int64_t *)(placeholder_1 + 8) - *(int64_t *)(placeholder_1 + 0x10)) - iVar8)) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208b4f;
            iVar8 = fcn.1802082c0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6)
                                 );
            uVar9 = *(undefined8 *)(placeholder_0 + 0x90);
            *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208b5e;
            uVar9 = func_0x00018001ed90(uVar9);
            if (iVar8 == 0) goto code_r0x000180208e7a;
            *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208b76;
            iVar3 = func_0x0001801fe310(iVar8, 1, uVar9);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208ba3;
                fcn.180208590(placeholder_1);
            } else {
                *(uint32_t *)((int64_t)puVar7 + 0x7c) = *(uint32_t *)((int64_t)puVar7 + 0x7c) | 8;
                uVar15 = 1;
                *(undefined4 *)((int64_t)&arg_50h + iVar6) = 1;
                *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208b91;
                iVar3 = fcn.180208380(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                      *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6), 
                                      *(int64_t *)(&stack0x00000048 + iVar6), *(int64_t *)(&stack0x00000190 + iVar6), 
                                      *(int64_t *)(&stack0x000001a0 + iVar6));
                if (iVar3 == 0) goto code_r0x000180208e7a;
                *(uint32_t *)(placeholder_1 + 0x34) = *(uint32_t *)(placeholder_1 + 0x34) | 1;
            }
        }
    }
code_r0x000180208ba3:
    uVar13 = (uint32_t)uVar15;
    uVar9 = *(undefined8 *)(placeholder_0 + 0x60);
    *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208baf;
    iVar8 = func_0x000180201e80(uVar9);
    if (iVar8 == 0) {
code_r0x000180208d1d:
        *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208d35;
        func_0x000180208ec0(placeholder_0, placeholder_1, *(undefined4 *)((int64_t)&arg_60h + iVar6), 
                            &stack0xfffffffffffffff0 + iVar6);
    } else {
        do {
            uVar13 = (uint32_t)uVar15;
            *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208bc8;
            iVar10 = func_0x0001801e8e30(iVar8);
            *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208bd3;
            uVar9 = func_0x0001801dd170(iVar8);
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar6) = uVar9;
            *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208be0;
            uVar11 = func_0x000180201ea0(iVar8);
            if (iVar10 == 7) {
                if ((uVar5 >> 0xc & 1) != 0) {
                    if (*(int32_t *)((int64_t)&arg_68h + iVar6) == 0) {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208c62;
                        iVar3 = func_0x000180208ec0(placeholder_0, placeholder_1, 
                                                    *(undefined4 *)((int64_t)&arg_60h + iVar6), 
                                                    &stack0xfffffffffffffff0 + iVar6);
                        uVar4 = *(undefined4 *)((int64_t)&arg_68h + iVar6);
                        if (iVar3 != 0) {
                            uVar4 = 1;
                        }
                        *(undefined4 *)((int64_t)&arg_68h + iVar6) = uVar4;
                    }
                    goto code_r0x000180208c7a;
                }
                goto code_r0x000180208cea;
            }
            if (iVar10 == 0x18) {
                uVar2 = uVar5 & 0x40;
joined_r0x000180208c2e:
                if (uVar2 != 0) {
code_r0x000180208c7a:
                    if ((*(uint8_t *)(placeholder_1 + 0x34) & 1) == 0) {
                        iVar12 = *(int64_t *)(placeholder_1 + 0x20);
                    } else {
                        iVar12 = 0;
                    }
                    if ((uint64_t)((*(int64_t *)(placeholder_1 + 8) - *(int64_t *)(placeholder_1 + 0x10)) - iVar12) <
                        uVar11) {
                        uVar2 = *(uint32_t *)((int64_t)&arg_58h + iVar6);
                        break;
                    }
                    *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208ca8;
                    iVar3 = fcn.180208220(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                          *(int64_t *)(&stack0x00000000 + iVar6));
                    if (iVar3 == 0) goto code_r0x000180208e7a;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208cbb;
                    func_0x000180203b10(puVar7, iVar8);
                    if ((((iVar10 != 0) && (iVar10 != 2)) && (iVar10 != 3)) && ((iVar10 != 0x1c && (iVar10 != 0x1d)))) {
                        *(uint32_t *)(placeholder_1 + 0x34) = *(uint32_t *)(placeholder_1 + 0x34) | 1;
                        uVar15 = 1;
                        *(undefined4 *)((int64_t)&arg_50h + iVar6) = 1;
                    }
                }
            } else if (iVar10 == 0x19) {
                if ((char)uVar5 < '\0') goto code_r0x000180208c7a;
            } else {
                if (iVar10 != 0x1b) {
                    uVar2 = uVar5 >> 0xb & 1;
                    goto joined_r0x000180208c2e;
                }
                if ((uVar5 & 0x20) != 0) {
                    *(undefined4 *)(placeholder_1 + 0x118) = 1;
                    goto code_r0x000180208c7a;
                }
            }
code_r0x000180208cea:
            uVar13 = (uint32_t)uVar15;
            uVar2 = *(uint32_t *)((int64_t)&arg_58h + iVar6);
            *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208cfd;
            iVar8 = func_0x000180201eb0(iVar8);
        } while (iVar8 != 0);
        uVar11 = (uint64_t)uVar2;
        if (*(int32_t *)((int64_t)&arg_68h + iVar6) == 0) goto code_r0x000180208d1d;
    }
    if ((uVar5 & 4) != 0) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208d4e;
        iVar3 = fcn.180208660(*(int64_t *)(&stack0x000000b8 + iVar6));
        if (iVar3 == 0) goto code_r0x000180208e7a;
        uVar13 = *(uint32_t *)((int64_t)&arg_50h + iVar6);
    }
    if (((uVar5 >> 8 & 1) != 0) && ((*(uint32_t *)(placeholder_0 + 0x198) & 0x800) != 0)) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208d8b;
        iVar3 = func_0x0001802097b0(placeholder_0, placeholder_1, (int64_t)&arg_50h + iVar6, placeholder_1 + 0x90);
        if (iVar3 == 0) goto code_r0x000180208e7a;
        uVar13 = *(uint32_t *)((int64_t)&arg_50h + iVar6);
    }
    *(uint32_t *)(placeholder_1 + 0x34) = *(uint32_t *)(placeholder_1 + 0x34) | 1;
    if (uVar13 == 0) {
        if (((uVar5 & 2) == 0) ||
           (((uVar5 >> 0xf & 1) == 0 &&
            ((*(uint32_t *)(placeholder_0 + 0x198) >> 7 & 1 << ((uint8_t)uVar11 & 0x1f) & 7) == 0)))) {
            iVar3 = *(int32_t *)(&stack0xfffffffffffffff0 + iVar6);
            goto code_r0x000180208e07;
        }
        *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208ddd;
        iVar8 = fcn.1802082c0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        if (iVar8 == 0) {
code_r0x000180208e7a:
            uVar9 = *(undefined8 *)(placeholder_0 + 0x58);
            *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208e86;
            func_0x000180203dd0(uVar9, puVar7);
            *(undefined8 *)(placeholder_1 + 0x88) = 0;
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208dee;
        iVar3 = func_0x0001801fe460(iVar8);
        if (iVar3 == 0) goto code_r0x000180208e7a;
        *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208dfe;
        iVar3 = fcn.180208380(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                              *(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                              *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                              *(int64_t *)(&stack0x00000190 + iVar6), *(int64_t *)(&stack0x000001a0 + iVar6));
        if (iVar3 == 0) goto code_r0x000180208e7a;
        uVar13 = 1;
    }
    iVar3 = 0;
code_r0x000180208e07:
    puVar7[1] = *(int64_t *)(placeholder_1 + 0x108) + *(int64_t *)(placeholder_1 + 0x10);
    *puVar7 = *(undefined8 *)(placeholder_0 + 0x170 + uVar11 * 8);
    uVar5 = 0;
    if (iVar3 == 0) {
        uVar5 = 4;
    }
    *(uint32_t *)(puVar7 + 4) =
         (*(uint32_t *)(puVar7 + 4) & 0xfffffffc | (uint32_t)uVar11) & 0xffffffc3 | uVar5 | (uVar13 & 1) << 3;
    pcVar1 = *(code **)(placeholder_0 + 0xa8);
    uVar9 = *(undefined8 *)(placeholder_0 + 0xb0);
    *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x180208e67;
    uVar9 = (*pcVar1)(uVar9);
    puVar7[2] = uVar9;
    *(undefined *)(puVar7 + 0xf) = *(undefined *)(placeholder_1 + 0x98);
    return 1;
}

// ============================================================
// Function: FUN_180208ec0
// Address: 0x180208ec0
// Size: 628 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_7ch because it doesn't fit into ProtoModel

undefined8
fcn.180208ec0(int64_t arg_30h, int64_t arg_40h, int64_t arg_50h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h)
{
    undefined4 uVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t *piVar9;
    int64_t iVar10;
    undefined8 uVar11;
    int64_t in_RCX;
    int64_t in_RDX;
    uint8_t *puVar12;
    int8_t iVar13;
    int32_t in_R8D;
    uint64_t uVar14;
    undefined4 *in_R9;
    undefined8 unaff_R14;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x180208ed6;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar7 = *(int32_t *)(in_RDX + 0x30);
    if (iVar7 == 0) {
        iVar13 = 0;
    } else if ((iVar7 == 1) || (iVar7 != 2)) {
        iVar13 = 2;
    } else {
        iVar13 = 1;
    }
    iVar2 = *(int64_t *)(in_RDX + 0x88);
    *(undefined8 *)((int64_t)&arg_88h + iVar8) = unaff_R14;
    *(undefined8 *)(iVar2 + 0x18) = 0xffffffffffffffff;
    if ((*(uint8_t *)(in_RDX + 0x114) & 1) == 0) {
code_r0x00018020902c:
        if ((((*(uint32_t *)(in_RDX + 0x114) & 0x400) != 0) && ((*(uint32_t *)(in_RCX + 0x198) & 0x400) != 0)) &&
           (in_R8D != 0)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18020905d;
            iVar10 = fcn.1802082c0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                                   *(int64_t *)((int64_t)&iStackX_8 + iVar8));
            puVar12 = (uint8_t *)(in_RCX + 0x1a0);
            if (iVar10 == 0) goto code_r0x000180209130;
            if ((iVar13 != 2) && ((*puVar12 & 1) != 0)) {
                *(uint32_t *)((int64_t)&var_8h + iVar8) = *(uint32_t *)((int64_t)&var_8h + iVar8) & 0xfffffffe;
                puVar12 = (uint8_t *)((int64_t)&var_8h + iVar8);
                *(undefined8 *)((int64_t)&iStackX_8 + iVar8) = 0;
                *(undefined (*) [16])((int64_t)&var_10h + iVar8) = ZEXT816(0);
                *(undefined8 *)(&stack0x00000000 + iVar8) = 0xc;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1802090a7;
            iVar7 = func_0x0001801fe100(iVar10, puVar12);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1802090bb;
                iVar7 = fcn.1802442e0(iVar10, (int64_t)&arg_90h + iVar8);
                if (iVar7 != 0) {
                    if (*(int64_t *)(in_RCX + 0x1c8) != 0) {
                        uVar14 = *(int64_t *)(in_RCX + 0x1d0) + *(int64_t *)((int64_t)&arg_90h + iVar8);
                        if ((uint64_t)(*(int64_t *)(in_RCX + 0x1c8) * 3) < uVar14) goto code_r0x000180209126;
                        *(uint64_t *)(in_RCX + 0x1d0) = uVar14;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1802090f2;
                    iVar7 = fcn.180208380(*(int64_t *)(&stack0x00000000 + iVar8), 
                                          *(int64_t *)((int64_t)&iStackX_8 + iVar8), 
                                          *(int64_t *)((int64_t)&var_10h + iVar8), 
                                          *(int64_t *)((int64_t)&var_18h + iVar8), 
                                          *(int64_t *)((int64_t)&var_20h + iVar8), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar8), 
                                          *(int64_t *)(&stack0x00000048 + iVar8), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar8), 
                                          *(int64_t *)(&stack0x00000198 + iVar8), *(int64_t *)(&stack0x000001a8 + iVar8)
                                         );
                    if (iVar7 != 0) {
                        *(uint32_t *)(iVar2 + 0x7c) = *(uint32_t *)(iVar2 + 0x7c) | 0x20;
                        *in_R9 = 0;
                        goto code_r0x000180209102;
                    }
                    goto code_r0x000180209130;
                }
            }
code_r0x000180209126:
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18020912e;
            fcn.180208590(in_RDX);
        }
code_r0x000180209102:
        uVar11 = 1;
    } else {
        if ((*(uint8_t *)(in_RDX + 0x34) & 1) == 0) {
            iVar10 = *(int64_t *)(in_RDX + 0x20);
        } else {
            iVar10 = 0;
        }
        if ((uint64_t)((*(int64_t *)(in_RDX + 8) - *(int64_t *)(in_RDX + 0x10)) - iVar10) < 5)
        goto code_r0x00018020902c;
        if ((*(uint32_t *)(in_RCX + 0x198) >> 4 & 1 << iVar13 & 7) == 0) {
            uVar11 = *(undefined8 *)(in_RCX + 0x68);
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x180208f71;
            iVar7 = func_0x000180202940(uVar11, iVar13);
            if (iVar7 == 0) goto code_r0x00018020902c;
        }
        uVar11 = *(undefined8 *)(in_RCX + 0x68);
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x180208f84;
        piVar9 = (int64_t *)func_0x0001802026f0(uVar11, iVar13);
        if (piVar9 == (int64_t *)0x0) goto code_r0x00018020902c;
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x180208f98;
        iVar10 = fcn.1802082c0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                               *(int64_t *)((int64_t)&iStackX_8 + iVar8));
        if (iVar10 != 0) {
            uVar4 = *(undefined4 *)((int64_t)piVar9 + 4);
            uVar5 = *(undefined4 *)(piVar9 + 1);
            uVar6 = *(undefined4 *)((int64_t)piVar9 + 0xc);
            uVar1 = *(undefined4 *)(in_RCX + 0x48);
            *(undefined4 *)((int64_t)&var_20h + iVar8) = *(undefined4 *)piVar9;
            *(undefined4 *)((int64_t)&var_20h + iVar8 + 4) = uVar4;
            *(undefined4 *)(&stack0x00000028 + iVar8) = uVar5;
            *(undefined4 *)(&stack0x0000002c + iVar8) = uVar6;
            uVar4 = *(undefined4 *)((int64_t)piVar9 + 0x14);
            uVar5 = *(undefined4 *)(piVar9 + 3);
            uVar6 = *(undefined4 *)((int64_t)piVar9 + 0x1c);
            *(undefined4 *)((int64_t)&arg_30h + iVar8) = *(undefined4 *)(piVar9 + 2);
            *(undefined4 *)((int64_t)&arg_30h + iVar8 + 4) = uVar4;
            *(undefined4 *)(&stack0x00000038 + iVar8) = uVar5;
            *(undefined4 *)(&stack0x0000003c + iVar8) = uVar6;
            uVar4 = *(undefined4 *)((int64_t)piVar9 + 0x24);
            uVar5 = *(undefined4 *)(piVar9 + 5);
            uVar6 = *(undefined4 *)((int64_t)piVar9 + 0x2c);
            *(undefined4 *)((int64_t)&arg_40h + iVar8) = *(undefined4 *)(piVar9 + 4);
            *(undefined4 *)((int64_t)&arg_40h + iVar8 + 4) = uVar4;
            *(undefined4 *)(&stack0x00000048 + iVar8) = uVar5;
            *(undefined4 *)(&stack0x0000004c + iVar8) = uVar6;
            *(int64_t *)((int64_t)&arg_50h + iVar8) = piVar9[6];
            *(uint32_t *)((int64_t)&arg_50h + iVar8) = *(uint32_t *)((int64_t)&arg_50h + iVar8) & 0xfffffffe;
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x180208fdf;
            iVar7 = func_0x0001801fdf70(iVar10, uVar1, (int64_t)&var_20h + iVar8);
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18020902c;
                fcn.180208590(in_RDX);
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x180208feb;
                iVar7 = fcn.180208380(*(int64_t *)(&stack0x00000000 + iVar8), *(int64_t *)((int64_t)&iStackX_8 + iVar8)
                                      , *(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8)
                                      , *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)((int64_t)&arg_40h + iVar8)
                                      , *(int64_t *)(&stack0x00000048 + iVar8), *(int64_t *)((int64_t)&arg_50h + iVar8)
                                      , *(int64_t *)(&stack0x00000198 + iVar8), *(int64_t *)(&stack0x000001a8 + iVar8));
                if (iVar7 == 0) goto code_r0x000180209130;
                *(uint32_t *)(iVar2 + 0x7c) = *(uint32_t *)(iVar2 + 0x7c) | 0x10;
                if (piVar9[1] != 0) {
                    *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(*piVar9 + 8);
                }
                pcVar3 = *(code **)(in_RCX + 0x270);
                if (pcVar3 != (code *)0x0) {
                    uVar11 = *(undefined8 *)(in_RCX + 0x278);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x180209025;
                    (*pcVar3)((int64_t)&var_20h + iVar8, iVar13, uVar11);
                }
            }
            goto code_r0x00018020902c;
        }
code_r0x000180209130:
        uVar11 = 0;
    }
    return uVar11;
}

// ============================================================
// Function: FUN_180209140
// Address: 0x180209140
// Size: 1636 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180209140(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_1b8h)
{
    uint32_t uVar1;
    undefined8 uVar2;
    uint64_t uVar3;
    undefined4 *puVar4;
    bool bVar5;
    int64_t iVar6;
    int64_t iVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined8 in_RCX;
    int64_t in_RDX;
    int64_t iVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    uint64_t *puVar17;
    uint64_t in_R8;
    uint64_t uVar18;
    undefined8 in_R9;
    uint64_t uVar19;
    uint64_t uVar20;
    uint64_t uVar21;
    uint64_t *puVar22;
    uint64_t uVar23;
    uint64_t uVar24;
    bool bVar25;
    bool bVar26;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    uint64_t auStack_100 [3];
    uint32_t auStack_e8 [2];
    int64_t var_e0h;
    undefined auStack_d8 [32];
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_48h;
    undefined8 uStack_40;
    int64_t var_8h;
    
    uStack_40 = 0x180209162;
    iVar10 = fcn.18045a350();
    iVar6 = arg_38h;
    iVar11 = arg_28h;
    iVar10 = -iVar10;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar10);
    *(int64_t *)((int64_t)&var_18h + iVar10) = arg_40h;
    iVar7 = arg_48h;
    uVar24 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar10) = in_RCX;
    *(undefined8 *)((int64_t)&arg_38h + iVar10) = in_R9;
    *(int64_t *)((int64_t)&arg_30h + iVar10) = iVar11;
    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1802091cb;
    fcn.1804986e0(&var_108h, 0, 0xc0);
    *(undefined4 *)((int64_t)&arg_28h + iVar10) = *(undefined4 *)(in_RDX + 0x30);
    uVar2 = *(undefined8 *)(in_RDX + 0x88);
    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1802091e6;
    iVar11 = func_0x0001801bc820(iVar11);
    *(int64_t *)((int64_t)&var_10h + iVar10) = iVar11;
    uVar14 = uVar24;
    do {
        iVar12 = uVar14 * 0xc;
        *(int64_t *)((int64_t)&var_8h + iVar10) = arg_50h;
        *(uint64_t **)(&stack0xfffffffffffffff0 + iVar10) = auStack_100 + iVar12 + -1;
        *(uint64_t *)(&stack0xffffffffffffffe8 + iVar10) = uVar14;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x18020923a;
        iVar8 = func_0x00018020a1f0(in_RCX, in_RDX, *(undefined8 *)((int64_t)&arg_38h + iVar10), 
                                    *(undefined8 *)((int64_t)&arg_30h + iVar10));
        iVar13 = iVar11;
        if ((iVar8 == 0) || ((uVar14 == 0 && ((int32_t)var_b0h == 0)))) goto code_r0x00018020976c;
        uVar14 = uVar14 + 1;
        auStack_100[iVar12 + -1] = in_R8;
        uVar23 = uVar24;
    } while (uVar14 < 2);
    while( true ) {
        uVar14 = uVar24;
        if ((*(uint32_t *)(in_RDX + 0x34) & 1) == 0) {
            uVar14 = *(uint64_t *)(in_RDX + 0x20);
        }
        uVar15 = (*(int64_t *)(in_RDX + 8) - uVar14) - *(int64_t *)(in_RDX + 0x10);
        uVar9 = (uint32_t)uVar23;
        uVar14 = (uint64_t)(uVar9 & 1);
        if (*(int32_t *)(&var_b0h + uVar14 * 0xc) == 0) goto code_r0x000180209767;
        if (uVar15 < 3) break;
        if ((*(uint32_t *)(in_RDX + 0x34) & 2) != 0) goto code_r0x000180209767;
        uVar3 = *(uint64_t *)(auStack_d8 + uVar14 * 0x60 + -8);
        puVar17 = auStack_100 + uVar14 * 0xc + -1;
        if (uVar23 != 0) {
            *(int64_t *)((int64_t)&var_8h + iVar10) = arg_50h;
            *(uint64_t **)(&stack0xfffffffffffffff0 + iVar10) =
                 auStack_100 + (uint64_t)((uint32_t)(uVar23 + 1) & 1) * 0xc + -1;
            *(uint64_t *)(&stack0xffffffffffffffe8 + iVar10) = uVar23 + 1;
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x180209306;
            iVar8 = func_0x00018020a1f0(*(undefined8 *)((int64_t)&arg_40h + iVar10), in_RDX, 
                                        *(undefined8 *)((int64_t)&arg_38h + iVar10), 
                                        *(undefined8 *)((int64_t)&arg_30h + iVar10));
            if (iVar8 == 0) goto code_r0x000180209767;
        }
        uVar16 = auStack_100[uVar14 * 0xc + 1];
        auStack_e8[uVar14 * 0x18] = auStack_e8[uVar14 * 0x18] & 0xfffffffe;
        auStack_100[uVar14 * 0xc + 1] = 0;
        *(undefined8 *)((int64_t)&var_20h + iVar10) = 0;
        *(undefined8 *)((int64_t)&iStackX_8 + iVar10) = 0;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x18020932c;
        iVar12 = func_0x0001801fe950(puVar17);
        auStack_100[uVar14 * 0xc + 1] = uVar16;
        if (iVar12 == 0) break;
        *(int64_t *)(&stack0xffffffffffffffe8 + iVar10) = (int64_t)&var_20h + iVar10;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x18020935f;
        iVar8 = fcn.180206d90((int64_t)&iStackX_8 + iVar10, *(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                              *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)&var_18h + iVar10), 
                              *(int64_t *)((int64_t)&arg_28h + iVar10), *(int64_t *)((int64_t)&arg_30h + iVar10), 
                              *(int64_t *)((int64_t)&arg_38h + iVar10));
        if (iVar8 == 0) break;
        uVar16 = *(uint64_t *)((int64_t)&var_20h + iVar10);
        if ((arg_30h != 0) || (bVar25 = false, *(int32_t *)(&var_b0h + (uint64_t)(uVar9 - 1 & 1) * 0xc) != 0)) {
            bVar25 = true;
        }
        if (((*(int64_t *)((int64_t)&iStackX_8 + iVar10) + uVar16 < uVar15) && (bVar25)) ||
           (*(int32_t *)(in_RDX + 0x118) != 0)) {
            uVar16 = auStack_100[uVar14 * 0xc + 1];
            auStack_e8[uVar14 * 0x18] = auStack_e8[uVar14 * 0x18] | 1;
            auStack_100[uVar14 * 0xc + 1] = 0;
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1802093e6;
            iVar12 = func_0x0001801fe950(puVar17);
            auStack_100[uVar14 * 0xc + 1] = uVar16;
            if (iVar12 == 0) break;
            uVar21 = 0;
            iVar13 = iVar12 + -1;
            if ((*(uint8_t *)(auStack_e8 + uVar14 * 0x18) & 1) == 0) {
                iVar13 = iVar12;
            }
            if ((uVar16 == 0) && (iVar13 + 1U <= uVar15)) {
                *(undefined4 *)((int64_t)&iStackX_8 + iVar10) = 1;
                uVar20 = uVar24;
code_r0x00018020945e:
                if (uVar15 < iVar13 + 2U) goto code_r0x000180209472;
                bVar25 = true;
                uVar19 = uVar24;
code_r0x0001802094b4:
                if (uVar15 < iVar13 + 4U) goto code_r0x0001802094c8;
                bVar26 = true;
                uVar18 = uVar24;
code_r0x00018020950a:
                if (uVar15 < iVar13 + 8U) goto code_r0x000180209524;
                iVar8 = *(int32_t *)((int64_t)&iStackX_8 + iVar10);
                uVar21 = uVar24;
                bVar5 = true;
            } else {
                uVar20 = uVar16;
                if (0x3f < uVar16) {
                    uVar20 = 0x3f;
                }
                if ((uVar15 < uVar20 + 1 + iVar13) && (uVar20 = uVar24, iVar13 + 1U <= uVar15)) {
                    uVar20 = (uVar15 - iVar13) - 1;
                }
                *(uint32_t *)((int64_t)&iStackX_8 + iVar10) = (uint32_t)(uVar20 != 0);
                if (uVar16 == 0) goto code_r0x00018020945e;
code_r0x000180209472:
                uVar19 = uVar16;
                if (0x3fff < uVar16) {
                    uVar19 = 0x3fff;
                }
                if ((uVar15 < uVar19 + 2 + iVar13) && (uVar19 = uVar24, iVar13 + 2U <= uVar15)) {
                    uVar19 = (uVar15 - iVar13) - 2;
                }
                bVar25 = uVar19 != 0;
                if (uVar16 == 0) goto code_r0x0001802094b4;
code_r0x0001802094c8:
                uVar18 = uVar16;
                if (0x3fffffff < uVar16) {
                    uVar18 = 0x3fffffff;
                }
                if ((uVar15 < uVar18 + 4 + iVar13) && (uVar18 = uVar24, iVar13 + 4U <= uVar15)) {
                    uVar18 = (uVar15 - iVar13) - 4;
                }
                bVar26 = uVar18 != 0;
                if (uVar16 == 0) goto code_r0x00018020950a;
code_r0x000180209524:
                iVar8 = *(int32_t *)((int64_t)&iStackX_8 + iVar10);
                *(int32_t *)((int64_t)&iStackX_8 + iVar10) = iVar8;
                if (0x3fffffffffffffff < uVar16) {
                    uVar16 = 0x3fffffffffffffff;
                }
                if (uVar15 < uVar16 + 8 + iVar13) {
                    uVar16 = uVar24;
                    if (iVar13 + 8U <= uVar15) {
                        uVar16 = (uVar15 - iVar13) - 8;
                    }
                    iVar8 = *(int32_t *)((int64_t)&iStackX_8 + iVar10);
                }
                bVar5 = false;
                if (uVar16 != 0) {
                    uVar21 = uVar16;
                    bVar5 = true;
                }
            }
            if ((bVar26) && (uVar21 <= uVar18)) {
                bVar5 = true;
                uVar21 = uVar18;
            }
            if ((bVar25) && (uVar21 <= uVar19)) {
                bVar5 = true;
                uVar21 = uVar19;
            }
            if (((iVar8 == 0) || (uVar20 < uVar21)) && (uVar20 = uVar21, !bVar5)) break;
            auStack_100[uVar14 * 0xc + 1] = uVar20;
        } else {
            puVar4 = *(undefined4 **)((int64_t)&var_18h + iVar10);
            auStack_e8[uVar14 * 0x18] = auStack_e8[uVar14 * 0x18] & 0xfffffffe;
            auStack_100[uVar14 * 0xc + 1] = uVar16;
            *puVar4 = 1;
        }
        if ((*(uint8_t *)(auStack_e8 + uVar14 * 0x18) & 2) != 0) {
            *(undefined4 *)(&var_b0h + (uint64_t)(uVar9 - 1 & 1) * 0xc) = 0;
        }
        uVar15 = auStack_100[uVar14 * 0xc + 1];
        if (uVar15 < uVar3) {
            auStack_e8[uVar14 * 0x18] = auStack_e8[uVar14 * 0x18] & 0xfffffffd;
        }
        puVar22 = (uint64_t *)(&var_b8h + (uint64_t)(uVar9 & 1) * 0xc);
        uVar16 = *puVar22;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x180209604;
        func_0x0001801e5f40(uVar15, auStack_d8 + uVar14 * 0x60, uVar16);
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x180209628;
        iVar8 = fcn.1802085d0(*(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)((int64_t)&arg_38h + iVar10));
        if (iVar8 == 0) goto code_r0x000180209767;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x180209638;
        iVar12 = fcn.1802082c0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                               *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10))
        ;
        if (iVar12 == 0) goto code_r0x000180209767;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x18020964c;
        iVar8 = func_0x0001801fe5d0(iVar12, puVar17);
        if (iVar8 == 0) {
            if ((*(uint8_t *)(in_RDX + 0x78) & 1) != 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x18020974d;
                fcn.180243fb0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), *(int64_t *)((int64_t)&var_18h + iVar10))
                ;
                *(uint32_t *)(in_RDX + 0x78) = *(uint32_t *)(in_RDX + 0x78) & 0xfffffffe;
                *(undefined8 *)(in_RDX + 0x38) = 0;
            }
            break;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x18020965c;
        iVar8 = fcn.180208380(*(int64_t *)(&stack0xfffffffffffffff0 + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                              *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)&iStackX_8 + iVar10), 
                              *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_30h + iVar10), 
                              *(int64_t *)((int64_t)&arg_38h + iVar10), *(int64_t *)((int64_t)&arg_40h + iVar10), 
                              *(int64_t *)(&stack0x00000188 + iVar10), *(int64_t *)(&stack0x00000198 + iVar10));
        if (iVar8 == 0) goto code_r0x000180209767;
        uVar15 = uVar24;
        if (*puVar22 != 0) {
            do {
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x18020969f;
                fcn.180208220(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
                uVar15 = uVar15 + 1;
            } while (uVar15 < *puVar22);
        }
        uVar9 = auStack_e8[uVar14 * 0x18];
        *(undefined4 *)iVar6 = 1;
        uVar1 = *(uint32_t *)(in_RDX + 0x34);
        *(uint32_t *)(in_RDX + 0x34) = uVar1 | 1;
        if ((uVar9 & 1) == 0) {
            *(uint32_t *)(in_RDX + 0x34) = uVar1 | 3;
        }
        uVar15 = auStack_100[uVar14 * 0xc + 1];
        if (uVar15 != 0) {
            uVar16 = *(uint64_t *)((int64_t)&var_10h + iVar10);
            if (*(uint64_t *)((int64_t)&var_10h + iVar10) < auStack_100[uVar14 * 0xc] + uVar15) {
                uVar16 = auStack_100[uVar14 * 0xc] + uVar15;
            }
            *(uint64_t *)((int64_t)&var_10h + iVar10) = uVar16;
        }
        var_128h = *puVar17;
        var_120h = auStack_100[uVar14 * 0xc];
        var_118h = var_120h + (uVar15 - 1);
        var_110h._0_4_ = uVar9 >> 1 & 1 | (uint32_t)var_110h & 0xfffffff8;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x18020972b;
        iVar8 = func_0x000180203c60(uVar2, &var_128h);
        if ((iVar8 == 0) || (auStack_100[uVar14 * 0xc + 1] < uVar3)) goto code_r0x000180209767;
        uVar23 = uVar23 + 1;
    }
    **(undefined4 **)((int64_t)&var_18h + iVar10) = 1;
code_r0x000180209767:
    iVar13 = *(int64_t *)((int64_t)&var_10h + iVar10);
code_r0x00018020976c:
    *(int64_t *)iVar7 = iVar13 - iVar11;
    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x180209789;
    func_0x000180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar10));
    return;
}

// ============================================================
// Function: FUN_1802097b0
// Address: 0x1802097b0
// Size: 920 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1802097b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h)
{
    uint8_t uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int32_t iVar5;
    char cVar10;
    int64_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 uVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t iVar11;
    undefined4 *in_R8;
    int64_t *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_48;
    int64_t var_20h;
    
    uStack_48 = 0x1802097c7;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_58h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar6);
    uVar2 = *(undefined8 *)(in_RCX + 0x70);
    iVar11 = 0;
    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x1802097fe;
    func_0x0001801e75b0((int64_t)&var_18h + iVar6, uVar2, 1);
    iVar3 = *(int64_t *)((int64_t)&arg_28h + iVar6);
    do {
        if (iVar3 == 0) {
code_r0x000180209af3:
            *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180209b03;
            func_0x000180459870(*(uint64_t *)((int64_t)&arg_58h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar6))
            ;
            return;
        }
        *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x18020981a;
        func_0x0001801e7600((int64_t)&var_18h + iVar6);
        uVar2 = *(undefined8 *)((int64_t)&arg_28h + iVar6);
        *(uint32_t *)(iVar3 + 0x100) = *(uint32_t *)(iVar3 + 0x100) & 0x8fffffff;
        *(uint32_t *)(iVar3 + 0x104) = *(uint32_t *)(iVar3 + 0x104) & 0xfffffffe;
        cVar10 = (char)((uint32_t)*(undefined4 *)(iVar3 + 0x100) >> 8);
        *(undefined8 *)(iVar3 + 0x60) = 0;
        if ((*(uint8_t *)(iVar3 + 0x104) & 4) != 0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x18020984f;
            iVar7 = fcn.1802082c0(*(int64_t *)((int64_t)&var_20h + iVar6), 
                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&arg_48h + iVar6) = *(undefined8 *)(iVar3 + 0x38);
                *(undefined8 *)((int64_t)&arg_50h + iVar6) = *(undefined8 *)(iVar3 + 0x40);
                *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180209880;
                iVar5 = func_0x0001801fe560(iVar7, (int64_t)&arg_48h + iVar6);
                if (iVar5 == 0) {
code_r0x000180209ac9:
                    if ((*(uint8_t *)(in_RDX + 0x78) & 1) != 0) {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180209ad8;
                        fcn.180243fb0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                        *(uint32_t *)(in_RDX + 0x78) = *(uint32_t *)(in_RDX + 0x78) & 0xfffffffe;
                        *(undefined8 *)(in_RDX + 0x38) = 0;
                    }
code_r0x000180209ae4:
                    *(int64_t *)(iVar3 + 0x30) = *in_R9;
                    *in_R9 = iVar3;
                } else {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180209890;
                    iVar5 = fcn.180208380(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                          *(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6)
                                          , *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                          *(int64_t *)(&stack0x00000180 + iVar6), *(int64_t *)(&stack0x00000190 + iVar6)
                                         );
                    if (iVar5 != 0) {
                        *in_R8 = 1;
                        *(uint32_t *)(in_RDX + 0x34) = *(uint32_t *)(in_RDX + 0x34) | 1;
                        *(uint32_t *)(iVar3 + 0x100) = *(uint32_t *)(iVar3 + 0x100) | 0x20000000;
                        cVar10 = (char)((uint32_t)*(undefined4 *)(iVar3 + 0x100) >> 8);
                        goto code_r0x0001802098b3;
                    }
                }
            }
            goto code_r0x000180209af3;
        }
code_r0x0001802098b3:
        if ((*(uint8_t *)(iVar3 + 0x104) & 8) != 0) {
            if (cVar10 == '\x05') {
                *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x1802098d3;
                iVar7 = fcn.1802082c0(*(int64_t *)((int64_t)&var_20h + iVar6), 
                                      *(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                if (iVar7 != 0) {
                    *(undefined8 *)((int64_t)&arg_30h + iVar6) = *(undefined8 *)(iVar3 + 0x38);
                    *(undefined8 *)((int64_t)&arg_38h + iVar6) = *(undefined8 *)(iVar3 + 0x48);
    // switch table (7 cases) at 0x180209b2c
                    switch(*(undefined *)(iVar3 + 0x101)) {
                    default:
                        goto code_r0x000180209af3;
                    case 2:
                        uVar4 = *(undefined8 *)(iVar3 + 0x70);
                        *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180209925;
                        iVar5 = func_0x0001801e6210(uVar4, (int64_t)&arg_40h + iVar6);
                        if (iVar5 == 0) goto code_r0x000180209af3;
                        break;
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                        *(undefined8 *)((int64_t)&arg_40h + iVar6) = *(undefined8 *)(iVar3 + 0x68);
                    }
                    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180209948;
                    iVar5 = func_0x0001801fe480(iVar7, (int64_t)&arg_30h + iVar6);
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180209b1c;
                        fcn.180208590(in_RDX);
                        goto code_r0x000180209ae4;
                    }
                    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180209958;
                    iVar5 = fcn.180208380(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                          *(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6)
                                          , *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                          *(int64_t *)(&stack0x00000180 + iVar6), *(int64_t *)(&stack0x00000190 + iVar6)
                                         );
                    if (iVar5 != 0) {
                        *in_R8 = 1;
                        *(uint32_t *)(in_RDX + 0x34) = *(uint32_t *)(in_RDX + 0x34) | 1;
                        *(uint32_t *)(iVar3 + 0x100) = *(uint32_t *)(iVar3 + 0x100) | 0x40000000;
                        *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180209981;
                        uVar8 = func_0x0001801bc820(iVar3 + 0x80);
                        if (*(uint64_t *)((int64_t)&arg_40h + iVar6) <= uVar8) {
                            *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x18020999b;
                            iVar7 = func_0x0001801bc820(iVar3 + 0x80);
                            *(int64_t *)(iVar3 + 0x60) = *(int64_t *)((int64_t)&arg_40h + iVar6) - iVar7;
                            goto code_r0x0001802099aa;
                        }
                    }
                }
            }
            goto code_r0x000180209af3;
        }
code_r0x0001802099aa:
        if (*(char *)(iVar3 + 0x102) == '\x01') {
            if ((*(uint8_t *)(iVar3 + 0x104) & 2) == 0) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x1802099ca;
                iVar5 = func_0x0001801e59a0(iVar3 + 0xa0, 0);
                if (iVar5 == 0) goto code_r0x000180209a2a;
            }
            *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x1802099d6;
            iVar7 = fcn.1802082c0(*(int64_t *)((int64_t)&var_20h + iVar6), 
                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
            if (iVar7 == 0) goto code_r0x000180209af3;
            *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x1802099ee;
            uVar9 = func_0x00018001ed90(iVar3 + 0xa0);
            uVar4 = *(undefined8 *)(iVar3 + 0x38);
            *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x1802099fd;
            iVar5 = func_0x0001801fe290(iVar7, uVar4, uVar9);
            if (iVar5 == 0) goto code_r0x000180209ac9;
            *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180209a0d;
            iVar5 = fcn.180208380(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6)
                                  , *(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                  *(int64_t *)(&stack0x00000180 + iVar6), *(int64_t *)(&stack0x00000190 + iVar6));
            if (iVar5 == 0) goto code_r0x000180209af3;
            *in_R8 = 1;
            *(uint32_t *)(in_RDX + 0x34) = *(uint32_t *)(in_RDX + 0x34) | 1;
            *(uint32_t *)(iVar3 + 0x100) = *(uint32_t *)(iVar3 + 0x100) | 0x10000000;
        }
code_r0x000180209a2a:
        cVar10 = *(char *)(iVar3 + 0x101);
        if ((((cVar10 == '\x01') || (cVar10 == '\x02')) || (cVar10 == '\x03')) && (1 < (uint8_t)(cVar10 - 5U))) {
            uVar1 = *(uint8_t *)(iVar3 + 0x104);
            *(undefined4 *)((int64_t)&var_10h + iVar6) = 0;
            if ((uVar1 & 8) != 0) goto code_r0x000180209af3;
            *(int64_t *)((int64_t)&var_8h + iVar6) = iVar11;
            *(int64_t *)(&stack0x00000000 + iVar6) = iVar3 + 0x60;
            *(int64_t *)(&stack0xfffffffffffffff8 + iVar6) = (int64_t)&var_10h + iVar6;
            *(undefined4 **)(&stack0xfffffffffffffff0 + iVar6) = in_R8;
            *(undefined8 *)(&stack0xffffffffffffffe8 + iVar6) = uVar2;
            *(int64_t *)((int64_t)&var_20h + iVar6) = iVar3 + 0x80;
            *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180209aa0;
            iVar5 = fcn.180209140(*(int64_t *)((int64_t)&var_20h + iVar6), 
                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6)
                                  , *(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000170 + iVar6));
            if (iVar5 == 0) {
                *(int64_t *)(iVar3 + 0x30) = *in_R9;
                *in_R9 = iVar3;
                goto code_r0x000180209af3;
            }
            iVar11 = iVar11 + *(int64_t *)(iVar3 + 0x60);
            if (*(int32_t *)((int64_t)&var_10h + iVar6) != 0) goto code_r0x000180209ae4;
        }
        *(int64_t *)(iVar3 + 0x30) = *in_R9;
        *in_R9 = iVar3;
        iVar3 = *(int64_t *)((int64_t)&arg_28h + iVar6);
    } while( true );
}

// ============================================================
// Function: FUN_180209b50
// Address: 0x180209b50
// Size: 1010 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel

void fcn.180209b50(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_b0h,
                  int64_t arg_108h, int64_t arg_170h, int64_t arg_198h)
{
    uint32_t *puVar1;
    char cVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t iVar9;
    uint64_t in_R8;
    undefined4 *in_R9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_38;
    int64_t var_10h;
    int64_t var_8h;
    
    uStack_38 = 0x180209b65;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_58h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar7);
    uVar3 = *(uint32_t *)(in_RDX + 0x30);
    iVar11 = 0;
    *(uint32_t *)((int64_t)&var_10h + iVar7) = uVar3;
    if (uVar3 != 0) {
        if ((uVar3 == 1) || (uVar3 != 2)) {
            iVar11 = 2;
        } else {
            iVar11 = 1;
        }
    }
    iVar10 = *(int64_t *)(in_RDX + 0x88);
    *in_R9 = 0;
    *(undefined8 *)((int64_t)&arg_b0h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_60h + iVar7) = unaff_RDI;
    *(int64_t *)((int64_t)&var_8h + iVar7) = iVar10;
    if (((*(int64_t *)(in_RDX + 0x10) != 0) && (uVar3 < 4)) && ((uint32_t)in_R8 < 3)) {
        *(undefined8 *)((int64_t)&var_20h + iVar7) = 0;
        iVar9 = in_RCX + 0x2c;
        uVar4 = *(uint32_t *)(((uint64_t)uVar3 * 3 + (in_R8 & 0xffffffff)) * 4 + 0x1804ba048);
        *(int64_t *)(&stack0x00000000 + iVar7) = in_RDX + 0x98;
        *(undefined8 *)((int64_t)aiStackX_8 + iVar7) = *(undefined8 *)((uint64_t)uVar3 * 0x20 + 0x1e8 + in_RCX);
        *(undefined8 *)((int64_t)aiStackX_8 + iVar7 + 8) = *(undefined8 *)(in_RDX + 0x28);
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x180209c39;
        iVar6 = func_0x00018026bea0(iVar9);
        *(undefined4 *)((int64_t)&arg_30h + iVar7) = 1;
        if (iVar6 == 0) {
            iVar9 = 0;
        }
        *(int64_t *)((int64_t)&var_18h + iVar7) = iVar9;
        iVar9 = *(int64_t *)(in_RDX + 0x90);
        *(undefined8 *)((int64_t)&arg_28h + iVar7) = *(undefined8 *)(in_RCX + 0x170 + iVar11 * 8);
        for (; iVar9 != 0; iVar9 = *(int64_t *)(iVar9 + 0x30)) {
            uVar3 = *(uint32_t *)(iVar9 + 0x100);
            if ((uVar3 & 0x60000000) != 0) {
                *(undefined8 *)((int64_t)&arg_38h + iVar7) = *(undefined8 *)(iVar9 + 0x38);
                *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
                *(undefined8 *)((int64_t)&arg_40h + iVar7) = 0xffffffffffffffff;
                *(uint32_t *)((int64_t)&arg_50h + iVar7) =
                     uVar3 >> 0x1c & 6 | *(uint32_t *)((int64_t)&arg_50h + iVar7) & 0xfffffff8;
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x180209cbb;
                iVar6 = func_0x000180203c60(iVar10);
                if (iVar6 == 0) goto code_r0x000180209f10;
            }
        }
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x180209cdd;
        iVar6 = func_0x00018020e2a0(in_RCX + 0x108, iVar10);
        if (iVar6 != 0) {
            *(int64_t *)(in_RCX + 0x170 + iVar11 * 8) = *(int64_t *)(in_RCX + 0x170 + iVar11 * 8) + 1;
            *in_R9 = 1;
            uVar5 = *(undefined8 *)(in_RCX + 0x50);
            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x180209d10;
            iVar6 = func_0x0001801fb960(uVar5, (int64_t)&stack0x00000000 + iVar7);
            if (iVar6 != 0) {
                iVar9 = *(int64_t *)(in_RDX + 0x90);
                if (iVar9 != 0) {
                    do {
                        puVar1 = (uint32_t *)(iVar9 + 0x104);
                        if ((*(uint32_t *)(iVar9 + 0x100) & 0x10000000) != 0) {
                            *puVar1 = *puVar1 & 0xfffffffd;
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x180209d57;
                            func_0x0001801e59a0(iVar9 + 0xa0, 1);
                        }
                        if ((*(uint32_t *)(iVar9 + 0x100) >> 0x1d & 1) != 0) {
                            *puVar1 = *puVar1 & 0xfffffffb;
                        }
                        if ((*(uint32_t *)(iVar9 + 0x100) >> 0x1e & 1) != 0) {
                            *puVar1 = *puVar1 & 0xfffffff7;
                        }
                        if (*(int64_t *)(iVar9 + 0x60) != 0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x180209d84;
                            func_0x0001801e5ba0(iVar9 + 0x80);
                            *(undefined8 *)(iVar9 + 0x60) = 0;
                        }
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x180209d9a;
                        fcn.1801e7fb0(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                                      *(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)aiStackX_8 + iVar7)
                                      , *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7)
                                      , *(int64_t *)((int64_t)&arg_30h + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7)
                                      , *(int64_t *)((int64_t)&arg_40h + iVar7), *(int64_t *)((int64_t)&arg_70h + iVar7)
                                      , *(int64_t *)(&stack0x00000078 + iVar7), *(int64_t *)((int64_t)&arg_80h + iVar7)
                                      , *(int64_t *)((int64_t)&arg_88h + iVar7));
                        cVar2 = *(char *)(iVar9 + 0x101);
                        if (((cVar2 == '\x01') || (cVar2 == '\x02')) || (cVar2 == '\x03')) {
                            uVar5 = *(undefined8 *)(iVar9 + 0x70);
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x180209db9;
                            iVar6 = func_0x0001801e6390(uVar5);
                            if (iVar6 == 0) {
                                uVar5 = *(undefined8 *)(iVar9 + 0x70);
                                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x180209dc8;
                                iVar6 = func_0x0001801e6210(uVar5, 0);
                                if (iVar6 != 0) {
                                    uVar5 = *(undefined8 *)(in_RCX + 0x70);
                                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x180209dd8;
                                    func_0x0001801e79e0(uVar5, iVar9);
                                }
                            }
                        }
                        iVar9 = *(int64_t *)(iVar9 + 0x30);
                    } while (iVar9 != 0);
                    iVar10 = *(int64_t *)((int64_t)&var_8h + iVar7);
                }
                if ((*(uint8_t *)(iVar10 + 0x20) & 8) != 0) {
                    *(uint32_t *)(in_RCX + 0x198) =
                         (*(uint32_t *)(in_RCX + 0x198) >> 7 & 7 & ~(1 << (int32_t)iVar11)) << 7 |
                         *(uint32_t *)(in_RCX + 0x198) & 0xfffffc7f;
                }
                if ((*(uint8_t *)(iVar10 + 0x7c) & 1) != 0) {
                    *(uint32_t *)(in_RCX + 0x198) = *(uint32_t *)(in_RCX + 0x198) & 0xfffffffe;
                }
                if ((*(uint8_t *)(iVar10 + 0x7c) & 2) != 0) {
                    *(uint32_t *)(in_RCX + 0x198) = *(uint32_t *)(in_RCX + 0x198) & 0xfffffffd;
                    uVar5 = *(undefined8 *)(in_RCX + 0x80);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x180209e40;
                    func_0x0001801e59a0(uVar5, 1);
                }
                if ((*(uint8_t *)(iVar10 + 0x7c) & 4) != 0) {
                    *(uint32_t *)(in_RCX + 0x198) = *(uint32_t *)(in_RCX + 0x198) & 0xfffffffb;
                    uVar5 = *(undefined8 *)(in_RCX + 0x88);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x180209e5f;
                    func_0x0001801e59a0(uVar5, 1);
                }
                if ((*(uint8_t *)(iVar10 + 0x7c) & 8) != 0) {
                    *(uint32_t *)(in_RCX + 0x198) = *(uint32_t *)(in_RCX + 0x198) & 0xfffffff7;
                    uVar5 = *(undefined8 *)(in_RCX + 0x90);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x180209e7e;
                    func_0x0001801e59a0(uVar5, 1);
                }
                if ((*(uint8_t *)(iVar10 + 0x7c) & 0x10) != 0) {
                    *(uint32_t *)(in_RCX + 0x198) =
                         (*(uint32_t *)(in_RCX + 0x198) >> 4 & 7 & ~(1 << (int32_t)iVar11)) << 4 |
                         *(uint32_t *)(in_RCX + 0x198) & 0xffffff8f;
                }
                if ((*(uint8_t *)(iVar10 + 0x7c) & 0x20) != 0) {
                    *(uint32_t *)(in_RCX + 0x198) = *(uint32_t *)(in_RCX + 0x198) & 0xfffffbff;
                }
                if ((*(uint8_t *)(iVar10 + 0x20) & 8) != 0) {
                    uVar5 = *(undefined8 *)(in_RCX + 0x68);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x180209ec6;
                    piVar8 = (int32_t *)func_0x0001802026c0(uVar5);
                    if (*(int32_t *)((int64_t)&var_10h + iVar7) == 0) {
                        if (*piVar8 != 0) {
                            *piVar8 = *piVar8 + -1;
                        }
                    } else if ((*(int32_t *)((int64_t)&var_10h + iVar7) == 2) && (piVar8[1] != 0)) {
                        piVar8[1] = piVar8[1] + -1;
                    }
                    if (((uVar4 >> 0xd & 1) != 0) && (piVar8[iVar11 + 2] != 0)) {
                        piVar8[iVar11 + 2] = piVar8[iVar11 + 2] + -1;
                    }
                }
            }
        }
    }
code_r0x000180209f10:
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x180209f30;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_58h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar7));
    return;
}

// ============================================================
// Function: FUN_180209f50
// Address: 0x180209f50
// Size: 672 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.180209f50(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    uint32_t uVar11;
    int64_t *in_RCX;
    undefined4 *in_RDX;
    int64_t *piVar12;
    uint64_t uVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    uint64_t in_R8;
    uint64_t in_R9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x180209f72;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar15 = (uint32_t)in_R8;
    in_R8 = in_R8 & 0xffffffff;
    if (uVar15 == 0) {
        uVar14 = 1;
    } else if ((uVar15 == 1) || (uVar15 != 2)) {
        uVar14 = 4;
        if (3 < uVar15) {
            return 0;
        }
    } else {
        uVar14 = 2;
    }
    piVar12 = in_RCX + 0x13;
    if ((uint32_t)in_R9 < 3) {
        *(undefined4 *)((int64_t)in_RCX + 0x114) = *(undefined4 *)((in_R8 * 3 + (in_R9 & 0xffffffff)) * 4 + 0x1804ba048)
        ;
        if (uVar15 == 0) {
            uVar5 = 1;
        } else if (uVar15 == 1) {
            uVar5 = 2;
        } else if (uVar15 == 2) {
            uVar5 = 3;
        } else if (uVar15 == 3) {
            uVar5 = 5;
        } else {
            uVar5 = 0xff;
        }
        *(undefined *)piVar12 = uVar5;
        uVar11 = *(uint32_t *)piVar12 & 0xffcf92ff | 0x9000;
        *(uint32_t *)piVar12 = uVar11;
        *(undefined4 *)((int64_t)in_RCX + 0x9c) = in_RDX[0x32];
        uVar2 = *(undefined4 *)((int64_t)in_RDX + 0x19);
        uVar3 = *(undefined4 *)((int64_t)in_RDX + 0x1d);
        uVar4 = *(undefined4 *)((int64_t)in_RDX + 0x21);
        *(undefined4 *)(in_RCX + 0x14) = *(undefined4 *)((int64_t)in_RDX + 0x15);
        *(undefined4 *)((int64_t)in_RCX + 0xa4) = uVar2;
        *(undefined4 *)(in_RCX + 0x15) = uVar3;
        *(undefined4 *)((int64_t)in_RCX + 0xac) = uVar4;
        *(undefined4 *)(in_RCX + 0x16) = *(undefined4 *)((int64_t)in_RDX + 0x25);
        *(undefined *)((int64_t)in_RCX + 0xb4) = *(undefined *)((int64_t)in_RDX + 0x29);
        uVar2 = in_RDX[1];
        uVar3 = in_RDX[2];
        uVar4 = in_RDX[3];
        *(undefined4 *)((int64_t)in_RCX + 0xb5) = *in_RDX;
        *(undefined4 *)((int64_t)in_RCX + 0xb9) = uVar2;
        *(undefined4 *)((int64_t)in_RCX + 0xbd) = uVar3;
        *(undefined4 *)((int64_t)in_RCX + 0xc1) = uVar4;
        *(undefined4 *)((int64_t)in_RCX + 0xc5) = in_RDX[4];
        *(undefined *)((int64_t)in_RCX + 0xc9) = *(undefined *)(in_RDX + 5);
        in_RCX[0x1c] = (uint64_t)(0x3fff - (uVar11 >> 10 & 0xf));
        if (uVar15 == 0) {
            in_RCX[0x1a] = *(int64_t *)(in_RDX + 0x3a);
            iVar8 = *(int64_t *)(in_RDX + 0x3c);
        } else {
            in_RCX[0x1a] = 0;
            iVar8 = 0;
        }
        in_RCX[0x1b] = iVar8;
        uVar5 = *(undefined *)(in_RCX + 0x14);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18020a0a4;
        uVar9 = func_0x0001801f97e0(uVar5);
        if (uVar9 != 0) {
            uVar1 = *(undefined8 *)(in_RDX + 0x14);
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18020a0b9;
            uVar10 = func_0x0001801fb7c0(uVar1);
            uVar13 = 0;
            if (*(uint64_t *)((int64_t)&arg_48h + iVar7) <= uVar10) {
                uVar13 = uVar10 - *(int64_t *)((int64_t)&arg_48h + iVar7);
            }
            if (uVar9 <= uVar13) {
                uVar1 = *(undefined8 *)(in_RDX + 0x14);
                *(uint64_t *)((int64_t)&arg_28h + iVar7) = uVar13 - uVar9;
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18020a0f1;
                iVar6 = func_0x0001801fb2e0(uVar1, in_R8, uVar13 - uVar9, (int64_t)&arg_28h + iVar7);
                if (iVar6 != 0) {
                    iVar8 = *(int64_t *)((int64_t)&arg_28h + iVar7);
                    in_RCX[0x1e] = uVar13;
                    in_RCX[0x21] = uVar13 - iVar8;
                    in_RCX[0x1f] = iVar8;
                    *(uint32_t *)(in_RCX + 0x22) = (uint32_t)in_R9;
                    if (((*(uint32_t *)((int64_t)in_RCX + 0x114) & 2) == 0) ||
                       (((*(uint32_t *)((int64_t)in_RCX + 0x114) >> 0xf & 1) == 0 &&
                        ((uVar14 & (uint32_t)in_RDX[0x66] >> 7) == 0)))) {
                        uVar9 = 0;
                    } else {
                        uVar9 = 1;
                    }
                    uVar13 = in_RCX[0x1f];
                    if (uVar9 <= uVar13) {
                        *(uint32_t *)((int64_t)in_RCX + 0x34) = *(uint32_t *)((int64_t)in_RCX + 0x34) & 0xfffffffc;
                        *(uint32_t *)(in_RCX + 0xf) = *(uint32_t *)(in_RCX + 0xf) & 0xfffffffe;
                        *(uint32_t *)(in_RCX + 6) = uVar15;
                        *in_RCX = (int64_t)in_RDX;
                        in_RCX[1] = uVar13;
                        in_RCX[4] = uVar9;
                        in_RCX[5] = 0;
                        in_RCX[2] = 0;
                        in_RCX[3] = 0;
                        in_RCX[7] = 0;
                        if (*(uint64_t *)(in_RDX + (in_R8 + 0xf) * 8) < uVar13) {
                            uVar1 = *(undefined8 *)(in_RDX + in_R8 * 8 + 0x76);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18020a1ad;
                            iVar7 = func_0x0001802249c0(uVar1, uVar13, 0x1804ba078, 0xd2);
                            if (iVar7 == 0) {
                                return 0;
                            }
                            *(int64_t *)(*in_RCX + 0x1d8 + in_R8 * 0x20) = iVar7;
                            *(uint64_t *)((in_R8 + 0xf) * 0x20 + *in_RCX) = uVar13;
                        }
                        *(undefined4 *)(in_RCX + 0x10) = 1;
                        in_RCX[0x11] = 0;
                        in_RCX[0x12] = 0;
                        *(undefined4 *)(in_RCX + 0x23) = 0;
                        return 1;
                    }
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18020a1f0
// Address: 0x18020a1f0
// Size: 121 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18020a1f0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h,
                     int64_t arg_68h)
{
    uint64_t uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020a205;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar2 = *(int64_t *)((int64_t)&arg_60h + iVar6);
    *(undefined8 *)(iVar2 + 0x50) = 2;
    *(undefined8 **)((int64_t)&var_18h + iVar6) = (undefined8 *)(iVar2 + 0x50);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020a234;
    iVar5 = fcn.1801e6230(*(int64_t *)((int64_t)&var_18h + iVar6));
    *(int32_t *)(iVar2 + 0x58) = iVar5;
    if (iVar5 != 0) {
        iVar7 = *(int64_t *)(iVar2 + 0x10);
        if ((iVar7 == 0) && ((*(uint8_t *)(iVar2 + 0x20) & 2) == 0)) {
            return iVar7;
        }
        uVar3 = *(undefined8 *)((int64_t)&arg_68h + iVar6);
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBX;
        *(int64_t *)(iVar2 + 0x28) = iVar7;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020a277;
        iVar7 = fcn.1801e5c20(in_R9, uVar3);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020a282;
        iVar6 = fcn.1801bc820(in_R9);
        uVar1 = iVar7 + iVar6;
        iVar6 = *(int64_t *)(iVar2 + 0x10);
        if ((iVar6 != 0) && (uVar4 = *(uint64_t *)(iVar2 + 8), uVar1 < iVar6 + uVar4)) {
            iVar6 = uVar1 - uVar4;
            if (uVar1 <= uVar4) {
                iVar6 = 0;
            }
            *(uint32_t *)(iVar2 + 0x20) = *(uint32_t *)(iVar2 + 0x20) & 0xfffffffd;
            *(int64_t *)(iVar2 + 0x10) = iVar6;
        }
        if ((iVar6 == 0) && ((*(uint8_t *)(iVar2 + 0x20) & 2) == 0)) {
            *(undefined4 *)(iVar2 + 0x58) = 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18020a269
// Address: 0x18020a269
// Size: 49 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18020a1f0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h,
                     int64_t arg_68h)
{
    uint64_t uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020a205;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar2 = *(int64_t *)((int64_t)&arg_60h + iVar6);
    *(undefined8 *)(iVar2 + 0x50) = 2;
    *(undefined8 **)((int64_t)&var_18h + iVar6) = (undefined8 *)(iVar2 + 0x50);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020a234;
    iVar5 = fcn.1801e6230(*(int64_t *)((int64_t)&var_18h + iVar6));
    *(int32_t *)(iVar2 + 0x58) = iVar5;
    if (iVar5 != 0) {
        iVar7 = *(int64_t *)(iVar2 + 0x10);
        if ((iVar7 == 0) && ((*(uint8_t *)(iVar2 + 0x20) & 2) == 0)) {
            return iVar7;
        }
        uVar3 = *(undefined8 *)((int64_t)&arg_68h + iVar6);
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBX;
        *(int64_t *)(iVar2 + 0x28) = iVar7;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020a277;
        iVar7 = fcn.1801e5c20(in_R9, uVar3);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020a282;
        iVar6 = fcn.1801bc820(in_R9);
        uVar1 = iVar7 + iVar6;
        iVar6 = *(int64_t *)(iVar2 + 0x10);
        if ((iVar6 != 0) && (uVar4 = *(uint64_t *)(iVar2 + 8), uVar1 < iVar6 + uVar4)) {
            iVar6 = uVar1 - uVar4;
            if (uVar1 <= uVar4) {
                iVar6 = 0;
            }
            *(uint32_t *)(iVar2 + 0x20) = *(uint32_t *)(iVar2 + 0x20) & 0xfffffffd;
            *(int64_t *)(iVar2 + 0x10) = iVar6;
        }
        if ((iVar6 == 0) && ((*(uint8_t *)(iVar2 + 0x20) & 2) == 0)) {
            *(undefined4 *)(iVar2 + 0x58) = 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18020a29a
// Address: 0x18020a29a
// Size: 71 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18020a1f0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h,
                     int64_t arg_68h)
{
    uint64_t uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020a205;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar2 = *(int64_t *)((int64_t)&arg_60h + iVar6);
    *(undefined8 *)(iVar2 + 0x50) = 2;
    *(undefined8 **)((int64_t)&var_18h + iVar6) = (undefined8 *)(iVar2 + 0x50);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020a234;
    iVar5 = fcn.1801e6230(*(int64_t *)((int64_t)&var_18h + iVar6));
    *(int32_t *)(iVar2 + 0x58) = iVar5;
    if (iVar5 != 0) {
        iVar7 = *(int64_t *)(iVar2 + 0x10);
        if ((iVar7 == 0) && ((*(uint8_t *)(iVar2 + 0x20) & 2) == 0)) {
            return iVar7;
        }
        uVar3 = *(undefined8 *)((int64_t)&arg_68h + iVar6);
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBX;
        *(int64_t *)(iVar2 + 0x28) = iVar7;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020a277;
        iVar7 = fcn.1801e5c20(in_R9, uVar3);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020a282;
        iVar6 = fcn.1801bc820(in_R9);
        uVar1 = iVar7 + iVar6;
        iVar6 = *(int64_t *)(iVar2 + 0x10);
        if ((iVar6 != 0) && (uVar4 = *(uint64_t *)(iVar2 + 8), uVar1 < iVar6 + uVar4)) {
            iVar6 = uVar1 - uVar4;
            if (uVar1 <= uVar4) {
                iVar6 = 0;
            }
            *(uint32_t *)(iVar2 + 0x20) = *(uint32_t *)(iVar2 + 0x20) & 0xfffffffd;
            *(int64_t *)(iVar2 + 0x10) = iVar6;
        }
        if ((iVar6 == 0) && ((*(uint8_t *)(iVar2 + 0x20) & 2) == 0)) {
            *(undefined4 *)(iVar2 + 0x58) = 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18020a2f0
// Address: 0x18020a2f0
// Size: 731 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.18020a2f0(int64_t arg_28h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_88h,
                  int64_t arg_90h, int64_t arg_98h, int64_t arg_a8h, int64_t arg_d0h, int64_t arg_198h)
{
    uint32_t uVar1;
    undefined8 uVar2;
    uint32_t *puVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t *piVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    uint32_t uVar9;
    uint64_t in_RDX;
    undefined8 unaff_RSI;
    uint64_t in_R8;
    int64_t in_R9;
    int64_t iVar10;
    bool bVar11;
    int64_t var_8h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18020a307;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar10 = 0;
    uVar9 = (uint32_t)in_RDX;
    if (uVar9 != 0) {
        if ((uVar9 == 1) || (uVar9 != 2)) {
            iVar10 = 2;
        } else {
            iVar10 = 1;
        }
    }
    uVar2 = *(undefined8 *)(in_RCX + 0x50);
    *(undefined8 *)((int64_t)&arg_90h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18020a34e;
    iVar4 = func_0x0001801fb7e0(uVar2, in_RDX & 0xffffffff);
    if ((((iVar4 == 0) || (3 < uVar9)) || (2 < (uint32_t)in_R8)) ||
       ((uVar1 = *(uint32_t *)(((in_RDX & 0xffffffff) * 3 + (in_R8 & 0xffffffff)) * 4 + 0x1804ba048),
        (uVar1 >> 0x10 & 1) == 0 && (in_R9 == 0)))) {
code_r0x00018020a5a9:
        bVar11 = false;
    } else {
        puVar3 = *(uint32_t **)((int64_t)&arg_a8h + iVar5);
        if ((uVar9 < *puVar3) && (*puVar3 != 3)) {
            *puVar3 = uVar9;
        }
        if ((uVar1 >> 0xd & 1) == 0) {
code_r0x00018020a3d5:
            if ((uVar1 & 4) != 0) {
                *(undefined8 *)((int64_t)&arg_88h + iVar5) = 2;
                *(int64_t *)(&stack0xfffffffffffffff8 + iVar5) = (int64_t)&arg_88h + iVar5;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18020a410;
                iVar4 = fcn.1801e6230(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5));
                if (iVar4 != 0) goto code_r0x00018020a551;
            }
            if ((uVar1 & 1) != 0) {
                uVar2 = *(undefined8 *)(in_RCX + 0x68);
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18020a42a;
                iVar4 = func_0x000180202940(uVar2, iVar10);
                if ((iVar4 != 0) || ((*(uint32_t *)(in_RCX + 0x198) >> 4 & 1 << (int8_t)iVar10 & 7) != 0))
                goto code_r0x00018020a551;
            }
            if (((uVar1 >> 0xd & 1) == 0) || ((1 << (int8_t)iVar10 & *(uint32_t *)(in_RCX + 0x198) >> 7 & 7) == 0)) {
                if ((uVar1 >> 9 & 1) == 0) {
code_r0x00018020a4df:
                    if ((((uVar1 & 8) == 0) || ((*(uint8_t *)(in_RCX + 0x198) & 1) == 0)) &&
                       (((uVar1 >> 10 & 1) == 0 ||
                        (((*(uint32_t *)(in_RCX + 0x198) & 0x400) == 0 || (*puVar3 != uVar9)))))) {
                        if (uVar9 != 1) {
                            uVar2 = *(undefined8 *)(in_RCX + 0x60);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18020a517;
                            for (iVar7 = func_0x000180201e80(uVar2, iVar10); iVar7 != 0;
                                iVar7 = func_0x000180201eb0(iVar7, iVar10)) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18020a528;
                                iVar8 = func_0x0001801e8e30(iVar7);
                                if (iVar8 == 7) {
                                    bVar11 = (uVar1 & 0x1000) == 0;
code_r0x00018020a563:
                                    if (!bVar11) goto code_r0x00018020a551;
                                } else {
                                    if (iVar8 == 0x18) {
                                        bVar11 = (uVar1 & 0x40) == 0;
                                        goto code_r0x00018020a563;
                                    }
                                    if (iVar8 != 0x19) {
                                        if (iVar8 == 0x1b) {
                                            bVar11 = (uVar1 & 0x20) == 0;
                                        } else {
                                            bVar11 = (uVar1 & 0x800) == 0;
                                        }
                                        goto code_r0x00018020a563;
                                    }
                                    if ((char)uVar1 < '\0') goto code_r0x00018020a551;
                                }
                                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18020a570;
                            }
                        }
                        if (((uVar1 >> 8 & 1) != 0) && ((*(uint32_t *)(in_RCX + 0x198) & 0x800) != 0)) {
                            uVar2 = *(undefined8 *)(in_RCX + 0x70);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18020a59b;
                            func_0x0001801e75b0((int64_t)&var_8h + iVar5, uVar2, 0);
                            return *(int64_t *)((int64_t)&var_18h + iVar5) != 0;
                        }
                        goto code_r0x00018020a5a9;
                    }
                } else if ((*(uint8_t *)(in_RCX + 0x198) & 2) == 0) {
                    uVar2 = *(undefined8 *)(in_RCX + 0x80);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18020a495;
                    iVar4 = func_0x0001801e59a0(uVar2, 0);
                    if ((iVar4 == 0) && ((*(uint8_t *)(in_RCX + 0x198) & 4) == 0)) {
                        uVar2 = *(undefined8 *)(in_RCX + 0x88);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18020a4b8;
                        iVar4 = func_0x0001801e59a0(uVar2, 0);
                        if ((iVar4 == 0) && ((*(uint8_t *)(in_RCX + 0x198) & 8) == 0)) {
                            uVar2 = *(undefined8 *)(in_RCX + 0x90);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18020a4db;
                            iVar4 = func_0x0001801e59a0(uVar2, 0);
                            if (iVar4 == 0) goto code_r0x00018020a4df;
                        }
                    }
                }
            }
        } else {
            uVar2 = *(undefined8 *)(in_RCX + 0x68);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18020a3ac;
            piVar6 = (int32_t *)func_0x0001802026c0(uVar2);
            if (uVar9 == 0) {
                iVar4 = *piVar6;
code_r0x00018020a3c1:
                if (iVar4 == 0) goto code_r0x00018020a3c7;
            } else {
                if (uVar9 == 2) {
                    iVar4 = piVar6[1];
                    goto code_r0x00018020a3c1;
                }
code_r0x00018020a3c7:
                if (piVar6[iVar10 + 2] == 0) goto code_r0x00018020a3d5;
            }
        }
code_r0x00018020a551:
        bVar11 = true;
    }
    return bVar11;
}

// ============================================================
// Function: FUN_18020a610
// Address: 0x18020a610
// Size: 206 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 * fcn.18020a610(int64_t arg_28h, int64_t arg_58h)
{
    uint64_t uVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    undefined8 in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020a620;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020a640;
    puVar3 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
    if (puVar3 == (undefined8 *)0x0) {
        return (undefined8 *)0x0;
    }
    *puVar3 = in_RCX;
    puVar3[1] = in_RDX;
    uVar1 = puVar3[6];
    puVar3[6] = 0x4b0;
    puVar3[2] = 12000;
    puVar3[3] = 0x960;
    if (0x4b0 < uVar1) {
        puVar3[8] = 12000;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020a68e;
    fcn.18020aec0(puVar3);
    puVar3[8] = puVar3[2];
    puVar3[7] = 0;
    puVar3[10] = 0;
    puVar3[0xb] = 0;
    *(undefined4 *)(puVar3 + 0xc) = 0;
    puVar3[0xd] = 0;
    *(undefined4 *)(puVar3 + 0xe) = 0;
    *(undefined4 *)(puVar3 + 4) = 1;
    *(undefined4 *)((int64_t)puVar3 + 0x24) = 2;
    *(undefined4 *)(puVar3 + 5) = 3;
    puVar3[9] = 0xffffffffffffffff;
    return puVar3;
}

