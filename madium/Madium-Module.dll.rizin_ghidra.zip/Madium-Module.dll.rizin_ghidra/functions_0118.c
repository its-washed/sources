// Chunk 118 - 50 functions

// ============================================================
// Function: FUN_1801972c0
// Address: 0x1801972c0
// Size: 99 bytes
// ============================================================
undefined8 fcn.1801972c0(undefined8 param_1, int64_t param_2)
{
    char cVar1;
    int64_t iVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801972ca;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((*(uint8_t *)(*(int64_t *)(param_2 + 0x300) + 0x20) & 8) != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801972df;
        cVar1 = fcn.18023bbe0();
        if (-1 < cVar1) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801972e8;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
            *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180197300;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                          *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
            *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180197312;
            fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar2));
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_180197370
// Address: 0x180197370
// Size: 90 bytes
// ============================================================
undefined8 fcn.180197370(int32_t **param_1)
{
    int32_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019737c;
    iVar2 = fcn.18045a350();
    piVar1 = *param_1;
    if (piVar1 != (int32_t *)0x0) {
        if (*piVar1 == 0) {
    // WARNING: Could not recover jumptable at 0x00018019739c. Too many branches
    // WARNING: Treating indirect jump as call
            uVar3 = (**(code **)(piVar1 + 0x1c))(piVar1);
            return uVar3;
        }
        if ((char)*piVar1 < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1801973ab;
            iVar2 = func_0x0001801bda50(piVar1);
            if (iVar2 != 0) {
    // WARNING: Could not recover jumptable at 0x0001801973bc. Too many branches
    // WARNING: Treating indirect jump as call
                uVar3 = (**(code **)(iVar2 + 0x70))(piVar1);
                return uVar3;
            }
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1801973d0
// Address: 0x1801973d0
// Size: 260 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.1801973d0(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h,
                     int64_t arg_90h, int64_t arg_98h, int64_t arg_c0h, int64_t arg_d0h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined4 *puVar7;
    uint64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801973e5;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801973f7;
    iVar6 = fcn.1801bcaf0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180197405;
        fcn.180229b10();
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019740c;
        fcn.18022ccf0(in_RDX & 0xffffffff);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019741a;
        iVar6 = fcn.1802119f0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        if (iVar6 != 0) {
            *(undefined4 *)((int64_t)&arg_c0h + iVar5) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019744a;
            puVar7 = (undefined4 *)
                     fcn.180229bc0((int64_t)&iStackX_20 + iVar5 + -8, 0x1804a97b8, (int64_t)&arg_c0h + iVar5);
            uVar1 = puVar7[1];
            uVar2 = puVar7[2];
            uVar3 = puVar7[3];
            *(undefined4 *)((int64_t)&arg_48h + iVar5) = *puVar7;
            *(undefined4 *)((int64_t)&arg_48h + iVar5 + 4) = uVar1;
            *(undefined4 *)(&stack0x00000050 + iVar5) = uVar2;
            *(undefined4 *)(&stack0x00000054 + iVar5) = uVar3;
            uVar1 = puVar7[5];
            uVar2 = puVar7[6];
            uVar3 = puVar7[7];
            *(undefined4 *)((int64_t)&arg_58h + iVar5) = puVar7[4];
            *(undefined4 *)((int64_t)&arg_58h + iVar5 + 4) = uVar1;
            *(undefined4 *)(&stack0x00000060 + iVar5) = uVar2;
            *(undefined4 *)(&stack0x00000064 + iVar5) = uVar3;
            *(undefined8 *)((int64_t)&arg_68h + iVar5) = *(undefined8 *)(puVar7 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180197470;
            puVar7 = (undefined4 *)fcn.180229ba0((int64_t)&iStackX_20 + iVar5 + -8);
            uVar1 = puVar7[1];
            uVar2 = puVar7[2];
            uVar3 = puVar7[3];
            *(undefined4 *)((int64_t)&arg_70h + iVar5) = *puVar7;
            *(undefined4 *)((int64_t)&arg_70h + iVar5 + 4) = uVar1;
            *(undefined4 *)(&stack0x00000078 + iVar5) = uVar2;
            *(undefined4 *)(&stack0x0000007c + iVar5) = uVar3;
            uVar1 = puVar7[5];
            uVar2 = puVar7[6];
            uVar3 = puVar7[7];
            *(undefined4 *)((int64_t)&arg_80h + iVar5) = puVar7[4];
            *(undefined4 *)((int64_t)&arg_80h + iVar5 + 4) = uVar1;
            *(undefined4 *)(&stack0x00000088 + iVar5) = uVar2;
            *(undefined4 *)(&stack0x0000008c + iVar5) = uVar3;
            *(undefined8 *)((int64_t)&arg_90h + iVar5) = *(undefined8 *)(puVar7 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019749f;
            iVar4 = fcn.180211ab0(iVar6, (int64_t)&arg_48h + iVar5);
            if ((iVar4 != 0) && (*(int32_t *)((int64_t)&arg_c0h + iVar5) != 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801974b5;
                fcn.180211a40(iVar6);
                iVar6 = 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801974bc;
        fcn.1802299d0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
    }
    return iVar6;
}

// ============================================================
// Function: FUN_1801974e0
// Address: 0x1801974e0
// Size: 46 bytes
// ============================================================
void fcn.1801974e0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801974f0;
        iVar1 = fcn.18045a350();
        *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x1801974fb;
        iVar2 = fcn.18020eec0();
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x180197508;
            fcn.180211a40(arg1);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180197510
// Address: 0x180197510
// Size: 52 bytes
// ============================================================
undefined8 fcn.180197510(int64_t param_1)
{
    int64_t iVar1;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019751c;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x180197527;
    iVar1 = fcn.18020eec0();
    if (iVar1 == 0) {
        return 1;
    }
    if (*(int32_t *)(param_1 + 0x14) == 0) {
        LOCK();
        *(int32_t *)(param_1 + 0x78) = *(int32_t *)(param_1 + 0x78) + 1;
        UNLOCK();
    }
    return 1;
}

// ============================================================
// Function: FUN_180197550
// Address: 0x180197550
// Size: 97 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180197550(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t iVar2;
    uint64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180197565;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180197577;
    iVar2 = fcn.1801bcb40(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180197581;
        fcn.180229b10();
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180197588;
        fcn.18022ccf0(in_RDX & 0xffffffff);
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180197596;
        iVar2 = fcn.180215540(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8)
                             );
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18019759e;
        fcn.1802299d0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    }
    return iVar2;
}

// ============================================================
// Function: FUN_1801975c0
// Address: 0x1801975c0
// Size: 46 bytes
// ============================================================
void fcn.1801975c0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801975d0;
        iVar1 = fcn.18045a350();
        *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x1801975db;
        iVar2 = fcn.18020f790();
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x1801975e8;
            fcn.180215590(arg1);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801975f0
// Address: 0x1801975f0
// Size: 52 bytes
// ============================================================
undefined8 fcn.1801975f0(int64_t param_1)
{
    int64_t iVar1;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801975fc;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x180197607;
    iVar1 = fcn.18020f790();
    if (iVar1 == 0) {
        return 1;
    }
    if (*(int32_t *)(param_1 + 0x10) == 0) {
        LOCK();
        *(int32_t *)(param_1 + 0x70) = *(int32_t *)(param_1 + 0x70) + 1;
        UNLOCK();
    }
    return 1;
}

// ============================================================
// Function: FUN_180197630
// Address: 0x180197630
// Size: 90 bytes
// ============================================================
undefined8 fcn.180197630(int64_t param_1)
{
    code *pcVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18019763c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int64_t *)(param_1 + 0x60) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180197652;
        uVar4 = fcn.18021a8e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
        *(undefined8 *)(param_1 + 0x58) = uVar4;
        pcVar1 = *(code **)(*(int64_t *)(param_1 + 0xc70) + 0x58);
        uVar2 = *(undefined8 *)(param_1 + 0xc80);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019766e;
        (*pcVar1)(uVar2, uVar4);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180197677;
        fcn.180219f80(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)(param_1 + 0x60) = 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_180197770
// Address: 0x180197770
// Size: 250 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180197770(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t iVar6;
    uint64_t in_R8;
    uint64_t *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x180197792;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = *(undefined8 *)(in_RCX + 0x1b0);
    iVar6 = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801977b2;
    iVar2 = func_0x00018020f590(uVar1);
    if ((iVar2 < 0) || (in_R8 < (uint64_t)(int64_t)iVar2)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180197815;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        iVar5 = iVar6;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801977c5;
        iVar5 = func_0x000180215470();
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801977d2;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801977e4;
            iVar3 = func_0x000180214b00(iVar5, uVar1);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801977f6;
                iVar3 = func_0x0001802146d0(iVar5, in_RDX, 0);
                if (0 < iVar3) {
                    *in_R9 = (int64_t)iVar2;
                    iVar6 = 1;
                    goto code_r0x000180197843;
                }
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180197809;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18019782d;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                  *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4));
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180197843;
    func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
code_r0x000180197843:
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18019784b;
    func_0x000180215310(iVar5);
    return iVar6;
}

// ============================================================
// Function: FUN_180197870
// Address: 0x180197870
// Size: 241 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.180197870(int64_t arg_28h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t iVar4;
    int64_t *piVar5;
    int32_t in_EDX;
    bool bVar6;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180197880;
    iVar2 = fcn.18045a350();
    if ((in_EDX < 0) || (*(int32_t *)(in_RCX + 0x118) <= in_EDX)) {
        return false;
    }
    bVar6 = *(int32_t *)(in_RCX + 0x78) == 0;
    iVar4 = 0x15a8;
    if (bVar6) {
        iVar4 = 0x1598;
    }
    iVar3 = 0x15a0;
    if (bVar6) {
        iVar3 = 0x1590;
    }
    iVar3 = *(int64_t *)(iVar3 + in_RCX);
    if (iVar3 == 0) {
        piVar5 = (int64_t *)(*(int64_t *)(in_RCX + 0x878) + 0x20);
    } else {
        uVar1 = *(undefined8 *)(iVar4 + in_RCX);
        *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x18019790f;
        iVar2 = func_0x000180498a80(iVar3, 2, uVar1);
        piVar5 = (int64_t *)(*(int64_t *)(in_RCX + 0x878) + 0x20);
        if (iVar2 != 0) {
            return *(int64_t *)(*piVar5 + 8 + (int64_t)in_EDX * 0x28) != 0;
        }
    }
    iVar2 = (int64_t)in_EDX * 0x28;
    if ((*(int64_t *)(*piVar5 + iVar2) != 0) && (*(int64_t *)(*piVar5 + 8 + iVar2) != 0)) {
        return true;
    }
    return false;
}

// ============================================================
// Function: FUN_180197970
// Address: 0x180197970
// Size: 36 bytes
// ============================================================
undefined8 fcn.180197970(int64_t arg_28h)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18019797c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int64_t *)(in_RCX + 0x60) != 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019799e;
    fcn.1802277e0();
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801979a6;
    iVar5 = fcn.18021a7c0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)(&stack0x00000050 + iVar4));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801979c4;
        iVar3 = fcn.18021a790(*(int64_t *)(&stack0x00000038 + iVar4));
        if (0 < iVar3) {
            uVar1 = *(undefined8 *)(in_RCX + 0x58);
            *(int64_t *)(in_RCX + 0x60) = iVar5;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801979d8;
            uVar6 = fcn.18021a960(iVar5, uVar1);
            *(undefined8 *)(in_RCX + 0x58) = uVar6;
            pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0xc70) + 0x58);
            uVar1 = *(undefined8 *)(in_RCX + 0xc80);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801979f4;
            (*pcVar2)(uVar1, uVar6);
            return 1;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180197a0c;
    fcn.180219f80(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180197a11;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180197a29;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                  *(int64_t *)(&stack0x00000048 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180197a3b;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_180197994
// Address: 0x180197994
// Size: 112 bytes
// ============================================================
undefined8 fcn.180197970(int64_t arg_28h)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18019797c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int64_t *)(in_RCX + 0x60) != 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019799e;
    fcn.1802277e0();
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801979a6;
    iVar5 = fcn.18021a7c0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)(&stack0x00000050 + iVar4));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801979c4;
        iVar3 = fcn.18021a790(*(int64_t *)(&stack0x00000038 + iVar4));
        if (0 < iVar3) {
            uVar1 = *(undefined8 *)(in_RCX + 0x58);
            *(int64_t *)(in_RCX + 0x60) = iVar5;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801979d8;
            uVar6 = fcn.18021a960(iVar5, uVar1);
            *(undefined8 *)(in_RCX + 0x58) = uVar6;
            pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0xc70) + 0x58);
            uVar1 = *(undefined8 *)(in_RCX + 0xc80);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801979f4;
            (*pcVar2)(uVar1, uVar6);
            return 1;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180197a0c;
    fcn.180219f80(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180197a11;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180197a29;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                  *(int64_t *)(&stack0x00000048 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180197a3b;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_180197a04
// Address: 0x180197a04
// Size: 68 bytes
// ============================================================
undefined8 fcn.180197970(int64_t arg_28h)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18019797c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int64_t *)(in_RCX + 0x60) != 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019799e;
    fcn.1802277e0();
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801979a6;
    iVar5 = fcn.18021a7c0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)(&stack0x00000050 + iVar4));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801979c4;
        iVar3 = fcn.18021a790(*(int64_t *)(&stack0x00000038 + iVar4));
        if (0 < iVar3) {
            uVar1 = *(undefined8 *)(in_RCX + 0x58);
            *(int64_t *)(in_RCX + 0x60) = iVar5;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801979d8;
            uVar6 = fcn.18021a960(iVar5, uVar1);
            *(undefined8 *)(in_RCX + 0x58) = uVar6;
            pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0xc70) + 0x58);
            uVar1 = *(undefined8 *)(in_RCX + 0xc80);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801979f4;
            (*pcVar2)(uVar1, uVar6);
            return 1;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180197a0c;
    fcn.180219f80(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180197a11;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180197a29;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                  *(int64_t *)(&stack0x00000048 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180197a3b;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_180197a50
// Address: 0x180197a50
// Size: 154 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180197a50(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int32_t *piVar2;
    int32_t *piVar3;
    int32_t *piVar4;
    int32_t *piVar5;
    int64_t iVar6;
    int32_t *piVar7;
    undefined8 uVar8;
    int32_t **in_RCX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180197a6a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    piVar2 = *in_RCX;
    piVar3 = in_RCX[1];
    piVar4 = in_RCX[2];
    if (piVar2 == (int32_t *)0x0) {
        return 0xffffffff;
    }
    piVar7 = piVar2;
    if (*piVar2 != 0) {
        if (-1 < (char)*piVar2) {
            return 0xffffffff;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180197a97;
        piVar7 = (int32_t *)func_0x0001801bda50(piVar2);
        if (piVar7 == (int32_t *)0x0) {
            return 0xffffffff;
        }
    }
    iVar1 = *(int32_t *)(in_RCX + 3);
    if ((iVar1 != 0) && (iVar1 != 1)) {
        if (iVar1 != 2) {
            return 0xffffffff;
        }
        piVar3 = in_RCX[4];
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180197ab6;
        uVar8 = (*(code *)piVar3)(piVar2);
        return uVar8;
    }
    piVar5 = in_RCX[4];
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180197ace;
    uVar8 = (*(code *)piVar5)(piVar2, piVar3, piVar4, piVar7 + 0x54c);
    return uVar8;
}

// ============================================================
// Function: FUN_180197af0
// Address: 0x180197af0
// Size: 128 bytes
// ============================================================
undefined8 fcn.180197af0(int64_t arg_58h)
{
    int64_t iVar1;
    undefined8 uVar2;
    uint64_t in_R8;
    undefined8 in_R9;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180197afc;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (in_R8 < 8) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180197b0d;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180197b25;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180197b3b;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar1));
        return 0;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar1) = *(undefined8 *)((int64_t)&arg_58h + iVar1);
    *(undefined8 *)((int64_t)&var_18h + iVar1) = in_R9;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180197b6a;
    uVar2 = fcn.1801952d0(*(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                          *(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1), 
                          *(int64_t *)(&stack0x00000048 + iVar1), *(int64_t *)(&stack0x00000050 + iVar1));
    return uVar2;
}

// ============================================================
// Function: FUN_180197b70
// Address: 0x180197b70
// Size: 58 bytes
// ============================================================
void fcn.180197b70(int64_t arg_28h)
{
    int64_t iVar1;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180197b7a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = in_R9;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = in_R8;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180197ba5;
    fcn.1801952d0(*(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                  *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1), *(int64_t *)(&stack0x00000058 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180197bb0
// Address: 0x180197bb0
// Size: 401 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.180197bb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
             int64_t arg_70h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t *piVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int32_t *in_RCX;
    undefined8 in_RDX;
    undefined8 in_R8;
    undefined8 *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180197bd0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX != (int32_t *)0x0) {
        piVar4 = in_RCX;
        if (*in_RCX != 0) {
            if ((char)*in_RCX < '\0') {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180197bf8;
                piVar4 = (int32_t *)func_0x0001801bda50();
            } else {
                piVar4 = (int32_t *)0x0;
            }
        }
        if ((*(uint8_t *)in_RCX & 0x80) != 0) {
code_r0x000180197c04:
            pcVar1 = *(code **)(*(int64_t *)(in_RCX + 6) + 0x50);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180197c1b;
            uVar5 = (*pcVar1)(in_RCX, in_RDX, in_R8, in_R9);
            return uVar5;
        }
        if (piVar4 != (int32_t *)0x0) {
            if (*(int64_t *)(piVar4 + 0x1c) == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180197c2e;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180197c46;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                              *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180197c58;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            } else {
                if ((*(uint8_t *)(piVar4 + 0x21) & 2) != 0) {
                    piVar4[0x1a] = 1;
                    return 0;
                }
                if ((piVar4[0x3c] == 1) || (piVar4[0x3c] == 8)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180197d10;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180197d28;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                                  *(int64_t *)(&stack0x00000048 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180197d3a;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
                    return 0;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180197ca6;
                iVar2 = func_0x00018019b3c0(piVar4, 0);
                if (iVar2 != 0) {
                    if ((piVar4[0x26c] & 0x100U) != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180197cbf;
                        iVar6 = func_0x0001802395d0();
                        if (iVar6 == 0) {
                            *(undefined4 *)((int64_t)&arg_30h + iVar3) = 0;
                            iVar6 = *(int64_t *)(in_RCX + 6);
                            *(int32_t **)((int64_t)&var_18h + iVar3) = in_RCX;
                            *(undefined8 *)((int64_t)&var_20h + iVar3) = in_RDX;
                            *(undefined8 *)((int64_t)&arg_28h + iVar3) = in_R8;
                            *(undefined8 *)((int64_t)&arg_38h + iVar3) = *(undefined8 *)(iVar6 + 0x50);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180197cfc;
                            uVar5 = func_0x000180198150(in_RCX, (int64_t)&var_18h + iVar3, fcn.180197a50);
                            *in_R9 = *(undefined8 *)(piVar4 + 0x54c);
                            return uVar5;
                        }
                    }
                    goto code_r0x000180197c04;
                }
            }
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_180197d50
// Address: 0x180197d50
// Size: 68 bytes
// ============================================================
int32_t fcn.180197d50(int32_t *param_1, int32_t *param_2)
{
    uint32_t uVar1;
    uint64_t uVar2;
    uint64_t *puVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    bool bVar7;
    
    fcn.18045a350();
    if ((*param_1 != *param_2) || (uVar5 = *(uint64_t *)(param_1 + 0x94), uVar5 != *(uint64_t *)(param_2 + 0x94))) {
        return 1;
    }
    puVar3 = (uint64_t *)(param_1 + 0x96);
    iVar4 = (int64_t)param_2 + (600 - (int64_t)puVar3);
    if (7 < uVar5) {
        for (; ((uint64_t)puVar3 & 7) != 0; puVar3 = (uint64_t *)((int64_t)puVar3 + 1)) {
            bVar7 = *(uint8_t *)puVar3 < *(uint8_t *)((int64_t)puVar3 + iVar4);
            if (*(uint8_t *)puVar3 != *(uint8_t *)((int64_t)puVar3 + iVar4)) goto code_r0x000180497f73;
            uVar5 = uVar5 - 1;
        }
        if (uVar5 >> 3 != 0) {
            uVar6 = uVar5 >> 5;
            if (uVar6 != 0) {
                do {
                    uVar2 = *puVar3;
                    if (uVar2 != *(uint64_t *)((int64_t)puVar3 + iVar4)) goto code_r0x000180497fe4;
                    uVar2 = puVar3[1];
                    if (uVar2 != *(uint64_t *)((int64_t)puVar3 + iVar4 + 8)) {
code_r0x000180497fe0:
                        puVar3 = puVar3 + 1;
                        goto code_r0x000180497fe4;
                    }
                    uVar2 = puVar3[2];
                    if (uVar2 != *(uint64_t *)((int64_t)puVar3 + iVar4 + 0x10)) {
code_r0x000180497fdc:
                        puVar3 = puVar3 + 1;
                        goto code_r0x000180497fe0;
                    }
                    uVar2 = puVar3[3];
                    if (uVar2 != *(uint64_t *)((int64_t)puVar3 + iVar4 + 0x18)) {
                        puVar3 = puVar3 + 1;
                        goto code_r0x000180497fdc;
                    }
                    puVar3 = puVar3 + 4;
                    uVar6 = uVar6 - 1;
                } while (uVar6 != 0);
                uVar5 = uVar5 & 0x1f;
            }
            uVar6 = uVar5 >> 3;
            if (uVar6 != 0) {
                do {
                    uVar2 = *puVar3;
                    if (uVar2 != *(uint64_t *)((int64_t)puVar3 + iVar4)) {
code_r0x000180497fe4:
                        uVar5 = *(uint64_t *)(iVar4 + (int64_t)puVar3);
                        uVar1 = (uint32_t)
                                ((uVar2 >> 0x38 | (uVar2 & 0xff000000000000) >> 0x28 | (uVar2 & 0xff0000000000) >> 0x18
                                  | (uVar2 & 0xff00000000) >> 8 | (uVar2 & 0xff000000) << 8 | (uVar2 & 0xff0000) << 0x18
                                  | (uVar2 & 0xff00) << 0x28 | uVar2 << 0x38) <
                                (uVar5 >> 0x38 | (uVar5 & 0xff000000000000) >> 0x28 | (uVar5 & 0xff0000000000) >> 0x18 |
                                 (uVar5 & 0xff00000000) >> 8 | (uVar5 & 0xff000000) << 8 | (uVar5 & 0xff0000) << 0x18 |
                                 (uVar5 & 0xff00) << 0x28 | uVar5 << 0x38));
                        return (1 - uVar1) - (uint32_t)(uVar1 != 0);
                    }
                    puVar3 = puVar3 + 1;
                    uVar6 = uVar6 - 1;
                } while (uVar6 != 0);
                uVar5 = uVar5 & 7;
            }
        }
    }
    while( true ) {
        if (uVar5 == 0) {
            return 0;
        }
        bVar7 = *(uint8_t *)puVar3 < *(uint8_t *)((int64_t)puVar3 + iVar4);
        if (*(uint8_t *)puVar3 != *(uint8_t *)((int64_t)puVar3 + iVar4)) break;
        puVar3 = (uint64_t *)((int64_t)puVar3 + 1);
        uVar5 = uVar5 - 1;
    }
code_r0x000180497f73:
    return (1 - (uint32_t)bVar7) - (uint32_t)(bVar7 != 0);
}

// ============================================================
// Function: FUN_180197da0
// Address: 0x180197da0
// Size: 91 bytes
// ============================================================
undefined4 fcn.180197da0(int64_t arg_60h)
{
    int64_t iVar1;
    int64_t in_RCX;
    undefined4 *puVar2;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180197daa;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    puVar2 = (undefined4 *)(in_RCX + 600);
    if (*(uint64_t *)(in_RCX + 0x250) < 4) {
        *(undefined4 *)((int64_t)&var_20h + iVar1) = 0;
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180197dd3;
        fcn.180498030((int64_t)&var_20h + iVar1);
        puVar2 = (undefined4 *)((int64_t)&var_20h + iVar1);
    }
    return *puVar2;
}

// ============================================================
// Function: FUN_180197e00
// Address: 0x180197e00
// Size: 44 bytes
// ============================================================
void fcn.180197e00(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                  int64_t arg_a0h)
{
    int64_t iVar1;
    uint32_t *puVar2;
    undefined8 uVar3;
    int32_t iVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int32_t *piVar9;
    int32_t *piVar10;
    int32_t *in_RCX;
    uint32_t uVar11;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    uint32_t uVar12;
    undefined8 unaff_R15;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180197e0f;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar1 = *(int64_t *)(in_RCX + 0x21e);
    puVar2 = *(uint32_t **)(in_RCX + 0x102);
    if (iVar1 == 0) {
        return;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar8) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_28h + iVar8) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_20h + iVar8) = unaff_R12;
    *(undefined8 *)((int64_t)&var_18h + iVar8) = unaff_R14;
    piVar10 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&var_10h + iVar8) = unaff_R15;
    if (((*(int64_t *)(iVar1 + 8) != 0) || (*(int64_t *)(iVar1 + 0x10) != 0)) ||
       (iVar7 = 0, *(int32_t *)(iVar1 + 0x18) != 0)) {
        iVar7 = 1;
    }
    *(uint32_t *)((int64_t)&arg_60h + iVar8) = *puVar2 & 1;
    *(uint32_t *)((int64_t)&arg_68h + iVar8) = puVar2[2] & 1;
    *(uint32_t *)((int64_t)&arg_70h + iVar8) = puVar2[3] & 1;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197e93;
    iVar4 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
    uVar11 = -(uint32_t)(iVar4 != 0) & 0x210;
    uVar12 = -(uint32_t)(iVar4 != 0) & 0x80;
    *(uint32_t *)((int64_t)&arg_58h + iVar8) = uVar12;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197ebd;
    iVar4 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
    if (iVar4 != 0) {
        uVar12 = 0x80;
        uVar11 = 0x210;
        *(undefined4 *)((int64_t)&arg_58h + iVar8) = 0x80;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197ede;
    iVar4 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
    uVar12 = uVar12 | 0x20;
    if (iVar4 == 0) {
        uVar12 = *(uint32_t *)((int64_t)&arg_58h + iVar8);
    }
    uVar5 = uVar11 | 0x10;
    if (iVar4 == 0) {
        uVar5 = uVar11;
    }
    if (*(int32_t *)((int64_t)&arg_60h + iVar8) == 0) {
        uVar11 = uVar5 | 2;
        if (iVar7 == 0) {
            uVar11 = uVar5;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197f22;
        iVar7 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
        if ((iVar7 != 0) && ((puVar2[1] & 0x100) != 0)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197f37;
            uVar5 = func_0x000180194ed0(in_RCX);
            if ((uVar5 & 0xffffff00) == 0x300) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197f4b;
                iVar7 = func_0x000180194ed0(in_RCX);
                if (iVar7 == 0x303) goto code_r0x000180197f52;
            }
        }
    } else {
        uVar11 = uVar5 | 3;
        if (iVar7 == 0) {
            uVar11 = uVar5 | 1;
        }
code_r0x000180197f52:
        uVar12 = uVar12 | 1;
    }
    uVar5 = uVar11 | 1;
    if ((*puVar2 & 0x1000) == 0) {
        uVar5 = uVar11;
    }
    uVar11 = uVar12 | 2;
    if (*(int32_t *)((int64_t)&arg_68h + iVar8) == 0) {
        uVar11 = uVar12;
    }
    uVar11 = uVar11 | ((*puVar2 & 0x1000) != 0) + 4;
    if ((puVar2[3] & 0x1000) != 0) {
        uVar11 = uVar11 | 8;
    }
    piVar9 = in_RCX;
    if ((*in_RCX != 0) && (piVar9 = piVar10, (char)*in_RCX < '\0')) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197fb1;
        piVar9 = (int32_t *)func_0x0001801bda50(in_RCX);
    }
    iVar7 = *in_RCX;
    if ((((iVar7 == 0x80) || (iVar7 == 0x81)) || (piVar9 == (int32_t *)0x0)) || ((piVar9[0x12] & 0xffffff00U) != 0x300))
    goto code_r0x00018019803e;
    piVar9 = in_RCX;
    if (iVar7 == 0) {
code_r0x000180198010:
        iVar7 = piVar9[0x12];
    } else {
        if ((char)iVar7 < '\0') {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197ff1;
            piVar10 = (int32_t *)func_0x0001801bda50(in_RCX);
        }
        iVar7 = 1;
        if (((*in_RCX != 0x80) && (*in_RCX != 0x81)) && (piVar9 = piVar10, iVar7 = 0, piVar10 != (int32_t *)0x0))
        goto code_r0x000180198010;
    }
    if (iVar7 == 0x303) {
        if ((puVar2[1] & 0x1000) != 0) {
            uVar11 = uVar11 | 1;
        }
        if (((puVar2[7] & 0x1000) != 0) || ((puVar2[8] & 0x1000) != 0)) {
            uVar11 = uVar11 | 8;
        }
    }
code_r0x00018019803e:
    if (*(int32_t *)((int64_t)&arg_70h + iVar8) != 0) {
        uVar3 = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x78);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18019805a;
        uVar6 = fcn.18023bbe0(uVar3);
        uVar12 = 0;
        if ((*(uint8_t *)(puVar2 + 3) & 2) != 0) {
            uVar12 = uVar6 & 0x80;
        }
        if (uVar12 != 0) {
            uVar11 = uVar11 | 8;
        }
    }
    if ((uVar11 & 8) == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18019808a;
        iVar7 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
        if ((iVar7 != 0) && ((puVar2[7] & 0x100) != 0)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18019809f;
            uVar12 = func_0x000180194ed0(in_RCX);
            if ((uVar12 & 0xffffff00) == 0x300) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980b3;
                iVar7 = func_0x000180194ed0(in_RCX);
                if (iVar7 == 0x303) {
                    uVar11 = uVar11 | 8;
                }
            }
        }
        if ((uVar11 & 8) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980cf;
            iVar7 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
            if ((iVar7 != 0) && ((puVar2[8] & 0x100) != 0)) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980e4;
                uVar12 = func_0x000180194ed0(in_RCX);
                if ((uVar12 & 0xffffff00) == 0x300) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980f8;
                    iVar7 = func_0x000180194ed0(in_RCX);
                    if (iVar7 == 0x303) {
                        uVar11 = uVar11 | 8;
                    }
                }
            }
        }
    }
    uVar12 = uVar5 | 0xc;
    if ((uVar5 & 1) != 0) {
        uVar12 = uVar5 | 0x4c;
    }
    in_RCX[0x105] = uVar11 | 0x10;
    uVar11 = uVar12 | 0x100;
    if ((uVar12 & 2) == 0) {
        uVar11 = uVar12;
    }
    in_RCX[0x104] = uVar11 | 0x80;
    return;
}

// ============================================================
// Function: FUN_180197e2c
// Address: 0x180197e2c
// Size: 5 bytes
// ============================================================
void fcn.180197e00(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                  int64_t arg_a0h)
{
    int64_t iVar1;
    uint32_t *puVar2;
    undefined8 uVar3;
    int32_t iVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int32_t *piVar9;
    int32_t *piVar10;
    int32_t *in_RCX;
    uint32_t uVar11;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    uint32_t uVar12;
    undefined8 unaff_R15;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180197e0f;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar1 = *(int64_t *)(in_RCX + 0x21e);
    puVar2 = *(uint32_t **)(in_RCX + 0x102);
    if (iVar1 == 0) {
        return;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar8) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_28h + iVar8) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_20h + iVar8) = unaff_R12;
    *(undefined8 *)((int64_t)&var_18h + iVar8) = unaff_R14;
    piVar10 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&var_10h + iVar8) = unaff_R15;
    if (((*(int64_t *)(iVar1 + 8) != 0) || (*(int64_t *)(iVar1 + 0x10) != 0)) ||
       (iVar7 = 0, *(int32_t *)(iVar1 + 0x18) != 0)) {
        iVar7 = 1;
    }
    *(uint32_t *)((int64_t)&arg_60h + iVar8) = *puVar2 & 1;
    *(uint32_t *)((int64_t)&arg_68h + iVar8) = puVar2[2] & 1;
    *(uint32_t *)((int64_t)&arg_70h + iVar8) = puVar2[3] & 1;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197e93;
    iVar4 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
    uVar11 = -(uint32_t)(iVar4 != 0) & 0x210;
    uVar12 = -(uint32_t)(iVar4 != 0) & 0x80;
    *(uint32_t *)((int64_t)&arg_58h + iVar8) = uVar12;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197ebd;
    iVar4 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
    if (iVar4 != 0) {
        uVar12 = 0x80;
        uVar11 = 0x210;
        *(undefined4 *)((int64_t)&arg_58h + iVar8) = 0x80;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197ede;
    iVar4 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
    uVar12 = uVar12 | 0x20;
    if (iVar4 == 0) {
        uVar12 = *(uint32_t *)((int64_t)&arg_58h + iVar8);
    }
    uVar5 = uVar11 | 0x10;
    if (iVar4 == 0) {
        uVar5 = uVar11;
    }
    if (*(int32_t *)((int64_t)&arg_60h + iVar8) == 0) {
        uVar11 = uVar5 | 2;
        if (iVar7 == 0) {
            uVar11 = uVar5;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197f22;
        iVar7 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
        if ((iVar7 != 0) && ((puVar2[1] & 0x100) != 0)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197f37;
            uVar5 = func_0x000180194ed0(in_RCX);
            if ((uVar5 & 0xffffff00) == 0x300) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197f4b;
                iVar7 = func_0x000180194ed0(in_RCX);
                if (iVar7 == 0x303) goto code_r0x000180197f52;
            }
        }
    } else {
        uVar11 = uVar5 | 3;
        if (iVar7 == 0) {
            uVar11 = uVar5 | 1;
        }
code_r0x000180197f52:
        uVar12 = uVar12 | 1;
    }
    uVar5 = uVar11 | 1;
    if ((*puVar2 & 0x1000) == 0) {
        uVar5 = uVar11;
    }
    uVar11 = uVar12 | 2;
    if (*(int32_t *)((int64_t)&arg_68h + iVar8) == 0) {
        uVar11 = uVar12;
    }
    uVar11 = uVar11 | ((*puVar2 & 0x1000) != 0) + 4;
    if ((puVar2[3] & 0x1000) != 0) {
        uVar11 = uVar11 | 8;
    }
    piVar9 = in_RCX;
    if ((*in_RCX != 0) && (piVar9 = piVar10, (char)*in_RCX < '\0')) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197fb1;
        piVar9 = (int32_t *)func_0x0001801bda50(in_RCX);
    }
    iVar7 = *in_RCX;
    if ((((iVar7 == 0x80) || (iVar7 == 0x81)) || (piVar9 == (int32_t *)0x0)) || ((piVar9[0x12] & 0xffffff00U) != 0x300))
    goto code_r0x00018019803e;
    piVar9 = in_RCX;
    if (iVar7 == 0) {
code_r0x000180198010:
        iVar7 = piVar9[0x12];
    } else {
        if ((char)iVar7 < '\0') {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197ff1;
            piVar10 = (int32_t *)func_0x0001801bda50(in_RCX);
        }
        iVar7 = 1;
        if (((*in_RCX != 0x80) && (*in_RCX != 0x81)) && (piVar9 = piVar10, iVar7 = 0, piVar10 != (int32_t *)0x0))
        goto code_r0x000180198010;
    }
    if (iVar7 == 0x303) {
        if ((puVar2[1] & 0x1000) != 0) {
            uVar11 = uVar11 | 1;
        }
        if (((puVar2[7] & 0x1000) != 0) || ((puVar2[8] & 0x1000) != 0)) {
            uVar11 = uVar11 | 8;
        }
    }
code_r0x00018019803e:
    if (*(int32_t *)((int64_t)&arg_70h + iVar8) != 0) {
        uVar3 = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x78);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18019805a;
        uVar6 = fcn.18023bbe0(uVar3);
        uVar12 = 0;
        if ((*(uint8_t *)(puVar2 + 3) & 2) != 0) {
            uVar12 = uVar6 & 0x80;
        }
        if (uVar12 != 0) {
            uVar11 = uVar11 | 8;
        }
    }
    if ((uVar11 & 8) == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18019808a;
        iVar7 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
        if ((iVar7 != 0) && ((puVar2[7] & 0x100) != 0)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18019809f;
            uVar12 = func_0x000180194ed0(in_RCX);
            if ((uVar12 & 0xffffff00) == 0x300) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980b3;
                iVar7 = func_0x000180194ed0(in_RCX);
                if (iVar7 == 0x303) {
                    uVar11 = uVar11 | 8;
                }
            }
        }
        if ((uVar11 & 8) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980cf;
            iVar7 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
            if ((iVar7 != 0) && ((puVar2[8] & 0x100) != 0)) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980e4;
                uVar12 = func_0x000180194ed0(in_RCX);
                if ((uVar12 & 0xffffff00) == 0x300) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980f8;
                    iVar7 = func_0x000180194ed0(in_RCX);
                    if (iVar7 == 0x303) {
                        uVar11 = uVar11 | 8;
                    }
                }
            }
        }
    }
    uVar12 = uVar5 | 0xc;
    if ((uVar5 & 1) != 0) {
        uVar12 = uVar5 | 0x4c;
    }
    in_RCX[0x105] = uVar11 | 0x10;
    uVar11 = uVar12 | 0x100;
    if ((uVar12 & 2) == 0) {
        uVar11 = uVar12;
    }
    in_RCX[0x104] = uVar11 | 0x80;
    return;
}

// ============================================================
// Function: FUN_180197e31
// Address: 0x180197e31
// Size: 358 bytes
// ============================================================
void fcn.180197e00(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                  int64_t arg_a0h)
{
    int64_t iVar1;
    uint32_t *puVar2;
    undefined8 uVar3;
    int32_t iVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int32_t *piVar9;
    int32_t *piVar10;
    int32_t *in_RCX;
    uint32_t uVar11;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    uint32_t uVar12;
    undefined8 unaff_R15;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180197e0f;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar1 = *(int64_t *)(in_RCX + 0x21e);
    puVar2 = *(uint32_t **)(in_RCX + 0x102);
    if (iVar1 == 0) {
        return;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar8) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_28h + iVar8) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_20h + iVar8) = unaff_R12;
    *(undefined8 *)((int64_t)&var_18h + iVar8) = unaff_R14;
    piVar10 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&var_10h + iVar8) = unaff_R15;
    if (((*(int64_t *)(iVar1 + 8) != 0) || (*(int64_t *)(iVar1 + 0x10) != 0)) ||
       (iVar7 = 0, *(int32_t *)(iVar1 + 0x18) != 0)) {
        iVar7 = 1;
    }
    *(uint32_t *)((int64_t)&arg_60h + iVar8) = *puVar2 & 1;
    *(uint32_t *)((int64_t)&arg_68h + iVar8) = puVar2[2] & 1;
    *(uint32_t *)((int64_t)&arg_70h + iVar8) = puVar2[3] & 1;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197e93;
    iVar4 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
    uVar11 = -(uint32_t)(iVar4 != 0) & 0x210;
    uVar12 = -(uint32_t)(iVar4 != 0) & 0x80;
    *(uint32_t *)((int64_t)&arg_58h + iVar8) = uVar12;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197ebd;
    iVar4 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
    if (iVar4 != 0) {
        uVar12 = 0x80;
        uVar11 = 0x210;
        *(undefined4 *)((int64_t)&arg_58h + iVar8) = 0x80;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197ede;
    iVar4 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
    uVar12 = uVar12 | 0x20;
    if (iVar4 == 0) {
        uVar12 = *(uint32_t *)((int64_t)&arg_58h + iVar8);
    }
    uVar5 = uVar11 | 0x10;
    if (iVar4 == 0) {
        uVar5 = uVar11;
    }
    if (*(int32_t *)((int64_t)&arg_60h + iVar8) == 0) {
        uVar11 = uVar5 | 2;
        if (iVar7 == 0) {
            uVar11 = uVar5;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197f22;
        iVar7 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
        if ((iVar7 != 0) && ((puVar2[1] & 0x100) != 0)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197f37;
            uVar5 = func_0x000180194ed0(in_RCX);
            if ((uVar5 & 0xffffff00) == 0x300) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197f4b;
                iVar7 = func_0x000180194ed0(in_RCX);
                if (iVar7 == 0x303) goto code_r0x000180197f52;
            }
        }
    } else {
        uVar11 = uVar5 | 3;
        if (iVar7 == 0) {
            uVar11 = uVar5 | 1;
        }
code_r0x000180197f52:
        uVar12 = uVar12 | 1;
    }
    uVar5 = uVar11 | 1;
    if ((*puVar2 & 0x1000) == 0) {
        uVar5 = uVar11;
    }
    uVar11 = uVar12 | 2;
    if (*(int32_t *)((int64_t)&arg_68h + iVar8) == 0) {
        uVar11 = uVar12;
    }
    uVar11 = uVar11 | ((*puVar2 & 0x1000) != 0) + 4;
    if ((puVar2[3] & 0x1000) != 0) {
        uVar11 = uVar11 | 8;
    }
    piVar9 = in_RCX;
    if ((*in_RCX != 0) && (piVar9 = piVar10, (char)*in_RCX < '\0')) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197fb1;
        piVar9 = (int32_t *)func_0x0001801bda50(in_RCX);
    }
    iVar7 = *in_RCX;
    if ((((iVar7 == 0x80) || (iVar7 == 0x81)) || (piVar9 == (int32_t *)0x0)) || ((piVar9[0x12] & 0xffffff00U) != 0x300))
    goto code_r0x00018019803e;
    piVar9 = in_RCX;
    if (iVar7 == 0) {
code_r0x000180198010:
        iVar7 = piVar9[0x12];
    } else {
        if ((char)iVar7 < '\0') {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197ff1;
            piVar10 = (int32_t *)func_0x0001801bda50(in_RCX);
        }
        iVar7 = 1;
        if (((*in_RCX != 0x80) && (*in_RCX != 0x81)) && (piVar9 = piVar10, iVar7 = 0, piVar10 != (int32_t *)0x0))
        goto code_r0x000180198010;
    }
    if (iVar7 == 0x303) {
        if ((puVar2[1] & 0x1000) != 0) {
            uVar11 = uVar11 | 1;
        }
        if (((puVar2[7] & 0x1000) != 0) || ((puVar2[8] & 0x1000) != 0)) {
            uVar11 = uVar11 | 8;
        }
    }
code_r0x00018019803e:
    if (*(int32_t *)((int64_t)&arg_70h + iVar8) != 0) {
        uVar3 = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x78);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18019805a;
        uVar6 = fcn.18023bbe0(uVar3);
        uVar12 = 0;
        if ((*(uint8_t *)(puVar2 + 3) & 2) != 0) {
            uVar12 = uVar6 & 0x80;
        }
        if (uVar12 != 0) {
            uVar11 = uVar11 | 8;
        }
    }
    if ((uVar11 & 8) == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18019808a;
        iVar7 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
        if ((iVar7 != 0) && ((puVar2[7] & 0x100) != 0)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18019809f;
            uVar12 = func_0x000180194ed0(in_RCX);
            if ((uVar12 & 0xffffff00) == 0x300) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980b3;
                iVar7 = func_0x000180194ed0(in_RCX);
                if (iVar7 == 0x303) {
                    uVar11 = uVar11 | 8;
                }
            }
        }
        if ((uVar11 & 8) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980cf;
            iVar7 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
            if ((iVar7 != 0) && ((puVar2[8] & 0x100) != 0)) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980e4;
                uVar12 = func_0x000180194ed0(in_RCX);
                if ((uVar12 & 0xffffff00) == 0x300) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980f8;
                    iVar7 = func_0x000180194ed0(in_RCX);
                    if (iVar7 == 0x303) {
                        uVar11 = uVar11 | 8;
                    }
                }
            }
        }
    }
    uVar12 = uVar5 | 0xc;
    if ((uVar5 & 1) != 0) {
        uVar12 = uVar5 | 0x4c;
    }
    in_RCX[0x105] = uVar11 | 0x10;
    uVar11 = uVar12 | 0x100;
    if ((uVar12 & 2) == 0) {
        uVar11 = uVar12;
    }
    in_RCX[0x104] = uVar11 | 0x80;
    return;
}

// ============================================================
// Function: FUN_180197f97
// Address: 0x180197f97
// Size: 182 bytes
// ============================================================
void fcn.180197e00(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                  int64_t arg_a0h)
{
    int64_t iVar1;
    uint32_t *puVar2;
    undefined8 uVar3;
    int32_t iVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int32_t *piVar9;
    int32_t *piVar10;
    int32_t *in_RCX;
    uint32_t uVar11;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    uint32_t uVar12;
    undefined8 unaff_R15;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180197e0f;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar1 = *(int64_t *)(in_RCX + 0x21e);
    puVar2 = *(uint32_t **)(in_RCX + 0x102);
    if (iVar1 == 0) {
        return;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar8) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_28h + iVar8) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_20h + iVar8) = unaff_R12;
    *(undefined8 *)((int64_t)&var_18h + iVar8) = unaff_R14;
    piVar10 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&var_10h + iVar8) = unaff_R15;
    if (((*(int64_t *)(iVar1 + 8) != 0) || (*(int64_t *)(iVar1 + 0x10) != 0)) ||
       (iVar7 = 0, *(int32_t *)(iVar1 + 0x18) != 0)) {
        iVar7 = 1;
    }
    *(uint32_t *)((int64_t)&arg_60h + iVar8) = *puVar2 & 1;
    *(uint32_t *)((int64_t)&arg_68h + iVar8) = puVar2[2] & 1;
    *(uint32_t *)((int64_t)&arg_70h + iVar8) = puVar2[3] & 1;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197e93;
    iVar4 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
    uVar11 = -(uint32_t)(iVar4 != 0) & 0x210;
    uVar12 = -(uint32_t)(iVar4 != 0) & 0x80;
    *(uint32_t *)((int64_t)&arg_58h + iVar8) = uVar12;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197ebd;
    iVar4 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
    if (iVar4 != 0) {
        uVar12 = 0x80;
        uVar11 = 0x210;
        *(undefined4 *)((int64_t)&arg_58h + iVar8) = 0x80;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197ede;
    iVar4 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
    uVar12 = uVar12 | 0x20;
    if (iVar4 == 0) {
        uVar12 = *(uint32_t *)((int64_t)&arg_58h + iVar8);
    }
    uVar5 = uVar11 | 0x10;
    if (iVar4 == 0) {
        uVar5 = uVar11;
    }
    if (*(int32_t *)((int64_t)&arg_60h + iVar8) == 0) {
        uVar11 = uVar5 | 2;
        if (iVar7 == 0) {
            uVar11 = uVar5;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197f22;
        iVar7 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
        if ((iVar7 != 0) && ((puVar2[1] & 0x100) != 0)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197f37;
            uVar5 = func_0x000180194ed0(in_RCX);
            if ((uVar5 & 0xffffff00) == 0x300) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197f4b;
                iVar7 = func_0x000180194ed0(in_RCX);
                if (iVar7 == 0x303) goto code_r0x000180197f52;
            }
        }
    } else {
        uVar11 = uVar5 | 3;
        if (iVar7 == 0) {
            uVar11 = uVar5 | 1;
        }
code_r0x000180197f52:
        uVar12 = uVar12 | 1;
    }
    uVar5 = uVar11 | 1;
    if ((*puVar2 & 0x1000) == 0) {
        uVar5 = uVar11;
    }
    uVar11 = uVar12 | 2;
    if (*(int32_t *)((int64_t)&arg_68h + iVar8) == 0) {
        uVar11 = uVar12;
    }
    uVar11 = uVar11 | ((*puVar2 & 0x1000) != 0) + 4;
    if ((puVar2[3] & 0x1000) != 0) {
        uVar11 = uVar11 | 8;
    }
    piVar9 = in_RCX;
    if ((*in_RCX != 0) && (piVar9 = piVar10, (char)*in_RCX < '\0')) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197fb1;
        piVar9 = (int32_t *)func_0x0001801bda50(in_RCX);
    }
    iVar7 = *in_RCX;
    if ((((iVar7 == 0x80) || (iVar7 == 0x81)) || (piVar9 == (int32_t *)0x0)) || ((piVar9[0x12] & 0xffffff00U) != 0x300))
    goto code_r0x00018019803e;
    piVar9 = in_RCX;
    if (iVar7 == 0) {
code_r0x000180198010:
        iVar7 = piVar9[0x12];
    } else {
        if ((char)iVar7 < '\0') {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197ff1;
            piVar10 = (int32_t *)func_0x0001801bda50(in_RCX);
        }
        iVar7 = 1;
        if (((*in_RCX != 0x80) && (*in_RCX != 0x81)) && (piVar9 = piVar10, iVar7 = 0, piVar10 != (int32_t *)0x0))
        goto code_r0x000180198010;
    }
    if (iVar7 == 0x303) {
        if ((puVar2[1] & 0x1000) != 0) {
            uVar11 = uVar11 | 1;
        }
        if (((puVar2[7] & 0x1000) != 0) || ((puVar2[8] & 0x1000) != 0)) {
            uVar11 = uVar11 | 8;
        }
    }
code_r0x00018019803e:
    if (*(int32_t *)((int64_t)&arg_70h + iVar8) != 0) {
        uVar3 = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x78);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18019805a;
        uVar6 = fcn.18023bbe0(uVar3);
        uVar12 = 0;
        if ((*(uint8_t *)(puVar2 + 3) & 2) != 0) {
            uVar12 = uVar6 & 0x80;
        }
        if (uVar12 != 0) {
            uVar11 = uVar11 | 8;
        }
    }
    if ((uVar11 & 8) == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18019808a;
        iVar7 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
        if ((iVar7 != 0) && ((puVar2[7] & 0x100) != 0)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18019809f;
            uVar12 = func_0x000180194ed0(in_RCX);
            if ((uVar12 & 0xffffff00) == 0x300) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980b3;
                iVar7 = func_0x000180194ed0(in_RCX);
                if (iVar7 == 0x303) {
                    uVar11 = uVar11 | 8;
                }
            }
        }
        if ((uVar11 & 8) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980cf;
            iVar7 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
            if ((iVar7 != 0) && ((puVar2[8] & 0x100) != 0)) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980e4;
                uVar12 = func_0x000180194ed0(in_RCX);
                if ((uVar12 & 0xffffff00) == 0x300) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980f8;
                    iVar7 = func_0x000180194ed0(in_RCX);
                    if (iVar7 == 0x303) {
                        uVar11 = uVar11 | 8;
                    }
                }
            }
        }
    }
    uVar12 = uVar5 | 0xc;
    if ((uVar5 & 1) != 0) {
        uVar12 = uVar5 | 0x4c;
    }
    in_RCX[0x105] = uVar11 | 0x10;
    uVar11 = uVar12 | 0x100;
    if ((uVar12 & 2) == 0) {
        uVar11 = uVar12;
    }
    in_RCX[0x104] = uVar11 | 0x80;
    return;
}

// ============================================================
// Function: FUN_18019804d
// Address: 0x18019804d
// Size: 48 bytes
// ============================================================
void fcn.180197e00(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                  int64_t arg_a0h)
{
    int64_t iVar1;
    uint32_t *puVar2;
    undefined8 uVar3;
    int32_t iVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int32_t *piVar9;
    int32_t *piVar10;
    int32_t *in_RCX;
    uint32_t uVar11;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    uint32_t uVar12;
    undefined8 unaff_R15;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180197e0f;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar1 = *(int64_t *)(in_RCX + 0x21e);
    puVar2 = *(uint32_t **)(in_RCX + 0x102);
    if (iVar1 == 0) {
        return;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar8) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_28h + iVar8) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_20h + iVar8) = unaff_R12;
    *(undefined8 *)((int64_t)&var_18h + iVar8) = unaff_R14;
    piVar10 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&var_10h + iVar8) = unaff_R15;
    if (((*(int64_t *)(iVar1 + 8) != 0) || (*(int64_t *)(iVar1 + 0x10) != 0)) ||
       (iVar7 = 0, *(int32_t *)(iVar1 + 0x18) != 0)) {
        iVar7 = 1;
    }
    *(uint32_t *)((int64_t)&arg_60h + iVar8) = *puVar2 & 1;
    *(uint32_t *)((int64_t)&arg_68h + iVar8) = puVar2[2] & 1;
    *(uint32_t *)((int64_t)&arg_70h + iVar8) = puVar2[3] & 1;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197e93;
    iVar4 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
    uVar11 = -(uint32_t)(iVar4 != 0) & 0x210;
    uVar12 = -(uint32_t)(iVar4 != 0) & 0x80;
    *(uint32_t *)((int64_t)&arg_58h + iVar8) = uVar12;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197ebd;
    iVar4 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
    if (iVar4 != 0) {
        uVar12 = 0x80;
        uVar11 = 0x210;
        *(undefined4 *)((int64_t)&arg_58h + iVar8) = 0x80;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197ede;
    iVar4 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
    uVar12 = uVar12 | 0x20;
    if (iVar4 == 0) {
        uVar12 = *(uint32_t *)((int64_t)&arg_58h + iVar8);
    }
    uVar5 = uVar11 | 0x10;
    if (iVar4 == 0) {
        uVar5 = uVar11;
    }
    if (*(int32_t *)((int64_t)&arg_60h + iVar8) == 0) {
        uVar11 = uVar5 | 2;
        if (iVar7 == 0) {
            uVar11 = uVar5;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197f22;
        iVar7 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
        if ((iVar7 != 0) && ((puVar2[1] & 0x100) != 0)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197f37;
            uVar5 = func_0x000180194ed0(in_RCX);
            if ((uVar5 & 0xffffff00) == 0x300) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197f4b;
                iVar7 = func_0x000180194ed0(in_RCX);
                if (iVar7 == 0x303) goto code_r0x000180197f52;
            }
        }
    } else {
        uVar11 = uVar5 | 3;
        if (iVar7 == 0) {
            uVar11 = uVar5 | 1;
        }
code_r0x000180197f52:
        uVar12 = uVar12 | 1;
    }
    uVar5 = uVar11 | 1;
    if ((*puVar2 & 0x1000) == 0) {
        uVar5 = uVar11;
    }
    uVar11 = uVar12 | 2;
    if (*(int32_t *)((int64_t)&arg_68h + iVar8) == 0) {
        uVar11 = uVar12;
    }
    uVar11 = uVar11 | ((*puVar2 & 0x1000) != 0) + 4;
    if ((puVar2[3] & 0x1000) != 0) {
        uVar11 = uVar11 | 8;
    }
    piVar9 = in_RCX;
    if ((*in_RCX != 0) && (piVar9 = piVar10, (char)*in_RCX < '\0')) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197fb1;
        piVar9 = (int32_t *)func_0x0001801bda50(in_RCX);
    }
    iVar7 = *in_RCX;
    if ((((iVar7 == 0x80) || (iVar7 == 0x81)) || (piVar9 == (int32_t *)0x0)) || ((piVar9[0x12] & 0xffffff00U) != 0x300))
    goto code_r0x00018019803e;
    piVar9 = in_RCX;
    if (iVar7 == 0) {
code_r0x000180198010:
        iVar7 = piVar9[0x12];
    } else {
        if ((char)iVar7 < '\0') {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197ff1;
            piVar10 = (int32_t *)func_0x0001801bda50(in_RCX);
        }
        iVar7 = 1;
        if (((*in_RCX != 0x80) && (*in_RCX != 0x81)) && (piVar9 = piVar10, iVar7 = 0, piVar10 != (int32_t *)0x0))
        goto code_r0x000180198010;
    }
    if (iVar7 == 0x303) {
        if ((puVar2[1] & 0x1000) != 0) {
            uVar11 = uVar11 | 1;
        }
        if (((puVar2[7] & 0x1000) != 0) || ((puVar2[8] & 0x1000) != 0)) {
            uVar11 = uVar11 | 8;
        }
    }
code_r0x00018019803e:
    if (*(int32_t *)((int64_t)&arg_70h + iVar8) != 0) {
        uVar3 = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x78);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18019805a;
        uVar6 = fcn.18023bbe0(uVar3);
        uVar12 = 0;
        if ((*(uint8_t *)(puVar2 + 3) & 2) != 0) {
            uVar12 = uVar6 & 0x80;
        }
        if (uVar12 != 0) {
            uVar11 = uVar11 | 8;
        }
    }
    if ((uVar11 & 8) == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18019808a;
        iVar7 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
        if ((iVar7 != 0) && ((puVar2[7] & 0x100) != 0)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18019809f;
            uVar12 = func_0x000180194ed0(in_RCX);
            if ((uVar12 & 0xffffff00) == 0x300) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980b3;
                iVar7 = func_0x000180194ed0(in_RCX);
                if (iVar7 == 0x303) {
                    uVar11 = uVar11 | 8;
                }
            }
        }
        if ((uVar11 & 8) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980cf;
            iVar7 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
            if ((iVar7 != 0) && ((puVar2[8] & 0x100) != 0)) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980e4;
                uVar12 = func_0x000180194ed0(in_RCX);
                if ((uVar12 & 0xffffff00) == 0x300) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980f8;
                    iVar7 = func_0x000180194ed0(in_RCX);
                    if (iVar7 == 0x303) {
                        uVar11 = uVar11 | 8;
                    }
                }
            }
        }
    }
    uVar12 = uVar5 | 0xc;
    if ((uVar5 & 1) != 0) {
        uVar12 = uVar5 | 0x4c;
    }
    in_RCX[0x105] = uVar11 | 0x10;
    uVar11 = uVar12 | 0x100;
    if ((uVar12 & 2) == 0) {
        uVar11 = uVar12;
    }
    in_RCX[0x104] = uVar11 | 0x80;
    return;
}

// ============================================================
// Function: FUN_18019807d
// Address: 0x18019807d
// Size: 192 bytes
// ============================================================
void fcn.180197e00(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                  int64_t arg_a0h)
{
    int64_t iVar1;
    uint32_t *puVar2;
    undefined8 uVar3;
    int32_t iVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int32_t *piVar9;
    int32_t *piVar10;
    int32_t *in_RCX;
    uint32_t uVar11;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    uint32_t uVar12;
    undefined8 unaff_R15;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180197e0f;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar1 = *(int64_t *)(in_RCX + 0x21e);
    puVar2 = *(uint32_t **)(in_RCX + 0x102);
    if (iVar1 == 0) {
        return;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar8) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_28h + iVar8) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_20h + iVar8) = unaff_R12;
    *(undefined8 *)((int64_t)&var_18h + iVar8) = unaff_R14;
    piVar10 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&var_10h + iVar8) = unaff_R15;
    if (((*(int64_t *)(iVar1 + 8) != 0) || (*(int64_t *)(iVar1 + 0x10) != 0)) ||
       (iVar7 = 0, *(int32_t *)(iVar1 + 0x18) != 0)) {
        iVar7 = 1;
    }
    *(uint32_t *)((int64_t)&arg_60h + iVar8) = *puVar2 & 1;
    *(uint32_t *)((int64_t)&arg_68h + iVar8) = puVar2[2] & 1;
    *(uint32_t *)((int64_t)&arg_70h + iVar8) = puVar2[3] & 1;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197e93;
    iVar4 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
    uVar11 = -(uint32_t)(iVar4 != 0) & 0x210;
    uVar12 = -(uint32_t)(iVar4 != 0) & 0x80;
    *(uint32_t *)((int64_t)&arg_58h + iVar8) = uVar12;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197ebd;
    iVar4 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
    if (iVar4 != 0) {
        uVar12 = 0x80;
        uVar11 = 0x210;
        *(undefined4 *)((int64_t)&arg_58h + iVar8) = 0x80;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197ede;
    iVar4 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
    uVar12 = uVar12 | 0x20;
    if (iVar4 == 0) {
        uVar12 = *(uint32_t *)((int64_t)&arg_58h + iVar8);
    }
    uVar5 = uVar11 | 0x10;
    if (iVar4 == 0) {
        uVar5 = uVar11;
    }
    if (*(int32_t *)((int64_t)&arg_60h + iVar8) == 0) {
        uVar11 = uVar5 | 2;
        if (iVar7 == 0) {
            uVar11 = uVar5;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197f22;
        iVar7 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
        if ((iVar7 != 0) && ((puVar2[1] & 0x100) != 0)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197f37;
            uVar5 = func_0x000180194ed0(in_RCX);
            if ((uVar5 & 0xffffff00) == 0x300) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197f4b;
                iVar7 = func_0x000180194ed0(in_RCX);
                if (iVar7 == 0x303) goto code_r0x000180197f52;
            }
        }
    } else {
        uVar11 = uVar5 | 3;
        if (iVar7 == 0) {
            uVar11 = uVar5 | 1;
        }
code_r0x000180197f52:
        uVar12 = uVar12 | 1;
    }
    uVar5 = uVar11 | 1;
    if ((*puVar2 & 0x1000) == 0) {
        uVar5 = uVar11;
    }
    uVar11 = uVar12 | 2;
    if (*(int32_t *)((int64_t)&arg_68h + iVar8) == 0) {
        uVar11 = uVar12;
    }
    uVar11 = uVar11 | ((*puVar2 & 0x1000) != 0) + 4;
    if ((puVar2[3] & 0x1000) != 0) {
        uVar11 = uVar11 | 8;
    }
    piVar9 = in_RCX;
    if ((*in_RCX != 0) && (piVar9 = piVar10, (char)*in_RCX < '\0')) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197fb1;
        piVar9 = (int32_t *)func_0x0001801bda50(in_RCX);
    }
    iVar7 = *in_RCX;
    if ((((iVar7 == 0x80) || (iVar7 == 0x81)) || (piVar9 == (int32_t *)0x0)) || ((piVar9[0x12] & 0xffffff00U) != 0x300))
    goto code_r0x00018019803e;
    piVar9 = in_RCX;
    if (iVar7 == 0) {
code_r0x000180198010:
        iVar7 = piVar9[0x12];
    } else {
        if ((char)iVar7 < '\0') {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197ff1;
            piVar10 = (int32_t *)func_0x0001801bda50(in_RCX);
        }
        iVar7 = 1;
        if (((*in_RCX != 0x80) && (*in_RCX != 0x81)) && (piVar9 = piVar10, iVar7 = 0, piVar10 != (int32_t *)0x0))
        goto code_r0x000180198010;
    }
    if (iVar7 == 0x303) {
        if ((puVar2[1] & 0x1000) != 0) {
            uVar11 = uVar11 | 1;
        }
        if (((puVar2[7] & 0x1000) != 0) || ((puVar2[8] & 0x1000) != 0)) {
            uVar11 = uVar11 | 8;
        }
    }
code_r0x00018019803e:
    if (*(int32_t *)((int64_t)&arg_70h + iVar8) != 0) {
        uVar3 = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x78);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18019805a;
        uVar6 = fcn.18023bbe0(uVar3);
        uVar12 = 0;
        if ((*(uint8_t *)(puVar2 + 3) & 2) != 0) {
            uVar12 = uVar6 & 0x80;
        }
        if (uVar12 != 0) {
            uVar11 = uVar11 | 8;
        }
    }
    if ((uVar11 & 8) == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18019808a;
        iVar7 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
        if ((iVar7 != 0) && ((puVar2[7] & 0x100) != 0)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18019809f;
            uVar12 = func_0x000180194ed0(in_RCX);
            if ((uVar12 & 0xffffff00) == 0x300) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980b3;
                iVar7 = func_0x000180194ed0(in_RCX);
                if (iVar7 == 0x303) {
                    uVar11 = uVar11 | 8;
                }
            }
        }
        if ((uVar11 & 8) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980cf;
            iVar7 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
            if ((iVar7 != 0) && ((puVar2[8] & 0x100) != 0)) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980e4;
                uVar12 = func_0x000180194ed0(in_RCX);
                if ((uVar12 & 0xffffff00) == 0x300) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980f8;
                    iVar7 = func_0x000180194ed0(in_RCX);
                    if (iVar7 == 0x303) {
                        uVar11 = uVar11 | 8;
                    }
                }
            }
        }
    }
    uVar12 = uVar5 | 0xc;
    if ((uVar5 & 1) != 0) {
        uVar12 = uVar5 | 0x4c;
    }
    in_RCX[0x105] = uVar11 | 0x10;
    uVar11 = uVar12 | 0x100;
    if ((uVar12 & 2) == 0) {
        uVar11 = uVar12;
    }
    in_RCX[0x104] = uVar11 | 0x80;
    return;
}

// ============================================================
// Function: FUN_18019813d
// Address: 0x18019813d
// Size: 9 bytes
// ============================================================
void fcn.180197e00(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                  int64_t arg_a0h)
{
    int64_t iVar1;
    uint32_t *puVar2;
    undefined8 uVar3;
    int32_t iVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int32_t *piVar9;
    int32_t *piVar10;
    int32_t *in_RCX;
    uint32_t uVar11;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    uint32_t uVar12;
    undefined8 unaff_R15;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180197e0f;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar1 = *(int64_t *)(in_RCX + 0x21e);
    puVar2 = *(uint32_t **)(in_RCX + 0x102);
    if (iVar1 == 0) {
        return;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar8) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_28h + iVar8) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_20h + iVar8) = unaff_R12;
    *(undefined8 *)((int64_t)&var_18h + iVar8) = unaff_R14;
    piVar10 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&var_10h + iVar8) = unaff_R15;
    if (((*(int64_t *)(iVar1 + 8) != 0) || (*(int64_t *)(iVar1 + 0x10) != 0)) ||
       (iVar7 = 0, *(int32_t *)(iVar1 + 0x18) != 0)) {
        iVar7 = 1;
    }
    *(uint32_t *)((int64_t)&arg_60h + iVar8) = *puVar2 & 1;
    *(uint32_t *)((int64_t)&arg_68h + iVar8) = puVar2[2] & 1;
    *(uint32_t *)((int64_t)&arg_70h + iVar8) = puVar2[3] & 1;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197e93;
    iVar4 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
    uVar11 = -(uint32_t)(iVar4 != 0) & 0x210;
    uVar12 = -(uint32_t)(iVar4 != 0) & 0x80;
    *(uint32_t *)((int64_t)&arg_58h + iVar8) = uVar12;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197ebd;
    iVar4 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
    if (iVar4 != 0) {
        uVar12 = 0x80;
        uVar11 = 0x210;
        *(undefined4 *)((int64_t)&arg_58h + iVar8) = 0x80;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197ede;
    iVar4 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
    uVar12 = uVar12 | 0x20;
    if (iVar4 == 0) {
        uVar12 = *(uint32_t *)((int64_t)&arg_58h + iVar8);
    }
    uVar5 = uVar11 | 0x10;
    if (iVar4 == 0) {
        uVar5 = uVar11;
    }
    if (*(int32_t *)((int64_t)&arg_60h + iVar8) == 0) {
        uVar11 = uVar5 | 2;
        if (iVar7 == 0) {
            uVar11 = uVar5;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197f22;
        iVar7 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
        if ((iVar7 != 0) && ((puVar2[1] & 0x100) != 0)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197f37;
            uVar5 = func_0x000180194ed0(in_RCX);
            if ((uVar5 & 0xffffff00) == 0x300) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197f4b;
                iVar7 = func_0x000180194ed0(in_RCX);
                if (iVar7 == 0x303) goto code_r0x000180197f52;
            }
        }
    } else {
        uVar11 = uVar5 | 3;
        if (iVar7 == 0) {
            uVar11 = uVar5 | 1;
        }
code_r0x000180197f52:
        uVar12 = uVar12 | 1;
    }
    uVar5 = uVar11 | 1;
    if ((*puVar2 & 0x1000) == 0) {
        uVar5 = uVar11;
    }
    uVar11 = uVar12 | 2;
    if (*(int32_t *)((int64_t)&arg_68h + iVar8) == 0) {
        uVar11 = uVar12;
    }
    uVar11 = uVar11 | ((*puVar2 & 0x1000) != 0) + 4;
    if ((puVar2[3] & 0x1000) != 0) {
        uVar11 = uVar11 | 8;
    }
    piVar9 = in_RCX;
    if ((*in_RCX != 0) && (piVar9 = piVar10, (char)*in_RCX < '\0')) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197fb1;
        piVar9 = (int32_t *)func_0x0001801bda50(in_RCX);
    }
    iVar7 = *in_RCX;
    if ((((iVar7 == 0x80) || (iVar7 == 0x81)) || (piVar9 == (int32_t *)0x0)) || ((piVar9[0x12] & 0xffffff00U) != 0x300))
    goto code_r0x00018019803e;
    piVar9 = in_RCX;
    if (iVar7 == 0) {
code_r0x000180198010:
        iVar7 = piVar9[0x12];
    } else {
        if ((char)iVar7 < '\0') {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x180197ff1;
            piVar10 = (int32_t *)func_0x0001801bda50(in_RCX);
        }
        iVar7 = 1;
        if (((*in_RCX != 0x80) && (*in_RCX != 0x81)) && (piVar9 = piVar10, iVar7 = 0, piVar10 != (int32_t *)0x0))
        goto code_r0x000180198010;
    }
    if (iVar7 == 0x303) {
        if ((puVar2[1] & 0x1000) != 0) {
            uVar11 = uVar11 | 1;
        }
        if (((puVar2[7] & 0x1000) != 0) || ((puVar2[8] & 0x1000) != 0)) {
            uVar11 = uVar11 | 8;
        }
    }
code_r0x00018019803e:
    if (*(int32_t *)((int64_t)&arg_70h + iVar8) != 0) {
        uVar3 = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x78);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18019805a;
        uVar6 = fcn.18023bbe0(uVar3);
        uVar12 = 0;
        if ((*(uint8_t *)(puVar2 + 3) & 2) != 0) {
            uVar12 = uVar6 & 0x80;
        }
        if (uVar12 != 0) {
            uVar11 = uVar11 | 8;
        }
    }
    if ((uVar11 & 8) == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18019808a;
        iVar7 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
        if ((iVar7 != 0) && ((puVar2[7] & 0x100) != 0)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18019809f;
            uVar12 = func_0x000180194ed0(in_RCX);
            if ((uVar12 & 0xffffff00) == 0x300) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980b3;
                iVar7 = func_0x000180194ed0(in_RCX);
                if (iVar7 == 0x303) {
                    uVar11 = uVar11 | 8;
                }
            }
        }
        if ((uVar11 & 8) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980cf;
            iVar7 = fcn.180197870(*(int64_t *)((int64_t)&iStackX_8 + iVar8));
            if ((iVar7 != 0) && ((puVar2[8] & 0x100) != 0)) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980e4;
                uVar12 = func_0x000180194ed0(in_RCX);
                if ((uVar12 & 0xffffff00) == 0x300) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801980f8;
                    iVar7 = func_0x000180194ed0(in_RCX);
                    if (iVar7 == 0x303) {
                        uVar11 = uVar11 | 8;
                    }
                }
            }
        }
    }
    uVar12 = uVar5 | 0xc;
    if ((uVar5 & 1) != 0) {
        uVar12 = uVar5 | 0x4c;
    }
    in_RCX[0x105] = uVar11 | 0x10;
    uVar11 = uVar12 | 0x100;
    if ((uVar12 & 2) == 0) {
        uVar11 = uVar12;
    }
    in_RCX[0x104] = uVar11 | 0x80;
    return;
}

// ============================================================
// Function: FUN_180198150
// Address: 0x180198150
// Size: 407 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined4 fcn.180198150(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t *piVar4;
    int64_t iVar5;
    int32_t *in_RCX;
    undefined8 in_RDX;
    undefined8 in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x18019816a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    piVar4 = in_RCX;
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198197;
        piVar4 = (int32_t *)func_0x0001801bda50();
        if (piVar4 == (int32_t *)0x0) {
            return 0;
        }
    }
    if (*(int64_t *)(piVar4 + 0x54a) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801981b2;
        iVar5 = func_0x000180239580();
        *(int64_t *)(piVar4 + 0x54a) = iVar5;
        if (iVar5 == 0) {
            return 0xffffffff;
        }
        if (*(int64_t *)(piVar4 + 0x55c) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801981de;
            iVar2 = func_0x0001802395b0(iVar5, 0x180196ee0, in_RCX);
            if (iVar2 == 0) {
                return 0xffffffff;
            }
        }
    }
    uVar1 = *(undefined8 *)(piVar4 + 0x54a);
    *(undefined8 *)((int64_t)&var_20h + iVar3) = 0x28;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = in_RDX;
    piVar4[0x1a] = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198216;
    iVar2 = func_0x000180239880(piVar4 + 0x548, uVar1, (int64_t)&arg_38h + iVar3, in_R8);
    if (iVar2 != 0) {
        if (iVar2 == 1) {
            piVar4[0x1a] = 6;
            return 0xffffffff;
        }
        if (iVar2 == 2) {
            piVar4[0x1a] = 5;
            return 0xffffffff;
        }
        if (iVar2 == 3) {
            *(undefined8 *)(piVar4 + 0x548) = 0;
            return *(undefined4 *)((int64_t)&arg_38h + iVar3);
        }
        piVar4[0x1a] = 1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198235;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019824d;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019825f;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0xffffffff;
    }
    piVar4[0x1a] = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019829f;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801982b7;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                  *(int64_t *)((int64_t)&arg_48h + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801982c9;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1801982f0
// Address: 0x1801982f0
// Size: 67 bytes
// ============================================================
undefined8 fcn.1801982f0(void)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801982fa;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180198302;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18019831a;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                  *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18019832c;
    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
    return 0;
}

// ============================================================
// Function: FUN_180198340
// Address: 0x180198340
// Size: 67 bytes
// ============================================================
undefined8 fcn.180198340(void)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18019834a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180198352;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18019836a;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                  *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18019837c;
    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
    return 0;
}

// ============================================================
// Function: FUN_180198390
// Address: 0x180198390
// Size: 94 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180198390(int64_t arg_28h, int64_t arg_30h)
{
    uint32_t uVar1;
    undefined8 uVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    int64_t iVar7;
    uint64_t in_RDX;
    uint32_t uVar8;
    undefined8 unaff_RDI;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801983a0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar7 = *(int64_t *)(in_RCX + 0x8f8);
    if (((*(int64_t *)(iVar7 + 0x250) != 0) && (*(int32_t *)(iVar7 + 0x2b0) == 0)) &&
       ((*(int32_t *)(in_RCX + 0x78) == 0 ||
        ((*(int64_t *)(iVar7 + 0x278) != 0 || ((*(uint8_t *)(in_RCX + 0x948) & 1) == 0)))))) {
        iVar7 = *(int64_t *)(in_RCX + 0xb88);
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RDI;
        uVar1 = *(uint32_t *)(iVar7 + 0x50);
        uVar8 = (uint32_t)in_RDX;
        if (((uVar8 & uVar1) != 0) &&
           ((*(int32_t *)(in_RCX + 0x508) == 0 ||
            ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0 &&
              (iVar4 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar4)) && (iVar4 != 0x10000)))))) {
            if (((uVar1 >> 9 & 1) == 0) &&
               ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0 ||
                 (iVar4 = **(int32_t **)(in_RCX + 0x18), iVar4 < 0x304)) ||
                ((((iVar4 == 0x10000 || (*(int32_t *)(in_RCX + 0x78) == 0)) ||
                  (((*(int32_t *)(in_RCX + 0x1538) != 0 && ((*(uint32_t *)(in_RCX + 0x9a8) >> 0x18 & 1) == 0)) ||
                   (*(int64_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x68) != 0)))) ||
                 ((*(uint32_t *)(in_RCX + 0x9a8) >> 0xe & 1) != 0)))))) {
                uVar2 = *(undefined8 *)(in_RCX + 0x8f8);
                uVar6 = *(undefined8 *)(in_RCX + 0xb88);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801984a5;
                func_0x00018019c530(uVar6, uVar2);
            }
            if (*(int64_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x60) != 0) {
                uVar2 = *(undefined8 *)(in_RCX + 0x8f8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801984bf;
                iVar4 = func_0x00018019ce20(uVar2);
                if (iVar4 != 0) {
                    uVar2 = *(undefined8 *)(in_RCX + 0x8f8);
                    uVar6 = *(undefined8 *)(in_RCX + 0x40);
                    pcVar3 = *(code **)(*(int64_t *)(in_RCX + 0xb88) + 0x60);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801984dc;
                    iVar4 = (*pcVar3)(uVar6, uVar2);
                    if (iVar4 == 0) {
                        uVar2 = *(undefined8 *)(in_RCX + 0x8f8);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801984ec;
                        func_0x00018019c980(uVar2);
                    }
                }
            }
        }
        if ((-1 < (char)uVar1) && ((uVar1 & uVar8) == uVar8)) {
            iVar7 = 0x80;
            if ((in_RDX & 1) == 0) {
                iVar7 = 0x8c;
            }
            if ((char)*(undefined4 *)(iVar7 + *(int64_t *)(in_RCX + 0xb88)) == -1) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019851e;
                uVar6 = func_0x000180467bd4(0);
                uVar2 = *(undefined8 *)(in_RCX + 0xb88);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019852d;
                func_0x00018019c780(uVar2, uVar6);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801983ee
// Address: 0x1801983ee
// Size: 324 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180198390(int64_t arg_28h, int64_t arg_30h)
{
    uint32_t uVar1;
    undefined8 uVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    int64_t iVar7;
    uint64_t in_RDX;
    uint32_t uVar8;
    undefined8 unaff_RDI;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801983a0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar7 = *(int64_t *)(in_RCX + 0x8f8);
    if (((*(int64_t *)(iVar7 + 0x250) != 0) && (*(int32_t *)(iVar7 + 0x2b0) == 0)) &&
       ((*(int32_t *)(in_RCX + 0x78) == 0 ||
        ((*(int64_t *)(iVar7 + 0x278) != 0 || ((*(uint8_t *)(in_RCX + 0x948) & 1) == 0)))))) {
        iVar7 = *(int64_t *)(in_RCX + 0xb88);
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RDI;
        uVar1 = *(uint32_t *)(iVar7 + 0x50);
        uVar8 = (uint32_t)in_RDX;
        if (((uVar8 & uVar1) != 0) &&
           ((*(int32_t *)(in_RCX + 0x508) == 0 ||
            ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0 &&
              (iVar4 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar4)) && (iVar4 != 0x10000)))))) {
            if (((uVar1 >> 9 & 1) == 0) &&
               ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0 ||
                 (iVar4 = **(int32_t **)(in_RCX + 0x18), iVar4 < 0x304)) ||
                ((((iVar4 == 0x10000 || (*(int32_t *)(in_RCX + 0x78) == 0)) ||
                  (((*(int32_t *)(in_RCX + 0x1538) != 0 && ((*(uint32_t *)(in_RCX + 0x9a8) >> 0x18 & 1) == 0)) ||
                   (*(int64_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x68) != 0)))) ||
                 ((*(uint32_t *)(in_RCX + 0x9a8) >> 0xe & 1) != 0)))))) {
                uVar2 = *(undefined8 *)(in_RCX + 0x8f8);
                uVar6 = *(undefined8 *)(in_RCX + 0xb88);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801984a5;
                func_0x00018019c530(uVar6, uVar2);
            }
            if (*(int64_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x60) != 0) {
                uVar2 = *(undefined8 *)(in_RCX + 0x8f8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801984bf;
                iVar4 = func_0x00018019ce20(uVar2);
                if (iVar4 != 0) {
                    uVar2 = *(undefined8 *)(in_RCX + 0x8f8);
                    uVar6 = *(undefined8 *)(in_RCX + 0x40);
                    pcVar3 = *(code **)(*(int64_t *)(in_RCX + 0xb88) + 0x60);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801984dc;
                    iVar4 = (*pcVar3)(uVar6, uVar2);
                    if (iVar4 == 0) {
                        uVar2 = *(undefined8 *)(in_RCX + 0x8f8);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801984ec;
                        func_0x00018019c980(uVar2);
                    }
                }
            }
        }
        if ((-1 < (char)uVar1) && ((uVar1 & uVar8) == uVar8)) {
            iVar7 = 0x80;
            if ((in_RDX & 1) == 0) {
                iVar7 = 0x8c;
            }
            if ((char)*(undefined4 *)(iVar7 + *(int64_t *)(in_RCX + 0xb88)) == -1) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019851e;
                uVar6 = func_0x000180467bd4(0);
                uVar2 = *(undefined8 *)(in_RCX + 0xb88);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019852d;
                func_0x00018019c780(uVar2, uVar6);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180198532
// Address: 0x180198532
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180198390(int64_t arg_28h, int64_t arg_30h)
{
    uint32_t uVar1;
    undefined8 uVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    int64_t iVar7;
    uint64_t in_RDX;
    uint32_t uVar8;
    undefined8 unaff_RDI;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801983a0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar7 = *(int64_t *)(in_RCX + 0x8f8);
    if (((*(int64_t *)(iVar7 + 0x250) != 0) && (*(int32_t *)(iVar7 + 0x2b0) == 0)) &&
       ((*(int32_t *)(in_RCX + 0x78) == 0 ||
        ((*(int64_t *)(iVar7 + 0x278) != 0 || ((*(uint8_t *)(in_RCX + 0x948) & 1) == 0)))))) {
        iVar7 = *(int64_t *)(in_RCX + 0xb88);
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RDI;
        uVar1 = *(uint32_t *)(iVar7 + 0x50);
        uVar8 = (uint32_t)in_RDX;
        if (((uVar8 & uVar1) != 0) &&
           ((*(int32_t *)(in_RCX + 0x508) == 0 ||
            ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0 &&
              (iVar4 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar4)) && (iVar4 != 0x10000)))))) {
            if (((uVar1 >> 9 & 1) == 0) &&
               ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0 ||
                 (iVar4 = **(int32_t **)(in_RCX + 0x18), iVar4 < 0x304)) ||
                ((((iVar4 == 0x10000 || (*(int32_t *)(in_RCX + 0x78) == 0)) ||
                  (((*(int32_t *)(in_RCX + 0x1538) != 0 && ((*(uint32_t *)(in_RCX + 0x9a8) >> 0x18 & 1) == 0)) ||
                   (*(int64_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x68) != 0)))) ||
                 ((*(uint32_t *)(in_RCX + 0x9a8) >> 0xe & 1) != 0)))))) {
                uVar2 = *(undefined8 *)(in_RCX + 0x8f8);
                uVar6 = *(undefined8 *)(in_RCX + 0xb88);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801984a5;
                func_0x00018019c530(uVar6, uVar2);
            }
            if (*(int64_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x60) != 0) {
                uVar2 = *(undefined8 *)(in_RCX + 0x8f8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801984bf;
                iVar4 = func_0x00018019ce20(uVar2);
                if (iVar4 != 0) {
                    uVar2 = *(undefined8 *)(in_RCX + 0x8f8);
                    uVar6 = *(undefined8 *)(in_RCX + 0x40);
                    pcVar3 = *(code **)(*(int64_t *)(in_RCX + 0xb88) + 0x60);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801984dc;
                    iVar4 = (*pcVar3)(uVar6, uVar2);
                    if (iVar4 == 0) {
                        uVar2 = *(undefined8 *)(in_RCX + 0x8f8);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801984ec;
                        func_0x00018019c980(uVar2);
                    }
                }
            }
        }
        if ((-1 < (char)uVar1) && ((uVar1 & uVar8) == uVar8)) {
            iVar7 = 0x80;
            if ((in_RDX & 1) == 0) {
                iVar7 = 0x8c;
            }
            if ((char)*(undefined4 *)(iVar7 + *(int64_t *)(in_RCX + 0xb88)) == -1) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019851e;
                uVar6 = func_0x000180467bd4(0);
                uVar2 = *(undefined8 *)(in_RCX + 0xb88);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019852d;
                func_0x00018019c780(uVar2, uVar6);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180198540
// Address: 0x180198540
// Size: 174 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.180198540(int64_t arg_30h, int64_t arg_38h)
{
    char cVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    code *pcVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t iVar10;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    uint64_t uVar11;
    uint64_t uVar12;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180198553;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar11 = 0;
    uVar12 = uVar11;
    if (*(int64_t *)(in_RCX + 0x8f8) != 0) {
        uVar12 = *(uint64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0);
    }
    if ((((*(int64_t *)(in_RCX + 0xb68) == 0) || (uVar12 == 0)) || (*(int32_t *)(in_RCX + 0x990) != 0)) ||
       (*(int64_t *)(in_RCX + 0x988) == 0)) {
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801985b1;
    iVar5 = fcn.180222010();
    if (iVar5 < 2) {
        return 1;
    }
    if (in_RCX != -0x518) {
        uVar9 = *(undefined8 *)(in_RCX + 0x520);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801985c8;
        iVar5 = fcn.180222010(uVar9);
        if ((0 < iVar5) && (*(char **)(in_RCX + 0x530) != (char *)0x0)) {
            cVar1 = **(char **)(in_RCX + 0x530);
            if (cVar1 == '\x02') {
                return 1;
            }
            if (cVar1 == '\x03') {
                return 1;
            }
        }
    }
    puVar2 = *(undefined8 **)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RBP;
    uVar9 = puVar2[0x8c];
    uVar3 = *puVar2;
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180198602;
    iVar8 = func_0x000180239f90(uVar3, uVar9);
    if (iVar8 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18019860f;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar7), *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180198627;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar7), *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
    } else {
        uVar9 = *(undefined8 *)(in_RCX + 0x988);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18019865b;
        uVar9 = fcn.180222340(uVar9, 1);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180198669;
        func_0x00018023a070(iVar8, uVar12);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180198674;
        func_0x00018023a0c0(iVar8, uVar9);
        uVar9 = *(undefined8 *)(*(int64_t *)(in_RCX + 8) + 0x1d0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180198687;
        func_0x00018023a110(iVar8, uVar9);
        uVar9 = *(undefined8 *)(in_RCX + 0x8f8);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180198693;
        iVar10 = func_0x00018019caf0(uVar9);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801986a2;
        func_0x00018023a120(iVar8, iVar10 * 1000);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801986aa;
        uVar9 = func_0x0001801935f0(in_RCX);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801986b8;
        iVar5 = func_0x00018023a150(uVar9, iVar8);
        if (iVar5 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801986c1;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar7), *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801986d9;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar7), *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
        } else {
            pcVar4 = *(code **)(in_RCX + 0xb68);
            uVar3 = *(undefined8 *)(in_RCX + 0xb70);
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801986ff;
            uVar6 = (*pcVar4)(iVar8, uVar9, uVar3);
            if (-1 < (int32_t)uVar6) {
                uVar11 = (uint64_t)uVar6;
            }
            if ((int32_t)uVar11 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18019873f;
                func_0x000180239f30(iVar8);
                if (0 < (int32_t)uVar11) {
                    return uVar11;
                }
                goto code_r0x000180198743;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18019870f;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar7), *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180198727;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar7), *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18019863d;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar7));
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180198645;
    func_0x000180239f30(iVar8);
code_r0x000180198743:
    *(undefined4 *)(in_RCX + 0x990) = 0x47;
    return uVar11;
}

// ============================================================
// Function: FUN_1801985ee
// Address: 0x1801985ee
// Size: 372 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.180198540(int64_t arg_30h, int64_t arg_38h)
{
    char cVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    code *pcVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t iVar10;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    uint64_t uVar11;
    uint64_t uVar12;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180198553;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar11 = 0;
    uVar12 = uVar11;
    if (*(int64_t *)(in_RCX + 0x8f8) != 0) {
        uVar12 = *(uint64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0);
    }
    if ((((*(int64_t *)(in_RCX + 0xb68) == 0) || (uVar12 == 0)) || (*(int32_t *)(in_RCX + 0x990) != 0)) ||
       (*(int64_t *)(in_RCX + 0x988) == 0)) {
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801985b1;
    iVar5 = fcn.180222010();
    if (iVar5 < 2) {
        return 1;
    }
    if (in_RCX != -0x518) {
        uVar9 = *(undefined8 *)(in_RCX + 0x520);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801985c8;
        iVar5 = fcn.180222010(uVar9);
        if ((0 < iVar5) && (*(char **)(in_RCX + 0x530) != (char *)0x0)) {
            cVar1 = **(char **)(in_RCX + 0x530);
            if (cVar1 == '\x02') {
                return 1;
            }
            if (cVar1 == '\x03') {
                return 1;
            }
        }
    }
    puVar2 = *(undefined8 **)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RBP;
    uVar9 = puVar2[0x8c];
    uVar3 = *puVar2;
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180198602;
    iVar8 = func_0x000180239f90(uVar3, uVar9);
    if (iVar8 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18019860f;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar7), *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180198627;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar7), *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
    } else {
        uVar9 = *(undefined8 *)(in_RCX + 0x988);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18019865b;
        uVar9 = fcn.180222340(uVar9, 1);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180198669;
        func_0x00018023a070(iVar8, uVar12);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180198674;
        func_0x00018023a0c0(iVar8, uVar9);
        uVar9 = *(undefined8 *)(*(int64_t *)(in_RCX + 8) + 0x1d0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180198687;
        func_0x00018023a110(iVar8, uVar9);
        uVar9 = *(undefined8 *)(in_RCX + 0x8f8);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180198693;
        iVar10 = func_0x00018019caf0(uVar9);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801986a2;
        func_0x00018023a120(iVar8, iVar10 * 1000);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801986aa;
        uVar9 = func_0x0001801935f0(in_RCX);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801986b8;
        iVar5 = func_0x00018023a150(uVar9, iVar8);
        if (iVar5 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801986c1;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar7), *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801986d9;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar7), *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
        } else {
            pcVar4 = *(code **)(in_RCX + 0xb68);
            uVar3 = *(undefined8 *)(in_RCX + 0xb70);
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801986ff;
            uVar6 = (*pcVar4)(iVar8, uVar9, uVar3);
            if (-1 < (int32_t)uVar6) {
                uVar11 = (uint64_t)uVar6;
            }
            if ((int32_t)uVar11 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18019873f;
                func_0x000180239f30(iVar8);
                if (0 < (int32_t)uVar11) {
                    return uVar11;
                }
                goto code_r0x000180198743;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18019870f;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar7), *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180198727;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar7), *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18019863d;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar7));
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180198645;
    func_0x000180239f30(iVar8);
code_r0x000180198743:
    *(undefined4 *)(in_RCX + 0x990) = 0x47;
    return uVar11;
}

// ============================================================
// Function: FUN_180198762
// Address: 0x180198762
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.180198540(int64_t arg_30h, int64_t arg_38h)
{
    char cVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    code *pcVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t iVar10;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    uint64_t uVar11;
    uint64_t uVar12;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180198553;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar11 = 0;
    uVar12 = uVar11;
    if (*(int64_t *)(in_RCX + 0x8f8) != 0) {
        uVar12 = *(uint64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0);
    }
    if ((((*(int64_t *)(in_RCX + 0xb68) == 0) || (uVar12 == 0)) || (*(int32_t *)(in_RCX + 0x990) != 0)) ||
       (*(int64_t *)(in_RCX + 0x988) == 0)) {
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801985b1;
    iVar5 = fcn.180222010();
    if (iVar5 < 2) {
        return 1;
    }
    if (in_RCX != -0x518) {
        uVar9 = *(undefined8 *)(in_RCX + 0x520);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801985c8;
        iVar5 = fcn.180222010(uVar9);
        if ((0 < iVar5) && (*(char **)(in_RCX + 0x530) != (char *)0x0)) {
            cVar1 = **(char **)(in_RCX + 0x530);
            if (cVar1 == '\x02') {
                return 1;
            }
            if (cVar1 == '\x03') {
                return 1;
            }
        }
    }
    puVar2 = *(undefined8 **)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RBP;
    uVar9 = puVar2[0x8c];
    uVar3 = *puVar2;
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180198602;
    iVar8 = func_0x000180239f90(uVar3, uVar9);
    if (iVar8 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18019860f;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar7), *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180198627;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar7), *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
    } else {
        uVar9 = *(undefined8 *)(in_RCX + 0x988);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18019865b;
        uVar9 = fcn.180222340(uVar9, 1);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180198669;
        func_0x00018023a070(iVar8, uVar12);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180198674;
        func_0x00018023a0c0(iVar8, uVar9);
        uVar9 = *(undefined8 *)(*(int64_t *)(in_RCX + 8) + 0x1d0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180198687;
        func_0x00018023a110(iVar8, uVar9);
        uVar9 = *(undefined8 *)(in_RCX + 0x8f8);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180198693;
        iVar10 = func_0x00018019caf0(uVar9);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801986a2;
        func_0x00018023a120(iVar8, iVar10 * 1000);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801986aa;
        uVar9 = func_0x0001801935f0(in_RCX);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801986b8;
        iVar5 = func_0x00018023a150(uVar9, iVar8);
        if (iVar5 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801986c1;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar7), *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801986d9;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar7), *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
        } else {
            pcVar4 = *(code **)(in_RCX + 0xb68);
            uVar3 = *(undefined8 *)(in_RCX + 0xb70);
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801986ff;
            uVar6 = (*pcVar4)(iVar8, uVar9, uVar3);
            if (-1 < (int32_t)uVar6) {
                uVar11 = (uint64_t)uVar6;
            }
            if ((int32_t)uVar11 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18019873f;
                func_0x000180239f30(iVar8);
                if (0 < (int32_t)uVar11) {
                    return uVar11;
                }
                goto code_r0x000180198743;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18019870f;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar7), *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180198727;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar7), *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18019863d;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar7));
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180198645;
    func_0x000180239f30(iVar8);
code_r0x000180198743:
    *(undefined4 *)(in_RCX + 0x990) = 0x47;
    return uVar11;
}

// ============================================================
// Function: FUN_180198780
// Address: 0x180198780
// Size: 585 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.180198780(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h,
             int64_t arg_88h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t *piVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int32_t *in_RCX;
    undefined8 in_RDX;
    undefined8 in_R8;
    int64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801987a0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX != (int32_t *)0x0) {
        piVar4 = in_RCX;
        if (*in_RCX != 0) {
            if ((char)*in_RCX < '\0') {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801987cc;
                piVar4 = (int32_t *)func_0x0001801bda50();
            } else {
                piVar4 = (int32_t *)0x0;
            }
        }
        if ((*(uint8_t *)in_RCX & 0x80) != 0) {
            *(undefined8 *)((int64_t)&var_18h + iVar3) = *(undefined8 *)((int64_t)&arg_88h + iVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801987f6;
            uVar5 = func_0x0001801c0010(in_RCX, in_RDX, in_R8, in_R9);
            return uVar5;
        }
        if (piVar4 != (int32_t *)0x0) {
            if (*(int64_t *)(piVar4 + 0x1c) == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198810;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198828;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                              *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)((int64_t)&arg_48h + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019883a;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            } else {
                if ((*(uint8_t *)(piVar4 + 0x21) & 1) != 0) {
                    piVar4[0x1a] = 1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198859;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198871;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198883;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
                    return 0xffffffff;
                }
                if (in_R9 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198897;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801988af;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801988c1;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
                    return 0xffffffff;
                }
                if ((piVar4[0x3c] == 1) || ((piVar4[0x3c] - 8U & 0xfffffffd) == 0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198982;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019899a;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801989ac;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
                    return 0;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801988f5;
                iVar2 = func_0x00018019b3c0(piVar4, 1);
                if (iVar2 != 0) {
                    if ((piVar4[0x26c] & 0x100U) != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019890e;
                        iVar6 = func_0x0001802395d0();
                        if (iVar6 == 0) {
                            iVar6 = *(int64_t *)(in_RCX + 6);
                            *(int32_t **)((int64_t)&arg_28h + iVar3) = in_RCX;
                            *(undefined8 *)((int64_t)&arg_30h + iVar3) = in_RDX;
                            *(undefined8 *)((int64_t)&arg_38h + iVar3) = in_R8;
                            *(undefined4 *)((int64_t)&arg_40h + iVar3) = 1;
                            *(undefined8 *)((int64_t)&arg_48h + iVar3) = *(undefined8 *)(iVar6 + 0x60);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019894b;
                            uVar5 = fcn.180198150(*(int64_t *)((int64_t)&arg_28h + iVar3), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar3), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                            **(undefined8 **)((int64_t)&arg_88h + iVar3) = *(undefined8 *)(piVar4 + 0x54c);
                            return uVar5;
                        }
                    }
                    pcVar1 = *(code **)(*(int64_t *)(in_RCX + 6) + 0x60);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019897b;
                    uVar5 = (*pcVar1)(in_RCX, in_RDX, in_R8, *(undefined8 *)((int64_t)&arg_88h + iVar3));
                    return uVar5;
                }
            }
            return 0xffffffff;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801989d0
// Address: 0x1801989d0
// Size: 80 bytes
// ============================================================
void fcn.1801989d0(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801989e0;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        uVar1 = *(undefined8 *)(arg1 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801989fc;
        fcn.180224990(uVar1, 0x1804a94a0, 0xa8);
        uVar1 = *(undefined8 *)(arg1 + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180198a05;
        fcn.18022ecc0(uVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180198a1a;
        fcn.180224990(arg1, 0x1804a94a0, 0xaa);
    }
    return;
}

// ============================================================
// Function: FUN_180198a20
// Address: 0x180198a20
// Size: 91 bytes
// ============================================================
undefined8 fcn.180198a20(int64_t arg_30h, int64_t arg_50h, int64_t arg_68h, int64_t arg_98h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t *piVar6;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_8;
    
    uStack_8 = 0x180198a2a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180198a37;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180198a4f;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), *(int64_t *)(&stack0x00000028 + iVar3), 
                      *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                      *(int64_t *)((int64_t)&arg_50h + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180198a61;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
        return 0;
    }
    piVar6 = *(int64_t **)(in_RCX + 0x158);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar3) = 0x180199e90;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + iVar3) = 0x180199ea6;
    iVar5 = fcn.1801a2080(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3)
                          , *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3));
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + iVar3) = 0x180199eb0;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + iVar3) = 0x180199ec8;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3), *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000070 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + iVar3) = 0x180199eda;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar4 + iVar3));
    } else {
        iVar5 = *(int64_t *)(piVar6[4] + *(int64_t *)((int64_t)&arg_68h + iVar4 + iVar3) * 0x28);
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + iVar3) = 0x180199f05;
            iVar2 = fcn.180238100(iVar5, in_RDX);
            if (iVar2 == 0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + iVar3) = 0x180199f11;
        iVar2 = fcn.1802308d0(in_RDX);
        if (iVar2 != 0) {
            uVar1 = *(undefined8 *)(piVar6[4] + 8 + *(int64_t *)((int64_t)&arg_68h + iVar4 + iVar3) * 0x28);
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + iVar3) = 0x180199f2c;
            fcn.18022ecc0(uVar1);
            *(int64_t *)(piVar6[4] + 8 + *(int64_t *)((int64_t)&arg_68h + iVar4 + iVar3) * 0x28) = in_RDX;
            *piVar6 = piVar6[4] + *(int64_t *)((int64_t)&arg_68h + iVar4 + iVar3) * 0x28;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180198a80
// Address: 0x180198a80
// Size: 461 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined4 fcn.180198a80(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 *in_RCX;
    int64_t in_RDX;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180198aa0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar4 = 0;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180198aba;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180198ad2;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                      *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar5));
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180198ae1;
        func_0x00018023faa0();
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180198ae9;
        iVar6 = fcn.18021a7c0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                              *(int64_t *)((int64_t)&arg_50h + iVar5));
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180198af6;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180198b0e;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                          *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)((int64_t)&arg_48h + iVar5));
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180198b2e;
            iVar3 = fcn.180219d10(*(int64_t *)((int64_t)&arg_38h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar5));
            if (iVar3 < 1) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180198b37;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180198b4f;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                              *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                              *(int64_t *)((int64_t)&arg_48h + iVar5));
            } else {
                if (in_R8D == 1) {
                    uVar1 = in_RCX[0x18];
                    uVar2 = in_RCX[0x17];
                    *(undefined8 *)((int64_t)&var_20h + iVar5) = in_RCX[0x8c];
                    *(undefined8 *)((int64_t)&var_18h + iVar5) = *in_RCX;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180198b90;
                    iVar6 = func_0x000180242cd0(iVar6, 0, uVar2, uVar1);
                } else {
                    if (in_R8D != 2) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180198bfe;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180198c16;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                      *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar5));
                        goto code_r0x000180198c1b;
                    }
                    uVar1 = in_RCX[0x8c];
                    uVar2 = *in_RCX;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180198bb1;
                    iVar6 = func_0x000180240690(iVar6, 0, uVar2, uVar1);
                }
                if (iVar6 != 0) {
                    uVar1 = in_RCX[0x2b];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180198bed;
                    uVar4 = func_0x000180199e80(uVar1, iVar6, in_RCX);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180198bf7;
                    fcn.18022ecc0(iVar6);
                    goto code_r0x000180198c28;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180198bbe;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180198bd6;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                              *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                              *(int64_t *)((int64_t)&arg_48h + iVar5));
            }
        }
    }
code_r0x000180198c1b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180198c28;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
code_r0x000180198c28:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180198c30;
    fcn.180219f80(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
    return uVar4;
}

// ============================================================
// Function: FUN_180198c50
// Address: 0x180198c50
// Size: 93 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8
fcn.180198c50(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
             int64_t arg_70h, int64_t arg_a0h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t *piVar6;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180198c60;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198c73;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198c8b;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198c9d;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined4 *)((int64_t)&iStackX_20 + iVar3 + -8) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198cc7;
    iVar2 = fcn.1801a8d20(*(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar3), 
                          *(int64_t *)(&stack0x000000c8 + iVar3));
    if (iVar2 != 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198cd3;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198ceb;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198cfa;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    piVar6 = *(int64_t **)(in_RCX + 0x158);
    uVar1 = *(undefined8 *)((int64_t)&arg_38h + iVar3);
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = *(undefined8 *)((int64_t)&arg_40h + iVar3);
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = uVar1;
    *(undefined8 *)(&stack0x00000028 + iVar3) = *(undefined8 *)(&stack0x00000028 + iVar3);
    *(undefined8 *)((int64_t)&iStackX_20 + iVar3) = 0x180199cba;
    iVar4 = fcn.18045a350(piVar6, in_RDX, in_RCX);
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199cce;
    iVar5 = fcn.180238400(in_RDX);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199cdb;
        fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199cf3;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199d05;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_68h + iVar4 + iVar3));
    } else {
        *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199d1c;
        iVar5 = fcn.1801a2080(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3));
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199d26;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
            *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199d3e;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
            *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199d50;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_68h + iVar4 + iVar3));
            return 0;
        }
        iVar5 = *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3);
        if (iVar5 == 3) {
            *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199d6a;
            iVar2 = fcn.18022e600(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3));
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199d73;
                fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
                *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199d8b;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
                *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199d9d;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_68h + iVar4 + iVar3));
                return 0;
            }
            iVar5 = *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3);
        }
        if (*(int64_t *)(piVar6[4] + 8 + iVar5 * 0x28) != 0) {
            *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199dc3;
            fcn.18022e6c0(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
            *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199dc8;
            fcn.1802203d0(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
            uVar1 = *(undefined8 *)(piVar6[4] + 8 + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28);
            *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199de2;
            iVar2 = fcn.180238100(in_RDX, uVar1);
            if (iVar2 == 0) {
                uVar1 = *(undefined8 *)(piVar6[4] + 8 + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28);
                *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199dfd;
                fcn.18022ecc0(uVar1);
                *(undefined8 *)(piVar6[4] + 8 + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28) = 0;
                *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199e18;
                fcn.1802203d0(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
            }
        }
        *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199e20;
        iVar2 = fcn.1802375f0(in_RDX);
        if (iVar2 != 0) {
            uVar1 = *(undefined8 *)(piVar6[4] + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28);
            *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199e3e;
            fcn.18021fe80(uVar1);
            *(int64_t *)(piVar6[4] + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28) = in_RDX;
            *piVar6 = piVar6[4] + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180198cad
// Address: 0x180198cad
// Size: 95 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8
fcn.180198c50(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
             int64_t arg_70h, int64_t arg_a0h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t *piVar6;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180198c60;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198c73;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198c8b;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198c9d;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined4 *)((int64_t)&iStackX_20 + iVar3 + -8) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198cc7;
    iVar2 = fcn.1801a8d20(*(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar3), 
                          *(int64_t *)(&stack0x000000c8 + iVar3));
    if (iVar2 != 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198cd3;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198ceb;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198cfa;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    piVar6 = *(int64_t **)(in_RCX + 0x158);
    uVar1 = *(undefined8 *)((int64_t)&arg_38h + iVar3);
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = *(undefined8 *)((int64_t)&arg_40h + iVar3);
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = uVar1;
    *(undefined8 *)(&stack0x00000028 + iVar3) = *(undefined8 *)(&stack0x00000028 + iVar3);
    *(undefined8 *)((int64_t)&iStackX_20 + iVar3) = 0x180199cba;
    iVar4 = fcn.18045a350(piVar6, in_RDX, in_RCX);
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199cce;
    iVar5 = fcn.180238400(in_RDX);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199cdb;
        fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199cf3;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199d05;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_68h + iVar4 + iVar3));
    } else {
        *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199d1c;
        iVar5 = fcn.1801a2080(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3));
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199d26;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
            *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199d3e;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
            *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199d50;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_68h + iVar4 + iVar3));
            return 0;
        }
        iVar5 = *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3);
        if (iVar5 == 3) {
            *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199d6a;
            iVar2 = fcn.18022e600(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3));
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199d73;
                fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
                *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199d8b;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
                *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199d9d;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_68h + iVar4 + iVar3));
                return 0;
            }
            iVar5 = *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3);
        }
        if (*(int64_t *)(piVar6[4] + 8 + iVar5 * 0x28) != 0) {
            *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199dc3;
            fcn.18022e6c0(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
            *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199dc8;
            fcn.1802203d0(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
            uVar1 = *(undefined8 *)(piVar6[4] + 8 + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28);
            *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199de2;
            iVar2 = fcn.180238100(in_RDX, uVar1);
            if (iVar2 == 0) {
                uVar1 = *(undefined8 *)(piVar6[4] + 8 + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28);
                *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199dfd;
                fcn.18022ecc0(uVar1);
                *(undefined8 *)(piVar6[4] + 8 + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28) = 0;
                *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199e18;
                fcn.1802203d0(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
            }
        }
        *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199e20;
        iVar2 = fcn.1802375f0(in_RDX);
        if (iVar2 != 0) {
            uVar1 = *(undefined8 *)(piVar6[4] + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28);
            *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199e3e;
            fcn.18021fe80(uVar1);
            *(int64_t *)(piVar6[4] + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28) = in_RDX;
            *piVar6 = piVar6[4] + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180198d0c
// Address: 0x180198d0c
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8
fcn.180198c50(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
             int64_t arg_70h, int64_t arg_a0h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t *piVar6;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180198c60;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198c73;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198c8b;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198c9d;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined4 *)((int64_t)&iStackX_20 + iVar3 + -8) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198cc7;
    iVar2 = fcn.1801a8d20(*(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar3), 
                          *(int64_t *)(&stack0x000000c8 + iVar3));
    if (iVar2 != 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198cd3;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198ceb;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180198cfa;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    piVar6 = *(int64_t **)(in_RCX + 0x158);
    uVar1 = *(undefined8 *)((int64_t)&arg_38h + iVar3);
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = *(undefined8 *)((int64_t)&arg_40h + iVar3);
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = uVar1;
    *(undefined8 *)(&stack0x00000028 + iVar3) = *(undefined8 *)(&stack0x00000028 + iVar3);
    *(undefined8 *)((int64_t)&iStackX_20 + iVar3) = 0x180199cba;
    iVar4 = fcn.18045a350(piVar6, in_RDX, in_RCX);
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199cce;
    iVar5 = fcn.180238400(in_RDX);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199cdb;
        fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199cf3;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199d05;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_68h + iVar4 + iVar3));
    } else {
        *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199d1c;
        iVar5 = fcn.1801a2080(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3));
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199d26;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
            *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199d3e;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
            *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199d50;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_68h + iVar4 + iVar3));
            return 0;
        }
        iVar5 = *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3);
        if (iVar5 == 3) {
            *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199d6a;
            iVar2 = fcn.18022e600(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3));
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199d73;
                fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
                *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199d8b;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
                *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199d9d;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_68h + iVar4 + iVar3));
                return 0;
            }
            iVar5 = *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3);
        }
        if (*(int64_t *)(piVar6[4] + 8 + iVar5 * 0x28) != 0) {
            *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199dc3;
            fcn.18022e6c0(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
            *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199dc8;
            fcn.1802203d0(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
            uVar1 = *(undefined8 *)(piVar6[4] + 8 + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28);
            *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199de2;
            iVar2 = fcn.180238100(in_RDX, uVar1);
            if (iVar2 == 0) {
                uVar1 = *(undefined8 *)(piVar6[4] + 8 + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28);
                *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199dfd;
                fcn.18022ecc0(uVar1);
                *(undefined8 *)(piVar6[4] + 8 + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28) = 0;
                *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199e18;
                fcn.1802203d0(*(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
            }
        }
        *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199e20;
        iVar2 = fcn.1802375f0(in_RDX);
        if (iVar2 != 0) {
            uVar1 = *(undefined8 *)(piVar6[4] + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28);
            *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + iVar3) = 0x180199e3e;
            fcn.18021fe80(uVar1);
            *(int64_t *)(piVar6[4] + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28) = in_RDX;
            *piVar6 = piVar6[4] + *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3) * 0x28;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180198d30
// Address: 0x180198d30
// Size: 27 bytes
// ============================================================
int32_t fcn.180198d30(int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    uint32_t uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 *in_RCX;
    int64_t in_RDX;
    int32_t *piVar11;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int32_t iVar12;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 uVar13;
    undefined8 unaff_R13;
    undefined8 uVar14;
    undefined8 unaff_R14;
    undefined8 *puVar15;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 auStack_10 [2];
    
    auStack_10[1] = 0x180198d3a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    piVar11 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar6 + -8) = unaff_RBP;
    *(undefined8 *)(&stack0x00000010 + iVar6) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar6) = unaff_RDI;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar6 + -0x20) = unaff_R14;
    iVar10 = iVar6 + -8;
    *(undefined8 *)((int64_t)auStack_10 + iVar6 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStack_10 + iVar6) = 0x180199f83;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar12 = 0;
    *(undefined8 *)((int64_t)&arg_60h + iVar7 + iVar6) = 0;
    puVar15 = in_RCX;
    if (piVar11 != (int32_t *)0x0) {
        puVar15 = *(undefined8 **)(piVar11 + 2);
    }
    *(undefined8 *)((int64_t)&arg_68h + iVar7 + iVar6) = unaff_R12;
    *(undefined8 *)((int64_t)&var_18h + iVar7 + iVar6) = unaff_R13;
    if (in_RCX == (undefined8 *)0x0) {
        if (piVar11 == (int32_t *)0x0) {
            return 0;
        }
        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x180199fbe;
        fcn.1802203d0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), *(int64_t *)(&stack0x00000028 + iVar7 + iVar6)
                      , *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), *(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
        if (*piVar11 == 0) {
            uVar13 = *(undefined8 *)(piVar11 + 0x544);
            uVar14 = *(undefined8 *)(piVar11 + 0x546);
        } else {
            if (-1 < (char)*piVar11) {
                return 0;
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x180199fe3;
            iVar8 = func_0x0001801bda50(piVar11);
            if (iVar8 == 0) {
                return 0;
            }
            uVar13 = *(undefined8 *)(iVar8 + 0x1510);
            uVar14 = *(undefined8 *)(iVar8 + 0x1518);
        }
    } else {
        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a004;
        fcn.1802203d0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), *(int64_t *)(&stack0x00000028 + iVar7 + iVar6)
                      , *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), *(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
        uVar13 = in_RCX[0x17];
        uVar14 = in_RCX[0x18];
    }
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a01c;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6));
        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a034;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), *(int64_t *)(&stack0x00000028 + iVar7 + iVar6)
                      , *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), *(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
    } else {
        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a043;
        func_0x00018023faa0();
        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a04b;
        iVar8 = fcn.18021a7c0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), 
                              *(int64_t *)(&stack0x00000050 + iVar7 + iVar6));
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a058;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6));
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a070;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), 
                          *(int64_t *)(&stack0x00000028 + iVar7 + iVar6), *(int64_t *)(&stack0x00000030 + iVar7 + iVar6)
                          , *(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
        } else {
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a090;
            iVar3 = fcn.180219d10(*(int64_t *)(&stack0x00000038 + iVar7 + iVar6), 
                                  *(int64_t *)(&stack0x00000040 + iVar7 + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
            if (iVar3 < 1) {
                *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a099;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6));
                *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a0b1;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), 
                              *(int64_t *)(&stack0x00000028 + iVar7 + iVar6), 
                              *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), 
                              *(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
            } else {
                uVar1 = puVar15[0x8c];
                uVar2 = *puVar15;
                *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a0ca;
                iVar9 = func_0x00018021ff10(uVar2, uVar1);
                *(int64_t *)((int64_t)&arg_60h + iVar7 + iVar6) = iVar9;
                if (iVar9 == 0) {
                    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a0d9;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6));
                } else {
                    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a0f6;
                    iVar9 = func_0x000180242c60(iVar8, (int64_t)&arg_60h + iVar7 + iVar6, uVar13, uVar14);
                    if (iVar9 == 0) {
                        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a100;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6));
                        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a118;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x00000028 + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
                        iVar12 = 0;
                        goto code_r0x00018019a21f;
                    }
                    if (in_RCX == (undefined8 *)0x0) {
                        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a13e;
                        iVar3 = func_0x000180199810(piVar11, *(undefined8 *)((int64_t)&arg_60h + iVar7 + iVar6));
                    } else {
                        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a134;
                        iVar3 = fcn.180198c50(*(int64_t *)(&stack0x00000028 + iVar7 + iVar6), 
                                              *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), 
                                              *(int64_t *)(&stack0x00000038 + iVar7 + iVar6), 
                                              *(int64_t *)(&stack0x00000048 + iVar7 + iVar6), 
                                              *(int64_t *)(&stack0x00000050 + iVar7 + iVar6), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6), 
                                              *(int64_t *)((int64_t)&arg_60h + iVar7 + iVar6), 
                                              *(int64_t *)(&stack0x00000090 + iVar7 + iVar6));
                    }
                    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar10 + 8) = 0x18019a145;
                    iVar4 = func_0x000180220920();
                    if (iVar4 == 0) {
                        iVar12 = iVar3;
                    }
                    if (iVar12 == 0) goto code_r0x00018019a22c;
                    if (in_RCX == (undefined8 *)0x0) {
                        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar10 + 8) = 0x18019a174;
                        iVar3 = func_0x000180193380(piVar11, 0x58, 0, 0);
                    } else {
                        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar10 + 8) = 0x18019a16a;
                        iVar3 = func_0x000180191a20(in_RCX);
                    }
                    if (iVar3 == 0) {
code_r0x00018019a261:
                        iVar12 = 0;
                        goto code_r0x00018019a22c;
                    }
                    uVar1 = puVar15[0x8c];
                    uVar2 = *puVar15;
                    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a18b;
                    iVar10 = func_0x00018021ff10(uVar2, uVar1);
                    *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6) = iVar10;
                    while (iVar10 != 0) {
                        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a1b3;
                        iVar10 = func_0x0001802201c0(iVar8, (int64_t)&arg_58h + iVar7 + iVar6, uVar13, uVar14);
                        if (iVar10 == 0) {
                            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a26f;
                            fcn.18021fe80(*(undefined8 *)((int64_t)&arg_58h + iVar7 + iVar6));
                            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a274;
                            uVar5 = func_0x000180220a00();
                            if ((((int32_t)uVar5 < 0) || ((uVar5 & 0x7f800000) != 0x4800000)) ||
                               ((((int32_t)uVar5 >> 0x1f & 0x7f800000U) + 0x7fffff & uVar5) != 0x6c))
                            goto code_r0x00018019a261;
                            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a2a5;
                            fcn.1802203d0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), 
                                          *(int64_t *)(&stack0x00000028 + iVar7 + iVar6), 
                                          *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), 
                                          *(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
                            goto code_r0x00018019a22c;
                        }
                        if (in_RCX == (undefined8 *)0x0) {
                            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a1e0;
                            iVar3 = func_0x000180193380(piVar11, 0x59, 0, 
                                                        *(undefined8 *)((int64_t)&arg_58h + iVar7 + iVar6));
                        } else {
                            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a1d6;
                            iVar3 = func_0x000180191a20(in_RCX);
                        }
                        if (iVar3 == 0) {
                            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a261;
                            fcn.18021fe80(*(undefined8 *)((int64_t)&arg_58h + iVar7 + iVar6));
                            goto code_r0x00018019a261;
                        }
                        uVar1 = puVar15[0x8c];
                        uVar2 = *puVar15;
                        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a1f3;
                        iVar10 = func_0x00018021ff10(uVar2, uVar1);
                        *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6) = iVar10;
                    }
                    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a202;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6));
                }
                *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a21a;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), 
                              *(int64_t *)(&stack0x00000028 + iVar7 + iVar6), 
                              *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), 
                              *(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
            }
        }
    }
code_r0x00018019a21f:
    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a22c;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar7 + iVar6));
code_r0x00018019a22c:
    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a236;
    fcn.18021fe80(*(undefined8 *)((int64_t)&arg_60h + iVar7 + iVar6));
    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x18019a23e;
    fcn.180219f80(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), *(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6));
    return iVar12;
}

// ============================================================
// Function: FUN_180198d50
// Address: 0x180198d50
// Size: 484 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

undefined4 fcn.180198d50(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 *in_RCX;
    int64_t in_RDX;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180198d68;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar4 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = 0;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180198d88;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180198da0;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar5), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_38h + iVar5));
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180198daf;
        func_0x00018023faa0();
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180198db7;
        iVar6 = fcn.18021a7c0(*(int64_t *)((int64_t)&iStackX_10 + iVar5 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5));
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180198dc4;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180198ddc;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar5), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180198dfc;
            iVar3 = fcn.180219d10(*(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5));
            if (iVar3 < 1) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180198e05;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar5 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar5));
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180198e1d;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar5 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar5), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar5), *(int64_t *)((int64_t)&arg_38h + iVar5));
            } else {
                uVar1 = in_RCX[0x8c];
                uVar2 = *in_RCX;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180198e36;
                iVar7 = func_0x00018021ff10(uVar2, uVar1);
                *(int64_t *)((int64_t)&arg_30h + iVar5) = iVar7;
                if (iVar7 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180198e45;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar5 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180198e5d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar5 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar5), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5), *(int64_t *)((int64_t)&arg_38h + iVar5));
                } else {
                    if (in_R8D == 2) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180198e7e;
                        iVar6 = func_0x000180240760(iVar6, (int64_t)&arg_30h + iVar5);
                    } else {
                        if (in_R8D != 1) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180198ee2;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar5 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_10 + iVar5));
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180198efa;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar5 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_10 + iVar5), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar5));
                            goto code_r0x000180198eff;
                        }
                        uVar1 = in_RCX[0x18];
                        uVar2 = in_RCX[0x17];
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180198ea5;
                        iVar6 = func_0x0001802201c0(iVar6, (int64_t)&arg_30h + iVar5, uVar2, uVar1);
                    }
                    if (iVar6 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180198ed8;
                        uVar4 = fcn.180198c50(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar5), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar5), 
                                              *(int64_t *)(&stack0x00000040 + iVar5), 
                                              *(int64_t *)(&stack0x00000048 + iVar5), 
                                              *(int64_t *)(&stack0x00000050 + iVar5), 
                                              *(int64_t *)(&stack0x00000080 + iVar5));
                        goto code_r0x000180198f0c;
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180198eaf;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar5 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180198ec7;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar5 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar5), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5), *(int64_t *)((int64_t)&arg_38h + iVar5));
                }
            }
        }
    }
code_r0x000180198eff:
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180198f0c;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
code_r0x000180198f0c:
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180198f16;
    fcn.18021fe80(*(undefined8 *)((int64_t)&arg_30h + iVar5));
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180198f1e;
    fcn.180219f80(*(int64_t *)((int64_t)&iStackX_10 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar5));
    return uVar4;
}

// ============================================================
// Function: FUN_180198f40
// Address: 0x180198f40
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined4 fcn.180198f40(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    int64_t in_RCX;
    uint64_t in_RDX;
    int64_t in_R8;
    int64_t in_R9;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180198f5a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (((in_RCX == 0) || (in_R8 == 0)) || (in_R9 == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180199114;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019912c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019913e;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R14;
    if ((int32_t)in_RDX == 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180198fa3;
        puVar5 = (undefined4 *)
                 fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        if (puVar5 == (undefined4 *)0x0) {
            return 0;
        }
        *puVar5 = 0xd0010000;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180198fc4;
        fcn.180498030(puVar5 + 1, in_R8, in_R9);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180198fd8;
        uVar2 = fcn.180198f40(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180198fef;
        fcn.180224990(puVar5, 0x1804a9818, 0x336);
        return uVar2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180199003;
    iVar3 = func_0x000180199930(in_RDX & 0xffffffff, in_R8, in_R9, 0);
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019900c;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    } else {
        if (**(int64_t **)(in_RCX + 0x158) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180199066;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019907e;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            goto code_r0x000180199029;
        }
        uVar1 = *(undefined8 *)(**(int64_t **)(in_RCX + 0x158) + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019909e;
        iVar6 = func_0x0001802249c0(uVar1, in_R9, 0x1804a9818, 0x343);
        if (iVar6 == 0) {
            return 0;
        }
        *(int64_t *)(**(int64_t **)(in_RCX + 0x158) + 0x18) = iVar6;
        uVar1 = *(undefined8 *)(**(int64_t **)(in_RCX + 0x158) + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801990cd;
        fcn.180498030(uVar1, in_R8, in_R9);
        *(int64_t *)(**(int64_t **)(in_RCX + 0x158) + 0x20) = in_R9;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801990eb;
        iVar3 = func_0x000180199930(in_RDX & 0xffffffff, in_R8, in_R9, in_RCX);
        if (iVar3 != 0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801990f4;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180199024;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                  *(int64_t *)(&stack0x00000048 + iVar4));
code_r0x000180199029:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180199036;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_180198f83
// Address: 0x180198f83
// Size: 186 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined4 fcn.180198f40(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    int64_t in_RCX;
    uint64_t in_RDX;
    int64_t in_R8;
    int64_t in_R9;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180198f5a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (((in_RCX == 0) || (in_R8 == 0)) || (in_R9 == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180199114;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019912c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019913e;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R14;
    if ((int32_t)in_RDX == 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180198fa3;
        puVar5 = (undefined4 *)
                 fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        if (puVar5 == (undefined4 *)0x0) {
            return 0;
        }
        *puVar5 = 0xd0010000;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180198fc4;
        fcn.180498030(puVar5 + 1, in_R8, in_R9);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180198fd8;
        uVar2 = fcn.180198f40(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180198fef;
        fcn.180224990(puVar5, 0x1804a9818, 0x336);
        return uVar2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180199003;
    iVar3 = func_0x000180199930(in_RDX & 0xffffffff, in_R8, in_R9, 0);
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019900c;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    } else {
        if (**(int64_t **)(in_RCX + 0x158) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180199066;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019907e;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            goto code_r0x000180199029;
        }
        uVar1 = *(undefined8 *)(**(int64_t **)(in_RCX + 0x158) + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019909e;
        iVar6 = func_0x0001802249c0(uVar1, in_R9, 0x1804a9818, 0x343);
        if (iVar6 == 0) {
            return 0;
        }
        *(int64_t *)(**(int64_t **)(in_RCX + 0x158) + 0x18) = iVar6;
        uVar1 = *(undefined8 *)(**(int64_t **)(in_RCX + 0x158) + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801990cd;
        fcn.180498030(uVar1, in_R8, in_R9);
        *(int64_t *)(**(int64_t **)(in_RCX + 0x158) + 0x20) = in_R9;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801990eb;
        iVar3 = func_0x000180199930(in_RDX & 0xffffffff, in_R8, in_R9, in_RCX);
        if (iVar3 != 0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801990f4;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180199024;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                  *(int64_t *)(&stack0x00000048 + iVar4));
code_r0x000180199029:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180199036;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_18019903d
// Address: 0x18019903d
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined4 fcn.180198f40(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    int64_t in_RCX;
    uint64_t in_RDX;
    int64_t in_R8;
    int64_t in_R9;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180198f5a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (((in_RCX == 0) || (in_R8 == 0)) || (in_R9 == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180199114;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019912c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019913e;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R14;
    if ((int32_t)in_RDX == 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180198fa3;
        puVar5 = (undefined4 *)
                 fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        if (puVar5 == (undefined4 *)0x0) {
            return 0;
        }
        *puVar5 = 0xd0010000;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180198fc4;
        fcn.180498030(puVar5 + 1, in_R8, in_R9);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180198fd8;
        uVar2 = fcn.180198f40(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180198fef;
        fcn.180224990(puVar5, 0x1804a9818, 0x336);
        return uVar2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180199003;
    iVar3 = func_0x000180199930(in_RDX & 0xffffffff, in_R8, in_R9, 0);
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019900c;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    } else {
        if (**(int64_t **)(in_RCX + 0x158) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180199066;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019907e;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            goto code_r0x000180199029;
        }
        uVar1 = *(undefined8 *)(**(int64_t **)(in_RCX + 0x158) + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019909e;
        iVar6 = func_0x0001802249c0(uVar1, in_R9, 0x1804a9818, 0x343);
        if (iVar6 == 0) {
            return 0;
        }
        *(int64_t *)(**(int64_t **)(in_RCX + 0x158) + 0x18) = iVar6;
        uVar1 = *(undefined8 *)(**(int64_t **)(in_RCX + 0x158) + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801990cd;
        fcn.180498030(uVar1, in_R8, in_R9);
        *(int64_t *)(**(int64_t **)(in_RCX + 0x158) + 0x20) = in_R9;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801990eb;
        iVar3 = func_0x000180199930(in_RDX & 0xffffffff, in_R8, in_R9, in_RCX);
        if (iVar3 != 0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801990f4;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180199024;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                  *(int64_t *)(&stack0x00000048 + iVar4));
code_r0x000180199029:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180199036;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_180199052
// Address: 0x180199052
// Size: 189 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined4 fcn.180198f40(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    int64_t in_RCX;
    uint64_t in_RDX;
    int64_t in_R8;
    int64_t in_R9;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180198f5a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (((in_RCX == 0) || (in_R8 == 0)) || (in_R9 == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180199114;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019912c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019913e;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R14;
    if ((int32_t)in_RDX == 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180198fa3;
        puVar5 = (undefined4 *)
                 fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        if (puVar5 == (undefined4 *)0x0) {
            return 0;
        }
        *puVar5 = 0xd0010000;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180198fc4;
        fcn.180498030(puVar5 + 1, in_R8, in_R9);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180198fd8;
        uVar2 = fcn.180198f40(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180198fef;
        fcn.180224990(puVar5, 0x1804a9818, 0x336);
        return uVar2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180199003;
    iVar3 = func_0x000180199930(in_RDX & 0xffffffff, in_R8, in_R9, 0);
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019900c;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    } else {
        if (**(int64_t **)(in_RCX + 0x158) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180199066;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019907e;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            goto code_r0x000180199029;
        }
        uVar1 = *(undefined8 *)(**(int64_t **)(in_RCX + 0x158) + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019909e;
        iVar6 = func_0x0001802249c0(uVar1, in_R9, 0x1804a9818, 0x343);
        if (iVar6 == 0) {
            return 0;
        }
        *(int64_t *)(**(int64_t **)(in_RCX + 0x158) + 0x18) = iVar6;
        uVar1 = *(undefined8 *)(**(int64_t **)(in_RCX + 0x158) + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801990cd;
        fcn.180498030(uVar1, in_R8, in_R9);
        *(int64_t *)(**(int64_t **)(in_RCX + 0x158) + 0x20) = in_R9;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801990eb;
        iVar3 = func_0x000180199930(in_RDX & 0xffffffff, in_R8, in_R9, in_RCX);
        if (iVar3 != 0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801990f4;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180199024;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                  *(int64_t *)(&stack0x00000048 + iVar4));
code_r0x000180199029:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180199036;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_18019910f
// Address: 0x18019910f
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined4 fcn.180198f40(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    int64_t in_RCX;
    uint64_t in_RDX;
    int64_t in_R8;
    int64_t in_R9;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180198f5a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (((in_RCX == 0) || (in_R8 == 0)) || (in_R9 == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180199114;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019912c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019913e;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R14;
    if ((int32_t)in_RDX == 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180198fa3;
        puVar5 = (undefined4 *)
                 fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        if (puVar5 == (undefined4 *)0x0) {
            return 0;
        }
        *puVar5 = 0xd0010000;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180198fc4;
        fcn.180498030(puVar5 + 1, in_R8, in_R9);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180198fd8;
        uVar2 = fcn.180198f40(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180198fef;
        fcn.180224990(puVar5, 0x1804a9818, 0x336);
        return uVar2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180199003;
    iVar3 = func_0x000180199930(in_RDX & 0xffffffff, in_R8, in_R9, 0);
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019900c;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    } else {
        if (**(int64_t **)(in_RCX + 0x158) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180199066;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019907e;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            goto code_r0x000180199029;
        }
        uVar1 = *(undefined8 *)(**(int64_t **)(in_RCX + 0x158) + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019909e;
        iVar6 = func_0x0001802249c0(uVar1, in_R9, 0x1804a9818, 0x343);
        if (iVar6 == 0) {
            return 0;
        }
        *(int64_t *)(**(int64_t **)(in_RCX + 0x158) + 0x18) = iVar6;
        uVar1 = *(undefined8 *)(**(int64_t **)(in_RCX + 0x158) + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801990cd;
        fcn.180498030(uVar1, in_R8, in_R9);
        *(int64_t *)(**(int64_t **)(in_RCX + 0x158) + 0x20) = in_R9;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801990eb;
        iVar3 = func_0x000180199930(in_RDX & 0xffffffff, in_R8, in_R9, in_RCX);
        if (iVar3 != 0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801990f4;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180199024;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                  *(int64_t *)(&stack0x00000048 + iVar4));
code_r0x000180199029:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180199036;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
    return 0;
}

