// Chunk 117 - 50 functions

// ============================================================
// Function: FUN_1801943f1
// Address: 0x1801943f1
// Size: 64 bytes
// ============================================================
void fcn.1801943f1(int64_t arg1, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_90h, int64_t arg_98h,
                  int64_t arg_b0h)
{
    int32_t in_EAX;
    int32_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t unaff_RSI;
    undefined8 auStackX_18 [2];
    
    iVar3 = arg1;
    if (in_EAX != 0) {
        if ((char)in_EAX < '\0') {
            iVar3 = func_0x0001801bda50();
        } else {
            iVar3 = 0;
        }
    }
    if ((*(uint8_t *)arg1 & 0x80) == 0) {
        if (iVar3 != 0) {
            if (*(int64_t *)(iVar3 + 0x60) != 0) {
                uVar2 = func_0x00018021a8e0(*(undefined8 *)(iVar3 + 0x58));
                *(undefined8 *)(iVar3 + 0x58) = uVar2;
            }
            func_0x00018021a070(*(undefined8 *)(iVar3 + 0x58));
            *(int64_t *)(iVar3 + 0x58) = unaff_RSI;
            if (*(int64_t *)(iVar3 + 0x60) != 0) {
                unaff_RSI = func_0x00018021a960();
                *(int64_t *)(iVar3 + 0x58) = unaff_RSI;
            }
            (**(code **)(*(int64_t *)(iVar3 + 0xc70) + 0x58))(*(undefined8 *)(iVar3 + 0xc80), unaff_RSI);
        }
        return;
    }
    auStackX_18[0] = 0x1801be47c;
    iVar3 = func_0x00018045a350(arg1);
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1801be492;
    iVar1 = func_0x0001801bdce0();
    if (iVar1 != 0) {
        *(int64_t *)((int64_t)&arg_90h + iVar3) = arg_38h;
        *(undefined8 *)((int64_t)&arg_98h + iVar3) = auStackX_18[1];
        uVar2 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_40h + iVar3) + 0x60);
        *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1801be4b1;
        iVar4 = func_0x0001801e8e30(uVar2);
        if (iVar4 != unaff_RSI) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1801be4c4;
            iVar1 = func_0x0001801e9120(uVar2, unaff_RSI);
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1801be4d0;
                func_0x00018021a070(iVar4);
                if (unaff_RSI != 0) {
                    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1801be4eb;
                    func_0x000180219d10(unaff_RSI, 0x66, 1, 0);
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180194431
// Address: 0x180194431
// Size: 101 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_30h

void fcn.1801943f1(int64_t arg1, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_90h, int64_t arg_98h,
                  int64_t arg_b0h)
{
    int32_t in_EAX;
    int32_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t unaff_RSI;
    undefined8 auStackX_18 [2];
    
    iVar3 = arg1;
    if (in_EAX != 0) {
        if ((char)in_EAX < '\0') {
            iVar3 = func_0x0001801bda50();
        } else {
            iVar3 = 0;
        }
    }
    if ((*(uint8_t *)arg1 & 0x80) == 0) {
        if (iVar3 != 0) {
            if (*(int64_t *)(iVar3 + 0x60) != 0) {
                uVar2 = func_0x00018021a8e0(*(undefined8 *)(iVar3 + 0x58));
                *(undefined8 *)(iVar3 + 0x58) = uVar2;
            }
            func_0x00018021a070(*(undefined8 *)(iVar3 + 0x58));
            *(int64_t *)(iVar3 + 0x58) = unaff_RSI;
            if (*(int64_t *)(iVar3 + 0x60) != 0) {
                unaff_RSI = func_0x00018021a960();
                *(int64_t *)(iVar3 + 0x58) = unaff_RSI;
            }
            (**(code **)(*(int64_t *)(iVar3 + 0xc70) + 0x58))(*(undefined8 *)(iVar3 + 0xc80), unaff_RSI);
        }
        return;
    }
    auStackX_18[0] = 0x1801be47c;
    iVar3 = func_0x00018045a350(arg1);
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1801be492;
    iVar1 = func_0x0001801bdce0();
    if (iVar1 != 0) {
        *(int64_t *)((int64_t)&arg_90h + iVar3) = arg_38h;
        *(undefined8 *)((int64_t)&arg_98h + iVar3) = auStackX_18[1];
        uVar2 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_40h + iVar3) + 0x60);
        *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1801be4b1;
        iVar4 = func_0x0001801e8e30(uVar2);
        if (iVar4 != unaff_RSI) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1801be4c4;
            iVar1 = func_0x0001801e9120(uVar2, unaff_RSI);
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1801be4d0;
                func_0x00018021a070(iVar4);
                if (unaff_RSI != 0) {
                    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1801be4eb;
                    func_0x000180219d10(unaff_RSI, 0x66, 1, 0);
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180194496
// Address: 0x180194496
// Size: 1 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_30h

void fcn.1801943f1(int64_t arg1, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_90h, int64_t arg_98h,
                  int64_t arg_b0h)
{
    int32_t in_EAX;
    int32_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t unaff_RSI;
    undefined8 auStackX_18 [2];
    
    iVar3 = arg1;
    if (in_EAX != 0) {
        if ((char)in_EAX < '\0') {
            iVar3 = func_0x0001801bda50();
        } else {
            iVar3 = 0;
        }
    }
    if ((*(uint8_t *)arg1 & 0x80) == 0) {
        if (iVar3 != 0) {
            if (*(int64_t *)(iVar3 + 0x60) != 0) {
                uVar2 = func_0x00018021a8e0(*(undefined8 *)(iVar3 + 0x58));
                *(undefined8 *)(iVar3 + 0x58) = uVar2;
            }
            func_0x00018021a070(*(undefined8 *)(iVar3 + 0x58));
            *(int64_t *)(iVar3 + 0x58) = unaff_RSI;
            if (*(int64_t *)(iVar3 + 0x60) != 0) {
                unaff_RSI = func_0x00018021a960();
                *(int64_t *)(iVar3 + 0x58) = unaff_RSI;
            }
            (**(code **)(*(int64_t *)(iVar3 + 0xc70) + 0x58))(*(undefined8 *)(iVar3 + 0xc80), unaff_RSI);
        }
        return;
    }
    auStackX_18[0] = 0x1801be47c;
    iVar3 = func_0x00018045a350(arg1);
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1801be492;
    iVar1 = func_0x0001801bdce0();
    if (iVar1 != 0) {
        *(int64_t *)((int64_t)&arg_90h + iVar3) = arg_38h;
        *(undefined8 *)((int64_t)&arg_98h + iVar3) = auStackX_18[1];
        uVar2 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_40h + iVar3) + 0x60);
        *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1801be4b1;
        iVar4 = func_0x0001801e8e30(uVar2);
        if (iVar4 != unaff_RSI) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1801be4c4;
            iVar1 = func_0x0001801e9120(uVar2, unaff_RSI);
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1801be4d0;
                func_0x00018021a070(iVar4);
                if (unaff_RSI != 0) {
                    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1801be4eb;
                    func_0x000180219d10(unaff_RSI, 0x66, 1, 0);
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801944a0
// Address: 0x1801944a0
// Size: 117 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_d08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_2e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_2dch
// WARNING: [rz-ghidra] Detected overlap for variable var_2d8h
// WARNING: [rz-ghidra] Detected overlap for variable var_2d4h

uint32_t fcn.1801944a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                      int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h,
                      int64_t arg_e0h)
{
    code *pcVar1;
    int64_t iVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int32_t *in_RCX;
    int32_t *piVar8;
    uint64_t uVar9;
    int32_t iVar10;
    uint32_t uVar11;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801944b0;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    piVar8 = (int32_t *)0x0;
    if (in_RCX != (int32_t *)0x0) {
        if (*in_RCX == 0) {
            piVar8 = in_RCX;
        }
        if ((char)*in_RCX < '\0') {
            iVar10 = 0;
            uVar12 = *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + 8);
            *(undefined8 *)((int64_t)&arg_28h + iVar6) = *(undefined8 *)((int64_t)&arg_28h + iVar6);
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + 8) = uVar12;
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6) = 0x1801bfc00;
            iVar7 = fcn.18045a350();
            iVar7 = -iVar7;
            *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar6) = 0x1801bfc20;
            iVar5 = fcn.1801bdce0(*(int64_t *)((int64_t)&arg_48h + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar7 + iVar6));
            if (iVar5 == 0) {
                return 0;
            }
            iVar2 = *(int64_t *)((int64_t)&arg_60h + iVar7 + iVar6);
            uVar11 = *(uint32_t *)(iVar2 + 0x100);
            if ((uVar11 & 4) == 0) {
                if ((uVar11 & 1) != 0) {
                    if (iVar10 == 0) {
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&arg_40h + iVar7 + iVar6) = 0;
                    *(undefined4 *)((int64_t)&arg_38h + iVar7 + iVar6) = 0x118;
                    *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar6) = 0x1801bfc69;
                    fcn.1801c1390(*(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar6));
                    return 0;
                }
                *(uint32_t *)(iVar2 + 0x100) = uVar11 | 4;
            }
            return 1;
        }
    }
    piVar8[0x1e] = 1;
    piVar8[0x21] = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801944f3;
    fcn.18019b4f0(*(int64_t *)((int64_t)aiStackX_10 + iVar6 + 8));
    *(undefined8 *)(piVar8 + 0x1c) = *(undefined8 *)(*(int64_t *)(in_RCX + 6) + 0x40);
    piVar8 = piVar8 + 0x314;
    uVar12 = *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + 8);
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = *(undefined8 *)((int64_t)&arg_28h + iVar6);
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RSI;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + 8) = uVar12;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar6) = unaff_R14;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + -8) = unaff_R15;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + -0x10) = 0x1801a2fee;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar11 = 1;
    uVar9 = *(uint64_t *)(piVar8 + 0x2e);
    if (uVar9 < *(uint64_t *)(piVar8 + 0x2c)) {
        do {
            *(uint64_t *)(piVar8 + 0x2e) = uVar9 + 1;
            *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar6 + -0x10) = 0x1801a3031;
            uVar3 = fcn.1801a4880(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar6));
            uVar9 = *(uint64_t *)(piVar8 + 0x2e);
            uVar11 = uVar11 & uVar3;
        } while (uVar9 < *(uint64_t *)(piVar8 + 0x2c));
    }
    *(undefined8 *)(piVar8 + 0x14) = 0;
    piVar8[0x16] = 0;
    *(undefined8 *)(piVar8 + 0x18) = 0;
    *(undefined8 *)(piVar8 + 0x1a) = 0;
    *(undefined *)(piVar8 + 0x1c) = 0;
    *(undefined8 *)(piVar8 + 0x1e) = 0;
    piVar8[0x20] = 0;
    *(undefined8 *)(piVar8 + 0x2c) = 0;
    *(undefined8 *)(piVar8 + 0x2e) = 0;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar6 + -0x10) = 0x1801a307c;
    fcn.180219f80(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6));
    *(undefined8 *)(piVar8 + 0xe) = 0;
    if (*(int64_t *)(piVar8 + 6) != 0) {
        pcVar1 = *(code **)(*(int64_t *)(piVar8 + 6) + 8);
        uVar12 = *(undefined8 *)(piVar8 + 10);
        *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar6 + -0x10) = 0x1801a3093;
        (*pcVar1)(uVar12);
    }
    if (*(int64_t *)(piVar8 + 8) != 0) {
        pcVar1 = *(code **)(*(int64_t *)(piVar8 + 8) + 8);
        uVar12 = *(undefined8 *)(piVar8 + 0xc);
        *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar6 + -0x10) = 0x1801a30a6;
        (*pcVar1)(uVar12);
    }
    *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar6 + -0x10) = 0x1801a30af;
    fcn.180219f80(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6));
    *(undefined8 *)(piVar8 + 6) = 0;
    *(undefined8 *)(piVar8 + 8) = 0;
    *(undefined8 *)(piVar8 + 0xe) = 0;
    *(undefined8 *)(piVar8 + 10) = 0;
    *(undefined8 *)(piVar8 + 0xc) = 0;
    if (*(int64_t *)(piVar8 + 0x22) != 0) {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar6 + -0x10) = 0x1801a30d4;
        fcn.1801c71d0(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6), *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6));
    }
    *(undefined8 *)((int64_t)&arg_90h + iVar7 + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_88h + iVar7 + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_80h + iVar7 + iVar6) = 0;
    *(undefined4 *)((int64_t)&arg_78h + iVar7 + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_70h + iVar7 + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_68h + iVar7 + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_60h + iVar7 + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_58h + iVar7 + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_50h + iVar7 + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar7 + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar7 + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar7 + iVar6) = 0;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar6 + -0x10) = 0x1801a3151;
    uVar3 = fcn.1801a4960(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_60h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_70h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_78h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_80h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_88h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_90h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_98h + iVar7 + iVar6), 
                          *(int64_t *)(&stack0x000000a0 + iVar7 + iVar6), *(int64_t *)(&stack0x000000a8 + iVar7 + iVar6)
                          , *(int64_t *)(&stack0x000000b0 + iVar7 + iVar6), 
                          *(int64_t *)(&stack0x000000b8 + iVar7 + iVar6));
    *(undefined8 *)((int64_t)&arg_90h + iVar7 + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_88h + iVar7 + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_80h + iVar7 + iVar6) = 0;
    *(undefined4 *)((int64_t)&arg_78h + iVar7 + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_70h + iVar7 + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_68h + iVar7 + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_60h + iVar7 + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_58h + iVar7 + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_50h + iVar7 + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar7 + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar7 + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar7 + iVar6) = 0;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar6 + -0x10) = 0x1801a31ca;
    uVar4 = fcn.1801a4960(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_60h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_70h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_78h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_80h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_88h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_90h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_98h + iVar7 + iVar6), 
                          *(int64_t *)(&stack0x000000a0 + iVar7 + iVar6), *(int64_t *)(&stack0x000000a8 + iVar7 + iVar6)
                          , *(int64_t *)(&stack0x000000b0 + iVar7 + iVar6), 
                          *(int64_t *)(&stack0x000000b8 + iVar7 + iVar6));
    return uVar4 & uVar3 & uVar11;
}

// ============================================================
// Function: FUN_180194520
// Address: 0x180194520
// Size: 376 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180194520(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t *piVar3;
    int32_t *piVar4;
    int32_t *in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RSI;
    int32_t *piVar5;
    int32_t *in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int32_t *piVar6;
    
    uStack_10 = 0x18019453b;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    piVar6 = (int32_t *)0x0;
    piVar5 = (int32_t *)0x0;
    piVar3 = piVar6;
    if (in_RCX != (int32_t *)0x0) {
        piVar4 = in_RCX;
        if ((*in_RCX != 0) && (piVar4 = piVar6, (char)*in_RCX < '\0')) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194562;
            piVar4 = (int32_t *)func_0x0001801bda50();
        }
        if ((*(uint8_t *)in_RCX & 0x80) == 0) {
            if (piVar4 != (int32_t *)0x0) {
                piVar3 = *(int32_t **)(piVar4 + 0x14);
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194574;
            piVar3 = (int32_t *)func_0x0001801be360(in_RCX);
        }
    }
    if (in_RDX == piVar3) {
        piVar3 = piVar6;
        if (in_RCX != (int32_t *)0x0) {
            piVar4 = in_RCX;
            if ((*in_RCX != 0) && (piVar4 = piVar6, (char)*in_RCX < '\0')) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801945a5;
                piVar4 = (int32_t *)func_0x0001801bda50(in_RCX);
            }
            if ((*(uint8_t *)in_RCX & 0x80) == 0) {
                if (piVar4 != (int32_t *)0x0) {
                    if (*(int64_t *)(piVar4 + 0x18) == 0) {
                        piVar3 = *(int32_t **)(piVar4 + 0x16);
                    } else {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801945cc;
                        piVar3 = (int32_t *)func_0x00018021a8d0();
                    }
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801945b7;
                piVar3 = (int32_t *)func_0x0001801be3a0(in_RCX);
            }
        }
        if (in_R8 == piVar3) {
            return;
        }
    }
    if ((in_RDX != (int32_t *)0x0) && (in_RDX == in_R8)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801945f2;
        iVar1 = func_0x00018021b280(in_RDX);
        if (iVar1 == 0) {
            return;
        }
    }
    piVar3 = piVar6;
    if (in_RCX != (int32_t *)0x0) {
        piVar4 = in_RCX;
        if ((*in_RCX != 0) && (piVar4 = piVar6, (char)*in_RCX < '\0')) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194616;
            piVar4 = (int32_t *)func_0x0001801bda50(in_RCX);
        }
        if ((*(uint8_t *)in_RCX & 0x80) == 0) {
            if (piVar4 != (int32_t *)0x0) {
                piVar3 = *(int32_t **)(piVar4 + 0x14);
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194628;
            piVar3 = (int32_t *)func_0x0001801be360(in_RCX);
        }
    }
    if (in_RDX != piVar3) {
        piVar3 = piVar6;
        if (in_RCX != (int32_t *)0x0) {
            piVar4 = in_RCX;
            if ((*in_RCX != 0) && (piVar4 = piVar6, (char)*in_RCX < '\0')) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019465d;
                piVar4 = (int32_t *)func_0x0001801bda50(in_RCX);
            }
            if ((*(uint8_t *)in_RCX & 0x80) == 0) {
                if (piVar4 != (int32_t *)0x0) {
                    if (*(int64_t *)(piVar4 + 0x18) == 0) {
                        piVar3 = *(int32_t **)(piVar4 + 0x16);
                    } else {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194684;
                        piVar3 = (int32_t *)func_0x00018021a8d0();
                    }
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019466f;
                piVar3 = (int32_t *)func_0x0001801be3a0(in_RCX);
            }
        }
        if (in_R8 == piVar3) {
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RSI;
            piVar3 = piVar6;
            if (in_RCX != (int32_t *)0x0) {
                piVar5 = in_RCX;
                if ((*in_RCX != 0) && (piVar5 = piVar6, (char)*in_RCX < '\0')) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801946bd;
                    piVar5 = (int32_t *)func_0x0001801bda50(in_RCX);
                }
                if ((*(uint8_t *)in_RCX & 0x80) == 0) {
                    if (piVar5 == (int32_t *)0x0) {
                        piVar3 = (int32_t *)0x0;
                    } else {
                        piVar3 = *(int32_t **)(piVar5 + 0x14);
                    }
                } else {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801946cf;
                    piVar3 = (int32_t *)func_0x0001801be360(in_RCX);
                }
                piVar4 = in_RCX;
                if ((*in_RCX != 0) && (piVar4 = piVar6, (char)*in_RCX < '\0')) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801946f9;
                    piVar4 = (int32_t *)func_0x0001801bda50(in_RCX);
                }
                if ((*(uint8_t *)in_RCX & 0x80) == 0) {
                    piVar5 = piVar6;
                    if (piVar4 != (int32_t *)0x0) {
                        if (*(int64_t *)(piVar4 + 0x18) == 0) {
                            piVar5 = *(int32_t **)(piVar4 + 0x16);
                        } else {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194723;
                            piVar5 = (int32_t *)func_0x00018021a8d0();
                        }
                    }
                } else {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019470b;
                    piVar5 = (int32_t *)func_0x0001801be3a0(in_RCX);
                }
            }
            if (piVar3 != piVar5) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194746;
                func_0x000180194270(in_RCX, in_RDX);
                return;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194753;
        func_0x000180194270(in_RCX, in_RDX);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019475e;
    func_0x0001801943d0(in_RCX, in_R8);
    return;
}

// ============================================================
// Function: FUN_180194698
// Address: 0x180194698
// Size: 163 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180194520(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t *piVar3;
    int32_t *piVar4;
    int32_t *in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RSI;
    int32_t *piVar5;
    int32_t *in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int32_t *piVar6;
    
    uStack_10 = 0x18019453b;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    piVar6 = (int32_t *)0x0;
    piVar5 = (int32_t *)0x0;
    piVar3 = piVar6;
    if (in_RCX != (int32_t *)0x0) {
        piVar4 = in_RCX;
        if ((*in_RCX != 0) && (piVar4 = piVar6, (char)*in_RCX < '\0')) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194562;
            piVar4 = (int32_t *)func_0x0001801bda50();
        }
        if ((*(uint8_t *)in_RCX & 0x80) == 0) {
            if (piVar4 != (int32_t *)0x0) {
                piVar3 = *(int32_t **)(piVar4 + 0x14);
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194574;
            piVar3 = (int32_t *)func_0x0001801be360(in_RCX);
        }
    }
    if (in_RDX == piVar3) {
        piVar3 = piVar6;
        if (in_RCX != (int32_t *)0x0) {
            piVar4 = in_RCX;
            if ((*in_RCX != 0) && (piVar4 = piVar6, (char)*in_RCX < '\0')) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801945a5;
                piVar4 = (int32_t *)func_0x0001801bda50(in_RCX);
            }
            if ((*(uint8_t *)in_RCX & 0x80) == 0) {
                if (piVar4 != (int32_t *)0x0) {
                    if (*(int64_t *)(piVar4 + 0x18) == 0) {
                        piVar3 = *(int32_t **)(piVar4 + 0x16);
                    } else {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801945cc;
                        piVar3 = (int32_t *)func_0x00018021a8d0();
                    }
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801945b7;
                piVar3 = (int32_t *)func_0x0001801be3a0(in_RCX);
            }
        }
        if (in_R8 == piVar3) {
            return;
        }
    }
    if ((in_RDX != (int32_t *)0x0) && (in_RDX == in_R8)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801945f2;
        iVar1 = func_0x00018021b280(in_RDX);
        if (iVar1 == 0) {
            return;
        }
    }
    piVar3 = piVar6;
    if (in_RCX != (int32_t *)0x0) {
        piVar4 = in_RCX;
        if ((*in_RCX != 0) && (piVar4 = piVar6, (char)*in_RCX < '\0')) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194616;
            piVar4 = (int32_t *)func_0x0001801bda50(in_RCX);
        }
        if ((*(uint8_t *)in_RCX & 0x80) == 0) {
            if (piVar4 != (int32_t *)0x0) {
                piVar3 = *(int32_t **)(piVar4 + 0x14);
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194628;
            piVar3 = (int32_t *)func_0x0001801be360(in_RCX);
        }
    }
    if (in_RDX != piVar3) {
        piVar3 = piVar6;
        if (in_RCX != (int32_t *)0x0) {
            piVar4 = in_RCX;
            if ((*in_RCX != 0) && (piVar4 = piVar6, (char)*in_RCX < '\0')) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019465d;
                piVar4 = (int32_t *)func_0x0001801bda50(in_RCX);
            }
            if ((*(uint8_t *)in_RCX & 0x80) == 0) {
                if (piVar4 != (int32_t *)0x0) {
                    if (*(int64_t *)(piVar4 + 0x18) == 0) {
                        piVar3 = *(int32_t **)(piVar4 + 0x16);
                    } else {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194684;
                        piVar3 = (int32_t *)func_0x00018021a8d0();
                    }
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019466f;
                piVar3 = (int32_t *)func_0x0001801be3a0(in_RCX);
            }
        }
        if (in_R8 == piVar3) {
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RSI;
            piVar3 = piVar6;
            if (in_RCX != (int32_t *)0x0) {
                piVar5 = in_RCX;
                if ((*in_RCX != 0) && (piVar5 = piVar6, (char)*in_RCX < '\0')) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801946bd;
                    piVar5 = (int32_t *)func_0x0001801bda50(in_RCX);
                }
                if ((*(uint8_t *)in_RCX & 0x80) == 0) {
                    if (piVar5 == (int32_t *)0x0) {
                        piVar3 = (int32_t *)0x0;
                    } else {
                        piVar3 = *(int32_t **)(piVar5 + 0x14);
                    }
                } else {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801946cf;
                    piVar3 = (int32_t *)func_0x0001801be360(in_RCX);
                }
                piVar4 = in_RCX;
                if ((*in_RCX != 0) && (piVar4 = piVar6, (char)*in_RCX < '\0')) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801946f9;
                    piVar4 = (int32_t *)func_0x0001801bda50(in_RCX);
                }
                if ((*(uint8_t *)in_RCX & 0x80) == 0) {
                    piVar5 = piVar6;
                    if (piVar4 != (int32_t *)0x0) {
                        if (*(int64_t *)(piVar4 + 0x18) == 0) {
                            piVar5 = *(int32_t **)(piVar4 + 0x16);
                        } else {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194723;
                            piVar5 = (int32_t *)func_0x00018021a8d0();
                        }
                    }
                } else {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019470b;
                    piVar5 = (int32_t *)func_0x0001801be3a0(in_RCX);
                }
            }
            if (piVar3 != piVar5) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194746;
                func_0x000180194270(in_RCX, in_RDX);
                return;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194753;
        func_0x000180194270(in_RCX, in_RDX);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019475e;
    func_0x0001801943d0(in_RCX, in_R8);
    return;
}

// ============================================================
// Function: FUN_18019473b
// Address: 0x18019473b
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180194520(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t *piVar3;
    int32_t *piVar4;
    int32_t *in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RSI;
    int32_t *piVar5;
    int32_t *in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int32_t *piVar6;
    
    uStack_10 = 0x18019453b;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    piVar6 = (int32_t *)0x0;
    piVar5 = (int32_t *)0x0;
    piVar3 = piVar6;
    if (in_RCX != (int32_t *)0x0) {
        piVar4 = in_RCX;
        if ((*in_RCX != 0) && (piVar4 = piVar6, (char)*in_RCX < '\0')) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194562;
            piVar4 = (int32_t *)func_0x0001801bda50();
        }
        if ((*(uint8_t *)in_RCX & 0x80) == 0) {
            if (piVar4 != (int32_t *)0x0) {
                piVar3 = *(int32_t **)(piVar4 + 0x14);
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194574;
            piVar3 = (int32_t *)func_0x0001801be360(in_RCX);
        }
    }
    if (in_RDX == piVar3) {
        piVar3 = piVar6;
        if (in_RCX != (int32_t *)0x0) {
            piVar4 = in_RCX;
            if ((*in_RCX != 0) && (piVar4 = piVar6, (char)*in_RCX < '\0')) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801945a5;
                piVar4 = (int32_t *)func_0x0001801bda50(in_RCX);
            }
            if ((*(uint8_t *)in_RCX & 0x80) == 0) {
                if (piVar4 != (int32_t *)0x0) {
                    if (*(int64_t *)(piVar4 + 0x18) == 0) {
                        piVar3 = *(int32_t **)(piVar4 + 0x16);
                    } else {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801945cc;
                        piVar3 = (int32_t *)func_0x00018021a8d0();
                    }
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801945b7;
                piVar3 = (int32_t *)func_0x0001801be3a0(in_RCX);
            }
        }
        if (in_R8 == piVar3) {
            return;
        }
    }
    if ((in_RDX != (int32_t *)0x0) && (in_RDX == in_R8)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801945f2;
        iVar1 = func_0x00018021b280(in_RDX);
        if (iVar1 == 0) {
            return;
        }
    }
    piVar3 = piVar6;
    if (in_RCX != (int32_t *)0x0) {
        piVar4 = in_RCX;
        if ((*in_RCX != 0) && (piVar4 = piVar6, (char)*in_RCX < '\0')) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194616;
            piVar4 = (int32_t *)func_0x0001801bda50(in_RCX);
        }
        if ((*(uint8_t *)in_RCX & 0x80) == 0) {
            if (piVar4 != (int32_t *)0x0) {
                piVar3 = *(int32_t **)(piVar4 + 0x14);
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194628;
            piVar3 = (int32_t *)func_0x0001801be360(in_RCX);
        }
    }
    if (in_RDX != piVar3) {
        piVar3 = piVar6;
        if (in_RCX != (int32_t *)0x0) {
            piVar4 = in_RCX;
            if ((*in_RCX != 0) && (piVar4 = piVar6, (char)*in_RCX < '\0')) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019465d;
                piVar4 = (int32_t *)func_0x0001801bda50(in_RCX);
            }
            if ((*(uint8_t *)in_RCX & 0x80) == 0) {
                if (piVar4 != (int32_t *)0x0) {
                    if (*(int64_t *)(piVar4 + 0x18) == 0) {
                        piVar3 = *(int32_t **)(piVar4 + 0x16);
                    } else {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194684;
                        piVar3 = (int32_t *)func_0x00018021a8d0();
                    }
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019466f;
                piVar3 = (int32_t *)func_0x0001801be3a0(in_RCX);
            }
        }
        if (in_R8 == piVar3) {
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RSI;
            piVar3 = piVar6;
            if (in_RCX != (int32_t *)0x0) {
                piVar5 = in_RCX;
                if ((*in_RCX != 0) && (piVar5 = piVar6, (char)*in_RCX < '\0')) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801946bd;
                    piVar5 = (int32_t *)func_0x0001801bda50(in_RCX);
                }
                if ((*(uint8_t *)in_RCX & 0x80) == 0) {
                    if (piVar5 == (int32_t *)0x0) {
                        piVar3 = (int32_t *)0x0;
                    } else {
                        piVar3 = *(int32_t **)(piVar5 + 0x14);
                    }
                } else {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801946cf;
                    piVar3 = (int32_t *)func_0x0001801be360(in_RCX);
                }
                piVar4 = in_RCX;
                if ((*in_RCX != 0) && (piVar4 = piVar6, (char)*in_RCX < '\0')) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801946f9;
                    piVar4 = (int32_t *)func_0x0001801bda50(in_RCX);
                }
                if ((*(uint8_t *)in_RCX & 0x80) == 0) {
                    piVar5 = piVar6;
                    if (piVar4 != (int32_t *)0x0) {
                        if (*(int64_t *)(piVar4 + 0x18) == 0) {
                            piVar5 = *(int32_t **)(piVar4 + 0x16);
                        } else {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194723;
                            piVar5 = (int32_t *)func_0x00018021a8d0();
                        }
                    }
                } else {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019470b;
                    piVar5 = (int32_t *)func_0x0001801be3a0(in_RCX);
                }
            }
            if (piVar3 != piVar5) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194746;
                func_0x000180194270(in_RCX, in_RDX);
                return;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194753;
        func_0x000180194270(in_RCX, in_RDX);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019475e;
    func_0x0001801943d0(in_RCX, in_R8);
    return;
}

// ============================================================
// Function: FUN_180194780
// Address: 0x180194780
// Size: 170 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180194780(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int32_t *piVar2;
    uint64_t uVar3;
    int32_t *in_RCX;
    uint64_t in_RDX;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180194795;
    iVar1 = fcn.18045a350();
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    piVar2 = in_RCX;
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x1801947b5;
        piVar2 = (int32_t *)func_0x0001801bda50();
        if (piVar2 == (int32_t *)0x0) {
            return 0;
        }
    }
    if (((((*(uint8_t *)in_RCX & 0x80) == 0) || ((in_RDX < 2 && (in_R8 < 2)))) &&
        ((uVar3 = 0, in_RDX == 1 || (uVar3 = in_RDX, in_RDX < 0x4001)))) &&
       ((*(uint64_t *)(piVar2 + 0x33c) = uVar3, uVar3 = 0, in_R8 == 1 || (uVar3 = in_R8, in_R8 < 0x4001)))) {
        *(uint64_t *)(piVar2 + 0x33e) = uVar3;
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180194830
// Address: 0x180194830
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180194830(int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    undefined8 uVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t *piVar6;
    int64_t iVar7;
    int32_t *in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180194845;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    piVar6 = in_RCX;
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019486f;
        piVar6 = (int32_t *)func_0x0001801bda50();
        if (piVar6 == (int32_t *)0x0) {
            return 0;
        }
    }
    iVar1 = *(int64_t *)(in_RCX + 2);
    uVar2 = *(undefined8 *)(piVar6 + 0x15a);
    *(undefined8 *)((int64_t)&var_20h + iVar5) = *(undefined8 *)(piVar6 + 0x21e);
    *(undefined8 *)((int64_t)&var_18h + iVar5) = in_RDX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801948ad;
    iVar7 = func_0x00018019f670(iVar1, uVar2, piVar6 + 0x156, piVar6 + 0x158);
    if (iVar7 == 0) {
        return 0;
    }
    pcVar3 = *(code **)(*(int64_t *)(iVar1 + 8) + 0xc0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801948bf;
    iVar4 = (*pcVar3)();
    if (0 < iVar4) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801948cb;
        iVar4 = func_0x0001801950c0(iVar7);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801948d4;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801948ec;
            func_0x0001802295a0(0x1804a94a0, 0xd70, 0x1804a95f0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801948fe;
            func_0x0001802296d0(0x14, 0xb9, 0);
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_180194930
// Address: 0x180194930
// Size: 117 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_d08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_2e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_2dch
// WARNING: [rz-ghidra] Detected overlap for variable var_2d8h
// WARNING: [rz-ghidra] Detected overlap for variable var_2d4h

uint32_t fcn.180194930(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_98h,
                      int64_t arg_e0h)
{
    code *pcVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t *in_RCX;
    int32_t *piVar7;
    uint64_t uVar8;
    int32_t iVar9;
    uint32_t uVar10;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar11;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x180194940;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    piVar7 = (int32_t *)0x0;
    if (in_RCX != (int32_t *)0x0) {
        if (*in_RCX == 0) {
            piVar7 = in_RCX;
        }
        if ((char)*in_RCX < '\0') {
            iVar9 = 0;
            uVar11 = *(undefined8 *)((int64_t)aiStackX_10 + iVar5 + 8);
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = *(undefined8 *)((int64_t)&arg_28h + iVar5);
            *(undefined8 *)((int64_t)aiStackX_10 + iVar5 + 8) = uVar11;
            *(undefined8 *)((int64_t)aiStackX_10 + iVar5) = 0x1801bfcb0;
            iVar6 = fcn.18045a350();
            iVar6 = -iVar6;
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x1801bfcd0;
            iVar4 = fcn.1801bdce0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000060 + iVar6 + iVar5));
            if (iVar4 == 0) {
                return 0;
            }
            uVar10 = *(uint32_t *)(*(int64_t *)(&stack0x00000060 + iVar6 + iVar5) + 0x100);
            if ((uVar10 & 4) != 0) {
                if ((uVar10 & 1) != 0) {
                    if (iVar9 == 0) {
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&arg_40h + iVar6 + iVar5) = 0;
                    *(undefined4 *)((int64_t)&arg_38h + iVar6 + iVar5) = 0x118;
                    *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x1801bfd19;
                    fcn.1801c1390(*(int64_t *)(&stack0x00000058 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
                    return 0;
                }
                *(uint32_t *)(*(int64_t *)(&stack0x00000060 + iVar6 + iVar5) + 0x100) = uVar10 & 0xfffffffb;
            }
            return 1;
        }
    }
    piVar7[0x1e] = 0;
    piVar7[0x21] = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180194983;
    fcn.18019b4f0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8));
    *(undefined8 *)(piVar7 + 0x1c) = *(undefined8 *)(*(int64_t *)(in_RCX + 6) + 0x48);
    piVar7 = piVar7 + 0x314;
    uVar11 = *(undefined8 *)((int64_t)aiStackX_10 + iVar5 + 8);
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = *(undefined8 *)((int64_t)&arg_28h + iVar5);
    *(undefined8 *)(&stack0x00000030 + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar5 + 8) = uVar11;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar5) = unaff_R14;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar5 + -8) = unaff_R15;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar5 + -0x10) = 0x1801a2fee;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar10 = 1;
    uVar8 = *(uint64_t *)(piVar7 + 0x2e);
    if (uVar8 < *(uint64_t *)(piVar7 + 0x2c)) {
        do {
            *(uint64_t *)(piVar7 + 0x2e) = uVar8 + 1;
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5 + -0x10) = 0x1801a3031;
            uVar2 = fcn.1801a4880(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            uVar8 = *(uint64_t *)(piVar7 + 0x2e);
            uVar10 = uVar10 & uVar2;
        } while (uVar8 < *(uint64_t *)(piVar7 + 0x2c));
    }
    *(undefined8 *)(piVar7 + 0x14) = 0;
    piVar7[0x16] = 0;
    *(undefined8 *)(piVar7 + 0x18) = 0;
    *(undefined8 *)(piVar7 + 0x1a) = 0;
    *(undefined *)(piVar7 + 0x1c) = 0;
    *(undefined8 *)(piVar7 + 0x1e) = 0;
    piVar7[0x20] = 0;
    *(undefined8 *)(piVar7 + 0x2c) = 0;
    *(undefined8 *)(piVar7 + 0x2e) = 0;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5 + -0x10) = 0x1801a307c;
    fcn.180219f80(*(int64_t *)((int64_t)&arg_28h + iVar6 + iVar5), *(int64_t *)(&stack0x00000030 + iVar6 + iVar5));
    *(undefined8 *)(piVar7 + 0xe) = 0;
    if (*(int64_t *)(piVar7 + 6) != 0) {
        pcVar1 = *(code **)(*(int64_t *)(piVar7 + 6) + 8);
        uVar11 = *(undefined8 *)(piVar7 + 10);
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5 + -0x10) = 0x1801a3093;
        (*pcVar1)(uVar11);
    }
    if (*(int64_t *)(piVar7 + 8) != 0) {
        pcVar1 = *(code **)(*(int64_t *)(piVar7 + 8) + 8);
        uVar11 = *(undefined8 *)(piVar7 + 0xc);
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5 + -0x10) = 0x1801a30a6;
        (*pcVar1)(uVar11);
    }
    *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5 + -0x10) = 0x1801a30af;
    fcn.180219f80(*(int64_t *)((int64_t)&arg_28h + iVar6 + iVar5), *(int64_t *)(&stack0x00000030 + iVar6 + iVar5));
    *(undefined8 *)(piVar7 + 6) = 0;
    *(undefined8 *)(piVar7 + 8) = 0;
    *(undefined8 *)(piVar7 + 0xe) = 0;
    *(undefined8 *)(piVar7 + 10) = 0;
    *(undefined8 *)(piVar7 + 0xc) = 0;
    if (*(int64_t *)(piVar7 + 0x22) != 0) {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5 + -0x10) = 0x1801a30d4;
        fcn.1801c71d0(*(int64_t *)((int64_t)&arg_28h + iVar6 + iVar5), *(int64_t *)(&stack0x00000030 + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5));
    }
    *(undefined8 *)(&stack0x00000090 + iVar6 + iVar5) = 0;
    *(undefined8 *)(&stack0x00000088 + iVar6 + iVar5) = 0;
    *(undefined8 *)(&stack0x00000080 + iVar6 + iVar5) = 0;
    *(undefined4 *)(&stack0x00000078 + iVar6 + iVar5) = 0;
    *(undefined8 *)(&stack0x00000070 + iVar6 + iVar5) = 0;
    *(undefined8 *)(&stack0x00000068 + iVar6 + iVar5) = 0;
    *(undefined8 *)(&stack0x00000060 + iVar6 + iVar5) = 0;
    *(undefined8 *)(&stack0x00000058 + iVar6 + iVar5) = 0;
    *(undefined8 *)(&stack0x00000050 + iVar6 + iVar5) = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar5) = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar6 + iVar5) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar6 + iVar5) = 0;
    *(undefined8 *)(&stack0x00000030 + iVar6 + iVar5) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar6 + iVar5) = 0;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5 + -0x10) = 0x1801a3151;
    uVar2 = fcn.1801a4960(*(int64_t *)((int64_t)&arg_28h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000030 + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000068 + iVar6 + iVar5), *(int64_t *)(&stack0x00000070 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000078 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000080 + iVar6 + iVar5), *(int64_t *)(&stack0x00000088 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000090 + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_98h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000a0 + iVar6 + iVar5), *(int64_t *)(&stack0x000000a8 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x000000b0 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000b8 + iVar6 + iVar5));
    *(undefined8 *)(&stack0x00000090 + iVar6 + iVar5) = 0;
    *(undefined8 *)(&stack0x00000088 + iVar6 + iVar5) = 0;
    *(undefined8 *)(&stack0x00000080 + iVar6 + iVar5) = 0;
    *(undefined4 *)(&stack0x00000078 + iVar6 + iVar5) = 0;
    *(undefined8 *)(&stack0x00000070 + iVar6 + iVar5) = 0;
    *(undefined8 *)(&stack0x00000068 + iVar6 + iVar5) = 0;
    *(undefined8 *)(&stack0x00000060 + iVar6 + iVar5) = 0;
    *(undefined8 *)(&stack0x00000058 + iVar6 + iVar5) = 0;
    *(undefined8 *)(&stack0x00000050 + iVar6 + iVar5) = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar5) = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar6 + iVar5) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar6 + iVar5) = 0;
    *(undefined8 *)(&stack0x00000030 + iVar6 + iVar5) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar6 + iVar5) = 0;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5 + -0x10) = 0x1801a31ca;
    uVar3 = fcn.1801a4960(*(int64_t *)((int64_t)&arg_28h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000030 + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)(&stack0x00000058 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000060 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000068 + iVar6 + iVar5), *(int64_t *)(&stack0x00000070 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000078 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000080 + iVar6 + iVar5), *(int64_t *)(&stack0x00000088 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000090 + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_98h + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000a0 + iVar6 + iVar5), *(int64_t *)(&stack0x000000a8 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x000000b0 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x000000b8 + iVar6 + iVar5));
    return uVar3 & uVar2 & uVar10;
}

// ============================================================
// Function: FUN_1801949b0
// Address: 0x1801949b0
// Size: 26 bytes
// ============================================================
// WARNING: Type propagation algorithm not settling

bool fcn.1801949b0(int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t in_R8;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    in_RCX = in_RCX + 0x30;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x180224465;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar6 = *(int64_t *)(in_RCX + 8);
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18022447e;
        iVar6 = fcn.180221f20();
        *(int64_t *)(in_RCX + 8) = iVar6;
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18022448c;
            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar5 + iVar4));
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802244a4;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_58h + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000070 + iVar5 + iVar4));
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802244b6;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
            return false;
        }
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar5 + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802244d5;
    iVar2 = fcn.180222010(iVar6);
    while( true ) {
        if (in_EDX < iVar2) {
            uVar1 = *(undefined8 *)(in_RCX + 8);
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x180224503;
            iVar6 = fcn.1802221b0(uVar1, in_EDX, in_R8);
            if (iVar6 != in_R8) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18022450d;
                fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar5 + iVar4));
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x180224525;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                              *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4), 
                              *(int64_t *)((int64_t)&arg_58h + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000070 + iVar5 + iVar4));
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x180224537;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
            }
            return iVar6 == in_R8;
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802244eb;
        iVar3 = fcn.180222110(*(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4), 
                              *(int64_t *)((int64_t)&arg_58h + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000068 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000070 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000078 + iVar5 + iVar4));
        if (iVar3 == 0) break;
        iVar2 = iVar2 + 1;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x180224540;
    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4));
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x180224558;
    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                  *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar5 + iVar4), 
                  *(int64_t *)(&stack0x00000070 + iVar5 + iVar4));
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18022456a;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
    return false;
}

// ============================================================
// Function: FUN_1801949d0
// Address: 0x1801949d0
// Size: 96 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801949d0(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801949e0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar1 = *in_RCX;
    if (iVar1 == 0x81) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801949f9;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a11;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a23;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
    if ((char)iVar1 < '\0') {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a3f;
        fcn.180228720();
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a46;
        fcn.180226be0();
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a4e;
    iVar3 = fcn.18021a7c0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a5b;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a73;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a85;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194aaa;
    fcn.18021a790(*(int64_t *)(&stack0x00000038 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194ab8;
    fcn.180194520(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    return 1;
}

// ============================================================
// Function: FUN_180194a30
// Address: 0x180194a30
// Size: 103 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801949d0(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801949e0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar1 = *in_RCX;
    if (iVar1 == 0x81) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801949f9;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a11;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a23;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
    if ((char)iVar1 < '\0') {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a3f;
        fcn.180228720();
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a46;
        fcn.180226be0();
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a4e;
    iVar3 = fcn.18021a7c0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a5b;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a73;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a85;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194aaa;
    fcn.18021a790(*(int64_t *)(&stack0x00000038 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194ab8;
    fcn.180194520(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    return 1;
}

// ============================================================
// Function: FUN_180194a97
// Address: 0x180194a97
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801949d0(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801949e0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar1 = *in_RCX;
    if (iVar1 == 0x81) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801949f9;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a11;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a23;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
    if ((char)iVar1 < '\0') {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a3f;
        fcn.180228720();
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a46;
        fcn.180226be0();
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a4e;
    iVar3 = fcn.18021a7c0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a5b;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a73;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a85;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194aaa;
    fcn.18021a790(*(int64_t *)(&stack0x00000038 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194ab8;
    fcn.180194520(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    return 1;
}

// ============================================================
// Function: FUN_180194ac2
// Address: 0x180194ac2
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801949d0(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801949e0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar1 = *in_RCX;
    if (iVar1 == 0x81) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801949f9;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a11;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a23;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
    if ((char)iVar1 < '\0') {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a3f;
        fcn.180228720();
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a46;
        fcn.180226be0();
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a4e;
    iVar3 = fcn.18021a7c0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a5b;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a73;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194a85;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194aaa;
    fcn.18021a790(*(int64_t *)(&stack0x00000038 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194ab8;
    fcn.180194520(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    return 1;
}

// ============================================================
// Function: FUN_180194ad0
// Address: 0x180194ad0
// Size: 75 bytes
// ============================================================
undefined8 fcn.180194ad0(int32_t *param_1, undefined8 param_2)
{
    int64_t iVar1;
    undefined8 uStack_10;
    
    uStack_10 = 0x180194adc;
    iVar1 = fcn.18045a350();
    if (param_1 != (int32_t *)0x0) {
        if (*param_1 == 0) {
code_r0x000180194b01:
            *(undefined8 *)(param_1 + 0x552) = param_2;
            return 1;
        }
        if ((char)*param_1 < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x180194afc;
            param_1 = (int32_t *)func_0x0001801bda50(param_1);
            if (param_1 != (int32_t *)0x0) goto code_r0x000180194b01;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180194b20
// Address: 0x180194b20
// Size: 76 bytes
// ============================================================
undefined8
fcn.180194b20(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h,
             int64_t arg_a8h)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined4 *puVar7;
    int32_t *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180194b2c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX != (int32_t *)0x0) {
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180194b46;
            uVar6 = fcn.1801bfd50(*(int64_t *)(&stack0x00000030 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar5), 
                                  *(int64_t *)(&stack0x00000050 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_80h + iVar5), *(int64_t *)(&stack0x00000088 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_90h + iVar5), *(int64_t *)(&stack0x000000b8 + iVar5));
            return uVar6;
        }
        if (*in_RCX == 0) {
            *(uint64_t *)(in_RCX + 0x26a) = *(uint64_t *)(in_RCX + 0x26a) | in_RDX;
            *(undefined8 *)((int64_t)&arg_a8h + iVar5) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180194b7e;
            puVar7 = (undefined4 *)fcn.180229cc0((int64_t)&var_18h + iVar5, 0x1804a9710, in_RCX + 0x26a);
            uVar2 = puVar7[1];
            uVar3 = puVar7[2];
            uVar4 = puVar7[3];
            *(undefined4 *)((int64_t)&arg_48h + iVar5) = *puVar7;
            *(undefined4 *)((int64_t)&arg_48h + iVar5 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000050 + iVar5) = uVar3;
            *(undefined4 *)(&stack0x00000054 + iVar5) = uVar4;
            uVar2 = puVar7[5];
            uVar3 = puVar7[6];
            uVar4 = puVar7[7];
            *(undefined4 *)((int64_t)&arg_58h + iVar5) = puVar7[4];
            *(undefined4 *)((int64_t)&arg_58h + iVar5 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000060 + iVar5) = uVar3;
            *(undefined4 *)(&stack0x00000064 + iVar5) = uVar4;
            *(undefined8 *)((int64_t)&arg_68h + iVar5) = *(undefined8 *)(puVar7 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180194ba4;
            puVar7 = (undefined4 *)fcn.180229ba0((int64_t)&var_18h + iVar5);
            uVar2 = puVar7[1];
            uVar3 = puVar7[2];
            uVar4 = puVar7[3];
            *(undefined4 *)((int64_t)&arg_70h + iVar5) = *puVar7;
            *(undefined4 *)((int64_t)&arg_70h + iVar5 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000078 + iVar5) = uVar3;
            *(undefined4 *)(&stack0x0000007c + iVar5) = uVar4;
            uVar2 = puVar7[5];
            uVar3 = puVar7[6];
            uVar4 = puVar7[7];
            *(undefined4 *)((int64_t)&arg_80h + iVar5) = puVar7[4];
            *(undefined4 *)((int64_t)&arg_80h + iVar5 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000088 + iVar5) = uVar3;
            *(undefined4 *)(&stack0x0000008c + iVar5) = uVar4;
            *(undefined8 *)((int64_t)&arg_90h + iVar5) = *(undefined8 *)(puVar7 + 8);
            pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0x31a) + 0x90);
            uVar6 = *(undefined8 *)(in_RCX + 0x31e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180194be3;
            (*pcVar1)(uVar6, (int64_t)&arg_48h + iVar5);
            pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0x31c) + 0x90);
            uVar6 = *(undefined8 *)(in_RCX + 800);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180194c00;
            (*pcVar1)(uVar6, (int64_t)&arg_48h + iVar5);
            return *(undefined8 *)(in_RCX + 0x26a);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180194b6c
// Address: 0x180194b6c
// Size: 172 bytes
// ============================================================
undefined8
fcn.180194b20(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h,
             int64_t arg_a8h)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined4 *puVar7;
    int32_t *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180194b2c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX != (int32_t *)0x0) {
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180194b46;
            uVar6 = fcn.1801bfd50(*(int64_t *)(&stack0x00000030 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar5), 
                                  *(int64_t *)(&stack0x00000050 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_80h + iVar5), *(int64_t *)(&stack0x00000088 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_90h + iVar5), *(int64_t *)(&stack0x000000b8 + iVar5));
            return uVar6;
        }
        if (*in_RCX == 0) {
            *(uint64_t *)(in_RCX + 0x26a) = *(uint64_t *)(in_RCX + 0x26a) | in_RDX;
            *(undefined8 *)((int64_t)&arg_a8h + iVar5) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180194b7e;
            puVar7 = (undefined4 *)fcn.180229cc0((int64_t)&var_18h + iVar5, 0x1804a9710, in_RCX + 0x26a);
            uVar2 = puVar7[1];
            uVar3 = puVar7[2];
            uVar4 = puVar7[3];
            *(undefined4 *)((int64_t)&arg_48h + iVar5) = *puVar7;
            *(undefined4 *)((int64_t)&arg_48h + iVar5 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000050 + iVar5) = uVar3;
            *(undefined4 *)(&stack0x00000054 + iVar5) = uVar4;
            uVar2 = puVar7[5];
            uVar3 = puVar7[6];
            uVar4 = puVar7[7];
            *(undefined4 *)((int64_t)&arg_58h + iVar5) = puVar7[4];
            *(undefined4 *)((int64_t)&arg_58h + iVar5 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000060 + iVar5) = uVar3;
            *(undefined4 *)(&stack0x00000064 + iVar5) = uVar4;
            *(undefined8 *)((int64_t)&arg_68h + iVar5) = *(undefined8 *)(puVar7 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180194ba4;
            puVar7 = (undefined4 *)fcn.180229ba0((int64_t)&var_18h + iVar5);
            uVar2 = puVar7[1];
            uVar3 = puVar7[2];
            uVar4 = puVar7[3];
            *(undefined4 *)((int64_t)&arg_70h + iVar5) = *puVar7;
            *(undefined4 *)((int64_t)&arg_70h + iVar5 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000078 + iVar5) = uVar3;
            *(undefined4 *)(&stack0x0000007c + iVar5) = uVar4;
            uVar2 = puVar7[5];
            uVar3 = puVar7[6];
            uVar4 = puVar7[7];
            *(undefined4 *)((int64_t)&arg_80h + iVar5) = puVar7[4];
            *(undefined4 *)((int64_t)&arg_80h + iVar5 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000088 + iVar5) = uVar3;
            *(undefined4 *)(&stack0x0000008c + iVar5) = uVar4;
            *(undefined8 *)((int64_t)&arg_90h + iVar5) = *(undefined8 *)(puVar7 + 8);
            pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0x31a) + 0x90);
            uVar6 = *(undefined8 *)(in_RCX + 0x31e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180194be3;
            (*pcVar1)(uVar6, (int64_t)&arg_48h + iVar5);
            pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0x31c) + 0x90);
            uVar6 = *(undefined8 *)(in_RCX + 800);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180194c00;
            (*pcVar1)(uVar6, (int64_t)&arg_48h + iVar5);
            return *(undefined8 *)(in_RCX + 0x26a);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180194c18
// Address: 0x180194c18
// Size: 11 bytes
// ============================================================
undefined8
fcn.180194b20(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h,
             int64_t arg_a8h)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined4 *puVar7;
    int32_t *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180194b2c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX != (int32_t *)0x0) {
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180194b46;
            uVar6 = fcn.1801bfd50(*(int64_t *)(&stack0x00000030 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar5), 
                                  *(int64_t *)(&stack0x00000050 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_80h + iVar5), *(int64_t *)(&stack0x00000088 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_90h + iVar5), *(int64_t *)(&stack0x000000b8 + iVar5));
            return uVar6;
        }
        if (*in_RCX == 0) {
            *(uint64_t *)(in_RCX + 0x26a) = *(uint64_t *)(in_RCX + 0x26a) | in_RDX;
            *(undefined8 *)((int64_t)&arg_a8h + iVar5) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180194b7e;
            puVar7 = (undefined4 *)fcn.180229cc0((int64_t)&var_18h + iVar5, 0x1804a9710, in_RCX + 0x26a);
            uVar2 = puVar7[1];
            uVar3 = puVar7[2];
            uVar4 = puVar7[3];
            *(undefined4 *)((int64_t)&arg_48h + iVar5) = *puVar7;
            *(undefined4 *)((int64_t)&arg_48h + iVar5 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000050 + iVar5) = uVar3;
            *(undefined4 *)(&stack0x00000054 + iVar5) = uVar4;
            uVar2 = puVar7[5];
            uVar3 = puVar7[6];
            uVar4 = puVar7[7];
            *(undefined4 *)((int64_t)&arg_58h + iVar5) = puVar7[4];
            *(undefined4 *)((int64_t)&arg_58h + iVar5 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000060 + iVar5) = uVar3;
            *(undefined4 *)(&stack0x00000064 + iVar5) = uVar4;
            *(undefined8 *)((int64_t)&arg_68h + iVar5) = *(undefined8 *)(puVar7 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180194ba4;
            puVar7 = (undefined4 *)fcn.180229ba0((int64_t)&var_18h + iVar5);
            uVar2 = puVar7[1];
            uVar3 = puVar7[2];
            uVar4 = puVar7[3];
            *(undefined4 *)((int64_t)&arg_70h + iVar5) = *puVar7;
            *(undefined4 *)((int64_t)&arg_70h + iVar5 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000078 + iVar5) = uVar3;
            *(undefined4 *)(&stack0x0000007c + iVar5) = uVar4;
            uVar2 = puVar7[5];
            uVar3 = puVar7[6];
            uVar4 = puVar7[7];
            *(undefined4 *)((int64_t)&arg_80h + iVar5) = puVar7[4];
            *(undefined4 *)((int64_t)&arg_80h + iVar5 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000088 + iVar5) = uVar3;
            *(undefined4 *)(&stack0x0000008c + iVar5) = uVar4;
            *(undefined8 *)((int64_t)&arg_90h + iVar5) = *(undefined8 *)(puVar7 + 8);
            pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0x31a) + 0x90);
            uVar6 = *(undefined8 *)(in_RCX + 0x31e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180194be3;
            (*pcVar1)(uVar6, (int64_t)&arg_48h + iVar5);
            pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0x31c) + 0x90);
            uVar6 = *(undefined8 *)(in_RCX + 800);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180194c00;
            (*pcVar1)(uVar6, (int64_t)&arg_48h + iVar5);
            return *(undefined8 *)(in_RCX + 0x26a);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180194c50
// Address: 0x180194c50
// Size: 124 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined4 fcn.180194c50(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_70h)
{
    int32_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int32_t *piVar6;
    int32_t *piVar7;
    int32_t *in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180194c63;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar4 = 1;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    piVar6 = in_RCX;
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180194c8b;
        piVar6 = (int32_t *)func_0x0001801bda50();
        if (piVar6 == (int32_t *)0x0) {
            return 0;
        }
    }
    if (*in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180194cb3;
        piVar7 = (int32_t *)func_0x00018019b1e0();
        if (in_RDX != piVar7) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180194cbd;
            piVar7 = (int32_t *)func_0x00018019b1f0();
            if (in_RDX != piVar7) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180194cc7;
                piVar7 = (int32_t *)func_0x00018019b200();
                if (in_RDX != piVar7) goto code_r0x000180194ccc;
            }
        }
    } else if (*(int32_t **)(in_RCX + 6) == in_RDX) {
code_r0x000180194ccc:
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RSI;
        piVar7 = *(int32_t **)(in_RCX + 6);
        if (piVar7 != in_RDX) {
            iVar1 = *in_RDX;
            *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_R14;
            iVar2 = *(int64_t *)(piVar6 + 0x1c);
            if (*piVar7 == iVar1) {
                *(int32_t **)(in_RCX + 6) = in_RDX;
            } else {
                pcVar3 = *(code **)(piVar7 + 0xe);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180194cf8;
                (*pcVar3)(in_RCX);
                *(int32_t **)(in_RCX + 6) = in_RDX;
                pcVar3 = *(code **)(in_RDX + 10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180194d05;
                uVar4 = (*pcVar3)(in_RCX);
            }
            if (iVar2 == *(int64_t *)(piVar7 + 0x12)) {
                *(undefined8 *)(piVar6 + 0x1c) = *(undefined8 *)(in_RDX + 0x12);
                return uVar4;
            }
            if (iVar2 == *(int64_t *)(piVar7 + 0x10)) {
                *(undefined8 *)(piVar6 + 0x1c) = *(undefined8 *)(in_RDX + 0x10);
            }
        }
        return uVar4;
    }
    return 0;
}

// ============================================================
// Function: FUN_180194ccc
// Address: 0x180194ccc
// Size: 101 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined4 fcn.180194c50(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_70h)
{
    int32_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int32_t *piVar6;
    int32_t *piVar7;
    int32_t *in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180194c63;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar4 = 1;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    piVar6 = in_RCX;
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180194c8b;
        piVar6 = (int32_t *)func_0x0001801bda50();
        if (piVar6 == (int32_t *)0x0) {
            return 0;
        }
    }
    if (*in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180194cb3;
        piVar7 = (int32_t *)func_0x00018019b1e0();
        if (in_RDX != piVar7) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180194cbd;
            piVar7 = (int32_t *)func_0x00018019b1f0();
            if (in_RDX != piVar7) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180194cc7;
                piVar7 = (int32_t *)func_0x00018019b200();
                if (in_RDX != piVar7) goto code_r0x000180194ccc;
            }
        }
    } else if (*(int32_t **)(in_RCX + 6) == in_RDX) {
code_r0x000180194ccc:
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RSI;
        piVar7 = *(int32_t **)(in_RCX + 6);
        if (piVar7 != in_RDX) {
            iVar1 = *in_RDX;
            *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_R14;
            iVar2 = *(int64_t *)(piVar6 + 0x1c);
            if (*piVar7 == iVar1) {
                *(int32_t **)(in_RCX + 6) = in_RDX;
            } else {
                pcVar3 = *(code **)(piVar7 + 0xe);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180194cf8;
                (*pcVar3)(in_RCX);
                *(int32_t **)(in_RCX + 6) = in_RDX;
                pcVar3 = *(code **)(in_RDX + 10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180194d05;
                uVar4 = (*pcVar3)(in_RCX);
            }
            if (iVar2 == *(int64_t *)(piVar7 + 0x12)) {
                *(undefined8 *)(piVar6 + 0x1c) = *(undefined8 *)(in_RDX + 0x12);
                return uVar4;
            }
            if (iVar2 == *(int64_t *)(piVar7 + 0x10)) {
                *(undefined8 *)(piVar6 + 0x1c) = *(undefined8 *)(in_RDX + 0x10);
            }
        }
        return uVar4;
    }
    return 0;
}

// ============================================================
// Function: FUN_180194d31
// Address: 0x180194d31
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined4 fcn.180194c50(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_70h)
{
    int32_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int32_t *piVar6;
    int32_t *piVar7;
    int32_t *in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180194c63;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar4 = 1;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    piVar6 = in_RCX;
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180194c8b;
        piVar6 = (int32_t *)func_0x0001801bda50();
        if (piVar6 == (int32_t *)0x0) {
            return 0;
        }
    }
    if (*in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180194cb3;
        piVar7 = (int32_t *)func_0x00018019b1e0();
        if (in_RDX != piVar7) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180194cbd;
            piVar7 = (int32_t *)func_0x00018019b1f0();
            if (in_RDX != piVar7) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180194cc7;
                piVar7 = (int32_t *)func_0x00018019b200();
                if (in_RDX != piVar7) goto code_r0x000180194ccc;
            }
        }
    } else if (*(int32_t **)(in_RCX + 6) == in_RDX) {
code_r0x000180194ccc:
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RSI;
        piVar7 = *(int32_t **)(in_RCX + 6);
        if (piVar7 != in_RDX) {
            iVar1 = *in_RDX;
            *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_R14;
            iVar2 = *(int64_t *)(piVar6 + 0x1c);
            if (*piVar7 == iVar1) {
                *(int32_t **)(in_RCX + 6) = in_RDX;
            } else {
                pcVar3 = *(code **)(piVar7 + 0xe);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180194cf8;
                (*pcVar3)(in_RCX);
                *(int32_t **)(in_RCX + 6) = in_RDX;
                pcVar3 = *(code **)(in_RDX + 10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180194d05;
                uVar4 = (*pcVar3)(in_RCX);
            }
            if (iVar2 == *(int64_t *)(piVar7 + 0x12)) {
                *(undefined8 *)(piVar6 + 0x1c) = *(undefined8 *)(in_RDX + 0x12);
                return uVar4;
            }
            if (iVar2 == *(int64_t *)(piVar7 + 0x10)) {
                *(undefined8 *)(piVar6 + 0x1c) = *(undefined8 *)(in_RDX + 0x10);
            }
        }
        return uVar4;
    }
    return 0;
}

// ============================================================
// Function: FUN_180194d44
// Address: 0x180194d44
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined4 fcn.180194c50(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_70h)
{
    int32_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int32_t *piVar6;
    int32_t *piVar7;
    int32_t *in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180194c63;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar4 = 1;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    piVar6 = in_RCX;
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180194c8b;
        piVar6 = (int32_t *)func_0x0001801bda50();
        if (piVar6 == (int32_t *)0x0) {
            return 0;
        }
    }
    if (*in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180194cb3;
        piVar7 = (int32_t *)func_0x00018019b1e0();
        if (in_RDX != piVar7) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180194cbd;
            piVar7 = (int32_t *)func_0x00018019b1f0();
            if (in_RDX != piVar7) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180194cc7;
                piVar7 = (int32_t *)func_0x00018019b200();
                if (in_RDX != piVar7) goto code_r0x000180194ccc;
            }
        }
    } else if (*(int32_t **)(in_RCX + 6) == in_RDX) {
code_r0x000180194ccc:
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RSI;
        piVar7 = *(int32_t **)(in_RCX + 6);
        if (piVar7 != in_RDX) {
            iVar1 = *in_RDX;
            *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_R14;
            iVar2 = *(int64_t *)(piVar6 + 0x1c);
            if (*piVar7 == iVar1) {
                *(int32_t **)(in_RCX + 6) = in_RDX;
            } else {
                pcVar3 = *(code **)(piVar7 + 0xe);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180194cf8;
                (*pcVar3)(in_RCX);
                *(int32_t **)(in_RCX + 6) = in_RDX;
                pcVar3 = *(code **)(in_RDX + 10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180194d05;
                uVar4 = (*pcVar3)(in_RCX);
            }
            if (iVar2 == *(int64_t *)(piVar7 + 0x12)) {
                *(undefined8 *)(piVar6 + 0x1c) = *(undefined8 *)(in_RDX + 0x12);
                return uVar4;
            }
            if (iVar2 == *(int64_t *)(piVar7 + 0x10)) {
                *(undefined8 *)(piVar6 + 0x1c) = *(undefined8 *)(in_RDX + 0x10);
            }
        }
        return uVar4;
    }
    return 0;
}

// ============================================================
// Function: FUN_180194d60
// Address: 0x180194d60
// Size: 332 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.180194d60(int64_t arg_30h, int64_t arg_38h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
                      int64_t arg_70h, int64_t arg_a8h, int64_t arg_c8h)
{
    uint32_t *puVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int32_t *piVar6;
    uint64_t uVar7;
    int64_t iVar8;
    undefined8 uVar9;
    undefined8 uVar10;
    int32_t *in_RCX;
    uint64_t uVar11;
    int64_t iVar12;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar13;
    uint64_t *puVar14;
    uint64_t uVar15;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180194d70;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX == (int32_t *)0x0) {
        return 0xffffffff;
    }
    piVar6 = in_RCX;
    if (*in_RCX != 0) {
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180194d93;
            piVar6 = (int32_t *)func_0x0001801bda50();
        } else {
            piVar6 = (int32_t *)0x0;
        }
    }
    if ((*(uint8_t *)in_RCX & 0x80) == 0) {
        if (piVar6 == (int32_t *)0x0) {
            return 0xffffffff;
        }
        if (*(int64_t *)(piVar6 + 0x1c) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180194dce;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180194de6;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                          *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180194df8;
            iVar3 = func_0x00018019b2a0(in_RCX);
            if (iVar3 == 0) {
                if ((piVar6[0x26c] & 0x100U) != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180194e0d;
                    iVar8 = func_0x0001802395d0();
                    if (iVar8 == 0) {
                        iVar8 = *(int64_t *)(in_RCX + 6);
                        *(undefined8 *)((int64_t)&arg_30h + iVar5) = 2;
                        *(undefined (*) [16])((int64_t)&var_20h + iVar5) = ZEXT816(0);
                        *(int32_t **)((int64_t)&var_18h + iVar5) = in_RCX;
                        *(undefined8 *)((int64_t)&arg_38h + iVar5) = *(undefined8 *)(iVar8 + 0x68);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180194e4a;
                        uVar7 = func_0x000180198150(in_RCX, (int64_t)&var_18h + iVar5, 0x180197a50);
                        return uVar7;
                    }
                }
    // WARNING: Could not recover jumptable at 0x000180194e6a. Too many branches
    // WARNING: Treating indirect jump as call
                uVar7 = (**(code **)(*(int64_t *)(in_RCX + 6) + 0x68))
                                  (in_RCX, *(code **)(*(int64_t *)(in_RCX + 6) + 0x68));
                return uVar7;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180194e72;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180194e8a;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                          *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180194e9c;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0xffffffff;
    }
    puVar14 = (uint64_t *)0x0;
    uVar7 = 0;
    *(undefined8 *)((int64_t)&arg_60h + iVar5) = *(undefined8 *)((int64_t)&arg_58h + iVar5);
    *(undefined8 *)((int64_t)&arg_68h + iVar5) = *(undefined8 *)(&stack0x00000048 + iVar5);
    *(undefined8 *)((int64_t)&arg_70h + iVar5) = unaff_R12;
    *(undefined8 *)(&stack0x00000048 + iVar5) = unaff_RBP;
    *(undefined8 *)(&stack0x00000040 + iVar5) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_R15;
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = 0x1801be521;
    iVar8 = fcn.18045a350(in_RCX, 0, 0, 0);
    iVar8 = -iVar8;
    *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be54c;
    iVar3 = fcn.1801bdce0(*(int64_t *)((int64_t)&arg_68h + iVar8 + iVar5), 
                          *(int64_t *)((int64_t)&arg_70h + iVar8 + iVar5), 
                          *(int64_t *)(&stack0x00000080 + iVar8 + iVar5));
    if (iVar3 == 0) {
        return 0xffffffff;
    }
    iVar3 = *(int32_t *)((int64_t)&var_20h + iVar5);
    *(undefined8 *)((int64_t)&arg_c8h + iVar8 + iVar5) = unaff_RSI;
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_60h + iVar8 + iVar5) = 0;
        *(undefined4 *)((int64_t)&arg_58h + iVar8 + iVar5) = 0x164;
        *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be594;
        fcn.1801c1390(*(int64_t *)(&stack0x00000078 + iVar8 + iVar5), *(int64_t *)(&stack0x00000080 + iVar8 + iVar5), 
                      *(int64_t *)(&stack0x00000088 + iVar8 + iVar5));
        return 0xffffffff;
    }
    uVar9 = *(undefined8 *)(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5) + 0x58);
    *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be5ab;
    uVar9 = fcn.1801dd6c0(uVar9);
    *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be5b3;
    fcn.18026d890(uVar9);
    uVar9 = *(undefined8 *)(*(int64_t *)((int64_t)&var_10h + iVar5) + 0xa0);
    *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be5c3;
    iVar3 = func_0x0001801e3b70(uVar9);
    if (iVar3 != 0) goto code_r0x0001801be81e;
    if ((uVar7 & 8) == 0) {
        if (puVar14 != (uint64_t *)0x0) {
            uVar13 = puVar14[1];
            uVar11 = *puVar14;
            uVar9 = *(undefined8 *)(*(int64_t *)((int64_t)&var_10h + iVar5) + 0xa0);
            *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be5f0;
            func_0x0001801e4e10(uVar9, uVar11, uVar13);
        }
        if ((uVar7 & 2) == 0) {
            iVar12 = *(int64_t *)((int64_t)&var_10h + iVar5);
            if ((*(uint8_t *)(iVar12 + 0x100) & 0x20) == 0) {
                uVar9 = *(undefined8 *)(iVar12 + 0xa0);
                *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be612;
                uVar9 = func_0x0001801e39c0(uVar9);
                *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be61a;
                func_0x0001801e7750(uVar9);
                *(uint32_t *)(iVar12 + 0x100) = *(uint32_t *)(iVar12 + 0x100) | 0x20;
                iVar12 = *(int64_t *)((int64_t)&var_10h + iVar5);
            }
            *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be62d;
            iVar3 = func_0x0001801c0580(iVar12);
            if (iVar3 == 0) {
                if ((uVar7 & 4) == 0) {
                    uVar9 = *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5);
                    *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be643;
                    iVar3 = func_0x0001801bd970(uVar9);
                    if (iVar3 == 0) goto code_r0x0001801be686;
                    uVar9 = *(undefined8 *)((int64_t)&var_10h + iVar5);
                    uVar10 = *(undefined8 *)(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5) + 0x58);
                    *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be65d;
                    func_0x0001801dd840(uVar10, 0);
                    *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be665;
                    uVar10 = func_0x0001801dd6d0(uVar10);
                    *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be67a;
                    iVar3 = func_0x0001801dcf10(uVar10, 0x1801c1ae0, uVar9, 0);
                    if (0 < iVar3) goto code_r0x0001801be6cf;
                    goto code_r0x0001801be67f;
                }
code_r0x0001801be686:
                iVar12 = *(int64_t *)(&stack0xfffffffffffffff8 + iVar5);
                uVar4 = *(uint32_t *)(iVar12 + 0x70);
                iVar2 = iVar12;
                while (uVar4 = uVar4 >> 5 & 3, uVar4 == 0) {
                    iVar2 = *(int64_t *)(iVar2 + 0x40);
                    if (iVar2 == 0) goto code_r0x0001801be6bc;
                    uVar4 = *(uint32_t *)(iVar2 + 0x70);
                }
                if (uVar4 != 2) {
code_r0x0001801be6bc:
                    uVar9 = *(undefined8 *)(iVar12 + 0x58);
                    *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be6c5;
                    uVar9 = func_0x0001801dd6d0(uVar9);
                    *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be6cf;
                    func_0x0001801dd2b0(uVar9, 0);
                }
            }
code_r0x0001801be6cf:
            uVar9 = *(undefined8 *)((int64_t)&var_10h + iVar5);
            *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be6d8;
            iVar3 = func_0x0001801c0580(uVar9);
            if (iVar3 == 0) {
                uVar9 = *(undefined8 *)(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5) + 0x58);
                *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be6ed;
                uVar9 = fcn.1801dd6c0(uVar9);
                *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be6f5;
                fcn.18026d900(uVar9);
                return 0;
            }
        }
    } else {
        uVar9 = *(undefined8 *)(*(int64_t *)((int64_t)&var_10h + iVar5) + 0xa0);
        *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be70c;
        iVar3 = func_0x0001801e3b50(uVar9);
        if (iVar3 != 0) goto code_r0x0001801be7c7;
        if ((uVar7 & 4) == 0) {
            uVar9 = *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5);
            *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be722;
            iVar3 = func_0x0001801bd970(uVar9);
            if (iVar3 == 0) goto code_r0x0001801be765;
            uVar9 = *(undefined8 *)((int64_t)&var_10h + iVar5);
            uVar10 = *(undefined8 *)(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5) + 0x58);
            *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be73c;
            func_0x0001801dd840(uVar10, 0);
            *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be744;
            uVar10 = func_0x0001801dd6d0(uVar10);
            *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be759;
            iVar3 = func_0x0001801dcf10(uVar10, 0x1801c1b40, uVar9, 0);
            if (iVar3 < 1) {
                uVar13 = 0;
                goto code_r0x0001801be8e2;
            }
        } else {
code_r0x0001801be765:
            iVar12 = *(int64_t *)(&stack0xfffffffffffffff8 + iVar5);
            uVar4 = *(uint32_t *)(iVar12 + 0x70);
            iVar2 = iVar12;
            while (uVar4 = uVar4 >> 5 & 3, uVar4 == 0) {
                iVar2 = *(int64_t *)(iVar2 + 0x40);
                if (iVar2 == 0) goto code_r0x0001801be79c;
                uVar4 = *(uint32_t *)(iVar2 + 0x70);
            }
            if (uVar4 != 2) {
code_r0x0001801be79c:
                uVar9 = *(undefined8 *)(iVar12 + 0x58);
                *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be7a5;
                uVar9 = func_0x0001801dd6d0(uVar9);
                *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be7af;
                func_0x0001801dd2b0(uVar9, 0);
            }
        }
        uVar9 = *(undefined8 *)(*(int64_t *)((int64_t)&var_10h + iVar5) + 0xa0);
        *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be7bf;
        iVar3 = func_0x0001801e3b50(uVar9);
        if (iVar3 == 0) {
code_r0x0001801be67f:
            uVar13 = 0;
            goto code_r0x0001801be8e2;
        }
    }
code_r0x0001801be7c7:
    uVar13 = 0;
    puVar1 = (uint32_t *)(*(int64_t *)((int64_t)&var_10h + iVar5) + 0x100);
    *puVar1 = *puVar1 | 0x20;
    uVar11 = uVar13;
    uVar15 = uVar13;
    if (puVar14 != (uint64_t *)0x0) {
        uVar11 = *puVar14;
        uVar15 = puVar14[1];
    }
    uVar9 = *(undefined8 *)(*(int64_t *)((int64_t)&var_10h + iVar5) + 0xa0);
    *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be7f8;
    func_0x0001801e3b90(uVar9, uVar11, uVar15);
    uVar9 = *(undefined8 *)(*(int64_t *)((int64_t)&var_10h + iVar5) + 0x78);
    *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be80a;
    func_0x000180194c30(uVar9, 1);
    uVar9 = *(undefined8 *)(*(int64_t *)((int64_t)&var_10h + iVar5) + 0xa0);
    *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be81a;
    iVar3 = func_0x0001801e3b70(uVar9);
    if (iVar3 != 0) {
code_r0x0001801be81e:
        uVar9 = *(undefined8 *)(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5) + 0x58);
        *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be82b;
        uVar9 = fcn.1801dd6c0(uVar9);
        *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be833;
        fcn.18026d900(uVar9);
        return 1;
    }
    if ((uVar7 & 4) == 0) {
        uVar9 = *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5);
        *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be84b;
        iVar3 = func_0x0001801bd970(uVar9);
        if ((iVar3 == 0) || ((uVar7 & 1) != 0)) goto code_r0x0001801be88f;
        uVar9 = *(undefined8 *)((int64_t)&var_10h + iVar5);
        uVar10 = *(undefined8 *)(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5) + 0x58);
        *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be86b;
        func_0x0001801dd840(uVar10, 0);
        *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be873;
        uVar10 = func_0x0001801dd6d0(uVar10);
        *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be888;
        iVar3 = func_0x0001801dcf10(uVar10, 0x1801c1b60, uVar9, 0);
        if (iVar3 < 1) goto code_r0x0001801be8e2;
    } else {
code_r0x0001801be88f:
        iVar12 = *(int64_t *)(&stack0xfffffffffffffff8 + iVar5);
        uVar4 = *(uint32_t *)(iVar12 + 0x70);
        iVar2 = iVar12;
        while (uVar4 = uVar4 >> 5 & 3, uVar4 == 0) {
            iVar2 = *(int64_t *)(iVar2 + 0x40);
            if (iVar2 == 0) goto code_r0x0001801be8bd;
            uVar4 = *(uint32_t *)(iVar2 + 0x70);
        }
        if (uVar4 != 2) {
code_r0x0001801be8bd:
            uVar9 = *(undefined8 *)(iVar12 + 0x58);
            *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be8c6;
            uVar9 = func_0x0001801dd6d0(uVar9);
            *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be8d0;
            func_0x0001801dd2b0(uVar9, 0);
        }
    }
    uVar9 = *(undefined8 *)(*(int64_t *)((int64_t)&var_10h + iVar5) + 0xa0);
    *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be8e0;
    uVar4 = func_0x0001801e3b70(uVar9);
    uVar13 = (uint64_t)uVar4;
code_r0x0001801be8e2:
    uVar9 = *(undefined8 *)(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5) + 0x58);
    *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be8ef;
    uVar9 = fcn.1801dd6c0(uVar9);
    *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = 0x1801be8f7;
    fcn.18026d900(uVar9);
    return uVar13;
}

// ============================================================
// Function: FUN_180194ed0
// Address: 0x180194ed0
// Size: 96 bytes
// ============================================================
int32_t fcn.180194ed0(int32_t *param_1)
{
    int64_t iVar1;
    int32_t *piVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x180194edc;
    iVar1 = fcn.18045a350();
    if (param_1 != (int32_t *)0x0) {
        piVar2 = param_1;
        if (*param_1 == 0) goto code_r0x000180194eff;
        if ((char)*param_1 < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x180194efb;
            piVar2 = (int32_t *)func_0x0001801bda50();
            goto code_r0x000180194eff;
        }
    }
    piVar2 = (int32_t *)0x0;
code_r0x000180194eff:
    if ((*param_1 != 0x80) && (*param_1 != 0x81)) {
        if (piVar2 != (int32_t *)0x0) {
            return piVar2[0x12];
        }
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_180194f30
// Address: 0x180194f30
// Size: 90 bytes
// ============================================================
int32_t fcn.180194f30(int64_t arg_38h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t *piVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined4 uVar6;
    int32_t *in_RCX;
    int32_t iVar7;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x180194f3c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX != (int32_t *)0x0) {
        piVar3 = in_RCX;
        if (*in_RCX != 0) {
            if ((char)*in_RCX < '\0') {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180194f5b;
                piVar3 = (int32_t *)func_0x0001801bda50();
            } else {
                piVar3 = (int32_t *)0x0;
            }
        }
        if ((*(uint8_t *)in_RCX & 0x80) != 0) {
            *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 8) = *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 8);
            *(undefined8 *)((int64_t)auStackX_10 + iVar2) = 0x1801bff0c;
            iVar4 = fcn.18045a350(in_RCX);
            iVar4 = -iVar4;
            iVar7 = 3;
            *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar2) = 0x1801bff21;
            iVar1 = fcn.1801bdce0(*(int64_t *)(&stack0x00000048 + iVar4 + iVar2), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar2), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar2));
            if (iVar1 != 0) {
                uVar5 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_38h + iVar4 + iVar2) + 0x58);
                *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar2) = 0x1801bff3e;
                uVar5 = fcn.1801dd6c0(uVar5);
                *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar2) = 0x1801bff46;
                fcn.18026d890(uVar5);
                if (*(int32_t *)((int64_t)&arg_60h + iVar4 + iVar2) == 0) {
                    uVar6 = *(undefined4 *)(*(int64_t *)((int64_t)&arg_50h + iVar4 + iVar2) + 0x128);
                } else {
                    uVar6 = *(undefined4 *)(*(int64_t *)((int64_t)&arg_58h + iVar4 + iVar2) + 0xb8);
                }
    // switch table (11 cases) at 0x1801bffc4
                switch(uVar6) {
                case 2:
                    break;
                case 3:
                    iVar7 = 2;
                    break;
                case 4:
                    iVar7 = 4;
                    break;
                default:
                    iVar7 = 1;
                    break;
                case 0xb:
                    iVar7 = 7;
                    break;
                case 0xc:
                    iVar7 = 8;
                }
                uVar5 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_38h + iVar4 + iVar2) + 0x58);
                *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar2) = 0x1801bffb2;
                uVar5 = fcn.1801dd6c0(uVar5);
                *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar2) = 0x1801bffba;
                fcn.18026d900(uVar5);
                return iVar7;
            }
            return 1;
        }
        if (piVar3 != (int32_t *)0x0) {
            return piVar3[0x1a];
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_180194f90
// Address: 0x180194f90
// Size: 108 bytes
// ============================================================
int32_t fcn.180194f90(int64_t arg_58h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t in_R8D;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180194f9a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_R8D < 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180194fa7;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180194fbf;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180194fd1;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar2));
        return -1;
    }
    *(int64_t *)((int64_t)&var_20h + iVar2) = (int64_t)&arg_58h + iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180194ff0;
    iVar1 = fcn.180198780(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                          *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                          *(int64_t *)(&stack0x00000040 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2), 
                          *(int64_t *)(&stack0x00000080 + iVar2));
    if (0 < iVar1) {
        iVar1 = *(int32_t *)((int64_t)&arg_58h + iVar2);
    }
    return iVar1;
}

// ============================================================
// Function: FUN_180195000
// Address: 0x180195000
// Size: 177 bytes
// ============================================================
undefined8 fcn.180195000(int64_t param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18019500a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(param_1 + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar1 = **(int32_t **)(param_1 + 0x18), 0x303 < iVar1)) && (iVar1 != 0x10000)) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180195033;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18019504b;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18019505d;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar2));
        return 0;
    }
    if ((*(uint32_t *)(param_1 + 0x9a8) >> 0x1e & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180195076;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18019508e;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801950a0;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar2));
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801950c0
// Address: 0x1801950c0
// Size: 121 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int32_t fcn.1801950c0(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int32_t iVar4;
    int32_t iVar5;
    undefined8 unaff_RSI;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801950d0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar4 = 0;
    if (in_RCX != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RSI;
        iVar5 = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801950f6;
        iVar1 = fcn.180222010();
        if (0 < iVar1) {
            do {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019510a;
                iVar3 = fcn.180222340(in_RCX, iVar5);
                iVar1 = iVar4 + 1;
                if (0x303 < *(int32_t *)(iVar3 + 0x2c)) {
                    iVar1 = iVar4;
                }
                iVar4 = iVar1;
                iVar5 = iVar5 + 1;
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180195123;
                iVar1 = fcn.180222010(in_RCX);
            } while (iVar5 < iVar1);
        }
        return iVar4;
    }
    return 0;
}

// ============================================================
// Function: FUN_180195140
// Address: 0x180195140
// Size: 221 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.180195140(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t *in_RCX;
    undefined8 in_RDX;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180195160;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar5 = 0;
    if (*in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019517a;
        iVar3 = fcn.180221f20();
        *in_RCX = iVar3;
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180195187;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019519f;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801951b1;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
            goto code_r0x0001801951b1;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801951c8;
    uVar4 = func_0x000180222020(in_RDX);
    uVar6 = uVar5;
    while( true ) {
        uVar5 = uVar4;
        if (uVar5 == 0) {
            return uVar6;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801951da;
        iVar1 = func_0x00018023a520(uVar5, in_R8 & 0xffffffff);
        if (iVar1 != 1) break;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801951ea;
        iVar1 = fcn.180222110(*(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                              *(int64_t *)((int64_t)&arg_40h + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar2));
        if (iVar1 == 0) break;
        uVar6 = (uint64_t)((int32_t)uVar6 + 1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801951f8;
        uVar4 = func_0x000180222020(in_RDX);
    }
code_r0x0001801951b1:
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801951b9;
    func_0x00018023a330(uVar5);
    return 0xffffffff;
}

// ============================================================
// Function: FUN_180195220
// Address: 0x180195220
// Size: 108 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180195220(int64_t arg_28h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180195230;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar1 = *(undefined8 *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180195246;
    fcn.180222290(uVar1, 0x180196ec0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180195255;
    fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000050 + iVar2));
    uVar1 = *(undefined8 *)(in_RCX + 0x10);
    *(undefined8 *)(in_RCX + 8) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180195264;
    fcn.180238640(uVar1);
    *(undefined8 *)(in_RCX + 0x10) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180195271;
    fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)(in_RCX + 0x20) = 0;
    *(undefined8 *)(in_RCX + 0x18) = 0;
    *(undefined8 *)(in_RCX + 0x2c) = 0xffffffffffffffff;
    return;
}

// ============================================================
// Function: FUN_180195290
// Address: 0x180195290
// Size: 20 bytes
// ============================================================
void fcn.180195290(undefined8 param_1, undefined8 param_2, code *UNRECOVERED_JUMPTABLE)
{
    fcn.18045a350();
    // WARNING: Could not recover jumptable at 0x0001801952a1. Too many branches
    // WARNING: Treating indirect jump as call
    (*UNRECOVERED_JUMPTABLE)();
    return;
}

// ============================================================
// Function: FUN_1801952b0
// Address: 0x1801952b0
// Size: 20 bytes
// ============================================================
void fcn.1801952b0(undefined8 param_1, code *UNRECOVERED_JUMPTABLE)
{
    fcn.18045a350();
    // WARNING: Could not recover jumptable at 0x0001801952c1. Too many branches
    // WARNING: Treating indirect jump as call
    (*UNRECOVERED_JUMPTABLE)();
    return;
}

// ============================================================
// Function: FUN_1801952d0
// Address: 0x1801952d0
// Size: 401 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1801952d0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                     int64_t arg_60h)
{
    uint8_t uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    code *pcVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined *puVar9;
    undefined8 in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t in_R8;
    uint64_t uVar10;
    uint64_t in_R9;
    uint64_t uVar11;
    undefined8 unaff_R12;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801952e3;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar7 = *(int64_t *)(in_RDX + 8);
    iVar2 = *(int64_t *)((int64_t)&arg_58h + iVar6);
    *(int64_t *)((int64_t)&arg_40h + iVar6) = iVar7;
    if (*(int64_t *)(iVar7 + 1000) != 0) {
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_RDI;
        *(undefined8 *)((int64_t)&arg_50h + iVar6) = unaff_R12;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180195333;
        iVar7 = fcn.180498cd0();
        uVar3 = *(uint64_t *)((int64_t)&arg_60h + iVar6);
        *(uint64_t *)((int64_t)&var_8h + iVar6) = (in_R9 + uVar3) * 2 + 3 + iVar7;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180195367;
        iVar8 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180195381;
            fcn.180498030(iVar8, in_RCX);
            uVar10 = 0;
            *(undefined *)(iVar7 + iVar8) = 0x20;
            puVar9 = (undefined *)(iVar8 + 1 + iVar7);
            uVar11 = uVar10;
            if (in_R9 != 0) {
                do {
                    uVar1 = *(uint8_t *)(uVar11 + in_R8);
                    uVar11 = uVar11 + 1;
                    *puVar9 = *(undefined *)((uint64_t)(uVar1 >> 4) + 0x1804a9438);
                    puVar9[1] = *(undefined *)((uint64_t)(uVar1 & 0xf) + 0x1804a9438);
                    puVar9 = puVar9 + 2;
                } while (uVar11 < in_R9);
            }
            *puVar9 = 0x20;
            puVar9 = puVar9 + 1;
            if (uVar3 != 0) {
                do {
                    uVar1 = *(uint8_t *)(iVar2 + uVar10);
                    uVar10 = uVar10 + 1;
                    *puVar9 = *(undefined *)((uint64_t)(uVar1 >> 4) + 0x1804a9438);
                    puVar9[1] = *(undefined *)((uint64_t)(uVar1 & 0xf) + 0x1804a9438);
                    puVar9 = puVar9 + 2;
                } while (uVar10 < uVar3);
            }
            *puVar9 = 0;
            pcVar4 = *(code **)(*(int64_t *)((int64_t)&arg_40h + iVar6) + 1000);
            if (pcVar4 != (code *)0x0) {
                uVar5 = *(undefined8 *)(in_RDX + 0x40);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180195426;
                (*pcVar4)(uVar5, iVar8);
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180195440;
            fcn.180224b90(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
            iVar8 = 1;
        }
        return iVar8;
    }
    return 1;
}

// ============================================================
// Function: FUN_180195470
// Address: 0x180195470
// Size: 310 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_61h

undefined8
fcn.180195470(undefined8 placeholder_0, int64_t *placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_40h,
             int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    int32_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int32_t *piVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar10;
    undefined8 unaff_RDI;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18019548b;
    var_18h = arg3;
    var_20h = arg4;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (placeholder_1[1] == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x1801954a2;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        if (*(int32_t *)((int64_t)&arg_68h + iVar6) == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x1801954f2;
            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                          *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                          *(int64_t *)(&stack0x00000030 + iVar6));
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x180195504;
            fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x1801954c4;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)(&stack0x00000030 + iVar6));
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x1801954da;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar6));
        return 0;
    }
    iVar1 = *(int32_t *)((int64_t)&arg_60h + iVar6);
    uVar10 = (uint64_t)(iVar1 != 0) + 2;
    if ((uint64_t)placeholder_1[1] % uVar10 != 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x180195536;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        if (*(int32_t *)((int64_t)&arg_68h + iVar6) == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x180195586;
            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                          *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                          *(int64_t *)(&stack0x00000030 + iVar6));
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x180195598;
            fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x180195558;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)(&stack0x00000030 + iVar6));
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18019556e;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_10h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_8h + iVar6) = unaff_RDI;
    *(undefined8 *)(&stack0x00000000 + iVar6) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x1801955bf;
    iVar7 = fcn.180221f20();
    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x1801955c7;
    iVar8 = fcn.180221f20();
    if ((iVar7 == 0) || (iVar8 == 0)) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x180195748;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        iVar1 = *(int32_t *)((int64_t)&arg_68h + iVar6);
    } else {
code_r0x0001801955e0:
        do {
            do {
                do {
                    uVar2 = placeholder_1[1];
                    if (uVar2 < uVar10) {
                        if (uVar2 == 0) {
                            if (*(int64_t **)((int64_t)&arg_50h + iVar6) == (int64_t *)0x0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x180195720;
                                fcn.180221d50(iVar7);
                            } else {
                                **(int64_t **)((int64_t)&arg_50h + iVar6) = iVar7;
                            }
                            if (*(int64_t **)((int64_t)&arg_58h + iVar6) != (int64_t *)0x0) {
                                **(int64_t **)((int64_t)&arg_58h + iVar6) = iVar8;
                                return 1;
                            }
                            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18019573c;
                            fcn.180221d50(iVar8);
                            return 1;
                        }
                        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x1801956b8;
                        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
                        if (*(int32_t *)((int64_t)&arg_68h + iVar6) == 0) {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x1801956ff;
                            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6)
                                          , *(int64_t *)((int64_t)&var_10h + iVar6), 
                                          *(int64_t *)((int64_t)&var_18h + iVar6), 
                                          *(int64_t *)(&stack0x00000030 + iVar6));
                            goto code_r0x000180195791;
                        }
                        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x1801956da;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                      *(int64_t *)(&stack0x00000030 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x1801956f0;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar6));
                        goto code_r0x00018019579e;
                    }
                    iVar3 = *placeholder_1;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x180195603;
                    fcn.180498030((int64_t)&arg_60h + iVar6, iVar3, uVar10);
                    *placeholder_1 = iVar3 + uVar10;
                    placeholder_1[1] = uVar2 - uVar10;
                } while ((iVar1 != 0) && (*(char *)((int64_t)&arg_60h + iVar6) != '\0'));
                piVar4 = &arg_60h;
                if (iVar1 != 0) {
                    piVar4 = (int64_t *)((int64_t)&arg_60h + 1);
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x180195645;
                piVar9 = (int32_t *)fcn.1801a0300(placeholder_0, (int64_t)piVar4 + iVar6, 1);
            } while (piVar9 == (int32_t *)0x0);
            if (*piVar9 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18019565d;
                iVar5 = fcn.180222110(*(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                      *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                      *(int64_t *)(&stack0x00000038 + iVar6));
                if (iVar5 == 0) break;
                if (*piVar9 != 0) goto code_r0x0001801955e0;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x180195675;
            iVar5 = fcn.180222110(*(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                  *(int64_t *)(&stack0x00000038 + iVar6));
        } while (iVar5 != 0);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x180195682;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        iVar1 = *(int32_t *)((int64_t)&arg_68h + iVar6);
    }
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18019578c;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)(&stack0x00000030 + iVar6));
code_r0x000180195791:
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18019579e;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18019576a;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)(&stack0x00000030 + iVar6));
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x180195780;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar6));
    }
code_r0x00018019579e:
    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x1801957a6;
    fcn.180221d50(iVar7);
    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x1801957ae;
    fcn.180221d50(iVar8);
    return 0;
}

// ============================================================
// Function: FUN_1801955a6
// Address: 0x1801955a6
// Size: 554 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_61h

undefined8
fcn.180195470(undefined8 placeholder_0, int64_t *placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_40h,
             int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    int32_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int32_t *piVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar10;
    undefined8 unaff_RDI;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18019548b;
    var_18h = arg3;
    var_20h = arg4;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (placeholder_1[1] == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x1801954a2;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        if (*(int32_t *)((int64_t)&arg_68h + iVar6) == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x1801954f2;
            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                          *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                          *(int64_t *)(&stack0x00000030 + iVar6));
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x180195504;
            fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x1801954c4;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)(&stack0x00000030 + iVar6));
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x1801954da;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar6));
        return 0;
    }
    iVar1 = *(int32_t *)((int64_t)&arg_60h + iVar6);
    uVar10 = (uint64_t)(iVar1 != 0) + 2;
    if ((uint64_t)placeholder_1[1] % uVar10 != 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x180195536;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        if (*(int32_t *)((int64_t)&arg_68h + iVar6) == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x180195586;
            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                          *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                          *(int64_t *)(&stack0x00000030 + iVar6));
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x180195598;
            fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x180195558;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)(&stack0x00000030 + iVar6));
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18019556e;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_10h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_8h + iVar6) = unaff_RDI;
    *(undefined8 *)(&stack0x00000000 + iVar6) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x1801955bf;
    iVar7 = fcn.180221f20();
    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x1801955c7;
    iVar8 = fcn.180221f20();
    if ((iVar7 == 0) || (iVar8 == 0)) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x180195748;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        iVar1 = *(int32_t *)((int64_t)&arg_68h + iVar6);
    } else {
code_r0x0001801955e0:
        do {
            do {
                do {
                    uVar2 = placeholder_1[1];
                    if (uVar2 < uVar10) {
                        if (uVar2 == 0) {
                            if (*(int64_t **)((int64_t)&arg_50h + iVar6) == (int64_t *)0x0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x180195720;
                                fcn.180221d50(iVar7);
                            } else {
                                **(int64_t **)((int64_t)&arg_50h + iVar6) = iVar7;
                            }
                            if (*(int64_t **)((int64_t)&arg_58h + iVar6) != (int64_t *)0x0) {
                                **(int64_t **)((int64_t)&arg_58h + iVar6) = iVar8;
                                return 1;
                            }
                            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18019573c;
                            fcn.180221d50(iVar8);
                            return 1;
                        }
                        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x1801956b8;
                        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
                        if (*(int32_t *)((int64_t)&arg_68h + iVar6) == 0) {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x1801956ff;
                            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6)
                                          , *(int64_t *)((int64_t)&var_10h + iVar6), 
                                          *(int64_t *)((int64_t)&var_18h + iVar6), 
                                          *(int64_t *)(&stack0x00000030 + iVar6));
                            goto code_r0x000180195791;
                        }
                        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x1801956da;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                      *(int64_t *)(&stack0x00000030 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x1801956f0;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar6));
                        goto code_r0x00018019579e;
                    }
                    iVar3 = *placeholder_1;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x180195603;
                    fcn.180498030((int64_t)&arg_60h + iVar6, iVar3, uVar10);
                    *placeholder_1 = iVar3 + uVar10;
                    placeholder_1[1] = uVar2 - uVar10;
                } while ((iVar1 != 0) && (*(char *)((int64_t)&arg_60h + iVar6) != '\0'));
                piVar4 = &arg_60h;
                if (iVar1 != 0) {
                    piVar4 = (int64_t *)((int64_t)&arg_60h + 1);
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x180195645;
                piVar9 = (int32_t *)fcn.1801a0300(placeholder_0, (int64_t)piVar4 + iVar6, 1);
            } while (piVar9 == (int32_t *)0x0);
            if (*piVar9 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18019565d;
                iVar5 = fcn.180222110(*(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                      *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                      *(int64_t *)(&stack0x00000038 + iVar6));
                if (iVar5 == 0) break;
                if (*piVar9 != 0) goto code_r0x0001801955e0;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x180195675;
            iVar5 = fcn.180222110(*(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                  *(int64_t *)(&stack0x00000038 + iVar6));
        } while (iVar5 != 0);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x180195682;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        iVar1 = *(int32_t *)((int64_t)&arg_68h + iVar6);
    }
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18019578c;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)(&stack0x00000030 + iVar6));
code_r0x000180195791:
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18019579e;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18019576a;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)(&stack0x00000030 + iVar6));
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x180195780;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar6));
    }
code_r0x00018019579e:
    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x1801957a6;
    fcn.180221d50(iVar7);
    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x1801957ae;
    fcn.180221d50(iVar8);
    return 0;
}

// ============================================================
// Function: FUN_1801957d0
// Address: 0x1801957d0
// Size: 1132 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1801957d0(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h,
                      int64_t arg_90h, int64_t arg_98h, int64_t arg_d8h)
{
    uint32_t *puVar1;
    uint32_t uVar2;
    undefined4 uVar3;
    code *pcVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int32_t *piVar11;
    uint64_t uVar12;
    undefined4 *puVar13;
    int32_t *in_RCX;
    uint64_t in_RDX;
    uint64_t uVar14;
    uint32_t uVar15;
    uint64_t in_R8;
    int64_t *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_21h;
    
    stack0xffffffffffffffe0 = 0x1801957ee;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    uVar12 = 0;
    uVar15 = (uint32_t)in_R8;
    uVar14 = (uint64_t)(int32_t)uVar15;
    if (in_RCX == (int32_t *)0x0) {
code_r0x00018019581c:
        piVar11 = (int32_t *)0x0;
    } else {
        piVar11 = in_RCX;
        if (*in_RCX != 0) {
            if (-1 < (char)*in_RCX) goto code_r0x00018019581c;
            *(undefined8 *)((int64_t)&var_21h + iVar10 + 1) = 0x180195817;
            piVar11 = (int32_t *)func_0x0001801bda50();
        }
    }
    if (((*(int32_t *)((int64_t)&arg_d8h + iVar10) == 0) && (in_RCX != (int32_t *)0x0)) &&
       ((*(uint8_t *)in_RCX & 0x80) != 0)) {
code_r0x000180195833:
        pcVar4 = *(code **)(*(int64_t *)(in_RCX + 6) + 0x98);
        *(undefined8 *)((int64_t)&var_21h + iVar10 + 1) = 0x18019584c;
        uVar12 = (*pcVar4)(in_RCX, in_RDX & 0xffffffff, in_R8 & 0xffffffff, in_R9);
        return uVar12;
    }
    if (piVar11 == (int32_t *)0x0) goto code_r0x000180195b62;
    // switch table (104 cases) at 0x180195b84
    switch((int32_t)in_RDX) {
    case 0x21:
        piVar11[0x26c] = piVar11[0x26c] | uVar15;
        *(undefined8 *)((int64_t)&var_21h + iVar10 + 1) = 0x1801958bd;
        puVar13 = (undefined4 *)func_0x000180229d80((int64_t)&var_18h + iVar10, 0x1804a95d0, piVar11 + 0x26c);
        uVar3 = puVar13[1];
        uVar7 = puVar13[2];
        uVar8 = puVar13[3];
        *(undefined4 *)((int64_t)&arg_48h + iVar10) = *puVar13;
        *(undefined4 *)((int64_t)&arg_48h + iVar10 + 4) = uVar3;
        *(undefined4 *)(&stack0x00000050 + iVar10) = uVar7;
        *(undefined4 *)(&stack0x00000054 + iVar10) = uVar8;
        uVar3 = puVar13[5];
        uVar7 = puVar13[6];
        uVar8 = puVar13[7];
        *(undefined4 *)((int64_t)&arg_58h + iVar10) = puVar13[4];
        *(undefined4 *)((int64_t)&arg_58h + iVar10 + 4) = uVar3;
        *(undefined4 *)(&stack0x00000060 + iVar10) = uVar7;
        *(undefined4 *)(&stack0x00000064 + iVar10) = uVar8;
        *(undefined8 *)((int64_t)&arg_68h + iVar10) = *(undefined8 *)(puVar13 + 8);
        *(undefined8 *)((int64_t)&var_21h + iVar10 + 1) = 0x1801958e6;
        puVar13 = (undefined4 *)fcn.180229ba0((int64_t)&var_18h + iVar10);
        uVar6 = *(undefined8 *)(piVar11 + 0x31e);
        uVar3 = puVar13[1];
        uVar7 = puVar13[2];
        uVar8 = puVar13[3];
        *(undefined4 *)((int64_t)&arg_70h + iVar10) = *puVar13;
        *(undefined4 *)((int64_t)&arg_70h + iVar10 + 4) = uVar3;
        *(undefined4 *)(&stack0x00000078 + iVar10) = uVar7;
        *(undefined4 *)(&stack0x0000007c + iVar10) = uVar8;
        uVar3 = puVar13[5];
        uVar7 = puVar13[6];
        uVar8 = puVar13[7];
        *(undefined4 *)((int64_t)&arg_80h + iVar10) = puVar13[4];
        *(undefined4 *)((int64_t)&arg_80h + iVar10 + 4) = uVar3;
        *(undefined4 *)(&stack0x00000088 + iVar10) = uVar7;
        *(undefined4 *)(&stack0x0000008c + iVar10) = uVar8;
        iVar5 = *(int64_t *)(piVar11 + 0x31a);
        *(undefined8 *)((int64_t)&arg_90h + iVar10) = *(undefined8 *)(puVar13 + 8);
        pcVar4 = *(code **)(iVar5 + 0x90);
        *(undefined8 *)((int64_t)&var_21h + iVar10 + 1) = 0x180195928;
        (*pcVar4)(uVar6, (int64_t)&arg_48h + iVar10);
        uVar12 = (uint64_t)(uint32_t)piVar11[0x26c];
        break;
    default:
        if ((in_RCX != (int32_t *)0x0) && ((*(uint8_t *)in_RCX & 0x80) != 0)) {
            *(undefined4 *)((int64_t)&var_8h + iVar10) = 0;
            *(undefined8 *)((int64_t)&var_21h + iVar10 + 1) = 0x180195b60;
            uVar12 = fcn.1801957d0(*(int64_t *)(&stack0x00000028 + iVar10), *(int64_t *)(&stack0x00000038 + iVar10), 
                                   *(int64_t *)((int64_t)&arg_48h + iVar10), *(int64_t *)(&stack0x00000050 + iVar10), 
                                   *(int64_t *)(&stack0x00000060 + iVar10), *(int64_t *)((int64_t)&arg_70h + iVar10), 
                                   *(int64_t *)(&stack0x00000078 + iVar10), *(int64_t *)(&stack0x000000b8 + iVar10));
            return uVar12;
        }
        goto code_r0x000180195833;
    case 0x28:
        uVar12 = (uint64_t)(uint32_t)piVar11[0x326];
        break;
    case 0x29:
        uVar2 = piVar11[0x326];
        piVar11[0x326] = uVar15;
        uVar12 = (uint64_t)uVar2;
        break;
    case 0x32:
        uVar12 = (uint64_t)(uint32_t)piVar11[0x270];
        break;
    case 0x33:
        if (-1 < (int32_t)uVar15) {
            uVar15 = piVar11[0x270];
            *(uint64_t *)(piVar11 + 0x270) = uVar14;
            return (uint64_t)uVar15;
        }
        goto code_r0x000180195b62;
    case 0x34:
        if (uVar15 - 0x200 < 0x3e01) {
            *(uint64_t *)(piVar11 + 0x276) = uVar14;
            if (uVar14 < *(uint64_t *)(piVar11 + 0x274)) {
                *(uint64_t *)(piVar11 + 0x274) = uVar14;
            }
            uVar6 = *(undefined8 *)(piVar11 + 800);
            pcVar4 = *(code **)(*(int64_t *)(piVar11 + 0x31c) + 0xa0);
            *(undefined8 *)((int64_t)&var_21h + iVar10 + 1) = 0x1801959ae;
            (*pcVar4)(uVar6);
            return 1;
        }
        goto code_r0x000180195b62;
    case 0x4c:
        uVar12 = (uint64_t)(uint32_t)piVar11[300];
        break;
    case 0x4e:
        piVar11[0x26c] = piVar11[0x26c] & ~uVar15;
        uVar12 = (uint64_t)(uint32_t)piVar11[0x26c];
        break;
    case 99:
        iVar10 = *(int64_t *)(piVar11 + 0x21e);
        puVar1 = (uint32_t *)(iVar10 + 0x1c);
        *puVar1 = *puVar1 | uVar15;
        uVar12 = (uint64_t)*(uint32_t *)(iVar10 + 0x1c);
        break;
    case 100:
        iVar10 = *(int64_t *)(piVar11 + 0x21e);
        puVar1 = (uint32_t *)(iVar10 + 0x1c);
        *puVar1 = *puVar1 & ~uVar15;
        uVar12 = (uint64_t)*(uint32_t *)(iVar10 + 0x1c);
        break;
    case 0x6e:
        if (in_R9 == (int64_t *)0x0) {
            return 2;
        }
        if (*(int64_t *)(piVar11 + 0xe8) != 0) {
            *in_R9 = *(int64_t *)(piVar11 + 0xe8);
            return (uint64_t)(uint32_t)piVar11[0xea];
        }
        goto code_r0x000180195b62;
    case 0x7a:
        if (*(int64_t *)(piVar11 + 0x23e) != 0) {
            *(undefined8 *)((int64_t)&var_21h + iVar10 + 1) = 0x180195a98;
            iVar9 = func_0x00018019b2a0(in_RCX);
            if (iVar9 == 0) {
                *(undefined8 *)((int64_t)&var_21h + iVar10 + 1) = 0x180195aa4;
                iVar9 = func_0x00018019b680(piVar11);
                if (iVar9 == 0) {
                    return (uint64_t)(*(uint32_t *)(*(int64_t *)(piVar11 + 0x23e) + 0x370) & 1);
                }
            }
        }
        uVar12 = 0xffffffff;
        break;
    case 0x7b:
        iVar9 = piVar11[0x26e];
        *(undefined8 *)((int64_t)&var_21h + iVar10 + 1) = 0x180195ad4;
        iVar9 = func_0x000180197230(in_R8 & 0xffffffff, iVar9);
        if (iVar9 != 0) {
            uVar3 = **(undefined4 **)(in_RCX + 4);
            *(undefined8 *)((int64_t)&var_21h + iVar10 + 1) = 0x180195aec;
            iVar9 = func_0x0001801afd20(uVar3, in_R8 & 0xffffffff, piVar11 + 0x26d);
            uVar12 = 0;
            if (iVar9 != 0) {
                uVar12 = 1;
            }
        }
        break;
    case 0x7c:
        iVar9 = piVar11[0x26d];
        *(undefined8 *)((int64_t)&var_21h + iVar10 + 1) = 0x180195b0e;
        iVar9 = func_0x000180197230(iVar9, in_R8 & 0xffffffff);
        if (iVar9 != 0) {
            uVar3 = **(undefined4 **)(in_RCX + 4);
            *(undefined8 *)((int64_t)&var_21h + iVar10 + 1) = 0x180195b24;
            iVar9 = func_0x0001801afd20(uVar3);
            if (iVar9 != 0) {
                uVar12 = 1;
            }
        }
        break;
    case 0x7d:
        if ((uVar14 <= *(uint64_t *)(piVar11 + 0x276)) && (uVar15 != 0)) {
            *(uint64_t *)(piVar11 + 0x274) = uVar14;
            return 1;
        }
        goto code_r0x000180195b62;
    case 0x7e:
        if (uVar15 - 1 < 0x20) {
            *(uint64_t *)(piVar11 + 0x278) = uVar14;
            pcVar4 = *(code **)(*(int64_t *)(piVar11 + 0x31a) + 0x78);
            if (pcVar4 != (code *)0x0) {
                uVar6 = *(undefined8 *)(piVar11 + 0x31e);
                *(undefined8 *)((int64_t)&var_21h + iVar10 + 1) = 0x180195a0e;
                (*pcVar4)(uVar6);
            }
            return 1;
        }
code_r0x000180195b62:
        uVar12 = 0;
        break;
    case 0x82:
        uVar12 = (uint64_t)(uint32_t)piVar11[0x26d];
        break;
    case 0x83:
        uVar12 = (uint64_t)(uint32_t)piVar11[0x26e];
        break;
    case 0x88:
        piVar11[0x1a] = 8;
        uVar12 = 1;
    }
    return uVar12;
}

// ============================================================
// Function: FUN_180195c40
// Address: 0x180195c40
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180195c40(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    undefined8 uVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 unaff_RBX;
    int32_t *piVar5;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 != 0) {
        uStack_10 = 0x180195c54;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBP;
        piVar5 = (int32_t *)0x0;
        if (*(int32_t *)arg1 == 0) {
            piVar5 = (int32_t *)arg1;
        }
        if (piVar5 != (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
            if (*(int64_t *)(piVar5 + 0x18) != 0) {
                uVar1 = *(undefined8 *)(piVar5 + 0x16);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195c8b;
                uVar4 = func_0x00018021a8e0(uVar1);
                *(undefined8 *)(piVar5 + 0x16) = uVar4;
                pcVar2 = *(code **)(*(int64_t *)(piVar5 + 0x31c) + 0x58);
                uVar1 = *(undefined8 *)(piVar5 + 800);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195ca7;
                (*pcVar2)(uVar1, uVar4);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195cb0;
                fcn.180219f80(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)(piVar5 + 0x18) = 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195cc0;
            func_0x0001801a2e20(piVar5 + 0x314);
            uVar1 = *(undefined8 *)(piVar5 + 0x144);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195ccc;
            func_0x000180233bc0(uVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195cd8;
            fcn.180195220(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
            uVar1 = *(undefined8 *)(piVar5 + 0x3e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195ce4;
            func_0x000180226310(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x156);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195cf0;
            fcn.180221d50(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x158);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195cfc;
            fcn.180221d50(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x15a);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d08;
            fcn.180221d50(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x154);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d14;
            fcn.180221d50(uVar1);
            if (*(int64_t *)(piVar5 + 0x23e) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d25;
                func_0x00018019d1c0(piVar5);
                uVar1 = *(undefined8 *)(piVar5 + 0x23e);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d31;
                func_0x00018019c980(uVar1);
            }
            uVar1 = *(undefined8 *)(piVar5 + 0x240);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d3d;
            func_0x00018019c980(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x242);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d56;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5ce);
            uVar1 = *(undefined8 *)(piVar5 + 0x21e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d62;
            func_0x0001801a1e40(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x560);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d7b;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d1);
            uVar1 = *(undefined8 *)(piVar5 + 0x286);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d94;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d4);
            uVar1 = *(undefined8 *)(piVar5 + 0x2e2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195da0;
            func_0x000180191f00(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x29c);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195db9;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d6);
            uVar1 = *(undefined8 *)(piVar5 + 0x2a0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195dd2;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d7);
            uVar1 = *(undefined8 *)(piVar5 + 0x2a4);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195deb;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d8);
            uVar1 = *(undefined8 *)(piVar5 + 0x2ac);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e04;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d9);
            uVar1 = *(undefined8 *)(piVar5 + 0x2b0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e1d;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5da);
            uVar1 = *(undefined8 *)(piVar5 + 0x2a8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e36;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5db);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e49;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            uVar1 = *(undefined8 *)(piVar5 + 0x292);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e62;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5df);
            *(undefined8 *)(piVar5 + 0x292) = 0;
            *(undefined8 *)(piVar5 + 0x294) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e83;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            uVar1 = *(undefined8 *)(piVar5 + 0x296);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e96;
            fcn.180222290(uVar1, 0x180196ec0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195ea5;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            uVar1 = *(undefined8 *)(piVar5 + 0x2de);
            *(undefined8 *)(piVar5 + 0x296) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195eb8;
            func_0x00018023a130(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x28a);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195ed1;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5e9);
            uVar1 = *(undefined8 *)(piVar5 + 700);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195eea;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5eb);
            uVar1 = *(undefined8 *)(piVar5 + 0x2c8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f03;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5ec);
            if (*(int64_t *)(piVar5 + 0x2d6) != 0) {
                uVar1 = *(undefined8 *)(*(int64_t *)(piVar5 + 0x2d6) + 0x288);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f28;
                fcn.180224990(uVar1, 0x1804a94a0, 0x5ee);
            }
            uVar1 = *(undefined8 *)(piVar5 + 0x2d6);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f41;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5ef);
            uVar1 = *(undefined8 *)(piVar5 + 0x2ec);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f5a;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5f0);
            uVar1 = *(undefined8 *)(piVar5 + 0x2f2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f66;
            func_0x000180215310(uVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f79;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f8c;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            uVar1 = *(undefined8 *)(piVar5 + 0x564);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195fa5;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5f6);
            uVar1 = *(undefined8 *)(piVar5 + 0x568);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195fbe;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5f7);
            uVar1 = *(undefined8 *)(piVar5 + 0x262);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195fca;
            fcn.180238640(uVar1);
            if (*(int64_t *)(arg1 + 0x18) != 0) {
                pcVar2 = *(code **)(*(int64_t *)(arg1 + 0x18) + 0x38);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195fdc;
                (*pcVar2)(arg1);
            }
            uVar1 = *(undefined8 *)(piVar5 + 0x54a);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195fe8;
            func_0x0001802394e0(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x2c0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196001;
            fcn.180224990(uVar1, 0x1804a94a0, 0x601);
            uVar1 = *(undefined8 *)(piVar5 + 0x2e4);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019600d;
            fcn.180221d50(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x16);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196016;
            func_0x00018021a070(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x14);
            *(undefined8 *)(piVar5 + 0x16) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196023;
            func_0x00018021a070(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x102);
            *(undefined8 *)(piVar5 + 0x14) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196040;
            fcn.180224990(uVar1, 0x1804a94a0, 0x612);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180195c57
// Address: 0x180195c57
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180195c40(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    undefined8 uVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 unaff_RBX;
    int32_t *piVar5;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 != 0) {
        uStack_10 = 0x180195c54;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBP;
        piVar5 = (int32_t *)0x0;
        if (*(int32_t *)arg1 == 0) {
            piVar5 = (int32_t *)arg1;
        }
        if (piVar5 != (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
            if (*(int64_t *)(piVar5 + 0x18) != 0) {
                uVar1 = *(undefined8 *)(piVar5 + 0x16);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195c8b;
                uVar4 = func_0x00018021a8e0(uVar1);
                *(undefined8 *)(piVar5 + 0x16) = uVar4;
                pcVar2 = *(code **)(*(int64_t *)(piVar5 + 0x31c) + 0x58);
                uVar1 = *(undefined8 *)(piVar5 + 800);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195ca7;
                (*pcVar2)(uVar1, uVar4);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195cb0;
                fcn.180219f80(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)(piVar5 + 0x18) = 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195cc0;
            func_0x0001801a2e20(piVar5 + 0x314);
            uVar1 = *(undefined8 *)(piVar5 + 0x144);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195ccc;
            func_0x000180233bc0(uVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195cd8;
            fcn.180195220(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
            uVar1 = *(undefined8 *)(piVar5 + 0x3e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195ce4;
            func_0x000180226310(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x156);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195cf0;
            fcn.180221d50(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x158);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195cfc;
            fcn.180221d50(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x15a);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d08;
            fcn.180221d50(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x154);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d14;
            fcn.180221d50(uVar1);
            if (*(int64_t *)(piVar5 + 0x23e) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d25;
                func_0x00018019d1c0(piVar5);
                uVar1 = *(undefined8 *)(piVar5 + 0x23e);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d31;
                func_0x00018019c980(uVar1);
            }
            uVar1 = *(undefined8 *)(piVar5 + 0x240);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d3d;
            func_0x00018019c980(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x242);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d56;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5ce);
            uVar1 = *(undefined8 *)(piVar5 + 0x21e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d62;
            func_0x0001801a1e40(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x560);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d7b;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d1);
            uVar1 = *(undefined8 *)(piVar5 + 0x286);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d94;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d4);
            uVar1 = *(undefined8 *)(piVar5 + 0x2e2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195da0;
            func_0x000180191f00(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x29c);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195db9;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d6);
            uVar1 = *(undefined8 *)(piVar5 + 0x2a0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195dd2;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d7);
            uVar1 = *(undefined8 *)(piVar5 + 0x2a4);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195deb;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d8);
            uVar1 = *(undefined8 *)(piVar5 + 0x2ac);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e04;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d9);
            uVar1 = *(undefined8 *)(piVar5 + 0x2b0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e1d;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5da);
            uVar1 = *(undefined8 *)(piVar5 + 0x2a8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e36;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5db);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e49;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            uVar1 = *(undefined8 *)(piVar5 + 0x292);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e62;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5df);
            *(undefined8 *)(piVar5 + 0x292) = 0;
            *(undefined8 *)(piVar5 + 0x294) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e83;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            uVar1 = *(undefined8 *)(piVar5 + 0x296);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e96;
            fcn.180222290(uVar1, 0x180196ec0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195ea5;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            uVar1 = *(undefined8 *)(piVar5 + 0x2de);
            *(undefined8 *)(piVar5 + 0x296) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195eb8;
            func_0x00018023a130(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x28a);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195ed1;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5e9);
            uVar1 = *(undefined8 *)(piVar5 + 700);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195eea;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5eb);
            uVar1 = *(undefined8 *)(piVar5 + 0x2c8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f03;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5ec);
            if (*(int64_t *)(piVar5 + 0x2d6) != 0) {
                uVar1 = *(undefined8 *)(*(int64_t *)(piVar5 + 0x2d6) + 0x288);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f28;
                fcn.180224990(uVar1, 0x1804a94a0, 0x5ee);
            }
            uVar1 = *(undefined8 *)(piVar5 + 0x2d6);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f41;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5ef);
            uVar1 = *(undefined8 *)(piVar5 + 0x2ec);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f5a;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5f0);
            uVar1 = *(undefined8 *)(piVar5 + 0x2f2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f66;
            func_0x000180215310(uVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f79;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f8c;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            uVar1 = *(undefined8 *)(piVar5 + 0x564);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195fa5;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5f6);
            uVar1 = *(undefined8 *)(piVar5 + 0x568);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195fbe;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5f7);
            uVar1 = *(undefined8 *)(piVar5 + 0x262);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195fca;
            fcn.180238640(uVar1);
            if (*(int64_t *)(arg1 + 0x18) != 0) {
                pcVar2 = *(code **)(*(int64_t *)(arg1 + 0x18) + 0x38);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195fdc;
                (*pcVar2)(arg1);
            }
            uVar1 = *(undefined8 *)(piVar5 + 0x54a);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195fe8;
            func_0x0001802394e0(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x2c0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196001;
            fcn.180224990(uVar1, 0x1804a94a0, 0x601);
            uVar1 = *(undefined8 *)(piVar5 + 0x2e4);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019600d;
            fcn.180221d50(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x16);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196016;
            func_0x00018021a070(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x14);
            *(undefined8 *)(piVar5 + 0x16) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196023;
            func_0x00018021a070(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x102);
            *(undefined8 *)(piVar5 + 0x14) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196040;
            fcn.180224990(uVar1, 0x1804a94a0, 0x612);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180195c77
// Address: 0x180195c77
// Size: 974 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180195c40(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    undefined8 uVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 unaff_RBX;
    int32_t *piVar5;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 != 0) {
        uStack_10 = 0x180195c54;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBP;
        piVar5 = (int32_t *)0x0;
        if (*(int32_t *)arg1 == 0) {
            piVar5 = (int32_t *)arg1;
        }
        if (piVar5 != (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
            if (*(int64_t *)(piVar5 + 0x18) != 0) {
                uVar1 = *(undefined8 *)(piVar5 + 0x16);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195c8b;
                uVar4 = func_0x00018021a8e0(uVar1);
                *(undefined8 *)(piVar5 + 0x16) = uVar4;
                pcVar2 = *(code **)(*(int64_t *)(piVar5 + 0x31c) + 0x58);
                uVar1 = *(undefined8 *)(piVar5 + 800);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195ca7;
                (*pcVar2)(uVar1, uVar4);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195cb0;
                fcn.180219f80(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)(piVar5 + 0x18) = 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195cc0;
            func_0x0001801a2e20(piVar5 + 0x314);
            uVar1 = *(undefined8 *)(piVar5 + 0x144);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195ccc;
            func_0x000180233bc0(uVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195cd8;
            fcn.180195220(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
            uVar1 = *(undefined8 *)(piVar5 + 0x3e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195ce4;
            func_0x000180226310(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x156);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195cf0;
            fcn.180221d50(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x158);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195cfc;
            fcn.180221d50(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x15a);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d08;
            fcn.180221d50(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x154);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d14;
            fcn.180221d50(uVar1);
            if (*(int64_t *)(piVar5 + 0x23e) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d25;
                func_0x00018019d1c0(piVar5);
                uVar1 = *(undefined8 *)(piVar5 + 0x23e);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d31;
                func_0x00018019c980(uVar1);
            }
            uVar1 = *(undefined8 *)(piVar5 + 0x240);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d3d;
            func_0x00018019c980(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x242);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d56;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5ce);
            uVar1 = *(undefined8 *)(piVar5 + 0x21e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d62;
            func_0x0001801a1e40(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x560);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d7b;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d1);
            uVar1 = *(undefined8 *)(piVar5 + 0x286);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d94;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d4);
            uVar1 = *(undefined8 *)(piVar5 + 0x2e2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195da0;
            func_0x000180191f00(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x29c);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195db9;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d6);
            uVar1 = *(undefined8 *)(piVar5 + 0x2a0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195dd2;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d7);
            uVar1 = *(undefined8 *)(piVar5 + 0x2a4);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195deb;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d8);
            uVar1 = *(undefined8 *)(piVar5 + 0x2ac);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e04;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d9);
            uVar1 = *(undefined8 *)(piVar5 + 0x2b0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e1d;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5da);
            uVar1 = *(undefined8 *)(piVar5 + 0x2a8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e36;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5db);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e49;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            uVar1 = *(undefined8 *)(piVar5 + 0x292);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e62;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5df);
            *(undefined8 *)(piVar5 + 0x292) = 0;
            *(undefined8 *)(piVar5 + 0x294) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e83;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            uVar1 = *(undefined8 *)(piVar5 + 0x296);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e96;
            fcn.180222290(uVar1, 0x180196ec0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195ea5;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            uVar1 = *(undefined8 *)(piVar5 + 0x2de);
            *(undefined8 *)(piVar5 + 0x296) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195eb8;
            func_0x00018023a130(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x28a);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195ed1;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5e9);
            uVar1 = *(undefined8 *)(piVar5 + 700);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195eea;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5eb);
            uVar1 = *(undefined8 *)(piVar5 + 0x2c8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f03;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5ec);
            if (*(int64_t *)(piVar5 + 0x2d6) != 0) {
                uVar1 = *(undefined8 *)(*(int64_t *)(piVar5 + 0x2d6) + 0x288);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f28;
                fcn.180224990(uVar1, 0x1804a94a0, 0x5ee);
            }
            uVar1 = *(undefined8 *)(piVar5 + 0x2d6);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f41;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5ef);
            uVar1 = *(undefined8 *)(piVar5 + 0x2ec);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f5a;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5f0);
            uVar1 = *(undefined8 *)(piVar5 + 0x2f2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f66;
            func_0x000180215310(uVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f79;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f8c;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            uVar1 = *(undefined8 *)(piVar5 + 0x564);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195fa5;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5f6);
            uVar1 = *(undefined8 *)(piVar5 + 0x568);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195fbe;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5f7);
            uVar1 = *(undefined8 *)(piVar5 + 0x262);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195fca;
            fcn.180238640(uVar1);
            if (*(int64_t *)(arg1 + 0x18) != 0) {
                pcVar2 = *(code **)(*(int64_t *)(arg1 + 0x18) + 0x38);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195fdc;
                (*pcVar2)(arg1);
            }
            uVar1 = *(undefined8 *)(piVar5 + 0x54a);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195fe8;
            func_0x0001802394e0(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x2c0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196001;
            fcn.180224990(uVar1, 0x1804a94a0, 0x601);
            uVar1 = *(undefined8 *)(piVar5 + 0x2e4);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019600d;
            fcn.180221d50(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x16);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196016;
            func_0x00018021a070(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x14);
            *(undefined8 *)(piVar5 + 0x16) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196023;
            func_0x00018021a070(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x102);
            *(undefined8 *)(piVar5 + 0x14) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196040;
            fcn.180224990(uVar1, 0x1804a94a0, 0x612);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180196045
// Address: 0x180196045
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180195c40(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    undefined8 uVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 unaff_RBX;
    int32_t *piVar5;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 != 0) {
        uStack_10 = 0x180195c54;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBP;
        piVar5 = (int32_t *)0x0;
        if (*(int32_t *)arg1 == 0) {
            piVar5 = (int32_t *)arg1;
        }
        if (piVar5 != (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
            if (*(int64_t *)(piVar5 + 0x18) != 0) {
                uVar1 = *(undefined8 *)(piVar5 + 0x16);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195c8b;
                uVar4 = func_0x00018021a8e0(uVar1);
                *(undefined8 *)(piVar5 + 0x16) = uVar4;
                pcVar2 = *(code **)(*(int64_t *)(piVar5 + 0x31c) + 0x58);
                uVar1 = *(undefined8 *)(piVar5 + 800);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195ca7;
                (*pcVar2)(uVar1, uVar4);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195cb0;
                fcn.180219f80(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)(piVar5 + 0x18) = 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195cc0;
            func_0x0001801a2e20(piVar5 + 0x314);
            uVar1 = *(undefined8 *)(piVar5 + 0x144);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195ccc;
            func_0x000180233bc0(uVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195cd8;
            fcn.180195220(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
            uVar1 = *(undefined8 *)(piVar5 + 0x3e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195ce4;
            func_0x000180226310(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x156);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195cf0;
            fcn.180221d50(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x158);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195cfc;
            fcn.180221d50(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x15a);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d08;
            fcn.180221d50(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x154);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d14;
            fcn.180221d50(uVar1);
            if (*(int64_t *)(piVar5 + 0x23e) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d25;
                func_0x00018019d1c0(piVar5);
                uVar1 = *(undefined8 *)(piVar5 + 0x23e);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d31;
                func_0x00018019c980(uVar1);
            }
            uVar1 = *(undefined8 *)(piVar5 + 0x240);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d3d;
            func_0x00018019c980(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x242);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d56;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5ce);
            uVar1 = *(undefined8 *)(piVar5 + 0x21e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d62;
            func_0x0001801a1e40(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x560);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d7b;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d1);
            uVar1 = *(undefined8 *)(piVar5 + 0x286);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d94;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d4);
            uVar1 = *(undefined8 *)(piVar5 + 0x2e2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195da0;
            func_0x000180191f00(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x29c);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195db9;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d6);
            uVar1 = *(undefined8 *)(piVar5 + 0x2a0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195dd2;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d7);
            uVar1 = *(undefined8 *)(piVar5 + 0x2a4);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195deb;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d8);
            uVar1 = *(undefined8 *)(piVar5 + 0x2ac);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e04;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d9);
            uVar1 = *(undefined8 *)(piVar5 + 0x2b0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e1d;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5da);
            uVar1 = *(undefined8 *)(piVar5 + 0x2a8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e36;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5db);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e49;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            uVar1 = *(undefined8 *)(piVar5 + 0x292);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e62;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5df);
            *(undefined8 *)(piVar5 + 0x292) = 0;
            *(undefined8 *)(piVar5 + 0x294) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e83;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            uVar1 = *(undefined8 *)(piVar5 + 0x296);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e96;
            fcn.180222290(uVar1, 0x180196ec0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195ea5;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            uVar1 = *(undefined8 *)(piVar5 + 0x2de);
            *(undefined8 *)(piVar5 + 0x296) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195eb8;
            func_0x00018023a130(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x28a);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195ed1;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5e9);
            uVar1 = *(undefined8 *)(piVar5 + 700);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195eea;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5eb);
            uVar1 = *(undefined8 *)(piVar5 + 0x2c8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f03;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5ec);
            if (*(int64_t *)(piVar5 + 0x2d6) != 0) {
                uVar1 = *(undefined8 *)(*(int64_t *)(piVar5 + 0x2d6) + 0x288);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f28;
                fcn.180224990(uVar1, 0x1804a94a0, 0x5ee);
            }
            uVar1 = *(undefined8 *)(piVar5 + 0x2d6);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f41;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5ef);
            uVar1 = *(undefined8 *)(piVar5 + 0x2ec);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f5a;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5f0);
            uVar1 = *(undefined8 *)(piVar5 + 0x2f2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f66;
            func_0x000180215310(uVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f79;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f8c;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            uVar1 = *(undefined8 *)(piVar5 + 0x564);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195fa5;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5f6);
            uVar1 = *(undefined8 *)(piVar5 + 0x568);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195fbe;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5f7);
            uVar1 = *(undefined8 *)(piVar5 + 0x262);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195fca;
            fcn.180238640(uVar1);
            if (*(int64_t *)(arg1 + 0x18) != 0) {
                pcVar2 = *(code **)(*(int64_t *)(arg1 + 0x18) + 0x38);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195fdc;
                (*pcVar2)(arg1);
            }
            uVar1 = *(undefined8 *)(piVar5 + 0x54a);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195fe8;
            func_0x0001802394e0(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x2c0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196001;
            fcn.180224990(uVar1, 0x1804a94a0, 0x601);
            uVar1 = *(undefined8 *)(piVar5 + 0x2e4);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019600d;
            fcn.180221d50(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x16);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196016;
            func_0x00018021a070(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x14);
            *(undefined8 *)(piVar5 + 0x16) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196023;
            func_0x00018021a070(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x102);
            *(undefined8 *)(piVar5 + 0x14) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196040;
            fcn.180224990(uVar1, 0x1804a94a0, 0x612);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180196054
// Address: 0x180196054
// Size: 1 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180195c40(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    undefined8 uVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 unaff_RBX;
    int32_t *piVar5;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 != 0) {
        uStack_10 = 0x180195c54;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBP;
        piVar5 = (int32_t *)0x0;
        if (*(int32_t *)arg1 == 0) {
            piVar5 = (int32_t *)arg1;
        }
        if (piVar5 != (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
            if (*(int64_t *)(piVar5 + 0x18) != 0) {
                uVar1 = *(undefined8 *)(piVar5 + 0x16);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195c8b;
                uVar4 = func_0x00018021a8e0(uVar1);
                *(undefined8 *)(piVar5 + 0x16) = uVar4;
                pcVar2 = *(code **)(*(int64_t *)(piVar5 + 0x31c) + 0x58);
                uVar1 = *(undefined8 *)(piVar5 + 800);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195ca7;
                (*pcVar2)(uVar1, uVar4);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195cb0;
                fcn.180219f80(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)(piVar5 + 0x18) = 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195cc0;
            func_0x0001801a2e20(piVar5 + 0x314);
            uVar1 = *(undefined8 *)(piVar5 + 0x144);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195ccc;
            func_0x000180233bc0(uVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195cd8;
            fcn.180195220(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
            uVar1 = *(undefined8 *)(piVar5 + 0x3e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195ce4;
            func_0x000180226310(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x156);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195cf0;
            fcn.180221d50(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x158);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195cfc;
            fcn.180221d50(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x15a);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d08;
            fcn.180221d50(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x154);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d14;
            fcn.180221d50(uVar1);
            if (*(int64_t *)(piVar5 + 0x23e) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d25;
                func_0x00018019d1c0(piVar5);
                uVar1 = *(undefined8 *)(piVar5 + 0x23e);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d31;
                func_0x00018019c980(uVar1);
            }
            uVar1 = *(undefined8 *)(piVar5 + 0x240);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d3d;
            func_0x00018019c980(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x242);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d56;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5ce);
            uVar1 = *(undefined8 *)(piVar5 + 0x21e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d62;
            func_0x0001801a1e40(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x560);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d7b;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d1);
            uVar1 = *(undefined8 *)(piVar5 + 0x286);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195d94;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d4);
            uVar1 = *(undefined8 *)(piVar5 + 0x2e2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195da0;
            func_0x000180191f00(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x29c);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195db9;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d6);
            uVar1 = *(undefined8 *)(piVar5 + 0x2a0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195dd2;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d7);
            uVar1 = *(undefined8 *)(piVar5 + 0x2a4);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195deb;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d8);
            uVar1 = *(undefined8 *)(piVar5 + 0x2ac);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e04;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5d9);
            uVar1 = *(undefined8 *)(piVar5 + 0x2b0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e1d;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5da);
            uVar1 = *(undefined8 *)(piVar5 + 0x2a8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e36;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5db);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e49;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            uVar1 = *(undefined8 *)(piVar5 + 0x292);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e62;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5df);
            *(undefined8 *)(piVar5 + 0x292) = 0;
            *(undefined8 *)(piVar5 + 0x294) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e83;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            uVar1 = *(undefined8 *)(piVar5 + 0x296);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195e96;
            fcn.180222290(uVar1, 0x180196ec0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195ea5;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            uVar1 = *(undefined8 *)(piVar5 + 0x2de);
            *(undefined8 *)(piVar5 + 0x296) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195eb8;
            func_0x00018023a130(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x28a);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195ed1;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5e9);
            uVar1 = *(undefined8 *)(piVar5 + 700);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195eea;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5eb);
            uVar1 = *(undefined8 *)(piVar5 + 0x2c8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f03;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5ec);
            if (*(int64_t *)(piVar5 + 0x2d6) != 0) {
                uVar1 = *(undefined8 *)(*(int64_t *)(piVar5 + 0x2d6) + 0x288);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f28;
                fcn.180224990(uVar1, 0x1804a94a0, 0x5ee);
            }
            uVar1 = *(undefined8 *)(piVar5 + 0x2d6);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f41;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5ef);
            uVar1 = *(undefined8 *)(piVar5 + 0x2ec);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f5a;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5f0);
            uVar1 = *(undefined8 *)(piVar5 + 0x2f2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f66;
            func_0x000180215310(uVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f79;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195f8c;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            uVar1 = *(undefined8 *)(piVar5 + 0x564);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195fa5;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5f6);
            uVar1 = *(undefined8 *)(piVar5 + 0x568);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195fbe;
            fcn.180224990(uVar1, 0x1804a94a0, 0x5f7);
            uVar1 = *(undefined8 *)(piVar5 + 0x262);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195fca;
            fcn.180238640(uVar1);
            if (*(int64_t *)(arg1 + 0x18) != 0) {
                pcVar2 = *(code **)(*(int64_t *)(arg1 + 0x18) + 0x38);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195fdc;
                (*pcVar2)(arg1);
            }
            uVar1 = *(undefined8 *)(piVar5 + 0x54a);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180195fe8;
            func_0x0001802394e0(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x2c0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196001;
            fcn.180224990(uVar1, 0x1804a94a0, 0x601);
            uVar1 = *(undefined8 *)(piVar5 + 0x2e4);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019600d;
            fcn.180221d50(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x16);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196016;
            func_0x00018021a070(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x14);
            *(undefined8 *)(piVar5 + 0x16) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196023;
            func_0x00018021a070(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x102);
            *(undefined8 *)(piVar5 + 0x14) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196040;
            fcn.180224990(uVar1, 0x1804a94a0, 0x612);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180196060
// Address: 0x180196060
// Size: 28 bytes
// ============================================================
int32_t * fcn.180196060(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    uint64_t uVar1;
    undefined8 uVar2;
    code *pcVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int32_t *piVar11;
    int64_t iVar12;
    int64_t iVar13;
    int32_t *piVar14;
    int32_t *piVar15;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 uStackX_8;
    int64_t var_10h;
    undefined8 auStackX_18 [2];
    
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    piVar14 = *(int32_t **)(in_RCX + 8);
    piVar15 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&arg_48h + iVar9) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar9 + 8) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar9) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar9 + -8) = unaff_R14;
    *(undefined8 *)((int64_t)&uStackX_8 + iVar9) = 0x180196093;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801960b6;
    piVar11 = (int32_t *)fcn.180224d60(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9));
    if (piVar11 == (int32_t *)0x0) {
        return (int32_t *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar10 + iVar9) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_58h + iVar10 + iVar9) = unaff_R12;
    if (piVar15 == (int32_t *)0x0) {
        piVar15 = piVar11;
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar10 + iVar9) = unaff_R15;
    *(int32_t **)(piVar11 + 0x10) = piVar15;
    LOCK();
    piVar15 = (int32_t *)(in_RCX + 0xa4);
    iVar8 = *piVar15;
    *piVar15 = *piVar15 + 1;
    UNLOCK();
    if (iVar8 + 1 < 2) {
code_r0x0001801968b9:
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801968ce;
        fcn.180224990(piVar11, 0x1804a94a0, 0x2f1);
        piVar11 = (int32_t *)0x0;
    } else {
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019610b;
        iVar12 = fcn.180222800();
        *(int64_t *)(piVar11 + 10) = iVar12;
        if (iVar12 == 0) {
code_r0x0001801968a4:
            uVar4 = *(undefined8 *)(piVar11 + 10);
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801968ad;
            fcn.1802227d0(uVar4);
            *(undefined8 *)(piVar11 + 10) = 0;
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801968b9;
            fcn.180191f00(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9), 
                          *(int64_t *)(&stack0x00000038 + iVar10 + iVar9), 
                          *(int64_t *)(&stack0x00000040 + iVar10 + iVar9), 
                          *(int64_t *)((int64_t)&arg_48h + iVar10 + iVar9));
            goto code_r0x0001801968b9;
        }
        piVar11[8] = 1;
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019612d;
        iVar8 = fcn.180224430(*(int64_t *)(&stack0x00000070 + iVar10 + iVar9));
        if (iVar8 == 0) goto code_r0x0001801968a4;
        *(int64_t *)(piVar11 + 2) = in_RCX;
        iVar8 = 0;
        *piVar11 = 0;
        *(int32_t **)(piVar11 + 6) = piVar14;
        *(int32_t **)(piVar11 + 4) = piVar14;
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196152;
        fcn.1801a2f30(piVar11 + 0x314, piVar11);
        *(undefined8 *)(piVar11 + 0x26a) = *(undefined8 *)(in_RCX + 0x138);
        piVar11[0x153] = *(int32_t *)(in_RCX + 0x3cc);
        if (*piVar14 == **(int32_t **)(in_RCX + 8)) {
            piVar11[0x26d] = *(int32_t *)(in_RCX + 0x144);
            piVar11[0x26e] = *(int32_t *)(in_RCX + 0x148);
        }
        piVar11[0x26c] = *(int32_t *)(in_RCX + 0x140);
        *(undefined8 *)(piVar11 + 0x270) = *(undefined8 *)(in_RCX + 0x150);
        piVar11[0x54e] = *(int32_t *)(in_RCX + 0x3f0);
        piVar11[0x54f] = *(int32_t *)(in_RCX + 0x3f4);
        *(undefined8 *)(piVar11 + 0x552) = *(undefined8 *)(in_RCX + 0x430);
        piVar11[0x2eb] = *(int32_t *)(in_RCX + 0x448);
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801961e4;
        iVar12 = fcn.180221950(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9));
        *(int64_t *)(piVar11 + 0x15a) = iVar12;
        if (iVar12 == 0) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801961f5;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9), 
                          *(int64_t *)(&stack0x00000038 + iVar10 + iVar9));
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019620d;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9), 
                          *(int64_t *)(&stack0x00000038 + iVar10 + iVar9), 
                          *(int64_t *)(&stack0x00000040 + iVar10 + iVar9), 
                          *(int64_t *)((int64_t)&arg_48h + iVar10 + iVar9), 
                          *(int64_t *)((int64_t)&arg_60h + iVar10 + iVar9));
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019621f;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar10 + iVar9));
            goto code_r0x000180196905;
        }
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196230;
        iVar12 = fcn.1801a1980(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9), 
                               *(int64_t *)(&stack0x00000038 + iVar10 + iVar9), 
                               *(int64_t *)(&stack0x00000040 + iVar10 + iVar9), 
                               *(int64_t *)((int64_t)&arg_48h + iVar10 + iVar9));
        *(int64_t *)(piVar11 + 0x21e) = iVar12;
        if (iVar12 == 0) goto code_r0x0001801968d1;
        piVar11[0x326] = *(int32_t *)(in_RCX + 0x168);
        *(undefined8 *)(piVar11 + 0x13e) = *(undefined8 *)(in_RCX + 0x170);
        *(undefined8 *)(piVar11 + 0x140) = *(undefined8 *)(in_RCX + 0x178);
        piVar11[0x252] = *(int32_t *)(in_RCX + 0x180);
        *(undefined8 *)(piVar11 + 0x312) = *(undefined8 *)(in_RCX + 0x3d8);
        *(undefined8 *)(piVar11 + 0x338) = *(undefined8 *)(in_RCX + 0x3f8);
        *(undefined8 *)(piVar11 + 0x33a) = *(undefined8 *)(in_RCX + 0x400);
        *(undefined8 *)(piVar11 + 0x33c) = *(undefined8 *)(in_RCX + 0x408);
        *(undefined8 *)(piVar11 + 0x33e) = *(undefined8 *)(in_RCX + 0x410);
        uVar1 = *(uint64_t *)(in_RCX + 0x188);
        *(uint64_t *)(piVar11 + 0x234) = uVar1;
        if (0x20 < uVar1) goto code_r0x000180196905;
        iVar5 = *(int32_t *)(in_RCX + 0x194);
        iVar6 = *(int32_t *)(in_RCX + 0x198);
        iVar7 = *(int32_t *)(in_RCX + 0x19c);
        piVar11[0x236] = *(int32_t *)(in_RCX + 400);
        piVar11[0x237] = iVar5;
        piVar11[0x238] = iVar6;
        piVar11[0x239] = iVar7;
        iVar5 = *(int32_t *)(in_RCX + 0x1a4);
        iVar6 = *(int32_t *)(in_RCX + 0x1a8);
        iVar7 = *(int32_t *)(in_RCX + 0x1ac);
        piVar11[0x23a] = *(int32_t *)(in_RCX + 0x1a0);
        piVar11[0x23b] = iVar5;
        piVar11[0x23c] = iVar6;
        piVar11[0x23d] = iVar7;
        *(undefined8 *)(piVar11 + 0x254) = *(undefined8 *)(in_RCX + 0x1b0);
        *(undefined8 *)(piVar11 + 0x246) = *(undefined8 *)(in_RCX + 0x1b8);
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019630f;
        iVar12 = fcn.180234050();
        *(int64_t *)(piVar11 + 0x144) = iVar12;
        if (iVar12 == 0) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196320;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9), 
                          *(int64_t *)(&stack0x00000038 + iVar10 + iVar9));
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196338;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9), 
                          *(int64_t *)(&stack0x00000038 + iVar10 + iVar9), 
                          *(int64_t *)(&stack0x00000040 + iVar10 + iVar9), 
                          *(int64_t *)((int64_t)&arg_48h + iVar10 + iVar9), 
                          *(int64_t *)((int64_t)&arg_60h + iVar10 + iVar9));
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019634a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar10 + iVar9));
            goto code_r0x000180196905;
        }
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019635e;
        fcn.180233c60(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9), *(int64_t *)(&stack0x00000038 + iVar10 + iVar9), 
                      *(int64_t *)(&stack0x00000040 + iVar10 + iVar9));
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196363;
        iVar12 = fcn.18019b1e0();
        if (*(int64_t *)(in_RCX + 8) != iVar12) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019636e;
            iVar12 = fcn.18019b1f0();
            if (*(int64_t *)(in_RCX + 8) != iVar12) {
                *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196379;
                iVar12 = fcn.18019b200();
                if (*(int64_t *)(in_RCX + 8) != iVar12) {
                    iVar8 = *(int32_t *)(in_RCX + 0x1c8);
                }
            }
        }
        piVar11[0x20] = iVar8;
        iVar12 = *(int64_t *)(in_RCX + 8);
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196398;
        iVar13 = fcn.18019b1e0();
        if (iVar12 != iVar13) {
            iVar12 = *(int64_t *)(in_RCX + 8);
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801963a6;
            iVar13 = fcn.18019b1f0();
            if (iVar12 != iVar13) {
                iVar12 = *(int64_t *)(in_RCX + 8);
                *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801963b4;
                iVar13 = fcn.18019b200();
                if (iVar12 != iVar13) {
                    *(undefined *)(piVar11 + 0x2cd) = *(undefined *)(in_RCX + 0x27c);
                }
            }
        }
        *(undefined8 *)(piVar11 + 0x276) = *(undefined8 *)(in_RCX + 0x1f0);
        *(undefined8 *)(piVar11 + 0x274) = *(undefined8 *)(in_RCX + 0x1e8);
        *(undefined8 *)(piVar11 + 0x278) = *(undefined8 *)(in_RCX + 0x1f8);
        *(undefined8 *)(piVar11 + 0x324) = *(undefined8 *)(in_RCX + 0x200);
        *(undefined8 *)(piVar11 + 0x282) = 0;
        *(undefined8 *)(piVar11 + 0x284) = 0;
        piVar11[0x298] = 0;
        piVar11[0x288] = *(int32_t *)(in_RCX + 0x278);
        piVar11[0x28d] = 0;
        *(undefined8 *)(piVar11 + 0x28e) = 0;
        *(undefined8 *)(piVar11 + 0x290) = 0;
        *(undefined8 *)(piVar11 + 0x292) = 0;
        *(undefined8 *)(piVar11 + 0x294) = 0;
        *(undefined8 *)(piVar11 + 0x296) = 0;
        LOCK();
        piVar15 = (int32_t *)(in_RCX + 0xa4);
        iVar8 = *piVar15;
        *piVar15 = *piVar15 + 1;
        UNLOCK();
        if (iVar8 + 1 < 2) goto code_r0x000180196905;
        *(int64_t *)(piVar11 + 0x2e2) = in_RCX;
        if (*(int64_t *)(in_RCX + 0x288) != 0) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019648b;
            iVar12 = fcn.180223170(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9));
            *(int64_t *)(piVar11 + 0x29c) = iVar12;
            if (iVar12 == 0) {
                *(undefined8 *)(piVar11 + 0x29a) = 0;
                goto code_r0x000180196905;
            }
            *(undefined8 *)(piVar11 + 0x29a) = *(undefined8 *)(in_RCX + 0x280);
        }
        if (*(int64_t *)(in_RCX + 0x298) != 0) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801964e5;
            iVar12 = fcn.180223170(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9));
            *(int64_t *)(piVar11 + 0x2a4) = iVar12;
            if (iVar12 == 0) {
                *(undefined8 *)(piVar11 + 0x2a2) = 0;
                goto code_r0x000180196905;
            }
            *(undefined8 *)(piVar11 + 0x2a2) = *(undefined8 *)(in_RCX + 0x290);
        }
        if (*(int64_t *)(in_RCX + 0x2a8) != 0) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019653f;
            iVar12 = fcn.180223170(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9));
            *(int64_t *)(piVar11 + 0x2ac) = iVar12;
            if (iVar12 == 0) {
                *(undefined8 *)(piVar11 + 0x2aa) = 0;
                goto code_r0x000180196905;
            }
            *(undefined8 *)(piVar11 + 0x2aa) = *(undefined8 *)(in_RCX + 0x2a0);
        }
        if (*(int64_t *)(in_RCX + 0x2b8) != 0) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019659a;
            iVar12 = fcn.180223170(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9));
            *(int64_t *)(piVar11 + 0x2b0) = iVar12;
            if (iVar12 == 0) {
                *(undefined8 *)(piVar11 + 0x2ae) = 0;
                goto code_r0x000180196905;
            }
            *(undefined8 *)(piVar11 + 0x2ae) = *(undefined8 *)(in_RCX + 0x2b0);
        }
        *(undefined8 *)(piVar11 + 0x2c0) = 0;
        if (*(int64_t *)(in_RCX + 0x2d0) != 0) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801965e9;
            iVar12 = fcn.1802248d0(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9), 
                                   *(int64_t *)(&stack0x00000038 + iVar10 + iVar9));
            *(int64_t *)(piVar11 + 700) = iVar12;
            if (iVar12 == 0) {
                *(undefined8 *)(piVar11 + 0x2be) = 0;
                goto code_r0x000180196905;
            }
            uVar4 = *(undefined8 *)(in_RCX + 0x2d8);
            uVar2 = *(undefined8 *)(in_RCX + 0x2d0);
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196617;
            fcn.180498030(iVar12, uVar2, uVar4);
            *(undefined8 *)(piVar11 + 0x2be) = *(undefined8 *)(in_RCX + 0x2d8);
        }
        *(undefined8 *)(piVar11 + 0x262) = 0;
        piVar11[0x264] = 0;
        *(undefined8 *)(piVar11 + 0x544) = *(undefined8 *)(in_RCX + 0xb8);
        *(undefined8 *)(piVar11 + 0x546) = *(undefined8 *)(in_RCX + 0xc0);
        piVar11[0x2e9] = -1;
        iVar12 = *(int64_t *)(in_RCX + 8);
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019665e;
        iVar13 = fcn.18019b1e0();
        if (iVar12 != iVar13) {
            iVar12 = *(int64_t *)(in_RCX + 8);
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019666c;
            iVar13 = fcn.18019b1f0();
            if (iVar12 != iVar13) {
                iVar12 = *(int64_t *)(in_RCX + 8);
                *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019667a;
                iVar13 = fcn.18019b200();
                if (iVar12 != iVar13) {
                    *(undefined8 *)(piVar11 + 0x558) = *(undefined8 *)(in_RCX + 0x438);
                    *(undefined8 *)(piVar11 + 0x55a) = *(undefined8 *)(in_RCX + 0x440);
                }
            }
        }
        pcVar3 = *(code **)(piVar14 + 10);
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801966a4;
        iVar8 = (*pcVar3)(piVar11);
        if (iVar8 != 0) {
            piVar11[0x1e] = (uint32_t)(*(int64_t *)(piVar14 + 0x10) != 0x1801982f0);
            pcVar3 = *(code **)(piVar14 + 8);
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801966c8;
            iVar8 = (*pcVar3)(piVar11);
            if (iVar8 != 0) {
                *(undefined8 *)(piVar11 + 0x25a) = *(undefined8 *)(in_RCX + 800);
                *(undefined8 *)(piVar11 + 0x25c) = *(undefined8 *)(in_RCX + 0x328);
                *(undefined8 *)(piVar11 + 0x25e) = *(undefined8 *)(in_RCX + 0x330);
                *(undefined8 *)(piVar11 + 0x260) = *(undefined8 *)(in_RCX + 0x338);
                *(undefined8 *)(piVar11 + 0x55c) = *(undefined8 *)(in_RCX + 0x450);
                *(undefined8 *)(piVar11 + 0x55e) = *(undefined8 *)(in_RCX + 0x458);
                *(undefined8 *)(piVar11 + 0x548) = 0;
                if (*(int64_t *)(in_RCX + 0x6a0) != 0) {
                    *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196750;
                    iVar12 = fcn.180223170(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9));
                    *(int64_t *)(piVar11 + 0x564) = iVar12;
                    if (iVar12 == 0) goto code_r0x0001801968d1;
                    *(undefined8 *)(piVar11 + 0x566) = *(undefined8 *)(in_RCX + 0x6a8);
                }
                if (*(int64_t *)(in_RCX + 0x6b0) != 0) {
                    *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196793;
                    iVar12 = fcn.180223170(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9));
                    *(int64_t *)(piVar11 + 0x568) = iVar12;
                    if (iVar12 == 0) goto code_r0x0001801968d1;
                    *(undefined8 *)(piVar11 + 0x56a) = *(undefined8 *)(in_RCX + 0x6b8);
                }
                uVar4 = *(undefined8 *)(in_RCX + 0x1e0);
                iVar12 = *(int64_t *)(in_RCX + 0x1d8);
                piVar14 = piVar11;
                if (*piVar11 == 0) {
code_r0x0001801967e6:
                    if (iVar12 == 0) {
code_r0x00018019687c:
                        *(int64_t *)(piVar14 + 0x2da) = iVar12;
                        *(undefined8 *)(piVar14 + 0x2dc) = uVar4;
                        *(int64_t *)(piVar11 + 0x46) = *(int64_t *)(in_RCX + 0x680) + 9;
                        return piVar11;
                    }
                    uVar2 = *(undefined8 *)(piVar11 + 2);
                    *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801967fd;
                    iVar8 = fcn.18019a6a0(uVar2, 0x12);
                    if (iVar8 == 0) {
                        piVar15 = piVar11;
                        if ((*piVar11 != 0) && (piVar15 = (int32_t *)0x0, (char)*piVar11 < '\0')) {
                            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019684c;
                            piVar15 = (int32_t *)fcn.1801bda50(piVar11);
                        }
                        if (((*(uint8_t *)piVar11 & 0x80) != 0) || (piVar15 != (int32_t *)0x0)) {
                            pcVar3 = *(code **)(*(int64_t *)(piVar11 + 6) + 0x98);
                            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196878;
                            iVar8 = (*pcVar3)(piVar11, 0x41, 1, 0);
                            if (iVar8 != 0) goto code_r0x00018019687c;
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196806;
                        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9), 
                                      *(int64_t *)(&stack0x00000038 + iVar10 + iVar9));
                        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019681e;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9), 
                                      *(int64_t *)(&stack0x00000038 + iVar10 + iVar9), 
                                      *(int64_t *)(&stack0x00000040 + iVar10 + iVar9), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar10 + iVar9), 
                                      *(int64_t *)((int64_t)&arg_60h + iVar10 + iVar9));
                        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196830;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar10 + iVar9));
                    }
                } else if ((char)*piVar11 < '\0') {
                    *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801967da;
                    piVar14 = (int32_t *)fcn.1801bda50(piVar11);
                    if (piVar14 != (int32_t *)0x0) goto code_r0x0001801967e6;
                }
            }
        }
    }
code_r0x0001801968d1:
    *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801968d6;
    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9), *(int64_t *)(&stack0x00000038 + iVar10 + iVar9));
    *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801968ee;
    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9), *(int64_t *)(&stack0x00000038 + iVar10 + iVar9), 
                  *(int64_t *)(&stack0x00000040 + iVar10 + iVar9), *(int64_t *)((int64_t)&arg_48h + iVar10 + iVar9), 
                  *(int64_t *)((int64_t)&arg_60h + iVar10 + iVar9));
    *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196900;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar10 + iVar9));
    if (piVar11 == (int32_t *)0x0) {
        return (int32_t *)0x0;
    }
code_r0x000180196905:
    LOCK();
    piVar14 = piVar11 + 8;
    iVar8 = *piVar14;
    *piVar14 = *piVar14 + -1;
    UNLOCK();
    if (iVar8 < 2) {
        if (*(int64_t *)(piVar11 + 6) != 0) {
            pcVar3 = *(code **)(*(int64_t *)(piVar11 + 6) + 0x18);
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196923;
            (*pcVar3)(piVar11);
        }
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196931;
        fcn.180223fb0(*(int64_t *)(&stack0x000000b0 + iVar10 + iVar9), *(int64_t *)(&stack0x00000118 + iVar10 + iVar9));
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019693a;
        fcn.180191f00(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9), *(int64_t *)(&stack0x00000038 + iVar10 + iVar9), 
                      *(int64_t *)(&stack0x00000040 + iVar10 + iVar9), *(int64_t *)((int64_t)&arg_48h + iVar10 + iVar9))
        ;
        uVar4 = *(undefined8 *)(piVar11 + 10);
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196943;
        fcn.1802227d0(uVar4);
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196958;
        fcn.180224990(piVar11, 0x1804a94a0, 0x5aa);
    }
    return (int32_t *)0x0;
}

// ============================================================
// Function: FUN_180196080
// Address: 0x180196080
// Size: 2295 bytes
// ============================================================
int32_t * fcn.180196060(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    uint64_t uVar1;
    undefined8 uVar2;
    code *pcVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int32_t *piVar11;
    int64_t iVar12;
    int64_t iVar13;
    int32_t *piVar14;
    int32_t *piVar15;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 uStackX_8;
    int64_t var_10h;
    undefined8 auStackX_18 [2];
    
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    piVar14 = *(int32_t **)(in_RCX + 8);
    piVar15 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&arg_48h + iVar9) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar9 + 8) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar9) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar9 + -8) = unaff_R14;
    *(undefined8 *)((int64_t)&uStackX_8 + iVar9) = 0x180196093;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801960b6;
    piVar11 = (int32_t *)fcn.180224d60(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9));
    if (piVar11 == (int32_t *)0x0) {
        return (int32_t *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar10 + iVar9) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_58h + iVar10 + iVar9) = unaff_R12;
    if (piVar15 == (int32_t *)0x0) {
        piVar15 = piVar11;
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar10 + iVar9) = unaff_R15;
    *(int32_t **)(piVar11 + 0x10) = piVar15;
    LOCK();
    piVar15 = (int32_t *)(in_RCX + 0xa4);
    iVar8 = *piVar15;
    *piVar15 = *piVar15 + 1;
    UNLOCK();
    if (iVar8 + 1 < 2) {
code_r0x0001801968b9:
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801968ce;
        fcn.180224990(piVar11, 0x1804a94a0, 0x2f1);
        piVar11 = (int32_t *)0x0;
    } else {
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019610b;
        iVar12 = fcn.180222800();
        *(int64_t *)(piVar11 + 10) = iVar12;
        if (iVar12 == 0) {
code_r0x0001801968a4:
            uVar4 = *(undefined8 *)(piVar11 + 10);
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801968ad;
            fcn.1802227d0(uVar4);
            *(undefined8 *)(piVar11 + 10) = 0;
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801968b9;
            fcn.180191f00(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9), 
                          *(int64_t *)(&stack0x00000038 + iVar10 + iVar9), 
                          *(int64_t *)(&stack0x00000040 + iVar10 + iVar9), 
                          *(int64_t *)((int64_t)&arg_48h + iVar10 + iVar9));
            goto code_r0x0001801968b9;
        }
        piVar11[8] = 1;
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019612d;
        iVar8 = fcn.180224430(*(int64_t *)(&stack0x00000070 + iVar10 + iVar9));
        if (iVar8 == 0) goto code_r0x0001801968a4;
        *(int64_t *)(piVar11 + 2) = in_RCX;
        iVar8 = 0;
        *piVar11 = 0;
        *(int32_t **)(piVar11 + 6) = piVar14;
        *(int32_t **)(piVar11 + 4) = piVar14;
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196152;
        fcn.1801a2f30(piVar11 + 0x314, piVar11);
        *(undefined8 *)(piVar11 + 0x26a) = *(undefined8 *)(in_RCX + 0x138);
        piVar11[0x153] = *(int32_t *)(in_RCX + 0x3cc);
        if (*piVar14 == **(int32_t **)(in_RCX + 8)) {
            piVar11[0x26d] = *(int32_t *)(in_RCX + 0x144);
            piVar11[0x26e] = *(int32_t *)(in_RCX + 0x148);
        }
        piVar11[0x26c] = *(int32_t *)(in_RCX + 0x140);
        *(undefined8 *)(piVar11 + 0x270) = *(undefined8 *)(in_RCX + 0x150);
        piVar11[0x54e] = *(int32_t *)(in_RCX + 0x3f0);
        piVar11[0x54f] = *(int32_t *)(in_RCX + 0x3f4);
        *(undefined8 *)(piVar11 + 0x552) = *(undefined8 *)(in_RCX + 0x430);
        piVar11[0x2eb] = *(int32_t *)(in_RCX + 0x448);
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801961e4;
        iVar12 = fcn.180221950(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9));
        *(int64_t *)(piVar11 + 0x15a) = iVar12;
        if (iVar12 == 0) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801961f5;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9), 
                          *(int64_t *)(&stack0x00000038 + iVar10 + iVar9));
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019620d;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9), 
                          *(int64_t *)(&stack0x00000038 + iVar10 + iVar9), 
                          *(int64_t *)(&stack0x00000040 + iVar10 + iVar9), 
                          *(int64_t *)((int64_t)&arg_48h + iVar10 + iVar9), 
                          *(int64_t *)((int64_t)&arg_60h + iVar10 + iVar9));
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019621f;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar10 + iVar9));
            goto code_r0x000180196905;
        }
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196230;
        iVar12 = fcn.1801a1980(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9), 
                               *(int64_t *)(&stack0x00000038 + iVar10 + iVar9), 
                               *(int64_t *)(&stack0x00000040 + iVar10 + iVar9), 
                               *(int64_t *)((int64_t)&arg_48h + iVar10 + iVar9));
        *(int64_t *)(piVar11 + 0x21e) = iVar12;
        if (iVar12 == 0) goto code_r0x0001801968d1;
        piVar11[0x326] = *(int32_t *)(in_RCX + 0x168);
        *(undefined8 *)(piVar11 + 0x13e) = *(undefined8 *)(in_RCX + 0x170);
        *(undefined8 *)(piVar11 + 0x140) = *(undefined8 *)(in_RCX + 0x178);
        piVar11[0x252] = *(int32_t *)(in_RCX + 0x180);
        *(undefined8 *)(piVar11 + 0x312) = *(undefined8 *)(in_RCX + 0x3d8);
        *(undefined8 *)(piVar11 + 0x338) = *(undefined8 *)(in_RCX + 0x3f8);
        *(undefined8 *)(piVar11 + 0x33a) = *(undefined8 *)(in_RCX + 0x400);
        *(undefined8 *)(piVar11 + 0x33c) = *(undefined8 *)(in_RCX + 0x408);
        *(undefined8 *)(piVar11 + 0x33e) = *(undefined8 *)(in_RCX + 0x410);
        uVar1 = *(uint64_t *)(in_RCX + 0x188);
        *(uint64_t *)(piVar11 + 0x234) = uVar1;
        if (0x20 < uVar1) goto code_r0x000180196905;
        iVar5 = *(int32_t *)(in_RCX + 0x194);
        iVar6 = *(int32_t *)(in_RCX + 0x198);
        iVar7 = *(int32_t *)(in_RCX + 0x19c);
        piVar11[0x236] = *(int32_t *)(in_RCX + 400);
        piVar11[0x237] = iVar5;
        piVar11[0x238] = iVar6;
        piVar11[0x239] = iVar7;
        iVar5 = *(int32_t *)(in_RCX + 0x1a4);
        iVar6 = *(int32_t *)(in_RCX + 0x1a8);
        iVar7 = *(int32_t *)(in_RCX + 0x1ac);
        piVar11[0x23a] = *(int32_t *)(in_RCX + 0x1a0);
        piVar11[0x23b] = iVar5;
        piVar11[0x23c] = iVar6;
        piVar11[0x23d] = iVar7;
        *(undefined8 *)(piVar11 + 0x254) = *(undefined8 *)(in_RCX + 0x1b0);
        *(undefined8 *)(piVar11 + 0x246) = *(undefined8 *)(in_RCX + 0x1b8);
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019630f;
        iVar12 = fcn.180234050();
        *(int64_t *)(piVar11 + 0x144) = iVar12;
        if (iVar12 == 0) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196320;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9), 
                          *(int64_t *)(&stack0x00000038 + iVar10 + iVar9));
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196338;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9), 
                          *(int64_t *)(&stack0x00000038 + iVar10 + iVar9), 
                          *(int64_t *)(&stack0x00000040 + iVar10 + iVar9), 
                          *(int64_t *)((int64_t)&arg_48h + iVar10 + iVar9), 
                          *(int64_t *)((int64_t)&arg_60h + iVar10 + iVar9));
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019634a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar10 + iVar9));
            goto code_r0x000180196905;
        }
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019635e;
        fcn.180233c60(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9), *(int64_t *)(&stack0x00000038 + iVar10 + iVar9), 
                      *(int64_t *)(&stack0x00000040 + iVar10 + iVar9));
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196363;
        iVar12 = fcn.18019b1e0();
        if (*(int64_t *)(in_RCX + 8) != iVar12) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019636e;
            iVar12 = fcn.18019b1f0();
            if (*(int64_t *)(in_RCX + 8) != iVar12) {
                *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196379;
                iVar12 = fcn.18019b200();
                if (*(int64_t *)(in_RCX + 8) != iVar12) {
                    iVar8 = *(int32_t *)(in_RCX + 0x1c8);
                }
            }
        }
        piVar11[0x20] = iVar8;
        iVar12 = *(int64_t *)(in_RCX + 8);
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196398;
        iVar13 = fcn.18019b1e0();
        if (iVar12 != iVar13) {
            iVar12 = *(int64_t *)(in_RCX + 8);
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801963a6;
            iVar13 = fcn.18019b1f0();
            if (iVar12 != iVar13) {
                iVar12 = *(int64_t *)(in_RCX + 8);
                *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801963b4;
                iVar13 = fcn.18019b200();
                if (iVar12 != iVar13) {
                    *(undefined *)(piVar11 + 0x2cd) = *(undefined *)(in_RCX + 0x27c);
                }
            }
        }
        *(undefined8 *)(piVar11 + 0x276) = *(undefined8 *)(in_RCX + 0x1f0);
        *(undefined8 *)(piVar11 + 0x274) = *(undefined8 *)(in_RCX + 0x1e8);
        *(undefined8 *)(piVar11 + 0x278) = *(undefined8 *)(in_RCX + 0x1f8);
        *(undefined8 *)(piVar11 + 0x324) = *(undefined8 *)(in_RCX + 0x200);
        *(undefined8 *)(piVar11 + 0x282) = 0;
        *(undefined8 *)(piVar11 + 0x284) = 0;
        piVar11[0x298] = 0;
        piVar11[0x288] = *(int32_t *)(in_RCX + 0x278);
        piVar11[0x28d] = 0;
        *(undefined8 *)(piVar11 + 0x28e) = 0;
        *(undefined8 *)(piVar11 + 0x290) = 0;
        *(undefined8 *)(piVar11 + 0x292) = 0;
        *(undefined8 *)(piVar11 + 0x294) = 0;
        *(undefined8 *)(piVar11 + 0x296) = 0;
        LOCK();
        piVar15 = (int32_t *)(in_RCX + 0xa4);
        iVar8 = *piVar15;
        *piVar15 = *piVar15 + 1;
        UNLOCK();
        if (iVar8 + 1 < 2) goto code_r0x000180196905;
        *(int64_t *)(piVar11 + 0x2e2) = in_RCX;
        if (*(int64_t *)(in_RCX + 0x288) != 0) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019648b;
            iVar12 = fcn.180223170(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9));
            *(int64_t *)(piVar11 + 0x29c) = iVar12;
            if (iVar12 == 0) {
                *(undefined8 *)(piVar11 + 0x29a) = 0;
                goto code_r0x000180196905;
            }
            *(undefined8 *)(piVar11 + 0x29a) = *(undefined8 *)(in_RCX + 0x280);
        }
        if (*(int64_t *)(in_RCX + 0x298) != 0) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801964e5;
            iVar12 = fcn.180223170(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9));
            *(int64_t *)(piVar11 + 0x2a4) = iVar12;
            if (iVar12 == 0) {
                *(undefined8 *)(piVar11 + 0x2a2) = 0;
                goto code_r0x000180196905;
            }
            *(undefined8 *)(piVar11 + 0x2a2) = *(undefined8 *)(in_RCX + 0x290);
        }
        if (*(int64_t *)(in_RCX + 0x2a8) != 0) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019653f;
            iVar12 = fcn.180223170(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9));
            *(int64_t *)(piVar11 + 0x2ac) = iVar12;
            if (iVar12 == 0) {
                *(undefined8 *)(piVar11 + 0x2aa) = 0;
                goto code_r0x000180196905;
            }
            *(undefined8 *)(piVar11 + 0x2aa) = *(undefined8 *)(in_RCX + 0x2a0);
        }
        if (*(int64_t *)(in_RCX + 0x2b8) != 0) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019659a;
            iVar12 = fcn.180223170(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9));
            *(int64_t *)(piVar11 + 0x2b0) = iVar12;
            if (iVar12 == 0) {
                *(undefined8 *)(piVar11 + 0x2ae) = 0;
                goto code_r0x000180196905;
            }
            *(undefined8 *)(piVar11 + 0x2ae) = *(undefined8 *)(in_RCX + 0x2b0);
        }
        *(undefined8 *)(piVar11 + 0x2c0) = 0;
        if (*(int64_t *)(in_RCX + 0x2d0) != 0) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801965e9;
            iVar12 = fcn.1802248d0(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9), 
                                   *(int64_t *)(&stack0x00000038 + iVar10 + iVar9));
            *(int64_t *)(piVar11 + 700) = iVar12;
            if (iVar12 == 0) {
                *(undefined8 *)(piVar11 + 0x2be) = 0;
                goto code_r0x000180196905;
            }
            uVar4 = *(undefined8 *)(in_RCX + 0x2d8);
            uVar2 = *(undefined8 *)(in_RCX + 0x2d0);
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196617;
            fcn.180498030(iVar12, uVar2, uVar4);
            *(undefined8 *)(piVar11 + 0x2be) = *(undefined8 *)(in_RCX + 0x2d8);
        }
        *(undefined8 *)(piVar11 + 0x262) = 0;
        piVar11[0x264] = 0;
        *(undefined8 *)(piVar11 + 0x544) = *(undefined8 *)(in_RCX + 0xb8);
        *(undefined8 *)(piVar11 + 0x546) = *(undefined8 *)(in_RCX + 0xc0);
        piVar11[0x2e9] = -1;
        iVar12 = *(int64_t *)(in_RCX + 8);
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019665e;
        iVar13 = fcn.18019b1e0();
        if (iVar12 != iVar13) {
            iVar12 = *(int64_t *)(in_RCX + 8);
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019666c;
            iVar13 = fcn.18019b1f0();
            if (iVar12 != iVar13) {
                iVar12 = *(int64_t *)(in_RCX + 8);
                *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019667a;
                iVar13 = fcn.18019b200();
                if (iVar12 != iVar13) {
                    *(undefined8 *)(piVar11 + 0x558) = *(undefined8 *)(in_RCX + 0x438);
                    *(undefined8 *)(piVar11 + 0x55a) = *(undefined8 *)(in_RCX + 0x440);
                }
            }
        }
        pcVar3 = *(code **)(piVar14 + 10);
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801966a4;
        iVar8 = (*pcVar3)(piVar11);
        if (iVar8 != 0) {
            piVar11[0x1e] = (uint32_t)(*(int64_t *)(piVar14 + 0x10) != 0x1801982f0);
            pcVar3 = *(code **)(piVar14 + 8);
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801966c8;
            iVar8 = (*pcVar3)(piVar11);
            if (iVar8 != 0) {
                *(undefined8 *)(piVar11 + 0x25a) = *(undefined8 *)(in_RCX + 800);
                *(undefined8 *)(piVar11 + 0x25c) = *(undefined8 *)(in_RCX + 0x328);
                *(undefined8 *)(piVar11 + 0x25e) = *(undefined8 *)(in_RCX + 0x330);
                *(undefined8 *)(piVar11 + 0x260) = *(undefined8 *)(in_RCX + 0x338);
                *(undefined8 *)(piVar11 + 0x55c) = *(undefined8 *)(in_RCX + 0x450);
                *(undefined8 *)(piVar11 + 0x55e) = *(undefined8 *)(in_RCX + 0x458);
                *(undefined8 *)(piVar11 + 0x548) = 0;
                if (*(int64_t *)(in_RCX + 0x6a0) != 0) {
                    *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196750;
                    iVar12 = fcn.180223170(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9));
                    *(int64_t *)(piVar11 + 0x564) = iVar12;
                    if (iVar12 == 0) goto code_r0x0001801968d1;
                    *(undefined8 *)(piVar11 + 0x566) = *(undefined8 *)(in_RCX + 0x6a8);
                }
                if (*(int64_t *)(in_RCX + 0x6b0) != 0) {
                    *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196793;
                    iVar12 = fcn.180223170(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9));
                    *(int64_t *)(piVar11 + 0x568) = iVar12;
                    if (iVar12 == 0) goto code_r0x0001801968d1;
                    *(undefined8 *)(piVar11 + 0x56a) = *(undefined8 *)(in_RCX + 0x6b8);
                }
                uVar4 = *(undefined8 *)(in_RCX + 0x1e0);
                iVar12 = *(int64_t *)(in_RCX + 0x1d8);
                piVar14 = piVar11;
                if (*piVar11 == 0) {
code_r0x0001801967e6:
                    if (iVar12 == 0) {
code_r0x00018019687c:
                        *(int64_t *)(piVar14 + 0x2da) = iVar12;
                        *(undefined8 *)(piVar14 + 0x2dc) = uVar4;
                        *(int64_t *)(piVar11 + 0x46) = *(int64_t *)(in_RCX + 0x680) + 9;
                        return piVar11;
                    }
                    uVar2 = *(undefined8 *)(piVar11 + 2);
                    *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801967fd;
                    iVar8 = fcn.18019a6a0(uVar2, 0x12);
                    if (iVar8 == 0) {
                        piVar15 = piVar11;
                        if ((*piVar11 != 0) && (piVar15 = (int32_t *)0x0, (char)*piVar11 < '\0')) {
                            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019684c;
                            piVar15 = (int32_t *)fcn.1801bda50(piVar11);
                        }
                        if (((*(uint8_t *)piVar11 & 0x80) != 0) || (piVar15 != (int32_t *)0x0)) {
                            pcVar3 = *(code **)(*(int64_t *)(piVar11 + 6) + 0x98);
                            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196878;
                            iVar8 = (*pcVar3)(piVar11, 0x41, 1, 0);
                            if (iVar8 != 0) goto code_r0x00018019687c;
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196806;
                        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9), 
                                      *(int64_t *)(&stack0x00000038 + iVar10 + iVar9));
                        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019681e;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9), 
                                      *(int64_t *)(&stack0x00000038 + iVar10 + iVar9), 
                                      *(int64_t *)(&stack0x00000040 + iVar10 + iVar9), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar10 + iVar9), 
                                      *(int64_t *)((int64_t)&arg_60h + iVar10 + iVar9));
                        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196830;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar10 + iVar9));
                    }
                } else if ((char)*piVar11 < '\0') {
                    *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801967da;
                    piVar14 = (int32_t *)fcn.1801bda50(piVar11);
                    if (piVar14 != (int32_t *)0x0) goto code_r0x0001801967e6;
                }
            }
        }
    }
code_r0x0001801968d1:
    *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801968d6;
    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9), *(int64_t *)(&stack0x00000038 + iVar10 + iVar9));
    *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x1801968ee;
    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9), *(int64_t *)(&stack0x00000038 + iVar10 + iVar9), 
                  *(int64_t *)(&stack0x00000040 + iVar10 + iVar9), *(int64_t *)((int64_t)&arg_48h + iVar10 + iVar9), 
                  *(int64_t *)((int64_t)&arg_60h + iVar10 + iVar9));
    *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196900;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar10 + iVar9));
    if (piVar11 == (int32_t *)0x0) {
        return (int32_t *)0x0;
    }
code_r0x000180196905:
    LOCK();
    piVar14 = piVar11 + 8;
    iVar8 = *piVar14;
    *piVar14 = *piVar14 + -1;
    UNLOCK();
    if (iVar8 < 2) {
        if (*(int64_t *)(piVar11 + 6) != 0) {
            pcVar3 = *(code **)(*(int64_t *)(piVar11 + 6) + 0x18);
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196923;
            (*pcVar3)(piVar11);
        }
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196931;
        fcn.180223fb0(*(int64_t *)(&stack0x000000b0 + iVar10 + iVar9), *(int64_t *)(&stack0x00000118 + iVar10 + iVar9));
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x18019693a;
        fcn.180191f00(*(int64_t *)(&stack0x00000030 + iVar10 + iVar9), *(int64_t *)(&stack0x00000038 + iVar10 + iVar9), 
                      *(int64_t *)(&stack0x00000040 + iVar10 + iVar9), *(int64_t *)((int64_t)&arg_48h + iVar10 + iVar9))
        ;
        uVar4 = *(undefined8 *)(piVar11 + 10);
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196943;
        fcn.1802227d0(uVar4);
        *(undefined8 *)((int64_t)&uStackX_8 + iVar10 + iVar9) = 0x180196958;
        fcn.180224990(piVar11, 0x1804a94a0, 0x5aa);
    }
    return (int32_t *)0x0;
}

// ============================================================
// Function: FUN_180196980
// Address: 0x180196980
// Size: 555 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.180196980(int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int32_t *piVar5;
    int32_t *in_RCX;
    code *pcVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180196995;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX == (int32_t *)0x0) {
        return false;
    }
    piVar5 = in_RCX;
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return false;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801969bc;
        piVar5 = (int32_t *)fcn.1801bda50();
        if (piVar5 == (int32_t *)0x0) {
            return false;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801969d0;
    iVar3 = func_0x00018019d1c0(piVar5);
    if (iVar3 != 0) {
        uVar1 = *(undefined8 *)(piVar5 + 0x23e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801969e2;
        func_0x00018019c980(uVar1);
        *(undefined8 *)(piVar5 + 0x23e) = 0;
    }
    uVar1 = *(undefined8 *)(piVar5 + 0x240);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801969f5;
    func_0x00018019c980(uVar1);
    uVar1 = *(undefined8 *)(piVar5 + 0x242);
    *(undefined8 *)(piVar5 + 0x240) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180196a15;
    fcn.180224990(uVar1, 0x1804a94a0, 0x256);
    *(undefined8 *)(piVar5 + 0x242) = 0;
    *(undefined8 *)(piVar5 + 0x244) = 0;
    piVar5[0x232] = 0;
    *(undefined8 *)(piVar5 + 0x554) = 0;
    piVar5[600] = 0;
    piVar5[0x142] = 0;
    piVar5[0x21] = 0;
    if (piVar5[0x2e8] == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180196a93;
        fcn.18019b4f0(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
        iVar3 = **(int32_t **)(in_RCX + 6);
        piVar5[0x12] = iVar3;
        piVar5[0x273] = iVar3;
        uVar1 = *(undefined8 *)(piVar5 + 0x3e);
        piVar5[0x1a] = 1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180196ab5;
        func_0x000180226310(uVar1);
        *(undefined8 *)(piVar5 + 0x3e) = 0;
        piVar5[0x272] = 0;
        piVar5[0x2e9] = -1;
        *(undefined (*) [16])(piVar5 + 0x2cf) = ZEXT816(0);
        uVar1 = *(undefined8 *)(piVar5 + 0x2f2);
        piVar5[0x2d3] = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180196ae8;
        func_0x000180215310(uVar1);
        *(undefined8 *)(piVar5 + 0x2f2) = 0;
        *(undefined8 *)(piVar5 + 0x151) = 0xffffffffffffffff;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180196b06;
        fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000048 + iVar4));
        uVar1 = *(undefined8 *)(piVar5 + 0x144);
        *(undefined8 *)(piVar5 + 0x14e) = 0;
        *(undefined8 *)(piVar5 + 0x14c) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180196b22;
        func_0x000180233fe0(uVar1, 0);
        uVar1 = *(undefined8 *)(piVar5 + 0x560);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180196b3b;
        fcn.180224990(uVar1, 0x1804a94a0, 0x282);
        *(undefined8 *)(piVar5 + 0x560) = 0;
        *(undefined8 *)(piVar5 + 0x562) = 0;
        iVar2 = *(int64_t *)(in_RCX + 6);
        if (iVar2 == *(int64_t *)(in_RCX + 4)) {
            pcVar6 = *(code **)(iVar2 + 0x30);
        } else {
            pcVar6 = *(code **)(iVar2 + 0x38);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180196b5c;
            (*pcVar6)(in_RCX);
            *(int64_t *)(in_RCX + 6) = *(int64_t *)(in_RCX + 4);
            pcVar6 = *(code **)(*(int64_t *)(in_RCX + 4) + 0x28);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180196b73;
        iVar3 = (*pcVar6)(in_RCX);
        if (iVar3 != 0) {
            uVar1 = *(undefined8 *)(piVar5 + 0x56);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180196b87;
            func_0x0001801a5ea0(uVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180196b93;
            iVar3 = fcn.1801a2fd0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                  *(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                                  *(int64_t *)(&stack0x00000048 + iVar4), *(int64_t *)(&stack0x00000050 + iVar4), 
                                  *(int64_t *)(&stack0x00000058 + iVar4), *(int64_t *)(&stack0x00000060 + iVar4), 
                                  *(int64_t *)(&stack0x00000068 + iVar4), *(int64_t *)(&stack0x00000070 + iVar4), 
                                  *(int64_t *)(&stack0x00000078 + iVar4), *(int64_t *)(&stack0x00000080 + iVar4), 
                                  *(int64_t *)(&stack0x00000088 + iVar4));
            return iVar3 != 0;
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180196a4f;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180196a67;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180196a79;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar4));
    }
    return false;
}

// ============================================================
// Function: FUN_180196bb0
// Address: 0x180196bb0
// Size: 608 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Type propagation algorithm not settling

uint64_t fcn.180196bb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t *piVar4;
    uint64_t uVar5;
    undefined8 uVar6;
    int32_t *piVar7;
    int32_t *in_RCX;
    uint64_t in_RDX;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180196bd0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == (int32_t *)0x0) {
code_r0x000180196bfb:
        piVar4 = (int32_t *)0x0;
    } else {
        piVar4 = in_RCX;
        if (*in_RCX != 0) {
            if (-1 < (char)*in_RCX) goto code_r0x000180196bfb;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196bf6;
            piVar4 = (int32_t *)fcn.1801bda50();
        }
    }
    if (0 < (int32_t)in_RDX) {
        return 0;
    }
    if ((in_RCX != (int32_t *)0x0) && ((*(uint8_t *)in_RCX & 0x80) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196c1a;
        uVar5 = func_0x0001801bf220(in_RCX, in_RDX & 0xffffffff);
        if ((int32_t)uVar5 != 0) {
            return uVar5;
        }
    }
    if (piVar4 == (int32_t *)0x0) {
        return 1;
    }
    if (in_R8D != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196c2d;
        uVar1 = func_0x000180220920();
        if (uVar1 != 0) {
            if ((int32_t)uVar1 < 0) {
                return 5;
            }
            if ((uVar1 & 0x7f800000) == 0x1000000) {
                return 5;
            }
            return 1;
        }
    }
    if (in_RCX == (int32_t *)0x0) {
code_r0x000180196cda:
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196ce2;
        iVar2 = fcn.180194f30(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3));
        if (iVar2 == 2) {
            uVar6 = *(undefined8 *)(piVar4 + 0x16);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196cf5;
            iVar2 = func_0x00018021b270(uVar6, 2);
            if (iVar2 != 0) {
                return 3;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196d10;
            iVar2 = func_0x00018021b270(uVar6, 1);
            if (iVar2 != 0) {
                return 2;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196d2b;
            iVar2 = func_0x00018021b270(uVar6, 4);
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196d37;
                iVar2 = func_0x000180182b10(uVar6);
joined_r0x000180196d3a:
                if (iVar2 == 2) {
                    return 7;
                }
                if (iVar2 != 3) {
                    return 5;
                }
                return 8;
            }
        }
        if (in_RCX == (int32_t *)0x0) goto code_r0x000180196d95;
    } else if (-1 < (char)*in_RCX) {
        if ((*in_RCX == 0) && (in_RCX[0x1a] == 3)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196c88;
            uVar6 = func_0x000180193c40(in_RCX);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196c98;
            iVar2 = func_0x00018021b270(uVar6, 1);
            if (iVar2 != 0) {
                return 2;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196ca9;
            iVar2 = func_0x00018021b270(uVar6, 2);
            if (iVar2 != 0) {
                return 3;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196cba;
            iVar2 = func_0x00018021b270(uVar6, 4);
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196cc6;
                iVar2 = func_0x000180182b10(uVar6);
                goto joined_r0x000180196d3a;
            }
        }
        goto code_r0x000180196cda;
    }
    piVar7 = in_RCX;
    if ((*in_RCX != 0) && (piVar7 = (int32_t *)0x0, (char)*in_RCX < '\0')) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196d71;
        piVar7 = (int32_t *)fcn.1801bda50(in_RCX);
    }
    if ((*(uint8_t *)in_RCX & 0x80) == 0) {
        if (piVar7 == (int32_t *)0x0) goto code_r0x000180196d95;
        uVar5 = (uint64_t)(uint32_t)piVar7[0x1a];
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196d81;
        uVar5 = func_0x0001801bff00(in_RCX);
    }
    if ((int32_t)uVar5 == 4) {
        return uVar5;
    }
code_r0x000180196d95:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196d9d;
    iVar2 = fcn.180194f30(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3));
    if (iVar2 == 8) {
        return 0xc;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196db4;
    iVar2 = fcn.180194f30(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3));
    if (iVar2 == 5) {
        return 9;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196dcb;
    iVar2 = fcn.180194f30(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3));
    if (iVar2 == 6) {
        return 10;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180196de2;
    iVar2 = fcn.180194f30(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3));
    if (iVar2 != 7) {
        if ((*(uint8_t *)(piVar4 + 0x21) & 2) == 0) {
            return 5;
        }
        return (uint64_t)(6 - (piVar4[0x6f] != 0));
    }
    return 0xb;
}

// ============================================================
// Function: FUN_180196e10
// Address: 0x180196e10
// Size: 169 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180196e10(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t *piVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined4 *in_RCX;
    int64_t in_RDX;
    undefined8 in_R8;
    undefined4 in_R9D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180196e2a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    LOCK();
    piVar1 = (int32_t *)(in_RDX + 0xa4);
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    if (1 < iVar3 + 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180196e52;
        iVar5 = fcn.180222800();
        *(int64_t *)(in_RCX + 10) = iVar5;
        if (iVar5 != 0) {
            in_RCX[8] = 1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180196e70;
            iVar3 = fcn.180224430(*(int64_t *)(&stack0x00000058 + iVar4));
            if (iVar3 != 0) {
                *(int64_t *)(in_RCX + 2) = in_RDX;
                *in_RCX = in_R9D;
                *(undefined8 *)(in_RCX + 6) = in_R8;
                *(undefined8 *)(in_RCX + 4) = in_R8;
                return 1;
            }
        }
        uVar2 = *(undefined8 *)(in_RCX + 10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180196e92;
        fcn.1802227d0(uVar2);
        *(undefined8 *)(in_RCX + 10) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180196ea2;
        fcn.180191f00(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4));
    }
    return 0;
}

// ============================================================
// Function: FUN_180196ec0
// Address: 0x180196ec0
// Size: 26 bytes
// ============================================================
void fcn.180196ec0(code *UNRECOVERED_JUMPTABLE, undefined8 param_2)
{
    fcn.18045a350();
    // WARNING: Could not recover jumptable at 0x000180196ed7. Too many branches
    // WARNING: Treating indirect jump as call
    (*UNRECOVERED_JUMPTABLE)(param_2);
    return;
}

// ============================================================
// Function: FUN_180196ee0
// Address: 0x180196ee0
// Size: 84 bytes
// ============================================================
undefined8 fcn.180196ee0(int32_t *param_1)
{
    int64_t iVar1;
    int32_t *piVar2;
    undefined8 uVar3;
    undefined8 uStack_10;
    
    uStack_10 = 0x180196eec;
    iVar1 = fcn.18045a350();
    if (param_1 != (int32_t *)0x0) {
        piVar2 = param_1;
        if (*param_1 == 0) {
code_r0x000180196f13:
    // WARNING: Could not recover jumptable at 0x000180196f29. Too many branches
    // WARNING: Treating indirect jump as call
            uVar3 = (**(code **)(piVar2 + 0x55c))(param_1, *(undefined8 *)(piVar2 + 0x55e));
            return uVar3;
        }
        if ((char)*param_1 < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x180196f0b;
            piVar2 = (int32_t *)fcn.1801bda50();
            if (piVar2 != (int32_t *)0x0) goto code_r0x000180196f13;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180196f40
// Address: 0x180196f40
// Size: 737 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180196f40(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    undefined2 *puVar1;
    char cVar2;
    uint64_t uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t iVar8;
    undefined2 *puVar9;
    int64_t iVar10;
    undefined8 uVar11;
    int64_t in_RCX;
    int64_t iVar12;
    undefined4 *in_RDX;
    char *pcVar13;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180196f55;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    uVar3 = *(uint64_t *)(in_RDX + 2);
    if (uVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x180196f6f;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x180196f87;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)(&stack0x00000030 + iVar8), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x180196f9d;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar8));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar8) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_50h + iVar8) = unaff_R14;
    if (uVar3 % ((uint64_t)(in_R8D != 0) + 2) == 0) {
        uVar11 = *(undefined8 *)(in_RCX + 0x3a0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x180197026;
        fcn.180224990(uVar11, 0x1804a94a0, 0x1bd8);
        *(undefined8 *)(in_RCX + 0x3a0) = 0;
        *(undefined8 *)(in_RCX + 0x3a8) = 0;
        if (in_R8D == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x180197189;
            fcn.180224990(0, 0x1804a9450, 0x1d9);
            *(undefined8 *)(in_RCX + 0x3a0) = 0;
            *(undefined8 *)(in_RCX + 0x3a8) = 0;
            iVar12 = *(int64_t *)(in_RDX + 2);
            if (iVar12 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801971b8;
                iVar10 = fcn.180223170(*(int64_t *)((int64_t)&var_18h + iVar8));
                *(int64_t *)(in_RCX + 0x3a0) = iVar10;
                if (iVar10 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801971c9;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801971e1;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)(&stack0x00000030 + iVar8), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar8));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801971f7;
                    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar8));
                    return 0;
                }
                *(int64_t *)(in_RCX + 0x3a8) = iVar12;
            }
        } else {
            uVar4 = *in_RDX;
            uVar5 = in_RDX[1];
            uVar6 = in_RDX[2];
            uVar7 = in_RDX[3];
            *(undefined4 *)((int64_t)&var_18h + iVar8) = uVar4;
            *(undefined4 *)((int64_t)&var_18h + iVar8 + 4) = uVar5;
            *(undefined4 *)((int64_t)&var_20h + iVar8) = uVar6;
            *(undefined4 *)((int64_t)&var_20h + iVar8 + 4) = uVar7;
            *(undefined4 *)((int64_t)&arg_28h + iVar8) = uVar4;
            *(undefined4 *)((int64_t)&arg_28h + iVar8 + 4) = uVar5;
            *(undefined4 *)(&stack0x00000030 + iVar8) = uVar6;
            *(undefined4 *)(&stack0x00000034 + iVar8) = uVar7;
            *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x18019706c;
            puVar9 = (undefined2 *)fcn.180224ed0(*(int64_t *)((int64_t)&var_18h + iVar8));
            *(undefined2 **)(in_RCX + 0x3a0) = puVar9;
            if (puVar9 == (undefined2 *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x180197080;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
                *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x180197098;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                              *(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)(&stack0x00000030 + iVar8), 
                              *(int64_t *)((int64_t)&arg_48h + iVar8));
                *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801970ae;
                fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar8));
                return 0;
            }
            iVar12 = *(int64_t *)((int64_t)&var_20h + iVar8);
            *(undefined8 *)(in_RCX + 0x3a8) = 0;
            if (iVar12 != 0) {
                pcVar13 = *(char **)((int64_t)&arg_28h + iVar8);
                do {
                    cVar2 = *pcVar13;
                    puVar1 = (undefined2 *)(pcVar13 + 1);
                    if (iVar12 - 1U < 2) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x180197119;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x180197131;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)(&stack0x00000030 + iVar8), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar8));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x180197147;
                        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar8));
                        uVar11 = *(undefined8 *)(in_RCX + 0x3a0);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x180197160;
                        fcn.180224990(uVar11, 0x1804a94a0, 0x1bf9);
                        *(undefined8 *)(in_RCX + 0x3a0) = 0;
                        *(undefined8 *)(in_RCX + 0x3a8) = 0;
                        return 0;
                    }
                    iVar12 = iVar12 + -3;
                    pcVar13 = pcVar13 + 3;
                    if (cVar2 == '\0') {
                        *puVar9 = *puVar1;
                        *(int64_t *)(in_RCX + 0x3a8) = *(int64_t *)(in_RCX + 0x3a8) + 2;
                    }
                    puVar9 = puVar9 + 1;
                } while (iVar12 != 0);
            }
        }
        uVar11 = 1;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x180196fd8;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x180196ff0;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)(&stack0x00000030 + iVar8), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x180197006;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar8));
        uVar11 = 0;
    }
    return uVar11;
}

