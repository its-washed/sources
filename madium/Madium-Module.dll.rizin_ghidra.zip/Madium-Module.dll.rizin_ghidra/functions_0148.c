// Chunk 148 - 50 functions

// ============================================================
// Function: FUN_1801f4d20
// Address: 0x1801f4d20
// Size: 281 bytes
// ============================================================
undefined8 fcn.1801f4d20(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined2 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t in_RCX;
    uint64_t in_RDX;
    uint32_t uVar6;
    uint64_t uVar8;
    uint64_t in_R8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    int64_t var_8h;
    uint64_t uVar7;
    
    uStack_30 = 0x1801f4d3c;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    uVar8 = 0;
    iVar2 = *(int32_t *)(in_RCX + 0x48);
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = 0;
    if (iVar2 != 0x300) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801f4d5e;
        uVar4 = func_0x0001801938c0();
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801f4d69;
        iVar2 = func_0x000180222010(uVar4);
        uVar7 = uVar8;
        if (0 < iVar2) {
            do {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801f4d7c;
                iVar5 = func_0x000180222340(uVar4, uVar7);
                if ((((*(uint8_t *)(iVar5 + 0x1c) & 0x84) != 0) || ((*(uint8_t *)(iVar5 + 0x20) & 8) != 0)) ||
                   (0x303 < *(int32_t *)(iVar5 + 0x2c))) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801f4dc0;
                    func_0x000180221d50(uVar4);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801f4dd2;
                    func_0x0001801ab620(in_RCX, (int64_t)&arg_38h + iVar3, (int64_t)&arg_50h + iVar3);
                    if (*(int64_t *)((int64_t)&arg_50h + iVar3) == 0) {
                        return 0;
                    }
                    do {
                        *(undefined8 *)(&stack0x00000000 + iVar3) = 0;
                        *(undefined4 *)((int64_t)&var_8h + iVar3) = 1;
                        uVar1 = *(undefined2 *)(*(int64_t *)((int64_t)&arg_38h + iVar3) + uVar8 * 2);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801f4e07;
                        iVar2 = func_0x0001801adc80(in_RCX, uVar1, in_RDX & 0xffffffff, in_R8 & 0xffffffff);
                        if (iVar2 != 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801f4e1c;
                            iVar2 = func_0x0001801ada30(in_RCX, uVar1, 0x20004);
                            if (iVar2 != 0) {
                                return 1;
                            }
                        }
                        uVar8 = uVar8 + 1;
                    } while (uVar8 < *(uint64_t *)((int64_t)&arg_50h + iVar3));
                    return 0;
                }
                uVar6 = (int32_t)uVar7 + 1;
                uVar7 = (uint64_t)uVar6;
            } while ((int32_t)uVar6 < iVar2);
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801f4d9f;
        func_0x000180221d50(uVar4);
    }
    return 0;
}

// ============================================================
// Function: FUN_1801f4e40
// Address: 0x1801f4e40
// Size: 700 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8
fcn.1801f4e40(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h,
             int64_t arg_78h, int64_t arg_90h, int64_t arg_98h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f4e56;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar2 = *(int32_t *)(in_RCX + 0x1c);
    if (*(int64_t *)((int64_t)&arg_90h + iVar3) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f4e79;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f4e91;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f4ea3;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f4ec3;
    iVar4 = fcn.180211490();
    *(int64_t *)(in_RCX + 0x1020) = iVar4;
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f4ed7;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f4eef;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f4f01;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f4f10;
    iVar5 = fcn.180215470();
    *(int64_t *)(in_RCX + 0x1038) = iVar5;
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f4f21;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f4f39;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f4f4b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f4f68;
    iVar1 = fcn.180214880(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                          *(int64_t *)((int64_t)&arg_68h + iVar3), *(int64_t *)((int64_t)&arg_70h + iVar3));
    if (iVar1 < 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f4f71;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f4f89;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f4f9b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0xfffffffe;
    }
    if (*(int64_t *)((int64_t)&arg_98h + iVar3) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f4fb7;
        iVar5 = fcn.180247740(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(int64_t *)(in_RCX + 0x1040) = iVar5;
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f4fc8;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f4fe0;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f4ff2;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            return 0xfffffffe;
        }
    }
    *(uint32_t *)((int64_t)&var_20h + iVar3) = (uint32_t)(iVar2 == 1);
    *(undefined8 *)((int64_t)&var_18h + iVar3) = *(undefined8 *)((int64_t)&arg_58h + iVar3);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f5023;
    iVar2 = fcn.180211b70(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                          *(int64_t *)((int64_t)&arg_68h + iVar3));
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f502c;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f5044;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f5056;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f5068;
    uVar6 = fcn.18020e940(iVar4);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f5070;
    iVar4 = fcn.18020eec0(uVar6);
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f508b;
        iVar2 = fcn.1801d5680(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                              *(int64_t *)((int64_t)&arg_48h + iVar3), *(int64_t *)(&stack0x00000050 + iVar3), 
                              *(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)((int64_t)&arg_70h + iVar3), 
                              *(int64_t *)((int64_t)&arg_78h + iVar3), *(int64_t *)(&stack0x00000088 + iVar3), 
                              *(int64_t *)((int64_t)&arg_98h + iVar3), *(int64_t *)(&stack0x000000a8 + iVar3));
        if (iVar2 == 0) {
            return 0xfffffffe;
        }
    }
    if (0x40 < *(uint64_t *)((int64_t)&arg_70h + iVar3)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f509f;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f50b7;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f50c9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f50e1;
    fcn.180498030(in_RCX + 0x1070, *(undefined8 *)((int64_t)&arg_68h + iVar3));
    return 1;
}

// ============================================================
// Function: FUN_1801f5100
// Address: 0x1801f5100
// Size: 704 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.1801f5100(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h,
             int64_t arg_98h, int64_t arg_d0h, int64_t arg_e8h, int64_t arg_f0h)
{
    int64_t iVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    undefined4 *puVar9;
    undefined8 *in_RCX;
    int64_t in_RDX;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t in_R8;
    int32_t in_R9D;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801f5122;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (in_R8 != 1) {
        return 0;
    }
    iVar11 = in_RCX[0x204];
    if (iVar11 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f5150;
    iVar7 = fcn.18020e940(iVar11);
    if (iVar7 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f5161;
    uVar8 = fcn.18020eec0(iVar7);
    uVar14 = *(uint64_t *)(in_RDX + 8);
    *(undefined8 *)((int64_t)&arg_d0h + iVar6) = uVar8;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f5178;
    iVar5 = func_0x00018020e950(iVar11);
    uVar13 = (uint64_t)iVar5;
    if (iVar5 == 0) {
        return 0;
    }
    if (uVar13 == 1) {
        if (in_R9D == 0) goto code_r0x0001801f524e;
code_r0x0001801f5263:
        iVar7 = *(int64_t *)((int64_t)&arg_d0h + iVar6);
code_r0x0001801f526b:
        uVar8 = *(undefined8 *)(in_RDX + 0x28);
        uVar10 = *(undefined8 *)(in_RDX + 0x20);
        if (iVar7 != 0) {
            *(int32_t *)(&stack0xfffffffffffffff8 + iVar6) = (int32_t)uVar14;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f5294;
            iVar5 = func_0x000180211bb0(iVar11, uVar10, (int64_t)&arg_d0h + iVar6, uVar8);
            if (iVar5 == 0) {
                return 0;
            }
            *(int64_t *)(in_RDX + 8) = (int64_t)*(int32_t *)((int64_t)&arg_d0h + iVar6);
            if (in_R9D != 0) {
                return 1;
            }
            iVar7 = *(int64_t *)((int64_t)&arg_e8h + iVar6);
            if (iVar7 == 0) {
                return 1;
            }
            uVar8 = *(undefined8 *)((int64_t)&arg_f0h + iVar6);
            *(undefined4 *)(iVar7 + 8) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f52dc;
            puVar9 = (undefined4 *)func_0x000180229c20((int64_t)&var_18h + iVar6, 0x1804b8258, iVar7, uVar8);
            uVar2 = puVar9[1];
            uVar3 = puVar9[2];
            uVar4 = puVar9[3];
            *(undefined4 *)((int64_t)&arg_48h + iVar6) = *puVar9;
            *(undefined4 *)((int64_t)&arg_48h + iVar6 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000050 + iVar6) = uVar3;
            *(undefined4 *)(&stack0x00000054 + iVar6) = uVar4;
            uVar2 = puVar9[5];
            uVar3 = puVar9[6];
            uVar4 = puVar9[7];
            *(undefined4 *)((int64_t)&arg_58h + iVar6) = puVar9[4];
            *(undefined4 *)((int64_t)&arg_58h + iVar6 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000060 + iVar6) = uVar3;
            *(undefined4 *)(&stack0x00000064 + iVar6) = uVar4;
            *(undefined8 *)((int64_t)&arg_68h + iVar6) = *(undefined8 *)(puVar9 + 8);
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f5308;
            puVar9 = (undefined4 *)func_0x000180229ba0((int64_t)&var_18h + iVar6);
            uVar2 = puVar9[1];
            uVar3 = puVar9[2];
            uVar4 = puVar9[3];
            *(undefined4 *)((int64_t)&arg_70h + iVar6) = *puVar9;
            *(undefined4 *)((int64_t)&arg_70h + iVar6 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000078 + iVar6) = uVar3;
            *(undefined4 *)(&stack0x0000007c + iVar6) = uVar4;
            uVar2 = puVar9[5];
            uVar3 = puVar9[6];
            uVar4 = puVar9[7];
            *(undefined4 *)((int64_t)&arg_80h + iVar6) = puVar9[4];
            *(undefined4 *)((int64_t)&arg_80h + iVar6 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000088 + iVar6) = uVar3;
            *(undefined4 *)(&stack0x0000008c + iVar6) = uVar4;
            *(undefined8 *)((int64_t)&arg_90h + iVar6) = *(undefined8 *)(puVar9 + 8);
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f533a;
            iVar5 = func_0x000180211450(iVar11, (int64_t)&arg_48h + iVar6);
            if (iVar5 != 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f5343;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f535b;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                          *(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)(&stack0x00000028 + iVar6));
            uVar8 = 0x50;
            goto code_r0x0001801f5219;
        }
    } else {
        if (in_R9D == 0) {
code_r0x0001801f524e:
            if (uVar14 == 0) {
                return 0;
            }
            if (uVar14 % uVar13 != 0) {
                return 0;
            }
            goto code_r0x0001801f5263;
        }
        iVar7 = *(int64_t *)((int64_t)&arg_d0h + iVar6);
        if (iVar7 != 0) goto code_r0x0001801f526b;
        iVar7 = *(int64_t *)(in_RDX + 0x28);
        iVar1 = *(int64_t *)(in_RDX + 8);
        iVar12 = uVar13 - uVar14 % uVar13;
        uVar14 = uVar14 + iVar12;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f51c9;
        fcn.1804986e0(iVar7 + iVar1, 0, iVar12);
        *(int64_t *)(in_RDX + 8) = *(int64_t *)(in_RDX + 8) + iVar12;
        *(char *)((uVar14 - 1) + *(int64_t *)(in_RDX + 0x28)) = (char)iVar12 + -1;
        uVar8 = *(undefined8 *)(in_RDX + 0x28);
        uVar10 = *(undefined8 *)(in_RDX + 0x20);
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f51eb;
    iVar5 = func_0x00018020f460(iVar11, uVar10, uVar8, uVar14 & 0xffffffff);
    if (0 < iVar5) {
        if (in_R9D != 0) {
            return 1;
        }
        uVar8 = *(undefined8 *)(in_RDX + 0x20);
        iVar11 = *(int64_t *)((int64_t)&arg_e8h + iVar6) + 8;
        if (*(int64_t *)((int64_t)&arg_e8h + iVar6) == 0) {
            iVar11 = 0;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar6) = *in_RCX;
        *(undefined8 *)((int64_t)&var_8h + iVar6) = *(undefined8 *)((int64_t)&arg_f0h + iVar6);
        *(uint64_t *)(&stack0x00000000 + iVar6) = uVar13;
        *(int64_t *)(&stack0xfffffffffffffff8 + iVar6) = iVar11;
        uVar10 = *(undefined8 *)(in_RDX + 0x10);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f53b1;
        uVar8 = func_0x0001802731d0(in_RDX + 8, uVar10, uVar8);
        return uVar8;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f51f9;
    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f5211;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                  *(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                  *(int64_t *)(&stack0x00000028 + iVar6));
    uVar8 = 0x14;
code_r0x0001801f5219:
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801f5227;
    func_0x0001801d5640(in_RCX, uVar8, 0xc0103, 0);
    return 0;
}

// ============================================================
// Function: FUN_1801f53c0
// Address: 0x1801f53c0
// Size: 747 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_1000h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1020h because it doesn't fit into ProtoModel

void fcn.1801f53c0(int64_t arg_28h, int64_t arg_38h, int64_t arg_88h, int64_t arg_f0h, int64_t arg_130h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    char cVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t iVar10;
    undefined *in_R8;
    int32_t in_R9D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_40;
    
    uStack_40 = 0x1801f53da;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_88h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar6);
    uVar8 = *(undefined8 *)(in_RCX + 0x1038);
    iVar1 = in_RCX + 0x1070;
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5411;
    iVar5 = func_0x00018020f590(uVar8);
    if (iVar5 < 1) goto code_r0x0001801f5680;
    *(int64_t *)((int64_t)&var_20h + iVar6) = (int64_t)iVar5;
    iVar10 = 0x30 - 0x30U % (uint64_t)(int64_t)iVar5;
    if (in_R9D == 0) {
        uVar7 = *(undefined8 *)(in_RCX + 0x1020);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5444;
        uVar7 = fcn.18020e940(uVar7);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f544c;
        iVar5 = func_0x00018020efb0(uVar7);
        if (iVar5 != 2) goto code_r0x0001801f5512;
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f545d;
        cVar4 = func_0x0001801d5830(uVar8);
        if (cVar4 == '\0') goto code_r0x0001801f5512;
        iVar9 = *(int64_t *)((int64_t)&var_20h + iVar6);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f547a;
        fcn.180498030((int64_t)&arg_38h + iVar6, iVar1, iVar9);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5491;
        fcn.180498030((int64_t)&arg_38h + iVar9 + iVar6, 0x1804b81c0, iVar10);
        iVar10 = iVar10 + iVar9;
        uVar7 = *(undefined8 *)(in_RDX + 8);
        uVar2 = *(undefined8 *)(in_RDX + 0x10);
        *(undefined8 *)(&stack0x00000068 + iVar10 + iVar6 + -0x30) = *(undefined8 *)(in_RCX + 0x1000);
        uVar3 = *(undefined8 *)(in_RDX + 0x28);
        (&stack0x00000070)[iVar10 + iVar6 + -0x30] = *(undefined *)(in_RDX + 4);
        (&stack0x00000071)[iVar10 + iVar6 + -0x30] = (char)((uint64_t)uVar7 >> 8);
        (&stack0x00000072)[iVar10 + iVar6 + -0x30] = (char)uVar7;
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f54cd;
        uVar8 = fcn.18020e940(uVar8);
        *(undefined *)((int64_t)&var_10h + iVar6) = 1;
        *(undefined8 *)((int64_t)&var_8h + iVar6) = *(undefined8 *)((int64_t)&var_20h + iVar6);
        *(int64_t *)(&stack0x00000000 + iVar6) = iVar1;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar6) = uVar2;
        *(undefined8 *)(&stack0xfffffffffffffff0 + iVar6) = uVar7;
        *(undefined8 *)(&stack0xffffffffffffffe8 + iVar6) = uVar3;
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5505;
        iVar5 = func_0x000180273440(uVar8, in_R8, (int64_t)&var_20h + iVar6, (int64_t)&arg_38h + iVar6);
        if (iVar5 < 1) goto code_r0x0001801f5680;
code_r0x0001801f5663:
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f566b;
        func_0x0001801d4800(in_RCX);
    } else {
code_r0x0001801f5512:
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5517;
        iVar9 = fcn.180215470();
        if (iVar9 == 0) goto code_r0x0001801f5680;
        *(undefined *)((int64_t)&var_18h + iVar6) = *(undefined *)(in_RDX + 4);
        *in_R8 = *(undefined *)(in_RDX + 9);
        in_R8[1] = *(undefined *)(in_RDX + 8);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5545;
        iVar5 = func_0x000180214b00(iVar9, uVar8);
        if (0 < iVar5) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f555d;
            iVar5 = func_0x0001802149b0(iVar9, iVar1, *(undefined8 *)((int64_t)&var_20h + iVar6));
            if (0 < iVar5) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5577;
                iVar5 = func_0x0001802149b0(iVar9, 0x1804b81c0, iVar10);
                if (0 < iVar5) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5594;
                    iVar5 = func_0x0001802149b0(iVar9, in_RCX + 0x1000, 8);
                    if (0 < iVar5) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f55af;
                        iVar5 = func_0x0001802149b0(iVar9, (int64_t)&var_18h + iVar6, 1);
                        if (0 < iVar5) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f55c8;
                            iVar5 = func_0x0001802149b0(iVar9, in_R8, 2);
                            if (0 < iVar5) {
                                uVar7 = *(undefined8 *)(in_RDX + 8);
                                uVar2 = *(undefined8 *)(in_RDX + 0x28);
                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f55e0;
                                iVar5 = func_0x0001802149b0(iVar9, uVar2, uVar7);
                                if (0 < iVar5) {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f55f6;
                                    iVar5 = func_0x0001802146d0(iVar9, in_R8, 0);
                                    if (0 < iVar5) {
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5605;
                                        iVar5 = func_0x000180214b00(iVar9, uVar8);
                                        if (0 < iVar5) {
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5619;
                                            iVar5 = func_0x0001802149b0(iVar9, iVar1, 
                                                                        *(undefined8 *)((int64_t)&var_20h + iVar6));
                                            if (0 < iVar5) {
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f562f;
                                                iVar5 = func_0x0001802149b0(iVar9, 0x1804b81f0, iVar10);
                                                if (0 < iVar5) {
                                                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5643;
                                                    iVar5 = func_0x0001802149b0(iVar9, in_R8, 
                                                                                *(undefined8 *)
                                                                                 ((int64_t)&var_20h + iVar6));
                                                    if (0 < iVar5) {
                                                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5657;
                                                        iVar5 = func_0x0001802146d0(iVar9, in_R8, 
                                                                                    (int64_t)&arg_28h + iVar6);
                                                        if (0 < iVar5) {
                                                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5663;
                                                            func_0x000180215310(iVar9);
                                                            goto code_r0x0001801f5663;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f567e;
        func_0x000180215310(iVar9);
    }
code_r0x0001801f5680:
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5690;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_88h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1801f56b0
// Address: 0x1801f56b0
// Size: 91 bytes
// ============================================================
bool fcn.1801f56b0(int64_t param_1, char *param_2, int64_t param_3, int64_t *param_4)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f56bc;
    iVar2 = fcn.18045a350();
    if ((*(int32_t *)(param_1 + 0x1018) == 0) || (iVar3 = 1, *param_2 != '\x17')) {
        iVar3 = 0;
    }
    *param_4 = iVar3;
    *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1801f56fe;
    iVar1 = func_0x0001801d79c0(param_1, iVar3 + param_3, -(uint32_t)(iVar3 != 0) & 0x45c, 0);
    return iVar1 != 0;
}

// ============================================================
// Function: FUN_1801f5710
// Address: 0x1801f5710
// Size: 392 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.1801f5710(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
             int64_t arg_78h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    char *in_RDX;
    int64_t iVar8;
    undefined8 in_R8;
    undefined *in_R9;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f5734;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    puVar1 = *(undefined8 **)((int64_t)&arg_78h + iVar6);
    puVar2 = *(undefined8 **)((int64_t)&arg_70h + iVar6);
    if ((*(int32_t *)(in_RCX + 0x1018) == 0) || (*in_RDX != '\x17')) {
        iVar8 = 0;
    } else {
        uVar7 = *(undefined8 *)((int64_t)&arg_68h + iVar6);
        *(undefined8 *)(in_R9 + 8) = 0;
        iVar8 = 1;
        *(undefined4 *)(in_R9 + 4) = *(undefined4 *)(in_RDX + 4);
        *(undefined8 *)(in_R9 + 0x10) = 0;
        *in_R9 = 0x17;
        uVar3 = *puVar2;
        uVar4 = puVar2[2];
        iVar9 = 7 - (uint64_t)((int32_t)uVar3 - 4U & 7);
        puVar2[3] = iVar9;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f57b1;
        iVar5 = func_0x000180244550(uVar7, uVar3, uVar4, 0);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f57ba;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f57d2;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                          *(int64_t *)(&stack0x00000038 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f57e8;
            func_0x0001801d5640(in_RCX, 0x50, 0xc0103, 0);
            return 0;
        }
        uVar7 = *(undefined8 *)((int64_t)&arg_68h + iVar6);
        *puVar1 = 1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f5805;
        iVar5 = func_0x000180243f60(uVar7, iVar9, 0);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f580e;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f5826;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                          *(int64_t *)(&stack0x00000038 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f583c;
            func_0x0001801d5640(in_RCX, 0x50, 0xc0103, 0);
            return 0;
        }
    }
    *(undefined8 **)((int64_t)&var_18h + iVar6) = puVar1;
    *(undefined8 **)((int64_t)&var_10h + iVar6) = puVar2 + iVar8 * 6;
    *(int64_t *)((int64_t)&var_8h + iVar6) = iVar8 * 0x38 + *(int64_t *)((int64_t)&arg_68h + iVar6);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f5879;
    uVar7 = func_0x0001801d6ca0(in_RCX, in_RDX, in_R8, 0);
    return uVar7;
}

// ============================================================
// Function: FUN_1801f58a0
// Address: 0x1801f58a0
// Size: 1375 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8
fcn.1801f58a0(int64_t placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h,
             int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h)
{
    undefined8 uVar1;
    uint32_t uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_40;
    int64_t var_10h;
    
    uStack_40 = 0x1801f58bf;
    var_18h = arg3;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar4 = (uint32_t)(*(int32_t *)(placeholder_0 + 0x1c) == 1);
    *(uint32_t *)((int64_t)&arg_50h + iVar6) = uVar4;
    if ((int32_t)placeholder_1 != 3) {
        return 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f58e6;
    iVar7 = fcn.180211490();
    *(int64_t *)(placeholder_0 + 0x1020) = iVar7;
    if (iVar7 == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f58fa;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5912;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20)
                      , *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
    } else {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f594a;
        iVar8 = fcn.180215470();
        *(int64_t *)(placeholder_0 + 0x1038) = iVar8;
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f595b;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5973;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
        } else {
            if (*(int64_t *)((int64_t)&arg_a8h + iVar6) != 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5995;
                iVar8 = fcn.180247740(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6));
                *(int64_t *)(placeholder_0 + 0x1040) = iVar8;
                if (iVar8 == 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f59a6;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f59be;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f59d0;
                    fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8));
                    return 0xfffffffe;
                }
            }
            uVar9 = *(undefined8 *)((int64_t)&arg_88h + iVar6);
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f59e5;
            uVar2 = fcn.18020ef80(uVar9);
            if ((uVar2 >> 0x15 & 1) == 0) {
                if (*(int32_t *)((int64_t)&arg_98h + iVar6) == 0x357) {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + iVar6) = *(undefined8 *)((int64_t)&arg_80h + iVar6);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5a29;
                    iVar8 = fcn.18022fea0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                          *(int64_t *)((int64_t)&var_10h + iVar6), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                          *(int64_t *)(&stack0x00000030 + iVar6));
                } else {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5a35;
                    iVar8 = fcn.18025acf0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                          *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8));
                }
                if (iVar8 == 0) {
code_r0x0001801f5b2a:
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5b32;
                    fcn.18022ecc0(iVar8);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5b37;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5b4f;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5b61;
                    fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8));
                    return 0xfffffffe;
                }
                uVar1 = *(undefined8 *)(placeholder_0 + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5a5c;
                fcn.18020f750(*(undefined8 *)((int64_t)&arg_a0h + iVar6));
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar6) = 0;
                *(int64_t *)((int64_t)&var_10h + iVar6) = iVar8;
                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar6) = uVar1;
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5a7b;
                iVar3 = fcn.18025c2e0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                      *(int64_t *)((int64_t)&var_10h + iVar6), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                      *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar6));
                if (iVar3 < 1) goto code_r0x0001801f5b2a;
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5a8b;
                fcn.18022ecc0(iVar8);
                uVar4 = *(uint32_t *)((int64_t)&arg_50h + iVar6);
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5aaa;
            iVar3 = fcn.18020efb0(uVar9);
            if (iVar3 == 6) {
                *(uint32_t *)((int64_t)&var_10h + iVar6) = uVar4;
                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar6) = 0;
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5acd;
                iVar3 = fcn.180211b70(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                      *(int64_t *)((int64_t)&var_10h + iVar6), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6));
                if (iVar3 == 0) {
code_r0x0001801f5af6:
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5afb;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5b13;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5b25;
                    fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8));
                    return 0xfffffffe;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5aee;
                iVar3 = fcn.180210b80(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
                if (iVar3 < 1) goto code_r0x0001801f5af6;
            } else {
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5b6e;
                iVar3 = fcn.18020efb0(uVar9);
                *(uint32_t *)((int64_t)&var_10h + iVar6) = uVar4;
                if (iVar3 == 7) {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + iVar6) = 0;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5b91;
                    iVar3 = fcn.180211b70(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                          *(int64_t *)((int64_t)&var_10h + iVar6), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                          *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6)
                                         );
                    if (iVar3 == 0) {
code_r0x0001801f5c0d:
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5c12;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                      *(int64_t *)((int64_t)&var_10h + iVar6));
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5c2a;
                        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                      *(int64_t *)((int64_t)&var_10h + iVar6), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5c3c;
                        fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8));
                        return 0xfffffffe;
                    }
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5bab;
                    iVar3 = fcn.180210b80(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                          *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
                    if (iVar3 < 1) goto code_r0x0001801f5c0d;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5bc7;
                    iVar3 = fcn.180210b80(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                          *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
                    if (iVar3 < 1) goto code_r0x0001801f5c0d;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5be8;
                    iVar3 = fcn.180210b80(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                          *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
                    if (iVar3 < 1) goto code_r0x0001801f5c0d;
                    *(uint32_t *)((int64_t)&var_10h + iVar6) = uVar4;
                    *(undefined8 *)(&stack0xffffffffffffffe8 + iVar6) = 0;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5c05;
                    iVar3 = fcn.180211b70(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                          *(int64_t *)((int64_t)&var_10h + iVar6), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                          *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6)
                                         );
                    if (iVar3 == 0) goto code_r0x0001801f5c0d;
                } else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + iVar6) = *(undefined8 *)((int64_t)&arg_68h + iVar6);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5c56;
                    iVar3 = fcn.180211b70(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                          *(int64_t *)((int64_t)&var_10h + iVar6), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                          *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6)
                                         );
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5c5f;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                      *(int64_t *)((int64_t)&var_10h + iVar6));
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5c77;
                        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                      *(int64_t *)((int64_t)&var_10h + iVar6), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5c89;
                        fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8));
                        return 0xfffffffe;
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5c96;
            uVar4 = fcn.18020ef80(uVar9);
            if (((uVar4 >> 0x15 & 1) != 0) && (*(int64_t *)((int64_t)&arg_80h + iVar6) != 0)) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5cbc;
                iVar3 = fcn.180210b80(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
                if (iVar3 < 1) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5cc5;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5cdd;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5cef;
                    fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8));
                    return 0xfffffffe;
                }
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5cfc;
            uVar9 = fcn.18020e940(iVar7);
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5d04;
            iVar8 = fcn.18020eec0(uVar9);
            if (iVar8 != 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5d1f;
                iVar3 = fcn.1801d5680(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6)
                                      , *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6)
                                      , *(int64_t *)((int64_t)&arg_58h + iVar6), *(int64_t *)((int64_t)&arg_68h + iVar6)
                                      , *(int64_t *)((int64_t)&arg_78h + iVar6));
                if (iVar3 == 0) {
                    return 0xfffffffe;
                }
            }
            iVar3 = *(int32_t *)(placeholder_0 + 0x14);
            if ((((iVar3 != 0x302) && (iVar3 != 0x303)) && (iVar3 != 0x100)) && ((iVar3 != 0xfeff && (iVar3 != 0xfefd)))
               ) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5d5a;
            uVar9 = fcn.18020e940(iVar7);
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5d62;
            iVar5 = fcn.18020efb0(uVar9);
            iVar3 = 0;
            if (iVar5 != 2) {
                if (iVar5 != 6) {
                    if (iVar5 == 7) {
                        iVar3 = 8;
                    }
                    *(int64_t *)(placeholder_0 + 0x1030) = (int64_t)iVar3;
                    return 1;
                }
                *(undefined8 *)(placeholder_0 + 0x1030) = 8;
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5d71;
            iVar5 = fcn.18020e980(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                                  *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                                  *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar6), *(int64_t *)((int64_t)&arg_68h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar6), *(int64_t *)(&stack0x000000b8 + iVar6), 
                                  *(int64_t *)(&stack0x00000118 + iVar6), *(int64_t *)(&stack0x00000120 + iVar6));
            if (-1 < iVar5) {
                if (1 < iVar5) {
                    iVar3 = iVar5;
                }
                *(int64_t *)(placeholder_0 + 0x1030) = (int64_t)iVar3;
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5d7a;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5d92;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
        }
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f5928;
    fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_10 + iVar6));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_1801f5e00
// Address: 0x1801f5e00
// Size: 250 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Removing arg arg_4a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_500h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_49h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ah
// WARNING: [rz-ghidra] Detected overlap for variable arg_4eh

void fcn.1801f5e00(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined2 uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined4 *puVar13;
    undefined8 uVar14;
    undefined8 *in_RCX;
    uint64_t uVar15;
    uint64_t uVar16;
    int64_t in_RDX;
    undefined *puVar17;
    int64_t *piVar18;
    undefined8 unaff_RSI;
    uint64_t uVar19;
    uint64_t in_R8;
    uint64_t uVar20;
    int32_t in_R9D;
    undefined8 unaff_R12;
    uint64_t uVar21;
    int64_t iVar22;
    int64_t iVar23;
    undefined8 unaff_R14;
    int64_t *piVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_488h;
    int64_t var_480h;
    int64_t var_478h;
    int64_t var_468h;
    undefined4 uStack_460;
    undefined4 uStack_45c;
    int64_t var_458h;
    undefined4 uStack_450;
    undefined4 uStack_44c;
    int64_t var_448h;
    int64_t var_440h;
    undefined4 uStack_438;
    undefined4 uStack_434;
    int64_t var_430h;
    undefined4 uStack_428;
    undefined4 uStack_424;
    int64_t var_420h;
    int64_t var_418h;
    int64_t var_3e8h;
    int64_t var_2e8h;
    int64_t var_1dfh;
    int64_t var_48h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801f5e1a;
    iVar10 = fcn.18045a350();
    iVar22 = arg_30h;
    iVar23 = arg_28h;
    iVar10 = -iVar10;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar10);
    var_488h = arg_28h;
    var_480h = arg_30h;
    *(int32_t *)((int64_t)&arg_28h + iVar10) = in_R9D;
    *(undefined4 *)((int64_t)&arg_28h + iVar10 + 4) = 0;
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5e6a;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5e82;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5e98;
        fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar10));
        goto code_r0x0001801f605a;
    }
    uVar14 = in_RCX[0x207];
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5eab;
    iVar11 = fcn.18020e940(uVar14);
    if (iVar11 != 0) {
        uVar14 = in_RCX[0x207];
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5ebc;
        iVar6 = func_0x00018020f590(uVar14);
        if (iVar6 < 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5ec5;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5edd;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5ef3;
            fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar10));
            goto code_r0x0001801f605a;
        }
    }
    *(undefined8 *)(&stack0x000004a8 + iVar10) = unaff_R14;
    iVar11 = in_RCX[0x204];
    *(int64_t *)((int64_t)&arg_30h + iVar10) = iVar11;
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5f18;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5f30;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5f46;
        fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar10));
        goto code_r0x0001801f605a;
    }
    *(undefined8 *)(&stack0x00000500 + iVar10) = unaff_RSI;
    *(undefined8 *)(&stack0x000004b0 + iVar10) = unaff_R12;
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5f65;
    iVar12 = fcn.18020e940(iVar11);
    *(int64_t *)((int64_t)&arg_50h + iVar10) = iVar12;
    if ((in_R9D != 0) &&
       ((((iVar6 = *(int32_t *)((int64_t)in_RCX + 0x14), iVar6 == 0x302 || (iVar6 == 0x303)) || (iVar6 == 0x100)) ||
        ((iVar6 == 0xfeff || (iVar6 == 0xfefd)))))) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5fa8;
        iVar6 = fcn.18020efb0(iVar12);
        if (iVar6 == 2) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5fb5;
            iVar6 = func_0x00018020ef90(iVar12);
            if ((1 < iVar6) && (uVar19 = 0, in_R8 != 0)) {
                piVar18 = (int64_t *)(in_RDX + 0x20);
                do {
                    iVar11 = piVar18[1];
                    if (*piVar18 != iVar11) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6090;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                        goto code_r0x0001801f601e;
                    }
                    uVar14 = *in_RCX;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5feb;
                    iVar7 = func_0x00018021b9c0(uVar14, iVar11, (int64_t)iVar6, 0);
                    if (iVar7 < 1) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f607d;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                        goto code_r0x0001801f601e;
                    }
                    uVar19 = uVar19 + 1;
                    piVar18 = piVar18 + 9;
                } while (uVar19 < in_R8);
            }
            iVar11 = *(int64_t *)((int64_t)&arg_30h + iVar10);
        }
    }
    if (iVar12 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6012;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
code_r0x0001801f601e:
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f602a;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60a6;
        iVar12 = fcn.18020eec0(iVar12);
        *(int64_t *)((int64_t)&arg_40h + iVar10) = iVar12;
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60b6;
        fcn.18020e940(iVar11);
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60be;
        iVar6 = func_0x00018020ef70();
        uVar19 = (uint64_t)iVar6;
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60ca;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60e2;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
        } else {
            if (in_R8 < 2) {
code_r0x0001801f6131:
                uVar21 = 0;
                if (in_R8 != 0) {
                    piVar24 = &var_1dfh;
                    *(int64_t **)((int64_t)&arg_38h + iVar10) = piVar24;
                    piVar18 = (int64_t *)(in_RDX + 8);
                    do {
                        uVar14 = *(undefined8 *)((int64_t)&arg_30h + iVar10);
                        (&var_3e8h)[uVar21] = *piVar18;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6162;
                        fcn.18020e940(uVar14);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f616a;
                        uVar8 = fcn.18020ef80();
                        if ((uVar8 >> 0x15 & 1) == 0) {
                            if (uVar19 == 1) {
                                *(undefined4 *)((int64_t)&arg_28h + iVar10 + 4) =
                                     *(undefined4 *)((int64_t)&arg_28h + iVar10 + 4);
                                if (*(int32_t *)((int64_t)&arg_28h + iVar10) == 0) goto code_r0x0001801f62c9;
                            } else if (*(int32_t *)((int64_t)&arg_28h + iVar10) == 0) {
code_r0x0001801f62c9:
                                if (((&var_3e8h)[uVar21] == 0) || ((uint64_t)(&var_3e8h)[uVar21] % uVar19 != 0))
                                goto code_r0x0001801f605a;
                            } else if (*(int64_t *)((int64_t)&arg_40h + iVar10) == 0) {
                                uVar16 = (&var_3e8h)[uVar21];
                                uVar20 = uVar19 - uVar16 % uVar19;
                                if (0x100 < uVar20) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f637c;
                                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                                    goto code_r0x0001801f601e;
                                }
                                uVar15 = uVar16;
                                if (uVar16 < uVar16 + uVar20) {
                                    do {
                                        *(char *)(uVar15 + piVar18[4]) = (char)uVar20 + -1;
                                        uVar15 = uVar15 + 1;
                                        uVar16 = (&var_3e8h)[uVar21];
                                    } while (uVar15 < uVar16 + uVar20);
                                }
                                *piVar18 = *piVar18 + uVar20;
                                (&var_3e8h)[uVar21] = uVar16 + uVar20;
                            }
                        } else {
                            puVar17 = *(undefined **)((int64_t)&arg_38h + iVar10);
                            if (*(int32_t *)(in_RCX + 2) == 0) {
                                *(undefined8 *)(puVar17 + -9) = in_RCX[0x200];
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f61c8;
                                iVar6 = func_0x0001801d4800(in_RCX);
                                if (iVar6 == 0) goto code_r0x0001801f605a;
                                puVar17 = *(undefined **)((int64_t)&arg_38h + iVar10);
                            } else {
                                uVar1 = *(undefined2 *)(in_RCX + 6);
                                *(char *)((int64_t)&arg_48h + iVar10 + 1) = (char)uVar1;
                                *(char *)((int64_t)&arg_48h + iVar10) = (char)((uint16_t)uVar1 >> 8);
                                *(undefined4 *)((int64_t)&arg_48h + iVar10 + 2) =
                                     *(undefined4 *)((int64_t)in_RCX + 0x1002);
                                *(undefined2 *)((int64_t)&arg_48h + iVar10 + 6) =
                                     *(undefined2 *)((int64_t)in_RCX + 0x1006);
                                *(undefined8 *)(puVar17 + -9) = *(undefined8 *)((int64_t)&arg_48h + iVar10);
                            }
                            uVar2 = *(undefined4 *)((int64_t)in_RCX + 0x14);
                            puVar17[-1] = *(undefined *)((int64_t)piVar18 + -4);
                            puVar17[1] = (char)uVar2;
                            iVar11 = *piVar18;
                            *puVar17 = (char)((uint32_t)uVar2 >> 8);
                            puVar17[3] = (char)iVar11;
                            puVar17[2] = (char)((uint64_t)iVar11 >> 8);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6211;
                            iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar10));
                            *(int32_t *)((int64_t)&arg_28h + iVar10 + 4) = iVar6;
                            if (iVar6 < 1) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6366;
                                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                                goto code_r0x0001801f601e;
                            }
                            piVar24 = *(int64_t **)((int64_t)&arg_38h + iVar10);
                            if (*(int32_t *)((int64_t)&arg_28h + iVar10) == 0) goto code_r0x0001801f62c9;
                            (&var_3e8h)[uVar21] = (&var_3e8h)[uVar21] + (int64_t)iVar6;
                            *piVar18 = *piVar18 + (int64_t)iVar6;
                        }
                        piVar24 = (int64_t *)((int64_t)piVar24 + 0xd);
                        uVar21 = uVar21 + 1;
                        piVar18 = piVar18 + 9;
                        *(int64_t **)((int64_t)&arg_38h + iVar10) = piVar24;
                    } while (uVar21 < in_R8);
                    iVar11 = *(int64_t *)((int64_t)&arg_30h + iVar10);
                    iVar12 = *(int64_t *)((int64_t)&arg_40h + iVar10);
                }
                if (in_R8 < 2) {
code_r0x0001801f63f9:
                    iVar6 = *(int32_t *)((int64_t)&arg_28h + iVar10);
                    if ((*(int32_t *)(in_RCX + 2) == 0) && (*(int32_t *)(in_RCX + 0x217) != 0)) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6439;
                        iVar7 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar10));
                        if (iVar7 < 1) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6442;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                            goto code_r0x0001801f601e;
                        }
                    }
                    if (iVar12 == 0) {
                        uVar14 = *(undefined8 *)(in_RDX + 0x20);
                        piVar18 = (int64_t *)(in_RDX + 0x20);
                        uVar4 = *(undefined8 *)(in_RDX + 0x28);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f65c5;
                        uVar8 = func_0x00018020f460(iVar11, uVar14, uVar4, (undefined4)var_3e8h);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f65d2;
                        uVar14 = fcn.18020e940(*(undefined8 *)((int64_t)&arg_30h + iVar10));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f65da;
                        uVar9 = fcn.18020ef80(uVar14);
                        if ((uVar9 >> 0x14 & 1) == 0) {
                            uVar8 = (uint32_t)(uVar8 == 0);
                        } else {
                            uVar8 = uVar8 >> 0x1f;
                        }
                        if (((uVar8 == 0) && (iVar6 == 0)) &&
                           (*(undefined8 *)((int64_t)&arg_40h + iVar10) = 0, var_478h = in_R8, in_R8 != 0)) {
                            do {
                                uVar14 = *(undefined8 *)((int64_t)&arg_50h + iVar10);
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f662d;
                                iVar6 = fcn.18020efb0(uVar14);
                                if (iVar6 == 6) {
                                    *piVar18 = *piVar18 + 8;
                                    piVar18[1] = piVar18[1] + 8;
                                    piVar18[-3] = piVar18[-3] + -8;
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f664a;
                                    iVar6 = fcn.18020efb0(uVar14);
                                    if (iVar6 == 7) {
                                        *piVar18 = *piVar18 + 8;
                                        piVar18[1] = piVar18[1] + 8;
                                        piVar18[-3] = piVar18[-3] + -8;
                                    } else if ((uVar19 != 1) &&
                                              (((iVar6 = *(int32_t *)((int64_t)in_RCX + 0x14), iVar6 == 0x302 ||
                                                (iVar6 == 0x303)) ||
                                               ((iVar6 == 0x100 || ((iVar6 == 0xfeff || (iVar6 == 0xfefd)))))))) {
                                        if ((uint64_t)piVar18[-3] < uVar19) break;
                                        *piVar18 = *piVar18 + uVar19;
                                        piVar18[1] = piVar18[1] + uVar19;
                                        piVar18[-2] = piVar18[-2] - uVar19;
                                        piVar18[-3] = piVar18[-3] - uVar19;
                                    }
                                }
                                iVar6 = *(int32_t *)((int64_t)&arg_28h + iVar10 + 4);
                                iVar22 = (int64_t)iVar6;
                                if (iVar6 == 0) {
                                    iVar22 = var_480h;
                                }
                                if (var_488h == 0) {
                                    iVar11 = 0;
                                    iVar12 = 0;
                                } else {
                                    iVar11 = iVar23 + 8;
                                    iVar12 = iVar23;
                                }
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f66d8;
                                uVar8 = fcn.18020ef80(*(undefined8 *)((int64_t)&arg_50h + iVar10));
                                iVar3 = *piVar18;
                                *(undefined8 *)((int64_t)&iStackX_20 + iVar10 + -8) = *in_RCX;
                                *(uint32_t *)((int64_t)&var_10h + iVar10) = (uint32_t)((uVar8 >> 0x15 & 1) != 0);
                                iVar5 = piVar18[-2];
                                *(int64_t *)((int64_t)&var_8h + iVar10) = iVar22;
                                *(uint64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20) = uVar19;
                                *(int64_t *)(&stack0xfffffffffffffff8 + iVar10) = iVar11;
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6712;
                                iVar6 = func_0x0001802732b0(piVar18 + -3, iVar5, iVar3, iVar12);
                                if (iVar6 == 0) break;
                                iVar23 = iVar23 + 0x10;
                                uVar21 = *(int64_t *)((int64_t)&arg_40h + iVar10) + 1;
                                piVar18 = piVar18 + 9;
                                *(uint64_t *)((int64_t)&arg_40h + iVar10) = uVar21;
                            } while (uVar21 < (uint64_t)var_478h);
                        }
                        goto code_r0x0001801f605a;
                    }
                    if (in_R8 < 2) {
                        uVar14 = *(undefined8 *)(in_RDX + 0x28);
                        uVar4 = *(undefined8 *)(in_RDX + 0x20);
                        *(undefined4 *)(&stack0xfffffffffffffff8 + iVar10) = (undefined4)var_3e8h;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6494;
                        iVar7 = func_0x000180211bb0(iVar11, uVar4, (int64_t)&arg_28h + iVar10 + 4, uVar14);
                        if ((iVar7 == 0) ||
                           (*(int64_t *)(in_RDX + 8) = (int64_t)*(int32_t *)((int64_t)&arg_28h + iVar10 + 4), iVar6 != 0
                           )) goto code_r0x0001801f605a;
                        uVar14 = *(undefined8 *)((int64_t)&arg_50h + iVar10);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f64bb;
                        iVar6 = fcn.18020efb0(uVar14);
                        if (iVar6 == 6) {
                            *(int64_t *)(in_RDX + 0x20) = *(int64_t *)(in_RDX + 0x20) + 8;
                            *(int64_t *)(in_RDX + 0x28) = *(int64_t *)(in_RDX + 0x28) + 8;
                        } else {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f64d4;
                            iVar6 = fcn.18020efb0(uVar14);
                            if (iVar6 == 7) {
                                *(int64_t *)(in_RDX + 0x20) = *(int64_t *)(in_RDX + 0x20) + 8;
                                *(int64_t *)(in_RDX + 0x28) = *(int64_t *)(in_RDX + 0x28) + 8;
                            } else if ((uVar19 != 1) &&
                                      ((((iVar6 = *(int32_t *)((int64_t)in_RCX + 0x14), iVar6 == 0x302 ||
                                         (iVar6 == 0x303)) || (iVar6 == 0x100)) ||
                                       ((iVar6 == 0xfeff || (iVar6 == 0xfefd)))))) {
                                *(int64_t *)(in_RDX + 0x20) = *(int64_t *)(in_RDX + 0x20) + uVar19;
                                *(int64_t *)(in_RDX + 0x28) = *(int64_t *)(in_RDX + 0x28) + uVar19;
                                *(int64_t *)(in_RDX + 0x10) = *(int64_t *)(in_RDX + 0x10) - uVar19;
                            }
                        }
                        if (iVar23 == 0) goto code_r0x0001801f605a;
                        *(undefined4 *)(iVar23 + 8) = 0;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6548;
                        puVar13 = (undefined4 *)func_0x000180229c20(&var_418h, 0x1804b8258, iVar23, iVar22);
                        var_468h._0_4_ = *puVar13;
                        var_468h._4_4_ = puVar13[1];
                        uStack_460 = puVar13[2];
                        uStack_45c = puVar13[3];
                        var_458h._0_4_ = puVar13[4];
                        var_458h._4_4_ = puVar13[5];
                        uStack_450 = puVar13[6];
                        uStack_44c = puVar13[7];
                        var_448h = *(int64_t *)(puVar13 + 8);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f656a;
                        puVar13 = (undefined4 *)func_0x000180229ba0(&var_418h);
                        var_440h._0_4_ = *puVar13;
                        var_440h._4_4_ = puVar13[1];
                        uStack_438 = puVar13[2];
                        uStack_434 = puVar13[3];
                        var_430h._0_4_ = puVar13[4];
                        var_430h._4_4_ = puVar13[5];
                        uStack_428 = puVar13[6];
                        uStack_424 = puVar13[7];
                        var_420h = *(int64_t *)(puVar13 + 8);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f658f;
                        iVar6 = func_0x000180211450(iVar11, &var_468h);
                        if (iVar6 != 0) goto code_r0x0001801f605a;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f659c;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6467;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                    }
                    goto code_r0x0001801f601e;
                }
                uVar21 = 0;
                piVar18 = (int64_t *)(in_RDX + 0x20);
                do {
                    iVar3 = *piVar18;
                    piVar18 = piVar18 + 9;
                    (&var_2e8h)[uVar21] = iVar3;
                    uVar21 = uVar21 + 1;
                } while (uVar21 < in_R8);
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f634e;
                iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar10));
                if (iVar6 < 1) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6357;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                } else {
                    uVar21 = 0;
                    piVar18 = (int64_t *)(in_RDX + 0x28);
                    do {
                        iVar3 = *piVar18;
                        piVar18 = piVar18 + 9;
                        (&var_2e8h)[uVar21] = iVar3;
                        uVar21 = uVar21 + 1;
                    } while (uVar21 < in_R8);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f63ce;
                    iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar10));
                    if (0 < iVar6) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f63e6;
                        iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar10));
                        if (0 < iVar6) goto code_r0x0001801f63f9;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f63ef;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60fb;
                fcn.18020e940(iVar11);
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6103;
                uVar8 = fcn.18020ef80();
                if ((uVar8 >> 0x17 & 1) != 0) goto code_r0x0001801f6131;
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f610e;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6126;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6040;
    fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar10));
code_r0x0001801f605a:
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6069;
    func_0x000180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar10));
    return;
}

// ============================================================
// Function: FUN_1801f5efa
// Address: 0x1801f5efa
// Size: 83 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Removing arg arg_4a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_500h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_49h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ah
// WARNING: [rz-ghidra] Detected overlap for variable arg_4eh

void fcn.1801f5e00(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined2 uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined4 *puVar13;
    undefined8 uVar14;
    undefined8 *in_RCX;
    uint64_t uVar15;
    uint64_t uVar16;
    int64_t in_RDX;
    undefined *puVar17;
    int64_t *piVar18;
    undefined8 unaff_RSI;
    uint64_t uVar19;
    uint64_t in_R8;
    uint64_t uVar20;
    int32_t in_R9D;
    undefined8 unaff_R12;
    uint64_t uVar21;
    int64_t iVar22;
    int64_t iVar23;
    undefined8 unaff_R14;
    int64_t *piVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_488h;
    int64_t var_480h;
    int64_t var_478h;
    int64_t var_468h;
    undefined4 uStack_460;
    undefined4 uStack_45c;
    int64_t var_458h;
    undefined4 uStack_450;
    undefined4 uStack_44c;
    int64_t var_448h;
    int64_t var_440h;
    undefined4 uStack_438;
    undefined4 uStack_434;
    int64_t var_430h;
    undefined4 uStack_428;
    undefined4 uStack_424;
    int64_t var_420h;
    int64_t var_418h;
    int64_t var_3e8h;
    int64_t var_2e8h;
    int64_t var_1dfh;
    int64_t var_48h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801f5e1a;
    iVar10 = fcn.18045a350();
    iVar22 = arg_30h;
    iVar23 = arg_28h;
    iVar10 = -iVar10;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar10);
    var_488h = arg_28h;
    var_480h = arg_30h;
    *(int32_t *)((int64_t)&arg_28h + iVar10) = in_R9D;
    *(undefined4 *)((int64_t)&arg_28h + iVar10 + 4) = 0;
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5e6a;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5e82;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5e98;
        fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar10));
        goto code_r0x0001801f605a;
    }
    uVar14 = in_RCX[0x207];
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5eab;
    iVar11 = fcn.18020e940(uVar14);
    if (iVar11 != 0) {
        uVar14 = in_RCX[0x207];
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5ebc;
        iVar6 = func_0x00018020f590(uVar14);
        if (iVar6 < 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5ec5;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5edd;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5ef3;
            fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar10));
            goto code_r0x0001801f605a;
        }
    }
    *(undefined8 *)(&stack0x000004a8 + iVar10) = unaff_R14;
    iVar11 = in_RCX[0x204];
    *(int64_t *)((int64_t)&arg_30h + iVar10) = iVar11;
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5f18;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5f30;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5f46;
        fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar10));
        goto code_r0x0001801f605a;
    }
    *(undefined8 *)(&stack0x00000500 + iVar10) = unaff_RSI;
    *(undefined8 *)(&stack0x000004b0 + iVar10) = unaff_R12;
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5f65;
    iVar12 = fcn.18020e940(iVar11);
    *(int64_t *)((int64_t)&arg_50h + iVar10) = iVar12;
    if ((in_R9D != 0) &&
       ((((iVar6 = *(int32_t *)((int64_t)in_RCX + 0x14), iVar6 == 0x302 || (iVar6 == 0x303)) || (iVar6 == 0x100)) ||
        ((iVar6 == 0xfeff || (iVar6 == 0xfefd)))))) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5fa8;
        iVar6 = fcn.18020efb0(iVar12);
        if (iVar6 == 2) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5fb5;
            iVar6 = func_0x00018020ef90(iVar12);
            if ((1 < iVar6) && (uVar19 = 0, in_R8 != 0)) {
                piVar18 = (int64_t *)(in_RDX + 0x20);
                do {
                    iVar11 = piVar18[1];
                    if (*piVar18 != iVar11) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6090;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                        goto code_r0x0001801f601e;
                    }
                    uVar14 = *in_RCX;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5feb;
                    iVar7 = func_0x00018021b9c0(uVar14, iVar11, (int64_t)iVar6, 0);
                    if (iVar7 < 1) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f607d;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                        goto code_r0x0001801f601e;
                    }
                    uVar19 = uVar19 + 1;
                    piVar18 = piVar18 + 9;
                } while (uVar19 < in_R8);
            }
            iVar11 = *(int64_t *)((int64_t)&arg_30h + iVar10);
        }
    }
    if (iVar12 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6012;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
code_r0x0001801f601e:
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f602a;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60a6;
        iVar12 = fcn.18020eec0(iVar12);
        *(int64_t *)((int64_t)&arg_40h + iVar10) = iVar12;
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60b6;
        fcn.18020e940(iVar11);
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60be;
        iVar6 = func_0x00018020ef70();
        uVar19 = (uint64_t)iVar6;
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60ca;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60e2;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
        } else {
            if (in_R8 < 2) {
code_r0x0001801f6131:
                uVar21 = 0;
                if (in_R8 != 0) {
                    piVar24 = &var_1dfh;
                    *(int64_t **)((int64_t)&arg_38h + iVar10) = piVar24;
                    piVar18 = (int64_t *)(in_RDX + 8);
                    do {
                        uVar14 = *(undefined8 *)((int64_t)&arg_30h + iVar10);
                        (&var_3e8h)[uVar21] = *piVar18;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6162;
                        fcn.18020e940(uVar14);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f616a;
                        uVar8 = fcn.18020ef80();
                        if ((uVar8 >> 0x15 & 1) == 0) {
                            if (uVar19 == 1) {
                                *(undefined4 *)((int64_t)&arg_28h + iVar10 + 4) =
                                     *(undefined4 *)((int64_t)&arg_28h + iVar10 + 4);
                                if (*(int32_t *)((int64_t)&arg_28h + iVar10) == 0) goto code_r0x0001801f62c9;
                            } else if (*(int32_t *)((int64_t)&arg_28h + iVar10) == 0) {
code_r0x0001801f62c9:
                                if (((&var_3e8h)[uVar21] == 0) || ((uint64_t)(&var_3e8h)[uVar21] % uVar19 != 0))
                                goto code_r0x0001801f605a;
                            } else if (*(int64_t *)((int64_t)&arg_40h + iVar10) == 0) {
                                uVar16 = (&var_3e8h)[uVar21];
                                uVar20 = uVar19 - uVar16 % uVar19;
                                if (0x100 < uVar20) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f637c;
                                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                                    goto code_r0x0001801f601e;
                                }
                                uVar15 = uVar16;
                                if (uVar16 < uVar16 + uVar20) {
                                    do {
                                        *(char *)(uVar15 + piVar18[4]) = (char)uVar20 + -1;
                                        uVar15 = uVar15 + 1;
                                        uVar16 = (&var_3e8h)[uVar21];
                                    } while (uVar15 < uVar16 + uVar20);
                                }
                                *piVar18 = *piVar18 + uVar20;
                                (&var_3e8h)[uVar21] = uVar16 + uVar20;
                            }
                        } else {
                            puVar17 = *(undefined **)((int64_t)&arg_38h + iVar10);
                            if (*(int32_t *)(in_RCX + 2) == 0) {
                                *(undefined8 *)(puVar17 + -9) = in_RCX[0x200];
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f61c8;
                                iVar6 = func_0x0001801d4800(in_RCX);
                                if (iVar6 == 0) goto code_r0x0001801f605a;
                                puVar17 = *(undefined **)((int64_t)&arg_38h + iVar10);
                            } else {
                                uVar1 = *(undefined2 *)(in_RCX + 6);
                                *(char *)((int64_t)&arg_48h + iVar10 + 1) = (char)uVar1;
                                *(char *)((int64_t)&arg_48h + iVar10) = (char)((uint16_t)uVar1 >> 8);
                                *(undefined4 *)((int64_t)&arg_48h + iVar10 + 2) =
                                     *(undefined4 *)((int64_t)in_RCX + 0x1002);
                                *(undefined2 *)((int64_t)&arg_48h + iVar10 + 6) =
                                     *(undefined2 *)((int64_t)in_RCX + 0x1006);
                                *(undefined8 *)(puVar17 + -9) = *(undefined8 *)((int64_t)&arg_48h + iVar10);
                            }
                            uVar2 = *(undefined4 *)((int64_t)in_RCX + 0x14);
                            puVar17[-1] = *(undefined *)((int64_t)piVar18 + -4);
                            puVar17[1] = (char)uVar2;
                            iVar11 = *piVar18;
                            *puVar17 = (char)((uint32_t)uVar2 >> 8);
                            puVar17[3] = (char)iVar11;
                            puVar17[2] = (char)((uint64_t)iVar11 >> 8);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6211;
                            iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar10));
                            *(int32_t *)((int64_t)&arg_28h + iVar10 + 4) = iVar6;
                            if (iVar6 < 1) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6366;
                                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                                goto code_r0x0001801f601e;
                            }
                            piVar24 = *(int64_t **)((int64_t)&arg_38h + iVar10);
                            if (*(int32_t *)((int64_t)&arg_28h + iVar10) == 0) goto code_r0x0001801f62c9;
                            (&var_3e8h)[uVar21] = (&var_3e8h)[uVar21] + (int64_t)iVar6;
                            *piVar18 = *piVar18 + (int64_t)iVar6;
                        }
                        piVar24 = (int64_t *)((int64_t)piVar24 + 0xd);
                        uVar21 = uVar21 + 1;
                        piVar18 = piVar18 + 9;
                        *(int64_t **)((int64_t)&arg_38h + iVar10) = piVar24;
                    } while (uVar21 < in_R8);
                    iVar11 = *(int64_t *)((int64_t)&arg_30h + iVar10);
                    iVar12 = *(int64_t *)((int64_t)&arg_40h + iVar10);
                }
                if (in_R8 < 2) {
code_r0x0001801f63f9:
                    iVar6 = *(int32_t *)((int64_t)&arg_28h + iVar10);
                    if ((*(int32_t *)(in_RCX + 2) == 0) && (*(int32_t *)(in_RCX + 0x217) != 0)) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6439;
                        iVar7 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar10));
                        if (iVar7 < 1) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6442;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                            goto code_r0x0001801f601e;
                        }
                    }
                    if (iVar12 == 0) {
                        uVar14 = *(undefined8 *)(in_RDX + 0x20);
                        piVar18 = (int64_t *)(in_RDX + 0x20);
                        uVar4 = *(undefined8 *)(in_RDX + 0x28);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f65c5;
                        uVar8 = func_0x00018020f460(iVar11, uVar14, uVar4, (undefined4)var_3e8h);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f65d2;
                        uVar14 = fcn.18020e940(*(undefined8 *)((int64_t)&arg_30h + iVar10));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f65da;
                        uVar9 = fcn.18020ef80(uVar14);
                        if ((uVar9 >> 0x14 & 1) == 0) {
                            uVar8 = (uint32_t)(uVar8 == 0);
                        } else {
                            uVar8 = uVar8 >> 0x1f;
                        }
                        if (((uVar8 == 0) && (iVar6 == 0)) &&
                           (*(undefined8 *)((int64_t)&arg_40h + iVar10) = 0, var_478h = in_R8, in_R8 != 0)) {
                            do {
                                uVar14 = *(undefined8 *)((int64_t)&arg_50h + iVar10);
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f662d;
                                iVar6 = fcn.18020efb0(uVar14);
                                if (iVar6 == 6) {
                                    *piVar18 = *piVar18 + 8;
                                    piVar18[1] = piVar18[1] + 8;
                                    piVar18[-3] = piVar18[-3] + -8;
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f664a;
                                    iVar6 = fcn.18020efb0(uVar14);
                                    if (iVar6 == 7) {
                                        *piVar18 = *piVar18 + 8;
                                        piVar18[1] = piVar18[1] + 8;
                                        piVar18[-3] = piVar18[-3] + -8;
                                    } else if ((uVar19 != 1) &&
                                              (((iVar6 = *(int32_t *)((int64_t)in_RCX + 0x14), iVar6 == 0x302 ||
                                                (iVar6 == 0x303)) ||
                                               ((iVar6 == 0x100 || ((iVar6 == 0xfeff || (iVar6 == 0xfefd)))))))) {
                                        if ((uint64_t)piVar18[-3] < uVar19) break;
                                        *piVar18 = *piVar18 + uVar19;
                                        piVar18[1] = piVar18[1] + uVar19;
                                        piVar18[-2] = piVar18[-2] - uVar19;
                                        piVar18[-3] = piVar18[-3] - uVar19;
                                    }
                                }
                                iVar6 = *(int32_t *)((int64_t)&arg_28h + iVar10 + 4);
                                iVar22 = (int64_t)iVar6;
                                if (iVar6 == 0) {
                                    iVar22 = var_480h;
                                }
                                if (var_488h == 0) {
                                    iVar11 = 0;
                                    iVar12 = 0;
                                } else {
                                    iVar11 = iVar23 + 8;
                                    iVar12 = iVar23;
                                }
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f66d8;
                                uVar8 = fcn.18020ef80(*(undefined8 *)((int64_t)&arg_50h + iVar10));
                                iVar3 = *piVar18;
                                *(undefined8 *)((int64_t)&iStackX_20 + iVar10 + -8) = *in_RCX;
                                *(uint32_t *)((int64_t)&var_10h + iVar10) = (uint32_t)((uVar8 >> 0x15 & 1) != 0);
                                iVar5 = piVar18[-2];
                                *(int64_t *)((int64_t)&var_8h + iVar10) = iVar22;
                                *(uint64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20) = uVar19;
                                *(int64_t *)(&stack0xfffffffffffffff8 + iVar10) = iVar11;
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6712;
                                iVar6 = func_0x0001802732b0(piVar18 + -3, iVar5, iVar3, iVar12);
                                if (iVar6 == 0) break;
                                iVar23 = iVar23 + 0x10;
                                uVar21 = *(int64_t *)((int64_t)&arg_40h + iVar10) + 1;
                                piVar18 = piVar18 + 9;
                                *(uint64_t *)((int64_t)&arg_40h + iVar10) = uVar21;
                            } while (uVar21 < (uint64_t)var_478h);
                        }
                        goto code_r0x0001801f605a;
                    }
                    if (in_R8 < 2) {
                        uVar14 = *(undefined8 *)(in_RDX + 0x28);
                        uVar4 = *(undefined8 *)(in_RDX + 0x20);
                        *(undefined4 *)(&stack0xfffffffffffffff8 + iVar10) = (undefined4)var_3e8h;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6494;
                        iVar7 = func_0x000180211bb0(iVar11, uVar4, (int64_t)&arg_28h + iVar10 + 4, uVar14);
                        if ((iVar7 == 0) ||
                           (*(int64_t *)(in_RDX + 8) = (int64_t)*(int32_t *)((int64_t)&arg_28h + iVar10 + 4), iVar6 != 0
                           )) goto code_r0x0001801f605a;
                        uVar14 = *(undefined8 *)((int64_t)&arg_50h + iVar10);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f64bb;
                        iVar6 = fcn.18020efb0(uVar14);
                        if (iVar6 == 6) {
                            *(int64_t *)(in_RDX + 0x20) = *(int64_t *)(in_RDX + 0x20) + 8;
                            *(int64_t *)(in_RDX + 0x28) = *(int64_t *)(in_RDX + 0x28) + 8;
                        } else {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f64d4;
                            iVar6 = fcn.18020efb0(uVar14);
                            if (iVar6 == 7) {
                                *(int64_t *)(in_RDX + 0x20) = *(int64_t *)(in_RDX + 0x20) + 8;
                                *(int64_t *)(in_RDX + 0x28) = *(int64_t *)(in_RDX + 0x28) + 8;
                            } else if ((uVar19 != 1) &&
                                      ((((iVar6 = *(int32_t *)((int64_t)in_RCX + 0x14), iVar6 == 0x302 ||
                                         (iVar6 == 0x303)) || (iVar6 == 0x100)) ||
                                       ((iVar6 == 0xfeff || (iVar6 == 0xfefd)))))) {
                                *(int64_t *)(in_RDX + 0x20) = *(int64_t *)(in_RDX + 0x20) + uVar19;
                                *(int64_t *)(in_RDX + 0x28) = *(int64_t *)(in_RDX + 0x28) + uVar19;
                                *(int64_t *)(in_RDX + 0x10) = *(int64_t *)(in_RDX + 0x10) - uVar19;
                            }
                        }
                        if (iVar23 == 0) goto code_r0x0001801f605a;
                        *(undefined4 *)(iVar23 + 8) = 0;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6548;
                        puVar13 = (undefined4 *)func_0x000180229c20(&var_418h, 0x1804b8258, iVar23, iVar22);
                        var_468h._0_4_ = *puVar13;
                        var_468h._4_4_ = puVar13[1];
                        uStack_460 = puVar13[2];
                        uStack_45c = puVar13[3];
                        var_458h._0_4_ = puVar13[4];
                        var_458h._4_4_ = puVar13[5];
                        uStack_450 = puVar13[6];
                        uStack_44c = puVar13[7];
                        var_448h = *(int64_t *)(puVar13 + 8);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f656a;
                        puVar13 = (undefined4 *)func_0x000180229ba0(&var_418h);
                        var_440h._0_4_ = *puVar13;
                        var_440h._4_4_ = puVar13[1];
                        uStack_438 = puVar13[2];
                        uStack_434 = puVar13[3];
                        var_430h._0_4_ = puVar13[4];
                        var_430h._4_4_ = puVar13[5];
                        uStack_428 = puVar13[6];
                        uStack_424 = puVar13[7];
                        var_420h = *(int64_t *)(puVar13 + 8);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f658f;
                        iVar6 = func_0x000180211450(iVar11, &var_468h);
                        if (iVar6 != 0) goto code_r0x0001801f605a;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f659c;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6467;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                    }
                    goto code_r0x0001801f601e;
                }
                uVar21 = 0;
                piVar18 = (int64_t *)(in_RDX + 0x20);
                do {
                    iVar3 = *piVar18;
                    piVar18 = piVar18 + 9;
                    (&var_2e8h)[uVar21] = iVar3;
                    uVar21 = uVar21 + 1;
                } while (uVar21 < in_R8);
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f634e;
                iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar10));
                if (iVar6 < 1) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6357;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                } else {
                    uVar21 = 0;
                    piVar18 = (int64_t *)(in_RDX + 0x28);
                    do {
                        iVar3 = *piVar18;
                        piVar18 = piVar18 + 9;
                        (&var_2e8h)[uVar21] = iVar3;
                        uVar21 = uVar21 + 1;
                    } while (uVar21 < in_R8);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f63ce;
                    iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar10));
                    if (0 < iVar6) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f63e6;
                        iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar10));
                        if (0 < iVar6) goto code_r0x0001801f63f9;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f63ef;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60fb;
                fcn.18020e940(iVar11);
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6103;
                uVar8 = fcn.18020ef80();
                if ((uVar8 >> 0x17 & 1) != 0) goto code_r0x0001801f6131;
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f610e;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6126;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6040;
    fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar10));
code_r0x0001801f605a:
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6069;
    func_0x000180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar10));
    return;
}

// ============================================================
// Function: FUN_1801f5f4d
// Address: 0x1801f5f4d
// Size: 261 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Removing arg arg_4a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_500h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_49h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ah
// WARNING: [rz-ghidra] Detected overlap for variable arg_4eh

void fcn.1801f5e00(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined2 uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined4 *puVar13;
    undefined8 uVar14;
    undefined8 *in_RCX;
    uint64_t uVar15;
    uint64_t uVar16;
    int64_t in_RDX;
    undefined *puVar17;
    int64_t *piVar18;
    undefined8 unaff_RSI;
    uint64_t uVar19;
    uint64_t in_R8;
    uint64_t uVar20;
    int32_t in_R9D;
    undefined8 unaff_R12;
    uint64_t uVar21;
    int64_t iVar22;
    int64_t iVar23;
    undefined8 unaff_R14;
    int64_t *piVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_488h;
    int64_t var_480h;
    int64_t var_478h;
    int64_t var_468h;
    undefined4 uStack_460;
    undefined4 uStack_45c;
    int64_t var_458h;
    undefined4 uStack_450;
    undefined4 uStack_44c;
    int64_t var_448h;
    int64_t var_440h;
    undefined4 uStack_438;
    undefined4 uStack_434;
    int64_t var_430h;
    undefined4 uStack_428;
    undefined4 uStack_424;
    int64_t var_420h;
    int64_t var_418h;
    int64_t var_3e8h;
    int64_t var_2e8h;
    int64_t var_1dfh;
    int64_t var_48h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801f5e1a;
    iVar10 = fcn.18045a350();
    iVar22 = arg_30h;
    iVar23 = arg_28h;
    iVar10 = -iVar10;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar10);
    var_488h = arg_28h;
    var_480h = arg_30h;
    *(int32_t *)((int64_t)&arg_28h + iVar10) = in_R9D;
    *(undefined4 *)((int64_t)&arg_28h + iVar10 + 4) = 0;
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5e6a;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5e82;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5e98;
        fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar10));
        goto code_r0x0001801f605a;
    }
    uVar14 = in_RCX[0x207];
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5eab;
    iVar11 = fcn.18020e940(uVar14);
    if (iVar11 != 0) {
        uVar14 = in_RCX[0x207];
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5ebc;
        iVar6 = func_0x00018020f590(uVar14);
        if (iVar6 < 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5ec5;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5edd;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5ef3;
            fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar10));
            goto code_r0x0001801f605a;
        }
    }
    *(undefined8 *)(&stack0x000004a8 + iVar10) = unaff_R14;
    iVar11 = in_RCX[0x204];
    *(int64_t *)((int64_t)&arg_30h + iVar10) = iVar11;
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5f18;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5f30;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5f46;
        fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar10));
        goto code_r0x0001801f605a;
    }
    *(undefined8 *)(&stack0x00000500 + iVar10) = unaff_RSI;
    *(undefined8 *)(&stack0x000004b0 + iVar10) = unaff_R12;
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5f65;
    iVar12 = fcn.18020e940(iVar11);
    *(int64_t *)((int64_t)&arg_50h + iVar10) = iVar12;
    if ((in_R9D != 0) &&
       ((((iVar6 = *(int32_t *)((int64_t)in_RCX + 0x14), iVar6 == 0x302 || (iVar6 == 0x303)) || (iVar6 == 0x100)) ||
        ((iVar6 == 0xfeff || (iVar6 == 0xfefd)))))) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5fa8;
        iVar6 = fcn.18020efb0(iVar12);
        if (iVar6 == 2) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5fb5;
            iVar6 = func_0x00018020ef90(iVar12);
            if ((1 < iVar6) && (uVar19 = 0, in_R8 != 0)) {
                piVar18 = (int64_t *)(in_RDX + 0x20);
                do {
                    iVar11 = piVar18[1];
                    if (*piVar18 != iVar11) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6090;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                        goto code_r0x0001801f601e;
                    }
                    uVar14 = *in_RCX;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5feb;
                    iVar7 = func_0x00018021b9c0(uVar14, iVar11, (int64_t)iVar6, 0);
                    if (iVar7 < 1) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f607d;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                        goto code_r0x0001801f601e;
                    }
                    uVar19 = uVar19 + 1;
                    piVar18 = piVar18 + 9;
                } while (uVar19 < in_R8);
            }
            iVar11 = *(int64_t *)((int64_t)&arg_30h + iVar10);
        }
    }
    if (iVar12 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6012;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
code_r0x0001801f601e:
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f602a;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60a6;
        iVar12 = fcn.18020eec0(iVar12);
        *(int64_t *)((int64_t)&arg_40h + iVar10) = iVar12;
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60b6;
        fcn.18020e940(iVar11);
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60be;
        iVar6 = func_0x00018020ef70();
        uVar19 = (uint64_t)iVar6;
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60ca;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60e2;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
        } else {
            if (in_R8 < 2) {
code_r0x0001801f6131:
                uVar21 = 0;
                if (in_R8 != 0) {
                    piVar24 = &var_1dfh;
                    *(int64_t **)((int64_t)&arg_38h + iVar10) = piVar24;
                    piVar18 = (int64_t *)(in_RDX + 8);
                    do {
                        uVar14 = *(undefined8 *)((int64_t)&arg_30h + iVar10);
                        (&var_3e8h)[uVar21] = *piVar18;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6162;
                        fcn.18020e940(uVar14);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f616a;
                        uVar8 = fcn.18020ef80();
                        if ((uVar8 >> 0x15 & 1) == 0) {
                            if (uVar19 == 1) {
                                *(undefined4 *)((int64_t)&arg_28h + iVar10 + 4) =
                                     *(undefined4 *)((int64_t)&arg_28h + iVar10 + 4);
                                if (*(int32_t *)((int64_t)&arg_28h + iVar10) == 0) goto code_r0x0001801f62c9;
                            } else if (*(int32_t *)((int64_t)&arg_28h + iVar10) == 0) {
code_r0x0001801f62c9:
                                if (((&var_3e8h)[uVar21] == 0) || ((uint64_t)(&var_3e8h)[uVar21] % uVar19 != 0))
                                goto code_r0x0001801f605a;
                            } else if (*(int64_t *)((int64_t)&arg_40h + iVar10) == 0) {
                                uVar16 = (&var_3e8h)[uVar21];
                                uVar20 = uVar19 - uVar16 % uVar19;
                                if (0x100 < uVar20) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f637c;
                                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                                    goto code_r0x0001801f601e;
                                }
                                uVar15 = uVar16;
                                if (uVar16 < uVar16 + uVar20) {
                                    do {
                                        *(char *)(uVar15 + piVar18[4]) = (char)uVar20 + -1;
                                        uVar15 = uVar15 + 1;
                                        uVar16 = (&var_3e8h)[uVar21];
                                    } while (uVar15 < uVar16 + uVar20);
                                }
                                *piVar18 = *piVar18 + uVar20;
                                (&var_3e8h)[uVar21] = uVar16 + uVar20;
                            }
                        } else {
                            puVar17 = *(undefined **)((int64_t)&arg_38h + iVar10);
                            if (*(int32_t *)(in_RCX + 2) == 0) {
                                *(undefined8 *)(puVar17 + -9) = in_RCX[0x200];
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f61c8;
                                iVar6 = func_0x0001801d4800(in_RCX);
                                if (iVar6 == 0) goto code_r0x0001801f605a;
                                puVar17 = *(undefined **)((int64_t)&arg_38h + iVar10);
                            } else {
                                uVar1 = *(undefined2 *)(in_RCX + 6);
                                *(char *)((int64_t)&arg_48h + iVar10 + 1) = (char)uVar1;
                                *(char *)((int64_t)&arg_48h + iVar10) = (char)((uint16_t)uVar1 >> 8);
                                *(undefined4 *)((int64_t)&arg_48h + iVar10 + 2) =
                                     *(undefined4 *)((int64_t)in_RCX + 0x1002);
                                *(undefined2 *)((int64_t)&arg_48h + iVar10 + 6) =
                                     *(undefined2 *)((int64_t)in_RCX + 0x1006);
                                *(undefined8 *)(puVar17 + -9) = *(undefined8 *)((int64_t)&arg_48h + iVar10);
                            }
                            uVar2 = *(undefined4 *)((int64_t)in_RCX + 0x14);
                            puVar17[-1] = *(undefined *)((int64_t)piVar18 + -4);
                            puVar17[1] = (char)uVar2;
                            iVar11 = *piVar18;
                            *puVar17 = (char)((uint32_t)uVar2 >> 8);
                            puVar17[3] = (char)iVar11;
                            puVar17[2] = (char)((uint64_t)iVar11 >> 8);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6211;
                            iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar10));
                            *(int32_t *)((int64_t)&arg_28h + iVar10 + 4) = iVar6;
                            if (iVar6 < 1) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6366;
                                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                                goto code_r0x0001801f601e;
                            }
                            piVar24 = *(int64_t **)((int64_t)&arg_38h + iVar10);
                            if (*(int32_t *)((int64_t)&arg_28h + iVar10) == 0) goto code_r0x0001801f62c9;
                            (&var_3e8h)[uVar21] = (&var_3e8h)[uVar21] + (int64_t)iVar6;
                            *piVar18 = *piVar18 + (int64_t)iVar6;
                        }
                        piVar24 = (int64_t *)((int64_t)piVar24 + 0xd);
                        uVar21 = uVar21 + 1;
                        piVar18 = piVar18 + 9;
                        *(int64_t **)((int64_t)&arg_38h + iVar10) = piVar24;
                    } while (uVar21 < in_R8);
                    iVar11 = *(int64_t *)((int64_t)&arg_30h + iVar10);
                    iVar12 = *(int64_t *)((int64_t)&arg_40h + iVar10);
                }
                if (in_R8 < 2) {
code_r0x0001801f63f9:
                    iVar6 = *(int32_t *)((int64_t)&arg_28h + iVar10);
                    if ((*(int32_t *)(in_RCX + 2) == 0) && (*(int32_t *)(in_RCX + 0x217) != 0)) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6439;
                        iVar7 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar10));
                        if (iVar7 < 1) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6442;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                            goto code_r0x0001801f601e;
                        }
                    }
                    if (iVar12 == 0) {
                        uVar14 = *(undefined8 *)(in_RDX + 0x20);
                        piVar18 = (int64_t *)(in_RDX + 0x20);
                        uVar4 = *(undefined8 *)(in_RDX + 0x28);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f65c5;
                        uVar8 = func_0x00018020f460(iVar11, uVar14, uVar4, (undefined4)var_3e8h);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f65d2;
                        uVar14 = fcn.18020e940(*(undefined8 *)((int64_t)&arg_30h + iVar10));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f65da;
                        uVar9 = fcn.18020ef80(uVar14);
                        if ((uVar9 >> 0x14 & 1) == 0) {
                            uVar8 = (uint32_t)(uVar8 == 0);
                        } else {
                            uVar8 = uVar8 >> 0x1f;
                        }
                        if (((uVar8 == 0) && (iVar6 == 0)) &&
                           (*(undefined8 *)((int64_t)&arg_40h + iVar10) = 0, var_478h = in_R8, in_R8 != 0)) {
                            do {
                                uVar14 = *(undefined8 *)((int64_t)&arg_50h + iVar10);
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f662d;
                                iVar6 = fcn.18020efb0(uVar14);
                                if (iVar6 == 6) {
                                    *piVar18 = *piVar18 + 8;
                                    piVar18[1] = piVar18[1] + 8;
                                    piVar18[-3] = piVar18[-3] + -8;
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f664a;
                                    iVar6 = fcn.18020efb0(uVar14);
                                    if (iVar6 == 7) {
                                        *piVar18 = *piVar18 + 8;
                                        piVar18[1] = piVar18[1] + 8;
                                        piVar18[-3] = piVar18[-3] + -8;
                                    } else if ((uVar19 != 1) &&
                                              (((iVar6 = *(int32_t *)((int64_t)in_RCX + 0x14), iVar6 == 0x302 ||
                                                (iVar6 == 0x303)) ||
                                               ((iVar6 == 0x100 || ((iVar6 == 0xfeff || (iVar6 == 0xfefd)))))))) {
                                        if ((uint64_t)piVar18[-3] < uVar19) break;
                                        *piVar18 = *piVar18 + uVar19;
                                        piVar18[1] = piVar18[1] + uVar19;
                                        piVar18[-2] = piVar18[-2] - uVar19;
                                        piVar18[-3] = piVar18[-3] - uVar19;
                                    }
                                }
                                iVar6 = *(int32_t *)((int64_t)&arg_28h + iVar10 + 4);
                                iVar22 = (int64_t)iVar6;
                                if (iVar6 == 0) {
                                    iVar22 = var_480h;
                                }
                                if (var_488h == 0) {
                                    iVar11 = 0;
                                    iVar12 = 0;
                                } else {
                                    iVar11 = iVar23 + 8;
                                    iVar12 = iVar23;
                                }
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f66d8;
                                uVar8 = fcn.18020ef80(*(undefined8 *)((int64_t)&arg_50h + iVar10));
                                iVar3 = *piVar18;
                                *(undefined8 *)((int64_t)&iStackX_20 + iVar10 + -8) = *in_RCX;
                                *(uint32_t *)((int64_t)&var_10h + iVar10) = (uint32_t)((uVar8 >> 0x15 & 1) != 0);
                                iVar5 = piVar18[-2];
                                *(int64_t *)((int64_t)&var_8h + iVar10) = iVar22;
                                *(uint64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20) = uVar19;
                                *(int64_t *)(&stack0xfffffffffffffff8 + iVar10) = iVar11;
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6712;
                                iVar6 = func_0x0001802732b0(piVar18 + -3, iVar5, iVar3, iVar12);
                                if (iVar6 == 0) break;
                                iVar23 = iVar23 + 0x10;
                                uVar21 = *(int64_t *)((int64_t)&arg_40h + iVar10) + 1;
                                piVar18 = piVar18 + 9;
                                *(uint64_t *)((int64_t)&arg_40h + iVar10) = uVar21;
                            } while (uVar21 < (uint64_t)var_478h);
                        }
                        goto code_r0x0001801f605a;
                    }
                    if (in_R8 < 2) {
                        uVar14 = *(undefined8 *)(in_RDX + 0x28);
                        uVar4 = *(undefined8 *)(in_RDX + 0x20);
                        *(undefined4 *)(&stack0xfffffffffffffff8 + iVar10) = (undefined4)var_3e8h;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6494;
                        iVar7 = func_0x000180211bb0(iVar11, uVar4, (int64_t)&arg_28h + iVar10 + 4, uVar14);
                        if ((iVar7 == 0) ||
                           (*(int64_t *)(in_RDX + 8) = (int64_t)*(int32_t *)((int64_t)&arg_28h + iVar10 + 4), iVar6 != 0
                           )) goto code_r0x0001801f605a;
                        uVar14 = *(undefined8 *)((int64_t)&arg_50h + iVar10);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f64bb;
                        iVar6 = fcn.18020efb0(uVar14);
                        if (iVar6 == 6) {
                            *(int64_t *)(in_RDX + 0x20) = *(int64_t *)(in_RDX + 0x20) + 8;
                            *(int64_t *)(in_RDX + 0x28) = *(int64_t *)(in_RDX + 0x28) + 8;
                        } else {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f64d4;
                            iVar6 = fcn.18020efb0(uVar14);
                            if (iVar6 == 7) {
                                *(int64_t *)(in_RDX + 0x20) = *(int64_t *)(in_RDX + 0x20) + 8;
                                *(int64_t *)(in_RDX + 0x28) = *(int64_t *)(in_RDX + 0x28) + 8;
                            } else if ((uVar19 != 1) &&
                                      ((((iVar6 = *(int32_t *)((int64_t)in_RCX + 0x14), iVar6 == 0x302 ||
                                         (iVar6 == 0x303)) || (iVar6 == 0x100)) ||
                                       ((iVar6 == 0xfeff || (iVar6 == 0xfefd)))))) {
                                *(int64_t *)(in_RDX + 0x20) = *(int64_t *)(in_RDX + 0x20) + uVar19;
                                *(int64_t *)(in_RDX + 0x28) = *(int64_t *)(in_RDX + 0x28) + uVar19;
                                *(int64_t *)(in_RDX + 0x10) = *(int64_t *)(in_RDX + 0x10) - uVar19;
                            }
                        }
                        if (iVar23 == 0) goto code_r0x0001801f605a;
                        *(undefined4 *)(iVar23 + 8) = 0;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6548;
                        puVar13 = (undefined4 *)func_0x000180229c20(&var_418h, 0x1804b8258, iVar23, iVar22);
                        var_468h._0_4_ = *puVar13;
                        var_468h._4_4_ = puVar13[1];
                        uStack_460 = puVar13[2];
                        uStack_45c = puVar13[3];
                        var_458h._0_4_ = puVar13[4];
                        var_458h._4_4_ = puVar13[5];
                        uStack_450 = puVar13[6];
                        uStack_44c = puVar13[7];
                        var_448h = *(int64_t *)(puVar13 + 8);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f656a;
                        puVar13 = (undefined4 *)func_0x000180229ba0(&var_418h);
                        var_440h._0_4_ = *puVar13;
                        var_440h._4_4_ = puVar13[1];
                        uStack_438 = puVar13[2];
                        uStack_434 = puVar13[3];
                        var_430h._0_4_ = puVar13[4];
                        var_430h._4_4_ = puVar13[5];
                        uStack_428 = puVar13[6];
                        uStack_424 = puVar13[7];
                        var_420h = *(int64_t *)(puVar13 + 8);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f658f;
                        iVar6 = func_0x000180211450(iVar11, &var_468h);
                        if (iVar6 != 0) goto code_r0x0001801f605a;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f659c;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6467;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                    }
                    goto code_r0x0001801f601e;
                }
                uVar21 = 0;
                piVar18 = (int64_t *)(in_RDX + 0x20);
                do {
                    iVar3 = *piVar18;
                    piVar18 = piVar18 + 9;
                    (&var_2e8h)[uVar21] = iVar3;
                    uVar21 = uVar21 + 1;
                } while (uVar21 < in_R8);
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f634e;
                iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar10));
                if (iVar6 < 1) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6357;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                } else {
                    uVar21 = 0;
                    piVar18 = (int64_t *)(in_RDX + 0x28);
                    do {
                        iVar3 = *piVar18;
                        piVar18 = piVar18 + 9;
                        (&var_2e8h)[uVar21] = iVar3;
                        uVar21 = uVar21 + 1;
                    } while (uVar21 < in_R8);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f63ce;
                    iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar10));
                    if (0 < iVar6) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f63e6;
                        iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar10));
                        if (0 < iVar6) goto code_r0x0001801f63f9;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f63ef;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60fb;
                fcn.18020e940(iVar11);
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6103;
                uVar8 = fcn.18020ef80();
                if ((uVar8 >> 0x17 & 1) != 0) goto code_r0x0001801f6131;
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f610e;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6126;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6040;
    fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar10));
code_r0x0001801f605a:
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6069;
    func_0x000180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar10));
    return;
}

// ============================================================
// Function: FUN_1801f6052
// Address: 0x1801f6052
// Size: 8 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Removing arg arg_4a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_500h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_49h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ah
// WARNING: [rz-ghidra] Detected overlap for variable arg_4eh

void fcn.1801f5e00(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined2 uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined4 *puVar13;
    undefined8 uVar14;
    undefined8 *in_RCX;
    uint64_t uVar15;
    uint64_t uVar16;
    int64_t in_RDX;
    undefined *puVar17;
    int64_t *piVar18;
    undefined8 unaff_RSI;
    uint64_t uVar19;
    uint64_t in_R8;
    uint64_t uVar20;
    int32_t in_R9D;
    undefined8 unaff_R12;
    uint64_t uVar21;
    int64_t iVar22;
    int64_t iVar23;
    undefined8 unaff_R14;
    int64_t *piVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_488h;
    int64_t var_480h;
    int64_t var_478h;
    int64_t var_468h;
    undefined4 uStack_460;
    undefined4 uStack_45c;
    int64_t var_458h;
    undefined4 uStack_450;
    undefined4 uStack_44c;
    int64_t var_448h;
    int64_t var_440h;
    undefined4 uStack_438;
    undefined4 uStack_434;
    int64_t var_430h;
    undefined4 uStack_428;
    undefined4 uStack_424;
    int64_t var_420h;
    int64_t var_418h;
    int64_t var_3e8h;
    int64_t var_2e8h;
    int64_t var_1dfh;
    int64_t var_48h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801f5e1a;
    iVar10 = fcn.18045a350();
    iVar22 = arg_30h;
    iVar23 = arg_28h;
    iVar10 = -iVar10;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar10);
    var_488h = arg_28h;
    var_480h = arg_30h;
    *(int32_t *)((int64_t)&arg_28h + iVar10) = in_R9D;
    *(undefined4 *)((int64_t)&arg_28h + iVar10 + 4) = 0;
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5e6a;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5e82;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5e98;
        fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar10));
        goto code_r0x0001801f605a;
    }
    uVar14 = in_RCX[0x207];
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5eab;
    iVar11 = fcn.18020e940(uVar14);
    if (iVar11 != 0) {
        uVar14 = in_RCX[0x207];
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5ebc;
        iVar6 = func_0x00018020f590(uVar14);
        if (iVar6 < 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5ec5;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5edd;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5ef3;
            fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar10));
            goto code_r0x0001801f605a;
        }
    }
    *(undefined8 *)(&stack0x000004a8 + iVar10) = unaff_R14;
    iVar11 = in_RCX[0x204];
    *(int64_t *)((int64_t)&arg_30h + iVar10) = iVar11;
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5f18;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5f30;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5f46;
        fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar10));
        goto code_r0x0001801f605a;
    }
    *(undefined8 *)(&stack0x00000500 + iVar10) = unaff_RSI;
    *(undefined8 *)(&stack0x000004b0 + iVar10) = unaff_R12;
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5f65;
    iVar12 = fcn.18020e940(iVar11);
    *(int64_t *)((int64_t)&arg_50h + iVar10) = iVar12;
    if ((in_R9D != 0) &&
       ((((iVar6 = *(int32_t *)((int64_t)in_RCX + 0x14), iVar6 == 0x302 || (iVar6 == 0x303)) || (iVar6 == 0x100)) ||
        ((iVar6 == 0xfeff || (iVar6 == 0xfefd)))))) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5fa8;
        iVar6 = fcn.18020efb0(iVar12);
        if (iVar6 == 2) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5fb5;
            iVar6 = func_0x00018020ef90(iVar12);
            if ((1 < iVar6) && (uVar19 = 0, in_R8 != 0)) {
                piVar18 = (int64_t *)(in_RDX + 0x20);
                do {
                    iVar11 = piVar18[1];
                    if (*piVar18 != iVar11) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6090;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                        goto code_r0x0001801f601e;
                    }
                    uVar14 = *in_RCX;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5feb;
                    iVar7 = func_0x00018021b9c0(uVar14, iVar11, (int64_t)iVar6, 0);
                    if (iVar7 < 1) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f607d;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                        goto code_r0x0001801f601e;
                    }
                    uVar19 = uVar19 + 1;
                    piVar18 = piVar18 + 9;
                } while (uVar19 < in_R8);
            }
            iVar11 = *(int64_t *)((int64_t)&arg_30h + iVar10);
        }
    }
    if (iVar12 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6012;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
code_r0x0001801f601e:
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f602a;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60a6;
        iVar12 = fcn.18020eec0(iVar12);
        *(int64_t *)((int64_t)&arg_40h + iVar10) = iVar12;
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60b6;
        fcn.18020e940(iVar11);
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60be;
        iVar6 = func_0x00018020ef70();
        uVar19 = (uint64_t)iVar6;
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60ca;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60e2;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
        } else {
            if (in_R8 < 2) {
code_r0x0001801f6131:
                uVar21 = 0;
                if (in_R8 != 0) {
                    piVar24 = &var_1dfh;
                    *(int64_t **)((int64_t)&arg_38h + iVar10) = piVar24;
                    piVar18 = (int64_t *)(in_RDX + 8);
                    do {
                        uVar14 = *(undefined8 *)((int64_t)&arg_30h + iVar10);
                        (&var_3e8h)[uVar21] = *piVar18;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6162;
                        fcn.18020e940(uVar14);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f616a;
                        uVar8 = fcn.18020ef80();
                        if ((uVar8 >> 0x15 & 1) == 0) {
                            if (uVar19 == 1) {
                                *(undefined4 *)((int64_t)&arg_28h + iVar10 + 4) =
                                     *(undefined4 *)((int64_t)&arg_28h + iVar10 + 4);
                                if (*(int32_t *)((int64_t)&arg_28h + iVar10) == 0) goto code_r0x0001801f62c9;
                            } else if (*(int32_t *)((int64_t)&arg_28h + iVar10) == 0) {
code_r0x0001801f62c9:
                                if (((&var_3e8h)[uVar21] == 0) || ((uint64_t)(&var_3e8h)[uVar21] % uVar19 != 0))
                                goto code_r0x0001801f605a;
                            } else if (*(int64_t *)((int64_t)&arg_40h + iVar10) == 0) {
                                uVar16 = (&var_3e8h)[uVar21];
                                uVar20 = uVar19 - uVar16 % uVar19;
                                if (0x100 < uVar20) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f637c;
                                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                                    goto code_r0x0001801f601e;
                                }
                                uVar15 = uVar16;
                                if (uVar16 < uVar16 + uVar20) {
                                    do {
                                        *(char *)(uVar15 + piVar18[4]) = (char)uVar20 + -1;
                                        uVar15 = uVar15 + 1;
                                        uVar16 = (&var_3e8h)[uVar21];
                                    } while (uVar15 < uVar16 + uVar20);
                                }
                                *piVar18 = *piVar18 + uVar20;
                                (&var_3e8h)[uVar21] = uVar16 + uVar20;
                            }
                        } else {
                            puVar17 = *(undefined **)((int64_t)&arg_38h + iVar10);
                            if (*(int32_t *)(in_RCX + 2) == 0) {
                                *(undefined8 *)(puVar17 + -9) = in_RCX[0x200];
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f61c8;
                                iVar6 = func_0x0001801d4800(in_RCX);
                                if (iVar6 == 0) goto code_r0x0001801f605a;
                                puVar17 = *(undefined **)((int64_t)&arg_38h + iVar10);
                            } else {
                                uVar1 = *(undefined2 *)(in_RCX + 6);
                                *(char *)((int64_t)&arg_48h + iVar10 + 1) = (char)uVar1;
                                *(char *)((int64_t)&arg_48h + iVar10) = (char)((uint16_t)uVar1 >> 8);
                                *(undefined4 *)((int64_t)&arg_48h + iVar10 + 2) =
                                     *(undefined4 *)((int64_t)in_RCX + 0x1002);
                                *(undefined2 *)((int64_t)&arg_48h + iVar10 + 6) =
                                     *(undefined2 *)((int64_t)in_RCX + 0x1006);
                                *(undefined8 *)(puVar17 + -9) = *(undefined8 *)((int64_t)&arg_48h + iVar10);
                            }
                            uVar2 = *(undefined4 *)((int64_t)in_RCX + 0x14);
                            puVar17[-1] = *(undefined *)((int64_t)piVar18 + -4);
                            puVar17[1] = (char)uVar2;
                            iVar11 = *piVar18;
                            *puVar17 = (char)((uint32_t)uVar2 >> 8);
                            puVar17[3] = (char)iVar11;
                            puVar17[2] = (char)((uint64_t)iVar11 >> 8);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6211;
                            iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar10));
                            *(int32_t *)((int64_t)&arg_28h + iVar10 + 4) = iVar6;
                            if (iVar6 < 1) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6366;
                                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                                goto code_r0x0001801f601e;
                            }
                            piVar24 = *(int64_t **)((int64_t)&arg_38h + iVar10);
                            if (*(int32_t *)((int64_t)&arg_28h + iVar10) == 0) goto code_r0x0001801f62c9;
                            (&var_3e8h)[uVar21] = (&var_3e8h)[uVar21] + (int64_t)iVar6;
                            *piVar18 = *piVar18 + (int64_t)iVar6;
                        }
                        piVar24 = (int64_t *)((int64_t)piVar24 + 0xd);
                        uVar21 = uVar21 + 1;
                        piVar18 = piVar18 + 9;
                        *(int64_t **)((int64_t)&arg_38h + iVar10) = piVar24;
                    } while (uVar21 < in_R8);
                    iVar11 = *(int64_t *)((int64_t)&arg_30h + iVar10);
                    iVar12 = *(int64_t *)((int64_t)&arg_40h + iVar10);
                }
                if (in_R8 < 2) {
code_r0x0001801f63f9:
                    iVar6 = *(int32_t *)((int64_t)&arg_28h + iVar10);
                    if ((*(int32_t *)(in_RCX + 2) == 0) && (*(int32_t *)(in_RCX + 0x217) != 0)) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6439;
                        iVar7 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar10));
                        if (iVar7 < 1) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6442;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                            goto code_r0x0001801f601e;
                        }
                    }
                    if (iVar12 == 0) {
                        uVar14 = *(undefined8 *)(in_RDX + 0x20);
                        piVar18 = (int64_t *)(in_RDX + 0x20);
                        uVar4 = *(undefined8 *)(in_RDX + 0x28);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f65c5;
                        uVar8 = func_0x00018020f460(iVar11, uVar14, uVar4, (undefined4)var_3e8h);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f65d2;
                        uVar14 = fcn.18020e940(*(undefined8 *)((int64_t)&arg_30h + iVar10));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f65da;
                        uVar9 = fcn.18020ef80(uVar14);
                        if ((uVar9 >> 0x14 & 1) == 0) {
                            uVar8 = (uint32_t)(uVar8 == 0);
                        } else {
                            uVar8 = uVar8 >> 0x1f;
                        }
                        if (((uVar8 == 0) && (iVar6 == 0)) &&
                           (*(undefined8 *)((int64_t)&arg_40h + iVar10) = 0, var_478h = in_R8, in_R8 != 0)) {
                            do {
                                uVar14 = *(undefined8 *)((int64_t)&arg_50h + iVar10);
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f662d;
                                iVar6 = fcn.18020efb0(uVar14);
                                if (iVar6 == 6) {
                                    *piVar18 = *piVar18 + 8;
                                    piVar18[1] = piVar18[1] + 8;
                                    piVar18[-3] = piVar18[-3] + -8;
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f664a;
                                    iVar6 = fcn.18020efb0(uVar14);
                                    if (iVar6 == 7) {
                                        *piVar18 = *piVar18 + 8;
                                        piVar18[1] = piVar18[1] + 8;
                                        piVar18[-3] = piVar18[-3] + -8;
                                    } else if ((uVar19 != 1) &&
                                              (((iVar6 = *(int32_t *)((int64_t)in_RCX + 0x14), iVar6 == 0x302 ||
                                                (iVar6 == 0x303)) ||
                                               ((iVar6 == 0x100 || ((iVar6 == 0xfeff || (iVar6 == 0xfefd)))))))) {
                                        if ((uint64_t)piVar18[-3] < uVar19) break;
                                        *piVar18 = *piVar18 + uVar19;
                                        piVar18[1] = piVar18[1] + uVar19;
                                        piVar18[-2] = piVar18[-2] - uVar19;
                                        piVar18[-3] = piVar18[-3] - uVar19;
                                    }
                                }
                                iVar6 = *(int32_t *)((int64_t)&arg_28h + iVar10 + 4);
                                iVar22 = (int64_t)iVar6;
                                if (iVar6 == 0) {
                                    iVar22 = var_480h;
                                }
                                if (var_488h == 0) {
                                    iVar11 = 0;
                                    iVar12 = 0;
                                } else {
                                    iVar11 = iVar23 + 8;
                                    iVar12 = iVar23;
                                }
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f66d8;
                                uVar8 = fcn.18020ef80(*(undefined8 *)((int64_t)&arg_50h + iVar10));
                                iVar3 = *piVar18;
                                *(undefined8 *)((int64_t)&iStackX_20 + iVar10 + -8) = *in_RCX;
                                *(uint32_t *)((int64_t)&var_10h + iVar10) = (uint32_t)((uVar8 >> 0x15 & 1) != 0);
                                iVar5 = piVar18[-2];
                                *(int64_t *)((int64_t)&var_8h + iVar10) = iVar22;
                                *(uint64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20) = uVar19;
                                *(int64_t *)(&stack0xfffffffffffffff8 + iVar10) = iVar11;
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6712;
                                iVar6 = func_0x0001802732b0(piVar18 + -3, iVar5, iVar3, iVar12);
                                if (iVar6 == 0) break;
                                iVar23 = iVar23 + 0x10;
                                uVar21 = *(int64_t *)((int64_t)&arg_40h + iVar10) + 1;
                                piVar18 = piVar18 + 9;
                                *(uint64_t *)((int64_t)&arg_40h + iVar10) = uVar21;
                            } while (uVar21 < (uint64_t)var_478h);
                        }
                        goto code_r0x0001801f605a;
                    }
                    if (in_R8 < 2) {
                        uVar14 = *(undefined8 *)(in_RDX + 0x28);
                        uVar4 = *(undefined8 *)(in_RDX + 0x20);
                        *(undefined4 *)(&stack0xfffffffffffffff8 + iVar10) = (undefined4)var_3e8h;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6494;
                        iVar7 = func_0x000180211bb0(iVar11, uVar4, (int64_t)&arg_28h + iVar10 + 4, uVar14);
                        if ((iVar7 == 0) ||
                           (*(int64_t *)(in_RDX + 8) = (int64_t)*(int32_t *)((int64_t)&arg_28h + iVar10 + 4), iVar6 != 0
                           )) goto code_r0x0001801f605a;
                        uVar14 = *(undefined8 *)((int64_t)&arg_50h + iVar10);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f64bb;
                        iVar6 = fcn.18020efb0(uVar14);
                        if (iVar6 == 6) {
                            *(int64_t *)(in_RDX + 0x20) = *(int64_t *)(in_RDX + 0x20) + 8;
                            *(int64_t *)(in_RDX + 0x28) = *(int64_t *)(in_RDX + 0x28) + 8;
                        } else {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f64d4;
                            iVar6 = fcn.18020efb0(uVar14);
                            if (iVar6 == 7) {
                                *(int64_t *)(in_RDX + 0x20) = *(int64_t *)(in_RDX + 0x20) + 8;
                                *(int64_t *)(in_RDX + 0x28) = *(int64_t *)(in_RDX + 0x28) + 8;
                            } else if ((uVar19 != 1) &&
                                      ((((iVar6 = *(int32_t *)((int64_t)in_RCX + 0x14), iVar6 == 0x302 ||
                                         (iVar6 == 0x303)) || (iVar6 == 0x100)) ||
                                       ((iVar6 == 0xfeff || (iVar6 == 0xfefd)))))) {
                                *(int64_t *)(in_RDX + 0x20) = *(int64_t *)(in_RDX + 0x20) + uVar19;
                                *(int64_t *)(in_RDX + 0x28) = *(int64_t *)(in_RDX + 0x28) + uVar19;
                                *(int64_t *)(in_RDX + 0x10) = *(int64_t *)(in_RDX + 0x10) - uVar19;
                            }
                        }
                        if (iVar23 == 0) goto code_r0x0001801f605a;
                        *(undefined4 *)(iVar23 + 8) = 0;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6548;
                        puVar13 = (undefined4 *)func_0x000180229c20(&var_418h, 0x1804b8258, iVar23, iVar22);
                        var_468h._0_4_ = *puVar13;
                        var_468h._4_4_ = puVar13[1];
                        uStack_460 = puVar13[2];
                        uStack_45c = puVar13[3];
                        var_458h._0_4_ = puVar13[4];
                        var_458h._4_4_ = puVar13[5];
                        uStack_450 = puVar13[6];
                        uStack_44c = puVar13[7];
                        var_448h = *(int64_t *)(puVar13 + 8);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f656a;
                        puVar13 = (undefined4 *)func_0x000180229ba0(&var_418h);
                        var_440h._0_4_ = *puVar13;
                        var_440h._4_4_ = puVar13[1];
                        uStack_438 = puVar13[2];
                        uStack_434 = puVar13[3];
                        var_430h._0_4_ = puVar13[4];
                        var_430h._4_4_ = puVar13[5];
                        uStack_428 = puVar13[6];
                        uStack_424 = puVar13[7];
                        var_420h = *(int64_t *)(puVar13 + 8);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f658f;
                        iVar6 = func_0x000180211450(iVar11, &var_468h);
                        if (iVar6 != 0) goto code_r0x0001801f605a;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f659c;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6467;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                    }
                    goto code_r0x0001801f601e;
                }
                uVar21 = 0;
                piVar18 = (int64_t *)(in_RDX + 0x20);
                do {
                    iVar3 = *piVar18;
                    piVar18 = piVar18 + 9;
                    (&var_2e8h)[uVar21] = iVar3;
                    uVar21 = uVar21 + 1;
                } while (uVar21 < in_R8);
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f634e;
                iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar10));
                if (iVar6 < 1) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6357;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                } else {
                    uVar21 = 0;
                    piVar18 = (int64_t *)(in_RDX + 0x28);
                    do {
                        iVar3 = *piVar18;
                        piVar18 = piVar18 + 9;
                        (&var_2e8h)[uVar21] = iVar3;
                        uVar21 = uVar21 + 1;
                    } while (uVar21 < in_R8);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f63ce;
                    iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar10));
                    if (0 < iVar6) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f63e6;
                        iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar10));
                        if (0 < iVar6) goto code_r0x0001801f63f9;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f63ef;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60fb;
                fcn.18020e940(iVar11);
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6103;
                uVar8 = fcn.18020ef80();
                if ((uVar8 >> 0x17 & 1) != 0) goto code_r0x0001801f6131;
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f610e;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6126;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6040;
    fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar10));
code_r0x0001801f605a:
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6069;
    func_0x000180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar10));
    return;
}

// ============================================================
// Function: FUN_1801f605a
// Address: 0x1801f605a
// Size: 30 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Removing arg arg_4a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_500h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_49h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ah
// WARNING: [rz-ghidra] Detected overlap for variable arg_4eh

void fcn.1801f5e00(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined2 uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined4 *puVar13;
    undefined8 uVar14;
    undefined8 *in_RCX;
    uint64_t uVar15;
    uint64_t uVar16;
    int64_t in_RDX;
    undefined *puVar17;
    int64_t *piVar18;
    undefined8 unaff_RSI;
    uint64_t uVar19;
    uint64_t in_R8;
    uint64_t uVar20;
    int32_t in_R9D;
    undefined8 unaff_R12;
    uint64_t uVar21;
    int64_t iVar22;
    int64_t iVar23;
    undefined8 unaff_R14;
    int64_t *piVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_488h;
    int64_t var_480h;
    int64_t var_478h;
    int64_t var_468h;
    undefined4 uStack_460;
    undefined4 uStack_45c;
    int64_t var_458h;
    undefined4 uStack_450;
    undefined4 uStack_44c;
    int64_t var_448h;
    int64_t var_440h;
    undefined4 uStack_438;
    undefined4 uStack_434;
    int64_t var_430h;
    undefined4 uStack_428;
    undefined4 uStack_424;
    int64_t var_420h;
    int64_t var_418h;
    int64_t var_3e8h;
    int64_t var_2e8h;
    int64_t var_1dfh;
    int64_t var_48h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801f5e1a;
    iVar10 = fcn.18045a350();
    iVar22 = arg_30h;
    iVar23 = arg_28h;
    iVar10 = -iVar10;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar10);
    var_488h = arg_28h;
    var_480h = arg_30h;
    *(int32_t *)((int64_t)&arg_28h + iVar10) = in_R9D;
    *(undefined4 *)((int64_t)&arg_28h + iVar10 + 4) = 0;
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5e6a;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5e82;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5e98;
        fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar10));
        goto code_r0x0001801f605a;
    }
    uVar14 = in_RCX[0x207];
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5eab;
    iVar11 = fcn.18020e940(uVar14);
    if (iVar11 != 0) {
        uVar14 = in_RCX[0x207];
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5ebc;
        iVar6 = func_0x00018020f590(uVar14);
        if (iVar6 < 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5ec5;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5edd;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5ef3;
            fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar10));
            goto code_r0x0001801f605a;
        }
    }
    *(undefined8 *)(&stack0x000004a8 + iVar10) = unaff_R14;
    iVar11 = in_RCX[0x204];
    *(int64_t *)((int64_t)&arg_30h + iVar10) = iVar11;
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5f18;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5f30;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5f46;
        fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar10));
        goto code_r0x0001801f605a;
    }
    *(undefined8 *)(&stack0x00000500 + iVar10) = unaff_RSI;
    *(undefined8 *)(&stack0x000004b0 + iVar10) = unaff_R12;
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5f65;
    iVar12 = fcn.18020e940(iVar11);
    *(int64_t *)((int64_t)&arg_50h + iVar10) = iVar12;
    if ((in_R9D != 0) &&
       ((((iVar6 = *(int32_t *)((int64_t)in_RCX + 0x14), iVar6 == 0x302 || (iVar6 == 0x303)) || (iVar6 == 0x100)) ||
        ((iVar6 == 0xfeff || (iVar6 == 0xfefd)))))) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5fa8;
        iVar6 = fcn.18020efb0(iVar12);
        if (iVar6 == 2) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5fb5;
            iVar6 = func_0x00018020ef90(iVar12);
            if ((1 < iVar6) && (uVar19 = 0, in_R8 != 0)) {
                piVar18 = (int64_t *)(in_RDX + 0x20);
                do {
                    iVar11 = piVar18[1];
                    if (*piVar18 != iVar11) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6090;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                        goto code_r0x0001801f601e;
                    }
                    uVar14 = *in_RCX;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5feb;
                    iVar7 = func_0x00018021b9c0(uVar14, iVar11, (int64_t)iVar6, 0);
                    if (iVar7 < 1) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f607d;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                        goto code_r0x0001801f601e;
                    }
                    uVar19 = uVar19 + 1;
                    piVar18 = piVar18 + 9;
                } while (uVar19 < in_R8);
            }
            iVar11 = *(int64_t *)((int64_t)&arg_30h + iVar10);
        }
    }
    if (iVar12 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6012;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
code_r0x0001801f601e:
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f602a;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60a6;
        iVar12 = fcn.18020eec0(iVar12);
        *(int64_t *)((int64_t)&arg_40h + iVar10) = iVar12;
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60b6;
        fcn.18020e940(iVar11);
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60be;
        iVar6 = func_0x00018020ef70();
        uVar19 = (uint64_t)iVar6;
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60ca;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60e2;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
        } else {
            if (in_R8 < 2) {
code_r0x0001801f6131:
                uVar21 = 0;
                if (in_R8 != 0) {
                    piVar24 = &var_1dfh;
                    *(int64_t **)((int64_t)&arg_38h + iVar10) = piVar24;
                    piVar18 = (int64_t *)(in_RDX + 8);
                    do {
                        uVar14 = *(undefined8 *)((int64_t)&arg_30h + iVar10);
                        (&var_3e8h)[uVar21] = *piVar18;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6162;
                        fcn.18020e940(uVar14);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f616a;
                        uVar8 = fcn.18020ef80();
                        if ((uVar8 >> 0x15 & 1) == 0) {
                            if (uVar19 == 1) {
                                *(undefined4 *)((int64_t)&arg_28h + iVar10 + 4) =
                                     *(undefined4 *)((int64_t)&arg_28h + iVar10 + 4);
                                if (*(int32_t *)((int64_t)&arg_28h + iVar10) == 0) goto code_r0x0001801f62c9;
                            } else if (*(int32_t *)((int64_t)&arg_28h + iVar10) == 0) {
code_r0x0001801f62c9:
                                if (((&var_3e8h)[uVar21] == 0) || ((uint64_t)(&var_3e8h)[uVar21] % uVar19 != 0))
                                goto code_r0x0001801f605a;
                            } else if (*(int64_t *)((int64_t)&arg_40h + iVar10) == 0) {
                                uVar16 = (&var_3e8h)[uVar21];
                                uVar20 = uVar19 - uVar16 % uVar19;
                                if (0x100 < uVar20) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f637c;
                                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                                    goto code_r0x0001801f601e;
                                }
                                uVar15 = uVar16;
                                if (uVar16 < uVar16 + uVar20) {
                                    do {
                                        *(char *)(uVar15 + piVar18[4]) = (char)uVar20 + -1;
                                        uVar15 = uVar15 + 1;
                                        uVar16 = (&var_3e8h)[uVar21];
                                    } while (uVar15 < uVar16 + uVar20);
                                }
                                *piVar18 = *piVar18 + uVar20;
                                (&var_3e8h)[uVar21] = uVar16 + uVar20;
                            }
                        } else {
                            puVar17 = *(undefined **)((int64_t)&arg_38h + iVar10);
                            if (*(int32_t *)(in_RCX + 2) == 0) {
                                *(undefined8 *)(puVar17 + -9) = in_RCX[0x200];
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f61c8;
                                iVar6 = func_0x0001801d4800(in_RCX);
                                if (iVar6 == 0) goto code_r0x0001801f605a;
                                puVar17 = *(undefined **)((int64_t)&arg_38h + iVar10);
                            } else {
                                uVar1 = *(undefined2 *)(in_RCX + 6);
                                *(char *)((int64_t)&arg_48h + iVar10 + 1) = (char)uVar1;
                                *(char *)((int64_t)&arg_48h + iVar10) = (char)((uint16_t)uVar1 >> 8);
                                *(undefined4 *)((int64_t)&arg_48h + iVar10 + 2) =
                                     *(undefined4 *)((int64_t)in_RCX + 0x1002);
                                *(undefined2 *)((int64_t)&arg_48h + iVar10 + 6) =
                                     *(undefined2 *)((int64_t)in_RCX + 0x1006);
                                *(undefined8 *)(puVar17 + -9) = *(undefined8 *)((int64_t)&arg_48h + iVar10);
                            }
                            uVar2 = *(undefined4 *)((int64_t)in_RCX + 0x14);
                            puVar17[-1] = *(undefined *)((int64_t)piVar18 + -4);
                            puVar17[1] = (char)uVar2;
                            iVar11 = *piVar18;
                            *puVar17 = (char)((uint32_t)uVar2 >> 8);
                            puVar17[3] = (char)iVar11;
                            puVar17[2] = (char)((uint64_t)iVar11 >> 8);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6211;
                            iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar10));
                            *(int32_t *)((int64_t)&arg_28h + iVar10 + 4) = iVar6;
                            if (iVar6 < 1) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6366;
                                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                                goto code_r0x0001801f601e;
                            }
                            piVar24 = *(int64_t **)((int64_t)&arg_38h + iVar10);
                            if (*(int32_t *)((int64_t)&arg_28h + iVar10) == 0) goto code_r0x0001801f62c9;
                            (&var_3e8h)[uVar21] = (&var_3e8h)[uVar21] + (int64_t)iVar6;
                            *piVar18 = *piVar18 + (int64_t)iVar6;
                        }
                        piVar24 = (int64_t *)((int64_t)piVar24 + 0xd);
                        uVar21 = uVar21 + 1;
                        piVar18 = piVar18 + 9;
                        *(int64_t **)((int64_t)&arg_38h + iVar10) = piVar24;
                    } while (uVar21 < in_R8);
                    iVar11 = *(int64_t *)((int64_t)&arg_30h + iVar10);
                    iVar12 = *(int64_t *)((int64_t)&arg_40h + iVar10);
                }
                if (in_R8 < 2) {
code_r0x0001801f63f9:
                    iVar6 = *(int32_t *)((int64_t)&arg_28h + iVar10);
                    if ((*(int32_t *)(in_RCX + 2) == 0) && (*(int32_t *)(in_RCX + 0x217) != 0)) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6439;
                        iVar7 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar10));
                        if (iVar7 < 1) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6442;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                            goto code_r0x0001801f601e;
                        }
                    }
                    if (iVar12 == 0) {
                        uVar14 = *(undefined8 *)(in_RDX + 0x20);
                        piVar18 = (int64_t *)(in_RDX + 0x20);
                        uVar4 = *(undefined8 *)(in_RDX + 0x28);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f65c5;
                        uVar8 = func_0x00018020f460(iVar11, uVar14, uVar4, (undefined4)var_3e8h);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f65d2;
                        uVar14 = fcn.18020e940(*(undefined8 *)((int64_t)&arg_30h + iVar10));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f65da;
                        uVar9 = fcn.18020ef80(uVar14);
                        if ((uVar9 >> 0x14 & 1) == 0) {
                            uVar8 = (uint32_t)(uVar8 == 0);
                        } else {
                            uVar8 = uVar8 >> 0x1f;
                        }
                        if (((uVar8 == 0) && (iVar6 == 0)) &&
                           (*(undefined8 *)((int64_t)&arg_40h + iVar10) = 0, var_478h = in_R8, in_R8 != 0)) {
                            do {
                                uVar14 = *(undefined8 *)((int64_t)&arg_50h + iVar10);
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f662d;
                                iVar6 = fcn.18020efb0(uVar14);
                                if (iVar6 == 6) {
                                    *piVar18 = *piVar18 + 8;
                                    piVar18[1] = piVar18[1] + 8;
                                    piVar18[-3] = piVar18[-3] + -8;
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f664a;
                                    iVar6 = fcn.18020efb0(uVar14);
                                    if (iVar6 == 7) {
                                        *piVar18 = *piVar18 + 8;
                                        piVar18[1] = piVar18[1] + 8;
                                        piVar18[-3] = piVar18[-3] + -8;
                                    } else if ((uVar19 != 1) &&
                                              (((iVar6 = *(int32_t *)((int64_t)in_RCX + 0x14), iVar6 == 0x302 ||
                                                (iVar6 == 0x303)) ||
                                               ((iVar6 == 0x100 || ((iVar6 == 0xfeff || (iVar6 == 0xfefd)))))))) {
                                        if ((uint64_t)piVar18[-3] < uVar19) break;
                                        *piVar18 = *piVar18 + uVar19;
                                        piVar18[1] = piVar18[1] + uVar19;
                                        piVar18[-2] = piVar18[-2] - uVar19;
                                        piVar18[-3] = piVar18[-3] - uVar19;
                                    }
                                }
                                iVar6 = *(int32_t *)((int64_t)&arg_28h + iVar10 + 4);
                                iVar22 = (int64_t)iVar6;
                                if (iVar6 == 0) {
                                    iVar22 = var_480h;
                                }
                                if (var_488h == 0) {
                                    iVar11 = 0;
                                    iVar12 = 0;
                                } else {
                                    iVar11 = iVar23 + 8;
                                    iVar12 = iVar23;
                                }
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f66d8;
                                uVar8 = fcn.18020ef80(*(undefined8 *)((int64_t)&arg_50h + iVar10));
                                iVar3 = *piVar18;
                                *(undefined8 *)((int64_t)&iStackX_20 + iVar10 + -8) = *in_RCX;
                                *(uint32_t *)((int64_t)&var_10h + iVar10) = (uint32_t)((uVar8 >> 0x15 & 1) != 0);
                                iVar5 = piVar18[-2];
                                *(int64_t *)((int64_t)&var_8h + iVar10) = iVar22;
                                *(uint64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20) = uVar19;
                                *(int64_t *)(&stack0xfffffffffffffff8 + iVar10) = iVar11;
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6712;
                                iVar6 = func_0x0001802732b0(piVar18 + -3, iVar5, iVar3, iVar12);
                                if (iVar6 == 0) break;
                                iVar23 = iVar23 + 0x10;
                                uVar21 = *(int64_t *)((int64_t)&arg_40h + iVar10) + 1;
                                piVar18 = piVar18 + 9;
                                *(uint64_t *)((int64_t)&arg_40h + iVar10) = uVar21;
                            } while (uVar21 < (uint64_t)var_478h);
                        }
                        goto code_r0x0001801f605a;
                    }
                    if (in_R8 < 2) {
                        uVar14 = *(undefined8 *)(in_RDX + 0x28);
                        uVar4 = *(undefined8 *)(in_RDX + 0x20);
                        *(undefined4 *)(&stack0xfffffffffffffff8 + iVar10) = (undefined4)var_3e8h;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6494;
                        iVar7 = func_0x000180211bb0(iVar11, uVar4, (int64_t)&arg_28h + iVar10 + 4, uVar14);
                        if ((iVar7 == 0) ||
                           (*(int64_t *)(in_RDX + 8) = (int64_t)*(int32_t *)((int64_t)&arg_28h + iVar10 + 4), iVar6 != 0
                           )) goto code_r0x0001801f605a;
                        uVar14 = *(undefined8 *)((int64_t)&arg_50h + iVar10);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f64bb;
                        iVar6 = fcn.18020efb0(uVar14);
                        if (iVar6 == 6) {
                            *(int64_t *)(in_RDX + 0x20) = *(int64_t *)(in_RDX + 0x20) + 8;
                            *(int64_t *)(in_RDX + 0x28) = *(int64_t *)(in_RDX + 0x28) + 8;
                        } else {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f64d4;
                            iVar6 = fcn.18020efb0(uVar14);
                            if (iVar6 == 7) {
                                *(int64_t *)(in_RDX + 0x20) = *(int64_t *)(in_RDX + 0x20) + 8;
                                *(int64_t *)(in_RDX + 0x28) = *(int64_t *)(in_RDX + 0x28) + 8;
                            } else if ((uVar19 != 1) &&
                                      ((((iVar6 = *(int32_t *)((int64_t)in_RCX + 0x14), iVar6 == 0x302 ||
                                         (iVar6 == 0x303)) || (iVar6 == 0x100)) ||
                                       ((iVar6 == 0xfeff || (iVar6 == 0xfefd)))))) {
                                *(int64_t *)(in_RDX + 0x20) = *(int64_t *)(in_RDX + 0x20) + uVar19;
                                *(int64_t *)(in_RDX + 0x28) = *(int64_t *)(in_RDX + 0x28) + uVar19;
                                *(int64_t *)(in_RDX + 0x10) = *(int64_t *)(in_RDX + 0x10) - uVar19;
                            }
                        }
                        if (iVar23 == 0) goto code_r0x0001801f605a;
                        *(undefined4 *)(iVar23 + 8) = 0;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6548;
                        puVar13 = (undefined4 *)func_0x000180229c20(&var_418h, 0x1804b8258, iVar23, iVar22);
                        var_468h._0_4_ = *puVar13;
                        var_468h._4_4_ = puVar13[1];
                        uStack_460 = puVar13[2];
                        uStack_45c = puVar13[3];
                        var_458h._0_4_ = puVar13[4];
                        var_458h._4_4_ = puVar13[5];
                        uStack_450 = puVar13[6];
                        uStack_44c = puVar13[7];
                        var_448h = *(int64_t *)(puVar13 + 8);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f656a;
                        puVar13 = (undefined4 *)func_0x000180229ba0(&var_418h);
                        var_440h._0_4_ = *puVar13;
                        var_440h._4_4_ = puVar13[1];
                        uStack_438 = puVar13[2];
                        uStack_434 = puVar13[3];
                        var_430h._0_4_ = puVar13[4];
                        var_430h._4_4_ = puVar13[5];
                        uStack_428 = puVar13[6];
                        uStack_424 = puVar13[7];
                        var_420h = *(int64_t *)(puVar13 + 8);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f658f;
                        iVar6 = func_0x000180211450(iVar11, &var_468h);
                        if (iVar6 != 0) goto code_r0x0001801f605a;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f659c;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6467;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                    }
                    goto code_r0x0001801f601e;
                }
                uVar21 = 0;
                piVar18 = (int64_t *)(in_RDX + 0x20);
                do {
                    iVar3 = *piVar18;
                    piVar18 = piVar18 + 9;
                    (&var_2e8h)[uVar21] = iVar3;
                    uVar21 = uVar21 + 1;
                } while (uVar21 < in_R8);
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f634e;
                iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar10));
                if (iVar6 < 1) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6357;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                } else {
                    uVar21 = 0;
                    piVar18 = (int64_t *)(in_RDX + 0x28);
                    do {
                        iVar3 = *piVar18;
                        piVar18 = piVar18 + 9;
                        (&var_2e8h)[uVar21] = iVar3;
                        uVar21 = uVar21 + 1;
                    } while (uVar21 < in_R8);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f63ce;
                    iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar10));
                    if (0 < iVar6) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f63e6;
                        iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar10));
                        if (0 < iVar6) goto code_r0x0001801f63f9;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f63ef;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60fb;
                fcn.18020e940(iVar11);
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6103;
                uVar8 = fcn.18020ef80();
                if ((uVar8 >> 0x17 & 1) != 0) goto code_r0x0001801f6131;
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f610e;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6126;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6040;
    fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar10));
code_r0x0001801f605a:
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6069;
    func_0x000180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar10));
    return;
}

// ============================================================
// Function: FUN_1801f6078
// Address: 0x1801f6078
// Size: 1743 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Removing arg arg_4a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_500h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_49h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ah
// WARNING: [rz-ghidra] Detected overlap for variable arg_4eh

void fcn.1801f5e00(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined2 uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined4 *puVar13;
    undefined8 uVar14;
    undefined8 *in_RCX;
    uint64_t uVar15;
    uint64_t uVar16;
    int64_t in_RDX;
    undefined *puVar17;
    int64_t *piVar18;
    undefined8 unaff_RSI;
    uint64_t uVar19;
    uint64_t in_R8;
    uint64_t uVar20;
    int32_t in_R9D;
    undefined8 unaff_R12;
    uint64_t uVar21;
    int64_t iVar22;
    int64_t iVar23;
    undefined8 unaff_R14;
    int64_t *piVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_488h;
    int64_t var_480h;
    int64_t var_478h;
    int64_t var_468h;
    undefined4 uStack_460;
    undefined4 uStack_45c;
    int64_t var_458h;
    undefined4 uStack_450;
    undefined4 uStack_44c;
    int64_t var_448h;
    int64_t var_440h;
    undefined4 uStack_438;
    undefined4 uStack_434;
    int64_t var_430h;
    undefined4 uStack_428;
    undefined4 uStack_424;
    int64_t var_420h;
    int64_t var_418h;
    int64_t var_3e8h;
    int64_t var_2e8h;
    int64_t var_1dfh;
    int64_t var_48h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801f5e1a;
    iVar10 = fcn.18045a350();
    iVar22 = arg_30h;
    iVar23 = arg_28h;
    iVar10 = -iVar10;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar10);
    var_488h = arg_28h;
    var_480h = arg_30h;
    *(int32_t *)((int64_t)&arg_28h + iVar10) = in_R9D;
    *(undefined4 *)((int64_t)&arg_28h + iVar10 + 4) = 0;
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5e6a;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5e82;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5e98;
        fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar10));
        goto code_r0x0001801f605a;
    }
    uVar14 = in_RCX[0x207];
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5eab;
    iVar11 = fcn.18020e940(uVar14);
    if (iVar11 != 0) {
        uVar14 = in_RCX[0x207];
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5ebc;
        iVar6 = func_0x00018020f590(uVar14);
        if (iVar6 < 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5ec5;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5edd;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5ef3;
            fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar10));
            goto code_r0x0001801f605a;
        }
    }
    *(undefined8 *)(&stack0x000004a8 + iVar10) = unaff_R14;
    iVar11 = in_RCX[0x204];
    *(int64_t *)((int64_t)&arg_30h + iVar10) = iVar11;
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5f18;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5f30;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5f46;
        fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar10));
        goto code_r0x0001801f605a;
    }
    *(undefined8 *)(&stack0x00000500 + iVar10) = unaff_RSI;
    *(undefined8 *)(&stack0x000004b0 + iVar10) = unaff_R12;
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5f65;
    iVar12 = fcn.18020e940(iVar11);
    *(int64_t *)((int64_t)&arg_50h + iVar10) = iVar12;
    if ((in_R9D != 0) &&
       ((((iVar6 = *(int32_t *)((int64_t)in_RCX + 0x14), iVar6 == 0x302 || (iVar6 == 0x303)) || (iVar6 == 0x100)) ||
        ((iVar6 == 0xfeff || (iVar6 == 0xfefd)))))) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5fa8;
        iVar6 = fcn.18020efb0(iVar12);
        if (iVar6 == 2) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5fb5;
            iVar6 = func_0x00018020ef90(iVar12);
            if ((1 < iVar6) && (uVar19 = 0, in_R8 != 0)) {
                piVar18 = (int64_t *)(in_RDX + 0x20);
                do {
                    iVar11 = piVar18[1];
                    if (*piVar18 != iVar11) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6090;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                        goto code_r0x0001801f601e;
                    }
                    uVar14 = *in_RCX;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f5feb;
                    iVar7 = func_0x00018021b9c0(uVar14, iVar11, (int64_t)iVar6, 0);
                    if (iVar7 < 1) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f607d;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                        goto code_r0x0001801f601e;
                    }
                    uVar19 = uVar19 + 1;
                    piVar18 = piVar18 + 9;
                } while (uVar19 < in_R8);
            }
            iVar11 = *(int64_t *)((int64_t)&arg_30h + iVar10);
        }
    }
    if (iVar12 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6012;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
code_r0x0001801f601e:
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f602a;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60a6;
        iVar12 = fcn.18020eec0(iVar12);
        *(int64_t *)((int64_t)&arg_40h + iVar10) = iVar12;
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60b6;
        fcn.18020e940(iVar11);
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60be;
        iVar6 = func_0x00018020ef70();
        uVar19 = (uint64_t)iVar6;
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60ca;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60e2;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
        } else {
            if (in_R8 < 2) {
code_r0x0001801f6131:
                uVar21 = 0;
                if (in_R8 != 0) {
                    piVar24 = &var_1dfh;
                    *(int64_t **)((int64_t)&arg_38h + iVar10) = piVar24;
                    piVar18 = (int64_t *)(in_RDX + 8);
                    do {
                        uVar14 = *(undefined8 *)((int64_t)&arg_30h + iVar10);
                        (&var_3e8h)[uVar21] = *piVar18;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6162;
                        fcn.18020e940(uVar14);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f616a;
                        uVar8 = fcn.18020ef80();
                        if ((uVar8 >> 0x15 & 1) == 0) {
                            if (uVar19 == 1) {
                                *(undefined4 *)((int64_t)&arg_28h + iVar10 + 4) =
                                     *(undefined4 *)((int64_t)&arg_28h + iVar10 + 4);
                                if (*(int32_t *)((int64_t)&arg_28h + iVar10) == 0) goto code_r0x0001801f62c9;
                            } else if (*(int32_t *)((int64_t)&arg_28h + iVar10) == 0) {
code_r0x0001801f62c9:
                                if (((&var_3e8h)[uVar21] == 0) || ((uint64_t)(&var_3e8h)[uVar21] % uVar19 != 0))
                                goto code_r0x0001801f605a;
                            } else if (*(int64_t *)((int64_t)&arg_40h + iVar10) == 0) {
                                uVar16 = (&var_3e8h)[uVar21];
                                uVar20 = uVar19 - uVar16 % uVar19;
                                if (0x100 < uVar20) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f637c;
                                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                                    goto code_r0x0001801f601e;
                                }
                                uVar15 = uVar16;
                                if (uVar16 < uVar16 + uVar20) {
                                    do {
                                        *(char *)(uVar15 + piVar18[4]) = (char)uVar20 + -1;
                                        uVar15 = uVar15 + 1;
                                        uVar16 = (&var_3e8h)[uVar21];
                                    } while (uVar15 < uVar16 + uVar20);
                                }
                                *piVar18 = *piVar18 + uVar20;
                                (&var_3e8h)[uVar21] = uVar16 + uVar20;
                            }
                        } else {
                            puVar17 = *(undefined **)((int64_t)&arg_38h + iVar10);
                            if (*(int32_t *)(in_RCX + 2) == 0) {
                                *(undefined8 *)(puVar17 + -9) = in_RCX[0x200];
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f61c8;
                                iVar6 = func_0x0001801d4800(in_RCX);
                                if (iVar6 == 0) goto code_r0x0001801f605a;
                                puVar17 = *(undefined **)((int64_t)&arg_38h + iVar10);
                            } else {
                                uVar1 = *(undefined2 *)(in_RCX + 6);
                                *(char *)((int64_t)&arg_48h + iVar10 + 1) = (char)uVar1;
                                *(char *)((int64_t)&arg_48h + iVar10) = (char)((uint16_t)uVar1 >> 8);
                                *(undefined4 *)((int64_t)&arg_48h + iVar10 + 2) =
                                     *(undefined4 *)((int64_t)in_RCX + 0x1002);
                                *(undefined2 *)((int64_t)&arg_48h + iVar10 + 6) =
                                     *(undefined2 *)((int64_t)in_RCX + 0x1006);
                                *(undefined8 *)(puVar17 + -9) = *(undefined8 *)((int64_t)&arg_48h + iVar10);
                            }
                            uVar2 = *(undefined4 *)((int64_t)in_RCX + 0x14);
                            puVar17[-1] = *(undefined *)((int64_t)piVar18 + -4);
                            puVar17[1] = (char)uVar2;
                            iVar11 = *piVar18;
                            *puVar17 = (char)((uint32_t)uVar2 >> 8);
                            puVar17[3] = (char)iVar11;
                            puVar17[2] = (char)((uint64_t)iVar11 >> 8);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6211;
                            iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar10));
                            *(int32_t *)((int64_t)&arg_28h + iVar10 + 4) = iVar6;
                            if (iVar6 < 1) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6366;
                                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                                goto code_r0x0001801f601e;
                            }
                            piVar24 = *(int64_t **)((int64_t)&arg_38h + iVar10);
                            if (*(int32_t *)((int64_t)&arg_28h + iVar10) == 0) goto code_r0x0001801f62c9;
                            (&var_3e8h)[uVar21] = (&var_3e8h)[uVar21] + (int64_t)iVar6;
                            *piVar18 = *piVar18 + (int64_t)iVar6;
                        }
                        piVar24 = (int64_t *)((int64_t)piVar24 + 0xd);
                        uVar21 = uVar21 + 1;
                        piVar18 = piVar18 + 9;
                        *(int64_t **)((int64_t)&arg_38h + iVar10) = piVar24;
                    } while (uVar21 < in_R8);
                    iVar11 = *(int64_t *)((int64_t)&arg_30h + iVar10);
                    iVar12 = *(int64_t *)((int64_t)&arg_40h + iVar10);
                }
                if (in_R8 < 2) {
code_r0x0001801f63f9:
                    iVar6 = *(int32_t *)((int64_t)&arg_28h + iVar10);
                    if ((*(int32_t *)(in_RCX + 2) == 0) && (*(int32_t *)(in_RCX + 0x217) != 0)) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6439;
                        iVar7 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar10));
                        if (iVar7 < 1) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6442;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                            goto code_r0x0001801f601e;
                        }
                    }
                    if (iVar12 == 0) {
                        uVar14 = *(undefined8 *)(in_RDX + 0x20);
                        piVar18 = (int64_t *)(in_RDX + 0x20);
                        uVar4 = *(undefined8 *)(in_RDX + 0x28);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f65c5;
                        uVar8 = func_0x00018020f460(iVar11, uVar14, uVar4, (undefined4)var_3e8h);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f65d2;
                        uVar14 = fcn.18020e940(*(undefined8 *)((int64_t)&arg_30h + iVar10));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f65da;
                        uVar9 = fcn.18020ef80(uVar14);
                        if ((uVar9 >> 0x14 & 1) == 0) {
                            uVar8 = (uint32_t)(uVar8 == 0);
                        } else {
                            uVar8 = uVar8 >> 0x1f;
                        }
                        if (((uVar8 == 0) && (iVar6 == 0)) &&
                           (*(undefined8 *)((int64_t)&arg_40h + iVar10) = 0, var_478h = in_R8, in_R8 != 0)) {
                            do {
                                uVar14 = *(undefined8 *)((int64_t)&arg_50h + iVar10);
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f662d;
                                iVar6 = fcn.18020efb0(uVar14);
                                if (iVar6 == 6) {
                                    *piVar18 = *piVar18 + 8;
                                    piVar18[1] = piVar18[1] + 8;
                                    piVar18[-3] = piVar18[-3] + -8;
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f664a;
                                    iVar6 = fcn.18020efb0(uVar14);
                                    if (iVar6 == 7) {
                                        *piVar18 = *piVar18 + 8;
                                        piVar18[1] = piVar18[1] + 8;
                                        piVar18[-3] = piVar18[-3] + -8;
                                    } else if ((uVar19 != 1) &&
                                              (((iVar6 = *(int32_t *)((int64_t)in_RCX + 0x14), iVar6 == 0x302 ||
                                                (iVar6 == 0x303)) ||
                                               ((iVar6 == 0x100 || ((iVar6 == 0xfeff || (iVar6 == 0xfefd)))))))) {
                                        if ((uint64_t)piVar18[-3] < uVar19) break;
                                        *piVar18 = *piVar18 + uVar19;
                                        piVar18[1] = piVar18[1] + uVar19;
                                        piVar18[-2] = piVar18[-2] - uVar19;
                                        piVar18[-3] = piVar18[-3] - uVar19;
                                    }
                                }
                                iVar6 = *(int32_t *)((int64_t)&arg_28h + iVar10 + 4);
                                iVar22 = (int64_t)iVar6;
                                if (iVar6 == 0) {
                                    iVar22 = var_480h;
                                }
                                if (var_488h == 0) {
                                    iVar11 = 0;
                                    iVar12 = 0;
                                } else {
                                    iVar11 = iVar23 + 8;
                                    iVar12 = iVar23;
                                }
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f66d8;
                                uVar8 = fcn.18020ef80(*(undefined8 *)((int64_t)&arg_50h + iVar10));
                                iVar3 = *piVar18;
                                *(undefined8 *)((int64_t)&iStackX_20 + iVar10 + -8) = *in_RCX;
                                *(uint32_t *)((int64_t)&var_10h + iVar10) = (uint32_t)((uVar8 >> 0x15 & 1) != 0);
                                iVar5 = piVar18[-2];
                                *(int64_t *)((int64_t)&var_8h + iVar10) = iVar22;
                                *(uint64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20) = uVar19;
                                *(int64_t *)(&stack0xfffffffffffffff8 + iVar10) = iVar11;
                                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6712;
                                iVar6 = func_0x0001802732b0(piVar18 + -3, iVar5, iVar3, iVar12);
                                if (iVar6 == 0) break;
                                iVar23 = iVar23 + 0x10;
                                uVar21 = *(int64_t *)((int64_t)&arg_40h + iVar10) + 1;
                                piVar18 = piVar18 + 9;
                                *(uint64_t *)((int64_t)&arg_40h + iVar10) = uVar21;
                            } while (uVar21 < (uint64_t)var_478h);
                        }
                        goto code_r0x0001801f605a;
                    }
                    if (in_R8 < 2) {
                        uVar14 = *(undefined8 *)(in_RDX + 0x28);
                        uVar4 = *(undefined8 *)(in_RDX + 0x20);
                        *(undefined4 *)(&stack0xfffffffffffffff8 + iVar10) = (undefined4)var_3e8h;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6494;
                        iVar7 = func_0x000180211bb0(iVar11, uVar4, (int64_t)&arg_28h + iVar10 + 4, uVar14);
                        if ((iVar7 == 0) ||
                           (*(int64_t *)(in_RDX + 8) = (int64_t)*(int32_t *)((int64_t)&arg_28h + iVar10 + 4), iVar6 != 0
                           )) goto code_r0x0001801f605a;
                        uVar14 = *(undefined8 *)((int64_t)&arg_50h + iVar10);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f64bb;
                        iVar6 = fcn.18020efb0(uVar14);
                        if (iVar6 == 6) {
                            *(int64_t *)(in_RDX + 0x20) = *(int64_t *)(in_RDX + 0x20) + 8;
                            *(int64_t *)(in_RDX + 0x28) = *(int64_t *)(in_RDX + 0x28) + 8;
                        } else {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f64d4;
                            iVar6 = fcn.18020efb0(uVar14);
                            if (iVar6 == 7) {
                                *(int64_t *)(in_RDX + 0x20) = *(int64_t *)(in_RDX + 0x20) + 8;
                                *(int64_t *)(in_RDX + 0x28) = *(int64_t *)(in_RDX + 0x28) + 8;
                            } else if ((uVar19 != 1) &&
                                      ((((iVar6 = *(int32_t *)((int64_t)in_RCX + 0x14), iVar6 == 0x302 ||
                                         (iVar6 == 0x303)) || (iVar6 == 0x100)) ||
                                       ((iVar6 == 0xfeff || (iVar6 == 0xfefd)))))) {
                                *(int64_t *)(in_RDX + 0x20) = *(int64_t *)(in_RDX + 0x20) + uVar19;
                                *(int64_t *)(in_RDX + 0x28) = *(int64_t *)(in_RDX + 0x28) + uVar19;
                                *(int64_t *)(in_RDX + 0x10) = *(int64_t *)(in_RDX + 0x10) - uVar19;
                            }
                        }
                        if (iVar23 == 0) goto code_r0x0001801f605a;
                        *(undefined4 *)(iVar23 + 8) = 0;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6548;
                        puVar13 = (undefined4 *)func_0x000180229c20(&var_418h, 0x1804b8258, iVar23, iVar22);
                        var_468h._0_4_ = *puVar13;
                        var_468h._4_4_ = puVar13[1];
                        uStack_460 = puVar13[2];
                        uStack_45c = puVar13[3];
                        var_458h._0_4_ = puVar13[4];
                        var_458h._4_4_ = puVar13[5];
                        uStack_450 = puVar13[6];
                        uStack_44c = puVar13[7];
                        var_448h = *(int64_t *)(puVar13 + 8);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f656a;
                        puVar13 = (undefined4 *)func_0x000180229ba0(&var_418h);
                        var_440h._0_4_ = *puVar13;
                        var_440h._4_4_ = puVar13[1];
                        uStack_438 = puVar13[2];
                        uStack_434 = puVar13[3];
                        var_430h._0_4_ = puVar13[4];
                        var_430h._4_4_ = puVar13[5];
                        uStack_428 = puVar13[6];
                        uStack_424 = puVar13[7];
                        var_420h = *(int64_t *)(puVar13 + 8);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f658f;
                        iVar6 = func_0x000180211450(iVar11, &var_468h);
                        if (iVar6 != 0) goto code_r0x0001801f605a;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f659c;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6467;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                    }
                    goto code_r0x0001801f601e;
                }
                uVar21 = 0;
                piVar18 = (int64_t *)(in_RDX + 0x20);
                do {
                    iVar3 = *piVar18;
                    piVar18 = piVar18 + 9;
                    (&var_2e8h)[uVar21] = iVar3;
                    uVar21 = uVar21 + 1;
                } while (uVar21 < in_R8);
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f634e;
                iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar10));
                if (iVar6 < 1) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6357;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                } else {
                    uVar21 = 0;
                    piVar18 = (int64_t *)(in_RDX + 0x28);
                    do {
                        iVar3 = *piVar18;
                        piVar18 = piVar18 + 9;
                        (&var_2e8h)[uVar21] = iVar3;
                        uVar21 = uVar21 + 1;
                    } while (uVar21 < in_R8);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f63ce;
                    iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar10));
                    if (0 < iVar6) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f63e6;
                        iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar10));
                        if (0 < iVar6) goto code_r0x0001801f63f9;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f63ef;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f60fb;
                fcn.18020e940(iVar11);
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6103;
                uVar8 = fcn.18020ef80();
                if ((uVar8 >> 0x17 & 1) != 0) goto code_r0x0001801f6131;
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f610e;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20));
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6126;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10));
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6040;
    fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar10));
code_r0x0001801f605a:
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801f6069;
    func_0x000180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar10));
    return;
}

// ============================================================
// Function: FUN_1801f6750
// Address: 0x1801f6750
// Size: 595 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_17h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_16h
// WARNING: [rz-ghidra] Detected overlap for variable var_12h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_46h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_45h

void fcn.1801f6750(int64_t arg_f0h)
{
    undefined2 uVar1;
    undefined8 uVar2;
    char cVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined4 *puVar8;
    int64_t in_RCX;
    uint64_t uVar9;
    int64_t in_RDX;
    int64_t iVar10;
    undefined8 in_R8;
    int32_t in_R9D;
    int64_t var_20h;
    int64_t var_d8h;
    int64_t var_c8h;
    undefined4 uStack_c0;
    undefined4 uStack_bc;
    int64_t var_b8h;
    undefined4 uStack_b0;
    undefined4 uStack_ac;
    int64_t var_a8h;
    int64_t var_a0h;
    undefined4 uStack_98;
    undefined4 uStack_94;
    int64_t var_90h;
    undefined4 uStack_88;
    undefined4 uStack_84;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_10h;
    
    var_40h = 0x1801f676f;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    var_40h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar5);
    iVar10 = *(int64_t *)(in_RCX + 0x1038);
    iVar6 = 0;
    *(undefined8 *)((int64_t)&var_40h + iVar5) = 0x1801f67a1;
    iVar4 = func_0x00018020f590(iVar10);
    if (iVar4 < 0) goto code_r0x0001801f697c;
    *(int64_t *)((int64_t)&var_10h + iVar5) = (int64_t)iVar4;
    if (*(int32_t *)(in_RCX + 0x10b4) == 0) {
        *(undefined8 *)((int64_t)&var_40h + iVar5) = 0x1801f67c0;
        iVar6 = fcn.180215470();
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&var_40h + iVar5) = 0x1801f67d7;
            iVar4 = func_0x000180214ac0(iVar6, iVar10);
            iVar10 = iVar6;
            if (iVar4 != 0) goto code_r0x0001801f67e2;
        }
    } else {
code_r0x0001801f67e2:
        if (*(int32_t *)(in_RCX + 0x10) == 0) {
            if (*(int32_t *)(in_RCX + 0x10b8) != 0) {
                *(undefined8 *)((int64_t)&var_40h + iVar5) = 0x1801f6808;
                iVar4 = func_0x000180215040(iVar10, 4, 0, in_RCX + 0x1000);
                if (iVar4 < 1) goto code_r0x0001801f6971;
            }
            if (*(int32_t *)(in_RCX + 0x10) != 0) goto code_r0x0001801f6816;
            var_50h = *(int64_t *)(in_RCX + 0x1000);
        } else {
code_r0x0001801f6816:
            uVar1 = *(undefined2 *)(in_RCX + 0x30);
            (&stack0xffffffffffffffe9)[iVar5] = (char)uVar1;
            (&stack0xffffffffffffffe8)[iVar5] = (char)((uint16_t)uVar1 >> 8);
            *(undefined4 *)(&stack0xffffffffffffffea + iVar5) = *(undefined4 *)(in_RCX + 0x1002);
            *(undefined2 *)(&stack0xffffffffffffffee + iVar5) = *(undefined2 *)(in_RCX + 0x1006);
            var_50h = *(int64_t *)(&stack0xffffffffffffffe8 + iVar5);
        }
        var_48h._0_1_ = *(undefined *)(in_RDX + 4);
        var_48h._1_1_ = (undefined)((uint32_t)*(undefined4 *)(in_RCX + 0x14) >> 8);
        var_48h._2_1_ = (undefined)*(undefined4 *)(in_RCX + 0x14);
        var_48h._4_1_ = (undefined)*(undefined8 *)(in_RDX + 8);
        var_48h._3_1_ = (undefined)((uint64_t)*(undefined8 *)(in_RDX + 8) >> 8);
        if ((in_R9D == 0) && (*(int32_t *)(in_RCX + 0x10b0) == 0)) {
            uVar7 = *(undefined8 *)(in_RCX + 0x1020);
            *(undefined8 *)((int64_t)&var_40h + iVar5) = 0x1801f689a;
            uVar7 = fcn.18020e940(uVar7);
            *(undefined8 *)((int64_t)&var_40h + iVar5) = 0x1801f68a2;
            iVar4 = fcn.18020efb0(uVar7);
            if (iVar4 == 2) {
                *(undefined8 *)((int64_t)&var_40h + iVar5) = 0x1801f68af;
                cVar3 = func_0x0001801d5830(iVar10);
                if (cVar3 != '\0') {
                    *(undefined8 *)((int64_t)&var_40h + iVar5) = 0x1801f68c7;
                    puVar8 = (undefined4 *)fcn.180229cc0(&var_78h, 0x1804b83d8, in_RDX + 0x10);
                    var_c8h._0_4_ = *puVar8;
                    var_c8h._4_4_ = puVar8[1];
                    uStack_c0 = puVar8[2];
                    uStack_bc = puVar8[3];
                    var_b8h._0_4_ = puVar8[4];
                    var_b8h._4_4_ = puVar8[5];
                    uStack_b0 = puVar8[6];
                    uStack_ac = puVar8[7];
                    var_a8h = *(int64_t *)(puVar8 + 8);
                    *(undefined8 *)((int64_t)&var_40h + iVar5) = 0x1801f68e9;
                    puVar8 = (undefined4 *)func_0x000180229ba0(&var_78h);
                    var_a0h._0_4_ = *puVar8;
                    var_a0h._4_4_ = puVar8[1];
                    uStack_98 = puVar8[2];
                    uStack_94 = puVar8[3];
                    var_90h._0_4_ = puVar8[4];
                    var_90h._4_4_ = puVar8[5];
                    uStack_88 = puVar8[6];
                    uStack_84 = puVar8[7];
                    var_80h = *(int64_t *)(puVar8 + 8);
                    *(undefined8 *)((int64_t)&var_40h + iVar5) = 0x1801f690a;
                    uVar7 = func_0x000180192480(iVar10);
                    *(undefined8 *)((int64_t)&var_40h + iVar5) = 0x1801f6916;
                    iVar4 = func_0x0001802592f0(uVar7, &var_c8h);
                    if (iVar4 == 0) goto code_r0x0001801f6971;
                }
            }
        }
        *(undefined8 *)((int64_t)&var_40h + iVar5) = 0x1801f692c;
        iVar4 = func_0x00018025c340(iVar10, &var_50h, 0xd);
        if (0 < iVar4) {
            uVar7 = *(undefined8 *)(in_RDX + 8);
            uVar2 = *(undefined8 *)(in_RDX + 0x28);
            *(undefined8 *)((int64_t)&var_40h + iVar5) = 0x1801f6940;
            iVar4 = func_0x00018025c340(iVar10, uVar2, uVar7);
            if (0 < iVar4) {
                *(undefined8 *)((int64_t)&var_40h + iVar5) = 0x1801f6955;
                iVar4 = func_0x00018025be60(iVar10, in_R8, (int64_t)&var_10h + iVar5);
                if ((0 < iVar4) && (*(int32_t *)(in_RCX + 0x10) == 0)) {
                    *(undefined8 *)((int64_t)&var_40h + iVar5) = 0x1801f6967;
                    func_0x0001801d4800(in_RCX);
                }
            }
        }
    }
code_r0x0001801f6971:
    *(undefined8 *)((int64_t)&var_40h + iVar5) = 0x1801f6979;
    func_0x000180215310(iVar6);
code_r0x0001801f697c:
    uVar9 = var_40h ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar5);
    *(undefined8 *)((int64_t)&var_40h + iVar5) = 0x1801f6988;
    func_0x000180459870(uVar9);
    return;
}

// ============================================================
// Function: FUN_1801f69b0
// Address: 0x1801f69b0
// Size: 149 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8
fcn.1801f69b0(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h,
             int64_t arg_98h, int64_t arg_b8h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_f8h, int64_t arg_100h,
             int64_t arg_108h, int64_t arg_110h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined4 *puVar11;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    undefined8 in_R8;
    undefined8 in_R9;
    uint32_t uVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f69ca;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    uVar1 = *(undefined8 *)((int64_t)&arg_e0h + iVar8);
    iVar7 = *(int32_t *)(in_RCX + 0x1c);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f69fe;
    iVar9 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
    *(int64_t *)(in_RCX + 0x10c0) = iVar9;
    if (iVar9 == 0) {
        return 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6a23;
    iVar9 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
    *(int64_t *)(in_RCX + 0x10c8) = iVar9;
    if (iVar9 == 0) {
        return 0xfffffffe;
    }
    uVar2 = *(undefined8 *)(in_RCX + 0x10c0);
    *(undefined8 *)((int64_t)&arg_b8h + iVar8) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6a52;
    fcn.180498030(uVar2, *(undefined8 *)((int64_t)&arg_d8h + iVar8), uVar1);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6a66;
    iVar6 = fcn.18020f2b0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar8), 
                          *(int64_t *)(&stack0x00000028 + iVar8), *(int64_t *)(&stack0x00000030 + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar8), *(int64_t *)(&stack0x00000040 + iVar8));
    if (((iVar6 != 0) && (*(int32_t *)((int64_t)&arg_108h + iVar8) == 0x357)) &&
       (*(int64_t *)((int64_t)&arg_110h + iVar8) != 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6aa1;
        iVar9 = fcn.180256ae0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6ab5;
            iVar10 = fcn.1802570e0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
            *(int64_t *)(in_RCX + 0x1028) = iVar10;
            if (iVar10 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6ad0;
                fcn.180256b30(iVar9);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6add;
                fcn.18020f750(*(undefined8 *)((int64_t)&arg_110h + iVar8));
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6af4;
                puVar11 = (undefined4 *)
                          fcn.180229e30(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8)
                                        , *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), 
                                        *(int64_t *)(&stack0x00000038 + iVar8), *(int64_t *)(&stack0x00000040 + iVar8));
                uVar3 = puVar11[1];
                uVar4 = puVar11[2];
                uVar5 = puVar11[3];
                *(undefined4 *)((int64_t)&arg_48h + iVar8) = *puVar11;
                *(undefined4 *)((int64_t)&arg_48h + iVar8 + 4) = uVar3;
                *(undefined4 *)(&stack0x00000050 + iVar8) = uVar4;
                *(undefined4 *)(&stack0x00000054 + iVar8) = uVar5;
                uVar3 = puVar11[5];
                uVar4 = puVar11[6];
                uVar5 = puVar11[7];
                *(undefined4 *)((int64_t)&arg_58h + iVar8) = puVar11[4];
                *(undefined4 *)((int64_t)&arg_58h + iVar8 + 4) = uVar3;
                *(undefined4 *)(&stack0x00000060 + iVar8) = uVar4;
                *(undefined4 *)(&stack0x00000064 + iVar8) = uVar5;
                *(undefined8 *)((int64_t)&arg_68h + iVar8) = *(undefined8 *)(puVar11 + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6b1d;
                puVar11 = (undefined4 *)fcn.180229ba0((int64_t)&iStackX_20 + iVar8 + -8);
                uVar3 = puVar11[1];
                uVar4 = puVar11[2];
                uVar5 = puVar11[3];
                *(undefined4 *)((int64_t)&arg_70h + iVar8) = *puVar11;
                *(undefined4 *)((int64_t)&arg_70h + iVar8 + 4) = uVar3;
                *(undefined4 *)(&stack0x00000078 + iVar8) = uVar4;
                *(undefined4 *)(&stack0x0000007c + iVar8) = uVar5;
                uVar3 = puVar11[5];
                uVar4 = puVar11[6];
                uVar5 = puVar11[7];
                *(undefined4 *)((int64_t)&arg_80h + iVar8) = puVar11[4];
                *(undefined4 *)((int64_t)&arg_80h + iVar8 + 4) = uVar3;
                *(undefined4 *)(&stack0x00000088 + iVar8) = uVar4;
                *(undefined4 *)(&stack0x0000008c + iVar8) = uVar5;
                *(undefined8 *)((int64_t)&arg_90h + iVar8) = *(undefined8 *)(puVar11 + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6b55;
                iVar7 = fcn.180257420(iVar10, in_R8, in_R9, (int64_t)&arg_48h + iVar8);
                if (iVar7 != 0) {
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6b62;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
                goto code_r0x0001801f6b6e;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6bbb;
        fcn.180256b30(iVar9);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6bc0;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        goto code_r0x0001801f6b6e;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6bd3;
    iVar9 = fcn.180211490();
    *(int64_t *)(in_RCX + 0x1020) = iVar9;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6be7;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        goto code_r0x0001801f6b6e;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c05;
    iVar6 = fcn.18020efb0(*(undefined8 *)((int64_t)&arg_f8h + iVar8));
    uVar12 = (uint32_t)(iVar7 == 1);
    *(uint32_t *)((int64_t)&var_10h + iVar8) = uVar12;
    *(undefined8 *)((int64_t)&var_8h + iVar8) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c2b;
    iVar7 = fcn.180211b70(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), *(int64_t *)(&stack0x00000050 + iVar8), 
                          *(int64_t *)((int64_t)&arg_58h + iVar8));
    if (0 < iVar7) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c42;
        iVar7 = fcn.180210b80(*(int64_t *)((int64_t)&iStackX_20 + iVar8), *(int64_t *)(&stack0x00000028 + iVar8), 
                              *(int64_t *)(&stack0x00000030 + iVar8), *(int64_t *)(&stack0x00000038 + iVar8));
        if (0 < iVar7) {
            if (iVar6 == 7) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c63;
                iVar7 = fcn.180210b80(*(int64_t *)((int64_t)&iStackX_20 + iVar8), *(int64_t *)(&stack0x00000028 + iVar8)
                                      , *(int64_t *)(&stack0x00000030 + iVar8), *(int64_t *)(&stack0x00000038 + iVar8));
                if (iVar7 < 1) goto code_r0x0001801f6c93;
            }
            *(uint32_t *)((int64_t)&var_10h + iVar8) = uVar12;
            *(undefined8 *)((int64_t)&var_8h + iVar8) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c85;
            iVar7 = fcn.180211b70(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), 
                                  *(int64_t *)(&stack0x00000050 + iVar8), *(int64_t *)((int64_t)&arg_58h + iVar8));
            if (0 < iVar7) {
                return 1;
            }
        }
    }
code_r0x0001801f6c93:
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c98;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
code_r0x0001801f6b6e:
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6b7a;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                  *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar8), 
                  *(int64_t *)(&stack0x00000038 + iVar8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6b8c;
    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_1801f6a45
// Address: 0x1801f6a45
// Size: 340 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8
fcn.1801f69b0(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h,
             int64_t arg_98h, int64_t arg_b8h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_f8h, int64_t arg_100h,
             int64_t arg_108h, int64_t arg_110h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined4 *puVar11;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    undefined8 in_R8;
    undefined8 in_R9;
    uint32_t uVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f69ca;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    uVar1 = *(undefined8 *)((int64_t)&arg_e0h + iVar8);
    iVar7 = *(int32_t *)(in_RCX + 0x1c);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f69fe;
    iVar9 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
    *(int64_t *)(in_RCX + 0x10c0) = iVar9;
    if (iVar9 == 0) {
        return 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6a23;
    iVar9 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
    *(int64_t *)(in_RCX + 0x10c8) = iVar9;
    if (iVar9 == 0) {
        return 0xfffffffe;
    }
    uVar2 = *(undefined8 *)(in_RCX + 0x10c0);
    *(undefined8 *)((int64_t)&arg_b8h + iVar8) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6a52;
    fcn.180498030(uVar2, *(undefined8 *)((int64_t)&arg_d8h + iVar8), uVar1);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6a66;
    iVar6 = fcn.18020f2b0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar8), 
                          *(int64_t *)(&stack0x00000028 + iVar8), *(int64_t *)(&stack0x00000030 + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar8), *(int64_t *)(&stack0x00000040 + iVar8));
    if (((iVar6 != 0) && (*(int32_t *)((int64_t)&arg_108h + iVar8) == 0x357)) &&
       (*(int64_t *)((int64_t)&arg_110h + iVar8) != 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6aa1;
        iVar9 = fcn.180256ae0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6ab5;
            iVar10 = fcn.1802570e0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
            *(int64_t *)(in_RCX + 0x1028) = iVar10;
            if (iVar10 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6ad0;
                fcn.180256b30(iVar9);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6add;
                fcn.18020f750(*(undefined8 *)((int64_t)&arg_110h + iVar8));
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6af4;
                puVar11 = (undefined4 *)
                          fcn.180229e30(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8)
                                        , *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), 
                                        *(int64_t *)(&stack0x00000038 + iVar8), *(int64_t *)(&stack0x00000040 + iVar8));
                uVar3 = puVar11[1];
                uVar4 = puVar11[2];
                uVar5 = puVar11[3];
                *(undefined4 *)((int64_t)&arg_48h + iVar8) = *puVar11;
                *(undefined4 *)((int64_t)&arg_48h + iVar8 + 4) = uVar3;
                *(undefined4 *)(&stack0x00000050 + iVar8) = uVar4;
                *(undefined4 *)(&stack0x00000054 + iVar8) = uVar5;
                uVar3 = puVar11[5];
                uVar4 = puVar11[6];
                uVar5 = puVar11[7];
                *(undefined4 *)((int64_t)&arg_58h + iVar8) = puVar11[4];
                *(undefined4 *)((int64_t)&arg_58h + iVar8 + 4) = uVar3;
                *(undefined4 *)(&stack0x00000060 + iVar8) = uVar4;
                *(undefined4 *)(&stack0x00000064 + iVar8) = uVar5;
                *(undefined8 *)((int64_t)&arg_68h + iVar8) = *(undefined8 *)(puVar11 + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6b1d;
                puVar11 = (undefined4 *)fcn.180229ba0((int64_t)&iStackX_20 + iVar8 + -8);
                uVar3 = puVar11[1];
                uVar4 = puVar11[2];
                uVar5 = puVar11[3];
                *(undefined4 *)((int64_t)&arg_70h + iVar8) = *puVar11;
                *(undefined4 *)((int64_t)&arg_70h + iVar8 + 4) = uVar3;
                *(undefined4 *)(&stack0x00000078 + iVar8) = uVar4;
                *(undefined4 *)(&stack0x0000007c + iVar8) = uVar5;
                uVar3 = puVar11[5];
                uVar4 = puVar11[6];
                uVar5 = puVar11[7];
                *(undefined4 *)((int64_t)&arg_80h + iVar8) = puVar11[4];
                *(undefined4 *)((int64_t)&arg_80h + iVar8 + 4) = uVar3;
                *(undefined4 *)(&stack0x00000088 + iVar8) = uVar4;
                *(undefined4 *)(&stack0x0000008c + iVar8) = uVar5;
                *(undefined8 *)((int64_t)&arg_90h + iVar8) = *(undefined8 *)(puVar11 + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6b55;
                iVar7 = fcn.180257420(iVar10, in_R8, in_R9, (int64_t)&arg_48h + iVar8);
                if (iVar7 != 0) {
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6b62;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
                goto code_r0x0001801f6b6e;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6bbb;
        fcn.180256b30(iVar9);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6bc0;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        goto code_r0x0001801f6b6e;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6bd3;
    iVar9 = fcn.180211490();
    *(int64_t *)(in_RCX + 0x1020) = iVar9;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6be7;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        goto code_r0x0001801f6b6e;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c05;
    iVar6 = fcn.18020efb0(*(undefined8 *)((int64_t)&arg_f8h + iVar8));
    uVar12 = (uint32_t)(iVar7 == 1);
    *(uint32_t *)((int64_t)&var_10h + iVar8) = uVar12;
    *(undefined8 *)((int64_t)&var_8h + iVar8) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c2b;
    iVar7 = fcn.180211b70(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), *(int64_t *)(&stack0x00000050 + iVar8), 
                          *(int64_t *)((int64_t)&arg_58h + iVar8));
    if (0 < iVar7) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c42;
        iVar7 = fcn.180210b80(*(int64_t *)((int64_t)&iStackX_20 + iVar8), *(int64_t *)(&stack0x00000028 + iVar8), 
                              *(int64_t *)(&stack0x00000030 + iVar8), *(int64_t *)(&stack0x00000038 + iVar8));
        if (0 < iVar7) {
            if (iVar6 == 7) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c63;
                iVar7 = fcn.180210b80(*(int64_t *)((int64_t)&iStackX_20 + iVar8), *(int64_t *)(&stack0x00000028 + iVar8)
                                      , *(int64_t *)(&stack0x00000030 + iVar8), *(int64_t *)(&stack0x00000038 + iVar8));
                if (iVar7 < 1) goto code_r0x0001801f6c93;
            }
            *(uint32_t *)((int64_t)&var_10h + iVar8) = uVar12;
            *(undefined8 *)((int64_t)&var_8h + iVar8) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c85;
            iVar7 = fcn.180211b70(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), 
                                  *(int64_t *)(&stack0x00000050 + iVar8), *(int64_t *)((int64_t)&arg_58h + iVar8));
            if (0 < iVar7) {
                return 1;
            }
        }
    }
code_r0x0001801f6c93:
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c98;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
code_r0x0001801f6b6e:
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6b7a;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                  *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar8), 
                  *(int64_t *)(&stack0x00000038 + iVar8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6b8c;
    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_1801f6b99
// Address: 0x1801f6b99
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8
fcn.1801f69b0(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h,
             int64_t arg_98h, int64_t arg_b8h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_f8h, int64_t arg_100h,
             int64_t arg_108h, int64_t arg_110h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined4 *puVar11;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    undefined8 in_R8;
    undefined8 in_R9;
    uint32_t uVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f69ca;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    uVar1 = *(undefined8 *)((int64_t)&arg_e0h + iVar8);
    iVar7 = *(int32_t *)(in_RCX + 0x1c);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f69fe;
    iVar9 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
    *(int64_t *)(in_RCX + 0x10c0) = iVar9;
    if (iVar9 == 0) {
        return 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6a23;
    iVar9 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
    *(int64_t *)(in_RCX + 0x10c8) = iVar9;
    if (iVar9 == 0) {
        return 0xfffffffe;
    }
    uVar2 = *(undefined8 *)(in_RCX + 0x10c0);
    *(undefined8 *)((int64_t)&arg_b8h + iVar8) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6a52;
    fcn.180498030(uVar2, *(undefined8 *)((int64_t)&arg_d8h + iVar8), uVar1);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6a66;
    iVar6 = fcn.18020f2b0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar8), 
                          *(int64_t *)(&stack0x00000028 + iVar8), *(int64_t *)(&stack0x00000030 + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar8), *(int64_t *)(&stack0x00000040 + iVar8));
    if (((iVar6 != 0) && (*(int32_t *)((int64_t)&arg_108h + iVar8) == 0x357)) &&
       (*(int64_t *)((int64_t)&arg_110h + iVar8) != 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6aa1;
        iVar9 = fcn.180256ae0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6ab5;
            iVar10 = fcn.1802570e0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
            *(int64_t *)(in_RCX + 0x1028) = iVar10;
            if (iVar10 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6ad0;
                fcn.180256b30(iVar9);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6add;
                fcn.18020f750(*(undefined8 *)((int64_t)&arg_110h + iVar8));
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6af4;
                puVar11 = (undefined4 *)
                          fcn.180229e30(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8)
                                        , *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), 
                                        *(int64_t *)(&stack0x00000038 + iVar8), *(int64_t *)(&stack0x00000040 + iVar8));
                uVar3 = puVar11[1];
                uVar4 = puVar11[2];
                uVar5 = puVar11[3];
                *(undefined4 *)((int64_t)&arg_48h + iVar8) = *puVar11;
                *(undefined4 *)((int64_t)&arg_48h + iVar8 + 4) = uVar3;
                *(undefined4 *)(&stack0x00000050 + iVar8) = uVar4;
                *(undefined4 *)(&stack0x00000054 + iVar8) = uVar5;
                uVar3 = puVar11[5];
                uVar4 = puVar11[6];
                uVar5 = puVar11[7];
                *(undefined4 *)((int64_t)&arg_58h + iVar8) = puVar11[4];
                *(undefined4 *)((int64_t)&arg_58h + iVar8 + 4) = uVar3;
                *(undefined4 *)(&stack0x00000060 + iVar8) = uVar4;
                *(undefined4 *)(&stack0x00000064 + iVar8) = uVar5;
                *(undefined8 *)((int64_t)&arg_68h + iVar8) = *(undefined8 *)(puVar11 + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6b1d;
                puVar11 = (undefined4 *)fcn.180229ba0((int64_t)&iStackX_20 + iVar8 + -8);
                uVar3 = puVar11[1];
                uVar4 = puVar11[2];
                uVar5 = puVar11[3];
                *(undefined4 *)((int64_t)&arg_70h + iVar8) = *puVar11;
                *(undefined4 *)((int64_t)&arg_70h + iVar8 + 4) = uVar3;
                *(undefined4 *)(&stack0x00000078 + iVar8) = uVar4;
                *(undefined4 *)(&stack0x0000007c + iVar8) = uVar5;
                uVar3 = puVar11[5];
                uVar4 = puVar11[6];
                uVar5 = puVar11[7];
                *(undefined4 *)((int64_t)&arg_80h + iVar8) = puVar11[4];
                *(undefined4 *)((int64_t)&arg_80h + iVar8 + 4) = uVar3;
                *(undefined4 *)(&stack0x00000088 + iVar8) = uVar4;
                *(undefined4 *)(&stack0x0000008c + iVar8) = uVar5;
                *(undefined8 *)((int64_t)&arg_90h + iVar8) = *(undefined8 *)(puVar11 + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6b55;
                iVar7 = fcn.180257420(iVar10, in_R8, in_R9, (int64_t)&arg_48h + iVar8);
                if (iVar7 != 0) {
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6b62;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
                goto code_r0x0001801f6b6e;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6bbb;
        fcn.180256b30(iVar9);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6bc0;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        goto code_r0x0001801f6b6e;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6bd3;
    iVar9 = fcn.180211490();
    *(int64_t *)(in_RCX + 0x1020) = iVar9;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6be7;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        goto code_r0x0001801f6b6e;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c05;
    iVar6 = fcn.18020efb0(*(undefined8 *)((int64_t)&arg_f8h + iVar8));
    uVar12 = (uint32_t)(iVar7 == 1);
    *(uint32_t *)((int64_t)&var_10h + iVar8) = uVar12;
    *(undefined8 *)((int64_t)&var_8h + iVar8) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c2b;
    iVar7 = fcn.180211b70(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), *(int64_t *)(&stack0x00000050 + iVar8), 
                          *(int64_t *)((int64_t)&arg_58h + iVar8));
    if (0 < iVar7) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c42;
        iVar7 = fcn.180210b80(*(int64_t *)((int64_t)&iStackX_20 + iVar8), *(int64_t *)(&stack0x00000028 + iVar8), 
                              *(int64_t *)(&stack0x00000030 + iVar8), *(int64_t *)(&stack0x00000038 + iVar8));
        if (0 < iVar7) {
            if (iVar6 == 7) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c63;
                iVar7 = fcn.180210b80(*(int64_t *)((int64_t)&iStackX_20 + iVar8), *(int64_t *)(&stack0x00000028 + iVar8)
                                      , *(int64_t *)(&stack0x00000030 + iVar8), *(int64_t *)(&stack0x00000038 + iVar8));
                if (iVar7 < 1) goto code_r0x0001801f6c93;
            }
            *(uint32_t *)((int64_t)&var_10h + iVar8) = uVar12;
            *(undefined8 *)((int64_t)&var_8h + iVar8) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c85;
            iVar7 = fcn.180211b70(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), 
                                  *(int64_t *)(&stack0x00000050 + iVar8), *(int64_t *)((int64_t)&arg_58h + iVar8));
            if (0 < iVar7) {
                return 1;
            }
        }
    }
code_r0x0001801f6c93:
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c98;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
code_r0x0001801f6b6e:
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6b7a;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                  *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar8), 
                  *(int64_t *)(&stack0x00000038 + iVar8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6b8c;
    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_1801f6bb3
// Address: 0x1801f6bb3
// Size: 246 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8
fcn.1801f69b0(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h,
             int64_t arg_98h, int64_t arg_b8h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_f8h, int64_t arg_100h,
             int64_t arg_108h, int64_t arg_110h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined4 *puVar11;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    undefined8 in_R8;
    undefined8 in_R9;
    uint32_t uVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f69ca;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    uVar1 = *(undefined8 *)((int64_t)&arg_e0h + iVar8);
    iVar7 = *(int32_t *)(in_RCX + 0x1c);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f69fe;
    iVar9 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
    *(int64_t *)(in_RCX + 0x10c0) = iVar9;
    if (iVar9 == 0) {
        return 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6a23;
    iVar9 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
    *(int64_t *)(in_RCX + 0x10c8) = iVar9;
    if (iVar9 == 0) {
        return 0xfffffffe;
    }
    uVar2 = *(undefined8 *)(in_RCX + 0x10c0);
    *(undefined8 *)((int64_t)&arg_b8h + iVar8) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6a52;
    fcn.180498030(uVar2, *(undefined8 *)((int64_t)&arg_d8h + iVar8), uVar1);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6a66;
    iVar6 = fcn.18020f2b0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar8), 
                          *(int64_t *)(&stack0x00000028 + iVar8), *(int64_t *)(&stack0x00000030 + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar8), *(int64_t *)(&stack0x00000040 + iVar8));
    if (((iVar6 != 0) && (*(int32_t *)((int64_t)&arg_108h + iVar8) == 0x357)) &&
       (*(int64_t *)((int64_t)&arg_110h + iVar8) != 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6aa1;
        iVar9 = fcn.180256ae0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6ab5;
            iVar10 = fcn.1802570e0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
            *(int64_t *)(in_RCX + 0x1028) = iVar10;
            if (iVar10 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6ad0;
                fcn.180256b30(iVar9);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6add;
                fcn.18020f750(*(undefined8 *)((int64_t)&arg_110h + iVar8));
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6af4;
                puVar11 = (undefined4 *)
                          fcn.180229e30(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8)
                                        , *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), 
                                        *(int64_t *)(&stack0x00000038 + iVar8), *(int64_t *)(&stack0x00000040 + iVar8));
                uVar3 = puVar11[1];
                uVar4 = puVar11[2];
                uVar5 = puVar11[3];
                *(undefined4 *)((int64_t)&arg_48h + iVar8) = *puVar11;
                *(undefined4 *)((int64_t)&arg_48h + iVar8 + 4) = uVar3;
                *(undefined4 *)(&stack0x00000050 + iVar8) = uVar4;
                *(undefined4 *)(&stack0x00000054 + iVar8) = uVar5;
                uVar3 = puVar11[5];
                uVar4 = puVar11[6];
                uVar5 = puVar11[7];
                *(undefined4 *)((int64_t)&arg_58h + iVar8) = puVar11[4];
                *(undefined4 *)((int64_t)&arg_58h + iVar8 + 4) = uVar3;
                *(undefined4 *)(&stack0x00000060 + iVar8) = uVar4;
                *(undefined4 *)(&stack0x00000064 + iVar8) = uVar5;
                *(undefined8 *)((int64_t)&arg_68h + iVar8) = *(undefined8 *)(puVar11 + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6b1d;
                puVar11 = (undefined4 *)fcn.180229ba0((int64_t)&iStackX_20 + iVar8 + -8);
                uVar3 = puVar11[1];
                uVar4 = puVar11[2];
                uVar5 = puVar11[3];
                *(undefined4 *)((int64_t)&arg_70h + iVar8) = *puVar11;
                *(undefined4 *)((int64_t)&arg_70h + iVar8 + 4) = uVar3;
                *(undefined4 *)(&stack0x00000078 + iVar8) = uVar4;
                *(undefined4 *)(&stack0x0000007c + iVar8) = uVar5;
                uVar3 = puVar11[5];
                uVar4 = puVar11[6];
                uVar5 = puVar11[7];
                *(undefined4 *)((int64_t)&arg_80h + iVar8) = puVar11[4];
                *(undefined4 *)((int64_t)&arg_80h + iVar8 + 4) = uVar3;
                *(undefined4 *)(&stack0x00000088 + iVar8) = uVar4;
                *(undefined4 *)(&stack0x0000008c + iVar8) = uVar5;
                *(undefined8 *)((int64_t)&arg_90h + iVar8) = *(undefined8 *)(puVar11 + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6b55;
                iVar7 = fcn.180257420(iVar10, in_R8, in_R9, (int64_t)&arg_48h + iVar8);
                if (iVar7 != 0) {
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6b62;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
                goto code_r0x0001801f6b6e;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6bbb;
        fcn.180256b30(iVar9);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6bc0;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        goto code_r0x0001801f6b6e;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6bd3;
    iVar9 = fcn.180211490();
    *(int64_t *)(in_RCX + 0x1020) = iVar9;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6be7;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        goto code_r0x0001801f6b6e;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c05;
    iVar6 = fcn.18020efb0(*(undefined8 *)((int64_t)&arg_f8h + iVar8));
    uVar12 = (uint32_t)(iVar7 == 1);
    *(uint32_t *)((int64_t)&var_10h + iVar8) = uVar12;
    *(undefined8 *)((int64_t)&var_8h + iVar8) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c2b;
    iVar7 = fcn.180211b70(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), *(int64_t *)(&stack0x00000050 + iVar8), 
                          *(int64_t *)((int64_t)&arg_58h + iVar8));
    if (0 < iVar7) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c42;
        iVar7 = fcn.180210b80(*(int64_t *)((int64_t)&iStackX_20 + iVar8), *(int64_t *)(&stack0x00000028 + iVar8), 
                              *(int64_t *)(&stack0x00000030 + iVar8), *(int64_t *)(&stack0x00000038 + iVar8));
        if (0 < iVar7) {
            if (iVar6 == 7) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c63;
                iVar7 = fcn.180210b80(*(int64_t *)((int64_t)&iStackX_20 + iVar8), *(int64_t *)(&stack0x00000028 + iVar8)
                                      , *(int64_t *)(&stack0x00000030 + iVar8), *(int64_t *)(&stack0x00000038 + iVar8));
                if (iVar7 < 1) goto code_r0x0001801f6c93;
            }
            *(uint32_t *)((int64_t)&var_10h + iVar8) = uVar12;
            *(undefined8 *)((int64_t)&var_8h + iVar8) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c85;
            iVar7 = fcn.180211b70(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), 
                                  *(int64_t *)(&stack0x00000050 + iVar8), *(int64_t *)((int64_t)&arg_58h + iVar8));
            if (0 < iVar7) {
                return 1;
            }
        }
    }
code_r0x0001801f6c93:
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c98;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
code_r0x0001801f6b6e:
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6b7a;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                  *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar8), 
                  *(int64_t *)(&stack0x00000038 + iVar8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6b8c;
    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_1801f6ca9
// Address: 0x1801f6ca9
// Size: 10 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8
fcn.1801f69b0(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h,
             int64_t arg_98h, int64_t arg_b8h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_f8h, int64_t arg_100h,
             int64_t arg_108h, int64_t arg_110h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined4 *puVar11;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    undefined8 in_R8;
    undefined8 in_R9;
    uint32_t uVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f69ca;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    uVar1 = *(undefined8 *)((int64_t)&arg_e0h + iVar8);
    iVar7 = *(int32_t *)(in_RCX + 0x1c);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f69fe;
    iVar9 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
    *(int64_t *)(in_RCX + 0x10c0) = iVar9;
    if (iVar9 == 0) {
        return 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6a23;
    iVar9 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
    *(int64_t *)(in_RCX + 0x10c8) = iVar9;
    if (iVar9 == 0) {
        return 0xfffffffe;
    }
    uVar2 = *(undefined8 *)(in_RCX + 0x10c0);
    *(undefined8 *)((int64_t)&arg_b8h + iVar8) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6a52;
    fcn.180498030(uVar2, *(undefined8 *)((int64_t)&arg_d8h + iVar8), uVar1);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6a66;
    iVar6 = fcn.18020f2b0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar8), 
                          *(int64_t *)(&stack0x00000028 + iVar8), *(int64_t *)(&stack0x00000030 + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar8), *(int64_t *)(&stack0x00000040 + iVar8));
    if (((iVar6 != 0) && (*(int32_t *)((int64_t)&arg_108h + iVar8) == 0x357)) &&
       (*(int64_t *)((int64_t)&arg_110h + iVar8) != 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6aa1;
        iVar9 = fcn.180256ae0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6ab5;
            iVar10 = fcn.1802570e0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
            *(int64_t *)(in_RCX + 0x1028) = iVar10;
            if (iVar10 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6ad0;
                fcn.180256b30(iVar9);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6add;
                fcn.18020f750(*(undefined8 *)((int64_t)&arg_110h + iVar8));
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6af4;
                puVar11 = (undefined4 *)
                          fcn.180229e30(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8)
                                        , *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), 
                                        *(int64_t *)(&stack0x00000038 + iVar8), *(int64_t *)(&stack0x00000040 + iVar8));
                uVar3 = puVar11[1];
                uVar4 = puVar11[2];
                uVar5 = puVar11[3];
                *(undefined4 *)((int64_t)&arg_48h + iVar8) = *puVar11;
                *(undefined4 *)((int64_t)&arg_48h + iVar8 + 4) = uVar3;
                *(undefined4 *)(&stack0x00000050 + iVar8) = uVar4;
                *(undefined4 *)(&stack0x00000054 + iVar8) = uVar5;
                uVar3 = puVar11[5];
                uVar4 = puVar11[6];
                uVar5 = puVar11[7];
                *(undefined4 *)((int64_t)&arg_58h + iVar8) = puVar11[4];
                *(undefined4 *)((int64_t)&arg_58h + iVar8 + 4) = uVar3;
                *(undefined4 *)(&stack0x00000060 + iVar8) = uVar4;
                *(undefined4 *)(&stack0x00000064 + iVar8) = uVar5;
                *(undefined8 *)((int64_t)&arg_68h + iVar8) = *(undefined8 *)(puVar11 + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6b1d;
                puVar11 = (undefined4 *)fcn.180229ba0((int64_t)&iStackX_20 + iVar8 + -8);
                uVar3 = puVar11[1];
                uVar4 = puVar11[2];
                uVar5 = puVar11[3];
                *(undefined4 *)((int64_t)&arg_70h + iVar8) = *puVar11;
                *(undefined4 *)((int64_t)&arg_70h + iVar8 + 4) = uVar3;
                *(undefined4 *)(&stack0x00000078 + iVar8) = uVar4;
                *(undefined4 *)(&stack0x0000007c + iVar8) = uVar5;
                uVar3 = puVar11[5];
                uVar4 = puVar11[6];
                uVar5 = puVar11[7];
                *(undefined4 *)((int64_t)&arg_80h + iVar8) = puVar11[4];
                *(undefined4 *)((int64_t)&arg_80h + iVar8 + 4) = uVar3;
                *(undefined4 *)(&stack0x00000088 + iVar8) = uVar4;
                *(undefined4 *)(&stack0x0000008c + iVar8) = uVar5;
                *(undefined8 *)((int64_t)&arg_90h + iVar8) = *(undefined8 *)(puVar11 + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6b55;
                iVar7 = fcn.180257420(iVar10, in_R8, in_R9, (int64_t)&arg_48h + iVar8);
                if (iVar7 != 0) {
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6b62;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
                goto code_r0x0001801f6b6e;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6bbb;
        fcn.180256b30(iVar9);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6bc0;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        goto code_r0x0001801f6b6e;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6bd3;
    iVar9 = fcn.180211490();
    *(int64_t *)(in_RCX + 0x1020) = iVar9;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6be7;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        goto code_r0x0001801f6b6e;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c05;
    iVar6 = fcn.18020efb0(*(undefined8 *)((int64_t)&arg_f8h + iVar8));
    uVar12 = (uint32_t)(iVar7 == 1);
    *(uint32_t *)((int64_t)&var_10h + iVar8) = uVar12;
    *(undefined8 *)((int64_t)&var_8h + iVar8) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c2b;
    iVar7 = fcn.180211b70(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), *(int64_t *)(&stack0x00000050 + iVar8), 
                          *(int64_t *)((int64_t)&arg_58h + iVar8));
    if (0 < iVar7) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c42;
        iVar7 = fcn.180210b80(*(int64_t *)((int64_t)&iStackX_20 + iVar8), *(int64_t *)(&stack0x00000028 + iVar8), 
                              *(int64_t *)(&stack0x00000030 + iVar8), *(int64_t *)(&stack0x00000038 + iVar8));
        if (0 < iVar7) {
            if (iVar6 == 7) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c63;
                iVar7 = fcn.180210b80(*(int64_t *)((int64_t)&iStackX_20 + iVar8), *(int64_t *)(&stack0x00000028 + iVar8)
                                      , *(int64_t *)(&stack0x00000030 + iVar8), *(int64_t *)(&stack0x00000038 + iVar8));
                if (iVar7 < 1) goto code_r0x0001801f6c93;
            }
            *(uint32_t *)((int64_t)&var_10h + iVar8) = uVar12;
            *(undefined8 *)((int64_t)&var_8h + iVar8) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c85;
            iVar7 = fcn.180211b70(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), 
                                  *(int64_t *)(&stack0x00000050 + iVar8), *(int64_t *)((int64_t)&arg_58h + iVar8));
            if (0 < iVar7) {
                return 1;
            }
        }
    }
code_r0x0001801f6c93:
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6c98;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
code_r0x0001801f6b6e:
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6b7a;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                  *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar8), 
                  *(int64_t *)(&stack0x00000038 + iVar8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6b8c;
    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_1801f6cc0
// Address: 0x1801f6cc0
// Size: 109 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.1801f6cc0(int64_t arg_28h, int64_t arg_30h, int64_t arg_68h, int64_t arg_78h, int64_t arg_b8h, int64_t arg_c8h,
                  int64_t arg_d0h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_118h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t in_R8;
    int32_t in_R9D;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f6ccf;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&arg_b8h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8);
    if (in_R8 != 1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6cf8;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d10;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)(&stack0x00000038 + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d26;
        fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
        goto code_r0x0001801f737b;
    }
    *(undefined8 *)((int64_t)&arg_e0h + iVar8) = unaff_RBP;
    iVar10 = *(int64_t *)(in_RCX + 0x1020);
    *(undefined8 *)((int64_t)&arg_d8h + iVar8) = unaff_R12;
    iVar1 = *(int64_t *)(in_RCX + 0x10c8);
    *(undefined8 *)((int64_t)&arg_d0h + iVar8) = unaff_R13;
    iVar11 = *(int64_t *)(in_RCX + 0x10c0);
    if ((iVar10 == 0) && (*(int64_t *)(in_RCX + 0x1028) == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d6d;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d85;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)(&stack0x00000038 + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d9b;
        fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
        goto code_r0x0001801f737b;
    }
    if (in_RDX[1] == 0x15) {
        uVar2 = *(undefined8 *)(in_RDX + 2);
        uVar3 = *(undefined8 *)(in_RDX + 10);
        uVar4 = *(undefined8 *)(in_RDX + 8);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6db9;
        fcn.180498030(uVar4, uVar3, uVar2);
        *(undefined8 *)(in_RDX + 10) = *(undefined8 *)(in_RDX + 8);
        goto code_r0x0001801f737b;
    }
    iVar5 = *(int64_t *)(in_RCX + 0x1028);
    *(undefined8 *)((int64_t)&arg_c8h + iVar8) = unaff_R15;
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6df1;
        iVar6 = fcn.18020e980(*(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8), 
                              *(int64_t *)(&stack0x00000038 + iVar8), *(int64_t *)(&stack0x00000040 + iVar8), 
                              *(int64_t *)(&stack0x00000048 + iVar8), *(int64_t *)(&stack0x00000050 + iVar8), 
                              *(int64_t *)(&stack0x00000058 + iVar8), *(int64_t *)(&stack0x00000060 + iVar8), 
                              *(int64_t *)((int64_t)&arg_68h + iVar8), *(int64_t *)(&stack0x00000070 + iVar8), 
                              *(int64_t *)(&stack0x00000088 + iVar8), *(int64_t *)(&stack0x00000090 + iVar8), 
                              *(int64_t *)((int64_t)&arg_d8h + iVar8), *(int64_t *)(&stack0x00000138 + iVar8), 
                              *(int64_t *)(&stack0x00000140 + iVar8));
        if (iVar6 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6dfa;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e12;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e28;
            fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
            goto code_r0x0001801f737b;
        }
        uVar9 = (uint64_t)iVar6;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6de4;
        uVar9 = func_0x0001802570c0();
    }
    *(undefined8 *)((int64_t)&arg_118h + iVar8) = unaff_RBX;
    if (in_R9D == 0) {
        if (*(uint64_t *)(in_RDX + 2) < *(int64_t *)(in_RCX + 0x10d8) + 1U) goto code_r0x0001801f737b;
        *(uint64_t *)(in_RDX + 2) = *(uint64_t *)(in_RDX + 2) - *(int64_t *)(in_RCX + 0x10d8);
    }
    if (uVar9 < 8) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e69;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e81;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)(&stack0x00000038 + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e97;
        fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
        goto code_r0x0001801f737b;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6eab;
    fcn.180498030(iVar1, iVar11, uVar9 - 8);
    *(uint8_t *)((uVar9 - 8) + iVar1) = *(uint8_t *)((uVar9 - 8) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1000);
    *(uint8_t *)((uVar9 - 7) + iVar1) = *(uint8_t *)((uVar9 - 7) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1001);
    *(uint8_t *)((uVar9 - 6) + iVar1) = *(uint8_t *)((uVar9 - 6) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1002);
    *(uint8_t *)((uVar9 - 5) + iVar1) = *(uint8_t *)((uVar9 - 5) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1003);
    *(uint8_t *)((uVar9 - 4) + iVar1) = *(uint8_t *)((uVar9 - 4) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1004);
    *(uint8_t *)((uVar9 - 3) + iVar1) = *(uint8_t *)((uVar9 - 3) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1005);
    *(uint8_t *)((uVar9 - 2) + iVar1) = *(uint8_t *)((uVar9 - 2) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1006);
    *(uint8_t *)((uVar9 - 1) + iVar1) = *(uint8_t *)((uVar9 - 1) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1007);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f3b;
    iVar6 = func_0x0001801d4800(in_RCX);
    if (iVar6 == 0) goto code_r0x0001801f737b;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f5e;
    iVar6 = func_0x000180244550((int64_t)&arg_30h + iVar8, (int64_t)&arg_68h + iVar8, 5, 0);
    if (iVar6 != 0) {
        iVar6 = in_RDX[1];
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f7a;
        iVar6 = func_0x0001802446f0((int64_t)&arg_30h + iVar8, (int64_t)iVar6, 1);
        if (iVar6 != 0) {
            iVar6 = *in_RDX;
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f95;
            iVar6 = func_0x0001802446f0((int64_t)&arg_30h + iVar8, (int64_t)iVar6, 2);
            if (iVar6 != 0) {
                iVar11 = *(int64_t *)(in_RCX + 0x10d8);
                iVar5 = *(int64_t *)(in_RDX + 2);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6fb8;
                iVar6 = func_0x0001802446f0((int64_t)&arg_30h + iVar8, iVar11 + iVar5, 2);
                if (iVar6 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6fcf;
                    iVar6 = func_0x0001802442e0((int64_t)&arg_30h + iVar8, (int64_t)&var_20h + iVar8);
                    if ((iVar6 != 0) && (*(int64_t *)((int64_t)&var_20h + iVar8) == 5)) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6fed;
                        iVar6 = func_0x000180244200((int64_t)&arg_30h + iVar8);
                        if (iVar6 != 0) {
                            if (*(int64_t *)(in_RCX + 0x1028) == 0) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7139;
                                iVar11 = fcn.18020e940(iVar10);
                                if (iVar11 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7143;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f715b;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar8), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7171;
                                    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                                    goto code_r0x0001801f737b;
                                }
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f717e;
                                iVar6 = fcn.18020efb0(iVar11);
                                *(int32_t *)((int64_t)&var_10h + iVar8) = in_R9D;
                                *(int64_t *)((int64_t)&var_8h + iVar8) = iVar1;
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f719a;
                                iVar7 = fcn.180211b70(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                      *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                      *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                      *(int64_t *)(&stack0x00000050 + iVar8), 
                                                      *(int64_t *)(&stack0x00000058 + iVar8));
                                if (iVar7 < 1) {
code_r0x0001801f72df:
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72e4;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72fc;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar8), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7312;
                                    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                                } else {
                                    if (in_R9D == 0) {
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f71c3;
                                        iVar7 = fcn.180210b80(*(int64_t *)((int64_t)&var_20h + iVar8), 
                                                              *(int64_t *)((int64_t)&arg_28h + iVar8), 
                                                              *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                                              *(int64_t *)(&stack0x00000038 + iVar8));
                                        if (iVar7 < 1) goto code_r0x0001801f72df;
                                    }
                                    if (iVar6 == 7) {
                                        *(int32_t *)((int64_t)&var_8h + iVar8) = in_RDX[2];
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f71e9;
                                        iVar6 = func_0x000180211bb0(iVar10, 0, (int64_t)&var_18h + iVar8, 0);
                                        if (iVar6 < 1) goto code_r0x0001801f737b;
                                    }
                                    *(undefined4 *)((int64_t)&var_8h + iVar8) = 5;
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7210;
                                    iVar6 = func_0x000180211bb0(iVar10, 0, (int64_t)&var_18h + iVar8, 
                                                                (int64_t)&arg_68h + iVar8);
                                    if (0 < iVar6) {
                                        uVar2 = *(undefined8 *)(in_RDX + 10);
                                        uVar3 = *(undefined8 *)(in_RDX + 8);
                                        *(int32_t *)((int64_t)&var_8h + iVar8) = in_RDX[2];
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7234;
                                        iVar6 = func_0x000180211bb0(iVar10, uVar3, (int64_t)&var_18h + iVar8, uVar2);
                                        if (0 < iVar6) {
                                            iVar1 = *(int64_t *)(in_RDX + 8);
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7252;
                                            iVar6 = func_0x000180211b40(iVar10, *(int32_t *)((int64_t)&var_18h + iVar8)
                                                                                + iVar1, (int64_t)&var_18h + iVar8 + 4);
                                            if (((0 < iVar6) &&
                                                ((int64_t)(*(int32_t *)((int64_t)&var_18h + iVar8 + 4) +
                                                          *(int32_t *)((int64_t)&var_18h + iVar8)) ==
                                                 *(int64_t *)(in_RDX + 2))) && (in_R9D != 0)) {
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7291;
                                                iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_20h + iVar8), 
                                                                      *(int64_t *)((int64_t)&arg_28h + iVar8), 
                                                                      *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                                                      *(int64_t *)(&stack0x00000038 + iVar8));
                                                if (iVar6 < 1) {
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f729a;
                                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_10h + iVar8));
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72b2;
                                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_20h + iVar8), 
                                                                  *(int64_t *)(&stack0x00000038 + iVar8));
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72c8;
                                                    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                                                } else {
                                                    *(int64_t *)(in_RDX + 2) =
                                                         *(int64_t *)(in_RDX + 2) + *(int64_t *)(in_RCX + 0x10d8);
                                                }
                                            }
                                        }
                                    }
                                }
                                goto code_r0x0001801f737b;
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f700c;
                            iVar10 = func_0x000180256f80();
                            if (iVar10 == 0) {
code_r0x0001801f70ef:
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70f4;
                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                              *(int64_t *)((int64_t)&var_10h + iVar8));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f710c;
                                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                              *(int64_t *)((int64_t)&var_10h + iVar8), 
                                              *(int64_t *)((int64_t)&var_18h + iVar8), 
                                              *(int64_t *)((int64_t)&var_20h + iVar8), 
                                              *(int64_t *)(&stack0x00000038 + iVar8));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7122;
                                fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                            } else {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7026;
                                iVar6 = func_0x0001802574c0(iVar10, iVar1, uVar9);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7044;
                                iVar6 = func_0x0001802574c0(iVar10, (int64_t)&arg_68h + iVar8, 5);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                uVar2 = *(undefined8 *)(in_RDX + 2);
                                uVar3 = *(undefined8 *)(in_RDX + 10);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f705c;
                                iVar6 = func_0x0001802574c0(iVar10, uVar3, uVar2);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                uVar2 = *(undefined8 *)(in_RCX + 0x10d8);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7080;
                                iVar6 = func_0x000180257200(iVar10, (int64_t)&arg_78h + iVar8, (int64_t)&arg_28h + iVar8
                                                            , uVar2);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                iVar1 = *(int64_t *)(in_RDX + 8);
                                iVar11 = *(int64_t *)(in_RDX + 2);
                                uVar2 = *(undefined8 *)(in_RCX + 0x10d8);
                                if (in_R9D != 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70a8;
                                    fcn.180498030(iVar1 + iVar11, (int64_t)&arg_78h + iVar8);
                                    *(int64_t *)(in_RDX + 2) = *(int64_t *)(in_RDX + 2) + *(int64_t *)(in_RCX + 0x10d8);
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70c0;
                                    func_0x000180257070(iVar10);
                                    goto code_r0x0001801f737b;
                                }
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70d7;
                                iVar6 = func_0x0001802262e0((int64_t)&arg_78h + iVar8, iVar1 + iVar11, uVar2);
                                if (iVar6 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70e8;
                                    func_0x000180257070(iVar10);
                                    goto code_r0x0001801f737b;
                                }
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f712a;
                            func_0x000180257070(iVar10);
                            goto code_r0x0001801f737b;
                        }
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7319;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7331;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                  *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                  *(int64_t *)(&stack0x00000038 + iVar8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7347;
    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7351;
    func_0x000180243fb0((int64_t)&arg_30h + iVar8);
code_r0x0001801f737b:
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f738b;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_b8h + iVar8) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_1801f6d2d
// Address: 0x1801f6d2d
// Size: 165 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.1801f6cc0(int64_t arg_28h, int64_t arg_30h, int64_t arg_68h, int64_t arg_78h, int64_t arg_b8h, int64_t arg_c8h,
                  int64_t arg_d0h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_118h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t in_R8;
    int32_t in_R9D;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f6ccf;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&arg_b8h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8);
    if (in_R8 != 1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6cf8;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d10;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)(&stack0x00000038 + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d26;
        fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
        goto code_r0x0001801f737b;
    }
    *(undefined8 *)((int64_t)&arg_e0h + iVar8) = unaff_RBP;
    iVar10 = *(int64_t *)(in_RCX + 0x1020);
    *(undefined8 *)((int64_t)&arg_d8h + iVar8) = unaff_R12;
    iVar1 = *(int64_t *)(in_RCX + 0x10c8);
    *(undefined8 *)((int64_t)&arg_d0h + iVar8) = unaff_R13;
    iVar11 = *(int64_t *)(in_RCX + 0x10c0);
    if ((iVar10 == 0) && (*(int64_t *)(in_RCX + 0x1028) == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d6d;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d85;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)(&stack0x00000038 + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d9b;
        fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
        goto code_r0x0001801f737b;
    }
    if (in_RDX[1] == 0x15) {
        uVar2 = *(undefined8 *)(in_RDX + 2);
        uVar3 = *(undefined8 *)(in_RDX + 10);
        uVar4 = *(undefined8 *)(in_RDX + 8);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6db9;
        fcn.180498030(uVar4, uVar3, uVar2);
        *(undefined8 *)(in_RDX + 10) = *(undefined8 *)(in_RDX + 8);
        goto code_r0x0001801f737b;
    }
    iVar5 = *(int64_t *)(in_RCX + 0x1028);
    *(undefined8 *)((int64_t)&arg_c8h + iVar8) = unaff_R15;
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6df1;
        iVar6 = fcn.18020e980(*(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8), 
                              *(int64_t *)(&stack0x00000038 + iVar8), *(int64_t *)(&stack0x00000040 + iVar8), 
                              *(int64_t *)(&stack0x00000048 + iVar8), *(int64_t *)(&stack0x00000050 + iVar8), 
                              *(int64_t *)(&stack0x00000058 + iVar8), *(int64_t *)(&stack0x00000060 + iVar8), 
                              *(int64_t *)((int64_t)&arg_68h + iVar8), *(int64_t *)(&stack0x00000070 + iVar8), 
                              *(int64_t *)(&stack0x00000088 + iVar8), *(int64_t *)(&stack0x00000090 + iVar8), 
                              *(int64_t *)((int64_t)&arg_d8h + iVar8), *(int64_t *)(&stack0x00000138 + iVar8), 
                              *(int64_t *)(&stack0x00000140 + iVar8));
        if (iVar6 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6dfa;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e12;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e28;
            fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
            goto code_r0x0001801f737b;
        }
        uVar9 = (uint64_t)iVar6;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6de4;
        uVar9 = func_0x0001802570c0();
    }
    *(undefined8 *)((int64_t)&arg_118h + iVar8) = unaff_RBX;
    if (in_R9D == 0) {
        if (*(uint64_t *)(in_RDX + 2) < *(int64_t *)(in_RCX + 0x10d8) + 1U) goto code_r0x0001801f737b;
        *(uint64_t *)(in_RDX + 2) = *(uint64_t *)(in_RDX + 2) - *(int64_t *)(in_RCX + 0x10d8);
    }
    if (uVar9 < 8) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e69;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e81;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)(&stack0x00000038 + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e97;
        fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
        goto code_r0x0001801f737b;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6eab;
    fcn.180498030(iVar1, iVar11, uVar9 - 8);
    *(uint8_t *)((uVar9 - 8) + iVar1) = *(uint8_t *)((uVar9 - 8) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1000);
    *(uint8_t *)((uVar9 - 7) + iVar1) = *(uint8_t *)((uVar9 - 7) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1001);
    *(uint8_t *)((uVar9 - 6) + iVar1) = *(uint8_t *)((uVar9 - 6) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1002);
    *(uint8_t *)((uVar9 - 5) + iVar1) = *(uint8_t *)((uVar9 - 5) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1003);
    *(uint8_t *)((uVar9 - 4) + iVar1) = *(uint8_t *)((uVar9 - 4) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1004);
    *(uint8_t *)((uVar9 - 3) + iVar1) = *(uint8_t *)((uVar9 - 3) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1005);
    *(uint8_t *)((uVar9 - 2) + iVar1) = *(uint8_t *)((uVar9 - 2) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1006);
    *(uint8_t *)((uVar9 - 1) + iVar1) = *(uint8_t *)((uVar9 - 1) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1007);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f3b;
    iVar6 = func_0x0001801d4800(in_RCX);
    if (iVar6 == 0) goto code_r0x0001801f737b;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f5e;
    iVar6 = func_0x000180244550((int64_t)&arg_30h + iVar8, (int64_t)&arg_68h + iVar8, 5, 0);
    if (iVar6 != 0) {
        iVar6 = in_RDX[1];
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f7a;
        iVar6 = func_0x0001802446f0((int64_t)&arg_30h + iVar8, (int64_t)iVar6, 1);
        if (iVar6 != 0) {
            iVar6 = *in_RDX;
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f95;
            iVar6 = func_0x0001802446f0((int64_t)&arg_30h + iVar8, (int64_t)iVar6, 2);
            if (iVar6 != 0) {
                iVar11 = *(int64_t *)(in_RCX + 0x10d8);
                iVar5 = *(int64_t *)(in_RDX + 2);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6fb8;
                iVar6 = func_0x0001802446f0((int64_t)&arg_30h + iVar8, iVar11 + iVar5, 2);
                if (iVar6 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6fcf;
                    iVar6 = func_0x0001802442e0((int64_t)&arg_30h + iVar8, (int64_t)&var_20h + iVar8);
                    if ((iVar6 != 0) && (*(int64_t *)((int64_t)&var_20h + iVar8) == 5)) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6fed;
                        iVar6 = func_0x000180244200((int64_t)&arg_30h + iVar8);
                        if (iVar6 != 0) {
                            if (*(int64_t *)(in_RCX + 0x1028) == 0) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7139;
                                iVar11 = fcn.18020e940(iVar10);
                                if (iVar11 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7143;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f715b;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar8), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7171;
                                    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                                    goto code_r0x0001801f737b;
                                }
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f717e;
                                iVar6 = fcn.18020efb0(iVar11);
                                *(int32_t *)((int64_t)&var_10h + iVar8) = in_R9D;
                                *(int64_t *)((int64_t)&var_8h + iVar8) = iVar1;
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f719a;
                                iVar7 = fcn.180211b70(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                      *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                      *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                      *(int64_t *)(&stack0x00000050 + iVar8), 
                                                      *(int64_t *)(&stack0x00000058 + iVar8));
                                if (iVar7 < 1) {
code_r0x0001801f72df:
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72e4;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72fc;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar8), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7312;
                                    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                                } else {
                                    if (in_R9D == 0) {
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f71c3;
                                        iVar7 = fcn.180210b80(*(int64_t *)((int64_t)&var_20h + iVar8), 
                                                              *(int64_t *)((int64_t)&arg_28h + iVar8), 
                                                              *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                                              *(int64_t *)(&stack0x00000038 + iVar8));
                                        if (iVar7 < 1) goto code_r0x0001801f72df;
                                    }
                                    if (iVar6 == 7) {
                                        *(int32_t *)((int64_t)&var_8h + iVar8) = in_RDX[2];
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f71e9;
                                        iVar6 = func_0x000180211bb0(iVar10, 0, (int64_t)&var_18h + iVar8, 0);
                                        if (iVar6 < 1) goto code_r0x0001801f737b;
                                    }
                                    *(undefined4 *)((int64_t)&var_8h + iVar8) = 5;
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7210;
                                    iVar6 = func_0x000180211bb0(iVar10, 0, (int64_t)&var_18h + iVar8, 
                                                                (int64_t)&arg_68h + iVar8);
                                    if (0 < iVar6) {
                                        uVar2 = *(undefined8 *)(in_RDX + 10);
                                        uVar3 = *(undefined8 *)(in_RDX + 8);
                                        *(int32_t *)((int64_t)&var_8h + iVar8) = in_RDX[2];
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7234;
                                        iVar6 = func_0x000180211bb0(iVar10, uVar3, (int64_t)&var_18h + iVar8, uVar2);
                                        if (0 < iVar6) {
                                            iVar1 = *(int64_t *)(in_RDX + 8);
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7252;
                                            iVar6 = func_0x000180211b40(iVar10, *(int32_t *)((int64_t)&var_18h + iVar8)
                                                                                + iVar1, (int64_t)&var_18h + iVar8 + 4);
                                            if (((0 < iVar6) &&
                                                ((int64_t)(*(int32_t *)((int64_t)&var_18h + iVar8 + 4) +
                                                          *(int32_t *)((int64_t)&var_18h + iVar8)) ==
                                                 *(int64_t *)(in_RDX + 2))) && (in_R9D != 0)) {
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7291;
                                                iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_20h + iVar8), 
                                                                      *(int64_t *)((int64_t)&arg_28h + iVar8), 
                                                                      *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                                                      *(int64_t *)(&stack0x00000038 + iVar8));
                                                if (iVar6 < 1) {
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f729a;
                                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_10h + iVar8));
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72b2;
                                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_20h + iVar8), 
                                                                  *(int64_t *)(&stack0x00000038 + iVar8));
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72c8;
                                                    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                                                } else {
                                                    *(int64_t *)(in_RDX + 2) =
                                                         *(int64_t *)(in_RDX + 2) + *(int64_t *)(in_RCX + 0x10d8);
                                                }
                                            }
                                        }
                                    }
                                }
                                goto code_r0x0001801f737b;
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f700c;
                            iVar10 = func_0x000180256f80();
                            if (iVar10 == 0) {
code_r0x0001801f70ef:
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70f4;
                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                              *(int64_t *)((int64_t)&var_10h + iVar8));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f710c;
                                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                              *(int64_t *)((int64_t)&var_10h + iVar8), 
                                              *(int64_t *)((int64_t)&var_18h + iVar8), 
                                              *(int64_t *)((int64_t)&var_20h + iVar8), 
                                              *(int64_t *)(&stack0x00000038 + iVar8));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7122;
                                fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                            } else {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7026;
                                iVar6 = func_0x0001802574c0(iVar10, iVar1, uVar9);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7044;
                                iVar6 = func_0x0001802574c0(iVar10, (int64_t)&arg_68h + iVar8, 5);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                uVar2 = *(undefined8 *)(in_RDX + 2);
                                uVar3 = *(undefined8 *)(in_RDX + 10);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f705c;
                                iVar6 = func_0x0001802574c0(iVar10, uVar3, uVar2);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                uVar2 = *(undefined8 *)(in_RCX + 0x10d8);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7080;
                                iVar6 = func_0x000180257200(iVar10, (int64_t)&arg_78h + iVar8, (int64_t)&arg_28h + iVar8
                                                            , uVar2);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                iVar1 = *(int64_t *)(in_RDX + 8);
                                iVar11 = *(int64_t *)(in_RDX + 2);
                                uVar2 = *(undefined8 *)(in_RCX + 0x10d8);
                                if (in_R9D != 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70a8;
                                    fcn.180498030(iVar1 + iVar11, (int64_t)&arg_78h + iVar8);
                                    *(int64_t *)(in_RDX + 2) = *(int64_t *)(in_RDX + 2) + *(int64_t *)(in_RCX + 0x10d8);
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70c0;
                                    func_0x000180257070(iVar10);
                                    goto code_r0x0001801f737b;
                                }
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70d7;
                                iVar6 = func_0x0001802262e0((int64_t)&arg_78h + iVar8, iVar1 + iVar11, uVar2);
                                if (iVar6 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70e8;
                                    func_0x000180257070(iVar10);
                                    goto code_r0x0001801f737b;
                                }
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f712a;
                            func_0x000180257070(iVar10);
                            goto code_r0x0001801f737b;
                        }
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7319;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7331;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                  *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                  *(int64_t *)(&stack0x00000038 + iVar8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7347;
    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7351;
    func_0x000180243fb0((int64_t)&arg_30h + iVar8);
code_r0x0001801f737b:
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f738b;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_b8h + iVar8) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_1801f6dd2
// Address: 0x1801f6dd2
// Size: 96 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.1801f6cc0(int64_t arg_28h, int64_t arg_30h, int64_t arg_68h, int64_t arg_78h, int64_t arg_b8h, int64_t arg_c8h,
                  int64_t arg_d0h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_118h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t in_R8;
    int32_t in_R9D;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f6ccf;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&arg_b8h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8);
    if (in_R8 != 1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6cf8;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d10;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)(&stack0x00000038 + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d26;
        fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
        goto code_r0x0001801f737b;
    }
    *(undefined8 *)((int64_t)&arg_e0h + iVar8) = unaff_RBP;
    iVar10 = *(int64_t *)(in_RCX + 0x1020);
    *(undefined8 *)((int64_t)&arg_d8h + iVar8) = unaff_R12;
    iVar1 = *(int64_t *)(in_RCX + 0x10c8);
    *(undefined8 *)((int64_t)&arg_d0h + iVar8) = unaff_R13;
    iVar11 = *(int64_t *)(in_RCX + 0x10c0);
    if ((iVar10 == 0) && (*(int64_t *)(in_RCX + 0x1028) == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d6d;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d85;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)(&stack0x00000038 + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d9b;
        fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
        goto code_r0x0001801f737b;
    }
    if (in_RDX[1] == 0x15) {
        uVar2 = *(undefined8 *)(in_RDX + 2);
        uVar3 = *(undefined8 *)(in_RDX + 10);
        uVar4 = *(undefined8 *)(in_RDX + 8);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6db9;
        fcn.180498030(uVar4, uVar3, uVar2);
        *(undefined8 *)(in_RDX + 10) = *(undefined8 *)(in_RDX + 8);
        goto code_r0x0001801f737b;
    }
    iVar5 = *(int64_t *)(in_RCX + 0x1028);
    *(undefined8 *)((int64_t)&arg_c8h + iVar8) = unaff_R15;
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6df1;
        iVar6 = fcn.18020e980(*(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8), 
                              *(int64_t *)(&stack0x00000038 + iVar8), *(int64_t *)(&stack0x00000040 + iVar8), 
                              *(int64_t *)(&stack0x00000048 + iVar8), *(int64_t *)(&stack0x00000050 + iVar8), 
                              *(int64_t *)(&stack0x00000058 + iVar8), *(int64_t *)(&stack0x00000060 + iVar8), 
                              *(int64_t *)((int64_t)&arg_68h + iVar8), *(int64_t *)(&stack0x00000070 + iVar8), 
                              *(int64_t *)(&stack0x00000088 + iVar8), *(int64_t *)(&stack0x00000090 + iVar8), 
                              *(int64_t *)((int64_t)&arg_d8h + iVar8), *(int64_t *)(&stack0x00000138 + iVar8), 
                              *(int64_t *)(&stack0x00000140 + iVar8));
        if (iVar6 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6dfa;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e12;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e28;
            fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
            goto code_r0x0001801f737b;
        }
        uVar9 = (uint64_t)iVar6;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6de4;
        uVar9 = func_0x0001802570c0();
    }
    *(undefined8 *)((int64_t)&arg_118h + iVar8) = unaff_RBX;
    if (in_R9D == 0) {
        if (*(uint64_t *)(in_RDX + 2) < *(int64_t *)(in_RCX + 0x10d8) + 1U) goto code_r0x0001801f737b;
        *(uint64_t *)(in_RDX + 2) = *(uint64_t *)(in_RDX + 2) - *(int64_t *)(in_RCX + 0x10d8);
    }
    if (uVar9 < 8) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e69;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e81;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)(&stack0x00000038 + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e97;
        fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
        goto code_r0x0001801f737b;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6eab;
    fcn.180498030(iVar1, iVar11, uVar9 - 8);
    *(uint8_t *)((uVar9 - 8) + iVar1) = *(uint8_t *)((uVar9 - 8) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1000);
    *(uint8_t *)((uVar9 - 7) + iVar1) = *(uint8_t *)((uVar9 - 7) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1001);
    *(uint8_t *)((uVar9 - 6) + iVar1) = *(uint8_t *)((uVar9 - 6) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1002);
    *(uint8_t *)((uVar9 - 5) + iVar1) = *(uint8_t *)((uVar9 - 5) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1003);
    *(uint8_t *)((uVar9 - 4) + iVar1) = *(uint8_t *)((uVar9 - 4) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1004);
    *(uint8_t *)((uVar9 - 3) + iVar1) = *(uint8_t *)((uVar9 - 3) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1005);
    *(uint8_t *)((uVar9 - 2) + iVar1) = *(uint8_t *)((uVar9 - 2) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1006);
    *(uint8_t *)((uVar9 - 1) + iVar1) = *(uint8_t *)((uVar9 - 1) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1007);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f3b;
    iVar6 = func_0x0001801d4800(in_RCX);
    if (iVar6 == 0) goto code_r0x0001801f737b;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f5e;
    iVar6 = func_0x000180244550((int64_t)&arg_30h + iVar8, (int64_t)&arg_68h + iVar8, 5, 0);
    if (iVar6 != 0) {
        iVar6 = in_RDX[1];
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f7a;
        iVar6 = func_0x0001802446f0((int64_t)&arg_30h + iVar8, (int64_t)iVar6, 1);
        if (iVar6 != 0) {
            iVar6 = *in_RDX;
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f95;
            iVar6 = func_0x0001802446f0((int64_t)&arg_30h + iVar8, (int64_t)iVar6, 2);
            if (iVar6 != 0) {
                iVar11 = *(int64_t *)(in_RCX + 0x10d8);
                iVar5 = *(int64_t *)(in_RDX + 2);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6fb8;
                iVar6 = func_0x0001802446f0((int64_t)&arg_30h + iVar8, iVar11 + iVar5, 2);
                if (iVar6 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6fcf;
                    iVar6 = func_0x0001802442e0((int64_t)&arg_30h + iVar8, (int64_t)&var_20h + iVar8);
                    if ((iVar6 != 0) && (*(int64_t *)((int64_t)&var_20h + iVar8) == 5)) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6fed;
                        iVar6 = func_0x000180244200((int64_t)&arg_30h + iVar8);
                        if (iVar6 != 0) {
                            if (*(int64_t *)(in_RCX + 0x1028) == 0) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7139;
                                iVar11 = fcn.18020e940(iVar10);
                                if (iVar11 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7143;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f715b;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar8), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7171;
                                    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                                    goto code_r0x0001801f737b;
                                }
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f717e;
                                iVar6 = fcn.18020efb0(iVar11);
                                *(int32_t *)((int64_t)&var_10h + iVar8) = in_R9D;
                                *(int64_t *)((int64_t)&var_8h + iVar8) = iVar1;
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f719a;
                                iVar7 = fcn.180211b70(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                      *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                      *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                      *(int64_t *)(&stack0x00000050 + iVar8), 
                                                      *(int64_t *)(&stack0x00000058 + iVar8));
                                if (iVar7 < 1) {
code_r0x0001801f72df:
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72e4;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72fc;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar8), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7312;
                                    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                                } else {
                                    if (in_R9D == 0) {
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f71c3;
                                        iVar7 = fcn.180210b80(*(int64_t *)((int64_t)&var_20h + iVar8), 
                                                              *(int64_t *)((int64_t)&arg_28h + iVar8), 
                                                              *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                                              *(int64_t *)(&stack0x00000038 + iVar8));
                                        if (iVar7 < 1) goto code_r0x0001801f72df;
                                    }
                                    if (iVar6 == 7) {
                                        *(int32_t *)((int64_t)&var_8h + iVar8) = in_RDX[2];
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f71e9;
                                        iVar6 = func_0x000180211bb0(iVar10, 0, (int64_t)&var_18h + iVar8, 0);
                                        if (iVar6 < 1) goto code_r0x0001801f737b;
                                    }
                                    *(undefined4 *)((int64_t)&var_8h + iVar8) = 5;
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7210;
                                    iVar6 = func_0x000180211bb0(iVar10, 0, (int64_t)&var_18h + iVar8, 
                                                                (int64_t)&arg_68h + iVar8);
                                    if (0 < iVar6) {
                                        uVar2 = *(undefined8 *)(in_RDX + 10);
                                        uVar3 = *(undefined8 *)(in_RDX + 8);
                                        *(int32_t *)((int64_t)&var_8h + iVar8) = in_RDX[2];
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7234;
                                        iVar6 = func_0x000180211bb0(iVar10, uVar3, (int64_t)&var_18h + iVar8, uVar2);
                                        if (0 < iVar6) {
                                            iVar1 = *(int64_t *)(in_RDX + 8);
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7252;
                                            iVar6 = func_0x000180211b40(iVar10, *(int32_t *)((int64_t)&var_18h + iVar8)
                                                                                + iVar1, (int64_t)&var_18h + iVar8 + 4);
                                            if (((0 < iVar6) &&
                                                ((int64_t)(*(int32_t *)((int64_t)&var_18h + iVar8 + 4) +
                                                          *(int32_t *)((int64_t)&var_18h + iVar8)) ==
                                                 *(int64_t *)(in_RDX + 2))) && (in_R9D != 0)) {
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7291;
                                                iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_20h + iVar8), 
                                                                      *(int64_t *)((int64_t)&arg_28h + iVar8), 
                                                                      *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                                                      *(int64_t *)(&stack0x00000038 + iVar8));
                                                if (iVar6 < 1) {
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f729a;
                                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_10h + iVar8));
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72b2;
                                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_20h + iVar8), 
                                                                  *(int64_t *)(&stack0x00000038 + iVar8));
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72c8;
                                                    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                                                } else {
                                                    *(int64_t *)(in_RDX + 2) =
                                                         *(int64_t *)(in_RDX + 2) + *(int64_t *)(in_RCX + 0x10d8);
                                                }
                                            }
                                        }
                                    }
                                }
                                goto code_r0x0001801f737b;
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f700c;
                            iVar10 = func_0x000180256f80();
                            if (iVar10 == 0) {
code_r0x0001801f70ef:
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70f4;
                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                              *(int64_t *)((int64_t)&var_10h + iVar8));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f710c;
                                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                              *(int64_t *)((int64_t)&var_10h + iVar8), 
                                              *(int64_t *)((int64_t)&var_18h + iVar8), 
                                              *(int64_t *)((int64_t)&var_20h + iVar8), 
                                              *(int64_t *)(&stack0x00000038 + iVar8));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7122;
                                fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                            } else {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7026;
                                iVar6 = func_0x0001802574c0(iVar10, iVar1, uVar9);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7044;
                                iVar6 = func_0x0001802574c0(iVar10, (int64_t)&arg_68h + iVar8, 5);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                uVar2 = *(undefined8 *)(in_RDX + 2);
                                uVar3 = *(undefined8 *)(in_RDX + 10);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f705c;
                                iVar6 = func_0x0001802574c0(iVar10, uVar3, uVar2);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                uVar2 = *(undefined8 *)(in_RCX + 0x10d8);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7080;
                                iVar6 = func_0x000180257200(iVar10, (int64_t)&arg_78h + iVar8, (int64_t)&arg_28h + iVar8
                                                            , uVar2);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                iVar1 = *(int64_t *)(in_RDX + 8);
                                iVar11 = *(int64_t *)(in_RDX + 2);
                                uVar2 = *(undefined8 *)(in_RCX + 0x10d8);
                                if (in_R9D != 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70a8;
                                    fcn.180498030(iVar1 + iVar11, (int64_t)&arg_78h + iVar8);
                                    *(int64_t *)(in_RDX + 2) = *(int64_t *)(in_RDX + 2) + *(int64_t *)(in_RCX + 0x10d8);
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70c0;
                                    func_0x000180257070(iVar10);
                                    goto code_r0x0001801f737b;
                                }
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70d7;
                                iVar6 = func_0x0001802262e0((int64_t)&arg_78h + iVar8, iVar1 + iVar11, uVar2);
                                if (iVar6 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70e8;
                                    func_0x000180257070(iVar10);
                                    goto code_r0x0001801f737b;
                                }
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f712a;
                            func_0x000180257070(iVar10);
                            goto code_r0x0001801f737b;
                        }
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7319;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7331;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                  *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                  *(int64_t *)(&stack0x00000038 + iVar8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7347;
    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7351;
    func_0x000180243fb0((int64_t)&arg_30h + iVar8);
code_r0x0001801f737b:
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f738b;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_b8h + iVar8) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_1801f6e32
// Address: 0x1801f6e32
// Size: 1321 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.1801f6cc0(int64_t arg_28h, int64_t arg_30h, int64_t arg_68h, int64_t arg_78h, int64_t arg_b8h, int64_t arg_c8h,
                  int64_t arg_d0h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_118h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t in_R8;
    int32_t in_R9D;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f6ccf;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&arg_b8h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8);
    if (in_R8 != 1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6cf8;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d10;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)(&stack0x00000038 + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d26;
        fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
        goto code_r0x0001801f737b;
    }
    *(undefined8 *)((int64_t)&arg_e0h + iVar8) = unaff_RBP;
    iVar10 = *(int64_t *)(in_RCX + 0x1020);
    *(undefined8 *)((int64_t)&arg_d8h + iVar8) = unaff_R12;
    iVar1 = *(int64_t *)(in_RCX + 0x10c8);
    *(undefined8 *)((int64_t)&arg_d0h + iVar8) = unaff_R13;
    iVar11 = *(int64_t *)(in_RCX + 0x10c0);
    if ((iVar10 == 0) && (*(int64_t *)(in_RCX + 0x1028) == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d6d;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d85;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)(&stack0x00000038 + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d9b;
        fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
        goto code_r0x0001801f737b;
    }
    if (in_RDX[1] == 0x15) {
        uVar2 = *(undefined8 *)(in_RDX + 2);
        uVar3 = *(undefined8 *)(in_RDX + 10);
        uVar4 = *(undefined8 *)(in_RDX + 8);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6db9;
        fcn.180498030(uVar4, uVar3, uVar2);
        *(undefined8 *)(in_RDX + 10) = *(undefined8 *)(in_RDX + 8);
        goto code_r0x0001801f737b;
    }
    iVar5 = *(int64_t *)(in_RCX + 0x1028);
    *(undefined8 *)((int64_t)&arg_c8h + iVar8) = unaff_R15;
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6df1;
        iVar6 = fcn.18020e980(*(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8), 
                              *(int64_t *)(&stack0x00000038 + iVar8), *(int64_t *)(&stack0x00000040 + iVar8), 
                              *(int64_t *)(&stack0x00000048 + iVar8), *(int64_t *)(&stack0x00000050 + iVar8), 
                              *(int64_t *)(&stack0x00000058 + iVar8), *(int64_t *)(&stack0x00000060 + iVar8), 
                              *(int64_t *)((int64_t)&arg_68h + iVar8), *(int64_t *)(&stack0x00000070 + iVar8), 
                              *(int64_t *)(&stack0x00000088 + iVar8), *(int64_t *)(&stack0x00000090 + iVar8), 
                              *(int64_t *)((int64_t)&arg_d8h + iVar8), *(int64_t *)(&stack0x00000138 + iVar8), 
                              *(int64_t *)(&stack0x00000140 + iVar8));
        if (iVar6 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6dfa;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e12;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e28;
            fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
            goto code_r0x0001801f737b;
        }
        uVar9 = (uint64_t)iVar6;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6de4;
        uVar9 = func_0x0001802570c0();
    }
    *(undefined8 *)((int64_t)&arg_118h + iVar8) = unaff_RBX;
    if (in_R9D == 0) {
        if (*(uint64_t *)(in_RDX + 2) < *(int64_t *)(in_RCX + 0x10d8) + 1U) goto code_r0x0001801f737b;
        *(uint64_t *)(in_RDX + 2) = *(uint64_t *)(in_RDX + 2) - *(int64_t *)(in_RCX + 0x10d8);
    }
    if (uVar9 < 8) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e69;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e81;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)(&stack0x00000038 + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e97;
        fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
        goto code_r0x0001801f737b;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6eab;
    fcn.180498030(iVar1, iVar11, uVar9 - 8);
    *(uint8_t *)((uVar9 - 8) + iVar1) = *(uint8_t *)((uVar9 - 8) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1000);
    *(uint8_t *)((uVar9 - 7) + iVar1) = *(uint8_t *)((uVar9 - 7) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1001);
    *(uint8_t *)((uVar9 - 6) + iVar1) = *(uint8_t *)((uVar9 - 6) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1002);
    *(uint8_t *)((uVar9 - 5) + iVar1) = *(uint8_t *)((uVar9 - 5) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1003);
    *(uint8_t *)((uVar9 - 4) + iVar1) = *(uint8_t *)((uVar9 - 4) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1004);
    *(uint8_t *)((uVar9 - 3) + iVar1) = *(uint8_t *)((uVar9 - 3) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1005);
    *(uint8_t *)((uVar9 - 2) + iVar1) = *(uint8_t *)((uVar9 - 2) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1006);
    *(uint8_t *)((uVar9 - 1) + iVar1) = *(uint8_t *)((uVar9 - 1) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1007);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f3b;
    iVar6 = func_0x0001801d4800(in_RCX);
    if (iVar6 == 0) goto code_r0x0001801f737b;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f5e;
    iVar6 = func_0x000180244550((int64_t)&arg_30h + iVar8, (int64_t)&arg_68h + iVar8, 5, 0);
    if (iVar6 != 0) {
        iVar6 = in_RDX[1];
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f7a;
        iVar6 = func_0x0001802446f0((int64_t)&arg_30h + iVar8, (int64_t)iVar6, 1);
        if (iVar6 != 0) {
            iVar6 = *in_RDX;
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f95;
            iVar6 = func_0x0001802446f0((int64_t)&arg_30h + iVar8, (int64_t)iVar6, 2);
            if (iVar6 != 0) {
                iVar11 = *(int64_t *)(in_RCX + 0x10d8);
                iVar5 = *(int64_t *)(in_RDX + 2);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6fb8;
                iVar6 = func_0x0001802446f0((int64_t)&arg_30h + iVar8, iVar11 + iVar5, 2);
                if (iVar6 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6fcf;
                    iVar6 = func_0x0001802442e0((int64_t)&arg_30h + iVar8, (int64_t)&var_20h + iVar8);
                    if ((iVar6 != 0) && (*(int64_t *)((int64_t)&var_20h + iVar8) == 5)) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6fed;
                        iVar6 = func_0x000180244200((int64_t)&arg_30h + iVar8);
                        if (iVar6 != 0) {
                            if (*(int64_t *)(in_RCX + 0x1028) == 0) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7139;
                                iVar11 = fcn.18020e940(iVar10);
                                if (iVar11 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7143;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f715b;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar8), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7171;
                                    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                                    goto code_r0x0001801f737b;
                                }
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f717e;
                                iVar6 = fcn.18020efb0(iVar11);
                                *(int32_t *)((int64_t)&var_10h + iVar8) = in_R9D;
                                *(int64_t *)((int64_t)&var_8h + iVar8) = iVar1;
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f719a;
                                iVar7 = fcn.180211b70(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                      *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                      *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                      *(int64_t *)(&stack0x00000050 + iVar8), 
                                                      *(int64_t *)(&stack0x00000058 + iVar8));
                                if (iVar7 < 1) {
code_r0x0001801f72df:
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72e4;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72fc;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar8), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7312;
                                    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                                } else {
                                    if (in_R9D == 0) {
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f71c3;
                                        iVar7 = fcn.180210b80(*(int64_t *)((int64_t)&var_20h + iVar8), 
                                                              *(int64_t *)((int64_t)&arg_28h + iVar8), 
                                                              *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                                              *(int64_t *)(&stack0x00000038 + iVar8));
                                        if (iVar7 < 1) goto code_r0x0001801f72df;
                                    }
                                    if (iVar6 == 7) {
                                        *(int32_t *)((int64_t)&var_8h + iVar8) = in_RDX[2];
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f71e9;
                                        iVar6 = func_0x000180211bb0(iVar10, 0, (int64_t)&var_18h + iVar8, 0);
                                        if (iVar6 < 1) goto code_r0x0001801f737b;
                                    }
                                    *(undefined4 *)((int64_t)&var_8h + iVar8) = 5;
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7210;
                                    iVar6 = func_0x000180211bb0(iVar10, 0, (int64_t)&var_18h + iVar8, 
                                                                (int64_t)&arg_68h + iVar8);
                                    if (0 < iVar6) {
                                        uVar2 = *(undefined8 *)(in_RDX + 10);
                                        uVar3 = *(undefined8 *)(in_RDX + 8);
                                        *(int32_t *)((int64_t)&var_8h + iVar8) = in_RDX[2];
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7234;
                                        iVar6 = func_0x000180211bb0(iVar10, uVar3, (int64_t)&var_18h + iVar8, uVar2);
                                        if (0 < iVar6) {
                                            iVar1 = *(int64_t *)(in_RDX + 8);
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7252;
                                            iVar6 = func_0x000180211b40(iVar10, *(int32_t *)((int64_t)&var_18h + iVar8)
                                                                                + iVar1, (int64_t)&var_18h + iVar8 + 4);
                                            if (((0 < iVar6) &&
                                                ((int64_t)(*(int32_t *)((int64_t)&var_18h + iVar8 + 4) +
                                                          *(int32_t *)((int64_t)&var_18h + iVar8)) ==
                                                 *(int64_t *)(in_RDX + 2))) && (in_R9D != 0)) {
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7291;
                                                iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_20h + iVar8), 
                                                                      *(int64_t *)((int64_t)&arg_28h + iVar8), 
                                                                      *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                                                      *(int64_t *)(&stack0x00000038 + iVar8));
                                                if (iVar6 < 1) {
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f729a;
                                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_10h + iVar8));
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72b2;
                                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_20h + iVar8), 
                                                                  *(int64_t *)(&stack0x00000038 + iVar8));
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72c8;
                                                    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                                                } else {
                                                    *(int64_t *)(in_RDX + 2) =
                                                         *(int64_t *)(in_RDX + 2) + *(int64_t *)(in_RCX + 0x10d8);
                                                }
                                            }
                                        }
                                    }
                                }
                                goto code_r0x0001801f737b;
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f700c;
                            iVar10 = func_0x000180256f80();
                            if (iVar10 == 0) {
code_r0x0001801f70ef:
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70f4;
                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                              *(int64_t *)((int64_t)&var_10h + iVar8));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f710c;
                                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                              *(int64_t *)((int64_t)&var_10h + iVar8), 
                                              *(int64_t *)((int64_t)&var_18h + iVar8), 
                                              *(int64_t *)((int64_t)&var_20h + iVar8), 
                                              *(int64_t *)(&stack0x00000038 + iVar8));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7122;
                                fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                            } else {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7026;
                                iVar6 = func_0x0001802574c0(iVar10, iVar1, uVar9);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7044;
                                iVar6 = func_0x0001802574c0(iVar10, (int64_t)&arg_68h + iVar8, 5);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                uVar2 = *(undefined8 *)(in_RDX + 2);
                                uVar3 = *(undefined8 *)(in_RDX + 10);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f705c;
                                iVar6 = func_0x0001802574c0(iVar10, uVar3, uVar2);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                uVar2 = *(undefined8 *)(in_RCX + 0x10d8);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7080;
                                iVar6 = func_0x000180257200(iVar10, (int64_t)&arg_78h + iVar8, (int64_t)&arg_28h + iVar8
                                                            , uVar2);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                iVar1 = *(int64_t *)(in_RDX + 8);
                                iVar11 = *(int64_t *)(in_RDX + 2);
                                uVar2 = *(undefined8 *)(in_RCX + 0x10d8);
                                if (in_R9D != 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70a8;
                                    fcn.180498030(iVar1 + iVar11, (int64_t)&arg_78h + iVar8);
                                    *(int64_t *)(in_RDX + 2) = *(int64_t *)(in_RDX + 2) + *(int64_t *)(in_RCX + 0x10d8);
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70c0;
                                    func_0x000180257070(iVar10);
                                    goto code_r0x0001801f737b;
                                }
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70d7;
                                iVar6 = func_0x0001802262e0((int64_t)&arg_78h + iVar8, iVar1 + iVar11, uVar2);
                                if (iVar6 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70e8;
                                    func_0x000180257070(iVar10);
                                    goto code_r0x0001801f737b;
                                }
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f712a;
                            func_0x000180257070(iVar10);
                            goto code_r0x0001801f737b;
                        }
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7319;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7331;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                  *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                  *(int64_t *)(&stack0x00000038 + iVar8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7347;
    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7351;
    func_0x000180243fb0((int64_t)&arg_30h + iVar8);
code_r0x0001801f737b:
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f738b;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_b8h + iVar8) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_1801f735b
// Address: 0x1801f735b
// Size: 8 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.1801f6cc0(int64_t arg_28h, int64_t arg_30h, int64_t arg_68h, int64_t arg_78h, int64_t arg_b8h, int64_t arg_c8h,
                  int64_t arg_d0h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_118h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t in_R8;
    int32_t in_R9D;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f6ccf;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&arg_b8h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8);
    if (in_R8 != 1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6cf8;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d10;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)(&stack0x00000038 + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d26;
        fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
        goto code_r0x0001801f737b;
    }
    *(undefined8 *)((int64_t)&arg_e0h + iVar8) = unaff_RBP;
    iVar10 = *(int64_t *)(in_RCX + 0x1020);
    *(undefined8 *)((int64_t)&arg_d8h + iVar8) = unaff_R12;
    iVar1 = *(int64_t *)(in_RCX + 0x10c8);
    *(undefined8 *)((int64_t)&arg_d0h + iVar8) = unaff_R13;
    iVar11 = *(int64_t *)(in_RCX + 0x10c0);
    if ((iVar10 == 0) && (*(int64_t *)(in_RCX + 0x1028) == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d6d;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d85;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)(&stack0x00000038 + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d9b;
        fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
        goto code_r0x0001801f737b;
    }
    if (in_RDX[1] == 0x15) {
        uVar2 = *(undefined8 *)(in_RDX + 2);
        uVar3 = *(undefined8 *)(in_RDX + 10);
        uVar4 = *(undefined8 *)(in_RDX + 8);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6db9;
        fcn.180498030(uVar4, uVar3, uVar2);
        *(undefined8 *)(in_RDX + 10) = *(undefined8 *)(in_RDX + 8);
        goto code_r0x0001801f737b;
    }
    iVar5 = *(int64_t *)(in_RCX + 0x1028);
    *(undefined8 *)((int64_t)&arg_c8h + iVar8) = unaff_R15;
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6df1;
        iVar6 = fcn.18020e980(*(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8), 
                              *(int64_t *)(&stack0x00000038 + iVar8), *(int64_t *)(&stack0x00000040 + iVar8), 
                              *(int64_t *)(&stack0x00000048 + iVar8), *(int64_t *)(&stack0x00000050 + iVar8), 
                              *(int64_t *)(&stack0x00000058 + iVar8), *(int64_t *)(&stack0x00000060 + iVar8), 
                              *(int64_t *)((int64_t)&arg_68h + iVar8), *(int64_t *)(&stack0x00000070 + iVar8), 
                              *(int64_t *)(&stack0x00000088 + iVar8), *(int64_t *)(&stack0x00000090 + iVar8), 
                              *(int64_t *)((int64_t)&arg_d8h + iVar8), *(int64_t *)(&stack0x00000138 + iVar8), 
                              *(int64_t *)(&stack0x00000140 + iVar8));
        if (iVar6 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6dfa;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e12;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e28;
            fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
            goto code_r0x0001801f737b;
        }
        uVar9 = (uint64_t)iVar6;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6de4;
        uVar9 = func_0x0001802570c0();
    }
    *(undefined8 *)((int64_t)&arg_118h + iVar8) = unaff_RBX;
    if (in_R9D == 0) {
        if (*(uint64_t *)(in_RDX + 2) < *(int64_t *)(in_RCX + 0x10d8) + 1U) goto code_r0x0001801f737b;
        *(uint64_t *)(in_RDX + 2) = *(uint64_t *)(in_RDX + 2) - *(int64_t *)(in_RCX + 0x10d8);
    }
    if (uVar9 < 8) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e69;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e81;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)(&stack0x00000038 + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e97;
        fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
        goto code_r0x0001801f737b;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6eab;
    fcn.180498030(iVar1, iVar11, uVar9 - 8);
    *(uint8_t *)((uVar9 - 8) + iVar1) = *(uint8_t *)((uVar9 - 8) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1000);
    *(uint8_t *)((uVar9 - 7) + iVar1) = *(uint8_t *)((uVar9 - 7) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1001);
    *(uint8_t *)((uVar9 - 6) + iVar1) = *(uint8_t *)((uVar9 - 6) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1002);
    *(uint8_t *)((uVar9 - 5) + iVar1) = *(uint8_t *)((uVar9 - 5) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1003);
    *(uint8_t *)((uVar9 - 4) + iVar1) = *(uint8_t *)((uVar9 - 4) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1004);
    *(uint8_t *)((uVar9 - 3) + iVar1) = *(uint8_t *)((uVar9 - 3) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1005);
    *(uint8_t *)((uVar9 - 2) + iVar1) = *(uint8_t *)((uVar9 - 2) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1006);
    *(uint8_t *)((uVar9 - 1) + iVar1) = *(uint8_t *)((uVar9 - 1) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1007);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f3b;
    iVar6 = func_0x0001801d4800(in_RCX);
    if (iVar6 == 0) goto code_r0x0001801f737b;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f5e;
    iVar6 = func_0x000180244550((int64_t)&arg_30h + iVar8, (int64_t)&arg_68h + iVar8, 5, 0);
    if (iVar6 != 0) {
        iVar6 = in_RDX[1];
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f7a;
        iVar6 = func_0x0001802446f0((int64_t)&arg_30h + iVar8, (int64_t)iVar6, 1);
        if (iVar6 != 0) {
            iVar6 = *in_RDX;
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f95;
            iVar6 = func_0x0001802446f0((int64_t)&arg_30h + iVar8, (int64_t)iVar6, 2);
            if (iVar6 != 0) {
                iVar11 = *(int64_t *)(in_RCX + 0x10d8);
                iVar5 = *(int64_t *)(in_RDX + 2);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6fb8;
                iVar6 = func_0x0001802446f0((int64_t)&arg_30h + iVar8, iVar11 + iVar5, 2);
                if (iVar6 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6fcf;
                    iVar6 = func_0x0001802442e0((int64_t)&arg_30h + iVar8, (int64_t)&var_20h + iVar8);
                    if ((iVar6 != 0) && (*(int64_t *)((int64_t)&var_20h + iVar8) == 5)) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6fed;
                        iVar6 = func_0x000180244200((int64_t)&arg_30h + iVar8);
                        if (iVar6 != 0) {
                            if (*(int64_t *)(in_RCX + 0x1028) == 0) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7139;
                                iVar11 = fcn.18020e940(iVar10);
                                if (iVar11 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7143;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f715b;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar8), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7171;
                                    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                                    goto code_r0x0001801f737b;
                                }
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f717e;
                                iVar6 = fcn.18020efb0(iVar11);
                                *(int32_t *)((int64_t)&var_10h + iVar8) = in_R9D;
                                *(int64_t *)((int64_t)&var_8h + iVar8) = iVar1;
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f719a;
                                iVar7 = fcn.180211b70(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                      *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                      *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                      *(int64_t *)(&stack0x00000050 + iVar8), 
                                                      *(int64_t *)(&stack0x00000058 + iVar8));
                                if (iVar7 < 1) {
code_r0x0001801f72df:
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72e4;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72fc;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar8), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7312;
                                    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                                } else {
                                    if (in_R9D == 0) {
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f71c3;
                                        iVar7 = fcn.180210b80(*(int64_t *)((int64_t)&var_20h + iVar8), 
                                                              *(int64_t *)((int64_t)&arg_28h + iVar8), 
                                                              *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                                              *(int64_t *)(&stack0x00000038 + iVar8));
                                        if (iVar7 < 1) goto code_r0x0001801f72df;
                                    }
                                    if (iVar6 == 7) {
                                        *(int32_t *)((int64_t)&var_8h + iVar8) = in_RDX[2];
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f71e9;
                                        iVar6 = func_0x000180211bb0(iVar10, 0, (int64_t)&var_18h + iVar8, 0);
                                        if (iVar6 < 1) goto code_r0x0001801f737b;
                                    }
                                    *(undefined4 *)((int64_t)&var_8h + iVar8) = 5;
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7210;
                                    iVar6 = func_0x000180211bb0(iVar10, 0, (int64_t)&var_18h + iVar8, 
                                                                (int64_t)&arg_68h + iVar8);
                                    if (0 < iVar6) {
                                        uVar2 = *(undefined8 *)(in_RDX + 10);
                                        uVar3 = *(undefined8 *)(in_RDX + 8);
                                        *(int32_t *)((int64_t)&var_8h + iVar8) = in_RDX[2];
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7234;
                                        iVar6 = func_0x000180211bb0(iVar10, uVar3, (int64_t)&var_18h + iVar8, uVar2);
                                        if (0 < iVar6) {
                                            iVar1 = *(int64_t *)(in_RDX + 8);
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7252;
                                            iVar6 = func_0x000180211b40(iVar10, *(int32_t *)((int64_t)&var_18h + iVar8)
                                                                                + iVar1, (int64_t)&var_18h + iVar8 + 4);
                                            if (((0 < iVar6) &&
                                                ((int64_t)(*(int32_t *)((int64_t)&var_18h + iVar8 + 4) +
                                                          *(int32_t *)((int64_t)&var_18h + iVar8)) ==
                                                 *(int64_t *)(in_RDX + 2))) && (in_R9D != 0)) {
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7291;
                                                iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_20h + iVar8), 
                                                                      *(int64_t *)((int64_t)&arg_28h + iVar8), 
                                                                      *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                                                      *(int64_t *)(&stack0x00000038 + iVar8));
                                                if (iVar6 < 1) {
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f729a;
                                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_10h + iVar8));
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72b2;
                                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_20h + iVar8), 
                                                                  *(int64_t *)(&stack0x00000038 + iVar8));
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72c8;
                                                    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                                                } else {
                                                    *(int64_t *)(in_RDX + 2) =
                                                         *(int64_t *)(in_RDX + 2) + *(int64_t *)(in_RCX + 0x10d8);
                                                }
                                            }
                                        }
                                    }
                                }
                                goto code_r0x0001801f737b;
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f700c;
                            iVar10 = func_0x000180256f80();
                            if (iVar10 == 0) {
code_r0x0001801f70ef:
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70f4;
                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                              *(int64_t *)((int64_t)&var_10h + iVar8));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f710c;
                                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                              *(int64_t *)((int64_t)&var_10h + iVar8), 
                                              *(int64_t *)((int64_t)&var_18h + iVar8), 
                                              *(int64_t *)((int64_t)&var_20h + iVar8), 
                                              *(int64_t *)(&stack0x00000038 + iVar8));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7122;
                                fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                            } else {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7026;
                                iVar6 = func_0x0001802574c0(iVar10, iVar1, uVar9);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7044;
                                iVar6 = func_0x0001802574c0(iVar10, (int64_t)&arg_68h + iVar8, 5);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                uVar2 = *(undefined8 *)(in_RDX + 2);
                                uVar3 = *(undefined8 *)(in_RDX + 10);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f705c;
                                iVar6 = func_0x0001802574c0(iVar10, uVar3, uVar2);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                uVar2 = *(undefined8 *)(in_RCX + 0x10d8);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7080;
                                iVar6 = func_0x000180257200(iVar10, (int64_t)&arg_78h + iVar8, (int64_t)&arg_28h + iVar8
                                                            , uVar2);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                iVar1 = *(int64_t *)(in_RDX + 8);
                                iVar11 = *(int64_t *)(in_RDX + 2);
                                uVar2 = *(undefined8 *)(in_RCX + 0x10d8);
                                if (in_R9D != 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70a8;
                                    fcn.180498030(iVar1 + iVar11, (int64_t)&arg_78h + iVar8);
                                    *(int64_t *)(in_RDX + 2) = *(int64_t *)(in_RDX + 2) + *(int64_t *)(in_RCX + 0x10d8);
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70c0;
                                    func_0x000180257070(iVar10);
                                    goto code_r0x0001801f737b;
                                }
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70d7;
                                iVar6 = func_0x0001802262e0((int64_t)&arg_78h + iVar8, iVar1 + iVar11, uVar2);
                                if (iVar6 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70e8;
                                    func_0x000180257070(iVar10);
                                    goto code_r0x0001801f737b;
                                }
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f712a;
                            func_0x000180257070(iVar10);
                            goto code_r0x0001801f737b;
                        }
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7319;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7331;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                  *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                  *(int64_t *)(&stack0x00000038 + iVar8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7347;
    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7351;
    func_0x000180243fb0((int64_t)&arg_30h + iVar8);
code_r0x0001801f737b:
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f738b;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_b8h + iVar8) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_1801f7363
// Address: 0x1801f7363
// Size: 24 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.1801f6cc0(int64_t arg_28h, int64_t arg_30h, int64_t arg_68h, int64_t arg_78h, int64_t arg_b8h, int64_t arg_c8h,
                  int64_t arg_d0h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_118h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t in_R8;
    int32_t in_R9D;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f6ccf;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&arg_b8h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8);
    if (in_R8 != 1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6cf8;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d10;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)(&stack0x00000038 + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d26;
        fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
        goto code_r0x0001801f737b;
    }
    *(undefined8 *)((int64_t)&arg_e0h + iVar8) = unaff_RBP;
    iVar10 = *(int64_t *)(in_RCX + 0x1020);
    *(undefined8 *)((int64_t)&arg_d8h + iVar8) = unaff_R12;
    iVar1 = *(int64_t *)(in_RCX + 0x10c8);
    *(undefined8 *)((int64_t)&arg_d0h + iVar8) = unaff_R13;
    iVar11 = *(int64_t *)(in_RCX + 0x10c0);
    if ((iVar10 == 0) && (*(int64_t *)(in_RCX + 0x1028) == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d6d;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d85;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)(&stack0x00000038 + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d9b;
        fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
        goto code_r0x0001801f737b;
    }
    if (in_RDX[1] == 0x15) {
        uVar2 = *(undefined8 *)(in_RDX + 2);
        uVar3 = *(undefined8 *)(in_RDX + 10);
        uVar4 = *(undefined8 *)(in_RDX + 8);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6db9;
        fcn.180498030(uVar4, uVar3, uVar2);
        *(undefined8 *)(in_RDX + 10) = *(undefined8 *)(in_RDX + 8);
        goto code_r0x0001801f737b;
    }
    iVar5 = *(int64_t *)(in_RCX + 0x1028);
    *(undefined8 *)((int64_t)&arg_c8h + iVar8) = unaff_R15;
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6df1;
        iVar6 = fcn.18020e980(*(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8), 
                              *(int64_t *)(&stack0x00000038 + iVar8), *(int64_t *)(&stack0x00000040 + iVar8), 
                              *(int64_t *)(&stack0x00000048 + iVar8), *(int64_t *)(&stack0x00000050 + iVar8), 
                              *(int64_t *)(&stack0x00000058 + iVar8), *(int64_t *)(&stack0x00000060 + iVar8), 
                              *(int64_t *)((int64_t)&arg_68h + iVar8), *(int64_t *)(&stack0x00000070 + iVar8), 
                              *(int64_t *)(&stack0x00000088 + iVar8), *(int64_t *)(&stack0x00000090 + iVar8), 
                              *(int64_t *)((int64_t)&arg_d8h + iVar8), *(int64_t *)(&stack0x00000138 + iVar8), 
                              *(int64_t *)(&stack0x00000140 + iVar8));
        if (iVar6 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6dfa;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e12;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e28;
            fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
            goto code_r0x0001801f737b;
        }
        uVar9 = (uint64_t)iVar6;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6de4;
        uVar9 = func_0x0001802570c0();
    }
    *(undefined8 *)((int64_t)&arg_118h + iVar8) = unaff_RBX;
    if (in_R9D == 0) {
        if (*(uint64_t *)(in_RDX + 2) < *(int64_t *)(in_RCX + 0x10d8) + 1U) goto code_r0x0001801f737b;
        *(uint64_t *)(in_RDX + 2) = *(uint64_t *)(in_RDX + 2) - *(int64_t *)(in_RCX + 0x10d8);
    }
    if (uVar9 < 8) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e69;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e81;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)(&stack0x00000038 + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e97;
        fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
        goto code_r0x0001801f737b;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6eab;
    fcn.180498030(iVar1, iVar11, uVar9 - 8);
    *(uint8_t *)((uVar9 - 8) + iVar1) = *(uint8_t *)((uVar9 - 8) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1000);
    *(uint8_t *)((uVar9 - 7) + iVar1) = *(uint8_t *)((uVar9 - 7) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1001);
    *(uint8_t *)((uVar9 - 6) + iVar1) = *(uint8_t *)((uVar9 - 6) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1002);
    *(uint8_t *)((uVar9 - 5) + iVar1) = *(uint8_t *)((uVar9 - 5) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1003);
    *(uint8_t *)((uVar9 - 4) + iVar1) = *(uint8_t *)((uVar9 - 4) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1004);
    *(uint8_t *)((uVar9 - 3) + iVar1) = *(uint8_t *)((uVar9 - 3) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1005);
    *(uint8_t *)((uVar9 - 2) + iVar1) = *(uint8_t *)((uVar9 - 2) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1006);
    *(uint8_t *)((uVar9 - 1) + iVar1) = *(uint8_t *)((uVar9 - 1) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1007);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f3b;
    iVar6 = func_0x0001801d4800(in_RCX);
    if (iVar6 == 0) goto code_r0x0001801f737b;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f5e;
    iVar6 = func_0x000180244550((int64_t)&arg_30h + iVar8, (int64_t)&arg_68h + iVar8, 5, 0);
    if (iVar6 != 0) {
        iVar6 = in_RDX[1];
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f7a;
        iVar6 = func_0x0001802446f0((int64_t)&arg_30h + iVar8, (int64_t)iVar6, 1);
        if (iVar6 != 0) {
            iVar6 = *in_RDX;
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f95;
            iVar6 = func_0x0001802446f0((int64_t)&arg_30h + iVar8, (int64_t)iVar6, 2);
            if (iVar6 != 0) {
                iVar11 = *(int64_t *)(in_RCX + 0x10d8);
                iVar5 = *(int64_t *)(in_RDX + 2);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6fb8;
                iVar6 = func_0x0001802446f0((int64_t)&arg_30h + iVar8, iVar11 + iVar5, 2);
                if (iVar6 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6fcf;
                    iVar6 = func_0x0001802442e0((int64_t)&arg_30h + iVar8, (int64_t)&var_20h + iVar8);
                    if ((iVar6 != 0) && (*(int64_t *)((int64_t)&var_20h + iVar8) == 5)) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6fed;
                        iVar6 = func_0x000180244200((int64_t)&arg_30h + iVar8);
                        if (iVar6 != 0) {
                            if (*(int64_t *)(in_RCX + 0x1028) == 0) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7139;
                                iVar11 = fcn.18020e940(iVar10);
                                if (iVar11 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7143;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f715b;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar8), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7171;
                                    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                                    goto code_r0x0001801f737b;
                                }
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f717e;
                                iVar6 = fcn.18020efb0(iVar11);
                                *(int32_t *)((int64_t)&var_10h + iVar8) = in_R9D;
                                *(int64_t *)((int64_t)&var_8h + iVar8) = iVar1;
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f719a;
                                iVar7 = fcn.180211b70(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                      *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                      *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                      *(int64_t *)(&stack0x00000050 + iVar8), 
                                                      *(int64_t *)(&stack0x00000058 + iVar8));
                                if (iVar7 < 1) {
code_r0x0001801f72df:
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72e4;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72fc;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar8), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7312;
                                    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                                } else {
                                    if (in_R9D == 0) {
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f71c3;
                                        iVar7 = fcn.180210b80(*(int64_t *)((int64_t)&var_20h + iVar8), 
                                                              *(int64_t *)((int64_t)&arg_28h + iVar8), 
                                                              *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                                              *(int64_t *)(&stack0x00000038 + iVar8));
                                        if (iVar7 < 1) goto code_r0x0001801f72df;
                                    }
                                    if (iVar6 == 7) {
                                        *(int32_t *)((int64_t)&var_8h + iVar8) = in_RDX[2];
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f71e9;
                                        iVar6 = func_0x000180211bb0(iVar10, 0, (int64_t)&var_18h + iVar8, 0);
                                        if (iVar6 < 1) goto code_r0x0001801f737b;
                                    }
                                    *(undefined4 *)((int64_t)&var_8h + iVar8) = 5;
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7210;
                                    iVar6 = func_0x000180211bb0(iVar10, 0, (int64_t)&var_18h + iVar8, 
                                                                (int64_t)&arg_68h + iVar8);
                                    if (0 < iVar6) {
                                        uVar2 = *(undefined8 *)(in_RDX + 10);
                                        uVar3 = *(undefined8 *)(in_RDX + 8);
                                        *(int32_t *)((int64_t)&var_8h + iVar8) = in_RDX[2];
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7234;
                                        iVar6 = func_0x000180211bb0(iVar10, uVar3, (int64_t)&var_18h + iVar8, uVar2);
                                        if (0 < iVar6) {
                                            iVar1 = *(int64_t *)(in_RDX + 8);
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7252;
                                            iVar6 = func_0x000180211b40(iVar10, *(int32_t *)((int64_t)&var_18h + iVar8)
                                                                                + iVar1, (int64_t)&var_18h + iVar8 + 4);
                                            if (((0 < iVar6) &&
                                                ((int64_t)(*(int32_t *)((int64_t)&var_18h + iVar8 + 4) +
                                                          *(int32_t *)((int64_t)&var_18h + iVar8)) ==
                                                 *(int64_t *)(in_RDX + 2))) && (in_R9D != 0)) {
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7291;
                                                iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_20h + iVar8), 
                                                                      *(int64_t *)((int64_t)&arg_28h + iVar8), 
                                                                      *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                                                      *(int64_t *)(&stack0x00000038 + iVar8));
                                                if (iVar6 < 1) {
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f729a;
                                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_10h + iVar8));
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72b2;
                                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_20h + iVar8), 
                                                                  *(int64_t *)(&stack0x00000038 + iVar8));
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72c8;
                                                    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                                                } else {
                                                    *(int64_t *)(in_RDX + 2) =
                                                         *(int64_t *)(in_RDX + 2) + *(int64_t *)(in_RCX + 0x10d8);
                                                }
                                            }
                                        }
                                    }
                                }
                                goto code_r0x0001801f737b;
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f700c;
                            iVar10 = func_0x000180256f80();
                            if (iVar10 == 0) {
code_r0x0001801f70ef:
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70f4;
                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                              *(int64_t *)((int64_t)&var_10h + iVar8));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f710c;
                                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                              *(int64_t *)((int64_t)&var_10h + iVar8), 
                                              *(int64_t *)((int64_t)&var_18h + iVar8), 
                                              *(int64_t *)((int64_t)&var_20h + iVar8), 
                                              *(int64_t *)(&stack0x00000038 + iVar8));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7122;
                                fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                            } else {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7026;
                                iVar6 = func_0x0001802574c0(iVar10, iVar1, uVar9);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7044;
                                iVar6 = func_0x0001802574c0(iVar10, (int64_t)&arg_68h + iVar8, 5);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                uVar2 = *(undefined8 *)(in_RDX + 2);
                                uVar3 = *(undefined8 *)(in_RDX + 10);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f705c;
                                iVar6 = func_0x0001802574c0(iVar10, uVar3, uVar2);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                uVar2 = *(undefined8 *)(in_RCX + 0x10d8);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7080;
                                iVar6 = func_0x000180257200(iVar10, (int64_t)&arg_78h + iVar8, (int64_t)&arg_28h + iVar8
                                                            , uVar2);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                iVar1 = *(int64_t *)(in_RDX + 8);
                                iVar11 = *(int64_t *)(in_RDX + 2);
                                uVar2 = *(undefined8 *)(in_RCX + 0x10d8);
                                if (in_R9D != 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70a8;
                                    fcn.180498030(iVar1 + iVar11, (int64_t)&arg_78h + iVar8);
                                    *(int64_t *)(in_RDX + 2) = *(int64_t *)(in_RDX + 2) + *(int64_t *)(in_RCX + 0x10d8);
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70c0;
                                    func_0x000180257070(iVar10);
                                    goto code_r0x0001801f737b;
                                }
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70d7;
                                iVar6 = func_0x0001802262e0((int64_t)&arg_78h + iVar8, iVar1 + iVar11, uVar2);
                                if (iVar6 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70e8;
                                    func_0x000180257070(iVar10);
                                    goto code_r0x0001801f737b;
                                }
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f712a;
                            func_0x000180257070(iVar10);
                            goto code_r0x0001801f737b;
                        }
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7319;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7331;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                  *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                  *(int64_t *)(&stack0x00000038 + iVar8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7347;
    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7351;
    func_0x000180243fb0((int64_t)&arg_30h + iVar8);
code_r0x0001801f737b:
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f738b;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_b8h + iVar8) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_1801f737b
// Address: 0x1801f737b
// Size: 28 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.1801f6cc0(int64_t arg_28h, int64_t arg_30h, int64_t arg_68h, int64_t arg_78h, int64_t arg_b8h, int64_t arg_c8h,
                  int64_t arg_d0h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_118h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t in_R8;
    int32_t in_R9D;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f6ccf;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&arg_b8h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8);
    if (in_R8 != 1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6cf8;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d10;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)(&stack0x00000038 + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d26;
        fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
        goto code_r0x0001801f737b;
    }
    *(undefined8 *)((int64_t)&arg_e0h + iVar8) = unaff_RBP;
    iVar10 = *(int64_t *)(in_RCX + 0x1020);
    *(undefined8 *)((int64_t)&arg_d8h + iVar8) = unaff_R12;
    iVar1 = *(int64_t *)(in_RCX + 0x10c8);
    *(undefined8 *)((int64_t)&arg_d0h + iVar8) = unaff_R13;
    iVar11 = *(int64_t *)(in_RCX + 0x10c0);
    if ((iVar10 == 0) && (*(int64_t *)(in_RCX + 0x1028) == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d6d;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d85;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)(&stack0x00000038 + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6d9b;
        fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
        goto code_r0x0001801f737b;
    }
    if (in_RDX[1] == 0x15) {
        uVar2 = *(undefined8 *)(in_RDX + 2);
        uVar3 = *(undefined8 *)(in_RDX + 10);
        uVar4 = *(undefined8 *)(in_RDX + 8);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6db9;
        fcn.180498030(uVar4, uVar3, uVar2);
        *(undefined8 *)(in_RDX + 10) = *(undefined8 *)(in_RDX + 8);
        goto code_r0x0001801f737b;
    }
    iVar5 = *(int64_t *)(in_RCX + 0x1028);
    *(undefined8 *)((int64_t)&arg_c8h + iVar8) = unaff_R15;
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6df1;
        iVar6 = fcn.18020e980(*(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8), 
                              *(int64_t *)(&stack0x00000038 + iVar8), *(int64_t *)(&stack0x00000040 + iVar8), 
                              *(int64_t *)(&stack0x00000048 + iVar8), *(int64_t *)(&stack0x00000050 + iVar8), 
                              *(int64_t *)(&stack0x00000058 + iVar8), *(int64_t *)(&stack0x00000060 + iVar8), 
                              *(int64_t *)((int64_t)&arg_68h + iVar8), *(int64_t *)(&stack0x00000070 + iVar8), 
                              *(int64_t *)(&stack0x00000088 + iVar8), *(int64_t *)(&stack0x00000090 + iVar8), 
                              *(int64_t *)((int64_t)&arg_d8h + iVar8), *(int64_t *)(&stack0x00000138 + iVar8), 
                              *(int64_t *)(&stack0x00000140 + iVar8));
        if (iVar6 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6dfa;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e12;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e28;
            fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
            goto code_r0x0001801f737b;
        }
        uVar9 = (uint64_t)iVar6;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6de4;
        uVar9 = func_0x0001802570c0();
    }
    *(undefined8 *)((int64_t)&arg_118h + iVar8) = unaff_RBX;
    if (in_R9D == 0) {
        if (*(uint64_t *)(in_RDX + 2) < *(int64_t *)(in_RCX + 0x10d8) + 1U) goto code_r0x0001801f737b;
        *(uint64_t *)(in_RDX + 2) = *(uint64_t *)(in_RDX + 2) - *(int64_t *)(in_RCX + 0x10d8);
    }
    if (uVar9 < 8) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e69;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e81;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)(&stack0x00000038 + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6e97;
        fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
        goto code_r0x0001801f737b;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6eab;
    fcn.180498030(iVar1, iVar11, uVar9 - 8);
    *(uint8_t *)((uVar9 - 8) + iVar1) = *(uint8_t *)((uVar9 - 8) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1000);
    *(uint8_t *)((uVar9 - 7) + iVar1) = *(uint8_t *)((uVar9 - 7) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1001);
    *(uint8_t *)((uVar9 - 6) + iVar1) = *(uint8_t *)((uVar9 - 6) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1002);
    *(uint8_t *)((uVar9 - 5) + iVar1) = *(uint8_t *)((uVar9 - 5) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1003);
    *(uint8_t *)((uVar9 - 4) + iVar1) = *(uint8_t *)((uVar9 - 4) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1004);
    *(uint8_t *)((uVar9 - 3) + iVar1) = *(uint8_t *)((uVar9 - 3) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1005);
    *(uint8_t *)((uVar9 - 2) + iVar1) = *(uint8_t *)((uVar9 - 2) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1006);
    *(uint8_t *)((uVar9 - 1) + iVar1) = *(uint8_t *)((uVar9 - 1) + iVar11) ^ *(uint8_t *)(in_RCX + 0x1007);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f3b;
    iVar6 = func_0x0001801d4800(in_RCX);
    if (iVar6 == 0) goto code_r0x0001801f737b;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f5e;
    iVar6 = func_0x000180244550((int64_t)&arg_30h + iVar8, (int64_t)&arg_68h + iVar8, 5, 0);
    if (iVar6 != 0) {
        iVar6 = in_RDX[1];
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f7a;
        iVar6 = func_0x0001802446f0((int64_t)&arg_30h + iVar8, (int64_t)iVar6, 1);
        if (iVar6 != 0) {
            iVar6 = *in_RDX;
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6f95;
            iVar6 = func_0x0001802446f0((int64_t)&arg_30h + iVar8, (int64_t)iVar6, 2);
            if (iVar6 != 0) {
                iVar11 = *(int64_t *)(in_RCX + 0x10d8);
                iVar5 = *(int64_t *)(in_RDX + 2);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6fb8;
                iVar6 = func_0x0001802446f0((int64_t)&arg_30h + iVar8, iVar11 + iVar5, 2);
                if (iVar6 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6fcf;
                    iVar6 = func_0x0001802442e0((int64_t)&arg_30h + iVar8, (int64_t)&var_20h + iVar8);
                    if ((iVar6 != 0) && (*(int64_t *)((int64_t)&var_20h + iVar8) == 5)) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f6fed;
                        iVar6 = func_0x000180244200((int64_t)&arg_30h + iVar8);
                        if (iVar6 != 0) {
                            if (*(int64_t *)(in_RCX + 0x1028) == 0) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7139;
                                iVar11 = fcn.18020e940(iVar10);
                                if (iVar11 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7143;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f715b;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar8), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7171;
                                    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                                    goto code_r0x0001801f737b;
                                }
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f717e;
                                iVar6 = fcn.18020efb0(iVar11);
                                *(int32_t *)((int64_t)&var_10h + iVar8) = in_R9D;
                                *(int64_t *)((int64_t)&var_8h + iVar8) = iVar1;
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f719a;
                                iVar7 = fcn.180211b70(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                      *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                      *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                      *(int64_t *)(&stack0x00000050 + iVar8), 
                                                      *(int64_t *)(&stack0x00000058 + iVar8));
                                if (iVar7 < 1) {
code_r0x0001801f72df:
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72e4;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72fc;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar8), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7312;
                                    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                                } else {
                                    if (in_R9D == 0) {
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f71c3;
                                        iVar7 = fcn.180210b80(*(int64_t *)((int64_t)&var_20h + iVar8), 
                                                              *(int64_t *)((int64_t)&arg_28h + iVar8), 
                                                              *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                                              *(int64_t *)(&stack0x00000038 + iVar8));
                                        if (iVar7 < 1) goto code_r0x0001801f72df;
                                    }
                                    if (iVar6 == 7) {
                                        *(int32_t *)((int64_t)&var_8h + iVar8) = in_RDX[2];
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f71e9;
                                        iVar6 = func_0x000180211bb0(iVar10, 0, (int64_t)&var_18h + iVar8, 0);
                                        if (iVar6 < 1) goto code_r0x0001801f737b;
                                    }
                                    *(undefined4 *)((int64_t)&var_8h + iVar8) = 5;
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7210;
                                    iVar6 = func_0x000180211bb0(iVar10, 0, (int64_t)&var_18h + iVar8, 
                                                                (int64_t)&arg_68h + iVar8);
                                    if (0 < iVar6) {
                                        uVar2 = *(undefined8 *)(in_RDX + 10);
                                        uVar3 = *(undefined8 *)(in_RDX + 8);
                                        *(int32_t *)((int64_t)&var_8h + iVar8) = in_RDX[2];
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7234;
                                        iVar6 = func_0x000180211bb0(iVar10, uVar3, (int64_t)&var_18h + iVar8, uVar2);
                                        if (0 < iVar6) {
                                            iVar1 = *(int64_t *)(in_RDX + 8);
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7252;
                                            iVar6 = func_0x000180211b40(iVar10, *(int32_t *)((int64_t)&var_18h + iVar8)
                                                                                + iVar1, (int64_t)&var_18h + iVar8 + 4);
                                            if (((0 < iVar6) &&
                                                ((int64_t)(*(int32_t *)((int64_t)&var_18h + iVar8 + 4) +
                                                          *(int32_t *)((int64_t)&var_18h + iVar8)) ==
                                                 *(int64_t *)(in_RDX + 2))) && (in_R9D != 0)) {
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7291;
                                                iVar6 = fcn.180210b80(*(int64_t *)((int64_t)&var_20h + iVar8), 
                                                                      *(int64_t *)((int64_t)&arg_28h + iVar8), 
                                                                      *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                                                      *(int64_t *)(&stack0x00000038 + iVar8));
                                                if (iVar6 < 1) {
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f729a;
                                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_10h + iVar8));
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72b2;
                                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_10h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_18h + iVar8), 
                                                                  *(int64_t *)((int64_t)&var_20h + iVar8), 
                                                                  *(int64_t *)(&stack0x00000038 + iVar8));
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f72c8;
                                                    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                                                } else {
                                                    *(int64_t *)(in_RDX + 2) =
                                                         *(int64_t *)(in_RDX + 2) + *(int64_t *)(in_RCX + 0x10d8);
                                                }
                                            }
                                        }
                                    }
                                }
                                goto code_r0x0001801f737b;
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f700c;
                            iVar10 = func_0x000180256f80();
                            if (iVar10 == 0) {
code_r0x0001801f70ef:
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70f4;
                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                              *(int64_t *)((int64_t)&var_10h + iVar8));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f710c;
                                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                              *(int64_t *)((int64_t)&var_10h + iVar8), 
                                              *(int64_t *)((int64_t)&var_18h + iVar8), 
                                              *(int64_t *)((int64_t)&var_20h + iVar8), 
                                              *(int64_t *)(&stack0x00000038 + iVar8));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7122;
                                fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
                            } else {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7026;
                                iVar6 = func_0x0001802574c0(iVar10, iVar1, uVar9);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7044;
                                iVar6 = func_0x0001802574c0(iVar10, (int64_t)&arg_68h + iVar8, 5);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                uVar2 = *(undefined8 *)(in_RDX + 2);
                                uVar3 = *(undefined8 *)(in_RDX + 10);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f705c;
                                iVar6 = func_0x0001802574c0(iVar10, uVar3, uVar2);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                uVar2 = *(undefined8 *)(in_RCX + 0x10d8);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7080;
                                iVar6 = func_0x000180257200(iVar10, (int64_t)&arg_78h + iVar8, (int64_t)&arg_28h + iVar8
                                                            , uVar2);
                                if (iVar6 == 0) goto code_r0x0001801f70ef;
                                iVar1 = *(int64_t *)(in_RDX + 8);
                                iVar11 = *(int64_t *)(in_RDX + 2);
                                uVar2 = *(undefined8 *)(in_RCX + 0x10d8);
                                if (in_R9D != 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70a8;
                                    fcn.180498030(iVar1 + iVar11, (int64_t)&arg_78h + iVar8);
                                    *(int64_t *)(in_RDX + 2) = *(int64_t *)(in_RDX + 2) + *(int64_t *)(in_RCX + 0x10d8);
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70c0;
                                    func_0x000180257070(iVar10);
                                    goto code_r0x0001801f737b;
                                }
                                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70d7;
                                iVar6 = func_0x0001802262e0((int64_t)&arg_78h + iVar8, iVar1 + iVar11, uVar2);
                                if (iVar6 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f70e8;
                                    func_0x000180257070(iVar10);
                                    goto code_r0x0001801f737b;
                                }
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f712a;
                            func_0x000180257070(iVar10);
                            goto code_r0x0001801f737b;
                        }
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7319;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7331;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                  *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                  *(int64_t *)(&stack0x00000038 + iVar8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7347;
    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f7351;
    func_0x000180243fb0((int64_t)&arg_30h + iVar8);
code_r0x0001801f737b:
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801f738b;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_b8h + iVar8) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_1801f73a0
// Address: 0x1801f73a0
// Size: 260 bytes
// ============================================================
undefined8 fcn.1801f73a0(int64_t param_1, int32_t *param_2)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f73ac;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar1 = param_2[1];
    if (iVar1 != 0x17) {
        if (iVar1 == 0x14) {
            iVar1 = *(int32_t *)(param_1 + 0x1048);
        } else {
            if (iVar1 != 0x15) goto code_r0x0001801f73d6;
            iVar1 = *(int32_t *)(param_1 + 0x10d0);
        }
        if (iVar1 == 0) {
code_r0x0001801f73d6:
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f73db;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f73f3;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f7409;
            fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar2));
            return 0;
        }
    }
    if (*param_2 != 0x303) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f741e;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f7436;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f744c;
        fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar2));
        return 0;
    }
    if (0x4100 < *(uint64_t *)(param_2 + 2)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f7463;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f747b;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f7491;
        fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar2));
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801f74b0
// Address: 0x1801f74b0
// Size: 228 bytes
// ============================================================
bool fcn.1801f74b0(undefined8 param_1, int64_t param_2)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f74bc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int32_t *)(param_2 + 4) != 0x15) {
        if ((*(int64_t *)(param_2 + 8) == 0) || (*(int32_t *)(param_2 + 4) != 0x17)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f7547;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f755f;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f7575;
            fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar2));
            return false;
        }
        iVar3 = *(int64_t *)(param_2 + 8) + -1;
        if (iVar3 != 0) {
            do {
                if (*(char *)(*(int64_t *)(param_2 + 0x20) + iVar3) != '\0') break;
                iVar3 = iVar3 + -1;
            } while (iVar3 != 0);
        }
        *(int64_t *)(param_2 + 8) = iVar3;
        *(uint32_t *)(param_2 + 4) = (uint32_t)*(uint8_t *)(*(int64_t *)(param_2 + 0x20) + iVar3);
    }
    if (0x4000 < *(uint64_t *)(param_2 + 8)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f750c;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f7524;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f753a;
        fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar2));
        return false;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f7585;
    iVar1 = func_0x0001801d5890(param_1);
    return iVar1 != 0;
}

// ============================================================
// Function: FUN_1801f75c0
// Address: 0x1801f75c0
// Size: 419 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801f75c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    char cVar1;
    code *pcVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    char *in_RDX;
    uint64_t uVar8;
    undefined8 in_R8;
    int64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f75de;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((*(int32_t *)(in_RCX + 0x10d0) == 0) || (*in_RDX == '\x15')) {
        cVar1 = *in_RDX;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801f7610;
        iVar4 = func_0x0001802446f0(in_R8, cVar1, 1);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801f7619;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801f7631;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801f7647;
            fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar5));
            return 0;
        }
        uVar6 = *(int64_t *)(in_R9 + 8) + 1;
        *(uint64_t *)(in_R9 + 8) = uVar6;
        if (uVar6 < *(uint32_t *)(in_RCX + 0x104c)) {
            pcVar2 = *(code **)(in_RCX + 0x1138);
            uVar8 = *(uint32_t *)(in_RCX + 0x104c) - uVar6;
            if (pcVar2 == (code *)0x0) {
                uVar7 = *(uint64_t *)(in_RCX + 0x1060);
                if ((uVar7 == 0) && (*(int64_t *)(in_RCX + 0x1068) == 0)) {
                    return 1;
                }
                cVar1 = *in_RDX;
                if (cVar1 == '\x16') {
                    uVar7 = *(uint64_t *)(in_RCX + 0x1068);
                } else if (cVar1 == '\x15') {
                    uVar7 = *(uint64_t *)(in_RCX + 0x1068);
                } else if (cVar1 != '\x17') {
                    return 1;
                }
                if (uVar7 == 0) {
                    return 1;
                }
                if ((uVar7 & uVar7 - 1) == 0) {
                    uVar6 = uVar6 & uVar7 - 1;
                } else {
                    uVar6 = uVar6 % uVar7;
                }
                if (uVar6 == 0) {
                    return 1;
                }
                uVar7 = uVar7 - uVar6;
            } else {
                cVar1 = *in_RDX;
                uVar3 = *(undefined8 *)(in_RCX + 0x1118);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801f7687;
                uVar7 = (*pcVar2)(uVar3, cVar1, uVar6);
            }
            if (uVar7 != 0) {
                if (uVar8 < uVar7) {
                    uVar7 = uVar8;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801f7706;
                iVar4 = func_0x000180244670(in_R8, 0, uVar7);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801f770f;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801f7727;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5), *(int64_t *)((int64_t)&arg_38h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801f773d;
                    fcn.1801d5640(*(int64_t *)((int64_t)&arg_30h + iVar5));
                    return 0;
                }
                *(int64_t *)(in_R9 + 8) = *(int64_t *)(in_R9 + 8) + uVar7;
            }
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801f7770
// Address: 0x1801f7770
// Size: 84 bytes
// ============================================================
undefined8 fcn.1801f7770(undefined8 param_1, int32_t param_2)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801f777a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_2 != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801f7786;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801f779e;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801f77b0;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0xfffffffe;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801f77d0
// Address: 0x1801f77d0
// Size: 216 bytes
// ============================================================
undefined8 fcn.1801f77d0(int64_t arg_28h, int64_t arg_58h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    uint32_t *in_RDX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f77dc;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar1 = *in_RDX;
    uVar2 = *(uint32_t *)(in_RCX + 0x14);
    if (uVar1 == 2) {
        if (uVar2 != 0x10000) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f77ff;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7817;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f782d;
            fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar5));
            return 0;
        }
        if (*(uint64_t *)(in_RDX + 2) < 9) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7845;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f785d;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7873;
            fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar5));
            return 0;
        }
code_r0x0001801f7ae3:
        if (0x4000 < *(uint64_t *)(in_RDX + 2)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7af2;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7b0a;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7b20;
            fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar5));
            return 0;
        }
        return 1;
    }
    if (uVar2 == 0x10000) {
        if ((uVar1 & 0xffffff00) == 0x300) goto code_r0x0001801f7ae3;
        if (*(int32_t *)(in_RCX + 0x10d4) != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RDI;
            uVar3 = *(undefined8 *)(in_RCX + 0xff0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f78c9;
            iVar4 = fcn.180498f90(uVar3, 0x1804b86d4, 4);
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f78e6;
                iVar4 = fcn.180498f90(uVar3, 0x1804b86dc, 5);
                if (iVar4 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7903;
                    iVar4 = fcn.180498f90(uVar3, 0x1804b86e4, 5);
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7920;
                        iVar4 = fcn.180498f90(uVar3, 0x1804a57e8, 5);
                        if (iVar4 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f793d;
                            iVar4 = fcn.180498f90(uVar3, 0x1804b86ec, 5);
                            if (iVar4 != 0) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f795a;
                                iVar4 = fcn.180498f90(uVar3, 0x1804b86f4, 5);
                                if (iVar4 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7977;
                                    iVar4 = fcn.180498f90(uVar3, 0x1804a7cd0, 5);
                                    if (iVar4 != 0) {
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7994;
                                        iVar4 = fcn.180498f90(uVar3, 0x1804b86fc, 4);
                                        if (iVar4 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f79b1;
                                            iVar4 = fcn.180498f90(uVar3, 0x1804b8704, 5);
                                            if (iVar4 == 0) {
                                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f79ba;
                                                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                                              *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
                                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f79d2;
                                                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                                              *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                                              *(int64_t *)((int64_t)&arg_28h + iVar5), 
                                                              *(int64_t *)(&stack0x00000030 + iVar5), 
                                                              *(int64_t *)(&stack0x00000048 + iVar5));
                                            } else {
                                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f79fa;
                                                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                                              *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
                                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7a12;
                                                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                                              *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                                              *(int64_t *)((int64_t)&arg_28h + iVar5), 
                                                              *(int64_t *)(&stack0x00000030 + iVar5), 
                                                              *(int64_t *)(&stack0x00000048 + iVar5));
                                            }
                                            goto code_r0x0001801f79e0;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7a27;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7a3f;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
code_r0x0001801f79e0:
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f79e8;
            fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar5));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7a54;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
    } else {
        if ((uVar2 == 0x304) || (uVar1 == uVar2)) goto code_r0x0001801f7ae3;
        if (((uVar1 ^ uVar2) & 0xff00) == 0) {
            if (in_RDX[1] == 0x15) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7aae;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7ac6;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                              *(int64_t *)(&stack0x00000048 + iVar5));
                goto code_r0x0001801f7a71;
            }
            *(uint32_t *)(in_RCX + 0x14) = uVar1 & 0xffff;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7ad9;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7a6c;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                  *(int64_t *)(&stack0x00000048 + iVar5));
code_r0x0001801f7a71:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7a82;
    fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_1801f78a8
// Address: 0x1801f78a8
// Size: 333 bytes
// ============================================================
undefined8 fcn.1801f77d0(int64_t arg_28h, int64_t arg_58h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    uint32_t *in_RDX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f77dc;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar1 = *in_RDX;
    uVar2 = *(uint32_t *)(in_RCX + 0x14);
    if (uVar1 == 2) {
        if (uVar2 != 0x10000) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f77ff;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7817;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f782d;
            fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar5));
            return 0;
        }
        if (*(uint64_t *)(in_RDX + 2) < 9) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7845;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f785d;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7873;
            fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar5));
            return 0;
        }
code_r0x0001801f7ae3:
        if (0x4000 < *(uint64_t *)(in_RDX + 2)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7af2;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7b0a;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7b20;
            fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar5));
            return 0;
        }
        return 1;
    }
    if (uVar2 == 0x10000) {
        if ((uVar1 & 0xffffff00) == 0x300) goto code_r0x0001801f7ae3;
        if (*(int32_t *)(in_RCX + 0x10d4) != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RDI;
            uVar3 = *(undefined8 *)(in_RCX + 0xff0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f78c9;
            iVar4 = fcn.180498f90(uVar3, 0x1804b86d4, 4);
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f78e6;
                iVar4 = fcn.180498f90(uVar3, 0x1804b86dc, 5);
                if (iVar4 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7903;
                    iVar4 = fcn.180498f90(uVar3, 0x1804b86e4, 5);
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7920;
                        iVar4 = fcn.180498f90(uVar3, 0x1804a57e8, 5);
                        if (iVar4 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f793d;
                            iVar4 = fcn.180498f90(uVar3, 0x1804b86ec, 5);
                            if (iVar4 != 0) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f795a;
                                iVar4 = fcn.180498f90(uVar3, 0x1804b86f4, 5);
                                if (iVar4 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7977;
                                    iVar4 = fcn.180498f90(uVar3, 0x1804a7cd0, 5);
                                    if (iVar4 != 0) {
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7994;
                                        iVar4 = fcn.180498f90(uVar3, 0x1804b86fc, 4);
                                        if (iVar4 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f79b1;
                                            iVar4 = fcn.180498f90(uVar3, 0x1804b8704, 5);
                                            if (iVar4 == 0) {
                                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f79ba;
                                                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                                              *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
                                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f79d2;
                                                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                                              *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                                              *(int64_t *)((int64_t)&arg_28h + iVar5), 
                                                              *(int64_t *)(&stack0x00000030 + iVar5), 
                                                              *(int64_t *)(&stack0x00000048 + iVar5));
                                            } else {
                                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f79fa;
                                                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                                              *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
                                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7a12;
                                                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                                              *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                                              *(int64_t *)((int64_t)&arg_28h + iVar5), 
                                                              *(int64_t *)(&stack0x00000030 + iVar5), 
                                                              *(int64_t *)(&stack0x00000048 + iVar5));
                                            }
                                            goto code_r0x0001801f79e0;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7a27;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7a3f;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
code_r0x0001801f79e0:
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f79e8;
            fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar5));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7a54;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
    } else {
        if ((uVar2 == 0x304) || (uVar1 == uVar2)) goto code_r0x0001801f7ae3;
        if (((uVar1 ^ uVar2) & 0xff00) == 0) {
            if (in_RDX[1] == 0x15) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7aae;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7ac6;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                              *(int64_t *)(&stack0x00000048 + iVar5));
                goto code_r0x0001801f7a71;
            }
            *(uint32_t *)(in_RCX + 0x14) = uVar1 & 0xffff;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7ad9;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7a6c;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                  *(int64_t *)(&stack0x00000048 + iVar5));
code_r0x0001801f7a71:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7a82;
    fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_1801f79f5
// Address: 0x1801f79f5
// Size: 90 bytes
// ============================================================
undefined8 fcn.1801f77d0(int64_t arg_28h, int64_t arg_58h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    uint32_t *in_RDX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f77dc;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar1 = *in_RDX;
    uVar2 = *(uint32_t *)(in_RCX + 0x14);
    if (uVar1 == 2) {
        if (uVar2 != 0x10000) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f77ff;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7817;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f782d;
            fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar5));
            return 0;
        }
        if (*(uint64_t *)(in_RDX + 2) < 9) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7845;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f785d;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7873;
            fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar5));
            return 0;
        }
code_r0x0001801f7ae3:
        if (0x4000 < *(uint64_t *)(in_RDX + 2)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7af2;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7b0a;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7b20;
            fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar5));
            return 0;
        }
        return 1;
    }
    if (uVar2 == 0x10000) {
        if ((uVar1 & 0xffffff00) == 0x300) goto code_r0x0001801f7ae3;
        if (*(int32_t *)(in_RCX + 0x10d4) != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RDI;
            uVar3 = *(undefined8 *)(in_RCX + 0xff0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f78c9;
            iVar4 = fcn.180498f90(uVar3, 0x1804b86d4, 4);
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f78e6;
                iVar4 = fcn.180498f90(uVar3, 0x1804b86dc, 5);
                if (iVar4 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7903;
                    iVar4 = fcn.180498f90(uVar3, 0x1804b86e4, 5);
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7920;
                        iVar4 = fcn.180498f90(uVar3, 0x1804a57e8, 5);
                        if (iVar4 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f793d;
                            iVar4 = fcn.180498f90(uVar3, 0x1804b86ec, 5);
                            if (iVar4 != 0) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f795a;
                                iVar4 = fcn.180498f90(uVar3, 0x1804b86f4, 5);
                                if (iVar4 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7977;
                                    iVar4 = fcn.180498f90(uVar3, 0x1804a7cd0, 5);
                                    if (iVar4 != 0) {
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7994;
                                        iVar4 = fcn.180498f90(uVar3, 0x1804b86fc, 4);
                                        if (iVar4 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f79b1;
                                            iVar4 = fcn.180498f90(uVar3, 0x1804b8704, 5);
                                            if (iVar4 == 0) {
                                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f79ba;
                                                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                                              *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
                                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f79d2;
                                                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                                              *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                                              *(int64_t *)((int64_t)&arg_28h + iVar5), 
                                                              *(int64_t *)(&stack0x00000030 + iVar5), 
                                                              *(int64_t *)(&stack0x00000048 + iVar5));
                                            } else {
                                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f79fa;
                                                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                                              *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
                                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7a12;
                                                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                                              *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                                              *(int64_t *)((int64_t)&arg_28h + iVar5), 
                                                              *(int64_t *)(&stack0x00000030 + iVar5), 
                                                              *(int64_t *)(&stack0x00000048 + iVar5));
                                            }
                                            goto code_r0x0001801f79e0;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7a27;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7a3f;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
code_r0x0001801f79e0:
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f79e8;
            fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar5));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7a54;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
    } else {
        if ((uVar2 == 0x304) || (uVar1 == uVar2)) goto code_r0x0001801f7ae3;
        if (((uVar1 ^ uVar2) & 0xff00) == 0) {
            if (in_RDX[1] == 0x15) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7aae;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7ac6;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                              *(int64_t *)(&stack0x00000048 + iVar5));
                goto code_r0x0001801f7a71;
            }
            *(uint32_t *)(in_RCX + 0x14) = uVar1 & 0xffff;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7ad9;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7a6c;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                  *(int64_t *)(&stack0x00000048 + iVar5));
code_r0x0001801f7a71:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7a82;
    fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_1801f7a4f
// Address: 0x1801f7a4f
// Size: 228 bytes
// ============================================================
undefined8 fcn.1801f77d0(int64_t arg_28h, int64_t arg_58h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    uint32_t *in_RDX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f77dc;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar1 = *in_RDX;
    uVar2 = *(uint32_t *)(in_RCX + 0x14);
    if (uVar1 == 2) {
        if (uVar2 != 0x10000) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f77ff;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7817;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f782d;
            fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar5));
            return 0;
        }
        if (*(uint64_t *)(in_RDX + 2) < 9) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7845;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f785d;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7873;
            fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar5));
            return 0;
        }
code_r0x0001801f7ae3:
        if (0x4000 < *(uint64_t *)(in_RDX + 2)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7af2;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7b0a;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7b20;
            fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar5));
            return 0;
        }
        return 1;
    }
    if (uVar2 == 0x10000) {
        if ((uVar1 & 0xffffff00) == 0x300) goto code_r0x0001801f7ae3;
        if (*(int32_t *)(in_RCX + 0x10d4) != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RDI;
            uVar3 = *(undefined8 *)(in_RCX + 0xff0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f78c9;
            iVar4 = fcn.180498f90(uVar3, 0x1804b86d4, 4);
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f78e6;
                iVar4 = fcn.180498f90(uVar3, 0x1804b86dc, 5);
                if (iVar4 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7903;
                    iVar4 = fcn.180498f90(uVar3, 0x1804b86e4, 5);
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7920;
                        iVar4 = fcn.180498f90(uVar3, 0x1804a57e8, 5);
                        if (iVar4 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f793d;
                            iVar4 = fcn.180498f90(uVar3, 0x1804b86ec, 5);
                            if (iVar4 != 0) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f795a;
                                iVar4 = fcn.180498f90(uVar3, 0x1804b86f4, 5);
                                if (iVar4 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7977;
                                    iVar4 = fcn.180498f90(uVar3, 0x1804a7cd0, 5);
                                    if (iVar4 != 0) {
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7994;
                                        iVar4 = fcn.180498f90(uVar3, 0x1804b86fc, 4);
                                        if (iVar4 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f79b1;
                                            iVar4 = fcn.180498f90(uVar3, 0x1804b8704, 5);
                                            if (iVar4 == 0) {
                                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f79ba;
                                                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                                              *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
                                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f79d2;
                                                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                                              *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                                              *(int64_t *)((int64_t)&arg_28h + iVar5), 
                                                              *(int64_t *)(&stack0x00000030 + iVar5), 
                                                              *(int64_t *)(&stack0x00000048 + iVar5));
                                            } else {
                                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f79fa;
                                                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                                              *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
                                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7a12;
                                                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                                              *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                                              *(int64_t *)((int64_t)&arg_28h + iVar5), 
                                                              *(int64_t *)(&stack0x00000030 + iVar5), 
                                                              *(int64_t *)(&stack0x00000048 + iVar5));
                                            }
                                            goto code_r0x0001801f79e0;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7a27;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7a3f;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
code_r0x0001801f79e0:
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f79e8;
            fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar5));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7a54;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
    } else {
        if ((uVar2 == 0x304) || (uVar1 == uVar2)) goto code_r0x0001801f7ae3;
        if (((uVar1 ^ uVar2) & 0xff00) == 0) {
            if (in_RDX[1] == 0x15) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7aae;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7ac6;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                              *(int64_t *)(&stack0x00000048 + iVar5));
                goto code_r0x0001801f7a71;
            }
            *(uint32_t *)(in_RCX + 0x14) = uVar1 & 0xffff;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7ad9;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7a6c;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                  *(int64_t *)(&stack0x00000048 + iVar5));
code_r0x0001801f7a71:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f7a82;
    fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_1801f7b80
// Address: 0x1801f7b80
// Size: 304 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.1801f7b80(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t in_RCX;
    uint64_t in_RDX;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f7b9a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined4 *)((int64_t)&var_20h + iVar3) = 0x80;
    *(undefined4 *)((int64_t)&var_18h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f7bbd;
    iVar1 = (*(code *)0x69aa42)();
    if (iVar1 == -1) {
        *(undefined4 *)((int64_t)&var_20h + iVar3) = 0;
        *(undefined4 *)((int64_t)&var_18h + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f7be5;
        iVar1 = (*(code *)0x69aa42)(in_RCX & 0xffffffff, in_RDX & 0xffffffff, in_R8 & 0xffffffff, 0);
        if (iVar1 == -1) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f7bf2;
            (*(code *)0x800000000000006f)();
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f7bf9;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f7c11;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f7c27;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            return -1;
        }
    }
    *(undefined4 *)((int64_t)&var_18h + iVar3) = 4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f7c51;
    iVar2 = (*(code *)0x8000000000000015)((int64_t)iVar1, 0xffff, 0xfffffffb, 0x1804b870c);
    if (iVar2 < 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f7c5a;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f7c72;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f7c78;
        (*(code *)0x800000000000006f)();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f7c8b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f7c92;
        func_0x000180274b10(iVar1);
        iVar1 = -1;
    }
    return iVar1;
}

// ============================================================
// Function: FUN_1801f7cb0
// Address: 0x1801f7cb0
// Size: 141 bytes
// ============================================================
void fcn.1801f7cb0(int64_t arg_1c0h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801f7cba;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(uint64_t *)((int64_t)&arg_1c0h + iVar2) = *(uint64_t *)0x1806a3940 ^ (int64_t)&stack0x00000000 + iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801f7cdf;
    iVar1 = (*(code *)0x8000000000000073)(0x202, (int64_t)&var_20h + iVar2);
    if (iVar1 != 0) {
        *(undefined4 *)0x18077e294 = 0;
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801f7cfd;
        fcn.180459870(*(uint64_t *)((int64_t)&arg_1c0h + iVar2) ^ (int64_t)&stack0x00000000 + iVar2);
        return;
    }
    *(undefined4 *)0x18077e290 = 1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801f7d1b;
    fcn.180243500(0x1801f82b0);
    *(undefined4 *)0x18077e294 = 1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801f7d35;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_1c0h + iVar2) ^ (int64_t)&stack0x00000000 + iVar2);
    return;
}

// ============================================================
// Function: FUN_1801f7d40
// Address: 0x1801f7d40
// Size: 51 bytes
// ============================================================
void fcn.1801f7d40(undefined8 *param_1)
{
    undefined4 uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f7d4c;
    iVar2 = fcn.18045a350();
    if (-1 < *(int32_t *)param_1) {
        uVar1 = *(undefined4 *)((int64_t)param_1 + 4);
        *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801f7d5f;
        fcn.180274b10(uVar1);
        uVar1 = *(undefined4 *)param_1;
        *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801f7d66;
        fcn.180274b10(uVar1);
        *param_1 = 0xffffffffffffffff;
    }
    return;
}

// ============================================================
// Function: FUN_1801f7d80
// Address: 0x1801f7d80
// Size: 159 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Removing arg arg_aah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ah

void fcn.1801f7d80(int64_t arg_28h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_80h, int64_t arg_88h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar7;
    undefined8 unaff_R12;
    int64_t iVar8;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f7d8f;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_38h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar6);
    *(undefined4 *)((int64_t)&iStackX_10 + iVar6 + -8) = 0x10;
    *(undefined4 *)((int64_t)&iStackX_10 + iVar6 + -4) = 0x10;
    iVar5 = -1;
    uVar7 = 0xffffffff;
    *(undefined (*) [16])((int64_t)&iStackX_20 + iVar6 + -8) = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7dd6;
    iVar1 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8));
    iVar2 = 0;
    if (iVar1 != 0) {
        iVar2 = *(int32_t *)0x18077e294;
    }
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7dea;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e02;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e18;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
        goto code_r0x0001801f81b0;
    }
    *(undefined8 *)((int64_t)&arg_80h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_50h + iVar6) = unaff_R12;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e43;
    iVar2 = fcn.1801f7b80(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_28h + iVar6));
    iVar8 = (int64_t)iVar2;
    if (iVar2 == -1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e50;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e68;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e6e;
        (*(code *)0x699ff6)();
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e7e;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
        goto code_r0x0001801f81b0;
    }
    *(undefined8 *)((int64_t)&arg_88h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_R15;
    *(undefined2 *)((int64_t)&iStackX_20 + iVar6 + -8) = 2;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7ea2;
    uVar3 = (*(code *)0x8000000000000008)(0x7f000001);
    *(undefined4 *)((int64_t)&iStackX_20 + iVar6 + -4) = uVar3;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7eba;
    iVar1 = (*(code *)0x8000000000000002)(iVar8, (int64_t)&iStackX_20 + iVar6 + -8, 0x10);
    if (iVar1 < 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7ec3;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7edb;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7ee1;
        (*(code *)0x699ff6)();
        uVar7 = 0xffffffff;
code_r0x0001801f80aa:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80b3;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80bb;
        fcn.180274b10(iVar2);
        if ((int32_t)uVar7 != -1) goto code_r0x0001801f8181;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f00;
        iVar1 = (*(code *)0x8000000000000006)
                          (iVar8, (int64_t)&iStackX_20 + iVar6 + -8, (int64_t)&iStackX_10 + iVar6 + -8);
        if (iVar1 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f09;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            uVar7 = 0xffffffff;
            iVar5 = -1;
code_r0x0001801f808a:
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f809d;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80a3;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f21;
        iVar1 = (*(code *)0x800000000000000d)(iVar8, 1);
        if (iVar1 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f2a;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f42;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f48;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f66;
        iVar1 = fcn.1801f7b80(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6));
        uVar7 = (uint64_t)iVar1;
        if (iVar1 == -1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f72;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f8a;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f90;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7fa8;
        iVar4 = func_0x0001800066d0(iVar1, 1);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7fb1;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7fc9;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7fcf;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7fef;
        iVar4 = (*(code *)0x8000000000000004)(uVar7, (int64_t)&iStackX_20 + iVar6 + -8, 0x10);
        if (iVar4 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7ff8;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8010;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8016;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8035;
        iVar5 = (*(code *)0x8000000000000001)(iVar8, (int64_t)&arg_28h + iVar6, (int64_t)&iStackX_10 + iVar6 + -4);
        if (iVar5 == -1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8042;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f805a;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8060;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f807c;
        iVar4 = (*(code *)0x8000000000000006)
                          (uVar7, (int64_t)&iStackX_20 + iVar6 + -8, (int64_t)&iStackX_10 + iVar6 + -8);
        if (iVar4 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8085;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            goto code_r0x0001801f808a;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80d1;
        fcn.180274b10(iVar2);
        if ((*(int16_t *)((int64_t)&arg_28h + iVar6) == 2) &&
           (*(int16_t *)((int64_t)&arg_28h + iVar6 + 2) == *(int16_t *)((int64_t)&iStackX_20 + iVar6 + -6))) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80f0;
            iVar2 = func_0x0001802749c0(iVar5, 1);
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80f9;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8130;
                iVar2 = func_0x0001802749c0(iVar1, 1);
                if (iVar2 != 0) {
                    *in_RCX = iVar5;
                    in_RCX[1] = iVar1;
                    goto code_r0x0001801f81b0;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8139;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8111;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8117;
            (*(code *)0x699ff6)();
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8153;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f816b;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8181;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
code_r0x0001801f8181:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8188;
        fcn.180274b10(uVar7 & 0xffffffff);
    }
    if (iVar5 != -1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8194;
        fcn.180274b10(iVar5);
    }
code_r0x0001801f81b0:
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f81bd;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_38h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1801f7e1f
// Address: 0x1801f7e1f
// Size: 102 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Removing arg arg_aah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ah

void fcn.1801f7d80(int64_t arg_28h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_80h, int64_t arg_88h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar7;
    undefined8 unaff_R12;
    int64_t iVar8;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f7d8f;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_38h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar6);
    *(undefined4 *)((int64_t)&iStackX_10 + iVar6 + -8) = 0x10;
    *(undefined4 *)((int64_t)&iStackX_10 + iVar6 + -4) = 0x10;
    iVar5 = -1;
    uVar7 = 0xffffffff;
    *(undefined (*) [16])((int64_t)&iStackX_20 + iVar6 + -8) = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7dd6;
    iVar1 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8));
    iVar2 = 0;
    if (iVar1 != 0) {
        iVar2 = *(int32_t *)0x18077e294;
    }
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7dea;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e02;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e18;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
        goto code_r0x0001801f81b0;
    }
    *(undefined8 *)((int64_t)&arg_80h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_50h + iVar6) = unaff_R12;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e43;
    iVar2 = fcn.1801f7b80(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_28h + iVar6));
    iVar8 = (int64_t)iVar2;
    if (iVar2 == -1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e50;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e68;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e6e;
        (*(code *)0x699ff6)();
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e7e;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
        goto code_r0x0001801f81b0;
    }
    *(undefined8 *)((int64_t)&arg_88h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_R15;
    *(undefined2 *)((int64_t)&iStackX_20 + iVar6 + -8) = 2;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7ea2;
    uVar3 = (*(code *)0x8000000000000008)(0x7f000001);
    *(undefined4 *)((int64_t)&iStackX_20 + iVar6 + -4) = uVar3;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7eba;
    iVar1 = (*(code *)0x8000000000000002)(iVar8, (int64_t)&iStackX_20 + iVar6 + -8, 0x10);
    if (iVar1 < 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7ec3;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7edb;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7ee1;
        (*(code *)0x699ff6)();
        uVar7 = 0xffffffff;
code_r0x0001801f80aa:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80b3;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80bb;
        fcn.180274b10(iVar2);
        if ((int32_t)uVar7 != -1) goto code_r0x0001801f8181;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f00;
        iVar1 = (*(code *)0x8000000000000006)
                          (iVar8, (int64_t)&iStackX_20 + iVar6 + -8, (int64_t)&iStackX_10 + iVar6 + -8);
        if (iVar1 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f09;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            uVar7 = 0xffffffff;
            iVar5 = -1;
code_r0x0001801f808a:
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f809d;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80a3;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f21;
        iVar1 = (*(code *)0x800000000000000d)(iVar8, 1);
        if (iVar1 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f2a;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f42;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f48;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f66;
        iVar1 = fcn.1801f7b80(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6));
        uVar7 = (uint64_t)iVar1;
        if (iVar1 == -1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f72;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f8a;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f90;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7fa8;
        iVar4 = func_0x0001800066d0(iVar1, 1);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7fb1;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7fc9;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7fcf;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7fef;
        iVar4 = (*(code *)0x8000000000000004)(uVar7, (int64_t)&iStackX_20 + iVar6 + -8, 0x10);
        if (iVar4 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7ff8;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8010;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8016;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8035;
        iVar5 = (*(code *)0x8000000000000001)(iVar8, (int64_t)&arg_28h + iVar6, (int64_t)&iStackX_10 + iVar6 + -4);
        if (iVar5 == -1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8042;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f805a;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8060;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f807c;
        iVar4 = (*(code *)0x8000000000000006)
                          (uVar7, (int64_t)&iStackX_20 + iVar6 + -8, (int64_t)&iStackX_10 + iVar6 + -8);
        if (iVar4 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8085;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            goto code_r0x0001801f808a;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80d1;
        fcn.180274b10(iVar2);
        if ((*(int16_t *)((int64_t)&arg_28h + iVar6) == 2) &&
           (*(int16_t *)((int64_t)&arg_28h + iVar6 + 2) == *(int16_t *)((int64_t)&iStackX_20 + iVar6 + -6))) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80f0;
            iVar2 = func_0x0001802749c0(iVar5, 1);
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80f9;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8130;
                iVar2 = func_0x0001802749c0(iVar1, 1);
                if (iVar2 != 0) {
                    *in_RCX = iVar5;
                    in_RCX[1] = iVar1;
                    goto code_r0x0001801f81b0;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8139;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8111;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8117;
            (*(code *)0x699ff6)();
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8153;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f816b;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8181;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
code_r0x0001801f8181:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8188;
        fcn.180274b10(uVar7 & 0xffffffff);
    }
    if (iVar5 != -1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8194;
        fcn.180274b10(iVar5);
    }
code_r0x0001801f81b0:
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f81bd;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_38h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1801f7e85
// Address: 0x1801f7e85
// Size: 798 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Removing arg arg_aah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ah

void fcn.1801f7d80(int64_t arg_28h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_80h, int64_t arg_88h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar7;
    undefined8 unaff_R12;
    int64_t iVar8;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f7d8f;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_38h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar6);
    *(undefined4 *)((int64_t)&iStackX_10 + iVar6 + -8) = 0x10;
    *(undefined4 *)((int64_t)&iStackX_10 + iVar6 + -4) = 0x10;
    iVar5 = -1;
    uVar7 = 0xffffffff;
    *(undefined (*) [16])((int64_t)&iStackX_20 + iVar6 + -8) = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7dd6;
    iVar1 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8));
    iVar2 = 0;
    if (iVar1 != 0) {
        iVar2 = *(int32_t *)0x18077e294;
    }
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7dea;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e02;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e18;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
        goto code_r0x0001801f81b0;
    }
    *(undefined8 *)((int64_t)&arg_80h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_50h + iVar6) = unaff_R12;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e43;
    iVar2 = fcn.1801f7b80(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_28h + iVar6));
    iVar8 = (int64_t)iVar2;
    if (iVar2 == -1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e50;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e68;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e6e;
        (*(code *)0x699ff6)();
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e7e;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
        goto code_r0x0001801f81b0;
    }
    *(undefined8 *)((int64_t)&arg_88h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_R15;
    *(undefined2 *)((int64_t)&iStackX_20 + iVar6 + -8) = 2;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7ea2;
    uVar3 = (*(code *)0x8000000000000008)(0x7f000001);
    *(undefined4 *)((int64_t)&iStackX_20 + iVar6 + -4) = uVar3;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7eba;
    iVar1 = (*(code *)0x8000000000000002)(iVar8, (int64_t)&iStackX_20 + iVar6 + -8, 0x10);
    if (iVar1 < 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7ec3;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7edb;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7ee1;
        (*(code *)0x699ff6)();
        uVar7 = 0xffffffff;
code_r0x0001801f80aa:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80b3;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80bb;
        fcn.180274b10(iVar2);
        if ((int32_t)uVar7 != -1) goto code_r0x0001801f8181;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f00;
        iVar1 = (*(code *)0x8000000000000006)
                          (iVar8, (int64_t)&iStackX_20 + iVar6 + -8, (int64_t)&iStackX_10 + iVar6 + -8);
        if (iVar1 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f09;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            uVar7 = 0xffffffff;
            iVar5 = -1;
code_r0x0001801f808a:
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f809d;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80a3;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f21;
        iVar1 = (*(code *)0x800000000000000d)(iVar8, 1);
        if (iVar1 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f2a;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f42;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f48;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f66;
        iVar1 = fcn.1801f7b80(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6));
        uVar7 = (uint64_t)iVar1;
        if (iVar1 == -1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f72;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f8a;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f90;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7fa8;
        iVar4 = func_0x0001800066d0(iVar1, 1);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7fb1;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7fc9;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7fcf;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7fef;
        iVar4 = (*(code *)0x8000000000000004)(uVar7, (int64_t)&iStackX_20 + iVar6 + -8, 0x10);
        if (iVar4 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7ff8;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8010;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8016;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8035;
        iVar5 = (*(code *)0x8000000000000001)(iVar8, (int64_t)&arg_28h + iVar6, (int64_t)&iStackX_10 + iVar6 + -4);
        if (iVar5 == -1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8042;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f805a;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8060;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f807c;
        iVar4 = (*(code *)0x8000000000000006)
                          (uVar7, (int64_t)&iStackX_20 + iVar6 + -8, (int64_t)&iStackX_10 + iVar6 + -8);
        if (iVar4 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8085;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            goto code_r0x0001801f808a;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80d1;
        fcn.180274b10(iVar2);
        if ((*(int16_t *)((int64_t)&arg_28h + iVar6) == 2) &&
           (*(int16_t *)((int64_t)&arg_28h + iVar6 + 2) == *(int16_t *)((int64_t)&iStackX_20 + iVar6 + -6))) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80f0;
            iVar2 = func_0x0001802749c0(iVar5, 1);
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80f9;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8130;
                iVar2 = func_0x0001802749c0(iVar1, 1);
                if (iVar2 != 0) {
                    *in_RCX = iVar5;
                    in_RCX[1] = iVar1;
                    goto code_r0x0001801f81b0;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8139;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8111;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8117;
            (*(code *)0x699ff6)();
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8153;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f816b;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8181;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
code_r0x0001801f8181:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8188;
        fcn.180274b10(uVar7 & 0xffffffff);
    }
    if (iVar5 != -1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8194;
        fcn.180274b10(iVar5);
    }
code_r0x0001801f81b0:
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f81bd;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_38h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1801f81a3
// Address: 0x1801f81a3
// Size: 13 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Removing arg arg_aah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ah

void fcn.1801f7d80(int64_t arg_28h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_80h, int64_t arg_88h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar7;
    undefined8 unaff_R12;
    int64_t iVar8;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f7d8f;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_38h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar6);
    *(undefined4 *)((int64_t)&iStackX_10 + iVar6 + -8) = 0x10;
    *(undefined4 *)((int64_t)&iStackX_10 + iVar6 + -4) = 0x10;
    iVar5 = -1;
    uVar7 = 0xffffffff;
    *(undefined (*) [16])((int64_t)&iStackX_20 + iVar6 + -8) = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7dd6;
    iVar1 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8));
    iVar2 = 0;
    if (iVar1 != 0) {
        iVar2 = *(int32_t *)0x18077e294;
    }
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7dea;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e02;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e18;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
        goto code_r0x0001801f81b0;
    }
    *(undefined8 *)((int64_t)&arg_80h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_50h + iVar6) = unaff_R12;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e43;
    iVar2 = fcn.1801f7b80(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_28h + iVar6));
    iVar8 = (int64_t)iVar2;
    if (iVar2 == -1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e50;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e68;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e6e;
        (*(code *)0x699ff6)();
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e7e;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
        goto code_r0x0001801f81b0;
    }
    *(undefined8 *)((int64_t)&arg_88h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_R15;
    *(undefined2 *)((int64_t)&iStackX_20 + iVar6 + -8) = 2;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7ea2;
    uVar3 = (*(code *)0x8000000000000008)(0x7f000001);
    *(undefined4 *)((int64_t)&iStackX_20 + iVar6 + -4) = uVar3;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7eba;
    iVar1 = (*(code *)0x8000000000000002)(iVar8, (int64_t)&iStackX_20 + iVar6 + -8, 0x10);
    if (iVar1 < 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7ec3;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7edb;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7ee1;
        (*(code *)0x699ff6)();
        uVar7 = 0xffffffff;
code_r0x0001801f80aa:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80b3;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80bb;
        fcn.180274b10(iVar2);
        if ((int32_t)uVar7 != -1) goto code_r0x0001801f8181;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f00;
        iVar1 = (*(code *)0x8000000000000006)
                          (iVar8, (int64_t)&iStackX_20 + iVar6 + -8, (int64_t)&iStackX_10 + iVar6 + -8);
        if (iVar1 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f09;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            uVar7 = 0xffffffff;
            iVar5 = -1;
code_r0x0001801f808a:
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f809d;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80a3;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f21;
        iVar1 = (*(code *)0x800000000000000d)(iVar8, 1);
        if (iVar1 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f2a;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f42;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f48;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f66;
        iVar1 = fcn.1801f7b80(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6));
        uVar7 = (uint64_t)iVar1;
        if (iVar1 == -1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f72;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f8a;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f90;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7fa8;
        iVar4 = func_0x0001800066d0(iVar1, 1);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7fb1;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7fc9;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7fcf;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7fef;
        iVar4 = (*(code *)0x8000000000000004)(uVar7, (int64_t)&iStackX_20 + iVar6 + -8, 0x10);
        if (iVar4 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7ff8;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8010;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8016;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8035;
        iVar5 = (*(code *)0x8000000000000001)(iVar8, (int64_t)&arg_28h + iVar6, (int64_t)&iStackX_10 + iVar6 + -4);
        if (iVar5 == -1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8042;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f805a;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8060;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f807c;
        iVar4 = (*(code *)0x8000000000000006)
                          (uVar7, (int64_t)&iStackX_20 + iVar6 + -8, (int64_t)&iStackX_10 + iVar6 + -8);
        if (iVar4 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8085;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            goto code_r0x0001801f808a;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80d1;
        fcn.180274b10(iVar2);
        if ((*(int16_t *)((int64_t)&arg_28h + iVar6) == 2) &&
           (*(int16_t *)((int64_t)&arg_28h + iVar6 + 2) == *(int16_t *)((int64_t)&iStackX_20 + iVar6 + -6))) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80f0;
            iVar2 = func_0x0001802749c0(iVar5, 1);
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80f9;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8130;
                iVar2 = func_0x0001802749c0(iVar1, 1);
                if (iVar2 != 0) {
                    *in_RCX = iVar5;
                    in_RCX[1] = iVar1;
                    goto code_r0x0001801f81b0;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8139;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8111;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8117;
            (*(code *)0x699ff6)();
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8153;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f816b;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8181;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
code_r0x0001801f8181:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8188;
        fcn.180274b10(uVar7 & 0xffffffff);
    }
    if (iVar5 != -1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8194;
        fcn.180274b10(iVar5);
    }
code_r0x0001801f81b0:
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f81bd;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_38h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1801f81b0
// Address: 0x1801f81b0
// Size: 22 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Removing arg arg_aah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ah

void fcn.1801f7d80(int64_t arg_28h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_80h, int64_t arg_88h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar7;
    undefined8 unaff_R12;
    int64_t iVar8;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f7d8f;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_38h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar6);
    *(undefined4 *)((int64_t)&iStackX_10 + iVar6 + -8) = 0x10;
    *(undefined4 *)((int64_t)&iStackX_10 + iVar6 + -4) = 0x10;
    iVar5 = -1;
    uVar7 = 0xffffffff;
    *(undefined (*) [16])((int64_t)&iStackX_20 + iVar6 + -8) = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7dd6;
    iVar1 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8));
    iVar2 = 0;
    if (iVar1 != 0) {
        iVar2 = *(int32_t *)0x18077e294;
    }
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7dea;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e02;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e18;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
        goto code_r0x0001801f81b0;
    }
    *(undefined8 *)((int64_t)&arg_80h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_50h + iVar6) = unaff_R12;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e43;
    iVar2 = fcn.1801f7b80(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_28h + iVar6));
    iVar8 = (int64_t)iVar2;
    if (iVar2 == -1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e50;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e68;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e6e;
        (*(code *)0x699ff6)();
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7e7e;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
        goto code_r0x0001801f81b0;
    }
    *(undefined8 *)((int64_t)&arg_88h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_R15;
    *(undefined2 *)((int64_t)&iStackX_20 + iVar6 + -8) = 2;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7ea2;
    uVar3 = (*(code *)0x8000000000000008)(0x7f000001);
    *(undefined4 *)((int64_t)&iStackX_20 + iVar6 + -4) = uVar3;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7eba;
    iVar1 = (*(code *)0x8000000000000002)(iVar8, (int64_t)&iStackX_20 + iVar6 + -8, 0x10);
    if (iVar1 < 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7ec3;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7edb;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7ee1;
        (*(code *)0x699ff6)();
        uVar7 = 0xffffffff;
code_r0x0001801f80aa:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80b3;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80bb;
        fcn.180274b10(iVar2);
        if ((int32_t)uVar7 != -1) goto code_r0x0001801f8181;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f00;
        iVar1 = (*(code *)0x8000000000000006)
                          (iVar8, (int64_t)&iStackX_20 + iVar6 + -8, (int64_t)&iStackX_10 + iVar6 + -8);
        if (iVar1 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f09;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            uVar7 = 0xffffffff;
            iVar5 = -1;
code_r0x0001801f808a:
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f809d;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80a3;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f21;
        iVar1 = (*(code *)0x800000000000000d)(iVar8, 1);
        if (iVar1 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f2a;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f42;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f48;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f66;
        iVar1 = fcn.1801f7b80(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6));
        uVar7 = (uint64_t)iVar1;
        if (iVar1 == -1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f72;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f8a;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7f90;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7fa8;
        iVar4 = func_0x0001800066d0(iVar1, 1);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7fb1;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7fc9;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7fcf;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7fef;
        iVar4 = (*(code *)0x8000000000000004)(uVar7, (int64_t)&iStackX_20 + iVar6 + -8, 0x10);
        if (iVar4 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f7ff8;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8010;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8016;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8035;
        iVar5 = (*(code *)0x8000000000000001)(iVar8, (int64_t)&arg_28h + iVar6, (int64_t)&iStackX_10 + iVar6 + -4);
        if (iVar5 == -1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8042;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f805a;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8060;
            (*(code *)0x699ff6)();
            goto code_r0x0001801f80aa;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f807c;
        iVar4 = (*(code *)0x8000000000000006)
                          (uVar7, (int64_t)&iStackX_20 + iVar6 + -8, (int64_t)&iStackX_10 + iVar6 + -8);
        if (iVar4 < 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8085;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            goto code_r0x0001801f808a;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80d1;
        fcn.180274b10(iVar2);
        if ((*(int16_t *)((int64_t)&arg_28h + iVar6) == 2) &&
           (*(int16_t *)((int64_t)&arg_28h + iVar6 + 2) == *(int16_t *)((int64_t)&iStackX_20 + iVar6 + -6))) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80f0;
            iVar2 = func_0x0001802749c0(iVar5, 1);
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f80f9;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8130;
                iVar2 = func_0x0001802749c0(iVar1, 1);
                if (iVar2 != 0) {
                    *in_RCX = iVar5;
                    in_RCX[1] = iVar1;
                    goto code_r0x0001801f81b0;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8139;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8111;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8117;
            (*(code *)0x699ff6)();
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8153;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f816b;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8181;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
code_r0x0001801f8181:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8188;
        fcn.180274b10(uVar7 & 0xffffffff);
    }
    if (iVar5 != -1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f8194;
        fcn.180274b10(iVar5);
    }
code_r0x0001801f81b0:
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801f81bd;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_38h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1801f81d0
// Address: 0x1801f81d0
// Size: 72 bytes
// ============================================================
undefined8 fcn.1801f81d0(int64_t param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f81dc;
    iVar2 = fcn.18045a350();
    do {
        iVar1 = *(int32_t *)(param_1 + 4);
        *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801f81fc;
        iVar1 = (*(code *)0x8000000000000013)((int64_t)iVar1, 0x1804b8710, 1, 0);
        if (-1 < iVar1) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801f8206;
        iVar1 = (*(code *)0x800000000000006f)();
    } while (iVar1 == 0x2714);
    return 1;
}

// ============================================================
// Function: FUN_1801f8220
// Address: 0x1801f8220
// Size: 143 bytes
// ============================================================
void fcn.1801f8220(int64_t arg_28h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int32_t *in_RCX;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f822c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_28h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar3);
    while( true ) {
        do {
            iVar1 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f8258;
            iVar1 = (*(code *)0x8000000000000010)((int64_t)iVar1, (int64_t)&var_18h + iVar3, 0x10, 0);
        } while (iVar1 == 0x10);
        if (-1 < iVar1) break;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f8267;
        iVar1 = (*(code *)0x800000000000006f)();
        if (iVar1 != 0x2714) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f8274;
            uVar2 = (*(code *)0x800000000000006f)();
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f827b;
            fcn.1802746d0(uVar2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f8291;
            fcn.180459870(*(uint64_t *)((int64_t)&arg_28h + iVar3) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar3));
            return;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f82a9;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_28h + iVar3) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar3));
    return;
}

// ============================================================
// Function: FUN_1801f82b0
// Address: 0x1801f82b0
// Size: 48 bytes
// ============================================================
void fcn.1801f82b0(void)
{
    fcn.18045a350();
    if (*(int32_t *)0x18077e290 != 0) {
        *(undefined4 *)0x18077e290 = 0;
    // WARNING: Treating indirect jump as call
    // switch table (1 cases) at 0x1804a4988
        (*(code *)0x8000000000000074)();
        return;
    }
    return;
}

// ============================================================
// Function: FUN_1801f82e0
// Address: 0x1801f82e0
// Size: 455 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h
// WARNING: [rz-ghidra] Detected overlap for variable var_23h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

void fcn.1801f82e0(int64_t arg_30h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint64_t in_R8;
    undefined *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801f82ee;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_30h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar3);
    *(undefined4 *)((int64_t)&var_18h + iVar3) = 0;
    iVar2 = *(int32_t *)(in_RCX + 0x20);
    if ((iVar2 == 1) || (iVar2 == 2)) {
        if (in_R8 < 0x10) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801f83e5;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
            goto code_r0x0001801f833d;
        }
        *(undefined4 *)((int64_t)&var_10h + iVar3) = 1;
        *(undefined8 *)((int64_t)&var_8h + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801f840d;
        iVar2 = fcn.180211b70(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                              *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)(&stack0x00000050 + iVar3), 
                              *(int64_t *)(&stack0x00000058 + iVar3));
        if (iVar2 != 0) {
            uVar1 = *(undefined8 *)(in_RCX + 0x10);
            *(undefined4 *)((int64_t)&var_8h + iVar3) = 0x10;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801f842f;
            iVar2 = func_0x000180211bb0(uVar1, (int64_t)&var_20h + iVar3, (int64_t)&var_18h + iVar3, in_RDX);
            if (iVar2 != 0) {
                *in_R9 = *(undefined *)((int64_t)&var_20h + iVar3);
                in_R9[1] = *(undefined *)((int64_t)&var_20h + iVar3 + 1);
                in_R9[2] = *(undefined *)((int64_t)&var_20h + iVar3 + 2);
                in_R9[3] = *(undefined *)((int64_t)&var_20h + iVar3 + 3);
                in_R9[4] = *(undefined *)((int64_t)&var_20h + iVar3 + 4);
                goto code_r0x0001801f8492;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801f8466;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
code_r0x0001801f846b:
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801f847e;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                      *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000038 + iVar3));
    } else if (iVar2 == 3) {
        if (0xf < in_R8) {
            *(undefined4 *)((int64_t)&var_10h + iVar3) = 1;
            *(undefined8 *)((int64_t)&var_8h + iVar3) = in_RDX;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801f8378;
            iVar2 = fcn.180211b70(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                                  *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)(&stack0x00000050 + iVar3), 
                                  *(int64_t *)(&stack0x00000058 + iVar3));
            if (iVar2 != 0) {
                uVar1 = *(undefined8 *)(in_RCX + 0x10);
                *(undefined4 *)((int64_t)&var_8h + iVar3) = 5;
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801f839c;
                iVar2 = func_0x000180211bb0(uVar1, in_R9, (int64_t)&var_18h + iVar3, 0x1804b88a8);
                if (iVar2 != 0) goto code_r0x0001801f8492;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801f83a9;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
            goto code_r0x0001801f846b;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801f8338;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
code_r0x0001801f833d:
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801f8350;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                      *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000038 + iVar3));
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801f83b8;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801f83d0;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                      *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000038 + iVar3));
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801f8490;
    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar3));
code_r0x0001801f8492:
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801f849f;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_30h + iVar3) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar3));
    return;
}

// ============================================================
// Function: FUN_1801f84b0
// Address: 0x1801f84b0
// Size: 1157 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

void fcn.1801f84b0(int64_t arg_28h)
{
    char cVar1;
    uint8_t uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 in_RCX;
    undefined8 in_RDX;
    undefined4 *in_R8;
    uint8_t *in_R9;
    int64_t aiStackX_8 [4];
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    undefined4 uStack_120;
    undefined4 uStack_11c;
    int64_t var_118h;
    undefined4 uStack_110;
    undefined4 uStack_10c;
    int64_t var_108h;
    undefined4 uStack_100;
    undefined4 uStack_fc;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_58h;
    undefined8 uStack_48;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    
    uStack_48 = 0x1801f84cc;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar5);
    iVar7 = 0;
    cVar1 = *(char *)in_R8;
    *(undefined4 *)((int64_t)&var_10h + iVar5) = 0;
    *(undefined4 *)((int64_t)&var_10h + iVar5 + 4) = 0;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5) = 0;
    if ((((cVar1 == '\x04') && (in_R8[1] != 0)) && (0xf < *(uint64_t *)(in_R8 + 0x12))) &&
       (((*(int64_t *)(in_R8 + 0x14) != 0 && (in_R9 != (uint8_t *)0x0)) && ((arg_28h != 0 && (*in_R9 < 0x15)))))) {
        var_138h._0_4_ = *in_R8;
        var_138h._4_4_ = in_R8[1];
        var_130h._0_4_ = in_R8[2];
        var_130h._4_4_ = in_R8[3];
        var_128h._0_4_ = in_R8[4];
        var_128h._4_4_ = in_R8[5];
        uStack_120 = in_R8[6];
        uStack_11c = in_R8[7];
        var_118h._0_4_ = in_R8[8];
        var_118h._4_4_ = in_R8[9];
        uStack_110 = in_R8[10];
        uStack_10c = in_R8[0xb];
        var_108h._0_4_ = in_R8[0xc];
        var_108h._4_4_ = in_R8[0xd];
        uStack_100 = in_R8[0xe];
        uStack_fc = in_R8[0xf];
        var_f8h._0_4_ = in_R8[0x10];
        var_f8h._4_4_ = in_R8[0x11];
        var_e8h = *(int64_t *)(in_R8 + 0x14);
        var_f0h = 0;
        *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f8599;
        iVar4 = func_0x000180244550((int64_t)aiStackX_8 + iVar5 + -8, &var_d8h, 0x80, 0);
        if (iVar4 != 0) {
            uVar2 = *in_R9;
            *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f85d7;
            iVar4 = func_0x0001802446f0((int64_t)aiStackX_8 + iVar5 + -8, uVar2, 1);
            iVar6 = iVar7;
            if (iVar4 == 0) {
code_r0x0001801f8887:
                *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f888c;
                fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
code_r0x0001801f8891:
                *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f88a4;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                              *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
                *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f88b6;
                fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar5 + -8));
            } else {
                uVar2 = *in_R9;
                *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f85f1;
                iVar4 = func_0x0001802445f0((int64_t)aiStackX_8 + iVar5 + -8, in_R9 + 1, uVar2);
                if (iVar4 == 0) goto code_r0x0001801f8887;
                *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f860e;
                iVar4 = func_0x0001801f93b0((int64_t)aiStackX_8 + iVar5 + -8, (undefined)var_130h, &var_138h, 0);
                if (iVar4 != 0) {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f8625;
                    iVar4 = func_0x0001802442e0((int64_t)aiStackX_8 + iVar5 + -8, &stack0xfffffffffffffff8 + iVar5);
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f864a;
                        iVar6 = func_0x0001802119f0(in_RCX, 0x1804adac8, in_RDX);
                        if (iVar6 == 0) {
                            *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f8657;
                            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar5), 
                                          *(int64_t *)((int64_t)&var_18h + iVar5));
                            *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f866f;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar5), 
                                          *(int64_t *)((int64_t)&var_18h + iVar5), 
                                          *(int64_t *)((int64_t)&var_10h + iVar5), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
                            *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f8681;
                            fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar5 + -8));
                        } else {
                            *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f8691;
                            iVar7 = fcn.180211490();
                            if (iVar7 == 0) {
                                *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f869e;
                                fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar5), 
                                              *(int64_t *)((int64_t)&var_18h + iVar5));
                                *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f86b6;
                                fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar5), 
                                              *(int64_t *)((int64_t)&var_18h + iVar5), 
                                              *(int64_t *)((int64_t)&var_10h + iVar5), 
                                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                              *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
                                *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f86c8;
                                fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar5 + -8));
                            } else {
                                *(undefined4 *)((int64_t)&var_18h + iVar5) = 1;
                                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b88c0;
                                *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f86f9;
                                iVar4 = fcn.180211b70(*(int64_t *)((int64_t)&var_20h + iVar5), 
                                                      *(int64_t *)((int64_t)&var_18h + iVar5), 
                                                      *(int64_t *)((int64_t)&var_10h + iVar5), 
                                                      *(int64_t *)((int64_t)&arg_28h + iVar5), 
                                                      *(int64_t *)(&stack0x00000030 + iVar5));
                                if (iVar4 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f8702;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar5), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar5));
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f871a;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar5), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar5), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar5), 
                                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f872c;
                                    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar5 + -8));
                                } else {
                                    *(undefined4 *)((int64_t)&var_20h + iVar5) =
                                         *(undefined4 *)(&stack0xfffffffffffffff8 + iVar5);
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f874f;
                                    iVar4 = func_0x000180211bb0(iVar7, 0, (int64_t)&var_10h + iVar5, &var_d8h);
                                    if (iVar4 == 1) {
                                        uVar3 = *(undefined8 *)(in_R8 + 0x14);
                                        *(int32_t *)((int64_t)&var_20h + iVar5) = in_R8[0x12] + -0x10;
                                        *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f87a9;
                                        iVar4 = func_0x000180211bb0(iVar7, 0, (int64_t)&var_10h + iVar5, uVar3);
                                        if (iVar4 == 1) {
                                            *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f87f4;
                                            iVar4 = func_0x000180211b40(iVar7, 0, (int64_t)&var_10h + iVar5 + 4);
                                            if (iVar4 == 1) {
                                                *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f8843;
                                                iVar4 = fcn.180210b80(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                                                      *(int64_t *)((int64_t)aiStackX_8 + iVar5 + -8), 
                                                                      *(int64_t *)((int64_t)aiStackX_8 + iVar5), 
                                                                      *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
                                                if (iVar4 != 1) {
                                                    *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f884d;
                                                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar5), 
                                                                  *(int64_t *)((int64_t)&var_18h + iVar5));
                                                    *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f8865;
                                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar5), 
                                                                  *(int64_t *)((int64_t)&var_18h + iVar5), 
                                                                  *(int64_t *)((int64_t)&var_10h + iVar5), 
                                                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
                                                    *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f8877;
                                                    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar5 + -8));
                                                }
                                            } else {
                                                *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f87fe;
                                                fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar5), 
                                                              *(int64_t *)((int64_t)&var_18h + iVar5));
                                                *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f8816;
                                                fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar5), 
                                                              *(int64_t *)((int64_t)&var_18h + iVar5), 
                                                              *(int64_t *)((int64_t)&var_10h + iVar5), 
                                                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                                              *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
                                                *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f8828;
                                                fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar5 + -8));
                                            }
                                        } else {
                                            *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f87b3;
                                            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar5), 
                                                          *(int64_t *)((int64_t)&var_18h + iVar5));
                                            *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f87cb;
                                            fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar5), 
                                                          *(int64_t *)((int64_t)&var_18h + iVar5), 
                                                          *(int64_t *)((int64_t)&var_10h + iVar5), 
                                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                                          *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
                                            *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f87dd;
                                            fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar5 + -8));
                                        }
                                    } else {
                                        *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f8759;
                                        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar5), 
                                                      *(int64_t *)((int64_t)&var_18h + iVar5));
                                        *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f8771;
                                        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar5), 
                                                      *(int64_t *)((int64_t)&var_18h + iVar5), 
                                                      *(int64_t *)((int64_t)&var_10h + iVar5), 
                                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                                      *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
                                        *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f8783;
                                        fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar5 + -8));
                                    }
                                }
                            }
                        }
                        goto code_r0x0001801f88b9;
                    }
                    *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f862e;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
                    goto code_r0x0001801f8891;
                }
            }
code_r0x0001801f88b9:
            *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f88c1;
            func_0x000180211a40(iVar6);
            *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f88c9;
            func_0x000180211410(iVar7);
            *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f88d3;
            func_0x000180244200((int64_t)aiStackX_8 + iVar5 + -8);
            goto code_r0x0001801f8912;
        }
        *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f85a2;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
        *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f85ba;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                      *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
    } else {
        *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f88da;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
        *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f88f2;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                      *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
    }
    *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f8904;
    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar5 + -8));
    *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f890b;
    func_0x000180211a40(0);
    *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f8912;
    func_0x000180211410(0);
code_r0x0001801f8912:
    *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801f8921;
    fcn.180459870(var_58h ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar5));
    return;
}

// ============================================================
// Function: FUN_1801f8940
// Address: 0x1801f8940
// Size: 58 bytes
// ============================================================
void fcn.1801f8940(int64_t param_1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f894c;
    iVar2 = fcn.18045a350();
    uVar1 = *(undefined8 *)(param_1 + 0x10);
    *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801f895b;
    fcn.180211410(uVar1);
    uVar1 = *(undefined8 *)(param_1 + 0x18);
    *(undefined8 *)(param_1 + 0x10) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801f896c;
    fcn.180211a40(uVar1);
    *(undefined8 *)(param_1 + 0x18) = 0;
    return;
}

// ============================================================
// Function: FUN_1801f8980
// Address: 0x1801f8980
// Size: 157 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_59h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h
// WARNING: [rz-ghidra] Detected overlap for variable var_23h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

void fcn.1801f8980(int64_t arg_48h)
{
    uint8_t *puVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint8_t uVar5;
    uint64_t uVar6;
    uint8_t **in_RDX;
    uint8_t *puVar7;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f8990;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&var_20h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar4);
    puVar7 = in_RDX[3];
    puVar1 = *in_RDX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f89bb;
    iVar3 = fcn.1801f82e0(*(int64_t *)((int64_t)&var_20h + iVar4));
    if (iVar3 != 0) {
        uVar5 = (~(*puVar1 >> 3) & 0x10 | 0xf) & *(uint8_t *)((int64_t)&var_18h + iVar4) ^ *puVar1;
        *puVar1 = uVar5;
        uVar5 = (uVar5 & 3) + 1;
        if (uVar5 != 0) {
            uVar6 = (uint64_t)uVar5;
            iVar2 = iVar4 - (int64_t)puVar7;
            do {
                *puVar7 = *puVar7 ^ puVar7[(int64_t)&var_18h + iVar2 + 1];
                puVar7 = puVar7 + 1;
                uVar6 = uVar6 - 1;
            } while (uVar6 != 0);
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f8a12;
    fcn.180459870(*(uint64_t *)((int64_t)&var_20h + iVar4) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar4));
    return;
}

// ============================================================
// Function: FUN_1801f8a20
// Address: 0x1801f8a20
// Size: 161 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_59h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h
// WARNING: [rz-ghidra] Detected overlap for variable var_23h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

void fcn.1801f8a20(int64_t arg_48h)
{
    uint8_t *puVar1;
    int64_t iVar2;
    uint8_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint8_t **in_RDX;
    uint8_t *puVar7;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f8a30;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&var_20h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar5);
    puVar7 = in_RDX[3];
    puVar1 = *in_RDX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f8a5b;
    iVar4 = fcn.1801f82e0(*(int64_t *)((int64_t)&var_20h + iVar5));
    if (iVar4 != 0) {
        uVar3 = (*puVar1 & 3) + 1;
        if (uVar3 != 0) {
            uVar6 = (uint64_t)uVar3;
            iVar2 = iVar5 - (int64_t)puVar7;
            do {
                *puVar7 = *puVar7 ^ puVar7[(int64_t)&var_18h + iVar2 + 1];
                puVar7 = puVar7 + 1;
                uVar6 = uVar6 - 1;
            } while (uVar6 != 0);
        }
        *puVar1 = *puVar1 ^ (~(*puVar1 >> 3) & 0x10 | 0xf) & *(uint8_t *)((int64_t)&var_18h + iVar5);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f8ab6;
    fcn.180459870(*(uint64_t *)((int64_t)&var_20h + iVar5) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar5));
    return;
}

