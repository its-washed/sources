// Chunk 69 - 50 functions

// ============================================================
// Function: FUN_1800d79b3
// Address: 0x1800d79b3
// Size: 72 bytes
// ============================================================
void fcn.1800d79b3(int64_t arg_28h, int64_t arg_58h, int64_t arg_60h)
{
    undefined4 uVar1;
    int64_t *piVar2;
    int64_t unaff_RDI;
    undefined4 *unaff_R15;
    int64_t var_20h;
    
    piVar2 = (int64_t *)func_0x0001800d8ef0();
    if (piVar2 == (int64_t *)0x0) {
        uVar1 = 0x119;
        var_20h = unaff_RDI;
    } else {
        var_20h = *piVar2;
        uVar1 = *(undefined4 *)((int64_t)piVar2 + 0xc);
    }
    *unaff_R15 = (undefined4)var_20h;
    unaff_R15[1] = var_20h._4_4_;
    unaff_R15[2] = uVar1;
    unaff_R15[3] = arg_28h._4_4_;
    return;
}

// ============================================================
// Function: FUN_1800d7a00
// Address: 0x1800d7a00
// Size: 1014 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

int64_t fcn.1800d7a00(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    uint8_t uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t *piVar5;
    undefined8 uVar6;
    undefined uVar7;
    int64_t iVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    int32_t iVar11;
    uint64_t uVar12;
    char cVar13;
    undefined4 uVar14;
    char cVar15;
    uint64_t uVar16;
    int32_t iVar17;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    iVar11 = *(int32_t *)(arg1 + 0x18);
    puVar1 = (undefined4 *)(arg1 + 0x14);
    uVar16 = *(uint64_t *)(arg1 + 8);
    uVar9 = *(uint32_t *)(arg1 + 0x10);
    uVar12 = (uint64_t)uVar9;
    uVar3 = *puVar1;
    iVar17 = uVar9 - iVar11;
    if (uVar12 < uVar16) {
        uVar7 = *(undefined *)(uVar12 + *(int64_t *)arg1);
    } else {
        uVar7 = 0;
    }
    var_8h._0_4_ = uVar3;
    var_8h._4_4_ = iVar17;
    // switch table (127 cases) at 0x1800d83d8
    switch(uVar7) {
    case 0:
        *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
        *(undefined4 *)arg2 = 0;
        *(undefined4 *)(arg2 + 0xc) = uVar3;
        *(int32_t *)(arg2 + 0x10) = iVar17;
        *(undefined8 *)(arg2 + 0x18) = 0;
        goto code_r0x0001800d83c3;
    default:
        if (uVar12 < uVar16) {
            cVar15 = *(char *)(uVar12 + *(int64_t *)arg1);
        } else {
            cVar15 = '\0';
        }
        if ((int32_t)cVar15 - 0x30U < 10) goto code_r0x0001800d8336;
        if (uVar12 < uVar16) {
            cVar15 = *(char *)(uVar12 + *(int64_t *)arg1);
        } else {
            cVar15 = '\0';
        }
        if (0x19 < ((int32_t)cVar15 | 0x20U) - 0x61) {
            if (uVar16 <= uVar12) goto code_r0x0001800d824c;
            if (*(char *)(uVar12 + *(int64_t *)arg1) != '_') {
                if (*(char *)(uVar12 + *(int64_t *)arg1) < '\0') {
                    func_0x0001800d84b0(arg1, arg2);
                    return arg2;
                }
                goto code_r0x0001800d8243;
            }
        }
        func_0x0001800d78a0(arg1, &var_48h);
        uVar14 = *puVar1;
        *(int32_t *)(arg2 + 0x10) = *(int32_t *)(arg1 + 0x10) - *(int32_t *)(arg1 + 0x18);
        *(undefined4 *)arg2 = (undefined4)var_40h;
        *(undefined4 *)(arg2 + 0xc) = uVar14;
code_r0x0001800d83b2:
        uVar6 = CONCAT44(var_48h._4_4_, (undefined4)var_48h);
        goto code_r0x0001800d83b6;
    case 0x22:
    case 0x27:
        if (uVar12 < uVar16) {
            uVar16 = (uint64_t)*(uint8_t *)(uVar12 + *(int64_t *)arg1);
        } else {
            uVar16 = 0;
        }
        uVar9 = uVar9 + 1;
        var_8h._0_4_ = uVar9;
code_r0x0001800d7e1c:
        *(uint32_t *)(arg1 + 0x10) = uVar9;
        do {
            uVar9 = *(uint32_t *)(arg1 + 0x10);
            uVar12 = (uint64_t)uVar9;
            if (uVar12 < *(uint64_t *)(arg1 + 8)) {
                cVar15 = *(char *)(uVar12 + *(int64_t *)arg1);
            } else {
                cVar15 = '\0';
            }
            if (cVar15 == (char)uVar16) {
                iVar11 = uVar9 + 1;
                *(int32_t *)(arg1 + 0x10) = iVar11;
                iVar8 = (uint64_t)(uint32_t)var_8h + *(int64_t *)arg1;
                var_8h._0_4_ = ~(uint32_t)var_8h + iVar11;
                iVar11 = iVar11 - *(int32_t *)(arg1 + 0x18);
                uVar14 = 0x117;
                goto code_r0x0001800d7ea0;
            }
            if (*(uint64_t *)(arg1 + 8) <= uVar12) {
code_r0x0001800d7e67:
                iVar8 = 0;
                uVar14 = 0x11e;
                iVar11 = uVar9 - *(int32_t *)(arg1 + 0x18);
                var_8h._0_4_ = 0;
code_r0x0001800d7ea0:
                uVar4 = *puVar1;
                *(undefined4 *)(arg2 + 4) = uVar3;
                *(int32_t *)(arg2 + 8) = iVar17;
                *(undefined4 *)(arg2 + 0xc) = uVar4;
                *(int32_t *)(arg2 + 0x10) = iVar11;
                *(undefined4 *)arg2 = uVar14;
                *(uint32_t *)(arg2 + 0x14) = (uint32_t)var_8h;
                *(int64_t *)(arg2 + 0x18) = iVar8;
                return arg2;
            }
            uVar2 = *(uint8_t *)(uVar12 + *(int64_t *)arg1);
            if ((uVar2 < 0xe) && ((0x2401U >> ((int32_t)(char)uVar2 & 0x1fU) & 1) != 0)) goto code_r0x0001800d7e67;
            if (uVar2 != 0x5c) goto code_r0x0001800d7e58;
            func_0x0001800d7520();
        } while( true );
    case 0x23:
    case 0x26:
    case 0x28:
    case 0x29:
    case 0x2c:
    case 0x3b:
    case 0x3f:
    case 0x5d:
    case 0x7c:
        if (uVar12 < uVar16) {
code_r0x0001800d8243:
            uVar10 = (uint32_t)*(uint8_t *)(uVar12 + *(int64_t *)arg1);
        } else {
code_r0x0001800d824c:
            uVar10 = 0;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 1;
        *(uint32_t *)arg2 = uVar10;
        *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
        *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
        *(undefined4 *)(arg2 + 0xc) = uVar3;
        *(undefined8 *)(arg2 + 0x18) = 0;
        goto code_r0x0001800d83c3;
    case 0x25:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if ((uVar16 <= uVar10) || (*(char *)((uint64_t)uVar10 + *(int64_t *)arg1) != '=')) {
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x25;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
        *(undefined4 *)arg2 = 0x113;
        break;
    case 0x2a:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if ((uVar16 <= uVar10) || (*(char *)((uint64_t)uVar10 + *(int64_t *)arg1) != '=')) {
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x2a;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
        *(undefined4 *)arg2 = 0x110;
        break;
    case 0x2b:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if ((uVar16 <= uVar10) || (*(char *)((uint64_t)uVar10 + *(int64_t *)arg1) != '=')) {
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x2b;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
        *(undefined4 *)arg2 = 0x10e;
        break;
    case 0x2d:
        uVar12 = (uint64_t)(uVar9 + 1);
        if (uVar16 <= uVar12) {
code_r0x0001800d7b12:
            *(uint32_t *)(arg1 + 0x10) = uVar9 + 1;
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x2d;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        if (*(char *)(uVar12 + *(int64_t *)arg1) == '>') {
            *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
            *(undefined4 *)arg2 = 0x107;
        } else {
            if (*(char *)(uVar12 + *(int64_t *)arg1) != '=') {
                if (*(char *)(uVar12 + *(int64_t *)arg1) == '-') {
                    func_0x0001800d72c0(arg1, arg2);
                    return arg2;
                }
                goto code_r0x0001800d7b12;
            }
            *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
            *(undefined4 *)arg2 = 0x10f;
        }
        break;
    case 0x2e:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if (uVar10 < uVar16) {
            iVar8 = *(int64_t *)arg1;
            if (*(char *)(iVar8 + (uint64_t)uVar10) == '.') {
                uVar10 = uVar9 + 2;
                *(uint32_t *)(arg1 + 0x10) = uVar10;
                if (uVar10 < uVar16) {
                    if (*(char *)(iVar8 + (uint64_t)uVar10) == '.') {
                        *(uint32_t *)(arg1 + 0x10) = uVar9 + 3;
                        *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
                        *(int32_t *)(arg2 + 0x10) = iVar17 + 3;
                        *(undefined4 *)arg2 = 0x106;
                        *(undefined4 *)(arg2 + 0xc) = uVar3;
                        *(undefined8 *)(arg2 + 0x18) = 0;
                        goto code_r0x0001800d83c3;
                    }
                    if (*(char *)(iVar8 + (uint64_t)uVar10) == '=') {
                        *(uint32_t *)(arg1 + 0x10) = uVar9 + 3;
                        *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
                        *(int32_t *)(arg2 + 0x10) = iVar17 + 3;
                        *(undefined4 *)arg2 = 0x115;
                        *(undefined4 *)(arg2 + 0xc) = uVar3;
                        *(undefined8 *)(arg2 + 0x18) = 0;
                        goto code_r0x0001800d83c3;
                    }
                }
                *(undefined4 *)arg2 = 0x105;
                break;
            }
            cVar15 = *(char *)((uint64_t)uVar10 + *(int64_t *)arg1);
        } else {
            cVar15 = '\0';
        }
        if ((int32_t)cVar15 - 0x30U < 10) {
code_r0x0001800d8336:
            func_0x0001800d7780(arg1, arg2, &var_8h, uVar12);
            return arg2;
        }
        *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
        *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
        *(undefined4 *)arg2 = 0x2e;
        *(undefined4 *)(arg2 + 0xc) = uVar3;
        *(undefined8 *)(arg2 + 0x18) = 0;
        goto code_r0x0001800d83c3;
    case 0x2f:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if (uVar16 <= uVar10) {
code_r0x0001800d80d4:
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x2f;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        cVar15 = *(char *)(*(int64_t *)arg1 + (uint64_t)uVar10);
        if (cVar15 == '=') {
            *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
            *(undefined4 *)arg2 = 0x111;
        } else {
            if (cVar15 != '/') goto code_r0x0001800d80d4;
            uVar10 = uVar9 + 2;
            *(uint32_t *)(arg1 + 0x10) = uVar10;
            if ((uVar10 < uVar16) && (*(char *)(*(int64_t *)arg1 + (uint64_t)uVar10) == '=')) {
                *(uint32_t *)(arg1 + 0x10) = uVar9 + 3;
                *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
                *(int32_t *)(arg2 + 0x10) = iVar17 + 3;
                *(undefined4 *)arg2 = 0x112;
                *(undefined4 *)(arg2 + 0xc) = uVar3;
                *(undefined8 *)(arg2 + 0x18) = 0;
                goto code_r0x0001800d83c3;
            }
            *(undefined4 *)arg2 = 0x109;
        }
        break;
    case 0x3a:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if ((uVar16 <= uVar10) || (*(char *)((uint64_t)uVar10 + *(int64_t *)arg1) != ':')) {
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x3a;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
        *(undefined4 *)arg2 = 0x108;
        break;
    case 0x3c:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if ((uVar16 <= uVar10) || (*(char *)((uint64_t)uVar10 + *(int64_t *)arg1) != '=')) {
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x3c;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
        *(undefined4 *)arg2 = 0x102;
        break;
    case 0x3d:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if ((uVar16 <= uVar10) || (*(char *)((uint64_t)uVar10 + *(int64_t *)arg1) != '=')) {
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x3d;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
        *(undefined4 *)arg2 = 0x101;
        break;
    case 0x3e:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if ((uVar16 <= uVar10) || (*(char *)((uint64_t)uVar10 + *(int64_t *)arg1) != '=')) {
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x3e;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
        *(undefined4 *)arg2 = 0x103;
        break;
    case 0x40:
        uVar10 = uVar9 + 1;
        uVar12 = (uint64_t)uVar10;
        if (uVar10 < uVar16) {
            cVar15 = *(char *)(uVar12 + *(int64_t *)arg1);
            *(uint32_t *)(arg1 + 0x10) = uVar10;
            if (cVar15 == '[') {
                *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
                *(undefined4 *)arg2 = 0x11d;
                break;
            }
            cVar15 = *(char *)(uVar12 + *(int64_t *)arg1);
        } else {
            *(uint32_t *)(arg1 + 0x10) = uVar10;
            cVar15 = '\0';
        }
        if ((((int32_t)cVar15 | 0x20U) - 0x61 < 0x1a) ||
           ((uVar10 < uVar16 && (*(char *)(uVar12 + *(int64_t *)arg1) == '_')))) {
            func_0x0001800d78a0(arg1, &var_48h);
            uVar14 = *puVar1;
            *(int32_t *)(arg2 + 0x10) = *(int32_t *)(arg1 + 0x10) - *(int32_t *)(arg1 + 0x18);
            *(undefined4 *)arg2 = 0x11c;
            *(undefined4 *)(arg2 + 0xc) = uVar14;
            goto code_r0x0001800d83b2;
        }
        *(undefined4 *)arg2 = 0x11c;
        *(uint32_t *)(arg2 + 0x10) = uVar10 - iVar11;
        uVar6 = 0x1805aadb1;
        *(undefined4 *)(arg2 + 0xc) = uVar3;
code_r0x0001800d83b6:
        *(undefined4 *)(arg2 + 4) = uVar3;
        *(int32_t *)(arg2 + 8) = iVar17;
        *(undefined8 *)(arg2 + 0x18) = uVar6;
        goto code_r0x0001800d83c3;
    case 0x5b:
        if (uVar12 < uVar16) {
            cVar15 = *(char *)(uVar12 + *(int64_t *)arg1);
        } else {
            cVar15 = '\0';
        }
        uVar10 = 0;
        do {
            uVar9 = uVar9 + 1;
            uVar12 = (uint64_t)uVar9;
            *(uint32_t *)(arg1 + 0x10) = uVar9;
            if (uVar16 <= uVar12) {
                cVar13 = '\0';
code_r0x0001800d7b81:
                if (cVar15 != cVar13) {
                    uVar10 = ~uVar10;
                }
                if (-1 < (int32_t)uVar10) {
                    func_0x0001800d73e0(arg1, arg2, &var_8h, uVar10, 0x116, 0x11e);
                    return arg2;
                }
                *(undefined4 *)(arg2 + 0x14) = 0;
                *(undefined8 *)(arg2 + 0x18) = 0;
                *(undefined4 *)(arg2 + 0xc) = uVar3;
                if (uVar10 == 0xffffffff) {
                    *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
                    *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
                    *(undefined4 *)arg2 = 0x5b;
                    return arg2;
                }
                *(undefined4 *)arg2 = 0x11e;
                *(uint32_t *)(arg2 + 0x10) = uVar9 - iVar11;
                *(undefined4 *)(arg2 + 4) = uVar3;
                *(int32_t *)(arg2 + 8) = iVar17;
                return arg2;
            }
            if (*(char *)(uVar12 + *(int64_t *)arg1) != '=') {
                cVar13 = *(char *)(uVar12 + *(int64_t *)arg1);
                goto code_r0x0001800d7b81;
            }
            uVar10 = uVar10 + 1;
        } while( true );
    case 0x5e:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if ((uVar16 <= uVar10) || (*(char *)((uint64_t)uVar10 + *(int64_t *)arg1) != '=')) {
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x5e;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
        *(undefined4 *)arg2 = 0x114;
        break;
    case 0x60:
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 1;
        func_0x0001800d75e0(arg1, arg2, CONCAT44(iVar17, uVar3), 0x10a, 0x10d);
        return arg2;
    case 0x7b:
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 1;
        if (*(int64_t *)(arg1 + 0x60) != *(int64_t *)(arg1 + 0x68)) {
            var_8h._0_4_ = 1;
            func_0x0001800d31a0((int64_t *)(arg1 + 0x60), &var_8h);
        }
        *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
        *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
        *(undefined4 *)arg2 = 0x7b;
        *(undefined4 *)(arg2 + 0xc) = uVar3;
        *(undefined8 *)(arg2 + 0x18) = 0;
        goto code_r0x0001800d83c3;
    case 0x7d:
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 1;
        if ((*(int64_t *)(arg1 + 0x60) != *(int64_t *)(arg1 + 0x68)) &&
           (piVar5 = (int32_t *)(*(int64_t *)(arg1 + 0x68) + -4), iVar11 = *piVar5, *(int32_t **)(arg1 + 0x68) = piVar5,
           iVar11 == 0)) {
            func_0x0001800d75e0(arg1, arg2, CONCAT44(iVar17, uVar3), 0x10b, 0x10c);
            return arg2;
        }
        *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
        *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
        *(undefined4 *)arg2 = 0x7d;
        *(undefined4 *)(arg2 + 0xc) = uVar3;
        *(undefined8 *)(arg2 + 0x18) = 0;
        goto code_r0x0001800d83c3;
    case 0x7e:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if ((uVar16 <= uVar10) || (*(char *)((uint64_t)uVar10 + *(int64_t *)arg1) != '=')) {
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x7e;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
        *(undefined4 *)arg2 = 0x104;
    }
    *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
    *(int32_t *)(arg2 + 0x10) = iVar17 + 2;
    *(undefined4 *)(arg2 + 0xc) = uVar3;
    *(undefined8 *)(arg2 + 0x18) = 0;
code_r0x0001800d83c3:
    *(undefined4 *)(arg2 + 0x14) = 0;
    return arg2;
code_r0x0001800d7e58:
    uVar9 = uVar9 + 1;
    goto code_r0x0001800d7e1c;
}

// ============================================================
// Function: FUN_1800d7df6
// Address: 0x1800d7df6
// Size: 247 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

int64_t fcn.1800d7a00(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    uint8_t uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t *piVar5;
    undefined8 uVar6;
    undefined uVar7;
    int64_t iVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    int32_t iVar11;
    uint64_t uVar12;
    char cVar13;
    undefined4 uVar14;
    char cVar15;
    uint64_t uVar16;
    int32_t iVar17;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    iVar11 = *(int32_t *)(arg1 + 0x18);
    puVar1 = (undefined4 *)(arg1 + 0x14);
    uVar16 = *(uint64_t *)(arg1 + 8);
    uVar9 = *(uint32_t *)(arg1 + 0x10);
    uVar12 = (uint64_t)uVar9;
    uVar3 = *puVar1;
    iVar17 = uVar9 - iVar11;
    if (uVar12 < uVar16) {
        uVar7 = *(undefined *)(uVar12 + *(int64_t *)arg1);
    } else {
        uVar7 = 0;
    }
    var_8h._0_4_ = uVar3;
    var_8h._4_4_ = iVar17;
    // switch table (127 cases) at 0x1800d83d8
    switch(uVar7) {
    case 0:
        *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
        *(undefined4 *)arg2 = 0;
        *(undefined4 *)(arg2 + 0xc) = uVar3;
        *(int32_t *)(arg2 + 0x10) = iVar17;
        *(undefined8 *)(arg2 + 0x18) = 0;
        goto code_r0x0001800d83c3;
    default:
        if (uVar12 < uVar16) {
            cVar15 = *(char *)(uVar12 + *(int64_t *)arg1);
        } else {
            cVar15 = '\0';
        }
        if ((int32_t)cVar15 - 0x30U < 10) goto code_r0x0001800d8336;
        if (uVar12 < uVar16) {
            cVar15 = *(char *)(uVar12 + *(int64_t *)arg1);
        } else {
            cVar15 = '\0';
        }
        if (0x19 < ((int32_t)cVar15 | 0x20U) - 0x61) {
            if (uVar16 <= uVar12) goto code_r0x0001800d824c;
            if (*(char *)(uVar12 + *(int64_t *)arg1) != '_') {
                if (*(char *)(uVar12 + *(int64_t *)arg1) < '\0') {
                    func_0x0001800d84b0(arg1, arg2);
                    return arg2;
                }
                goto code_r0x0001800d8243;
            }
        }
        func_0x0001800d78a0(arg1, &var_48h);
        uVar14 = *puVar1;
        *(int32_t *)(arg2 + 0x10) = *(int32_t *)(arg1 + 0x10) - *(int32_t *)(arg1 + 0x18);
        *(undefined4 *)arg2 = (undefined4)var_40h;
        *(undefined4 *)(arg2 + 0xc) = uVar14;
code_r0x0001800d83b2:
        uVar6 = CONCAT44(var_48h._4_4_, (undefined4)var_48h);
        goto code_r0x0001800d83b6;
    case 0x22:
    case 0x27:
        if (uVar12 < uVar16) {
            uVar16 = (uint64_t)*(uint8_t *)(uVar12 + *(int64_t *)arg1);
        } else {
            uVar16 = 0;
        }
        uVar9 = uVar9 + 1;
        var_8h._0_4_ = uVar9;
code_r0x0001800d7e1c:
        *(uint32_t *)(arg1 + 0x10) = uVar9;
        do {
            uVar9 = *(uint32_t *)(arg1 + 0x10);
            uVar12 = (uint64_t)uVar9;
            if (uVar12 < *(uint64_t *)(arg1 + 8)) {
                cVar15 = *(char *)(uVar12 + *(int64_t *)arg1);
            } else {
                cVar15 = '\0';
            }
            if (cVar15 == (char)uVar16) {
                iVar11 = uVar9 + 1;
                *(int32_t *)(arg1 + 0x10) = iVar11;
                iVar8 = (uint64_t)(uint32_t)var_8h + *(int64_t *)arg1;
                var_8h._0_4_ = ~(uint32_t)var_8h + iVar11;
                iVar11 = iVar11 - *(int32_t *)(arg1 + 0x18);
                uVar14 = 0x117;
                goto code_r0x0001800d7ea0;
            }
            if (*(uint64_t *)(arg1 + 8) <= uVar12) {
code_r0x0001800d7e67:
                iVar8 = 0;
                uVar14 = 0x11e;
                iVar11 = uVar9 - *(int32_t *)(arg1 + 0x18);
                var_8h._0_4_ = 0;
code_r0x0001800d7ea0:
                uVar4 = *puVar1;
                *(undefined4 *)(arg2 + 4) = uVar3;
                *(int32_t *)(arg2 + 8) = iVar17;
                *(undefined4 *)(arg2 + 0xc) = uVar4;
                *(int32_t *)(arg2 + 0x10) = iVar11;
                *(undefined4 *)arg2 = uVar14;
                *(uint32_t *)(arg2 + 0x14) = (uint32_t)var_8h;
                *(int64_t *)(arg2 + 0x18) = iVar8;
                return arg2;
            }
            uVar2 = *(uint8_t *)(uVar12 + *(int64_t *)arg1);
            if ((uVar2 < 0xe) && ((0x2401U >> ((int32_t)(char)uVar2 & 0x1fU) & 1) != 0)) goto code_r0x0001800d7e67;
            if (uVar2 != 0x5c) goto code_r0x0001800d7e58;
            func_0x0001800d7520();
        } while( true );
    case 0x23:
    case 0x26:
    case 0x28:
    case 0x29:
    case 0x2c:
    case 0x3b:
    case 0x3f:
    case 0x5d:
    case 0x7c:
        if (uVar12 < uVar16) {
code_r0x0001800d8243:
            uVar10 = (uint32_t)*(uint8_t *)(uVar12 + *(int64_t *)arg1);
        } else {
code_r0x0001800d824c:
            uVar10 = 0;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 1;
        *(uint32_t *)arg2 = uVar10;
        *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
        *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
        *(undefined4 *)(arg2 + 0xc) = uVar3;
        *(undefined8 *)(arg2 + 0x18) = 0;
        goto code_r0x0001800d83c3;
    case 0x25:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if ((uVar16 <= uVar10) || (*(char *)((uint64_t)uVar10 + *(int64_t *)arg1) != '=')) {
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x25;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
        *(undefined4 *)arg2 = 0x113;
        break;
    case 0x2a:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if ((uVar16 <= uVar10) || (*(char *)((uint64_t)uVar10 + *(int64_t *)arg1) != '=')) {
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x2a;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
        *(undefined4 *)arg2 = 0x110;
        break;
    case 0x2b:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if ((uVar16 <= uVar10) || (*(char *)((uint64_t)uVar10 + *(int64_t *)arg1) != '=')) {
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x2b;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
        *(undefined4 *)arg2 = 0x10e;
        break;
    case 0x2d:
        uVar12 = (uint64_t)(uVar9 + 1);
        if (uVar16 <= uVar12) {
code_r0x0001800d7b12:
            *(uint32_t *)(arg1 + 0x10) = uVar9 + 1;
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x2d;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        if (*(char *)(uVar12 + *(int64_t *)arg1) == '>') {
            *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
            *(undefined4 *)arg2 = 0x107;
        } else {
            if (*(char *)(uVar12 + *(int64_t *)arg1) != '=') {
                if (*(char *)(uVar12 + *(int64_t *)arg1) == '-') {
                    func_0x0001800d72c0(arg1, arg2);
                    return arg2;
                }
                goto code_r0x0001800d7b12;
            }
            *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
            *(undefined4 *)arg2 = 0x10f;
        }
        break;
    case 0x2e:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if (uVar10 < uVar16) {
            iVar8 = *(int64_t *)arg1;
            if (*(char *)(iVar8 + (uint64_t)uVar10) == '.') {
                uVar10 = uVar9 + 2;
                *(uint32_t *)(arg1 + 0x10) = uVar10;
                if (uVar10 < uVar16) {
                    if (*(char *)(iVar8 + (uint64_t)uVar10) == '.') {
                        *(uint32_t *)(arg1 + 0x10) = uVar9 + 3;
                        *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
                        *(int32_t *)(arg2 + 0x10) = iVar17 + 3;
                        *(undefined4 *)arg2 = 0x106;
                        *(undefined4 *)(arg2 + 0xc) = uVar3;
                        *(undefined8 *)(arg2 + 0x18) = 0;
                        goto code_r0x0001800d83c3;
                    }
                    if (*(char *)(iVar8 + (uint64_t)uVar10) == '=') {
                        *(uint32_t *)(arg1 + 0x10) = uVar9 + 3;
                        *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
                        *(int32_t *)(arg2 + 0x10) = iVar17 + 3;
                        *(undefined4 *)arg2 = 0x115;
                        *(undefined4 *)(arg2 + 0xc) = uVar3;
                        *(undefined8 *)(arg2 + 0x18) = 0;
                        goto code_r0x0001800d83c3;
                    }
                }
                *(undefined4 *)arg2 = 0x105;
                break;
            }
            cVar15 = *(char *)((uint64_t)uVar10 + *(int64_t *)arg1);
        } else {
            cVar15 = '\0';
        }
        if ((int32_t)cVar15 - 0x30U < 10) {
code_r0x0001800d8336:
            func_0x0001800d7780(arg1, arg2, &var_8h, uVar12);
            return arg2;
        }
        *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
        *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
        *(undefined4 *)arg2 = 0x2e;
        *(undefined4 *)(arg2 + 0xc) = uVar3;
        *(undefined8 *)(arg2 + 0x18) = 0;
        goto code_r0x0001800d83c3;
    case 0x2f:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if (uVar16 <= uVar10) {
code_r0x0001800d80d4:
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x2f;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        cVar15 = *(char *)(*(int64_t *)arg1 + (uint64_t)uVar10);
        if (cVar15 == '=') {
            *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
            *(undefined4 *)arg2 = 0x111;
        } else {
            if (cVar15 != '/') goto code_r0x0001800d80d4;
            uVar10 = uVar9 + 2;
            *(uint32_t *)(arg1 + 0x10) = uVar10;
            if ((uVar10 < uVar16) && (*(char *)(*(int64_t *)arg1 + (uint64_t)uVar10) == '=')) {
                *(uint32_t *)(arg1 + 0x10) = uVar9 + 3;
                *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
                *(int32_t *)(arg2 + 0x10) = iVar17 + 3;
                *(undefined4 *)arg2 = 0x112;
                *(undefined4 *)(arg2 + 0xc) = uVar3;
                *(undefined8 *)(arg2 + 0x18) = 0;
                goto code_r0x0001800d83c3;
            }
            *(undefined4 *)arg2 = 0x109;
        }
        break;
    case 0x3a:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if ((uVar16 <= uVar10) || (*(char *)((uint64_t)uVar10 + *(int64_t *)arg1) != ':')) {
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x3a;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
        *(undefined4 *)arg2 = 0x108;
        break;
    case 0x3c:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if ((uVar16 <= uVar10) || (*(char *)((uint64_t)uVar10 + *(int64_t *)arg1) != '=')) {
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x3c;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
        *(undefined4 *)arg2 = 0x102;
        break;
    case 0x3d:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if ((uVar16 <= uVar10) || (*(char *)((uint64_t)uVar10 + *(int64_t *)arg1) != '=')) {
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x3d;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
        *(undefined4 *)arg2 = 0x101;
        break;
    case 0x3e:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if ((uVar16 <= uVar10) || (*(char *)((uint64_t)uVar10 + *(int64_t *)arg1) != '=')) {
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x3e;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
        *(undefined4 *)arg2 = 0x103;
        break;
    case 0x40:
        uVar10 = uVar9 + 1;
        uVar12 = (uint64_t)uVar10;
        if (uVar10 < uVar16) {
            cVar15 = *(char *)(uVar12 + *(int64_t *)arg1);
            *(uint32_t *)(arg1 + 0x10) = uVar10;
            if (cVar15 == '[') {
                *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
                *(undefined4 *)arg2 = 0x11d;
                break;
            }
            cVar15 = *(char *)(uVar12 + *(int64_t *)arg1);
        } else {
            *(uint32_t *)(arg1 + 0x10) = uVar10;
            cVar15 = '\0';
        }
        if ((((int32_t)cVar15 | 0x20U) - 0x61 < 0x1a) ||
           ((uVar10 < uVar16 && (*(char *)(uVar12 + *(int64_t *)arg1) == '_')))) {
            func_0x0001800d78a0(arg1, &var_48h);
            uVar14 = *puVar1;
            *(int32_t *)(arg2 + 0x10) = *(int32_t *)(arg1 + 0x10) - *(int32_t *)(arg1 + 0x18);
            *(undefined4 *)arg2 = 0x11c;
            *(undefined4 *)(arg2 + 0xc) = uVar14;
            goto code_r0x0001800d83b2;
        }
        *(undefined4 *)arg2 = 0x11c;
        *(uint32_t *)(arg2 + 0x10) = uVar10 - iVar11;
        uVar6 = 0x1805aadb1;
        *(undefined4 *)(arg2 + 0xc) = uVar3;
code_r0x0001800d83b6:
        *(undefined4 *)(arg2 + 4) = uVar3;
        *(int32_t *)(arg2 + 8) = iVar17;
        *(undefined8 *)(arg2 + 0x18) = uVar6;
        goto code_r0x0001800d83c3;
    case 0x5b:
        if (uVar12 < uVar16) {
            cVar15 = *(char *)(uVar12 + *(int64_t *)arg1);
        } else {
            cVar15 = '\0';
        }
        uVar10 = 0;
        do {
            uVar9 = uVar9 + 1;
            uVar12 = (uint64_t)uVar9;
            *(uint32_t *)(arg1 + 0x10) = uVar9;
            if (uVar16 <= uVar12) {
                cVar13 = '\0';
code_r0x0001800d7b81:
                if (cVar15 != cVar13) {
                    uVar10 = ~uVar10;
                }
                if (-1 < (int32_t)uVar10) {
                    func_0x0001800d73e0(arg1, arg2, &var_8h, uVar10, 0x116, 0x11e);
                    return arg2;
                }
                *(undefined4 *)(arg2 + 0x14) = 0;
                *(undefined8 *)(arg2 + 0x18) = 0;
                *(undefined4 *)(arg2 + 0xc) = uVar3;
                if (uVar10 == 0xffffffff) {
                    *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
                    *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
                    *(undefined4 *)arg2 = 0x5b;
                    return arg2;
                }
                *(undefined4 *)arg2 = 0x11e;
                *(uint32_t *)(arg2 + 0x10) = uVar9 - iVar11;
                *(undefined4 *)(arg2 + 4) = uVar3;
                *(int32_t *)(arg2 + 8) = iVar17;
                return arg2;
            }
            if (*(char *)(uVar12 + *(int64_t *)arg1) != '=') {
                cVar13 = *(char *)(uVar12 + *(int64_t *)arg1);
                goto code_r0x0001800d7b81;
            }
            uVar10 = uVar10 + 1;
        } while( true );
    case 0x5e:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if ((uVar16 <= uVar10) || (*(char *)((uint64_t)uVar10 + *(int64_t *)arg1) != '=')) {
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x5e;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
        *(undefined4 *)arg2 = 0x114;
        break;
    case 0x60:
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 1;
        func_0x0001800d75e0(arg1, arg2, CONCAT44(iVar17, uVar3), 0x10a, 0x10d);
        return arg2;
    case 0x7b:
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 1;
        if (*(int64_t *)(arg1 + 0x60) != *(int64_t *)(arg1 + 0x68)) {
            var_8h._0_4_ = 1;
            func_0x0001800d31a0((int64_t *)(arg1 + 0x60), &var_8h);
        }
        *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
        *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
        *(undefined4 *)arg2 = 0x7b;
        *(undefined4 *)(arg2 + 0xc) = uVar3;
        *(undefined8 *)(arg2 + 0x18) = 0;
        goto code_r0x0001800d83c3;
    case 0x7d:
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 1;
        if ((*(int64_t *)(arg1 + 0x60) != *(int64_t *)(arg1 + 0x68)) &&
           (piVar5 = (int32_t *)(*(int64_t *)(arg1 + 0x68) + -4), iVar11 = *piVar5, *(int32_t **)(arg1 + 0x68) = piVar5,
           iVar11 == 0)) {
            func_0x0001800d75e0(arg1, arg2, CONCAT44(iVar17, uVar3), 0x10b, 0x10c);
            return arg2;
        }
        *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
        *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
        *(undefined4 *)arg2 = 0x7d;
        *(undefined4 *)(arg2 + 0xc) = uVar3;
        *(undefined8 *)(arg2 + 0x18) = 0;
        goto code_r0x0001800d83c3;
    case 0x7e:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if ((uVar16 <= uVar10) || (*(char *)((uint64_t)uVar10 + *(int64_t *)arg1) != '=')) {
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x7e;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
        *(undefined4 *)arg2 = 0x104;
    }
    *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
    *(int32_t *)(arg2 + 0x10) = iVar17 + 2;
    *(undefined4 *)(arg2 + 0xc) = uVar3;
    *(undefined8 *)(arg2 + 0x18) = 0;
code_r0x0001800d83c3:
    *(undefined4 *)(arg2 + 0x14) = 0;
    return arg2;
code_r0x0001800d7e58:
    uVar9 = uVar9 + 1;
    goto code_r0x0001800d7e1c;
}

// ============================================================
// Function: FUN_1800d7eed
// Address: 0x1800d7eed
// Size: 1470 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

int64_t fcn.1800d7a00(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    uint8_t uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t *piVar5;
    undefined8 uVar6;
    undefined uVar7;
    int64_t iVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    int32_t iVar11;
    uint64_t uVar12;
    char cVar13;
    undefined4 uVar14;
    char cVar15;
    uint64_t uVar16;
    int32_t iVar17;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    iVar11 = *(int32_t *)(arg1 + 0x18);
    puVar1 = (undefined4 *)(arg1 + 0x14);
    uVar16 = *(uint64_t *)(arg1 + 8);
    uVar9 = *(uint32_t *)(arg1 + 0x10);
    uVar12 = (uint64_t)uVar9;
    uVar3 = *puVar1;
    iVar17 = uVar9 - iVar11;
    if (uVar12 < uVar16) {
        uVar7 = *(undefined *)(uVar12 + *(int64_t *)arg1);
    } else {
        uVar7 = 0;
    }
    var_8h._0_4_ = uVar3;
    var_8h._4_4_ = iVar17;
    // switch table (127 cases) at 0x1800d83d8
    switch(uVar7) {
    case 0:
        *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
        *(undefined4 *)arg2 = 0;
        *(undefined4 *)(arg2 + 0xc) = uVar3;
        *(int32_t *)(arg2 + 0x10) = iVar17;
        *(undefined8 *)(arg2 + 0x18) = 0;
        goto code_r0x0001800d83c3;
    default:
        if (uVar12 < uVar16) {
            cVar15 = *(char *)(uVar12 + *(int64_t *)arg1);
        } else {
            cVar15 = '\0';
        }
        if ((int32_t)cVar15 - 0x30U < 10) goto code_r0x0001800d8336;
        if (uVar12 < uVar16) {
            cVar15 = *(char *)(uVar12 + *(int64_t *)arg1);
        } else {
            cVar15 = '\0';
        }
        if (0x19 < ((int32_t)cVar15 | 0x20U) - 0x61) {
            if (uVar16 <= uVar12) goto code_r0x0001800d824c;
            if (*(char *)(uVar12 + *(int64_t *)arg1) != '_') {
                if (*(char *)(uVar12 + *(int64_t *)arg1) < '\0') {
                    func_0x0001800d84b0(arg1, arg2);
                    return arg2;
                }
                goto code_r0x0001800d8243;
            }
        }
        func_0x0001800d78a0(arg1, &var_48h);
        uVar14 = *puVar1;
        *(int32_t *)(arg2 + 0x10) = *(int32_t *)(arg1 + 0x10) - *(int32_t *)(arg1 + 0x18);
        *(undefined4 *)arg2 = (undefined4)var_40h;
        *(undefined4 *)(arg2 + 0xc) = uVar14;
code_r0x0001800d83b2:
        uVar6 = CONCAT44(var_48h._4_4_, (undefined4)var_48h);
        goto code_r0x0001800d83b6;
    case 0x22:
    case 0x27:
        if (uVar12 < uVar16) {
            uVar16 = (uint64_t)*(uint8_t *)(uVar12 + *(int64_t *)arg1);
        } else {
            uVar16 = 0;
        }
        uVar9 = uVar9 + 1;
        var_8h._0_4_ = uVar9;
code_r0x0001800d7e1c:
        *(uint32_t *)(arg1 + 0x10) = uVar9;
        do {
            uVar9 = *(uint32_t *)(arg1 + 0x10);
            uVar12 = (uint64_t)uVar9;
            if (uVar12 < *(uint64_t *)(arg1 + 8)) {
                cVar15 = *(char *)(uVar12 + *(int64_t *)arg1);
            } else {
                cVar15 = '\0';
            }
            if (cVar15 == (char)uVar16) {
                iVar11 = uVar9 + 1;
                *(int32_t *)(arg1 + 0x10) = iVar11;
                iVar8 = (uint64_t)(uint32_t)var_8h + *(int64_t *)arg1;
                var_8h._0_4_ = ~(uint32_t)var_8h + iVar11;
                iVar11 = iVar11 - *(int32_t *)(arg1 + 0x18);
                uVar14 = 0x117;
                goto code_r0x0001800d7ea0;
            }
            if (*(uint64_t *)(arg1 + 8) <= uVar12) {
code_r0x0001800d7e67:
                iVar8 = 0;
                uVar14 = 0x11e;
                iVar11 = uVar9 - *(int32_t *)(arg1 + 0x18);
                var_8h._0_4_ = 0;
code_r0x0001800d7ea0:
                uVar4 = *puVar1;
                *(undefined4 *)(arg2 + 4) = uVar3;
                *(int32_t *)(arg2 + 8) = iVar17;
                *(undefined4 *)(arg2 + 0xc) = uVar4;
                *(int32_t *)(arg2 + 0x10) = iVar11;
                *(undefined4 *)arg2 = uVar14;
                *(uint32_t *)(arg2 + 0x14) = (uint32_t)var_8h;
                *(int64_t *)(arg2 + 0x18) = iVar8;
                return arg2;
            }
            uVar2 = *(uint8_t *)(uVar12 + *(int64_t *)arg1);
            if ((uVar2 < 0xe) && ((0x2401U >> ((int32_t)(char)uVar2 & 0x1fU) & 1) != 0)) goto code_r0x0001800d7e67;
            if (uVar2 != 0x5c) goto code_r0x0001800d7e58;
            func_0x0001800d7520();
        } while( true );
    case 0x23:
    case 0x26:
    case 0x28:
    case 0x29:
    case 0x2c:
    case 0x3b:
    case 0x3f:
    case 0x5d:
    case 0x7c:
        if (uVar12 < uVar16) {
code_r0x0001800d8243:
            uVar10 = (uint32_t)*(uint8_t *)(uVar12 + *(int64_t *)arg1);
        } else {
code_r0x0001800d824c:
            uVar10 = 0;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 1;
        *(uint32_t *)arg2 = uVar10;
        *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
        *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
        *(undefined4 *)(arg2 + 0xc) = uVar3;
        *(undefined8 *)(arg2 + 0x18) = 0;
        goto code_r0x0001800d83c3;
    case 0x25:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if ((uVar16 <= uVar10) || (*(char *)((uint64_t)uVar10 + *(int64_t *)arg1) != '=')) {
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x25;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
        *(undefined4 *)arg2 = 0x113;
        break;
    case 0x2a:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if ((uVar16 <= uVar10) || (*(char *)((uint64_t)uVar10 + *(int64_t *)arg1) != '=')) {
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x2a;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
        *(undefined4 *)arg2 = 0x110;
        break;
    case 0x2b:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if ((uVar16 <= uVar10) || (*(char *)((uint64_t)uVar10 + *(int64_t *)arg1) != '=')) {
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x2b;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
        *(undefined4 *)arg2 = 0x10e;
        break;
    case 0x2d:
        uVar12 = (uint64_t)(uVar9 + 1);
        if (uVar16 <= uVar12) {
code_r0x0001800d7b12:
            *(uint32_t *)(arg1 + 0x10) = uVar9 + 1;
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x2d;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        if (*(char *)(uVar12 + *(int64_t *)arg1) == '>') {
            *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
            *(undefined4 *)arg2 = 0x107;
        } else {
            if (*(char *)(uVar12 + *(int64_t *)arg1) != '=') {
                if (*(char *)(uVar12 + *(int64_t *)arg1) == '-') {
                    func_0x0001800d72c0(arg1, arg2);
                    return arg2;
                }
                goto code_r0x0001800d7b12;
            }
            *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
            *(undefined4 *)arg2 = 0x10f;
        }
        break;
    case 0x2e:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if (uVar10 < uVar16) {
            iVar8 = *(int64_t *)arg1;
            if (*(char *)(iVar8 + (uint64_t)uVar10) == '.') {
                uVar10 = uVar9 + 2;
                *(uint32_t *)(arg1 + 0x10) = uVar10;
                if (uVar10 < uVar16) {
                    if (*(char *)(iVar8 + (uint64_t)uVar10) == '.') {
                        *(uint32_t *)(arg1 + 0x10) = uVar9 + 3;
                        *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
                        *(int32_t *)(arg2 + 0x10) = iVar17 + 3;
                        *(undefined4 *)arg2 = 0x106;
                        *(undefined4 *)(arg2 + 0xc) = uVar3;
                        *(undefined8 *)(arg2 + 0x18) = 0;
                        goto code_r0x0001800d83c3;
                    }
                    if (*(char *)(iVar8 + (uint64_t)uVar10) == '=') {
                        *(uint32_t *)(arg1 + 0x10) = uVar9 + 3;
                        *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
                        *(int32_t *)(arg2 + 0x10) = iVar17 + 3;
                        *(undefined4 *)arg2 = 0x115;
                        *(undefined4 *)(arg2 + 0xc) = uVar3;
                        *(undefined8 *)(arg2 + 0x18) = 0;
                        goto code_r0x0001800d83c3;
                    }
                }
                *(undefined4 *)arg2 = 0x105;
                break;
            }
            cVar15 = *(char *)((uint64_t)uVar10 + *(int64_t *)arg1);
        } else {
            cVar15 = '\0';
        }
        if ((int32_t)cVar15 - 0x30U < 10) {
code_r0x0001800d8336:
            func_0x0001800d7780(arg1, arg2, &var_8h, uVar12);
            return arg2;
        }
        *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
        *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
        *(undefined4 *)arg2 = 0x2e;
        *(undefined4 *)(arg2 + 0xc) = uVar3;
        *(undefined8 *)(arg2 + 0x18) = 0;
        goto code_r0x0001800d83c3;
    case 0x2f:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if (uVar16 <= uVar10) {
code_r0x0001800d80d4:
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x2f;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        cVar15 = *(char *)(*(int64_t *)arg1 + (uint64_t)uVar10);
        if (cVar15 == '=') {
            *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
            *(undefined4 *)arg2 = 0x111;
        } else {
            if (cVar15 != '/') goto code_r0x0001800d80d4;
            uVar10 = uVar9 + 2;
            *(uint32_t *)(arg1 + 0x10) = uVar10;
            if ((uVar10 < uVar16) && (*(char *)(*(int64_t *)arg1 + (uint64_t)uVar10) == '=')) {
                *(uint32_t *)(arg1 + 0x10) = uVar9 + 3;
                *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
                *(int32_t *)(arg2 + 0x10) = iVar17 + 3;
                *(undefined4 *)arg2 = 0x112;
                *(undefined4 *)(arg2 + 0xc) = uVar3;
                *(undefined8 *)(arg2 + 0x18) = 0;
                goto code_r0x0001800d83c3;
            }
            *(undefined4 *)arg2 = 0x109;
        }
        break;
    case 0x3a:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if ((uVar16 <= uVar10) || (*(char *)((uint64_t)uVar10 + *(int64_t *)arg1) != ':')) {
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x3a;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
        *(undefined4 *)arg2 = 0x108;
        break;
    case 0x3c:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if ((uVar16 <= uVar10) || (*(char *)((uint64_t)uVar10 + *(int64_t *)arg1) != '=')) {
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x3c;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
        *(undefined4 *)arg2 = 0x102;
        break;
    case 0x3d:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if ((uVar16 <= uVar10) || (*(char *)((uint64_t)uVar10 + *(int64_t *)arg1) != '=')) {
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x3d;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
        *(undefined4 *)arg2 = 0x101;
        break;
    case 0x3e:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if ((uVar16 <= uVar10) || (*(char *)((uint64_t)uVar10 + *(int64_t *)arg1) != '=')) {
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x3e;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
        *(undefined4 *)arg2 = 0x103;
        break;
    case 0x40:
        uVar10 = uVar9 + 1;
        uVar12 = (uint64_t)uVar10;
        if (uVar10 < uVar16) {
            cVar15 = *(char *)(uVar12 + *(int64_t *)arg1);
            *(uint32_t *)(arg1 + 0x10) = uVar10;
            if (cVar15 == '[') {
                *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
                *(undefined4 *)arg2 = 0x11d;
                break;
            }
            cVar15 = *(char *)(uVar12 + *(int64_t *)arg1);
        } else {
            *(uint32_t *)(arg1 + 0x10) = uVar10;
            cVar15 = '\0';
        }
        if ((((int32_t)cVar15 | 0x20U) - 0x61 < 0x1a) ||
           ((uVar10 < uVar16 && (*(char *)(uVar12 + *(int64_t *)arg1) == '_')))) {
            func_0x0001800d78a0(arg1, &var_48h);
            uVar14 = *puVar1;
            *(int32_t *)(arg2 + 0x10) = *(int32_t *)(arg1 + 0x10) - *(int32_t *)(arg1 + 0x18);
            *(undefined4 *)arg2 = 0x11c;
            *(undefined4 *)(arg2 + 0xc) = uVar14;
            goto code_r0x0001800d83b2;
        }
        *(undefined4 *)arg2 = 0x11c;
        *(uint32_t *)(arg2 + 0x10) = uVar10 - iVar11;
        uVar6 = 0x1805aadb1;
        *(undefined4 *)(arg2 + 0xc) = uVar3;
code_r0x0001800d83b6:
        *(undefined4 *)(arg2 + 4) = uVar3;
        *(int32_t *)(arg2 + 8) = iVar17;
        *(undefined8 *)(arg2 + 0x18) = uVar6;
        goto code_r0x0001800d83c3;
    case 0x5b:
        if (uVar12 < uVar16) {
            cVar15 = *(char *)(uVar12 + *(int64_t *)arg1);
        } else {
            cVar15 = '\0';
        }
        uVar10 = 0;
        do {
            uVar9 = uVar9 + 1;
            uVar12 = (uint64_t)uVar9;
            *(uint32_t *)(arg1 + 0x10) = uVar9;
            if (uVar16 <= uVar12) {
                cVar13 = '\0';
code_r0x0001800d7b81:
                if (cVar15 != cVar13) {
                    uVar10 = ~uVar10;
                }
                if (-1 < (int32_t)uVar10) {
                    func_0x0001800d73e0(arg1, arg2, &var_8h, uVar10, 0x116, 0x11e);
                    return arg2;
                }
                *(undefined4 *)(arg2 + 0x14) = 0;
                *(undefined8 *)(arg2 + 0x18) = 0;
                *(undefined4 *)(arg2 + 0xc) = uVar3;
                if (uVar10 == 0xffffffff) {
                    *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
                    *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
                    *(undefined4 *)arg2 = 0x5b;
                    return arg2;
                }
                *(undefined4 *)arg2 = 0x11e;
                *(uint32_t *)(arg2 + 0x10) = uVar9 - iVar11;
                *(undefined4 *)(arg2 + 4) = uVar3;
                *(int32_t *)(arg2 + 8) = iVar17;
                return arg2;
            }
            if (*(char *)(uVar12 + *(int64_t *)arg1) != '=') {
                cVar13 = *(char *)(uVar12 + *(int64_t *)arg1);
                goto code_r0x0001800d7b81;
            }
            uVar10 = uVar10 + 1;
        } while( true );
    case 0x5e:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if ((uVar16 <= uVar10) || (*(char *)((uint64_t)uVar10 + *(int64_t *)arg1) != '=')) {
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x5e;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
        *(undefined4 *)arg2 = 0x114;
        break;
    case 0x60:
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 1;
        func_0x0001800d75e0(arg1, arg2, CONCAT44(iVar17, uVar3), 0x10a, 0x10d);
        return arg2;
    case 0x7b:
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 1;
        if (*(int64_t *)(arg1 + 0x60) != *(int64_t *)(arg1 + 0x68)) {
            var_8h._0_4_ = 1;
            func_0x0001800d31a0((int64_t *)(arg1 + 0x60), &var_8h);
        }
        *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
        *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
        *(undefined4 *)arg2 = 0x7b;
        *(undefined4 *)(arg2 + 0xc) = uVar3;
        *(undefined8 *)(arg2 + 0x18) = 0;
        goto code_r0x0001800d83c3;
    case 0x7d:
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 1;
        if ((*(int64_t *)(arg1 + 0x60) != *(int64_t *)(arg1 + 0x68)) &&
           (piVar5 = (int32_t *)(*(int64_t *)(arg1 + 0x68) + -4), iVar11 = *piVar5, *(int32_t **)(arg1 + 0x68) = piVar5,
           iVar11 == 0)) {
            func_0x0001800d75e0(arg1, arg2, CONCAT44(iVar17, uVar3), 0x10b, 0x10c);
            return arg2;
        }
        *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
        *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
        *(undefined4 *)arg2 = 0x7d;
        *(undefined4 *)(arg2 + 0xc) = uVar3;
        *(undefined8 *)(arg2 + 0x18) = 0;
        goto code_r0x0001800d83c3;
    case 0x7e:
        uVar10 = uVar9 + 1;
        *(uint32_t *)(arg1 + 0x10) = uVar10;
        if ((uVar16 <= uVar10) || (*(char *)((uint64_t)uVar10 + *(int64_t *)arg1) != '=')) {
            *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
            *(int32_t *)(arg2 + 0x10) = iVar17 + 1;
            *(undefined4 *)arg2 = 0x7e;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x0001800d83c3;
        }
        *(uint32_t *)(arg1 + 0x10) = uVar9 + 2;
        *(undefined4 *)arg2 = 0x104;
    }
    *(uint64_t *)(arg2 + 4) = CONCAT44(iVar17, uVar3);
    *(int32_t *)(arg2 + 0x10) = iVar17 + 2;
    *(undefined4 *)(arg2 + 0xc) = uVar3;
    *(undefined8 *)(arg2 + 0x18) = 0;
code_r0x0001800d83c3:
    *(undefined4 *)(arg2 + 0x14) = 0;
    return arg2;
code_r0x0001800d7e58:
    uVar9 = uVar9 + 1;
    goto code_r0x0001800d7e1c;
}

// ============================================================
// Function: FUN_1800d84b0
// Address: 0x1800d84b0
// Size: 346 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch

int64_t fcn.1800d84b0(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    undefined4 uVar2;
    uint8_t uVar3;
    int32_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    uint64_t uVar7;
    uint32_t uVar8;
    int32_t iVar9;
    int64_t var_54h;
    int64_t var_48h;
    int64_t var_40h;
    
    uVar6 = *(uint32_t *)(arg1 + 0x10);
    uVar7 = (uint64_t)uVar6;
    iVar1 = *(int32_t *)(arg1 + 0x18);
    iVar9 = uVar6 - iVar1;
    uVar2 = *(undefined4 *)(arg1 + 0x14);
    if (uVar7 < *(uint64_t *)(arg1 + 8)) {
        uVar3 = *(uint8_t *)(uVar7 + *(int64_t *)arg1);
        if (-1 < (char)uVar3) {
            uVar3 = *(uint8_t *)(uVar7 + *(int64_t *)arg1);
            goto code_r0x0001800d85b3;
        }
        uVar8 = (uint32_t)uVar3;
        if ((uVar3 & 0xe0) == 0xc0) {
            iVar4 = 2;
            uVar8 = uVar8 & 0x1f;
        } else if ((uVar3 & 0xf0) == 0xe0) {
            iVar4 = 3;
            uVar8 = uVar8 & 0xf;
        } else {
            if ((uVar3 & 0xf8) != 0xf0) {
                *(undefined4 *)(arg2 + 4) = uVar2;
                *(uint32_t *)(arg1 + 0x10) = uVar6 + 1;
                *(uint32_t *)(arg2 + 0x10) = (uVar6 + 1) - iVar1;
                var_40h = 0;
                *(undefined4 *)(arg2 + 0x14) = 0;
                *(int32_t *)(arg2 + 8) = iVar9;
                *(undefined4 *)(arg2 + 0xc) = uVar2;
                goto code_r0x0001800d85f0;
            }
            iVar4 = 4;
            uVar8 = uVar8 & 7;
        }
        uVar6 = uVar6 + 1;
        iVar5 = 1;
        *(uint32_t *)(arg1 + 0x10) = uVar6;
        do {
            uVar7 = (uint64_t)uVar6;
            if ((*(uint64_t *)(arg1 + 8) <= uVar7) || ((*(uint8_t *)(uVar7 + *(int64_t *)arg1) & 0xc0) != 0x80)) {
                *(undefined4 *)(arg2 + 4) = uVar2;
                var_40h = 0;
                *(int32_t *)(arg2 + 8) = iVar9;
                *(undefined4 *)(arg2 + 0x14) = 0;
                *(undefined4 *)(arg2 + 0xc) = uVar2;
                *(uint32_t *)(arg2 + 0x10) = uVar6 - iVar1;
                goto code_r0x0001800d85f0;
            }
            iVar5 = iVar5 + 1;
            uVar8 = (int32_t)*(char *)(uVar7 + *(int64_t *)arg1) & 0x3fU | uVar8 << 6;
            uVar6 = uVar6 + 1;
            *(uint32_t *)(arg1 + 0x10) = uVar6;
        } while (iVar5 < iVar4);
    } else {
        uVar3 = 0;
code_r0x0001800d85b3:
        uVar6 = uVar6 + 1;
        uVar8 = (uint32_t)uVar3;
        *(uint32_t *)(arg1 + 0x10) = uVar6;
    }
    var_40h = (int64_t)uVar8;
    *(undefined4 *)(arg2 + 0x14) = 0;
    *(undefined4 *)(arg2 + 4) = uVar2;
    *(int32_t *)(arg2 + 8) = iVar9;
    *(undefined4 *)(arg2 + 0xc) = uVar2;
    *(uint32_t *)(arg2 + 0x10) = uVar6 - iVar1;
code_r0x0001800d85f0:
    *(int64_t *)(arg2 + 0x18) = var_40h;
    *(undefined4 *)arg2 = 0x120;
    return arg2;
}

// ============================================================
// Function: FUN_1800d8610
// Address: 0x1800d8610
// Size: 99 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800d8610(int64_t arg1)
{
    char *pcVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint32_t uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    uint8_t uVar11;
    int32_t iVar12;
    uint64_t uVar13;
    char cVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar8 = *(int64_t *)(arg1 + 0x10);
    if (iVar8 != 0) {
        iVar4 = arg1;
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            iVar4 = *(int64_t *)arg1;
        }
        if (((iVar8 != 0) && (iVar3 = func_0x0001804580f0(iVar4, iVar4 + iVar8, 0x5c), iVar3 != iVar4 + iVar8)) &&
           (iVar3 - iVar4 != -1)) {
            uVar2 = *(uint64_t *)(arg1 + 0x10);
            iVar8 = 0;
            uVar6 = 0;
            if (uVar2 != 0) {
code_r0x0001800d8690:
                do {
                    uVar7 = uVar6;
                    uVar13 = *(uint64_t *)(arg1 + 0x18);
                    iVar4 = arg1;
                    if (0xf < uVar13) {
                        iVar4 = *(int64_t *)arg1;
                    }
                    if (*(char *)(iVar4 + uVar7) != '\\') {
                        if (uVar13 < 0x10) {
                            *(undefined *)(arg1 + iVar8) = *(undefined *)(arg1 + uVar7);
                            iVar8 = iVar8 + 1;
                            uVar6 = uVar7 + 1;
                        } else {
                            *(undefined *)(*(int64_t *)arg1 + iVar8) = *(undefined *)(uVar7 + *(int64_t *)arg1);
                            iVar8 = iVar8 + 1;
                            uVar6 = uVar7 + 1;
                        }
                        goto code_r0x0001800d8afd;
                    }
                    if (uVar7 + 1 == uVar2) {
code_r0x0001800d8848:
                        return 0;
                    }
                    iVar4 = arg1;
                    if (0xf < uVar13) {
                        iVar4 = *(int64_t *)arg1;
                    }
                    cVar14 = *(char *)(iVar4 + 1 + uVar7);
                    uVar6 = uVar7 + 2;
    // switch table (7 cases) at 0x1800d8b24
                    switch(cVar14) {
                    case '\0':
                        goto code_r0x0001800d8848;
                    default:
                        uVar10 = (int32_t)cVar14 - 0x30;
                        if (uVar10 < 10) {
                            if (uVar6 != uVar2) {
                                iVar4 = arg1;
                                if (0xf < uVar13) {
                                    iVar4 = *(int64_t *)arg1;
                                }
                                if ((int32_t)*(char *)(iVar4 + uVar6) - 0x30U < 10) {
                                    iVar4 = arg1;
                                    if (0xf < uVar13) {
                                        iVar4 = *(int64_t *)arg1;
                                    }
                                    pcVar1 = (char *)(iVar4 + uVar6);
                                    uVar6 = uVar7 + 3;
                                    uVar10 = (int32_t)*pcVar1 + (uVar10 * 5 + -0x18) * 2;
                                    if (uVar6 != uVar2) {
                                        iVar4 = arg1;
                                        if (0xf < uVar13) {
                                            iVar4 = *(int64_t *)arg1;
                                        }
                                        if ((int32_t)*(char *)(iVar4 + uVar6) - 0x30U < 10) {
                                            iVar4 = arg1;
                                            if (0xf < uVar13) {
                                                iVar4 = *(int64_t *)arg1;
                                            }
                                            pcVar1 = (char *)(iVar4 + uVar6);
                                            uVar6 = uVar7 + 4;
                                            uVar10 = (int32_t)*pcVar1 + (uVar10 * 5 + -0x18) * 2;
                                        }
                                    }
                                    if (0xff < uVar10) {
                                        return 0;
                                    }
                                }
                            }
                            iVar4 = arg1;
                            if (0xf < uVar13) {
                                iVar4 = *(int64_t *)arg1;
                            }
                            *(char *)(iVar4 + iVar8) = (char)uVar10;
                        } else {
    // switch table (22 cases) at 0x1800d8bbc
                            switch(cVar14) {
                            case 'a':
                                cVar14 = '\a';
                                break;
                            case 'b':
                                cVar14 = '\b';
                                break;
                            case 'f':
                                cVar14 = '\f';
                                break;
                            case 'n':
                                cVar14 = '\n';
                                break;
                            case 'r':
                                cVar14 = '\r';
                                break;
                            case 't':
                                cVar14 = '\t';
                                break;
                            case 'v':
                                cVar14 = '\v';
                            }
                            iVar4 = arg1;
                            if (0xf < uVar13) {
                                iVar4 = *(int64_t *)arg1;
                            }
                            *(char *)(iVar4 + iVar8) = cVar14;
                        }
                        goto code_r0x0001800d8afa;
                    case '\n':
                        if (uVar13 < 0x10) {
                            *(undefined *)(arg1 + iVar8) = 10;
                        } else {
                            *(undefined *)(*(int64_t *)arg1 + iVar8) = 10;
                        }
code_r0x0001800d8afa:
                        iVar8 = iVar8 + 1;
                        break;
                    case '\r':
                        iVar4 = arg1;
                        if (0xf < uVar13) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        *(undefined *)(iVar4 + iVar8) = 10;
                        iVar8 = iVar8 + 1;
                        if (uVar2 <= uVar6) goto code_r0x0001800d8838;
                        iVar4 = arg1;
                        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        if (*(char *)(iVar4 + uVar6) != '\n') goto code_r0x0001800d8690;
                        uVar6 = uVar7 + 3;
                        break;
                    case 'u':
                        if (uVar2 < uVar7 + 5) {
                            return 0;
                        }
                        iVar4 = arg1;
                        if (0xf < uVar13) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        if (*(char *)(iVar4 + uVar6) != '{') {
                            return 0;
                        }
                        uVar7 = uVar7 + 3;
                        iVar4 = arg1;
                        if (0xf < uVar13) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        if (*(char *)(iVar4 + uVar7) == '}') {
                            return 0;
                        }
                        uVar10 = 0;
                        iVar12 = 0;
                        do {
                            if (uVar7 == uVar2) {
                                return 0;
                            }
                            iVar4 = arg1;
                            if (0xf < uVar13) {
                                iVar4 = *(int64_t *)arg1;
                                uVar13 = *(uint64_t *)(arg1 + 0x18);
                            }
                            cVar14 = *(char *)(iVar4 + uVar7);
                            if (cVar14 == '}') goto code_r0x0001800d8908;
                            uVar9 = (int32_t)cVar14 - 0x30;
                            uVar5 = (int32_t)cVar14 | 0x20;
                            if (9 < uVar9) {
                                if (5 < uVar5 - 0x61) {
                                    return 0;
                                }
                                if (9 < uVar9) {
                                    uVar9 = uVar5 - 0x57;
                                }
                            }
                            uVar7 = uVar7 + 1;
                            uVar10 = uVar10 * 0x10 + uVar9;
                            iVar12 = iVar12 + 1;
                        } while (iVar12 < 0x10);
                        if (uVar7 == uVar2) {
                            return 0;
                        }
code_r0x0001800d8908:
                        iVar4 = arg1;
                        if (0xf < uVar13) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        if (*(char *)(iVar4 + uVar7) != '}') {
                            return 0;
                        }
                        iVar4 = arg1;
                        if (0xf < uVar13) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        uVar11 = (uint8_t)uVar10;
                        if (uVar10 < 0x80) {
                            *(uint8_t *)(iVar4 + iVar8) = uVar11;
                            uVar6 = uVar7 + 1;
                            iVar8 = iVar8 + 1;
                        } else if (uVar10 < 0x800) {
                            uVar6 = uVar7 + 1;
                            *(uint8_t *)(iVar4 + iVar8) = (uint8_t)(uVar10 >> 6) | 0xc0;
                            *(uint8_t *)(iVar4 + 1 + iVar8) = uVar11 & 0x3f | 0x80;
                            iVar8 = iVar8 + 2;
                        } else if (uVar10 < 0x10000) {
                            uVar6 = uVar7 + 1;
                            *(uint8_t *)(iVar4 + iVar8) = (uint8_t)(uVar10 >> 0xc) | 0xe0;
                            *(uint8_t *)(iVar4 + 2 + iVar8) = uVar11 & 0x3f | 0x80;
                            *(uint8_t *)(iVar4 + 1 + iVar8) = (uint8_t)(uVar10 >> 6) & 0x3f | 0x80;
                            iVar8 = iVar8 + 3;
                        } else {
                            if (0x10ffff < uVar10) {
                                return 0;
                            }
                            uVar6 = uVar7 + 1;
                            *(uint8_t *)(iVar4 + iVar8) = (uint8_t)(uVar10 >> 0x12) | 0xf0;
                            *(uint8_t *)(iVar4 + 1 + iVar8) = (uint8_t)(uVar10 >> 0xc) & 0x3f | 0x80;
                            *(uint8_t *)(iVar4 + 3 + iVar8) = uVar11 & 0x3f | 0x80;
                            *(uint8_t *)(iVar4 + 2 + iVar8) = (uint8_t)(uVar10 >> 6) & 0x3f | 0x80;
                            iVar8 = iVar8 + 4;
                        }
                        break;
                    case 'x':
                        if (uVar2 < uVar7 + 4) {
                            return 0;
                        }
                        iVar12 = 0;
                        uVar10 = 0;
                        do {
                            iVar4 = arg1;
                            if (0xf < uVar13) {
                                iVar4 = *(int64_t *)arg1;
                            }
                            uVar5 = (uint32_t)*(char *)((uint64_t)uVar10 + iVar4 + uVar6);
                            uVar9 = uVar5 - 0x30;
                            uVar5 = uVar5 | 0x20;
                            if (9 < uVar9) {
                                if (5 < uVar5 - 0x61) {
                                    return 0;
                                }
                                if (9 < uVar9) {
                                    uVar9 = uVar5 - 0x57;
                                }
                            }
                            uVar10 = uVar10 + 1;
                            iVar12 = iVar12 * 0x10 + uVar9;
                        } while ((int32_t)uVar10 < 2);
                        if (*(uint64_t *)(arg1 + 0x18) < 0x10) {
                            *(char *)(arg1 + iVar8) = (char)iVar12;
                            iVar8 = iVar8 + 1;
                            uVar6 = uVar7 + 4;
                        } else {
                            *(char *)(*(int64_t *)arg1 + iVar8) = (char)iVar12;
                            iVar8 = iVar8 + 1;
                            uVar6 = uVar7 + 4;
                        }
                        break;
                    case 'z':
                        while( true ) {
                            if (uVar2 <= uVar6) goto code_r0x0001800d8838;
                            iVar4 = arg1;
                            if (0xf < uVar13) {
                                iVar4 = *(int64_t *)arg1;
                            }
                            if ((*(char *)(iVar4 + uVar6) != ' ') && (4 < (uint8_t)(*(char *)(iVar4 + uVar6) - 9U)))
                            break;
                            uVar6 = uVar6 + 1;
                        }
                    }
code_r0x0001800d8afd:
                } while (uVar6 < uVar2);
            }
code_r0x0001800d8838:
            func_0x00018000b3b0(arg1, iVar8, 0);
            return 1;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1800d8673
// Address: 0x1800d8673
// Size: 495 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800d8610(int64_t arg1)
{
    char *pcVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint32_t uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    uint8_t uVar11;
    int32_t iVar12;
    uint64_t uVar13;
    char cVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar8 = *(int64_t *)(arg1 + 0x10);
    if (iVar8 != 0) {
        iVar4 = arg1;
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            iVar4 = *(int64_t *)arg1;
        }
        if (((iVar8 != 0) && (iVar3 = func_0x0001804580f0(iVar4, iVar4 + iVar8, 0x5c), iVar3 != iVar4 + iVar8)) &&
           (iVar3 - iVar4 != -1)) {
            uVar2 = *(uint64_t *)(arg1 + 0x10);
            iVar8 = 0;
            uVar6 = 0;
            if (uVar2 != 0) {
code_r0x0001800d8690:
                do {
                    uVar7 = uVar6;
                    uVar13 = *(uint64_t *)(arg1 + 0x18);
                    iVar4 = arg1;
                    if (0xf < uVar13) {
                        iVar4 = *(int64_t *)arg1;
                    }
                    if (*(char *)(iVar4 + uVar7) != '\\') {
                        if (uVar13 < 0x10) {
                            *(undefined *)(arg1 + iVar8) = *(undefined *)(arg1 + uVar7);
                            iVar8 = iVar8 + 1;
                            uVar6 = uVar7 + 1;
                        } else {
                            *(undefined *)(*(int64_t *)arg1 + iVar8) = *(undefined *)(uVar7 + *(int64_t *)arg1);
                            iVar8 = iVar8 + 1;
                            uVar6 = uVar7 + 1;
                        }
                        goto code_r0x0001800d8afd;
                    }
                    if (uVar7 + 1 == uVar2) {
code_r0x0001800d8848:
                        return 0;
                    }
                    iVar4 = arg1;
                    if (0xf < uVar13) {
                        iVar4 = *(int64_t *)arg1;
                    }
                    cVar14 = *(char *)(iVar4 + 1 + uVar7);
                    uVar6 = uVar7 + 2;
    // switch table (7 cases) at 0x1800d8b24
                    switch(cVar14) {
                    case '\0':
                        goto code_r0x0001800d8848;
                    default:
                        uVar10 = (int32_t)cVar14 - 0x30;
                        if (uVar10 < 10) {
                            if (uVar6 != uVar2) {
                                iVar4 = arg1;
                                if (0xf < uVar13) {
                                    iVar4 = *(int64_t *)arg1;
                                }
                                if ((int32_t)*(char *)(iVar4 + uVar6) - 0x30U < 10) {
                                    iVar4 = arg1;
                                    if (0xf < uVar13) {
                                        iVar4 = *(int64_t *)arg1;
                                    }
                                    pcVar1 = (char *)(iVar4 + uVar6);
                                    uVar6 = uVar7 + 3;
                                    uVar10 = (int32_t)*pcVar1 + (uVar10 * 5 + -0x18) * 2;
                                    if (uVar6 != uVar2) {
                                        iVar4 = arg1;
                                        if (0xf < uVar13) {
                                            iVar4 = *(int64_t *)arg1;
                                        }
                                        if ((int32_t)*(char *)(iVar4 + uVar6) - 0x30U < 10) {
                                            iVar4 = arg1;
                                            if (0xf < uVar13) {
                                                iVar4 = *(int64_t *)arg1;
                                            }
                                            pcVar1 = (char *)(iVar4 + uVar6);
                                            uVar6 = uVar7 + 4;
                                            uVar10 = (int32_t)*pcVar1 + (uVar10 * 5 + -0x18) * 2;
                                        }
                                    }
                                    if (0xff < uVar10) {
                                        return 0;
                                    }
                                }
                            }
                            iVar4 = arg1;
                            if (0xf < uVar13) {
                                iVar4 = *(int64_t *)arg1;
                            }
                            *(char *)(iVar4 + iVar8) = (char)uVar10;
                        } else {
    // switch table (22 cases) at 0x1800d8bbc
                            switch(cVar14) {
                            case 'a':
                                cVar14 = '\a';
                                break;
                            case 'b':
                                cVar14 = '\b';
                                break;
                            case 'f':
                                cVar14 = '\f';
                                break;
                            case 'n':
                                cVar14 = '\n';
                                break;
                            case 'r':
                                cVar14 = '\r';
                                break;
                            case 't':
                                cVar14 = '\t';
                                break;
                            case 'v':
                                cVar14 = '\v';
                            }
                            iVar4 = arg1;
                            if (0xf < uVar13) {
                                iVar4 = *(int64_t *)arg1;
                            }
                            *(char *)(iVar4 + iVar8) = cVar14;
                        }
                        goto code_r0x0001800d8afa;
                    case '\n':
                        if (uVar13 < 0x10) {
                            *(undefined *)(arg1 + iVar8) = 10;
                        } else {
                            *(undefined *)(*(int64_t *)arg1 + iVar8) = 10;
                        }
code_r0x0001800d8afa:
                        iVar8 = iVar8 + 1;
                        break;
                    case '\r':
                        iVar4 = arg1;
                        if (0xf < uVar13) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        *(undefined *)(iVar4 + iVar8) = 10;
                        iVar8 = iVar8 + 1;
                        if (uVar2 <= uVar6) goto code_r0x0001800d8838;
                        iVar4 = arg1;
                        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        if (*(char *)(iVar4 + uVar6) != '\n') goto code_r0x0001800d8690;
                        uVar6 = uVar7 + 3;
                        break;
                    case 'u':
                        if (uVar2 < uVar7 + 5) {
                            return 0;
                        }
                        iVar4 = arg1;
                        if (0xf < uVar13) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        if (*(char *)(iVar4 + uVar6) != '{') {
                            return 0;
                        }
                        uVar7 = uVar7 + 3;
                        iVar4 = arg1;
                        if (0xf < uVar13) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        if (*(char *)(iVar4 + uVar7) == '}') {
                            return 0;
                        }
                        uVar10 = 0;
                        iVar12 = 0;
                        do {
                            if (uVar7 == uVar2) {
                                return 0;
                            }
                            iVar4 = arg1;
                            if (0xf < uVar13) {
                                iVar4 = *(int64_t *)arg1;
                                uVar13 = *(uint64_t *)(arg1 + 0x18);
                            }
                            cVar14 = *(char *)(iVar4 + uVar7);
                            if (cVar14 == '}') goto code_r0x0001800d8908;
                            uVar9 = (int32_t)cVar14 - 0x30;
                            uVar5 = (int32_t)cVar14 | 0x20;
                            if (9 < uVar9) {
                                if (5 < uVar5 - 0x61) {
                                    return 0;
                                }
                                if (9 < uVar9) {
                                    uVar9 = uVar5 - 0x57;
                                }
                            }
                            uVar7 = uVar7 + 1;
                            uVar10 = uVar10 * 0x10 + uVar9;
                            iVar12 = iVar12 + 1;
                        } while (iVar12 < 0x10);
                        if (uVar7 == uVar2) {
                            return 0;
                        }
code_r0x0001800d8908:
                        iVar4 = arg1;
                        if (0xf < uVar13) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        if (*(char *)(iVar4 + uVar7) != '}') {
                            return 0;
                        }
                        iVar4 = arg1;
                        if (0xf < uVar13) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        uVar11 = (uint8_t)uVar10;
                        if (uVar10 < 0x80) {
                            *(uint8_t *)(iVar4 + iVar8) = uVar11;
                            uVar6 = uVar7 + 1;
                            iVar8 = iVar8 + 1;
                        } else if (uVar10 < 0x800) {
                            uVar6 = uVar7 + 1;
                            *(uint8_t *)(iVar4 + iVar8) = (uint8_t)(uVar10 >> 6) | 0xc0;
                            *(uint8_t *)(iVar4 + 1 + iVar8) = uVar11 & 0x3f | 0x80;
                            iVar8 = iVar8 + 2;
                        } else if (uVar10 < 0x10000) {
                            uVar6 = uVar7 + 1;
                            *(uint8_t *)(iVar4 + iVar8) = (uint8_t)(uVar10 >> 0xc) | 0xe0;
                            *(uint8_t *)(iVar4 + 2 + iVar8) = uVar11 & 0x3f | 0x80;
                            *(uint8_t *)(iVar4 + 1 + iVar8) = (uint8_t)(uVar10 >> 6) & 0x3f | 0x80;
                            iVar8 = iVar8 + 3;
                        } else {
                            if (0x10ffff < uVar10) {
                                return 0;
                            }
                            uVar6 = uVar7 + 1;
                            *(uint8_t *)(iVar4 + iVar8) = (uint8_t)(uVar10 >> 0x12) | 0xf0;
                            *(uint8_t *)(iVar4 + 1 + iVar8) = (uint8_t)(uVar10 >> 0xc) & 0x3f | 0x80;
                            *(uint8_t *)(iVar4 + 3 + iVar8) = uVar11 & 0x3f | 0x80;
                            *(uint8_t *)(iVar4 + 2 + iVar8) = (uint8_t)(uVar10 >> 6) & 0x3f | 0x80;
                            iVar8 = iVar8 + 4;
                        }
                        break;
                    case 'x':
                        if (uVar2 < uVar7 + 4) {
                            return 0;
                        }
                        iVar12 = 0;
                        uVar10 = 0;
                        do {
                            iVar4 = arg1;
                            if (0xf < uVar13) {
                                iVar4 = *(int64_t *)arg1;
                            }
                            uVar5 = (uint32_t)*(char *)((uint64_t)uVar10 + iVar4 + uVar6);
                            uVar9 = uVar5 - 0x30;
                            uVar5 = uVar5 | 0x20;
                            if (9 < uVar9) {
                                if (5 < uVar5 - 0x61) {
                                    return 0;
                                }
                                if (9 < uVar9) {
                                    uVar9 = uVar5 - 0x57;
                                }
                            }
                            uVar10 = uVar10 + 1;
                            iVar12 = iVar12 * 0x10 + uVar9;
                        } while ((int32_t)uVar10 < 2);
                        if (*(uint64_t *)(arg1 + 0x18) < 0x10) {
                            *(char *)(arg1 + iVar8) = (char)iVar12;
                            iVar8 = iVar8 + 1;
                            uVar6 = uVar7 + 4;
                        } else {
                            *(char *)(*(int64_t *)arg1 + iVar8) = (char)iVar12;
                            iVar8 = iVar8 + 1;
                            uVar6 = uVar7 + 4;
                        }
                        break;
                    case 'z':
                        while( true ) {
                            if (uVar2 <= uVar6) goto code_r0x0001800d8838;
                            iVar4 = arg1;
                            if (0xf < uVar13) {
                                iVar4 = *(int64_t *)arg1;
                            }
                            if ((*(char *)(iVar4 + uVar6) != ' ') && (4 < (uint8_t)(*(char *)(iVar4 + uVar6) - 9U)))
                            break;
                            uVar6 = uVar6 + 1;
                        }
                    }
code_r0x0001800d8afd:
                } while (uVar6 < uVar2);
            }
code_r0x0001800d8838:
            func_0x00018000b3b0(arg1, iVar8, 0);
            return 1;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1800d8862
// Address: 0x1800d8862
// Size: 688 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800d8610(int64_t arg1)
{
    char *pcVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint32_t uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    uint8_t uVar11;
    int32_t iVar12;
    uint64_t uVar13;
    char cVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar8 = *(int64_t *)(arg1 + 0x10);
    if (iVar8 != 0) {
        iVar4 = arg1;
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            iVar4 = *(int64_t *)arg1;
        }
        if (((iVar8 != 0) && (iVar3 = func_0x0001804580f0(iVar4, iVar4 + iVar8, 0x5c), iVar3 != iVar4 + iVar8)) &&
           (iVar3 - iVar4 != -1)) {
            uVar2 = *(uint64_t *)(arg1 + 0x10);
            iVar8 = 0;
            uVar6 = 0;
            if (uVar2 != 0) {
code_r0x0001800d8690:
                do {
                    uVar7 = uVar6;
                    uVar13 = *(uint64_t *)(arg1 + 0x18);
                    iVar4 = arg1;
                    if (0xf < uVar13) {
                        iVar4 = *(int64_t *)arg1;
                    }
                    if (*(char *)(iVar4 + uVar7) != '\\') {
                        if (uVar13 < 0x10) {
                            *(undefined *)(arg1 + iVar8) = *(undefined *)(arg1 + uVar7);
                            iVar8 = iVar8 + 1;
                            uVar6 = uVar7 + 1;
                        } else {
                            *(undefined *)(*(int64_t *)arg1 + iVar8) = *(undefined *)(uVar7 + *(int64_t *)arg1);
                            iVar8 = iVar8 + 1;
                            uVar6 = uVar7 + 1;
                        }
                        goto code_r0x0001800d8afd;
                    }
                    if (uVar7 + 1 == uVar2) {
code_r0x0001800d8848:
                        return 0;
                    }
                    iVar4 = arg1;
                    if (0xf < uVar13) {
                        iVar4 = *(int64_t *)arg1;
                    }
                    cVar14 = *(char *)(iVar4 + 1 + uVar7);
                    uVar6 = uVar7 + 2;
    // switch table (7 cases) at 0x1800d8b24
                    switch(cVar14) {
                    case '\0':
                        goto code_r0x0001800d8848;
                    default:
                        uVar10 = (int32_t)cVar14 - 0x30;
                        if (uVar10 < 10) {
                            if (uVar6 != uVar2) {
                                iVar4 = arg1;
                                if (0xf < uVar13) {
                                    iVar4 = *(int64_t *)arg1;
                                }
                                if ((int32_t)*(char *)(iVar4 + uVar6) - 0x30U < 10) {
                                    iVar4 = arg1;
                                    if (0xf < uVar13) {
                                        iVar4 = *(int64_t *)arg1;
                                    }
                                    pcVar1 = (char *)(iVar4 + uVar6);
                                    uVar6 = uVar7 + 3;
                                    uVar10 = (int32_t)*pcVar1 + (uVar10 * 5 + -0x18) * 2;
                                    if (uVar6 != uVar2) {
                                        iVar4 = arg1;
                                        if (0xf < uVar13) {
                                            iVar4 = *(int64_t *)arg1;
                                        }
                                        if ((int32_t)*(char *)(iVar4 + uVar6) - 0x30U < 10) {
                                            iVar4 = arg1;
                                            if (0xf < uVar13) {
                                                iVar4 = *(int64_t *)arg1;
                                            }
                                            pcVar1 = (char *)(iVar4 + uVar6);
                                            uVar6 = uVar7 + 4;
                                            uVar10 = (int32_t)*pcVar1 + (uVar10 * 5 + -0x18) * 2;
                                        }
                                    }
                                    if (0xff < uVar10) {
                                        return 0;
                                    }
                                }
                            }
                            iVar4 = arg1;
                            if (0xf < uVar13) {
                                iVar4 = *(int64_t *)arg1;
                            }
                            *(char *)(iVar4 + iVar8) = (char)uVar10;
                        } else {
    // switch table (22 cases) at 0x1800d8bbc
                            switch(cVar14) {
                            case 'a':
                                cVar14 = '\a';
                                break;
                            case 'b':
                                cVar14 = '\b';
                                break;
                            case 'f':
                                cVar14 = '\f';
                                break;
                            case 'n':
                                cVar14 = '\n';
                                break;
                            case 'r':
                                cVar14 = '\r';
                                break;
                            case 't':
                                cVar14 = '\t';
                                break;
                            case 'v':
                                cVar14 = '\v';
                            }
                            iVar4 = arg1;
                            if (0xf < uVar13) {
                                iVar4 = *(int64_t *)arg1;
                            }
                            *(char *)(iVar4 + iVar8) = cVar14;
                        }
                        goto code_r0x0001800d8afa;
                    case '\n':
                        if (uVar13 < 0x10) {
                            *(undefined *)(arg1 + iVar8) = 10;
                        } else {
                            *(undefined *)(*(int64_t *)arg1 + iVar8) = 10;
                        }
code_r0x0001800d8afa:
                        iVar8 = iVar8 + 1;
                        break;
                    case '\r':
                        iVar4 = arg1;
                        if (0xf < uVar13) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        *(undefined *)(iVar4 + iVar8) = 10;
                        iVar8 = iVar8 + 1;
                        if (uVar2 <= uVar6) goto code_r0x0001800d8838;
                        iVar4 = arg1;
                        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        if (*(char *)(iVar4 + uVar6) != '\n') goto code_r0x0001800d8690;
                        uVar6 = uVar7 + 3;
                        break;
                    case 'u':
                        if (uVar2 < uVar7 + 5) {
                            return 0;
                        }
                        iVar4 = arg1;
                        if (0xf < uVar13) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        if (*(char *)(iVar4 + uVar6) != '{') {
                            return 0;
                        }
                        uVar7 = uVar7 + 3;
                        iVar4 = arg1;
                        if (0xf < uVar13) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        if (*(char *)(iVar4 + uVar7) == '}') {
                            return 0;
                        }
                        uVar10 = 0;
                        iVar12 = 0;
                        do {
                            if (uVar7 == uVar2) {
                                return 0;
                            }
                            iVar4 = arg1;
                            if (0xf < uVar13) {
                                iVar4 = *(int64_t *)arg1;
                                uVar13 = *(uint64_t *)(arg1 + 0x18);
                            }
                            cVar14 = *(char *)(iVar4 + uVar7);
                            if (cVar14 == '}') goto code_r0x0001800d8908;
                            uVar9 = (int32_t)cVar14 - 0x30;
                            uVar5 = (int32_t)cVar14 | 0x20;
                            if (9 < uVar9) {
                                if (5 < uVar5 - 0x61) {
                                    return 0;
                                }
                                if (9 < uVar9) {
                                    uVar9 = uVar5 - 0x57;
                                }
                            }
                            uVar7 = uVar7 + 1;
                            uVar10 = uVar10 * 0x10 + uVar9;
                            iVar12 = iVar12 + 1;
                        } while (iVar12 < 0x10);
                        if (uVar7 == uVar2) {
                            return 0;
                        }
code_r0x0001800d8908:
                        iVar4 = arg1;
                        if (0xf < uVar13) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        if (*(char *)(iVar4 + uVar7) != '}') {
                            return 0;
                        }
                        iVar4 = arg1;
                        if (0xf < uVar13) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        uVar11 = (uint8_t)uVar10;
                        if (uVar10 < 0x80) {
                            *(uint8_t *)(iVar4 + iVar8) = uVar11;
                            uVar6 = uVar7 + 1;
                            iVar8 = iVar8 + 1;
                        } else if (uVar10 < 0x800) {
                            uVar6 = uVar7 + 1;
                            *(uint8_t *)(iVar4 + iVar8) = (uint8_t)(uVar10 >> 6) | 0xc0;
                            *(uint8_t *)(iVar4 + 1 + iVar8) = uVar11 & 0x3f | 0x80;
                            iVar8 = iVar8 + 2;
                        } else if (uVar10 < 0x10000) {
                            uVar6 = uVar7 + 1;
                            *(uint8_t *)(iVar4 + iVar8) = (uint8_t)(uVar10 >> 0xc) | 0xe0;
                            *(uint8_t *)(iVar4 + 2 + iVar8) = uVar11 & 0x3f | 0x80;
                            *(uint8_t *)(iVar4 + 1 + iVar8) = (uint8_t)(uVar10 >> 6) & 0x3f | 0x80;
                            iVar8 = iVar8 + 3;
                        } else {
                            if (0x10ffff < uVar10) {
                                return 0;
                            }
                            uVar6 = uVar7 + 1;
                            *(uint8_t *)(iVar4 + iVar8) = (uint8_t)(uVar10 >> 0x12) | 0xf0;
                            *(uint8_t *)(iVar4 + 1 + iVar8) = (uint8_t)(uVar10 >> 0xc) & 0x3f | 0x80;
                            *(uint8_t *)(iVar4 + 3 + iVar8) = uVar11 & 0x3f | 0x80;
                            *(uint8_t *)(iVar4 + 2 + iVar8) = (uint8_t)(uVar10 >> 6) & 0x3f | 0x80;
                            iVar8 = iVar8 + 4;
                        }
                        break;
                    case 'x':
                        if (uVar2 < uVar7 + 4) {
                            return 0;
                        }
                        iVar12 = 0;
                        uVar10 = 0;
                        do {
                            iVar4 = arg1;
                            if (0xf < uVar13) {
                                iVar4 = *(int64_t *)arg1;
                            }
                            uVar5 = (uint32_t)*(char *)((uint64_t)uVar10 + iVar4 + uVar6);
                            uVar9 = uVar5 - 0x30;
                            uVar5 = uVar5 | 0x20;
                            if (9 < uVar9) {
                                if (5 < uVar5 - 0x61) {
                                    return 0;
                                }
                                if (9 < uVar9) {
                                    uVar9 = uVar5 - 0x57;
                                }
                            }
                            uVar10 = uVar10 + 1;
                            iVar12 = iVar12 * 0x10 + uVar9;
                        } while ((int32_t)uVar10 < 2);
                        if (*(uint64_t *)(arg1 + 0x18) < 0x10) {
                            *(char *)(arg1 + iVar8) = (char)iVar12;
                            iVar8 = iVar8 + 1;
                            uVar6 = uVar7 + 4;
                        } else {
                            *(char *)(*(int64_t *)arg1 + iVar8) = (char)iVar12;
                            iVar8 = iVar8 + 1;
                            uVar6 = uVar7 + 4;
                        }
                        break;
                    case 'z':
                        while( true ) {
                            if (uVar2 <= uVar6) goto code_r0x0001800d8838;
                            iVar4 = arg1;
                            if (0xf < uVar13) {
                                iVar4 = *(int64_t *)arg1;
                            }
                            if ((*(char *)(iVar4 + uVar6) != ' ') && (4 < (uint8_t)(*(char *)(iVar4 + uVar6) - 9U)))
                            break;
                            uVar6 = uVar6 + 1;
                        }
                    }
code_r0x0001800d8afd:
                } while (uVar6 < uVar2);
            }
code_r0x0001800d8838:
            func_0x00018000b3b0(arg1, iVar8, 0);
            return 1;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1800d8b12
// Address: 0x1800d8b12
// Size: 258 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800d8610(int64_t arg1)
{
    char *pcVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint32_t uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    uint8_t uVar11;
    int32_t iVar12;
    uint64_t uVar13;
    char cVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar8 = *(int64_t *)(arg1 + 0x10);
    if (iVar8 != 0) {
        iVar4 = arg1;
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            iVar4 = *(int64_t *)arg1;
        }
        if (((iVar8 != 0) && (iVar3 = func_0x0001804580f0(iVar4, iVar4 + iVar8, 0x5c), iVar3 != iVar4 + iVar8)) &&
           (iVar3 - iVar4 != -1)) {
            uVar2 = *(uint64_t *)(arg1 + 0x10);
            iVar8 = 0;
            uVar6 = 0;
            if (uVar2 != 0) {
code_r0x0001800d8690:
                do {
                    uVar7 = uVar6;
                    uVar13 = *(uint64_t *)(arg1 + 0x18);
                    iVar4 = arg1;
                    if (0xf < uVar13) {
                        iVar4 = *(int64_t *)arg1;
                    }
                    if (*(char *)(iVar4 + uVar7) != '\\') {
                        if (uVar13 < 0x10) {
                            *(undefined *)(arg1 + iVar8) = *(undefined *)(arg1 + uVar7);
                            iVar8 = iVar8 + 1;
                            uVar6 = uVar7 + 1;
                        } else {
                            *(undefined *)(*(int64_t *)arg1 + iVar8) = *(undefined *)(uVar7 + *(int64_t *)arg1);
                            iVar8 = iVar8 + 1;
                            uVar6 = uVar7 + 1;
                        }
                        goto code_r0x0001800d8afd;
                    }
                    if (uVar7 + 1 == uVar2) {
code_r0x0001800d8848:
                        return 0;
                    }
                    iVar4 = arg1;
                    if (0xf < uVar13) {
                        iVar4 = *(int64_t *)arg1;
                    }
                    cVar14 = *(char *)(iVar4 + 1 + uVar7);
                    uVar6 = uVar7 + 2;
    // switch table (7 cases) at 0x1800d8b24
                    switch(cVar14) {
                    case '\0':
                        goto code_r0x0001800d8848;
                    default:
                        uVar10 = (int32_t)cVar14 - 0x30;
                        if (uVar10 < 10) {
                            if (uVar6 != uVar2) {
                                iVar4 = arg1;
                                if (0xf < uVar13) {
                                    iVar4 = *(int64_t *)arg1;
                                }
                                if ((int32_t)*(char *)(iVar4 + uVar6) - 0x30U < 10) {
                                    iVar4 = arg1;
                                    if (0xf < uVar13) {
                                        iVar4 = *(int64_t *)arg1;
                                    }
                                    pcVar1 = (char *)(iVar4 + uVar6);
                                    uVar6 = uVar7 + 3;
                                    uVar10 = (int32_t)*pcVar1 + (uVar10 * 5 + -0x18) * 2;
                                    if (uVar6 != uVar2) {
                                        iVar4 = arg1;
                                        if (0xf < uVar13) {
                                            iVar4 = *(int64_t *)arg1;
                                        }
                                        if ((int32_t)*(char *)(iVar4 + uVar6) - 0x30U < 10) {
                                            iVar4 = arg1;
                                            if (0xf < uVar13) {
                                                iVar4 = *(int64_t *)arg1;
                                            }
                                            pcVar1 = (char *)(iVar4 + uVar6);
                                            uVar6 = uVar7 + 4;
                                            uVar10 = (int32_t)*pcVar1 + (uVar10 * 5 + -0x18) * 2;
                                        }
                                    }
                                    if (0xff < uVar10) {
                                        return 0;
                                    }
                                }
                            }
                            iVar4 = arg1;
                            if (0xf < uVar13) {
                                iVar4 = *(int64_t *)arg1;
                            }
                            *(char *)(iVar4 + iVar8) = (char)uVar10;
                        } else {
    // switch table (22 cases) at 0x1800d8bbc
                            switch(cVar14) {
                            case 'a':
                                cVar14 = '\a';
                                break;
                            case 'b':
                                cVar14 = '\b';
                                break;
                            case 'f':
                                cVar14 = '\f';
                                break;
                            case 'n':
                                cVar14 = '\n';
                                break;
                            case 'r':
                                cVar14 = '\r';
                                break;
                            case 't':
                                cVar14 = '\t';
                                break;
                            case 'v':
                                cVar14 = '\v';
                            }
                            iVar4 = arg1;
                            if (0xf < uVar13) {
                                iVar4 = *(int64_t *)arg1;
                            }
                            *(char *)(iVar4 + iVar8) = cVar14;
                        }
                        goto code_r0x0001800d8afa;
                    case '\n':
                        if (uVar13 < 0x10) {
                            *(undefined *)(arg1 + iVar8) = 10;
                        } else {
                            *(undefined *)(*(int64_t *)arg1 + iVar8) = 10;
                        }
code_r0x0001800d8afa:
                        iVar8 = iVar8 + 1;
                        break;
                    case '\r':
                        iVar4 = arg1;
                        if (0xf < uVar13) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        *(undefined *)(iVar4 + iVar8) = 10;
                        iVar8 = iVar8 + 1;
                        if (uVar2 <= uVar6) goto code_r0x0001800d8838;
                        iVar4 = arg1;
                        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        if (*(char *)(iVar4 + uVar6) != '\n') goto code_r0x0001800d8690;
                        uVar6 = uVar7 + 3;
                        break;
                    case 'u':
                        if (uVar2 < uVar7 + 5) {
                            return 0;
                        }
                        iVar4 = arg1;
                        if (0xf < uVar13) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        if (*(char *)(iVar4 + uVar6) != '{') {
                            return 0;
                        }
                        uVar7 = uVar7 + 3;
                        iVar4 = arg1;
                        if (0xf < uVar13) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        if (*(char *)(iVar4 + uVar7) == '}') {
                            return 0;
                        }
                        uVar10 = 0;
                        iVar12 = 0;
                        do {
                            if (uVar7 == uVar2) {
                                return 0;
                            }
                            iVar4 = arg1;
                            if (0xf < uVar13) {
                                iVar4 = *(int64_t *)arg1;
                                uVar13 = *(uint64_t *)(arg1 + 0x18);
                            }
                            cVar14 = *(char *)(iVar4 + uVar7);
                            if (cVar14 == '}') goto code_r0x0001800d8908;
                            uVar9 = (int32_t)cVar14 - 0x30;
                            uVar5 = (int32_t)cVar14 | 0x20;
                            if (9 < uVar9) {
                                if (5 < uVar5 - 0x61) {
                                    return 0;
                                }
                                if (9 < uVar9) {
                                    uVar9 = uVar5 - 0x57;
                                }
                            }
                            uVar7 = uVar7 + 1;
                            uVar10 = uVar10 * 0x10 + uVar9;
                            iVar12 = iVar12 + 1;
                        } while (iVar12 < 0x10);
                        if (uVar7 == uVar2) {
                            return 0;
                        }
code_r0x0001800d8908:
                        iVar4 = arg1;
                        if (0xf < uVar13) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        if (*(char *)(iVar4 + uVar7) != '}') {
                            return 0;
                        }
                        iVar4 = arg1;
                        if (0xf < uVar13) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        uVar11 = (uint8_t)uVar10;
                        if (uVar10 < 0x80) {
                            *(uint8_t *)(iVar4 + iVar8) = uVar11;
                            uVar6 = uVar7 + 1;
                            iVar8 = iVar8 + 1;
                        } else if (uVar10 < 0x800) {
                            uVar6 = uVar7 + 1;
                            *(uint8_t *)(iVar4 + iVar8) = (uint8_t)(uVar10 >> 6) | 0xc0;
                            *(uint8_t *)(iVar4 + 1 + iVar8) = uVar11 & 0x3f | 0x80;
                            iVar8 = iVar8 + 2;
                        } else if (uVar10 < 0x10000) {
                            uVar6 = uVar7 + 1;
                            *(uint8_t *)(iVar4 + iVar8) = (uint8_t)(uVar10 >> 0xc) | 0xe0;
                            *(uint8_t *)(iVar4 + 2 + iVar8) = uVar11 & 0x3f | 0x80;
                            *(uint8_t *)(iVar4 + 1 + iVar8) = (uint8_t)(uVar10 >> 6) & 0x3f | 0x80;
                            iVar8 = iVar8 + 3;
                        } else {
                            if (0x10ffff < uVar10) {
                                return 0;
                            }
                            uVar6 = uVar7 + 1;
                            *(uint8_t *)(iVar4 + iVar8) = (uint8_t)(uVar10 >> 0x12) | 0xf0;
                            *(uint8_t *)(iVar4 + 1 + iVar8) = (uint8_t)(uVar10 >> 0xc) & 0x3f | 0x80;
                            *(uint8_t *)(iVar4 + 3 + iVar8) = uVar11 & 0x3f | 0x80;
                            *(uint8_t *)(iVar4 + 2 + iVar8) = (uint8_t)(uVar10 >> 6) & 0x3f | 0x80;
                            iVar8 = iVar8 + 4;
                        }
                        break;
                    case 'x':
                        if (uVar2 < uVar7 + 4) {
                            return 0;
                        }
                        iVar12 = 0;
                        uVar10 = 0;
                        do {
                            iVar4 = arg1;
                            if (0xf < uVar13) {
                                iVar4 = *(int64_t *)arg1;
                            }
                            uVar5 = (uint32_t)*(char *)((uint64_t)uVar10 + iVar4 + uVar6);
                            uVar9 = uVar5 - 0x30;
                            uVar5 = uVar5 | 0x20;
                            if (9 < uVar9) {
                                if (5 < uVar5 - 0x61) {
                                    return 0;
                                }
                                if (9 < uVar9) {
                                    uVar9 = uVar5 - 0x57;
                                }
                            }
                            uVar10 = uVar10 + 1;
                            iVar12 = iVar12 * 0x10 + uVar9;
                        } while ((int32_t)uVar10 < 2);
                        if (*(uint64_t *)(arg1 + 0x18) < 0x10) {
                            *(char *)(arg1 + iVar8) = (char)iVar12;
                            iVar8 = iVar8 + 1;
                            uVar6 = uVar7 + 4;
                        } else {
                            *(char *)(*(int64_t *)arg1 + iVar8) = (char)iVar12;
                            iVar8 = iVar8 + 1;
                            uVar6 = uVar7 + 4;
                        }
                        break;
                    case 'z':
                        while( true ) {
                            if (uVar2 <= uVar6) goto code_r0x0001800d8838;
                            iVar4 = arg1;
                            if (0xf < uVar13) {
                                iVar4 = *(int64_t *)arg1;
                            }
                            if ((*(char *)(iVar4 + uVar6) != ' ') && (4 < (uint8_t)(*(char *)(iVar4 + uVar6) - 9U)))
                            break;
                            uVar6 = uVar6 + 1;
                        }
                    }
code_r0x0001800d8afd:
                } while (uVar6 < uVar2);
            }
code_r0x0001800d8838:
            func_0x00018000b3b0(arg1, iVar8, 0);
            return 1;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1800d8c20
// Address: 0x1800d8c20
// Size: 56 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

undefined8 * fcn.1800d8c20(int64_t arg1, int64_t arg2, int64_t arg_50h)
{
    undefined4 *puVar1;
    uint8_t *puVar2;
    undefined8 *puVar3;
    uint32_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    int64_t iVar13;
    uint64_t uVar14;
    undefined8 *puVar15;
    int64_t *piVar16;
    uint64_t uVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStackX_20;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar13 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar13 * 3) >> 2) || (iVar9 = func_0x0001800d8ef0(), iVar9 != 0))
    goto code_r0x0001800d8ff0;
    puVar3 = (undefined8 *)(arg1 + 0x18);
    if (iVar13 == 0) {
        uStackX_20 = *puVar3;
        uVar12 = 0x10;
        var_8h._0_4_ = *(uint32_t *)(arg1 + 0x20);
        iVar9 = func_0x000180459890();
        var_60h = 0x10;
        uVar17 = 0;
        uVar14 = 0x10;
        iVar13 = iVar9;
        var_18h = iVar9;
code_r0x0001800d8d10:
        do {
            uVar5 = *(undefined4 *)(arg1 + 0x1c);
            uVar6 = *(undefined4 *)(arg1 + 0x20);
            uVar7 = *(undefined4 *)(arg1 + 0x24);
            uVar10 = uVar17 + 1;
            puVar1 = (undefined4 *)(iVar9 + uVar17 * 0x10);
            *puVar1 = *(undefined4 *)puVar3;
            puVar1[1] = uVar5;
            puVar1[2] = uVar6;
            puVar1[3] = uVar7;
            uVar17 = uVar10;
        } while (uVar10 < uVar12);
    } else {
        uStackX_20 = *puVar3;
        var_8h._0_4_ = *(uint32_t *)(arg1 + 0x20);
        uVar12 = iVar13 * 2;
        if (uVar12 == 0) {
            iVar13 = 0;
            uVar14 = 0;
            var_60h = 0;
            var_18h = 0;
        } else {
            iVar9 = func_0x000180459890();
            uVar17 = 0;
            uVar14 = uVar12;
            iVar13 = iVar9;
            var_18h = iVar9;
            var_60h = uVar12;
            if (uVar12 != 0) goto code_r0x0001800d8d10;
        }
    }
    var_58h = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            piVar16 = (int64_t *)(*(int64_t *)arg1 + var_58h * 0x10);
            uVar4 = *(uint32_t *)(piVar16 + 1);
            if ((uVar4 != *(uint32_t *)(arg1 + 0x20)) ||
               (iVar8 = func_0x000180497f30(*piVar16, *puVar3), iVar13 = var_18h, iVar8 != 0)) {
                uVar11 = 0x811c9dc5;
                if ((uint64_t)uVar4 != 0) {
                    uVar12 = 0;
                    do {
                        puVar2 = (uint8_t *)(*piVar16 + uVar12);
                        uVar12 = uVar12 + 1;
                        uVar11 = (*puVar2 ^ uVar11) * 0x1000193;
                    } while (uVar12 < uVar4);
                }
                uVar12 = (uint64_t)uVar11;
                uVar17 = 0;
                while( true ) {
                    uVar12 = uVar12 & uVar14 - 1;
                    uVar11 = *(uint32_t *)(iVar13 + 8 + uVar12 * 0x10);
                    puVar15 = (undefined8 *)(iVar13 + uVar12 * 0x10);
                    if ((uVar11 == (uint32_t)var_8h) && (iVar8 = func_0x000180497f30(*puVar15, uStackX_20), iVar8 == 0))
                    {
                        uVar5 = *(undefined4 *)((int64_t)piVar16 + 4);
                        uVar6 = *(undefined4 *)(piVar16 + 1);
                        uVar7 = *(undefined4 *)((int64_t)piVar16 + 0xc);
                        *(undefined4 *)puVar15 = *(undefined4 *)piVar16;
                        *(undefined4 *)((int64_t)puVar15 + 4) = uVar5;
                        *(undefined4 *)(puVar15 + 1) = uVar6;
                        *(undefined4 *)((int64_t)puVar15 + 0xc) = uVar7;
                        goto code_r0x0001800d8e5d;
                    }
                    if ((uVar11 == uVar4) && (iVar8 = func_0x000180497f30(*puVar15, *piVar16), iVar8 == 0))
                    goto code_r0x0001800d8e5d;
                    iVar13 = uVar12 + uVar17;
                    uVar17 = uVar17 + 1;
                    if (uVar14 - 1 < uVar17) break;
                    uVar12 = iVar13 + 1;
                    iVar13 = var_18h;
                }
                puVar15 = (undefined8 *)0x0;
code_r0x0001800d8e5d:
                puVar1 = (undefined4 *)(*(int64_t *)arg1 + var_58h * 0x10);
                uVar5 = puVar1[1];
                uVar6 = puVar1[2];
                uVar7 = puVar1[3];
                *(undefined4 *)puVar15 = *puVar1;
                *(undefined4 *)((int64_t)puVar15 + 4) = uVar5;
                *(undefined4 *)(puVar15 + 1) = uVar6;
                *(undefined4 *)((int64_t)puVar15 + 0xc) = uVar7;
                uVar14 = var_60h;
            }
            var_58h = var_58h + 1;
            iVar13 = var_18h;
        } while ((uint64_t)var_58h < *(uint64_t *)(arg1 + 8));
    }
    iVar9 = *(int64_t *)arg1;
    *(uint64_t *)(arg1 + 8) = uVar14;
    *(int64_t *)arg1 = iVar13;
    if (iVar9 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800d8ff0:
    uVar4 = *(uint32_t *)(arg2 + 8);
    uVar11 = 0x811c9dc5;
    if ((uint64_t)uVar4 != 0) {
        uVar12 = 0;
        do {
            puVar2 = (uint8_t *)(*(int64_t *)arg2 + uVar12);
            uVar12 = uVar12 + 1;
            uVar11 = (*puVar2 ^ uVar11) * 0x1000193;
        } while (uVar12 < uVar4);
    }
    iVar13 = *(int64_t *)arg1;
    uVar14 = *(int64_t *)(arg1 + 8) - 1;
    uVar12 = (uint64_t)uVar11;
    uVar17 = 0;
    while( true ) {
        uVar12 = uVar12 & uVar14;
        uVar11 = *(uint32_t *)(iVar13 + 8 + uVar12 * 0x10);
        puVar3 = (undefined8 *)(iVar13 + uVar12 * 0x10);
        if ((uVar11 == *(uint32_t *)(arg1 + 0x20)) &&
           (iVar8 = func_0x000180497f30(*puVar3, *(undefined8 *)(arg1 + 0x18), uVar11), iVar8 == 0)) {
            uVar5 = *(undefined4 *)(arg2 + 4);
            uVar6 = *(undefined4 *)(arg2 + 8);
            uVar7 = *(undefined4 *)(arg2 + 0xc);
            *(undefined4 *)puVar3 = *(undefined4 *)arg2;
            *(undefined4 *)((int64_t)puVar3 + 4) = uVar5;
            *(undefined4 *)(puVar3 + 1) = uVar6;
            *(undefined4 *)((int64_t)puVar3 + 0xc) = uVar7;
            *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
            return puVar3;
        }
        if ((uVar11 == uVar4) && (iVar8 = func_0x000180497f30(*puVar3, *(undefined8 *)arg2, uVar11), iVar8 == 0)) break;
        iVar9 = uVar12 + uVar17;
        uVar17 = uVar17 + 1;
        if (uVar14 < uVar17) {
            return (undefined8 *)0x0;
        }
        iVar13 = *(int64_t *)arg1;
        uVar12 = iVar9 + 1;
    }
    return puVar3;
}

// ============================================================
// Function: FUN_1800d8c58
// Address: 0x1800d8c58
// Size: 263 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

undefined8 * fcn.1800d8c20(int64_t arg1, int64_t arg2, int64_t arg_50h)
{
    undefined4 *puVar1;
    uint8_t *puVar2;
    undefined8 *puVar3;
    uint32_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    int64_t iVar13;
    uint64_t uVar14;
    undefined8 *puVar15;
    int64_t *piVar16;
    uint64_t uVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStackX_20;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar13 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar13 * 3) >> 2) || (iVar9 = func_0x0001800d8ef0(), iVar9 != 0))
    goto code_r0x0001800d8ff0;
    puVar3 = (undefined8 *)(arg1 + 0x18);
    if (iVar13 == 0) {
        uStackX_20 = *puVar3;
        uVar12 = 0x10;
        var_8h._0_4_ = *(uint32_t *)(arg1 + 0x20);
        iVar9 = func_0x000180459890();
        var_60h = 0x10;
        uVar17 = 0;
        uVar14 = 0x10;
        iVar13 = iVar9;
        var_18h = iVar9;
code_r0x0001800d8d10:
        do {
            uVar5 = *(undefined4 *)(arg1 + 0x1c);
            uVar6 = *(undefined4 *)(arg1 + 0x20);
            uVar7 = *(undefined4 *)(arg1 + 0x24);
            uVar10 = uVar17 + 1;
            puVar1 = (undefined4 *)(iVar9 + uVar17 * 0x10);
            *puVar1 = *(undefined4 *)puVar3;
            puVar1[1] = uVar5;
            puVar1[2] = uVar6;
            puVar1[3] = uVar7;
            uVar17 = uVar10;
        } while (uVar10 < uVar12);
    } else {
        uStackX_20 = *puVar3;
        var_8h._0_4_ = *(uint32_t *)(arg1 + 0x20);
        uVar12 = iVar13 * 2;
        if (uVar12 == 0) {
            iVar13 = 0;
            uVar14 = 0;
            var_60h = 0;
            var_18h = 0;
        } else {
            iVar9 = func_0x000180459890();
            uVar17 = 0;
            uVar14 = uVar12;
            iVar13 = iVar9;
            var_18h = iVar9;
            var_60h = uVar12;
            if (uVar12 != 0) goto code_r0x0001800d8d10;
        }
    }
    var_58h = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            piVar16 = (int64_t *)(*(int64_t *)arg1 + var_58h * 0x10);
            uVar4 = *(uint32_t *)(piVar16 + 1);
            if ((uVar4 != *(uint32_t *)(arg1 + 0x20)) ||
               (iVar8 = func_0x000180497f30(*piVar16, *puVar3), iVar13 = var_18h, iVar8 != 0)) {
                uVar11 = 0x811c9dc5;
                if ((uint64_t)uVar4 != 0) {
                    uVar12 = 0;
                    do {
                        puVar2 = (uint8_t *)(*piVar16 + uVar12);
                        uVar12 = uVar12 + 1;
                        uVar11 = (*puVar2 ^ uVar11) * 0x1000193;
                    } while (uVar12 < uVar4);
                }
                uVar12 = (uint64_t)uVar11;
                uVar17 = 0;
                while( true ) {
                    uVar12 = uVar12 & uVar14 - 1;
                    uVar11 = *(uint32_t *)(iVar13 + 8 + uVar12 * 0x10);
                    puVar15 = (undefined8 *)(iVar13 + uVar12 * 0x10);
                    if ((uVar11 == (uint32_t)var_8h) && (iVar8 = func_0x000180497f30(*puVar15, uStackX_20), iVar8 == 0))
                    {
                        uVar5 = *(undefined4 *)((int64_t)piVar16 + 4);
                        uVar6 = *(undefined4 *)(piVar16 + 1);
                        uVar7 = *(undefined4 *)((int64_t)piVar16 + 0xc);
                        *(undefined4 *)puVar15 = *(undefined4 *)piVar16;
                        *(undefined4 *)((int64_t)puVar15 + 4) = uVar5;
                        *(undefined4 *)(puVar15 + 1) = uVar6;
                        *(undefined4 *)((int64_t)puVar15 + 0xc) = uVar7;
                        goto code_r0x0001800d8e5d;
                    }
                    if ((uVar11 == uVar4) && (iVar8 = func_0x000180497f30(*puVar15, *piVar16), iVar8 == 0))
                    goto code_r0x0001800d8e5d;
                    iVar13 = uVar12 + uVar17;
                    uVar17 = uVar17 + 1;
                    if (uVar14 - 1 < uVar17) break;
                    uVar12 = iVar13 + 1;
                    iVar13 = var_18h;
                }
                puVar15 = (undefined8 *)0x0;
code_r0x0001800d8e5d:
                puVar1 = (undefined4 *)(*(int64_t *)arg1 + var_58h * 0x10);
                uVar5 = puVar1[1];
                uVar6 = puVar1[2];
                uVar7 = puVar1[3];
                *(undefined4 *)puVar15 = *puVar1;
                *(undefined4 *)((int64_t)puVar15 + 4) = uVar5;
                *(undefined4 *)(puVar15 + 1) = uVar6;
                *(undefined4 *)((int64_t)puVar15 + 0xc) = uVar7;
                uVar14 = var_60h;
            }
            var_58h = var_58h + 1;
            iVar13 = var_18h;
        } while ((uint64_t)var_58h < *(uint64_t *)(arg1 + 8));
    }
    iVar9 = *(int64_t *)arg1;
    *(uint64_t *)(arg1 + 8) = uVar14;
    *(int64_t *)arg1 = iVar13;
    if (iVar9 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800d8ff0:
    uVar4 = *(uint32_t *)(arg2 + 8);
    uVar11 = 0x811c9dc5;
    if ((uint64_t)uVar4 != 0) {
        uVar12 = 0;
        do {
            puVar2 = (uint8_t *)(*(int64_t *)arg2 + uVar12);
            uVar12 = uVar12 + 1;
            uVar11 = (*puVar2 ^ uVar11) * 0x1000193;
        } while (uVar12 < uVar4);
    }
    iVar13 = *(int64_t *)arg1;
    uVar14 = *(int64_t *)(arg1 + 8) - 1;
    uVar12 = (uint64_t)uVar11;
    uVar17 = 0;
    while( true ) {
        uVar12 = uVar12 & uVar14;
        uVar11 = *(uint32_t *)(iVar13 + 8 + uVar12 * 0x10);
        puVar3 = (undefined8 *)(iVar13 + uVar12 * 0x10);
        if ((uVar11 == *(uint32_t *)(arg1 + 0x20)) &&
           (iVar8 = func_0x000180497f30(*puVar3, *(undefined8 *)(arg1 + 0x18), uVar11), iVar8 == 0)) {
            uVar5 = *(undefined4 *)(arg2 + 4);
            uVar6 = *(undefined4 *)(arg2 + 8);
            uVar7 = *(undefined4 *)(arg2 + 0xc);
            *(undefined4 *)puVar3 = *(undefined4 *)arg2;
            *(undefined4 *)((int64_t)puVar3 + 4) = uVar5;
            *(undefined4 *)(puVar3 + 1) = uVar6;
            *(undefined4 *)((int64_t)puVar3 + 0xc) = uVar7;
            *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
            return puVar3;
        }
        if ((uVar11 == uVar4) && (iVar8 = func_0x000180497f30(*puVar3, *(undefined8 *)arg2, uVar11), iVar8 == 0)) break;
        iVar9 = uVar12 + uVar17;
        uVar17 = uVar17 + 1;
        if (uVar14 < uVar17) {
            return (undefined8 *)0x0;
        }
        iVar13 = *(int64_t *)arg1;
        uVar12 = iVar9 + 1;
    }
    return puVar3;
}

// ============================================================
// Function: FUN_1800d8d5f
// Address: 0x1800d8d5f
// Size: 325 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

undefined8 * fcn.1800d8c20(int64_t arg1, int64_t arg2, int64_t arg_50h)
{
    undefined4 *puVar1;
    uint8_t *puVar2;
    undefined8 *puVar3;
    uint32_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    int64_t iVar13;
    uint64_t uVar14;
    undefined8 *puVar15;
    int64_t *piVar16;
    uint64_t uVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStackX_20;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar13 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar13 * 3) >> 2) || (iVar9 = func_0x0001800d8ef0(), iVar9 != 0))
    goto code_r0x0001800d8ff0;
    puVar3 = (undefined8 *)(arg1 + 0x18);
    if (iVar13 == 0) {
        uStackX_20 = *puVar3;
        uVar12 = 0x10;
        var_8h._0_4_ = *(uint32_t *)(arg1 + 0x20);
        iVar9 = func_0x000180459890();
        var_60h = 0x10;
        uVar17 = 0;
        uVar14 = 0x10;
        iVar13 = iVar9;
        var_18h = iVar9;
code_r0x0001800d8d10:
        do {
            uVar5 = *(undefined4 *)(arg1 + 0x1c);
            uVar6 = *(undefined4 *)(arg1 + 0x20);
            uVar7 = *(undefined4 *)(arg1 + 0x24);
            uVar10 = uVar17 + 1;
            puVar1 = (undefined4 *)(iVar9 + uVar17 * 0x10);
            *puVar1 = *(undefined4 *)puVar3;
            puVar1[1] = uVar5;
            puVar1[2] = uVar6;
            puVar1[3] = uVar7;
            uVar17 = uVar10;
        } while (uVar10 < uVar12);
    } else {
        uStackX_20 = *puVar3;
        var_8h._0_4_ = *(uint32_t *)(arg1 + 0x20);
        uVar12 = iVar13 * 2;
        if (uVar12 == 0) {
            iVar13 = 0;
            uVar14 = 0;
            var_60h = 0;
            var_18h = 0;
        } else {
            iVar9 = func_0x000180459890();
            uVar17 = 0;
            uVar14 = uVar12;
            iVar13 = iVar9;
            var_18h = iVar9;
            var_60h = uVar12;
            if (uVar12 != 0) goto code_r0x0001800d8d10;
        }
    }
    var_58h = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            piVar16 = (int64_t *)(*(int64_t *)arg1 + var_58h * 0x10);
            uVar4 = *(uint32_t *)(piVar16 + 1);
            if ((uVar4 != *(uint32_t *)(arg1 + 0x20)) ||
               (iVar8 = func_0x000180497f30(*piVar16, *puVar3), iVar13 = var_18h, iVar8 != 0)) {
                uVar11 = 0x811c9dc5;
                if ((uint64_t)uVar4 != 0) {
                    uVar12 = 0;
                    do {
                        puVar2 = (uint8_t *)(*piVar16 + uVar12);
                        uVar12 = uVar12 + 1;
                        uVar11 = (*puVar2 ^ uVar11) * 0x1000193;
                    } while (uVar12 < uVar4);
                }
                uVar12 = (uint64_t)uVar11;
                uVar17 = 0;
                while( true ) {
                    uVar12 = uVar12 & uVar14 - 1;
                    uVar11 = *(uint32_t *)(iVar13 + 8 + uVar12 * 0x10);
                    puVar15 = (undefined8 *)(iVar13 + uVar12 * 0x10);
                    if ((uVar11 == (uint32_t)var_8h) && (iVar8 = func_0x000180497f30(*puVar15, uStackX_20), iVar8 == 0))
                    {
                        uVar5 = *(undefined4 *)((int64_t)piVar16 + 4);
                        uVar6 = *(undefined4 *)(piVar16 + 1);
                        uVar7 = *(undefined4 *)((int64_t)piVar16 + 0xc);
                        *(undefined4 *)puVar15 = *(undefined4 *)piVar16;
                        *(undefined4 *)((int64_t)puVar15 + 4) = uVar5;
                        *(undefined4 *)(puVar15 + 1) = uVar6;
                        *(undefined4 *)((int64_t)puVar15 + 0xc) = uVar7;
                        goto code_r0x0001800d8e5d;
                    }
                    if ((uVar11 == uVar4) && (iVar8 = func_0x000180497f30(*puVar15, *piVar16), iVar8 == 0))
                    goto code_r0x0001800d8e5d;
                    iVar13 = uVar12 + uVar17;
                    uVar17 = uVar17 + 1;
                    if (uVar14 - 1 < uVar17) break;
                    uVar12 = iVar13 + 1;
                    iVar13 = var_18h;
                }
                puVar15 = (undefined8 *)0x0;
code_r0x0001800d8e5d:
                puVar1 = (undefined4 *)(*(int64_t *)arg1 + var_58h * 0x10);
                uVar5 = puVar1[1];
                uVar6 = puVar1[2];
                uVar7 = puVar1[3];
                *(undefined4 *)puVar15 = *puVar1;
                *(undefined4 *)((int64_t)puVar15 + 4) = uVar5;
                *(undefined4 *)(puVar15 + 1) = uVar6;
                *(undefined4 *)((int64_t)puVar15 + 0xc) = uVar7;
                uVar14 = var_60h;
            }
            var_58h = var_58h + 1;
            iVar13 = var_18h;
        } while ((uint64_t)var_58h < *(uint64_t *)(arg1 + 8));
    }
    iVar9 = *(int64_t *)arg1;
    *(uint64_t *)(arg1 + 8) = uVar14;
    *(int64_t *)arg1 = iVar13;
    if (iVar9 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800d8ff0:
    uVar4 = *(uint32_t *)(arg2 + 8);
    uVar11 = 0x811c9dc5;
    if ((uint64_t)uVar4 != 0) {
        uVar12 = 0;
        do {
            puVar2 = (uint8_t *)(*(int64_t *)arg2 + uVar12);
            uVar12 = uVar12 + 1;
            uVar11 = (*puVar2 ^ uVar11) * 0x1000193;
        } while (uVar12 < uVar4);
    }
    iVar13 = *(int64_t *)arg1;
    uVar14 = *(int64_t *)(arg1 + 8) - 1;
    uVar12 = (uint64_t)uVar11;
    uVar17 = 0;
    while( true ) {
        uVar12 = uVar12 & uVar14;
        uVar11 = *(uint32_t *)(iVar13 + 8 + uVar12 * 0x10);
        puVar3 = (undefined8 *)(iVar13 + uVar12 * 0x10);
        if ((uVar11 == *(uint32_t *)(arg1 + 0x20)) &&
           (iVar8 = func_0x000180497f30(*puVar3, *(undefined8 *)(arg1 + 0x18), uVar11), iVar8 == 0)) {
            uVar5 = *(undefined4 *)(arg2 + 4);
            uVar6 = *(undefined4 *)(arg2 + 8);
            uVar7 = *(undefined4 *)(arg2 + 0xc);
            *(undefined4 *)puVar3 = *(undefined4 *)arg2;
            *(undefined4 *)((int64_t)puVar3 + 4) = uVar5;
            *(undefined4 *)(puVar3 + 1) = uVar6;
            *(undefined4 *)((int64_t)puVar3 + 0xc) = uVar7;
            *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
            return puVar3;
        }
        if ((uVar11 == uVar4) && (iVar8 = func_0x000180497f30(*puVar3, *(undefined8 *)arg2, uVar11), iVar8 == 0)) break;
        iVar9 = uVar12 + uVar17;
        uVar17 = uVar17 + 1;
        if (uVar14 < uVar17) {
            return (undefined8 *)0x0;
        }
        iVar13 = *(int64_t *)arg1;
        uVar12 = iVar9 + 1;
    }
    return puVar3;
}

// ============================================================
// Function: FUN_1800d8ea4
// Address: 0x1800d8ea4
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

undefined8 * fcn.1800d8c20(int64_t arg1, int64_t arg2, int64_t arg_50h)
{
    undefined4 *puVar1;
    uint8_t *puVar2;
    undefined8 *puVar3;
    uint32_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    int64_t iVar13;
    uint64_t uVar14;
    undefined8 *puVar15;
    int64_t *piVar16;
    uint64_t uVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStackX_20;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar13 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar13 * 3) >> 2) || (iVar9 = func_0x0001800d8ef0(), iVar9 != 0))
    goto code_r0x0001800d8ff0;
    puVar3 = (undefined8 *)(arg1 + 0x18);
    if (iVar13 == 0) {
        uStackX_20 = *puVar3;
        uVar12 = 0x10;
        var_8h._0_4_ = *(uint32_t *)(arg1 + 0x20);
        iVar9 = func_0x000180459890();
        var_60h = 0x10;
        uVar17 = 0;
        uVar14 = 0x10;
        iVar13 = iVar9;
        var_18h = iVar9;
code_r0x0001800d8d10:
        do {
            uVar5 = *(undefined4 *)(arg1 + 0x1c);
            uVar6 = *(undefined4 *)(arg1 + 0x20);
            uVar7 = *(undefined4 *)(arg1 + 0x24);
            uVar10 = uVar17 + 1;
            puVar1 = (undefined4 *)(iVar9 + uVar17 * 0x10);
            *puVar1 = *(undefined4 *)puVar3;
            puVar1[1] = uVar5;
            puVar1[2] = uVar6;
            puVar1[3] = uVar7;
            uVar17 = uVar10;
        } while (uVar10 < uVar12);
    } else {
        uStackX_20 = *puVar3;
        var_8h._0_4_ = *(uint32_t *)(arg1 + 0x20);
        uVar12 = iVar13 * 2;
        if (uVar12 == 0) {
            iVar13 = 0;
            uVar14 = 0;
            var_60h = 0;
            var_18h = 0;
        } else {
            iVar9 = func_0x000180459890();
            uVar17 = 0;
            uVar14 = uVar12;
            iVar13 = iVar9;
            var_18h = iVar9;
            var_60h = uVar12;
            if (uVar12 != 0) goto code_r0x0001800d8d10;
        }
    }
    var_58h = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            piVar16 = (int64_t *)(*(int64_t *)arg1 + var_58h * 0x10);
            uVar4 = *(uint32_t *)(piVar16 + 1);
            if ((uVar4 != *(uint32_t *)(arg1 + 0x20)) ||
               (iVar8 = func_0x000180497f30(*piVar16, *puVar3), iVar13 = var_18h, iVar8 != 0)) {
                uVar11 = 0x811c9dc5;
                if ((uint64_t)uVar4 != 0) {
                    uVar12 = 0;
                    do {
                        puVar2 = (uint8_t *)(*piVar16 + uVar12);
                        uVar12 = uVar12 + 1;
                        uVar11 = (*puVar2 ^ uVar11) * 0x1000193;
                    } while (uVar12 < uVar4);
                }
                uVar12 = (uint64_t)uVar11;
                uVar17 = 0;
                while( true ) {
                    uVar12 = uVar12 & uVar14 - 1;
                    uVar11 = *(uint32_t *)(iVar13 + 8 + uVar12 * 0x10);
                    puVar15 = (undefined8 *)(iVar13 + uVar12 * 0x10);
                    if ((uVar11 == (uint32_t)var_8h) && (iVar8 = func_0x000180497f30(*puVar15, uStackX_20), iVar8 == 0))
                    {
                        uVar5 = *(undefined4 *)((int64_t)piVar16 + 4);
                        uVar6 = *(undefined4 *)(piVar16 + 1);
                        uVar7 = *(undefined4 *)((int64_t)piVar16 + 0xc);
                        *(undefined4 *)puVar15 = *(undefined4 *)piVar16;
                        *(undefined4 *)((int64_t)puVar15 + 4) = uVar5;
                        *(undefined4 *)(puVar15 + 1) = uVar6;
                        *(undefined4 *)((int64_t)puVar15 + 0xc) = uVar7;
                        goto code_r0x0001800d8e5d;
                    }
                    if ((uVar11 == uVar4) && (iVar8 = func_0x000180497f30(*puVar15, *piVar16), iVar8 == 0))
                    goto code_r0x0001800d8e5d;
                    iVar13 = uVar12 + uVar17;
                    uVar17 = uVar17 + 1;
                    if (uVar14 - 1 < uVar17) break;
                    uVar12 = iVar13 + 1;
                    iVar13 = var_18h;
                }
                puVar15 = (undefined8 *)0x0;
code_r0x0001800d8e5d:
                puVar1 = (undefined4 *)(*(int64_t *)arg1 + var_58h * 0x10);
                uVar5 = puVar1[1];
                uVar6 = puVar1[2];
                uVar7 = puVar1[3];
                *(undefined4 *)puVar15 = *puVar1;
                *(undefined4 *)((int64_t)puVar15 + 4) = uVar5;
                *(undefined4 *)(puVar15 + 1) = uVar6;
                *(undefined4 *)((int64_t)puVar15 + 0xc) = uVar7;
                uVar14 = var_60h;
            }
            var_58h = var_58h + 1;
            iVar13 = var_18h;
        } while ((uint64_t)var_58h < *(uint64_t *)(arg1 + 8));
    }
    iVar9 = *(int64_t *)arg1;
    *(uint64_t *)(arg1 + 8) = uVar14;
    *(int64_t *)arg1 = iVar13;
    if (iVar9 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800d8ff0:
    uVar4 = *(uint32_t *)(arg2 + 8);
    uVar11 = 0x811c9dc5;
    if ((uint64_t)uVar4 != 0) {
        uVar12 = 0;
        do {
            puVar2 = (uint8_t *)(*(int64_t *)arg2 + uVar12);
            uVar12 = uVar12 + 1;
            uVar11 = (*puVar2 ^ uVar11) * 0x1000193;
        } while (uVar12 < uVar4);
    }
    iVar13 = *(int64_t *)arg1;
    uVar14 = *(int64_t *)(arg1 + 8) - 1;
    uVar12 = (uint64_t)uVar11;
    uVar17 = 0;
    while( true ) {
        uVar12 = uVar12 & uVar14;
        uVar11 = *(uint32_t *)(iVar13 + 8 + uVar12 * 0x10);
        puVar3 = (undefined8 *)(iVar13 + uVar12 * 0x10);
        if ((uVar11 == *(uint32_t *)(arg1 + 0x20)) &&
           (iVar8 = func_0x000180497f30(*puVar3, *(undefined8 *)(arg1 + 0x18), uVar11), iVar8 == 0)) {
            uVar5 = *(undefined4 *)(arg2 + 4);
            uVar6 = *(undefined4 *)(arg2 + 8);
            uVar7 = *(undefined4 *)(arg2 + 0xc);
            *(undefined4 *)puVar3 = *(undefined4 *)arg2;
            *(undefined4 *)((int64_t)puVar3 + 4) = uVar5;
            *(undefined4 *)(puVar3 + 1) = uVar6;
            *(undefined4 *)((int64_t)puVar3 + 0xc) = uVar7;
            *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
            return puVar3;
        }
        if ((uVar11 == uVar4) && (iVar8 = func_0x000180497f30(*puVar3, *(undefined8 *)arg2, uVar11), iVar8 == 0)) break;
        iVar9 = uVar12 + uVar17;
        uVar17 = uVar17 + 1;
        if (uVar14 < uVar17) {
            return (undefined8 *)0x0;
        }
        iVar13 = *(int64_t *)arg1;
        uVar12 = iVar9 + 1;
    }
    return puVar3;
}

// ============================================================
// Function: FUN_1800d8eca
// Address: 0x1800d8eca
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

undefined8 * fcn.1800d8c20(int64_t arg1, int64_t arg2, int64_t arg_50h)
{
    undefined4 *puVar1;
    uint8_t *puVar2;
    undefined8 *puVar3;
    uint32_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    int64_t iVar13;
    uint64_t uVar14;
    undefined8 *puVar15;
    int64_t *piVar16;
    uint64_t uVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStackX_20;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar13 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar13 * 3) >> 2) || (iVar9 = func_0x0001800d8ef0(), iVar9 != 0))
    goto code_r0x0001800d8ff0;
    puVar3 = (undefined8 *)(arg1 + 0x18);
    if (iVar13 == 0) {
        uStackX_20 = *puVar3;
        uVar12 = 0x10;
        var_8h._0_4_ = *(uint32_t *)(arg1 + 0x20);
        iVar9 = func_0x000180459890();
        var_60h = 0x10;
        uVar17 = 0;
        uVar14 = 0x10;
        iVar13 = iVar9;
        var_18h = iVar9;
code_r0x0001800d8d10:
        do {
            uVar5 = *(undefined4 *)(arg1 + 0x1c);
            uVar6 = *(undefined4 *)(arg1 + 0x20);
            uVar7 = *(undefined4 *)(arg1 + 0x24);
            uVar10 = uVar17 + 1;
            puVar1 = (undefined4 *)(iVar9 + uVar17 * 0x10);
            *puVar1 = *(undefined4 *)puVar3;
            puVar1[1] = uVar5;
            puVar1[2] = uVar6;
            puVar1[3] = uVar7;
            uVar17 = uVar10;
        } while (uVar10 < uVar12);
    } else {
        uStackX_20 = *puVar3;
        var_8h._0_4_ = *(uint32_t *)(arg1 + 0x20);
        uVar12 = iVar13 * 2;
        if (uVar12 == 0) {
            iVar13 = 0;
            uVar14 = 0;
            var_60h = 0;
            var_18h = 0;
        } else {
            iVar9 = func_0x000180459890();
            uVar17 = 0;
            uVar14 = uVar12;
            iVar13 = iVar9;
            var_18h = iVar9;
            var_60h = uVar12;
            if (uVar12 != 0) goto code_r0x0001800d8d10;
        }
    }
    var_58h = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            piVar16 = (int64_t *)(*(int64_t *)arg1 + var_58h * 0x10);
            uVar4 = *(uint32_t *)(piVar16 + 1);
            if ((uVar4 != *(uint32_t *)(arg1 + 0x20)) ||
               (iVar8 = func_0x000180497f30(*piVar16, *puVar3), iVar13 = var_18h, iVar8 != 0)) {
                uVar11 = 0x811c9dc5;
                if ((uint64_t)uVar4 != 0) {
                    uVar12 = 0;
                    do {
                        puVar2 = (uint8_t *)(*piVar16 + uVar12);
                        uVar12 = uVar12 + 1;
                        uVar11 = (*puVar2 ^ uVar11) * 0x1000193;
                    } while (uVar12 < uVar4);
                }
                uVar12 = (uint64_t)uVar11;
                uVar17 = 0;
                while( true ) {
                    uVar12 = uVar12 & uVar14 - 1;
                    uVar11 = *(uint32_t *)(iVar13 + 8 + uVar12 * 0x10);
                    puVar15 = (undefined8 *)(iVar13 + uVar12 * 0x10);
                    if ((uVar11 == (uint32_t)var_8h) && (iVar8 = func_0x000180497f30(*puVar15, uStackX_20), iVar8 == 0))
                    {
                        uVar5 = *(undefined4 *)((int64_t)piVar16 + 4);
                        uVar6 = *(undefined4 *)(piVar16 + 1);
                        uVar7 = *(undefined4 *)((int64_t)piVar16 + 0xc);
                        *(undefined4 *)puVar15 = *(undefined4 *)piVar16;
                        *(undefined4 *)((int64_t)puVar15 + 4) = uVar5;
                        *(undefined4 *)(puVar15 + 1) = uVar6;
                        *(undefined4 *)((int64_t)puVar15 + 0xc) = uVar7;
                        goto code_r0x0001800d8e5d;
                    }
                    if ((uVar11 == uVar4) && (iVar8 = func_0x000180497f30(*puVar15, *piVar16), iVar8 == 0))
                    goto code_r0x0001800d8e5d;
                    iVar13 = uVar12 + uVar17;
                    uVar17 = uVar17 + 1;
                    if (uVar14 - 1 < uVar17) break;
                    uVar12 = iVar13 + 1;
                    iVar13 = var_18h;
                }
                puVar15 = (undefined8 *)0x0;
code_r0x0001800d8e5d:
                puVar1 = (undefined4 *)(*(int64_t *)arg1 + var_58h * 0x10);
                uVar5 = puVar1[1];
                uVar6 = puVar1[2];
                uVar7 = puVar1[3];
                *(undefined4 *)puVar15 = *puVar1;
                *(undefined4 *)((int64_t)puVar15 + 4) = uVar5;
                *(undefined4 *)(puVar15 + 1) = uVar6;
                *(undefined4 *)((int64_t)puVar15 + 0xc) = uVar7;
                uVar14 = var_60h;
            }
            var_58h = var_58h + 1;
            iVar13 = var_18h;
        } while ((uint64_t)var_58h < *(uint64_t *)(arg1 + 8));
    }
    iVar9 = *(int64_t *)arg1;
    *(uint64_t *)(arg1 + 8) = uVar14;
    *(int64_t *)arg1 = iVar13;
    if (iVar9 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800d8ff0:
    uVar4 = *(uint32_t *)(arg2 + 8);
    uVar11 = 0x811c9dc5;
    if ((uint64_t)uVar4 != 0) {
        uVar12 = 0;
        do {
            puVar2 = (uint8_t *)(*(int64_t *)arg2 + uVar12);
            uVar12 = uVar12 + 1;
            uVar11 = (*puVar2 ^ uVar11) * 0x1000193;
        } while (uVar12 < uVar4);
    }
    iVar13 = *(int64_t *)arg1;
    uVar14 = *(int64_t *)(arg1 + 8) - 1;
    uVar12 = (uint64_t)uVar11;
    uVar17 = 0;
    while( true ) {
        uVar12 = uVar12 & uVar14;
        uVar11 = *(uint32_t *)(iVar13 + 8 + uVar12 * 0x10);
        puVar3 = (undefined8 *)(iVar13 + uVar12 * 0x10);
        if ((uVar11 == *(uint32_t *)(arg1 + 0x20)) &&
           (iVar8 = func_0x000180497f30(*puVar3, *(undefined8 *)(arg1 + 0x18), uVar11), iVar8 == 0)) {
            uVar5 = *(undefined4 *)(arg2 + 4);
            uVar6 = *(undefined4 *)(arg2 + 8);
            uVar7 = *(undefined4 *)(arg2 + 0xc);
            *(undefined4 *)puVar3 = *(undefined4 *)arg2;
            *(undefined4 *)((int64_t)puVar3 + 4) = uVar5;
            *(undefined4 *)(puVar3 + 1) = uVar6;
            *(undefined4 *)((int64_t)puVar3 + 0xc) = uVar7;
            *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
            return puVar3;
        }
        if ((uVar11 == uVar4) && (iVar8 = func_0x000180497f30(*puVar3, *(undefined8 *)arg2, uVar11), iVar8 == 0)) break;
        iVar9 = uVar12 + uVar17;
        uVar17 = uVar17 + 1;
        if (uVar14 < uVar17) {
            return (undefined8 *)0x0;
        }
        iVar13 = *(int64_t *)arg1;
        uVar12 = iVar9 + 1;
    }
    return puVar3;
}

// ============================================================
// Function: FUN_1800d8ef0
// Address: 0x1800d8ef0
// Size: 244 bytes
// ============================================================
undefined8 * fcn.1800d8ef0(int64_t arg1, int64_t arg2)
{
    uint8_t *puVar1;
    undefined8 *puVar2;
    uint32_t uVar3;
    int32_t iVar4;
    uint64_t uVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    
    if (*(int64_t *)(arg1 + 0x10) != 0) {
        uVar3 = *(uint32_t *)(arg2 + 8);
        if ((uVar3 != *(uint32_t *)(arg1 + 0x20)) ||
           (iVar4 = func_0x000180497f30(*(undefined8 *)arg2, *(undefined8 *)(arg1 + 0x18), uVar3), iVar4 != 0)) {
            uVar6 = 0x811c9dc5;
            if ((uint64_t)uVar3 != 0) {
                uVar5 = 0;
                do {
                    puVar1 = (uint8_t *)(*(int64_t *)arg2 + uVar5);
                    uVar5 = uVar5 + 1;
                    uVar6 = (*puVar1 ^ uVar6) * 0x1000193;
                } while (uVar5 < uVar3);
            }
            uVar8 = *(int64_t *)(arg1 + 8) - 1;
            uVar5 = (uint64_t)uVar6;
            uVar9 = 0;
            while( true ) {
                uVar5 = uVar5 & uVar8;
                uVar6 = *(uint32_t *)(*(int64_t *)arg1 + 8 + uVar5 * 0x10);
                puVar2 = (undefined8 *)(*(int64_t *)arg1 + uVar5 * 0x10);
                if ((uVar6 == uVar3) && (iVar4 = func_0x000180497f30(*puVar2, *(undefined8 *)arg2, uVar6), iVar4 == 0))
                {
                    return puVar2;
                }
                if ((uVar6 == *(uint32_t *)(arg1 + 0x20)) &&
                   (iVar4 = func_0x000180497f30(*puVar2, *(undefined8 *)(arg1 + 0x18), uVar6), iVar4 == 0)) break;
                iVar7 = uVar5 + uVar9;
                uVar9 = uVar9 + 1;
                if (uVar8 < uVar9) {
                    return (undefined8 *)0x0;
                }
                uVar5 = iVar7 + 1;
            }
        }
    }
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_1800d8ff0
// Address: 0x1800d8ff0
// Size: 222 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

undefined8 * fcn.1800d8c20(int64_t arg1, int64_t arg2, int64_t arg_50h)
{
    undefined4 *puVar1;
    uint8_t *puVar2;
    undefined8 *puVar3;
    uint32_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    int64_t iVar13;
    uint64_t uVar14;
    undefined8 *puVar15;
    int64_t *piVar16;
    uint64_t uVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStackX_20;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar13 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar13 * 3) >> 2) || (iVar9 = fcn.1800d8ef0(arg1, arg2), iVar9 != 0))
    goto code_r0x0001800d8ff0;
    puVar3 = (undefined8 *)(arg1 + 0x18);
    if (iVar13 == 0) {
        uStackX_20 = *puVar3;
        uVar12 = 0x10;
        var_8h._0_4_ = *(uint32_t *)(arg1 + 0x20);
        iVar9 = func_0x000180459890();
        var_60h = 0x10;
        uVar17 = 0;
        uVar14 = 0x10;
        iVar13 = iVar9;
        var_18h = iVar9;
code_r0x0001800d8d10:
        do {
            uVar5 = *(undefined4 *)(arg1 + 0x1c);
            uVar6 = *(undefined4 *)(arg1 + 0x20);
            uVar7 = *(undefined4 *)(arg1 + 0x24);
            uVar10 = uVar17 + 1;
            puVar1 = (undefined4 *)(iVar9 + uVar17 * 0x10);
            *puVar1 = *(undefined4 *)puVar3;
            puVar1[1] = uVar5;
            puVar1[2] = uVar6;
            puVar1[3] = uVar7;
            uVar17 = uVar10;
        } while (uVar10 < uVar12);
    } else {
        uStackX_20 = *puVar3;
        var_8h._0_4_ = *(uint32_t *)(arg1 + 0x20);
        uVar12 = iVar13 * 2;
        if (uVar12 == 0) {
            iVar13 = 0;
            uVar14 = 0;
            var_60h = 0;
            var_18h = 0;
        } else {
            iVar9 = func_0x000180459890();
            uVar17 = 0;
            uVar14 = uVar12;
            iVar13 = iVar9;
            var_18h = iVar9;
            var_60h = uVar12;
            if (uVar12 != 0) goto code_r0x0001800d8d10;
        }
    }
    var_58h = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            piVar16 = (int64_t *)(*(int64_t *)arg1 + var_58h * 0x10);
            uVar4 = *(uint32_t *)(piVar16 + 1);
            if ((uVar4 != *(uint32_t *)(arg1 + 0x20)) ||
               (iVar8 = func_0x000180497f30(*piVar16, *puVar3), iVar13 = var_18h, iVar8 != 0)) {
                uVar11 = 0x811c9dc5;
                if ((uint64_t)uVar4 != 0) {
                    uVar12 = 0;
                    do {
                        puVar2 = (uint8_t *)(*piVar16 + uVar12);
                        uVar12 = uVar12 + 1;
                        uVar11 = (*puVar2 ^ uVar11) * 0x1000193;
                    } while (uVar12 < uVar4);
                }
                uVar12 = (uint64_t)uVar11;
                uVar17 = 0;
                while( true ) {
                    uVar12 = uVar12 & uVar14 - 1;
                    uVar11 = *(uint32_t *)(iVar13 + 8 + uVar12 * 0x10);
                    puVar15 = (undefined8 *)(iVar13 + uVar12 * 0x10);
                    if ((uVar11 == (uint32_t)var_8h) && (iVar8 = func_0x000180497f30(*puVar15, uStackX_20), iVar8 == 0))
                    {
                        uVar5 = *(undefined4 *)((int64_t)piVar16 + 4);
                        uVar6 = *(undefined4 *)(piVar16 + 1);
                        uVar7 = *(undefined4 *)((int64_t)piVar16 + 0xc);
                        *(undefined4 *)puVar15 = *(undefined4 *)piVar16;
                        *(undefined4 *)((int64_t)puVar15 + 4) = uVar5;
                        *(undefined4 *)(puVar15 + 1) = uVar6;
                        *(undefined4 *)((int64_t)puVar15 + 0xc) = uVar7;
                        goto code_r0x0001800d8e5d;
                    }
                    if ((uVar11 == uVar4) && (iVar8 = func_0x000180497f30(*puVar15, *piVar16), iVar8 == 0))
                    goto code_r0x0001800d8e5d;
                    iVar13 = uVar12 + uVar17;
                    uVar17 = uVar17 + 1;
                    if (uVar14 - 1 < uVar17) break;
                    uVar12 = iVar13 + 1;
                    iVar13 = var_18h;
                }
                puVar15 = (undefined8 *)0x0;
code_r0x0001800d8e5d:
                puVar1 = (undefined4 *)(*(int64_t *)arg1 + var_58h * 0x10);
                uVar5 = puVar1[1];
                uVar6 = puVar1[2];
                uVar7 = puVar1[3];
                *(undefined4 *)puVar15 = *puVar1;
                *(undefined4 *)((int64_t)puVar15 + 4) = uVar5;
                *(undefined4 *)(puVar15 + 1) = uVar6;
                *(undefined4 *)((int64_t)puVar15 + 0xc) = uVar7;
                uVar14 = var_60h;
            }
            var_58h = var_58h + 1;
            iVar13 = var_18h;
        } while ((uint64_t)var_58h < *(uint64_t *)(arg1 + 8));
    }
    iVar9 = *(int64_t *)arg1;
    *(uint64_t *)(arg1 + 8) = uVar14;
    *(int64_t *)arg1 = iVar13;
    if (iVar9 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800d8ff0:
    uVar4 = *(uint32_t *)(arg2 + 8);
    uVar11 = 0x811c9dc5;
    if ((uint64_t)uVar4 != 0) {
        uVar12 = 0;
        do {
            puVar2 = (uint8_t *)(*(int64_t *)arg2 + uVar12);
            uVar12 = uVar12 + 1;
            uVar11 = (*puVar2 ^ uVar11) * 0x1000193;
        } while (uVar12 < uVar4);
    }
    iVar13 = *(int64_t *)arg1;
    uVar14 = *(int64_t *)(arg1 + 8) - 1;
    uVar12 = (uint64_t)uVar11;
    uVar17 = 0;
    while( true ) {
        uVar12 = uVar12 & uVar14;
        uVar11 = *(uint32_t *)(iVar13 + 8 + uVar12 * 0x10);
        puVar3 = (undefined8 *)(iVar13 + uVar12 * 0x10);
        if ((uVar11 == *(uint32_t *)(arg1 + 0x20)) &&
           (iVar8 = func_0x000180497f30(*puVar3, *(undefined8 *)(arg1 + 0x18), uVar11), iVar8 == 0)) {
            uVar5 = *(undefined4 *)(arg2 + 4);
            uVar6 = *(undefined4 *)(arg2 + 8);
            uVar7 = *(undefined4 *)(arg2 + 0xc);
            *(undefined4 *)puVar3 = *(undefined4 *)arg2;
            *(undefined4 *)((int64_t)puVar3 + 4) = uVar5;
            *(undefined4 *)(puVar3 + 1) = uVar6;
            *(undefined4 *)((int64_t)puVar3 + 0xc) = uVar7;
            *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
            return puVar3;
        }
        if ((uVar11 == uVar4) && (iVar8 = func_0x000180497f30(*puVar3, *(undefined8 *)arg2, uVar11), iVar8 == 0)) break;
        iVar9 = uVar12 + uVar17;
        uVar17 = uVar17 + 1;
        if (uVar14 < uVar17) {
            return (undefined8 *)0x0;
        }
        iVar13 = *(int64_t *)arg1;
        uVar12 = iVar9 + 1;
    }
    return puVar3;
}

// ============================================================
// Function: FUN_1800d90e0
// Address: 0x1800d90e0
// Size: 1889 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d90e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    undefined8 uVar6;
    undefined4 *puVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    undefined (*pauVar10) [16];
    int64_t *piVar11;
    undefined4 *puVar12;
    uint64_t uVar13;
    int64_t iVar14;
    undefined4 *puVar15;
    undefined4 *puVar16;
    uint64_t uVar17;
    int64_t iVar18;
    undefined4 *puVar19;
    undefined4 *puVar20;
    undefined *puVar21;
    uint64_t uVar22;
    int32_t *piVar23;
    int64_t var_10h;
    undefined8 uStack_130;
    undefined auStack_128 [8];
    undefined auStack_120 [24];
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    undefined4 uStack_90;
    undefined4 uStack_8c;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    var_40h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_128;
    var_e8h = arg1;
    var_d0h = arg1;
    if (*(uint64_t *)(arg3 + 8) == 0) {
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    } else {
        if (*(uint64_t *)(arg3 + 8) < 2) {
            iVar18 = **(int64_t **)arg3;
            if (*(int32_t *)(iVar18 + 8) == *(int32_t *)0x180782758) {
                _var_108h = ZEXT816(0);
                var_f8h = 0;
                iVar18 = **(int64_t **)arg3;
                iVar14 = 0;
                if (*(int32_t *)(iVar18 + 8) == *(int32_t *)0x180782758) {
                    iVar14 = iVar18;
                }
                piVar23 = *(int32_t **)(iVar14 + 0x20);
                var_d0h = (int64_t)(piVar23 + *(int64_t *)(iVar14 + 0x28) * 6);
                var_d8h = (int64_t)piVar23;
                if (piVar23 != (int32_t *)var_d0h) {
                    do {
                        var_d8h = (int64_t)piVar23;
                        if (*piVar23 == 1) {
                            iVar18 = 0;
                            if (*(int32_t *)(*(int64_t *)(piVar23 + 2) + 8) == *(int32_t *)0x18078273c) {
                                iVar18 = *(int64_t *)(piVar23 + 2);
                            }
                            _var_b8h = ZEXT816(0);
                            var_a8h = 0;
                            var_a0h = 0;
                            func_0x000180004830(&var_b8h, *(undefined8 *)(iVar18 + 0x20), *(undefined8 *)(iVar18 + 0x28)
                                               );
                            uVar22 = var_a0h;
                            iVar14 = var_a8h;
                            iVar18 = var_b8h;
                            piVar11 = &var_b8h;
                            if (0xf < (uint64_t)var_a0h) {
                                piVar11 = (int64_t *)var_b8h;
                            }
                            if ((var_a8h == 3) && (iVar5 = func_0x000180497f30(piVar11, 0x180641954, 3), iVar5 == 0)) {
code_r0x0001800d92fb:
                                if (*(int32_t *)(*(int64_t *)(piVar23 + 4) + 8) != *(int32_t *)0x18078273c) {
                                    piVar11 = &var_b8h;
                                    if (0xf < uVar22) {
                                        piVar11 = (int64_t *)iVar18;
                                    }
                                    uVar6 = func_0x0001800d4c50(&var_68h, 0x1806428b0, piVar11);
                                    func_0x0001800f09e0(&var_108h, *(int64_t *)(piVar23 + 4) + 0xc, uVar6);
                                    piVar11 = &var_68h;
                                    goto code_r0x0001800d937a;
                                }
                            } else {
                                piVar11 = &var_b8h;
                                if (0xf < uVar22) {
                                    piVar11 = (int64_t *)iVar18;
                                }
                                if ((iVar14 == 6) && (iVar5 = func_0x000180497f30(piVar11, 0x180641940, 6), iVar5 == 0))
                                goto code_r0x0001800d92fb;
                                piVar11 = &var_b8h;
                                if (0xf < uVar22) {
                                    piVar11 = (int64_t *)iVar18;
                                }
                                uVar6 = func_0x0001800d4c50(&var_98h, 0x180642850, piVar11);
                                func_0x0001800f09e0(&var_108h, *(int64_t *)(piVar23 + 2) + 0xc, uVar6);
                                piVar11 = &var_98h;
code_r0x0001800d937a:
                                func_0x000180004e40(piVar11);
                                iVar18 = var_b8h;
                                uVar22 = var_a0h;
                            }
                            if (0xf < uVar22) {
                                uVar13 = uVar22 + 1;
                                iVar14 = iVar18;
                                if (0xfff < uVar13) {
                                    iVar14 = *(int64_t *)(iVar18 + -8);
                                    if (0x1f < (iVar18 - iVar14) - 8U) {
code_r0x0001800d9827:
                                        pcVar1 = (code *)swi(0x29);
                                        (*pcVar1)(5);
                                        puVar21 = auStack_120;
                                        goto code_r0x0001800d982e;
                                    }
                                    uVar13 = uVar22 + 0x28;
                                }
                                func_0x000180459c3c(iVar14, uVar13);
                            }
                        } else {
                            iVar18 = *(int64_t *)(piVar23 + 4);
                            puVar12 = (undefined4 *)var_100h;
                            if (var_100h == var_f8h) {
                                iVar14 = (var_100h - var_108h) / 6 + (var_100h - var_108h >> 0x3f);
                                iVar14 = (iVar14 >> 3) - (iVar14 >> 0x3f);
                                if (iVar14 == 0x555555555555555) {
                                    func_0x000180010010();
                                    pcVar1 = (code *)swi(3);
                                    (*pcVar1)();
                                    return;
                                }
                                uVar22 = (var_f8h - var_108h >> 4) * -0x5555555555555555;
                                uVar13 = 0x555555555555555 - (uVar22 >> 1);
                                puVar21 = auStack_128;
                                if (uVar13 <= uVar22 && uVar22 - uVar13 != 0) goto code_r0x0001800d9835;
                                var_c0h = iVar14 + 1;
                                uVar22 = (uVar22 >> 1) + uVar22;
                                uVar13 = var_c0h;
                                if ((uint64_t)var_c0h <= uVar22) {
                                    uVar13 = uVar22;
                                }
                                puVar21 = auStack_128;
                                if (0x555555555555555 < uVar13) goto code_r0x0001800d9835;
                                uVar22 = uVar13 * 0x30;
                                if (uVar22 != 0) {
                                    if (uVar22 < 0x1000) {
                                        puVar7 = (undefined4 *)func_0x000180459890(uVar22);
                                        goto code_r0x0001800d950e;
                                    }
                                    puVar21 = auStack_128;
                                    if (uVar22 + 0x27 <= uVar22) goto code_r0x0001800d9835;
                                    iVar8 = func_0x000180459890();
                                    if (iVar8 != 0) {
                                        puVar7 = (undefined4 *)(iVar8 + 0x27U & 0xffffffffffffffe0);
                                        *(int64_t *)(puVar7 + -2) = iVar8;
                                        goto code_r0x0001800d950e;
                                    }
                                    goto code_r0x0001800d9827;
                                }
                                puVar7 = (undefined4 *)0x0;
code_r0x0001800d950e:
                                puVar19 = puVar7 + iVar14 * 0xc;
                                puVar15 = puVar19 + 0xc;
                                var_68h = (int64_t)&var_108h;
                                uVar2 = *(undefined4 *)(iVar18 + 0x10);
                                uVar3 = *(undefined4 *)(iVar18 + 0x14);
                                uVar4 = *(undefined4 *)(iVar18 + 0x18);
                                *puVar19 = *(undefined4 *)(iVar18 + 0xc);
                                puVar19[1] = uVar2;
                                puVar19[2] = uVar3;
                                puVar19[3] = uVar4;
                                *(undefined (*) [16])(puVar19 + 4) = ZEXT816(0);
                                *(undefined8 *)(puVar19 + 8) = 0;
                                *(undefined8 *)(puVar19 + 10) = 0;
                                var_60h = (int64_t)puVar7;
                                var_58h = uVar13;
                                var_50h = (int64_t)puVar15;
                                var_48h = (int64_t)puVar15;
                                puVar9 = (undefined4 *)func_0x000180459890(0x50);
                                *(undefined4 **)(puVar19 + 4) = puVar9;
                                *(undefined8 *)(puVar19 + 8) = 0x4c;
                                *(undefined8 *)(puVar19 + 10) = 0x4f;
                                *puVar9 = 0x796c6e4f;
                                puVar9[1] = 0x6e6f6320;
                                puVar9[2] = 0x6e617473;
                                puVar9[3] = 0x6b207374;
                                puVar9[4] = 0x20737965;
                                puVar9[5] = 0x65737527;
                                puVar9[6] = 0x6e612027;
                                puVar9[7] = 0x72272064;
                                puVar9[8] = 0x6f736165;
                                puVar9[9] = 0x6120276e;
                                puVar9[10] = 0x61206572;
                                puVar9[0xb] = 0x776f6c6c;
                                puVar9[0xc] = 0x66206465;
                                puVar9[0xd] = 0x4020726f;
                                puVar9[0xe] = 0x72706564;
                                puVar9[0xf] = 0x74616365;
                                puVar9[0xf] = 0x74616365;
                                puVar9[0x10] = 0x61206465;
                                puVar9[0x11] = 0x69727474;
                                puVar9[0x12] = 0x65747562;
                                *(undefined *)(puVar9 + 0x13) = 0;
                                iVar18 = var_100h;
                                if (puVar12 == (undefined4 *)var_100h) {
                                    var_50h = (int64_t)puVar19;
                                    if (var_108h != var_100h) {
                                        pauVar10 = (undefined (*) [16])(puVar7 + 4);
                                        puVar12 = (undefined4 *)(var_108h + 0x10);
                                        puVar15 = puVar7;
                                        puVar9 = (undefined4 *)var_108h;
                                        do {
                                            uVar2 = puVar9[1];
                                            uVar3 = puVar9[2];
                                            uVar4 = puVar9[3];
                                            *puVar15 = *puVar9;
                                            puVar15[1] = uVar2;
                                            puVar15[2] = uVar3;
                                            puVar15[3] = uVar4;
                                            *pauVar10 = ZEXT816(0);
                                            *(undefined8 *)pauVar10[1] = 0;
                                            *(undefined8 *)(pauVar10[1] + 8) = 0;
                                            uVar2 = puVar12[1];
                                            uVar3 = puVar12[2];
                                            uVar4 = puVar12[3];
                                            *(undefined4 *)*pauVar10 = *puVar12;
                                            *(undefined4 *)(*pauVar10 + 4) = uVar2;
                                            *(undefined4 *)(*pauVar10 + 8) = uVar3;
                                            *(undefined4 *)(*pauVar10 + 0xc) = uVar4;
                                            uVar2 = puVar12[5];
                                            uVar3 = puVar12[6];
                                            uVar4 = puVar12[7];
                                            *(undefined4 *)pauVar10[1] = puVar12[4];
                                            *(undefined4 *)(pauVar10[1] + 4) = uVar2;
                                            *(undefined4 *)(pauVar10[1] + 8) = uVar3;
                                            *(undefined4 *)(pauVar10[1] + 0xc) = uVar4;
                                            *(undefined8 *)(puVar12 + 4) = 0;
                                            *(undefined8 *)(puVar12 + 6) = 0xf;
                                            *(undefined *)puVar12 = 0;
                                            puVar15 = puVar15 + 0xc;
                                            puVar9 = puVar9 + 0xc;
                                            pauVar10 = pauVar10 + 3;
                                            puVar12 = puVar12 + 0xc;
                                        } while (puVar9 != (undefined4 *)var_100h);
                                    }
                                } else {
                                    if ((undefined4 *)var_108h != puVar12) {
                                        pauVar10 = (undefined (*) [16])(puVar7 + 4);
                                        puVar9 = (undefined4 *)(var_108h + 0x10);
                                        puVar16 = puVar7;
                                        puVar20 = (undefined4 *)var_108h;
                                        do {
                                            uVar2 = puVar20[1];
                                            uVar3 = puVar20[2];
                                            uVar4 = puVar20[3];
                                            *puVar16 = *puVar20;
                                            puVar16[1] = uVar2;
                                            puVar16[2] = uVar3;
                                            puVar16[3] = uVar4;
                                            *pauVar10 = ZEXT816(0);
                                            *(undefined8 *)pauVar10[1] = 0;
                                            *(undefined8 *)(pauVar10[1] + 8) = 0;
                                            uVar2 = puVar9[1];
                                            uVar3 = puVar9[2];
                                            uVar4 = puVar9[3];
                                            *(undefined4 *)*pauVar10 = *puVar9;
                                            *(undefined4 *)(*pauVar10 + 4) = uVar2;
                                            *(undefined4 *)(*pauVar10 + 8) = uVar3;
                                            *(undefined4 *)(*pauVar10 + 0xc) = uVar4;
                                            uVar2 = puVar9[5];
                                            uVar3 = puVar9[6];
                                            uVar4 = puVar9[7];
                                            *(undefined4 *)pauVar10[1] = puVar9[4];
                                            *(undefined4 *)(pauVar10[1] + 4) = uVar2;
                                            *(undefined4 *)(pauVar10[1] + 8) = uVar3;
                                            *(undefined4 *)(pauVar10[1] + 0xc) = uVar4;
                                            *(undefined8 *)(puVar9 + 4) = 0;
                                            *(undefined8 *)(puVar9 + 6) = 0xf;
                                            *(undefined *)puVar9 = 0;
                                            puVar16 = puVar16 + 0xc;
                                            puVar20 = puVar20 + 0xc;
                                            pauVar10 = pauVar10 + 3;
                                            puVar9 = puVar9 + 0xc;
                                        } while (puVar20 != puVar12);
                                    }
                                    var_50h = (int64_t)puVar7;
                                    if (puVar12 != (undefined4 *)var_100h) {
                                        pauVar10 = (undefined (*) [16])(puVar19 + 0x10);
                                        puVar9 = (undefined4 *)((int64_t)puVar12 + 0x10);
                                        do {
                                            uVar2 = puVar12[1];
                                            uVar3 = puVar12[2];
                                            uVar4 = puVar12[3];
                                            *puVar15 = *puVar12;
                                            puVar15[1] = uVar2;
                                            puVar15[2] = uVar3;
                                            puVar15[3] = uVar4;
                                            *pauVar10 = ZEXT816(0);
                                            *(undefined8 *)pauVar10[1] = 0;
                                            *(undefined8 *)(pauVar10[1] + 8) = 0;
                                            uVar2 = puVar9[1];
                                            uVar3 = puVar9[2];
                                            uVar4 = puVar9[3];
                                            *(undefined4 *)*pauVar10 = *puVar9;
                                            *(undefined4 *)(*pauVar10 + 4) = uVar2;
                                            *(undefined4 *)(*pauVar10 + 8) = uVar3;
                                            *(undefined4 *)(*pauVar10 + 0xc) = uVar4;
                                            uVar2 = puVar9[5];
                                            uVar3 = puVar9[6];
                                            uVar4 = puVar9[7];
                                            *(undefined4 *)pauVar10[1] = puVar9[4];
                                            *(undefined4 *)(pauVar10[1] + 4) = uVar2;
                                            *(undefined4 *)(pauVar10[1] + 8) = uVar3;
                                            *(undefined4 *)(pauVar10[1] + 0xc) = uVar4;
                                            *(undefined8 *)(puVar9 + 4) = 0;
                                            *(undefined8 *)(puVar9 + 6) = 0xf;
                                            *(undefined *)puVar9 = 0;
                                            puVar15 = puVar15 + 0xc;
                                            puVar12 = puVar12 + 0xc;
                                            pauVar10 = pauVar10 + 3;
                                            puVar9 = puVar9 + 0xc;
                                        } while (puVar12 != (undefined4 *)var_100h);
                                    }
                                }
                                var_60h = 0;
                                if (var_108h == 0) {
code_r0x0001800d979d:
                                    var_100h = (int64_t)(puVar7 + var_c0h * 0xc);
                                    var_108h = (int64_t)puVar7;
                                    var_f8h = (int64_t)(puVar7 + uVar13 * 0xc);
                                    func_0x0001800f3660(&var_68h);
                                    piVar23 = (int32_t *)var_d8h;
                                    goto code_r0x0001800d97cc;
                                }
                                iVar14 = var_108h;
                                if (var_108h != var_100h) {
                                    do {
                                        uVar22 = *(uint64_t *)(iVar14 + 0x28);
                                        if (0xf < uVar22) {
                                            iVar8 = *(int64_t *)(iVar14 + 0x10);
                                            uVar17 = uVar22 + 1;
                                            if (0xfff < uVar17) {
                                                puVar21 = auStack_128;
                                                if (0x1f < (iVar8 - *(int64_t *)(iVar8 + -8)) - 8U)
                                                goto code_r0x0001800d982e;
                                                uVar17 = uVar22 + 0x28;
                                                iVar8 = *(int64_t *)(iVar8 + -8);
                                            }
                                            func_0x000180459c3c(iVar8, uVar17);
                                        }
                                        *(undefined8 *)(iVar14 + 0x20) = 0;
                                        *(undefined8 *)(iVar14 + 0x28) = 0xf;
                                        *(undefined *)(iVar14 + 0x10) = 0;
                                        iVar14 = iVar14 + 0x30;
                                    } while (iVar14 != iVar18);
                                    iVar14 = var_108h;
                                }
                                uVar22 = (var_f8h - iVar14 >> 4) * 0x10;
                                if (uVar22 < 0x1000) {
code_r0x0001800d9798:
                                    func_0x000180459c3c(iVar14, uVar22);
                                    goto code_r0x0001800d979d;
                                }
                                puVar21 = auStack_128;
                                if ((iVar14 - *(int64_t *)(iVar14 + -8)) - 8U < 0x20) {
                                    uVar22 = uVar22 + 0x27;
                                    iVar14 = *(int64_t *)(iVar14 + -8);
                                    goto code_r0x0001800d9798;
                                }
code_r0x0001800d982e:
                                pcVar1 = (code *)swi(0x29);
                                (*pcVar1)(5);
                                puVar21 = puVar21 + 8;
code_r0x0001800d9835:
                                *(undefined8 *)(puVar21 + -8) = 0x1800d983a;
                                func_0x000180004720();
                                pcVar1 = (code *)swi(3);
                                (*pcVar1)();
                                return;
                            }
                            uVar2 = *(undefined4 *)(iVar18 + 0x10);
                            uVar3 = *(undefined4 *)(iVar18 + 0x14);
                            uVar4 = *(undefined4 *)(iVar18 + 0x18);
                            *(undefined4 *)var_100h = *(undefined4 *)(iVar18 + 0xc);
                            *(undefined4 *)(var_100h + 4) = uVar2;
                            *(undefined4 *)(var_100h + 8) = uVar3;
                            *(undefined4 *)(var_100h + 0xc) = uVar4;
                            *(undefined (*) [16])(var_100h + 0x10) = ZEXT816(0);
                            *(undefined8 *)(var_100h + 0x20) = 0;
                            *(undefined8 *)(var_100h + 0x28) = 0;
                            puVar7 = (undefined4 *)func_0x000180459890(0x50);
                            *(undefined4 **)((int64_t)puVar12 + 0x10) = puVar7;
                            *(undefined8 *)((int64_t)puVar12 + 0x20) = 0x4c;
                            *(undefined8 *)((int64_t)puVar12 + 0x28) = 0x4f;
                            *puVar7 = 0x796c6e4f;
                            puVar7[1] = 0x6e6f6320;
                            puVar7[2] = 0x6e617473;
                            puVar7[3] = 0x6b207374;
                            puVar7[4] = 0x20737965;
                            puVar7[5] = 0x65737527;
                            puVar7[6] = 0x6e612027;
                            puVar7[7] = 0x72272064;
                            puVar7[8] = 0x6f736165;
                            puVar7[9] = 0x6120276e;
                            puVar7[10] = 0x61206572;
                            puVar7[0xb] = 0x776f6c6c;
                            puVar7[0xc] = 0x66206465;
                            puVar7[0xd] = 0x4020726f;
                            puVar7[0xe] = 0x72706564;
                            puVar7[0xf] = 0x74616365;
                            puVar7[0xf] = 0x74616365;
                            puVar7[0x10] = 0x61206465;
                            puVar7[0x11] = 0x69727474;
                            puVar7[0x12] = 0x65747562;
                            *(undefined *)(puVar7 + 0x13) = 0;
                            var_100h = var_100h + 0x30;
                        }
code_r0x0001800d97cc:
                        piVar23 = piVar23 + 6;
                        var_d8h = (int64_t)piVar23;
                    } while (piVar23 != (int32_t *)var_d0h);
                }
                *(int64_t *)var_e8h = var_108h;
                *(int64_t *)(var_e8h + 8) = var_100h;
                *(int64_t *)(var_e8h + 0x10) = var_f8h;
                goto code_r0x0001800d97fd;
            }
            var_98h._0_4_ = *(undefined4 *)(iVar18 + 0xc);
            var_98h._4_4_ = *(undefined4 *)(iVar18 + 0x10);
            uStack_90 = *(undefined4 *)(iVar18 + 0x14);
            uStack_8c = *(undefined4 *)(iVar18 + 0x18);
            _var_88h = ZEXT816(0);
            var_78h = 0;
            var_70h = 0;
            func_0x000180004830(&var_88h, 0x180642820, 0x25);
            var_e8h = (int64_t)&var_98h;
            var_e0h = (int64_t)&var_68h;
            func_0x0001800f2bb0(arg1, &var_e8h);
        } else {
            var_98h._0_4_ = *(undefined4 *)arg2;
            var_98h._4_4_ = *(undefined4 *)(arg2 + 4);
            uStack_90 = *(undefined4 *)(arg2 + 8);
            uStack_8c = *(undefined4 *)(arg2 + 0xc);
            _var_88h = ZEXT816(0);
            var_78h = 0;
            var_70h = 0;
            func_0x000180004830(&var_88h, 0x1806427e8, 0x32);
            var_e8h = (int64_t)&var_98h;
            var_e0h = (int64_t)&var_68h;
            func_0x0001800f2bb0(arg1, &var_e8h);
        }
        func_0x000180459d94(&var_98h, 0x30, 1, 0x1800d9850);
    }
code_r0x0001800d97fd:
    func_0x000180459870(var_40h ^ (uint64_t)auStack_128);
    return;
}

// ============================================================
// Function: FUN_1800d9860
// Address: 0x1800d9860
// Size: 51 bytes
// ============================================================
void fcn.1800d9860(int64_t arg1)
{
    int64_t *piVar1;
    
    if ((*(char *)(arg1 + 0x50) != '\0') && (piVar1 = *(int64_t **)(arg1 + 0x48), piVar1 != (int64_t *)0x0)) {
        (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)(arg1 + 0x10));
        *(undefined8 *)(arg1 + 0x48) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800d98a0
// Address: 0x1800d98a0
// Size: 50 bytes
// ============================================================
void fcn.1800d98a0(int64_t arg1)
{
    int64_t *piVar1;
    
    if ((*(char *)(arg1 + 0x40) != '\0') && (piVar1 = *(int64_t **)(arg1 + 0x38), piVar1 != (int64_t *)0x0)) {
        (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)arg1);
        *(undefined8 *)(arg1 + 0x38) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800d9940
// Address: 0x1800d9940
// Size: 89 bytes
// ============================================================
void fcn.1800d9940(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    code *pcVar1;
    undefined8 uVar2;
    int64_t iStackX_18;
    int64_t iStackX_20;
    int64_t in_stack_ffffffffffffff58;
    int64_t var_a0h;
    int64_t var_80h;
    int64_t var_58h;
    
    iStackX_18 = arg3;
    iStackX_20 = arg4;
    fcn.1800d4cb0(&var_80h, arg2, &iStackX_18);
    uVar2 = fcn.18000b4d0(&var_a0h, &var_80h);
    fcn.1800d98e0(&var_58h, arg1, uVar2);
    fcn.18045bae0(in_stack_ffffffffffffff58);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1800d99a0
// Address: 0x1800d99a0
// Size: 614 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1800d99a0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int32_t iVar11;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_558 [32];
    int64_t var_538h;
    int64_t var_530h;
    int64_t var_528h;
    int64_t var_510h;
    int64_t var_4f8h;
    int64_t var_478h;
    int64_t var_46ch;
    int64_t var_418h;
    int64_t var_410h;
    int64_t var_408h;
    int64_t var_400h;
    int64_t var_3f8h;
    int64_t var_3f0h;
    int64_t var_368h;
    int64_t var_360h;
    int64_t var_328h;
    int64_t var_320h;
    int64_t var_318h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_38h;
    int64_t var_28h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_558;
    var_510h = arg_30h;
    var_530h = arg_30h;
    var_538h = arg_28h;
    var_528h = arg1;
    func_0x0001800d9e60(&var_4f8h);
    uVar10 = func_0x0001800dae50(&var_4f8h);
    func_0x0001800ef070(&var_4f8h, var_360h - var_368h >> 3 & 0xffffffff);
    if ((int32_t)var_478h != 0) {
        func_0x0001800ef2f0(&var_4f8h, 0, 0);
    }
    iVar9 = var_318h;
    iVar8 = var_320h;
    iVar7 = var_328h;
    iVar6 = var_3f0h;
    iVar5 = var_3f8h;
    iVar4 = var_400h;
    iVar3 = var_408h;
    iVar2 = var_410h;
    iVar1 = var_418h;
    if ((arg3 == 0) || (iVar11 = 1, *(char *)(arg2 + -1 + arg3) == '\n')) {
        iVar11 = 0;
    }
    *(undefined8 *)arg1 = uVar10;
    *(uint64_t *)(arg1 + 8) = (uint64_t)(uint32_t)((int32_t)var_46ch + iVar11);
    var_3f0h = 0;
    var_3f8h = 0;
    var_400h = 0;
    *(int64_t *)(arg1 + 0x10) = iVar4;
    *(int64_t *)(arg1 + 0x18) = iVar5;
    *(int64_t *)(arg1 + 0x20) = iVar6;
    var_318h = 0;
    var_320h = 0;
    var_328h = 0;
    *(int64_t *)(arg1 + 0x28) = iVar7;
    *(int64_t *)(arg1 + 0x30) = iVar8;
    *(int64_t *)(arg1 + 0x38) = iVar9;
    var_408h = 0;
    var_410h = 0;
    var_418h = 0;
    *(int64_t *)(arg1 + 0x40) = iVar1;
    *(int64_t *)(arg1 + 0x48) = iVar2;
    *(int64_t *)(arg1 + 0x50) = iVar3;
    *(int64_t *)(arg1 + 0x58) = var_68h;
    *(int64_t *)(arg1 + 0x60) = var_60h;
    *(int64_t *)(arg1 + 0x68) = var_58h;
    *(int64_t *)(arg1 + 0x70) = var_50h;
    _var_68h = ZEXT816(0);
    var_58h = 0;
    func_0x0001800d9c10(&var_4f8h);
    if (*(char *)(arg_30h + 0x50) != '\0') {
        func_0x00018000ace0(arg_30h + 0x30);
        if (*(int64_t *)(arg_30h + 8) != 0) {
            func_0x0001800f4640();
            *(undefined8 *)(arg_30h + 8) = 0;
            *(undefined8 *)(arg_30h + 0x10) = 0;
        }
    }
    func_0x000180459870(var_38h ^ (uint64_t)auStack_558);
    return;
}

// ============================================================
// Function: FUN_1800d9c10
// Address: 0x1800d9c10
// Size: 571 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d9c10(int64_t arg1)
{
    int64_t var_8h;
    
    if (*(int64_t *)(arg1 + 0x490) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x490) = 0;
        *(undefined8 *)(arg1 + 0x498) = 0;
    }
    func_0x000180004e40(arg1 + 0x470);
    func_0x00018000ace0(arg1 + 0x458);
    func_0x00018000ace0(arg1 + 0x440);
    func_0x000180041a30(arg1 + 0x428);
    func_0x00018000ace0(arg1 + 0x410);
    func_0x00018000ace0(arg1 + 0x3f8);
    func_0x0001800f2ce0(arg1 + 0x3e0);
    func_0x0001800f2d70(arg1 + 0x3c8);
    func_0x000180028940(arg1 + 0x3b0);
    func_0x0001800f2df0(arg1 + 0x398);
    func_0x0001800bf810(arg1 + 0x380);
    func_0x00018002a260(arg1 + 0x368);
    func_0x00018000ace0(arg1 + 0x350);
    func_0x0001800bf810(arg1 + 0x338);
    func_0x0001800bf810(arg1 + 800);
    func_0x00018000ace0(arg1 + 0x308);
    func_0x0001800c1750(arg1 + 0x2f0);
    func_0x00018000ace0(arg1 + 0x2d8);
    func_0x00018000ace0(arg1 + 0x2c0);
    func_0x00018000ace0(arg1 + 0x2a8);
    func_0x00018000ace0(arg1 + 0x290);
    func_0x00018002a260(arg1 + 0x278);
    func_0x00018002a260(arg1 + 0x260);
    func_0x00018000ace0(arg1 + 0x248);
    func_0x00018000ace0(arg1 + 0x230);
    if (*(int64_t *)(arg1 + 0x200) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x200) = 0;
        *(undefined8 *)(arg1 + 0x208) = 0;
    }
    func_0x00018002ee50(arg1 + 0x1e8);
    func_0x0001800c17d0(arg1 + 0x1d0);
    if (*(int64_t *)(arg1 + 0x1a8) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x1a8) = 0;
        *(undefined8 *)(arg1 + 0x1b0) = 0;
    }
    func_0x00018000ace0(arg1 + 400);
    if (*(int64_t *)(arg1 + 0x168) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x168) = 0;
        *(undefined8 *)(arg1 + 0x170) = 0;
    }
    func_0x00018000ace0(arg1 + 0x148);
    func_0x0001800c0990(arg1 + 0xf8);
    func_0x00018007c820(arg1 + 0xe0);
    func_0x00018002ee50(arg1 + 0xc0);
    if (*(char *)(arg1 + 0x50) != '\0') {
        func_0x00018000ace0(arg1 + 0x30);
        if (*(int64_t *)(arg1 + 8) != 0) {
            func_0x0001800f4640();
            *(undefined8 *)(arg1 + 8) = 0;
            *(undefined8 *)(arg1 + 0x10) = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d9e60
// Address: 0x1800d9e60
// Size: 3944 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x0001800da5b8)
// WARNING: Removing unreachable block (ram,0x0001800da735)
// WARNING: Variable defined which should be unmapped: var_64h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable arg_31h
// WARNING: [rz-ghidra] Detected overlap for variable arg_33h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h

int64_t fcn.1800d9e60(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    uint64_t *puVar1;
    undefined (**ppauVar2) [16];
    uint8_t uVar3;
    int64_t **ppiVar4;
    int64_t iVar5;
    int64_t iVar6;
    code *pcVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    undefined *puVar10;
    int64_t **ppiVar11;
    int64_t *piVar12;
    undefined (*pauVar13) [16];
    int64_t iVar14;
    undefined8 uVar15;
    int32_t iVar16;
    uint64_t uVar17;
    undefined *puVar18;
    uint64_t uVar19;
    int64_t *piVar20;
    undefined (*pauVar21) [16];
    uint64_t uVar22;
    int64_t iVar23;
    uint64_t uVar24;
    undefined *puVar25;
    undefined (*pauVar26) [16];
    int64_t iVar27;
    uint64_t unaff_R15;
    uint64_t uVar28;
    undefined4 uVar29;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStackY_a8 [8];
    undefined auStackY_a0 [24];
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    undefined4 var_70h;
    int64_t var_6ch;
    int64_t var_64h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    puVar25 = auStackY_a8;
    func_0x0001800be4c0(arg1, arg_30h);
    iVar16 = 0;
    var_10h._0_4_ = 0;
    if (*(char *)(arg_30h + 0x50) == '\0') {
        uVar15 = 0;
    } else {
        uVar15 = *(undefined8 *)(arg_30h + 0x48);
        iVar16 = (int32_t)((uint64_t)uVar15 >> 0x20);
        var_10h._0_4_ = (undefined4)uVar15;
    }
    *(int64_t *)(arg1 + 0x60) = arg2;
    *(int64_t *)(arg1 + 0x68) = arg3;
    *(undefined4 *)(arg1 + 0x70) = 0;
    *(undefined4 *)(arg1 + 0x74) = (undefined4)var_10h;
    *(int32_t *)(arg1 + 0x78) = -iVar16;
    *(undefined4 *)(arg1 + 0x80) = 0;
    *(undefined8 *)(arg1 + 0x84) = uVar15;
    *(undefined4 *)(arg1 + 0x8c) = (undefined4)var_10h;
    *(int32_t *)(arg1 + 0x90) = iVar16;
    *(undefined4 *)(arg1 + 0x94) = 0;
    *(undefined8 *)(arg1 + 0x98) = 0;
    *(undefined8 *)(arg1 + 0xa0) = 0;
    *(undefined8 *)(arg1 + 0xa8) = 0;
    *(int64_t *)(arg1 + 0xb0) = arg4;
    *(undefined2 *)(arg1 + 0xb8) = 0x100;
    *(undefined8 *)(arg1 + 0xc0) = 0;
    *(undefined8 *)(arg1 + 200) = 0;
    *(undefined8 *)(arg1 + 0xd0) = 0;
    *(int64_t *)(arg1 + 0xd8) = arg_28h;
    *(undefined8 *)(arg1 + 0xe0) = 0;
    *(undefined8 *)(arg1 + 0xe8) = 0;
    *(undefined8 *)(arg1 + 0xf0) = 0;
    *(undefined8 *)(arg1 + 0xf8) = 0;
    *(undefined8 *)(arg1 + 0x100) = 0;
    *(undefined8 *)(arg1 + 0x108) = 0;
    *(undefined *)(arg1 + 0x110) = 1;
    *(undefined4 *)(arg1 + 0x114) = 0;
    *(undefined8 *)(arg1 + 0x118) = 0;
    *(undefined8 *)(arg1 + 0x120) = 0;
    *(undefined8 *)(arg1 + 0x128) = 0;
    *(undefined8 *)(arg1 + 0x130) = 0;
    var_80h = 0;
    *(undefined4 *)(arg1 + 0x138) = 0;
    *(undefined8 *)(arg1 + 0x13c) = 0;
    *(undefined8 *)(arg1 + 0x148) = 0;
    *(undefined8 *)(arg1 + 0x150) = 0;
    *(undefined8 *)(arg1 + 0x158) = 0;
    *(undefined8 *)(arg1 + 0x160) = 0;
    *(undefined8 *)(arg1 + 0x168) = 0;
    *(undefined8 *)(arg1 + 0x170) = 0;
    *(undefined8 *)(arg1 + 0x178) = 0;
    *(undefined8 *)(arg1 + 0x180) = 0;
    *(undefined8 *)(arg1 + 400) = 0;
    *(undefined8 *)(arg1 + 0x198) = 0;
    *(undefined8 *)(arg1 + 0x1a0) = 0;
    *(undefined8 *)(arg1 + 0x1a8) = 0;
    *(undefined8 *)(arg1 + 0x1b0) = 0;
    *(undefined8 *)(arg1 + 0x1b8) = 0;
    *(undefined8 *)(arg1 + 0x1c0) = 0;
    *(undefined8 *)(arg1 + 0x1d0) = 0;
    *(undefined8 *)(arg1 + 0x1d8) = 0;
    *(undefined8 *)(arg1 + 0x1e0) = 0;
    *(undefined8 *)(arg1 + 0x1e8) = 0;
    *(undefined8 *)(arg1 + 0x1f0) = 0;
    *(undefined8 *)(arg1 + 0x1f8) = 0;
    *(undefined8 *)(arg1 + 0x200) = 0;
    *(undefined8 *)(arg1 + 0x208) = 0;
    *(undefined8 *)(arg1 + 0x210) = 0;
    *(undefined8 *)(arg1 + 0x218) = 0;
    *(undefined *)(arg1 + 0x228) = 0;
    *(undefined8 *)(arg1 + 0x230) = 0;
    *(undefined8 *)(arg1 + 0x238) = 0;
    *(undefined8 *)(arg1 + 0x240) = 0;
    *(undefined8 *)(arg1 + 0x248) = 0;
    *(undefined8 *)(arg1 + 0x250) = 0;
    *(undefined8 *)(arg1 + 600) = 0;
    *(undefined8 *)(arg1 + 0x260) = 0;
    *(undefined8 *)(arg1 + 0x268) = 0;
    *(undefined8 *)(arg1 + 0x270) = 0;
    *(undefined8 *)(arg1 + 0x278) = 0;
    *(undefined8 *)(arg1 + 0x280) = 0;
    *(undefined8 *)(arg1 + 0x288) = 0;
    *(undefined8 *)(arg1 + 0x290) = 0;
    *(undefined8 *)(arg1 + 0x298) = 0;
    *(undefined8 *)(arg1 + 0x2a0) = 0;
    *(undefined8 *)(arg1 + 0x2a8) = 0;
    *(undefined8 *)(arg1 + 0x2b0) = 0;
    *(undefined8 *)(arg1 + 0x2b8) = 0;
    *(undefined8 *)(arg1 + 0x2c0) = 0;
    *(undefined8 *)(arg1 + 0x2c8) = 0;
    *(undefined8 *)(arg1 + 0x2d0) = 0;
    *(undefined8 *)(arg1 + 0x2d8) = 0;
    *(undefined8 *)(arg1 + 0x2e0) = 0;
    *(undefined8 *)(arg1 + 0x2e8) = 0;
    *(undefined8 *)(arg1 + 0x2f0) = 0;
    *(undefined8 *)(arg1 + 0x2f8) = 0;
    *(undefined8 *)(arg1 + 0x300) = 0;
    *(undefined8 *)(arg1 + 0x308) = 0;
    *(undefined8 *)(arg1 + 0x310) = 0;
    *(undefined8 *)(arg1 + 0x318) = 0;
    *(undefined8 *)(arg1 + 800) = 0;
    *(undefined8 *)(arg1 + 0x328) = 0;
    *(undefined8 *)(arg1 + 0x330) = 0;
    *(undefined8 *)(arg1 + 0x338) = 0;
    *(undefined8 *)(arg1 + 0x340) = 0;
    *(undefined8 *)(arg1 + 0x348) = 0;
    *(undefined8 *)(arg1 + 0x350) = 0;
    *(undefined8 *)(arg1 + 0x358) = 0;
    *(undefined8 *)(arg1 + 0x360) = 0;
    *(undefined8 *)(arg1 + 0x368) = 0;
    *(undefined8 *)(arg1 + 0x370) = 0;
    *(undefined8 *)(arg1 + 0x378) = 0;
    *(undefined8 *)(arg1 + 0x380) = 0;
    *(undefined8 *)(arg1 + 0x388) = 0;
    *(undefined8 *)(arg1 + 0x390) = 0;
    *(undefined8 *)(arg1 + 0x398) = 0;
    *(undefined8 *)(arg1 + 0x3a0) = 0;
    *(undefined8 *)(arg1 + 0x3a8) = 0;
    *(undefined8 *)(arg1 + 0x3b0) = 0;
    *(undefined8 *)(arg1 + 0x3b8) = 0;
    *(undefined8 *)(arg1 + 0x3c0) = 0;
    *(undefined8 *)(arg1 + 0x3c8) = 0;
    *(undefined8 *)(arg1 + 0x3d0) = 0;
    *(undefined8 *)(arg1 + 0x3d8) = 0;
    *(undefined8 *)(arg1 + 0x3e0) = 0;
    *(undefined8 *)(arg1 + 1000) = 0;
    *(undefined8 *)(arg1 + 0x3f0) = 0;
    *(undefined8 *)(arg1 + 0x3f8) = 0;
    *(undefined8 *)(arg1 + 0x400) = 0;
    *(undefined8 *)(arg1 + 0x408) = 0;
    *(undefined8 *)(arg1 + 0x410) = 0;
    *(undefined8 *)(arg1 + 0x418) = 0;
    *(undefined8 *)(arg1 + 0x420) = 0;
    *(undefined8 *)(arg1 + 0x428) = 0;
    *(undefined8 *)(arg1 + 0x430) = 0;
    *(undefined8 *)(arg1 + 0x438) = 0;
    *(undefined8 *)(arg1 + 0x440) = 0;
    *(undefined8 *)(arg1 + 0x448) = 0;
    *(undefined8 *)(arg1 + 0x450) = 0;
    *(undefined8 *)(arg1 + 0x458) = 0;
    *(undefined8 *)(arg1 + 0x460) = 0;
    *(undefined8 *)(arg1 + 0x468) = 0;
    *(undefined (*) [16])(arg1 + 0x470) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x480) = 0;
    *(undefined8 *)(arg1 + 0x488) = 0xf;
    *(undefined *)(arg1 + 0x470) = 0;
    *(undefined8 *)(arg1 + 0x490) = 0;
    *(undefined8 *)(arg1 + 0x498) = 0;
    *(undefined8 *)(arg1 + 0x4a0) = 0;
    *(undefined8 *)(arg1 + 0x4a8) = 0;
    puVar18 = *(undefined **)(arg1 + 0x158);
    if ((uint64_t)((int64_t)puVar18 - *(int64_t *)(arg1 + 0x148) >> 3) < 8) {
        arg3 = -*(int64_t *)(arg1 + 0x148);
        puVar10 = (undefined *)func_0x000180459890(0x40);
        func_0x000180498030(puVar10, *(int64_t *)(arg1 + 0x148), *(int64_t *)(arg1 + 0x150) - *(int64_t *)(arg1 + 0x148)
                           );
        iVar23 = *(int64_t *)(arg1 + 0x148);
        if (iVar23 == 0) {
code_r0x0001800da33e:
            *(undefined **)(arg1 + 0x148) = puVar10;
            arg3 = arg3 >> 3;
            *(undefined **)(arg1 + 0x150) = puVar10 + arg3 * 8;
            puVar18 = puVar10 + 0x40;
            *(undefined **)(arg1 + 0x158) = puVar18;
            goto code_r0x0001800da362;
        }
        uVar17 = (*(int64_t *)(arg1 + 0x158) - iVar23 >> 3) * 8;
        if (uVar17 < 0x1000) {
code_r0x0001800da333:
            func_0x000180459c3c(iVar23, uVar17);
            goto code_r0x0001800da33e;
        }
        uVar24 = (iVar23 - *(int64_t *)(iVar23 + -8)) - 8;
        uVar22 = arg_30h;
        if (uVar24 < 0x20) {
            uVar17 = uVar17 + 0x27;
            iVar23 = *(int64_t *)(iVar23 + -8);
            goto code_r0x0001800da333;
        }
code_r0x0001800dab5d:
        uVar17 = 5;
        pcVar7 = (code *)swi(0x29);
        (*pcVar7)(5);
        puVar25 = auStackY_a0;
code_r0x0001800dab67:
        *(undefined8 *)(puVar25 + -8) = 0x1800dab72;
        func_0x000180459c3c(uVar24, uVar17);
    } else {
code_r0x0001800da362:
        uVar17 = 0;
        puVar10 = *(undefined **)(arg1 + 0x150);
        if (puVar10 == puVar18) {
            iVar23 = (int64_t)puVar10 - *(int64_t *)(arg1 + 0x148) >> 3;
            if (iVar23 == 0x1fffffffffffffff) {
                func_0x000180010010();
code_r0x0001800dadc2:
                func_0x000180004720();
                pcVar7 = (code *)swi(3);
                iVar23 = (*pcVar7)();
                return iVar23;
            }
            uVar19 = (int64_t)puVar18 - *(int64_t *)(arg1 + 0x148) >> 3;
            uVar24 = uVar19 >> 1;
            if (0x1fffffffffffffff - uVar24 < uVar19) goto code_r0x0001800dadc2;
            uVar22 = iVar23 + 1;
            uVar28 = uVar22;
            if (uVar22 <= uVar24 + uVar19) {
                uVar28 = uVar24 + uVar19;
            }
            if (0x1fffffffffffffff < uVar28) goto code_r0x0001800dadc2;
            unaff_R15 = uVar28 * 8;
            if (unaff_R15 != 0) {
                if (unaff_R15 < 0x1000) {
                    uVar17 = func_0x000180459890(unaff_R15);
                } else {
                    if (unaff_R15 + 0x27 <= unaff_R15) goto code_r0x0001800dadc2;
                    iVar27 = func_0x000180459890();
                    if (iVar27 == 0) goto code_r0x0001800dab5d;
                    uVar17 = iVar27 + 0x27U & 0xffffffffffffffe0;
                    *(int64_t *)(uVar17 - 8) = iVar27;
                }
            }
            *(undefined *)(uVar17 + iVar23 * 8) = 1;
            *(undefined2 *)(uVar17 + 1 + iVar23 * 8) = arg_30h._1_2_;
            *(undefined *)(uVar17 + 3 + iVar23 * 8) = arg_30h._3_1_;
            *(undefined4 *)(uVar17 + 4 + iVar23 * 8) = 0;
            puVar18 = *(undefined **)(arg1 + 0x148);
            if (puVar10 == *(undefined **)(arg1 + 0x150)) {
                iVar27 = (int64_t)*(undefined **)(arg1 + 0x150) - (int64_t)puVar18;
                uVar24 = uVar17;
            } else {
                func_0x000180498030(uVar17, puVar18, (int64_t)puVar10 - (int64_t)puVar18);
                iVar27 = *(int64_t *)(arg1 + 0x150) - (int64_t)puVar10;
                uVar24 = uVar17 + (iVar23 + 1) * 8;
                puVar18 = puVar10;
            }
            func_0x000180498030(uVar24, puVar18, iVar27);
            iVar23 = *(int64_t *)(arg1 + 0x148);
            if (iVar23 != 0) {
                uVar24 = (*(int64_t *)(arg1 + 0x158) - iVar23 >> 3) * 8;
                if (0xfff < uVar24) {
                    arg3 = uVar17;
                    if (0x1f < (iVar23 - *(int64_t *)(iVar23 + -8)) - 8U) goto code_r0x0001800dab5d;
                    uVar24 = uVar24 + 0x27;
                    iVar23 = *(int64_t *)(iVar23 + -8);
                }
                func_0x000180459c3c(iVar23, uVar24);
            }
            *(uint64_t *)(arg1 + 0x148) = uVar17;
            *(uint64_t *)(arg1 + 0x150) = uVar17 + uVar22 * 8;
            *(uint64_t *)(arg1 + 0x158) = unaff_R15 + uVar17;
        } else {
            *puVar10 = 1;
            *(undefined2 *)(puVar10 + 1) = arg_30h._1_2_;
            puVar10[3] = arg_30h._3_1_;
            *(undefined4 *)(puVar10 + 4) = 0;
            *(int64_t *)(arg1 + 0x150) = *(int64_t *)(arg1 + 0x150) + 8;
        }
        var_80h = 0x18063ca00;
        var_78h = 4;
        ppiVar11 = (int64_t **)fcn.1800d8c20(arg4, (int64_t)&var_80h, stack0xffffffffffffffa0);
        if (*(int32_t *)((int64_t)ppiVar11 + 0xc) == 0) {
            ppiVar4 = *(int64_t ***)(arg4 + 0x30);
            iVar23 = (int64_t)*ppiVar4;
            if (iVar23 == 0) {
code_r0x0001800da578:
                piVar20 = (int64_t *)func_0x000180459890(0x2008);
                *piVar20 = (int64_t)*ppiVar4;
                *ppiVar4 = piVar20;
                piVar20 = piVar20 + 1;
                piVar12 = (int64_t *)0x5;
            } else {
                piVar20 = (int64_t *)((int64_t)ppiVar4[1] + iVar23 + 0xf & 0xfffffffffffffff8);
                if (iVar23 + 0x2008U < (int64_t)piVar20 + 5U) goto code_r0x0001800da578;
                piVar12 = (int64_t *)((int64_t)piVar20 + (5 - (iVar23 + 8)));
            }
            ppiVar4[1] = piVar12;
            *(undefined4 *)piVar20 = 0x666c6573;
            *(undefined *)((int64_t)piVar20 + 4) = 0;
            *ppiVar11 = piVar20;
            *(undefined4 *)((int64_t)ppiVar11 + 0xc) = 0x119;
        } else {
            piVar20 = *ppiVar11;
        }
        *(int64_t **)(arg1 + 0x118) = piVar20;
        var_80h = 0x18063e2d0;
        var_78h = 6;
        ppiVar11 = (int64_t **)fcn.1800d8c20(arg4, (int64_t)&var_80h, stack0xffffffffffffffa0);
        if (*(int32_t *)((int64_t)ppiVar11 + 0xc) == 0) {
            ppiVar4 = *(int64_t ***)(arg4 + 0x30);
            iVar23 = (int64_t)*ppiVar4;
            if (iVar23 == 0) {
code_r0x0001800da62e:
                piVar20 = (int64_t *)func_0x000180459890(0x2008);
                *piVar20 = (int64_t)*ppiVar4;
                *ppiVar4 = piVar20;
                piVar20 = piVar20 + 1;
                piVar12 = (int64_t *)0x7;
            } else {
                piVar20 = (int64_t *)((int64_t)ppiVar4[1] + iVar23 + 0xf & 0xfffffffffffffff8);
                if (iVar23 + 0x2008U < (int64_t)piVar20 + 7U) goto code_r0x0001800da62e;
                piVar12 = (int64_t *)((int64_t)piVar20 + (7 - (iVar23 + 8)));
            }
            ppiVar4[1] = piVar12;
            *(undefined4 *)piVar20 = 0x626d756e;
            *(undefined2 *)((int64_t)piVar20 + 4) = 0x7265;
            *(undefined *)((int64_t)piVar20 + 6) = 0;
            *ppiVar11 = piVar20;
            *(undefined4 *)((int64_t)ppiVar11 + 0xc) = 0x119;
        } else {
            piVar20 = *ppiVar11;
        }
        *(int64_t **)(arg1 + 0x120) = piVar20;
        var_80h = 0x1806425b0;
        var_78h = 10;
        ppiVar11 = (int64_t **)fcn.1800d8c20(arg4, (int64_t)&var_80h, stack0xffffffffffffffa0);
        if (*(int32_t *)((int64_t)ppiVar11 + 0xc) == 0) {
            ppiVar4 = *(int64_t ***)(arg4 + 0x30);
            iVar23 = (int64_t)*ppiVar4;
            if (iVar23 == 0) {
code_r0x0001800da6e6:
                piVar20 = (int64_t *)func_0x000180459890(0x2008);
                *piVar20 = (int64_t)*ppiVar4;
                *ppiVar4 = piVar20;
                piVar20 = piVar20 + 1;
                piVar12 = (int64_t *)0xb;
            } else {
                piVar20 = (int64_t *)((int64_t)ppiVar4[1] + iVar23 + 0xf & 0xfffffffffffffff8);
                if (iVar23 + 0x2008U < (int64_t)piVar20 + 0xbU) goto code_r0x0001800da6e6;
                piVar12 = (int64_t *)((int64_t)piVar20 + (0xb - (iVar23 + 8)));
            }
            ppiVar4[1] = piVar12;
            *piVar20 = 0x692d726f72726525;
            *(undefined2 *)(piVar20 + 1) = 0x2564;
            *(undefined *)((int64_t)piVar20 + 10) = 0;
            *ppiVar11 = piVar20;
            *(undefined4 *)((int64_t)ppiVar11 + 0xc) = 0x119;
        } else {
            piVar20 = *ppiVar11;
        }
        *(int64_t **)(arg1 + 0x128) = piVar20;
        var_80h = 0x18063da4c;
        var_78h = 3;
        ppiVar11 = (int64_t **)fcn.1800d8c20(arg4, (int64_t)&var_80h, stack0xffffffffffffffa0);
        if (*(int32_t *)((int64_t)ppiVar11 + 0xc) == 0) {
            ppiVar4 = *(int64_t ***)(arg4 + 0x30);
            iVar23 = (int64_t)*ppiVar4;
            if (iVar23 == 0) {
code_r0x0001800da7aa:
                piVar20 = (int64_t *)func_0x000180459890(0x2008);
                *piVar20 = (int64_t)*ppiVar4;
                *ppiVar4 = piVar20;
                piVar20 = piVar20 + 1;
                piVar12 = (int64_t *)0x4;
            } else {
                piVar20 = (int64_t *)((int64_t)ppiVar4[1] + iVar23 + 0xf & 0xfffffffffffffff8);
                if ((undefined2 *)(iVar23 + 0x2008) < (undefined2 *)((int64_t)piVar20 + 4)) goto code_r0x0001800da7aa;
                piVar12 = (int64_t *)((int64_t)piVar20 + (4 - (iVar23 + 8)));
            }
            ppiVar4[1] = piVar12;
            *(undefined2 *)piVar20 = 0x696e;
            *(undefined *)((int64_t)piVar20 + 2) = 0x6c;
            *(undefined *)((int64_t)piVar20 + 3) = 0;
            *ppiVar11 = piVar20;
            *(undefined4 *)((int64_t)ppiVar11 + 0xc) = 0x119;
        } else {
            piVar20 = *ppiVar11;
        }
        *(int64_t **)(arg1 + 0x130) = piVar20;
        ppauVar2 = (undefined (**) [16])(arg1 + 0x1e8);
        unaff_R15 = 0;
        uVar8 = 0;
        var_88h._0_4_ = 0;
        pauVar21 = *ppauVar2;
        uVar17 = *(int64_t *)(arg1 + 0x1f8) - (int64_t)pauVar21 >> 2;
        arg3 = 0x138;
        if (uVar17 < 0x138) {
            puVar10 = (undefined *)0x3fffffffffffffff;
            if ((uVar17 <= 0x3fffffffffffffff - (uVar17 >> 1)) &&
               (puVar10 = (undefined *)((uVar17 >> 1) + uVar17), puVar10 < (undefined *)0x138)) {
                puVar10 = (undefined *)0x138;
            }
            if (pauVar21 != (undefined (*) [16])0x0) {
                uVar24 = (*(int64_t *)(arg1 + 0x1f8) - (int64_t)pauVar21 >> 2) * 4;
                if (0xfff < uVar24) {
                    uVar22 = arg_30h;
                    if ((undefined *)0x1f <
                        (undefined *)((int64_t)pauVar21 + (-8 - (int64_t)*(undefined (**) [16])(pauVar21[-1] + 8))))
                    goto code_r0x0001800dab5d;
                    uVar24 = uVar24 + 0x27;
                    pauVar21 = *(undefined (**) [16])(pauVar21[-1] + 8);
                }
                func_0x000180459c3c(pauVar21, uVar24);
                *ppauVar2 = (undefined (*) [16])0x0;
                *(undefined8 *)(arg1 + 0x1f0) = 0;
                *(undefined8 *)(arg1 + 0x1f8) = 0;
            }
            func_0x000180030a80(ppauVar2, puVar10);
            pauVar26 = *ppauVar2;
            var_70h = 0;
            uVar17 = unaff_R15;
            do {
                uVar22 = uVar17 + 1;
                if (*(uint8_t *)((int64_t)&var_88h + uVar17) != *(uint8_t *)((int64_t)&var_70h + uVar17)) {
                    uVar8 = -(uint32_t)
                             (*(uint8_t *)((int64_t)&var_88h + uVar17) < *(uint8_t *)((int64_t)&var_70h + uVar17)) | 1;
                    break;
                }
                uVar17 = uVar22;
            } while (uVar22 != 4);
            if (uVar8 == 0) {
                func_0x0001804986e0(pauVar26, 0, 0x4e0);
                pauVar26 = pauVar26 + 0x4e;
            } else {
                iVar23 = 9;
                pauVar21 = pauVar26;
                do {
                    pauVar13 = pauVar21;
                    *pauVar13 = ZEXT816(0);
                    pauVar13[1] = ZEXT816(0);
                    pauVar13[2] = ZEXT816(0);
                    pauVar13[3] = ZEXT816(0);
                    pauVar13[4] = ZEXT816(0);
                    pauVar13[5] = ZEXT816(0);
                    pauVar13[6] = ZEXT816(0);
                    pauVar13[7] = ZEXT816(0);
                    iVar23 = iVar23 + -1;
                    pauVar21 = pauVar13 + 8;
                } while (iVar23 != 0);
                pauVar13[8] = ZEXT816(0);
                pauVar13[9] = ZEXT816(0);
                pauVar13[10] = ZEXT816(0);
                pauVar13[0xb] = ZEXT816(0);
                pauVar13[0xc] = ZEXT816(0);
                pauVar13[0xd] = ZEXT816(0);
                do {
                    pauVar26 = (undefined (*) [16])(*pauVar26 + 4);
                    arg3 = arg3 - 1;
                } while (arg3 != 0);
            }
        } else {
            iVar23 = (int64_t)*(undefined (**) [16])(arg1 + 0x1f0) - (int64_t)pauVar21;
            uVar17 = iVar23 >> 2;
            if (uVar17 < 0x138) {
                var_6ch._0_4_ = 0;
                uVar22 = unaff_R15;
                do {
                    uVar24 = uVar22 + 1;
                    uVar8 = 0;
                    if (*(uint8_t *)((int64_t)&var_88h + uVar22) != *(uint8_t *)((int64_t)&var_6ch + uVar22)) {
                        uVar9 = -(uint32_t)
                                 (*(uint8_t *)((int64_t)&var_88h + uVar22) < *(uint8_t *)((int64_t)&var_6ch + uVar22)) |
                                1;
                        break;
                    }
                    uVar22 = uVar24;
                    uVar9 = uVar8;
                } while (uVar24 != 4);
                if (uVar9 == 0) {
                    iVar23 = uVar17 * 4;
code_r0x0001800da9c5:
                    func_0x0001804986e0(pauVar21, 0, iVar23);
                } else {
                    uVar22 = iVar23 + 3U >> 2;
                    if (*(undefined (**) [16])(arg1 + 0x1f0) < pauVar21) {
                        uVar22 = unaff_R15;
                    }
                    if (uVar22 != 0) {
                        iVar23 = uVar22 << 2;
                        goto code_r0x0001800da9c5;
                    }
                }
                iVar23 = 0x138 - uVar17;
                pauVar26 = *(undefined (**) [16])(arg1 + 0x1f0);
                var_6ch._4_4_ = 0;
                uVar17 = unaff_R15;
                do {
                    uVar22 = uVar17 + 1;
                    uVar3 = *(uint8_t *)((int64_t)&var_6ch + uVar17 + 4);
                    if (*(uint8_t *)((int64_t)&var_88h + uVar17) != uVar3) {
                        uVar8 = -(uint32_t)(*(uint8_t *)((int64_t)&var_88h + uVar17) < uVar3) | 1;
                        break;
                    }
                    uVar17 = uVar22;
                } while (uVar22 != 4);
                if (uVar8 == 0) {
                    func_0x0001804986e0(pauVar26, 0, iVar23 * 4);
                    pauVar26 = (undefined (*) [16])((int64_t)pauVar26 + iVar23 * 4);
                } else if (iVar23 != 0) {
                    func_0x0001804986e0(pauVar26, 0, iVar23 * 4);
                    do {
                        pauVar26 = (undefined (*) [16])(*pauVar26 + 4);
                        iVar23 = iVar23 + -1;
                    } while (iVar23 != 0);
                }
            } else {
                pauVar26 = pauVar21 + 0x4e;
                var_64h._0_4_ = 0;
                uVar17 = unaff_R15;
                do {
                    uVar22 = uVar17 + 1;
                    if (*(uint8_t *)((int64_t)&var_88h + uVar17) != *(uint8_t *)((int64_t)&var_64h + uVar17)) {
                        uVar8 = -(uint32_t)
                                 (*(uint8_t *)((int64_t)&var_88h + uVar17) < *(uint8_t *)((int64_t)&var_64h + uVar17)) |
                                1;
                        break;
                    }
                    uVar17 = uVar22;
                } while (uVar22 != 4);
                if ((uVar8 == 0) || (pauVar21 <= pauVar26)) {
                    func_0x0001804986e0(pauVar21, 0, 0x4e0);
                }
            }
        }
        *(undefined (**) [16])(arg1 + 0x1f0) = pauVar26;
        **(undefined4 **)(arg1 + 0x1e8) = 1;
        *(undefined *)(arg1 + 0xb8) = 1;
        func_0x0001800f0350(arg1);
        *(undefined *)(arg1 + 0x110) = 0;
        puVar18 = auStackY_a8;
        uVar22 = arg_30h;
        if (0xf < (uint64_t)(*(int64_t *)(arg1 + 0x1a0) - *(int64_t *)(arg1 + 400) >> 3)) goto code_r0x0001800dab96;
        arg3 = *(int64_t *)(arg1 + 0x198) - *(int64_t *)(arg1 + 400);
        puVar10 = (undefined *)func_0x000180459890(0x80);
        func_0x000180498030(puVar10, *(int64_t *)(arg1 + 400), *(int64_t *)(arg1 + 0x198) - *(int64_t *)(arg1 + 400));
        uVar24 = *(uint64_t *)(arg1 + 400);
        if (uVar24 != 0) {
            uVar17 = ((int64_t)(*(int64_t *)(arg1 + 0x1a0) - uVar24) >> 3) * 8;
            puVar25 = auStackY_a8;
            if (0xfff < uVar17) {
                puVar1 = (uint64_t *)(uVar24 - 8);
                uVar24 = (uVar24 - *puVar1) - 8;
                if (0x1f < uVar24) goto code_r0x0001800dab5d;
                uVar17 = uVar17 + 0x27;
                uVar24 = *puVar1;
                puVar25 = auStackY_a8;
            }
            goto code_r0x0001800dab67;
        }
    }
    *(undefined **)(arg1 + 400) = puVar10;
    *(undefined **)(arg1 + 0x198) = puVar10 + (arg3 >> 3) * 8;
    *(undefined **)(arg1 + 0x1a0) = puVar10 + 0x80;
    puVar18 = puVar25;
code_r0x0001800dab96:
    iVar23 = *(int64_t *)(arg1 + 0x248);
    if ((uint64_t)(*(int64_t *)(arg1 + 600) - iVar23 >> 3) < 0x10) {
        iVar27 = *(int64_t *)(arg1 + 0x250);
        *(undefined8 *)(puVar18 + -8) = 0x1800dabc9;
        iVar14 = func_0x000180459890(0x80);
        iVar5 = *(int64_t *)(arg1 + 0x248);
        iVar6 = *(int64_t *)(arg1 + 0x250);
        *(undefined8 *)(puVar18 + -8) = 0x1800dabe5;
        uVar29 = func_0x000180498030(iVar14, iVar5, iVar6 - iVar5);
        iVar5 = *(int64_t *)(arg1 + 0x248);
        if (iVar5 != 0) {
            iVar6 = *(int64_t *)(arg1 + 600);
            *(undefined8 *)(puVar18 + -8) = 0x1800dac04;
            func_0x0001800c21a0(uVar29, iVar5, iVar6 - iVar5 >> 3);
        }
        *(int64_t *)(arg1 + 0x248) = iVar14;
        *(int64_t *)(arg1 + 0x250) = iVar14 + (iVar27 - iVar23 >> 3) * 8;
        *(int64_t *)(arg1 + 600) = iVar14 + 0x80;
    }
    iVar23 = *(int64_t *)(arg1 + 0x290);
    if ((uint64_t)(*(int64_t *)(arg1 + 0x2a0) - iVar23 >> 3) < 0x10) {
        iVar27 = *(int64_t *)(arg1 + 0x298);
        *(undefined8 *)(puVar18 + -8) = 0x1800dac57;
        iVar14 = func_0x000180459890(0x80);
        iVar5 = *(int64_t *)(arg1 + 0x290);
        iVar6 = *(int64_t *)(arg1 + 0x298);
        *(undefined8 *)(puVar18 + -8) = 0x1800dac73;
        uVar29 = func_0x000180498030(iVar14, iVar5, iVar6 - iVar5);
        iVar5 = *(int64_t *)(arg1 + 0x290);
        if (iVar5 != 0) {
            iVar6 = *(int64_t *)(arg1 + 0x2a0);
            *(undefined8 *)(puVar18 + -8) = 0x1800dac92;
            func_0x0001800c21a0(uVar29, iVar5, iVar6 - iVar5 >> 3);
        }
        *(int64_t *)(arg1 + 0x290) = iVar14;
        *(int64_t *)(arg1 + 0x298) = iVar14 + (iVar27 - iVar23 >> 3) * 8;
        *(int64_t *)(arg1 + 0x2a0) = iVar14 + 0x80;
    }
    *(undefined8 *)(puVar18 + -8) = 0x1800dacbe;
    func_0x0001800c0de0(arg1 + 0x308);
    piVar20 = (int64_t *)(arg1 + 0x2f0);
    iVar23 = *piVar20;
    if ((uint64_t)((*(int64_t *)(arg1 + 0x300) - iVar23 >> 4) * -0x5555555555555555) < 0x10) {
        iVar27 = *(int64_t *)(arg1 + 0x2f8);
        *(undefined8 *)(puVar18 + -8) = 0x1800dad00;
        uVar15 = func_0x000180459890(0x300);
        iVar5 = *piVar20;
        iVar6 = *(int64_t *)(arg1 + 0x2f8);
        *(undefined8 *)(puVar18 + -8) = 0x1800dad15;
        func_0x000180498030(uVar15, iVar5, iVar6 - iVar5);
        *(undefined8 *)(puVar18 + -8) = 0x1800dad29;
        func_0x0001800f3380(piVar20, uVar15, (iVar27 - iVar23 >> 4) * -0x5555555555555555, 0x10);
    }
    if (*(char *)(uVar22 + 0x50) != (char)unaff_R15) {
        piVar20 = (int64_t *)(arg1 + 0x168);
        if (piVar20 != (int64_t *)(uVar22 + 8)) {
            *(undefined8 *)(puVar18 + -8) = 0x1800dad4a;
            func_0x0001800c2610((int64_t)&var_64h + 4);
            if (piVar20 == (int64_t *)((int64_t)&var_64h + 4)) {
                if (stack0xffffffffffffffa0 != 0) {
                    *(undefined8 *)(puVar18 + -8) = 0x1800dad8f;
                    func_0x0001800f4640();
                }
            } else {
                if (*piVar20 != 0) {
                    *(undefined8 *)(puVar18 + -8) = 0x1800dad60;
                    func_0x0001800f4640();
                }
                *piVar20 = stack0xffffffffffffffa0;
                *(int64_t *)(arg1 + 0x170) = var_58h;
                *(int64_t *)(arg1 + 0x178) = var_50h;
                *(int64_t *)(arg1 + 0x180) = var_48h;
            }
        }
        *(undefined8 *)(puVar18 + -8) = 0x1800dada0;
        func_0x0001800c0fd0(arg1 + 400, uVar22 + 0x30);
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800dadd0
// Address: 0x1800dadd0
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_478h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_398h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_358h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_348h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_338h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_278h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_280h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_268h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_34h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_258h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_248h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_250h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_124h
// WARNING: [rz-ghidra] Removing arg arg_2a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_154h
// WARNING: [rz-ghidra] Removing arg arg_2d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_328h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_310h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_428h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_318h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_144h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_408h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_418h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_13ch
// WARNING: [rz-ghidra] Removing arg arg_2b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_458h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_228h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_230h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_238h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_240h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_468h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_438h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_218h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_220h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_450h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_448h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_388h because it doesn't fit into ProtoModel

undefined8 fcn.1800dadd0(int64_t arg1)
{
    undefined8 uVar1;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_10h;
    int64_t in_stack_00000020;
    int64_t in_stack_00000028;
    int64_t in_stack_00000030;
    int64_t in_stack_00000040;
    int64_t in_stack_00000050;
    int64_t in_stack_00000058;
    int64_t in_stack_00000060;
    int64_t in_stack_00000068;
    int64_t in_stack_00000070;
    int64_t in_stack_00000078;
    int64_t in_stack_00000080;
    int64_t in_stack_00000088;
    int64_t in_stack_00000090;
    int64_t in_stack_00000098;
    int64_t in_stack_000000a0;
    int64_t in_stack_000000a8;
    int64_t in_stack_000000b0;
    int64_t in_stack_000000b8;
    int64_t in_stack_000000c0;
    int64_t in_stack_000000c8;
    int64_t in_stack_000000d0;
    int64_t in_stack_000000d8;
    int64_t in_stack_000000e0;
    int64_t in_stack_000000e8;
    int64_t in_stack_000000f0;
    int64_t in_stack_00000100;
    int64_t in_stack_00000118;
    int64_t in_stack_00000130;
    int64_t in_stack_00000138;
    int64_t in_stack_00000140;
    int64_t in_stack_00000148;
    int64_t in_stack_00000150;
    int64_t in_stack_00000158;
    int64_t in_stack_00000168;
    int64_t in_stack_00000170;
    int64_t in_stack_00000178;
    int64_t in_stack_00000180;
    int64_t in_stack_00000188;
    int64_t in_stack_00000190;
    int64_t in_stack_00000198;
    int64_t in_stack_000001a0;
    int64_t in_stack_000001a8;
    int64_t in_stack_000001b0;
    int64_t in_stack_000001b8;
    int64_t in_stack_000001c0;
    int64_t in_stack_000001c8;
    int64_t in_stack_000001d0;
    int64_t in_stack_000001d8;
    int64_t in_stack_000001e0;
    
    uVar1 = fcn.1800dae50(unaff_retaddr, in_stack_00000020, in_stack_00000028, in_stack_00000030, in_stack_00000040, 
                          in_stack_00000050, in_stack_00000058, in_stack_00000060, in_stack_00000068, in_stack_00000070
                          , in_stack_00000078, in_stack_00000080, in_stack_00000088, in_stack_00000090, 
                          in_stack_00000098, in_stack_000000a0, in_stack_000000a8, in_stack_000000b0, in_stack_000000b8
                          , in_stack_000000c0, in_stack_000000c8, in_stack_000000d0, in_stack_000000d8, 
                          in_stack_000000e0, in_stack_000000e8, in_stack_000000f0, in_stack_00000100, in_stack_00000118
                          , in_stack_00000130, in_stack_00000138, in_stack_00000140, in_stack_00000148, 
                          in_stack_00000150, in_stack_00000158, in_stack_00000168, in_stack_00000170, in_stack_00000178
                          , in_stack_00000180, in_stack_00000188, in_stack_00000190, in_stack_00000198, 
                          in_stack_000001a0, in_stack_000001a8, in_stack_000001b0, in_stack_000001b8, in_stack_000001c0
                          , in_stack_000001c8, in_stack_000001d0, in_stack_000001d8, in_stack_000001e0);
    fcn.1800ef070(in_stack_00000050);
    return uVar1;
}

// ============================================================
// Function: FUN_1800dae50
// Address: 0x1800dae50
// Size: 12024 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_5c0h
// WARNING: Variable defined which should be unmapped: var_5a0h
// WARNING: Variable defined which should be unmapped: var_598h
// WARNING: Variable defined which should be unmapped: var_580h
// WARNING: Variable defined which should be unmapped: var_570h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: [rz-ghidra] Removing arg arg_478h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_398h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_358h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_348h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_338h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_278h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_280h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_268h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_34h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_258h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_248h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_250h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_124h
// WARNING: [rz-ghidra] Removing arg arg_2a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_154h
// WARNING: [rz-ghidra] Removing arg arg_2d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_328h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_310h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_428h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_318h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_144h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_408h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_418h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_13ch
// WARNING: [rz-ghidra] Removing arg arg_2b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_458h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_228h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_230h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_238h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_240h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_468h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_438h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_218h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_220h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_450h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_448h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_388h because it doesn't fit into ProtoModel

void fcn.1800dae50(int64_t arg1, int64_t arg_30h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_70h,
                  int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h,
                  int64_t arg_b0h, int64_t arg_b8h, int64_t arg_c0h, int64_t arg_c8h, int64_t arg_d0h, int64_t arg_d8h,
                  int64_t arg_e0h, int64_t arg_e8h, int64_t arg_f0h, int64_t arg_f8h, int64_t arg_100h, int64_t arg_108h
                  , int64_t arg_110h, int64_t arg_118h, int64_t arg_120h, int64_t arg_130h, int64_t arg_148h,
                  int64_t arg_160h, int64_t arg_168h, int64_t arg_170h, int64_t arg_178h, int64_t arg_180h,
                  int64_t arg_188h, int64_t arg_198h, int64_t arg_1a0h, int64_t arg_1a8h, int64_t arg_1b0h,
                  int64_t arg_1b8h, int64_t arg_1c0h, int64_t arg_1c8h, int64_t arg_1d0h, int64_t arg_1d8h,
                  int64_t arg_1e0h, int64_t arg_1e8h, int64_t arg_1f0h, int64_t arg_1f8h, int64_t arg_200h,
                  int64_t arg_208h, int64_t arg_210h)
{
    int32_t *piVar1;
    uint64_t uVar2;
    undefined auVar3 [16];
    code *pcVar4;
    undefined auVar5 [16];
    undefined auVar6 [16];
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined auVar10 [12];
    undefined uVar11;
    undefined uVar12;
    char cVar13;
    uint32_t uVar14;
    int32_t iVar15;
    uint64_t uVar16;
    int64_t **ppiVar17;
    int64_t *piVar18;
    undefined4 *puVar19;
    undefined8 *puVar20;
    undefined8 uVar21;
    int64_t *piVar22;
    int64_t *piVar23;
    int64_t iVar24;
    undefined8 uVar25;
    uint64_t uVar26;
    int64_t **ppiVar27;
    int64_t **ppiVar28;
    uint64_t uVar29;
    int64_t iVar30;
    int64_t **ppiVar31;
    int64_t iVar32;
    undefined *puVar33;
    int64_t **ppiVar34;
    undefined *puVar35;
    int64_t iVar36;
    int64_t **in_R9;
    int64_t **ppiVar37;
    undefined4 uVar38;
    undefined4 uVar39;
    int32_t iVar40;
    int64_t var_10h;
    int64_t var_24h;
    undefined auStackY_5e8 [8];
    undefined auStackY_5e0 [24];
    int64_t var_5c8h;
    int64_t var_5c0h;
    int64_t var_5b8h;
    int64_t var_5b0h;
    int64_t var_5a8h;
    int64_t var_5a0h;
    int64_t var_598h;
    int64_t in_stack_fffffffffffffa70;
    int64_t var_588h;
    int64_t var_580h;
    int64_t var_578h;
    int64_t var_570h;
    undefined4 in_stack_fffffffffffffa98;
    undefined4 in_stack_fffffffffffffa9c;
    int64_t **in_stack_fffffffffffffaa0;
    int64_t **in_stack_fffffffffffffaa8;
    undefined in_stack_fffffffffffffab0 [16];
    int64_t **in_stack_fffffffffffffac0;
    int64_t **in_stack_fffffffffffffac8;
    int64_t **ppiVar41;
    int64_t **in_stack_fffffffffffffad0;
    int64_t **in_stack_fffffffffffffad8;
    int64_t *in_stack_fffffffffffffae0;
    int64_t in_stack_fffffffffffffae8;
    undefined4 in_stack_fffffffffffffaf0;
    undefined4 uVar42;
    undefined4 in_stack_fffffffffffffaf4;
    undefined4 uVar43;
    undefined4 in_stack_fffffffffffffaf8;
    int32_t in_stack_fffffffffffffafc;
    undefined4 in_stack_fffffffffffffb00;
    undefined4 uVar44;
    undefined4 in_stack_fffffffffffffb04;
    int32_t iVar45;
    undefined4 in_stack_fffffffffffffb08;
    undefined4 in_stack_fffffffffffffb0c;
    int64_t **in_stack_fffffffffffffb10;
    int64_t **in_stack_fffffffffffffb18;
    undefined4 in_stack_fffffffffffffb20;
    undefined4 in_stack_fffffffffffffb24;
    int64_t **in_stack_fffffffffffffb28;
    undefined4 in_stack_fffffffffffffb30;
    undefined4 in_stack_fffffffffffffb34;
    undefined4 uStack_4c8;
    undefined4 uStack_4c4;
    undefined4 in_stack_fffffffffffffb40;
    undefined4 in_stack_fffffffffffffb44;
    int64_t *arg_148h_00;
    int64_t *piStack_498;
    int64_t *in_stack_fffffffffffffb70;
    int64_t **in_stack_fffffffffffffb78;
    int64_t in_stack_fffffffffffffb80;
    int64_t in_stack_fffffffffffffb88;
    int64_t in_stack_fffffffffffffb90;
    int32_t iVar46;
    undefined4 in_stack_fffffffffffffb9c;
    undefined8 uStack_460;
    int64_t in_stack_fffffffffffffba8;
    int64_t in_stack_fffffffffffffbb0;
    int64_t *in_stack_fffffffffffffbb8;
    int64_t in_stack_fffffffffffffbc0;
    int64_t in_stack_fffffffffffffbc8;
    int64_t in_stack_fffffffffffffbd0;
    int64_t *in_stack_fffffffffffffbe0;
    int64_t in_stack_fffffffffffffbe8;
    uint64_t in_stack_fffffffffffffbf0;
    int64_t *in_stack_fffffffffffffbf8;
    int64_t in_stack_fffffffffffffc00;
    int64_t in_stack_fffffffffffffc08;
    int64_t in_stack_fffffffffffffc10;
    int64_t **in_stack_fffffffffffffc18;
    int64_t **in_stack_fffffffffffffc20;
    int64_t iStack_3d8;
    int64_t **ppiStack_3d0;
    int32_t iStack_3c8;
    undefined8 uStack_3c4;
    int32_t iStack_3bc;
    undefined8 uStack_3b8;
    undefined4 uStack_3b0;
    undefined8 uStack_3ac;
    undefined4 uStack_3a4;
    undefined8 uStack_3a0;
    int32_t iStack_398;
    undefined8 uStack_394;
    int64_t *piStack_388;
    undefined8 uStack_380;
    undefined8 uStack_378;
    undefined8 uStack_370;
    int64_t *piStack_368;
    int64_t *apiStack_360 [2];
    int64_t iStack_350;
    undefined8 uStack_348;
    undefined8 uStack_340;
    undefined8 uStack_338;
    undefined8 uStack_330;
    undefined8 uStack_328;
    undefined8 uStack_320;
    undefined8 uStack_318;
    undefined8 uStack_310;
    undefined8 uStack_308;
    undefined8 uStack_300;
    undefined8 uStack_2f8;
    undefined8 uStack_2f0;
    undefined8 uStack_2e8;
    int64_t *piStack_2e0;
    undefined8 uStack_2d8;
    undefined8 uStack_2d0;
    undefined8 uStack_2c8;
    int64_t *piStack_2c0;
    undefined8 uStack_2b8;
    undefined8 uStack_2b0;
    undefined8 uStack_2a8;
    undefined8 uStack_2a0;
    undefined8 uStack_298;
    int64_t *piStack_290;
    undefined8 uStack_288;
    undefined8 uStack_280;
    undefined8 uStack_278;
    int64_t *piStack_270;
    undefined8 uStack_268;
    undefined8 uStack_260;
    undefined8 uStack_258;
    int64_t *piStack_250;
    undefined8 uStack_248;
    undefined8 uStack_240;
    undefined8 uStack_238;
    undefined8 uStack_230;
    undefined8 uStack_228;
    undefined8 uStack_220;
    undefined8 uStack_218;
    undefined8 uStack_210;
    undefined8 uStack_208;
    undefined8 uStack_200;
    undefined8 uStack_1f8;
    undefined8 uStack_1f0;
    undefined8 uStack_1e8;
    undefined8 uStack_1e0;
    undefined8 uStack_1d8;
    undefined8 uStack_1d0;
    undefined8 uStack_1c8;
    int64_t *piStack_1c0;
    undefined8 uStack_1b8;
    undefined auStack_1b0 [16];
    undefined auStack_1a0 [16];
    undefined auStack_190 [16];
    undefined4 uStack_180;
    undefined4 uStack_17c;
    undefined4 uStack_178;
    undefined4 uStack_174;
    undefined4 uStack_170;
    undefined4 uStack_16c;
    undefined4 uStack_168;
    undefined4 uStack_164;
    undefined auStack_160 [16];
    undefined auStack_150 [16];
    undefined auStack_140 [16];
    undefined4 uStack_130;
    undefined4 uStack_12c;
    undefined4 uStack_128;
    undefined4 uStack_124;
    int64_t *apiStack_120 [2];
    undefined4 uStack_110;
    undefined4 uStack_10c;
    undefined4 uStack_108;
    undefined4 uStack_104;
    undefined auStack_100 [16];
    int64_t *apiStack_f0 [2];
    undefined auStack_e0 [16];
    undefined auStack_d0 [16];
    undefined auStack_c0 [16];
    undefined uStack_b0;
    unkbyte7 Stack_af;
    undefined8 uStack_a0;
    uint64_t uStack_98;
    undefined uStack_90;
    unkbyte7 Stack_8f;
    undefined8 uStack_80;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_8h;
    
    puVar33 = auStackY_5e8;
    var_70h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_5e8;
    func_0x0001800f1fd0(apiStack_360, arg1 + 0x248);
    ppiVar41 = (int64_t **)CONCAT44(in_stack_fffffffffffffb04, in_stack_fffffffffffffb00);
    ppiVar34 = (int64_t **)CONCAT44(in_stack_fffffffffffffaf4, in_stack_fffffffffffffaf0);
    uStack_348 = *(undefined8 *)(arg1 + 0xa8);
    arg_148h_00 = apiStack_360[0];
    iVar30 = iStack_350;
    do {
        uVar38 = SUB84(ppiVar34, 0);
        ppiVar31 = (int64_t **)0x0;
        iVar15 = *(int32_t *)(arg1 + 0x80);
        if (((iVar15 == 0) || (iVar15 - 0x126U < 3)) || (iVar15 == 0x136)) break;
        iVar46 = *(int32_t *)(arg1 + 0x114);
        *(uint32_t *)(arg1 + 0x114) = iVar46 + 1U;
        if (*(uint32_t *)0x180778500 < iVar46 + 1U) {
            iVar30 = func_0x0001800d90d0(arg1 + 0x60);
            fcn.1800d9940(iVar30 + 4, 0x180644050, 0x1806428e0, (int64_t)in_R9);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
    // switch table (11 cases) at 0x1800ddd00
        switch(iVar15) {
        case 0x11c:
        case 0x11d:
            func_0x0001800de530(arg1, &stack0xfffffffffffffae0);
            iVar15 = *(int32_t *)(arg1 + 0x80);
            if (iVar15 == 0x119) {
                if (*(char *)0x180778520 == '\0') {
code_r0x0001800dca5b:
                    if (*(char *)0x180778460 != '\0') {
                        ppiVar37 = ppiVar31;
                        do {
                            ppiVar17 = ppiVar37 + 0x300c851e;
                            ppiVar37 = (int64_t **)((int64_t)ppiVar37 + 1);
                            if (*(char *)ppiVar17 != *(char *)(*(int64_t *)(arg1 + 0x98) + -1 + (int64_t)ppiVar37))
                            goto code_r0x0001800dcada;
                        } while (ppiVar37 != (int64_t **)0x6);
                        _var_588h = *(undefined (*) [16])(arg1 + 0x84);
                        func_0x0001800f0350(arg1);
                        if (in_stack_fffffffffffffae8 == 0) {
                            ppiVar31 = (int64_t **)&var_588h;
                        } else {
                            ppiVar31 = (int64_t **)(*in_stack_fffffffffffffae0 + 0xc);
                        }
                        piStack_498 = *ppiVar31;
                        in_stack_fffffffffffffb70 = ppiVar31[1];
                        var_5c8h = CONCAT71(var_5c8h._1_7_, 1);
                        in_R9 = (int64_t **)&stack0xfffffffffffffae0;
                        ppiVar37 = (int64_t **)func_0x0001800df760(arg1, &piStack_498);
                        break;
                    }
                } else if (*(char *)0x180778460 != '\0') {
                    if (*(int64_t *)(arg1 + 0x98) != 0) {
                        in_R9 = (int64_t **)0x1806428e8;
                        ppiVar37 = ppiVar31;
                        do {
                            ppiVar17 = (int64_t **)((int64_t)ppiVar37 + 1);
                            if (*(char *)(*(int64_t *)(arg1 + 0x98) + (int64_t)ppiVar37) !=
                                *(char *)(ppiVar37 + 0x300c851d)) goto code_r0x0001800dca5b;
                            ppiVar37 = ppiVar17;
                        } while (ppiVar17 != (int64_t **)0x7);
                        _var_588h = *(undefined (*) [16])(arg1 + 0x84);
                        func_0x0001800f0350(arg1);
                        if (in_stack_fffffffffffffae8 == 0) {
                            piVar18 = &var_588h;
                        } else {
                            piVar18 = (int64_t *)(*in_stack_fffffffffffffae0 + 0xc);
                        }
                        in_R9 = (int64_t **)&stack0xfffffffffffffae0;
                        ppiVar37 = (int64_t **)func_0x0001800e2eb0(arg1, piVar18);
                        break;
                    }
                    goto code_r0x0001800dca5b;
                }
code_r0x0001800dcada:
                if (*(char *)arg1 != '\0') {
                    do {
                        ppiVar37 = ppiVar31 + 0x300c8535;
                        ppiVar31 = (int64_t **)((int64_t)ppiVar31 + 1);
                        if (*(char *)ppiVar37 != *(char *)(*(int64_t *)(arg1 + 0x98) + -1 + (int64_t)ppiVar31))
                        goto code_r0x0001800dcb26;
                    } while (ppiVar31 != (int64_t **)0x8);
                    iVar32 = func_0x0001800ea9f0(arg1, CONCAT71((unkint7)((uint64_t)*(int64_t *)(arg1 + 0x98) >> 8), 1))
                    ;
                    ppiVar37 = (int64_t **)func_0x0001800e13d0(arg1, iVar32 + 0xc);
                    break;
                }
            } else {
                if (iVar15 == 299) {
                    var_570h = *(int64_t *)(arg1 + 0x84);
                    in_stack_fffffffffffffa98 = *(undefined4 *)(arg1 + 0x8c);
                    in_stack_fffffffffffffa9c = *(undefined4 *)(arg1 + 0x90);
                    if (in_stack_fffffffffffffae8 != 0) {
                        iVar32 = *in_stack_fffffffffffffae0;
                        var_570h = *(int64_t *)(iVar32 + 0xc);
                        in_stack_fffffffffffffa98 = *(undefined4 *)(iVar32 + 0x14);
                        in_stack_fffffffffffffa9c = *(undefined4 *)(iVar32 + 0x18);
                    }
                    uStack_4c8 = *(undefined4 *)(arg1 + 0x80);
                    uStack_4c4 = *(undefined4 *)(arg1 + 0x84);
                    in_stack_fffffffffffffb40 = *(undefined4 *)(arg1 + 0x88);
                    in_stack_fffffffffffffb44 = *(undefined4 *)(arg1 + 0x8c);
                    func_0x0001800f0350(arg1);
                    var_5a0h = 0;
                    if (*(int32_t *)(arg1 + 0x80) == 0x119) {
                        var_5a0h = *(int64_t *)(arg1 + 0x98);
                    }
                    piVar18 = (int64_t *)func_0x0001800ea720(arg1, 0x180642a80);
                    var_578h = CONCAT44(var_578h._4_4_, *(undefined4 *)(arg1 + 0x114));
                    iVar15 = *(int32_t *)(arg1 + 0x80);
                    while (iVar15 == 0x2e) {
                        iVar32 = *(int64_t *)(arg1 + 0x84);
                        func_0x0001800f0350(arg1);
                        if (*(int32_t *)(arg1 + 0x80) == 0x119) {
                            uVar42 = (undefined4)*(undefined8 *)(arg1 + 0x98);
                            uVar43 = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x98) >> 0x20);
                            auVar3 = *(undefined (*) [16])(arg1 + 0x84);
                            uVar38 = auVar3._0_4_;
                            iVar15 = auVar3._4_4_;
                            uVar39 = auVar3._8_4_;
                            iVar40 = auVar3._12_4_;
                            uVar44 = uVar39;
                            iVar45 = iVar40;
                            func_0x0001800f0350(arg1);
                            ppiVar41 = (int64_t **)CONCAT44(iVar45, uVar44);
                            ppiVar31 = (int64_t **)CONCAT44(uVar43, uVar42);
                            in_stack_fffffffffffffaa8 = ppiVar31;
                            in_stack_fffffffffffffaf8 = uVar38;
                            in_stack_fffffffffffffafc = iVar15;
                            ppiVar34 = ppiVar31;
                        } else {
                            func_0x0001800efe90(arg1, 0x180642a90);
                            auVar10 = *(undefined (*) [12])(arg1 + 0x84);
                            var_588h = auVar10._0_8_;
                            var_580h = var_588h;
                            auVar3 = _var_588h;
                            ppiVar31 = *(int64_t ***)(arg1 + 0x128);
                            var_588h._0_4_ = auVar10._0_4_;
                            var_588h._4_4_ = auVar10._4_4_;
                            uVar38 = (undefined4)var_588h;
                            iVar15 = var_588h._4_4_;
                            uVar39 = (undefined4)var_588h;
                            iVar40 = var_588h._4_4_;
                            _var_588h = auVar3;
                        }
                        in_stack_fffffffffffffab0._4_4_ = iVar15;
                        in_stack_fffffffffffffab0._0_4_ = uVar38;
                        in_stack_fffffffffffffab0._8_4_ = uVar39;
                        in_stack_fffffffffffffab0._12_4_ = iVar40;
                        ppiVar37 = *(int64_t ***)(arg1 + 0xd8);
                        uStack_310 = *(undefined8 *)((int64_t)piVar18 + 0xc);
                        uStack_308 = in_stack_fffffffffffffab0._8_8_;
                        iVar24 = (int64_t)*ppiVar37;
                        var_5a0h = (int64_t)ppiVar31;
                        if (iVar24 == 0) {
code_r0x0001800dc5d1:
                            piVar22 = (int64_t *)func_0x000180459890(0x2008);
                            *piVar22 = (int64_t)*ppiVar37;
                            *ppiVar37 = piVar22;
                            piVar22 = piVar22 + 1;
                            piVar23 = (int64_t *)0x50;
                        } else {
                            piVar22 = (int64_t *)((int64_t)ppiVar37[1] + iVar24 + 0xf & 0xfffffffffffffff8);
                            if ((int64_t *)(iVar24 + 0x2008) < piVar22 + 10) goto code_r0x0001800dc5d1;
                            piVar23 = (int64_t *)((int64_t)piVar22 + (0x50 - (iVar24 + 8)));
                        }
                        ppiVar37[1] = piVar23;
                        *(int32_t *)(piVar22 + 1) = *(int32_t *)0x18078269c;
                        *(undefined4 *)((int64_t)piVar22 + 0xc) = (undefined4)uStack_310;
                        *(undefined4 *)(piVar22 + 2) = uStack_310._4_4_;
                        *(undefined4 *)((int64_t)piVar22 + 0x14) = (undefined4)uStack_308;
                        *(undefined4 *)(piVar22 + 3) = uStack_308._4_4_;
                        *piVar22 = 0x180641ca8;
                        piVar22[4] = (int64_t)piVar18;
                        piVar22[5] = (int64_t)ppiVar31;
                        auVar5._4_4_ = iVar15;
                        auVar5._0_4_ = uVar38;
                        auVar5._8_4_ = uVar39;
                        auVar5._12_4_ = iVar40;
                        *(undefined (*) [16])(piVar22 + 6) = auVar5;
                        piVar22[8] = iVar32;
                        *(undefined *)(piVar22 + 9) = 0x2e;
                        uVar14 = *(int32_t *)(arg1 + 0x114) + 1;
                        *(uint32_t *)(arg1 + 0x114) = uVar14;
                        if (*(uint32_t *)0x180778500 < uVar14) {
                            iVar30 = func_0x0001800d90d0(arg1 + 0x60);
                            fcn.1800d9940(iVar30 + 4, 0x180644050, 0x180642a80, (int64_t)in_R9);
                            pcVar4 = (code *)swi(3);
                            (*pcVar4)();
                            return;
                        }
                        piVar18 = piVar22;
                        iVar15 = *(int32_t *)(arg1 + 0x80);
                    }
                    *(undefined4 *)(arg1 + 0x114) = (undefined4)var_578h;
                    piVar22 = piVar18;
                    if (iVar15 == 0x3a) {
                        iVar32 = *(int64_t *)(arg1 + 0x84);
                        func_0x0001800f0350(arg1);
                        if (*(int32_t *)(arg1 + 0x80) == 0x119) {
                            uVar42 = (undefined4)*(undefined8 *)(arg1 + 0x98);
                            uVar43 = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x98) >> 0x20);
                            auVar3 = *(undefined (*) [16])(arg1 + 0x84);
                            uVar38 = auVar3._0_4_;
                            iVar15 = auVar3._4_4_;
                            uVar39 = auVar3._8_4_;
                            iVar40 = auVar3._12_4_;
                            uVar44 = uVar39;
                            iVar45 = iVar40;
                            func_0x0001800f0350(arg1);
                            ppiVar41 = (int64_t **)CONCAT44(iVar45, uVar44);
                            ppiVar31 = (int64_t **)CONCAT44(uVar43, uVar42);
                            in_stack_fffffffffffffaa8 = ppiVar31;
                            in_stack_fffffffffffffaf8 = uVar38;
                            in_stack_fffffffffffffafc = iVar15;
                            ppiVar34 = ppiVar31;
                        } else {
                            func_0x0001800efe90(arg1, 0x180642aa0);
                            auVar10 = *(undefined (*) [12])(arg1 + 0x84);
                            var_588h = auVar10._0_8_;
                            var_580h = var_588h;
                            auVar3 = _var_588h;
                            ppiVar31 = *(int64_t ***)(arg1 + 0x128);
                            var_588h._0_4_ = auVar10._0_4_;
                            var_588h._4_4_ = auVar10._4_4_;
                            uVar38 = (undefined4)var_588h;
                            iVar15 = var_588h._4_4_;
                            uVar39 = (undefined4)var_588h;
                            iVar40 = var_588h._4_4_;
                            _var_588h = auVar3;
                        }
                        in_stack_fffffffffffffab0._4_4_ = iVar15;
                        in_stack_fffffffffffffab0._0_4_ = uVar38;
                        in_stack_fffffffffffffab0._8_4_ = uVar39;
                        in_stack_fffffffffffffab0._12_4_ = iVar40;
                        ppiVar37 = *(int64_t ***)(arg1 + 0xd8);
                        uStack_300 = *(undefined8 *)((int64_t)piVar18 + 0xc);
                        uStack_2f8 = in_stack_fffffffffffffab0._8_8_;
                        iVar24 = (int64_t)*ppiVar37;
                        var_5a0h = (int64_t)ppiVar31;
                        if (iVar24 == 0) {
code_r0x0001800dc749:
                            piVar22 = (int64_t *)func_0x000180459890(0x2008);
                            *piVar22 = (int64_t)*ppiVar37;
                            *ppiVar37 = piVar22;
                            piVar22 = piVar22 + 1;
                            piVar23 = (int64_t *)0x50;
                        } else {
                            piVar22 = (int64_t *)((int64_t)ppiVar37[1] + iVar24 + 0xf & 0xfffffffffffffff8);
                            if ((int64_t *)(iVar24 + 0x2008) < piVar22 + 10) goto code_r0x0001800dc749;
                            piVar23 = (int64_t *)((int64_t)piVar22 + (0x50 - (iVar24 + 8)));
                        }
                        ppiVar37[1] = piVar23;
                        *(int32_t *)(piVar22 + 1) = *(int32_t *)0x18078269c;
                        *(undefined4 *)((int64_t)piVar22 + 0xc) = (undefined4)uStack_300;
                        *(undefined4 *)(piVar22 + 2) = uStack_300._4_4_;
                        *(undefined4 *)((int64_t)piVar22 + 0x14) = (undefined4)uStack_2f8;
                        *(undefined4 *)(piVar22 + 3) = uStack_2f8._4_4_;
                        *piVar22 = 0x180641ca8;
                        piVar22[4] = (int64_t)piVar18;
                        piVar22[5] = (int64_t)ppiVar31;
                        auVar6._4_4_ = iVar15;
                        auVar6._0_4_ = uVar38;
                        auVar6._8_4_ = uVar39;
                        auVar6._12_4_ = iVar40;
                        *(undefined (*) [16])(piVar22 + 6) = auVar6;
                        piVar22[8] = iVar32;
                        *(undefined *)(piVar22 + 9) = 0x3a;
                    }
                    if (*(char *)0x180778460 != '\0') {
                        iVar15 = *(int32_t *)(piVar22 + 1);
                        if (iVar15 == *(int32_t *)0x180782728) {
                            piVar18 = (int64_t *)0x0;
                            if (iVar15 == *(int32_t *)0x180782728) {
                                piVar18 = piVar22;
                            }
                            if (*(char *)(piVar18[4] + 0x30) == '\0') goto code_r0x0001800dc838;
                        }
                        if (((iVar15 != *(int32_t *)0x180782738) && (iVar15 != *(int32_t *)0x180782730)) &&
                           (iVar15 != *(int32_t *)0x18078269c)) {
                            if (*(char *)0x180778520 == '\0') {
                                piStack_388 = piVar22;
                                func_0x0001800f1110(arg1, auStack_160, &piStack_388, 1);
                                piVar22 = (int64_t *)
                                          func_0x0001800f0080(arg1, (int64_t)piVar22 + 0xc, auStack_160, 0x180642ab0);
                            } else {
                                piVar22 = (int64_t *)func_0x0001800e2de0(arg1, piVar22);
                            }
                        }
                    }
code_r0x0001800dc838:
                    piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x1e8) + 0x4a0);
                    *piVar1 = *piVar1 + 1;
                    var_5b0h._0_1_ = 0;
                    var_5b8h = (int64_t)&stack0xfffffffffffffae0;
                    var_5c0h = 0;
                    var_5c8h = (int64_t)&var_5a0h;
                    in_R9 = (int64_t **)&uStack_4c8;
                    ppiVar31 = (int64_t **)func_0x0001800e3690(arg1, auStack_150);
                    piVar18 = *ppiVar31;
                    piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x1e8) + 0x4a0);
                    *piVar1 = *piVar1 + -1;
                    ppiVar31 = *(int64_t ***)(arg1 + 0xd8);
                    uStack_2f0 = var_570h;
                    uStack_2e8 = *(undefined8 *)((int64_t)piVar18 + 0x14);
                    iVar32 = (int64_t)*ppiVar31;
                    if (iVar32 == 0) {
code_r0x0001800dc8e3:
                        piVar23 = (int64_t *)func_0x000180459890(0x2008);
                        *piVar23 = (int64_t)*ppiVar31;
                        *ppiVar31 = piVar23;
                        ppiVar37 = (int64_t **)(piVar23 + 1);
                        piVar23 = (int64_t *)0x38;
                    } else {
                        ppiVar37 = (int64_t **)((int64_t)ppiVar31[1] + iVar32 + 0xf & 0xfffffffffffffff8);
                        if ((int64_t **)(iVar32 + 0x2008) < ppiVar37 + 7) goto code_r0x0001800dc8e3;
                        piVar23 = (int64_t *)((int64_t)ppiVar37 + (0x38 - (iVar32 + 8)));
                    }
                    ppiVar31[1] = piVar23;
                    *(undefined4 *)(ppiVar37 + 1) = *(undefined4 *)0x180782690;
                    *(undefined4 *)((int64_t)ppiVar37 + 0xc) = (undefined4)uStack_2f0;
                    *(undefined4 *)(ppiVar37 + 2) = uStack_2f0._4_4_;
                    *(undefined4 *)((int64_t)ppiVar37 + 0x14) = (undefined4)uStack_2e8;
                    *(undefined4 *)(ppiVar37 + 3) = uStack_2e8._4_4_;
                    *(undefined *)(ppiVar37 + 4) = 0;
                    *ppiVar37 = (int64_t *)0x180641d48;
                    ppiVar37[5] = piVar22;
                    ppiVar37[6] = piVar18;
                    if (*(char *)(arg1 + 0x58) == '\0') break;
                    ppiVar31 = *(int64_t ***)(arg1 + 0xd8);
                    iVar32 = (int64_t)*ppiVar31;
                    if (iVar32 == 0) {
code_r0x0001800dc97b:
                        piVar18 = (int64_t *)func_0x000180459890(0x2008);
                        *piVar18 = (int64_t)*ppiVar31;
                        *ppiVar31 = piVar18;
                        piVar18 = piVar18 + 1;
                        piVar22 = (int64_t *)0xc;
                    } else {
                        piVar18 = (int64_t *)((int64_t)ppiVar31[1] + iVar32 + 0xf & 0xfffffffffffffff8);
                        if (iVar32 + 0x2008U < (int64_t)piVar18 + 0xcU) goto code_r0x0001800dc97b;
                        piVar22 = (int64_t *)((int64_t)piVar18 + (0xc - (iVar32 + 8)));
                    }
                    ppiVar31[1] = piVar22;
                    *(undefined4 *)piVar18 = *(undefined4 *)0x180782a68;
                    *(uint64_t *)((int64_t)piVar18 + 4) = CONCAT44(in_stack_fffffffffffffb40, uStack_4c4);
                    var_570h = (int64_t)ppiVar37;
                    ppiVar31 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_570h);
                    *ppiVar31 = piVar18;
                    break;
                }
                if (iVar15 == 0x12e) {
                    if (*(char *)0x180778460 == '\0') {
                        ppiVar37 = (int64_t **)func_0x0001800dee80(arg1, &stack0xfffffffffffffae0);
                    } else {
                        ppiVar31 = (int64_t **)(arg1 + 0x84);
                        if (in_stack_fffffffffffffae8 != 0) {
                            ppiVar31 = (int64_t **)(*in_stack_fffffffffffffae0 + 0xc);
                        }
                        piStack_498 = *ppiVar31;
                        in_stack_fffffffffffffb70 = ppiVar31[1];
                        var_5c8h = var_5c8h & 0xffffffffffffff00;
                        in_R9 = (int64_t **)&stack0xfffffffffffffae0;
                        ppiVar37 = (int64_t **)func_0x0001800df760(arg1, &piStack_498);
                    }
                    break;
                }
            }
code_r0x0001800dcb26:
            if (*(char *)0x180778460 == '\0') {
                var_5c0h = func_0x0001800d62b0(arg1 + 0x80, &uStack_90);
                if (0xf < *(uint64_t *)(var_5c0h + 0x18)) {
                    var_5c0h = *(int64_t *)var_5c0h;
                }
                piStack_2c0 = (int64_t *)0x0;
                uStack_2b8 = 0;
                uStack_2b0 = 0;
                uStack_2a8 = 0;
                var_5c8h = 0x180642cc0;
                in_R9 = &piStack_2c0;
                ppiVar37 = (int64_t **)func_0x0001800eff80(arg1, arg1 + 0x84);
                if (0xf < (uint64_t)var_78h) {
                    uVar29 = var_78h + 1;
                    iVar24 = CONCAT71(Stack_8f, uStack_90);
                    iVar32 = iVar24;
                    if (0xfff < uVar29) {
                        iVar32 = *(int64_t *)(iVar24 + -8);
                        if (0x1f < (iVar24 - iVar32) - 8U) goto code_r0x0001800ddc8d;
                        uVar29 = var_78h + 0x28;
                    }
                    func_0x000180459c3c(iVar32, uVar29);
                }
                uStack_80 = 0;
                var_78h = 0xf;
                uStack_90 = 0;
            } else {
                var_5c0h = func_0x0001800d62b0(arg1 + 0x80, &uStack_b0);
                if (0xf < *(uint64_t *)(var_5c0h + 0x18)) {
                    var_5c0h = *(int64_t *)var_5c0h;
                }
                piStack_2e0 = (int64_t *)0x0;
                uStack_2d8 = 0;
                uStack_2d0 = 0;
                uStack_2c8 = 0;
                var_5c8h = 0x180642c30;
                in_R9 = &piStack_2e0;
                ppiVar37 = (int64_t **)func_0x0001800eff80(arg1, arg1 + 0x84);
                if (0xf < uStack_98) {
                    uVar29 = uStack_98 + 1;
                    iVar24 = CONCAT71(Stack_af, uStack_b0);
                    iVar32 = iVar24;
                    if (0xfff < uVar29) {
                        iVar32 = *(int64_t *)(iVar24 + -8);
                        if (0x1f < (iVar24 - iVar32) - 8U) {
code_r0x0001800ddc8d:
                            pcVar4 = (code *)swi(0x29);
                            (*pcVar4)(5);
                            puVar33 = auStackY_5e0;
                            goto code_r0x0001800ddc94;
                        }
                        uVar29 = uStack_98 + 0x28;
                    }
                    func_0x000180459c3c(iVar32, uVar29);
                }
                uStack_a0 = 0;
                uStack_98 = 0xf;
                uStack_b0 = 0;
            }
            break;
        default:
            auVar3 = *(undefined (*) [16])(arg1 + 0x84);
            _var_588h = auVar3;
            ppiVar17 = (int64_t **)func_0x0001800ea9f0(arg1, 0x180000001);
            cVar13 = *(char *)0x180778460;
            iVar15 = *(int32_t *)(ppiVar17 + 1);
            in_stack_fffffffffffffac0 = ppiVar17;
            if (iVar15 == *(int32_t *)0x180782740) {
                ppiVar31 = *(int64_t ***)(arg1 + 0xd8);
                iVar32 = (int64_t)*ppiVar31;
                if (iVar32 == 0) {
code_r0x0001800dcd2f:
                    piVar18 = (int64_t *)func_0x000180459890(0x2008);
                    *piVar18 = (int64_t)*ppiVar31;
                    *ppiVar31 = piVar18;
                    ppiVar37 = (int64_t **)(piVar18 + 1);
                    piVar18 = (int64_t *)0x30;
                } else {
                    ppiVar37 = (int64_t **)((int64_t)ppiVar31[1] + iVar32 + 0xf & 0xfffffffffffffff8);
                    if ((int64_t **)(iVar32 + 0x2008) < ppiVar37 + 6) goto code_r0x0001800dcd2f;
                    piVar18 = (int64_t *)((int64_t)ppiVar37 + (0x30 - (iVar32 + 8)));
                }
                ppiVar31[1] = piVar18;
                uVar38 = *(undefined4 *)0x180782698;
                *ppiVar37 = (int64_t *)0x180642298;
                *(undefined4 *)(ppiVar37 + 1) = uVar38;
                uVar38 = *(undefined4 *)(ppiVar17 + 2);
                uVar39 = *(undefined4 *)((int64_t)ppiVar17 + 0x14);
                uVar44 = *(undefined4 *)(ppiVar17 + 3);
                *(undefined4 *)((int64_t)ppiVar37 + 0xc) = *(undefined4 *)((int64_t)ppiVar17 + 0xc);
                *(undefined4 *)(ppiVar37 + 2) = uVar38;
                *(undefined4 *)((int64_t)ppiVar37 + 0x14) = uVar39;
                *(undefined4 *)(ppiVar37 + 3) = uVar44;
                *(undefined *)(ppiVar37 + 4) = 0;
                *ppiVar37 = (int64_t *)0x1806422c0;
                ppiVar37[5] = (int64_t *)ppiVar17;
            } else {
                iVar40 = *(int32_t *)(arg1 + 0x80);
                if ((iVar40 != 0x2c) && (iVar40 != 0x3d)) {
                    if (iVar40 == 0x10e) {
                        uVar38 = 0;
                    } else if (iVar40 == 0x10f) {
                        uVar38 = 1;
                    } else if (iVar40 == 0x110) {
                        uVar38 = 2;
                    } else if (iVar40 == 0x111) {
                        uVar38 = 3;
                    } else if (iVar40 == 0x112) {
                        uVar38 = 4;
                    } else if (iVar40 == 0x113) {
                        uVar38 = 5;
                    } else if (iVar40 == 0x114) {
                        uVar38 = 6;
                    } else {
                        if (iVar40 != 0x115) {
                            ppiVar37 = ppiVar31;
                            if (iVar15 == *(int32_t *)0x180782738) {
                                ppiVar37 = ppiVar17;
                            }
                            if (ppiVar37 == (int64_t **)0x0) {
                                ppiVar37 = ppiVar31;
                                if (iVar15 == *(int32_t *)0x180782728) {
                                    ppiVar37 = ppiVar17;
                                }
                                if (ppiVar37 != (int64_t **)0x0) {
                                    ppiVar37 = (int64_t **)ppiVar37[4];
                                    goto code_r0x0001800dcf62;
                                }
                                piVar18 = (int64_t *)0x0;
                            } else {
                                ppiVar37 = ppiVar37 + 4;
code_r0x0001800dcf62:
                                piVar18 = *ppiVar37;
                                ppiVar37 = ppiVar31;
                                if (piVar18 != (int64_t *)0x0) {
                                    do {
                                        ppiVar27 = (int64_t **)((int64_t)ppiVar37 + 1);
                                        if (*(char *)((int64_t)piVar18 + (int64_t)ppiVar37) !=
                                            *(char *)((int64_t)ppiVar37 + 0x18062623c)) goto code_r0x0001800dcfa1;
                                        ppiVar37 = ppiVar27;
                                    } while (ppiVar27 != (int64_t **)0x5);
                                    in_R9 = *(int64_t ***)((int64_t)ppiVar17 + 0xc);
                                    ppiVar37 = (int64_t **)func_0x0001800e00c0(arg1);
                                    in_stack_fffffffffffffac0 = ppiVar17;
                                    break;
                                }
                            }
code_r0x0001800dcfa1:
                            if (piVar18 == (int64_t *)0x0) {
code_r0x0001800dd28e:
                                if ((cVar13 == '\0') || (ppiVar37 = ppiVar31, piVar18 == (int64_t *)0x0)) {
code_r0x0001800dd2f0:
                                    if ((*(char *)arg1 == '\0') || (piVar18 == (int64_t *)0x0)) {
code_r0x0001800dd34c:
                                        if ((((auVar3._4_4_ == *(int32_t *)(arg1 + 0x88)) &&
                                             (auVar3._0_4_ == *(int32_t *)(arg1 + 0x84))) &&
                                            (auVar3._12_4_ == *(int32_t *)(arg1 + 0x90))) &&
                                           (auVar3._8_4_ == *(int32_t *)(arg1 + 0x8c))) {
                                            func_0x0001800f0350(arg1);
                                        }
                                        piStack_250 = (int64_t *)0x0;
                                        uStack_248 = 0;
                                        in_stack_fffffffffffffc18 = ppiVar17;
                                        func_0x0001800f1110(arg1, auStack_1b0, &stack0xfffffffffffffc18, 1);
                                        var_5c8h = 0x1806429b0;
                                        in_R9 = &piStack_250;
                                        ppiVar37 = (int64_t **)func_0x0001800eff80(arg1, (int64_t)ppiVar17 + 0xc);
                                    } else {
                                        do {
                                            ppiVar37 = (int64_t **)((int64_t)ppiVar31 + 1);
                                            if (*(char *)((int64_t)piVar18 + (int64_t)ppiVar31) !=
                                                *(char *)(ppiVar31 + 0x300c8535)) goto code_r0x0001800dd34c;
                                            ppiVar31 = ppiVar37;
                                        } while (ppiVar37 != (int64_t **)0x8);
                                        uStack_260 = 0;
                                        uStack_258 = 0;
                                        ppiVar37 = (int64_t **)func_0x0001800e13d0(arg1, (int64_t)ppiVar17 + 0xc);
                                    }
                                } else {
                                    do {
                                        ppiVar27 = (int64_t **)((int64_t)ppiVar37 + 1);
                                        if (*(char *)((int64_t)piVar18 + (int64_t)ppiVar37) !=
                                            *(char *)(ppiVar37 + 0x300c851e)) goto code_r0x0001800dd2f0;
                                        ppiVar37 = ppiVar27;
                                    } while (ppiVar27 != (int64_t **)0x6);
                                    piStack_270 = (int64_t *)0x0;
                                    uStack_268 = 0;
                                    piStack_498 = *(int64_t **)((int64_t)ppiVar17 + 0xc);
                                    in_stack_fffffffffffffb70 = *(int64_t **)((int64_t)ppiVar17 + 0x14);
                                    var_5c8h = CONCAT71(var_5c8h._1_7_, 1);
                                    in_R9 = &piStack_270;
                                    ppiVar37 = (int64_t **)func_0x0001800df760(arg1, &piStack_498);
                                }
                            } else {
                                in_R9 = (int64_t **)(uint64_t)*(uint8_t *)0x180778560;
                                ppiVar37 = ppiVar31;
                                ppiVar27 = ppiVar31;
                                if (*(uint8_t *)0x180778560 == 0) {
code_r0x0001800dd010:
                                    do {
                                        ppiVar27 = (int64_t **)((int64_t)ppiVar37 + 1);
                                        if (*(char *)((int64_t)piVar18 + (int64_t)ppiVar37) !=
                                            *(char *)(ppiVar37 + 0x300c851d)) goto code_r0x0001800dd1ee;
                                        ppiVar37 = ppiVar27;
                                    } while (ppiVar27 != (int64_t **)0x7);
                                    if ((*(char *)0x180778520 == '\0') || (*(char *)0x180778460 == '\0')) {
                                        if ((*(uint8_t *)0x180778560 == 0) ||
                                           (ppiVar37 = ppiVar31, *(int64_t *)(arg1 + 0x98) == 0)) {
code_r0x0001800dd195:
                                            if ((*(int32_t *)(arg1 + 0x80) != 0x119) ||
                                               (ppiVar37 = ppiVar31, *(int64_t *)(arg1 + 0x98) == 0))
                                            goto code_r0x0001800dd1ee;
                                            do {
                                                ppiVar27 = (int64_t **)((int64_t)ppiVar37 + 1);
                                                if (*(char *)(*(int64_t *)(arg1 + 0x98) + (int64_t)ppiVar37) !=
                                                    *(char *)((int64_t)ppiVar37 + 0x18062623c))
                                                goto code_r0x0001800dd1ee;
                                                ppiVar37 = ppiVar27;
                                            } while (ppiVar27 != (int64_t **)0x5);
                                            in_R9 = *(int64_t ***)(arg1 + 0x84);
                                            func_0x0001800f0350(arg1);
                                            ppiVar37 = (int64_t **)func_0x0001800e00c0(arg1, (int64_t)ppiVar17 + 0xc);
                                        } else {
                                            do {
                                                ppiVar27 = (int64_t **)((int64_t)ppiVar37 + 1);
                                                if (*(char *)(*(int64_t *)(arg1 + 0x98) + (int64_t)ppiVar37) !=
                                                    *(char *)(ppiVar37 + 0x300c7c33)) goto code_r0x0001800dd195;
                                                ppiVar37 = ppiVar27;
                                            } while (ppiVar27 != (int64_t **)0x6);
                                            func_0x0001800f0350(arg1);
                                            ppiVar37 = (int64_t **)func_0x0001800e0670(arg1, &var_588h);
                                            in_stack_fffffffffffffac0 = ppiVar17;
                                        }
                                    } else {
                                        iVar15 = *(int32_t *)(arg1 + 0x80);
                                        uStack_4c4 = *(undefined4 *)(arg1 + 0x84);
                                        in_stack_fffffffffffffb40 = *(undefined4 *)(arg1 + 0x88);
                                        in_stack_fffffffffffffb44 = *(undefined4 *)(arg1 + 0x8c);
                                        if ((iVar15 == 0x12e) || (iVar15 == 299)) {
code_r0x0001800dd0a4:
                                            piStack_290 = (int64_t *)0x0;
                                            uStack_288 = 0;
                                            in_R9 = &piStack_290;
                                            ppiVar37 = (int64_t **)func_0x0001800e2eb0(arg1);
                                            in_stack_fffffffffffffac0 = ppiVar17;
                                        } else {
                                            iVar32 = *(int64_t *)(arg1 + 0x98);
                                            if (iVar15 == 0x119) {
                                                ppiVar37 = ppiVar31;
                                                if (iVar32 != 0) {
                                                    do {
                                                        ppiVar27 = (int64_t **)((int64_t)ppiVar37 + 1);
                                                        if (*(char *)(iVar32 + (int64_t)ppiVar37) !=
                                                            *(char *)(ppiVar37 + 0x300c851e)) goto code_r0x0001800dd0dd;
                                                        ppiVar37 = ppiVar27;
                                                    } while (ppiVar27 != (int64_t **)0x6);
                                                    goto code_r0x0001800dd0a4;
                                                }
code_r0x0001800dd0dd:
                                                ppiVar37 = ppiVar31;
                                                if (*(uint8_t *)0x180778560 == 0) {
                                                    if (iVar32 != 0) {
code_r0x0001800dd112:
                                                        do {
                                                            ppiVar27 = (int64_t **)((int64_t)ppiVar37 + 1);
                                                            if (*(char *)(iVar32 + (int64_t)ppiVar37) !=
                                                                *(char *)((int64_t)ppiVar37 + 0x18062623c))
                                                            goto code_r0x0001800dd1ee;
                                                            ppiVar37 = ppiVar27;
                                                        } while (ppiVar27 != (int64_t **)0x5);
                                                        func_0x0001800f0350(arg1);
                                                        in_R9 = (int64_t **)
                                                                CONCAT44(in_stack_fffffffffffffb40, uStack_4c4);
                                                        ppiVar37 = (int64_t **)
                                                                   func_0x0001800e00c0(arg1, (int64_t)ppiVar17 + 0xc);
                                                        break;
                                                    }
                                                } else {
                                                    ppiVar27 = ppiVar31;
                                                    if (iVar32 != 0) {
                                                        do {
                                                            ppiVar28 = (int64_t **)((int64_t)ppiVar27 + 1);
                                                            if (*(char *)(iVar32 + (int64_t)ppiVar27) !=
                                                                *(char *)(ppiVar27 + 0x300c7c33))
                                                            goto code_r0x0001800dd112;
                                                            ppiVar27 = ppiVar28;
                                                        } while (ppiVar28 != (int64_t **)0x6);
                                                        goto code_r0x0001800dd0a4;
                                                    }
                                                }
                                            }
code_r0x0001800dd1ee:
                                            iVar15 = func_0x000180498f10(piVar18, 0x1806428f8);
                                            if (iVar15 != 0) goto code_r0x0001800dd28e;
                                            if (*(int32_t *)(*(int64_t *)(arg1 + 0x150) + -4) == 0) {
                                                in_stack_fffffffffffffc10 =
                                                     func_0x0001800f0da0(*(undefined8 *)(arg1 + 0xd8), 
                                                                         (int64_t)ppiVar17 + 0xc);
                                                func_0x0001800f1110(arg1, apiStack_f0, &stack0xfffffffffffffc10, 1);
                                                uStack_280 = 0;
                                                uStack_278 = 0;
                                                var_5c8h = 0x180642958;
                                                in_R9 = apiStack_f0;
                                                ppiVar37 = (int64_t **)
                                                           func_0x0001800eff80(arg1, (int64_t)ppiVar17 + 0xc);
                                            } else {
                                                ppiVar37 = (int64_t **)
                                                           func_0x0001800f0da0(*(undefined8 *)(arg1 + 0xd8), 
                                                                               (int64_t)ppiVar17 + 0xc);
                                            }
                                        }
                                    }
                                } else {
                                    do {
                                        ppiVar28 = (int64_t **)((int64_t)ppiVar27 + 1);
                                        if (*(char *)((int64_t)piVar18 + (int64_t)ppiVar27) !=
                                            *(char *)(ppiVar27 + 0x300c7c33)) goto code_r0x0001800dd010;
                                        ppiVar27 = ppiVar28;
                                    } while (ppiVar28 != (int64_t **)0x6);
                                    ppiVar37 = (int64_t **)func_0x0001800e0670(arg1, &var_588h);
                                    in_stack_fffffffffffffac0 = ppiVar17;
                                }
                            }
                            break;
                        }
                        uVar38 = 7;
                    }
                    cVar13 = func_0x0001800de090(ppiVar17);
                    if (cVar13 == '\0') {
                        if ((*(char *)0x180778520 == '\0') || (*(char *)0x180778460 == '\0')) {
                            ppiStack_3d0 = ppiVar17;
                            func_0x0001800f1110(arg1, auStack_100, &ppiStack_3d0, 1);
                            in_R9 = (int64_t **)0x180642ab0;
                            ppiVar17 = (int64_t **)func_0x0001800f0080(arg1, (int64_t)ppiVar17 + 0xc);
                        } else {
                            ppiVar17 = (int64_t **)func_0x0001800e2de0(arg1, ppiVar17);
                        }
                    }
                    uVar21 = *(undefined8 *)(arg1 + 0x84);
                    func_0x0001800f0350(arg1);
                    piVar18 = (int64_t *)func_0x0001800e9350(arg1, 0);
                    uStack_2a0 = *(undefined8 *)((int64_t)ppiVar17 + 0xc);
                    uStack_298 = *(undefined8 *)((int64_t)piVar18 + 0x14);
                    ppiVar37 = (int64_t **)func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), 0x40);
                    *(undefined4 *)(ppiVar37 + 1) = *(undefined4 *)0x180782734;
                    *(undefined4 *)((int64_t)ppiVar37 + 0xc) = (undefined4)uStack_2a0;
                    *(undefined4 *)(ppiVar37 + 2) = uStack_2a0._4_4_;
                    *(undefined4 *)((int64_t)ppiVar37 + 0x14) = (undefined4)uStack_298;
                    *(undefined4 *)(ppiVar37 + 3) = uStack_298._4_4_;
                    *(undefined *)(ppiVar37 + 4) = 0;
                    *ppiVar37 = (int64_t *)0x180642108;
                    *(undefined4 *)(ppiVar37 + 5) = uVar38;
                    ppiVar37[6] = (int64_t *)ppiVar17;
                    ppiVar37[7] = piVar18;
                    if (*(char *)(arg1 + 0x58) != '\0') {
                        puVar19 = (undefined4 *)func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), 0xc);
                        *puVar19 = *(undefined4 *)0x180782a3c;
                        *(undefined8 *)(puVar19 + 1) = uVar21;
                        var_570h = (int64_t)ppiVar37;
                        puVar20 = (undefined8 *)func_0x0001800cc970(arg1 + 0x490, &var_570h);
                        *puVar20 = puVar19;
                    }
                    break;
                }
                var_578h = (int64_t)ppiVar17;
                if (iVar15 == *(int32_t *)0x180782728) {
                    if (*(char *)0x180778460 != '\0') {
                        if (iVar15 == *(int32_t *)0x180782728) {
                            ppiVar31 = ppiVar17;
                        }
                        if (*(char *)(ppiVar31[4] + 6) != '\0') goto code_r0x0001800dd431;
                    }
                } else {
code_r0x0001800dd431:
                    if (((iVar15 != *(int32_t *)0x180782738) && (iVar15 != *(int32_t *)0x180782730)) &&
                       (iVar15 != *(int32_t *)0x18078269c)) {
                        if ((*(char *)0x180778520 == '\0') || (*(char *)0x180778460 == '\0')) {
                            in_stack_fffffffffffffc20 = ppiVar17;
                            func_0x0001800f1110(arg1, auStack_1a0, &stack0xfffffffffffffc20, 1);
                            var_578h = func_0x0001800f0080(arg1, (int64_t)ppiVar17 + 0xc, auStack_1a0, 0x180642ab0);
                        } else {
                            var_578h = func_0x0001800e2de0(arg1, ppiVar17);
                        }
                    }
                }
                piVar18 = (int64_t *)(arg1 + 0x290);
                var_570h = *(int64_t *)(arg1 + 0x298) - *piVar18 >> 3;
                in_stack_fffffffffffffaa8 = (int64_t **)(arg1 + 0x440);
                in_stack_fffffffffffffaa0 =
                     (int64_t **)(*(int64_t *)(arg1 + 0x448) - (int64_t)*in_stack_fffffffffffffaa8 >> 3);
                var_5a0h = 0;
                in_stack_fffffffffffffab0._8_8_ = 0;
                in_stack_fffffffffffffab0._0_8_ = in_stack_fffffffffffffaa0;
                in_stack_fffffffffffffac0 = (int64_t **)var_578h;
                in_stack_fffffffffffffb18 = in_stack_fffffffffffffaa8;
                piStack_498 = piVar18;
                in_stack_fffffffffffffb70 = (int64_t *)var_570h;
                func_0x0001800bf890(piVar18, &var_578h);
                ppiVar34 = (int64_t **)0x1;
                iVar15 = *(int32_t *)(arg1 + 0x80);
                in_R9 = (int64_t **)0x1;
                if (iVar15 == 0x2c) {
                    do {
                        if (*(char *)(arg1 + 0x58) != '\0') {
                            func_0x0001800f1a70(&stack0xfffffffffffffaa8, arg1 + 0x84);
                        }
                        func_0x0001800f0350(arg1);
                        iVar32 = func_0x0001800ea9f0(arg1, 1);
                        iVar15 = *(int32_t *)(iVar32 + 8);
                        var_5a0h = iVar32;
                        if (iVar15 == *(int32_t *)0x180782728) {
                            if (*(char *)0x180778460 != '\0') {
                                iVar24 = 0;
                                if (iVar15 == *(int32_t *)0x180782728) {
                                    iVar24 = iVar32;
                                }
                                if (*(char *)(*(int64_t *)(iVar24 + 0x20) + 0x30) != '\0') goto code_r0x0001800dd583;
                            }
                        } else {
code_r0x0001800dd583:
                            if (((iVar15 != *(int32_t *)0x180782738) && (iVar15 != *(int32_t *)0x180782730)) &&
                               (iVar15 != *(int32_t *)0x18078269c)) {
                                if ((*(char *)0x180778520 == '\0') || (*(char *)0x180778460 == '\0')) {
                                    iStack_3d8 = iVar32;
                                    func_0x0001800f1110(arg1, auStack_190, &iStack_3d8, 1);
                                    var_5a0h = func_0x0001800f0080(arg1, iVar32 + 0xc, auStack_190, 0x180642ab0);
                                } else {
                                    var_5a0h = func_0x0001800e2de0(arg1, iVar32);
                                }
                            }
                        }
                        func_0x0001800bf890(piVar18, &var_5a0h);
                        ppiVar34 = (int64_t **)((int64_t)ppiVar34 + 1);
                        iVar15 = *(int32_t *)(arg1 + 0x80);
                    } while (iVar15 == 0x2c);
                    var_5a0h = in_stack_fffffffffffffab0._8_8_;
                    in_stack_fffffffffffffaa0 = in_stack_fffffffffffffab0._0_8_;
                    in_stack_fffffffffffffb18 = in_stack_fffffffffffffaa8;
                    in_R9 = ppiVar34;
                }
                if (iVar15 == 0x3d) {
                    func_0x0001800f0350(arg1);
code_r0x0001800dd664:
                    in_stack_fffffffffffffbb8 = *(int64_t **)(arg1 + 0xa0);
                } else {
                    cVar13 = func_0x0001800ef2a0(arg1, 0x3d);
                    if (cVar13 != '\0') goto code_r0x0001800dd664;
                    in_stack_fffffffffffffbb8 = (int64_t *)0xffffffffffffffff;
                }
                ppiVar31 = (int64_t **)(arg1 + 0x2a8);
                iVar32 = *(int64_t *)(arg1 + 0x2b0) - (int64_t)*ppiVar31;
                in_stack_fffffffffffffb28 = (int64_t **)(iVar32 >> 3);
                in_stack_fffffffffffffaf8 = SUB84(in_stack_fffffffffffffb28, 0);
                in_stack_fffffffffffffafc = (int32_t)(iVar32 >> 0x23);
                ppiVar17 = (int64_t **)(arg1 + 0x440);
                var_578h = *(int64_t *)(arg1 + 0x448) - (int64_t)*ppiVar17 >> 3;
                ppiVar27 = (int64_t **)0x0;
                puVar35 = &stack0xfffffffffffffac8;
                if (*(char *)(arg1 + 0x58) == '\0') {
                    puVar35 = (undefined *)0x0;
                }
                in_stack_fffffffffffffac8 = ppiVar17;
                in_stack_fffffffffffffad0 = (int64_t **)var_578h;
                in_stack_fffffffffffffb10 = ppiVar17;
                ppiVar34 = ppiVar31;
                uVar21 = func_0x0001800e9350(arg1, 0);
                var_588h = uVar21;
                func_0x0001800bf890(ppiVar31, &var_588h);
                ppiVar37 = (int64_t **)0x1;
                iVar15 = *(int32_t *)(arg1 + 0x80);
                ppiVar28 = (int64_t **)var_578h;
                while (ppiVar41 = ppiVar37, iVar15 == 0x2c) {
                    ppiVar17 = in_stack_fffffffffffffac8;
                    if (puVar35 != (undefined *)0x0) {
                        func_0x0001800f1a70(puVar35, arg1 + 0x84);
                        ppiVar17 = in_stack_fffffffffffffac8;
                    }
                    func_0x0001800f0350(arg1);
                    if (*(int32_t *)(arg1 + 0x80) == 0x29) {
                        func_0x0001800efe70(arg1, arg1 + 0x84);
                        ppiVar28 = in_stack_fffffffffffffad0;
                        in_stack_fffffffffffffac8 = ppiVar17;
                        in_stack_fffffffffffffb10 = ppiVar17;
                        break;
                    }
                    uVar21 = func_0x0001800e9350(arg1, 0);
                    var_588h = uVar21;
                    func_0x0001800bf890(ppiVar31);
                    ppiVar37 = (int64_t **)((int64_t)ppiVar37 + 1);
                    ppiVar28 = in_stack_fffffffffffffad0;
                    in_stack_fffffffffffffac8 = ppiVar17;
                    in_stack_fffffffffffffb10 = ppiVar17;
                    iVar15 = *(int32_t *)(arg1 + 0x80);
                }
                var_578h = (int64_t)ppiVar28;
                ppiVar28 = *(int64_t ***)(arg1 + 0xd8);
                if (ppiVar37 == (int64_t **)0x0) {
                    piVar18 = (int64_t *)0x0;
                } else {
                    piVar18 = *ppiVar31 + (int64_t)in_stack_fffffffffffffb28;
                }
                func_0x0001800f1110(arg1, &uStack_170, piVar18, ppiVar37);
                in_stack_fffffffffffffb78 = in_R9;
                func_0x0001800f1110(arg1, &uStack_180);
                in_stack_fffffffffffffbc8 = *(int64_t *)((int64_t)in_stack_fffffffffffffac0 + 0xc);
                in_stack_fffffffffffffbd0 = *(int64_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x2b0) + -8) + 0x14);
                iVar32 = (int64_t)*ppiVar28;
                if (iVar32 == 0) {
code_r0x0001800dd832:
                    piVar18 = (int64_t *)func_0x000180459890(0x2008);
                    *piVar18 = (int64_t)*ppiVar28;
                    *ppiVar28 = piVar18;
                    ppiVar37 = (int64_t **)(piVar18 + 1);
                    piVar18 = (int64_t *)0x48;
                } else {
                    ppiVar37 = (int64_t **)((int64_t)ppiVar28[1] + iVar32 + 0xf & 0xfffffffffffffff8);
                    if ((int64_t **)(iVar32 + 0x2008) < ppiVar37 + 9) goto code_r0x0001800dd832;
                    piVar18 = (int64_t *)((int64_t)ppiVar37 + (0x48 - (iVar32 + 8)));
                }
                ppiVar28[1] = piVar18;
                *(undefined4 *)(ppiVar37 + 1) = *(undefined4 *)0x180782754;
                *(int32_t *)((int64_t)ppiVar37 + 0xc) = (int32_t)in_stack_fffffffffffffbc8;
                *(int32_t *)(ppiVar37 + 2) = (int32_t)((uint64_t)in_stack_fffffffffffffbc8 >> 0x20);
                *(int32_t *)((int64_t)ppiVar37 + 0x14) = (int32_t)in_stack_fffffffffffffbd0;
                *(int32_t *)(ppiVar37 + 3) = (int32_t)((uint64_t)in_stack_fffffffffffffbd0 >> 0x20);
                *(undefined *)(ppiVar37 + 4) = 0;
                *ppiVar37 = (int64_t *)0x180642040;
                *(undefined4 *)(ppiVar37 + 5) = uStack_180;
                *(undefined4 *)((int64_t)ppiVar37 + 0x2c) = uStack_17c;
                *(undefined4 *)(ppiVar37 + 6) = uStack_178;
                *(undefined4 *)((int64_t)ppiVar37 + 0x34) = uStack_174;
                *(undefined4 *)(ppiVar37 + 7) = uStack_170;
                *(undefined4 *)((int64_t)ppiVar37 + 0x3c) = uStack_16c;
                *(undefined4 *)(ppiVar37 + 8) = uStack_168;
                *(undefined4 *)((int64_t)ppiVar37 + 0x44) = uStack_164;
                in_stack_fffffffffffffad8 = ppiVar27;
                if (*(char *)(arg1 + 0x58) != '\0') {
                    in_stack_fffffffffffffac0 = *(int64_t ***)(arg1 + 0xd8);
                    if (ppiVar27 == (int64_t **)0x0) {
                        piVar22 = (int64_t *)0x0;
                    } else {
                        piVar18 = *ppiVar17;
                        piVar22 = (int64_t *)func_0x0001800d4d20(in_stack_fffffffffffffac0, (int64_t)ppiVar27 * 8);
                        if (ppiVar27 != (int64_t **)0x0) {
                            piVar18 = piVar18 + var_578h;
                            ppiVar31 = (int64_t **)0x0;
                            if ((ppiVar27 < (int64_t **)0x2) ||
                               ((piVar22 <= piVar18 + (int64_t)ppiVar27 + -1 &&
                                (piVar18 <= piVar22 + (int64_t)ppiVar27 + -1)))) {
                                do {
                                    piVar22[(int64_t)ppiVar31] = piVar18[(int64_t)ppiVar31];
                                    ppiVar31 = (int64_t **)((int64_t)ppiVar31 + 1);
                                } while (ppiVar31 < ppiVar27);
                            } else {
                                func_0x000180498030(piVar22, piVar18, (int64_t)ppiVar27 * 8);
                            }
                        }
                    }
                    if (var_5a0h == 0) {
                        piVar23 = (int64_t *)0x0;
                        in_R9 = (int64_t **)var_5a0h;
                    } else {
                        piVar18 = *in_stack_fffffffffffffb18;
                        piVar23 = (int64_t *)func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), var_5a0h * 8);
                        in_R9 = (int64_t **)var_5a0h;
                        if (var_5a0h != 0) {
                            piVar18 = piVar18 + (int64_t)in_stack_fffffffffffffaa0;
                            uVar29 = 0;
                            if (((uint64_t)var_5a0h < 2) ||
                               ((piVar23 <= piVar18 + var_5a0h + -1 && (piVar18 <= piVar23 + var_5a0h + -1)))) {
                                do {
                                    piVar23[uVar29] = piVar18[uVar29];
                                    uVar29 = uVar29 + 1;
                                } while (uVar29 < (uint64_t)var_5a0h);
                            } else {
                                func_0x000180498030(piVar23, piVar18, var_5a0h * 8);
                            }
                        }
                    }
                    piVar18 = *in_stack_fffffffffffffac0;
                    if (piVar18 == (int64_t *)0x0) {
code_r0x0001800dda02:
                        ppiVar31 = (int64_t **)func_0x000180459890(0x2008);
                        *ppiVar31 = *in_stack_fffffffffffffac0;
                        *in_stack_fffffffffffffac0 = (int64_t *)ppiVar31;
                        ppiVar31 = ppiVar31 + 1;
                        piVar18 = (int64_t *)0x30;
                    } else {
                        ppiVar31 = (int64_t **)
                                   ((int64_t)in_stack_fffffffffffffac0[1] + 7 + (int64_t)(piVar18 + 1) &
                                   0xfffffffffffffff8);
                        if (piVar18 + 0x401 < ppiVar31 + 6) goto code_r0x0001800dda02;
                        piVar18 = (int64_t *)((int64_t)ppiVar31 + (0x30 - (int64_t)(piVar18 + 1)));
                    }
                    in_stack_fffffffffffffac0[1] = piVar18;
                    *(undefined4 *)ppiVar31 = *(undefined4 *)0x180782a8c;
                    ppiVar31[1] = piVar23;
                    ppiVar31[2] = (int64_t *)var_5a0h;
                    ppiVar31[3] = in_stack_fffffffffffffbb8;
                    ppiVar31[4] = piVar22;
                    ppiVar31[5] = (int64_t *)ppiVar27;
                    var_588h = (int64_t)ppiVar37;
                    ppiVar17 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_588h);
                    *ppiVar17 = (int64_t *)ppiVar31;
                }
                if (*in_stack_fffffffffffffb10 + var_578h != in_stack_fffffffffffffb10[1]) {
                    in_stack_fffffffffffffb10[1] = *in_stack_fffffffffffffb10 + var_578h;
                }
                iVar32 = *(int64_t *)(arg1 + 0x2a8) + (int64_t)in_stack_fffffffffffffb28 * 8;
                if (iVar32 != *(int64_t *)(arg1 + 0x2b0)) {
                    *(int64_t *)(arg1 + 0x2b0) = iVar32;
                }
                if (*in_stack_fffffffffffffb18 + (int64_t)in_stack_fffffffffffffaa0 != in_stack_fffffffffffffb18[1]) {
                    in_stack_fffffffffffffb18[1] = *in_stack_fffffffffffffb18 + (int64_t)in_stack_fffffffffffffaa0;
                }
                iVar32 = *(int64_t *)(arg1 + 0x290) + var_570h * 8;
                if (iVar32 != *(int64_t *)(arg1 + 0x298)) {
                    *(int64_t *)(arg1 + 0x298) = iVar32;
                }
            }
            break;
        case 0x124:
            _var_588h = *(undefined (*) [16])(arg1 + 0x84);
            func_0x0001800f0350(arg1);
            if (*(int32_t *)(*(int64_t *)(arg1 + 0x150) + -4) == 0) {
                uStack_370 = func_0x0001800f0cf0(*(undefined8 *)(arg1 + 0xd8), &var_588h);
                func_0x0001800f1110(arg1, apiStack_120, &uStack_370, 1);
                uStack_320 = 0;
                uStack_318 = 0;
                var_5c8h = 0x180642930;
                in_R9 = apiStack_120;
                ppiVar37 = (int64_t **)func_0x0001800eff80(arg1, &var_588h);
            } else {
                ppiVar37 = (int64_t **)func_0x0001800f0cf0(*(undefined8 *)(arg1 + 0xd8), &var_588h);
            }
            break;
        case 0x125:
            uStack_4c4 = *(undefined4 *)*(undefined (*) [16])(arg1 + 0x84);
            in_stack_fffffffffffffb40 = *(undefined4 *)(arg1 + 0x88);
            in_stack_fffffffffffffb44 = *(undefined4 *)(arg1 + 0x8c);
            _var_588h = *(undefined (*) [16])(arg1 + 0x84);
            func_0x0001800f0350(arg1, uStack_4c4);
            uVar21 = *(undefined8 *)(arg1 + 0x84);
            ppiVar37 = (int64_t **)
                       fcn.1800dae50(arg1, var_5c0h, var_5a0h, CONCAT71(var_598h._1_7_, (undefined)var_598h), 
                                     in_stack_fffffffffffffa70, var_580h, var_570h, 
                                     CONCAT44(in_stack_fffffffffffffa9c, in_stack_fffffffffffffa98), 
                                     (int64_t)in_stack_fffffffffffffaa0, (int64_t)in_stack_fffffffffffffaa8, 
                                     in_stack_fffffffffffffab0._0_8_, in_stack_fffffffffffffab0._8_8_, 
                                     (int64_t)in_stack_fffffffffffffac0, (int64_t)in_stack_fffffffffffffac8, 
                                     (int64_t)in_stack_fffffffffffffad0, (int64_t)in_stack_fffffffffffffad8, 
                                     (int64_t)in_stack_fffffffffffffae0, in_stack_fffffffffffffae8, (int64_t)ppiVar34, 
                                     CONCAT44(in_stack_fffffffffffffafc, in_stack_fffffffffffffaf8), (int64_t)ppiVar41, 
                                     CONCAT44(in_stack_fffffffffffffb0c, in_stack_fffffffffffffb08), 
                                     (int64_t)in_stack_fffffffffffffb10, (int64_t)in_stack_fffffffffffffb18, 
                                     CONCAT44(in_stack_fffffffffffffb24, in_stack_fffffffffffffb20), 
                                     (int64_t)in_stack_fffffffffffffb28, 
                                     CONCAT44(in_stack_fffffffffffffb34, in_stack_fffffffffffffb30), 
                                     CONCAT44(in_stack_fffffffffffffb44, in_stack_fffffffffffffb40), 
                                     (int64_t)arg_148h_00, (int64_t)in_stack_fffffffffffffb70, 
                                     (int64_t)in_stack_fffffffffffffb78, in_stack_fffffffffffffb80, 
                                     in_stack_fffffffffffffb88, in_stack_fffffffffffffb90, 
                                     CONCAT44(in_stack_fffffffffffffb9c, iVar46), in_stack_fffffffffffffba8, 
                                     in_stack_fffffffffffffbb0, (int64_t)in_stack_fffffffffffffbb8, 
                                     in_stack_fffffffffffffbc0, in_stack_fffffffffffffbc8, in_stack_fffffffffffffbd0, 
                                     iVar30, (int64_t)in_stack_fffffffffffffbe0, in_stack_fffffffffffffbe8, 
                                     in_stack_fffffffffffffbf0, (int64_t)in_stack_fffffffffffffbf8, 
                                     in_stack_fffffffffffffc00, in_stack_fffffffffffffc08, in_stack_fffffffffffffc10, 
                                     (int64_t)in_stack_fffffffffffffc18, (int64_t)in_stack_fffffffffffffc20);
            fcn.1800ef070(var_570h);
            *(int64_t *)((int64_t)ppiVar37 + 0xc) = var_588h;
            _var_588h = *(undefined (*) [16])(arg1 + 0x84);
            uStack_3b8 = CONCAT44(in_stack_fffffffffffffb40, uStack_4c4);
            iStack_3bc = iVar15;
            cVar13 = func_0x0001800ef810(arg1, 0x128);
            *(char *)(ppiVar37 + 7) = cVar13;
            if (cVar13 != '\0') {
                *(int64_t *)((int64_t)ppiVar37 + 0x14) = var_580h;
            }
            if (*(char *)(arg1 + 0x58) != '\0') {
                ppiVar31 = *(int64_t ***)(arg1 + 0xd8);
                if (cVar13 == '\0') {
                    in_stack_fffffffffffffbc0 = -1;
                    iVar32 = -1;
                } else {
                    iVar32 = var_588h;
                }
                iVar24 = (int64_t)*ppiVar31;
                if (iVar24 == 0) {
code_r0x0001800db204:
                    piVar18 = (int64_t *)func_0x000180459890(0x2008);
                    *piVar18 = (int64_t)*ppiVar31;
                    *ppiVar31 = piVar18;
                    piVar18 = piVar18 + 1;
                    piVar22 = (int64_t *)0x14;
                } else {
                    piVar18 = (int64_t *)((int64_t)ppiVar31[1] + iVar24 + 0xf & 0xfffffffffffffff8);
                    if (iVar24 + 0x2008U < (int64_t)piVar18 + 0x14U) goto code_r0x0001800db204;
                    piVar22 = (int64_t *)((int64_t)piVar18 + (0x14 - (iVar24 + 8)));
                }
                ppiVar31[1] = piVar22;
                *(undefined4 *)piVar18 = *(undefined4 *)0x180782abc;
                *(undefined8 *)((int64_t)piVar18 + 4) = uVar21;
                *(int64_t *)((int64_t)piVar18 + 0xc) = iVar32;
                var_570h = (int64_t)ppiVar37;
                ppiVar31 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_570h);
                *ppiVar31 = piVar18;
            }
            break;
        case 0x12a:
            _var_588h = *(undefined (*) [16])(arg1 + 0x84);
            func_0x0001800f0350(arg1);
            func_0x0001800e4090(arg1, &piStack_498, 0);
            if (*(int32_t *)(arg1 + 0x80) == 0x3d) {
                uVar21 = *(undefined8 *)(arg1 + 0x84);
                func_0x0001800f0350(arg1);
                var_570h = func_0x0001800e9350(arg1, 0);
                if (*(int32_t *)(arg1 + 0x80) == 0x2c) {
                    func_0x0001800f0350(arg1);
code_r0x0001800db2d9:
                    in_stack_fffffffffffffba8 = *(int64_t *)(arg1 + 0xa0);
                } else {
                    cVar13 = func_0x0001800ef2a0(arg1, 0x2c, 0x180642988);
                    if (cVar13 != '\0') goto code_r0x0001800db2d9;
                    in_stack_fffffffffffffba8 = -1;
                }
                in_stack_fffffffffffffb28 = (int64_t **)func_0x0001800e9350(arg1, 0);
                uStack_460 = 0xffffffffffffffff;
                in_stack_fffffffffffffaa0 = (int64_t **)0x0;
                if (*(int32_t *)(arg1 + 0x80) == 0x2c) {
                    uStack_460 = *(undefined8 *)(arg1 + 0x84);
                    func_0x0001800f0350(arg1);
                    in_stack_fffffffffffffaa0 = (int64_t **)func_0x0001800e9350(arg1, 0);
                }
                var_578h = CONCAT44(var_578h._4_4_, *(int32_t *)(arg1 + 0x80));
                uVar42 = *(undefined4 *)(arg1 + 0x84);
                in_stack_fffffffffffffaf8 = *(undefined4 *)(arg1 + 0x88);
                in_stack_fffffffffffffafc = *(int32_t *)(arg1 + 0x8c);
                uVar39 = *(undefined4 *)(arg1 + 0x90);
                uVar44 = *(undefined4 *)(arg1 + 0x94);
                in_stack_fffffffffffffb08 = *(undefined4 *)(arg1 + 0x98);
                in_stack_fffffffffffffb0c = *(undefined4 *)(arg1 + 0x9c);
                if (*(int32_t *)(arg1 + 0x80) == 0x125) {
                    func_0x0001800f0350(arg1);
                    var_5a8h._0_1_ = 1;
                } else {
                    var_5a8h._0_1_ = func_0x0001800ef2a0(arg1, 0x125, 0x180642998);
                }
                piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x150) + -4);
                *piVar1 = *piVar1 + 1;
                piVar18 = (int64_t *)func_0x0001800eef70(arg1, &piStack_498);
                piVar22 = (int64_t *)fcn.1800dadd0(arg1);
                piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x150) + -4);
                *piVar1 = *piVar1 + -1;
                fcn.1800ef070(var_570h);
                in_stack_fffffffffffffb20 = *(undefined4 *)(arg1 + 0x8c);
                in_stack_fffffffffffffb24 = *(undefined4 *)(arg1 + 0x90);
                uStack_3b0 = (undefined4)var_578h;
                uStack_3ac = CONCAT44(in_stack_fffffffffffffaf8, uVar42);
                uVar11 = func_0x0001800ef810(arg1, 0x128);
                *(undefined *)(piVar22 + 7) = uVar11;
                uStack_230 = var_588h;
                uStack_228 = CONCAT44(in_stack_fffffffffffffb24, in_stack_fffffffffffffb20);
                ppiVar37 = (int64_t **)func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), 0x68);
                ppiVar41 = (int64_t **)CONCAT44(uVar44, uVar39);
                ppiVar34 = (int64_t **)CONCAT44(uVar42, uVar38);
                *(undefined4 *)(ppiVar37 + 1) = *(undefined4 *)0x180782778;
                *(undefined4 *)((int64_t)ppiVar37 + 0xc) = (undefined4)uStack_230;
                *(undefined4 *)(ppiVar37 + 2) = uStack_230._4_4_;
                *(undefined4 *)((int64_t)ppiVar37 + 0x14) = (undefined4)uStack_228;
                *(undefined4 *)(ppiVar37 + 3) = uStack_228._4_4_;
                *(undefined *)(ppiVar37 + 4) = 0;
                *ppiVar37 = (int64_t *)0x180641a40;
                ppiVar37[5] = piVar18;
                ppiVar37[6] = (int64_t *)var_570h;
                ppiVar37[7] = (int64_t *)in_stack_fffffffffffffb28;
                ppiVar37[8] = (int64_t *)in_stack_fffffffffffffaa0;
                ppiVar37[9] = piVar22;
                *(undefined *)(ppiVar37 + 10) = (undefined)var_5a8h;
                *(undefined4 *)((int64_t)ppiVar37 + 0x54) = uVar42;
                *(undefined4 *)(ppiVar37 + 0xb) = in_stack_fffffffffffffaf8;
                *(int32_t *)((int64_t)ppiVar37 + 0x5c) = in_stack_fffffffffffffafc;
                *(undefined4 *)(ppiVar37 + 0xc) = uVar39;
                in_stack_fffffffffffffb18 = ppiVar37;
                if (*(char *)(arg1 + 0x58) != '\0') {
                    puVar19 = (undefined4 *)func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), 0x24);
                    var_570h = (int64_t)ppiVar37;
                    *puVar19 = *(undefined4 *)0x180782a4c;
                    *(int64_t *)(puVar19 + 1) = in_stack_fffffffffffffb88;
                    *(undefined8 *)(puVar19 + 3) = uVar21;
                    *(int64_t *)(puVar19 + 5) = in_stack_fffffffffffffba8;
                    *(undefined8 *)(puVar19 + 7) = uStack_460;
                    ppiVar37 = (int64_t **)var_570h;
                    puVar20 = (undefined8 *)func_0x0001800cc970(arg1 + 0x490, &var_570h);
                    ppiVar41 = (int64_t **)CONCAT44(uVar44, uVar39);
                    ppiVar34 = (int64_t **)CONCAT44(uVar42, uVar38);
                    *puVar20 = puVar19;
                    in_stack_fffffffffffffb18 = ppiVar37;
                }
            } else {
                ppiVar41 = (int64_t **)(arg1 + 0x2f0);
                ppiVar37 = (int64_t **)((*(int64_t *)(arg1 + 0x2f8) - (int64_t)*ppiVar41 >> 4) * -0x5555555555555555);
                ppiVar17 = (int64_t **)0x0;
                uStack_380 = 0;
                uStack_378 = 0;
                func_0x0001800f1c30(&stack0xfffffffffffffac8, &piStack_498);
                if (*(int32_t *)(arg1 + 0x80) == 0x2c) {
                    if (*(char *)(arg1 + 0x58) == '\0') {
                        func_0x0001800f0350(arg1);
                        var_5c0h = 0;
                        var_5c8h = 0;
                    } else {
                        var_570h = *(int64_t *)(arg1 + 0x84);
                        func_0x0001800f0350(arg1);
                        var_5c0h = (int64_t)&var_570h;
                        var_5c8h = (int64_t)&uStack_380;
                    }
                    var_5b0h._0_1_ = 0;
                    var_5b8h = 0;
                    func_0x0001800e4340(arg1, &piStack_498, &stack0xfffffffffffffac8, 0);
                }
                auVar3 = *(undefined (*) [16])(arg1 + 0x84);
                if (*(int32_t *)(arg1 + 0x80) == 0x12d) {
                    func_0x0001800f0350(arg1);
                    var_5a8h._0_1_ = 1;
                } else {
                    var_5a8h._0_1_ = func_0x0001800ef2a0(arg1, 0x12d, 0x180642998);
                }
                in_stack_fffffffffffffaa8 = (int64_t **)(arg1 + 0x290);
                in_stack_fffffffffffffab0._8_8_ = 0;
                in_stack_fffffffffffffab0._0_8_ = *(int64_t *)(arg1 + 0x298) - (int64_t)*in_stack_fffffffffffffaa8 >> 3;
                in_stack_fffffffffffffbf8 = (int64_t *)(arg1 + 0x440);
                in_stack_fffffffffffffc00 = *(int64_t *)(arg1 + 0x448) - *in_stack_fffffffffffffbf8 >> 3;
                in_stack_fffffffffffffc08 = 0;
                ppiVar34 = (int64_t **)&stack0xfffffffffffffbf8;
                if (*(char *)(arg1 + 0x58) == '\0') {
                    ppiVar34 = ppiVar31;
                }
                func_0x0001800e3fd0(arg1, &stack0xfffffffffffffaa8, ppiVar34);
                var_578h = CONCAT44(var_578h._4_4_, *(int32_t *)(arg1 + 0x80));
                uStack_4c4 = *(undefined4 *)(arg1 + 0x84);
                in_stack_fffffffffffffb40 = *(undefined4 *)(arg1 + 0x88);
                in_stack_fffffffffffffb44 = *(undefined4 *)(arg1 + 0x8c);
                uVar38 = *(undefined4 *)(arg1 + 0x90);
                if (*(int32_t *)(arg1 + 0x80) == 0x125) {
                    func_0x0001800f0350(arg1);
                    var_598h._0_1_ = 1;
                } else {
                    var_598h._0_1_ = func_0x0001800ef2a0(arg1, 0x125, 0x180642998);
                }
                iVar24 = *(int64_t *)(arg1 + 0x198) - *(int64_t *)(arg1 + 400) >> 3;
                piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x150) + -4);
                *piVar1 = *piVar1 + 1;
                ppiVar27 = (int64_t **)(arg1 + 0x308);
                iVar32 = *(int64_t *)(arg1 + 0x310) - (int64_t)*ppiVar27;
                in_stack_fffffffffffffb18 = (int64_t **)(iVar32 >> 3);
                in_stack_fffffffffffffaf8 = SUB84(in_stack_fffffffffffffb18, 0);
                in_stack_fffffffffffffafc = (int32_t)(iVar32 >> 0x23);
                ppiVar28 = ppiVar31;
                in_stack_fffffffffffffac0 = ppiVar41;
                in_stack_fffffffffffffac8 = ppiVar41;
                in_stack_fffffffffffffad0 = ppiVar37;
                in_stack_fffffffffffffad8 = ppiVar17;
                in_stack_fffffffffffffb10 = ppiVar37;
                ppiVar34 = ppiVar27;
                if (ppiVar17 != (int64_t **)0x0) {
                    do {
                        var_570h = func_0x0001800eef70(arg1, *ppiVar41 + ((int64_t)ppiVar31 + (int64_t)ppiVar37) * 6);
                        func_0x0001800bf890(ppiVar27, &var_570h);
                        ppiVar28 = (int64_t **)((int64_t)ppiVar28 + 1);
                        ppiVar31 = (int64_t **)((int64_t)ppiVar31 + 1);
                    } while (ppiVar31 < ppiVar17);
                }
                ppiVar41 = ppiVar28;
                iVar32 = fcn.1800dae50(arg1, var_5c0h, var_5a0h, CONCAT71(var_598h._1_7_, (undefined)var_598h), 
                                       in_stack_fffffffffffffa70, var_580h, var_570h, 
                                       CONCAT44(in_stack_fffffffffffffa9c, in_stack_fffffffffffffa98), 
                                       (int64_t)in_stack_fffffffffffffaa0, (int64_t)in_stack_fffffffffffffaa8, 
                                       in_stack_fffffffffffffab0._0_8_, in_stack_fffffffffffffab0._8_8_, 
                                       (int64_t)in_stack_fffffffffffffac0, (int64_t)in_stack_fffffffffffffac8, 
                                       (int64_t)in_stack_fffffffffffffad0, (int64_t)in_stack_fffffffffffffad8, 
                                       (int64_t)in_stack_fffffffffffffae0, in_stack_fffffffffffffae8, (int64_t)ppiVar34
                                       , CONCAT44(in_stack_fffffffffffffafc, in_stack_fffffffffffffaf8), 
                                       (int64_t)ppiVar28, CONCAT44(in_stack_fffffffffffffb0c, in_stack_fffffffffffffb08)
                                       , (int64_t)in_stack_fffffffffffffb10, (int64_t)in_stack_fffffffffffffb18, 
                                       CONCAT44(in_stack_fffffffffffffb24, in_stack_fffffffffffffb20), iVar24, 
                                       CONCAT44(in_stack_fffffffffffffb34, in_stack_fffffffffffffb30), 
                                       CONCAT44(in_stack_fffffffffffffb44, in_stack_fffffffffffffb40), 
                                       (int64_t)arg_148h_00, (int64_t)in_stack_fffffffffffffb70, 
                                       (int64_t)in_stack_fffffffffffffb78, in_stack_fffffffffffffb80, 
                                       in_stack_fffffffffffffb88, in_stack_fffffffffffffb90, 
                                       CONCAT44(in_stack_fffffffffffffb9c, iVar46), in_stack_fffffffffffffba8, 
                                       in_stack_fffffffffffffbb0, (int64_t)in_stack_fffffffffffffbb8, 
                                       in_stack_fffffffffffffbc0, in_stack_fffffffffffffbc8, in_stack_fffffffffffffbd0, 
                                       iVar30, (int64_t)in_stack_fffffffffffffbe0, in_stack_fffffffffffffbe8, 
                                       in_stack_fffffffffffffbf0, (int64_t)in_stack_fffffffffffffbf8, 
                                       in_stack_fffffffffffffc00, in_stack_fffffffffffffc08, in_stack_fffffffffffffc10, 
                                       (int64_t)in_stack_fffffffffffffc18, (int64_t)in_stack_fffffffffffffc20);
                var_570h = iVar32;
                fcn.1800ef070(iVar32);
                piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x150) + -4);
                *piVar1 = *piVar1 + -1;
                fcn.1800ef070(var_570h);
                piStack_498 = *(int64_t **)(arg1 + 0x84);
                in_stack_fffffffffffffb70 = *(int64_t **)(arg1 + 0x8c);
                uStack_3a4 = (undefined4)var_578h;
                uStack_3a0 = CONCAT44(in_stack_fffffffffffffb40, uStack_4c4);
                uVar11 = func_0x0001800ef810(arg1, 0x128, &uStack_3a4);
                *(undefined *)(iVar32 + 0x38) = uVar11;
                ppiVar31 = *(int64_t ***)(arg1 + 0xd8);
                in_R9 = in_stack_fffffffffffffab0._8_8_;
                var_5a0h = in_stack_fffffffffffffab0._0_8_;
                if (in_R9 == (int64_t **)0x0) {
                    piVar18 = (int64_t *)0x0;
                } else {
                    piVar18 = *in_stack_fffffffffffffaa8 + var_5a0h;
                }
                in_stack_fffffffffffffaa0 = ppiVar31;
                in_stack_fffffffffffffb28 = in_stack_fffffffffffffaa8;
                func_0x0001800f1110(arg1, &uStack_110, piVar18);
                if (ppiVar28 == (int64_t **)0x0) {
                    piVar18 = (int64_t *)0x0;
                } else {
                    piVar18 = *ppiVar27 + (int64_t)in_stack_fffffffffffffb18;
                }
                if (ppiVar28 == (int64_t **)0x0) {
                    piVar22 = (int64_t *)0x0;
                } else {
                    piVar22 = (int64_t *)func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), (int64_t)ppiVar28 * 8);
                    ppiVar37 = (int64_t **)0x0;
                    ppiVar31 = in_stack_fffffffffffffaa0;
                    if (((int64_t **)0x1 < ppiVar28) &&
                       ((piVar18 + (int64_t)ppiVar28 + -1 < piVar22 || (piVar22 + (int64_t)ppiVar28 + -1 < piVar18)))) {
                        func_0x000180498030(piVar22, piVar18, (int64_t)ppiVar28 * 8);
                        do {
                            ppiVar37 = (int64_t **)((int64_t)ppiVar37 + 1);
                            ppiVar31 = in_stack_fffffffffffffaa0;
                        } while (ppiVar37 < ppiVar28);
                    }
                    for (; in_stack_fffffffffffffaa0 = ppiVar31, ppiVar37 < ppiVar28;
                        ppiVar37 = (int64_t **)((int64_t)ppiVar37 + 1)) {
                        piVar22[(int64_t)ppiVar37] = piVar18[(int64_t)ppiVar37];
                    }
                }
                uStack_220 = var_588h;
                piVar18 = *ppiVar31;
                uStack_218 = in_stack_fffffffffffffb70;
                if (piVar18 == (int64_t *)0x0) {
code_r0x0001800db8f2:
                    ppiVar37 = (int64_t **)func_0x000180459890(0x2008);
                    *ppiVar37 = *ppiVar31;
                    *ppiVar31 = (int64_t *)ppiVar37;
                    ppiVar37 = ppiVar37 + 1;
                    piVar18 = (int64_t *)0x78;
                } else {
                    ppiVar37 = (int64_t **)((int64_t)ppiVar31[1] + 7 + (int64_t)(piVar18 + 1) & 0xfffffffffffffff8);
                    if (piVar18 + 0x401 < ppiVar37 + 0xf) goto code_r0x0001800db8f2;
                    piVar18 = (int64_t *)((int64_t)ppiVar37 + (0x78 - (int64_t)(piVar18 + 1)));
                }
                ppiVar31[1] = piVar18;
                *(undefined4 *)(ppiVar37 + 1) = *(undefined4 *)0x180782780;
                *(undefined4 *)((int64_t)ppiVar37 + 0xc) = (undefined4)uStack_220;
                *(undefined4 *)(ppiVar37 + 2) = uStack_220._4_4_;
                *(undefined4 *)((int64_t)ppiVar37 + 0x14) = (undefined4)uStack_218;
                *(undefined4 *)(ppiVar37 + 3) = uStack_218._4_4_;
                *(undefined *)(ppiVar37 + 4) = 0;
                *ppiVar37 = (int64_t *)0x180641c30;
                ppiVar37[5] = piVar22;
                ppiVar37[6] = (int64_t *)ppiVar28;
                *(undefined4 *)(ppiVar37 + 7) = uStack_110;
                *(undefined4 *)((int64_t)ppiVar37 + 0x3c) = uStack_10c;
                *(undefined4 *)(ppiVar37 + 8) = uStack_108;
                *(undefined4 *)((int64_t)ppiVar37 + 0x44) = uStack_104;
                ppiVar37[9] = (int64_t *)var_570h;
                *(undefined *)(ppiVar37 + 10) = (undefined)var_5a8h;
                *(undefined (*) [16])((int64_t)ppiVar37 + 0x54) = auVar3;
                *(undefined *)((int64_t)ppiVar37 + 100) = (undefined)var_598h;
                *(undefined4 *)(ppiVar37 + 0xd) = uStack_4c4;
                *(undefined4 *)((int64_t)ppiVar37 + 0x6c) = in_stack_fffffffffffffb40;
                *(undefined4 *)(ppiVar37 + 0xe) = in_stack_fffffffffffffb44;
                *(undefined4 *)((int64_t)ppiVar37 + 0x74) = uVar38;
                if (*(char *)(arg1 + 0x58) != '\0') {
                    ppiVar31 = *(int64_t ***)(arg1 + 0xd8);
                    puVar19 = (undefined4 *)func_0x0001800f0e50(arg1, auStack_e0, &stack0xfffffffffffffbf8);
                    var_570h = func_0x0001800e4200(arg1, auStack_d0, &stack0xfffffffffffffac8);
                    iVar32 = (int64_t)*ppiVar31;
                    if (iVar32 == 0) {
code_r0x0001800db9f0:
                        piVar18 = (int64_t *)func_0x000180459890(0x2008);
                        *piVar18 = (int64_t)*ppiVar31;
                        *ppiVar31 = piVar18;
                        piVar18 = piVar18 + 1;
                        piVar22 = (int64_t *)0x38;
                    } else {
                        piVar18 = (int64_t *)((int64_t)ppiVar31[1] + iVar32 + 0xf & 0xfffffffffffffff8);
                        if ((int64_t *)(iVar32 + 0x2008U) < piVar18 + 7) goto code_r0x0001800db9f0;
                        piVar22 = (int64_t *)((int64_t)piVar18 + (0x38 - (iVar32 + 8)));
                    }
                    ppiVar31[1] = piVar22;
                    uVar38 = *puVar19;
                    uVar39 = puVar19[1];
                    uVar44 = puVar19[2];
                    uVar42 = puVar19[3];
                    uVar43 = *(undefined4 *)var_570h;
                    uVar7 = *(undefined4 *)(var_570h + 4);
                    uVar8 = *(undefined4 *)(var_570h + 8);
                    uVar9 = *(undefined4 *)(var_570h + 0xc);
                    *(undefined4 *)piVar18 = *(undefined4 *)0x180782ac8;
                    *(undefined4 *)(piVar18 + 1) = uVar43;
                    *(undefined4 *)((int64_t)piVar18 + 0xc) = uVar7;
                    *(undefined4 *)(piVar18 + 2) = uVar8;
                    *(undefined4 *)((int64_t)piVar18 + 0x14) = uVar9;
                    *(undefined4 *)(piVar18 + 3) = (undefined4)uStack_380;
                    *(undefined4 *)((int64_t)piVar18 + 0x1c) = uStack_380._4_4_;
                    *(undefined4 *)(piVar18 + 4) = (undefined4)uStack_378;
                    *(undefined4 *)((int64_t)piVar18 + 0x24) = uStack_378._4_4_;
                    *(undefined4 *)(piVar18 + 5) = uVar38;
                    *(undefined4 *)((int64_t)piVar18 + 0x2c) = uVar39;
                    *(undefined4 *)(piVar18 + 6) = uVar44;
                    *(undefined4 *)((int64_t)piVar18 + 0x34) = uVar42;
                    var_570h = (int64_t)ppiVar37;
                    ppiVar31 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_570h);
                    *ppiVar31 = piVar18;
                }
                iVar32 = *(int64_t *)(arg1 + 0x308) + (int64_t)in_stack_fffffffffffffb18 * 8;
                if (iVar32 != *(int64_t *)(arg1 + 0x310)) {
                    *(int64_t *)(arg1 + 0x310) = iVar32;
                }
                iVar32 = *in_stack_fffffffffffffbf8 + in_stack_fffffffffffffc00 * 8;
                if (iVar32 != in_stack_fffffffffffffbf8[1]) {
                    in_stack_fffffffffffffbf8[1] = iVar32;
                }
                if (*in_stack_fffffffffffffb28 + var_5a0h != in_stack_fffffffffffffb28[1]) {
                    in_stack_fffffffffffffb28[1] = *in_stack_fffffffffffffb28 + var_5a0h;
                }
                if (*in_stack_fffffffffffffac0 + (int64_t)in_stack_fffffffffffffb10 * 6 != in_stack_fffffffffffffac0[1])
                {
                    in_stack_fffffffffffffac0[1] = *in_stack_fffffffffffffac0 + (int64_t)in_stack_fffffffffffffb10 * 6;
                }
            }
            break;
        case 299:
            uStack_1e0 = 0;
            uStack_1d8 = 0;
            piStack_498 = *(int64_t **)(arg1 + 0x84);
            in_stack_fffffffffffffb70 = *(int64_t **)(arg1 + 0x8c);
            uStack_4c8 = *(undefined4 *)(arg1 + 0x80);
            uStack_4c4 = *(undefined4 *)(arg1 + 0x84);
            in_stack_fffffffffffffb40 = *(undefined4 *)(arg1 + 0x88);
            in_stack_fffffffffffffb44 = *(undefined4 *)(arg1 + 0x8c);
            func_0x0001800f0350(arg1);
            var_5a0h = 0;
            if (*(int32_t *)(arg1 + 0x80) == 0x119) {
                var_5a0h = *(int64_t *)(arg1 + 0x98);
            }
            piVar18 = (int64_t *)func_0x0001800ea720(arg1, 0x180642a80);
            var_578h = CONCAT44(var_578h._4_4_, *(undefined4 *)(arg1 + 0x114));
            iVar15 = *(int32_t *)(arg1 + 0x80);
            while (iVar15 == 0x2e) {
                iVar32 = *(int64_t *)(arg1 + 0x84);
                func_0x0001800f0350(arg1);
                if (*(int32_t *)(arg1 + 0x80) == 0x119) {
                    uVar42 = (undefined4)*(undefined8 *)(arg1 + 0x98);
                    uVar43 = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x98) >> 0x20);
                    auVar3 = *(undefined (*) [16])(arg1 + 0x84);
                    uVar38 = auVar3._0_4_;
                    iVar15 = auVar3._4_4_;
                    uVar39 = auVar3._8_4_;
                    iVar40 = auVar3._12_4_;
                    uVar44 = uVar39;
                    iVar45 = iVar40;
                    func_0x0001800f0350(arg1);
                    ppiVar41 = (int64_t **)CONCAT44(iVar45, uVar44);
                    ppiVar31 = (int64_t **)CONCAT44(uVar43, uVar42);
                    in_stack_fffffffffffffaa8 = ppiVar31;
                    in_stack_fffffffffffffaf8 = uVar38;
                    in_stack_fffffffffffffafc = iVar15;
                    ppiVar34 = ppiVar31;
                } else {
                    func_0x0001800efe90(arg1, 0x180642a90);
                    auVar10 = *(undefined (*) [12])(arg1 + 0x84);
                    var_588h = auVar10._0_8_;
                    var_580h = var_588h;
                    auVar3 = _var_588h;
                    ppiVar31 = *(int64_t ***)(arg1 + 0x128);
                    var_588h._0_4_ = auVar10._0_4_;
                    var_588h._4_4_ = auVar10._4_4_;
                    uVar38 = (undefined4)var_588h;
                    iVar15 = var_588h._4_4_;
                    uVar39 = (undefined4)var_588h;
                    iVar40 = var_588h._4_4_;
                    _var_588h = auVar3;
                }
                in_stack_fffffffffffffab0._4_4_ = iVar15;
                in_stack_fffffffffffffab0._0_4_ = uVar38;
                in_stack_fffffffffffffab0._8_4_ = uVar39;
                in_stack_fffffffffffffab0._12_4_ = iVar40;
                uStack_200 = *(undefined8 *)((int64_t)piVar18 + 0xc);
                uStack_1f8 = in_stack_fffffffffffffab0._8_8_;
                var_5a0h = (int64_t)ppiVar31;
                piVar22 = (int64_t *)func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), 0x50);
                *(int32_t *)(piVar22 + 1) = *(int32_t *)0x18078269c;
                *(undefined4 *)((int64_t)piVar22 + 0xc) = (undefined4)uStack_200;
                *(undefined4 *)(piVar22 + 2) = uStack_200._4_4_;
                *(undefined4 *)((int64_t)piVar22 + 0x14) = (undefined4)uStack_1f8;
                *(undefined4 *)(piVar22 + 3) = uStack_1f8._4_4_;
                *piVar22 = 0x180641ca8;
                piVar22[4] = (int64_t)piVar18;
                piVar22[5] = (int64_t)ppiVar31;
                auVar3._4_4_ = iVar15;
                auVar3._0_4_ = uVar38;
                auVar3._8_4_ = uVar39;
                auVar3._12_4_ = iVar40;
                *(undefined (*) [16])(piVar22 + 6) = auVar3;
                piVar22[8] = iVar32;
                *(undefined *)(piVar22 + 9) = 0x2e;
                uVar14 = *(int32_t *)(arg1 + 0x114) + 1;
                *(uint32_t *)(arg1 + 0x114) = uVar14;
                if (*(uint32_t *)0x180778500 < uVar14) {
                    iVar30 = func_0x0001800d90d0(arg1 + 0x60);
                    fcn.1800d9940(iVar30 + 4, 0x180644050, 0x180642a80, (int64_t)in_R9);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                piVar18 = piVar22;
                iVar15 = *(int32_t *)(arg1 + 0x80);
            }
            *(undefined4 *)(arg1 + 0x114) = (undefined4)var_578h;
            piVar22 = piVar18;
            if (iVar15 == 0x3a) {
                iVar32 = *(int64_t *)(arg1 + 0x84);
                func_0x0001800f0350(arg1);
                ppiVar31 = ppiVar34;
                func_0x0001800ecb20(arg1, &stack0xfffffffffffffaf0, 0x180642aa0);
                uStack_1e8 = ppiVar41;
                uStack_1f0 = *(undefined8 *)((int64_t)piVar18 + 0xc);
                var_5a0h = (int64_t)ppiVar31;
                ppiVar34 = ppiVar31;
                ppiVar41 = uStack_1e8;
                piVar22 = (int64_t *)func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), 0x50);
                *(int32_t *)(piVar22 + 1) = *(int32_t *)0x18078269c;
                *(undefined4 *)((int64_t)piVar22 + 0xc) = (undefined4)uStack_1f0;
                *(undefined4 *)(piVar22 + 2) = uStack_1f0._4_4_;
                *(undefined4 *)((int64_t)piVar22 + 0x14) = (undefined4)uStack_1e8;
                *(undefined4 *)(piVar22 + 3) = uStack_1e8._4_4_;
                *piVar22 = 0x180641ca8;
                piVar22[4] = (int64_t)piVar18;
                piVar22[5] = (int64_t)ppiVar31;
                *(undefined4 *)(piVar22 + 6) = in_stack_fffffffffffffaf8;
                *(int32_t *)((int64_t)piVar22 + 0x34) = in_stack_fffffffffffffafc;
                piVar22[7] = (int64_t)ppiVar41;
                piVar22[8] = iVar32;
                *(undefined *)(piVar22 + 9) = 0x3a;
            }
            if ((*(char *)0x180778460 != '\0') && (cVar13 = func_0x0001800de090(piVar22), cVar13 == '\0')) {
                if (*(char *)0x180778520 == '\0') {
                    piStack_368 = piVar22;
                    func_0x0001800f1110(arg1, auStack_140, &piStack_368, 1);
                    piVar22 = (int64_t *)func_0x0001800f0080(arg1, (int64_t)piVar22 + 0xc, auStack_140, 0x180642ab0);
                } else {
                    piVar22 = (int64_t *)func_0x0001800e2de0(arg1, piVar22);
                }
            }
            piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x1e8) + 0x4a0);
            *piVar1 = *piVar1 + 1;
            var_5b0h._0_1_ = 0;
            var_5b8h = (int64_t)&uStack_1e0;
            var_5c0h = 0;
            var_5c8h = (int64_t)&var_5a0h;
            in_R9 = (int64_t **)&uStack_4c8;
            ppiVar31 = (int64_t **)func_0x0001800e3690(arg1, auStack_c0, iVar15 == 0x3a);
            piVar18 = *ppiVar31;
            piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x1e8) + 0x4a0);
            *piVar1 = *piVar1 + -1;
            uStack_1d0 = piStack_498;
            uStack_1c8 = *(undefined8 *)((int64_t)piVar18 + 0x14);
            ppiVar37 = (int64_t **)func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), 0x38);
            *(undefined4 *)(ppiVar37 + 1) = *(undefined4 *)0x180782690;
            *(undefined4 *)((int64_t)ppiVar37 + 0xc) = (undefined4)uStack_1d0;
            *(undefined4 *)(ppiVar37 + 2) = uStack_1d0._4_4_;
            *(undefined4 *)((int64_t)ppiVar37 + 0x14) = (undefined4)uStack_1c8;
            *(undefined4 *)(ppiVar37 + 3) = uStack_1c8._4_4_;
            *(undefined *)(ppiVar37 + 4) = 0;
            *ppiVar37 = (int64_t *)0x180641d48;
            ppiVar37[5] = piVar22;
            ppiVar37[6] = piVar18;
            if (*(char *)(arg1 + 0x58) != '\0') {
                puVar19 = (undefined4 *)func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), 0xc);
                *puVar19 = *(undefined4 *)0x180782a68;
                *(uint64_t *)(puVar19 + 1) = CONCAT44(in_stack_fffffffffffffb40, uStack_4c4);
                var_570h = (int64_t)ppiVar37;
                puVar20 = (undefined8 *)func_0x0001800cc970(arg1 + 0x490, &var_570h);
                *puVar20 = puVar19;
            }
            break;
        case 300:
            ppiVar37 = (int64_t **)func_0x0001800ddd50(arg1);
            break;
        case 0x12e:
            if (*(char *)0x180778460 == '\0') {
                uStack_340 = 0;
                uStack_338 = 0;
                ppiVar37 = (int64_t **)func_0x0001800dee80(arg1, &uStack_340);
            } else {
                piStack_498 = *(int64_t **)*(undefined (*) [16])(arg1 + 0x84);
                _var_588h = *(undefined (*) [16])(arg1 + 0x84);
                in_stack_fffffffffffffb70 = *(int64_t **)(arg1 + 0x8c);
                piStack_1c0 = (int64_t *)0x0;
                uStack_1b8 = 0;
                var_5c8h = var_5c8h & 0xffffffffffffff00;
                in_R9 = &piStack_1c0;
                ppiVar37 = (int64_t **)func_0x0001800df760(arg1, &var_588h, piStack_498);
            }
            break;
        case 0x132:
            uStack_4c4 = *(undefined4 *)(int64_t **)(arg1 + 0x84);
            in_stack_fffffffffffffb40 = *(undefined4 *)(arg1 + 0x88);
            piStack_498 = *(int64_t **)(arg1 + 0x84);
            in_stack_fffffffffffffb44 = *(undefined4 *)(int64_t **)(arg1 + 0x8c);
            in_stack_fffffffffffffb70 = *(int64_t **)(arg1 + 0x8c);
            func_0x0001800f0350(arg1, uStack_4c4);
            piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x150) + -4);
            *piVar1 = *piVar1 + 1;
            piVar18 = (int64_t *)
                      fcn.1800dae50(arg1, var_5c0h, var_5a0h, CONCAT71(var_598h._1_7_, (undefined)var_598h), 
                                    in_stack_fffffffffffffa70, var_580h, var_570h, 
                                    CONCAT44(in_stack_fffffffffffffa9c, in_stack_fffffffffffffa98), 
                                    (int64_t)in_stack_fffffffffffffaa0, (int64_t)in_stack_fffffffffffffaa8, 
                                    in_stack_fffffffffffffab0._0_8_, in_stack_fffffffffffffab0._8_8_, 
                                    (int64_t)in_stack_fffffffffffffac0, (int64_t)in_stack_fffffffffffffac8, 
                                    (int64_t)in_stack_fffffffffffffad0, (int64_t)in_stack_fffffffffffffad8, 
                                    (int64_t)in_stack_fffffffffffffae0, in_stack_fffffffffffffae8, (int64_t)ppiVar34, 
                                    CONCAT44(in_stack_fffffffffffffafc, in_stack_fffffffffffffaf8), (int64_t)ppiVar41, 
                                    CONCAT44(in_stack_fffffffffffffb0c, in_stack_fffffffffffffb08), 
                                    (int64_t)in_stack_fffffffffffffb10, (int64_t)in_stack_fffffffffffffb18, 
                                    CONCAT44(in_stack_fffffffffffffb24, in_stack_fffffffffffffb20), 
                                    (int64_t)in_stack_fffffffffffffb28, 
                                    CONCAT44(in_stack_fffffffffffffb34, in_stack_fffffffffffffb30), 
                                    CONCAT44(in_stack_fffffffffffffb44, in_stack_fffffffffffffb40), (int64_t)arg_148h_00
                                    , (int64_t)in_stack_fffffffffffffb70, (int64_t)in_stack_fffffffffffffb78, 
                                    in_stack_fffffffffffffb80, in_stack_fffffffffffffb88, in_stack_fffffffffffffb90, 
                                    CONCAT44(in_stack_fffffffffffffb9c, iVar46), in_stack_fffffffffffffba8, 
                                    in_stack_fffffffffffffbb0, (int64_t)in_stack_fffffffffffffbb8, 
                                    in_stack_fffffffffffffbc0, in_stack_fffffffffffffbc8, in_stack_fffffffffffffbd0, 
                                    iVar30, (int64_t)in_stack_fffffffffffffbe0, in_stack_fffffffffffffbe8, 
                                    in_stack_fffffffffffffbf0, (int64_t)in_stack_fffffffffffffbf8, 
                                    in_stack_fffffffffffffc00, in_stack_fffffffffffffc08, in_stack_fffffffffffffc10, 
                                    (int64_t)in_stack_fffffffffffffc18, (int64_t)in_stack_fffffffffffffc20);
            piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x150) + -4);
            *piVar1 = *piVar1 + -1;
            uStack_394 = CONCAT44(in_stack_fffffffffffffb40, uStack_4c4);
            iStack_398 = iVar15;
            cVar13 = func_0x0001800ef810(arg1, 0x136, &iStack_398);
            *(char *)(piVar18 + 7) = cVar13;
            if (cVar13 == '\0') {
                iVar32 = -1;
            } else {
                iVar32 = *(int64_t *)(arg1 + 0xa0);
            }
            in_stack_fffffffffffffbb0 = iVar32;
            piVar22 = (int64_t *)func_0x0001800e9350(arg1, 0);
            fcn.1800ef070(var_570h);
            uStack_210 = piStack_498;
            uStack_208 = *(undefined8 *)((int64_t)piVar22 + 0x14);
            ppiVar37 = (int64_t **)func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), 0x40);
            *(undefined4 *)(ppiVar37 + 1) = *(undefined4 *)0x180782684;
            *(undefined4 *)((int64_t)ppiVar37 + 0xc) = (undefined4)uStack_210;
            *(undefined4 *)(ppiVar37 + 2) = uStack_210._4_4_;
            *(undefined4 *)((int64_t)ppiVar37 + 0x14) = (undefined4)uStack_208;
            *(undefined4 *)(ppiVar37 + 3) = uStack_208._4_4_;
            *(undefined *)(ppiVar37 + 4) = 0;
            *ppiVar37 = (int64_t *)0x180641c80;
            ppiVar37[5] = piVar22;
            ppiVar37[6] = piVar18;
            *(char *)(ppiVar37 + 7) = cVar13;
            if (*(char *)(arg1 + 0x58) != '\0') {
                puVar19 = (undefined4 *)func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), 0xc);
                *puVar19 = *(undefined4 *)0x180782aa8;
                *(int64_t *)(puVar19 + 1) = iVar32;
                var_570h = (int64_t)ppiVar37;
                puVar20 = (undefined8 *)func_0x0001800cc970(arg1 + 0x490, &var_570h);
                *puVar20 = puVar19;
            }
            break;
        case 0x133:
            _var_588h = *(undefined (*) [16])(arg1 + 0x84);
            func_0x0001800f0350(arg1);
            ppiVar17 = (int64_t **)(arg1 + 0x290);
            var_5a0h = *(int64_t *)(arg1 + 0x298) - (int64_t)*ppiVar17 >> 3;
            in_R9 = (int64_t **)0x0;
            in_stack_fffffffffffffbe0 = (int64_t *)(arg1 + 0x440);
            in_stack_fffffffffffffbe8 = *(int64_t *)(arg1 + 0x448) - *in_stack_fffffffffffffbe0 >> 3;
            uVar29 = 0;
            iVar15 = *(int32_t *)(arg1 + 0x80);
            if (((iVar15 == 0) || (iVar15 - 0x126U < 3)) || ((iVar15 == 0x136 || (iVar15 == 0x3b)))) {
code_r0x0001800dc121:
                ppiVar37 = (int64_t **)&var_588h;
            } else {
                ppiVar37 = (int64_t **)&stack0xfffffffffffffbe0;
                if (*(char *)(arg1 + 0x58) == '\0') {
                    ppiVar37 = ppiVar31;
                }
                func_0x0001800e3fd0(arg1, &stack0xfffffffffffffac8, ppiVar37);
                if (in_R9 == (int64_t **)0x0) goto code_r0x0001800dc121;
                ppiVar37 = (int64_t **)(ppiVar17[1][-1] + 0xc);
            }
            iVar32 = var_5a0h;
            piStack_498 = *ppiVar37;
            in_stack_fffffffffffffb70 = ppiVar37[1];
            uVar21 = *(undefined8 *)(arg1 + 0xd8);
            if (in_R9 != (int64_t **)0x0) {
                ppiVar31 = (int64_t **)(*ppiVar17 + var_5a0h);
            }
            in_stack_fffffffffffffac8 = ppiVar17;
            in_stack_fffffffffffffad0 = (int64_t **)var_5a0h;
            in_stack_fffffffffffffad8 = in_R9;
            func_0x0001800f1110(arg1, &uStack_130, ppiVar31);
            uStack_330 = var_588h;
            uStack_328 = in_stack_fffffffffffffb70;
            ppiVar37 = (int64_t **)func_0x0001800d4d20(uVar21, 0x38);
            *(undefined4 *)(ppiVar37 + 1) = *(undefined4 *)0x1807826d0;
            *(undefined4 *)((int64_t)ppiVar37 + 0xc) = (undefined4)uStack_330;
            *(undefined4 *)(ppiVar37 + 2) = uStack_330._4_4_;
            *(undefined4 *)((int64_t)ppiVar37 + 0x14) = (undefined4)uStack_328;
            *(undefined4 *)(ppiVar37 + 3) = uStack_328._4_4_;
            *(undefined *)(ppiVar37 + 4) = 0;
            *ppiVar37 = (int64_t *)0x180641e10;
            *(undefined4 *)(ppiVar37 + 5) = uStack_130;
            *(undefined4 *)((int64_t)ppiVar37 + 0x2c) = uStack_12c;
            *(undefined4 *)(ppiVar37 + 6) = uStack_128;
            *(undefined4 *)((int64_t)ppiVar37 + 0x34) = uStack_124;
            in_stack_fffffffffffffbf0 = uVar29;
            if (*(char *)(arg1 + 0x58) != '\0') {
                in_stack_fffffffffffffaa0 = *(int64_t ***)(arg1 + 0xd8);
                if (uVar29 == 0) {
                    uVar16 = 0;
                    ppiVar17 = in_stack_fffffffffffffac8;
                } else {
                    iVar32 = in_stack_fffffffffffffbe8 * 8;
                    iVar24 = *in_stack_fffffffffffffbe0;
                    uVar16 = func_0x0001800d4d20(in_stack_fffffffffffffaa0, uVar29 * 8);
                    ppiVar17 = in_stack_fffffffffffffac8;
                    if (uVar29 != 0) {
                        uVar2 = iVar32 + iVar24;
                        uVar26 = 0;
                        if ((uVar29 < 2) ||
                           ((uVar16 <= uVar2 + (uVar29 - 1) * 8 && (uVar2 <= uVar16 + (uVar29 - 1) * 8)))) {
                            do {
                                *(undefined8 *)(uVar16 + uVar26 * 8) = *(undefined8 *)(uVar2 + uVar26 * 8);
                                uVar26 = uVar26 + 1;
                            } while (uVar26 < uVar29);
                        } else {
                            func_0x000180498030(uVar16, uVar2, uVar29 * 8);
                            ppiVar17 = in_stack_fffffffffffffac8;
                        }
                    }
                }
                puVar19 = (undefined4 *)func_0x0001800d4d20(in_stack_fffffffffffffaa0, 0x18);
                *puVar19 = *(undefined4 *)0x180782a48;
                *(uint64_t *)(puVar19 + 2) = uVar16;
                *(uint64_t *)(puVar19 + 4) = uVar29;
                var_570h = (int64_t)ppiVar37;
                puVar20 = (undefined8 *)func_0x0001800cc970(arg1 + 0x490, &var_570h);
                *puVar20 = puVar19;
                iVar32 = var_5a0h;
                in_stack_fffffffffffffac8 = ppiVar17;
            }
            if (((*(char *)0x180778520 != '\0') && (*(char *)0x180778460 != '\0')) &&
               (*(int64_t *)(arg1 + 0x150) - *(int64_t *)(arg1 + 0x148) == 8)) {
                if (*(int64_t *)(arg1 + 0x210) != 0) {
                    func_0x0001800efe70(arg1, (int64_t)ppiVar37 + 0xc, 0x180642b80);
                }
                *(undefined *)(arg1 + 0x228) = 1;
            }
            iVar24 = *in_stack_fffffffffffffbe0 + in_stack_fffffffffffffbe8 * 8;
            if (iVar24 != in_stack_fffffffffffffbe0[1]) {
                in_stack_fffffffffffffbe0[1] = iVar24;
            }
            if (*ppiVar17 + iVar32 != ppiVar17[1]) {
                ppiVar17[1] = *ppiVar17 + iVar32;
            }
            break;
        case 0x137:
            _var_588h = *(undefined (*) [16])(arg1 + 0x84);
            func_0x0001800f0350(arg1);
            var_570h = func_0x0001800e9350(arg1, 0);
            iVar15 = *(int32_t *)(arg1 + 0x80);
            uVar42 = *(undefined4 *)(arg1 + 0x84);
            in_stack_fffffffffffffaf8 = *(undefined4 *)(arg1 + 0x88);
            in_stack_fffffffffffffafc = *(int32_t *)(arg1 + 0x8c);
            uVar39 = *(undefined4 *)(arg1 + 0x90);
            uVar44 = *(undefined4 *)(arg1 + 0x94);
            in_stack_fffffffffffffb08 = *(undefined4 *)(arg1 + 0x98);
            in_stack_fffffffffffffb0c = *(undefined4 *)(arg1 + 0x9c);
            if (iVar15 == 0x125) {
                func_0x0001800f0350(arg1);
                uVar11 = 1;
            } else {
                uVar11 = func_0x0001800ef2a0(arg1, 0x125, 0x180642a00);
            }
            piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x150) + -4);
            *piVar1 = *piVar1 + 1;
            piVar18 = (int64_t *)
                      fcn.1800dae50(arg1, var_5c0h, var_5a0h, CONCAT71(var_598h._1_7_, (undefined)var_598h), 
                                    in_stack_fffffffffffffa70, var_580h, var_570h, 
                                    CONCAT44(in_stack_fffffffffffffa9c, in_stack_fffffffffffffa98), 
                                    (int64_t)in_stack_fffffffffffffaa0, (int64_t)in_stack_fffffffffffffaa8, 
                                    in_stack_fffffffffffffab0._0_8_, in_stack_fffffffffffffab0._8_8_, 
                                    (int64_t)in_stack_fffffffffffffac0, (int64_t)in_stack_fffffffffffffac8, 
                                    (int64_t)in_stack_fffffffffffffad0, (int64_t)in_stack_fffffffffffffad8, 
                                    (int64_t)in_stack_fffffffffffffae0, in_stack_fffffffffffffae8, 
                                    CONCAT44(uVar42, uVar38), 
                                    CONCAT44(in_stack_fffffffffffffafc, in_stack_fffffffffffffaf8), 
                                    CONCAT44(uVar44, uVar39), 
                                    CONCAT44(in_stack_fffffffffffffb0c, in_stack_fffffffffffffb08), 
                                    (int64_t)in_stack_fffffffffffffb10, (int64_t)in_stack_fffffffffffffb18, 
                                    CONCAT44(in_stack_fffffffffffffb24, in_stack_fffffffffffffb20), 
                                    (int64_t)in_stack_fffffffffffffb28, 
                                    CONCAT44(in_stack_fffffffffffffb34, in_stack_fffffffffffffb30), 
                                    CONCAT44(in_stack_fffffffffffffb44, in_stack_fffffffffffffb40), (int64_t)arg_148h_00
                                    , (int64_t)in_stack_fffffffffffffb70, (int64_t)in_stack_fffffffffffffb78, 
                                    in_stack_fffffffffffffb80, in_stack_fffffffffffffb88, in_stack_fffffffffffffb90, 
                                    CONCAT44(in_stack_fffffffffffffb9c, iVar46), in_stack_fffffffffffffba8, 
                                    in_stack_fffffffffffffbb0, (int64_t)in_stack_fffffffffffffbb8, 
                                    in_stack_fffffffffffffbc0, in_stack_fffffffffffffbc8, in_stack_fffffffffffffbd0, 
                                    iVar30, (int64_t)in_stack_fffffffffffffbe0, in_stack_fffffffffffffbe8, 
                                    in_stack_fffffffffffffbf0, (int64_t)in_stack_fffffffffffffbf8, 
                                    in_stack_fffffffffffffc00, in_stack_fffffffffffffc08, in_stack_fffffffffffffc10, 
                                    (int64_t)in_stack_fffffffffffffc18, (int64_t)in_stack_fffffffffffffc20);
            fcn.1800ef070(var_570h);
            piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x150) + -4);
            *piVar1 = *piVar1 + -1;
            in_stack_fffffffffffffb28 = *(int64_t ***)(arg1 + 0x84);
            in_stack_fffffffffffffb30 = *(undefined4 *)(arg1 + 0x8c);
            in_stack_fffffffffffffb34 = *(undefined4 *)(arg1 + 0x90);
            uStack_3c4 = CONCAT44(in_stack_fffffffffffffaf8, uVar42);
            iStack_3c8 = iVar15;
            uVar12 = func_0x0001800ef810(arg1, 0x128, &iStack_3c8);
            *(undefined *)(piVar18 + 7) = uVar12;
            ppiVar31 = *(int64_t ***)(arg1 + 0xd8);
            uStack_240 = var_588h;
            uStack_238 = CONCAT44(in_stack_fffffffffffffb34, in_stack_fffffffffffffb30);
            iVar32 = (int64_t)*ppiVar31;
            if (iVar32 == 0) {
code_r0x0001800db096:
                piVar22 = (int64_t *)func_0x000180459890(0x2008);
                *piVar22 = (int64_t)*ppiVar31;
                *ppiVar31 = piVar22;
                ppiVar37 = (int64_t **)(piVar22 + 1);
                piVar22 = (int64_t *)0x50;
            } else {
                ppiVar37 = (int64_t **)((int64_t)ppiVar31[1] + iVar32 + 0xf & 0xfffffffffffffff8);
                if ((int64_t **)(iVar32 + 0x2008) < ppiVar37 + 10) goto code_r0x0001800db096;
                piVar22 = (int64_t *)((int64_t)ppiVar37 + (0x50 - (iVar32 + 8)));
            }
            ppiVar41 = (int64_t **)CONCAT44(uVar44, uVar39);
            ppiVar34 = (int64_t **)CONCAT44(uVar42, uVar38);
            ppiVar31[1] = piVar22;
            *(undefined4 *)(ppiVar37 + 1) = *(undefined4 *)0x1807826fc;
            *(undefined4 *)((int64_t)ppiVar37 + 0xc) = (undefined4)uStack_240;
            *(undefined4 *)(ppiVar37 + 2) = uStack_240._4_4_;
            *(undefined4 *)((int64_t)ppiVar37 + 0x14) = (undefined4)uStack_238;
            *(undefined4 *)(ppiVar37 + 3) = uStack_238._4_4_;
            *(undefined *)(ppiVar37 + 4) = 0;
            *ppiVar37 = (int64_t *)0x180641dc0;
            ppiVar37[5] = (int64_t *)var_570h;
            ppiVar37[6] = piVar18;
            *(undefined *)(ppiVar37 + 7) = uVar11;
            *(undefined4 *)((int64_t)ppiVar37 + 0x3c) = uVar42;
            *(undefined4 *)(ppiVar37 + 8) = in_stack_fffffffffffffaf8;
            *(int32_t *)((int64_t)ppiVar37 + 0x44) = in_stack_fffffffffffffafc;
            *(undefined4 *)(ppiVar37 + 9) = uVar39;
        }
        *(int32_t *)(arg1 + 0x114) = iVar46;
        if (*(int32_t *)(arg1 + 0x80) == 0x3b) {
            func_0x0001800f0350(arg1);
            *(undefined *)(ppiVar37 + 4) = 1;
            *(undefined8 *)((int64_t)ppiVar37 + 0x14) = *(undefined8 *)(arg1 + 0xa8);
        }
        ppiVar31 = (int64_t **)arg_148h_00[1];
        if (ppiVar31 == (int64_t **)arg_148h_00[2]) {
            iVar32 = (int64_t)ppiVar31 - *arg_148h_00 >> 3;
            if (iVar32 == 0x1fffffffffffffff) {
code_r0x0001800ddc94:
                *(undefined8 *)(puVar33 + -8) = 0x1800ddc99;
                func_0x000180010010();
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            uVar29 = (int64_t)(int64_t **)arg_148h_00[2] - *arg_148h_00 >> 3;
            if (0x1fffffffffffffff - (uVar29 >> 1) < uVar29) {
                in_R9 = (int64_t **)0x1fffffffffffffff;
            } else {
                in_R9 = (int64_t **)(uVar29 + (uVar29 >> 1));
                if (in_R9 < (int64_t **)(iVar32 + 1U)) {
                    in_R9 = (int64_t **)(iVar32 + 1U);
                }
            }
            var_588h = (int64_t)in_R9;
            iVar24 = func_0x00018001ba60(uVar29, &var_588h);
            *(int64_t ***)(iVar24 + iVar32 * 8) = ppiVar37;
            ppiVar17 = (int64_t **)*arg_148h_00;
            if (ppiVar31 == (int64_t **)arg_148h_00[1]) {
                iVar36 = (int64_t)(int64_t **)arg_148h_00[1] - (int64_t)ppiVar17;
                iVar32 = iVar24;
                ppiVar31 = ppiVar17;
            } else {
                func_0x000180498030(iVar24, ppiVar17, (int64_t)ppiVar31 - (int64_t)ppiVar17);
                iVar36 = arg_148h_00[1] - (int64_t)ppiVar31;
                iVar32 = iVar32 * 8 + 8 + iVar24;
            }
            func_0x000180498030(iVar32, ppiVar31, iVar36);
            func_0x0001800c2120(arg_148h_00, iVar24);
        } else {
            *ppiVar31 = (int64_t *)ppiVar37;
            arg_148h_00[1] = arg_148h_00[1] + 8;
        }
        iVar30 = iVar30 + 1;
        iStack_350 = iVar30;
        cVar13 = func_0x0001800dae20(ppiVar37);
    } while (cVar13 == '\0');
    uVar21 = *(undefined8 *)(arg1 + 0xd8);
    uVar25 = func_0x0001800f0bf0(arg1, auStack_150, apiStack_360);
    func_0x0001800f0c30(uVar21, &stack0xfffffffffffffbc8, uVar25);
    func_0x0001800f1a50(apiStack_360);
    func_0x000180459870(var_70h ^ (uint64_t)auStackY_5e8);
    return;
}

// ============================================================
// Function: FUN_1800ddd50
// Address: 0x1800ddd50
// Size: 819 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_69h
// WARNING: Variable defined which should be unmapped: var_59h
// WARNING: Variable defined which should be unmapped: var_51h
// WARNING: Variable defined which should be unmapped: var_49h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_2dh
// WARNING: Variable defined which should be unmapped: var_21h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_67h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_65h
// WARNING: [rz-ghidra] Detected overlap for variable var_61h
// WARNING: [rz-ghidra] Detected overlap for variable var_36h
// WARNING: [rz-ghidra] Detected overlap for variable var_25h
// WARNING: [rz-ghidra] Removing arg arg_478h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_398h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_358h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_348h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_338h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_278h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_280h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_268h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_34h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_258h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_248h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_250h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_124h
// WARNING: [rz-ghidra] Removing arg arg_2a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_154h
// WARNING: [rz-ghidra] Removing arg arg_2d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_328h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_310h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_428h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_318h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_144h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_408h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_418h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_13ch
// WARNING: [rz-ghidra] Removing arg arg_2b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_458h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_228h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_230h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_238h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_240h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_468h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_438h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_218h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_220h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_450h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_448h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_388h because it doesn't fit into ProtoModel

int64_t * fcn.1800ddd50(int64_t arg1)
{
    uint32_t uVar1;
    undefined *puVar2;
    int32_t iVar3;
    int64_t **ppiVar4;
    code *pcVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined auVar8 [16];
    int64_t arg_98h;
    undefined auVar9 [16];
    int64_t arg_88h;
    undefined auVar10 [16];
    int32_t iVar11;
    undefined4 uVar12;
    char cVar13;
    undefined uVar14;
    int64_t arg_f8h;
    int64_t iVar15;
    int64_t *piVar16;
    int64_t iVar17;
    int64_t *piVar18;
    int64_t unaff_RBX;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    int64_t unaff_RDI;
    int64_t in_R9;
    undefined uVar19;
    int64_t unaff_R12;
    undefined uVar20;
    int64_t unaff_R13;
    int64_t unaff_R14;
    int64_t unaff_R15;
    undefined4 unaff_XMM6_Da;
    int32_t iVar21;
    undefined4 unaff_XMM6_Db;
    undefined4 uVar22;
    undefined4 unaff_XMM6_Dc;
    undefined4 uVar23;
    undefined4 unaff_XMM6_Dd;
    undefined4 uVar24;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    undefined4 unaff_XMM8_Da;
    int32_t iVar25;
    undefined4 unaff_XMM8_Db;
    undefined4 uVar26;
    undefined4 unaff_XMM8_Dc;
    undefined4 uVar27;
    undefined4 unaff_XMM8_Dd;
    undefined4 uVar28;
    int64_t unaff_retaddr;
    int64_t in_stack_00000010;
    int64_t arg_100h;
    int64_t var_18h;
    int64_t in_stack_00000020;
    int64_t in_stack_00000028;
    int64_t in_stack_00000030;
    int64_t in_stack_00000040;
    int64_t in_stack_00000058;
    int64_t in_stack_00000070;
    int64_t in_stack_00000078;
    int64_t in_stack_00000080;
    int64_t in_stack_00000088;
    int64_t in_stack_00000090;
    int64_t in_stack_00000098;
    int64_t in_stack_000000a8;
    int64_t in_stack_000000b0;
    int64_t in_stack_000000b8;
    int64_t in_stack_000000c0;
    int64_t in_stack_000000c8;
    int64_t in_stack_000000d0;
    int64_t in_stack_000000d8;
    int64_t in_stack_000000e0;
    int64_t in_stack_000000e8;
    int64_t in_stack_000000f0;
    int64_t in_stack_000000f8;
    int64_t in_stack_00000100;
    int64_t in_stack_00000108;
    int64_t in_stack_00000110;
    int64_t in_stack_00000118;
    int64_t in_stack_00000120;
    int32_t iStack_c8;
    int32_t iStack_c4;
    undefined4 in_stack_ffffffffffffff40;
    undefined4 in_stack_ffffffffffffff44;
    undefined4 uStack_b0;
    undefined4 uStack_ac;
    undefined4 uVar29;
    undefined4 uVar30;
    undefined in_stack_ffffffffffffff68;
    undefined2 in_stack_ffffffffffffff69;
    undefined in_stack_ffffffffffffff6b;
    undefined4 in_stack_ffffffffffffff6c;
    undefined4 in_stack_ffffffffffffff70;
    int32_t iVar31;
    undefined4 uVar32;
    undefined4 uVar33;
    undefined auStack_70 [7];
    int64_t var_69h;
    undefined auStack_60 [7];
    int64_t var_59h;
    int64_t var_51h;
    int64_t var_49h;
    int64_t var_38h;
    int64_t var_2dh;
    int64_t var_21h;
    
    iVar11 = *(int32_t *)(arg1 + 0x84);
    uVar12 = *(undefined4 *)(arg1 + 0x88);
    uVar27 = *(undefined4 *)(arg1 + 0x8c);
    uVar28 = *(undefined4 *)(arg1 + 0x90);
    iVar17 = CONCAT44(unaff_XMM6_Db, unaff_XMM6_Da);
    auVar6._8_4_ = unaff_XMM6_Dc;
    auVar6._0_8_ = iVar17;
    auVar6._12_4_ = unaff_XMM6_Dd;
    arg_98h = CONCAT44(unaff_XMM7_Db, unaff_XMM7_Da);
    auVar8._8_4_ = unaff_XMM7_Dc;
    auVar8._0_8_ = arg_98h;
    auVar8._12_4_ = unaff_XMM7_Dd;
    arg_88h = CONCAT44(unaff_XMM8_Db, unaff_XMM8_Da);
    auVar9._8_4_ = unaff_XMM8_Dc;
    auVar9._0_8_ = arg_88h;
    auVar9._12_4_ = unaff_XMM8_Dd;
    func_0x0001800f0350();
    arg_f8h = func_0x0001800e9350(arg1, 0);
    iVar3 = *(int32_t *)(arg1 + 0x84);
    uVar22 = *(undefined4 *)(arg1 + 0x88);
    uVar23 = *(undefined4 *)(arg1 + 0x8c);
    iVar21 = *(int32_t *)(arg1 + 0x80);
    uVar24 = *(undefined4 *)(arg1 + 0x90);
    uVar33 = *(undefined4 *)(arg1 + 0x94);
    iVar31 = iVar3;
    uVar32 = uVar24;
    if (iVar21 == 0x134) {
        func_0x0001800f0350(arg1);
        uVar29 = uVar27;
        uVar30 = uVar28;
code_r0x0001800ddde5:
        uVar20 = 1;
        iVar25 = iVar3;
        uVar26 = uVar22;
        uVar27 = uVar23;
        uVar28 = uVar24;
    } else {
        uVar20 = 0;
        cVar13 = func_0x0001800ef2a0(arg1, 0x134, 0x1806429f0);
        iVar25 = iVar11;
        uVar26 = uVar12;
        uVar29 = uVar27;
        uVar30 = uVar28;
        if (cVar13 != '\0') goto code_r0x0001800ddde5;
    }
    _auStack_60 = auVar9._8_8_;
    stack0xffffffffffffffb0 = auVar8._8_8_;
    iVar15 = fcn.1800dae50(arg1, CONCAT44(in_stack_ffffffffffffff44, in_stack_ffffffffffffff40), 
                           CONCAT44(uVar30, uVar29), 
                           CONCAT44(in_stack_ffffffffffffff6c, 
                                    CONCAT13(in_stack_ffffffffffffff6b, 
                                             CONCAT21(in_stack_ffffffffffffff69, in_stack_ffffffffffffff68))), 
                           CONCAT44(iVar31, in_stack_ffffffffffffff70), CONCAT44(uVar33, uVar32), _auStack_70, arg_88h, 
                           _auStack_60, arg_98h, stack0xffffffffffffffb0, iVar17, auVar6._8_8_, unaff_R15, unaff_R14, 
                           unaff_R13, unaff_RDI, unaff_RSI, unaff_RBX, unaff_RBP, unaff_retaddr, arg_f8h, 
                           in_stack_00000010, unaff_R12, in_stack_00000020, in_stack_00000028, in_stack_00000030, 
                           in_stack_00000040, in_stack_00000058, in_stack_00000070, in_stack_00000078, in_stack_00000080
                           , in_stack_00000088, in_stack_00000090, in_stack_00000098, in_stack_000000a8, 
                           in_stack_000000b0, in_stack_000000b8, in_stack_000000c0, in_stack_000000c8, in_stack_000000d0
                           , in_stack_000000d8, in_stack_000000e0, in_stack_000000e8, in_stack_000000f0, 
                           in_stack_000000f8, in_stack_00000100, in_stack_00000108, in_stack_00000110, in_stack_00000118
                           , in_stack_00000120);
    arg_100h = iVar15;
    fcn.1800ef070(_auStack_70);
    puVar2 = (undefined *)(iVar15 + 0x38);
    if (*(int32_t *)(arg1 + 0x80) == 0x127) {
        *puVar2 = 1;
        iVar3 = *(int32_t *)(arg1 + 0x114);
        uVar1 = iVar3 + 1;
        *(uint32_t *)(arg1 + 0x114) = uVar1;
        if (*(uint32_t *)0x180778500 < uVar1) {
            iVar17 = func_0x0001800d90d0(arg1 + 0x60);
            fcn.1800d9940(iVar17 + 4, 0x180644050, 0x180642324, in_R9);
            pcVar5 = (code *)swi(3);
            piVar18 = (int64_t *)(*pcVar5)();
            return piVar18;
        }
        iVar21 = *(int32_t *)(arg1 + 0x84);
        uVar22 = *(undefined4 *)(arg1 + 0x88);
        uVar23 = *(undefined4 *)(arg1 + 0x8c);
        uVar24 = *(undefined4 *)(arg1 + 0x90);
        uVar19 = 1;
        iVar15 = fcn.1800ddd50(arg1);
        uStack_b0 = *(undefined4 *)(iVar15 + 0x14);
        uStack_ac = *(undefined4 *)(iVar15 + 0x18);
        *(int32_t *)(arg1 + 0x114) = iVar3;
    } else {
        iVar15 = 0;
        uVar19 = 0;
        if (*(int32_t *)(arg1 + 0x80) == 0x126) {
            *puVar2 = 1;
            iVar21 = *(int32_t *)(arg1 + 0x84);
            uVar22 = *(undefined4 *)(arg1 + 0x88);
            uVar23 = *(undefined4 *)(arg1 + 0x8c);
            uVar24 = *(undefined4 *)(arg1 + 0x90);
            iVar3 = *(int32_t *)(arg1 + 0x80);
            uVar33 = *(undefined4 *)(arg1 + 0x90);
            uVar32 = *(undefined4 *)(arg1 + 0x94);
            iVar31 = iVar21;
            func_0x0001800f0350();
            iVar15 = fcn.1800dae50(arg1, CONCAT44(in_stack_ffffffffffffff44, in_stack_ffffffffffffff40), 
                                   CONCAT44(uVar30, uVar29), 
                                   CONCAT44(in_stack_ffffffffffffff6c, 
                                            CONCAT13(in_stack_ffffffffffffff6b, 
                                                     CONCAT21(in_stack_ffffffffffffff69, in_stack_ffffffffffffff68))), 
                                   CONCAT44(iVar31, in_stack_ffffffffffffff70), CONCAT44(uVar32, uVar33), _auStack_70, 
                                   arg_88h, _auStack_60, arg_98h, stack0xffffffffffffffb0, iVar17, auVar6._8_8_, 
                                   unaff_R15, unaff_R14, unaff_R13, unaff_RDI, unaff_RSI, unaff_RBX, unaff_RBP, 
                                   unaff_retaddr, arg_f8h, arg_100h, unaff_R12, in_stack_00000020, in_stack_00000028, 
                                   in_stack_00000030, in_stack_00000040, in_stack_00000058, in_stack_00000070, 
                                   in_stack_00000078, in_stack_00000080, in_stack_00000088, in_stack_00000090, 
                                   in_stack_00000098, in_stack_000000a8, in_stack_000000b0, in_stack_000000b8, 
                                   in_stack_000000c0, in_stack_000000c8, in_stack_000000d0, in_stack_000000d8, 
                                   in_stack_000000e0, in_stack_000000e8, in_stack_000000f0, in_stack_000000f8, 
                                   in_stack_00000100, in_stack_00000108, in_stack_00000110, in_stack_00000118, 
                                   in_stack_00000120);
            iStack_c4 = iVar31;
            fcn.1800ef070(_auStack_70);
            *(uint64_t *)(iVar15 + 0xc) = CONCAT44(uVar33, uVar23);
            uStack_b0 = *(undefined4 *)(arg1 + 0x8c);
            uStack_ac = *(undefined4 *)(arg1 + 0x90);
            iStack_c8 = iVar3;
            uVar14 = func_0x0001800ef810(arg1, 0x128, &iStack_c8);
            if (iVar15 != 0) {
                iVar17 = 0;
                if (*(int32_t *)(iVar15 + 8) == *(int32_t *)0x180782718) {
                    iVar17 = iVar15;
                }
                if (iVar17 != 0) {
                    *(undefined *)(iVar17 + 0x38) = uVar14;
                }
                uVar19 = 1;
                goto code_r0x0001800ddf62;
            }
            uVar19 = 1;
        } else {
            uStack_b0 = *(undefined4 *)(arg1 + 0x8c);
            uStack_ac = *(undefined4 *)(arg1 + 0x90);
            iStack_c8 = iVar21;
            iStack_c4 = iVar3;
            uVar23 = uVar29;
            uVar24 = uVar30;
            uVar14 = func_0x0001800ef810(arg1, 0x128, &iStack_c8);
            iVar21 = iVar11;
            uVar22 = uVar12;
        }
        *puVar2 = uVar14;
    }
code_r0x0001800ddf62:
    ppiVar4 = *(int64_t ***)(arg1 + 0xd8);
    iVar17 = (int64_t)*ppiVar4;
    iStack_c8 = iVar11;
    iStack_c4 = uVar12;
    if (iVar17 != 0) {
        piVar18 = (int64_t *)((int64_t)ppiVar4[1] + iVar17 + 0xf & 0xfffffffffffffff8);
        if (piVar18 + 0xd <= (int64_t *)(iVar17 + 0x2008)) {
            piVar16 = (int64_t *)((int64_t)piVar18 + (0x68 - (iVar17 + 8)));
            goto code_r0x0001800ddfcc;
        }
    }
    piVar16 = (int64_t *)func_0x000180459890(0x2008);
    *piVar16 = (int64_t)*ppiVar4;
    piVar18 = piVar16 + 1;
    *ppiVar4 = piVar16;
    piVar16 = (int64_t *)0x68;
code_r0x0001800ddfcc:
    ppiVar4[1] = piVar16;
    *(undefined4 *)(piVar18 + 1) = *(undefined4 *)0x180782724;
    *(undefined2 *)((int64_t)piVar18 + 0x51) = in_stack_ffffffffffffff69;
    *piVar18 = 0x180641a90;
    *(undefined *)((int64_t)piVar18 + 0x53) = in_stack_ffffffffffffff6b;
    piVar18[5] = arg_f8h;
    *(undefined2 *)((int64_t)piVar18 + 0x65) = in_stack_ffffffffffffff69;
    piVar18[6] = arg_100h;
    auVar10._4_4_ = uVar26;
    auVar10._0_4_ = iVar25;
    auVar10._8_4_ = uVar27;
    auVar10._12_4_ = uVar28;
    *(undefined (*) [16])(piVar18 + 8) = auVar10;
    *(undefined *)((int64_t)piVar18 + 100) = uVar19;
    auVar7._4_4_ = uVar22;
    auVar7._0_4_ = iVar21;
    auVar7._8_4_ = uVar23;
    auVar7._12_4_ = uVar24;
    *(undefined (*) [16])((int64_t)piVar18 + 0x54) = auVar7;
    *(undefined *)((int64_t)piVar18 + 0x67) = in_stack_ffffffffffffff6b;
    *(int32_t *)((int64_t)piVar18 + 0xc) = iStack_c8;
    *(int32_t *)(piVar18 + 2) = iStack_c4;
    *(undefined4 *)((int64_t)piVar18 + 0x14) = uStack_b0;
    *(undefined4 *)(piVar18 + 3) = uStack_ac;
    *(undefined *)(piVar18 + 4) = 0;
    piVar18[7] = iVar15;
    *(undefined *)(piVar18 + 10) = uVar20;
    return piVar18;
}

// ============================================================
// Function: FUN_1800de0e0
// Address: 0x1800de0e0
// Size: 625 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_15h
// WARNING: [rz-ghidra] Detected overlap for variable var_17h

int64_t fcn.1800de0e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    undefined8 *puVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t var_8h;
    undefined2 var_15h;
    undefined var_17h;
    int64_t var_18h;
    int64_t var_a8h;
    undefined4 uStack_a0;
    undefined4 uStack_9c;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_78h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_10h;
    
    *(undefined *)(arg2 + 4) = 0;
    var_38h._0_1_ = '\0';
    iVar4 = 0;
    iVar7 = *(int64_t *)0x180778300;
    while (iVar7 != 0) {
        iVar7 = (int64_t)iVar4 * 0x58;
        iVar3 = func_0x000180498f10(arg4, *(undefined8 *)(iVar7 + 0x180778300));
        if (iVar3 == 0) {
            *(undefined4 *)arg2 = *(undefined4 *)(iVar7 + 0x180778308);
            *(undefined *)(arg2 + 4) = 1;
            *(undefined2 *)(arg2 + 5) = var_15h;
            *(undefined *)(arg2 + 7) = var_17h;
            func_0x0001800de360(&var_78h, iVar7 + 0x180778310);
            break;
        }
        iVar4 = iVar4 + 1;
        iVar7 = *(int64_t *)((int64_t)iVar4 * 0x58 + 0x180778300);
    }
    puVar5 = (undefined8 *)0x1807780e0;
    while ((*(char *)puVar5[0xb] == '\0' || (iVar4 = func_0x000180498f10(arg4, *puVar5), iVar4 != 0))) {
        puVar5 = puVar5 + 0xc;
        if (puVar5 == (undefined8 *)0x180778140) {
code_r0x0001800de1f1:
            if (*(char *)(arg2 + 4) == '\0') {
                iVar7 = func_0x000180498cd0(arg4);
                if (iVar7 == 0) {
                    func_0x0001800efe70(arg1, arg3, 0x180642a10);
                } else {
                    func_0x0001800efe70(arg1, arg3, 0x180642a30, arg4);
                }
            } else {
                piVar6 = (int64_t *)(**(int64_t **)arg_28h + *(int64_t *)(arg_28h + 8) * 8);
                piVar1 = piVar6 + *(int64_t *)(arg_28h + 0x10);
                for (; piVar6 != piVar1; piVar6 = piVar6 + 1) {
                    if (*(int32_t *)(*piVar6 + 0x20) == *(int32_t *)arg2) {
                        func_0x0001800efe70(arg1, arg3, 0x180642a48, arg4);
                    }
                }
                if ((char)var_38h != '\0') {
                    var_a8h._0_4_ = *(undefined4 *)arg3;
                    var_a8h._4_4_ = *(undefined4 *)(arg3 + 4);
                    uStack_a0 = *(undefined4 *)(arg3 + 8);
                    uStack_9c = *(undefined4 *)(arg3 + 0xc);
                    if ((int64_t *)var_40h == (int64_t *)0x0) {
                        func_0x000180454690();
                        pcVar2 = (code *)swi(3);
                        iVar7 = (*pcVar2)();
                        return iVar7;
                    }
                    (**(code **)(*(int64_t *)var_40h + 0x10))(var_40h, &var_98h, &var_a8h, arg_30h);
                    for (; var_98h != var_90h; var_98h = var_98h + 0x30) {
                        piVar6 = (int64_t *)(var_98h + 0x10);
                        if (0xf < *(uint64_t *)(var_98h + 0x28)) {
                            piVar6 = (int64_t *)*piVar6;
                        }
                        func_0x0001800efe70(arg1, var_98h, 0x18063cc8c, piVar6);
                    }
                    func_0x0001800f3260(&var_98h);
                }
            }
            if (((char)var_38h != '\0') && (var_40h != 0)) {
                (**(code **)(*(int64_t *)var_40h + 0x20))
                          (var_40h, CONCAT71((unkint7)((uint64_t)&var_78h >> 8), (int64_t *)var_40h != &var_78h));
            }
            return arg2;
        }
    }
    *(undefined4 *)arg2 = *(undefined4 *)(puVar5 + 1);
    *(undefined *)(arg2 + 4) = 1;
    *(undefined2 *)(arg2 + 5) = var_15h;
    *(undefined *)(arg2 + 7) = var_17h;
    func_0x0001800de360(&var_78h, puVar5 + 2);
    goto code_r0x0001800de1f1;
}

// ============================================================
// Function: FUN_1800de360
// Address: 0x1800de360
// Size: 460 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800de360(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t *piVar4;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_c8 [32];
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t *piStack_20;
    uint64_t uStack_18;
    int64_t var_8h;
    
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_c8;
    if (*(char *)(arg2 + 0x40) == '\0') {
        if (*(char *)(arg1 + 0x40) != '\0') {
            piVar4 = *(int64_t **)(arg1 + 0x38);
            if (piVar4 != (int64_t *)0x0) {
                (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)arg1);
                *(undefined8 *)(arg1 + 0x38) = 0;
            }
            *(undefined *)(arg1 + 0x40) = 0;
        }
        goto code_r0x0001800de508;
    }
    if (*(char *)(arg1 + 0x40) == '\0') {
        *(undefined8 *)(arg1 + 0x38) = 0;
        puVar1 = *(undefined8 **)(arg2 + 0x38);
        var_a8h = arg1;
        if (puVar1 != (undefined8 *)0x0) {
            uVar3 = (**(code **)*puVar1)(puVar1, arg1);
            *(undefined8 *)(arg1 + 0x38) = uVar3;
        }
        *(undefined *)(arg1 + 0x40) = 1;
        goto code_r0x0001800de508;
    }
    var_60h = 0;
    puVar1 = *(undefined8 **)(arg2 + 0x38);
    if (puVar1 != (undefined8 *)0x0) {
        var_60h = (**(code **)*puVar1)(puVar1, &var_98h);
    }
    if (((int64_t *)var_60h == &var_98h) ||
       (piVar4 = (int64_t *)var_60h, iVar2 = *(int64_t *)(arg1 + 0x38), *(int64_t *)(arg1 + 0x38) == arg1)) {
        piStack_20 = (int64_t *)0x0;
        if (var_60h != 0) {
            if ((int64_t *)var_60h == &var_98h) {
                piStack_20 = (int64_t *)(**(code **)(*(int64_t *)var_60h + 8))(var_60h, &var_58h);
                if (var_60h == 0) goto code_r0x0001800de43e;
                (**(code **)(*(int64_t *)var_60h + 0x20))
                          (var_60h, CONCAT71((unkint7)((uint64_t)&var_98h >> 8), (int64_t *)var_60h != &var_98h));
            } else {
                piStack_20 = (int64_t *)var_60h;
            }
            var_60h = 0;
        }
code_r0x0001800de43e:
        piVar4 = *(int64_t **)(arg1 + 0x38);
        if (piVar4 != (int64_t *)0x0) {
            if (piVar4 == (int64_t *)arg1) {
                var_60h = (**(code **)(*piVar4 + 8))(piVar4, &var_98h);
                piVar4 = *(int64_t **)(arg1 + 0x38);
                if (piVar4 == (int64_t *)0x0) goto code_r0x0001800de479;
                (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)arg1);
                piVar4 = (int64_t *)var_60h;
            }
            var_60h = (int64_t)piVar4;
            *(undefined8 *)(arg1 + 0x38) = 0;
        }
code_r0x0001800de479:
        if (piStack_20 != (int64_t *)0x0) {
            piVar4 = piStack_20;
            iVar2 = var_60h;
            if (piStack_20 != &var_58h) goto code_r0x0001800de3d4;
            uVar3 = (**(code **)(*piStack_20 + 8))(piStack_20, arg1);
            *(undefined8 *)(arg1 + 0x38) = uVar3;
            if (piStack_20 != (int64_t *)0x0) {
                (**(code **)(*piStack_20 + 0x20))
                          (piStack_20, CONCAT71((unkint7)((uint64_t)&var_58h >> 8), piStack_20 != &var_58h));
            }
        }
    } else {
code_r0x0001800de3d4:
        var_60h = iVar2;
        *(int64_t **)(arg1 + 0x38) = piVar4;
    }
    if (var_60h != 0) {
        (**(code **)(*(int64_t *)var_60h + 0x20))(var_60h, (int64_t *)var_60h != &var_98h);
    }
code_r0x0001800de508:
    func_0x000180459870(uStack_18 ^ (uint64_t)auStack_c8);
    return;
}

// ============================================================
// Function: FUN_1800de530
// Address: 0x1800de530
// Size: 2384 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_198h
// WARNING: Variable defined which should be unmapped: var_190h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_15h
// WARNING: [rz-ghidra] Detected overlap for variable var_17h

int64_t fcn.1800de530(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    undefined auVar7 [16];
    undefined auVar8 [12];
    char cVar9;
    int64_t *piVar10;
    undefined8 uVar11;
    int64_t iVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t *piVar15;
    int64_t iVar16;
    int64_t iVar17;
    int64_t iVar18;
    undefined4 uVar19;
    undefined4 uVar20;
    undefined4 uVar21;
    undefined4 uVar22;
    undefined4 uVar23;
    undefined4 uVar24;
    undefined4 uVar25;
    undefined4 uVar26;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    undefined4 uStack_148;
    undefined4 uStack_144;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int32_t var_100h;
    int64_t var_fch;
    int64_t var_f0h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_74h;
    undefined4 uStack_6c;
    undefined4 uStack_68;
    undefined4 uStack_64;
    int64_t var_58h;
    
    var_168h = arg1 + 0x230;
    var_160h = *(int64_t *)(arg1 + 0x238) - *(int64_t *)var_168h >> 3;
    var_158h = 0;
    do {
        while( true ) {
            iVar12 = var_158h;
            iVar17 = var_160h;
            iVar4 = var_168h;
            iVar2 = *(int32_t *)(arg1 + 0x80);
            if (1 < iVar2 - 0x11cU) {
                *(undefined8 *)arg2 = 0;
                *(undefined8 *)(arg2 + 8) = 0;
                if (var_158h == 0) {
                    *(undefined8 *)(arg2 + 8) = 0;
                } else {
                    iVar18 = *(int64_t *)var_168h;
                    uVar13 = func_0x0001800d4d20(*(undefined8 *)(arg1 + 0xd8), var_158h * 8);
                    *(uint64_t *)arg2 = uVar13;
                    *(int64_t *)(arg2 + 8) = iVar12;
                    if (iVar12 != 0) {
                        uVar1 = iVar18 + iVar17 * 8;
                        if (((uint64_t)iVar12 < 2) ||
                           ((uVar13 <= uVar1 + (iVar12 + -1) * 8 && (uVar1 <= uVar13 + (iVar12 + -1) * 8)))) {
                            uVar14 = 0;
                            do {
                                *(undefined8 *)(uVar13 + uVar14 * 8) = *(undefined8 *)(uVar1 + uVar14 * 8);
                                uVar14 = uVar14 + 1;
                            } while (uVar14 < (uint64_t)iVar12);
                        } else {
                            func_0x000180498030(uVar13, uVar1, iVar12 * 8);
                        }
                    }
                }
                iVar17 = *(int64_t *)iVar4 + iVar17 * 8;
                if (iVar17 != *(int64_t *)(iVar4 + 8)) {
                    *(int64_t *)(iVar4 + 8) = iVar17;
                }
                return arg2;
            }
            var_118h = 0;
            var_110h = 0;
            if (iVar2 == 0x11c) break;
            var_74h._0_4_ = *(undefined4 *)(arg1 + 0x84);
            var_74h._4_4_ = *(undefined4 *)(arg1 + 0x88);
            uStack_6c = *(undefined4 *)(arg1 + 0x8c);
            uStack_68 = *(undefined4 *)(arg1 + 0x90);
            func_0x0001800f0350();
            iVar4 = CONCAT44(var_74h._4_4_, (undefined4)var_74h);
            if (*(int32_t *)(arg1 + 0x80) != 0x5d) {
                do {
                    if (*(int32_t *)(arg1 + 0x80) == 0x119) {
                        iVar17 = *(int64_t *)(arg1 + 0x98);
                        uVar23 = *(undefined4 *)(arg1 + 0x84);
                        uVar24 = *(undefined4 *)(arg1 + 0x88);
                        uVar25 = *(undefined4 *)(arg1 + 0x8c);
                        uVar26 = *(undefined4 *)(arg1 + 0x90);
                        var_170h = iVar17;
                        func_0x0001800f0350(arg1);
                    } else {
                        func_0x0001800efe90(arg1, 0x180642a70);
                        auVar8 = *(undefined (*) [12])(arg1 + 0x84);
                        var_188h = auVar8._0_8_;
                        var_180h = var_188h;
                        auVar7 = _var_188h;
                        iVar17 = *(int64_t *)(arg1 + 0x128);
                        var_188h._0_4_ = auVar8._0_4_;
                        var_188h._4_4_ = auVar8._4_4_;
                        uVar23 = (undefined4)var_188h;
                        uVar24 = var_188h._4_4_;
                        uVar25 = (undefined4)var_188h;
                        uVar26 = var_188h._4_4_;
                        _var_188h = auVar7;
                        var_170h = iVar17;
                    }
                    iVar3 = *(int32_t *)(arg1 + 0x80);
                    var_74h._4_4_ = uVar23;
                    uStack_6c = uVar24;
                    uStack_68 = uVar25;
                    uStack_64 = uVar26;
                    if ((iVar3 - 0x116U < 2) || (iVar3 == 0x7b)) {
                        if (iVar3 == 0x28) goto code_r0x0001800de842;
                        if (iVar3 == 0x7b) {
                            var_188h = *(int64_t *)(arg1 + 0x8c);
                            iVar12 = func_0x0001800ebfc0();
                            var_178h = *(int64_t *)(arg1 + 0xa8);
                            ppiVar5 = *(int64_t ***)(int64_t *)(arg1 + 0xd8);
                            iVar17 = (int64_t)*ppiVar5;
                            if (iVar17 == 0) {
code_r0x0001800dea48:
                                piVar15 = (int64_t *)func_0x000180459890(0x2008);
                                *piVar15 = (int64_t)*ppiVar5;
                                *ppiVar5 = piVar15;
                                piVar15 = piVar15 + 1;
                                piVar10 = (int64_t *)0x8;
                            } else {
                                piVar15 = (int64_t *)((int64_t)ppiVar5[1] + iVar17 + 0xf & 0xfffffffffffffff8);
                                if ((int64_t *)(iVar17 + 0x2008U) < piVar15 + 1) goto code_r0x0001800dea48;
                                piVar10 = (int64_t *)((int64_t)piVar15 + (8 - (iVar17 + 8)));
                            }
                            ppiVar5[1] = piVar10;
                            *piVar15 = iVar12;
                            uVar19 = *(undefined4 *)(iVar12 + 0xc);
                            uVar20 = *(undefined4 *)(iVar12 + 0x10);
                            uVar21 = *(undefined4 *)(iVar12 + 0x14);
                            uVar22 = *(undefined4 *)(iVar12 + 0x18);
                            var_140h = var_188h;
                        } else {
                            iVar17 = *(int64_t *)(arg1 + 0x84);
                            var_178h = *(int64_t *)(arg1 + 0x8c);
                            iVar18 = func_0x0001800edec0(arg1);
                            var_188h = iVar18;
                            ppiVar5 = *(int64_t ***)(int64_t *)(arg1 + 0xd8);
                            iVar12 = (int64_t)*ppiVar5;
                            if (iVar12 == 0) {
code_r0x0001800dead9:
                                piVar15 = (int64_t *)func_0x000180459890(0x2008);
                                *piVar15 = (int64_t)*ppiVar5;
                                *ppiVar5 = piVar15;
                                piVar15 = piVar15 + 1;
                                piVar10 = (int64_t *)0x8;
                                iVar18 = var_188h;
                            } else {
                                piVar15 = (int64_t *)((int64_t)ppiVar5[1] + iVar12 + 0xf & 0xfffffffffffffff8);
                                if ((int64_t *)(iVar12 + 0x2008U) < piVar15 + 1) goto code_r0x0001800dead9;
                                piVar10 = (int64_t *)((int64_t)piVar15 + (8 - (iVar12 + 8)));
                            }
                            ppiVar5[1] = piVar10;
                            *piVar15 = iVar18;
                            uVar19 = *(undefined4 *)(iVar18 + 0xc);
                            uVar20 = *(undefined4 *)(iVar18 + 0x10);
                            uVar21 = *(undefined4 *)(iVar18 + 0x14);
                            uVar22 = *(undefined4 *)(iVar18 + 0x18);
                            var_140h = iVar17;
                        }
                        var_128h = 1;
                        var_138h = var_178h;
                        var_150h._4_4_ = uVar20;
                        var_150h._0_4_ = uVar19;
                        uStack_148 = uVar21;
                        uStack_144 = uVar22;
code_r0x0001800deb28:
                        piVar10 = piVar15 + var_128h;
                        var_130h = (int64_t)piVar15;
                        iVar17 = var_170h;
                        for (; var_170h = iVar17, piVar15 != piVar10; piVar15 = piVar15 + 1) {
                            iVar3 = *(int32_t *)(*piVar15 + 8);
                            if ((((iVar3 != *(int32_t *)0x180782670) && (iVar3 != *(int32_t *)0x1807826cc)) &&
                                (iVar3 != *(int32_t *)0x1807826b4)) &&
                               ((iVar3 != *(int32_t *)0x18078273c && (cVar9 = func_0x0001800d61b0(), cVar9 == '\0')))) {
                                func_0x0001800efe70(arg1, &var_140h, 0x180642bd8);
                            }
                            iVar17 = var_170h;
                        }
                        var_188h._4_4_ = uVar24;
                        var_188h._0_4_ = uVar23;
                        unique0x100003bf = uVar25;
                        unique0x100003c3 = uVar26;
                        fcn.1800de0e0(arg1, (int64_t)&var_108h, (int64_t)&var_188h, iVar17, (int64_t)&var_168h, 
                                      (int64_t)&var_130h);
                        ppiVar5 = *(int64_t ***)(arg1 + 0xd8);
                        uVar23 = 4;
                        if (var_108h._4_1_ != '\0') {
                            uVar23 = (undefined4)var_108h;
                        }
                        var_a8h = CONCAT44(uStack_6c, var_74h._4_4_);
                        var_a0h = var_138h;
                        iVar12 = (int64_t)*ppiVar5;
                        if (iVar12 == 0) {
code_r0x0001800dec0d:
                            piVar15 = (int64_t *)func_0x000180459890(0x2008);
                            *piVar15 = (int64_t)*ppiVar5;
                            *ppiVar5 = piVar15;
                            piVar15 = piVar15 + 1;
                            piVar10 = (int64_t *)0x40;
                        } else {
                            piVar15 = (int64_t *)((int64_t)ppiVar5[1] + iVar12 + 0xf & 0xfffffffffffffff8);
                            if ((int64_t *)(iVar12 + 0x2008) < piVar15 + 8) goto code_r0x0001800dec0d;
                            piVar10 = (int64_t *)((int64_t)piVar15 + (0x40 - (iVar12 + 8)));
                        }
                        ppiVar5[1] = piVar10;
                        *(undefined4 *)(piVar15 + 1) = *(undefined4 *)0x1807826b0;
                        *(undefined4 *)((int64_t)piVar15 + 0xc) = (undefined4)var_a8h;
                        *(undefined4 *)(piVar15 + 2) = var_a8h._4_4_;
                        *(undefined4 *)((int64_t)piVar15 + 0x14) = (undefined4)var_a0h;
                        *(undefined4 *)(piVar15 + 3) = var_a0h._4_4_;
                        *piVar15 = 0x1806422e8;
                        *(undefined4 *)(piVar15 + 4) = uVar23;
                        piVar15[5] = var_130h;
                        piVar15[6] = var_128h;
                        piVar15[7] = iVar17;
                        var_188h = (int64_t)piVar15;
                    } else {
                        if (iVar3 == 0x28) {
code_r0x0001800de842:
                            iVar17 = *(int64_t *)(arg1 + 0x8c);
                            iVar12 = *(int64_t *)(arg1 + 0x84);
                            var_100h = iVar3;
                            var_fch = iVar12;
                            func_0x0001800f0350(arg1);
                            piVar15 = (int64_t *)(arg1 + 0x290);
                            var_178h = *(int64_t *)(arg1 + 0x298) - *piVar15 >> 3;
                            iVar18 = 0;
                            var_d0h = 0;
                            var_e0h = (int64_t)piVar15;
                            var_d8h = var_178h;
                            if (*(int32_t *)(arg1 + 0x80) != 0x29) {
                                uVar11 = func_0x0001800e9350(arg1, 0);
                                var_188h = uVar11;
                                func_0x0001800bf890(piVar15, &var_188h);
                                iVar18 = 1;
                                iVar3 = *(int32_t *)(arg1 + 0x80);
                                while (var_d0h = iVar18, iVar3 == 0x2c) {
                                    func_0x0001800f0350(arg1);
                                    if (*(int32_t *)(arg1 + 0x80) == 0x29) {
                                        func_0x0001800efe70(arg1, arg1 + 0x84, 0x1806433c8);
                                        break;
                                    }
                                    uVar11 = func_0x0001800e9350(arg1, 0);
                                    var_188h = uVar11;
                                    func_0x0001800bf890(piVar15);
                                    iVar18 = iVar18 + 1;
                                    iVar3 = *(int32_t *)(arg1 + 0x80);
                                }
                            }
                            iVar6 = *(int64_t *)(arg1 + 0x8c);
                            if (*(int32_t *)(arg1 + 0x80) == 0x29) {
                                func_0x0001800f0350(arg1);
                            } else {
                                func_0x0001800ef5a0(arg1, 0x29, &var_100h, 0);
                                func_0x0001800ef4e0(arg1, 0x29);
                                iVar12 = var_fch;
                            }
                            if (iVar18 == 0) {
                                iVar16 = 0;
                            } else {
                                iVar16 = *piVar15 + var_178h * 8;
                            }
                            func_0x0001800f1110(arg1, &var_b8h, iVar16, iVar18);
                            iVar16 = *(int64_t *)(arg1 + 0xa0);
                            var_c0h._0_4_ = (undefined4)iVar16;
                            var_c0h._4_4_ = (undefined4)((uint64_t)iVar16 >> 0x20);
                            uStack_148 = (undefined4)var_c0h;
                            var_150h = iVar12;
                            uStack_144 = var_c0h._4_4_;
                            var_128h = var_b0h;
                            iVar18 = *piVar15 + var_178h * 8;
                            piVar15 = (int64_t *)var_b8h;
                            var_140h = iVar17;
                            var_138h = iVar6;
                            var_c8h = iVar12;
                            var_c0h = iVar16;
                            if (iVar18 != *(int64_t *)(arg1 + 0x298)) {
                                *(int64_t *)(arg1 + 0x298) = iVar18;
                            }
                            goto code_r0x0001800deb28;
                        }
                        var_188h._4_4_ = uVar24;
                        var_188h._0_4_ = uVar23;
                        unique0x10000377 = uVar25;
                        unique0x1000037b = uVar26;
                        fcn.1800de0e0(arg1, (int64_t)&var_20h, (int64_t)&var_188h, iVar17, (int64_t)&var_168h, 
                                      (int64_t)&var_118h);
                        ppiVar5 = *(int64_t ***)(arg1 + 0xd8);
                        uVar19 = 4;
                        if (var_20h._4_1_ != '\0') {
                            uVar19 = (undefined4)var_20h;
                        }
                        iVar12 = (int64_t)*ppiVar5;
                        if (iVar12 == 0) {
code_r0x0001800de7eb:
                            piVar15 = (int64_t *)func_0x000180459890(0x2008);
                            *piVar15 = (int64_t)*ppiVar5;
                            *ppiVar5 = piVar15;
                            piVar15 = piVar15 + 1;
                            piVar10 = (int64_t *)0x40;
                        } else {
                            piVar15 = (int64_t *)((int64_t)ppiVar5[1] + iVar12 + 0xf & 0xfffffffffffffff8);
                            if ((int64_t *)(iVar12 + 0x2008) < piVar15 + 8) goto code_r0x0001800de7eb;
                            piVar10 = (int64_t *)((int64_t)piVar15 + (0x40 - (iVar12 + 8)));
                        }
                        ppiVar5[1] = piVar10;
                        *(undefined4 *)(piVar15 + 1) = *(undefined4 *)0x1807826b0;
                        auVar7._4_4_ = uVar24;
                        auVar7._0_4_ = uVar23;
                        auVar7._8_4_ = uVar25;
                        auVar7._12_4_ = uVar26;
                        *(undefined (*) [16])((int64_t)piVar15 + 0xc) = auVar7;
                        *piVar15 = 0x1806422e8;
                        *(undefined4 *)(piVar15 + 4) = uVar19;
                        *(undefined4 *)(piVar15 + 5) = (undefined4)var_118h;
                        *(undefined4 *)((int64_t)piVar15 + 0x2c) = var_118h._4_4_;
                        *(undefined4 *)(piVar15 + 6) = (undefined4)var_110h;
                        *(undefined4 *)((int64_t)piVar15 + 0x34) = var_110h._4_4_;
                        piVar15[7] = iVar17;
                        var_170h = (int64_t)piVar15;
                    }
                    func_0x0001800f1a70(&var_168h);
                    if (*(int32_t *)(arg1 + 0x80) != 0x2c) goto code_r0x0001800ded62;
                    func_0x0001800f0350(arg1);
                } while( true );
            }
            var_90h = *(int64_t *)(arg1 + 0x8c);
            var_98h = iVar4;
            func_0x0001800efe70(arg1, &var_98h, 0x180642c10);
            ppiVar5 = *(int64_t ***)(arg1 + 0xd8);
            var_80h = *(int64_t *)(arg1 + 0x8c);
            iVar17 = (int64_t)*ppiVar5;
            var_88h = iVar4;
            if (iVar17 == 0) {
code_r0x0001800ded00:
                piVar15 = (int64_t *)func_0x000180459890(0x2008);
                *piVar15 = (int64_t)*ppiVar5;
                *ppiVar5 = piVar15;
                piVar15 = piVar15 + 1;
                piVar10 = (int64_t *)0x40;
            } else {
                piVar15 = (int64_t *)((int64_t)ppiVar5[1] + iVar17 + 0xf & 0xfffffffffffffff8);
                if ((int64_t *)(iVar17 + 0x2008) < piVar15 + 8) goto code_r0x0001800ded00;
                piVar10 = (int64_t *)((int64_t)piVar15 + (0x40 - (iVar17 + 8)));
            }
            ppiVar5[1] = piVar10;
            iVar17 = *(int64_t *)(arg1 + 0x128);
            *(undefined4 *)(piVar15 + 1) = *(undefined4 *)0x1807826b0;
            *(undefined4 *)((int64_t)piVar15 + 0xc) = (undefined4)var_88h;
            *(undefined4 *)(piVar15 + 2) = var_88h._4_4_;
            *(undefined4 *)((int64_t)piVar15 + 0x14) = (undefined4)var_80h;
            *(undefined4 *)(piVar15 + 3) = var_80h._4_4_;
            *piVar15 = 0x1806422e8;
            *(undefined4 *)(piVar15 + 4) = 4;
            *(undefined4 *)(piVar15 + 5) = (undefined4)var_118h;
            *(undefined4 *)((int64_t)piVar15 + 0x2c) = var_118h._4_4_;
            *(undefined4 *)(piVar15 + 6) = (undefined4)var_110h;
            *(undefined4 *)((int64_t)piVar15 + 0x34) = var_110h._4_4_;
            piVar15[7] = iVar17;
            var_188h = (int64_t)piVar15;
            func_0x0001800f1a70(&var_168h, &var_188h);
code_r0x0001800ded62:
            var_f0h._0_4_ = iVar2;
            unique0x10001150 = iVar4;
            if (*(int32_t *)(arg1 + 0x80) == 0x5d) {
                func_0x0001800f0350(arg1);
            } else {
                func_0x0001800ef5a0(arg1, 0x5d);
                func_0x0001800ef4e0(arg1);
            }
        }
        uVar23 = *(undefined4 *)*(undefined (*) [16])(arg1 + 0x84);
        uVar24 = *(undefined4 *)(arg1 + 0x88);
        uVar25 = *(undefined4 *)(arg1 + 0x8c);
        uVar26 = *(undefined4 *)(arg1 + 0x90);
        _var_188h = *(undefined (*) [16])(arg1 + 0x84);
        iVar4 = *(int64_t *)(arg1 + 0x98);
        fcn.1800de0e0(arg1, (int64_t)&var_18h, (int64_t)&var_188h, iVar4, (int64_t)&var_168h, (int64_t)&var_118h);
        func_0x0001800f0350(arg1);
        ppiVar5 = *(int64_t ***)(arg1 + 0xd8);
        uVar19 = 4;
        if (var_18h._4_1_ != '\0') {
            uVar19 = (undefined4)var_18h;
        }
        iVar17 = (int64_t)*ppiVar5;
        if (iVar17 == 0) {
code_r0x0001800de65f:
            piVar15 = (int64_t *)func_0x000180459890(0x2008);
            *piVar15 = (int64_t)*ppiVar5;
            *ppiVar5 = piVar15;
            piVar15 = piVar15 + 1;
            piVar10 = (int64_t *)0x40;
        } else {
            piVar15 = (int64_t *)((int64_t)ppiVar5[1] + iVar17 + 0xf & 0xfffffffffffffff8);
            if ((int64_t *)(iVar17 + 0x2008) < piVar15 + 8) goto code_r0x0001800de65f;
            piVar10 = (int64_t *)((int64_t)piVar15 + (0x40 - (iVar17 + 8)));
        }
        ppiVar5[1] = piVar10;
        *(undefined4 *)(piVar15 + 1) = *(undefined4 *)0x1807826b0;
        *(undefined4 *)((int64_t)piVar15 + 0xc) = uVar23;
        *(undefined4 *)(piVar15 + 2) = uVar24;
        *(undefined4 *)((int64_t)piVar15 + 0x14) = uVar25;
        *(undefined4 *)(piVar15 + 3) = uVar26;
        *piVar15 = 0x1806422e8;
        *(undefined4 *)(piVar15 + 4) = uVar19;
        *(undefined4 *)(piVar15 + 5) = (undefined4)var_118h;
        *(undefined4 *)((int64_t)piVar15 + 0x2c) = var_118h._4_4_;
        *(undefined4 *)(piVar15 + 6) = (undefined4)var_110h;
        *(undefined4 *)((int64_t)piVar15 + 0x34) = var_110h._4_4_;
        piVar15[7] = iVar4;
        func_0x0001800f1a70(&var_168h);
    } while( true );
}

// ============================================================
// Function: FUN_1800dee80
// Address: 0x1800dee80
// Size: 2259 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_97h
// WARNING: [rz-ghidra] Detected overlap for variable var_95h
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h

void fcn.1800dee80(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int32_t *piVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t *piVar12;
    int64_t **ppiVar13;
    undefined8 uVar14;
    int64_t *piVar15;
    int64_t *piVar16;
    undefined4 *puVar17;
    int64_t iVar18;
    uint64_t uVar19;
    undefined *puVar20;
    int32_t iVar21;
    int64_t *piVar22;
    undefined4 uVar23;
    undefined4 uVar24;
    undefined4 uVar25;
    undefined4 uVar26;
    int64_t var_18h;
    undefined auStack_198 [8];
    undefined auStack_190 [24];
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    undefined8 var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    undefined4 uStack_b0;
    undefined4 uStack_ac;
    int64_t var_a8h;
    undefined4 uStack_a0;
    undefined4 uStack_9c;
    undefined2 var_97h;
    undefined var_95h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    undefined4 uStack_78;
    undefined4 uStack_74;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    puVar20 = auStack_198;
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_198;
    piVar22 = (int64_t *)(arg1 + 0x84);
    iVar21 = *(int32_t *)piVar22;
    uVar23 = *(undefined4 *)(arg1 + 0x88);
    var_138h = *piVar22;
    if (*(int64_t *)(arg2 + 8) != 0) {
        piVar11 = (int64_t *)(**(int64_t **)arg2 + 0xc);
        iVar21 = *(int32_t *)piVar11;
        uVar23 = *(undefined4 *)(**(int64_t **)arg2 + 0x10);
        var_138h = *piVar11;
    }
    var_150h = *piVar22;
    func_0x0001800f0350(arg1);
    piVar1 = (int32_t *)(arg1 + 0x80);
    if (*piVar1 != 299) {
        if (*(int64_t *)(arg2 + 8) != 0) {
            var_170h = func_0x0001800d62b0(piVar1, &var_70h);
            if (0xf < *(uint64_t *)(var_170h + 0x18)) {
                var_170h = *(int64_t *)var_170h;
            }
            var_128h = 0;
            var_120h = 0;
            var_138h = 0;
            var_130h = 0;
            var_178h = 0x180642b00;
            func_0x0001800eff80(arg1, piVar22, &var_138h);
            puVar20 = auStack_198;
            if ((uint64_t)var_58h < 0x10) goto code_r0x0001800df724;
            uVar19 = var_58h + 1;
            iVar18 = var_70h;
            if (0xfff < uVar19) {
                iVar18 = *(int64_t *)(var_70h + -8);
                if (0x1f < (var_70h - iVar18) - 8U) {
                    pcVar4 = (code *)swi(0x29);
                    (*pcVar4)(5);
                    puVar20 = auStack_190;
                    goto code_r0x0001800df1f1;
                }
                uVar19 = var_58h + 0x28;
            }
            func_0x000180459c3c(iVar18, uVar19);
            puVar20 = auStack_198;
            goto code_r0x0001800df724;
        }
code_r0x0001800df1f1:
        piVar2 = (int32_t *)(*(int64_t *)(arg1 + 0x1e8) + 0xf4);
        *piVar2 = *piVar2 + 1;
        var_e0h = arg1 + 0x2f0;
        var_d8h = (*(int64_t *)(arg1 + 0x2f8) - *(int64_t *)var_e0h >> 4) * -0x5555555555555555;
        piVar11 = (int64_t *)0x0;
        var_d0h = 0;
        *(undefined8 *)(puVar20 + 0x70) = 0;
        *(undefined8 *)(puVar20 + 0x78) = 0;
        puVar20[0x38] = 0;
        *(undefined8 *)(puVar20 + 0x30) = 0;
        *(undefined8 *)(puVar20 + 0x28) = 0;
        if (*(char *)(arg1 + 0x58) == '\0') {
            *(undefined8 *)(puVar20 + 0x20) = 0;
        } else {
            *(undefined **)(puVar20 + 0x20) = puVar20 + 0x70;
        }
        *(undefined8 *)(puVar20 + -8) = 0x1800df26e;
        func_0x0001800e4340(arg1, &var_70h, &var_e0h);
        piVar2 = (int32_t *)(*(int64_t *)(arg1 + 0x1e8) + 0xf4);
        *piVar2 = *piVar2 + -1;
        var_70h = arg1 + 0x308;
        var_f0h = *(int64_t *)(arg1 + 0x310) - *(int64_t *)var_70h >> 3;
        var_60h = 0;
        var_c8h = arg1 + 0x290;
        iVar18 = *(int64_t *)(arg1 + 0x298) - *(int64_t *)var_c8h;
        var_f8h = iVar18 >> 3;
        var_c0h._0_4_ = (undefined4)var_f8h;
        var_c0h._4_4_ = (int32_t)(iVar18 >> 0x23);
        var_b8h = 0;
        var_118h = arg1 + 0x440;
        var_110h = *(int64_t *)(arg1 + 0x448) - *(int64_t *)var_118h >> 3;
        var_108h = 0;
        puVar20[0x40] = 0;
        piVar12 = piVar11;
        uVar23 = (undefined4)var_a8h;
        uVar24 = var_a8h._4_4_;
        uVar25 = uStack_a0;
        uVar26 = uStack_9c;
        var_100h = var_118h;
        var_68h = var_f0h;
        if (*piVar1 == 0x3d) {
            uVar23 = *(undefined4 *)(arg1 + 0x84);
            uVar24 = *(undefined4 *)(arg1 + 0x88);
            uVar25 = *(undefined4 *)(arg1 + 0x8c);
            uVar26 = *(undefined4 *)(arg1 + 0x90);
            puVar20[0x40] = 1;
            *(undefined8 *)(puVar20 + -8) = 0x1800df30a;
            func_0x0001800f0350(arg1);
            piVar16 = &var_118h;
            if (*(char *)(arg1 + 0x58) == '\0') {
                piVar16 = piVar11;
            }
            *(undefined8 *)(puVar20 + -8) = 0x1800df320;
            uVar14 = func_0x0001800e9350(arg1, 0);
            *(undefined8 *)(puVar20 + 0x48) = uVar14;
            *(undefined8 *)(puVar20 + -8) = 0x1800df336;
            func_0x0001800bf890(arg1 + 0x290, puVar20 + 0x48);
            var_b8h = 1;
            piVar12 = (int64_t *)0x1;
            if (*piVar1 == 0x2c) {
                do {
                    piVar12 = (int64_t *)var_b8h;
                    if (piVar16 != (int64_t *)0x0) {
                        *(undefined8 *)(puVar20 + -8) = 0x1800df35a;
                        func_0x0001800f1a70(piVar16, arg1 + 0x84);
                    }
                    *(undefined8 *)(puVar20 + -8) = 0x1800df362;
                    func_0x0001800f0350(arg1);
                    if (*piVar1 == 0x29) {
                        *(undefined8 *)(puVar20 + -8) = 0x1800df3ae;
                        func_0x0001800efe70(arg1, piVar22, 0x1806433c8);
                        var_100h = var_118h;
                        goto code_r0x0001800df3bc;
                    }
                    *(undefined8 *)(puVar20 + -8) = 0x1800df372;
                    uVar14 = func_0x0001800e9350(arg1, 0);
                    *(undefined8 *)(puVar20 + 0x48) = uVar14;
                    *(undefined8 *)(puVar20 + -8) = 0x1800df388;
                    func_0x0001800bf890(arg1 + 0x290);
                    var_b8h = (int64_t)piVar12 + 1;
                } while (*piVar1 == 0x2c);
                var_100h = var_118h;
                piVar12 = (int64_t *)var_b8h;
            }
        }
code_r0x0001800df3bc:
        iVar10 = var_d0h;
        iVar9 = var_d8h;
        iVar18 = var_e0h;
        var_e8h = var_d8h;
        *(int64_t *)(puVar20 + 0x48) = var_e0h;
        piVar22 = piVar11;
        if (var_d0h != 0) {
            do {
                iVar3 = *(int64_t *)iVar18;
                *(undefined8 *)(puVar20 + -8) = 0x1800df407;
                uVar14 = func_0x0001800eef70(arg1, ((int64_t)piVar22 + iVar9) * 0x30 + iVar3);
                *(undefined8 *)(puVar20 + 0x50) = uVar14;
                *(undefined8 *)(puVar20 + -8) = 0x1800df419;
                func_0x0001800bf890((int64_t *)(arg1 + 0x308), puVar20 + 0x50);
                piVar11 = (int64_t *)((int64_t)piVar11 + 1);
                piVar22 = (int64_t *)((int64_t)piVar22 + 1);
                piVar12 = (int64_t *)var_b8h;
                var_60h = (int64_t)piVar11;
            } while (piVar22 < (uint64_t)iVar10);
        }
        piVar22 = (int64_t *)0x0;
        if (piVar12 == (int64_t *)0x0) {
            puVar17 = (undefined4 *)(arg1 + 0xa0);
        } else {
            puVar17 = (undefined4 *)(*(int64_t *)(*(int64_t *)(arg1 + 0x298) + -8) + 0xc);
        }
        var_90h._0_4_ = *puVar17;
        var_90h._4_4_ = puVar17[1];
        var_88h._0_4_ = puVar17[2];
        var_88h._4_4_ = puVar17[3];
        *(undefined8 *)(puVar20 + 0x50) = *(undefined8 *)(arg1 + 0xd8);
        piVar16 = piVar22;
        if (piVar12 != (int64_t *)0x0) {
            piVar16 = (int64_t *)(*(int64_t *)(arg1 + 0x290) + var_f8h * 8);
        }
        *(undefined8 *)(puVar20 + -8) = 0x1800df488;
        func_0x0001800f1110(arg1, &var_80h, piVar16, piVar12);
        piVar12 = piVar22;
        if (piVar11 != (int64_t *)0x0) {
            piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x308) + var_f0h * 8);
        }
        if (piVar11 != (int64_t *)0x0) {
            uVar14 = *(undefined8 *)(arg1 + 0xd8);
            *(undefined8 *)(puVar20 + -8) = 0x1800df4ba;
            piVar15 = (int64_t *)func_0x0001800d4d20(uVar14, (int64_t)piVar11 * 8);
            piVar16 = piVar22;
            if (((int64_t *)0x1 < piVar11) &&
               ((piVar12 + (int64_t)piVar11 + -1 < piVar15 || (piVar15 + (int64_t)piVar11 + -1 < piVar12)))) {
                *(undefined8 *)(puVar20 + -8) = 0x1800df4f5;
                func_0x000180498030(piVar15, piVar12, (int64_t)piVar11 * 8);
                do {
                    piVar22 = (int64_t *)((int64_t)piVar22 + 1);
                    piVar16 = piVar22;
                } while (piVar22 < piVar11);
            }
            for (; piVar22 = piVar15, piVar16 < piVar11; piVar16 = (int64_t *)((int64_t)piVar16 + 1)) {
                piVar15[(int64_t)piVar16] = piVar12[(int64_t)piVar16];
            }
        }
        *(undefined8 *)(puVar20 + 0x60) = *(undefined8 *)(puVar20 + 0x60);
        *(uint64_t *)(puVar20 + 0x68) = CONCAT44(var_88h._4_4_, (undefined4)var_88h);
        ppiVar13 = *(int64_t ***)(puVar20 + 0x50);
        iVar18 = (int64_t)*ppiVar13;
        if (iVar18 == 0) {
code_r0x0001800df56f:
            *(undefined8 *)(puVar20 + -8) = 0x1800df579;
            piVar12 = (int64_t *)func_0x000180459890(0x2008);
            *piVar12 = (int64_t)*ppiVar13;
            *ppiVar13 = piVar12;
            piVar12 = piVar12 + 1;
            piVar16 = (int64_t *)0x78;
        } else {
            piVar12 = (int64_t *)((int64_t)ppiVar13[1] + iVar18 + 0xf & 0xfffffffffffffff8);
            if ((int64_t *)(iVar18 + 0x2008) < piVar12 + 0xf) goto code_r0x0001800df56f;
            piVar16 = (int64_t *)((int64_t)piVar12 + (0x78 - (iVar18 + 8)));
        }
        ppiVar13[1] = piVar16;
        *(undefined4 *)(piVar12 + 1) = *(undefined4 *)0x1807826f8;
        uVar5 = *(undefined4 *)(puVar20 + 100);
        uVar6 = *(undefined4 *)(puVar20 + 0x68);
        uVar7 = *(undefined4 *)(puVar20 + 0x6c);
        *(undefined4 *)((int64_t)piVar12 + 0xc) = *(undefined4 *)(puVar20 + 0x60);
        *(undefined4 *)(piVar12 + 2) = uVar5;
        *(undefined4 *)((int64_t)piVar12 + 0x14) = uVar6;
        *(undefined4 *)(piVar12 + 3) = uVar7;
        *(undefined *)(piVar12 + 4) = 0;
        *piVar12 = 0x180641a68;
        piVar12[5] = (int64_t)piVar22;
        piVar12[6] = (int64_t)piVar11;
        *(undefined4 *)(piVar12 + 7) = (undefined4)var_80h;
        *(undefined4 *)((int64_t)piVar12 + 0x3c) = var_80h._4_4_;
        *(undefined4 *)(piVar12 + 8) = uStack_78;
        *(undefined4 *)((int64_t)piVar12 + 0x44) = uStack_74;
        *(undefined2 *)(piVar12 + 9) = 0;
        *(undefined *)((int64_t)piVar12 + 0x5c) = 0;
        *(undefined4 *)(piVar12 + 0xc) = uVar23;
        *(undefined4 *)((int64_t)piVar12 + 100) = uVar24;
        *(undefined4 *)(piVar12 + 0xd) = uVar25;
        *(undefined4 *)((int64_t)piVar12 + 0x6c) = uVar26;
        *(undefined *)(piVar12 + 0xe) = puVar20[0x40];
        *(undefined2 *)((int64_t)piVar12 + 0x71) = var_97h;
        *(undefined *)((int64_t)piVar12 + 0x73) = var_95h;
        if (*(char *)(arg1 + 0x58) != '\0') {
            ppiVar13 = *(int64_t ***)(arg1 + 0xd8);
            *(undefined8 *)(puVar20 + -8) = 0x1800df605;
            puVar17 = (undefined4 *)func_0x0001800f0e50(arg1, &var_90h, &var_118h);
            *(undefined8 *)(puVar20 + -8) = 0x1800df618;
            uVar14 = func_0x0001800e4200(arg1, &var_a8h, &var_e0h);
            *(undefined8 *)(puVar20 + 0x50) = uVar14;
            iVar18 = (int64_t)*ppiVar13;
            if (iVar18 == 0) {
code_r0x0001800df654:
                *(undefined8 *)(puVar20 + -8) = 0x1800df65e;
                piVar22 = (int64_t *)func_0x000180459890(0x2008);
                *piVar22 = (int64_t)*ppiVar13;
                *ppiVar13 = piVar22;
                piVar22 = piVar22 + 1;
                piVar11 = (int64_t *)0x38;
            } else {
                piVar22 = (int64_t *)((int64_t)ppiVar13[1] + iVar18 + 0xf & 0xfffffffffffffff8);
                if ((int64_t *)(iVar18 + 0x2008U) < piVar22 + 7) goto code_r0x0001800df654;
                piVar11 = (int64_t *)((int64_t)piVar22 + (0x38 - (iVar18 + 8)));
            }
            ppiVar13[1] = piVar11;
            uVar23 = *puVar17;
            uVar24 = puVar17[1];
            uVar25 = puVar17[2];
            uVar26 = puVar17[3];
            puVar17 = *(undefined4 **)(puVar20 + 0x50);
            uVar5 = *puVar17;
            uVar6 = puVar17[1];
            uVar7 = puVar17[2];
            uVar8 = puVar17[3];
            *(undefined4 *)piVar22 = *(undefined4 *)0x180782a78;
            *(undefined4 *)(piVar22 + 1) = uVar5;
            *(undefined4 *)((int64_t)piVar22 + 0xc) = uVar6;
            *(undefined4 *)(piVar22 + 2) = uVar7;
            *(undefined4 *)((int64_t)piVar22 + 0x14) = uVar8;
            uVar5 = *(undefined4 *)(puVar20 + 0x74);
            uVar6 = *(undefined4 *)(puVar20 + 0x78);
            uVar7 = *(undefined4 *)(puVar20 + 0x7c);
            *(undefined4 *)(piVar22 + 3) = *(undefined4 *)(puVar20 + 0x70);
            *(undefined4 *)((int64_t)piVar22 + 0x1c) = uVar5;
            *(undefined4 *)(piVar22 + 4) = uVar6;
            *(undefined4 *)((int64_t)piVar22 + 0x24) = uVar7;
            *(undefined4 *)(piVar22 + 5) = uVar23;
            *(undefined4 *)((int64_t)piVar22 + 0x2c) = uVar24;
            *(undefined4 *)(piVar22 + 6) = uVar25;
            *(undefined4 *)((int64_t)piVar22 + 0x34) = uVar26;
            *(int64_t **)(puVar20 + 0x50) = piVar12;
            *(undefined8 *)(puVar20 + -8) = 0x1800df6b0;
            ppiVar13 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, puVar20 + 0x50);
            *ppiVar13 = piVar22;
        }
        iVar18 = *(int64_t *)var_100h + var_110h * 8;
        if (iVar18 != *(int64_t *)(var_100h + 8)) {
            *(int64_t *)(var_100h + 8) = iVar18;
        }
        iVar18 = *(int64_t *)(arg1 + 0x290) + var_f8h * 8;
        if (iVar18 != *(int64_t *)(arg1 + 0x298)) {
            *(int64_t *)(arg1 + 0x298) = iVar18;
        }
        iVar18 = *(int64_t *)(arg1 + 0x308) + var_f0h * 8;
        if (iVar18 != *(int64_t *)(arg1 + 0x310)) {
            *(int64_t *)(arg1 + 0x310) = iVar18;
        }
        piVar22 = *(int64_t **)(puVar20 + 0x48);
        iVar18 = var_e8h * 0x30 + *piVar22;
        if (iVar18 != piVar22[1]) {
            piVar22[1] = iVar18;
        }
        goto code_r0x0001800df724;
    }
    var_c8h._0_4_ = *piVar1;
    var_c8h._4_4_ = *(int32_t *)(arg1 + 0x84);
    uVar24 = *(undefined4 *)(arg1 + 0x88);
    var_c0h._4_4_ = *(int32_t *)(arg1 + 0x8c);
    var_b8h = *(int64_t *)(arg1 + 0x90);
    uStack_b0 = *(undefined4 *)(arg1 + 0x98);
    uStack_ac = *(undefined4 *)(arg1 + 0x9c);
    var_c0h._0_4_ = uVar24;
    func_0x0001800f0350(arg1);
    uVar14 = CONCAT44((undefined4)var_c0h, var_c8h._4_4_);
    var_c0h._0_4_ = uVar24;
    if (var_c8h._4_4_ == iVar21) {
        var_c0h._0_4_ = uVar23;
    }
    if (*piVar1 == 0x119) {
        var_70h = *(int64_t *)(arg1 + 0x98);
        var_68h = *piVar22;
        iVar18 = *(int64_t *)(arg1 + 0x8c);
        var_60h = iVar18;
        func_0x0001800f0350(arg1);
        var_118h = var_70h;
        var_110h = var_68h;
        var_108h = iVar18;
    } else {
        func_0x0001800efe90(arg1, 0x180642ae8);
        var_148h._0_4_ = *(undefined4 *)piVar22;
        var_148h._4_4_ = *(undefined4 *)(arg1 + 0x88);
        var_110h = *piVar22;
        var_140h = *piVar22;
        var_118h = *(int64_t *)(arg1 + 0x128);
        var_108h = *piVar22;
    }
    piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x1e8) + 0x4a0);
    *piVar1 = *piVar1 + 1;
    var_160h._0_1_ = 0;
    var_170h = (int64_t)&var_118h;
    var_178h = (int64_t)&var_118h;
    var_168h = arg2;
    func_0x0001800e3690(arg1, &var_148h, 0, &var_c8h);
    piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x1e8) + 0x4a0);
    *piVar1 = *piVar1 + -1;
    var_128h = var_138h;
    iVar9 = CONCAT44(var_148h._4_4_, (undefined4)var_148h);
    var_120h = *(int64_t *)(iVar9 + 0x14);
    ppiVar13 = *(int64_t ***)(arg1 + 0xd8);
    iVar18 = (int64_t)*ppiVar13;
    if (iVar18 == 0) {
code_r0x0001800df04d:
        piVar22 = (int64_t *)func_0x000180459890(0x2008);
        *piVar22 = (int64_t)*ppiVar13;
        *ppiVar13 = piVar22;
        piVar22 = piVar22 + 1;
        piVar11 = (int64_t *)0x40;
    } else {
        piVar22 = (int64_t *)((int64_t)ppiVar13[1] + iVar18 + 0xf & 0xfffffffffffffff8);
        if ((int64_t *)(iVar18 + 0x2008) < piVar22 + 8) goto code_r0x0001800df04d;
        piVar11 = (int64_t *)((int64_t)piVar22 + (0x40 - (iVar18 + 8)));
    }
    ppiVar13[1] = piVar11;
    *(undefined4 *)(piVar22 + 1) = *(undefined4 *)0x1807826c4;
    *(undefined4 *)((int64_t)piVar22 + 0xc) = (undefined4)var_128h;
    *(undefined4 *)(piVar22 + 2) = var_128h._4_4_;
    *(undefined4 *)((int64_t)piVar22 + 0x14) = (undefined4)var_120h;
    *(undefined4 *)(piVar22 + 3) = var_120h._4_4_;
    *(undefined *)(piVar22 + 4) = 0;
    *piVar22 = 0x180641f28;
    piVar22[5] = var_140h;
    piVar22[6] = iVar9;
    *(undefined *)(piVar22 + 7) = 0;
    if (*(char *)(arg1 + 0x58) != '\0') {
        ppiVar13 = *(int64_t ***)(arg1 + 0xd8);
        iVar18 = (int64_t)*ppiVar13;
        if (iVar18 == 0) {
code_r0x0001800df0eb:
            piVar11 = (int64_t *)func_0x000180459890(0x2008);
            *piVar11 = (int64_t)*ppiVar13;
            *ppiVar13 = piVar11;
            piVar11 = piVar11 + 1;
            piVar12 = (int64_t *)0x14;
        } else {
            piVar11 = (int64_t *)((int64_t)ppiVar13[1] + iVar18 + 0xf & 0xfffffffffffffff8);
            if (iVar18 + 0x2008U < (int64_t)piVar11 + 0x14U) goto code_r0x0001800df0eb;
            piVar12 = (int64_t *)((int64_t)piVar11 + (0x14 - (iVar18 + 8)));
        }
        ppiVar13[1] = piVar12;
        *(undefined4 *)piVar11 = *(undefined4 *)0x180782a44;
        *(int64_t *)((int64_t)piVar11 + 4) = var_150h;
        *(undefined8 *)((int64_t)piVar11 + 0xc) = uVar14;
        var_150h = (int64_t)piVar22;
        ppiVar13 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_150h);
        *ppiVar13 = piVar11;
    }
    puVar20 = auStack_198;
code_r0x0001800df724:
    *(undefined8 *)(puVar20 + -8) = 0x1800df730;
    func_0x000180459870(var_50h ^ (uint64_t)puVar20);
    return;
}

// ============================================================
// Function: FUN_1800df760
// Address: 0x1800df760
// Size: 2392 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.1800df760(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int32_t *piVar1;
    int32_t *piVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    code *pcVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    char cVar11;
    undefined *puVar12;
    int64_t *piVar13;
    int64_t *piVar14;
    int64_t **ppiVar15;
    undefined8 uVar16;
    undefined4 *puVar17;
    undefined8 uVar18;
    int64_t iVar19;
    undefined8 uVar20;
    undefined8 *puVar21;
    uint64_t uVar22;
    uint64_t uVar23;
    undefined *puVar24;
    int64_t *piVar25;
    int64_t *piVar26;
    int64_t *piVar27;
    int64_t var_18h;
    undefined auStack_198 [8];
    undefined auStack_190 [24];
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    undefined4 uStack_d0;
    undefined4 uStack_cc;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a0h;
    undefined4 uStack_98;
    undefined4 uStack_94;
    undefined4 uStack_90;
    undefined4 uStack_8c;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    cVar11 = (char)arg_28h;
    puVar24 = auStack_198;
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_198;
    var_158h._0_1_ = (char)arg_28h;
    var_110h = arg2;
    if ((char)arg_28h == '\0') {
        func_0x0001800f0350();
    }
    piVar1 = (int32_t *)(arg1 + 0x80);
    if (*piVar1 != 299) {
        puVar12 = auStack_198;
        if (*(int64_t *)(arg4 + 8) == 0) {
code_r0x0001800dfab8:
            puVar24 = puVar12;
            piVar2 = (int32_t *)(*(int64_t *)(arg1 + 0x1e8) + 0xf4);
            *piVar2 = *piVar2 + 1;
            var_e8h = arg1 + 0x2f0;
            var_e0h = (*(int64_t *)(arg1 + 0x2f8) - *(int64_t *)var_e8h >> 4) * -0x5555555555555555;
            piVar26 = (int64_t *)0x0;
            var_d8h = 0;
            *(undefined8 *)(puVar24 + 0x58) = 0;
            *(undefined8 *)(puVar24 + 0x60) = 0;
            puVar24[0x38] = cVar11;
            *(undefined8 *)(puVar24 + 0x30) = 0;
            *(undefined8 *)(puVar24 + 0x28) = 0;
            if (*(char *)(arg1 + 0x58) == '\0') {
                *(undefined8 *)(puVar24 + 0x20) = 0;
            } else {
                *(undefined **)(puVar24 + 0x20) = puVar24 + 0x58;
            }
            *(undefined8 *)(puVar24 + -8) = 0x1800dfb36;
            func_0x0001800e4340(arg1, &var_70h, &var_e8h);
            piVar2 = (int32_t *)(*(int64_t *)(arg1 + 0x1e8) + 0xf4);
            *piVar2 = *piVar2 + -1;
            var_100h = arg1 + 0x308;
            var_f8h = *(int64_t *)(arg1 + 0x310) - *(int64_t *)var_100h >> 3;
            var_f0h = 0;
            piVar13 = (int64_t *)(arg1 + 0x290);
            var_68h = *(int64_t *)(arg1 + 0x298) - *piVar13 >> 3;
            *(int64_t *)(puVar24 + 0x68) = var_68h;
            var_60h = 0;
            var_c8h = arg1 + 0x440;
            var_c0h = *(int64_t *)(arg1 + 0x448) - *(int64_t *)var_c8h >> 3;
            var_118h = var_c0h;
            var_b8h = 0;
            var_88h._0_1_ = 0;
            piVar27 = piVar26;
            var_a0h = var_f8h;
            var_70h = (int64_t)piVar13;
            piVar14 = (int64_t *)var_e8h;
            iVar19 = var_e0h;
            if (*piVar1 == 0x3d) {
                uStack_98 = *(undefined4 *)(arg1 + 0x84);
                uStack_94 = *(undefined4 *)(arg1 + 0x88);
                uStack_90 = *(undefined4 *)(arg1 + 0x8c);
                uStack_8c = *(undefined4 *)(arg1 + 0x90);
                var_88h._0_1_ = 1;
                *(undefined8 *)(puVar24 + -8) = 0x1800dfbd7;
                func_0x0001800f0350(arg1);
                piVar25 = &var_c8h;
                if (*(char *)(arg1 + 0x58) == '\0') {
                    piVar25 = piVar26;
                }
                *(undefined8 *)(puVar24 + -8) = 0x1800dfbed;
                uVar16 = func_0x0001800e9350(arg1, 0);
                *(undefined8 *)(puVar24 + 0x48) = uVar16;
                *(undefined8 *)(puVar24 + -8) = 0x1800dfbff;
                func_0x0001800bf890(piVar13, puVar24 + 0x48);
                piVar27 = (int64_t *)0x1;
                var_60h = 1;
                piVar14 = (int64_t *)var_e8h;
                iVar19 = var_e0h;
                if (*piVar1 == 0x2c) {
                    do {
                        piVar27 = (int64_t *)var_60h;
                        if (piVar25 != (int64_t *)0x0) {
                            *(undefined8 *)(puVar24 + -8) = 0x1800dfc24;
                            func_0x0001800f1a70(piVar25, arg1 + 0x84);
                        }
                        *(undefined8 *)(puVar24 + -8) = 0x1800dfc2c;
                        func_0x0001800f0350(arg1);
                        if (*piVar1 == 0x29) {
                            *(undefined8 *)(puVar24 + -8) = 0x1800dfc70;
                            func_0x0001800efe70(arg1, arg1 + 0x84, 0x1806433c8);
                            piVar14 = (int64_t *)var_e8h;
                            iVar19 = var_e0h;
                            break;
                        }
                        *(undefined8 *)(puVar24 + -8) = 0x1800dfc3c;
                        uVar16 = func_0x0001800e9350(arg1, 0);
                        *(undefined8 *)(puVar24 + 0x48) = uVar16;
                        *(undefined8 *)(puVar24 + -8) = 0x1800dfc4e;
                        func_0x0001800bf890(piVar13);
                        piVar27 = (int64_t *)((int64_t)piVar27 + 1);
                        var_60h = (int64_t)piVar27;
                        piVar14 = (int64_t *)var_e8h;
                        iVar19 = var_e0h;
                    } while (*piVar1 == 0x2c);
                    var_118h = var_c0h;
                }
            }
            iVar4 = var_d8h;
            piVar13 = piVar26;
            var_e8h = (int64_t)piVar14;
            var_e0h = iVar19;
            if (var_d8h != 0) {
                do {
                    iVar6 = *piVar14;
                    *(undefined8 *)(puVar24 + -8) = 0x1800dfca8;
                    uVar16 = func_0x0001800eef70(arg1, (iVar19 + (int64_t)piVar26) * 0x30 + iVar6);
                    *(undefined8 *)(puVar24 + 0x48) = uVar16;
                    *(undefined8 *)(puVar24 + -8) = 0x1800dfcbe;
                    func_0x0001800bf890(arg1 + 0x308, puVar24 + 0x48);
                    piVar13 = (int64_t *)((int64_t)piVar13 + 1);
                    piVar26 = (int64_t *)((int64_t)piVar26 + 1);
                    piVar27 = (int64_t *)var_60h;
                    var_f0h = (int64_t)piVar13;
                } while (piVar26 < (uint64_t)iVar4);
            }
            piVar26 = (int64_t *)(arg1 + 0x290);
            uVar23 = 0;
            if (piVar27 == (int64_t *)0x0) {
                puVar17 = (undefined4 *)(arg1 + 0xa0);
            } else {
                puVar17 = (undefined4 *)(*(int64_t *)(*(int64_t *)(arg1 + 0x298) + -8) + 0xc);
            }
            uVar8 = puVar17[1];
            uVar9 = puVar17[2];
            uVar10 = puVar17[3];
            *(undefined4 *)(puVar24 + 0x70) = *puVar17;
            *(undefined4 *)(puVar24 + 0x74) = uVar8;
            *(undefined4 *)(puVar24 + 0x78) = uVar9;
            *(undefined4 *)(puVar24 + 0x7c) = uVar10;
            if (*(char *)0x1807784e0 == '\0') {
                if ((puVar24[0x40] == '\0') ||
                   (((piVar27 != (int64_t *)0x0 &&
                     ((iVar5 = *(int32_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x298) + -8) + 8),
                      iVar5 == *(int32_t *)0x180782740 || (iVar5 == *(int32_t *)0x1807826b8)))) || (piVar27 == piVar13))
                   )) {
                    uVar16 = *(undefined8 *)(arg1 + 0xd8);
                    uVar22 = uVar23;
                    if (piVar27 != (int64_t *)0x0) {
                        uVar22 = *piVar26 + *(int64_t *)(puVar24 + 0x68) * 8;
                    }
                    *(undefined8 *)(puVar24 + -8) = 0x1800dff6d;
                    func_0x0001800f1110(arg1, &var_b0h, uVar22, piVar27);
                    *(undefined8 *)(puVar24 + -8) = 0x1800dff7d;
                    uVar18 = func_0x0001800f0e50(arg1, &var_80h, &var_100h);
                    *(undefined8 *)(puVar24 + 0x48) = *(undefined8 *)var_110h;
                    *(undefined8 *)(puVar24 + 0x50) = *(undefined8 *)(puVar24 + 0x78);
                    *(int64_t **)(puVar24 + 0x28) = &arg_28h;
                    *(undefined4 **)(puVar24 + 0x20) = &uStack_98;
                    *(undefined8 *)(puVar24 + -8) = 0x1800dffbc;
                    uVar16 = func_0x0001800f0ff0(uVar16, puVar24 + 0x48, uVar18, &var_b0h);
                    iVar19 = var_b8h;
                    piVar14 = (int64_t *)var_c8h;
                    if (*(char *)(arg1 + 0x58) != '\0') {
                        var_110h = *(int64_t *)(arg1 + 0xd8);
                        if (var_b8h == 0) {
                            *(undefined8 *)(puVar24 + 0x70) = 0;
                            *(undefined8 *)(puVar24 + 0x78) = 0;
                        } else {
                            *(undefined8 *)(puVar24 + 0x48) = *(undefined8 *)var_c8h;
                            iVar4 = var_b8h * 8;
                            *(undefined8 *)(puVar24 + -8) = 0x1800e0008;
                            uVar22 = func_0x0001800d4d20(var_110h, iVar4);
                            *(uint64_t *)(puVar24 + 0x70) = uVar22;
                            *(int64_t *)(puVar24 + 0x78) = iVar19;
                            if (iVar19 != 0) {
                                uVar3 = *(int64_t *)(puVar24 + 0x48) + var_118h * 8;
                                if (((uint64_t)iVar19 < 2) ||
                                   ((uVar22 <= uVar3 + (iVar19 + -1) * 8 && (uVar3 <= uVar22 + (iVar19 + -1) * 8)))) {
                                    do {
                                        *(undefined8 *)(uVar22 + uVar23 * 8) = *(undefined8 *)(uVar3 + uVar23 * 8);
                                        uVar23 = uVar23 + 1;
                                    } while (uVar23 < (uint64_t)iVar19);
                                } else {
                                    *(undefined8 *)(puVar24 + -8) = 0x1800e0052;
                                    func_0x000180498030(uVar22, uVar3, iVar4);
                                }
                            }
                        }
                        *(undefined8 *)(puVar24 + -8) = 0x1800e0080;
                        uVar18 = func_0x0001800e4200(arg1, &var_80h, &var_e8h);
                        *(undefined8 *)(puVar24 + -8) = 0x1800e0096;
                        uVar18 = func_0x0001800f0f40(var_110h, uVar18, puVar24 + 0x58, puVar24 + 0x70);
                        *(undefined8 *)(puVar24 + 0x48) = uVar16;
                        *(undefined8 *)(puVar24 + -8) = 0x1800e00af;
                        puVar21 = (undefined8 *)func_0x0001800cc970(arg1 + 0x490, puVar24 + 0x48);
                        *puVar21 = uVar18;
                    }
                } else {
                    *(undefined8 *)(puVar24 + 0x58) = 0;
                    *(undefined8 *)(puVar24 + 0x60) = 0;
                    *(undefined8 *)(puVar24 + 0x48) = 0;
                    *(undefined8 *)(puVar24 + 0x50) = 0;
                    var_110h = *(int64_t *)var_110h;
                    var_108h = *(int64_t *)(puVar24 + 0x78);
                    *(undefined8 *)(puVar24 + 0x20) = 0x180642b50;
                    *(undefined8 *)(puVar24 + -8) = 0x1800dff38;
                    func_0x0001800eff80(arg1, &var_110h, puVar24 + 0x48, puVar24 + 0x58);
                    piVar14 = (int64_t *)var_c8h;
                }
            } else {
                uVar16 = *(undefined8 *)(arg1 + 0xd8);
                if (piVar27 != (int64_t *)0x0) {
                    uVar23 = *piVar26 + *(int64_t *)(puVar24 + 0x68) * 8;
                }
                *(undefined8 *)(puVar24 + -8) = 0x1800dfd35;
                func_0x0001800f1110(arg1, &var_b0h, uVar23, piVar27);
                *(undefined8 *)(puVar24 + -8) = 0x1800dfd45;
                uVar18 = func_0x0001800f0e50(arg1, &var_80h, &var_100h);
                *(undefined8 *)(puVar24 + 0x48) = *(undefined8 *)var_110h;
                *(undefined8 *)(puVar24 + 0x50) = *(undefined8 *)(puVar24 + 0x78);
                *(int64_t **)(puVar24 + 0x28) = &arg_28h;
                *(undefined4 **)(puVar24 + 0x20) = &uStack_98;
                *(undefined8 *)(puVar24 + -8) = 0x1800dfd84;
                iVar19 = func_0x0001800f0ff0(uVar16, puVar24 + 0x48, uVar18, &var_b0h);
                if (*(char *)(arg1 + 0x58) != '\0') {
                    uVar16 = *(undefined8 *)(arg1 + 0xd8);
                    *(undefined8 *)(puVar24 + -8) = 0x1800dfda4;
                    uVar18 = func_0x0001800f0e50(arg1, &var_b0h, &var_c8h);
                    *(undefined8 *)(puVar24 + -8) = 0x1800dfdb8;
                    uVar20 = func_0x0001800e4200(arg1, puVar24 + 0x70, &var_e8h);
                    *(undefined8 *)(puVar24 + -8) = 0x1800dfdcb;
                    uVar16 = func_0x0001800f0f40(uVar16, uVar20, puVar24 + 0x58, uVar18);
                    *(int64_t *)(puVar24 + 0x48) = iVar19;
                    *(undefined8 *)(puVar24 + -8) = 0x1800dfde4;
                    puVar21 = (undefined8 *)func_0x0001800cc970(arg1 + 0x490, puVar24 + 0x48);
                    *puVar21 = uVar16;
                }
                piVar14 = (int64_t *)var_c8h;
                if (((puVar24[0x40] != '\0') &&
                    ((piVar27 == (int64_t *)0x0 ||
                     ((iVar5 = *(int32_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x298) + -8) + 8),
                      iVar5 != *(int32_t *)0x180782740 && (iVar5 != *(int32_t *)0x1807826b8)))))) &&
                   (piVar27 != piVar13)) {
                    *(undefined8 *)(puVar24 + -8) = 0x1800dfe27;
                    func_0x0001800efe70(arg1, iVar19 + 0xc, 0x180642b50);
                    piVar14 = (int64_t *)var_c8h;
                }
            }
            iVar19 = *piVar14 + var_118h * 8;
            if (iVar19 != piVar14[1]) {
                piVar14[1] = iVar19;
            }
            if (*piVar26 + *(int64_t *)(puVar24 + 0x68) * 8 != *(int64_t *)(arg1 + 0x298)) {
                *(int64_t *)(arg1 + 0x298) = *piVar26 + *(int64_t *)(puVar24 + 0x68) * 8;
            }
            iVar19 = *(int64_t *)var_100h + var_a0h * 8;
            if (iVar19 != *(int64_t *)(var_100h + 8)) {
                *(int64_t *)(var_100h + 8) = iVar19;
            }
            iVar19 = var_e0h * 0x30 + *(int64_t *)var_e8h;
            if (iVar19 != *(int64_t *)(var_e8h + 8)) {
                *(int64_t *)(var_e8h + 8) = iVar19;
            }
        } else {
            var_170h = func_0x0001800d62b0(piVar1, &var_70h);
            if (0xf < *(uint64_t *)(var_170h + 0x18)) {
                var_170h = *(int64_t *)var_170h;
            }
            var_140h = 0;
            var_138h = 0;
            var_128h = 0;
            var_120h = 0;
            var_178h = 0x180642b00;
            func_0x0001800eff80(arg1, arg1 + 0x84, &var_128h);
            if (0xf < (uint64_t)var_58h) {
                uVar23 = var_58h + 1;
                iVar19 = var_70h;
                if (0xfff < uVar23) {
                    iVar19 = *(int64_t *)(var_70h + -8);
                    if (0x1f < (var_70h - iVar19) - 8U) {
                        pcVar7 = (code *)swi(0x29);
                        (*pcVar7)(5);
                        puVar12 = auStack_190;
                        goto code_r0x0001800dfab8;
                    }
                    uVar23 = var_58h + 0x28;
                }
                func_0x000180459c3c(iVar19, uVar23);
            }
        }
        goto code_r0x0001800dfe92;
    }
    var_e8h._0_4_ = *piVar1;
    var_e8h._4_4_ = *(int32_t *)(arg1 + 0x84);
    var_e0h._0_4_ = *(undefined4 *)(arg1 + 0x88);
    var_e0h._4_4_ = *(undefined4 *)(arg1 + 0x8c);
    var_d8h = *(int64_t *)(arg1 + 0x90);
    uStack_d0 = *(undefined4 *)(arg1 + 0x98);
    uStack_cc = *(undefined4 *)(arg1 + 0x9c);
    func_0x0001800f0350(arg1);
    uVar16 = CONCAT44((undefined4)var_e0h, var_e8h._4_4_);
    if (var_e8h._4_4_ == *(int32_t *)arg2) {
        var_e0h._0_4_ = *(undefined4 *)(arg2 + 4);
    }
    if (*piVar1 == 0x119) {
        var_70h = *(int64_t *)(arg1 + 0x98);
        var_68h = *(int64_t *)(arg1 + 0x84);
        iVar19 = *(int64_t *)(arg1 + 0x8c);
        var_60h = iVar19;
        func_0x0001800f0350(arg1);
        var_100h = var_70h;
        var_f8h = var_68h;
        var_f0h = iVar19;
    } else {
        func_0x0001800efe90(arg1, 0x180642ae8);
        piVar26 = (int64_t *)(arg1 + 0x84);
        var_f8h = *piVar26;
        var_140h = *piVar26;
        var_100h = *(int64_t *)(arg1 + 0x128);
        var_138h = var_140h;
        var_f0h = *piVar26;
    }
    piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x1e8) + 0x4a0);
    *piVar1 = *piVar1 + 1;
    var_160h._0_1_ = cVar11;
    var_170h = (int64_t)&var_100h;
    var_178h = (int64_t)&var_100h;
    var_168h = arg4;
    func_0x0001800e3690(arg1, &var_128h, 0, &var_e8h);
    piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x1e8) + 0x4a0);
    *piVar1 = *piVar1 + -1;
    var_140h = *(int64_t *)arg2;
    var_130h = var_128h;
    var_138h = *(int64_t *)(var_128h + 0x14);
    ppiVar15 = *(int64_t ***)(arg1 + 0xd8);
    iVar19 = (int64_t)*ppiVar15;
    if (iVar19 == 0) {
code_r0x0001800df90e:
        piVar26 = (int64_t *)func_0x000180459890(0x2008);
        *piVar26 = (int64_t)*ppiVar15;
        *ppiVar15 = piVar26;
        piVar26 = piVar26 + 1;
        piVar13 = (int64_t *)0x40;
    } else {
        piVar26 = (int64_t *)((int64_t)ppiVar15[1] + iVar19 + 0xf & 0xfffffffffffffff8);
        if ((int64_t *)(iVar19 + 0x2008) < piVar26 + 8) goto code_r0x0001800df90e;
        piVar13 = (int64_t *)((int64_t)piVar26 + (0x40 - (iVar19 + 8)));
    }
    ppiVar15[1] = piVar13;
    *(undefined4 *)(piVar26 + 1) = *(undefined4 *)0x1807826c4;
    *(undefined4 *)((int64_t)piVar26 + 0xc) = (undefined4)var_140h;
    *(undefined4 *)(piVar26 + 2) = var_140h._4_4_;
    *(undefined4 *)((int64_t)piVar26 + 0x14) = (undefined4)var_138h;
    *(undefined4 *)(piVar26 + 3) = var_138h._4_4_;
    *(undefined *)(piVar26 + 4) = 0;
    *piVar26 = 0x180641f28;
    piVar26[5] = var_120h;
    piVar26[6] = var_130h;
    *(char *)(piVar26 + 7) = cVar11;
    if (*(char *)(arg1 + 0x58) != '\0') {
        ppiVar15 = *(int64_t ***)(arg1 + 0xd8);
        iVar19 = (int64_t)*ppiVar15;
        if (iVar19 == 0) {
code_r0x0001800df9b6:
            piVar13 = (int64_t *)func_0x000180459890(0x2008);
            *piVar13 = (int64_t)*ppiVar15;
            *ppiVar15 = piVar13;
            piVar13 = piVar13 + 1;
            piVar14 = (int64_t *)0x14;
        } else {
            piVar13 = (int64_t *)((int64_t)ppiVar15[1] + iVar19 + 0xf & 0xfffffffffffffff8);
            if (iVar19 + 0x2008U < (int64_t)piVar13 + 0x14U) goto code_r0x0001800df9b6;
            piVar14 = (int64_t *)((int64_t)piVar13 + (0x14 - (iVar19 + 8)));
        }
        ppiVar15[1] = piVar14;
        *(undefined4 *)piVar13 = *(undefined4 *)0x180782a44;
        *(int64_t *)((int64_t)piVar13 + 4) = arg3;
        *(undefined8 *)((int64_t)piVar13 + 0xc) = uVar16;
        var_130h = (int64_t)piVar26;
        ppiVar15 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &var_130h);
        *ppiVar15 = piVar13;
    }
    puVar24 = auStack_198;
code_r0x0001800dfe92:
    *(undefined8 *)(puVar24 + -8) = 0x1800dfe9e;
    func_0x000180459870(var_50h ^ (uint64_t)puVar24);
    return;
}

// ============================================================
// Function: FUN_1800e00c0
// Address: 0x1800e00c0
// Size: 718 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: Variable defined which should be unmapped: var_100h
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_f0h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_21h
// WARNING: Variable defined which should be unmapped: var_31h
// WARNING: Type propagation algorithm not settling
// WARNING: [rz-ghidra] Removing arg arg_67h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_59h
// WARNING: [rz-ghidra] Detected overlap for variable var_51h
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_61h
// WARNING: [rz-ghidra] Removing arg arg_6fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_2dh

int64_t * fcn.1800e00c0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4)
{
    int32_t *piVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined auVar4 [16];
    undefined auVar5 [16];
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    char cVar14;
    int64_t *piVar15;
    uint64_t uVar16;
    int64_t *piVar17;
    int64_t *piVar18;
    int64_t **ppiVar19;
    undefined4 *puVar20;
    undefined8 *puVar21;
    undefined8 *puVar22;
    int64_t iVar23;
    int64_t iVar24;
    undefined8 uVar25;
    undefined4 uVar26;
    undefined4 uVar27;
    undefined4 uVar28;
    undefined4 uVar29;
    undefined8 uStackX_8;
    int64_t *piStackX_10;
    undefined uStackX_18;
    int64_t var_20h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t iStack_d8;
    undefined auStack_d0 [16];
    undefined uStack_c0;
    int64_t iStack_b8;
    undefined8 uStack_b0;
    undefined8 uStack_a8;
    undefined8 uStack_90;
    undefined4 uStack_88;
    undefined4 uStack_84;
    undefined4 uStack_80;
    undefined auStack_7c [3];
    int64_t var_79h;
    int64_t var_71h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_49h;
    int64_t var_31h;
    int64_t var_21h;
    
    piStackX_10 = (int64_t *)arg2;
    uStackX_18 = (undefined)placeholder_2;
    if (*(int32_t *)(arg1 + 0x80) != 299) {
        if (*(int32_t *)(arg1 + 0x80) == 0x119) {
            iVar24 = *(int64_t *)(arg1 + 0x98);
            uVar26 = *(undefined4 *)(arg1 + 0x84);
            uVar27 = *(undefined4 *)(arg1 + 0x88);
            uVar28 = *(undefined4 *)(arg1 + 0x8c);
            uVar29 = *(undefined4 *)(arg1 + 0x90);
            func_0x0001800f0350();
        } else {
            func_0x0001800efe90(arg1, 0x180642dc8);
            uVar26 = *(undefined4 *)(arg1 + 0x84);
            uVar27 = *(undefined4 *)(arg1 + 0x88);
            uVar28 = *(undefined4 *)(arg1 + 0x8c);
            uVar29 = *(undefined4 *)(arg1 + 0x90);
            iVar24 = *(int64_t *)(arg1 + 0x128);
        }
        uVar25 = 0;
        uStackX_8 = (int64_t *)0xffffffffffffffff;
        var_e8h = 0;
        var_e0h = 0;
        iStack_b8 = -1;
        if (*(char *)(arg1 + 0x58) == '\0') {
            var_100h = 0;
            puVar22 = &uStack_b0;
            var_108h = 0;
            puVar21 = (undefined8 *)0x0;
        } else {
            var_100h = (int64_t)&iStack_b8;
            puVar21 = &uStackX_8;
            var_108h = (int64_t)&var_e8h;
            puVar22 = &uStack_90;
        }
        puVar20 = (undefined4 *)func_0x0001800ecbd0(arg1, puVar22, 1, puVar21, var_108h, var_100h);
        uVar6 = *puVar20;
        uVar7 = puVar20[1];
        uVar8 = puVar20[2];
        uVar9 = puVar20[3];
        uVar10 = puVar20[4];
        uVar11 = puVar20[5];
        uVar12 = puVar20[6];
        uVar13 = puVar20[7];
        if (*(int32_t *)(arg1 + 0x80) == 0x3d) {
            func_0x0001800f0350(arg1);
code_r0x0001800e046f:
            iVar23 = *(int64_t *)(arg1 + 0xa0);
        } else {
            cVar14 = func_0x0001800ef2a0(arg1, 0x3d, 0x180642dd8);
            if (cVar14 != '\0') goto code_r0x0001800e046f;
            iStack_d8 = -1;
            iVar23 = -1;
        }
        uStack_b0 = *(undefined8 *)(arg1 + 0x84);
        uStack_a8 = *(undefined8 *)(arg1 + 0x8c);
        uVar2 = *(undefined4 *)(arg1 + 0x114);
        if ((*(int32_t *)(arg1 + 0x80) != 0x7c) && (*(int32_t *)(arg1 + 0x80) != 0x26)) {
            puVar21 = (undefined8 *)func_0x0001800e81c0(arg1, &iStack_d8, 0, 0);
            uVar25 = *puVar21;
            *(undefined4 *)(arg1 + 0x114) = uVar2;
        }
        iStack_d8 = func_0x0001800e7930(arg1, uVar25, &uStack_b0);
        ppiVar19 = *(int64_t ***)(arg1 + 0xd8);
        *(undefined4 *)(arg1 + 0x114) = uVar2;
        uStack_b0 = *(undefined8 *)arg2;
        iVar3 = (int64_t)*ppiVar19;
        uStack_a8 = *(undefined8 *)(iStack_d8 + 0x14);
        if (iVar3 == 0) {
code_r0x0001800e051d:
            piVar17 = (int64_t *)func_0x000180459890(0x2008);
            *piVar17 = (int64_t)*ppiVar19;
            piVar15 = piVar17 + 1;
            *ppiVar19 = piVar17;
            piVar17 = (int64_t *)0x70;
        } else {
            piVar15 = (int64_t *)((int64_t)ppiVar19[1] + iVar3 + 0xf & 0xfffffffffffffff8);
            if ((int64_t *)(iVar3 + 0x2008) < piVar15 + 0xe) goto code_r0x0001800e051d;
            piVar17 = (int64_t *)((int64_t)piVar15 + (0x70 - (iVar3 + 8)));
        }
        ppiVar19[1] = piVar17;
        *(undefined4 *)(piVar15 + 1) = *(undefined4 *)0x18078266c;
        *piVar15 = 0x180641f50;
        piVar15[0xc] = iStack_d8;
        *(undefined4 *)(piVar15 + 8) = uVar6;
        *(undefined4 *)((int64_t)piVar15 + 0x44) = uVar7;
        *(undefined4 *)(piVar15 + 9) = uVar8;
        *(undefined4 *)((int64_t)piVar15 + 0x4c) = uVar9;
        *(undefined *)(piVar15 + 0xd) = uStackX_18;
        *(undefined4 *)(piVar15 + 10) = uVar10;
        *(undefined4 *)((int64_t)piVar15 + 0x54) = uVar11;
        *(undefined4 *)(piVar15 + 0xb) = uVar12;
        *(undefined4 *)((int64_t)piVar15 + 0x5c) = uVar13;
        *(undefined *)(piVar15 + 4) = 0;
        *(undefined4 *)((int64_t)piVar15 + 0xc) = (undefined4)uStack_b0;
        *(undefined4 *)(piVar15 + 2) = uStack_b0._4_4_;
        *(undefined4 *)((int64_t)piVar15 + 0x14) = (undefined4)uStack_a8;
        *(undefined4 *)(piVar15 + 3) = uStack_a8._4_4_;
        piVar15[5] = iVar24;
        auVar5._4_4_ = uVar27;
        auVar5._0_4_ = uVar26;
        auVar5._8_4_ = uVar28;
        auVar5._12_4_ = uVar29;
        *(undefined (*) [16])(piVar15 + 6) = auVar5;
        if (*(char *)(arg1 + 0x58) == '\0') {
            return piVar15;
        }
        ppiVar19 = *(int64_t ***)(arg1 + 0xd8);
        iVar24 = (int64_t)*ppiVar19;
        if (iVar24 != 0) {
            piVar17 = (int64_t *)((int64_t)ppiVar19[1] + iVar24 + 0xf & 0xfffffffffffffff8);
            if (piVar17 + 7 <= (int64_t *)(iVar24 + 0x2008U)) {
                piVar18 = (int64_t *)((int64_t)piVar17 + (0x38 - (iVar24 + 8)));
                goto code_r0x0001800e05f6;
            }
        }
        piVar18 = (int64_t *)func_0x000180459890(0x2008);
        *piVar18 = (int64_t)*ppiVar19;
        piVar17 = piVar18 + 1;
        *ppiVar19 = piVar18;
        piVar18 = (int64_t *)0x38;
code_r0x0001800e05f6:
        ppiVar19[1] = piVar18;
        *(undefined4 *)piVar17 = *(undefined4 *)0x180782a7c;
        piVar17[5] = iStack_b8;
        *(int64_t **)((int64_t)piVar17 + 0xc) = uStackX_8;
        *(undefined4 *)(piVar17 + 3) = (undefined4)var_e8h;
        *(undefined4 *)((int64_t)piVar17 + 0x1c) = var_e8h._4_4_;
        *(undefined4 *)(piVar17 + 4) = (undefined4)var_e0h;
        *(undefined4 *)((int64_t)piVar17 + 0x24) = var_e0h._4_4_;
        *(int64_t *)((int64_t)piVar17 + 4) = arg4;
        piVar17[6] = iVar23;
        uStackX_8 = piVar15;
        ppiVar19 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &uStackX_8);
        *ppiVar19 = piVar17;
        return piVar15;
    }
    uStack_90._0_4_ = *(undefined4 *)(arg1 + 0x80);
    uStack_90._4_4_ = *(undefined4 *)(arg1 + 0x84);
    uStack_88 = *(undefined4 *)(arg1 + 0x88);
    uStack_84 = *(undefined4 *)(arg1 + 0x8c);
    uStack_80 = *(undefined4 *)(arg1 + 0x90);
    _auStack_7c = *(undefined4 *)(arg1 + 0x94);
    var_79h._1_4_ = *(undefined4 *)(arg1 + 0x98);
    unique0x10000486 = *(undefined4 *)(arg1 + 0x9c);
    func_0x0001800f0350();
    iVar24 = *(int64_t *)(arg1 + 0x1d8) - *(int64_t *)(arg1 + 0x1d0) >> 3;
    if (*(int32_t *)(arg1 + 0x80) == 0x119) {
        iVar23 = *(int64_t *)(arg1 + 0x98);
        uVar26 = *(undefined4 *)(arg1 + 0x84);
        uVar27 = *(undefined4 *)(arg1 + 0x88);
        uVar28 = *(undefined4 *)(arg1 + 0x8c);
        uVar29 = *(undefined4 *)(arg1 + 0x90);
        func_0x0001800f0350(arg1);
    } else {
        func_0x0001800efe90(arg1, 0x180642e48);
        iVar23 = *(int64_t *)(arg1 + 0x128);
        uVar26 = *(undefined4 *)(arg1 + 0x84);
        uVar27 = *(undefined4 *)(arg1 + 0x88);
        uVar28 = *(undefined4 *)(arg1 + 0x8c);
        uVar29 = *(undefined4 *)(arg1 + 0x90);
    }
    uStack_c0 = 1;
    piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x1e8) + 0x4a0);
    *piVar1 = *piVar1 + 1;
    uVar25 = *(undefined8 *)(arg1 + 0x160);
    *(int64_t *)(arg1 + 0x160) = *(int64_t *)(arg1 + 0x150) - *(int64_t *)(arg1 + 0x148) >> 3;
    auStack_d0._4_4_ = uVar27;
    auStack_d0._0_4_ = uVar26;
    auStack_d0._8_4_ = uVar28;
    auStack_d0._12_4_ = uVar29;
    var_e8h = 0;
    var_e0h = 0;
    iStack_d8 = iVar23;
    piVar15 = (int64_t *)func_0x0001800e3690(arg1, &uStack_b0, 0, &uStack_90, &iStack_d8, 0, &var_e8h, 0);
    iStack_d8 = *piVar15;
    *(undefined8 *)(arg1 + 0x160) = uVar25;
    piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x1e8) + 0x4a0);
    *piVar1 = *piVar1 + -1;
    uVar16 = (*(int64_t *)(arg1 + 0x1d8) - *(int64_t *)(arg1 + 0x1d0) >> 3) * -0x71c71c71c71c71c7;
    ppiVar19 = *(int64_t ***)(arg1 + 0xd8);
    uStackX_8 = (int64_t *)
                CONCAT71(uStackX_8._1_7_, 
                         (uint64_t)(iVar24 * -0x71c71c71c71c71c7) <= uVar16 && uVar16 + iVar24 * 0x71c71c71c71c71c7 != 0
                        );
    var_e8h = *piStackX_10;
    iVar24 = (int64_t)*ppiVar19;
    var_e0h = *(int64_t *)(iStack_d8 + 0x14);
    if (iVar24 == 0) {
code_r0x0001800e0290:
        piVar17 = (int64_t *)func_0x000180459890(0x2008);
        *piVar17 = (int64_t)*ppiVar19;
        piVar15 = piVar17 + 1;
        *ppiVar19 = piVar17;
        piVar17 = (int64_t *)0x50;
    } else {
        piVar15 = (int64_t *)((int64_t)ppiVar19[1] + iVar24 + 0xf & 0xfffffffffffffff8);
        if ((int64_t *)(iVar24 + 0x2008) < piVar15 + 10) goto code_r0x0001800e0290;
        piVar17 = (int64_t *)((int64_t)piVar15 + (0x50 - (iVar24 + 8)));
    }
    ppiVar19[1] = piVar17;
    *(undefined4 *)(piVar15 + 1) = *(undefined4 *)0x180782760;
    *piVar15 = 0x180642018;
    piVar15[8] = iStack_d8;
    *(undefined *)((int64_t)piVar15 + 0x49) = (undefined)uStackX_8;
    *(undefined4 *)((int64_t)piVar15 + 0xc) = (undefined4)var_e8h;
    *(undefined4 *)(piVar15 + 2) = var_e8h._4_4_;
    *(undefined4 *)((int64_t)piVar15 + 0x14) = (undefined4)var_e0h;
    *(undefined4 *)(piVar15 + 3) = var_e0h._4_4_;
    *(undefined *)(piVar15 + 4) = 0;
    piVar15[5] = iVar23;
    auVar4._4_4_ = uVar27;
    auVar4._0_4_ = uVar26;
    auVar4._8_4_ = uVar28;
    auVar4._12_4_ = uVar29;
    *(undefined (*) [16])(piVar15 + 6) = auVar4;
    *(undefined *)(piVar15 + 9) = (undefined)placeholder_2;
    if (*(char *)(arg1 + 0x58) == '\0') {
        return piVar15;
    }
    ppiVar19 = *(int64_t ***)(arg1 + 0xd8);
    iVar24 = (int64_t)*ppiVar19;
    if (iVar24 != 0) {
        piVar17 = (int64_t *)((int64_t)ppiVar19[1] + iVar24 + 0xf & 0xfffffffffffffff8);
        if ((int64_t)piVar17 + 0x14U <= iVar24 + 0x2008U) {
            piVar18 = (int64_t *)((int64_t)piVar17 + (0x14 - (iVar24 + 8)));
            goto code_r0x0001800e0356;
        }
    }
    piVar18 = (int64_t *)func_0x000180459890(0x2008);
    *piVar18 = (int64_t)*ppiVar19;
    piVar17 = piVar18 + 1;
    *ppiVar19 = piVar18;
    piVar18 = (int64_t *)0x14;
code_r0x0001800e0356:
    ppiVar19[1] = piVar18;
    *(undefined4 *)piVar17 = *(undefined4 *)0x180782a60;
    *(uint64_t *)((int64_t)piVar17 + 0xc) = CONCAT44(uStack_88, uStack_90._4_4_);
    *(int64_t *)((int64_t)piVar17 + 4) = arg4;
    uStackX_8 = piVar15;
    ppiVar19 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &uStackX_8);
    *ppiVar19 = piVar17;
    return piVar15;
}

// ============================================================
// Function: FUN_1800e038e
// Address: 0x1800e038e
// Size: 522 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: Variable defined which should be unmapped: var_100h
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_f0h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_21h
// WARNING: Variable defined which should be unmapped: var_31h
// WARNING: Type propagation algorithm not settling
// WARNING: [rz-ghidra] Removing arg arg_67h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_59h
// WARNING: [rz-ghidra] Detected overlap for variable var_51h
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_61h
// WARNING: [rz-ghidra] Removing arg arg_6fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_2dh

int64_t * fcn.1800e00c0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4)
{
    int32_t *piVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined auVar4 [16];
    undefined auVar5 [16];
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    char cVar14;
    int64_t *piVar15;
    uint64_t uVar16;
    int64_t *piVar17;
    int64_t *piVar18;
    int64_t **ppiVar19;
    undefined4 *puVar20;
    undefined8 *puVar21;
    undefined8 *puVar22;
    int64_t iVar23;
    int64_t iVar24;
    undefined8 uVar25;
    undefined4 uVar26;
    undefined4 uVar27;
    undefined4 uVar28;
    undefined4 uVar29;
    undefined8 uStackX_8;
    int64_t *piStackX_10;
    undefined uStackX_18;
    int64_t var_20h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t iStack_d8;
    undefined auStack_d0 [16];
    undefined uStack_c0;
    int64_t iStack_b8;
    undefined8 uStack_b0;
    undefined8 uStack_a8;
    undefined8 uStack_90;
    undefined4 uStack_88;
    undefined4 uStack_84;
    undefined4 uStack_80;
    undefined auStack_7c [3];
    int64_t var_79h;
    int64_t var_71h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_49h;
    int64_t var_31h;
    int64_t var_21h;
    
    piStackX_10 = (int64_t *)arg2;
    uStackX_18 = (undefined)placeholder_2;
    if (*(int32_t *)(arg1 + 0x80) != 299) {
        if (*(int32_t *)(arg1 + 0x80) == 0x119) {
            iVar24 = *(int64_t *)(arg1 + 0x98);
            uVar26 = *(undefined4 *)(arg1 + 0x84);
            uVar27 = *(undefined4 *)(arg1 + 0x88);
            uVar28 = *(undefined4 *)(arg1 + 0x8c);
            uVar29 = *(undefined4 *)(arg1 + 0x90);
            func_0x0001800f0350();
        } else {
            func_0x0001800efe90(arg1, 0x180642dc8);
            uVar26 = *(undefined4 *)(arg1 + 0x84);
            uVar27 = *(undefined4 *)(arg1 + 0x88);
            uVar28 = *(undefined4 *)(arg1 + 0x8c);
            uVar29 = *(undefined4 *)(arg1 + 0x90);
            iVar24 = *(int64_t *)(arg1 + 0x128);
        }
        uVar25 = 0;
        uStackX_8 = (int64_t *)0xffffffffffffffff;
        var_e8h = 0;
        var_e0h = 0;
        iStack_b8 = -1;
        if (*(char *)(arg1 + 0x58) == '\0') {
            var_100h = 0;
            puVar22 = &uStack_b0;
            var_108h = 0;
            puVar21 = (undefined8 *)0x0;
        } else {
            var_100h = (int64_t)&iStack_b8;
            puVar21 = &uStackX_8;
            var_108h = (int64_t)&var_e8h;
            puVar22 = &uStack_90;
        }
        puVar20 = (undefined4 *)func_0x0001800ecbd0(arg1, puVar22, 1, puVar21, var_108h, var_100h);
        uVar6 = *puVar20;
        uVar7 = puVar20[1];
        uVar8 = puVar20[2];
        uVar9 = puVar20[3];
        uVar10 = puVar20[4];
        uVar11 = puVar20[5];
        uVar12 = puVar20[6];
        uVar13 = puVar20[7];
        if (*(int32_t *)(arg1 + 0x80) == 0x3d) {
            func_0x0001800f0350(arg1);
code_r0x0001800e046f:
            iVar23 = *(int64_t *)(arg1 + 0xa0);
        } else {
            cVar14 = func_0x0001800ef2a0(arg1, 0x3d, 0x180642dd8);
            if (cVar14 != '\0') goto code_r0x0001800e046f;
            iStack_d8 = -1;
            iVar23 = -1;
        }
        uStack_b0 = *(undefined8 *)(arg1 + 0x84);
        uStack_a8 = *(undefined8 *)(arg1 + 0x8c);
        uVar2 = *(undefined4 *)(arg1 + 0x114);
        if ((*(int32_t *)(arg1 + 0x80) != 0x7c) && (*(int32_t *)(arg1 + 0x80) != 0x26)) {
            puVar21 = (undefined8 *)func_0x0001800e81c0(arg1, &iStack_d8, 0, 0);
            uVar25 = *puVar21;
            *(undefined4 *)(arg1 + 0x114) = uVar2;
        }
        iStack_d8 = func_0x0001800e7930(arg1, uVar25, &uStack_b0);
        ppiVar19 = *(int64_t ***)(arg1 + 0xd8);
        *(undefined4 *)(arg1 + 0x114) = uVar2;
        uStack_b0 = *(undefined8 *)arg2;
        iVar3 = (int64_t)*ppiVar19;
        uStack_a8 = *(undefined8 *)(iStack_d8 + 0x14);
        if (iVar3 == 0) {
code_r0x0001800e051d:
            piVar17 = (int64_t *)func_0x000180459890(0x2008);
            *piVar17 = (int64_t)*ppiVar19;
            piVar15 = piVar17 + 1;
            *ppiVar19 = piVar17;
            piVar17 = (int64_t *)0x70;
        } else {
            piVar15 = (int64_t *)((int64_t)ppiVar19[1] + iVar3 + 0xf & 0xfffffffffffffff8);
            if ((int64_t *)(iVar3 + 0x2008) < piVar15 + 0xe) goto code_r0x0001800e051d;
            piVar17 = (int64_t *)((int64_t)piVar15 + (0x70 - (iVar3 + 8)));
        }
        ppiVar19[1] = piVar17;
        *(undefined4 *)(piVar15 + 1) = *(undefined4 *)0x18078266c;
        *piVar15 = 0x180641f50;
        piVar15[0xc] = iStack_d8;
        *(undefined4 *)(piVar15 + 8) = uVar6;
        *(undefined4 *)((int64_t)piVar15 + 0x44) = uVar7;
        *(undefined4 *)(piVar15 + 9) = uVar8;
        *(undefined4 *)((int64_t)piVar15 + 0x4c) = uVar9;
        *(undefined *)(piVar15 + 0xd) = uStackX_18;
        *(undefined4 *)(piVar15 + 10) = uVar10;
        *(undefined4 *)((int64_t)piVar15 + 0x54) = uVar11;
        *(undefined4 *)(piVar15 + 0xb) = uVar12;
        *(undefined4 *)((int64_t)piVar15 + 0x5c) = uVar13;
        *(undefined *)(piVar15 + 4) = 0;
        *(undefined4 *)((int64_t)piVar15 + 0xc) = (undefined4)uStack_b0;
        *(undefined4 *)(piVar15 + 2) = uStack_b0._4_4_;
        *(undefined4 *)((int64_t)piVar15 + 0x14) = (undefined4)uStack_a8;
        *(undefined4 *)(piVar15 + 3) = uStack_a8._4_4_;
        piVar15[5] = iVar24;
        auVar5._4_4_ = uVar27;
        auVar5._0_4_ = uVar26;
        auVar5._8_4_ = uVar28;
        auVar5._12_4_ = uVar29;
        *(undefined (*) [16])(piVar15 + 6) = auVar5;
        if (*(char *)(arg1 + 0x58) == '\0') {
            return piVar15;
        }
        ppiVar19 = *(int64_t ***)(arg1 + 0xd8);
        iVar24 = (int64_t)*ppiVar19;
        if (iVar24 != 0) {
            piVar17 = (int64_t *)((int64_t)ppiVar19[1] + iVar24 + 0xf & 0xfffffffffffffff8);
            if (piVar17 + 7 <= (int64_t *)(iVar24 + 0x2008U)) {
                piVar18 = (int64_t *)((int64_t)piVar17 + (0x38 - (iVar24 + 8)));
                goto code_r0x0001800e05f6;
            }
        }
        piVar18 = (int64_t *)func_0x000180459890(0x2008);
        *piVar18 = (int64_t)*ppiVar19;
        piVar17 = piVar18 + 1;
        *ppiVar19 = piVar18;
        piVar18 = (int64_t *)0x38;
code_r0x0001800e05f6:
        ppiVar19[1] = piVar18;
        *(undefined4 *)piVar17 = *(undefined4 *)0x180782a7c;
        piVar17[5] = iStack_b8;
        *(int64_t **)((int64_t)piVar17 + 0xc) = uStackX_8;
        *(undefined4 *)(piVar17 + 3) = (undefined4)var_e8h;
        *(undefined4 *)((int64_t)piVar17 + 0x1c) = var_e8h._4_4_;
        *(undefined4 *)(piVar17 + 4) = (undefined4)var_e0h;
        *(undefined4 *)((int64_t)piVar17 + 0x24) = var_e0h._4_4_;
        *(int64_t *)((int64_t)piVar17 + 4) = arg4;
        piVar17[6] = iVar23;
        uStackX_8 = piVar15;
        ppiVar19 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &uStackX_8);
        *ppiVar19 = piVar17;
        return piVar15;
    }
    uStack_90._0_4_ = *(undefined4 *)(arg1 + 0x80);
    uStack_90._4_4_ = *(undefined4 *)(arg1 + 0x84);
    uStack_88 = *(undefined4 *)(arg1 + 0x88);
    uStack_84 = *(undefined4 *)(arg1 + 0x8c);
    uStack_80 = *(undefined4 *)(arg1 + 0x90);
    _auStack_7c = *(undefined4 *)(arg1 + 0x94);
    var_79h._1_4_ = *(undefined4 *)(arg1 + 0x98);
    unique0x10000486 = *(undefined4 *)(arg1 + 0x9c);
    func_0x0001800f0350();
    iVar24 = *(int64_t *)(arg1 + 0x1d8) - *(int64_t *)(arg1 + 0x1d0) >> 3;
    if (*(int32_t *)(arg1 + 0x80) == 0x119) {
        iVar23 = *(int64_t *)(arg1 + 0x98);
        uVar26 = *(undefined4 *)(arg1 + 0x84);
        uVar27 = *(undefined4 *)(arg1 + 0x88);
        uVar28 = *(undefined4 *)(arg1 + 0x8c);
        uVar29 = *(undefined4 *)(arg1 + 0x90);
        func_0x0001800f0350(arg1);
    } else {
        func_0x0001800efe90(arg1, 0x180642e48);
        iVar23 = *(int64_t *)(arg1 + 0x128);
        uVar26 = *(undefined4 *)(arg1 + 0x84);
        uVar27 = *(undefined4 *)(arg1 + 0x88);
        uVar28 = *(undefined4 *)(arg1 + 0x8c);
        uVar29 = *(undefined4 *)(arg1 + 0x90);
    }
    uStack_c0 = 1;
    piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x1e8) + 0x4a0);
    *piVar1 = *piVar1 + 1;
    uVar25 = *(undefined8 *)(arg1 + 0x160);
    *(int64_t *)(arg1 + 0x160) = *(int64_t *)(arg1 + 0x150) - *(int64_t *)(arg1 + 0x148) >> 3;
    auStack_d0._4_4_ = uVar27;
    auStack_d0._0_4_ = uVar26;
    auStack_d0._8_4_ = uVar28;
    auStack_d0._12_4_ = uVar29;
    var_e8h = 0;
    var_e0h = 0;
    iStack_d8 = iVar23;
    piVar15 = (int64_t *)func_0x0001800e3690(arg1, &uStack_b0, 0, &uStack_90, &iStack_d8, 0, &var_e8h, 0);
    iStack_d8 = *piVar15;
    *(undefined8 *)(arg1 + 0x160) = uVar25;
    piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x1e8) + 0x4a0);
    *piVar1 = *piVar1 + -1;
    uVar16 = (*(int64_t *)(arg1 + 0x1d8) - *(int64_t *)(arg1 + 0x1d0) >> 3) * -0x71c71c71c71c71c7;
    ppiVar19 = *(int64_t ***)(arg1 + 0xd8);
    uStackX_8 = (int64_t *)
                CONCAT71(uStackX_8._1_7_, 
                         (uint64_t)(iVar24 * -0x71c71c71c71c71c7) <= uVar16 && uVar16 + iVar24 * 0x71c71c71c71c71c7 != 0
                        );
    var_e8h = *piStackX_10;
    iVar24 = (int64_t)*ppiVar19;
    var_e0h = *(int64_t *)(iStack_d8 + 0x14);
    if (iVar24 == 0) {
code_r0x0001800e0290:
        piVar17 = (int64_t *)func_0x000180459890(0x2008);
        *piVar17 = (int64_t)*ppiVar19;
        piVar15 = piVar17 + 1;
        *ppiVar19 = piVar17;
        piVar17 = (int64_t *)0x50;
    } else {
        piVar15 = (int64_t *)((int64_t)ppiVar19[1] + iVar24 + 0xf & 0xfffffffffffffff8);
        if ((int64_t *)(iVar24 + 0x2008) < piVar15 + 10) goto code_r0x0001800e0290;
        piVar17 = (int64_t *)((int64_t)piVar15 + (0x50 - (iVar24 + 8)));
    }
    ppiVar19[1] = piVar17;
    *(undefined4 *)(piVar15 + 1) = *(undefined4 *)0x180782760;
    *piVar15 = 0x180642018;
    piVar15[8] = iStack_d8;
    *(undefined *)((int64_t)piVar15 + 0x49) = (undefined)uStackX_8;
    *(undefined4 *)((int64_t)piVar15 + 0xc) = (undefined4)var_e8h;
    *(undefined4 *)(piVar15 + 2) = var_e8h._4_4_;
    *(undefined4 *)((int64_t)piVar15 + 0x14) = (undefined4)var_e0h;
    *(undefined4 *)(piVar15 + 3) = var_e0h._4_4_;
    *(undefined *)(piVar15 + 4) = 0;
    piVar15[5] = iVar23;
    auVar4._4_4_ = uVar27;
    auVar4._0_4_ = uVar26;
    auVar4._8_4_ = uVar28;
    auVar4._12_4_ = uVar29;
    *(undefined (*) [16])(piVar15 + 6) = auVar4;
    *(undefined *)(piVar15 + 9) = (undefined)placeholder_2;
    if (*(char *)(arg1 + 0x58) == '\0') {
        return piVar15;
    }
    ppiVar19 = *(int64_t ***)(arg1 + 0xd8);
    iVar24 = (int64_t)*ppiVar19;
    if (iVar24 != 0) {
        piVar17 = (int64_t *)((int64_t)ppiVar19[1] + iVar24 + 0xf & 0xfffffffffffffff8);
        if ((int64_t)piVar17 + 0x14U <= iVar24 + 0x2008U) {
            piVar18 = (int64_t *)((int64_t)piVar17 + (0x14 - (iVar24 + 8)));
            goto code_r0x0001800e0356;
        }
    }
    piVar18 = (int64_t *)func_0x000180459890(0x2008);
    *piVar18 = (int64_t)*ppiVar19;
    piVar17 = piVar18 + 1;
    *ppiVar19 = piVar18;
    piVar18 = (int64_t *)0x14;
code_r0x0001800e0356:
    ppiVar19[1] = piVar18;
    *(undefined4 *)piVar17 = *(undefined4 *)0x180782a60;
    *(uint64_t *)((int64_t)piVar17 + 0xc) = CONCAT44(uStack_88, uStack_90._4_4_);
    *(int64_t *)((int64_t)piVar17 + 4) = arg4;
    uStackX_8 = piVar15;
    ppiVar19 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &uStackX_8);
    *ppiVar19 = piVar17;
    return piVar15;
}

// ============================================================
// Function: FUN_1800e0598
// Address: 0x1800e0598
// Size: 201 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: Variable defined which should be unmapped: var_100h
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_f0h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_21h
// WARNING: Variable defined which should be unmapped: var_31h
// WARNING: Type propagation algorithm not settling
// WARNING: [rz-ghidra] Removing arg arg_67h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_59h
// WARNING: [rz-ghidra] Detected overlap for variable var_51h
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_61h
// WARNING: [rz-ghidra] Removing arg arg_6fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_2dh

int64_t * fcn.1800e00c0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4)
{
    int32_t *piVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined auVar4 [16];
    undefined auVar5 [16];
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    char cVar14;
    int64_t *piVar15;
    uint64_t uVar16;
    int64_t *piVar17;
    int64_t *piVar18;
    int64_t **ppiVar19;
    undefined4 *puVar20;
    undefined8 *puVar21;
    undefined8 *puVar22;
    int64_t iVar23;
    int64_t iVar24;
    undefined8 uVar25;
    undefined4 uVar26;
    undefined4 uVar27;
    undefined4 uVar28;
    undefined4 uVar29;
    undefined8 uStackX_8;
    int64_t *piStackX_10;
    undefined uStackX_18;
    int64_t var_20h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t iStack_d8;
    undefined auStack_d0 [16];
    undefined uStack_c0;
    int64_t iStack_b8;
    undefined8 uStack_b0;
    undefined8 uStack_a8;
    undefined8 uStack_90;
    undefined4 uStack_88;
    undefined4 uStack_84;
    undefined4 uStack_80;
    undefined auStack_7c [3];
    int64_t var_79h;
    int64_t var_71h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_49h;
    int64_t var_31h;
    int64_t var_21h;
    
    piStackX_10 = (int64_t *)arg2;
    uStackX_18 = (undefined)placeholder_2;
    if (*(int32_t *)(arg1 + 0x80) != 299) {
        if (*(int32_t *)(arg1 + 0x80) == 0x119) {
            iVar24 = *(int64_t *)(arg1 + 0x98);
            uVar26 = *(undefined4 *)(arg1 + 0x84);
            uVar27 = *(undefined4 *)(arg1 + 0x88);
            uVar28 = *(undefined4 *)(arg1 + 0x8c);
            uVar29 = *(undefined4 *)(arg1 + 0x90);
            func_0x0001800f0350();
        } else {
            func_0x0001800efe90(arg1, 0x180642dc8);
            uVar26 = *(undefined4 *)(arg1 + 0x84);
            uVar27 = *(undefined4 *)(arg1 + 0x88);
            uVar28 = *(undefined4 *)(arg1 + 0x8c);
            uVar29 = *(undefined4 *)(arg1 + 0x90);
            iVar24 = *(int64_t *)(arg1 + 0x128);
        }
        uVar25 = 0;
        uStackX_8 = (int64_t *)0xffffffffffffffff;
        var_e8h = 0;
        var_e0h = 0;
        iStack_b8 = -1;
        if (*(char *)(arg1 + 0x58) == '\0') {
            var_100h = 0;
            puVar22 = &uStack_b0;
            var_108h = 0;
            puVar21 = (undefined8 *)0x0;
        } else {
            var_100h = (int64_t)&iStack_b8;
            puVar21 = &uStackX_8;
            var_108h = (int64_t)&var_e8h;
            puVar22 = &uStack_90;
        }
        puVar20 = (undefined4 *)func_0x0001800ecbd0(arg1, puVar22, 1, puVar21, var_108h, var_100h);
        uVar6 = *puVar20;
        uVar7 = puVar20[1];
        uVar8 = puVar20[2];
        uVar9 = puVar20[3];
        uVar10 = puVar20[4];
        uVar11 = puVar20[5];
        uVar12 = puVar20[6];
        uVar13 = puVar20[7];
        if (*(int32_t *)(arg1 + 0x80) == 0x3d) {
            func_0x0001800f0350(arg1);
code_r0x0001800e046f:
            iVar23 = *(int64_t *)(arg1 + 0xa0);
        } else {
            cVar14 = func_0x0001800ef2a0(arg1, 0x3d, 0x180642dd8);
            if (cVar14 != '\0') goto code_r0x0001800e046f;
            iStack_d8 = -1;
            iVar23 = -1;
        }
        uStack_b0 = *(undefined8 *)(arg1 + 0x84);
        uStack_a8 = *(undefined8 *)(arg1 + 0x8c);
        uVar2 = *(undefined4 *)(arg1 + 0x114);
        if ((*(int32_t *)(arg1 + 0x80) != 0x7c) && (*(int32_t *)(arg1 + 0x80) != 0x26)) {
            puVar21 = (undefined8 *)func_0x0001800e81c0(arg1, &iStack_d8, 0, 0);
            uVar25 = *puVar21;
            *(undefined4 *)(arg1 + 0x114) = uVar2;
        }
        iStack_d8 = func_0x0001800e7930(arg1, uVar25, &uStack_b0);
        ppiVar19 = *(int64_t ***)(arg1 + 0xd8);
        *(undefined4 *)(arg1 + 0x114) = uVar2;
        uStack_b0 = *(undefined8 *)arg2;
        iVar3 = (int64_t)*ppiVar19;
        uStack_a8 = *(undefined8 *)(iStack_d8 + 0x14);
        if (iVar3 == 0) {
code_r0x0001800e051d:
            piVar17 = (int64_t *)func_0x000180459890(0x2008);
            *piVar17 = (int64_t)*ppiVar19;
            piVar15 = piVar17 + 1;
            *ppiVar19 = piVar17;
            piVar17 = (int64_t *)0x70;
        } else {
            piVar15 = (int64_t *)((int64_t)ppiVar19[1] + iVar3 + 0xf & 0xfffffffffffffff8);
            if ((int64_t *)(iVar3 + 0x2008) < piVar15 + 0xe) goto code_r0x0001800e051d;
            piVar17 = (int64_t *)((int64_t)piVar15 + (0x70 - (iVar3 + 8)));
        }
        ppiVar19[1] = piVar17;
        *(undefined4 *)(piVar15 + 1) = *(undefined4 *)0x18078266c;
        *piVar15 = 0x180641f50;
        piVar15[0xc] = iStack_d8;
        *(undefined4 *)(piVar15 + 8) = uVar6;
        *(undefined4 *)((int64_t)piVar15 + 0x44) = uVar7;
        *(undefined4 *)(piVar15 + 9) = uVar8;
        *(undefined4 *)((int64_t)piVar15 + 0x4c) = uVar9;
        *(undefined *)(piVar15 + 0xd) = uStackX_18;
        *(undefined4 *)(piVar15 + 10) = uVar10;
        *(undefined4 *)((int64_t)piVar15 + 0x54) = uVar11;
        *(undefined4 *)(piVar15 + 0xb) = uVar12;
        *(undefined4 *)((int64_t)piVar15 + 0x5c) = uVar13;
        *(undefined *)(piVar15 + 4) = 0;
        *(undefined4 *)((int64_t)piVar15 + 0xc) = (undefined4)uStack_b0;
        *(undefined4 *)(piVar15 + 2) = uStack_b0._4_4_;
        *(undefined4 *)((int64_t)piVar15 + 0x14) = (undefined4)uStack_a8;
        *(undefined4 *)(piVar15 + 3) = uStack_a8._4_4_;
        piVar15[5] = iVar24;
        auVar5._4_4_ = uVar27;
        auVar5._0_4_ = uVar26;
        auVar5._8_4_ = uVar28;
        auVar5._12_4_ = uVar29;
        *(undefined (*) [16])(piVar15 + 6) = auVar5;
        if (*(char *)(arg1 + 0x58) == '\0') {
            return piVar15;
        }
        ppiVar19 = *(int64_t ***)(arg1 + 0xd8);
        iVar24 = (int64_t)*ppiVar19;
        if (iVar24 != 0) {
            piVar17 = (int64_t *)((int64_t)ppiVar19[1] + iVar24 + 0xf & 0xfffffffffffffff8);
            if (piVar17 + 7 <= (int64_t *)(iVar24 + 0x2008U)) {
                piVar18 = (int64_t *)((int64_t)piVar17 + (0x38 - (iVar24 + 8)));
                goto code_r0x0001800e05f6;
            }
        }
        piVar18 = (int64_t *)func_0x000180459890(0x2008);
        *piVar18 = (int64_t)*ppiVar19;
        piVar17 = piVar18 + 1;
        *ppiVar19 = piVar18;
        piVar18 = (int64_t *)0x38;
code_r0x0001800e05f6:
        ppiVar19[1] = piVar18;
        *(undefined4 *)piVar17 = *(undefined4 *)0x180782a7c;
        piVar17[5] = iStack_b8;
        *(int64_t **)((int64_t)piVar17 + 0xc) = uStackX_8;
        *(undefined4 *)(piVar17 + 3) = (undefined4)var_e8h;
        *(undefined4 *)((int64_t)piVar17 + 0x1c) = var_e8h._4_4_;
        *(undefined4 *)(piVar17 + 4) = (undefined4)var_e0h;
        *(undefined4 *)((int64_t)piVar17 + 0x24) = var_e0h._4_4_;
        *(int64_t *)((int64_t)piVar17 + 4) = arg4;
        piVar17[6] = iVar23;
        uStackX_8 = piVar15;
        ppiVar19 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &uStackX_8);
        *ppiVar19 = piVar17;
        return piVar15;
    }
    uStack_90._0_4_ = *(undefined4 *)(arg1 + 0x80);
    uStack_90._4_4_ = *(undefined4 *)(arg1 + 0x84);
    uStack_88 = *(undefined4 *)(arg1 + 0x88);
    uStack_84 = *(undefined4 *)(arg1 + 0x8c);
    uStack_80 = *(undefined4 *)(arg1 + 0x90);
    _auStack_7c = *(undefined4 *)(arg1 + 0x94);
    var_79h._1_4_ = *(undefined4 *)(arg1 + 0x98);
    unique0x10000486 = *(undefined4 *)(arg1 + 0x9c);
    func_0x0001800f0350();
    iVar24 = *(int64_t *)(arg1 + 0x1d8) - *(int64_t *)(arg1 + 0x1d0) >> 3;
    if (*(int32_t *)(arg1 + 0x80) == 0x119) {
        iVar23 = *(int64_t *)(arg1 + 0x98);
        uVar26 = *(undefined4 *)(arg1 + 0x84);
        uVar27 = *(undefined4 *)(arg1 + 0x88);
        uVar28 = *(undefined4 *)(arg1 + 0x8c);
        uVar29 = *(undefined4 *)(arg1 + 0x90);
        func_0x0001800f0350(arg1);
    } else {
        func_0x0001800efe90(arg1, 0x180642e48);
        iVar23 = *(int64_t *)(arg1 + 0x128);
        uVar26 = *(undefined4 *)(arg1 + 0x84);
        uVar27 = *(undefined4 *)(arg1 + 0x88);
        uVar28 = *(undefined4 *)(arg1 + 0x8c);
        uVar29 = *(undefined4 *)(arg1 + 0x90);
    }
    uStack_c0 = 1;
    piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x1e8) + 0x4a0);
    *piVar1 = *piVar1 + 1;
    uVar25 = *(undefined8 *)(arg1 + 0x160);
    *(int64_t *)(arg1 + 0x160) = *(int64_t *)(arg1 + 0x150) - *(int64_t *)(arg1 + 0x148) >> 3;
    auStack_d0._4_4_ = uVar27;
    auStack_d0._0_4_ = uVar26;
    auStack_d0._8_4_ = uVar28;
    auStack_d0._12_4_ = uVar29;
    var_e8h = 0;
    var_e0h = 0;
    iStack_d8 = iVar23;
    piVar15 = (int64_t *)func_0x0001800e3690(arg1, &uStack_b0, 0, &uStack_90, &iStack_d8, 0, &var_e8h, 0);
    iStack_d8 = *piVar15;
    *(undefined8 *)(arg1 + 0x160) = uVar25;
    piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x1e8) + 0x4a0);
    *piVar1 = *piVar1 + -1;
    uVar16 = (*(int64_t *)(arg1 + 0x1d8) - *(int64_t *)(arg1 + 0x1d0) >> 3) * -0x71c71c71c71c71c7;
    ppiVar19 = *(int64_t ***)(arg1 + 0xd8);
    uStackX_8 = (int64_t *)
                CONCAT71(uStackX_8._1_7_, 
                         (uint64_t)(iVar24 * -0x71c71c71c71c71c7) <= uVar16 && uVar16 + iVar24 * 0x71c71c71c71c71c7 != 0
                        );
    var_e8h = *piStackX_10;
    iVar24 = (int64_t)*ppiVar19;
    var_e0h = *(int64_t *)(iStack_d8 + 0x14);
    if (iVar24 == 0) {
code_r0x0001800e0290:
        piVar17 = (int64_t *)func_0x000180459890(0x2008);
        *piVar17 = (int64_t)*ppiVar19;
        piVar15 = piVar17 + 1;
        *ppiVar19 = piVar17;
        piVar17 = (int64_t *)0x50;
    } else {
        piVar15 = (int64_t *)((int64_t)ppiVar19[1] + iVar24 + 0xf & 0xfffffffffffffff8);
        if ((int64_t *)(iVar24 + 0x2008) < piVar15 + 10) goto code_r0x0001800e0290;
        piVar17 = (int64_t *)((int64_t)piVar15 + (0x50 - (iVar24 + 8)));
    }
    ppiVar19[1] = piVar17;
    *(undefined4 *)(piVar15 + 1) = *(undefined4 *)0x180782760;
    *piVar15 = 0x180642018;
    piVar15[8] = iStack_d8;
    *(undefined *)((int64_t)piVar15 + 0x49) = (undefined)uStackX_8;
    *(undefined4 *)((int64_t)piVar15 + 0xc) = (undefined4)var_e8h;
    *(undefined4 *)(piVar15 + 2) = var_e8h._4_4_;
    *(undefined4 *)((int64_t)piVar15 + 0x14) = (undefined4)var_e0h;
    *(undefined4 *)(piVar15 + 3) = var_e0h._4_4_;
    *(undefined *)(piVar15 + 4) = 0;
    piVar15[5] = iVar23;
    auVar4._4_4_ = uVar27;
    auVar4._0_4_ = uVar26;
    auVar4._8_4_ = uVar28;
    auVar4._12_4_ = uVar29;
    *(undefined (*) [16])(piVar15 + 6) = auVar4;
    *(undefined *)(piVar15 + 9) = (undefined)placeholder_2;
    if (*(char *)(arg1 + 0x58) == '\0') {
        return piVar15;
    }
    ppiVar19 = *(int64_t ***)(arg1 + 0xd8);
    iVar24 = (int64_t)*ppiVar19;
    if (iVar24 != 0) {
        piVar17 = (int64_t *)((int64_t)ppiVar19[1] + iVar24 + 0xf & 0xfffffffffffffff8);
        if ((int64_t)piVar17 + 0x14U <= iVar24 + 0x2008U) {
            piVar18 = (int64_t *)((int64_t)piVar17 + (0x14 - (iVar24 + 8)));
            goto code_r0x0001800e0356;
        }
    }
    piVar18 = (int64_t *)func_0x000180459890(0x2008);
    *piVar18 = (int64_t)*ppiVar19;
    piVar17 = piVar18 + 1;
    *ppiVar19 = piVar18;
    piVar18 = (int64_t *)0x14;
code_r0x0001800e0356:
    ppiVar19[1] = piVar18;
    *(undefined4 *)piVar17 = *(undefined4 *)0x180782a60;
    *(uint64_t *)((int64_t)piVar17 + 0xc) = CONCAT44(uStack_88, uStack_90._4_4_);
    *(int64_t *)((int64_t)piVar17 + 4) = arg4;
    uStackX_8 = piVar15;
    ppiVar19 = (int64_t **)func_0x0001800cc970(arg1 + 0x490, &uStackX_8);
    *ppiVar19 = piVar17;
    return piVar15;
}

// ============================================================
// Function: FUN_1800e0670
// Address: 0x1800e0670
// Size: 3412 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_ch
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_250h
// WARNING: [rz-ghidra] Detected overlap for variable var_258h
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable arg_61h
// WARNING: [rz-ghidra] Detected overlap for variable var_23h
// WARNING: [rz-ghidra] Detected overlap for variable arg_63h
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Detected overlap for variable arg_89h
// WARNING: [rz-ghidra] Detected overlap for variable arg_8bh

void fcn.1800e0670(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h, int64_t arg_38h, undefined8 placeholder_7, int64_t arg_48h, undefined8 placeholder_9,
                  undefined8 placeholder_10, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h,
                  int64_t arg_80h, int64_t arg_88h, undefined8 placeholder_17, int64_t arg_98h,
                  undefined8 placeholder_19, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h,
                  undefined8 placeholder_23, int64_t arg_c8h, int64_t arg_d0h, int64_t arg_d8h, int64_t arg_e0h,
                  undefined8 placeholder_28, int64_t arg_f0h, undefined8 placeholder_30, int64_t arg_100h,
                  undefined8 placeholder_32, int64_t arg_110h, undefined8 placeholder_34, int64_t arg_120h,
                  int64_t arg_128h)
{
    undefined4 uVar1;
    int32_t *piVar2;
    code *pcVar3;
    undefined auVar4 [16];
    int64_t *piVar5;
    undefined *puVar6;
    int32_t iVar7;
    undefined8 *puVar8;
    undefined8 uVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    int64_t iVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    undefined *puVar17;
    uint64_t uVar18;
    uint64_t uVar19;
    int64_t *piVar20;
    int32_t *piVar21;
    undefined *puVar22;
    undefined *puVar23;
    undefined *puVar24;
    int64_t iVar25;
    int64_t iVar26;
    int64_t **ppiVar27;
    uint64_t *puVar28;
    uint64_t uVar29;
    int64_t *piVar30;
    int64_t **ppiVar31;
    undefined uVar32;
    int32_t *piVar33;
    undefined4 uVar34;
    undefined4 uVar35;
    undefined4 uVar36;
    undefined4 uVar37;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_298 [8];
    undefined auStack_290 [24];
    int64_t var_278h;
    int64_t var_270h;
    int64_t var_268h;
    int64_t var_260h;
    undefined var_258h;
    int64_t var_257h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_220h;
    uint64_t uStack_218;
    undefined8 uStack_210;
    undefined uStack_208;
    undefined8 uStack_200;
    undefined8 uStack_1f8;
    undefined8 uStack_1f0;
    int64_t iStack_1e8;
    int64_t iStack_1e0;
    int64_t *piStack_1d8;
    int64_t iStack_1d0;
    int64_t **ppiStack_1c8;
    int64_t **ppiStack_1c0;
    undefined8 uStack_1b8;
    undefined8 uStack_1b0;
    undefined4 uStack_1a8;
    undefined4 uStack_1a4;
    undefined4 uStack_1a0;
    undefined4 uStack_19c;
    undefined8 uStack_198;
    undefined4 uStack_190;
    undefined4 uStack_18c;
    undefined4 uStack_188;
    undefined4 uStack_184;
    undefined4 uStack_180;
    undefined4 uStack_17c;
    undefined2 uStack_177;
    undefined uStack_175;
    int64_t *piStack_170;
    uint64_t uStack_168;
    uint64_t uStack_160;
    uint64_t uStack_158;
    undefined8 uStack_150;
    undefined8 uStack_138;
    undefined4 uStack_130;
    undefined4 uStack_12c;
    undefined4 uStack_128;
    undefined4 uStack_124;
    undefined auStack_120 [8];
    undefined8 uStack_118;
    undefined4 uStack_110;
    undefined4 uStack_10c;
    undefined auStack_100 [16];
    uint64_t uStack_f0;
    uint64_t uStack_e8;
    undefined auStack_e0 [16];
    uint64_t uStack_d0;
    uint64_t uStack_c8;
    int32_t aiStack_c0 [2];
    undefined auStack_b8 [16];
    undefined4 uStack_a8;
    undefined4 uStack_a4;
    undefined4 uStack_a0;
    undefined4 uStack_9c;
    undefined4 uStack_98;
    undefined4 uStack_94;
    undefined4 uStack_90;
    undefined4 uStack_8c;
    undefined4 uStack_88;
    undefined4 uStack_84;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_ch;
    
    puVar23 = auStack_298;
    puVar24 = auStack_298;
    puVar22 = auStack_298;
    var_70h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_298;
    var_257h._0_1_ = (undefined)placeholder_2;
    iStack_1d0 = arg1;
    ppiStack_1c8 = (int64_t **)arg2;
    if (*(int32_t *)(arg1 + 0x80) == 0x119) {
        var_248h = *(int64_t *)(arg1 + 0x98);
        var_240h = *(int64_t *)(arg1 + 0x84);
        uVar34 = *(undefined4 *)(int64_t *)(arg1 + 0x8c);
        uVar35 = *(undefined4 *)(arg1 + 0x90);
        var_238h = *(int64_t *)(arg1 + 0x8c);
        func_0x0001800f0350();
    } else {
        func_0x0001800efe90(arg1, 0x180642dc8);
        var_248h = *(int64_t *)(arg1 + 0x128);
        var_240h = *(int64_t *)(arg1 + 0x84);
        uVar34 = *(undefined4 *)(int64_t *)(arg1 + 0x8c);
        uVar35 = *(undefined4 *)(arg1 + 0x90);
        var_238h = *(int64_t *)(arg1 + 0x8c);
    }
    uStack_150 = *(undefined8 *)(arg1 + 0x198);
    ppiStack_1c0 = *(int64_t ***)(arg1 + 400);
    var_230h = var_248h;
    var_228h = var_240h;
    var_220h = CONCAT44(uVar35, uVar34);
    iVar11 = 0;
    uStack_218 = 0;
    uStack_210 = 0;
    uStack_208 = 1;
    piStack_170 = (int64_t *)(arg1 + 0x84);
    piStack_1d8 = (int64_t *)func_0x0001800eef70(arg1, &var_230h);
    var_248h = arg1 + 0x398;
    var_240h = (*(int64_t *)(arg1 + 0x3a0) - *(int64_t *)var_248h) / 0x50;
    var_238h = 0;
    stack0xfffffffffffffdb0 = 0;
    var_230h = 0;
    var_228h = 0;
    var_220h = 0;
    uStack_218 = 0;
    iVar7 = *(int32_t *)(arg1 + 0x80);
    piVar20 = (int64_t *)(arg1 + 0x84);
    if (iVar7 == 0x128) {
code_r0x0001800e118d:
        piVar12 = piStack_1d8;
        iVar11 = var_240h;
        piVar30 = (int64_t *)var_248h;
        iStack_1e8 = *piVar20;
        iStack_1e0 = piVar20[1];
        if (iVar7 == 0x128) goto code_r0x0001800e1124;
        func_0x0001800ef2a0(arg1, 0x128, 0x18063e198);
    } else {
        do {
            uVar19 = uStack_218;
            if (iVar7 == 0) {
                iVar7 = 0;
                piVar20 = piStack_170;
                goto code_r0x0001800e118d;
            }
            var_258h = 0;
            uVar34 = uStack_188;
            uVar35 = uStack_184;
            uVar36 = uStack_180;
            uVar37 = uStack_17c;
            if ((iVar7 == 0x119) && (*(int64_t *)(arg1 + 0x98) != 0)) {
                iVar26 = 0;
                do {
                    iVar14 = iVar26 + 1;
                    if (*(char *)(*(int64_t *)(arg1 + 0x98) + iVar26) != *(char *)(iVar26 + 0x180642de4))
                    goto code_r0x0001800e0a45;
                    iVar26 = iVar14;
                } while (iVar14 != 7);
                uVar34 = *(undefined4 *)*(undefined (*) [16])(arg1 + 0x84);
                uVar35 = *(undefined4 *)(arg1 + 0x88);
                uVar36 = *(undefined4 *)(arg1 + 0x8c);
                uVar37 = *(undefined4 *)(arg1 + 0x90);
                auVar4 = *(undefined (*) [16])(arg1 + 0x84);
                func_0x0001800f0350(arg1);
                if (*(int32_t *)(arg1 + 0x80) == 299) {
                    var_258h = 1;
                    iVar7 = 299;
                    goto code_r0x0001800e0a45;
                }
                if (*(int32_t *)(arg1 + 0x80) == 0x119) {
                    uVar19 = *(uint64_t *)(arg1 + 0x98);
                    uStack_1f8 = *(uint64_t *)(arg1 + 0x84);
                    uVar10 = *(uint64_t *)(arg1 + 0x8c);
                    uStack_200 = uVar19;
                    uStack_1f0 = uVar10;
                    func_0x0001800f0350();
                    uStack_1a8 = (undefined4)uStack_200;
                    uStack_1a4 = uStack_200._4_4_;
                    uStack_1a0 = (undefined4)uStack_1f8;
                    uStack_19c = uStack_1f8._4_4_;
                    uStack_190 = CONCAT31(uStack_190._1_3_, 1);
                    iVar26 = 0;
                    uVar32 = 0;
                    uVar34 = uStack_188;
                    uVar35 = uStack_184;
                    uVar36 = uStack_180;
                    uVar37 = uStack_17c;
                    uStack_198 = uVar10;
                    if (*(int32_t *)(arg1 + 0x80) == 0x3a) {
                        uVar34 = *(undefined4 *)(arg1 + 0x84);
                        uVar35 = *(undefined4 *)(arg1 + 0x88);
                        uVar36 = *(undefined4 *)(arg1 + 0x8c);
                        uVar37 = *(undefined4 *)(arg1 + 0x90);
                        uVar32 = 1;
                        func_0x0001800f0350(arg1);
                        uVar1 = *(undefined4 *)(arg1 + 0x114);
                        uStack_168 = *(uint64_t *)(arg1 + 0x84);
                        uStack_160 = *(uint64_t *)(arg1 + 0x8c);
                        uVar9 = 0;
                        if ((*(int32_t *)(arg1 + 0x80) != 0x7c) && (*(int32_t *)(arg1 + 0x80) != 0x26)) {
                            puVar8 = (undefined8 *)func_0x0001800e81c0(arg1, &uStack_188, 0, 0);
                            uVar9 = *puVar8;
                            *(undefined4 *)(arg1 + 0x114) = uVar1;
                        }
                        iVar26 = func_0x0001800e7930(arg1, uVar9, &uStack_168);
                        *(undefined4 *)(arg1 + 0x114) = uVar1;
                    }
                    iVar7 = func_0x000180498f90(uVar19, 0x180642d40);
                    if (iVar7 == 0) {
                        func_0x0001800efe70(arg1, &uStack_1a0);
                    }
                    iVar14 = func_0x0001800c1560(&var_230h, &uStack_1a8);
                    if (iVar14 == 0) {
                        func_0x0001800ccb10(&var_230h, &uStack_1a8);
                        uStack_138 = CONCAT44(uStack_1a4, uStack_1a8);
                        uStack_130 = uStack_1a0;
                        uStack_12c = uStack_19c;
                        uStack_128 = (undefined4)uStack_198;
                        uStack_124 = uStack_198._4_4_;
                        auStack_120._4_4_ = uVar35;
                        auStack_120._0_4_ = uVar34;
                        unique0x100005a9 = uVar36;
                        unique0x100005ad = uVar37;
                        uStack_110 = CONCAT13(uStack_175, CONCAT21(uStack_177, uVar32));
                        aiStack_c0[0] = 0;
                        uStack_a8 = uStack_1a8;
                        uStack_a4 = uStack_1a4;
                        uStack_a0 = uStack_1a0;
                        uStack_9c = uStack_19c;
                        uStack_98 = (undefined4)uStack_198;
                        uStack_94 = uStack_198._4_4_;
                        var_80h._0_4_ = uStack_110;
                        var_80h._4_4_ = uStack_10c;
                        auStack_b8 = auVar4;
                        uStack_90 = uVar34;
                        uStack_8c = uVar35;
                        uStack_88 = uVar36;
                        uStack_84 = uVar37;
                        var_78h = iVar26;
                        func_0x0001800f2050(&var_248h, aiStack_c0);
                        pcVar3 = *(code **)((int64_t)aiStack_c0[0] * 8 + 0x180644200);
                        if (pcVar3 != (code *)0x1800086f0) {
                            (*pcVar3)();
                        }
                        stack0xfffffffffffffdb0 = var_230h;
                        iVar11 = var_230h;
                    } else {
                        func_0x0001800efe70(arg1, &uStack_1a0, 0x180642d70, CONCAT44(uStack_1a4, uStack_1a8));
                    }
                } else {
                    func_0x0001800efe90(arg1, 0x180642df0);
                }
            } else {
code_r0x0001800e0a45:
                if (iVar7 == 299) {
                    uStack_1a8 = *(undefined4 *)(arg1 + 0x80);
                    uStack_1a4 = *(undefined4 *)(arg1 + 0x84);
                    uStack_1a0 = *(undefined4 *)(arg1 + 0x88);
                    uStack_19c = *(undefined4 *)(arg1 + 0x8c);
                    uStack_198 = *(uint64_t *)(arg1 + 0x90);
                    uStack_190 = *(undefined4 *)(arg1 + 0x98);
                    uStack_18c = *(undefined4 *)(arg1 + 0x9c);
                    func_0x0001800f0350();
                    if (*(int32_t *)(arg1 + 0x80) == 0x119) {
                        uVar10 = *(uint64_t *)(arg1 + 0x98);
                        uStack_160 = *(uint64_t *)(arg1 + 0x84);
                        uVar18 = *(uint64_t *)(arg1 + 0x8c);
                        uStack_168 = uVar10;
                        uStack_158 = uVar18;
                        func_0x0001800f0350(arg1);
                        uVar29 = uStack_168;
                        uStack_1f0 = uVar18;
                    } else {
                        func_0x0001800efe90(arg1, 0x180642aa0);
                        uStack_168 = *(uint64_t *)(arg1 + 0x84);
                        uVar10 = *(uint64_t *)(arg1 + 0x128);
                        uVar29 = uVar10;
                        uStack_1f0 = *(uint64_t *)(arg1 + 0x84);
                        uStack_160 = uStack_168;
                    }
                    piVar2 = (int32_t *)(*(int64_t *)(arg1 + 0x1e8) + 0x4a0);
                    *piVar2 = *piVar2 + 1;
                    uVar18 = 0;
                    uStack_1b8 = 0;
                    uStack_1b0 = 0;
                    var_260h._0_1_ = 0;
                    var_268h = (int64_t)&uStack_1b8;
                    var_270h = 0;
                    var_278h = (int64_t)&uStack_200;
                    uStack_200 = uVar29;
                    uStack_1f8 = uStack_160;
                    func_0x0001800e3690(arg1, &iStack_1e8, 0, &uStack_1a8);
                    piVar2 = (int32_t *)(*(int64_t *)(arg1 + 0x1e8) + 0x4a0);
                    *piVar2 = *piVar2 + -1;
                    if (*(int64_t *)(iStack_1e8 + 0x60) != 0) {
                        iVar26 = ***(int64_t ***)(iStack_1e8 + 0x58);
                        uVar16 = uVar18;
                        if (iVar26 != 0) {
                            do {
                                uVar15 = uVar16 + 1;
                                if (*(char *)(iVar26 + uVar16) != *(char *)(uVar16 + 0x18063ca00))
                                goto code_r0x0001800e0b8f;
                                uVar16 = uVar15;
                            } while (uVar15 != 5);
                            iVar26 = (**(int64_t ***)(iStack_1e8 + 0x58))[7];
                            if (iVar26 != 0) {
                                func_0x0001800efe70(arg1, iVar26 + 0xc, 0x180642d90);
                            }
                        }
                    }
code_r0x0001800e0b8f:
                    iVar7 = func_0x000180498f90(uVar10, 0x180642d40, 2);
                    iVar26 = iVar11;
                    if (iVar7 == 0) {
                        auStack_100 = ZEXT816(0);
                        uStack_f0 = 0;
                        uStack_e8 = 0;
                        uVar9 = func_0x000180498cd0(uVar10);
                        func_0x000180004830(auStack_100, uVar10, uVar9);
                        uVar10 = uStack_e8;
                        uVar19 = uStack_f0;
                        puVar6 = (undefined *)auStack_100._0_8_;
                        puVar17 = auStack_100;
                        if (0xf < uStack_e8) {
                            puVar17 = (undefined *)auStack_100._0_8_;
                        }
                        uVar16 = 0xcbf29ce484222325;
                        if (uStack_f0 != 0) {
                            do {
                                uVar16 = (uVar16 ^ (uint8_t)puVar17[uVar18]) * 0x100000001b3;
                                uVar18 = uVar18 + 1;
                                arg1 = iStack_1d0;
                            } while (uVar18 < uStack_f0);
                        }
                        iVar11 = *(int64_t *)(*(int64_t *)0x180782358 + 8 + (uVar16 & *(uint64_t *)0x180782370) * 0x10);
                        if (iVar11 != *(int64_t *)0x180782348) {
                            iVar26 = *(int64_t *)(*(int64_t *)0x180782358 + (uVar16 & *(uint64_t *)0x180782370) * 0x10);
                            while( true ) {
                                piVar20 = (int64_t *)(iVar11 + 0x10);
                                if (0xf < *(uint64_t *)(iVar11 + 0x28)) {
                                    piVar20 = (int64_t *)*piVar20;
                                }
                                puVar17 = auStack_100;
                                if (0xf < uVar10) {
                                    puVar17 = puVar6;
                                }
                                if ((uVar19 == *(uint64_t *)(iVar11 + 0x20)) &&
                                   ((uVar19 == 0 || (iVar7 = func_0x000180497f30(puVar17, piVar20, uVar19), iVar7 == 0))
                                   )) goto code_r0x0001800e0cae;
                                if (iVar11 == iVar26) break;
                                iVar11 = *(int64_t *)(iVar11 + 8);
                            }
                        }
                        iVar11 = 0;
code_r0x0001800e0cae:
                        uVar18 = 0;
                        if (0xf < uVar10) {
                            uVar19 = uVar10 + 1;
                            puVar17 = puVar6;
                            if (uVar19 < 0x1000) {
code_r0x0001800e0cdd:
                                func_0x000180459c3c(puVar17, uVar19);
                                goto code_r0x0001800e0ce5;
                            }
                            puVar17 = *(undefined **)(puVar6 + -8);
                            if (puVar6 + (-8 - (int64_t)puVar17) < (undefined *)0x20) {
                                uVar19 = uVar10 + 0x28;
                                goto code_r0x0001800e0cdd;
                            }
code_r0x0001800e1104:
                            pcVar3 = (code *)swi(0x29);
                            (*pcVar3)(5);
                            puVar22 = auStack_290;
                            break;
                        }
code_r0x0001800e0ce5:
                        if (iVar11 == 0) {
                            auStack_e0 = ZEXT816(0);
                            uStack_d0 = 0;
                            uStack_c8 = 0;
                            uVar9 = func_0x000180498cd0(uVar29);
                            func_0x000180004830(auStack_e0, uVar29, uVar9);
                            uVar10 = uStack_c8;
                            uVar19 = uStack_d0;
                            puVar6 = (undefined *)auStack_e0._0_8_;
                            puVar17 = auStack_e0;
                            if (0xf < uStack_c8) {
                                puVar17 = (undefined *)auStack_e0._0_8_;
                            }
                            uVar15 = 0xcbf29ce484222325;
                            uVar16 = uVar18;
                            if (uStack_d0 != 0) {
                                do {
                                    uVar15 = (uVar15 ^ (uint8_t)puVar17[uVar16]) * 0x100000001b3;
                                    uVar16 = uVar16 + 1;
                                    arg1 = iStack_1d0;
                                } while (uVar16 < uStack_d0);
                            }
                            uVar16 = *(uint64_t *)
                                      (*(int64_t *)0x180781fb8 + 8 + (uVar15 & *(uint64_t *)0x180781fd0) * 0x10);
                            if (uVar16 != *(uint64_t *)0x180781fa8) {
                                uVar15 = *(uint64_t *)
                                          (*(int64_t *)0x180781fb8 + (uVar15 & *(uint64_t *)0x180781fd0) * 0x10);
                                while( true ) {
                                    piVar20 = (int64_t *)(uVar16 + 0x10);
                                    if (0xf < *(uint64_t *)(uVar16 + 0x28)) {
                                        piVar20 = (int64_t *)*piVar20;
                                    }
                                    puVar17 = auStack_e0;
                                    if (0xf < uVar10) {
                                        puVar17 = puVar6;
                                    }
                                    if ((uVar19 == *(uint64_t *)(uVar16 + 0x20)) &&
                                       ((uVar18 = uVar16, uVar19 == 0 ||
                                        (iVar7 = func_0x000180497f30(puVar17, piVar20, uVar19), iVar7 == 0))))
                                    goto code_r0x0001800e0e04;
                                    if (uVar16 == uVar15) break;
                                    uVar16 = *(uint64_t *)(uVar16 + 8);
                                }
                                uVar18 = 0;
                            }
code_r0x0001800e0e04:
                            if (0xf < uVar10) {
                                if ((0xfff < uVar10 + 1) &&
                                   ((undefined *)0x1f < puVar6 + (-8 - *(int64_t *)(puVar6 + -8))))
                                goto code_r0x0001800e1104;
                                func_0x000180459c3c();
                            }
                            uVar19 = uStack_218;
                            iVar26 = stack0xfffffffffffffdb0;
                            if (uVar18 != 0) goto code_r0x0001800e0e63;
                            uVar9 = 0x180642ef0;
                        } else {
                            uVar9 = 0x180642ec0;
                        }
                        func_0x0001800efe70(arg1, &uStack_1f8, uVar9, uVar29);
                        uVar19 = uStack_218;
                        uVar29 = uStack_200;
                        iVar26 = stack0xfffffffffffffdb0;
                    }
code_r0x0001800e0e63:
                    iVar14 = var_228h;
                    iVar11 = iVar26;
                    if ((var_220h != 0) && (uVar29 != uVar19)) {
                        uVar10 = (uVar29 >> 5 ^ uVar29) >> 4;
                        uVar18 = 0;
                        do {
                            uVar10 = uVar10 & var_228h - 1U;
                            uVar16 = *(uint64_t *)(iVar26 + uVar10 * 8);
                            if (uVar16 == uVar29) {
                                func_0x0001800efe70(arg1, &uStack_1f8, 0x180642d70, uVar29);
                                goto code_r0x0001800e10ec;
                            }
                            if (uVar16 == uVar19) break;
                            uVar10 = uVar10 + 1 + uVar18;
                            uVar18 = uVar18 + 1;
                        } while (uVar18 <= var_228h - 1U);
                    }
                    iVar25 = var_228h;
                    if ((uint64_t)(var_228h * 3) >> 2 <= (uint64_t)var_220h) {
                        if ((var_220h != 0) && (uVar29 != uVar19)) {
                            uVar10 = (uVar29 >> 5 ^ uVar29) >> 4;
                            uVar18 = 0;
                            do {
                                uVar10 = uVar10 & var_228h - 1U;
                                uVar16 = *(uint64_t *)(iVar26 + uVar10 * 8);
                                if (uVar16 == uVar29) goto code_r0x0001800e0fe1;
                                if (uVar16 == uVar19) break;
                                uVar10 = uVar10 + 1 + uVar18;
                                uVar18 = uVar18 + 1;
                            } while (uVar18 <= var_228h - 1U);
                        }
                        if (var_228h == 0) {
                            iVar25 = 0x10;
code_r0x0001800e0f34:
                            iVar11 = func_0x000180459890(iVar25 * 8);
                            func_0x0001800ccc60(iVar11, iVar25, &uStack_218);
                        } else {
                            iVar25 = var_228h * 2;
                            if (iVar25 != 0) goto code_r0x0001800e0f34;
                            iVar11 = 0;
                            iVar25 = 0;
                        }
                        if (iVar14 != 0) {
                            uVar10 = 0;
                            do {
                                uVar18 = *(uint64_t *)(iVar26 + uVar10 * 8);
                                if (uVar18 != uVar19) {
                                    uVar16 = (uVar18 >> 5 ^ uVar18) >> 4;
                                    uVar15 = 0;
                                    do {
                                        uVar16 = uVar16 & iVar25 - 1U;
                                        puVar28 = (uint64_t *)(iVar11 + uVar16 * 8);
                                        if (*puVar28 == uVar19) {
                                            *puVar28 = uVar18;
                                            goto code_r0x0001800e0fab;
                                        }
                                        if (*puVar28 == uVar18) goto code_r0x0001800e0fab;
                                        uVar16 = uVar16 + 1 + uVar15;
                                        uVar15 = uVar15 + 1;
                                    } while (uVar15 <= iVar25 - 1U);
                                    puVar28 = (uint64_t *)0x0;
code_r0x0001800e0fab:
                                    *puVar28 = *(uint64_t *)(iVar26 + uVar10 * 8);
                                }
                                uVar10 = uVar10 + 1;
                            } while (uVar10 < (uint64_t)iVar14);
                        }
                        unique0x100017af = iVar11;
                        var_230h = iVar11;
                        var_228h = iVar25;
                        if (iVar26 != 0) {
                            func_0x0001800f4640();
                        }
                    }
code_r0x0001800e0fe1:
                    uVar10 = (uVar29 >> 5 ^ uVar29) >> 4;
                    uVar18 = 0;
                    do {
                        uVar10 = uVar10 & iVar25 - 1U;
                        puVar28 = (uint64_t *)(iVar11 + uVar10 * 8);
                        uVar16 = *puVar28;
                        if (uVar16 == uVar19) {
                            *puVar28 = uVar29;
                            var_220h = var_220h + 1;
                            break;
                        }
                        if (uVar16 == uVar29) break;
                        uVar10 = uVar10 + 1 + uVar18;
                        uVar18 = uVar18 + 1;
                    } while (uVar18 <= iVar25 - 1U);
                    uStack_138._0_4_ = CONCAT13(uStack_175, CONCAT21(uStack_177, var_258h));
                    uStack_138 = CONCAT44(uStack_1a4, (undefined4)uStack_138);
                    uStack_130 = uStack_1a0;
                    uStack_12c = uStack_19c;
                    uStack_128 = (undefined4)uStack_198;
                    auStack_120 = (undefined  [8])uVar29;
                    auVar4 = _auStack_120;
                    aiStack_c0[0] = 1;
                    auStack_b8._4_4_ = uVar35;
                    auStack_b8._0_4_ = uVar34;
                    auStack_b8._8_4_ = uVar36;
                    auStack_b8._12_4_ = uVar37;
                    uStack_a8 = (undefined4)uStack_138;
                    uStack_a4 = uStack_1a4;
                    uStack_a0 = uStack_1a0;
                    uStack_9c = uStack_19c;
                    auStack_120._0_4_ = (undefined4)uVar29;
                    auStack_120._4_4_ = (undefined4)(uVar29 >> 0x20);
                    uStack_98 = (undefined4)uStack_198;
                    uStack_94 = uStack_124;
                    uStack_90 = auStack_120._0_4_;
                    uStack_8c = auStack_120._4_4_;
                    uStack_88 = (undefined4)uStack_1f8;
                    uStack_84 = uStack_1f8._4_4_;
                    var_80h._0_4_ = (undefined4)uStack_1f0;
                    var_80h._4_4_ = uStack_1f0._4_4_;
                    var_78h = iStack_1e8;
                    _auStack_120 = auVar4;
                    func_0x0001800f2050(&var_248h, aiStack_c0);
                    pcVar3 = *(code **)((int64_t)aiStack_c0[0] * 8 + 0x180644200);
                    if (pcVar3 != (code *)0x1800086f0) {
                        (*pcVar3)();
                    }
                } else {
                    func_0x0001800efe70(arg1, arg1 + 0x84, 0x180642f40);
                    func_0x0001800f0350();
                }
            }
code_r0x0001800e10ec:
            iVar7 = *(int32_t *)(arg1 + 0x80);
        } while (iVar7 != 0x128);
        iStack_1e8 = *piStack_170;
        iStack_1e0 = piStack_170[1];
        puVar23 = puVar22;
        piVar30 = *(int64_t **)(puVar22 + 0x50);
        iVar11 = *(int64_t *)(puVar22 + 0x58);
code_r0x0001800e1124:
        piVar12 = piStack_1d8;
        *(undefined8 *)(puVar23 + -8) = 0x1800e112c;
        func_0x0001800f0350(arg1);
        puVar24 = puVar23;
    }
    uStack_1b8 = *ppiStack_1c8;
    uStack_1b0 = iStack_1e0;
    if (1 < *(uint32_t *)(arg1 + 0x114)) {
        iVar26 = *piVar12;
        *(undefined8 *)(puVar24 + -8) = 0x1800e115f;
        func_0x0001800efe70(arg1, piVar12 + 1, 0x180642f90, iVar26);
    }
    ppiVar31 = *(int64_t ***)(arg1 + 0xd8);
    piVar20 = *(int64_t **)(puVar24 + 0x60);
    ppiStack_1c8 = ppiVar31;
    if (piVar20 == (int64_t *)0x0) {
        piVar12 = (int64_t *)0x0;
    } else {
        iVar26 = iVar11 * 0x50 + *piVar30;
        *(undefined8 *)(puVar24 + -8) = 0x1800e11d1;
        piVar12 = (int64_t *)func_0x0001800d4d20(ppiVar31, (int64_t)piVar20 * 0x50);
        piVar13 = (int64_t *)0x0;
        if (piVar20 != (int64_t *)0x0) {
            do {
                iVar7 = *(int32_t *)(iVar26 + (int64_t)piVar13 * 0x50);
                *(int32_t *)(piVar12 + (int64_t)piVar13 * 10) = iVar7;
                pcVar3 = *(code **)((int64_t)iVar7 * 8 + 0x1806441a0);
                *(undefined8 *)(puVar24 + -8) = 0x1800e1215;
                (*pcVar3)(piVar12 + (int64_t)piVar13 * 10 + 1, (int64_t)piVar13 * 0x50 + 8 + iVar26);
                piVar13 = (int64_t *)((int64_t)piVar13 + 1);
                ppiVar31 = ppiStack_1c8;
            } while (piVar13 < piVar20);
        }
    }
    piVar13 = *ppiVar31;
    if (piVar13 != (int64_t *)0x0) {
        ppiVar27 = (int64_t **)((int64_t)ppiVar31[1] + 7 + (int64_t)(piVar13 + 1) & 0xfffffffffffffff8);
        if (ppiVar27 + 9 <= piVar13 + 0x401) {
            piVar13 = (int64_t *)((int64_t)ppiVar27 + (0x48 - (int64_t)(piVar13 + 1)));
            goto code_r0x0001800e1277;
        }
    }
    *(undefined8 *)(puVar24 + -8) = 0x1800e1263;
    ppiVar27 = (int64_t **)func_0x000180459890(0x2008);
    *ppiVar27 = *ppiVar31;
    *ppiVar31 = (int64_t *)ppiVar27;
    ppiVar27 = ppiVar27 + 1;
    piVar13 = (int64_t *)0x48;
code_r0x0001800e1277:
    iVar26 = iStack_1d0;
    piVar5 = piStack_1d8;
    ppiVar31[1] = piVar13;
    *(undefined4 *)(ppiVar27 + 1) = *(undefined4 *)0x180782788;
    *(undefined4 *)((int64_t)ppiVar27 + 0xc) = (undefined4)uStack_1b8;
    *(undefined4 *)(ppiVar27 + 2) = uStack_1b8._4_4_;
    *(undefined4 *)((int64_t)ppiVar27 + 0x14) = (undefined4)uStack_1b0;
    *(undefined4 *)(ppiVar27 + 3) = uStack_1b0._4_4_;
    *(undefined *)(ppiVar27 + 4) = 0;
    *ppiVar27 = (int64_t *)0x180641eb0;
    ppiVar27[5] = piStack_1d8;
    ppiVar27[6] = piVar12;
    ppiVar27[7] = piVar20;
    *(undefined *)(ppiVar27 + 8) = puVar24[0x41];
    *(undefined8 *)(puVar24 + -8) = 0x1800e12c5;
    iVar14 = func_0x0001800c1560(iStack_1d0 + 0x1a8, piStack_1d8);
    if (iVar14 == 0) {
        *(undefined8 *)(puVar24 + -8) = 0x1800e133f;
        func_0x0001800ccb10(iVar26 + 0x1a8, piVar5);
    } else {
        *(undefined8 *)(puVar24 + -8) = 0x1800e12de;
        fcn.1800ef070(*(int64_t *)(puVar24 + 0x78));
        iVar14 = *piVar5;
        *(undefined8 *)(puVar24 + -8) = 0x1800e12fc;
        ppiStack_1c0 = ppiVar27;
        func_0x0001800f1110(iVar26, &uStack_1b8, &ppiStack_1c0, 1);
        iStack_1e8 = 0;
        iStack_1e0 = 0;
        *(int64_t *)(puVar24 + 0x28) = iVar14;
        *(undefined8 *)(puVar24 + 0x20) = 0x180642e08;
        *(undefined8 *)(puVar24 + -8) = 0x1800e132b;
        func_0x0001800eff80(iVar26, piVar5 + 1, &iStack_1e8, &uStack_1b8);
    }
    if (*(int64_t *)(puVar24 + 0x48) != 0) {
        *(undefined8 *)(puVar24 + -8) = 0x1800e134f;
        func_0x0001800f4640();
    }
    piVar2 = (int32_t *)piVar30[1];
    piVar33 = (int32_t *)(iVar11 * 0x50 + *piVar30);
    piVar21 = piVar33;
    if (piVar33 != piVar2) {
        do {
            pcVar3 = *(code **)((int64_t)*piVar21 * 8 + 0x180644200);
            *(undefined8 *)(puVar24 + -8) = 0x1800e137f;
            (*pcVar3)(piVar21 + 2);
            piVar21 = piVar21 + 0x14;
        } while (piVar21 != piVar2);
        piVar30[1] = (int64_t)piVar33;
    }
    *(undefined8 *)(puVar24 + -8) = 0x1800e13a0;
    func_0x000180459870(var_70h ^ (uint64_t)puVar24);
    return;
}

// ============================================================
// Function: FUN_1800e13d0
// Address: 0x1800e13d0
// Size: 6658 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_2c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_2b3h
// WARNING: [rz-ghidra] Detected overlap for variable var_2b1h
// WARNING: [rz-ghidra] Detected overlap for variable arg_d4h
// WARNING: [rz-ghidra] Removing arg arg_dch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Removing arg arg_131h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_fh
// WARNING: [rz-ghidra] Removing arg arg_133h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_dh
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable arg_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_2b0h
// WARNING: [rz-ghidra] Detected overlap for variable var_2c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_2b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_2a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.1800e13d0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t **placeholder_3, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                  undefined8 placeholder_12, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h,
                  int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h,
                  int64_t arg_c0h, int64_t arg_c8h, int64_t arg_d0h, undefined8 placeholder_26,
                  undefined8 placeholder_27, int64_t arg_e8h, int64_t arg_f0h, int64_t arg_f8h, int64_t arg_100h,
                  int64_t arg_108h, undefined8 placeholder_33, int64_t arg_118h, int64_t arg_120h, int64_t arg_140h,
                  int64_t arg_148h, int64_t arg_150h, int64_t arg_158h, int64_t arg_160h, int64_t arg_168h,
                  int64_t arg_178h, int64_t arg_188h, int64_t arg_190h, int64_t arg_198h, int64_t arg_1a0h,
                  int64_t arg_1a8h)
{
    undefined4 uVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined auVar4 [16];
    undefined4 uVar5;
    undefined4 uVar6;
    bool bVar7;
    char cVar8;
    undefined *puVar9;
    int64_t *piVar10;
    int64_t **ppiVar11;
    undefined8 uVar12;
    int64_t **ppiVar13;
    int64_t *piVar14;
    int32_t *piVar15;
    undefined8 *puVar16;
    undefined8 uVar17;
    int64_t iVar18;
    int64_t **ppiVar19;
    int64_t **ppiVar20;
    uint64_t uVar21;
    undefined4 *puVar22;
    uint64_t uVar23;
    int64_t ***pppiVar24;
    int64_t **ppiVar25;
    int32_t iVar26;
    undefined *puVar27;
    int64_t **ppiVar28;
    int64_t iVar29;
    int64_t *piVar30;
    int64_t **ppiVar31;
    undefined4 uVar32;
    undefined4 uVar33;
    undefined4 uVar34;
    undefined4 uVar35;
    int64_t var_8h;
    undefined8 uStack_310;
    undefined auStack_308 [8];
    undefined auStack_300 [24];
    int64_t var_2e8h;
    int64_t var_2e0h;
    int64_t var_2d8h;
    int64_t var_2d0h;
    char var_2c8h;
    int64_t var_2c7h;
    undefined var_2b8h;
    int64_t var_2b7h;
    int64_t var_2a8h;
    int64_t var_2a0h;
    int64_t var_298h;
    int64_t var_290h;
    int64_t *piStack_288;
    int64_t iStack_280;
    int64_t **ppiStack_278;
    int32_t iStack_270;
    undefined4 uStack_26c;
    undefined4 uStack_268;
    undefined4 uStack_264;
    int64_t **ppiStack_258;
    undefined8 uStack_250;
    int64_t **ppiStack_248;
    undefined4 uStack_240;
    undefined4 uStack_23c;
    undefined8 uStack_228;
    undefined8 uStack_220;
    undefined8 uStack_218;
    undefined8 uStack_208;
    undefined8 uStack_200;
    int64_t *piStack_1f8;
    int64_t *piStack_1f0;
    int64_t **ppiStack_1e8;
    int64_t *piStack_1e0;
    int64_t iStack_1d8;
    int64_t **ppiStack_1d0;
    undefined8 uStack_1c8;
    undefined8 uStack_1c0;
    undefined8 uStack_1b8;
    undefined4 uStack_1b0;
    int32_t iStack_1ac;
    int64_t *piStack_1a8;
    undefined4 uStack_1a0;
    undefined4 uStack_19c;
    undefined8 uStack_198;
    int64_t **ppiStack_190;
    int64_t **ppiStack_188;
    int64_t **ppiStack_180;
    undefined8 uStack_178;
    undefined4 uStack_170;
    undefined4 uStack_16c;
    undefined4 uStack_168;
    undefined4 uStack_164;
    int64_t *piStack_160;
    int64_t **ppiStack_158;
    undefined auStack_150 [16];
    int64_t **ppiStack_140;
    undefined uStack_138;
    int64_t **ppiStack_134;
    int64_t **ppiStack_12c;
    undefined4 uStack_124;
    int32_t iStack_120;
    undefined4 uStack_11c;
    undefined4 uStack_118;
    undefined4 uStack_114;
    int64_t *piStack_110;
    int64_t *piStack_108;
    int64_t **ppiStack_100;
    undefined8 uStack_f0;
    undefined4 uStack_e8;
    undefined4 uStack_e4;
    undefined4 uStack_e0;
    undefined4 uStack_dc;
    undefined2 uStack_d7;
    undefined uStack_d5;
    undefined8 uStack_d0;
    undefined8 uStack_c8;
    int64_t **ppiStack_c0;
    int64_t **ppiStack_b8;
    undefined8 uStack_b0;
    undefined8 uStack_a8;
    undefined4 uStack_a0;
    undefined4 uStack_9c;
    undefined4 uStack_98;
    undefined4 uStack_94;
    undefined auStack_90 [16];
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    uint64_t var_60h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    
    puVar27 = auStack_308;
    var_60h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_308;
    piVar15 = (int32_t *)(arg1 + 0x80);
    iVar18 = arg1;
    puVar9 = auStack_308;
    ppiStack_278 = (int64_t **)arg2;
    ppiStack_180 = (int64_t **)arg3;
    if (*(int64_t *)(arg3 + 8) == 0) {
code_r0x0001800e14df:
        puVar27 = puVar9;
        puVar9 = puVar27;
        if (*piVar15 != 299) {
            ppiVar20 = (int64_t **)0x0;
            ppiVar31 = ppiVar20;
            if (*(int64_t *)(iVar18 + 0x98) == 0) {
code_r0x0001800e1d42:
                ppiVar31 = ppiVar20;
                uStack_1b8 = (int64_t *)CONCAT44(uStack_1b8._4_4_, (int32_t)uStack_1b8);
                if (*(int64_t *)(arg1 + 0x98) == 0) {
code_r0x0001800e2cb6:
                    *(undefined8 *)(puVar27 + -8) = 0x1800e2ccc;
                    func_0x0001800ecab0(arg1, &var_80h, 0x180643390);
                    if ((char)var_68h == '\0') {
                        uStack_208 = 0;
                        uStack_200 = (int64_t **)0x0;
                        uStack_198 = 0;
                        ppiStack_190 = (int64_t **)0x0;
                        *(undefined8 *)(puVar27 + 0x20) = 0x1806432b0;
                        *(undefined8 *)(puVar27 + -8) = 0x1800e2d92;
                        func_0x0001800eff80(arg1, arg2, &uStack_198, &uStack_208);
                    } else {
                        if (*(int32_t *)(arg1 + 0x80) == 0x3a) {
                            *(undefined8 *)(puVar27 + -8) = 0x1800e2cfe;
                            func_0x0001800f0350();
                        } else {
                            *(undefined8 *)(puVar27 + -8) = 0x1800e2cf7;
                            func_0x0001800ef2a0(arg1, 0x3a, 0x180643288);
                        }
                        *(undefined8 *)(puVar27 + -8) = 0x1800e2d08;
                        iVar18 = func_0x0001800e8150(arg1, 1);
                        uStack_208 = *(undefined8 *)arg2;
                        uStack_200 = *(int64_t ***)(iVar18 + 0x14);
                        uVar12 = *(undefined8 *)(arg1 + 0xd8);
                        *(undefined8 *)(puVar27 + -8) = 0x1800e2d2b;
                        puVar16 = (undefined8 *)func_0x0001800d4d20(uVar12, 0x48);
                        *(undefined4 *)(puVar16 + 1) = *(undefined4 *)0x180782714;
                        *(undefined4 *)((int64_t)puVar16 + 0xc) = (undefined4)uStack_208;
                        *(undefined4 *)(puVar16 + 2) = uStack_208._4_4_;
                        *(undefined4 *)((int64_t)puVar16 + 0x14) = (undefined4)uStack_200;
                        *(undefined4 *)(puVar16 + 3) = uStack_200._4_4_;
                        *(undefined *)(puVar16 + 4) = 0;
                        *puVar16 = 0x180642180;
                        puVar16[5] = CONCAT44(var_80h._4_4_, (undefined4)var_80h);
                        *(undefined4 *)(puVar16 + 6) = (undefined4)var_78h;
                        *(undefined4 *)((int64_t)puVar16 + 0x34) = var_78h._4_4_;
                        *(undefined4 *)(puVar16 + 7) = (undefined4)var_70h;
                        *(undefined4 *)((int64_t)puVar16 + 0x3c) = var_70h._4_4_;
                        puVar16[8] = iVar18;
                    }
                    goto code_r0x0001800e2d92;
                }
                do {
                    ppiVar11 = (int64_t **)((int64_t)ppiVar31 + 1);
                    uStack_1b8 = (int64_t *)CONCAT44(uStack_1b8._4_4_, (int32_t)uStack_1b8);
                    if (*(char *)(*(int64_t *)(arg1 + 0x98) + (int64_t)ppiVar31) != *(char *)(ppiVar31 + 0x300c8601))
                    goto code_r0x0001800e2cb6;
                    ppiVar31 = ppiVar11;
                } while (ppiVar11 != (int64_t **)0x7);
            } else {
                do {
                    ppiVar11 = (int64_t **)((int64_t)ppiVar31 + 1);
                    if (*(char *)(*(int64_t *)(iVar18 + 0x98) + (int64_t)ppiVar31) != *(char *)(ppiVar31 + 0x300c7c33))
                    goto code_r0x0001800e1d42;
                    ppiVar31 = ppiVar11;
                } while (ppiVar11 != (int64_t **)0x6);
                if (*(char *)0x180778098 != '\0') {
                    *(undefined8 *)(puVar27 + -8) = 0x1800e1d3d;
                    piVar15 = (int32_t *)func_0x0001800d70e0(arg1 + 0x60, &var_80h);
                    if (*piVar15 == 0x3a) goto code_r0x0001800e1d42;
                }
            }
            bVar7 = false;
            ppiVar31 = ppiVar20;
            if (*(int64_t *)(arg1 + 0x98) != 0) {
                do {
                    ppiVar11 = (int64_t **)((int64_t)ppiVar31 + 1);
                    if (*(char *)(*(int64_t *)(arg1 + 0x98) + (int64_t)ppiVar31) != *(char *)(ppiVar31 + 0x300c8601))
                    goto code_r0x0001800e1dd8;
                    ppiVar31 = ppiVar11;
                } while (ppiVar11 != (int64_t **)0x7);
                *(undefined8 *)(puVar27 + -8) = 0x1800e1d9b;
                func_0x0001800f0350(arg1);
                iVar18 = *(int64_t *)(arg1 + 0x98);
                if (iVar18 == 0) {
code_r0x0001800e1e69:
                    *(undefined8 *)(puVar27 + 0x48) = 0;
                    *(undefined8 *)(puVar27 + 0x50) = 0;
                    iStack_270 = 0;
                    uStack_26c = 0;
                    uStack_268 = 0;
                    uStack_264 = 0;
                    *(int64_t *)(puVar27 + 0x28) = iVar18;
                    *(undefined8 *)(puVar27 + 0x20) = 0x180643010;
                    *(undefined8 *)(puVar27 + -8) = 0x1800e1ea4;
                    func_0x0001800eff80(arg1, arg1 + 0x84, &iStack_270, puVar27 + 0x48);
                    goto code_r0x0001800e2d92;
                }
                bVar7 = true;
                ppiVar31 = ppiVar20;
                do {
                    ppiVar11 = (int64_t **)((int64_t)ppiVar31 + 1);
                    if (*(char *)(iVar18 + (int64_t)ppiVar31) != *(char *)((int64_t)ppiVar31 + 0x18062623c))
                    goto code_r0x0001800e1e69;
                    ppiVar31 = ppiVar11;
                } while (ppiVar11 != (int64_t **)0x5);
            }
code_r0x0001800e1dd8:
            *(undefined8 *)(puVar27 + -8) = 0x1800e1de0;
            func_0x0001800f0350(arg1);
            uStack_a0 = *(undefined4 *)(arg1 + 0x84);
            uStack_9c = *(undefined4 *)(arg1 + 0x88);
            uStack_98 = *(undefined4 *)(arg1 + 0x8c);
            uStack_94 = *(undefined4 *)(arg1 + 0x90);
            *(undefined8 *)(puVar27 + -8) = 0x1800e1e05;
            func_0x0001800ecb20(arg1, &var_80h, 0x180642dc8);
            puVar27[0x41] = 0;
            ppiVar31 = ppiVar20;
            if (*(int64_t *)(arg1 + 0x98) == 0) {
code_r0x0001800e1ea9:
                uVar12 = *(undefined8 *)(puVar27 + 0x48);
            } else {
                do {
                    ppiVar11 = (int64_t **)((int64_t)ppiVar31 + 1);
                    if (*(char *)(*(int64_t *)(arg1 + 0x98) + (int64_t)ppiVar31) != *(char *)(ppiVar31 + 0x300c860a))
                    goto code_r0x0001800e1ea9;
                    ppiVar31 = ppiVar11;
                } while (ppiVar11 != (int64_t **)0x8);
                *(undefined8 *)(puVar27 + -8) = 0x1800e1e4c;
                func_0x0001800f0350(arg1);
                *(undefined8 *)(puVar27 + -8) = 0x1800e1e5f;
                puVar16 = (undefined8 *)func_0x0001800ecb20(arg1, &ppiStack_258, 0x1806431c0);
                uVar12 = *puVar16;
                puVar27[0x41] = 1;
            }
            uStack_f0 = uVar12;
            if (bVar7) {
                ppiVar31 = ppiVar20;
                if (*(int64_t *)(arg1 + 0x98) == 0) {
code_r0x0001800e1eee:
                    *(undefined8 *)(puVar27 + -8) = 0x1800e1f04;
                    func_0x0001800efe70(arg1, arg1 + 0x84, 0x1806431e0);
                } else {
                    do {
                        ppiVar11 = (int64_t **)((int64_t)ppiVar31 + 1);
                        if (*(char *)(*(int64_t *)(arg1 + 0x98) + (int64_t)ppiVar31) != *(char *)(ppiVar31 + 0x300c863a)
                           ) goto code_r0x0001800e1eee;
                        ppiVar31 = ppiVar11;
                    } while (ppiVar11 != (int64_t **)0x5);
                    *(undefined8 *)(puVar27 + -8) = 0x1800e1eec;
                    func_0x0001800f0350(arg1);
                }
            }
            piStack_1e0 = (int64_t *)(arg1 + 0x380);
            iStack_1d8 = (*(int64_t *)(arg1 + 0x388) - *piStack_1e0 >> 3) * 0x6db6db6db6db6db7;
            ppiStack_1d0 = (int64_t **)0x0;
            ppiStack_278 = (int64_t **)0x0;
            iVar26 = *(int32_t *)(arg1 + 0x80);
            ppiVar31 = ppiVar20;
            if (iVar26 != 0x128) {
code_r0x0001800e1f60:
                arg2 = 0x1806431b4;
                if (iVar26 - 0x11cU < 2) {
                    *(undefined8 *)(puVar27 + -8) = 0x1800e1f88;
                    ppiVar11 = (int64_t **)fcn.1800de530(arg1, (int64_t)auStack_90);
                    if (*(int32_t *)(arg1 + 0x80) != 299) {
                        *(undefined8 *)(puVar27 + -8) = 0x1800e2c23;
                        puVar16 = (undefined8 *)func_0x0001800d62b0(arg1 + 0x80, &var_80h);
                        if (0xf < (uint64_t)puVar16[3]) {
                            puVar16 = (undefined8 *)*puVar16;
                        }
                        uStack_208 = 0;
                        uStack_200 = (int64_t **)0x0;
                        uStack_198 = 0;
                        ppiStack_190 = (int64_t **)0x0;
                        *(undefined8 **)(puVar27 + 0x28) = puVar16;
                        *(undefined8 *)(puVar27 + 0x20) = 0x180643240;
                        *(undefined8 *)(puVar27 + -8) = 0x1800e2c66;
                        func_0x0001800eff80(arg1, arg1 + 0x84, &uStack_198, &uStack_208);
                        uVar23 = CONCAT44(var_68h._4_4_, (undefined4)var_68h);
                        piVar10 = piStack_1e0;
                        if (uVar23 < 0x10) goto code_r0x0001800e2be5;
                        uVar21 = uVar23 + 1;
                        iVar29 = CONCAT44(var_80h._4_4_, (undefined4)var_80h);
                        iVar18 = iVar29;
                        if (0xfff < uVar21) {
                            iVar18 = *(int64_t *)(iVar29 + -8);
                            if (0x1f < (iVar29 - iVar18) - 8U) {
                                pcVar3 = (code *)swi(0x29);
                                (*pcVar3)(5);
                                puVar27 = puVar27 + 8;
                                goto code_r0x0001800e2cb6;
                            }
                            uVar21 = uVar23 + 0x28;
                        }
                        *(undefined8 *)(puVar27 + -8) = 0x1800e2ca6;
                        func_0x000180459c3c(iVar18, uVar21);
                        piVar10 = piStack_1e0;
                        goto code_r0x0001800e2be5;
                    }
                    piStack_160 = *ppiVar11;
                    *(int64_t **)(puVar27 + 0x60) = ppiVar11[1];
                    iVar26 = 299;
                } else {
                    piStack_160 = (int64_t *)0x0;
                    *(undefined8 *)(puVar27 + 0x60) = 0;
                }
                if (iVar26 != 299) {
                    if (iVar26 == 0x5b) {
                        uStack_1b8._4_4_ = *(undefined4 *)(arg1 + 0x84);
                        uStack_1b0 = *(undefined4 *)(arg1 + 0x88);
                        iStack_1ac = *(int32_t *)(arg1 + 0x8c);
                        ppiVar11 = *(int64_t ***)(int64_t **)(arg1 + 0x90);
                        piStack_1a8 = *(int64_t **)(arg1 + 0x90);
                        uVar33 = *(undefined4 *)(arg1 + 0x98);
                        uVar35 = *(undefined4 *)(arg1 + 0x9c);
                        *(undefined8 *)(puVar27 + -8) = 0x1800e273d;
                        uStack_1b8._0_4_ = iVar26;
                        uStack_1a0 = uVar33;
                        uStack_19c = uVar35;
                        func_0x0001800f0350(arg1);
                        if (*(int32_t *)(arg1 + 0x80) - 0x116U < 2) {
                            *(undefined8 *)(puVar27 + -8) = 0x1800e2762;
                            piVar15 = (int32_t *)func_0x0001800d70e0(arg1 + 0x60, &piStack_110);
                            if (*piVar15 != 0x5d) goto code_r0x0001800e28f5;
                            uVar33 = *(undefined4 *)(arg1 + 0x88);
                            uVar35 = *(undefined4 *)(arg1 + 0x8c);
                            uVar32 = *(undefined4 *)(arg1 + 0x90);
                            *(undefined4 *)(puVar27 + 0x48) = *(undefined4 *)(arg1 + 0x84);
                            *(undefined4 *)(puVar27 + 0x4c) = uVar33;
                            *(undefined4 *)(puVar27 + 0x50) = uVar35;
                            *(undefined4 *)(puVar27 + 0x54) = uVar32;
                            *(undefined8 *)(puVar27 + -8) = 0x1800e2787;
                            func_0x0001800edd70(arg1, &ppiStack_258, 0);
                            uVar33 = *(undefined4 *)(arg1 + 0xa4);
                            uVar35 = *(undefined4 *)(arg1 + 0xa8);
                            uVar32 = *(undefined4 *)(arg1 + 0xac);
                            *(undefined4 *)(puVar27 + 0x60) = *(undefined4 *)(arg1 + 0xa0);
                            *(undefined4 *)(puVar27 + 100) = uVar33;
                            *(undefined4 *)(puVar27 + 0x68) = uVar35;
                            *(undefined4 *)(puVar27 + 0x6c) = uVar32;
                            ppiVar31 = (int64_t **)CONCAT44(uStack_1b0, uStack_1b8._4_4_);
                            uStack_26c = uStack_1b8._4_4_;
                            uStack_268 = uStack_1b0;
                            iStack_270 = iVar26;
                            if (*(int32_t *)(arg1 + 0x80) == 0x5d) {
                                *(undefined8 *)(puVar27 + -8) = 0x1800e27d1;
                                func_0x0001800f0350(arg1);
                            } else {
                                *(undefined8 *)(puVar27 + -8) = 0x1800e27bd;
                                func_0x0001800ef5a0(arg1, 0x5d, &iStack_270, 0);
                                *(undefined8 *)(puVar27 + -8) = 0x1800e27ca;
                                func_0x0001800ef4e0(arg1, 0x5d);
                            }
                            if (*(int32_t *)(arg1 + 0x80) == 0x3a) {
                                *(undefined8 *)(puVar27 + -8) = 0x1800e27f6;
                                func_0x0001800f0350(arg1);
                            } else {
                                *(undefined8 *)(puVar27 + -8) = 0x1800e27ef;
                                func_0x0001800ef2a0(arg1, 0x3a, 0x180643128);
                            }
                            uVar33 = *(undefined4 *)(arg1 + 0x114);
                            uStack_228 = *(int64_t ***)(arg1 + 0x84);
                            uStack_220 = *(int64_t ***)(arg1 + 0x8c);
                            ppiVar11 = ppiVar20;
                            if ((*(int32_t *)(arg1 + 0x80) != 0x7c) && (*(int32_t *)(arg1 + 0x80) != 0x26)) {
                                *(undefined8 *)(puVar27 + -8) = 0x1800e2832;
                                ppiVar11 = (int64_t **)func_0x0001800e81c0(arg1, &uStack_e8, 0);
                                ppiVar11 = (int64_t **)*ppiVar11;
                                *(undefined4 *)(arg1 + 0x114) = uVar33;
                            }
                            *(undefined8 *)(puVar27 + -8) = 0x1800e2848;
                            ppiVar13 = (int64_t **)func_0x0001800e7930(arg1, ppiVar11);
                            *(undefined4 *)(arg1 + 0x114) = uVar33;
                            ppiVar11 = ppiStack_258;
                            cVar8 = (char)ppiStack_248;
                            if ((char)ppiStack_248 == '\0') {
code_r0x0001800e2876:
                                bVar7 = false;
                            } else {
                                *(undefined8 *)(puVar27 + -8) = 0x1800e286d;
                                iVar18 = func_0x000180498a80(ppiStack_258, 0);
                                if (iVar18 == 0) goto code_r0x0001800e2876;
                                bVar7 = true;
                            }
                            if ((cVar8 == '\0') || (bVar7)) {
                                *(undefined8 *)(puVar27 + -8) = 0x1800e28e5;
                                func_0x0001800efe70(arg1);
                                ppiVar31 = ppiStack_278;
                                goto code_r0x0001800e2acd;
                            }
                            auStack_150._8_8_ = *(undefined8 *)(puVar27 + 0x68);
                            auStack_150._0_8_ = *(undefined8 *)(puVar27 + 0x48);
                            uStack_138 = 0;
                            ppiStack_12c = *(int64_t ***)(arg1 + 0xa8);
                            ppiStack_158 = ppiVar11;
                            ppiStack_140 = ppiVar13;
                            ppiStack_134 = ppiVar31;
                            goto code_r0x0001800e26f1;
                        }
code_r0x0001800e28f5:
                        ppiStack_258 = (int64_t **)CONCAT44(uStack_1b8._4_4_, (int32_t)uStack_1b8);
                        uStack_250 = (int64_t *)CONCAT44(iStack_1ac, uStack_1b0);
                        uStack_228 = (int64_t **)CONCAT44(uStack_e4, uStack_e8);
                        uStack_220 = (int64_t **)CONCAT44(uStack_dc, uStack_e0);
                        uStack_218 = (int64_t *)
                                     ((uint64_t)CONCAT43(uStack_218._4_4_, CONCAT12(uStack_d5, uStack_d7)) << 8);
                        *(int64_t ****)(puVar27 + 0x20) = &ppiStack_258;
                        *(undefined8 *)(puVar27 + -8) = 0x1800e2944;
                        ppiStack_248 = ppiVar11;
                        uStack_240 = uVar33;
                        uStack_23c = uVar35;
                        ppiVar11 = (int64_t **)func_0x0001800e58a0(arg1, &uStack_1b8, 3, &uStack_228);
                        if (ppiVar31 == (int64_t **)0x0) {
                            ppiStack_278 = (int64_t **)*ppiVar11;
                            ppiVar31 = ppiStack_278;
                        } else {
                            piVar10 = *ppiVar11;
                            *(undefined8 *)(puVar27 + -8) = 0x1800e295f;
                            func_0x0001800efe70(arg1, piVar10 + 2, 0x180643180);
                        }
                        goto code_r0x0001800e2acd;
                    }
                    uVar33 = 3;
                    if (iVar26 == 0x119) {
                        *(undefined8 *)(puVar27 + -8) = 0x1800e298e;
                        piVar15 = (int32_t *)func_0x0001800d70e0(arg1 + 0x60, &ppiStack_258);
                        if (*piVar15 == 0x3a) goto code_r0x0001800e2a1a;
                        iVar18 = *(int64_t *)(arg1 + 0x98);
                        ppiVar11 = ppiVar20;
                        if (iVar18 == 0) {
code_r0x0001800e29fb:
                            *(undefined8 *)(puVar27 + -8) = 0x1800e2a11;
                            func_0x0001800efe70(arg1, arg1 + 0x84, 0x180643348);
                            uVar33 = 3;
                        } else {
                            do {
                                ppiVar28 = (int64_t **)((int64_t)ppiVar11 + 1);
                                ppiVar13 = ppiVar20;
                                if (*(char *)(iVar18 + (int64_t)ppiVar11) != *(char *)((int64_t)ppiVar11 + 0x1806431b4))
                                goto code_r0x0001800e29e0;
                                ppiVar11 = ppiVar28;
                            } while (ppiVar28 != (int64_t **)0x5);
                            uVar33 = 1;
                        }
                        goto code_r0x0001800e2a11;
                    }
                    goto code_r0x0001800e2a1a;
                }
                uVar33 = *(undefined4 *)(arg1 + 0x88);
                uVar35 = *(undefined4 *)(arg1 + 0x8c);
                uVar32 = *(undefined4 *)(arg1 + 0x90);
                *(undefined4 *)(puVar27 + 0x48) = *(undefined4 *)(arg1 + 0x84);
                *(undefined4 *)(puVar27 + 0x4c) = uVar33;
                *(undefined4 *)(puVar27 + 0x50) = uVar35;
                *(undefined4 *)(puVar27 + 0x54) = uVar32;
                *(undefined8 *)(puVar27 + -8) = 0x1800e1fcf;
                func_0x0001800f0350(arg1);
                if (*(int32_t *)(arg1 + 0x80) == 0x119) {
                    ppiStack_180 = *(int64_t ***)(arg1 + 0x98);
                    uStack_178 = *(int64_t ***)(arg1 + 0x84);
                    uVar32 = *(undefined4 *)(int64_t **)(arg1 + 0x8c);
                    uVar35 = *(undefined4 *)(arg1 + 0x90);
                    piVar10 = *(int64_t **)(arg1 + 0x8c);
                    *(undefined8 *)(puVar27 + -8) = 0x1800e203a;
                    uStack_170 = uVar32;
                    uStack_16c = uVar35;
                    func_0x0001800f0350(arg1);
                    uStack_228 = ppiStack_180;
                    uVar33 = SUB84(uStack_178, 0);
                    uStack_220 = uStack_178;
                    ppiVar31 = ppiStack_180;
                    uVar34 = uStack_178._4_4_;
                    uStack_218 = piVar10;
                } else {
                    *(undefined8 *)(puVar27 + -8) = 0x1800e1feb;
                    func_0x0001800efe90(arg1, 0x180642a80);
                    uVar33 = *(undefined4 *)(int64_t **)(arg1 + 0x84);
                    uVar35 = *(undefined4 *)(arg1 + 0x88);
                    ppiStack_180 = *(int64_t ***)(int64_t **)(arg1 + 0x84);
                    ppiVar31 = *(int64_t ***)(arg1 + 0x128);
                    uVar34 = uVar35;
                    uVar32 = uVar33;
                    uStack_178 = ppiStack_180;
                }
                iStack_120 = *(int32_t *)(arg1 + 0x80);
                uStack_11c = (undefined4)*(undefined8 *)(arg1 + 0x84);
                uStack_118 = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x84) >> 0x20);
                uStack_1c8 = ppiVar31;
                if (iStack_120 == 0x28) {
                    *(undefined8 *)(puVar27 + -8) = 0x1800e2098;
                    func_0x0001800f0350(arg1);
                } else {
                    *(undefined8 *)(puVar27 + -8) = 0x1800e2091;
                    func_0x0001800ef2a0(arg1, 0x28, 0x180642e60);
                }
                piStack_1f8 = (int64_t *)(arg1 + 0x2f0);
                piStack_108 = (int64_t *)((*(int64_t *)(arg1 + 0x2f8) - *piStack_1f8 >> 4) * -0x5555555555555555);
                *(int64_t **)(puVar27 + 0x58) = piStack_108;
                ppiStack_100 = (int64_t **)0x0;
                piStack_110 = piStack_1f8;
                if (*(int32_t *)(arg1 + 0x80) == 0x29) {
                    puVar27[0x40] = 0;
                    piStack_1f0 = (int64_t *)0x0;
                } else {
                    puVar27[0x38] = 0;
                    *(undefined8 *)(puVar27 + 0x30) = 0;
                    *(undefined8 *)(puVar27 + 0x28) = 0;
                    *(undefined8 *)(puVar27 + 0x20) = 0;
                    *(undefined8 *)(puVar27 + -8) = 0x1800e2103;
                    ppiVar11 = (int64_t **)func_0x0001800e4340(arg1, &uStack_228, &piStack_110, 1);
                    puVar27[0x40] = *(undefined *)(ppiVar11 + 3);
                    piStack_1f0 = *ppiVar11;
                    *(int64_t **)(puVar27 + 0x58) = piStack_108;
                }
                ppiVar11 = ppiStack_100;
                piStack_1f8 = piStack_110;
                if (*(int32_t *)(arg1 + 0x80) == 0x29) {
                    *(undefined8 *)(puVar27 + -8) = 0x1800e2170;
                    func_0x0001800f0350(arg1);
                } else {
                    *(undefined8 *)(puVar27 + -8) = 0x1800e215c;
                    func_0x0001800ef5a0(arg1, 0x29, &iStack_120, 0);
                    *(undefined8 *)(puVar27 + -8) = 0x1800e2169;
                    func_0x0001800ef4e0(arg1, 0x29);
                }
                if (*(int32_t *)(arg1 + 0x80) == 0x3a) {
code_r0x0001800e21a3:
                    *(undefined8 *)(puVar27 + -8) = 0x1800e21ab;
                    func_0x0001800f0350(arg1);
                    uVar1 = *(undefined4 *)(arg1 + 0x114);
                    *(undefined8 *)(puVar27 + -8) = 0x1800e21ba;
                    ppiVar13 = (int64_t **)func_0x0001800e48f0(arg1);
                    *(int64_t ***)(puVar27 + 0x78) = ppiVar13;
                    if (*(int32_t *)(arg1 + 0x80) == 0x2c) {
                        *(undefined8 *)(puVar27 + -8) = 0x1800e21e2;
                        func_0x0001800efe70(arg1, arg1 + 0x84, 0x180643660);
                        *(undefined8 *)(puVar27 + -8) = 0x1800e21ea;
                        func_0x0001800f0350(arg1);
                        ppiVar13 = *(int64_t ***)(puVar27 + 0x78);
                    }
                    *(undefined4 *)(arg1 + 0x114) = uVar1;
                } else {
                    if (*(int32_t *)(arg1 + 0x80) == 0x107) {
                        *(undefined8 *)(puVar27 + -8) = 0x1800e21a3;
                        func_0x0001800efe70(arg1, arg1 + 0x84, 0x180643430);
                        goto code_r0x0001800e21a3;
                    }
                    *(undefined8 *)(puVar27 + 0x78) = 0;
                    ppiVar13 = ppiVar20;
                }
                if (ppiVar13 == (int64_t **)0x0) {
                    uStack_228 = (int64_t **)0x0;
                    uStack_220 = (int64_t **)0x0;
                    uStack_218 = (int64_t *)0x0;
                    uVar17 = *(undefined8 *)(arg1 + 0xd8);
                    *(undefined8 *)(puVar27 + -8) = 0x1800e221e;
                    uVar17 = func_0x0001800f11f0(uVar17, arg1 + 0x84, &uStack_228);
                    *(undefined8 *)(puVar27 + 0x78) = uVar17;
                }
                ppiVar25 = ppiStack_100;
                uStack_228 = *(int64_t ***)(arg1 + 0xa0);
                ppiVar28 = *(int64_t ***)(arg1 + 0xa8);
                piVar10 = (int64_t *)(arg1 + 0x350);
                *(int64_t **)(puVar27 + 0x70) = piVar10;
                iVar18 = *(int64_t *)(arg1 + 0x358) - *piVar10;
                iStack_280 = iVar18 >> 3;
                uStack_1b0 = (undefined4)iStack_280;
                iStack_1ac = (int32_t)(iVar18 >> 0x23);
                piStack_1a8 = (int64_t *)0x0;
                ppiVar13 = (int64_t **)(arg1 + 0x428);
                uStack_250 = (int64_t *)(*(int64_t *)(arg1 + 0x430) - (int64_t)*ppiVar13 >> 5);
                piStack_288 = uStack_250;
                ppiStack_188 = (int64_t **)0x0;
                ppiStack_248 = (int64_t **)0x0;
                ppiStack_258 = ppiVar13;
                uStack_220 = ppiVar28;
                ppiStack_1e8 = ppiVar13;
                uStack_1b8 = piVar10;
                if (ppiVar11 == (int64_t **)0x0) {
code_r0x0001800e2642:
                    auStack_150._4_4_ = uVar34;
                    auStack_150._0_4_ = uVar33;
                    auStack_150._8_4_ = uVar32;
                    auStack_150._12_4_ = uVar35;
                    uStack_198 = 0;
                    ppiStack_190 = (int64_t **)0x0;
                    uStack_208 = *(undefined8 *)(puVar27 + 0x48);
                    *(undefined8 *)(puVar27 + -8) = 0x1800e2680;
                    uStack_200 = ppiVar28;
                    ppiStack_158 = ppiVar31;
                    ppiStack_140 = (int64_t **)func_0x0001800f0170(arg1, &uStack_208, &uStack_198);
                    ppiStack_134 = (int64_t **)0x0;
                    ppiStack_12c = (int64_t **)0x0;
                    if (*ppiVar13 + (int64_t)piStack_288 * 4 != *(int64_t **)(arg1 + 0x430)) {
                        *(int64_t **)(arg1 + 0x430) = *ppiVar13 + (int64_t)piStack_288 * 4;
                    }
                    iVar18 = *piVar10 + iStack_280 * 8;
                    if (iVar18 != *(int64_t *)(arg1 + 0x358)) {
                        *(int64_t *)(arg1 + 0x358) = iVar18;
                    }
                } else {
                    iVar18 = *(int64_t *)(puVar27 + 0x58);
                    piVar30 = (int64_t *)(iVar18 * 0x30 + *piStack_1f8);
                    iVar29 = *piVar30;
                    ppiVar11 = ppiVar20;
                    if (iVar29 == 0) goto code_r0x0001800e2642;
                    do {
                        ppiVar19 = (int64_t **)((int64_t)ppiVar11 + 1);
                        if (*(char *)(iVar29 + (int64_t)ppiVar11) != *(char *)(ppiVar11 + 0x300c7940))
                        goto code_r0x0001800e2642;
                        ppiVar11 = ppiVar19;
                    } while (ppiVar19 != (int64_t **)0x5);
                    if (piVar30[3] != 0) goto code_r0x0001800e2642;
                    ppiStack_180 = (int64_t **)0x1;
                    ppiVar11 = *(int64_t ***)(puVar27 + 0x48);
                    if ((int64_t **)0x1 < ppiStack_100) {
                        ppiVar31 = (int64_t **)0x1;
                        do {
                            iVar18 = (iVar18 + (int64_t)ppiVar31) * 0x30;
                            uStack_228 = *(int64_t ***)(*piStack_1f8 + iVar18);
                            ppiVar13 = (int64_t **)(*piStack_1f8 + 8 + iVar18);
                            uStack_178 = (int64_t **)*ppiVar13;
                            uStack_220 = (int64_t **)*ppiVar13;
                            uStack_164 = *(undefined4 *)((int64_t)ppiVar13 + 0xc);
                            uStack_218 = ppiVar13[1];
                            uStack_168 = CONCAT31((unkint3)((uint32_t)*(undefined4 *)(ppiVar13 + 1) >> 8), 1);
                            *(undefined8 *)(puVar27 + -8) = 0x1800e2373;
                            ppiStack_180 = uStack_228;
                            func_0x0001800f1e20(&ppiStack_258, &ppiStack_180);
                            pppiVar24 = (int64_t ***)(*piStack_1f8 + 0x18 + iVar18);
                            if (*pppiVar24 == (int64_t **)0x0) {
                                uStack_d0 = 0;
                                uStack_c8 = 0;
                                *(undefined8 *)(puVar27 + -8) = 0x1800e23c0;
                                ppiStack_c0 = ppiVar11;
                                ppiStack_b8 = ppiVar28;
                                ppiStack_180 = (int64_t **)
                                               func_0x0001800f0170(arg1, &ppiStack_c0, &uStack_d0, 0x180643058);
                                pppiVar24 = &ppiStack_180;
                            }
                            *(undefined8 *)(puVar27 + -8) = 0x1800e23d7;
                            func_0x0001800f1a70(&uStack_1b8, pppiVar24);
                            ppiVar31 = (int64_t **)((int64_t)ppiVar31 + 1);
                            iVar18 = *(int64_t *)(puVar27 + 0x58);
                        } while (ppiVar31 < ppiVar25);
                        iStack_280 = CONCAT44(iStack_1ac, uStack_1b0);
                        *(int64_t **)(puVar27 + 0x70) = uStack_1b8;
                        ppiStack_188 = ppiStack_248;
                        piStack_288 = uStack_250;
                        ppiVar31 = uStack_1c8;
                        uVar12 = uStack_f0;
                        piVar10 = uStack_1b8;
                    }
                    piVar30 = uStack_250;
                    piStack_288 = uStack_250;
                    ppiStack_248 = ppiStack_188;
                    ppiStack_1e8 = ppiStack_258;
                    uStack_1b8 = piVar10;
                    if ((puVar27[0x40] != '\0') && (piStack_1f0 == (int64_t *)0x0)) {
                        *(undefined8 *)(puVar27 + -8) = 0x1800e2447;
                        func_0x0001800efe70(arg1, puVar27 + 0x48, 0x180643058);
                        ppiVar11 = *(int64_t ***)(puVar27 + 0x48);
                    }
                    ppiStack_180 = *(int64_t ***)(arg1 + 0xd8);
                    ppiVar13 = ppiVar20;
                    if (ppiStack_188 != (int64_t **)0x0) {
                        piVar10 = *ppiStack_1e8;
                        *(undefined8 *)(puVar27 + -8) = 0x1800e2485;
                        ppiVar13 = (int64_t **)func_0x0001800d4d20(ppiStack_180, (int64_t)ppiStack_188 << 5);
                        ppiVar25 = ppiVar20;
                        if (ppiStack_188 != (int64_t **)0x0) {
                            do {
                                piVar14 = piVar10 + (int64_t)piVar30 * 4 + (int64_t)ppiVar25 * 4;
                                uVar1 = *(undefined4 *)((int64_t)piVar14 + 4);
                                uVar5 = *(undefined4 *)(piVar14 + 1);
                                uVar6 = *(undefined4 *)((int64_t)piVar14 + 0xc);
                                ppiVar19 = ppiVar13 + (int64_t)ppiVar25 * 4;
                                *(undefined4 *)ppiVar19 = *(undefined4 *)piVar14;
                                *(undefined4 *)((int64_t)ppiVar19 + 4) = uVar1;
                                *(undefined4 *)(ppiVar19 + 1) = uVar5;
                                *(undefined4 *)((int64_t)ppiVar19 + 0xc) = uVar6;
                                piVar14 = piVar10 + (int64_t)piVar30 * 4 + (int64_t)ppiVar25 * 4 + 2;
                                uVar1 = *(undefined4 *)((int64_t)piVar14 + 4);
                                uVar5 = *(undefined4 *)(piVar14 + 1);
                                uVar6 = *(undefined4 *)((int64_t)piVar14 + 0xc);
                                ppiVar19 = ppiVar13 + (int64_t)ppiVar25 * 4 + 2;
                                *(undefined4 *)ppiVar19 = *(undefined4 *)piVar14;
                                *(undefined4 *)((int64_t)ppiVar19 + 4) = uVar1;
                                *(undefined4 *)(ppiVar19 + 1) = uVar5;
                                *(undefined4 *)((int64_t)ppiVar19 + 0xc) = uVar6;
                                ppiVar25 = (int64_t **)((int64_t)ppiVar25 + 1);
                            } while (ppiVar25 < ppiStack_188);
                        }
                    }
                    ppiVar25 = ppiVar20;
                    if (piStack_1a8 != (int64_t *)0x0) {
                        ppiVar25 = (int64_t **)(**(int64_t **)(puVar27 + 0x70) + iStack_280 * 8);
                    }
                    *(undefined8 *)(puVar27 + -8) = 0x1800e24f0;
                    func_0x0001800f1110(arg1, &uStack_228, ppiVar25);
                    piVar10 = *ppiStack_180;
                    uStack_b0 = ppiVar11;
                    uStack_a8 = ppiVar28;
                    if (piVar10 == (int64_t *)0x0) {
code_r0x0001800e253f:
                        *(undefined8 *)(puVar27 + -8) = 0x1800e2549;
                        ppiVar25 = (int64_t **)func_0x000180459890(0x2008);
                        *ppiVar25 = *ppiStack_180;
                        *ppiStack_180 = (int64_t *)ppiVar25;
                        ppiVar25 = ppiVar25 + 1;
                        piVar10 = (int64_t *)0x80;
                    } else {
                        ppiVar25 = (int64_t **)
                                   ((int64_t)ppiStack_180[1] + 7 + (int64_t)(piVar10 + 1) & 0xfffffffffffffff8);
                        if (piVar10 + 0x401 < ppiVar25 + 0x10) goto code_r0x0001800e253f;
                        piVar10 = (int64_t *)((int64_t)ppiVar25 + (0x80 - (int64_t)(piVar10 + 1)));
                    }
                    ppiStack_180[1] = piVar10;
                    *(undefined4 *)(ppiVar25 + 1) = *(undefined4 *)0x1807826ac;
                    *(undefined4 *)((int64_t)ppiVar25 + 0xc) = (undefined4)uStack_b0;
                    *(undefined4 *)(ppiVar25 + 2) = uStack_b0._4_4_;
                    *(undefined4 *)((int64_t)ppiVar25 + 0x14) = (undefined4)uStack_a8;
                    *(undefined4 *)(ppiVar25 + 3) = uStack_a8._4_4_;
                    *ppiVar25 = (int64_t *)0x180642270;
                    ppiVar25[4] = piStack_160;
                    ppiVar25[5] = *(int64_t **)(puVar27 + 0x60);
                    ppiVar25[6] = (int64_t *)0x0;
                    ppiVar25[7] = (int64_t *)0x0;
                    ppiVar25[8] = (int64_t *)0x0;
                    ppiVar25[9] = (int64_t *)0x0;
                    *(undefined4 *)(ppiVar25 + 10) = (undefined4)uStack_228;
                    *(undefined4 *)((int64_t)ppiVar25 + 0x54) = uStack_228._4_4_;
                    *(undefined4 *)(ppiVar25 + 0xb) = (undefined4)uStack_220;
                    *(undefined4 *)((int64_t)ppiVar25 + 0x5c) = uStack_220._4_4_;
                    ppiVar25[0xc] = piStack_1f0;
                    ppiVar25[0xd] = (int64_t *)ppiVar13;
                    ppiVar25[0xe] = (int64_t *)ppiStack_188;
                    ppiVar25[0xf] = *(int64_t **)(puVar27 + 0x78);
                    auStack_150._4_4_ = uVar34;
                    auStack_150._0_4_ = uVar33;
                    auStack_150._8_4_ = uVar32;
                    auStack_150._12_4_ = uVar35;
                    if (*ppiStack_1e8 + (int64_t)piStack_288 * 4 != ppiStack_1e8[1]) {
                        ppiStack_1e8[1] = *ppiStack_1e8 + (int64_t)piStack_288 * 4;
                    }
                    piVar10 = *(int64_t **)(puVar27 + 0x70);
                    iVar18 = *piVar10 + iStack_280 * 8;
                    ppiStack_158 = ppiVar31;
                    ppiStack_140 = ppiVar25;
                    ppiStack_134 = ppiVar11;
                    ppiStack_12c = ppiVar28;
                    if (iVar18 != piVar10[1]) {
                        piVar10[1] = iVar18;
                    }
                }
                uStack_138 = 1;
                if (*(int64_t *)(puVar27 + 0x58) * 0x30 + *piStack_1f8 != piStack_1f8[1]) {
                    piStack_1f8[1] = *(int64_t *)(puVar27 + 0x58) * 0x30 + *piStack_1f8;
                }
code_r0x0001800e26f1:
                uStack_124 = 3;
                *(undefined8 *)(puVar27 + -8) = 0x1800e2701;
                func_0x0001800f23a0(&piStack_1e0);
                ppiVar31 = ppiStack_278;
                goto code_r0x0001800e2acd;
            }
code_r0x0001800e2ae4:
            piVar10 = piStack_1e0;
            uStack_198 = *(undefined8 *)(arg1 + 0x84);
            ppiStack_190 = *(int64_t ***)(arg1 + 0x8c);
            *(undefined8 *)(puVar27 + -8) = 0x1800e2af8;
            func_0x0001800f0350(arg1);
            ppiVar11 = ppiStack_1d0;
            uVar17 = *(undefined8 *)(arg1 + 0xd8);
            ppiVar13 = ppiVar20;
            if (ppiStack_1d0 != (int64_t **)0x0) {
                iVar18 = iStack_1d8 * 0x38 + *piVar10;
                *(undefined8 *)(puVar27 + -8) = 0x1800e2b1c;
                ppiVar13 = (int64_t **)func_0x0001800d4d20(uVar17, (int64_t)ppiStack_1d0 * 0x38);
                if (ppiVar11 != (int64_t **)0x0) {
                    do {
                        iVar29 = (int64_t)ppiVar20 * 0x38;
                        puVar22 = (undefined4 *)(iVar29 + iVar18);
                        uVar33 = puVar22[1];
                        uVar35 = puVar22[2];
                        uVar32 = puVar22[3];
                        ppiVar28 = ppiVar13 + (int64_t)ppiVar20 * 7;
                        *(undefined4 *)ppiVar28 = *puVar22;
                        *(undefined4 *)((int64_t)ppiVar28 + 4) = uVar33;
                        *(undefined4 *)(ppiVar28 + 1) = uVar35;
                        *(undefined4 *)((int64_t)ppiVar28 + 0xc) = uVar32;
                        puVar22 = (undefined4 *)(iVar29 + 0x10 + iVar18);
                        uVar33 = puVar22[1];
                        uVar35 = puVar22[2];
                        uVar32 = puVar22[3];
                        ppiVar28 = ppiVar13 + (int64_t)ppiVar20 * 7 + 2;
                        *(undefined4 *)ppiVar28 = *puVar22;
                        *(undefined4 *)((int64_t)ppiVar28 + 4) = uVar33;
                        *(undefined4 *)(ppiVar28 + 1) = uVar35;
                        *(undefined4 *)((int64_t)ppiVar28 + 0xc) = uVar32;
                        puVar22 = (undefined4 *)(iVar29 + 0x20 + iVar18);
                        uVar33 = puVar22[1];
                        uVar35 = puVar22[2];
                        uVar32 = puVar22[3];
                        ppiVar28 = ppiVar13 + (int64_t)ppiVar20 * 7 + 4;
                        *(undefined4 *)ppiVar28 = *puVar22;
                        *(undefined4 *)((int64_t)ppiVar28 + 4) = uVar33;
                        *(undefined4 *)(ppiVar28 + 1) = uVar35;
                        *(undefined4 *)((int64_t)ppiVar28 + 0xc) = uVar32;
                        ppiVar13[(int64_t)ppiVar20 * 7 + 6] = *(int64_t **)(iVar29 + 0x30 + iVar18);
                        ppiVar20 = (int64_t **)((int64_t)ppiVar20 + 1);
                    } while (ppiVar20 < ppiVar11);
                }
            }
            uStack_208 = CONCAT44(uStack_9c, uStack_a0);
            uStack_200 = ppiStack_190;
            *(undefined8 *)(puVar27 + -8) = 0x1800e2b88;
            puVar16 = (undefined8 *)func_0x0001800d4d20(uVar17, 0x58);
            *(undefined4 *)(puVar16 + 1) = *(undefined4 *)0x1807826a4;
            *(undefined4 *)((int64_t)puVar16 + 0xc) = (undefined4)uStack_208;
            *(undefined4 *)(puVar16 + 2) = uStack_208._4_4_;
            *(undefined4 *)((int64_t)puVar16 + 0x14) = (undefined4)uStack_200;
            *(undefined4 *)(puVar16 + 3) = uStack_200._4_4_;
            *(undefined *)(puVar16 + 4) = 0;
            *puVar16 = 0x180641be0;
            puVar16[5] = CONCAT44(var_80h._4_4_, (undefined4)var_80h);
            puVar16[6] = uVar12;
            *(undefined *)(puVar16 + 7) = puVar27[0x41];
            *(undefined4 *)((int64_t)puVar16 + 0x39) = *(undefined4 *)(puVar27 + 0x51);
            *(undefined2 *)((int64_t)puVar16 + 0x3d) = *(undefined2 *)(puVar27 + 0x55);
            *(undefined *)((int64_t)puVar16 + 0x3f) = puVar27[0x57];
            puVar16[8] = ppiVar13;
            puVar16[9] = ppiVar11;
            puVar16[10] = ppiVar31;
code_r0x0001800e2be5:
            iVar18 = iStack_1d8 * 0x38 + *piVar10;
            if (iVar18 != piVar10[1]) {
                piVar10[1] = iVar18;
            }
            goto code_r0x0001800e2d92;
        }
    } else {
        puVar9 = auStack_308;
        if (*piVar15 != 299) {
            var_2e0h = func_0x0001800d62b0(piVar15, &var_80h);
            if (0xf < *(uint64_t *)(var_2e0h + 0x18)) {
                var_2e0h = *(int64_t *)var_2e0h;
            }
            stack0xfffffffffffffd40 = 0;
            _var_2b8h = 0;
            iStack_270 = 0;
            uStack_26c = 0;
            uStack_268 = 0;
            uStack_264 = 0;
            var_2e8h = 0x1806430a0;
            func_0x0001800eff80(arg1, arg1 + 0x84, &iStack_270, (int64_t)&var_2c7h + 7);
            uVar23 = CONCAT44(var_68h._4_4_, (undefined4)var_68h);
            if (0xf < uVar23) {
                uVar21 = uVar23 + 1;
                iVar29 = CONCAT44(var_80h._4_4_, (undefined4)var_80h);
                iVar18 = iVar29;
                if (0xfff < uVar21) {
                    iVar18 = *(int64_t *)(iVar29 + -8);
                    if (0x1f < (iVar29 - iVar18) - 8U) {
                        iVar18 = 5;
                        pcVar3 = (code *)swi(0x29);
                        (*pcVar3)();
                        puVar9 = auStack_300;
                        goto code_r0x0001800e14df;
                    }
                    uVar21 = uVar23 + 0x28;
                }
                func_0x000180459c3c(iVar18, uVar21);
            }
            goto code_r0x0001800e2d92;
        }
    }
    puVar27 = puVar9;
    *(undefined8 *)(puVar27 + -8) = 0x1800e14f0;
    func_0x0001800f0350();
    if (*piVar15 == 0x119) {
        ppiStack_258 = *(int64_t ***)(arg1 + 0x98);
        uStack_250._0_4_ = *(undefined4 *)(arg1 + 0x84);
        uStack_250._4_4_ = *(undefined4 *)(arg1 + 0x88);
        ppiStack_248 = (int64_t **)(arg1 + 0x8c);
        uVar33 = *(undefined4 *)ppiStack_248;
        uVar35 = *(undefined4 *)(arg1 + 0x90);
        ppiVar31 = (int64_t **)*ppiStack_248;
        ppiStack_248 = (int64_t **)*ppiStack_248;
        *(undefined8 *)(puVar27 + -8) = 0x1800e1548;
        func_0x0001800f0350(arg1);
        ppiVar20 = ppiStack_258;
        uVar32 = (undefined4)uStack_250;
        uVar34 = uStack_250._4_4_;
        ppiStack_248 = ppiVar31;
    } else {
        *(undefined8 *)(puVar27 + -8) = 0x1800e1507;
        func_0x0001800efe90(arg1, 0x1806430f0);
        uVar33 = *(undefined4 *)(arg1 + 0x88);
        uVar35 = *(undefined4 *)(arg1 + 0x8c);
        uVar32 = *(undefined4 *)(arg1 + 0x90);
        *(undefined4 *)(puVar27 + 0x48) = *(undefined4 *)(arg1 + 0x84);
        *(undefined4 *)(puVar27 + 0x4c) = uVar33;
        *(undefined4 *)(puVar27 + 0x50) = uVar35;
        *(undefined4 *)(puVar27 + 0x54) = uVar32;
        *(undefined8 *)(puVar27 + 0x50) = *(undefined8 *)(puVar27 + 0x48);
        uVar33 = *(undefined4 *)(puVar27 + 0x50);
        uVar35 = *(undefined4 *)(puVar27 + 0x54);
        ppiVar20 = *(int64_t ***)(arg1 + 0x128);
        uVar32 = *(undefined4 *)(puVar27 + 0x48);
        uVar34 = *(undefined4 *)(puVar27 + 0x4c);
    }
    ppiVar31 = (int64_t **)0x0;
    *(undefined8 *)(puVar27 + 0x28) = 0;
    *(undefined8 *)(puVar27 + 0x20) = 0;
    *(undefined8 *)(puVar27 + -8) = 0x1800e1586;
    func_0x0001800ecbd0(arg1, &var_80h, 0, 0);
    iVar26 = *piVar15;
    *(int32_t *)(puVar27 + 0x60) = iVar26;
    *(undefined8 *)(puVar27 + 100) = *(undefined8 *)(arg1 + 0x84);
    if (iVar26 == 0x28) {
        *(undefined8 *)(puVar27 + -8) = 0x1800e15b5;
        func_0x0001800f0350(arg1);
    } else {
        *(undefined8 *)(puVar27 + -8) = 0x1800e15ae;
        func_0x0001800ef2a0(arg1, 0x28, 0x180643108);
    }
    piStack_110 = (int64_t *)(arg1 + 0x2f0);
    *(int64_t **)(puVar27 + 0x78) = piStack_110;
    piStack_288 = (int64_t *)((*(int64_t *)(arg1 + 0x2f8) - *piStack_110 >> 4) * -0x5555555555555555);
    ppiStack_100 = (int64_t **)0x0;
    uStack_1c8 = (int64_t **)0x0;
    uStack_1c0 = 0;
    piStack_108 = piStack_288;
    if (*piVar15 == 0x29) {
        puVar27[0x40] = 0;
        iStack_280 = 0;
    } else {
        puVar27[0x38] = 0;
        *(undefined8 *)(puVar27 + 0x30) = 0;
        *(undefined8 *)(puVar27 + 0x28) = 0;
        *(undefined8 *)(puVar27 + 0x20) = 0;
        *(undefined8 *)(puVar27 + -8) = 0x1800e162c;
        piVar10 = (int64_t *)func_0x0001800e4340(arg1, &ppiStack_258, &piStack_110, 1);
        puVar27[0x40] = *(undefined *)(piVar10 + 3);
        uStack_1c8 = (int64_t **)piVar10[1];
        uStack_1c0 = piVar10[2];
        iStack_280 = *piVar10;
        piStack_288 = piStack_108;
        *(int64_t **)(puVar27 + 0x78) = piStack_110;
    }
    piVar10 = piStack_110;
    if (*piVar15 == 0x29) {
        *(undefined8 *)(puVar27 + -8) = 0x1800e1693;
        func_0x0001800f0350(arg1);
    } else {
        *(undefined8 *)(puVar27 + -8) = 0x1800e167f;
        func_0x0001800ef5a0(arg1, 0x29, puVar27 + 0x60, 0);
        *(undefined8 *)(puVar27 + -8) = 0x1800e168c;
        func_0x0001800ef4e0(arg1, 0x29);
    }
    if (*piVar15 == 0x3a) {
code_r0x0001800e16c1:
        *(undefined8 *)(puVar27 + -8) = 0x1800e16c9;
        func_0x0001800f0350(arg1);
        uVar1 = *(undefined4 *)(arg1 + 0x114);
        *(undefined8 *)(puVar27 + -8) = 0x1800e16d8;
        ppiVar11 = (int64_t **)func_0x0001800e48f0(arg1);
        *(int64_t ***)(puVar27 + 0x58) = ppiVar11;
        if (*piVar15 == 0x2c) {
            *(undefined8 *)(puVar27 + -8) = 0x1800e16fb;
            func_0x0001800efe70(arg1, arg1 + 0x84, 0x180643660);
            *(undefined8 *)(puVar27 + -8) = 0x1800e1703;
            func_0x0001800f0350(arg1);
            ppiVar11 = *(int64_t ***)(puVar27 + 0x58);
        }
        *(undefined4 *)(arg1 + 0x114) = uVar1;
    } else {
        if (*piVar15 == 0x107) {
            *(undefined8 *)(puVar27 + -8) = 0x1800e16c1;
            func_0x0001800efe70(arg1, arg1 + 0x84, 0x180643430);
            goto code_r0x0001800e16c1;
        }
        *(undefined8 *)(puVar27 + 0x58) = 0;
        ppiVar11 = ppiVar31;
    }
    if (ppiVar11 == (int64_t **)0x0) {
        ppiStack_258 = (int64_t **)0x0;
        uStack_250 = (int64_t *)0x0;
        ppiStack_248 = (int64_t **)0x0;
        uVar12 = *(undefined8 *)(arg1 + 0xd8);
        *(undefined8 *)(puVar27 + -8) = 0x1800e1737;
        uVar12 = func_0x0001800f11f0(uVar12, arg1 + 0x84, &ppiStack_258);
        *(undefined8 *)(puVar27 + 0x58) = uVar12;
    }
    uVar1 = *(undefined4 *)(arg1 + 0x88);
    uVar5 = *(undefined4 *)(arg1 + 0x8c);
    uVar6 = *(undefined4 *)(arg1 + 0x90);
    *(undefined4 *)(puVar27 + 0x48) = *(undefined4 *)(arg1 + 0x84);
    *(undefined4 *)(puVar27 + 0x4c) = uVar1;
    *(undefined4 *)(puVar27 + 0x50) = uVar5;
    *(undefined4 *)(puVar27 + 0x54) = uVar6;
    piStack_1e0 = (int64_t *)(arg1 + 0x350);
    iStack_1d8 = *(int64_t *)(arg1 + 0x358) - *piStack_1e0 >> 3;
    *(int64_t *)(puVar27 + 0x60) = iStack_1d8;
    ppiStack_1d0 = (int64_t **)0x0;
    ppiVar11 = (int64_t **)(arg1 + 0x3e0);
    iVar18 = *(int64_t *)(arg1 + 1000) - (int64_t)*ppiVar11;
    iVar18 = iVar18 / 6 + (iVar18 >> 0x3f);
    uStack_250 = (int64_t *)((iVar18 >> 2) - (iVar18 >> 0x3f));
    ppiStack_248 = (int64_t **)0x0;
    *(undefined8 *)(puVar27 + 0x70) = 0;
    ppiVar13 = ppiVar31;
    ppiStack_258 = ppiVar11;
    piStack_1f0 = uStack_250;
    if (ppiStack_100 == (int64_t **)0x0) {
        ppiVar28 = ppiVar31;
        iVar18 = *(int64_t *)(puVar27 + 0x60);
code_r0x0001800e1a7f:
        piVar10 = piStack_1e0;
        if ((puVar27[0x40] == '\0') || (iStack_280 != 0)) {
            uVar12 = *(undefined8 *)(arg1 + 0xd8);
            *(undefined8 *)(puVar27 + 0x60) = uVar12;
            if (ppiVar28 == (int64_t **)0x0) {
                *(undefined8 *)(puVar27 + 0x70) = 0;
                ppiStack_1e8 = ppiVar31;
            } else {
                *(int64_t *)(puVar27 + 0x70) = (int64_t)*ppiVar11 + (int64_t)piStack_1f0 * 0x18;
                *(undefined8 *)(puVar27 + -8) = 0x1800e1b22;
                ppiStack_1e8 = (int64_t **)func_0x0001800d4d20(uVar12, (int64_t)ppiVar28 * 0x18);
                iVar29 = *(int64_t *)(puVar27 + 0x70);
                ppiVar13 = ppiVar31;
                do {
                    puVar22 = (undefined4 *)(iVar29 + (int64_t)ppiVar13 * 0x18);
                    uVar1 = puVar22[1];
                    uVar5 = puVar22[2];
                    uVar6 = puVar22[3];
                    ppiVar25 = ppiStack_1e8 + (int64_t)ppiVar13 * 3;
                    *(undefined4 *)ppiVar25 = *puVar22;
                    *(undefined4 *)((int64_t)ppiVar25 + 4) = uVar1;
                    *(undefined4 *)(ppiVar25 + 1) = uVar5;
                    *(undefined4 *)((int64_t)ppiVar25 + 0xc) = uVar6;
                    ppiStack_1e8[(int64_t)ppiVar13 * 3 + 2] = *(int64_t **)(iVar29 + 0x10 + (int64_t)ppiVar13 * 0x18);
                    ppiVar13 = (int64_t **)((int64_t)ppiVar13 + 1);
                } while (ppiVar13 < ppiVar28);
            }
            if (ppiStack_1d0 != (int64_t **)0x0) {
                ppiVar31 = (int64_t **)(*piVar10 + iVar18 * 8);
            }
            *(undefined8 *)(puVar27 + -8) = 0x1800e1b81;
            func_0x0001800f1110(arg1, &uStack_1b8, ppiVar31);
            iStack_270 = (int32_t)*ppiStack_278;
            uStack_26c = (undefined4)((uint64_t)*ppiStack_278 >> 0x20);
            uStack_268 = (undefined4)*(undefined8 *)(puVar27 + 0x50);
            uStack_264 = (undefined4)((uint64_t)*(undefined8 *)(puVar27 + 0x50) >> 0x20);
            ppiVar31 = *(int64_t ***)(puVar27 + 0x60);
            iVar29 = (int64_t)*ppiVar31;
            if (iVar29 == 0) {
code_r0x0001800e1bd6:
                *(undefined8 *)(puVar27 + -8) = 0x1800e1be0;
                piVar30 = (int64_t *)func_0x000180459890(0x2008);
                *piVar30 = (int64_t)*ppiVar31;
                *ppiVar31 = piVar30;
                piVar30 = piVar30 + 1;
                piVar14 = (int64_t *)0xb8;
            } else {
                piVar30 = (int64_t *)((int64_t)ppiVar31[1] + iVar29 + 0xf & 0xfffffffffffffff8);
                if ((int64_t *)(iVar29 + 0x2008) < piVar30 + 0x17) goto code_r0x0001800e1bd6;
                piVar14 = (int64_t *)((int64_t)piVar30 + (0xb8 - (iVar29 + 8)));
            }
            ppiVar31[1] = piVar14;
            *(undefined4 *)(piVar30 + 1) = *(undefined4 *)0x1807826a8;
            *(int32_t *)((int64_t)piVar30 + 0xc) = iStack_270;
            *(undefined4 *)(piVar30 + 2) = uStack_26c;
            *(undefined4 *)((int64_t)piVar30 + 0x14) = uStack_268;
            *(undefined4 *)(piVar30 + 3) = uStack_264;
            *(undefined *)(piVar30 + 4) = 0;
            *piVar30 = 0x1806421d0;
            uVar1 = *(undefined4 *)((int64_t)ppiStack_180 + 4);
            uVar5 = *(undefined4 *)(ppiStack_180 + 1);
            uVar6 = *(undefined4 *)((int64_t)ppiStack_180 + 0xc);
            *(undefined4 *)(piVar30 + 5) = *(undefined4 *)ppiStack_180;
            *(undefined4 *)((int64_t)piVar30 + 0x2c) = uVar1;
            *(undefined4 *)(piVar30 + 6) = uVar5;
            *(undefined4 *)((int64_t)piVar30 + 0x34) = uVar6;
            piVar30[7] = (int64_t)ppiVar20;
            auVar4._4_4_ = uVar34;
            auVar4._0_4_ = uVar32;
            auVar4._8_4_ = uVar33;
            auVar4._12_4_ = uVar35;
            *(undefined (*) [16])(piVar30 + 8) = auVar4;
            *(undefined4 *)(piVar30 + 10) = (undefined4)var_80h;
            *(undefined4 *)((int64_t)piVar30 + 0x54) = var_80h._4_4_;
            *(undefined4 *)(piVar30 + 0xb) = (undefined4)var_78h;
            *(undefined4 *)((int64_t)piVar30 + 0x5c) = var_78h._4_4_;
            *(undefined4 *)(piVar30 + 0xc) = (undefined4)var_70h;
            *(undefined4 *)((int64_t)piVar30 + 100) = var_70h._4_4_;
            *(undefined4 *)(piVar30 + 0xd) = (undefined4)var_68h;
            *(undefined4 *)((int64_t)piVar30 + 0x6c) = var_68h._4_4_;
            *(int32_t *)(piVar30 + 0xe) = (int32_t)uStack_1b8;
            *(undefined4 *)((int64_t)piVar30 + 0x74) = uStack_1b8._4_4_;
            *(undefined4 *)(piVar30 + 0xf) = uStack_1b0;
            *(int32_t *)((int64_t)piVar30 + 0x7c) = iStack_1ac;
            piVar30[0x10] = iStack_280;
            piVar30[0x11] = (int64_t)ppiStack_1e8;
            piVar30[0x12] = (int64_t)ppiVar28;
            *(undefined *)(piVar30 + 0x13) = puVar27[0x40];
            *(undefined4 *)((int64_t)piVar30 + 0x9c) = (undefined4)uStack_1c8;
            *(undefined4 *)(piVar30 + 0x14) = uStack_1c8._4_4_;
            *(undefined4 *)((int64_t)piVar30 + 0xa4) = (undefined4)uStack_1c0;
            *(undefined4 *)(piVar30 + 0x15) = uStack_1c0._4_4_;
            piVar30[0x16] = *(int64_t *)(puVar27 + 0x58);
        } else {
            iStack_270 = 0;
            uStack_26c = 0;
            uStack_268 = 0;
            uStack_264 = 0;
            iStack_120 = 0;
            uStack_11c = 0;
            uStack_118 = 0;
            uStack_114 = 0;
            *(int64_t **)(puVar27 + 0x60) = *ppiStack_278;
            *(undefined8 *)(puVar27 + 0x68) = *(undefined8 *)(puVar27 + 0x50);
            *(undefined8 *)(puVar27 + 0x20) = 0x180642fd8;
            *(undefined8 *)(puVar27 + -8) = 0x1800e1add;
            func_0x0001800eff80(arg1, puVar27 + 0x60, &iStack_120, &iStack_270);
        }
    } else {
        while (ppiVar28 = (int64_t **)(((int64_t)ppiVar13 + (int64_t)piStack_288) * 0x30),
              *(int64_t *)(*piVar10 + 0x18 + (int64_t)ppiVar28) != 0) {
            *(undefined8 *)(puVar27 + -8) = 0x1800e17ea;
            func_0x0001800f1a70(&piStack_1e0);
            uVar12 = *(undefined8 *)(*piVar10 + (int64_t)ppiVar28);
            uStack_1b8._0_4_ = (int32_t)uVar12;
            uStack_1b8._4_4_ = (undefined4)((uint64_t)uVar12 >> 0x20);
            puVar16 = (undefined8 *)(*piVar10 + 8 + (int64_t)ppiVar28);
            uVar12 = *puVar16;
            piVar10 = (int64_t *)puVar16[1];
            uStack_1b0 = (undefined4)uVar12;
            iStack_1ac = (int32_t)((uint64_t)uVar12 >> 0x20);
            puVar22 = *(undefined4 **)(arg1 + 1000);
            piStack_1a8 = piVar10;
            if (puVar22 == *(undefined4 **)(arg1 + 0x3f0)) {
                iVar18 = (int64_t)puVar22 - (int64_t)*ppiVar11;
                iVar18 = iVar18 / 6 + (iVar18 >> 0x3f);
                iVar18 = (iVar18 >> 2) - (iVar18 >> 0x3f);
                if (iVar18 == 0xaaaaaaaaaaaaaaa) {
                    *(undefined8 *)(puVar27 + -8) = 0x1800e2dcb;
                    func_0x000180010010();
code_r0x0001800e2dcc:
                    *(undefined8 *)(puVar27 + -8) = 0x1800e2dd1;
                    func_0x000180004720();
                    pcVar3 = (code *)swi(3);
                    (*pcVar3)();
                    return;
                }
                uVar23 = ((int64_t)*(undefined4 **)(arg1 + 0x3f0) - (int64_t)*ppiVar11) / 0x18;
                if (0xaaaaaaaaaaaaaaa - (uVar23 >> 1) < uVar23) goto code_r0x0001800e2dcc;
                uVar23 = (uVar23 >> 1) + uVar23;
                uVar21 = iVar18 + 1U;
                if (iVar18 + 1U <= uVar23) {
                    uVar21 = uVar23;
                }
                if (0xaaaaaaaaaaaaaaa < uVar21) goto code_r0x0001800e2dcc;
                piStack_160 = (int64_t *)(uVar21 * 0x18);
                ppiVar13 = ppiVar31;
                if (piStack_160 != (int64_t *)0x0) {
                    if (piStack_160 < (int64_t *)0x1000) {
                        *(undefined8 *)(puVar27 + -8) = 0x1800e1904;
                        ppiVar13 = (int64_t **)func_0x000180459890(piStack_160);
                        goto code_r0x0001800e1907;
                    }
                    if ((int64_t *)((int64_t)piStack_160 + 0x27U) <= piStack_160) goto code_r0x0001800e2dcc;
                    *(undefined8 *)(puVar27 + -8) = 0x1800e18e5;
                    piVar30 = (int64_t *)func_0x000180459890();
                    if (piVar30 != (int64_t *)0x0) {
                        ppiVar13 = (int64_t **)((int64_t)piVar30 + 0x27U & 0xffffffffffffffe0);
                        ppiVar13[-1] = piVar30;
                        goto code_r0x0001800e1907;
                    }
code_r0x0001800e1a05:
                    pcVar3 = (code *)swi(0x29);
                    (*pcVar3)(5);
                    puVar27 = puVar27 + 8;
                    iVar18 = iStack_1d8;
                    goto code_r0x0001800e1a7f;
                }
code_r0x0001800e1907:
                ppiVar28 = ppiVar13 + iVar18 * 3;
                *(int64_t ***)(puVar27 + 0x60) = ppiVar28;
                *(int32_t *)ppiVar28 = (int32_t)uStack_1b8;
                *(undefined4 *)((int64_t)ppiVar28 + 4) = uStack_1b8._4_4_;
                *(undefined4 *)(ppiVar28 + 1) = uStack_1b0;
                *(int32_t *)((int64_t)ppiVar28 + 0xc) = iStack_1ac;
                ppiVar28[2] = piVar10;
                puVar2 = (undefined4 *)*ppiVar11;
                if (puVar22 == *(undefined4 **)(arg1 + 1000)) {
                    iVar29 = (int64_t)*(undefined4 **)(arg1 + 1000) - (int64_t)puVar2;
                    ppiVar28 = ppiVar13;
                    puVar22 = puVar2;
                } else {
                    *(undefined8 *)(puVar27 + -8) = 0x1800e1943;
                    func_0x000180498030(ppiVar13, puVar2, (int64_t)puVar22 - (int64_t)puVar2);
                    iVar29 = *(int64_t *)(arg1 + 1000) - (int64_t)puVar22;
                    ppiVar28 = (int64_t **)(*(int64_t *)(puVar27 + 0x60) + 0x18);
                }
                *(undefined8 *)(puVar27 + -8) = 0x1800e195b;
                func_0x000180498030(ppiVar28, puVar22, iVar29);
                iVar29 = (int64_t)*ppiVar11;
                if (iVar29 != 0) {
                    uVar23 = ((*(int64_t *)(arg1 + 0x3f0) - iVar29) / 0x18) * 0x18;
                    if (0xfff < uVar23) {
                        ppiVar28 = ppiVar13;
                        if (0x1f < (iVar29 - *(int64_t *)(iVar29 + -8)) - 8U) goto code_r0x0001800e1a05;
                        uVar23 = uVar23 + 0x27;
                        iVar29 = *(int64_t *)(iVar29 + -8);
                    }
                    *(undefined8 *)(puVar27 + -8) = 0x1800e19b9;
                    func_0x000180459c3c(iVar29, uVar23);
                }
                *ppiVar11 = (int64_t *)ppiVar13;
                *(int64_t ***)(arg1 + 1000) = ppiVar13 + (iVar18 + 1) * 3;
                *(int64_t *)(arg1 + 0x3f0) = (int64_t)piStack_160 + (int64_t)ppiVar13;
            } else {
                *puVar22 = (int32_t)uStack_1b8;
                puVar22[1] = uStack_1b8._4_4_;
                puVar22[2] = uStack_1b0;
                puVar22[3] = iStack_1ac;
                *(int64_t **)(puVar22 + 4) = piVar10;
                *(int64_t *)(arg1 + 1000) = *(int64_t *)(arg1 + 1000) + 0x18;
            }
            ppiVar28 = (int64_t **)((int64_t)ppiStack_248 + 1);
            ppiVar13 = (int64_t **)(*(int64_t *)(puVar27 + 0x70) + 1);
            *(int64_t ***)(puVar27 + 0x70) = ppiVar13;
            iVar18 = iStack_1d8;
            ppiStack_248 = ppiVar28;
            if (ppiStack_100 <= ppiVar13) goto code_r0x0001800e1a7f;
            piVar10 = *(int64_t **)(puVar27 + 0x78);
        }
        iStack_270 = 0;
        uStack_26c = 0;
        uStack_268 = 0;
        uStack_264 = 0;
        iStack_120 = 0;
        uStack_11c = 0;
        uStack_118 = 0;
        uStack_114 = 0;
        *(int64_t **)(puVar27 + 0x60) = *ppiStack_278;
        *(undefined8 *)(puVar27 + 0x68) = *(undefined8 *)(puVar27 + 0x50);
        *(undefined8 *)(puVar27 + 0x20) = 0x180642fd8;
        *(undefined8 *)(puVar27 + -8) = 0x1800e1a6a;
        func_0x0001800eff80(arg1, puVar27 + 0x60, &iStack_120, &iStack_270);
        iVar18 = iStack_1d8;
        piVar10 = piStack_1e0;
    }
    iVar29 = (int64_t)*ppiVar11 + (int64_t)piStack_1f0 * 0x18;
    if (iVar29 != *(int64_t *)(arg1 + 1000)) {
        *(int64_t *)(arg1 + 1000) = iVar29;
    }
    iVar18 = *piVar10 + iVar18 * 8;
    if (iVar18 != piVar10[1]) {
        piVar10[1] = iVar18;
    }
    piVar10 = *(int64_t **)(puVar27 + 0x78);
    iVar18 = (int64_t)piStack_288 * 0x30 + *piVar10;
    if (iVar18 != piVar10[1]) {
        piVar10[1] = iVar18;
    }
code_r0x0001800e2d92:
    *(undefined8 *)(puVar27 + -8) = 0x1800e2da1;
    func_0x000180459870(var_60h ^ (uint64_t)puVar27);
    return;
code_r0x0001800e29e0:
    do {
        ppiVar11 = (int64_t **)((int64_t)ppiVar13 + 1);
        if (*(char *)(iVar18 + (int64_t)ppiVar13) != *(char *)((int64_t)ppiVar13 + 0x18064333c))
        goto code_r0x0001800e29fb;
        ppiVar13 = ppiVar11;
    } while (ppiVar11 != (int64_t **)0x6);
    uVar33 = 2;
code_r0x0001800e2a11:
    *(undefined8 *)(puVar27 + -8) = 0x1800e2a1a;
    func_0x0001800d7020(arg1 + 0x60);
code_r0x0001800e2a1a:
    uStack_228 = *(int64_t ***)*(undefined (*) [16])(arg1 + 0x84);
    auVar4 = *(undefined (*) [16])(arg1 + 0x84);
    uStack_220 = *(int64_t ***)(arg1 + 0x8c);
    if (*(int32_t *)(arg1 + 0x80) != 0x119) {
        *(undefined8 *)(puVar27 + -8) = 0x1800e2c0b;
        func_0x0001800efe90(arg1, 0x180643380);
        goto code_r0x0001800e2ae4;
    }
    ppiVar11 = *(int64_t ***)(arg1 + 0x98);
    *(undefined8 *)(puVar27 + -8) = 0x1800e2a49;
    func_0x0001800f0350();
    if (*(int32_t *)(arg1 + 0x80) == 0x3a) {
        *(undefined8 *)(puVar27 + -8) = 0x1800e2a6e;
        func_0x0001800f0350(arg1);
    } else {
        *(undefined8 *)(puVar27 + -8) = 0x1800e2a67;
        func_0x0001800ef2a0(arg1, 0x3a, 0x180643128);
    }
    *(undefined8 *)(puVar27 + -8) = 0x1800e2a78;
    ppiStack_140 = (int64_t **)func_0x0001800e8150(arg1, 0);
    uStack_138 = 0;
    ppiStack_134 = uStack_228;
    ppiStack_12c = *(int64_t ***)(arg1 + 0xa8);
    *(undefined8 *)(puVar27 + -8) = 0x1800e2ac3;
    ppiStack_158 = ppiVar11;
    auStack_150 = auVar4;
    uStack_124 = uVar33;
    func_0x0001800f23a0(&piStack_1e0);
code_r0x0001800e2acd:
    iVar26 = *(int32_t *)(arg1 + 0x80);
    if (iVar26 == 0x128) goto code_r0x0001800e2ae4;
    goto code_r0x0001800e1f60;
}

// ============================================================
// Function: FUN_1800e2de0
// Address: 0x1800e2de0
// Size: 204 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800e2de0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    undefined auStack_18 [16];
    
    var_18h = arg2;
    if (*(char *)0x180778460 != '\0') {
        if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782728) {
            iVar1 = 0;
            if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782728) {
                iVar1 = arg2;
            }
            if (*(char *)(*(int64_t **)(iVar1 + 0x20) + 6) != '\0') {
                iVar1 = **(int64_t **)(iVar1 + 0x20);
                fcn.1800f1110(arg1, auStack_18, &var_18h, 1);
                fcn.1800f0080(iVar1);
                return;
            }
        }
    }
    fcn.1800f1110(arg1, auStack_18, &var_18h, 1);
    fcn.1800f0080(var_28h);
    return;
}

// ============================================================
// Function: FUN_1800e2eb0
// Address: 0x1800e2eb0
// Size: 1059 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_a8h
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_90h
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_80h
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_250h
// WARNING: [rz-ghidra] Detected overlap for variable var_258h
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable arg_61h
// WARNING: [rz-ghidra] Detected overlap for variable var_23h
// WARNING: [rz-ghidra] Detected overlap for variable arg_63h
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Detected overlap for variable arg_89h
// WARNING: [rz-ghidra] Detected overlap for variable arg_8bh

void fcn.1800e2eb0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int32_t iVar1;
    code *pcVar2;
    char cVar3;
    uint64_t arg_98h;
    undefined8 *puVar4;
    int32_t *piVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    undefined8 unaff_RBX;
    int64_t iVar11;
    undefined *puVar12;
    undefined *puVar13;
    int64_t unaff_RBP;
    undefined8 unaff_RSI;
    int64_t unaff_RDI;
    int64_t unaff_R14;
    int64_t unaff_R15;
    bool bVar14;
    int64_t unaff_retaddr;
    int64_t in_stack_00000008;
    int64_t in_stack_00000010;
    int64_t var_18h;
    int64_t in_stack_00000020;
    undefined8 in_stack_00000028;
    int64_t in_stack_00000030;
    undefined8 in_stack_00000038;
    int64_t in_stack_00000040;
    undefined8 in_stack_00000048;
    int64_t in_stack_00000050;
    int64_t in_stack_00000058;
    undefined auStack_c8 [8];
    undefined auStack_c0 [24];
    int64_t var_a8h;
    int64_t in_stack_ffffffffffffff60;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t in_stack_ffffffffffffff90;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 in_stack_ffffffffffffffb0;
    undefined4 in_stack_ffffffffffffffb4;
    int64_t in_stack_ffffffffffffffb8;
    int64_t var_40h;
    int64_t var_38h;
    undefined8 in_stack_ffffffffffffffd0;
    
    puVar12 = auStack_c8;
    arg_98h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_c8;
    iVar11 = 0;
    puVar4 = (undefined8 *)arg4;
    if ((*(int64_t *)(arg1 + 0x150) - *(int64_t *)(arg1 + 0x148) != 8) || (*(int32_t *)(arg1 + 0x114) != 1)) {
        func_0x0001800efe70(arg1, arg2, 0x18063f768);
    }
    if (*(char *)(arg1 + 0x228) != '\0') {
        func_0x0001800efe70(arg1, arg2, 0x180642b80);
    }
    var_80h = (int64_t)&var_88h;
    var_88h = arg1;
    var_78h = arg1;
    if ((*(int64_t *)(arg4 + 8) == 0) || (*(int32_t *)(arg1 + 0x80) == 299)) {
code_r0x0001800e2fb3:
        iVar1 = *(int32_t *)(arg1 + 0x80);
        if (iVar1 != 0x12e) {
            if (iVar1 == 299) {
                var_58h._0_4_ = *(undefined4 *)arg2;
                var_58h._4_4_ = *(undefined4 *)(arg2 + 4);
                var_a8h = CONCAT71(var_a8h._1_7_, 1);
                iVar7 = fcn.1800df760(arg1, (int64_t)&var_58h, arg3, arg4, var_a8h);
                bVar14 = *(int32_t *)(iVar7 + 8) == *(int32_t *)0x1807826c4;
                puVar13 = auStack_c8;
                if (bVar14) {
                    if (bVar14) {
                        iVar11 = iVar7;
                    }
                    cVar3 = func_0x0001800e32e0(&var_88h, **(undefined8 **)(iVar11 + 0x28), 
                                                *(undefined8 **)(iVar11 + 0x28) + 1);
                    if (cVar3 == '\0') {
                        func_0x0001800efe70(arg1, *(undefined8 **)(iVar11 + 0x28) + 1, 0x180643478, 
                                            **(undefined8 **)(iVar11 + 0x28));
                    }
                    *(undefined *)(*(int64_t *)(iVar11 + 0x28) + 0x31) = 1;
                    *(undefined *)(*(int64_t *)(iVar11 + 0x28) + 0x30) = 1;
                    puVar13 = auStack_c8;
                }
            } else if ((iVar1 == 0x119) && (*(int64_t *)(arg1 + 0x98) != 0)) {
                puVar4 = (undefined8 *)0x1806428f0;
                iVar7 = iVar11;
                do {
                    iVar8 = iVar7 + 1;
                    if (*(char *)(*(int64_t *)(arg1 + 0x98) + iVar7) != *(char *)(iVar7 + 0x1806428f0))
                    goto code_r0x0001800e31c1;
                    iVar7 = iVar8;
                } while (iVar8 != 6);
                var_68h = *(int64_t *)(arg1 + 0x84);
                var_60h = *(int64_t *)(arg1 + 0x8c);
                func_0x0001800f0350(arg1);
                if (*(int32_t *)(arg1 + 0x80) == 299) {
                    func_0x0001800efe70(arg1, arg2, 0x180643540);
                    var_98h = 0;
                    var_90h = 0;
                    var_58h._0_4_ = *(undefined4 *)arg2;
                    var_58h._4_4_ = *(undefined4 *)(arg2 + 4);
                    var_a8h = CONCAT71(var_a8h._1_7_, 1);
                    fcn.1800df760(arg1, (int64_t)&var_58h, var_68h, (int64_t)&var_98h, var_a8h);
                    puVar13 = auStack_c8;
                } else {
                    var_98h = 0;
                    var_90h = 0;
                    var_58h._0_4_ = *(undefined4 *)arg2;
                    var_58h._4_4_ = *(undefined4 *)(arg2 + 4);
                    var_a8h = CONCAT71(var_a8h._1_7_, 1);
                    uVar6 = fcn.1800df760(arg1, (int64_t)&var_58h, var_68h, (int64_t)&var_98h, var_a8h);
                    func_0x0001800e35a0(&var_80h, uVar6, &var_68h);
                    puVar13 = auStack_c8;
                }
            } else {
code_r0x0001800e31c1:
                if (((*(char *)0x180778560 == '\0') || (iVar1 != 0x119)) ||
                   (iVar7 = *(int64_t *)(arg1 + 0x98), iVar8 = iVar11, iVar7 == 0)) {
code_r0x0001800e3281:
                    var_98h = 0;
                    var_90h = 0;
                    var_80h = 0;
                    var_78h = 0;
                    var_a8h = 0x180643540;
                    func_0x0001800eff80(arg1, arg2, &var_80h, &var_98h);
                    puVar13 = auStack_c8;
                } else {
                    do {
                        iVar9 = iVar8 + 1;
                        if (*(char *)(iVar7 + iVar8) != *(char *)(iVar8 + 0x18063e198)) goto code_r0x0001800e3281;
                        iVar8 = iVar9;
                    } while (iVar9 != 6);
                    func_0x0001800f0350(arg1);
                    iVar7 = fcn.1800e0670(arg1, arg2, CONCAT71((unkint7)((uint64_t)iVar7 >> 8), 1), puVar4, var_a8h, 
                                          in_stack_ffffffffffffff60, var_98h, var_90h, var_88h, var_80h, var_78h, 
                                          in_stack_ffffffffffffff90, var_68h, var_60h, 
                                          CONCAT44(var_58h._4_4_, (undefined4)var_58h), 
                                          CONCAT44(in_stack_ffffffffffffffb4, in_stack_ffffffffffffffb0), 
                                          in_stack_ffffffffffffffb8, var_40h, arg_98h, in_stack_ffffffffffffffd0, 
                                          unaff_R15, unaff_R14, unaff_RDI, unaff_RSI, unaff_RBP, unaff_retaddr, 
                                          in_stack_00000008, in_stack_00000010, unaff_RBX, in_stack_00000020, 
                                          in_stack_00000028, in_stack_00000030, in_stack_00000038, in_stack_00000040, 
                                          in_stack_00000048, in_stack_00000050, in_stack_00000058);
                    if (*(int32_t *)(iVar7 + 8) == *(int32_t *)0x180782788) {
                        iVar11 = iVar7;
                    }
                    puVar13 = auStack_c8;
                    if (iVar11 != 0) {
                        cVar3 = func_0x0001800e32e0(&var_88h, **(undefined8 **)(iVar11 + 0x28), 
                                                    *(undefined8 **)(iVar11 + 0x28) + 1);
                        if (cVar3 == '\0') {
                            func_0x0001800efe70(arg1, *(undefined8 **)(iVar11 + 0x28) + 1, 0x1806433a8, 
                                                **(undefined8 **)(iVar11 + 0x28));
                        }
                        *(undefined *)(*(int64_t *)(iVar11 + 0x28) + 0x31) = 1;
                        puVar13 = auStack_c8;
                    }
                }
            }
            goto code_r0x0001800e32b0;
        }
        var_98h = *(int64_t *)(arg1 + 0x84);
        var_90h = *(int64_t *)(arg1 + 0x8c);
        piVar5 = (int32_t *)func_0x0001800d70e0(arg1 + 0x60, &var_58h);
        if (*piVar5 == 299) {
            func_0x0001800efe70(arg1, arg2, 0x1806434f0);
            var_80h = 0;
            var_78h = 0;
            var_68h = *(int64_t *)arg2;
            var_60h = *(int64_t *)(arg2 + 8);
            var_a8h = CONCAT71(var_a8h._1_7_, 1);
            fcn.1800df760(arg1, (int64_t)&var_68h, var_98h, (int64_t)&var_80h, var_a8h);
            puVar13 = auStack_c8;
            goto code_r0x0001800e32b0;
        }
    } else {
        puVar4 = (undefined8 *)func_0x0001800d62b0((int32_t *)(arg1 + 0x80), &var_58h);
        if (0xf < (uint64_t)puVar4[3]) {
            puVar4 = (undefined8 *)*puVar4;
        }
        func_0x0001800efe70(arg1, arg1 + 0x84, 0x1806434a0);
        if ((uint64_t)var_40h < 0x10) goto code_r0x0001800e2fb3;
        uVar10 = var_40h + 1;
        iVar8 = CONCAT44(var_58h._4_4_, (undefined4)var_58h);
        iVar7 = iVar8;
        if (uVar10 < 0x1000) {
code_r0x0001800e2fae:
            func_0x000180459c3c(iVar7, uVar10);
            goto code_r0x0001800e2fb3;
        }
        iVar7 = *(int64_t *)(iVar8 + -8);
        if ((iVar8 - iVar7) - 8U < 0x20) {
            uVar10 = var_40h + 0x28;
            goto code_r0x0001800e2fae;
        }
        arg1 = 5;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)();
        puVar12 = auStack_c0;
    }
    var_68h = 0;
    var_60h = 0;
    var_58h._0_4_ = *(undefined4 *)arg2;
    var_58h._4_4_ = *(undefined4 *)(arg2 + 4);
    puVar12[0x20] = 0;
    *(undefined8 *)(puVar12 + -8) = 0x1800e304f;
    uVar6 = fcn.1800df760(arg1, (int64_t)&var_58h, arg3, (int64_t)&var_68h, *(int64_t *)(puVar12 + 0x20));
    *(undefined8 *)(puVar12 + -8) = 0x1800e305f;
    func_0x0001800e35a0(&var_80h, uVar6, &var_98h);
    puVar13 = puVar12;
code_r0x0001800e32b0:
    *(undefined8 *)(puVar13 + -8) = 0x1800e32bc;
    func_0x000180459870(arg_98h ^ (uint64_t)puVar13);
    return;
}

// ============================================================
// Function: FUN_1800e32e0
// Address: 0x1800e32e0
// Size: 143 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800e32e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 *puVar1;
    undefined4 *puVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int64_t iVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    uint64_t uVar17;
    int64_t *piVar18;
    uint64_t uVar19;
    uint64_t *puVar20;
    int64_t *piVar21;
    int64_t iVar22;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    
    arg1 = *(int64_t *)arg1;
    piVar18 = (int64_t *)(arg1 + 0x200);
    uVar14 = *(uint64_t *)(arg1 + 0x210);
    if ((uVar14 != 0) && (arg2 != *(int64_t *)(arg1 + 0x218))) {
        uVar19 = *(int64_t *)(arg1 + 0x208) - 1;
        uVar13 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar15 = 0;
        do {
            uVar13 = uVar13 & uVar19;
            iVar22 = *piVar18 + uVar13 * 0x18;
            iVar12 = *(int64_t *)(*piVar18 + uVar13 * 0x18);
            if (iVar12 == arg2) {
                iVar12 = iVar22 + 8;
                if (iVar22 == 0) {
                    iVar12 = 0;
                }
                if (iVar12 != 0) {
                    return 0;
                }
                break;
            }
            if (iVar12 == *(int64_t *)(arg1 + 0x218)) break;
            uVar13 = uVar13 + 1 + uVar15;
            uVar15 = uVar15 + 1;
        } while (uVar15 <= uVar19);
    }
    uVar5 = *(undefined4 *)arg3;
    uVar6 = *(undefined4 *)(arg3 + 4);
    uVar7 = *(undefined4 *)(arg3 + 8);
    uVar8 = *(undefined4 *)(arg3 + 0xc);
    iVar22 = *(int64_t *)(arg1 + 0x208);
    if (uVar14 < (uint64_t)(iVar22 * 3) >> 2) goto code_r0x0001800e352a;
    if ((uVar14 != 0) && (arg2 != *(int64_t *)(arg1 + 0x218))) {
        uVar14 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar13 = 0;
        do {
            uVar14 = uVar14 & iVar22 - 1U;
            iVar12 = *(int64_t *)(*piVar18 + uVar14 * 0x18);
            if (iVar12 == arg2) goto code_r0x0001800e352a;
            if (iVar12 == *(int64_t *)(arg1 + 0x218)) break;
            uVar14 = uVar14 + 1 + uVar13;
            uVar13 = uVar13 + 1;
        } while (uVar13 <= iVar22 - 1U);
    }
    uVar14 = *(uint64_t *)(arg1 + 0x218);
    if (iVar22 == 0) {
        uVar13 = 0x10;
        iVar12 = func_0x000180459890(0x180);
        uVar19 = 0;
        iVar22 = iVar12;
        uVar15 = 0x10;
code_r0x0001800e3450:
        do {
            uVar16 = uVar19 + 1;
            puVar1 = (undefined8 *)(iVar12 + uVar19 * 0x18);
            *puVar1 = *(undefined8 *)(arg1 + 0x218);
            puVar1[1] = 0;
            puVar1[2] = 0;
            uVar19 = uVar16;
        } while (uVar16 < uVar13);
    } else {
        uVar13 = iVar22 * 2;
        if (uVar13 == 0) {
            iVar22 = 0;
            uVar15 = 0;
        } else {
            iVar12 = func_0x000180459890(iVar22 * 0x30);
            uVar19 = 0;
            iVar22 = iVar12;
            uVar15 = uVar13;
            if (uVar13 != 0) goto code_r0x0001800e3450;
        }
    }
    uVar13 = 0;
    if (*(int64_t *)(arg1 + 0x208) != 0) {
        do {
            iVar12 = uVar13 * 0x18;
            uVar19 = *(uint64_t *)(iVar12 + *piVar18);
            if (uVar19 != *(uint64_t *)(arg1 + 0x218)) {
                uVar16 = (uVar19 >> 5 ^ uVar19) >> 4;
                uVar17 = 0;
                do {
                    uVar16 = uVar16 & uVar15 - 1;
                    puVar20 = (uint64_t *)(iVar22 + uVar16 * 0x18);
                    uVar3 = *(uint64_t *)(iVar22 + uVar16 * 0x18);
                    if (uVar3 == uVar14) {
                        *puVar20 = uVar19;
                        goto code_r0x0001800e34ef;
                    }
                    if (uVar3 == uVar19) goto code_r0x0001800e34ef;
                    uVar16 = uVar16 + 1 + uVar17;
                    uVar17 = uVar17 + 1;
                } while (uVar17 <= uVar15 - 1);
                puVar20 = (uint64_t *)0x0;
code_r0x0001800e34ef:
                iVar4 = *piVar18;
                *puVar20 = *(uint64_t *)(iVar4 + iVar12);
                puVar2 = (undefined4 *)(iVar4 + 8 + iVar12);
                uVar9 = puVar2[1];
                uVar10 = puVar2[2];
                uVar11 = puVar2[3];
                *(undefined4 *)(puVar20 + 1) = *puVar2;
                *(undefined4 *)((int64_t)puVar20 + 0xc) = uVar9;
                *(undefined4 *)(puVar20 + 2) = uVar10;
                *(undefined4 *)((int64_t)puVar20 + 0x14) = uVar11;
            }
            uVar13 = uVar13 + 1;
        } while (uVar13 < *(uint64_t *)(arg1 + 0x208));
    }
    iVar12 = *piVar18;
    *piVar18 = iVar22;
    *(uint64_t *)(arg1 + 0x208) = uVar15;
    if (iVar12 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800e352a:
    uVar15 = *(int64_t *)(arg1 + 0x208) - 1;
    uVar14 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
    uVar13 = 0;
    do {
        uVar14 = uVar14 & uVar15;
        piVar21 = (int64_t *)(*piVar18 + uVar14 * 0x18);
        iVar22 = *(int64_t *)(*piVar18 + uVar14 * 0x18);
        if (iVar22 == *(int64_t *)(arg1 + 0x218)) {
            *piVar21 = arg2;
            *(int64_t *)(arg1 + 0x210) = *(int64_t *)(arg1 + 0x210) + 1;
            goto code_r0x0001800e3583;
        }
        if (iVar22 == arg2) goto code_r0x0001800e3583;
        uVar14 = uVar14 + 1 + uVar13;
        uVar13 = uVar13 + 1;
    } while (uVar13 <= uVar15);
    piVar21 = (int64_t *)0x0;
code_r0x0001800e3583:
    *(undefined4 *)(piVar21 + 1) = uVar5;
    *(undefined4 *)((int64_t)piVar21 + 0xc) = uVar6;
    *(undefined4 *)(piVar21 + 2) = uVar7;
    *(undefined4 *)((int64_t)piVar21 + 0x14) = uVar8;
    return CONCAT71((unkint7)((uint64_t)iVar22 >> 8), 1);
}

// ============================================================
// Function: FUN_1800e336f
// Address: 0x1800e336f
// Size: 124 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800e32e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 *puVar1;
    undefined4 *puVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int64_t iVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    uint64_t uVar17;
    int64_t *piVar18;
    uint64_t uVar19;
    uint64_t *puVar20;
    int64_t *piVar21;
    int64_t iVar22;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    
    arg1 = *(int64_t *)arg1;
    piVar18 = (int64_t *)(arg1 + 0x200);
    uVar14 = *(uint64_t *)(arg1 + 0x210);
    if ((uVar14 != 0) && (arg2 != *(int64_t *)(arg1 + 0x218))) {
        uVar19 = *(int64_t *)(arg1 + 0x208) - 1;
        uVar13 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar15 = 0;
        do {
            uVar13 = uVar13 & uVar19;
            iVar22 = *piVar18 + uVar13 * 0x18;
            iVar12 = *(int64_t *)(*piVar18 + uVar13 * 0x18);
            if (iVar12 == arg2) {
                iVar12 = iVar22 + 8;
                if (iVar22 == 0) {
                    iVar12 = 0;
                }
                if (iVar12 != 0) {
                    return 0;
                }
                break;
            }
            if (iVar12 == *(int64_t *)(arg1 + 0x218)) break;
            uVar13 = uVar13 + 1 + uVar15;
            uVar15 = uVar15 + 1;
        } while (uVar15 <= uVar19);
    }
    uVar5 = *(undefined4 *)arg3;
    uVar6 = *(undefined4 *)(arg3 + 4);
    uVar7 = *(undefined4 *)(arg3 + 8);
    uVar8 = *(undefined4 *)(arg3 + 0xc);
    iVar22 = *(int64_t *)(arg1 + 0x208);
    if (uVar14 < (uint64_t)(iVar22 * 3) >> 2) goto code_r0x0001800e352a;
    if ((uVar14 != 0) && (arg2 != *(int64_t *)(arg1 + 0x218))) {
        uVar14 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar13 = 0;
        do {
            uVar14 = uVar14 & iVar22 - 1U;
            iVar12 = *(int64_t *)(*piVar18 + uVar14 * 0x18);
            if (iVar12 == arg2) goto code_r0x0001800e352a;
            if (iVar12 == *(int64_t *)(arg1 + 0x218)) break;
            uVar14 = uVar14 + 1 + uVar13;
            uVar13 = uVar13 + 1;
        } while (uVar13 <= iVar22 - 1U);
    }
    uVar14 = *(uint64_t *)(arg1 + 0x218);
    if (iVar22 == 0) {
        uVar13 = 0x10;
        iVar12 = func_0x000180459890(0x180);
        uVar19 = 0;
        iVar22 = iVar12;
        uVar15 = 0x10;
code_r0x0001800e3450:
        do {
            uVar16 = uVar19 + 1;
            puVar1 = (undefined8 *)(iVar12 + uVar19 * 0x18);
            *puVar1 = *(undefined8 *)(arg1 + 0x218);
            puVar1[1] = 0;
            puVar1[2] = 0;
            uVar19 = uVar16;
        } while (uVar16 < uVar13);
    } else {
        uVar13 = iVar22 * 2;
        if (uVar13 == 0) {
            iVar22 = 0;
            uVar15 = 0;
        } else {
            iVar12 = func_0x000180459890(iVar22 * 0x30);
            uVar19 = 0;
            iVar22 = iVar12;
            uVar15 = uVar13;
            if (uVar13 != 0) goto code_r0x0001800e3450;
        }
    }
    uVar13 = 0;
    if (*(int64_t *)(arg1 + 0x208) != 0) {
        do {
            iVar12 = uVar13 * 0x18;
            uVar19 = *(uint64_t *)(iVar12 + *piVar18);
            if (uVar19 != *(uint64_t *)(arg1 + 0x218)) {
                uVar16 = (uVar19 >> 5 ^ uVar19) >> 4;
                uVar17 = 0;
                do {
                    uVar16 = uVar16 & uVar15 - 1;
                    puVar20 = (uint64_t *)(iVar22 + uVar16 * 0x18);
                    uVar3 = *(uint64_t *)(iVar22 + uVar16 * 0x18);
                    if (uVar3 == uVar14) {
                        *puVar20 = uVar19;
                        goto code_r0x0001800e34ef;
                    }
                    if (uVar3 == uVar19) goto code_r0x0001800e34ef;
                    uVar16 = uVar16 + 1 + uVar17;
                    uVar17 = uVar17 + 1;
                } while (uVar17 <= uVar15 - 1);
                puVar20 = (uint64_t *)0x0;
code_r0x0001800e34ef:
                iVar4 = *piVar18;
                *puVar20 = *(uint64_t *)(iVar4 + iVar12);
                puVar2 = (undefined4 *)(iVar4 + 8 + iVar12);
                uVar9 = puVar2[1];
                uVar10 = puVar2[2];
                uVar11 = puVar2[3];
                *(undefined4 *)(puVar20 + 1) = *puVar2;
                *(undefined4 *)((int64_t)puVar20 + 0xc) = uVar9;
                *(undefined4 *)(puVar20 + 2) = uVar10;
                *(undefined4 *)((int64_t)puVar20 + 0x14) = uVar11;
            }
            uVar13 = uVar13 + 1;
        } while (uVar13 < *(uint64_t *)(arg1 + 0x208));
    }
    iVar12 = *piVar18;
    *piVar18 = iVar22;
    *(uint64_t *)(arg1 + 0x208) = uVar15;
    if (iVar12 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800e352a:
    uVar15 = *(int64_t *)(arg1 + 0x208) - 1;
    uVar14 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
    uVar13 = 0;
    do {
        uVar14 = uVar14 & uVar15;
        piVar21 = (int64_t *)(*piVar18 + uVar14 * 0x18);
        iVar22 = *(int64_t *)(*piVar18 + uVar14 * 0x18);
        if (iVar22 == *(int64_t *)(arg1 + 0x218)) {
            *piVar21 = arg2;
            *(int64_t *)(arg1 + 0x210) = *(int64_t *)(arg1 + 0x210) + 1;
            goto code_r0x0001800e3583;
        }
        if (iVar22 == arg2) goto code_r0x0001800e3583;
        uVar14 = uVar14 + 1 + uVar13;
        uVar13 = uVar13 + 1;
    } while (uVar13 <= uVar15);
    piVar21 = (int64_t *)0x0;
code_r0x0001800e3583:
    *(undefined4 *)(piVar21 + 1) = uVar5;
    *(undefined4 *)((int64_t)piVar21 + 0xc) = uVar6;
    *(undefined4 *)(piVar21 + 2) = uVar7;
    *(undefined4 *)((int64_t)piVar21 + 0x14) = uVar8;
    return CONCAT71((unkint7)((uint64_t)iVar22 >> 8), 1);
}

// ============================================================
// Function: FUN_1800e33eb
// Address: 0x1800e33eb
// Size: 10 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800e32e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 *puVar1;
    undefined4 *puVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int64_t iVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    uint64_t uVar17;
    int64_t *piVar18;
    uint64_t uVar19;
    uint64_t *puVar20;
    int64_t *piVar21;
    int64_t iVar22;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    
    arg1 = *(int64_t *)arg1;
    piVar18 = (int64_t *)(arg1 + 0x200);
    uVar14 = *(uint64_t *)(arg1 + 0x210);
    if ((uVar14 != 0) && (arg2 != *(int64_t *)(arg1 + 0x218))) {
        uVar19 = *(int64_t *)(arg1 + 0x208) - 1;
        uVar13 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar15 = 0;
        do {
            uVar13 = uVar13 & uVar19;
            iVar22 = *piVar18 + uVar13 * 0x18;
            iVar12 = *(int64_t *)(*piVar18 + uVar13 * 0x18);
            if (iVar12 == arg2) {
                iVar12 = iVar22 + 8;
                if (iVar22 == 0) {
                    iVar12 = 0;
                }
                if (iVar12 != 0) {
                    return 0;
                }
                break;
            }
            if (iVar12 == *(int64_t *)(arg1 + 0x218)) break;
            uVar13 = uVar13 + 1 + uVar15;
            uVar15 = uVar15 + 1;
        } while (uVar15 <= uVar19);
    }
    uVar5 = *(undefined4 *)arg3;
    uVar6 = *(undefined4 *)(arg3 + 4);
    uVar7 = *(undefined4 *)(arg3 + 8);
    uVar8 = *(undefined4 *)(arg3 + 0xc);
    iVar22 = *(int64_t *)(arg1 + 0x208);
    if (uVar14 < (uint64_t)(iVar22 * 3) >> 2) goto code_r0x0001800e352a;
    if ((uVar14 != 0) && (arg2 != *(int64_t *)(arg1 + 0x218))) {
        uVar14 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar13 = 0;
        do {
            uVar14 = uVar14 & iVar22 - 1U;
            iVar12 = *(int64_t *)(*piVar18 + uVar14 * 0x18);
            if (iVar12 == arg2) goto code_r0x0001800e352a;
            if (iVar12 == *(int64_t *)(arg1 + 0x218)) break;
            uVar14 = uVar14 + 1 + uVar13;
            uVar13 = uVar13 + 1;
        } while (uVar13 <= iVar22 - 1U);
    }
    uVar14 = *(uint64_t *)(arg1 + 0x218);
    if (iVar22 == 0) {
        uVar13 = 0x10;
        iVar12 = func_0x000180459890(0x180);
        uVar19 = 0;
        iVar22 = iVar12;
        uVar15 = 0x10;
code_r0x0001800e3450:
        do {
            uVar16 = uVar19 + 1;
            puVar1 = (undefined8 *)(iVar12 + uVar19 * 0x18);
            *puVar1 = *(undefined8 *)(arg1 + 0x218);
            puVar1[1] = 0;
            puVar1[2] = 0;
            uVar19 = uVar16;
        } while (uVar16 < uVar13);
    } else {
        uVar13 = iVar22 * 2;
        if (uVar13 == 0) {
            iVar22 = 0;
            uVar15 = 0;
        } else {
            iVar12 = func_0x000180459890(iVar22 * 0x30);
            uVar19 = 0;
            iVar22 = iVar12;
            uVar15 = uVar13;
            if (uVar13 != 0) goto code_r0x0001800e3450;
        }
    }
    uVar13 = 0;
    if (*(int64_t *)(arg1 + 0x208) != 0) {
        do {
            iVar12 = uVar13 * 0x18;
            uVar19 = *(uint64_t *)(iVar12 + *piVar18);
            if (uVar19 != *(uint64_t *)(arg1 + 0x218)) {
                uVar16 = (uVar19 >> 5 ^ uVar19) >> 4;
                uVar17 = 0;
                do {
                    uVar16 = uVar16 & uVar15 - 1;
                    puVar20 = (uint64_t *)(iVar22 + uVar16 * 0x18);
                    uVar3 = *(uint64_t *)(iVar22 + uVar16 * 0x18);
                    if (uVar3 == uVar14) {
                        *puVar20 = uVar19;
                        goto code_r0x0001800e34ef;
                    }
                    if (uVar3 == uVar19) goto code_r0x0001800e34ef;
                    uVar16 = uVar16 + 1 + uVar17;
                    uVar17 = uVar17 + 1;
                } while (uVar17 <= uVar15 - 1);
                puVar20 = (uint64_t *)0x0;
code_r0x0001800e34ef:
                iVar4 = *piVar18;
                *puVar20 = *(uint64_t *)(iVar4 + iVar12);
                puVar2 = (undefined4 *)(iVar4 + 8 + iVar12);
                uVar9 = puVar2[1];
                uVar10 = puVar2[2];
                uVar11 = puVar2[3];
                *(undefined4 *)(puVar20 + 1) = *puVar2;
                *(undefined4 *)((int64_t)puVar20 + 0xc) = uVar9;
                *(undefined4 *)(puVar20 + 2) = uVar10;
                *(undefined4 *)((int64_t)puVar20 + 0x14) = uVar11;
            }
            uVar13 = uVar13 + 1;
        } while (uVar13 < *(uint64_t *)(arg1 + 0x208));
    }
    iVar12 = *piVar18;
    *piVar18 = iVar22;
    *(uint64_t *)(arg1 + 0x208) = uVar15;
    if (iVar12 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800e352a:
    uVar15 = *(int64_t *)(arg1 + 0x208) - 1;
    uVar14 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
    uVar13 = 0;
    do {
        uVar14 = uVar14 & uVar15;
        piVar21 = (int64_t *)(*piVar18 + uVar14 * 0x18);
        iVar22 = *(int64_t *)(*piVar18 + uVar14 * 0x18);
        if (iVar22 == *(int64_t *)(arg1 + 0x218)) {
            *piVar21 = arg2;
            *(int64_t *)(arg1 + 0x210) = *(int64_t *)(arg1 + 0x210) + 1;
            goto code_r0x0001800e3583;
        }
        if (iVar22 == arg2) goto code_r0x0001800e3583;
        uVar14 = uVar14 + 1 + uVar13;
        uVar13 = uVar13 + 1;
    } while (uVar13 <= uVar15);
    piVar21 = (int64_t *)0x0;
code_r0x0001800e3583:
    *(undefined4 *)(piVar21 + 1) = uVar5;
    *(undefined4 *)((int64_t)piVar21 + 0xc) = uVar6;
    *(undefined4 *)(piVar21 + 2) = uVar7;
    *(undefined4 *)((int64_t)piVar21 + 0x14) = uVar8;
    return CONCAT71((unkint7)((uint64_t)iVar22 >> 8), 1);
}

// ============================================================
// Function: FUN_1800e33f5
// Address: 0x1800e33f5
// Size: 155 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800e32e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 *puVar1;
    undefined4 *puVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int64_t iVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    uint64_t uVar17;
    int64_t *piVar18;
    uint64_t uVar19;
    uint64_t *puVar20;
    int64_t *piVar21;
    int64_t iVar22;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    
    arg1 = *(int64_t *)arg1;
    piVar18 = (int64_t *)(arg1 + 0x200);
    uVar14 = *(uint64_t *)(arg1 + 0x210);
    if ((uVar14 != 0) && (arg2 != *(int64_t *)(arg1 + 0x218))) {
        uVar19 = *(int64_t *)(arg1 + 0x208) - 1;
        uVar13 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar15 = 0;
        do {
            uVar13 = uVar13 & uVar19;
            iVar22 = *piVar18 + uVar13 * 0x18;
            iVar12 = *(int64_t *)(*piVar18 + uVar13 * 0x18);
            if (iVar12 == arg2) {
                iVar12 = iVar22 + 8;
                if (iVar22 == 0) {
                    iVar12 = 0;
                }
                if (iVar12 != 0) {
                    return 0;
                }
                break;
            }
            if (iVar12 == *(int64_t *)(arg1 + 0x218)) break;
            uVar13 = uVar13 + 1 + uVar15;
            uVar15 = uVar15 + 1;
        } while (uVar15 <= uVar19);
    }
    uVar5 = *(undefined4 *)arg3;
    uVar6 = *(undefined4 *)(arg3 + 4);
    uVar7 = *(undefined4 *)(arg3 + 8);
    uVar8 = *(undefined4 *)(arg3 + 0xc);
    iVar22 = *(int64_t *)(arg1 + 0x208);
    if (uVar14 < (uint64_t)(iVar22 * 3) >> 2) goto code_r0x0001800e352a;
    if ((uVar14 != 0) && (arg2 != *(int64_t *)(arg1 + 0x218))) {
        uVar14 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar13 = 0;
        do {
            uVar14 = uVar14 & iVar22 - 1U;
            iVar12 = *(int64_t *)(*piVar18 + uVar14 * 0x18);
            if (iVar12 == arg2) goto code_r0x0001800e352a;
            if (iVar12 == *(int64_t *)(arg1 + 0x218)) break;
            uVar14 = uVar14 + 1 + uVar13;
            uVar13 = uVar13 + 1;
        } while (uVar13 <= iVar22 - 1U);
    }
    uVar14 = *(uint64_t *)(arg1 + 0x218);
    if (iVar22 == 0) {
        uVar13 = 0x10;
        iVar12 = func_0x000180459890(0x180);
        uVar19 = 0;
        iVar22 = iVar12;
        uVar15 = 0x10;
code_r0x0001800e3450:
        do {
            uVar16 = uVar19 + 1;
            puVar1 = (undefined8 *)(iVar12 + uVar19 * 0x18);
            *puVar1 = *(undefined8 *)(arg1 + 0x218);
            puVar1[1] = 0;
            puVar1[2] = 0;
            uVar19 = uVar16;
        } while (uVar16 < uVar13);
    } else {
        uVar13 = iVar22 * 2;
        if (uVar13 == 0) {
            iVar22 = 0;
            uVar15 = 0;
        } else {
            iVar12 = func_0x000180459890(iVar22 * 0x30);
            uVar19 = 0;
            iVar22 = iVar12;
            uVar15 = uVar13;
            if (uVar13 != 0) goto code_r0x0001800e3450;
        }
    }
    uVar13 = 0;
    if (*(int64_t *)(arg1 + 0x208) != 0) {
        do {
            iVar12 = uVar13 * 0x18;
            uVar19 = *(uint64_t *)(iVar12 + *piVar18);
            if (uVar19 != *(uint64_t *)(arg1 + 0x218)) {
                uVar16 = (uVar19 >> 5 ^ uVar19) >> 4;
                uVar17 = 0;
                do {
                    uVar16 = uVar16 & uVar15 - 1;
                    puVar20 = (uint64_t *)(iVar22 + uVar16 * 0x18);
                    uVar3 = *(uint64_t *)(iVar22 + uVar16 * 0x18);
                    if (uVar3 == uVar14) {
                        *puVar20 = uVar19;
                        goto code_r0x0001800e34ef;
                    }
                    if (uVar3 == uVar19) goto code_r0x0001800e34ef;
                    uVar16 = uVar16 + 1 + uVar17;
                    uVar17 = uVar17 + 1;
                } while (uVar17 <= uVar15 - 1);
                puVar20 = (uint64_t *)0x0;
code_r0x0001800e34ef:
                iVar4 = *piVar18;
                *puVar20 = *(uint64_t *)(iVar4 + iVar12);
                puVar2 = (undefined4 *)(iVar4 + 8 + iVar12);
                uVar9 = puVar2[1];
                uVar10 = puVar2[2];
                uVar11 = puVar2[3];
                *(undefined4 *)(puVar20 + 1) = *puVar2;
                *(undefined4 *)((int64_t)puVar20 + 0xc) = uVar9;
                *(undefined4 *)(puVar20 + 2) = uVar10;
                *(undefined4 *)((int64_t)puVar20 + 0x14) = uVar11;
            }
            uVar13 = uVar13 + 1;
        } while (uVar13 < *(uint64_t *)(arg1 + 0x208));
    }
    iVar12 = *piVar18;
    *piVar18 = iVar22;
    *(uint64_t *)(arg1 + 0x208) = uVar15;
    if (iVar12 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800e352a:
    uVar15 = *(int64_t *)(arg1 + 0x208) - 1;
    uVar14 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
    uVar13 = 0;
    do {
        uVar14 = uVar14 & uVar15;
        piVar21 = (int64_t *)(*piVar18 + uVar14 * 0x18);
        iVar22 = *(int64_t *)(*piVar18 + uVar14 * 0x18);
        if (iVar22 == *(int64_t *)(arg1 + 0x218)) {
            *piVar21 = arg2;
            *(int64_t *)(arg1 + 0x210) = *(int64_t *)(arg1 + 0x210) + 1;
            goto code_r0x0001800e3583;
        }
        if (iVar22 == arg2) goto code_r0x0001800e3583;
        uVar14 = uVar14 + 1 + uVar13;
        uVar13 = uVar13 + 1;
    } while (uVar13 <= uVar15);
    piVar21 = (int64_t *)0x0;
code_r0x0001800e3583:
    *(undefined4 *)(piVar21 + 1) = uVar5;
    *(undefined4 *)((int64_t)piVar21 + 0xc) = uVar6;
    *(undefined4 *)(piVar21 + 2) = uVar7;
    *(undefined4 *)((int64_t)piVar21 + 0x14) = uVar8;
    return CONCAT71((unkint7)((uint64_t)iVar22 >> 8), 1);
}

// ============================================================
// Function: FUN_1800e3490
// Address: 0x1800e3490
// Size: 149 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800e32e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 *puVar1;
    undefined4 *puVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int64_t iVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    uint64_t uVar17;
    int64_t *piVar18;
    uint64_t uVar19;
    uint64_t *puVar20;
    int64_t *piVar21;
    int64_t iVar22;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    
    arg1 = *(int64_t *)arg1;
    piVar18 = (int64_t *)(arg1 + 0x200);
    uVar14 = *(uint64_t *)(arg1 + 0x210);
    if ((uVar14 != 0) && (arg2 != *(int64_t *)(arg1 + 0x218))) {
        uVar19 = *(int64_t *)(arg1 + 0x208) - 1;
        uVar13 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar15 = 0;
        do {
            uVar13 = uVar13 & uVar19;
            iVar22 = *piVar18 + uVar13 * 0x18;
            iVar12 = *(int64_t *)(*piVar18 + uVar13 * 0x18);
            if (iVar12 == arg2) {
                iVar12 = iVar22 + 8;
                if (iVar22 == 0) {
                    iVar12 = 0;
                }
                if (iVar12 != 0) {
                    return 0;
                }
                break;
            }
            if (iVar12 == *(int64_t *)(arg1 + 0x218)) break;
            uVar13 = uVar13 + 1 + uVar15;
            uVar15 = uVar15 + 1;
        } while (uVar15 <= uVar19);
    }
    uVar5 = *(undefined4 *)arg3;
    uVar6 = *(undefined4 *)(arg3 + 4);
    uVar7 = *(undefined4 *)(arg3 + 8);
    uVar8 = *(undefined4 *)(arg3 + 0xc);
    iVar22 = *(int64_t *)(arg1 + 0x208);
    if (uVar14 < (uint64_t)(iVar22 * 3) >> 2) goto code_r0x0001800e352a;
    if ((uVar14 != 0) && (arg2 != *(int64_t *)(arg1 + 0x218))) {
        uVar14 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar13 = 0;
        do {
            uVar14 = uVar14 & iVar22 - 1U;
            iVar12 = *(int64_t *)(*piVar18 + uVar14 * 0x18);
            if (iVar12 == arg2) goto code_r0x0001800e352a;
            if (iVar12 == *(int64_t *)(arg1 + 0x218)) break;
            uVar14 = uVar14 + 1 + uVar13;
            uVar13 = uVar13 + 1;
        } while (uVar13 <= iVar22 - 1U);
    }
    uVar14 = *(uint64_t *)(arg1 + 0x218);
    if (iVar22 == 0) {
        uVar13 = 0x10;
        iVar12 = func_0x000180459890(0x180);
        uVar19 = 0;
        iVar22 = iVar12;
        uVar15 = 0x10;
code_r0x0001800e3450:
        do {
            uVar16 = uVar19 + 1;
            puVar1 = (undefined8 *)(iVar12 + uVar19 * 0x18);
            *puVar1 = *(undefined8 *)(arg1 + 0x218);
            puVar1[1] = 0;
            puVar1[2] = 0;
            uVar19 = uVar16;
        } while (uVar16 < uVar13);
    } else {
        uVar13 = iVar22 * 2;
        if (uVar13 == 0) {
            iVar22 = 0;
            uVar15 = 0;
        } else {
            iVar12 = func_0x000180459890(iVar22 * 0x30);
            uVar19 = 0;
            iVar22 = iVar12;
            uVar15 = uVar13;
            if (uVar13 != 0) goto code_r0x0001800e3450;
        }
    }
    uVar13 = 0;
    if (*(int64_t *)(arg1 + 0x208) != 0) {
        do {
            iVar12 = uVar13 * 0x18;
            uVar19 = *(uint64_t *)(iVar12 + *piVar18);
            if (uVar19 != *(uint64_t *)(arg1 + 0x218)) {
                uVar16 = (uVar19 >> 5 ^ uVar19) >> 4;
                uVar17 = 0;
                do {
                    uVar16 = uVar16 & uVar15 - 1;
                    puVar20 = (uint64_t *)(iVar22 + uVar16 * 0x18);
                    uVar3 = *(uint64_t *)(iVar22 + uVar16 * 0x18);
                    if (uVar3 == uVar14) {
                        *puVar20 = uVar19;
                        goto code_r0x0001800e34ef;
                    }
                    if (uVar3 == uVar19) goto code_r0x0001800e34ef;
                    uVar16 = uVar16 + 1 + uVar17;
                    uVar17 = uVar17 + 1;
                } while (uVar17 <= uVar15 - 1);
                puVar20 = (uint64_t *)0x0;
code_r0x0001800e34ef:
                iVar4 = *piVar18;
                *puVar20 = *(uint64_t *)(iVar4 + iVar12);
                puVar2 = (undefined4 *)(iVar4 + 8 + iVar12);
                uVar9 = puVar2[1];
                uVar10 = puVar2[2];
                uVar11 = puVar2[3];
                *(undefined4 *)(puVar20 + 1) = *puVar2;
                *(undefined4 *)((int64_t)puVar20 + 0xc) = uVar9;
                *(undefined4 *)(puVar20 + 2) = uVar10;
                *(undefined4 *)((int64_t)puVar20 + 0x14) = uVar11;
            }
            uVar13 = uVar13 + 1;
        } while (uVar13 < *(uint64_t *)(arg1 + 0x208));
    }
    iVar12 = *piVar18;
    *piVar18 = iVar22;
    *(uint64_t *)(arg1 + 0x208) = uVar15;
    if (iVar12 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800e352a:
    uVar15 = *(int64_t *)(arg1 + 0x208) - 1;
    uVar14 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
    uVar13 = 0;
    do {
        uVar14 = uVar14 & uVar15;
        piVar21 = (int64_t *)(*piVar18 + uVar14 * 0x18);
        iVar22 = *(int64_t *)(*piVar18 + uVar14 * 0x18);
        if (iVar22 == *(int64_t *)(arg1 + 0x218)) {
            *piVar21 = arg2;
            *(int64_t *)(arg1 + 0x210) = *(int64_t *)(arg1 + 0x210) + 1;
            goto code_r0x0001800e3583;
        }
        if (iVar22 == arg2) goto code_r0x0001800e3583;
        uVar14 = uVar14 + 1 + uVar13;
        uVar13 = uVar13 + 1;
    } while (uVar13 <= uVar15);
    piVar21 = (int64_t *)0x0;
code_r0x0001800e3583:
    *(undefined4 *)(piVar21 + 1) = uVar5;
    *(undefined4 *)((int64_t)piVar21 + 0xc) = uVar6;
    *(undefined4 *)(piVar21 + 2) = uVar7;
    *(undefined4 *)((int64_t)piVar21 + 0x14) = uVar8;
    return CONCAT71((unkint7)((uint64_t)iVar22 >> 8), 1);
}

// ============================================================
// Function: FUN_1800e3525
// Address: 0x1800e3525
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800e32e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 *puVar1;
    undefined4 *puVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int64_t iVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    uint64_t uVar17;
    int64_t *piVar18;
    uint64_t uVar19;
    uint64_t *puVar20;
    int64_t *piVar21;
    int64_t iVar22;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    
    arg1 = *(int64_t *)arg1;
    piVar18 = (int64_t *)(arg1 + 0x200);
    uVar14 = *(uint64_t *)(arg1 + 0x210);
    if ((uVar14 != 0) && (arg2 != *(int64_t *)(arg1 + 0x218))) {
        uVar19 = *(int64_t *)(arg1 + 0x208) - 1;
        uVar13 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar15 = 0;
        do {
            uVar13 = uVar13 & uVar19;
            iVar22 = *piVar18 + uVar13 * 0x18;
            iVar12 = *(int64_t *)(*piVar18 + uVar13 * 0x18);
            if (iVar12 == arg2) {
                iVar12 = iVar22 + 8;
                if (iVar22 == 0) {
                    iVar12 = 0;
                }
                if (iVar12 != 0) {
                    return 0;
                }
                break;
            }
            if (iVar12 == *(int64_t *)(arg1 + 0x218)) break;
            uVar13 = uVar13 + 1 + uVar15;
            uVar15 = uVar15 + 1;
        } while (uVar15 <= uVar19);
    }
    uVar5 = *(undefined4 *)arg3;
    uVar6 = *(undefined4 *)(arg3 + 4);
    uVar7 = *(undefined4 *)(arg3 + 8);
    uVar8 = *(undefined4 *)(arg3 + 0xc);
    iVar22 = *(int64_t *)(arg1 + 0x208);
    if (uVar14 < (uint64_t)(iVar22 * 3) >> 2) goto code_r0x0001800e352a;
    if ((uVar14 != 0) && (arg2 != *(int64_t *)(arg1 + 0x218))) {
        uVar14 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar13 = 0;
        do {
            uVar14 = uVar14 & iVar22 - 1U;
            iVar12 = *(int64_t *)(*piVar18 + uVar14 * 0x18);
            if (iVar12 == arg2) goto code_r0x0001800e352a;
            if (iVar12 == *(int64_t *)(arg1 + 0x218)) break;
            uVar14 = uVar14 + 1 + uVar13;
            uVar13 = uVar13 + 1;
        } while (uVar13 <= iVar22 - 1U);
    }
    uVar14 = *(uint64_t *)(arg1 + 0x218);
    if (iVar22 == 0) {
        uVar13 = 0x10;
        iVar12 = func_0x000180459890(0x180);
        uVar19 = 0;
        iVar22 = iVar12;
        uVar15 = 0x10;
code_r0x0001800e3450:
        do {
            uVar16 = uVar19 + 1;
            puVar1 = (undefined8 *)(iVar12 + uVar19 * 0x18);
            *puVar1 = *(undefined8 *)(arg1 + 0x218);
            puVar1[1] = 0;
            puVar1[2] = 0;
            uVar19 = uVar16;
        } while (uVar16 < uVar13);
    } else {
        uVar13 = iVar22 * 2;
        if (uVar13 == 0) {
            iVar22 = 0;
            uVar15 = 0;
        } else {
            iVar12 = func_0x000180459890(iVar22 * 0x30);
            uVar19 = 0;
            iVar22 = iVar12;
            uVar15 = uVar13;
            if (uVar13 != 0) goto code_r0x0001800e3450;
        }
    }
    uVar13 = 0;
    if (*(int64_t *)(arg1 + 0x208) != 0) {
        do {
            iVar12 = uVar13 * 0x18;
            uVar19 = *(uint64_t *)(iVar12 + *piVar18);
            if (uVar19 != *(uint64_t *)(arg1 + 0x218)) {
                uVar16 = (uVar19 >> 5 ^ uVar19) >> 4;
                uVar17 = 0;
                do {
                    uVar16 = uVar16 & uVar15 - 1;
                    puVar20 = (uint64_t *)(iVar22 + uVar16 * 0x18);
                    uVar3 = *(uint64_t *)(iVar22 + uVar16 * 0x18);
                    if (uVar3 == uVar14) {
                        *puVar20 = uVar19;
                        goto code_r0x0001800e34ef;
                    }
                    if (uVar3 == uVar19) goto code_r0x0001800e34ef;
                    uVar16 = uVar16 + 1 + uVar17;
                    uVar17 = uVar17 + 1;
                } while (uVar17 <= uVar15 - 1);
                puVar20 = (uint64_t *)0x0;
code_r0x0001800e34ef:
                iVar4 = *piVar18;
                *puVar20 = *(uint64_t *)(iVar4 + iVar12);
                puVar2 = (undefined4 *)(iVar4 + 8 + iVar12);
                uVar9 = puVar2[1];
                uVar10 = puVar2[2];
                uVar11 = puVar2[3];
                *(undefined4 *)(puVar20 + 1) = *puVar2;
                *(undefined4 *)((int64_t)puVar20 + 0xc) = uVar9;
                *(undefined4 *)(puVar20 + 2) = uVar10;
                *(undefined4 *)((int64_t)puVar20 + 0x14) = uVar11;
            }
            uVar13 = uVar13 + 1;
        } while (uVar13 < *(uint64_t *)(arg1 + 0x208));
    }
    iVar12 = *piVar18;
    *piVar18 = iVar22;
    *(uint64_t *)(arg1 + 0x208) = uVar15;
    if (iVar12 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800e352a:
    uVar15 = *(int64_t *)(arg1 + 0x208) - 1;
    uVar14 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
    uVar13 = 0;
    do {
        uVar14 = uVar14 & uVar15;
        piVar21 = (int64_t *)(*piVar18 + uVar14 * 0x18);
        iVar22 = *(int64_t *)(*piVar18 + uVar14 * 0x18);
        if (iVar22 == *(int64_t *)(arg1 + 0x218)) {
            *piVar21 = arg2;
            *(int64_t *)(arg1 + 0x210) = *(int64_t *)(arg1 + 0x210) + 1;
            goto code_r0x0001800e3583;
        }
        if (iVar22 == arg2) goto code_r0x0001800e3583;
        uVar14 = uVar14 + 1 + uVar13;
        uVar13 = uVar13 + 1;
    } while (uVar13 <= uVar15);
    piVar21 = (int64_t *)0x0;
code_r0x0001800e3583:
    *(undefined4 *)(piVar21 + 1) = uVar5;
    *(undefined4 *)((int64_t)piVar21 + 0xc) = uVar6;
    *(undefined4 *)(piVar21 + 2) = uVar7;
    *(undefined4 *)((int64_t)piVar21 + 0x14) = uVar8;
    return CONCAT71((unkint7)((uint64_t)iVar22 >> 8), 1);
}

// ============================================================
// Function: FUN_1800e358f
// Address: 0x1800e358f
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800e32e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 *puVar1;
    undefined4 *puVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int64_t iVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    uint64_t uVar17;
    int64_t *piVar18;
    uint64_t uVar19;
    uint64_t *puVar20;
    int64_t *piVar21;
    int64_t iVar22;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    
    arg1 = *(int64_t *)arg1;
    piVar18 = (int64_t *)(arg1 + 0x200);
    uVar14 = *(uint64_t *)(arg1 + 0x210);
    if ((uVar14 != 0) && (arg2 != *(int64_t *)(arg1 + 0x218))) {
        uVar19 = *(int64_t *)(arg1 + 0x208) - 1;
        uVar13 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar15 = 0;
        do {
            uVar13 = uVar13 & uVar19;
            iVar22 = *piVar18 + uVar13 * 0x18;
            iVar12 = *(int64_t *)(*piVar18 + uVar13 * 0x18);
            if (iVar12 == arg2) {
                iVar12 = iVar22 + 8;
                if (iVar22 == 0) {
                    iVar12 = 0;
                }
                if (iVar12 != 0) {
                    return 0;
                }
                break;
            }
            if (iVar12 == *(int64_t *)(arg1 + 0x218)) break;
            uVar13 = uVar13 + 1 + uVar15;
            uVar15 = uVar15 + 1;
        } while (uVar15 <= uVar19);
    }
    uVar5 = *(undefined4 *)arg3;
    uVar6 = *(undefined4 *)(arg3 + 4);
    uVar7 = *(undefined4 *)(arg3 + 8);
    uVar8 = *(undefined4 *)(arg3 + 0xc);
    iVar22 = *(int64_t *)(arg1 + 0x208);
    if (uVar14 < (uint64_t)(iVar22 * 3) >> 2) goto code_r0x0001800e352a;
    if ((uVar14 != 0) && (arg2 != *(int64_t *)(arg1 + 0x218))) {
        uVar14 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar13 = 0;
        do {
            uVar14 = uVar14 & iVar22 - 1U;
            iVar12 = *(int64_t *)(*piVar18 + uVar14 * 0x18);
            if (iVar12 == arg2) goto code_r0x0001800e352a;
            if (iVar12 == *(int64_t *)(arg1 + 0x218)) break;
            uVar14 = uVar14 + 1 + uVar13;
            uVar13 = uVar13 + 1;
        } while (uVar13 <= iVar22 - 1U);
    }
    uVar14 = *(uint64_t *)(arg1 + 0x218);
    if (iVar22 == 0) {
        uVar13 = 0x10;
        iVar12 = func_0x000180459890(0x180);
        uVar19 = 0;
        iVar22 = iVar12;
        uVar15 = 0x10;
code_r0x0001800e3450:
        do {
            uVar16 = uVar19 + 1;
            puVar1 = (undefined8 *)(iVar12 + uVar19 * 0x18);
            *puVar1 = *(undefined8 *)(arg1 + 0x218);
            puVar1[1] = 0;
            puVar1[2] = 0;
            uVar19 = uVar16;
        } while (uVar16 < uVar13);
    } else {
        uVar13 = iVar22 * 2;
        if (uVar13 == 0) {
            iVar22 = 0;
            uVar15 = 0;
        } else {
            iVar12 = func_0x000180459890(iVar22 * 0x30);
            uVar19 = 0;
            iVar22 = iVar12;
            uVar15 = uVar13;
            if (uVar13 != 0) goto code_r0x0001800e3450;
        }
    }
    uVar13 = 0;
    if (*(int64_t *)(arg1 + 0x208) != 0) {
        do {
            iVar12 = uVar13 * 0x18;
            uVar19 = *(uint64_t *)(iVar12 + *piVar18);
            if (uVar19 != *(uint64_t *)(arg1 + 0x218)) {
                uVar16 = (uVar19 >> 5 ^ uVar19) >> 4;
                uVar17 = 0;
                do {
                    uVar16 = uVar16 & uVar15 - 1;
                    puVar20 = (uint64_t *)(iVar22 + uVar16 * 0x18);
                    uVar3 = *(uint64_t *)(iVar22 + uVar16 * 0x18);
                    if (uVar3 == uVar14) {
                        *puVar20 = uVar19;
                        goto code_r0x0001800e34ef;
                    }
                    if (uVar3 == uVar19) goto code_r0x0001800e34ef;
                    uVar16 = uVar16 + 1 + uVar17;
                    uVar17 = uVar17 + 1;
                } while (uVar17 <= uVar15 - 1);
                puVar20 = (uint64_t *)0x0;
code_r0x0001800e34ef:
                iVar4 = *piVar18;
                *puVar20 = *(uint64_t *)(iVar4 + iVar12);
                puVar2 = (undefined4 *)(iVar4 + 8 + iVar12);
                uVar9 = puVar2[1];
                uVar10 = puVar2[2];
                uVar11 = puVar2[3];
                *(undefined4 *)(puVar20 + 1) = *puVar2;
                *(undefined4 *)((int64_t)puVar20 + 0xc) = uVar9;
                *(undefined4 *)(puVar20 + 2) = uVar10;
                *(undefined4 *)((int64_t)puVar20 + 0x14) = uVar11;
            }
            uVar13 = uVar13 + 1;
        } while (uVar13 < *(uint64_t *)(arg1 + 0x208));
    }
    iVar12 = *piVar18;
    *piVar18 = iVar22;
    *(uint64_t *)(arg1 + 0x208) = uVar15;
    if (iVar12 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800e352a:
    uVar15 = *(int64_t *)(arg1 + 0x208) - 1;
    uVar14 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
    uVar13 = 0;
    do {
        uVar14 = uVar14 & uVar15;
        piVar21 = (int64_t *)(*piVar18 + uVar14 * 0x18);
        iVar22 = *(int64_t *)(*piVar18 + uVar14 * 0x18);
        if (iVar22 == *(int64_t *)(arg1 + 0x218)) {
            *piVar21 = arg2;
            *(int64_t *)(arg1 + 0x210) = *(int64_t *)(arg1 + 0x210) + 1;
            goto code_r0x0001800e3583;
        }
        if (iVar22 == arg2) goto code_r0x0001800e3583;
        uVar14 = uVar14 + 1 + uVar13;
        uVar13 = uVar13 + 1;
    } while (uVar13 <= uVar15);
    piVar21 = (int64_t *)0x0;
code_r0x0001800e3583:
    *(undefined4 *)(piVar21 + 1) = uVar5;
    *(undefined4 *)((int64_t)piVar21 + 0xc) = uVar6;
    *(undefined4 *)(piVar21 + 2) = uVar7;
    *(undefined4 *)((int64_t)piVar21 + 0x14) = uVar8;
    return CONCAT71((unkint7)((uint64_t)iVar22 >> 8), 1);
}

// ============================================================
// Function: FUN_1800e35a0
// Address: 0x1800e35a0
// Size: 45 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800e35a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h, int64_t arg_60h)
{
    int64_t **ppiVar1;
    int64_t *piVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    char cVar6;
    int64_t **ppiVar7;
    int64_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar8 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x1807826f8) {
        iVar8 = arg2;
    }
    if (iVar8 != 0) {
        *(undefined *)(iVar8 + 0x49) = 1;
        ppiVar7 = *(int64_t ***)(iVar8 + 0x28);
        ppiVar1 = ppiVar7 + *(int64_t *)(iVar8 + 0x30);
        for (; ppiVar7 != ppiVar1; ppiVar7 = ppiVar7 + 1) {
            piVar2 = *ppiVar7;
            cVar6 = fcn.1800e32e0(*(int64_t *)arg1, *piVar2, (int64_t)(piVar2 + 1));
            if (cVar6 == '\0') {
                func_0x0001800efe70(*(undefined8 *)(arg1 + 8), piVar2 + 1, 0x180643478, *piVar2);
            } else {
                *(undefined *)((int64_t)piVar2 + 0x31) = 1;
            }
        }
        uVar3 = *(undefined4 *)(arg3 + 4);
        uVar4 = *(undefined4 *)(arg3 + 8);
        uVar5 = *(undefined4 *)(arg3 + 0xc);
        *(undefined4 *)(iVar8 + 0x4c) = *(undefined4 *)arg3;
        *(undefined4 *)(iVar8 + 0x50) = uVar3;
        *(undefined4 *)(iVar8 + 0x54) = uVar4;
        *(undefined4 *)(iVar8 + 0x58) = uVar5;
        if (*(char *)(iVar8 + 0x5c) == '\0') {
            *(undefined *)(iVar8 + 0x5c) = 1;
            return arg2;
        }
    }
    return arg2;
}

// ============================================================
// Function: FUN_1800e35cd
// Address: 0x1800e35cd
// Size: 31 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800e35a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h, int64_t arg_60h)
{
    int64_t **ppiVar1;
    int64_t *piVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    char cVar6;
    int64_t **ppiVar7;
    int64_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar8 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x1807826f8) {
        iVar8 = arg2;
    }
    if (iVar8 != 0) {
        *(undefined *)(iVar8 + 0x49) = 1;
        ppiVar7 = *(int64_t ***)(iVar8 + 0x28);
        ppiVar1 = ppiVar7 + *(int64_t *)(iVar8 + 0x30);
        for (; ppiVar7 != ppiVar1; ppiVar7 = ppiVar7 + 1) {
            piVar2 = *ppiVar7;
            cVar6 = fcn.1800e32e0(*(int64_t *)arg1, *piVar2, (int64_t)(piVar2 + 1));
            if (cVar6 == '\0') {
                func_0x0001800efe70(*(undefined8 *)(arg1 + 8), piVar2 + 1, 0x180643478, *piVar2);
            } else {
                *(undefined *)((int64_t)piVar2 + 0x31) = 1;
            }
        }
        uVar3 = *(undefined4 *)(arg3 + 4);
        uVar4 = *(undefined4 *)(arg3 + 8);
        uVar5 = *(undefined4 *)(arg3 + 0xc);
        *(undefined4 *)(iVar8 + 0x4c) = *(undefined4 *)arg3;
        *(undefined4 *)(iVar8 + 0x50) = uVar3;
        *(undefined4 *)(iVar8 + 0x54) = uVar4;
        *(undefined4 *)(iVar8 + 0x58) = uVar5;
        if (*(char *)(iVar8 + 0x5c) == '\0') {
            *(undefined *)(iVar8 + 0x5c) = 1;
            return arg2;
        }
    }
    return arg2;
}

// ============================================================
// Function: FUN_1800e35ec
// Address: 0x1800e35ec
// Size: 92 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800e35a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h, int64_t arg_60h)
{
    int64_t **ppiVar1;
    int64_t *piVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    char cVar6;
    int64_t **ppiVar7;
    int64_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar8 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x1807826f8) {
        iVar8 = arg2;
    }
    if (iVar8 != 0) {
        *(undefined *)(iVar8 + 0x49) = 1;
        ppiVar7 = *(int64_t ***)(iVar8 + 0x28);
        ppiVar1 = ppiVar7 + *(int64_t *)(iVar8 + 0x30);
        for (; ppiVar7 != ppiVar1; ppiVar7 = ppiVar7 + 1) {
            piVar2 = *ppiVar7;
            cVar6 = fcn.1800e32e0(*(int64_t *)arg1, *piVar2, (int64_t)(piVar2 + 1));
            if (cVar6 == '\0') {
                func_0x0001800efe70(*(undefined8 *)(arg1 + 8), piVar2 + 1, 0x180643478, *piVar2);
            } else {
                *(undefined *)((int64_t)piVar2 + 0x31) = 1;
            }
        }
        uVar3 = *(undefined4 *)(arg3 + 4);
        uVar4 = *(undefined4 *)(arg3 + 8);
        uVar5 = *(undefined4 *)(arg3 + 0xc);
        *(undefined4 *)(iVar8 + 0x4c) = *(undefined4 *)arg3;
        *(undefined4 *)(iVar8 + 0x50) = uVar3;
        *(undefined4 *)(iVar8 + 0x54) = uVar4;
        *(undefined4 *)(iVar8 + 0x58) = uVar5;
        if (*(char *)(iVar8 + 0x5c) == '\0') {
            *(undefined *)(iVar8 + 0x5c) = 1;
            return arg2;
        }
    }
    return arg2;
}

// ============================================================
// Function: FUN_1800e3648
// Address: 0x1800e3648
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800e35a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h, int64_t arg_60h)
{
    int64_t **ppiVar1;
    int64_t *piVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    char cVar6;
    int64_t **ppiVar7;
    int64_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar8 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x1807826f8) {
        iVar8 = arg2;
    }
    if (iVar8 != 0) {
        *(undefined *)(iVar8 + 0x49) = 1;
        ppiVar7 = *(int64_t ***)(iVar8 + 0x28);
        ppiVar1 = ppiVar7 + *(int64_t *)(iVar8 + 0x30);
        for (; ppiVar7 != ppiVar1; ppiVar7 = ppiVar7 + 1) {
            piVar2 = *ppiVar7;
            cVar6 = fcn.1800e32e0(*(int64_t *)arg1, *piVar2, (int64_t)(piVar2 + 1));
            if (cVar6 == '\0') {
                func_0x0001800efe70(*(undefined8 *)(arg1 + 8), piVar2 + 1, 0x180643478, *piVar2);
            } else {
                *(undefined *)((int64_t)piVar2 + 0x31) = 1;
            }
        }
        uVar3 = *(undefined4 *)(arg3 + 4);
        uVar4 = *(undefined4 *)(arg3 + 8);
        uVar5 = *(undefined4 *)(arg3 + 0xc);
        *(undefined4 *)(iVar8 + 0x4c) = *(undefined4 *)arg3;
        *(undefined4 *)(iVar8 + 0x50) = uVar3;
        *(undefined4 *)(iVar8 + 0x54) = uVar4;
        *(undefined4 *)(iVar8 + 0x58) = uVar5;
        if (*(char *)(iVar8 + 0x5c) == '\0') {
            *(undefined *)(iVar8 + 0x5c) = 1;
            return arg2;
        }
    }
    return arg2;
}

// ============================================================
// Function: FUN_1800e3664
// Address: 0x1800e3664
// Size: 31 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800e35a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h, int64_t arg_60h)
{
    int64_t **ppiVar1;
    int64_t *piVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    char cVar6;
    int64_t **ppiVar7;
    int64_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar8 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x1807826f8) {
        iVar8 = arg2;
    }
    if (iVar8 != 0) {
        *(undefined *)(iVar8 + 0x49) = 1;
        ppiVar7 = *(int64_t ***)(iVar8 + 0x28);
        ppiVar1 = ppiVar7 + *(int64_t *)(iVar8 + 0x30);
        for (; ppiVar7 != ppiVar1; ppiVar7 = ppiVar7 + 1) {
            piVar2 = *ppiVar7;
            cVar6 = fcn.1800e32e0(*(int64_t *)arg1, *piVar2, (int64_t)(piVar2 + 1));
            if (cVar6 == '\0') {
                func_0x0001800efe70(*(undefined8 *)(arg1 + 8), piVar2 + 1, 0x180643478, *piVar2);
            } else {
                *(undefined *)((int64_t)piVar2 + 0x31) = 1;
            }
        }
        uVar3 = *(undefined4 *)(arg3 + 4);
        uVar4 = *(undefined4 *)(arg3 + 8);
        uVar5 = *(undefined4 *)(arg3 + 0xc);
        *(undefined4 *)(iVar8 + 0x4c) = *(undefined4 *)arg3;
        *(undefined4 *)(iVar8 + 0x50) = uVar3;
        *(undefined4 *)(iVar8 + 0x54) = uVar4;
        *(undefined4 *)(iVar8 + 0x58) = uVar5;
        if (*(char *)(iVar8 + 0x5c) == '\0') {
            *(undefined *)(iVar8 + 0x5c) = 1;
            return arg2;
        }
    }
    return arg2;
}

