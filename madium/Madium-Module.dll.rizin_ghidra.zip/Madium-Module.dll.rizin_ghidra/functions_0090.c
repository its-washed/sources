// Chunk 90 - 50 functions

// ============================================================
// Function: FUN_18012cf59
// Address: 0x18012cf59
// Size: 186 bytes
// ============================================================
void fcn.18012cf59(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_68h, int64_t arg_78h)
{
    uint16_t uVar1;
    uint16_t uVar2;
    uint16_t uVar3;
    uint16_t uVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int32_t iVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    int64_t in_RAX;
    int64_t iVar10;
    uint8_t uVar11;
    uint8_t *puVar12;
    uint32_t *puVar13;
    int64_t iVar14;
    int64_t unaff_RBP;
    uint8_t *puVar15;
    int32_t iVar16;
    uint32_t *puVar17;
    int32_t iVar18;
    uint32_t uVar19;
    uint32_t uVar20;
    uint64_t uVar21;
    undefined4 in_R11D;
    int32_t unaff_R12D;
    int32_t unaff_R13D;
    int64_t iVar23;
    int32_t unaff_R15D;
    float fVar24;
    float fVar25;
    undefined auVar26 [16];
    undefined auVar27 [16];
    float fVar28;
    float fVar29;
    float unaff_XMM7_Da;
    float unaff_XMM8_Da;
    float unaff_XMM9_Da;
    float unaff_XMM13_Da;
    float unaff_XMM14_Da;
    undefined4 unaff_XMM14_Db;
    undefined4 unaff_XMM14_Dc;
    undefined4 unaff_XMM14_Dd;
    float unaff_XMM15_Da;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_30h;
    uint64_t uVar22;
    
    iVar16 = 0;
    *(undefined8 *)(unaff_RBP + 0x290) = 0;
    if (0 < *(int32_t *)(unaff_RBP + -0x58)) {
        iVar7 = *(int32_t *)(unaff_RBP + -0x58);
        do {
            func_0x0001804986e0(unaff_RBP + 0x290, 0, in_R11D);
            uVar22 = 0;
            uVar21 = 0;
            if ((uint32_t)arg_68h == 2) {
                uVar19 = 0;
                uVar6 = 0;
                if (-1 < unaff_R13D) {
                    do {
                        iVar10 = (int64_t)(int32_t)uVar19;
                        uVar11 = *(uint8_t *)(in_RAX + iVar10);
                        uVar6 = uVar19 + 2;
                        uVar20 = (int32_t)uVar22 +
                                 ((uint32_t)uVar11 - (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)))
                        ;
                        uVar22 = (uint64_t)uVar20;
                        uVar19 = uVar19 + 1;
                        *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                        *(char *)(in_RAX + iVar10) = (char)(uVar20 >> 1);
                        uVar21 = uVar22;
                        uVar6 = uVar19;
                    } while ((int32_t)uVar19 <= unaff_R13D);
                }
            } else if ((uint32_t)arg_68h == 3) {
                uVar19 = 0;
                uVar6 = 0;
                if (-1 < unaff_R13D) {
                    do {
                        iVar10 = (int64_t)(int32_t)uVar19;
                        uVar11 = *(uint8_t *)(in_RAX + iVar10);
                        uVar6 = uVar19 + 3;
                        uVar22 = (uint64_t)
                                 ((int32_t)uVar22 +
                                 ((uint32_t)uVar11 - (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)))
                                 );
                        uVar19 = uVar19 + 1;
                        *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                        *(char *)(in_RAX + iVar10) = (char)(uVar22 / 3);
                        uVar21 = uVar22;
                        uVar6 = uVar19;
                    } while ((int32_t)uVar19 <= unaff_R13D);
                }
            } else if ((uint32_t)arg_68h == 4) {
                uVar19 = 0;
                uVar6 = 0;
                if (-1 < unaff_R13D) {
                    do {
                        iVar10 = (int64_t)(int32_t)uVar19;
                        uVar11 = *(uint8_t *)(in_RAX + iVar10);
                        uVar6 = uVar19 - 4;
                        uVar20 = (int32_t)uVar22 +
                                 ((uint32_t)uVar11 - (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)))
                        ;
                        uVar22 = (uint64_t)uVar20;
                        uVar19 = uVar19 + 1;
                        *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                        *(char *)(in_RAX + iVar10) = (char)(uVar20 >> 2);
                        uVar21 = uVar22;
                        uVar6 = uVar19;
                    } while ((int32_t)uVar19 <= unaff_R13D);
                }
            } else {
                uVar19 = 0;
                uVar21 = uVar22;
                if ((uint32_t)arg_68h == 5) {
                    uVar6 = 0;
                    if (-1 < unaff_R13D) {
                        do {
                            iVar10 = (int64_t)(int32_t)uVar19;
                            uVar11 = *(uint8_t *)(in_RAX + iVar10);
                            uVar6 = uVar19 - 3;
                            uVar22 = (uint64_t)
                                     ((int32_t)uVar22 +
                                     ((uint32_t)uVar11 -
                                     (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7))));
                            uVar19 = uVar19 + 1;
                            *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                            *(char *)(in_RAX + iVar10) = (char)(uVar22 / 5);
                            uVar21 = uVar22;
                            uVar6 = uVar19;
                        } while ((int32_t)uVar19 <= unaff_R13D);
                    }
                } else {
                    uVar6 = uVar19;
                    if (-1 < unaff_R13D) {
                        do {
                            iVar10 = (int64_t)(int32_t)uVar19;
                            uVar11 = *(uint8_t *)(in_RAX + iVar10);
                            uVar6 = uVar19 + (uint32_t)arg_68h;
                            uVar20 = (int32_t)uVar22 +
                                     ((uint32_t)uVar11 -
                                     (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)));
                            uVar22 = (uint64_t)uVar20;
                            uVar19 = uVar19 + 1;
                            *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                            *(char *)(in_RAX + iVar10) = (char)(uVar20 / (uint32_t)arg_68h);
                            uVar21 = uVar22;
                            uVar6 = uVar19;
                        } while ((int32_t)uVar19 <= unaff_R13D);
                    }
                }
            }
            for (; (int32_t)uVar6 < unaff_R15D; uVar6 = uVar6 + 1) {
                uVar19 = (int32_t)uVar21 - (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7));
                *(char *)(in_RAX + (int32_t)uVar6) = (char)(uVar19 / (uint32_t)arg_68h);
                uVar21 = (uint64_t)uVar19;
            }
            in_RAX = in_RAX + unaff_R15D;
            iVar16 = iVar16 + 1;
        } while (iVar16 < iVar7);
        in_RAX = *(int64_t *)(unaff_RBP + -0x50);
        unaff_R12D = (int32_t)arg_78h;
    }
    if (0x1ffffffff < arg_78h) {
        iVar16 = 0;
        *(undefined8 *)(unaff_RBP + 0x290) = 0;
        if (0 < unaff_R15D) {
            do {
                func_0x0001804986e0(unaff_RBP + 0x290, 0, arg_78h._4_4_);
                uVar22 = 0;
                uVar21 = 0;
                if (arg_78h._4_4_ == 2) {
                    uVar19 = 0;
                    uVar6 = 0;
                    if (-1 < unaff_R12D) {
                        do {
                            iVar7 = uVar19 * unaff_R15D;
                            uVar11 = *(uint8_t *)(iVar7 + in_RAX);
                            uVar20 = (int32_t)uVar22 +
                                     ((uint32_t)uVar11 -
                                     (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)));
                            uVar22 = (uint64_t)uVar20;
                            uVar6 = uVar19 + 2;
                            uVar19 = uVar19 + 1;
                            *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                            *(char *)(iVar7 + in_RAX) = (char)(uVar20 >> 1);
                            uVar21 = uVar22;
                            uVar6 = uVar19;
                        } while ((int32_t)uVar19 <= unaff_R12D);
                    }
                } else if (arg_78h._4_4_ == 3) {
                    uVar19 = 0;
                    uVar6 = 0;
                    if (-1 < unaff_R12D) {
                        do {
                            iVar7 = uVar19 * unaff_R15D;
                            uVar11 = *(uint8_t *)(iVar7 + in_RAX);
                            uVar22 = (uint64_t)
                                     ((int32_t)uVar22 +
                                     ((uint32_t)uVar11 -
                                     (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7))));
                            uVar6 = uVar19 + 3;
                            uVar19 = uVar19 + 1;
                            *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                            *(char *)(iVar7 + in_RAX) = (char)(uVar22 / 3);
                            uVar21 = uVar22;
                            uVar6 = uVar19;
                        } while ((int32_t)uVar19 <= unaff_R12D);
                    }
                } else if (arg_78h._4_4_ == 4) {
                    uVar19 = 0;
                    uVar6 = 0;
                    if (-1 < unaff_R12D) {
                        do {
                            iVar7 = uVar19 * unaff_R15D;
                            uVar11 = *(uint8_t *)(iVar7 + in_RAX);
                            uVar20 = (int32_t)uVar22 +
                                     ((uint32_t)uVar11 -
                                     (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)));
                            uVar22 = (uint64_t)uVar20;
                            uVar6 = uVar19 - 4;
                            uVar19 = uVar19 + 1;
                            *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                            *(char *)(iVar7 + in_RAX) = (char)(uVar20 >> 2);
                            uVar21 = uVar22;
                            uVar6 = uVar19;
                        } while ((int32_t)uVar19 <= unaff_R12D);
                    }
                } else {
                    uVar19 = 0;
                    uVar21 = uVar22;
                    if (arg_78h._4_4_ == 5) {
                        uVar6 = 0;
                        if (-1 < unaff_R12D) {
                            do {
                                iVar7 = uVar19 * unaff_R15D;
                                uVar11 = *(uint8_t *)(iVar7 + in_RAX);
                                uVar22 = (uint64_t)
                                         ((int32_t)uVar22 +
                                         ((uint32_t)uVar11 -
                                         (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7))));
                                uVar6 = uVar19 - 3;
                                uVar19 = uVar19 + 1;
                                *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                                *(char *)(iVar7 + in_RAX) = (char)(uVar22 / 5);
                                uVar21 = uVar22;
                                uVar6 = uVar19;
                            } while ((int32_t)uVar19 <= unaff_R12D);
                        }
                    } else {
                        uVar6 = uVar19;
                        if (-1 < unaff_R12D) {
                            do {
                                iVar7 = uVar19 * unaff_R15D;
                                uVar11 = *(uint8_t *)(iVar7 + in_RAX);
                                uVar20 = (int32_t)uVar22 +
                                         ((uint32_t)uVar11 -
                                         (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)));
                                uVar21 = (uint64_t)uVar20;
                                uVar6 = uVar19 + arg_78h._4_4_;
                                uVar19 = uVar19 + 1;
                                *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                                *(char *)(iVar7 + in_RAX) = (char)(uVar20 / arg_78h._4_4_);
                                uVar22 = uVar21;
                                uVar6 = uVar19;
                            } while ((int32_t)uVar19 <= unaff_R12D);
                        }
                    }
                }
                iVar7 = *(int32_t *)(unaff_RBP + -0x58);
                for (; (int32_t)uVar6 < iVar7; uVar6 = uVar6 + 1) {
                    uVar19 = (int32_t)uVar21 - (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7));
                    uVar21 = (uint64_t)uVar19;
                    *(char *)((int32_t)(uVar6 * unaff_R15D) + in_RAX) = (char)(uVar19 / arg_78h._4_4_);
                }
                in_RAX = in_RAX + 1;
                iVar16 = iVar16 + 1;
            } while (iVar16 < unaff_R15D);
        }
    }
    fVar25 = unaff_XMM15_Da;
    if ((uint32_t)arg_68h != 0) {
        fVar25 = (float)(1 - (uint32_t)arg_68h) / (unaff_XMM9_Da + unaff_XMM9_Da);
    }
    fVar29 = unaff_XMM15_Da;
    if (arg_78h._4_4_ != 0) {
        fVar29 = (float)(1 - arg_78h._4_4_) / (unaff_XMM8_Da + unaff_XMM8_Da);
    }
    iVar10 = *(int64_t *)(unaff_RBP + 0x78);
    fVar24 = *(float *)(**(int64_t **)(*(int64_t *)(iVar10 + 0x58) + 0x28) + 0x3c);
    fVar28 = unaff_XMM14_Da;
    if (fVar24 != unaff_XMM15_Da) {
        unaff_XMM14_Db = 0;
        unaff_XMM14_Dc = 0;
        unaff_XMM14_Dd = 0;
        fVar28 = *(float *)(iVar10 + 0x14) / fVar24;
    }
    auVar26._4_4_ = unaff_XMM14_Db;
    auVar26._0_4_ = fVar28;
    auVar26._8_4_ = unaff_XMM14_Dc;
    auVar26._12_4_ = unaff_XMM14_Dd;
    auVar27._4_12_ = auVar26._4_12_;
    auVar27._0_4_ = fVar28 * *(float *)(*(int64_t *)(unaff_RBP + 0x50) + 0x50) + unaff_XMM13_Da;
    fVar24 = (float)func_0x0001800f4120(auVar27._0_8_);
    fVar24 = fVar24 + fVar25;
    fVar25 = (float)func_0x0001800f4120();
    puVar17 = *(uint32_t **)(unaff_RBP + 0x48);
    iVar5 = *(int64_t *)(unaff_RBP + 0x30);
    iVar23 = *(int64_t *)(unaff_RBP + -0x30);
    iVar16 = *(int32_t *)(unaff_RBP + -0x40);
    iVar7 = *(int32_t *)(unaff_RBP + -0x3c);
    iVar14 = *(int64_t *)(unaff_RBP + 0x28);
    fVar28 = unaff_XMM14_Da / (unaff_XMM9_Da * unaff_XMM7_Da);
    fVar25 = fVar25 + (float)(int32_t)(*(float *)(iVar10 + 0x44) + unaff_XMM13_Da) + fVar29;
    fVar29 = unaff_XMM14_Da / (unaff_XMM8_Da * unaff_XMM7_Da);
    puVar17[2] = (uint32_t)((float)iVar16 * fVar28 + fVar24);
    puVar17[3] = (uint32_t)((float)iVar7 * fVar29 + fVar25);
    puVar17[4] = (uint32_t)((float)((uint32_t)*(uint16_t *)(iVar23 + 4 + iVar5 * 8) + iVar16) * fVar28 + fVar24);
    uVar1 = *(uint16_t *)(iVar23 + 6 + iVar5 * 8);
    *puVar17 = *puVar17 | 2;
    puVar17[10] = *(uint32_t *)(unaff_RBP + 0x10);
    puVar17[5] = (uint32_t)((float)((uint32_t)uVar1 + iVar7) * fVar29 + fVar25);
    iVar10 = *(int64_t *)(iVar14 + 0x38);
    uVar1 = *(uint16_t *)(iVar23 + 2 + iVar5 * 8);
    uVar2 = *(uint16_t *)(iVar23 + iVar5 * 8);
    uVar3 = *(uint16_t *)(iVar23 + 6 + iVar5 * 8);
    uVar6 = (uint32_t)uVar3;
    iVar16 = *(int32_t *)(iVar10 + 0x1c);
    iVar18 = *(int32_t *)(iVar10 + 0x24) * *(int32_t *)(iVar10 + 0x1c);
    iVar7 = *(int32_t *)(iVar10 + 0x18);
    uVar4 = *(uint16_t *)(iVar23 + 4 + iVar5 * 8);
    *(int64_t *)(unaff_RBP + 0x30) = iVar10;
    puVar17 = (uint32_t *)
              ((int64_t)(int32_t)(((uint32_t)uVar1 * iVar16 + (uint32_t)uVar2) * *(int32_t *)(iVar10 + 0x24)) +
              *(int64_t *)(iVar10 + 0x28));
    if (iVar7 == 1) {
        if (uVar3 != 0) {
            iVar10 = *(int64_t *)(unaff_RBP + -0x50);
            do {
                func_0x000180498030(puVar17, iVar10, (uint32_t)uVar4);
                uVar6 = uVar6 - 1;
                iVar10 = iVar10 + unaff_R15D;
                puVar17 = (uint32_t *)((int64_t)puVar17 + (int64_t)iVar18);
            } while (0 < (int32_t)uVar6);
            iVar10 = *(int64_t *)(unaff_RBP + 0x30);
            iVar23 = *(int64_t *)(unaff_RBP + -0x30);
        }
    } else if ((iVar7 == 0) && (uVar6 != 0)) {
        puVar15 = *(uint8_t **)(unaff_RBP + -0x50);
        do {
            puVar12 = puVar15;
            puVar13 = puVar17;
            uVar19 = (uint32_t)uVar4;
            if (uVar4 != 0) {
                do {
                    uVar11 = *puVar12;
                    puVar12 = puVar12 + 1;
                    uVar19 = uVar19 - 1;
                    *puVar13 = (uint32_t)uVar11 << 0x18 | 0xffffff;
                    puVar13 = puVar13 + 1;
                } while (0 < (int32_t)uVar19);
            }
            uVar6 = uVar6 - 1;
            puVar15 = puVar15 + unaff_R15D;
            puVar17 = (uint32_t *)((int64_t)puVar17 + (int64_t)iVar18);
        } while (0 < (int32_t)uVar6);
    }
    uVar1 = *(uint16_t *)(iVar23 + 4 + iVar5 * 8);
    fVar25 = *(float *)(*(int64_t *)(unaff_RBP + 0x50) + 0x6c);
    if (fVar25 != unaff_XMM14_Da) {
        uVar2 = *(uint16_t *)(iVar23 + 6 + iVar5 * 8);
        uVar6 = (uint32_t)uVar2;
        iVar16 = *(int32_t *)(iVar10 + 0x1c) * *(int32_t *)(iVar10 + 0x24);
        puVar17 = (uint32_t *)
                  ((int64_t)(int32_t)(((uint32_t)*(uint16_t *)(iVar23 + 2 + iVar5 * 8) * *(int32_t *)(iVar10 + 0x1c) +
                                      (uint32_t)*(uint16_t *)(iVar23 + iVar5 * 8)) * *(int32_t *)(iVar10 + 0x24)) +
                  *(int64_t *)(iVar10 + 0x28));
        if (*(int32_t *)(iVar10 + 0x18) == 1) {
            if (uVar2 != 0) {
                do {
                    uVar19 = (uint32_t)uVar1;
                    puVar13 = puVar17;
                    if (3 < uVar19) {
                        do {
                            uVar11 = 0xff;
                            if ((uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar13 * fVar25) < 0xff) {
                                uVar11 = (uint8_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar13 * fVar25);
                            }
                            *(uint8_t *)puVar13 = uVar11;
                            iVar14 = (int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 1) * fVar25);
                            uVar11 = 0xff;
                            if ((uint32_t)iVar14 < 0xff) {
                                uVar11 = (uint8_t)iVar14;
                            }
                            *(uint8_t *)((int64_t)puVar13 + 1) = uVar11;
                            iVar14 = (int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 2) * fVar25);
                            uVar11 = 0xff;
                            if ((uint32_t)iVar14 < 0xff) {
                                uVar11 = (uint8_t)iVar14;
                            }
                            *(uint8_t *)((int64_t)puVar13 + 2) = uVar11;
                            iVar14 = (int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 3) * fVar25);
                            uVar11 = 0xff;
                            if ((uint32_t)iVar14 < 0xff) {
                                uVar11 = (uint8_t)iVar14;
                            }
                            uVar19 = uVar19 - 4;
                            *(uint8_t *)((int64_t)puVar13 + 3) = uVar11;
                            puVar13 = puVar13 + 1;
                        } while (3 < (int32_t)uVar19);
                    }
                    for (; 0 < (int32_t)uVar19; uVar19 = uVar19 - 1) {
                        uVar11 = 0xff;
                        if ((uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar13 * fVar25) < 0xff) {
                            uVar11 = (uint8_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar13 * fVar25);
                        }
                        *(uint8_t *)puVar13 = uVar11;
                        puVar13 = (uint32_t *)((int64_t)puVar13 + 1);
                    }
                    uVar6 = uVar6 - 1;
                    puVar17 = (uint32_t *)((int64_t)puVar17 + (int64_t)iVar16);
                } while (0 < (int32_t)uVar6);
            }
        } else if ((*(int32_t *)(iVar10 + 0x18) == 0) && (uVar6 != 0)) {
            do {
                uVar19 = (uint32_t)uVar1;
                puVar13 = puVar17;
                if (3 < uVar19) {
                    do {
                        uVar20 = *puVar13;
                        uVar8 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 3) * fVar25);
                        uVar9 = 0xff;
                        if (uVar8 < 0xff) {
                            uVar9 = uVar8;
                        }
                        uVar8 = puVar13[1];
                        *puVar13 = ((uVar9 << 8 | uVar20 >> 0x10 & 0xff) << 8 | uVar20 >> 8 & 0xff) << 8 | uVar20 & 0xff
                        ;
                        uVar9 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 7) * fVar25);
                        uVar20 = 0xff;
                        if (uVar9 < 0xff) {
                            uVar20 = uVar9;
                        }
                        uVar9 = puVar13[2];
                        puVar13[1] = ((uVar20 << 8 | uVar8 >> 0x10 & 0xff) << 8 | uVar8 >> 8 & 0xff) << 8 | uVar8 & 0xff
                        ;
                        uVar8 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 0xb) * fVar25);
                        uVar20 = 0xff;
                        if (uVar8 < 0xff) {
                            uVar20 = uVar8;
                        }
                        uVar8 = puVar13[3];
                        puVar13[2] = ((uVar20 << 8 | uVar9 >> 0x10 & 0xff) << 8 | uVar9 >> 8 & 0xff) << 8 | uVar9 & 0xff
                        ;
                        uVar9 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 0xf) * fVar25);
                        uVar20 = 0xff;
                        if (uVar9 < 0xff) {
                            uVar20 = uVar9;
                        }
                        uVar19 = uVar19 - 4;
                        puVar13[3] = ((uVar20 << 8 | uVar8 >> 0x10 & 0xff) << 8 | uVar8 >> 8 & 0xff) << 8 | uVar8 & 0xff
                        ;
                        puVar13 = puVar13 + 4;
                    } while (3 < (int32_t)uVar19);
                }
                for (; 0 < (int32_t)uVar19; uVar19 = uVar19 - 1) {
                    uVar20 = *puVar13;
                    uVar8 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 3) * fVar25);
                    uVar9 = 0xff;
                    if (uVar8 < 0xff) {
                        uVar9 = uVar8;
                    }
                    *puVar13 = ((uVar9 << 8 | uVar20 >> 0x10 & 0xff) << 8 | uVar20 >> 8 & 0xff) << 8 | uVar20 & 0xff;
                    puVar13 = puVar13 + 1;
                }
                uVar6 = uVar6 - 1;
                puVar17 = (uint32_t *)((int64_t)puVar17 + (int64_t)iVar16);
            } while (0 < (int32_t)uVar6);
        }
    }
    func_0x000180127510(*(undefined8 *)(unaff_RBP + 0x28), iVar10, *(undefined2 *)(iVar23 + iVar5 * 8), 
                        *(undefined2 *)(iVar23 + 2 + iVar5 * 8), *(undefined2 *)(iVar23 + 4 + iVar5 * 8));
    func_0x000180459870(*(uint64_t *)(unaff_RBP + 0x298) ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_18012d013
// Address: 0x18012d013
// Size: 3540 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Removing arg arg_74h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Removing arg arg_290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_48h

void fcn.18012d013(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_80h)
{
    float *pfVar1;
    undefined8 uVar2;
    uint16_t uVar3;
    uint16_t uVar4;
    uint16_t uVar5;
    uint16_t uVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    float *pfVar10;
    int64_t iVar11;
    undefined8 *puVar12;
    int64_t iVar13;
    undefined8 *puVar14;
    undefined uVar15;
    uint8_t uVar16;
    int32_t iVar17;
    int32_t iVar18;
    int32_t iVar19;
    int64_t iVar20;
    undefined8 *puVar21;
    int64_t **ppiVar22;
    uint8_t *puVar23;
    int64_t iVar24;
    uint32_t *puVar25;
    int64_t unaff_RBP;
    undefined8 *puVar26;
    uint8_t *puVar27;
    uint64_t uVar28;
    uint32_t *puVar29;
    uint32_t uVar30;
    int64_t iVar31;
    uint64_t uVar32;
    uint32_t uVar33;
    int32_t iVar34;
    int64_t unaff_R13;
    undefined8 *puVar35;
    int32_t iVar36;
    float *pfVar37;
    int32_t iVar38;
    undefined8 *puVar39;
    float fVar40;
    float fVar41;
    float fVar42;
    undefined auVar43 [16];
    undefined auVar44 [16];
    undefined auVar45 [16];
    float fVar46;
    float fVar47;
    float fVar48;
    float fVar49;
    float fVar50;
    float fVar51;
    float fVar52;
    uint32_t unaff_XMM11_Da;
    float fVar53;
    float unaff_XMM12_Da;
    float fVar54;
    float fVar55;
    float unaff_XMM13_Da;
    float unaff_XMM14_Da;
    undefined4 unaff_XMM14_Db;
    undefined4 unaff_XMM14_Dc;
    undefined4 unaff_XMM14_Dd;
    float unaff_XMM15_Da;
    undefined4 unaff_XMM15_Db;
    undefined4 unaff_XMM15_Dc;
    undefined4 unaff_XMM15_Dd;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_64h;
    int64_t var_50h;
    int64_t var_44h;
    int64_t var_38h;
    
    iVar20 = *(int64_t *)(unaff_RBP + -0x70);
    if (iVar20 == 0) goto code_r0x00018012cf11;
    if (arg_60h < 0x100000000) {
        *(int64_t *)(unaff_RBP + -0x70) = iVar20;
        *(int64_t *)(unaff_RBP + 0x20) = unaff_R13;
    } else {
        iVar17 = 0;
        if (arg_60h._4_4_ < 8) {
            *(int64_t *)(unaff_RBP + -0x70) = iVar20;
            *(int64_t *)(unaff_RBP + 0x20) = unaff_R13;
            iVar17 = 0;
        } else {
            uVar7 = arg_60h._4_4_ & 0x80000007;
            if ((int32_t)uVar7 < 0) {
                uVar7 = (uVar7 - 1 | 0xfffffff8) + 1;
            }
            *(int64_t *)(unaff_RBP + 0x20) = unaff_R13;
            do {
                iVar17 = iVar17 + 8;
            } while (iVar17 < (int32_t)(arg_60h._4_4_ - uVar7));
            if ((int32_t)arg_60h._4_4_ <= iVar17) goto code_r0x00018012d11d;
        }
        if (1 < (int32_t)(arg_60h._4_4_ - iVar17)) {
            do {
                iVar17 = iVar17 + 2;
            } while (iVar17 < (int32_t)(arg_60h._4_4_ - 1));
        }
    }
code_r0x00018012d11d:
    pfVar10 = (float *)func_0x00018046d050();
    *(float **)(unaff_RBP + 0x70) = pfVar10;
    if (pfVar10 != (float *)0x0) {
        iVar17 = 0;
        iVar38 = 0;
        iVar36 = 0;
        if (0 < (int32_t)arg_60h._4_4_) {
            do {
                iVar20 = iVar20 + (int64_t)iVar38 * 8;
                iVar19 = *(int32_t *)(unaff_R13 + (int64_t)iVar36 * 4);
                iVar38 = iVar38 + iVar19;
                iVar34 = iVar19 + -1;
                iVar18 = 0;
                if (0 < iVar19) {
                    do {
                        if (*(float *)(iVar20 + 4 + (int64_t)iVar34 * 8) != *(float *)(iVar20 + 4 + (int64_t)iVar18 * 8)
                           ) {
                            iVar11 = (int64_t)iVar17;
                            pfVar10[iVar11 * 5 + 4] = 0.0;
                            fVar51 = *(float *)(iVar20 + 4 + (int64_t)iVar34 * 8);
                            pfVar37 = (float *)(iVar20 + 4 + (int64_t)iVar18 * 8);
                            iVar19 = iVar18;
                            if (*pfVar37 <= fVar51 && fVar51 != *pfVar37) {
                                pfVar10[iVar11 * 5 + 4] = 1.401298e-45;
                                iVar19 = iVar34;
                                iVar34 = iVar18;
                            }
                            iVar17 = iVar17 + 1;
                            pfVar10[iVar11 * 5] =
                                 unaff_XMM12_Da * *(float *)(iVar20 + (int64_t)iVar19 * 8) + unaff_XMM15_Da;
                            pfVar10[iVar11 * 5 + 1] =
                                 (float)(unaff_XMM11_Da ^ 0x80000000) * *(float *)(iVar20 + 4 + (int64_t)iVar19 * 8) +
                                 unaff_XMM15_Da;
                            pfVar10[iVar11 * 5 + 2] =
                                 unaff_XMM12_Da * *(float *)(iVar20 + (int64_t)iVar34 * 8) + unaff_XMM15_Da;
                            pfVar10[iVar11 * 5 + 3] =
                                 (float)(unaff_XMM11_Da ^ 0x80000000) * *(float *)(iVar20 + 4 + (int64_t)iVar34 * 8) +
                                 unaff_XMM15_Da;
                        }
                        iVar19 = iVar18 + 1;
                        iVar34 = iVar18;
                        iVar18 = iVar19;
                    } while (iVar19 < *(int32_t *)(unaff_R13 + (int64_t)iVar36 * 4));
                }
                iVar20 = *(int64_t *)(unaff_RBP + -0x70);
                iVar36 = iVar36 + 1;
            } while (iVar36 < (int32_t)arg_60h._4_4_);
        }
        func_0x000180122a30(pfVar10, iVar17);
        uVar28 = 1;
        puVar26 = (undefined8 *)0x0;
        if (1 < iVar17) {
            do {
                uVar7 = (uint32_t)uVar28;
                fVar53 = pfVar10[uVar28 * 5];
                fVar51 = pfVar10[uVar28 * 5 + 1];
                uVar2 = *(undefined8 *)(pfVar10 + uVar28 * 5 + 2);
                fVar49 = pfVar10[uVar28 * 5 + 4];
                if (uVar7 < 4) goto code_r0x00018012d37c;
                do {
                    uVar30 = (uint32_t)uVar28;
                    if (pfVar10[uVar28 * 5 + -4] <= fVar51) goto code_r0x00018012d3b6;
                    pfVar1 = pfVar10 + uVar28 * 5 + -5;
                    fVar47 = pfVar1[1];
                    fVar42 = pfVar1[2];
                    fVar50 = pfVar1[3];
                    fVar46 = pfVar10[uVar28 * 5 + -1];
                    pfVar37 = pfVar10 + uVar28 * 5;
                    *pfVar37 = *pfVar1;
                    pfVar37[1] = fVar47;
                    pfVar37[2] = fVar42;
                    pfVar37[3] = fVar50;
                    pfVar10[uVar28 * 5 + 4] = fVar46;
                    if (pfVar10[uVar28 * 5 + -9] <= fVar51) {
                        uVar30 = uVar30 - 1;
                        goto code_r0x00018012d3b6;
                    }
                    pfVar37 = pfVar10 + uVar28 * 5 + -10;
                    fVar47 = pfVar37[1];
                    fVar42 = pfVar37[2];
                    fVar50 = pfVar37[3];
                    fVar46 = pfVar10[uVar28 * 5 + -6];
                    pfVar1 = pfVar10 + uVar28 * 5 + -5;
                    *pfVar1 = *pfVar37;
                    pfVar1[1] = fVar47;
                    pfVar1[2] = fVar42;
                    pfVar1[3] = fVar50;
                    pfVar10[uVar28 * 5 + -1] = fVar46;
                    if (pfVar10[uVar28 * 5 + -0xe] <= fVar51) {
                        uVar30 = uVar30 - 2;
                        goto code_r0x00018012d3b6;
                    }
                    pfVar37 = pfVar10 + uVar28 * 5 + -0xf;
                    fVar47 = pfVar37[1];
                    fVar42 = pfVar37[2];
                    fVar50 = pfVar37[3];
                    fVar46 = pfVar10[uVar28 * 5 + -0xb];
                    pfVar1 = pfVar10 + uVar28 * 5 + -10;
                    *pfVar1 = *pfVar37;
                    pfVar1[1] = fVar47;
                    pfVar1[2] = fVar42;
                    pfVar1[3] = fVar50;
                    pfVar10[uVar28 * 5 + -6] = fVar46;
                    if (pfVar10[uVar28 * 5 + -0x13] <= fVar51) {
                        uVar30 = uVar30 - 3;
                        goto code_r0x00018012d3b6;
                    }
                    fVar46 = pfVar10[uVar28 * 5 + -0x10];
                    uVar30 = uVar30 - 4;
                    pfVar37 = pfVar10 + uVar28 * 5 + -0x14;
                    fVar47 = pfVar37[1];
                    fVar42 = pfVar37[2];
                    fVar50 = pfVar37[3];
                    pfVar1 = pfVar10 + uVar28 * 5 + -0xf;
                    *pfVar1 = *pfVar37;
                    pfVar1[1] = fVar47;
                    pfVar1[2] = fVar42;
                    pfVar1[3] = fVar50;
                    pfVar10[uVar28 * 5 + -0xb] = fVar46;
                    uVar28 = (uint64_t)uVar30;
                } while (3 < (int32_t)uVar30);
                while (0 < (int32_t)uVar30) {
code_r0x00018012d37c:
                    uVar30 = (uint32_t)uVar28;
                    if (pfVar10[uVar28 * 5 + -4] <= fVar51) break;
                    pfVar1 = pfVar10 + uVar28 * 5 + -5;
                    fVar47 = pfVar1[1];
                    fVar42 = pfVar1[2];
                    fVar50 = pfVar1[3];
                    fVar46 = pfVar10[uVar28 * 5 + -1];
                    uVar30 = uVar30 - 1;
                    pfVar37 = pfVar10 + uVar28 * 5;
                    *pfVar37 = *pfVar1;
                    pfVar37[1] = fVar47;
                    pfVar37[2] = fVar42;
                    pfVar37[3] = fVar50;
                    pfVar10[uVar28 * 5 + 4] = fVar46;
                    uVar28 = (uint64_t)uVar30;
                }
code_r0x00018012d3b6:
                if (uVar7 != uVar30) {
                    iVar20 = (int64_t)(int32_t)uVar30;
                    *(undefined8 *)(pfVar10 + iVar20 * 5 + 2) = uVar2;
                    pfVar10[iVar20 * 5 + 4] = fVar49;
                    pfVar10[iVar20 * 5 + 1] = fVar51;
                    pfVar10[iVar20 * 5] = fVar53;
                }
                uVar28 = (uint64_t)(uVar7 + 1);
            } while ((int32_t)(uVar7 + 1) < iVar17);
        }
        *(undefined8 *)(unaff_RBP + 0x18) = 0;
        arg_60h._0_4_ = 0;
        *(undefined8 *)(unaff_RBP + -0x38) = 0;
        arg_70h._0_4_ = 0;
        iVar36 = arg_68h._4_4_ + 1;
        *(float **)(unaff_RBP + 0x40) = pfVar10;
        if (iVar36 < 0x41) {
            iVar20 = unaff_RBP + 0x80;
        } else {
            iVar20 = func_0x00018046d050((int64_t)(iVar36 * 2 + 1) << 2);
        }
        iVar38 = *(int32_t *)(unaff_RBP + 0x290);
        *(int64_t *)(unaff_RBP + 0x38) = iVar20;
        iVar13 = (int64_t)iVar36 * 4;
        iVar36 = *(int32_t *)(unaff_RBP + -0x68);
        *(int32_t *)(unaff_RBP + -0x78) = iVar36;
        *(int64_t *)(unaff_RBP + 0x68) = iVar13;
        iVar11 = iVar13 + iVar20;
        *(int64_t *)(unaff_RBP + 0x60) = iVar11;
        pfVar10[(int64_t)iVar17 * 5 + 1] = (float)(iVar36 + iVar38) + unaff_XMM14_Da;
        auVar43 = *(undefined (*) [16])0x180646c10;
        if (0 < iVar38) {
            iVar17 = arg_68h._4_4_ + 1;
            *(int64_t *)(unaff_RBP + 0x58) = (int64_t)(arg_68h._4_4_ + 2) << 2;
            arg_60h._4_4_ = 0;
            puVar35 = puVar26;
            puVar39 = puVar26;
            do {
                fVar51 = (float)iVar36 + unaff_XMM14_Da;
                fVar53 = (float)iVar36 + unaff_XMM15_Da;
                func_0x0001804986e0(iVar20, 0, iVar13);
                func_0x0001804986e0(iVar11, 0, *(undefined8 *)(unaff_RBP + 0x58));
                if (puVar39 != (undefined8 *)0x0) {
                    puVar14 = (undefined8 *)(unaff_RBP + -0x38);
                    do {
                        puVar12 = puVar39;
                        if (*(float *)((int64_t)puVar39 + 0x1c) <= fVar53) {
                            *puVar14 = *puVar39;
                            *puVar39 = puVar35;
                            *(undefined4 *)((int64_t)puVar39 + 0x14) = 0;
                            puVar12 = puVar14;
                            puVar35 = puVar39;
                        }
                        puVar39 = (undefined8 *)*puVar12;
                        puVar14 = puVar12;
                    } while (puVar39 != (undefined8 *)0x0);
                    puVar39 = *(undefined8 **)(unaff_RBP + -0x38);
                }
                if (pfVar10[1] <= fVar51) {
                    puVar14 = *(undefined8 **)(unaff_RBP + 0x18);
                    iVar17 = *(int32_t *)(unaff_RBP + -0x68);
                    pfVar37 = pfVar10;
                    do {
                        iVar36 = (int32_t)puVar26;
                        if (pfVar37[1] != pfVar37[3]) {
                            puVar12 = puVar14;
                            if (puVar35 == (undefined8 *)0x0) {
                                if (iVar36 == 0) {
                                    puVar12 = (undefined8 *)func_0x00018046d050(0x6408);
                                    if (puVar12 == (undefined8 *)0x0) goto code_r0x00018012d652;
                                    *puVar12 = puVar14;
                                    iVar36 = 800;
                                }
                                puVar26 = (undefined8 *)(uint64_t)(iVar36 - 1U);
                                puVar21 = puVar12 + (int64_t)(int32_t)(iVar36 - 1U) * 4 + 1;
                                puVar14 = puVar12;
                                if (puVar21 == (undefined8 *)0x0) goto code_r0x00018012d652;
                            } else {
                                puVar21 = puVar35;
                                puVar35 = (undefined8 *)*puVar35;
                            }
                            fVar46 = (pfVar37[2] - *pfVar37) / (pfVar37[3] - pfVar37[1]);
                            *(float *)((int64_t)puVar21 + 0xc) = fVar46;
                            fVar49 = unaff_XMM15_Da;
                            if (fVar46 != unaff_XMM15_Da) {
                                fVar49 = unaff_XMM14_Da / fVar46;
                            }
                            *(float *)(puVar21 + 2) = fVar49;
                            *(float *)(puVar21 + 1) =
                                 ((fVar53 - pfVar37[1]) * fVar46 + *pfVar37) - (float)*(int32_t *)(unaff_RBP + -0x48);
                            fVar49 = unaff_XMM14_Da;
                            if (pfVar37[4] == 0.0) {
                                fVar49 = -1.0;
                            }
                            *(float *)((int64_t)puVar21 + 0x14) = fVar49;
                            *(float *)(puVar21 + 3) = pfVar37[1];
                            fVar49 = pfVar37[3];
                            *(float *)((int64_t)puVar21 + 0x1c) = fVar49;
                            if ((((int32_t)arg_70h == 0) && (iVar17 != 0)) && (fVar49 < fVar53)) {
                                *(float *)((int64_t)puVar21 + 0x1c) = fVar53;
                            }
                            *puVar21 = puVar39;
                            *(undefined8 **)(unaff_RBP + -0x38) = puVar21;
                            puVar14 = puVar12;
                            puVar39 = puVar21;
                        }
code_r0x00018012d652:
                        pfVar10 = pfVar37 + 5;
                        pfVar1 = pfVar37 + 6;
                        pfVar37 = pfVar10;
                    } while (*pfVar1 <= fVar51);
                    iVar20 = *(int64_t *)(unaff_RBP + 0x38);
                    iVar11 = *(int64_t *)(unaff_RBP + 0x60);
                    *(undefined8 **)(unaff_RBP + 0x18) = puVar14;
                    iVar17 = *(int32_t *)(unaff_RBP + -0x44);
                    arg_60h._0_4_ = (uint32_t)puVar26;
                    *(float **)(unaff_RBP + 0x40) = pfVar10;
                }
                if (puVar39 != (undefined8 *)0x0) {
                    fVar51 = fVar53 + 1.0;
                    puVar14 = puVar39;
                    do {
                        fVar49 = *(float *)((int64_t)puVar14 + 0xc);
                        fVar46 = *(float *)(puVar14 + 1);
                        if (fVar49 == unaff_XMM15_Da) {
                            if (fVar46 < (float)iVar17) {
                                if (fVar46 < unaff_XMM15_Da) {
                                    func_0x0001801228f0(iVar11);
                                } else {
                                    func_0x0001801228f0(iVar20);
                                    func_0x0001801228f0(iVar11);
                                }
                            }
                        } else {
                            fVar47 = *(float *)(puVar14 + 3);
                            fVar54 = fVar49 + fVar46;
                            fVar50 = fVar46;
                            fVar42 = fVar53;
                            if (fVar53 < fVar47) {
                                fVar50 = (fVar47 - fVar53) * fVar49 + fVar46;
                                fVar42 = fVar47;
                            }
                            fVar47 = *(float *)((int64_t)puVar14 + 0x1c);
                            fVar40 = fVar51;
                            fVar52 = fVar54;
                            if (fVar47 < fVar51) {
                                fVar40 = fVar47;
                                fVar52 = (fVar47 - fVar53) * fVar49 + fVar46;
                            }
                            if (((fVar50 < unaff_XMM15_Da) || (fVar52 < unaff_XMM15_Da)) ||
                               (((float)iVar17 <= fVar50 || ((float)iVar17 <= fVar52)))) {
                                uVar28 = 0;
                                if (0 < iVar17) {
                                    do {
                                        uVar7 = (int32_t)uVar28 + 1;
                                        uVar32 = (uint64_t)uVar7;
                                        fVar47 = (float)(int32_t)uVar28;
                                        fVar49 = (float)uVar7;
                                        if ((fVar47 <= fVar46) || (fVar54 <= fVar49)) {
                                            if ((fVar47 <= fVar54) || (fVar46 <= fVar49)) {
                                                if (((fVar46 < fVar47) && (fVar47 < fVar54)) ||
                                                   ((fVar54 < fVar47 && (fVar47 < fVar46)))) {
                                                    func_0x0001801228f0(iVar20);
                                                } else if (((fVar46 < fVar49) && (fVar49 < fVar54)) ||
                                                          ((fVar54 < fVar49 && (fVar49 < fVar46)))) {
                                                    func_0x0001801228f0(iVar20);
                                                }
                                            } else {
                                                func_0x0001801228f0(iVar20);
                                                func_0x0001801228f0();
                                            }
                                        } else {
                                            func_0x0001801228f0(iVar20);
                                            func_0x0001801228f0();
                                        }
                                        func_0x0001801228f0(iVar20);
                                        uVar28 = uVar32 & 0xffffffff;
                                    } while ((int32_t)uVar32 < iVar17);
                                }
                            } else {
                                iVar36 = (int32_t)fVar50;
                                if (iVar36 == (int32_t)fVar52) {
                                    iVar13 = (int64_t)iVar36;
                                    fVar49 = (fVar40 - fVar42) * *(float *)((int64_t)puVar14 + 0x14);
                                    *(float *)(iVar20 + iVar13 * 4) =
                                         ((((float)iVar36 + 1.0) - fVar52) + (((float)iVar36 + 1.0) - fVar50)) * 0.5 *
                                         fVar49 + *(float *)(iVar20 + iVar13 * 4);
                                    *(float *)(iVar11 + 4 + iVar13 * 4) = fVar49 + *(float *)(iVar11 + 4 + iVar13 * 4);
                                } else {
                                    fVar49 = *(float *)(puVar14 + 2);
                                    fVar47 = fVar50;
                                    if (fVar52 < fVar50) {
                                        fVar46 = fVar40 - fVar53;
                                        fVar49 = (float)((uint32_t)fVar49 ^ 0x80000000);
                                        fVar40 = fVar51 - (fVar42 - fVar53);
                                        fVar42 = fVar51 - fVar46;
                                        fVar47 = fVar52;
                                        fVar46 = fVar54;
                                        fVar52 = fVar50;
                                    }
                                    fVar50 = *(float *)((int64_t)puVar14 + 0x14);
                                    iVar19 = (int32_t)fVar47;
                                    iVar38 = (int32_t)fVar52;
                                    iVar36 = iVar19 + 1;
                                    fVar55 = (float)iVar38;
                                    fVar41 = ((float)iVar36 - fVar46) * fVar49 + fVar53;
                                    fVar54 = (fVar55 - fVar46) * fVar49 + fVar53;
                                    fVar46 = fVar51;
                                    if (fVar41 <= fVar51) {
                                        fVar46 = fVar41;
                                    }
                                    fVar41 = (fVar46 - fVar42) * fVar50;
                                    *(float *)(iVar20 + (int64_t)iVar19 * 4) =
                                         ((float)iVar36 - fVar47) * fVar41 * 0.5 +
                                         *(float *)(iVar20 + (int64_t)iVar19 * 4);
                                    if ((fVar51 < fVar54) &&
                                       (iVar19 = (iVar38 - iVar19) + -1, fVar54 = fVar51, iVar19 != 0)) {
                                        fVar49 = (fVar51 - fVar46) / (float)iVar19;
                                    }
                                    if (iVar36 < iVar38) {
                                        fVar49 = fVar49 * fVar50;
                                        fVar46 = fVar49 * 0.5;
                                        if (3 < iVar38 - iVar36) {
                                            do {
                                                iVar13 = (int64_t)iVar36;
                                                iVar36 = iVar36 + 4;
                                                *(float *)(iVar20 + iVar13 * 4) =
                                                     fVar41 + fVar46 + *(float *)(iVar20 + iVar13 * 4);
                                                fVar47 = fVar41 + fVar49 + fVar49;
                                                *(float *)(iVar20 + 4 + iVar13 * 4) =
                                                     fVar46 + fVar41 + fVar49 + *(float *)(iVar20 + 4 + iVar13 * 4);
                                                fVar48 = fVar47 + fVar49;
                                                *(float *)(iVar20 + 8 + iVar13 * 4) =
                                                     fVar46 + fVar47 + *(float *)(iVar20 + 8 + iVar13 * 4);
                                                fVar41 = fVar48 + fVar49;
                                                *(float *)(iVar20 + 0xc + iVar13 * 4) =
                                                     fVar46 + fVar48 + *(float *)(iVar20 + 0xc + iVar13 * 4);
                                            } while (iVar36 < iVar38 + -3);
                                        }
                                        for (; iVar36 < iVar38; iVar36 = iVar36 + 1) {
    // WARNING: Read-only address (ram,0x000180646c10) is written
                                            fVar47 = fVar41 + fVar46;
                                            fVar41 = fVar41 + fVar49;
                                            *(float *)(iVar20 + (int64_t)iVar36 * 4) =
                                                 fVar47 + *(float *)(iVar20 + (int64_t)iVar36 * 4);
                                        }
                                    }
                                    iVar13 = (int64_t)iVar38;
                                    *(float *)(iVar20 + iVar13 * 4) =
                                         (((fVar55 + 1.0) - fVar52) + ((fVar55 + 1.0) - fVar55)) * 0.5 *
                                         (fVar40 - fVar54) * fVar50 + fVar41 + *(float *)(iVar20 + iVar13 * 4);
                                    *(float *)(iVar11 + 4 + iVar13 * 4) =
                                         (fVar40 - fVar42) * fVar50 + *(float *)(iVar11 + 4 + iVar13 * 4);
                                }
                            }
                        }
                        unaff_XMM13_Da = 0.5;
                        puVar14 = (undefined8 *)*puVar14;
                    } while (puVar14 != (undefined8 *)0x0);
                    unaff_XMM14_Da = 1.0;
                    unaff_XMM14_Db = 0;
                    unaff_XMM14_Dc = 0;
                    unaff_XMM14_Dd = 0;
                    auVar43 = *(undefined (*) [16])0x180646c10;
                }
                iVar36 = 0;
                auVar45._4_4_ = unaff_XMM15_Db;
                auVar45._0_4_ = unaff_XMM15_Da;
                auVar45._8_4_ = unaff_XMM15_Dc;
                auVar45._12_4_ = unaff_XMM15_Dd;
                uVar7 = auVar43._0_4_;
                if (iVar17 < 4) {
                    if (0 < iVar17) goto code_r0x00018012dce2;
                } else {
                    iVar13 = *(int64_t *)(unaff_RBP + -0x50);
                    do {
                        iVar31 = (int64_t)iVar36;
                        iVar24 = (int64_t)(int32_t)(iVar36 + arg_60h._4_4_);
                        fVar51 = auVar45._0_4_ + *(float *)(iVar11 + iVar31 * 4);
                        iVar38 = (int32_t)((float)((uint32_t)(fVar51 + *(float *)(iVar20 + iVar31 * 4)) & uVar7) * 255.0
                                          + unaff_XMM13_Da);
                        uVar15 = (undefined)iVar38;
                        if (0xff < iVar38) {
                            uVar15 = 0xff;
                        }
                        *(undefined *)(iVar24 + iVar13) = uVar15;
                        fVar51 = fVar51 + *(float *)(iVar11 + 4 + iVar31 * 4);
                        iVar38 = (int32_t)((float)((uint32_t)(fVar51 + *(float *)(iVar20 + 4 + iVar31 * 4)) & uVar7) *
                                           255.0 + unaff_XMM13_Da);
                        uVar15 = (undefined)iVar38;
                        if (0xff < iVar38) {
                            uVar15 = 0xff;
                        }
                        *(undefined *)(iVar24 + 1 + iVar13) = uVar15;
                        fVar51 = fVar51 + *(float *)(iVar11 + 8 + iVar31 * 4);
                        iVar38 = (int32_t)((float)((uint32_t)(fVar51 + *(float *)(iVar20 + 8 + iVar31 * 4)) & uVar7) *
                                           255.0 + unaff_XMM13_Da);
                        uVar15 = (undefined)iVar38;
                        if (0xff < iVar38) {
                            uVar15 = 0xff;
                        }
                        *(undefined *)(iVar24 + 2 + iVar13) = uVar15;
                        auVar45._0_4_ = fVar51 + *(float *)(iVar11 + 0xc + iVar31 * 4);
                        iVar38 = (int32_t)((float)((uint32_t)(auVar45._0_4_ + *(float *)(iVar20 + 0xc + iVar31 * 4)) &
                                                  uVar7) * 255.0 + unaff_XMM13_Da);
                        if (0xff < iVar38) {
                            iVar38 = 0xff;
                        }
                        iVar36 = iVar36 + 4;
                        *(char *)(iVar24 + 3 + iVar13) = (char)iVar38;
                    } while (iVar36 < iVar17 + -3);
                    iVar17 = *(int32_t *)(unaff_RBP + -0x44);
                    puVar26 = (undefined8 *)(uint64_t)(uint32_t)arg_60h;
                    if (iVar36 < iVar17) {
code_r0x00018012dce2:
                        iVar13 = *(int64_t *)(unaff_RBP + -0x50);
                        do {
                            auVar45._0_4_ = auVar45._0_4_ + *(float *)(iVar11 + (int64_t)iVar36 * 4);
                            iVar38 = arg_60h._4_4_ + iVar36;
                            iVar19 = (int32_t)((float)((uint32_t)
                                                       (auVar45._0_4_ + *(float *)(iVar20 + (int64_t)iVar36 * 4)) &
                                                      uVar7) * 255.0 + unaff_XMM13_Da);
                            if (0xff < iVar19) {
                                iVar19 = 0xff;
                            }
                            iVar36 = iVar36 + 1;
                            *(char *)(iVar38 + iVar13) = (char)iVar19;
                        } while (iVar36 < iVar17);
                        pfVar10 = *(float **)(unaff_RBP + 0x40);
                        puVar26 = (undefined8 *)(uint64_t)(uint32_t)arg_60h;
                    }
                }
                if (puVar39 != (undefined8 *)0x0) {
                    ppiVar22 = (int64_t **)(unaff_RBP + -0x38);
                    puVar14 = puVar39;
                    do {
                        *(float *)(puVar14 + 1) = *(float *)((int64_t)puVar14 + 0xc) + *(float *)(puVar14 + 1);
                        ppiVar22 = (int64_t **)*ppiVar22;
                        puVar14 = *ppiVar22;
                    } while (puVar14 != (undefined8 *)0x0);
                }
                iVar36 = *(int32_t *)(unaff_RBP + -0x78) + 1;
                arg_60h._4_4_ = arg_60h._4_4_ + arg_70h._4_4_;
                arg_70h._0_4_ = (int32_t)arg_70h + 1;
                iVar13 = *(int64_t *)(unaff_RBP + 0x68);
                *(int32_t *)(unaff_RBP + -0x78) = iVar36;
            } while ((int32_t)arg_70h < *(int32_t *)(unaff_RBP + 0x290));
            pfVar10 = *(float **)(unaff_RBP + 0x70);
        }
        puVar26 = *(undefined8 **)(unaff_RBP + 0x18);
        while (puVar26 != (undefined8 *)0x0) {
            puVar39 = (undefined8 *)*puVar26;
            func_0x000180460d90(puVar26);
            puVar26 = puVar39;
        }
        if (iVar20 != unaff_RBP + 0x80) {
            func_0x000180460d90(iVar20);
        }
        func_0x000180460d90(pfVar10);
        iVar20 = *(int64_t *)(unaff_RBP + -0x70);
        unaff_R13 = *(int64_t *)(unaff_RBP + 0x20);
    }
    func_0x000180460d90(unaff_R13);
    func_0x000180460d90(iVar20);
code_r0x00018012cf11:
    fVar51 = *(float *)(unaff_RBP + -100);
    fVar53 = *(float *)(unaff_RBP + -0x60);
    fVar49 = *(float *)(unaff_RBP + -0x5c);
    func_0x000180460d90(*(undefined8 *)(unaff_RBP + -0x80));
    iVar20 = *(int64_t *)(unaff_RBP + -0x50);
    if (1 < (int32_t)(uint32_t)arg_68h) {
        iVar17 = 0;
        *(undefined8 *)(unaff_RBP + 0x290) = 0;
        if (0 < *(int32_t *)(unaff_RBP + -0x58)) {
            iVar36 = *(int32_t *)(unaff_RBP + -0x58);
            do {
                func_0x0001804986e0(unaff_RBP + 0x290, 0, (uint32_t)arg_68h);
                uVar32 = 0;
                uVar28 = 0;
                if ((uint32_t)arg_68h == 2) {
                    uVar30 = 0;
                    uVar7 = 0;
                    if (-1 < arg_68h._4_4_) {
                        do {
                            iVar11 = (int64_t)(int32_t)uVar30;
                            uVar16 = *(uint8_t *)(iVar20 + iVar11);
                            uVar7 = uVar30 + 2;
                            uVar33 = (int32_t)uVar32 +
                                     ((uint32_t)uVar16 -
                                     (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar30 & 7)));
                            uVar32 = (uint64_t)uVar33;
                            uVar30 = uVar30 + 1;
                            *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar7 & 7)) = uVar16;
                            *(char *)(iVar20 + iVar11) = (char)(uVar33 >> 1);
                            uVar28 = uVar32;
                            uVar7 = uVar30;
                        } while ((int32_t)uVar30 <= arg_68h._4_4_);
                    }
                } else if ((uint32_t)arg_68h == 3) {
                    uVar30 = 0;
                    uVar7 = 0;
                    if (-1 < arg_68h._4_4_) {
                        do {
                            iVar11 = (int64_t)(int32_t)uVar30;
                            uVar16 = *(uint8_t *)(iVar20 + iVar11);
                            uVar7 = uVar30 + 3;
                            uVar32 = (uint64_t)
                                     ((int32_t)uVar32 +
                                     ((uint32_t)uVar16 -
                                     (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar30 & 7))));
                            uVar30 = uVar30 + 1;
                            *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar7 & 7)) = uVar16;
                            *(char *)(iVar20 + iVar11) = (char)(uVar32 / 3);
                            uVar28 = uVar32;
                            uVar7 = uVar30;
                        } while ((int32_t)uVar30 <= arg_68h._4_4_);
                    }
                } else if ((uint32_t)arg_68h == 4) {
                    uVar30 = 0;
                    uVar7 = 0;
                    if (-1 < arg_68h._4_4_) {
                        do {
                            iVar11 = (int64_t)(int32_t)uVar30;
                            uVar16 = *(uint8_t *)(iVar20 + iVar11);
                            uVar7 = uVar30 - 4;
                            uVar33 = (int32_t)uVar32 +
                                     ((uint32_t)uVar16 -
                                     (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar30 & 7)));
                            uVar32 = (uint64_t)uVar33;
                            uVar30 = uVar30 + 1;
                            *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar7 & 7)) = uVar16;
                            *(char *)(iVar20 + iVar11) = (char)(uVar33 >> 2);
                            uVar28 = uVar32;
                            uVar7 = uVar30;
                        } while ((int32_t)uVar30 <= arg_68h._4_4_);
                    }
                } else {
                    uVar7 = 0;
                    uVar28 = uVar32;
                    if ((uint32_t)arg_68h == 5) {
                        if (-1 < arg_68h._4_4_) {
                            do {
                                iVar11 = (int64_t)(int32_t)uVar7;
                                uVar16 = *(uint8_t *)(iVar20 + iVar11);
                                uVar30 = uVar7 - 3;
                                uVar32 = (uint64_t)
                                         ((int32_t)uVar32 +
                                         ((uint32_t)uVar16 -
                                         (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar7 & 7))));
                                uVar7 = uVar7 + 1;
                                *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar30 & 7)) = uVar16;
                                *(char *)(iVar20 + iVar11) = (char)(uVar32 / 5);
                                uVar28 = uVar32;
                            } while ((int32_t)uVar7 <= arg_68h._4_4_);
                        }
                    } else if (-1 < arg_68h._4_4_) {
                        do {
                            iVar11 = (int64_t)(int32_t)uVar7;
                            uVar16 = *(uint8_t *)(iVar20 + iVar11);
                            uVar30 = uVar7 + (uint32_t)arg_68h;
                            uVar33 = (int32_t)uVar32 +
                                     ((uint32_t)uVar16 -
                                     (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar7 & 7)));
                            uVar32 = (uint64_t)uVar33;
                            uVar7 = uVar7 + 1;
                            *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar30 & 7)) = uVar16;
                            *(char *)(iVar20 + iVar11) = (char)(uVar33 / (uint32_t)arg_68h);
                            uVar28 = uVar32;
                        } while ((int32_t)uVar7 <= arg_68h._4_4_);
                    }
                }
                for (; (int32_t)uVar7 < arg_70h._4_4_; uVar7 = uVar7 + 1) {
    // WARNING: Read-only address (ram,0x000180646c10) is written
                    uVar30 = (int32_t)uVar28 - (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar7 & 7));
                    *(char *)(iVar20 + (int32_t)uVar7) = (char)(uVar30 / (uint32_t)arg_68h);
                    uVar28 = (uint64_t)uVar30;
                }
    // WARNING: Read-only address (ram,0x000180646c10) is written
                iVar20 = iVar20 + arg_70h._4_4_;
                iVar17 = iVar17 + 1;
            } while (iVar17 < iVar36);
            iVar20 = *(int64_t *)(unaff_RBP + -0x50);
        }
    }
    if (1 < (int32_t)arg_78h._4_4_) {
        iVar17 = 0;
        *(undefined8 *)(unaff_RBP + 0x290) = 0;
        if (0 < arg_70h._4_4_) {
            do {
                func_0x0001804986e0(unaff_RBP + 0x290, 0, arg_78h._4_4_);
                uVar32 = 0;
                uVar28 = 0;
                if (arg_78h._4_4_ == 2) {
                    uVar30 = 0;
                    uVar7 = 0;
                    if (-1 < (int32_t)arg_78h) {
                        do {
                            iVar36 = uVar30 * arg_70h._4_4_;
                            uVar16 = *(uint8_t *)(iVar36 + iVar20);
                            uVar33 = (int32_t)uVar32 +
                                     ((uint32_t)uVar16 -
                                     (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar30 & 7)));
                            uVar32 = (uint64_t)uVar33;
                            uVar7 = uVar30 + 2;
                            uVar30 = uVar30 + 1;
                            *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar7 & 7)) = uVar16;
                            *(char *)(iVar36 + iVar20) = (char)(uVar33 >> 1);
                            uVar28 = uVar32;
                            uVar7 = uVar30;
                        } while ((int32_t)uVar30 <= (int32_t)arg_78h);
                    }
                } else if (arg_78h._4_4_ == 3) {
                    uVar30 = 0;
                    uVar7 = 0;
                    if (-1 < (int32_t)arg_78h) {
                        do {
                            iVar36 = uVar30 * arg_70h._4_4_;
                            uVar16 = *(uint8_t *)(iVar36 + iVar20);
                            uVar32 = (uint64_t)
                                     ((int32_t)uVar32 +
                                     ((uint32_t)uVar16 -
                                     (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar30 & 7))));
                            uVar7 = uVar30 + 3;
                            uVar30 = uVar30 + 1;
                            *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar7 & 7)) = uVar16;
                            *(char *)(iVar36 + iVar20) = (char)(uVar32 / 3);
                            uVar28 = uVar32;
                            uVar7 = uVar30;
                        } while ((int32_t)uVar30 <= (int32_t)arg_78h);
                    }
                } else if (arg_78h._4_4_ == 4) {
                    uVar30 = 0;
                    uVar7 = 0;
                    if (-1 < (int32_t)arg_78h) {
                        do {
                            iVar36 = uVar30 * arg_70h._4_4_;
                            uVar16 = *(uint8_t *)(iVar36 + iVar20);
                            uVar33 = (int32_t)uVar32 +
                                     ((uint32_t)uVar16 -
                                     (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar30 & 7)));
                            uVar32 = (uint64_t)uVar33;
                            uVar7 = uVar30 - 4;
                            uVar30 = uVar30 + 1;
                            *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar7 & 7)) = uVar16;
                            *(char *)(iVar36 + iVar20) = (char)(uVar33 >> 2);
                            uVar28 = uVar32;
                            uVar7 = uVar30;
                        } while ((int32_t)uVar30 <= (int32_t)arg_78h);
                    }
                } else {
                    uVar30 = 0;
                    uVar28 = uVar32;
                    if (arg_78h._4_4_ == 5) {
                        uVar7 = 0;
                        if (-1 < (int32_t)arg_78h) {
                            do {
                                iVar36 = uVar30 * arg_70h._4_4_;
                                uVar16 = *(uint8_t *)(iVar36 + iVar20);
                                uVar32 = (uint64_t)
                                         ((int32_t)uVar32 +
                                         ((uint32_t)uVar16 -
                                         (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar30 & 7))));
                                uVar7 = uVar30 - 3;
                                uVar30 = uVar30 + 1;
                                *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar7 & 7)) = uVar16;
                                *(char *)(iVar36 + iVar20) = (char)(uVar32 / 5);
                                uVar28 = uVar32;
                                uVar7 = uVar30;
                            } while ((int32_t)uVar30 <= (int32_t)arg_78h);
                        }
                    } else {
                        uVar7 = uVar30;
                        if (-1 < (int32_t)arg_78h) {
                            do {
                                iVar36 = uVar30 * arg_70h._4_4_;
                                uVar16 = *(uint8_t *)(iVar36 + iVar20);
                                uVar33 = (int32_t)uVar32 +
                                         ((uint32_t)uVar16 -
                                         (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar30 & 7)));
                                uVar28 = (uint64_t)uVar33;
                                uVar7 = uVar30 + arg_78h._4_4_;
                                uVar30 = uVar30 + 1;
                                *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar7 & 7)) = uVar16;
                                *(char *)(iVar36 + iVar20) = (char)(uVar33 / arg_78h._4_4_);
                                uVar32 = uVar28;
                                uVar7 = uVar30;
                            } while ((int32_t)uVar30 <= (int32_t)arg_78h);
                        }
                    }
                }
                iVar36 = *(int32_t *)(unaff_RBP + -0x58);
                for (; (int32_t)uVar7 < iVar36; uVar7 = uVar7 + 1) {
    // WARNING: Read-only address (ram,0x000180646c10) is written
                    uVar30 = (int32_t)uVar28 - (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar7 & 7));
                    uVar28 = (uint64_t)uVar30;
                    *(char *)((int32_t)(uVar7 * arg_70h._4_4_) + iVar20) = (char)(uVar30 / arg_78h._4_4_);
                }
    // WARNING: Read-only address (ram,0x000180646c10) is written
                iVar20 = iVar20 + 1;
                iVar17 = iVar17 + 1;
            } while (iVar17 < arg_70h._4_4_);
        }
    }
    fVar46 = unaff_XMM15_Da;
    if ((uint32_t)arg_68h != 0) {
        fVar46 = (float)(1 - (uint32_t)arg_68h) / (fVar49 + fVar49);
    }
    fVar47 = unaff_XMM15_Da;
    if (arg_78h._4_4_ != 0) {
        fVar47 = (float)(1 - arg_78h._4_4_) / (fVar53 + fVar53);
    }
    iVar20 = *(int64_t *)(unaff_RBP + 0x78);
    fVar42 = *(float *)(**(int64_t **)(*(int64_t *)(iVar20 + 0x58) + 0x28) + 0x3c);
    if (fVar42 == unaff_XMM15_Da) {
        uVar28 = CONCAT44(unaff_XMM14_Db, unaff_XMM14_Da);
    } else {
        unaff_XMM14_Dc = 0;
        unaff_XMM14_Dd = 0;
        uVar28 = (uint64_t)(uint32_t)(*(float *)(iVar20 + 0x14) / fVar42);
    }
    auVar43._8_4_ = unaff_XMM14_Dc;
    auVar43._0_8_ = uVar28;
    auVar43._12_4_ = unaff_XMM14_Dd;
    auVar44._4_12_ = auVar43._4_12_;
    auVar44._0_4_ = (float)uVar28 * *(float *)(*(int64_t *)(unaff_RBP + 0x50) + 0x50) + unaff_XMM13_Da;
    fVar42 = (float)func_0x0001800f4120(auVar44._0_8_);
    fVar42 = fVar42 + fVar46;
    fVar46 = (float)func_0x0001800f4120();
    puVar29 = *(uint32_t **)(unaff_RBP + 0x48);
    iVar11 = *(int64_t *)(unaff_RBP + 0x30);
    iVar13 = *(int64_t *)(unaff_RBP + -0x30);
    iVar17 = *(int32_t *)(unaff_RBP + -0x40);
    iVar36 = *(int32_t *)(unaff_RBP + -0x3c);
    iVar24 = *(int64_t *)(unaff_RBP + 0x28);
    fVar49 = unaff_XMM14_Da / (fVar49 * fVar51);
    fVar46 = fVar46 + (float)(int32_t)(*(float *)(iVar20 + 0x44) + unaff_XMM13_Da) + fVar47;
    fVar51 = unaff_XMM14_Da / (fVar53 * fVar51);
    puVar29[2] = (uint32_t)((float)iVar17 * fVar49 + fVar42);
    puVar29[3] = (uint32_t)((float)iVar36 * fVar51 + fVar46);
    puVar29[4] = (uint32_t)((float)((uint32_t)*(uint16_t *)(iVar13 + 4 + iVar11 * 8) + iVar17) * fVar49 + fVar42);
    uVar3 = *(uint16_t *)(iVar13 + 6 + iVar11 * 8);
    *puVar29 = *puVar29 | 2;
    puVar29[10] = *(uint32_t *)(unaff_RBP + 0x10);
    puVar29[5] = (uint32_t)((float)((uint32_t)uVar3 + iVar36) * fVar51 + fVar46);
    iVar20 = *(int64_t *)(iVar24 + 0x38);
    uVar3 = *(uint16_t *)(iVar13 + 2 + iVar11 * 8);
    uVar4 = *(uint16_t *)(iVar13 + iVar11 * 8);
    uVar5 = *(uint16_t *)(iVar13 + 6 + iVar11 * 8);
    uVar7 = (uint32_t)uVar5;
    iVar17 = *(int32_t *)(iVar20 + 0x1c);
    iVar38 = *(int32_t *)(iVar20 + 0x24) * *(int32_t *)(iVar20 + 0x1c);
    iVar36 = *(int32_t *)(iVar20 + 0x18);
    uVar6 = *(uint16_t *)(iVar13 + 4 + iVar11 * 8);
    *(int64_t *)(unaff_RBP + 0x30) = iVar20;
    puVar29 = (uint32_t *)
              ((int64_t)(int32_t)(((uint32_t)uVar3 * iVar17 + (uint32_t)uVar4) * *(int32_t *)(iVar20 + 0x24)) +
              *(int64_t *)(iVar20 + 0x28));
    if (iVar36 == 1) {
        if (uVar5 != 0) {
            iVar20 = *(int64_t *)(unaff_RBP + -0x50);
            do {
                func_0x000180498030(puVar29, iVar20, (uint32_t)uVar6);
                uVar7 = uVar7 - 1;
                iVar20 = iVar20 + arg_70h._4_4_;
                puVar29 = (uint32_t *)((int64_t)puVar29 + (int64_t)iVar38);
            } while (0 < (int32_t)uVar7);
            iVar20 = *(int64_t *)(unaff_RBP + 0x30);
            iVar13 = *(int64_t *)(unaff_RBP + -0x30);
        }
    } else if ((iVar36 == 0) && (uVar7 != 0)) {
        puVar27 = *(uint8_t **)(unaff_RBP + -0x50);
        do {
            puVar23 = puVar27;
            puVar25 = puVar29;
            uVar30 = (uint32_t)uVar6;
            if (uVar6 != 0) {
                do {
                    uVar16 = *puVar23;
                    puVar23 = puVar23 + 1;
                    uVar30 = uVar30 - 1;
                    *puVar25 = (uint32_t)uVar16 << 0x18 | 0xffffff;
                    puVar25 = puVar25 + 1;
                } while (0 < (int32_t)uVar30);
            }
            uVar7 = uVar7 - 1;
            puVar27 = puVar27 + arg_70h._4_4_;
            puVar29 = (uint32_t *)((int64_t)puVar29 + (int64_t)iVar38);
        } while (0 < (int32_t)uVar7);
    }
    uVar3 = *(uint16_t *)(iVar13 + 4 + iVar11 * 8);
    fVar51 = *(float *)(*(int64_t *)(unaff_RBP + 0x50) + 0x6c);
    if (fVar51 != unaff_XMM14_Da) {
        uVar4 = *(uint16_t *)(iVar13 + 6 + iVar11 * 8);
        uVar7 = (uint32_t)uVar4;
        iVar17 = *(int32_t *)(iVar20 + 0x1c) * *(int32_t *)(iVar20 + 0x24);
        puVar29 = (uint32_t *)
                  ((int64_t)(int32_t)(((uint32_t)*(uint16_t *)(iVar13 + 2 + iVar11 * 8) * *(int32_t *)(iVar20 + 0x1c) +
                                      (uint32_t)*(uint16_t *)(iVar13 + iVar11 * 8)) * *(int32_t *)(iVar20 + 0x24)) +
                  *(int64_t *)(iVar20 + 0x28));
        if (*(int32_t *)(iVar20 + 0x18) == 1) {
            if (uVar4 != 0) {
                do {
                    uVar30 = (uint32_t)uVar3;
                    puVar25 = puVar29;
                    if (3 < uVar30) {
                        do {
                            uVar16 = 0xff;
                            if ((uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar25 * fVar51) < 0xff) {
                                uVar16 = (uint8_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar25 * fVar51);
                            }
                            *(uint8_t *)puVar25 = uVar16;
                            iVar24 = (int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar25 + 1) * fVar51);
                            uVar16 = 0xff;
                            if ((uint32_t)iVar24 < 0xff) {
                                uVar16 = (uint8_t)iVar24;
                            }
                            *(uint8_t *)((int64_t)puVar25 + 1) = uVar16;
                            iVar24 = (int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar25 + 2) * fVar51);
                            uVar16 = 0xff;
                            if ((uint32_t)iVar24 < 0xff) {
                                uVar16 = (uint8_t)iVar24;
                            }
                            *(uint8_t *)((int64_t)puVar25 + 2) = uVar16;
                            iVar24 = (int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar25 + 3) * fVar51);
                            uVar16 = 0xff;
                            if ((uint32_t)iVar24 < 0xff) {
                                uVar16 = (uint8_t)iVar24;
                            }
                            uVar30 = uVar30 - 4;
                            *(uint8_t *)((int64_t)puVar25 + 3) = uVar16;
                            puVar25 = puVar25 + 1;
                        } while (3 < (int32_t)uVar30);
                    }
                    for (; 0 < (int32_t)uVar30; uVar30 = uVar30 - 1) {
    // WARNING: Read-only address (ram,0x000180646c10) is written
                        uVar16 = 0xff;
                        if ((uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar25 * fVar51) < 0xff) {
                            uVar16 = (uint8_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar25 * fVar51);
                        }
                        *(uint8_t *)puVar25 = uVar16;
                        puVar25 = (uint32_t *)((int64_t)puVar25 + 1);
                    }
    // WARNING: Read-only address (ram,0x000180646c10) is written
                    uVar7 = uVar7 - 1;
                    puVar29 = (uint32_t *)((int64_t)puVar29 + (int64_t)iVar17);
                } while (0 < (int32_t)uVar7);
            }
        } else if ((*(int32_t *)(iVar20 + 0x18) == 0) && (uVar7 != 0)) {
            do {
                uVar30 = (uint32_t)uVar3;
                puVar25 = puVar29;
                if (3 < uVar30) {
                    do {
                        uVar33 = *puVar25;
                        uVar8 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar25 + 3) * fVar51);
                        uVar9 = 0xff;
                        if (uVar8 < 0xff) {
                            uVar9 = uVar8;
                        }
                        uVar8 = puVar25[1];
                        *puVar25 = ((uVar9 << 8 | uVar33 >> 0x10 & 0xff) << 8 | uVar33 >> 8 & 0xff) << 8 | uVar33 & 0xff
                        ;
                        uVar9 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar25 + 7) * fVar51);
                        uVar33 = 0xff;
                        if (uVar9 < 0xff) {
                            uVar33 = uVar9;
                        }
                        uVar9 = puVar25[2];
                        puVar25[1] = ((uVar33 << 8 | uVar8 >> 0x10 & 0xff) << 8 | uVar8 >> 8 & 0xff) << 8 | uVar8 & 0xff
                        ;
                        uVar8 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar25 + 0xb) * fVar51);
                        uVar33 = 0xff;
                        if (uVar8 < 0xff) {
                            uVar33 = uVar8;
                        }
                        uVar8 = puVar25[3];
                        puVar25[2] = ((uVar33 << 8 | uVar9 >> 0x10 & 0xff) << 8 | uVar9 >> 8 & 0xff) << 8 | uVar9 & 0xff
                        ;
                        uVar9 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar25 + 0xf) * fVar51);
                        uVar33 = 0xff;
                        if (uVar9 < 0xff) {
                            uVar33 = uVar9;
                        }
                        uVar30 = uVar30 - 4;
                        puVar25[3] = ((uVar33 << 8 | uVar8 >> 0x10 & 0xff) << 8 | uVar8 >> 8 & 0xff) << 8 | uVar8 & 0xff
                        ;
                        puVar25 = puVar25 + 4;
                    } while (3 < (int32_t)uVar30);
                }
                for (; 0 < (int32_t)uVar30; uVar30 = uVar30 - 1) {
    // WARNING: Read-only address (ram,0x000180646c10) is written
                    uVar33 = *puVar25;
                    uVar8 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar25 + 3) * fVar51);
                    uVar9 = 0xff;
                    if (uVar8 < 0xff) {
                        uVar9 = uVar8;
                    }
                    *puVar25 = ((uVar9 << 8 | uVar33 >> 0x10 & 0xff) << 8 | uVar33 >> 8 & 0xff) << 8 | uVar33 & 0xff;
                    puVar25 = puVar25 + 1;
                }
    // WARNING: Read-only address (ram,0x000180646c10) is written
                uVar7 = uVar7 - 1;
                puVar29 = (uint32_t *)((int64_t)puVar29 + (int64_t)iVar17);
            } while (0 < (int32_t)uVar7);
        }
    }
    func_0x000180127510(*(undefined8 *)(unaff_RBP + 0x28), iVar20, *(undefined2 *)(iVar13 + iVar11 * 8), 
                        *(undefined2 *)(iVar13 + 2 + iVar11 * 8), *(undefined2 *)(iVar13 + 4 + iVar11 * 8));
    func_0x000180459870(*(uint64_t *)(unaff_RBP + 0x298) ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_18012dde7
// Address: 0x18012dde7
// Size: 1480 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Removing arg arg_3c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_440h because it doesn't fit into ProtoModel

void fcn.18012cf59(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_68h, int64_t arg_78h)
{
    uint16_t uVar1;
    uint16_t uVar2;
    uint16_t uVar3;
    uint16_t uVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int32_t iVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    int64_t in_RAX;
    int64_t iVar10;
    uint8_t uVar11;
    uint8_t *puVar12;
    uint32_t *puVar13;
    int64_t iVar14;
    int64_t unaff_RBP;
    uint8_t *puVar15;
    int32_t iVar16;
    uint32_t *puVar17;
    int32_t iVar18;
    uint32_t uVar19;
    uint32_t uVar20;
    uint64_t uVar21;
    undefined4 in_R11D;
    int32_t unaff_R12D;
    int32_t unaff_R13D;
    int64_t iVar23;
    int32_t unaff_R15D;
    float fVar24;
    float fVar25;
    undefined auVar26 [16];
    undefined auVar27 [16];
    float fVar28;
    float fVar29;
    float unaff_XMM7_Da;
    float unaff_XMM8_Da;
    float unaff_XMM9_Da;
    float unaff_XMM13_Da;
    float unaff_XMM14_Da;
    undefined4 unaff_XMM14_Db;
    undefined4 unaff_XMM14_Dc;
    undefined4 unaff_XMM14_Dd;
    float unaff_XMM15_Da;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_30h;
    uint64_t uVar22;
    
    iVar16 = 0;
    *(undefined8 *)(unaff_RBP + 0x290) = 0;
    if (0 < *(int32_t *)(unaff_RBP + -0x58)) {
        iVar7 = *(int32_t *)(unaff_RBP + -0x58);
        do {
            func_0x0001804986e0(unaff_RBP + 0x290, 0, in_R11D);
            uVar22 = 0;
            uVar21 = 0;
            if ((uint32_t)arg_68h == 2) {
                uVar19 = 0;
                uVar6 = 0;
                if (-1 < unaff_R13D) {
                    do {
                        iVar10 = (int64_t)(int32_t)uVar19;
                        uVar11 = *(uint8_t *)(in_RAX + iVar10);
                        uVar6 = uVar19 + 2;
                        uVar20 = (int32_t)uVar22 +
                                 ((uint32_t)uVar11 - (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)))
                        ;
                        uVar22 = (uint64_t)uVar20;
                        uVar19 = uVar19 + 1;
                        *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                        *(char *)(in_RAX + iVar10) = (char)(uVar20 >> 1);
                        uVar21 = uVar22;
                        uVar6 = uVar19;
                    } while ((int32_t)uVar19 <= unaff_R13D);
                }
            } else if ((uint32_t)arg_68h == 3) {
                uVar19 = 0;
                uVar6 = 0;
                if (-1 < unaff_R13D) {
                    do {
                        iVar10 = (int64_t)(int32_t)uVar19;
                        uVar11 = *(uint8_t *)(in_RAX + iVar10);
                        uVar6 = uVar19 + 3;
                        uVar22 = (uint64_t)
                                 ((int32_t)uVar22 +
                                 ((uint32_t)uVar11 - (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)))
                                 );
                        uVar19 = uVar19 + 1;
                        *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                        *(char *)(in_RAX + iVar10) = (char)(uVar22 / 3);
                        uVar21 = uVar22;
                        uVar6 = uVar19;
                    } while ((int32_t)uVar19 <= unaff_R13D);
                }
            } else if ((uint32_t)arg_68h == 4) {
                uVar19 = 0;
                uVar6 = 0;
                if (-1 < unaff_R13D) {
                    do {
                        iVar10 = (int64_t)(int32_t)uVar19;
                        uVar11 = *(uint8_t *)(in_RAX + iVar10);
                        uVar6 = uVar19 - 4;
                        uVar20 = (int32_t)uVar22 +
                                 ((uint32_t)uVar11 - (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)))
                        ;
                        uVar22 = (uint64_t)uVar20;
                        uVar19 = uVar19 + 1;
                        *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                        *(char *)(in_RAX + iVar10) = (char)(uVar20 >> 2);
                        uVar21 = uVar22;
                        uVar6 = uVar19;
                    } while ((int32_t)uVar19 <= unaff_R13D);
                }
            } else {
                uVar19 = 0;
                uVar21 = uVar22;
                if ((uint32_t)arg_68h == 5) {
                    uVar6 = 0;
                    if (-1 < unaff_R13D) {
                        do {
                            iVar10 = (int64_t)(int32_t)uVar19;
                            uVar11 = *(uint8_t *)(in_RAX + iVar10);
                            uVar6 = uVar19 - 3;
                            uVar22 = (uint64_t)
                                     ((int32_t)uVar22 +
                                     ((uint32_t)uVar11 -
                                     (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7))));
                            uVar19 = uVar19 + 1;
                            *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                            *(char *)(in_RAX + iVar10) = (char)(uVar22 / 5);
                            uVar21 = uVar22;
                            uVar6 = uVar19;
                        } while ((int32_t)uVar19 <= unaff_R13D);
                    }
                } else {
                    uVar6 = uVar19;
                    if (-1 < unaff_R13D) {
                        do {
                            iVar10 = (int64_t)(int32_t)uVar19;
                            uVar11 = *(uint8_t *)(in_RAX + iVar10);
                            uVar6 = uVar19 + (uint32_t)arg_68h;
                            uVar20 = (int32_t)uVar22 +
                                     ((uint32_t)uVar11 -
                                     (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)));
                            uVar22 = (uint64_t)uVar20;
                            uVar19 = uVar19 + 1;
                            *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                            *(char *)(in_RAX + iVar10) = (char)(uVar20 / (uint32_t)arg_68h);
                            uVar21 = uVar22;
                            uVar6 = uVar19;
                        } while ((int32_t)uVar19 <= unaff_R13D);
                    }
                }
            }
            for (; (int32_t)uVar6 < unaff_R15D; uVar6 = uVar6 + 1) {
                uVar19 = (int32_t)uVar21 - (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7));
                *(char *)(in_RAX + (int32_t)uVar6) = (char)(uVar19 / (uint32_t)arg_68h);
                uVar21 = (uint64_t)uVar19;
            }
            in_RAX = in_RAX + unaff_R15D;
            iVar16 = iVar16 + 1;
        } while (iVar16 < iVar7);
        in_RAX = *(int64_t *)(unaff_RBP + -0x50);
        unaff_R12D = (int32_t)arg_78h;
    }
    if (0x1ffffffff < arg_78h) {
        iVar16 = 0;
        *(undefined8 *)(unaff_RBP + 0x290) = 0;
        if (0 < unaff_R15D) {
            do {
                func_0x0001804986e0(unaff_RBP + 0x290, 0, arg_78h._4_4_);
                uVar22 = 0;
                uVar21 = 0;
                if (arg_78h._4_4_ == 2) {
                    uVar19 = 0;
                    uVar6 = 0;
                    if (-1 < unaff_R12D) {
                        do {
                            iVar7 = uVar19 * unaff_R15D;
                            uVar11 = *(uint8_t *)(iVar7 + in_RAX);
                            uVar20 = (int32_t)uVar22 +
                                     ((uint32_t)uVar11 -
                                     (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)));
                            uVar22 = (uint64_t)uVar20;
                            uVar6 = uVar19 + 2;
                            uVar19 = uVar19 + 1;
                            *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                            *(char *)(iVar7 + in_RAX) = (char)(uVar20 >> 1);
                            uVar21 = uVar22;
                            uVar6 = uVar19;
                        } while ((int32_t)uVar19 <= unaff_R12D);
                    }
                } else if (arg_78h._4_4_ == 3) {
                    uVar19 = 0;
                    uVar6 = 0;
                    if (-1 < unaff_R12D) {
                        do {
                            iVar7 = uVar19 * unaff_R15D;
                            uVar11 = *(uint8_t *)(iVar7 + in_RAX);
                            uVar22 = (uint64_t)
                                     ((int32_t)uVar22 +
                                     ((uint32_t)uVar11 -
                                     (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7))));
                            uVar6 = uVar19 + 3;
                            uVar19 = uVar19 + 1;
                            *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                            *(char *)(iVar7 + in_RAX) = (char)(uVar22 / 3);
                            uVar21 = uVar22;
                            uVar6 = uVar19;
                        } while ((int32_t)uVar19 <= unaff_R12D);
                    }
                } else if (arg_78h._4_4_ == 4) {
                    uVar19 = 0;
                    uVar6 = 0;
                    if (-1 < unaff_R12D) {
                        do {
                            iVar7 = uVar19 * unaff_R15D;
                            uVar11 = *(uint8_t *)(iVar7 + in_RAX);
                            uVar20 = (int32_t)uVar22 +
                                     ((uint32_t)uVar11 -
                                     (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)));
                            uVar22 = (uint64_t)uVar20;
                            uVar6 = uVar19 - 4;
                            uVar19 = uVar19 + 1;
                            *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                            *(char *)(iVar7 + in_RAX) = (char)(uVar20 >> 2);
                            uVar21 = uVar22;
                            uVar6 = uVar19;
                        } while ((int32_t)uVar19 <= unaff_R12D);
                    }
                } else {
                    uVar19 = 0;
                    uVar21 = uVar22;
                    if (arg_78h._4_4_ == 5) {
                        uVar6 = 0;
                        if (-1 < unaff_R12D) {
                            do {
                                iVar7 = uVar19 * unaff_R15D;
                                uVar11 = *(uint8_t *)(iVar7 + in_RAX);
                                uVar22 = (uint64_t)
                                         ((int32_t)uVar22 +
                                         ((uint32_t)uVar11 -
                                         (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7))));
                                uVar6 = uVar19 - 3;
                                uVar19 = uVar19 + 1;
                                *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                                *(char *)(iVar7 + in_RAX) = (char)(uVar22 / 5);
                                uVar21 = uVar22;
                                uVar6 = uVar19;
                            } while ((int32_t)uVar19 <= unaff_R12D);
                        }
                    } else {
                        uVar6 = uVar19;
                        if (-1 < unaff_R12D) {
                            do {
                                iVar7 = uVar19 * unaff_R15D;
                                uVar11 = *(uint8_t *)(iVar7 + in_RAX);
                                uVar20 = (int32_t)uVar22 +
                                         ((uint32_t)uVar11 -
                                         (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)));
                                uVar21 = (uint64_t)uVar20;
                                uVar6 = uVar19 + arg_78h._4_4_;
                                uVar19 = uVar19 + 1;
                                *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                                *(char *)(iVar7 + in_RAX) = (char)(uVar20 / arg_78h._4_4_);
                                uVar22 = uVar21;
                                uVar6 = uVar19;
                            } while ((int32_t)uVar19 <= unaff_R12D);
                        }
                    }
                }
                iVar7 = *(int32_t *)(unaff_RBP + -0x58);
                for (; (int32_t)uVar6 < iVar7; uVar6 = uVar6 + 1) {
                    uVar19 = (int32_t)uVar21 - (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7));
                    uVar21 = (uint64_t)uVar19;
                    *(char *)((int32_t)(uVar6 * unaff_R15D) + in_RAX) = (char)(uVar19 / arg_78h._4_4_);
                }
                in_RAX = in_RAX + 1;
                iVar16 = iVar16 + 1;
            } while (iVar16 < unaff_R15D);
        }
    }
    fVar25 = unaff_XMM15_Da;
    if ((uint32_t)arg_68h != 0) {
        fVar25 = (float)(1 - (uint32_t)arg_68h) / (unaff_XMM9_Da + unaff_XMM9_Da);
    }
    fVar29 = unaff_XMM15_Da;
    if (arg_78h._4_4_ != 0) {
        fVar29 = (float)(1 - arg_78h._4_4_) / (unaff_XMM8_Da + unaff_XMM8_Da);
    }
    iVar10 = *(int64_t *)(unaff_RBP + 0x78);
    fVar24 = *(float *)(**(int64_t **)(*(int64_t *)(iVar10 + 0x58) + 0x28) + 0x3c);
    fVar28 = unaff_XMM14_Da;
    if (fVar24 != unaff_XMM15_Da) {
        unaff_XMM14_Db = 0;
        unaff_XMM14_Dc = 0;
        unaff_XMM14_Dd = 0;
        fVar28 = *(float *)(iVar10 + 0x14) / fVar24;
    }
    auVar26._4_4_ = unaff_XMM14_Db;
    auVar26._0_4_ = fVar28;
    auVar26._8_4_ = unaff_XMM14_Dc;
    auVar26._12_4_ = unaff_XMM14_Dd;
    auVar27._4_12_ = auVar26._4_12_;
    auVar27._0_4_ = fVar28 * *(float *)(*(int64_t *)(unaff_RBP + 0x50) + 0x50) + unaff_XMM13_Da;
    fVar24 = (float)func_0x0001800f4120(auVar27._0_8_);
    fVar24 = fVar24 + fVar25;
    fVar25 = (float)func_0x0001800f4120();
    puVar17 = *(uint32_t **)(unaff_RBP + 0x48);
    iVar5 = *(int64_t *)(unaff_RBP + 0x30);
    iVar23 = *(int64_t *)(unaff_RBP + -0x30);
    iVar16 = *(int32_t *)(unaff_RBP + -0x40);
    iVar7 = *(int32_t *)(unaff_RBP + -0x3c);
    iVar14 = *(int64_t *)(unaff_RBP + 0x28);
    fVar28 = unaff_XMM14_Da / (unaff_XMM9_Da * unaff_XMM7_Da);
    fVar25 = fVar25 + (float)(int32_t)(*(float *)(iVar10 + 0x44) + unaff_XMM13_Da) + fVar29;
    fVar29 = unaff_XMM14_Da / (unaff_XMM8_Da * unaff_XMM7_Da);
    puVar17[2] = (uint32_t)((float)iVar16 * fVar28 + fVar24);
    puVar17[3] = (uint32_t)((float)iVar7 * fVar29 + fVar25);
    puVar17[4] = (uint32_t)((float)((uint32_t)*(uint16_t *)(iVar23 + 4 + iVar5 * 8) + iVar16) * fVar28 + fVar24);
    uVar1 = *(uint16_t *)(iVar23 + 6 + iVar5 * 8);
    *puVar17 = *puVar17 | 2;
    puVar17[10] = *(uint32_t *)(unaff_RBP + 0x10);
    puVar17[5] = (uint32_t)((float)((uint32_t)uVar1 + iVar7) * fVar29 + fVar25);
    iVar10 = *(int64_t *)(iVar14 + 0x38);
    uVar1 = *(uint16_t *)(iVar23 + 2 + iVar5 * 8);
    uVar2 = *(uint16_t *)(iVar23 + iVar5 * 8);
    uVar3 = *(uint16_t *)(iVar23 + 6 + iVar5 * 8);
    uVar6 = (uint32_t)uVar3;
    iVar16 = *(int32_t *)(iVar10 + 0x1c);
    iVar18 = *(int32_t *)(iVar10 + 0x24) * *(int32_t *)(iVar10 + 0x1c);
    iVar7 = *(int32_t *)(iVar10 + 0x18);
    uVar4 = *(uint16_t *)(iVar23 + 4 + iVar5 * 8);
    *(int64_t *)(unaff_RBP + 0x30) = iVar10;
    puVar17 = (uint32_t *)
              ((int64_t)(int32_t)(((uint32_t)uVar1 * iVar16 + (uint32_t)uVar2) * *(int32_t *)(iVar10 + 0x24)) +
              *(int64_t *)(iVar10 + 0x28));
    if (iVar7 == 1) {
        if (uVar3 != 0) {
            iVar10 = *(int64_t *)(unaff_RBP + -0x50);
            do {
                func_0x000180498030(puVar17, iVar10, (uint32_t)uVar4);
                uVar6 = uVar6 - 1;
                iVar10 = iVar10 + unaff_R15D;
                puVar17 = (uint32_t *)((int64_t)puVar17 + (int64_t)iVar18);
            } while (0 < (int32_t)uVar6);
            iVar10 = *(int64_t *)(unaff_RBP + 0x30);
            iVar23 = *(int64_t *)(unaff_RBP + -0x30);
        }
    } else if ((iVar7 == 0) && (uVar6 != 0)) {
        puVar15 = *(uint8_t **)(unaff_RBP + -0x50);
        do {
            puVar12 = puVar15;
            puVar13 = puVar17;
            uVar19 = (uint32_t)uVar4;
            if (uVar4 != 0) {
                do {
                    uVar11 = *puVar12;
                    puVar12 = puVar12 + 1;
                    uVar19 = uVar19 - 1;
                    *puVar13 = (uint32_t)uVar11 << 0x18 | 0xffffff;
                    puVar13 = puVar13 + 1;
                } while (0 < (int32_t)uVar19);
            }
            uVar6 = uVar6 - 1;
            puVar15 = puVar15 + unaff_R15D;
            puVar17 = (uint32_t *)((int64_t)puVar17 + (int64_t)iVar18);
        } while (0 < (int32_t)uVar6);
    }
    uVar1 = *(uint16_t *)(iVar23 + 4 + iVar5 * 8);
    fVar25 = *(float *)(*(int64_t *)(unaff_RBP + 0x50) + 0x6c);
    if (fVar25 != unaff_XMM14_Da) {
        uVar2 = *(uint16_t *)(iVar23 + 6 + iVar5 * 8);
        uVar6 = (uint32_t)uVar2;
        iVar16 = *(int32_t *)(iVar10 + 0x1c) * *(int32_t *)(iVar10 + 0x24);
        puVar17 = (uint32_t *)
                  ((int64_t)(int32_t)(((uint32_t)*(uint16_t *)(iVar23 + 2 + iVar5 * 8) * *(int32_t *)(iVar10 + 0x1c) +
                                      (uint32_t)*(uint16_t *)(iVar23 + iVar5 * 8)) * *(int32_t *)(iVar10 + 0x24)) +
                  *(int64_t *)(iVar10 + 0x28));
        if (*(int32_t *)(iVar10 + 0x18) == 1) {
            if (uVar2 != 0) {
                do {
                    uVar19 = (uint32_t)uVar1;
                    puVar13 = puVar17;
                    if (3 < uVar19) {
                        do {
                            uVar11 = 0xff;
                            if ((uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar13 * fVar25) < 0xff) {
                                uVar11 = (uint8_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar13 * fVar25);
                            }
                            *(uint8_t *)puVar13 = uVar11;
                            iVar14 = (int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 1) * fVar25);
                            uVar11 = 0xff;
                            if ((uint32_t)iVar14 < 0xff) {
                                uVar11 = (uint8_t)iVar14;
                            }
                            *(uint8_t *)((int64_t)puVar13 + 1) = uVar11;
                            iVar14 = (int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 2) * fVar25);
                            uVar11 = 0xff;
                            if ((uint32_t)iVar14 < 0xff) {
                                uVar11 = (uint8_t)iVar14;
                            }
                            *(uint8_t *)((int64_t)puVar13 + 2) = uVar11;
                            iVar14 = (int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 3) * fVar25);
                            uVar11 = 0xff;
                            if ((uint32_t)iVar14 < 0xff) {
                                uVar11 = (uint8_t)iVar14;
                            }
                            uVar19 = uVar19 - 4;
                            *(uint8_t *)((int64_t)puVar13 + 3) = uVar11;
                            puVar13 = puVar13 + 1;
                        } while (3 < (int32_t)uVar19);
                    }
                    for (; 0 < (int32_t)uVar19; uVar19 = uVar19 - 1) {
                        uVar11 = 0xff;
                        if ((uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar13 * fVar25) < 0xff) {
                            uVar11 = (uint8_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar13 * fVar25);
                        }
                        *(uint8_t *)puVar13 = uVar11;
                        puVar13 = (uint32_t *)((int64_t)puVar13 + 1);
                    }
                    uVar6 = uVar6 - 1;
                    puVar17 = (uint32_t *)((int64_t)puVar17 + (int64_t)iVar16);
                } while (0 < (int32_t)uVar6);
            }
        } else if ((*(int32_t *)(iVar10 + 0x18) == 0) && (uVar6 != 0)) {
            do {
                uVar19 = (uint32_t)uVar1;
                puVar13 = puVar17;
                if (3 < uVar19) {
                    do {
                        uVar20 = *puVar13;
                        uVar8 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 3) * fVar25);
                        uVar9 = 0xff;
                        if (uVar8 < 0xff) {
                            uVar9 = uVar8;
                        }
                        uVar8 = puVar13[1];
                        *puVar13 = ((uVar9 << 8 | uVar20 >> 0x10 & 0xff) << 8 | uVar20 >> 8 & 0xff) << 8 | uVar20 & 0xff
                        ;
                        uVar9 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 7) * fVar25);
                        uVar20 = 0xff;
                        if (uVar9 < 0xff) {
                            uVar20 = uVar9;
                        }
                        uVar9 = puVar13[2];
                        puVar13[1] = ((uVar20 << 8 | uVar8 >> 0x10 & 0xff) << 8 | uVar8 >> 8 & 0xff) << 8 | uVar8 & 0xff
                        ;
                        uVar8 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 0xb) * fVar25);
                        uVar20 = 0xff;
                        if (uVar8 < 0xff) {
                            uVar20 = uVar8;
                        }
                        uVar8 = puVar13[3];
                        puVar13[2] = ((uVar20 << 8 | uVar9 >> 0x10 & 0xff) << 8 | uVar9 >> 8 & 0xff) << 8 | uVar9 & 0xff
                        ;
                        uVar9 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 0xf) * fVar25);
                        uVar20 = 0xff;
                        if (uVar9 < 0xff) {
                            uVar20 = uVar9;
                        }
                        uVar19 = uVar19 - 4;
                        puVar13[3] = ((uVar20 << 8 | uVar8 >> 0x10 & 0xff) << 8 | uVar8 >> 8 & 0xff) << 8 | uVar8 & 0xff
                        ;
                        puVar13 = puVar13 + 4;
                    } while (3 < (int32_t)uVar19);
                }
                for (; 0 < (int32_t)uVar19; uVar19 = uVar19 - 1) {
                    uVar20 = *puVar13;
                    uVar8 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 3) * fVar25);
                    uVar9 = 0xff;
                    if (uVar8 < 0xff) {
                        uVar9 = uVar8;
                    }
                    *puVar13 = ((uVar9 << 8 | uVar20 >> 0x10 & 0xff) << 8 | uVar20 >> 8 & 0xff) << 8 | uVar20 & 0xff;
                    puVar13 = puVar13 + 1;
                }
                uVar6 = uVar6 - 1;
                puVar17 = (uint32_t *)((int64_t)puVar17 + (int64_t)iVar16);
            } while (0 < (int32_t)uVar6);
        }
    }
    func_0x000180127510(*(undefined8 *)(unaff_RBP + 0x28), iVar10, *(undefined2 *)(iVar23 + iVar5 * 8), 
                        *(undefined2 *)(iVar23 + 2 + iVar5 * 8), *(undefined2 *)(iVar23 + 4 + iVar5 * 8));
    func_0x000180459870(*(uint64_t *)(unaff_RBP + 0x298) ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_18012e3af
// Address: 0x18012e3af
// Size: 185 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Removing arg arg_3c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_440h because it doesn't fit into ProtoModel

void fcn.18012cf59(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_68h, int64_t arg_78h)
{
    uint16_t uVar1;
    uint16_t uVar2;
    uint16_t uVar3;
    uint16_t uVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int32_t iVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    int64_t in_RAX;
    int64_t iVar10;
    uint8_t uVar11;
    uint8_t *puVar12;
    uint32_t *puVar13;
    int64_t iVar14;
    int64_t unaff_RBP;
    uint8_t *puVar15;
    int32_t iVar16;
    uint32_t *puVar17;
    int32_t iVar18;
    uint32_t uVar19;
    uint32_t uVar20;
    uint64_t uVar21;
    undefined4 in_R11D;
    int32_t unaff_R12D;
    int32_t unaff_R13D;
    int64_t iVar23;
    int32_t unaff_R15D;
    float fVar24;
    float fVar25;
    undefined auVar26 [16];
    undefined auVar27 [16];
    float fVar28;
    float fVar29;
    float unaff_XMM7_Da;
    float unaff_XMM8_Da;
    float unaff_XMM9_Da;
    float unaff_XMM13_Da;
    float unaff_XMM14_Da;
    undefined4 unaff_XMM14_Db;
    undefined4 unaff_XMM14_Dc;
    undefined4 unaff_XMM14_Dd;
    float unaff_XMM15_Da;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_30h;
    uint64_t uVar22;
    
    iVar16 = 0;
    *(undefined8 *)(unaff_RBP + 0x290) = 0;
    if (0 < *(int32_t *)(unaff_RBP + -0x58)) {
        iVar7 = *(int32_t *)(unaff_RBP + -0x58);
        do {
            func_0x0001804986e0(unaff_RBP + 0x290, 0, in_R11D);
            uVar22 = 0;
            uVar21 = 0;
            if ((uint32_t)arg_68h == 2) {
                uVar19 = 0;
                uVar6 = 0;
                if (-1 < unaff_R13D) {
                    do {
                        iVar10 = (int64_t)(int32_t)uVar19;
                        uVar11 = *(uint8_t *)(in_RAX + iVar10);
                        uVar6 = uVar19 + 2;
                        uVar20 = (int32_t)uVar22 +
                                 ((uint32_t)uVar11 - (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)))
                        ;
                        uVar22 = (uint64_t)uVar20;
                        uVar19 = uVar19 + 1;
                        *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                        *(char *)(in_RAX + iVar10) = (char)(uVar20 >> 1);
                        uVar21 = uVar22;
                        uVar6 = uVar19;
                    } while ((int32_t)uVar19 <= unaff_R13D);
                }
            } else if ((uint32_t)arg_68h == 3) {
                uVar19 = 0;
                uVar6 = 0;
                if (-1 < unaff_R13D) {
                    do {
                        iVar10 = (int64_t)(int32_t)uVar19;
                        uVar11 = *(uint8_t *)(in_RAX + iVar10);
                        uVar6 = uVar19 + 3;
                        uVar22 = (uint64_t)
                                 ((int32_t)uVar22 +
                                 ((uint32_t)uVar11 - (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)))
                                 );
                        uVar19 = uVar19 + 1;
                        *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                        *(char *)(in_RAX + iVar10) = (char)(uVar22 / 3);
                        uVar21 = uVar22;
                        uVar6 = uVar19;
                    } while ((int32_t)uVar19 <= unaff_R13D);
                }
            } else if ((uint32_t)arg_68h == 4) {
                uVar19 = 0;
                uVar6 = 0;
                if (-1 < unaff_R13D) {
                    do {
                        iVar10 = (int64_t)(int32_t)uVar19;
                        uVar11 = *(uint8_t *)(in_RAX + iVar10);
                        uVar6 = uVar19 - 4;
                        uVar20 = (int32_t)uVar22 +
                                 ((uint32_t)uVar11 - (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)))
                        ;
                        uVar22 = (uint64_t)uVar20;
                        uVar19 = uVar19 + 1;
                        *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                        *(char *)(in_RAX + iVar10) = (char)(uVar20 >> 2);
                        uVar21 = uVar22;
                        uVar6 = uVar19;
                    } while ((int32_t)uVar19 <= unaff_R13D);
                }
            } else {
                uVar19 = 0;
                uVar21 = uVar22;
                if ((uint32_t)arg_68h == 5) {
                    uVar6 = 0;
                    if (-1 < unaff_R13D) {
                        do {
                            iVar10 = (int64_t)(int32_t)uVar19;
                            uVar11 = *(uint8_t *)(in_RAX + iVar10);
                            uVar6 = uVar19 - 3;
                            uVar22 = (uint64_t)
                                     ((int32_t)uVar22 +
                                     ((uint32_t)uVar11 -
                                     (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7))));
                            uVar19 = uVar19 + 1;
                            *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                            *(char *)(in_RAX + iVar10) = (char)(uVar22 / 5);
                            uVar21 = uVar22;
                            uVar6 = uVar19;
                        } while ((int32_t)uVar19 <= unaff_R13D);
                    }
                } else {
                    uVar6 = uVar19;
                    if (-1 < unaff_R13D) {
                        do {
                            iVar10 = (int64_t)(int32_t)uVar19;
                            uVar11 = *(uint8_t *)(in_RAX + iVar10);
                            uVar6 = uVar19 + (uint32_t)arg_68h;
                            uVar20 = (int32_t)uVar22 +
                                     ((uint32_t)uVar11 -
                                     (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)));
                            uVar22 = (uint64_t)uVar20;
                            uVar19 = uVar19 + 1;
                            *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                            *(char *)(in_RAX + iVar10) = (char)(uVar20 / (uint32_t)arg_68h);
                            uVar21 = uVar22;
                            uVar6 = uVar19;
                        } while ((int32_t)uVar19 <= unaff_R13D);
                    }
                }
            }
            for (; (int32_t)uVar6 < unaff_R15D; uVar6 = uVar6 + 1) {
                uVar19 = (int32_t)uVar21 - (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7));
                *(char *)(in_RAX + (int32_t)uVar6) = (char)(uVar19 / (uint32_t)arg_68h);
                uVar21 = (uint64_t)uVar19;
            }
            in_RAX = in_RAX + unaff_R15D;
            iVar16 = iVar16 + 1;
        } while (iVar16 < iVar7);
        in_RAX = *(int64_t *)(unaff_RBP + -0x50);
        unaff_R12D = (int32_t)arg_78h;
    }
    if (0x1ffffffff < arg_78h) {
        iVar16 = 0;
        *(undefined8 *)(unaff_RBP + 0x290) = 0;
        if (0 < unaff_R15D) {
            do {
                func_0x0001804986e0(unaff_RBP + 0x290, 0, arg_78h._4_4_);
                uVar22 = 0;
                uVar21 = 0;
                if (arg_78h._4_4_ == 2) {
                    uVar19 = 0;
                    uVar6 = 0;
                    if (-1 < unaff_R12D) {
                        do {
                            iVar7 = uVar19 * unaff_R15D;
                            uVar11 = *(uint8_t *)(iVar7 + in_RAX);
                            uVar20 = (int32_t)uVar22 +
                                     ((uint32_t)uVar11 -
                                     (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)));
                            uVar22 = (uint64_t)uVar20;
                            uVar6 = uVar19 + 2;
                            uVar19 = uVar19 + 1;
                            *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                            *(char *)(iVar7 + in_RAX) = (char)(uVar20 >> 1);
                            uVar21 = uVar22;
                            uVar6 = uVar19;
                        } while ((int32_t)uVar19 <= unaff_R12D);
                    }
                } else if (arg_78h._4_4_ == 3) {
                    uVar19 = 0;
                    uVar6 = 0;
                    if (-1 < unaff_R12D) {
                        do {
                            iVar7 = uVar19 * unaff_R15D;
                            uVar11 = *(uint8_t *)(iVar7 + in_RAX);
                            uVar22 = (uint64_t)
                                     ((int32_t)uVar22 +
                                     ((uint32_t)uVar11 -
                                     (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7))));
                            uVar6 = uVar19 + 3;
                            uVar19 = uVar19 + 1;
                            *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                            *(char *)(iVar7 + in_RAX) = (char)(uVar22 / 3);
                            uVar21 = uVar22;
                            uVar6 = uVar19;
                        } while ((int32_t)uVar19 <= unaff_R12D);
                    }
                } else if (arg_78h._4_4_ == 4) {
                    uVar19 = 0;
                    uVar6 = 0;
                    if (-1 < unaff_R12D) {
                        do {
                            iVar7 = uVar19 * unaff_R15D;
                            uVar11 = *(uint8_t *)(iVar7 + in_RAX);
                            uVar20 = (int32_t)uVar22 +
                                     ((uint32_t)uVar11 -
                                     (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)));
                            uVar22 = (uint64_t)uVar20;
                            uVar6 = uVar19 - 4;
                            uVar19 = uVar19 + 1;
                            *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                            *(char *)(iVar7 + in_RAX) = (char)(uVar20 >> 2);
                            uVar21 = uVar22;
                            uVar6 = uVar19;
                        } while ((int32_t)uVar19 <= unaff_R12D);
                    }
                } else {
                    uVar19 = 0;
                    uVar21 = uVar22;
                    if (arg_78h._4_4_ == 5) {
                        uVar6 = 0;
                        if (-1 < unaff_R12D) {
                            do {
                                iVar7 = uVar19 * unaff_R15D;
                                uVar11 = *(uint8_t *)(iVar7 + in_RAX);
                                uVar22 = (uint64_t)
                                         ((int32_t)uVar22 +
                                         ((uint32_t)uVar11 -
                                         (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7))));
                                uVar6 = uVar19 - 3;
                                uVar19 = uVar19 + 1;
                                *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                                *(char *)(iVar7 + in_RAX) = (char)(uVar22 / 5);
                                uVar21 = uVar22;
                                uVar6 = uVar19;
                            } while ((int32_t)uVar19 <= unaff_R12D);
                        }
                    } else {
                        uVar6 = uVar19;
                        if (-1 < unaff_R12D) {
                            do {
                                iVar7 = uVar19 * unaff_R15D;
                                uVar11 = *(uint8_t *)(iVar7 + in_RAX);
                                uVar20 = (int32_t)uVar22 +
                                         ((uint32_t)uVar11 -
                                         (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)));
                                uVar21 = (uint64_t)uVar20;
                                uVar6 = uVar19 + arg_78h._4_4_;
                                uVar19 = uVar19 + 1;
                                *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                                *(char *)(iVar7 + in_RAX) = (char)(uVar20 / arg_78h._4_4_);
                                uVar22 = uVar21;
                                uVar6 = uVar19;
                            } while ((int32_t)uVar19 <= unaff_R12D);
                        }
                    }
                }
                iVar7 = *(int32_t *)(unaff_RBP + -0x58);
                for (; (int32_t)uVar6 < iVar7; uVar6 = uVar6 + 1) {
                    uVar19 = (int32_t)uVar21 - (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7));
                    uVar21 = (uint64_t)uVar19;
                    *(char *)((int32_t)(uVar6 * unaff_R15D) + in_RAX) = (char)(uVar19 / arg_78h._4_4_);
                }
                in_RAX = in_RAX + 1;
                iVar16 = iVar16 + 1;
            } while (iVar16 < unaff_R15D);
        }
    }
    fVar25 = unaff_XMM15_Da;
    if ((uint32_t)arg_68h != 0) {
        fVar25 = (float)(1 - (uint32_t)arg_68h) / (unaff_XMM9_Da + unaff_XMM9_Da);
    }
    fVar29 = unaff_XMM15_Da;
    if (arg_78h._4_4_ != 0) {
        fVar29 = (float)(1 - arg_78h._4_4_) / (unaff_XMM8_Da + unaff_XMM8_Da);
    }
    iVar10 = *(int64_t *)(unaff_RBP + 0x78);
    fVar24 = *(float *)(**(int64_t **)(*(int64_t *)(iVar10 + 0x58) + 0x28) + 0x3c);
    fVar28 = unaff_XMM14_Da;
    if (fVar24 != unaff_XMM15_Da) {
        unaff_XMM14_Db = 0;
        unaff_XMM14_Dc = 0;
        unaff_XMM14_Dd = 0;
        fVar28 = *(float *)(iVar10 + 0x14) / fVar24;
    }
    auVar26._4_4_ = unaff_XMM14_Db;
    auVar26._0_4_ = fVar28;
    auVar26._8_4_ = unaff_XMM14_Dc;
    auVar26._12_4_ = unaff_XMM14_Dd;
    auVar27._4_12_ = auVar26._4_12_;
    auVar27._0_4_ = fVar28 * *(float *)(*(int64_t *)(unaff_RBP + 0x50) + 0x50) + unaff_XMM13_Da;
    fVar24 = (float)func_0x0001800f4120(auVar27._0_8_);
    fVar24 = fVar24 + fVar25;
    fVar25 = (float)func_0x0001800f4120();
    puVar17 = *(uint32_t **)(unaff_RBP + 0x48);
    iVar5 = *(int64_t *)(unaff_RBP + 0x30);
    iVar23 = *(int64_t *)(unaff_RBP + -0x30);
    iVar16 = *(int32_t *)(unaff_RBP + -0x40);
    iVar7 = *(int32_t *)(unaff_RBP + -0x3c);
    iVar14 = *(int64_t *)(unaff_RBP + 0x28);
    fVar28 = unaff_XMM14_Da / (unaff_XMM9_Da * unaff_XMM7_Da);
    fVar25 = fVar25 + (float)(int32_t)(*(float *)(iVar10 + 0x44) + unaff_XMM13_Da) + fVar29;
    fVar29 = unaff_XMM14_Da / (unaff_XMM8_Da * unaff_XMM7_Da);
    puVar17[2] = (uint32_t)((float)iVar16 * fVar28 + fVar24);
    puVar17[3] = (uint32_t)((float)iVar7 * fVar29 + fVar25);
    puVar17[4] = (uint32_t)((float)((uint32_t)*(uint16_t *)(iVar23 + 4 + iVar5 * 8) + iVar16) * fVar28 + fVar24);
    uVar1 = *(uint16_t *)(iVar23 + 6 + iVar5 * 8);
    *puVar17 = *puVar17 | 2;
    puVar17[10] = *(uint32_t *)(unaff_RBP + 0x10);
    puVar17[5] = (uint32_t)((float)((uint32_t)uVar1 + iVar7) * fVar29 + fVar25);
    iVar10 = *(int64_t *)(iVar14 + 0x38);
    uVar1 = *(uint16_t *)(iVar23 + 2 + iVar5 * 8);
    uVar2 = *(uint16_t *)(iVar23 + iVar5 * 8);
    uVar3 = *(uint16_t *)(iVar23 + 6 + iVar5 * 8);
    uVar6 = (uint32_t)uVar3;
    iVar16 = *(int32_t *)(iVar10 + 0x1c);
    iVar18 = *(int32_t *)(iVar10 + 0x24) * *(int32_t *)(iVar10 + 0x1c);
    iVar7 = *(int32_t *)(iVar10 + 0x18);
    uVar4 = *(uint16_t *)(iVar23 + 4 + iVar5 * 8);
    *(int64_t *)(unaff_RBP + 0x30) = iVar10;
    puVar17 = (uint32_t *)
              ((int64_t)(int32_t)(((uint32_t)uVar1 * iVar16 + (uint32_t)uVar2) * *(int32_t *)(iVar10 + 0x24)) +
              *(int64_t *)(iVar10 + 0x28));
    if (iVar7 == 1) {
        if (uVar3 != 0) {
            iVar10 = *(int64_t *)(unaff_RBP + -0x50);
            do {
                func_0x000180498030(puVar17, iVar10, (uint32_t)uVar4);
                uVar6 = uVar6 - 1;
                iVar10 = iVar10 + unaff_R15D;
                puVar17 = (uint32_t *)((int64_t)puVar17 + (int64_t)iVar18);
            } while (0 < (int32_t)uVar6);
            iVar10 = *(int64_t *)(unaff_RBP + 0x30);
            iVar23 = *(int64_t *)(unaff_RBP + -0x30);
        }
    } else if ((iVar7 == 0) && (uVar6 != 0)) {
        puVar15 = *(uint8_t **)(unaff_RBP + -0x50);
        do {
            puVar12 = puVar15;
            puVar13 = puVar17;
            uVar19 = (uint32_t)uVar4;
            if (uVar4 != 0) {
                do {
                    uVar11 = *puVar12;
                    puVar12 = puVar12 + 1;
                    uVar19 = uVar19 - 1;
                    *puVar13 = (uint32_t)uVar11 << 0x18 | 0xffffff;
                    puVar13 = puVar13 + 1;
                } while (0 < (int32_t)uVar19);
            }
            uVar6 = uVar6 - 1;
            puVar15 = puVar15 + unaff_R15D;
            puVar17 = (uint32_t *)((int64_t)puVar17 + (int64_t)iVar18);
        } while (0 < (int32_t)uVar6);
    }
    uVar1 = *(uint16_t *)(iVar23 + 4 + iVar5 * 8);
    fVar25 = *(float *)(*(int64_t *)(unaff_RBP + 0x50) + 0x6c);
    if (fVar25 != unaff_XMM14_Da) {
        uVar2 = *(uint16_t *)(iVar23 + 6 + iVar5 * 8);
        uVar6 = (uint32_t)uVar2;
        iVar16 = *(int32_t *)(iVar10 + 0x1c) * *(int32_t *)(iVar10 + 0x24);
        puVar17 = (uint32_t *)
                  ((int64_t)(int32_t)(((uint32_t)*(uint16_t *)(iVar23 + 2 + iVar5 * 8) * *(int32_t *)(iVar10 + 0x1c) +
                                      (uint32_t)*(uint16_t *)(iVar23 + iVar5 * 8)) * *(int32_t *)(iVar10 + 0x24)) +
                  *(int64_t *)(iVar10 + 0x28));
        if (*(int32_t *)(iVar10 + 0x18) == 1) {
            if (uVar2 != 0) {
                do {
                    uVar19 = (uint32_t)uVar1;
                    puVar13 = puVar17;
                    if (3 < uVar19) {
                        do {
                            uVar11 = 0xff;
                            if ((uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar13 * fVar25) < 0xff) {
                                uVar11 = (uint8_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar13 * fVar25);
                            }
                            *(uint8_t *)puVar13 = uVar11;
                            iVar14 = (int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 1) * fVar25);
                            uVar11 = 0xff;
                            if ((uint32_t)iVar14 < 0xff) {
                                uVar11 = (uint8_t)iVar14;
                            }
                            *(uint8_t *)((int64_t)puVar13 + 1) = uVar11;
                            iVar14 = (int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 2) * fVar25);
                            uVar11 = 0xff;
                            if ((uint32_t)iVar14 < 0xff) {
                                uVar11 = (uint8_t)iVar14;
                            }
                            *(uint8_t *)((int64_t)puVar13 + 2) = uVar11;
                            iVar14 = (int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 3) * fVar25);
                            uVar11 = 0xff;
                            if ((uint32_t)iVar14 < 0xff) {
                                uVar11 = (uint8_t)iVar14;
                            }
                            uVar19 = uVar19 - 4;
                            *(uint8_t *)((int64_t)puVar13 + 3) = uVar11;
                            puVar13 = puVar13 + 1;
                        } while (3 < (int32_t)uVar19);
                    }
                    for (; 0 < (int32_t)uVar19; uVar19 = uVar19 - 1) {
                        uVar11 = 0xff;
                        if ((uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar13 * fVar25) < 0xff) {
                            uVar11 = (uint8_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar13 * fVar25);
                        }
                        *(uint8_t *)puVar13 = uVar11;
                        puVar13 = (uint32_t *)((int64_t)puVar13 + 1);
                    }
                    uVar6 = uVar6 - 1;
                    puVar17 = (uint32_t *)((int64_t)puVar17 + (int64_t)iVar16);
                } while (0 < (int32_t)uVar6);
            }
        } else if ((*(int32_t *)(iVar10 + 0x18) == 0) && (uVar6 != 0)) {
            do {
                uVar19 = (uint32_t)uVar1;
                puVar13 = puVar17;
                if (3 < uVar19) {
                    do {
                        uVar20 = *puVar13;
                        uVar8 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 3) * fVar25);
                        uVar9 = 0xff;
                        if (uVar8 < 0xff) {
                            uVar9 = uVar8;
                        }
                        uVar8 = puVar13[1];
                        *puVar13 = ((uVar9 << 8 | uVar20 >> 0x10 & 0xff) << 8 | uVar20 >> 8 & 0xff) << 8 | uVar20 & 0xff
                        ;
                        uVar9 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 7) * fVar25);
                        uVar20 = 0xff;
                        if (uVar9 < 0xff) {
                            uVar20 = uVar9;
                        }
                        uVar9 = puVar13[2];
                        puVar13[1] = ((uVar20 << 8 | uVar8 >> 0x10 & 0xff) << 8 | uVar8 >> 8 & 0xff) << 8 | uVar8 & 0xff
                        ;
                        uVar8 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 0xb) * fVar25);
                        uVar20 = 0xff;
                        if (uVar8 < 0xff) {
                            uVar20 = uVar8;
                        }
                        uVar8 = puVar13[3];
                        puVar13[2] = ((uVar20 << 8 | uVar9 >> 0x10 & 0xff) << 8 | uVar9 >> 8 & 0xff) << 8 | uVar9 & 0xff
                        ;
                        uVar9 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 0xf) * fVar25);
                        uVar20 = 0xff;
                        if (uVar9 < 0xff) {
                            uVar20 = uVar9;
                        }
                        uVar19 = uVar19 - 4;
                        puVar13[3] = ((uVar20 << 8 | uVar8 >> 0x10 & 0xff) << 8 | uVar8 >> 8 & 0xff) << 8 | uVar8 & 0xff
                        ;
                        puVar13 = puVar13 + 4;
                    } while (3 < (int32_t)uVar19);
                }
                for (; 0 < (int32_t)uVar19; uVar19 = uVar19 - 1) {
                    uVar20 = *puVar13;
                    uVar8 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 3) * fVar25);
                    uVar9 = 0xff;
                    if (uVar8 < 0xff) {
                        uVar9 = uVar8;
                    }
                    *puVar13 = ((uVar9 << 8 | uVar20 >> 0x10 & 0xff) << 8 | uVar20 >> 8 & 0xff) << 8 | uVar20 & 0xff;
                    puVar13 = puVar13 + 1;
                }
                uVar6 = uVar6 - 1;
                puVar17 = (uint32_t *)((int64_t)puVar17 + (int64_t)iVar16);
            } while (0 < (int32_t)uVar6);
        }
    }
    func_0x000180127510(*(undefined8 *)(unaff_RBP + 0x28), iVar10, *(undefined2 *)(iVar23 + iVar5 * 8), 
                        *(undefined2 *)(iVar23 + 2 + iVar5 * 8), *(undefined2 *)(iVar23 + 4 + iVar5 * 8));
    func_0x000180459870(*(uint64_t *)(unaff_RBP + 0x298) ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_18012e468
// Address: 0x18012e468
// Size: 980 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Removing arg arg_3c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_440h because it doesn't fit into ProtoModel

void fcn.18012cf59(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_68h, int64_t arg_78h)
{
    uint16_t uVar1;
    uint16_t uVar2;
    uint16_t uVar3;
    uint16_t uVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int32_t iVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    int64_t in_RAX;
    int64_t iVar10;
    uint8_t uVar11;
    uint8_t *puVar12;
    uint32_t *puVar13;
    int64_t iVar14;
    int64_t unaff_RBP;
    uint8_t *puVar15;
    int32_t iVar16;
    uint32_t *puVar17;
    int32_t iVar18;
    uint32_t uVar19;
    uint32_t uVar20;
    uint64_t uVar21;
    undefined4 in_R11D;
    int32_t unaff_R12D;
    int32_t unaff_R13D;
    int64_t iVar23;
    int32_t unaff_R15D;
    float fVar24;
    float fVar25;
    undefined auVar26 [16];
    undefined auVar27 [16];
    float fVar28;
    float fVar29;
    float unaff_XMM7_Da;
    float unaff_XMM8_Da;
    float unaff_XMM9_Da;
    float unaff_XMM13_Da;
    float unaff_XMM14_Da;
    undefined4 unaff_XMM14_Db;
    undefined4 unaff_XMM14_Dc;
    undefined4 unaff_XMM14_Dd;
    float unaff_XMM15_Da;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_30h;
    uint64_t uVar22;
    
    iVar16 = 0;
    *(undefined8 *)(unaff_RBP + 0x290) = 0;
    if (0 < *(int32_t *)(unaff_RBP + -0x58)) {
        iVar7 = *(int32_t *)(unaff_RBP + -0x58);
        do {
            func_0x0001804986e0(unaff_RBP + 0x290, 0, in_R11D);
            uVar22 = 0;
            uVar21 = 0;
            if ((uint32_t)arg_68h == 2) {
                uVar19 = 0;
                uVar6 = 0;
                if (-1 < unaff_R13D) {
                    do {
                        iVar10 = (int64_t)(int32_t)uVar19;
                        uVar11 = *(uint8_t *)(in_RAX + iVar10);
                        uVar6 = uVar19 + 2;
                        uVar20 = (int32_t)uVar22 +
                                 ((uint32_t)uVar11 - (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)))
                        ;
                        uVar22 = (uint64_t)uVar20;
                        uVar19 = uVar19 + 1;
                        *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                        *(char *)(in_RAX + iVar10) = (char)(uVar20 >> 1);
                        uVar21 = uVar22;
                        uVar6 = uVar19;
                    } while ((int32_t)uVar19 <= unaff_R13D);
                }
            } else if ((uint32_t)arg_68h == 3) {
                uVar19 = 0;
                uVar6 = 0;
                if (-1 < unaff_R13D) {
                    do {
                        iVar10 = (int64_t)(int32_t)uVar19;
                        uVar11 = *(uint8_t *)(in_RAX + iVar10);
                        uVar6 = uVar19 + 3;
                        uVar22 = (uint64_t)
                                 ((int32_t)uVar22 +
                                 ((uint32_t)uVar11 - (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)))
                                 );
                        uVar19 = uVar19 + 1;
                        *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                        *(char *)(in_RAX + iVar10) = (char)(uVar22 / 3);
                        uVar21 = uVar22;
                        uVar6 = uVar19;
                    } while ((int32_t)uVar19 <= unaff_R13D);
                }
            } else if ((uint32_t)arg_68h == 4) {
                uVar19 = 0;
                uVar6 = 0;
                if (-1 < unaff_R13D) {
                    do {
                        iVar10 = (int64_t)(int32_t)uVar19;
                        uVar11 = *(uint8_t *)(in_RAX + iVar10);
                        uVar6 = uVar19 - 4;
                        uVar20 = (int32_t)uVar22 +
                                 ((uint32_t)uVar11 - (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)))
                        ;
                        uVar22 = (uint64_t)uVar20;
                        uVar19 = uVar19 + 1;
                        *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                        *(char *)(in_RAX + iVar10) = (char)(uVar20 >> 2);
                        uVar21 = uVar22;
                        uVar6 = uVar19;
                    } while ((int32_t)uVar19 <= unaff_R13D);
                }
            } else {
                uVar19 = 0;
                uVar21 = uVar22;
                if ((uint32_t)arg_68h == 5) {
                    uVar6 = 0;
                    if (-1 < unaff_R13D) {
                        do {
                            iVar10 = (int64_t)(int32_t)uVar19;
                            uVar11 = *(uint8_t *)(in_RAX + iVar10);
                            uVar6 = uVar19 - 3;
                            uVar22 = (uint64_t)
                                     ((int32_t)uVar22 +
                                     ((uint32_t)uVar11 -
                                     (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7))));
                            uVar19 = uVar19 + 1;
                            *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                            *(char *)(in_RAX + iVar10) = (char)(uVar22 / 5);
                            uVar21 = uVar22;
                            uVar6 = uVar19;
                        } while ((int32_t)uVar19 <= unaff_R13D);
                    }
                } else {
                    uVar6 = uVar19;
                    if (-1 < unaff_R13D) {
                        do {
                            iVar10 = (int64_t)(int32_t)uVar19;
                            uVar11 = *(uint8_t *)(in_RAX + iVar10);
                            uVar6 = uVar19 + (uint32_t)arg_68h;
                            uVar20 = (int32_t)uVar22 +
                                     ((uint32_t)uVar11 -
                                     (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)));
                            uVar22 = (uint64_t)uVar20;
                            uVar19 = uVar19 + 1;
                            *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                            *(char *)(in_RAX + iVar10) = (char)(uVar20 / (uint32_t)arg_68h);
                            uVar21 = uVar22;
                            uVar6 = uVar19;
                        } while ((int32_t)uVar19 <= unaff_R13D);
                    }
                }
            }
            for (; (int32_t)uVar6 < unaff_R15D; uVar6 = uVar6 + 1) {
                uVar19 = (int32_t)uVar21 - (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7));
                *(char *)(in_RAX + (int32_t)uVar6) = (char)(uVar19 / (uint32_t)arg_68h);
                uVar21 = (uint64_t)uVar19;
            }
            in_RAX = in_RAX + unaff_R15D;
            iVar16 = iVar16 + 1;
        } while (iVar16 < iVar7);
        in_RAX = *(int64_t *)(unaff_RBP + -0x50);
        unaff_R12D = (int32_t)arg_78h;
    }
    if (0x1ffffffff < arg_78h) {
        iVar16 = 0;
        *(undefined8 *)(unaff_RBP + 0x290) = 0;
        if (0 < unaff_R15D) {
            do {
                func_0x0001804986e0(unaff_RBP + 0x290, 0, arg_78h._4_4_);
                uVar22 = 0;
                uVar21 = 0;
                if (arg_78h._4_4_ == 2) {
                    uVar19 = 0;
                    uVar6 = 0;
                    if (-1 < unaff_R12D) {
                        do {
                            iVar7 = uVar19 * unaff_R15D;
                            uVar11 = *(uint8_t *)(iVar7 + in_RAX);
                            uVar20 = (int32_t)uVar22 +
                                     ((uint32_t)uVar11 -
                                     (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)));
                            uVar22 = (uint64_t)uVar20;
                            uVar6 = uVar19 + 2;
                            uVar19 = uVar19 + 1;
                            *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                            *(char *)(iVar7 + in_RAX) = (char)(uVar20 >> 1);
                            uVar21 = uVar22;
                            uVar6 = uVar19;
                        } while ((int32_t)uVar19 <= unaff_R12D);
                    }
                } else if (arg_78h._4_4_ == 3) {
                    uVar19 = 0;
                    uVar6 = 0;
                    if (-1 < unaff_R12D) {
                        do {
                            iVar7 = uVar19 * unaff_R15D;
                            uVar11 = *(uint8_t *)(iVar7 + in_RAX);
                            uVar22 = (uint64_t)
                                     ((int32_t)uVar22 +
                                     ((uint32_t)uVar11 -
                                     (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7))));
                            uVar6 = uVar19 + 3;
                            uVar19 = uVar19 + 1;
                            *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                            *(char *)(iVar7 + in_RAX) = (char)(uVar22 / 3);
                            uVar21 = uVar22;
                            uVar6 = uVar19;
                        } while ((int32_t)uVar19 <= unaff_R12D);
                    }
                } else if (arg_78h._4_4_ == 4) {
                    uVar19 = 0;
                    uVar6 = 0;
                    if (-1 < unaff_R12D) {
                        do {
                            iVar7 = uVar19 * unaff_R15D;
                            uVar11 = *(uint8_t *)(iVar7 + in_RAX);
                            uVar20 = (int32_t)uVar22 +
                                     ((uint32_t)uVar11 -
                                     (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)));
                            uVar22 = (uint64_t)uVar20;
                            uVar6 = uVar19 - 4;
                            uVar19 = uVar19 + 1;
                            *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                            *(char *)(iVar7 + in_RAX) = (char)(uVar20 >> 2);
                            uVar21 = uVar22;
                            uVar6 = uVar19;
                        } while ((int32_t)uVar19 <= unaff_R12D);
                    }
                } else {
                    uVar19 = 0;
                    uVar21 = uVar22;
                    if (arg_78h._4_4_ == 5) {
                        uVar6 = 0;
                        if (-1 < unaff_R12D) {
                            do {
                                iVar7 = uVar19 * unaff_R15D;
                                uVar11 = *(uint8_t *)(iVar7 + in_RAX);
                                uVar22 = (uint64_t)
                                         ((int32_t)uVar22 +
                                         ((uint32_t)uVar11 -
                                         (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7))));
                                uVar6 = uVar19 - 3;
                                uVar19 = uVar19 + 1;
                                *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                                *(char *)(iVar7 + in_RAX) = (char)(uVar22 / 5);
                                uVar21 = uVar22;
                                uVar6 = uVar19;
                            } while ((int32_t)uVar19 <= unaff_R12D);
                        }
                    } else {
                        uVar6 = uVar19;
                        if (-1 < unaff_R12D) {
                            do {
                                iVar7 = uVar19 * unaff_R15D;
                                uVar11 = *(uint8_t *)(iVar7 + in_RAX);
                                uVar20 = (int32_t)uVar22 +
                                         ((uint32_t)uVar11 -
                                         (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar19 & 7)));
                                uVar21 = (uint64_t)uVar20;
                                uVar6 = uVar19 + arg_78h._4_4_;
                                uVar19 = uVar19 + 1;
                                *(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7)) = uVar11;
                                *(char *)(iVar7 + in_RAX) = (char)(uVar20 / arg_78h._4_4_);
                                uVar22 = uVar21;
                                uVar6 = uVar19;
                            } while ((int32_t)uVar19 <= unaff_R12D);
                        }
                    }
                }
                iVar7 = *(int32_t *)(unaff_RBP + -0x58);
                for (; (int32_t)uVar6 < iVar7; uVar6 = uVar6 + 1) {
                    uVar19 = (int32_t)uVar21 - (uint32_t)*(uint8_t *)(unaff_RBP + 0x290 + (uint64_t)(uVar6 & 7));
                    uVar21 = (uint64_t)uVar19;
                    *(char *)((int32_t)(uVar6 * unaff_R15D) + in_RAX) = (char)(uVar19 / arg_78h._4_4_);
                }
                in_RAX = in_RAX + 1;
                iVar16 = iVar16 + 1;
            } while (iVar16 < unaff_R15D);
        }
    }
    fVar25 = unaff_XMM15_Da;
    if ((uint32_t)arg_68h != 0) {
        fVar25 = (float)(1 - (uint32_t)arg_68h) / (unaff_XMM9_Da + unaff_XMM9_Da);
    }
    fVar29 = unaff_XMM15_Da;
    if (arg_78h._4_4_ != 0) {
        fVar29 = (float)(1 - arg_78h._4_4_) / (unaff_XMM8_Da + unaff_XMM8_Da);
    }
    iVar10 = *(int64_t *)(unaff_RBP + 0x78);
    fVar24 = *(float *)(**(int64_t **)(*(int64_t *)(iVar10 + 0x58) + 0x28) + 0x3c);
    fVar28 = unaff_XMM14_Da;
    if (fVar24 != unaff_XMM15_Da) {
        unaff_XMM14_Db = 0;
        unaff_XMM14_Dc = 0;
        unaff_XMM14_Dd = 0;
        fVar28 = *(float *)(iVar10 + 0x14) / fVar24;
    }
    auVar26._4_4_ = unaff_XMM14_Db;
    auVar26._0_4_ = fVar28;
    auVar26._8_4_ = unaff_XMM14_Dc;
    auVar26._12_4_ = unaff_XMM14_Dd;
    auVar27._4_12_ = auVar26._4_12_;
    auVar27._0_4_ = fVar28 * *(float *)(*(int64_t *)(unaff_RBP + 0x50) + 0x50) + unaff_XMM13_Da;
    fVar24 = (float)func_0x0001800f4120(auVar27._0_8_);
    fVar24 = fVar24 + fVar25;
    fVar25 = (float)func_0x0001800f4120();
    puVar17 = *(uint32_t **)(unaff_RBP + 0x48);
    iVar5 = *(int64_t *)(unaff_RBP + 0x30);
    iVar23 = *(int64_t *)(unaff_RBP + -0x30);
    iVar16 = *(int32_t *)(unaff_RBP + -0x40);
    iVar7 = *(int32_t *)(unaff_RBP + -0x3c);
    iVar14 = *(int64_t *)(unaff_RBP + 0x28);
    fVar28 = unaff_XMM14_Da / (unaff_XMM9_Da * unaff_XMM7_Da);
    fVar25 = fVar25 + (float)(int32_t)(*(float *)(iVar10 + 0x44) + unaff_XMM13_Da) + fVar29;
    fVar29 = unaff_XMM14_Da / (unaff_XMM8_Da * unaff_XMM7_Da);
    puVar17[2] = (uint32_t)((float)iVar16 * fVar28 + fVar24);
    puVar17[3] = (uint32_t)((float)iVar7 * fVar29 + fVar25);
    puVar17[4] = (uint32_t)((float)((uint32_t)*(uint16_t *)(iVar23 + 4 + iVar5 * 8) + iVar16) * fVar28 + fVar24);
    uVar1 = *(uint16_t *)(iVar23 + 6 + iVar5 * 8);
    *puVar17 = *puVar17 | 2;
    puVar17[10] = *(uint32_t *)(unaff_RBP + 0x10);
    puVar17[5] = (uint32_t)((float)((uint32_t)uVar1 + iVar7) * fVar29 + fVar25);
    iVar10 = *(int64_t *)(iVar14 + 0x38);
    uVar1 = *(uint16_t *)(iVar23 + 2 + iVar5 * 8);
    uVar2 = *(uint16_t *)(iVar23 + iVar5 * 8);
    uVar3 = *(uint16_t *)(iVar23 + 6 + iVar5 * 8);
    uVar6 = (uint32_t)uVar3;
    iVar16 = *(int32_t *)(iVar10 + 0x1c);
    iVar18 = *(int32_t *)(iVar10 + 0x24) * *(int32_t *)(iVar10 + 0x1c);
    iVar7 = *(int32_t *)(iVar10 + 0x18);
    uVar4 = *(uint16_t *)(iVar23 + 4 + iVar5 * 8);
    *(int64_t *)(unaff_RBP + 0x30) = iVar10;
    puVar17 = (uint32_t *)
              ((int64_t)(int32_t)(((uint32_t)uVar1 * iVar16 + (uint32_t)uVar2) * *(int32_t *)(iVar10 + 0x24)) +
              *(int64_t *)(iVar10 + 0x28));
    if (iVar7 == 1) {
        if (uVar3 != 0) {
            iVar10 = *(int64_t *)(unaff_RBP + -0x50);
            do {
                func_0x000180498030(puVar17, iVar10, (uint32_t)uVar4);
                uVar6 = uVar6 - 1;
                iVar10 = iVar10 + unaff_R15D;
                puVar17 = (uint32_t *)((int64_t)puVar17 + (int64_t)iVar18);
            } while (0 < (int32_t)uVar6);
            iVar10 = *(int64_t *)(unaff_RBP + 0x30);
            iVar23 = *(int64_t *)(unaff_RBP + -0x30);
        }
    } else if ((iVar7 == 0) && (uVar6 != 0)) {
        puVar15 = *(uint8_t **)(unaff_RBP + -0x50);
        do {
            puVar12 = puVar15;
            puVar13 = puVar17;
            uVar19 = (uint32_t)uVar4;
            if (uVar4 != 0) {
                do {
                    uVar11 = *puVar12;
                    puVar12 = puVar12 + 1;
                    uVar19 = uVar19 - 1;
                    *puVar13 = (uint32_t)uVar11 << 0x18 | 0xffffff;
                    puVar13 = puVar13 + 1;
                } while (0 < (int32_t)uVar19);
            }
            uVar6 = uVar6 - 1;
            puVar15 = puVar15 + unaff_R15D;
            puVar17 = (uint32_t *)((int64_t)puVar17 + (int64_t)iVar18);
        } while (0 < (int32_t)uVar6);
    }
    uVar1 = *(uint16_t *)(iVar23 + 4 + iVar5 * 8);
    fVar25 = *(float *)(*(int64_t *)(unaff_RBP + 0x50) + 0x6c);
    if (fVar25 != unaff_XMM14_Da) {
        uVar2 = *(uint16_t *)(iVar23 + 6 + iVar5 * 8);
        uVar6 = (uint32_t)uVar2;
        iVar16 = *(int32_t *)(iVar10 + 0x1c) * *(int32_t *)(iVar10 + 0x24);
        puVar17 = (uint32_t *)
                  ((int64_t)(int32_t)(((uint32_t)*(uint16_t *)(iVar23 + 2 + iVar5 * 8) * *(int32_t *)(iVar10 + 0x1c) +
                                      (uint32_t)*(uint16_t *)(iVar23 + iVar5 * 8)) * *(int32_t *)(iVar10 + 0x24)) +
                  *(int64_t *)(iVar10 + 0x28));
        if (*(int32_t *)(iVar10 + 0x18) == 1) {
            if (uVar2 != 0) {
                do {
                    uVar19 = (uint32_t)uVar1;
                    puVar13 = puVar17;
                    if (3 < uVar19) {
                        do {
                            uVar11 = 0xff;
                            if ((uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar13 * fVar25) < 0xff) {
                                uVar11 = (uint8_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar13 * fVar25);
                            }
                            *(uint8_t *)puVar13 = uVar11;
                            iVar14 = (int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 1) * fVar25);
                            uVar11 = 0xff;
                            if ((uint32_t)iVar14 < 0xff) {
                                uVar11 = (uint8_t)iVar14;
                            }
                            *(uint8_t *)((int64_t)puVar13 + 1) = uVar11;
                            iVar14 = (int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 2) * fVar25);
                            uVar11 = 0xff;
                            if ((uint32_t)iVar14 < 0xff) {
                                uVar11 = (uint8_t)iVar14;
                            }
                            *(uint8_t *)((int64_t)puVar13 + 2) = uVar11;
                            iVar14 = (int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 3) * fVar25);
                            uVar11 = 0xff;
                            if ((uint32_t)iVar14 < 0xff) {
                                uVar11 = (uint8_t)iVar14;
                            }
                            uVar19 = uVar19 - 4;
                            *(uint8_t *)((int64_t)puVar13 + 3) = uVar11;
                            puVar13 = puVar13 + 1;
                        } while (3 < (int32_t)uVar19);
                    }
                    for (; 0 < (int32_t)uVar19; uVar19 = uVar19 - 1) {
                        uVar11 = 0xff;
                        if ((uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar13 * fVar25) < 0xff) {
                            uVar11 = (uint8_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar13 * fVar25);
                        }
                        *(uint8_t *)puVar13 = uVar11;
                        puVar13 = (uint32_t *)((int64_t)puVar13 + 1);
                    }
                    uVar6 = uVar6 - 1;
                    puVar17 = (uint32_t *)((int64_t)puVar17 + (int64_t)iVar16);
                } while (0 < (int32_t)uVar6);
            }
        } else if ((*(int32_t *)(iVar10 + 0x18) == 0) && (uVar6 != 0)) {
            do {
                uVar19 = (uint32_t)uVar1;
                puVar13 = puVar17;
                if (3 < uVar19) {
                    do {
                        uVar20 = *puVar13;
                        uVar8 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 3) * fVar25);
                        uVar9 = 0xff;
                        if (uVar8 < 0xff) {
                            uVar9 = uVar8;
                        }
                        uVar8 = puVar13[1];
                        *puVar13 = ((uVar9 << 8 | uVar20 >> 0x10 & 0xff) << 8 | uVar20 >> 8 & 0xff) << 8 | uVar20 & 0xff
                        ;
                        uVar9 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 7) * fVar25);
                        uVar20 = 0xff;
                        if (uVar9 < 0xff) {
                            uVar20 = uVar9;
                        }
                        uVar9 = puVar13[2];
                        puVar13[1] = ((uVar20 << 8 | uVar8 >> 0x10 & 0xff) << 8 | uVar8 >> 8 & 0xff) << 8 | uVar8 & 0xff
                        ;
                        uVar8 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 0xb) * fVar25);
                        uVar20 = 0xff;
                        if (uVar8 < 0xff) {
                            uVar20 = uVar8;
                        }
                        uVar8 = puVar13[3];
                        puVar13[2] = ((uVar20 << 8 | uVar9 >> 0x10 & 0xff) << 8 | uVar9 >> 8 & 0xff) << 8 | uVar9 & 0xff
                        ;
                        uVar9 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 0xf) * fVar25);
                        uVar20 = 0xff;
                        if (uVar9 < 0xff) {
                            uVar20 = uVar9;
                        }
                        uVar19 = uVar19 - 4;
                        puVar13[3] = ((uVar20 << 8 | uVar8 >> 0x10 & 0xff) << 8 | uVar8 >> 8 & 0xff) << 8 | uVar8 & 0xff
                        ;
                        puVar13 = puVar13 + 4;
                    } while (3 < (int32_t)uVar19);
                }
                for (; 0 < (int32_t)uVar19; uVar19 = uVar19 - 1) {
                    uVar20 = *puVar13;
                    uVar8 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar13 + 3) * fVar25);
                    uVar9 = 0xff;
                    if (uVar8 < 0xff) {
                        uVar9 = uVar8;
                    }
                    *puVar13 = ((uVar9 << 8 | uVar20 >> 0x10 & 0xff) << 8 | uVar20 >> 8 & 0xff) << 8 | uVar20 & 0xff;
                    puVar13 = puVar13 + 1;
                }
                uVar6 = uVar6 - 1;
                puVar17 = (uint32_t *)((int64_t)puVar17 + (int64_t)iVar16);
            } while (0 < (int32_t)uVar6);
        }
    }
    func_0x000180127510(*(undefined8 *)(unaff_RBP + 0x28), iVar10, *(undefined2 *)(iVar23 + iVar5 * 8), 
                        *(undefined2 *)(iVar23 + 2 + iVar5 * 8), *(undefined2 *)(iVar23 + 4 + iVar5 * 8));
    func_0x000180459870(*(uint64_t *)(unaff_RBP + 0x298) ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_18012e840
// Address: 0x18012e840
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Variable var_2h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

uint32_t * fcn.18012e840(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    undefined4 *puVar1;
    float fVar2;
    int32_t iVar3;
    int32_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    undefined8 uVar10;
    int64_t iVar11;
    int32_t iVar12;
    uint32_t *puVar13;
    int64_t iVar14;
    float fVar15;
    float fVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar3 = *(int32_t *)(arg2 + 0x30);
    iVar4 = *(int32_t *)(arg2 + 0x34);
    if (iVar3 == iVar4) {
        if (iVar4 == 0) {
            iVar8 = 8;
        } else {
            iVar8 = iVar4 / 2 + iVar4;
        }
        iVar12 = iVar3 + 1;
        if (iVar3 + 1 < iVar8) {
            iVar12 = iVar8;
        }
        if (iVar4 < iVar12) {
            uVar10 = func_0x00018046d050((int64_t)iVar12 * 0x2c);
            if (*(int64_t *)(arg2 + 0x38) != 0) {
                func_0x000180498030(uVar10, *(int64_t *)(arg2 + 0x38), (int64_t)*(int32_t *)(arg2 + 0x30) * 0x2c);
                func_0x000180460d90(*(undefined8 *)(arg2 + 0x38));
            }
            *(undefined8 *)(arg2 + 0x38) = uVar10;
            *(int32_t *)(arg2 + 0x34) = iVar12;
        }
    }
    uVar5 = *(undefined4 *)(arg4 + 4);
    uVar6 = *(undefined4 *)(arg4 + 8);
    uVar7 = *(undefined4 *)(arg4 + 0xc);
    iVar11 = (int64_t)*(int32_t *)(arg2 + 0x30) * 0x2c;
    iVar14 = *(int64_t *)(arg2 + 0x38);
    puVar1 = (undefined4 *)(iVar11 + iVar14);
    *puVar1 = *(undefined4 *)arg4;
    puVar1[1] = uVar5;
    puVar1[2] = uVar6;
    puVar1[3] = uVar7;
    uVar5 = *(undefined4 *)(arg4 + 0x14);
    uVar6 = *(undefined4 *)(arg4 + 0x18);
    uVar7 = *(undefined4 *)(arg4 + 0x1c);
    puVar1 = (undefined4 *)(iVar11 + 0x10 + iVar14);
    *puVar1 = *(undefined4 *)(arg4 + 0x10);
    puVar1[1] = uVar5;
    puVar1[2] = uVar6;
    puVar1[3] = uVar7;
    uVar5 = *(undefined4 *)(arg4 + 0x20);
    uVar6 = *(undefined4 *)(arg4 + 0x24);
    uVar7 = *(undefined4 *)(arg4 + 0x28);
    puVar1 = (undefined4 *)(iVar11 + 0x1c + iVar14);
    *puVar1 = *(undefined4 *)(arg4 + 0x1c);
    puVar1[1] = uVar5;
    puVar1[2] = uVar6;
    puVar1[3] = uVar7;
    *(int32_t *)(arg2 + 0x30) = *(int32_t *)(arg2 + 0x30) + 1;
    puVar13 = (uint32_t *)((int64_t)iVar3 * 0x2c + *(int64_t *)(arg2 + 0x38));
    if (puVar13[10] != 0xffffffff) {
        iVar14 = *(int64_t *)(*(int64_t *)(arg1 + 0x2b0) + 0x68);
        iVar11 = (int64_t)(*(int32_t *)
                            (*(int64_t *)(*(int64_t *)(arg1 + 0x2b0) + 0x78) + (uint64_t)(puVar13[10] & 0x7ffff) * 4) <<
                          0xc) >> 0xc;
        puVar13[6] = (uint32_t)((float)(uint32_t)*(uint16_t *)(iVar14 + iVar11 * 8) * *(float *)(arg1 + 0x54));
        puVar13[7] = (uint32_t)((float)(uint32_t)*(uint16_t *)(iVar14 + 2 + iVar11 * 8) * *(float *)(arg1 + 0x58));
        puVar13[8] = (uint32_t)
                     ((float)((uint32_t)*(uint16_t *)(iVar14 + iVar11 * 8) +
                             (uint32_t)*(uint16_t *)(iVar14 + 4 + iVar11 * 8)) * *(float *)(arg1 + 0x54));
        puVar13[9] = (uint32_t)
                     ((float)((uint32_t)*(uint16_t *)(iVar14 + 6 + iVar11 * 8) +
                             (uint32_t)*(uint16_t *)(iVar14 + 2 + iVar11 * 8)) * *(float *)(arg1 + 0x58));
        uVar9 = *(uint32_t *)(arg2 + 0x4c);
        *(uint32_t *)(arg2 + 0x4c) =
             ((uint32_t)*(uint16_t *)(iVar14 + 6 + iVar11 * 8) * (uint32_t)*(uint16_t *)(iVar14 + 4 + iVar11 * 8) +
              uVar9 ^ uVar9) & 0x3ffffff ^ uVar9;
    }
    if (arg3 != 0) {
        fVar16 = *(float *)(**(int64_t **)(*(int64_t *)(arg2 + 0x58) + 0x28) + 0x3c);
        if (fVar16 == 0.0) {
            fVar16 = 1.0;
        } else {
            fVar16 = *(float *)(arg2 + 0x14) / fVar16;
        }
        fVar2 = (float)puVar13[1];
        fVar15 = fVar16 * *(float *)(arg3 + 0x58);
        if ((fVar15 <= fVar2) && (fVar15 = fVar16 * *(float *)(arg3 + 0x5c), fVar2 <= fVar15)) {
            fVar15 = fVar2;
        }
        if (fVar15 != fVar2) {
            fVar16 = (fVar15 - fVar2) * 0.5;
            if (*(char *)(arg3 + 0x36) != '\0') {
                fVar16 = (float)(int32_t)fVar16;
            }
            puVar13[2] = (uint32_t)(fVar16 + (float)puVar13[2]);
            puVar13[4] = (uint32_t)(fVar16 + (float)puVar13[4]);
        }
        if (*(char *)(arg3 + 0x36) != '\0') {
            fVar15 = (float)(int32_t)(fVar15 + 0.5);
        }
        puVar13[1] = (uint32_t)(fVar15 + *(float *)(arg3 + 0x60));
    }
    if ((*(uint8_t *)puVar13 & 1) != 0) {
        *(undefined *)(*(int64_t *)(arg1 + 0x38) + 0x56) = 1;
        *(undefined *)(arg1 + 0x53) = 1;
    }
    uVar9 = *puVar13 >> 6;
    func_0x00018012b5c0(arg2, uVar9 + 1);
    *(uint32_t *)(*(int64_t *)(arg2 + 8) + (uint64_t)uVar9 * 4) = puVar13[1];
    *(int16_t *)(*(int64_t *)(arg2 + 0x28) + (uint64_t)uVar9 * 2) = (int16_t)iVar3;
    iVar14 = (int64_t)((int32_t)uVar9 >> 0xd) >> 3;
    *(uint8_t *)(iVar14 + 0x34 + *(int64_t *)(arg2 + 0x58)) =
         *(uint8_t *)(iVar14 + 0x34 + *(int64_t *)(arg2 + 0x58)) | (uint8_t)(1 << ((int32_t)uVar9 >> 0xd & 7U));
    return puVar13;
}

// ============================================================
// Function: FUN_18012e85a
// Address: 0x18012e85a
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Variable var_2h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

uint32_t * fcn.18012e840(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    undefined4 *puVar1;
    float fVar2;
    int32_t iVar3;
    int32_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    undefined8 uVar10;
    int64_t iVar11;
    int32_t iVar12;
    uint32_t *puVar13;
    int64_t iVar14;
    float fVar15;
    float fVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar3 = *(int32_t *)(arg2 + 0x30);
    iVar4 = *(int32_t *)(arg2 + 0x34);
    if (iVar3 == iVar4) {
        if (iVar4 == 0) {
            iVar8 = 8;
        } else {
            iVar8 = iVar4 / 2 + iVar4;
        }
        iVar12 = iVar3 + 1;
        if (iVar3 + 1 < iVar8) {
            iVar12 = iVar8;
        }
        if (iVar4 < iVar12) {
            uVar10 = func_0x00018046d050((int64_t)iVar12 * 0x2c);
            if (*(int64_t *)(arg2 + 0x38) != 0) {
                func_0x000180498030(uVar10, *(int64_t *)(arg2 + 0x38), (int64_t)*(int32_t *)(arg2 + 0x30) * 0x2c);
                func_0x000180460d90(*(undefined8 *)(arg2 + 0x38));
            }
            *(undefined8 *)(arg2 + 0x38) = uVar10;
            *(int32_t *)(arg2 + 0x34) = iVar12;
        }
    }
    uVar5 = *(undefined4 *)(arg4 + 4);
    uVar6 = *(undefined4 *)(arg4 + 8);
    uVar7 = *(undefined4 *)(arg4 + 0xc);
    iVar11 = (int64_t)*(int32_t *)(arg2 + 0x30) * 0x2c;
    iVar14 = *(int64_t *)(arg2 + 0x38);
    puVar1 = (undefined4 *)(iVar11 + iVar14);
    *puVar1 = *(undefined4 *)arg4;
    puVar1[1] = uVar5;
    puVar1[2] = uVar6;
    puVar1[3] = uVar7;
    uVar5 = *(undefined4 *)(arg4 + 0x14);
    uVar6 = *(undefined4 *)(arg4 + 0x18);
    uVar7 = *(undefined4 *)(arg4 + 0x1c);
    puVar1 = (undefined4 *)(iVar11 + 0x10 + iVar14);
    *puVar1 = *(undefined4 *)(arg4 + 0x10);
    puVar1[1] = uVar5;
    puVar1[2] = uVar6;
    puVar1[3] = uVar7;
    uVar5 = *(undefined4 *)(arg4 + 0x20);
    uVar6 = *(undefined4 *)(arg4 + 0x24);
    uVar7 = *(undefined4 *)(arg4 + 0x28);
    puVar1 = (undefined4 *)(iVar11 + 0x1c + iVar14);
    *puVar1 = *(undefined4 *)(arg4 + 0x1c);
    puVar1[1] = uVar5;
    puVar1[2] = uVar6;
    puVar1[3] = uVar7;
    *(int32_t *)(arg2 + 0x30) = *(int32_t *)(arg2 + 0x30) + 1;
    puVar13 = (uint32_t *)((int64_t)iVar3 * 0x2c + *(int64_t *)(arg2 + 0x38));
    if (puVar13[10] != 0xffffffff) {
        iVar14 = *(int64_t *)(*(int64_t *)(arg1 + 0x2b0) + 0x68);
        iVar11 = (int64_t)(*(int32_t *)
                            (*(int64_t *)(*(int64_t *)(arg1 + 0x2b0) + 0x78) + (uint64_t)(puVar13[10] & 0x7ffff) * 4) <<
                          0xc) >> 0xc;
        puVar13[6] = (uint32_t)((float)(uint32_t)*(uint16_t *)(iVar14 + iVar11 * 8) * *(float *)(arg1 + 0x54));
        puVar13[7] = (uint32_t)((float)(uint32_t)*(uint16_t *)(iVar14 + 2 + iVar11 * 8) * *(float *)(arg1 + 0x58));
        puVar13[8] = (uint32_t)
                     ((float)((uint32_t)*(uint16_t *)(iVar14 + iVar11 * 8) +
                             (uint32_t)*(uint16_t *)(iVar14 + 4 + iVar11 * 8)) * *(float *)(arg1 + 0x54));
        puVar13[9] = (uint32_t)
                     ((float)((uint32_t)*(uint16_t *)(iVar14 + 6 + iVar11 * 8) +
                             (uint32_t)*(uint16_t *)(iVar14 + 2 + iVar11 * 8)) * *(float *)(arg1 + 0x58));
        uVar9 = *(uint32_t *)(arg2 + 0x4c);
        *(uint32_t *)(arg2 + 0x4c) =
             ((uint32_t)*(uint16_t *)(iVar14 + 6 + iVar11 * 8) * (uint32_t)*(uint16_t *)(iVar14 + 4 + iVar11 * 8) +
              uVar9 ^ uVar9) & 0x3ffffff ^ uVar9;
    }
    if (arg3 != 0) {
        fVar16 = *(float *)(**(int64_t **)(*(int64_t *)(arg2 + 0x58) + 0x28) + 0x3c);
        if (fVar16 == 0.0) {
            fVar16 = 1.0;
        } else {
            fVar16 = *(float *)(arg2 + 0x14) / fVar16;
        }
        fVar2 = (float)puVar13[1];
        fVar15 = fVar16 * *(float *)(arg3 + 0x58);
        if ((fVar15 <= fVar2) && (fVar15 = fVar16 * *(float *)(arg3 + 0x5c), fVar2 <= fVar15)) {
            fVar15 = fVar2;
        }
        if (fVar15 != fVar2) {
            fVar16 = (fVar15 - fVar2) * 0.5;
            if (*(char *)(arg3 + 0x36) != '\0') {
                fVar16 = (float)(int32_t)fVar16;
            }
            puVar13[2] = (uint32_t)(fVar16 + (float)puVar13[2]);
            puVar13[4] = (uint32_t)(fVar16 + (float)puVar13[4]);
        }
        if (*(char *)(arg3 + 0x36) != '\0') {
            fVar15 = (float)(int32_t)(fVar15 + 0.5);
        }
        puVar13[1] = (uint32_t)(fVar15 + *(float *)(arg3 + 0x60));
    }
    if ((*(uint8_t *)puVar13 & 1) != 0) {
        *(undefined *)(*(int64_t *)(arg1 + 0x38) + 0x56) = 1;
        *(undefined *)(arg1 + 0x53) = 1;
    }
    uVar9 = *puVar13 >> 6;
    func_0x00018012b5c0(arg2, uVar9 + 1);
    *(uint32_t *)(*(int64_t *)(arg2 + 8) + (uint64_t)uVar9 * 4) = puVar13[1];
    *(int16_t *)(*(int64_t *)(arg2 + 0x28) + (uint64_t)uVar9 * 2) = (int16_t)iVar3;
    iVar14 = (int64_t)((int32_t)uVar9 >> 0xd) >> 3;
    *(uint8_t *)(iVar14 + 0x34 + *(int64_t *)(arg2 + 0x58)) =
         *(uint8_t *)(iVar14 + 0x34 + *(int64_t *)(arg2 + 0x58)) | (uint8_t)(1 << ((int32_t)uVar9 >> 0xd & 7U));
    return puVar13;
}

// ============================================================
// Function: FUN_18012e89d
// Address: 0x18012e89d
// Size: 59 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Variable var_2h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

uint32_t * fcn.18012e840(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    undefined4 *puVar1;
    float fVar2;
    int32_t iVar3;
    int32_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    undefined8 uVar10;
    int64_t iVar11;
    int32_t iVar12;
    uint32_t *puVar13;
    int64_t iVar14;
    float fVar15;
    float fVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar3 = *(int32_t *)(arg2 + 0x30);
    iVar4 = *(int32_t *)(arg2 + 0x34);
    if (iVar3 == iVar4) {
        if (iVar4 == 0) {
            iVar8 = 8;
        } else {
            iVar8 = iVar4 / 2 + iVar4;
        }
        iVar12 = iVar3 + 1;
        if (iVar3 + 1 < iVar8) {
            iVar12 = iVar8;
        }
        if (iVar4 < iVar12) {
            uVar10 = func_0x00018046d050((int64_t)iVar12 * 0x2c);
            if (*(int64_t *)(arg2 + 0x38) != 0) {
                func_0x000180498030(uVar10, *(int64_t *)(arg2 + 0x38), (int64_t)*(int32_t *)(arg2 + 0x30) * 0x2c);
                func_0x000180460d90(*(undefined8 *)(arg2 + 0x38));
            }
            *(undefined8 *)(arg2 + 0x38) = uVar10;
            *(int32_t *)(arg2 + 0x34) = iVar12;
        }
    }
    uVar5 = *(undefined4 *)(arg4 + 4);
    uVar6 = *(undefined4 *)(arg4 + 8);
    uVar7 = *(undefined4 *)(arg4 + 0xc);
    iVar11 = (int64_t)*(int32_t *)(arg2 + 0x30) * 0x2c;
    iVar14 = *(int64_t *)(arg2 + 0x38);
    puVar1 = (undefined4 *)(iVar11 + iVar14);
    *puVar1 = *(undefined4 *)arg4;
    puVar1[1] = uVar5;
    puVar1[2] = uVar6;
    puVar1[3] = uVar7;
    uVar5 = *(undefined4 *)(arg4 + 0x14);
    uVar6 = *(undefined4 *)(arg4 + 0x18);
    uVar7 = *(undefined4 *)(arg4 + 0x1c);
    puVar1 = (undefined4 *)(iVar11 + 0x10 + iVar14);
    *puVar1 = *(undefined4 *)(arg4 + 0x10);
    puVar1[1] = uVar5;
    puVar1[2] = uVar6;
    puVar1[3] = uVar7;
    uVar5 = *(undefined4 *)(arg4 + 0x20);
    uVar6 = *(undefined4 *)(arg4 + 0x24);
    uVar7 = *(undefined4 *)(arg4 + 0x28);
    puVar1 = (undefined4 *)(iVar11 + 0x1c + iVar14);
    *puVar1 = *(undefined4 *)(arg4 + 0x1c);
    puVar1[1] = uVar5;
    puVar1[2] = uVar6;
    puVar1[3] = uVar7;
    *(int32_t *)(arg2 + 0x30) = *(int32_t *)(arg2 + 0x30) + 1;
    puVar13 = (uint32_t *)((int64_t)iVar3 * 0x2c + *(int64_t *)(arg2 + 0x38));
    if (puVar13[10] != 0xffffffff) {
        iVar14 = *(int64_t *)(*(int64_t *)(arg1 + 0x2b0) + 0x68);
        iVar11 = (int64_t)(*(int32_t *)
                            (*(int64_t *)(*(int64_t *)(arg1 + 0x2b0) + 0x78) + (uint64_t)(puVar13[10] & 0x7ffff) * 4) <<
                          0xc) >> 0xc;
        puVar13[6] = (uint32_t)((float)(uint32_t)*(uint16_t *)(iVar14 + iVar11 * 8) * *(float *)(arg1 + 0x54));
        puVar13[7] = (uint32_t)((float)(uint32_t)*(uint16_t *)(iVar14 + 2 + iVar11 * 8) * *(float *)(arg1 + 0x58));
        puVar13[8] = (uint32_t)
                     ((float)((uint32_t)*(uint16_t *)(iVar14 + iVar11 * 8) +
                             (uint32_t)*(uint16_t *)(iVar14 + 4 + iVar11 * 8)) * *(float *)(arg1 + 0x54));
        puVar13[9] = (uint32_t)
                     ((float)((uint32_t)*(uint16_t *)(iVar14 + 6 + iVar11 * 8) +
                             (uint32_t)*(uint16_t *)(iVar14 + 2 + iVar11 * 8)) * *(float *)(arg1 + 0x58));
        uVar9 = *(uint32_t *)(arg2 + 0x4c);
        *(uint32_t *)(arg2 + 0x4c) =
             ((uint32_t)*(uint16_t *)(iVar14 + 6 + iVar11 * 8) * (uint32_t)*(uint16_t *)(iVar14 + 4 + iVar11 * 8) +
              uVar9 ^ uVar9) & 0x3ffffff ^ uVar9;
    }
    if (arg3 != 0) {
        fVar16 = *(float *)(**(int64_t **)(*(int64_t *)(arg2 + 0x58) + 0x28) + 0x3c);
        if (fVar16 == 0.0) {
            fVar16 = 1.0;
        } else {
            fVar16 = *(float *)(arg2 + 0x14) / fVar16;
        }
        fVar2 = (float)puVar13[1];
        fVar15 = fVar16 * *(float *)(arg3 + 0x58);
        if ((fVar15 <= fVar2) && (fVar15 = fVar16 * *(float *)(arg3 + 0x5c), fVar2 <= fVar15)) {
            fVar15 = fVar2;
        }
        if (fVar15 != fVar2) {
            fVar16 = (fVar15 - fVar2) * 0.5;
            if (*(char *)(arg3 + 0x36) != '\0') {
                fVar16 = (float)(int32_t)fVar16;
            }
            puVar13[2] = (uint32_t)(fVar16 + (float)puVar13[2]);
            puVar13[4] = (uint32_t)(fVar16 + (float)puVar13[4]);
        }
        if (*(char *)(arg3 + 0x36) != '\0') {
            fVar15 = (float)(int32_t)(fVar15 + 0.5);
        }
        puVar13[1] = (uint32_t)(fVar15 + *(float *)(arg3 + 0x60));
    }
    if ((*(uint8_t *)puVar13 & 1) != 0) {
        *(undefined *)(*(int64_t *)(arg1 + 0x38) + 0x56) = 1;
        *(undefined *)(arg1 + 0x53) = 1;
    }
    uVar9 = *puVar13 >> 6;
    func_0x00018012b5c0(arg2, uVar9 + 1);
    *(uint32_t *)(*(int64_t *)(arg2 + 8) + (uint64_t)uVar9 * 4) = puVar13[1];
    *(int16_t *)(*(int64_t *)(arg2 + 0x28) + (uint64_t)uVar9 * 2) = (int16_t)iVar3;
    iVar14 = (int64_t)((int32_t)uVar9 >> 0xd) >> 3;
    *(uint8_t *)(iVar14 + 0x34 + *(int64_t *)(arg2 + 0x58)) =
         *(uint8_t *)(iVar14 + 0x34 + *(int64_t *)(arg2 + 0x58)) | (uint8_t)(1 << ((int32_t)uVar9 >> 0xd & 7U));
    return puVar13;
}

// ============================================================
// Function: FUN_18012e8d8
// Address: 0x18012e8d8
// Size: 428 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Variable var_2h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

uint32_t * fcn.18012e840(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    undefined4 *puVar1;
    float fVar2;
    int32_t iVar3;
    int32_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    undefined8 uVar10;
    int64_t iVar11;
    int32_t iVar12;
    uint32_t *puVar13;
    int64_t iVar14;
    float fVar15;
    float fVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar3 = *(int32_t *)(arg2 + 0x30);
    iVar4 = *(int32_t *)(arg2 + 0x34);
    if (iVar3 == iVar4) {
        if (iVar4 == 0) {
            iVar8 = 8;
        } else {
            iVar8 = iVar4 / 2 + iVar4;
        }
        iVar12 = iVar3 + 1;
        if (iVar3 + 1 < iVar8) {
            iVar12 = iVar8;
        }
        if (iVar4 < iVar12) {
            uVar10 = func_0x00018046d050((int64_t)iVar12 * 0x2c);
            if (*(int64_t *)(arg2 + 0x38) != 0) {
                func_0x000180498030(uVar10, *(int64_t *)(arg2 + 0x38), (int64_t)*(int32_t *)(arg2 + 0x30) * 0x2c);
                func_0x000180460d90(*(undefined8 *)(arg2 + 0x38));
            }
            *(undefined8 *)(arg2 + 0x38) = uVar10;
            *(int32_t *)(arg2 + 0x34) = iVar12;
        }
    }
    uVar5 = *(undefined4 *)(arg4 + 4);
    uVar6 = *(undefined4 *)(arg4 + 8);
    uVar7 = *(undefined4 *)(arg4 + 0xc);
    iVar11 = (int64_t)*(int32_t *)(arg2 + 0x30) * 0x2c;
    iVar14 = *(int64_t *)(arg2 + 0x38);
    puVar1 = (undefined4 *)(iVar11 + iVar14);
    *puVar1 = *(undefined4 *)arg4;
    puVar1[1] = uVar5;
    puVar1[2] = uVar6;
    puVar1[3] = uVar7;
    uVar5 = *(undefined4 *)(arg4 + 0x14);
    uVar6 = *(undefined4 *)(arg4 + 0x18);
    uVar7 = *(undefined4 *)(arg4 + 0x1c);
    puVar1 = (undefined4 *)(iVar11 + 0x10 + iVar14);
    *puVar1 = *(undefined4 *)(arg4 + 0x10);
    puVar1[1] = uVar5;
    puVar1[2] = uVar6;
    puVar1[3] = uVar7;
    uVar5 = *(undefined4 *)(arg4 + 0x20);
    uVar6 = *(undefined4 *)(arg4 + 0x24);
    uVar7 = *(undefined4 *)(arg4 + 0x28);
    puVar1 = (undefined4 *)(iVar11 + 0x1c + iVar14);
    *puVar1 = *(undefined4 *)(arg4 + 0x1c);
    puVar1[1] = uVar5;
    puVar1[2] = uVar6;
    puVar1[3] = uVar7;
    *(int32_t *)(arg2 + 0x30) = *(int32_t *)(arg2 + 0x30) + 1;
    puVar13 = (uint32_t *)((int64_t)iVar3 * 0x2c + *(int64_t *)(arg2 + 0x38));
    if (puVar13[10] != 0xffffffff) {
        iVar14 = *(int64_t *)(*(int64_t *)(arg1 + 0x2b0) + 0x68);
        iVar11 = (int64_t)(*(int32_t *)
                            (*(int64_t *)(*(int64_t *)(arg1 + 0x2b0) + 0x78) + (uint64_t)(puVar13[10] & 0x7ffff) * 4) <<
                          0xc) >> 0xc;
        puVar13[6] = (uint32_t)((float)(uint32_t)*(uint16_t *)(iVar14 + iVar11 * 8) * *(float *)(arg1 + 0x54));
        puVar13[7] = (uint32_t)((float)(uint32_t)*(uint16_t *)(iVar14 + 2 + iVar11 * 8) * *(float *)(arg1 + 0x58));
        puVar13[8] = (uint32_t)
                     ((float)((uint32_t)*(uint16_t *)(iVar14 + iVar11 * 8) +
                             (uint32_t)*(uint16_t *)(iVar14 + 4 + iVar11 * 8)) * *(float *)(arg1 + 0x54));
        puVar13[9] = (uint32_t)
                     ((float)((uint32_t)*(uint16_t *)(iVar14 + 6 + iVar11 * 8) +
                             (uint32_t)*(uint16_t *)(iVar14 + 2 + iVar11 * 8)) * *(float *)(arg1 + 0x58));
        uVar9 = *(uint32_t *)(arg2 + 0x4c);
        *(uint32_t *)(arg2 + 0x4c) =
             ((uint32_t)*(uint16_t *)(iVar14 + 6 + iVar11 * 8) * (uint32_t)*(uint16_t *)(iVar14 + 4 + iVar11 * 8) +
              uVar9 ^ uVar9) & 0x3ffffff ^ uVar9;
    }
    if (arg3 != 0) {
        fVar16 = *(float *)(**(int64_t **)(*(int64_t *)(arg2 + 0x58) + 0x28) + 0x3c);
        if (fVar16 == 0.0) {
            fVar16 = 1.0;
        } else {
            fVar16 = *(float *)(arg2 + 0x14) / fVar16;
        }
        fVar2 = (float)puVar13[1];
        fVar15 = fVar16 * *(float *)(arg3 + 0x58);
        if ((fVar15 <= fVar2) && (fVar15 = fVar16 * *(float *)(arg3 + 0x5c), fVar2 <= fVar15)) {
            fVar15 = fVar2;
        }
        if (fVar15 != fVar2) {
            fVar16 = (fVar15 - fVar2) * 0.5;
            if (*(char *)(arg3 + 0x36) != '\0') {
                fVar16 = (float)(int32_t)fVar16;
            }
            puVar13[2] = (uint32_t)(fVar16 + (float)puVar13[2]);
            puVar13[4] = (uint32_t)(fVar16 + (float)puVar13[4]);
        }
        if (*(char *)(arg3 + 0x36) != '\0') {
            fVar15 = (float)(int32_t)(fVar15 + 0.5);
        }
        puVar13[1] = (uint32_t)(fVar15 + *(float *)(arg3 + 0x60));
    }
    if ((*(uint8_t *)puVar13 & 1) != 0) {
        *(undefined *)(*(int64_t *)(arg1 + 0x38) + 0x56) = 1;
        *(undefined *)(arg1 + 0x53) = 1;
    }
    uVar9 = *puVar13 >> 6;
    func_0x00018012b5c0(arg2, uVar9 + 1);
    *(uint32_t *)(*(int64_t *)(arg2 + 8) + (uint64_t)uVar9 * 4) = puVar13[1];
    *(int16_t *)(*(int64_t *)(arg2 + 0x28) + (uint64_t)uVar9 * 2) = (int16_t)iVar3;
    iVar14 = (int64_t)((int32_t)uVar9 >> 0xd) >> 3;
    *(uint8_t *)(iVar14 + 0x34 + *(int64_t *)(arg2 + 0x58)) =
         *(uint8_t *)(iVar14 + 0x34 + *(int64_t *)(arg2 + 0x58)) | (uint8_t)(1 << ((int32_t)uVar9 >> 0xd & 7U));
    return puVar13;
}

// ============================================================
// Function: FUN_18012ea84
// Address: 0x18012ea84
// Size: 115 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Variable var_2h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

uint32_t * fcn.18012e840(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    undefined4 *puVar1;
    float fVar2;
    int32_t iVar3;
    int32_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    undefined8 uVar10;
    int64_t iVar11;
    int32_t iVar12;
    uint32_t *puVar13;
    int64_t iVar14;
    float fVar15;
    float fVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar3 = *(int32_t *)(arg2 + 0x30);
    iVar4 = *(int32_t *)(arg2 + 0x34);
    if (iVar3 == iVar4) {
        if (iVar4 == 0) {
            iVar8 = 8;
        } else {
            iVar8 = iVar4 / 2 + iVar4;
        }
        iVar12 = iVar3 + 1;
        if (iVar3 + 1 < iVar8) {
            iVar12 = iVar8;
        }
        if (iVar4 < iVar12) {
            uVar10 = func_0x00018046d050((int64_t)iVar12 * 0x2c);
            if (*(int64_t *)(arg2 + 0x38) != 0) {
                func_0x000180498030(uVar10, *(int64_t *)(arg2 + 0x38), (int64_t)*(int32_t *)(arg2 + 0x30) * 0x2c);
                func_0x000180460d90(*(undefined8 *)(arg2 + 0x38));
            }
            *(undefined8 *)(arg2 + 0x38) = uVar10;
            *(int32_t *)(arg2 + 0x34) = iVar12;
        }
    }
    uVar5 = *(undefined4 *)(arg4 + 4);
    uVar6 = *(undefined4 *)(arg4 + 8);
    uVar7 = *(undefined4 *)(arg4 + 0xc);
    iVar11 = (int64_t)*(int32_t *)(arg2 + 0x30) * 0x2c;
    iVar14 = *(int64_t *)(arg2 + 0x38);
    puVar1 = (undefined4 *)(iVar11 + iVar14);
    *puVar1 = *(undefined4 *)arg4;
    puVar1[1] = uVar5;
    puVar1[2] = uVar6;
    puVar1[3] = uVar7;
    uVar5 = *(undefined4 *)(arg4 + 0x14);
    uVar6 = *(undefined4 *)(arg4 + 0x18);
    uVar7 = *(undefined4 *)(arg4 + 0x1c);
    puVar1 = (undefined4 *)(iVar11 + 0x10 + iVar14);
    *puVar1 = *(undefined4 *)(arg4 + 0x10);
    puVar1[1] = uVar5;
    puVar1[2] = uVar6;
    puVar1[3] = uVar7;
    uVar5 = *(undefined4 *)(arg4 + 0x20);
    uVar6 = *(undefined4 *)(arg4 + 0x24);
    uVar7 = *(undefined4 *)(arg4 + 0x28);
    puVar1 = (undefined4 *)(iVar11 + 0x1c + iVar14);
    *puVar1 = *(undefined4 *)(arg4 + 0x1c);
    puVar1[1] = uVar5;
    puVar1[2] = uVar6;
    puVar1[3] = uVar7;
    *(int32_t *)(arg2 + 0x30) = *(int32_t *)(arg2 + 0x30) + 1;
    puVar13 = (uint32_t *)((int64_t)iVar3 * 0x2c + *(int64_t *)(arg2 + 0x38));
    if (puVar13[10] != 0xffffffff) {
        iVar14 = *(int64_t *)(*(int64_t *)(arg1 + 0x2b0) + 0x68);
        iVar11 = (int64_t)(*(int32_t *)
                            (*(int64_t *)(*(int64_t *)(arg1 + 0x2b0) + 0x78) + (uint64_t)(puVar13[10] & 0x7ffff) * 4) <<
                          0xc) >> 0xc;
        puVar13[6] = (uint32_t)((float)(uint32_t)*(uint16_t *)(iVar14 + iVar11 * 8) * *(float *)(arg1 + 0x54));
        puVar13[7] = (uint32_t)((float)(uint32_t)*(uint16_t *)(iVar14 + 2 + iVar11 * 8) * *(float *)(arg1 + 0x58));
        puVar13[8] = (uint32_t)
                     ((float)((uint32_t)*(uint16_t *)(iVar14 + iVar11 * 8) +
                             (uint32_t)*(uint16_t *)(iVar14 + 4 + iVar11 * 8)) * *(float *)(arg1 + 0x54));
        puVar13[9] = (uint32_t)
                     ((float)((uint32_t)*(uint16_t *)(iVar14 + 6 + iVar11 * 8) +
                             (uint32_t)*(uint16_t *)(iVar14 + 2 + iVar11 * 8)) * *(float *)(arg1 + 0x58));
        uVar9 = *(uint32_t *)(arg2 + 0x4c);
        *(uint32_t *)(arg2 + 0x4c) =
             ((uint32_t)*(uint16_t *)(iVar14 + 6 + iVar11 * 8) * (uint32_t)*(uint16_t *)(iVar14 + 4 + iVar11 * 8) +
              uVar9 ^ uVar9) & 0x3ffffff ^ uVar9;
    }
    if (arg3 != 0) {
        fVar16 = *(float *)(**(int64_t **)(*(int64_t *)(arg2 + 0x58) + 0x28) + 0x3c);
        if (fVar16 == 0.0) {
            fVar16 = 1.0;
        } else {
            fVar16 = *(float *)(arg2 + 0x14) / fVar16;
        }
        fVar2 = (float)puVar13[1];
        fVar15 = fVar16 * *(float *)(arg3 + 0x58);
        if ((fVar15 <= fVar2) && (fVar15 = fVar16 * *(float *)(arg3 + 0x5c), fVar2 <= fVar15)) {
            fVar15 = fVar2;
        }
        if (fVar15 != fVar2) {
            fVar16 = (fVar15 - fVar2) * 0.5;
            if (*(char *)(arg3 + 0x36) != '\0') {
                fVar16 = (float)(int32_t)fVar16;
            }
            puVar13[2] = (uint32_t)(fVar16 + (float)puVar13[2]);
            puVar13[4] = (uint32_t)(fVar16 + (float)puVar13[4]);
        }
        if (*(char *)(arg3 + 0x36) != '\0') {
            fVar15 = (float)(int32_t)(fVar15 + 0.5);
        }
        puVar13[1] = (uint32_t)(fVar15 + *(float *)(arg3 + 0x60));
    }
    if ((*(uint8_t *)puVar13 & 1) != 0) {
        *(undefined *)(*(int64_t *)(arg1 + 0x38) + 0x56) = 1;
        *(undefined *)(arg1 + 0x53) = 1;
    }
    uVar9 = *puVar13 >> 6;
    func_0x00018012b5c0(arg2, uVar9 + 1);
    *(uint32_t *)(*(int64_t *)(arg2 + 8) + (uint64_t)uVar9 * 4) = puVar13[1];
    *(int16_t *)(*(int64_t *)(arg2 + 0x28) + (uint64_t)uVar9 * 2) = (int16_t)iVar3;
    iVar14 = (int64_t)((int32_t)uVar9 >> 0xd) >> 3;
    *(uint8_t *)(iVar14 + 0x34 + *(int64_t *)(arg2 + 0x58)) =
         *(uint8_t *)(iVar14 + 0x34 + *(int64_t *)(arg2 + 0x58)) | (uint8_t)(1 << ((int32_t)uVar9 >> 0xd & 7U));
    return puVar13;
}

// ============================================================
// Function: FUN_18012eb00
// Address: 0x18012eb00
// Size: 121 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_6h
// WARNING: [rz-ghidra] Detected overlap for variable var_2h

int64_t fcn.18012eb00(int64_t arg1)
{
    uint16_t uVar1;
    int64_t iVar2;
    uint16_t in_DX;
    int64_t unaff_RBX;
    int64_t unaff_retaddr;
    int64_t in_stack_00000008;
    int64_t in_stack_00000010;
    int64_t in_stack_00000018;
    
    if ((uint64_t)in_DX < (uint64_t)(int64_t)*(int32_t *)(arg1 + 0x20)) {
        uVar1 = *(uint16_t *)(*(int64_t *)(arg1 + 0x28) + (uint64_t)in_DX * 2);
        if (uVar1 == 0xfffe) {
            return (int64_t)*(int32_t *)(arg1 + 0x40) * 0x2c + *(int64_t *)(arg1 + 0x38);
        }
        if (uVar1 != 0xffff) {
            return (uint64_t)uVar1 * 0x2c + *(int64_t *)(arg1 + 0x38);
        }
    }
    iVar2 = fcn.18012b6e0(unaff_RBX, unaff_retaddr, in_stack_00000008, in_stack_00000010, in_stack_00000018);
    if (iVar2 == 0) {
        iVar2 = (int64_t)*(int32_t *)(arg1 + 0x40) * 0x2c + *(int64_t *)(arg1 + 0x38);
    }
    return iVar2;
}

// ============================================================
// Function: FUN_18012eb80
// Address: 0x18012eb80
// Size: 102 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_6h
// WARNING: [rz-ghidra] Detected overlap for variable var_2h

int64_t fcn.18012eb80(int64_t arg1)
{
    uint16_t uVar1;
    int64_t iVar2;
    uint16_t in_DX;
    int64_t unaff_RBX;
    int64_t unaff_retaddr;
    int64_t in_stack_00000008;
    int64_t in_stack_00000010;
    int64_t in_stack_00000018;
    
    if ((uint64_t)in_DX < (uint64_t)(int64_t)*(int32_t *)(arg1 + 0x20)) {
        uVar1 = *(uint16_t *)(*(int64_t *)(arg1 + 0x28) + (uint64_t)in_DX * 2);
        if (uVar1 == 0xfffe) {
            return 0;
        }
        if (uVar1 != 0xffff) {
            return (uint64_t)uVar1 * 0x2c + *(int64_t *)(arg1 + 0x38);
        }
    }
    *(uint32_t *)(arg1 + 0x4c) = *(uint32_t *)(arg1 + 0x4c) | 0x8000000;
    iVar2 = fcn.18012b6e0(unaff_RBX, unaff_retaddr, in_stack_00000008, in_stack_00000010, in_stack_00000018);
    *(uint32_t *)(arg1 + 0x4c) = *(uint32_t *)(arg1 + 0x4c) & 0xf7ffffff;
    return iVar2;
}

// ============================================================
// Function: FUN_18012ebf0
// Address: 0x18012ebf0
// Size: 140 bytes
// ============================================================
undefined8 fcn.18012ebf0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    char cVar3;
    int64_t iVar4;
    undefined2 in_DX;
    int64_t *piVar5;
    
    iVar2 = *(int64_t *)(arg1 + 8);
    if (*(int32_t *)(arg1 + 0x38) != 0) {
        in_DX = func_0x0001800f6060((int32_t *)(arg1 + 0x38), in_DX, in_DX);
    }
    piVar5 = *(int64_t **)(arg1 + 0x28);
    piVar1 = piVar5 + *(int32_t *)(arg1 + 0x20);
    while( true ) {
        if (piVar5 == piVar1) {
            return 0;
        }
        iVar4 = *(int64_t *)(*piVar5 + 0x88);
        if (iVar4 == 0) {
            iVar4 = *(int64_t *)(iVar2 + 0x2b8);
        }
        if ((*(code **)(iVar4 + 0x28) != (code *)0x0) &&
           (cVar3 = (**(code **)(iVar4 + 0x28))(iVar2, *piVar5, in_DX), cVar3 != '\0')) break;
        piVar5 = piVar5 + 1;
    }
    return 1;
}

// ============================================================
// Function: FUN_18012ec80
// Address: 0x18012ec80
// Size: 2080 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x00018012f27c)
// WARNING: Removing unreachable block (ram,0x00018012f263)
// WARNING: Removing unreachable block (ram,0x00018012f291)
// WARNING: Variable defined which should be unmapped: var_158h
// WARNING: Variable defined which should be unmapped: var_150h
// WARNING: Variable defined which should be unmapped: var_148h
// WARNING: Variable defined which should be unmapped: var_140h
// WARNING: Variable defined which should be unmapped: var_138h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Variable var_2h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable arg_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_6h
// WARNING: [rz-ghidra] Detected overlap for variable var_2h

void fcn.18012ec80(int64_t arg1)
{
    float fVar1;
    uint16_t uVar2;
    int32_t iVar3;
    int32_t iVar4;
    uint64_t uVar5;
    int32_t iVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    uint32_t uVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    undefined (*pauVar12) [16];
    int64_t iVar13;
    int32_t iVar14;
    undefined (*pauVar15) [16];
    int32_t iVar16;
    uint32_t uVar17;
    uint64_t uVar18;
    uint32_t *puVar19;
    undefined (*pauVar20) [16];
    int64_t iVar21;
    int32_t iVar22;
    uint32_t uVar23;
    int64_t iVar24;
    float in_XMM1_Da;
    float in_XMM2_Da;
    float fVar25;
    undefined auVar26 [16];
    int64_t var_17bh;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_110h;
    int64_t var_100h;
    int64_t var_b8h;
    undefined4 uStack_b0;
    undefined4 uStack_ac;
    int64_t var_90h;
    float var_88h;
    undefined var_84h [4];
    int64_t var_80h;
    int64_t var_40h;
    
    var_80h = *(uint64_t *)0x1806a3940 ^ (int64_t)&var_17bh + 3U;
    iVar24 = *(int64_t *)arg1;
    fVar25 = (float)(int32_t)(in_XMM1_Da + 0.5);
    if (in_XMM2_Da < 0.0) {
        in_XMM2_Da = *(float *)(arg1 + 0x14);
    }
    if (((iVar24 != 0) && (*(float *)(iVar24 + 0x14) == fVar25)) && (*(float *)(iVar24 + 0x18) == in_XMM2_Da))
    goto code_r0x00018012f469;
    iVar24 = *(int64_t *)(arg1 + 8);
    var_130h = *(int64_t *)(iVar24 + 0x2b0);
    var_90h._0_4_ = *(undefined4 *)(arg1 + 0x18);
    var_90h._4_4_ = fVar25;
    var_88h = in_XMM2_Da;
    uVar18 = 0xffffffff;
    piVar10 = &var_90h;
    do {
        uVar17 = (uint32_t)(uVar18 >> 8) ^
                 *(uint32_t *)((uVar18 & 0xff ^ (uint64_t)*(uint8_t *)piVar10) * 4 + 0x180618620);
        uVar18 = (uint64_t)uVar17;
        piVar10 = (int64_t *)((int64_t)piVar10 + 1);
    } while (piVar10 < var_84h);
    uVar17 = ~uVar17;
    uVar11 = (uint64_t)*(int32_t *)(var_130h + 0xd8);
    var_150h = (int64_t)*(uint32_t **)(var_130h + 0xe0);
    uVar18 = uVar11;
    while (uVar5 = uVar18, uVar5 != 0) {
        uVar18 = uVar5 >> 1;
        if (*(uint32_t *)(var_150h + uVar18 * 4 * 4) < uVar17) {
            var_150h = var_150h + (uVar18 * 4 + 4) * 4;
            uVar18 = uVar5 + (-1 - uVar18);
        }
    }
    var_158h._0_4_ = uVar17;
    var_138h = iVar24;
    if (((uint32_t *)var_150h == *(uint32_t **)(var_130h + 0xe0) + uVar11 * 4) || (*(uint32_t *)var_150h != uVar17)) {
        var_148h = CONCAT44(var_148h._4_4_, uVar17);
        var_140h = 0;
        var_150h = func_0x00018011f760((int32_t *)(var_130h + 0xd8), var_150h);
    }
    pauVar12 = *(undefined (**) [16])(var_150h + 8);
    if (*(undefined (**) [16])(var_150h + 8) == (undefined (*) [16])0x0) {
        if (((*(uint8_t *)(arg1 + 0x10) & 8) != 0) || (*(char *)(iVar24 + 0x50) != '\0')) {
            iVar21 = *(int64_t *)(iVar24 + 0x2b0);
            iVar22 = 0;
            iVar3 = *(int32_t *)(iVar21 + 0xc0);
            do {
                pauVar15 = (undefined (*) [16])0x0;
                pauVar20 = (undefined (*) [16])0x0;
                uVar18 = 0;
                if (3 < iVar3) {
                    iVar13 = *(int64_t *)(iVar21 + 0xd0);
                    do {
                        uVar23 = (uint32_t)uVar18;
                        pauVar12 = (undefined (*) [16])
                                   (*(int64_t *)(iVar13 + (uVar18 >> 5) * 8) + (uint64_t)(uVar23 & 0x1f) * 0x68);
                        if (((*(int64_t *)(pauVar12[5] + 8) == arg1) &&
                            ((*(uint32_t *)(pauVar12[4] + 0xc) & 0x4000000) == 0)) &&
                           ((iVar22 != 0 || (*(float *)(pauVar12[1] + 8) == in_XMM2_Da)))) {
                            fVar1 = *(float *)(pauVar12[1] + 4);
                            if ((fVar25 < fVar1) &&
                               ((pauVar15 == (undefined (*) [16])0x0 || (fVar1 < *(float *)(pauVar15[1] + 4))))) {
                                pauVar15 = pauVar12;
                            }
                            if ((fVar1 < fVar25) &&
                               ((pauVar20 == (undefined (*) [16])0x0 ||
                                (*(float *)(pauVar20[1] + 4) <= fVar1 && fVar1 != *(float *)(pauVar20[1] + 4))))) {
                                pauVar20 = pauVar12;
                            }
                        }
                        pauVar12 = (undefined (*) [16])
                                   (*(int64_t *)(iVar13 + (uint64_t)(uVar23 + 1 >> 5) * 8) +
                                   (uint64_t)(uVar23 + 1 & 0x1f) * 0x68);
                        if (((*(int64_t *)(pauVar12[5] + 8) == arg1) &&
                            ((*(uint32_t *)(pauVar12[4] + 0xc) & 0x4000000) == 0)) &&
                           ((iVar22 != 0 || (*(float *)(pauVar12[1] + 8) == in_XMM2_Da)))) {
                            fVar1 = *(float *)(pauVar12[1] + 4);
                            if ((fVar25 < fVar1) &&
                               ((pauVar15 == (undefined (*) [16])0x0 || (fVar1 < *(float *)(pauVar15[1] + 4))))) {
                                pauVar15 = pauVar12;
                            }
                            if ((fVar1 < fVar25) &&
                               ((pauVar20 == (undefined (*) [16])0x0 ||
                                (*(float *)(pauVar20[1] + 4) <= fVar1 && fVar1 != *(float *)(pauVar20[1] + 4))))) {
                                pauVar20 = pauVar12;
                            }
                        }
                        pauVar12 = (undefined (*) [16])
                                   (*(int64_t *)(iVar13 + (uint64_t)(uVar23 + 2 >> 5) * 8) +
                                   (uint64_t)(uVar23 + 2 & 0x1f) * 0x68);
                        if (((*(int64_t *)(pauVar12[5] + 8) == arg1) &&
                            ((*(uint32_t *)(pauVar12[4] + 0xc) & 0x4000000) == 0)) &&
                           ((iVar22 != 0 || (*(float *)(pauVar12[1] + 8) == in_XMM2_Da)))) {
                            fVar1 = *(float *)(pauVar12[1] + 4);
                            if ((fVar25 < fVar1) &&
                               ((pauVar15 == (undefined (*) [16])0x0 || (fVar1 < *(float *)(pauVar15[1] + 4))))) {
                                pauVar15 = pauVar12;
                            }
                            if ((fVar1 < fVar25) &&
                               ((pauVar20 == (undefined (*) [16])0x0 ||
                                (*(float *)(pauVar20[1] + 4) <= fVar1 && fVar1 != *(float *)(pauVar20[1] + 4))))) {
                                pauVar20 = pauVar12;
                            }
                        }
                        pauVar12 = (undefined (*) [16])
                                   (*(int64_t *)(iVar13 + (uint64_t)(uVar23 + 3 >> 5) * 8) +
                                   (uint64_t)(uVar23 + 3 & 0x1f) * 0x68);
                        if (((*(int64_t *)(pauVar12[5] + 8) == arg1) &&
                            ((*(uint32_t *)(pauVar12[4] + 0xc) & 0x4000000) == 0)) &&
                           ((iVar22 != 0 || (*(float *)(pauVar12[1] + 8) == in_XMM2_Da)))) {
                            fVar1 = *(float *)(pauVar12[1] + 4);
                            if ((fVar25 < fVar1) &&
                               ((pauVar15 == (undefined (*) [16])0x0 || (fVar1 < *(float *)(pauVar15[1] + 4))))) {
                                pauVar15 = pauVar12;
                            }
                            if ((fVar1 < fVar25) &&
                               ((pauVar20 == (undefined (*) [16])0x0 ||
                                (*(float *)(pauVar20[1] + 4) <= fVar1 && fVar1 != *(float *)(pauVar20[1] + 4))))) {
                                pauVar20 = pauVar12;
                            }
                        }
                        uVar18 = (uint64_t)(uVar23 + 4);
                        if (iVar3 + -3 <= (int32_t)(uVar23 + 4)) goto code_r0x00018012f08e;
                    } while( true );
                }
                if (0 < iVar3) {
                    iVar13 = *(int64_t *)(iVar21 + 0xd0);
                    do {
                        pauVar12 = (undefined (*) [16])
                                   (*(int64_t *)(iVar13 + (uVar18 >> 5) * 8) +
                                   (uint64_t)((uint32_t)uVar18 & 0x1f) * 0x68);
                        if (((*(int64_t *)(pauVar12[5] + 8) == arg1) &&
                            ((*(uint32_t *)(pauVar12[4] + 0xc) & 0x4000000) == 0)) &&
                           ((iVar22 != 0 || (*(float *)(pauVar12[1] + 8) == in_XMM2_Da)))) {
                            fVar1 = *(float *)(pauVar12[1] + 4);
                            if ((fVar25 < fVar1) &&
                               ((pauVar15 == (undefined (*) [16])0x0 || (fVar1 < *(float *)(pauVar15[1] + 4))))) {
                                pauVar15 = pauVar12;
                            }
                            if ((fVar1 < fVar25) &&
                               ((pauVar20 == (undefined (*) [16])0x0 ||
                                (*(float *)(pauVar20[1] + 4) <= fVar1 && fVar1 != *(float *)(pauVar20[1] + 4))))) {
                                pauVar20 = pauVar12;
                            }
                        }
                        uVar18 = (uint64_t)((uint32_t)uVar18 + 1);
code_r0x00018012f08e:
                    } while ((int32_t)uVar18 < iVar3);
                    if (((pauVar15 != (undefined (*) [16])0x0) &&
                        (((pauVar12 = pauVar15, pauVar20 == (undefined (*) [16])0x0 ||
                          (pauVar12 = pauVar20, *(float *)(pauVar15[1] + 4) < fVar25 + fVar25)) ||
                         (pauVar12 = pauVar15, fVar25 * 0.5 < *(float *)(pauVar20[1] + 4))))) ||
                       (pauVar12 = pauVar20, pauVar20 != (undefined (*) [16])0x0)) goto code_r0x00018012f450;
                }
                iVar22 = iVar22 + 1;
            } while (iVar22 < 2);
            if (*(char *)(iVar24 + 0x50) != '\0') goto code_r0x00018012f469;
        }
        iVar21 = *(int64_t *)(iVar24 + 0x2b0);
        auVar26 = ZEXT816(0);
        iVar13 = 0;
        var_148h = 0;
        stack0xffffffffffffff4c = auVar26._4_12_;
        var_b8h._0_4_ = 0xffffffff;
        iVar3 = *(int32_t *)(iVar21 + 0xc0);
        iVar22 = *(int32_t *)(iVar21 + 0xc4);
        if (iVar3 == iVar22) {
            uVar23 = iVar22 + 0x3fU & 0xffffffe0;
            iVar14 = (int32_t)((iVar22 >> 0x1f & 0x1fU) + iVar22) >> 5;
            iVar22 = (int32_t)(uVar23 + ((int32_t)(iVar22 + 0x3fU) >> 0x1f & 0x1fU)) >> 5;
            iVar24 = var_138h;
            uVar17 = (uint32_t)var_158h;
            if (iVar14 < iVar22) {
                iVar4 = *(int32_t *)(iVar21 + 0xcc);
                if (iVar4 < iVar22) {
                    if (iVar4 == 0) {
                        iVar6 = 8;
                    } else {
                        iVar6 = iVar4 / 2 + iVar4;
                    }
                    iVar16 = iVar22;
                    if (iVar22 < iVar6) {
                        iVar16 = iVar6;
                    }
                    if (iVar4 < iVar16) {
                        uVar7 = func_0x00018046d050((int64_t)iVar16 << 3);
                        if (*(int64_t *)(iVar21 + 0xd0) != 0) {
                            func_0x000180498030(uVar7);
                            func_0x000180460d90(*(undefined8 *)(iVar21 + 0xd0));
                        }
                        *(undefined8 *)(iVar21 + 0xd0) = uVar7;
                        *(int32_t *)(iVar21 + 0xcc) = iVar16;
                    }
                }
                iVar13 = var_148h;
                *(int32_t *)(iVar21 + 200) = iVar22;
                do {
                    uVar7 = func_0x00018046d050(0xd00);
                    *(undefined8 *)(*(int64_t *)(iVar21 + 0xd0) + (int64_t)iVar14 * 8) = uVar7;
                    iVar14 = iVar14 + 1;
                } while (iVar14 < iVar22);
                *(uint32_t *)(iVar21 + 0xc4) = uVar23;
                iVar24 = var_138h;
                uVar17 = (uint32_t)var_158h;
            }
        }
        uVar9 = iVar3 >> 0x1f & 0x1f;
        uVar23 = iVar3 + uVar9;
        pauVar12 = (undefined (*) [16])
                   ((int64_t)(int32_t)((uVar23 & 0x1f) - uVar9) * 0x68 +
                   *(int64_t *)(*(int64_t *)(iVar21 + 0xd0) + (int64_t)((int32_t)uVar23 >> 5) * 8));
        *pauVar12 = auVar26;
        pauVar12[1] = auVar26;
        pauVar12[2] = auVar26;
        pauVar12[3] = auVar26;
        *(undefined4 *)pauVar12[4] = (undefined4)var_b8h;
        *(undefined4 *)(pauVar12[4] + 4) = var_b8h._4_4_;
        *(undefined4 *)(pauVar12[4] + 8) = uStack_b0;
        *(undefined4 *)(pauVar12[4] + 0xc) = uStack_ac;
        pauVar12[5] = auVar26;
        *(int64_t *)pauVar12[6] = iVar13;
        *(int32_t *)(iVar21 + 0xc0) = *(int32_t *)(iVar21 + 0xc0) + 1;
        *(float *)(pauVar12[1] + 4) = fVar25;
        *(float *)(pauVar12[1] + 8) = in_XMM2_Da;
        *(uint32_t *)(pauVar12[5] + 4) = uVar17;
        *(int64_t *)(pauVar12[5] + 8) = arg1;
        *(undefined4 *)pauVar12[5] = *(undefined4 *)(*(int64_t *)(iVar24 + 0x2b0) + 0xa4);
        piVar8 = *(int64_t **)(arg1 + 0x28);
        piVar10 = piVar8 + *(int32_t *)(arg1 + 0x20);
        if (piVar8 == piVar10) {
code_r0x00018012f305:
            iVar21 = 0;
        } else {
            iVar21 = 0;
            do {
                iVar13 = *(int64_t *)(*piVar8 + 0x88);
                if (iVar13 == 0) {
                    iVar13 = *(int64_t *)(iVar24 + 0x2b8);
                }
                iVar21 = iVar21 + *(int64_t *)(iVar13 + 0x48);
                piVar8 = piVar8 + 1;
            } while (piVar8 != piVar10);
            if (iVar21 == 0) goto code_r0x00018012f305;
            iVar21 = func_0x00018046d050(iVar21);
        }
        *(int64_t *)pauVar12[6] = iVar21;
        piVar8 = *(int64_t **)(arg1 + 0x28);
        piVar10 = piVar8 + *(int32_t *)(arg1 + 0x20);
        for (; piVar8 != piVar10; piVar8 = piVar8 + 1) {
            iVar13 = *(int64_t *)(*piVar8 + 0x88);
            if (iVar13 == 0) {
                iVar13 = *(int64_t *)(iVar24 + 0x2b8);
            }
            if (*(code **)(iVar13 + 0x30) != (code *)0x0) {
                (**(code **)(iVar13 + 0x30))(iVar24, *piVar8, pauVar12, iVar21);
            }
            iVar21 = iVar21 + *(int64_t *)(iVar13 + 0x48);
        }
        if (*(uint32_t *)pauVar12[2] < 0x21) {
code_r0x00018012f387:
            *(uint32_t *)(pauVar12[4] + 0xc) = *(uint32_t *)(pauVar12[4] + 0xc) | 0x8000000;
            puVar19 = (uint32_t *)
                      fcn.18012b6e0(CONCAT44(var_158h._4_4_, (uint32_t)var_158h), var_150h, var_148h, var_140h, var_138h
                                   );
            *(uint32_t *)(pauVar12[4] + 0xc) = *(uint32_t *)(pauVar12[4] + 0xc) & 0xf7ffffff;
code_r0x00018012f3a8:
            if (puVar19 != (uint32_t *)0x0) {
                *puVar19 = *puVar19 & 0xfffffffd;
            }
        } else {
            uVar2 = *(uint16_t *)(*(int64_t *)(pauVar12[2] + 8) + 0x40);
            if (uVar2 != 0xfffe) {
                if (uVar2 == 0xffff) goto code_r0x00018012f387;
                puVar19 = (uint32_t *)((uint64_t)uVar2 * 0x2c + *(int64_t *)(pauVar12[3] + 8));
                goto code_r0x00018012f3a8;
            }
            puVar19 = (uint32_t *)0x0;
        }
        if (*(uint32_t *)pauVar12[2] < 10) {
code_r0x00018012f3d2:
            *(uint32_t *)(pauVar12[4] + 0xc) = *(uint32_t *)(pauVar12[4] + 0xc) | 0x8000000;
            iVar21 = fcn.18012b6e0(CONCAT44(var_158h._4_4_, (uint32_t)var_158h), var_150h, var_148h, var_140h, var_138h)
            ;
            *(uint32_t *)(pauVar12[4] + 0xc) = *(uint32_t *)(pauVar12[4] + 0xc) & 0xf7ffffff;
code_r0x00018012f3f0:
            if (iVar21 == 0) goto code_r0x00018012f3f5;
        } else {
            uVar2 = *(uint16_t *)(*(int64_t *)(pauVar12[2] + 8) + 0x12);
            if (uVar2 != 0xfffe) {
                if (uVar2 == 0xffff) goto code_r0x00018012f3d2;
                iVar21 = (uint64_t)uVar2 * 0x2c + *(int64_t *)(pauVar12[3] + 8);
                goto code_r0x00018012f3f0;
            }
code_r0x00018012f3f5:
            if (puVar19 != (uint32_t *)0x0) {
                _var_120h = ZEXT816(0);
                _var_110h = ZEXT816(0);
                var_100h._0_4_ = 0xffffffff;
                var_128h._0_4_ = 0x240;
                var_128h._4_4_ = (float)puVar19[1] * 4.0;
                fcn.18012e840(iVar24, (int64_t)pauVar12, 0, (int64_t)&var_128h, 
                              CONCAT44(var_158h._4_4_, (uint32_t)var_158h));
            }
        }
        *(undefined (**) [16])(var_150h + 8) = pauVar12;
        if (pauVar12 == (undefined (*) [16])0x0) goto code_r0x00018012f469;
    }
code_r0x00018012f450:
    *(undefined4 *)pauVar12[5] = *(undefined4 *)(var_130h + 0xa4);
    *(undefined (**) [16])arg1 = pauVar12;
code_r0x00018012f469:
    func_0x000180459870(var_80h ^ (int64_t)&var_17bh + 3U);
    return;
}

// ============================================================
// Function: FUN_18012f4a0
// Address: 0x18012f4a0
// Size: 539 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h

char * fcn.18012f4a0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_28h,
                    int64_t arg_30h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint32_t uVar3;
    int32_t iVar4;
    uint32_t *puVar5;
    uint32_t uVar6;
    char *pcVar7;
    uint32_t uVar8;
    char *pcVar9;
    int64_t iVar10;
    float fVar11;
    float in_XMM1_Da;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    
    puVar5 = (uint32_t *)fcn.18012ec80(arg1);
    uVar8 = 2;
    uVar1 = arg_30h & 2;
    uVar2 = arg_30h & 2;
    fVar13 = 0.0;
    fVar14 = 0.0;
    fVar15 = (float)arg_28h / (in_XMM1_Da / (float)puVar5[5]);
    fVar12 = 0.0;
    pcVar9 = (char *)arg3;
    pcVar7 = (char *)arg3;
    if ((uint64_t)arg3 < (uint64_t)arg4) {
        do {
            arg_28h._0_4_ = (float)(int32_t)*pcVar9;
            if ((uint32_t)(float)arg_28h < 0x80) {
                iVar10 = 1;
            } else {
                iVar4 = func_0x0001800f5c80(&arg_28h, pcVar9, arg4);
                iVar10 = (int64_t)iVar4;
            }
            uVar3 = (uint32_t)(float)arg_28h;
            if ((uint32_t)(float)arg_28h < 0x20) {
                if ((float)arg_28h == 1.401298e-44) {
                    return pcVar9;
                }
                if ((float)arg_28h != 1.821688e-44) goto code_r0x00018012f57e;
            } else {
code_r0x00018012f57e:
                if ((*puVar5 <= (uint32_t)(float)arg_28h) ||
                   (fVar11 = *(float *)(*(int64_t *)(puVar5 + 2) + (uint64_t)(uint32_t)(float)arg_28h * 4), fVar11 < 0.0
                   )) {
                    fVar11 = (float)func_0x00018012bbd0(puVar5, (uint32_t)(float)arg_28h & 0xffff);
                }
                if (uVar3 < 0x80) {
                    uVar6 = *(uint32_t *)((uint64_t)(uVar3 >> 4) * 4 + 0x1807823a0);
code_r0x00018012f5ca:
                    uVar6 = uVar6 >> ((uint8_t)uVar3 & 0xf) * '\x02' & 3;
                    if (uVar6 != 0) goto code_r0x00018012f5fa;
                    if ((uVar8 != 0) && (uVar1 == 0)) {
                        fVar13 = fVar13 + fVar12;
                        fVar12 = 0.0;
                        pcVar7 = pcVar9;
                    }
                    fVar14 = fVar14 + fVar11;
                } else {
                    uVar6 = *(uint32_t *)0x180782388;
                    if (uVar3 - 0x3000 < 0x10) goto code_r0x00018012f5ca;
                    uVar6 = 2;
code_r0x00018012f5fa:
                    if (uVar8 == 1) {
                        if ((uVar6 != 1) && (9 < uVar3 - 0x30)) {
code_r0x00018012f616:
                            fVar12 = fVar12 + fVar14;
                            fVar14 = 0.0;
                            fVar13 = fVar13 + fVar12;
                            fVar12 = 0.0;
                            pcVar7 = pcVar9;
                        }
                    } else if ((uVar8 == 0) && (uVar2 != 0)) goto code_r0x00018012f616;
                    fVar12 = fVar12 + fVar11;
                }
                uVar8 = uVar6;
                if (fVar15 < fVar12 + fVar14 + fVar13) {
                    if (fVar12 + fVar14 <= fVar15) {
                        return pcVar7;
                    }
                    break;
                }
            }
            pcVar9 = pcVar9 + iVar10;
        } while (pcVar9 < (uint64_t)arg4);
        if (pcVar9 == (char *)arg3) {
            arg_28h._0_4_ = 0.0;
            iVar4 = func_0x0001800f5c80(&arg_28h, pcVar9, arg4);
            pcVar9 = pcVar9 + iVar4;
        }
    }
    return pcVar9;
}

// ============================================================
// Function: FUN_18012f6c0
// Address: 0x18012f6c0
// Size: 114 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h

void fcn.18012f6c0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h)
{
    float fVar1;
    uint32_t uVar2;
    int64_t arg1_00;
    uint32_t *puVar3;
    float in_XMM2_Da;
    float fVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_8h;
    
    arg1_00 = fcn.18012ec80(arg1);
    puVar3 = (uint32_t *)fcn.18012eb00(arg1_00);
    if ((puVar3 != (uint32_t *)0x0) && ((*puVar3 & 2) != 0)) {
        uVar2 = (uint32_t)arg_28h | 0xffffff;
        if ((*puVar3 & 1) == 0) {
            uVar2 = (uint32_t)arg_28h;
        }
        if (in_XMM2_Da < 0.0) {
            fVar6 = 1.0;
        } else {
            fVar6 = in_XMM2_Da / *(float *)(arg1_00 + 0x14);
        }
        fVar8 = fVar6 * (float)puVar3[2] + (float)(int32_t)*(float *)arg4;
        fVar7 = fVar6 * (float)puVar3[4] + (float)(int32_t)*(float *)arg4;
        if ((arg_38h == 0) ||
           ((fVar8 < *(float *)(arg_38h + 8) || fVar8 == *(float *)(arg_38h + 8) && (*(float *)arg_38h <= fVar7)))) {
            fVar10 = (float)puVar3[9];
            fVar11 = (float)puVar3[8];
            fVar5 = (float)puVar3[7];
            fVar4 = (float)puVar3[6];
            fVar9 = fVar6 * (float)puVar3[3] + (float)(int32_t)*(float *)(arg4 + 4);
            fVar6 = fVar6 * (float)puVar3[5] + (float)(int32_t)*(float *)(arg4 + 4);
            if (arg_38h != 0) {
                fVar1 = *(float *)arg_38h;
                if (fVar8 < fVar1) {
                    fVar4 = (1.0 - (fVar7 - fVar1) / (fVar7 - fVar8)) * (fVar11 - fVar4) + fVar4;
                    fVar8 = fVar1;
                }
                fVar1 = *(float *)(arg_38h + 4);
                if (fVar9 < fVar1) {
                    fVar5 = (1.0 - (fVar6 - fVar1) / (fVar6 - fVar9)) * (fVar10 - fVar5) + fVar5;
                    fVar9 = fVar1;
                }
                fVar1 = *(float *)(arg_38h + 8);
                if (fVar1 < fVar7) {
                    fVar11 = ((fVar1 - fVar8) / (fVar7 - fVar8)) * (fVar11 - fVar4) + fVar4;
                    fVar7 = fVar1;
                }
                fVar1 = *(float *)(arg_38h + 0xc);
                if (fVar1 < fVar6) {
                    fVar10 = ((fVar1 - fVar9) / (fVar6 - fVar9)) * (fVar10 - fVar5) + fVar5;
                    fVar6 = fVar1;
                }
                if (fVar6 <= fVar9) {
                    return;
                }
            }
            func_0x000180124680(arg2, 6, 4);
            var_a8h._0_4_ = fVar11;
            var_a8h._4_4_ = fVar10;
            var_a0h._0_4_ = fVar4;
            var_a0h._4_4_ = fVar5;
            var_98h._0_4_ = fVar7;
            var_98h._4_4_ = fVar6;
            var_90h._0_4_ = fVar8;
            var_90h._4_4_ = fVar9;
            func_0x000180124790(arg2, &var_90h, &var_98h, &var_a0h, &var_a8h, uVar2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18012f732
// Address: 0x18012f732
// Size: 133 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h

void fcn.18012f6c0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h)
{
    float fVar1;
    uint32_t uVar2;
    int64_t arg1_00;
    uint32_t *puVar3;
    float in_XMM2_Da;
    float fVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_8h;
    
    arg1_00 = fcn.18012ec80(arg1);
    puVar3 = (uint32_t *)fcn.18012eb00(arg1_00);
    if ((puVar3 != (uint32_t *)0x0) && ((*puVar3 & 2) != 0)) {
        uVar2 = (uint32_t)arg_28h | 0xffffff;
        if ((*puVar3 & 1) == 0) {
            uVar2 = (uint32_t)arg_28h;
        }
        if (in_XMM2_Da < 0.0) {
            fVar6 = 1.0;
        } else {
            fVar6 = in_XMM2_Da / *(float *)(arg1_00 + 0x14);
        }
        fVar8 = fVar6 * (float)puVar3[2] + (float)(int32_t)*(float *)arg4;
        fVar7 = fVar6 * (float)puVar3[4] + (float)(int32_t)*(float *)arg4;
        if ((arg_38h == 0) ||
           ((fVar8 < *(float *)(arg_38h + 8) || fVar8 == *(float *)(arg_38h + 8) && (*(float *)arg_38h <= fVar7)))) {
            fVar10 = (float)puVar3[9];
            fVar11 = (float)puVar3[8];
            fVar5 = (float)puVar3[7];
            fVar4 = (float)puVar3[6];
            fVar9 = fVar6 * (float)puVar3[3] + (float)(int32_t)*(float *)(arg4 + 4);
            fVar6 = fVar6 * (float)puVar3[5] + (float)(int32_t)*(float *)(arg4 + 4);
            if (arg_38h != 0) {
                fVar1 = *(float *)arg_38h;
                if (fVar8 < fVar1) {
                    fVar4 = (1.0 - (fVar7 - fVar1) / (fVar7 - fVar8)) * (fVar11 - fVar4) + fVar4;
                    fVar8 = fVar1;
                }
                fVar1 = *(float *)(arg_38h + 4);
                if (fVar9 < fVar1) {
                    fVar5 = (1.0 - (fVar6 - fVar1) / (fVar6 - fVar9)) * (fVar10 - fVar5) + fVar5;
                    fVar9 = fVar1;
                }
                fVar1 = *(float *)(arg_38h + 8);
                if (fVar1 < fVar7) {
                    fVar11 = ((fVar1 - fVar8) / (fVar7 - fVar8)) * (fVar11 - fVar4) + fVar4;
                    fVar7 = fVar1;
                }
                fVar1 = *(float *)(arg_38h + 0xc);
                if (fVar1 < fVar6) {
                    fVar10 = ((fVar1 - fVar9) / (fVar6 - fVar9)) * (fVar10 - fVar5) + fVar5;
                    fVar6 = fVar1;
                }
                if (fVar6 <= fVar9) {
                    return;
                }
            }
            func_0x000180124680(arg2, 6, 4);
            var_a8h._0_4_ = fVar11;
            var_a8h._4_4_ = fVar10;
            var_a0h._0_4_ = fVar4;
            var_a0h._4_4_ = fVar5;
            var_98h._0_4_ = fVar7;
            var_98h._4_4_ = fVar6;
            var_90h._0_4_ = fVar8;
            var_90h._4_4_ = fVar9;
            func_0x000180124790(arg2, &var_90h, &var_98h, &var_a0h, &var_a8h, uVar2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18012f7b7
// Address: 0x18012f7b7
// Size: 486 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h

void fcn.18012f6c0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h)
{
    float fVar1;
    uint32_t uVar2;
    int64_t arg1_00;
    uint32_t *puVar3;
    float in_XMM2_Da;
    float fVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_8h;
    
    arg1_00 = fcn.18012ec80(arg1);
    puVar3 = (uint32_t *)fcn.18012eb00(arg1_00);
    if ((puVar3 != (uint32_t *)0x0) && ((*puVar3 & 2) != 0)) {
        uVar2 = (uint32_t)arg_28h | 0xffffff;
        if ((*puVar3 & 1) == 0) {
            uVar2 = (uint32_t)arg_28h;
        }
        if (in_XMM2_Da < 0.0) {
            fVar6 = 1.0;
        } else {
            fVar6 = in_XMM2_Da / *(float *)(arg1_00 + 0x14);
        }
        fVar8 = fVar6 * (float)puVar3[2] + (float)(int32_t)*(float *)arg4;
        fVar7 = fVar6 * (float)puVar3[4] + (float)(int32_t)*(float *)arg4;
        if ((arg_38h == 0) ||
           ((fVar8 < *(float *)(arg_38h + 8) || fVar8 == *(float *)(arg_38h + 8) && (*(float *)arg_38h <= fVar7)))) {
            fVar10 = (float)puVar3[9];
            fVar11 = (float)puVar3[8];
            fVar5 = (float)puVar3[7];
            fVar4 = (float)puVar3[6];
            fVar9 = fVar6 * (float)puVar3[3] + (float)(int32_t)*(float *)(arg4 + 4);
            fVar6 = fVar6 * (float)puVar3[5] + (float)(int32_t)*(float *)(arg4 + 4);
            if (arg_38h != 0) {
                fVar1 = *(float *)arg_38h;
                if (fVar8 < fVar1) {
                    fVar4 = (1.0 - (fVar7 - fVar1) / (fVar7 - fVar8)) * (fVar11 - fVar4) + fVar4;
                    fVar8 = fVar1;
                }
                fVar1 = *(float *)(arg_38h + 4);
                if (fVar9 < fVar1) {
                    fVar5 = (1.0 - (fVar6 - fVar1) / (fVar6 - fVar9)) * (fVar10 - fVar5) + fVar5;
                    fVar9 = fVar1;
                }
                fVar1 = *(float *)(arg_38h + 8);
                if (fVar1 < fVar7) {
                    fVar11 = ((fVar1 - fVar8) / (fVar7 - fVar8)) * (fVar11 - fVar4) + fVar4;
                    fVar7 = fVar1;
                }
                fVar1 = *(float *)(arg_38h + 0xc);
                if (fVar1 < fVar6) {
                    fVar10 = ((fVar1 - fVar9) / (fVar6 - fVar9)) * (fVar10 - fVar5) + fVar5;
                    fVar6 = fVar1;
                }
                if (fVar6 <= fVar9) {
                    return;
                }
            }
            func_0x000180124680(arg2, 6, 4);
            var_a8h._0_4_ = fVar11;
            var_a8h._4_4_ = fVar10;
            var_a0h._0_4_ = fVar4;
            var_a0h._4_4_ = fVar5;
            var_98h._0_4_ = fVar7;
            var_98h._4_4_ = fVar6;
            var_90h._0_4_ = fVar8;
            var_90h._4_4_ = fVar9;
            func_0x000180124790(arg2, &var_90h, &var_98h, &var_a0h, &var_a8h, uVar2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18012f99d
// Address: 0x18012f99d
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h

void fcn.18012f6c0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h)
{
    float fVar1;
    uint32_t uVar2;
    int64_t arg1_00;
    uint32_t *puVar3;
    float in_XMM2_Da;
    float fVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_8h;
    
    arg1_00 = fcn.18012ec80(arg1);
    puVar3 = (uint32_t *)fcn.18012eb00(arg1_00);
    if ((puVar3 != (uint32_t *)0x0) && ((*puVar3 & 2) != 0)) {
        uVar2 = (uint32_t)arg_28h | 0xffffff;
        if ((*puVar3 & 1) == 0) {
            uVar2 = (uint32_t)arg_28h;
        }
        if (in_XMM2_Da < 0.0) {
            fVar6 = 1.0;
        } else {
            fVar6 = in_XMM2_Da / *(float *)(arg1_00 + 0x14);
        }
        fVar8 = fVar6 * (float)puVar3[2] + (float)(int32_t)*(float *)arg4;
        fVar7 = fVar6 * (float)puVar3[4] + (float)(int32_t)*(float *)arg4;
        if ((arg_38h == 0) ||
           ((fVar8 < *(float *)(arg_38h + 8) || fVar8 == *(float *)(arg_38h + 8) && (*(float *)arg_38h <= fVar7)))) {
            fVar10 = (float)puVar3[9];
            fVar11 = (float)puVar3[8];
            fVar5 = (float)puVar3[7];
            fVar4 = (float)puVar3[6];
            fVar9 = fVar6 * (float)puVar3[3] + (float)(int32_t)*(float *)(arg4 + 4);
            fVar6 = fVar6 * (float)puVar3[5] + (float)(int32_t)*(float *)(arg4 + 4);
            if (arg_38h != 0) {
                fVar1 = *(float *)arg_38h;
                if (fVar8 < fVar1) {
                    fVar4 = (1.0 - (fVar7 - fVar1) / (fVar7 - fVar8)) * (fVar11 - fVar4) + fVar4;
                    fVar8 = fVar1;
                }
                fVar1 = *(float *)(arg_38h + 4);
                if (fVar9 < fVar1) {
                    fVar5 = (1.0 - (fVar6 - fVar1) / (fVar6 - fVar9)) * (fVar10 - fVar5) + fVar5;
                    fVar9 = fVar1;
                }
                fVar1 = *(float *)(arg_38h + 8);
                if (fVar1 < fVar7) {
                    fVar11 = ((fVar1 - fVar8) / (fVar7 - fVar8)) * (fVar11 - fVar4) + fVar4;
                    fVar7 = fVar1;
                }
                fVar1 = *(float *)(arg_38h + 0xc);
                if (fVar1 < fVar6) {
                    fVar10 = ((fVar1 - fVar9) / (fVar6 - fVar9)) * (fVar10 - fVar5) + fVar5;
                    fVar6 = fVar1;
                }
                if (fVar6 <= fVar9) {
                    return;
                }
            }
            func_0x000180124680(arg2, 6, 4);
            var_a8h._0_4_ = fVar11;
            var_a8h._4_4_ = fVar10;
            var_a0h._0_4_ = fVar4;
            var_a0h._4_4_ = fVar5;
            var_98h._0_4_ = fVar7;
            var_98h._4_4_ = fVar6;
            var_90h._0_4_ = fVar8;
            var_90h._4_4_ = fVar9;
            func_0x000180124790(arg2, &var_90h, &var_98h, &var_a0h, &var_a8h, uVar2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18012f9b6
// Address: 0x18012f9b6
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h

void fcn.18012f6c0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h)
{
    float fVar1;
    uint32_t uVar2;
    int64_t arg1_00;
    uint32_t *puVar3;
    float in_XMM2_Da;
    float fVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_8h;
    
    arg1_00 = fcn.18012ec80(arg1);
    puVar3 = (uint32_t *)fcn.18012eb00(arg1_00);
    if ((puVar3 != (uint32_t *)0x0) && ((*puVar3 & 2) != 0)) {
        uVar2 = (uint32_t)arg_28h | 0xffffff;
        if ((*puVar3 & 1) == 0) {
            uVar2 = (uint32_t)arg_28h;
        }
        if (in_XMM2_Da < 0.0) {
            fVar6 = 1.0;
        } else {
            fVar6 = in_XMM2_Da / *(float *)(arg1_00 + 0x14);
        }
        fVar8 = fVar6 * (float)puVar3[2] + (float)(int32_t)*(float *)arg4;
        fVar7 = fVar6 * (float)puVar3[4] + (float)(int32_t)*(float *)arg4;
        if ((arg_38h == 0) ||
           ((fVar8 < *(float *)(arg_38h + 8) || fVar8 == *(float *)(arg_38h + 8) && (*(float *)arg_38h <= fVar7)))) {
            fVar10 = (float)puVar3[9];
            fVar11 = (float)puVar3[8];
            fVar5 = (float)puVar3[7];
            fVar4 = (float)puVar3[6];
            fVar9 = fVar6 * (float)puVar3[3] + (float)(int32_t)*(float *)(arg4 + 4);
            fVar6 = fVar6 * (float)puVar3[5] + (float)(int32_t)*(float *)(arg4 + 4);
            if (arg_38h != 0) {
                fVar1 = *(float *)arg_38h;
                if (fVar8 < fVar1) {
                    fVar4 = (1.0 - (fVar7 - fVar1) / (fVar7 - fVar8)) * (fVar11 - fVar4) + fVar4;
                    fVar8 = fVar1;
                }
                fVar1 = *(float *)(arg_38h + 4);
                if (fVar9 < fVar1) {
                    fVar5 = (1.0 - (fVar6 - fVar1) / (fVar6 - fVar9)) * (fVar10 - fVar5) + fVar5;
                    fVar9 = fVar1;
                }
                fVar1 = *(float *)(arg_38h + 8);
                if (fVar1 < fVar7) {
                    fVar11 = ((fVar1 - fVar8) / (fVar7 - fVar8)) * (fVar11 - fVar4) + fVar4;
                    fVar7 = fVar1;
                }
                fVar1 = *(float *)(arg_38h + 0xc);
                if (fVar1 < fVar6) {
                    fVar10 = ((fVar1 - fVar9) / (fVar6 - fVar9)) * (fVar10 - fVar5) + fVar5;
                    fVar6 = fVar1;
                }
                if (fVar6 <= fVar9) {
                    return;
                }
            }
            func_0x000180124680(arg2, 6, 4);
            var_a8h._0_4_ = fVar11;
            var_a8h._4_4_ = fVar10;
            var_a0h._0_4_ = fVar4;
            var_a0h._4_4_ = fVar5;
            var_98h._0_4_ = fVar7;
            var_98h._4_4_ = fVar6;
            var_90h._0_4_ = fVar8;
            var_90h._4_4_ = fVar9;
            func_0x000180124790(arg2, &var_90h, &var_98h, &var_a0h, &var_a8h, uVar2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18012f9d0
// Address: 0x18012f9d0
// Size: 96 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_128h
// WARNING: Variable defined which should be unmapped: var_120h
// WARNING: Variable defined which should be unmapped: var_118h
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable arg_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_6h
// WARNING: [rz-ghidra] Detected overlap for variable var_2h

void fcn.18012f9d0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t *piVar1;
    float fVar2;
    float fVar3;
    uint16_t uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    bool bVar7;
    int16_t iVar8;
    int32_t iVar9;
    int32_t iVar10;
    float fVar11;
    int64_t iVar12;
    char *pcVar13;
    char *arg3;
    int64_t iVar14;
    char *pcVar15;
    uint64_t uVar16;
    uint32_t *puVar17;
    int32_t iVar18;
    undefined8 placeholder_1;
    uint64_t placeholder_1_00;
    float *pfVar19;
    char *arg4_00;
    int16_t *piVar20;
    int32_t iVar21;
    bool bVar22;
    float in_XMM2_Da;
    float fVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    float fVar31;
    float fVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    undefined auVar36 [16];
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    float fVar37;
    int64_t var_108h;
    int64_t var_fch;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    fVar33 = (float)(int32_t)*(float *)(arg4 + 4);
    if (fVar33 < *(float *)(arg_30h + 0xc) || fVar33 == *(float *)(arg_30h + 0xc)) {
        fVar34 = *(float *)arg4;
        bVar7 = (float)arg_48h <= 0.0;
        do {
            fVar34 = (float)(int32_t)fVar34;
            auVar36 = ZEXT416((uint32_t)fVar34);
            pcVar15 = (char *)arg_40h;
            if ((char *)arg_40h == (char *)0x0) {
                iVar12 = func_0x000180498cd0(arg_38h);
                pcVar15 = (char *)(iVar12 + arg_38h);
            }
            iVar12 = fcn.18012ec80(arg1);
            fVar31 = *(float *)(iVar12 + 0x14);
            arg3 = (char *)arg_38h;
            if (fVar33 + in_XMM2_Da < *(float *)(arg_30h + 4)) {
                do {
                    if (pcVar15 <= arg3) break;
                    placeholder_1 = 10;
                    pcVar13 = (char *)func_0x000180498a80(arg3, 10, (int64_t)pcVar15 - (int64_t)arg3);
                    if (bVar7) {
                        arg3 = pcVar13 + 1;
                        if (pcVar13 == (char *)0x0) {
                            arg3 = pcVar15;
                        }
                    } else {
                        var_120h._0_4_ = (undefined4)arg_50h;
                        arg4_00 = pcVar15;
                        if (pcVar13 != (char *)0x0) {
                            arg4_00 = pcVar13;
                        }
                        arg3 = (char *)fcn.18012f4a0(arg1, placeholder_1, (int64_t)arg3, (int64_t)arg4_00, 
                                                     CONCAT44(var_128h._4_4_, (float)arg_48h), 
                                                     CONCAT44(var_120h._4_4_, (undefined4)arg_50h));
                        var_128h._0_4_ = (float)arg_48h;
                        if ((arg_50h & 2U) == 0) {
                            for (; arg3 < pcVar15; arg3 = arg3 + 1) {
                                if ((*arg3 != ' ') && (*arg3 != '\t')) goto code_r0x00018012fb6c;
                            }
                        } else {
code_r0x00018012fb6c:
                            if ((arg3 < pcVar15) && (*arg3 == '\n')) {
                                arg3 = arg3 + 1;
                            }
                        }
                    }
                    fVar33 = fVar33 + in_XMM2_Da;
                } while (fVar33 + in_XMM2_Da < *(float *)(arg_30h + 4));
            }
            arg_40h = (int64_t)pcVar15;
            if ((10000 < (int64_t)pcVar15 - (int64_t)arg3) && (bVar7)) {
                fVar37 = *(float *)(arg_30h + 0xc);
                arg_40h = (int64_t)arg3;
                fVar28 = fVar33;
                while ((fVar28 < fVar37 && ((uint64_t)arg_40h < pcVar15))) {
                    iVar14 = func_0x000180498a80(arg_40h, 10, (int64_t)pcVar15 - arg_40h);
                    arg_40h = (int64_t)pcVar15;
                    if (iVar14 != 0) {
                        arg_40h = (int64_t)(iVar14 + 1);
                    }
                    fVar28 = fVar28 + in_XMM2_Da;
                }
            }
            if (arg3 == (char *)arg_40h) {
                return;
            }
            iVar9 = (int32_t)arg_40h - (int32_t)arg3;
            fVar31 = in_XMM2_Da / fVar31;
            iVar5 = *(int32_t *)(arg2 + 0x10);
            placeholder_1_00 = (uint64_t)(uint32_t)(iVar9 * 6);
            fVar37 = fVar31;
            func_0x000180124680(arg2, placeholder_1_00, iVar9 * 4);
            iVar18 = *(int32_t *)arg2;
            pfVar19 = *(float **)(arg2 + 0x40);
            piVar20 = *(int16_t **)(arg2 + 0x48);
            iVar21 = *(int32_t *)(arg2 + 0x34);
            pcVar15 = (char *)0x0;
            var_118h._0_4_ = CONCAT31(var_118h._1_3_, (char)arg_50h) & 0xffffff01;
            fVar28 = (float)((uint32_t)(float)arg_28h | 0xffffff);
            if (arg3 < (uint64_t)arg_40h) {
                do {
                    fVar35 = auVar36._0_4_;
                    if (bVar7) {
code_r0x00018012fd48:
                        var_118h._4_4_ = (uint32_t)*arg3;
                        if (var_118h._4_4_ < 0x80) {
                            arg3 = arg3 + 1;
                        } else {
                            iVar10 = func_0x0001800f5c80((int64_t)&var_118h + 4, arg3, arg_40h);
                            arg3 = arg3 + iVar10;
                        }
                        placeholder_1_00 = (uint64_t)var_118h._4_4_;
                        if (var_118h._4_4_ < 0x20) {
                            if (var_118h._4_4_ == 10) {
                                fVar33 = fVar33 + in_XMM2_Da;
                                if (*(float *)(arg_30h + 0xc) <= fVar33 && fVar33 != *(float *)(arg_30h + 0xc)) break;
                                auVar36 = ZEXT416((uint32_t)fVar34);
                            } else if (var_118h._4_4_ != 0xd) goto code_r0x00018012fda2;
                        } else {
code_r0x00018012fda2:
                            if ((placeholder_1_00 & 0xffff) < (uint64_t)(int64_t)*(int32_t *)(iVar12 + 0x20)) {
                                uVar4 = *(uint16_t *)(*(int64_t *)(iVar12 + 0x28) + (placeholder_1_00 & 0xffff) * 2);
                                uVar16 = (uint64_t)uVar4;
                                if (uVar4 == 0xfffe) goto code_r0x00018012fde0;
                                if (uVar4 == 0xffff) goto code_r0x00018012fdd0;
code_r0x00018012fde8:
                                puVar17 = (uint32_t *)(uVar16 * 0x2c + *(int64_t *)(iVar12 + 0x38));
                            } else {
code_r0x00018012fdd0:
                                puVar17 = (uint32_t *)
                                          fcn.18012b6e0(CONCAT44(var_128h._4_4_, (float)var_128h), 
                                                        CONCAT44(var_120h._4_4_, (undefined4)var_120h), 
                                                        CONCAT44(var_118h._4_4_, (uint32_t)var_118h), 
                                                        CONCAT44(fVar37, fVar28), CONCAT44(iVar18, fVar34));
                                if (puVar17 == (uint32_t *)0x0) {
code_r0x00018012fde0:
                                    uVar16 = (uint64_t)*(int32_t *)(iVar12 + 0x40);
                                    goto code_r0x00018012fde8;
                                }
                            }
                            uVar6 = *puVar17;
                            fVar2 = (float)puVar17[1];
                            if ((uVar6 & 2) != 0) {
                                fVar11 = *(float *)(arg_30h + 8);
                                fVar26 = fVar31 * (float)puVar17[2] + fVar35;
                                if (fVar26 <= fVar11) {
                                    fVar3 = *(float *)arg_30h;
                                    fVar25 = fVar31 * (float)puVar17[4] + fVar35;
                                    if (fVar3 <= fVar25) {
                                        fVar23 = (float)puVar17[6];
                                        fVar29 = fVar31 * (float)puVar17[3] + fVar33;
                                        fVar24 = (float)puVar17[7];
                                        fVar32 = (float)puVar17[8];
                                        fVar27 = fVar31 * (float)puVar17[5] + fVar33;
                                        fVar30 = (float)puVar17[9];
                                        if ((char)var_118h != '\0') {
                                            if (fVar26 < fVar3) {
                                                fVar23 = (1.0 - (fVar25 - fVar3) / (fVar25 - fVar26)) *
                                                         (fVar32 - fVar23) + fVar23;
                                                fVar26 = fVar3;
                                            }
                                            fVar3 = *(float *)(arg_30h + 4);
                                            if (fVar29 < fVar3) {
                                                fVar24 = (1.0 - (fVar27 - fVar3) / (fVar27 - fVar29)) *
                                                         (fVar30 - fVar24) + fVar24;
                                                fVar29 = fVar3;
                                            }
                                            if (fVar11 < fVar25) {
                                                fVar32 = ((fVar11 - fVar26) / (fVar25 - fVar26)) * (fVar32 - fVar23) +
                                                         fVar23;
                                                fVar25 = fVar11;
                                            }
                                            fVar11 = *(float *)(arg_30h + 0xc);
                                            if (fVar11 < fVar27) {
                                                fVar30 = ((fVar11 - fVar29) / (fVar27 - fVar29)) * (fVar30 - fVar24) +
                                                         fVar24;
                                                fVar27 = fVar11;
                                            }
                                            if (fVar27 <= fVar29) goto code_r0x000180130013;
                                        }
                                        *pfVar19 = fVar26;
                                        fVar11 = (float)arg_28h;
                                        if ((uVar6 & 1) != 0) {
                                            fVar11 = fVar28;
                                        }
                                        pfVar19[4] = fVar11;
                                        pfVar19[9] = fVar11;
                                        pfVar19[0xe] = fVar11;
                                        pfVar19[0x13] = fVar11;
                                        iVar8 = (int16_t)iVar21;
                                        pfVar19[1] = fVar29;
                                        pfVar19[2] = fVar23;
                                        pfVar19[3] = fVar24;
                                        pfVar19[5] = fVar25;
                                        pfVar19[6] = fVar29;
                                        pfVar19[7] = fVar32;
                                        pfVar19[8] = fVar24;
                                        pfVar19[10] = fVar25;
                                        pfVar19[0xb] = fVar27;
                                        pfVar19[0xc] = fVar32;
                                        pfVar19[0xd] = fVar30;
                                        pfVar19[0xf] = fVar26;
                                        pfVar19[0x10] = fVar27;
                                        pfVar19[0x11] = fVar23;
                                        pfVar19[0x12] = fVar30;
                                        pfVar19 = pfVar19 + 0x14;
                                        piVar20[1] = iVar8 + 1;
                                        piVar20[2] = iVar8 + 2;
                                        piVar20[4] = iVar8 + 2;
                                        *piVar20 = iVar8;
                                        piVar20[3] = iVar8;
                                        iVar21 = iVar21 + 4;
                                        piVar20[5] = iVar8 + 3;
                                        piVar20 = piVar20 + 6;
                                    }
                                }
                            }
code_r0x000180130013:
                            auVar36._0_4_ = fVar35 + fVar31 * fVar2;
                        }
code_r0x000180130029:
                        bVar22 = arg3 < (uint64_t)arg_40h;
                        fVar31 = fVar37;
                    } else {
                        if (pcVar15 == (char *)0x0) {
                            var_128h._0_4_ = (float)arg_48h - (fVar35 - fVar34);
                            pcVar15 = (char *)fcn.18012f4a0(arg1, placeholder_1_00, (int64_t)arg3, arg_40h, 
                                                            CONCAT44(var_128h._4_4_, (float)var_128h), 
                                                            CONCAT44(var_120h._4_4_, (undefined4)arg_50h));
                            var_120h._0_4_ = (undefined4)arg_50h;
                        }
                        if (arg3 < pcVar15) goto code_r0x00018012fd48;
                        fVar33 = fVar33 + in_XMM2_Da;
                        if (*(float *)(arg_30h + 0xc) <= fVar33 && fVar33 != *(float *)(arg_30h + 0xc)) break;
                        pcVar15 = (char *)0x0;
                        auVar36 = ZEXT416((uint32_t)fVar34);
                        fVar31 = fVar37;
                        if ((arg_50h & 2U) != 0) {
code_r0x00018012fd2e:
                            bVar22 = arg3 < (uint64_t)arg_40h;
                            if (!bVar22) goto code_r0x00018013002c;
                            if (*arg3 == '\n') {
                                arg3 = arg3 + 1;
                            }
                            goto code_r0x000180130029;
                        }
                        bVar22 = arg3 < (uint64_t)arg_40h;
                        if (bVar22) {
                            do {
                                if ((*arg3 != ' ') && (*arg3 != '\t')) goto code_r0x00018012fd2e;
                                arg3 = arg3 + 1;
                            } while (arg3 < (uint64_t)arg_40h);
                            goto code_r0x000180130029;
                        }
                    }
code_r0x00018013002c:
                    fVar37 = fVar31;
                } while (bVar22);
            }
            iVar10 = *(int32_t *)arg2;
            if (iVar18 == iVar10) {
                iVar18 = (int32_t)((int64_t)piVar20 - *(int64_t *)(arg2 + 0x18) >> 1);
                *(int32_t *)(arg2 + 0x10) = iVar18;
                *(int32_t *)(arg2 + 0x20) = (int32_t)((int64_t)pfVar19 - *(int64_t *)(arg2 + 0x28) >> 2) * -0x33333333;
                piVar1 = (int32_t *)(*(int64_t *)(arg2 + 8) + -0x20 + (int64_t)iVar10 * 0x48);
                *piVar1 = *piVar1 + (iVar18 - (iVar5 + iVar9 * 6));
                *(float **)(arg2 + 0x40) = pfVar19;
                *(int16_t **)(arg2 + 0x48) = piVar20;
                *(int32_t *)(arg2 + 0x34) = iVar21;
                return;
            }
            *(int32_t *)arg2 = iVar10 + -1;
            piVar1 = (int32_t *)(*(int64_t *)(arg2 + 8) + -0x68 + (int64_t)iVar10 * 0x48);
            *piVar1 = *piVar1 + iVar9 * -6;
            *(int32_t *)(arg2 + 0x20) = *(int32_t *)(arg2 + 0x20) + iVar9 * -4;
            *(int32_t *)(arg2 + 0x10) = *(int32_t *)(arg2 + 0x10) + iVar9 * -6;
            func_0x000180124200(arg2);
            fVar34 = *(float *)arg4;
            fVar33 = (float)(int32_t)*(float *)(arg4 + 4);
        } while (fVar33 < *(float *)(arg_30h + 0xc) || fVar33 == *(float *)(arg_30h + 0xc));
    }
    return;
}

// ============================================================
// Function: FUN_18012fa30
// Address: 0x18012fa30
// Size: 1868 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_128h
// WARNING: Variable defined which should be unmapped: var_120h
// WARNING: Variable defined which should be unmapped: var_118h
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable arg_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_6h
// WARNING: [rz-ghidra] Detected overlap for variable var_2h

void fcn.18012f9d0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t *piVar1;
    float fVar2;
    float fVar3;
    uint16_t uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    bool bVar7;
    int16_t iVar8;
    int32_t iVar9;
    int32_t iVar10;
    float fVar11;
    int64_t iVar12;
    char *pcVar13;
    char *arg3;
    int64_t iVar14;
    char *pcVar15;
    uint64_t uVar16;
    uint32_t *puVar17;
    int32_t iVar18;
    undefined8 placeholder_1;
    uint64_t placeholder_1_00;
    float *pfVar19;
    char *arg4_00;
    int16_t *piVar20;
    int32_t iVar21;
    bool bVar22;
    float in_XMM2_Da;
    float fVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    float fVar31;
    float fVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    undefined auVar36 [16];
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    float fVar37;
    int64_t var_108h;
    int64_t var_fch;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    fVar33 = (float)(int32_t)*(float *)(arg4 + 4);
    if (fVar33 < *(float *)(arg_30h + 0xc) || fVar33 == *(float *)(arg_30h + 0xc)) {
        fVar34 = *(float *)arg4;
        bVar7 = (float)arg_48h <= 0.0;
        do {
            fVar34 = (float)(int32_t)fVar34;
            auVar36 = ZEXT416((uint32_t)fVar34);
            pcVar15 = (char *)arg_40h;
            if ((char *)arg_40h == (char *)0x0) {
                iVar12 = func_0x000180498cd0(arg_38h);
                pcVar15 = (char *)(iVar12 + arg_38h);
            }
            iVar12 = fcn.18012ec80(arg1);
            fVar31 = *(float *)(iVar12 + 0x14);
            arg3 = (char *)arg_38h;
            if (fVar33 + in_XMM2_Da < *(float *)(arg_30h + 4)) {
                do {
                    if (pcVar15 <= arg3) break;
                    placeholder_1 = 10;
                    pcVar13 = (char *)func_0x000180498a80(arg3, 10, (int64_t)pcVar15 - (int64_t)arg3);
                    if (bVar7) {
                        arg3 = pcVar13 + 1;
                        if (pcVar13 == (char *)0x0) {
                            arg3 = pcVar15;
                        }
                    } else {
                        var_120h._0_4_ = (undefined4)arg_50h;
                        arg4_00 = pcVar15;
                        if (pcVar13 != (char *)0x0) {
                            arg4_00 = pcVar13;
                        }
                        arg3 = (char *)fcn.18012f4a0(arg1, placeholder_1, (int64_t)arg3, (int64_t)arg4_00, 
                                                     CONCAT44(var_128h._4_4_, (float)arg_48h), 
                                                     CONCAT44(var_120h._4_4_, (undefined4)arg_50h));
                        var_128h._0_4_ = (float)arg_48h;
                        if ((arg_50h & 2U) == 0) {
                            for (; arg3 < pcVar15; arg3 = arg3 + 1) {
                                if ((*arg3 != ' ') && (*arg3 != '\t')) goto code_r0x00018012fb6c;
                            }
                        } else {
code_r0x00018012fb6c:
                            if ((arg3 < pcVar15) && (*arg3 == '\n')) {
                                arg3 = arg3 + 1;
                            }
                        }
                    }
                    fVar33 = fVar33 + in_XMM2_Da;
                } while (fVar33 + in_XMM2_Da < *(float *)(arg_30h + 4));
            }
            arg_40h = (int64_t)pcVar15;
            if ((10000 < (int64_t)pcVar15 - (int64_t)arg3) && (bVar7)) {
                fVar37 = *(float *)(arg_30h + 0xc);
                arg_40h = (int64_t)arg3;
                fVar28 = fVar33;
                while ((fVar28 < fVar37 && ((uint64_t)arg_40h < pcVar15))) {
                    iVar14 = func_0x000180498a80(arg_40h, 10, (int64_t)pcVar15 - arg_40h);
                    arg_40h = (int64_t)pcVar15;
                    if (iVar14 != 0) {
                        arg_40h = (int64_t)(iVar14 + 1);
                    }
                    fVar28 = fVar28 + in_XMM2_Da;
                }
            }
            if (arg3 == (char *)arg_40h) {
                return;
            }
            iVar9 = (int32_t)arg_40h - (int32_t)arg3;
            fVar31 = in_XMM2_Da / fVar31;
            iVar5 = *(int32_t *)(arg2 + 0x10);
            placeholder_1_00 = (uint64_t)(uint32_t)(iVar9 * 6);
            fVar37 = fVar31;
            func_0x000180124680(arg2, placeholder_1_00, iVar9 * 4);
            iVar18 = *(int32_t *)arg2;
            pfVar19 = *(float **)(arg2 + 0x40);
            piVar20 = *(int16_t **)(arg2 + 0x48);
            iVar21 = *(int32_t *)(arg2 + 0x34);
            pcVar15 = (char *)0x0;
            var_118h._0_4_ = CONCAT31(var_118h._1_3_, (char)arg_50h) & 0xffffff01;
            fVar28 = (float)((uint32_t)(float)arg_28h | 0xffffff);
            if (arg3 < (uint64_t)arg_40h) {
                do {
                    fVar35 = auVar36._0_4_;
                    if (bVar7) {
code_r0x00018012fd48:
                        var_118h._4_4_ = (uint32_t)*arg3;
                        if (var_118h._4_4_ < 0x80) {
                            arg3 = arg3 + 1;
                        } else {
                            iVar10 = func_0x0001800f5c80((int64_t)&var_118h + 4, arg3, arg_40h);
                            arg3 = arg3 + iVar10;
                        }
                        placeholder_1_00 = (uint64_t)var_118h._4_4_;
                        if (var_118h._4_4_ < 0x20) {
                            if (var_118h._4_4_ == 10) {
                                fVar33 = fVar33 + in_XMM2_Da;
                                if (*(float *)(arg_30h + 0xc) <= fVar33 && fVar33 != *(float *)(arg_30h + 0xc)) break;
                                auVar36 = ZEXT416((uint32_t)fVar34);
                            } else if (var_118h._4_4_ != 0xd) goto code_r0x00018012fda2;
                        } else {
code_r0x00018012fda2:
                            if ((placeholder_1_00 & 0xffff) < (uint64_t)(int64_t)*(int32_t *)(iVar12 + 0x20)) {
                                uVar4 = *(uint16_t *)(*(int64_t *)(iVar12 + 0x28) + (placeholder_1_00 & 0xffff) * 2);
                                uVar16 = (uint64_t)uVar4;
                                if (uVar4 == 0xfffe) goto code_r0x00018012fde0;
                                if (uVar4 == 0xffff) goto code_r0x00018012fdd0;
code_r0x00018012fde8:
                                puVar17 = (uint32_t *)(uVar16 * 0x2c + *(int64_t *)(iVar12 + 0x38));
                            } else {
code_r0x00018012fdd0:
                                puVar17 = (uint32_t *)
                                          fcn.18012b6e0(CONCAT44(var_128h._4_4_, (float)var_128h), 
                                                        CONCAT44(var_120h._4_4_, (undefined4)var_120h), 
                                                        CONCAT44(var_118h._4_4_, (uint32_t)var_118h), 
                                                        CONCAT44(fVar37, fVar28), CONCAT44(iVar18, fVar34));
                                if (puVar17 == (uint32_t *)0x0) {
code_r0x00018012fde0:
                                    uVar16 = (uint64_t)*(int32_t *)(iVar12 + 0x40);
                                    goto code_r0x00018012fde8;
                                }
                            }
                            uVar6 = *puVar17;
                            fVar2 = (float)puVar17[1];
                            if ((uVar6 & 2) != 0) {
                                fVar11 = *(float *)(arg_30h + 8);
                                fVar26 = fVar31 * (float)puVar17[2] + fVar35;
                                if (fVar26 <= fVar11) {
                                    fVar3 = *(float *)arg_30h;
                                    fVar25 = fVar31 * (float)puVar17[4] + fVar35;
                                    if (fVar3 <= fVar25) {
                                        fVar23 = (float)puVar17[6];
                                        fVar29 = fVar31 * (float)puVar17[3] + fVar33;
                                        fVar24 = (float)puVar17[7];
                                        fVar32 = (float)puVar17[8];
                                        fVar27 = fVar31 * (float)puVar17[5] + fVar33;
                                        fVar30 = (float)puVar17[9];
                                        if ((char)var_118h != '\0') {
                                            if (fVar26 < fVar3) {
                                                fVar23 = (1.0 - (fVar25 - fVar3) / (fVar25 - fVar26)) *
                                                         (fVar32 - fVar23) + fVar23;
                                                fVar26 = fVar3;
                                            }
                                            fVar3 = *(float *)(arg_30h + 4);
                                            if (fVar29 < fVar3) {
                                                fVar24 = (1.0 - (fVar27 - fVar3) / (fVar27 - fVar29)) *
                                                         (fVar30 - fVar24) + fVar24;
                                                fVar29 = fVar3;
                                            }
                                            if (fVar11 < fVar25) {
                                                fVar32 = ((fVar11 - fVar26) / (fVar25 - fVar26)) * (fVar32 - fVar23) +
                                                         fVar23;
                                                fVar25 = fVar11;
                                            }
                                            fVar11 = *(float *)(arg_30h + 0xc);
                                            if (fVar11 < fVar27) {
                                                fVar30 = ((fVar11 - fVar29) / (fVar27 - fVar29)) * (fVar30 - fVar24) +
                                                         fVar24;
                                                fVar27 = fVar11;
                                            }
                                            if (fVar27 <= fVar29) goto code_r0x000180130013;
                                        }
                                        *pfVar19 = fVar26;
                                        fVar11 = (float)arg_28h;
                                        if ((uVar6 & 1) != 0) {
                                            fVar11 = fVar28;
                                        }
                                        pfVar19[4] = fVar11;
                                        pfVar19[9] = fVar11;
                                        pfVar19[0xe] = fVar11;
                                        pfVar19[0x13] = fVar11;
                                        iVar8 = (int16_t)iVar21;
                                        pfVar19[1] = fVar29;
                                        pfVar19[2] = fVar23;
                                        pfVar19[3] = fVar24;
                                        pfVar19[5] = fVar25;
                                        pfVar19[6] = fVar29;
                                        pfVar19[7] = fVar32;
                                        pfVar19[8] = fVar24;
                                        pfVar19[10] = fVar25;
                                        pfVar19[0xb] = fVar27;
                                        pfVar19[0xc] = fVar32;
                                        pfVar19[0xd] = fVar30;
                                        pfVar19[0xf] = fVar26;
                                        pfVar19[0x10] = fVar27;
                                        pfVar19[0x11] = fVar23;
                                        pfVar19[0x12] = fVar30;
                                        pfVar19 = pfVar19 + 0x14;
                                        piVar20[1] = iVar8 + 1;
                                        piVar20[2] = iVar8 + 2;
                                        piVar20[4] = iVar8 + 2;
                                        *piVar20 = iVar8;
                                        piVar20[3] = iVar8;
                                        iVar21 = iVar21 + 4;
                                        piVar20[5] = iVar8 + 3;
                                        piVar20 = piVar20 + 6;
                                    }
                                }
                            }
code_r0x000180130013:
                            auVar36._0_4_ = fVar35 + fVar31 * fVar2;
                        }
code_r0x000180130029:
                        bVar22 = arg3 < (uint64_t)arg_40h;
                        fVar31 = fVar37;
                    } else {
                        if (pcVar15 == (char *)0x0) {
                            var_128h._0_4_ = (float)arg_48h - (fVar35 - fVar34);
                            pcVar15 = (char *)fcn.18012f4a0(arg1, placeholder_1_00, (int64_t)arg3, arg_40h, 
                                                            CONCAT44(var_128h._4_4_, (float)var_128h), 
                                                            CONCAT44(var_120h._4_4_, (undefined4)arg_50h));
                            var_120h._0_4_ = (undefined4)arg_50h;
                        }
                        if (arg3 < pcVar15) goto code_r0x00018012fd48;
                        fVar33 = fVar33 + in_XMM2_Da;
                        if (*(float *)(arg_30h + 0xc) <= fVar33 && fVar33 != *(float *)(arg_30h + 0xc)) break;
                        pcVar15 = (char *)0x0;
                        auVar36 = ZEXT416((uint32_t)fVar34);
                        fVar31 = fVar37;
                        if ((arg_50h & 2U) != 0) {
code_r0x00018012fd2e:
                            bVar22 = arg3 < (uint64_t)arg_40h;
                            if (!bVar22) goto code_r0x00018013002c;
                            if (*arg3 == '\n') {
                                arg3 = arg3 + 1;
                            }
                            goto code_r0x000180130029;
                        }
                        bVar22 = arg3 < (uint64_t)arg_40h;
                        if (bVar22) {
                            do {
                                if ((*arg3 != ' ') && (*arg3 != '\t')) goto code_r0x00018012fd2e;
                                arg3 = arg3 + 1;
                            } while (arg3 < (uint64_t)arg_40h);
                            goto code_r0x000180130029;
                        }
                    }
code_r0x00018013002c:
                    fVar37 = fVar31;
                } while (bVar22);
            }
            iVar10 = *(int32_t *)arg2;
            if (iVar18 == iVar10) {
                iVar18 = (int32_t)((int64_t)piVar20 - *(int64_t *)(arg2 + 0x18) >> 1);
                *(int32_t *)(arg2 + 0x10) = iVar18;
                *(int32_t *)(arg2 + 0x20) = (int32_t)((int64_t)pfVar19 - *(int64_t *)(arg2 + 0x28) >> 2) * -0x33333333;
                piVar1 = (int32_t *)(*(int64_t *)(arg2 + 8) + -0x20 + (int64_t)iVar10 * 0x48);
                *piVar1 = *piVar1 + (iVar18 - (iVar5 + iVar9 * 6));
                *(float **)(arg2 + 0x40) = pfVar19;
                *(int16_t **)(arg2 + 0x48) = piVar20;
                *(int32_t *)(arg2 + 0x34) = iVar21;
                return;
            }
            *(int32_t *)arg2 = iVar10 + -1;
            piVar1 = (int32_t *)(*(int64_t *)(arg2 + 8) + -0x68 + (int64_t)iVar10 * 0x48);
            *piVar1 = *piVar1 + iVar9 * -6;
            *(int32_t *)(arg2 + 0x20) = *(int32_t *)(arg2 + 0x20) + iVar9 * -4;
            *(int32_t *)(arg2 + 0x10) = *(int32_t *)(arg2 + 0x10) + iVar9 * -6;
            func_0x000180124200(arg2);
            fVar34 = *(float *)arg4;
            fVar33 = (float)(int32_t)*(float *)(arg4 + 4);
        } while (fVar33 < *(float *)(arg_30h + 0xc) || fVar33 == *(float *)(arg_30h + 0xc));
    }
    return;
}

// ============================================================
// Function: FUN_18013017c
// Address: 0x18013017c
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_128h
// WARNING: Variable defined which should be unmapped: var_120h
// WARNING: Variable defined which should be unmapped: var_118h
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable arg_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_6h
// WARNING: [rz-ghidra] Detected overlap for variable var_2h

void fcn.18012f9d0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t *piVar1;
    float fVar2;
    float fVar3;
    uint16_t uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    bool bVar7;
    int16_t iVar8;
    int32_t iVar9;
    int32_t iVar10;
    float fVar11;
    int64_t iVar12;
    char *pcVar13;
    char *arg3;
    int64_t iVar14;
    char *pcVar15;
    uint64_t uVar16;
    uint32_t *puVar17;
    int32_t iVar18;
    undefined8 placeholder_1;
    uint64_t placeholder_1_00;
    float *pfVar19;
    char *arg4_00;
    int16_t *piVar20;
    int32_t iVar21;
    bool bVar22;
    float in_XMM2_Da;
    float fVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    float fVar31;
    float fVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    undefined auVar36 [16];
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    float fVar37;
    int64_t var_108h;
    int64_t var_fch;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    fVar33 = (float)(int32_t)*(float *)(arg4 + 4);
    if (fVar33 < *(float *)(arg_30h + 0xc) || fVar33 == *(float *)(arg_30h + 0xc)) {
        fVar34 = *(float *)arg4;
        bVar7 = (float)arg_48h <= 0.0;
        do {
            fVar34 = (float)(int32_t)fVar34;
            auVar36 = ZEXT416((uint32_t)fVar34);
            pcVar15 = (char *)arg_40h;
            if ((char *)arg_40h == (char *)0x0) {
                iVar12 = func_0x000180498cd0(arg_38h);
                pcVar15 = (char *)(iVar12 + arg_38h);
            }
            iVar12 = fcn.18012ec80(arg1);
            fVar31 = *(float *)(iVar12 + 0x14);
            arg3 = (char *)arg_38h;
            if (fVar33 + in_XMM2_Da < *(float *)(arg_30h + 4)) {
                do {
                    if (pcVar15 <= arg3) break;
                    placeholder_1 = 10;
                    pcVar13 = (char *)func_0x000180498a80(arg3, 10, (int64_t)pcVar15 - (int64_t)arg3);
                    if (bVar7) {
                        arg3 = pcVar13 + 1;
                        if (pcVar13 == (char *)0x0) {
                            arg3 = pcVar15;
                        }
                    } else {
                        var_120h._0_4_ = (undefined4)arg_50h;
                        arg4_00 = pcVar15;
                        if (pcVar13 != (char *)0x0) {
                            arg4_00 = pcVar13;
                        }
                        arg3 = (char *)fcn.18012f4a0(arg1, placeholder_1, (int64_t)arg3, (int64_t)arg4_00, 
                                                     CONCAT44(var_128h._4_4_, (float)arg_48h), 
                                                     CONCAT44(var_120h._4_4_, (undefined4)arg_50h));
                        var_128h._0_4_ = (float)arg_48h;
                        if ((arg_50h & 2U) == 0) {
                            for (; arg3 < pcVar15; arg3 = arg3 + 1) {
                                if ((*arg3 != ' ') && (*arg3 != '\t')) goto code_r0x00018012fb6c;
                            }
                        } else {
code_r0x00018012fb6c:
                            if ((arg3 < pcVar15) && (*arg3 == '\n')) {
                                arg3 = arg3 + 1;
                            }
                        }
                    }
                    fVar33 = fVar33 + in_XMM2_Da;
                } while (fVar33 + in_XMM2_Da < *(float *)(arg_30h + 4));
            }
            arg_40h = (int64_t)pcVar15;
            if ((10000 < (int64_t)pcVar15 - (int64_t)arg3) && (bVar7)) {
                fVar37 = *(float *)(arg_30h + 0xc);
                arg_40h = (int64_t)arg3;
                fVar28 = fVar33;
                while ((fVar28 < fVar37 && ((uint64_t)arg_40h < pcVar15))) {
                    iVar14 = func_0x000180498a80(arg_40h, 10, (int64_t)pcVar15 - arg_40h);
                    arg_40h = (int64_t)pcVar15;
                    if (iVar14 != 0) {
                        arg_40h = (int64_t)(iVar14 + 1);
                    }
                    fVar28 = fVar28 + in_XMM2_Da;
                }
            }
            if (arg3 == (char *)arg_40h) {
                return;
            }
            iVar9 = (int32_t)arg_40h - (int32_t)arg3;
            fVar31 = in_XMM2_Da / fVar31;
            iVar5 = *(int32_t *)(arg2 + 0x10);
            placeholder_1_00 = (uint64_t)(uint32_t)(iVar9 * 6);
            fVar37 = fVar31;
            func_0x000180124680(arg2, placeholder_1_00, iVar9 * 4);
            iVar18 = *(int32_t *)arg2;
            pfVar19 = *(float **)(arg2 + 0x40);
            piVar20 = *(int16_t **)(arg2 + 0x48);
            iVar21 = *(int32_t *)(arg2 + 0x34);
            pcVar15 = (char *)0x0;
            var_118h._0_4_ = CONCAT31(var_118h._1_3_, (char)arg_50h) & 0xffffff01;
            fVar28 = (float)((uint32_t)(float)arg_28h | 0xffffff);
            if (arg3 < (uint64_t)arg_40h) {
                do {
                    fVar35 = auVar36._0_4_;
                    if (bVar7) {
code_r0x00018012fd48:
                        var_118h._4_4_ = (uint32_t)*arg3;
                        if (var_118h._4_4_ < 0x80) {
                            arg3 = arg3 + 1;
                        } else {
                            iVar10 = func_0x0001800f5c80((int64_t)&var_118h + 4, arg3, arg_40h);
                            arg3 = arg3 + iVar10;
                        }
                        placeholder_1_00 = (uint64_t)var_118h._4_4_;
                        if (var_118h._4_4_ < 0x20) {
                            if (var_118h._4_4_ == 10) {
                                fVar33 = fVar33 + in_XMM2_Da;
                                if (*(float *)(arg_30h + 0xc) <= fVar33 && fVar33 != *(float *)(arg_30h + 0xc)) break;
                                auVar36 = ZEXT416((uint32_t)fVar34);
                            } else if (var_118h._4_4_ != 0xd) goto code_r0x00018012fda2;
                        } else {
code_r0x00018012fda2:
                            if ((placeholder_1_00 & 0xffff) < (uint64_t)(int64_t)*(int32_t *)(iVar12 + 0x20)) {
                                uVar4 = *(uint16_t *)(*(int64_t *)(iVar12 + 0x28) + (placeholder_1_00 & 0xffff) * 2);
                                uVar16 = (uint64_t)uVar4;
                                if (uVar4 == 0xfffe) goto code_r0x00018012fde0;
                                if (uVar4 == 0xffff) goto code_r0x00018012fdd0;
code_r0x00018012fde8:
                                puVar17 = (uint32_t *)(uVar16 * 0x2c + *(int64_t *)(iVar12 + 0x38));
                            } else {
code_r0x00018012fdd0:
                                puVar17 = (uint32_t *)
                                          fcn.18012b6e0(CONCAT44(var_128h._4_4_, (float)var_128h), 
                                                        CONCAT44(var_120h._4_4_, (undefined4)var_120h), 
                                                        CONCAT44(var_118h._4_4_, (uint32_t)var_118h), 
                                                        CONCAT44(fVar37, fVar28), CONCAT44(iVar18, fVar34));
                                if (puVar17 == (uint32_t *)0x0) {
code_r0x00018012fde0:
                                    uVar16 = (uint64_t)*(int32_t *)(iVar12 + 0x40);
                                    goto code_r0x00018012fde8;
                                }
                            }
                            uVar6 = *puVar17;
                            fVar2 = (float)puVar17[1];
                            if ((uVar6 & 2) != 0) {
                                fVar11 = *(float *)(arg_30h + 8);
                                fVar26 = fVar31 * (float)puVar17[2] + fVar35;
                                if (fVar26 <= fVar11) {
                                    fVar3 = *(float *)arg_30h;
                                    fVar25 = fVar31 * (float)puVar17[4] + fVar35;
                                    if (fVar3 <= fVar25) {
                                        fVar23 = (float)puVar17[6];
                                        fVar29 = fVar31 * (float)puVar17[3] + fVar33;
                                        fVar24 = (float)puVar17[7];
                                        fVar32 = (float)puVar17[8];
                                        fVar27 = fVar31 * (float)puVar17[5] + fVar33;
                                        fVar30 = (float)puVar17[9];
                                        if ((char)var_118h != '\0') {
                                            if (fVar26 < fVar3) {
                                                fVar23 = (1.0 - (fVar25 - fVar3) / (fVar25 - fVar26)) *
                                                         (fVar32 - fVar23) + fVar23;
                                                fVar26 = fVar3;
                                            }
                                            fVar3 = *(float *)(arg_30h + 4);
                                            if (fVar29 < fVar3) {
                                                fVar24 = (1.0 - (fVar27 - fVar3) / (fVar27 - fVar29)) *
                                                         (fVar30 - fVar24) + fVar24;
                                                fVar29 = fVar3;
                                            }
                                            if (fVar11 < fVar25) {
                                                fVar32 = ((fVar11 - fVar26) / (fVar25 - fVar26)) * (fVar32 - fVar23) +
                                                         fVar23;
                                                fVar25 = fVar11;
                                            }
                                            fVar11 = *(float *)(arg_30h + 0xc);
                                            if (fVar11 < fVar27) {
                                                fVar30 = ((fVar11 - fVar29) / (fVar27 - fVar29)) * (fVar30 - fVar24) +
                                                         fVar24;
                                                fVar27 = fVar11;
                                            }
                                            if (fVar27 <= fVar29) goto code_r0x000180130013;
                                        }
                                        *pfVar19 = fVar26;
                                        fVar11 = (float)arg_28h;
                                        if ((uVar6 & 1) != 0) {
                                            fVar11 = fVar28;
                                        }
                                        pfVar19[4] = fVar11;
                                        pfVar19[9] = fVar11;
                                        pfVar19[0xe] = fVar11;
                                        pfVar19[0x13] = fVar11;
                                        iVar8 = (int16_t)iVar21;
                                        pfVar19[1] = fVar29;
                                        pfVar19[2] = fVar23;
                                        pfVar19[3] = fVar24;
                                        pfVar19[5] = fVar25;
                                        pfVar19[6] = fVar29;
                                        pfVar19[7] = fVar32;
                                        pfVar19[8] = fVar24;
                                        pfVar19[10] = fVar25;
                                        pfVar19[0xb] = fVar27;
                                        pfVar19[0xc] = fVar32;
                                        pfVar19[0xd] = fVar30;
                                        pfVar19[0xf] = fVar26;
                                        pfVar19[0x10] = fVar27;
                                        pfVar19[0x11] = fVar23;
                                        pfVar19[0x12] = fVar30;
                                        pfVar19 = pfVar19 + 0x14;
                                        piVar20[1] = iVar8 + 1;
                                        piVar20[2] = iVar8 + 2;
                                        piVar20[4] = iVar8 + 2;
                                        *piVar20 = iVar8;
                                        piVar20[3] = iVar8;
                                        iVar21 = iVar21 + 4;
                                        piVar20[5] = iVar8 + 3;
                                        piVar20 = piVar20 + 6;
                                    }
                                }
                            }
code_r0x000180130013:
                            auVar36._0_4_ = fVar35 + fVar31 * fVar2;
                        }
code_r0x000180130029:
                        bVar22 = arg3 < (uint64_t)arg_40h;
                        fVar31 = fVar37;
                    } else {
                        if (pcVar15 == (char *)0x0) {
                            var_128h._0_4_ = (float)arg_48h - (fVar35 - fVar34);
                            pcVar15 = (char *)fcn.18012f4a0(arg1, placeholder_1_00, (int64_t)arg3, arg_40h, 
                                                            CONCAT44(var_128h._4_4_, (float)var_128h), 
                                                            CONCAT44(var_120h._4_4_, (undefined4)arg_50h));
                            var_120h._0_4_ = (undefined4)arg_50h;
                        }
                        if (arg3 < pcVar15) goto code_r0x00018012fd48;
                        fVar33 = fVar33 + in_XMM2_Da;
                        if (*(float *)(arg_30h + 0xc) <= fVar33 && fVar33 != *(float *)(arg_30h + 0xc)) break;
                        pcVar15 = (char *)0x0;
                        auVar36 = ZEXT416((uint32_t)fVar34);
                        fVar31 = fVar37;
                        if ((arg_50h & 2U) != 0) {
code_r0x00018012fd2e:
                            bVar22 = arg3 < (uint64_t)arg_40h;
                            if (!bVar22) goto code_r0x00018013002c;
                            if (*arg3 == '\n') {
                                arg3 = arg3 + 1;
                            }
                            goto code_r0x000180130029;
                        }
                        bVar22 = arg3 < (uint64_t)arg_40h;
                        if (bVar22) {
                            do {
                                if ((*arg3 != ' ') && (*arg3 != '\t')) goto code_r0x00018012fd2e;
                                arg3 = arg3 + 1;
                            } while (arg3 < (uint64_t)arg_40h);
                            goto code_r0x000180130029;
                        }
                    }
code_r0x00018013002c:
                    fVar37 = fVar31;
                } while (bVar22);
            }
            iVar10 = *(int32_t *)arg2;
            if (iVar18 == iVar10) {
                iVar18 = (int32_t)((int64_t)piVar20 - *(int64_t *)(arg2 + 0x18) >> 1);
                *(int32_t *)(arg2 + 0x10) = iVar18;
                *(int32_t *)(arg2 + 0x20) = (int32_t)((int64_t)pfVar19 - *(int64_t *)(arg2 + 0x28) >> 2) * -0x33333333;
                piVar1 = (int32_t *)(*(int64_t *)(arg2 + 8) + -0x20 + (int64_t)iVar10 * 0x48);
                *piVar1 = *piVar1 + (iVar18 - (iVar5 + iVar9 * 6));
                *(float **)(arg2 + 0x40) = pfVar19;
                *(int16_t **)(arg2 + 0x48) = piVar20;
                *(int32_t *)(arg2 + 0x34) = iVar21;
                return;
            }
            *(int32_t *)arg2 = iVar10 + -1;
            piVar1 = (int32_t *)(*(int64_t *)(arg2 + 8) + -0x68 + (int64_t)iVar10 * 0x48);
            *piVar1 = *piVar1 + iVar9 * -6;
            *(int32_t *)(arg2 + 0x20) = *(int32_t *)(arg2 + 0x20) + iVar9 * -4;
            *(int32_t *)(arg2 + 0x10) = *(int32_t *)(arg2 + 0x10) + iVar9 * -6;
            func_0x000180124200(arg2);
            fVar34 = *(float *)arg4;
            fVar33 = (float)(int32_t)*(float *)(arg4 + 4);
        } while (fVar33 < *(float *)(arg_30h + 0xc) || fVar33 == *(float *)(arg_30h + 0xc));
    }
    return;
}

// ============================================================
// Function: FUN_1801301a0
// Address: 0x1801301a0
// Size: 451 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_48h

void fcn.1801301a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_78h)
{
    int32_t iVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    int64_t var_8h;
    int64_t var_18h;
    float var_48h;
    float var_44h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar1 = (int32_t)arg4;
    fVar2 = *(float *)(*(int64_t *)(arg1 + 0x38) + 0x20);
    fVar4 = fVar2 * 0.5;
    fVar2 = fVar2 * 0.4 * (float)arg_28h;
    fVar5 = fVar4 + (float)arg2;
    var_8h._4_4_ = (float)((uint64_t)arg2 >> 0x20);
    var_8h._4_4_ = fVar4 * (float)arg_28h + var_8h._4_4_;
    if (iVar1 == 0) {
        fVar2 = (float)((uint32_t)fVar2 ^ 0x80000000);
    } else if (iVar1 != 1) {
        if ((iVar1 == 2) || (iVar1 == 3)) {
            if (iVar1 == 2) {
                fVar2 = (float)((uint32_t)fVar2 ^ 0x80000000);
            }
            var_40h._4_4_ = fVar2 * -0.75;
            fVar3 = fVar2 * 0.75;
            var_48h = fVar2 * -0.866;
            fVar4 = fVar2 * 0.0;
            var_44h = var_40h._4_4_;
            var_40h._0_4_ = fVar2 * 0.866;
        } else {
            fVar4 = 0.0;
            var_48h = 0.0;
            var_40h._4_4_ = 0.0;
            fVar3 = 0.0;
            var_44h = 0.0;
            var_40h._0_4_ = 0.0;
        }
        goto code_r0x0001801302c0;
    }
    var_48h = fVar2 * -0.75;
    fVar4 = fVar2 * 0.75;
    var_44h = fVar2 * 0.866;
    var_40h._4_4_ = fVar2 * -0.866;
    fVar3 = fVar2 * 0.0;
    var_40h._0_4_ = var_48h;
code_r0x0001801302c0:
    var_40h._0_4_ = fVar5 + (float)var_40h;
    var_40h._4_4_ = var_8h._4_4_ + var_40h._4_4_;
    var_44h = var_8h._4_4_ + var_44h;
    var_48h = fVar5 + var_48h;
    var_8h = CONCAT44(var_8h._4_4_ + fVar3, fVar5 + fVar4);
    if ((arg3 & 0xff000000U) != 0) {
        func_0x0001800f3b50(arg1, &var_8h);
        func_0x0001800f3b50(arg1, &var_48h);
        func_0x0001800f3b50(arg1, &var_40h);
        func_0x0001800f3bc0(arg1, arg3 & 0xffffffff);
    }
    return;
}

// ============================================================
// Function: FUN_180130370
// Address: 0x180130370
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180130370(int64_t arg1, int64_t arg2, int64_t arg3)
{
    float fVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t var_28h;
    int64_t var_18h;
    
    uVar3 = 0x41b00000;
    fVar1 = *(float *)(*(int64_t *)(arg1 + 0x38) + 0x20);
    if (22.0 <= fVar1) {
        uVar3 = 0x42200000;
        uVar2 = 0;
        if (fVar1 < 40.0) {
            uVar2 = 0xc;
        }
    } else {
        uVar2 = 8;
    }
    var_18h = arg2;
    func_0x000180126840(uVar3, &var_18h, fVar1 * 0.2, arg3 & 0xffffffff, uVar2);
    return;
}

// ============================================================
// Function: FUN_1801303d0
// Address: 0x1801303d0
// Size: 505 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_80h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.1801303d0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    float in_XMM3_Da;
    float fVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_38h;
    int64_t var_18h;
    
    iVar2 = *(int32_t *)(arg1 + 0x54);
    iVar4 = 8;
    fVar8 = in_XMM3_Da / 5.0;
    if (fVar8 <= 1.0) {
        fVar8 = 1.0;
    }
    fVar5 = in_XMM3_Da - fVar8 * 0.5;
    var_8h._4_4_ = (float)((uint64_t)arg2 >> 0x20);
    fVar6 = fVar5 / 3.0;
    fVar7 = fVar8 * 0.25 + (float)arg2 + fVar6;
    fVar5 = (fVar8 * 0.25 + var_8h._4_4_ + fVar5) - fVar6 * 0.5;
    if (*(int32_t *)(arg1 + 0x50) == iVar2) {
        iVar3 = *(int32_t *)(arg1 + 0x50) + 1;
        if (iVar2 == 0) {
            iVar2 = 8;
        } else {
            iVar2 = iVar2 / 2 + iVar2;
        }
        if (iVar3 < iVar2) {
            iVar3 = iVar2;
        }
        func_0x00018011f4f0(arg1 + 0x50, iVar3);
    }
    iVar2 = *(int32_t *)(arg1 + 0x50);
    iVar1 = *(int64_t *)(arg1 + 0x58);
    *(float *)(iVar1 + (int64_t)iVar2 * 8) = fVar7 - fVar6;
    *(float *)(iVar1 + 4 + (int64_t)iVar2 * 8) = fVar5 - fVar6;
    *(int32_t *)(arg1 + 0x50) = *(int32_t *)(arg1 + 0x50) + 1;
    iVar2 = *(int32_t *)(arg1 + 0x54);
    if (*(int32_t *)(arg1 + 0x50) == iVar2) {
        iVar3 = *(int32_t *)(arg1 + 0x50) + 1;
        if (iVar2 == 0) {
            iVar2 = 8;
        } else {
            iVar2 = iVar2 / 2 + iVar2;
        }
        if (iVar3 < iVar2) {
            iVar3 = iVar2;
        }
        func_0x00018011f4f0(arg1 + 0x50, iVar3);
    }
    iVar2 = *(int32_t *)(arg1 + 0x50);
    iVar1 = *(int64_t *)(arg1 + 0x58);
    *(float *)(iVar1 + (int64_t)iVar2 * 8) = fVar7;
    *(float *)(iVar1 + 4 + (int64_t)iVar2 * 8) = fVar5;
    *(int32_t *)(arg1 + 0x50) = *(int32_t *)(arg1 + 0x50) + 1;
    iVar2 = *(int32_t *)(arg1 + 0x54);
    if (*(int32_t *)(arg1 + 0x50) == iVar2) {
        iVar3 = *(int32_t *)(arg1 + 0x50) + 1;
        if (iVar2 != 0) {
            iVar4 = iVar2 + iVar2 / 2;
        }
        if (iVar3 < iVar4) {
            iVar3 = iVar4;
        }
        func_0x00018011f4f0(arg1 + 0x50, iVar3);
    }
    iVar2 = *(int32_t *)(arg1 + 0x50);
    iVar1 = *(int64_t *)(arg1 + 0x58);
    *(float *)(iVar1 + (int64_t)iVar2 * 8) = fVar7 + fVar6 + fVar6;
    *(float *)(iVar1 + 4 + (int64_t)iVar2 * 8) = fVar5 - (fVar6 + fVar6);
    *(int32_t *)(arg1 + 0x50) = *(int32_t *)(arg1 + 0x50) + 1;
    func_0x0001801248e0(arg1, *(undefined8 *)(arg1 + 0x58), *(undefined4 *)(arg1 + 0x50), arg3 & 0xffffffff, 0, fVar8);
    *(undefined4 *)(arg1 + 0x50) = 0;
    return;
}

// ============================================================
// Function: FUN_1801305d0
// Address: 0x1801305d0
// Size: 100 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

void fcn.1801305d0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t var_8h;
    float fStack_38;
    float fStack_34;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    var_30h._0_4_ = (float)arg3 + (float)arg2;
    var_28h._4_4_ = (float)((uint64_t)arg2 >> 0x20);
    var_20h._4_4_ = (float)((uint64_t)arg3 >> 0x20);
    fStack_34 = var_28h._4_4_ - var_20h._4_4_;
    fStack_38 = (float)arg2 - (float)arg3;
    if ((arg_28h & 0xff000000U) != 0) {
        var_30h._4_4_ = fStack_34;
        var_28h = arg2;
        var_20h = arg3;
        func_0x0001800f3b50(fStack_38, &fStack_38);
        func_0x0001800f3b50(arg1, &var_30h);
        iVar1 = *(int32_t *)(arg1 + 0x54);
        if (*(int32_t *)(arg1 + 0x50) == iVar1) {
            iVar2 = *(int32_t *)(arg1 + 0x50) + 1;
            if (iVar1 == 0) {
                iVar1 = 8;
            } else {
                iVar1 = iVar1 / 2 + iVar1;
            }
            if (iVar2 < iVar1) {
                iVar2 = iVar1;
            }
            func_0x00018011f4f0(arg1 + 0x50, iVar2);
        }
        *(int64_t *)(*(int64_t *)(arg1 + 0x58) + (int64_t)*(int32_t *)(arg1 + 0x50) * 8) = arg2;
        *(int32_t *)(arg1 + 0x50) = *(int32_t *)(arg1 + 0x50) + 1;
        func_0x0001800f3bc0(arg1, arg_28h & 0xffffffff);
    }
    return;
}

// ============================================================
// Function: FUN_180130634
// Address: 0x180130634
// Size: 112 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

void fcn.1801305d0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t var_8h;
    float fStack_38;
    float fStack_34;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    var_30h._0_4_ = (float)arg3 + (float)arg2;
    var_28h._4_4_ = (float)((uint64_t)arg2 >> 0x20);
    var_20h._4_4_ = (float)((uint64_t)arg3 >> 0x20);
    fStack_34 = var_28h._4_4_ - var_20h._4_4_;
    fStack_38 = (float)arg2 - (float)arg3;
    if ((arg_28h & 0xff000000U) != 0) {
        var_30h._4_4_ = fStack_34;
        var_28h = arg2;
        var_20h = arg3;
        func_0x0001800f3b50(fStack_38, &fStack_38);
        func_0x0001800f3b50(arg1, &var_30h);
        iVar1 = *(int32_t *)(arg1 + 0x54);
        if (*(int32_t *)(arg1 + 0x50) == iVar1) {
            iVar2 = *(int32_t *)(arg1 + 0x50) + 1;
            if (iVar1 == 0) {
                iVar1 = 8;
            } else {
                iVar1 = iVar1 / 2 + iVar1;
            }
            if (iVar2 < iVar1) {
                iVar2 = iVar1;
            }
            func_0x00018011f4f0(arg1 + 0x50, iVar2);
        }
        *(int64_t *)(*(int64_t *)(arg1 + 0x58) + (int64_t)*(int32_t *)(arg1 + 0x50) * 8) = arg2;
        *(int32_t *)(arg1 + 0x50) = *(int32_t *)(arg1 + 0x50) + 1;
        func_0x0001800f3bc0(arg1, arg_28h & 0xffffffff);
    }
    return;
}

// ============================================================
// Function: FUN_1801306a4
// Address: 0x1801306a4
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

void fcn.1801305d0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t var_8h;
    float fStack_38;
    float fStack_34;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    var_30h._0_4_ = (float)arg3 + (float)arg2;
    var_28h._4_4_ = (float)((uint64_t)arg2 >> 0x20);
    var_20h._4_4_ = (float)((uint64_t)arg3 >> 0x20);
    fStack_34 = var_28h._4_4_ - var_20h._4_4_;
    fStack_38 = (float)arg2 - (float)arg3;
    if ((arg_28h & 0xff000000U) != 0) {
        var_30h._4_4_ = fStack_34;
        var_28h = arg2;
        var_20h = arg3;
        func_0x0001800f3b50(fStack_38, &fStack_38);
        func_0x0001800f3b50(arg1, &var_30h);
        iVar1 = *(int32_t *)(arg1 + 0x54);
        if (*(int32_t *)(arg1 + 0x50) == iVar1) {
            iVar2 = *(int32_t *)(arg1 + 0x50) + 1;
            if (iVar1 == 0) {
                iVar1 = 8;
            } else {
                iVar1 = iVar1 / 2 + iVar1;
            }
            if (iVar2 < iVar1) {
                iVar2 = iVar1;
            }
            func_0x00018011f4f0(arg1 + 0x50, iVar2);
        }
        *(int64_t *)(*(int64_t *)(arg1 + 0x58) + (int64_t)*(int32_t *)(arg1 + 0x50) * 8) = arg2;
        *(int32_t *)(arg1 + 0x50) = *(int32_t *)(arg1 + 0x50) + 1;
        func_0x0001800f3bc0(arg1, arg_28h & 0xffffffff);
    }
    return;
}

// ============================================================
// Function: FUN_1801306b0
// Address: 0x1801306b0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_d0h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_71h
// WARNING: [rz-ghidra] Detected overlap for variable var_75h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h

void fcn.1801306b0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    float in_XMM3_Da;
    float fVar7;
    int64_t var_8h;
    int64_t var_10h;
    float in_stack_00000028;
    float in_stack_00000030;
    int64_t var_d8h;
    int64_t var_d0h;
    float fStack_c8;
    float fStack_c4;
    float fStack_c0;
    float fStack_bc;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_79h;
    int64_t var_6dh;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if (in_XMM3_Da <= in_stack_00000028) {
        fVar1 = *(float *)(arg2 + 0xc);
        fVar2 = *(float *)(arg2 + 4);
        fStack_c8 = in_stack_00000028;
        fStack_c4 = fVar1;
        fStack_bc = fVar2;
        if (in_stack_00000030 == 0.0) {
            func_0x000180126550(arg1, &fStack_c0, &fStack_c8, arg3 & 0xffffffff, 0, 0);
        } else {
            fVar3 = *(float *)arg2;
            fVar4 = (fVar1 - fVar2) * 0.5;
            fVar6 = (*(float *)(arg2 + 8) - fVar3) * 0.5;
            if (fVar4 <= fVar6) {
                fVar6 = fVar4;
            }
            fVar6 = fVar6 - 1.0;
            if (0.0 <= fVar6) {
                if (fVar6 <= in_stack_00000030) {
                    in_stack_00000030 = fVar6;
                }
            } else {
                in_stack_00000030 = 0.0;
            }
            fVar4 = 1.0 / in_stack_00000030;
            fVar6 = 1.0 - (in_XMM3_Da - fVar3) * fVar4;
            fStack_c0 = in_XMM3_Da;
            if (0.0 < fVar6) {
                if (fVar6 < 1.0) {
                    fVar6 = (float)func_0x00018048e9f0(fVar6);
                } else {
                    fVar6 = 0.0;
                }
            } else {
                fVar6 = 1.570796;
            }
            fVar5 = 1.0 - (in_stack_00000028 - fVar3) * fVar4;
            if (0.0 < fVar5) {
                if (fVar5 < 1.0) {
                    fVar5 = (float)func_0x00018048e9f0();
                } else {
                    fVar5 = 0.0;
                }
            } else {
                fVar5 = 1.570796;
            }
            fVar7 = in_XMM3_Da;
            if (in_XMM3_Da <= fVar3 + in_stack_00000030) {
                fVar7 = fVar3 + in_stack_00000030;
            }
            if (fVar6 == fVar5) {
                fStack_c0 = fVar7;
                fStack_bc = fVar1;
                func_0x0001800f3b50(arg1, &fStack_c0);
                fStack_c0 = fVar7;
                fStack_bc = fVar2;
                func_0x0001800f3b50(arg1, &fStack_c0);
            } else if ((fVar6 == 0.0) && (fVar5 == 1.570796)) {
                fStack_c4 = fVar1 - in_stack_00000030;
                fStack_c8 = fVar7;
                if (0.5 <= in_stack_00000030) {
                    func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0xc, 0x18);
                } else {
                    func_0x00018011f490(arg1 + 0x50);
                }
                fStack_c4 = in_stack_00000030 + fVar2;
                if (0.5 <= in_stack_00000030) {
                    fStack_c8 = fVar7;
                    func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0x18, 0x24);
                } else {
                    fStack_c8 = fVar7;
                    func_0x00018011f490(arg1 + 0x50);
                }
            } else {
                fStack_bc = fVar1 - in_stack_00000030;
                fStack_c0 = fVar7;
                func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, 3.141593 - fVar5, 3.141593 - fVar6, 0);
                fStack_bc = in_stack_00000030 + fVar2;
                fStack_c0 = fVar7;
                func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, fVar6 + 3.141593, fVar5 + 3.141593, 0);
            }
            if (in_stack_00000030 + *(float *)arg2 < in_stack_00000028) {
                fVar3 = *(float *)(arg2 + 8);
                fVar6 = 1.0 - (fVar3 - in_stack_00000028) * fVar4;
                if (0.0 < fVar6) {
                    if (fVar6 < 1.0) {
                        fVar6 = (float)func_0x00018048e9f0(fVar6);
                    } else {
                        fVar6 = 0.0;
                    }
                } else {
                    fVar6 = 1.570796;
                }
                fVar4 = 1.0 - (fVar3 - in_XMM3_Da) * fVar4;
                if (0.0 < fVar4) {
                    if (fVar4 < 1.0) {
                        fVar4 = (float)func_0x00018048e9f0();
                    } else {
                        fVar4 = 0.0;
                    }
                } else {
                    fVar4 = 1.570796;
                }
                if (fVar3 - in_stack_00000030 <= in_stack_00000028) {
                    in_stack_00000028 = fVar3 - in_stack_00000030;
                }
                if (fVar6 == fVar4) {
                    fStack_c0 = in_stack_00000028;
                    fStack_bc = fVar2;
                    func_0x0001800f3b50(arg1, &fStack_c0);
                    fStack_c0 = in_stack_00000028;
                    fStack_bc = fVar1;
                    func_0x0001800f3b50(arg1, &fStack_c0);
                } else if ((fVar6 == 0.0) && (fVar4 == 1.570796)) {
                    fStack_c4 = in_stack_00000030 + fVar2;
                    fStack_c8 = in_stack_00000028;
                    if (0.5 <= in_stack_00000030) {
                        func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0x24, 0x30);
                    } else {
                        func_0x00018011f490(arg1 + 0x50);
                    }
                    fStack_c4 = fVar1 - in_stack_00000030;
                    if (0.5 <= in_stack_00000030) {
                        fStack_c8 = in_stack_00000028;
                        func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0, 0xc);
                    } else {
                        fStack_c8 = in_stack_00000028;
                        func_0x00018011f490(arg1 + 0x50);
                    }
                } else {
                    fStack_bc = in_stack_00000030 + fVar2;
                    fStack_c0 = in_stack_00000028;
                    func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, (uint32_t)fVar4 ^ 0x80000000, 
                                        (uint32_t)fVar6 ^ 0x80000000, 0);
                    fStack_bc = fVar1 - in_stack_00000030;
                    fStack_c0 = in_stack_00000028;
                    func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, fVar6, fVar4, 0);
                }
            }
            func_0x0001800f3bc0(arg1, arg3 & 0xffffffff);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801306f3
// Address: 0x1801306f3
// Size: 120 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_d0h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_71h
// WARNING: [rz-ghidra] Detected overlap for variable var_75h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h

void fcn.1801306b0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    float in_XMM3_Da;
    float fVar7;
    int64_t var_8h;
    int64_t var_10h;
    float in_stack_00000028;
    float in_stack_00000030;
    int64_t var_d8h;
    int64_t var_d0h;
    float fStack_c8;
    float fStack_c4;
    float fStack_c0;
    float fStack_bc;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_79h;
    int64_t var_6dh;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if (in_XMM3_Da <= in_stack_00000028) {
        fVar1 = *(float *)(arg2 + 0xc);
        fVar2 = *(float *)(arg2 + 4);
        fStack_c8 = in_stack_00000028;
        fStack_c4 = fVar1;
        fStack_bc = fVar2;
        if (in_stack_00000030 == 0.0) {
            func_0x000180126550(arg1, &fStack_c0, &fStack_c8, arg3 & 0xffffffff, 0, 0);
        } else {
            fVar3 = *(float *)arg2;
            fVar4 = (fVar1 - fVar2) * 0.5;
            fVar6 = (*(float *)(arg2 + 8) - fVar3) * 0.5;
            if (fVar4 <= fVar6) {
                fVar6 = fVar4;
            }
            fVar6 = fVar6 - 1.0;
            if (0.0 <= fVar6) {
                if (fVar6 <= in_stack_00000030) {
                    in_stack_00000030 = fVar6;
                }
            } else {
                in_stack_00000030 = 0.0;
            }
            fVar4 = 1.0 / in_stack_00000030;
            fVar6 = 1.0 - (in_XMM3_Da - fVar3) * fVar4;
            fStack_c0 = in_XMM3_Da;
            if (0.0 < fVar6) {
                if (fVar6 < 1.0) {
                    fVar6 = (float)func_0x00018048e9f0(fVar6);
                } else {
                    fVar6 = 0.0;
                }
            } else {
                fVar6 = 1.570796;
            }
            fVar5 = 1.0 - (in_stack_00000028 - fVar3) * fVar4;
            if (0.0 < fVar5) {
                if (fVar5 < 1.0) {
                    fVar5 = (float)func_0x00018048e9f0();
                } else {
                    fVar5 = 0.0;
                }
            } else {
                fVar5 = 1.570796;
            }
            fVar7 = in_XMM3_Da;
            if (in_XMM3_Da <= fVar3 + in_stack_00000030) {
                fVar7 = fVar3 + in_stack_00000030;
            }
            if (fVar6 == fVar5) {
                fStack_c0 = fVar7;
                fStack_bc = fVar1;
                func_0x0001800f3b50(arg1, &fStack_c0);
                fStack_c0 = fVar7;
                fStack_bc = fVar2;
                func_0x0001800f3b50(arg1, &fStack_c0);
            } else if ((fVar6 == 0.0) && (fVar5 == 1.570796)) {
                fStack_c4 = fVar1 - in_stack_00000030;
                fStack_c8 = fVar7;
                if (0.5 <= in_stack_00000030) {
                    func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0xc, 0x18);
                } else {
                    func_0x00018011f490(arg1 + 0x50);
                }
                fStack_c4 = in_stack_00000030 + fVar2;
                if (0.5 <= in_stack_00000030) {
                    fStack_c8 = fVar7;
                    func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0x18, 0x24);
                } else {
                    fStack_c8 = fVar7;
                    func_0x00018011f490(arg1 + 0x50);
                }
            } else {
                fStack_bc = fVar1 - in_stack_00000030;
                fStack_c0 = fVar7;
                func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, 3.141593 - fVar5, 3.141593 - fVar6, 0);
                fStack_bc = in_stack_00000030 + fVar2;
                fStack_c0 = fVar7;
                func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, fVar6 + 3.141593, fVar5 + 3.141593, 0);
            }
            if (in_stack_00000030 + *(float *)arg2 < in_stack_00000028) {
                fVar3 = *(float *)(arg2 + 8);
                fVar6 = 1.0 - (fVar3 - in_stack_00000028) * fVar4;
                if (0.0 < fVar6) {
                    if (fVar6 < 1.0) {
                        fVar6 = (float)func_0x00018048e9f0(fVar6);
                    } else {
                        fVar6 = 0.0;
                    }
                } else {
                    fVar6 = 1.570796;
                }
                fVar4 = 1.0 - (fVar3 - in_XMM3_Da) * fVar4;
                if (0.0 < fVar4) {
                    if (fVar4 < 1.0) {
                        fVar4 = (float)func_0x00018048e9f0();
                    } else {
                        fVar4 = 0.0;
                    }
                } else {
                    fVar4 = 1.570796;
                }
                if (fVar3 - in_stack_00000030 <= in_stack_00000028) {
                    in_stack_00000028 = fVar3 - in_stack_00000030;
                }
                if (fVar6 == fVar4) {
                    fStack_c0 = in_stack_00000028;
                    fStack_bc = fVar2;
                    func_0x0001800f3b50(arg1, &fStack_c0);
                    fStack_c0 = in_stack_00000028;
                    fStack_bc = fVar1;
                    func_0x0001800f3b50(arg1, &fStack_c0);
                } else if ((fVar6 == 0.0) && (fVar4 == 1.570796)) {
                    fStack_c4 = in_stack_00000030 + fVar2;
                    fStack_c8 = in_stack_00000028;
                    if (0.5 <= in_stack_00000030) {
                        func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0x24, 0x30);
                    } else {
                        func_0x00018011f490(arg1 + 0x50);
                    }
                    fStack_c4 = fVar1 - in_stack_00000030;
                    if (0.5 <= in_stack_00000030) {
                        fStack_c8 = in_stack_00000028;
                        func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0, 0xc);
                    } else {
                        fStack_c8 = in_stack_00000028;
                        func_0x00018011f490(arg1 + 0x50);
                    }
                } else {
                    fStack_bc = in_stack_00000030 + fVar2;
                    fStack_c0 = in_stack_00000028;
                    func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, (uint32_t)fVar4 ^ 0x80000000, 
                                        (uint32_t)fVar6 ^ 0x80000000, 0);
                    fStack_bc = fVar1 - in_stack_00000030;
                    fStack_c0 = in_stack_00000028;
                    func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, fVar6, fVar4, 0);
                }
            }
            func_0x0001800f3bc0(arg1, arg3 & 0xffffffff);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18013076b
// Address: 0x18013076b
// Size: 237 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_d0h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_71h
// WARNING: [rz-ghidra] Detected overlap for variable var_75h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h

void fcn.1801306b0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    float in_XMM3_Da;
    float fVar7;
    int64_t var_8h;
    int64_t var_10h;
    float in_stack_00000028;
    float in_stack_00000030;
    int64_t var_d8h;
    int64_t var_d0h;
    float fStack_c8;
    float fStack_c4;
    float fStack_c0;
    float fStack_bc;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_79h;
    int64_t var_6dh;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if (in_XMM3_Da <= in_stack_00000028) {
        fVar1 = *(float *)(arg2 + 0xc);
        fVar2 = *(float *)(arg2 + 4);
        fStack_c8 = in_stack_00000028;
        fStack_c4 = fVar1;
        fStack_bc = fVar2;
        if (in_stack_00000030 == 0.0) {
            func_0x000180126550(arg1, &fStack_c0, &fStack_c8, arg3 & 0xffffffff, 0, 0);
        } else {
            fVar3 = *(float *)arg2;
            fVar4 = (fVar1 - fVar2) * 0.5;
            fVar6 = (*(float *)(arg2 + 8) - fVar3) * 0.5;
            if (fVar4 <= fVar6) {
                fVar6 = fVar4;
            }
            fVar6 = fVar6 - 1.0;
            if (0.0 <= fVar6) {
                if (fVar6 <= in_stack_00000030) {
                    in_stack_00000030 = fVar6;
                }
            } else {
                in_stack_00000030 = 0.0;
            }
            fVar4 = 1.0 / in_stack_00000030;
            fVar6 = 1.0 - (in_XMM3_Da - fVar3) * fVar4;
            fStack_c0 = in_XMM3_Da;
            if (0.0 < fVar6) {
                if (fVar6 < 1.0) {
                    fVar6 = (float)func_0x00018048e9f0(fVar6);
                } else {
                    fVar6 = 0.0;
                }
            } else {
                fVar6 = 1.570796;
            }
            fVar5 = 1.0 - (in_stack_00000028 - fVar3) * fVar4;
            if (0.0 < fVar5) {
                if (fVar5 < 1.0) {
                    fVar5 = (float)func_0x00018048e9f0();
                } else {
                    fVar5 = 0.0;
                }
            } else {
                fVar5 = 1.570796;
            }
            fVar7 = in_XMM3_Da;
            if (in_XMM3_Da <= fVar3 + in_stack_00000030) {
                fVar7 = fVar3 + in_stack_00000030;
            }
            if (fVar6 == fVar5) {
                fStack_c0 = fVar7;
                fStack_bc = fVar1;
                func_0x0001800f3b50(arg1, &fStack_c0);
                fStack_c0 = fVar7;
                fStack_bc = fVar2;
                func_0x0001800f3b50(arg1, &fStack_c0);
            } else if ((fVar6 == 0.0) && (fVar5 == 1.570796)) {
                fStack_c4 = fVar1 - in_stack_00000030;
                fStack_c8 = fVar7;
                if (0.5 <= in_stack_00000030) {
                    func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0xc, 0x18);
                } else {
                    func_0x00018011f490(arg1 + 0x50);
                }
                fStack_c4 = in_stack_00000030 + fVar2;
                if (0.5 <= in_stack_00000030) {
                    fStack_c8 = fVar7;
                    func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0x18, 0x24);
                } else {
                    fStack_c8 = fVar7;
                    func_0x00018011f490(arg1 + 0x50);
                }
            } else {
                fStack_bc = fVar1 - in_stack_00000030;
                fStack_c0 = fVar7;
                func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, 3.141593 - fVar5, 3.141593 - fVar6, 0);
                fStack_bc = in_stack_00000030 + fVar2;
                fStack_c0 = fVar7;
                func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, fVar6 + 3.141593, fVar5 + 3.141593, 0);
            }
            if (in_stack_00000030 + *(float *)arg2 < in_stack_00000028) {
                fVar3 = *(float *)(arg2 + 8);
                fVar6 = 1.0 - (fVar3 - in_stack_00000028) * fVar4;
                if (0.0 < fVar6) {
                    if (fVar6 < 1.0) {
                        fVar6 = (float)func_0x00018048e9f0(fVar6);
                    } else {
                        fVar6 = 0.0;
                    }
                } else {
                    fVar6 = 1.570796;
                }
                fVar4 = 1.0 - (fVar3 - in_XMM3_Da) * fVar4;
                if (0.0 < fVar4) {
                    if (fVar4 < 1.0) {
                        fVar4 = (float)func_0x00018048e9f0();
                    } else {
                        fVar4 = 0.0;
                    }
                } else {
                    fVar4 = 1.570796;
                }
                if (fVar3 - in_stack_00000030 <= in_stack_00000028) {
                    in_stack_00000028 = fVar3 - in_stack_00000030;
                }
                if (fVar6 == fVar4) {
                    fStack_c0 = in_stack_00000028;
                    fStack_bc = fVar2;
                    func_0x0001800f3b50(arg1, &fStack_c0);
                    fStack_c0 = in_stack_00000028;
                    fStack_bc = fVar1;
                    func_0x0001800f3b50(arg1, &fStack_c0);
                } else if ((fVar6 == 0.0) && (fVar4 == 1.570796)) {
                    fStack_c4 = in_stack_00000030 + fVar2;
                    fStack_c8 = in_stack_00000028;
                    if (0.5 <= in_stack_00000030) {
                        func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0x24, 0x30);
                    } else {
                        func_0x00018011f490(arg1 + 0x50);
                    }
                    fStack_c4 = fVar1 - in_stack_00000030;
                    if (0.5 <= in_stack_00000030) {
                        fStack_c8 = in_stack_00000028;
                        func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0, 0xc);
                    } else {
                        fStack_c8 = in_stack_00000028;
                        func_0x00018011f490(arg1 + 0x50);
                    }
                } else {
                    fStack_bc = in_stack_00000030 + fVar2;
                    fStack_c0 = in_stack_00000028;
                    func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, (uint32_t)fVar4 ^ 0x80000000, 
                                        (uint32_t)fVar6 ^ 0x80000000, 0);
                    fStack_bc = fVar1 - in_stack_00000030;
                    fStack_c0 = in_stack_00000028;
                    func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, fVar6, fVar4, 0);
                }
            }
            func_0x0001800f3bc0(arg1, arg3 & 0xffffffff);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180130858
// Address: 0x180130858
// Size: 420 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_d0h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_71h
// WARNING: [rz-ghidra] Detected overlap for variable var_75h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h

void fcn.1801306b0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    float in_XMM3_Da;
    float fVar7;
    int64_t var_8h;
    int64_t var_10h;
    float in_stack_00000028;
    float in_stack_00000030;
    int64_t var_d8h;
    int64_t var_d0h;
    float fStack_c8;
    float fStack_c4;
    float fStack_c0;
    float fStack_bc;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_79h;
    int64_t var_6dh;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if (in_XMM3_Da <= in_stack_00000028) {
        fVar1 = *(float *)(arg2 + 0xc);
        fVar2 = *(float *)(arg2 + 4);
        fStack_c8 = in_stack_00000028;
        fStack_c4 = fVar1;
        fStack_bc = fVar2;
        if (in_stack_00000030 == 0.0) {
            func_0x000180126550(arg1, &fStack_c0, &fStack_c8, arg3 & 0xffffffff, 0, 0);
        } else {
            fVar3 = *(float *)arg2;
            fVar4 = (fVar1 - fVar2) * 0.5;
            fVar6 = (*(float *)(arg2 + 8) - fVar3) * 0.5;
            if (fVar4 <= fVar6) {
                fVar6 = fVar4;
            }
            fVar6 = fVar6 - 1.0;
            if (0.0 <= fVar6) {
                if (fVar6 <= in_stack_00000030) {
                    in_stack_00000030 = fVar6;
                }
            } else {
                in_stack_00000030 = 0.0;
            }
            fVar4 = 1.0 / in_stack_00000030;
            fVar6 = 1.0 - (in_XMM3_Da - fVar3) * fVar4;
            fStack_c0 = in_XMM3_Da;
            if (0.0 < fVar6) {
                if (fVar6 < 1.0) {
                    fVar6 = (float)func_0x00018048e9f0(fVar6);
                } else {
                    fVar6 = 0.0;
                }
            } else {
                fVar6 = 1.570796;
            }
            fVar5 = 1.0 - (in_stack_00000028 - fVar3) * fVar4;
            if (0.0 < fVar5) {
                if (fVar5 < 1.0) {
                    fVar5 = (float)func_0x00018048e9f0();
                } else {
                    fVar5 = 0.0;
                }
            } else {
                fVar5 = 1.570796;
            }
            fVar7 = in_XMM3_Da;
            if (in_XMM3_Da <= fVar3 + in_stack_00000030) {
                fVar7 = fVar3 + in_stack_00000030;
            }
            if (fVar6 == fVar5) {
                fStack_c0 = fVar7;
                fStack_bc = fVar1;
                func_0x0001800f3b50(arg1, &fStack_c0);
                fStack_c0 = fVar7;
                fStack_bc = fVar2;
                func_0x0001800f3b50(arg1, &fStack_c0);
            } else if ((fVar6 == 0.0) && (fVar5 == 1.570796)) {
                fStack_c4 = fVar1 - in_stack_00000030;
                fStack_c8 = fVar7;
                if (0.5 <= in_stack_00000030) {
                    func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0xc, 0x18);
                } else {
                    func_0x00018011f490(arg1 + 0x50);
                }
                fStack_c4 = in_stack_00000030 + fVar2;
                if (0.5 <= in_stack_00000030) {
                    fStack_c8 = fVar7;
                    func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0x18, 0x24);
                } else {
                    fStack_c8 = fVar7;
                    func_0x00018011f490(arg1 + 0x50);
                }
            } else {
                fStack_bc = fVar1 - in_stack_00000030;
                fStack_c0 = fVar7;
                func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, 3.141593 - fVar5, 3.141593 - fVar6, 0);
                fStack_bc = in_stack_00000030 + fVar2;
                fStack_c0 = fVar7;
                func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, fVar6 + 3.141593, fVar5 + 3.141593, 0);
            }
            if (in_stack_00000030 + *(float *)arg2 < in_stack_00000028) {
                fVar3 = *(float *)(arg2 + 8);
                fVar6 = 1.0 - (fVar3 - in_stack_00000028) * fVar4;
                if (0.0 < fVar6) {
                    if (fVar6 < 1.0) {
                        fVar6 = (float)func_0x00018048e9f0(fVar6);
                    } else {
                        fVar6 = 0.0;
                    }
                } else {
                    fVar6 = 1.570796;
                }
                fVar4 = 1.0 - (fVar3 - in_XMM3_Da) * fVar4;
                if (0.0 < fVar4) {
                    if (fVar4 < 1.0) {
                        fVar4 = (float)func_0x00018048e9f0();
                    } else {
                        fVar4 = 0.0;
                    }
                } else {
                    fVar4 = 1.570796;
                }
                if (fVar3 - in_stack_00000030 <= in_stack_00000028) {
                    in_stack_00000028 = fVar3 - in_stack_00000030;
                }
                if (fVar6 == fVar4) {
                    fStack_c0 = in_stack_00000028;
                    fStack_bc = fVar2;
                    func_0x0001800f3b50(arg1, &fStack_c0);
                    fStack_c0 = in_stack_00000028;
                    fStack_bc = fVar1;
                    func_0x0001800f3b50(arg1, &fStack_c0);
                } else if ((fVar6 == 0.0) && (fVar4 == 1.570796)) {
                    fStack_c4 = in_stack_00000030 + fVar2;
                    fStack_c8 = in_stack_00000028;
                    if (0.5 <= in_stack_00000030) {
                        func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0x24, 0x30);
                    } else {
                        func_0x00018011f490(arg1 + 0x50);
                    }
                    fStack_c4 = fVar1 - in_stack_00000030;
                    if (0.5 <= in_stack_00000030) {
                        fStack_c8 = in_stack_00000028;
                        func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0, 0xc);
                    } else {
                        fStack_c8 = in_stack_00000028;
                        func_0x00018011f490(arg1 + 0x50);
                    }
                } else {
                    fStack_bc = in_stack_00000030 + fVar2;
                    fStack_c0 = in_stack_00000028;
                    func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, (uint32_t)fVar4 ^ 0x80000000, 
                                        (uint32_t)fVar6 ^ 0x80000000, 0);
                    fStack_bc = fVar1 - in_stack_00000030;
                    fStack_c0 = in_stack_00000028;
                    func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, fVar6, fVar4, 0);
                }
            }
            func_0x0001800f3bc0(arg1, arg3 & 0xffffffff);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801309fc
// Address: 0x1801309fc
// Size: 516 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_d0h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_71h
// WARNING: [rz-ghidra] Detected overlap for variable var_75h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h

void fcn.1801306b0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    float in_XMM3_Da;
    float fVar7;
    int64_t var_8h;
    int64_t var_10h;
    float in_stack_00000028;
    float in_stack_00000030;
    int64_t var_d8h;
    int64_t var_d0h;
    float fStack_c8;
    float fStack_c4;
    float fStack_c0;
    float fStack_bc;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_79h;
    int64_t var_6dh;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if (in_XMM3_Da <= in_stack_00000028) {
        fVar1 = *(float *)(arg2 + 0xc);
        fVar2 = *(float *)(arg2 + 4);
        fStack_c8 = in_stack_00000028;
        fStack_c4 = fVar1;
        fStack_bc = fVar2;
        if (in_stack_00000030 == 0.0) {
            func_0x000180126550(arg1, &fStack_c0, &fStack_c8, arg3 & 0xffffffff, 0, 0);
        } else {
            fVar3 = *(float *)arg2;
            fVar4 = (fVar1 - fVar2) * 0.5;
            fVar6 = (*(float *)(arg2 + 8) - fVar3) * 0.5;
            if (fVar4 <= fVar6) {
                fVar6 = fVar4;
            }
            fVar6 = fVar6 - 1.0;
            if (0.0 <= fVar6) {
                if (fVar6 <= in_stack_00000030) {
                    in_stack_00000030 = fVar6;
                }
            } else {
                in_stack_00000030 = 0.0;
            }
            fVar4 = 1.0 / in_stack_00000030;
            fVar6 = 1.0 - (in_XMM3_Da - fVar3) * fVar4;
            fStack_c0 = in_XMM3_Da;
            if (0.0 < fVar6) {
                if (fVar6 < 1.0) {
                    fVar6 = (float)func_0x00018048e9f0(fVar6);
                } else {
                    fVar6 = 0.0;
                }
            } else {
                fVar6 = 1.570796;
            }
            fVar5 = 1.0 - (in_stack_00000028 - fVar3) * fVar4;
            if (0.0 < fVar5) {
                if (fVar5 < 1.0) {
                    fVar5 = (float)func_0x00018048e9f0();
                } else {
                    fVar5 = 0.0;
                }
            } else {
                fVar5 = 1.570796;
            }
            fVar7 = in_XMM3_Da;
            if (in_XMM3_Da <= fVar3 + in_stack_00000030) {
                fVar7 = fVar3 + in_stack_00000030;
            }
            if (fVar6 == fVar5) {
                fStack_c0 = fVar7;
                fStack_bc = fVar1;
                func_0x0001800f3b50(arg1, &fStack_c0);
                fStack_c0 = fVar7;
                fStack_bc = fVar2;
                func_0x0001800f3b50(arg1, &fStack_c0);
            } else if ((fVar6 == 0.0) && (fVar5 == 1.570796)) {
                fStack_c4 = fVar1 - in_stack_00000030;
                fStack_c8 = fVar7;
                if (0.5 <= in_stack_00000030) {
                    func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0xc, 0x18);
                } else {
                    func_0x00018011f490(arg1 + 0x50);
                }
                fStack_c4 = in_stack_00000030 + fVar2;
                if (0.5 <= in_stack_00000030) {
                    fStack_c8 = fVar7;
                    func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0x18, 0x24);
                } else {
                    fStack_c8 = fVar7;
                    func_0x00018011f490(arg1 + 0x50);
                }
            } else {
                fStack_bc = fVar1 - in_stack_00000030;
                fStack_c0 = fVar7;
                func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, 3.141593 - fVar5, 3.141593 - fVar6, 0);
                fStack_bc = in_stack_00000030 + fVar2;
                fStack_c0 = fVar7;
                func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, fVar6 + 3.141593, fVar5 + 3.141593, 0);
            }
            if (in_stack_00000030 + *(float *)arg2 < in_stack_00000028) {
                fVar3 = *(float *)(arg2 + 8);
                fVar6 = 1.0 - (fVar3 - in_stack_00000028) * fVar4;
                if (0.0 < fVar6) {
                    if (fVar6 < 1.0) {
                        fVar6 = (float)func_0x00018048e9f0(fVar6);
                    } else {
                        fVar6 = 0.0;
                    }
                } else {
                    fVar6 = 1.570796;
                }
                fVar4 = 1.0 - (fVar3 - in_XMM3_Da) * fVar4;
                if (0.0 < fVar4) {
                    if (fVar4 < 1.0) {
                        fVar4 = (float)func_0x00018048e9f0();
                    } else {
                        fVar4 = 0.0;
                    }
                } else {
                    fVar4 = 1.570796;
                }
                if (fVar3 - in_stack_00000030 <= in_stack_00000028) {
                    in_stack_00000028 = fVar3 - in_stack_00000030;
                }
                if (fVar6 == fVar4) {
                    fStack_c0 = in_stack_00000028;
                    fStack_bc = fVar2;
                    func_0x0001800f3b50(arg1, &fStack_c0);
                    fStack_c0 = in_stack_00000028;
                    fStack_bc = fVar1;
                    func_0x0001800f3b50(arg1, &fStack_c0);
                } else if ((fVar6 == 0.0) && (fVar4 == 1.570796)) {
                    fStack_c4 = in_stack_00000030 + fVar2;
                    fStack_c8 = in_stack_00000028;
                    if (0.5 <= in_stack_00000030) {
                        func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0x24, 0x30);
                    } else {
                        func_0x00018011f490(arg1 + 0x50);
                    }
                    fStack_c4 = fVar1 - in_stack_00000030;
                    if (0.5 <= in_stack_00000030) {
                        fStack_c8 = in_stack_00000028;
                        func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0, 0xc);
                    } else {
                        fStack_c8 = in_stack_00000028;
                        func_0x00018011f490(arg1 + 0x50);
                    }
                } else {
                    fStack_bc = in_stack_00000030 + fVar2;
                    fStack_c0 = in_stack_00000028;
                    func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, (uint32_t)fVar4 ^ 0x80000000, 
                                        (uint32_t)fVar6 ^ 0x80000000, 0);
                    fStack_bc = fVar1 - in_stack_00000030;
                    fStack_c0 = in_stack_00000028;
                    func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, fVar6, fVar4, 0);
                }
            }
            func_0x0001800f3bc0(arg1, arg3 & 0xffffffff);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180130c00
// Address: 0x180130c00
// Size: 40 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_d0h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_71h
// WARNING: [rz-ghidra] Detected overlap for variable var_75h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h

void fcn.1801306b0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    float in_XMM3_Da;
    float fVar7;
    int64_t var_8h;
    int64_t var_10h;
    float in_stack_00000028;
    float in_stack_00000030;
    int64_t var_d8h;
    int64_t var_d0h;
    float fStack_c8;
    float fStack_c4;
    float fStack_c0;
    float fStack_bc;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_79h;
    int64_t var_6dh;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if (in_XMM3_Da <= in_stack_00000028) {
        fVar1 = *(float *)(arg2 + 0xc);
        fVar2 = *(float *)(arg2 + 4);
        fStack_c8 = in_stack_00000028;
        fStack_c4 = fVar1;
        fStack_bc = fVar2;
        if (in_stack_00000030 == 0.0) {
            func_0x000180126550(arg1, &fStack_c0, &fStack_c8, arg3 & 0xffffffff, 0, 0);
        } else {
            fVar3 = *(float *)arg2;
            fVar4 = (fVar1 - fVar2) * 0.5;
            fVar6 = (*(float *)(arg2 + 8) - fVar3) * 0.5;
            if (fVar4 <= fVar6) {
                fVar6 = fVar4;
            }
            fVar6 = fVar6 - 1.0;
            if (0.0 <= fVar6) {
                if (fVar6 <= in_stack_00000030) {
                    in_stack_00000030 = fVar6;
                }
            } else {
                in_stack_00000030 = 0.0;
            }
            fVar4 = 1.0 / in_stack_00000030;
            fVar6 = 1.0 - (in_XMM3_Da - fVar3) * fVar4;
            fStack_c0 = in_XMM3_Da;
            if (0.0 < fVar6) {
                if (fVar6 < 1.0) {
                    fVar6 = (float)func_0x00018048e9f0(fVar6);
                } else {
                    fVar6 = 0.0;
                }
            } else {
                fVar6 = 1.570796;
            }
            fVar5 = 1.0 - (in_stack_00000028 - fVar3) * fVar4;
            if (0.0 < fVar5) {
                if (fVar5 < 1.0) {
                    fVar5 = (float)func_0x00018048e9f0();
                } else {
                    fVar5 = 0.0;
                }
            } else {
                fVar5 = 1.570796;
            }
            fVar7 = in_XMM3_Da;
            if (in_XMM3_Da <= fVar3 + in_stack_00000030) {
                fVar7 = fVar3 + in_stack_00000030;
            }
            if (fVar6 == fVar5) {
                fStack_c0 = fVar7;
                fStack_bc = fVar1;
                func_0x0001800f3b50(arg1, &fStack_c0);
                fStack_c0 = fVar7;
                fStack_bc = fVar2;
                func_0x0001800f3b50(arg1, &fStack_c0);
            } else if ((fVar6 == 0.0) && (fVar5 == 1.570796)) {
                fStack_c4 = fVar1 - in_stack_00000030;
                fStack_c8 = fVar7;
                if (0.5 <= in_stack_00000030) {
                    func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0xc, 0x18);
                } else {
                    func_0x00018011f490(arg1 + 0x50);
                }
                fStack_c4 = in_stack_00000030 + fVar2;
                if (0.5 <= in_stack_00000030) {
                    fStack_c8 = fVar7;
                    func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0x18, 0x24);
                } else {
                    fStack_c8 = fVar7;
                    func_0x00018011f490(arg1 + 0x50);
                }
            } else {
                fStack_bc = fVar1 - in_stack_00000030;
                fStack_c0 = fVar7;
                func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, 3.141593 - fVar5, 3.141593 - fVar6, 0);
                fStack_bc = in_stack_00000030 + fVar2;
                fStack_c0 = fVar7;
                func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, fVar6 + 3.141593, fVar5 + 3.141593, 0);
            }
            if (in_stack_00000030 + *(float *)arg2 < in_stack_00000028) {
                fVar3 = *(float *)(arg2 + 8);
                fVar6 = 1.0 - (fVar3 - in_stack_00000028) * fVar4;
                if (0.0 < fVar6) {
                    if (fVar6 < 1.0) {
                        fVar6 = (float)func_0x00018048e9f0(fVar6);
                    } else {
                        fVar6 = 0.0;
                    }
                } else {
                    fVar6 = 1.570796;
                }
                fVar4 = 1.0 - (fVar3 - in_XMM3_Da) * fVar4;
                if (0.0 < fVar4) {
                    if (fVar4 < 1.0) {
                        fVar4 = (float)func_0x00018048e9f0();
                    } else {
                        fVar4 = 0.0;
                    }
                } else {
                    fVar4 = 1.570796;
                }
                if (fVar3 - in_stack_00000030 <= in_stack_00000028) {
                    in_stack_00000028 = fVar3 - in_stack_00000030;
                }
                if (fVar6 == fVar4) {
                    fStack_c0 = in_stack_00000028;
                    fStack_bc = fVar2;
                    func_0x0001800f3b50(arg1, &fStack_c0);
                    fStack_c0 = in_stack_00000028;
                    fStack_bc = fVar1;
                    func_0x0001800f3b50(arg1, &fStack_c0);
                } else if ((fVar6 == 0.0) && (fVar4 == 1.570796)) {
                    fStack_c4 = in_stack_00000030 + fVar2;
                    fStack_c8 = in_stack_00000028;
                    if (0.5 <= in_stack_00000030) {
                        func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0x24, 0x30);
                    } else {
                        func_0x00018011f490(arg1 + 0x50);
                    }
                    fStack_c4 = fVar1 - in_stack_00000030;
                    if (0.5 <= in_stack_00000030) {
                        fStack_c8 = in_stack_00000028;
                        func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0, 0xc);
                    } else {
                        fStack_c8 = in_stack_00000028;
                        func_0x00018011f490(arg1 + 0x50);
                    }
                } else {
                    fStack_bc = in_stack_00000030 + fVar2;
                    fStack_c0 = in_stack_00000028;
                    func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, (uint32_t)fVar4 ^ 0x80000000, 
                                        (uint32_t)fVar6 ^ 0x80000000, 0);
                    fStack_bc = fVar1 - in_stack_00000030;
                    fStack_c0 = in_stack_00000028;
                    func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, fVar6, fVar4, 0);
                }
            }
            func_0x0001800f3bc0(arg1, arg3 & 0xffffffff);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180130c28
// Address: 0x180130c28
// Size: 30 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_d0h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_71h
// WARNING: [rz-ghidra] Detected overlap for variable var_75h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h

void fcn.1801306b0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    float in_XMM3_Da;
    float fVar7;
    int64_t var_8h;
    int64_t var_10h;
    float in_stack_00000028;
    float in_stack_00000030;
    int64_t var_d8h;
    int64_t var_d0h;
    float fStack_c8;
    float fStack_c4;
    float fStack_c0;
    float fStack_bc;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_79h;
    int64_t var_6dh;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if (in_XMM3_Da <= in_stack_00000028) {
        fVar1 = *(float *)(arg2 + 0xc);
        fVar2 = *(float *)(arg2 + 4);
        fStack_c8 = in_stack_00000028;
        fStack_c4 = fVar1;
        fStack_bc = fVar2;
        if (in_stack_00000030 == 0.0) {
            func_0x000180126550(arg1, &fStack_c0, &fStack_c8, arg3 & 0xffffffff, 0, 0);
        } else {
            fVar3 = *(float *)arg2;
            fVar4 = (fVar1 - fVar2) * 0.5;
            fVar6 = (*(float *)(arg2 + 8) - fVar3) * 0.5;
            if (fVar4 <= fVar6) {
                fVar6 = fVar4;
            }
            fVar6 = fVar6 - 1.0;
            if (0.0 <= fVar6) {
                if (fVar6 <= in_stack_00000030) {
                    in_stack_00000030 = fVar6;
                }
            } else {
                in_stack_00000030 = 0.0;
            }
            fVar4 = 1.0 / in_stack_00000030;
            fVar6 = 1.0 - (in_XMM3_Da - fVar3) * fVar4;
            fStack_c0 = in_XMM3_Da;
            if (0.0 < fVar6) {
                if (fVar6 < 1.0) {
                    fVar6 = (float)func_0x00018048e9f0(fVar6);
                } else {
                    fVar6 = 0.0;
                }
            } else {
                fVar6 = 1.570796;
            }
            fVar5 = 1.0 - (in_stack_00000028 - fVar3) * fVar4;
            if (0.0 < fVar5) {
                if (fVar5 < 1.0) {
                    fVar5 = (float)func_0x00018048e9f0();
                } else {
                    fVar5 = 0.0;
                }
            } else {
                fVar5 = 1.570796;
            }
            fVar7 = in_XMM3_Da;
            if (in_XMM3_Da <= fVar3 + in_stack_00000030) {
                fVar7 = fVar3 + in_stack_00000030;
            }
            if (fVar6 == fVar5) {
                fStack_c0 = fVar7;
                fStack_bc = fVar1;
                func_0x0001800f3b50(arg1, &fStack_c0);
                fStack_c0 = fVar7;
                fStack_bc = fVar2;
                func_0x0001800f3b50(arg1, &fStack_c0);
            } else if ((fVar6 == 0.0) && (fVar5 == 1.570796)) {
                fStack_c4 = fVar1 - in_stack_00000030;
                fStack_c8 = fVar7;
                if (0.5 <= in_stack_00000030) {
                    func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0xc, 0x18);
                } else {
                    func_0x00018011f490(arg1 + 0x50);
                }
                fStack_c4 = in_stack_00000030 + fVar2;
                if (0.5 <= in_stack_00000030) {
                    fStack_c8 = fVar7;
                    func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0x18, 0x24);
                } else {
                    fStack_c8 = fVar7;
                    func_0x00018011f490(arg1 + 0x50);
                }
            } else {
                fStack_bc = fVar1 - in_stack_00000030;
                fStack_c0 = fVar7;
                func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, 3.141593 - fVar5, 3.141593 - fVar6, 0);
                fStack_bc = in_stack_00000030 + fVar2;
                fStack_c0 = fVar7;
                func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, fVar6 + 3.141593, fVar5 + 3.141593, 0);
            }
            if (in_stack_00000030 + *(float *)arg2 < in_stack_00000028) {
                fVar3 = *(float *)(arg2 + 8);
                fVar6 = 1.0 - (fVar3 - in_stack_00000028) * fVar4;
                if (0.0 < fVar6) {
                    if (fVar6 < 1.0) {
                        fVar6 = (float)func_0x00018048e9f0(fVar6);
                    } else {
                        fVar6 = 0.0;
                    }
                } else {
                    fVar6 = 1.570796;
                }
                fVar4 = 1.0 - (fVar3 - in_XMM3_Da) * fVar4;
                if (0.0 < fVar4) {
                    if (fVar4 < 1.0) {
                        fVar4 = (float)func_0x00018048e9f0();
                    } else {
                        fVar4 = 0.0;
                    }
                } else {
                    fVar4 = 1.570796;
                }
                if (fVar3 - in_stack_00000030 <= in_stack_00000028) {
                    in_stack_00000028 = fVar3 - in_stack_00000030;
                }
                if (fVar6 == fVar4) {
                    fStack_c0 = in_stack_00000028;
                    fStack_bc = fVar2;
                    func_0x0001800f3b50(arg1, &fStack_c0);
                    fStack_c0 = in_stack_00000028;
                    fStack_bc = fVar1;
                    func_0x0001800f3b50(arg1, &fStack_c0);
                } else if ((fVar6 == 0.0) && (fVar4 == 1.570796)) {
                    fStack_c4 = in_stack_00000030 + fVar2;
                    fStack_c8 = in_stack_00000028;
                    if (0.5 <= in_stack_00000030) {
                        func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0x24, 0x30);
                    } else {
                        func_0x00018011f490(arg1 + 0x50);
                    }
                    fStack_c4 = fVar1 - in_stack_00000030;
                    if (0.5 <= in_stack_00000030) {
                        fStack_c8 = in_stack_00000028;
                        func_0x0001801257a0(arg1, &fStack_c8, in_stack_00000030, 0, 0xc);
                    } else {
                        fStack_c8 = in_stack_00000028;
                        func_0x00018011f490(arg1 + 0x50);
                    }
                } else {
                    fStack_bc = in_stack_00000030 + fVar2;
                    fStack_c0 = in_stack_00000028;
                    func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, (uint32_t)fVar4 ^ 0x80000000, 
                                        (uint32_t)fVar6 ^ 0x80000000, 0);
                    fStack_bc = fVar1 - in_stack_00000030;
                    fStack_c0 = in_stack_00000028;
                    func_0x000180125bc0(arg1, &fStack_c0, in_stack_00000030, fVar6, fVar4, 0);
                }
            }
            func_0x0001800f3bc0(arg1, arg3 & 0xffffffff);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180130c50
// Address: 0x180130c50
// Size: 855 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_70h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h

void fcn.180130c50(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    float fVar1;
    float fVar2;
    float fVar3;
    bool bVar4;
    bool bVar5;
    bool bVar6;
    char cVar7;
    char cVar8;
    uint64_t uVar9;
    uint32_t uVar10;
    uint32_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    float var_60h;
    int64_t var_5ch;
    int64_t var_48h;
    
    fVar1 = *(float *)arg2;
    fVar2 = *(float *)arg3;
    fVar3 = *(float *)(arg3 + 4);
    uVar9 = arg4 & 0xffffffff;
    bVar5 = *(float *)(arg2 + 8) != *(float *)(arg3 + 8);
    bVar6 = *(float *)(arg3 + 8) <= *(float *)(arg2 + 8);
    var_10h._0_4_ = CONCAT31(var_10h._1_3_, fVar1 < fVar2);
    bVar4 = *(float *)(arg2 + 4) <= fVar3 && fVar3 != *(float *)(arg2 + 4);
    var_18h._0_4_ = CONCAT31(var_18h._1_3_, bVar4);
    var_68h._0_1_ = *(float *)(arg3 + 0xc) < *(float *)(arg2 + 0xc);
    uVar10 = bVar4 ^ 1;
    uVar11 = (uint32_t)(uint8_t)(char)var_68h;
    if (fVar1 < fVar2) {
        var_68h._4_4_ = fVar2;
        var_60h = *(float *)(arg3 + 0xc);
        var_5ch._0_4_ = fVar1;
        var_5ch._4_4_ = fVar3;
        func_0x000180126550(arg1, &var_5ch, (int64_t)&var_68h + 4, fVar3, (undefined4)arg_28h, 
                            (uVar11 ^ 1) << 6 | uVar10 << 4 | 0x100);
    }
    if (bVar6 && bVar5) {
        var_5ch._0_4_ = *(float *)(arg2 + 8);
        var_5ch._4_4_ = *(float *)(arg3 + 0xc);
        var_68h._4_4_ = *(float *)(arg3 + 8);
        var_60h = *(float *)(arg3 + 4);
        func_0x000180126550(arg1, (int64_t)&var_68h + 4, &var_5ch, uVar9, (undefined4)arg_28h, 
                            uVar10 << 5 | (uVar11 ^ 1) << 7 | 0x100);
    }
    cVar7 = (char)var_18h;
    if ((char)var_18h != '\0') {
        var_18h._0_4_ = *(undefined4 *)(arg3 + 8);
        var_18h._4_4_ = *(undefined4 *)(arg3 + 4);
        var_5ch._0_4_ = *(float *)arg3;
        var_5ch._4_4_ = *(float *)(arg2 + 4);
        func_0x000180126550(arg1, &var_5ch, &var_18h, uVar9, (undefined4)arg_28h, 
                            ((bVar6 && bVar5) ^ 1) << 5 | ((uint32_t)var_10h & 0xff ^ 1) << 4 | 0x100);
    }
    cVar8 = (char)var_68h;
    if ((char)var_68h != '\0') {
        var_18h._0_4_ = *(undefined4 *)(arg3 + 8);
        var_18h._4_4_ = *(undefined4 *)(arg2 + 0xc);
        var_5ch._0_4_ = *(float *)arg3;
        var_5ch._4_4_ = *(float *)(arg3 + 0xc);
        func_0x000180126550(arg1, &var_5ch, &var_18h, uVar9, (undefined4)arg_28h, 
                            ((bVar6 && bVar5) ^ 1) << 7 | ((uint32_t)var_10h & 0xff ^ 1) << 6 | 0x100);
    }
    if (((char)var_10h != '\0') && (cVar7 != '\0')) {
        var_18h._0_4_ = *(undefined4 *)arg3;
        var_18h._4_4_ = *(undefined4 *)(arg3 + 4);
        var_5ch._0_4_ = *(float *)arg2;
        var_5ch._4_4_ = *(float *)(arg2 + 4);
        func_0x000180126550(arg1, &var_5ch, &var_18h, uVar9, (undefined4)arg_28h, 0x10);
    }
    if ((bVar6 && bVar5) && (cVar7 != '\0')) {
        var_18h._0_4_ = *(undefined4 *)(arg2 + 8);
        var_18h._4_4_ = *(undefined4 *)(arg3 + 4);
        var_5ch._0_4_ = *(float *)(arg3 + 8);
        var_5ch._4_4_ = *(float *)(arg2 + 4);
        func_0x000180126550(arg1, &var_5ch, &var_18h, uVar9, (undefined4)arg_28h, 0x20);
    }
    if (((char)var_10h != '\0') && (cVar8 != '\0')) {
        var_10h._0_4_ = *(uint32_t *)arg3;
        var_10h._4_4_ = *(undefined4 *)(arg2 + 0xc);
        var_18h._0_4_ = *(undefined4 *)arg2;
        var_18h._4_4_ = *(undefined4 *)(arg3 + 0xc);
        func_0x000180126550(arg1, &var_18h, &var_10h, uVar9, (undefined4)arg_28h, 0x40);
    }
    if ((bVar6 && bVar5) && (cVar8 != '\0')) {
        var_10h._0_4_ = *(undefined4 *)(arg2 + 8);
        var_10h._4_4_ = *(undefined4 *)(arg2 + 0xc);
        var_18h._0_4_ = *(undefined4 *)(arg3 + 8);
        var_18h._4_4_ = *(undefined4 *)(arg3 + 0xc);
        func_0x000180126550(arg1, &var_18h, &var_10h, uVar9, (undefined4)arg_28h, 0x80);
    }
    return;
}

// ============================================================
// Function: FUN_1801310b0
// Address: 0x1801310b0
// Size: 81 bytes
// ============================================================
void fcn.1801310b0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    
    uVar1 = (arg2 & 0xffffffffU) + *(int64_t *)0x1807823c0;
    if (uVar1 <= *(uint64_t *)0x180782390) {
        if ((uint64_t)arg1 < *(uint64_t *)0x180782380) {
            *(int64_t *)0x1807823c0 = *(uint64_t *)0x180782390 + 1;
            return;
        }
        fcn.180498030(*(int64_t *)0x1807823c0, arg1);
    }
    *(uint64_t *)0x1807823c0 = uVar1;
    return;
}

// ============================================================
// Function: FUN_180131110
// Address: 0x180131110
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180131110(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar4 = (int32_t)arg2;
    iVar1 = *(int32_t *)(arg1 + 4);
    if (iVar4 <= iVar1) {
        *(int32_t *)arg1 = iVar4;
        return;
    }
    if (iVar1 == 0) {
        iVar2 = 8;
    } else {
        iVar2 = iVar1 / 2 + iVar1;
    }
    iVar5 = iVar4;
    if (iVar4 < iVar2) {
        iVar5 = iVar2;
    }
    if (iVar1 < iVar5) {
        uVar3 = func_0x00018046d050((int64_t)iVar5 << 2);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar3, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 << 2);
            func_0x000180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar3;
        *(int32_t *)(arg1 + 4) = iVar5;
        *(int32_t *)arg1 = iVar4;
        return;
    }
    *(int32_t *)arg1 = iVar4;
    return;
}

// ============================================================
// Function: FUN_18013112a
// Address: 0x18013112a
// Size: 119 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180131110(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar4 = (int32_t)arg2;
    iVar1 = *(int32_t *)(arg1 + 4);
    if (iVar4 <= iVar1) {
        *(int32_t *)arg1 = iVar4;
        return;
    }
    if (iVar1 == 0) {
        iVar2 = 8;
    } else {
        iVar2 = iVar1 / 2 + iVar1;
    }
    iVar5 = iVar4;
    if (iVar4 < iVar2) {
        iVar5 = iVar2;
    }
    if (iVar1 < iVar5) {
        uVar3 = func_0x00018046d050((int64_t)iVar5 << 2);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar3, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 << 2);
            func_0x000180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar3;
        *(int32_t *)(arg1 + 4) = iVar5;
        *(int32_t *)arg1 = iVar4;
        return;
    }
    *(int32_t *)arg1 = iVar4;
    return;
}

// ============================================================
// Function: FUN_1801311a1
// Address: 0x1801311a1
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180131110(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar4 = (int32_t)arg2;
    iVar1 = *(int32_t *)(arg1 + 4);
    if (iVar4 <= iVar1) {
        *(int32_t *)arg1 = iVar4;
        return;
    }
    if (iVar1 == 0) {
        iVar2 = 8;
    } else {
        iVar2 = iVar1 / 2 + iVar1;
    }
    iVar5 = iVar4;
    if (iVar4 < iVar2) {
        iVar5 = iVar2;
    }
    if (iVar1 < iVar5) {
        uVar3 = func_0x00018046d050((int64_t)iVar5 << 2);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar3, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 << 2);
            func_0x000180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar3;
        *(int32_t *)(arg1 + 4) = iVar5;
        *(int32_t *)arg1 = iVar4;
        return;
    }
    *(int32_t *)arg1 = iVar4;
    return;
}

// ============================================================
// Function: FUN_1801311b3
// Address: 0x1801311b3
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180131110(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar4 = (int32_t)arg2;
    iVar1 = *(int32_t *)(arg1 + 4);
    if (iVar4 <= iVar1) {
        *(int32_t *)arg1 = iVar4;
        return;
    }
    if (iVar1 == 0) {
        iVar2 = 8;
    } else {
        iVar2 = iVar1 / 2 + iVar1;
    }
    iVar5 = iVar4;
    if (iVar4 < iVar2) {
        iVar5 = iVar2;
    }
    if (iVar1 < iVar5) {
        uVar3 = func_0x00018046d050((int64_t)iVar5 << 2);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar3, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 << 2);
            func_0x000180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar3;
        *(int32_t *)(arg1 + 4) = iVar5;
        *(int32_t *)arg1 = iVar4;
        return;
    }
    *(int32_t *)arg1 = iVar4;
    return;
}

// ============================================================
// Function: FUN_1801311c0
// Address: 0x1801311c0
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801311c0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 *puVar1;
    undefined4 uVar2;
    uint32_t uVar3;
    int32_t iVar4;
    uint32_t uVar5;
    uint64_t uVar6;
    int32_t iVar7;
    undefined4 *puVar8;
    int64_t iVar9;
    uint32_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar4 = *(int32_t *)(arg1 + 4);
    iVar7 = (int32_t)arg2;
    if (iVar4 < iVar7) {
        if (iVar4 == 0) {
            uVar3 = 8;
        } else {
            uVar3 = iVar4 / 2 + iVar4;
        }
        uVar6 = arg2 & 0xffffffff;
        if (iVar7 < (int32_t)uVar3) {
            uVar6 = (uint64_t)uVar3;
        }
        func_0x00018011fb10(arg1, uVar6);
    }
    uVar3 = *(uint32_t *)arg1;
    uVar6 = (uint64_t)(int32_t)uVar3;
    if ((int32_t)uVar3 < iVar7) {
        if (iVar7 - uVar3 < 4) goto code_r0x0001801312b0;
        puVar8 = (undefined4 *)(*(int64_t *)(arg1 + 8) + uVar6 * 4);
        puVar1 = (undefined4 *)(*(int64_t *)(arg1 + 8) + (int64_t)(iVar7 + -1) * 4);
        if ((puVar8 <= (undefined4 *)(arg1 + 8U)) && ((undefined4 *)(arg1 + 8U) <= puVar1)) goto code_r0x0001801312b0;
        if ((puVar8 <= (uint64_t)arg3) && ((uint64_t)arg3 <= puVar1)) goto code_r0x0001801312b0;
        uVar2 = *(undefined4 *)arg3;
        uVar10 = iVar7 - uVar3 & 0x80000003;
        if ((int32_t)uVar10 < 0) {
            uVar10 = (uVar10 - 1 | 0xfffffffc) + 1;
        }
        do {
            uVar5 = (int32_t)uVar6 + 4;
            uVar6 = (uint64_t)uVar5;
        } while ((int32_t)uVar5 < (int32_t)(iVar7 - uVar10));
        iVar4 = ((iVar7 - uVar10) - uVar3) + 3;
        for (uVar6 = (uint64_t)((int64_t)((int32_t)(iVar4 + (iVar4 >> 0x1f & 3U)) >> 2) << 4) >> 2; uVar6 != 0;
            uVar6 = uVar6 - 1) {
            *puVar8 = uVar2;
            puVar8 = puVar8 + 1;
        }
        iVar4 = uVar5 - iVar7;
        uVar3 = uVar5;
        while (SBORROW4(uVar3, iVar7) != iVar4 < 0) {
code_r0x0001801312b0:
            iVar9 = (int64_t)(int32_t)uVar3;
            uVar3 = uVar3 + 1;
            *(undefined4 *)(*(int64_t *)(arg1 + 8) + iVar9 * 4) = *(undefined4 *)arg3;
            iVar4 = uVar3 - iVar7;
        }
    }
    *(int32_t *)arg1 = iVar7;
    return;
}

// ============================================================
// Function: FUN_180131210
// Address: 0x180131210
// Size: 184 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801311c0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 *puVar1;
    undefined4 uVar2;
    uint32_t uVar3;
    int32_t iVar4;
    uint32_t uVar5;
    uint64_t uVar6;
    int32_t iVar7;
    undefined4 *puVar8;
    int64_t iVar9;
    uint32_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar4 = *(int32_t *)(arg1 + 4);
    iVar7 = (int32_t)arg2;
    if (iVar4 < iVar7) {
        if (iVar4 == 0) {
            uVar3 = 8;
        } else {
            uVar3 = iVar4 / 2 + iVar4;
        }
        uVar6 = arg2 & 0xffffffff;
        if (iVar7 < (int32_t)uVar3) {
            uVar6 = (uint64_t)uVar3;
        }
        func_0x00018011fb10(arg1, uVar6);
    }
    uVar3 = *(uint32_t *)arg1;
    uVar6 = (uint64_t)(int32_t)uVar3;
    if ((int32_t)uVar3 < iVar7) {
        if (iVar7 - uVar3 < 4) goto code_r0x0001801312b0;
        puVar8 = (undefined4 *)(*(int64_t *)(arg1 + 8) + uVar6 * 4);
        puVar1 = (undefined4 *)(*(int64_t *)(arg1 + 8) + (int64_t)(iVar7 + -1) * 4);
        if ((puVar8 <= (undefined4 *)(arg1 + 8U)) && ((undefined4 *)(arg1 + 8U) <= puVar1)) goto code_r0x0001801312b0;
        if ((puVar8 <= (uint64_t)arg3) && ((uint64_t)arg3 <= puVar1)) goto code_r0x0001801312b0;
        uVar2 = *(undefined4 *)arg3;
        uVar10 = iVar7 - uVar3 & 0x80000003;
        if ((int32_t)uVar10 < 0) {
            uVar10 = (uVar10 - 1 | 0xfffffffc) + 1;
        }
        do {
            uVar5 = (int32_t)uVar6 + 4;
            uVar6 = (uint64_t)uVar5;
        } while ((int32_t)uVar5 < (int32_t)(iVar7 - uVar10));
        iVar4 = ((iVar7 - uVar10) - uVar3) + 3;
        for (uVar6 = (uint64_t)((int64_t)((int32_t)(iVar4 + (iVar4 >> 0x1f & 3U)) >> 2) << 4) >> 2; uVar6 != 0;
            uVar6 = uVar6 - 1) {
            *puVar8 = uVar2;
            puVar8 = puVar8 + 1;
        }
        iVar4 = uVar5 - iVar7;
        uVar3 = uVar5;
        while (SBORROW4(uVar3, iVar7) != iVar4 < 0) {
code_r0x0001801312b0:
            iVar9 = (int64_t)(int32_t)uVar3;
            uVar3 = uVar3 + 1;
            *(undefined4 *)(*(int64_t *)(arg1 + 8) + iVar9 * 4) = *(undefined4 *)arg3;
            iVar4 = uVar3 - iVar7;
        }
    }
    *(int32_t *)arg1 = iVar7;
    return;
}

// ============================================================
// Function: FUN_1801312c8
// Address: 0x1801312c8
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801311c0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 *puVar1;
    undefined4 uVar2;
    uint32_t uVar3;
    int32_t iVar4;
    uint32_t uVar5;
    uint64_t uVar6;
    int32_t iVar7;
    undefined4 *puVar8;
    int64_t iVar9;
    uint32_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar4 = *(int32_t *)(arg1 + 4);
    iVar7 = (int32_t)arg2;
    if (iVar4 < iVar7) {
        if (iVar4 == 0) {
            uVar3 = 8;
        } else {
            uVar3 = iVar4 / 2 + iVar4;
        }
        uVar6 = arg2 & 0xffffffff;
        if (iVar7 < (int32_t)uVar3) {
            uVar6 = (uint64_t)uVar3;
        }
        func_0x00018011fb10(arg1, uVar6);
    }
    uVar3 = *(uint32_t *)arg1;
    uVar6 = (uint64_t)(int32_t)uVar3;
    if ((int32_t)uVar3 < iVar7) {
        if (iVar7 - uVar3 < 4) goto code_r0x0001801312b0;
        puVar8 = (undefined4 *)(*(int64_t *)(arg1 + 8) + uVar6 * 4);
        puVar1 = (undefined4 *)(*(int64_t *)(arg1 + 8) + (int64_t)(iVar7 + -1) * 4);
        if ((puVar8 <= (undefined4 *)(arg1 + 8U)) && ((undefined4 *)(arg1 + 8U) <= puVar1)) goto code_r0x0001801312b0;
        if ((puVar8 <= (uint64_t)arg3) && ((uint64_t)arg3 <= puVar1)) goto code_r0x0001801312b0;
        uVar2 = *(undefined4 *)arg3;
        uVar10 = iVar7 - uVar3 & 0x80000003;
        if ((int32_t)uVar10 < 0) {
            uVar10 = (uVar10 - 1 | 0xfffffffc) + 1;
        }
        do {
            uVar5 = (int32_t)uVar6 + 4;
            uVar6 = (uint64_t)uVar5;
        } while ((int32_t)uVar5 < (int32_t)(iVar7 - uVar10));
        iVar4 = ((iVar7 - uVar10) - uVar3) + 3;
        for (uVar6 = (uint64_t)((int64_t)((int32_t)(iVar4 + (iVar4 >> 0x1f & 3U)) >> 2) << 4) >> 2; uVar6 != 0;
            uVar6 = uVar6 - 1) {
            *puVar8 = uVar2;
            puVar8 = puVar8 + 1;
        }
        iVar4 = uVar5 - iVar7;
        uVar3 = uVar5;
        while (SBORROW4(uVar3, iVar7) != iVar4 < 0) {
code_r0x0001801312b0:
            iVar9 = (int64_t)(int32_t)uVar3;
            uVar3 = uVar3 + 1;
            *(undefined4 *)(*(int64_t *)(arg1 + 8) + iVar9 * 4) = *(undefined4 *)arg3;
            iVar4 = uVar3 - iVar7;
        }
    }
    *(int32_t *)arg1 = iVar7;
    return;
}

// ============================================================
// Function: FUN_1801312e0
// Address: 0x1801312e0
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801312e0(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180460d90();
        }
        uVar1 = fcn.18046d050((int64_t)iVar2 << 3);
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_180131330
// Address: 0x180131330
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180131330(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 << 5);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 << 5);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_180131348
// Address: 0x180131348
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180131330(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 << 5);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 << 5);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_180131386
// Address: 0x180131386
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180131330(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 << 5);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 << 5);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_1801313a0
// Address: 0x1801313a0
// Size: 56 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.1801313a0(int64_t arg1, int64_t arg2, int64_t arg_48h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (*(int64_t *)(arg1 + 8) != 0) {
        *(undefined8 *)arg1 = 0;
        fcn.180460d90();
        *(undefined8 *)(arg1 + 8) = 0;
    }
    iVar1 = *(int32_t *)arg2;
    iVar2 = *(int32_t *)(arg1 + 4);
    if (iVar1 <= iVar2) {
        *(int32_t *)arg1 = iVar1;
        return arg1;
    }
    if (iVar2 == 0) {
        iVar3 = 8;
    } else {
        iVar3 = iVar2 / 2 + iVar2;
    }
    iVar5 = iVar1;
    if (iVar1 < iVar3) {
        iVar5 = iVar3;
    }
    if (iVar2 < iVar5) {
        iVar4 = fcn.18046d050((int64_t)iVar5 * 2);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(iVar4, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 2);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(int64_t *)(arg1 + 8) = iVar4;
        *(int32_t *)(arg1 + 4) = iVar5;
        *(int32_t *)arg1 = iVar1;
        if ((iVar4 != 0) && (*(int64_t *)(arg2 + 8) != 0)) {
            fcn.180498030(iVar4, *(int64_t *)(arg2 + 8), (int64_t)iVar1 * 2);
        }
    } else {
        *(int32_t *)arg1 = iVar1;
    }
    return arg1;
}

