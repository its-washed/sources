// Chunk 84 - 50 functions

// ============================================================
// Function: FUN_18011c780
// Address: 0x18011c780
// Size: 217 bytes
// ============================================================
void fcn.18011c780(int64_t arg1, int64_t arg_a0h)
{
    undefined8 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    undefined4 *puVar5;
    undefined4 *puVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    int64_t iVar11;
    undefined8 *puVar12;
    uint32_t uVar13;
    undefined8 uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_68h;
    int64_t var_58h;
    
    iVar7 = *(int64_t *)0x180781f28;
    iVar8 = func_0x0001800f60f0(*(int64_t *)0x180781f28 + 0x28e8, arg1 & 0xffffffff);
    if (iVar8 != 0) {
        func_0x00018011cca0(arg1 & 0xffffffffU, 1);
        func_0x00018011c860(arg1 & 0xffffffff);
        iVar8 = func_0x0001800f60f0(iVar7 + 0x28e8, arg1 & 0xffffffffU);
        if (iVar8 != 0) {
            if (((*(uint32_t *)(iVar8 + 0x10) & 0x800) != 0) && (iVar11 = *(int64_t *)(iVar8 + 0x18), iVar11 != 0)) {
                *(uint32_t *)(iVar11 + 8) = *(uint32_t *)(iVar11 + 8) | 0x800;
                *(uint32_t *)(iVar11 + 0x10) =
                     *(uint32_t *)(iVar11 + 0xc) | *(uint32_t *)(iVar11 + 4) | *(uint32_t *)(iVar11 + 8);
            }
            if (*(int64_t *)(iVar8 + 0x98) != 0) {
                *(undefined8 *)(*(int64_t *)(iVar8 + 0x98) + 0x4c8) = 0;
            }
            puVar6 = *(undefined4 **)(iVar8 + 0x18);
            if (puVar6 != (undefined4 *)0x0) {
                iVar11 = *(int64_t *)(puVar6 + 8);
                if (iVar11 == iVar8) {
                    iVar11 = *(int64_t *)(puVar6 + 10);
                }
                puVar4 = *(undefined4 **)(puVar6 + 8);
                puVar5 = *(undefined4 **)(puVar6 + 10);
                uVar2 = puVar6[0x16];
                uVar3 = puVar6[0x17];
                iVar8 = *(int64_t *)(iVar11 + 0x20);
                *(int64_t *)(puVar6 + 8) = iVar8;
                *(undefined8 *)(puVar6 + 10) = *(undefined8 *)(iVar11 + 0x28);
                if (iVar8 != 0) {
                    *(undefined4 **)(iVar8 + 0x18) = puVar6;
                }
                if (*(int64_t *)(puVar6 + 10) != 0) {
                    *(undefined4 **)(*(int64_t *)(puVar6 + 10) + 0x18) = puVar6;
                }
                puVar6[0x18] = *(undefined4 *)(iVar11 + 0x60);
                *(undefined8 *)(puVar6 + 0x16) = *(undefined8 *)(iVar11 + 0x58);
                *(undefined8 *)(iVar11 + 0x28) = 0;
                *(undefined8 *)(iVar11 + 0x20) = 0;
                if (puVar4 != (undefined4 *)0x0) {
                    func_0x0001801167e0(puVar6, puVar4);
                    func_0x00018011d570(*puVar4, *puVar6);
                }
                if (puVar5 != (undefined4 *)0x0) {
                    func_0x0001801167e0(puVar6, puVar5);
                    func_0x00018011d570(*puVar5, *puVar6);
                }
                puVar12 = *(undefined8 **)(puVar6 + 0xe);
                puVar1 = puVar12 + (int32_t)puVar6[0xc];
                for (; puVar12 != puVar1; puVar12 = puVar12 + 1) {
                    uVar14 = func_0x000180106470(*puVar12, puVar6 + 0x12, 1);
                    func_0x0001801065c0(uVar14, puVar6 + 0x14, 1);
                }
                puVar6[0x36] = puVar6[0x36] & 0xfffffe00;
                *(undefined8 *)(puVar6 + 0x28) = *(undefined8 *)(iVar11 + 0xa0);
                puVar6[0x16] = uVar2;
                puVar6[0x17] = uVar3;
                uVar10 = puVar6[2];
                puVar6[2] = uVar10 & 0xfffc078f;
                uVar13 = 0;
                uVar9 = uVar13;
                if (puVar4 != (undefined4 *)0x0) {
                    uVar9 = puVar4[2];
                }
                uVar9 = (uVar10 ^ uVar9) & 0xfffc078f ^ uVar9;
                puVar6[2] = uVar9;
                uVar10 = uVar13;
                if (puVar5 != (undefined4 *)0x0) {
                    uVar10 = puVar5[2];
                }
                uVar9 = uVar10 & 0x3f870 | uVar9;
                puVar6[2] = uVar9;
                uVar10 = uVar13;
                if (puVar4 != (undefined4 *)0x0) {
                    uVar10 = puVar4[3];
                }
                if (puVar5 != (undefined4 *)0x0) {
                    uVar13 = puVar5[3];
                }
                puVar6[3] = uVar13 | uVar10;
                puVar6[4] = uVar13 | uVar10 | puVar6[1] | uVar9;
                if (puVar4 != (undefined4 *)0x0) {
                    iVar8 = *(int64_t *)(puVar4 + 0x10);
                    if (iVar8 != 0) {
                        if (*(int64_t *)(iVar8 + 0xa8) != 0) {
                            func_0x000180460d90();
                        }
                        if (*(int64_t *)(iVar8 + 0x10) != 0) {
                            func_0x000180460d90();
                        }
                        func_0x000180460d90(iVar8);
                    }
                    *(undefined8 *)(puVar4 + 0x10) = 0;
                    func_0x0001800f6220(iVar7 + 0x28e8, *puVar4, 0);
                    *(undefined8 *)(puVar4 + 10) = 0;
                    *(undefined8 *)(puVar4 + 8) = 0;
                    if (*(int64_t *)(puVar4 + 0xe) != 0) {
                        func_0x000180460d90();
                    }
                    func_0x000180460d90(puVar4);
                }
                if (puVar5 != (undefined4 *)0x0) {
                    iVar8 = *(int64_t *)(puVar5 + 0x10);
                    if (iVar8 != 0) {
                        if (*(int64_t *)(iVar8 + 0xa8) != 0) {
                            func_0x000180460d90();
                        }
                        if (*(int64_t *)(iVar8 + 0x10) != 0) {
                            func_0x000180460d90();
                        }
                        func_0x000180460d90(iVar8);
                    }
                    *(undefined8 *)(puVar5 + 0x10) = 0;
                    func_0x0001800f6220(iVar7 + 0x28e8, *puVar5, 0);
                    *(undefined8 *)(puVar5 + 10) = 0;
                    *(undefined8 *)(puVar5 + 8) = 0;
                    if (*(int64_t *)(puVar5 + 0xe) != 0) {
                        func_0x000180460d90();
                    }
                    func_0x000180460d90(puVar5);
                }
                return;
            }
            func_0x0001801152b0(iVar7);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18011c860
// Address: 0x18011c860
// Size: 1076 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_80h
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_70h
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch

void fcn.18011c860(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4,
                  undefined8 placeholder_4, int64_t arg_30h)
{
    undefined8 *puVar1;
    int64_t iVar2;
    int32_t *piVar3;
    int64_t iVar4;
    int64_t iVar5;
    bool bVar6;
    int64_t iVar7;
    uint32_t uVar8;
    int32_t iVar9;
    int32_t *piVar10;
    undefined4 *puVar11;
    uint64_t uVar12;
    int32_t iVar13;
    undefined4 *puVar14;
    uint32_t *puVar15;
    uint32_t uVar16;
    int32_t iVar17;
    uint64_t uVar18;
    uint64_t uVar19;
    uint64_t uVar20;
    int32_t iVar21;
    uint64_t uVar22;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    iVar7 = *(int64_t *)0x180781f28;
    iVar13 = (int32_t)arg1;
    puVar1 = (undefined8 *)(*(int64_t *)0x180781f28 + 0x28e8);
    if (iVar13 == 0) {
        iVar21 = 0;
        var_18h._0_4_ = 0;
        puVar15 = (uint32_t *)0xd8;
        var_70h = 0;
    } else {
        var_70h = func_0x0001800f60f0(puVar1, arg1 & 0xffffffff);
        if (var_70h == 0) {
            return;
        }
        puVar15 = (uint32_t *)(var_70h + 0xd8);
        var_18h._0_4_ = (int32_t)(*puVar15 << 0x1d) >> 0x1d;
        iVar21 = (int32_t)(*puVar15 << 0x1a) >> 0x1d;
    }
    uVar18 = 0;
    bVar6 = false;
    var_60h = 0;
    iVar17 = 0;
    var_58h = 0;
    uVar19 = uVar18;
    uVar22 = uVar18;
    uVar12 = uVar18;
    uVar20 = uVar18;
    if (0 < *(int32_t *)puVar1) {
        do {
            piVar3 = *(int32_t **)(*(int64_t *)(iVar7 + 0x28f0) + 8 + (int64_t)(int32_t)uVar20 * 0x10);
            uVar12 = uVar22;
            if (piVar3 != (int32_t *)0x0) {
                if (iVar13 == 0) {
code_r0x00018011c9a9:
                    if ((piVar3[4] & 0x800U) != 0) {
                        bVar6 = true;
                    }
                    if (iVar13 != 0) {
                        puVar11 = *(undefined4 **)(iVar7 + 0x2900);
                        puVar14 = puVar11 + (int64_t)*(int32_t *)(iVar7 + 0x28f8) * 0x10;
                        for (; puVar11 != puVar14; puVar11 = puVar11 + 0x10) {
                            if (*(int32_t **)(puVar11 + 4) == piVar3) {
                                *puVar11 = 0;
                            }
                        }
                    }
                    if (var_70h != 0) {
                        func_0x0001801167e0(var_70h, piVar3);
                        func_0x00018011d570(*piVar3, *(undefined4 *)var_70h);
                    }
                    iVar9 = (int32_t)uVar19;
                    iVar17 = (int32_t)uVar18;
                    if (iVar17 == iVar9) {
                        if (iVar9 == 0) {
                            uVar8 = 8;
                        } else {
                            uVar8 = iVar9 / 2 + iVar9;
                        }
                        uVar16 = iVar17 + 1U;
                        if ((int32_t)(iVar17 + 1U) < (int32_t)uVar8) {
                            uVar16 = uVar8;
                        }
                        if (iVar9 < (int32_t)uVar16) {
                            uVar12 = func_0x00018046d050((int64_t)(int32_t)uVar16 << 3);
                            if (uVar22 != 0) {
                                func_0x000180498030(uVar12, uVar22, (int64_t)iVar17 << 3);
                                func_0x000180460d90(uVar22);
                            }
                            uVar19 = (uint64_t)uVar16;
                            var_60h = (uint64_t)uVar16 << 0x20;
                            var_58h = uVar12;
                        }
                    }
                    *(int32_t **)(uVar12 + (int64_t)iVar17 * 8) = piVar3;
                    uVar18 = (uint64_t)(iVar17 + 1U);
                    var_60h = CONCAT44(var_60h._4_4_, iVar17 + 1U);
                } else if ((*piVar3 != iVar13) && (piVar10 = piVar3, *(int64_t *)(piVar3 + 6) != 0)) {
                    do {
                        piVar10 = *(int32_t **)(piVar10 + 6);
                    } while (*(int64_t *)(piVar10 + 6) != 0);
                    if (*piVar10 == iVar13) goto code_r0x00018011c9a9;
                }
            }
            iVar17 = (int32_t)uVar18;
            uVar8 = (int32_t)uVar20 + 1;
            uVar22 = uVar12;
            uVar20 = (uint64_t)uVar8;
        } while ((int32_t)uVar8 < *(int32_t *)puVar1);
        puVar15 = (uint32_t *)(var_70h + 0xd8);
    }
    uVar19 = 0;
    if (var_70h != 0) {
        *puVar15 = (iVar21 * 8 ^ (uint32_t)var_18h) & 0xffffffc7 ^ ((uint32_t)var_18h ^ *puVar15) & 0xffffffc0 ^
                   iVar21 * 8;
    }
    uVar22 = uVar19;
    if (*(int64_t *)(iVar7 + 0x2958) != 0) {
        uVar22 = *(int64_t *)(iVar7 + 0x2958) + 4;
    }
    do {
        if (uVar22 == 0) {
            if ((1 < iVar17) && (1 < (uint64_t)(int64_t)iVar17)) {
                func_0x00018046f0d0(uVar12, (int64_t)iVar17, 8, 0x180115340, iVar7, var_70h, puVar1, var_70h, puVar1, 
                                    var_60h, var_58h);
            }
            iVar21 = 0;
            if (0 < iVar17) {
                do {
                    iVar9 = 0;
                    iVar4 = *(int64_t *)(uVar12 + (int64_t)iVar21 * 8);
                    if (*(int64_t *)(iVar4 + 0x98) != 0) {
                        *(undefined8 *)(*(int64_t *)(iVar4 + 0x98) + 0x4c8) = 0;
                    }
                    iVar5 = *(int64_t *)(iVar4 + 0x18);
                    if (iVar5 != 0) {
                        for (; iVar9 < 2; iVar9 = iVar9 + 1) {
                            iVar2 = (int64_t)iVar9 * 8 + 0x20;
                            if (*(int64_t *)(iVar5 + iVar2) == iVar4) {
                                *(undefined8 *)(iVar2 + *(int64_t *)(iVar4 + 0x18)) = 0;
                            }
                        }
                    }
                    func_0x0001801152b0(iVar7, iVar4);
                    iVar21 = iVar21 + 1;
                } while (iVar21 < iVar17);
            }
            if (iVar13 == 0) {
                if (*(int64_t *)(iVar7 + 0x28f0) != 0) {
                    *puVar1 = 0;
                    func_0x000180460d90();
                    *(undefined8 *)(iVar7 + 0x28f0) = 0;
                }
                if (*(int64_t *)(iVar7 + 0x2900) != 0) {
                    *(undefined8 *)(iVar7 + 0x28f8) = 0;
                    func_0x000180460d90();
                    *(undefined8 *)(iVar7 + 0x2900) = 0;
                }
            } else if (bVar6) {
                *(int64_t *)(var_70h + 0xa8) = var_70h;
                *(uint32_t *)(var_70h + 8) = *(uint32_t *)(var_70h + 8) | 0x800;
                *(uint32_t *)(var_70h + 0x10) =
                     *(uint32_t *)(var_70h + 0xc) | *(uint32_t *)(var_70h + 4) | *(uint32_t *)(var_70h + 8);
            }
            if (uVar12 != 0) {
                func_0x000180460d90(uVar12);
            }
            return;
        }
        if ((*(int32_t *)(uVar22 + 0x14) != 0) && (uVar20 = uVar19, 0 < iVar17)) {
            do {
                if (**(int32_t **)(uVar12 + (int64_t)(int32_t)uVar20 * 8) == *(int32_t *)(uVar22 + 0x14)) {
                    *(int32_t *)(uVar22 + 0x14) = iVar13;
                    break;
                }
                uVar8 = (int32_t)uVar20 + 1;
                uVar20 = (uint64_t)uVar8;
            } while ((int32_t)uVar8 < iVar17);
        }
        uVar20 = (int64_t)*(int32_t *)(uVar22 - 4) + uVar22;
        uVar22 = uVar19;
        if (uVar20 != *(int64_t *)(iVar7 + 0x2958) + 4 + (int64_t)*(int32_t *)(iVar7 + 0x2950)) {
            uVar22 = uVar20;
        }
    } while( true );
}

// ============================================================
// Function: FUN_18011cca0
// Address: 0x18011cca0
// Size: 272 bytes
// ============================================================
void fcn.18011cca0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int32_t *piVar5;
    char in_DL;
    int32_t iVar6;
    int32_t iVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    
    iVar4 = *(int64_t *)0x180781f28;
    uVar8 = 0;
    iVar6 = (int32_t)arg1;
    if (in_DL != '\0') {
        uVar3 = uVar8;
        if (*(int64_t *)(*(int64_t *)0x180781f28 + 0x2958) != 0) {
            uVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2958) + 4;
        }
        while (uVar3 != 0) {
            if ((iVar6 == 0) || (*(int32_t *)(uVar3 + 0x14) == iVar6)) {
code_r0x00018011cd0e:
                *(undefined4 *)(uVar3 + 0x14) = 0;
            } else if ((*(int32_t *)(uVar3 + 0x14) != 0) &&
                      (piVar5 = (int32_t *)func_0x0001800f60f0(iVar4 + 0x28e8), piVar5 != (int32_t *)0x0)) {
                iVar1 = *(int64_t *)(piVar5 + 6);
                while (iVar1 != 0) {
                    piVar5 = *(int32_t **)(piVar5 + 6);
                    iVar1 = *(int64_t *)(piVar5 + 6);
                }
                if (*piVar5 == iVar6) goto code_r0x00018011cd0e;
            }
            uVar9 = (int64_t)*(int32_t *)(uVar3 - 4) + uVar3;
            uVar3 = uVar8;
            if (uVar9 != *(int64_t *)(iVar4 + 0x2958) + 4 + (int64_t)*(int32_t *)(iVar4 + 0x2950)) {
                uVar3 = uVar9;
            }
        }
    }
    if (0 < *(int32_t *)(iVar4 + 0x1580)) {
        do {
            iVar7 = (int32_t)uVar8;
            iVar1 = *(int64_t *)(*(int64_t *)(iVar4 + 0x1588) + (int64_t)iVar7 * 8);
            if (iVar6 == 0) {
code_r0x00018011cd92:
                func_0x000180115d50((int64_t)iVar7, iVar1, in_DL);
            } else {
                piVar5 = *(int32_t **)(iVar1 + 0x4c0);
                if (piVar5 != (int32_t *)0x0) {
                    iVar2 = *(int64_t *)(piVar5 + 6);
                    while (iVar2 != 0) {
                        piVar5 = *(int32_t **)(piVar5 + 6);
                        iVar2 = *(int64_t *)(piVar5 + 6);
                    }
                    if (*piVar5 == iVar6) goto code_r0x00018011cd92;
                }
                if ((*(int32_t **)(iVar1 + 0x4c8) != (int32_t *)0x0) && (**(int32_t **)(iVar1 + 0x4c8) == iVar6))
                goto code_r0x00018011cd92;
            }
            uVar8 = (uint64_t)(iVar7 + 1U);
        } while ((int32_t)(iVar7 + 1U) < *(int32_t *)(iVar4 + 0x1580));
    }
    return;
}

// ============================================================
// Function: FUN_18011cdb0
// Address: 0x18011cdb0
// Size: 642 bytes
// ============================================================
void fcn.18011cdb0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4)
{
    float fVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    int64_t var_18h;
    
    iVar2 = *(int64_t *)0x180781f28;
    iVar4 = 0;
    do {
        iVar3 = (int64_t)*(int32_t *)(iVar4 * 4 + 0x180618a30) + 0xed;
        fVar1 = *(float *)(iVar2 + iVar3 * 0x10);
        if (0.0 <= fVar1) {
            fVar8 = 1.0;
            if (fVar1 <= 1.0) {
                fVar8 = fVar1;
            }
        } else {
            fVar8 = 0.0;
        }
        fVar1 = *(float *)(iVar2 + 4 + iVar3 * 0x10);
        if (0.0 <= fVar1) {
            fVar5 = 1.0;
            if (fVar1 <= 1.0) {
                fVar5 = fVar1;
            }
        } else {
            fVar5 = 0.0;
        }
        fVar1 = *(float *)(iVar2 + 8 + iVar3 * 0x10);
        if (0.0 <= fVar1) {
            fVar6 = 1.0;
            if (fVar1 <= 1.0) {
                fVar6 = fVar1;
            }
        } else {
            fVar6 = 0.0;
        }
        fVar1 = *(float *)(iVar2 + 0xc + iVar3 * 0x10);
        if (0.0 <= fVar1) {
            fVar7 = 1.0;
            if (fVar1 <= 1.0) {
                fVar7 = fVar1;
            }
        } else {
            fVar7 = 0.0;
        }
        iVar3 = (int64_t)*(int32_t *)(iVar4 * 4 + 0x180618a34) + 0xed;
        *(int32_t *)(arg1 + 0x498 + iVar4 * 4) =
             (int32_t)(fVar7 * 255.0 + 0.5) << 0x18 |
             (int32_t)(fVar6 * 255.0 + 0.5) << 0x10 |
             (int32_t)(fVar5 * 255.0 + 0.5) << 8 | (int32_t)(fVar8 * 255.0 + 0.5);
        fVar1 = *(float *)(iVar2 + iVar3 * 0x10);
        if (0.0 <= fVar1) {
            fVar8 = 1.0;
            if (fVar1 <= 1.0) {
                fVar8 = fVar1;
            }
        } else {
            fVar8 = 0.0;
        }
        fVar1 = *(float *)(iVar2 + 4 + iVar3 * 0x10);
        if (0.0 <= fVar1) {
            fVar5 = 1.0;
            if (fVar1 <= 1.0) {
                fVar5 = fVar1;
            }
        } else {
            fVar5 = 0.0;
        }
        fVar1 = *(float *)(iVar2 + 8 + iVar3 * 0x10);
        if (0.0 <= fVar1) {
            fVar6 = 1.0;
            if (fVar1 <= 1.0) {
                fVar6 = fVar1;
            }
        } else {
            fVar6 = 0.0;
        }
        fVar1 = *(float *)(iVar2 + 0xc + iVar3 * 0x10);
        if (0.0 <= fVar1) {
            fVar7 = 1.0;
            if (fVar1 <= 1.0) {
                fVar7 = fVar1;
            }
        } else {
            fVar7 = 0.0;
        }
        iVar3 = (int64_t)*(int32_t *)(iVar4 * 4 + 0x180618a38) + 0xed;
        *(int32_t *)(arg1 + 0x49c + iVar4 * 4) =
             (int32_t)(fVar7 * 255.0 + 0.5) << 0x18 |
             (int32_t)(fVar6 * 255.0 + 0.5) << 0x10 |
             (int32_t)(fVar5 * 255.0 + 0.5) << 8 | (int32_t)(fVar8 * 255.0 + 0.5);
        fVar1 = *(float *)(iVar2 + iVar3 * 0x10);
        if (0.0 <= fVar1) {
            fVar8 = 1.0;
            if (fVar1 <= 1.0) {
                fVar8 = fVar1;
            }
        } else {
            fVar8 = 0.0;
        }
        fVar1 = *(float *)(iVar2 + 4 + iVar3 * 0x10);
        if (0.0 <= fVar1) {
            fVar5 = 1.0;
            if (fVar1 <= 1.0) {
                fVar5 = fVar1;
            }
        } else {
            fVar5 = 0.0;
        }
        fVar1 = *(float *)(iVar2 + 8 + iVar3 * 0x10);
        if (0.0 <= fVar1) {
            fVar6 = 1.0;
            if (fVar1 <= 1.0) {
                fVar6 = fVar1;
            }
        } else {
            fVar6 = 0.0;
        }
        fVar1 = *(float *)(iVar2 + 0xc + iVar3 * 0x10);
        if (0.0 <= fVar1) {
            fVar7 = 1.0;
            if (fVar1 <= 1.0) {
                fVar7 = fVar1;
            }
        } else {
            fVar7 = 0.0;
        }
        *(int32_t *)(arg1 + 0x4a0 + iVar4 * 4) =
             (int32_t)(fVar7 * 255.0 + 0.5) << 0x18 |
             (int32_t)(fVar6 * 255.0 + 0.5) << 0x10 |
             (int32_t)(fVar5 * 255.0 + 0.5) << 8 | (int32_t)(fVar8 * 255.0 + 0.5);
        iVar4 = iVar4 + 3;
    } while (iVar4 != 9);
    return;
}

// ============================================================
// Function: FUN_18011d040
// Address: 0x18011d040
// Size: 1326 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Removing arg arg_230h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_384h
// WARNING: [rz-ghidra] Detected overlap for variable var_380h
// WARNING: [rz-ghidra] Detected overlap for variable var_37ch
// WARNING: [rz-ghidra] Detected overlap for variable var_34bh
// WARNING: [rz-ghidra] Detected overlap for variable var_349h
// WARNING: [rz-ghidra] Removing arg arg_73h because it doesn't fit into ProtoModel

void fcn.18011d040(int64_t arg1, int64_t arg_e0h, int64_t arg_100h, int64_t arg_108h, int64_t arg_118h, int64_t arg_1c0h
                  )
{
    char *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    undefined4 uVar6;
    bool bVar7;
    bool bVar8;
    char cVar9;
    int32_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    int32_t *piVar13;
    int64_t iVar14;
    int32_t iVar15;
    char *pcVar16;
    undefined uVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    undefined auStack_3c8 [32];
    int64_t var_3a8h;
    int64_t var_3a0h;
    int64_t var_398h;
    int64_t var_388h;
    undefined4 var_380h;
    undefined4 var_37ch;
    int64_t var_374h;
    int64_t var_34fh;
    char acStack_338 [32];
    undefined8 uStack_318;
    undefined8 uStack_310;
    int64_t iStack_300;
    char acStack_258 [144];
    undefined8 uStack_1c8;
    undefined8 uStack_1c0;
    int64_t iStack_1b0;
    undefined uStack_108;
    uint64_t uStack_98;
    int64_t var_70h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    
    iVar14 = *(int64_t *)0x180781f28;
    uStack_98 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_3c8;
    if (*(char *)(*(int64_t *)0x180781f28 + 0x2400) == '\0') goto code_r0x00018011d533;
    fVar18 = *(float *)(arg1 + 100);
    fVar20 = fVar18 + *(float *)(arg1 + 0x6c);
    fVar19 = *(float *)(undefined8 *)(arg1 + 0x60);
    fVar21 = fVar19 + *(float *)(arg1 + 0x68);
    var_380h = fVar21;
    var_388h = *(undefined8 *)(arg1 + 0x60);
    var_37ch = fVar20;
    if ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x15f0) == 0) ||
       (iVar12 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0),
       *(int64_t *)(iVar12 + 0x428) != *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15f0) + 0x428)))
    goto code_r0x00018011d533;
    iVar10 = *(int32_t *)(arg1 + 0x10);
    uVar17 = 1;
    cVar9 = func_0x000180108120(&var_388h, &var_380h);
    if ((cVar9 == '\0') || ((iVar10 == *(int32_t *)(iVar14 + 0x241c) || (*(char *)(iVar12 + 0x10e) != '\0'))))
    goto code_r0x00018011d533;
    *(float *)(iVar14 + 0x2450) = fVar19;
    *(float *)(iVar14 + 0x2454) = fVar18;
    *(float *)(iVar14 + 0x2458) = fVar21;
    *(float *)(iVar14 + 0x245c) = fVar20;
    uVar2 = *(undefined4 *)(iVar12 + 700);
    uVar3 = *(undefined4 *)(iVar12 + 0x2c0);
    uVar6 = *(undefined4 *)(iVar12 + 0x2c4);
    *(undefined4 *)(iVar14 + 0x2460) = *(undefined4 *)(iVar12 + 0x2b8);
    *(undefined4 *)(iVar14 + 0x2464) = uVar2;
    *(undefined4 *)(iVar14 + 0x2468) = uVar3;
    *(undefined4 *)(iVar14 + 0x246c) = uVar6;
    *(int32_t *)(iVar14 + 0x2470) = iVar10;
    iVar12 = 0;
    *(undefined4 *)(iVar14 + 0x2474) = 0;
    *(undefined *)(iVar14 + 0x2402) = uVar17;
    if ((*(int32_t *)(iVar14 + 0x2424) == -1) ||
       (iVar10 = func_0x000180498f10(0x180644588, iVar14 + 0x2428), iVar10 != 0)) {
code_r0x00018011d51e:
        *(undefined *)(iVar14 + 0x2402) = 0;
        cVar9 = *(char *)(iVar14 + 0x244a);
    } else {
        uVar4 = **(undefined8 **)(iVar14 + 0x2410);
        cVar9 = func_0x0001801191b0(arg1, uVar4);
        if (cVar9 == '\0') goto code_r0x00018011d51e;
        iVar11 = func_0x000180112360();
        if (iVar11 != 0) {
            bVar8 = false;
            bVar7 = false;
            if (*(int64_t *)(arg1 + 0x4c8) == 0) {
                iVar11 = *(int64_t *)(arg1 + 0x4c0);
                if (*(int64_t *)(arg1 + 0x4c0) == 0) {
                    bVar8 = true;
                    goto code_r0x00018011d26c;
                }
code_r0x00018011d248:
                iVar12 = iVar11;
                iVar11 = *(int64_t *)(iVar12 + 0x40);
                if (((iVar11 == 0) || ((*(uint32_t *)(iVar12 + 0x10) >> 0xd & 1) != 0)) ||
                   ((*(uint32_t *)(iVar12 + 0x10) >> 0xc & 1) != 0)) goto code_r0x00018011d26c;
                fVar18 = *(float *)(iVar11 + 0x38);
                fVar19 = *(float *)(iVar11 + 0x3c);
                fVar20 = *(float *)(iVar11 + 0x40);
                fVar21 = *(float *)(iVar11 + 0x44);
            } else {
                iVar11 = func_0x00018011bfb0(*(int64_t *)(arg1 + 0x4c8), *(undefined8 *)(iVar14 + 0x118));
                iVar12 = iVar11;
                if (iVar11 != 0) {
                    if (((((*(uint32_t *)(iVar11 + 0x10) & 0x400) != 0) && (*(int64_t *)(iVar11 + 0x18) == 0)) &&
                        ((iVar12 = *(int64_t *)(iVar11 + 0xa8), iVar12 == 0 || (*(int64_t *)(iVar11 + 0x20) != 0)))) &&
                       ((iVar12 = iVar11, *(int64_t *)(iVar11 + 0x20) != 0 &&
                        (iVar12 = func_0x00018011bf70(), iVar12 == 0)))) {
                        iVar12 = func_0x00018011bf70(*(undefined8 *)(iVar11 + 0x28));
                    }
                    iVar11 = iVar12;
                    if (iVar12 != 0) goto code_r0x00018011d248;
                }
code_r0x00018011d26c:
                bVar7 = bVar8;
                fVar18 = *(float *)(arg1 + 0x60);
                fVar19 = *(float *)(arg1 + 100);
                fVar20 = fVar18 + *(float *)(arg1 + 0x68);
                fVar21 = *(float *)(iVar14 + 0xde0) + *(float *)(iVar14 + 0xde0) + *(float *)(iVar14 + 0x12f8) + fVar19;
            }
            var_388h._4_4_ = fVar19;
            var_388h._0_4_ = fVar18;
            var_380h = fVar20;
            var_37ch = fVar21;
            if ((*(char *)(iVar14 + 0x82) == '\0') &&
               (cVar9 = func_0x000180108120(&var_388h, &var_380h, 1), cVar9 == '\0')) {
                uVar17 = 0;
            } else {
                uVar17 = 1;
            }
            if (((*(char *)(iVar14 + 0x2449) != '\0') || (*(char *)(iVar14 + 0x244a) != '\0')) &&
               ((iVar12 != 0 || (bVar7)))) {
                func_0x000180114c50(acStack_258 + 0x70);
                func_0x000180114c50(acStack_338);
                pcVar1 = acStack_258 + 0x70;
                pcVar16 = pcVar1;
                if ((iVar12 == 0) ||
                   (((*(int64_t *)(iVar12 + 0x18) == 0 && ((*(uint32_t *)(iVar12 + 0x10) & 0x800) == 0)) &&
                    (*(int64_t *)(iVar12 + 0x20) == 0)))) {
code_r0x00018011d394:
                    var_398h._0_1_ = 0;
                    var_3a8h = (int64_t)(acStack_258 + 0x70);
                    var_3a0h._0_1_ = uVar17;
                    func_0x0001801192f0(arg1, iVar12, uVar4);
                } else {
                    iVar11 = iVar12;
                    if (*(int64_t *)(iVar12 + 0x18) == 0) {
code_r0x00018011d360:
                        var_398h._0_1_ = 1;
                        var_3a8h = (int64_t)acStack_338;
                        var_3a0h._0_1_ = uVar17;
                        func_0x0001801192f0(arg1, iVar11, uVar4);
                        pcVar16 = acStack_338;
                        if (acStack_258[3] == '\0') {
                            pcVar16 = pcVar1;
                        }
                    } else {
                        do {
                            iVar11 = *(int64_t *)(iVar11 + 0x18);
                        } while (*(int64_t *)(iVar11 + 0x18) != 0);
                        if (iVar11 != 0) goto code_r0x00018011d360;
                    }
                    if (*(int64_t *)(iVar12 + 0x20) == 0) goto code_r0x00018011d394;
                }
                if (pcVar16 == acStack_338) {
                    uStack_108 = 0;
                }
                func_0x00018011a310(arg1, iVar12, uVar4, acStack_258 + 0x70);
                func_0x00018011a310(arg1, iVar12, uVar4, acStack_338);
                if ((pcVar16[0xe0] != '\0') && (*(char *)(iVar14 + 0x244a) != '\0')) {
                    uVar2 = *(undefined4 *)(pcVar16 + 0xf4);
                    uVar3 = *(undefined4 *)(pcVar16 + 0xf0);
                    uVar5 = *(undefined8 *)(pcVar16 + 0xe8);
                    piVar13 = (int32_t *)(iVar14 + 0x28f8);
                    iVar10 = *(int32_t *)(iVar14 + 0x28fc);
                    if (*piVar13 == iVar10) {
                        iVar15 = *piVar13 + 1;
                        if (iVar10 == 0) {
                            iVar10 = 8;
                        } else {
                            iVar10 = iVar10 / 2 + iVar10;
                        }
                        if (iVar15 < iVar10) {
                            iVar15 = iVar10;
                        }
                        func_0x00018011fa30(piVar13, iVar15);
                    }
                    iVar12 = (int64_t)*piVar13 * 0x40;
                    iVar14 = *(int64_t *)(iVar14 + 0x2900);
                    *(undefined4 *)(iVar12 + iVar14) = 1;
                    *(undefined4 *)(iVar12 + 4 + iVar14) = (undefined4)var_374h;
                    *(int64_t *)(iVar12 + 8 + iVar14) = arg1;
                    *(undefined8 *)(iVar12 + 0x10 + iVar14) = uVar5;
                    *(undefined8 *)(iVar12 + 0x18 + iVar14) = uVar4;
                    *(undefined4 *)(iVar12 + 0x20 + iVar14) = uVar3;
                    *(undefined4 *)(iVar12 + 0x24 + iVar14) = uVar2;
                    *(bool *)(iVar12 + 0x28 + iVar14) = pcVar16 == acStack_338;
                    *(undefined4 *)(iVar12 + 0x29 + iVar14) = (undefined4)var_34fh;
                    *(undefined2 *)(iVar12 + 0x2d + iVar14) = var_34fh._4_2_;
                    *(undefined *)(iVar12 + 0x2f + iVar14) = var_34fh._6_1_;
                    *(undefined8 *)(iVar12 + 0x30 + iVar14) = 0;
                    *(undefined8 *)(iVar12 + 0x38 + iVar14) = 0;
                    *piVar13 = *piVar13 + 1;
                }
                uStack_310 = 0;
                uStack_318 = 0;
                if (iStack_300 != 0) {
                    func_0x000180460d90();
                }
                uStack_1c0 = 0;
                uStack_1c8 = 0;
                iVar14 = *(int64_t *)0x180781f28;
                if (iStack_1b0 != 0) {
                    func_0x000180460d90();
                    iVar14 = *(int64_t *)0x180781f28;
                }
            }
        }
        *(undefined *)(iVar14 + 0x2402) = 0;
        cVar9 = *(char *)(iVar14 + 0x244a);
    }
    if (cVar9 != '\0') {
        func_0x0001801120a0();
    }
code_r0x00018011d533:
    func_0x000180459870(uStack_98 ^ (uint64_t)auStack_3c8);
    return;
}

// ============================================================
// Function: FUN_18011d620
// Address: 0x18011d620
// Size: 198 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x00018011c895)
// WARNING: Removing unreachable block (ram,0x00018011c8b0)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Removing unreachable block (ram,0x00018011c9c5)
// WARNING: Removing unreachable block (ram,0x00018011c9e0)
// WARNING: Removing unreachable block (ram,0x00018011c9e6)
// WARNING: Removing unreachable block (ram,0x00018011c9e9)
// WARNING: Removing unreachable block (ram,0x00018011c97e)
// WARNING: Removing unreachable block (ram,0x00018011c987)
// WARNING: Removing unreachable block (ram,0x00018011c995)
// WARNING: Removing unreachable block (ram,0x00018011c9a0)
// WARNING: Removing unreachable block (ram,0x00018011cc4c)
// WARNING: Removing unreachable block (ram,0x00018011cc56)

void fcn.18011d620(int64_t arg1)
{
    int64_t iVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    uint32_t uVar4;
    int32_t iVar5;
    uint64_t uVar6;
    uint32_t *puVar7;
    uint32_t uVar8;
    int32_t iVar9;
    uint32_t uVar10;
    undefined4 *puVar11;
    int32_t iVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iVar17;
    undefined4 *puVar18;
    undefined8 *puVar19;
    int64_t iVar20;
    undefined8 *puVar21;
    undefined8 uVar22;
    uint64_t uVar23;
    uint64_t uVar12;
    
    uVar12 = 0;
    if (*(int64_t *)(arg1 + 0x2910) != 0) {
        *(undefined8 *)(arg1 + 0x2908) = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg1 + 0x2910) = 0;
    }
    iVar3 = *(int64_t *)0x180781f28;
    uVar6 = uVar12;
    if (*(int64_t *)(*(int64_t *)0x180781f28 + 0x2958) != 0) {
        uVar6 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2958) + 4;
    }
    while (uVar6 != 0) {
        iVar13 = *(int32_t *)(uVar6 - 4);
        *(undefined4 *)(uVar6 + 0x14) = 0;
        uVar16 = (int64_t)iVar13 + uVar6;
        uVar6 = uVar12;
        if (uVar16 != *(int64_t *)(iVar3 + 0x2958) + 4 + (int64_t)*(int32_t *)(iVar3 + 0x2950)) {
            uVar6 = uVar16;
        }
    }
    if (0 < *(int32_t *)(iVar3 + 0x1580)) {
        do {
            func_0x000180115d50();
            uVar10 = (int32_t)uVar12 + 1;
            uVar12 = (uint64_t)uVar10;
        } while ((int32_t)uVar10 < *(int32_t *)(iVar3 + 0x1580));
    }
    iVar3 = *(int64_t *)0x180781f28;
    puVar19 = (undefined8 *)(*(int64_t *)0x180781f28 + 0x28e8);
    puVar18 = (undefined4 *)0x0;
    iVar20 = 0;
    puVar11 = (undefined4 *)0x0;
    puVar7 = (uint32_t *)0xd8;
    uVar14 = 0;
    uVar22 = 0;
    iVar13 = 0;
    uVar23 = 0;
    uVar12 = uVar14;
    uVar16 = uVar14;
    uVar6 = uVar14;
    uVar15 = uVar14;
    iVar17 = *(int64_t *)0x180781f28;
    puVar21 = puVar19;
    if (0 < *(int32_t *)puVar19) {
        do {
            puVar2 = *(undefined4 **)(*(int64_t *)(iVar3 + 0x28f0) + 8 + (int64_t)(int32_t)uVar15 * 0x10);
            uVar6 = uVar16;
            if (puVar2 != (undefined4 *)0x0) {
                if (puVar11 != (undefined4 *)0x0) {
                    func_0x0001801167e0(puVar11, puVar2);
                    func_0x00018011d570(*puVar2, *puVar11);
                }
                uVar10 = (uint32_t)((uint64_t)uVar22 >> 0x20);
                iVar9 = (int32_t)uVar12;
                iVar13 = (int32_t)uVar14;
                if (iVar13 == iVar9) {
                    if (iVar9 == 0) {
                        uVar4 = 8;
                    } else {
                        uVar4 = iVar9 / 2 + iVar9;
                    }
                    uVar8 = iVar13 + 1U;
                    if ((int32_t)(iVar13 + 1U) < (int32_t)uVar4) {
                        uVar8 = uVar4;
                    }
                    puVar11 = puVar18;
                    if (iVar9 < (int32_t)uVar8) {
                        uVar6 = func_0x00018046d050((int64_t)(int32_t)uVar8 << 3);
                        puVar11 = puVar18;
                        if (uVar16 != 0) {
                            func_0x000180498030(uVar6, uVar16, (int64_t)iVar13 << 3);
                            func_0x000180460d90(uVar16);
                            puVar11 = puVar18;
                        }
                        uVar12 = (uint64_t)uVar8;
                        puVar18 = puVar11;
                        uVar23 = uVar6;
                        uVar10 = uVar8;
                    }
                }
                *(undefined4 **)(uVar6 + (int64_t)iVar13 * 8) = puVar2;
                uVar14 = (uint64_t)(iVar13 + 1U);
                uVar22 = CONCAT44(uVar10, iVar13 + 1U);
            }
            iVar13 = (int32_t)uVar14;
            uVar10 = (int32_t)uVar15 + 1;
            uVar16 = uVar6;
            uVar15 = (uint64_t)uVar10;
        } while ((int32_t)uVar10 < *(int32_t *)puVar21);
        puVar7 = (uint32_t *)(iVar20 + 0xd8);
    }
    uVar12 = 0;
    if (puVar11 != (undefined4 *)0x0) {
        *puVar7 = *puVar7 & 0xffffffc0;
    }
    uVar16 = uVar12;
    if (*(int64_t *)(iVar17 + 0x2958) != 0) {
        uVar16 = *(int64_t *)(iVar17 + 0x2958) + 4;
    }
    do {
        if (uVar16 == 0) {
            if ((1 < iVar13) && (1 < (uint64_t)(int64_t)iVar13)) {
                func_0x00018046f0d0(uVar6, (int64_t)iVar13, 8, 0x180115340, iVar17, puVar18, puVar19, iVar20, puVar21, 
                                    uVar22, uVar23);
            }
            iVar9 = 0;
            if (0 < iVar13) {
                do {
                    iVar5 = 0;
                    iVar3 = *(int64_t *)(uVar6 + (int64_t)iVar9 * 8);
                    if (*(int64_t *)(iVar3 + 0x98) != 0) {
                        *(undefined8 *)(*(int64_t *)(iVar3 + 0x98) + 0x4c8) = 0;
                    }
                    iVar20 = *(int64_t *)(iVar3 + 0x18);
                    if (iVar20 != 0) {
                        for (; iVar5 < 2; iVar5 = iVar5 + 1) {
                            iVar1 = (int64_t)iVar5 * 8 + 0x20;
                            if (*(int64_t *)(iVar20 + iVar1) == iVar3) {
                                *(undefined8 *)(iVar1 + *(int64_t *)(iVar3 + 0x18)) = 0;
                            }
                        }
                    }
                    func_0x0001801152b0(iVar17, iVar3);
                    iVar9 = iVar9 + 1;
                } while (iVar9 < iVar13);
            }
            if (puVar21[1] != 0) {
                *puVar21 = 0;
                func_0x000180460d90();
                puVar21[1] = 0;
            }
            if (puVar21[3] != 0) {
                puVar21[2] = 0;
                func_0x000180460d90();
                puVar21[3] = 0;
            }
            if (uVar6 != 0) {
                func_0x000180460d90(uVar6);
            }
            return;
        }
        if ((*(int32_t *)(uVar16 + 0x14) != 0) && (uVar15 = uVar12, 0 < iVar13)) {
            do {
                if (**(int32_t **)(uVar6 + (int64_t)(int32_t)uVar15 * 8) == *(int32_t *)(uVar16 + 0x14)) {
                    *(undefined4 *)(uVar16 + 0x14) = 0;
                    break;
                }
                uVar10 = (int32_t)uVar15 + 1;
                uVar15 = (uint64_t)uVar10;
            } while ((int32_t)uVar10 < iVar13);
        }
        uVar15 = (int64_t)*(int32_t *)(uVar16 - 4) + uVar16;
        uVar16 = uVar12;
        if (uVar15 != *(int64_t *)(iVar17 + 0x2958) + 4 + (int64_t)*(int32_t *)(iVar17 + 0x2950)) {
            uVar16 = uVar15;
        }
    } while( true );
}

// ============================================================
// Function: FUN_18011d6f0
// Address: 0x18011d6f0
// Size: 2000 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch

void fcn.18011d6f0(int64_t arg1)
{
    uint32_t *puVar1;
    int64_t *piVar2;
    undefined4 uVar3;
    uint8_t uVar4;
    uint8_t uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int32_t iVar9;
    uint32_t uVar10;
    int32_t *piVar11;
    undefined4 *puVar12;
    undefined4 *puVar13;
    int64_t iVar14;
    undefined8 uVar15;
    int64_t iVar16;
    int32_t *piVar17;
    int32_t *piVar18;
    int64_t iVar19;
    uint64_t uVar20;
    int64_t *piVar21;
    uint64_t uVar22;
    uint64_t uVar23;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    puVar1 = (uint32_t *)(arg1 + 0x2908);
    if (*(int32_t *)(arg1 + 0x1580) == 0) {
        var_60h = 0;
        var_58h = 0;
        var_50h = 0;
        var_48h = 0;
        var_40h = 0;
        uVar10 = *puVar1;
        if (0 < (int32_t)uVar10) {
            var_58h = func_0x00018046d050((int64_t)(int32_t)uVar10 << 4);
            var_60h = (uint64_t)uVar10 << 0x20;
            var_48h = func_0x00018046d050((int64_t)(int32_t)uVar10 << 4);
            var_50h = CONCAT44(uVar10, (int32_t)var_50h);
        }
        var_78h._0_4_ = 0;
        iVar19 = var_58h;
        var_70h = var_58h;
        if (0 < (int32_t)*puVar1) {
            do {
                iVar14 = 0;
                puVar13 = (undefined4 *)(*(int64_t *)(arg1 + 0x2910) + (int64_t)(int32_t)var_78h * 0x24);
                uVar3 = *puVar13;
                iVar6 = func_0x0001800f6060(&var_50h, uVar3, 0xffffffff);
                if ((iVar6 == -1) || ((int64_t)iVar6 * 0x10 + iVar19 == 0)) {
                    var_20h._0_4_ = uVar3;
                    if (puVar13[1] != 0) {
                        iVar6 = func_0x0001800f6060(&var_50h, puVar13[1], 0xffffffff);
                        if (iVar6 != -1) {
                            iVar14 = (int64_t)iVar6 * 0x10 + iVar19;
                        }
                        if (iVar14 != 0) {
                            var_20h._0_4_ = *(undefined4 *)(iVar14 + 0xc);
                        }
                    }
                    piVar11 = (int32_t *)func_0x0001800f6170(&var_50h, uVar3);
                    if (*piVar11 == -1) {
                        iVar6 = (int32_t)var_40h;
                        iVar19 = (int64_t)(int32_t)var_40h;
                        *piVar11 = (int32_t)var_40h;
                        if ((int32_t)var_40h == (int32_t)var_60h) {
                            iVar7 = (int32_t)var_60h + 1;
                            if (var_60h._4_4_ < iVar7) {
                                if (var_60h._4_4_ == 0) {
                                    iVar8 = 8;
                                } else {
                                    iVar8 = var_60h._4_4_ / 2 + var_60h._4_4_;
                                }
                                iVar9 = iVar7;
                                if (iVar7 < iVar8) {
                                    iVar9 = iVar8;
                                }
                                if (var_60h._4_4_ < iVar9) {
                                    iVar14 = func_0x00018046d050((int64_t)iVar9 << 4);
                                    if (var_58h != 0) {
                                        func_0x000180498030(iVar14, var_58h, (int64_t)(int32_t)var_60h << 4);
                                        func_0x000180460d90(var_58h);
                                    }
                                    var_60h = CONCAT44(iVar9, iVar7);
                                    var_40h = CONCAT44(var_40h._4_4_, iVar6 + 1);
                                    var_58h = iVar14;
                                    goto code_r0x00018011d8e9;
                                }
                            }
                            var_60h = CONCAT44(var_60h._4_4_, iVar7);
                            var_40h = CONCAT44(var_40h._4_4_, (int32_t)var_40h + 1);
                        } else {
                            var_40h = CONCAT44(var_40h._4_4_, *(undefined4 *)(var_58h + iVar19 * 0x10));
                        }
code_r0x00018011d8e9:
                        puVar12 = (undefined4 *)(var_58h + iVar19 * 0x10);
                        if (puVar12 != (undefined4 *)0x0) {
                            *(undefined8 *)(puVar12 + 1) = 0;
                            *puVar12 = 0;
                        }
                        var_40h = CONCAT44(var_40h._4_4_ + 1, (int32_t)var_40h);
                    } else {
                        puVar12 = (undefined4 *)((int64_t)*piVar11 * 0x10 + var_58h);
                    }
                    puVar12[3] = (undefined4)var_20h;
                    iVar19 = var_58h;
                    var_70h = var_58h;
                    if (puVar13[1] != 0) {
                        piVar11 = (int32_t *)func_0x0001800f6170(&var_50h);
                        if (*piVar11 == -1) {
                            iVar6 = (int32_t)var_40h;
                            iVar19 = (int64_t)(int32_t)var_40h;
                            *piVar11 = (int32_t)var_40h;
                            if ((int32_t)var_40h == (int32_t)var_60h) {
                                iVar7 = (int32_t)var_60h + 1;
                                if (var_60h._4_4_ < iVar7) {
                                    if (var_60h._4_4_ == 0) {
                                        iVar8 = 8;
                                    } else {
                                        iVar8 = var_60h._4_4_ / 2 + var_60h._4_4_;
                                    }
                                    iVar9 = iVar7;
                                    if (iVar7 < iVar8) {
                                        iVar9 = iVar8;
                                    }
                                    if (var_60h._4_4_ < iVar9) {
                                        iVar14 = func_0x00018046d050((int64_t)iVar9 << 4);
                                        if (var_58h != 0) {
                                            func_0x000180498030(iVar14, var_58h, (int64_t)(int32_t)var_60h << 4);
                                            func_0x000180460d90(var_58h);
                                        }
                                        var_60h = CONCAT44(iVar9, iVar7);
                                        var_40h = CONCAT44(var_40h._4_4_, iVar6 + 1);
                                        var_58h = iVar14;
                                        goto code_r0x00018011d9f2;
                                    }
                                }
                                var_60h = CONCAT44(var_60h._4_4_, iVar7);
                                var_40h = CONCAT44(var_40h._4_4_, (int32_t)var_40h + 1);
                            } else {
                                var_40h = CONCAT44(var_40h._4_4_, *(undefined4 *)(var_58h + iVar19 * 0x10));
                            }
code_r0x00018011d9f2:
                            puVar13 = (undefined4 *)(var_58h + iVar19 * 0x10);
                            if (puVar13 != (undefined4 *)0x0) {
                                *(undefined8 *)(puVar13 + 1) = 0;
                                *puVar13 = 0;
                                puVar13[3] = 0;
                            }
                            var_40h = CONCAT44(var_40h._4_4_ + 1, (int32_t)var_40h);
                        } else {
                            puVar13 = (undefined4 *)((int64_t)*piVar11 * 0x10 + var_58h);
                        }
                        puVar13[2] = puVar13[2] + 1;
                        iVar19 = var_58h;
                        var_70h = var_58h;
                    }
                } else {
                    *puVar13 = 0;
                }
                iVar14 = *(int64_t *)0x180781f28;
                var_78h._0_4_ = (int32_t)var_78h + 1;
            } while ((int32_t)var_78h < (int32_t)*puVar1);
            iVar6 = 0;
            if (0 < (int32_t)*puVar1) {
                do {
                    iVar7 = *(int32_t *)(*(int64_t *)(arg1 + 0x2910) + 8 + (int64_t)iVar6 * 0x24);
                    if (iVar7 != 0) {
                        iVar16 = *(int64_t *)(iVar14 + 0x2958);
                        piVar11 = (int32_t *)0x0;
                        if (iVar16 != 0) {
                            piVar11 = (int32_t *)(iVar16 + 4);
                        }
                        while (piVar11 != (int32_t *)0x0) {
                            if ((*piVar11 == iVar7) && (*(char *)((int64_t)piVar11 + 0x21) == '\0')) {
                                if ((piVar11[5] != 0) &&
                                   ((iVar7 = func_0x0001800f6060(&var_50h, piVar11[5], 0xffffffff), iVar7 != -1 &&
                                    (iVar16 = (int64_t)iVar7 * 0x10 + iVar19, iVar16 != 0)))) {
                                    piVar11 = (int32_t *)(iVar16 + 8);
                                    *piVar11 = *piVar11 + 1;
                                }
                                break;
                            }
                            piVar18 = (int32_t *)((int64_t)piVar11[-1] + (int64_t)piVar11);
                            piVar11 = (int32_t *)0x0;
                            if (piVar18 != (int32_t *)((int64_t)*(int32_t *)(iVar14 + 0x2950) + 4 + iVar16)) {
                                piVar11 = piVar18;
                            }
                        }
                    }
                    iVar6 = iVar6 + 1;
                } while (iVar6 < (int32_t)*puVar1);
            }
        }
        piVar18 = (int32_t *)0x0;
        piVar11 = piVar18;
        if (*(int64_t *)(arg1 + 0x2958) != 0) {
            piVar11 = (int32_t *)(*(int64_t *)(arg1 + 0x2958) + 4);
        }
        while (piVar11 != (int32_t *)0x0) {
            iVar6 = piVar11[5];
            if (((iVar6 != 0) && (iVar7 = func_0x0001800f6060(&var_50h, iVar6, 0xffffffff), iVar7 != -1)) &&
               (piVar17 = (int32_t *)((int64_t)iVar7 * 0x10 + iVar19), piVar17 != (int32_t *)0x0)) {
                *piVar17 = *piVar17 + 1;
                if (piVar17[3] != iVar6) {
                    iVar6 = func_0x0001800f6060(&var_50h, piVar17[3], 0xffffffff);
                    piVar17 = piVar18;
                    if (iVar6 != -1) {
                        piVar17 = (int32_t *)((int64_t)iVar6 * 0x10 + iVar19);
                    }
                    if (piVar17 == (int32_t *)0x0) goto code_r0x00018011db6f;
                }
                piVar17[1] = piVar17[1] + 1;
            }
code_r0x00018011db6f:
            piVar17 = (int32_t *)((int64_t)piVar11[-1] + (int64_t)piVar11);
            piVar11 = piVar18;
            if (piVar17 != (int32_t *)(*(int64_t *)(arg1 + 0x2958) + 4 + (int64_t)*(int32_t *)(arg1 + 0x2950))) {
                piVar11 = piVar17;
            }
        }
        var_18h._0_4_ = 0;
        if (0 < (int32_t)*puVar1) {
            do {
                piVar11 = (int32_t *)(*(int64_t *)(arg1 + 0x2910) + (int64_t)(int32_t)piVar18 * 0x24);
                iVar6 = *piVar11;
                iVar7 = func_0x0001800f6060(&var_50h, iVar6, 0xffffffff);
                if (((iVar7 != -1) && (piVar18 = (int32_t *)((int64_t)iVar7 * 0x10 + iVar19), piVar18 != (int32_t *)0x0)
                    ) && (iVar7 = *piVar18, iVar7 < 2)) {
                    piVar17 = piVar18;
                    if (iVar6 != piVar18[3]) {
                        iVar8 = func_0x0001800f6060(&var_50h, piVar18[3], 0xffffffff);
                        if (iVar8 == -1) {
                            piVar17 = (int32_t *)0x0;
                        } else {
                            piVar17 = (int32_t *)((int64_t)iVar8 * 0x10 + iVar19);
                        }
                    }
                    iVar8 = piVar11[1];
                    if ((iVar8 == 0) || (iVar9 = func_0x0001800f6060(&var_50h, iVar8, 0xffffffff), iVar9 == -1)) {
                        iVar14 = 0;
                    } else {
                        iVar14 = (int64_t)iVar9 * 0x10 + iVar19;
                    }
                    iVar16 = *(int64_t *)0x180781f28;
                    if ((((iVar7 == 1) && (iVar8 == 0)) && (piVar18[2] == 0)) && ((piVar11[5] & 0x800U) == 0)) {
code_r0x00018011dc81:
                        uVar5 = 1;
                    } else {
                        uVar5 = 0;
                        if (((iVar7 == 0) && (uVar5 = 0, iVar8 == 0)) && (piVar18[2] == 0)) goto code_r0x00018011dc81;
                    }
                    if ((piVar17 == (int32_t *)0x0) || (piVar17[1] == 0)) {
                        uVar4 = 1;
                    } else {
                        uVar4 = 0;
                    }
                    if ((bool)(uVar5 | uVar4)) {
                        iVar6 = 0;
                        uVar20 = 0;
                        if (*(int64_t *)(*(int64_t *)0x180781f28 + 0x2958) != 0) {
                            uVar20 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2958) + 4;
                        }
                        while (uVar20 != 0) {
                            uVar22 = 0;
                            do {
                                iVar19 = var_70h;
                                if (*(int32_t *)(uVar20 + 0x14) == piVar11[uVar22]) {
                                    *(undefined4 *)(uVar20 + 0x14) = 0;
                                    *(undefined2 *)(uVar20 + 0x1c) = 0xffff;
                                    iVar6 = iVar6 + 1;
                                    if (0 < iVar6) goto code_r0x00018011dd2b;
                                    break;
                                }
                                uVar10 = (int32_t)uVar22 + 1;
                                uVar22 = (uint64_t)uVar10;
                            } while ((int32_t)uVar10 < 1);
                            uVar22 = (int64_t)*(int32_t *)(uVar20 - 4) + uVar20;
                            uVar20 = 0;
                            if (uVar22 != *(int64_t *)(iVar16 + 0x2958) + 4 + (int64_t)*(int32_t *)(iVar16 + 0x2950)) {
                                uVar20 = uVar22;
                            }
                        }
code_r0x00018011dd2b:
                        *piVar11 = 0;
                    } else {
                        uVar20 = 0;
                        if ((iVar14 != 0) && (*(int32_t *)(iVar14 + 8) == 1)) {
                            uVar22 = uVar20;
                            if (0 < *(int32_t *)(*(int64_t *)0x180781f28 + 0x1580)) {
                                do {
                                    iVar14 = *(int64_t *)(*(int64_t *)(iVar16 + 0x1588) + (int64_t)(int32_t)uVar22 * 8);
                                    if ((*(int32_t *)(iVar14 + 0x4d0) == iVar6) && (*(int64_t *)(iVar14 + 0x4c0) == 0))
                                    {
                                        *(int32_t *)(iVar14 + 0x4d0) = iVar8;
                                    }
                                    uVar10 = (int32_t)uVar22 + 1;
                                    uVar22 = (uint64_t)uVar10;
                                } while ((int32_t)uVar10 < *(int32_t *)(iVar16 + 0x1580));
                            }
                            uVar22 = uVar20;
                            if (*(int64_t *)(iVar16 + 0x2958) != 0) {
                                uVar22 = *(int64_t *)(iVar16 + 0x2958) + 4;
                            }
                            if (uVar22 == 0) goto code_r0x00018011dd2b;
                            do {
                                if (*(int32_t *)(uVar22 + 0x14) == iVar6) {
                                    *(int32_t *)(uVar22 + 0x14) = iVar8;
                                }
                                uVar23 = (int64_t)*(int32_t *)(uVar22 - 4) + uVar22;
                                uVar22 = uVar20;
                                if (uVar23 != *(int64_t *)(iVar16 + 0x2958) + 4 + (int64_t)*(int32_t *)(iVar16 + 0x2950)
                                   ) {
                                    uVar22 = uVar23;
                                }
                            } while (uVar22 != 0);
                            *piVar11 = 0;
                        }
                    }
                }
                var_18h._0_4_ = (uint32_t)var_18h + 1;
                piVar18 = (int32_t *)(uint64_t)(uint32_t)var_18h;
            } while ((int32_t)(uint32_t)var_18h < *(int32_t *)(arg1 + 0x2908));
        }
        iVar6 = 0;
        if (0 < (int32_t)var_50h) {
            do {
                iVar6 = iVar6 + 1;
            } while (iVar6 < (int32_t)var_50h);
        }
        if (var_48h != 0) {
            func_0x000180460d90();
        }
        if (iVar19 != 0) {
            func_0x000180460d90(iVar19);
        }
    }
    func_0x000180115390(arg1, *(undefined8 *)(arg1 + 0x2910), *(undefined4 *)(arg1 + 0x2908));
    piVar21 = *(int64_t **)(arg1 + 0x1588);
    piVar2 = piVar21 + *(int32_t *)(arg1 + 0x1580);
    for (; piVar21 != piVar2; piVar21 = piVar21 + 1) {
        iVar19 = *piVar21;
        if (((*(int32_t *)(iVar19 + 0x4d0) != 0) && (*(int32_t *)(arg1 + 4) + -1 <= *(int32_t *)(iVar19 + 0x2e0))) &&
           (*(int64_t *)(iVar19 + 0x4c0) == 0)) {
            uVar15 = func_0x0001800f60f0(arg1 + 0x28e8);
            func_0x0001801162d0(uVar15, iVar19, 1);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18011df00
// Address: 0x18011df00
// Size: 1029 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_36h
// WARNING: [rz-ghidra] Detected overlap for variable var_3eh
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_3ah

void fcn.18011df00(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4)
{
    int32_t *piVar1;
    undefined4 *puVar2;
    undefined auVar3 [16];
    int32_t iVar4;
    int64_t iVar5;
    uint32_t uVar6;
    uint64_t uVar7;
    char *pcVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t var_20h;
    int64_t var_78h;
    int32_t var_68h;
    int64_t var_64h;
    int64_t var_58h;
    int32_t var_50h;
    undefined4 var_4ch;
    int64_t var_48h;
    undefined8 var_40h;
    int64_t var_38h;
    
    var_20h._0_1_ = '\0';
    var_64h._0_4_ = 0;
    stack0xffffffffffffffb9 = SUB1615(ZEXT816(0), 1);
    var_48h._0_1_ = 0xff;
    var_64h._4_4_ = 0;
    var_68h = 0;
    _var_58h = ZEXT816(0);
    var_38h._0_4_ = 0;
    for (; (*(char *)arg4 == ' ' || (*(char *)arg4 == '\t')); arg4 = arg4 + 1) {
    }
    iVar9 = 8;
    iVar4 = func_0x000180498f90(arg4, 0x180645188, 8);
    if (iVar4 == 0) {
        for (pcVar8 = (char *)(arg4 + 8); (*pcVar8 == ' ' || (*pcVar8 == '\t')); pcVar8 = pcVar8 + 1) {
        }
    } else {
        iVar4 = func_0x000180498f90(arg4, 0x180645100, 9);
        if (iVar4 != 0) {
            return;
        }
        for (pcVar8 = (char *)(arg4 + 9); (*pcVar8 == ' ' || (*pcVar8 == '\t')); pcVar8 = pcVar8 + 1) {
        }
        var_48h = SUB168(_var_48h, 0) | 0x40000000000;
    }
    iVar4 = func_0x0001800f3a40(pcVar8, 0x180645198, &var_58h, &var_68h);
    if (iVar4 != 1) {
        return;
    }
    pcVar8 = pcVar8 + var_68h;
    iVar4 = func_0x0001800f3a40(pcVar8, 0x1806451a8, (int64_t)&var_58h + 4, &var_68h);
    if (iVar4 == 1) {
        if (var_58h._4_4_ == 0) {
            return;
        }
        pcVar8 = pcVar8 + var_68h;
    }
    iVar4 = func_0x0001800f3a40(pcVar8, 0x1806451c0, &var_50h, &var_68h);
    if (iVar4 == 1) {
        if (var_50h == 0) {
            return;
        }
        pcVar8 = pcVar8 + var_68h;
    }
    if (var_58h._4_4_ == 0) {
        iVar4 = func_0x0001800f3a40(pcVar8, 0x180645140, &var_64h, (int64_t)&var_64h + 4, &var_68h);
        auVar3 = _var_48h;
        if (iVar4 != 2) {
            return;
        }
        iVar5 = (int64_t)var_68h;
        var_40h._2_2_ = var_64h._4_2_;
        var_48h = auVar3._0_8_;
        var_40h._0_2_ = (undefined2)var_64h;
        iVar4 = func_0x0001800f3a40(pcVar8 + iVar5, 0x180645150, &var_64h, (int64_t)&var_64h + 4, &var_68h);
        if (iVar4 != 2) {
            return;
        }
        pcVar8 = pcVar8 + iVar5 + var_68h;
        var_40h._4_2_ = (undefined2)var_64h;
        var_40h._6_2_ = var_64h._4_2_;
    } else {
        iVar4 = func_0x0001800f3a40(pcVar8, 0x180645160, &var_64h, (int64_t)&var_64h + 4, &var_68h);
        if (iVar4 == 2) {
            pcVar8 = pcVar8 + var_68h;
            var_38h._0_4_ = CONCAT22(var_64h._4_2_, (int16_t)(int32_t)var_64h);
        }
    }
    iVar4 = func_0x0001800f3a40(pcVar8, 0x180645178, &var_20h, &var_68h, &var_68h);
    if (iVar4 == 1) {
        pcVar8 = pcVar8 + var_68h;
        if ((char)var_20h == 'X') {
            auVar3[15] = 0;
            auVar3._0_15_ = stack0xffffffffffffffb9;
            _var_48h = auVar3 << 8;
        } else {
            if ((char)var_20h == 'Y') {
                var_48h._0_1_ = 1;
            }
        }
    }
    iVar4 = func_0x0001800f3a40(pcVar8, 0x180645238, &var_64h, &var_68h, &var_68h);
    if ((iVar4 == 1) && (pcVar8 = pcVar8 + var_68h, (int32_t)var_64h != 0)) {
        var_48h = SUB168(_var_48h, 0) | 0x2000000000;
    }
    iVar4 = func_0x0001800f3a40(pcVar8, 0x180645248, &var_64h, &var_68h, &var_68h);
    if ((iVar4 == 1) && (pcVar8 = pcVar8 + var_68h, (int32_t)var_64h != 0)) {
        var_48h = SUB168(_var_48h, 0) | 0x80000000000;
    }
    iVar4 = func_0x0001800f3a40(pcVar8, 0x180645260, &var_64h, &var_68h);
    if ((iVar4 == 1) && (pcVar8 = pcVar8 + var_68h, (int32_t)var_64h != 0)) {
        var_48h = SUB168(_var_48h, 0) | 0x100000000000;
    }
    iVar4 = func_0x0001800f3a40(pcVar8, 0x180645270, &var_64h, &var_68h);
    if ((iVar4 == 1) && (pcVar8 = pcVar8 + var_68h, (int32_t)var_64h != 0)) {
        var_48h = SUB168(_var_48h, 0) | 0x200000000000;
    }
    iVar4 = func_0x0001800f3a40(pcVar8, 0x1806451d8, &var_64h, &var_68h);
    if ((iVar4 == 1) && (pcVar8 = pcVar8 + var_68h, (int32_t)var_64h != 0)) {
        var_48h = SUB168(_var_48h, 0) | 0x400000000000;
    }
    iVar4 = func_0x0001800f3a40(pcVar8, 0x1806451f8, &var_64h, &var_68h);
    if ((iVar4 == 1) && (pcVar8 = pcVar8 + var_68h, (int32_t)var_64h != 0)) {
        var_48h = SUB168(_var_48h, 0) | 0x800000000000;
    }
    func_0x0001800f3a40(pcVar8, 0x180645210, &var_4ch, &var_68h);
    if ((var_58h._4_4_ != 0) && (0 < *(int32_t *)(arg1 + 0x2908))) {
        uVar7 = 0;
        do {
            if (*(int32_t *)(*(int64_t *)(arg1 + 0x2910) + uVar7 * 0x24) == var_58h._4_4_) {
                var_48h._0_2_ =
                     CONCAT11(*(char *)(*(int64_t *)(arg1 + 0x2910) + uVar7 * 0x24 + 0x11) + '\x01', (undefined)var_48h)
                ;
                break;
            }
            uVar6 = (int32_t)uVar7 + 1;
            uVar7 = (uint64_t)uVar6;
        } while ((int32_t)uVar6 < *(int32_t *)(arg1 + 0x2908));
    }
    piVar1 = (int32_t *)(arg1 + 0x2908);
    iVar4 = *(int32_t *)(arg1 + 0x290c);
    if (*piVar1 == iVar4) {
        iVar10 = *piVar1 + 1;
        if (iVar4 != 0) {
            iVar9 = iVar4 + iVar4 / 2;
        }
        if (iVar10 < iVar9) {
            iVar10 = iVar9;
        }
        func_0x00018011f420(piVar1, iVar10);
    }
    iVar9 = *piVar1;
    iVar5 = *(int64_t *)(arg1 + 0x2910);
    puVar2 = (undefined4 *)(iVar5 + (int64_t)iVar9 * 0x24);
    *puVar2 = (undefined4)var_58h;
    puVar2[1] = var_58h._4_4_;
    puVar2[2] = var_50h;
    puVar2[3] = var_4ch;
    iVar5 = iVar5 + (int64_t)iVar9 * 0x24;
    *(undefined4 *)(iVar5 + 0x10) = (undefined4)var_48h;
    *(undefined4 *)(iVar5 + 0x14) = var_48h._4_4_;
    *(undefined4 *)(iVar5 + 0x18) = (undefined4)var_40h;
    *(undefined4 *)(iVar5 + 0x1c) = var_40h._4_4_;
    *(undefined4 *)(iVar5 + 0x20) = (undefined4)var_38h;
    *piVar1 = *piVar1 + 1;
    return;
}

// ============================================================
// Function: FUN_18011e310
// Address: 0x18011e310
// Size: 364 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_3eh
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_3ah
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_36h
// WARNING: [rz-ghidra] Detected overlap for variable arg_28h

void fcn.18011e310(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 *puVar1;
    uint32_t *puVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    undefined uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    uint32_t uVar12;
    int64_t iVar13;
    int32_t iVar14;
    int64_t iVar15;
    int32_t iVar16;
    uint64_t uVar17;
    int64_t var_24h;
    int64_t var_58h;
    undefined4 var_50h;
    undefined var_48h [2];
    int64_t var_46h;
    
    uVar17 = arg3 & 0xffffffff;
    while( true ) {
        uVar10 = *(undefined4 *)arg2;
        if (*(undefined4 **)(arg2 + 0x18) == (undefined4 *)0x0) {
            var_58h._4_4_ = 0;
        } else {
            var_58h._4_4_ = **(undefined4 **)(arg2 + 0x18);
        }
        if ((((*(uint32_t *)(arg2 + 0x10) & 0x400) == 0) || (*(int64_t *)(arg2 + 0x98) == 0)) ||
           (iVar13 = *(int64_t *)(*(int64_t *)(arg2 + 0x98) + 0x408), iVar13 == 0)) {
            var_50h = 0;
        } else {
            var_50h = *(undefined4 *)(iVar13 + 0x10);
        }
        uVar11 = *(undefined4 *)(arg2 + 0xcc);
        if (*(int64_t *)(arg2 + 0x20) == 0) {
            uVar9 = 0xff;
        } else {
            uVar9 = *(undefined *)(arg2 + 0x60);
        }
        uVar12 = *(uint32_t *)(arg2 + 8);
        iVar14 = *(int32_t *)(arg1 + 0x24);
        _var_48h = ZEXT24((undefined  [2])CONCAT11((char)uVar17, uVar9));
        fVar3 = *(float *)(arg2 + 0x48);
        fVar4 = *(float *)(arg2 + 0x4c);
        fVar5 = *(float *)(arg2 + 0x50);
        fVar6 = *(float *)(arg2 + 0x54);
        fVar7 = *(float *)(arg2 + 0x58);
        fVar8 = *(float *)(arg2 + 0x5c);
        if (*(int32_t *)(arg1 + 0x20) == iVar14) {
            iVar16 = *(int32_t *)(arg1 + 0x20) + 1;
            if (iVar14 == 0) {
                iVar14 = 8;
            } else {
                iVar14 = iVar14 / 2 + iVar14;
            }
            if (iVar16 < iVar14) {
                iVar16 = iVar14;
            }
            func_0x00018011f420(arg1 + 0x20, iVar16);
        }
        iVar15 = (int64_t)*(int32_t *)(arg1 + 0x20);
        iVar13 = *(int64_t *)(arg1 + 0x28);
        puVar1 = (undefined4 *)(iVar13 + iVar15 * 0x24);
        *puVar1 = uVar10;
        puVar1[1] = var_58h._4_4_;
        puVar1[2] = var_50h;
        puVar1[3] = uVar11;
        puVar2 = (uint32_t *)(iVar13 + 0x10 + iVar15 * 0x24);
        *puVar2 = _var_48h;
        puVar2[1] = uVar12 & 0x3fc20;
        puVar2[2] = CONCAT22((int16_t)(int32_t)fVar4, (int16_t)(int32_t)fVar3);
        puVar2[3] = CONCAT22((int16_t)(int32_t)fVar6, (int16_t)(int32_t)fVar5);
        *(uint32_t *)(iVar13 + 0x20 + iVar15 * 0x24) = CONCAT22((int16_t)(int32_t)fVar8, (int16_t)(int32_t)fVar7);
        *(int32_t *)(arg1 + 0x20) = *(int32_t *)(arg1 + 0x20) + 1;
        if (*(int64_t *)(arg2 + 0x20) != 0) {
            fcn.18011e310(arg1, *(int64_t *)(arg2 + 0x20), (uint64_t)((int32_t)uVar17 + 1));
        }
        arg2 = *(undefined8 *)(arg2 + 0x28);
        if ((undefined4 *)arg2 == (undefined4 *)0x0) break;
        uVar17 = (uint64_t)((int32_t)uVar17 + 1);
    }
    return;
}

// ============================================================
// Function: FUN_18011e480
// Address: 0x18011e480
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Removing arg arg_bah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2958h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2950h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_3eh
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_3ah
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_36h
// WARNING: [rz-ghidra] Detected overlap for variable arg_28h

void fcn.18011e480(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_78h, int64_t arg_88h)
{
    int32_t *arg1_00;
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    uint64_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    if ((*(uint8_t *)(arg1 + 0x30) & 0x80) != 0) {
        arg1_00 = (int32_t *)(arg1 + 0x28e8);
        iVar5 = *(int32_t *)(arg1 + 0x290c);
        if (iVar5 < 0) {
            iVar5 = iVar5 / 2 + iVar5;
            iVar2 = 0;
            if (0 < iVar5) {
                iVar2 = iVar5;
            }
            func_0x00018011f420(arg1 + 0x2908, iVar2);
        }
        *(undefined4 *)(arg1 + 0x2908) = 0;
        func_0x00018011f420(arg1 + 0x2908);
        iVar5 = 0;
        if (0 < *arg1_00) {
            do {
                iVar4 = *(int64_t *)(*(int64_t *)(arg1 + 0x28f0) + 8 + (int64_t)iVar5 * 0x10);
                if ((iVar4 != 0) && (*(int64_t *)(iVar4 + 0x18) == 0)) {
                    fcn.18011e310((int64_t)arg1_00, iVar4, 0);
                }
                iVar5 = iVar5 + 1;
            } while (iVar5 < *arg1_00);
        }
        iVar5 = 0;
        if (0 < *(int32_t *)(arg1 + 0x2908)) {
            uVar8 = 0;
            do {
                iVar2 = (int32_t)*(char *)(*(int64_t *)(arg1 + 0x2910) + 0x11 + uVar8 * 0x24);
                if (iVar5 <= iVar2) {
                    iVar5 = iVar2;
                }
                uVar7 = (int32_t)uVar8 + 1;
                uVar8 = (uint64_t)uVar7;
            } while ((int32_t)uVar7 < *(int32_t *)(arg1 + 0x2908));
        }
        func_0x0001800f65a0(arg3, 0x180645228, *(undefined8 *)arg2);
        iVar2 = 0;
        if (0 < *(int32_t *)(arg1 + 0x2908)) {
            do {
                iVar6 = *(int32_t *)arg3 + -1;
                if (*(int32_t *)arg3 == 0) {
                    iVar6 = 0;
                }
                iVar9 = (int32_t)*(char *)(*(int64_t *)(arg1 + 0x2910) + 0x11 + (int64_t)iVar2 * 0x24);
                piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x2910) + (int64_t)iVar2 * 0x24);
                uVar3 = 0x1806452d0;
                if ((piVar1[5] & 0x400U) != 0) {
                    uVar3 = 0x180645100;
                }
                func_0x0001800f65a0(arg3, 0x1806452e0, iVar9 * 2, 0x1805aadb1, uVar3, iVar5 * 2 + iVar9 * -2, 
                                    0x1805aadb1);
                func_0x0001800f65a0();
                if (piVar1[1] == 0) {
                    if (piVar1[2] != 0) {
                        func_0x0001800f65a0();
                    }
                    var_48h = CONCAT44((int32_t)((uint64_t)uVar3 >> 0x20), (int32_t)*(int16_t *)(piVar1 + 7));
                    func_0x0001800f65a0(arg3, 0x180645298, (int32_t)*(int16_t *)(piVar1 + 6), 
                                        (int32_t)*(int16_t *)((int64_t)piVar1 + 0x1a), var_48h, 
                                        (int32_t)*(int16_t *)((int64_t)piVar1 + 0x1e), 0x1805aadb1);
                } else {
                    func_0x0001800f65a0();
                }
                if (*(char *)(piVar1 + 4) != -1) {
                    func_0x0001800f65a0(arg3, 0x1806452b0, (*(char *)(piVar1 + 4) != '\0') + 'X');
                }
                if ((*(uint8_t *)(piVar1 + 5) & 0x20) != 0) {
                    func_0x0001800f65a0(arg3, 0x1806452c0);
                }
                if ((piVar1[5] & 0x800U) != 0) {
                    func_0x0001800f65a0(arg3, 0x180645360);
                }
                if ((piVar1[5] & 0x1000U) != 0) {
                    func_0x0001800f65a0(arg3, 0x180645370);
                }
                if ((piVar1[5] & 0x2000U) != 0) {
                    func_0x0001800f65a0(arg3, 0x180645380);
                }
                if ((piVar1[5] & 0x4000U) != 0) {
                    func_0x0001800f65a0(arg3, 0x180645390);
                }
                if ((piVar1[5] & 0x8000U) != 0) {
                    func_0x0001800f65a0(arg3, 0x180645320);
                }
                if (piVar1[3] != 0) {
                    func_0x0001800f65a0(arg3, 0x180645338);
                }
                if ((*(char *)(arg1 + 0xba) != '\0') && (iVar4 = func_0x0001800f60f0(arg1_00, *piVar1), iVar4 != 0)) {
                    iVar9 = *(int32_t *)arg3 + -1;
                    if (*(int32_t *)arg3 == 0) {
                        iVar9 = 0;
                    }
                    iVar6 = (iVar6 - iVar9) + 0x5c;
                    if (iVar6 < 3) {
                        iVar6 = 2;
                    }
                    iVar4 = func_0x0001800f65a0(arg3, 0x18064534c, iVar6);
                    if ((((*(uint32_t *)(iVar4 + 0x10) & 0x400) != 0) && (*(int64_t *)(iVar4 + 0x98) != 0)) &&
                       (iVar4 = *(int64_t *)(*(int64_t *)(iVar4 + 0x98) + 0x408), iVar4 != 0)) {
                        func_0x0001800f65a0(arg3, 0x180645350, *(undefined8 *)(iVar4 + 8));
                    }
                    uVar8 = 0;
                    iVar4 = 0;
                    if (*(int64_t *)(arg1 + 0x2958) != 0) {
                        iVar4 = *(int64_t *)(arg1 + 0x2958) + 4;
                    }
                    while (iVar4 != 0) {
                        if (*(int32_t *)(iVar4 + 0x14) == *piVar1) {
                            iVar6 = (int32_t)uVar8;
                            uVar8 = (uint64_t)(iVar6 + 1);
                            if (iVar6 == 0) {
                                iVar4 = func_0x0001800f65a0(arg3, 0x1806453a8);
                            }
                            iVar4 = func_0x0001800f65a0(arg3, 0x1806453b8, iVar4 + 0x24);
                        }
                        iVar10 = *(int32_t *)(iVar4 + -4) + iVar4;
                        iVar4 = 0;
                        if (iVar10 != *(int64_t *)(arg1 + 0x2958) + 4 + (int64_t)*(int32_t *)(arg1 + 0x2950)) {
                            iVar4 = iVar10;
                        }
                    }
                }
                func_0x0001800f65a0(arg3, 0x1805ab2a0);
                iVar2 = iVar2 + 1;
            } while (iVar2 < *(int32_t *)(arg1 + 0x2908));
        }
        func_0x0001800f65a0(arg3, 0x1805ab2a0);
    }
    return;
}

// ============================================================
// Function: FUN_18011e49c
// Address: 0x18011e49c
// Size: 219 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Removing arg arg_bah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2958h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2950h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_3eh
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_3ah
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_36h
// WARNING: [rz-ghidra] Detected overlap for variable arg_28h

void fcn.18011e480(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_78h, int64_t arg_88h)
{
    int32_t *arg1_00;
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    uint64_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    if ((*(uint8_t *)(arg1 + 0x30) & 0x80) != 0) {
        arg1_00 = (int32_t *)(arg1 + 0x28e8);
        iVar5 = *(int32_t *)(arg1 + 0x290c);
        if (iVar5 < 0) {
            iVar5 = iVar5 / 2 + iVar5;
            iVar2 = 0;
            if (0 < iVar5) {
                iVar2 = iVar5;
            }
            func_0x00018011f420(arg1 + 0x2908, iVar2);
        }
        *(undefined4 *)(arg1 + 0x2908) = 0;
        func_0x00018011f420(arg1 + 0x2908);
        iVar5 = 0;
        if (0 < *arg1_00) {
            do {
                iVar4 = *(int64_t *)(*(int64_t *)(arg1 + 0x28f0) + 8 + (int64_t)iVar5 * 0x10);
                if ((iVar4 != 0) && (*(int64_t *)(iVar4 + 0x18) == 0)) {
                    fcn.18011e310((int64_t)arg1_00, iVar4, 0);
                }
                iVar5 = iVar5 + 1;
            } while (iVar5 < *arg1_00);
        }
        iVar5 = 0;
        if (0 < *(int32_t *)(arg1 + 0x2908)) {
            uVar8 = 0;
            do {
                iVar2 = (int32_t)*(char *)(*(int64_t *)(arg1 + 0x2910) + 0x11 + uVar8 * 0x24);
                if (iVar5 <= iVar2) {
                    iVar5 = iVar2;
                }
                uVar7 = (int32_t)uVar8 + 1;
                uVar8 = (uint64_t)uVar7;
            } while ((int32_t)uVar7 < *(int32_t *)(arg1 + 0x2908));
        }
        func_0x0001800f65a0(arg3, 0x180645228, *(undefined8 *)arg2);
        iVar2 = 0;
        if (0 < *(int32_t *)(arg1 + 0x2908)) {
            do {
                iVar6 = *(int32_t *)arg3 + -1;
                if (*(int32_t *)arg3 == 0) {
                    iVar6 = 0;
                }
                iVar9 = (int32_t)*(char *)(*(int64_t *)(arg1 + 0x2910) + 0x11 + (int64_t)iVar2 * 0x24);
                piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x2910) + (int64_t)iVar2 * 0x24);
                uVar3 = 0x1806452d0;
                if ((piVar1[5] & 0x400U) != 0) {
                    uVar3 = 0x180645100;
                }
                func_0x0001800f65a0(arg3, 0x1806452e0, iVar9 * 2, 0x1805aadb1, uVar3, iVar5 * 2 + iVar9 * -2, 
                                    0x1805aadb1);
                func_0x0001800f65a0();
                if (piVar1[1] == 0) {
                    if (piVar1[2] != 0) {
                        func_0x0001800f65a0();
                    }
                    var_48h = CONCAT44((int32_t)((uint64_t)uVar3 >> 0x20), (int32_t)*(int16_t *)(piVar1 + 7));
                    func_0x0001800f65a0(arg3, 0x180645298, (int32_t)*(int16_t *)(piVar1 + 6), 
                                        (int32_t)*(int16_t *)((int64_t)piVar1 + 0x1a), var_48h, 
                                        (int32_t)*(int16_t *)((int64_t)piVar1 + 0x1e), 0x1805aadb1);
                } else {
                    func_0x0001800f65a0();
                }
                if (*(char *)(piVar1 + 4) != -1) {
                    func_0x0001800f65a0(arg3, 0x1806452b0, (*(char *)(piVar1 + 4) != '\0') + 'X');
                }
                if ((*(uint8_t *)(piVar1 + 5) & 0x20) != 0) {
                    func_0x0001800f65a0(arg3, 0x1806452c0);
                }
                if ((piVar1[5] & 0x800U) != 0) {
                    func_0x0001800f65a0(arg3, 0x180645360);
                }
                if ((piVar1[5] & 0x1000U) != 0) {
                    func_0x0001800f65a0(arg3, 0x180645370);
                }
                if ((piVar1[5] & 0x2000U) != 0) {
                    func_0x0001800f65a0(arg3, 0x180645380);
                }
                if ((piVar1[5] & 0x4000U) != 0) {
                    func_0x0001800f65a0(arg3, 0x180645390);
                }
                if ((piVar1[5] & 0x8000U) != 0) {
                    func_0x0001800f65a0(arg3, 0x180645320);
                }
                if (piVar1[3] != 0) {
                    func_0x0001800f65a0(arg3, 0x180645338);
                }
                if ((*(char *)(arg1 + 0xba) != '\0') && (iVar4 = func_0x0001800f60f0(arg1_00, *piVar1), iVar4 != 0)) {
                    iVar9 = *(int32_t *)arg3 + -1;
                    if (*(int32_t *)arg3 == 0) {
                        iVar9 = 0;
                    }
                    iVar6 = (iVar6 - iVar9) + 0x5c;
                    if (iVar6 < 3) {
                        iVar6 = 2;
                    }
                    iVar4 = func_0x0001800f65a0(arg3, 0x18064534c, iVar6);
                    if ((((*(uint32_t *)(iVar4 + 0x10) & 0x400) != 0) && (*(int64_t *)(iVar4 + 0x98) != 0)) &&
                       (iVar4 = *(int64_t *)(*(int64_t *)(iVar4 + 0x98) + 0x408), iVar4 != 0)) {
                        func_0x0001800f65a0(arg3, 0x180645350, *(undefined8 *)(iVar4 + 8));
                    }
                    uVar8 = 0;
                    iVar4 = 0;
                    if (*(int64_t *)(arg1 + 0x2958) != 0) {
                        iVar4 = *(int64_t *)(arg1 + 0x2958) + 4;
                    }
                    while (iVar4 != 0) {
                        if (*(int32_t *)(iVar4 + 0x14) == *piVar1) {
                            iVar6 = (int32_t)uVar8;
                            uVar8 = (uint64_t)(iVar6 + 1);
                            if (iVar6 == 0) {
                                iVar4 = func_0x0001800f65a0(arg3, 0x1806453a8);
                            }
                            iVar4 = func_0x0001800f65a0(arg3, 0x1806453b8, iVar4 + 0x24);
                        }
                        iVar10 = *(int32_t *)(iVar4 + -4) + iVar4;
                        iVar4 = 0;
                        if (iVar10 != *(int64_t *)(arg1 + 0x2958) + 4 + (int64_t)*(int32_t *)(arg1 + 0x2950)) {
                            iVar4 = iVar10;
                        }
                    }
                }
                func_0x0001800f65a0(arg3, 0x1805ab2a0);
                iVar2 = iVar2 + 1;
            } while (iVar2 < *(int32_t *)(arg1 + 0x2908));
        }
        func_0x0001800f65a0(arg3, 0x1805ab2a0);
    }
    return;
}

// ============================================================
// Function: FUN_18011e577
// Address: 0x18011e577
// Size: 758 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Removing arg arg_bah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2958h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2950h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_3eh
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_3ah
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_36h
// WARNING: [rz-ghidra] Detected overlap for variable arg_28h

void fcn.18011e480(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_78h, int64_t arg_88h)
{
    int32_t *arg1_00;
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    uint64_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    if ((*(uint8_t *)(arg1 + 0x30) & 0x80) != 0) {
        arg1_00 = (int32_t *)(arg1 + 0x28e8);
        iVar5 = *(int32_t *)(arg1 + 0x290c);
        if (iVar5 < 0) {
            iVar5 = iVar5 / 2 + iVar5;
            iVar2 = 0;
            if (0 < iVar5) {
                iVar2 = iVar5;
            }
            func_0x00018011f420(arg1 + 0x2908, iVar2);
        }
        *(undefined4 *)(arg1 + 0x2908) = 0;
        func_0x00018011f420(arg1 + 0x2908);
        iVar5 = 0;
        if (0 < *arg1_00) {
            do {
                iVar4 = *(int64_t *)(*(int64_t *)(arg1 + 0x28f0) + 8 + (int64_t)iVar5 * 0x10);
                if ((iVar4 != 0) && (*(int64_t *)(iVar4 + 0x18) == 0)) {
                    fcn.18011e310((int64_t)arg1_00, iVar4, 0);
                }
                iVar5 = iVar5 + 1;
            } while (iVar5 < *arg1_00);
        }
        iVar5 = 0;
        if (0 < *(int32_t *)(arg1 + 0x2908)) {
            uVar8 = 0;
            do {
                iVar2 = (int32_t)*(char *)(*(int64_t *)(arg1 + 0x2910) + 0x11 + uVar8 * 0x24);
                if (iVar5 <= iVar2) {
                    iVar5 = iVar2;
                }
                uVar7 = (int32_t)uVar8 + 1;
                uVar8 = (uint64_t)uVar7;
            } while ((int32_t)uVar7 < *(int32_t *)(arg1 + 0x2908));
        }
        func_0x0001800f65a0(arg3, 0x180645228, *(undefined8 *)arg2);
        iVar2 = 0;
        if (0 < *(int32_t *)(arg1 + 0x2908)) {
            do {
                iVar6 = *(int32_t *)arg3 + -1;
                if (*(int32_t *)arg3 == 0) {
                    iVar6 = 0;
                }
                iVar9 = (int32_t)*(char *)(*(int64_t *)(arg1 + 0x2910) + 0x11 + (int64_t)iVar2 * 0x24);
                piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x2910) + (int64_t)iVar2 * 0x24);
                uVar3 = 0x1806452d0;
                if ((piVar1[5] & 0x400U) != 0) {
                    uVar3 = 0x180645100;
                }
                func_0x0001800f65a0(arg3, 0x1806452e0, iVar9 * 2, 0x1805aadb1, uVar3, iVar5 * 2 + iVar9 * -2, 
                                    0x1805aadb1);
                func_0x0001800f65a0();
                if (piVar1[1] == 0) {
                    if (piVar1[2] != 0) {
                        func_0x0001800f65a0();
                    }
                    var_48h = CONCAT44((int32_t)((uint64_t)uVar3 >> 0x20), (int32_t)*(int16_t *)(piVar1 + 7));
                    func_0x0001800f65a0(arg3, 0x180645298, (int32_t)*(int16_t *)(piVar1 + 6), 
                                        (int32_t)*(int16_t *)((int64_t)piVar1 + 0x1a), var_48h, 
                                        (int32_t)*(int16_t *)((int64_t)piVar1 + 0x1e), 0x1805aadb1);
                } else {
                    func_0x0001800f65a0();
                }
                if (*(char *)(piVar1 + 4) != -1) {
                    func_0x0001800f65a0(arg3, 0x1806452b0, (*(char *)(piVar1 + 4) != '\0') + 'X');
                }
                if ((*(uint8_t *)(piVar1 + 5) & 0x20) != 0) {
                    func_0x0001800f65a0(arg3, 0x1806452c0);
                }
                if ((piVar1[5] & 0x800U) != 0) {
                    func_0x0001800f65a0(arg3, 0x180645360);
                }
                if ((piVar1[5] & 0x1000U) != 0) {
                    func_0x0001800f65a0(arg3, 0x180645370);
                }
                if ((piVar1[5] & 0x2000U) != 0) {
                    func_0x0001800f65a0(arg3, 0x180645380);
                }
                if ((piVar1[5] & 0x4000U) != 0) {
                    func_0x0001800f65a0(arg3, 0x180645390);
                }
                if ((piVar1[5] & 0x8000U) != 0) {
                    func_0x0001800f65a0(arg3, 0x180645320);
                }
                if (piVar1[3] != 0) {
                    func_0x0001800f65a0(arg3, 0x180645338);
                }
                if ((*(char *)(arg1 + 0xba) != '\0') && (iVar4 = func_0x0001800f60f0(arg1_00, *piVar1), iVar4 != 0)) {
                    iVar9 = *(int32_t *)arg3 + -1;
                    if (*(int32_t *)arg3 == 0) {
                        iVar9 = 0;
                    }
                    iVar6 = (iVar6 - iVar9) + 0x5c;
                    if (iVar6 < 3) {
                        iVar6 = 2;
                    }
                    iVar4 = func_0x0001800f65a0(arg3, 0x18064534c, iVar6);
                    if ((((*(uint32_t *)(iVar4 + 0x10) & 0x400) != 0) && (*(int64_t *)(iVar4 + 0x98) != 0)) &&
                       (iVar4 = *(int64_t *)(*(int64_t *)(iVar4 + 0x98) + 0x408), iVar4 != 0)) {
                        func_0x0001800f65a0(arg3, 0x180645350, *(undefined8 *)(iVar4 + 8));
                    }
                    uVar8 = 0;
                    iVar4 = 0;
                    if (*(int64_t *)(arg1 + 0x2958) != 0) {
                        iVar4 = *(int64_t *)(arg1 + 0x2958) + 4;
                    }
                    while (iVar4 != 0) {
                        if (*(int32_t *)(iVar4 + 0x14) == *piVar1) {
                            iVar6 = (int32_t)uVar8;
                            uVar8 = (uint64_t)(iVar6 + 1);
                            if (iVar6 == 0) {
                                iVar4 = func_0x0001800f65a0(arg3, 0x1806453a8);
                            }
                            iVar4 = func_0x0001800f65a0(arg3, 0x1806453b8, iVar4 + 0x24);
                        }
                        iVar10 = *(int32_t *)(iVar4 + -4) + iVar4;
                        iVar4 = 0;
                        if (iVar10 != *(int64_t *)(arg1 + 0x2958) + 4 + (int64_t)*(int32_t *)(arg1 + 0x2950)) {
                            iVar4 = iVar10;
                        }
                    }
                }
                func_0x0001800f65a0(arg3, 0x1805ab2a0);
                iVar2 = iVar2 + 1;
            } while (iVar2 < *(int32_t *)(arg1 + 0x2908));
        }
        func_0x0001800f65a0(arg3, 0x1805ab2a0);
    }
    return;
}

// ============================================================
// Function: FUN_18011e86d
// Address: 0x18011e86d
// Size: 30 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Removing arg arg_bah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2958h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2950h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_3eh
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_3ah
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_36h
// WARNING: [rz-ghidra] Detected overlap for variable arg_28h

void fcn.18011e480(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_78h, int64_t arg_88h)
{
    int32_t *arg1_00;
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    uint64_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    if ((*(uint8_t *)(arg1 + 0x30) & 0x80) != 0) {
        arg1_00 = (int32_t *)(arg1 + 0x28e8);
        iVar5 = *(int32_t *)(arg1 + 0x290c);
        if (iVar5 < 0) {
            iVar5 = iVar5 / 2 + iVar5;
            iVar2 = 0;
            if (0 < iVar5) {
                iVar2 = iVar5;
            }
            func_0x00018011f420(arg1 + 0x2908, iVar2);
        }
        *(undefined4 *)(arg1 + 0x2908) = 0;
        func_0x00018011f420(arg1 + 0x2908);
        iVar5 = 0;
        if (0 < *arg1_00) {
            do {
                iVar4 = *(int64_t *)(*(int64_t *)(arg1 + 0x28f0) + 8 + (int64_t)iVar5 * 0x10);
                if ((iVar4 != 0) && (*(int64_t *)(iVar4 + 0x18) == 0)) {
                    fcn.18011e310((int64_t)arg1_00, iVar4, 0);
                }
                iVar5 = iVar5 + 1;
            } while (iVar5 < *arg1_00);
        }
        iVar5 = 0;
        if (0 < *(int32_t *)(arg1 + 0x2908)) {
            uVar8 = 0;
            do {
                iVar2 = (int32_t)*(char *)(*(int64_t *)(arg1 + 0x2910) + 0x11 + uVar8 * 0x24);
                if (iVar5 <= iVar2) {
                    iVar5 = iVar2;
                }
                uVar7 = (int32_t)uVar8 + 1;
                uVar8 = (uint64_t)uVar7;
            } while ((int32_t)uVar7 < *(int32_t *)(arg1 + 0x2908));
        }
        func_0x0001800f65a0(arg3, 0x180645228, *(undefined8 *)arg2);
        iVar2 = 0;
        if (0 < *(int32_t *)(arg1 + 0x2908)) {
            do {
                iVar6 = *(int32_t *)arg3 + -1;
                if (*(int32_t *)arg3 == 0) {
                    iVar6 = 0;
                }
                iVar9 = (int32_t)*(char *)(*(int64_t *)(arg1 + 0x2910) + 0x11 + (int64_t)iVar2 * 0x24);
                piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x2910) + (int64_t)iVar2 * 0x24);
                uVar3 = 0x1806452d0;
                if ((piVar1[5] & 0x400U) != 0) {
                    uVar3 = 0x180645100;
                }
                func_0x0001800f65a0(arg3, 0x1806452e0, iVar9 * 2, 0x1805aadb1, uVar3, iVar5 * 2 + iVar9 * -2, 
                                    0x1805aadb1);
                func_0x0001800f65a0();
                if (piVar1[1] == 0) {
                    if (piVar1[2] != 0) {
                        func_0x0001800f65a0();
                    }
                    var_48h = CONCAT44((int32_t)((uint64_t)uVar3 >> 0x20), (int32_t)*(int16_t *)(piVar1 + 7));
                    func_0x0001800f65a0(arg3, 0x180645298, (int32_t)*(int16_t *)(piVar1 + 6), 
                                        (int32_t)*(int16_t *)((int64_t)piVar1 + 0x1a), var_48h, 
                                        (int32_t)*(int16_t *)((int64_t)piVar1 + 0x1e), 0x1805aadb1);
                } else {
                    func_0x0001800f65a0();
                }
                if (*(char *)(piVar1 + 4) != -1) {
                    func_0x0001800f65a0(arg3, 0x1806452b0, (*(char *)(piVar1 + 4) != '\0') + 'X');
                }
                if ((*(uint8_t *)(piVar1 + 5) & 0x20) != 0) {
                    func_0x0001800f65a0(arg3, 0x1806452c0);
                }
                if ((piVar1[5] & 0x800U) != 0) {
                    func_0x0001800f65a0(arg3, 0x180645360);
                }
                if ((piVar1[5] & 0x1000U) != 0) {
                    func_0x0001800f65a0(arg3, 0x180645370);
                }
                if ((piVar1[5] & 0x2000U) != 0) {
                    func_0x0001800f65a0(arg3, 0x180645380);
                }
                if ((piVar1[5] & 0x4000U) != 0) {
                    func_0x0001800f65a0(arg3, 0x180645390);
                }
                if ((piVar1[5] & 0x8000U) != 0) {
                    func_0x0001800f65a0(arg3, 0x180645320);
                }
                if (piVar1[3] != 0) {
                    func_0x0001800f65a0(arg3, 0x180645338);
                }
                if ((*(char *)(arg1 + 0xba) != '\0') && (iVar4 = func_0x0001800f60f0(arg1_00, *piVar1), iVar4 != 0)) {
                    iVar9 = *(int32_t *)arg3 + -1;
                    if (*(int32_t *)arg3 == 0) {
                        iVar9 = 0;
                    }
                    iVar6 = (iVar6 - iVar9) + 0x5c;
                    if (iVar6 < 3) {
                        iVar6 = 2;
                    }
                    iVar4 = func_0x0001800f65a0(arg3, 0x18064534c, iVar6);
                    if ((((*(uint32_t *)(iVar4 + 0x10) & 0x400) != 0) && (*(int64_t *)(iVar4 + 0x98) != 0)) &&
                       (iVar4 = *(int64_t *)(*(int64_t *)(iVar4 + 0x98) + 0x408), iVar4 != 0)) {
                        func_0x0001800f65a0(arg3, 0x180645350, *(undefined8 *)(iVar4 + 8));
                    }
                    uVar8 = 0;
                    iVar4 = 0;
                    if (*(int64_t *)(arg1 + 0x2958) != 0) {
                        iVar4 = *(int64_t *)(arg1 + 0x2958) + 4;
                    }
                    while (iVar4 != 0) {
                        if (*(int32_t *)(iVar4 + 0x14) == *piVar1) {
                            iVar6 = (int32_t)uVar8;
                            uVar8 = (uint64_t)(iVar6 + 1);
                            if (iVar6 == 0) {
                                iVar4 = func_0x0001800f65a0(arg3, 0x1806453a8);
                            }
                            iVar4 = func_0x0001800f65a0(arg3, 0x1806453b8, iVar4 + 0x24);
                        }
                        iVar10 = *(int32_t *)(iVar4 + -4) + iVar4;
                        iVar4 = 0;
                        if (iVar10 != *(int64_t *)(arg1 + 0x2958) + 4 + (int64_t)*(int32_t *)(arg1 + 0x2950)) {
                            iVar4 = iVar10;
                        }
                    }
                }
                func_0x0001800f65a0(arg3, 0x1805ab2a0);
                iVar2 = iVar2 + 1;
            } while (iVar2 < *(int32_t *)(arg1 + 0x2908));
        }
        func_0x0001800f65a0(arg3, 0x1805ab2a0);
    }
    return;
}

// ============================================================
// Function: FUN_18011e88b
// Address: 0x18011e88b
// Size: 9 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Removing arg arg_bah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2958h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2950h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_3eh
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_3ah
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_36h
// WARNING: [rz-ghidra] Detected overlap for variable arg_28h

void fcn.18011e480(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_78h, int64_t arg_88h)
{
    int32_t *arg1_00;
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    uint64_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    if ((*(uint8_t *)(arg1 + 0x30) & 0x80) != 0) {
        arg1_00 = (int32_t *)(arg1 + 0x28e8);
        iVar5 = *(int32_t *)(arg1 + 0x290c);
        if (iVar5 < 0) {
            iVar5 = iVar5 / 2 + iVar5;
            iVar2 = 0;
            if (0 < iVar5) {
                iVar2 = iVar5;
            }
            func_0x00018011f420(arg1 + 0x2908, iVar2);
        }
        *(undefined4 *)(arg1 + 0x2908) = 0;
        func_0x00018011f420(arg1 + 0x2908);
        iVar5 = 0;
        if (0 < *arg1_00) {
            do {
                iVar4 = *(int64_t *)(*(int64_t *)(arg1 + 0x28f0) + 8 + (int64_t)iVar5 * 0x10);
                if ((iVar4 != 0) && (*(int64_t *)(iVar4 + 0x18) == 0)) {
                    fcn.18011e310((int64_t)arg1_00, iVar4, 0);
                }
                iVar5 = iVar5 + 1;
            } while (iVar5 < *arg1_00);
        }
        iVar5 = 0;
        if (0 < *(int32_t *)(arg1 + 0x2908)) {
            uVar8 = 0;
            do {
                iVar2 = (int32_t)*(char *)(*(int64_t *)(arg1 + 0x2910) + 0x11 + uVar8 * 0x24);
                if (iVar5 <= iVar2) {
                    iVar5 = iVar2;
                }
                uVar7 = (int32_t)uVar8 + 1;
                uVar8 = (uint64_t)uVar7;
            } while ((int32_t)uVar7 < *(int32_t *)(arg1 + 0x2908));
        }
        func_0x0001800f65a0(arg3, 0x180645228, *(undefined8 *)arg2);
        iVar2 = 0;
        if (0 < *(int32_t *)(arg1 + 0x2908)) {
            do {
                iVar6 = *(int32_t *)arg3 + -1;
                if (*(int32_t *)arg3 == 0) {
                    iVar6 = 0;
                }
                iVar9 = (int32_t)*(char *)(*(int64_t *)(arg1 + 0x2910) + 0x11 + (int64_t)iVar2 * 0x24);
                piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x2910) + (int64_t)iVar2 * 0x24);
                uVar3 = 0x1806452d0;
                if ((piVar1[5] & 0x400U) != 0) {
                    uVar3 = 0x180645100;
                }
                func_0x0001800f65a0(arg3, 0x1806452e0, iVar9 * 2, 0x1805aadb1, uVar3, iVar5 * 2 + iVar9 * -2, 
                                    0x1805aadb1);
                func_0x0001800f65a0();
                if (piVar1[1] == 0) {
                    if (piVar1[2] != 0) {
                        func_0x0001800f65a0();
                    }
                    var_48h = CONCAT44((int32_t)((uint64_t)uVar3 >> 0x20), (int32_t)*(int16_t *)(piVar1 + 7));
                    func_0x0001800f65a0(arg3, 0x180645298, (int32_t)*(int16_t *)(piVar1 + 6), 
                                        (int32_t)*(int16_t *)((int64_t)piVar1 + 0x1a), var_48h, 
                                        (int32_t)*(int16_t *)((int64_t)piVar1 + 0x1e), 0x1805aadb1);
                } else {
                    func_0x0001800f65a0();
                }
                if (*(char *)(piVar1 + 4) != -1) {
                    func_0x0001800f65a0(arg3, 0x1806452b0, (*(char *)(piVar1 + 4) != '\0') + 'X');
                }
                if ((*(uint8_t *)(piVar1 + 5) & 0x20) != 0) {
                    func_0x0001800f65a0(arg3, 0x1806452c0);
                }
                if ((piVar1[5] & 0x800U) != 0) {
                    func_0x0001800f65a0(arg3, 0x180645360);
                }
                if ((piVar1[5] & 0x1000U) != 0) {
                    func_0x0001800f65a0(arg3, 0x180645370);
                }
                if ((piVar1[5] & 0x2000U) != 0) {
                    func_0x0001800f65a0(arg3, 0x180645380);
                }
                if ((piVar1[5] & 0x4000U) != 0) {
                    func_0x0001800f65a0(arg3, 0x180645390);
                }
                if ((piVar1[5] & 0x8000U) != 0) {
                    func_0x0001800f65a0(arg3, 0x180645320);
                }
                if (piVar1[3] != 0) {
                    func_0x0001800f65a0(arg3, 0x180645338);
                }
                if ((*(char *)(arg1 + 0xba) != '\0') && (iVar4 = func_0x0001800f60f0(arg1_00, *piVar1), iVar4 != 0)) {
                    iVar9 = *(int32_t *)arg3 + -1;
                    if (*(int32_t *)arg3 == 0) {
                        iVar9 = 0;
                    }
                    iVar6 = (iVar6 - iVar9) + 0x5c;
                    if (iVar6 < 3) {
                        iVar6 = 2;
                    }
                    iVar4 = func_0x0001800f65a0(arg3, 0x18064534c, iVar6);
                    if ((((*(uint32_t *)(iVar4 + 0x10) & 0x400) != 0) && (*(int64_t *)(iVar4 + 0x98) != 0)) &&
                       (iVar4 = *(int64_t *)(*(int64_t *)(iVar4 + 0x98) + 0x408), iVar4 != 0)) {
                        func_0x0001800f65a0(arg3, 0x180645350, *(undefined8 *)(iVar4 + 8));
                    }
                    uVar8 = 0;
                    iVar4 = 0;
                    if (*(int64_t *)(arg1 + 0x2958) != 0) {
                        iVar4 = *(int64_t *)(arg1 + 0x2958) + 4;
                    }
                    while (iVar4 != 0) {
                        if (*(int32_t *)(iVar4 + 0x14) == *piVar1) {
                            iVar6 = (int32_t)uVar8;
                            uVar8 = (uint64_t)(iVar6 + 1);
                            if (iVar6 == 0) {
                                iVar4 = func_0x0001800f65a0(arg3, 0x1806453a8);
                            }
                            iVar4 = func_0x0001800f65a0(arg3, 0x1806453b8, iVar4 + 0x24);
                        }
                        iVar10 = *(int32_t *)(iVar4 + -4) + iVar4;
                        iVar4 = 0;
                        if (iVar10 != *(int64_t *)(arg1 + 0x2958) + 4 + (int64_t)*(int32_t *)(arg1 + 0x2950)) {
                            iVar4 = iVar10;
                        }
                    }
                }
                func_0x0001800f65a0(arg3, 0x1805ab2a0);
                iVar2 = iVar2 + 1;
            } while (iVar2 < *(int32_t *)(arg1 + 0x2908));
        }
        func_0x0001800f65a0(arg3, 0x1805ab2a0);
    }
    return;
}

// ============================================================
// Function: FUN_18011e8a0
// Address: 0x18011e8a0
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_2828h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2830h because it doesn't fit into ProtoModel

undefined8 fcn.18011e8a0(int64_t arg1, int64_t arg_40h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (*(int64_t *)(arg1 + 0x2830) != 0) {
        *(undefined8 *)(arg1 + 0x2828) = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg1 + 0x2830) = 0;
    }
    iVar1 = (*(code *)0x69a498)(0);
    if (iVar1 != 0) {
        iVar3 = (*(code *)0x69a4ce)(0xd);
        if (iVar3 != 0) {
            iVar4 = (*(code *)0x699dae)(iVar3);
            if (iVar4 != 0) {
                uVar2 = (*(code *)0x699eb4)(0xfde9, 0, iVar4, 0xffffffff, 0, 0, 0, 0);
                func_0x00018011f640(arg1 + 0x2828, uVar2);
                (*(code *)0x699eb4)(0xfde9, 0, iVar4, 0xffffffff, *(undefined8 *)(arg1 + 0x2830), uVar2, 0, 0);
            }
            (*(code *)0x699dbc)(iVar3);
            (*(code *)0x69a486)();
            return *(undefined8 *)(arg1 + 0x2830);
        }
        (*(code *)0x69a486)();
        return 0;
    }
    return 0;
}

// ============================================================
// Function: FUN_18011e8ea
// Address: 0x18011e8ea
// Size: 41 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_2828h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2830h because it doesn't fit into ProtoModel

undefined8 fcn.18011e8a0(int64_t arg1, int64_t arg_40h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (*(int64_t *)(arg1 + 0x2830) != 0) {
        *(undefined8 *)(arg1 + 0x2828) = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg1 + 0x2830) = 0;
    }
    iVar1 = (*(code *)0x69a498)(0);
    if (iVar1 != 0) {
        iVar3 = (*(code *)0x69a4ce)(0xd);
        if (iVar3 != 0) {
            iVar4 = (*(code *)0x699dae)(iVar3);
            if (iVar4 != 0) {
                uVar2 = (*(code *)0x699eb4)(0xfde9, 0, iVar4, 0xffffffff, 0, 0, 0, 0);
                func_0x00018011f640(arg1 + 0x2828, uVar2);
                (*(code *)0x699eb4)(0xfde9, 0, iVar4, 0xffffffff, *(undefined8 *)(arg1 + 0x2830), uVar2, 0, 0);
            }
            (*(code *)0x699dbc)(iVar3);
            (*(code *)0x69a486)();
            return *(undefined8 *)(arg1 + 0x2830);
        }
        (*(code *)0x69a486)();
        return 0;
    }
    return 0;
}

// ============================================================
// Function: FUN_18011e913
// Address: 0x18011e913
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_2828h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2830h because it doesn't fit into ProtoModel

undefined8 fcn.18011e8a0(int64_t arg1, int64_t arg_40h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (*(int64_t *)(arg1 + 0x2830) != 0) {
        *(undefined8 *)(arg1 + 0x2828) = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg1 + 0x2830) = 0;
    }
    iVar1 = (*(code *)0x69a498)(0);
    if (iVar1 != 0) {
        iVar3 = (*(code *)0x69a4ce)(0xd);
        if (iVar3 != 0) {
            iVar4 = (*(code *)0x699dae)(iVar3);
            if (iVar4 != 0) {
                uVar2 = (*(code *)0x699eb4)(0xfde9, 0, iVar4, 0xffffffff, 0, 0, 0, 0);
                func_0x00018011f640(arg1 + 0x2828, uVar2);
                (*(code *)0x699eb4)(0xfde9, 0, iVar4, 0xffffffff, *(undefined8 *)(arg1 + 0x2830), uVar2, 0, 0);
            }
            (*(code *)0x699dbc)(iVar3);
            (*(code *)0x69a486)();
            return *(undefined8 *)(arg1 + 0x2830);
        }
        (*(code *)0x69a486)();
        return 0;
    }
    return 0;
}

// ============================================================
// Function: FUN_18011e94d
// Address: 0x18011e94d
// Size: 86 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_2828h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2830h because it doesn't fit into ProtoModel

undefined8 fcn.18011e8a0(int64_t arg1, int64_t arg_40h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (*(int64_t *)(arg1 + 0x2830) != 0) {
        *(undefined8 *)(arg1 + 0x2828) = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg1 + 0x2830) = 0;
    }
    iVar1 = (*(code *)0x69a498)(0);
    if (iVar1 != 0) {
        iVar3 = (*(code *)0x69a4ce)(0xd);
        if (iVar3 != 0) {
            iVar4 = (*(code *)0x699dae)(iVar3);
            if (iVar4 != 0) {
                uVar2 = (*(code *)0x699eb4)(0xfde9, 0, iVar4, 0xffffffff, 0, 0, 0, 0);
                func_0x00018011f640(arg1 + 0x2828, uVar2);
                (*(code *)0x699eb4)(0xfde9, 0, iVar4, 0xffffffff, *(undefined8 *)(arg1 + 0x2830), uVar2, 0, 0);
            }
            (*(code *)0x699dbc)(iVar3);
            (*(code *)0x69a486)();
            return *(undefined8 *)(arg1 + 0x2830);
        }
        (*(code *)0x69a486)();
        return 0;
    }
    return 0;
}

// ============================================================
// Function: FUN_18011e9a3
// Address: 0x18011e9a3
// Size: 45 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_2828h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2830h because it doesn't fit into ProtoModel

undefined8 fcn.18011e8a0(int64_t arg1, int64_t arg_40h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (*(int64_t *)(arg1 + 0x2830) != 0) {
        *(undefined8 *)(arg1 + 0x2828) = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg1 + 0x2830) = 0;
    }
    iVar1 = (*(code *)0x69a498)(0);
    if (iVar1 != 0) {
        iVar3 = (*(code *)0x69a4ce)(0xd);
        if (iVar3 != 0) {
            iVar4 = (*(code *)0x699dae)(iVar3);
            if (iVar4 != 0) {
                uVar2 = (*(code *)0x699eb4)(0xfde9, 0, iVar4, 0xffffffff, 0, 0, 0, 0);
                func_0x00018011f640(arg1 + 0x2828, uVar2);
                (*(code *)0x699eb4)(0xfde9, 0, iVar4, 0xffffffff, *(undefined8 *)(arg1 + 0x2830), uVar2, 0, 0);
            }
            (*(code *)0x699dbc)(iVar3);
            (*(code *)0x69a486)();
            return *(undefined8 *)(arg1 + 0x2830);
        }
        (*(code *)0x69a486)();
        return 0;
    }
    return 0;
}

// ============================================================
// Function: FUN_18011e9d0
// Address: 0x18011e9d0
// Size: 27 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011e9d0(undefined8 placeholder_0, int64_t arg2)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_10h;
    
    iVar1 = (*(code *)0x69a498)(0);
    if (iVar1 != 0) {
        iVar1 = (*(code *)0x699e90)(0xfde9, 0, arg2, 0xffffffff, 0, 0);
        iVar2 = (*(code *)0x699da0)(2, (int64_t)iVar1 * 2);
        if (iVar2 != 0) {
            uVar3 = (*(code *)0x699dae)(iVar2);
            (*(code *)0x699e90)(0xfde9, 0, arg2, 0xffffffff, uVar3, iVar1);
            (*(code *)0x699dbc)(iVar2);
            (*(code *)0x69a474)();
            iVar4 = (*(code *)0x69a460)(0xd, iVar2);
            if (iVar4 == 0) {
                (*(code *)0x699ea6)(iVar2);
            }
        }
        (*(code *)0x69a486)();
    }
    return;
}

// ============================================================
// Function: FUN_18011e9eb
// Address: 0x18011e9eb
// Size: 168 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011e9d0(undefined8 placeholder_0, int64_t arg2)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_10h;
    
    iVar1 = (*(code *)0x69a498)(0);
    if (iVar1 != 0) {
        iVar1 = (*(code *)0x699e90)(0xfde9, 0, arg2, 0xffffffff, 0, 0);
        iVar2 = (*(code *)0x699da0)(2, (int64_t)iVar1 * 2);
        if (iVar2 != 0) {
            uVar3 = (*(code *)0x699dae)(iVar2);
            (*(code *)0x699e90)(0xfde9, 0, arg2, 0xffffffff, uVar3, iVar1);
            (*(code *)0x699dbc)(iVar2);
            (*(code *)0x69a474)();
            iVar4 = (*(code *)0x69a460)(0xd, iVar2);
            if (iVar4 == 0) {
                (*(code *)0x699ea6)(iVar2);
            }
        }
        (*(code *)0x69a486)();
    }
    return;
}

// ============================================================
// Function: FUN_18011ea93
// Address: 0x18011ea93
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011e9d0(undefined8 placeholder_0, int64_t arg2)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_10h;
    
    iVar1 = (*(code *)0x69a498)(0);
    if (iVar1 != 0) {
        iVar1 = (*(code *)0x699e90)(0xfde9, 0, arg2, 0xffffffff, 0, 0);
        iVar2 = (*(code *)0x699da0)(2, (int64_t)iVar1 * 2);
        if (iVar2 != 0) {
            uVar3 = (*(code *)0x699dae)(iVar2);
            (*(code *)0x699e90)(0xfde9, 0, arg2, 0xffffffff, uVar3, iVar1);
            (*(code *)0x699dbc)(iVar2);
            (*(code *)0x69a474)();
            iVar4 = (*(code *)0x69a460)(0xd, iVar2);
            if (iVar4 == 0) {
                (*(code *)0x699ea6)(iVar2);
            }
        }
        (*(code *)0x69a486)();
    }
    return;
}

// ============================================================
// Function: FUN_18011eaa0
// Address: 0x18011eaa0
// Size: 206 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.18011eaa0(undefined8 placeholder_0, int64_t arg2)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar1 = (*(code *)0x699e90)(0xfde9, 0, arg2, 0xffffffff, 0, 0);
    iVar2 = 0;
    if (0 < iVar1) {
        iVar4 = iVar1;
        if (iVar1 < 8) {
            iVar4 = 8;
        }
        if (0 < iVar4) {
            iVar2 = func_0x00018046d050((int64_t)iVar4 * 2);
        }
    }
    (*(code *)0x699e90)(0xfde9, 0, arg2, 0xffffffff, iVar2, iVar1);
    iVar3 = (*(code *)0x69a7d0)(0, 0x1806453c0, iVar2, 0, 0, 10);
    if (iVar2 != 0) {
        func_0x000180460d90(iVar2);
    }
    return 0x20 < iVar3;
}

// ============================================================
// Function: FUN_18011eb70
// Address: 0x18011eb70
// Size: 45 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch

void fcn.18011eb70(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    undefined auStack_88 [32];
    int64_t var_68h;
    int32_t var_60h;
    int32_t var_5ch;
    int64_t var_58h;
    int64_t var_48h;
    int32_t var_40h;
    int64_t var_3ch;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    iVar1 = *(int64_t *)(arg2 + 0x68);
    if ((iVar1 != 0) && (iVar2 = (*(code *)0x69a84c)(iVar1), iVar2 != 0)) {
        var_48h._0_4_ = 0x20;
        _var_3ch = ZEXT816(0);
        var_48h._4_4_ = (int32_t)(*(float *)(arg3 + 4) - *(float *)(arg2 + 8));
        var_40h = (int32_t)(*(float *)(arg3 + 8) - *(float *)(arg2 + 0xc));
        (*(code *)0x69a81e)(iVar2, &var_48h);
        var_68h._0_4_ = 0;
        _var_58h = ZEXT816(0);
        var_68h._4_4_ = 0x40;
        var_60h = (int32_t)(*(float *)(arg3 + 4) - *(float *)(arg2 + 8));
        var_5ch = (int32_t)(*(float *)(arg3 + 8) - *(float *)(arg2 + 0xc));
        (*(code *)0x69a806)(iVar2, &var_68h);
        (*(code *)0x69a838)(iVar1, iVar2);
    }
    fcn.180459870(var_28h ^ (uint64_t)auStack_88);
    return;
}

// ============================================================
// Function: FUN_18011eb9d
// Address: 0x18011eb9d
// Size: 188 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch

void fcn.18011eb70(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    undefined auStack_88 [32];
    int64_t var_68h;
    int32_t var_60h;
    int32_t var_5ch;
    int64_t var_58h;
    int64_t var_48h;
    int32_t var_40h;
    int64_t var_3ch;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    iVar1 = *(int64_t *)(arg2 + 0x68);
    if ((iVar1 != 0) && (iVar2 = (*(code *)0x69a84c)(iVar1), iVar2 != 0)) {
        var_48h._0_4_ = 0x20;
        _var_3ch = ZEXT816(0);
        var_48h._4_4_ = (int32_t)(*(float *)(arg3 + 4) - *(float *)(arg2 + 8));
        var_40h = (int32_t)(*(float *)(arg3 + 8) - *(float *)(arg2 + 0xc));
        (*(code *)0x69a81e)(iVar2, &var_48h);
        var_68h._0_4_ = 0;
        _var_58h = ZEXT816(0);
        var_68h._4_4_ = 0x40;
        var_60h = (int32_t)(*(float *)(arg3 + 4) - *(float *)(arg2 + 8));
        var_5ch = (int32_t)(*(float *)(arg3 + 8) - *(float *)(arg2 + 0xc));
        (*(code *)0x69a806)(iVar2, &var_68h);
        (*(code *)0x69a838)(iVar1, iVar2);
    }
    fcn.180459870(var_28h ^ (uint64_t)auStack_88);
    return;
}

// ============================================================
// Function: FUN_18011ec59
// Address: 0x18011ec59
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch

void fcn.18011eb70(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    undefined auStack_88 [32];
    int64_t var_68h;
    int32_t var_60h;
    int32_t var_5ch;
    int64_t var_58h;
    int64_t var_48h;
    int32_t var_40h;
    int64_t var_3ch;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    iVar1 = *(int64_t *)(arg2 + 0x68);
    if ((iVar1 != 0) && (iVar2 = (*(code *)0x69a84c)(iVar1), iVar2 != 0)) {
        var_48h._0_4_ = 0x20;
        _var_3ch = ZEXT816(0);
        var_48h._4_4_ = (int32_t)(*(float *)(arg3 + 4) - *(float *)(arg2 + 8));
        var_40h = (int32_t)(*(float *)(arg3 + 8) - *(float *)(arg2 + 0xc));
        (*(code *)0x69a81e)(iVar2, &var_48h);
        var_68h._0_4_ = 0;
        _var_58h = ZEXT816(0);
        var_68h._4_4_ = 0x40;
        var_60h = (int32_t)(*(float *)(arg3 + 4) - *(float *)(arg2 + 8));
        var_5ch = (int32_t)(*(float *)(arg3 + 8) - *(float *)(arg2 + 0xc));
        (*(code *)0x69a806)(iVar2, &var_68h);
        (*(code *)0x69a838)(iVar1, iVar2);
    }
    fcn.180459870(var_28h ^ (uint64_t)auStack_88);
    return;
}

// ============================================================
// Function: FUN_18011ec70
// Address: 0x18011ec70
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18011ec70(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int32_t *)(arg1 + 4);
    if (*(int32_t *)arg1 == iVar1) {
        iVar4 = *(int32_t *)arg1 + 1;
        if (iVar1 == 0) {
            iVar2 = 8;
        } else {
            iVar2 = iVar1 / 2 + iVar1;
        }
        if (iVar4 < iVar2) {
            iVar4 = iVar2;
        }
        if (iVar1 < iVar4) {
            uVar3 = func_0x00018046d050((int64_t)iVar4 << 3);
            if (*(int64_t *)(arg1 + 8) != 0) {
                func_0x000180498030(uVar3, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 << 3);
                func_0x000180460d90(*(undefined8 *)(arg1 + 8));
            }
            *(undefined8 *)(arg1 + 8) = uVar3;
            *(int32_t *)(arg1 + 4) = iVar4;
        }
    }
    *(undefined8 *)(*(int64_t *)(arg1 + 8) + (int64_t)*(int32_t *)arg1 * 8) = *(undefined8 *)arg2;
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    return;
}

// ============================================================
// Function: FUN_18011ecb5
// Address: 0x18011ecb5
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18011ec70(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int32_t *)(arg1 + 4);
    if (*(int32_t *)arg1 == iVar1) {
        iVar4 = *(int32_t *)arg1 + 1;
        if (iVar1 == 0) {
            iVar2 = 8;
        } else {
            iVar2 = iVar1 / 2 + iVar1;
        }
        if (iVar4 < iVar2) {
            iVar4 = iVar2;
        }
        if (iVar1 < iVar4) {
            uVar3 = func_0x00018046d050((int64_t)iVar4 << 3);
            if (*(int64_t *)(arg1 + 8) != 0) {
                func_0x000180498030(uVar3, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 << 3);
                func_0x000180460d90(*(undefined8 *)(arg1 + 8));
            }
            *(undefined8 *)(arg1 + 8) = uVar3;
            *(int32_t *)(arg1 + 4) = iVar4;
        }
    }
    *(undefined8 *)(*(int64_t *)(arg1 + 8) + (int64_t)*(int32_t *)arg1 * 8) = *(undefined8 *)arg2;
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    return;
}

// ============================================================
// Function: FUN_18011ecef
// Address: 0x18011ecef
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18011ec70(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int32_t *)(arg1 + 4);
    if (*(int32_t *)arg1 == iVar1) {
        iVar4 = *(int32_t *)arg1 + 1;
        if (iVar1 == 0) {
            iVar2 = 8;
        } else {
            iVar2 = iVar1 / 2 + iVar1;
        }
        if (iVar4 < iVar2) {
            iVar4 = iVar2;
        }
        if (iVar1 < iVar4) {
            uVar3 = func_0x00018046d050((int64_t)iVar4 << 3);
            if (*(int64_t *)(arg1 + 8) != 0) {
                func_0x000180498030(uVar3, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 << 3);
                func_0x000180460d90(*(undefined8 *)(arg1 + 8));
            }
            *(undefined8 *)(arg1 + 8) = uVar3;
            *(int32_t *)(arg1 + 4) = iVar4;
        }
    }
    *(undefined8 *)(*(int64_t *)(arg1 + 8) + (int64_t)*(int32_t *)arg1 * 8) = *(undefined8 *)arg2;
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    return;
}

// ============================================================
// Function: FUN_18011ed20
// Address: 0x18011ed20
// Size: 103 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011ed20(int64_t arg1)
{
    int64_t var_8h;
    
    if (*(int64_t *)(arg1 + 0x18) != 0) {
        *(undefined8 *)(arg1 + 0x10) = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg1 + 0x18) = 0;
    }
    if (*(int64_t *)(arg1 + 8) != 0) {
        *(undefined8 *)arg1 = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg1 + 8) = 0;
    }
    *(undefined8 *)(arg1 + 0x20) = 0;
    if (*(int64_t *)(arg1 + 0x18) != 0) {
        func_0x000180460d90();
    }
    if (*(int64_t *)(arg1 + 8) != 0) {
        func_0x000180460d90();
    }
    return;
}

// ============================================================
// Function: FUN_18011ed90
// Address: 0x18011ed90
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18011ed90(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar2 = *(int32_t *)(arg1 + 4);
    if (*(int32_t *)arg1 == iVar2) {
        iVar10 = *(int32_t *)arg1 + 1;
        if (iVar2 == 0) {
            iVar7 = 8;
        } else {
            iVar7 = iVar2 / 2 + iVar2;
        }
        if (iVar10 < iVar7) {
            iVar10 = iVar7;
        }
        if (iVar2 < iVar10) {
            uVar8 = func_0x00018046d050((int64_t)iVar10 * 0x48);
            if (*(int64_t *)(arg1 + 8) != 0) {
                func_0x000180498030(uVar8, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x48);
                func_0x000180460d90(*(undefined8 *)(arg1 + 8));
            }
            *(undefined8 *)(arg1 + 8) = uVar8;
            *(int32_t *)(arg1 + 4) = iVar10;
        }
    }
    iVar9 = (int64_t)*(int32_t *)arg1;
    uVar4 = *(undefined4 *)(arg2 + 4);
    uVar5 = *(undefined4 *)(arg2 + 8);
    uVar6 = *(undefined4 *)(arg2 + 0xc);
    iVar3 = *(int64_t *)(arg1 + 8);
    puVar1 = (undefined4 *)(iVar3 + iVar9 * 0x48);
    *puVar1 = *(undefined4 *)arg2;
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    uVar4 = *(undefined4 *)(arg2 + 0x14);
    uVar5 = *(undefined4 *)(arg2 + 0x18);
    uVar6 = *(undefined4 *)(arg2 + 0x1c);
    puVar1 = (undefined4 *)(iVar3 + 0x10 + iVar9 * 0x48);
    *puVar1 = *(undefined4 *)(arg2 + 0x10);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    uVar4 = *(undefined4 *)(arg2 + 0x24);
    uVar5 = *(undefined4 *)(arg2 + 0x28);
    uVar6 = *(undefined4 *)(arg2 + 0x2c);
    puVar1 = (undefined4 *)(iVar3 + 0x20 + iVar9 * 0x48);
    *puVar1 = *(undefined4 *)(arg2 + 0x20);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    uVar4 = *(undefined4 *)(arg2 + 0x34);
    uVar5 = *(undefined4 *)(arg2 + 0x38);
    uVar6 = *(undefined4 *)(arg2 + 0x3c);
    puVar1 = (undefined4 *)(iVar3 + 0x30 + iVar9 * 0x48);
    *puVar1 = *(undefined4 *)(arg2 + 0x30);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    *(undefined8 *)(iVar3 + 0x40 + iVar9 * 0x48) = *(undefined8 *)(arg2 + 0x40);
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    return;
}

// ============================================================
// Function: FUN_18011edd0
// Address: 0x18011edd0
// Size: 70 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18011ed90(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar2 = *(int32_t *)(arg1 + 4);
    if (*(int32_t *)arg1 == iVar2) {
        iVar10 = *(int32_t *)arg1 + 1;
        if (iVar2 == 0) {
            iVar7 = 8;
        } else {
            iVar7 = iVar2 / 2 + iVar2;
        }
        if (iVar10 < iVar7) {
            iVar10 = iVar7;
        }
        if (iVar2 < iVar10) {
            uVar8 = func_0x00018046d050((int64_t)iVar10 * 0x48);
            if (*(int64_t *)(arg1 + 8) != 0) {
                func_0x000180498030(uVar8, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x48);
                func_0x000180460d90(*(undefined8 *)(arg1 + 8));
            }
            *(undefined8 *)(arg1 + 8) = uVar8;
            *(int32_t *)(arg1 + 4) = iVar10;
        }
    }
    iVar9 = (int64_t)*(int32_t *)arg1;
    uVar4 = *(undefined4 *)(arg2 + 4);
    uVar5 = *(undefined4 *)(arg2 + 8);
    uVar6 = *(undefined4 *)(arg2 + 0xc);
    iVar3 = *(int64_t *)(arg1 + 8);
    puVar1 = (undefined4 *)(iVar3 + iVar9 * 0x48);
    *puVar1 = *(undefined4 *)arg2;
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    uVar4 = *(undefined4 *)(arg2 + 0x14);
    uVar5 = *(undefined4 *)(arg2 + 0x18);
    uVar6 = *(undefined4 *)(arg2 + 0x1c);
    puVar1 = (undefined4 *)(iVar3 + 0x10 + iVar9 * 0x48);
    *puVar1 = *(undefined4 *)(arg2 + 0x10);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    uVar4 = *(undefined4 *)(arg2 + 0x24);
    uVar5 = *(undefined4 *)(arg2 + 0x28);
    uVar6 = *(undefined4 *)(arg2 + 0x2c);
    puVar1 = (undefined4 *)(iVar3 + 0x20 + iVar9 * 0x48);
    *puVar1 = *(undefined4 *)(arg2 + 0x20);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    uVar4 = *(undefined4 *)(arg2 + 0x34);
    uVar5 = *(undefined4 *)(arg2 + 0x38);
    uVar6 = *(undefined4 *)(arg2 + 0x3c);
    puVar1 = (undefined4 *)(iVar3 + 0x30 + iVar9 * 0x48);
    *puVar1 = *(undefined4 *)(arg2 + 0x30);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    *(undefined8 *)(iVar3 + 0x40 + iVar9 * 0x48) = *(undefined8 *)(arg2 + 0x40);
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    return;
}

// ============================================================
// Function: FUN_18011ee16
// Address: 0x18011ee16
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18011ed90(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar2 = *(int32_t *)(arg1 + 4);
    if (*(int32_t *)arg1 == iVar2) {
        iVar10 = *(int32_t *)arg1 + 1;
        if (iVar2 == 0) {
            iVar7 = 8;
        } else {
            iVar7 = iVar2 / 2 + iVar2;
        }
        if (iVar10 < iVar7) {
            iVar10 = iVar7;
        }
        if (iVar2 < iVar10) {
            uVar8 = func_0x00018046d050((int64_t)iVar10 * 0x48);
            if (*(int64_t *)(arg1 + 8) != 0) {
                func_0x000180498030(uVar8, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x48);
                func_0x000180460d90(*(undefined8 *)(arg1 + 8));
            }
            *(undefined8 *)(arg1 + 8) = uVar8;
            *(int32_t *)(arg1 + 4) = iVar10;
        }
    }
    iVar9 = (int64_t)*(int32_t *)arg1;
    uVar4 = *(undefined4 *)(arg2 + 4);
    uVar5 = *(undefined4 *)(arg2 + 8);
    uVar6 = *(undefined4 *)(arg2 + 0xc);
    iVar3 = *(int64_t *)(arg1 + 8);
    puVar1 = (undefined4 *)(iVar3 + iVar9 * 0x48);
    *puVar1 = *(undefined4 *)arg2;
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    uVar4 = *(undefined4 *)(arg2 + 0x14);
    uVar5 = *(undefined4 *)(arg2 + 0x18);
    uVar6 = *(undefined4 *)(arg2 + 0x1c);
    puVar1 = (undefined4 *)(iVar3 + 0x10 + iVar9 * 0x48);
    *puVar1 = *(undefined4 *)(arg2 + 0x10);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    uVar4 = *(undefined4 *)(arg2 + 0x24);
    uVar5 = *(undefined4 *)(arg2 + 0x28);
    uVar6 = *(undefined4 *)(arg2 + 0x2c);
    puVar1 = (undefined4 *)(iVar3 + 0x20 + iVar9 * 0x48);
    *puVar1 = *(undefined4 *)(arg2 + 0x20);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    uVar4 = *(undefined4 *)(arg2 + 0x34);
    uVar5 = *(undefined4 *)(arg2 + 0x38);
    uVar6 = *(undefined4 *)(arg2 + 0x3c);
    puVar1 = (undefined4 *)(iVar3 + 0x30 + iVar9 * 0x48);
    *puVar1 = *(undefined4 *)(arg2 + 0x30);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    *(undefined8 *)(iVar3 + 0x40 + iVar9 * 0x48) = *(undefined8 *)(arg2 + 0x40);
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    return;
}

// ============================================================
// Function: FUN_18011ee60
// Address: 0x18011ee60
// Size: 110 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18011ee60(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar1 = 0;
    if (0 < *(int32_t *)arg1) {
        do {
            if (*(int64_t *)((int64_t)iVar1 * 0x58 + 8 + *(int64_t *)(arg1 + 8)) != 0) {
                func_0x000180460d90();
            }
            iVar1 = iVar1 + 1;
        } while (iVar1 < *(int32_t *)arg1);
    }
    if (*(int64_t *)(arg1 + 8) != 0) {
        *(undefined8 *)arg1 = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg1 + 8) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18011eed0
// Address: 0x18011eed0
// Size: 171 bytes
// ============================================================
void fcn.18011eed0(int64_t arg1)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    
    iVar4 = 0;
    iVar2 = *(int32_t *)(arg1 + 0x10);
    if (0 < iVar2) {
        do {
            iVar1 = *(int32_t *)(*(int64_t *)(arg1 + 0x18) + 8 + (int64_t)iVar4 * 0x10);
            if (iVar1 != -1) {
                iVar3 = (int64_t)iVar1 * 0xb0 + *(int64_t *)(arg1 + 8);
                if (*(int64_t *)(iVar3 + 0xa8) != 0) {
                    func_0x000180460d90();
                    iVar2 = *(int32_t *)(arg1 + 0x10);
                }
                if (*(int64_t *)(iVar3 + 0x10) != 0) {
                    func_0x000180460d90();
                    iVar2 = *(int32_t *)(arg1 + 0x10);
                }
            }
            iVar4 = iVar4 + 1;
        } while (iVar4 < iVar2);
    }
    if (*(int64_t *)(arg1 + 0x18) != 0) {
        *(undefined8 *)(arg1 + 0x10) = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg1 + 0x18) = 0;
    }
    if (*(int64_t *)(arg1 + 8) != 0) {
        *(undefined8 *)arg1 = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg1 + 8) = 0;
    }
    *(undefined8 *)(arg1 + 0x20) = 0;
    return;
}

// ============================================================
// Function: FUN_18011ef80
// Address: 0x18011ef80
// Size: 51 bytes
// ============================================================
void fcn.18011ef80(int64_t arg1)
{
    fcn.18011eed0(arg1);
    if (*(int64_t *)(arg1 + 0x18) != 0) {
        func_0x000180460d90();
    }
    if (*(int64_t *)(arg1 + 8) != 0) {
        func_0x000180460d90();
    }
    return;
}

// ============================================================
// Function: FUN_18011efc0
// Address: 0x18011efc0
// Size: 190 bytes
// ============================================================
void fcn.18011efc0(int64_t arg1)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t iVar3;
    
    iVar3 = 0;
    if (0 < *(int32_t *)(arg1 + 0x10)) {
        do {
            iVar1 = *(int32_t *)(*(int64_t *)(arg1 + 0x18) + 8 + (int64_t)iVar3 * 0x10);
            if (iVar1 != -1) {
                iVar2 = (int64_t)iVar1 * 0x250 + *(int64_t *)(arg1 + 8);
                func_0x000180460d90(*(undefined8 *)(iVar2 + 8));
                if (*(int64_t *)(iVar2 + 0x1e8) != 0) {
                    func_0x000180460d90();
                }
                if (*(int64_t *)(iVar2 + 0x1c8) != 0) {
                    func_0x000180460d90();
                }
                if (*(int64_t *)(iVar2 + 0x198) != 0) {
                    func_0x000180460d90();
                }
            }
            iVar3 = iVar3 + 1;
        } while (iVar3 < *(int32_t *)(arg1 + 0x10));
    }
    if (*(int64_t *)(arg1 + 0x18) != 0) {
        *(undefined8 *)(arg1 + 0x10) = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg1 + 0x18) = 0;
    }
    if (*(int64_t *)(arg1 + 8) != 0) {
        *(undefined8 *)arg1 = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg1 + 8) = 0;
    }
    *(undefined8 *)(arg1 + 0x20) = 0;
    return;
}

// ============================================================
// Function: FUN_18011f080
// Address: 0x18011f080
// Size: 51 bytes
// ============================================================
void fcn.18011f080(int64_t arg1)
{
    fcn.18011efc0(arg1);
    if (*(int64_t *)(arg1 + 0x18) != 0) {
        func_0x000180460d90();
    }
    if (*(int64_t *)(arg1 + 8) != 0) {
        func_0x000180460d90();
    }
    return;
}

// ============================================================
// Function: FUN_18011f0c0
// Address: 0x18011f0c0
// Size: 128 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f0c0(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    int64_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t iVar8;
    int64_t var_8h;
    
    iVar6 = *(int32_t *)(arg1 + 4);
    if (*(int32_t *)arg1 == iVar6) {
        iVar8 = *(int32_t *)arg1 + 1;
        if (iVar6 == 0) {
            iVar6 = 8;
        } else {
            iVar6 = iVar6 / 2 + iVar6;
        }
        if (iVar8 < iVar6) {
            iVar8 = iVar6;
        }
        func_0x00018011f970(arg1, iVar8);
    }
    uVar3 = *(undefined4 *)(arg2 + 4);
    uVar4 = *(undefined4 *)(arg2 + 8);
    uVar5 = *(undefined4 *)(arg2 + 0xc);
    iVar7 = (int64_t)*(int32_t *)arg1 * 0x38;
    iVar2 = *(int64_t *)(arg1 + 8);
    puVar1 = (undefined4 *)(iVar7 + iVar2);
    *puVar1 = *(undefined4 *)arg2;
    puVar1[1] = uVar3;
    puVar1[2] = uVar4;
    puVar1[3] = uVar5;
    uVar3 = *(undefined4 *)(arg2 + 0x14);
    uVar4 = *(undefined4 *)(arg2 + 0x18);
    uVar5 = *(undefined4 *)(arg2 + 0x1c);
    puVar1 = (undefined4 *)(iVar7 + 0x10 + iVar2);
    *puVar1 = *(undefined4 *)(arg2 + 0x10);
    puVar1[1] = uVar3;
    puVar1[2] = uVar4;
    puVar1[3] = uVar5;
    uVar3 = *(undefined4 *)(arg2 + 0x24);
    uVar4 = *(undefined4 *)(arg2 + 0x28);
    uVar5 = *(undefined4 *)(arg2 + 0x2c);
    puVar1 = (undefined4 *)(iVar7 + 0x20 + iVar2);
    *puVar1 = *(undefined4 *)(arg2 + 0x20);
    puVar1[1] = uVar3;
    puVar1[2] = uVar4;
    puVar1[3] = uVar5;
    *(undefined8 *)(iVar7 + 0x30 + iVar2) = *(undefined8 *)(arg2 + 0x30);
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    return;
}

// ============================================================
// Function: FUN_18011f140
// Address: 0x18011f140
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18011f140(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar4 = (int32_t)arg2;
    iVar1 = *(int32_t *)(arg1 + 4);
    if (iVar4 <= iVar1) {
        *(int32_t *)arg1 = iVar4;
        return;
    }
    if (iVar1 == 0) {
        iVar2 = 8;
    } else {
        iVar2 = iVar1 / 2 + iVar1;
    }
    iVar5 = iVar4;
    if (iVar4 < iVar2) {
        iVar5 = iVar2;
    }
    if (iVar1 < iVar5) {
        uVar3 = func_0x00018046d050((int64_t)iVar5 * 0x3c);
        if (*(int64_t *)(arg1 + 8) != 0) {
            func_0x000180498030(uVar3, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x3c);
            func_0x000180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar3;
        *(int32_t *)(arg1 + 4) = iVar5;
        *(int32_t *)arg1 = iVar4;
        return;
    }
    *(int32_t *)arg1 = iVar4;
    return;
}

// ============================================================
// Function: FUN_18011f15a
// Address: 0x18011f15a
// Size: 119 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18011f140(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar4 = (int32_t)arg2;
    iVar1 = *(int32_t *)(arg1 + 4);
    if (iVar4 <= iVar1) {
        *(int32_t *)arg1 = iVar4;
        return;
    }
    if (iVar1 == 0) {
        iVar2 = 8;
    } else {
        iVar2 = iVar1 / 2 + iVar1;
    }
    iVar5 = iVar4;
    if (iVar4 < iVar2) {
        iVar5 = iVar2;
    }
    if (iVar1 < iVar5) {
        uVar3 = func_0x00018046d050((int64_t)iVar5 * 0x3c);
        if (*(int64_t *)(arg1 + 8) != 0) {
            func_0x000180498030(uVar3, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x3c);
            func_0x000180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar3;
        *(int32_t *)(arg1 + 4) = iVar5;
        *(int32_t *)arg1 = iVar4;
        return;
    }
    *(int32_t *)arg1 = iVar4;
    return;
}

// ============================================================
// Function: FUN_18011f1d1
// Address: 0x18011f1d1
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18011f140(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar4 = (int32_t)arg2;
    iVar1 = *(int32_t *)(arg1 + 4);
    if (iVar4 <= iVar1) {
        *(int32_t *)arg1 = iVar4;
        return;
    }
    if (iVar1 == 0) {
        iVar2 = 8;
    } else {
        iVar2 = iVar1 / 2 + iVar1;
    }
    iVar5 = iVar4;
    if (iVar4 < iVar2) {
        iVar5 = iVar2;
    }
    if (iVar1 < iVar5) {
        uVar3 = func_0x00018046d050((int64_t)iVar5 * 0x3c);
        if (*(int64_t *)(arg1 + 8) != 0) {
            func_0x000180498030(uVar3, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x3c);
            func_0x000180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar3;
        *(int32_t *)(arg1 + 4) = iVar5;
        *(int32_t *)arg1 = iVar4;
        return;
    }
    *(int32_t *)arg1 = iVar4;
    return;
}

// ============================================================
// Function: FUN_18011f1e3
// Address: 0x18011f1e3
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18011f140(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar4 = (int32_t)arg2;
    iVar1 = *(int32_t *)(arg1 + 4);
    if (iVar4 <= iVar1) {
        *(int32_t *)arg1 = iVar4;
        return;
    }
    if (iVar1 == 0) {
        iVar2 = 8;
    } else {
        iVar2 = iVar1 / 2 + iVar1;
    }
    iVar5 = iVar4;
    if (iVar4 < iVar2) {
        iVar5 = iVar2;
    }
    if (iVar1 < iVar5) {
        uVar3 = func_0x00018046d050((int64_t)iVar5 * 0x3c);
        if (*(int64_t *)(arg1 + 8) != 0) {
            func_0x000180498030(uVar3, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x3c);
            func_0x000180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar3;
        *(int32_t *)(arg1 + 4) = iVar5;
        *(int32_t *)arg1 = iVar4;
        return;
    }
    *(int32_t *)arg1 = iVar4;
    return;
}

// ============================================================
// Function: FUN_18011f1f0
// Address: 0x18011f1f0
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f1f0(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t iVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar1 = *(int32_t *)(arg1 + 4);
    if (*(int32_t *)arg1 == iVar1) {
        iVar5 = *(int32_t *)arg1 + 1;
        if (iVar1 == 0) {
            iVar3 = 8;
        } else {
            iVar3 = iVar1 / 2 + iVar1;
        }
        if (iVar5 < iVar3) {
            iVar5 = iVar3;
        }
        if (iVar1 < iVar5) {
            uVar4 = func_0x00018046d050((int64_t)iVar5 * 0xc);
            if (*(int64_t *)(arg1 + 8) != 0) {
                func_0x000180498030(uVar4, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0xc);
                func_0x000180460d90(*(undefined8 *)(arg1 + 8));
            }
            *(undefined8 *)(arg1 + 8) = uVar4;
            *(int32_t *)(arg1 + 4) = iVar5;
        }
    }
    iVar1 = *(int32_t *)arg1;
    iVar2 = *(int64_t *)(arg1 + 8);
    *(undefined8 *)(iVar2 + (int64_t)iVar1 * 0xc) = *(undefined8 *)arg2;
    *(undefined4 *)(iVar2 + (int64_t)iVar1 * 0xc + 8) = *(undefined4 *)(arg2 + 8);
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    return;
}

// ============================================================
// Function: FUN_18011f230
// Address: 0x18011f230
// Size: 70 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f1f0(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t iVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar1 = *(int32_t *)(arg1 + 4);
    if (*(int32_t *)arg1 == iVar1) {
        iVar5 = *(int32_t *)arg1 + 1;
        if (iVar1 == 0) {
            iVar3 = 8;
        } else {
            iVar3 = iVar1 / 2 + iVar1;
        }
        if (iVar5 < iVar3) {
            iVar5 = iVar3;
        }
        if (iVar1 < iVar5) {
            uVar4 = func_0x00018046d050((int64_t)iVar5 * 0xc);
            if (*(int64_t *)(arg1 + 8) != 0) {
                func_0x000180498030(uVar4, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0xc);
                func_0x000180460d90(*(undefined8 *)(arg1 + 8));
            }
            *(undefined8 *)(arg1 + 8) = uVar4;
            *(int32_t *)(arg1 + 4) = iVar5;
        }
    }
    iVar1 = *(int32_t *)arg1;
    iVar2 = *(int64_t *)(arg1 + 8);
    *(undefined8 *)(iVar2 + (int64_t)iVar1 * 0xc) = *(undefined8 *)arg2;
    *(undefined4 *)(iVar2 + (int64_t)iVar1 * 0xc + 8) = *(undefined4 *)(arg2 + 8);
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    return;
}

// ============================================================
// Function: FUN_18011f276
// Address: 0x18011f276
// Size: 49 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f1f0(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t iVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar1 = *(int32_t *)(arg1 + 4);
    if (*(int32_t *)arg1 == iVar1) {
        iVar5 = *(int32_t *)arg1 + 1;
        if (iVar1 == 0) {
            iVar3 = 8;
        } else {
            iVar3 = iVar1 / 2 + iVar1;
        }
        if (iVar5 < iVar3) {
            iVar5 = iVar3;
        }
        if (iVar1 < iVar5) {
            uVar4 = func_0x00018046d050((int64_t)iVar5 * 0xc);
            if (*(int64_t *)(arg1 + 8) != 0) {
                func_0x000180498030(uVar4, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0xc);
                func_0x000180460d90(*(undefined8 *)(arg1 + 8));
            }
            *(undefined8 *)(arg1 + 8) = uVar4;
            *(int32_t *)(arg1 + 4) = iVar5;
        }
    }
    iVar1 = *(int32_t *)arg1;
    iVar2 = *(int64_t *)(arg1 + 8);
    *(undefined8 *)(iVar2 + (int64_t)iVar1 * 0xc) = *(undefined8 *)arg2;
    *(undefined4 *)(iVar2 + (int64_t)iVar1 * 0xc + 8) = *(undefined4 *)(arg2 + 8);
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    return;
}

// ============================================================
// Function: FUN_18011f2b0
// Address: 0x18011f2b0
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f2b0(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    undefined8 uVar8;
    int32_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar2 = *(int32_t *)(arg1 + 4);
    if (*(int32_t *)arg1 == iVar2) {
        iVar9 = *(int32_t *)arg1 + 1;
        if (iVar2 == 0) {
            iVar7 = 8;
        } else {
            iVar7 = iVar2 / 2 + iVar2;
        }
        if (iVar9 < iVar7) {
            iVar9 = iVar7;
        }
        if (iVar2 < iVar9) {
            uVar8 = func_0x00018046d050((int64_t)iVar9 * 0x14);
            if (*(int64_t *)(arg1 + 8) != 0) {
                func_0x000180498030(uVar8, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x14);
                func_0x000180460d90(*(undefined8 *)(arg1 + 8));
            }
            *(undefined8 *)(arg1 + 8) = uVar8;
            *(int32_t *)(arg1 + 4) = iVar9;
        }
    }
    iVar2 = *(int32_t *)arg1;
    uVar4 = *(undefined4 *)(arg2 + 4);
    uVar5 = *(undefined4 *)(arg2 + 8);
    uVar6 = *(undefined4 *)(arg2 + 0xc);
    iVar3 = *(int64_t *)(arg1 + 8);
    puVar1 = (undefined4 *)(iVar3 + (int64_t)iVar2 * 0x14);
    *puVar1 = *(undefined4 *)arg2;
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    *(undefined4 *)(iVar3 + (int64_t)iVar2 * 0x14 + 0x10) = *(undefined4 *)(arg2 + 0x10);
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    return;
}

// ============================================================
// Function: FUN_18011f2f0
// Address: 0x18011f2f0
// Size: 70 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f2b0(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    undefined8 uVar8;
    int32_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar2 = *(int32_t *)(arg1 + 4);
    if (*(int32_t *)arg1 == iVar2) {
        iVar9 = *(int32_t *)arg1 + 1;
        if (iVar2 == 0) {
            iVar7 = 8;
        } else {
            iVar7 = iVar2 / 2 + iVar2;
        }
        if (iVar9 < iVar7) {
            iVar9 = iVar7;
        }
        if (iVar2 < iVar9) {
            uVar8 = func_0x00018046d050((int64_t)iVar9 * 0x14);
            if (*(int64_t *)(arg1 + 8) != 0) {
                func_0x000180498030(uVar8, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x14);
                func_0x000180460d90(*(undefined8 *)(arg1 + 8));
            }
            *(undefined8 *)(arg1 + 8) = uVar8;
            *(int32_t *)(arg1 + 4) = iVar9;
        }
    }
    iVar2 = *(int32_t *)arg1;
    uVar4 = *(undefined4 *)(arg2 + 4);
    uVar5 = *(undefined4 *)(arg2 + 8);
    uVar6 = *(undefined4 *)(arg2 + 0xc);
    iVar3 = *(int64_t *)(arg1 + 8);
    puVar1 = (undefined4 *)(iVar3 + (int64_t)iVar2 * 0x14);
    *puVar1 = *(undefined4 *)arg2;
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    *(undefined4 *)(iVar3 + (int64_t)iVar2 * 0x14 + 0x10) = *(undefined4 *)(arg2 + 0x10);
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    return;
}

// ============================================================
// Function: FUN_18011f336
// Address: 0x18011f336
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f2b0(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    undefined8 uVar8;
    int32_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar2 = *(int32_t *)(arg1 + 4);
    if (*(int32_t *)arg1 == iVar2) {
        iVar9 = *(int32_t *)arg1 + 1;
        if (iVar2 == 0) {
            iVar7 = 8;
        } else {
            iVar7 = iVar2 / 2 + iVar2;
        }
        if (iVar9 < iVar7) {
            iVar9 = iVar7;
        }
        if (iVar2 < iVar9) {
            uVar8 = func_0x00018046d050((int64_t)iVar9 * 0x14);
            if (*(int64_t *)(arg1 + 8) != 0) {
                func_0x000180498030(uVar8, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x14);
                func_0x000180460d90(*(undefined8 *)(arg1 + 8));
            }
            *(undefined8 *)(arg1 + 8) = uVar8;
            *(int32_t *)(arg1 + 4) = iVar9;
        }
    }
    iVar2 = *(int32_t *)arg1;
    uVar4 = *(undefined4 *)(arg2 + 4);
    uVar5 = *(undefined4 *)(arg2 + 8);
    uVar6 = *(undefined4 *)(arg2 + 0xc);
    iVar3 = *(int64_t *)(arg1 + 8);
    puVar1 = (undefined4 *)(iVar3 + (int64_t)iVar2 * 0x14);
    *puVar1 = *(undefined4 *)arg2;
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    *(undefined4 *)(iVar3 + (int64_t)iVar2 * 0x14 + 0x10) = *(undefined4 *)(arg2 + 0x10);
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    return;
}

// ============================================================
// Function: FUN_18011f370
// Address: 0x18011f370
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18011f370(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar4 = (int32_t)arg2;
    iVar1 = *(int32_t *)(arg1 + 4);
    if (iVar4 <= iVar1) {
        *(int32_t *)arg1 = iVar4;
        return;
    }
    if (iVar1 == 0) {
        iVar2 = 8;
    } else {
        iVar2 = iVar1 / 2 + iVar1;
    }
    iVar5 = iVar4;
    if (iVar4 < iVar2) {
        iVar5 = iVar2;
    }
    if (iVar1 < iVar5) {
        uVar3 = func_0x00018046d050((int64_t)iVar5 * 0x78);
        if (*(int64_t *)(arg1 + 8) != 0) {
            func_0x000180498030(uVar3, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x78);
            func_0x000180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar3;
        *(int32_t *)(arg1 + 4) = iVar5;
        *(int32_t *)arg1 = iVar4;
        return;
    }
    *(int32_t *)arg1 = iVar4;
    return;
}

