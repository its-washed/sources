// Chunk 115 - 50 functions

// ============================================================
// Function: FUN_18018da30
// Address: 0x18018da30
// Size: 419 bytes
// ============================================================
void fcn.18018da30(void)
{
    int32_t iVar1;
    undefined4 uVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    int64_t iVar5;
    code *pcVar6;
    undefined auStack_1d8 [32];
    int64_t var_1b8h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1d8;
    iVar1 = (*(code *)0x8000000000000073)(0x202, &var_1b8h);
    if (iVar1 == 0) {
        iVar4 = (*(code *)0x69a0ee)(0x1804a8998);
        if (((((iVar4 == 0) || (iVar5 = (*(code *)0x699eee)(iVar4, 0x1804a89b0), iVar5 == 0)) ||
             (*(int64_t *)0x18077e210 = iVar5, iVar5 = (*(code *)0x699eee)(iVar4, 0x1804a89c8), iVar5 == 0)) ||
            ((*(int64_t *)0x18077e218 = iVar5, pcVar6 = (code *)(*(code *)0x699eee)(iVar4, 0x1804a89d8),
             pcVar6 == (code *)0x0 ||
             (*(code **)0x18077e220 = pcVar6, iVar5 = (*(code *)0x699eee)(iVar4, 0x1804a89f0), iVar5 == 0)))) ||
           ((*(int64_t *)0x18077e228 = iVar5, iVar5 = (*(code *)0x699eee)(iVar4, 0x1804a8a08), iVar5 == 0 ||
            ((*(int64_t *)0x18077e230 = iVar5, iVar5 = (*(code *)0x699eee)(iVar4, 0x1804a8a20), iVar5 == 0 ||
             (*(int64_t *)0x18077e238 = iVar5, pcVar6 = (code *)(*(code *)0x699eee)(iVar4, 0x1804a8a38),
             pcVar6 == (code *)0x0)))))) goto code_r0x00018018da7d;
        *(code **)0x18077e240 = pcVar6;
        iVar1 = (**(code **)0x18077e220)(0x18077e268, 0xf0003, 0, 0);
        if (iVar1 == 0) {
            *(undefined8 *)0x18077e248 = 0;
            (*(code *)0x69a04e)(0x18077e250);
            *(undefined *)0x18077e258 = 1;
            goto code_r0x00018018da7d;
        }
        iVar1 = (**(code **)0x18077e240)(iVar1);
    }
    (*(code *)0x69a006)(iVar1);
    puVar3 = (undefined4 *)fcn.18046b77c();
    uVar2 = fcn.18018d4d0(iVar1);
    *puVar3 = uVar2;
code_r0x00018018da7d:
    fcn.180459870(var_18h ^ (uint64_t)auStack_1d8);
    return;
}

// ============================================================
// Function: FUN_18018dbe0
// Address: 0x18018dbe0
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18018dbe0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t **ppiVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    int64_t **ppiVar5;
    int32_t iVar6;
    undefined4 uVar7;
    int64_t *piVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_98 [32];
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_20h;
    
    var_20h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_98;
    piVar3 = *(int64_t **)(arg1 + 0x30);
    piVar1 = (int64_t *)(arg1 + 0x30);
    if (((piVar3 == piVar1) || (piVar8 = piVar3 + -1, piVar8 == (int64_t *)0x0)) || (0x1f < (uint64_t)piVar3[3])) {
        uVar4 = *(undefined8 *)arg1;
        piVar8 = (int64_t *)func_0x00018046d050(0x28);
        if (piVar8 == (int64_t *)0x0) {
            (*(code *)0x69a006)(8);
            puVar9 = (undefined4 *)fcn.18046b77c();
            *puVar9 = 0xc;
            piVar8 = (int64_t *)0x0;
        } else {
            var_48h._0_4_ = 0;
            piVar3 = piVar8 + 1;
            var_50h = 0;
            piVar8[3] = 0;
            var_58h._0_4_ = 0;
            piVar8[4] = 0;
            var_60h._0_4_ = 1;
            var_68h._0_4_ = 3;
            var_70h._0_4_ = 0;
            var_78h = 0;
            *piVar3 = (int64_t)piVar3;
            piVar8[2] = (int64_t)piVar3;
            *piVar8 = arg1;
            iVar6 = (**(code **)0x18077e218)(&var_38h, 0x100000, 0x18069c320, &var_30h);
            if (iVar6 == 0) {
                iVar10 = (*(code *)0x69a016)(var_38h, uVar4, 0, 0);
                if ((iVar10 != 0) && (iVar6 = (*(code *)0x69a102)(var_38h, 2), iVar6 != 0)) {
                    piVar8[3] = var_38h;
                    piVar8[2] = (int64_t)piVar1;
                    iVar10 = *piVar1;
                    *piVar3 = iVar10;
                    *(int64_t **)(iVar10 + 8) = piVar3;
                    *piVar1 = (int64_t)piVar3;
                    goto code_r0x00018018dd64;
                }
                (*(code *)0x699d92)(var_38h);
                uVar7 = (*(code *)0x699ff6)();
                uVar7 = fcn.18018d4d0(uVar7);
                puVar9 = (undefined4 *)fcn.18046b77c();
                *puVar9 = uVar7;
            } else {
                uVar7 = (**(code **)0x18077e240)(iVar6);
                (*(code *)0x69a006)(uVar7);
                puVar9 = (undefined4 *)fcn.18046b77c();
                uVar7 = fcn.18018d4d0(uVar7);
                *puVar9 = uVar7;
            }
            func_0x000180460d90(piVar8);
            piVar8 = (int64_t *)0x0;
        }
code_r0x00018018dd64:
        if (piVar8 == (int64_t *)0x0) goto code_r0x00018018ddb7;
    }
    piVar8[4] = piVar8[4] + 1;
    if (piVar8[4] == 0x20) {
        ppiVar2 = (int64_t **)(piVar8 + 1);
        *(int64_t *)(piVar8[1] + 8) = piVar8[2];
        *(int64_t **)piVar8[2] = *ppiVar2;
        ppiVar5 = *(int64_t ***)(arg1 + 0x38);
        piVar8[2] = (int64_t)ppiVar5;
        *ppiVar2 = piVar1;
        *ppiVar5 = (int64_t *)ppiVar2;
        *(int64_t ***)(arg1 + 0x38) = ppiVar2;
    }
code_r0x00018018ddb7:
    fcn.180459870(var_20h ^ (uint64_t)auStack_98);
    return;
}

// ============================================================
// Function: FUN_18018dc1c
// Address: 0x18018dc1c
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18018dbe0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t **ppiVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    int64_t **ppiVar5;
    int32_t iVar6;
    undefined4 uVar7;
    int64_t *piVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_98 [32];
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_20h;
    
    var_20h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_98;
    piVar3 = *(int64_t **)(arg1 + 0x30);
    piVar1 = (int64_t *)(arg1 + 0x30);
    if (((piVar3 == piVar1) || (piVar8 = piVar3 + -1, piVar8 == (int64_t *)0x0)) || (0x1f < (uint64_t)piVar3[3])) {
        uVar4 = *(undefined8 *)arg1;
        piVar8 = (int64_t *)func_0x00018046d050(0x28);
        if (piVar8 == (int64_t *)0x0) {
            (*(code *)0x69a006)(8);
            puVar9 = (undefined4 *)fcn.18046b77c();
            *puVar9 = 0xc;
            piVar8 = (int64_t *)0x0;
        } else {
            var_48h._0_4_ = 0;
            piVar3 = piVar8 + 1;
            var_50h = 0;
            piVar8[3] = 0;
            var_58h._0_4_ = 0;
            piVar8[4] = 0;
            var_60h._0_4_ = 1;
            var_68h._0_4_ = 3;
            var_70h._0_4_ = 0;
            var_78h = 0;
            *piVar3 = (int64_t)piVar3;
            piVar8[2] = (int64_t)piVar3;
            *piVar8 = arg1;
            iVar6 = (**(code **)0x18077e218)(&var_38h, 0x100000, 0x18069c320, &var_30h);
            if (iVar6 == 0) {
                iVar10 = (*(code *)0x69a016)(var_38h, uVar4, 0, 0);
                if ((iVar10 != 0) && (iVar6 = (*(code *)0x69a102)(var_38h, 2), iVar6 != 0)) {
                    piVar8[3] = var_38h;
                    piVar8[2] = (int64_t)piVar1;
                    iVar10 = *piVar1;
                    *piVar3 = iVar10;
                    *(int64_t **)(iVar10 + 8) = piVar3;
                    *piVar1 = (int64_t)piVar3;
                    goto code_r0x00018018dd64;
                }
                (*(code *)0x699d92)(var_38h);
                uVar7 = (*(code *)0x699ff6)();
                uVar7 = fcn.18018d4d0(uVar7);
                puVar9 = (undefined4 *)fcn.18046b77c();
                *puVar9 = uVar7;
            } else {
                uVar7 = (**(code **)0x18077e240)(iVar6);
                (*(code *)0x69a006)(uVar7);
                puVar9 = (undefined4 *)fcn.18046b77c();
                uVar7 = fcn.18018d4d0(uVar7);
                *puVar9 = uVar7;
            }
            func_0x000180460d90(piVar8);
            piVar8 = (int64_t *)0x0;
        }
code_r0x00018018dd64:
        if (piVar8 == (int64_t *)0x0) goto code_r0x00018018ddb7;
    }
    piVar8[4] = piVar8[4] + 1;
    if (piVar8[4] == 0x20) {
        ppiVar2 = (int64_t **)(piVar8 + 1);
        *(int64_t *)(piVar8[1] + 8) = piVar8[2];
        *(int64_t **)piVar8[2] = *ppiVar2;
        ppiVar5 = *(int64_t ***)(arg1 + 0x38);
        piVar8[2] = (int64_t)ppiVar5;
        *ppiVar2 = piVar1;
        *ppiVar5 = (int64_t *)ppiVar2;
        *(int64_t ***)(arg1 + 0x38) = ppiVar2;
    }
code_r0x00018018ddb7:
    fcn.180459870(var_20h ^ (uint64_t)auStack_98);
    return;
}

// ============================================================
// Function: FUN_18018dc60
// Address: 0x18018dc60
// Size: 260 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18018dbe0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t **ppiVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    int64_t **ppiVar5;
    int32_t iVar6;
    undefined4 uVar7;
    int64_t *piVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_98 [32];
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_20h;
    
    var_20h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_98;
    piVar3 = *(int64_t **)(arg1 + 0x30);
    piVar1 = (int64_t *)(arg1 + 0x30);
    if (((piVar3 == piVar1) || (piVar8 = piVar3 + -1, piVar8 == (int64_t *)0x0)) || (0x1f < (uint64_t)piVar3[3])) {
        uVar4 = *(undefined8 *)arg1;
        piVar8 = (int64_t *)func_0x00018046d050(0x28);
        if (piVar8 == (int64_t *)0x0) {
            (*(code *)0x69a006)(8);
            puVar9 = (undefined4 *)fcn.18046b77c();
            *puVar9 = 0xc;
            piVar8 = (int64_t *)0x0;
        } else {
            var_48h._0_4_ = 0;
            piVar3 = piVar8 + 1;
            var_50h = 0;
            piVar8[3] = 0;
            var_58h._0_4_ = 0;
            piVar8[4] = 0;
            var_60h._0_4_ = 1;
            var_68h._0_4_ = 3;
            var_70h._0_4_ = 0;
            var_78h = 0;
            *piVar3 = (int64_t)piVar3;
            piVar8[2] = (int64_t)piVar3;
            *piVar8 = arg1;
            iVar6 = (**(code **)0x18077e218)(&var_38h, 0x100000, 0x18069c320, &var_30h);
            if (iVar6 == 0) {
                iVar10 = (*(code *)0x69a016)(var_38h, uVar4, 0, 0);
                if ((iVar10 != 0) && (iVar6 = (*(code *)0x69a102)(var_38h, 2), iVar6 != 0)) {
                    piVar8[3] = var_38h;
                    piVar8[2] = (int64_t)piVar1;
                    iVar10 = *piVar1;
                    *piVar3 = iVar10;
                    *(int64_t **)(iVar10 + 8) = piVar3;
                    *piVar1 = (int64_t)piVar3;
                    goto code_r0x00018018dd64;
                }
                (*(code *)0x699d92)(var_38h);
                uVar7 = (*(code *)0x699ff6)();
                uVar7 = fcn.18018d4d0(uVar7);
                puVar9 = (undefined4 *)fcn.18046b77c();
                *puVar9 = uVar7;
            } else {
                uVar7 = (**(code **)0x18077e240)(iVar6);
                (*(code *)0x69a006)(uVar7);
                puVar9 = (undefined4 *)fcn.18046b77c();
                uVar7 = fcn.18018d4d0(uVar7);
                *puVar9 = uVar7;
            }
            func_0x000180460d90(piVar8);
            piVar8 = (int64_t *)0x0;
        }
code_r0x00018018dd64:
        if (piVar8 == (int64_t *)0x0) goto code_r0x00018018ddb7;
    }
    piVar8[4] = piVar8[4] + 1;
    if (piVar8[4] == 0x20) {
        ppiVar2 = (int64_t **)(piVar8 + 1);
        *(int64_t *)(piVar8[1] + 8) = piVar8[2];
        *(int64_t **)piVar8[2] = *ppiVar2;
        ppiVar5 = *(int64_t ***)(arg1 + 0x38);
        piVar8[2] = (int64_t)ppiVar5;
        *ppiVar2 = piVar1;
        *ppiVar5 = (int64_t *)ppiVar2;
        *(int64_t ***)(arg1 + 0x38) = ppiVar2;
    }
code_r0x00018018ddb7:
    fcn.180459870(var_20h ^ (uint64_t)auStack_98);
    return;
}

// ============================================================
// Function: FUN_18018dd64
// Address: 0x18018dd64
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18018dbe0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t **ppiVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    int64_t **ppiVar5;
    int32_t iVar6;
    undefined4 uVar7;
    int64_t *piVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_98 [32];
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_20h;
    
    var_20h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_98;
    piVar3 = *(int64_t **)(arg1 + 0x30);
    piVar1 = (int64_t *)(arg1 + 0x30);
    if (((piVar3 == piVar1) || (piVar8 = piVar3 + -1, piVar8 == (int64_t *)0x0)) || (0x1f < (uint64_t)piVar3[3])) {
        uVar4 = *(undefined8 *)arg1;
        piVar8 = (int64_t *)func_0x00018046d050(0x28);
        if (piVar8 == (int64_t *)0x0) {
            (*(code *)0x69a006)(8);
            puVar9 = (undefined4 *)fcn.18046b77c();
            *puVar9 = 0xc;
            piVar8 = (int64_t *)0x0;
        } else {
            var_48h._0_4_ = 0;
            piVar3 = piVar8 + 1;
            var_50h = 0;
            piVar8[3] = 0;
            var_58h._0_4_ = 0;
            piVar8[4] = 0;
            var_60h._0_4_ = 1;
            var_68h._0_4_ = 3;
            var_70h._0_4_ = 0;
            var_78h = 0;
            *piVar3 = (int64_t)piVar3;
            piVar8[2] = (int64_t)piVar3;
            *piVar8 = arg1;
            iVar6 = (**(code **)0x18077e218)(&var_38h, 0x100000, 0x18069c320, &var_30h);
            if (iVar6 == 0) {
                iVar10 = (*(code *)0x69a016)(var_38h, uVar4, 0, 0);
                if ((iVar10 != 0) && (iVar6 = (*(code *)0x69a102)(var_38h, 2), iVar6 != 0)) {
                    piVar8[3] = var_38h;
                    piVar8[2] = (int64_t)piVar1;
                    iVar10 = *piVar1;
                    *piVar3 = iVar10;
                    *(int64_t **)(iVar10 + 8) = piVar3;
                    *piVar1 = (int64_t)piVar3;
                    goto code_r0x00018018dd64;
                }
                (*(code *)0x699d92)(var_38h);
                uVar7 = (*(code *)0x699ff6)();
                uVar7 = fcn.18018d4d0(uVar7);
                puVar9 = (undefined4 *)fcn.18046b77c();
                *puVar9 = uVar7;
            } else {
                uVar7 = (**(code **)0x18077e240)(iVar6);
                (*(code *)0x69a006)(uVar7);
                puVar9 = (undefined4 *)fcn.18046b77c();
                uVar7 = fcn.18018d4d0(uVar7);
                *puVar9 = uVar7;
            }
            func_0x000180460d90(piVar8);
            piVar8 = (int64_t *)0x0;
        }
code_r0x00018018dd64:
        if (piVar8 == (int64_t *)0x0) goto code_r0x00018018ddb7;
    }
    piVar8[4] = piVar8[4] + 1;
    if (piVar8[4] == 0x20) {
        ppiVar2 = (int64_t **)(piVar8 + 1);
        *(int64_t *)(piVar8[1] + 8) = piVar8[2];
        *(int64_t **)piVar8[2] = *ppiVar2;
        ppiVar5 = *(int64_t ***)(arg1 + 0x38);
        piVar8[2] = (int64_t)ppiVar5;
        *ppiVar2 = piVar1;
        *ppiVar5 = (int64_t *)ppiVar2;
        *(int64_t ***)(arg1 + 0x38) = ppiVar2;
    }
code_r0x00018018ddb7:
    fcn.180459870(var_20h ^ (uint64_t)auStack_98);
    return;
}

// ============================================================
// Function: FUN_18018dd79
// Address: 0x18018dd79
// Size: 87 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18018dbe0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t **ppiVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    int64_t **ppiVar5;
    int32_t iVar6;
    undefined4 uVar7;
    int64_t *piVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_98 [32];
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_20h;
    
    var_20h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_98;
    piVar3 = *(int64_t **)(arg1 + 0x30);
    piVar1 = (int64_t *)(arg1 + 0x30);
    if (((piVar3 == piVar1) || (piVar8 = piVar3 + -1, piVar8 == (int64_t *)0x0)) || (0x1f < (uint64_t)piVar3[3])) {
        uVar4 = *(undefined8 *)arg1;
        piVar8 = (int64_t *)func_0x00018046d050(0x28);
        if (piVar8 == (int64_t *)0x0) {
            (*(code *)0x69a006)(8);
            puVar9 = (undefined4 *)fcn.18046b77c();
            *puVar9 = 0xc;
            piVar8 = (int64_t *)0x0;
        } else {
            var_48h._0_4_ = 0;
            piVar3 = piVar8 + 1;
            var_50h = 0;
            piVar8[3] = 0;
            var_58h._0_4_ = 0;
            piVar8[4] = 0;
            var_60h._0_4_ = 1;
            var_68h._0_4_ = 3;
            var_70h._0_4_ = 0;
            var_78h = 0;
            *piVar3 = (int64_t)piVar3;
            piVar8[2] = (int64_t)piVar3;
            *piVar8 = arg1;
            iVar6 = (**(code **)0x18077e218)(&var_38h, 0x100000, 0x18069c320, &var_30h);
            if (iVar6 == 0) {
                iVar10 = (*(code *)0x69a016)(var_38h, uVar4, 0, 0);
                if ((iVar10 != 0) && (iVar6 = (*(code *)0x69a102)(var_38h, 2), iVar6 != 0)) {
                    piVar8[3] = var_38h;
                    piVar8[2] = (int64_t)piVar1;
                    iVar10 = *piVar1;
                    *piVar3 = iVar10;
                    *(int64_t **)(iVar10 + 8) = piVar3;
                    *piVar1 = (int64_t)piVar3;
                    goto code_r0x00018018dd64;
                }
                (*(code *)0x699d92)(var_38h);
                uVar7 = (*(code *)0x699ff6)();
                uVar7 = fcn.18018d4d0(uVar7);
                puVar9 = (undefined4 *)fcn.18046b77c();
                *puVar9 = uVar7;
            } else {
                uVar7 = (**(code **)0x18077e240)(iVar6);
                (*(code *)0x69a006)(uVar7);
                puVar9 = (undefined4 *)fcn.18046b77c();
                uVar7 = fcn.18018d4d0(uVar7);
                *puVar9 = uVar7;
            }
            func_0x000180460d90(piVar8);
            piVar8 = (int64_t *)0x0;
        }
code_r0x00018018dd64:
        if (piVar8 == (int64_t *)0x0) goto code_r0x00018018ddb7;
    }
    piVar8[4] = piVar8[4] + 1;
    if (piVar8[4] == 0x20) {
        ppiVar2 = (int64_t **)(piVar8 + 1);
        *(int64_t *)(piVar8[1] + 8) = piVar8[2];
        *(int64_t **)piVar8[2] = *ppiVar2;
        ppiVar5 = *(int64_t ***)(arg1 + 0x38);
        piVar8[2] = (int64_t)ppiVar5;
        *ppiVar2 = piVar1;
        *ppiVar5 = (int64_t *)ppiVar2;
        *(int64_t ***)(arg1 + 0x38) = ppiVar2;
    }
code_r0x00018018ddb7:
    fcn.180459870(var_20h ^ (uint64_t)auStack_98);
    return;
}

// ============================================================
// Function: FUN_18018ddd0
// Address: 0x18018ddd0
// Size: 360 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18018ddd0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t **ppiVar1;
    undefined8 *puVar2;
    int64_t *piVar3;
    undefined4 *puVar4;
    undefined8 *puVar5;
    undefined8 uVar6;
    uint32_t uVar7;
    int32_t iVar8;
    int64_t **ppiVar9;
    int64_t var_8h;
    int64_t in_stack_00000018;
    int64_t in_stack_00000048;
    
    iVar8 = (int32_t)arg2;
    if (iVar8 == 1) {
        puVar5 = (undefined8 *)fcn.18018e620(in_stack_00000018, in_stack_00000048);
        if (puVar5 != (undefined8 *)0x0) {
            uVar7 = *(uint32_t *)arg4 | 0x18;
            *(uint32_t *)(puVar5 + 0x10) = uVar7;
            uVar6 = *(undefined8 *)(arg4 + 8);
code_r0x00018018dee6:
            puVar5[0xf] = uVar6;
            if (((~*(uint32_t *)((int64_t)puVar5 + 0x84) & uVar7 & 0x27df) != 0) &&
               (ppiVar9 = (int64_t **)(puVar5 + 6), (int64_t **)*ppiVar9 == ppiVar9)) {
                ppiVar1 = (int64_t **)(arg1 + 0x10);
                puVar5[7] = ppiVar1;
                piVar3 = *ppiVar1;
                *ppiVar9 = piVar3;
                piVar3[1] = (int64_t)ppiVar9;
                *ppiVar1 = (int64_t *)ppiVar9;
            }
            if (*(int64_t *)(arg1 + 0x98) != 0) {
                fcn.18018e0c0(arg1);
            }
            return 0;
        }
    } else {
        if (iVar8 == 2) {
            puVar2 = *(undefined8 **)(arg1 + 8);
            while (puVar2 != (undefined8 *)0x0) {
                if ((uint64_t)arg3 < (uint64_t)puVar2[3]) {
                    puVar2 = (undefined8 *)*puVar2;
                } else {
                    if ((uint64_t)arg3 <= (uint64_t)puVar2[3]) {
                        puVar5 = puVar2 + -8;
                        if (puVar5 == (undefined8 *)0x0) {
                            return 0xffffffff;
                        }
                        uVar7 = *(uint32_t *)arg4 | 0x18;
                        *(uint32_t *)(puVar2 + 8) = uVar7;
                        uVar6 = *(undefined8 *)(arg4 + 8);
                        goto code_r0x00018018dee6;
                    }
                    puVar2 = (undefined8 *)puVar2[1];
                }
            }
        } else {
            if (iVar8 != 3) {
                (*(code *)0x69a006)(0x57);
                puVar4 = (undefined4 *)fcn.18046b77c();
                *puVar4 = 0x16;
                return 0xffffffff;
            }
            puVar5 = *(undefined8 **)(arg1 + 8);
            while (puVar5 != (undefined8 *)0x0) {
                if ((uint64_t)arg3 < (uint64_t)puVar5[3]) {
                    puVar5 = (undefined8 *)*puVar5;
                } else {
                    if ((uint64_t)arg3 <= (uint64_t)puVar5[3]) {
                        if (puVar5 + -8 == (undefined8 *)0x0) {
                            return 0xffffffff;
                        }
                        fcn.18018e500(arg1, puVar5 + -8, 0);
                        return 0;
                    }
                    puVar5 = (undefined8 *)puVar5[1];
                }
            }
        }
        (*(code *)0x69a006)(0x490);
        puVar4 = (undefined4 *)fcn.18046b77c();
        *puVar4 = 2;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18018df40
// Address: 0x18018df40
// Size: 379 bytes
// ============================================================
uint64_t fcn.18018df40(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int32_t **ppiVar1;
    int32_t **ppiVar2;
    int32_t *piVar3;
    int32_t *piVar4;
    uint32_t uVar5;
    int32_t iVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    int32_t iVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    uint64_t uVar9;
    
    uVar12 = 0;
    uVar9 = uVar12;
    uVar11 = uVar12;
    if ((uint32_t)arg4 != 0) {
        do {
            piVar3 = *(int32_t **)(uVar9 * 0x20 + 8 + arg3);
            *(undefined8 *)(piVar3 + 0x21) = 0;
            iVar10 = (int32_t)uVar11;
            if (*(char *)(piVar3 + 0x23) == '\0') {
                uVar11 = uVar12;
                if (*piVar3 != -0x3ffffee0) {
                    if (*piVar3 < 0) {
                        uVar11 = 8;
                    } else {
                        uVar11 = 0;
                        if (piVar3[6] != 0) {
                            uVar8 = piVar3[10];
                            if ((uVar8 & 0x20) != 0) {
                                iVar6 = fcn.18018e500(arg1, piVar3, 0);
                                goto code_r0x00018018e09e;
                            }
                            uVar7 = -(uint32_t)((uVar8 & 0x81) != 0) & 0x41;
                            uVar5 = uVar7 | 0x82;
                            if ((uVar8 & 2) == 0) {
                                uVar5 = uVar7;
                            }
                            uVar7 = uVar5 | 0x304;
                            if ((uVar8 & 4) == 0) {
                                uVar7 = uVar5;
                            }
                            uVar5 = uVar7 | 0x2041;
                            if ((uVar8 & 8) == 0) {
                                uVar5 = uVar7;
                            }
                            uVar7 = uVar5 | 0x10;
                            if ((uVar8 & 0x10) == 0) {
                                uVar7 = uVar5;
                            }
                            uVar11 = (uint64_t)(uVar7 | 0x214d);
                            if ((uVar8 >> 8 & 1) == 0) {
                                uVar11 = (uint64_t)uVar7;
                            }
                        }
                    }
                }
                ppiVar1 = (int32_t **)(piVar3 + 0xc);
                if ((int32_t **)*ppiVar1 == ppiVar1) {
                    ppiVar2 = (int32_t **)(arg1 + 0x10);
                    *(int32_t ***)(piVar3 + 0xe) = ppiVar2;
                    piVar4 = *ppiVar2;
                    *ppiVar1 = piVar4;
                    *(int32_t ***)(piVar4 + 2) = ppiVar1;
                    *ppiVar2 = (int32_t *)ppiVar1;
                }
                uVar8 = piVar3[0x20] & (uint32_t)uVar11;
                iVar6 = 0;
                if (uVar8 != 0) {
                    if (piVar3[0x20] < 0) {
                        piVar3[0x20] = 0;
                    }
                    *(undefined8 *)(arg2 + 8 + (int64_t)iVar10 * 0x10) = *(undefined8 *)(piVar3 + 0x1e);
                    *(uint32_t *)(arg2 + (int64_t)iVar10 * 0x10) = uVar8;
                    iVar6 = 1;
                }
            } else {
                iVar6 = fcn.18018e500(arg1, piVar3, 0);
            }
code_r0x00018018e09e:
            uVar11 = (uint64_t)(uint32_t)(iVar10 + iVar6);
            uVar8 = (int32_t)uVar9 + 1;
            uVar9 = (uint64_t)uVar8;
        } while (uVar8 < (uint32_t)arg4);
    }
    return uVar11;
}

// ============================================================
// Function: FUN_18018e0c0
// Address: 0x18018e0c0
// Size: 86 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18018e0c0(int64_t arg1)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int32_t iVar3;
    int64_t var_8h;
    
    puVar1 = (undefined8 *)(arg1 + 0x10);
    puVar2 = (undefined8 *)*puVar1;
    while( true ) {
        if (puVar2 == puVar1) {
            return 0;
        }
        iVar3 = func_0x00018018e880(arg1, *(int64_t *)(arg1 + 0x18) + -0x30);
        if (iVar3 < 0) break;
        puVar2 = (undefined8 *)*puVar1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18018e120
// Address: 0x18018e120
// Size: 209 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18018e120(int64_t arg1)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg1 + 8);
    while (iVar1 != 0) {
        fcn.18018e500(arg1, iVar1 + -0x40, 1);
        iVar1 = *(int64_t *)(arg1 + 8);
    }
    while ((*(int64_t **)(int64_t *)(arg1 + 0x20) != (int64_t *)(arg1 + 0x20) && (*(int64_t *)(arg1 + 0x28) != 0))) {
        fcn.18018e500(arg1, *(int64_t *)(arg1 + 0x28) + -0x30, 1);
    }
    while ((*(int64_t **)(int64_t *)(arg1 + 0x30) != (int64_t *)(arg1 + 0x30) &&
           (piVar2 = *(int64_t **)(arg1 + 0x38), piVar2 != (int64_t *)0x0))) {
        (*(code *)0x699d92)(piVar2[2]);
        *(int64_t *)(*piVar2 + 8) = piVar2[1];
        *(int64_t *)piVar2[1] = *piVar2;
        *piVar2 = (int64_t)piVar2;
        piVar2[1] = (int64_t)piVar2;
        func_0x000180460d90(piVar2 + -1);
    }
    (*(code *)0x699f4c)(arg1 + 0x70);
    func_0x000180460d90(arg1);
    return 0;
}

// ============================================================
// Function: FUN_18018e200
// Address: 0x18018e200
// Size: 91 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2028h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2060h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2058h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2040h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2050h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2048h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.18018e200(int64_t arg_28h)
{
    undefined8 *puVar1;
    int64_t *piVar2;
    uint32_t uVar3;
    undefined8 *puVar4;
    undefined8 uVar5;
    int32_t iVar6;
    undefined4 uVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    int64_t arg3;
    int64_t iVar10;
    uint64_t uVar11;
    undefined8 *in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    int32_t iVar12;
    uint64_t in_R9;
    undefined8 unaff_R12;
    uint64_t uVar13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18018e20f;
    iVar8 = func_0x00018045a350();
    iVar8 = -iVar8;
    *(uint64_t *)(&stack0x00002028 + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8);
    *(int32_t *)((int64_t)&var_18h + iVar8) = in_R8D;
    iVar12 = (int32_t)in_R9;
    *(undefined8 *)((int64_t)&var_20h + iVar8) = in_RDX;
    if (in_R8D < 1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e246;
        (*(code *)0x69a006)(0x57);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e24b;
        puVar9 = (undefined4 *)fcn.18046b77c();
        *puVar9 = 0x16;
        goto code_r0x00018018e42f;
    }
    *(undefined8 *)(&stack0x00002060 + iVar8) = unaff_RBP;
    *(undefined8 *)(&stack0x00002058 + iVar8) = unaff_RDI;
    *(undefined8 *)(&stack0x00002040 + iVar8) = unaff_R15;
    if ((uint64_t)(int64_t)in_R8D < 0x101) {
code_r0x00018018e297:
        arg3 = (int64_t)&arg_28h + iVar8;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e287;
        arg3 = func_0x00018046d050((int64_t)in_R8D << 5);
        if (arg3 == 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar8) = 0x100;
            goto code_r0x00018018e297;
        }
    }
    *(undefined8 *)(&stack0x00002050 + iVar8) = unaff_R12;
    *(undefined8 *)(&stack0x00002048 + iVar8) = unaff_R14;
    if (iVar12 < 1) {
        uVar13 = 0;
        in_R9 = (uint64_t)-(uint32_t)(iVar12 != 0);
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e2b7;
        iVar10 = (*(code *)0x69a0dc)();
        in_R9 = in_R9 & 0xffffffff;
        uVar13 = iVar10 + iVar12;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e2d8;
    (*(code *)0x699f1c)(in_RCX + 0xe);
    puVar1 = in_RCX + 2;
    while( true ) {
        puVar4 = (undefined8 *)*puVar1;
        while (puVar4 != puVar1) {
            iVar10 = in_RCX[3];
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e300;
            iVar6 = func_0x00018018e880(in_RCX, iVar10 + -0x30);
            if (iVar6 < 0) goto code_r0x00018018e3c0;
            puVar4 = (undefined8 *)*puVar1;
        }
        piVar2 = in_RCX + 0x13;
        *piVar2 = *piVar2 + 1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e321;
        (*(code *)0x699f34)(in_RCX + 0xe);
        uVar5 = *in_RCX;
        *(undefined4 *)((int64_t)&var_10h + iVar8) = 0;
        *(int32_t *)((int64_t)&var_8h + iVar8) = (int32_t)in_R9;
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e344;
        iVar6 = (*(code *)0x69a030)(uVar5, arg3, *(undefined4 *)((int64_t)&var_18h + iVar8), 
                                    (int64_t)&var_18h + iVar8 + 4);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e350;
        (*(code *)0x699f1c)(in_RCX + 0xe);
        *piVar2 = *piVar2 + -1;
        if (iVar6 == 0) break;
        uVar3 = *(uint32_t *)((int64_t)&var_18h + iVar8 + 4);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e36d;
        iVar6 = fcn.18018df40((int64_t)in_RCX, *(int64_t *)((int64_t)&var_20h + iVar8), arg3, (uint64_t)uVar3);
        if ((iVar6 < 0) || (0 < iVar6)) goto code_r0x00018018e3c5;
        if (-1 < iVar12) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e384;
            uVar11 = (*(code *)0x69a0dc)();
            if (uVar13 <= uVar11) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e3a8;
                (*(code *)0x69a006)(0x102);
                goto code_r0x00018018e3c5;
            }
            in_R9 = (uint64_t)(uint32_t)((int32_t)uVar13 - (int32_t)uVar11);
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e3b0;
    uVar7 = (*(code *)0x699ff6)();
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e3b7;
    uVar7 = fcn.18018d4d0(uVar7);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e3be;
    puVar9 = (undefined4 *)fcn.18046b77c();
    *puVar9 = uVar7;
code_r0x00018018e3c0:
    iVar6 = -1;
code_r0x00018018e3c5:
    if (in_RCX[0x13] != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e3f4;
        fcn.18018e0c0((int64_t)in_RCX);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e3fe;
    (*(code *)0x699f34)(in_RCX + 0xe);
    if (arg3 != (int64_t)&arg_28h + iVar8) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e410;
        func_0x000180460d90(arg3);
    }
    if (iVar6 < 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e426;
        (*(code *)0x699ff6)();
    }
code_r0x00018018e42f:
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e43f;
    fcn.180459870(*(uint64_t *)(&stack0x00002028 + iVar8) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_18018e25b
// Address: 0x18018e25b
// Size: 401 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2028h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2060h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2058h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2040h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2050h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2048h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.18018e200(int64_t arg_28h)
{
    undefined8 *puVar1;
    int64_t *piVar2;
    uint32_t uVar3;
    undefined8 *puVar4;
    undefined8 uVar5;
    int32_t iVar6;
    undefined4 uVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    int64_t arg3;
    int64_t iVar10;
    uint64_t uVar11;
    undefined8 *in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    int32_t iVar12;
    uint64_t in_R9;
    undefined8 unaff_R12;
    uint64_t uVar13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18018e20f;
    iVar8 = func_0x00018045a350();
    iVar8 = -iVar8;
    *(uint64_t *)(&stack0x00002028 + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8);
    *(int32_t *)((int64_t)&var_18h + iVar8) = in_R8D;
    iVar12 = (int32_t)in_R9;
    *(undefined8 *)((int64_t)&var_20h + iVar8) = in_RDX;
    if (in_R8D < 1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e246;
        (*(code *)0x69a006)(0x57);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e24b;
        puVar9 = (undefined4 *)fcn.18046b77c();
        *puVar9 = 0x16;
        goto code_r0x00018018e42f;
    }
    *(undefined8 *)(&stack0x00002060 + iVar8) = unaff_RBP;
    *(undefined8 *)(&stack0x00002058 + iVar8) = unaff_RDI;
    *(undefined8 *)(&stack0x00002040 + iVar8) = unaff_R15;
    if ((uint64_t)(int64_t)in_R8D < 0x101) {
code_r0x00018018e297:
        arg3 = (int64_t)&arg_28h + iVar8;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e287;
        arg3 = func_0x00018046d050((int64_t)in_R8D << 5);
        if (arg3 == 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar8) = 0x100;
            goto code_r0x00018018e297;
        }
    }
    *(undefined8 *)(&stack0x00002050 + iVar8) = unaff_R12;
    *(undefined8 *)(&stack0x00002048 + iVar8) = unaff_R14;
    if (iVar12 < 1) {
        uVar13 = 0;
        in_R9 = (uint64_t)-(uint32_t)(iVar12 != 0);
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e2b7;
        iVar10 = (*(code *)0x69a0dc)();
        in_R9 = in_R9 & 0xffffffff;
        uVar13 = iVar10 + iVar12;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e2d8;
    (*(code *)0x699f1c)(in_RCX + 0xe);
    puVar1 = in_RCX + 2;
    while( true ) {
        puVar4 = (undefined8 *)*puVar1;
        while (puVar4 != puVar1) {
            iVar10 = in_RCX[3];
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e300;
            iVar6 = func_0x00018018e880(in_RCX, iVar10 + -0x30);
            if (iVar6 < 0) goto code_r0x00018018e3c0;
            puVar4 = (undefined8 *)*puVar1;
        }
        piVar2 = in_RCX + 0x13;
        *piVar2 = *piVar2 + 1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e321;
        (*(code *)0x699f34)(in_RCX + 0xe);
        uVar5 = *in_RCX;
        *(undefined4 *)((int64_t)&var_10h + iVar8) = 0;
        *(int32_t *)((int64_t)&var_8h + iVar8) = (int32_t)in_R9;
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e344;
        iVar6 = (*(code *)0x69a030)(uVar5, arg3, *(undefined4 *)((int64_t)&var_18h + iVar8), 
                                    (int64_t)&var_18h + iVar8 + 4);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e350;
        (*(code *)0x699f1c)(in_RCX + 0xe);
        *piVar2 = *piVar2 + -1;
        if (iVar6 == 0) break;
        uVar3 = *(uint32_t *)((int64_t)&var_18h + iVar8 + 4);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e36d;
        iVar6 = fcn.18018df40((int64_t)in_RCX, *(int64_t *)((int64_t)&var_20h + iVar8), arg3, (uint64_t)uVar3);
        if ((iVar6 < 0) || (0 < iVar6)) goto code_r0x00018018e3c5;
        if (-1 < iVar12) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e384;
            uVar11 = (*(code *)0x69a0dc)();
            if (uVar13 <= uVar11) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e3a8;
                (*(code *)0x69a006)(0x102);
                goto code_r0x00018018e3c5;
            }
            in_R9 = (uint64_t)(uint32_t)((int32_t)uVar13 - (int32_t)uVar11);
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e3b0;
    uVar7 = (*(code *)0x699ff6)();
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e3b7;
    uVar7 = fcn.18018d4d0(uVar7);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e3be;
    puVar9 = (undefined4 *)fcn.18046b77c();
    *puVar9 = uVar7;
code_r0x00018018e3c0:
    iVar6 = -1;
code_r0x00018018e3c5:
    if (in_RCX[0x13] != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e3f4;
        fcn.18018e0c0((int64_t)in_RCX);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e3fe;
    (*(code *)0x699f34)(in_RCX + 0xe);
    if (arg3 != (int64_t)&arg_28h + iVar8) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e410;
        func_0x000180460d90(arg3);
    }
    if (iVar6 < 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e426;
        (*(code *)0x699ff6)();
    }
code_r0x00018018e42f:
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e43f;
    fcn.180459870(*(uint64_t *)(&stack0x00002028 + iVar8) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_18018e3ec
// Address: 0x18018e3ec
// Size: 48 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2028h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2060h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2058h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2040h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2050h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2048h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.18018e200(int64_t arg_28h)
{
    undefined8 *puVar1;
    int64_t *piVar2;
    uint32_t uVar3;
    undefined8 *puVar4;
    undefined8 uVar5;
    int32_t iVar6;
    undefined4 uVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    int64_t arg3;
    int64_t iVar10;
    uint64_t uVar11;
    undefined8 *in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    int32_t iVar12;
    uint64_t in_R9;
    undefined8 unaff_R12;
    uint64_t uVar13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18018e20f;
    iVar8 = func_0x00018045a350();
    iVar8 = -iVar8;
    *(uint64_t *)(&stack0x00002028 + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8);
    *(int32_t *)((int64_t)&var_18h + iVar8) = in_R8D;
    iVar12 = (int32_t)in_R9;
    *(undefined8 *)((int64_t)&var_20h + iVar8) = in_RDX;
    if (in_R8D < 1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e246;
        (*(code *)0x69a006)(0x57);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e24b;
        puVar9 = (undefined4 *)fcn.18046b77c();
        *puVar9 = 0x16;
        goto code_r0x00018018e42f;
    }
    *(undefined8 *)(&stack0x00002060 + iVar8) = unaff_RBP;
    *(undefined8 *)(&stack0x00002058 + iVar8) = unaff_RDI;
    *(undefined8 *)(&stack0x00002040 + iVar8) = unaff_R15;
    if ((uint64_t)(int64_t)in_R8D < 0x101) {
code_r0x00018018e297:
        arg3 = (int64_t)&arg_28h + iVar8;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e287;
        arg3 = func_0x00018046d050((int64_t)in_R8D << 5);
        if (arg3 == 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar8) = 0x100;
            goto code_r0x00018018e297;
        }
    }
    *(undefined8 *)(&stack0x00002050 + iVar8) = unaff_R12;
    *(undefined8 *)(&stack0x00002048 + iVar8) = unaff_R14;
    if (iVar12 < 1) {
        uVar13 = 0;
        in_R9 = (uint64_t)-(uint32_t)(iVar12 != 0);
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e2b7;
        iVar10 = (*(code *)0x69a0dc)();
        in_R9 = in_R9 & 0xffffffff;
        uVar13 = iVar10 + iVar12;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e2d8;
    (*(code *)0x699f1c)(in_RCX + 0xe);
    puVar1 = in_RCX + 2;
    while( true ) {
        puVar4 = (undefined8 *)*puVar1;
        while (puVar4 != puVar1) {
            iVar10 = in_RCX[3];
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e300;
            iVar6 = func_0x00018018e880(in_RCX, iVar10 + -0x30);
            if (iVar6 < 0) goto code_r0x00018018e3c0;
            puVar4 = (undefined8 *)*puVar1;
        }
        piVar2 = in_RCX + 0x13;
        *piVar2 = *piVar2 + 1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e321;
        (*(code *)0x699f34)(in_RCX + 0xe);
        uVar5 = *in_RCX;
        *(undefined4 *)((int64_t)&var_10h + iVar8) = 0;
        *(int32_t *)((int64_t)&var_8h + iVar8) = (int32_t)in_R9;
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e344;
        iVar6 = (*(code *)0x69a030)(uVar5, arg3, *(undefined4 *)((int64_t)&var_18h + iVar8), 
                                    (int64_t)&var_18h + iVar8 + 4);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e350;
        (*(code *)0x699f1c)(in_RCX + 0xe);
        *piVar2 = *piVar2 + -1;
        if (iVar6 == 0) break;
        uVar3 = *(uint32_t *)((int64_t)&var_18h + iVar8 + 4);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e36d;
        iVar6 = fcn.18018df40((int64_t)in_RCX, *(int64_t *)((int64_t)&var_20h + iVar8), arg3, (uint64_t)uVar3);
        if ((iVar6 < 0) || (0 < iVar6)) goto code_r0x00018018e3c5;
        if (-1 < iVar12) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e384;
            uVar11 = (*(code *)0x69a0dc)();
            if (uVar13 <= uVar11) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e3a8;
                (*(code *)0x69a006)(0x102);
                goto code_r0x00018018e3c5;
            }
            in_R9 = (uint64_t)(uint32_t)((int32_t)uVar13 - (int32_t)uVar11);
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e3b0;
    uVar7 = (*(code *)0x699ff6)();
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e3b7;
    uVar7 = fcn.18018d4d0(uVar7);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e3be;
    puVar9 = (undefined4 *)fcn.18046b77c();
    *puVar9 = uVar7;
code_r0x00018018e3c0:
    iVar6 = -1;
code_r0x00018018e3c5:
    if (in_RCX[0x13] != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e3f4;
        fcn.18018e0c0((int64_t)in_RCX);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e3fe;
    (*(code *)0x699f34)(in_RCX + 0xe);
    if (arg3 != (int64_t)&arg_28h + iVar8) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e410;
        func_0x000180460d90(arg3);
    }
    if (iVar6 < 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e426;
        (*(code *)0x699ff6)();
    }
code_r0x00018018e42f:
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e43f;
    fcn.180459870(*(uint64_t *)(&stack0x00002028 + iVar8) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_18018e41c
// Address: 0x18018e41c
// Size: 47 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2028h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2060h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2058h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2040h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2050h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2048h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.18018e200(int64_t arg_28h)
{
    undefined8 *puVar1;
    int64_t *piVar2;
    uint32_t uVar3;
    undefined8 *puVar4;
    undefined8 uVar5;
    int32_t iVar6;
    undefined4 uVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    int64_t arg3;
    int64_t iVar10;
    uint64_t uVar11;
    undefined8 *in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    int32_t iVar12;
    uint64_t in_R9;
    undefined8 unaff_R12;
    uint64_t uVar13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18018e20f;
    iVar8 = func_0x00018045a350();
    iVar8 = -iVar8;
    *(uint64_t *)(&stack0x00002028 + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8);
    *(int32_t *)((int64_t)&var_18h + iVar8) = in_R8D;
    iVar12 = (int32_t)in_R9;
    *(undefined8 *)((int64_t)&var_20h + iVar8) = in_RDX;
    if (in_R8D < 1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e246;
        (*(code *)0x69a006)(0x57);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e24b;
        puVar9 = (undefined4 *)fcn.18046b77c();
        *puVar9 = 0x16;
        goto code_r0x00018018e42f;
    }
    *(undefined8 *)(&stack0x00002060 + iVar8) = unaff_RBP;
    *(undefined8 *)(&stack0x00002058 + iVar8) = unaff_RDI;
    *(undefined8 *)(&stack0x00002040 + iVar8) = unaff_R15;
    if ((uint64_t)(int64_t)in_R8D < 0x101) {
code_r0x00018018e297:
        arg3 = (int64_t)&arg_28h + iVar8;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e287;
        arg3 = func_0x00018046d050((int64_t)in_R8D << 5);
        if (arg3 == 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar8) = 0x100;
            goto code_r0x00018018e297;
        }
    }
    *(undefined8 *)(&stack0x00002050 + iVar8) = unaff_R12;
    *(undefined8 *)(&stack0x00002048 + iVar8) = unaff_R14;
    if (iVar12 < 1) {
        uVar13 = 0;
        in_R9 = (uint64_t)-(uint32_t)(iVar12 != 0);
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e2b7;
        iVar10 = (*(code *)0x69a0dc)();
        in_R9 = in_R9 & 0xffffffff;
        uVar13 = iVar10 + iVar12;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e2d8;
    (*(code *)0x699f1c)(in_RCX + 0xe);
    puVar1 = in_RCX + 2;
    while( true ) {
        puVar4 = (undefined8 *)*puVar1;
        while (puVar4 != puVar1) {
            iVar10 = in_RCX[3];
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e300;
            iVar6 = func_0x00018018e880(in_RCX, iVar10 + -0x30);
            if (iVar6 < 0) goto code_r0x00018018e3c0;
            puVar4 = (undefined8 *)*puVar1;
        }
        piVar2 = in_RCX + 0x13;
        *piVar2 = *piVar2 + 1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e321;
        (*(code *)0x699f34)(in_RCX + 0xe);
        uVar5 = *in_RCX;
        *(undefined4 *)((int64_t)&var_10h + iVar8) = 0;
        *(int32_t *)((int64_t)&var_8h + iVar8) = (int32_t)in_R9;
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e344;
        iVar6 = (*(code *)0x69a030)(uVar5, arg3, *(undefined4 *)((int64_t)&var_18h + iVar8), 
                                    (int64_t)&var_18h + iVar8 + 4);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e350;
        (*(code *)0x699f1c)(in_RCX + 0xe);
        *piVar2 = *piVar2 + -1;
        if (iVar6 == 0) break;
        uVar3 = *(uint32_t *)((int64_t)&var_18h + iVar8 + 4);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e36d;
        iVar6 = fcn.18018df40((int64_t)in_RCX, *(int64_t *)((int64_t)&var_20h + iVar8), arg3, (uint64_t)uVar3);
        if ((iVar6 < 0) || (0 < iVar6)) goto code_r0x00018018e3c5;
        if (-1 < iVar12) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e384;
            uVar11 = (*(code *)0x69a0dc)();
            if (uVar13 <= uVar11) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e3a8;
                (*(code *)0x69a006)(0x102);
                goto code_r0x00018018e3c5;
            }
            in_R9 = (uint64_t)(uint32_t)((int32_t)uVar13 - (int32_t)uVar11);
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e3b0;
    uVar7 = (*(code *)0x699ff6)();
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e3b7;
    uVar7 = fcn.18018d4d0(uVar7);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e3be;
    puVar9 = (undefined4 *)fcn.18046b77c();
    *puVar9 = uVar7;
code_r0x00018018e3c0:
    iVar6 = -1;
code_r0x00018018e3c5:
    if (in_RCX[0x13] != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e3f4;
        fcn.18018e0c0((int64_t)in_RCX);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e3fe;
    (*(code *)0x699f34)(in_RCX + 0xe);
    if (arg3 != (int64_t)&arg_28h + iVar8) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e410;
        func_0x000180460d90(arg3);
    }
    if (iVar6 < 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e426;
        (*(code *)0x699ff6)();
    }
code_r0x00018018e42f:
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18018e43f;
    fcn.180459870(*(uint64_t *)(&stack0x00002028 + iVar8) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_18018e450
// Address: 0x18018e450
// Size: 166 bytes
// ============================================================
void fcn.18018e450(int64_t arg1)
{
    int32_t iVar1;
    undefined4 uVar2;
    undefined4 *puVar3;
    undefined auStack_48 [32];
    int64_t var_28h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_48;
    if (*(int32_t *)arg1 == 0x103) {
        iVar1 = (**(code **)0x18077e210)(*(undefined8 *)(*(int64_t *)(arg1 + 0x68) + 0x18), arg1, &var_28h);
        if ((iVar1 != 0) && (iVar1 != -0x3ffffddb)) {
            uVar2 = (**(code **)0x18077e240)(iVar1);
            (*(code *)0x69a006)(uVar2);
            puVar3 = (undefined4 *)fcn.18046b77c();
            uVar2 = fcn.18018d4d0(uVar2);
            *puVar3 = uVar2;
            fcn.180459870(var_18h ^ (uint64_t)auStack_48);
            return;
        }
    }
    *(undefined4 *)(arg1 + 0x88) = 2;
    *(undefined4 *)(arg1 + 0x84) = 0;
    fcn.180459870(var_18h ^ (uint64_t)auStack_48);
    return;
}

// ============================================================
// Function: FUN_18018e500
// Address: 0x18018e500
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18018e500(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    int64_t *piVar2;
    int64_t **ppiVar3;
    char in_R8B;
    int64_t **ppiVar4;
    int64_t var_8h;
    int64_t var_20h;
    
    if (*(char *)(arg2 + 0x8c) == '\0') {
        if (*(int32_t *)(arg2 + 0x88) == 1) {
            fcn.18018e450(arg2);
        }
        puVar1 = (undefined8 *)(arg2 + 0x30);
        if (*(undefined8 **)(arg2 + 0x30) != puVar1) {
            (*(undefined8 **)(arg2 + 0x30))[1] = *(undefined8 *)(arg2 + 0x38);
            **(undefined8 **)(arg2 + 0x38) = *puVar1;
            *puVar1 = puVar1;
            *(undefined8 **)(arg2 + 0x38) = puVar1;
        }
        func_0x00018018ecd0(arg1 + 8, arg2 + 0x40);
        *(undefined *)(arg2 + 0x8c) = 1;
    }
    ppiVar3 = (int64_t **)(arg2 + 0x30);
    if ((in_R8B == '\0') && (*(int32_t *)(arg2 + 0x88) != 0)) {
        if ((int64_t **)*ppiVar3 == ppiVar3) {
            ppiVar4 = (int64_t **)(arg1 + 0x20);
            *(int64_t ***)(arg2 + 0x38) = ppiVar4;
            piVar2 = *ppiVar4;
            *ppiVar3 = piVar2;
            piVar2[1] = (int64_t)ppiVar3;
            *ppiVar4 = (int64_t *)ppiVar3;
            return 0;
        }
    } else {
        if ((int64_t **)*ppiVar3 != ppiVar3) {
            (*ppiVar3)[1] = (int64_t)*(int64_t **)(arg2 + 0x38);
            **(int64_t ***)(arg2 + 0x38) = *ppiVar3;
            *ppiVar3 = (int64_t *)ppiVar3;
            *(int64_t ***)(arg2 + 0x38) = ppiVar3;
        }
        piVar2 = *(int64_t **)(arg2 + 0x68);
        ppiVar3 = (int64_t **)(piVar2 + 1);
        piVar2[4] = piVar2[4] + -1;
        ppiVar4 = (int64_t **)(*piVar2 + 0x30);
        *(int64_t *)((int64_t)*ppiVar3 + 8) = piVar2[2];
        *(int64_t **)piVar2[2] = *ppiVar3;
        piVar2[2] = (int64_t)ppiVar4;
        piVar2 = *ppiVar4;
        *ppiVar3 = piVar2;
        piVar2[1] = (int64_t)ppiVar3;
        *ppiVar4 = (int64_t *)ppiVar3;
        func_0x000180460d90(arg2);
    }
    return 0;
}

// ============================================================
// Function: FUN_18018e513
// Address: 0x18018e513
// Size: 105 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18018e500(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    int64_t *piVar2;
    int64_t **ppiVar3;
    char in_R8B;
    int64_t **ppiVar4;
    int64_t var_8h;
    int64_t var_20h;
    
    if (*(char *)(arg2 + 0x8c) == '\0') {
        if (*(int32_t *)(arg2 + 0x88) == 1) {
            fcn.18018e450(arg2);
        }
        puVar1 = (undefined8 *)(arg2 + 0x30);
        if (*(undefined8 **)(arg2 + 0x30) != puVar1) {
            (*(undefined8 **)(arg2 + 0x30))[1] = *(undefined8 *)(arg2 + 0x38);
            **(undefined8 **)(arg2 + 0x38) = *puVar1;
            *puVar1 = puVar1;
            *(undefined8 **)(arg2 + 0x38) = puVar1;
        }
        func_0x00018018ecd0(arg1 + 8, arg2 + 0x40);
        *(undefined *)(arg2 + 0x8c) = 1;
    }
    ppiVar3 = (int64_t **)(arg2 + 0x30);
    if ((in_R8B == '\0') && (*(int32_t *)(arg2 + 0x88) != 0)) {
        if ((int64_t **)*ppiVar3 == ppiVar3) {
            ppiVar4 = (int64_t **)(arg1 + 0x20);
            *(int64_t ***)(arg2 + 0x38) = ppiVar4;
            piVar2 = *ppiVar4;
            *ppiVar3 = piVar2;
            piVar2[1] = (int64_t)ppiVar3;
            *ppiVar4 = (int64_t *)ppiVar3;
            return 0;
        }
    } else {
        if ((int64_t **)*ppiVar3 != ppiVar3) {
            (*ppiVar3)[1] = (int64_t)*(int64_t **)(arg2 + 0x38);
            **(int64_t ***)(arg2 + 0x38) = *ppiVar3;
            *ppiVar3 = (int64_t *)ppiVar3;
            *(int64_t ***)(arg2 + 0x38) = ppiVar3;
        }
        piVar2 = *(int64_t **)(arg2 + 0x68);
        ppiVar3 = (int64_t **)(piVar2 + 1);
        piVar2[4] = piVar2[4] + -1;
        ppiVar4 = (int64_t **)(*piVar2 + 0x30);
        *(int64_t *)((int64_t)*ppiVar3 + 8) = piVar2[2];
        *(int64_t **)piVar2[2] = *ppiVar3;
        piVar2[2] = (int64_t)ppiVar4;
        piVar2 = *ppiVar4;
        *ppiVar3 = piVar2;
        piVar2[1] = (int64_t)ppiVar3;
        *ppiVar4 = (int64_t *)ppiVar3;
        func_0x000180460d90(arg2);
    }
    return 0;
}

// ============================================================
// Function: FUN_18018e57c
// Address: 0x18018e57c
// Size: 159 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18018e500(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    int64_t *piVar2;
    int64_t **ppiVar3;
    char in_R8B;
    int64_t **ppiVar4;
    int64_t var_8h;
    int64_t var_20h;
    
    if (*(char *)(arg2 + 0x8c) == '\0') {
        if (*(int32_t *)(arg2 + 0x88) == 1) {
            fcn.18018e450(arg2);
        }
        puVar1 = (undefined8 *)(arg2 + 0x30);
        if (*(undefined8 **)(arg2 + 0x30) != puVar1) {
            (*(undefined8 **)(arg2 + 0x30))[1] = *(undefined8 *)(arg2 + 0x38);
            **(undefined8 **)(arg2 + 0x38) = *puVar1;
            *puVar1 = puVar1;
            *(undefined8 **)(arg2 + 0x38) = puVar1;
        }
        func_0x00018018ecd0(arg1 + 8, arg2 + 0x40);
        *(undefined *)(arg2 + 0x8c) = 1;
    }
    ppiVar3 = (int64_t **)(arg2 + 0x30);
    if ((in_R8B == '\0') && (*(int32_t *)(arg2 + 0x88) != 0)) {
        if ((int64_t **)*ppiVar3 == ppiVar3) {
            ppiVar4 = (int64_t **)(arg1 + 0x20);
            *(int64_t ***)(arg2 + 0x38) = ppiVar4;
            piVar2 = *ppiVar4;
            *ppiVar3 = piVar2;
            piVar2[1] = (int64_t)ppiVar3;
            *ppiVar4 = (int64_t *)ppiVar3;
            return 0;
        }
    } else {
        if ((int64_t **)*ppiVar3 != ppiVar3) {
            (*ppiVar3)[1] = (int64_t)*(int64_t **)(arg2 + 0x38);
            **(int64_t ***)(arg2 + 0x38) = *ppiVar3;
            *ppiVar3 = (int64_t *)ppiVar3;
            *(int64_t ***)(arg2 + 0x38) = ppiVar3;
        }
        piVar2 = *(int64_t **)(arg2 + 0x68);
        ppiVar3 = (int64_t **)(piVar2 + 1);
        piVar2[4] = piVar2[4] + -1;
        ppiVar4 = (int64_t **)(*piVar2 + 0x30);
        *(int64_t *)((int64_t)*ppiVar3 + 8) = piVar2[2];
        *(int64_t **)piVar2[2] = *ppiVar3;
        piVar2[2] = (int64_t)ppiVar4;
        piVar2 = *ppiVar4;
        *ppiVar3 = piVar2;
        piVar2[1] = (int64_t)ppiVar3;
        *ppiVar4 = (int64_t *)ppiVar3;
        func_0x000180460d90(arg2);
    }
    return 0;
}

// ============================================================
// Function: FUN_18018e620
// Address: 0x18018e620
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

undefined (*) [16] fcn.18018e620(int64_t arg1, int64_t arg2, int64_t arg_48h, int64_t arg_78h)
{
    int64_t **ppiVar1;
    int32_t iVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t *piVar5;
    undefined (*pauVar6) [16];
    undefined (*pauVar7) [16];
    undefined4 *puVar8;
    int64_t iVar9;
    int64_t **ppiVar10;
    bool bVar11;
    int64_t var_10h;
    undefined auStackX_18 [8];
    int64_t iStackX_20;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar9 = arg2;
    if (0xfffffffffffffffd < arg2 - 1U) {
        (*(code *)0x69a006)(6);
        puVar8 = (undefined4 *)fcn.18046b77c();
        *puVar8 = 9;
        return (undefined (*) [16])0x0;
    }
    do {
        iVar2 = (*(code *)0x69aa36)(iVar9, 0x48000022, 0, 0, &iStackX_20, 8, &var_10h, 0, 0);
        if ((iVar2 != -1) && (iStackX_20 != -1)) {
            piVar5 = (int64_t *)fcn.18018dbe0(arg1);
            if (piVar5 == (int64_t *)0x0) {
                return (undefined (*) [16])0x0;
            }
            pauVar6 = (undefined (*) [16])func_0x00018046d050(0x90);
            if (pauVar6 == (undefined (*) [16])0x0) {
                (*(code *)0x69a006)(8);
                puVar8 = (undefined4 *)fcn.18046b77c();
                *puVar8 = 0xc;
            } else {
                *pauVar6 = ZEXT816(0);
                pauVar6[1] = ZEXT816(0);
                pauVar6[2] = ZEXT816(0);
                pauVar6[3] = ZEXT816(0);
                pauVar6[4] = ZEXT816(0);
                pauVar6[5] = ZEXT816(0);
                pauVar6[6] = ZEXT816(0);
                pauVar6[7] = ZEXT816(0);
                pauVar6[8] = ZEXT816(0);
                *(int64_t *)pauVar6[7] = iStackX_20;
                *(int64_t **)(pauVar6[6] + 8) = piVar5;
                pauVar7 = pauVar6 + 3;
                *(undefined (**) [16])*pauVar7 = pauVar7;
                *(undefined (**) [16])(pauVar6[3] + 8) = pauVar7;
                iVar2 = func_0x00018018eb20(arg1 + 8, pauVar6 + 4, arg2);
                if (-1 < iVar2) {
                    return pauVar6;
                }
                (*(code *)0x69a006)(0xb7);
                puVar8 = (undefined4 *)fcn.18046b77c();
                *puVar8 = 0x11;
                func_0x000180460d90(pauVar6);
            }
            ppiVar1 = (int64_t **)(piVar5 + 1);
            ppiVar10 = (int64_t **)(*piVar5 + 0x30);
            piVar5[4] = piVar5[4] + -1;
            *(int64_t *)(piVar5[1] + 8) = piVar5[2];
            *(int64_t **)piVar5[2] = *ppiVar1;
            piVar5[2] = (int64_t)ppiVar10;
            piVar5 = *ppiVar10;
            *ppiVar1 = piVar5;
            piVar5[1] = (int64_t)ppiVar1;
            *ppiVar10 = (int64_t *)ppiVar1;
            return (undefined (*) [16])0x0;
        }
        iVar2 = (*(code *)0x699ff6)();
        if (iVar2 == 0x2736) {
            (*(code *)0x69a006)(0x2736);
            puVar8 = (undefined4 *)fcn.18046b77c();
            uVar4 = fcn.18018d4d0(0x2736);
            *puVar8 = uVar4;
            return (undefined (*) [16])0x0;
        }
        iVar3 = (*(code *)0x69aa36)(iVar9, 0x4800001d, 0, 0, &var_38h, 8, auStackX_18, 0, 0);
    } while (((iVar3 != -1) && (var_38h != -1)) && (bVar11 = var_38h != iVar9, iVar9 = var_38h, bVar11));
    (*(code *)0x69a006)(iVar2);
    puVar8 = (undefined4 *)fcn.18046b77c();
    uVar4 = fcn.18018d4d0(iVar2);
    *puVar8 = uVar4;
    return (undefined (*) [16])0x0;
}

// ============================================================
// Function: FUN_18018e63c
// Address: 0x18018e63c
// Size: 475 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

undefined (*) [16] fcn.18018e620(int64_t arg1, int64_t arg2, int64_t arg_48h, int64_t arg_78h)
{
    int64_t **ppiVar1;
    int32_t iVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t *piVar5;
    undefined (*pauVar6) [16];
    undefined (*pauVar7) [16];
    undefined4 *puVar8;
    int64_t iVar9;
    int64_t **ppiVar10;
    bool bVar11;
    int64_t var_10h;
    undefined auStackX_18 [8];
    int64_t iStackX_20;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar9 = arg2;
    if (0xfffffffffffffffd < arg2 - 1U) {
        (*(code *)0x69a006)(6);
        puVar8 = (undefined4 *)fcn.18046b77c();
        *puVar8 = 9;
        return (undefined (*) [16])0x0;
    }
    do {
        iVar2 = (*(code *)0x69aa36)(iVar9, 0x48000022, 0, 0, &iStackX_20, 8, &var_10h, 0, 0);
        if ((iVar2 != -1) && (iStackX_20 != -1)) {
            piVar5 = (int64_t *)fcn.18018dbe0(arg1);
            if (piVar5 == (int64_t *)0x0) {
                return (undefined (*) [16])0x0;
            }
            pauVar6 = (undefined (*) [16])func_0x00018046d050(0x90);
            if (pauVar6 == (undefined (*) [16])0x0) {
                (*(code *)0x69a006)(8);
                puVar8 = (undefined4 *)fcn.18046b77c();
                *puVar8 = 0xc;
            } else {
                *pauVar6 = ZEXT816(0);
                pauVar6[1] = ZEXT816(0);
                pauVar6[2] = ZEXT816(0);
                pauVar6[3] = ZEXT816(0);
                pauVar6[4] = ZEXT816(0);
                pauVar6[5] = ZEXT816(0);
                pauVar6[6] = ZEXT816(0);
                pauVar6[7] = ZEXT816(0);
                pauVar6[8] = ZEXT816(0);
                *(int64_t *)pauVar6[7] = iStackX_20;
                *(int64_t **)(pauVar6[6] + 8) = piVar5;
                pauVar7 = pauVar6 + 3;
                *(undefined (**) [16])*pauVar7 = pauVar7;
                *(undefined (**) [16])(pauVar6[3] + 8) = pauVar7;
                iVar2 = func_0x00018018eb20(arg1 + 8, pauVar6 + 4, arg2);
                if (-1 < iVar2) {
                    return pauVar6;
                }
                (*(code *)0x69a006)(0xb7);
                puVar8 = (undefined4 *)fcn.18046b77c();
                *puVar8 = 0x11;
                func_0x000180460d90(pauVar6);
            }
            ppiVar1 = (int64_t **)(piVar5 + 1);
            ppiVar10 = (int64_t **)(*piVar5 + 0x30);
            piVar5[4] = piVar5[4] + -1;
            *(int64_t *)(piVar5[1] + 8) = piVar5[2];
            *(int64_t **)piVar5[2] = *ppiVar1;
            piVar5[2] = (int64_t)ppiVar10;
            piVar5 = *ppiVar10;
            *ppiVar1 = piVar5;
            piVar5[1] = (int64_t)ppiVar1;
            *ppiVar10 = (int64_t *)ppiVar1;
            return (undefined (*) [16])0x0;
        }
        iVar2 = (*(code *)0x699ff6)();
        if (iVar2 == 0x2736) {
            (*(code *)0x69a006)(0x2736);
            puVar8 = (undefined4 *)fcn.18046b77c();
            uVar4 = fcn.18018d4d0(0x2736);
            *puVar8 = uVar4;
            return (undefined (*) [16])0x0;
        }
        iVar3 = (*(code *)0x69aa36)(iVar9, 0x4800001d, 0, 0, &var_38h, 8, auStackX_18, 0, 0);
    } while (((iVar3 != -1) && (var_38h != -1)) && (bVar11 = var_38h != iVar9, iVar9 = var_38h, bVar11));
    (*(code *)0x69a006)(iVar2);
    puVar8 = (undefined4 *)fcn.18046b77c();
    uVar4 = fcn.18018d4d0(iVar2);
    *puVar8 = uVar4;
    return (undefined (*) [16])0x0;
}

// ============================================================
// Function: FUN_18018e817
// Address: 0x18018e817
// Size: 71 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

undefined (*) [16] fcn.18018e620(int64_t arg1, int64_t arg2, int64_t arg_48h, int64_t arg_78h)
{
    int64_t **ppiVar1;
    int32_t iVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t *piVar5;
    undefined (*pauVar6) [16];
    undefined (*pauVar7) [16];
    undefined4 *puVar8;
    int64_t iVar9;
    int64_t **ppiVar10;
    bool bVar11;
    int64_t var_10h;
    undefined auStackX_18 [8];
    int64_t iStackX_20;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar9 = arg2;
    if (0xfffffffffffffffd < arg2 - 1U) {
        (*(code *)0x69a006)(6);
        puVar8 = (undefined4 *)fcn.18046b77c();
        *puVar8 = 9;
        return (undefined (*) [16])0x0;
    }
    do {
        iVar2 = (*(code *)0x69aa36)(iVar9, 0x48000022, 0, 0, &iStackX_20, 8, &var_10h, 0, 0);
        if ((iVar2 != -1) && (iStackX_20 != -1)) {
            piVar5 = (int64_t *)fcn.18018dbe0(arg1);
            if (piVar5 == (int64_t *)0x0) {
                return (undefined (*) [16])0x0;
            }
            pauVar6 = (undefined (*) [16])func_0x00018046d050(0x90);
            if (pauVar6 == (undefined (*) [16])0x0) {
                (*(code *)0x69a006)(8);
                puVar8 = (undefined4 *)fcn.18046b77c();
                *puVar8 = 0xc;
            } else {
                *pauVar6 = ZEXT816(0);
                pauVar6[1] = ZEXT816(0);
                pauVar6[2] = ZEXT816(0);
                pauVar6[3] = ZEXT816(0);
                pauVar6[4] = ZEXT816(0);
                pauVar6[5] = ZEXT816(0);
                pauVar6[6] = ZEXT816(0);
                pauVar6[7] = ZEXT816(0);
                pauVar6[8] = ZEXT816(0);
                *(int64_t *)pauVar6[7] = iStackX_20;
                *(int64_t **)(pauVar6[6] + 8) = piVar5;
                pauVar7 = pauVar6 + 3;
                *(undefined (**) [16])*pauVar7 = pauVar7;
                *(undefined (**) [16])(pauVar6[3] + 8) = pauVar7;
                iVar2 = func_0x00018018eb20(arg1 + 8, pauVar6 + 4, arg2);
                if (-1 < iVar2) {
                    return pauVar6;
                }
                (*(code *)0x69a006)(0xb7);
                puVar8 = (undefined4 *)fcn.18046b77c();
                *puVar8 = 0x11;
                func_0x000180460d90(pauVar6);
            }
            ppiVar1 = (int64_t **)(piVar5 + 1);
            ppiVar10 = (int64_t **)(*piVar5 + 0x30);
            piVar5[4] = piVar5[4] + -1;
            *(int64_t *)(piVar5[1] + 8) = piVar5[2];
            *(int64_t **)piVar5[2] = *ppiVar1;
            piVar5[2] = (int64_t)ppiVar10;
            piVar5 = *ppiVar10;
            *ppiVar1 = piVar5;
            piVar5[1] = (int64_t)ppiVar1;
            *ppiVar10 = (int64_t *)ppiVar1;
            return (undefined (*) [16])0x0;
        }
        iVar2 = (*(code *)0x699ff6)();
        if (iVar2 == 0x2736) {
            (*(code *)0x69a006)(0x2736);
            puVar8 = (undefined4 *)fcn.18046b77c();
            uVar4 = fcn.18018d4d0(0x2736);
            *puVar8 = uVar4;
            return (undefined (*) [16])0x0;
        }
        iVar3 = (*(code *)0x69aa36)(iVar9, 0x4800001d, 0, 0, &var_38h, 8, auStackX_18, 0, 0);
    } while (((iVar3 != -1) && (var_38h != -1)) && (bVar11 = var_38h != iVar9, iVar9 = var_38h, bVar11));
    (*(code *)0x69a006)(iVar2);
    puVar8 = (undefined4 *)fcn.18046b77c();
    uVar4 = fcn.18018d4d0(iVar2);
    *puVar8 = uVar4;
    return (undefined (*) [16])0x0;
}

// ============================================================
// Function: FUN_18018e85e
// Address: 0x18018e85e
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

undefined (*) [16] fcn.18018e620(int64_t arg1, int64_t arg2, int64_t arg_48h, int64_t arg_78h)
{
    int64_t **ppiVar1;
    int32_t iVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t *piVar5;
    undefined (*pauVar6) [16];
    undefined (*pauVar7) [16];
    undefined4 *puVar8;
    int64_t iVar9;
    int64_t **ppiVar10;
    bool bVar11;
    int64_t var_10h;
    undefined auStackX_18 [8];
    int64_t iStackX_20;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar9 = arg2;
    if (0xfffffffffffffffd < arg2 - 1U) {
        (*(code *)0x69a006)(6);
        puVar8 = (undefined4 *)fcn.18046b77c();
        *puVar8 = 9;
        return (undefined (*) [16])0x0;
    }
    do {
        iVar2 = (*(code *)0x69aa36)(iVar9, 0x48000022, 0, 0, &iStackX_20, 8, &var_10h, 0, 0);
        if ((iVar2 != -1) && (iStackX_20 != -1)) {
            piVar5 = (int64_t *)fcn.18018dbe0(arg1);
            if (piVar5 == (int64_t *)0x0) {
                return (undefined (*) [16])0x0;
            }
            pauVar6 = (undefined (*) [16])func_0x00018046d050(0x90);
            if (pauVar6 == (undefined (*) [16])0x0) {
                (*(code *)0x69a006)(8);
                puVar8 = (undefined4 *)fcn.18046b77c();
                *puVar8 = 0xc;
            } else {
                *pauVar6 = ZEXT816(0);
                pauVar6[1] = ZEXT816(0);
                pauVar6[2] = ZEXT816(0);
                pauVar6[3] = ZEXT816(0);
                pauVar6[4] = ZEXT816(0);
                pauVar6[5] = ZEXT816(0);
                pauVar6[6] = ZEXT816(0);
                pauVar6[7] = ZEXT816(0);
                pauVar6[8] = ZEXT816(0);
                *(int64_t *)pauVar6[7] = iStackX_20;
                *(int64_t **)(pauVar6[6] + 8) = piVar5;
                pauVar7 = pauVar6 + 3;
                *(undefined (**) [16])*pauVar7 = pauVar7;
                *(undefined (**) [16])(pauVar6[3] + 8) = pauVar7;
                iVar2 = func_0x00018018eb20(arg1 + 8, pauVar6 + 4, arg2);
                if (-1 < iVar2) {
                    return pauVar6;
                }
                (*(code *)0x69a006)(0xb7);
                puVar8 = (undefined4 *)fcn.18046b77c();
                *puVar8 = 0x11;
                func_0x000180460d90(pauVar6);
            }
            ppiVar1 = (int64_t **)(piVar5 + 1);
            ppiVar10 = (int64_t **)(*piVar5 + 0x30);
            piVar5[4] = piVar5[4] + -1;
            *(int64_t *)(piVar5[1] + 8) = piVar5[2];
            *(int64_t **)piVar5[2] = *ppiVar1;
            piVar5[2] = (int64_t)ppiVar10;
            piVar5 = *ppiVar10;
            *ppiVar1 = piVar5;
            piVar5[1] = (int64_t)ppiVar1;
            *ppiVar10 = (int64_t *)ppiVar1;
            return (undefined (*) [16])0x0;
        }
        iVar2 = (*(code *)0x699ff6)();
        if (iVar2 == 0x2736) {
            (*(code *)0x69a006)(0x2736);
            puVar8 = (undefined4 *)fcn.18046b77c();
            uVar4 = fcn.18018d4d0(0x2736);
            *puVar8 = uVar4;
            return (undefined (*) [16])0x0;
        }
        iVar3 = (*(code *)0x69aa36)(iVar9, 0x4800001d, 0, 0, &var_38h, 8, auStackX_18, 0, 0);
    } while (((iVar3 != -1) && (var_38h != -1)) && (bVar11 = var_38h != iVar9, iVar9 = var_38h, bVar11));
    (*(code *)0x69a006)(iVar2);
    puVar8 = (undefined4 *)fcn.18046b77c();
    uVar4 = fcn.18018d4d0(iVar2);
    *puVar8 = uVar4;
    return (undefined (*) [16])0x0;
}

// ============================================================
// Function: FUN_18018e880
// Address: 0x18018e880
// Size: 543 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18018e880(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    undefined8 uVar2;
    uint32_t uVar3;
    int32_t iVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    undefined4 *puVar7;
    uint32_t uVar8;
    int64_t **ppiVar9;
    undefined8 *puVar10;
    int64_t **ppiVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(int32_t *)(arg2 + 0x88) == 1) {
        if (((~*(uint32_t *)(arg2 + 0x84) & *(uint32_t *)(arg2 + 0x80) & 0x27df) != 0) &&
           (iVar4 = fcn.18018e450(arg2), iVar4 < 0)) {
            return 0xffffffff;
        }
    } else if (*(int32_t *)(arg2 + 0x88) == 0) {
        *(undefined8 *)(arg2 + 0x18) = 1;
        *(undefined4 *)(arg2 + 0x2c) = 0;
        puVar10 = (undefined8 *)(arg2 + 0x10);
        *puVar10 = 0x7fffffffffffffff;
        *(undefined8 *)(arg2 + 0x20) = *(undefined8 *)(arg2 + 0x70);
        uVar5 = *(uint32_t *)(arg2 + 0x80);
        uVar8 = 0xa1;
        if ((uVar5 & 0x41) == 0) {
            uVar8 = 0x20;
        }
        uVar3 = uVar8 | 2;
        if ((uVar5 & 0x82) == 0) {
            uVar3 = uVar8;
        }
        uVar8 = uVar3 | 4;
        if ((uVar5 & 0x304) == 0) {
            uVar8 = uVar3;
        }
        uVar3 = uVar8 | 8;
        if ((uVar5 & 0x2041) == 0) {
            uVar3 = uVar8;
        }
        uVar8 = uVar3 | 0x10;
        if ((uVar5 & 0x10) == 0) {
            uVar8 = uVar3;
        }
        uVar5 = uVar8 | 0x100;
        if ((*(uint8_t *)(arg2 + 0x80) & 8) == 0) {
            uVar5 = uVar8;
        }
        *(uint32_t *)(arg2 + 0x28) = uVar5;
        uVar2 = *(undefined8 *)(*(int64_t *)(arg2 + 0x68) + 0x18);
        *(undefined4 *)arg2 = 0x103;
        iVar4 = (**(code **)0x18077e228)(uVar2, 0, 0, arg2, arg2, 0x12024, puVar10, 0x20, puVar10, 0x20);
        if (iVar4 != 0) {
            if (iVar4 == 0x103) {
                (*(code *)0x69a006)(0x3e5);
                puVar7 = (undefined4 *)fcn.18046b77c();
                *puVar7 = 0x70;
            } else {
                uVar6 = (**(code **)0x18077e240)(iVar4);
                (*(code *)0x69a006)(uVar6);
                puVar7 = (undefined4 *)fcn.18046b77c();
                uVar6 = fcn.18018d4d0(uVar6);
                *puVar7 = uVar6;
            }
            iVar4 = (*(code *)0x699ff6)();
            if (iVar4 == 6) {
                if (*(char *)(arg2 + 0x8c) == '\0') {
                    if (*(int32_t *)(arg2 + 0x88) == 1) {
                        fcn.18018e450(arg2);
                    }
                    puVar10 = (undefined8 *)(arg2 + 0x30);
                    if (*(undefined8 **)(arg2 + 0x30) != puVar10) {
                        (*(undefined8 **)(arg2 + 0x30))[1] = *(undefined8 *)(arg2 + 0x38);
                        **(undefined8 **)(arg2 + 0x38) = *puVar10;
                        *puVar10 = puVar10;
                        *(undefined8 **)(arg2 + 0x38) = puVar10;
                    }
                    func_0x00018018ecd0(arg1 + 8, arg2 + 0x40);
                    *(undefined *)(arg2 + 0x8c) = 1;
                }
                ppiVar9 = (int64_t **)(arg2 + 0x30);
                if (*(int32_t *)(arg2 + 0x88) == 0) {
                    if ((int64_t **)*ppiVar9 != ppiVar9) {
                        (*ppiVar9)[1] = (int64_t)*(int64_t **)(arg2 + 0x38);
                        **(int64_t ***)(arg2 + 0x38) = *ppiVar9;
                        *ppiVar9 = (int64_t *)ppiVar9;
                        *(int64_t ***)(arg2 + 0x38) = ppiVar9;
                    }
                    piVar1 = *(int64_t **)(arg2 + 0x68);
                    ppiVar9 = (int64_t **)(piVar1 + 1);
                    piVar1[4] = piVar1[4] + -1;
                    ppiVar11 = (int64_t **)(*piVar1 + 0x30);
                    *(int64_t *)((int64_t)*ppiVar9 + 8) = piVar1[2];
                    *(int64_t **)piVar1[2] = *ppiVar9;
                    piVar1[2] = (int64_t)ppiVar11;
                    piVar1 = *ppiVar11;
                    *ppiVar9 = piVar1;
                    piVar1[1] = (int64_t)ppiVar9;
                    *ppiVar11 = (int64_t *)ppiVar9;
                    func_0x000180460d90(arg2);
                } else if ((int64_t **)*ppiVar9 == ppiVar9) {
                    ppiVar11 = (int64_t **)(arg1 + 0x20);
                    *(int64_t ***)(arg2 + 0x38) = ppiVar11;
                    piVar1 = *ppiVar11;
                    *ppiVar9 = piVar1;
                    piVar1[1] = (int64_t)ppiVar9;
                    *ppiVar11 = (int64_t *)ppiVar9;
                    return 0;
                }
                return 0;
            }
            if (iVar4 != 0x3e5) {
                uVar6 = (*(code *)0x699ff6)();
                uVar6 = fcn.18018d4d0(uVar6);
                puVar7 = (undefined4 *)fcn.18046b77c();
                *puVar7 = uVar6;
                return 0xffffffff;
            }
        }
        *(undefined4 *)(arg2 + 0x84) = *(undefined4 *)(arg2 + 0x80);
        *(undefined4 *)(arg2 + 0x88) = 1;
    }
    puVar10 = (undefined8 *)(arg2 + 0x30);
    if (*(undefined8 **)(arg2 + 0x30) != puVar10) {
        (*(undefined8 **)(arg2 + 0x30))[1] = *(undefined8 *)(arg2 + 0x38);
        **(undefined8 **)(arg2 + 0x38) = *puVar10;
        *puVar10 = puVar10;
        *(undefined8 **)(arg2 + 0x38) = puVar10;
    }
    return 0;
}

// ============================================================
// Function: FUN_18018ecd0
// Address: 0x18018ecd0
// Size: 768 bytes
// ============================================================
void fcn.18018ecd0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    char cVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    int64_t *piVar8;
    
    ppiVar4 = *(int64_t ***)arg2;
    ppiVar6 = *(int64_t ***)(arg2 + 0x10);
    ppiVar3 = *(int64_t ***)(arg2 + 8);
    ppiVar7 = ppiVar3;
    if ((ppiVar4 != (int64_t **)0x0) && (ppiVar7 = ppiVar4, ppiVar3 != (int64_t **)0x0)) {
        ppiVar7 = ppiVar3;
        for (ppiVar2 = (int64_t **)*ppiVar3; ppiVar2 != (int64_t **)0x0; ppiVar2 = (int64_t **)*ppiVar2) {
            ppiVar7 = ppiVar2;
        }
    }
    if (ppiVar6 == (int64_t **)0x0) {
        *(int64_t ***)arg1 = ppiVar7;
    } else if (*ppiVar6 == (int64_t *)arg2) {
        *ppiVar6 = (int64_t *)ppiVar7;
    } else {
        ppiVar6[1] = (int64_t *)ppiVar7;
    }
    if ((ppiVar4 == (int64_t **)0x0) || (ppiVar3 == (int64_t **)0x0)) {
        cVar5 = *(char *)(arg2 + 0x20);
        ppiVar4 = ppiVar7;
    } else {
        cVar5 = *(char *)(ppiVar7 + 4);
        *(undefined *)(ppiVar7 + 4) = *(undefined *)(arg2 + 0x20);
        *ppiVar7 = (int64_t *)ppiVar4;
        ppiVar4[2] = (int64_t *)ppiVar7;
        if (ppiVar7 == ppiVar3) {
            ppiVar7[2] = (int64_t *)ppiVar6;
            ppiVar4 = (int64_t **)ppiVar7[1];
            ppiVar6 = ppiVar7;
        } else {
            ppiVar6 = (int64_t **)ppiVar7[2];
            ppiVar7[2] = *(int64_t **)(arg2 + 0x10);
            ppiVar4 = (int64_t **)ppiVar7[1];
            *ppiVar6 = (int64_t *)ppiVar4;
            ppiVar7[1] = (int64_t *)ppiVar3;
            ppiVar3[2] = (int64_t *)ppiVar7;
        }
    }
    if (ppiVar4 != (int64_t **)0x0) {
        ppiVar4[2] = (int64_t *)ppiVar6;
    }
    if (cVar5 == '\0') {
        if ((ppiVar4 == (int64_t **)0x0) || (*(char *)(ppiVar4 + 4) == '\0')) {
            ppiVar3 = ppiVar4;
            if (ppiVar4 != *(int64_t ***)arg1) {
                do {
                    ppiVar4 = ppiVar6;
                    ppiVar6 = (int64_t **)*ppiVar4;
                    if (ppiVar3 != ppiVar6) {
                        if (*(char *)(ppiVar6 + 4) != '\0') {
                            *(undefined *)(ppiVar6 + 4) = 0;
                            ppiVar6 = (int64_t **)ppiVar4[2];
                            piVar8 = *ppiVar4;
                            *(undefined *)(ppiVar4 + 4) = 1;
                            if (ppiVar6 == (int64_t **)0x0) {
                                *(int64_t **)arg1 = piVar8;
                            } else if ((int64_t **)*ppiVar6 == ppiVar4) {
                                *ppiVar6 = piVar8;
                            } else {
                                ppiVar6[1] = piVar8;
                            }
                            piVar8[2] = (int64_t)ppiVar6;
                            ppiVar4[2] = piVar8;
                            piVar1 = (int64_t *)piVar8[1];
                            *ppiVar4 = piVar1;
                            if (piVar1 != (int64_t *)0x0) {
                                piVar1[2] = (int64_t)ppiVar4;
                            }
                            piVar8[1] = (int64_t)ppiVar4;
                            ppiVar6 = (int64_t **)*ppiVar4;
                        }
                        piVar8 = *ppiVar6;
                        if ((piVar8 == (int64_t *)0x0) || (*(char *)(piVar8 + 4) == '\0')) {
                            if ((ppiVar6[1] == (int64_t *)0x0) || (*(char *)(ppiVar6[1] + 4) == '\0'))
                            goto code_r0x00018018ef01;
                            if ((piVar8 == (int64_t *)0x0) || (*(char *)(piVar8 + 4) == '\0')) {
                                *(undefined *)(ppiVar6[1] + 4) = 0;
                                *(undefined *)(ppiVar6 + 4) = 1;
                                func_0x00018018eaa0(arg1);
                                ppiVar6 = (int64_t **)*ppiVar4;
                                piVar8 = *ppiVar6;
                            }
                        }
                        *(undefined *)(ppiVar6 + 4) = *(undefined *)(ppiVar4 + 4);
                        *(undefined *)(piVar8 + 4) = 0;
                        ppiVar6 = (int64_t **)ppiVar4[2];
                        piVar8 = *ppiVar4;
                        *(undefined *)(ppiVar4 + 4) = 0;
                        if (ppiVar6 == (int64_t **)0x0) {
                            *(int64_t **)arg1 = piVar8;
                        } else if ((int64_t **)*ppiVar6 == ppiVar4) {
                            *ppiVar6 = piVar8;
                        } else {
                            ppiVar6[1] = piVar8;
                        }
                        piVar8[2] = (int64_t)ppiVar6;
                        ppiVar4[2] = piVar8;
                        piVar1 = (int64_t *)piVar8[1];
                        *ppiVar4 = piVar1;
                        if (piVar1 != (int64_t *)0x0) {
                            piVar1[2] = (int64_t)ppiVar4;
                        }
                        piVar8[1] = (int64_t)ppiVar4;
code_r0x00018018efbe:
                        ppiVar4 = *(int64_t ***)arg1;
                        break;
                    }
                    ppiVar6 = (int64_t **)ppiVar4[1];
                    if (*(char *)(ppiVar6 + 4) != '\0') {
                        *(undefined *)(ppiVar6 + 4) = 0;
                        ppiVar6 = (int64_t **)ppiVar4[2];
                        ppiVar3 = (int64_t **)ppiVar4[1];
                        *(undefined *)(ppiVar4 + 4) = 1;
                        if (ppiVar6 == (int64_t **)0x0) {
                            *(int64_t ***)arg1 = ppiVar3;
                        } else if ((int64_t **)*ppiVar6 == ppiVar4) {
                            *ppiVar6 = (int64_t *)ppiVar3;
                        } else {
                            ppiVar6[1] = (int64_t *)ppiVar3;
                        }
                        ppiVar3[2] = (int64_t *)ppiVar6;
                        ppiVar4[2] = (int64_t *)ppiVar3;
                        piVar8 = *ppiVar3;
                        ppiVar4[1] = piVar8;
                        if (piVar8 != (int64_t *)0x0) {
                            piVar8[2] = (int64_t)ppiVar4;
                        }
                        *ppiVar3 = (int64_t *)ppiVar4;
                        ppiVar6 = (int64_t **)ppiVar4[1];
                    }
                    piVar8 = *ppiVar6 + 4;
                    if (((*ppiVar6 != (int64_t *)0x0) && (*(char *)piVar8 != '\0')) ||
                       ((ppiVar6[1] != (int64_t *)0x0 && (*(char *)(ppiVar6[1] + 4) != '\0')))) {
                        if ((ppiVar6[1] == (int64_t *)0x0) || (*(char *)(ppiVar6[1] + 4) == '\0')) {
                            *(char *)piVar8 = '\0';
                            *(undefined *)(ppiVar6 + 4) = 1;
                            func_0x00018018eae0(arg1);
                            ppiVar6 = (int64_t **)ppiVar4[1];
                        }
                        *(undefined *)(ppiVar6 + 4) = *(undefined *)(ppiVar4 + 4);
                        *(undefined *)(ppiVar6[1] + 4) = 0;
                        ppiVar6 = (int64_t **)ppiVar4[2];
                        ppiVar3 = (int64_t **)ppiVar4[1];
                        *(undefined *)(ppiVar4 + 4) = 0;
                        if (ppiVar6 == (int64_t **)0x0) {
                            *(int64_t ***)arg1 = ppiVar3;
                        } else if ((int64_t **)*ppiVar6 == ppiVar4) {
                            *ppiVar6 = (int64_t *)ppiVar3;
                        } else {
                            ppiVar6[1] = (int64_t *)ppiVar3;
                        }
                        ppiVar3[2] = (int64_t *)ppiVar6;
                        ppiVar4[2] = (int64_t *)ppiVar3;
                        piVar8 = *ppiVar3;
                        ppiVar4[1] = piVar8;
                        if (piVar8 != (int64_t *)0x0) {
                            piVar8[2] = (int64_t)ppiVar4;
                        }
                        *ppiVar3 = (int64_t *)ppiVar4;
                        goto code_r0x00018018efbe;
                    }
code_r0x00018018ef01:
                    *(undefined *)(ppiVar6 + 4) = 1;
                    if (*(char *)(ppiVar4 + 4) != '\0') goto code_r0x00018018efc6;
                    ppiVar3 = ppiVar4;
                    ppiVar6 = (int64_t **)ppiVar4[2];
                } while (ppiVar4 != *(int64_t ***)arg1);
            }
            if (ppiVar4 == (int64_t **)0x0) {
                return;
            }
        }
code_r0x00018018efc6:
        *(undefined *)(ppiVar4 + 4) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18018efd0
// Address: 0x18018efd0
// Size: 60 bytes
// ============================================================
void fcn.18018efd0(int64_t arg1)
{
    int32_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    
    piVar1 = (int32_t *)(arg1 + 0x28);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 0x10000001) {
        iVar3 = (**(code **)0x18077e230)(*(undefined8 *)0x18077e268, piVar1, 0, 0);
        if (iVar3 != 0) {
            fcn.180473b90();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18018f030
// Address: 0x18018f030
// Size: 218 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

uint8_t * fcn.18018f030(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    uint8_t *puVar1;
    char cVar2;
    int64_t iVar3;
    int32_t iVar4;
    uint32_t uVar5;
    int32_t iVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    uint8_t uVar13;
    uint8_t *puVar14;
    uint8_t uVar15;
    uint32_t uVar16;
    uint32_t uVar17;
    uint8_t *puVar18;
    uint32_t uVar19;
    uint32_t uVar20;
    uint8_t *puVar21;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    
    if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) {
        return (uint8_t *)0x0;
    }
    uVar7 = *(uint32_t *)arg1;
    uVar20 = *(uint32_t *)(arg1 + 4);
    uVar16 = uVar7 >> 10 & 0x7f;
    if (arg4 == 0) {
        if (uVar16 == 1) {
            return (uint8_t *)0x0;
        }
        if (uVar16 == 2) {
            return (uint8_t *)0x0;
        }
        if (uVar16 == 4) {
            return (uint8_t *)0x0;
        }
        if (uVar16 != 0x12) {
            if (uVar16 != 0x3f) {
                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x8bffffff | 0xb000000;
                return (uint8_t *)0x1;
            }
            if (*(int64_t *)(arg2 + 0x38) != 0) {
                *(uint32_t *)arg1 = (uVar7 & 0xfffffc00 ^ uVar7) & 0x1fc00 ^ uVar7;
                iVar4 = (**(code **)(arg2 + 0x38))();
                if (iVar4 != 0) {
                    *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x87ffffff;
                    *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) | 0x7000000;
                    *(uint32_t *)(arg1 + 4) = uVar20;
                    return (uint8_t *)0x0;
                }
                return (uint8_t *)0x0;
            }
            return (uint8_t *)0x0;
        }
        return (uint8_t *)0x0;
    }
    var_58h = 0;
    var_60h = 0;
    var_68h = 0;
    var_78h = arg3;
    if (uVar16 != 0x2d) {
        var_78h = 0;
    }
    var_8h = arg3;
    if (uVar16 != 0x32) {
        var_8h = 0;
    }
    // switch table (16 cases) at 0x180191420
    switch(uVar16) {
    case 0x10:
        var_58h = arg3;
        break;
    case 0x15:
    case 0x16:
    case 0x17:
    case 0x18:
    case 0x19:
    case 0x1a:
    case 0x1b:
    case 0x1c:
    case 0x1d:
    case 0x1e:
    case 0x1f:
        var_60h = arg3;
    }
    puVar1 = (uint8_t *)(arg3 + arg4);
    puVar21 = (uint8_t *)arg3;
    uVar17 = uVar16;
    if ((uint8_t *)arg3 != puVar1) {
code_r0x00018018f196:
        if ((0x3a < (int32_t)uVar16) || (uVar20 = uVar20 + 1, uVar20 <= *(uint32_t *)0x18069c350)) {
            uVar9 = (uint64_t)*puVar21;
            puVar14 = (uint8_t *)var_8h;
            puVar18 = (uint8_t *)var_68h;
code_r0x00018018f1c0:
            uVar15 = (uint8_t)uVar9;
            if (0x3f < uVar16 - 1) {
                uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x9dffffff | 0x1d000000;
                goto code_r0x000180191213;
            }
            iVar4 = (int32_t)puVar21;
    // switch table (64 cases) at 0x180191460
            switch(uVar16) {
            case 1:
                if ((uVar15 != 0xd) && (uVar15 != 10)) {
                    uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x8dffffff | 0xd000000;
                    goto code_r0x000180191213;
                }
                goto code_r0x00018018fcc1;
            case 2:
                if ((uVar15 != 0xd) && (uVar15 != 10)) {
                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffffc03;
                    *(undefined8 *)(arg1 + 8) = 0xffffffffffffffff;
                    if (uVar15 != 0x48) {
                        uVar16 = 0x12;
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffffffc;
                        goto code_r0x00018018ff9a;
                    }
                    if (*(int64_t *)arg2 != 0) {
                        uVar16 = *(uint32_t *)arg1 & 0xfffe0fff | 0xc00;
code_r0x00018018fc73:
                        *(uint32_t *)arg1 = uVar16;
                        goto code_r0x00018018fc75;
                    }
                    uVar16 = 3;
                    uVar17 = 3;
                }
                goto code_r0x00018018fcc1;
            case 3:
                if (uVar15 == 0x54) {
                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffffffd | 1;
                    uVar16 = 6;
                    uVar17 = 6;
                } else {
                    if (uVar15 != 0x45) goto code_r0x0001801910c1;
                    *(undefined *)(arg1 + 0x16) = 2;
                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0x82fffffc | 0x2000000;
                    uVar16 = 0x13;
                    uVar17 = 0x13;
                }
                goto code_r0x00018018fcc1;
            case 4:
                if ((uVar15 != 0xd) && (uVar15 != 10)) {
                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffffc03;
                    *(undefined8 *)(arg1 + 8) = 0xffffffffffffffff;
                    if (uVar15 != 0x48) goto code_r0x0001801910c1;
                    if (*(int64_t *)arg2 != 0) {
                        uVar16 = *(uint32_t *)arg1 & 0xfffe17ff | 0x1400;
                        goto code_r0x00018018fc73;
                    }
                    uVar16 = 5;
                    uVar17 = 5;
                }
                goto code_r0x00018018fcc1;
            case 5:
                if (uVar15 == 0x54) {
                    uVar16 = 6;
                    uVar17 = 6;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 6:
                if (uVar15 == 0x54) {
                    uVar16 = 7;
                    uVar17 = 7;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 7:
                if (uVar15 == 0x50) {
                    uVar16 = 8;
                    uVar17 = 8;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 8:
                if (uVar15 == 0x2f) {
                    uVar16 = 9;
                    uVar17 = 9;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 9:
                if (9 < (uint8_t)(uVar15 - 0x30)) goto code_r0x0001801910d3;
                *(int16_t *)(arg1 + 0x10) = (char)uVar15 + -0x30;
                uVar16 = 10;
                uVar17 = 10;
                goto code_r0x00018018fcc1;
            case 10:
                if (uVar15 != 0x2e) goto code_r0x0001801910d3;
                uVar16 = 0xb;
                uVar17 = 0xb;
                goto code_r0x00018018fcc1;
            case 0xb:
                if (9 < (uint8_t)(uVar15 - 0x30)) goto code_r0x0001801910d3;
                *(int16_t *)(arg1 + 0x12) = (char)uVar15 + -0x30;
                uVar16 = 0xc;
                uVar17 = 0xc;
                goto code_r0x00018018fcc1;
            case 0xc:
                if (uVar15 != 0x20) goto code_r0x0001801910d3;
                uVar16 = 0xd;
                uVar17 = 0xd;
                goto code_r0x00018018fcc1;
            case 0xd:
                if ((uint8_t)(uVar15 - 0x30) < 10) {
                    *(int16_t *)(arg1 + 0x14) = (char)uVar15 + -0x30;
                    uVar16 = 0xe;
                    uVar17 = 0xe;
                } else if (uVar15 != 0x20) {
code_r0x00018018fe6d:
                    uVar8 = *(uint32_t *)(arg1 + 0x14);
                    goto code_r0x00018018fe70;
                }
                goto code_r0x00018018fcc1;
            case 0xe:
                if ((uint8_t)(uVar15 - 0x30) < 10) {
                    *(int16_t *)(arg1 + 0x14) = *(int16_t *)(arg1 + 0x14) * 10 + -0x30 + (int16_t)(char)uVar15;
                    uVar8 = *(uint32_t *)(arg1 + 0x14);
                    if (999 < (uint16_t)uVar8) {
code_r0x00018018fe70:
                        uVar7 = uVar8 & 0x8fffffff | 0xf000000;
                        goto code_r0x000180191213;
                    }
                    goto code_r0x00018018fcc1;
                }
                if ((uVar15 != 10) && (uVar15 != 0xd)) {
                    if (uVar15 != 0x20) goto code_r0x00018018fe6d;
                    uVar16 = 0xf;
                    uVar17 = 0xf;
                    goto code_r0x00018018fcc1;
                }
                uVar16 = 0xf;
                uVar17 = 0xf;
                goto code_r0x00018018f1c0;
            case 0xf:
                goto code_r0x00018018f20f;
            case 0x10:
                if (uVar15 == 0xd) {
                    uVar17 = 0x11;
                    uVar16 = 0x11;
                    if (var_58h != 0) {
                        if (*(int64_t *)(arg2 + 0x10) != 0) {
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffe47ff;
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0x4400;
                            iVar4 = (**(code **)(arg2 + 0x10))(arg1, var_58h, (int64_t)puVar21 - var_58h);
                            if (iVar4 != 0) {
                                *(uint32_t *)(arg1 + 4) = uVar20;
                                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x88ffffff | 0x8000000;
                            }
                            if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
                            uVar17 = *(uint32_t *)arg1 >> 10 & 0x7f;
                        }
                        var_58h = 0;
                        uVar16 = uVar17;
                    }
                } else if (uVar15 == 10) {
                    uVar17 = 0x2c;
                    uVar16 = 0x2c;
                    if (var_58h != 0) {
                        if (*(int64_t *)(arg2 + 0x10) != 0) {
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffeb3ff;
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0xb000;
                            iVar4 = (**(code **)(arg2 + 0x10))(arg1, var_58h, (int64_t)puVar21 - var_58h);
                            if (iVar4 != 0) {
                                *(uint32_t *)(arg1 + 4) = uVar20;
                                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x88ffffff | 0x8000000;
                            }
                            if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
                            uVar17 = *(uint32_t *)arg1 >> 10 & 0x7f;
                        }
                        var_58h = 0;
                        uVar16 = uVar17;
                    }
                }
                goto code_r0x00018018fcc1;
            case 0x11:
                if (uVar15 == 10) {
                    uVar16 = 0x2c;
                    uVar17 = 0x2c;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x12:
                if ((uVar15 != 0xd) && (uVar15 != 10)) {
code_r0x00018018ff9a:
                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffffc03;
                    uVar17 = *(uint32_t *)arg1;
                    *(undefined8 *)(arg1 + 8) = 0xffffffffffffffff;
                    if (0x19 < (uint8_t)((uVar15 | 0x20) + 0x9f)) goto code_r0x0001801910e5;
                    *(undefined *)(arg1 + 0x16) = 0;
                    *(uint32_t *)arg1 = uVar17 & 0x81ffffff | 0x1000000;
    // switch table (21 cases) at 0x1801915c4
                    switch(uVar15) {
                    case 0x41:
                        *(undefined *)(arg1 + 0x16) = 0x13;
                        break;
                    case 0x42:
                        *(undefined *)(arg1 + 0x16) = 0x10;
                        break;
                    case 0x43:
                        *(undefined *)(arg1 + 0x16) = 5;
                        break;
                    case 0x44:
                        break;
                    default:
                        goto code_r0x0001801910e5;
                    case 0x47:
                        *(undefined *)(arg1 + 0x16) = 1;
                        break;
                    case 0x48:
                        *(undefined *)(arg1 + 0x16) = 2;
                        break;
                    case 0x4c:
                        *(undefined *)(arg1 + 0x16) = 9;
                        break;
                    case 0x4d:
                        *(undefined *)(arg1 + 0x16) = 10;
                        break;
                    case 0x4e:
                        *(undefined *)(arg1 + 0x16) = 0x19;
                        break;
                    case 0x4f:
                        *(undefined *)(arg1 + 0x16) = 6;
                        break;
                    case 0x50:
                        *(undefined *)(arg1 + 0x16) = 3;
                        break;
                    case 0x52:
                        *(undefined *)(arg1 + 0x16) = 0x14;
                        break;
                    case 0x53:
                        *(undefined *)(arg1 + 0x16) = 0x1a;
                        break;
                    case 0x54:
                        *(undefined *)(arg1 + 0x16) = 7;
                        break;
                    case 0x55:
                        *(undefined *)(arg1 + 0x16) = 0xf;
                    }
                    if (*(int64_t *)arg2 == 0) {
                        uVar16 = 0x13;
                        uVar17 = 0x13;
                    } else {
                        *(uint32_t *)arg1 = uVar17 & 0x81fe4fff | 0x1004c00;
code_r0x00018018fc75:
                        iVar4 = (**(code **)arg2)(arg1);
                        if (iVar4 != 0) {
                            *(uint32_t *)(arg1 + 4) = uVar20;
                            uVar16 = *(uint32_t *)(arg1 + 0x14) & 0x81ffffff | 0x1000000;
code_r0x00018018fc8f:
                            *(uint32_t *)(arg1 + 0x14) = uVar16;
                        }
code_r0x00018018fc92:
                        if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
code_r0x00018018fc9f:
                        uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
                        uVar17 = uVar16;
                    }
                }
                goto code_r0x00018018fcc1;
            case 0x13:
                if (uVar15 == 0) {
code_r0x0001801910e5:
                    uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x90ffffff | 0x10000000;
                    goto code_r0x000180191213;
                }
                iVar3 = *(int64_t *)((uint64_t)*(uint8_t *)(arg1 + 0x16) * 8 + 0x18069c360);
                if ((uVar15 == 0x20) && (*(char *)((uint64_t)(*(uint8_t *)(arg1 + 3) & 0x7f) + iVar3) == '\0')) {
                    uVar17 = 0x14;
                    uVar16 = 0x14;
                } else if (uVar15 != *(uint8_t *)((uint64_t)(*(uint32_t *)arg1 >> 0x18 & 0x7f) + iVar3)) {
                    if ((0x19 < (uint8_t)(uVar15 + 0xbf)) && (uVar15 != 0x2d)) {
code_r0x0001801910f6:
                        uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x90ffffff | 0x10000000;
                        goto code_r0x000180191213;
                    }
                    uVar8 = (uint32_t)*(uint8_t *)(arg1 + 0x16) << 0x10 | *(uint32_t *)arg1 >> 0x10 & 0x7f00 |
                            (int32_t)(char)uVar15;
                    if (uVar8 < 0xa0150) {
                        if (uVar8 == 0xa014f) {
                            *(undefined *)(arg1 + 0x16) = 0xb;
                        } else if (uVar8 < 0x50149) {
                            if (uVar8 == 0x50148) {
                                *(undefined *)(arg1 + 0x16) = 0x16;
                            } else if (uVar8 == 0x30141) {
                                *(undefined *)(arg1 + 0x16) = 0x1c;
                            } else if (uVar8 == 0x30152) {
                                *(undefined *)(arg1 + 0x16) = 0xc;
                            } else if (uVar8 == 0x30155) {
                                *(undefined *)(arg1 + 0x16) = 4;
                            } else {
                                if (uVar8 != 0x40252) goto code_r0x0001801910f6;
                                *(undefined *)(arg1 + 0x16) = 0x1d;
                            }
                        } else if (uVar8 == 0x50250) {
                            *(undefined *)(arg1 + 0x16) = 8;
                        } else if (uVar8 == 0x90149) {
                            *(undefined *)(arg1 + 0x16) = 0x1f;
                        } else if (uVar8 == 0xa012d) {
                            *(undefined *)(arg1 + 0x16) = 0x18;
                        } else {
                            if (uVar8 != 0xa0145) goto code_r0x0001801910f6;
                            *(undefined *)(arg1 + 0x16) = 0x17;
                        }
                    } else if (uVar8 < 0xf0254) {
                        if (uVar8 == 0xf0253) {
                            *(undefined *)(arg1 + 0x16) = 0x1b;
                        } else if (uVar8 == 0xa0241) {
                            *(undefined *)(arg1 + 0x16) = 0x15;
                        } else if (uVar8 == 0xa0341) {
                            *(undefined *)(arg1 + 0x16) = 0x1e;
                        } else if (uVar8 == 0xc0450) {
                            *(undefined *)(arg1 + 0x16) = 0xd;
                        } else {
                            if (uVar8 != 0xf0242) goto code_r0x0001801910f6;
                            *(undefined *)(arg1 + 0x16) = 0x12;
                        }
                    } else if (uVar8 == 0xf0349) {
                        *(undefined *)(arg1 + 0x16) = 0x20;
                    } else if (uVar8 == 0x140242) {
                        *(undefined *)(arg1 + 0x16) = 0x11;
                    } else if (uVar8 == 0x1a0145) {
                        *(undefined *)(arg1 + 0x16) = 0xe;
                    } else {
                        if (uVar8 != 0x1a014f) goto code_r0x0001801910f6;
                        *(undefined *)(arg1 + 0x16) = 0x21;
                    }
                }
                uVar8 = *(uint32_t *)arg1;
                *(uint32_t *)arg1 = (uVar8 + 0x1000000 ^ uVar8) & 0x7f000000 ^ uVar8;
                goto code_r0x00018018fcc1;
            case 0x14:
                if (uVar15 != 0x20) {
                    if (var_60h == 0) {
                        var_60h = (int64_t)puVar21;
                    }
                    if (*(char *)(arg1 + 0x16) == '\x05') {
                        uVar16 = 0x18;
                    }
                    goto code_r0x000180190245;
                }
                goto code_r0x00018018fcc1;
            case 0x15:
            case 0x16:
            case 0x17:
            case 0x18:
                if ((uVar15 < 0x21) && ((0x100002400U >> (uVar9 & 0x3f) & 1) != 0)) {
                    uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x91ffffff | 0x11000000;
                    goto code_r0x000180191213;
                }
code_r0x000180190245:
                uVar16 = fcn.1801916d0(uVar16, uVar9 & 0xff);
                uVar17 = uVar16;
                if (uVar16 == 1) {
                    uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x91ffffff | 0x11000000;
                    goto code_r0x000180191213;
                }
                goto code_r0x00018018fcc1;
            default:
                if ((uVar15 == 10) || (uVar15 == 0xd)) {
                    *(undefined4 *)(arg1 + 0x10) = 0x90000;
                    uVar17 = (uVar15 != 0xd) + 0x2b;
                    uVar16 = uVar17;
                    if (var_60h != 0) {
                        if (*(int64_t *)(arg2 + 8) == 0) goto code_r0x000180190316;
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffe03ff;
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 | uVar17 * 0x400;
                        iVar4 = (**(code **)(arg2 + 8))(arg1, var_60h, (int64_t)puVar21 - var_60h);
                        if (iVar4 != 0) {
                            *(uint32_t *)(arg1 + 4) = uVar20;
                            *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x82ffffff | 0x2000000;
                        }
                        if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) == 0) {
                            var_60h = 0;
                            goto code_r0x00018018fc9f;
                        }
                        goto code_r0x0001801911e6;
                    }
                } else {
                    if (uVar15 != 0x20) goto code_r0x000180190245;
                    uVar17 = 0x20;
                    uVar16 = 0x20;
                    if (var_60h != 0) {
                        if (*(int64_t *)(arg2 + 8) != 0) {
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffe83ff;
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0x8000;
                            iVar4 = (**(code **)(arg2 + 8))(arg1, var_60h, (int64_t)puVar21 - var_60h);
                            if (iVar4 != 0) {
                                *(uint32_t *)(arg1 + 4) = uVar20;
                                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x82ffffff | 0x2000000;
                            }
                            if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
                            uVar17 = *(uint32_t *)arg1 >> 10 & 0x7f;
                        }
code_r0x000180190316:
                        var_60h = 0;
                        uVar16 = uVar17;
                    }
                }
                goto code_r0x00018018fcc1;
            case 0x20:
                if (uVar15 != 0x20) {
                    if (uVar15 == 0x48) {
                        uVar16 = 0x21;
                        uVar17 = 0x21;
                    } else {
                        if ((uVar15 != 0x49) || (*(char *)(arg1 + 0x16) != '!')) {
code_r0x0001801910c1:
                            uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x9cffffff | 0x1c000000;
                            goto code_r0x000180191213;
                        }
                        uVar16 = 0x25;
                        uVar17 = 0x25;
                    }
                }
                goto code_r0x00018018fcc1;
            case 0x21:
                if (uVar15 == 0x54) {
                    uVar16 = 0x22;
                    uVar17 = 0x22;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x22:
                if (uVar15 == 0x54) {
                    uVar16 = 0x23;
                    uVar17 = 0x23;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x23:
                if (uVar15 == 0x50) {
                    uVar16 = 0x24;
                    uVar17 = 0x24;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x24:
                if (uVar15 == 0x2f) {
                    uVar16 = 0x27;
                    uVar17 = 0x27;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x25:
                if (uVar15 == 0x43) {
                    uVar16 = 0x26;
                    uVar17 = 0x26;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x26:
                if (uVar15 == 0x45) {
                    uVar16 = 0x24;
                    uVar17 = 0x24;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x27:
                if (9 < (uint8_t)(uVar15 - 0x30)) goto code_r0x0001801910d3;
                *(int16_t *)(arg1 + 0x10) = (char)uVar15 + -0x30;
                uVar16 = 0x28;
                uVar17 = 0x28;
                goto code_r0x00018018fcc1;
            case 0x28:
                if (uVar15 != 0x2e) goto code_r0x0001801910d3;
                uVar16 = 0x29;
                uVar17 = 0x29;
                goto code_r0x00018018fcc1;
            case 0x29:
                if (9 < (uint8_t)(uVar15 - 0x30)) goto code_r0x0001801910d3;
                *(int16_t *)(arg1 + 0x12) = (char)uVar15 + -0x30;
                uVar16 = 0x2a;
                uVar17 = 0x2a;
                goto code_r0x00018018fcc1;
            case 0x2a:
                if (uVar15 == 0xd) {
                    uVar16 = 0x2b;
                    uVar17 = 0x2b;
                } else {
                    if (uVar15 != 10) {
code_r0x0001801910d3:
                        uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x8effffff | 0xe000000;
                        goto code_r0x000180191213;
                    }
                    uVar16 = 0x2c;
                    uVar17 = 0x2c;
                }
                goto code_r0x00018018fcc1;
            case 0x2b:
                if (uVar15 != 10) goto code_r0x00018019110f;
                uVar16 = 0x2c;
                uVar17 = 0x2c;
                goto code_r0x00018018fcc1;
            case 0x2c:
                if (uVar15 == 0xd) {
                    uVar16 = 0x39;
                    uVar17 = 0x39;
                    goto code_r0x00018018fcc1;
                }
                if (uVar15 != 10) {
                    if ((uVar15 == 0x20) || (cVar2 = *(char *)((uVar9 & 0xff) + 0x1804a8a50), cVar2 == '\0'))
                    goto code_r0x000180191014;
                    uVar17 = 0x2d;
                    uVar16 = 0x2d;
                    uVar8 = *(uint32_t *)arg1;
                    if (var_78h == 0) {
                        var_78h = (int64_t)puVar21;
                    }
                    if (cVar2 == 'c') {
                        *(uint32_t *)arg1 = uVar8 & 0x8003ffff | 0x20000;
                    } else if (cVar2 == 'p') {
                        *(uint32_t *)arg1 = uVar8 & 0x800bffff | 0xa0000;
                    } else if (cVar2 == 't') {
                        *(uint32_t *)arg1 = uVar8 & 0x800fffff | 0xe0000;
                    } else if (cVar2 == 'u') {
                        *(uint32_t *)arg1 = uVar8 & 0x8011ffff | 0x100000;
                    } else {
                        *(uint32_t *)arg1 = uVar8 & 0x8001ffff;
                    }
                    goto code_r0x00018018fcc1;
                }
                uVar16 = 0x39;
                uVar17 = 0x39;
                goto code_r0x00018018f1c0;
            case 0x2d:
                goto joined_r0x0001801904dd;
            case 0x2e:
                if ((uVar15 != 0x20) && (uVar15 != 9)) {
                    if (uVar15 == 0xd) {
                        uVar16 = 0x2f;
                        uVar17 = 0x2f;
                    } else {
                        if (uVar15 != 10) goto code_r0x000180190971;
                        uVar16 = 0x30;
                        uVar17 = 0x30;
                    }
                }
                goto code_r0x00018018fcc1;
            case 0x2f:
                if (uVar15 == 10) {
                    uVar16 = 0x30;
                    uVar17 = 0x30;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x30:
                if ((uVar15 == 0x20) || (uVar15 == 9)) {
                    uVar16 = 0x2e;
                    uVar17 = 0x2e;
                    goto code_r0x00018018fcc1;
                }
                uVar8 = *(uint32_t *)arg1;
                uVar17 = uVar8 >> 0x11 & 0x7f;
                if (uVar17 == 10) goto code_r0x000180191033;
                if (uVar17 == 0x15) {
                    uVar8 = uVar8 | 4;
code_r0x00018018f7a7:
                    *(uint32_t *)arg1 = uVar8;
                } else {
                    if (uVar17 == 0x16) {
                        uVar8 = uVar8 | 8;
                        goto code_r0x00018018f7a7;
                    }
                    if (uVar17 == 0x17) {
                        uVar8 = uVar8 | 0x10;
                        goto code_r0x00018018f7a7;
                    }
                    if (uVar17 == 0x18) {
                        uVar8 = uVar8 | 0x20;
                        goto code_r0x00018018f7a7;
                    }
                }
                uVar17 = 0x2c;
                var_8h = (int64_t)puVar14;
                if (puVar14 == (uint8_t *)0x0) {
                    var_8h = (int64_t)puVar21;
                }
                puVar14 = (uint8_t *)var_8h;
                uVar16 = 0x2c;
                if ((uint8_t *)var_8h != (uint8_t *)0x0) {
                    if (*(int64_t *)(arg2 + 0x20) != 0) {
                        *(uint32_t *)arg1 = uVar8 & 0xfffeb3ff | 0xb000;
                        iVar4 = (**(code **)(arg2 + 0x20))(arg1, var_8h, (int64_t)puVar21 - var_8h);
                        if (iVar4 != 0) {
                            *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x84ffffff;
                            *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) | 0x4000000;
                            *(uint32_t *)(arg1 + 4) = uVar20;
                        }
                        if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x000180191077;
                        uVar17 = *(uint32_t *)arg1 >> 10 & 0x7f;
                    }
                    var_8h = 0;
                    puVar14 = (uint8_t *)0x0;
                    uVar16 = uVar17;
                }
                goto code_r0x00018018f1c0;
            case 0x31:
code_r0x000180190971:
                uVar17 = 0x32;
                uVar16 = 0x32;
                var_8h = (int64_t)puVar14;
                if (puVar14 == (uint8_t *)0x0) {
                    var_8h = (int64_t)puVar21;
                }
                *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0x80ffffff;
                uVar8 = *(uint32_t *)arg1;
                uVar13 = uVar15 | 0x20;
    // switch table (8 cases) at 0x180191654
                switch(uVar8 >> 0x11 & 0x7f) {
                case 9:
                    if (uVar13 == 0x6b) {
                        *(uint32_t *)arg1 = uVar8 & 0xff23ffff | 0x220000;
                    } else if (uVar13 == 99) {
                        *(uint32_t *)arg1 = uVar8 & 0xff25ffff | 0x240000;
                    } else if (uVar13 == 0x75) {
                        *(uint32_t *)arg1 = uVar8 & 0xff27ffff | 0x260000;
                    } else {
                        *(uint32_t *)arg1 = uVar8 & 0xff29ffff | 0x280000;
                    }
                    break;
                case 10:
                    if (9 < (uint8_t)(uVar15 - 0x30)) {
code_r0x000180191033:
                        uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x99ffffff | 0x19000000;
                        goto code_r0x000180191213;
                    }
                    if ((uVar8 >> 9 & 1) != 0) {
code_r0x000180191045:
                        uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x9affffff | 0x1a000000;
                        goto code_r0x000180191213;
                    }
                    *(int64_t *)(arg1 + 8) = (int64_t)((char)uVar15 + -0x30);
                    *(uint32_t *)arg1 = uVar8 & 0xff17ffff | 0x160200;
                    break;
                case 0xc:
                case 0x10:
                    break;
                case 0xd:
                    if (uVar13 == 99) {
                        *(uint32_t *)arg1 = uVar8 & 0xff1fffff | 0x1e0000;
                        break;
                    }
                default:
                    *(uint32_t *)arg1 = uVar8 & 0xff01ffff;
                    break;
                case 0xe:
                    *(uint32_t *)arg1 = uVar8 & 0xff01ffff | 0x80;
                }
                goto code_r0x00018018fcc1;
            case 0x32:
                uVar8 = *(uint32_t *)arg1 >> 0x11 & 0x7f;
code_r0x00018018f261:
                if (puVar21 != puVar1) {
                    uVar15 = *puVar21;
                    uVar9 = (uint64_t)(uint32_t)(int32_t)(char)uVar15;
                    if (uVar15 != 0xd) {
                        if (uVar15 != 10) {
                            if (((-1 < (int32_t)uVar7) && (uVar15 != 9)) && ((uVar15 < 0x20 || (uVar15 == 0x7f))))
                            goto code_r0x000180191014;
                            uVar13 = uVar15 | 0x20;
    // switch table (25 cases) at 0x180191560
                            switch(uVar8) {
                            case 0:
                                uVar9 = (arg3 - (int64_t)puVar21) + arg4;
                                if ((int64_t)(uint64_t)*(uint32_t *)0x18069c350 <= (int64_t)uVar9) {
                                    uVar9 = (uint64_t)*(uint32_t *)0x18069c350;
                                }
                                puVar14 = puVar21 + uVar9;
                                for (; puVar21 != puVar14; puVar21 = puVar21 + 1) {
                                    uVar15 = *puVar21;
                                    if ((uVar15 == 0xd) || (uVar15 == 10)) {
                                        puVar21 = puVar21 + -1;
                                        break;
                                    }
                                    if (((-1 < (int32_t)uVar7) && (uVar15 != 9)) &&
                                       ((uVar15 < 0x20 || (uVar15 == 0x7f)))) goto code_r0x000180191014;
                                }
                                if (puVar21 == puVar1) goto code_r0x00018018f261;
                                break;
                            default:
                                uVar17 = 0x32;
                                uVar16 = 0x32;
code_r0x00018018f612:
                                uVar8 = 0;
                                break;
                            case 9:
                            case 0xd:
                                break;
                            case 10:
                                if (uVar15 != 0x20) {
                                    uVar8 = 0xb;
                                    goto code_r0x00018018f335;
                                }
                                break;
                            case 0xb:
                                if (uVar15 == 0x20) {
                                    uVar8 = 0xc;
                                    puVar21 = puVar21 + 1;
                                } else {
code_r0x00018018f335:
                                    if ((9 < (uint8_t)(uVar15 - 0x30)) || (0x1999999999999998 < *(uint64_t *)(arg1 + 8))
                                       ) {
                                        *(uint32_t *)arg1 =
                                             *(uint32_t *)arg1 ^ (uVar8 << 0x11 ^ *(uint32_t *)arg1) & 0xfe0000;
                                        goto code_r0x000180191033;
                                    }
                                    puVar21 = puVar21 + 1;
                                    *(uint64_t *)(arg1 + 8) =
                                         (int64_t)(int32_t)((int32_t)(char)uVar15 - 0x30) + *(uint64_t *)(arg1 + 8) * 10
                                    ;
                                }
                                goto code_r0x00018018f261;
                            case 0xc:
                                if (uVar15 != 0x20) {
                                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xff01ffff ^ 0x180000;
                                    uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x99ffffff | 0x19000000;
                                    goto code_r0x000180191213;
                                }
                                break;
                            case 0xf:
                                uVar19 = *(uint32_t *)arg1;
                                uVar5 = (uVar19 ^ uVar19 + 0x1000000) & 0x7f000000 ^ uVar19;
                                uVar19 = (uVar19 + 0x1000000 & 0x7f000000) >> 0x18;
                                *(uint32_t *)arg1 = uVar5;
                                if ((7 < uVar19) ||
                                   (uVar13 != *(uint8_t *)((uint64_t)(uVar5 >> 0x18 & 0x7f) + 0x1804a62f0)))
                                goto code_r0x00018018f612;
                                if (uVar19 == 6) {
                                    uVar8 = 0x15;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                break;
                            case 0x10:
                                if (uVar13 == 0x6b) {
                                    uVar8 = 0x11;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                if (uVar13 == 99) {
                                    uVar8 = 0x12;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                if (uVar13 == 0x75) {
                                    uVar8 = 0x13;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                if (uVar13 != 0x20) {
                                    uVar8 = -(uint32_t)(*(char *)((uint64_t)uVar13 + 0x1804a8a50) != '\0') & 0x14;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                break;
                            case 0x11:
                                uVar19 = *(uint32_t *)arg1;
                                uVar5 = (uVar19 ^ uVar19 + 0x1000000) & 0x7f000000 ^ uVar19;
                                uVar19 = (uVar19 + 0x1000000 & 0x7f000000) >> 0x18;
                                *(uint32_t *)arg1 = uVar5;
                                if ((10 < uVar19) ||
                                   (uVar13 != *(uint8_t *)((uint64_t)(uVar5 >> 0x18 & 0x7f) + 0x1804a6308))) {
code_r0x00018018f600:
                                    uVar8 = 0x14;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                if (uVar19 == 9) {
                                    uVar8 = 0x16;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                break;
                            case 0x12:
                                uVar19 = *(uint32_t *)arg1;
                                uVar5 = (uVar19 ^ uVar19 + 0x1000000) & 0x7f000000 ^ uVar19;
                                uVar19 = (uVar19 + 0x1000000 & 0x7f000000) >> 0x18;
                                *(uint32_t *)arg1 = uVar5;
                                if ((5 < uVar19) ||
                                   (uVar13 != *(uint8_t *)((uint64_t)(uVar5 >> 0x18 & 0x7f) + 0x18063c2dc)))
                                goto code_r0x00018018f600;
                                if (uVar19 == 4) {
                                    uVar8 = 0x17;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                break;
                            case 0x13:
                                uVar19 = *(uint32_t *)arg1;
                                uVar5 = (uVar19 ^ uVar19 + 0x1000000) & 0x7f000000 ^ uVar19;
                                uVar19 = (uVar19 + 0x1000000 & 0x7f000000) >> 0x18;
                                *(uint32_t *)arg1 = uVar5;
                                if ((7 < uVar19) ||
                                   (uVar13 != *(uint8_t *)((uint64_t)(uVar5 >> 0x18 & 0x7f) + 0x1804a6318)))
                                goto code_r0x00018018f600;
                                if (uVar19 == 6) {
                                    uVar8 = 0x18;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                break;
                            case 0x14:
                                if (uVar15 == 0x2c) {
                                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0x80ffffff;
                                    uVar8 = 0x10;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                break;
                            case 0x15:
                                if (uVar15 != 0x20) {
                                    uVar8 = 0;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                break;
                            case 0x16:
                            case 0x17:
                            case 0x18:
                                if (uVar15 != 0x2c) {
                                    if (uVar15 != 0x20) goto code_r0x00018018f600;
                                    break;
                                }
                                if (uVar8 == 0x16) {
                                    *(uint32_t *)arg1 = *(uint32_t *)arg1 | 8;
                                    uVar8 = 0x10;
                                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0x80ffffff;
                                    puVar21 = puVar21 + 1;
                                } else if (uVar8 == 0x17) {
                                    *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0x10;
                                    uVar8 = 0x10;
                                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0x80ffffff;
                                    puVar21 = puVar21 + 1;
                                } else {
                                    if (uVar8 == 0x18) {
                                        *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0x20;
                                    }
                                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0x80ffffff;
                                    uVar8 = 0x10;
                                    puVar21 = puVar21 + 1;
                                }
                                goto code_r0x00018018f261;
                            }
                            puVar21 = puVar21 + 1;
                            goto code_r0x00018018f261;
                        }
                        uVar17 = 0x34;
                        uVar16 = 0x34;
                        uVar20 = uVar20 + ((int32_t)puVar21 - iVar4);
                        if (*(uint32_t *)0x18069c350 < uVar20) goto code_r0x000180191002;
                        uVar8 = (uVar8 << 0x11 ^ *(uint32_t *)arg1) & 0xfe0000 ^ *(uint32_t *)arg1;
                        *(uint32_t *)arg1 = uVar8;
                        puVar14 = (uint8_t *)var_8h;
                        puVar18 = (uint8_t *)var_68h;
                        uVar16 = uVar17;
                        if (var_8h != 0) {
                            if (*(int64_t *)(arg2 + 0x20) != 0) {
                                *(uint32_t *)arg1 = uVar8 & 0xfffed3ff | 0xd000;
                                iVar4 = (**(code **)(arg2 + 0x20))(arg1, var_8h, (int64_t)puVar21 - var_8h);
                                if (iVar4 != 0) {
                                    *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x84ffffff;
                                    *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) | 0x4000000;
                                    *(uint32_t *)(arg1 + 4) = uVar20;
                                }
                                if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x000180191077;
                                uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
                            }
                            var_8h = 0;
                            puVar14 = (uint8_t *)var_8h;
                            uVar17 = uVar16;
                        }
                        goto code_r0x00018018f1c0;
                    }
                    uVar17 = 0x34;
                    uVar16 = 0x34;
                    uVar19 = (uVar8 << 0x11 ^ *(uint32_t *)arg1) & 0xfe0000 ^ *(uint32_t *)arg1;
                    *(uint32_t *)arg1 = uVar19;
                    if (var_8h == 0) goto code_r0x00018018fbe9;
                    uVar16 = uVar17;
                    if (*(int64_t *)(arg2 + 0x20) != 0) {
                        *(uint32_t *)arg1 = uVar19 & 0xfffed3ff | 0xd000;
                        iVar6 = (**(code **)(arg2 + 0x20))(arg1, var_8h, (int64_t)puVar21 - var_8h);
                        if (iVar6 != 0) {
                            *(uint32_t *)(arg1 + 4) = uVar20;
                            *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x84ffffff | 0x4000000;
                        }
                        uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
                        if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
                    }
                    var_8h = 0;
                    uVar17 = uVar16;
                }
code_r0x00018018fbe9:
                *(uint32_t *)arg1 = *(uint32_t *)arg1 ^ (uVar8 << 0x11 ^ *(uint32_t *)arg1) & 0xfe0000;
                if (puVar21 == (uint8_t *)(arg3 + arg4)) {
                    puVar21 = puVar21 + -1;
                }
                uVar20 = uVar20 + ((int32_t)puVar21 - iVar4);
                if (*(uint32_t *)0x18069c350 < uVar20) goto code_r0x000180191002;
                goto code_r0x00018018fcc1;
            case 0x33:
                if ((uVar15 == 0x20) || (uVar15 == 9)) {
                    if ((*(uint32_t *)arg1 & 0xfe0000) == 0x160000) {
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xff19ffff | 0x180000;
                    }
                    uVar16 = 0x31;
                    uVar17 = 0x31;
                    goto code_r0x00018018f1c0;
                }
                uVar16 = *(uint32_t *)arg1;
                uVar17 = uVar16 >> 0x11 & 0x7f;
                if (uVar17 == 0x15) {
                    *(uint32_t *)arg1 = uVar16 | 4;
                } else {
                    if (uVar17 == 0x16) {
                        *(uint32_t *)arg1 = uVar16 | 8;
                        uVar16 = 0x2c;
                        uVar17 = 0x2c;
                        goto code_r0x00018018f1c0;
                    }
                    if (uVar17 == 0x17) {
                        *(uint32_t *)arg1 = uVar16 | 0x10;
                        uVar16 = 0x2c;
                        uVar17 = 0x2c;
                        goto code_r0x00018018f1c0;
                    }
                    if (uVar17 == 0x18) {
                        *(uint32_t *)arg1 = uVar16 | 0x20;
                        uVar16 = 0x2c;
                        uVar17 = 0x2c;
                        goto code_r0x00018018f1c0;
                    }
                }
                uVar16 = 0x2c;
                uVar17 = 0x2c;
                goto code_r0x00018018f1c0;
            case 0x34:
                if (uVar15 != 10) {
code_r0x00018019110f:
                    uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x97ffffff | 0x17000000;
                    goto code_r0x000180191213;
                }
                uVar16 = 0x33;
                uVar17 = 0x33;
                goto code_r0x00018018fcc1;
            case 0x35:
                cVar2 = *(char *)((uVar9 & 0xff) + 0x1804a8b50);
                if (cVar2 == -1) {
code_r0x0001801911f7:
                    uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x9bffffff | 0x1b000000;
                    goto code_r0x000180191213;
                }
                *(int64_t *)(arg1 + 8) = (int64_t)cVar2;
                uVar16 = 0x36;
                uVar17 = 0x36;
                goto code_r0x00018018fcc1;
            case 0x36:
                if (uVar15 == 0xd) {
                    uVar16 = 0x38;
                    uVar17 = 0x38;
                } else {
                    cVar2 = *(char *)((uVar9 & 0xff) + 0x1804a8b50);
                    if (cVar2 == -1) {
                        if ((uVar15 != 0x3b) && (uVar15 != 0x20)) goto code_r0x0001801911f7;
                        uVar16 = 0x37;
                        uVar17 = 0x37;
                    } else {
                        if (0xffffffffffffffe < *(uint64_t *)(arg1 + 8)) goto code_r0x000180191033;
                        *(uint64_t *)(arg1 + 8) = *(uint64_t *)(arg1 + 8) * 0x10 + (int64_t)cVar2;
                    }
                }
                goto code_r0x00018018fcc1;
            case 0x37:
                uVar16 = uVar17;
                if (uVar15 == 0xd) {
                    uVar16 = 0x38;
                    uVar17 = uVar16;
                }
                goto code_r0x00018018fcc1;
            case 0x38:
                if (uVar15 == 10) {
                    *(undefined4 *)(arg1 + 4) = 0;
                    if (*(int64_t *)(arg1 + 8) == 0) {
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0x40;
                        uVar17 = 0x2c;
                        uVar16 = 0x2c;
                    } else {
                        uVar17 = 0x3b;
                        uVar16 = 0x3b;
                    }
                    if (*(int64_t *)(arg2 + 0x40) != 0) {
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffe03ff;
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 | uVar16 << 10;
                        iVar4 = (**(code **)(arg2 + 0x40))(arg1);
                        if (iVar4 != 0) {
                            *(undefined4 *)(arg1 + 4) = 0;
                            *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x89ffffff | 0x9000000;
                        }
                        if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
                        uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
                        uVar17 = uVar16;
                    }
                    uVar20 = 0;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x39:
                if (uVar15 != 10) break;
                uVar17 = *(uint32_t *)arg1;
                uVar8 = uVar17 >> 2;
                if ((uVar8 & 0x10) == 0) {
                    if (((uVar8 & 1) != 0) && ((char)(uint8_t)uVar8 < '\0')) goto code_r0x000180191045;
                    if (((uint8_t)uVar8 & 0x28) == 0x28) {
                        if (((uVar17 & 3) == 0) || (*(int16_t *)(arg1 + 0x14) == 0x65)) {
                            uVar17 = 0x80000000;
                            uVar16 = *(uint32_t *)(arg1 + 0x14) & 0x7fffffff;
                        } else {
                            uVar17 = 0;
                            uVar16 = *(uint32_t *)(arg1 + 0x14) & 0x7fffffff;
                        }
                    } else {
                        uVar16 = 0;
                        if (*(char *)(arg1 + 0x16) == '\x05') {
                            uVar16 = 0x80000000;
                        }
                        uVar17 = *(uint32_t *)(arg1 + 0x14) & 0x7fffffff;
                    }
                    *(uint32_t *)(arg1 + 0x14) = uVar16 | uVar17;
                    if ((*(code **)(arg2 + 0x28) != (code *)0x0) &&
                       (iVar4 = (**(code **)(arg2 + 0x28))(arg1), puVar14 = (uint8_t *)var_8h, iVar4 != 0)) {
                        if (iVar4 != 1) {
                            if (iVar4 != 2) {
                                *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffeebff;
                                *(uint32_t *)(arg1 + 4) = uVar20;
                                *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0xe800;
                                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x85ffffff | 0x5000000;
                                goto code_r0x000180191077;
                            }
                            *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) | 0x80000000;
                        }
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0x100;
                    }
                    if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) {
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffeebff;
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0xe800;
                        *(uint32_t *)(arg1 + 4) = uVar20;
                        goto code_r0x000180191091;
                    }
                    uVar16 = 0x3a;
                    uVar17 = 0x3a;
                } else if (*(int64_t *)(arg2 + 0x48) == 0) {
                    uVar16 = 0x40;
                    uVar17 = 0x40;
                } else {
                    *(uint32_t *)arg1 = uVar17 & 0xffff03ff | 0x10000;
                    iVar4 = (**(code **)(arg2 + 0x48))(arg1);
                    if (iVar4 != 0) {
                        *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x8affffff;
                        *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) | 0xa000000;
                        *(uint32_t *)(arg1 + 4) = uVar20;
                    }
                    if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x000180191077;
                    uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
                    puVar14 = (uint8_t *)var_8h;
                    uVar17 = uVar16;
                }
                goto code_r0x00018018f1c0;
            case 0x3a:
                if (uVar15 == 10) {
                    *(undefined4 *)(arg1 + 4) = 0;
                    uVar16 = *(uint32_t *)arg1 >> 2;
                    if (((uVar16 & 1) != 0) || (uVar17 = 0, (*(int64_t *)(arg1 + 8) + 1U & 0xfffffffffffffffe) != 0)) {
                        uVar17 = 1;
                    }
                    uVar19 = 1;
                    uVar8 = *(uint32_t *)(arg1 + 0x14);
                    uVar20 = 0;
                    if (((int32_t)uVar8 < 0) &&
                       ((((char)(uVar8 >> 0x10) == '\x05' || ((uVar16 & 0x40) != 0)) || (uVar17 == 0)))) {
                        if ((*(int16_t *)(arg1 + 0x10) == 0) || (*(int16_t *)(arg1 + 0x12) == 0)) {
                            uVar7 = *(uint32_t *)arg1;
                            if ((uVar7 & 8) != 0) goto code_r0x00018019113d;
                        } else {
                            uVar7 = *(uint32_t *)arg1;
                            if ((uVar7 & 0x10) == 0) {
code_r0x00018019113d:
                                if ((((((uVar7 & 3) == 0) || (uVar8 = uVar8 & 0xffff, uVar8 - 100 < 100)) ||
                                     ((uVar8 == 0xcc ||
                                      (((uVar8 == 0x130 || ((uVar7 >> 8 & 1) != 0)) || ((uVar7 & 4) != 0)))))) ||
                                    (*(int64_t *)(arg1 + 8) != -1)) && (uVar19 = 4, (uVar7 & 3) == 0)) {
                                    uVar19 = 0x12;
                                }
                            }
                        }
                        if (*(int64_t *)(arg2 + 0x38) != 0) {
                            *(uint32_t *)arg1 = uVar7 & 0xfffe03ff | uVar19 << 10;
                            iVar4 = (**(code **)(arg2 + 0x38))(arg1);
                            if (iVar4 != 0) {
                                *(undefined4 *)(arg1 + 4) = 0;
                                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x87ffffff | 0x7000000;
                            }
                            if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
                            uVar7 = *(uint32_t *)arg1;
                            uVar19 = uVar7 >> 10;
                        }
                        *(undefined4 *)(arg1 + 4) = 0;
                        *(uint32_t *)arg1 = (uVar19 << 10 ^ uVar7) & 0x1fc00 ^ uVar7;
                        goto code_r0x0001801911e6;
                    }
                    if ((*(uint32_t *)arg1 >> 8 & 1) == 0) {
                        uVar17 = *(uint32_t *)arg1;
                        if ((uVar17 & 4) != 0) {
                            uVar20 = 0;
                            uVar16 = 0x35;
                            uVar17 = 0x35;
                            goto code_r0x00018018fcc1;
                        }
                        uVar16 = 1;
                        if (*(int64_t *)(arg1 + 8) == 0) {
                            if ((*(int16_t *)(arg1 + 0x10) == 0) || (*(int16_t *)(arg1 + 0x12) == 0)) {
                                uVar17 = uVar17 & 8;
                            } else {
                                uVar17 = uVar17 & 0x10;
                            }
                            if ((uVar17 != 0) && (uVar16 = 4, (*(uint8_t *)arg1 & 3) == 0)) {
                                uVar16 = 0x12;
                            }
                            uVar17 = uVar16;
                            if (*(int64_t *)(arg2 + 0x38) == 0) goto code_r0x00018018fcc1;
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffe03ff;
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 | uVar16 << 10;
                        } else {
                            if (*(int64_t *)(arg1 + 8) != -1) {
                                uVar20 = 0;
                                uVar16 = 0x3e;
                                uVar17 = 0x3e;
                                goto code_r0x00018018fcc1;
                            }
                            if (((((uVar17 & 3) != 0) && (uVar8 = uVar8 & 0xffff, 99 < uVar8 - 100)) && (uVar8 != 0xcc))
                               && ((uVar8 != 0x130 && ((uVar17 >> 8 & 1) == 0)))) {
                                uVar20 = 0;
                                uVar16 = 0x3f;
                                uVar17 = 0x3f;
                                goto code_r0x00018018fcc1;
                            }
                            if ((*(int16_t *)(arg1 + 0x10) == 0) || (*(int16_t *)(arg1 + 0x12) == 0)) {
                                uVar8 = *(uint32_t *)arg1;
                                if ((uVar8 & 8) != 0) goto code_r0x000180190c19;
                            } else {
                                uVar8 = *(uint32_t *)arg1;
                                if ((uVar8 & 0x10) == 0) {
code_r0x000180190c19:
                                    if ((((((uVar8 & 3) == 0) ||
                                          (uVar17 = *(uint32_t *)(arg1 + 0x14) & 0xffff, uVar17 - 100 < 100)) ||
                                         (uVar17 == 0xcc)) ||
                                        (((uVar17 == 0x130 || ((uVar8 >> 8 & 1) != 0)) ||
                                         (((uVar8 & 4) != 0 || (*(int64_t *)(arg1 + 8) != -1)))))) &&
                                       (uVar16 = 4, (uVar8 & 3) == 0)) {
                                        uVar16 = 0x12;
                                    }
                                }
                            }
                            uVar17 = uVar16;
                            if (*(int64_t *)(arg2 + 0x38) == 0) goto code_r0x00018018fcc1;
                            *(uint32_t *)arg1 = uVar8 & 0xfffe03ff | uVar16 << 10;
                        }
                    } else {
                        if ((*(int16_t *)(arg1 + 0x10) == 0) || (*(int16_t *)(arg1 + 0x12) == 0)) {
                            uVar8 = *(uint32_t *)arg1;
                            uVar16 = uVar8 & 8;
                        } else {
                            uVar8 = *(uint32_t *)arg1;
                            uVar16 = uVar8 & 0x10;
                        }
                        if (uVar16 == 0) {
                            uVar16 = 1;
                        } else {
                            uVar16 = 4;
                            if ((uVar8 & 3) == 0) {
                                uVar16 = 0x12;
                            }
                        }
                        uVar17 = uVar16;
                        if (*(int64_t *)(arg2 + 0x38) == 0) goto code_r0x00018018fcc1;
                        *(uint32_t *)arg1 = uVar16 << 10 | uVar8 & 0xfffe03ff;
                    }
                    iVar4 = (**(code **)(arg2 + 0x38))(arg1);
                    if (iVar4 != 0) {
                        *(undefined4 *)(arg1 + 4) = 0;
                        *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x87ffffff | 0x7000000;
                    }
                    if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
                    uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
                    uVar17 = uVar16;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x3b:
                uVar9 = *(uint64_t *)(arg1 + 8);
                uVar12 = (arg3 - (int64_t)puVar21) + arg4;
                uVar11 = uVar9;
                if (uVar12 <= uVar9) {
                    uVar11 = uVar12;
                }
                var_68h = (int64_t)puVar18;
                if (puVar18 == (uint8_t *)0x0) {
                    var_68h = (int64_t)puVar21;
                }
                puVar21 = puVar21 + (uVar11 - 1);
                *(uint64_t *)(arg1 + 8) = uVar9 - uVar11;
                uVar16 = uVar17;
                if (uVar9 - uVar11 == 0) {
                    uVar16 = 0x3c;
                    uVar17 = 0x3c;
                }
                goto code_r0x00018018fcc1;
            case 0x3c:
                if (uVar15 == 0xd) {
                    uVar17 = 0x3d;
                    uVar16 = 0x3d;
                    if (puVar18 != (uint8_t *)0x0) {
                        if (*(int64_t *)(arg2 + 0x30) != 0) {
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffef7ff;
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0xf400;
                            iVar4 = (**(code **)(arg2 + 0x30))(arg1, puVar18, (int64_t)puVar21 - (int64_t)puVar18);
                            if (iVar4 != 0) {
                                *(uint32_t *)(arg1 + 4) = uVar20;
                                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x86ffffff | 0x6000000;
                            }
                            if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
                            uVar17 = *(uint32_t *)arg1 >> 10 & 0x7f;
                        }
                        var_68h = 0;
                        uVar16 = uVar17;
                    }
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x3d:
                if (uVar15 != 10) break;
                uVar20 = 0;
                *(undefined4 *)(arg1 + 4) = 0;
                if (*(int64_t *)(arg2 + 0x48) != 0) {
                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffed7ff;
                    *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0xd400;
                    iVar4 = (**(code **)(arg2 + 0x48))(arg1);
                    if (iVar4 != 0) {
                        *(undefined4 *)(arg1 + 4) = 0;
                        uVar16 = *(uint32_t *)(arg1 + 0x14) & 0x8affffff | 0xa000000;
                        goto code_r0x00018018fc8f;
                    }
                    goto code_r0x00018018fc92;
                }
                uVar16 = 0x35;
                uVar17 = 0x35;
                goto code_r0x00018018fcc1;
            case 0x3e:
                uVar11 = *(uint64_t *)(arg1 + 8);
                uVar10 = (arg3 - (int64_t)puVar21) + arg4;
                uVar12 = uVar11;
                if (uVar10 <= uVar11) {
                    uVar12 = uVar10;
                }
                var_68h = (int64_t)puVar18;
                if (puVar18 == (uint8_t *)0x0) {
                    var_68h = (int64_t)puVar21;
                }
                *(uint64_t *)(arg1 + 8) = uVar11 - uVar12;
                puVar21 = puVar21 + (uVar12 - 1);
                if (uVar11 - uVar12 != 0) goto code_r0x00018018fcc1;
                uVar17 = 0x40;
                puVar14 = (uint8_t *)var_8h;
                puVar18 = (uint8_t *)var_68h;
                uVar16 = 0x40;
                if ((uint8_t *)var_68h != (uint8_t *)0x0) {
                    if (*(int64_t *)(arg2 + 0x30) != 0) {
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xffff03ff;
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0x10000;
                        iVar4 = (**(code **)(arg2 + 0x30))(arg1, var_68h, puVar21 + (1 - var_68h));
                        if (iVar4 != 0) {
                            *(uint32_t *)(arg1 + 4) = uVar20;
                            *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x86ffffff | 0x6000000;
                        }
                        if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x000180191077;
                        uVar17 = *(uint32_t *)arg1 >> 10 & 0x7f;
                    }
                    var_68h = 0;
                    puVar18 = (uint8_t *)0x0;
                    uVar16 = uVar17;
                }
                goto code_r0x00018018f1c0;
            case 0x3f:
                var_68h = (int64_t)puVar18;
                if (puVar18 == (uint8_t *)0x0) {
                    var_68h = (int64_t)puVar21;
                }
                puVar21 = (uint8_t *)(arg4 + -1 + arg3);
                goto code_r0x00018018fcc1;
            case 0x40:
                if ((*(int16_t *)(arg1 + 0x10) == 0) || (*(int16_t *)(arg1 + 0x12) == 0)) {
                    uVar17 = *(uint32_t *)arg1;
                    uVar16 = uVar17 & 8;
                } else {
                    uVar17 = *(uint32_t *)arg1;
                    uVar16 = uVar17 & 0x10;
                }
                if ((uVar16 == 0) ||
                   ((((((uVar17 & 3) != 0 && (uVar16 = *(uint32_t *)(arg1 + 0x14) & 0xffff, 99 < uVar16 - 100)) &&
                      (uVar16 != 0xcc)) && ((uVar16 != 0x130 && ((uVar17 >> 2 & 0x40) == 0)))) &&
                    (((uVar17 >> 2 & 1) == 0 && (*(int64_t *)(arg1 + 8) == -1)))))) {
                    uVar16 = 1;
                } else {
                    uVar16 = 4;
                    if ((uVar17 & 3) == 0) {
                        uVar16 = 0x12;
                    }
                }
                if (*(int64_t *)(arg2 + 0x38) != 0) {
                    *(uint32_t *)arg1 = uVar17 & 0xfffe03ff | uVar16 << 10;
                    iVar4 = (**(code **)(arg2 + 0x38))(arg1);
                    if (iVar4 != 0) {
                        *(uint32_t *)(arg1 + 4) = uVar20;
                        *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x87ffffff | 0x7000000;
                    }
                    uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
                    if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
                }
                uVar17 = uVar16;
                if (*(int32_t *)(arg1 + 0x14) < 0) {
                    *(uint32_t *)(arg1 + 4) = uVar20;
                    *(uint32_t *)arg1 = *(uint32_t *)arg1 ^ (uVar16 << 10 ^ *(uint32_t *)arg1) & 0x1fc00;
                    return puVar21 + (1 - arg3);
                }
                goto code_r0x00018018fcc1;
            }
            uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x9effffff | 0x1e000000;
            goto code_r0x000180191213;
        }
        goto code_r0x000180191002;
    }
code_r0x000180191250:
    if ((var_78h == 0) || (*(int64_t *)(arg2 + 0x18) == 0)) {
code_r0x0001801912a6:
        if ((var_8h != 0) && (*(int64_t *)(arg2 + 0x20) != 0)) {
            *(uint32_t *)arg1 = *(uint32_t *)arg1 ^ (uVar16 << 10 ^ *(uint32_t *)arg1) & 0x1fc00;
            iVar4 = (**(code **)(arg2 + 0x20))(arg1, var_8h, (int64_t)puVar21 - var_8h);
            if (iVar4 != 0) {
                *(uint32_t *)(arg1 + 4) = uVar20;
                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x84ffffff | 0x4000000;
            }
            if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x000180191077;
            uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
        }
        if ((var_60h != 0) && (*(int64_t *)(arg2 + 8) != 0)) {
            *(uint32_t *)arg1 = *(uint32_t *)arg1 ^ (uVar16 << 10 ^ *(uint32_t *)arg1) & 0x1fc00;
            iVar4 = (**(code **)(arg2 + 8))(arg1, var_60h, (int64_t)puVar21 - var_60h);
            if (iVar4 != 0) {
                *(uint32_t *)(arg1 + 4) = uVar20;
                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x82ffffff | 0x2000000;
            }
            if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x000180191077;
            uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
        }
        if ((var_68h != 0) && (*(int64_t *)(arg2 + 0x30) != 0)) {
            *(uint32_t *)arg1 = *(uint32_t *)arg1 ^ (uVar16 << 10 ^ *(uint32_t *)arg1) & 0x1fc00;
            iVar4 = (**(code **)(arg2 + 0x30))(arg1, var_68h, (int64_t)puVar21 - var_68h);
            if (iVar4 != 0) {
                *(uint32_t *)(arg1 + 4) = uVar20;
                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x86ffffff | 0x6000000;
            }
            if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x000180191077;
            uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
        }
        if ((var_58h != 0) && (*(int64_t *)(arg2 + 0x10) != 0)) {
            *(uint32_t *)arg1 = *(uint32_t *)arg1 ^ (uVar16 << 10 ^ *(uint32_t *)arg1) & 0x1fc00;
            iVar4 = (**(code **)(arg2 + 0x10))(arg1, var_58h, (int64_t)puVar21 - var_58h);
            if (iVar4 != 0) {
                *(uint32_t *)(arg1 + 4) = uVar20;
                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x88ffffff | 0x8000000;
            }
            if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x000180191077;
            uVar16 = *(uint32_t *)arg1 >> 10;
        }
        *(uint32_t *)(arg1 + 4) = uVar20;
        *(uint32_t *)arg1 = *(uint32_t *)arg1 ^ (uVar16 << 10 ^ *(uint32_t *)arg1) & 0x1fc00;
    } else {
        *(uint32_t *)arg1 = *(uint32_t *)arg1 ^ (uVar16 << 10 ^ *(uint32_t *)arg1) & 0x1fc00;
        iVar4 = (**(code **)(arg2 + 0x18))(arg1, var_78h, (int64_t)puVar21 - var_78h);
        if (iVar4 != 0) {
            *(uint32_t *)(arg1 + 4) = uVar20;
            *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x83ffffff | 0x3000000;
        }
        if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) == 0) {
            uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
            goto code_r0x0001801912a6;
        }
code_r0x000180191077:
        arg4 = (int64_t)(puVar21 + -arg3);
    }
    return (uint8_t *)arg4;
joined_r0x0001801904dd:
    if (puVar21 == (uint8_t *)(arg3 + arg4)) goto code_r0x00018019086d;
    uVar15 = *puVar21;
    if ((uVar15 == 0x20) || (cVar2 = *(char *)((uint64_t)uVar15 + 0x1804a8a50), cVar2 == '\0'))
    goto code_r0x00018019086d;
    uVar8 = *(uint32_t *)arg1;
    // switch table (15 cases) at 0x180191618
    switch(uVar8 >> 0x11 & 0x7f) {
    case 0:
        puVar14 = puVar21 + 1;
        uVar11 = (arg3 - (int64_t)puVar21) + arg4;
        uVar9 = (uint64_t)*(uint32_t *)0x18069c350;
        if (uVar11 < *(uint32_t *)0x18069c350) {
            uVar9 = uVar11;
        }
        while (puVar14 < (uint8_t *)(uVar9 + arg3)) {
            if ((puVar21[1] == 0x20) || (*(char *)((uint64_t)puVar21[1] + 0x1804a8a50) == '\0')) break;
            puVar14 = puVar21 + 2;
            puVar21 = puVar21 + 1;
        }
        break;
    case 1:
        uVar19 = 0;
        if (cVar2 == 'o') {
            uVar19 = 0x40000;
        }
        *(uint32_t *)arg1 = ((uVar8 + 0x1000000 ^ uVar8) & 0x7f000000 ^ uVar8) & 0xff01ffff | uVar19;
        break;
    case 2:
        uVar19 = 0;
        if (cVar2 == 'n') {
            uVar19 = 0x60000;
        }
        *(uint32_t *)arg1 = ((uVar8 + 0x1000000 ^ uVar8) & 0x7f000000 ^ uVar8) & 0xff01ffff | uVar19;
        break;
    case 3:
        uVar8 = (uVar8 + 0x1000000 ^ uVar8) & 0x7f000000 ^ uVar8;
        if (cVar2 == 'n') {
            *(uint32_t *)arg1 = uVar8 & 0xff09ffff | 0x80000;
        } else if (cVar2 == 't') {
            *(uint32_t *)arg1 = uVar8 & 0xff0dffff | 0xc0000;
        } else {
            *(uint32_t *)arg1 = uVar8 & 0xff01ffff;
        }
        break;
    case 4:
        uVar19 = (uVar8 ^ uVar8 + 0x1000000) & 0x7f000000 ^ uVar8;
        uVar8 = (uVar8 + 0x1000000 & 0x7f000000) >> 0x18;
        *(uint32_t *)arg1 = uVar19;
        if ((uVar8 < 0xb) && (cVar2 == *(char *)((uint64_t)(uVar19 >> 0x18 & 0x7f) + 0x1804a62f8))) {
            if (uVar8 == 9) {
                *(uint32_t *)arg1 = uVar19 & 0xff13ffff | 0x120000;
            }
        } else {
code_r0x000180190698:
            *(uint32_t *)arg1 = uVar19 & 0xff01ffff;
        }
        break;
    case 5:
        uVar19 = (uVar8 ^ uVar8 + 0x1000000) & 0x7f000000 ^ uVar8;
        uVar8 = (uVar8 + 0x1000000 & 0x7f000000) >> 0x18;
        *(uint32_t *)arg1 = uVar19;
        if ((0x10 < uVar8) || (cVar2 != *(char *)((uint64_t)(uVar19 >> 0x18 & 0x7f) + 0x1804a9380)))
        goto code_r0x000180190698;
        if (uVar8 == 0xf) {
            *(uint32_t *)arg1 = uVar19 & 0xff13ffff | 0x120000;
        }
        break;
    case 6:
        uVar19 = (uVar8 ^ uVar8 + 0x1000000) & 0x7f000000 ^ uVar8;
        uVar8 = (uVar8 + 0x1000000 & 0x7f000000) >> 0x18;
        *(uint32_t *)arg1 = uVar19;
        if ((0xe < uVar8) || (cVar2 != *(char *)((uint64_t)(uVar19 >> 0x18 & 0x7f) + 0x1804a8960)))
        goto code_r0x000180190698;
        if (uVar8 == 0xd) {
            *(uint32_t *)arg1 = uVar19 & 0xff15ffff | 0x140000;
        }
        break;
    case 7:
        uVar19 = (uVar8 ^ uVar8 + 0x1000000) & 0x7f000000 ^ uVar8;
        uVar8 = (uVar8 + 0x1000000 & 0x7f000000) >> 0x18;
        *(uint32_t *)arg1 = uVar19;
        if ((0x11 < uVar8) || (cVar2 != *(char *)((uint64_t)(uVar19 >> 0x18 & 0x7f) + 0x1804a9398)))
        goto code_r0x000180190698;
        if (uVar8 == 0x10) {
            *(uint32_t *)arg1 = uVar19 & 0xff1bfffb | 0x1a0000;
        }
        break;
    case 8:
        uVar19 = (uVar8 ^ uVar8 + 0x1000000) & 0x7f000000 ^ uVar8;
        uVar8 = (uVar8 + 0x1000000 & 0x7f000000) >> 0x18;
        *(uint32_t *)arg1 = uVar19;
        if ((7 < uVar8) || (cVar2 != *(char *)((uint64_t)(uVar19 >> 0x18 & 0x7f) + 0x1804a6318)))
        goto code_r0x000180190698;
        if (uVar8 == 6) {
            *(uint32_t *)arg1 = uVar19 & 0xff1dffff | 0x1c0000;
        }
        break;
    case 9:
    case 10:
    case 0xd:
    case 0xe:
        *(uint32_t *)arg1 = uVar8 & 0xff01ffff;
    }
    puVar21 = puVar21 + 1;
    goto joined_r0x0001801904dd;
code_r0x00018018f20f:
    uVar17 = 0x10;
    uVar16 = 0x10;
    if (var_58h == 0) {
        var_58h = (int64_t)puVar21;
    }
    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0x80ffffff;
    if ((uVar15 == 0xd) || (uVar15 == 10)) goto code_r0x00018018f1c0;
    goto code_r0x00018018fcc1;
code_r0x00018019086d:
    if (puVar21 == (uint8_t *)(arg3 + arg4)) {
        puVar21 = puVar21 + -1;
        uVar20 = uVar20 + ((int32_t)puVar21 - iVar4);
        if (uVar20 <= *(uint32_t *)0x18069c350) {
code_r0x00018018fcc1:
            puVar21 = puVar21 + 1;
            if (puVar21 == puVar1) goto code_r0x000180191250;
            goto code_r0x00018018f196;
        }
    } else {
        uVar20 = uVar20 + ((int32_t)puVar21 - iVar4);
        if (uVar20 <= *(uint32_t *)0x18069c350) {
            if (uVar15 == 0x3a) {
                uVar17 = 0x2e;
                uVar16 = 0x2e;
                if (var_78h != 0) {
                    if (*(int64_t *)(arg2 + 0x18) != 0) {
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffebbff;
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0xb800;
                        iVar4 = (**(code **)(arg2 + 0x18))(arg1, var_78h, (int64_t)puVar21 - var_78h);
                        if (iVar4 != 0) {
                            *(uint32_t *)(arg1 + 4) = uVar20;
                            *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x83ffffff | 0x3000000;
                        }
                        if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) {
code_r0x0001801911e6:
                            return puVar21 + (1 - arg3);
                        }
                        uVar17 = *(uint32_t *)arg1 >> 10 & 0x7f;
                    }
                    var_78h = 0;
                    uVar16 = uVar17;
                }
                goto code_r0x00018018fcc1;
            }
code_r0x000180191014:
            uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x98ffffff | 0x18000000;
            goto code_r0x000180191213;
        }
    }
code_r0x000180191002:
    uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x8cffffff | 0xc000000;
code_r0x000180191213:
    *(uint32_t *)(arg1 + 4) = uVar20;
    *(uint32_t *)(arg1 + 0x14) = uVar7;
    if ((uVar7 & 0x7f000000) == 0) {
        *(uint32_t *)(arg1 + 0x14) = uVar7 & 0xa0ffffff | 0x20000000;
    }
    *(uint32_t *)(arg1 + 4) = uVar20;
    *(uint32_t *)arg1 = *(uint32_t *)arg1 ^ (uVar16 << 10 ^ *(uint32_t *)arg1) & 0x1fc00;
code_r0x000180191091:
    return puVar21 + -arg3;
}

// ============================================================
// Function: FUN_18018f10a
// Address: 0x18018f10a
// Size: 8101 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

uint8_t * fcn.18018f030(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    uint8_t *puVar1;
    char cVar2;
    int64_t iVar3;
    int32_t iVar4;
    uint32_t uVar5;
    int32_t iVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    uint8_t uVar13;
    uint8_t *puVar14;
    uint8_t uVar15;
    uint32_t uVar16;
    uint32_t uVar17;
    uint8_t *puVar18;
    uint32_t uVar19;
    uint32_t uVar20;
    uint8_t *puVar21;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    
    if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) {
        return (uint8_t *)0x0;
    }
    uVar7 = *(uint32_t *)arg1;
    uVar20 = *(uint32_t *)(arg1 + 4);
    uVar16 = uVar7 >> 10 & 0x7f;
    if (arg4 == 0) {
        if (uVar16 == 1) {
            return (uint8_t *)0x0;
        }
        if (uVar16 == 2) {
            return (uint8_t *)0x0;
        }
        if (uVar16 == 4) {
            return (uint8_t *)0x0;
        }
        if (uVar16 != 0x12) {
            if (uVar16 != 0x3f) {
                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x8bffffff | 0xb000000;
                return (uint8_t *)0x1;
            }
            if (*(int64_t *)(arg2 + 0x38) != 0) {
                *(uint32_t *)arg1 = (uVar7 & 0xfffffc00 ^ uVar7) & 0x1fc00 ^ uVar7;
                iVar4 = (**(code **)(arg2 + 0x38))();
                if (iVar4 != 0) {
                    *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x87ffffff;
                    *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) | 0x7000000;
                    *(uint32_t *)(arg1 + 4) = uVar20;
                    return (uint8_t *)0x0;
                }
                return (uint8_t *)0x0;
            }
            return (uint8_t *)0x0;
        }
        return (uint8_t *)0x0;
    }
    var_58h = 0;
    var_60h = 0;
    var_68h = 0;
    var_78h = arg3;
    if (uVar16 != 0x2d) {
        var_78h = 0;
    }
    var_8h = arg3;
    if (uVar16 != 0x32) {
        var_8h = 0;
    }
    // switch table (16 cases) at 0x180191420
    switch(uVar16) {
    case 0x10:
        var_58h = arg3;
        break;
    case 0x15:
    case 0x16:
    case 0x17:
    case 0x18:
    case 0x19:
    case 0x1a:
    case 0x1b:
    case 0x1c:
    case 0x1d:
    case 0x1e:
    case 0x1f:
        var_60h = arg3;
    }
    puVar1 = (uint8_t *)(arg3 + arg4);
    puVar21 = (uint8_t *)arg3;
    uVar17 = uVar16;
    if ((uint8_t *)arg3 != puVar1) {
code_r0x00018018f196:
        if ((0x3a < (int32_t)uVar16) || (uVar20 = uVar20 + 1, uVar20 <= *(uint32_t *)0x18069c350)) {
            uVar9 = (uint64_t)*puVar21;
            puVar14 = (uint8_t *)var_8h;
            puVar18 = (uint8_t *)var_68h;
code_r0x00018018f1c0:
            uVar15 = (uint8_t)uVar9;
            if (0x3f < uVar16 - 1) {
                uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x9dffffff | 0x1d000000;
                goto code_r0x000180191213;
            }
            iVar4 = (int32_t)puVar21;
    // switch table (64 cases) at 0x180191460
            switch(uVar16) {
            case 1:
                if ((uVar15 != 0xd) && (uVar15 != 10)) {
                    uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x8dffffff | 0xd000000;
                    goto code_r0x000180191213;
                }
                goto code_r0x00018018fcc1;
            case 2:
                if ((uVar15 != 0xd) && (uVar15 != 10)) {
                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffffc03;
                    *(undefined8 *)(arg1 + 8) = 0xffffffffffffffff;
                    if (uVar15 != 0x48) {
                        uVar16 = 0x12;
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffffffc;
                        goto code_r0x00018018ff9a;
                    }
                    if (*(int64_t *)arg2 != 0) {
                        uVar16 = *(uint32_t *)arg1 & 0xfffe0fff | 0xc00;
code_r0x00018018fc73:
                        *(uint32_t *)arg1 = uVar16;
                        goto code_r0x00018018fc75;
                    }
                    uVar16 = 3;
                    uVar17 = 3;
                }
                goto code_r0x00018018fcc1;
            case 3:
                if (uVar15 == 0x54) {
                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffffffd | 1;
                    uVar16 = 6;
                    uVar17 = 6;
                } else {
                    if (uVar15 != 0x45) goto code_r0x0001801910c1;
                    *(undefined *)(arg1 + 0x16) = 2;
                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0x82fffffc | 0x2000000;
                    uVar16 = 0x13;
                    uVar17 = 0x13;
                }
                goto code_r0x00018018fcc1;
            case 4:
                if ((uVar15 != 0xd) && (uVar15 != 10)) {
                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffffc03;
                    *(undefined8 *)(arg1 + 8) = 0xffffffffffffffff;
                    if (uVar15 != 0x48) goto code_r0x0001801910c1;
                    if (*(int64_t *)arg2 != 0) {
                        uVar16 = *(uint32_t *)arg1 & 0xfffe17ff | 0x1400;
                        goto code_r0x00018018fc73;
                    }
                    uVar16 = 5;
                    uVar17 = 5;
                }
                goto code_r0x00018018fcc1;
            case 5:
                if (uVar15 == 0x54) {
                    uVar16 = 6;
                    uVar17 = 6;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 6:
                if (uVar15 == 0x54) {
                    uVar16 = 7;
                    uVar17 = 7;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 7:
                if (uVar15 == 0x50) {
                    uVar16 = 8;
                    uVar17 = 8;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 8:
                if (uVar15 == 0x2f) {
                    uVar16 = 9;
                    uVar17 = 9;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 9:
                if (9 < (uint8_t)(uVar15 - 0x30)) goto code_r0x0001801910d3;
                *(int16_t *)(arg1 + 0x10) = (char)uVar15 + -0x30;
                uVar16 = 10;
                uVar17 = 10;
                goto code_r0x00018018fcc1;
            case 10:
                if (uVar15 != 0x2e) goto code_r0x0001801910d3;
                uVar16 = 0xb;
                uVar17 = 0xb;
                goto code_r0x00018018fcc1;
            case 0xb:
                if (9 < (uint8_t)(uVar15 - 0x30)) goto code_r0x0001801910d3;
                *(int16_t *)(arg1 + 0x12) = (char)uVar15 + -0x30;
                uVar16 = 0xc;
                uVar17 = 0xc;
                goto code_r0x00018018fcc1;
            case 0xc:
                if (uVar15 != 0x20) goto code_r0x0001801910d3;
                uVar16 = 0xd;
                uVar17 = 0xd;
                goto code_r0x00018018fcc1;
            case 0xd:
                if ((uint8_t)(uVar15 - 0x30) < 10) {
                    *(int16_t *)(arg1 + 0x14) = (char)uVar15 + -0x30;
                    uVar16 = 0xe;
                    uVar17 = 0xe;
                } else if (uVar15 != 0x20) {
code_r0x00018018fe6d:
                    uVar8 = *(uint32_t *)(arg1 + 0x14);
                    goto code_r0x00018018fe70;
                }
                goto code_r0x00018018fcc1;
            case 0xe:
                if ((uint8_t)(uVar15 - 0x30) < 10) {
                    *(int16_t *)(arg1 + 0x14) = *(int16_t *)(arg1 + 0x14) * 10 + -0x30 + (int16_t)(char)uVar15;
                    uVar8 = *(uint32_t *)(arg1 + 0x14);
                    if (999 < (uint16_t)uVar8) {
code_r0x00018018fe70:
                        uVar7 = uVar8 & 0x8fffffff | 0xf000000;
                        goto code_r0x000180191213;
                    }
                    goto code_r0x00018018fcc1;
                }
                if ((uVar15 != 10) && (uVar15 != 0xd)) {
                    if (uVar15 != 0x20) goto code_r0x00018018fe6d;
                    uVar16 = 0xf;
                    uVar17 = 0xf;
                    goto code_r0x00018018fcc1;
                }
                uVar16 = 0xf;
                uVar17 = 0xf;
                goto code_r0x00018018f1c0;
            case 0xf:
                goto code_r0x00018018f20f;
            case 0x10:
                if (uVar15 == 0xd) {
                    uVar17 = 0x11;
                    uVar16 = 0x11;
                    if (var_58h != 0) {
                        if (*(int64_t *)(arg2 + 0x10) != 0) {
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffe47ff;
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0x4400;
                            iVar4 = (**(code **)(arg2 + 0x10))(arg1, var_58h, (int64_t)puVar21 - var_58h);
                            if (iVar4 != 0) {
                                *(uint32_t *)(arg1 + 4) = uVar20;
                                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x88ffffff | 0x8000000;
                            }
                            if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
                            uVar17 = *(uint32_t *)arg1 >> 10 & 0x7f;
                        }
                        var_58h = 0;
                        uVar16 = uVar17;
                    }
                } else if (uVar15 == 10) {
                    uVar17 = 0x2c;
                    uVar16 = 0x2c;
                    if (var_58h != 0) {
                        if (*(int64_t *)(arg2 + 0x10) != 0) {
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffeb3ff;
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0xb000;
                            iVar4 = (**(code **)(arg2 + 0x10))(arg1, var_58h, (int64_t)puVar21 - var_58h);
                            if (iVar4 != 0) {
                                *(uint32_t *)(arg1 + 4) = uVar20;
                                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x88ffffff | 0x8000000;
                            }
                            if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
                            uVar17 = *(uint32_t *)arg1 >> 10 & 0x7f;
                        }
                        var_58h = 0;
                        uVar16 = uVar17;
                    }
                }
                goto code_r0x00018018fcc1;
            case 0x11:
                if (uVar15 == 10) {
                    uVar16 = 0x2c;
                    uVar17 = 0x2c;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x12:
                if ((uVar15 != 0xd) && (uVar15 != 10)) {
code_r0x00018018ff9a:
                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffffc03;
                    uVar17 = *(uint32_t *)arg1;
                    *(undefined8 *)(arg1 + 8) = 0xffffffffffffffff;
                    if (0x19 < (uint8_t)((uVar15 | 0x20) + 0x9f)) goto code_r0x0001801910e5;
                    *(undefined *)(arg1 + 0x16) = 0;
                    *(uint32_t *)arg1 = uVar17 & 0x81ffffff | 0x1000000;
    // switch table (21 cases) at 0x1801915c4
                    switch(uVar15) {
                    case 0x41:
                        *(undefined *)(arg1 + 0x16) = 0x13;
                        break;
                    case 0x42:
                        *(undefined *)(arg1 + 0x16) = 0x10;
                        break;
                    case 0x43:
                        *(undefined *)(arg1 + 0x16) = 5;
                        break;
                    case 0x44:
                        break;
                    default:
                        goto code_r0x0001801910e5;
                    case 0x47:
                        *(undefined *)(arg1 + 0x16) = 1;
                        break;
                    case 0x48:
                        *(undefined *)(arg1 + 0x16) = 2;
                        break;
                    case 0x4c:
                        *(undefined *)(arg1 + 0x16) = 9;
                        break;
                    case 0x4d:
                        *(undefined *)(arg1 + 0x16) = 10;
                        break;
                    case 0x4e:
                        *(undefined *)(arg1 + 0x16) = 0x19;
                        break;
                    case 0x4f:
                        *(undefined *)(arg1 + 0x16) = 6;
                        break;
                    case 0x50:
                        *(undefined *)(arg1 + 0x16) = 3;
                        break;
                    case 0x52:
                        *(undefined *)(arg1 + 0x16) = 0x14;
                        break;
                    case 0x53:
                        *(undefined *)(arg1 + 0x16) = 0x1a;
                        break;
                    case 0x54:
                        *(undefined *)(arg1 + 0x16) = 7;
                        break;
                    case 0x55:
                        *(undefined *)(arg1 + 0x16) = 0xf;
                    }
                    if (*(int64_t *)arg2 == 0) {
                        uVar16 = 0x13;
                        uVar17 = 0x13;
                    } else {
                        *(uint32_t *)arg1 = uVar17 & 0x81fe4fff | 0x1004c00;
code_r0x00018018fc75:
                        iVar4 = (**(code **)arg2)(arg1);
                        if (iVar4 != 0) {
                            *(uint32_t *)(arg1 + 4) = uVar20;
                            uVar16 = *(uint32_t *)(arg1 + 0x14) & 0x81ffffff | 0x1000000;
code_r0x00018018fc8f:
                            *(uint32_t *)(arg1 + 0x14) = uVar16;
                        }
code_r0x00018018fc92:
                        if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
code_r0x00018018fc9f:
                        uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
                        uVar17 = uVar16;
                    }
                }
                goto code_r0x00018018fcc1;
            case 0x13:
                if (uVar15 == 0) {
code_r0x0001801910e5:
                    uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x90ffffff | 0x10000000;
                    goto code_r0x000180191213;
                }
                iVar3 = *(int64_t *)((uint64_t)*(uint8_t *)(arg1 + 0x16) * 8 + 0x18069c360);
                if ((uVar15 == 0x20) && (*(char *)((uint64_t)(*(uint8_t *)(arg1 + 3) & 0x7f) + iVar3) == '\0')) {
                    uVar17 = 0x14;
                    uVar16 = 0x14;
                } else if (uVar15 != *(uint8_t *)((uint64_t)(*(uint32_t *)arg1 >> 0x18 & 0x7f) + iVar3)) {
                    if ((0x19 < (uint8_t)(uVar15 + 0xbf)) && (uVar15 != 0x2d)) {
code_r0x0001801910f6:
                        uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x90ffffff | 0x10000000;
                        goto code_r0x000180191213;
                    }
                    uVar8 = (uint32_t)*(uint8_t *)(arg1 + 0x16) << 0x10 | *(uint32_t *)arg1 >> 0x10 & 0x7f00 |
                            (int32_t)(char)uVar15;
                    if (uVar8 < 0xa0150) {
                        if (uVar8 == 0xa014f) {
                            *(undefined *)(arg1 + 0x16) = 0xb;
                        } else if (uVar8 < 0x50149) {
                            if (uVar8 == 0x50148) {
                                *(undefined *)(arg1 + 0x16) = 0x16;
                            } else if (uVar8 == 0x30141) {
                                *(undefined *)(arg1 + 0x16) = 0x1c;
                            } else if (uVar8 == 0x30152) {
                                *(undefined *)(arg1 + 0x16) = 0xc;
                            } else if (uVar8 == 0x30155) {
                                *(undefined *)(arg1 + 0x16) = 4;
                            } else {
                                if (uVar8 != 0x40252) goto code_r0x0001801910f6;
                                *(undefined *)(arg1 + 0x16) = 0x1d;
                            }
                        } else if (uVar8 == 0x50250) {
                            *(undefined *)(arg1 + 0x16) = 8;
                        } else if (uVar8 == 0x90149) {
                            *(undefined *)(arg1 + 0x16) = 0x1f;
                        } else if (uVar8 == 0xa012d) {
                            *(undefined *)(arg1 + 0x16) = 0x18;
                        } else {
                            if (uVar8 != 0xa0145) goto code_r0x0001801910f6;
                            *(undefined *)(arg1 + 0x16) = 0x17;
                        }
                    } else if (uVar8 < 0xf0254) {
                        if (uVar8 == 0xf0253) {
                            *(undefined *)(arg1 + 0x16) = 0x1b;
                        } else if (uVar8 == 0xa0241) {
                            *(undefined *)(arg1 + 0x16) = 0x15;
                        } else if (uVar8 == 0xa0341) {
                            *(undefined *)(arg1 + 0x16) = 0x1e;
                        } else if (uVar8 == 0xc0450) {
                            *(undefined *)(arg1 + 0x16) = 0xd;
                        } else {
                            if (uVar8 != 0xf0242) goto code_r0x0001801910f6;
                            *(undefined *)(arg1 + 0x16) = 0x12;
                        }
                    } else if (uVar8 == 0xf0349) {
                        *(undefined *)(arg1 + 0x16) = 0x20;
                    } else if (uVar8 == 0x140242) {
                        *(undefined *)(arg1 + 0x16) = 0x11;
                    } else if (uVar8 == 0x1a0145) {
                        *(undefined *)(arg1 + 0x16) = 0xe;
                    } else {
                        if (uVar8 != 0x1a014f) goto code_r0x0001801910f6;
                        *(undefined *)(arg1 + 0x16) = 0x21;
                    }
                }
                uVar8 = *(uint32_t *)arg1;
                *(uint32_t *)arg1 = (uVar8 + 0x1000000 ^ uVar8) & 0x7f000000 ^ uVar8;
                goto code_r0x00018018fcc1;
            case 0x14:
                if (uVar15 != 0x20) {
                    if (var_60h == 0) {
                        var_60h = (int64_t)puVar21;
                    }
                    if (*(char *)(arg1 + 0x16) == '\x05') {
                        uVar16 = 0x18;
                    }
                    goto code_r0x000180190245;
                }
                goto code_r0x00018018fcc1;
            case 0x15:
            case 0x16:
            case 0x17:
            case 0x18:
                if ((uVar15 < 0x21) && ((0x100002400U >> (uVar9 & 0x3f) & 1) != 0)) {
                    uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x91ffffff | 0x11000000;
                    goto code_r0x000180191213;
                }
code_r0x000180190245:
                uVar16 = fcn.1801916d0(uVar16, uVar9 & 0xff);
                uVar17 = uVar16;
                if (uVar16 == 1) {
                    uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x91ffffff | 0x11000000;
                    goto code_r0x000180191213;
                }
                goto code_r0x00018018fcc1;
            default:
                if ((uVar15 == 10) || (uVar15 == 0xd)) {
                    *(undefined4 *)(arg1 + 0x10) = 0x90000;
                    uVar17 = (uVar15 != 0xd) + 0x2b;
                    uVar16 = uVar17;
                    if (var_60h != 0) {
                        if (*(int64_t *)(arg2 + 8) == 0) goto code_r0x000180190316;
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffe03ff;
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 | uVar17 * 0x400;
                        iVar4 = (**(code **)(arg2 + 8))(arg1, var_60h, (int64_t)puVar21 - var_60h);
                        if (iVar4 != 0) {
                            *(uint32_t *)(arg1 + 4) = uVar20;
                            *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x82ffffff | 0x2000000;
                        }
                        if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) == 0) {
                            var_60h = 0;
                            goto code_r0x00018018fc9f;
                        }
                        goto code_r0x0001801911e6;
                    }
                } else {
                    if (uVar15 != 0x20) goto code_r0x000180190245;
                    uVar17 = 0x20;
                    uVar16 = 0x20;
                    if (var_60h != 0) {
                        if (*(int64_t *)(arg2 + 8) != 0) {
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffe83ff;
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0x8000;
                            iVar4 = (**(code **)(arg2 + 8))(arg1, var_60h, (int64_t)puVar21 - var_60h);
                            if (iVar4 != 0) {
                                *(uint32_t *)(arg1 + 4) = uVar20;
                                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x82ffffff | 0x2000000;
                            }
                            if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
                            uVar17 = *(uint32_t *)arg1 >> 10 & 0x7f;
                        }
code_r0x000180190316:
                        var_60h = 0;
                        uVar16 = uVar17;
                    }
                }
                goto code_r0x00018018fcc1;
            case 0x20:
                if (uVar15 != 0x20) {
                    if (uVar15 == 0x48) {
                        uVar16 = 0x21;
                        uVar17 = 0x21;
                    } else {
                        if ((uVar15 != 0x49) || (*(char *)(arg1 + 0x16) != '!')) {
code_r0x0001801910c1:
                            uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x9cffffff | 0x1c000000;
                            goto code_r0x000180191213;
                        }
                        uVar16 = 0x25;
                        uVar17 = 0x25;
                    }
                }
                goto code_r0x00018018fcc1;
            case 0x21:
                if (uVar15 == 0x54) {
                    uVar16 = 0x22;
                    uVar17 = 0x22;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x22:
                if (uVar15 == 0x54) {
                    uVar16 = 0x23;
                    uVar17 = 0x23;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x23:
                if (uVar15 == 0x50) {
                    uVar16 = 0x24;
                    uVar17 = 0x24;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x24:
                if (uVar15 == 0x2f) {
                    uVar16 = 0x27;
                    uVar17 = 0x27;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x25:
                if (uVar15 == 0x43) {
                    uVar16 = 0x26;
                    uVar17 = 0x26;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x26:
                if (uVar15 == 0x45) {
                    uVar16 = 0x24;
                    uVar17 = 0x24;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x27:
                if (9 < (uint8_t)(uVar15 - 0x30)) goto code_r0x0001801910d3;
                *(int16_t *)(arg1 + 0x10) = (char)uVar15 + -0x30;
                uVar16 = 0x28;
                uVar17 = 0x28;
                goto code_r0x00018018fcc1;
            case 0x28:
                if (uVar15 != 0x2e) goto code_r0x0001801910d3;
                uVar16 = 0x29;
                uVar17 = 0x29;
                goto code_r0x00018018fcc1;
            case 0x29:
                if (9 < (uint8_t)(uVar15 - 0x30)) goto code_r0x0001801910d3;
                *(int16_t *)(arg1 + 0x12) = (char)uVar15 + -0x30;
                uVar16 = 0x2a;
                uVar17 = 0x2a;
                goto code_r0x00018018fcc1;
            case 0x2a:
                if (uVar15 == 0xd) {
                    uVar16 = 0x2b;
                    uVar17 = 0x2b;
                } else {
                    if (uVar15 != 10) {
code_r0x0001801910d3:
                        uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x8effffff | 0xe000000;
                        goto code_r0x000180191213;
                    }
                    uVar16 = 0x2c;
                    uVar17 = 0x2c;
                }
                goto code_r0x00018018fcc1;
            case 0x2b:
                if (uVar15 != 10) goto code_r0x00018019110f;
                uVar16 = 0x2c;
                uVar17 = 0x2c;
                goto code_r0x00018018fcc1;
            case 0x2c:
                if (uVar15 == 0xd) {
                    uVar16 = 0x39;
                    uVar17 = 0x39;
                    goto code_r0x00018018fcc1;
                }
                if (uVar15 != 10) {
                    if ((uVar15 == 0x20) || (cVar2 = *(char *)((uVar9 & 0xff) + 0x1804a8a50), cVar2 == '\0'))
                    goto code_r0x000180191014;
                    uVar17 = 0x2d;
                    uVar16 = 0x2d;
                    uVar8 = *(uint32_t *)arg1;
                    if (var_78h == 0) {
                        var_78h = (int64_t)puVar21;
                    }
                    if (cVar2 == 'c') {
                        *(uint32_t *)arg1 = uVar8 & 0x8003ffff | 0x20000;
                    } else if (cVar2 == 'p') {
                        *(uint32_t *)arg1 = uVar8 & 0x800bffff | 0xa0000;
                    } else if (cVar2 == 't') {
                        *(uint32_t *)arg1 = uVar8 & 0x800fffff | 0xe0000;
                    } else if (cVar2 == 'u') {
                        *(uint32_t *)arg1 = uVar8 & 0x8011ffff | 0x100000;
                    } else {
                        *(uint32_t *)arg1 = uVar8 & 0x8001ffff;
                    }
                    goto code_r0x00018018fcc1;
                }
                uVar16 = 0x39;
                uVar17 = 0x39;
                goto code_r0x00018018f1c0;
            case 0x2d:
                goto joined_r0x0001801904dd;
            case 0x2e:
                if ((uVar15 != 0x20) && (uVar15 != 9)) {
                    if (uVar15 == 0xd) {
                        uVar16 = 0x2f;
                        uVar17 = 0x2f;
                    } else {
                        if (uVar15 != 10) goto code_r0x000180190971;
                        uVar16 = 0x30;
                        uVar17 = 0x30;
                    }
                }
                goto code_r0x00018018fcc1;
            case 0x2f:
                if (uVar15 == 10) {
                    uVar16 = 0x30;
                    uVar17 = 0x30;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x30:
                if ((uVar15 == 0x20) || (uVar15 == 9)) {
                    uVar16 = 0x2e;
                    uVar17 = 0x2e;
                    goto code_r0x00018018fcc1;
                }
                uVar8 = *(uint32_t *)arg1;
                uVar17 = uVar8 >> 0x11 & 0x7f;
                if (uVar17 == 10) goto code_r0x000180191033;
                if (uVar17 == 0x15) {
                    uVar8 = uVar8 | 4;
code_r0x00018018f7a7:
                    *(uint32_t *)arg1 = uVar8;
                } else {
                    if (uVar17 == 0x16) {
                        uVar8 = uVar8 | 8;
                        goto code_r0x00018018f7a7;
                    }
                    if (uVar17 == 0x17) {
                        uVar8 = uVar8 | 0x10;
                        goto code_r0x00018018f7a7;
                    }
                    if (uVar17 == 0x18) {
                        uVar8 = uVar8 | 0x20;
                        goto code_r0x00018018f7a7;
                    }
                }
                uVar17 = 0x2c;
                var_8h = (int64_t)puVar14;
                if (puVar14 == (uint8_t *)0x0) {
                    var_8h = (int64_t)puVar21;
                }
                puVar14 = (uint8_t *)var_8h;
                uVar16 = 0x2c;
                if ((uint8_t *)var_8h != (uint8_t *)0x0) {
                    if (*(int64_t *)(arg2 + 0x20) != 0) {
                        *(uint32_t *)arg1 = uVar8 & 0xfffeb3ff | 0xb000;
                        iVar4 = (**(code **)(arg2 + 0x20))(arg1, var_8h, (int64_t)puVar21 - var_8h);
                        if (iVar4 != 0) {
                            *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x84ffffff;
                            *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) | 0x4000000;
                            *(uint32_t *)(arg1 + 4) = uVar20;
                        }
                        if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x000180191077;
                        uVar17 = *(uint32_t *)arg1 >> 10 & 0x7f;
                    }
                    var_8h = 0;
                    puVar14 = (uint8_t *)0x0;
                    uVar16 = uVar17;
                }
                goto code_r0x00018018f1c0;
            case 0x31:
code_r0x000180190971:
                uVar17 = 0x32;
                uVar16 = 0x32;
                var_8h = (int64_t)puVar14;
                if (puVar14 == (uint8_t *)0x0) {
                    var_8h = (int64_t)puVar21;
                }
                *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0x80ffffff;
                uVar8 = *(uint32_t *)arg1;
                uVar13 = uVar15 | 0x20;
    // switch table (8 cases) at 0x180191654
                switch(uVar8 >> 0x11 & 0x7f) {
                case 9:
                    if (uVar13 == 0x6b) {
                        *(uint32_t *)arg1 = uVar8 & 0xff23ffff | 0x220000;
                    } else if (uVar13 == 99) {
                        *(uint32_t *)arg1 = uVar8 & 0xff25ffff | 0x240000;
                    } else if (uVar13 == 0x75) {
                        *(uint32_t *)arg1 = uVar8 & 0xff27ffff | 0x260000;
                    } else {
                        *(uint32_t *)arg1 = uVar8 & 0xff29ffff | 0x280000;
                    }
                    break;
                case 10:
                    if (9 < (uint8_t)(uVar15 - 0x30)) {
code_r0x000180191033:
                        uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x99ffffff | 0x19000000;
                        goto code_r0x000180191213;
                    }
                    if ((uVar8 >> 9 & 1) != 0) {
code_r0x000180191045:
                        uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x9affffff | 0x1a000000;
                        goto code_r0x000180191213;
                    }
                    *(int64_t *)(arg1 + 8) = (int64_t)((char)uVar15 + -0x30);
                    *(uint32_t *)arg1 = uVar8 & 0xff17ffff | 0x160200;
                    break;
                case 0xc:
                case 0x10:
                    break;
                case 0xd:
                    if (uVar13 == 99) {
                        *(uint32_t *)arg1 = uVar8 & 0xff1fffff | 0x1e0000;
                        break;
                    }
                default:
                    *(uint32_t *)arg1 = uVar8 & 0xff01ffff;
                    break;
                case 0xe:
                    *(uint32_t *)arg1 = uVar8 & 0xff01ffff | 0x80;
                }
                goto code_r0x00018018fcc1;
            case 0x32:
                uVar8 = *(uint32_t *)arg1 >> 0x11 & 0x7f;
code_r0x00018018f261:
                if (puVar21 != puVar1) {
                    uVar15 = *puVar21;
                    uVar9 = (uint64_t)(uint32_t)(int32_t)(char)uVar15;
                    if (uVar15 != 0xd) {
                        if (uVar15 != 10) {
                            if (((-1 < (int32_t)uVar7) && (uVar15 != 9)) && ((uVar15 < 0x20 || (uVar15 == 0x7f))))
                            goto code_r0x000180191014;
                            uVar13 = uVar15 | 0x20;
    // switch table (25 cases) at 0x180191560
                            switch(uVar8) {
                            case 0:
                                uVar9 = (arg3 - (int64_t)puVar21) + arg4;
                                if ((int64_t)(uint64_t)*(uint32_t *)0x18069c350 <= (int64_t)uVar9) {
                                    uVar9 = (uint64_t)*(uint32_t *)0x18069c350;
                                }
                                puVar14 = puVar21 + uVar9;
                                for (; puVar21 != puVar14; puVar21 = puVar21 + 1) {
                                    uVar15 = *puVar21;
                                    if ((uVar15 == 0xd) || (uVar15 == 10)) {
                                        puVar21 = puVar21 + -1;
                                        break;
                                    }
                                    if (((-1 < (int32_t)uVar7) && (uVar15 != 9)) &&
                                       ((uVar15 < 0x20 || (uVar15 == 0x7f)))) goto code_r0x000180191014;
                                }
                                if (puVar21 == puVar1) goto code_r0x00018018f261;
                                break;
                            default:
                                uVar17 = 0x32;
                                uVar16 = 0x32;
code_r0x00018018f612:
                                uVar8 = 0;
                                break;
                            case 9:
                            case 0xd:
                                break;
                            case 10:
                                if (uVar15 != 0x20) {
                                    uVar8 = 0xb;
                                    goto code_r0x00018018f335;
                                }
                                break;
                            case 0xb:
                                if (uVar15 == 0x20) {
                                    uVar8 = 0xc;
                                    puVar21 = puVar21 + 1;
                                } else {
code_r0x00018018f335:
                                    if ((9 < (uint8_t)(uVar15 - 0x30)) || (0x1999999999999998 < *(uint64_t *)(arg1 + 8))
                                       ) {
                                        *(uint32_t *)arg1 =
                                             *(uint32_t *)arg1 ^ (uVar8 << 0x11 ^ *(uint32_t *)arg1) & 0xfe0000;
                                        goto code_r0x000180191033;
                                    }
                                    puVar21 = puVar21 + 1;
                                    *(uint64_t *)(arg1 + 8) =
                                         (int64_t)(int32_t)((int32_t)(char)uVar15 - 0x30) + *(uint64_t *)(arg1 + 8) * 10
                                    ;
                                }
                                goto code_r0x00018018f261;
                            case 0xc:
                                if (uVar15 != 0x20) {
                                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xff01ffff ^ 0x180000;
                                    uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x99ffffff | 0x19000000;
                                    goto code_r0x000180191213;
                                }
                                break;
                            case 0xf:
                                uVar19 = *(uint32_t *)arg1;
                                uVar5 = (uVar19 ^ uVar19 + 0x1000000) & 0x7f000000 ^ uVar19;
                                uVar19 = (uVar19 + 0x1000000 & 0x7f000000) >> 0x18;
                                *(uint32_t *)arg1 = uVar5;
                                if ((7 < uVar19) ||
                                   (uVar13 != *(uint8_t *)((uint64_t)(uVar5 >> 0x18 & 0x7f) + 0x1804a62f0)))
                                goto code_r0x00018018f612;
                                if (uVar19 == 6) {
                                    uVar8 = 0x15;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                break;
                            case 0x10:
                                if (uVar13 == 0x6b) {
                                    uVar8 = 0x11;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                if (uVar13 == 99) {
                                    uVar8 = 0x12;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                if (uVar13 == 0x75) {
                                    uVar8 = 0x13;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                if (uVar13 != 0x20) {
                                    uVar8 = -(uint32_t)(*(char *)((uint64_t)uVar13 + 0x1804a8a50) != '\0') & 0x14;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                break;
                            case 0x11:
                                uVar19 = *(uint32_t *)arg1;
                                uVar5 = (uVar19 ^ uVar19 + 0x1000000) & 0x7f000000 ^ uVar19;
                                uVar19 = (uVar19 + 0x1000000 & 0x7f000000) >> 0x18;
                                *(uint32_t *)arg1 = uVar5;
                                if ((10 < uVar19) ||
                                   (uVar13 != *(uint8_t *)((uint64_t)(uVar5 >> 0x18 & 0x7f) + 0x1804a6308))) {
code_r0x00018018f600:
                                    uVar8 = 0x14;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                if (uVar19 == 9) {
                                    uVar8 = 0x16;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                break;
                            case 0x12:
                                uVar19 = *(uint32_t *)arg1;
                                uVar5 = (uVar19 ^ uVar19 + 0x1000000) & 0x7f000000 ^ uVar19;
                                uVar19 = (uVar19 + 0x1000000 & 0x7f000000) >> 0x18;
                                *(uint32_t *)arg1 = uVar5;
                                if ((5 < uVar19) ||
                                   (uVar13 != *(uint8_t *)((uint64_t)(uVar5 >> 0x18 & 0x7f) + 0x18063c2dc)))
                                goto code_r0x00018018f600;
                                if (uVar19 == 4) {
                                    uVar8 = 0x17;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                break;
                            case 0x13:
                                uVar19 = *(uint32_t *)arg1;
                                uVar5 = (uVar19 ^ uVar19 + 0x1000000) & 0x7f000000 ^ uVar19;
                                uVar19 = (uVar19 + 0x1000000 & 0x7f000000) >> 0x18;
                                *(uint32_t *)arg1 = uVar5;
                                if ((7 < uVar19) ||
                                   (uVar13 != *(uint8_t *)((uint64_t)(uVar5 >> 0x18 & 0x7f) + 0x1804a6318)))
                                goto code_r0x00018018f600;
                                if (uVar19 == 6) {
                                    uVar8 = 0x18;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                break;
                            case 0x14:
                                if (uVar15 == 0x2c) {
                                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0x80ffffff;
                                    uVar8 = 0x10;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                break;
                            case 0x15:
                                if (uVar15 != 0x20) {
                                    uVar8 = 0;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                break;
                            case 0x16:
                            case 0x17:
                            case 0x18:
                                if (uVar15 != 0x2c) {
                                    if (uVar15 != 0x20) goto code_r0x00018018f600;
                                    break;
                                }
                                if (uVar8 == 0x16) {
                                    *(uint32_t *)arg1 = *(uint32_t *)arg1 | 8;
                                    uVar8 = 0x10;
                                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0x80ffffff;
                                    puVar21 = puVar21 + 1;
                                } else if (uVar8 == 0x17) {
                                    *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0x10;
                                    uVar8 = 0x10;
                                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0x80ffffff;
                                    puVar21 = puVar21 + 1;
                                } else {
                                    if (uVar8 == 0x18) {
                                        *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0x20;
                                    }
                                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0x80ffffff;
                                    uVar8 = 0x10;
                                    puVar21 = puVar21 + 1;
                                }
                                goto code_r0x00018018f261;
                            }
                            puVar21 = puVar21 + 1;
                            goto code_r0x00018018f261;
                        }
                        uVar17 = 0x34;
                        uVar16 = 0x34;
                        uVar20 = uVar20 + ((int32_t)puVar21 - iVar4);
                        if (*(uint32_t *)0x18069c350 < uVar20) goto code_r0x000180191002;
                        uVar8 = (uVar8 << 0x11 ^ *(uint32_t *)arg1) & 0xfe0000 ^ *(uint32_t *)arg1;
                        *(uint32_t *)arg1 = uVar8;
                        puVar14 = (uint8_t *)var_8h;
                        puVar18 = (uint8_t *)var_68h;
                        uVar16 = uVar17;
                        if (var_8h != 0) {
                            if (*(int64_t *)(arg2 + 0x20) != 0) {
                                *(uint32_t *)arg1 = uVar8 & 0xfffed3ff | 0xd000;
                                iVar4 = (**(code **)(arg2 + 0x20))(arg1, var_8h, (int64_t)puVar21 - var_8h);
                                if (iVar4 != 0) {
                                    *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x84ffffff;
                                    *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) | 0x4000000;
                                    *(uint32_t *)(arg1 + 4) = uVar20;
                                }
                                if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x000180191077;
                                uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
                            }
                            var_8h = 0;
                            puVar14 = (uint8_t *)var_8h;
                            uVar17 = uVar16;
                        }
                        goto code_r0x00018018f1c0;
                    }
                    uVar17 = 0x34;
                    uVar16 = 0x34;
                    uVar19 = (uVar8 << 0x11 ^ *(uint32_t *)arg1) & 0xfe0000 ^ *(uint32_t *)arg1;
                    *(uint32_t *)arg1 = uVar19;
                    if (var_8h == 0) goto code_r0x00018018fbe9;
                    uVar16 = uVar17;
                    if (*(int64_t *)(arg2 + 0x20) != 0) {
                        *(uint32_t *)arg1 = uVar19 & 0xfffed3ff | 0xd000;
                        iVar6 = (**(code **)(arg2 + 0x20))(arg1, var_8h, (int64_t)puVar21 - var_8h);
                        if (iVar6 != 0) {
                            *(uint32_t *)(arg1 + 4) = uVar20;
                            *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x84ffffff | 0x4000000;
                        }
                        uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
                        if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
                    }
                    var_8h = 0;
                    uVar17 = uVar16;
                }
code_r0x00018018fbe9:
                *(uint32_t *)arg1 = *(uint32_t *)arg1 ^ (uVar8 << 0x11 ^ *(uint32_t *)arg1) & 0xfe0000;
                if (puVar21 == (uint8_t *)(arg3 + arg4)) {
                    puVar21 = puVar21 + -1;
                }
                uVar20 = uVar20 + ((int32_t)puVar21 - iVar4);
                if (*(uint32_t *)0x18069c350 < uVar20) goto code_r0x000180191002;
                goto code_r0x00018018fcc1;
            case 0x33:
                if ((uVar15 == 0x20) || (uVar15 == 9)) {
                    if ((*(uint32_t *)arg1 & 0xfe0000) == 0x160000) {
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xff19ffff | 0x180000;
                    }
                    uVar16 = 0x31;
                    uVar17 = 0x31;
                    goto code_r0x00018018f1c0;
                }
                uVar16 = *(uint32_t *)arg1;
                uVar17 = uVar16 >> 0x11 & 0x7f;
                if (uVar17 == 0x15) {
                    *(uint32_t *)arg1 = uVar16 | 4;
                } else {
                    if (uVar17 == 0x16) {
                        *(uint32_t *)arg1 = uVar16 | 8;
                        uVar16 = 0x2c;
                        uVar17 = 0x2c;
                        goto code_r0x00018018f1c0;
                    }
                    if (uVar17 == 0x17) {
                        *(uint32_t *)arg1 = uVar16 | 0x10;
                        uVar16 = 0x2c;
                        uVar17 = 0x2c;
                        goto code_r0x00018018f1c0;
                    }
                    if (uVar17 == 0x18) {
                        *(uint32_t *)arg1 = uVar16 | 0x20;
                        uVar16 = 0x2c;
                        uVar17 = 0x2c;
                        goto code_r0x00018018f1c0;
                    }
                }
                uVar16 = 0x2c;
                uVar17 = 0x2c;
                goto code_r0x00018018f1c0;
            case 0x34:
                if (uVar15 != 10) {
code_r0x00018019110f:
                    uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x97ffffff | 0x17000000;
                    goto code_r0x000180191213;
                }
                uVar16 = 0x33;
                uVar17 = 0x33;
                goto code_r0x00018018fcc1;
            case 0x35:
                cVar2 = *(char *)((uVar9 & 0xff) + 0x1804a8b50);
                if (cVar2 == -1) {
code_r0x0001801911f7:
                    uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x9bffffff | 0x1b000000;
                    goto code_r0x000180191213;
                }
                *(int64_t *)(arg1 + 8) = (int64_t)cVar2;
                uVar16 = 0x36;
                uVar17 = 0x36;
                goto code_r0x00018018fcc1;
            case 0x36:
                if (uVar15 == 0xd) {
                    uVar16 = 0x38;
                    uVar17 = 0x38;
                } else {
                    cVar2 = *(char *)((uVar9 & 0xff) + 0x1804a8b50);
                    if (cVar2 == -1) {
                        if ((uVar15 != 0x3b) && (uVar15 != 0x20)) goto code_r0x0001801911f7;
                        uVar16 = 0x37;
                        uVar17 = 0x37;
                    } else {
                        if (0xffffffffffffffe < *(uint64_t *)(arg1 + 8)) goto code_r0x000180191033;
                        *(uint64_t *)(arg1 + 8) = *(uint64_t *)(arg1 + 8) * 0x10 + (int64_t)cVar2;
                    }
                }
                goto code_r0x00018018fcc1;
            case 0x37:
                uVar16 = uVar17;
                if (uVar15 == 0xd) {
                    uVar16 = 0x38;
                    uVar17 = uVar16;
                }
                goto code_r0x00018018fcc1;
            case 0x38:
                if (uVar15 == 10) {
                    *(undefined4 *)(arg1 + 4) = 0;
                    if (*(int64_t *)(arg1 + 8) == 0) {
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0x40;
                        uVar17 = 0x2c;
                        uVar16 = 0x2c;
                    } else {
                        uVar17 = 0x3b;
                        uVar16 = 0x3b;
                    }
                    if (*(int64_t *)(arg2 + 0x40) != 0) {
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffe03ff;
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 | uVar16 << 10;
                        iVar4 = (**(code **)(arg2 + 0x40))(arg1);
                        if (iVar4 != 0) {
                            *(undefined4 *)(arg1 + 4) = 0;
                            *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x89ffffff | 0x9000000;
                        }
                        if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
                        uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
                        uVar17 = uVar16;
                    }
                    uVar20 = 0;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x39:
                if (uVar15 != 10) break;
                uVar17 = *(uint32_t *)arg1;
                uVar8 = uVar17 >> 2;
                if ((uVar8 & 0x10) == 0) {
                    if (((uVar8 & 1) != 0) && ((char)(uint8_t)uVar8 < '\0')) goto code_r0x000180191045;
                    if (((uint8_t)uVar8 & 0x28) == 0x28) {
                        if (((uVar17 & 3) == 0) || (*(int16_t *)(arg1 + 0x14) == 0x65)) {
                            uVar17 = 0x80000000;
                            uVar16 = *(uint32_t *)(arg1 + 0x14) & 0x7fffffff;
                        } else {
                            uVar17 = 0;
                            uVar16 = *(uint32_t *)(arg1 + 0x14) & 0x7fffffff;
                        }
                    } else {
                        uVar16 = 0;
                        if (*(char *)(arg1 + 0x16) == '\x05') {
                            uVar16 = 0x80000000;
                        }
                        uVar17 = *(uint32_t *)(arg1 + 0x14) & 0x7fffffff;
                    }
                    *(uint32_t *)(arg1 + 0x14) = uVar16 | uVar17;
                    if ((*(code **)(arg2 + 0x28) != (code *)0x0) &&
                       (iVar4 = (**(code **)(arg2 + 0x28))(arg1), puVar14 = (uint8_t *)var_8h, iVar4 != 0)) {
                        if (iVar4 != 1) {
                            if (iVar4 != 2) {
                                *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffeebff;
                                *(uint32_t *)(arg1 + 4) = uVar20;
                                *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0xe800;
                                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x85ffffff | 0x5000000;
                                goto code_r0x000180191077;
                            }
                            *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) | 0x80000000;
                        }
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0x100;
                    }
                    if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) {
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffeebff;
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0xe800;
                        *(uint32_t *)(arg1 + 4) = uVar20;
                        goto code_r0x000180191091;
                    }
                    uVar16 = 0x3a;
                    uVar17 = 0x3a;
                } else if (*(int64_t *)(arg2 + 0x48) == 0) {
                    uVar16 = 0x40;
                    uVar17 = 0x40;
                } else {
                    *(uint32_t *)arg1 = uVar17 & 0xffff03ff | 0x10000;
                    iVar4 = (**(code **)(arg2 + 0x48))(arg1);
                    if (iVar4 != 0) {
                        *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x8affffff;
                        *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) | 0xa000000;
                        *(uint32_t *)(arg1 + 4) = uVar20;
                    }
                    if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x000180191077;
                    uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
                    puVar14 = (uint8_t *)var_8h;
                    uVar17 = uVar16;
                }
                goto code_r0x00018018f1c0;
            case 0x3a:
                if (uVar15 == 10) {
                    *(undefined4 *)(arg1 + 4) = 0;
                    uVar16 = *(uint32_t *)arg1 >> 2;
                    if (((uVar16 & 1) != 0) || (uVar17 = 0, (*(int64_t *)(arg1 + 8) + 1U & 0xfffffffffffffffe) != 0)) {
                        uVar17 = 1;
                    }
                    uVar19 = 1;
                    uVar8 = *(uint32_t *)(arg1 + 0x14);
                    uVar20 = 0;
                    if (((int32_t)uVar8 < 0) &&
                       ((((char)(uVar8 >> 0x10) == '\x05' || ((uVar16 & 0x40) != 0)) || (uVar17 == 0)))) {
                        if ((*(int16_t *)(arg1 + 0x10) == 0) || (*(int16_t *)(arg1 + 0x12) == 0)) {
                            uVar7 = *(uint32_t *)arg1;
                            if ((uVar7 & 8) != 0) goto code_r0x00018019113d;
                        } else {
                            uVar7 = *(uint32_t *)arg1;
                            if ((uVar7 & 0x10) == 0) {
code_r0x00018019113d:
                                if ((((((uVar7 & 3) == 0) || (uVar8 = uVar8 & 0xffff, uVar8 - 100 < 100)) ||
                                     ((uVar8 == 0xcc ||
                                      (((uVar8 == 0x130 || ((uVar7 >> 8 & 1) != 0)) || ((uVar7 & 4) != 0)))))) ||
                                    (*(int64_t *)(arg1 + 8) != -1)) && (uVar19 = 4, (uVar7 & 3) == 0)) {
                                    uVar19 = 0x12;
                                }
                            }
                        }
                        if (*(int64_t *)(arg2 + 0x38) != 0) {
                            *(uint32_t *)arg1 = uVar7 & 0xfffe03ff | uVar19 << 10;
                            iVar4 = (**(code **)(arg2 + 0x38))(arg1);
                            if (iVar4 != 0) {
                                *(undefined4 *)(arg1 + 4) = 0;
                                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x87ffffff | 0x7000000;
                            }
                            if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
                            uVar7 = *(uint32_t *)arg1;
                            uVar19 = uVar7 >> 10;
                        }
                        *(undefined4 *)(arg1 + 4) = 0;
                        *(uint32_t *)arg1 = (uVar19 << 10 ^ uVar7) & 0x1fc00 ^ uVar7;
                        goto code_r0x0001801911e6;
                    }
                    if ((*(uint32_t *)arg1 >> 8 & 1) == 0) {
                        uVar17 = *(uint32_t *)arg1;
                        if ((uVar17 & 4) != 0) {
                            uVar20 = 0;
                            uVar16 = 0x35;
                            uVar17 = 0x35;
                            goto code_r0x00018018fcc1;
                        }
                        uVar16 = 1;
                        if (*(int64_t *)(arg1 + 8) == 0) {
                            if ((*(int16_t *)(arg1 + 0x10) == 0) || (*(int16_t *)(arg1 + 0x12) == 0)) {
                                uVar17 = uVar17 & 8;
                            } else {
                                uVar17 = uVar17 & 0x10;
                            }
                            if ((uVar17 != 0) && (uVar16 = 4, (*(uint8_t *)arg1 & 3) == 0)) {
                                uVar16 = 0x12;
                            }
                            uVar17 = uVar16;
                            if (*(int64_t *)(arg2 + 0x38) == 0) goto code_r0x00018018fcc1;
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffe03ff;
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 | uVar16 << 10;
                        } else {
                            if (*(int64_t *)(arg1 + 8) != -1) {
                                uVar20 = 0;
                                uVar16 = 0x3e;
                                uVar17 = 0x3e;
                                goto code_r0x00018018fcc1;
                            }
                            if (((((uVar17 & 3) != 0) && (uVar8 = uVar8 & 0xffff, 99 < uVar8 - 100)) && (uVar8 != 0xcc))
                               && ((uVar8 != 0x130 && ((uVar17 >> 8 & 1) == 0)))) {
                                uVar20 = 0;
                                uVar16 = 0x3f;
                                uVar17 = 0x3f;
                                goto code_r0x00018018fcc1;
                            }
                            if ((*(int16_t *)(arg1 + 0x10) == 0) || (*(int16_t *)(arg1 + 0x12) == 0)) {
                                uVar8 = *(uint32_t *)arg1;
                                if ((uVar8 & 8) != 0) goto code_r0x000180190c19;
                            } else {
                                uVar8 = *(uint32_t *)arg1;
                                if ((uVar8 & 0x10) == 0) {
code_r0x000180190c19:
                                    if ((((((uVar8 & 3) == 0) ||
                                          (uVar17 = *(uint32_t *)(arg1 + 0x14) & 0xffff, uVar17 - 100 < 100)) ||
                                         (uVar17 == 0xcc)) ||
                                        (((uVar17 == 0x130 || ((uVar8 >> 8 & 1) != 0)) ||
                                         (((uVar8 & 4) != 0 || (*(int64_t *)(arg1 + 8) != -1)))))) &&
                                       (uVar16 = 4, (uVar8 & 3) == 0)) {
                                        uVar16 = 0x12;
                                    }
                                }
                            }
                            uVar17 = uVar16;
                            if (*(int64_t *)(arg2 + 0x38) == 0) goto code_r0x00018018fcc1;
                            *(uint32_t *)arg1 = uVar8 & 0xfffe03ff | uVar16 << 10;
                        }
                    } else {
                        if ((*(int16_t *)(arg1 + 0x10) == 0) || (*(int16_t *)(arg1 + 0x12) == 0)) {
                            uVar8 = *(uint32_t *)arg1;
                            uVar16 = uVar8 & 8;
                        } else {
                            uVar8 = *(uint32_t *)arg1;
                            uVar16 = uVar8 & 0x10;
                        }
                        if (uVar16 == 0) {
                            uVar16 = 1;
                        } else {
                            uVar16 = 4;
                            if ((uVar8 & 3) == 0) {
                                uVar16 = 0x12;
                            }
                        }
                        uVar17 = uVar16;
                        if (*(int64_t *)(arg2 + 0x38) == 0) goto code_r0x00018018fcc1;
                        *(uint32_t *)arg1 = uVar16 << 10 | uVar8 & 0xfffe03ff;
                    }
                    iVar4 = (**(code **)(arg2 + 0x38))(arg1);
                    if (iVar4 != 0) {
                        *(undefined4 *)(arg1 + 4) = 0;
                        *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x87ffffff | 0x7000000;
                    }
                    if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
                    uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
                    uVar17 = uVar16;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x3b:
                uVar9 = *(uint64_t *)(arg1 + 8);
                uVar12 = (arg3 - (int64_t)puVar21) + arg4;
                uVar11 = uVar9;
                if (uVar12 <= uVar9) {
                    uVar11 = uVar12;
                }
                var_68h = (int64_t)puVar18;
                if (puVar18 == (uint8_t *)0x0) {
                    var_68h = (int64_t)puVar21;
                }
                puVar21 = puVar21 + (uVar11 - 1);
                *(uint64_t *)(arg1 + 8) = uVar9 - uVar11;
                uVar16 = uVar17;
                if (uVar9 - uVar11 == 0) {
                    uVar16 = 0x3c;
                    uVar17 = 0x3c;
                }
                goto code_r0x00018018fcc1;
            case 0x3c:
                if (uVar15 == 0xd) {
                    uVar17 = 0x3d;
                    uVar16 = 0x3d;
                    if (puVar18 != (uint8_t *)0x0) {
                        if (*(int64_t *)(arg2 + 0x30) != 0) {
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffef7ff;
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0xf400;
                            iVar4 = (**(code **)(arg2 + 0x30))(arg1, puVar18, (int64_t)puVar21 - (int64_t)puVar18);
                            if (iVar4 != 0) {
                                *(uint32_t *)(arg1 + 4) = uVar20;
                                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x86ffffff | 0x6000000;
                            }
                            if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
                            uVar17 = *(uint32_t *)arg1 >> 10 & 0x7f;
                        }
                        var_68h = 0;
                        uVar16 = uVar17;
                    }
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x3d:
                if (uVar15 != 10) break;
                uVar20 = 0;
                *(undefined4 *)(arg1 + 4) = 0;
                if (*(int64_t *)(arg2 + 0x48) != 0) {
                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffed7ff;
                    *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0xd400;
                    iVar4 = (**(code **)(arg2 + 0x48))(arg1);
                    if (iVar4 != 0) {
                        *(undefined4 *)(arg1 + 4) = 0;
                        uVar16 = *(uint32_t *)(arg1 + 0x14) & 0x8affffff | 0xa000000;
                        goto code_r0x00018018fc8f;
                    }
                    goto code_r0x00018018fc92;
                }
                uVar16 = 0x35;
                uVar17 = 0x35;
                goto code_r0x00018018fcc1;
            case 0x3e:
                uVar11 = *(uint64_t *)(arg1 + 8);
                uVar10 = (arg3 - (int64_t)puVar21) + arg4;
                uVar12 = uVar11;
                if (uVar10 <= uVar11) {
                    uVar12 = uVar10;
                }
                var_68h = (int64_t)puVar18;
                if (puVar18 == (uint8_t *)0x0) {
                    var_68h = (int64_t)puVar21;
                }
                *(uint64_t *)(arg1 + 8) = uVar11 - uVar12;
                puVar21 = puVar21 + (uVar12 - 1);
                if (uVar11 - uVar12 != 0) goto code_r0x00018018fcc1;
                uVar17 = 0x40;
                puVar14 = (uint8_t *)var_8h;
                puVar18 = (uint8_t *)var_68h;
                uVar16 = 0x40;
                if ((uint8_t *)var_68h != (uint8_t *)0x0) {
                    if (*(int64_t *)(arg2 + 0x30) != 0) {
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xffff03ff;
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0x10000;
                        iVar4 = (**(code **)(arg2 + 0x30))(arg1, var_68h, puVar21 + (1 - var_68h));
                        if (iVar4 != 0) {
                            *(uint32_t *)(arg1 + 4) = uVar20;
                            *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x86ffffff | 0x6000000;
                        }
                        if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x000180191077;
                        uVar17 = *(uint32_t *)arg1 >> 10 & 0x7f;
                    }
                    var_68h = 0;
                    puVar18 = (uint8_t *)0x0;
                    uVar16 = uVar17;
                }
                goto code_r0x00018018f1c0;
            case 0x3f:
                var_68h = (int64_t)puVar18;
                if (puVar18 == (uint8_t *)0x0) {
                    var_68h = (int64_t)puVar21;
                }
                puVar21 = (uint8_t *)(arg4 + -1 + arg3);
                goto code_r0x00018018fcc1;
            case 0x40:
                if ((*(int16_t *)(arg1 + 0x10) == 0) || (*(int16_t *)(arg1 + 0x12) == 0)) {
                    uVar17 = *(uint32_t *)arg1;
                    uVar16 = uVar17 & 8;
                } else {
                    uVar17 = *(uint32_t *)arg1;
                    uVar16 = uVar17 & 0x10;
                }
                if ((uVar16 == 0) ||
                   ((((((uVar17 & 3) != 0 && (uVar16 = *(uint32_t *)(arg1 + 0x14) & 0xffff, 99 < uVar16 - 100)) &&
                      (uVar16 != 0xcc)) && ((uVar16 != 0x130 && ((uVar17 >> 2 & 0x40) == 0)))) &&
                    (((uVar17 >> 2 & 1) == 0 && (*(int64_t *)(arg1 + 8) == -1)))))) {
                    uVar16 = 1;
                } else {
                    uVar16 = 4;
                    if ((uVar17 & 3) == 0) {
                        uVar16 = 0x12;
                    }
                }
                if (*(int64_t *)(arg2 + 0x38) != 0) {
                    *(uint32_t *)arg1 = uVar17 & 0xfffe03ff | uVar16 << 10;
                    iVar4 = (**(code **)(arg2 + 0x38))(arg1);
                    if (iVar4 != 0) {
                        *(uint32_t *)(arg1 + 4) = uVar20;
                        *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x87ffffff | 0x7000000;
                    }
                    uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
                    if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
                }
                uVar17 = uVar16;
                if (*(int32_t *)(arg1 + 0x14) < 0) {
                    *(uint32_t *)(arg1 + 4) = uVar20;
                    *(uint32_t *)arg1 = *(uint32_t *)arg1 ^ (uVar16 << 10 ^ *(uint32_t *)arg1) & 0x1fc00;
                    return puVar21 + (1 - arg3);
                }
                goto code_r0x00018018fcc1;
            }
            uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x9effffff | 0x1e000000;
            goto code_r0x000180191213;
        }
        goto code_r0x000180191002;
    }
code_r0x000180191250:
    if ((var_78h == 0) || (*(int64_t *)(arg2 + 0x18) == 0)) {
code_r0x0001801912a6:
        if ((var_8h != 0) && (*(int64_t *)(arg2 + 0x20) != 0)) {
            *(uint32_t *)arg1 = *(uint32_t *)arg1 ^ (uVar16 << 10 ^ *(uint32_t *)arg1) & 0x1fc00;
            iVar4 = (**(code **)(arg2 + 0x20))(arg1, var_8h, (int64_t)puVar21 - var_8h);
            if (iVar4 != 0) {
                *(uint32_t *)(arg1 + 4) = uVar20;
                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x84ffffff | 0x4000000;
            }
            if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x000180191077;
            uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
        }
        if ((var_60h != 0) && (*(int64_t *)(arg2 + 8) != 0)) {
            *(uint32_t *)arg1 = *(uint32_t *)arg1 ^ (uVar16 << 10 ^ *(uint32_t *)arg1) & 0x1fc00;
            iVar4 = (**(code **)(arg2 + 8))(arg1, var_60h, (int64_t)puVar21 - var_60h);
            if (iVar4 != 0) {
                *(uint32_t *)(arg1 + 4) = uVar20;
                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x82ffffff | 0x2000000;
            }
            if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x000180191077;
            uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
        }
        if ((var_68h != 0) && (*(int64_t *)(arg2 + 0x30) != 0)) {
            *(uint32_t *)arg1 = *(uint32_t *)arg1 ^ (uVar16 << 10 ^ *(uint32_t *)arg1) & 0x1fc00;
            iVar4 = (**(code **)(arg2 + 0x30))(arg1, var_68h, (int64_t)puVar21 - var_68h);
            if (iVar4 != 0) {
                *(uint32_t *)(arg1 + 4) = uVar20;
                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x86ffffff | 0x6000000;
            }
            if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x000180191077;
            uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
        }
        if ((var_58h != 0) && (*(int64_t *)(arg2 + 0x10) != 0)) {
            *(uint32_t *)arg1 = *(uint32_t *)arg1 ^ (uVar16 << 10 ^ *(uint32_t *)arg1) & 0x1fc00;
            iVar4 = (**(code **)(arg2 + 0x10))(arg1, var_58h, (int64_t)puVar21 - var_58h);
            if (iVar4 != 0) {
                *(uint32_t *)(arg1 + 4) = uVar20;
                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x88ffffff | 0x8000000;
            }
            if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x000180191077;
            uVar16 = *(uint32_t *)arg1 >> 10;
        }
        *(uint32_t *)(arg1 + 4) = uVar20;
        *(uint32_t *)arg1 = *(uint32_t *)arg1 ^ (uVar16 << 10 ^ *(uint32_t *)arg1) & 0x1fc00;
    } else {
        *(uint32_t *)arg1 = *(uint32_t *)arg1 ^ (uVar16 << 10 ^ *(uint32_t *)arg1) & 0x1fc00;
        iVar4 = (**(code **)(arg2 + 0x18))(arg1, var_78h, (int64_t)puVar21 - var_78h);
        if (iVar4 != 0) {
            *(uint32_t *)(arg1 + 4) = uVar20;
            *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x83ffffff | 0x3000000;
        }
        if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) == 0) {
            uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
            goto code_r0x0001801912a6;
        }
code_r0x000180191077:
        arg4 = (int64_t)(puVar21 + -arg3);
    }
    return (uint8_t *)arg4;
joined_r0x0001801904dd:
    if (puVar21 == (uint8_t *)(arg3 + arg4)) goto code_r0x00018019086d;
    uVar15 = *puVar21;
    if ((uVar15 == 0x20) || (cVar2 = *(char *)((uint64_t)uVar15 + 0x1804a8a50), cVar2 == '\0'))
    goto code_r0x00018019086d;
    uVar8 = *(uint32_t *)arg1;
    // switch table (15 cases) at 0x180191618
    switch(uVar8 >> 0x11 & 0x7f) {
    case 0:
        puVar14 = puVar21 + 1;
        uVar11 = (arg3 - (int64_t)puVar21) + arg4;
        uVar9 = (uint64_t)*(uint32_t *)0x18069c350;
        if (uVar11 < *(uint32_t *)0x18069c350) {
            uVar9 = uVar11;
        }
        while (puVar14 < (uint8_t *)(uVar9 + arg3)) {
            if ((puVar21[1] == 0x20) || (*(char *)((uint64_t)puVar21[1] + 0x1804a8a50) == '\0')) break;
            puVar14 = puVar21 + 2;
            puVar21 = puVar21 + 1;
        }
        break;
    case 1:
        uVar19 = 0;
        if (cVar2 == 'o') {
            uVar19 = 0x40000;
        }
        *(uint32_t *)arg1 = ((uVar8 + 0x1000000 ^ uVar8) & 0x7f000000 ^ uVar8) & 0xff01ffff | uVar19;
        break;
    case 2:
        uVar19 = 0;
        if (cVar2 == 'n') {
            uVar19 = 0x60000;
        }
        *(uint32_t *)arg1 = ((uVar8 + 0x1000000 ^ uVar8) & 0x7f000000 ^ uVar8) & 0xff01ffff | uVar19;
        break;
    case 3:
        uVar8 = (uVar8 + 0x1000000 ^ uVar8) & 0x7f000000 ^ uVar8;
        if (cVar2 == 'n') {
            *(uint32_t *)arg1 = uVar8 & 0xff09ffff | 0x80000;
        } else if (cVar2 == 't') {
            *(uint32_t *)arg1 = uVar8 & 0xff0dffff | 0xc0000;
        } else {
            *(uint32_t *)arg1 = uVar8 & 0xff01ffff;
        }
        break;
    case 4:
        uVar19 = (uVar8 ^ uVar8 + 0x1000000) & 0x7f000000 ^ uVar8;
        uVar8 = (uVar8 + 0x1000000 & 0x7f000000) >> 0x18;
        *(uint32_t *)arg1 = uVar19;
        if ((uVar8 < 0xb) && (cVar2 == *(char *)((uint64_t)(uVar19 >> 0x18 & 0x7f) + 0x1804a62f8))) {
            if (uVar8 == 9) {
                *(uint32_t *)arg1 = uVar19 & 0xff13ffff | 0x120000;
            }
        } else {
code_r0x000180190698:
            *(uint32_t *)arg1 = uVar19 & 0xff01ffff;
        }
        break;
    case 5:
        uVar19 = (uVar8 ^ uVar8 + 0x1000000) & 0x7f000000 ^ uVar8;
        uVar8 = (uVar8 + 0x1000000 & 0x7f000000) >> 0x18;
        *(uint32_t *)arg1 = uVar19;
        if ((0x10 < uVar8) || (cVar2 != *(char *)((uint64_t)(uVar19 >> 0x18 & 0x7f) + 0x1804a9380)))
        goto code_r0x000180190698;
        if (uVar8 == 0xf) {
            *(uint32_t *)arg1 = uVar19 & 0xff13ffff | 0x120000;
        }
        break;
    case 6:
        uVar19 = (uVar8 ^ uVar8 + 0x1000000) & 0x7f000000 ^ uVar8;
        uVar8 = (uVar8 + 0x1000000 & 0x7f000000) >> 0x18;
        *(uint32_t *)arg1 = uVar19;
        if ((0xe < uVar8) || (cVar2 != *(char *)((uint64_t)(uVar19 >> 0x18 & 0x7f) + 0x1804a8960)))
        goto code_r0x000180190698;
        if (uVar8 == 0xd) {
            *(uint32_t *)arg1 = uVar19 & 0xff15ffff | 0x140000;
        }
        break;
    case 7:
        uVar19 = (uVar8 ^ uVar8 + 0x1000000) & 0x7f000000 ^ uVar8;
        uVar8 = (uVar8 + 0x1000000 & 0x7f000000) >> 0x18;
        *(uint32_t *)arg1 = uVar19;
        if ((0x11 < uVar8) || (cVar2 != *(char *)((uint64_t)(uVar19 >> 0x18 & 0x7f) + 0x1804a9398)))
        goto code_r0x000180190698;
        if (uVar8 == 0x10) {
            *(uint32_t *)arg1 = uVar19 & 0xff1bfffb | 0x1a0000;
        }
        break;
    case 8:
        uVar19 = (uVar8 ^ uVar8 + 0x1000000) & 0x7f000000 ^ uVar8;
        uVar8 = (uVar8 + 0x1000000 & 0x7f000000) >> 0x18;
        *(uint32_t *)arg1 = uVar19;
        if ((7 < uVar8) || (cVar2 != *(char *)((uint64_t)(uVar19 >> 0x18 & 0x7f) + 0x1804a6318)))
        goto code_r0x000180190698;
        if (uVar8 == 6) {
            *(uint32_t *)arg1 = uVar19 & 0xff1dffff | 0x1c0000;
        }
        break;
    case 9:
    case 10:
    case 0xd:
    case 0xe:
        *(uint32_t *)arg1 = uVar8 & 0xff01ffff;
    }
    puVar21 = puVar21 + 1;
    goto joined_r0x0001801904dd;
code_r0x00018018f20f:
    uVar17 = 0x10;
    uVar16 = 0x10;
    if (var_58h == 0) {
        var_58h = (int64_t)puVar21;
    }
    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0x80ffffff;
    if ((uVar15 == 0xd) || (uVar15 == 10)) goto code_r0x00018018f1c0;
    goto code_r0x00018018fcc1;
code_r0x00018019086d:
    if (puVar21 == (uint8_t *)(arg3 + arg4)) {
        puVar21 = puVar21 + -1;
        uVar20 = uVar20 + ((int32_t)puVar21 - iVar4);
        if (uVar20 <= *(uint32_t *)0x18069c350) {
code_r0x00018018fcc1:
            puVar21 = puVar21 + 1;
            if (puVar21 == puVar1) goto code_r0x000180191250;
            goto code_r0x00018018f196;
        }
    } else {
        uVar20 = uVar20 + ((int32_t)puVar21 - iVar4);
        if (uVar20 <= *(uint32_t *)0x18069c350) {
            if (uVar15 == 0x3a) {
                uVar17 = 0x2e;
                uVar16 = 0x2e;
                if (var_78h != 0) {
                    if (*(int64_t *)(arg2 + 0x18) != 0) {
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffebbff;
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0xb800;
                        iVar4 = (**(code **)(arg2 + 0x18))(arg1, var_78h, (int64_t)puVar21 - var_78h);
                        if (iVar4 != 0) {
                            *(uint32_t *)(arg1 + 4) = uVar20;
                            *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x83ffffff | 0x3000000;
                        }
                        if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) {
code_r0x0001801911e6:
                            return puVar21 + (1 - arg3);
                        }
                        uVar17 = *(uint32_t *)arg1 >> 10 & 0x7f;
                    }
                    var_78h = 0;
                    uVar16 = uVar17;
                }
                goto code_r0x00018018fcc1;
            }
code_r0x000180191014:
            uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x98ffffff | 0x18000000;
            goto code_r0x000180191213;
        }
    }
code_r0x000180191002:
    uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x8cffffff | 0xc000000;
code_r0x000180191213:
    *(uint32_t *)(arg1 + 4) = uVar20;
    *(uint32_t *)(arg1 + 0x14) = uVar7;
    if ((uVar7 & 0x7f000000) == 0) {
        *(uint32_t *)(arg1 + 0x14) = uVar7 & 0xa0ffffff | 0x20000000;
    }
    *(uint32_t *)(arg1 + 4) = uVar20;
    *(uint32_t *)arg1 = *(uint32_t *)arg1 ^ (uVar16 << 10 ^ *(uint32_t *)arg1) & 0x1fc00;
code_r0x000180191091:
    return puVar21 + -arg3;
}

// ============================================================
// Function: FUN_1801910af
// Address: 0x1801910af
// Size: 1477 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

uint8_t * fcn.18018f030(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    uint8_t *puVar1;
    char cVar2;
    int64_t iVar3;
    int32_t iVar4;
    uint32_t uVar5;
    int32_t iVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    uint8_t uVar13;
    uint8_t *puVar14;
    uint8_t uVar15;
    uint32_t uVar16;
    uint32_t uVar17;
    uint8_t *puVar18;
    uint32_t uVar19;
    uint32_t uVar20;
    uint8_t *puVar21;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    
    if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) {
        return (uint8_t *)0x0;
    }
    uVar7 = *(uint32_t *)arg1;
    uVar20 = *(uint32_t *)(arg1 + 4);
    uVar16 = uVar7 >> 10 & 0x7f;
    if (arg4 == 0) {
        if (uVar16 == 1) {
            return (uint8_t *)0x0;
        }
        if (uVar16 == 2) {
            return (uint8_t *)0x0;
        }
        if (uVar16 == 4) {
            return (uint8_t *)0x0;
        }
        if (uVar16 != 0x12) {
            if (uVar16 != 0x3f) {
                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x8bffffff | 0xb000000;
                return (uint8_t *)0x1;
            }
            if (*(int64_t *)(arg2 + 0x38) != 0) {
                *(uint32_t *)arg1 = (uVar7 & 0xfffffc00 ^ uVar7) & 0x1fc00 ^ uVar7;
                iVar4 = (**(code **)(arg2 + 0x38))();
                if (iVar4 != 0) {
                    *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x87ffffff;
                    *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) | 0x7000000;
                    *(uint32_t *)(arg1 + 4) = uVar20;
                    return (uint8_t *)0x0;
                }
                return (uint8_t *)0x0;
            }
            return (uint8_t *)0x0;
        }
        return (uint8_t *)0x0;
    }
    var_58h = 0;
    var_60h = 0;
    var_68h = 0;
    var_78h = arg3;
    if (uVar16 != 0x2d) {
        var_78h = 0;
    }
    var_8h = arg3;
    if (uVar16 != 0x32) {
        var_8h = 0;
    }
    // switch table (16 cases) at 0x180191420
    switch(uVar16) {
    case 0x10:
        var_58h = arg3;
        break;
    case 0x15:
    case 0x16:
    case 0x17:
    case 0x18:
    case 0x19:
    case 0x1a:
    case 0x1b:
    case 0x1c:
    case 0x1d:
    case 0x1e:
    case 0x1f:
        var_60h = arg3;
    }
    puVar1 = (uint8_t *)(arg3 + arg4);
    puVar21 = (uint8_t *)arg3;
    uVar17 = uVar16;
    if ((uint8_t *)arg3 != puVar1) {
code_r0x00018018f196:
        if ((0x3a < (int32_t)uVar16) || (uVar20 = uVar20 + 1, uVar20 <= *(uint32_t *)0x18069c350)) {
            uVar9 = (uint64_t)*puVar21;
            puVar14 = (uint8_t *)var_8h;
            puVar18 = (uint8_t *)var_68h;
code_r0x00018018f1c0:
            uVar15 = (uint8_t)uVar9;
            if (0x3f < uVar16 - 1) {
                uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x9dffffff | 0x1d000000;
                goto code_r0x000180191213;
            }
            iVar4 = (int32_t)puVar21;
    // switch table (64 cases) at 0x180191460
            switch(uVar16) {
            case 1:
                if ((uVar15 != 0xd) && (uVar15 != 10)) {
                    uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x8dffffff | 0xd000000;
                    goto code_r0x000180191213;
                }
                goto code_r0x00018018fcc1;
            case 2:
                if ((uVar15 != 0xd) && (uVar15 != 10)) {
                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffffc03;
                    *(undefined8 *)(arg1 + 8) = 0xffffffffffffffff;
                    if (uVar15 != 0x48) {
                        uVar16 = 0x12;
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffffffc;
                        goto code_r0x00018018ff9a;
                    }
                    if (*(int64_t *)arg2 != 0) {
                        uVar16 = *(uint32_t *)arg1 & 0xfffe0fff | 0xc00;
code_r0x00018018fc73:
                        *(uint32_t *)arg1 = uVar16;
                        goto code_r0x00018018fc75;
                    }
                    uVar16 = 3;
                    uVar17 = 3;
                }
                goto code_r0x00018018fcc1;
            case 3:
                if (uVar15 == 0x54) {
                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffffffd | 1;
                    uVar16 = 6;
                    uVar17 = 6;
                } else {
                    if (uVar15 != 0x45) goto code_r0x0001801910c1;
                    *(undefined *)(arg1 + 0x16) = 2;
                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0x82fffffc | 0x2000000;
                    uVar16 = 0x13;
                    uVar17 = 0x13;
                }
                goto code_r0x00018018fcc1;
            case 4:
                if ((uVar15 != 0xd) && (uVar15 != 10)) {
                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffffc03;
                    *(undefined8 *)(arg1 + 8) = 0xffffffffffffffff;
                    if (uVar15 != 0x48) goto code_r0x0001801910c1;
                    if (*(int64_t *)arg2 != 0) {
                        uVar16 = *(uint32_t *)arg1 & 0xfffe17ff | 0x1400;
                        goto code_r0x00018018fc73;
                    }
                    uVar16 = 5;
                    uVar17 = 5;
                }
                goto code_r0x00018018fcc1;
            case 5:
                if (uVar15 == 0x54) {
                    uVar16 = 6;
                    uVar17 = 6;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 6:
                if (uVar15 == 0x54) {
                    uVar16 = 7;
                    uVar17 = 7;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 7:
                if (uVar15 == 0x50) {
                    uVar16 = 8;
                    uVar17 = 8;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 8:
                if (uVar15 == 0x2f) {
                    uVar16 = 9;
                    uVar17 = 9;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 9:
                if (9 < (uint8_t)(uVar15 - 0x30)) goto code_r0x0001801910d3;
                *(int16_t *)(arg1 + 0x10) = (char)uVar15 + -0x30;
                uVar16 = 10;
                uVar17 = 10;
                goto code_r0x00018018fcc1;
            case 10:
                if (uVar15 != 0x2e) goto code_r0x0001801910d3;
                uVar16 = 0xb;
                uVar17 = 0xb;
                goto code_r0x00018018fcc1;
            case 0xb:
                if (9 < (uint8_t)(uVar15 - 0x30)) goto code_r0x0001801910d3;
                *(int16_t *)(arg1 + 0x12) = (char)uVar15 + -0x30;
                uVar16 = 0xc;
                uVar17 = 0xc;
                goto code_r0x00018018fcc1;
            case 0xc:
                if (uVar15 != 0x20) goto code_r0x0001801910d3;
                uVar16 = 0xd;
                uVar17 = 0xd;
                goto code_r0x00018018fcc1;
            case 0xd:
                if ((uint8_t)(uVar15 - 0x30) < 10) {
                    *(int16_t *)(arg1 + 0x14) = (char)uVar15 + -0x30;
                    uVar16 = 0xe;
                    uVar17 = 0xe;
                } else if (uVar15 != 0x20) {
code_r0x00018018fe6d:
                    uVar8 = *(uint32_t *)(arg1 + 0x14);
                    goto code_r0x00018018fe70;
                }
                goto code_r0x00018018fcc1;
            case 0xe:
                if ((uint8_t)(uVar15 - 0x30) < 10) {
                    *(int16_t *)(arg1 + 0x14) = *(int16_t *)(arg1 + 0x14) * 10 + -0x30 + (int16_t)(char)uVar15;
                    uVar8 = *(uint32_t *)(arg1 + 0x14);
                    if (999 < (uint16_t)uVar8) {
code_r0x00018018fe70:
                        uVar7 = uVar8 & 0x8fffffff | 0xf000000;
                        goto code_r0x000180191213;
                    }
                    goto code_r0x00018018fcc1;
                }
                if ((uVar15 != 10) && (uVar15 != 0xd)) {
                    if (uVar15 != 0x20) goto code_r0x00018018fe6d;
                    uVar16 = 0xf;
                    uVar17 = 0xf;
                    goto code_r0x00018018fcc1;
                }
                uVar16 = 0xf;
                uVar17 = 0xf;
                goto code_r0x00018018f1c0;
            case 0xf:
                goto code_r0x00018018f20f;
            case 0x10:
                if (uVar15 == 0xd) {
                    uVar17 = 0x11;
                    uVar16 = 0x11;
                    if (var_58h != 0) {
                        if (*(int64_t *)(arg2 + 0x10) != 0) {
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffe47ff;
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0x4400;
                            iVar4 = (**(code **)(arg2 + 0x10))(arg1, var_58h, (int64_t)puVar21 - var_58h);
                            if (iVar4 != 0) {
                                *(uint32_t *)(arg1 + 4) = uVar20;
                                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x88ffffff | 0x8000000;
                            }
                            if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
                            uVar17 = *(uint32_t *)arg1 >> 10 & 0x7f;
                        }
                        var_58h = 0;
                        uVar16 = uVar17;
                    }
                } else if (uVar15 == 10) {
                    uVar17 = 0x2c;
                    uVar16 = 0x2c;
                    if (var_58h != 0) {
                        if (*(int64_t *)(arg2 + 0x10) != 0) {
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffeb3ff;
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0xb000;
                            iVar4 = (**(code **)(arg2 + 0x10))(arg1, var_58h, (int64_t)puVar21 - var_58h);
                            if (iVar4 != 0) {
                                *(uint32_t *)(arg1 + 4) = uVar20;
                                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x88ffffff | 0x8000000;
                            }
                            if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
                            uVar17 = *(uint32_t *)arg1 >> 10 & 0x7f;
                        }
                        var_58h = 0;
                        uVar16 = uVar17;
                    }
                }
                goto code_r0x00018018fcc1;
            case 0x11:
                if (uVar15 == 10) {
                    uVar16 = 0x2c;
                    uVar17 = 0x2c;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x12:
                if ((uVar15 != 0xd) && (uVar15 != 10)) {
code_r0x00018018ff9a:
                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffffc03;
                    uVar17 = *(uint32_t *)arg1;
                    *(undefined8 *)(arg1 + 8) = 0xffffffffffffffff;
                    if (0x19 < (uint8_t)((uVar15 | 0x20) + 0x9f)) goto code_r0x0001801910e5;
                    *(undefined *)(arg1 + 0x16) = 0;
                    *(uint32_t *)arg1 = uVar17 & 0x81ffffff | 0x1000000;
    // switch table (21 cases) at 0x1801915c4
                    switch(uVar15) {
                    case 0x41:
                        *(undefined *)(arg1 + 0x16) = 0x13;
                        break;
                    case 0x42:
                        *(undefined *)(arg1 + 0x16) = 0x10;
                        break;
                    case 0x43:
                        *(undefined *)(arg1 + 0x16) = 5;
                        break;
                    case 0x44:
                        break;
                    default:
                        goto code_r0x0001801910e5;
                    case 0x47:
                        *(undefined *)(arg1 + 0x16) = 1;
                        break;
                    case 0x48:
                        *(undefined *)(arg1 + 0x16) = 2;
                        break;
                    case 0x4c:
                        *(undefined *)(arg1 + 0x16) = 9;
                        break;
                    case 0x4d:
                        *(undefined *)(arg1 + 0x16) = 10;
                        break;
                    case 0x4e:
                        *(undefined *)(arg1 + 0x16) = 0x19;
                        break;
                    case 0x4f:
                        *(undefined *)(arg1 + 0x16) = 6;
                        break;
                    case 0x50:
                        *(undefined *)(arg1 + 0x16) = 3;
                        break;
                    case 0x52:
                        *(undefined *)(arg1 + 0x16) = 0x14;
                        break;
                    case 0x53:
                        *(undefined *)(arg1 + 0x16) = 0x1a;
                        break;
                    case 0x54:
                        *(undefined *)(arg1 + 0x16) = 7;
                        break;
                    case 0x55:
                        *(undefined *)(arg1 + 0x16) = 0xf;
                    }
                    if (*(int64_t *)arg2 == 0) {
                        uVar16 = 0x13;
                        uVar17 = 0x13;
                    } else {
                        *(uint32_t *)arg1 = uVar17 & 0x81fe4fff | 0x1004c00;
code_r0x00018018fc75:
                        iVar4 = (**(code **)arg2)(arg1);
                        if (iVar4 != 0) {
                            *(uint32_t *)(arg1 + 4) = uVar20;
                            uVar16 = *(uint32_t *)(arg1 + 0x14) & 0x81ffffff | 0x1000000;
code_r0x00018018fc8f:
                            *(uint32_t *)(arg1 + 0x14) = uVar16;
                        }
code_r0x00018018fc92:
                        if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
code_r0x00018018fc9f:
                        uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
                        uVar17 = uVar16;
                    }
                }
                goto code_r0x00018018fcc1;
            case 0x13:
                if (uVar15 == 0) {
code_r0x0001801910e5:
                    uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x90ffffff | 0x10000000;
                    goto code_r0x000180191213;
                }
                iVar3 = *(int64_t *)((uint64_t)*(uint8_t *)(arg1 + 0x16) * 8 + 0x18069c360);
                if ((uVar15 == 0x20) && (*(char *)((uint64_t)(*(uint8_t *)(arg1 + 3) & 0x7f) + iVar3) == '\0')) {
                    uVar17 = 0x14;
                    uVar16 = 0x14;
                } else if (uVar15 != *(uint8_t *)((uint64_t)(*(uint32_t *)arg1 >> 0x18 & 0x7f) + iVar3)) {
                    if ((0x19 < (uint8_t)(uVar15 + 0xbf)) && (uVar15 != 0x2d)) {
code_r0x0001801910f6:
                        uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x90ffffff | 0x10000000;
                        goto code_r0x000180191213;
                    }
                    uVar8 = (uint32_t)*(uint8_t *)(arg1 + 0x16) << 0x10 | *(uint32_t *)arg1 >> 0x10 & 0x7f00 |
                            (int32_t)(char)uVar15;
                    if (uVar8 < 0xa0150) {
                        if (uVar8 == 0xa014f) {
                            *(undefined *)(arg1 + 0x16) = 0xb;
                        } else if (uVar8 < 0x50149) {
                            if (uVar8 == 0x50148) {
                                *(undefined *)(arg1 + 0x16) = 0x16;
                            } else if (uVar8 == 0x30141) {
                                *(undefined *)(arg1 + 0x16) = 0x1c;
                            } else if (uVar8 == 0x30152) {
                                *(undefined *)(arg1 + 0x16) = 0xc;
                            } else if (uVar8 == 0x30155) {
                                *(undefined *)(arg1 + 0x16) = 4;
                            } else {
                                if (uVar8 != 0x40252) goto code_r0x0001801910f6;
                                *(undefined *)(arg1 + 0x16) = 0x1d;
                            }
                        } else if (uVar8 == 0x50250) {
                            *(undefined *)(arg1 + 0x16) = 8;
                        } else if (uVar8 == 0x90149) {
                            *(undefined *)(arg1 + 0x16) = 0x1f;
                        } else if (uVar8 == 0xa012d) {
                            *(undefined *)(arg1 + 0x16) = 0x18;
                        } else {
                            if (uVar8 != 0xa0145) goto code_r0x0001801910f6;
                            *(undefined *)(arg1 + 0x16) = 0x17;
                        }
                    } else if (uVar8 < 0xf0254) {
                        if (uVar8 == 0xf0253) {
                            *(undefined *)(arg1 + 0x16) = 0x1b;
                        } else if (uVar8 == 0xa0241) {
                            *(undefined *)(arg1 + 0x16) = 0x15;
                        } else if (uVar8 == 0xa0341) {
                            *(undefined *)(arg1 + 0x16) = 0x1e;
                        } else if (uVar8 == 0xc0450) {
                            *(undefined *)(arg1 + 0x16) = 0xd;
                        } else {
                            if (uVar8 != 0xf0242) goto code_r0x0001801910f6;
                            *(undefined *)(arg1 + 0x16) = 0x12;
                        }
                    } else if (uVar8 == 0xf0349) {
                        *(undefined *)(arg1 + 0x16) = 0x20;
                    } else if (uVar8 == 0x140242) {
                        *(undefined *)(arg1 + 0x16) = 0x11;
                    } else if (uVar8 == 0x1a0145) {
                        *(undefined *)(arg1 + 0x16) = 0xe;
                    } else {
                        if (uVar8 != 0x1a014f) goto code_r0x0001801910f6;
                        *(undefined *)(arg1 + 0x16) = 0x21;
                    }
                }
                uVar8 = *(uint32_t *)arg1;
                *(uint32_t *)arg1 = (uVar8 + 0x1000000 ^ uVar8) & 0x7f000000 ^ uVar8;
                goto code_r0x00018018fcc1;
            case 0x14:
                if (uVar15 != 0x20) {
                    if (var_60h == 0) {
                        var_60h = (int64_t)puVar21;
                    }
                    if (*(char *)(arg1 + 0x16) == '\x05') {
                        uVar16 = 0x18;
                    }
                    goto code_r0x000180190245;
                }
                goto code_r0x00018018fcc1;
            case 0x15:
            case 0x16:
            case 0x17:
            case 0x18:
                if ((uVar15 < 0x21) && ((0x100002400U >> (uVar9 & 0x3f) & 1) != 0)) {
                    uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x91ffffff | 0x11000000;
                    goto code_r0x000180191213;
                }
code_r0x000180190245:
                uVar16 = fcn.1801916d0(uVar16, uVar9 & 0xff);
                uVar17 = uVar16;
                if (uVar16 == 1) {
                    uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x91ffffff | 0x11000000;
                    goto code_r0x000180191213;
                }
                goto code_r0x00018018fcc1;
            default:
                if ((uVar15 == 10) || (uVar15 == 0xd)) {
                    *(undefined4 *)(arg1 + 0x10) = 0x90000;
                    uVar17 = (uVar15 != 0xd) + 0x2b;
                    uVar16 = uVar17;
                    if (var_60h != 0) {
                        if (*(int64_t *)(arg2 + 8) == 0) goto code_r0x000180190316;
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffe03ff;
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 | uVar17 * 0x400;
                        iVar4 = (**(code **)(arg2 + 8))(arg1, var_60h, (int64_t)puVar21 - var_60h);
                        if (iVar4 != 0) {
                            *(uint32_t *)(arg1 + 4) = uVar20;
                            *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x82ffffff | 0x2000000;
                        }
                        if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) == 0) {
                            var_60h = 0;
                            goto code_r0x00018018fc9f;
                        }
                        goto code_r0x0001801911e6;
                    }
                } else {
                    if (uVar15 != 0x20) goto code_r0x000180190245;
                    uVar17 = 0x20;
                    uVar16 = 0x20;
                    if (var_60h != 0) {
                        if (*(int64_t *)(arg2 + 8) != 0) {
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffe83ff;
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0x8000;
                            iVar4 = (**(code **)(arg2 + 8))(arg1, var_60h, (int64_t)puVar21 - var_60h);
                            if (iVar4 != 0) {
                                *(uint32_t *)(arg1 + 4) = uVar20;
                                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x82ffffff | 0x2000000;
                            }
                            if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
                            uVar17 = *(uint32_t *)arg1 >> 10 & 0x7f;
                        }
code_r0x000180190316:
                        var_60h = 0;
                        uVar16 = uVar17;
                    }
                }
                goto code_r0x00018018fcc1;
            case 0x20:
                if (uVar15 != 0x20) {
                    if (uVar15 == 0x48) {
                        uVar16 = 0x21;
                        uVar17 = 0x21;
                    } else {
                        if ((uVar15 != 0x49) || (*(char *)(arg1 + 0x16) != '!')) {
code_r0x0001801910c1:
                            uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x9cffffff | 0x1c000000;
                            goto code_r0x000180191213;
                        }
                        uVar16 = 0x25;
                        uVar17 = 0x25;
                    }
                }
                goto code_r0x00018018fcc1;
            case 0x21:
                if (uVar15 == 0x54) {
                    uVar16 = 0x22;
                    uVar17 = 0x22;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x22:
                if (uVar15 == 0x54) {
                    uVar16 = 0x23;
                    uVar17 = 0x23;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x23:
                if (uVar15 == 0x50) {
                    uVar16 = 0x24;
                    uVar17 = 0x24;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x24:
                if (uVar15 == 0x2f) {
                    uVar16 = 0x27;
                    uVar17 = 0x27;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x25:
                if (uVar15 == 0x43) {
                    uVar16 = 0x26;
                    uVar17 = 0x26;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x26:
                if (uVar15 == 0x45) {
                    uVar16 = 0x24;
                    uVar17 = 0x24;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x27:
                if (9 < (uint8_t)(uVar15 - 0x30)) goto code_r0x0001801910d3;
                *(int16_t *)(arg1 + 0x10) = (char)uVar15 + -0x30;
                uVar16 = 0x28;
                uVar17 = 0x28;
                goto code_r0x00018018fcc1;
            case 0x28:
                if (uVar15 != 0x2e) goto code_r0x0001801910d3;
                uVar16 = 0x29;
                uVar17 = 0x29;
                goto code_r0x00018018fcc1;
            case 0x29:
                if (9 < (uint8_t)(uVar15 - 0x30)) goto code_r0x0001801910d3;
                *(int16_t *)(arg1 + 0x12) = (char)uVar15 + -0x30;
                uVar16 = 0x2a;
                uVar17 = 0x2a;
                goto code_r0x00018018fcc1;
            case 0x2a:
                if (uVar15 == 0xd) {
                    uVar16 = 0x2b;
                    uVar17 = 0x2b;
                } else {
                    if (uVar15 != 10) {
code_r0x0001801910d3:
                        uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x8effffff | 0xe000000;
                        goto code_r0x000180191213;
                    }
                    uVar16 = 0x2c;
                    uVar17 = 0x2c;
                }
                goto code_r0x00018018fcc1;
            case 0x2b:
                if (uVar15 != 10) goto code_r0x00018019110f;
                uVar16 = 0x2c;
                uVar17 = 0x2c;
                goto code_r0x00018018fcc1;
            case 0x2c:
                if (uVar15 == 0xd) {
                    uVar16 = 0x39;
                    uVar17 = 0x39;
                    goto code_r0x00018018fcc1;
                }
                if (uVar15 != 10) {
                    if ((uVar15 == 0x20) || (cVar2 = *(char *)((uVar9 & 0xff) + 0x1804a8a50), cVar2 == '\0'))
                    goto code_r0x000180191014;
                    uVar17 = 0x2d;
                    uVar16 = 0x2d;
                    uVar8 = *(uint32_t *)arg1;
                    if (var_78h == 0) {
                        var_78h = (int64_t)puVar21;
                    }
                    if (cVar2 == 'c') {
                        *(uint32_t *)arg1 = uVar8 & 0x8003ffff | 0x20000;
                    } else if (cVar2 == 'p') {
                        *(uint32_t *)arg1 = uVar8 & 0x800bffff | 0xa0000;
                    } else if (cVar2 == 't') {
                        *(uint32_t *)arg1 = uVar8 & 0x800fffff | 0xe0000;
                    } else if (cVar2 == 'u') {
                        *(uint32_t *)arg1 = uVar8 & 0x8011ffff | 0x100000;
                    } else {
                        *(uint32_t *)arg1 = uVar8 & 0x8001ffff;
                    }
                    goto code_r0x00018018fcc1;
                }
                uVar16 = 0x39;
                uVar17 = 0x39;
                goto code_r0x00018018f1c0;
            case 0x2d:
                goto joined_r0x0001801904dd;
            case 0x2e:
                if ((uVar15 != 0x20) && (uVar15 != 9)) {
                    if (uVar15 == 0xd) {
                        uVar16 = 0x2f;
                        uVar17 = 0x2f;
                    } else {
                        if (uVar15 != 10) goto code_r0x000180190971;
                        uVar16 = 0x30;
                        uVar17 = 0x30;
                    }
                }
                goto code_r0x00018018fcc1;
            case 0x2f:
                if (uVar15 == 10) {
                    uVar16 = 0x30;
                    uVar17 = 0x30;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x30:
                if ((uVar15 == 0x20) || (uVar15 == 9)) {
                    uVar16 = 0x2e;
                    uVar17 = 0x2e;
                    goto code_r0x00018018fcc1;
                }
                uVar8 = *(uint32_t *)arg1;
                uVar17 = uVar8 >> 0x11 & 0x7f;
                if (uVar17 == 10) goto code_r0x000180191033;
                if (uVar17 == 0x15) {
                    uVar8 = uVar8 | 4;
code_r0x00018018f7a7:
                    *(uint32_t *)arg1 = uVar8;
                } else {
                    if (uVar17 == 0x16) {
                        uVar8 = uVar8 | 8;
                        goto code_r0x00018018f7a7;
                    }
                    if (uVar17 == 0x17) {
                        uVar8 = uVar8 | 0x10;
                        goto code_r0x00018018f7a7;
                    }
                    if (uVar17 == 0x18) {
                        uVar8 = uVar8 | 0x20;
                        goto code_r0x00018018f7a7;
                    }
                }
                uVar17 = 0x2c;
                var_8h = (int64_t)puVar14;
                if (puVar14 == (uint8_t *)0x0) {
                    var_8h = (int64_t)puVar21;
                }
                puVar14 = (uint8_t *)var_8h;
                uVar16 = 0x2c;
                if ((uint8_t *)var_8h != (uint8_t *)0x0) {
                    if (*(int64_t *)(arg2 + 0x20) != 0) {
                        *(uint32_t *)arg1 = uVar8 & 0xfffeb3ff | 0xb000;
                        iVar4 = (**(code **)(arg2 + 0x20))(arg1, var_8h, (int64_t)puVar21 - var_8h);
                        if (iVar4 != 0) {
                            *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x84ffffff;
                            *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) | 0x4000000;
                            *(uint32_t *)(arg1 + 4) = uVar20;
                        }
                        if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x000180191077;
                        uVar17 = *(uint32_t *)arg1 >> 10 & 0x7f;
                    }
                    var_8h = 0;
                    puVar14 = (uint8_t *)0x0;
                    uVar16 = uVar17;
                }
                goto code_r0x00018018f1c0;
            case 0x31:
code_r0x000180190971:
                uVar17 = 0x32;
                uVar16 = 0x32;
                var_8h = (int64_t)puVar14;
                if (puVar14 == (uint8_t *)0x0) {
                    var_8h = (int64_t)puVar21;
                }
                *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0x80ffffff;
                uVar8 = *(uint32_t *)arg1;
                uVar13 = uVar15 | 0x20;
    // switch table (8 cases) at 0x180191654
                switch(uVar8 >> 0x11 & 0x7f) {
                case 9:
                    if (uVar13 == 0x6b) {
                        *(uint32_t *)arg1 = uVar8 & 0xff23ffff | 0x220000;
                    } else if (uVar13 == 99) {
                        *(uint32_t *)arg1 = uVar8 & 0xff25ffff | 0x240000;
                    } else if (uVar13 == 0x75) {
                        *(uint32_t *)arg1 = uVar8 & 0xff27ffff | 0x260000;
                    } else {
                        *(uint32_t *)arg1 = uVar8 & 0xff29ffff | 0x280000;
                    }
                    break;
                case 10:
                    if (9 < (uint8_t)(uVar15 - 0x30)) {
code_r0x000180191033:
                        uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x99ffffff | 0x19000000;
                        goto code_r0x000180191213;
                    }
                    if ((uVar8 >> 9 & 1) != 0) {
code_r0x000180191045:
                        uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x9affffff | 0x1a000000;
                        goto code_r0x000180191213;
                    }
                    *(int64_t *)(arg1 + 8) = (int64_t)((char)uVar15 + -0x30);
                    *(uint32_t *)arg1 = uVar8 & 0xff17ffff | 0x160200;
                    break;
                case 0xc:
                case 0x10:
                    break;
                case 0xd:
                    if (uVar13 == 99) {
                        *(uint32_t *)arg1 = uVar8 & 0xff1fffff | 0x1e0000;
                        break;
                    }
                default:
                    *(uint32_t *)arg1 = uVar8 & 0xff01ffff;
                    break;
                case 0xe:
                    *(uint32_t *)arg1 = uVar8 & 0xff01ffff | 0x80;
                }
                goto code_r0x00018018fcc1;
            case 0x32:
                uVar8 = *(uint32_t *)arg1 >> 0x11 & 0x7f;
code_r0x00018018f261:
                if (puVar21 != puVar1) {
                    uVar15 = *puVar21;
                    uVar9 = (uint64_t)(uint32_t)(int32_t)(char)uVar15;
                    if (uVar15 != 0xd) {
                        if (uVar15 != 10) {
                            if (((-1 < (int32_t)uVar7) && (uVar15 != 9)) && ((uVar15 < 0x20 || (uVar15 == 0x7f))))
                            goto code_r0x000180191014;
                            uVar13 = uVar15 | 0x20;
    // switch table (25 cases) at 0x180191560
                            switch(uVar8) {
                            case 0:
                                uVar9 = (arg3 - (int64_t)puVar21) + arg4;
                                if ((int64_t)(uint64_t)*(uint32_t *)0x18069c350 <= (int64_t)uVar9) {
                                    uVar9 = (uint64_t)*(uint32_t *)0x18069c350;
                                }
                                puVar14 = puVar21 + uVar9;
                                for (; puVar21 != puVar14; puVar21 = puVar21 + 1) {
                                    uVar15 = *puVar21;
                                    if ((uVar15 == 0xd) || (uVar15 == 10)) {
                                        puVar21 = puVar21 + -1;
                                        break;
                                    }
                                    if (((-1 < (int32_t)uVar7) && (uVar15 != 9)) &&
                                       ((uVar15 < 0x20 || (uVar15 == 0x7f)))) goto code_r0x000180191014;
                                }
                                if (puVar21 == puVar1) goto code_r0x00018018f261;
                                break;
                            default:
                                uVar17 = 0x32;
                                uVar16 = 0x32;
code_r0x00018018f612:
                                uVar8 = 0;
                                break;
                            case 9:
                            case 0xd:
                                break;
                            case 10:
                                if (uVar15 != 0x20) {
                                    uVar8 = 0xb;
                                    goto code_r0x00018018f335;
                                }
                                break;
                            case 0xb:
                                if (uVar15 == 0x20) {
                                    uVar8 = 0xc;
                                    puVar21 = puVar21 + 1;
                                } else {
code_r0x00018018f335:
                                    if ((9 < (uint8_t)(uVar15 - 0x30)) || (0x1999999999999998 < *(uint64_t *)(arg1 + 8))
                                       ) {
                                        *(uint32_t *)arg1 =
                                             *(uint32_t *)arg1 ^ (uVar8 << 0x11 ^ *(uint32_t *)arg1) & 0xfe0000;
                                        goto code_r0x000180191033;
                                    }
                                    puVar21 = puVar21 + 1;
                                    *(uint64_t *)(arg1 + 8) =
                                         (int64_t)(int32_t)((int32_t)(char)uVar15 - 0x30) + *(uint64_t *)(arg1 + 8) * 10
                                    ;
                                }
                                goto code_r0x00018018f261;
                            case 0xc:
                                if (uVar15 != 0x20) {
                                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xff01ffff ^ 0x180000;
                                    uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x99ffffff | 0x19000000;
                                    goto code_r0x000180191213;
                                }
                                break;
                            case 0xf:
                                uVar19 = *(uint32_t *)arg1;
                                uVar5 = (uVar19 ^ uVar19 + 0x1000000) & 0x7f000000 ^ uVar19;
                                uVar19 = (uVar19 + 0x1000000 & 0x7f000000) >> 0x18;
                                *(uint32_t *)arg1 = uVar5;
                                if ((7 < uVar19) ||
                                   (uVar13 != *(uint8_t *)((uint64_t)(uVar5 >> 0x18 & 0x7f) + 0x1804a62f0)))
                                goto code_r0x00018018f612;
                                if (uVar19 == 6) {
                                    uVar8 = 0x15;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                break;
                            case 0x10:
                                if (uVar13 == 0x6b) {
                                    uVar8 = 0x11;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                if (uVar13 == 99) {
                                    uVar8 = 0x12;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                if (uVar13 == 0x75) {
                                    uVar8 = 0x13;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                if (uVar13 != 0x20) {
                                    uVar8 = -(uint32_t)(*(char *)((uint64_t)uVar13 + 0x1804a8a50) != '\0') & 0x14;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                break;
                            case 0x11:
                                uVar19 = *(uint32_t *)arg1;
                                uVar5 = (uVar19 ^ uVar19 + 0x1000000) & 0x7f000000 ^ uVar19;
                                uVar19 = (uVar19 + 0x1000000 & 0x7f000000) >> 0x18;
                                *(uint32_t *)arg1 = uVar5;
                                if ((10 < uVar19) ||
                                   (uVar13 != *(uint8_t *)((uint64_t)(uVar5 >> 0x18 & 0x7f) + 0x1804a6308))) {
code_r0x00018018f600:
                                    uVar8 = 0x14;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                if (uVar19 == 9) {
                                    uVar8 = 0x16;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                break;
                            case 0x12:
                                uVar19 = *(uint32_t *)arg1;
                                uVar5 = (uVar19 ^ uVar19 + 0x1000000) & 0x7f000000 ^ uVar19;
                                uVar19 = (uVar19 + 0x1000000 & 0x7f000000) >> 0x18;
                                *(uint32_t *)arg1 = uVar5;
                                if ((5 < uVar19) ||
                                   (uVar13 != *(uint8_t *)((uint64_t)(uVar5 >> 0x18 & 0x7f) + 0x18063c2dc)))
                                goto code_r0x00018018f600;
                                if (uVar19 == 4) {
                                    uVar8 = 0x17;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                break;
                            case 0x13:
                                uVar19 = *(uint32_t *)arg1;
                                uVar5 = (uVar19 ^ uVar19 + 0x1000000) & 0x7f000000 ^ uVar19;
                                uVar19 = (uVar19 + 0x1000000 & 0x7f000000) >> 0x18;
                                *(uint32_t *)arg1 = uVar5;
                                if ((7 < uVar19) ||
                                   (uVar13 != *(uint8_t *)((uint64_t)(uVar5 >> 0x18 & 0x7f) + 0x1804a6318)))
                                goto code_r0x00018018f600;
                                if (uVar19 == 6) {
                                    uVar8 = 0x18;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                break;
                            case 0x14:
                                if (uVar15 == 0x2c) {
                                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0x80ffffff;
                                    uVar8 = 0x10;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                break;
                            case 0x15:
                                if (uVar15 != 0x20) {
                                    uVar8 = 0;
                                    puVar21 = puVar21 + 1;
                                    goto code_r0x00018018f261;
                                }
                                break;
                            case 0x16:
                            case 0x17:
                            case 0x18:
                                if (uVar15 != 0x2c) {
                                    if (uVar15 != 0x20) goto code_r0x00018018f600;
                                    break;
                                }
                                if (uVar8 == 0x16) {
                                    *(uint32_t *)arg1 = *(uint32_t *)arg1 | 8;
                                    uVar8 = 0x10;
                                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0x80ffffff;
                                    puVar21 = puVar21 + 1;
                                } else if (uVar8 == 0x17) {
                                    *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0x10;
                                    uVar8 = 0x10;
                                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0x80ffffff;
                                    puVar21 = puVar21 + 1;
                                } else {
                                    if (uVar8 == 0x18) {
                                        *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0x20;
                                    }
                                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0x80ffffff;
                                    uVar8 = 0x10;
                                    puVar21 = puVar21 + 1;
                                }
                                goto code_r0x00018018f261;
                            }
                            puVar21 = puVar21 + 1;
                            goto code_r0x00018018f261;
                        }
                        uVar17 = 0x34;
                        uVar16 = 0x34;
                        uVar20 = uVar20 + ((int32_t)puVar21 - iVar4);
                        if (*(uint32_t *)0x18069c350 < uVar20) goto code_r0x000180191002;
                        uVar8 = (uVar8 << 0x11 ^ *(uint32_t *)arg1) & 0xfe0000 ^ *(uint32_t *)arg1;
                        *(uint32_t *)arg1 = uVar8;
                        puVar14 = (uint8_t *)var_8h;
                        puVar18 = (uint8_t *)var_68h;
                        uVar16 = uVar17;
                        if (var_8h != 0) {
                            if (*(int64_t *)(arg2 + 0x20) != 0) {
                                *(uint32_t *)arg1 = uVar8 & 0xfffed3ff | 0xd000;
                                iVar4 = (**(code **)(arg2 + 0x20))(arg1, var_8h, (int64_t)puVar21 - var_8h);
                                if (iVar4 != 0) {
                                    *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x84ffffff;
                                    *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) | 0x4000000;
                                    *(uint32_t *)(arg1 + 4) = uVar20;
                                }
                                if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x000180191077;
                                uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
                            }
                            var_8h = 0;
                            puVar14 = (uint8_t *)var_8h;
                            uVar17 = uVar16;
                        }
                        goto code_r0x00018018f1c0;
                    }
                    uVar17 = 0x34;
                    uVar16 = 0x34;
                    uVar19 = (uVar8 << 0x11 ^ *(uint32_t *)arg1) & 0xfe0000 ^ *(uint32_t *)arg1;
                    *(uint32_t *)arg1 = uVar19;
                    if (var_8h == 0) goto code_r0x00018018fbe9;
                    uVar16 = uVar17;
                    if (*(int64_t *)(arg2 + 0x20) != 0) {
                        *(uint32_t *)arg1 = uVar19 & 0xfffed3ff | 0xd000;
                        iVar6 = (**(code **)(arg2 + 0x20))(arg1, var_8h, (int64_t)puVar21 - var_8h);
                        if (iVar6 != 0) {
                            *(uint32_t *)(arg1 + 4) = uVar20;
                            *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x84ffffff | 0x4000000;
                        }
                        uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
                        if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
                    }
                    var_8h = 0;
                    uVar17 = uVar16;
                }
code_r0x00018018fbe9:
                *(uint32_t *)arg1 = *(uint32_t *)arg1 ^ (uVar8 << 0x11 ^ *(uint32_t *)arg1) & 0xfe0000;
                if (puVar21 == (uint8_t *)(arg3 + arg4)) {
                    puVar21 = puVar21 + -1;
                }
                uVar20 = uVar20 + ((int32_t)puVar21 - iVar4);
                if (*(uint32_t *)0x18069c350 < uVar20) goto code_r0x000180191002;
                goto code_r0x00018018fcc1;
            case 0x33:
                if ((uVar15 == 0x20) || (uVar15 == 9)) {
                    if ((*(uint32_t *)arg1 & 0xfe0000) == 0x160000) {
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xff19ffff | 0x180000;
                    }
                    uVar16 = 0x31;
                    uVar17 = 0x31;
                    goto code_r0x00018018f1c0;
                }
                uVar16 = *(uint32_t *)arg1;
                uVar17 = uVar16 >> 0x11 & 0x7f;
                if (uVar17 == 0x15) {
                    *(uint32_t *)arg1 = uVar16 | 4;
                } else {
                    if (uVar17 == 0x16) {
                        *(uint32_t *)arg1 = uVar16 | 8;
                        uVar16 = 0x2c;
                        uVar17 = 0x2c;
                        goto code_r0x00018018f1c0;
                    }
                    if (uVar17 == 0x17) {
                        *(uint32_t *)arg1 = uVar16 | 0x10;
                        uVar16 = 0x2c;
                        uVar17 = 0x2c;
                        goto code_r0x00018018f1c0;
                    }
                    if (uVar17 == 0x18) {
                        *(uint32_t *)arg1 = uVar16 | 0x20;
                        uVar16 = 0x2c;
                        uVar17 = 0x2c;
                        goto code_r0x00018018f1c0;
                    }
                }
                uVar16 = 0x2c;
                uVar17 = 0x2c;
                goto code_r0x00018018f1c0;
            case 0x34:
                if (uVar15 != 10) {
code_r0x00018019110f:
                    uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x97ffffff | 0x17000000;
                    goto code_r0x000180191213;
                }
                uVar16 = 0x33;
                uVar17 = 0x33;
                goto code_r0x00018018fcc1;
            case 0x35:
                cVar2 = *(char *)((uVar9 & 0xff) + 0x1804a8b50);
                if (cVar2 == -1) {
code_r0x0001801911f7:
                    uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x9bffffff | 0x1b000000;
                    goto code_r0x000180191213;
                }
                *(int64_t *)(arg1 + 8) = (int64_t)cVar2;
                uVar16 = 0x36;
                uVar17 = 0x36;
                goto code_r0x00018018fcc1;
            case 0x36:
                if (uVar15 == 0xd) {
                    uVar16 = 0x38;
                    uVar17 = 0x38;
                } else {
                    cVar2 = *(char *)((uVar9 & 0xff) + 0x1804a8b50);
                    if (cVar2 == -1) {
                        if ((uVar15 != 0x3b) && (uVar15 != 0x20)) goto code_r0x0001801911f7;
                        uVar16 = 0x37;
                        uVar17 = 0x37;
                    } else {
                        if (0xffffffffffffffe < *(uint64_t *)(arg1 + 8)) goto code_r0x000180191033;
                        *(uint64_t *)(arg1 + 8) = *(uint64_t *)(arg1 + 8) * 0x10 + (int64_t)cVar2;
                    }
                }
                goto code_r0x00018018fcc1;
            case 0x37:
                uVar16 = uVar17;
                if (uVar15 == 0xd) {
                    uVar16 = 0x38;
                    uVar17 = uVar16;
                }
                goto code_r0x00018018fcc1;
            case 0x38:
                if (uVar15 == 10) {
                    *(undefined4 *)(arg1 + 4) = 0;
                    if (*(int64_t *)(arg1 + 8) == 0) {
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0x40;
                        uVar17 = 0x2c;
                        uVar16 = 0x2c;
                    } else {
                        uVar17 = 0x3b;
                        uVar16 = 0x3b;
                    }
                    if (*(int64_t *)(arg2 + 0x40) != 0) {
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffe03ff;
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 | uVar16 << 10;
                        iVar4 = (**(code **)(arg2 + 0x40))(arg1);
                        if (iVar4 != 0) {
                            *(undefined4 *)(arg1 + 4) = 0;
                            *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x89ffffff | 0x9000000;
                        }
                        if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
                        uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
                        uVar17 = uVar16;
                    }
                    uVar20 = 0;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x39:
                if (uVar15 != 10) break;
                uVar17 = *(uint32_t *)arg1;
                uVar8 = uVar17 >> 2;
                if ((uVar8 & 0x10) == 0) {
                    if (((uVar8 & 1) != 0) && ((char)(uint8_t)uVar8 < '\0')) goto code_r0x000180191045;
                    if (((uint8_t)uVar8 & 0x28) == 0x28) {
                        if (((uVar17 & 3) == 0) || (*(int16_t *)(arg1 + 0x14) == 0x65)) {
                            uVar17 = 0x80000000;
                            uVar16 = *(uint32_t *)(arg1 + 0x14) & 0x7fffffff;
                        } else {
                            uVar17 = 0;
                            uVar16 = *(uint32_t *)(arg1 + 0x14) & 0x7fffffff;
                        }
                    } else {
                        uVar16 = 0;
                        if (*(char *)(arg1 + 0x16) == '\x05') {
                            uVar16 = 0x80000000;
                        }
                        uVar17 = *(uint32_t *)(arg1 + 0x14) & 0x7fffffff;
                    }
                    *(uint32_t *)(arg1 + 0x14) = uVar16 | uVar17;
                    if ((*(code **)(arg2 + 0x28) != (code *)0x0) &&
                       (iVar4 = (**(code **)(arg2 + 0x28))(arg1), puVar14 = (uint8_t *)var_8h, iVar4 != 0)) {
                        if (iVar4 != 1) {
                            if (iVar4 != 2) {
                                *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffeebff;
                                *(uint32_t *)(arg1 + 4) = uVar20;
                                *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0xe800;
                                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x85ffffff | 0x5000000;
                                goto code_r0x000180191077;
                            }
                            *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) | 0x80000000;
                        }
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0x100;
                    }
                    if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) {
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffeebff;
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0xe800;
                        *(uint32_t *)(arg1 + 4) = uVar20;
                        goto code_r0x000180191091;
                    }
                    uVar16 = 0x3a;
                    uVar17 = 0x3a;
                } else if (*(int64_t *)(arg2 + 0x48) == 0) {
                    uVar16 = 0x40;
                    uVar17 = 0x40;
                } else {
                    *(uint32_t *)arg1 = uVar17 & 0xffff03ff | 0x10000;
                    iVar4 = (**(code **)(arg2 + 0x48))(arg1);
                    if (iVar4 != 0) {
                        *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x8affffff;
                        *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) | 0xa000000;
                        *(uint32_t *)(arg1 + 4) = uVar20;
                    }
                    if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x000180191077;
                    uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
                    puVar14 = (uint8_t *)var_8h;
                    uVar17 = uVar16;
                }
                goto code_r0x00018018f1c0;
            case 0x3a:
                if (uVar15 == 10) {
                    *(undefined4 *)(arg1 + 4) = 0;
                    uVar16 = *(uint32_t *)arg1 >> 2;
                    if (((uVar16 & 1) != 0) || (uVar17 = 0, (*(int64_t *)(arg1 + 8) + 1U & 0xfffffffffffffffe) != 0)) {
                        uVar17 = 1;
                    }
                    uVar19 = 1;
                    uVar8 = *(uint32_t *)(arg1 + 0x14);
                    uVar20 = 0;
                    if (((int32_t)uVar8 < 0) &&
                       ((((char)(uVar8 >> 0x10) == '\x05' || ((uVar16 & 0x40) != 0)) || (uVar17 == 0)))) {
                        if ((*(int16_t *)(arg1 + 0x10) == 0) || (*(int16_t *)(arg1 + 0x12) == 0)) {
                            uVar7 = *(uint32_t *)arg1;
                            if ((uVar7 & 8) != 0) goto code_r0x00018019113d;
                        } else {
                            uVar7 = *(uint32_t *)arg1;
                            if ((uVar7 & 0x10) == 0) {
code_r0x00018019113d:
                                if ((((((uVar7 & 3) == 0) || (uVar8 = uVar8 & 0xffff, uVar8 - 100 < 100)) ||
                                     ((uVar8 == 0xcc ||
                                      (((uVar8 == 0x130 || ((uVar7 >> 8 & 1) != 0)) || ((uVar7 & 4) != 0)))))) ||
                                    (*(int64_t *)(arg1 + 8) != -1)) && (uVar19 = 4, (uVar7 & 3) == 0)) {
                                    uVar19 = 0x12;
                                }
                            }
                        }
                        if (*(int64_t *)(arg2 + 0x38) != 0) {
                            *(uint32_t *)arg1 = uVar7 & 0xfffe03ff | uVar19 << 10;
                            iVar4 = (**(code **)(arg2 + 0x38))(arg1);
                            if (iVar4 != 0) {
                                *(undefined4 *)(arg1 + 4) = 0;
                                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x87ffffff | 0x7000000;
                            }
                            if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
                            uVar7 = *(uint32_t *)arg1;
                            uVar19 = uVar7 >> 10;
                        }
                        *(undefined4 *)(arg1 + 4) = 0;
                        *(uint32_t *)arg1 = (uVar19 << 10 ^ uVar7) & 0x1fc00 ^ uVar7;
                        goto code_r0x0001801911e6;
                    }
                    if ((*(uint32_t *)arg1 >> 8 & 1) == 0) {
                        uVar17 = *(uint32_t *)arg1;
                        if ((uVar17 & 4) != 0) {
                            uVar20 = 0;
                            uVar16 = 0x35;
                            uVar17 = 0x35;
                            goto code_r0x00018018fcc1;
                        }
                        uVar16 = 1;
                        if (*(int64_t *)(arg1 + 8) == 0) {
                            if ((*(int16_t *)(arg1 + 0x10) == 0) || (*(int16_t *)(arg1 + 0x12) == 0)) {
                                uVar17 = uVar17 & 8;
                            } else {
                                uVar17 = uVar17 & 0x10;
                            }
                            if ((uVar17 != 0) && (uVar16 = 4, (*(uint8_t *)arg1 & 3) == 0)) {
                                uVar16 = 0x12;
                            }
                            uVar17 = uVar16;
                            if (*(int64_t *)(arg2 + 0x38) == 0) goto code_r0x00018018fcc1;
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffe03ff;
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 | uVar16 << 10;
                        } else {
                            if (*(int64_t *)(arg1 + 8) != -1) {
                                uVar20 = 0;
                                uVar16 = 0x3e;
                                uVar17 = 0x3e;
                                goto code_r0x00018018fcc1;
                            }
                            if (((((uVar17 & 3) != 0) && (uVar8 = uVar8 & 0xffff, 99 < uVar8 - 100)) && (uVar8 != 0xcc))
                               && ((uVar8 != 0x130 && ((uVar17 >> 8 & 1) == 0)))) {
                                uVar20 = 0;
                                uVar16 = 0x3f;
                                uVar17 = 0x3f;
                                goto code_r0x00018018fcc1;
                            }
                            if ((*(int16_t *)(arg1 + 0x10) == 0) || (*(int16_t *)(arg1 + 0x12) == 0)) {
                                uVar8 = *(uint32_t *)arg1;
                                if ((uVar8 & 8) != 0) goto code_r0x000180190c19;
                            } else {
                                uVar8 = *(uint32_t *)arg1;
                                if ((uVar8 & 0x10) == 0) {
code_r0x000180190c19:
                                    if ((((((uVar8 & 3) == 0) ||
                                          (uVar17 = *(uint32_t *)(arg1 + 0x14) & 0xffff, uVar17 - 100 < 100)) ||
                                         (uVar17 == 0xcc)) ||
                                        (((uVar17 == 0x130 || ((uVar8 >> 8 & 1) != 0)) ||
                                         (((uVar8 & 4) != 0 || (*(int64_t *)(arg1 + 8) != -1)))))) &&
                                       (uVar16 = 4, (uVar8 & 3) == 0)) {
                                        uVar16 = 0x12;
                                    }
                                }
                            }
                            uVar17 = uVar16;
                            if (*(int64_t *)(arg2 + 0x38) == 0) goto code_r0x00018018fcc1;
                            *(uint32_t *)arg1 = uVar8 & 0xfffe03ff | uVar16 << 10;
                        }
                    } else {
                        if ((*(int16_t *)(arg1 + 0x10) == 0) || (*(int16_t *)(arg1 + 0x12) == 0)) {
                            uVar8 = *(uint32_t *)arg1;
                            uVar16 = uVar8 & 8;
                        } else {
                            uVar8 = *(uint32_t *)arg1;
                            uVar16 = uVar8 & 0x10;
                        }
                        if (uVar16 == 0) {
                            uVar16 = 1;
                        } else {
                            uVar16 = 4;
                            if ((uVar8 & 3) == 0) {
                                uVar16 = 0x12;
                            }
                        }
                        uVar17 = uVar16;
                        if (*(int64_t *)(arg2 + 0x38) == 0) goto code_r0x00018018fcc1;
                        *(uint32_t *)arg1 = uVar16 << 10 | uVar8 & 0xfffe03ff;
                    }
                    iVar4 = (**(code **)(arg2 + 0x38))(arg1);
                    if (iVar4 != 0) {
                        *(undefined4 *)(arg1 + 4) = 0;
                        *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x87ffffff | 0x7000000;
                    }
                    if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
                    uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
                    uVar17 = uVar16;
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x3b:
                uVar9 = *(uint64_t *)(arg1 + 8);
                uVar12 = (arg3 - (int64_t)puVar21) + arg4;
                uVar11 = uVar9;
                if (uVar12 <= uVar9) {
                    uVar11 = uVar12;
                }
                var_68h = (int64_t)puVar18;
                if (puVar18 == (uint8_t *)0x0) {
                    var_68h = (int64_t)puVar21;
                }
                puVar21 = puVar21 + (uVar11 - 1);
                *(uint64_t *)(arg1 + 8) = uVar9 - uVar11;
                uVar16 = uVar17;
                if (uVar9 - uVar11 == 0) {
                    uVar16 = 0x3c;
                    uVar17 = 0x3c;
                }
                goto code_r0x00018018fcc1;
            case 0x3c:
                if (uVar15 == 0xd) {
                    uVar17 = 0x3d;
                    uVar16 = 0x3d;
                    if (puVar18 != (uint8_t *)0x0) {
                        if (*(int64_t *)(arg2 + 0x30) != 0) {
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffef7ff;
                            *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0xf400;
                            iVar4 = (**(code **)(arg2 + 0x30))(arg1, puVar18, (int64_t)puVar21 - (int64_t)puVar18);
                            if (iVar4 != 0) {
                                *(uint32_t *)(arg1 + 4) = uVar20;
                                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x86ffffff | 0x6000000;
                            }
                            if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
                            uVar17 = *(uint32_t *)arg1 >> 10 & 0x7f;
                        }
                        var_68h = 0;
                        uVar16 = uVar17;
                    }
                    goto code_r0x00018018fcc1;
                }
                break;
            case 0x3d:
                if (uVar15 != 10) break;
                uVar20 = 0;
                *(undefined4 *)(arg1 + 4) = 0;
                if (*(int64_t *)(arg2 + 0x48) != 0) {
                    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffed7ff;
                    *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0xd400;
                    iVar4 = (**(code **)(arg2 + 0x48))(arg1);
                    if (iVar4 != 0) {
                        *(undefined4 *)(arg1 + 4) = 0;
                        uVar16 = *(uint32_t *)(arg1 + 0x14) & 0x8affffff | 0xa000000;
                        goto code_r0x00018018fc8f;
                    }
                    goto code_r0x00018018fc92;
                }
                uVar16 = 0x35;
                uVar17 = 0x35;
                goto code_r0x00018018fcc1;
            case 0x3e:
                uVar11 = *(uint64_t *)(arg1 + 8);
                uVar10 = (arg3 - (int64_t)puVar21) + arg4;
                uVar12 = uVar11;
                if (uVar10 <= uVar11) {
                    uVar12 = uVar10;
                }
                var_68h = (int64_t)puVar18;
                if (puVar18 == (uint8_t *)0x0) {
                    var_68h = (int64_t)puVar21;
                }
                *(uint64_t *)(arg1 + 8) = uVar11 - uVar12;
                puVar21 = puVar21 + (uVar12 - 1);
                if (uVar11 - uVar12 != 0) goto code_r0x00018018fcc1;
                uVar17 = 0x40;
                puVar14 = (uint8_t *)var_8h;
                puVar18 = (uint8_t *)var_68h;
                uVar16 = 0x40;
                if ((uint8_t *)var_68h != (uint8_t *)0x0) {
                    if (*(int64_t *)(arg2 + 0x30) != 0) {
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xffff03ff;
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0x10000;
                        iVar4 = (**(code **)(arg2 + 0x30))(arg1, var_68h, puVar21 + (1 - var_68h));
                        if (iVar4 != 0) {
                            *(uint32_t *)(arg1 + 4) = uVar20;
                            *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x86ffffff | 0x6000000;
                        }
                        if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x000180191077;
                        uVar17 = *(uint32_t *)arg1 >> 10 & 0x7f;
                    }
                    var_68h = 0;
                    puVar18 = (uint8_t *)0x0;
                    uVar16 = uVar17;
                }
                goto code_r0x00018018f1c0;
            case 0x3f:
                var_68h = (int64_t)puVar18;
                if (puVar18 == (uint8_t *)0x0) {
                    var_68h = (int64_t)puVar21;
                }
                puVar21 = (uint8_t *)(arg4 + -1 + arg3);
                goto code_r0x00018018fcc1;
            case 0x40:
                if ((*(int16_t *)(arg1 + 0x10) == 0) || (*(int16_t *)(arg1 + 0x12) == 0)) {
                    uVar17 = *(uint32_t *)arg1;
                    uVar16 = uVar17 & 8;
                } else {
                    uVar17 = *(uint32_t *)arg1;
                    uVar16 = uVar17 & 0x10;
                }
                if ((uVar16 == 0) ||
                   ((((((uVar17 & 3) != 0 && (uVar16 = *(uint32_t *)(arg1 + 0x14) & 0xffff, 99 < uVar16 - 100)) &&
                      (uVar16 != 0xcc)) && ((uVar16 != 0x130 && ((uVar17 >> 2 & 0x40) == 0)))) &&
                    (((uVar17 >> 2 & 1) == 0 && (*(int64_t *)(arg1 + 8) == -1)))))) {
                    uVar16 = 1;
                } else {
                    uVar16 = 4;
                    if ((uVar17 & 3) == 0) {
                        uVar16 = 0x12;
                    }
                }
                if (*(int64_t *)(arg2 + 0x38) != 0) {
                    *(uint32_t *)arg1 = uVar17 & 0xfffe03ff | uVar16 << 10;
                    iVar4 = (**(code **)(arg2 + 0x38))(arg1);
                    if (iVar4 != 0) {
                        *(uint32_t *)(arg1 + 4) = uVar20;
                        *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x87ffffff | 0x7000000;
                    }
                    uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
                    if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x0001801911e6;
                }
                uVar17 = uVar16;
                if (*(int32_t *)(arg1 + 0x14) < 0) {
                    *(uint32_t *)(arg1 + 4) = uVar20;
                    *(uint32_t *)arg1 = *(uint32_t *)arg1 ^ (uVar16 << 10 ^ *(uint32_t *)arg1) & 0x1fc00;
                    return puVar21 + (1 - arg3);
                }
                goto code_r0x00018018fcc1;
            }
            uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x9effffff | 0x1e000000;
            goto code_r0x000180191213;
        }
        goto code_r0x000180191002;
    }
code_r0x000180191250:
    if ((var_78h == 0) || (*(int64_t *)(arg2 + 0x18) == 0)) {
code_r0x0001801912a6:
        if ((var_8h != 0) && (*(int64_t *)(arg2 + 0x20) != 0)) {
            *(uint32_t *)arg1 = *(uint32_t *)arg1 ^ (uVar16 << 10 ^ *(uint32_t *)arg1) & 0x1fc00;
            iVar4 = (**(code **)(arg2 + 0x20))(arg1, var_8h, (int64_t)puVar21 - var_8h);
            if (iVar4 != 0) {
                *(uint32_t *)(arg1 + 4) = uVar20;
                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x84ffffff | 0x4000000;
            }
            if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x000180191077;
            uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
        }
        if ((var_60h != 0) && (*(int64_t *)(arg2 + 8) != 0)) {
            *(uint32_t *)arg1 = *(uint32_t *)arg1 ^ (uVar16 << 10 ^ *(uint32_t *)arg1) & 0x1fc00;
            iVar4 = (**(code **)(arg2 + 8))(arg1, var_60h, (int64_t)puVar21 - var_60h);
            if (iVar4 != 0) {
                *(uint32_t *)(arg1 + 4) = uVar20;
                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x82ffffff | 0x2000000;
            }
            if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x000180191077;
            uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
        }
        if ((var_68h != 0) && (*(int64_t *)(arg2 + 0x30) != 0)) {
            *(uint32_t *)arg1 = *(uint32_t *)arg1 ^ (uVar16 << 10 ^ *(uint32_t *)arg1) & 0x1fc00;
            iVar4 = (**(code **)(arg2 + 0x30))(arg1, var_68h, (int64_t)puVar21 - var_68h);
            if (iVar4 != 0) {
                *(uint32_t *)(arg1 + 4) = uVar20;
                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x86ffffff | 0x6000000;
            }
            if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x000180191077;
            uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
        }
        if ((var_58h != 0) && (*(int64_t *)(arg2 + 0x10) != 0)) {
            *(uint32_t *)arg1 = *(uint32_t *)arg1 ^ (uVar16 << 10 ^ *(uint32_t *)arg1) & 0x1fc00;
            iVar4 = (**(code **)(arg2 + 0x10))(arg1, var_58h, (int64_t)puVar21 - var_58h);
            if (iVar4 != 0) {
                *(uint32_t *)(arg1 + 4) = uVar20;
                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x88ffffff | 0x8000000;
            }
            if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) goto code_r0x000180191077;
            uVar16 = *(uint32_t *)arg1 >> 10;
        }
        *(uint32_t *)(arg1 + 4) = uVar20;
        *(uint32_t *)arg1 = *(uint32_t *)arg1 ^ (uVar16 << 10 ^ *(uint32_t *)arg1) & 0x1fc00;
    } else {
        *(uint32_t *)arg1 = *(uint32_t *)arg1 ^ (uVar16 << 10 ^ *(uint32_t *)arg1) & 0x1fc00;
        iVar4 = (**(code **)(arg2 + 0x18))(arg1, var_78h, (int64_t)puVar21 - var_78h);
        if (iVar4 != 0) {
            *(uint32_t *)(arg1 + 4) = uVar20;
            *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x83ffffff | 0x3000000;
        }
        if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) == 0) {
            uVar16 = *(uint32_t *)arg1 >> 10 & 0x7f;
            goto code_r0x0001801912a6;
        }
code_r0x000180191077:
        arg4 = (int64_t)(puVar21 + -arg3);
    }
    return (uint8_t *)arg4;
joined_r0x0001801904dd:
    if (puVar21 == (uint8_t *)(arg3 + arg4)) goto code_r0x00018019086d;
    uVar15 = *puVar21;
    if ((uVar15 == 0x20) || (cVar2 = *(char *)((uint64_t)uVar15 + 0x1804a8a50), cVar2 == '\0'))
    goto code_r0x00018019086d;
    uVar8 = *(uint32_t *)arg1;
    // switch table (15 cases) at 0x180191618
    switch(uVar8 >> 0x11 & 0x7f) {
    case 0:
        puVar14 = puVar21 + 1;
        uVar11 = (arg3 - (int64_t)puVar21) + arg4;
        uVar9 = (uint64_t)*(uint32_t *)0x18069c350;
        if (uVar11 < *(uint32_t *)0x18069c350) {
            uVar9 = uVar11;
        }
        while (puVar14 < (uint8_t *)(uVar9 + arg3)) {
            if ((puVar21[1] == 0x20) || (*(char *)((uint64_t)puVar21[1] + 0x1804a8a50) == '\0')) break;
            puVar14 = puVar21 + 2;
            puVar21 = puVar21 + 1;
        }
        break;
    case 1:
        uVar19 = 0;
        if (cVar2 == 'o') {
            uVar19 = 0x40000;
        }
        *(uint32_t *)arg1 = ((uVar8 + 0x1000000 ^ uVar8) & 0x7f000000 ^ uVar8) & 0xff01ffff | uVar19;
        break;
    case 2:
        uVar19 = 0;
        if (cVar2 == 'n') {
            uVar19 = 0x60000;
        }
        *(uint32_t *)arg1 = ((uVar8 + 0x1000000 ^ uVar8) & 0x7f000000 ^ uVar8) & 0xff01ffff | uVar19;
        break;
    case 3:
        uVar8 = (uVar8 + 0x1000000 ^ uVar8) & 0x7f000000 ^ uVar8;
        if (cVar2 == 'n') {
            *(uint32_t *)arg1 = uVar8 & 0xff09ffff | 0x80000;
        } else if (cVar2 == 't') {
            *(uint32_t *)arg1 = uVar8 & 0xff0dffff | 0xc0000;
        } else {
            *(uint32_t *)arg1 = uVar8 & 0xff01ffff;
        }
        break;
    case 4:
        uVar19 = (uVar8 ^ uVar8 + 0x1000000) & 0x7f000000 ^ uVar8;
        uVar8 = (uVar8 + 0x1000000 & 0x7f000000) >> 0x18;
        *(uint32_t *)arg1 = uVar19;
        if ((uVar8 < 0xb) && (cVar2 == *(char *)((uint64_t)(uVar19 >> 0x18 & 0x7f) + 0x1804a62f8))) {
            if (uVar8 == 9) {
                *(uint32_t *)arg1 = uVar19 & 0xff13ffff | 0x120000;
            }
        } else {
code_r0x000180190698:
            *(uint32_t *)arg1 = uVar19 & 0xff01ffff;
        }
        break;
    case 5:
        uVar19 = (uVar8 ^ uVar8 + 0x1000000) & 0x7f000000 ^ uVar8;
        uVar8 = (uVar8 + 0x1000000 & 0x7f000000) >> 0x18;
        *(uint32_t *)arg1 = uVar19;
        if ((0x10 < uVar8) || (cVar2 != *(char *)((uint64_t)(uVar19 >> 0x18 & 0x7f) + 0x1804a9380)))
        goto code_r0x000180190698;
        if (uVar8 == 0xf) {
            *(uint32_t *)arg1 = uVar19 & 0xff13ffff | 0x120000;
        }
        break;
    case 6:
        uVar19 = (uVar8 ^ uVar8 + 0x1000000) & 0x7f000000 ^ uVar8;
        uVar8 = (uVar8 + 0x1000000 & 0x7f000000) >> 0x18;
        *(uint32_t *)arg1 = uVar19;
        if ((0xe < uVar8) || (cVar2 != *(char *)((uint64_t)(uVar19 >> 0x18 & 0x7f) + 0x1804a8960)))
        goto code_r0x000180190698;
        if (uVar8 == 0xd) {
            *(uint32_t *)arg1 = uVar19 & 0xff15ffff | 0x140000;
        }
        break;
    case 7:
        uVar19 = (uVar8 ^ uVar8 + 0x1000000) & 0x7f000000 ^ uVar8;
        uVar8 = (uVar8 + 0x1000000 & 0x7f000000) >> 0x18;
        *(uint32_t *)arg1 = uVar19;
        if ((0x11 < uVar8) || (cVar2 != *(char *)((uint64_t)(uVar19 >> 0x18 & 0x7f) + 0x1804a9398)))
        goto code_r0x000180190698;
        if (uVar8 == 0x10) {
            *(uint32_t *)arg1 = uVar19 & 0xff1bfffb | 0x1a0000;
        }
        break;
    case 8:
        uVar19 = (uVar8 ^ uVar8 + 0x1000000) & 0x7f000000 ^ uVar8;
        uVar8 = (uVar8 + 0x1000000 & 0x7f000000) >> 0x18;
        *(uint32_t *)arg1 = uVar19;
        if ((7 < uVar8) || (cVar2 != *(char *)((uint64_t)(uVar19 >> 0x18 & 0x7f) + 0x1804a6318)))
        goto code_r0x000180190698;
        if (uVar8 == 6) {
            *(uint32_t *)arg1 = uVar19 & 0xff1dffff | 0x1c0000;
        }
        break;
    case 9:
    case 10:
    case 0xd:
    case 0xe:
        *(uint32_t *)arg1 = uVar8 & 0xff01ffff;
    }
    puVar21 = puVar21 + 1;
    goto joined_r0x0001801904dd;
code_r0x00018018f20f:
    uVar17 = 0x10;
    uVar16 = 0x10;
    if (var_58h == 0) {
        var_58h = (int64_t)puVar21;
    }
    *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0x80ffffff;
    if ((uVar15 == 0xd) || (uVar15 == 10)) goto code_r0x00018018f1c0;
    goto code_r0x00018018fcc1;
code_r0x00018019086d:
    if (puVar21 == (uint8_t *)(arg3 + arg4)) {
        puVar21 = puVar21 + -1;
        uVar20 = uVar20 + ((int32_t)puVar21 - iVar4);
        if (uVar20 <= *(uint32_t *)0x18069c350) {
code_r0x00018018fcc1:
            puVar21 = puVar21 + 1;
            if (puVar21 == puVar1) goto code_r0x000180191250;
            goto code_r0x00018018f196;
        }
    } else {
        uVar20 = uVar20 + ((int32_t)puVar21 - iVar4);
        if (uVar20 <= *(uint32_t *)0x18069c350) {
            if (uVar15 == 0x3a) {
                uVar17 = 0x2e;
                uVar16 = 0x2e;
                if (var_78h != 0) {
                    if (*(int64_t *)(arg2 + 0x18) != 0) {
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 & 0xfffebbff;
                        *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0xb800;
                        iVar4 = (**(code **)(arg2 + 0x18))(arg1, var_78h, (int64_t)puVar21 - var_78h);
                        if (iVar4 != 0) {
                            *(uint32_t *)(arg1 + 4) = uVar20;
                            *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) & 0x83ffffff | 0x3000000;
                        }
                        if ((*(uint32_t *)(arg1 + 0x14) & 0x7f000000) != 0) {
code_r0x0001801911e6:
                            return puVar21 + (1 - arg3);
                        }
                        uVar17 = *(uint32_t *)arg1 >> 10 & 0x7f;
                    }
                    var_78h = 0;
                    uVar16 = uVar17;
                }
                goto code_r0x00018018fcc1;
            }
code_r0x000180191014:
            uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x98ffffff | 0x18000000;
            goto code_r0x000180191213;
        }
    }
code_r0x000180191002:
    uVar7 = *(uint32_t *)(arg1 + 0x14) & 0x8cffffff | 0xc000000;
code_r0x000180191213:
    *(uint32_t *)(arg1 + 4) = uVar20;
    *(uint32_t *)(arg1 + 0x14) = uVar7;
    if ((uVar7 & 0x7f000000) == 0) {
        *(uint32_t *)(arg1 + 0x14) = uVar7 & 0xa0ffffff | 0x20000000;
    }
    *(uint32_t *)(arg1 + 4) = uVar20;
    *(uint32_t *)arg1 = *(uint32_t *)arg1 ^ (uVar16 << 10 ^ *(uint32_t *)arg1) & 0x1fc00;
code_r0x000180191091:
    return puVar21 + -arg3;
}

// ============================================================
// Function: FUN_1801918e0
// Address: 0x1801918e0
// Size: 67 bytes
// ============================================================
undefined8 fcn.1801918e0(void)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801918ea;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801918f2;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18019190a;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                  *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18019191c;
    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
    return 0;
}

// ============================================================
// Function: FUN_180191930
// Address: 0x180191930
// Size: 41 bytes
// ============================================================
void fcn.180191930(void)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18019193a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0x180197330;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180191954;
    fcn.18022c840(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000058 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180191960
// Address: 0x180191960
// Size: 162 bytes
// ============================================================
undefined8 fcn.180191960(int64_t param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_8;
    
    uStack_8 = 0x18019196a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (param_1 == 0) {
code_r0x0001801919cc:
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801919d1;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801919e9;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000028 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801919fb;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar2));
        return 0;
    }
    iVar4 = ***(int64_t ***)(param_1 + 0x158);
    if (iVar4 == 0) goto code_r0x0001801919cc;
    if ((**(int64_t ***)(param_1 + 0x158))[1] == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180191992;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801919aa;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000028 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801919bc;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar2));
        return 0;
    }
    *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + 8) = unaff_RBX;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar2) = 0x18023810c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (iVar4 != 0) {
        uVar5 = *(undefined8 *)(iVar4 + 0x50);
        *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar2) = 0x180238124;
        iVar4 = fcn.180235930(uVar5);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar2) = 0x180238138;
            uVar5 = fcn.18022ebc0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000060 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000068 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000070 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000078 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x000000d0 + iVar3 + iVar2));
            iVar1 = (int32_t)uVar5;
            if (iVar1 == -2) {
                *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar2) = 0x1802381a2;
                fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar3 + iVar2));
                *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar2) = 0x1802381ba;
                fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000070 + iVar3 + iVar2));
            } else if (iVar1 == -1) {
                *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar2) = 0x18023817e;
                fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar3 + iVar2));
                *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar2) = 0x180238196;
                fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000070 + iVar3 + iVar2));
            } else {
                if (iVar1 != 0) {
                    if (iVar1 != 1) {
                        return 0;
                    }
                    return uVar5;
                }
                *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar2) = 0x18023815a;
                fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar3 + iVar2));
                *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar2) = 0x180238172;
                fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000070 + iVar3 + iVar2));
            }
            goto code_r0x0001802381e3;
        }
    }
    *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar2) = 0x1802381c6;
    fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2));
    *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar2) = 0x1802381de;
    fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                  *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                  *(int64_t *)(&stack0x00000070 + iVar3 + iVar2));
code_r0x0001802381e3:
    *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar2) = 0x1802381f0;
    fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar3 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_180191a20
// Address: 0x180191a20
// Size: 1240 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.180191a20(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                      int64_t arg_58h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_f0h, int64_t arg_1f0h)
{
    uint32_t *puVar1;
    uint32_t uVar2;
    undefined4 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    int32_t in_EDX;
    int64_t iVar10;
    uint64_t uVar11;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar12;
    uint32_t uVar13;
    uint64_t in_R8;
    undefined8 in_R9;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180191a30;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar13 = (uint32_t)in_R8;
    uVar11 = (uint64_t)(int32_t)uVar13;
    if ((in_EDX == 0x5c) && (uVar13 == 1)) {
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = in_R9;
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = 0;
        *(undefined8 *)((int64_t)&var_20h + iVar6) = 0;
        *(undefined8 *)((int64_t)&var_18h + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180191a69;
        uVar11 = fcn.1801abdc0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                               *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                               *(int64_t *)(&stack0x00000068 + iVar6), *(int64_t *)(&stack0x00000088 + iVar6), 
                               *(int64_t *)(&stack0x00000090 + iVar6));
        return uVar11;
    }
    if (in_RCX == 0) {
        if ((in_EDX - 0x62U & 0xfffffffb) != 0) {
            return 0;
        }
        iVar4 = 0;
        iVar10 = 0;
        iVar9 = 0;
        uVar12 = *(undefined8 *)(&stack0x00000038 + iVar6);
        *(undefined8 *)(&stack0x00000038 + iVar6) = *(undefined8 *)((int64_t)&arg_48h + iVar6);
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RSI;
        *(undefined8 *)((int64_t)&var_20h + iVar6) = unaff_R14;
        *(undefined8 *)((int64_t)&var_18h + iVar6) = 0x1801ac790;
        iVar7 = fcn.18045a350(0, 0, in_R9);
        iVar7 = -iVar7;
        *(uint64_t *)((int64_t)&arg_e0h + iVar7 + iVar6) = *(uint64_t *)0x1806a3940 ^ (int64_t)&var_20h + iVar7 + iVar6;
        *(undefined8 *)((int64_t)&arg_50h + iVar7 + iVar6) = 0;
        iVar8 = *(int64_t *)((int64_t)&arg_d8h + iVar7 + iVar6);
        if (iVar9 != 0) {
            iVar8 = iVar9;
        }
        *(int64_t *)((int64_t)&arg_d8h + iVar7 + iVar6) = iVar8;
        *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar6) = (int64_t)&arg_50h + iVar7 + iVar6;
        *(undefined8 *)((int64_t)&var_18h + iVar7 + iVar6) = 0x1801ac7f0;
        iVar5 = fcn.18024a850(*(int64_t *)((int64_t)&arg_48h + iVar7 + iVar6), 
                              *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar6), 
                              *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6), 
                              *(int64_t *)(&stack0x00000068 + iVar7 + iVar6));
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&arg_f0h + iVar7 + iVar6) = uVar12;
            iVar8 = *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar6);
            if (iVar8 == 0) {
                *(undefined8 *)((int64_t)&var_18h + iVar7 + iVar6) = 0x1801ac80f;
                fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar7 + iVar6), 
                              *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar6));
                *(undefined8 *)((int64_t)&var_18h + iVar7 + iVar6) = 0x1801ac827;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar7 + iVar6), 
                              *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar6), 
                              *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar6), 
                              *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6), 
                              *(int64_t *)(&stack0x00000070 + iVar7 + iVar6));
                *(undefined8 *)((int64_t)&var_18h + iVar7 + iVar6) = 0x1801ac840;
                fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar7 + iVar6));
            } else if (iVar10 != 0) {
                *(undefined8 *)((int64_t)&var_18h + iVar7 + iVar6) = 0x1801ac86d;
                iVar9 = fcn.180224ed0(*(int64_t *)((int64_t)&arg_40h + iVar7 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x00000060 + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x00000068 + iVar7 + iVar6));
                if (iVar9 != 0) {
                    *(undefined8 *)((int64_t)&var_18h + iVar7 + iVar6) = 0x1801ac886;
                    fcn.180498030(iVar9, (int64_t)&arg_58h + iVar7 + iVar6, iVar8 * 2);
                    if (iVar4 == 0) {
                        uVar12 = *(undefined8 *)(iVar10 + 0x40);
                        *(undefined8 *)((int64_t)&var_18h + iVar7 + iVar6) = 0x1801ac8ba;
                        fcn.180224990(uVar12, 0x1804aeee0, 0xf17);
                        *(int64_t *)(iVar10 + 0x40) = iVar9;
                        *(int64_t *)(iVar10 + 0x48) = iVar8;
                    } else {
                        uVar12 = *(undefined8 *)(iVar10 + 0x50);
                        *(undefined8 *)((int64_t)&var_18h + iVar7 + iVar6) = 0x1801ac8a1;
                        fcn.180224990(uVar12, 0x1804aeee0, 0xf13);
                        *(int64_t *)(iVar10 + 0x50) = iVar9;
                        *(int64_t *)(iVar10 + 0x58) = iVar8;
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&var_18h + iVar7 + iVar6) = 0x1801ac8e1;
        uVar11 = fcn.180459870(*(uint64_t *)((int64_t)&arg_e0h + iVar7 + iVar6) ^ (int64_t)&var_20h + iVar7 + iVar6);
        return uVar11;
    }
    // switch table (116 cases) at 0x180191e00
    switch(in_EDX) {
    case 0x10:
        *(undefined8 *)(in_RCX + 0x178) = in_R9;
        return 1;
    default:
    // WARNING: Could not recover jumptable at 0x000180191dfb. Too many branches
    // WARNING: Treating indirect jump as call
        uVar11 = (**(code **)(*(int64_t *)(in_RCX + 8) + 0xa0))(in_RCX);
        return uVar11;
    case 0x14:
        if (*(int64_t *)(in_RCX + 0x30) == 0) {
            return 0;
        }
        return (uint64_t)*(uint32_t *)(*(int64_t *)(in_RCX + 0x30) + 0x50);
    case 0x15:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x78);
    case 0x16:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x80);
    case 0x17:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x7c);
    case 0x18:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x84);
    case 0x19:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x8c);
    case 0x1a:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x88);
    case 0x1b:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x9c);
    case 0x1c:
        return (uint64_t)*(uint32_t *)(in_RCX + 0xa0);
    case 0x1d:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x90);
    case 0x1e:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x94);
    case 0x1f:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x98);
    case 0x21:
        *(uint32_t *)(in_RCX + 0x140) = *(uint32_t *)(in_RCX + 0x140) | uVar13;
        return (uint64_t)*(uint32_t *)(in_RCX + 0x140);
    case 0x28:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x168);
    case 0x29:
        uVar2 = *(uint32_t *)(in_RCX + 0x168);
        *(uint32_t *)(in_RCX + 0x168) = uVar13;
        return (uint64_t)uVar2;
    case 0x2a:
        if (-1 < (int32_t)uVar13) {
            uVar13 = *(uint32_t *)(in_RCX + 0x38);
            *(uint64_t *)(in_RCX + 0x38) = uVar11;
            return (uint64_t)uVar13;
        }
        break;
    case 0x2b:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x38);
    case 0x2c:
        uVar2 = *(uint32_t *)(in_RCX + 0x50);
        *(uint32_t *)(in_RCX + 0x50) = uVar13;
        return (uint64_t)uVar2;
    case 0x2d:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x50);
    case 0x32:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x150);
    case 0x33:
        if (-1 < (int32_t)uVar13) {
            uVar13 = *(uint32_t *)(in_RCX + 0x150);
            *(uint64_t *)(in_RCX + 0x150) = uVar11;
            return (uint64_t)uVar13;
        }
        break;
    case 0x34:
        if (uVar13 - 0x200 < 0x3e01) {
            *(uint64_t *)(in_RCX + 0x1f0) = uVar11;
            if (uVar11 < *(uint64_t *)(in_RCX + 0x1e8)) {
                *(uint64_t *)(in_RCX + 0x1e8) = uVar11;
            }
            return 1;
        }
        break;
    case 0x4e:
        *(uint32_t *)(in_RCX + 0x140) = *(uint32_t *)(in_RCX + 0x140) & ~uVar13;
        return (uint64_t)*(uint32_t *)(in_RCX + 0x140);
    case 99:
        iVar6 = *(int64_t *)(in_RCX + 0x158);
        puVar1 = (uint32_t *)(iVar6 + 0x1c);
        *puVar1 = *puVar1 | uVar13;
        return (uint64_t)*(uint32_t *)(iVar6 + 0x1c);
    case 100:
        iVar6 = *(int64_t *)(in_RCX + 0x158);
        puVar1 = (uint32_t *)(iVar6 + 0x1c);
        *puVar1 = *puVar1 & ~uVar13;
        return (uint64_t)*(uint32_t *)(iVar6 + 0x1c);
    case 0x7b:
        uVar3 = *(undefined4 *)(in_RCX + 0x148);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180191d57;
        iVar4 = fcn.180197230(in_R8 & 0xffffffff, uVar3);
        if (iVar4 == 0) {
            return 0;
        }
        uVar3 = **(undefined4 **)(in_RCX + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180191d6f;
        iVar4 = fcn.1801afd20(uVar3, in_R8 & 0xffffffff, in_RCX + 0x144);
        if (iVar4 == 0) {
            return 0;
        }
        return 1;
    case 0x7c:
        uVar3 = *(undefined4 *)(in_RCX + 0x144);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180191da4;
        iVar4 = fcn.180197230(uVar3, in_R8 & 0xffffffff);
        if (iVar4 != 0) {
            uVar3 = **(undefined4 **)(in_RCX + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180191dba;
            iVar4 = fcn.1801afd20(uVar3);
            if (iVar4 != 0) {
                return 1;
            }
        }
        return 0;
    case 0x7d:
        if ((uVar11 <= *(uint64_t *)(in_RCX + 0x1f0)) && (uVar13 != 0)) {
            *(uint64_t *)(in_RCX + 0x1e8) = uVar11;
            return 1;
        }
        break;
    case 0x7e:
        if (uVar13 - 1 < 0x20) {
            *(uint64_t *)(in_RCX + 0x1f8) = uVar11;
            return 1;
        }
        break;
    case 0x82:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x144);
    case 0x83:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x148);
    }
    return 0;
}

// ============================================================
// Function: FUN_180191f00
// Address: 0x180191f00
// Size: 55 bytes
// ============================================================
void fcn.180191f00(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 unaff_RBP;
    int64_t iVar7;
    undefined8 unaff_RSI;
    int64_t *piVar8;
    uint64_t uVar9;
    undefined8 unaff_RDI;
    uint64_t uVar10;
    uint64_t uVar11;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180191f14;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0xa4);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            uVar3 = *(undefined8 *)(arg1 + 0x1c0);
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191f50;
            func_0x000180233bc0(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x3b8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191f69;
            fcn.180224990(uVar3, 0x1804a94a0, 0x9c);
            uVar3 = *(undefined8 *)(arg1 + 0x3c0);
            uVar11 = 0;
            *(undefined8 *)(arg1 + 0x3b8) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191f8c;
            fcn.180224990(uVar3, 0x1804a94a0, 0x9f);
            *(undefined8 *)(arg1 + 0x3c0) = 0;
            *(undefined *)(arg1 + 0x3c8) = 0;
            if (*(int64_t *)(arg1 + 0x30) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191faa;
                func_0x00018019c780(arg1, 0);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fbe;
            func_0x000180223fb0(1, arg1, arg1 + 0xf0);
            uVar3 = *(undefined8 *)(arg1 + 0x30);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fc7;
            func_0x000180228ec0(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x28);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fd0;
            func_0x00018021f290(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x1d0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fdc;
            func_0x00018023b1a0(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fe5;
            func_0x000180221d50(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fee;
            func_0x000180221d50(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x20);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191ff7;
            func_0x000180221d50(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x158);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192003;
            func_0x0001801a1e40(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x128);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192016;
            func_0x000180222050(uVar3, 0x1802348f0);
            uVar3 = *(undefined8 *)(arg1 + 0x130);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192029;
            func_0x000180222050(uVar3, 0x1802348f0);
            uVar3 = *(undefined8 *)(arg1 + 0x110);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192035;
            func_0x000180238640(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x3d0);
            *(undefined8 *)(arg1 + 0x118) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192048;
            func_0x000180221d50(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192050;
            func_0x0001801bd180(arg1);
            uVar3 = *(undefined8 *)(arg1 + 0x208);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019205c;
            func_0x0001801bca50(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x288);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192075;
            fcn.180224990(uVar3, 0x1804a94a0, 0x115c);
            uVar3 = *(undefined8 *)(arg1 + 0x298);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019208e;
            fcn.180224990(uVar3, 0x1804a94a0, 0x115d);
            uVar3 = *(undefined8 *)(arg1 + 0x2a8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801920a7;
            fcn.180224990(uVar3, 0x1804a94a0, 0x115e);
            uVar3 = *(undefined8 *)(arg1 + 0x2b8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801920c0;
            fcn.180224990(uVar3, 0x1804a94a0, 0x115f);
            uVar3 = *(undefined8 *)(arg1 + 0x2d0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801920d9;
            fcn.180224990(uVar3, 0x1804a94a0, 0x1160);
            uVar3 = *(undefined8 *)(arg1 + 0x250);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801920f2;
            func_0x000180225200(uVar3, 0x1804a94a0, 0x1161);
            iVar7 = *(int64_t *)(arg1 + 0x100);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192106;
                iVar5 = func_0x00018020f790(iVar7);
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192113;
                    func_0x000180215590(iVar7);
                }
            }
            iVar7 = *(int64_t *)(arg1 + 0x108);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192127;
                iVar5 = func_0x00018020f790(iVar7);
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192134;
                    func_0x000180215590(iVar7);
                }
            }
            piVar8 = (int64_t *)(arg1 + 0x4a0);
            iVar7 = 0x18;
            do {
                iVar5 = *piVar8;
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192150;
                    iVar6 = func_0x00018020eec0(iVar5);
                    if (iVar6 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019215d;
                        func_0x000180211a40(iVar5);
                    }
                }
                piVar8 = piVar8 + 1;
                iVar7 = iVar7 + -1;
            } while (iVar7 != 0);
            piVar8 = (int64_t *)(arg1 + 0x560);
            iVar7 = 0xe;
            do {
                iVar5 = *piVar8;
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192183;
                    iVar6 = func_0x00018020f790(iVar5);
                    if (iVar6 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192190;
                        func_0x000180215590(iVar5);
                    }
                }
                piVar8 = piVar8 + 1;
                iVar7 = iVar7 + -1;
            } while (iVar7 != 0);
            uVar9 = uVar11;
            uVar10 = uVar11;
            if (*(int64_t *)(arg1 + 0x668) != 0) {
                do {
                    uVar3 = *(undefined8 *)(uVar10 + *(int64_t *)(arg1 + 0x660));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801921cd;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x116b);
                    uVar3 = *(undefined8 *)(uVar10 + 8 + *(int64_t *)(arg1 + 0x660));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801921eb;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x116c);
                    uVar3 = *(undefined8 *)(uVar10 + 0x10 + *(int64_t *)(arg1 + 0x660));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192209;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x116d);
                    uVar9 = uVar9 + 1;
                    uVar10 = uVar10 + 0x38;
                } while (uVar9 < *(uint64_t *)(arg1 + 0x668));
            }
            uVar3 = *(undefined8 *)(arg1 + 0x660);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192232;
            fcn.180224990(uVar3, 0x1804a94a0, 0x116f);
            uVar9 = uVar11;
            if (*(int64_t *)(arg1 + 0x680) != 0) {
                do {
                    uVar3 = *(undefined8 *)(uVar11 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019226d;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1171);
                    uVar3 = *(undefined8 *)(uVar11 + 0x10 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019228b;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1172);
                    uVar3 = *(undefined8 *)(uVar11 + 0x18 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801922a9;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1173);
                    uVar3 = *(undefined8 *)(uVar11 + 0x20 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801922c7;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1174);
                    uVar3 = *(undefined8 *)(uVar11 + 0x28 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801922e5;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1175);
                    uVar3 = *(undefined8 *)(uVar11 + 0x30 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192303;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1176);
                    uVar3 = *(undefined8 *)(uVar11 + 0x38 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192321;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1177);
                    uVar3 = *(undefined8 *)(uVar11 + 0x40 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019233f;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1178);
                    uVar3 = *(undefined8 *)(uVar11 + 0x48 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019235d;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1179);
                    uVar9 = uVar9 + 1;
                    uVar11 = uVar11 + 0x68;
                } while (uVar9 < *(uint64_t *)(arg1 + 0x680));
            }
            uVar3 = *(undefined8 *)(arg1 + 0x678);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019238a;
            fcn.180224990(uVar3, 0x1804a94a0, 0x117b);
            uVar3 = *(undefined8 *)(arg1 + 0x160);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801923a3;
            fcn.180224990(uVar3, 0x1804a94a0, 0x117c);
            uVar3 = *(undefined8 *)(arg1 + 0x650);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801923bc;
            fcn.180224990(uVar3, 0x1804a94a0, 0x117e);
            uVar3 = *(undefined8 *)(arg1 + 0x658);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801923d5;
            fcn.180224990(uVar3, 0x1804a94a0, 0x117f);
            uVar3 = *(undefined8 *)(arg1 + 0x6a0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801923ee;
            fcn.180224990(uVar3, 0x1804a94a0, 0x1181);
            uVar3 = *(undefined8 *)(arg1 + 0x6b0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192407;
            fcn.180224990(uVar3, 0x1804a94a0, 0x1182);
            uVar3 = *(undefined8 *)(arg1 + 0x3e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192413;
            func_0x0001802227d0(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x460);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019242c;
            fcn.180224990(uVar3, 0x1804a94a0, 0x118a);
            uVar3 = *(undefined8 *)(arg1 + 0x6d0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192445;
            fcn.180224990(uVar3, 0x1804a94a0, 0x118c);
            uVar3 = *(undefined8 *)(arg1 + 0x6c8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192451;
            func_0x0001801bf190(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192466;
            fcn.180224990(arg1, 0x1804a94a0, 0x1193);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180191f37
// Address: 0x180191f37
// Size: 628 bytes
// ============================================================
void fcn.180191f00(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 unaff_RBP;
    int64_t iVar7;
    undefined8 unaff_RSI;
    int64_t *piVar8;
    uint64_t uVar9;
    undefined8 unaff_RDI;
    uint64_t uVar10;
    uint64_t uVar11;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180191f14;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0xa4);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            uVar3 = *(undefined8 *)(arg1 + 0x1c0);
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191f50;
            func_0x000180233bc0(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x3b8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191f69;
            fcn.180224990(uVar3, 0x1804a94a0, 0x9c);
            uVar3 = *(undefined8 *)(arg1 + 0x3c0);
            uVar11 = 0;
            *(undefined8 *)(arg1 + 0x3b8) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191f8c;
            fcn.180224990(uVar3, 0x1804a94a0, 0x9f);
            *(undefined8 *)(arg1 + 0x3c0) = 0;
            *(undefined *)(arg1 + 0x3c8) = 0;
            if (*(int64_t *)(arg1 + 0x30) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191faa;
                func_0x00018019c780(arg1, 0);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fbe;
            func_0x000180223fb0(1, arg1, arg1 + 0xf0);
            uVar3 = *(undefined8 *)(arg1 + 0x30);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fc7;
            func_0x000180228ec0(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x28);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fd0;
            func_0x00018021f290(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x1d0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fdc;
            func_0x00018023b1a0(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fe5;
            func_0x000180221d50(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fee;
            func_0x000180221d50(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x20);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191ff7;
            func_0x000180221d50(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x158);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192003;
            func_0x0001801a1e40(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x128);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192016;
            func_0x000180222050(uVar3, 0x1802348f0);
            uVar3 = *(undefined8 *)(arg1 + 0x130);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192029;
            func_0x000180222050(uVar3, 0x1802348f0);
            uVar3 = *(undefined8 *)(arg1 + 0x110);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192035;
            func_0x000180238640(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x3d0);
            *(undefined8 *)(arg1 + 0x118) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192048;
            func_0x000180221d50(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192050;
            func_0x0001801bd180(arg1);
            uVar3 = *(undefined8 *)(arg1 + 0x208);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019205c;
            func_0x0001801bca50(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x288);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192075;
            fcn.180224990(uVar3, 0x1804a94a0, 0x115c);
            uVar3 = *(undefined8 *)(arg1 + 0x298);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019208e;
            fcn.180224990(uVar3, 0x1804a94a0, 0x115d);
            uVar3 = *(undefined8 *)(arg1 + 0x2a8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801920a7;
            fcn.180224990(uVar3, 0x1804a94a0, 0x115e);
            uVar3 = *(undefined8 *)(arg1 + 0x2b8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801920c0;
            fcn.180224990(uVar3, 0x1804a94a0, 0x115f);
            uVar3 = *(undefined8 *)(arg1 + 0x2d0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801920d9;
            fcn.180224990(uVar3, 0x1804a94a0, 0x1160);
            uVar3 = *(undefined8 *)(arg1 + 0x250);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801920f2;
            func_0x000180225200(uVar3, 0x1804a94a0, 0x1161);
            iVar7 = *(int64_t *)(arg1 + 0x100);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192106;
                iVar5 = func_0x00018020f790(iVar7);
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192113;
                    func_0x000180215590(iVar7);
                }
            }
            iVar7 = *(int64_t *)(arg1 + 0x108);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192127;
                iVar5 = func_0x00018020f790(iVar7);
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192134;
                    func_0x000180215590(iVar7);
                }
            }
            piVar8 = (int64_t *)(arg1 + 0x4a0);
            iVar7 = 0x18;
            do {
                iVar5 = *piVar8;
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192150;
                    iVar6 = func_0x00018020eec0(iVar5);
                    if (iVar6 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019215d;
                        func_0x000180211a40(iVar5);
                    }
                }
                piVar8 = piVar8 + 1;
                iVar7 = iVar7 + -1;
            } while (iVar7 != 0);
            piVar8 = (int64_t *)(arg1 + 0x560);
            iVar7 = 0xe;
            do {
                iVar5 = *piVar8;
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192183;
                    iVar6 = func_0x00018020f790(iVar5);
                    if (iVar6 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192190;
                        func_0x000180215590(iVar5);
                    }
                }
                piVar8 = piVar8 + 1;
                iVar7 = iVar7 + -1;
            } while (iVar7 != 0);
            uVar9 = uVar11;
            uVar10 = uVar11;
            if (*(int64_t *)(arg1 + 0x668) != 0) {
                do {
                    uVar3 = *(undefined8 *)(uVar10 + *(int64_t *)(arg1 + 0x660));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801921cd;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x116b);
                    uVar3 = *(undefined8 *)(uVar10 + 8 + *(int64_t *)(arg1 + 0x660));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801921eb;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x116c);
                    uVar3 = *(undefined8 *)(uVar10 + 0x10 + *(int64_t *)(arg1 + 0x660));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192209;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x116d);
                    uVar9 = uVar9 + 1;
                    uVar10 = uVar10 + 0x38;
                } while (uVar9 < *(uint64_t *)(arg1 + 0x668));
            }
            uVar3 = *(undefined8 *)(arg1 + 0x660);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192232;
            fcn.180224990(uVar3, 0x1804a94a0, 0x116f);
            uVar9 = uVar11;
            if (*(int64_t *)(arg1 + 0x680) != 0) {
                do {
                    uVar3 = *(undefined8 *)(uVar11 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019226d;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1171);
                    uVar3 = *(undefined8 *)(uVar11 + 0x10 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019228b;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1172);
                    uVar3 = *(undefined8 *)(uVar11 + 0x18 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801922a9;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1173);
                    uVar3 = *(undefined8 *)(uVar11 + 0x20 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801922c7;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1174);
                    uVar3 = *(undefined8 *)(uVar11 + 0x28 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801922e5;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1175);
                    uVar3 = *(undefined8 *)(uVar11 + 0x30 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192303;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1176);
                    uVar3 = *(undefined8 *)(uVar11 + 0x38 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192321;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1177);
                    uVar3 = *(undefined8 *)(uVar11 + 0x40 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019233f;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1178);
                    uVar3 = *(undefined8 *)(uVar11 + 0x48 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019235d;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1179);
                    uVar9 = uVar9 + 1;
                    uVar11 = uVar11 + 0x68;
                } while (uVar9 < *(uint64_t *)(arg1 + 0x680));
            }
            uVar3 = *(undefined8 *)(arg1 + 0x678);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019238a;
            fcn.180224990(uVar3, 0x1804a94a0, 0x117b);
            uVar3 = *(undefined8 *)(arg1 + 0x160);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801923a3;
            fcn.180224990(uVar3, 0x1804a94a0, 0x117c);
            uVar3 = *(undefined8 *)(arg1 + 0x650);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801923bc;
            fcn.180224990(uVar3, 0x1804a94a0, 0x117e);
            uVar3 = *(undefined8 *)(arg1 + 0x658);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801923d5;
            fcn.180224990(uVar3, 0x1804a94a0, 0x117f);
            uVar3 = *(undefined8 *)(arg1 + 0x6a0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801923ee;
            fcn.180224990(uVar3, 0x1804a94a0, 0x1181);
            uVar3 = *(undefined8 *)(arg1 + 0x6b0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192407;
            fcn.180224990(uVar3, 0x1804a94a0, 0x1182);
            uVar3 = *(undefined8 *)(arg1 + 0x3e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192413;
            func_0x0001802227d0(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x460);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019242c;
            fcn.180224990(uVar3, 0x1804a94a0, 0x118a);
            uVar3 = *(undefined8 *)(arg1 + 0x6d0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192445;
            fcn.180224990(uVar3, 0x1804a94a0, 0x118c);
            uVar3 = *(undefined8 *)(arg1 + 0x6c8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192451;
            func_0x0001801bf190(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192466;
            fcn.180224990(arg1, 0x1804a94a0, 0x1193);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801921ab
// Address: 0x1801921ab
// Size: 153 bytes
// ============================================================
void fcn.180191f00(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 unaff_RBP;
    int64_t iVar7;
    undefined8 unaff_RSI;
    int64_t *piVar8;
    uint64_t uVar9;
    undefined8 unaff_RDI;
    uint64_t uVar10;
    uint64_t uVar11;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180191f14;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0xa4);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            uVar3 = *(undefined8 *)(arg1 + 0x1c0);
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191f50;
            func_0x000180233bc0(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x3b8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191f69;
            fcn.180224990(uVar3, 0x1804a94a0, 0x9c);
            uVar3 = *(undefined8 *)(arg1 + 0x3c0);
            uVar11 = 0;
            *(undefined8 *)(arg1 + 0x3b8) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191f8c;
            fcn.180224990(uVar3, 0x1804a94a0, 0x9f);
            *(undefined8 *)(arg1 + 0x3c0) = 0;
            *(undefined *)(arg1 + 0x3c8) = 0;
            if (*(int64_t *)(arg1 + 0x30) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191faa;
                func_0x00018019c780(arg1, 0);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fbe;
            func_0x000180223fb0(1, arg1, arg1 + 0xf0);
            uVar3 = *(undefined8 *)(arg1 + 0x30);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fc7;
            func_0x000180228ec0(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x28);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fd0;
            func_0x00018021f290(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x1d0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fdc;
            func_0x00018023b1a0(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fe5;
            func_0x000180221d50(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fee;
            func_0x000180221d50(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x20);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191ff7;
            func_0x000180221d50(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x158);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192003;
            func_0x0001801a1e40(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x128);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192016;
            func_0x000180222050(uVar3, 0x1802348f0);
            uVar3 = *(undefined8 *)(arg1 + 0x130);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192029;
            func_0x000180222050(uVar3, 0x1802348f0);
            uVar3 = *(undefined8 *)(arg1 + 0x110);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192035;
            func_0x000180238640(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x3d0);
            *(undefined8 *)(arg1 + 0x118) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192048;
            func_0x000180221d50(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192050;
            func_0x0001801bd180(arg1);
            uVar3 = *(undefined8 *)(arg1 + 0x208);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019205c;
            func_0x0001801bca50(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x288);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192075;
            fcn.180224990(uVar3, 0x1804a94a0, 0x115c);
            uVar3 = *(undefined8 *)(arg1 + 0x298);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019208e;
            fcn.180224990(uVar3, 0x1804a94a0, 0x115d);
            uVar3 = *(undefined8 *)(arg1 + 0x2a8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801920a7;
            fcn.180224990(uVar3, 0x1804a94a0, 0x115e);
            uVar3 = *(undefined8 *)(arg1 + 0x2b8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801920c0;
            fcn.180224990(uVar3, 0x1804a94a0, 0x115f);
            uVar3 = *(undefined8 *)(arg1 + 0x2d0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801920d9;
            fcn.180224990(uVar3, 0x1804a94a0, 0x1160);
            uVar3 = *(undefined8 *)(arg1 + 0x250);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801920f2;
            func_0x000180225200(uVar3, 0x1804a94a0, 0x1161);
            iVar7 = *(int64_t *)(arg1 + 0x100);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192106;
                iVar5 = func_0x00018020f790(iVar7);
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192113;
                    func_0x000180215590(iVar7);
                }
            }
            iVar7 = *(int64_t *)(arg1 + 0x108);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192127;
                iVar5 = func_0x00018020f790(iVar7);
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192134;
                    func_0x000180215590(iVar7);
                }
            }
            piVar8 = (int64_t *)(arg1 + 0x4a0);
            iVar7 = 0x18;
            do {
                iVar5 = *piVar8;
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192150;
                    iVar6 = func_0x00018020eec0(iVar5);
                    if (iVar6 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019215d;
                        func_0x000180211a40(iVar5);
                    }
                }
                piVar8 = piVar8 + 1;
                iVar7 = iVar7 + -1;
            } while (iVar7 != 0);
            piVar8 = (int64_t *)(arg1 + 0x560);
            iVar7 = 0xe;
            do {
                iVar5 = *piVar8;
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192183;
                    iVar6 = func_0x00018020f790(iVar5);
                    if (iVar6 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192190;
                        func_0x000180215590(iVar5);
                    }
                }
                piVar8 = piVar8 + 1;
                iVar7 = iVar7 + -1;
            } while (iVar7 != 0);
            uVar9 = uVar11;
            uVar10 = uVar11;
            if (*(int64_t *)(arg1 + 0x668) != 0) {
                do {
                    uVar3 = *(undefined8 *)(uVar10 + *(int64_t *)(arg1 + 0x660));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801921cd;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x116b);
                    uVar3 = *(undefined8 *)(uVar10 + 8 + *(int64_t *)(arg1 + 0x660));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801921eb;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x116c);
                    uVar3 = *(undefined8 *)(uVar10 + 0x10 + *(int64_t *)(arg1 + 0x660));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192209;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x116d);
                    uVar9 = uVar9 + 1;
                    uVar10 = uVar10 + 0x38;
                } while (uVar9 < *(uint64_t *)(arg1 + 0x668));
            }
            uVar3 = *(undefined8 *)(arg1 + 0x660);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192232;
            fcn.180224990(uVar3, 0x1804a94a0, 0x116f);
            uVar9 = uVar11;
            if (*(int64_t *)(arg1 + 0x680) != 0) {
                do {
                    uVar3 = *(undefined8 *)(uVar11 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019226d;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1171);
                    uVar3 = *(undefined8 *)(uVar11 + 0x10 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019228b;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1172);
                    uVar3 = *(undefined8 *)(uVar11 + 0x18 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801922a9;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1173);
                    uVar3 = *(undefined8 *)(uVar11 + 0x20 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801922c7;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1174);
                    uVar3 = *(undefined8 *)(uVar11 + 0x28 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801922e5;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1175);
                    uVar3 = *(undefined8 *)(uVar11 + 0x30 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192303;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1176);
                    uVar3 = *(undefined8 *)(uVar11 + 0x38 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192321;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1177);
                    uVar3 = *(undefined8 *)(uVar11 + 0x40 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019233f;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1178);
                    uVar3 = *(undefined8 *)(uVar11 + 0x48 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019235d;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1179);
                    uVar9 = uVar9 + 1;
                    uVar11 = uVar11 + 0x68;
                } while (uVar9 < *(uint64_t *)(arg1 + 0x680));
            }
            uVar3 = *(undefined8 *)(arg1 + 0x678);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019238a;
            fcn.180224990(uVar3, 0x1804a94a0, 0x117b);
            uVar3 = *(undefined8 *)(arg1 + 0x160);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801923a3;
            fcn.180224990(uVar3, 0x1804a94a0, 0x117c);
            uVar3 = *(undefined8 *)(arg1 + 0x650);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801923bc;
            fcn.180224990(uVar3, 0x1804a94a0, 0x117e);
            uVar3 = *(undefined8 *)(arg1 + 0x658);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801923d5;
            fcn.180224990(uVar3, 0x1804a94a0, 0x117f);
            uVar3 = *(undefined8 *)(arg1 + 0x6a0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801923ee;
            fcn.180224990(uVar3, 0x1804a94a0, 0x1181);
            uVar3 = *(undefined8 *)(arg1 + 0x6b0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192407;
            fcn.180224990(uVar3, 0x1804a94a0, 0x1182);
            uVar3 = *(undefined8 *)(arg1 + 0x3e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192413;
            func_0x0001802227d0(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x460);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019242c;
            fcn.180224990(uVar3, 0x1804a94a0, 0x118a);
            uVar3 = *(undefined8 *)(arg1 + 0x6d0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192445;
            fcn.180224990(uVar3, 0x1804a94a0, 0x118c);
            uVar3 = *(undefined8 *)(arg1 + 0x6c8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192451;
            func_0x0001801bf190(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192466;
            fcn.180224990(arg1, 0x1804a94a0, 0x1193);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180192244
// Address: 0x180192244
// Size: 556 bytes
// ============================================================
void fcn.180191f00(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 unaff_RBP;
    int64_t iVar7;
    undefined8 unaff_RSI;
    int64_t *piVar8;
    uint64_t uVar9;
    undefined8 unaff_RDI;
    uint64_t uVar10;
    uint64_t uVar11;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180191f14;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0xa4);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            uVar3 = *(undefined8 *)(arg1 + 0x1c0);
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191f50;
            func_0x000180233bc0(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x3b8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191f69;
            fcn.180224990(uVar3, 0x1804a94a0, 0x9c);
            uVar3 = *(undefined8 *)(arg1 + 0x3c0);
            uVar11 = 0;
            *(undefined8 *)(arg1 + 0x3b8) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191f8c;
            fcn.180224990(uVar3, 0x1804a94a0, 0x9f);
            *(undefined8 *)(arg1 + 0x3c0) = 0;
            *(undefined *)(arg1 + 0x3c8) = 0;
            if (*(int64_t *)(arg1 + 0x30) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191faa;
                func_0x00018019c780(arg1, 0);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fbe;
            func_0x000180223fb0(1, arg1, arg1 + 0xf0);
            uVar3 = *(undefined8 *)(arg1 + 0x30);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fc7;
            func_0x000180228ec0(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x28);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fd0;
            func_0x00018021f290(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x1d0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fdc;
            func_0x00018023b1a0(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fe5;
            func_0x000180221d50(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fee;
            func_0x000180221d50(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x20);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191ff7;
            func_0x000180221d50(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x158);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192003;
            func_0x0001801a1e40(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x128);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192016;
            func_0x000180222050(uVar3, 0x1802348f0);
            uVar3 = *(undefined8 *)(arg1 + 0x130);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192029;
            func_0x000180222050(uVar3, 0x1802348f0);
            uVar3 = *(undefined8 *)(arg1 + 0x110);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192035;
            func_0x000180238640(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x3d0);
            *(undefined8 *)(arg1 + 0x118) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192048;
            func_0x000180221d50(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192050;
            func_0x0001801bd180(arg1);
            uVar3 = *(undefined8 *)(arg1 + 0x208);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019205c;
            func_0x0001801bca50(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x288);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192075;
            fcn.180224990(uVar3, 0x1804a94a0, 0x115c);
            uVar3 = *(undefined8 *)(arg1 + 0x298);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019208e;
            fcn.180224990(uVar3, 0x1804a94a0, 0x115d);
            uVar3 = *(undefined8 *)(arg1 + 0x2a8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801920a7;
            fcn.180224990(uVar3, 0x1804a94a0, 0x115e);
            uVar3 = *(undefined8 *)(arg1 + 0x2b8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801920c0;
            fcn.180224990(uVar3, 0x1804a94a0, 0x115f);
            uVar3 = *(undefined8 *)(arg1 + 0x2d0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801920d9;
            fcn.180224990(uVar3, 0x1804a94a0, 0x1160);
            uVar3 = *(undefined8 *)(arg1 + 0x250);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801920f2;
            func_0x000180225200(uVar3, 0x1804a94a0, 0x1161);
            iVar7 = *(int64_t *)(arg1 + 0x100);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192106;
                iVar5 = func_0x00018020f790(iVar7);
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192113;
                    func_0x000180215590(iVar7);
                }
            }
            iVar7 = *(int64_t *)(arg1 + 0x108);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192127;
                iVar5 = func_0x00018020f790(iVar7);
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192134;
                    func_0x000180215590(iVar7);
                }
            }
            piVar8 = (int64_t *)(arg1 + 0x4a0);
            iVar7 = 0x18;
            do {
                iVar5 = *piVar8;
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192150;
                    iVar6 = func_0x00018020eec0(iVar5);
                    if (iVar6 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019215d;
                        func_0x000180211a40(iVar5);
                    }
                }
                piVar8 = piVar8 + 1;
                iVar7 = iVar7 + -1;
            } while (iVar7 != 0);
            piVar8 = (int64_t *)(arg1 + 0x560);
            iVar7 = 0xe;
            do {
                iVar5 = *piVar8;
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192183;
                    iVar6 = func_0x00018020f790(iVar5);
                    if (iVar6 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192190;
                        func_0x000180215590(iVar5);
                    }
                }
                piVar8 = piVar8 + 1;
                iVar7 = iVar7 + -1;
            } while (iVar7 != 0);
            uVar9 = uVar11;
            uVar10 = uVar11;
            if (*(int64_t *)(arg1 + 0x668) != 0) {
                do {
                    uVar3 = *(undefined8 *)(uVar10 + *(int64_t *)(arg1 + 0x660));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801921cd;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x116b);
                    uVar3 = *(undefined8 *)(uVar10 + 8 + *(int64_t *)(arg1 + 0x660));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801921eb;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x116c);
                    uVar3 = *(undefined8 *)(uVar10 + 0x10 + *(int64_t *)(arg1 + 0x660));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192209;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x116d);
                    uVar9 = uVar9 + 1;
                    uVar10 = uVar10 + 0x38;
                } while (uVar9 < *(uint64_t *)(arg1 + 0x668));
            }
            uVar3 = *(undefined8 *)(arg1 + 0x660);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192232;
            fcn.180224990(uVar3, 0x1804a94a0, 0x116f);
            uVar9 = uVar11;
            if (*(int64_t *)(arg1 + 0x680) != 0) {
                do {
                    uVar3 = *(undefined8 *)(uVar11 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019226d;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1171);
                    uVar3 = *(undefined8 *)(uVar11 + 0x10 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019228b;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1172);
                    uVar3 = *(undefined8 *)(uVar11 + 0x18 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801922a9;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1173);
                    uVar3 = *(undefined8 *)(uVar11 + 0x20 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801922c7;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1174);
                    uVar3 = *(undefined8 *)(uVar11 + 0x28 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801922e5;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1175);
                    uVar3 = *(undefined8 *)(uVar11 + 0x30 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192303;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1176);
                    uVar3 = *(undefined8 *)(uVar11 + 0x38 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192321;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1177);
                    uVar3 = *(undefined8 *)(uVar11 + 0x40 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019233f;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1178);
                    uVar3 = *(undefined8 *)(uVar11 + 0x48 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019235d;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1179);
                    uVar9 = uVar9 + 1;
                    uVar11 = uVar11 + 0x68;
                } while (uVar9 < *(uint64_t *)(arg1 + 0x680));
            }
            uVar3 = *(undefined8 *)(arg1 + 0x678);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019238a;
            fcn.180224990(uVar3, 0x1804a94a0, 0x117b);
            uVar3 = *(undefined8 *)(arg1 + 0x160);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801923a3;
            fcn.180224990(uVar3, 0x1804a94a0, 0x117c);
            uVar3 = *(undefined8 *)(arg1 + 0x650);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801923bc;
            fcn.180224990(uVar3, 0x1804a94a0, 0x117e);
            uVar3 = *(undefined8 *)(arg1 + 0x658);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801923d5;
            fcn.180224990(uVar3, 0x1804a94a0, 0x117f);
            uVar3 = *(undefined8 *)(arg1 + 0x6a0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801923ee;
            fcn.180224990(uVar3, 0x1804a94a0, 0x1181);
            uVar3 = *(undefined8 *)(arg1 + 0x6b0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192407;
            fcn.180224990(uVar3, 0x1804a94a0, 0x1182);
            uVar3 = *(undefined8 *)(arg1 + 0x3e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192413;
            func_0x0001802227d0(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x460);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019242c;
            fcn.180224990(uVar3, 0x1804a94a0, 0x118a);
            uVar3 = *(undefined8 *)(arg1 + 0x6d0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192445;
            fcn.180224990(uVar3, 0x1804a94a0, 0x118c);
            uVar3 = *(undefined8 *)(arg1 + 0x6c8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192451;
            func_0x0001801bf190(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192466;
            fcn.180224990(arg1, 0x1804a94a0, 0x1193);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180192470
// Address: 0x180192470
// Size: 6 bytes
// ============================================================
void fcn.180191f00(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 unaff_RBP;
    int64_t iVar7;
    undefined8 unaff_RSI;
    int64_t *piVar8;
    uint64_t uVar9;
    undefined8 unaff_RDI;
    uint64_t uVar10;
    uint64_t uVar11;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180191f14;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0xa4);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            uVar3 = *(undefined8 *)(arg1 + 0x1c0);
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191f50;
            func_0x000180233bc0(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x3b8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191f69;
            fcn.180224990(uVar3, 0x1804a94a0, 0x9c);
            uVar3 = *(undefined8 *)(arg1 + 0x3c0);
            uVar11 = 0;
            *(undefined8 *)(arg1 + 0x3b8) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191f8c;
            fcn.180224990(uVar3, 0x1804a94a0, 0x9f);
            *(undefined8 *)(arg1 + 0x3c0) = 0;
            *(undefined *)(arg1 + 0x3c8) = 0;
            if (*(int64_t *)(arg1 + 0x30) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191faa;
                func_0x00018019c780(arg1, 0);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fbe;
            func_0x000180223fb0(1, arg1, arg1 + 0xf0);
            uVar3 = *(undefined8 *)(arg1 + 0x30);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fc7;
            func_0x000180228ec0(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x28);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fd0;
            func_0x00018021f290(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x1d0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fdc;
            func_0x00018023b1a0(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fe5;
            func_0x000180221d50(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191fee;
            func_0x000180221d50(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x20);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180191ff7;
            func_0x000180221d50(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x158);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192003;
            func_0x0001801a1e40(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x128);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192016;
            func_0x000180222050(uVar3, 0x1802348f0);
            uVar3 = *(undefined8 *)(arg1 + 0x130);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192029;
            func_0x000180222050(uVar3, 0x1802348f0);
            uVar3 = *(undefined8 *)(arg1 + 0x110);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192035;
            func_0x000180238640(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x3d0);
            *(undefined8 *)(arg1 + 0x118) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192048;
            func_0x000180221d50(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192050;
            func_0x0001801bd180(arg1);
            uVar3 = *(undefined8 *)(arg1 + 0x208);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019205c;
            func_0x0001801bca50(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x288);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192075;
            fcn.180224990(uVar3, 0x1804a94a0, 0x115c);
            uVar3 = *(undefined8 *)(arg1 + 0x298);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019208e;
            fcn.180224990(uVar3, 0x1804a94a0, 0x115d);
            uVar3 = *(undefined8 *)(arg1 + 0x2a8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801920a7;
            fcn.180224990(uVar3, 0x1804a94a0, 0x115e);
            uVar3 = *(undefined8 *)(arg1 + 0x2b8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801920c0;
            fcn.180224990(uVar3, 0x1804a94a0, 0x115f);
            uVar3 = *(undefined8 *)(arg1 + 0x2d0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801920d9;
            fcn.180224990(uVar3, 0x1804a94a0, 0x1160);
            uVar3 = *(undefined8 *)(arg1 + 0x250);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801920f2;
            func_0x000180225200(uVar3, 0x1804a94a0, 0x1161);
            iVar7 = *(int64_t *)(arg1 + 0x100);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192106;
                iVar5 = func_0x00018020f790(iVar7);
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192113;
                    func_0x000180215590(iVar7);
                }
            }
            iVar7 = *(int64_t *)(arg1 + 0x108);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192127;
                iVar5 = func_0x00018020f790(iVar7);
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192134;
                    func_0x000180215590(iVar7);
                }
            }
            piVar8 = (int64_t *)(arg1 + 0x4a0);
            iVar7 = 0x18;
            do {
                iVar5 = *piVar8;
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192150;
                    iVar6 = func_0x00018020eec0(iVar5);
                    if (iVar6 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019215d;
                        func_0x000180211a40(iVar5);
                    }
                }
                piVar8 = piVar8 + 1;
                iVar7 = iVar7 + -1;
            } while (iVar7 != 0);
            piVar8 = (int64_t *)(arg1 + 0x560);
            iVar7 = 0xe;
            do {
                iVar5 = *piVar8;
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192183;
                    iVar6 = func_0x00018020f790(iVar5);
                    if (iVar6 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192190;
                        func_0x000180215590(iVar5);
                    }
                }
                piVar8 = piVar8 + 1;
                iVar7 = iVar7 + -1;
            } while (iVar7 != 0);
            uVar9 = uVar11;
            uVar10 = uVar11;
            if (*(int64_t *)(arg1 + 0x668) != 0) {
                do {
                    uVar3 = *(undefined8 *)(uVar10 + *(int64_t *)(arg1 + 0x660));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801921cd;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x116b);
                    uVar3 = *(undefined8 *)(uVar10 + 8 + *(int64_t *)(arg1 + 0x660));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801921eb;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x116c);
                    uVar3 = *(undefined8 *)(uVar10 + 0x10 + *(int64_t *)(arg1 + 0x660));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192209;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x116d);
                    uVar9 = uVar9 + 1;
                    uVar10 = uVar10 + 0x38;
                } while (uVar9 < *(uint64_t *)(arg1 + 0x668));
            }
            uVar3 = *(undefined8 *)(arg1 + 0x660);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192232;
            fcn.180224990(uVar3, 0x1804a94a0, 0x116f);
            uVar9 = uVar11;
            if (*(int64_t *)(arg1 + 0x680) != 0) {
                do {
                    uVar3 = *(undefined8 *)(uVar11 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019226d;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1171);
                    uVar3 = *(undefined8 *)(uVar11 + 0x10 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019228b;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1172);
                    uVar3 = *(undefined8 *)(uVar11 + 0x18 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801922a9;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1173);
                    uVar3 = *(undefined8 *)(uVar11 + 0x20 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801922c7;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1174);
                    uVar3 = *(undefined8 *)(uVar11 + 0x28 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801922e5;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1175);
                    uVar3 = *(undefined8 *)(uVar11 + 0x30 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192303;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1176);
                    uVar3 = *(undefined8 *)(uVar11 + 0x38 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192321;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1177);
                    uVar3 = *(undefined8 *)(uVar11 + 0x40 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019233f;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1178);
                    uVar3 = *(undefined8 *)(uVar11 + 0x48 + *(int64_t *)(arg1 + 0x678));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019235d;
                    fcn.180224990(uVar3, 0x1804a94a0, 0x1179);
                    uVar9 = uVar9 + 1;
                    uVar11 = uVar11 + 0x68;
                } while (uVar9 < *(uint64_t *)(arg1 + 0x680));
            }
            uVar3 = *(undefined8 *)(arg1 + 0x678);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019238a;
            fcn.180224990(uVar3, 0x1804a94a0, 0x117b);
            uVar3 = *(undefined8 *)(arg1 + 0x160);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801923a3;
            fcn.180224990(uVar3, 0x1804a94a0, 0x117c);
            uVar3 = *(undefined8 *)(arg1 + 0x650);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801923bc;
            fcn.180224990(uVar3, 0x1804a94a0, 0x117e);
            uVar3 = *(undefined8 *)(arg1 + 0x658);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801923d5;
            fcn.180224990(uVar3, 0x1804a94a0, 0x117f);
            uVar3 = *(undefined8 *)(arg1 + 0x6a0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801923ee;
            fcn.180224990(uVar3, 0x1804a94a0, 0x1181);
            uVar3 = *(undefined8 *)(arg1 + 0x6b0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192407;
            fcn.180224990(uVar3, 0x1804a94a0, 0x1182);
            uVar3 = *(undefined8 *)(arg1 + 0x3e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192413;
            func_0x0001802227d0(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x460);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019242c;
            fcn.180224990(uVar3, 0x1804a94a0, 0x118a);
            uVar3 = *(undefined8 *)(arg1 + 0x6d0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192445;
            fcn.180224990(uVar3, 0x1804a94a0, 0x118c);
            uVar3 = *(undefined8 *)(arg1 + 0x6c8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192451;
            func_0x0001801bf190(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180192466;
            fcn.180224990(arg1, 0x1804a94a0, 0x1193);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801924a0
// Address: 0x1801924a0
// Size: 124 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1801924a0(int64_t arg_28h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t in_R8;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801924b0;
    iVar3 = fcn.18045a350();
    if (in_RDX == 0) {
        if (in_R8 != 0) {
code_r0x0001801924ec:
            uVar1 = *(undefined8 *)(in_RCX + 0x28);
            *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x1801924f8;
            iVar2 = func_0x0001802339b0(uVar1, in_R8);
            return iVar2 != 0;
        }
    } else {
        uVar1 = *(undefined8 *)(in_RCX + 0x28);
        *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x1801924e3;
        iVar2 = func_0x000180233920(uVar1);
        if (iVar2 != 0) {
            if (in_R8 == 0) {
                return true;
            }
            goto code_r0x0001801924ec;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_180192520
// Address: 0x180192520
// Size: 29 bytes
// ============================================================
undefined8 *
fcn.180192520(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_60h, int64_t arg_68h,
             int64_t arg_70h, int64_t arg_78h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 *arg1;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t in_RCX;
    undefined8 uVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 auStackX_8 [4];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar8 = 0;
    uVar9 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + 0x18) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + 8) = unaff_R12;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3) = 0x180192558;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    arg1 = (undefined8 *)0x0;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192574;
        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019258c;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019259e;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
        return (undefined8 *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar4 + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_68h + iVar4 + iVar3) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801925bb;
    iVar2 = func_0x00018019a3b0(0x200000, 0);
    if (iVar2 == 0) {
        return (undefined8 *)0x0;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801925c8;
    iVar2 = func_0x0001801a1090();
    if (iVar2 < 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801925d1;
        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801925e9;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
        goto code_r0x000180192b49;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019260a;
    arg1 = (undefined8 *)func_0x000180224d60(0x6d8, 0x1804a94a0, 0xfd2);
    if (arg1 == (undefined8 *)0x0) {
        return (undefined8 *)0x0;
    }
    *(undefined4 *)((int64_t)arg1 + 0xa4) = 1;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192625;
    iVar5 = func_0x000180222800();
    arg1[0x7c] = iVar5;
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192636;
        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
code_r0x00018019263b:
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019264e;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
    } else {
        *arg1 = uVar9;
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192675;
            iVar5 = func_0x0001802231e0(iVar8, 0x1804a94a0, 0xfec);
            arg1[0x8c] = iVar5;
            if (iVar5 == 0) goto code_r0x000180192b56;
        }
        arg1[1] = in_RCX;
        *(undefined8 *)((int64_t)arg1 + 0x144) = 0;
        *(undefined4 *)(arg1 + 0x28) = 4;
        *(undefined4 *)(arg1 + 10) = 2;
        arg1[7] = 0x5000;
        pcVar1 = *(code **)(in_RCX + 0xd0);
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801926af;
        uVar6 = (*pcVar1)();
        arg1[0x2a] = 0x19000;
        arg1[0xb] = uVar6;
        *(undefined4 *)(arg1 + 0x30) = 0;
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801926d8;
        uVar6 = func_0x000180229130(0x180197da0, 0x180197d50);
        *(undefined8 *)((int64_t)&arg_30h + iVar4 + iVar3) = 0x180195290;
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192701;
        iVar5 = func_0x000180229290(uVar6, 0x1801952b0, 0x180195290, 0x1801952b0);
        arg1[6] = iVar5;
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019270f;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
            goto code_r0x00018019263b;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019271e;
        iVar5 = func_0x00018021f3d0();
        arg1[5] = iVar5;
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019272c;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
code_r0x000180192731:
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192744;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
        } else {
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192759;
            iVar5 = func_0x00018023b2a0(uVar9, iVar8);
            arg1[0x3a] = iVar5;
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019276a;
                fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192782;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
            } else {
                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192794;
                iVar2 = func_0x0001801a03c0(arg1);
                if (iVar2 == 0) {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019279d;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                } else {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801927c7;
                    iVar2 = func_0x0001801a8bd0(arg1);
                    if (iVar2 == 0) {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801927d0;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                    } else {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801927df;
                        iVar2 = func_0x0001801a8c20(arg1);
                        if (iVar2 == 0) {
                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801927e8;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                        } else {
                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801927f7;
                            iVar2 = func_0x0001801a94a0(arg1);
                            if (iVar2 == 0) {
                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192800;
                                fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                            } else {
                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019280c;
                                uVar6 = func_0x00018019e0b0();
                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192817;
                                iVar2 = func_0x00018019e150(arg1, uVar6);
                                if (iVar2 == 0) {
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192820;
                                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                } else {
                                    iVar5 = arg1[0xd0];
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019283a;
                                    iVar5 = func_0x0001801a2190(iVar5 + 9);
                                    arg1[0x2b] = iVar5;
                                    if (iVar5 != 0) {
                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019285d;
                                        uVar7 = func_0x00018019e0a0();
                                        uVar6 = arg1[4];
                                        *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3) = iVar5;
                                        *(undefined8 *)((int64_t)&arg_30h + iVar4 + iVar3) = uVar7;
                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019287b;
                                        iVar5 = func_0x00018019f670(arg1, uVar6, arg1 + 2, arg1 + 3);
                                        if (iVar5 != 0) {
                                            uVar6 = arg1[2];
                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019288d;
                                            iVar2 = fcn.180222010(uVar6);
                                            if (0 < iVar2) {
                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019289a;
                                                iVar5 = func_0x000180234050();
                                                arg1[0x38] = iVar5;
                                                if (iVar5 == 0) {
                                                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801928ab;
                                                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                                    goto code_r0x000180192731;
                                                }
                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801928c5;
                                                uVar6 = func_0x000180197550(uVar9, 4, iVar8);
                                                arg1[0x20] = uVar6;
                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801928dc;
                                                uVar6 = func_0x000180197550(uVar9, 0x40, iVar8);
                                                arg1[0x21] = uVar6;
                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801928e8;
                                                iVar8 = func_0x000180221f20();
                                                arg1[0x25] = iVar8;
                                                if (iVar8 == 0) {
                                                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801928f9;
                                                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                                } else {
                                                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192908;
                                                    iVar8 = func_0x000180221f20();
                                                    arg1[0x26] = iVar8;
                                                    if (iVar8 == 0) {
                                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                             0x180192919;
                                                        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                      *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                                    } else {
                                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                             0x180192937;
                                                        iVar2 = func_0x000180224430(1, arg1, arg1 + 0x1e);
                                                        if (iVar2 != 0) {
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192961;
                                                            iVar8 = func_0x0001802253e0(0x40, 0x1804a94a0, 0x1054);
                                                            arg1[0x4a] = iVar8;
                                                            if (iVar8 == 0) goto code_r0x000180192b56;
                                                            if ((*(uint8_t *)(*(int64_t *)(in_RCX + 0xd8) + 0x50) & 8)
                                                                == 0) {
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192983;
                                                                uVar6 = func_0x00018019e120();
                                                                arg1[0x23] = uVar6;
                                                            }
                                                            arg1[0x3e] = 0x4000;
                                                            arg1[0x3d] = 0x4000;
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x1801929b8;
                                                            iVar2 = func_0x00018021b9c0(uVar9, arg1 + 0x48, 0x10, 0);
                                                            if (iVar2 < 1) {
code_r0x0001801929f8:
                                                                arg1[0x27] = arg1[0x27] | 0x4000;
                                                            } else {
                                                                uVar6 = arg1[0x4a];
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x1801929d4;
                                                                iVar2 = func_0x00018021be60(uVar9, uVar6, 0x20, 0);
                                                                if (iVar2 < 1) goto code_r0x0001801929f8;
                                                                iVar8 = arg1[0x4a];
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x1801929f4;
                                                                iVar2 = func_0x00018021be60(uVar9, iVar8 + 0x20, 0x20, 0
                                                                                           );
                                                                if (iVar2 < 1) goto code_r0x0001801929f8;
                                                            }
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192a1b;
                                                            iVar2 = func_0x00018021be60(uVar9, arg1 + 0x60, 0x20, 0);
                                                            if (iVar2 < 1) {
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192a24;
                                                                fcn.180229480(*(int64_t *)
                                                                               ((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&arg_38h + iVar4 + iVar3));
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192a3c;
                                                                fcn.1802295a0(*(int64_t *)
                                                                               ((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&arg_38h + iVar4 + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&arg_40h + iVar4 + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&arg_48h + iVar4 + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&arg_60h + iVar4 + iVar3));
                                                                goto code_r0x000180192b49;
                                                            }
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192a4e;
                                                            iVar2 = func_0x0001801bd290(arg1);
                                                            if (iVar2 == 0) {
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192a57;
                                                                fcn.180229480(*(int64_t *)
                                                                               ((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&arg_38h + iVar4 + iVar3));
                                                                goto code_r0x0001801927a2;
                                                            }
                                                            arg1[0x27] = arg1[0x27] | 0x120000;
                                                            *(undefined4 *)(arg1 + 0x4f) = 0xffffffff;
                                                            *(undefined4 *)(arg1 + 0x7e) = 0;
                                                            *(undefined4 *)((int64_t)arg1 + 0x3f4) = 0x4000;
                                                            arg1[0x86] = 2;
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192a97;
                                                            iVar8 = func_0x00018019b1e0();
                                                            if (in_RCX == iVar8) {
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192aa1;
                                                                iVar8 = func_0x0001801bf8e0();
                                                                arg1[0xd9] = iVar8;
                                                                if (iVar8 == 0) goto code_r0x000180192b56;
                                                            }
                                                            arg1[0xd8] = 0;
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192abd;
                                                            iVar8 = func_0x00018019b1e0();
                                                            if (in_RCX == iVar8) {
code_r0x000180192ad6:
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192adb;
                                                                iVar8 = func_0x00018019b1f0();
                                                                uVar9 = 0x12;
                                                                if (in_RCX == iVar8) {
                                                                    uVar9 = 0xe;
                                                                }
                                                                arg1[0xd8] = uVar9;
                                                            } else {
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192ac7;
                                                                iVar8 = func_0x00018019b1f0();
                                                                if (in_RCX == iVar8) goto code_r0x000180192ad6;
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192ad1;
                                                                iVar8 = func_0x00018019b200();
                                                                if (in_RCX == iVar8) goto code_r0x000180192ad6;
                                                            }
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192afa;
                                                            iVar2 = func_0x0001801bc510(arg1);
                                                            if (iVar2 != 0) {
                                                                return arg1;
                                                            }
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192b03;
                                                            fcn.180229480(*(int64_t *)
                                                                           ((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&arg_38h + iVar4 + iVar3));
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192b1b;
                                                            fcn.1802295a0(*(int64_t *)
                                                                           ((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&arg_38h + iVar4 + iVar3), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&arg_40h + iVar4 + iVar3), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&arg_48h + iVar4 + iVar3), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&arg_60h + iVar4 + iVar3));
                                                            goto code_r0x000180192b49;
                                                        }
                                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                             0x180192940;
                                                        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                      *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                                    }
                                                }
                                                goto code_r0x00018019263b;
                                            }
                                        }
                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192b2c;
                                        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                      *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192b44;
                                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                      *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                                                      *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                                                      *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                                                      *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
                                        goto code_r0x000180192b49;
                                    }
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019284e;
                                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                }
                            }
                        }
                    }
                }
code_r0x0001801927a2:
                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801927b5;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
            }
        }
    }
code_r0x000180192b49:
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192b56;
    fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
code_r0x000180192b56:
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192b5e;
    fcn.180191f00((int64_t)arg1, *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                  *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3));
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_180192540
// Address: 0x180192540
// Size: 101 bytes
// ============================================================
undefined8 *
fcn.180192520(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_60h, int64_t arg_68h,
             int64_t arg_70h, int64_t arg_78h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 *arg1;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t in_RCX;
    undefined8 uVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 auStackX_8 [4];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar8 = 0;
    uVar9 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + 0x18) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + 8) = unaff_R12;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3) = 0x180192558;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    arg1 = (undefined8 *)0x0;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192574;
        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019258c;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019259e;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
        return (undefined8 *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar4 + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_68h + iVar4 + iVar3) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801925bb;
    iVar2 = func_0x00018019a3b0(0x200000, 0);
    if (iVar2 == 0) {
        return (undefined8 *)0x0;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801925c8;
    iVar2 = func_0x0001801a1090();
    if (iVar2 < 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801925d1;
        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801925e9;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
        goto code_r0x000180192b49;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019260a;
    arg1 = (undefined8 *)func_0x000180224d60(0x6d8, 0x1804a94a0, 0xfd2);
    if (arg1 == (undefined8 *)0x0) {
        return (undefined8 *)0x0;
    }
    *(undefined4 *)((int64_t)arg1 + 0xa4) = 1;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192625;
    iVar5 = func_0x000180222800();
    arg1[0x7c] = iVar5;
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192636;
        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
code_r0x00018019263b:
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019264e;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
    } else {
        *arg1 = uVar9;
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192675;
            iVar5 = func_0x0001802231e0(iVar8, 0x1804a94a0, 0xfec);
            arg1[0x8c] = iVar5;
            if (iVar5 == 0) goto code_r0x000180192b56;
        }
        arg1[1] = in_RCX;
        *(undefined8 *)((int64_t)arg1 + 0x144) = 0;
        *(undefined4 *)(arg1 + 0x28) = 4;
        *(undefined4 *)(arg1 + 10) = 2;
        arg1[7] = 0x5000;
        pcVar1 = *(code **)(in_RCX + 0xd0);
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801926af;
        uVar6 = (*pcVar1)();
        arg1[0x2a] = 0x19000;
        arg1[0xb] = uVar6;
        *(undefined4 *)(arg1 + 0x30) = 0;
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801926d8;
        uVar6 = func_0x000180229130(0x180197da0, 0x180197d50);
        *(undefined8 *)((int64_t)&arg_30h + iVar4 + iVar3) = 0x180195290;
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192701;
        iVar5 = func_0x000180229290(uVar6, 0x1801952b0, 0x180195290, 0x1801952b0);
        arg1[6] = iVar5;
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019270f;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
            goto code_r0x00018019263b;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019271e;
        iVar5 = func_0x00018021f3d0();
        arg1[5] = iVar5;
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019272c;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
code_r0x000180192731:
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192744;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
        } else {
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192759;
            iVar5 = func_0x00018023b2a0(uVar9, iVar8);
            arg1[0x3a] = iVar5;
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019276a;
                fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192782;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
            } else {
                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192794;
                iVar2 = func_0x0001801a03c0(arg1);
                if (iVar2 == 0) {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019279d;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                } else {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801927c7;
                    iVar2 = func_0x0001801a8bd0(arg1);
                    if (iVar2 == 0) {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801927d0;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                    } else {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801927df;
                        iVar2 = func_0x0001801a8c20(arg1);
                        if (iVar2 == 0) {
                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801927e8;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                        } else {
                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801927f7;
                            iVar2 = func_0x0001801a94a0(arg1);
                            if (iVar2 == 0) {
                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192800;
                                fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                            } else {
                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019280c;
                                uVar6 = func_0x00018019e0b0();
                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192817;
                                iVar2 = func_0x00018019e150(arg1, uVar6);
                                if (iVar2 == 0) {
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192820;
                                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                } else {
                                    iVar5 = arg1[0xd0];
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019283a;
                                    iVar5 = func_0x0001801a2190(iVar5 + 9);
                                    arg1[0x2b] = iVar5;
                                    if (iVar5 != 0) {
                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019285d;
                                        uVar7 = func_0x00018019e0a0();
                                        uVar6 = arg1[4];
                                        *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3) = iVar5;
                                        *(undefined8 *)((int64_t)&arg_30h + iVar4 + iVar3) = uVar7;
                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019287b;
                                        iVar5 = func_0x00018019f670(arg1, uVar6, arg1 + 2, arg1 + 3);
                                        if (iVar5 != 0) {
                                            uVar6 = arg1[2];
                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019288d;
                                            iVar2 = fcn.180222010(uVar6);
                                            if (0 < iVar2) {
                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019289a;
                                                iVar5 = func_0x000180234050();
                                                arg1[0x38] = iVar5;
                                                if (iVar5 == 0) {
                                                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801928ab;
                                                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                                    goto code_r0x000180192731;
                                                }
                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801928c5;
                                                uVar6 = func_0x000180197550(uVar9, 4, iVar8);
                                                arg1[0x20] = uVar6;
                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801928dc;
                                                uVar6 = func_0x000180197550(uVar9, 0x40, iVar8);
                                                arg1[0x21] = uVar6;
                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801928e8;
                                                iVar8 = func_0x000180221f20();
                                                arg1[0x25] = iVar8;
                                                if (iVar8 == 0) {
                                                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801928f9;
                                                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                                } else {
                                                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192908;
                                                    iVar8 = func_0x000180221f20();
                                                    arg1[0x26] = iVar8;
                                                    if (iVar8 == 0) {
                                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                             0x180192919;
                                                        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                      *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                                    } else {
                                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                             0x180192937;
                                                        iVar2 = func_0x000180224430(1, arg1, arg1 + 0x1e);
                                                        if (iVar2 != 0) {
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192961;
                                                            iVar8 = func_0x0001802253e0(0x40, 0x1804a94a0, 0x1054);
                                                            arg1[0x4a] = iVar8;
                                                            if (iVar8 == 0) goto code_r0x000180192b56;
                                                            if ((*(uint8_t *)(*(int64_t *)(in_RCX + 0xd8) + 0x50) & 8)
                                                                == 0) {
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192983;
                                                                uVar6 = func_0x00018019e120();
                                                                arg1[0x23] = uVar6;
                                                            }
                                                            arg1[0x3e] = 0x4000;
                                                            arg1[0x3d] = 0x4000;
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x1801929b8;
                                                            iVar2 = func_0x00018021b9c0(uVar9, arg1 + 0x48, 0x10, 0);
                                                            if (iVar2 < 1) {
code_r0x0001801929f8:
                                                                arg1[0x27] = arg1[0x27] | 0x4000;
                                                            } else {
                                                                uVar6 = arg1[0x4a];
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x1801929d4;
                                                                iVar2 = func_0x00018021be60(uVar9, uVar6, 0x20, 0);
                                                                if (iVar2 < 1) goto code_r0x0001801929f8;
                                                                iVar8 = arg1[0x4a];
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x1801929f4;
                                                                iVar2 = func_0x00018021be60(uVar9, iVar8 + 0x20, 0x20, 0
                                                                                           );
                                                                if (iVar2 < 1) goto code_r0x0001801929f8;
                                                            }
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192a1b;
                                                            iVar2 = func_0x00018021be60(uVar9, arg1 + 0x60, 0x20, 0);
                                                            if (iVar2 < 1) {
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192a24;
                                                                fcn.180229480(*(int64_t *)
                                                                               ((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&arg_38h + iVar4 + iVar3));
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192a3c;
                                                                fcn.1802295a0(*(int64_t *)
                                                                               ((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&arg_38h + iVar4 + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&arg_40h + iVar4 + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&arg_48h + iVar4 + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&arg_60h + iVar4 + iVar3));
                                                                goto code_r0x000180192b49;
                                                            }
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192a4e;
                                                            iVar2 = func_0x0001801bd290(arg1);
                                                            if (iVar2 == 0) {
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192a57;
                                                                fcn.180229480(*(int64_t *)
                                                                               ((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&arg_38h + iVar4 + iVar3));
                                                                goto code_r0x0001801927a2;
                                                            }
                                                            arg1[0x27] = arg1[0x27] | 0x120000;
                                                            *(undefined4 *)(arg1 + 0x4f) = 0xffffffff;
                                                            *(undefined4 *)(arg1 + 0x7e) = 0;
                                                            *(undefined4 *)((int64_t)arg1 + 0x3f4) = 0x4000;
                                                            arg1[0x86] = 2;
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192a97;
                                                            iVar8 = func_0x00018019b1e0();
                                                            if (in_RCX == iVar8) {
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192aa1;
                                                                iVar8 = func_0x0001801bf8e0();
                                                                arg1[0xd9] = iVar8;
                                                                if (iVar8 == 0) goto code_r0x000180192b56;
                                                            }
                                                            arg1[0xd8] = 0;
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192abd;
                                                            iVar8 = func_0x00018019b1e0();
                                                            if (in_RCX == iVar8) {
code_r0x000180192ad6:
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192adb;
                                                                iVar8 = func_0x00018019b1f0();
                                                                uVar9 = 0x12;
                                                                if (in_RCX == iVar8) {
                                                                    uVar9 = 0xe;
                                                                }
                                                                arg1[0xd8] = uVar9;
                                                            } else {
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192ac7;
                                                                iVar8 = func_0x00018019b1f0();
                                                                if (in_RCX == iVar8) goto code_r0x000180192ad6;
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192ad1;
                                                                iVar8 = func_0x00018019b200();
                                                                if (in_RCX == iVar8) goto code_r0x000180192ad6;
                                                            }
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192afa;
                                                            iVar2 = func_0x0001801bc510(arg1);
                                                            if (iVar2 != 0) {
                                                                return arg1;
                                                            }
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192b03;
                                                            fcn.180229480(*(int64_t *)
                                                                           ((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&arg_38h + iVar4 + iVar3));
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192b1b;
                                                            fcn.1802295a0(*(int64_t *)
                                                                           ((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&arg_38h + iVar4 + iVar3), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&arg_40h + iVar4 + iVar3), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&arg_48h + iVar4 + iVar3), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&arg_60h + iVar4 + iVar3));
                                                            goto code_r0x000180192b49;
                                                        }
                                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                             0x180192940;
                                                        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                      *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                                    }
                                                }
                                                goto code_r0x00018019263b;
                                            }
                                        }
                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192b2c;
                                        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                      *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192b44;
                                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                      *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                                                      *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                                                      *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                                                      *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
                                        goto code_r0x000180192b49;
                                    }
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019284e;
                                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                }
                            }
                        }
                    }
                }
code_r0x0001801927a2:
                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801927b5;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
            }
        }
    }
code_r0x000180192b49:
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192b56;
    fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
code_r0x000180192b56:
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192b5e;
    fcn.180191f00((int64_t)arg1, *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                  *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3));
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_1801925a5
// Address: 0x1801925a5
// Size: 1477 bytes
// ============================================================
undefined8 *
fcn.180192520(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_60h, int64_t arg_68h,
             int64_t arg_70h, int64_t arg_78h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 *arg1;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t in_RCX;
    undefined8 uVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 auStackX_8 [4];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar8 = 0;
    uVar9 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + 0x18) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + 8) = unaff_R12;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3) = 0x180192558;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    arg1 = (undefined8 *)0x0;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192574;
        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019258c;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019259e;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
        return (undefined8 *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar4 + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_68h + iVar4 + iVar3) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801925bb;
    iVar2 = func_0x00018019a3b0(0x200000, 0);
    if (iVar2 == 0) {
        return (undefined8 *)0x0;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801925c8;
    iVar2 = func_0x0001801a1090();
    if (iVar2 < 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801925d1;
        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801925e9;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
        goto code_r0x000180192b49;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019260a;
    arg1 = (undefined8 *)func_0x000180224d60(0x6d8, 0x1804a94a0, 0xfd2);
    if (arg1 == (undefined8 *)0x0) {
        return (undefined8 *)0x0;
    }
    *(undefined4 *)((int64_t)arg1 + 0xa4) = 1;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192625;
    iVar5 = func_0x000180222800();
    arg1[0x7c] = iVar5;
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192636;
        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
code_r0x00018019263b:
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019264e;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
    } else {
        *arg1 = uVar9;
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192675;
            iVar5 = func_0x0001802231e0(iVar8, 0x1804a94a0, 0xfec);
            arg1[0x8c] = iVar5;
            if (iVar5 == 0) goto code_r0x000180192b56;
        }
        arg1[1] = in_RCX;
        *(undefined8 *)((int64_t)arg1 + 0x144) = 0;
        *(undefined4 *)(arg1 + 0x28) = 4;
        *(undefined4 *)(arg1 + 10) = 2;
        arg1[7] = 0x5000;
        pcVar1 = *(code **)(in_RCX + 0xd0);
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801926af;
        uVar6 = (*pcVar1)();
        arg1[0x2a] = 0x19000;
        arg1[0xb] = uVar6;
        *(undefined4 *)(arg1 + 0x30) = 0;
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801926d8;
        uVar6 = func_0x000180229130(0x180197da0, 0x180197d50);
        *(undefined8 *)((int64_t)&arg_30h + iVar4 + iVar3) = 0x180195290;
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192701;
        iVar5 = func_0x000180229290(uVar6, 0x1801952b0, 0x180195290, 0x1801952b0);
        arg1[6] = iVar5;
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019270f;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
            goto code_r0x00018019263b;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019271e;
        iVar5 = func_0x00018021f3d0();
        arg1[5] = iVar5;
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019272c;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
code_r0x000180192731:
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192744;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
        } else {
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192759;
            iVar5 = func_0x00018023b2a0(uVar9, iVar8);
            arg1[0x3a] = iVar5;
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019276a;
                fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192782;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
            } else {
                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192794;
                iVar2 = func_0x0001801a03c0(arg1);
                if (iVar2 == 0) {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019279d;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                } else {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801927c7;
                    iVar2 = func_0x0001801a8bd0(arg1);
                    if (iVar2 == 0) {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801927d0;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                    } else {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801927df;
                        iVar2 = func_0x0001801a8c20(arg1);
                        if (iVar2 == 0) {
                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801927e8;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                        } else {
                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801927f7;
                            iVar2 = func_0x0001801a94a0(arg1);
                            if (iVar2 == 0) {
                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192800;
                                fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                            } else {
                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019280c;
                                uVar6 = func_0x00018019e0b0();
                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192817;
                                iVar2 = func_0x00018019e150(arg1, uVar6);
                                if (iVar2 == 0) {
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192820;
                                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                } else {
                                    iVar5 = arg1[0xd0];
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019283a;
                                    iVar5 = func_0x0001801a2190(iVar5 + 9);
                                    arg1[0x2b] = iVar5;
                                    if (iVar5 != 0) {
                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019285d;
                                        uVar7 = func_0x00018019e0a0();
                                        uVar6 = arg1[4];
                                        *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3) = iVar5;
                                        *(undefined8 *)((int64_t)&arg_30h + iVar4 + iVar3) = uVar7;
                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019287b;
                                        iVar5 = func_0x00018019f670(arg1, uVar6, arg1 + 2, arg1 + 3);
                                        if (iVar5 != 0) {
                                            uVar6 = arg1[2];
                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019288d;
                                            iVar2 = fcn.180222010(uVar6);
                                            if (0 < iVar2) {
                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019289a;
                                                iVar5 = func_0x000180234050();
                                                arg1[0x38] = iVar5;
                                                if (iVar5 == 0) {
                                                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801928ab;
                                                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                                    goto code_r0x000180192731;
                                                }
                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801928c5;
                                                uVar6 = func_0x000180197550(uVar9, 4, iVar8);
                                                arg1[0x20] = uVar6;
                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801928dc;
                                                uVar6 = func_0x000180197550(uVar9, 0x40, iVar8);
                                                arg1[0x21] = uVar6;
                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801928e8;
                                                iVar8 = func_0x000180221f20();
                                                arg1[0x25] = iVar8;
                                                if (iVar8 == 0) {
                                                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801928f9;
                                                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                                } else {
                                                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192908;
                                                    iVar8 = func_0x000180221f20();
                                                    arg1[0x26] = iVar8;
                                                    if (iVar8 == 0) {
                                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                             0x180192919;
                                                        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                      *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                                    } else {
                                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                             0x180192937;
                                                        iVar2 = func_0x000180224430(1, arg1, arg1 + 0x1e);
                                                        if (iVar2 != 0) {
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192961;
                                                            iVar8 = func_0x0001802253e0(0x40, 0x1804a94a0, 0x1054);
                                                            arg1[0x4a] = iVar8;
                                                            if (iVar8 == 0) goto code_r0x000180192b56;
                                                            if ((*(uint8_t *)(*(int64_t *)(in_RCX + 0xd8) + 0x50) & 8)
                                                                == 0) {
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192983;
                                                                uVar6 = func_0x00018019e120();
                                                                arg1[0x23] = uVar6;
                                                            }
                                                            arg1[0x3e] = 0x4000;
                                                            arg1[0x3d] = 0x4000;
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x1801929b8;
                                                            iVar2 = func_0x00018021b9c0(uVar9, arg1 + 0x48, 0x10, 0);
                                                            if (iVar2 < 1) {
code_r0x0001801929f8:
                                                                arg1[0x27] = arg1[0x27] | 0x4000;
                                                            } else {
                                                                uVar6 = arg1[0x4a];
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x1801929d4;
                                                                iVar2 = func_0x00018021be60(uVar9, uVar6, 0x20, 0);
                                                                if (iVar2 < 1) goto code_r0x0001801929f8;
                                                                iVar8 = arg1[0x4a];
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x1801929f4;
                                                                iVar2 = func_0x00018021be60(uVar9, iVar8 + 0x20, 0x20, 0
                                                                                           );
                                                                if (iVar2 < 1) goto code_r0x0001801929f8;
                                                            }
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192a1b;
                                                            iVar2 = func_0x00018021be60(uVar9, arg1 + 0x60, 0x20, 0);
                                                            if (iVar2 < 1) {
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192a24;
                                                                fcn.180229480(*(int64_t *)
                                                                               ((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&arg_38h + iVar4 + iVar3));
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192a3c;
                                                                fcn.1802295a0(*(int64_t *)
                                                                               ((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&arg_38h + iVar4 + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&arg_40h + iVar4 + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&arg_48h + iVar4 + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&arg_60h + iVar4 + iVar3));
                                                                goto code_r0x000180192b49;
                                                            }
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192a4e;
                                                            iVar2 = func_0x0001801bd290(arg1);
                                                            if (iVar2 == 0) {
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192a57;
                                                                fcn.180229480(*(int64_t *)
                                                                               ((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&arg_38h + iVar4 + iVar3));
                                                                goto code_r0x0001801927a2;
                                                            }
                                                            arg1[0x27] = arg1[0x27] | 0x120000;
                                                            *(undefined4 *)(arg1 + 0x4f) = 0xffffffff;
                                                            *(undefined4 *)(arg1 + 0x7e) = 0;
                                                            *(undefined4 *)((int64_t)arg1 + 0x3f4) = 0x4000;
                                                            arg1[0x86] = 2;
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192a97;
                                                            iVar8 = func_0x00018019b1e0();
                                                            if (in_RCX == iVar8) {
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192aa1;
                                                                iVar8 = func_0x0001801bf8e0();
                                                                arg1[0xd9] = iVar8;
                                                                if (iVar8 == 0) goto code_r0x000180192b56;
                                                            }
                                                            arg1[0xd8] = 0;
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192abd;
                                                            iVar8 = func_0x00018019b1e0();
                                                            if (in_RCX == iVar8) {
code_r0x000180192ad6:
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192adb;
                                                                iVar8 = func_0x00018019b1f0();
                                                                uVar9 = 0x12;
                                                                if (in_RCX == iVar8) {
                                                                    uVar9 = 0xe;
                                                                }
                                                                arg1[0xd8] = uVar9;
                                                            } else {
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192ac7;
                                                                iVar8 = func_0x00018019b1f0();
                                                                if (in_RCX == iVar8) goto code_r0x000180192ad6;
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192ad1;
                                                                iVar8 = func_0x00018019b200();
                                                                if (in_RCX == iVar8) goto code_r0x000180192ad6;
                                                            }
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192afa;
                                                            iVar2 = func_0x0001801bc510(arg1);
                                                            if (iVar2 != 0) {
                                                                return arg1;
                                                            }
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192b03;
                                                            fcn.180229480(*(int64_t *)
                                                                           ((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&arg_38h + iVar4 + iVar3));
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192b1b;
                                                            fcn.1802295a0(*(int64_t *)
                                                                           ((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&arg_38h + iVar4 + iVar3), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&arg_40h + iVar4 + iVar3), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&arg_48h + iVar4 + iVar3), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&arg_60h + iVar4 + iVar3));
                                                            goto code_r0x000180192b49;
                                                        }
                                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                             0x180192940;
                                                        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                      *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                                    }
                                                }
                                                goto code_r0x00018019263b;
                                            }
                                        }
                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192b2c;
                                        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                      *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192b44;
                                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                      *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                                                      *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                                                      *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                                                      *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
                                        goto code_r0x000180192b49;
                                    }
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019284e;
                                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                }
                            }
                        }
                    }
                }
code_r0x0001801927a2:
                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801927b5;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
            }
        }
    }
code_r0x000180192b49:
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192b56;
    fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
code_r0x000180192b56:
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192b5e;
    fcn.180191f00((int64_t)arg1, *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                  *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3));
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_180192b6a
// Address: 0x180192b6a
// Size: 19 bytes
// ============================================================
undefined8 *
fcn.180192520(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_60h, int64_t arg_68h,
             int64_t arg_70h, int64_t arg_78h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 *arg1;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t in_RCX;
    undefined8 uVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 auStackX_8 [4];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar8 = 0;
    uVar9 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + 0x18) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + 8) = unaff_R12;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3) = 0x180192558;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    arg1 = (undefined8 *)0x0;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192574;
        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019258c;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019259e;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
        return (undefined8 *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar4 + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_68h + iVar4 + iVar3) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801925bb;
    iVar2 = func_0x00018019a3b0(0x200000, 0);
    if (iVar2 == 0) {
        return (undefined8 *)0x0;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801925c8;
    iVar2 = func_0x0001801a1090();
    if (iVar2 < 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801925d1;
        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801925e9;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
        goto code_r0x000180192b49;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019260a;
    arg1 = (undefined8 *)func_0x000180224d60(0x6d8, 0x1804a94a0, 0xfd2);
    if (arg1 == (undefined8 *)0x0) {
        return (undefined8 *)0x0;
    }
    *(undefined4 *)((int64_t)arg1 + 0xa4) = 1;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192625;
    iVar5 = func_0x000180222800();
    arg1[0x7c] = iVar5;
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192636;
        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
code_r0x00018019263b:
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019264e;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
    } else {
        *arg1 = uVar9;
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192675;
            iVar5 = func_0x0001802231e0(iVar8, 0x1804a94a0, 0xfec);
            arg1[0x8c] = iVar5;
            if (iVar5 == 0) goto code_r0x000180192b56;
        }
        arg1[1] = in_RCX;
        *(undefined8 *)((int64_t)arg1 + 0x144) = 0;
        *(undefined4 *)(arg1 + 0x28) = 4;
        *(undefined4 *)(arg1 + 10) = 2;
        arg1[7] = 0x5000;
        pcVar1 = *(code **)(in_RCX + 0xd0);
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801926af;
        uVar6 = (*pcVar1)();
        arg1[0x2a] = 0x19000;
        arg1[0xb] = uVar6;
        *(undefined4 *)(arg1 + 0x30) = 0;
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801926d8;
        uVar6 = func_0x000180229130(0x180197da0, 0x180197d50);
        *(undefined8 *)((int64_t)&arg_30h + iVar4 + iVar3) = 0x180195290;
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192701;
        iVar5 = func_0x000180229290(uVar6, 0x1801952b0, 0x180195290, 0x1801952b0);
        arg1[6] = iVar5;
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019270f;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
            goto code_r0x00018019263b;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019271e;
        iVar5 = func_0x00018021f3d0();
        arg1[5] = iVar5;
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019272c;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
code_r0x000180192731:
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192744;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
        } else {
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192759;
            iVar5 = func_0x00018023b2a0(uVar9, iVar8);
            arg1[0x3a] = iVar5;
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019276a;
                fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192782;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
            } else {
                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192794;
                iVar2 = func_0x0001801a03c0(arg1);
                if (iVar2 == 0) {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019279d;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                } else {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801927c7;
                    iVar2 = func_0x0001801a8bd0(arg1);
                    if (iVar2 == 0) {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801927d0;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                    } else {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801927df;
                        iVar2 = func_0x0001801a8c20(arg1);
                        if (iVar2 == 0) {
                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801927e8;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                        } else {
                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801927f7;
                            iVar2 = func_0x0001801a94a0(arg1);
                            if (iVar2 == 0) {
                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192800;
                                fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                            } else {
                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019280c;
                                uVar6 = func_0x00018019e0b0();
                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192817;
                                iVar2 = func_0x00018019e150(arg1, uVar6);
                                if (iVar2 == 0) {
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192820;
                                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                } else {
                                    iVar5 = arg1[0xd0];
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019283a;
                                    iVar5 = func_0x0001801a2190(iVar5 + 9);
                                    arg1[0x2b] = iVar5;
                                    if (iVar5 != 0) {
                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019285d;
                                        uVar7 = func_0x00018019e0a0();
                                        uVar6 = arg1[4];
                                        *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3) = iVar5;
                                        *(undefined8 *)((int64_t)&arg_30h + iVar4 + iVar3) = uVar7;
                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019287b;
                                        iVar5 = func_0x00018019f670(arg1, uVar6, arg1 + 2, arg1 + 3);
                                        if (iVar5 != 0) {
                                            uVar6 = arg1[2];
                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019288d;
                                            iVar2 = fcn.180222010(uVar6);
                                            if (0 < iVar2) {
                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019289a;
                                                iVar5 = func_0x000180234050();
                                                arg1[0x38] = iVar5;
                                                if (iVar5 == 0) {
                                                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801928ab;
                                                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                                    goto code_r0x000180192731;
                                                }
                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801928c5;
                                                uVar6 = func_0x000180197550(uVar9, 4, iVar8);
                                                arg1[0x20] = uVar6;
                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801928dc;
                                                uVar6 = func_0x000180197550(uVar9, 0x40, iVar8);
                                                arg1[0x21] = uVar6;
                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801928e8;
                                                iVar8 = func_0x000180221f20();
                                                arg1[0x25] = iVar8;
                                                if (iVar8 == 0) {
                                                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801928f9;
                                                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                                } else {
                                                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192908;
                                                    iVar8 = func_0x000180221f20();
                                                    arg1[0x26] = iVar8;
                                                    if (iVar8 == 0) {
                                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                             0x180192919;
                                                        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                      *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                                    } else {
                                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                             0x180192937;
                                                        iVar2 = func_0x000180224430(1, arg1, arg1 + 0x1e);
                                                        if (iVar2 != 0) {
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192961;
                                                            iVar8 = func_0x0001802253e0(0x40, 0x1804a94a0, 0x1054);
                                                            arg1[0x4a] = iVar8;
                                                            if (iVar8 == 0) goto code_r0x000180192b56;
                                                            if ((*(uint8_t *)(*(int64_t *)(in_RCX + 0xd8) + 0x50) & 8)
                                                                == 0) {
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192983;
                                                                uVar6 = func_0x00018019e120();
                                                                arg1[0x23] = uVar6;
                                                            }
                                                            arg1[0x3e] = 0x4000;
                                                            arg1[0x3d] = 0x4000;
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x1801929b8;
                                                            iVar2 = func_0x00018021b9c0(uVar9, arg1 + 0x48, 0x10, 0);
                                                            if (iVar2 < 1) {
code_r0x0001801929f8:
                                                                arg1[0x27] = arg1[0x27] | 0x4000;
                                                            } else {
                                                                uVar6 = arg1[0x4a];
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x1801929d4;
                                                                iVar2 = func_0x00018021be60(uVar9, uVar6, 0x20, 0);
                                                                if (iVar2 < 1) goto code_r0x0001801929f8;
                                                                iVar8 = arg1[0x4a];
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x1801929f4;
                                                                iVar2 = func_0x00018021be60(uVar9, iVar8 + 0x20, 0x20, 0
                                                                                           );
                                                                if (iVar2 < 1) goto code_r0x0001801929f8;
                                                            }
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192a1b;
                                                            iVar2 = func_0x00018021be60(uVar9, arg1 + 0x60, 0x20, 0);
                                                            if (iVar2 < 1) {
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192a24;
                                                                fcn.180229480(*(int64_t *)
                                                                               ((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&arg_38h + iVar4 + iVar3));
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192a3c;
                                                                fcn.1802295a0(*(int64_t *)
                                                                               ((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&arg_38h + iVar4 + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&arg_40h + iVar4 + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&arg_48h + iVar4 + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&arg_60h + iVar4 + iVar3));
                                                                goto code_r0x000180192b49;
                                                            }
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192a4e;
                                                            iVar2 = func_0x0001801bd290(arg1);
                                                            if (iVar2 == 0) {
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192a57;
                                                                fcn.180229480(*(int64_t *)
                                                                               ((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&arg_38h + iVar4 + iVar3));
                                                                goto code_r0x0001801927a2;
                                                            }
                                                            arg1[0x27] = arg1[0x27] | 0x120000;
                                                            *(undefined4 *)(arg1 + 0x4f) = 0xffffffff;
                                                            *(undefined4 *)(arg1 + 0x7e) = 0;
                                                            *(undefined4 *)((int64_t)arg1 + 0x3f4) = 0x4000;
                                                            arg1[0x86] = 2;
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192a97;
                                                            iVar8 = func_0x00018019b1e0();
                                                            if (in_RCX == iVar8) {
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192aa1;
                                                                iVar8 = func_0x0001801bf8e0();
                                                                arg1[0xd9] = iVar8;
                                                                if (iVar8 == 0) goto code_r0x000180192b56;
                                                            }
                                                            arg1[0xd8] = 0;
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192abd;
                                                            iVar8 = func_0x00018019b1e0();
                                                            if (in_RCX == iVar8) {
code_r0x000180192ad6:
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192adb;
                                                                iVar8 = func_0x00018019b1f0();
                                                                uVar9 = 0x12;
                                                                if (in_RCX == iVar8) {
                                                                    uVar9 = 0xe;
                                                                }
                                                                arg1[0xd8] = uVar9;
                                                            } else {
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192ac7;
                                                                iVar8 = func_0x00018019b1f0();
                                                                if (in_RCX == iVar8) goto code_r0x000180192ad6;
                                                                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                     0x180192ad1;
                                                                iVar8 = func_0x00018019b200();
                                                                if (in_RCX == iVar8) goto code_r0x000180192ad6;
                                                            }
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192afa;
                                                            iVar2 = func_0x0001801bc510(arg1);
                                                            if (iVar2 != 0) {
                                                                return arg1;
                                                            }
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192b03;
                                                            fcn.180229480(*(int64_t *)
                                                                           ((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&arg_38h + iVar4 + iVar3));
                                                            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                                 0x180192b1b;
                                                            fcn.1802295a0(*(int64_t *)
                                                                           ((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&arg_38h + iVar4 + iVar3), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&arg_40h + iVar4 + iVar3), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&arg_48h + iVar4 + iVar3), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&arg_60h + iVar4 + iVar3));
                                                            goto code_r0x000180192b49;
                                                        }
                                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) =
                                                             0x180192940;
                                                        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                                      *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                                    }
                                                }
                                                goto code_r0x00018019263b;
                                            }
                                        }
                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192b2c;
                                        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                      *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192b44;
                                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                      *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                                                      *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                                                      *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                                                      *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
                                        goto code_r0x000180192b49;
                                    }
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18019284e;
                                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                                }
                            }
                        }
                    }
                }
code_r0x0001801927a2:
                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1801927b5;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
            }
        }
    }
code_r0x000180192b49:
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192b56;
    fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
code_r0x000180192b56:
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180192b5e;
    fcn.180191f00((int64_t)arg1, *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                  *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                  *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3));
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_180192b80
// Address: 0x180192b80
// Size: 164 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180192b80(int64_t arg_38h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180192b90;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180192ba1;
    fcn.18022fb60(in_RDX);
    *(undefined8 *)((int64_t)&iStackX_20 + iVar3 + -8) = in_RDX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180192bb9;
    iVar2 = fcn.1801a25e0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)(&stack0x00000060 + iVar3));
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180192bc2;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180192bda;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180192bec;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x158) + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180192c09;
    fcn.18022ecc0(uVar1);
    *(undefined8 *)(*(int64_t *)(in_RCX + 0x158) + 8) = in_RDX;
    return 1;
}

// ============================================================
// Function: FUN_180192c30
// Address: 0x180192c30
// Size: 39 bytes
// ============================================================
undefined8 fcn.180192c30(int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint32_t uVar5;
    uint64_t in_R8;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180192c3c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar5 = (uint32_t)in_R8;
    if ((uVar5 != 0) && (in_RDX != 0)) {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
        if (1 < uVar5) {
            uVar2 = 0;
            do {
                if (*(uint8_t *)((uint64_t)uVar2 + in_RDX) == 0) {
                    return 1;
                }
                uVar2 = uVar2 + 1 + (uint32_t)*(uint8_t *)((uint64_t)uVar2 + in_RDX);
            } while (uVar2 < uVar5);
            if (uVar2 == uVar5) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180192ca0;
                iVar4 = fcn.180223170(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
                if (iVar4 != 0) {
                    uVar1 = *(undefined8 *)(in_RCX + 0x2d0);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180192cc1;
                    fcn.180224990(uVar1, 0x1804a94a0, 0xeba);
                    *(int64_t *)(in_RCX + 0x2d0) = iVar4;
                    *(uint64_t *)(in_RCX + 0x2d8) = in_R8 & 0xffffffff;
                    return 0;
                }
            }
        }
        return 1;
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x2d0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180192d0f;
    fcn.180224990(uVar1, 0x1804a94a0, 0xeae);
    *(undefined8 *)(in_RCX + 0x2d0) = 0;
    *(undefined8 *)(in_RCX + 0x2d8) = 0;
    return 0;
}

// ============================================================
// Function: FUN_180192c57
// Address: 0x180192c57
// Size: 138 bytes
// ============================================================
undefined8 fcn.180192c30(int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint32_t uVar5;
    uint64_t in_R8;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180192c3c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar5 = (uint32_t)in_R8;
    if ((uVar5 != 0) && (in_RDX != 0)) {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
        if (1 < uVar5) {
            uVar2 = 0;
            do {
                if (*(uint8_t *)((uint64_t)uVar2 + in_RDX) == 0) {
                    return 1;
                }
                uVar2 = uVar2 + 1 + (uint32_t)*(uint8_t *)((uint64_t)uVar2 + in_RDX);
            } while (uVar2 < uVar5);
            if (uVar2 == uVar5) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180192ca0;
                iVar4 = fcn.180223170(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
                if (iVar4 != 0) {
                    uVar1 = *(undefined8 *)(in_RCX + 0x2d0);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180192cc1;
                    fcn.180224990(uVar1, 0x1804a94a0, 0xeba);
                    *(int64_t *)(in_RCX + 0x2d0) = iVar4;
                    *(uint64_t *)(in_RCX + 0x2d8) = in_R8 & 0xffffffff;
                    return 0;
                }
            }
        }
        return 1;
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x2d0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180192d0f;
    fcn.180224990(uVar1, 0x1804a94a0, 0xeae);
    *(undefined8 *)(in_RCX + 0x2d0) = 0;
    *(undefined8 *)(in_RCX + 0x2d8) = 0;
    return 0;
}

// ============================================================
// Function: FUN_180192ce1
// Address: 0x180192ce1
// Size: 21 bytes
// ============================================================
undefined8 fcn.180192c30(int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint32_t uVar5;
    uint64_t in_R8;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180192c3c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar5 = (uint32_t)in_R8;
    if ((uVar5 != 0) && (in_RDX != 0)) {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
        if (1 < uVar5) {
            uVar2 = 0;
            do {
                if (*(uint8_t *)((uint64_t)uVar2 + in_RDX) == 0) {
                    return 1;
                }
                uVar2 = uVar2 + 1 + (uint32_t)*(uint8_t *)((uint64_t)uVar2 + in_RDX);
            } while (uVar2 < uVar5);
            if (uVar2 == uVar5) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180192ca0;
                iVar4 = fcn.180223170(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
                if (iVar4 != 0) {
                    uVar1 = *(undefined8 *)(in_RCX + 0x2d0);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180192cc1;
                    fcn.180224990(uVar1, 0x1804a94a0, 0xeba);
                    *(int64_t *)(in_RCX + 0x2d0) = iVar4;
                    *(uint64_t *)(in_RCX + 0x2d8) = in_R8 & 0xffffffff;
                    return 0;
                }
            }
        }
        return 1;
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x2d0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180192d0f;
    fcn.180224990(uVar1, 0x1804a94a0, 0xeae);
    *(undefined8 *)(in_RCX + 0x2d0) = 0;
    *(undefined8 *)(in_RCX + 0x2d8) = 0;
    return 0;
}

// ============================================================
// Function: FUN_180192cf6
// Address: 0x180192cf6
// Size: 47 bytes
// ============================================================
undefined8 fcn.180192c30(int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint32_t uVar5;
    uint64_t in_R8;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180192c3c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar5 = (uint32_t)in_R8;
    if ((uVar5 != 0) && (in_RDX != 0)) {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
        if (1 < uVar5) {
            uVar2 = 0;
            do {
                if (*(uint8_t *)((uint64_t)uVar2 + in_RDX) == 0) {
                    return 1;
                }
                uVar2 = uVar2 + 1 + (uint32_t)*(uint8_t *)((uint64_t)uVar2 + in_RDX);
            } while (uVar2 < uVar5);
            if (uVar2 == uVar5) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180192ca0;
                iVar4 = fcn.180223170(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
                if (iVar4 != 0) {
                    uVar1 = *(undefined8 *)(in_RCX + 0x2d0);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180192cc1;
                    fcn.180224990(uVar1, 0x1804a94a0, 0xeba);
                    *(int64_t *)(in_RCX + 0x2d0) = iVar4;
                    *(uint64_t *)(in_RCX + 0x2d8) = in_R8 & 0xffffffff;
                    return 0;
                }
            }
        }
        return 1;
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x2d0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180192d0f;
    fcn.180224990(uVar1, 0x1804a94a0, 0xeae);
    *(undefined8 *)(in_RCX + 0x2d0) = 0;
    *(undefined8 *)(in_RCX + 0x2d8) = 0;
    return 0;
}

// ============================================================
// Function: FUN_180192d30
// Address: 0x180192d30
// Size: 172 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_400h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_408h because it doesn't fit into ProtoModel

undefined8 fcn.180192d30(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t in_RCX;
    uint64_t in_RDX;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180192d4a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180192d5b;
    iVar2 = func_0x00018019b1e0();
    if (*(int64_t *)(in_RCX + 8) != iVar2) {
        iVar2 = *(int64_t *)(in_RCX + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180192d6a;
        iVar3 = func_0x00018019b1f0();
        if (iVar2 != iVar3) {
            iVar2 = *(int64_t *)(in_RCX + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180192d78;
            iVar1 = func_0x00018019b200();
            if (iVar2 != iVar1) goto code_r0x000180192d89;
        }
    }
    if (1 < in_RDX) {
        return 0;
    }
    if (1 < in_R8) {
        return 0;
    }
code_r0x000180192d89:
    uVar4 = 0;
    if (((in_RDX == 1) || (uVar4 = in_RDX, in_RDX < 0x4001)) &&
       ((*(uint64_t *)(in_RCX + 0x408) = uVar4, uVar4 = 0, in_R8 == 1 || (uVar4 = in_R8, in_R8 < 0x4001)))) {
        *(uint64_t *)(in_RCX + 0x410) = uVar4;
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180192de0
// Address: 0x180192de0
// Size: 49 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180192de0(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180192df0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180192e02;
    fcn.18021f290(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000048 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1));
    *(undefined8 *)(in_RCX + 0x28) = in_RDX;
    return;
}

// ============================================================
// Function: FUN_180192e20
// Address: 0x180192e20
// Size: 79 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

undefined8 fcn.180192e20(int64_t arg_38h, int64_t arg_40h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t iVar6;
    int32_t iVar7;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180192e30;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&var_20h + iVar3) = *(undefined8 *)(in_RCX + 0x158);
    *(undefined8 *)((int64_t)&var_18h + iVar3) = in_RDX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180192e58;
    iVar4 = fcn.18019f670(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)(&stack0x00000080 + iVar3), *(int64_t *)(&stack0x00000088 + iVar3), 
                          *(int64_t *)(&stack0x00000090 + iVar3), *(int64_t *)(&stack0x00000098 + iVar3), 
                          *(int64_t *)(&stack0x000000a0 + iVar3), *(int64_t *)(&stack0x000000a8 + iVar3));
    if (iVar4 == 0) {
        return 0;
    }
    iVar5 = *(int64_t *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
    pcVar1 = *(code **)(iVar5 + 0xc0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180192e7a;
    iVar2 = (*pcVar1)();
    if (iVar2 < 1) {
        return 1;
    }
    iVar6 = 0;
    iVar7 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180192e8a;
    iVar2 = fcn.180222010(iVar4);
    if (0 < iVar2) {
        do {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180192e9a;
            iVar5 = fcn.180222340(iVar4, iVar7);
            iVar2 = iVar6 + 1;
            if (0x303 < *(int32_t *)(iVar5 + 0x2c)) {
                iVar2 = iVar6;
            }
            iVar6 = iVar2;
            iVar7 = iVar7 + 1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180192eb3;
            iVar2 = fcn.180222010(iVar4);
        } while (iVar7 < iVar2);
        if (iVar6 != 0) {
            return 1;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180192ec0;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180192ed8;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180192eea;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    return 0;
}

