// Chunk 178 - 50 functions

// ============================================================
// Function: FUN_180237470
// Address: 0x180237470
// Size: 29 bytes
// ============================================================
void fcn.180237470(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_60h, int64_t arg_70h, int64_t arg_78h, int64_t arg_90h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    int64_t iVar4;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar5;
    undefined8 uStackX_8;
    undefined8 auStackX_10 [3];
    
    iVar2 = func_0x00018045a350();
    iVar2 = -iVar2;
    iVar5 = 0x1804e2870;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 0x10) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 8) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStackX_8 + iVar2) = 0x18026177e;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_90h + iVar3 + iVar2) = *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_10 + iVar3 + iVar2;
    *(undefined8 *)((int64_t)&arg_70h + iVar3 + iVar2) = 0;
    *(undefined *)((int64_t)&arg_78h + iVar3 + iVar2) = 0;
    iVar4 = (int64_t)&arg_70h + iVar3 + iVar2;
    if (in_RCX != 0) {
        iVar4 = in_RCX;
    }
    if ((iVar4 == 0) || (iVar5 == 0)) {
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x180261804;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x18026181c;
        func_0x0001802295a0(0x1804e6d08, 0x73, 0x1804e6cf0);
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x18026182e;
        func_0x0001802296d0(0xd, 0xc0102, 0);
    } else {
        *(undefined8 *)((int64_t)&arg_60h + iVar3 + iVar2) = 0;
        *(undefined8 *)((int64_t)&arg_58h + iVar3 + iVar2) = 0;
        *(undefined4 *)((int64_t)&arg_50h + iVar3 + iVar2) = 0;
        *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar2) = (int64_t)&arg_78h + iVar3 + iVar2;
        *(undefined *)((int64_t)&arg_40h + iVar3 + iVar2) = 0;
        *(undefined4 *)((int64_t)&arg_38h + iVar3 + iVar2) = 0;
        *(undefined4 *)((int64_t)&arg_30h + iVar3 + iVar2) = 0xffffffff;
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x1802617e9;
        iVar1 = func_0x0001802629a0(iVar4);
        if (iVar1 < 1) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x1802617f8;
            func_0x000180261290(iVar4, iVar5);
        }
    }
    *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x180261841;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_90h + iVar3 + iVar2) ^ (int64_t)auStackX_10 + iVar3 + iVar2);
    return;
}

// ============================================================
// Function: FUN_180237490
// Address: 0x180237490
// Size: 29 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.180237490(int64_t arg_58h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    int64_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined4 uVar6;
    undefined8 unaff_R14;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x1802642ca;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar1 = iVar4 + iVar3 + 0x20;
    uVar6 = 0;
    *(undefined8 *)((int64_t)&arg_58h + iVar4 + iVar3) = in_RCX;
    *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = unaff_RBX;
    *(undefined8 *)(&stack0x00000040 + iVar4 + iVar3) = unaff_RBP;
    *(undefined8 *)(&stack0x00000038 + iVar4 + iVar3 + 0x20 + -0x20) = unaff_RSI;
    *(undefined8 *)(&stack0x00000030 + iVar4 + iVar3) = 0x1802645e2;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_RDX != (int64_t *)0x0) && (*in_RDX == 0)) {
        *(undefined4 *)((int64_t)&arg_58h + iVar3 + iVar1 + -0x20) = uVar6;
        *(undefined8 *)((int64_t)&arg_98h + iVar3 + iVar1 + -0x20) = unaff_RDI;
        *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026461d;
        uVar2 = fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)((int64_t)&arg_88h + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)((int64_t)&arg_90h + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
        if ((int32_t)uVar2 < 1) {
            return (uint64_t)uVar2;
        }
        *(undefined8 *)((int64_t)&arg_a0h + iVar3 + iVar1 + -0x20) = unaff_R14;
        *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026464d;
        iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_58h + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000060 + iVar3 + iVar1 + -0x20));
        if (iVar4 == 0) {
            uVar5 = 0xffffffff;
        } else {
            *(int64_t *)((int64_t)&arg_90h + iVar3 + iVar1 + -0x20) = iVar4;
            *(undefined4 *)((int64_t)&arg_58h + iVar3 + iVar1 + -0x20) = uVar6;
            *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026468d;
            fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)((int64_t)&arg_88h + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)((int64_t)&arg_90h + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
            uVar5 = (uint64_t)uVar2;
            *in_RDX = iVar4;
        }
        return uVar5;
    }
    *(undefined4 *)((int64_t)&arg_58h + iVar3 + iVar1 + -0x20) = uVar6;
    *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x1802646a8;
    uVar5 = fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)((int64_t)&arg_88h + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)((int64_t)&arg_90h + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
    return uVar5;
}

// ============================================================
// Function: FUN_180237500
// Address: 0x180237500
// Size: 144 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint32_t fcn.180237500(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h)
{
    undefined4 *puVar1;
    int64_t iVar2;
    int64_t in_RCX;
    undefined4 *in_RDX;
    undefined4 *in_R8;
    undefined4 *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023751b;
    iVar2 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x180237537;
    func_0x00018023bad0();
    if (in_RDX != (undefined4 *)0x0) {
        *in_RDX = *(undefined4 *)(in_RCX + 0xa8);
    }
    if (in_R8 != (undefined4 *)0x0) {
        *in_R8 = *(undefined4 *)(in_RCX + 0xac);
    }
    if (in_R9 != (undefined4 *)0x0) {
        *in_R9 = *(undefined4 *)(in_RCX + 0xb0);
    }
    puVar1 = *(undefined4 **)((int64_t)&arg_48h + -iVar2);
    if (puVar1 != (undefined4 *)0x0) {
        *puVar1 = *(undefined4 *)(in_RCX + 0xb4);
    }
    return *(uint32_t *)(in_RCX + 0xb4) & 1;
}

// ============================================================
// Function: FUN_180237590
// Address: 0x180237590
// Size: 25 bytes
// ============================================================
int64_t fcn.180237590(int64_t arg_58h, int64_t arg_88h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    undefined8 uStackX_20;
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar4 = *in_RCX;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2) = 0x18025fdea;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (iVar4 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18025fe0c;
    iVar1 = fcn.180260030((int64_t)&arg_58h + iVar3 + iVar2, iVar4, 2);
    if ((iVar1 == 0) || (iVar4 = *(int64_t *)((int64_t)&arg_58h + iVar3 + iVar2), 0xffffffff < iVar4 + 0x80000000U)) {
        iVar4 = 0xffffffff;
    }
    return iVar4;
}

// ============================================================
// Function: FUN_1802375b0
// Address: 0x1802375b0
// Size: 62 bytes
// ============================================================
undefined8 fcn.1802375b0(int64_t param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802375bc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (param_1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802375d0;
        iVar1 = fcn.180234ab0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2));
        if (iVar1 != 0) {
            *(undefined4 *)(param_1 + 0x7c) = 1;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180237610
// Address: 0x180237610
// Size: 61 bytes
// ============================================================
undefined8 fcn.180237610(int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_90h)
{
    code *pcVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t in_RCX;
    undefined8 *puVar11;
    undefined8 *puVar12;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023761c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar7 = *(undefined8 *)(in_RCX + 0x50);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023762b;
    iVar5 = func_0x000180235930(uVar7);
    iVar8 = in_RCX + 0x90;
    puVar12 = (undefined8 *)(in_RCX + 0x80);
    puVar11 = (undefined8 *)(in_RCX + 0xa8);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = *(undefined8 *)(&stack0x00000018 + iVar4);
    *(undefined8 *)(&stack0x00000018 + iVar4) = unaff_RBP;
    *(undefined8 *)(&stack0x00000010 + iVar4) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar4) = unaff_RDI;
    *(undefined8 *)(&stack0x00000018 + iVar4 + -0x18) = 0x180237662;
    iVar6 = fcn.18045a350(puVar11, puVar12, iVar8);
    iVar6 = -iVar6;
    *(undefined4 *)(puVar11 + 1) = 0xffffffff;
    *puVar11 = 0;
    *(undefined4 *)((int64_t)puVar11 + 0xc) = 0;
    uVar7 = *puVar12;
    *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x180237688;
    uVar2 = func_0x00018022cd20(uVar7);
    *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x180237699;
    iVar3 = func_0x0001802567e0(uVar2, (int64_t)&arg_48h + iVar6 + iVar4, (int64_t)&arg_50h + iVar6 + iVar4);
    if ((iVar3 == 0) || (iVar3 = *(int32_t *)((int64_t)&arg_50h + iVar6 + iVar4), iVar3 == 0)) {
        *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x1802377d2;
        fcn.180229480(*(int64_t *)(&stack0x00000028 + iVar6 + iVar4), *(int64_t *)(&stack0x00000030 + iVar6 + iVar4));
        *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x1802377ea;
        fcn.1802295a0(*(int64_t *)(&stack0x00000028 + iVar6 + iVar4), *(int64_t *)(&stack0x00000030 + iVar6 + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), *(int64_t *)(&stack0x00000040 + iVar6 + iVar4), 
                      *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar4));
        goto code_r0x0001802377ef;
    }
    iVar10 = *(int32_t *)((int64_t)&arg_48h + iVar6 + iVar4);
    *(int32_t *)puVar11 = iVar10;
    *(int32_t *)((int64_t)puVar11 + 4) = iVar3;
    if (iVar10 == 0) {
        *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x180237740;
        iVar9 = func_0x000180247890(0);
        if ((iVar9 == 0) || (pcVar1 = *(code **)(iVar9 + 0xd8), pcVar1 == (code *)0x0)) {
code_r0x000180237760:
            if (iVar5 != 0) {
                *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x18023776d;
                iVar3 = func_0x00018022fb60(iVar5);
                if (iVar3 != 0) goto code_r0x000180237771;
            }
            *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x1802377ae;
            fcn.180229480(*(int64_t *)(&stack0x00000028 + iVar6 + iVar4), *(int64_t *)(&stack0x00000030 + iVar6 + iVar4)
                         );
            *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x1802377c6;
            fcn.1802295a0(*(int64_t *)(&stack0x00000028 + iVar6 + iVar4), *(int64_t *)(&stack0x00000030 + iVar6 + iVar4)
                          , *(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar6 + iVar4), 
                          *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar4));
code_r0x0001802377ef:
            *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x1802377fc;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar4));
            return 0;
        }
        *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x18023775c;
        iVar3 = (*pcVar1)(puVar11, puVar12, iVar8);
        if (iVar3 == 0) goto code_r0x000180237760;
    } else {
        if (iVar10 == 4) {
            *(undefined4 *)(puVar11 + 1) = 0x27;
            goto code_r0x000180237778;
        }
        if (iVar10 == 0x40) {
            *(undefined4 *)(puVar11 + 1) = 0x3f;
            goto code_r0x000180237778;
        }
        if (iVar10 == 0x329) {
            *(undefined4 *)(puVar11 + 1) = 0x69;
            goto code_r0x000180237778;
        }
        *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x1802376d1;
        uVar7 = func_0x00018022ccf0();
        *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x1802376d9;
        iVar8 = func_0x00018022e160(uVar7);
        if (iVar8 == 0) {
            *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x1802376e3;
            fcn.180229480(*(int64_t *)(&stack0x00000028 + iVar6 + iVar4), *(int64_t *)(&stack0x00000030 + iVar6 + iVar4)
                         );
            *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x1802376fb;
            fcn.1802295a0(*(int64_t *)(&stack0x00000028 + iVar6 + iVar4), *(int64_t *)(&stack0x00000030 + iVar6 + iVar4)
                          , *(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar6 + iVar4), 
                          *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar4));
            goto code_r0x0001802377ef;
        }
        *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x18023770d;
        iVar3 = func_0x00018020f800(iVar8);
        if (iVar3 < 1) {
            return 0;
        }
        iVar3 = iVar3 * 4;
code_r0x000180237771:
        *(int32_t *)(puVar11 + 1) = iVar3;
    }
    iVar10 = *(int32_t *)((int64_t)&arg_48h + iVar6 + iVar4);
code_r0x000180237778:
    if ((((iVar10 == 0x40) || (iVar10 == 0x2a0)) || (iVar10 == 0x2a1)) || (iVar10 == 0x2a2)) {
        *(uint32_t *)((int64_t)puVar11 + 0xc) = *(uint32_t *)((int64_t)puVar11 + 0xc) | 2;
    }
    *(uint32_t *)((int64_t)puVar11 + 0xc) = *(uint32_t *)((int64_t)puVar11 + 0xc) | 1;
    return 1;
}

// ============================================================
// Function: FUN_180237650
// Address: 0x180237650
// Size: 443 bytes
// ============================================================
undefined8 fcn.180237610(int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_90h)
{
    code *pcVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t in_RCX;
    undefined8 *puVar11;
    undefined8 *puVar12;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023761c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar7 = *(undefined8 *)(in_RCX + 0x50);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023762b;
    iVar5 = func_0x000180235930(uVar7);
    iVar8 = in_RCX + 0x90;
    puVar12 = (undefined8 *)(in_RCX + 0x80);
    puVar11 = (undefined8 *)(in_RCX + 0xa8);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = *(undefined8 *)(&stack0x00000018 + iVar4);
    *(undefined8 *)(&stack0x00000018 + iVar4) = unaff_RBP;
    *(undefined8 *)(&stack0x00000010 + iVar4) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar4) = unaff_RDI;
    *(undefined8 *)(&stack0x00000018 + iVar4 + -0x18) = 0x180237662;
    iVar6 = fcn.18045a350(puVar11, puVar12, iVar8);
    iVar6 = -iVar6;
    *(undefined4 *)(puVar11 + 1) = 0xffffffff;
    *puVar11 = 0;
    *(undefined4 *)((int64_t)puVar11 + 0xc) = 0;
    uVar7 = *puVar12;
    *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x180237688;
    uVar2 = func_0x00018022cd20(uVar7);
    *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x180237699;
    iVar3 = func_0x0001802567e0(uVar2, (int64_t)&arg_48h + iVar6 + iVar4, (int64_t)&arg_50h + iVar6 + iVar4);
    if ((iVar3 == 0) || (iVar3 = *(int32_t *)((int64_t)&arg_50h + iVar6 + iVar4), iVar3 == 0)) {
        *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x1802377d2;
        fcn.180229480(*(int64_t *)(&stack0x00000028 + iVar6 + iVar4), *(int64_t *)(&stack0x00000030 + iVar6 + iVar4));
        *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x1802377ea;
        fcn.1802295a0(*(int64_t *)(&stack0x00000028 + iVar6 + iVar4), *(int64_t *)(&stack0x00000030 + iVar6 + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), *(int64_t *)(&stack0x00000040 + iVar6 + iVar4), 
                      *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar4));
        goto code_r0x0001802377ef;
    }
    iVar10 = *(int32_t *)((int64_t)&arg_48h + iVar6 + iVar4);
    *(int32_t *)puVar11 = iVar10;
    *(int32_t *)((int64_t)puVar11 + 4) = iVar3;
    if (iVar10 == 0) {
        *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x180237740;
        iVar9 = func_0x000180247890(0);
        if ((iVar9 == 0) || (pcVar1 = *(code **)(iVar9 + 0xd8), pcVar1 == (code *)0x0)) {
code_r0x000180237760:
            if (iVar5 != 0) {
                *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x18023776d;
                iVar3 = func_0x00018022fb60(iVar5);
                if (iVar3 != 0) goto code_r0x000180237771;
            }
            *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x1802377ae;
            fcn.180229480(*(int64_t *)(&stack0x00000028 + iVar6 + iVar4), *(int64_t *)(&stack0x00000030 + iVar6 + iVar4)
                         );
            *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x1802377c6;
            fcn.1802295a0(*(int64_t *)(&stack0x00000028 + iVar6 + iVar4), *(int64_t *)(&stack0x00000030 + iVar6 + iVar4)
                          , *(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar6 + iVar4), 
                          *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar4));
code_r0x0001802377ef:
            *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x1802377fc;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar4));
            return 0;
        }
        *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x18023775c;
        iVar3 = (*pcVar1)(puVar11, puVar12, iVar8);
        if (iVar3 == 0) goto code_r0x000180237760;
    } else {
        if (iVar10 == 4) {
            *(undefined4 *)(puVar11 + 1) = 0x27;
            goto code_r0x000180237778;
        }
        if (iVar10 == 0x40) {
            *(undefined4 *)(puVar11 + 1) = 0x3f;
            goto code_r0x000180237778;
        }
        if (iVar10 == 0x329) {
            *(undefined4 *)(puVar11 + 1) = 0x69;
            goto code_r0x000180237778;
        }
        *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x1802376d1;
        uVar7 = func_0x00018022ccf0();
        *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x1802376d9;
        iVar8 = func_0x00018022e160(uVar7);
        if (iVar8 == 0) {
            *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x1802376e3;
            fcn.180229480(*(int64_t *)(&stack0x00000028 + iVar6 + iVar4), *(int64_t *)(&stack0x00000030 + iVar6 + iVar4)
                         );
            *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x1802376fb;
            fcn.1802295a0(*(int64_t *)(&stack0x00000028 + iVar6 + iVar4), *(int64_t *)(&stack0x00000030 + iVar6 + iVar4)
                          , *(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar6 + iVar4), 
                          *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar4));
            goto code_r0x0001802377ef;
        }
        *(undefined8 *)(&stack0x00000018 + iVar6 + iVar4 + -0x18) = 0x18023770d;
        iVar3 = func_0x00018020f800(iVar8);
        if (iVar3 < 1) {
            return 0;
        }
        iVar3 = iVar3 * 4;
code_r0x000180237771:
        *(int32_t *)(puVar11 + 1) = iVar3;
    }
    iVar10 = *(int32_t *)((int64_t)&arg_48h + iVar6 + iVar4);
code_r0x000180237778:
    if ((((iVar10 == 0x40) || (iVar10 == 0x2a0)) || (iVar10 == 0x2a1)) || (iVar10 == 0x2a2)) {
        *(uint32_t *)((int64_t)puVar11 + 0xc) = *(uint32_t *)((int64_t)puVar11 + 0xc) | 2;
    }
    *(uint32_t *)((int64_t)puVar11 + 0xc) = *(uint32_t *)((int64_t)puVar11 + 0xc) | 1;
    return 1;
}

// ============================================================
// Function: FUN_180237810
// Address: 0x180237810
// Size: 69 bytes
// ============================================================
undefined8 fcn.180237810(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg_38h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    var_18h._0_4_ = (undefined4)arg3;
    uStack_10 = 0x180237820;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if ((arg3 & 0x30000U) == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180237840;
    fcn.18022cd20(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)((int64_t)&arg_38h + iVar1), *(int64_t *)(&stack0x00000040 + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1), *(int64_t *)(&stack0x00000060 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023784f;
    uVar2 = fcn.180238490(*(int64_t *)((int64_t)&iStackX_20 + iVar1 + -8), *(int64_t *)(&stack0x00000068 + iVar1), 
                          *(int64_t *)(&stack0x00000078 + iVar1));
    return uVar2;
}

// ============================================================
// Function: FUN_180237860
// Address: 0x180237860
// Size: 30 bytes
// ============================================================
uint64_t fcn.180237860(int64_t arg_30h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t in_RCX;
    int64_t iVar5;
    int64_t in_RDX;
    int64_t iVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar6 = *(int64_t *)(in_RDX + 0x18);
    iVar5 = *(int64_t *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x1802378f0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (iVar6 == 0) {
        return (uint64_t)(iVar5 != 0);
    }
    if (iVar5 != 0) {
        if ((*(int64_t *)(iVar5 + 0x18) == 0) || (*(int32_t *)(iVar5 + 8) != 0)) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18023793a;
            iVar1 = fcn.180234b40();
            if (iVar1 < 0) {
                return 0xfffffffe;
            }
        }
        if ((*(int64_t *)(iVar6 + 0x18) == 0) || (*(int32_t *)(iVar6 + 8) != 0)) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180237955;
            iVar1 = fcn.180234b40(iVar6, 0);
            if (iVar1 < 0) {
                return 0xfffffffe;
            }
        }
        iVar1 = *(int32_t *)(iVar5 + 0x20);
        iVar4 = iVar1 - *(int32_t *)(iVar6 + 0x20);
        if (iVar4 == 0) {
            if (iVar1 == 0) {
                return (int64_t)iVar1;
            }
            iVar5 = *(int64_t *)(iVar5 + 0x18);
            if ((iVar5 == 0) || (iVar6 = *(int64_t *)(iVar6 + 0x18), iVar6 == 0)) {
                return 0xfffffffe;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18023798d;
            iVar4 = fcn.180497f30(iVar5, iVar6, (int64_t)iVar1);
        }
        if (-1 < iVar4) {
            return (uint64_t)(0 < iVar4);
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_180237880
// Address: 0x180237880
// Size: 94 bytes
// ============================================================
uint64_t fcn.180237880(int64_t param_1, int64_t param_2)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x18023788a;
    iVar2 = fcn.18045a350();
    if (((*(uint32_t *)(param_1 + 0x7c) & 0x100000) == 0) && ((*(uint32_t *)(param_2 + 0x7c) & 0x100000) == 0)) {
        *(undefined8 *)((int64_t)&uStack_8 - iVar2) = 0x1802378b8;
        iVar1 = fcn.180497f30(param_1 + 0xb0, param_2 + 0xb0, 0x14);
        if (iVar1 < 0) {
            return 0xffffffff;
        }
        return (uint64_t)(0 < iVar1);
    }
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_1802378e0
// Address: 0x1802378e0
// Size: 213 bytes
// ============================================================
uint64_t fcn.180237860(int64_t arg_30h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t in_RCX;
    int64_t iVar5;
    int64_t in_RDX;
    int64_t iVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar6 = *(int64_t *)(in_RDX + 0x18);
    iVar5 = *(int64_t *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x1802378f0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (iVar6 == 0) {
        return (uint64_t)(iVar5 != 0);
    }
    if (iVar5 != 0) {
        if ((*(int64_t *)(iVar5 + 0x18) == 0) || (*(int32_t *)(iVar5 + 8) != 0)) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18023793a;
            iVar1 = fcn.180234b40();
            if (iVar1 < 0) {
                return 0xfffffffe;
            }
        }
        if ((*(int64_t *)(iVar6 + 0x18) == 0) || (*(int32_t *)(iVar6 + 8) != 0)) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180237955;
            iVar1 = fcn.180234b40(iVar6, 0);
            if (iVar1 < 0) {
                return 0xfffffffe;
            }
        }
        iVar1 = *(int32_t *)(iVar5 + 0x20);
        iVar4 = iVar1 - *(int32_t *)(iVar6 + 0x20);
        if (iVar4 == 0) {
            if (iVar1 == 0) {
                return (int64_t)iVar1;
            }
            iVar5 = *(int64_t *)(iVar5 + 0x18);
            if ((iVar5 == 0) || (iVar6 = *(int64_t *)(iVar6 + 0x18), iVar6 == 0)) {
                return 0xfffffffe;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18023798d;
            iVar4 = fcn.180497f30(iVar5, iVar6, (int64_t)iVar1);
        }
        if (-1 < iVar4) {
            return (uint64_t)(0 < iVar4);
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1802379c0
// Address: 0x1802379c0
// Size: 201 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_12h
// WARNING: [rz-ghidra] Detected overlap for variable var_13h
// WARNING: [rz-ghidra] Detected overlap for variable var_11h

void fcn.1802379c0(int64_t arg_28h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined4 *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1802379cf;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_28h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar3);
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1802379fb;
    iVar4 = func_0x000180215540(in_RDX, 0x1804ad35c);
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237a08;
    iVar2 = fcn.180234b40(in_RCX, 0);
    if (in_R9 != (undefined4 *)0x0) {
        *in_R9 = 0;
    }
    if ((-1 < iVar2) && (iVar4 != 0)) {
        iVar2 = *(int32_t *)(in_RCX + 0x20);
        uVar1 = *(undefined8 *)(in_RCX + 0x18);
        *(undefined8 *)((int64_t)&var_8h + iVar3) = 0;
        *(int64_t *)(&stack0x00000000 + iVar3) = iVar4;
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237a37;
        iVar2 = func_0x000180214220(uVar1, (int64_t)iVar2, (int64_t)&var_10h + iVar3, 0);
        if ((iVar2 != 0) && (in_R9 != (undefined4 *)0x0)) {
            *in_R9 = 1;
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237a71;
    func_0x000180215590(iVar4);
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237a80;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_28h + iVar3) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar3));
    return;
}

// ============================================================
// Function: FUN_180237a90
// Address: 0x180237a90
// Size: 92 bytes
// ============================================================
bool fcn.180237a90(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int32_t iVar7;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t in_R8;
    undefined8 unaff_R14;
    int64_t aiStackX_8 [4];
    undefined8 uStack_20;
    
    uStack_20 = 0x180237aa0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237ab6;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237ace;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x10), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x18)
                      , *(int64_t *)((int64_t)&arg_38h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237ae0;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
        return false;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_R14;
    if (in_RDX != 0) {
        iVar7 = 0;
        if ((in_R8 & 4) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237b1e;
            iVar3 = fcn.180222010();
            if (0 < iVar3) {
                do {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237b30;
                    iVar6 = fcn.180222340(in_RCX, iVar7);
                    if (iVar6 == in_RDX) {
                        return true;
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237b4f;
                    fcn.18023bad0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237b5f;
                    fcn.18023bad0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
                    iVar3 = 0;
                    if (((*(uint32_t *)(iVar6 + 0xd8) & 0x100000) == 0) &&
                       (iVar3 = 0, (*(uint32_t *)(in_RDX + 0xd8) & 0x100000) == 0)) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237b90;
                        iVar3 = fcn.180497f30(iVar6 + 0x128, in_RDX + 0x128, 0x14);
                        if (iVar3 == 0) goto code_r0x000180237ba1;
                        uVar4 = (iVar3 >> 0x1f & 0xfffffffeU) + 1;
code_r0x000180237bd6:
                        if (uVar4 == 0) {
                            return true;
                        }
                    } else {
code_r0x000180237ba1:
                        if ((*(int32_t *)(iVar6 + 0x7c) != 0) || (*(int32_t *)(in_RDX + 0x7c) != 0)) {
code_r0x000180237bce:
                            uVar4 = (uint32_t)(0 < iVar3);
                            goto code_r0x000180237bd6;
                        }
                        iVar3 = *(int32_t *)(iVar6 + 0x78);
                        if ((*(int32_t *)(in_RDX + 0x78) <= iVar3) && (iVar3 <= *(int32_t *)(in_RDX + 0x78))) {
                            uVar1 = *(undefined8 *)(in_RDX + 0x70);
                            uVar2 = *(undefined8 *)(iVar6 + 0x70);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237bc8;
                            iVar3 = fcn.180497f30(uVar2, uVar1, (int64_t)iVar3);
                            if (-1 < iVar3) goto code_r0x000180237bce;
                        }
                    }
                    iVar7 = iVar7 + 1;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237be8;
                    iVar3 = fcn.180222010(in_RCX);
                } while (iVar7 < iVar3);
            }
        }
        if ((in_R8 & 8) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237c00;
            iVar7 = fcn.18024c670(*(int64_t *)((int64_t)aiStackX_8 + iVar5), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x10), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x18), 
                                  *(int64_t *)(&stack0x00000048 + iVar5), *(int64_t *)(&stack0x00000050 + iVar5), 
                                  *(int64_t *)(&stack0x00000058 + iVar5), *(int64_t *)(&stack0x00000060 + iVar5));
            if (iVar7 != 0) {
                return 0 < iVar7;
            }
        }
        if ((in_R8 & 1) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237c1d;
            iVar7 = fcn.1802375f0(in_RDX);
            if (iVar7 == 0) {
                return false;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237c3c;
        iVar7 = fcn.180221da0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x10));
        if (iVar7 != 0) {
            return true;
        }
        if ((in_R8 & 1) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237c4c;
            fcn.18021fe80(in_RDX);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237c51;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237c69;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x10), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x18)
                      , *(int64_t *)((int64_t)&arg_38h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237c7b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
    }
    return false;
}

// ============================================================
// Function: FUN_180237aec
// Address: 0x180237aec
// Size: 431 bytes
// ============================================================
bool fcn.180237a90(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int32_t iVar7;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t in_R8;
    undefined8 unaff_R14;
    int64_t aiStackX_8 [4];
    undefined8 uStack_20;
    
    uStack_20 = 0x180237aa0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237ab6;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237ace;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x10), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x18)
                      , *(int64_t *)((int64_t)&arg_38h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237ae0;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
        return false;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_R14;
    if (in_RDX != 0) {
        iVar7 = 0;
        if ((in_R8 & 4) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237b1e;
            iVar3 = fcn.180222010();
            if (0 < iVar3) {
                do {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237b30;
                    iVar6 = fcn.180222340(in_RCX, iVar7);
                    if (iVar6 == in_RDX) {
                        return true;
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237b4f;
                    fcn.18023bad0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237b5f;
                    fcn.18023bad0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
                    iVar3 = 0;
                    if (((*(uint32_t *)(iVar6 + 0xd8) & 0x100000) == 0) &&
                       (iVar3 = 0, (*(uint32_t *)(in_RDX + 0xd8) & 0x100000) == 0)) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237b90;
                        iVar3 = fcn.180497f30(iVar6 + 0x128, in_RDX + 0x128, 0x14);
                        if (iVar3 == 0) goto code_r0x000180237ba1;
                        uVar4 = (iVar3 >> 0x1f & 0xfffffffeU) + 1;
code_r0x000180237bd6:
                        if (uVar4 == 0) {
                            return true;
                        }
                    } else {
code_r0x000180237ba1:
                        if ((*(int32_t *)(iVar6 + 0x7c) != 0) || (*(int32_t *)(in_RDX + 0x7c) != 0)) {
code_r0x000180237bce:
                            uVar4 = (uint32_t)(0 < iVar3);
                            goto code_r0x000180237bd6;
                        }
                        iVar3 = *(int32_t *)(iVar6 + 0x78);
                        if ((*(int32_t *)(in_RDX + 0x78) <= iVar3) && (iVar3 <= *(int32_t *)(in_RDX + 0x78))) {
                            uVar1 = *(undefined8 *)(in_RDX + 0x70);
                            uVar2 = *(undefined8 *)(iVar6 + 0x70);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237bc8;
                            iVar3 = fcn.180497f30(uVar2, uVar1, (int64_t)iVar3);
                            if (-1 < iVar3) goto code_r0x000180237bce;
                        }
                    }
                    iVar7 = iVar7 + 1;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237be8;
                    iVar3 = fcn.180222010(in_RCX);
                } while (iVar7 < iVar3);
            }
        }
        if ((in_R8 & 8) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237c00;
            iVar7 = fcn.18024c670(*(int64_t *)((int64_t)aiStackX_8 + iVar5), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x10), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x18), 
                                  *(int64_t *)(&stack0x00000048 + iVar5), *(int64_t *)(&stack0x00000050 + iVar5), 
                                  *(int64_t *)(&stack0x00000058 + iVar5), *(int64_t *)(&stack0x00000060 + iVar5));
            if (iVar7 != 0) {
                return 0 < iVar7;
            }
        }
        if ((in_R8 & 1) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237c1d;
            iVar7 = fcn.1802375f0(in_RDX);
            if (iVar7 == 0) {
                return false;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237c3c;
        iVar7 = fcn.180221da0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x10));
        if (iVar7 != 0) {
            return true;
        }
        if ((in_R8 & 1) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237c4c;
            fcn.18021fe80(in_RDX);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237c51;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237c69;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x10), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x18)
                      , *(int64_t *)((int64_t)&arg_38h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237c7b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
    }
    return false;
}

// ============================================================
// Function: FUN_180237c9b
// Address: 0x180237c9b
// Size: 7 bytes
// ============================================================
bool fcn.180237a90(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int32_t iVar7;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t in_R8;
    undefined8 unaff_R14;
    int64_t aiStackX_8 [4];
    undefined8 uStack_20;
    
    uStack_20 = 0x180237aa0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237ab6;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237ace;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x10), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x18)
                      , *(int64_t *)((int64_t)&arg_38h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237ae0;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
        return false;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_R14;
    if (in_RDX != 0) {
        iVar7 = 0;
        if ((in_R8 & 4) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237b1e;
            iVar3 = fcn.180222010();
            if (0 < iVar3) {
                do {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237b30;
                    iVar6 = fcn.180222340(in_RCX, iVar7);
                    if (iVar6 == in_RDX) {
                        return true;
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237b4f;
                    fcn.18023bad0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237b5f;
                    fcn.18023bad0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
                    iVar3 = 0;
                    if (((*(uint32_t *)(iVar6 + 0xd8) & 0x100000) == 0) &&
                       (iVar3 = 0, (*(uint32_t *)(in_RDX + 0xd8) & 0x100000) == 0)) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237b90;
                        iVar3 = fcn.180497f30(iVar6 + 0x128, in_RDX + 0x128, 0x14);
                        if (iVar3 == 0) goto code_r0x000180237ba1;
                        uVar4 = (iVar3 >> 0x1f & 0xfffffffeU) + 1;
code_r0x000180237bd6:
                        if (uVar4 == 0) {
                            return true;
                        }
                    } else {
code_r0x000180237ba1:
                        if ((*(int32_t *)(iVar6 + 0x7c) != 0) || (*(int32_t *)(in_RDX + 0x7c) != 0)) {
code_r0x000180237bce:
                            uVar4 = (uint32_t)(0 < iVar3);
                            goto code_r0x000180237bd6;
                        }
                        iVar3 = *(int32_t *)(iVar6 + 0x78);
                        if ((*(int32_t *)(in_RDX + 0x78) <= iVar3) && (iVar3 <= *(int32_t *)(in_RDX + 0x78))) {
                            uVar1 = *(undefined8 *)(in_RDX + 0x70);
                            uVar2 = *(undefined8 *)(iVar6 + 0x70);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237bc8;
                            iVar3 = fcn.180497f30(uVar2, uVar1, (int64_t)iVar3);
                            if (-1 < iVar3) goto code_r0x000180237bce;
                        }
                    }
                    iVar7 = iVar7 + 1;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237be8;
                    iVar3 = fcn.180222010(in_RCX);
                } while (iVar7 < iVar3);
            }
        }
        if ((in_R8 & 8) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237c00;
            iVar7 = fcn.18024c670(*(int64_t *)((int64_t)aiStackX_8 + iVar5), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x10), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x18), 
                                  *(int64_t *)(&stack0x00000048 + iVar5), *(int64_t *)(&stack0x00000050 + iVar5), 
                                  *(int64_t *)(&stack0x00000058 + iVar5), *(int64_t *)(&stack0x00000060 + iVar5));
            if (iVar7 != 0) {
                return 0 < iVar7;
            }
        }
        if ((in_R8 & 1) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237c1d;
            iVar7 = fcn.1802375f0(in_RDX);
            if (iVar7 == 0) {
                return false;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237c3c;
        iVar7 = fcn.180221da0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x10));
        if (iVar7 != 0) {
            return true;
        }
        if ((in_R8 & 1) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237c4c;
            fcn.18021fe80(in_RDX);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237c51;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237c69;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x10), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x18)
                      , *(int64_t *)((int64_t)&arg_38h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180237c7b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
    }
    return false;
}

// ============================================================
// Function: FUN_180237cb0
// Address: 0x180237cb0
// Size: 94 bytes
// ============================================================
undefined4
fcn.180237cb0(int64_t placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg_38h, int64_t arg_40h,
             int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int32_t iVar5;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    var_18h._0_4_ = (undefined4)arg3;
    uStack_20 = 0x180237cc3;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (placeholder_0 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237cd9;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237cf1;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_38h + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237d03;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_R12;
    *(undefined8 *)((int64_t)&var_10h + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&var_8h + iVar3) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237d2f;
    iVar1 = fcn.180222010(placeholder_1);
    iVar4 = 0;
    if (0 < iVar1) {
        iVar5 = iVar1;
        do {
            iVar5 = iVar5 + -1;
            iVar2 = iVar4;
            if ((arg3 & 2U) != 0) {
                iVar2 = iVar5;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237d60;
            fcn.180222340(placeholder_1, iVar2);
            if (placeholder_0 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237d6d;
                placeholder_0 = fcn.180221f20();
                if (placeholder_0 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237dc1;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237dd9;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237deb;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar3));
                    return 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237d85;
            iVar2 = fcn.180237a90(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            if (iVar2 == 0) {
                return 0;
            }
            iVar4 = iVar4 + 1;
        } while (iVar4 < iVar1);
    }
    return 1;
}

// ============================================================
// Function: FUN_180237d0e
// Address: 0x180237d0e
// Size: 174 bytes
// ============================================================
undefined4
fcn.180237cb0(int64_t placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg_38h, int64_t arg_40h,
             int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int32_t iVar5;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    var_18h._0_4_ = (undefined4)arg3;
    uStack_20 = 0x180237cc3;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (placeholder_0 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237cd9;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237cf1;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_38h + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237d03;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_R12;
    *(undefined8 *)((int64_t)&var_10h + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&var_8h + iVar3) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237d2f;
    iVar1 = fcn.180222010(placeholder_1);
    iVar4 = 0;
    if (0 < iVar1) {
        iVar5 = iVar1;
        do {
            iVar5 = iVar5 + -1;
            iVar2 = iVar4;
            if ((arg3 & 2U) != 0) {
                iVar2 = iVar5;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237d60;
            fcn.180222340(placeholder_1, iVar2);
            if (placeholder_0 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237d6d;
                placeholder_0 = fcn.180221f20();
                if (placeholder_0 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237dc1;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237dd9;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237deb;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar3));
                    return 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237d85;
            iVar2 = fcn.180237a90(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            if (iVar2 == 0) {
                return 0;
            }
            iVar4 = iVar4 + 1;
        } while (iVar4 < iVar1);
    }
    return 1;
}

// ============================================================
// Function: FUN_180237dbc
// Address: 0x180237dbc
// Size: 49 bytes
// ============================================================
undefined4
fcn.180237cb0(int64_t placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg_38h, int64_t arg_40h,
             int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int32_t iVar5;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    var_18h._0_4_ = (undefined4)arg3;
    uStack_20 = 0x180237cc3;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (placeholder_0 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237cd9;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237cf1;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_38h + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237d03;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_R12;
    *(undefined8 *)((int64_t)&var_10h + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&var_8h + iVar3) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237d2f;
    iVar1 = fcn.180222010(placeholder_1);
    iVar4 = 0;
    if (0 < iVar1) {
        iVar5 = iVar1;
        do {
            iVar5 = iVar5 + -1;
            iVar2 = iVar4;
            if ((arg3 & 2U) != 0) {
                iVar2 = iVar5;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237d60;
            fcn.180222340(placeholder_1, iVar2);
            if (placeholder_0 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237d6d;
                placeholder_0 = fcn.180221f20();
                if (placeholder_0 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237dc1;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237dd9;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237deb;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar3));
                    return 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180237d85;
            iVar2 = fcn.180237a90(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            if (iVar2 == 0) {
                return 0;
            }
            iVar4 = iVar4 + 1;
        } while (iVar4 < iVar1);
    }
    return 1;
}

// ============================================================
// Function: FUN_180237df0
// Address: 0x180237df0
// Size: 72 bytes
// ============================================================
void fcn.180237df0(int64_t arg_60h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint32_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint32_t uVar5;
    undefined8 unaff_RDI;
    uint64_t uVar6;
    int64_t in_R8;
    uint64_t in_R9;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_28;
    
    uStack_28 = 0x180237e02;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_60h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar3);
    *(int32_t *)((int64_t)aiStackX_18 + iVar3 + -0x18) = (int32_t)in_R9;
    if ((in_R9 & 0x30000) == 0) goto code_r0x00018023802b;
    *(undefined8 *)((int64_t)&arg_90h + iVar3) = unaff_RBX;
    uVar4 = 0;
    uVar5 = 0;
    *(undefined8 *)((int64_t)&arg_88h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_80h + iVar3) = unaff_RDI;
    uVar6 = uVar4;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237e5f;
        in_RDX = fcn.180222340(in_R8);
        uVar6 = 1;
        if (in_RDX != 0) goto code_r0x000180237e72;
    } else {
code_r0x000180237e72:
        uVar1 = *(undefined8 *)(in_RDX + 0x50);
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237e7b;
        uVar4 = func_0x000180235930(uVar1);
    }
    if (in_R8 == 0) {
        if (uVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237e9b;
            iVar2 = fcn.18022fc40(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18), 
                                  *(int64_t *)((int64_t)&var_8h + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)(&stack0x00000058 + iVar3));
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237eb7;
                iVar2 = func_0x00018022f7c0(uVar4, (int64_t)aiStackX_18 + iVar3 + -8, 0x50, (int64_t)&var_8h + iVar3);
                if (iVar2 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237ed1;
                    func_0x00018022d1b0((int64_t)aiStackX_18 + iVar3 + -8);
                }
            }
        }
    } else {
        *(undefined8 *)((int64_t)&arg_78h + iVar3) = unaff_R15;
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f21;
        iVar2 = fcn.180237590(in_RDX);
        if (iVar2 == 2) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f44;
            iVar2 = fcn.180238490(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18), 
                                  *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar3));
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f59;
                iVar2 = fcn.180222010(in_R8);
                uVar5 = (uint32_t)uVar6;
                if ((int32_t)(uint32_t)uVar6 < iVar2) {
                    do {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f68;
                        func_0x00018021fee0(in_RDX);
                        uVar5 = (uint32_t)uVar6;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f75;
                        in_RDX = fcn.180222340(in_R8, uVar6);
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f80;
                        iVar2 = fcn.180237590(in_RDX);
                        if (iVar2 != 2) goto code_r0x000180238000;
                        if (in_RDX != 0) {
                            uVar1 = *(undefined8 *)(in_RDX + 0x50);
                            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f9c;
                            func_0x000180235930(uVar1);
                        }
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237faf;
                        iVar2 = fcn.180238490(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18), 
                                              *(int64_t *)(&stack0x00000050 + iVar3), 
                                              *(int64_t *)((int64_t)&arg_60h + iVar3));
                        if (iVar2 != 0) goto code_r0x000180237fe0;
                        uVar5 = uVar5 + 1;
                        uVar6 = (uint64_t)uVar5;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237fbf;
                        iVar2 = fcn.180222010(in_R8);
                    } while ((int32_t)uVar5 < iVar2);
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237fcb;
                func_0x00018021fee0(in_RDX);
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237fda;
                iVar2 = fcn.180238490(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18), 
                                      *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar3));
                if (iVar2 == 0) goto code_r0x00018023802b;
            }
code_r0x000180237fe0:
            if ((iVar2 - 0x3bU < 2) && (uVar5 != 0)) {
                uVar5 = uVar5 - 1;
            }
        } else {
            uVar5 = 0;
        }
code_r0x000180238000:
        if (in_RCX != (uint32_t *)0x0) {
            *in_RCX = uVar5;
        }
    }
code_r0x00018023802b:
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18023803b;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_60h + iVar3) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar3));
    return;
}

// ============================================================
// Function: FUN_180237e38
// Address: 0x180237e38
// Size: 220 bytes
// ============================================================
void fcn.180237df0(int64_t arg_60h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint32_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint32_t uVar5;
    undefined8 unaff_RDI;
    uint64_t uVar6;
    int64_t in_R8;
    uint64_t in_R9;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_28;
    
    uStack_28 = 0x180237e02;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_60h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar3);
    *(int32_t *)((int64_t)aiStackX_18 + iVar3 + -0x18) = (int32_t)in_R9;
    if ((in_R9 & 0x30000) == 0) goto code_r0x00018023802b;
    *(undefined8 *)((int64_t)&arg_90h + iVar3) = unaff_RBX;
    uVar4 = 0;
    uVar5 = 0;
    *(undefined8 *)((int64_t)&arg_88h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_80h + iVar3) = unaff_RDI;
    uVar6 = uVar4;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237e5f;
        in_RDX = fcn.180222340(in_R8);
        uVar6 = 1;
        if (in_RDX != 0) goto code_r0x000180237e72;
    } else {
code_r0x000180237e72:
        uVar1 = *(undefined8 *)(in_RDX + 0x50);
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237e7b;
        uVar4 = func_0x000180235930(uVar1);
    }
    if (in_R8 == 0) {
        if (uVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237e9b;
            iVar2 = fcn.18022fc40(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18), 
                                  *(int64_t *)((int64_t)&var_8h + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)(&stack0x00000058 + iVar3));
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237eb7;
                iVar2 = func_0x00018022f7c0(uVar4, (int64_t)aiStackX_18 + iVar3 + -8, 0x50, (int64_t)&var_8h + iVar3);
                if (iVar2 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237ed1;
                    func_0x00018022d1b0((int64_t)aiStackX_18 + iVar3 + -8);
                }
            }
        }
    } else {
        *(undefined8 *)((int64_t)&arg_78h + iVar3) = unaff_R15;
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f21;
        iVar2 = fcn.180237590(in_RDX);
        if (iVar2 == 2) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f44;
            iVar2 = fcn.180238490(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18), 
                                  *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar3));
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f59;
                iVar2 = fcn.180222010(in_R8);
                uVar5 = (uint32_t)uVar6;
                if ((int32_t)(uint32_t)uVar6 < iVar2) {
                    do {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f68;
                        func_0x00018021fee0(in_RDX);
                        uVar5 = (uint32_t)uVar6;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f75;
                        in_RDX = fcn.180222340(in_R8, uVar6);
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f80;
                        iVar2 = fcn.180237590(in_RDX);
                        if (iVar2 != 2) goto code_r0x000180238000;
                        if (in_RDX != 0) {
                            uVar1 = *(undefined8 *)(in_RDX + 0x50);
                            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f9c;
                            func_0x000180235930(uVar1);
                        }
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237faf;
                        iVar2 = fcn.180238490(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18), 
                                              *(int64_t *)(&stack0x00000050 + iVar3), 
                                              *(int64_t *)((int64_t)&arg_60h + iVar3));
                        if (iVar2 != 0) goto code_r0x000180237fe0;
                        uVar5 = uVar5 + 1;
                        uVar6 = (uint64_t)uVar5;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237fbf;
                        iVar2 = fcn.180222010(in_R8);
                    } while ((int32_t)uVar5 < iVar2);
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237fcb;
                func_0x00018021fee0(in_RDX);
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237fda;
                iVar2 = fcn.180238490(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18), 
                                      *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar3));
                if (iVar2 == 0) goto code_r0x00018023802b;
            }
code_r0x000180237fe0:
            if ((iVar2 - 0x3bU < 2) && (uVar5 != 0)) {
                uVar5 = uVar5 - 1;
            }
        } else {
            uVar5 = 0;
        }
code_r0x000180238000:
        if (in_RCX != (uint32_t *)0x0) {
            *in_RCX = uVar5;
        }
    }
code_r0x00018023802b:
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18023803b;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_60h + iVar3) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar3));
    return;
}

// ============================================================
// Function: FUN_180237f14
// Address: 0x180237f14
// Size: 255 bytes
// ============================================================
void fcn.180237df0(int64_t arg_60h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint32_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint32_t uVar5;
    undefined8 unaff_RDI;
    uint64_t uVar6;
    int64_t in_R8;
    uint64_t in_R9;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_28;
    
    uStack_28 = 0x180237e02;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_60h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar3);
    *(int32_t *)((int64_t)aiStackX_18 + iVar3 + -0x18) = (int32_t)in_R9;
    if ((in_R9 & 0x30000) == 0) goto code_r0x00018023802b;
    *(undefined8 *)((int64_t)&arg_90h + iVar3) = unaff_RBX;
    uVar4 = 0;
    uVar5 = 0;
    *(undefined8 *)((int64_t)&arg_88h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_80h + iVar3) = unaff_RDI;
    uVar6 = uVar4;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237e5f;
        in_RDX = fcn.180222340(in_R8);
        uVar6 = 1;
        if (in_RDX != 0) goto code_r0x000180237e72;
    } else {
code_r0x000180237e72:
        uVar1 = *(undefined8 *)(in_RDX + 0x50);
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237e7b;
        uVar4 = func_0x000180235930(uVar1);
    }
    if (in_R8 == 0) {
        if (uVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237e9b;
            iVar2 = fcn.18022fc40(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18), 
                                  *(int64_t *)((int64_t)&var_8h + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)(&stack0x00000058 + iVar3));
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237eb7;
                iVar2 = func_0x00018022f7c0(uVar4, (int64_t)aiStackX_18 + iVar3 + -8, 0x50, (int64_t)&var_8h + iVar3);
                if (iVar2 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237ed1;
                    func_0x00018022d1b0((int64_t)aiStackX_18 + iVar3 + -8);
                }
            }
        }
    } else {
        *(undefined8 *)((int64_t)&arg_78h + iVar3) = unaff_R15;
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f21;
        iVar2 = fcn.180237590(in_RDX);
        if (iVar2 == 2) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f44;
            iVar2 = fcn.180238490(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18), 
                                  *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar3));
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f59;
                iVar2 = fcn.180222010(in_R8);
                uVar5 = (uint32_t)uVar6;
                if ((int32_t)(uint32_t)uVar6 < iVar2) {
                    do {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f68;
                        func_0x00018021fee0(in_RDX);
                        uVar5 = (uint32_t)uVar6;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f75;
                        in_RDX = fcn.180222340(in_R8, uVar6);
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f80;
                        iVar2 = fcn.180237590(in_RDX);
                        if (iVar2 != 2) goto code_r0x000180238000;
                        if (in_RDX != 0) {
                            uVar1 = *(undefined8 *)(in_RDX + 0x50);
                            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f9c;
                            func_0x000180235930(uVar1);
                        }
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237faf;
                        iVar2 = fcn.180238490(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18), 
                                              *(int64_t *)(&stack0x00000050 + iVar3), 
                                              *(int64_t *)((int64_t)&arg_60h + iVar3));
                        if (iVar2 != 0) goto code_r0x000180237fe0;
                        uVar5 = uVar5 + 1;
                        uVar6 = (uint64_t)uVar5;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237fbf;
                        iVar2 = fcn.180222010(in_R8);
                    } while ((int32_t)uVar5 < iVar2);
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237fcb;
                func_0x00018021fee0(in_RDX);
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237fda;
                iVar2 = fcn.180238490(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18), 
                                      *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar3));
                if (iVar2 == 0) goto code_r0x00018023802b;
            }
code_r0x000180237fe0:
            if ((iVar2 - 0x3bU < 2) && (uVar5 != 0)) {
                uVar5 = uVar5 - 1;
            }
        } else {
            uVar5 = 0;
        }
code_r0x000180238000:
        if (in_RCX != (uint32_t *)0x0) {
            *in_RCX = uVar5;
        }
    }
code_r0x00018023802b:
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18023803b;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_60h + iVar3) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar3));
    return;
}

// ============================================================
// Function: FUN_180238013
// Address: 0x180238013
// Size: 24 bytes
// ============================================================
void fcn.180237df0(int64_t arg_60h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint32_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint32_t uVar5;
    undefined8 unaff_RDI;
    uint64_t uVar6;
    int64_t in_R8;
    uint64_t in_R9;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_28;
    
    uStack_28 = 0x180237e02;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_60h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar3);
    *(int32_t *)((int64_t)aiStackX_18 + iVar3 + -0x18) = (int32_t)in_R9;
    if ((in_R9 & 0x30000) == 0) goto code_r0x00018023802b;
    *(undefined8 *)((int64_t)&arg_90h + iVar3) = unaff_RBX;
    uVar4 = 0;
    uVar5 = 0;
    *(undefined8 *)((int64_t)&arg_88h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_80h + iVar3) = unaff_RDI;
    uVar6 = uVar4;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237e5f;
        in_RDX = fcn.180222340(in_R8);
        uVar6 = 1;
        if (in_RDX != 0) goto code_r0x000180237e72;
    } else {
code_r0x000180237e72:
        uVar1 = *(undefined8 *)(in_RDX + 0x50);
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237e7b;
        uVar4 = func_0x000180235930(uVar1);
    }
    if (in_R8 == 0) {
        if (uVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237e9b;
            iVar2 = fcn.18022fc40(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18), 
                                  *(int64_t *)((int64_t)&var_8h + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)(&stack0x00000058 + iVar3));
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237eb7;
                iVar2 = func_0x00018022f7c0(uVar4, (int64_t)aiStackX_18 + iVar3 + -8, 0x50, (int64_t)&var_8h + iVar3);
                if (iVar2 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237ed1;
                    func_0x00018022d1b0((int64_t)aiStackX_18 + iVar3 + -8);
                }
            }
        }
    } else {
        *(undefined8 *)((int64_t)&arg_78h + iVar3) = unaff_R15;
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f21;
        iVar2 = fcn.180237590(in_RDX);
        if (iVar2 == 2) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f44;
            iVar2 = fcn.180238490(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18), 
                                  *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar3));
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f59;
                iVar2 = fcn.180222010(in_R8);
                uVar5 = (uint32_t)uVar6;
                if ((int32_t)(uint32_t)uVar6 < iVar2) {
                    do {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f68;
                        func_0x00018021fee0(in_RDX);
                        uVar5 = (uint32_t)uVar6;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f75;
                        in_RDX = fcn.180222340(in_R8, uVar6);
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f80;
                        iVar2 = fcn.180237590(in_RDX);
                        if (iVar2 != 2) goto code_r0x000180238000;
                        if (in_RDX != 0) {
                            uVar1 = *(undefined8 *)(in_RDX + 0x50);
                            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f9c;
                            func_0x000180235930(uVar1);
                        }
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237faf;
                        iVar2 = fcn.180238490(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18), 
                                              *(int64_t *)(&stack0x00000050 + iVar3), 
                                              *(int64_t *)((int64_t)&arg_60h + iVar3));
                        if (iVar2 != 0) goto code_r0x000180237fe0;
                        uVar5 = uVar5 + 1;
                        uVar6 = (uint64_t)uVar5;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237fbf;
                        iVar2 = fcn.180222010(in_R8);
                    } while ((int32_t)uVar5 < iVar2);
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237fcb;
                func_0x00018021fee0(in_RDX);
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237fda;
                iVar2 = fcn.180238490(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18), 
                                      *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar3));
                if (iVar2 == 0) goto code_r0x00018023802b;
            }
code_r0x000180237fe0:
            if ((iVar2 - 0x3bU < 2) && (uVar5 != 0)) {
                uVar5 = uVar5 - 1;
            }
        } else {
            uVar5 = 0;
        }
code_r0x000180238000:
        if (in_RCX != (uint32_t *)0x0) {
            *in_RCX = uVar5;
        }
    }
code_r0x00018023802b:
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18023803b;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_60h + iVar3) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar3));
    return;
}

// ============================================================
// Function: FUN_18023802b
// Address: 0x18023802b
// Size: 31 bytes
// ============================================================
void fcn.180237df0(int64_t arg_60h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint32_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint32_t uVar5;
    undefined8 unaff_RDI;
    uint64_t uVar6;
    int64_t in_R8;
    uint64_t in_R9;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_28;
    
    uStack_28 = 0x180237e02;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_60h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar3);
    *(int32_t *)((int64_t)aiStackX_18 + iVar3 + -0x18) = (int32_t)in_R9;
    if ((in_R9 & 0x30000) == 0) goto code_r0x00018023802b;
    *(undefined8 *)((int64_t)&arg_90h + iVar3) = unaff_RBX;
    uVar4 = 0;
    uVar5 = 0;
    *(undefined8 *)((int64_t)&arg_88h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_80h + iVar3) = unaff_RDI;
    uVar6 = uVar4;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237e5f;
        in_RDX = fcn.180222340(in_R8);
        uVar6 = 1;
        if (in_RDX != 0) goto code_r0x000180237e72;
    } else {
code_r0x000180237e72:
        uVar1 = *(undefined8 *)(in_RDX + 0x50);
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237e7b;
        uVar4 = func_0x000180235930(uVar1);
    }
    if (in_R8 == 0) {
        if (uVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237e9b;
            iVar2 = fcn.18022fc40(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18), 
                                  *(int64_t *)((int64_t)&var_8h + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)(&stack0x00000058 + iVar3));
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237eb7;
                iVar2 = func_0x00018022f7c0(uVar4, (int64_t)aiStackX_18 + iVar3 + -8, 0x50, (int64_t)&var_8h + iVar3);
                if (iVar2 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237ed1;
                    func_0x00018022d1b0((int64_t)aiStackX_18 + iVar3 + -8);
                }
            }
        }
    } else {
        *(undefined8 *)((int64_t)&arg_78h + iVar3) = unaff_R15;
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f21;
        iVar2 = fcn.180237590(in_RDX);
        if (iVar2 == 2) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f44;
            iVar2 = fcn.180238490(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18), 
                                  *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar3));
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f59;
                iVar2 = fcn.180222010(in_R8);
                uVar5 = (uint32_t)uVar6;
                if ((int32_t)(uint32_t)uVar6 < iVar2) {
                    do {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f68;
                        func_0x00018021fee0(in_RDX);
                        uVar5 = (uint32_t)uVar6;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f75;
                        in_RDX = fcn.180222340(in_R8, uVar6);
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f80;
                        iVar2 = fcn.180237590(in_RDX);
                        if (iVar2 != 2) goto code_r0x000180238000;
                        if (in_RDX != 0) {
                            uVar1 = *(undefined8 *)(in_RDX + 0x50);
                            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f9c;
                            func_0x000180235930(uVar1);
                        }
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237faf;
                        iVar2 = fcn.180238490(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18), 
                                              *(int64_t *)(&stack0x00000050 + iVar3), 
                                              *(int64_t *)((int64_t)&arg_60h + iVar3));
                        if (iVar2 != 0) goto code_r0x000180237fe0;
                        uVar5 = uVar5 + 1;
                        uVar6 = (uint64_t)uVar5;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237fbf;
                        iVar2 = fcn.180222010(in_R8);
                    } while ((int32_t)uVar5 < iVar2);
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237fcb;
                func_0x00018021fee0(in_RDX);
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237fda;
                iVar2 = fcn.180238490(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18), 
                                      *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar3));
                if (iVar2 == 0) goto code_r0x00018023802b;
            }
code_r0x000180237fe0:
            if ((iVar2 - 0x3bU < 2) && (uVar5 != 0)) {
                uVar5 = uVar5 - 1;
            }
        } else {
            uVar5 = 0;
        }
code_r0x000180238000:
        if (in_RCX != (uint32_t *)0x0) {
            *in_RCX = uVar5;
        }
    }
code_r0x00018023802b:
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18023803b;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_60h + iVar3) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar3));
    return;
}

// ============================================================
// Function: FUN_18023804a
// Address: 0x18023804a
// Size: 7 bytes
// ============================================================
void fcn.180237df0(int64_t arg_60h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint32_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint32_t uVar5;
    undefined8 unaff_RDI;
    uint64_t uVar6;
    int64_t in_R8;
    uint64_t in_R9;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_28;
    
    uStack_28 = 0x180237e02;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_60h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar3);
    *(int32_t *)((int64_t)aiStackX_18 + iVar3 + -0x18) = (int32_t)in_R9;
    if ((in_R9 & 0x30000) == 0) goto code_r0x00018023802b;
    *(undefined8 *)((int64_t)&arg_90h + iVar3) = unaff_RBX;
    uVar4 = 0;
    uVar5 = 0;
    *(undefined8 *)((int64_t)&arg_88h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_80h + iVar3) = unaff_RDI;
    uVar6 = uVar4;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237e5f;
        in_RDX = fcn.180222340(in_R8);
        uVar6 = 1;
        if (in_RDX != 0) goto code_r0x000180237e72;
    } else {
code_r0x000180237e72:
        uVar1 = *(undefined8 *)(in_RDX + 0x50);
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237e7b;
        uVar4 = func_0x000180235930(uVar1);
    }
    if (in_R8 == 0) {
        if (uVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237e9b;
            iVar2 = fcn.18022fc40(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18), 
                                  *(int64_t *)((int64_t)&var_8h + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)(&stack0x00000058 + iVar3));
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237eb7;
                iVar2 = func_0x00018022f7c0(uVar4, (int64_t)aiStackX_18 + iVar3 + -8, 0x50, (int64_t)&var_8h + iVar3);
                if (iVar2 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237ed1;
                    func_0x00018022d1b0((int64_t)aiStackX_18 + iVar3 + -8);
                }
            }
        }
    } else {
        *(undefined8 *)((int64_t)&arg_78h + iVar3) = unaff_R15;
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f21;
        iVar2 = fcn.180237590(in_RDX);
        if (iVar2 == 2) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f44;
            iVar2 = fcn.180238490(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18), 
                                  *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar3));
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f59;
                iVar2 = fcn.180222010(in_R8);
                uVar5 = (uint32_t)uVar6;
                if ((int32_t)(uint32_t)uVar6 < iVar2) {
                    do {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f68;
                        func_0x00018021fee0(in_RDX);
                        uVar5 = (uint32_t)uVar6;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f75;
                        in_RDX = fcn.180222340(in_R8, uVar6);
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f80;
                        iVar2 = fcn.180237590(in_RDX);
                        if (iVar2 != 2) goto code_r0x000180238000;
                        if (in_RDX != 0) {
                            uVar1 = *(undefined8 *)(in_RDX + 0x50);
                            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237f9c;
                            func_0x000180235930(uVar1);
                        }
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237faf;
                        iVar2 = fcn.180238490(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18), 
                                              *(int64_t *)(&stack0x00000050 + iVar3), 
                                              *(int64_t *)((int64_t)&arg_60h + iVar3));
                        if (iVar2 != 0) goto code_r0x000180237fe0;
                        uVar5 = uVar5 + 1;
                        uVar6 = (uint64_t)uVar5;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237fbf;
                        iVar2 = fcn.180222010(in_R8);
                    } while ((int32_t)uVar5 < iVar2);
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237fcb;
                func_0x00018021fee0(in_RDX);
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x180237fda;
                iVar2 = fcn.180238490(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18), 
                                      *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar3));
                if (iVar2 == 0) goto code_r0x00018023802b;
            }
code_r0x000180237fe0:
            if ((iVar2 - 0x3bU < 2) && (uVar5 != 0)) {
                uVar5 = uVar5 - 1;
            }
        } else {
            uVar5 = 0;
        }
code_r0x000180238000:
        if (in_RCX != (uint32_t *)0x0) {
            *in_RCX = uVar5;
        }
    }
code_r0x00018023802b:
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18023803b;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_60h + iVar3) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar3));
    return;
}

// ============================================================
// Function: FUN_180238060
// Address: 0x180238060
// Size: 34 bytes
// ============================================================
int64_t fcn.180238060(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int32_t iVar5;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023806c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180238074;
    iVar3 = fcn.180221950(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
    if (iVar3 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
    iVar5 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180238091;
    iVar1 = fcn.180222010(iVar3);
    if (0 < iVar1) {
        do {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023809f;
            uVar4 = fcn.180222340(iVar3, iVar5);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802380a7;
            iVar1 = fcn.1802375f0(uVar4);
            if (iVar1 == 0) {
                while (0 < iVar5) {
                    iVar5 = iVar5 + -1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802380dc;
                    uVar4 = fcn.180222340(iVar3, iVar5);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802380e4;
                    fcn.18021fe80(uVar4);
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802380f0;
                fcn.180221d50(iVar3);
                return 0;
            }
            iVar5 = iVar5 + 1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802380b5;
            iVar1 = fcn.180222010(iVar3);
        } while (iVar5 < iVar1);
    }
    return iVar3;
}

// ============================================================
// Function: FUN_180238082
// Address: 0x180238082
// Size: 69 bytes
// ============================================================
int64_t fcn.180238060(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int32_t iVar5;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023806c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180238074;
    iVar3 = fcn.180221950(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
    if (iVar3 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
    iVar5 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180238091;
    iVar1 = fcn.180222010(iVar3);
    if (0 < iVar1) {
        do {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023809f;
            uVar4 = fcn.180222340(iVar3, iVar5);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802380a7;
            iVar1 = fcn.1802375f0(uVar4);
            if (iVar1 == 0) {
                while (0 < iVar5) {
                    iVar5 = iVar5 + -1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802380dc;
                    uVar4 = fcn.180222340(iVar3, iVar5);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802380e4;
                    fcn.18021fe80(uVar4);
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802380f0;
                fcn.180221d50(iVar3);
                return 0;
            }
            iVar5 = iVar5 + 1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802380b5;
            iVar1 = fcn.180222010(iVar3);
        } while (iVar5 < iVar1);
    }
    return iVar3;
}

// ============================================================
// Function: FUN_1802380c7
// Address: 0x1802380c7
// Size: 54 bytes
// ============================================================
int64_t fcn.180238060(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int32_t iVar5;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023806c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180238074;
    iVar3 = fcn.180221950(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
    if (iVar3 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
    iVar5 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180238091;
    iVar1 = fcn.180222010(iVar3);
    if (0 < iVar1) {
        do {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023809f;
            uVar4 = fcn.180222340(iVar3, iVar5);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802380a7;
            iVar1 = fcn.1802375f0(uVar4);
            if (iVar1 == 0) {
                while (0 < iVar5) {
                    iVar5 = iVar5 + -1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802380dc;
                    uVar4 = fcn.180222340(iVar3, iVar5);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802380e4;
                    fcn.18021fe80(uVar4);
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802380f0;
                fcn.180221d50(iVar3);
                return 0;
            }
            iVar5 = iVar5 + 1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802380b5;
            iVar1 = fcn.180222010(iVar3);
        } while (iVar5 < iVar1);
    }
    return iVar3;
}

// ============================================================
// Function: FUN_180238100
// Address: 0x180238100
// Size: 248 bytes
// ============================================================
undefined8 fcn.180238100(int64_t param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023810c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (param_1 != 0) {
        uVar4 = *(undefined8 *)(param_1 + 0x50);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180238124;
        iVar3 = fcn.180235930(uVar4);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180238138;
            uVar4 = fcn.18022ebc0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000028 + iVar2)
                                  , *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                                  *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2), 
                                  *(int64_t *)(&stack0x000000a8 + iVar2));
            iVar1 = (int32_t)uVar4;
            if (iVar1 == -2) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802381a2;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802381ba;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar2));
            } else if (iVar1 == -1) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023817e;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180238196;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar2));
            } else {
                if (iVar1 != 0) {
                    if (iVar1 != 1) {
                        return 0;
                    }
                    return uVar4;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023815a;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180238172;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar2));
            }
            goto code_r0x0001802381e3;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802381c6;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802381de;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
code_r0x0001802381e3:
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802381f0;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_180238200
// Address: 0x180238200
// Size: 237 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_7ch because it doesn't fit into ProtoModel

uint32_t fcn.180238200(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h, int64_t arg_70h,
                      int64_t arg_d8h, int64_t arg_120h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180238215;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar3 = 0;
    if (in_RCX == in_RDX) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023824b;
    fcn.18023bad0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180238258;
    fcn.18023bad0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
    if (((*(uint32_t *)(in_RCX + 0xd8) & 0x100000) == 0) && ((*(uint32_t *)(in_RDX + 0xd8) & 0x100000) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180238289;
        iVar3 = fcn.180497f30(in_RCX + 0x128, in_RDX + 0x128, 0x14);
        if (iVar3 != 0) {
            return (iVar3 >> 0x1f & 0xfffffffeU) + 1;
        }
    }
    if ((*(int32_t *)(in_RCX + 0x7c) == 0) && (*(int32_t *)(in_RDX + 0x7c) == 0)) {
        iVar3 = *(int32_t *)(in_RCX + 0x78);
        if (iVar3 < *(int32_t *)(in_RDX + 0x78)) {
            return 0xffffffff;
        }
        if (*(int32_t *)(in_RDX + 0x78) < iVar3) {
            return 1;
        }
        uVar1 = *(undefined8 *)(in_RDX + 0x70);
        uVar2 = *(undefined8 *)(in_RCX + 0x70);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802382c8;
        iVar3 = fcn.180497f30(uVar2, uVar1, (int64_t)iVar3);
        if (iVar3 < 0) {
            return 0xffffffff;
        }
    }
    return (uint32_t)(0 < iVar3);
}

// ============================================================
// Function: FUN_1802382f0
// Address: 0x1802382f0
// Size: 262 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1802382f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    int64_t in_RDX;
    int32_t iVar5;
    bool bVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180238310;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar5 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180238320;
    iVar2 = fcn.180222010();
    if (0 < iVar2) {
        do {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023833a;
            iVar4 = fcn.180222340(in_RCX, iVar5);
            iVar1 = *(int64_t *)(iVar4 + 0x48);
            if (in_RDX == 0) {
                bVar6 = iVar1 != 0;
code_r0x0001802383be:
                if (!bVar6) {
                    return iVar4;
                }
            } else if (iVar1 != 0) {
                if ((*(int64_t *)(iVar1 + 0x18) == 0) || (*(int32_t *)(iVar1 + 8) != 0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023836c;
                    iVar2 = fcn.180234b40(iVar1, 0);
                    if (iVar2 < 0) goto code_r0x0001802383c2;
                }
                if ((*(int64_t *)(in_RDX + 0x18) == 0) || (*(int32_t *)(in_RDX + 8) != 0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180238387;
                    iVar2 = fcn.180234b40(in_RDX, 0);
                    if (iVar2 < 0) goto code_r0x0001802383c2;
                }
                iVar2 = *(int32_t *)(iVar1 + 0x20) - *(int32_t *)(in_RDX + 0x20);
                if (iVar2 == 0) {
                    if (*(int32_t *)(iVar1 + 0x20) == 0) {
                        return iVar4;
                    }
                    if ((*(int64_t *)(iVar1 + 0x18) == 0) || (*(int64_t *)(in_RDX + 0x18) == 0))
                    goto code_r0x0001802383c2;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802383b3;
                    iVar2 = fcn.180497f30();
                }
                if (-1 < iVar2) {
                    bVar6 = 0 < iVar2;
                    goto code_r0x0001802383be;
                }
            }
code_r0x0001802383c2:
            iVar5 = iVar5 + 1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802383cc;
            iVar2 = fcn.180222010(in_RCX);
        } while (iVar5 < iVar2);
    }
    return 0;
}

// ============================================================
// Function: FUN_180238400
// Address: 0x180238400
// Size: 38 bytes
// ============================================================
int64_t fcn.180238400(int64_t param_1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_1 == 0) {
        return 0;
    }
    iVar2 = *(int64_t *)(param_1 + 0x50);
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x18023593a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar1 + iVar3) = 0x180235947;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar1 + iVar3), *(int64_t *)(&stack0x00000050 + iVar1 + iVar3));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar1 + iVar3) = 0x18023595f;
        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar1 + iVar3), *(int64_t *)(&stack0x00000050 + iVar1 + iVar3), 
                      *(int64_t *)(&stack0x00000058 + iVar1 + iVar3), *(int64_t *)(&stack0x00000060 + iVar1 + iVar3), 
                      *(int64_t *)(&stack0x00000078 + iVar1 + iVar3));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar1 + iVar3) = 0x180235971;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar1 + iVar3));
        return 0;
    }
    iVar2 = *(int64_t *)(iVar2 + 0x10);
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar1 + iVar3) = 0x180235986;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar1 + iVar3), *(int64_t *)(&stack0x00000050 + iVar1 + iVar3));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar1 + iVar3) = 0x18023599e;
        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar1 + iVar3), *(int64_t *)(&stack0x00000050 + iVar1 + iVar3), 
                      *(int64_t *)(&stack0x00000058 + iVar1 + iVar3), *(int64_t *)(&stack0x00000060 + iVar1 + iVar3), 
                      *(int64_t *)(&stack0x00000078 + iVar1 + iVar3));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar1 + iVar3) = 0x1802359b0;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar1 + iVar3));
        iVar2 = 0;
    }
    return iVar2;
}

// ============================================================
// Function: FUN_180238430
// Address: 0x180238430
// Size: 38 bytes
// ============================================================
int64_t fcn.180238430(int64_t arg_48h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == 0) {
        return 0;
    }
    iVar4 = *(int64_t *)(in_RCX + 0x50);
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x18023584a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar3) = 0x180235857;
        fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar2 + iVar3), *(int64_t *)(&stack0x00000050 + iVar2 + iVar3));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar3) = 0x18023586f;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar2 + iVar3), *(int64_t *)(&stack0x00000050 + iVar2 + iVar3), 
                      *(int64_t *)(&stack0x00000058 + iVar2 + iVar3), *(int64_t *)(&stack0x00000060 + iVar2 + iVar3), 
                      *(int64_t *)(&stack0x00000078 + iVar2 + iVar3));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar3) = 0x180235881;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar2 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar2 + iVar3) = unaff_RBX;
    iVar4 = *(int64_t *)(iVar4 + 0x10);
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar3) = 0x18023589b;
        fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar2 + iVar3), *(int64_t *)(&stack0x00000050 + iVar2 + iVar3));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar3) = 0x1802358b3;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar2 + iVar3), *(int64_t *)(&stack0x00000050 + iVar2 + iVar3), 
                      *(int64_t *)(&stack0x00000058 + iVar2 + iVar3), *(int64_t *)(&stack0x00000060 + iVar2 + iVar3), 
                      *(int64_t *)(&stack0x00000078 + iVar2 + iVar3));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar3) = 0x1802358c5;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar2 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar3) = 0x1802358d9;
    iVar1 = fcn.1802308d0(iVar4);
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar3) = 0x1802358e2;
        fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar2 + iVar3), *(int64_t *)(&stack0x00000050 + iVar2 + iVar3));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar3) = 0x1802358fa;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar2 + iVar3), *(int64_t *)(&stack0x00000050 + iVar2 + iVar3), 
                      *(int64_t *)(&stack0x00000058 + iVar2 + iVar3), *(int64_t *)(&stack0x00000060 + iVar2 + iVar3), 
                      *(int64_t *)(&stack0x00000078 + iVar2 + iVar3));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar3) = 0x18023590c;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar2 + iVar3));
        return 0;
    }
    return iVar4;
}

// ============================================================
// Function: FUN_180238470
// Address: 0x180238470
// Size: 30 bytes
// ============================================================
uint64_t fcn.180238470(int64_t param_1, int64_t param_2)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar6 = *(int64_t *)(param_2 + 0x48);
    iVar5 = *(int64_t *)(param_1 + 0x48);
    *(undefined8 *)(&stack0x00000030 + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1802378f0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (iVar6 == 0) {
        return (uint64_t)(iVar5 != 0);
    }
    if (iVar5 != 0) {
        if ((*(int64_t *)(iVar5 + 0x18) == 0) || (*(int32_t *)(iVar5 + 8) != 0)) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar3) = 0x18023793a;
            iVar1 = fcn.180234b40();
            if (iVar1 < 0) {
                return 0xfffffffe;
            }
        }
        if ((*(int64_t *)(iVar6 + 0x18) == 0) || (*(int32_t *)(iVar6 + 8) != 0)) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar3) = 0x180237955;
            iVar1 = fcn.180234b40(iVar6, 0);
            if (iVar1 < 0) {
                return 0xfffffffe;
            }
        }
        iVar1 = *(int32_t *)(iVar5 + 0x20);
        iVar4 = iVar1 - *(int32_t *)(iVar6 + 0x20);
        if (iVar4 == 0) {
            if (iVar1 == 0) {
                return (int64_t)iVar1;
            }
            iVar5 = *(int64_t *)(iVar5 + 0x18);
            if ((iVar5 == 0) || (iVar6 = *(int64_t *)(iVar6 + 0x18), iVar6 == 0)) {
                return 0xfffffffe;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar3) = 0x18023798d;
            iVar4 = fcn.180497f30(iVar5, iVar6, (int64_t)iVar1);
        }
        if (-1 < iVar4) {
            return (uint64_t)(0 < iVar4);
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_180238490
// Address: 0x180238490
// Size: 259 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180238490(int64_t arg_28h, int64_t arg_78h, int64_t arg_88h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int32_t in_EDX;
    uint32_t *in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802384a5;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(uint64_t *)((int64_t)&arg_78h + iVar2) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2);
    if (in_RCX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802384d7;
        iVar1 = fcn.18022fc40(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                              *(int64_t *)(&stack0x00000070 + iVar2));
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802384f7;
            iVar1 = func_0x00018022f7c0(in_RCX, (int64_t)&arg_28h + iVar2, 0x50, (int64_t)&var_18h + iVar2);
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180238505;
                iVar1 = func_0x00018022d1b0((int64_t)&arg_28h + iVar2);
                if ((iVar1 == 0x2cb) && (((in_EDX == -1 || (in_EDX == 0x31b)) && ((*in_R8 >> 0x11 & 1) != 0)))) {
                    *in_R8 = *in_R8 & 0xfffeffff;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023857e;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_78h + iVar2) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2));
    return;
}

// ============================================================
// Function: FUN_1802385a0
// Address: 0x1802385a0
// Size: 148 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.1802385a0(int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t *in_RCX;
    int64_t in_RDX;
    int32_t iVar9;
    undefined8 unaff_RBP;
    uint64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802385b5;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar8 = *in_RCX;
    if (iVar8 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802385ce;
        iVar8 = fcn.180221f20();
        *in_RCX = iVar8;
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802385db;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar7), *(int64_t *)((int64_t)aiStackX_18 + iVar7 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802385f3;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar7), *(int64_t *)((int64_t)aiStackX_18 + iVar7 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180238605;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar7));
            return false;
        }
    }
    in_R8 = in_R8 & 0xffffffff;
    uVar1 = *(undefined8 *)((int64_t)&arg_28h + iVar7);
    uVar2 = *(undefined8 *)((int64_t)&arg_30h + iVar7);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7) = *(undefined8 *)((int64_t)aiStackX_18 + iVar7);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + -8) = unaff_R12;
    *(undefined8 *)((int64_t)&var_8h + iVar7) = unaff_R15;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + -0x18) = 0x180237aa0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (iVar8 == 0) {
        *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar7 + -0x18) = 0x180237ab6;
        fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar5 + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar5 + iVar7));
        *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar7 + -0x18) = 0x180237ace;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar5 + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar5 + iVar7), 
                      *(int64_t *)(&stack0x00000038 + iVar5 + iVar7), *(int64_t *)(&stack0x00000040 + iVar5 + iVar7), 
                      *(int64_t *)(&stack0x00000058 + iVar5 + iVar7));
        *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar7 + -0x18) = 0x180237ae0;
        fcn.1802296d0(*(int64_t *)(&stack0x00000048 + iVar5 + iVar7));
        return false;
    }
    *(undefined8 *)(&stack0x00000048 + iVar5 + iVar7) = uVar1;
    *(undefined8 *)(&stack0x00000050 + iVar5 + iVar7) = unaff_RBP;
    *(undefined8 *)(&stack0x00000058 + iVar5 + iVar7) = uVar2;
    *(undefined8 *)(&stack0x00000060 + iVar5 + iVar7) = unaff_R14;
    if (in_RDX != 0) {
        iVar9 = 0;
        if ((in_R8 & 4) != 0) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar7 + -0x18) = 0x180237b1e;
            iVar3 = fcn.180222010();
            if (0 < iVar3) {
                do {
                    *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar7 + -0x18) = 0x180237b30;
                    iVar6 = fcn.180222340(iVar8, iVar9);
                    if (iVar6 == in_RDX) {
                        return true;
                    }
                    *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar7 + -0x18) = 0x180237b4f;
                    fcn.18023bad0(*(int64_t *)((int64_t)&arg_28h + iVar5 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar5 + iVar7));
                    *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar7 + -0x18) = 0x180237b5f;
                    fcn.18023bad0(*(int64_t *)((int64_t)&arg_28h + iVar5 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar5 + iVar7));
                    iVar3 = 0;
                    if (((*(uint32_t *)(iVar6 + 0xd8) & 0x100000) == 0) &&
                       (iVar3 = 0, (*(uint32_t *)(in_RDX + 0xd8) & 0x100000) == 0)) {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar7 + -0x18) = 0x180237b90;
                        iVar3 = fcn.180497f30(iVar6 + 0x128, in_RDX + 0x128, 0x14);
                        if (iVar3 == 0) goto code_r0x000180237ba1;
                        uVar4 = (iVar3 >> 0x1f & 0xfffffffeU) + 1;
code_r0x000180237bd6:
                        if (uVar4 == 0) {
                            return true;
                        }
                    } else {
code_r0x000180237ba1:
                        if ((*(int32_t *)(iVar6 + 0x7c) != 0) || (*(int32_t *)(in_RDX + 0x7c) != 0)) {
code_r0x000180237bce:
                            uVar4 = (uint32_t)(0 < iVar3);
                            goto code_r0x000180237bd6;
                        }
                        iVar3 = *(int32_t *)(iVar6 + 0x78);
                        if ((*(int32_t *)(in_RDX + 0x78) <= iVar3) && (iVar3 <= *(int32_t *)(in_RDX + 0x78))) {
                            uVar1 = *(undefined8 *)(in_RDX + 0x70);
                            uVar2 = *(undefined8 *)(iVar6 + 0x70);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar7 + -0x18) = 0x180237bc8;
                            iVar3 = fcn.180497f30(uVar2, uVar1, (int64_t)iVar3);
                            if (-1 < iVar3) goto code_r0x000180237bce;
                        }
                    }
                    iVar9 = iVar9 + 1;
                    *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar7 + -0x18) = 0x180237be8;
                    iVar3 = fcn.180222010(iVar8);
                } while (iVar9 < iVar3);
            }
        }
        if ((in_R8 & 8) != 0) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar7 + -0x18) = 0x180237c00;
            iVar9 = fcn.18024c670(*(int64_t *)((int64_t)&arg_28h + iVar5 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar5 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar5 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar5 + iVar7), 
                                  *(int64_t *)(&stack0x00000068 + iVar5 + iVar7), 
                                  *(int64_t *)(&stack0x00000070 + iVar5 + iVar7), 
                                  *(int64_t *)(&stack0x00000078 + iVar5 + iVar7), 
                                  *(int64_t *)(&stack0x00000080 + iVar5 + iVar7));
            if (iVar9 != 0) {
                return 0 < iVar9;
            }
        }
        if ((in_R8 & 1) != 0) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar7 + -0x18) = 0x180237c1d;
            iVar9 = fcn.1802375f0(in_RDX);
            if (iVar9 == 0) {
                return false;
            }
        }
        *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar7 + -0x18) = 0x180237c3c;
        iVar9 = fcn.180221da0(*(int64_t *)((int64_t)&arg_28h + iVar5 + iVar7), 
                              *(int64_t *)((int64_t)&arg_30h + iVar5 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar5 + iVar7));
        if (iVar9 != 0) {
            return true;
        }
        if ((in_R8 & 1) != 0) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar7 + -0x18) = 0x180237c4c;
            fcn.18021fe80(in_RDX);
        }
        *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar7 + -0x18) = 0x180237c51;
        fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar5 + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar5 + iVar7));
        *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar7 + -0x18) = 0x180237c69;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar5 + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar5 + iVar7), 
                      *(int64_t *)(&stack0x00000038 + iVar5 + iVar7), *(int64_t *)(&stack0x00000040 + iVar5 + iVar7), 
                      *(int64_t *)(&stack0x00000058 + iVar5 + iVar7));
        *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar7 + -0x18) = 0x180237c7b;
        fcn.1802296d0(*(int64_t *)(&stack0x00000048 + iVar5 + iVar7));
    }
    return false;
}

// ============================================================
// Function: FUN_180238640
// Address: 0x180238640
// Size: 29 bytes
// ============================================================
void fcn.180238640(int32_t *param_1)
{
    int64_t iVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    code *pcVar6;
    int32_t iVar7;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar8;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined8 auStackX_18 [2];
    
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    pcVar6 = fcn.18021fe80;
    if (param_1 != (int32_t *)0x0) {
        *(undefined8 *)(&stack0x00000048 + iVar5) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + 8) = unaff_RSI;
        *(undefined8 *)((int64_t)auStackX_18 + iVar5) = 0x180222069;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        *(undefined8 *)(&stack0x00000050 + iVar4 + iVar5) = unaff_RBX;
        iVar7 = 0;
        *(undefined8 *)(&stack0x00000060 + iVar4 + iVar5) = unaff_R14;
        if (0 < *param_1) {
            *(undefined8 *)(&stack0x00000058 + iVar4 + iVar5) = unaff_RDI;
            iVar8 = 0;
            do {
                iVar1 = *(int64_t *)(iVar8 + *(int64_t *)(param_1 + 2));
                if (iVar1 != 0) {
                    pcVar2 = *(code **)(param_1 + 8);
                    if (pcVar2 == (code *)0x0) {
                        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar5) = 0x1802220b2;
                        (*pcVar6)();
                    } else {
                        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar5) = 0x1802220ae;
                        (*pcVar2)(pcVar6, iVar1);
                    }
                }
                iVar7 = iVar7 + 1;
                iVar8 = iVar8 + 8;
            } while (iVar7 < *param_1);
        }
        uVar3 = *(undefined8 *)(param_1 + 2);
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar5) = 0x1802220d7;
        fcn.180224990(uVar3, 0x1804bf768, 0x1ce);
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar5) = 0x1802220ec;
        fcn.180224990(param_1, 0x1804bf768, 0x1cf);
    }
    return;
}

// ============================================================
// Function: FUN_180238660
// Address: 0x180238660
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h

void fcn.180238660(int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_d8h, int64_t arg_1b8h)
{
    undefined uVar1;
    bool bVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    uint64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_48h;
    undefined8 uStack_28;
    
    uStack_28 = 0x180238675;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4);
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023869b;
    var_a0h = in_RDX;
    iVar3 = func_0x00018028f3a0(in_RDX);
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_d8h + iVar4) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_90h + iVar4) = unaff_R12;
        *(undefined8 *)((int64_t)&arg_88h + iVar4) = unaff_R13;
        *(undefined8 *)((int64_t)&arg_80h + iVar4) = unaff_R14;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802386cb;
        iVar5 = func_0x00018028f260(in_RDX);
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802386d6;
        iVar6 = func_0x00018028f240(in_RDX);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238797;
            func_0x000180245e70(in_RCX, 0x1804e2bb0, in_R8 & 0xffffffff, 0x1805aadb1);
        } else {
            *(undefined8 *)((int64_t)&var_8h + iVar4) = 0x1805aadb1;
            *(int32_t *)(&stack0x00000000 + iVar4) = (int32_t)in_R8 + 2;
            bVar2 = true;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238710;
            func_0x000180245e70(in_RCX, 0x1804e2b98, in_R8 & 0xffffffff, 0x1805aadb1);
            var_a8h._0_4_ = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023871b;
            iVar3 = fcn.180222010(iVar5);
            if ((int32_t)var_a8h < iVar3) {
                do {
                    if (bVar2) {
                        bVar2 = false;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238736;
                        func_0x00018021a9d0(in_RCX, 0x180641928);
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238748;
                    uVar7 = fcn.180222340(iVar5, (int32_t)var_a8h);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023875c;
                    func_0x00018022cd40(&var_98h, 0x50, uVar7, 0);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238768;
                    func_0x00018021a9d0(in_RCX, &var_98h);
                    var_a8h._0_4_ = (int32_t)var_a8h + 1;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238773;
                    iVar3 = fcn.180222010(iVar5);
                } while ((int32_t)var_a8h < iVar3);
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238789;
            func_0x00018021a9d0(in_RCX, 0x1805ab2a0);
        }
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238855;
            func_0x000180245e70(in_RCX, 0x1804e2be0, in_R8 & 0xffffffff, 0x1805aadb1);
        } else {
            *(undefined8 *)((int64_t)&var_8h + iVar4) = 0x1805aadb1;
            *(int32_t *)(&stack0x00000000 + iVar4) = (int32_t)in_R8 + 2;
            bVar2 = true;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802387cd;
            func_0x000180245e70(in_RCX, 0x1804e2bc8, in_R8 & 0xffffffff, 0x1805aadb1);
            var_a8h._0_4_ = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802387d8;
            iVar3 = fcn.180222010(iVar6);
            if ((int32_t)var_a8h < iVar3) {
                do {
                    if (bVar2) {
                        bVar2 = false;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802387f4;
                        func_0x00018021a9d0(in_RCX, 0x180641928);
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238806;
                    uVar7 = fcn.180222340(iVar6, (int32_t)var_a8h);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023881a;
                    func_0x00018022cd40(&var_98h, 0x50, uVar7, 0);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238826;
                    func_0x00018021a9d0(in_RCX, &var_98h);
                    var_a8h._0_4_ = (int32_t)var_a8h + 1;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238831;
                    iVar3 = fcn.180222010(iVar6);
                } while ((int32_t)var_a8h < iVar3);
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238847;
            func_0x00018021a9d0(in_RCX, 0x1805ab2a0);
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238865;
        iVar5 = func_0x00018028f120(var_a0h, &var_a8h);
        if (iVar5 != 0) {
            *(int64_t *)((int64_t)&var_8h + iVar4) = iVar5;
            *(int32_t *)(&stack0x00000000 + iVar4) = (int32_t)var_a8h;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238893;
            func_0x000180245e70(in_RCX, 0x1804e2bf8, in_R8 & 0xffffffff, 0x1805aadb1);
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023889f;
        iVar5 = func_0x00018028f280(var_a0h, (int64_t)&var_a8h + 4);
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802388bc;
            func_0x000180245e70(in_RCX, 0x1804e2c08, in_R8 & 0xffffffff, 0x1805aadb1);
            var_a8h._0_4_ = 0;
            if (0 < var_a8h._4_4_) {
                do {
                    uVar7 = 0x1805aadb1;
                    if ((int32_t)var_a8h != 0) {
                        uVar7 = 0x1805ab2c8;
                    }
                    uVar1 = *(undefined *)((int32_t)var_a8h + iVar5);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802388f0;
                    func_0x000180245e70(in_RCX, 0x1804e2c14, uVar7, uVar1);
                    var_a8h._0_4_ = (int32_t)var_a8h + 1;
                } while ((int32_t)var_a8h < var_a8h._4_4_);
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238914;
            func_0x00018021b2c0(in_RCX, 0x1805ab2a0, 1);
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238935;
    fcn.180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4));
    return;
}

// ============================================================
// Function: FUN_1802386a3
// Address: 0x1802386a3
// Size: 11 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h

void fcn.180238660(int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_d8h, int64_t arg_1b8h)
{
    undefined uVar1;
    bool bVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    uint64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_48h;
    undefined8 uStack_28;
    
    uStack_28 = 0x180238675;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4);
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023869b;
    var_a0h = in_RDX;
    iVar3 = func_0x00018028f3a0(in_RDX);
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_d8h + iVar4) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_90h + iVar4) = unaff_R12;
        *(undefined8 *)((int64_t)&arg_88h + iVar4) = unaff_R13;
        *(undefined8 *)((int64_t)&arg_80h + iVar4) = unaff_R14;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802386cb;
        iVar5 = func_0x00018028f260(in_RDX);
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802386d6;
        iVar6 = func_0x00018028f240(in_RDX);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238797;
            func_0x000180245e70(in_RCX, 0x1804e2bb0, in_R8 & 0xffffffff, 0x1805aadb1);
        } else {
            *(undefined8 *)((int64_t)&var_8h + iVar4) = 0x1805aadb1;
            *(int32_t *)(&stack0x00000000 + iVar4) = (int32_t)in_R8 + 2;
            bVar2 = true;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238710;
            func_0x000180245e70(in_RCX, 0x1804e2b98, in_R8 & 0xffffffff, 0x1805aadb1);
            var_a8h._0_4_ = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023871b;
            iVar3 = fcn.180222010(iVar5);
            if ((int32_t)var_a8h < iVar3) {
                do {
                    if (bVar2) {
                        bVar2 = false;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238736;
                        func_0x00018021a9d0(in_RCX, 0x180641928);
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238748;
                    uVar7 = fcn.180222340(iVar5, (int32_t)var_a8h);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023875c;
                    func_0x00018022cd40(&var_98h, 0x50, uVar7, 0);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238768;
                    func_0x00018021a9d0(in_RCX, &var_98h);
                    var_a8h._0_4_ = (int32_t)var_a8h + 1;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238773;
                    iVar3 = fcn.180222010(iVar5);
                } while ((int32_t)var_a8h < iVar3);
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238789;
            func_0x00018021a9d0(in_RCX, 0x1805ab2a0);
        }
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238855;
            func_0x000180245e70(in_RCX, 0x1804e2be0, in_R8 & 0xffffffff, 0x1805aadb1);
        } else {
            *(undefined8 *)((int64_t)&var_8h + iVar4) = 0x1805aadb1;
            *(int32_t *)(&stack0x00000000 + iVar4) = (int32_t)in_R8 + 2;
            bVar2 = true;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802387cd;
            func_0x000180245e70(in_RCX, 0x1804e2bc8, in_R8 & 0xffffffff, 0x1805aadb1);
            var_a8h._0_4_ = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802387d8;
            iVar3 = fcn.180222010(iVar6);
            if ((int32_t)var_a8h < iVar3) {
                do {
                    if (bVar2) {
                        bVar2 = false;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802387f4;
                        func_0x00018021a9d0(in_RCX, 0x180641928);
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238806;
                    uVar7 = fcn.180222340(iVar6, (int32_t)var_a8h);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023881a;
                    func_0x00018022cd40(&var_98h, 0x50, uVar7, 0);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238826;
                    func_0x00018021a9d0(in_RCX, &var_98h);
                    var_a8h._0_4_ = (int32_t)var_a8h + 1;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238831;
                    iVar3 = fcn.180222010(iVar6);
                } while ((int32_t)var_a8h < iVar3);
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238847;
            func_0x00018021a9d0(in_RCX, 0x1805ab2a0);
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238865;
        iVar5 = func_0x00018028f120(var_a0h, &var_a8h);
        if (iVar5 != 0) {
            *(int64_t *)((int64_t)&var_8h + iVar4) = iVar5;
            *(int32_t *)(&stack0x00000000 + iVar4) = (int32_t)var_a8h;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238893;
            func_0x000180245e70(in_RCX, 0x1804e2bf8, in_R8 & 0xffffffff, 0x1805aadb1);
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023889f;
        iVar5 = func_0x00018028f280(var_a0h, (int64_t)&var_a8h + 4);
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802388bc;
            func_0x000180245e70(in_RCX, 0x1804e2c08, in_R8 & 0xffffffff, 0x1805aadb1);
            var_a8h._0_4_ = 0;
            if (0 < var_a8h._4_4_) {
                do {
                    uVar7 = 0x1805aadb1;
                    if ((int32_t)var_a8h != 0) {
                        uVar7 = 0x1805ab2c8;
                    }
                    uVar1 = *(undefined *)((int32_t)var_a8h + iVar5);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802388f0;
                    func_0x000180245e70(in_RCX, 0x1804e2c14, uVar7, uVar1);
                    var_a8h._0_4_ = (int32_t)var_a8h + 1;
                } while ((int32_t)var_a8h < var_a8h._4_4_);
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238914;
            func_0x00018021b2c0(in_RCX, 0x1805ab2a0, 1);
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238935;
    fcn.180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4));
    return;
}

// ============================================================
// Function: FUN_1802386ae
// Address: 0x1802386ae
// Size: 259 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h

void fcn.180238660(int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_d8h, int64_t arg_1b8h)
{
    undefined uVar1;
    bool bVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    uint64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_48h;
    undefined8 uStack_28;
    
    uStack_28 = 0x180238675;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4);
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023869b;
    var_a0h = in_RDX;
    iVar3 = func_0x00018028f3a0(in_RDX);
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_d8h + iVar4) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_90h + iVar4) = unaff_R12;
        *(undefined8 *)((int64_t)&arg_88h + iVar4) = unaff_R13;
        *(undefined8 *)((int64_t)&arg_80h + iVar4) = unaff_R14;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802386cb;
        iVar5 = func_0x00018028f260(in_RDX);
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802386d6;
        iVar6 = func_0x00018028f240(in_RDX);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238797;
            func_0x000180245e70(in_RCX, 0x1804e2bb0, in_R8 & 0xffffffff, 0x1805aadb1);
        } else {
            *(undefined8 *)((int64_t)&var_8h + iVar4) = 0x1805aadb1;
            *(int32_t *)(&stack0x00000000 + iVar4) = (int32_t)in_R8 + 2;
            bVar2 = true;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238710;
            func_0x000180245e70(in_RCX, 0x1804e2b98, in_R8 & 0xffffffff, 0x1805aadb1);
            var_a8h._0_4_ = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023871b;
            iVar3 = fcn.180222010(iVar5);
            if ((int32_t)var_a8h < iVar3) {
                do {
                    if (bVar2) {
                        bVar2 = false;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238736;
                        func_0x00018021a9d0(in_RCX, 0x180641928);
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238748;
                    uVar7 = fcn.180222340(iVar5, (int32_t)var_a8h);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023875c;
                    func_0x00018022cd40(&var_98h, 0x50, uVar7, 0);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238768;
                    func_0x00018021a9d0(in_RCX, &var_98h);
                    var_a8h._0_4_ = (int32_t)var_a8h + 1;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238773;
                    iVar3 = fcn.180222010(iVar5);
                } while ((int32_t)var_a8h < iVar3);
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238789;
            func_0x00018021a9d0(in_RCX, 0x1805ab2a0);
        }
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238855;
            func_0x000180245e70(in_RCX, 0x1804e2be0, in_R8 & 0xffffffff, 0x1805aadb1);
        } else {
            *(undefined8 *)((int64_t)&var_8h + iVar4) = 0x1805aadb1;
            *(int32_t *)(&stack0x00000000 + iVar4) = (int32_t)in_R8 + 2;
            bVar2 = true;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802387cd;
            func_0x000180245e70(in_RCX, 0x1804e2bc8, in_R8 & 0xffffffff, 0x1805aadb1);
            var_a8h._0_4_ = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802387d8;
            iVar3 = fcn.180222010(iVar6);
            if ((int32_t)var_a8h < iVar3) {
                do {
                    if (bVar2) {
                        bVar2 = false;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802387f4;
                        func_0x00018021a9d0(in_RCX, 0x180641928);
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238806;
                    uVar7 = fcn.180222340(iVar6, (int32_t)var_a8h);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023881a;
                    func_0x00018022cd40(&var_98h, 0x50, uVar7, 0);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238826;
                    func_0x00018021a9d0(in_RCX, &var_98h);
                    var_a8h._0_4_ = (int32_t)var_a8h + 1;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238831;
                    iVar3 = fcn.180222010(iVar6);
                } while ((int32_t)var_a8h < iVar3);
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238847;
            func_0x00018021a9d0(in_RCX, 0x1805ab2a0);
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238865;
        iVar5 = func_0x00018028f120(var_a0h, &var_a8h);
        if (iVar5 != 0) {
            *(int64_t *)((int64_t)&var_8h + iVar4) = iVar5;
            *(int32_t *)(&stack0x00000000 + iVar4) = (int32_t)var_a8h;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238893;
            func_0x000180245e70(in_RCX, 0x1804e2bf8, in_R8 & 0xffffffff, 0x1805aadb1);
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023889f;
        iVar5 = func_0x00018028f280(var_a0h, (int64_t)&var_a8h + 4);
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802388bc;
            func_0x000180245e70(in_RCX, 0x1804e2c08, in_R8 & 0xffffffff, 0x1805aadb1);
            var_a8h._0_4_ = 0;
            if (0 < var_a8h._4_4_) {
                do {
                    uVar7 = 0x1805aadb1;
                    if ((int32_t)var_a8h != 0) {
                        uVar7 = 0x1805ab2c8;
                    }
                    uVar1 = *(undefined *)((int32_t)var_a8h + iVar5);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802388f0;
                    func_0x000180245e70(in_RCX, 0x1804e2c14, uVar7, uVar1);
                    var_a8h._0_4_ = (int32_t)var_a8h + 1;
                } while ((int32_t)var_a8h < var_a8h._4_4_);
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238914;
            func_0x00018021b2c0(in_RCX, 0x1805ab2a0, 1);
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238935;
    fcn.180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4));
    return;
}

// ============================================================
// Function: FUN_1802387b1
// Address: 0x1802387b1
// Size: 193 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h

void fcn.180238660(int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_d8h, int64_t arg_1b8h)
{
    undefined uVar1;
    bool bVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    uint64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_48h;
    undefined8 uStack_28;
    
    uStack_28 = 0x180238675;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4);
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023869b;
    var_a0h = in_RDX;
    iVar3 = func_0x00018028f3a0(in_RDX);
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_d8h + iVar4) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_90h + iVar4) = unaff_R12;
        *(undefined8 *)((int64_t)&arg_88h + iVar4) = unaff_R13;
        *(undefined8 *)((int64_t)&arg_80h + iVar4) = unaff_R14;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802386cb;
        iVar5 = func_0x00018028f260(in_RDX);
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802386d6;
        iVar6 = func_0x00018028f240(in_RDX);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238797;
            func_0x000180245e70(in_RCX, 0x1804e2bb0, in_R8 & 0xffffffff, 0x1805aadb1);
        } else {
            *(undefined8 *)((int64_t)&var_8h + iVar4) = 0x1805aadb1;
            *(int32_t *)(&stack0x00000000 + iVar4) = (int32_t)in_R8 + 2;
            bVar2 = true;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238710;
            func_0x000180245e70(in_RCX, 0x1804e2b98, in_R8 & 0xffffffff, 0x1805aadb1);
            var_a8h._0_4_ = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023871b;
            iVar3 = fcn.180222010(iVar5);
            if ((int32_t)var_a8h < iVar3) {
                do {
                    if (bVar2) {
                        bVar2 = false;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238736;
                        func_0x00018021a9d0(in_RCX, 0x180641928);
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238748;
                    uVar7 = fcn.180222340(iVar5, (int32_t)var_a8h);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023875c;
                    func_0x00018022cd40(&var_98h, 0x50, uVar7, 0);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238768;
                    func_0x00018021a9d0(in_RCX, &var_98h);
                    var_a8h._0_4_ = (int32_t)var_a8h + 1;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238773;
                    iVar3 = fcn.180222010(iVar5);
                } while ((int32_t)var_a8h < iVar3);
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238789;
            func_0x00018021a9d0(in_RCX, 0x1805ab2a0);
        }
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238855;
            func_0x000180245e70(in_RCX, 0x1804e2be0, in_R8 & 0xffffffff, 0x1805aadb1);
        } else {
            *(undefined8 *)((int64_t)&var_8h + iVar4) = 0x1805aadb1;
            *(int32_t *)(&stack0x00000000 + iVar4) = (int32_t)in_R8 + 2;
            bVar2 = true;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802387cd;
            func_0x000180245e70(in_RCX, 0x1804e2bc8, in_R8 & 0xffffffff, 0x1805aadb1);
            var_a8h._0_4_ = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802387d8;
            iVar3 = fcn.180222010(iVar6);
            if ((int32_t)var_a8h < iVar3) {
                do {
                    if (bVar2) {
                        bVar2 = false;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802387f4;
                        func_0x00018021a9d0(in_RCX, 0x180641928);
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238806;
                    uVar7 = fcn.180222340(iVar6, (int32_t)var_a8h);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023881a;
                    func_0x00018022cd40(&var_98h, 0x50, uVar7, 0);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238826;
                    func_0x00018021a9d0(in_RCX, &var_98h);
                    var_a8h._0_4_ = (int32_t)var_a8h + 1;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238831;
                    iVar3 = fcn.180222010(iVar6);
                } while ((int32_t)var_a8h < iVar3);
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238847;
            func_0x00018021a9d0(in_RCX, 0x1805ab2a0);
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238865;
        iVar5 = func_0x00018028f120(var_a0h, &var_a8h);
        if (iVar5 != 0) {
            *(int64_t *)((int64_t)&var_8h + iVar4) = iVar5;
            *(int32_t *)(&stack0x00000000 + iVar4) = (int32_t)var_a8h;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238893;
            func_0x000180245e70(in_RCX, 0x1804e2bf8, in_R8 & 0xffffffff, 0x1805aadb1);
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023889f;
        iVar5 = func_0x00018028f280(var_a0h, (int64_t)&var_a8h + 4);
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802388bc;
            func_0x000180245e70(in_RCX, 0x1804e2c08, in_R8 & 0xffffffff, 0x1805aadb1);
            var_a8h._0_4_ = 0;
            if (0 < var_a8h._4_4_) {
                do {
                    uVar7 = 0x1805aadb1;
                    if ((int32_t)var_a8h != 0) {
                        uVar7 = 0x1805ab2c8;
                    }
                    uVar1 = *(undefined *)((int32_t)var_a8h + iVar5);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802388f0;
                    func_0x000180245e70(in_RCX, 0x1804e2c14, uVar7, uVar1);
                    var_a8h._0_4_ = (int32_t)var_a8h + 1;
                } while ((int32_t)var_a8h < var_a8h._4_4_);
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238914;
            func_0x00018021b2c0(in_RCX, 0x1805ab2a0, 1);
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238935;
    fcn.180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4));
    return;
}

// ============================================================
// Function: FUN_180238872
// Address: 0x180238872
// Size: 183 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h

void fcn.180238660(int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_d8h, int64_t arg_1b8h)
{
    undefined uVar1;
    bool bVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    uint64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_48h;
    undefined8 uStack_28;
    
    uStack_28 = 0x180238675;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4);
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023869b;
    var_a0h = in_RDX;
    iVar3 = func_0x00018028f3a0(in_RDX);
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_d8h + iVar4) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_90h + iVar4) = unaff_R12;
        *(undefined8 *)((int64_t)&arg_88h + iVar4) = unaff_R13;
        *(undefined8 *)((int64_t)&arg_80h + iVar4) = unaff_R14;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802386cb;
        iVar5 = func_0x00018028f260(in_RDX);
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802386d6;
        iVar6 = func_0x00018028f240(in_RDX);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238797;
            func_0x000180245e70(in_RCX, 0x1804e2bb0, in_R8 & 0xffffffff, 0x1805aadb1);
        } else {
            *(undefined8 *)((int64_t)&var_8h + iVar4) = 0x1805aadb1;
            *(int32_t *)(&stack0x00000000 + iVar4) = (int32_t)in_R8 + 2;
            bVar2 = true;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238710;
            func_0x000180245e70(in_RCX, 0x1804e2b98, in_R8 & 0xffffffff, 0x1805aadb1);
            var_a8h._0_4_ = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023871b;
            iVar3 = fcn.180222010(iVar5);
            if ((int32_t)var_a8h < iVar3) {
                do {
                    if (bVar2) {
                        bVar2 = false;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238736;
                        func_0x00018021a9d0(in_RCX, 0x180641928);
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238748;
                    uVar7 = fcn.180222340(iVar5, (int32_t)var_a8h);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023875c;
                    func_0x00018022cd40(&var_98h, 0x50, uVar7, 0);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238768;
                    func_0x00018021a9d0(in_RCX, &var_98h);
                    var_a8h._0_4_ = (int32_t)var_a8h + 1;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238773;
                    iVar3 = fcn.180222010(iVar5);
                } while ((int32_t)var_a8h < iVar3);
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238789;
            func_0x00018021a9d0(in_RCX, 0x1805ab2a0);
        }
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238855;
            func_0x000180245e70(in_RCX, 0x1804e2be0, in_R8 & 0xffffffff, 0x1805aadb1);
        } else {
            *(undefined8 *)((int64_t)&var_8h + iVar4) = 0x1805aadb1;
            *(int32_t *)(&stack0x00000000 + iVar4) = (int32_t)in_R8 + 2;
            bVar2 = true;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802387cd;
            func_0x000180245e70(in_RCX, 0x1804e2bc8, in_R8 & 0xffffffff, 0x1805aadb1);
            var_a8h._0_4_ = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802387d8;
            iVar3 = fcn.180222010(iVar6);
            if ((int32_t)var_a8h < iVar3) {
                do {
                    if (bVar2) {
                        bVar2 = false;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802387f4;
                        func_0x00018021a9d0(in_RCX, 0x180641928);
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238806;
                    uVar7 = fcn.180222340(iVar6, (int32_t)var_a8h);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023881a;
                    func_0x00018022cd40(&var_98h, 0x50, uVar7, 0);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238826;
                    func_0x00018021a9d0(in_RCX, &var_98h);
                    var_a8h._0_4_ = (int32_t)var_a8h + 1;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238831;
                    iVar3 = fcn.180222010(iVar6);
                } while ((int32_t)var_a8h < iVar3);
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238847;
            func_0x00018021a9d0(in_RCX, 0x1805ab2a0);
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238865;
        iVar5 = func_0x00018028f120(var_a0h, &var_a8h);
        if (iVar5 != 0) {
            *(int64_t *)((int64_t)&var_8h + iVar4) = iVar5;
            *(int32_t *)(&stack0x00000000 + iVar4) = (int32_t)var_a8h;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238893;
            func_0x000180245e70(in_RCX, 0x1804e2bf8, in_R8 & 0xffffffff, 0x1805aadb1);
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023889f;
        iVar5 = func_0x00018028f280(var_a0h, (int64_t)&var_a8h + 4);
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802388bc;
            func_0x000180245e70(in_RCX, 0x1804e2c08, in_R8 & 0xffffffff, 0x1805aadb1);
            var_a8h._0_4_ = 0;
            if (0 < var_a8h._4_4_) {
                do {
                    uVar7 = 0x1805aadb1;
                    if ((int32_t)var_a8h != 0) {
                        uVar7 = 0x1805ab2c8;
                    }
                    uVar1 = *(undefined *)((int32_t)var_a8h + iVar5);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802388f0;
                    func_0x000180245e70(in_RCX, 0x1804e2c14, uVar7, uVar1);
                    var_a8h._0_4_ = (int32_t)var_a8h + 1;
                } while ((int32_t)var_a8h < var_a8h._4_4_);
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238914;
            func_0x00018021b2c0(in_RCX, 0x1805ab2a0, 1);
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238935;
    fcn.180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4));
    return;
}

// ============================================================
// Function: FUN_180238929
// Address: 0x180238929
// Size: 32 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h

void fcn.180238660(int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_d8h, int64_t arg_1b8h)
{
    undefined uVar1;
    bool bVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    uint64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_48h;
    undefined8 uStack_28;
    
    uStack_28 = 0x180238675;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4);
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023869b;
    var_a0h = in_RDX;
    iVar3 = func_0x00018028f3a0(in_RDX);
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_d8h + iVar4) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_90h + iVar4) = unaff_R12;
        *(undefined8 *)((int64_t)&arg_88h + iVar4) = unaff_R13;
        *(undefined8 *)((int64_t)&arg_80h + iVar4) = unaff_R14;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802386cb;
        iVar5 = func_0x00018028f260(in_RDX);
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802386d6;
        iVar6 = func_0x00018028f240(in_RDX);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238797;
            func_0x000180245e70(in_RCX, 0x1804e2bb0, in_R8 & 0xffffffff, 0x1805aadb1);
        } else {
            *(undefined8 *)((int64_t)&var_8h + iVar4) = 0x1805aadb1;
            *(int32_t *)(&stack0x00000000 + iVar4) = (int32_t)in_R8 + 2;
            bVar2 = true;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238710;
            func_0x000180245e70(in_RCX, 0x1804e2b98, in_R8 & 0xffffffff, 0x1805aadb1);
            var_a8h._0_4_ = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023871b;
            iVar3 = fcn.180222010(iVar5);
            if ((int32_t)var_a8h < iVar3) {
                do {
                    if (bVar2) {
                        bVar2 = false;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238736;
                        func_0x00018021a9d0(in_RCX, 0x180641928);
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238748;
                    uVar7 = fcn.180222340(iVar5, (int32_t)var_a8h);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023875c;
                    func_0x00018022cd40(&var_98h, 0x50, uVar7, 0);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238768;
                    func_0x00018021a9d0(in_RCX, &var_98h);
                    var_a8h._0_4_ = (int32_t)var_a8h + 1;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238773;
                    iVar3 = fcn.180222010(iVar5);
                } while ((int32_t)var_a8h < iVar3);
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238789;
            func_0x00018021a9d0(in_RCX, 0x1805ab2a0);
        }
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238855;
            func_0x000180245e70(in_RCX, 0x1804e2be0, in_R8 & 0xffffffff, 0x1805aadb1);
        } else {
            *(undefined8 *)((int64_t)&var_8h + iVar4) = 0x1805aadb1;
            *(int32_t *)(&stack0x00000000 + iVar4) = (int32_t)in_R8 + 2;
            bVar2 = true;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802387cd;
            func_0x000180245e70(in_RCX, 0x1804e2bc8, in_R8 & 0xffffffff, 0x1805aadb1);
            var_a8h._0_4_ = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802387d8;
            iVar3 = fcn.180222010(iVar6);
            if ((int32_t)var_a8h < iVar3) {
                do {
                    if (bVar2) {
                        bVar2 = false;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802387f4;
                        func_0x00018021a9d0(in_RCX, 0x180641928);
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238806;
                    uVar7 = fcn.180222340(iVar6, (int32_t)var_a8h);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023881a;
                    func_0x00018022cd40(&var_98h, 0x50, uVar7, 0);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238826;
                    func_0x00018021a9d0(in_RCX, &var_98h);
                    var_a8h._0_4_ = (int32_t)var_a8h + 1;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238831;
                    iVar3 = fcn.180222010(iVar6);
                } while ((int32_t)var_a8h < iVar3);
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238847;
            func_0x00018021a9d0(in_RCX, 0x1805ab2a0);
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238865;
        iVar5 = func_0x00018028f120(var_a0h, &var_a8h);
        if (iVar5 != 0) {
            *(int64_t *)((int64_t)&var_8h + iVar4) = iVar5;
            *(int32_t *)(&stack0x00000000 + iVar4) = (int32_t)var_a8h;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238893;
            func_0x000180245e70(in_RCX, 0x1804e2bf8, in_R8 & 0xffffffff, 0x1805aadb1);
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023889f;
        iVar5 = func_0x00018028f280(var_a0h, (int64_t)&var_a8h + 4);
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802388bc;
            func_0x000180245e70(in_RCX, 0x1804e2c08, in_R8 & 0xffffffff, 0x1805aadb1);
            var_a8h._0_4_ = 0;
            if (0 < var_a8h._4_4_) {
                do {
                    uVar7 = 0x1805aadb1;
                    if ((int32_t)var_a8h != 0) {
                        uVar7 = 0x1805ab2c8;
                    }
                    uVar1 = *(undefined *)((int32_t)var_a8h + iVar5);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802388f0;
                    func_0x000180245e70(in_RCX, 0x1804e2c14, uVar7, uVar1);
                    var_a8h._0_4_ = (int32_t)var_a8h + 1;
                } while ((int32_t)var_a8h < var_a8h._4_4_);
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238914;
            func_0x00018021b2c0(in_RCX, 0x1805ab2a0, 1);
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180238935;
    fcn.180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4));
    return;
}

// ============================================================
// Function: FUN_180238950
// Address: 0x180238950
// Size: 174 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h

undefined8
fcn.180238950(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg_58h, int64_t arg_68h,
             int64_t arg_70h)
{
    undefined uVar1;
    int32_t iVar2;
    uint32_t uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int32_t *piVar7;
    undefined8 uVar8;
    int64_t iVar9;
    uint32_t uVar10;
    undefined8 unaff_RBX;
    uint32_t uVar12;
    uint64_t uVar13;
    uint64_t in_R9;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    undefined8 uStack_40;
    int64_t var_10h;
    int64_t var_8h;
    uint64_t uVar11;
    
    var_18h._0_4_ = (undefined4)arg3;
    uStack_40 = 0x18023896a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar11 = 0;
    uVar12 = (uint32_t)arg3 & 0xf0000;
    *(uint32_t *)((int64_t)&var_8h + iVar6 + 4) = uVar12;
    uVar10 = 0;
    uVar3 = 0xc;
    if (uVar12 != 0x40000) {
        uVar3 = uVar10;
    }
    *(uint32_t *)((int64_t)&arg_70h + iVar6) = uVar3;
    uVar4 = 10;
    uVar13 = arg3 & 0xffffffff;
    if (uVar12 != 0x40000) {
        uVar4 = 0x20;
    }
    *(undefined4 *)(&stack0x00000000 + iVar6) = uVar4;
    *(uint32_t *)((int64_t)&var_8h + iVar6) = (uint32_t)((uint32_t)arg3 == 0);
    if ((in_R9 & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1802389dc;
        iVar2 = func_0x00018021b2c0(placeholder_0, 0x1804e29a0, 0xd);
        if (iVar2 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1802389f6;
        iVar2 = func_0x00018021b2c0(placeholder_0, 0x1804e29b0, 10);
        if (iVar2 < 1) {
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar6) = unaff_RBX;
    if ((in_R9 & 2) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238a1b;
        uVar3 = fcn.180237590(placeholder_1);
        if (uVar3 < 3) {
            *(uint32_t *)(&stack0xffffffffffffffe8 + iVar6) = uVar3;
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238a3a;
            iVar2 = func_0x000180245e70(placeholder_0, 0x1804e29c0, 0x1805aadb1, uVar3 + 1);
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238a4b;
            iVar2 = func_0x000180245e70(placeholder_0, 0x1804e29e0, 0x1805aadb1, uVar3);
        }
        if (iVar2 < 1) {
            return 0;
        }
    }
    if ((in_R9 & 4) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238a65;
        piVar7 = (int32_t *)fcn.18000f490(placeholder_1);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238a7d;
        iVar2 = func_0x00018021b2c0(placeholder_0, 0x1804e2a00, 0x16);
        if (iVar2 < 1) {
            return 0;
        }
        if (*piVar7 == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238a99;
            iVar2 = func_0x00018021a9d0(placeholder_0, 0x1804e2c20);
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238aa3;
            fcn.180229b10();
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238ab0;
            iVar5 = func_0x00018025fe40((int64_t)aiStackX_8 + iVar6, piVar7);
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238ab7;
            fcn.1802299d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            iVar2 = piVar7[1];
            if (iVar5 == 0) {
                uVar8 = 0x1805aadb1;
                if (iVar2 == 0x102) {
                    uVar8 = 0x1804e2c48;
                }
                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar6) = uVar8;
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238b3d;
                iVar2 = func_0x000180245e70(placeholder_0, 0x1804e2c54, 0xc, 0x1805aadb1);
                if (iVar2 < 1) {
                    return 0;
                }
                uVar13 = uVar11;
                if (0 < *piVar7 + -1) {
                    do {
                        uVar1 = *(undefined *)(*(int64_t *)(piVar7 + 2) + uVar13);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238b72;
                        iVar2 = func_0x000180245e70(placeholder_0, 0x1804e2c5c, uVar1, 0x3a);
                        if (iVar2 < 1) {
                            return 0;
                        }
                        uVar10 = (int32_t)uVar11 + 1;
                        uVar11 = (uint64_t)uVar10;
                        uVar13 = uVar13 + 1;
                    } while ((int32_t)uVar10 < *piVar7 + -1);
                    uVar12 = *(uint32_t *)((int64_t)&var_8h + iVar6 + 4);
                }
                uVar1 = *(undefined *)(*(int64_t *)(piVar7 + 2) + (int64_t)(int32_t)uVar10);
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238ba7;
                iVar2 = func_0x000180245e70(placeholder_0, 0x1804b8af0, uVar1);
            } else {
                iVar9 = *(int64_t *)((int64_t)aiStackX_8 + iVar6);
                if (iVar2 == 0x102) {
                    iVar9 = -iVar9;
                }
                *(int64_t *)((int64_t)&var_10h + iVar6) = iVar9;
                uVar8 = 0x180641948;
                if (iVar2 != 0x102) {
                    uVar8 = 0x1805aadb1;
                }
                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar6) = uVar8;
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238b00;
                iVar2 = func_0x000180245e70(placeholder_0, 0x1804e2c30);
            }
        }
        if (iVar2 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238bbe;
        iVar2 = func_0x00018021a9d0(placeholder_0, 0x1805ab2a0);
        if (iVar2 < 1) {
            return 0;
        }
        uVar13 = (uint64_t)*(uint32_t *)((int64_t)&arg_68h + iVar6);
    }
    if ((in_R9 & 8) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238bdc;
        uVar8 = func_0x0001800d90d0(placeholder_1);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238bee;
        iVar2 = func_0x00018021a9d0(placeholder_0, 0x1804ba494);
        if (iVar2 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238c04;
        iVar2 = func_0x0001802390d0(placeholder_0, uVar8, 0);
        if (iVar2 < 1) {
            return 0;
        }
    }
    if ((in_R9 & 0x10) == 0) {
        uVar4 = 10;
        if (uVar12 != 0x40000) {
            uVar4 = 0x20;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238c33;
        iVar2 = func_0x000180245e70(placeholder_0, 0x1804e2a18, uVar4);
        if (iVar2 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238c43;
        uVar8 = fcn.1801e3990(placeholder_1);
        uVar4 = *(undefined4 *)((int64_t)&arg_70h + iVar6);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238c5b;
        iVar5 = func_0x0001802a7ff0(placeholder_0, uVar8, uVar4, uVar13);
        iVar2 = *(int32_t *)((int64_t)&var_8h + iVar6);
        if (iVar5 < iVar2) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238c7c;
        iVar5 = func_0x00018021b2c0(placeholder_0, 0x1805ab2a0, 1);
        if (iVar5 < 1) {
            return 0;
        }
    } else {
        uVar4 = *(undefined4 *)((int64_t)&arg_70h + iVar6);
        iVar2 = *(int32_t *)((int64_t)&var_8h + iVar6);
    }
    if ((in_R9 & 0x20) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238cb0;
        iVar5 = func_0x00018021b2c0(placeholder_0, 0x1804e2a30, 0x11);
        if (iVar5 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238ccd;
        iVar5 = func_0x00018021b2c0(placeholder_0, 0x1804e2a48, 0x18);
        if (iVar5 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238cdd;
        uVar8 = func_0x0001801e8e30(placeholder_1);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238ceb;
        iVar5 = func_0x0001802aa5d0(placeholder_0, uVar8, 0);
        if (iVar5 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238d08;
        iVar5 = func_0x00018021b2c0(placeholder_0, 0x1804e2a68, 0x19);
        if (iVar5 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238d18;
        uVar8 = func_0x000180201ea0(placeholder_1);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238d26;
        iVar5 = func_0x0001802aa5d0(placeholder_0, uVar8, 0);
        if (iVar5 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238d43;
        iVar5 = func_0x00018021b2c0(placeholder_0, 0x1805ab2a0, 1);
        if (iVar5 < 1) {
            return 0;
        }
    }
    if ((in_R9 & 0x40) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238d65;
        iVar5 = func_0x000180245e70(placeholder_0, 0x1804e2a88, *(undefined4 *)(&stack0x00000000 + iVar6));
        if (iVar5 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238d75;
        uVar8 = fcn.180238460(placeholder_1);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238d86;
        iVar5 = func_0x0001802a7ff0(placeholder_0, uVar8, uVar4, uVar13);
        if (iVar5 < iVar2) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238da3;
        iVar2 = func_0x00018021b2c0(placeholder_0, 0x1805ab2a0, 1);
        if (iVar2 < 1) {
            return 0;
        }
    }
    if (-1 < (char)in_R9) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238dbc;
        uVar8 = func_0x0001802374f0(placeholder_1);
        *(undefined8 *)(&stack0xffffffffffffffe8 + iVar6) = uVar8;
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238dd3;
        func_0x0001802359c0((int64_t)aiStackX_8 + iVar6, 0, 0, 0);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238de8;
        iVar2 = func_0x00018021b2c0(placeholder_0, 0x1804e2aa0, 0x21);
        if (iVar2 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238e09;
        iVar2 = func_0x000180245e70(placeholder_0, 0x1804e2ac8, 0x1805aadb1);
        if (iVar2 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238e1e;
        iVar2 = func_0x00018027c790(placeholder_0, *(undefined8 *)((int64_t)aiStackX_8 + iVar6));
        if (iVar2 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238e35;
        iVar2 = func_0x00018021a9d0(placeholder_0, 0x1805ab2a0);
        if (iVar2 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238e45;
        iVar9 = fcn.180238400(placeholder_1);
        if (iVar9 == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238e5c;
            func_0x000180245e70(placeholder_0, 0x1804e2ae8, 0x1805aadb1);
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238e64;
            func_0x0001802aad40(placeholder_0);
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238e77;
            func_0x00018022ff40(placeholder_0, iVar9, 0x10, 0);
        }
    }
    uVar12 = (uint32_t)in_R9;
    if ((uVar12 >> 0xc & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238e9c;
        func_0x0001802374d0(placeholder_1, (int64_t)aiStackX_8 + iVar6, (int64_t)&stack0x00000000 + iVar6);
        if (*(int64_t *)((int64_t)aiStackX_8 + iVar6) != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238eb5;
            iVar2 = func_0x000180245e70(placeholder_0, 0x1804e2b08, 0x1805aadb1);
            if (iVar2 < 1) {
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238ed0;
            iVar2 = func_0x000180238fb0(placeholder_0, *(undefined8 *)((int64_t)aiStackX_8 + iVar6), 0xc);
            if (iVar2 == 0) {
                return 0;
            }
        }
        if (*(int64_t *)(&stack0x00000000 + iVar6) != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238ef1;
            iVar2 = func_0x000180245e70(placeholder_0, 0x1804e2b20, 0x1805aadb1);
            if (iVar2 < 1) {
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238f0c;
            iVar2 = func_0x000180238fb0(placeholder_0, *(undefined8 *)(&stack0x00000000 + iVar6), 0xc);
            if (iVar2 == 0) {
                return 0;
            }
        }
    }
    if ((uVar12 >> 8 & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238f22;
        uVar8 = func_0x00018020f790(placeholder_1);
        *(undefined4 *)(&stack0xffffffffffffffe8 + iVar6) = 8;
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238f3f;
        iVar2 = func_0x0001802ab300(placeholder_0, 0x1804e2b38, uVar8, in_R9 & 0xffffffff);
        if (iVar2 == 0) {
            return 0;
        }
    }
    if ((uVar12 >> 9 & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238f5b;
        func_0x00018021fea0((int64_t)aiStackX_8 + iVar6, (int64_t)&stack0x00000000 + iVar6, placeholder_1);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238f6d;
        iVar2 = func_0x0001802390d0(placeholder_0, *(undefined8 *)(&stack0x00000000 + iVar6), 
                                    *(undefined8 *)((int64_t)aiStackX_8 + iVar6));
        if (iVar2 < 1) {
            return 0;
        }
    }
    if ((uVar12 >> 10 & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238f85;
        iVar2 = fcn.180238660(*(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                              *(int64_t *)(&stack0x00000050 + iVar6), *(int64_t *)(&stack0x00000098 + iVar6), 
                              *(int64_t *)(&stack0x00000178 + iVar6));
        if (iVar2 == 0) {
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1802389fe
// Address: 0x1802389fe
// Size: 1433 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h

undefined8
fcn.180238950(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg_58h, int64_t arg_68h,
             int64_t arg_70h)
{
    undefined uVar1;
    int32_t iVar2;
    uint32_t uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int32_t *piVar7;
    undefined8 uVar8;
    int64_t iVar9;
    uint32_t uVar10;
    undefined8 unaff_RBX;
    uint32_t uVar12;
    uint64_t uVar13;
    uint64_t in_R9;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    undefined8 uStack_40;
    int64_t var_10h;
    int64_t var_8h;
    uint64_t uVar11;
    
    var_18h._0_4_ = (undefined4)arg3;
    uStack_40 = 0x18023896a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar11 = 0;
    uVar12 = (uint32_t)arg3 & 0xf0000;
    *(uint32_t *)((int64_t)&var_8h + iVar6 + 4) = uVar12;
    uVar10 = 0;
    uVar3 = 0xc;
    if (uVar12 != 0x40000) {
        uVar3 = uVar10;
    }
    *(uint32_t *)((int64_t)&arg_70h + iVar6) = uVar3;
    uVar4 = 10;
    uVar13 = arg3 & 0xffffffff;
    if (uVar12 != 0x40000) {
        uVar4 = 0x20;
    }
    *(undefined4 *)(&stack0x00000000 + iVar6) = uVar4;
    *(uint32_t *)((int64_t)&var_8h + iVar6) = (uint32_t)((uint32_t)arg3 == 0);
    if ((in_R9 & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1802389dc;
        iVar2 = func_0x00018021b2c0(placeholder_0, 0x1804e29a0, 0xd);
        if (iVar2 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1802389f6;
        iVar2 = func_0x00018021b2c0(placeholder_0, 0x1804e29b0, 10);
        if (iVar2 < 1) {
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar6) = unaff_RBX;
    if ((in_R9 & 2) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238a1b;
        uVar3 = fcn.180237590(placeholder_1);
        if (uVar3 < 3) {
            *(uint32_t *)(&stack0xffffffffffffffe8 + iVar6) = uVar3;
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238a3a;
            iVar2 = func_0x000180245e70(placeholder_0, 0x1804e29c0, 0x1805aadb1, uVar3 + 1);
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238a4b;
            iVar2 = func_0x000180245e70(placeholder_0, 0x1804e29e0, 0x1805aadb1, uVar3);
        }
        if (iVar2 < 1) {
            return 0;
        }
    }
    if ((in_R9 & 4) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238a65;
        piVar7 = (int32_t *)fcn.18000f490(placeholder_1);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238a7d;
        iVar2 = func_0x00018021b2c0(placeholder_0, 0x1804e2a00, 0x16);
        if (iVar2 < 1) {
            return 0;
        }
        if (*piVar7 == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238a99;
            iVar2 = func_0x00018021a9d0(placeholder_0, 0x1804e2c20);
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238aa3;
            fcn.180229b10();
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238ab0;
            iVar5 = func_0x00018025fe40((int64_t)aiStackX_8 + iVar6, piVar7);
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238ab7;
            fcn.1802299d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            iVar2 = piVar7[1];
            if (iVar5 == 0) {
                uVar8 = 0x1805aadb1;
                if (iVar2 == 0x102) {
                    uVar8 = 0x1804e2c48;
                }
                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar6) = uVar8;
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238b3d;
                iVar2 = func_0x000180245e70(placeholder_0, 0x1804e2c54, 0xc, 0x1805aadb1);
                if (iVar2 < 1) {
                    return 0;
                }
                uVar13 = uVar11;
                if (0 < *piVar7 + -1) {
                    do {
                        uVar1 = *(undefined *)(*(int64_t *)(piVar7 + 2) + uVar13);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238b72;
                        iVar2 = func_0x000180245e70(placeholder_0, 0x1804e2c5c, uVar1, 0x3a);
                        if (iVar2 < 1) {
                            return 0;
                        }
                        uVar10 = (int32_t)uVar11 + 1;
                        uVar11 = (uint64_t)uVar10;
                        uVar13 = uVar13 + 1;
                    } while ((int32_t)uVar10 < *piVar7 + -1);
                    uVar12 = *(uint32_t *)((int64_t)&var_8h + iVar6 + 4);
                }
                uVar1 = *(undefined *)(*(int64_t *)(piVar7 + 2) + (int64_t)(int32_t)uVar10);
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238ba7;
                iVar2 = func_0x000180245e70(placeholder_0, 0x1804b8af0, uVar1);
            } else {
                iVar9 = *(int64_t *)((int64_t)aiStackX_8 + iVar6);
                if (iVar2 == 0x102) {
                    iVar9 = -iVar9;
                }
                *(int64_t *)((int64_t)&var_10h + iVar6) = iVar9;
                uVar8 = 0x180641948;
                if (iVar2 != 0x102) {
                    uVar8 = 0x1805aadb1;
                }
                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar6) = uVar8;
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238b00;
                iVar2 = func_0x000180245e70(placeholder_0, 0x1804e2c30);
            }
        }
        if (iVar2 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238bbe;
        iVar2 = func_0x00018021a9d0(placeholder_0, 0x1805ab2a0);
        if (iVar2 < 1) {
            return 0;
        }
        uVar13 = (uint64_t)*(uint32_t *)((int64_t)&arg_68h + iVar6);
    }
    if ((in_R9 & 8) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238bdc;
        uVar8 = func_0x0001800d90d0(placeholder_1);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238bee;
        iVar2 = func_0x00018021a9d0(placeholder_0, 0x1804ba494);
        if (iVar2 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238c04;
        iVar2 = func_0x0001802390d0(placeholder_0, uVar8, 0);
        if (iVar2 < 1) {
            return 0;
        }
    }
    if ((in_R9 & 0x10) == 0) {
        uVar4 = 10;
        if (uVar12 != 0x40000) {
            uVar4 = 0x20;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238c33;
        iVar2 = func_0x000180245e70(placeholder_0, 0x1804e2a18, uVar4);
        if (iVar2 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238c43;
        uVar8 = fcn.1801e3990(placeholder_1);
        uVar4 = *(undefined4 *)((int64_t)&arg_70h + iVar6);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238c5b;
        iVar5 = func_0x0001802a7ff0(placeholder_0, uVar8, uVar4, uVar13);
        iVar2 = *(int32_t *)((int64_t)&var_8h + iVar6);
        if (iVar5 < iVar2) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238c7c;
        iVar5 = func_0x00018021b2c0(placeholder_0, 0x1805ab2a0, 1);
        if (iVar5 < 1) {
            return 0;
        }
    } else {
        uVar4 = *(undefined4 *)((int64_t)&arg_70h + iVar6);
        iVar2 = *(int32_t *)((int64_t)&var_8h + iVar6);
    }
    if ((in_R9 & 0x20) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238cb0;
        iVar5 = func_0x00018021b2c0(placeholder_0, 0x1804e2a30, 0x11);
        if (iVar5 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238ccd;
        iVar5 = func_0x00018021b2c0(placeholder_0, 0x1804e2a48, 0x18);
        if (iVar5 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238cdd;
        uVar8 = func_0x0001801e8e30(placeholder_1);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238ceb;
        iVar5 = func_0x0001802aa5d0(placeholder_0, uVar8, 0);
        if (iVar5 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238d08;
        iVar5 = func_0x00018021b2c0(placeholder_0, 0x1804e2a68, 0x19);
        if (iVar5 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238d18;
        uVar8 = func_0x000180201ea0(placeholder_1);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238d26;
        iVar5 = func_0x0001802aa5d0(placeholder_0, uVar8, 0);
        if (iVar5 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238d43;
        iVar5 = func_0x00018021b2c0(placeholder_0, 0x1805ab2a0, 1);
        if (iVar5 < 1) {
            return 0;
        }
    }
    if ((in_R9 & 0x40) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238d65;
        iVar5 = func_0x000180245e70(placeholder_0, 0x1804e2a88, *(undefined4 *)(&stack0x00000000 + iVar6));
        if (iVar5 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238d75;
        uVar8 = fcn.180238460(placeholder_1);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238d86;
        iVar5 = func_0x0001802a7ff0(placeholder_0, uVar8, uVar4, uVar13);
        if (iVar5 < iVar2) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238da3;
        iVar2 = func_0x00018021b2c0(placeholder_0, 0x1805ab2a0, 1);
        if (iVar2 < 1) {
            return 0;
        }
    }
    if (-1 < (char)in_R9) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238dbc;
        uVar8 = func_0x0001802374f0(placeholder_1);
        *(undefined8 *)(&stack0xffffffffffffffe8 + iVar6) = uVar8;
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238dd3;
        func_0x0001802359c0((int64_t)aiStackX_8 + iVar6, 0, 0, 0);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238de8;
        iVar2 = func_0x00018021b2c0(placeholder_0, 0x1804e2aa0, 0x21);
        if (iVar2 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238e09;
        iVar2 = func_0x000180245e70(placeholder_0, 0x1804e2ac8, 0x1805aadb1);
        if (iVar2 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238e1e;
        iVar2 = func_0x00018027c790(placeholder_0, *(undefined8 *)((int64_t)aiStackX_8 + iVar6));
        if (iVar2 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238e35;
        iVar2 = func_0x00018021a9d0(placeholder_0, 0x1805ab2a0);
        if (iVar2 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238e45;
        iVar9 = fcn.180238400(placeholder_1);
        if (iVar9 == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238e5c;
            func_0x000180245e70(placeholder_0, 0x1804e2ae8, 0x1805aadb1);
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238e64;
            func_0x0001802aad40(placeholder_0);
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238e77;
            func_0x00018022ff40(placeholder_0, iVar9, 0x10, 0);
        }
    }
    uVar12 = (uint32_t)in_R9;
    if ((uVar12 >> 0xc & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238e9c;
        func_0x0001802374d0(placeholder_1, (int64_t)aiStackX_8 + iVar6, (int64_t)&stack0x00000000 + iVar6);
        if (*(int64_t *)((int64_t)aiStackX_8 + iVar6) != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238eb5;
            iVar2 = func_0x000180245e70(placeholder_0, 0x1804e2b08, 0x1805aadb1);
            if (iVar2 < 1) {
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238ed0;
            iVar2 = func_0x000180238fb0(placeholder_0, *(undefined8 *)((int64_t)aiStackX_8 + iVar6), 0xc);
            if (iVar2 == 0) {
                return 0;
            }
        }
        if (*(int64_t *)(&stack0x00000000 + iVar6) != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238ef1;
            iVar2 = func_0x000180245e70(placeholder_0, 0x1804e2b20, 0x1805aadb1);
            if (iVar2 < 1) {
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238f0c;
            iVar2 = func_0x000180238fb0(placeholder_0, *(undefined8 *)(&stack0x00000000 + iVar6), 0xc);
            if (iVar2 == 0) {
                return 0;
            }
        }
    }
    if ((uVar12 >> 8 & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238f22;
        uVar8 = func_0x00018020f790(placeholder_1);
        *(undefined4 *)(&stack0xffffffffffffffe8 + iVar6) = 8;
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238f3f;
        iVar2 = func_0x0001802ab300(placeholder_0, 0x1804e2b38, uVar8, in_R9 & 0xffffffff);
        if (iVar2 == 0) {
            return 0;
        }
    }
    if ((uVar12 >> 9 & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238f5b;
        func_0x00018021fea0((int64_t)aiStackX_8 + iVar6, (int64_t)&stack0x00000000 + iVar6, placeholder_1);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238f6d;
        iVar2 = func_0x0001802390d0(placeholder_0, *(undefined8 *)(&stack0x00000000 + iVar6), 
                                    *(undefined8 *)((int64_t)aiStackX_8 + iVar6));
        if (iVar2 < 1) {
            return 0;
        }
    }
    if ((uVar12 >> 10 & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238f85;
        iVar2 = fcn.180238660(*(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                              *(int64_t *)(&stack0x00000050 + iVar6), *(int64_t *)(&stack0x00000098 + iVar6), 
                              *(int64_t *)(&stack0x00000178 + iVar6));
        if (iVar2 == 0) {
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_180238f97
// Address: 0x180238f97
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h

undefined8
fcn.180238950(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg_58h, int64_t arg_68h,
             int64_t arg_70h)
{
    undefined uVar1;
    int32_t iVar2;
    uint32_t uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int32_t *piVar7;
    undefined8 uVar8;
    int64_t iVar9;
    uint32_t uVar10;
    undefined8 unaff_RBX;
    uint32_t uVar12;
    uint64_t uVar13;
    uint64_t in_R9;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    undefined8 uStack_40;
    int64_t var_10h;
    int64_t var_8h;
    uint64_t uVar11;
    
    var_18h._0_4_ = (undefined4)arg3;
    uStack_40 = 0x18023896a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar11 = 0;
    uVar12 = (uint32_t)arg3 & 0xf0000;
    *(uint32_t *)((int64_t)&var_8h + iVar6 + 4) = uVar12;
    uVar10 = 0;
    uVar3 = 0xc;
    if (uVar12 != 0x40000) {
        uVar3 = uVar10;
    }
    *(uint32_t *)((int64_t)&arg_70h + iVar6) = uVar3;
    uVar4 = 10;
    uVar13 = arg3 & 0xffffffff;
    if (uVar12 != 0x40000) {
        uVar4 = 0x20;
    }
    *(undefined4 *)(&stack0x00000000 + iVar6) = uVar4;
    *(uint32_t *)((int64_t)&var_8h + iVar6) = (uint32_t)((uint32_t)arg3 == 0);
    if ((in_R9 & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1802389dc;
        iVar2 = func_0x00018021b2c0(placeholder_0, 0x1804e29a0, 0xd);
        if (iVar2 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1802389f6;
        iVar2 = func_0x00018021b2c0(placeholder_0, 0x1804e29b0, 10);
        if (iVar2 < 1) {
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar6) = unaff_RBX;
    if ((in_R9 & 2) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238a1b;
        uVar3 = fcn.180237590(placeholder_1);
        if (uVar3 < 3) {
            *(uint32_t *)(&stack0xffffffffffffffe8 + iVar6) = uVar3;
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238a3a;
            iVar2 = func_0x000180245e70(placeholder_0, 0x1804e29c0, 0x1805aadb1, uVar3 + 1);
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238a4b;
            iVar2 = func_0x000180245e70(placeholder_0, 0x1804e29e0, 0x1805aadb1, uVar3);
        }
        if (iVar2 < 1) {
            return 0;
        }
    }
    if ((in_R9 & 4) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238a65;
        piVar7 = (int32_t *)fcn.18000f490(placeholder_1);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238a7d;
        iVar2 = func_0x00018021b2c0(placeholder_0, 0x1804e2a00, 0x16);
        if (iVar2 < 1) {
            return 0;
        }
        if (*piVar7 == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238a99;
            iVar2 = func_0x00018021a9d0(placeholder_0, 0x1804e2c20);
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238aa3;
            fcn.180229b10();
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238ab0;
            iVar5 = func_0x00018025fe40((int64_t)aiStackX_8 + iVar6, piVar7);
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238ab7;
            fcn.1802299d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            iVar2 = piVar7[1];
            if (iVar5 == 0) {
                uVar8 = 0x1805aadb1;
                if (iVar2 == 0x102) {
                    uVar8 = 0x1804e2c48;
                }
                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar6) = uVar8;
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238b3d;
                iVar2 = func_0x000180245e70(placeholder_0, 0x1804e2c54, 0xc, 0x1805aadb1);
                if (iVar2 < 1) {
                    return 0;
                }
                uVar13 = uVar11;
                if (0 < *piVar7 + -1) {
                    do {
                        uVar1 = *(undefined *)(*(int64_t *)(piVar7 + 2) + uVar13);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238b72;
                        iVar2 = func_0x000180245e70(placeholder_0, 0x1804e2c5c, uVar1, 0x3a);
                        if (iVar2 < 1) {
                            return 0;
                        }
                        uVar10 = (int32_t)uVar11 + 1;
                        uVar11 = (uint64_t)uVar10;
                        uVar13 = uVar13 + 1;
                    } while ((int32_t)uVar10 < *piVar7 + -1);
                    uVar12 = *(uint32_t *)((int64_t)&var_8h + iVar6 + 4);
                }
                uVar1 = *(undefined *)(*(int64_t *)(piVar7 + 2) + (int64_t)(int32_t)uVar10);
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238ba7;
                iVar2 = func_0x000180245e70(placeholder_0, 0x1804b8af0, uVar1);
            } else {
                iVar9 = *(int64_t *)((int64_t)aiStackX_8 + iVar6);
                if (iVar2 == 0x102) {
                    iVar9 = -iVar9;
                }
                *(int64_t *)((int64_t)&var_10h + iVar6) = iVar9;
                uVar8 = 0x180641948;
                if (iVar2 != 0x102) {
                    uVar8 = 0x1805aadb1;
                }
                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar6) = uVar8;
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238b00;
                iVar2 = func_0x000180245e70(placeholder_0, 0x1804e2c30);
            }
        }
        if (iVar2 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238bbe;
        iVar2 = func_0x00018021a9d0(placeholder_0, 0x1805ab2a0);
        if (iVar2 < 1) {
            return 0;
        }
        uVar13 = (uint64_t)*(uint32_t *)((int64_t)&arg_68h + iVar6);
    }
    if ((in_R9 & 8) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238bdc;
        uVar8 = func_0x0001800d90d0(placeholder_1);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238bee;
        iVar2 = func_0x00018021a9d0(placeholder_0, 0x1804ba494);
        if (iVar2 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238c04;
        iVar2 = func_0x0001802390d0(placeholder_0, uVar8, 0);
        if (iVar2 < 1) {
            return 0;
        }
    }
    if ((in_R9 & 0x10) == 0) {
        uVar4 = 10;
        if (uVar12 != 0x40000) {
            uVar4 = 0x20;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238c33;
        iVar2 = func_0x000180245e70(placeholder_0, 0x1804e2a18, uVar4);
        if (iVar2 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238c43;
        uVar8 = fcn.1801e3990(placeholder_1);
        uVar4 = *(undefined4 *)((int64_t)&arg_70h + iVar6);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238c5b;
        iVar5 = func_0x0001802a7ff0(placeholder_0, uVar8, uVar4, uVar13);
        iVar2 = *(int32_t *)((int64_t)&var_8h + iVar6);
        if (iVar5 < iVar2) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238c7c;
        iVar5 = func_0x00018021b2c0(placeholder_0, 0x1805ab2a0, 1);
        if (iVar5 < 1) {
            return 0;
        }
    } else {
        uVar4 = *(undefined4 *)((int64_t)&arg_70h + iVar6);
        iVar2 = *(int32_t *)((int64_t)&var_8h + iVar6);
    }
    if ((in_R9 & 0x20) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238cb0;
        iVar5 = func_0x00018021b2c0(placeholder_0, 0x1804e2a30, 0x11);
        if (iVar5 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238ccd;
        iVar5 = func_0x00018021b2c0(placeholder_0, 0x1804e2a48, 0x18);
        if (iVar5 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238cdd;
        uVar8 = func_0x0001801e8e30(placeholder_1);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238ceb;
        iVar5 = func_0x0001802aa5d0(placeholder_0, uVar8, 0);
        if (iVar5 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238d08;
        iVar5 = func_0x00018021b2c0(placeholder_0, 0x1804e2a68, 0x19);
        if (iVar5 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238d18;
        uVar8 = func_0x000180201ea0(placeholder_1);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238d26;
        iVar5 = func_0x0001802aa5d0(placeholder_0, uVar8, 0);
        if (iVar5 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238d43;
        iVar5 = func_0x00018021b2c0(placeholder_0, 0x1805ab2a0, 1);
        if (iVar5 < 1) {
            return 0;
        }
    }
    if ((in_R9 & 0x40) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238d65;
        iVar5 = func_0x000180245e70(placeholder_0, 0x1804e2a88, *(undefined4 *)(&stack0x00000000 + iVar6));
        if (iVar5 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238d75;
        uVar8 = fcn.180238460(placeholder_1);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238d86;
        iVar5 = func_0x0001802a7ff0(placeholder_0, uVar8, uVar4, uVar13);
        if (iVar5 < iVar2) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238da3;
        iVar2 = func_0x00018021b2c0(placeholder_0, 0x1805ab2a0, 1);
        if (iVar2 < 1) {
            return 0;
        }
    }
    if (-1 < (char)in_R9) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238dbc;
        uVar8 = func_0x0001802374f0(placeholder_1);
        *(undefined8 *)(&stack0xffffffffffffffe8 + iVar6) = uVar8;
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238dd3;
        func_0x0001802359c0((int64_t)aiStackX_8 + iVar6, 0, 0, 0);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238de8;
        iVar2 = func_0x00018021b2c0(placeholder_0, 0x1804e2aa0, 0x21);
        if (iVar2 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238e09;
        iVar2 = func_0x000180245e70(placeholder_0, 0x1804e2ac8, 0x1805aadb1);
        if (iVar2 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238e1e;
        iVar2 = func_0x00018027c790(placeholder_0, *(undefined8 *)((int64_t)aiStackX_8 + iVar6));
        if (iVar2 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238e35;
        iVar2 = func_0x00018021a9d0(placeholder_0, 0x1805ab2a0);
        if (iVar2 < 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238e45;
        iVar9 = fcn.180238400(placeholder_1);
        if (iVar9 == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238e5c;
            func_0x000180245e70(placeholder_0, 0x1804e2ae8, 0x1805aadb1);
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238e64;
            func_0x0001802aad40(placeholder_0);
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238e77;
            func_0x00018022ff40(placeholder_0, iVar9, 0x10, 0);
        }
    }
    uVar12 = (uint32_t)in_R9;
    if ((uVar12 >> 0xc & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238e9c;
        func_0x0001802374d0(placeholder_1, (int64_t)aiStackX_8 + iVar6, (int64_t)&stack0x00000000 + iVar6);
        if (*(int64_t *)((int64_t)aiStackX_8 + iVar6) != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238eb5;
            iVar2 = func_0x000180245e70(placeholder_0, 0x1804e2b08, 0x1805aadb1);
            if (iVar2 < 1) {
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238ed0;
            iVar2 = func_0x000180238fb0(placeholder_0, *(undefined8 *)((int64_t)aiStackX_8 + iVar6), 0xc);
            if (iVar2 == 0) {
                return 0;
            }
        }
        if (*(int64_t *)(&stack0x00000000 + iVar6) != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238ef1;
            iVar2 = func_0x000180245e70(placeholder_0, 0x1804e2b20, 0x1805aadb1);
            if (iVar2 < 1) {
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238f0c;
            iVar2 = func_0x000180238fb0(placeholder_0, *(undefined8 *)(&stack0x00000000 + iVar6), 0xc);
            if (iVar2 == 0) {
                return 0;
            }
        }
    }
    if ((uVar12 >> 8 & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238f22;
        uVar8 = func_0x00018020f790(placeholder_1);
        *(undefined4 *)(&stack0xffffffffffffffe8 + iVar6) = 8;
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238f3f;
        iVar2 = func_0x0001802ab300(placeholder_0, 0x1804e2b38, uVar8, in_R9 & 0xffffffff);
        if (iVar2 == 0) {
            return 0;
        }
    }
    if ((uVar12 >> 9 & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238f5b;
        func_0x00018021fea0((int64_t)aiStackX_8 + iVar6, (int64_t)&stack0x00000000 + iVar6, placeholder_1);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238f6d;
        iVar2 = func_0x0001802390d0(placeholder_0, *(undefined8 *)(&stack0x00000000 + iVar6), 
                                    *(undefined8 *)((int64_t)aiStackX_8 + iVar6));
        if (iVar2 < 1) {
            return 0;
        }
    }
    if ((uVar12 >> 10 & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180238f85;
        iVar2 = fcn.180238660(*(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                              *(int64_t *)(&stack0x00000050 + iVar6), *(int64_t *)(&stack0x00000098 + iVar6), 
                              *(int64_t *)(&stack0x00000178 + iVar6));
        if (iVar2 == 0) {
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_180238fb0
// Address: 0x180238fb0
// Size: 282 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.180238fb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 in_RCX;
    uint32_t *in_RDX;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t in_R8;
    undefined8 uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x180238fd2;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar2 = *in_RDX;
    uVar7 = 0;
    iVar3 = *(int64_t *)(in_RDX + 2);
    uVar8 = uVar7;
    if (0 < (int32_t)uVar2) {
        do {
            iVar5 = (int32_t)uVar8;
            if (iVar5 == (iVar5 / 0x12) * 0x12) {
                if (0 < iVar5) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180239033;
                    iVar4 = func_0x00018021b2c0(in_RCX, 0x1805ab2a0, 1);
                    if (iVar4 < 1) {
                        return false;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180239048;
                iVar4 = func_0x00018021a4a0(in_RCX, in_R8 & 0xffffffff, in_R8 & 0xffffffff);
                if (iVar4 < 1) {
                    return false;
                }
            }
            uVar1 = *(undefined *)(uVar7 + iVar3);
            uVar9 = 0x1805ab2c8;
            if (iVar5 + 1U == uVar2) {
                uVar9 = 0x1805aadb1;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18023907a;
            iVar4 = func_0x000180245e70(in_RCX, 0x1804e2b54, uVar1, uVar9);
            if (iVar4 < 1) {
                return false;
            }
            uVar7 = uVar7 + 1;
            uVar8 = (uint64_t)(iVar5 + 1U);
        } while ((int64_t)uVar7 < (int64_t)(int32_t)uVar2);
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18023909f;
    iVar5 = func_0x00018021b2c0(in_RCX, 0x1805ab2a0, 1);
    return iVar5 == 1;
}

// ============================================================
// Function: FUN_1802390d0
// Address: 0x1802390d0
// Size: 332 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.1802390d0(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h, int64_t arg_60h, int64_t arg_a8h)
{
    undefined uVar1;
    uint32_t uVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    undefined8 in_RCX;
    undefined8 *in_RDX;
    uint64_t uVar10;
    undefined8 unaff_RBP;
    uint32_t *in_R8;
    uint64_t uVar11;
    undefined8 uVar12;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802390e5;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023910a;
    iVar5 = func_0x000180245e70();
    if (0 < iVar5) {
        uVar12 = *in_RDX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023911d;
        iVar5 = func_0x00018027c790(in_RCX, uVar12);
        if (0 < iVar5) {
            if (in_R8 != (uint32_t *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180239146;
                iVar5 = func_0x000180245e70(in_RCX, 0x1804e2b80, 4, 0x1805aadb1);
                if (iVar5 < 1) {
                    return 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180239156;
            iVar5 = fcn.18022cd20(*(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar7), *(int64_t *)(&stack0x00000040 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar7), *(int64_t *)((int64_t)&arg_60h + iVar7));
            if (iVar5 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023916b;
                iVar5 = fcn.1802567e0(*(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7)
                                      , *(int64_t *)(&stack0x00000038 + iVar7), *(int64_t *)(&stack0x00000040 + iVar7), 
                                      *(int64_t *)(&stack0x00000088 + iVar7), *(int64_t *)(&stack0x000000a0 + iVar7));
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023917a;
                    iVar8 = fcn.180247890(*(int64_t *)(&stack0x00000150 + iVar7), *(int64_t *)(&stack0x00000170 + iVar7)
                                          , *(int64_t *)(&stack0x00000178 + iVar7), 
                                          *(int64_t *)(&stack0x00000198 + iVar7));
                    if ((iVar8 != 0) && (pcVar3 = *(code **)(iVar8 + 0xa0), pcVar3 != (code *)0x0)) {
                        *(undefined8 *)((int64_t)&iStackX_20 + iVar7 + -8) = 0;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802391a6;
                        uVar9 = (*pcVar3)(in_RCX, in_RDX, in_R8, 8);
                        return uVar9;
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802391cb;
            iVar5 = func_0x00018021b2c0(in_RCX, 0x1805ab2a0, 1);
            if (iVar5 == 1) {
                if (in_R8 == (uint32_t *)0x0) {
                    return 1;
                }
                uVar11 = 8;
                uVar12 = *(undefined8 *)((int64_t)&arg_50h + iVar7);
                *(undefined8 *)((int64_t)&arg_48h + iVar7) = *(undefined8 *)((int64_t)&arg_48h + iVar7);
                *(undefined8 *)((int64_t)&arg_50h + iVar7) = unaff_RBP;
                *(undefined8 *)(&stack0x00000058 + iVar7) = uVar12;
                *(undefined8 *)(&stack0x00000038 + iVar7) = *(undefined8 *)(&stack0x00000038 + iVar7);
                *(undefined8 *)(&stack0x00000030 + iVar7) = unaff_R12;
                *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_R13;
                *(undefined8 *)((int64_t)&iStackX_20 + iVar7) = unaff_R14;
                *(undefined8 *)((int64_t)&iStackX_20 + iVar7 + -8) = unaff_R15;
                *(undefined8 *)((int64_t)&var_10h + iVar7) = 0x180238fd2;
                iVar6 = fcn.18045a350(in_RCX, in_R8, 8);
                iVar6 = -iVar6;
                uVar2 = *in_R8;
                uVar10 = 0;
                iVar8 = *(int64_t *)(in_R8 + 2);
                uVar9 = uVar10;
                if (0 < (int32_t)uVar2) {
                    do {
                        iVar5 = (int32_t)uVar9;
                        if (iVar5 == (iVar5 / 0x12) * 0x12) {
                            if (0 < iVar5) {
                                *(undefined8 *)((int64_t)&var_10h + iVar6 + iVar7) = 0x180239033;
                                iVar4 = func_0x00018021b2c0(in_RCX, 0x1805ab2a0, 1);
                                if (iVar4 < 1) {
                                    return 0;
                                }
                            }
                            *(undefined8 *)((int64_t)&var_10h + iVar6 + iVar7) = 0x180239048;
                            iVar4 = func_0x00018021a4a0(in_RCX, uVar11 & 0xffffffff, uVar11 & 0xffffffff);
                            if (iVar4 < 1) {
                                return 0;
                            }
                        }
                        uVar1 = *(undefined *)(uVar10 + iVar8);
                        uVar12 = 0x1805ab2c8;
                        if (iVar5 + 1U == uVar2) {
                            uVar12 = 0x1805aadb1;
                        }
                        *(undefined8 *)((int64_t)&var_10h + iVar6 + iVar7) = 0x18023907a;
                        iVar4 = func_0x000180245e70(in_RCX, 0x1804e2b54, uVar1, uVar12);
                        if (iVar4 < 1) {
                            return 0;
                        }
                        uVar10 = uVar10 + 1;
                        uVar9 = (uint64_t)(iVar5 + 1U);
                    } while ((int64_t)uVar10 < (int64_t)(int32_t)uVar2);
                }
                *(undefined8 *)((int64_t)&var_10h + iVar6 + iVar7) = 0x18023909f;
                iVar5 = func_0x00018021b2c0(in_RCX, 0x1805ab2a0, 1);
                return (uint64_t)(iVar5 == 1);
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180239220
// Address: 0x180239220
// Size: 349 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_19h

int32_t fcn.180239220(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    int32_t *in_RDX;
    uint32_t uVar5;
    uint64_t uVar7;
    uint64_t in_R8;
    undefined8 uVar8;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_20 [7];
    int64_t var_19h;
    uint64_t uVar6;
    
    _auStack_20 = 0x180239238;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*in_RDX == 0) {
        *(undefined8 *)(auStack_20 + iVar4) = 0x180239255;
        iVar2 = func_0x00018021a9d0();
    } else {
        *(undefined8 *)(auStack_20 + iVar4) = 0x18023925c;
        fcn.180229b10();
        *(undefined8 *)(auStack_20 + iVar4) = 0x180239269;
        iVar3 = func_0x00018025fe40((int64_t)&arg_40h + iVar4, in_RDX);
        *(undefined8 *)(auStack_20 + iVar4) = 0x180239270;
        fcn.1802299d0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        iVar2 = in_RDX[1];
        if (iVar3 == 0) {
            uVar8 = 0x1805aadb1;
            if (iVar2 == 0x102) {
                uVar8 = 0x1804e2c48;
            }
            *(undefined8 *)((int64_t)&var_8h + iVar4) = uVar8;
            *(undefined8 *)(auStack_20 + iVar4) = 0x1802392fc;
            iVar2 = func_0x000180245e70(in_RCX, 0x1804e2c54, in_R8 & 0xffffffff, 0x1805aadb1);
            if (iVar2 < 1) {
                return -1;
            }
            uVar6 = 0;
            uVar5 = 0;
            uVar7 = uVar6;
            if (0 < *in_RDX + -1) {
                do {
                    uVar1 = *(undefined *)(uVar7 + *(int64_t *)(in_RDX + 2));
                    *(undefined8 *)(auStack_20 + iVar4) = 0x18023932e;
                    iVar2 = func_0x000180245e70(in_RCX, 0x1804e2c5c, uVar1, 0x3a);
                    if (iVar2 < 1) {
                        return -1;
                    }
                    uVar5 = (int32_t)uVar6 + 1;
                    uVar6 = (uint64_t)uVar5;
                    uVar7 = uVar7 + 1;
                } while ((int32_t)uVar5 < *in_RDX + -1);
            }
            uVar1 = *(undefined *)((int64_t)(int32_t)uVar5 + *(int64_t *)(in_RDX + 2));
            *(undefined8 *)(auStack_20 + iVar4) = 0x18023935a;
            iVar2 = func_0x000180245e70(in_RCX, 0x1804b8af0, uVar1);
            return (0 < iVar2) - 1;
        }
        iVar9 = *(int64_t *)((int64_t)&arg_40h + iVar4);
        if (iVar2 == 0x102) {
            iVar9 = -iVar9;
        }
        *(int64_t *)((int64_t)&var_10h + iVar4) = iVar9;
        uVar8 = 0x180641948;
        if (iVar2 != 0x102) {
            uVar8 = 0x1805aadb1;
        }
        *(undefined8 *)((int64_t)&var_8h + iVar4) = uVar8;
        *(undefined8 *)(auStack_20 + iVar4) = 0x1802392b8;
        iVar2 = func_0x000180245e70(in_RCX, 0x1804e2c30);
    }
    if (iVar2 < 1) {
        return -1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180239380
// Address: 0x180239380
// Size: 26 bytes
// ============================================================
undefined8 fcn.180239380(int64_t param_1, int32_t param_2)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t *piVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    piVar4 = *(int32_t **)(param_1 + 0x38);
    *(undefined8 *)(&stack0x00000030 + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x1802ab590;
    iVar3 = fcn.18045a350();
    if (piVar4 != (int32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_18 + (iVar2 - iVar3)) = 0x1802ab5a2;
        iVar1 = fcn.180222010();
        if ((param_2 < iVar1) && (-1 < param_2)) {
            if (((piVar4 != (int32_t *)0x0) && (-1 < param_2)) && (param_2 < *piVar4)) {
                return *(undefined8 *)(*(int64_t *)(piVar4 + 2) + (int64_t)param_2 * 8);
            }
            return 0;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1802393a0
// Address: 0x1802393a0
// Size: 26 bytes
// ============================================================
int32_t fcn.1802393a0(int64_t param_1, undefined8 param_2, int32_t param_3)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    int64_t iVar8;
    int32_t iVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar8 = *(int64_t *)(param_1 + 0x38);
    *(undefined8 *)(&stack0x00000038 + iVar4) = unaff_RBX;
    *(undefined8 *)(&stack0x00000040 + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x1802a7015;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802a7025;
    iVar6 = fcn.18022cba0(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4)
                          , *(int64_t *)(&stack0x00000058 + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000078 + iVar5 + iVar4));
    if (iVar6 == 0) {
        return -2;
    }
    if (iVar8 != 0) {
        *(undefined8 *)(&stack0x00000050 + iVar5 + iVar4) = unaff_RDI;
        iVar9 = 0;
        if (-1 < param_3 + 1) {
            iVar9 = param_3 + 1;
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802a7075;
        iVar2 = fcn.180222010(iVar8);
        while( true ) {
            if (iVar2 <= iVar9) {
                return -1;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802a708a;
            puVar7 = (undefined8 *)fcn.180222340(iVar8, iVar9);
            uVar1 = *puVar7;
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802a7095;
            iVar3 = fcn.180298380(uVar1, iVar6);
            if (iVar3 == 0) break;
            iVar9 = iVar9 + 1;
        }
        return iVar9;
    }
    return -1;
}

